"""Tests for docs-alignment deterministic inventory seeding."""

from __future__ import annotations

import importlib.util
import json
import sys
from pathlib import Path

import pytest


REPO_ROOT = Path(__file__).resolve().parents[3]
PLAN_SCRIPT = REPO_ROOT / "scripts/agentflow/docs_alignment/docs_alignment_plan.py"
PIPELINE_SCRIPT = REPO_ROOT / "scripts/agentflow/docs_alignment/docs_alignment_pipeline.py"
RUNNER_SCRIPT = REPO_ROOT / "scripts/agentflow/docs_alignment/run_docs_alignment.py"


def _load_plan_module():
    spec = importlib.util.spec_from_file_location("docs_alignment_plan", PLAN_SCRIPT)
    assert spec is not None
    assert spec.loader is not None
    module = importlib.util.module_from_spec(spec)
    previous = sys.modules.get(spec.name)
    sys.modules[spec.name] = module
    try:
        spec.loader.exec_module(module)
    finally:
        if previous is None:
            sys.modules.pop(spec.name, None)
        else:
            sys.modules[spec.name] = previous
    return module


def _load_pipeline_module():
    spec = importlib.util.spec_from_file_location("docs_alignment_pipeline", PIPELINE_SCRIPT)
    assert spec is not None
    assert spec.loader is not None
    module = importlib.util.module_from_spec(spec)
    previous = sys.modules.get(spec.name)
    sys.modules[spec.name] = module
    try:
        spec.loader.exec_module(module)
    finally:
        if previous is None:
            sys.modules.pop(spec.name, None)
        else:
            sys.modules[spec.name] = previous
    return module


def _load_runner_module():
    spec = importlib.util.spec_from_file_location("run_docs_alignment", RUNNER_SCRIPT)
    assert spec is not None
    assert spec.loader is not None
    module = importlib.util.module_from_spec(spec)
    previous = sys.modules.get(spec.name)
    sys.modules[spec.name] = module
    try:
        spec.loader.exec_module(module)
    finally:
        if previous is None:
            sys.modules.pop(spec.name, None)
        else:
            sys.modules[spec.name] = previous
    return module


def test_build_deterministic_plan_exposes_expected_modules(tmp_path: Path) -> None:
    plan = _load_plan_module()

    (tmp_path / "docs").mkdir(parents=True)
    (tmp_path / "docs/README.md").write_text("# Docs\n", encoding="utf-8")
    (tmp_path / "docs/architecture.md").write_text("# Architecture\n", encoding="utf-8")
    (tmp_path / "docs/notebook").mkdir(parents=True)
    (tmp_path / "docs/plans").mkdir(parents=True)
    (tmp_path / "docs/api").mkdir(parents=True)
    (tmp_path / "docs/api/legacy.md").write_text("legacy\n", encoding="utf-8")
    (tmp_path / "docs/api-server").mkdir(parents=True)
    (tmp_path / "docs/api-server/FILES_CREATED.md").write_text("legacy\n", encoding="utf-8")
    (tmp_path / "docs/operations").mkdir(parents=True)
    (tmp_path / "docs/operations/operations.md").write_text("legacy\n", encoding="utf-8")

    deterministic_plan = plan.build_deterministic_plan(tmp_path)
    modules = deterministic_plan["modules"]
    module_ids = [module["id"] for module in modules]

    assert plan.PLAN_ROOT == Path(".agentflow/docs-alignment/plan")
    assert plan.ROUTER_SKILL_DIR == plan.PLAN_ROOT / "runtime-skills" / "repo-skill-router"
    assert plan.ROUTER_SKILL_REF == str(plan.ROUTER_SKILL_DIR)
    assert module_ids == [
        "clients",
        "api-server",
        "control-plane",
        "compute-plane",
        "workflow",
        "operations",
        "final-surface",
    ]

    final_surface = next(module for module in modules if module["id"] == "final-surface")
    assert final_surface["canonical_targets"] == ["docs/README.md", "docs/architecture.md"]
    assert final_surface["preserve_scope"] == ["docs/notebook"]
    assert "docs/plans" in final_surface["legacy_delete_scope"]
    assert "docs/api" in final_surface["legacy_delete_scope"]
    assert "docs/api-server/FILES_CREATED.md" in final_surface["legacy_delete_scope"]
    assert "docs/operations/operations.md" in final_surface["legacy_delete_scope"]
    assert "docs/notebook" not in final_surface["legacy_delete_scope"]


def test_build_deterministic_plan_uses_file_level_canonical_targets(tmp_path: Path) -> None:
    plan = _load_plan_module()

    deterministic_plan = plan.build_deterministic_plan(tmp_path)
    modules = {module["id"]: module for module in deterministic_plan["modules"]}

    assert modules["clients"]["canonical_targets"] == [
        "docs/clients/README.md",
        "docs/clients/flows.md",
        "docs/clients/boundaries.md",
    ]
    assert modules["clients"]["write_scope"] == [
        "docs/clients/README.md",
        "docs/clients/flows.md",
        "docs/clients/boundaries.md",
    ]
    assert modules["api-server"]["canonical_targets"] == [
        "docs/api-server/README.md",
        "docs/api-server/flows.md",
    ]
    assert modules["api-server"]["write_scope"] == [
        "docs/api-server/README.md",
        "docs/api-server/flows.md",
    ]
    assert modules["control-plane"]["canonical_targets"] == [
        "docs/control-plane/README.md",
        "docs/control-plane/flows.md",
        "docs/control-plane/boundaries.md",
    ]
    assert modules["control-plane"]["write_scope"] == [
        "docs/control-plane/README.md",
        "docs/control-plane/flows.md",
        "docs/control-plane/boundaries.md",
    ]
    assert modules["compute-plane"]["canonical_targets"] == [
        "docs/compute-plane/README.md",
        "docs/compute-plane/flows.md",
        "docs/compute-plane/boundaries.md",
    ]
    assert modules["compute-plane"]["write_scope"] == [
        "docs/compute-plane/README.md",
        "docs/compute-plane/flows.md",
        "docs/compute-plane/boundaries.md",
    ]
    assert modules["workflow"]["canonical_targets"] == [
        "docs/workflow/README.md",
        "docs/workflow/flows.md",
        "docs/workflow/execution-model.md",
        "docs/workflow/plugins.md",
        "docs/workflow/boundaries.md",
    ]
    assert modules["workflow"]["write_scope"] == [
        "docs/workflow/README.md",
        "docs/workflow/flows.md",
        "docs/workflow/execution-model.md",
        "docs/workflow/plugins.md",
        "docs/workflow/boundaries.md",
    ]
    assert modules["operations"]["canonical_targets"] == [
        "docs/operations/README.md",
        "docs/operations/topology.md",
    ]
    assert modules["operations"]["write_scope"] == [
        "docs/operations/README.md",
        "docs/operations/topology.md",
    ]


def test_merge_plan_decisions_defaults_write_scope_to_file_level_canonical_targets(tmp_path: Path) -> None:
    plan = _load_plan_module()

    frozen_plan = plan.merge_plan_decisions(
        plan.build_deterministic_plan(tmp_path),
        {
            "module_decisions": [
                {"id": "clients", "enabled": True},
                {"id": "api-server", "enabled": True},
                {"id": "control-plane", "enabled": True},
                {"id": "compute-plane", "enabled": True},
                {"id": "workflow", "enabled": True},
                {"id": "operations", "enabled": True},
            ]
        },
    )
    modules = {module["id"]: module for module in frozen_plan["modules"]}

    assert modules["clients"]["write_scope"] == [
        "docs/clients/README.md",
        "docs/clients/flows.md",
        "docs/clients/boundaries.md",
    ]
    assert modules["api-server"]["write_scope"] == [
        "docs/api-server/README.md",
        "docs/api-server/flows.md",
    ]
    assert modules["control-plane"]["write_scope"] == [
        "docs/control-plane/README.md",
        "docs/control-plane/flows.md",
        "docs/control-plane/boundaries.md",
    ]
    assert modules["compute-plane"]["write_scope"] == [
        "docs/compute-plane/README.md",
        "docs/compute-plane/flows.md",
        "docs/compute-plane/boundaries.md",
    ]
    assert modules["workflow"]["write_scope"] == [
        "docs/workflow/README.md",
        "docs/workflow/flows.md",
        "docs/workflow/execution-model.md",
        "docs/workflow/plugins.md",
        "docs/workflow/boundaries.md",
    ]
    assert modules["operations"]["write_scope"] == [
        "docs/operations/README.md",
        "docs/operations/topology.md",
    ]


def test_write_plan_seed_artifacts_materializes_inventory_and_router_skill(tmp_path: Path) -> None:
    plan = _load_plan_module()

    (tmp_path / "docs").mkdir(parents=True)
    (tmp_path / "docs/README.md").write_text("# Docs\n", encoding="utf-8")
    (tmp_path / "docs/architecture.md").write_text("# Architecture\n", encoding="utf-8")
    (tmp_path / "skills/local-test-skill").mkdir(parents=True)
    (tmp_path / "skills/local-test-skill/SKILL.md").write_text(
        "---\nname: local-test-skill\ndescription: Local test skill.\n---\n",
        encoding="utf-8",
    )

    plan_dir = tmp_path / plan.PLAN_ROOT
    artifacts = plan.write_plan_seed_artifacts(tmp_path, plan_dir=plan_dir)

    inventory_path = artifacts["inventory_path"]
    skill_catalog_path = artifacts["skill_catalog_path"]
    router_skill_path = artifacts["router_skill_path"]

    assert inventory_path == plan_dir / "inventory.json"
    assert skill_catalog_path == plan_dir / "repo_skill_catalog.md"
    assert router_skill_path == plan_dir / "runtime-skills/repo-skill-router/SKILL.md"
    assert inventory_path.exists()
    assert skill_catalog_path.exists()
    assert router_skill_path.exists()

    inventory_payload = json.loads(inventory_path.read_text(encoding="utf-8"))
    module_ids = [module["id"] for module in inventory_payload["modules"]]
    assert module_ids == [
        "clients",
        "api-server",
        "control-plane",
        "compute-plane",
        "workflow",
        "operations",
        "final-surface",
    ]

    router_text = router_skill_path.read_text(encoding="utf-8")
    assert "repo-skill-router" in router_text
    assert str(skill_catalog_path.relative_to(tmp_path)) in router_text


def test_write_plan_seed_artifacts_defaults_plan_dir_under_monorepo(tmp_path: Path) -> None:
    plan = _load_plan_module()

    (tmp_path / "docs").mkdir(parents=True)
    (tmp_path / "docs/README.md").write_text("# Docs\n", encoding="utf-8")
    (tmp_path / "docs/architecture.md").write_text("# Architecture\n", encoding="utf-8")

    artifacts = plan.write_plan_seed_artifacts(tmp_path)
    expected_plan_dir = tmp_path / plan.PLAN_ROOT

    assert artifacts["inventory_path"] == expected_plan_dir / "inventory.json"
    assert artifacts["skill_catalog_path"] == expected_plan_dir / "repo_skill_catalog.md"
    assert artifacts["router_skill_path"] == expected_plan_dir / "runtime-skills/repo-skill-router/SKILL.md"
    assert artifacts["inventory_path"].exists()
    assert artifacts["skill_catalog_path"].exists()
    assert artifacts["router_skill_path"].exists()


def test_build_plan_pipeline_json_contains_planner_nodes(tmp_path: Path) -> None:
    plan = _load_plan_module()
    (tmp_path / "docs").mkdir(parents=True)
    artifacts = plan.write_plan_seed_artifacts(tmp_path)

    rendered = plan.build_plan_pipeline_json(
        monorepo_path=tmp_path,
        inventory_relative_path=str(Path(artifacts["inventory_path"]).relative_to(tmp_path)),
        skill_catalog_relative_path=str(Path(artifacts["skill_catalog_path"]).relative_to(tmp_path)),
        model="gpt-5.4",
        provider_base_url="http://example.local",
        provider_name="openai-pinned",
        provider_api_key_env="OPENAI_API_KEY",
    )
    payload = json.loads(rendered)
    node_ids = {node["id"] for node in payload["nodes"]}
    assert "plan_module_decisions" in node_ids
    assert "plan_summary" in node_ids


def test_build_module_pipeline_json_uses_frozen_scope(tmp_path: Path) -> None:
    pipeline = _load_pipeline_module()
    plan_path = tmp_path / "modules.json"
    plan_path.write_text(
        json.dumps(
            {
                "modules": [
                    {
                        "id": "clients",
                        "enabled": True,
                        "canonical_targets": [
                            "docs/clients/README.md",
                            "docs/clients/flows.md",
                            "docs/clients/boundaries.md",
                        ],
                        "write_scope": [
                            "docs/clients/README.md",
                            "docs/clients/flows.md",
                            "docs/clients/boundaries.md",
                        ],
                        "preserve_scope": ["docs/notebook"],
                        "legacy_delete_scope": ["docs/plans"],
                        "verify_commands": ["echo verify-clients"],
                    }
                ]
            },
            indent=2,
        )
        + "\n",
        encoding="utf-8",
    )

    rendered = pipeline.build_module_pipeline_json(
        monorepo_path=tmp_path,
        plan_path=plan_path,
        module_id="clients",
        model="gpt-5.4",
        provider_base_url="http://example.local",
        provider_name="openai-pinned",
        provider_api_key_env="OPENAI_API_KEY",
    )
    payload = json.loads(rendered)
    node_ids = {node["id"] for node in payload["nodes"]}
    assert node_ids >= {"review_scope", "rewrite_module", "implementation_review", "verify_module", "final_summary"}
    review_prompt = next(node for node in payload["nodes"] if node["id"] == "review_scope")["prompt"]
    rewrite_prompt = next(node for node in payload["nodes"] if node["id"] == "rewrite_module")["prompt"]
    assert "Canonical target files (must be created or updated by this module only):" in review_prompt
    assert "docs/clients/README.md" in review_prompt
    assert "docs/clients/flows.md" in review_prompt
    assert "docs/clients/boundaries.md" in review_prompt
    assert "docs/notebook" in review_prompt
    assert "docs/plans" in review_prompt
    assert "docs/clients/README.md" in rewrite_prompt
    assert "docs/clients/flows.md" in rewrite_prompt
    assert "docs/clients/boundaries.md" in rewrite_prompt
    assert "Canonical target files:" in rewrite_prompt
    assert "Only create and/or update the listed canonical target files." in rewrite_prompt
    assert "docs/notebook" in rewrite_prompt
    assert "docs/plans" in rewrite_prompt
    assert "Do not create additional docs files beyond the canonical targets" in rewrite_prompt


def test_build_module_pipeline_json_removes_skip_contract_and_uses_unique_review_approval_token(tmp_path: Path) -> None:
    pipeline = _load_pipeline_module()
    plan_path = tmp_path / "modules.json"
    plan_path.write_text(
        json.dumps(
            {
                "modules": [
                    {
                        "id": "clients",
                        "enabled": True,
                        "canonical_targets": [
                            "docs/clients/README.md",
                            "docs/clients/flows.md",
                            "docs/clients/boundaries.md",
                        ],
                        "write_scope": [
                            "docs/clients/README.md",
                            "docs/clients/flows.md",
                            "docs/clients/boundaries.md",
                        ],
                        "preserve_scope": [],
                        "legacy_delete_scope": [],
                        "verify_commands": [
                            "test -e docs/clients/README.md",
                            "test -e docs/clients/flows.md",
                            "test -e docs/clients/boundaries.md",
                        ],
                    }
                ]
            },
            indent=2,
        )
        + "\n",
        encoding="utf-8",
    )

    payload = json.loads(
        pipeline.build_module_pipeline_json(
            monorepo_path=tmp_path,
            plan_path=plan_path,
            module_id="clients",
            model="gpt-5.4",
            provider_base_url="http://example.local",
            provider_name="openai-pinned",
            provider_api_key_env="OPENAI_API_KEY",
        )
    )

    review_scope_prompt = next(node for node in payload["nodes"] if node["id"] == "review_scope")["prompt"]
    rewrite_prompt = next(node for node in payload["nodes"] if node["id"] == "rewrite_module")["prompt"]
    implementation_review_node = next(node for node in payload["nodes"] if node["id"] == "implementation_review")
    implementation_review_prompt = implementation_review_node["prompt"]

    assert "skip" not in review_scope_prompt
    assert "skip" not in rewrite_prompt
    assert "skipped" not in rewrite_prompt
    assert "DOCS_ALIGNMENT_REVIEW_APPROVED" in implementation_review_prompt
    assert "exactly `DOCS_ALIGNMENT_REVIEW_APPROVED` and nothing else" in implementation_review_prompt
    assert "do not include `DOCS_ALIGNMENT_REVIEW_APPROVED` anywhere in the response" in implementation_review_prompt
    assert "LGTM" not in implementation_review_prompt
    assert implementation_review_node["success_criteria"] == [
        {"kind": "output_contains", "value": "DOCS_ALIGNMENT_REVIEW_APPROVED"}
    ]


def test_non_default_plan_dir_updates_router_skill_refs(tmp_path: Path) -> None:
    plan = _load_plan_module()
    pipeline = _load_pipeline_module()
    (tmp_path / "docs").mkdir(parents=True)

    plan_dir = tmp_path / ".agentflow/custom-docs-alignment/plan"
    artifacts = plan.write_plan_seed_artifacts(tmp_path, plan_dir=plan_dir)
    expected_router_skill_ref = str((plan_dir / "runtime-skills" / "repo-skill-router").relative_to(tmp_path))

    inventory_payload = json.loads(artifacts["inventory_path"].read_text(encoding="utf-8"))
    assert inventory_payload["router_skill_ref"] == expected_router_skill_ref

    plan_pipeline = json.loads(
        plan.build_plan_pipeline_json(
            monorepo_path=tmp_path,
            inventory_relative_path=str(Path(artifacts["inventory_path"]).relative_to(tmp_path)),
            skill_catalog_relative_path=str(Path(artifacts["skill_catalog_path"]).relative_to(tmp_path)),
            model="gpt-5.4",
            provider_base_url="http://example.local",
            provider_name="openai-pinned",
            provider_api_key_env="OPENAI_API_KEY",
        )
    )
    for node in plan_pipeline["nodes"]:
        assert node["skills"] == [expected_router_skill_ref]

    modules_path = plan_dir / "modules.json"
    modules_path.write_text(
        json.dumps(
            {
                "modules": [
                    {
                        "id": "clients",
                        "enabled": True,
                        "canonical_targets": [
                            "docs/clients/README.md",
                            "docs/clients/flows.md",
                            "docs/clients/boundaries.md",
                        ],
                        "write_scope": [
                            "docs/clients/README.md",
                            "docs/clients/flows.md",
                            "docs/clients/boundaries.md",
                        ],
                        "preserve_scope": [],
                        "legacy_delete_scope": [],
                        "verify_commands": [
                            "test -e docs/clients/README.md",
                            "test -e docs/clients/flows.md",
                            "test -e docs/clients/boundaries.md",
                        ],
                    }
                ]
            },
            indent=2,
        )
        + "\n",
        encoding="utf-8",
    )
    module_pipeline = json.loads(
        pipeline.build_module_pipeline_json(
            monorepo_path=tmp_path,
            plan_path=modules_path,
            module_id="clients",
            model="gpt-5.4",
            provider_base_url="http://example.local",
            provider_name="openai-pinned",
            provider_api_key_env="OPENAI_API_KEY",
        )
    )
    for node in module_pipeline["nodes"]:
        if node.get("agent") == "codex":
            assert node["skills"] == [expected_router_skill_ref]


def test_merge_plan_decisions_rejects_malformed_string_values_for_list_fields(tmp_path: Path) -> None:
    plan = _load_plan_module()
    base_plan = plan.build_deterministic_plan(tmp_path)

    with pytest.raises(SystemExit, match=r"write_scope.*list"):
        plan.merge_plan_decisions(
            base_plan,
            {"module_decisions": [{"id": "clients", "write_scope": "docs/clients"}]},
        )


def test_build_module_pipeline_json_uses_plan_verify_commands_without_hidden_fallback(tmp_path: Path) -> None:
    plan = _load_plan_module()
    pipeline = _load_pipeline_module()
    (tmp_path / "docs/clients").mkdir(parents=True)

    frozen_plan = plan.merge_plan_decisions(
        plan.build_deterministic_plan(tmp_path),
        {"module_decisions": [{"id": "clients", "enabled": True}]},
    )
    modules_path = tmp_path / "modules.json"
    modules_path.write_text(json.dumps(frozen_plan, indent=2) + "\n", encoding="utf-8")

    rendered = pipeline.build_module_pipeline_json(
        monorepo_path=tmp_path,
        plan_path=modules_path,
        module_id="clients",
        model="gpt-5.4",
        provider_base_url="http://example.local",
        provider_name="openai-pinned",
        provider_api_key_env="OPENAI_API_KEY",
    )
    payload = json.loads(rendered)
    verify_script = next(node for node in payload["nodes"] if node["id"] == "verify_module")["prompt"]
    frozen_module = next(module for module in frozen_plan["modules"] if module["id"] == "clients")

    assert frozen_module["verify_commands"] == [
        "test -e docs/clients/README.md",
        "test -e docs/clients/flows.md",
        "test -e docs/clients/boundaries.md",
    ]
    assert verify_script == (
        "set -euo pipefail\n"
        "test -e docs/clients/README.md\n"
        "test -e docs/clients/flows.md\n"
        "test -e docs/clients/boundaries.md"
    )
    assert "pytest cli/tests/docs -q" not in verify_script


def test_build_module_pipeline_json_rejects_non_boolean_enabled_value(tmp_path: Path) -> None:
    pipeline = _load_pipeline_module()
    plan_path = tmp_path / "modules.json"
    plan_path.write_text(
        json.dumps(
            {
                "modules": [
                    {
                        "id": "clients",
                        "enabled": "false",
                        "canonical_targets": [
                            "docs/clients/README.md",
                            "docs/clients/flows.md",
                            "docs/clients/boundaries.md",
                        ],
                        "write_scope": [
                            "docs/clients/README.md",
                            "docs/clients/flows.md",
                            "docs/clients/boundaries.md",
                        ],
                        "preserve_scope": [],
                        "legacy_delete_scope": [],
                        "verify_commands": [
                            "test -e docs/clients/README.md",
                            "test -e docs/clients/flows.md",
                            "test -e docs/clients/boundaries.md",
                        ],
                    }
                ]
            },
            indent=2,
        )
        + "\n",
        encoding="utf-8",
    )

    with pytest.raises(SystemExit, match=r"enabled.*boolean"):
        pipeline.build_module_pipeline_json(
            monorepo_path=tmp_path,
            plan_path=plan_path,
            module_id="clients",
            model="gpt-5.4",
            provider_base_url="http://example.local",
            provider_name="openai-pinned",
            provider_api_key_env="OPENAI_API_KEY",
        )


def test_write_plan_seed_artifacts_rejects_absolute_plan_dir_outside_monorepo(tmp_path: Path) -> None:
    plan = _load_plan_module()
    (tmp_path / "docs").mkdir(parents=True)

    outside_plan_dir = tmp_path.parent / "external-docs-alignment-plan"

    with pytest.raises(SystemExit, match=r"plan_dir.*inside.*monorepo"):
        plan.build_deterministic_plan(tmp_path, plan_dir=outside_plan_dir)

    with pytest.raises(SystemExit, match=r"plan_dir.*inside.*monorepo"):
        plan.write_plan_seed_artifacts(tmp_path, plan_dir=outside_plan_dir)


def test_pipeline_prompts_escape_working_dir_with_jinja_delimiters(tmp_path: Path) -> None:
    plan = _load_plan_module()
    pipeline = _load_pipeline_module()

    monorepo_path = tmp_path / "repo{{danger}}{%tag%}"
    (monorepo_path / "docs/clients").mkdir(parents=True)
    artifacts = plan.write_plan_seed_artifacts(monorepo_path)

    plan_pipeline = json.loads(
        plan.build_plan_pipeline_json(
            monorepo_path=monorepo_path,
            inventory_relative_path=str(Path(artifacts["inventory_path"]).relative_to(monorepo_path)),
            skill_catalog_relative_path=str(Path(artifacts["skill_catalog_path"]).relative_to(monorepo_path)),
            model="gpt-5.4",
            provider_base_url="http://example.local",
            provider_name="openai-pinned",
            provider_api_key_env="OPENAI_API_KEY",
        )
    )
    plan_prompt = next(node for node in plan_pipeline["nodes"] if node["id"] == "plan_module_decisions")["prompt"]

    frozen_plan = plan.merge_plan_decisions(
        json.loads(artifacts["inventory_path"].read_text(encoding="utf-8")),
        {"module_decisions": [{"id": "clients", "enabled": True}]},
    )
    modules_path = monorepo_path / plan.PLAN_ROOT / "modules.json"
    modules_path.write_text(json.dumps(frozen_plan, indent=2) + "\n", encoding="utf-8")
    module_pipeline = json.loads(
        pipeline.build_module_pipeline_json(
            monorepo_path=monorepo_path,
            plan_path=modules_path,
            module_id="clients",
            model="gpt-5.4",
            provider_base_url="http://example.local",
            provider_name="openai-pinned",
            provider_api_key_env="OPENAI_API_KEY",
        )
    )
    module_prompt = next(node for node in module_pipeline["nodes"] if node["id"] == "review_scope")["prompt"]

    working_dir = str(monorepo_path.resolve())
    assert working_dir not in plan_prompt
    assert working_dir not in module_prompt
    assert "{{ '{{' }}" in plan_prompt
    assert "{{ '{%' }}" in plan_prompt
    assert "{{ '{{' }}" in module_prompt
    assert "{{ '{%' }}" in module_prompt


def test_verify_docs_surface_flags_missing_canonical_file_and_legacy_directory(tmp_path: Path) -> None:
    runner = _load_runner_module()

    (tmp_path / "docs").mkdir(parents=True)
    (tmp_path / "docs/README.md").write_text("# Docs\n", encoding="utf-8")
    (tmp_path / "docs/notebook").mkdir(parents=True)
    for notebook_file in runner.PRESERVED_NOTEBOOK_FILES:
        file_path = tmp_path / notebook_file
        file_path.parent.mkdir(parents=True, exist_ok=True)
        file_path.write_text("preserved\n", encoding="utf-8")

    legacy_dir = tmp_path / "docs/api"
    legacy_dir.mkdir(parents=True, exist_ok=True)
    (legacy_dir / "legacy.md").write_text("legacy\n", encoding="utf-8")

    report = runner.verify_docs_surface(
        monorepo_path=tmp_path,
        reports_dir=tmp_path / ".agentflow" / "docs-alignment" / "plan" / "reports",
    )

    assert report["status"] == "failed"
    assert "docs/architecture.md" in report["missing_canonical_files"]
    assert "docs/api" in report["unexpected_legacy_paths"]
    assert "docs/api" in report["unexpected_legacy_directories"]
    assert report["missing_preserved_notebook_files"] == []


def test_verify_docs_surface_flags_legacy_file_inside_canonical_directory(tmp_path: Path) -> None:
    runner = _load_runner_module()

    for canonical_doc in runner.CANONICAL_DOC_FILES:
        file_path = tmp_path / canonical_doc
        file_path.parent.mkdir(parents=True, exist_ok=True)
        file_path.write_text("canonical\n", encoding="utf-8")
    for notebook_file in runner.PRESERVED_NOTEBOOK_FILES:
        file_path = tmp_path / notebook_file
        file_path.parent.mkdir(parents=True, exist_ok=True)
        file_path.write_text("preserved\n", encoding="utf-8")

    legacy_file = tmp_path / "docs/api-server/FILES_CREATED.md"
    legacy_file.write_text("legacy\n", encoding="utf-8")

    report = runner.verify_docs_surface(
        monorepo_path=tmp_path,
        reports_dir=tmp_path / ".agentflow" / "docs-alignment" / "plan" / "reports",
    )

    assert report["status"] == "failed"
    assert report["unexpected_legacy_files"] == ["docs/api-server/FILES_CREATED.md"]


def test_pick_enabled_modules_rejects_duplicate_requested_modules() -> None:
    runner = _load_runner_module()
    plan_payload = {
        "modules": [
            {"id": "clients", "enabled": True},
            {"id": "api-server", "enabled": True},
        ]
    }

    with pytest.raises(SystemExit, match=r"duplicate.*clients"):
        runner._pick_enabled_modules(plan_payload, ["clients", "clients"], False)


def test_command_wave_rejects_non_positive_max_parallel(tmp_path: Path) -> None:
    runner = _load_runner_module()
    modules_path = tmp_path / "modules.json"
    modules_path.write_text(json.dumps({"modules": []}, indent=2) + "\n", encoding="utf-8")
    args = runner.argparse.Namespace(
        source_repo=str(tmp_path),
        plan_file=str(modules_path),
        plan_worktree=None,
        module=[],
        all_enabled=False,
        base_ref="HEAD",
        max_parallel=0,
        child_progress="off",
    )

    with pytest.raises(SystemExit, match=r"max-parallel.*positive"):
        runner._command_wave(args)


def test_load_plan_file_rejects_missing_and_invalid_json(tmp_path: Path) -> None:
    runner = _load_runner_module()

    missing_path = tmp_path / "missing-modules.json"
    with pytest.raises(SystemExit, match=r"plan file.*not found"):
        runner._load_plan_file(missing_path)

    invalid_path = tmp_path / "invalid-modules.json"
    invalid_path.write_text("{ not-json", encoding="utf-8")
    with pytest.raises(SystemExit, match=r"plan file.*valid JSON"):
        runner._load_plan_file(invalid_path)


def test_install_reference_scripts_allows_repo_root_target() -> None:
    runner = _load_runner_module()

    copied = runner._install_reference_scripts(REPO_ROOT)

    assert copied == [
        "scripts/agentflow/docs_alignment/docs_alignment_plan.py",
        "scripts/agentflow/docs_alignment/docs_alignment_pipeline.py",
        "scripts/agentflow/docs_alignment/run_docs_alignment.py",
    ]
