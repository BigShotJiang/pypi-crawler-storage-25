"""Minimal high-value SDK tests for NotebookAPI."""

from unittest.mock import Mock, patch

import pytest

from agentenv.sdk import NotebookAPI as SDKNotebookAPI


def make_api() -> SDKNotebookAPI:
    return SDKNotebookAPI(Mock())


def test_create_session_forwards_workspace():
    api = make_api()
    created = Mock(id="ns-1")

    with patch("agentenv.api.notebook.NotebookAPI") as low_cls:
        low_cls.return_value.create.return_value = created

        got = api.create(workspace_id="wk-1", name="Session 1")

        assert got is created
        low_cls.return_value.create.assert_called_once_with(
            workspace_id="wk-1",
            name="Session 1",
            type="small",
            cpu=None,
            memory=None,
            image=None,
            snapshot_id=None,
            gpu_count=None,
            gpu_type=None,
            storage_mode=None,
            env=None,
            idle_ttl_seconds=None,
            persistent=None,
            snapshot_favor=None,
            hard_kill_at=None,
            hard_kill_after_seconds=None,
        )


def test_create_document_forwards_image():
    api = make_api()
    created = Mock(id="nb-1")

    with patch("agentenv.api.notebook.NotebookAPI") as low_cls:
        low_cls.return_value.create_document.return_value = created

        got = api.create_document(
            workspace_id="wk-1",
            name="Demo",
            image="docker://registry.example/custom:latest",
        )

        assert got is created
        low_cls.return_value.create_document.assert_called_once_with(
            workspace_id="wk-1",
            name="Demo",
            description=None,
            kernel=None,
            runtime=None,
            image="docker://registry.example/custom:latest",
            auto_save_enabled=None,
            markdown_first_cell=False,
        )


def test_list_all_forwards_workspace_filter():
    api = make_api()
    sessions = [Mock(id="ns-1")]

    with patch("agentenv.api.notebook.NotebookAPI") as low_cls:
        low_cls.return_value.list_all.return_value = sessions

        got = api.list_all(workspace_id="wk-1")

        assert got is sessions
        low_cls.return_value.list_all.assert_called_once_with(workspace_id="wk-1")


def test_session_lifecycle_helpers_forward_to_low_level_api():
    api = make_api()
    session = Mock(id="ns-1")

    with patch("agentenv.api.notebook.NotebookAPI") as low_cls:
        low = low_cls.return_value
        low.get.return_value = session
        low.stop.return_value = session
        low.wake.return_value = session
        low.wait_for_status.return_value = session

        assert api.get("ns-1") is session
        assert api.stop("ns-1") is session
        assert api.wake("ns-1") is session
        api.delete("ns-1")
        assert (
            api.wait_for_status(
                "ns-1",
                desired_status="stopped",
                timeout=5.0,
                interval=0.25,
            )
            is session
        )

        low.get.assert_called_once_with("ns-1")
        low.stop.assert_called_once_with("ns-1")
        low.wake.assert_called_once_with("ns-1")
        low.delete.assert_called_once_with("ns-1")
        low.wait_for_status.assert_called_once_with(
            "ns-1",
            desired_status="stopped",
            timeout=5.0,
            interval=0.25,
        )


def test_import_document_forwards_image():
    api = make_api()
    document = Mock(id="nb-1")

    with patch("agentenv.api.notebook.NotebookAPI") as low_cls:
        low_cls.return_value.import_document.return_value = document

        got = api.import_document(
            workspace_id="wk-1",
            name="Imported",
            url="https://example.com/demo.ipynb",
            image="docker://registry.example/custom:latest",
        )

        assert got is document
        low_cls.return_value.import_document.assert_called_once_with(
            workspace_id="wk-1",
            name="Imported",
            url="https://example.com/demo.ipynb",
            file_path=None,
            image="docker://registry.example/custom:latest",
        )


def test_get_cell_requires_exactly_one_selector():
    api = make_api()

    with pytest.raises(ValueError):
        api.get_cell("nb-1")

    with pytest.raises(ValueError):
        api.get_cell("nb-1", index=0, cell_id="cell-1")


def test_update_cell_resolves_then_updates():
    api = make_api()
    resolved = Mock(id="cell-1", source_ot_version=4)
    updated = Mock(id="cell-1", source="x = 2")

    with patch("agentenv.api.notebook.NotebookAPI") as low_cls:
        low = low_cls.return_value
        low.get_cell.return_value = resolved
        low.update_cell_source.return_value = updated

        got = api.update_cell("nb-1", "x = 2", cell_id="cell-1")

        assert got is updated
        low.get_cell.assert_called_once_with("nb-1", "cell-1")
        low.update_cell_source.assert_called_once_with(
            "nb-1",
            "cell-1",
            "x = 2",
            expected_version=4,
        )


def test_execute_cell_wait_returns_final_cell():
    api = make_api()
    result = Mock(execution_id="exec-1", status="started")
    running = Mock(status="running")
    done = Mock(status="ok")

    with patch("agentenv.api.notebook.NotebookAPI") as low_cls, patch(
        "time.sleep", return_value=None
    ):
        low = low_cls.return_value
        low.execute_cell.return_value = result
        low.get_cell.side_effect = [running, done]

        got = api.execute_cell("nb-1", cell_id="cell-1", wait=True, timeout=2)

        assert got is done
        assert low.get_cell.call_count == 2


def test_execute_cell_wait_returns_final_cell_when_outputs_arrive_without_status():
    api = make_api()
    result = Mock(execution_id="exec-1", status="started")
    baseline = Mock(
        status=None,
        outputs=[
            Mock(
                model_dump=lambda by_alias=True, exclude_none=True: {
                    "outputType": "stream",
                    "text": "old\n",
                }
            )
        ],
        execution_count=None,
        last_run_duration=None,
    )
    done = Mock(
        status=None,
        outputs=[
            Mock(
                model_dump=lambda by_alias=True, exclude_none=True: {
                    "outputType": "stream",
                    "text": "new\n",
                }
            )
        ],
        execution_count=None,
        last_run_duration=None,
    )

    with patch("agentenv.api.notebook.NotebookAPI") as low_cls, patch(
        "time.sleep", return_value=None
    ):
        low = low_cls.return_value
        low.execute_cell.return_value = result
        low.get_cell.side_effect = [baseline, baseline, done]

        got = api.execute_cell("nb-1", cell_id="cell-1", wait=True, timeout=2)

        assert got is done
        assert low.get_cell.call_count == 3


def test_execute_cell_wait_ignores_zero_duration_while_status_is_starting():
    api = make_api()
    result = Mock(execution_id="exec-1", status="started")
    baseline = Mock(
        status=None,
        outputs=[
            Mock(
                model_dump=lambda by_alias=True, exclude_none=True: {
                    "outputType": "stream",
                    "text": "old\n",
                }
            )
        ],
        execution_count=1,
        last_run_at=1000,
        last_run_duration=None,
    )
    starting = Mock(
        status="starting",
        outputs=[
            Mock(
                model_dump=lambda by_alias=True, exclude_none=True: {
                    "outputType": "stream",
                    "text": "old\n",
                }
            )
        ],
        execution_count=1,
        last_run_at=1000,
        last_run_duration=0.0,
    )
    done = Mock(
        status="ok",
        outputs=[
            Mock(
                model_dump=lambda by_alias=True, exclude_none=True: {
                    "outputType": "stream",
                    "text": "new\n",
                }
            )
        ],
        execution_count=2,
        last_run_at=2000,
        last_run_duration=0.4,
    )

    with patch("agentenv.api.notebook.NotebookAPI") as low_cls, patch(
        "time.sleep", return_value=None
    ):
        low = low_cls.return_value
        low.execute_cell.return_value = result
        low.get_cell.side_effect = [baseline, starting, done]

        got = api.execute_cell("nb-1", cell_id="cell-1", wait=True, timeout=2)

        assert got is done
        assert low.get_cell.call_count == 3


def test_ensure_kernel_wait_returns_running_payload():
    api = make_api()

    with patch("agentenv.api.notebook.NotebookAPI") as low_cls, patch(
        "time.sleep", return_value=None
    ):
        low = low_cls.return_value
        low.ensure_kernel.return_value = {"status": "starting"}
        low.get_kernel_status.side_effect = [
            {"status": "busy", "message": "Kernel starting"},
            {"status": "idle"},
        ]

        got = api.ensure_kernel("nb-1", wait=True, timeout=2)

        assert got["status"] == "running"
        assert got["ensureStatus"] == "starting"
        assert got["kernelStatus"] == {"status": "idle"}


def test_kernel_helpers_forward_to_low_level_api():
    api = make_api()

    with patch("agentenv.api.notebook.NotebookAPI") as low_cls:
        low = low_cls.return_value
        low.get_kernel_status.return_value = {"status": "idle"}
        low.interrupt_kernel.return_value = {"status": "interrupted"}
        low.restart_kernel.return_value = {"status": "restarting"}
        low.update_kernel_ttl_policy.return_value = {"persistent": False}
        low.get_cell_outputs.return_value = [Mock(output_type="stream")]
        low.clear_notebook_outputs.return_value = {"clearedCellCount": 2}

        assert api.get_kernel_status("nb-1") == {"status": "idle"}
        assert api.interrupt_kernel("nb-1") == {"status": "interrupted"}
        assert api.restart_kernel("nb-1") == {"status": "restarting"}
        assert api.update_kernel_ttl_policy(
            "nb-1",
            persistent=False,
            idle_ttl_seconds=600,
            snapshot_favor="disk",
            hard_kill_at="2026-02-06T21:00:00Z",
            hard_kill_after_seconds=3600,
        ) == {"persistent": False}
        assert api.get_cell_outputs("nb-1", "cell-1") == [low.get_cell_outputs.return_value[0]]
        assert api.clear_notebook_outputs("nb-1") == {"clearedCellCount": 2}

        low.get_kernel_status.assert_called_once_with("nb-1")
        low.interrupt_kernel.assert_called_once_with("nb-1")
        low.restart_kernel.assert_called_once_with("nb-1")
        low.update_kernel_ttl_policy.assert_called_once_with(
            "nb-1",
            persistent=False,
            idle_ttl_seconds=600,
            snapshot_favor="disk",
            hard_kill_at="2026-02-06T21:00:00Z",
            hard_kill_after_seconds=3600,
        )
        low.get_cell_outputs.assert_called_once_with("nb-1", "cell-1")
        low.clear_notebook_outputs.assert_called_once_with("nb-1")


def test_file_and_collaboration_helpers_forward_to_low_level_api():
    api = make_api()
    file_entry = Mock(path="data/demo.csv")
    collaborator = Mock(user_id="user-1")

    with patch("agentenv.api.notebook.NotebookAPI") as low_cls:
        low = low_cls.return_value
        low.list_files.return_value = [file_entry]
        low.create_directory.return_value = file_entry
        low.upload_file.return_value = file_entry
        low.list_collaborators.return_value = [collaborator]

        assert api.list_files("nb-1", "data") == [file_entry]
        assert api.create_directory("nb-1", "data") is file_entry
        assert api.upload_file(
            "nb-1",
            "/tmp/demo.csv",
            remote_path="data",
            remote_filename="renamed.csv",
        ) is file_entry
        api.download_file("nb-1", "data/demo.csv", "/tmp/demo.csv")
        api.delete_file("nb-1", "data/demo.csv")
        assert api.list_collaborators("nb-1") == [collaborator]

        low.list_files.assert_called_once_with("nb-1", "data")
        low.create_directory.assert_called_once_with("nb-1", "data")
        low.upload_file.assert_called_once_with(
            "nb-1",
            "/tmp/demo.csv",
            remote_path="data",
            remote_filename="renamed.csv",
        )
        low.download_file.assert_called_once_with("nb-1", "data/demo.csv", "/tmp/demo.csv")
        low.delete_file.assert_called_once_with("nb-1", "data/demo.csv")
        low.list_collaborators.assert_called_once_with("nb-1")
