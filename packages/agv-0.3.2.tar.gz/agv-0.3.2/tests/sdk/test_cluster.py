"""Tests for cluster SDK management helpers."""

from types import SimpleNamespace
from unittest.mock import Mock, patch

from agentenv.sdk.cluster import (
    create_ray_cluster,
    create_spark_cluster,
    get_cluster,
    list_clusters,
    stop_cluster,
    wait_for_cluster,
)


def _settings() -> SimpleNamespace:
    return SimpleNamespace(
        api_url="https://api.example.com",
        api_key="sk_test",
        access_token="jwt_test",
        workspace="wk_default",
    )


def test_create_ray_cluster_uses_selected_workspace_by_default() -> None:
    with patch("agentenv.sdk.cluster.get_settings", return_value=_settings()):
        with patch("agentenv.sdk.cluster.ApiClient", return_value=Mock()):
            with patch("agentenv.sdk.cluster.ClusterAPI") as mock_api_cls:
                mock_api_cls.return_value.create_ray_cluster.return_value = {"id": "cl_123"}

                result = create_ray_cluster(shape="4x2xH100")

    assert result == {"id": "cl_123"}
    mock_api_cls.return_value.create_ray_cluster.assert_called_once_with(
        workspace_id="wk_default",
        shape="4x2xH100",
        name=None,
        image=None,
        snapshot_id=None,
        allow_cidr=None,
    )


def test_create_spark_cluster_forwards_optional_fields() -> None:
    with patch("agentenv.sdk.cluster.get_settings", return_value=_settings()):
        with patch("agentenv.sdk.cluster.ApiClient", return_value=Mock()):
            with patch("agentenv.sdk.cluster.ClusterAPI") as mock_api_cls:
                mock_api_cls.return_value.create_spark_cluster.return_value = {"id": "cl_456"}

                result = create_spark_cluster(
                    shape="2xA100",
                    workspace_id="wk_custom",
                    name="spark-demo",
                    image="docker://apache/spark:3.5.8",
                    allow_cidr="1.2.3.4/32",
                )

    assert result == {"id": "cl_456"}
    mock_api_cls.return_value.create_spark_cluster.assert_called_once_with(
        workspace_id="wk_custom",
        shape="2xA100",
        name="spark-demo",
        image="docker://apache/spark:3.5.8",
        snapshot_id=None,
        allow_cidr="1.2.3.4/32",
    )


def test_list_clusters_delegates_to_api_wrapper() -> None:
    with patch("agentenv.sdk.cluster.get_settings", return_value=_settings()):
        with patch("agentenv.sdk.cluster.ApiClient", return_value=Mock()):
            with patch("agentenv.sdk.cluster.ClusterAPI") as mock_api_cls:
                mock_api_cls.return_value.list_clusters.return_value = [{"id": "cl_123"}]

                result = list_clusters(workspace_id="wk_custom")

    assert result == [{"id": "cl_123"}]
    mock_api_cls.return_value.list_clusters.assert_called_once_with(workspace_id="wk_custom")


def test_get_stop_and_wait_delegate_to_api_wrapper() -> None:
    with patch("agentenv.sdk.cluster.get_settings", return_value=_settings()):
        with patch("agentenv.sdk.cluster.ApiClient", return_value=Mock()):
            with patch("agentenv.sdk.cluster.ClusterAPI") as mock_api_cls:
                mock_api_cls.return_value.get_cluster.return_value = {"id": "cl_123", "status": "running"}
                mock_api_cls.return_value.stop_cluster.return_value = {"id": "cl_123", "status": "stopping"}
                mock_api_cls.return_value.wait_for_cluster.return_value = {"id": "cl_123", "status": "running"}

                got = get_cluster("cl_123")
                stopped = stop_cluster("cl_123")
                waited = wait_for_cluster("cl_123", timeout=30, target_status="running", poll_interval=1.0)

    assert got["status"] == "running"
    assert stopped["status"] == "stopping"
    assert waited["status"] == "running"
    mock_api_cls.return_value.get_cluster.assert_called_once_with("cl_123")
    mock_api_cls.return_value.stop_cluster.assert_called_once_with("cl_123")
    mock_api_cls.return_value.wait_for_cluster.assert_called_once_with(
        "cl_123",
        timeout=30,
        target_status="running",
        terminal_statuses=None,
        poll_interval=1.0,
    )
