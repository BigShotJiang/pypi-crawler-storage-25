"""Tests for AI SDK."""

import pytest
from unittest.mock import Mock, patch

from agentenv.sdk.ai import AIClient, ChatCompletions, ManagementAPI


class TestAIClient:
    """Test AIClient SDK."""

    @patch("agentenv.sdk.ai.Client")
    def test_init_with_api_key(self, mock_client_class):
        """Test initialization with API key."""
        mock_client = Mock()
        mock_client_class.return_value = mock_client

        client = AIClient(api_key="cr_test123")

        assert client.api_key == "cr_test123"
        assert client.chat is not None
        assert client.chat.completions is not None
        assert client.embeddings is not None

    @patch("agentenv.sdk.ai.Client")
    @patch.dict("os.environ", {"AGENTENV_AI_KEY": "cr_env_key"})
    def test_init_from_env(self, mock_client_class):
        """Test initialization from environment variable."""
        mock_client = Mock()
        mock_client_class.return_value = mock_client

        client = AIClient()

        assert client.api_key == "cr_env_key"


class TestChatCompletions:
    """Test ChatCompletions SDK."""

    def test_create_non_streaming(self):
        """Test non-streaming chat completion."""
        mock_api = Mock()
        mock_response = Mock()
        mock_response.id = "chat_123"
        mock_response.choices = [Mock(message=Mock(content="Hello!"))]
        mock_api.create.return_value = mock_response

        chat = ChatCompletions(mock_api)
        response = chat.create(
            model="gpt-4",
            messages=[{"role": "user", "content": "Hi"}],
            stream=False,
        )

        assert response.id == "chat_123"
        mock_api.create.assert_called_once()

    def test_create_with_message_objects(self):
        """Test chat with Message objects."""
        mock_api = Mock()
        mock_response = Mock()
        mock_response.id = "chat_123"
        mock_response.choices = [Mock(message=Mock(content="Hello!"))]
        mock_api.create.return_value = mock_response

        from agentenv.api.models import Message

        chat = ChatCompletions(mock_api)
        response = chat.create(
            model="gpt-4",
            messages=[Message(role="user", content="Hi")],
        )

        assert response.id == "chat_123"


class TestManagementAPI:
    """Test AI management SDK wrappers."""

    def test_add_platform_pool_member(self):
        """Test platform-model pool members are supported."""
        mock_api = Mock()
        mock_api.add_pool_member.return_value = {"id": "pool_123"}

        management_api = ManagementAPI(mock_api)

        response = management_api.add_pool_member(
            "pool_123",
            source_type="platform",
            platform_model_id="openai/gpt-4o",
            priority=2,
            weight=3,
        )

        assert response == {"id": "pool_123"}
        mock_api.add_pool_member.assert_called_once_with(
            "pool_123",
            upstream_id=None,
            priority=2,
            weight=3,
            source_type="platform",
            platform_model_id="openai/gpt-4o",
        )

    def test_get_usage_forwards_extended_filters(self):
        """Test usage filters are exposed in the high-level SDK."""
        mock_api = Mock()
        expected_report = Mock()
        mock_api.get_usage.return_value = expected_report

        management_api = ManagementAPI(mock_api)
        report = management_api.get_usage(
            start_date="2026-04-01",
            end_date="2026-04-07",
            upstream_id="up_123",
            api_key_id="key_123",
            provider_type="openai",
            model="gpt-4o",
            limit=5,
        )

        assert report is expected_report
        mock_api.get_usage.assert_called_once_with(
            start_date="2026-04-01",
            end_date="2026-04-07",
            upstream_id="up_123",
            api_key_id="key_123",
            provider_type="openai",
            model="gpt-4o",
            limit=5,
        )

    def test_list_platform_models(self):
        """Test model discovery is available from management SDK."""
        mock_api = Mock()
        mock_api.list_platform_models.return_value = {"providers": [{"id": "openai"}]}

        management_api = ManagementAPI(mock_api)
        payload = management_api.list_platform_models()

        assert payload["providers"][0]["id"] == "openai"
        mock_api.list_platform_models.assert_called_once_with()
