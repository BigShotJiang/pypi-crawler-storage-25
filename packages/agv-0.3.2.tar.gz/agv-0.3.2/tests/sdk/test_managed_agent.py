"""Tests for managed-agent SDK support."""

from types import SimpleNamespace
from unittest.mock import Mock, patch

from agentenv.api.models import APIError
from agentenv.sdk import Client, ManagedAgentAPI as SDKManagedAgentAPI
from agentenv.api.models import ManagedAgentListResponse


def test_client_exposes_managed_agent_properties() -> None:
    """Client should expose managed_agent and managed_agents properties."""
    settings = SimpleNamespace(
        api_url="https://api.example.com",
        api_key=None,
        access_token=None,
    )

    with patch("agentenv.sdk.get_settings", return_value=settings):
        with patch("agentenv.sdk._Client") as mock_client_class:
            mock_client = Mock()
            mock_client_class.return_value = mock_client

            client = Client(api_key="sk_test")

    assert isinstance(client.managed_agent, SDKManagedAgentAPI)
    assert isinstance(client.managed_agents, SDKManagedAgentAPI)


def test_managed_agent_sdk_list_all_delegates_to_api_wrapper() -> None:
    """SDK managed-agent wrapper should delegate to the API layer."""
    api_client = Mock()
    expected = ManagedAgentListResponse(total=0, page=1, limit=50, agents=[])

    with patch("agentenv.api.managed_agent.ManagedAgentAPI.list_all", return_value=expected) as mock_list:
        wrapper = SDKManagedAgentAPI(api_client)
        result = wrapper.list_all(workspace_id="wk_123", page=2, limit=10)

    assert result == expected
    mock_list.assert_called_once_with(
        workspace_id="wk_123",
        agent_workspace_group_id=None,
        search=None,
        page=2,
        limit=10,
    )


def test_managed_agent_sdk_send_message_delegates_to_api_wrapper() -> None:
    """SDK managed-agent wrapper should expose message streaming helpers."""
    api_client = Mock()
    expected = [{"type": "message.completed", "content": "done"}]

    with patch("agentenv.api.managed_agent.ManagedAgentAPI.send_message", return_value=expected) as mock_send:
        wrapper = SDKManagedAgentAPI(api_client)
        result = wrapper.send_message("ma_123", "hello")

    assert result == expected
    mock_send.assert_called_once_with("ma_123", "hello")


def test_managed_agent_sdk_wait_for_status_delegates_to_api_wrapper() -> None:
    """SDK managed-agent wrapper should expose polling helpers."""
    api_client = Mock()
    expected = Mock(status="running")

    with patch(
        "agentenv.api.managed_agent.ManagedAgentAPI.wait_for_status",
        return_value=expected,
    ) as mock_wait:
        wrapper = SDKManagedAgentAPI(api_client)
        result = wrapper.wait_for_status("ma_123", timeout=30, interval=1)

    assert result == expected
    mock_wait.assert_called_once_with(
        "ma_123",
        desired_status="running",
        timeout=30,
        interval=1,
    )


def test_managed_agent_sdk_wake_and_wait_delegates_to_api_wrapper() -> None:
    """SDK managed-agent wrapper should expose a wake-and-poll helper."""
    api_client = Mock()
    expected = Mock(status="running")

    with patch("agentenv.api.managed_agent.ManagedAgentAPI.wake") as mock_wake:
        with patch(
            "agentenv.api.managed_agent.ManagedAgentAPI.wait_for_status",
            return_value=expected,
        ) as mock_wait:
            wrapper = SDKManagedAgentAPI(api_client)
            result = wrapper.wake_and_wait("ma_123", timeout=30, interval=1)

    assert result == expected
    mock_wake.assert_called_once_with("ma_123")
    mock_wait.assert_called_once_with(
        "ma_123",
        desired_status="running",
        timeout=30,
        interval=1,
    )


def test_managed_agent_sdk_wake_and_wait_tolerates_inflight_wake() -> None:
    """wake_and_wait should still poll when the wake request races with the backend."""
    api_client = Mock()
    expected = Mock(status="running")

    with patch(
        "agentenv.api.managed_agent.ManagedAgentAPI.wake",
        side_effect=APIError(
            status_code=409,
            message="Managed agent is already waking",
            details={"code": "already_waking"},
        ),
    ) as mock_wake:
        with patch(
            "agentenv.api.managed_agent.ManagedAgentAPI.wait_for_status",
            return_value=expected,
        ) as mock_wait:
            wrapper = SDKManagedAgentAPI(api_client)
            result = wrapper.wake_and_wait("ma_123")

    assert result == expected
    mock_wake.assert_called_once_with("ma_123")
    mock_wait.assert_called_once_with(
        "ma_123",
        desired_status="running",
        timeout=120.0,
        interval=0.5,
    )


def test_managed_agent_sdk_wake_and_wait_propagates_unexpected_wake_errors() -> None:
    """wake_and_wait should not hide real wake failures."""
    api_client = Mock()
    failure = APIError(status_code=401, message="Unauthorized")

    with patch(
        "agentenv.api.managed_agent.ManagedAgentAPI.wake",
        side_effect=failure,
    ) as mock_wake:
        with patch("agentenv.api.managed_agent.ManagedAgentAPI.wait_for_status") as mock_wait:
            wrapper = SDKManagedAgentAPI(api_client)
            try:
                wrapper.wake_and_wait("ma_123")
            except APIError as exc:
                assert exc is failure
            else:
                raise AssertionError("Expected APIError")

    mock_wake.assert_called_once_with("ma_123")
    mock_wait.assert_not_called()
