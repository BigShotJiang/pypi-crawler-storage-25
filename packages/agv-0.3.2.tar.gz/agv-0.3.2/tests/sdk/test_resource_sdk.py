from __future__ import annotations

from pathlib import Path
from unittest.mock import Mock, patch

from agentenv.sdk import AppAPI, FileAPI as SDKFileAPI, SiteAPI as SDKSiteAPI, WorkflowAPI as SDKWorkflowAPI
from agentenv.sdk import Client


def test_client_exposes_resource_wrappers() -> None:
    client = Client.__new__(Client)
    client._client = Mock()

    assert isinstance(client.app, AppAPI)
    assert isinstance(client.site, SDKSiteAPI)
    assert isinstance(client.file, SDKFileAPI)
    assert isinstance(client.workflow, SDKWorkflowAPI)


def test_app_sdk_delegates_to_api_wrapper() -> None:
    api_client = Mock()
    wrapper = AppAPI(api_client)

    with patch("agentenv.sdk._AppAPI") as api_cls:
        api = api_cls.return_value
        api.list_all.return_value = ["app-1"]
        api.get.return_value = {"id": "app-1"}
        api.create.return_value = {"id": "app-2"}

        assert wrapper.list_all(workspace_id="wk_123") == ["app-1"]
        assert wrapper.get("app-1") == {"id": "app-1"}
        assert wrapper.create(name="web", port=8080) == {"id": "app-2"}

        api.list_all.assert_called_once_with(workspace_id="wk_123")
        api.get.assert_called_once_with("app-1")
        api.create.assert_called_once_with({"name": "web", "port": 8080})


def test_site_sdk_delegates_to_api_wrapper(tmp_path: Path) -> None:
    api_client = Mock()
    wrapper = SDKSiteAPI(api_client)
    zip_path = tmp_path / "site.zip"
    zip_path.write_bytes(b"zip")

    with patch("agentenv.sdk._SiteAPI") as api_cls:
        api = api_cls.return_value
        api.list_all.return_value = ["site-1"]
        api.get.return_value = {"id": "site-1"}
        api.create.return_value = {"id": "site-2"}
        api.deploy.return_value = {"id": "site-1", "version": "v2"}

        assert wrapper.list_all(workspace_id="wk_123") == ["site-1"]
        assert wrapper.get("site-1") == {"id": "site-1"}
        assert wrapper.create("docs", slug="docs", workspace_id="wk_123") == {"id": "site-2"}
        assert wrapper.deploy("site-1", zip_path) == {"id": "site-1", "version": "v2"}

        api.list_all.assert_called_once_with(workspace_id="wk_123")
        api.get.assert_called_once_with("site-1")
        api.create.assert_called_once_with(name="docs", slug="docs", workspace_id="wk_123")
        api.deploy.assert_called_once_with("site-1", zip_path)


def test_file_sdk_delegates_to_api_wrapper(tmp_path: Path) -> None:
    api_client = Mock()
    wrapper = SDKFileAPI(api_client)
    local_file = tmp_path / "payload.txt"
    local_file.write_text("payload", encoding="utf-8")

    with patch("agentenv.sdk._FileAPI") as api_cls:
        api = api_cls.return_value
        api.list_all.return_value = ["file-1"]
        api.upload.return_value = {"path": "/remote.txt"}
        api.download.return_value = None

        assert wrapper.list_all(workspace_id="wk_123", path="/") == ["file-1"]
        assert wrapper.upload(str(local_file), remote_path="/remote.txt", workspace_id="wk_123") == {
            "path": "/remote.txt"
        }
        wrapper.download("/remote.txt", str(tmp_path / "downloaded.txt"), workspace_id="wk_123")

        api.list_all.assert_called_once_with(workspace_id="wk_123", path="/")
        api.upload.assert_called_once_with(str(local_file), "wk_123", "/remote.txt")
        api.download.assert_called_once_with("/remote.txt", str(tmp_path / "downloaded.txt"), "wk_123")


def test_workflow_sdk_delegates_to_api_wrapper() -> None:
    api_client = Mock()
    wrapper = SDKWorkflowAPI(api_client)

    with patch("agentenv.sdk._WorkflowAPI") as api_cls:
        api = api_cls.return_value
        api.list_all.return_value = ["wf-1"]
        api.create.return_value = {"id": "wf-1"}
        api.execute.return_value = {"executionId": "exec_1"}
        api.list_trusted_plugins.return_value = ["http", "slack"]

        assert wrapper.list_all(workspace_id="wk_123") == ["wf-1"]
        assert wrapper.create("wk_123", "Example", {"nodes": [], "edges": []}) == {"id": "wf-1"}
        assert wrapper.execute("wf_123", input_data={"x": 1}) == {"executionId": "exec_1"}
        assert wrapper.list_trusted_plugins() == ["http", "slack"]

        api.list_all.assert_called_once_with("wk_123", status=None)
        api.create.assert_called_once_with("wk_123", "Example", {"nodes": [], "edges": []}, description=None)
        api.execute.assert_called_once_with("wf_123", input_data={"x": 1}, trigger_node_id=None)
        api.list_trusted_plugins.assert_called_once_with()
