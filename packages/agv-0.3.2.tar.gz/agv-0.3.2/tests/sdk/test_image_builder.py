"""Tests for SDK image builder conditions and sandbox helpers."""

import sys
from types import SimpleNamespace
from unittest.mock import Mock, patch

import httpx
import pytest

sys.modules.setdefault(
    "yaml",
    SimpleNamespace(
        safe_load=lambda *args, **kwargs: {},
        safe_dump=lambda *args, **kwargs: "",
    ),
)
sys.modules.setdefault(
    "dotenv",
    SimpleNamespace(load_dotenv=lambda *args, **kwargs: None),
)

from agentenv.sdk import SandboxResource
from agentenv.sdk.image import condition, http_ready, image


def make_sandbox_resource() -> SandboxResource:
    sandbox = SimpleNamespace(
        id="sb-1",
        status="running",
        config={},
        metadata={},
    )
    return SandboxResource(Mock(), sandbox)


def test_sandbox_resource_exec_delegates_to_api() -> None:
    resource = make_sandbox_resource()
    result = SimpleNamespace(exec_id="exec-1", output="ok", exit_code=0)

    with patch("agentenv.api.sandbox.SandboxAPI") as low_cls:
        low_cls.return_value.exec.return_value = result

        got = resource.exec("echo ok")

    assert got is result
    low_cls.return_value.exec.assert_called_once_with("sb-1", "echo ok")


def test_sandbox_resource_ensure_port_reuses_existing_mapping() -> None:
    resource = make_sandbox_resource()
    existing = SimpleNamespace(
        host_port=12345,
        container_port=8080,
        protocol="http",
        host_ip="10.0.0.1",
        public_url="https://example.test",
    )

    with patch.object(resource, "list_ports", return_value=[existing]) as list_ports, patch.object(
        resource, "expose_port"
    ) as expose_port:
        got = resource.ensure_port(8080, "http")

    assert got is existing
    list_ports.assert_called_once()
    expose_port.assert_not_called()


def test_sandbox_resource_http_ready_uses_reachable_mapping() -> None:
    resource = make_sandbox_resource()
    mapping = SimpleNamespace(
        host_port=12345,
        container_port=4500,
        protocol="tcp",
        host_ip="10.0.0.1",
        public_url=None,
    )

    with patch.object(resource, "ensure_port", return_value=mapping), patch(
        "httpx.request",
        return_value=httpx.Response(200, request=httpx.Request("GET", "http://10.0.0.1:12345/readyz")),
    ) as request:
        assert resource.http_ready(4500, path="/readyz", port_type="tcp") is True

    request.assert_called_once()


def test_image_builder_wait_until_requires_name_for_lambda() -> None:
    builder = image("python:3.11", workspace_id="wk_123")

    with pytest.raises(ValueError):
        builder.wait_until(lambda sandbox: True)


def test_image_builder_finalize_waits_for_condition_before_snapshot() -> None:
    settings = SimpleNamespace(
        api_url="https://api.example.com",
        api_key=None,
        access_token=None,
        resolve_image=lambda value: value,
    )
    sandbox_model = SimpleNamespace(id="sb-1", status="running", config={}, metadata={})
    image_model = SimpleNamespace(id="img-1", status="completed")
    fake_client = Mock()

    class FakeSandboxResource:
        def __init__(self):
            self.id = "sb-1"
            self.status = "running"
            self.refresh_count = 0

        def refresh(self) -> None:
            self.refresh_count += 1

    fake_resource = FakeSandboxResource()
    predicate_calls = {"count": 0}

    def ready_when_polled_twice(sandbox: FakeSandboxResource) -> bool:
        predicate_calls["count"] += 1
        return predicate_calls["count"] >= 2

    with patch("agentenv.sdk.image.get_settings", return_value=settings), patch(
        "agentenv.sdk.image.ApiClient", return_value=fake_client
    ), patch("agentenv.sdk.image.SandboxAPI") as sandbox_api_cls, patch(
        "agentenv.sdk.image.ImageAPI"
    ) as image_api_cls, patch("time.sleep", return_value=None):
        sandbox_api = sandbox_api_cls.return_value
        image_api = image_api_cls.return_value
        sandbox_api.create.return_value = sandbox_model
        sandbox_api.wait_for_status.return_value = sandbox_model
        sandbox_api.exec.return_value = SimpleNamespace(exit_code=0, output="")
        image_api.list_all.return_value = []
        image_api.ensure.return_value = image_model

        builder = image("python:3.11", workspace_id="wk_123")
        builder.wait_until(
            condition(
                ready_when_polled_twice,
                name="ready-when-polled-twice",
                hash_data={"type": "custom-ready"},
                interval=0.01,
            )
        )
        builder._sandbox_resource = lambda sandbox: fake_resource  # type: ignore[method-assign]

        got = builder.finalize()

    assert got is image_model
    assert predicate_calls["count"] == 2
    assert fake_resource.refresh_count == 2
    image_api.ensure.assert_called_once()
    sandbox_api.exec.assert_called_once()


def test_image_builder_build_hash_changes_when_condition_changes() -> None:
    builder_a = image("python:3.11", workspace_id="wk_123").wait_until(
        http_ready(4500, "/readyz", port_type="tcp")
    )
    builder_b = image("python:3.11", workspace_id="wk_123").wait_until(
        http_ready(8888, "/api/status", port_type="tcp")
    )

    assert builder_a.build_hash() != builder_b.build_hash()
