"""Data filters

Collection of filters that can be chained together.
"""

# pylint: disable=missing-function-docstring

# External modules
import pandas as pd

def value_filter(d, var, val):
    if d.empty:
        return ~d.index.isna(), [var]
    if isinstance(val, list):
        min_val, max_val = min(val), max(val)
    else:
        min_val, max_val = val, val
    if var in d:
        return (min_val <= d[var].ffill()) & (d[var].ffill() <= max_val), [var]
    _min = var + "_min"
    _max = var + "_max"
    return (d[_min].ffill() <= max_val) & (min_val <= d[_max].ffill()), [var]

def starting(d):
    return value_filter(d, "State [-]", 3)

def running(d):
    return value_filter(d, "State [-]", 4)

def stopping(d):
    return value_filter(d, "State [-]", 5)

def where(d, condition):
    f_a = ~d.index.isna()
    v_a = []
    for var, val in condition.items():
        f, v = value_filter(d, var, val)
        f_a &= f
        v_a += v
    return f_a, v_a

def edge(d, var, vals):
    f, v = where(d, {var: vals[1]})
    if d.empty:
        return f, v
    d1 = d.shift(1).bfill()
    f1, _ = where(d1, {var: vals[0]})
    ft = f & f1
    return ft | ft.shift(-1).ffill(), v

def steady(d, window=None, limits=None):
    window = window or "5min"
    limits = limits or {
        "TT938 [deg C]": 0.25,
        "TT939 [deg C]": 0.25,
        "TT536 [deg C]": 0.25,
        "TT537 [deg C]": 0.25,
        "PowerOutput [kW]": 2,
        "FCP793SpeedSetpoint [%]": 0.5,
    }
    var = list(limits.keys()) + ["State [-]"]
    f, _ = running(d)
    if not all(v in d for v in limits):
        return f, var
    std = d.rolling(window, center=True).std().fillna(max(limits.values()))
    for k, v in limits.items():
        f &= std[k] < v
    return f, var

def steady_where(d, condition, window=None, limits=None):
    f_s, v_s = steady(d, window, limits)
    f_w, v_w = where(d, condition)
    return f_s & f_w, v_s + v_w

def less_than(d, v1, v2, margin=0):
    """Check where d[v1] < d[v2]"""
    if d.empty:
        return ~d.index.isna(), [v1, v2]
    if v1 in d:
        f = d[v1] < d[v2] - margin
    else:
        f = d[v1 + "_min"] < d[v2 + "_max"] - margin
    return f, [v1, v2]

def true_for(f, time):
    """Filter where f has been True for long enough"""
    n = int(pd.Timedelta(time)/f.index.freq)
    if n == 0:
        return f
    return f.rolling(n).sum() == n

def shift(d, time):
    """Shift a dataframe/series based on time"""
    n = int(pd.Timedelta(time)/d.index.freq)
    return d.shift(n)

def extend(f, time):
    """Extend/pad the True values in a boolean series by time"""
    n = int(pd.Timedelta(time)/f.index.freq)
    return f.rolling(window=2*n+1, center=True, min_periods=1).max().astype(bool)
