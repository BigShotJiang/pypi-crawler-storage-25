#!/usr/bin/env python3
"""
Stripe Integration Manager for Terradev
Handles dynamic checkout session creation, webhook processing,
and Enterprise+ metered GPU-hour billing.
"""

import os
import json
import math
try:
    import stripe
except ImportError:
    stripe = None
from typing import Dict, Optional, Any, List
from datetime import datetime
from pathlib import Path
import logging

logger = logging.getLogger(__name__)

# Enterprise+ metered billing rate
ENTERPRISE_PLUS_GPU_HOUR_RATE_CENTS = 9  # $0.09 per GPU-hour
ENTERPRISE_PLUS_MIN_GPUS = 32
ENTERPRISE_PLUS_MIN_MONTHLY_HOURS = 128  # Minimum 128 hours of usage per month
# Monthly floor: 32 GPUs × 128 hrs = 4,096 GPU-hours = $368.64/month minimum
ENTERPRISE_PLUS_MONTHLY_FLOOR_GPU_HOURS = ENTERPRISE_PLUS_MIN_GPUS * ENTERPRISE_PLUS_MIN_MONTHLY_HOURS


class StripeManager:
    """Manages Stripe integration for Terradev CLI"""
    
    def __init__(self):
        # BYOAPI: Stripe billing permanently disabled
        self.demo_mode = True
        self.publishable_key = ""
        self.secret_key = None
        self._metering_file = Path.home() / '.terradev' / 'gpu_metering.json'
        logger.info("Stripe billing disabled - BYOAPI mode active")
    
    # ── Flat-rate subscription checkout (Research+ / Enterprise) ──────

    def create_checkout_session(self, tier: str, customer_email: str, success_url: str, cancel_url: str) -> Dict[str, Any]:
        """Create a dynamic Stripe checkout session - DISABLED (BYOAPI)"""
        logger.info("Stripe checkout disabled - BYOAPI mode")
        return {
            'disabled': True,
            'message': 'Billing disabled - BYOAPI mode active',
            'session_id': None,
            'checkout_url': None
        }

    # ── Enterprise+ metered subscription ─────────────────────────────

    def _create_enterprise_plus_checkout(self, customer_email: str, success_url: str, cancel_url: str) -> Dict[str, Any]:
        """Create a Stripe checkout session for Enterprise+ metered billing.
        
        Enterprise+ uses Stripe metered usage billing:
        - $0.09 × max(gpu_count, 32) × hours_used, billed monthly
        - 32-GPU floor per instance (8 GPUs billed as 32, 72 billed as 72)
        - Monthly minimum: 32 GPUs × 128 hrs = 4,096 GPU-hrs ($368.64/mo)
        - No charge for months with zero usage; minimum reconciled at month end
        - Card on file, invoiced at end of billing period
        """
        try:
            product = self._get_or_create_product('enterprise_plus', {
                'name': 'Terradev Enterprise+',
                'description': 'Metered GPU-hour billing — $0.09 × max(gpu_count, 32) × hours_used. '
                               '32-GPU floor per instance. Monthly minimum: 4,096 GPU-hrs ($368.64/mo). '
                               'Unlimited provisions, servers, seats, dedicated support.',
            })
            
            # Create metered price (usage-based, billed per GPU-hour)
            price = self._get_or_create_metered_price(product.id)
            
            session = stripe.checkout.Session.create(
                payment_method_types=['card'],
                line_items=[{
                    'price': price.id,
                }],
                mode='subscription',
                success_url=success_url,
                cancel_url=cancel_url,
                customer_email=customer_email,
                metadata={
                    'tier': 'enterprise_plus',
                    'product': 'terradev_cli',
                    'version': '3.1.8',
                    'billing_model': 'metered',
                    'gpu_hour_rate_cents': str(ENTERPRISE_PLUS_GPU_HOUR_RATE_CENTS),
                    'min_gpus': str(ENTERPRISE_PLUS_MIN_GPUS),
                },
                subscription_data={
                    'metadata': {
                        'tier': 'enterprise_plus',
                        'product': 'terradev_cli',
                        'billing_model': 'metered',
                    }
                }
            )
            
            return {
                'session_id': session.id,
                'checkout_url': session.url,
                'publishable_key': self.publishable_key
            }
            
        except Exception as e:
            logging.error(f"Failed to create Enterprise+ checkout: {e}")
            raise

    def _get_or_create_metered_price(self, product_id: str) -> stripe.Price:
        """Get or create a metered price for Enterprise+ GPU-hour billing."""
        try:
            prices = stripe.Price.list(product=product_id, limit=100, active=True)
            for price in prices.data:
                if (price.recurring and
                    price.recurring.get('usage_type') == 'metered' and
                    price.unit_amount == ENTERPRISE_PLUS_GPU_HOUR_RATE_CENTS and
                    price.currency == 'usd'):
                    return price
            
            # Create metered price — $0.09 per GPU-hour, billed monthly
            return stripe.Price.create(
                product=product_id,
                unit_amount=ENTERPRISE_PLUS_GPU_HOUR_RATE_CENTS,  # 9 cents
                currency='usd',
                recurring={
                    'interval': 'month',
                    'usage_type': 'metered',
                    'aggregate_usage': 'sum',  # Sum all GPU-hours in the period
                },
                metadata={
                    'tier': 'enterprise_plus',
                    'product': 'terradev_cli',
                    'unit': 'gpu_hour',
                }
            )
        except Exception as e:
            logging.error(f"Failed to get/create metered price: {e}")
            raise

    # ── GPU-hour metering ────────────────────────────────────────────

    def report_gpu_hours(self, subscription_item_id: str, gpu_hours: float,
                         gpu_type: str = '', instance_id: str = '') -> Optional[Dict[str, Any]]:
        """Report GPU-hour usage to Stripe for metered billing - DISABLED (BYOAPI)"""
        logger.info(f"GPU-hour billing disabled - BYOAPI mode: {gpu_hours:.2f} hours tracked locally only")
        # Track locally for audit trail only (no billing)
        self._record_local_metering(gpu_hours, gpu_type, instance_id, reported=False)
        return {'disabled': True, 'gpu_hours': gpu_hours, 'billed': False}

    def get_subscription_item_id(self, customer_email: str) -> Optional[str]:
        """Look up the Enterprise+ subscription item ID for a customer.
        
        The subscription item ID is needed to report metered usage.
        Cached locally in ~/.terradev/gpu_metering.json after first lookup.
        """
        # Check local cache first
        metering = self._load_metering()
        cached_id = metering.get('subscription_item_id')
        if cached_id:
            return cached_id
        
        if self.demo_mode:
            return 'si_demo_enterprise_plus'
        
        try:
            # Find customer by email
            customers = stripe.Customer.list(email=customer_email, limit=1)
            if not customers.data:
                return None
            
            customer = customers.data[0]
            
            # Find active Enterprise+ subscription
            subscriptions = stripe.Subscription.list(
                customer=customer.id, status='active', limit=10
            )
            for sub in subscriptions.data:
                if sub.metadata.get('tier') == 'enterprise_plus':
                    # Get the metered subscription item
                    for item in sub['items']['data']:
                        if (item.price.recurring and 
                            item.price.recurring.get('usage_type') == 'metered'):
                            # Cache it
                            metering['subscription_item_id'] = item.id
                            metering['subscription_id'] = sub.id
                            metering['customer_id'] = customer.id
                            self._save_metering(metering)
                            return item.id
            
            return None
            
        except Exception as e:
            logging.error(f"Failed to look up subscription item: {e}")
            return None

    def reconcile_monthly_minimum(self, subscription_item_id: str) -> Optional[Dict[str, Any]]:
        """Reconcile monthly minimum at month boundary.

        Enterprise+ floor: 32 GPUs x 48 hrs = 1,536 GPU-hrs ($138.24/mo).
        If actual usage for previous month < floor, report shortfall to Stripe.
        Tracks reconciled months to prevent double-billing.
        No charge if zero usage in the month (customer wasn't active).
        """
        metering = self._load_metering()
        now = datetime.now()

        if now.month == 1:
            prev_year, prev_month = now.year - 1, 12
        else:
            prev_year, prev_month = now.year, now.month - 1
        prev_key = f"{prev_year}-{prev_month:02d}"

        reconciled = metering.get('reconciled_months', [])
        if prev_key in reconciled:
            return None

        prev_start = datetime(prev_year, prev_month, 1)
        prev_end = now.replace(day=1, hour=0, minute=0, second=0, microsecond=0)

        records = metering.get('records', [])
        prev_hours = 0.0
        for r in records:
            try:
                ts = datetime.fromisoformat(r['timestamp'])
                if prev_start <= ts < prev_end:
                    prev_hours += r.get('gpu_hours', 0)
            except Exception:
                continue

        # Mark reconciled regardless of outcome
        metering.setdefault('reconciled_months', []).append(prev_key)

        if prev_hours < 0.01:
            self._save_metering(metering)
            return None

        shortfall = ENTERPRISE_PLUS_MONTHLY_FLOOR_GPU_HOURS - prev_hours
        if shortfall <= 0:
            self._save_metering(metering)
            return None

        result = self.report_gpu_hours(
            subscription_item_id, shortfall,
            gpu_type='monthly_minimum_topup',
            instance_id=f'minimum-{prev_key}',
        )
        self._save_metering(metering)

        cost = round(math.ceil(shortfall) * ENTERPRISE_PLUS_GPU_HOUR_RATE_CENTS / 100, 2)
        logger.info(f"Monthly minimum for {prev_key}: {prev_hours:.1f} used, "
                     f"{shortfall:.1f} top-up, ${cost:.2f}")
        return {
            'month': prev_key,
            'actual_gpu_hours': round(prev_hours, 2),
            'floor_gpu_hours': ENTERPRISE_PLUS_MONTHLY_FLOOR_GPU_HOURS,
            'shortfall_gpu_hours': round(shortfall, 2),
            'topup_cost_usd': cost,
            'stripe_result': result,
        }

    def get_current_period_usage(self) -> Dict[str, Any]:
        """Get GPU-hour usage for the current billing period."""
        metering = self._load_metering()
        records = metering.get('records', [])
        
        # Filter to current month
        now = datetime.now()
        month_start = now.replace(day=1, hour=0, minute=0, second=0, microsecond=0)
        
        current_records = [
            r for r in records 
            if datetime.fromisoformat(r['timestamp']) >= month_start
        ]
        
        total_hours = sum(r.get('gpu_hours', 0) for r in current_records)
        billed_hours = max(math.ceil(total_hours), 0)
        floor = ENTERPRISE_PLUS_MONTHLY_FLOOR_GPU_HOURS
        projected_billed = max(billed_hours, floor) if total_hours > 0.01 else 0
        total_cost = round(projected_billed * ENTERPRISE_PLUS_GPU_HOUR_RATE_CENTS / 100, 2)
        shortfall = max(floor - billed_hours, 0) if total_hours > 0.01 else 0
        
        return {
            'billing_period_start': month_start.isoformat(),
            'total_gpu_hours': round(total_hours, 2),
            'total_gpu_hours_billed': billed_hours,
            'monthly_minimum_gpu_hours': floor,
            'projected_billed_gpu_hours': projected_billed,
            'shortfall_gpu_hours': shortfall,
            'estimated_cost_usd': total_cost,
            'rate_per_gpu_hour': ENTERPRISE_PLUS_GPU_HOUR_RATE_CENTS / 100,
            'record_count': len(current_records),
            'min_gpus_per_instance': ENTERPRISE_PLUS_MIN_GPUS,
            'min_monthly_hours': ENTERPRISE_PLUS_MIN_MONTHLY_HOURS,
            'billing_formula': 'max(gpu_count, 32) × hours_used × $0.09, min 4096 GPU-hrs/mo ($368.64)',
        }

    # ── Local metering persistence ───────────────────────────────────

    def _load_metering(self) -> Dict[str, Any]:
        """Load local metering state."""
        if self._metering_file.exists():
            try:
                with open(self._metering_file, 'r') as f:
                    return json.load(f)
            except Exception:
                pass
        return {'records': []}

    def _save_metering(self, data: Dict[str, Any]):
        """Save local metering state."""
        self._metering_file.parent.mkdir(parents=True, exist_ok=True)
        with open(self._metering_file, 'w') as f:
            json.dump(data, f, indent=2)

    def _record_local_metering(self, gpu_hours: float, gpu_type: str, 
                                instance_id: str, reported: bool = True):
        """Record a metering event locally for audit trail."""
        metering = self._load_metering()
        metering.setdefault('records', []).append({
            'timestamp': datetime.now().isoformat(),
            'gpu_hours': round(gpu_hours, 4),
            'gpu_type': gpu_type,
            'instance_id': instance_id,
            'reported_to_stripe': reported,
            'cost_usd': round(math.ceil(gpu_hours) * ENTERPRISE_PLUS_GPU_HOUR_RATE_CENTS / 100, 2),
        })
        self._save_metering(metering)
    
    # ── Shared helpers ────────────────────────────────────────────────

    def _get_or_create_product(self, tier: str, config: Dict[str, Any]) -> stripe.Product:
        """Get existing product or create new one"""
        
        try:
            products = stripe.Product.list(limit=100, active=True)
            for product in products.data:
                if product.metadata.get('tier') == tier and product.metadata.get('product') == 'terradev_cli':
                    return product
            
            return stripe.Product.create(
                name=config['name'],
                description=config['description'],
                metadata={
                    'tier': tier,
                    'product': 'terradev_cli',
                    'version': '3.1.8'
                }
            )
            
        except Exception as e:
            logging.error(f"Failed to get/create product: {e}")
            raise
    
    def _get_or_create_price(self, product_id: str, config: Dict[str, Any]) -> stripe.Price:
        """Get existing price or create new one"""
        
        try:
            # Search for existing price
            prices = stripe.Price.list(product=product_id, limit=100, active=True)
            for price in prices.data:
                if price.unit_amount == config['price'] and price.currency == config['currency']:
                    return price
            
            # Create new price
            return stripe.Price.create(
                product=product_id,
                unit_amount=config['price'],
                currency=config['currency'],
                recurring={'interval': 'month'},
                metadata={
                    'product': 'terradev_cli'
                }
            )
            
        except Exception as e:
            logging.error(f"Failed to get/create price: {e}")
            raise
    
    def construct_webhook_event(self, payload: str, sig_header: str, webhook_secret: str) -> stripe.Event:
        """Construct webhook event for verification"""
        
        if self.demo_mode:
            # Demo mode - return mock event
            return {
                'type': 'checkout.session.completed',
                'data': {
                    'object': {
                        'id': f'cs_demo_{datetime.now().strftime("%Y%m%d_%H%M%S")}',
                        'customer': 'cus_demo_123',
                        'metadata': {'tier': 'research_plus'},
                        'subscription': 'sub_demo_123'
                    }
                }
            }
        
        try:
            return stripe.Webhook.construct_event(payload, sig_header, webhook_secret)
        except Exception as e:
            logging.error(f"Webhook signature verification failed: {e}")
            raise
    
    def get_customer_info(self, customer_id: str) -> Dict[str, Any]:
        """Get customer information from Stripe"""
        
        if self.demo_mode:
            return {
                'id': customer_id,
                'email': 'demo@example.com',
                'metadata': {'tier': 'research_plus'}
            }
        
        try:
            customer = stripe.Customer.retrieve(customer_id)
            return {
                'id': customer.id,
                'email': customer.email,
                'metadata': customer.metadata
            }
        except Exception as e:
            logging.error(f"Failed to get customer info: {e}")
            raise
    
    def cancel_subscription(self, subscription_id: str) -> bool:
        """Cancel a subscription"""
        
        if self.demo_mode:
            return True
        
        try:
            stripe.Subscription.delete(subscription_id)
            return True
        except Exception as e:
            logging.error(f"Failed to cancel subscription: {e}")
            return False

# Global instance
stripe_manager = StripeManager()
