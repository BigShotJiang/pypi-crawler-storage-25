"""Structured agent output — VCS-agnostic JSON that the SaaS platform translates to VCS API calls."""

from __future__ import annotations

import json
import sys
import uuid
from dataclasses import asdict, dataclass, field
from pathlib import Path
from typing import Any


@dataclass
class AgentOutput:
    """Standard output contract for all agents."""

    agent: str
    status: str       # completed, failed, no_change
    output_type: str  # file_commit, review, pull_request, report, …
    error_code: str = ""   # empty string = no error; see core/errors.py for codes
    metadata: dict[str, Any] = field(default_factory=dict)
    result: dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)

    def to_json(self, indent: int = 2) -> str:
        return json.dumps(self.to_dict(), indent=indent, default=str)


def create_output(
    agent: str,
    status: str,
    output_type: str,
    result: dict[str, Any],
    *,
    error_code: str = "",
    branch: str = "",
    base_branch: str = "",
    tokens_used: dict[str, int] | None = None,
    duration_ms: int = 0,
    ci_context: dict[str, Any] | None = None,
    commit_hash: str = "",       # ← add
    author: str = "",            # ← add
    commit_message: str = "",    # ← add
) -> AgentOutput:
    """Create an AgentOutput with populated metadata."""
    import os
    metadata: dict[str, Any] = {
        "run_id": os.environ.get("VIDURA_RUN_ID") or str(uuid.uuid4()),
        "branch": branch,
        "base_branch": base_branch,
        "commit_hash": commit_hash,        # ← add
        "current_commit": commit_hash,     # ← add (callback.py checks both)
        "author": author,                  # ← add
        "commit_message": commit_message,  # ← add
        "tokens_used": tokens_used or {"input": 0, "output": 0},
        "duration_ms": duration_ms,
    }

    if ci_context:
        metadata.update(ci_context)

    return AgentOutput(
        agent=agent,
        status=status,
        output_type=output_type,
        error_code=error_code,
        metadata=metadata,
        result=result,
    )


def write_output(output: AgentOutput, output_file: str | None = None) -> None:
    """Write AgentOutput as JSON to a file or stdout."""
    json_str = output.to_json()

    if output_file:
        Path(output_file).parent.mkdir(parents=True, exist_ok=True)
        Path(output_file).write_text(json_str, encoding="utf-8")
    else:
        sys.stdout.write(json_str + "\n")


async def post_callback(output: AgentOutput, callback_url: str, token: str) -> None:
    """POST the AgentOutput JSON to the SaaS callback URL."""
    import urllib.request

    data = output.to_json().encode("utf-8")
    req = urllib.request.Request(
        callback_url,
        data=data,
        headers={
            "Authorization": f"Bearer {token}",
            "Content-Type": "application/json",
        },
        method="POST",
    )

    try:
        with urllib.request.urlopen(req, timeout=30) as resp:
            return json.loads(resp.read())
    except Exception as err:
        from core.logger import logger
        logger.warn(f"Callback POST failed: {err}")
        return None
