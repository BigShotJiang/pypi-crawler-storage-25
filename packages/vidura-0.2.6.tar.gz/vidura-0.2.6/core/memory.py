"""Skill memory manager (L3). Two-tier memory: local (per-project) + optional global (Git repo).

All file maps, initial content, and category routing are now driven by the agent manifest.
"""

from __future__ import annotations

import re
from dataclasses import dataclass
from pathlib import Path
from typing import Any

from core.extractor.types import ExtractedApiDelta
from core.logger import logger
from core.storage.local_store import LocalMemoryStore
from core.storage.memory_store import MemoryStore

MAX_SKILL_CHARS = 8_000


@dataclass
class MemorySearchResult:
    """A ranked section from a skill memory file."""

    source: str  # e.g. "project:api-patterns.md" or "global:style-guide.md"
    section: str
    score: float


class MemoryManager:
    """Manages two tiers of memory:

    * **local** (per-project) — stored on the filesystem inside the repo.
    * **global** (shared)     — stored in a Git repo (optional, admin-managed).

    All file maps and initial content come from the agent manifest.
    """

    def __init__(
        self,
        repo_path: str,
        memory_dir: str = ".agent/skills",
        global_store: MemoryStore | None = None,
        local_store: MemoryStore | None = None,
        *,
        local_files: dict[str, str] | None = None,
        local_initial_content: dict[str, str] | None = None,
        global_files: dict[str, str] | None = None,
        global_initial_content: dict[str, str] | None = None,
        categories: dict[str, str] | None = None,
    ) -> None:
        self._local = local_store or LocalMemoryStore(Path(repo_path) / memory_dir)
        self._global = global_store
        self.skills_dir = Path(repo_path) / memory_dir

        # Manifest-driven file maps (logical_name -> filename)
        self._local_files = local_files or {}
        self._local_initial_content = local_initial_content or {}
        self._global_files = global_files or {}
        self._global_initial_content = global_initial_content or {}
        self._categories = categories or {}

    # ── Lifecycle ─────────────────────────────────────────────────────────────

    def initialize(self) -> None:
        """Create skill files that don't yet exist. Safe to call repeatedly."""
        if self._local_initial_content:
            self._local.initialize(self._local_initial_content)
        if self._global and self._global_initial_content:
            self._global.initialize(self._global_initial_content)

    # ── Read ──────────────────────────────────────────────────────────────────

    def read_all(self) -> dict[str, str]:
        """Read all local skill files. Returns {logical_name: content}."""
        result: dict[str, str] = {}
        for key, filename in self._local_files.items():
            result[key] = self._local.read(filename)
        return result
    
    # def read_skill(self, filename: str, scope: str = "project") -> str:
    #     if scope == "global" and self._global:
    #         return self._global.read(filename)
    #     return self._local.read(filename)

    def read_skill(self, filename: str, scope: str = "project") -> str:
        if scope == "global" and self._global:
            content = self._global.read(filename)
            logger.info(f"[memory:read] scope=global file={filename} chars={len(content)}")
            return content
        content = self._local.read(filename)
        logger.info(f"[memory:read] scope=project file={filename} chars={len(content)}")
        return content

    # ── Update from delta (doc-gen compatible) ────────────────────────────────

    def update_from_delta(self, delta: ExtractedApiDelta) -> None:
        import re as _re

        date = delta.timestamp[:10]

        api_file = self._categories.get("api") or self._local_files.get("api")
        auth_file = self._categories.get("auth") or self._local_files.get("auth")
        versioning_file = self._categories.get("versioning") or self._local_files.get("versioning")
        general_file = self._categories.get("general") or self._local_files.get("master")

        def _fmt_auth(ep) -> str:
            if not ep or not ep.auth:
                return "none"
            auth_str = ep.auth.type
            if ep.auth.scopes:
                auth_str += f" [{', '.join(ep.auth.scopes)}]"
            return auth_str

        def _fmt_fields(fields) -> str:
            if not fields:
                return "none"
            return ", ".join(
                f"{f.name}({'*' if bool(f.required) else '?'}): {f.type}"
                for f in fields
            )

        def _fmt_query(params) -> str:
            if not params:
                return "none"
            return ", ".join(
                f"{p.name}({'*' if bool(p.required) else '?'}): {p.type}"
                for p in params
            )

        def _fmt_path(params) -> str:
            if not params:
                return "none"
            return ", ".join(f"{p.name}: {p.type}" for p in params)

        def _version_label(path: str) -> str:
            m = _re.search(r"/v(\d+)(?:/|$)", path)
            return f"v{m.group(1)}" if m else "unversioned"

        # ── api-patterns.md / common-patterns ────────────────────────────────────
        if api_file and (delta.new or delta.modified or delta.removed):
            lines_parts = [f"\n## {delta.feature} ({date})\n"]

            if delta.new:
                lines_parts.append("### Added\n")
                for e in delta.new:
                    lines_parts.append(f"- `{e.method} {e.path}`")
                    if e.handler:
                        lines_parts.append(f"  - handler: {e.handler}")
                    lines_parts.append(f"  - versioning: {_version_label(e.path)}")
                    lines_parts.append(f"  - auth: {_fmt_auth(e)}")
                    lines_parts.append(f"  - path params: {_fmt_path(e.params)}")
                    lines_parts.append(f"  - query params: {_fmt_query(e.query)}")
                    lines_parts.append(f"  - request: {_fmt_fields(e.request_schema)}")
                    lines_parts.append(f"  - response: {_fmt_fields(e.response_schema)}")

            if delta.modified:
                lines_parts.append("\n### Modified\n")
                for m in delta.modified:
                    before = m.before
                    after = m.after

                    before_auth = _fmt_auth(before)
                    after_auth = _fmt_auth(after)

                    before_req_names = {f.name for f in (before.request_schema or [])}
                    after_req_names = {f.name for f in (after.request_schema or [])}

                    before_res_names = {f.name for f in (before.response_schema or [])}
                    after_res_names = {f.name for f in (after.response_schema or [])}

                    before_query_names = {q.name for q in (before.query or [])}
                    after_query_names = {q.name for q in (after.query or [])}

                    before_path_names = {p.name for p in (before.params or [])}
                    after_path_names = {p.name for p in (after.params or [])}

                    req_added = sorted(after_req_names - before_req_names)
                    req_removed = sorted(before_req_names - after_req_names)

                    res_added = sorted(after_res_names - before_res_names)
                    res_removed = sorted(before_res_names - after_res_names)

                    query_added = sorted(after_query_names - before_query_names)
                    query_removed = sorted(before_query_names - after_query_names)

                    path_added = sorted(after_path_names - before_path_names)
                    path_removed = sorted(before_path_names - after_path_names)

                    breaking = bool(
                        req_removed
                        or res_removed
                        or path_removed
                        or before_auth != after_auth
                    )

                    tag = " ⚠️ BREAKING" if breaking else ""
                    lines_parts.append(f"- `{after.method} {after.path}`{tag} — {m.change_type}")
                    if after.handler:
                        lines_parts.append(f"  - handler: {after.handler}")
                    lines_parts.append(f"  - versioning: {_version_label(after.path)}")

                    if before_auth != after_auth:
                        lines_parts.append(f"  - auth: {before_auth} → {after_auth}")

                    if req_added:
                        lines_parts.append(f"  - request fields added: {', '.join(req_added)}")
                    if req_removed:
                        lines_parts.append(f"  - request fields removed: {', '.join(req_removed)} ⚠️ BREAKING")

                    if res_added:
                        lines_parts.append(f"  - response fields added: {', '.join(res_added)}")
                    if res_removed:
                        lines_parts.append(f"  - response fields removed: {', '.join(res_removed)} ⚠️ BREAKING")

                    if query_added:
                        lines_parts.append(f"  - query params added: {', '.join(query_added)}")
                    if query_removed:
                        lines_parts.append(f"  - query params removed: {', '.join(query_removed)}")

                    if path_added:
                        lines_parts.append(f"  - path params added: {', '.join(path_added)}")
                    if path_removed:
                        lines_parts.append(f"  - path params removed: {', '.join(path_removed)} ⚠️ BREAKING")

                    lines_parts.append(f"  - before request: {_fmt_fields(before.request_schema)}")
                    lines_parts.append(f"  - after request: {_fmt_fields(after.request_schema)}")
                    lines_parts.append(f"  - before response: {_fmt_fields(before.response_schema)}")
                    lines_parts.append(f"  - after response: {_fmt_fields(after.response_schema)}")
                    lines_parts.append(f"  - before query: {_fmt_query(before.query)}")
                    lines_parts.append(f"  - after query: {_fmt_query(after.query)}")
                    lines_parts.append(f"  - before path params: {_fmt_path(before.params)}")
                    lines_parts.append(f"  - after path params: {_fmt_path(after.params)}")

            if delta.removed:
                lines_parts.append("\n### Removed\n")
                for e in delta.removed:
                    lines_parts.append(f"- `{e.method} {e.path}` ⚠️ BREAKING")
                    if e.handler:
                        lines_parts.append(f"  - handler: {e.handler}")
                    lines_parts.append(f"  - versioning: {_version_label(e.path)}")
                    lines_parts.append(f"  - old auth: {_fmt_auth(e)}")
                    lines_parts.append(f"  - old path params: {_fmt_path(e.params)}")
                    lines_parts.append(f"  - old query params: {_fmt_query(e.query)}")
                    lines_parts.append(f"  - old request: {_fmt_fields(e.request_schema)}")
                    lines_parts.append(f"  - old response: {_fmt_fields(e.response_schema)}")
                    lines_parts.append("  - impact: endpoint removed; add migration/replacement note in docs if applicable")

            if delta.contract_changes:
                lines_parts.append("\n### Contract Changes\n")
                for c in delta.contract_changes:
                    lines_parts.append(f"- `{c.endpoint}` — {c.change_type}: {c.description}")

            entry = "\n".join(lines_parts)
            self._local.append(api_file, entry)

            global_api_file = self._global_files.get("common-patterns")
            if self._global and global_api_file:
                self._global.append(global_api_file, entry)

        # ── auth-strategies.md ────────────────────────────────────────────────────
        if auth_file:
            auth_lines = []

            if delta.auth_changes:
                auth_lines.append(f"\n## Auth changes — {delta.feature} ({date})\n")
                for a in delta.auth_changes:
                    auth_lines.append(f"- **{a.type}**: {a.description}")

            auth_seen: dict[str, list[str]] = {}
            for e in delta.new:
                auth_seen.setdefault(_fmt_auth(e), []).append(e.path)

            if auth_seen:
                if not auth_lines:
                    auth_lines.append(f"\n## Auth patterns — {delta.feature} ({date})\n")
                for auth_type, paths in auth_seen.items():
                    auth_lines.append(f"- **{auth_type}**")
                    auth_lines.append(f"  - endpoints: {', '.join(f'`{p}`' for p in paths[:5])}")
                    if len(paths) > 5:
                        auth_lines.append(f"  - ...and {len(paths) - 5} more")

            if auth_lines:
                entry = "\n".join(auth_lines)
                self._local.append(auth_file, entry)

                global_auth_file = self._global_files.get("auth-strategies")
                if self._global and global_auth_file:
                    self._global.append(global_auth_file, entry)

        # ── versioning.md ─────────────────────────────────────────────────────────
        if versioning_file:
            ver_lines = []

            if delta.versioning_changes:
                ver_lines.append(f"\n## Version changes — {delta.feature} ({date})\n")
                for v in delta.versioning_changes:
                    ver_lines.append(f"- **{v.type}**: {v.description}")

            all_eps = list(delta.new) + [m.after for m in delta.modified] + list(delta.removed)
            version_counts: dict[str, int] = {}

            for e in all_eps:
                label = _version_label(e.path)
                version_counts[label] = version_counts.get(label, 0) + 1

            if version_counts:
                if not ver_lines:
                    ver_lines.append(f"\n## Versioning — {delta.feature} ({date})\n")
                for v, count in sorted(version_counts.items()):
                    ver_lines.append(f"- `{v}` — {count} endpoint(s) on this branch")

            if ver_lines:
                entry = "\n".join(ver_lines)
                self._local.append(versioning_file, entry)

                global_versioning_file = self._global_files.get("versioning")
                if self._global and global_versioning_file:
                    self._global.append(global_versioning_file, entry)

        # ── master/general ────────────────────────────────────────────────────────
        if general_file:
            summary = (
                f"\n## {delta.feature} ({date})\n"
                f"- new: {len(delta.new)}, modified: {len(delta.modified)}, removed: {len(delta.removed)}\n"
            )
            self._local.append(general_file, summary)

        self._prune_store(self._local, list(self._local_files.values()))
        if self._global and self._global_files:
            self._prune_store(self._global, list(self._global_files.values()))
    # ── Token-budgeted context ────────────────────────────────────────────────

    def get_token_budgeted_context(self, max_tokens: int) -> str:
        """Return all local memory as a single string, capped by token budget."""
        all_memory = self.read_all()
        parts = [f"## {key}\n{content}" for key, content in all_memory.items() if content.strip()]
        combined = "\n\n".join(parts)

        char_budget = max_tokens * 4
        if len(combined) <= char_budget:
            return combined
        return combined[:char_budget] + "\n...[truncated for token budget]"

    # ── Search ────────────────────────────────────────────────────────────────

    def search_memory(
        self, query: str, max_results: int = 5, scope: str = "all"
    ) -> list[MemorySearchResult]:
        """Keyword search across skill files.

        scope: "project" | "global" | "all"
        """
        terms = [t.lower() for t in re.split(r"\W+", query) if len(t) >= 2]
        if not terms:
            return []
        # logger.info(f"[memory:search] query='{query}' scope={scope}")

        results: list[MemorySearchResult] = []

        if scope in ("project", "all"):
            local_filenames = list(self._local_files.values())
            results.extend(self._search_store(self._local, terms, "project", local_filenames))

        if scope in ("global", "all") and self._global:
            global_filenames = self._global.list_files() or list(self._global_files.values())
            results.extend(self._search_store(self._global, terms, "global", global_filenames))

        results.sort(key=lambda r: r.score, reverse=True)
        return results[:max_results]
        if top:
            for r in top:
                logger.info(f"  └─ found: {r.source} score={r.score:.0f} | {r.section[:60].strip()}...")
        else:
            logger.info(f"  └─ no results found")
        return top

    # ── Feedback ──────────────────────────────────────────────────────────────

    def record_feedback(
        self,
        feature: str,
        rating: str,
        note: str = "",
        scope: str = "project",
    ) -> None:
        """Record human or automated feedback on an agent run.

        rating: "good" | "bad" | "improved"
        Appends a structured entry to the ``feedback`` category file so future
        runs can learn from past successes and failures.
        """
        from datetime import datetime, timezone

        date = datetime.now(timezone.utc).strftime("%Y-%m-%d")
        symbol = {"good": "+", "bad": "-", "improved": "^"}.get(rating, "·")
        lines = [f"\n## [{symbol}] {feature} ({date}) — {rating.upper()}"]
        if note:
            lines.append(note)
        entry = "\n".join(lines) + "\n"

        feedback_file = self._categories.get("feedback") or self._local_files.get("feedback")

        if not feedback_file:
            logger.warn("No feedback memory file configured for this agent — skipping.")
            return

        if scope == "global" and self._global:
            self._global.append(feedback_file, entry)
            self._prune_store(self._global, list(self._global_files.values()))
        else:
            self._local.append(feedback_file, entry)
            self._prune_store(self._local, list(self._local_files.values()))

        logger.debug(f"Feedback recorded: [{rating}] {feature}")

    # ── Store ─────────────────────────────────────────────────────────────────

    def store_memory(
        self,
        category: str,
        title: str,
        content: str,
        scope: str = "project",
    ) -> None:
        # Never store endpoint inventory in searchable memory files —
        # it causes hallucination when injected as context in future runs.
        # Endpoint data lives only in api-inventory.json (non-searchable).
        BLOCKED_CATEGORIES = {"api", "auth", "versioning"}
        if category in BLOCKED_CATEGORIES:
            logger.debug(f"[memory:store] blocked category '{category}' — endpoint data not stored in searchable memory")
            return
        
        entry = f"\n## {title}\n{content}\n"

        if scope == "global" and self._global:
            # Use category mapping, fallback to first global file
            filename = self._categories.get(category)
            if not filename or filename not in self._global_files.values():
                # Try to find a reasonable global file
                filename = next(iter(self._global_files.values()), None)
            if filename:
                self._global.append(filename, entry)
                self._prune_store(self._global, list(self._global_files.values()))
                logger.debug(f"Stored global memory: [{category}] {title}")
        else:
            # Use category mapping, fallback to first local file
            filename = self._categories.get(category)
            if not filename or filename not in self._local_files.values():
                filename = next(iter(self._local_files.values()), None)
            if filename:
                self._local.append(filename, entry)
                self._prune_store(self._local, list(self._local_files.values()))
                logger.debug(f"Stored memory: [{category}] {title}")

    # ── Auto-context ──────────────────────────────────────────────────────────

    def get_auto_context(
        self, branch: str, changed_files: list[str], max_chars: int = 2000
    ) -> str:
        """Inject only style/convention hints — never endpoint data or feedback."""

        # These files contain endpoint paths, auth data, or run feedback.
        # Injecting them causes the LLM to hallucinate endpoints from past runs.
        BLOCKED_FILES = {
            "feedback.md", "api-patterns.md", "common-patterns.md",
            "auth-patterns.md", "auth-strategies.md", "versioning.md",
            "agentic-system-master.md",
        }

        branch_parts = re.split(r"[/_\-]", branch)
        file_parts: list[str] = []
        for fp in changed_files:
            file_parts.extend(re.split(r"[/_\-.\\\\/]", fp))

        all_keywords = set(
            w.lower()
            for w in branch_parts + file_parts
            if len(w) >= 3
            and w.lower() not in {"the", "and", "for", "src", "lib", "api", "main", "feature"}
        )

        if not all_keywords:
            return ""

        query = " ".join(list(all_keywords)[:10])
        results = self.search_memory(query, max_results=5, scope="all")

        if not results:
            return ""

        context_parts = ["## Relevant Memory Context"]
        total = len(context_parts[0])

        for r in results:
            filename = r.source.split(":")[-1]
            if filename in BLOCKED_FILES:
                logger.debug(f"[memory:auto_context] blocked {r.source} — contains endpoint/feedback data")
                continue

            # Strip any endpoint lines that slipped through other files
            clean_section = re.sub(
                r"^\s*[-•`]*\s*(GET|POST|PUT|DELETE|PATCH)\s+/[^\n]*$",
                "",
                r.section,
                flags=re.MULTILINE,
            )
            clean_section = re.sub(r"\n{3,}", "\n\n", clean_section).strip()

            if not clean_section or len(clean_section) < 50:
                continue

            header = f"\n### From {r.source} (relevance: {r.score:.0f})"
            entry = header + "\n" + clean_section
            if total + len(entry) > max_chars:
                remaining = max_chars - total - 30
                if remaining > 100:
                    context_parts.append(entry[:remaining] + "\n...[capped]")
                break
            context_parts.append(entry)
            total += len(entry)

        if len(context_parts) == 1:
            logger.info("[memory:auto_context] nothing injected — all results blocked")
            return ""

        result = "\n".join(context_parts)
        logger.info(f"[memory:auto_context] injected {len(result)} chars into turn 1")
        for part in context_parts[1:]:
            first_line = part.strip().split("\n")[0]
            logger.info(f"  └─ {first_line[:80]}")
        return result

    @property
    def has_global(self) -> bool:
        return self._global is not None

    # ─── Private helpers ──────────────────────────────────────────────────────

    def _search_store(
        self,
        store: MemoryStore,
        terms: list[str],
        scope_label: str,
        filenames: list[str],
    ) -> list[MemorySearchResult]:
        results: list[MemorySearchResult] = []
        for filename in filenames:
            content = store.read(filename)
            if not content:
                continue

            sections = re.split(r"(?=^## )", content, flags=re.MULTILINE)
            for section in sections:
                section = section.strip()
                if not section:
                    continue

                lower_section = section.lower()
                score = sum(lower_section.count(term) for term in terms)
                if score > 0:
                    results.append(
                        MemorySearchResult(
                            source=f"{scope_label}:{filename}",
                            section=section[:1000],
                            score=score,
                        )
                    )
        return results

    def _prune_store(self, store: MemoryStore, filenames: list[str]) -> None:
        for filename in filenames:
            content = store.read(filename)
            if len(content) <= MAX_SKILL_CHARS:
                continue

            lines = content.split("\n")
            header = "\n".join(lines[:8])
            keep_from = int(len(lines) * 0.4)
            pruned = f"{header}\n\n...(older entries pruned)...\n\n" + "\n".join(lines[keep_from:])
            store.write(filename, pruned)
            logger.debug(f"Pruned skill: {filename}")
