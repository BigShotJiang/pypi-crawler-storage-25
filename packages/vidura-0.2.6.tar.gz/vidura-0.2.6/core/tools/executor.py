"""Generic stateful tool dispatcher — manifest-driven.

Handles core tools (file, search, plan, memory) directly.
Delegates agent-specific tools to dynamically-loaded handler from manifest.
"""

from __future__ import annotations

import fnmatch
import json
import re
from dataclasses import dataclass
from pathlib import Path
from typing import Any

from core.agent_manifest import AgentManifest, load_agent_tool_handler
from core.config import AgentConfig
from core.git import GitAnalyzer
from core.llm.base import LLMProvider
from core.logger import logger
from core.memory import MemoryManager
from core.tools.core_tools import build_tool_set, get_core_tools_by_names

TerminalStatus = str  # "GENERATED", "NO_API_CHANGE", etc.

SEARCH_SKIP_DIRS = {".git", "node_modules", "__pycache__", "venv", ".venv", ".tox", "dist", "build"}
MAX_PLAN_REVISIONS = 3


@dataclass
class ToolResult:
    """Result of a tool execution."""

    content: str
    is_terminal: bool
    terminal_status: TerminalStatus | None = None
    output_path: str | None = None
    feature_name: str | None = None


@dataclass
class AgentPlan:
    """Agent's self-created plan."""

    goal: str
    steps: list[str]
    revision_count: int = 0


class ToolExecutor:
    """Manifest-driven tool dispatcher. Core tools are built-in;
    agent-specific tools are loaded from the manifest's tool modules."""

    def __init__(
        self,
        repo_path: str,
        config: AgentConfig,
        branch: str,
        memory: MemoryManager,
        manifest: AgentManifest,
        secondary_providers: dict[str, LLMProvider] | None = None,
        skills_dir: Path | None = None,
    ) -> None:
        self.repo_path = repo_path
        self.config = config
        self.branch = branch
        self._memory = memory
        self._manifest = manifest
        self._secondary_providers = secondary_providers or {}
        self._skills_dir = skills_dir or Path(repo_path) / "skills"

        self._git = GitAnalyzer(repo_path)
        self._plan: AgentPlan | None = None
        self._current_draft: str = ""
        self.token_budget_pct: float = 0.0  # updated each turn by workflow; tools use this to tighten responses

        # Terminal tools from manifest
        self._terminal_tools: set[str] = set(manifest.workflow.terminal_tools)

        # Load agent-specific tool handlers
        self._agent_handlers: list[Any] = []
        self._agent_tool_defs: list[dict] = []
        self._agent_tool_names: set[str] = set()

        # Hard execution guards
        self._read_file_calls = 0
        self._search_codebase_calls = 0 
        self._store_draft_calls = 0
        self._get_changed_files_calls = 0 
        self._exploration_locked = False
        self._changed_files = None

        for module_path in manifest.tools.agent_specific:
            try:
                module = load_agent_tool_handler(module_path)
                handler_cls = getattr(module, "ToolHandler", None)
                if handler_cls:
                    handler = handler_cls(
                        repo_path=repo_path,
                        config=config,
                        branch=branch,
                        memory=memory,
                        secondary_providers=secondary_providers or {},
                        skills_dir=self._skills_dir,
                        executor=self,
                    )
                    self._agent_handlers.append(handler)
                tool_defs = getattr(module, "TOOL_DEFINITIONS", [])
                self._agent_tool_defs.extend(tool_defs)
                for td in tool_defs:
                    self._agent_tool_names.add(td["name"])
            except (ImportError, AttributeError) as err:
                logger.warn(f"Failed to load agent tools from {module_path}: {err}")

        # Build core tool definitions from manifest's core tool list
        self._core_tool_defs = get_core_tools_by_names(manifest.tools.core)
        self._core_tool_names = {t["name"] for t in self._core_tool_defs}

        # Exploration-only tools (gated behind progressive state)
        self._exploration_only = set(manifest.tools.exploration_only)

    

    def is_terminal(self, tool_name: str) -> bool:
        return tool_name in self._terminal_tools

    def get_tool_definitions(self) -> list[dict]:
        """Return the current tool set based on progressive gating."""
        gate_field = self._manifest.workflow.progressive_gate_field
        gate_active = False
        if gate_field:
            gate_active = bool(getattr(self, gate_field, ""))

        if gate_active:
            # All tools available
            return build_tool_set(self._core_tool_defs, self._agent_tool_defs)
        else:
            # Exclude exploration-only tools
            return build_tool_set(
                self._core_tool_defs,
                self._agent_tool_defs,
                exclude=self._exploration_only,
            )

    async def execute(self, tool_name: str, tool_input: dict) -> ToolResult:
        logger.info(f"Tool call: {tool_name}")

        if self._exploration_locked and tool_name in {
            "get_changed_files",
            "read_file",
            "search_codebase",
            "create_plan",
            "revise_plan",
        }:
            return ToolResult(
                content=json.dumps({
                    "error": f"{tool_name} is blocked after store_draft. Exploration is complete. Proceed with critique, evaluation, validation, and writing.",
                }),
                is_terminal=False,
            )

        # Core tool handlers
        core_handlers = {
            "get_changed_files": lambda: self._get_changed_files(),
            "read_file": lambda: self._read_file(
                tool_input.get("path", ""),
                tool_input.get("offset", 0),
                tool_input.get("limit", 100),
            ),
            "search_codebase": lambda: self._search_codebase(
                tool_input.get("pattern", ""),
                tool_input.get("glob"),
                tool_input.get("maxResults", 20),
            ),
            "create_plan": lambda: self._create_plan(
                tool_input.get("goal", ""),
                tool_input.get("steps", []),
            ),
            "revise_plan": lambda: self._revise_plan(
                tool_input.get("reason", ""),
                tool_input.get("updatedSteps", []),
            ),
            "read_memory": lambda: self._read_memory(
                tool_input.get("skill", ""),
                tool_input.get("scope", "project"),
            ),
            "search_memory": lambda: self._search_memory(
                tool_input.get("query", ""),
                tool_input.get("maxResults", 5),
                tool_input.get("scope", "all"),
            ),
            "store_memory": lambda: self._store_memory(
                tool_input.get("category", "general"),
                tool_input.get("title", ""),
                tool_input.get("content", ""),
                tool_input.get("scope", "project"),
            ),
            "store_draft": lambda: self._store_draft(tool_input.get("documentation", "")),
            "signal_no_change": lambda: self._signal_no_change(tool_input.get("reason", "")),
        }

        handler = core_handlers.get(tool_name)
        if handler:
            return handler()

        # Delegate to agent-specific handlers
        for agent_handler in self._agent_handlers:
            if hasattr(agent_handler, "can_handle") and agent_handler.can_handle(tool_name):
                return await agent_handler.handle(tool_name, tool_input)

        return ToolResult(
            content=json.dumps({"error": f"Unknown tool: {tool_name}"}),
            is_terminal=False,
        )

    # ─── Core tool implementations ───────────────────────────────────────────

    def _get_changed_files(self) -> ToolResult:
        # ── Cap repeated calls — prevents infinite retry loop ─────────────────
        if self._get_changed_files_calls >= 2:
            self._changed_files = []
            return ToolResult(
                content=json.dumps({
                    "total": 0,
                    "files": [],
                    "noChanges": True,
                    "message": (
                        "No API-relevant files changed in this commit. "
                        "Call extract_api_changes now — it will scan the full "
                        "repository automatically if no inventory exists yet."
                    ),
                }),
                is_terminal=False,
            )
        self._get_changed_files_calls += 1
        # ────────────────────────────────────────
        all_changed = self._git.get_changed_files(self.config.base_branch)

        logger.info(f"Changed files: {len(all_changed)} total")

        preview = [
            {
                "path": f.path,
                "status": f.status,
                "diffPreview": "\n".join(f.diff.split("\n")[:10]),
            }
            for f in all_changed
        ]

        # Store for agent handlers to use
        self._changed_files = all_changed

        return ToolResult(
            content=json.dumps({"total": len(all_changed), "files": preview}),
            is_terminal=False,
        )

    def _read_file(self, path: str, offset: int = 0, limit: int = 100) -> ToolResult:
        # Block exploration after drafting starts
        if self._exploration_locked:
            return ToolResult(
                content=json.dumps({
                    "error": "read_file is blocked after store_draft. Exploration is complete. Proceed to validation and writing.",
                    "readsUsed": self._read_file_calls,
                    "readsRemaining": max(0, 8 - self._read_file_calls),
                }),
                is_terminal=False,
            )

        # Hard cap: max 4 total read_file calls per run
        if self._read_file_calls >= 8:
            return ToolResult(
                content=json.dumps({
                    "error": "read_file hard cap exceeded (max 8 total calls). Use the information you already have and draft now.",
                    "readsUsed": self._read_file_calls,
                    "readsRemaining": 0,
                }),
                is_terminal=False,
            )

        self._read_file_calls += 1
        logger.info(f"[read_file] #{self._read_file_calls} path={path} offset={offset} limit={limit}")  # ← ADD THIS


        # Tighten the hard cap when budget is running low to avoid burning tokens on large file reads
        hard_cap = 300 if self.token_budget_pct < 0.70 else (150 if self.token_budget_pct < 0.85 else 60)
        limit = min(max(limit, 1), hard_cap)
        offset = max(offset, 0)

        repo_root = Path(self.repo_path).resolve()
        target = (repo_root / path).resolve()

        if not str(target).startswith(str(repo_root)):
            return ToolResult(
                content=json.dumps({"error": "Path traversal not allowed."}),
                is_terminal=False,
            )

        if not target.exists():
            return ToolResult(
                content=json.dumps({"error": f"File not found: {path}"}),
                is_terminal=False,
            )

        if not target.is_file():
            return ToolResult(
                content=json.dumps({"error": f"Not a file: {path}"}),
                is_terminal=False,
            )

        try:
            lines = target.read_text(encoding="utf-8", errors="replace").split("\n")
            total_lines = len(lines)
            selected = lines[offset : offset + limit]

            numbered = [f"{offset + i + 1}: {line}" for i, line in enumerate(selected)]

            return ToolResult(
                content=json.dumps({
                    "path": path,
                    "totalLines": total_lines,
                    "offset": offset,
                    "linesReturned": len(selected),
                    "readsUsed": self._read_file_calls,
                    "readsRemaining": max(0, 8 - self._read_file_calls),
                    "content": "\n".join(numbered),
                }),
                is_terminal=False,
            )
        except Exception as err:
            return ToolResult(
                content=json.dumps({"error": f"Failed to read file: {err}"}),
                is_terminal=False,
            )

    def _search_codebase(self, pattern: str, glob_filter: str | None = None, max_results: int = 20) -> ToolResult:
        # Hard cap: max 6 total search_codebase calls per run
        if self._search_codebase_calls >= 6:
            return ToolResult(
                content=json.dumps({
                    "error": "search_codebase hard cap exceeded (max 6 calls). Use read_file for remaining lookups.",
                    "searchesUsed": self._search_codebase_calls,
                }),
                is_terminal=False,
            )
        self._search_codebase_calls += 1

        # Reduce result cap as budget tightens — each match line costs input tokens on the next turn
        result_cap = 50 if self.token_budget_pct < 0.70 else (20 if self.token_budget_pct < 0.85 else 10)
        max_results = min(max(max_results, 1), result_cap)

        try:
            compiled = re.compile(pattern, re.IGNORECASE)
        except re.error as err:
            return ToolResult(
                content=json.dumps({"error": f"Invalid regex: {err}"}),
                is_terminal=False,
            )

        repo_root = Path(self.repo_path)
        matches: list[dict] = []

        for file_path in repo_root.rglob("*"):
            if len(matches) >= max_results:
                break

            parts = file_path.relative_to(repo_root).parts
            if any(part in SEARCH_SKIP_DIRS for part in parts):
                continue

            if not file_path.is_file():
                continue

            rel_path = str(file_path.relative_to(repo_root)).replace("\\", "/")

            if glob_filter and not fnmatch.fnmatch(rel_path, glob_filter):
                continue

            try:
                content = file_path.read_text(encoding="utf-8", errors="replace")
            except Exception:
                continue

            for i, line in enumerate(content.split("\n"), start=1):
                if compiled.search(line):
                    matches.append({
                        "file": rel_path,
                        "line": i,
                        "content": line.strip()[:200],
                    })
                    if len(matches) >= max_results:
                        break

        return ToolResult(
            content=json.dumps({"pattern": pattern, "totalMatches": len(matches), "matches": matches}),
            is_terminal=False,
        )

    def _create_plan(self, goal: str, steps: list[str]) -> ToolResult:
        self._plan = AgentPlan(goal=goal, steps=steps)
        logger.info(f"Plan created: {goal} ({len(steps)} steps)")

        return ToolResult(
            content=json.dumps({
                "planCreated": True,
                "goal": goal,
                "steps": steps,
                "message": "Plan registered. Proceed with execution. Call revise_plan if you need to adjust.",
            }),
            is_terminal=False,
        )

    def _revise_plan(self, reason: str, updated_steps: list[str]) -> ToolResult:
        if not self._plan:
            return ToolResult(
                content=json.dumps({"error": "No plan exists. Call create_plan first."}),
                is_terminal=False,
            )

        if self._plan.revision_count >= MAX_PLAN_REVISIONS:
            return ToolResult(
                content=json.dumps({
                    "error": f"Plan revision limit reached ({MAX_PLAN_REVISIONS}). Stop revising and execute the current plan.",
                    "currentSteps": self._plan.steps,
                }),
                is_terminal=False,
            )

        self._plan.steps = updated_steps
        self._plan.revision_count += 1
        logger.info(f"Plan revised (#{self._plan.revision_count}): {reason}")

        return ToolResult(
            content=json.dumps({
                "planRevised": True,
                "reason": reason,
                "revisionNumber": self._plan.revision_count,
                "updatedSteps": updated_steps,
            }),
            is_terminal=False,
        )

    def _read_memory(self, skill: str, scope: str = "project") -> ToolResult:
        logger.info(f"[agent:read_memory] skill='{skill}' scope={scope}")
        # Use manifest memory maps for validation
        if scope == "global":
            valid_keys = set(self._manifest.memory.global_files.keys())
            file_map = self._manifest.memory.global_files
        else:
            valid_keys = set(self._manifest.memory.local_files.keys())
            file_map = self._manifest.memory.local_files

        filename = file_map.get(skill)
        if not filename:
            valid = ", ".join(valid_keys)
            return ToolResult(
                content=json.dumps({"error": f"Unknown skill: '{skill}'. Valid: {valid}"}),
                is_terminal=False,
            )

        if scope == "global" and not self._memory.has_global:
            return ToolResult(
                content=json.dumps({"error": "Global memory is not configured."}),
                is_terminal=False,
            )

        raw = self._memory.read_skill(filename, scope=scope)
        content = raw[:3000] + "\n...[truncated]" if len(raw) > 3000 else raw

        return ToolResult(content=content, is_terminal=False)

    def _search_memory(self, query: str, max_results: int = 5, scope: str = "all") -> ToolResult:
        logger.info(f"[agent:search_memory] query='{query}' scope={scope} max={max_results}")
        results = self._memory.search_memory(query, max_results=max_results, scope=scope)

        if not results:
            return ToolResult(
                content=json.dumps({
                    "query": query,
                    "scope": scope,
                    "totalResults": 0,
                    "results": [],
                    "message": "No matching memory sections found.",
                }),
                is_terminal=False,
            )

        return ToolResult(
            content=json.dumps({
                "query": query,
                "scope": scope,
                "totalResults": len(results),
                "results": [{"source": r.source, "score": r.score, "section": r.section} for r in results],
            }),
            is_terminal=False,
        )

    def _store_memory(self, category: str, title: str, content: str, scope: str = "project") -> ToolResult:
        if not title or not content:
            return ToolResult(
                content=json.dumps({"error": "Both title and content are required."}),
                is_terminal=False,
            )

        if scope == "global" and not self._memory.has_global:
            return ToolResult(
                content=json.dumps({"error": "Global memory is not configured. Use scope 'project' instead."}),
                is_terminal=False,
            )

        self._memory.store_memory(category, title, content, scope=scope)

        return ToolResult(
            content=json.dumps({
                "stored": True,
                "category": category,
                "scope": scope,
                "title": title,
                "message": f"Memory stored under '{category}' ({scope} scope).",
            }),
            is_terminal=False,
        )

    def _store_draft(self, documentation: str) -> ToolResult:
        if not documentation.strip():
            return ToolResult(
                content=json.dumps({"error": "Draft cannot be empty."}),
                is_terminal=False,
            )

        # Hard cap: maximum 3 draft stores per run
        if self._store_draft_calls >= 5:
            return ToolResult(
                content=json.dumps({
                    "error": "store_draft hard cap exceeded (max 3 total calls). Proceed to validate_documentation and write_documentation.",
                    "draftStoresUsed": self._store_draft_calls,
                    "draftStoresRemaining": 0,
                }),
                is_terminal=False,
            )
        
          # ── Anti-shrink guard ─────────────────────────────────────────────
        # Reject drafts that are significantly shorter than the current draft.
        # This prevents the agent from dropping content during revision.
        if self._current_draft and self._store_draft_calls >= 1:
            current_len = len(self._current_draft)
            new_len = len(documentation.strip())
            if new_len < current_len * 0.85:  # more than 15% shorter
                return ToolResult(
                    content=json.dumps({
                        "error": (
                            f"Draft rejected — new draft ({new_len} chars) is significantly shorter than "
                            f"the current draft ({current_len} chars). "
                            "You must preserve all existing content and only ADD or FIX sections. "
                            "Copy the previous draft and apply targeted changes only."
                        ),
                        "currentDraftLength": current_len,
                        "newDraftLength": new_len,
                    }),
                    is_terminal=False,
                )
        # ─────────────────────────────────────────────────────────────────

        self._store_draft_calls += 1

        # Once a draft exists, exploration must stop
        self._exploration_locked = True

        # Hard cap: truncate at 4000 chars (~1000 tokens).
        MAX_DRAFT_CHARS = 16000
        original_len = len(documentation)
        was_truncated = original_len > MAX_DRAFT_CHARS
        if was_truncated:
            documentation = documentation[:MAX_DRAFT_CHARS]
            logger.warn(
                f"Draft truncated from {original_len:,} to {MAX_DRAFT_CHARS} chars. "
                "Write a shorter draft — aim for under 3,000 words using bullet lists."
            )

        self._current_draft = documentation
        char_count = len(documentation)
        # Push store_draft step to agent handler's steps log
        for handler in self._agent_handlers:
            if hasattr(handler, "_steps_log"):
                handler._steps_log.append(
                    f"store_draft — draft #{self._store_draft_calls} "
                    f"({char_count} chars)"
                )
        
        logger.info(f"Draft stored ({char_count} chars)")

        return ToolResult(
            content=json.dumps({
                "stored": True,
                "charCount": char_count,
                "truncated": was_truncated,
                "draftStoresUsed": self._store_draft_calls,
                "draftStoresRemaining": max(0, 3 - self._store_draft_calls),
                "explorationLocked": True,
                "message": (
                    "Draft stored. Exploration is now locked. Call critique_documentation, evaluate_quality, then validate_documentation."
                    if not was_truncated else
                    "Draft was truncated to 4000 chars. Exploration is locked. Rewrite more concisely only if needed, then validate and write."
                ),
            }),
            is_terminal=False,
        )

    def _signal_no_change(self, reason: str) -> ToolResult:
        logger.success(f"NO_CHANGE: {reason}")
        return ToolResult(
            content=json.dumps({"noChange": True, "reason": reason}),
            is_terminal=True,
            terminal_status="NO_API_CHANGE",
        )