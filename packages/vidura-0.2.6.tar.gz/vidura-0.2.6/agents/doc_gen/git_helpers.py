"""Doc-gen specific git helpers — API file filtering."""

from __future__ import annotations

import os
import re

from core.extractor.types import ChangedFile

# File extensions that can contain API definitions
API_EXTENSIONS = {".ts", ".js", ".py", ".java", ".kt", ".graphql", ".gql"}

API_PATH_PATTERNS = [
    re.compile(r"/(routes?|controllers?|handlers?|api|endpoints?|views?|resources?|routers?)/", re.IGNORECASE),
    re.compile(r"\.(routes?|controller|handler|resource|router)\.(ts|js|py|java|kt)$", re.IGNORECASE),
    re.compile(r"schema\.(graphql|gql)$", re.IGNORECASE),
]

# FIX: FastAPI content signatures — if a .py file contains these patterns it IS
# an API file regardless of where it lives in the directory tree.
# filter_api_files was dropping files like app/payments.py, app/tasks.py, main.py
# because they don't match any API_PATH_PATTERNS, so FastApiExtractor.detect()
# never saw them and [fastapi] always reported "matched 0 file(s)".
FASTAPI_CONTENT_SIGNATURES = re.compile(
    r"from\s+fastapi\s+import|@(?:app|router)\s*\.\s*(?:get|post|put|patch|delete|head|options)\s*\(",
    re.IGNORECASE,
)

DJANGO_CONTENT_SIGNATURES = re.compile(
    r"from\s+rest_framework|from\s+django|@api_view|ViewSet|APIView"
    r"|router\.register|@action|urlpatterns",
    re.IGNORECASE,
)


def filter_api_files(files: list[ChangedFile]) -> list[ChangedFile]:
    """Filter to only API-related changed files."""
    result: list[ChangedFile] = []
    for f in files:
        ext = os.path.splitext(f.path)[1].lower()
        if ext not in API_EXTENSIONS:
            continue
        # Accept any .graphql/.gql file
        if ext in (".graphql", ".gql"):
            result.append(f)
            continue
        # Accept files in API-adjacent paths
        if any(p.search(f.path) for p in API_PATH_PATTERNS):
            result.append(f)
            continue
        # FIX: Accept any .py file whose diff or content contains FastAPI signatures.
        # This catches flat-layout projects (main.py, payments.py, tasks.py) and any
        # file outside the conventional /routes/, /api/, /controllers/ directories.
        if ext == ".py":
            # Strip diff markers before scanning so +from rest_framework matches
            src = re.sub(r"^[+\-]", "", f.diff + (f.content or ""), flags=re.MULTILINE)
            if FASTAPI_CONTENT_SIGNATURES.search(src) or DJANGO_CONTENT_SIGNATURES.search(src):
                result.append(f)
    return result