"""Doc-gen agent tool handler — API extraction, validation, writing, critique, evaluation."""

from __future__ import annotations

import json
from pathlib import Path
from typing import Any

from agents.doc_gen.document import DocumentGenerator, DocumentMetadata
from agents.doc_gen.extractor import extract_api_delta
from agents.doc_gen.validator_engine import ValidatorEngine
from core.config import AgentConfig
from core.extractor.types import ChangedFile, ExtractedApiDelta
from core.logger import logger
from core.memory import MemoryManager
from core.skill_loader import load_skill
from core.skill_runner import SkillRunner
from core.tools.executor import ToolResult

import re
import datetime
# ─── Tool definitions exposed to the LLM ─────────────────────────────────────

TOOL_DEFINITIONS: list[dict] = [
    {
    "name": "extract_api_changes",
    "description": (
        "Extract structured API changes from the changed files. "
        "Automatically detects the framework (django, fastapi, flask) from file contents. "
        "Call this once — it runs all extractors and returns combined results."
    ),
    "input_schema": {
        "type": "object",
        "properties": {},
        "required": [],
    },
},
    {
        "name": "validate_documentation",
        "description": (
            "Validate the stored draft against the extracted API delta. "
            "Returns valid (boolean), errors[], and warnings[]. "
            "Fix all errors before calling write_documentation. "
            "Requires store_draft to be called first."
        ),
        "input_schema": {
            "type": "object",
            "properties": {},
            "required": [],
        },
    },
    {
        "name": "write_documentation",
        "description": (
            "Write the stored draft to disk as both .md and .docx files. "
            "This is a TERMINAL action — the agent loop exits after this call. "
            "Only call after validate_documentation returns valid=true with no errors. "
            "Requires store_draft to be called first."
        ),
        "input_schema": {
            "type": "object",
            "properties": {
                "featureName": {
                    "type": "string",
                    "description": (
                        'The feature name used for the output filename (e.g. "user-auth", "payment-api")'
                    ),
                },
            },
            "required": ["featureName"],
        },
    },
    {
        "name": "critique_documentation",
        "description": (
            "Submit the stored draft for critic review by a separate LLM instance. "
            "Returns scores (1-10) for completeness, clarity, accuracy, structure, and tone, "
            "plus actionable suggestions. Requires store_draft to be called first."
        ),
        "input_schema": {
            "type": "object",
            "properties": {},
            "required": [],
        },
    },
    {
        "name": "evaluate_quality",
        "description": (
            "Evaluate the quality of the stored draft using LLM-based scoring. "
            "Returns a quality score and dimension-level scores for target audience fit, "
            "completeness, code examples, and consistency. Requires store_draft to be called first."
        ),
        "input_schema": {
            "type": "object",
            "properties": {
                "compareWithExisting": {
                    "type": "boolean",
                    "description": "Whether to compare against existing docs in the output dir for style consistency",
                },
            },
            "required": [],
        },
    },
]

_HANDLED_TOOLS = {t["name"] for t in TOOL_DEFINITIONS}


# ─── Tool handler ─────────────────────────────────────────────────────────────


class ToolHandler:
    """Handles doc-gen specific tools: extraction, validation, writing, critique, evaluation."""

    def __init__(
        self,
        repo_path: str,
        config: AgentConfig,
        branch: str,
        memory: MemoryManager,
        secondary_providers: dict[str, Any],
        skills_dir: Path,
        executor: Any,
    ) -> None:
        self.repo_path = repo_path
        self.config = config
        self.branch = branch
        self._memory = memory
        self._secondary_providers = secondary_providers
        self._skills_dir = skills_dir
        self._executor = executor

        self._merged_delta: ExtractedApiDelta | None = None
        self._doc_gen = DocumentGenerator()
        self._validator = ValidatorEngine()
        self._last_quality_score: float | None = None
        self._last_critique_result: dict | None = None
        self._last_validation_errors: list[str] = []
        self._steps_log: list[str] = []

            
        self._validate_calls = 0
        self._critique_calls = 0
        self._evaluate_calls = 0
        self._search_codebase_calls = 0

    def can_handle(self, tool_name: str) -> bool:
        return tool_name in _HANDLED_TOOLS

    async def handle(self, tool_name: str, tool_input: dict[str, Any]) -> ToolResult:
        handlers = {
            "extract_api_changes": lambda: self._extract_api_changes(
                # tool_input.get("framework", "fastapi"),
            ),
            "validate_documentation": lambda: self._validate_documentation(),
            "critique_documentation": lambda: self._critique_documentation(),
            "evaluate_quality": lambda: self._evaluate_quality(
                tool_input.get("compareWithExisting", False),
            ),
        }

        if tool_name == "write_documentation":
            return await self._write_documentation(tool_input.get("featureName", ""))

        handler = handlers.get(tool_name)
        if handler:
            return handler()

        return ToolResult(
            content=json.dumps({"error": f"Unknown doc-gen tool: {tool_name}"}),
            is_terminal=False,
        )

    # ─── Tool implementations ─────────────────────────────────────────────────

    def _extract_api_changes(self, framework: str = "") -> ToolResult:
        from agents.doc_gen.git_helpers import filter_api_files

        # ── First-run MUST come first — before changed_files check ───────────
        if self._is_first_run():
            logger.info("[first-run] No api-inventory found — scanning entire repo")
            SKIP_DIRS = {
                ".git", "node_modules", "__pycache__", "venv", ".venv",
                "dist", "build", "docs", ".agent", "skills", "tests", "test"
            }
            repo_root = Path(self.repo_path)
            all_py_files = []
            for py_path in repo_root.rglob("*.py"):
                parts = py_path.relative_to(repo_root).parts
                if any(part in SKIP_DIRS for part in parts):
                    continue
                rel = str(py_path.relative_to(repo_root)).replace("\\", "/")
                try:
                    content = py_path.read_text(encoding="utf-8", errors="replace")
                except Exception:
                    continue
                from core.extractor.types import ChangedFile as _CF
                all_py_files.append(_CF(
                    path=rel,
                    status="added",
                    diff="\n".join(f"+{line}" for line in content.splitlines()),
                    content=content,
                ))
            logger.info(f"[first-run] Found {len(all_py_files)} Python files to scan")
            api_files = filter_api_files(all_py_files)
            logger.info(f"[first-run] {len(api_files)} API files after filtering")

        else:
            # Normal diff mode
            changed_files = getattr(self._executor, "_changed_files", None)

            if changed_files is None:
                # get_changed_files was never called
                return ToolResult(
                    content=json.dumps({"error": "No changed files available. Call get_changed_files first."}),
                    is_terminal=False,
                )

            if not changed_files:
                # get_changed_files was called but returned empty list
                # This means no API files changed in this commit
                # Signal no change rather than erroring
                logger.info("[extract] get_changed_files returned empty — no API files changed")
                return ToolResult(
                    content=json.dumps({
                        "new": [],
                        "modified": [],
                        "removed": [],
                        "noChanges": True,
                        "message": "No API-relevant files changed in this commit. Call signal_no_change now.",
                    }),
                    is_terminal=False,
                )

            api_files = filter_api_files(changed_files)

        # Always run ALL extractors — never trust the LLM's framework guess.

        # Always run ALL extractors — never trust the LLM's framework guess.
        # Each extractor's detect() method checks file content to self-select.
        all_frameworks = ["django", "fastapi", "flask"]
        combined: dict = {"new": [], "modified": [], "removed": [],
                        "contract_changes": [], "auth_changes": [], "versioning_changes": []}

        for fw in all_frameworks:
            delta = extract_api_delta(
                api_files,
                self.branch,
                self.branch,
                self.config.base_branch,
                [fw],
            )
            combined["new"].extend(delta.new)
            combined["modified"].extend(delta.modified)
            combined["removed"].extend(delta.removed)
            combined["contract_changes"].extend(delta.contract_changes)
            combined["auth_changes"].extend(delta.auth_changes)
            combined["versioning_changes"].extend(delta.versioning_changes)
            logger.debug(f"[{fw}] new: {len(delta.new)}, modified: {len(delta.modified)}, removed: {len(delta.removed)}")

            logger.info("==== EXTRACTED API DEBUG ====")
            logger.info(f"[{fw}] New APIs: {[ (e.method, e.path) for e in delta.new ]}")
            logger.info(f"[{fw}] Modified APIs: {[ (m.after.method, m.after.path) for m in delta.modified ]}")
            logger.info(f"[{fw}] Removed APIs: {[ (e.method, e.path) for e in delta.removed ]}")
            logger.info("==== END API DEBUG ====")

        # Merge into the session-level delta
        # Merge into the session-level delta
        if self._merged_delta is None:
            # Build from the already-combined loop results above —
            # do NOT call extract_api_delta again (it would re-run on the same files)
            from core.extractor.types import ExtractedApiDelta
            self._merged_delta = ExtractedApiDelta(
                feature=self.branch,
                branch=self.branch,
                base_branch=self.config.base_branch,
                timestamp=datetime.datetime.utcnow().isoformat(),
                new=combined["new"],
                modified=combined["modified"],
                removed=combined["removed"],
                contract_changes=combined["contract_changes"],
                auth_changes=combined["auth_changes"],
                versioning_changes=combined["versioning_changes"],
            )
        else:
            self._merged_delta.new.extend(combined["new"])
            self._merged_delta.modified.extend(combined["modified"])
            self._merged_delta.removed.extend(combined["removed"])
            self._merged_delta.contract_changes.extend(combined["contract_changes"])
            self._merged_delta.auth_changes.extend(combined["auth_changes"])
            self._merged_delta.versioning_changes.extend(combined["versioning_changes"])

            # Log after merge regardless of which branch ran
        self._steps_log.append(
            f"extract_api_changes — "
            f"{len(self._merged_delta.new)} new, "
            f"{len(self._merged_delta.modified)} modified, "
            f"{len(self._merged_delta.removed)} removed endpoints"
        )

        logger.info("==== FINAL MERGED DELTA ====")
        logger.info(f"Total New: {len(self._merged_delta.new)}")
        logger.info(f"Total Modified: {len(self._merged_delta.modified)}")
        logger.info(f"Total Removed: {len(self._merged_delta.removed)}")
        logger.info("==== END FINAL DELTA ====")
        # ── Save inventory immediately on first run ───────────────────────────
        # Do this before returning so even if the run fails later (token budget,
        # validation errors), the inventory exists and next run uses diff mode.
        if self._is_first_run():
            self._save_api_inventory()
            logger.info("[first-run] api-inventory.md saved — future runs will use git diff mode")
        # ─────────────────────────────────────────────────────────────────────
        total = (
            len(self._merged_delta.new)
            + len(self._merged_delta.modified)
            + len(self._merged_delta.removed)
        )

        if total == 0:
            logger.info("[extract] Zero API changes detected")
            return ToolResult(
                content=json.dumps({
                    "new": [],
                    "modified": [],
                    "removed": [],
                    "noChanges": True,
                    "message": "No API changes detected in this diff. Call signal_no_change now.",
                }),
                is_terminal=False,
            )

        result_dict = _delta_to_dict(self._merged_delta)

        # ── Inject _readHint so LLM jumps to correct line ─────────────────────
        changed_files_list = getattr(self._executor, "_changed_files", [])

        def _find_endpoint_line(ep_method: str, ep_path: str) -> tuple[str, int] | None:
            for cf in changed_files_list:
                try:
                    full = (Path(self.repo_path) / cf.path).read_text(encoding="utf-8", errors="replace")
                    lines = full.split("\n")
                    pat = re.compile(rf'@(?:app|router)\.{ep_method.lower()}\s*\(', re.IGNORECASE)
                    for i, line in enumerate(lines, start=1):
                        if pat.search(line) and ep_path in line:
                            return cf.path, i
                    # NO FALLBACK — removed endpoints won't be found, return None
                except Exception:
                    pass
            return None

        all_ep_dicts = result_dict.get("new", []) + result_dict.get("removed", [])
        for mod in result_dict.get("modified", []):
            after = mod.get("after")
            if after:
                all_ep_dicts.append(after)

        for ep_dict in all_ep_dicts:
            if not isinstance(ep_dict, dict):
                continue
            hit = _find_endpoint_line(ep_dict.get("method", ""), ep_dict.get("path", ""))
            if hit:
                file_path, lineno = hit
                ep_dict["_sourceFile"] = file_path
                ep_dict["_sourceLine"] = lineno
                ep_dict["_readHint"] = f"read_file(path='{file_path}', offset={max(0, lineno - 2)}, limit=80)"
        # ─────────────────────────────────────────────────────────────────────
        # ── Debug: show exactly what's extracted and passed to LLM ───────────
        logger.debug("==== DELTA PASSED TO LLM ====")
        logger.debug(f"Total: {len(self._merged_delta.new)} new, {len(self._merged_delta.modified)} modified, {len(self._merged_delta.removed)} removed")

        for ep in self._merged_delta.new:
            logger.debug(f"[NEW] {ep.method} {ep.path}")
            logger.debug(f"  auth       : {ep.auth.type if ep.auth else 'none'}")
            logger.debug(f"  handler    : {ep.handler}")
            logger.debug(f"  path_params: {[(p.name, p.type) for p in (ep.params or [])]}")
            logger.debug(f"  query_params: {[(q.name, q.type, q.required) for q in (ep.query or [])]}")
            logger.debug(f"  request_body: {[(f.name, f.type, f.required) for f in (ep.request_schema or [])]}")
            logger.debug(f"  response   : {[(f.name, f.type) for f in (ep.response_schema or [])]}")

        for mod in self._merged_delta.modified:
            ep = mod.after
            logger.debug(f"[MODIFIED] {ep.method} {ep.path} ({mod.change_type})")
            logger.debug(f"  query_params: {[(q.name, q.type, q.required) for q in (ep.query or [])]}")
            logger.debug(f"  request_body: {[(f.name, f.type, f.required) for f in (ep.request_schema or [])]}")

        for ep in self._merged_delta.removed:
            logger.debug(f"[REMOVED] {ep.method} {ep.path}")

        logger.debug(f"[JSON TO LLM] {json.dumps(result_dict)[:800]}")
        logger.debug("==== END DELTA ====")
        # ─────────────────────────────────────────────────────────────────────
        result_dict["_instruction"] = (
            "GROUND TRUTH — document ONLY the endpoints listed in this response. "
            f"Total: {len(self._merged_delta.new)} new, "
            f"{len(self._merged_delta.modified)} modified, "
            f"{len(self._merged_delta.removed)} removed. "
            "Endpoints in 'removed' must appear ONLY under '## Removed APIs' — "
            "never as active or new endpoints. "
            "Do not add fields, descriptions, or endpoints from memory or inference."
        )
        return ToolResult(
            content=json.dumps(result_dict),
            is_terminal=False,
        )
        

    def _validate_documentation(self) -> ToolResult:
        draft = self._executor._current_draft
        

        if not draft:
            return ToolResult(
                content=json.dumps({
                    "valid": False,
                    "errors": ["No draft available. Call store_draft first."],
                    "warnings": [],
                }),
                is_terminal=False,
            )

        if not self._merged_delta:
            return ToolResult(
                content=json.dumps({
                    "valid": False,
                    "errors": ["No API delta available. Call extract_api_changes first."],
                    "warnings": [],
                }),
                is_terminal=False,
            )

        # 🚨 Enforce critique + evaluate BEFORE validation
        if self._critique_calls == 0:
            return ToolResult(
                content=json.dumps({
                    "valid": False,
                    "errors": ["You must call critique_documentation before validate_documentation."],
                    "warnings": [],
                }),
                is_terminal=False,
            )

        if self._evaluate_calls == 0:
            return ToolResult(
                content=json.dumps({
                    "valid": False,
                    "errors": ["You must call evaluate_quality before validate_documentation."],
                    "warnings": [],
                }),
                is_terminal=False,
            )

        # 🚨 Hard cap: max 2 validations
        if self._validate_calls >= 2:
            return ToolResult(
                content=json.dumps({
                    "valid": False,
                    "errors": [
                        "validate_documentation hard cap exceeded (max 2). "
                        "Do NOT validate again. Add Known Limitations and call write_documentation immediately."
                    ],
                    "warnings": [],
                }),
                is_terminal=False,
            )

        self._validate_calls += 1

        # Load validator
        validator_path = self._skills_dir / "validator.md"
        if not validator_path.exists():
            return ToolResult(
                content=json.dumps({
                    "valid": True,
                    "errors": [],
                    "warnings": ["No validator.md skill found — skipping validation."],
                }),
                is_terminal=False,
            )

        skill = load_skill(validator_path)
        result = self._validator.validate(draft, self._merged_delta, skill)

        message = (
            "Documentation is valid. Call write_documentation now."
            if result.valid
            else (
                f"Validation failed with {len(result.errors)} error(s). "
                "Fix ONLY these errors. Do NOT re-explore. Then call write_documentation."
            )
        )
        self._last_validation_errors = result.errors
        self._steps_log.append(
            f"validate_documentation — "
            f"{'passed' if result.valid else f'failed: {len(result.errors)} error(s): {result.errors[:2]}'}"
        )

        
        
        return ToolResult(
            content=json.dumps({
                "valid": result.valid,
                "errors": result.errors,
                "warnings": result.warnings,
                "validateCallsUsed": self._validate_calls,
                "validateCallsRemaining": max(0, 2 - self._validate_calls),
                "message": message,
            }),
            is_terminal=False,
        )

    async def _write_documentation(self, feature_name: str) -> ToolResult:
        draft = self._executor._current_draft
        if not draft:
            return ToolResult(
                content=json.dumps({
                    "success": False,
                    "error": "No draft available. Call store_draft before writing.",
                }),
                is_terminal=False,
            )
        
        # ── Guard against missing delta ───────────────────────────────────────
        if not self._merged_delta:
            return ToolResult(
                content=json.dumps({
                    "success": False,
                    "error": "No API delta available. Call extract_api_changes first.",
                }),
                is_terminal=True,
                terminal_status="NO_API_CHANGE",
            )
        # ─────────────────────────────────────────────────────────────────────

        hallucination_result = self._validate_no_hallucination(draft)
        if hallucination_result is not None:
            return hallucination_result  # non-terminal — agent fixes and retries

        total_apis = (
            len(self._merged_delta.new) +
            len(self._merged_delta.modified) +
            len(self._merged_delta.removed)
        )

        if total_apis == 0:
            return ToolResult(
                content=json.dumps({
                    "success": False,
                    "error": "No API changes detected — skipping documentation"
                }),
                is_terminal=True,
                terminal_status="NO_API_CHANGE"
            )

        output_dir = str(Path(self.repo_path) / self.config.output_dir)

        # Read doc-specific config from extra fields
        extra = getattr(self.config, "extra", {}) or {}
        doc_title_template = extra.get("doc_title_template", "{feature} - API Documentation")

        # Gather git metadata for the metadata block in the DOCX
        git_meta = self._executor._git.get_commit_metadata(self.config.base_branch)
        changed_files = getattr(self._executor, "_changed_files", [])
        doc_changed_files = [
            f"{f.path} ({f.status.lower()})"
            for f in changed_files
            if not (
                f.path.startswith("skills/")
                or f.path.startswith(".agent/")
                or f.path.startswith(".git")
                or f.path == ".gitignore"
            )
        ]

        metadata = DocumentMetadata(
            feature_name=feature_name,
            version=git_meta.get("version", ""),
            repo_name=self.config.repo_name or git_meta["repo_name"],
            project_name=self.config.project_name or git_meta["repo_name"],
            org_name=self.config.org_name or "",
            branch_name=self.branch,
            authors=git_meta.get("authors", "Engineering Team"),
            previous_commit=git_meta.get("previous_commit", ""),
            current_commit=git_meta.get("current_commit", ""),
            commit_message=git_meta.get("commit_message", ""),
            commit_time=git_meta.get("commit_time", ""),
            changed_files=doc_changed_files,
            
        )

        # Give the generator the repo root so it can resolve relative logo paths
        self._doc_gen._repo_path = self.repo_path

        output = await self._doc_gen.generate(
            draft,
            feature_name,
            output_dir,
            metadata=metadata,
            doc_title_template=doc_title_template,
            org_name=self.config.org_name,
            project_name=self.config.project_name,
            repo_name=self.config.repo_name,
        )

        # Log write step first so it appears in the run summary
        self._steps_log.append(
            f"write_documentation — "
            f"md: {output.markdown_path}, "
            f"docx: {output.docx_path}"
        )

        # Persist endpoint knowledge for future runs
        self._memory.update_from_delta(self._merged_delta)
        self._save_api_inventory()          # writes api-inventory.md + memory entry
        self._store_run_summary(feature_name, extra)

        logger.success(f"Documentation written -> {output.docx_path}")

        return ToolResult(
            content=json.dumps({
                "success": True,
                "markdownPath": output.markdown_path,
                "docxPath": output.docx_path,
            }),
            is_terminal=True,
            terminal_status="GENERATED",
            output_path=output.docx_path,
            feature_name=feature_name,
        )

    def _critique_documentation(self) -> ToolResult:
        self._critique_calls += 1
        draft = self._executor._current_draft
        if not draft:
            return ToolResult(
                content=json.dumps({"error": "No draft available. Call store_draft first."}),
                is_terminal=False,
            )

        critic_provider = self._secondary_providers.get("critic")
        if not critic_provider:
            return ToolResult(
                content=json.dumps({"error": "Critic agent is not configured (no LLM provider available)."}),
                is_terminal=False,
            )

        if not self._merged_delta:
            return ToolResult(
                content=json.dumps({"error": "No API delta available. Call extract_api_changes first."}),
                is_terminal=False,
            )

        # Load critic skill and run via SkillRunner
        critic_path = self._skills_dir / "critic.md"
        if not critic_path.exists():
            return ToolResult(
                content=json.dumps({"error": "No critic.md skill found in skills directory."}),
                is_terminal=False,
            )

        skill = load_skill(critic_path)
        runner = SkillRunner(critic_provider)
        result = runner.run(skill, {
            "documentation": draft,
            "delta_summary": json.dumps(_delta_to_dict(self._merged_delta)),
        })

        if isinstance(result, dict):
            self._last_critique_result = result
            overall = (
                result.get("overallScore")
                or result.get("overall_score")
                or result.get("score")
                or "?"
            )
            self._steps_log.append(
                f"critique_documentation — overall score: {overall}/10"
            )

        return ToolResult(
            content=json.dumps(result),
            is_terminal=False,
        )

    def _evaluate_quality(self, compare_with_existing: bool = False) -> ToolResult:
        self._evaluate_calls += 1
        draft = self._executor._current_draft
        if not draft:
            return ToolResult(
                content=json.dumps({"error": "No draft available. Call store_draft first."}),
                is_terminal=False,
            )

        evaluator_provider = self._secondary_providers.get("evaluator")
        if not evaluator_provider:
            return ToolResult(
                content=json.dumps({"error": "Quality evaluator is not configured (no LLM provider available)."}),
                is_terminal=False,
            )

        # Skip evaluator for small changes
        if self._merged_delta:
            total_endpoints = (
                len(self._merged_delta.new)
                + len(self._merged_delta.modified)
                + len(self._merged_delta.removed)
            )
            if total_endpoints <= 2:
                return ToolResult(
                    content=json.dumps({
                        "skipped": True,
                        "reason": f"Only {total_endpoints} endpoint(s) changed — critic review is sufficient.",
                        "qualityScore": None,
                    }),
                    is_terminal=False,
                )

        # Load evaluator skill and run
        evaluator_path = self._skills_dir / "evaluator.md"
        if not evaluator_path.exists():
            return ToolResult(
                content=json.dumps({"error": "No evaluator.md skill found in skills directory."}),
                is_terminal=False,
            )

        skill = load_skill(evaluator_path)
        runner = SkillRunner(evaluator_provider)

        context: dict[str, Any] = {"documentation": draft}

        if compare_with_existing:
            output_dir = Path(self.repo_path) / self.config.output_dir
            existing = _read_existing_docs(output_dir)
            if existing:
                context["existing_docs"] = existing

        result = runner.run(skill, context)

        # Cache the score so write_documentation can store an automated feedback entry
        # Cache the score so write_documentation can store an automated feedback entry
        if isinstance(result, dict):
            score = result.get("qualityScore") or result.get("overallScore")
            if score is not None:
                try:
                    self._last_quality_score = float(score)
                except (TypeError, ValueError):
                    pass
                self._steps_log.append(
        f"evaluate_quality — score: {self._last_quality_score or '?'}/10"
    )

        return ToolResult(
            content=json.dumps(result),
            is_terminal=False,
        )

    def _store_run_summary(self, feature_name: str, extra: dict) -> None:
        """Store rich feedback after every successful write.
        All scores, steps, and lessons come from actual run data — nothing hardcoded.
        """
        if not self._merged_delta:
            return

        score = self._last_quality_score
        style = extra.get("doc_style", "detailed")
        n_new = len(self._merged_delta.new)
        n_mod = len(self._merged_delta.modified)
        n_rem = len(self._merged_delta.removed)
        rating = "good" if (score is not None and score >= 7) else "improved"

        lines = []

        # ── Run overview ──────────────────────────────────────────────────────
        lines.append(f"Style: {style}.")
        lines.append(
            f"Endpoints: {n_new} new, {n_mod} modified, {n_rem} removed."
        )
        # Helper used in critic notes and lessons blocks
        def _extract_msg(s: Any) -> str:
            if isinstance(s, str):
                return s
            if isinstance(s, dict):
                return (s.get("message") or s.get("suggestion")
                        or s.get("issue") or str(s))
            return str(s)
        
        # ── Quality scores (real — from evaluator + critic LLM calls) ─────────
        if score is not None or self._last_critique_result:
            lines.append("\nQuality Scores:")
            if score is not None:
                lines.append(f"  Evaluator overall: {score:.1f}/10")
            if self._last_critique_result:
                cr = self._last_critique_result
                critic_overall = cr.get("overallScore") or cr.get("overall_score")
                if critic_overall is not None:
                    lines.append(f"  Critic overall: {critic_overall}/10")
                # Dimensions are nested under 'scores' key
                scores_dict = cr.get("scores") or {}
                for dim in ("completeness", "clarity", "accuracy",
                            "structure", "developerExperience"):
                    val = scores_dict.get(dim) or cr.get(dim)
                    if val is not None:
                        lines.append(f"  {dim}: {val}/10")

        # ── Critic notes (real — from critic LLM output) ──────────────────────
        # ── Critic notes (real — from critic LLM output) ──────────────────────
        if self._last_critique_result:
            cr = self._last_critique_result

            def _extract_msg(s: Any) -> str:
                if isinstance(s, str):
                    return s
                if isinstance(s, dict):
                    return (s.get("message") or s.get("suggestion")
                            or s.get("issue") or str(s))
                return str(s)

            critical = cr.get("criticalIssues") or []
            suggestions = cr.get("suggestions") or cr.get("improvements") or []

            if critical:
                lines.append("\nCritical Issues (fix first):")
                for s in critical[:5]:
                    lines.append(f"  - {_extract_msg(s)}")

            if suggestions:
                lines.append("\nSuggestions:")
                for s in suggestions[:5]:
                    lines.append(f"  - {_extract_msg(s)}")

        # ── Validation gaps (real — from validator engine) ────────────────────
        if self._last_validation_errors:
            lines.append("\nValidation Gaps:")
            for e in self._last_validation_errors[:5]:
                lines.append(f"  - {e}")

        # ── Steps (real — logged during actual execution) ─────────────────────
        if self._steps_log:
            lines.append("\nSteps This Run:")
            for i, step in enumerate(self._steps_log, 1):
                lines.append(f"  {i}. {step}")

        # ── Lessons (real — derived from actual critic + validator output) ─────
        # ── Lessons (actionable instructions for next run's first draft) ────────
        lines.append("\nLessons — Apply Before Writing First Draft Next Run:")
        lessons_added = False

        # Validation errors → direct fix instructions
        if self._last_validation_errors:
            for e in self._last_validation_errors[:3]:
                if "Feature" in e or "header" in e.lower():
                    clean = re.sub(
                        r"^(feature|feat|fix|chore|hotfix|release)/", "",
                        self._merged_delta.feature
                    )
                    lines.append(
                        f"  - Start document with exactly: '# Feature: {clean}'"
                    )
                elif "Invented endpoint" in e:
                    lines.append(
                        "  - Only document endpoints from extract_api_changes — "
                        "never from memory or inference"
                    )
                else:
                    lines.append(f"  - Fix before drafting: {e}")
                lessons_added = True

        # Critical issues → must-fix instructions
        if self._last_critique_result:
            cr = self._last_critique_result
            critical = cr.get("criticalIssues") or []
            for c in critical[:3]:
                lines.append(f"  - Must fix: {_extract_msg(c)}")
                lessons_added = True

            # Low dimension scores → targeted instructions
            scores_dict = cr.get("scores") or {}
            dim_instructions = {
                "completeness": "Include all path params, query params, request body, response schema, and error codes",
                "developerExperience": "Add runnable cURL with Authorization: Bearer <token> for every endpoint",
                "accuracy": "Verify all field names and types against source using read_file — no guessing",
                "structure": "Use ### METHOD /path heading format for every endpoint",
                "clarity": "Write 2-3 sentence description per endpoint: what, when, expected output",
            }
            for dim, instruction in dim_instructions.items():
                val = scores_dict.get(dim) or cr.get(dim)
                if val is not None and float(val) < 7:
                    lines.append(f"  - {instruction} ({dim} scored {val}/10 last run)")
                    lessons_added = True

        if not lessons_added:
            lines.append("  - All dimensions scored well — maintain current approach")

        note = "\n".join(lines)
        self._memory.record_feedback(feature_name, rating, note, scope="global")

    def _validate_no_hallucination(self, draft: str) -> ToolResult | None:
        if not self._merged_delta:
            return None  # no delta = nothing to check, let it through

        def _normalise(path: str) -> str:
            return re.sub(r"^/(v\d+|api/v\d+)/", "/", path)

        active_allowed: set[tuple[str, str]] = set()
        for e in self._merged_delta.new:
            active_allowed.add((e.method, _normalise(e.path)))
        for m in self._merged_delta.modified:
            active_allowed.add((m.after.method, _normalise(m.after.path)))

        removed_allowed: set[tuple[str, str]] = set()
        for e in self._merged_delta.removed:
            removed_allowed.add((e.method, _normalise(e.path)))

        all_allowed = active_allowed | removed_allowed

        found = re.findall(r"(GET|POST|PUT|DELETE|PATCH)\s+(/[^\s`\n]+)", draft)

        hallucinated = []
        for method, path in found:
            if (method, _normalise(path)) not in all_allowed:
                hallucinated.append(f"{method} {path}")

        if not hallucinated:
            return None  # clean

        exact_allowed = (
            [f"{e.method} {e.path}" for e in self._merged_delta.new]
            + [f"{m.after.method} {m.after.path}" for m in self._merged_delta.modified]
            + [f"{e.method} {e.path}" for e in self._merged_delta.removed]
        )

        logger.warn(f"[hallucination-check] Blocked: {hallucinated}")
        logger.warn(f"[hallucination-check] Allowed: {exact_allowed}")

        # Unlock one store_draft slot so agent can fix and resubmit
        self._executor._store_draft_calls = max(0, self._executor._store_draft_calls - 1)
        self._executor._exploration_locked = False

        return ToolResult(
            content=json.dumps({
                "success": False,
                "hallucinationDetected": True,
                "blockedEndpoints": hallucinated,
                "allowedEndpoints": exact_allowed,
                "action": (
                    "Your draft contains endpoint paths not in the extracted delta. "
                    "Copy the exact paths from allowedEndpoints character-for-character. "
                    "Fix the draft, call store_draft, then call write_documentation again."
                ),
            }),
            is_terminal=False,  # agent can fix and retry
        )
    
    def _generate_doc_from_delta(self) -> str:
        if not self._merged_delta:
            return ""

        delta = self._merged_delta
        lines = ["# API Changes\n"]

        def render(ep):
            return f"""
    ### {ep.method} {ep.path}

    Auth: {ep.auth.type if ep.auth else "none"}

    Request:
    {[f"{f.name}: {f.type}" for f in (ep.request_schema or [])]}

    Response:
    {[f"{f.name}: {f.type}" for f in (ep.response_schema or [])]}
    """

        if delta.new:
            lines.append("## New APIs\n")
            for ep in delta.new:
                lines.append(render(ep))

        if delta.modified:
            lines.append("## Modified APIs\n")
            for m in delta.modified:
                lines.append(render(m.after))

        if delta.removed:
            lines.append("## Removed APIs\n")
            for ep in delta.removed:
                lines.append(f"- {ep.method} {ep.path}")

        return "\n".join(lines)
    
    def _inventory_path(self) -> Path:
        """Path to the api-inventory file that marks a completed first run."""
        mem_dir = getattr(self.config, "memory_dir", ".agent/skills")
        return Path(self.repo_path) / mem_dir / "api-inventory.md"

    def _is_first_run(self) -> bool:
        md_path = self._inventory_path()
        json_path = md_path.with_suffix(".json")
        return not md_path.exists() and not json_path.exists()

    # def _save_api_inventory(self) -> None:
    #     if not self._merged_delta:
    #         return

    #     inv_path = Path(self.repo_path) / ".agent/skills/api-inventory.md"
    #     inv_path.parent.mkdir(parents=True, exist_ok=True)

    #     # Load existing
    #     if inv_path.exists():
    #         existing = json.loads(inv_path.read_text())
    #         endpoints = {
    #             (e["method"], e["path"]): e
    #             for e in existing.get("endpoints", [])
    #         }
    #     else:
    #         endpoints = {}

    #     def to_dict(ep):
    #         return {
    #             "method": ep.method,
    #             "path": ep.path,
    #             "handler": ep.handler,
    #             "auth": ep.auth.type if ep.auth else "none",
    #             "request": [
    #                 {"name": f.name, "type": f.type, "required": f.required}
    #                 for f in (ep.request_schema or [])
    #             ],
    #             "response": [
    #                 {"name": f.name, "type": f.type, "required": f.required}
    #                 for f in (ep.response_schema or [])
    #             ],
    #             "query": [
    #                 {"name": q.name, "type": q.type, "required": q.required}
    #                 for q in (ep.query or [])
    #             ],
    #             "params": [
    #                 {"name": p.name, "type": p.type}
    #                 for p in (ep.params or [])
    #             ],
    #             "last_updated": datetime.datetime.utcnow().isoformat(),
    #             "status": "active"
    #         }

    #     # Apply changes
    #     for ep in self._merged_delta.new:
    #         endpoints[(ep.method, ep.path)] = to_dict(ep)

    #     for mod in self._merged_delta.modified:
    #         endpoints[(mod.after.method, mod.after.path)] = to_dict(mod.after)

    #     for ep in self._merged_delta.removed:
    #         key = (ep.method, ep.path)
    #         if key in endpoints:
    #             endpoints[key]["status"] = "removed"

    #     final = {"endpoints": list(endpoints.values())}
    #     inv_path.write_text(json.dumps(final, indent=2))

    #     logger.info(f"[api-inventory] JSON updated: {len(final['endpoints'])} endpoints")

    def _save_api_inventory(self) -> None:
        if not self._merged_delta:
            return

        inv_path = self._inventory_path()
        inv_path.parent.mkdir(parents=True, exist_ok=True)

        # Load existing endpoints from markdown front-matter JSON block
        existing_endpoints: dict = {}
        if inv_path.exists():
            content = inv_path.read_text(encoding="utf-8")
            # Extract JSON from fenced code block
            json_match = re.search(r"```json\n(.*?)\n```", content, re.DOTALL)
            if json_match:
                try:
                    data = json.loads(json_match.group(1))
                    existing_endpoints = {
                        (e["method"], e["path"]): e
                        for e in data.get("endpoints", [])
                    }
                except Exception:
                    existing_endpoints = {}

        def to_dict(ep):
            return {
                "method": ep.method,
                "path": ep.path,
                "handler": ep.handler,
                "auth": ep.auth.type if ep.auth else "none",
                "request": [{"name": f.name, "type": f.type, "required": f.required} for f in (ep.request_schema or [])],
                "response": [{"name": f.name, "type": f.type, "required": f.required} for f in (ep.response_schema or [])],
                "query": [{"name": q.name, "type": q.type, "required": q.required} for q in (ep.query or [])],
                "params": [{"name": p.name, "type": p.type} for p in (ep.params or [])],
                "last_updated": datetime.datetime.utcnow().isoformat(),
                "status": "active",
            }

        for ep in self._merged_delta.new:
            existing_endpoints[(ep.method, ep.path)] = to_dict(ep)
        for mod in self._merged_delta.modified:
            existing_endpoints[(mod.after.method, mod.after.path)] = to_dict(mod.after)
        for ep in self._merged_delta.removed:
            key = (ep.method, ep.path)
            if key in existing_endpoints:
                existing_endpoints[key]["status"] = "removed"

        endpoints_list = list(existing_endpoints.values())

        # Write human-readable markdown with embedded JSON for machine reading
        lines = [
            "# API Inventory",
            f"Last updated: {datetime.datetime.utcnow().strftime('%Y-%m-%d %H:%M:%S')} UTC",
            f"Total endpoints: {len(endpoints_list)}",
            "",
            "## Endpoints",
            "",
        ]

        # Group by status
        active = [e for e in endpoints_list if e.get("status") != "removed"]
        removed = [e for e in endpoints_list if e.get("status") == "removed"]

        for ep in sorted(active, key=lambda e: e["path"]):
            lines.append(f"### {ep['method']} {ep['path']}")
            lines.append(f"- Handler: `{ep.get('handler', 'unknown')}`")
            lines.append(f"- Auth: `{ep.get('auth', 'none')}`")
            if ep.get("params"):
                lines.append(f"- Path params: {', '.join(p['name'] for p in ep['params'])}")
            if ep.get("query"):
                lines.append(f"- Query params: {', '.join(q['name'] for q in ep['query'])}")
            if ep.get("request"):
                lines.append(f"- Request body: {', '.join(f['name'] for f in ep['request'])}")
            if ep.get("response"):
                lines.append(f"- Response fields: {', '.join(f['name'] for f in ep['response'])}")
            lines.append("")

        if removed:
            lines.append("## Removed Endpoints")
            lines.append("")
            for ep in removed:
                lines.append(f"- ~~{ep['method']} {ep['path']}~~")
            lines.append("")

        # Embed full JSON for machine reading
        lines.append("## Raw Data")
        lines.append("```json")
        lines.append(json.dumps({"endpoints": endpoints_list}, indent=2))
        lines.append("```")

        inv_path.write_text("\n".join(lines), encoding="utf-8")
        logger.info(f"[api-inventory] Markdown updated: {len(endpoints_list)} endpoints → {inv_path}")
        
    def get_merged_delta(self) -> ExtractedApiDelta | None:
        return self._merged_delta


# ─── Helpers ──────────────────────────────────────────────────────────────────


def _delta_to_dict(delta: ExtractedApiDelta) -> dict:
    """Serialize an ExtractedApiDelta to a JSON-friendly dict."""

    def endpoint_dict(ep: Any) -> dict:
        d: dict[str, Any] = {"method": ep.method, "path": ep.path}
        if ep.handler:
            d["handler"] = ep.handler
        if ep.params:                          # ← ADD
            d["pathParams"] = [
                {"name": p.name, "type": p.type}
                for p in ep.params
            ]
        if ep.query:                           # ← ADD
            d["queryParams"] = [
                {"name": q.name, "type": q.type, "required": q.required}
                for q in ep.query
            ]
        if ep.request_schema:
            d["requestSchema"] = [
                {"name": s.name, "type": s.type, "required": s.required}
                for s in ep.request_schema
            ]
        if ep.response_schema:
            d["responseSchema"] = [
                {"name": s.name, "type": s.type, "required": s.required}
                for s in ep.response_schema
            ]
        if ep.auth:
            d["auth"] = {"type": ep.auth.type}
            if ep.auth.scopes:
                d["auth"]["scopes"] = ep.auth.scopes
        if ep.tags:
            d["tags"] = ep.tags
        return d

    return {
        "feature": delta.feature,
        "branch": delta.branch,
        "baseBranch": delta.base_branch,
        "timestamp": delta.timestamp,
        "new": [endpoint_dict(e) for e in delta.new],
        "modified": [
            {
                "before": endpoint_dict(m.before),
                "after": endpoint_dict(m.after),
                "changeType": m.change_type,
            }
            for m in delta.modified
        ],
        "removed": [endpoint_dict(e) for e in delta.removed],
        "contractChanges": [
            {"endpoint": c.endpoint, "changeType": c.change_type, "description": c.description}
            for c in delta.contract_changes
        ],
        "authChanges": [
            {"file": a.file, "type": a.type, "description": a.description}
            for a in delta.auth_changes
        ],
        "versioningChanges": [
            {"type": v.type, "description": v.description}
            for v in delta.versioning_changes
        ],
    }


def _read_existing_docs(output_dir: Path) -> str:
    """Read existing markdown docs for style comparison."""
    if not output_dir.exists():
        return ""

    docs: list[str] = []
    for md_file in sorted(output_dir.glob("*-api-docs.md"))[:3]:
        try:
            content = md_file.read_text(encoding="utf-8", errors="replace")
            docs.append(f"### {md_file.name}\n{content[:2000]}")
        except Exception:
            continue

    return "\n\n".join(docs) if docs else ""

