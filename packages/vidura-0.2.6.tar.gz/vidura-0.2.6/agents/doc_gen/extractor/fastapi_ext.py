
"""FastAPI decorator extractor."""

from __future__ import annotations

import re
from core.logger import logger

from core.extractor.types import (
    ApiEndpoint,
    AuthChange,
    AuthRequirement,
    ChangedFile,
    ModifiedEndpoint,
    SchemaField,
    PathParam,
    QueryParam,
)

# @app.get("/path") | @router.post("/path/{id}")
ROUTE_PATTERN = re.compile(
    r"@(?:app|router)\s*\.\s*(get|post|put|patch|delete|head|options)\s*\(\s*['\"]([^'\"]+)['\"]",
    re.IGNORECASE,
)


class FastApiExtractor:
    def detect(self, files: list[ChangedFile]) -> list[ChangedFile]:
        return [
            f for f in files
            if f.path.endswith(".py") and self._looks_like_fastapi(f.diff + (f.content or ""))
        ]

    def extract(self, file: ChangedFile, full_content: str) -> dict:
        added_src = self._diff_lines(file.diff, "+")
        removed_src = self._diff_lines(file.diff, "-")

        # Determine lookup strategy for new endpoints:
        # If added_src contains 'def ' — the full function was added in this diff
        #   → use added_src (prevents bleed from full_content)
        # If added_src only has the decorator — only path changed, body unchanged
        #   → use full_content (body lives there)
        if "def " in added_src:
            added_lookup = added_src
        else:
            added_lookup = full_content

        added = self._parse_routes(added_src, added_lookup)

        # Removed endpoints: always use removed_src — function gone from full_content
        removed = self._parse_routes(removed_src, removed_src)

        # Body-change fallback: decorator line not in diff but params inside changed.
        # Example: removing a Body() param doesn't touch @app.post(...) line.
        if not added and not removed:
            prev_content = getattr(file, 'prev_content', None)
            body_changed = self._routes_with_body_changes(file.diff, full_content, prev_content)

            if body_changed:
                logger.debug(
                    f"[fastapi] body-change detected in {file.path}: "
                    f"{[(e.method, e.path) for e in body_changed]}"
                )
                return {
                    "new": [],
                    "modified": [
                        ModifiedEndpoint(before=ep, after=ep, change_type="request-schema")
                        for ep in body_changed
                    ],
                    "removed": [],
                    "contract_changes": [],
                    "auth_changes": [],
                    "versioning_changes": [],
                }

        return self._categorise(file.path, added, removed)

    # ─── Private helpers ────────────────────────────────────────────────────────

    @staticmethod
    def _looks_like_fastapi(src: str) -> bool:
        pattern = r"from\s+fastapi\s+import|@(?:app|router)\.(get|post|put|patch|delete)"
        return bool(re.search(pattern, src, re.IGNORECASE))

    @staticmethod
    def _diff_lines(diff: str, marker: str) -> str:
        triple = marker * 3
        return "\n".join(
            line[1:] for line in diff.split("\n") if line.startswith(marker) and not line.startswith(triple)
        )

    def _parse_routes(self, src: str, full_content: str) -> list[ApiEndpoint]:
        results: list[ApiEndpoint] = []

        for m in ROUTE_PATTERN.finditer(src):
            method = m.group(1).upper()
            path = m.group(2)

            # Re-find the same route in full_content to get a valid position.
            fc_pos = None
            for fc_m in ROUTE_PATTERN.finditer(full_content):
                if fc_m.group(1).upper() == method and fc_m.group(2) == path:
                    fc_pos = fc_m.start()
                    break

            if fc_pos is None:
                # Route not found in full_content — use src position directly
                # This happens for removed endpoints when full_content = removed_src
                fc_pos = m.start()

            results.append(
                ApiEndpoint(
                    method=method,
                    path=path,
                    handler=self._extract_handler_name(full_content, fc_pos),
                    request_schema=self._extract_request_schema(full_content, fc_pos),
                    response_schema=self._extract_response_schema(full_content, fc_pos),
                    params=self._extract_path_params(path),
                    query=self._extract_query_params(full_content, fc_pos),
                    auth=self._detect_auth(full_content, fc_pos),
                )
            )

        return results


    @staticmethod
    def _extract_signature_block(src: str, pos: int) -> str:
        """
        Extract the complete function signature by tracking parenthesis depth.
        This handles multi-line signatures with nested parens in default values
        like Query(...), Body(None), Query(False) correctly.
        """
        # Find the 'def' line after the decorator
        ctx = src[pos: pos + 4000]
        def_match = re.search(r"def\s+\w+\s*\(", ctx)
        if not def_match:
            return ""

        # Start from the opening paren of the function definition
        start = def_match.end() - 1  # position of '('
        depth = 0
        i = start
        
        while i < len(ctx):
            ch = ctx[i]
            if ch == "(":
                depth += 1
            elif ch == ")":
                depth -= 1
                if depth == 0:
                    # Found the closing paren of the function signature
                    return ctx[start + 1: i]  # content between outer parens
            i += 1

        return ""
    
    @staticmethod
    def _extract_handler_name(src: str, pos: int) -> str | None:
        ctx = src[pos: pos + 500]
        m = re.search(r"def\s+(\w+)\s*\(", ctx)
        return m.group(1) if m else None

    def _extract_request_schema(self, src: str, pos: int) -> list[SchemaField] | None:
        """
        Extract request body fields.

        Supports:
        1. Inline Body(...) params in function signatures
        2. Closest Pydantic BaseModel declared before the route
        """
        fields: list[SchemaField] = []
        signature = self._extract_signature_block(src, pos)

        # Inline Body(...) params like:
        # payload: dict = Body(...)
        # reviewed_by: str = Body(...)
        # notes: Optional[str] = Body(None)
        for m in re.finditer(
            r"(\w+)\s*:\s*(Optional\[[^\]]+\]|List\[[^\]]+\]|list\[[^\]]+\]|dict|str|int|float|bool|\w+)\s*=\s*Body\((.*?)\)",
            signature,
            re.DOTALL,
        ):
            name = m.group(1)
            typ = m.group(2).strip()
            default_expr = m.group(3)

            required = "None" not in default_expr and not typ.startswith("Optional[")
            clean_type = typ.replace("Optional[", "").replace("]", "")

            fields.append(
                SchemaField(
                    name=name,
                    type=clean_type,
                    required=required,
                    description=None,
                )
            )

        if fields:
            return fields

        # Fallback: nearest Pydantic BaseModel before route
        ctx = src[max(0, pos - 2500): pos]
        model_matches = list(re.finditer(r"class\s+(\w+)\s*\(\s*BaseModel\s*\)\s*:", ctx))
        if not model_matches:
            return None

        model_body = ctx[model_matches[-1].start():]

        for m in re.finditer(
            r"^\s+(\w+)\s*:\s*(Optional\[[\w\[\], ]+\]|List\[[\w\[\], ]+\]|str|int|float|bool|dict|list|\w+)",
            model_body,
            re.MULTILINE,
        ):
            typ = m.group(2).strip()
            fields.append(
                SchemaField(
                    name=m.group(1),
                    type=typ.replace("Optional[", "").replace("]", ""),
                    required=not typ.startswith("Optional"),
                    description=None,
                )
            )
            if len(fields) >= 20:
                break

        return fields or None

    @staticmethod
    def _detect_auth(src: str, pos: int) -> AuthRequirement:
        """
        Detect auth from:
        - authorization/token headers
        - Depends(get_current_user / oauth2 / bearer / auth...)
        - api key patterns
        """
        ctx = src[pos: pos + 1400]  # ← remove the lookback (was max(0, pos-200))

        # Header-based auth like authorization: str = Header(...)
        if re.search(
            r"(authorization|auth|access_token|token)\s*:\s*[\w\[\], ]+\s*=\s*Header\s*\(",
            ctx,
            re.IGNORECASE,
        ):
            return AuthRequirement(type="bearer")

        # Depends-based auth
        if re.search(
            r"Depends\s*\(\s*(?:get_current_user|oauth2_scheme|bearer|jwt|auth)",
            ctx,
            re.IGNORECASE,
        ):
            return AuthRequirement(type="bearer")

        if re.search(r"api_key|APIKey", ctx, re.IGNORECASE):
            return AuthRequirement(type="api-key")

        if re.search(r"basic\s+auth|HTTPBasic|BasicAuth", ctx, re.IGNORECASE):
            return AuthRequirement(type="basic")

        if re.search(r"oauth2", ctx, re.IGNORECASE):
            return AuthRequirement(type="oauth2")

        return AuthRequirement(type="none")

    @staticmethod
    def _extract_path_params(path: str) -> list[PathParam]:
        return [PathParam(name=p, type="string") for p in re.findall(r"{(\w+)}", path)]

    def _extract_query_params(self, src: str, pos: int) -> list[QueryParam] | None:
        """
        Extract only params explicitly declared with Query(...).
        """
        signature = self._extract_signature_block(src, pos)
        params: list[QueryParam] = []

        for m in re.finditer(
            r"(\w+)\s*:\s*(Optional\[[^\]]+\]|List\[[^\]]+\]|int|str|float|bool)\s*=\s*Query\((.*?)\)",
            signature,
            re.DOTALL,
        ):
            name = m.group(1)
            typ = m.group(2).strip()
            default_expr = m.group(3)

            required = "None" not in default_expr and not typ.startswith("Optional[")

            params.append(
                QueryParam(
                    name=name,
                    type=typ.replace("Optional[", "").replace("]", ""),
                    required=required,
                )
            )

        return params or None

    def _extract_response_schema(self, src: str, pos: int) -> list[SchemaField] | None:
        """
        Extract response schema from:
        1. response_model=...
        2. top-level keys in returned dict
        """
        ctx = src[pos: pos + 3000]

        # response_model=SomeModel
        m = re.search(r"response_model\s*=\s*(\w+)", ctx)
        if m:
            return [
                SchemaField(
                    name="body",
                    type=m.group(1),
                    required=True,
                    description=None,
                )
            ]
        
                # ── Single-line return dict: return {"key": "value"} ──────────────
        single_line = re.search(r"return\s*\{([^{}]+)\}", ctx)
        if single_line:
            fields = []
            for key_match in re.finditer(r'["\']([\w_]+)["\']\s*:\s*([^,}]+)', single_line.group(1)):
                name = key_match.group(1)
                value = key_match.group(2).strip().strip('"\'')
                if value in ("True", "False") or value.lower() in ("true", "false"):
                    inferred = "boolean"
                elif value.lstrip("-").isdigit():
                    inferred = "integer"
                elif value == "None":
                    inferred = "null"
                else:
                    inferred = "string"
                fields.append(SchemaField(name=name, type=inferred, required=True, description=None))
            if fields:
                return fields

        # ── Multi-line return dict ────────────────────────────────────────
        # Limit scan to current function only — stop at next decorator
        next_decorator = re.search(r"\n@(?:app|router)\.", ctx)
        scan_limit = next_decorator.start() if next_decorator else len(ctx)
        ctx_limited = ctx[:scan_limit]

        # fallback: capture first return { ... }
        # Match multi-line return dict — closing } may be on same or different line
        ret = re.search(r"return\s*\{(.*?)(?:\n\s*\}|\})", ctx, re.DOTALL)
        if not ret:
            return None

        fields: list[SchemaField] = []
        return_body = ret.group(1)

        for key_match in re.finditer(
            r'["\']([\w_]+)["\']\s*:\s*([^,\n]+)', return_body
        ):
            name = key_match.group(1)
            value = key_match.group(2).strip().rstrip(",").strip()

            # Only infer from actual literals visible in the source code.
            # Never guess from variable names — that is project-specific.
            if value.startswith('"') or value.startswith("'"):
                inferred = "string"
            elif value in ("True", "False"):
                inferred = "boolean"
            elif value.lstrip("-").isdigit():
                inferred = "integer"
            elif re.match(r"^-?\d+\.\d+$", value):
                inferred = "float"
            elif value.startswith("{"):
                inferred = "object"
            elif value.startswith("["):
                inferred = "array"
            elif value == "None":
                inferred = "null"
            else:
                # Variable reference — type cannot be determined statically.
                # Agent must use read_file to find the actual type.
                inferred = "unknown"

            fields.append(
                SchemaField(
                    name=name,
                    type=inferred,
                    required=True,
                    description=None,
                )
            )

        return fields or None

    @staticmethod
    def _categorise(file_path: str, added: list[ApiEndpoint], removed: list[ApiEndpoint]) -> dict:
        new_eps: list[ApiEndpoint] = []
        modified: list[ModifiedEndpoint] = []
        removed_eps: list[ApiEndpoint] = []
        auth_changes: list[AuthChange] = []

        for ep in added:
            prev = next((r for r in removed if r.path == ep.path and r.method == ep.method), None)
            if prev:
                change_type = "request-schema"

                before_auth = prev.auth.type if prev.auth else "none"
                after_auth = ep.auth.type if ep.auth else "none"

                if before_auth != after_auth:
                    change_type = "auth"
                    auth_changes.append(
                        AuthChange(
                            file=file_path,
                            type="modified",
                            description=f"{ep.method} {ep.path} auth changed: {before_auth} -> {after_auth}",
                        )
                    )

                modified.append(
                    ModifiedEndpoint(
                        before=prev,
                        after=ep,
                        change_type=change_type,
                    )
                )
            else:
                new_eps.append(ep)

        for ep in removed:
            if not any(a.path == ep.path and a.method == ep.method for a in added):
                removed_eps.append(ep)

        return {
            "new": new_eps,
            "modified": modified,
            "removed": removed_eps,
            "contract_changes": [],
            "auth_changes": auth_changes,
            "versioning_changes": [],
        }
    
    @staticmethod
    def _changed_line_numbers(diff: str) -> tuple[set[int], set[int]]:
        """Return (old_line_numbers, new_line_numbers) that changed."""
        old_lines: set[int] = set()
        new_lines: set[int] = set()
        old_lineno = 0
        new_lineno = 0

        for line in diff.split("\n"):
            hunk = re.match(r"^@@ -(\d+)(?:,\d+)? \+(\d+)(?:,\d+)? @@", line)
            if hunk:
                old_lineno = int(hunk.group(1))
                new_lineno = int(hunk.group(2))
                continue
            if line.startswith("+++") or line.startswith("---"):
                continue
            if line.startswith("+"):
                new_lines.add(new_lineno)
                new_lineno += 1
            elif line.startswith("-"):
                old_lines.add(old_lineno)
                old_lineno += 1
            else:
                old_lineno += 1
                new_lineno += 1

        return old_lines, new_lines

    def _build_route_spans(
        self, full_content: str
    ) -> list[tuple[tuple[int, int], "ApiEndpoint"]]:
        """Return [(start_line, end_line), endpoint] for every route in the file.

        Line numbers are 1-based. end_line is the line before the next decorator
        (or end of file). This lets us map any changed line back to its owning route.
        """
        file_lines = full_content.split("\n")
        spans: list[tuple[tuple[int, int], ApiEndpoint]] = []

        decorator_positions: list[tuple[int, int, str, str]] = []
        char_offset = 0
        for i, line in enumerate(file_lines, start=1):
            m = ROUTE_PATTERN.search(line)
            if m:
                decorator_positions.append((i, char_offset + m.start(), m.group(1).upper(), m.group(2)))
            char_offset += len(line) + 1

        for idx, (lineno, fc_pos, method, path) in enumerate(decorator_positions):
            end_line = (
                decorator_positions[idx + 1][0] - 1
                if idx + 1 < len(decorator_positions)
                else len(file_lines)
            )
            ep = ApiEndpoint(
                method=method,
                path=path,
                handler=self._extract_handler_name(full_content, fc_pos),
                request_schema=self._extract_request_schema(full_content, fc_pos),
                response_schema=self._extract_response_schema(full_content, fc_pos),
                params=self._extract_path_params(path),
                query=self._extract_query_params(full_content, fc_pos),
                auth=self._detect_auth(full_content, fc_pos),
            )
            spans.append(((lineno, end_line), ep))

        return spans

    def _routes_with_body_changes(
        self, diff: str, full_content: str, prev_content: str | None = None
    ) -> list[ApiEndpoint]:
        old_lines, new_lines = self._changed_line_numbers(diff)

        if not old_lines and not new_lines:
            return []

        affected: list[ApiEndpoint] = []
        seen: set[tuple[str, str]] = set()

        # ── Check removed lines against prev_content ──────────────────────────
        # Removed lines map to the OLD file — use prev_content for span lookup
        if old_lines and prev_content:
            prev_file_lines = prev_content.split("\n")
            meaningful_old = {
                ln for ln in old_lines
                if ln <= len(prev_file_lines) and prev_file_lines[ln - 1].strip()
            }
            if meaningful_old:
                prev_spans = self._build_route_spans(prev_content)
                for lineno in meaningful_old:
                    for (start, end), ep in prev_spans:
                        if start <= lineno <= end:
                            key = (ep.method, ep.path)
                            if key not in seen:
                                seen.add(key)
                                affected.append(ep)
                            break

        # ── Check added lines against current full_content ───────────────────
        # Added lines map to the NEW file — use full_content for span lookup
        if new_lines:
            curr_file_lines = full_content.split("\n")
            meaningful_new = {
                ln for ln in new_lines
                if ln <= len(curr_file_lines) and curr_file_lines[ln - 1].strip()
            }
            if meaningful_new:
                curr_spans = self._build_route_spans(full_content)
                for lineno in meaningful_new:
                    for (start, end), ep in curr_spans:
                        if start <= lineno <= end:
                            key = (ep.method, ep.path)
                            if key not in seen:
                                seen.add(key)
                                affected.append(ep)
                            break

        if not affected:
            logger.debug("[fastapi] body-change: no routes matched changed lines")

        return affected