# """Django URL pattern extractor.

# Detects:
#   - path("api/users/", views.UserListView.as_view())
#   - path("api/users/<int:pk>/", views.UserDetailView)
#   - re_path(r"^api/orders/(?P<order_id>\\d+)/$", views.order_detail)
#   - @api_view(["GET", "POST"])  (DRF function-based views)
#   - class UserViewSet(ModelViewSet)  (DRF viewsets with router.register)
#   - router.register(r"users", UserViewSet)
# """

# from __future__ import annotations

# import re

# from core.extractor.types import (
#     ApiEndpoint,
#     AuthRequirement,
#     ChangedFile,
#     ModifiedEndpoint,
# )

# # path("api/users/", ...) | path("api/users/<int:pk>/", ...)
# PATH_PATTERN = re.compile(
#     r"""(?:re_)?path\s*\(\s*[r]?['"]([^'"]+)['"]""",
#     re.IGNORECASE,
# )

# # @api_view(["GET", "POST"])
# API_VIEW_PATTERN = re.compile(
#     r"@api_view\s*\(\s*\[([^\]]+)\]",
#     re.IGNORECASE,
# )

# # router.register(r"users", UserViewSet)
# ROUTER_REGISTER_PATTERN = re.compile(
#     r"router\s*\.\s*register\s*\(\s*[r]?['\"]([^'\"]+)['\"]",
#     re.IGNORECASE,
# )

# # class UserViewSet(ModelViewSet) | class UserView(APIView)
# DRF_CLASS_PATTERN = re.compile(
#     r"class\s+(\w+)\s*\(.*(?:ViewSet|APIView|GenericAPIView|ModelViewSet|ReadOnlyModelViewSet|CreateAPIView|ListAPIView|RetrieveAPIView|UpdateAPIView|DestroyAPIView)",
#     re.IGNORECASE,
# )

# # HTTP method decorators: @action(detail=True, methods=["post"])
# ACTION_PATTERN = re.compile(
#     r"@action\s*\(([^)]+)\)",
#     re.IGNORECASE | re.DOTALL,
# )

# URLPATTERNS_METHODS = {
#     "List": ["GET"],
#     "Create": ["POST"],
#     "Retrieve": ["GET"],
#     "Update": ["PUT", "PATCH"],
#     "Destroy": ["DELETE"],
#     "ListCreate": ["GET", "POST"],
#     "RetrieveUpdate": ["GET", "PUT", "PATCH"],
#     "RetrieveDestroy": ["GET", "DELETE"],
#     "RetrieveUpdateDestroy": ["GET", "PUT", "PATCH", "DELETE"],
# }


# class DjangoExtractor:
#     def detect(self, files: list[ChangedFile]) -> list[ChangedFile]:
#         return [
#             f
#             for f in files
#             if f.path.endswith(".py") and self._looks_like_django(f.diff + (f.content or ""))
#         ]

#     def extract(self, file: ChangedFile, full_content: str) -> dict:
#         added = self._parse_routes(self._diff_lines(file.diff, "+"), full_content)
#         removed = self._parse_routes(self._diff_lines(file.diff, "-"), "")
#         return self._categorise(added, removed)

#     # ─── Private helpers ─────────────────────────────────────────────────────

#     @staticmethod
#     def _looks_like_django(src: str) -> bool:
#         return bool(
#             re.search(
#                 r"from\s+django|from\s+rest_framework|urlpatterns|@api_view"
#                 r"|ViewSet|APIView|router\.register|@action",
#                 src,
#                 re.IGNORECASE,
#             )
#         )

#     @staticmethod
#     def _diff_lines(diff: str, marker: str) -> str:
#         triple = marker * 3
#         return "\n".join(
#             line[1:] for line in diff.split("\n") if line.startswith(marker) and not line.startswith(triple)
#         )

#     def _parse_routes(self, src: str, full_content: str) -> list[ApiEndpoint]:
#         results: list[ApiEndpoint] = []

#         # Build function_name → actual_path map from urlpatterns
#         urlpatterns_map = self._extract_urlpatterns_paths(full_content)

#         # 1) @action(detail=False, methods=['get'], url_path='get-events')
#         results.extend(self._extract_action_endpoints(src, full_content, urlpatterns_map))

#         # 2) @api_view(["GET", "POST"]) — DRF function-based views
#         # AFTER
#         for m in API_VIEW_PATTERN.finditer(src):
#             methods_str = m.group(1)
#             methods = [s.strip().strip("'\"").upper() for s in methods_str.split(",")]
#             func_name = self._find_function_after(src, m.end())
#             path = urlpatterns_map.get(func_name, f"/{func_name}/") # type: ignore

#             # Find auth by locating function body in full_content
#             if func_name and full_content:
#                 func_pos = full_content.find(f"def {func_name}")
#                 if func_pos >= 0:
#                     # Read 600 chars of function body to find auth checks
#                     auth = self._detect_auth_in_function(full_content, func_pos)
#                 else:
#                     auth = self._detect_auth(full_content, m.start())
#             else:
#                 auth = self._detect_auth(full_content or src, m.start())

#             for method in methods:
#                 if method in ("GET", "POST", "PUT", "PATCH", "DELETE", "HEAD", "OPTIONS"):
#                     results.append(ApiEndpoint(method=method, path=path, handler=func_name, auth=auth))

#         # 3) path() / re_path() entries (skip include() and admin paths)
#         for m in PATH_PATTERN.finditer(src):
#             raw_path = m.group(1)
#             context = src[m.start(): m.start() + 100]
#             if "include(" in context:
#                 continue
#             if raw_path.startswith("admin/") or raw_path.startswith(".well-known"):
#                 continue
#             path = self._normalise_path(raw_path)
#             methods = self._infer_methods_from_context(src, m.start())
#             auth = self._detect_auth(full_content or src, m.start())
#             if methods:
#                 for method in methods:
#                     results.append(ApiEndpoint(method=method, path=path, auth=auth))

#         # 4) router.register(r"users", UserViewSet)
#         for m in ROUTER_REGISTER_PATTERN.finditer(src):
#             prefix = m.group(1).strip("/")
#             path = f"/api/{prefix}/" if prefix else "/api/"
#             auth = self._detect_auth(full_content or src, m.start())
#             for method in ("GET", "POST"):
#                 results.append(ApiEndpoint(method=method, path=path, auth=auth))
#             results.append(ApiEndpoint(method="GET", path=f"{path}{{id}}/", auth=auth))
#             results.append(ApiEndpoint(method="PUT", path=f"{path}{{id}}/", auth=auth))
#             results.append(ApiEndpoint(method="DELETE", path=f"{path}{{id}}/", auth=auth))

#         return results
    
#     # ADD THESE 3 NEW METHODS

#     def _extract_action_endpoints(
#         self,
#         src: str,
#         full_content: str,
#         urlpatterns_map: dict[str, str],
#     ) -> list[ApiEndpoint]:
#         """Extract endpoints from @action decorators in ViewSet classes."""
#         results: list[ApiEndpoint] = []
#         viewset_prefix = self._extract_viewset_prefix(full_content)

#         for m in ACTION_PATTERN.finditer(src):
#             action_args = m.group(1)

#             # Extract methods=['get', 'post']
#             methods_match = re.search(
#                 r"methods\s*=\s*\[([^\]]+)\]", action_args, re.IGNORECASE
#             )
#             if not methods_match:
#                 continue
#             methods = [
#                 s.strip().strip("'\"").upper()
#                 for s in methods_match.group(1).split(",")
#             ]

#             # Extract url_path='get-events'
#             url_path_match = re.search(
#                 r"url_path\s*=\s*['\"]([^'\"]+)['\"]", action_args, re.IGNORECASE
#             )
#             url_path = url_path_match.group(1) if url_path_match else None

#             # Extract detail=True/False
#             detail_match = re.search(
#                 r"detail\s*=\s*(True|False)", action_args, re.IGNORECASE
#             )
#             is_detail = detail_match and detail_match.group(1).lower() == "true"

#             # Find function name after decorator
#             func_name = self._find_function_after(src, m.end())

#             # Build full path
#             if url_path:
#                 if is_detail:
#                     path = f"{viewset_prefix}{{pk}}/{url_path}/"
#                 else:
#                     path = f"{viewset_prefix}{url_path}/"
#             elif func_name:
#                 path = f"{viewset_prefix}{func_name.replace('_', '-')}/"
#             else:
#                 continue

#             # Detect auth from surrounding context
#             ctx = src[max(0, m.start() - 50): m.end() + 800]

#             auth = self._detect_auth_from_decorators(ctx)

#             for method in methods:
#                 if method in ("GET", "POST", "PUT", "PATCH", "DELETE"):
#                     results.append(ApiEndpoint(
#                         method=method,
#                         path=self._normalise_path(path),
#                         handler=func_name,
#                         auth=auth,
#                     ))

#         return results

#     def _extract_viewset_prefix(self, full_content: str) -> str:
#         """Extract the URL prefix for a ViewSet from router or include patterns."""
#         # router.register(r"events", EventViewSet) → /api/events/
#         router_match = re.search(
#             r"router\s*\.\s*register\s*\(\s*[r]?['\"]([^'\"]+)['\"]",
#             full_content,
#             re.IGNORECASE,
#         )
#         if router_match:
#             prefix = router_match.group(1).strip("/")
#             return f"/api/{prefix}/"

#         # path('api/v1/events/', include('events.urls')) → /api/v1/events/
#         include_match = re.search(
#             r"""path\s*\(\s*[r]?['"]([^'"]+)['"]\s*,\s*include""",
#             full_content,
#             re.IGNORECASE,
#         )
#         if include_match:
#             return f"/{include_match.group(1).strip('/')}/"

#         return "/api/"

#     def _extract_urlpatterns_paths(self, full_content: str) -> dict[str, str]:
#         """Map function_name → URL path from urlpatterns block."""
#         mapping = {}
#         pattern = re.compile(
#             r"""path\s*\(\s*[r]?['"]([^'"]+)['"]\s*,\s*(\w+)""",
#             re.IGNORECASE,
#         )
#         for m in pattern.finditer(full_content):
#             url_path = self._normalise_path(m.group(1))
#             func_name = m.group(2)
#             mapping[func_name] = url_path
#         return mapping

#     @staticmethod
#     def _normalise_path(raw: str) -> str:
#         path = raw.strip("/")
#         path = re.sub(r"\(\?P<(\w+)>[^)]+\)", r"{\1}", path)
#         path = re.sub(r"<(?:\w+:)?(\w+)>", r"{\1}", path)
#         return f"/{path}/" if path else "/"

#     @staticmethod
#     def _infer_methods_from_context(src: str, pos: int) -> list[str]:
#         ctx = src[max(0, pos - 300) : pos + 300]
#         for class_suffix, methods in URLPATTERNS_METHODS.items():
#             if class_suffix in ctx:
#                 return methods
#         return []

#     @staticmethod
#     def _find_function_after(src: str, pos: int) -> str | None:
#         rest = src[pos : pos + 300]
#         m = re.search(r"def\s+(\w+)", rest)
#         return m.group(1) if m else None

#     @staticmethod
#     def _detect_auth(src: str, pos: int) -> AuthRequirement:
#         ctx = src[max(0, pos - 400) : pos + 400]
#         if re.search(
#             r"IsAuthenticated|permission_classes|IsAdminUser|TokenAuthentication"
#             r"|JWTAuthentication|validate_access|require_auth\s*=\s*True",
#             ctx, re.IGNORECASE
#         ):
#             return AuthRequirement(type="bearer")
#         if re.search(r"SessionAuthentication|login_required", ctx, re.IGNORECASE):
#             return AuthRequirement(type="basic")
#         if re.search(r"APIKey|api_key", ctx, re.IGNORECASE):
#             return AuthRequirement(type="api-key")
#         return AuthRequirement(type="none")
    
#     @staticmethod
#     def _detect_auth_from_decorators(ctx: str) -> AuthRequirement:
#         """Detect auth from @validate_access and similar decorators."""
#         if re.search(r"require_auth\s*=\s*True", ctx, re.IGNORECASE):
#             return AuthRequirement(type="bearer")
#         if re.search(r"allow_guest\s*=\s*True", ctx, re.IGNORECASE):
#             return AuthRequirement(type="none")
#         if re.search(
#             r"IsAuthenticated|JWTAuthentication|TokenAuthentication",
#             ctx, re.IGNORECASE
#         ):
#             return AuthRequirement(type="bearer")
#         return AuthRequirement(type="none")   # ← add this line

#     @staticmethod
#     def _detect_auth_in_function(full_content: str, func_pos: int) -> AuthRequirement:
#         """Detect auth by reading the function body in full_content."""
#         # Read 800 chars from function definition — covers most function bodies
#         ctx = full_content[func_pos: func_pos + 800]
#         if re.search(
#             r'headers\.get\(["\']Authorization["\']\)'
#             r'|IsAuthenticated|permission_classes|TokenAuthentication'
#             r'|JWTAuthentication|validate_access|require_auth\s*=\s*True',
#             ctx, re.IGNORECASE
#         ):
#             return AuthRequirement(type="bearer")
#         if re.search(r"SessionAuthentication|login_required", ctx, re.IGNORECASE):
#             return AuthRequirement(type="basic")
#         if re.search(r"APIKey|api_key", ctx, re.IGNORECASE):
#             return AuthRequirement(type="api-key")
#         return AuthRequirement(type="none")

#     @staticmethod
#     def _categorise(added: list[ApiEndpoint], removed: list[ApiEndpoint]) -> dict:
#         new_eps: list[ApiEndpoint] = []
#         modified: list[ModifiedEndpoint] = []
#         removed_eps: list[ApiEndpoint] = []

#         for ep in added:
#             prev = next((r for r in removed if r.path == ep.path and r.method == ep.method), None)
#             if prev:
#                 modified.append(ModifiedEndpoint(before=prev, after=ep, change_type="request-schema"))
#             else:
#                 new_eps.append(ep)

#         for ep in removed:
#             if not any(a.path == ep.path and a.method == ep.method for a in added):
#                 removed_eps.append(ep)

#         return {
#             "new": new_eps,
#             "modified": modified,
#             "removed": removed_eps,
#             "contract_changes": [],
#             "auth_changes": [],
#             "versioning_changes": [],
#         }

"""Django URL pattern extractor — improved for ViewSet-heavy codebases.

Detects:
  - @action(detail=False/True, methods=[...], url_path='...') on ViewSet methods
  - @validate_access(require_auth=True/False) stacked on action methods
  - Multiple ViewSet classes per file, each with its own URL prefix
  - Class name → URL prefix inference when no router.register is present
  - @api_view(["GET", "POST"]) DRF function-based views
  - path() / re_path() urlpatterns
  - router.register(r"prefix", ViewSetClass) explicit mappings
"""

from __future__ import annotations

import re

from core.extractor.types import (
    ApiEndpoint,
    AuthRequirement,
    ChangedFile,
    ModifiedEndpoint,
)

# ── Compiled patterns ─────────────────────────────────────────────────────────

PATH_PATTERN = re.compile(
    r"""(?:re_)?path\s*\(\s*[r]?['"]([^'"]+)['"]""",
    re.IGNORECASE,
)

API_VIEW_PATTERN = re.compile(
    r"@api_view\s*\(\s*\[([^\]]+)\]",
    re.IGNORECASE,
)

ROUTER_REGISTER_PATTERN = re.compile(
    r"router\s*\.\s*register\s*\(\s*[r]?['\"]([^'\"]+)['\"]\s*,\s*(\w+)",
    re.IGNORECASE,
)

DRF_CLASS_PATTERN = re.compile(
    r"^class\s+(\w+)\s*\([^)]*(?:ViewSet|APIView|GenericAPIView|ModelViewSet"
    r"|ReadOnlyModelViewSet|CreateAPIView|ListAPIView|RetrieveAPIView"
    r"|UpdateAPIView|DestroyAPIView)[^)]*\)\s*:",
    re.IGNORECASE | re.MULTILINE,
)

ACTION_PATTERN = re.compile(
    r"@action\s*\(([^)]+)\)",
    re.IGNORECASE | re.DOTALL,
)

# @validate_access(require_auth=True) or @validate_access(allow_guest=True)
VALIDATE_ACCESS_PATTERN = re.compile(
    r"@validate_access\s*\(([^)]*)\)",
    re.IGNORECASE | re.DOTALL,
)

URLPATTERNS_METHODS = {
    "List": ["GET"],
    "Create": ["POST"],
    "Retrieve": ["GET"],
    "Update": ["PUT", "PATCH"],
    "Destroy": ["DELETE"],
    "ListCreate": ["GET", "POST"],
    "RetrieveUpdate": ["GET", "PUT", "PATCH"],
    "RetrieveDestroy": ["GET", "DELETE"],
    "RetrieveUpdateDestroy": ["GET", "PUT", "PATCH", "DELETE"],
}


class DjangoExtractor:
    def detect(self, files: list[ChangedFile]) -> list[ChangedFile]:
        return [
            f for f in files
            if f.path.endswith(".py") and self._looks_like_django(f.diff + (f.content or ""))
        ]

    def extract(self, file: ChangedFile, full_content: str) -> dict:
        added = self._parse_routes(self._diff_lines(file.diff, "+"), full_content)
        removed = self._parse_routes(self._diff_lines(file.diff, "-"), "")
        return self._categorise(added, removed)

    # ─── Private helpers ──────────────────────────────────────────────────────

    @staticmethod
    def _looks_like_django(src: str) -> bool:
        # Strip diff markers (+/-) before scanning — raw diffs prefix every line
        clean = re.sub(r"^[+\-]", "", src, flags=re.MULTILINE)
        return bool(re.search(
            r"from\s+django|from\s+rest_framework|urlpatterns|@api_view"
            r"|ViewSet|APIView|router\.register|@action",
            clean, re.IGNORECASE,
        ))

    @staticmethod
    def _diff_lines(diff: str, marker: str) -> str:
        triple = marker * 3
        return "\n".join(
            line[1:] for line in diff.split("\n")
            if line.startswith(marker) and not line.startswith(triple)
        )

    def _parse_routes(self, src: str, full_content: str) -> list[ApiEndpoint]:
        results: list[ApiEndpoint] = []
        urlpatterns_map = self._extract_urlpatterns_paths(full_content)

        # ── 1. @action endpoints (primary path for ViewSet files) ─────────────
        results.extend(
            self._extract_action_endpoints(src, full_content, urlpatterns_map)
        )

        # ── 2. @api_view function-based views ─────────────────────────────────
        for m in API_VIEW_PATTERN.finditer(src):
            methods_str = m.group(1)
            methods = [s.strip().strip("'\"").upper() for s in methods_str.split(",")]
            func_name = self._find_function_after(src, m.end())
            path = urlpatterns_map.get(func_name, f"/{func_name}/")  # type: ignore

            if func_name and full_content:
                func_pos = full_content.find(f"def {func_name}")
                auth = (
                    self._detect_auth_in_function(full_content, func_pos)
                    if func_pos >= 0
                    else self._detect_auth(full_content, m.start())
                )
            else:
                auth = self._detect_auth(full_content or src, m.start())

            for method in methods:
                if method in ("GET", "POST", "PUT", "PATCH", "DELETE", "HEAD", "OPTIONS"):
                    results.append(ApiEndpoint(method=method, path=path, handler=func_name, auth=auth))

        # ── 3. path() / re_path() entries ─────────────────────────────────────
        for m in PATH_PATTERN.finditer(src):
            raw_path = m.group(1)
            context = src[m.start(): m.start() + 100]
            if "include(" in context:
                continue
            if raw_path.startswith("admin/") or raw_path.startswith(".well-known"):
                continue
            path = self._normalise_path(raw_path)
            methods = self._infer_methods_from_context(src, m.start())
            auth = self._detect_auth(full_content or src, m.start())
            for method in methods:
                results.append(ApiEndpoint(method=method, path=path, auth=auth))

        # ── 4. router.register() ──────────────────────────────────────────────
        # Only add generic CRUD routes when no @action endpoints were found
        if not results:
            for m in ROUTER_REGISTER_PATTERN.finditer(src):
                prefix = m.group(1).strip("/")
                path = f"/api/{prefix}/"
                auth = self._detect_auth(full_content or src, m.start())
                for method in ("GET", "POST"):
                    results.append(ApiEndpoint(method=method, path=path, auth=auth))
                results.append(ApiEndpoint(method="GET", path=f"{path}{{id}}/", auth=auth))
                results.append(ApiEndpoint(method="PUT", path=f"{path}{{id}}/", auth=auth))
                results.append(ApiEndpoint(method="DELETE", path=f"{path}{{id}}/", auth=auth))

        return results

    # ─── @action extraction ───────────────────────────────────────────────────

    def _extract_action_endpoints(
        self,
        src: str,
        full_content: str,
        urlpatterns_map: dict[str, str],
    ) -> list[ApiEndpoint]:
        """
        Extract all @action endpoints, grouped by their enclosing ViewSet class.

        For each ViewSet class found in the diff src (or full_content fallback),
        we derive the URL prefix from:
          1. router.register() explicit mapping in full_content
          2. Class name → slug inference (NotificationMasterViewSet → /api/notification-master/)
        """
        results: list[ApiEndpoint] = []

        # Build class_name → url_prefix map from the whole file
        class_prefix_map = self._build_class_prefix_map(full_content or src)

        # Find all @action decorators in the diff src
        for m in ACTION_PATTERN.finditer(src):
            action_args = m.group(1)
            action_end = m.end()

            # ── Extract methods=['get', 'post'] ───────────────────────────────
            methods_match = re.search(
                r"methods\s*=\s*\[([^\]]+)\]", action_args, re.IGNORECASE
            )
            if not methods_match:
                continue
            methods = [
                s.strip().strip("'\"").upper()
                for s in methods_match.group(1).split(",")
            ]

            # ── Extract url_path='...' ────────────────────────────────────────
            url_path_match = re.search(
                r"url_path\s*=\s*['\"]([^'\"]+)['\"]", action_args, re.IGNORECASE
            )
            url_path = url_path_match.group(1) if url_path_match else None

            # ── Extract detail=True/False ─────────────────────────────────────
            detail_match = re.search(
                r"detail\s*=\s*(True|False)", action_args, re.IGNORECASE
            )
            is_detail = bool(detail_match and detail_match.group(1).lower() == "true")

            # ── Find function name immediately after @action(...) ─────────────
            # Skip any stacked decorators (@validate_access etc.) to get to def
            func_name = self._find_function_after_decorators(src, action_end)

            # ── Find which ViewSet class this action belongs to ───────────────
            class_name = self._find_enclosing_class(src, m.start(), full_content)
            prefix = class_prefix_map.get(class_name, self._class_name_to_prefix(class_name))

            # ── Detect auth ───────────────────────────────────────────────────
            # Read the block between @action and def (covers stacked decorators)
            block_after_action = src[action_end: action_end + 400]
            auth = self._detect_auth_from_block(block_after_action, full_content or src, m.start())

            # ── Build path ────────────────────────────────────────────────────
            action_segment = url_path or (func_name.replace("_", "-") if func_name else "action")
            if is_detail:
                path = f"{prefix}{{pk}}/{action_segment}/"
            else:
                path = f"{prefix}{action_segment}/"

            for method in methods:
                if method in ("GET", "POST", "PUT", "PATCH", "DELETE"):
                    results.append(ApiEndpoint(
                        method=method,
                        path=self._normalise_path(path),
                        handler=func_name,
                        auth=auth,
                    ))

        return results

    # ─── Class → prefix mapping ───────────────────────────────────────────────

    def _build_class_prefix_map(self, full_content: str) -> dict[str, str]:
        """
        Build {ClassName: url_prefix} from:
          1. Explicit router.register(r"prefix", ClassName) entries
          2. Class name → slug inference as fallback
        """
        mapping: dict[str, str] = {}

        # Explicit router.register mappings
        for m in ROUTER_REGISTER_PATTERN.finditer(full_content):
            prefix = m.group(1).strip("/")
            class_name = m.group(2)
            mapping[class_name] = f"/api/{prefix}/"

        # For every ViewSet class not covered by router.register, infer from name
        for m in DRF_CLASS_PATTERN.finditer(full_content):
            class_name = m.group(1)
            if class_name not in mapping:
                mapping[class_name] = self._class_name_to_prefix(class_name)

        return mapping

    @staticmethod
    def _class_name_to_prefix(class_name: str) -> str:
        """
        Convert ViewSet class name to URL prefix slug.

        Examples:
          NotificationMasterViewSet   → /api/notification-master/
          FCMDeviceViewSet            → /api/fcm-device/
          NotificationViewSet         → /api/notification/
          NotificationIntervalViewSet → /api/notification-interval/
          UserAPIView                 → /api/user/
        """
        if not class_name:
            return "/api/"

        # Strip trailing ViewSet/View/APIView
        name = re.sub(r"(ViewSet|APIView|View)$", "", class_name, flags=re.IGNORECASE)

        # CamelCase → kebab, handling consecutive capitals (FCM, API, etc.)
        # Step 1: insert hyphen between lowercase/digit and uppercase  (deviceId → device-Id)
        slug = re.sub(r"([a-z0-9])([A-Z])", r"\1-\2", name)
        # Step 2: insert hyphen between a run of caps and a cap+lower  (FCMDevice → FCM-Device)
        slug = re.sub(r"([A-Z]+)([A-Z][a-z])", r"\1-\2", slug)
        slug = slug.lower().strip("-")
        slug = re.sub(r"-+", "-", slug)

        return f"/api/{slug}/"

    # ─── Auth detection ───────────────────────────────────────────────────────

    def _detect_auth_from_block(
        self, block: str, full_content: str, fallback_pos: int
    ) -> AuthRequirement:
        """
        Detect auth by checking (in order):
          1. @validate_access is commented out → none
          2. @validate_access(require_auth=True/False) active → bearer/none
          3. Standard DRF permission patterns in surrounding context
        """
        # Check commented-out FIRST — before running the regex
        # so that # @validate_access(require_auth=True) is not matched as active
        if re.search(r"#\s*@validate_access", block, re.IGNORECASE):
            return AuthRequirement(type="none")

        # Strip all comment lines then search for active @validate_access
        clean_block = "\n".join(
            line for line in block.split("\n")
            if not line.strip().startswith("#")
        )
        va_match = VALIDATE_ACCESS_PATTERN.search(clean_block)
        if va_match:
            args = va_match.group(1)
            if re.search(r"require_auth\s*=\s*True", args, re.IGNORECASE):
                return AuthRequirement(type="bearer")
            if re.search(r"allow_guest\s*=\s*True", args, re.IGNORECASE):
                return AuthRequirement(type="none")
            # @validate_access() with no args — treat as bearer
            return AuthRequirement(type="bearer")

        # Fall back to scanning surrounding context in full_content
        return self._detect_auth(full_content, fallback_pos)

    @staticmethod
    def _detect_auth(src: str, pos: int) -> AuthRequirement:
        ctx = src[max(0, pos - 400): pos + 400]
        if re.search(
            r"IsAuthenticated|permission_classes|IsAdminUser|TokenAuthentication"
            r"|JWTAuthentication|validate_access|require_auth\s*=\s*True",
            ctx, re.IGNORECASE,
        ):
            return AuthRequirement(type="bearer")
        if re.search(r"SessionAuthentication|login_required", ctx, re.IGNORECASE):
            return AuthRequirement(type="basic")
        if re.search(r"APIKey|api_key", ctx, re.IGNORECASE):
            return AuthRequirement(type="api-key")
        return AuthRequirement(type="none")

    @staticmethod
    def _detect_auth_in_function(full_content: str, func_pos: int) -> AuthRequirement:
        ctx = full_content[func_pos: func_pos + 800]
        if re.search(
            r'headers\.get\(["\']Authorization["\']\)'
            r"|IsAuthenticated|permission_classes|TokenAuthentication"
            r"|JWTAuthentication|validate_access|require_auth\s*=\s*True",
            ctx, re.IGNORECASE,
        ):
            return AuthRequirement(type="bearer")
        if re.search(r"SessionAuthentication|login_required", ctx, re.IGNORECASE):
            return AuthRequirement(type="basic")
        if re.search(r"APIKey|api_key", ctx, re.IGNORECASE):
            return AuthRequirement(type="api-key")
        return AuthRequirement(type="none")

    # ─── Utility helpers ──────────────────────────────────────────────────────

    @staticmethod
    def _find_function_after(src: str, pos: int) -> str | None:
        rest = src[pos: pos + 300]
        m = re.search(r"def\s+(\w+)", rest)
        return m.group(1) if m else None

    @staticmethod
    def _find_function_after_decorators(src: str, pos: int) -> str | None:
        """
        Find the def name after @action, skipping any stacked decorators.
        Handles:
            @action(...)
            @validate_access(require_auth=True)
            def my_function(self, request):
        """
        rest = src[pos: pos + 600]
        m = re.search(r"def\s+(\w+)", rest)
        return m.group(1) if m else None

    @staticmethod
    def _find_enclosing_class(src: str, action_pos: int, full_content: str) -> str:
        """
        Find which ViewSet class an @action at action_pos belongs to.

        Strategy: scan backwards in src from action_pos for the nearest
        'class Xxx(...)' definition. If not found in src (diff only contains
        the method, not the class header), scan full_content using the
        function name as anchor.
        """
        # Scan backwards in src
        text_before = src[:action_pos]
        class_matches = list(DRF_CLASS_PATTERN.finditer(text_before))
        if class_matches:
            return class_matches[-1].group(1)

        # Fallback: scan full_content — find the function def that follows this
        # action, then find which class it belongs to in the full file
        func_match = re.search(r"def\s+(\w+)", src[action_pos: action_pos + 600])
        if func_match and full_content:
            func_name = func_match.group(1)
            # Find the function in full_content
            func_pos = full_content.find(f"def {func_name}")
            if func_pos >= 0:
                text_before_full = full_content[:func_pos]
                class_matches_full = list(DRF_CLASS_PATTERN.finditer(text_before_full))
                if class_matches_full:
                    return class_matches_full[-1].group(1)

        return ""

    @staticmethod
    def _extract_urlpatterns_paths(full_content: str) -> dict[str, str]:
        mapping = {}
        pattern = re.compile(
            r"""path\s*\(\s*[r]?['"]([^'"]+)['"]\s*,\s*(\w+)""",
            re.IGNORECASE,
        )
        for m in pattern.finditer(full_content):
            url_path = DjangoExtractor._normalise_path(m.group(1))
            func_name = m.group(2)
            mapping[func_name] = url_path
        return mapping

    @staticmethod
    def _normalise_path(raw: str) -> str:
        path = raw.strip("/")
        path = re.sub(r"\(\?P<(\w+)>[^)]+\)", r"{\1}", path)
        path = re.sub(r"<(?:\w+:)?(\w+)>", r"{\1}", path)
        return f"/{path}/" if path else "/"

    @staticmethod
    def _infer_methods_from_context(src: str, pos: int) -> list[str]:
        ctx = src[max(0, pos - 300): pos + 300]
        for class_suffix, methods in URLPATTERNS_METHODS.items():
            if class_suffix in ctx:
                return methods
        return []

    @staticmethod
    def _categorise(added: list[ApiEndpoint], removed: list[ApiEndpoint]) -> dict:
        new_eps: list[ApiEndpoint] = []
        modified: list[ModifiedEndpoint] = []
        removed_eps: list[ApiEndpoint] = []

        for ep in added:
            prev = next(
                (r for r in removed if r.path == ep.path and r.method == ep.method), None
            )
            if prev:
                modified.append(ModifiedEndpoint(before=prev, after=ep, change_type="request-schema"))
            else:
                new_eps.append(ep)

        for ep in removed:
            if not any(a.path == ep.path and a.method == ep.method for a in added):
                removed_eps.append(ep)

        return {
            "new": new_eps,
            "modified": modified,
            "removed": removed_eps,
            "contract_changes": [],
            "auth_changes": [],
            "versioning_changes": [],
        }