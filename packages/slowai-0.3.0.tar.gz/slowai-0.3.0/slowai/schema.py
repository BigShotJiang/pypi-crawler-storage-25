"""
slowai.schema — the product thesis, in type form.

Every deep learning workload lives in exactly one of three performance
regimes (Horace He, "Making Deep Learning Go Brrrr From First Principles").
The fix for each regime is different — applying a compute-bound fix to an
overhead-bound workload makes nothing faster.

Diagnosis has to come before prescription. This file defines what a
diagnosis looks like.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from enum import Enum


class Regime(str, Enum):
    """The performance regime a workload is stuck in."""

    COMPUTE_BOUND = "compute"
    """GPU is saturated doing math. Matrix multiplies dominate.
    Fix = different math (smaller model, tensor cores, better algorithms)."""

    MEMORY_BOUND = "memory"
    """GPU is waiting for data. Pointwise ops dominate, FLOP usage is low.
    Fix = less data movement (fusion, fp16/bf16, better data layout)."""

    OVERHEAD_BOUND = "overhead"
    """GPU is idle waiting for Python/dispatcher. Lots of tiny ops, idle gaps.
    Fix = fewer, bigger ops (torch.compile, larger batches, op fusion)."""

    UNKNOWN = "unknown"
    """Classifier could not confidently pick a regime. Evidence is ambiguous."""


@dataclass
class Diagnosis:
    """A single diagnosis output from `slowai diagnose <workload>`.

    Attributes:
        workload: Path or name of the script/module that was profiled.
        regime: Which performance regime the classifier picked.
        confidence: Model confidence in the regime call, in [0.0, 1.0].
        evidence: Raw signals the classifier used. At minimum:
            - gpu_utilization: fraction of wall time the GPU was busy
            - dispatch_to_kernel: fraction of time in Python dispatch vs GPU work
            - memory_bandwidth_used: fraction of peak memory bandwidth used
        top_fixes: Ranked list of recommended fixes (filled in Phase 2).
            Empty list in Phase 1 — diagnose only, no prescriptions.
    """

    workload: str
    regime: Regime
    confidence: float
    evidence: dict[str, float]
    top_fixes: list[str] = field(default_factory=list)

    def __post_init__(self) -> None:
        if not 0.0 <= self.confidence <= 1.0:
            raise ValueError(
                f"confidence must be in [0.0, 1.0], got {self.confidence}"
            )

    def summary(self) -> str:
        """One-line human summary. Used by the CLI."""
        return (
            f"{self.workload}: {self.regime.value.upper()}_BOUND "
            f"(confidence: {self.confidence:.2f})"
        )


# Phase 1 ships when the classifier produces the correct Diagnosis.regime
# for all workloads in the curated test corpus (see tests/corpus/).
# Target: 90%+ regime accuracy before Phase 2 begins.
