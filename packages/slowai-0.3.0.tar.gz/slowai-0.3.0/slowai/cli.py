"""slowai CLI — V3.

Usage:
    slowai diagnose <workload.py>
    slowai diagnose <workload.py> --json
    slowai fix <workload.py>
    slowai fix <workload.py> --json
"""

from __future__ import annotations

import argparse
import dataclasses
import json
import sys


def _diagnosis_to_dict(diag) -> dict:
    """Flatten a Diagnosis into plain dicts/lists for JSON output."""
    d = dataclasses.asdict(diag)
    # Regime is a str Enum — asdict leaves it as the value already,
    # but be defensive in case of subclassing.
    if hasattr(diag.regime, "value"):
        d["regime"] = diag.regime.value
    return d


def _cmd_diagnose(args) -> int:
    # Lazy imports so `slowai --help` works without torch installed.
    from slowai.diagnose import classify
    from slowai.profiler import profile_workload

    try:
        result = profile_workload(args.workload)
    except FileNotFoundError as e:
        print(f"error: {e}", file=sys.stderr)
        return 2
    except Exception as e:  # noqa: BLE001
        print(f"error: failed to profile workload: {e}", file=sys.stderr)
        return 3

    diag = classify(result)

    if args.json:
        print(json.dumps(_diagnosis_to_dict(diag), indent=2, default=str))
        return 0

    # Human-readable output.
    print(diag.summary())
    print(f"  device: {result.device}")
    print(f"  wall time: {result.wall_time_s:.3f}s")
    print(f"  total ops: {result.total_op_count}")
    if result.op_stats:
        top = result.top_op
        print(f"  top op: {top.name} (x{top.count}, {top.total_us / 1000:.1f} ms total)")
    if diag.evidence:
        print("  evidence:")
        for k, v in diag.evidence.items():
            if isinstance(v, float):
                print(f"    {k}: {v:.3f}")
            else:
                print(f"    {k}: {v}")
    if diag.top_fixes:
        print("  top fixes (cheapest first):")
        for i, fix in enumerate(diag.top_fixes, 1):
            print(f"    {i}. {fix}")
    return 0


def _cmd_fix(args) -> int:
    """The V3 command: diagnose + auto-apply fixes + show before/after speedup."""
    from slowai.remediate import auto_fix

    print(f"slowai fix: profiling baseline for {args.workload} ...")
    try:
        report = auto_fix(args.workload)
    except FileNotFoundError as e:
        print(f"error: {e}", file=sys.stderr)
        return 2
    except Exception as e:  # noqa: BLE001
        print(f"error: failed to run auto-fix: {e}", file=sys.stderr)
        return 3

    bd = report.baseline_diagnosis

    if args.json:
        out = {
            "workload": report.workload,
            "baseline": _diagnosis_to_dict(bd),
            "remedies": [
                {
                    "name": r.remedy_name,
                    "description": r.remedy_description,
                    "baseline_wall_s": r.baseline_wall_s,
                    "remedied_wall_s": r.remedied_wall_s,
                    "speedup": r.speedup,
                    "regime_before": r.regime_before.value,
                    "regime_after": r.regime_after.value,
                    "confidence_after": r.confidence_after,
                    "error": r.error,
                }
                for r in report.results
            ],
            "best": report.best.remedy_name if report.best else None,
        }
        print(json.dumps(out, indent=2, default=str))
        return 0

    # Human-readable output.
    print()
    print("=" * 62)
    print(f"  BASELINE: {bd.summary()}")
    print(f"  wall time: {bd.evidence.get('wall_time_s', 0):.3f}s")
    print("=" * 62)

    if not report.results:
        print("\n  No auto-remedies available for this regime.")
        if bd.top_fixes:
            print("  Manual fixes (from `slowai diagnose`):")
            for i, fix in enumerate(bd.top_fixes, 1):
                print(f"    {i}. {fix}")
        return 0

    print(f"\n  Tried {len(report.results)} remedies:\n")

    for i, rr in enumerate(report.results, 1):
        if rr.error:
            status = "FAILED"
            detail = f"     error: {rr.error}"
        else:
            arrow = ">>>" if rr.speedup > 1.05 else "---" if rr.speedup >= 0.95 else "<<<"
            status = f"{rr.speedup:.2f}x"
            detail = (
                f"     {rr.baseline_wall_s:.3f}s {arrow} {rr.remedied_wall_s:.3f}s"
            )

        best_marker = "  ** BEST **" if report.best and rr.remedy_name == report.best.remedy_name else ""
        print(f"  {i}. [{status}] {rr.remedy_name}{best_marker}")
        print(f"     {rr.remedy_description}")
        print(detail)
        if not rr.error:
            print(f"     regime: {rr.regime_after.value} (confidence: {rr.confidence_after:.2f})")
        print()

    best = report.best
    if best:
        pct = (best.speedup - 1.0) * 100
        print("-" * 62)
        print(f"  WINNER: {best.remedy_name}")
        print(f"  {best.baseline_wall_s:.3f}s >>> {best.remedied_wall_s:.3f}s  ({best.speedup:.2f}x, +{pct:.0f}% faster)")
        print(f"  How: {best.remedy_description}")
        print("-" * 62)
    else:
        print("-" * 62)
        print("  No remedy produced a speedup. The workload may already be")
        print("  well-optimized, or the fixes require manual code changes.")
        print("  Run `slowai diagnose` for the full prescription list.")
        print("-" * 62)

    return 0


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(
        prog="slowai",
        description="Diagnose and auto-fix PyTorch performance bottlenecks.",
    )
    sub = parser.add_subparsers(dest="command", required=True)

    # --- slowai diagnose ---
    diag = sub.add_parser(
        "diagnose", help="Profile a workload and classify its regime."
    )
    diag.add_argument("workload", help="Path to the Python script to diagnose.")
    diag.add_argument(
        "--json",
        action="store_true",
        help="Emit the Diagnosis as JSON instead of human-readable text.",
    )
    diag.set_defaults(func=_cmd_diagnose)

    # --- slowai fix ---
    fix = sub.add_parser(
        "fix", help="Auto-apply fixes and show before/after speedup."
    )
    fix.add_argument("workload", help="Path to the Python script to fix.")
    fix.add_argument(
        "--json",
        action="store_true",
        help="Emit the FixReport as JSON instead of human-readable text.",
    )
    fix.set_defaults(func=_cmd_fix)

    args = parser.parse_args(argv)
    return args.func(args)


if __name__ == "__main__":
    sys.exit(main())
