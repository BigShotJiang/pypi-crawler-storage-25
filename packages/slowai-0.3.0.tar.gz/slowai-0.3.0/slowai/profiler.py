"""
slowai.profiler — run a workload under torch.profiler and collect per-op stats.

This module is the ONLY place in slowai that talks to torch. Everything
downstream (the classifier, the CLI) operates on the plain ProfileResult
dataclass below so it can be unit-tested without installing torch.

V1 is CPU-or-CUDA agnostic: it reads whatever profiler.key_averages() hands
back and normalizes it into a small, regime-agnostic shape. The classifier
decides what the shape MEANS.
"""

from __future__ import annotations

import importlib.util
import time
from dataclasses import dataclass, field
from pathlib import Path


@dataclass
class OpStat:
    """Normalized per-op-type stat extracted from torch.profiler."""

    name: str
    count: int
    total_us: float  # total wall-microseconds spent in this op (all calls summed)
    self_us: float   # self time (exclusive of children) in microseconds

    @property
    def avg_us(self) -> float:
        return self.total_us / self.count if self.count else 0.0


@dataclass
class ProfileResult:
    """Everything the classifier needs to decide a regime."""

    workload: str
    wall_time_s: float
    device: str                # "cuda" | "cpu" | "mps" | ...
    total_op_count: int        # sum of OpStat.count across all ops
    op_stats: list[OpStat] = field(default_factory=list)
    notes: list[str] = field(default_factory=list)

    @property
    def top_op(self) -> OpStat | None:
        if not self.op_stats:
            return None
        return max(self.op_stats, key=lambda s: s.total_us)

    @property
    def top_op_fraction(self) -> float:
        """Fraction of total op time spent in the single biggest op type."""
        if not self.op_stats:
            return 0.0
        total = sum(s.total_us for s in self.op_stats)
        if total <= 0:
            return 0.0
        return max(s.total_us for s in self.op_stats) / total


def _load_workload_module(path: str):
    """Load a .py file as a module so we can call its main()."""
    p = Path(path).resolve()
    if not p.exists():
        raise FileNotFoundError(f"Workload file not found: {path}")
    if p.suffix != ".py":
        raise ValueError(f"Workload must be a .py file, got: {path}")

    spec = importlib.util.spec_from_file_location(f"slowai_workload_{p.stem}", p)
    if spec is None or spec.loader is None:
        raise ImportError(f"Could not load spec for {path}")
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def profile_workload(path: str, wrap_context=None) -> ProfileResult:
    """
    Load and run a workload .py file under torch.profiler, return ProfileResult.

    The workload file must expose a top-level `main()` callable that actually
    runs the work. slowai imports the module (which triggers no work by
    convention — everything goes in main) and then profiles main().

    Args:
        path: Path to the workload .py file.
        wrap_context: Optional callable returning a context manager to wrap
            main(). Used by the remediate engine to apply autocast without
            modifying user code. Example: lambda: torch.autocast('cuda', dtype=torch.bfloat16)
    """
    # Imported lazily so `import slowai.schema` and the classifier tests
    # don't require torch to be installed.
    import torch
    from torch.profiler import ProfilerActivity, profile

    module = _load_workload_module(path)
    if not hasattr(module, "main") or not callable(module.main):
        raise AttributeError(
            f"Workload {path} must define a top-level `main()` callable."
        )

    device = "cuda" if torch.cuda.is_available() else "cpu"
    activities = [ProfilerActivity.CPU]
    if device == "cuda":
        activities.append(ProfilerActivity.CUDA)

    # Helper: run main() with optional context wrapper (e.g. autocast).
    def _run_main():
        if wrap_context is not None:
            with wrap_context():
                module.main()
        else:
            module.main()

    # Warmup: a single untimed pass. First pass eats kernel launch / autotune
    # costs that would pollute the regime signal.
    try:
        _run_main()
    except Exception as e:  # noqa: BLE001
        raise RuntimeError(f"Workload warmup failed: {e}") from e

    if device == "cuda":
        torch.cuda.synchronize()

    t0 = time.perf_counter()
    with profile(activities=activities, record_shapes=False) as prof:
        _run_main()
        if device == "cuda":
            torch.cuda.synchronize()
    wall = time.perf_counter() - t0

    # Normalize the profiler output into our shape. key_averages() returns
    # one row per op TYPE, already aggregated across all invocations.
    op_stats: list[OpStat] = []
    total_ops = 0
    for row in prof.key_averages():
        # cpu_time_total / self_cpu_time_total are in microseconds
        total_us = float(getattr(row, "cpu_time_total", 0.0))
        self_us = float(getattr(row, "self_cpu_time_total", 0.0))
        if device == "cuda":
            # Prefer CUDA timing when running on GPU — CPU time includes dispatch.
            cuda_total = float(getattr(row, "cuda_time_total", 0.0))
            cuda_self = float(getattr(row, "self_cuda_time_total", 0.0))
            if cuda_total > 0:
                total_us = cuda_total
                self_us = cuda_self
        count = int(getattr(row, "count", 0))
        if count == 0:
            continue
        op_stats.append(
            OpStat(name=str(row.key), count=count, total_us=total_us, self_us=self_us)
        )
        total_ops += count

    return ProfileResult(
        workload=path,
        wall_time_s=wall,
        device=device,
        total_op_count=total_ops,
        op_stats=op_stats,
        notes=[f"warmup=1", f"device={device}"],
    )
