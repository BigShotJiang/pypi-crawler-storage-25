"""
slowai.diagnose — classify a ProfileResult into a Regime.

This is a PURE function of the ProfileResult. No torch, no I/O, no side
effects. Everything here is unit-testable without installing torch.

V0.3 uses a hand-tuned heuristic classifier with support for real-world
models. Real neural networks (MobileNet, ResNet, transformers) don't fit
neatly into one regime — they mix matmuls, normalization, pointwise, and
dispatch overhead. The classifier now:

    1. Filters noise ops (sync, initialization) before computing shares
    2. Counts normalization ops (batch_norm, layer_norm) as compute work
    3. Uses a combined compute share (matmul + norm) for real-model accuracy
    4. Detects the dominant regime even when no single category hits 60%

The three regimes (in priority order):

    1. OVERHEAD_BOUND   — many tiny ops dominate (framework dispatch >> GPU work)
    2. COMPUTE_BOUND    — matmul + normalization ops own the wall time
    3. MEMORY_BOUND     — pointwise ops dominate, low FLOP density

Anything genuinely ambiguous → UNKNOWN with low confidence.
"""

from __future__ import annotations

from slowai.profiler import OpStat, ProfileResult
from slowai.schema import Diagnosis, Regime


# --- tuning knobs -----------------------------------------------------------
# These are the ONLY magic numbers in the classifier. Every one is documented.

# Below this avg-op wall time (microseconds), an op counts as "tiny".
TINY_OP_US = 100.0

# If more than this fraction of the op count is tiny ops, we lean OVERHEAD_BOUND.
OVERHEAD_TINY_OP_FRACTION = 0.75

# Need at least this many total ops before "many tiny ops" is a valid signal.
# A 10-op workload that happens to be fast shouldn't be classified as overhead.
OVERHEAD_MIN_OP_COUNT = 500

# Matmul-class op name fragments. Dense math that saturates GPU ALUs.
MATMUL_OPS = ("mm", "matmul", "addmm", "bmm", "linear", "gemm", "conv")

# Normalization ops. These are compute-adjacent: they run fused GPU kernels
# with mean/variance reductions that behave like compute work, not pointwise.
# On MobileNetV2, batch_norm is the #1 time consumer. Discovered on Jetson
# Orin Nano: real models spend 30-40% of wall time in norm ops that the V1
# classifier ignored, causing false UNKNOWN classifications.
NORM_OPS = ("batch_norm", "layer_norm", "group_norm", "instance_norm")

# Sync/transfer ops that move data between GPU and CPU but aren't real compute.
# Discovered on Jetson Orin Nano: aten::item was eating ~30% of wall time in
# memory-bound workloads, diluting pointwise_share below threshold.
SYNC_OPS = ("item", "to", "copy_", "contiguous", "pin_memory", "record_stream")

# Initialization ops — tensor creation noise, not model compute. aten::normal_
# from torch.randn was the #1 op in ResNet-50 profiles, polluting the signal.
INIT_OPS = ("normal_", "uniform_", "randn", "rand", "zero_", "ones_", "fill_",
            "empty", "arange", "linspace")

# Pointwise op name fragments. Long-tail of these → memory-bound.
POINTWISE_OPS = (
    "add", "sub", "mul", "div",
    "relu", "sigmoid", "tanh", "gelu", "silu",
    "exp", "log", "sqrt", "pow",
    "copy", "clamp", "neg",
)

# Top-op share thresholds.
COMPUTE_TOP_OP_SHARE = 0.60   # matmul owns 60%+ of op-time → compute-bound
MEMORY_POINTWISE_SHARE = 0.50 # pointwise ops own 50%+ of op-time → memory-bound

# Combined compute share (matmul + norm). Real models split compute across
# convolutions and normalizations. This combined threshold catches models like
# MobileNetV2 where matmul_share=0.36 and norm_share=0.30 — individually
# below threshold but combined clearly compute-bound.
COMBINED_COMPUTE_SHARE = 0.45

# Confidence values. Deliberately coarse. These are the numbers the user
# will see in the Diagnosis; they should reflect real uncertainty, not
# false precision.
HIGH_CONFIDENCE = 0.85
MID_CONFIDENCE = 0.70
LOW_CONFIDENCE = 0.45
# ----------------------------------------------------------------------------


# --- prescription recipes ---------------------------------------------------
# One ranked list of fixes per regime. Cheapest-first. If a fix at position N
# works, the user never has to touch N+1.

FIXES_COMPUTE_BOUND = [
    "Enable tensor cores: switch matmul dtype to bf16 or tf32",
    "Reduce model size: smaller hidden dim or fewer layers",
    "Use a fused attention kernel (torch.nn.functional.scaled_dot_product_attention)",
    "Shrink batch size if FLOPs/sample is the actual bottleneck",
]

FIXES_MEMORY_BOUND = [
    "Fuse pointwise ops with torch.compile (auto-fuses chains like add→mul→relu)",
    "Switch activations to fp16/bf16 to halve memory traffic",
    "Adopt channels_last memory format for conv stacks",
    "Increase op granularity: fewer, larger pointwise ops per layer",
]

FIXES_OVERHEAD_BOUND = [
    "Wrap the model in torch.compile — kills per-op dispatch overhead",
    "Increase batch size so each op has more work to amortize dispatch",
    "Merge tiny ops into bigger ones (vectorize Python loops, stack tensors)",
    "Use CUDA graphs for fixed-shape inference loops",
]

FIXES_UNKNOWN = [
    "Run the workload with longer warmup — first-call overhead may be skewing the profile",
    "Increase the work-per-step (bigger batch or longer loop) so the dominant cost becomes obvious",
    "Profile on the target device — CPU profiling often misleads when the target is GPU",
]

_FIXES_BY_REGIME = {
    Regime.COMPUTE_BOUND: FIXES_COMPUTE_BOUND,
    Regime.MEMORY_BOUND: FIXES_MEMORY_BOUND,
    Regime.OVERHEAD_BOUND: FIXES_OVERHEAD_BOUND,
    Regime.UNKNOWN: FIXES_UNKNOWN,
}


def prescribe(regime: Regime) -> list[str]:
    """Return the ranked fix list for a given regime. Pure lookup."""
    return list(_FIXES_BY_REGIME.get(regime, FIXES_UNKNOWN))
# ----------------------------------------------------------------------------


def _name_matches(name: str, fragments: tuple[str, ...]) -> bool:
    """Case-insensitive substring match against any fragment."""
    n = name.lower()
    return any(frag in n for frag in fragments)


def _filter_noise_ops(op_stats: list[OpStat]) -> list[OpStat]:
    """Remove sync/transfer and initialization ops that aren't real model work.

    V0.2 filtered SYNC_OPS only. V0.3 also filters INIT_OPS — tensor creation
    noise (aten::normal_, aten::empty) that pollutes the profile on GPU.
    """
    return [
        s for s in op_stats
        if not _name_matches(s.name, SYNC_OPS)
        and not _name_matches(s.name, INIT_OPS)
    ]


def _matmul_share(op_stats: list[OpStat]) -> float:
    """Fraction of total op-time spent in matmul-class ops."""
    total = sum(s.total_us for s in op_stats)
    if total <= 0:
        return 0.0
    mm = sum(s.total_us for s in op_stats if _name_matches(s.name, MATMUL_OPS))
    return mm / total


def _norm_share(op_stats: list[OpStat]) -> float:
    """Fraction of total op-time spent in normalization ops."""
    total = sum(s.total_us for s in op_stats)
    if total <= 0:
        return 0.0
    nm = sum(s.total_us for s in op_stats if _name_matches(s.name, NORM_OPS))
    return nm / total


def _pointwise_share(op_stats: list[OpStat]) -> float:
    """Fraction of total op-time spent in pointwise ops."""
    total = sum(s.total_us for s in op_stats)
    if total <= 0:
        return 0.0
    pw = sum(s.total_us for s in op_stats if _name_matches(s.name, POINTWISE_OPS))
    return pw / total


def _tiny_op_fraction(op_stats: list[OpStat]) -> float:
    """Fraction of total op COUNT where avg_us < TINY_OP_US."""
    total_count = sum(s.count for s in op_stats)
    if total_count == 0:
        return 0.0
    tiny_count = sum(s.count for s in op_stats if s.avg_us < TINY_OP_US)
    return tiny_count / total_count


def classify(result: ProfileResult) -> Diagnosis:
    """Classify a ProfileResult into a Diagnosis. Pure function.

    V0.3 changes from V0.2:
    - Filters both sync AND init ops (not just sync)
    - Computes norm_share separately for evidence
    - Uses combined_compute_share (matmul + norm) for real-model detection
    - Computes evidence from filtered ops, not raw result
    """
    op_stats = _filter_noise_ops(result.op_stats)

    if not op_stats or result.total_op_count == 0:
        return Diagnosis(
            workload=result.workload,
            regime=Regime.UNKNOWN,
            confidence=LOW_CONFIDENCE,
            evidence={"reason_empty_profile": 1.0},
            top_fixes=prescribe(Regime.UNKNOWN),
        )

    # Compute all shares from filtered ops.
    total_count = sum(s.count for s in op_stats)
    top = max(op_stats, key=lambda s: s.total_us)
    total_us = sum(s.total_us for s in op_stats)
    top_share = top.total_us / total_us if total_us > 0 else 0.0

    mm_share = _matmul_share(op_stats)
    nm_share = _norm_share(op_stats)
    pw_share = _pointwise_share(op_stats)
    tiny_frac = _tiny_op_fraction(op_stats)
    combined_compute = mm_share + nm_share

    evidence: dict[str, float] = {
        "wall_time_s": result.wall_time_s,
        "total_op_count": float(total_count),
        "top_op_share": top_share,
        "matmul_share": mm_share,
        "norm_share": nm_share,
        "combined_compute_share": combined_compute,
        "pointwise_share": pw_share,
        "tiny_op_fraction": tiny_frac,
        "top_op_avg_us": top.avg_us,
    }

    # Rule 1 — OVERHEAD_BOUND.
    # Lots of ops, most of them are tiny. Classic torch.compile / fuse target.
    if (
        total_count >= OVERHEAD_MIN_OP_COUNT
        and tiny_frac >= OVERHEAD_TINY_OP_FRACTION
    ):
        confidence = HIGH_CONFIDENCE if tiny_frac >= 0.90 else MID_CONFIDENCE
        return Diagnosis(
            workload=result.workload,
            regime=Regime.OVERHEAD_BOUND,
            confidence=confidence,
            evidence=evidence,
            top_fixes=prescribe(Regime.OVERHEAD_BOUND),
        )

    # Rule 2 — COMPUTE_BOUND.
    # Pure matmul dominance (classic GEMM workloads).
    if mm_share >= COMPUTE_TOP_OP_SHARE:
        confidence = HIGH_CONFIDENCE if mm_share >= 0.80 else MID_CONFIDENCE
        return Diagnosis(
            workload=result.workload,
            regime=Regime.COMPUTE_BOUND,
            confidence=confidence,
            evidence=evidence,
            top_fixes=prescribe(Regime.COMPUTE_BOUND),
        )

    # Rule 2b — COMPUTE_BOUND (real models).
    # Matmul + normalization combined dominate. Real neural networks split
    # compute across convolutions and batch/layer norms. Neither alone hits 60%
    # but together they clearly dominate. Matmul must still be the larger share
    # to avoid classifying norm-heavy workloads as compute-bound.
    if combined_compute >= COMBINED_COMPUTE_SHARE and mm_share > pw_share:
        confidence = MID_CONFIDENCE if combined_compute >= 0.60 else LOW_CONFIDENCE
        return Diagnosis(
            workload=result.workload,
            regime=Regime.COMPUTE_BOUND,
            confidence=confidence,
            evidence=evidence,
            top_fixes=prescribe(Regime.COMPUTE_BOUND),
        )

    # Rule 3 — MEMORY_BOUND.
    # Pointwise ops dominate the op-time budget, and the ops aren't tiny
    # (otherwise Rule 1 would have fired).
    if pw_share >= MEMORY_POINTWISE_SHARE:
        confidence = HIGH_CONFIDENCE if pw_share >= 0.75 else MID_CONFIDENCE
        return Diagnosis(
            workload=result.workload,
            regime=Regime.MEMORY_BOUND,
            confidence=confidence,
            evidence=evidence,
            top_fixes=prescribe(Regime.MEMORY_BOUND),
        )

    # Fallthrough — nothing is clearly dominant. Be honest about it.
    return Diagnosis(
        workload=result.workload,
        regime=Regime.UNKNOWN,
        confidence=LOW_CONFIDENCE,
        evidence=evidence,
        top_fixes=prescribe(Regime.UNKNOWN),
    )
