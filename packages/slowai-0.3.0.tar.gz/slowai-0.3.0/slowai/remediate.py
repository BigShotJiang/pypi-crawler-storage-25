"""
slowai.remediate — auto-apply fixes and measure before/after speedup.

V3 feature: the thing that makes slowai acquisition-worthy. Instead of just
TELLING you what's wrong, we FIX it and PROVE it worked.

Flow:
    1. Profile baseline workload → classify regime
    2. Select applicable remedies for that regime
    3. For each remedy: re-profile with remedy active → measure speedup
    4. Rank by speedup, report the winner

Remedies are environment-level transforms — they don't modify user code.
They work by changing PyTorch's global settings (TF32, cuDNN benchmark) or
wrapping the workload execution in a context manager (autocast for bf16/fp16).

Constraint: torch.compile does NOT work on Jetson aarch64 (InductorError),
so all remedies here are compile-free. When torch.compile lands on Jetson,
we add it as another Remedy and get free speedups.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Callable

from slowai.schema import Diagnosis, Regime


# ---------------------------------------------------------------------------
# Remedy definition
# ---------------------------------------------------------------------------

@dataclass
class Remedy:
    """A single auto-applicable fix.

    Remedies work in two ways (both optional, at least one required):
        setup/teardown: Set global PyTorch flags before profiling, restore after.
        wrap_main: Return a context manager that wraps the workload's main().
    """
    name: str
    description: str
    setup: Callable[[], None] | None = None
    teardown: Callable[[], None] | None = None
    wrap_main: Callable | None = None  # () -> ContextManager


@dataclass
class RemedyResult:
    """Before/after comparison for a single remedy."""
    remedy_name: str
    remedy_description: str
    baseline_wall_s: float
    remedied_wall_s: float
    speedup: float          # baseline / remedied (>1.0 = faster)
    regime_before: Regime
    regime_after: Regime
    confidence_after: float
    error: str | None = None  # non-None if the remedy crashed


@dataclass
class FixReport:
    """Complete auto-fix report for a workload."""
    workload: str
    baseline_diagnosis: Diagnosis
    results: list[RemedyResult] = field(default_factory=list)

    @property
    def best(self) -> RemedyResult | None:
        """The remedy with the highest speedup, or None if nothing helped."""
        valid = [r for r in self.results if r.error is None and r.speedup > 1.0]
        return max(valid, key=lambda r: r.speedup) if valid else None


# ---------------------------------------------------------------------------
# Remedy implementations — pure PyTorch environment transforms
# ---------------------------------------------------------------------------

def _setup_tf32() -> None:
    import torch
    torch.backends.cuda.matmul.allow_tf32 = True
    torch.backends.cudnn.allow_tf32 = True

def _teardown_tf32() -> None:
    import torch
    torch.backends.cuda.matmul.allow_tf32 = False
    torch.backends.cudnn.allow_tf32 = False

def _setup_cudnn_bench() -> None:
    import torch
    torch.backends.cudnn.benchmark = True

def _teardown_cudnn_bench() -> None:
    import torch
    torch.backends.cudnn.benchmark = False

def _wrap_bf16():
    import torch
    return torch.autocast("cuda", dtype=torch.bfloat16)

def _wrap_fp16():
    import torch
    return torch.autocast("cuda", dtype=torch.float16)

def _setup_high_precision() -> None:
    """Tell PyTorch to prefer speed over precision for float32 matmuls."""
    import torch
    torch.set_float32_matmul_precision("high")

def _teardown_high_precision() -> None:
    import torch
    torch.set_float32_matmul_precision("highest")


# ---------------------------------------------------------------------------
# Remedy catalog
# ---------------------------------------------------------------------------

REMEDY_TF32 = Remedy(
    name="tf32_tensor_cores",
    description="Enable TF32 tensor cores (19-bit precision, ~2x matmul throughput on Ampere+)",
    setup=_setup_tf32,
    teardown=_teardown_tf32,
)

REMEDY_MATMUL_PRECISION = Remedy(
    name="high_matmul_precision",
    description="Set float32 matmul precision to 'high' (allows TF32 and internal downcasting)",
    setup=_setup_high_precision,
    teardown=_teardown_high_precision,
)

REMEDY_BF16 = Remedy(
    name="bf16_autocast",
    description="Run under bfloat16 automatic mixed precision (halves memory traffic + faster math)",
    wrap_main=_wrap_bf16,
)

REMEDY_FP16 = Remedy(
    name="fp16_autocast",
    description="Run under float16 automatic mixed precision (halves memory traffic)",
    wrap_main=_wrap_fp16,
)

REMEDY_CUDNN_BENCH = Remedy(
    name="cudnn_benchmark",
    description="Enable cuDNN auto-tuner for convolution kernels (finds fastest algorithm)",
    setup=_setup_cudnn_bench,
    teardown=_teardown_cudnn_bench,
)

# Ordered by expected impact. First remedy that wins big → user ships it.
REMEDIES_BY_REGIME: dict[Regime, list[Remedy]] = {
    Regime.COMPUTE_BOUND: [
        REMEDY_TF32,
        REMEDY_MATMUL_PRECISION,
        REMEDY_BF16,
        REMEDY_CUDNN_BENCH,
    ],
    Regime.MEMORY_BOUND: [
        REMEDY_BF16,
        REMEDY_FP16,
        REMEDY_TF32,
    ],
    Regime.OVERHEAD_BOUND: [
        # torch.compile would be #1 here but doesn't work on Jetson aarch64.
        # These are the best compile-free options.
        REMEDY_BF16,
        REMEDY_TF32,
    ],
    Regime.UNKNOWN: [
        REMEDY_TF32,
        REMEDY_BF16,
    ],
}


# ---------------------------------------------------------------------------
# Core engine
# ---------------------------------------------------------------------------

def _apply_one_remedy(
    workload_path: str,
    remedy: Remedy,
    baseline_diag: Diagnosis,
) -> RemedyResult:
    """Profile a workload with one remedy active. Return before/after."""
    from slowai.diagnose import classify
    from slowai.profiler import profile_workload

    baseline_wall = baseline_diag.evidence.get("wall_time_s", 0.0)

    # Setup global state.
    if remedy.setup:
        remedy.setup()

    try:
        result = profile_workload(workload_path, wrap_context=remedy.wrap_main)
        diag = classify(result)
        speedup = baseline_wall / result.wall_time_s if result.wall_time_s > 0 else 0.0

        return RemedyResult(
            remedy_name=remedy.name,
            remedy_description=remedy.description,
            baseline_wall_s=baseline_wall,
            remedied_wall_s=result.wall_time_s,
            speedup=round(speedup, 3),
            regime_before=baseline_diag.regime,
            regime_after=diag.regime,
            confidence_after=diag.confidence,
        )
    except Exception as e:  # noqa: BLE001
        return RemedyResult(
            remedy_name=remedy.name,
            remedy_description=remedy.description,
            baseline_wall_s=baseline_wall,
            remedied_wall_s=-1.0,
            speedup=0.0,
            regime_before=baseline_diag.regime,
            regime_after=Regime.UNKNOWN,
            confidence_after=0.0,
            error=str(e),
        )
    finally:
        # Always restore state.
        if remedy.teardown:
            try:
                remedy.teardown()
            except Exception:  # noqa: BLE001
                pass


def auto_fix(workload_path: str) -> FixReport:
    """The V3 money shot: diagnose, auto-apply fixes, measure speedup.

    Returns a FixReport with the baseline diagnosis and ranked remedy results.
    """
    from slowai.diagnose import classify
    from slowai.profiler import profile_workload

    # Step 1: baseline profile + classify.
    baseline_result = profile_workload(workload_path)
    baseline_diag = classify(baseline_result)

    report = FixReport(
        workload=workload_path,
        baseline_diagnosis=baseline_diag,
    )

    # Step 2: get remedies for this regime.
    remedies = REMEDIES_BY_REGIME.get(baseline_diag.regime, [])
    if not remedies:
        return report

    # Step 3: try each remedy, measure speedup.
    for remedy in remedies:
        rr = _apply_one_remedy(workload_path, remedy, baseline_diag)
        report.results.append(rr)

    # Step 4: sort by speedup (best first).
    report.results.sort(key=lambda r: r.speedup, reverse=True)

    return report
