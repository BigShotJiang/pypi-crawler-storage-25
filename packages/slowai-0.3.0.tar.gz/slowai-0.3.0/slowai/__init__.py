"""slowai — diagnose and auto-fix PyTorch performance bottlenecks."""

from slowai.schema import Diagnosis, Regime

__version__ = "0.3.0"
__all__ = ["Diagnosis", "Regime"]
