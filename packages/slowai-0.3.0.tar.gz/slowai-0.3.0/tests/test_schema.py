"""Minimal tests for slowai.schema — the first commit of the moat."""

import pytest

from slowai.schema import Diagnosis, Regime


def test_regime_enum_has_three_bound_values_plus_unknown() -> None:
    assert Regime.COMPUTE_BOUND.value == "compute"
    assert Regime.MEMORY_BOUND.value == "memory"
    assert Regime.OVERHEAD_BOUND.value == "overhead"
    assert Regime.UNKNOWN.value == "unknown"


def test_diagnosis_happy_path() -> None:
    d = Diagnosis(
        workload="train.py",
        regime=Regime.OVERHEAD_BOUND,
        confidence=0.82,
        evidence={
            "gpu_utilization": 0.31,
            "dispatch_to_kernel": 0.58,
            "memory_bandwidth_used": 0.12,
        },
    )
    assert d.regime is Regime.OVERHEAD_BOUND
    assert d.confidence == 0.82
    assert d.top_fixes == []
    assert "OVERHEAD_BOUND" in d.summary()


def test_diagnosis_confidence_bounds_are_enforced() -> None:
    with pytest.raises(ValueError):
        Diagnosis(
            workload="train.py",
            regime=Regime.COMPUTE_BOUND,
            confidence=1.7,
            evidence={},
        )
    with pytest.raises(ValueError):
        Diagnosis(
            workload="train.py",
            regime=Regime.COMPUTE_BOUND,
            confidence=-0.1,
            evidence={},
        )


def test_diagnosis_top_fixes_default_empty_for_phase1() -> None:
    d = Diagnosis(
        workload="x.py",
        regime=Regime.UNKNOWN,
        confidence=0.0,
        evidence={},
    )
    assert d.top_fixes == [], "Phase 1 must not prescribe fixes."
