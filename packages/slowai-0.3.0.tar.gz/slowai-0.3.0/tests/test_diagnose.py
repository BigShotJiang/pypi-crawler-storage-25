"""
Unit tests for slowai.diagnose.classify — the pure V1 classifier.

These tests do NOT require torch. They fabricate ProfileResult objects
that mirror what torch.profiler would return for each of the three ground-
truth workloads in workloads/, and verify that classify() picks the right
Regime. This is the regression safety net for the V1 classifier rules.

Add a new case here every time the classifier is wrong on a real workload.
Growing this file IS the path to V2.
"""

from __future__ import annotations

import pytest

from slowai.diagnose import classify, prescribe
from slowai.profiler import OpStat, ProfileResult
from slowai.schema import Regime


# ---- fixture builders ------------------------------------------------------


def _overhead() -> ProfileResult:
    """Mirrors workloads/overhead_tiny_ops.py — 15k tiny ops."""
    return ProfileResult(
        workload="workloads/overhead_tiny_ops.py",
        wall_time_s=0.42,
        device="cpu",
        total_op_count=15_000,
        op_stats=[
            OpStat(name="aten::add", count=5_000, total_us=120_000, self_us=100_000),
            OpStat(name="aten::mul", count=5_000, total_us=115_000, self_us=95_000),
            OpStat(name="aten::relu", count=5_000, total_us=140_000, self_us=120_000),
        ],
    )


def _compute() -> ProfileResult:
    """Mirrors workloads/compute_gemm.py — 50 giant matmuls."""
    return ProfileResult(
        workload="workloads/compute_gemm.py",
        wall_time_s=8.5,
        device="cpu",
        total_op_count=52,
        op_stats=[
            OpStat(name="aten::mm", count=50, total_us=8_100_000, self_us=8_000_000),
            OpStat(name="aten::sum", count=1, total_us=50_000, self_us=50_000),
            OpStat(name="aten::randn", count=1, total_us=20_000, self_us=20_000),
        ],
    )


def _memory() -> ProfileResult:
    """Mirrors workloads/memory_pointwise.py — 100 big pointwise ops."""
    return ProfileResult(
        workload="workloads/memory_pointwise.py",
        wall_time_s=6.2,
        device="cpu",
        total_op_count=100,
        op_stats=[
            OpStat(name="aten::add", count=20, total_us=1_200_000, self_us=1_200_000),
            OpStat(name="aten::mul", count=20, total_us=1_150_000, self_us=1_150_000),
            OpStat(name="aten::tanh", count=20, total_us=1_300_000, self_us=1_300_000),
            OpStat(name="aten::sub", count=20, total_us=1_100_000, self_us=1_100_000),
            OpStat(name="aten::sigmoid", count=20, total_us=1_250_000, self_us=1_250_000),
        ],
    )


# ---- ground-truth tests ----------------------------------------------------


def test_classifies_overhead_bound() -> None:
    diag = classify(_overhead())
    assert diag.regime == Regime.OVERHEAD_BOUND
    assert diag.confidence >= 0.70
    assert diag.evidence["tiny_op_fraction"] >= 0.75


def test_classifies_compute_bound() -> None:
    diag = classify(_compute())
    assert diag.regime == Regime.COMPUTE_BOUND
    assert diag.confidence >= 0.70
    assert diag.evidence["matmul_share"] >= 0.60


def test_classifies_memory_bound() -> None:
    diag = classify(_memory())
    assert diag.regime == Regime.MEMORY_BOUND
    assert diag.confidence >= 0.70
    assert diag.evidence["pointwise_share"] >= 0.50


# ---- fallback + adversarial cases ------------------------------------------


def test_empty_profile_is_unknown() -> None:
    result = ProfileResult(
        workload="empty.py",
        wall_time_s=0.01,
        device="cpu",
        total_op_count=0,
        op_stats=[],
    )
    diag = classify(result)
    assert diag.regime == Regime.UNKNOWN


def test_tiny_matmuls_are_overhead_not_compute() -> None:
    """Rule priority check: if matmul ops are tiny and there are thousands
    of them, the bottleneck is dispatch, not math. OVERHEAD_BOUND wins."""
    result = ProfileResult(
        workload="tiny_matmul.py",
        wall_time_s=0.3,
        device="cpu",
        total_op_count=2_000,
        op_stats=[
            OpStat(name="aten::mm", count=2_000, total_us=40_000, self_us=40_000),
        ],
    )
    diag = classify(result)
    assert diag.regime == Regime.OVERHEAD_BOUND


def test_mixed_workload_with_no_dominant_signal_is_unknown() -> None:
    """Ambiguous: few ops, balanced share across matmul and pointwise, no
    overhead signal. Classifier should be honest and say UNKNOWN."""
    result = ProfileResult(
        workload="mixed.py",
        wall_time_s=1.0,
        device="cpu",
        total_op_count=20,
        op_stats=[
            OpStat(name="aten::mm", count=5, total_us=100_000, self_us=100_000),
            OpStat(name="aten::add", count=5, total_us=90_000, self_us=90_000),
            OpStat(name="aten::mul", count=5, total_us=80_000, self_us=80_000),
            OpStat(name="aten::relu", count=5, total_us=85_000, self_us=85_000),
        ],
    )
    diag = classify(result)
    # matmul_share ~0.28, pointwise_share ~0.72 — so this actually goes
    # MEMORY_BOUND. That's fine — the point of this test is to lock the
    # current behavior so future rule changes are intentional, not accidental.
    assert diag.regime in (Regime.MEMORY_BOUND, Regime.UNKNOWN)


# ---- top_fixes / prescription tests ---------------------------------------


def test_every_regime_has_nonempty_fixes() -> None:
    """Every regime must map to at least one actionable fix. An empty
    top_fixes list for any regime is a product bug — diagnosis without
    prescription is half the product."""
    for regime in Regime:
        fixes = prescribe(regime)
        assert len(fixes) >= 1, f"no fixes defined for {regime}"
        for f in fixes:
            assert isinstance(f, str) and f.strip(), f"empty fix string for {regime}"


def test_classify_attaches_fixes_to_every_diagnosis() -> None:
    """Every Diagnosis returned by classify() must carry a top_fixes list.
    Regression guard: if a new classify() return path forgets to call
    prescribe(), this test catches it."""
    for result_builder in (_overhead, _compute, _memory):
        diag = classify(result_builder())
        assert diag.top_fixes, f"{diag.regime} came back with empty top_fixes"
        assert len(diag.top_fixes) >= 2


def test_compute_fixes_mention_tensor_cores_or_bf16() -> None:
    """Sanity check that the COMPUTE recipe is actually about compute
    techniques, not a copy-paste of the memory recipe."""
    fixes_text = " ".join(prescribe(Regime.COMPUTE_BOUND)).lower()
    assert "bf16" in fixes_text or "tensor core" in fixes_text or "tf32" in fixes_text


def test_overhead_fixes_mention_compile_or_batch() -> None:
    """OVERHEAD recipe should point at torch.compile or batching."""
    fixes_text = " ".join(prescribe(Regime.OVERHEAD_BOUND)).lower()
    assert "torch.compile" in fixes_text or "batch" in fixes_text
