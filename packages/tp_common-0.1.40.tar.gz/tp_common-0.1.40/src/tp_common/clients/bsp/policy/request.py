"""Схемы запросов HTTP-клиента bsp-policy.

Зеркалят ``bsp-policy/src/api/v1/*/request.py``; при изменении API сервиса
схемы нужно синхронизировать здесь.
"""

from __future__ import annotations

import uuid
from datetime import date, datetime
from enum import StrEnum

from pydantic import Field

from tp_common.route.camel_case_enum import CamelCaseEnum
from tp_common.route.schemes import (
    BaseAppEventMessagesQueryParams,
    BaseQueryRequest,
    BaseRequest,
)


class VehiclePolicyStatus(CamelCaseEnum, StrEnum):
    ACTIVE = "active"
    EXPIRED = "expired"
    WAITING_ACTIVATION = "waiting_activation"
    NOT_FOUND = "not_found"


class TaskStatus(StrEnum):
    CREATED = "CREATED"
    PROCESSING = "PROCESSING"
    COMPLETED = "COMPLETED"
    PARTIAL_COMPLETED = "PARTIAL_COMPLETED"
    FAILED = "FAILED"
    NOT_FOUND = "NOT_FOUND"


class PolicySeries(StrEnum):
    XXX = "ХХХ"
    TTT = "ТТТ"
    AAA = "ААА"
    AAV = "ААВ"
    AAK = "ААК"
    AAM = "ААМ"
    AAN = "ААН"
    AAS = "ААС"
    VVV = "ВВВ"
    EEE = "ЕЕЕ"
    KKK = "ККК"
    MMM = "МММ"
    NNN = "ННН"
    RRR = "РРР"
    SSS = "ССС"


class PolicyStatus(StrEnum):
    ACTIVE = "ACTIVE"
    WAITING_ACTIVATION = "WAITING_ACTIVATION"
    EXPIRED = "EXPIRED"


class VehiclesSortBy(CamelCaseEnum, StrEnum):
    VEHICLE_ID = "vehicle_id"
    REG_NUMBER = "reg_number"
    VIN = "vin"
    BRAND = "brand"
    MODEL = "model"
    POLICY_STATUS = "policy_status"
    CREATED_AT = "created_at"
    UPDATED_AT = "updated_at"


class VehiclesRequest(BaseQueryRequest[VehiclesSortBy]):
    """GET ``/vehicles`` — список ТС с фильтрами и пагинацией."""

    vehicle_id: uuid.UUID | None = Field(default=None)
    reg_number: str | None = None
    vin: str | None = None
    brand: str | None = None
    model: str | None = None
    policy_status: VehiclePolicyStatus | None = None


class VehicleEnsureRequest(BaseRequest):
    """POST ``/vehicles`` — ТС и цепочка проверки ОСАГО."""

    reg_number: str


class VehicleSyncRequest(BaseRequest):
    """PATCH ``/vehicles/sync`` — эталонный набор госномеров."""

    reg_numbers: list[str] = Field(
        min_length=1,
        description="Целевой набор госномеров: добавление отсутствующих и удаление лишних.",
    )


class TasksSortBy(CamelCaseEnum, StrEnum):
    TASK_ID = "task_id"
    REG_NUMBER = "reg_number"
    STATUS = "status"
    PRIORITY = "priority"
    POLICIES_FOUND_COUNT = "policies_found_count"
    POLICIES_WITHOUT_DATES_COUNT = "policies_without_dates_count"
    COMPLETED_AT = "completed_at"
    LAST_ERROR_NAME = "last_error_name"
    LAST_ERROR_MESSAGE = "last_error_message"
    CREATED_AT = "created_at"
    UPDATED_AT = "updated_at"


class TasksRequest(BaseQueryRequest[TasksSortBy]):
    """GET ``/tasks`` — список задач проверки ОСАГО."""

    task_id: uuid.UUID | None = Field(default=None)
    reg_number: str | None = None
    status: TaskStatus | None = None
    priority: int | None = None
    policies_found_count: int | None = None
    policies_without_dates_count: int | None = None
    completed_at: datetime | None = None
    last_error_name: str | None = None
    last_error_message: str | None = None


class PoliciesSortBy(CamelCaseEnum, StrEnum):
    POLICY_ID = "policy_id"
    TASK_ID = "task_id"
    POLICY_SERIES = "policy_series"
    POLICY_NUMBER = "policy_number"
    STATUS = "status"
    INSURANCE_ID = "insurance_id"
    START_DATE = "start_date"
    END_DATE = "end_date"
    CREATED_AT = "created_at"
    UPDATED_AT = "updated_at"


class PoliciesRequest(BaseQueryRequest[PoliciesSortBy]):
    """GET ``/policies`` — список полисов."""

    policy_id: uuid.UUID | None = Field(default=None)
    task_id: uuid.UUID | None = None
    policy_series: PolicySeries | None = None
    policy_number: str | None = None
    status: PolicyStatus | None = None
    insurance_id: uuid.UUID | None = None
    start_date: date | None = None
    end_date: date | None = None


class AccountsSortBy(CamelCaseEnum, StrEnum):
    ACCOUNT_ID = "account_id"
    GUID = "guid"
    USER_ID = "user_id"
    ACCESS_TOKEN = "access_token"
    REFRESH_TOKEN = "refresh_token"
    ESIA_SUBJ_ID = "esia_subj_id"
    PHONE_NUMBER = "phone_number"
    EMAIL = "email"
    LOCKED_AT = "locked_at"
    LOCKED_BY = "locked_by"
    LOCKED_UNTIL = "locked_until"
    DAILY_REQUESTS_BUCKET_DATE = "daily_requests_bucket_date"
    DAILY_REQUESTS_COUNT = "daily_requests_count"
    PROXY = "proxy"
    CREATED_AT = "created_at"
    UPDATED_AT = "updated_at"


class AccountsRequest(BaseQueryRequest[AccountsSortBy]):
    """GET ``/accounts`` — список учётных записей Autoins."""

    account_id: uuid.UUID | None = Field(default=None)
    guid: str | None = None
    user_id: str | None = None
    phone_number: str | None = None
    email: str | None = None
    proxy: str | None = None


class AccountCreateRequest(BaseRequest):
    """POST ``/accounts`` — создать учётную запись Autoins."""

    user_id: str = Field(min_length=1)
    guid: str | None = None
    access_token: str | None = None
    refresh_token: str | None = None
    esia_subj_id: str | None = None
    phone_number: str | None = None
    email: str | None = None
    proxy: str | None = None


class TaskEventsRequest(BaseAppEventMessagesQueryParams):
    """Query GET ``/events/tasks`` (long-poll Kafka ``bsp-policy.events.v1.tasks.<service_id>``)."""
