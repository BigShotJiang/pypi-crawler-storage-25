"""
Пример: GET ``/policies`` — список полисов.

Запуск::

  python -m tp_common.clients.bsp.policy.examples.list_policies
"""

from __future__ import annotations

from tp_common.clients.bsp.policy.client import BspPolicyClient
from tp_common.clients.bsp.policy.examples import demo_params
from tp_common.clients.bsp.policy.examples._runner import main
from tp_common.clients.bsp.policy.request import PoliciesRequest


async def _call(client: BspPolicyClient) -> object:
    return await client.list_policies(
        PoliciesRequest(
            limit=demo_params.POLICIES_LIMIT,
            offset=demo_params.POLICIES_OFFSET,
            sort=demo_params.POLICIES_SORT,
        )
    )


if __name__ == "__main__":
    main(_call)
