"""
Пример: GET ``/accounts`` — список учётных записей Autoins.

Запуск::

  python -m tp_common.clients.bsp.policy.examples.list_accounts
"""

from __future__ import annotations

from tp_common.clients.bsp.policy.client import BspPolicyClient
from tp_common.clients.bsp.policy.examples import demo_params
from tp_common.clients.bsp.policy.examples._runner import main
from tp_common.clients.bsp.policy.request import AccountsRequest


async def _call(client: BspPolicyClient) -> object:
    return await client.list_accounts(
        AccountsRequest(
            limit=demo_params.ACCOUNTS_LIMIT,
            offset=demo_params.ACCOUNTS_OFFSET,
            sort=demo_params.ACCOUNTS_SORT,
        )
    )


if __name__ == "__main__":
    main(_call)
