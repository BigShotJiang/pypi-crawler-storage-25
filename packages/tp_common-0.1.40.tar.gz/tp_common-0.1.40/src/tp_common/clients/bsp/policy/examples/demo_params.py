"""Демо-параметры примеров bsp-policy: значения в коде.

Keycloak и базовый URL — в ``create_client`` (``POLICY_KEYCLOAK_URL``, ``POLICY_URL``).
"""

from __future__ import annotations

import uuid

from dplex.internal.sort import Order

from tp_common.clients.bsp.policy.request import TasksSortBy, VehiclesSortBy

REG_NUMBER = "В524КЕ797"
REG_NUMBER_EXTRA = "Р997МТ716"

SYNC_REG_NUMBERS = [REG_NUMBER, REG_NUMBER_EXTRA]

VEHICLES_REG_NUMBER: str | None = REG_NUMBER
VEHICLES_LIMIT = 20
VEHICLES_OFFSET = 0
VEHICLES_SORT = Order.DESC
VEHICLES_SORT_BY: VehiclesSortBy | None = VehiclesSortBy.CREATED_AT

TASK_LIST_REG_NUMBER: str | None = REG_NUMBER
TASK_LIST_TASK_ID: uuid.UUID | None = None
TASK_LIST_LIMIT = 20
TASK_LIST_OFFSET = 0
TASK_LIST_SORT = Order.DESC
TASK_LIST_SORT_BY: TasksSortBy | None = TasksSortBy.CREATED_AT

POLICIES_LIMIT = 20
POLICIES_OFFSET = 0
POLICIES_SORT = Order.DESC

ACCOUNTS_LIMIT = 20
ACCOUNTS_OFFSET = 0
ACCOUNTS_SORT = Order.DESC

ACCOUNT_USER_ID = "demo-user-id"

TASK_EVENTS_LIMIT = 10
TASK_EVENTS_OFFSET: int | None = None
TASK_EVENTS_TIMEOUT = 25.0
TASK_EVENTS_HTTP_TIMEOUT = 120.0
