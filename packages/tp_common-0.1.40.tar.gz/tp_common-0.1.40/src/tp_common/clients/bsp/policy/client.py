"""HTTP-клиент bsp-policy (``/api/v1``)."""

from __future__ import annotations

from tp_common.clients.bsp.base_ms_client import BaseMsClient
from tp_common.clients.bsp.policy.request import (
    AccountCreateRequest,
    AccountsRequest,
    PoliciesRequest,
    TaskEventsRequest,
    TasksRequest,
    VehicleEnsureRequest,
    VehiclesRequest,
    VehicleSyncRequest,
)
from tp_common.clients.bsp.policy.response import (
    Account,
    AccountsResponse,
    PoliciesResponse,
    TaskEventsResponse,
    TasksResponse,
    Vehicle,
    VehiclesResponse,
)
from tp_common.keycloak.oauth_client import KeycloakOAuthClient
from tp_common.tp_logger.schemas import EnvironmentType
from tp_common.tp_logger.tp_logging import TpLogger


class BspPolicyClient(BaseMsClient):
    """Клиент bsp-policy: пути и модели; Bearer и retry — в ``KeycloakClient``.

    Пути: ``/vehicles`` (GET, POST), ``/vehicles/sync`` (PATCH, 204),
    ``/tasks`` (GET), ``/policies`` (GET), ``/accounts`` (GET, POST),
    ``/events/tasks`` (long-poll).
    """

    _service_name = "bsp-policy"

    def __init__(
        self,
        *,
        keycloak_url: str | None = None,
        logger: TpLogger,
        policy_url: str | None = None,
        keycloak_oauth: KeycloakOAuthClient | None = None,
        env_type: EnvironmentType = EnvironmentType.LOCAL,
        max_retries: int = 3,
        token_min_ttl_s: int = 30,
        verify_ssl: bool = False,
    ) -> None:
        super().__init__(
            logger=logger,
            keycloak_url=keycloak_url,
            keycloak_oauth=keycloak_oauth,
            env_type=env_type,
            service_url=policy_url,
            max_retries=max_retries,
            token_min_ttl_s=token_min_ttl_s,
            verify_ssl=verify_ssl,
        )

    async def list_vehicles(self, request: VehiclesRequest) -> VehiclesResponse:
        """GET ``/vehicles`` — список ТС с фильтрами и пагинацией."""
        return await self.get(
            uri="/vehicles",
            response_schema=VehiclesResponse,
            params=request,
        )

    async def ensure_vehicle(self, request: VehicleEnsureRequest) -> Vehicle:
        """POST ``/vehicles`` — ТС и цепочка проверки ОСАГО (идемпотентно)."""
        return await self.post(
            uri="/vehicles",
            response_schema=Vehicle,
            json=request.model_dump(mode="json", by_alias=True),
        )

    async def sync_vehicles(self, request: VehicleSyncRequest) -> None:
        """PATCH ``/vehicles/sync`` — эталонный набор госномеров (ответ 204)."""
        await self.patch_response(
            uri="/vehicles/sync",
            json=request.model_dump(mode="json", by_alias=True),
        )

    async def list_tasks(self, request: TasksRequest) -> TasksResponse:
        """GET ``/tasks`` — список задач проверки ОСАГО."""
        return await self.get(
            uri="/tasks",
            response_schema=TasksResponse,
            params=request,
        )

    async def list_policies(self, request: PoliciesRequest) -> PoliciesResponse:
        """GET ``/policies`` — список полисов."""
        return await self.get(
            uri="/policies",
            response_schema=PoliciesResponse,
            params=request,
        )

    async def list_accounts(self, request: AccountsRequest) -> AccountsResponse:
        """GET ``/accounts`` — список учётных записей Autoins."""
        return await self.get(
            uri="/accounts",
            response_schema=AccountsResponse,
            params=request,
        )

    async def create_account(self, request: AccountCreateRequest) -> Account:
        """POST ``/accounts`` — создать учётную запись Autoins."""
        return await self.post(
            uri="/accounts",
            response_schema=Account,
            json=request.model_dump(mode="json", exclude_none=True, by_alias=True),
        )

    async def get_task_events(
        self,
        request: TaskEventsRequest,
        *,
        http_timeout: float = 120.0,
    ) -> TaskEventsResponse:
        """GET ``/events/tasks`` — long-poll app-событий задач.

        ``service_id`` из Bearer (Keycloak). В следующем запросе задайте
        ``TaskEventsRequest.offset`` равным прошлому ``nextOffset``, либо опустите поле.
        """
        return await self.get(
            uri="/events/tasks",
            response_schema=TaskEventsResponse,
            params=request,
            timeout=http_timeout,
        )
