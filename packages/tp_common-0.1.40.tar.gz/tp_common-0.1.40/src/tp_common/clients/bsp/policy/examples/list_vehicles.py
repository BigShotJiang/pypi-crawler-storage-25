"""
Пример: GET ``/vehicles`` — список ТС.

Запуск::

  python -m tp_common.clients.bsp.policy.examples.list_vehicles
"""

from __future__ import annotations

from tp_common.clients.bsp.policy.client import BspPolicyClient
from tp_common.clients.bsp.policy.examples import demo_params
from tp_common.clients.bsp.policy.examples._runner import main
from tp_common.clients.bsp.policy.request import VehiclesRequest


async def _call(client: BspPolicyClient) -> object:
    return await client.list_vehicles(
        VehiclesRequest(
            reg_number=demo_params.VEHICLES_REG_NUMBER,
            limit=demo_params.VEHICLES_LIMIT,
            offset=demo_params.VEHICLES_OFFSET,
            sort=demo_params.VEHICLES_SORT,
            sort_by=demo_params.VEHICLES_SORT_BY,
        )
    )


if __name__ == "__main__":
    main(_call)
