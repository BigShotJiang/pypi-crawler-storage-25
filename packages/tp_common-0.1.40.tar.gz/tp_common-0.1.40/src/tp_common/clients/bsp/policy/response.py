"""Схемы ответов HTTP-клиента bsp-policy (зеркало ``bsp-policy/src/api/v1/*/response.py``)."""

from __future__ import annotations

import uuid
from datetime import date, datetime
from enum import StrEnum

from pydantic import Field

from tp_common.clients.bsp.policy.request import (
    PolicySeries,
    PolicyStatus,
    TaskStatus,
    VehiclePolicyStatus,
)
from tp_common.kafka.app_event.schemas import BaseAppEventMessage
from tp_common.route.schemes import (
    BaseAppEventMessagesResponse,
    BaseQueryResponse,
    BaseResponse,
)


class TaskStep(StrEnum):
    NSIS = "NSIS"
    AUTOINS = "AUTOINS"


class Vehicle(BaseResponse):
    vehicle_id: uuid.UUID
    reg_number: str
    vin: str | None
    brand: str | None
    model: str | None
    policy_status: VehiclePolicyStatus | None
    created_at: datetime
    updated_at: datetime


class VehiclesResponse(BaseQueryResponse[Vehicle]):
    """Список ТС с ``total``."""


class Task(BaseResponse):
    task_id: uuid.UUID
    reg_number: str
    status: TaskStatus
    step: TaskStep | None
    priority: int
    policies_found_count: int
    policies_without_dates_count: int
    completed_at: datetime | None
    last_error_name: str | None
    last_error_message: str | None
    created_at: datetime
    updated_at: datetime


class TasksResponse(BaseQueryResponse[Task]):
    """Список задач с ``total``."""


class Policy(BaseResponse):
    policy_id: uuid.UUID
    task_id: uuid.UUID | None
    policy_series: PolicySeries
    policy_number: str
    status: PolicyStatus
    insurance_id: uuid.UUID
    start_date: date
    end_date: date
    created_at: datetime
    updated_at: datetime


class PoliciesResponse(BaseQueryResponse[Policy]):
    """Список полисов с ``total``."""


class Account(BaseResponse):
    account_id: uuid.UUID
    guid: str | None
    user_id: str | None
    access_token: str | None
    refresh_token: str | None
    esia_subj_id: str | None
    phone_number: str | None
    email: str | None
    locked_at: datetime | None
    locked_by: str | None
    locked_until: datetime
    daily_requests_bucket_date: date | None
    daily_requests_count: int
    banned_at: datetime | None
    unbanned_at: datetime | None
    proxy: str | None
    created_at: datetime
    updated_at: datetime


class AccountsResponse(BaseQueryResponse[Account]):
    """Список аккаунтов Autoins с ``total``."""


class TaskAppEventType(StrEnum):
    COMPLETED = "completed"
    PARTIAL_COMPLETED = "partial_completed"
    FAILED = "failed"
    NOT_FOUND = "not_found"


class TaskEventMessage(BaseAppEventMessage):
    """Один элемент ``messages`` в ответе GET ``/events/tasks``."""

    task_id: uuid.UUID = Field(description="Идентификатор главной задачи")
    reg_number: str = Field(description="Госномер транспортного средства")
    completed_at: datetime = Field(description="Момент завершения задачи (UTC)")


class TaskEventsResponse(BaseAppEventMessagesResponse[TaskEventMessage]):
    """Long-poll: ``messages`` + ``nextOffset``."""


__all__ = [
    "Account",
    "AccountsResponse",
    "PoliciesResponse",
    "Policy",
    "Task",
    "TaskAppEventType",
    "TaskEventMessage",
    "TaskEventsResponse",
    "TasksResponse",
    "TaskStep",
    "Vehicle",
    "VehiclesResponse",
]
