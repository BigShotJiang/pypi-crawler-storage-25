"""
Пример: GET ``/events/tasks`` — long-poll событий задач.

Запуск::

  python -m tp_common.clients.bsp.policy.examples.get_task_events
"""

from __future__ import annotations

from tp_common.clients.bsp.policy.client import BspPolicyClient
from tp_common.clients.bsp.policy.examples import demo_params
from tp_common.clients.bsp.policy.examples._runner import main
from tp_common.clients.bsp.policy.request import TaskEventsRequest


async def _call(client: BspPolicyClient) -> object:
    return await client.get_task_events(
        TaskEventsRequest(
            limit=demo_params.TASK_EVENTS_LIMIT,
            offset=demo_params.TASK_EVENTS_OFFSET,
            timeout=demo_params.TASK_EVENTS_TIMEOUT,
        ),
        http_timeout=demo_params.TASK_EVENTS_HTTP_TIMEOUT,
    )


if __name__ == "__main__":
    main(_call)
