"""Примеры вызовов BspPolicyClient."""
