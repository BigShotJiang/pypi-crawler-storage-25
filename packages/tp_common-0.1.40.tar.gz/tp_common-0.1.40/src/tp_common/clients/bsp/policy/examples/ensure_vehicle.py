"""
Пример: POST ``/vehicles`` — ТС и цепочка проверки ОСАГО.

Запуск::

  python -m tp_common.clients.bsp.policy.examples.ensure_vehicle
"""

from __future__ import annotations

from tp_common.clients.bsp.policy.client import BspPolicyClient
from tp_common.clients.bsp.policy.examples import demo_params
from tp_common.clients.bsp.policy.examples._runner import main
from tp_common.clients.bsp.policy.request import VehicleEnsureRequest


async def _call(client: BspPolicyClient) -> object:
    return await client.ensure_vehicle(
        VehicleEnsureRequest(reg_number=demo_params.REG_NUMBER)
    )


if __name__ == "__main__":
    main(_call)
