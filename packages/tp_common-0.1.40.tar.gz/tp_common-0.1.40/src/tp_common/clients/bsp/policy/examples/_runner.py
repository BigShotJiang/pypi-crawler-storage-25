"""Общий запуск примеров: клиент из окружения, JSON на stdout."""

from __future__ import annotations

import asyncio
import json
import sys
from collections.abc import Awaitable, Callable
from typing import Any

from tp_common.clients.bsp.policy.client import BspPolicyClient
from tp_common.clients.bsp.policy.examples.create_client import create_policy_client


async def run_example(
    call: Callable[[BspPolicyClient], Awaitable[Any]],
) -> None:
    try:
        client = create_policy_client()
    except ValueError as error:
        print(error, file=sys.stderr)
        raise SystemExit(2) from error

    async with client:
        result = await call(client)
        if result is None:
            payload: dict[str, str] = {"status": "ok"}
            print(json.dumps(payload, indent=2, ensure_ascii=False))
        else:
            print(
                json.dumps(result.model_dump(mode="json"), indent=2, ensure_ascii=False)
            )


def main(call: Callable[[BspPolicyClient], Awaitable[Any]]) -> None:
    asyncio.run(run_example(call))
