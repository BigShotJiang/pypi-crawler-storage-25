"""
Пример: PATCH ``/vehicles/sync`` — синхронизация списка ГРЗ.

Запуск::

  python -m tp_common.clients.bsp.policy.examples.sync_vehicles
"""

from __future__ import annotations

from tp_common.clients.bsp.policy.client import BspPolicyClient
from tp_common.clients.bsp.policy.examples import demo_params
from tp_common.clients.bsp.policy.examples._runner import main
from tp_common.clients.bsp.policy.request import VehicleSyncRequest


async def _call(client: BspPolicyClient) -> object:
    await client.sync_vehicles(
        VehicleSyncRequest(reg_numbers=list(demo_params.SYNC_REG_NUMBERS))
    )
    return None


if __name__ == "__main__":
    main(_call)
