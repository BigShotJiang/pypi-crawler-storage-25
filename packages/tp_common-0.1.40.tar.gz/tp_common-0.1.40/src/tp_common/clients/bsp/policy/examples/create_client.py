"""Создание BspPolicyClient для примеров (переменные окружения, .env рядом с примерами)."""

from __future__ import annotations

import os
from pathlib import Path

from tp_common.clients.bsp.policy.client import BspPolicyClient
from tp_common.tp_logger.schemas import EnvironmentType
from tp_common.tp_logger.tp_logging import TpLoggerFactory
from tp_common.utils import find_env_file, load_env_file


def _env_type_from_os() -> EnvironmentType:
    raw = os.getenv("ENV_TYPE", "").strip().lower()
    if not raw:
        return EnvironmentType.DEV
    try:
        return EnvironmentType(raw)
    except ValueError:
        return EnvironmentType.DEV


def create_policy_client(
    *,
    keycloak_url: str | None = None,
    policy_url: str | None = None,
    logger_name: str = "bsp_policy_examples",
) -> BspPolicyClient:
    """Собирает HTTP-клиент из окружения.

    Переменные:
      POLICY_KEYCLOAK_URL или KEYCLOAK_URL — URL Keycloak с учётными данными.
      POLICY_URL — опционально, иначе базовый URL по ``ENV_TYPE``.
      ENV_TYPE — local | dev | staging | prod (по умолчанию dev).
    """
    _env_path = find_env_file(anchor=Path(__file__))
    if _env_path:
        load_env_file(_env_path)

    url = (
        keycloak_url
        or os.getenv("POLICY_KEYCLOAK_URL", "").strip()
        or os.getenv("KEYCLOAK_URL", "").strip()
    )
    if not url:
        raise ValueError(
            "Укажите POLICY_KEYCLOAK_URL или KEYCLOAK_URL, например:\n"
            "  https://my_client:secret@keycloak.example.com"
        )

    resolved_url = policy_url
    if resolved_url is None:
        from_env = os.getenv("POLICY_URL", "").strip()
        resolved_url = from_env or None

    env_type = _env_type_from_os()
    logger = TpLoggerFactory(env_type).get_logger(logger_name, use_queue=False)

    return BspPolicyClient(
        logger=logger,
        keycloak_url=url,
        env_type=env_type,
        policy_url=resolved_url,
    )
