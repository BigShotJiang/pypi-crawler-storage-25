"""
Пример: POST ``/accounts`` — создать учётную запись Autoins.

Запуск::

  python -m tp_common.clients.bsp.policy.examples.create_account
"""

from __future__ import annotations

from tp_common.clients.bsp.policy.client import BspPolicyClient
from tp_common.clients.bsp.policy.examples import demo_params
from tp_common.clients.bsp.policy.examples._runner import main
from tp_common.clients.bsp.policy.request import AccountCreateRequest


async def _call(client: BspPolicyClient) -> object:
    return await client.create_account(
        AccountCreateRequest(user_id=demo_params.ACCOUNT_USER_ID)
    )


if __name__ == "__main__":
    main(_call)
