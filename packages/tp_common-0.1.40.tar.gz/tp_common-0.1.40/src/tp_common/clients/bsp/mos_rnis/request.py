"""Схемы запросов HTTP-клиента bsp-mos-rnis.

Зеркалят ``bsp-mos-rnis/src/api/v1/*/request.py``; при изменении API сервиса
схемы нужно синхронизировать здесь.
"""

from __future__ import annotations

import uuid
from enum import StrEnum

from pydantic import Field, field_validator

from tp_common.route.camel_case_enum import CamelCaseEnum
from tp_common.route.schemes import (
    BaseAppEventMessagesQueryParams,
    BaseQueryRequest,
    BaseRequest,
)


class TaskStatus(StrEnum):
    PENDING = "pending"
    PROCESSING = "processing"
    COMPLETED = "completed"
    ERROR = "error"


class TasksSortBy(CamelCaseEnum, StrEnum):
    TASK_ID = "task_id"
    REG_NUMBER = "reg_number"
    STATUS = "status"
    PRIORITY = "priority"
    LOCKED_AT = "locked_at"
    LOCKED_BY = "locked_by"
    ERROR_MESSAGE = "error_message"
    FOUND_TERMINAL_COUNT = "found_terminal_count"
    COMPLETED_AT = "completed_at"
    CREATED_AT = "created_at"
    UPDATED_AT = "updated_at"


class TasksRequest(BaseQueryRequest[TasksSortBy]):
    """GET ``/tasks`` — поиск задач загрузки РНИС."""

    reg_number: str | None = Field(
        default=None,
        min_length=4,
        max_length=32,
        description="Государственный регистрационный знак (основной фильтр)",
    )
    task_id: uuid.UUID | None = Field(
        default=None,
        description="Дополнительный фильтр по идентификатору задачи",
    )
    status: TaskStatus | None = Field(
        default=None,
        description="Фильтр по статусу задачи",
    )
    is_completed: bool | None = Field(
        default=None,
        description="True — только завершённые; False — только незавершённые",
    )

    @field_validator("reg_number")
    @classmethod
    def normalize_reg_number(cls, value: str | None) -> str | None:
        if value is None:
            return None
        normalized = value.strip().upper()
        return normalized or None


class TerminalsRequest(BaseRequest):
    """GET ``/terminals`` — полный список терминалов по ГРЗ."""

    reg_number: str = Field(
        min_length=4,
        max_length=32,
        description="Государственный регистрационный знак",
    )

    @field_validator("reg_number")
    @classmethod
    def normalize_reg_number(cls, value: str) -> str:
        return value.strip().upper()


class VehicleGetRequest(BaseRequest):
    """GET ``/vehicles`` — снимок ТС по ГРЗ (без постановки задачи)."""

    reg_number: str = Field(
        min_length=4,
        max_length=32,
        description="Государственный регистрационный знак",
    )

    @field_validator("reg_number")
    @classmethod
    def normalize_reg_number(cls, value: str) -> str:
        return value.strip().upper()


class VehicleCreateRequest(BaseRequest):
    """POST ``/vehicles`` — ТС и задача на загрузку."""

    reg_number: str = Field(
        min_length=4,
        max_length=32,
        description="Государственный регистрационный знак",
    )


class VehicleSyncRequest(BaseRequest):
    """POST ``/vehicles/sync`` — синхронизация списка ГРЗ."""

    reg_numbers: list[str] = Field(
        min_length=1,
        description="Полный желаемый список ГРЗ",
    )


class AccountCreateRequest(BaseRequest):
    """POST ``/accounts`` — прокси в bsp-mos-account (``enable_rnis`` на сервере)."""

    login: str = Field(description="Логин кабинета", max_length=255)
    password: str = Field(description="Пароль кабинета", max_length=255)
    proxy: str | None = Field(
        default=None,
        max_length=255,
        description="Прокси: протокол://логин:пароль@IP-адрес:порт",
    )


class TaskEventsRequest(BaseAppEventMessagesQueryParams):
    """Query GET ``/events/tasks`` (long-poll Kafka ``bsp-mos-rnis.events.v1.tasks.<service_id>``)."""
