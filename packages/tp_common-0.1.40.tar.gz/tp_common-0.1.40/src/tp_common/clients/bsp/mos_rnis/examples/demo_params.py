"""Демо-параметры примеров bsp-mos-rnis: значения в коде.

Пароль аккаунта — единственное поле из окружения (``MOS_RNIS_ACCOUNT_PASSWORD``).
Keycloak и базовый URL — в ``create_client`` (``MOS_RNIS_KEYCLOAK_URL``, ``MOS_RNIS_URL``).
"""

from __future__ import annotations

import os
import uuid

from dplex.internal.sort import Order

from tp_common.clients.bsp.mos_rnis.request import TasksSortBy, TaskStatus

# --- ТС / задачи / терминалы ---

REG_NUMBER = "В524КЕ797"
REG_NUMBER_EXTRA = "Р997МТ716"

SYNC_REG_NUMBERS = [REG_NUMBER, REG_NUMBER_EXTRA]

# --- GET /tasks ---

TASK_LIST_REG_NUMBER: str | None = REG_NUMBER
TASK_LIST_TASK_ID: uuid.UUID | None = None
TASK_LIST_STATUS: TaskStatus | None = None
TASK_LIST_IS_COMPLETED: bool | None = None
TASK_LIST_LIMIT = 20
TASK_LIST_OFFSET = 0
TASK_LIST_SORT = Order.DESC
TASK_LIST_SORT_BY: TasksSortBy | None = TasksSortBy.CREATED_AT

# --- GET /terminals ---

TERMINALS_REG_NUMBER = REG_NUMBER

# --- GET /events/tasks ---

TASK_EVENTS_LIMIT = 10
TASK_EVENTS_OFFSET: int | None = None
TASK_EVENTS_TIMEOUT = 25.0
TASK_EVENTS_HTTP_TIMEOUT = 120.0

# --- POST /accounts ---

ACCOUNT_LOGIN = "79130858525"
ACCOUNT_PROXY: str | None = None


def account_password() -> str:
    value = os.getenv("MOS_RNIS_ACCOUNT_PASSWORD", "").strip()
    if not value:
        msg = (
            "Задайте MOS_RNIS_ACCOUNT_PASSWORD для примера create_account, например:\n"
            "  set MOS_RNIS_ACCOUNT_PASSWORD=secret"
        )
        raise ValueError(msg)
    return value
