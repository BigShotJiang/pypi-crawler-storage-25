"""
FMU probe result models.

These models define the contract for FMU probing operations - extracting
metadata from modelDescription.xml. Probe results feed into SignalDefinition
rows in the core Django app.

Probing is done in-process in the Django worker (not in containers) since
it's just XML parsing with no FMU execution.
"""

from __future__ import annotations

from typing import Literal

from pydantic import BaseModel, ConfigDict, Field


class FMUVariableMeta(BaseModel):
    """Metadata extracted from modelDescription.xml."""

    model_config = ConfigDict(extra="forbid")

    name: str
    causality: str
    variability: str | None = None
    value_reference: int = 0
    value_type: str
    unit: str | None = None


class FMUProbeResult(BaseModel):
    """Result of a short probe run to vet an FMU before approval."""

    model_config = ConfigDict(extra="forbid")

    status: Literal["success", "error"] = "error"
    variables: list[FMUVariableMeta] = Field(default_factory=list)
    errors: list[str] = Field(default_factory=list)
    messages: list[str] = Field(default_factory=list)
    execution_seconds: float | None = None

    @classmethod
    def success(
        cls,
        *,
        variables: list[FMUVariableMeta],
        execution_seconds: float | None = None,
        messages: list[str] | None = None,
    ) -> FMUProbeResult:
        return cls(
            status="success",
            variables=variables,
            execution_seconds=execution_seconds,
            messages=messages or [],
            errors=[],
        )

    @classmethod
    def failure(
        cls,
        *,
        errors: list[str],
        messages: list[str] | None = None,
    ) -> FMUProbeResult:
        return cls(
            status="error",
            variables=[],
            errors=errors,
            messages=messages or [],
        )
