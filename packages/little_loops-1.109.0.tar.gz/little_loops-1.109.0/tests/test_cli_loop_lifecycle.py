"""Tests for cli/loop/lifecycle.py - status, stop, resume commands."""

from __future__ import annotations

import argparse
import json
import os
import signal
import time
from datetime import UTC
from pathlib import Path
from unittest.mock import MagicMock, patch

import pytest

from little_loops.cli.loop.lifecycle import (
    _format_relative_time,
    cmd_resume,
    cmd_status,
    cmd_stop,
)
from little_loops.fsm.persistence import LoopState


class TestCmdStatus:
    """Tests for cmd_status."""

    def test_no_state_returns_1(self, tmp_path: Path) -> None:
        """Returns 1 when no state found."""
        logger = MagicMock()

        with patch("little_loops.fsm.persistence.StatePersistence") as mock_cls:
            mock_cls.return_value.load_state.return_value = None
            result = cmd_status("test-loop", tmp_path, logger)

        assert result == 1
        logger.error.assert_called_once()

    def test_status_prints_state(self, tmp_path: Path) -> None:
        """Prints state information when found."""
        logger = MagicMock()
        mock_state = MagicMock()
        mock_state.loop_name = "test-loop"
        mock_state.status = "running"
        mock_state.current_state = "check"
        mock_state.iteration = 5
        mock_state.started_at = "2026-02-14T10:00:00"
        mock_state.updated_at = "2026-02-14T10:05:00"
        mock_state.continuation_prompt = None
        mock_state.pid = None

        with (
            patch(
                "little_loops.cli.loop.lifecycle._find_instances", return_value=[(None, mock_state)]
            ),
            patch("builtins.print") as mock_print,
        ):
            result = cmd_status("test-loop", tmp_path, logger)

        assert result == 0
        print_calls = [str(c) for c in mock_print.call_args_list]
        print_text = " ".join(print_calls)
        assert "test-loop" in print_text
        assert "running" in print_text

    def test_status_with_continuation_prompt(self, tmp_path: Path) -> None:
        """Shows truncated continuation prompt when present."""
        logger = MagicMock()
        mock_state = MagicMock()
        mock_state.loop_name = "test-loop"
        mock_state.status = "awaiting_continuation"
        mock_state.current_state = "check"
        mock_state.iteration = 3
        mock_state.started_at = "2026-02-14T10:00:00"
        mock_state.updated_at = "2026-02-14T10:05:00"
        mock_state.continuation_prompt = "A" * 300  # Long prompt

        with (
            patch(
                "little_loops.cli.loop.lifecycle._find_instances", return_value=[(None, mock_state)]
            ),
            patch("builtins.print") as mock_print,
        ):
            result = cmd_status("test-loop", tmp_path, logger)

        assert result == 0
        print_calls = [str(c) for c in mock_print.call_args_list]
        print_text = " ".join(print_calls)
        assert "..." in print_text  # Truncated


class TestCmdStop:
    """Tests for cmd_stop."""

    def test_no_state_returns_1(self, tmp_path: Path) -> None:
        """Returns 1 when no state found."""
        logger = MagicMock()

        with patch("little_loops.fsm.persistence.StatePersistence") as mock_cls:
            mock_cls.return_value.load_state.return_value = None
            result = cmd_stop("test-loop", tmp_path, logger)

        assert result == 1

    def test_not_running_returns_1(self, tmp_path: Path) -> None:
        """Returns 1 when loop is not running."""
        logger = MagicMock()
        mock_state = MagicMock()
        mock_state.status = "completed"

        with patch("little_loops.fsm.persistence.StatePersistence") as mock_cls:
            mock_cls.return_value.load_state.return_value = mock_state
            result = cmd_stop("test-loop", tmp_path, logger)

        assert result == 1
        logger.error.assert_called_once()

    def test_running_loop_stopped(self, tmp_path: Path) -> None:
        """Successfully stops a running loop."""
        logger = MagicMock()
        mock_state = MagicMock()
        mock_state.status = "running"

        with (
            patch(
                "little_loops.cli.loop.lifecycle._find_instances", return_value=[(None, mock_state)]
            ),
            patch("little_loops.fsm.persistence.StatePersistence") as mock_cls,
        ):
            mock_persistence = mock_cls.return_value
            result = cmd_stop("test-loop", tmp_path, logger)

        assert result == 0
        assert mock_state.status == "interrupted"
        mock_persistence.save_state.assert_called_once_with(mock_state)

    def test_stop_with_pid_sends_sigterm_and_waits(self, tmp_path: Path) -> None:
        """Sends SIGTERM and polls for exit when PID file exists (BUG-592)."""
        logger = MagicMock()
        mock_state = MagicMock()
        mock_state.status = "running"

        running_dir = tmp_path / ".running"
        running_dir.mkdir()
        pid_file = running_dir / "test-loop.pid"
        pid_file.write_text("12345")

        # Process alive on first check, dead after SIGTERM poll
        alive_seq = [True, True, False]

        with (
            patch(
                "little_loops.cli.loop.lifecycle._find_instances", return_value=[(None, mock_state)]
            ),
            patch("little_loops.fsm.persistence.StatePersistence") as mock_cls,
            patch("little_loops.cli.loop.lifecycle._process_alive", side_effect=alive_seq),
            patch("little_loops.cli.loop.lifecycle.os.kill") as mock_kill,
            patch("little_loops.cli.loop.lifecycle.time.sleep"),
        ):
            result = cmd_stop("test-loop", tmp_path, logger)

        assert result == 0
        mock_kill.assert_any_call(12345, signal.SIGTERM)
        assert mock_state.status == "interrupted"
        mock_cls.return_value.save_state.assert_called_once_with(mock_state)
        assert not pid_file.exists(), "PID file should be removed after SIGTERM stop"

    def test_stop_sends_sigkill_if_process_does_not_exit(self, tmp_path: Path) -> None:
        """Escalates to SIGKILL after grace period if process does not exit (BUG-592)."""
        logger = MagicMock()
        mock_state = MagicMock()
        mock_state.status = "running"

        running_dir = tmp_path / ".running"
        running_dir.mkdir()
        pid_file = running_dir / "test-loop.pid"
        pid_file.write_text("12345")

        # Process stays alive through all polls: first check (alive) + 10 poll iterations
        alive_seq = [True] + [True] * 10

        with (
            patch(
                "little_loops.cli.loop.lifecycle._find_instances", return_value=[(None, mock_state)]
            ),
            patch("little_loops.fsm.persistence.StatePersistence"),
            patch("little_loops.cli.loop.lifecycle._process_alive", side_effect=alive_seq),
            patch("little_loops.cli.loop.lifecycle.os.kill") as mock_kill,
            patch("little_loops.cli.loop.lifecycle.time.sleep"),
        ):
            result = cmd_stop("test-loop", tmp_path, logger)

        assert result == 0
        mock_kill.assert_any_call(12345, signal.SIGTERM)
        mock_kill.assert_any_call(12345, signal.SIGKILL)
        logger.warning.assert_called_once()
        assert mock_state.status == "interrupted"
        assert not pid_file.exists(), "PID file should be removed after SIGKILL stop"

    def test_stop_sigkill_handles_race_if_process_exits_between_poll_and_kill(
        self, tmp_path: Path
    ) -> None:
        """OSError on SIGKILL is swallowed when process exits just before the kill (BUG-592)."""
        logger = MagicMock()
        mock_state = MagicMock()
        mock_state.status = "running"

        running_dir = tmp_path / ".running"
        running_dir.mkdir()
        pid_file = running_dir / "test-loop.pid"
        pid_file.write_text("12345")

        alive_seq = [True] + [True] * 10

        def kill_side_effect(pid: int, sig: int) -> None:
            if sig == signal.SIGKILL:
                raise OSError("No such process")

        with (
            patch(
                "little_loops.cli.loop.lifecycle._find_instances", return_value=[(None, mock_state)]
            ),
            patch("little_loops.fsm.persistence.StatePersistence"),
            patch("little_loops.cli.loop.lifecycle._process_alive", side_effect=alive_seq),
            patch("little_loops.cli.loop.lifecycle.os.kill", side_effect=kill_side_effect),
            patch("little_loops.cli.loop.lifecycle.time.sleep"),
        ):
            result = cmd_stop("test-loop", tmp_path, logger)

        assert result == 0  # No exception propagated
        assert mock_state.status == "interrupted"
        assert not pid_file.exists(), "PID file should be removed even when SIGKILL raises OSError"

    def test_stop_interrupted_with_live_lock_pid_kills_process_and_removes_lock(
        self, tmp_path: Path
    ) -> None:
        """Kills orphaned lock holder and returns 0 when interrupted state has live lock PID (BUG-1353)."""
        import json as _json

        logger = MagicMock()
        mock_state = MagicMock()
        mock_state.status = "interrupted"

        running_dir = tmp_path / ".running"
        running_dir.mkdir()
        lock_file = running_dir / "test-loop.lock"
        lock_file.write_text(
            _json.dumps(
                {
                    "loop_name": "test-loop",
                    "scope": ["/tmp"],
                    "pid": 58522,
                    "started_at": "2026-05-03T10:00:00Z",
                }
            )
        )

        # alive check in orphaned-lock branch, then poll in _kill_with_timeout (dies on first poll)
        alive_seq = [True, False]

        with (
            patch(
                "little_loops.cli.loop.lifecycle._find_instances", return_value=[(None, mock_state)]
            ),
            patch("little_loops.cli.loop.lifecycle._process_alive", side_effect=alive_seq),
            patch("little_loops.cli.loop.lifecycle.os.kill") as mock_kill,
            patch("little_loops.cli.loop.lifecycle.time.sleep"),
        ):
            result = cmd_stop("test-loop", tmp_path, logger)

        assert result == 0
        mock_kill.assert_called_once_with(58522, signal.SIGTERM)
        assert not lock_file.exists(), "Lock file should be removed after killing orphaned holder"
        logger.warning.assert_called_once()
        logger.success.assert_called_once()

    def test_stop_interrupted_with_dead_lock_pid_removes_stale_lock_exits_0(
        self, tmp_path: Path
    ) -> None:
        """Removes stale lock file and returns 0 when interrupted state has dead lock PID (BUG-1353)."""
        import json as _json

        logger = MagicMock()
        mock_state = MagicMock()
        mock_state.status = "interrupted"

        running_dir = tmp_path / ".running"
        running_dir.mkdir()
        lock_file = running_dir / "test-loop.lock"
        lock_file.write_text(
            _json.dumps(
                {
                    "loop_name": "test-loop",
                    "scope": ["/tmp"],
                    "pid": 99999,
                    "started_at": "2026-05-03T10:00:00Z",
                }
            )
        )

        with (
            patch(
                "little_loops.cli.loop.lifecycle._find_instances", return_value=[(None, mock_state)]
            ),
            patch("little_loops.cli.loop.lifecycle._process_alive", return_value=False),
        ):
            result = cmd_stop("test-loop", tmp_path, logger)

        assert result == 0
        assert not lock_file.exists(), "Stale lock file should be removed"
        logger.info.assert_called_once()

    def test_stop_interrupted_with_no_lock_file_returns_error(self, tmp_path: Path) -> None:
        """Returns error when interrupted state has no lock file (unchanged behavior, BUG-1353)."""
        logger = MagicMock()
        mock_state = MagicMock()
        mock_state.status = "interrupted"

        running_dir = tmp_path / ".running"
        running_dir.mkdir()

        with patch(
            "little_loops.cli.loop.lifecycle._find_instances", return_value=[(None, mock_state)]
        ):
            result = cmd_stop("test-loop", tmp_path, logger)

        assert result == 1
        logger.error.assert_called_once()


class TestCmdResume:
    """Tests for cmd_resume."""

    def test_file_not_found_returns_1(self, tmp_path: Path) -> None:
        """Returns 1 when loop file not found."""
        logger = MagicMock()
        args = argparse.Namespace()

        with patch(
            "little_loops.cli.loop.lifecycle.load_loop",
            side_effect=FileNotFoundError("Not found"),
        ):
            result = cmd_resume("test-loop", args, tmp_path, logger)

        assert result == 1
        logger.error.assert_called_once()

    def test_validation_error_returns_1(self, tmp_path: Path) -> None:
        """Returns 1 when loop has validation errors."""
        logger = MagicMock()
        args = argparse.Namespace()

        with patch(
            "little_loops.cli.loop.lifecycle.load_loop",
            side_effect=ValueError("Invalid FSM"),
        ):
            result = cmd_resume("test-loop", args, tmp_path, logger)

        assert result == 1

    def test_nothing_to_resume_returns_1(self, tmp_path: Path) -> None:
        """Returns 1 when nothing to resume."""
        logger = MagicMock()
        args = argparse.Namespace()
        mock_fsm = MagicMock()

        with (
            patch(
                "little_loops.cli.loop.lifecycle.load_loop",
                return_value=mock_fsm,
            ),
            patch("little_loops.fsm.persistence.StatePersistence") as mock_persist_cls,
            patch("little_loops.fsm.persistence.PersistentExecutor") as mock_exec_cls,
        ):
            mock_persist_cls.return_value.load_state.return_value = None
            mock_exec_cls.return_value.resume.return_value = None
            result = cmd_resume("test-loop", args, tmp_path, logger)

        assert result == 1

    def test_resume_success(self, tmp_path: Path) -> None:
        """Returns 0 on successful terminal resume."""
        logger = MagicMock()
        args = argparse.Namespace()
        mock_fsm = MagicMock()

        mock_result = MagicMock()
        mock_result.final_state = "done"
        mock_result.iterations = 5
        mock_result.duration_ms = 30000  # 30 seconds
        mock_result.terminated_by = "terminal"

        with (
            patch(
                "little_loops.cli.loop.lifecycle.load_loop",
                return_value=mock_fsm,
            ),
            patch("little_loops.fsm.persistence.StatePersistence") as mock_persist_cls,
            patch("little_loops.fsm.persistence.PersistentExecutor") as mock_exec_cls,
        ):
            mock_persist_cls.return_value.load_state.return_value = None
            mock_exec_cls.return_value.resume.return_value = mock_result
            result = cmd_resume("test-loop", args, tmp_path, logger)

        assert result == 0

    def test_resume_with_minutes_duration(
        self, tmp_path: Path, capsys: pytest.CaptureFixture[str]
    ) -> None:
        """Duration is formatted in minutes when >= 60s.

        After BUG-1645, the completion line is printed by run_foreground via
        ``print()`` rather than emitted by ``logger.success``, so we assert on
        captured stdout instead of the logger mock.
        """
        logger = MagicMock()
        args = argparse.Namespace()
        mock_fsm = MagicMock()
        mock_fsm.name = "test-loop"
        mock_fsm.max_iterations = 10

        mock_result = MagicMock()
        mock_result.final_state = "done"
        mock_result.iterations = 10
        mock_result.duration_ms = 120000  # 2 minutes
        mock_result.terminated_by = "terminal"

        with (
            patch(
                "little_loops.cli.loop.lifecycle.load_loop",
                return_value=mock_fsm,
            ),
            patch("little_loops.fsm.persistence.StatePersistence") as mock_persist_cls,
            patch("little_loops.fsm.persistence.PersistentExecutor") as mock_exec_cls,
        ):
            mock_persist_cls.return_value.load_state.return_value = None
            mock_exec_cls.return_value.resume.return_value = mock_result
            result = cmd_resume("test-loop", args, tmp_path, logger)

        assert result == 0
        out = capsys.readouterr().out
        assert "2m" in out
        assert "Resumed and completed" in out

    def test_resume_awaiting_continuation(self, tmp_path: Path) -> None:
        """Shows context when resuming from awaiting_continuation."""
        logger = MagicMock()
        args = argparse.Namespace()
        mock_fsm = MagicMock()

        mock_state = MagicMock()
        mock_state.status = "awaiting_continuation"
        mock_state.iteration = 5
        mock_state.continuation_prompt = "A" * 600  # Long prompt

        mock_result = MagicMock()
        mock_result.final_state = "done"
        mock_result.iterations = 8
        mock_result.duration_ms = 5000
        mock_result.terminated_by = "terminal"

        with (
            patch(
                "little_loops.cli.loop.lifecycle.load_loop",
                return_value=mock_fsm,
            ),
            patch(
                "little_loops.cli.loop.lifecycle._find_instances", return_value=[(None, mock_state)]
            ),
            patch("little_loops.fsm.persistence.PersistentExecutor") as mock_exec_cls,
            patch("builtins.print") as mock_print,
        ):
            mock_exec_cls.return_value.resume.return_value = mock_result
            result = cmd_resume("test-loop", args, tmp_path, logger)

        assert result == 0
        print_calls = [str(c) for c in mock_print.call_args_list]
        print_text = " ".join(print_calls)
        assert "..." in print_text  # Truncated prompt
        assert "Resuming from context handoff" in print_text

    def test_resume_non_terminal_returns_1(self, tmp_path: Path) -> None:
        """Returns 1 when resumed loop didn't reach terminal state."""
        logger = MagicMock()
        args = argparse.Namespace()
        mock_fsm = MagicMock()

        mock_result = MagicMock()
        mock_result.final_state = "error"
        mock_result.iterations = 5
        mock_result.duration_ms = 10000
        mock_result.terminated_by = "max_iterations"

        with (
            patch(
                "little_loops.cli.loop.lifecycle.load_loop",
                return_value=mock_fsm,
            ),
            patch("little_loops.fsm.persistence.StatePersistence") as mock_persist_cls,
            patch("little_loops.fsm.persistence.PersistentExecutor") as mock_exec_cls,
        ):
            mock_persist_cls.return_value.load_state.return_value = None
            mock_exec_cls.return_value.resume.return_value = mock_result
            result = cmd_resume("test-loop", args, tmp_path, logger)

        assert result == 1

    def test_resume_registers_signal_handlers(self, tmp_path: Path) -> None:
        """cmd_resume registers SIGINT/SIGTERM handlers before calling resume (BUG-600)."""
        logger = MagicMock()
        args = argparse.Namespace()
        mock_fsm = MagicMock()

        mock_result = MagicMock()
        mock_result.final_state = "done"
        mock_result.iterations = 3
        mock_result.duration_ms = 5000
        mock_result.terminated_by = "terminal"

        with (
            patch(
                "little_loops.cli.loop.lifecycle.load_loop",
                return_value=mock_fsm,
            ),
            patch("little_loops.fsm.persistence.StatePersistence") as mock_persist_cls,
            patch("little_loops.fsm.persistence.PersistentExecutor") as mock_exec_cls,
            patch("little_loops.cli.loop.lifecycle.register_loop_signal_handlers") as mock_register,
        ):
            mock_persist_cls.return_value.load_state.return_value = None
            mock_exec_cls.return_value.resume.return_value = mock_result
            result = cmd_resume("test-loop", args, tmp_path, logger)

        assert result == 0
        expected_pid_file = tmp_path / ".running" / "test-loop.pid"
        mock_register.assert_called_once_with(
            mock_exec_cls.return_value, pid_file=expected_pid_file
        )

    def test_resume_wires_display_callback_to_event_bus(self, tmp_path: Path) -> None:
        """cmd_resume registers display_progress on executor.event_bus (BUG-1645).

        Regression guard: before BUG-1645 the resume path called executor.resume()
        directly without registering any event subscriber, so the terminal stayed
        silent for the entire run. Routing through run_foreground must register at
        least one subscriber on the executor's event bus.
        """
        logger = MagicMock()
        args = argparse.Namespace()
        mock_fsm = MagicMock()
        mock_fsm.name = "test-loop"
        mock_fsm.max_iterations = 5

        mock_result = MagicMock()
        mock_result.final_state = "done"
        mock_result.iterations = 3
        mock_result.duration_ms = 5000
        mock_result.terminated_by = "terminal"

        with (
            patch(
                "little_loops.cli.loop.lifecycle.load_loop",
                return_value=mock_fsm,
            ),
            patch("little_loops.fsm.persistence.StatePersistence") as mock_persist_cls,
            patch("little_loops.fsm.persistence.PersistentExecutor") as mock_exec_cls,
        ):
            mock_persist_cls.return_value.load_state.return_value = None
            mock_exec_cls.return_value.resume.return_value = mock_result
            result = cmd_resume("test-loop", args, tmp_path, logger)

        assert result == 0
        # event_bus.register must have been called with the display closure.
        assert mock_exec_cls.return_value.event_bus.register.call_count >= 1

    def test_context_overrides_applied_to_fsm(self, tmp_path: Path) -> None:
        """--context KEY=VALUE overrides are applied to fsm.context before execution."""
        logger = MagicMock()
        args = argparse.Namespace(context=["issue_id=042", "mode=fast"])
        mock_fsm = MagicMock()
        mock_fsm.context = {"issue_id": "001"}

        mock_result = MagicMock()
        mock_result.final_state = "done"
        mock_result.iterations = 1
        mock_result.duration_ms = 1000
        mock_result.terminated_by = "terminal"

        with (
            patch("little_loops.cli.loop.lifecycle.load_loop", return_value=mock_fsm),
            patch("little_loops.fsm.persistence.StatePersistence") as mock_persist_cls,
            patch("little_loops.fsm.persistence.PersistentExecutor") as mock_exec_cls,
        ):
            mock_persist_cls.return_value.load_state.return_value = None
            mock_exec_cls.return_value.resume.return_value = mock_result
            result = cmd_resume("test-loop", args, tmp_path, logger)

        assert result == 0
        assert mock_fsm.context["issue_id"] == "042"
        assert mock_fsm.context["mode"] == "fast"

    def test_context_invalid_format_raises_system_exit(self, tmp_path: Path) -> None:
        """--context value missing '=' raises SystemExit with clear message."""
        logger = MagicMock()
        args = argparse.Namespace(context=["badvalue"])
        mock_fsm = MagicMock()
        mock_fsm.context = {}

        with (
            patch("little_loops.cli.loop.lifecycle.load_loop", return_value=mock_fsm),
            patch("little_loops.fsm.persistence.StatePersistence") as mock_persist_cls,
        ):
            mock_persist_cls.return_value.load_state.return_value = None
            with pytest.raises(SystemExit) as exc_info:
                cmd_resume("test-loop", args, tmp_path, logger)

        assert "KEY=VALUE" in str(exc_info.value)

    def test_resume_signal_handler_triggers_graceful_shutdown(self, tmp_path: Path) -> None:
        """Ctrl-C during resume calls request_shutdown() instead of raising KeyboardInterrupt."""
        from little_loops.cli.loop._helpers import _loop_signal_handler

        mock_executor = MagicMock()

        import little_loops.cli.loop._helpers as _h

        _h._loop_shutdown_requested = False
        _h._loop_executor = mock_executor
        _h._loop_pid_file = None
        _h._using_alt_screen = False

        # Simulate first Ctrl-C (SIGINT)
        _loop_signal_handler(signal.SIGINT, None)

        mock_executor.request_shutdown.assert_called_once()


class TestCmdResumeBackground:
    """Tests for cmd_resume --background flag (FEAT-608)."""

    def test_background_flag_calls_run_background(self, tmp_path: Path) -> None:
        """--background flag delegates to run_background() with subcommand='resume'."""
        logger = MagicMock()
        args = argparse.Namespace(background=True)

        with patch("little_loops.cli.loop.lifecycle.run_background") as mock_rb:
            mock_rb.return_value = 0
            result = cmd_resume("test-loop", args, tmp_path, logger)

        assert result == 0
        mock_rb.assert_called_once_with("test-loop", args, tmp_path, subcommand="resume")

    def test_background_skips_foreground_execution(self, tmp_path: Path) -> None:
        """--background flag returns before calling executor.resume()."""
        logger = MagicMock()
        args = argparse.Namespace(background=True)

        with (
            patch("little_loops.cli.loop.lifecycle.run_background", return_value=0),
            patch("little_loops.cli.loop.lifecycle.load_loop") as mock_load,
        ):
            cmd_resume("test-loop", args, tmp_path, logger)

        mock_load.assert_not_called()

    def test_no_background_flag_runs_foreground(self, tmp_path: Path) -> None:
        """Without --background, resume runs in foreground (default unchanged)."""
        logger = MagicMock()
        args = argparse.Namespace()
        mock_fsm = MagicMock()
        mock_result = MagicMock()
        mock_result.final_state = "done"
        mock_result.iterations = 1
        mock_result.duration_ms = 1000
        mock_result.terminated_by = "terminal"

        with (
            patch("little_loops.cli.loop.lifecycle.load_loop", return_value=mock_fsm),
            patch("little_loops.fsm.persistence.StatePersistence") as mock_persist_cls,
            patch("little_loops.fsm.persistence.PersistentExecutor") as mock_exec_cls,
            patch("little_loops.cli.loop.lifecycle.run_background") as mock_rb,
        ):
            mock_persist_cls.return_value.load_state.return_value = None
            mock_exec_cls.return_value.resume.return_value = mock_result
            result = cmd_resume("test-loop", args, tmp_path, logger)

        assert result == 0
        mock_rb.assert_not_called()

    def test_foreground_internal_registers_pid_cleanup(self, tmp_path: Path) -> None:
        """--foreground-internal registers atexit PID cleanup for background-resumed process."""

        logger = MagicMock()
        args = argparse.Namespace(foreground_internal=True)
        mock_fsm = MagicMock()
        mock_result = MagicMock()
        mock_result.final_state = "done"
        mock_result.iterations = 1
        mock_result.duration_ms = 1000
        mock_result.terminated_by = "terminal"

        running_dir = tmp_path / ".running"
        running_dir.mkdir(parents=True)
        pid_file = running_dir / "test-loop.pid"
        pid_file.write_text("123")

        registered: list = []

        with (
            patch("little_loops.cli.loop.lifecycle.load_loop", return_value=mock_fsm),
            patch("little_loops.fsm.persistence.StatePersistence") as mock_persist_cls,
            patch("little_loops.fsm.persistence.PersistentExecutor") as mock_exec_cls,
            patch("little_loops.cli.loop.lifecycle.atexit.register", side_effect=registered.append),
        ):
            mock_persist_cls.return_value.load_state.return_value = None
            mock_exec_cls.return_value.resume.return_value = mock_result
            result = cmd_resume("test-loop", args, tmp_path, logger)

        assert result == 0
        assert len(registered) == 1  # PID cleanup was registered

    def test_plain_foreground_resume_writes_pid_file(self, tmp_path: Path) -> None:
        """Plain foreground resume writes a PID file so cmd_stop can send SIGTERM (BUG-639)."""
        logger = MagicMock()
        args = argparse.Namespace()  # no background, no foreground_internal
        mock_fsm = MagicMock()
        mock_result = MagicMock()
        mock_result.final_state = "done"
        mock_result.iterations = 1
        mock_result.duration_ms = 1000
        mock_result.terminated_by = "terminal"

        with (
            patch("little_loops.cli.loop.lifecycle.load_loop", return_value=mock_fsm),
            patch("little_loops.fsm.persistence.StatePersistence") as mock_persist_cls,
            patch("little_loops.fsm.persistence.PersistentExecutor") as mock_exec_cls,
            patch("little_loops.cli.loop.lifecycle.os.getpid", return_value=99999),
        ):
            mock_persist_cls.return_value.load_state.return_value = None
            mock_exec_cls.return_value.resume.return_value = mock_result
            result = cmd_resume("test-loop", args, tmp_path, logger)

        assert result == 0
        pid_file = tmp_path / ".running" / "test-loop.pid"
        assert pid_file.exists(), "PID file should be written for plain foreground resume (BUG-639)"
        assert pid_file.read_text() == "99999"

    def test_plain_foreground_resume_pid_passed_to_signal_handler(self, tmp_path: Path) -> None:
        """Signal handler receives the PID file so force-exit cleans it up (BUG-639)."""
        logger = MagicMock()
        args = argparse.Namespace()
        mock_fsm = MagicMock()
        mock_result = MagicMock()
        mock_result.final_state = "done"
        mock_result.iterations = 1
        mock_result.duration_ms = 1000
        mock_result.terminated_by = "terminal"

        with (
            patch("little_loops.cli.loop.lifecycle.load_loop", return_value=mock_fsm),
            patch("little_loops.fsm.persistence.StatePersistence") as mock_persist_cls,
            patch("little_loops.fsm.persistence.PersistentExecutor") as mock_exec_cls,
            patch("little_loops.cli.loop.lifecycle.register_loop_signal_handlers") as mock_reg,
        ):
            mock_persist_cls.return_value.load_state.return_value = None
            mock_exec_cls.return_value.resume.return_value = mock_result
            cmd_resume("test-loop", args, tmp_path, logger)

        expected_pid_file = tmp_path / ".running" / "test-loop.pid"
        mock_reg.assert_called_once_with(mock_exec_cls.return_value, pid_file=expected_pid_file)

    def test_foreground_internal_does_not_overwrite_parent_pid(self, tmp_path: Path) -> None:
        """--foreground-internal skips writing PID (parent wrote it); existing PID preserved (BUG-639)."""
        logger = MagicMock()
        args = argparse.Namespace(foreground_internal=True)
        mock_fsm = MagicMock()
        mock_result = MagicMock()
        mock_result.final_state = "done"
        mock_result.iterations = 1
        mock_result.duration_ms = 1000
        mock_result.terminated_by = "terminal"

        running_dir = tmp_path / ".running"
        running_dir.mkdir(parents=True)
        pid_file = running_dir / "test-loop.pid"
        pid_file.write_text("12345")  # Parent-written PID

        with (
            patch("little_loops.cli.loop.lifecycle.load_loop", return_value=mock_fsm),
            patch("little_loops.fsm.persistence.StatePersistence") as mock_persist_cls,
            patch("little_loops.fsm.persistence.PersistentExecutor") as mock_exec_cls,
            patch("little_loops.cli.loop.lifecycle.atexit.register"),
        ):
            mock_persist_cls.return_value.load_state.return_value = None
            mock_exec_cls.return_value.resume.return_value = mock_result
            cmd_resume("test-loop", args, tmp_path, logger)

        assert pid_file.read_text() == "12345", "Parent-written PID should not be overwritten"


class TestCmdResumeExitCodes:
    """Tests for cmd_resume exit code mapping per terminated_by value (BUG-605)."""

    def _resume_with_terminated_by(self, tmp_path: Path, terminated_by: str) -> int:
        logger = MagicMock()
        args = argparse.Namespace()
        mock_fsm = MagicMock()

        mock_result = MagicMock()
        mock_result.final_state = "done"
        mock_result.iterations = 1
        mock_result.duration_ms = 1000
        mock_result.terminated_by = terminated_by

        with (
            patch("little_loops.cli.loop.lifecycle.load_loop", return_value=mock_fsm),
            patch("little_loops.fsm.persistence.StatePersistence") as mock_persist_cls,
            patch("little_loops.fsm.persistence.PersistentExecutor") as mock_exec_cls,
        ):
            mock_persist_cls.return_value.load_state.return_value = None
            mock_exec_cls.return_value.resume.return_value = mock_result
            return cmd_resume("test-loop", args, tmp_path, logger)

    @pytest.mark.parametrize("terminated_by", ["terminal", "signal", "handoff"])
    def test_zero_exit_for_graceful_termination(self, tmp_path: Path, terminated_by: str) -> None:
        """terminal, signal, and handoff all return exit code 0."""
        assert self._resume_with_terminated_by(tmp_path, terminated_by) == 0

    @pytest.mark.parametrize("terminated_by", ["max_iterations", "timeout"])
    def test_nonzero_exit_for_limit_termination(self, tmp_path: Path, terminated_by: str) -> None:
        """max_iterations and timeout return exit code 1."""
        assert self._resume_with_terminated_by(tmp_path, terminated_by) == 1

    def test_unknown_terminated_by_returns_1(self, tmp_path: Path) -> None:
        """Unknown terminated_by values fall back to exit code 1."""
        assert self._resume_with_terminated_by(tmp_path, "unexpected") == 1


class TestCmdRunHandoffThreshold:
    """Tests for --handoff-threshold handling in cmd_run (ENH-768)."""

    def _make_args(
        self, handoff_threshold: int | None = None, **kwargs: object
    ) -> argparse.Namespace:
        defaults = {
            "input": None,
            "context": [],
            "max_iterations": None,
            "delay": None,
            "no_llm": False,
            "llm_model": None,
            "dry_run": True,
            "background": False,
            "foreground_internal": False,
            "quiet": False,
            "verbose": False,
            "follow": False,
            "show_diagrams": None,
            "diagram_edge_labels": None,
            "diagram_state_detail": None,
            "diagram_scope": None,
            "clear": False,
            "queue": False,
            "handoff_threshold": handoff_threshold,
            "program_md": None,
        }
        defaults.update(kwargs)
        return argparse.Namespace(**defaults)

    def _make_loop(self, tmp_path: Path) -> Path:
        """Create a minimal loop YAML in tmp_path."""
        loops_dir = tmp_path / ".loops"
        loops_dir.mkdir()
        (loops_dir / "test-loop.yaml").write_text(
            "name: test-loop\ninitial: done\nstates:\n  done:\n    terminal: true\n"
        )
        return loops_dir

    def test_handoff_threshold_sets_env_var(
        self, tmp_path: Path, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        """Setting --handoff-threshold writes LL_HANDOFF_THRESHOLD to env."""
        import os

        from little_loops.cli.loop.run import cmd_run
        from little_loops.logger import Logger

        monkeypatch.delenv("LL_HANDOFF_THRESHOLD", raising=False)
        loops_dir = self._make_loop(tmp_path)
        args = self._make_args(handoff_threshold=40)
        logger = Logger(use_color=False)

        result = cmd_run("test-loop", args, loops_dir, logger)

        assert result == 0
        assert os.environ.get("LL_HANDOFF_THRESHOLD") == "40"

    def test_handoff_threshold_none_does_not_set_env_var(
        self, tmp_path: Path, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        """When --handoff-threshold is not set, LL_HANDOFF_THRESHOLD is left alone."""
        import os

        from little_loops.cli.loop.run import cmd_run
        from little_loops.logger import Logger

        monkeypatch.delenv("LL_HANDOFF_THRESHOLD", raising=False)
        loops_dir = self._make_loop(tmp_path)
        args = self._make_args(handoff_threshold=None)
        logger = Logger(use_color=False)

        cmd_run("test-loop", args, loops_dir, logger)

        assert "LL_HANDOFF_THRESHOLD" not in os.environ

    def test_handoff_threshold_out_of_range_raises(self, tmp_path: Path) -> None:
        """--handoff-threshold outside 1-100 raises SystemExit."""
        from little_loops.cli.loop.run import cmd_run
        from little_loops.logger import Logger

        loops_dir = self._make_loop(tmp_path)
        logger = Logger(use_color=False)

        with pytest.raises(SystemExit):
            cmd_run("test-loop", self._make_args(handoff_threshold=0), loops_dir, logger)

        with pytest.raises(SystemExit):
            cmd_run("test-loop", self._make_args(handoff_threshold=101), loops_dir, logger)


class TestCmdRunYAMLConfigOverrides:
    """Tests for YAML config block override in cmd_run (FEAT-862)."""

    def _make_args(
        self, handoff_threshold: int | None = None, **kwargs: object
    ) -> argparse.Namespace:
        defaults = {
            "input": None,
            "context": [],
            "max_iterations": None,
            "delay": None,
            "no_llm": False,
            "llm_model": None,
            "dry_run": True,
            "background": False,
            "foreground_internal": False,
            "quiet": False,
            "verbose": False,
            "follow": False,
            "show_diagrams": None,
            "diagram_edge_labels": None,
            "diagram_state_detail": None,
            "diagram_scope": None,
            "clear": False,
            "queue": False,
            "handoff_threshold": handoff_threshold,
            "program_md": None,
        }
        defaults.update(kwargs)
        return argparse.Namespace(**defaults)

    def _make_loop(self, tmp_path: Path, config_block: str = "") -> Path:
        """Create a minimal loop YAML in tmp_path with optional config block."""
        loops_dir = tmp_path / ".loops"
        loops_dir.mkdir()
        content = "name: test-loop\ninitial: done\nstates:\n  done:\n    terminal: true\n"
        if config_block:
            content += config_block
        (loops_dir / "test-loop.yaml").write_text(content)
        return loops_dir

    def test_yaml_config_handoff_threshold_sets_env_var(
        self, tmp_path: Path, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        """YAML config.handoff_threshold sets LL_HANDOFF_THRESHOLD when no CLI flag."""
        import os

        from little_loops.cli.loop.run import cmd_run
        from little_loops.logger import Logger

        monkeypatch.delenv("LL_HANDOFF_THRESHOLD", raising=False)
        loops_dir = self._make_loop(tmp_path, config_block="config:\n  handoff_threshold: 60\n")
        args = self._make_args(handoff_threshold=None)
        logger = Logger(use_color=False)

        result = cmd_run("test-loop", args, loops_dir, logger)

        assert result == 0
        assert os.environ.get("LL_HANDOFF_THRESHOLD") == "60"

    def test_cli_handoff_threshold_wins_over_yaml(
        self, tmp_path: Path, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        """CLI --handoff-threshold overrides YAML config.handoff_threshold."""
        import os

        from little_loops.cli.loop.run import cmd_run
        from little_loops.logger import Logger

        monkeypatch.delenv("LL_HANDOFF_THRESHOLD", raising=False)
        loops_dir = self._make_loop(tmp_path, config_block="config:\n  handoff_threshold: 60\n")
        args = self._make_args(handoff_threshold=80)
        logger = Logger(use_color=False)

        cmd_run("test-loop", args, loops_dir, logger)

        assert os.environ.get("LL_HANDOFF_THRESHOLD") == "80"

    def test_no_yaml_config_no_env_var(
        self, tmp_path: Path, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        """No YAML config block and no CLI flag leaves LL_HANDOFF_THRESHOLD unset."""
        import os

        from little_loops.cli.loop.run import cmd_run
        from little_loops.logger import Logger

        monkeypatch.delenv("LL_HANDOFF_THRESHOLD", raising=False)
        loops_dir = self._make_loop(tmp_path)
        args = self._make_args(handoff_threshold=None)
        logger = Logger(use_color=False)

        cmd_run("test-loop", args, loops_dir, logger)

        assert "LL_HANDOFF_THRESHOLD" not in os.environ


class TestFormatRelativeTime:
    """Tests for _format_relative_time helper."""

    def test_seconds(self) -> None:
        assert _format_relative_time(30) == "30s ago"

    def test_minutes(self) -> None:
        assert _format_relative_time(180) == "3m ago"

    def test_minutes_and_seconds(self) -> None:
        assert _format_relative_time(90) == "1m 30s ago"

    def test_hours(self) -> None:
        assert _format_relative_time(3600) == "1h ago"

    def test_hours_and_minutes(self) -> None:
        assert _format_relative_time(4980) == "1h 23m ago"

    def test_days(self) -> None:
        assert _format_relative_time(86400) == "1d ago"

    def test_days_and_hours(self) -> None:
        assert _format_relative_time(90000) == "1d 1h ago"

    def test_zero(self) -> None:
        assert _format_relative_time(0) == "0s ago"


class TestCmdStatusLogFile:
    """Tests for log file details in cmd_status output."""

    def _make_state(self) -> MagicMock:
        mock_state = MagicMock()
        mock_state.loop_name = "test-loop"
        mock_state.status = "running"
        mock_state.current_state = "check"
        mock_state.iteration = 5
        mock_state.started_at = "2026-03-31T10:00:00"
        mock_state.updated_at = "2026-03-31T10:05:00"
        mock_state.continuation_prompt = None
        mock_state.pid = None
        return mock_state

    def test_status_shows_log_file_details(self, tmp_path: Path) -> None:
        """Shows log path, age, and last event when log file exists."""
        logger = MagicMock()
        mock_state = self._make_state()

        running_dir = tmp_path / ".running"
        running_dir.mkdir(parents=True)
        log_file = running_dir / "test-loop.log"
        log_file.write_text(
            "[STATE] idle → check (iteration 4)\n[STATE] check → run_eval (iteration 5)\n"
        )
        # Set mtime to 180 seconds ago
        mtime = time.time() - 180
        os.utime(log_file, (mtime, mtime))

        with (
            patch(
                "little_loops.cli.loop.lifecycle._find_instances", return_value=[(None, mock_state)]
            ),
            patch("builtins.print") as mock_print,
        ):
            result = cmd_status("test-loop", tmp_path, logger)

        assert result == 0
        print_calls = [str(c) for c in mock_print.call_args_list]
        print_text = "\n".join(print_calls)
        assert "Log:" in print_text
        assert "test-loop.log" in print_text
        assert "Log updated:" in print_text
        assert "3m" in print_text
        assert "Last event:" in print_text
        assert "run_eval" in print_text

    def test_status_foreground_run_no_pid_no_log(self, tmp_path: Path) -> None:
        """Shows foreground-run label when no .pid and no .log file exist."""
        logger = MagicMock()
        mock_state = self._make_state()

        running_dir = tmp_path / ".running"
        running_dir.mkdir(parents=True)

        with (
            patch(
                "little_loops.cli.loop.lifecycle._find_instances", return_value=[(None, mock_state)]
            ),
            patch("builtins.print") as mock_print,
        ):
            result = cmd_status("test-loop", tmp_path, logger)

        assert result == 0
        print_calls = [str(c) for c in mock_print.call_args_list]
        print_text = "\n".join(print_calls)
        assert "Log: (foreground run — output went to terminal)" in print_text
        assert "Log: (not found)" not in print_text

    def test_status_background_run_log_missing(self, tmp_path: Path) -> None:
        """Shows 'expected … missing' label when .pid exists but .log was deleted."""
        logger = MagicMock()
        mock_state = self._make_state()

        running_dir = tmp_path / ".running"
        running_dir.mkdir(parents=True)
        # .pid exists (background run) but no .log
        pid_file = running_dir / "test-loop.pid"
        pid_file.write_text("99999")

        with (
            patch(
                "little_loops.cli.loop.lifecycle._find_instances", return_value=[(None, mock_state)]
            ),
            patch("little_loops.fsm.persistence.StatePersistence.save_state"),
            patch("builtins.print") as mock_print,
        ):
            result = cmd_status("test-loop", tmp_path, logger)

        assert result == 0
        print_calls = [str(c) for c in mock_print.call_args_list]
        print_text = "\n".join(print_calls)
        assert "expected" in print_text
        assert "missing" in print_text
        assert "Log: (foreground run" not in print_text

    def test_status_shows_events_line(self, tmp_path: Path) -> None:
        """Shows Events: line when .events.jsonl file exists."""
        import json as _json

        logger = MagicMock()
        mock_state = self._make_state()

        running_dir = tmp_path / ".running"
        running_dir.mkdir(parents=True)
        events_file = running_dir / "test-loop.events.jsonl"
        # Write two events with a recent timestamp
        from datetime import datetime

        ts = datetime.now(tz=UTC).isoformat()
        events_file.write_text(
            _json.dumps({"ts": ts, "type": "state_enter"})
            + "\n"
            + _json.dumps({"ts": ts, "type": "evaluate"})
            + "\n"
        )

        with (
            patch(
                "little_loops.cli.loop.lifecycle._find_instances", return_value=[(None, mock_state)]
            ),
            patch("builtins.print") as mock_print,
        ):
            result = cmd_status("test-loop", tmp_path, logger)

        assert result == 0
        print_calls = [str(c) for c in mock_print.call_args_list]
        print_text = "\n".join(print_calls)
        assert "Events:" in print_text
        assert "2 events" in print_text

    def test_status_json_includes_log_fields(self, tmp_path: Path) -> None:
        """JSON output includes log_file, log_updated_ago, and last_event."""
        import json

        from little_loops.logger import Logger

        logger = Logger(verbose=False)

        running_dir = tmp_path / ".running"
        running_dir.mkdir(parents=True)
        log_file = running_dir / "test-loop.log"
        log_file.write_text("[STATE] check → run_eval (iteration 5)\n")
        mtime = time.time() - 60
        os.utime(log_file, (mtime, mtime))

        mock_state = self._make_state()
        mock_state.to_dict.return_value = {
            "loop_name": "test-loop",
            "status": "running",
            "current_state": "check",
            "iteration": 5,
        }
        args = argparse.Namespace(json=True)

        with (
            patch(
                "little_loops.cli.loop.lifecycle._find_instances", return_value=[(None, mock_state)]
            ),
            patch("builtins.print") as mock_print,
        ):
            result = cmd_status("test-loop", tmp_path, logger, args)

        assert result == 0
        json_output = mock_print.call_args_list[0][0][0]
        data = json.loads(json_output)
        assert "log_file" in data
        assert "log_updated_ago" in data
        assert "last_event" in data
        assert "pid_source" in data
        assert "events_file" in data

    def test_status_json_log_not_found(self, tmp_path: Path) -> None:
        """JSON output includes null log fields when no log file."""
        import json

        from little_loops.logger import Logger

        logger = Logger(verbose=False)

        running_dir = tmp_path / ".running"
        running_dir.mkdir(parents=True)

        mock_state = self._make_state()
        mock_state.to_dict.return_value = {
            "loop_name": "test-loop",
            "status": "running",
            "current_state": "check",
            "iteration": 5,
        }
        args = argparse.Namespace(json=True)

        with (
            patch(
                "little_loops.cli.loop.lifecycle._find_instances", return_value=[(None, mock_state)]
            ),
            patch("builtins.print") as mock_print,
        ):
            result = cmd_status("test-loop", tmp_path, logger, args)

        assert result == 0
        json_output = mock_print.call_args_list[0][0][0]
        data = json.loads(json_output)
        assert data["log_file"] is None
        assert data["log_updated_ago"] is None
        assert data["last_event"] is None
        assert "events_file" in data
        assert data["events_file"] is None


class TestCmdStatusLockFilePid:
    """Tests for BUG-1352: lock-file PID fallback in cmd_status."""

    def _make_state(self) -> MagicMock:
        mock_state = MagicMock()
        mock_state.loop_name = "test-loop"
        mock_state.status = "interrupted"
        mock_state.current_state = "check"
        mock_state.iteration = 3
        mock_state.started_at = "2026-05-03T10:00:00"
        mock_state.updated_at = "2026-05-03T10:05:00"
        mock_state.continuation_prompt = None
        mock_state.to_dict.return_value = {
            "loop_name": "test-loop",
            "status": "interrupted",
            "current_state": "check",
            "iteration": 3,
        }
        return mock_state

    def test_status_json_reads_pid_from_lock_file(self, tmp_path: Path) -> None:
        """JSON output includes PID from .lock file when no .pid file exists."""
        import json as _json

        from little_loops.logger import Logger

        logger = Logger(verbose=False)
        mock_state = self._make_state()

        running_dir = tmp_path / ".running"
        running_dir.mkdir(parents=True)
        lock_file = running_dir / "test-loop.lock"
        lock_file.write_text(
            _json.dumps(
                {
                    "loop_name": "test-loop",
                    "scope": ["/tmp"],
                    "pid": 12345,
                    "started_at": "2026-05-03T10:00:00Z",
                }
            )
        )

        args = argparse.Namespace(json=True)

        with (
            patch(
                "little_loops.cli.loop.lifecycle._find_instances", return_value=[(None, mock_state)]
            ),
            patch("builtins.print") as mock_print,
        ):
            result = cmd_status("test-loop", tmp_path, logger, args)

        assert result == 0
        data = _json.loads(mock_print.call_args_list[0][0][0])
        assert data["pid"] == 12345
        assert data["pid_source"] == "lock_file"

    def test_status_json_pid_source_pid_file_when_pid_file_exists(self, tmp_path: Path) -> None:
        """pid_source is 'pid_file' when PID comes from .pid file."""
        import json as _json

        from little_loops.logger import Logger

        logger = Logger(verbose=False)
        mock_state = self._make_state()

        running_dir = tmp_path / ".running"
        running_dir.mkdir(parents=True)
        pid_file = running_dir / "test-loop.pid"
        pid_file.write_text("99999")

        args = argparse.Namespace(json=True)

        with (
            patch(
                "little_loops.cli.loop.lifecycle._find_instances", return_value=[(None, mock_state)]
            ),
            patch("builtins.print") as mock_print,
        ):
            result = cmd_status("test-loop", tmp_path, logger, args)

        assert result == 0
        data = _json.loads(mock_print.call_args_list[0][0][0])
        assert data["pid"] == 99999
        assert data["pid_source"] == "pid_file"

    def test_status_json_pid_source_null_when_no_pid_or_lock(self, tmp_path: Path) -> None:
        """pid_source is null when neither .pid nor .lock file exists."""
        import json as _json

        from little_loops.logger import Logger

        logger = Logger(verbose=False)
        mock_state = self._make_state()

        running_dir = tmp_path / ".running"
        running_dir.mkdir(parents=True)

        args = argparse.Namespace(json=True)

        with (
            patch(
                "little_loops.cli.loop.lifecycle._find_instances", return_value=[(None, mock_state)]
            ),
            patch("builtins.print") as mock_print,
        ):
            result = cmd_status("test-loop", tmp_path, logger, args)

        assert result == 0
        data = _json.loads(mock_print.call_args_list[0][0][0])
        assert data["pid"] is None
        assert data["pid_source"] is None

    def test_status_json_lock_file_malformed_yields_null_pid(self, tmp_path: Path) -> None:
        """Malformed .lock file is silently ignored; pid remains null."""
        import json as _json

        from little_loops.logger import Logger

        logger = Logger(verbose=False)
        mock_state = self._make_state()

        running_dir = tmp_path / ".running"
        running_dir.mkdir(parents=True)
        lock_file = running_dir / "test-loop.lock"
        lock_file.write_text("not-valid-json{{")

        args = argparse.Namespace(json=True)

        with (
            patch(
                "little_loops.cli.loop.lifecycle._find_instances", return_value=[(None, mock_state)]
            ),
            patch("builtins.print") as mock_print,
        ):
            result = cmd_status("test-loop", tmp_path, logger, args)

        assert result == 0
        data = _json.loads(mock_print.call_args_list[0][0][0])
        assert data["pid"] is None

    def test_status_human_readable_shows_lock_pid(self, tmp_path: Path) -> None:
        """Human-readable output shows lock-file PID when no .pid file."""
        import json as _json

        from little_loops.logger import Logger

        logger = Logger(verbose=False)
        mock_state = self._make_state()

        running_dir = tmp_path / ".running"
        running_dir.mkdir(parents=True)
        lock_file = running_dir / "test-loop.lock"
        lock_file.write_text(
            _json.dumps(
                {
                    "loop_name": "test-loop",
                    "scope": ["/tmp"],
                    "pid": 12345,
                    "started_at": "2026-05-03T10:00:00Z",
                }
            )
        )

        with (
            patch(
                "little_loops.cli.loop.lifecycle._find_instances", return_value=[(None, mock_state)]
            ),
            patch("little_loops.cli.loop.lifecycle._process_alive", return_value=True),
            patch("builtins.print") as mock_print,
        ):
            result = cmd_status("test-loop", tmp_path, logger)

        assert result == 0
        output = "\n".join(str(c) for c in mock_print.call_args_list)
        assert "12345" in output

    def test_status_json_multi_instance_reads_lock_file_pid(self, tmp_path: Path) -> None:
        """Multi-instance JSON output includes lock-file PID for each instance."""
        import json as _json

        from little_loops.logger import Logger

        logger = Logger(verbose=False)

        state1 = MagicMock()
        state1.status = "interrupted"
        state1.to_dict.return_value = {"loop_name": "test-loop", "status": "interrupted"}
        state2 = MagicMock()
        state2.status = "running"
        state2.to_dict.return_value = {"loop_name": "test-loop", "status": "running"}

        running_dir = tmp_path / ".running"
        running_dir.mkdir(parents=True)
        (running_dir / "test-loop-inst1.lock").write_text(
            _json.dumps(
                {
                    "loop_name": "test-loop",
                    "scope": ["/tmp"],
                    "pid": 11111,
                    "started_at": "2026-05-03T10:00:00Z",
                }
            )
        )

        instances = [("test-loop-inst1", state1), ("test-loop-inst2", state2)]
        args = argparse.Namespace(json=True)

        with (
            patch("little_loops.cli.loop.lifecycle._find_instances", return_value=instances),
            patch("builtins.print") as mock_print,
        ):
            result = cmd_status("test-loop", tmp_path, logger, args)

        assert result == 0
        result_list = _json.loads(mock_print.call_args_list[0][0][0])
        inst1 = next(r for r in result_list if r["instance_id"] == "test-loop-inst1")
        inst2 = next(r for r in result_list if r["instance_id"] == "test-loop-inst2")
        assert inst1["pid"] == 11111
        assert inst1["pid_source"] == "lock_file"
        assert inst2["pid"] is None
        assert inst2["pid_source"] is None


class TestCmdResumeCircuitWiring:
    """Tests for ENH-1137: cmd_resume wires RateLimitCircuit into PersistentExecutor."""

    def test_cmd_resume_wires_circuit_when_enabled(self, tmp_path: Path) -> None:
        """circuit_breaker_enabled=True → PersistentExecutor receives a RateLimitCircuit."""
        from little_loops.fsm.rate_limit_circuit import RateLimitCircuit

        logger = MagicMock()
        args = argparse.Namespace()
        mock_fsm = MagicMock()
        mock_result = MagicMock()
        mock_result.final_state = "done"
        mock_result.iterations = 1
        mock_result.duration_ms = 100
        mock_result.terminated_by = "terminal"

        mock_config = MagicMock()
        mock_config.commands.rate_limits.circuit_breaker_enabled = True
        mock_config.commands.rate_limits.circuit_breaker_path = str(
            tmp_path / "rate-limit-circuit.json"
        )
        mock_config.extensions = {}
        mock_config.events = MagicMock(transports=[])

        with (
            patch("little_loops.cli.loop.lifecycle.load_loop", return_value=mock_fsm),
            patch("little_loops.fsm.persistence.StatePersistence") as mock_persist_cls,
            patch("little_loops.fsm.persistence.PersistentExecutor") as mock_exec_cls,
            patch("little_loops.config.BRConfig", return_value=mock_config),
            patch("little_loops.extension.wire_extensions"),
            patch("little_loops.transport.wire_transports"),
        ):
            mock_persist_cls.return_value.load_state.return_value = None
            mock_exec_cls.return_value.resume.return_value = mock_result
            cmd_resume("test-loop", args, tmp_path, logger)

        # PersistentExecutor was constructed with circuit= set to a RateLimitCircuit.
        kwargs = mock_exec_cls.call_args.kwargs
        assert "circuit" in kwargs
        assert isinstance(kwargs["circuit"], RateLimitCircuit)

    def test_cmd_resume_passes_none_when_disabled(self, tmp_path: Path) -> None:
        """circuit_breaker_enabled=False → PersistentExecutor receives circuit=None."""
        logger = MagicMock()
        args = argparse.Namespace()
        mock_fsm = MagicMock()
        mock_result = MagicMock()
        mock_result.final_state = "done"
        mock_result.iterations = 1
        mock_result.duration_ms = 100
        mock_result.terminated_by = "terminal"

        mock_config = MagicMock()
        mock_config.commands.rate_limits.circuit_breaker_enabled = False
        mock_config.commands.rate_limits.circuit_breaker_path = str(
            tmp_path / "rate-limit-circuit.json"
        )
        mock_config.extensions = {}
        mock_config.events = MagicMock(transports=[])

        with (
            patch("little_loops.cli.loop.lifecycle.load_loop", return_value=mock_fsm),
            patch("little_loops.fsm.persistence.StatePersistence") as mock_persist_cls,
            patch("little_loops.fsm.persistence.PersistentExecutor") as mock_exec_cls,
            patch("little_loops.config.BRConfig", return_value=mock_config),
            patch("little_loops.extension.wire_extensions"),
            patch("little_loops.transport.wire_transports"),
        ):
            mock_persist_cls.return_value.load_state.return_value = None
            mock_exec_cls.return_value.resume.return_value = mock_result
            cmd_resume("test-loop", args, tmp_path, logger)

        kwargs = mock_exec_cls.call_args.kwargs
        assert kwargs.get("circuit") is None


class TestCmdResumeTransportWiring:
    """Tests for FEAT-1323: cmd_resume wires transports and tears them down on exit."""

    def test_cmd_resume_wires_transports(self, tmp_path: Path) -> None:
        """cmd_resume calls wire_transports(executor.event_bus, config.events)."""
        logger = MagicMock()
        args = argparse.Namespace()
        mock_fsm = MagicMock()
        mock_result = MagicMock()
        mock_result.final_state = "done"
        mock_result.iterations = 1
        mock_result.duration_ms = 100
        mock_result.terminated_by = "terminal"

        mock_config = MagicMock()
        mock_config.commands.rate_limits.circuit_breaker_enabled = False
        mock_config.commands.rate_limits.circuit_breaker_path = str(
            tmp_path / "rate-limit-circuit.json"
        )
        mock_config.extensions = {}
        mock_config.events = MagicMock(transports=[])

        with (
            patch("little_loops.cli.loop.lifecycle.load_loop", return_value=mock_fsm),
            patch("little_loops.fsm.persistence.StatePersistence") as mock_persist_cls,
            patch("little_loops.fsm.persistence.PersistentExecutor") as mock_exec_cls,
            patch("little_loops.config.BRConfig", return_value=mock_config),
            patch("little_loops.extension.wire_extensions"),
            patch("little_loops.transport.wire_transports") as mock_wire,
        ):
            mock_persist_cls.return_value.load_state.return_value = None
            mock_exec_cls.return_value.resume.return_value = mock_result
            cmd_resume("test-loop", args, tmp_path, logger)

        mock_wire.assert_called_once()
        bus_arg, events_arg = mock_wire.call_args.args
        assert bus_arg is mock_exec_cls.return_value.event_bus
        assert events_arg is mock_config.events

    def test_cmd_resume_calls_close_transports_on_success(self, tmp_path: Path) -> None:
        """cmd_resume runs executor.close_transports() in finally on normal exit."""
        logger = MagicMock()
        args = argparse.Namespace()
        mock_fsm = MagicMock()
        mock_result = MagicMock()
        mock_result.final_state = "done"
        mock_result.iterations = 1
        mock_result.duration_ms = 100
        mock_result.terminated_by = "terminal"

        mock_config = MagicMock()
        mock_config.commands.rate_limits.circuit_breaker_enabled = False
        mock_config.commands.rate_limits.circuit_breaker_path = str(
            tmp_path / "rate-limit-circuit.json"
        )
        mock_config.extensions = {}
        mock_config.events = MagicMock(transports=[])

        with (
            patch("little_loops.cli.loop.lifecycle.load_loop", return_value=mock_fsm),
            patch("little_loops.fsm.persistence.StatePersistence") as mock_persist_cls,
            patch("little_loops.fsm.persistence.PersistentExecutor") as mock_exec_cls,
            patch("little_loops.config.BRConfig", return_value=mock_config),
            patch("little_loops.extension.wire_extensions"),
            patch("little_loops.transport.wire_transports"),
        ):
            mock_persist_cls.return_value.load_state.return_value = None
            mock_exec_cls.return_value.resume.return_value = mock_result
            cmd_resume("test-loop", args, tmp_path, logger)

        mock_exec_cls.return_value.close_transports.assert_called_once()

    def test_cmd_resume_close_transports_runs_on_exception(self, tmp_path: Path) -> None:
        """cmd_resume still tears down transports if executor.resume() raises."""
        logger = MagicMock()
        args = argparse.Namespace()
        mock_fsm = MagicMock()

        mock_config = MagicMock()
        mock_config.commands.rate_limits.circuit_breaker_enabled = False
        mock_config.commands.rate_limits.circuit_breaker_path = str(
            tmp_path / "rate-limit-circuit.json"
        )
        mock_config.extensions = {}
        mock_config.events = MagicMock(transports=[])

        with (
            patch("little_loops.cli.loop.lifecycle.load_loop", return_value=mock_fsm),
            patch("little_loops.fsm.persistence.StatePersistence") as mock_persist_cls,
            patch("little_loops.fsm.persistence.PersistentExecutor") as mock_exec_cls,
            patch("little_loops.config.BRConfig", return_value=mock_config),
            patch("little_loops.extension.wire_extensions"),
            patch("little_loops.transport.wire_transports"),
        ):
            mock_persist_cls.return_value.load_state.return_value = None
            mock_exec_cls.return_value.resume.side_effect = KeyboardInterrupt
            try:
                cmd_resume("test-loop", args, tmp_path, logger)
            except KeyboardInterrupt:
                pass

        mock_exec_cls.return_value.close_transports.assert_called_once()


class TestFindInstances:
    """Unit tests for _find_instances — ENH-1356."""

    def _write_state(self, path, loop_name: str, status: str = "running") -> None:
        import json

        path.write_text(
            json.dumps(
                {
                    "loop_name": loop_name,
                    "current_state": "check",
                    "iteration": 1,
                    "captured": {},
                    "prev_result": None,
                    "last_result": None,
                    "started_at": "2026-05-03T12:23:06Z",
                    "updated_at": "2026-05-03T12:25:00Z",
                    "status": status,
                }
            )
        )

    def test_empty_when_no_files(self, tmp_path) -> None:
        """Returns empty list when running_dir has no state files."""
        from little_loops.fsm.persistence import _find_instances

        running_dir = tmp_path / ".running"
        running_dir.mkdir()
        assert _find_instances("my-loop", running_dir) == []

    def test_empty_when_dir_missing(self, tmp_path) -> None:
        """Returns empty list when running_dir does not exist."""
        from little_loops.fsm.persistence import _find_instances

        assert _find_instances("my-loop", tmp_path / ".running") == []

    def test_discovers_legacy_bare_stem(self, tmp_path) -> None:
        """Discovers legacy bare-stem state file with instance_id=None."""
        from little_loops.fsm.persistence import _find_instances

        running_dir = tmp_path / ".running"
        running_dir.mkdir()
        self._write_state(running_dir / "test-loop.state.json", "test-loop")

        instances = _find_instances("test-loop", running_dir)
        assert len(instances) == 1
        instance_id, state = instances[0]
        assert instance_id is None
        assert state.loop_name == "test-loop"
        assert state.status == "running"

    def test_discovers_timestamp_scoped(self, tmp_path) -> None:
        """Discovers instance-scoped state file; instance_id is the file stem."""
        from little_loops.fsm.persistence import _find_instances

        running_dir = tmp_path / ".running"
        running_dir.mkdir()
        self._write_state(running_dir / "test-loop-20260503T122306.state.json", "test-loop")

        instances = _find_instances("test-loop", running_dir)
        assert len(instances) == 1
        instance_id, state = instances[0]
        assert instance_id == "test-loop-20260503T122306"
        assert state.loop_name == "test-loop"

    def test_discovers_mixed_legacy_and_scoped(self, tmp_path) -> None:
        """Discovers both legacy and instance-scoped files in the same directory."""
        from little_loops.fsm.persistence import _find_instances

        running_dir = tmp_path / ".running"
        running_dir.mkdir()
        self._write_state(running_dir / "test-loop.state.json", "test-loop")
        self._write_state(running_dir / "test-loop-20260503T122306.state.json", "test-loop")

        instances = _find_instances("test-loop", running_dir)
        assert len(instances) == 2
        ids = {iid for iid, _ in instances}
        assert None in ids
        assert "test-loop-20260503T122306" in ids

    def test_ignores_other_loops(self, tmp_path) -> None:
        """Does not return state files for a different loop name."""
        from little_loops.fsm.persistence import _find_instances

        running_dir = tmp_path / ".running"
        running_dir.mkdir()
        self._write_state(running_dir / "other-loop.state.json", "other-loop")
        self._write_state(running_dir / "other-loop-20260503T122306.state.json", "other-loop")

        assert _find_instances("test-loop", running_dir) == []

    def test_skips_non_timestamp_hyphenated_names(self, tmp_path) -> None:
        """Does not match files like 'test-loop-extra.state.json' (no timestamp suffix)."""
        from little_loops.fsm.persistence import _find_instances

        running_dir = tmp_path / ".running"
        running_dir.mkdir()
        self._write_state(running_dir / "test-loop-extra.state.json", "test-loop-extra")

        assert _find_instances("test-loop", running_dir) == []


class TestCmdStatusMultiInstance:
    """Multi-instance aggregate output for cmd_status — ENH-1356."""

    def test_aggregate_shows_numbered_instances(self, tmp_path) -> None:
        """Two instances produce a numbered list, not a single-instance block."""
        logger = MagicMock()
        state1 = MagicMock()
        state1.loop_name = "autodev"
        state1.status = "running"
        state1.current_state = "implement"
        state1.iteration = 12
        state1.continuation_prompt = None
        state1.pid = None

        state2 = MagicMock()
        state2.loop_name = "autodev"
        state2.status = "running"
        state2.current_state = "refine_current"
        state2.iteration = 3
        state2.continuation_prompt = None
        state2.pid = None

        instances = [
            ("autodev-20260503T122306", state1),
            ("autodev-20260503T122340", state2),
        ]

        with (
            patch("little_loops.cli.loop.lifecycle._find_instances", return_value=instances),
            patch("builtins.print") as mock_print,
        ):
            result = cmd_status("autodev", tmp_path, logger)

        assert result == 0
        output = "\n".join(str(c) for c in mock_print.call_args_list)
        assert "[1]" in output
        assert "[2]" in output
        assert "autodev-20260503T122306" in output
        assert "autodev-20260503T122340" in output

    def test_aggregate_header_shows_count(self, tmp_path) -> None:
        """Header line includes the instance count and loop name."""
        logger = MagicMock()
        state1 = MagicMock()
        state1.status = "running"
        state1.continuation_prompt = None
        state1.pid = None
        state2 = MagicMock()
        state2.status = "running"
        state2.continuation_prompt = None
        state2.pid = None

        with (
            patch(
                "little_loops.cli.loop.lifecycle._find_instances",
                return_value=[
                    ("autodev-20260503T122306", state1),
                    ("autodev-20260503T122340", state2),
                ],
            ),
            patch("builtins.print") as mock_print,
        ):
            cmd_status("autodev", tmp_path, logger)

        first_call = str(mock_print.call_args_list[0])
        assert "2 instances" in first_call
        assert "autodev" in first_call


class TestCmdStopMultiInstance:
    """Multi-instance stop behaviour — ENH-1356."""

    def test_stop_terminates_all_running_instances(self, tmp_path) -> None:
        """cmd_stop marks every running instance as interrupted."""
        logger = MagicMock()
        state1 = MagicMock()
        state1.status = "running"
        state2 = MagicMock()
        state2.status = "running"

        instances = [
            ("autodev-20260503T122306", state1),
            ("autodev-20260503T122340", state2),
        ]

        with (
            patch("little_loops.cli.loop.lifecycle._find_instances", return_value=instances),
            patch("little_loops.fsm.persistence.StatePersistence"),
        ):
            result = cmd_stop("autodev", tmp_path, logger)

        assert result == 0
        assert state1.status == "interrupted"
        assert state2.status == "interrupted"

    def test_stop_skips_non_running_instances(self, tmp_path) -> None:
        """cmd_stop only processes instances with status 'running'."""
        logger = MagicMock()
        state_running = MagicMock()
        state_running.status = "running"
        state_done = MagicMock()
        state_done.status = "completed"

        instances = [
            ("autodev-20260503T122306", state_running),
            ("autodev-20260503T122340", state_done),
        ]

        with (
            patch("little_loops.cli.loop.lifecycle._find_instances", return_value=instances),
            patch("little_loops.fsm.persistence.StatePersistence"),
        ):
            result = cmd_stop("autodev", tmp_path, logger)

        assert result == 0
        assert state_running.status == "interrupted"
        assert state_done.status == "completed"


class TestCmdResumeMultiInstance:
    """Multi-instance resume error — ENH-1356."""

    def test_resume_errors_when_multiple_resumable(self, tmp_path) -> None:
        """cmd_resume exits non-zero and lists instance IDs when 2+ are resumable."""
        logger = MagicMock()
        args = argparse.Namespace()

        state1 = MagicMock()
        state1.status = "awaiting_continuation"
        state2 = MagicMock()
        state2.status = "running"

        instances = [
            ("autodev-20260503T122306", state1),
            ("autodev-20260503T122340", state2),
        ]

        with (
            patch("little_loops.cli.loop.lifecycle._find_instances", return_value=instances),
            patch("builtins.print") as mock_print,
        ):
            result = cmd_resume("autodev", args, tmp_path, logger)

        assert result == 1
        output = "\n".join(str(c) for c in mock_print.call_args_list)
        assert "autodev-20260503T122306" in output
        assert "autodev-20260503T122340" in output

    def test_resume_succeeds_with_single_resumable(self, tmp_path) -> None:
        """cmd_resume proceeds normally when exactly one resumable instance found."""
        logger = MagicMock()
        args = argparse.Namespace()
        mock_fsm = MagicMock()
        mock_result = MagicMock()
        mock_result.final_state = "done"
        mock_result.iterations = 2
        mock_result.duration_ms = 3000
        mock_result.terminated_by = "terminal"

        resumable_state = MagicMock()
        resumable_state.status = "awaiting_continuation"
        resumable_state.continuation_prompt = None

        with (
            patch(
                "little_loops.cli.loop.lifecycle._find_instances",
                return_value=[("autodev-20260503T122306", resumable_state)],
            ),
            patch("little_loops.cli.loop.lifecycle.load_loop", return_value=mock_fsm),
            patch("little_loops.fsm.persistence.PersistentExecutor") as mock_exec_cls,
        ):
            mock_exec_cls.return_value.resume.return_value = mock_result
            result = cmd_resume("autodev", args, tmp_path, logger)

        assert result == 0


class TestCmdResumeInterrupted:
    """Interrupted-loop resume — ENH-1605."""

    def test_interrupted_instance_is_resumable(self, tmp_path) -> None:
        """cmd_resume proceeds normally when the single instance is interrupted."""
        logger = MagicMock()
        args = argparse.Namespace()
        mock_fsm = MagicMock()
        mock_result = MagicMock()
        mock_result.final_state = "done"
        mock_result.iterations = 3
        mock_result.duration_ms = 5000
        mock_result.terminated_by = "terminal"

        interrupted_state = MagicMock()
        interrupted_state.status = "interrupted"
        interrupted_state.continuation_prompt = None

        with (
            patch(
                "little_loops.cli.loop.lifecycle._find_instances",
                return_value=[("myloop-20260101T120000", interrupted_state)],
            ),
            patch("little_loops.cli.loop.lifecycle.load_loop", return_value=mock_fsm),
            patch("little_loops.fsm.persistence.PersistentExecutor") as mock_exec_cls,
        ):
            mock_exec_cls.return_value.resume.return_value = mock_result
            result = cmd_resume("myloop", args, tmp_path, logger)

        assert result == 0


class TestCmdListMultiInstance:
    """cmd_list deduplication for multi-instance loops — ENH-1356."""

    def test_list_no_duplicate_rows_for_multi_instance(
        self,
        tmp_path,
        monkeypatch,
        capsys,
    ) -> None:
        """Two instances of the same loop produce one grouped row, not two."""
        import json
        import sys
        from unittest.mock import patch

        loops_dir = tmp_path / ".loops"
        loops_dir.mkdir()
        running_dir = loops_dir / ".running"
        running_dir.mkdir()

        base_state = {
            "loop_name": "autodev",
            "current_state": "implement",
            "iteration": 1,
            "captured": {},
            "prev_result": None,
            "last_result": None,
            "started_at": "2026-05-03T12:23:06Z",
            "updated_at": "2026-05-03T12:25:00Z",
            "status": "running",
        }
        (running_dir / "autodev-20260503T122306.state.json").write_text(json.dumps(base_state))
        (running_dir / "autodev-20260503T122340.state.json").write_text(
            json.dumps({**base_state, "iteration": 3})
        )

        monkeypatch.chdir(tmp_path)
        with patch.object(sys, "argv", ["ll-loop", "list", "--running"]):
            from little_loops.cli import main_loop

            result = main_loop()

        assert result == 0
        out = capsys.readouterr().out
        assert out.count("autodev") == 1


class TestReconcileStaleRunning:
    """Tests for ENH-1669: auto-flip orphaned running state on cmd_status read path."""

    def _make_state(
        self,
        status: str = "running",
        pid: int | None = None,
    ) -> LoopState:
        return LoopState(
            loop_name="test-loop",
            current_state="check",
            iteration=1,
            captured={},
            prev_result=None,
            last_result=None,
            started_at="2026-05-24T10:00:00Z",
            updated_at="2026-05-24T10:05:00Z",
            status=status,
            pid=pid,
        )

    def _write_state(self, running_dir: Path, stem: str, state: LoopState) -> Path:
        running_dir.mkdir(parents=True, exist_ok=True)
        state_file = running_dir / f"{stem}.state.json"
        state_file.write_text(json.dumps(state.to_dict()))
        return state_file

    def test_reconciles_dead_state_pid_no_pid_file(self, tmp_path: Path) -> None:
        """Flips running→interrupted when only state.pid exists and it's dead."""
        logger = MagicMock()
        running_dir = tmp_path / ".running"
        state = self._make_state(status="running", pid=40692)
        self._write_state(running_dir, "test-loop", state)

        with (
            patch(
                "little_loops.cli.loop.lifecycle._find_instances",
                return_value=[(None, state)],
            ),
            patch("little_loops.cli.loop.lifecycle._process_alive", return_value=False),
            patch("builtins.print"),
        ):
            result = cmd_status("test-loop", tmp_path, logger)

        assert result == 0
        assert state.status == "interrupted"
        assert state.reconciled_at is not None
        written = json.loads((running_dir / "test-loop.state.json").read_text())
        assert written["status"] == "interrupted"
        assert "reconciled_at" in written

    def test_reconciles_dead_pid_file(self, tmp_path: Path) -> None:
        """Flips running→interrupted when .pid file has dead PID (state.pid absent)."""
        logger = MagicMock()
        running_dir = tmp_path / ".running"
        state = self._make_state(status="running", pid=None)
        self._write_state(running_dir, "test-loop", state)
        (running_dir / "test-loop.pid").write_text("88888")

        with (
            patch(
                "little_loops.cli.loop.lifecycle._find_instances",
                return_value=[(None, state)],
            ),
            patch("little_loops.cli.loop.lifecycle._process_alive", return_value=False),
            patch("builtins.print"),
        ):
            result = cmd_status("test-loop", tmp_path, logger)

        assert result == 0
        assert state.status == "interrupted"
        assert state.reconciled_at is not None

    def test_no_reconcile_live_lock_pid(self, tmp_path: Path) -> None:
        """Does NOT reconcile when .lock file holds a live PID."""
        logger = MagicMock()
        running_dir = tmp_path / ".running"
        state = self._make_state(status="running", pid=None)
        self._write_state(running_dir, "test-loop", state)
        (running_dir / "test-loop.lock").write_text(
            json.dumps({"pid": 77777, "loop_name": "test-loop", "scope": "test", "started_at": ""})
        )

        with (
            patch(
                "little_loops.cli.loop.lifecycle._find_instances",
                return_value=[(None, state)],
            ),
            patch("little_loops.cli.loop.lifecycle._process_alive", return_value=True),
            patch("builtins.print"),
        ):
            result = cmd_status("test-loop", tmp_path, logger)

        assert result == 0
        assert state.status == "running"
        assert state.reconciled_at is None

    def test_no_reconcile_already_interrupted(self, tmp_path: Path) -> None:
        """Does NOT change state when already interrupted (non-running status)."""
        logger = MagicMock()
        running_dir = tmp_path / ".running"
        state = self._make_state(status="interrupted", pid=40692)
        self._write_state(running_dir, "test-loop", state)

        with (
            patch(
                "little_loops.cli.loop.lifecycle._find_instances",
                return_value=[(None, state)],
            ),
            patch("little_loops.cli.loop.lifecycle._process_alive", return_value=False),
            patch("builtins.print"),
        ):
            result = cmd_status("test-loop", tmp_path, logger)

        assert result == 0
        assert state.status == "interrupted"
        assert state.reconciled_at is None

    def test_no_reconcile_no_pid_anywhere(self, tmp_path: Path) -> None:
        """Does NOT reconcile when no PID is resolvable from any source."""
        logger = MagicMock()
        running_dir = tmp_path / ".running"
        state = self._make_state(status="running", pid=None)
        self._write_state(running_dir, "test-loop", state)

        with (
            patch(
                "little_loops.cli.loop.lifecycle._find_instances",
                return_value=[(None, state)],
            ),
            patch("builtins.print"),
        ):
            result = cmd_status("test-loop", tmp_path, logger)

        assert result == 0
        assert state.status == "running"
        assert state.reconciled_at is None

    def test_reconciles_in_multi_instance_human_readable(self, tmp_path: Path) -> None:
        """Multi-instance human-readable path reconciles dead-PID running entries."""
        logger = MagicMock()
        running_dir = tmp_path / ".running"
        state1 = self._make_state(status="running", pid=11111)
        state2 = self._make_state(status="running", pid=22222)
        self._write_state(running_dir, "test-loop-inst1", state1)
        self._write_state(running_dir, "test-loop-inst2", state2)
        instances = [
            ("test-loop-inst1", state1),
            ("test-loop-inst2", state2),
        ]

        with (
            patch(
                "little_loops.cli.loop.lifecycle._find_instances",
                return_value=instances,
            ),
            patch("little_loops.cli.loop.lifecycle._process_alive", return_value=False),
            patch("builtins.print"),
        ):
            result = cmd_status("test-loop", tmp_path, logger)

        assert result == 0
        assert state1.status == "interrupted"
        assert state2.status == "interrupted"
        assert state1.reconciled_at is not None
        assert state2.reconciled_at is not None
