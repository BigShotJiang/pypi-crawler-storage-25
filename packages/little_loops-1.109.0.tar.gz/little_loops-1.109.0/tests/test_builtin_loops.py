"""Tests for built-in loops shipped with the plugin."""

from __future__ import annotations

import re
import subprocess
import sys
from pathlib import Path
from unittest.mock import patch

import pytest
import yaml

from little_loops.fsm.validation import ValidationSeverity, load_and_validate, validate_fsm

BUILTIN_LOOPS_DIR = Path(__file__).parent.parent / "little_loops" / "loops"


class TestBuiltinLoopFiles:
    """Tests that all built-in loop YAML files are valid."""

    @pytest.fixture
    def builtin_loops(self) -> list[Path]:
        """Get all built-in loop files."""
        assert BUILTIN_LOOPS_DIR.exists(), f"Built-in loops dir not found: {BUILTIN_LOOPS_DIR}"
        files = sorted(BUILTIN_LOOPS_DIR.glob("*.yaml"))
        assert len(files) > 0, "No built-in loop files found"
        return files

    def test_all_parse_as_yaml(self, builtin_loops: list[Path]) -> None:
        """All built-in loop files parse as valid YAML."""
        for loop_file in builtin_loops:
            with open(loop_file) as f:
                data = yaml.safe_load(f)
            assert isinstance(data, dict), f"{loop_file.name}: root must be a mapping"

    def test_all_validate_as_valid_fsm(self, builtin_loops: list[Path]) -> None:
        """All built-in loops load and validate as FSMs without errors."""
        for loop_file in builtin_loops:
            fsm, _ = load_and_validate(loop_file)
            errors = validate_fsm(fsm)
            error_list = [e for e in errors if e.severity == ValidationSeverity.ERROR]
            assert not error_list, (
                f"{loop_file.name}: validation errors: {[str(e) for e in error_list]}"
            )

    def test_all_have_description_field(self, builtin_loops: list[Path]) -> None:
        """All built-in loops define a top-level description: field.

        Regression guard for ENH-1331: debug-loop-run and audit-loop-run skills
        require a machine-readable description for goal-alignment assessment.
        """
        for loop_file in builtin_loops:
            fsm, warnings = load_and_validate(loop_file)
            assert fsm.description, f"{loop_file.name}: missing top-level 'description:' field"
            description_warnings = [
                w
                for w in warnings
                if w.severity == ValidationSeverity.WARNING and "description" in w.message.lower()
            ]
            assert not description_warnings, (
                f"{loop_file.name}: produced description warning: "
                f"{[str(w) for w in description_warnings]}"
            )

    def test_expected_loops_exist(self) -> None:
        """The expected set of built-in loops exists."""
        expected = {
            "dead-code-cleanup",
            "docs-sync",
            "evaluation-quality",
            "fix-quality-and-tests",
            "issue-discovery-triage",
            "issue-refinement",
            "issue-staleness-review",
            "backlog-flow-optimizer",
            "sprint-build-and-validate",
            "worktree-health",
            "rl-bandit",
            "rl-rlhf",
            "rl-policy",
            "rl-coding-agent",
            "apo-feedback-refinement",
            "apo-contrastive",
            "apo-opro",
            "apo-beam",
            "apo-textgrad",
            "examples-miner",
            "context-health-monitor",
            "harness-single-shot",
            "harness-multi-item",
            "harness-optimize",
            "general-task",
            "refine-to-ready-issue",
            "agent-eval-improve",
            "dataset-curation",
            "incremental-refactor",
            "prompt-across-issues",
            "prompt-regression-test",
            "test-coverage-improvement",
            "eval-driven-development",
            "greenfield-builder",
            "outer-loop-eval",
            "auto-refine-and-implement",
            "autodev",
            "scan-and-implement",
            "recursive-refine",
            "html-anything",
            "html-website-generator",
            "sprint-refine-and-implement",
            "svg-image-generator",
            "svg-textgrad",
            "rn-plan",
            "rn-plan-apo",
            "rn-refine",
            "loop-specialist-eval",
            "hitl-compare",
            "hitl-md",
            "deep-research",
            "deep-research-arxiv",
            "loop-router",
        }
        actual = {f.stem for f in BUILTIN_LOOPS_DIR.glob("*.yaml")}
        assert expected == actual

    def test_no_bare_pass_token_in_output_contains(self, builtin_loops: list[Path]) -> None:
        """No built-in loop uses bare 'PASS' as an output_contains pattern.

        Bare 'PASS' collides with per-criterion scoring annotations
        (e.g. 'design_quality: 8/10 — PASS') in free-form LLM output.
        Use compound tokens like 'ALL_PASS' or 'CONVERGED' instead.
        """
        for loop_file in builtin_loops:
            with open(loop_file) as f:
                data = yaml.safe_load(f)
            for state_name, state in (data.get("states") or {}).items():
                evaluate = state.get("evaluate") or {}
                if evaluate.get("type") == "output_contains":
                    pattern = evaluate.get("pattern")
                    assert pattern != "PASS", (
                        f"{loop_file.name}/{state_name} uses ambiguous 'PASS' token — "
                        "scoring output annotations will match substring. "
                        "Use a compound token (e.g. 'ALL_PASS')."
                    )

    def test_no_bare_bash_variable_in_shell_actions(self, builtin_loops: list[Path]) -> None:
        """No built-in loop shell action uses unescaped ${VAR} bare bash variables.

        Bare ${VAR} (no dot) is intercepted by the FSM template engine and raises
        InterpolationError before bash ever sees it. Use $${VAR} to pass through.
        Regression guard for BUG-1675.
        """
        import re

        bare_var_pattern = re.compile(r"(?<!\$)\$\{[A-Z_][A-Z0-9_]*\}")
        # Context-namespace variables like ${context.x}, ${captured.y.z} are valid — skip those.
        # We only flag bare names with no dot.
        for loop_file in builtin_loops:
            with open(loop_file) as f:
                data = yaml.safe_load(f)
            for state_name, state in (data.get("states") or {}).items():
                if state.get("action_type") != "shell":
                    continue
                action = state.get("action", "")
                matches = bare_var_pattern.findall(action)
                assert not matches, (
                    f"{loop_file.name}/{state_name} contains unescaped bash variable(s) "
                    f"{matches} — use $$${{VAR}} to prevent FSM template engine interception "
                    "(BUG-1675)"
                )

    def test_all_failure_terminals_have_diagnostic_action(self, builtin_loops: list[Path]) -> None:
        """Loops with a diagnose state must have a diagnostic action before failure terminals.

        Regression guard for BUG-1606: all fixed loops must have a pre-terminal diagnose
        state that executes a prompt action before transitioning to a failure terminal.
        Loops without a diagnose state are skipped (not yet updated).
        """
        for loop_file in builtin_loops:
            with open(loop_file) as f:
                data = yaml.safe_load(f)
            states = data.get("states", {})
            failure_terminals = {
                name
                for name, cfg in states.items()
                if cfg.get("terminal") and name in ("failed", "error", "aborted")
            }
            if not failure_terminals:
                continue
            diagnose = states.get("diagnose") or states.get("diagnose_failure")
            if diagnose is None:
                continue  # Loop not yet updated with diagnose state (pending BUG-1606)
            assert diagnose.get("action"), (
                f"{loop_file.name}: 'diagnose' state exists but has no diagnostic action"
            )
            assert not diagnose.get("terminal", False), (
                f"{loop_file.name}: 'diagnose' state must not be terminal"
            )


class TestBuiltinLoopResolution:
    """Tests for resolve_loop_path with built-in fallback."""

    def test_builtin_fallback(self, tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> None:
        """resolve_loop_path falls back to built-in loops."""
        monkeypatch.chdir(tmp_path)
        with patch.object(sys, "argv", ["ll-loop", "validate", "fix-quality-and-tests"]):
            from little_loops.cli import main_loop

            result = main_loop()
        # Should succeed because fix-quality-and-tests is a built-in
        assert result == 0

    def test_project_overrides_builtin(
        self, tmp_path: Path, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        """Project-local loop takes priority over built-in."""
        loops_dir = tmp_path / ".loops"
        loops_dir.mkdir()
        # Create a project-local loop with the same name but different content
        (loops_dir / "fix-quality-and-tests.yaml").write_text(
            "name: fix-quality-and-tests\ninitial: start\nstates:\n  start:\n    terminal: true\n"
        )

        monkeypatch.chdir(tmp_path)
        with patch.object(sys, "argv", ["ll-loop", "validate", "fix-quality-and-tests"]):
            from little_loops.cli import main_loop

            result = main_loop()
        # Should use the project-local version (which is a simple terminal FSM)
        assert result == 0


class TestBuiltinLoopList:
    """Tests for ll-loop list with built-in loops."""

    def test_list_shows_builtin_tag(
        self,
        tmp_path: Path,
        monkeypatch: pytest.MonkeyPatch,
        capsys: pytest.CaptureFixture[str],
    ) -> None:
        """ll-loop list shows [built-in] tag for bundled loops."""
        monkeypatch.chdir(tmp_path)
        with patch.object(sys, "argv", ["ll-loop", "list"]):
            from little_loops.cli import main_loop

            result = main_loop()
        assert result == 0
        captured = capsys.readouterr()
        assert "[built-in]" in captured.out
        assert "fix-quality-and-tests" in captured.out

    def test_list_hides_overridden_builtin(
        self,
        tmp_path: Path,
        monkeypatch: pytest.MonkeyPatch,
        capsys: pytest.CaptureFixture[str],
    ) -> None:
        """Project loop with same name hides built-in from list."""
        loops_dir = tmp_path / ".loops"
        loops_dir.mkdir()
        (loops_dir / "fix-quality-and-tests.yaml").write_text(
            "name: fix-quality-and-tests\ninitial: start\nstates:\n  start:\n    terminal: true\n"
        )

        monkeypatch.chdir(tmp_path)
        with patch.object(sys, "argv", ["ll-loop", "list"]):
            from little_loops.cli import main_loop

            result = main_loop()
        assert result == 0
        captured = capsys.readouterr()
        lines = captured.out.strip().split("\n")
        # fix-quality-and-tests should appear without [built-in] tag (project version)
        pr_lines = [line for line in lines if "fix-quality-and-tests" in line]
        assert len(pr_lines) == 1
        assert "[built-in]" not in pr_lines[0]


class TestBuiltinLoopInstall:
    """Tests for ll-loop install subcommand."""

    def test_install_copies_to_project(
        self,
        tmp_path: Path,
        monkeypatch: pytest.MonkeyPatch,
        capsys: pytest.CaptureFixture[str],
    ) -> None:
        """install copies built-in loop to .loops/."""
        monkeypatch.chdir(tmp_path)
        with patch.object(sys, "argv", ["ll-loop", "install", "fix-quality-and-tests"]):
            from little_loops.cli import main_loop

            result = main_loop()
        assert result == 0
        dest = tmp_path / ".loops" / "fix-quality-and-tests.yaml"
        assert dest.exists()
        captured = capsys.readouterr()
        assert "Installed" in captured.out

    def test_install_creates_loops_dir(
        self,
        tmp_path: Path,
        monkeypatch: pytest.MonkeyPatch,
    ) -> None:
        """install creates .loops/ directory if it doesn't exist."""
        monkeypatch.chdir(tmp_path)
        assert not (tmp_path / ".loops").exists()
        with patch.object(sys, "argv", ["ll-loop", "install", "issue-refinement"]):
            from little_loops.cli import main_loop

            result = main_loop()
        assert result == 0
        assert (tmp_path / ".loops" / "issue-refinement.yaml").exists()

    def test_install_rejects_existing(
        self,
        tmp_path: Path,
        monkeypatch: pytest.MonkeyPatch,
    ) -> None:
        """install refuses to overwrite existing project loop."""
        loops_dir = tmp_path / ".loops"
        loops_dir.mkdir()
        (loops_dir / "fix-quality-and-tests.yaml").write_text("existing content")

        monkeypatch.chdir(tmp_path)
        with patch.object(sys, "argv", ["ll-loop", "install", "fix-quality-and-tests"]):
            from little_loops.cli import main_loop

            result = main_loop()
        assert result == 1

    def test_install_rejects_unknown(
        self,
        tmp_path: Path,
        monkeypatch: pytest.MonkeyPatch,
    ) -> None:
        """install rejects unknown loop name."""
        monkeypatch.chdir(tmp_path)
        with patch.object(sys, "argv", ["ll-loop", "install", "nonexistent-loop"]):
            from little_loops.cli import main_loop

            result = main_loop()
        assert result == 1


class TestBuiltinLoopScratchIsolation:
    """Tests that built-in loops use project-scoped scratch paths, not global /tmp names."""

    AFFECTED_LOOPS = [
        "issue-refinement",
        "fix-quality-and-tests",
        "dead-code-cleanup",
    ]

    # Bare /tmp paths that must not appear in any action text
    FORBIDDEN_PATTERNS = [
        "/tmp/issue-refinement-commit-count",
        "/tmp/ll-test-results.txt",
        "/tmp/ll-dead-code-report.txt",
        "/tmp/ll-dead-code-excluded.txt",
        "/tmp/ll-dead-code-tests.txt",
        "/tmp/ll-pr-test-results.txt",
    ]

    def _collect_action_text(self, data: dict) -> list[str]:
        """Recursively collect all action strings from an FSM data dict."""
        texts: list[str] = []
        for state_data in data.get("states", {}).values():
            action = state_data.get("action", "")
            if isinstance(action, str):
                texts.append(action)
        return texts

    @pytest.mark.parametrize("loop_name", AFFECTED_LOOPS)
    def test_no_global_tmp_paths(self, loop_name: str) -> None:
        """Action text in affected loops must not reference bare /tmp scratch paths."""
        loop_file = BUILTIN_LOOPS_DIR / f"{loop_name}.yaml"
        assert loop_file.exists(), f"Loop file not found: {loop_file}"
        data = yaml.safe_load(loop_file.read_text())
        action_texts = self._collect_action_text(data)
        combined = "\n".join(action_texts)
        for forbidden in self.FORBIDDEN_PATTERNS:
            # Use negative lookbehind so ".loops/tmp/foo" does not trigger a
            # false positive when checking for the bare "/tmp/foo" pattern.
            bare_pattern = r"(?<!\.loops)" + re.escape(forbidden)
            assert not re.search(bare_pattern, combined), (
                f"{loop_name}.yaml still references global tmp path: {forbidden!r}"
            )


class TestEvaluationQualityLoop:
    """Structural tests for the evaluation-quality FSM loop."""

    LOOP_FILE = BUILTIN_LOOPS_DIR / "evaluation-quality.yaml"

    @pytest.fixture
    def data(self) -> dict:
        assert self.LOOP_FILE.exists(), f"Loop file not found: {self.LOOP_FILE}"
        return yaml.safe_load(self.LOOP_FILE.read_text())

    def test_required_top_level_fields(self, data: dict) -> None:
        """Loop must have name, initial, and states fields."""
        assert data.get("name") == "evaluation-quality"
        assert data.get("initial") == "sample"
        assert isinstance(data.get("states"), dict)

    def test_required_states_exist(self, data: dict) -> None:
        """All required states must be present."""
        required = {
            "sample",
            "evaluate_code",
            "score",
            "route_action",
            "route_issues",
            "route_code",
            "remediate_issues",
            "remediate_code",
            "remediate_backlog",
            "prepare_report",
            "report",
            "done",
        }
        actual = set(data["states"].keys())
        missing = required - actual
        assert not missing, f"Missing states: {missing}"

    def test_done_state_is_terminal(self, data: dict) -> None:
        """done state must have terminal: true."""
        done_state = data["states"].get("done", {})
        assert done_state.get("terminal") is True

    def test_score_state_has_capture(self, data: dict) -> None:
        """score state must define capture: scores so route states can interpolate it."""
        score_state = data["states"].get("score", {})
        assert score_state.get("capture") == "scores"

    def test_route_states_have_on_error(self, data: dict) -> None:
        """All route/evaluate states must define on_error to prevent hangs."""
        route_states = ["route_action", "route_issues", "route_code"]
        for state_name in route_states:
            state = data["states"].get(state_name, {})
            assert "on_error" in state, f"Route state '{state_name}' missing on_error"

    def test_context_thresholds_defined(self, data: dict) -> None:
        """context block must define the three quality thresholds."""
        ctx = data.get("context", {})
        assert "issue_quality_threshold" in ctx
        assert "code_health_threshold" in ctx
        assert "backlog_health_threshold" in ctx

    def test_evaluate_code_uses_loops_tmp(self, data: dict) -> None:
        """evaluate_code state must use .loops/tmp/ paths, not bare /tmp/."""
        action = data["states"].get("evaluate_code", {}).get("action", "")
        assert ".loops/tmp/" in action, "evaluate_code must use .loops/tmp/ for output files"
        # Bare /tmp/... references are forbidden; .loops/tmp/... is fine.
        # Use negative lookbehind to avoid false positives on ".loops/tmp/eval-..."
        assert not re.search(r"(?<!\.loops)/tmp/eval-", action), (
            "evaluate_code must not use bare /tmp/ paths"
        )

    def test_prepare_report_is_shell_state(self, data: dict) -> None:
        """prepare_report must be a shell state (date expansion needs shell context)."""
        state = data["states"].get("prepare_report", {})
        assert state.get("action_type") == "shell"

    def test_report_references_captured_report_path(self, data: dict) -> None:
        """report state must reference ${captured.report_path.output} for dated filename."""
        action = data["states"].get("report", {}).get("action", "")
        assert "${captured.report_path.output}" in action

    def test_score_state_emits_primary_concern(self, data: dict) -> None:
        """score state prompt must instruct output of PRIMARY_CONCERN tag."""
        action = data["states"].get("score", {}).get("action", "")
        assert "PRIMARY_CONCERN" in action

    def test_route_action_routes_on_none(self, data: dict) -> None:
        """route_action must route to prepare_report when PRIMARY_CONCERN: NONE.

        prepare_report is required in all paths (including the healthy/NONE path)
        because $(date +%Y-%m-%d) does not expand in prompt states — a shell state
        must compute the dated report path before the report prompt state runs.
        """
        state = data["states"].get("route_action", {})
        assert state.get("on_yes") == "prepare_report"
        evaluate = state.get("evaluate", {})
        assert "NONE" in evaluate.get("pattern", "")

    def test_max_iterations_and_timeout(self, data: dict) -> None:
        """Loop must define max_iterations and timeout."""
        assert data.get("max_iterations", 0) > 0
        assert data.get("timeout", 0) > 0


class TestIssueRefinementSubLoop:
    """Tests that issue-refinement.yaml delegates refinement to the refine-to-ready-issue sub-loop."""

    LOOP_FILE = BUILTIN_LOOPS_DIR / "issue-refinement.yaml"
    REMOVED_STATES = [
        "route_format",
        "route_verify",
        "route_score",
        "format_issues",
        "score_issues",
        "refine_issues",
        "verify_only",
    ]

    @pytest.fixture
    def data(self) -> dict:
        assert self.LOOP_FILE.exists(), f"Loop file not found: {self.LOOP_FILE}"
        return yaml.safe_load(self.LOOP_FILE.read_text())

    def test_parse_id_capture_is_input(self, data: dict) -> None:
        """parse_id must capture as 'input' so context_passthrough injects it into child loop."""
        parse_id = data["states"].get("parse_id", {})
        assert parse_id.get("capture") == "input", (
            f"parse_id.capture should be 'input', got {parse_id.get('capture')!r} — "
            f"child loop reads context.input via context_passthrough"
        )

    def test_parse_id_routes_to_sub_loop(self, data: dict) -> None:
        """parse_id.on_yes must route to run_refine_to_ready, not route_format."""
        parse_id = data["states"].get("parse_id", {})
        assert parse_id.get("on_yes") == "run_refine_to_ready", (
            f"parse_id.on_yes should be 'run_refine_to_ready', got {parse_id.get('on_yes')!r}"
        )

    def test_run_refine_to_ready_state_exists(self, data: dict) -> None:
        """run_refine_to_ready sub-loop state must exist."""
        assert "run_refine_to_ready" in data["states"], (
            "State 'run_refine_to_ready' not found in issue-refinement.yaml"
        )

    def test_run_refine_to_ready_uses_sub_loop(self, data: dict) -> None:
        """run_refine_to_ready must use 'loop:' field to invoke refine-to-ready-issue."""
        state = data["states"].get("run_refine_to_ready", {})
        assert state.get("loop") == "refine-to-ready-issue", (
            f"run_refine_to_ready.loop should be 'refine-to-ready-issue', got {state.get('loop')!r}"
        )

    def test_run_refine_to_ready_has_context_passthrough(self, data: dict) -> None:
        """run_refine_to_ready must set context_passthrough: true to inject captured input."""
        state = data["states"].get("run_refine_to_ready", {})
        assert state.get("context_passthrough") is True, (
            f"run_refine_to_ready.context_passthrough should be true, got {state.get('context_passthrough')!r}"
        )

    def test_run_refine_to_ready_routes_to_check_commit(self, data: dict) -> None:
        """run_refine_to_ready on_yes must route to check_commit."""
        state = data["states"].get("run_refine_to_ready", {})
        assert state.get("on_yes") == "check_commit", (
            f"run_refine_to_ready.on_yes should be 'check_commit', got {state.get('on_yes')!r}"
        )

    def test_run_refine_to_ready_on_no_routes_to_handle_failure(self, data: dict) -> None:
        """run_refine_to_ready on_no must route to handle_failure for skip-list tracking."""
        state = data["states"].get("run_refine_to_ready", {})
        assert state.get("on_no") == "handle_failure", (
            f"run_refine_to_ready.on_no should be 'handle_failure', got {state.get('on_no')!r}"
        )

    def test_handle_failure_state_exists(self, data: dict) -> None:
        """handle_failure state must exist to track failed issues in skip list."""
        assert "handle_failure" in data["states"], (
            "State 'handle_failure' not found in issue-refinement.yaml"
        )

    def test_handle_failure_next_is_check_commit(self, data: dict) -> None:
        """handle_failure must route next to check_commit after appending to skip list."""
        state = data["states"].get("handle_failure", {})
        assert state.get("next") == "check_commit", (
            f"handle_failure.next should be 'check_commit', got {state.get('next')!r}"
        )

    def test_evaluate_action_includes_skip_list(self, data: dict) -> None:
        """evaluate action must pass skip list to ll-issues next-action."""
        evaluate = data["states"].get("evaluate", {})
        action = evaluate.get("action", "")
        assert "issue-refinement-skip-list" in action, (
            f"evaluate.action should reference issue-refinement-skip-list, got: {action!r}"
        )

    def test_init_action_clears_skip_list(self, data: dict) -> None:
        """init action must clear the skip list at the start of each run."""
        init = data["states"].get("init", {})
        action = init.get("action", "")
        assert "issue-refinement-skip-list" in action, (
            f"init.action should clear issue-refinement-skip-list, got: {action!r}"
        )

    @pytest.mark.parametrize("state_name", REMOVED_STATES)
    def test_removed_states_absent(self, data: dict, state_name: str) -> None:
        """Inline routing and prompt states must be removed — logic lives in refine-to-ready-issue."""
        assert state_name not in data["states"], (
            f"State '{state_name}' should have been removed; logic delegated to refine-to-ready-issue sub-loop"
        )


class TestRefineToReadyIssueSubLoop:
    """Tests that refine-to-ready-issue.yaml routes correctly through wire, breakdown, and confidence states."""

    LOOP_FILE = BUILTIN_LOOPS_DIR / "refine-to-ready-issue.yaml"

    @pytest.fixture
    def data(self) -> dict:
        assert self.LOOP_FILE.exists(), f"Loop file not found: {self.LOOP_FILE}"
        return yaml.safe_load(self.LOOP_FILE.read_text())

    def test_confidence_check_routes_to_verify_scores_persisted(self, data: dict) -> None:
        """confidence_check must route to verify_scores_persisted guard before check_readiness (ENH-1033 + guard)."""
        confidence_check = data["states"].get("confidence_check", {})
        assert confidence_check.get("next") == "verify_scores_persisted", (
            f"confidence_check.next should be 'verify_scores_persisted', got {confidence_check.get('next')!r}"
        )

    def test_confidence_check_has_on_error(self, data: dict) -> None:
        """confidence_check must define on_error so a SIGKILL'd subprocess routes to diagnose
        rather than calling request_shutdown() and cascading a full loop termination."""
        confidence_check = data["states"].get("confidence_check", {})
        assert confidence_check.get("on_error") == "diagnose", (
            f"confidence_check.on_error should be 'diagnose', got {confidence_check.get('on_error')!r}"
        )

    def test_verify_scores_persisted_on_yes_routes_to_check_readiness(self, data: dict) -> None:
        """verify_scores_persisted.on_yes must route to check_readiness (scores written → proceed)."""
        state = data["states"].get("verify_scores_persisted", {})
        assert state.get("on_yes") == "check_readiness", (
            f"verify_scores_persisted.on_yes should be 'check_readiness', got {state.get('on_yes')!r}"
        )

    def test_verify_scores_persisted_on_no_routes_to_retry_confidence_check(
        self, data: dict
    ) -> None:
        """verify_scores_persisted.on_no must route to retry_confidence_check (one re-run before failing)."""
        state = data["states"].get("verify_scores_persisted", {})
        assert state.get("on_no") == "retry_confidence_check", (
            f"verify_scores_persisted.on_no should be 'retry_confidence_check', got {state.get('on_no')!r}"
        )

    def test_check_readiness_on_yes_routes_to_check_outcome(self, data: dict) -> None:
        """check_readiness.on_yes must route to check_outcome (readiness passed → check outcome next)."""
        state = data["states"].get("check_readiness", {})
        assert state.get("on_yes") == "check_outcome", (
            f"check_readiness.on_yes should be 'check_outcome', got {state.get('on_yes')!r}"
        )

    def test_check_readiness_on_no_routes_to_check_refine_limit(self, data: dict) -> None:
        """check_readiness.on_no must route to check_refine_limit (technical gap → retry refinement)."""
        state = data["states"].get("check_readiness", {})
        assert state.get("on_no") == "check_refine_limit", (
            f"check_readiness.on_no should be 'check_refine_limit', got {state.get('on_no')!r}"
        )

    def test_check_readiness_on_error_is_check_scores_from_file(self, data: dict) -> None:
        """check_readiness.on_error must route to check_scores_from_file (preserves error fallback)."""
        state = data["states"].get("check_readiness", {})
        assert state.get("on_error") == "check_scores_from_file", (
            f"check_readiness.on_error should be 'check_scores_from_file', got {state.get('on_error')!r}"
        )

    def test_check_outcome_on_yes_routes_to_done(self, data: dict) -> None:
        """check_outcome.on_yes must route to done (both scores pass)."""
        state = data["states"].get("check_outcome", {})
        assert state.get("on_yes") == "done", (
            f"check_outcome.on_yes should be 'done', got {state.get('on_yes')!r}"
        )

    def test_check_outcome_on_no_routes_to_check_decision_needed(self, data: dict) -> None:
        """check_outcome.on_no must route to check_decision_needed (outcome fail → decision check before breakdown)."""
        state = data["states"].get("check_outcome", {})
        assert state.get("on_no") == "check_decision_needed", (
            f"check_outcome.on_no should be 'check_decision_needed', got {state.get('on_no')!r}"
        )

    def test_check_scores_from_file_state_exists(self, data: dict) -> None:
        """check_scores_from_file state must exist as the error recovery path for confidence_check."""
        assert "check_scores_from_file" in data["states"], (
            "State 'check_scores_from_file' not found in refine-to-ready-issue.yaml — "
            "required as fallback when confidence_check LLM evaluation times out"
        )

    def test_check_scores_from_file_routes_to_done(self, data: dict) -> None:
        """check_scores_from_file.on_yes must route to done when scores meet thresholds."""
        state = data["states"].get("check_scores_from_file", {})
        assert state.get("on_yes") == "done", (
            f"check_scores_from_file.on_yes should be 'done', got {state.get('on_yes')!r}"
        )

    def test_check_scores_from_file_routes_to_breakdown_issue_on_no(self, data: dict) -> None:
        """check_scores_from_file.on_no must route to breakdown_issue (ENH-1033: outcome-only fails avoid retry)."""
        state = data["states"].get("check_scores_from_file", {})
        assert state.get("on_no") == "breakdown_issue", (
            f"check_scores_from_file.on_no should be 'breakdown_issue', got {state.get('on_no')!r}"
        )

    def test_verify_issue_state_absent(self, data: dict) -> None:
        """verify_issue state must not exist — it was removed in ENH-980."""
        assert "verify_issue" not in data["states"], (
            "State 'verify_issue' should have been removed; confidence_check.on_yes now routes to 'done'"
        )

    def test_check_lifetime_limit_routes_to_breakdown_issue(self, data: dict) -> None:
        """check_lifetime_limit.on_no must route to breakdown_issue (not failed)."""
        state = data["states"].get("check_lifetime_limit", {})
        assert state.get("on_no") == "breakdown_issue", (
            f"check_lifetime_limit.on_no should be 'breakdown_issue', got {state.get('on_no')!r}"
        )

    def test_breakdown_issue_state_exists(self, data: dict) -> None:
        """breakdown_issue state must exist to invoke /ll:issue-size-review on cap exhaustion."""
        assert "breakdown_issue" in data["states"], (
            "State 'breakdown_issue' not found in refine-to-ready-issue.yaml"
        )

    def test_breakdown_issue_is_slash_command(self, data: dict) -> None:
        """breakdown_issue must use action_type: slash_command."""
        state = data["states"].get("breakdown_issue", {})
        assert state.get("action_type") == "slash_command", (
            f"breakdown_issue.action_type should be 'slash_command', got {state.get('action_type')!r}"
        )

    def test_breakdown_issue_action_contains_auto(self, data: dict) -> None:
        """breakdown_issue action must include --auto to avoid blocking on interactive input."""
        state = data["states"].get("breakdown_issue", {})
        assert "--auto" in state.get("action", ""), (
            "breakdown_issue action must include '--auto' flag to prevent interactive stalling"
        )

    def test_breakdown_issue_routes_to_write_broke_down(self, data: dict) -> None:
        """breakdown_issue.next must be 'write_broke_down' to set the flag before exiting."""
        state = data["states"].get("breakdown_issue", {})
        assert state.get("next") == "write_broke_down", (
            f"breakdown_issue.next should be 'write_broke_down', got {state.get('next')!r}"
        )

    def test_write_broke_down_state_exists(self, data: dict) -> None:
        """write_broke_down state must exist to signal to recursive-refine that breakdown ran."""
        assert "write_broke_down" in data["states"], (
            "State 'write_broke_down' not found in refine-to-ready-issue.yaml"
        )

    def test_write_broke_down_routes_to_done(self, data: dict) -> None:
        """write_broke_down.next must route to done."""
        state = data["states"].get("write_broke_down", {})
        assert state.get("next") == "done", (
            f"write_broke_down.next should be 'done', got {state.get('next')!r}"
        )

    def test_write_broke_down_action_writes_flag(self, data: dict) -> None:
        """write_broke_down action must write to the recursive-refine-broke-down flag file."""
        state = data["states"].get("write_broke_down", {})
        assert "recursive-refine-broke-down" in state.get("action", ""), (
            "write_broke_down action must write to '.loops/tmp/recursive-refine-broke-down'"
        )

    def test_broke_down_flag_initialized_in_resolve_issue(self, data: dict) -> None:
        """resolve_issue action must initialize the recursive-refine-broke-down flag file."""
        state = data["states"].get("resolve_issue", {})
        assert "recursive-refine-broke-down" in state.get("action", ""), (
            "resolve_issue action must initialize '.loops/tmp/recursive-refine-broke-down' flag"
        )

    def test_breakdown_issue_on_error_is_diagnose(self, data: dict) -> None:
        """breakdown_issue.on_error must route to 'diagnose', not 'failed' directly."""
        state = data["states"].get("breakdown_issue", {})
        assert state.get("on_error") == "diagnose", (
            f"breakdown_issue.on_error should be 'diagnose', got {state.get('on_error')!r}"
        )

    def test_diagnose_routes_to_failed(self, data: dict) -> None:
        """diagnose state must route to failed."""
        state = data["states"].get("diagnose", {})
        assert state.get("next") == "failed"

    def test_diagnose_is_not_terminal(self, data: dict) -> None:
        """diagnose state must not be a terminal state."""
        state = data["states"].get("diagnose", {})
        assert not state.get("terminal", False)

    def test_check_wire_done_state_exists(self, data: dict) -> None:
        """check_wire_done state must exist to gate wire_issue to once per run."""
        assert "check_wire_done" in data["states"], (
            "State 'check_wire_done' not found in refine-to-ready-issue.yaml"
        )

    def test_check_wire_done_evaluate_output_numeric_lt_1(self, data: dict) -> None:
        """check_wire_done must use output_numeric lt 1 to detect whether wire has run."""
        state = data["states"].get("check_wire_done", {})
        evaluate = state.get("evaluate", {})
        assert evaluate.get("type") == "output_numeric", (
            f"check_wire_done evaluate.type should be 'output_numeric', got {evaluate.get('type')!r}"
        )
        assert evaluate.get("operator") == "lt", (
            f"check_wire_done evaluate.operator should be 'lt', got {evaluate.get('operator')!r}"
        )
        assert evaluate.get("target") == 1, (
            f"check_wire_done evaluate.target should be 1, got {evaluate.get('target')!r}"
        )

    def test_wire_issue_state_exists(self, data: dict) -> None:
        """wire_issue state must exist to run /ll:wire-issue once per loop run."""
        assert "wire_issue" in data["states"], (
            "State 'wire_issue' not found in refine-to-ready-issue.yaml"
        )

    def test_wire_issue_action_contains_auto(self, data: dict) -> None:
        """wire_issue action must include --auto to avoid blocking on interactive input."""
        state = data["states"].get("wire_issue", {})
        assert "--auto" in state.get("action", ""), (
            "wire_issue action must include '--auto' flag to prevent interactive stalling"
        )

    def test_wire_issue_on_error_is_confidence_check(self, data: dict) -> None:
        """wire_issue.on_error must route to confidence_check (wiring failure is non-fatal)."""
        state = data["states"].get("wire_issue", {})
        assert state.get("on_error") == "confidence_check", (
            f"wire_issue.on_error should be 'confidence_check', got {state.get('on_error')!r}"
        )

    def test_mark_wire_done_state_exists(self, data: dict) -> None:
        """mark_wire_done state must exist to set the wire-done flag after wiring."""
        assert "mark_wire_done" in data["states"], (
            "State 'mark_wire_done' not found in refine-to-ready-issue.yaml"
        )

    def test_mark_wire_done_routes_to_confidence_check(self, data: dict) -> None:
        """mark_wire_done.next must route to confidence_check."""
        state = data["states"].get("mark_wire_done", {})
        assert state.get("next") == "confidence_check", (
            f"mark_wire_done.next should be 'confidence_check', got {state.get('next')!r}"
        )

    def test_wire_done_flag_initialized_in_resolve_issue(self, data: dict) -> None:
        """resolve_issue action must initialize the wire-done flag file."""
        state = data["states"].get("resolve_issue", {})
        assert "refine-to-ready-wire-done" in state.get("action", ""), (
            "resolve_issue action must initialize '.loops/tmp/refine-to-ready-wire-done' flag"
        )

    def test_check_refine_limit_routes_to_refine_issue(self, data: dict) -> None:
        """check_refine_limit.on_yes must route directly to refine_issue (not check_lifetime_limit)."""
        state = data["states"].get("check_refine_limit", {})
        assert state.get("on_yes") == "refine_issue", (
            f"check_refine_limit.on_yes should be 'refine_issue', got {state.get('on_yes')!r}"
        )

    def test_check_refine_limit_on_no_routes_to_breakdown_issue(self, data: dict) -> None:
        """check_refine_limit.on_no must route to breakdown_issue (not failed)."""
        state = data["states"].get("check_refine_limit", {})
        assert state.get("on_no") == "breakdown_issue", (
            f"check_refine_limit.on_no should be 'breakdown_issue', got {state.get('on_no')!r}"
        )

    def test_check_missing_artifacts_state_exists(self, data: dict) -> None:
        """check_missing_artifacts state must exist to gate size-review on wiring gaps (BUG-1490)."""
        assert "check_missing_artifacts" in data["states"], (
            "State 'check_missing_artifacts' not found in refine-to-ready-issue.yaml — "
            "required to prevent size-review running on issues with missing_artifacts=true"
        )

    def test_check_missing_artifacts_uses_shell_exit_fragment(self, data: dict) -> None:
        """check_missing_artifacts must use shell_exit fragment to route on exit code."""
        state = data["states"].get("check_missing_artifacts", {})
        assert state.get("fragment") == "shell_exit", (
            f"check_missing_artifacts.fragment should be 'shell_exit', got {state.get('fragment')!r}"
        )

    def test_check_missing_artifacts_on_yes_routes_to_done(self, data: dict) -> None:
        """check_missing_artifacts.on_yes (missing_artifacts=true) must exit via done so the outer loop owns wire repair."""
        state = data["states"].get("check_missing_artifacts", {})
        assert state.get("on_yes") == "done", (
            f"check_missing_artifacts.on_yes should be 'done', got {state.get('on_yes')!r}"
        )

    def test_check_missing_artifacts_on_no_routes_to_breakdown_issue(self, data: dict) -> None:
        """check_missing_artifacts.on_no must route to breakdown_issue (no artifact gap → scope too large)."""
        state = data["states"].get("check_missing_artifacts", {})
        assert state.get("on_no") == "breakdown_issue", (
            f"check_missing_artifacts.on_no should be 'breakdown_issue', got {state.get('on_no')!r}"
        )

    def test_check_decision_needed_on_no_routes_to_check_missing_artifacts(
        self, data: dict
    ) -> None:
        """check_decision_needed.on_no must route to check_missing_artifacts, not breakdown_issue (BUG-1490)."""
        state = data["states"].get("check_decision_needed", {})
        assert state.get("on_no") == "check_missing_artifacts", (
            f"check_decision_needed.on_no should be 'check_missing_artifacts', got {state.get('on_no')!r}"
        )


class TestHarnessCapture:
    """Tests that harness YAML files wire execute output to check_semantic via capture/source."""

    HARNESS_FILES = [
        "harness-single-shot.yaml",
        "harness-multi-item.yaml",
    ]

    @pytest.mark.parametrize("loop_name", HARNESS_FILES)
    def test_execute_state_has_capture_execute_result(self, loop_name: str) -> None:
        """execute state must define capture: execute_result so check_semantic can reference it."""
        path = BUILTIN_LOOPS_DIR / loop_name
        assert path.exists(), f"Loop file not found: {path}"
        data = yaml.safe_load(path.read_text())
        execute_state = data.get("states", {}).get("execute", {})
        assert execute_state.get("capture") == "execute_result", (
            f"{loop_name}: execute state must have 'capture: execute_result' so "
            f"check_semantic can reference the skill output via ${{captured.execute_result.output}}"
        )

    @pytest.mark.parametrize("loop_name", HARNESS_FILES)
    def test_check_semantic_evaluate_has_source(self, loop_name: str) -> None:
        """check_semantic evaluate block must define source pointing to execute's captured output."""
        path = BUILTIN_LOOPS_DIR / loop_name
        assert path.exists(), f"Loop file not found: {path}"
        data = yaml.safe_load(path.read_text())
        check_semantic = data.get("states", {}).get("check_semantic", {})
        evaluate = check_semantic.get("evaluate", {})
        assert evaluate.get("source") == "${captured.execute_result.output}", (
            f"{loop_name}: check_semantic.evaluate must have "
            f"'source: \"${{captured.execute_result.output}}\"' so the LLM evaluator "
            f"receives actual skill output as evidence, not the echo string"
        )


class TestBuiltinLoopOnBlockedCoverage:
    """Tests that llm_structured evaluate states in built-in loops define on_blocked handlers."""

    # Each entry: (loop_file, state_name, expected_on_blocked_value)
    REQUIRED_ON_BLOCKED: list[tuple[str, str, str]] = [
        ("issue-staleness-review.yaml", "triage", "find_stale"),
    ]

    @pytest.mark.parametrize("loop_file,state_name,expected", REQUIRED_ON_BLOCKED)
    def test_llm_structured_state_has_on_blocked(
        self, loop_file: str, state_name: str, expected: str
    ) -> None:
        """Each audited llm_structured evaluate state must define on_blocked."""
        path = BUILTIN_LOOPS_DIR / loop_file
        assert path.exists(), f"Loop file not found: {path}"
        data = yaml.safe_load(path.read_text())
        state_data = data.get("states", {}).get(state_name)
        assert state_data is not None, f"State '{state_name}' not found in {loop_file}"
        assert state_data.get("evaluate", {}).get("type") == "llm_structured", (
            f"State '{state_name}' in {loop_file} is not an llm_structured evaluate state"
        )
        assert "on_blocked" in state_data, (
            f"State '{state_name}' in {loop_file} is missing on_blocked handler"
        )
        assert state_data["on_blocked"] == expected, (
            f"State '{state_name}' in {loop_file}: expected on_blocked={expected!r}, "
            f"got {state_data['on_blocked']!r}"
        )


class TestPromptAcrossIssuesLoop:
    """Structural tests for the prompt-across-issues FSM loop."""

    LOOP_FILE = BUILTIN_LOOPS_DIR / "prompt-across-issues.yaml"

    @pytest.fixture
    def data(self) -> dict:
        assert self.LOOP_FILE.exists(), f"Loop file not found: {self.LOOP_FILE}"
        return yaml.safe_load(self.LOOP_FILE.read_text())

    def test_required_top_level_fields(self, data: dict) -> None:
        """Loop must have name, initial, and states fields."""
        assert data.get("name") == "prompt-across-issues"
        assert data.get("initial") == "init"
        assert isinstance(data.get("states"), dict)

    def test_required_states_exist(self, data: dict) -> None:
        """All required states must be present."""
        required = {
            "init",
            "discover",
            "prepare_prompt",
            "execute",
            "advance",
            "done",
            "diagnose_error",
            "error",
        }
        actual = set(data["states"].keys())
        missing = required - actual
        assert not missing, f"Missing states: {missing}"

    def test_done_state_is_terminal(self, data: dict) -> None:
        """done state must have terminal: true."""
        done_state = data["states"].get("done", {})
        assert done_state.get("terminal") is True

    def test_error_state_is_terminal(self, data: dict) -> None:
        """error state must have terminal: true."""
        error_state = data["states"].get("error", {})
        assert error_state.get("terminal") is True

    def test_discover_captures_current_item(self, data: dict) -> None:
        """discover state must capture as 'current_item'."""
        discover_state = data["states"].get("discover", {})
        assert discover_state.get("capture") == "current_item"

    def test_prepare_prompt_captures_final_prompt(self, data: dict) -> None:
        """prepare_prompt state must capture as 'final_prompt'."""
        prepare_state = data["states"].get("prepare_prompt", {})
        assert prepare_state.get("capture") == "final_prompt"

    def test_execute_uses_final_prompt(self, data: dict) -> None:
        """execute state action must reference ${captured.final_prompt.output}."""
        execute_state = data["states"].get("execute", {})
        action = execute_state.get("action", "")
        assert "${captured.final_prompt.output}" in action

    def test_advance_removes_from_pending_file(self, data: dict) -> None:
        """advance state action must modify the pending.txt file."""
        advance_state = data["states"].get("advance", {})
        action = advance_state.get("action", "")
        assert "pending" in action

    def test_advance_emits_progress_count(self, data: dict) -> None:
        """advance state action must compute REMAINING and echo a progress line."""
        advance_state = data["states"].get("advance", {})
        action = advance_state.get("action", "")
        assert "REMAINING" in action
        assert "remaining" in action

    def test_init_validates_input(self, data: dict) -> None:
        """init state action must check that ${context.input} is non-empty."""
        init_state = data["states"].get("init", {})
        action = init_state.get("action", "")
        assert "${context.input}" in action

    def test_execute_has_max_retries(self, data: dict) -> None:
        """execute state must define max_retries to prevent stuck items."""
        execute_state = data["states"].get("execute", {})
        assert execute_state.get("max_retries", 0) > 0

    def test_diagnose_error_routes_to_error(self, data: dict) -> None:
        state = data["states"].get("diagnose_error", {})
        assert state.get("next") == "error"

    def test_diagnose_error_is_not_terminal(self, data: dict) -> None:
        state = data["states"].get("diagnose_error", {})
        assert not state.get("terminal", False)

    def test_init_on_error_routes_to_diagnose_error(self, data: dict) -> None:
        state = data["states"].get("init", {})
        assert state.get("on_error") == "diagnose_error"


class TestAutoRefineAndImplementLoop:
    """Structural tests for the auto-refine-and-implement FSM loop."""

    LOOP_FILE = BUILTIN_LOOPS_DIR / "auto-refine-and-implement.yaml"

    @pytest.fixture
    def data(self) -> dict:
        assert self.LOOP_FILE.exists(), f"Loop file not found: {self.LOOP_FILE}"
        return yaml.safe_load(self.LOOP_FILE.read_text())

    def test_required_top_level_fields(self, data: dict) -> None:
        """Loop must have name, initial, and states fields."""
        assert data.get("name") == "auto-refine-and-implement"
        assert data.get("initial") == "init"
        assert isinstance(data.get("states"), dict)

    def test_required_states_exist(self, data: dict) -> None:
        """All required states must be present."""
        required = {
            "init",
            "get_next_issue",
            "refine_issue",
            "get_passed_issues",
            "implement_next",
            "implement_issue",
            "skip_and_continue",
            "done",
        }
        actual = set(data["states"].keys())
        missing = required - actual
        assert not missing, f"Missing states: {missing}"

    def test_init_state_exists(self, data: dict) -> None:
        """init state must exist to clear temp files on each fresh run."""
        assert "init" in data["states"], "init state missing from auto-refine-and-implement"

    def test_init_state_is_shell_type(self, data: dict) -> None:
        """init state must be a shell action with unconditional next: get_next_issue."""
        init = data["states"].get("init", {})
        assert init.get("action_type") == "shell"
        assert init.get("next") == "get_next_issue"

    def test_init_clears_skip_file(self, data: dict) -> None:
        """init action must clear the skip file so each run starts fresh."""
        init = data["states"].get("init", {})
        action = init.get("action", "")
        assert "auto-refine-and-implement-skipped.txt" in action, (
            f"init.action should clear auto-refine-and-implement-skipped.txt, got: {action!r}"
        )

    def test_init_clears_impl_queue_file(self, data: dict) -> None:
        """init action must clear the impl queue so each run starts fresh."""
        init = data["states"].get("init", {})
        action = init.get("action", "")
        assert "auto-refine-and-implement-impl-queue.txt" in action, (
            f"init.action should clear auto-refine-and-implement-impl-queue.txt, got: {action!r}"
        )

    def test_done_state_is_terminal(self, data: dict) -> None:
        """done state must have terminal: true."""
        done_state = data["states"].get("done", {})
        assert done_state.get("terminal") is True

    def test_get_next_issue_captures_input(self, data: dict) -> None:
        """get_next_issue must capture as 'input' for context_passthrough to work."""
        state = data["states"].get("get_next_issue", {})
        assert state.get("capture") == "input"

    def test_refine_issue_delegates_to_recursive_refine(self, data: dict) -> None:
        """refine_issue must delegate to recursive-refine with explicit input binding."""
        state = data["states"].get("refine_issue", {})
        assert state.get("loop") == "recursive-refine"
        # Migrated from context_passthrough to explicit with: binding (FEAT-1311)
        assert "input" in state.get("with", {}), (
            "refine_issue must bind 'input' via 'with:' to pass the issue ID to recursive-refine"
        )

    def test_refine_issue_has_success_and_failure_routes(self, data: dict) -> None:
        """refine_issue must define on_success and on_failure routes."""
        state = data["states"].get("refine_issue", {})
        assert state.get("on_success") == "get_passed_issues"
        assert state.get("on_failure") == "skip_and_continue"

    def test_implement_next_captures_impl_id(self, data: dict) -> None:
        """implement_next must capture as 'impl_id' for implement_issue to reference."""
        state = data["states"].get("implement_next", {})
        assert state.get("capture") == "impl_id"

    def test_implement_issue_uses_impl_id(self, data: dict) -> None:
        """implement_issue action must reference captured.impl_id.output."""
        state = data["states"].get("implement_issue", {})
        action = state.get("action", "")
        assert "${captured.impl_id.output}" in action

    def test_implement_issue_routes_to_implement_next(self, data: dict) -> None:
        """implement_issue must loop back to implement_next to drain the queue."""
        state = data["states"].get("implement_issue", {})
        assert state.get("next") == "implement_next"

    def test_implement_issue_has_completed_guard(self, data: dict) -> None:
        """implement_issue must skip ll-auto when the issue is already in completed/."""
        state = data["states"].get("implement_issue", {})
        action = state.get("action", "")
        assert "completed" in action, "implement_issue action must check .issues/completed/"
        assert "exit 0" in action, (
            "implement_issue action must exit 0 when issue is already completed"
        )

    def test_go_no_go_uses_ll_action_invoke(self, data: dict) -> None:
        """go_no_go must call ll-action via the invoke subcommand, not pass the skill as a subcommand."""
        state = data["states"].get("go_no_go", {})
        action = state.get("action", "")
        assert "ll-action invoke" in action, (
            "go_no_go action must use 'll-action invoke', not 'll-action go-no-go'"
        )
        assert "--check" in action, "go_no_go action must pass --check flag"

    def test_skip_and_continue_uses_input_capture(self, data: dict) -> None:
        """skip_and_continue must reference captured.input.output (not impl_id)."""
        state = data["states"].get("skip_and_continue", {})
        action = state.get("action", "")
        assert "${captured.input.output}" in action

    def test_skip_and_continue_routes_to_get_next_issue(self, data: dict) -> None:
        """skip_and_continue must route back to get_next_issue."""
        state = data["states"].get("skip_and_continue", {})
        assert state.get("next") == "get_next_issue"

    def test_skipped_file_uses_loops_tmp(self, data: dict) -> None:
        """Skipped tracking file must use .loops/tmp/ path."""
        states = data.get("states", {})
        skipped_ref = "auto-refine-and-implement-skipped"
        found = False
        for state_data in states.values():
            action = state_data.get("action", "")
            if skipped_ref in action:
                found = True
                assert ".loops/tmp/" in action
        assert found, f"No state references {skipped_ref!r}"

    def test_impl_queue_file_uses_loops_tmp(self, data: dict) -> None:
        """Impl queue file must use .loops/tmp/ path."""
        states = data.get("states", {})
        queue_ref = "auto-refine-and-implement-impl-queue"
        found = False
        for state_data in states.values():
            action = state_data.get("action", "")
            if queue_ref in action:
                found = True
                assert ".loops/tmp/" in action
        assert found, f"No state references {queue_ref!r}"

    def test_get_passed_issues_reads_recursive_refine_outputs(self, data: dict) -> None:
        """get_passed_issues must read both recursive-refine output files."""
        state = data["states"].get("get_passed_issues", {})
        action = state.get("action", "")
        assert "recursive-refine-passed.txt" in action
        assert "recursive-refine-skipped.txt" in action


class TestSprintRefineAndImplementLoop:
    """Structural tests for the sprint-refine-and-implement FSM loop."""

    LOOP_FILE = BUILTIN_LOOPS_DIR / "sprint-refine-and-implement.yaml"

    @pytest.fixture
    def data(self) -> dict:
        assert self.LOOP_FILE.exists(), f"Loop file not found: {self.LOOP_FILE}"
        return yaml.safe_load(self.LOOP_FILE.read_text())

    def test_required_states_exist(self, data: dict) -> None:
        """All required states must be present."""
        required = {
            "implement_next",
            "implement_issue",
            "done",
        }
        actual = set(data["states"].keys())
        missing = required - actual
        assert not missing, f"Missing states: {missing}"

    def test_implement_issue_uses_impl_id(self, data: dict) -> None:
        """implement_issue action must reference captured.impl_id.output."""
        state = data["states"].get("implement_issue", {})
        action = state.get("action", "")
        assert "${captured.impl_id.output}" in action

    def test_implement_issue_routes_to_implement_next(self, data: dict) -> None:
        """implement_issue must loop back to implement_next to drain the queue."""
        state = data["states"].get("implement_issue", {})
        assert state.get("next") == "implement_next"

    def test_implement_issue_has_completed_guard(self, data: dict) -> None:
        """implement_issue must skip ll-auto when the issue is already in completed/."""
        state = data["states"].get("implement_issue", {})
        action = state.get("action", "")
        assert "completed" in action, "implement_issue action must check .issues/completed/"
        assert "exit 0" in action, (
            "implement_issue action must exit 0 when issue is already completed"
        )

    def test_go_no_go_uses_ll_action_invoke(self, data: dict) -> None:
        """go_no_go must call ll-action via the invoke subcommand, not pass the skill as a subcommand."""
        state = data["states"].get("go_no_go", {})
        action = state.get("action", "")
        assert "ll-action invoke" in action, (
            "go_no_go action must use 'll-action invoke', not 'll-action go-no-go'"
        )
        assert "--check" in action, "go_no_go action must pass --check flag"


class TestAutodevLoop:
    """Structural tests for the autodev FSM loop (ENH-1127: interleaved refine+implement)."""

    LOOP_FILE = BUILTIN_LOOPS_DIR / "autodev.yaml"

    @pytest.fixture
    def data(self) -> dict:
        assert self.LOOP_FILE.exists(), f"Loop file not found: {self.LOOP_FILE}"
        return yaml.safe_load(self.LOOP_FILE.read_text())

    def test_required_top_level_fields(self, data: dict) -> None:
        """Loop must have name, initial, and states fields."""
        assert data.get("name") == "autodev"
        assert data.get("initial") == "init"
        assert isinstance(data.get("states"), dict)

    def test_required_states_exist(self, data: dict) -> None:
        """Interleaved state machine must have these states; the old refine-all-then-implement-all
        intermediary states (refine_issue, seed_impl_queue, implement_next, implement_issue) must be gone."""
        required = {
            "init",
            "dequeue_next",
            "refine_current",
            "check_decision_after_refine",
            "check_passed",
            "detect_children",
            "enqueue_children",
            "size_review_snap",
            "check_broke_down",
            "recheck_scores",
            "check_decision_before_size_review",
            "triage_outcome_failure",
            "check_missing_artifacts",
            "run_size_review",
            "enqueue_or_skip",
            "recheck_after_size_review",
            "decide_current",
            "run_decide",
            "mark_decide_ran",
            "rerun_confidence_after_decide",
            "snap_and_size_review",
            "run_wire",
            "run_refine",
            "rerun_confidence_after_wire",
            "implement_current",
            "done",
        }
        actual = set(data["states"].keys())
        missing = required - actual
        assert not missing, f"Missing states: {missing}"

    def test_old_states_removed(self, data: dict) -> None:
        """Old two-phase states must be removed in favor of the interleaved design."""
        states = set(data["states"].keys())
        forbidden = {"refine_issue", "seed_impl_queue", "implement_next", "implement_issue"}
        present = states & forbidden
        assert not present, f"Deprecated states still present: {present}"

    def test_done_state_is_terminal(self, data: dict) -> None:
        """done state must have terminal: true."""
        done_state = data["states"].get("done", {})
        assert done_state.get("terminal") is True

    def test_init_references_autodev_queue(self, data: dict) -> None:
        """init must initialize .loops/tmp/autodev-queue.txt as the unified queue."""
        init = data["states"].get("init", {})
        action = init.get("action", "")
        assert "autodev-queue.txt" in action
        assert ".loops/tmp/" in action

    def test_init_does_not_reference_impl_queue(self, data: dict) -> None:
        """init must NOT reference the now-removed autodev-impl-queue.txt."""
        init = data["states"].get("init", {})
        action = init.get("action", "")
        assert "autodev-impl-queue.txt" not in action, (
            "autodev-impl-queue.txt is removed in the interleaved design"
        )

    def test_no_state_references_impl_queue(self, data: dict) -> None:
        """No state anywhere should reference the deleted autodev-impl-queue.txt."""
        for name, state in data["states"].items():
            action = state.get("action", "")
            assert "autodev-impl-queue.txt" not in action, (
                f"State {name!r} still references deleted autodev-impl-queue.txt"
            )

    def test_no_state_references_recursive_refine_passed(self, data: dict) -> None:
        """autodev must write its own passed file, not read from recursive-refine's."""
        for name, state in data["states"].items():
            action = state.get("action", "")
            assert "recursive-refine-passed.txt" not in action, (
                f"State {name!r} must not read recursive-refine-passed.txt; "
                f"autodev manages its own passed list now"
            )

    def test_dequeue_next_captures_input(self, data: dict) -> None:
        """dequeue_next must capture as 'input' for context_passthrough to the sub-loop."""
        state = data["states"].get("dequeue_next", {})
        assert state.get("capture") == "input"

    def test_dequeue_next_routes_to_refine_current(self, data: dict) -> None:
        """dequeue_next must route to refine_current on success."""
        state = data["states"].get("dequeue_next", {})
        assert state.get("on_yes") == "refine_current"

    def test_refine_current_delegates_to_refine_to_ready_issue(self, data: dict) -> None:
        """refine_current must delegate to refine-to-ready-issue (NOT recursive-refine)."""
        state = data["states"].get("refine_current", {})
        assert state.get("loop") == "refine-to-ready-issue"
        assert state.get("context_passthrough") is True

    def test_refine_current_has_success_and_failure_routes(self, data: dict) -> None:
        """refine_current must define on_success and on_failure routes, and they must differ
        (ENH-1679: failure should not silently reuse the success path)."""
        state = data["states"].get("refine_current", {})
        assert "on_success" in state
        assert "on_failure" in state
        assert state["on_success"] != state["on_failure"], (
            "refine_current.on_success and on_failure must differ — "
            "routing both to the same state launders the sub-loop verdict (ENH-1679)"
        )

    def test_refine_current_failure_routes_to_skip_inflight(self, data: dict) -> None:
        """refine_current.on_failure must route to skip_inflight, not copy_broke_down (ENH-1679).
        A sub-loop that exits via its failed terminal (e.g. diagnose → failed) should skip
        the issue, not proceed to implement_current as if refinement succeeded."""
        state = data["states"].get("refine_current", {})
        assert state.get("on_failure") == "skip_inflight", (
            f"refine_current.on_failure should be 'skip_inflight', got {state.get('on_failure')!r}"
        )

    def test_refine_current_error_routes_to_skip_inflight(self, data: dict) -> None:
        """refine_current.on_error must route to skip_inflight (ENH-1679).
        A signal or executor crash during refinement should skip the issue."""
        state = data["states"].get("refine_current", {})
        assert state.get("on_error") == "skip_inflight", (
            f"refine_current.on_error should be 'skip_inflight', got {state.get('on_error')!r}"
        )

    def test_refine_current_on_no_routes_to_dequeue_next(self, data: dict) -> None:
        """refine_current.on_no (sub-loop queue empty / never started) must route to dequeue_next."""
        state = data["states"].get("refine_current", {})
        assert state.get("on_no") == "dequeue_next", (
            f"refine_current.on_no should be 'dequeue_next', got {state.get('on_no')!r}"
        )

    def test_skip_inflight_state_exists(self, data: dict) -> None:
        """skip_inflight state must be declared in autodev (ENH-1679)."""
        assert "skip_inflight" in data["states"], (
            "skip_inflight state not found — add it as the on_failure/on_error target "
            "for refine_current (ENH-1679)"
        )

    def test_skip_inflight_is_shell_action(self, data: dict) -> None:
        """skip_inflight must use action_type: shell (ENH-1679)."""
        state = data["states"].get("skip_inflight", {})
        assert state.get("action_type") == "shell", (
            f"skip_inflight.action_type should be 'shell', got {state.get('action_type')!r}"
        )

    def test_skip_inflight_writes_skipped_file(self, data: dict) -> None:
        """skip_inflight must append to autodev-skipped.txt (ENH-1679)."""
        state = data["states"].get("skip_inflight", {})
        action = state.get("action", "")
        assert "autodev-skipped.txt" in action, (
            "skip_inflight must record the skipped issue ID in autodev-skipped.txt"
        )

    def test_skip_inflight_clears_autodev_inflight(self, data: dict) -> None:
        """skip_inflight must clear autodev-inflight so done does not surface a stale warning (ENH-1679)."""
        state = data["states"].get("skip_inflight", {})
        action = state.get("action", "")
        assert "autodev-inflight" in action, (
            "skip_inflight must clear autodev-inflight so BUG-1226 done-state "
            "warning is not triggered for a cleanly-skipped issue"
        )

    def test_skip_inflight_routes_to_dequeue_next(self, data: dict) -> None:
        """skip_inflight must route to dequeue_next on success and on_error (ENH-1679)."""
        state = data["states"].get("skip_inflight", {})
        assert state.get("next") == "dequeue_next", (
            f"skip_inflight.next should be 'dequeue_next', got {state.get('next')!r}"
        )
        assert state.get("on_error") == "dequeue_next", (
            f"skip_inflight.on_error should be 'dequeue_next', got {state.get('on_error')!r}"
        )

    def test_implement_current_uses_shell_exit_fragment(self, data: dict) -> None:
        """implement_current must use shell_exit fragment for exit-code-aware routing."""
        state = data["states"].get("implement_current", {})
        assert state.get("fragment") == "shell_exit"

    def test_implement_current_runs_ll_auto_only(self, data: dict) -> None:
        """implement_current must invoke ll-auto --only against the captured input."""
        state = data["states"].get("implement_current", {})
        action = state.get("action", "")
        assert "ll-auto --only" in action
        assert "${captured.input.output}" in action

    def test_implement_current_routes_back_to_dequeue_next(self, data: dict) -> None:
        """After implementing (exit 0), return to dequeue_next for the next queued issue."""
        state = data["states"].get("implement_current", {})
        assert state.get("on_yes") == "dequeue_next"

    def test_implement_current_on_no_routes_to_dequeue_next(self, data: dict) -> None:
        """On gate-blocked exit (exit 1), still advance to dequeue_next."""
        state = data["states"].get("implement_current", {})
        assert state.get("on_no") == "dequeue_next"

    def test_implement_current_on_error_routes_to_done(self, data: dict) -> None:
        """On fatal error, terminate the loop via done."""
        state = data["states"].get("implement_current", {})
        assert state.get("on_error") == "done"

    def test_copy_broke_down_routes_to_check_decision_after_refine(self, data: dict) -> None:
        """copy_broke_down must route to check_decision_after_refine so decision_needed is
        checked immediately after confidence-check (via sub-loop) completes."""
        state = data["states"].get("copy_broke_down", {})
        assert state.get("next") == "check_decision_after_refine", (
            f"copy_broke_down.next should be 'check_decision_after_refine', got {state.get('next')!r}"
        )

    def test_check_decision_after_refine_routes_correctly(self, data: dict) -> None:
        """check_decision_after_refine must route to run_decide (on_yes) and check_passed (on_no/on_error)."""
        state = data["states"].get("check_decision_after_refine", {})
        assert state.get("on_yes") == "run_decide", (
            f"check_decision_after_refine.on_yes should be 'run_decide', got {state.get('on_yes')!r}"
        )
        assert state.get("on_no") == "check_passed", (
            f"check_decision_after_refine.on_no should be 'check_passed', got {state.get('on_no')!r}"
        )
        assert state.get("on_error") == "check_passed", (
            f"check_decision_after_refine.on_error should be 'check_passed', got {state.get('on_error')!r}"
        )

    def test_check_passed_on_yes_routes_to_implement_current(self, data: dict) -> None:
        """On threshold pass, proceed directly to implementation (decision_needed already handled
        by check_decision_after_refine before scores are evaluated)."""
        state = data["states"].get("check_passed", {})
        assert state.get("on_yes") == "implement_current"

    def test_check_passed_on_no_routes_to_triage_outcome_failure(self, data: dict) -> None:
        """On threshold fail, triage outcome before routing to size-review or decide."""
        state = data["states"].get("check_passed", {})
        assert state.get("on_no") == "triage_outcome_failure"

    def test_enqueue_children_prepends_to_autodev_queue(self, data: dict) -> None:
        """enqueue_children must rewrite .loops/tmp/autodev-queue.txt, not recursive-refine-queue.txt."""
        state = data["states"].get("enqueue_children", {})
        action = state.get("action", "")
        assert "autodev-queue.txt" in action
        assert "recursive-refine-queue.txt" not in action

    def test_enqueue_children_filters_by_parent_reference(self, data: dict) -> None:
        """enqueue_children must filter candidates by 'Decomposed from' parent reference
        (same discipline as recursive-refine's detect_children/enqueue_children)."""
        # Detect_children does the filter; enqueue_children consumes the filtered file.
        detect_action = data["states"].get("detect_children", {}).get("action", "")
        assert "Decomposed from" in detect_action

    def test_broke_down_flag_copied_to_autodev_namespace(self, data: dict) -> None:
        """autodev must copy .loops/tmp/recursive-refine-broke-down to .loops/tmp/autodev-broke-down
        after the sub-loop returns, and read the copy for its own routing."""
        # Some state must cp the source file to autodev-broke-down.
        copied = any(
            "autodev-broke-down" in s.get("action", "")
            and "recursive-refine-broke-down" in s.get("action", "")
            for s in data["states"].values()
        )
        assert copied, (
            "No state copies recursive-refine-broke-down to autodev-broke-down; "
            "cross-loop handshake must be namespaced into autodev-*"
        )

    def test_check_broke_down_reads_autodev_namespaced_flag(self, data: dict) -> None:
        """check_broke_down must read the autodev-namespaced copy, not the source file."""
        state = data["states"].get("check_broke_down", {})
        action = state.get("action", "")
        assert "autodev-broke-down" in action
        # BUG-1183: the shortcut must also depend on a non-empty children file,
        # not the flag alone.
        assert "autodev-new-children.txt" in action

    def test_check_broke_down_evaluate_output_numeric_lt_1(self, data: dict) -> None:
        """check_broke_down must use output_numeric lt 1 to gate the shortcut."""
        state = data["states"].get("check_broke_down", {})
        evaluate = state.get("evaluate", {})
        assert evaluate.get("type") == "output_numeric", (
            f"check_broke_down evaluate.type should be 'output_numeric', got {evaluate.get('type')!r}"
        )
        assert evaluate.get("operator") == "lt", (
            f"check_broke_down evaluate.operator should be 'lt', got {evaluate.get('operator')!r}"
        )
        assert evaluate.get("target") == 1, (
            f"check_broke_down evaluate.target should be 1, got {evaluate.get('target')!r}"
        )

    def test_check_broke_down_on_yes_routes_to_recheck_scores(self, data: dict) -> None:
        """check_broke_down.on_yes (flag=0 OR no children) must route to recheck_scores."""
        state = data["states"].get("check_broke_down", {})
        assert state.get("on_yes") == "recheck_scores", (
            f"check_broke_down.on_yes should be 'recheck_scores', got {state.get('on_yes')!r}"
        )

    def test_check_broke_down_on_no_routes_to_enqueue_or_skip(self, data: dict) -> None:
        """check_broke_down.on_no (flag=1 AND children exist) must route to enqueue_or_skip."""
        state = data["states"].get("check_broke_down", {})
        assert state.get("on_no") == "enqueue_or_skip", (
            f"check_broke_down.on_no should be 'enqueue_or_skip', got {state.get('on_no')!r}"
        )

    def test_check_broke_down_on_error_routes_to_recheck_scores(self, data: dict) -> None:
        """check_broke_down.on_error must route to recheck_scores (fail-safe)."""
        state = data["states"].get("check_broke_down", {})
        assert state.get("on_error") == "recheck_scores", (
            f"check_broke_down.on_error should be 'recheck_scores', got {state.get('on_error')!r}"
        )

    def test_tmp_files_use_autodev_namespace(self, data: dict) -> None:
        """All new bookkeeping temp files must use the autodev-* namespace, not recursive-refine-*."""
        for name, state in data["states"].items():
            action = state.get("action", "")
            # These recursive-refine-scoped files must not be read or written from autodev
            # (except recursive-refine-broke-down, which is the shared handshake source — copied to autodev-*).
            assert "recursive-refine-passed.txt" not in action, (
                f"State {name!r} reads recursive-refine-passed.txt"
            )
            assert "recursive-refine-skipped.txt" not in action, (
                f"State {name!r} reads recursive-refine-skipped.txt"
            )
            assert "recursive-refine-queue.txt" not in action, (
                f"State {name!r} rewrites recursive-refine-queue.txt"
            )
            assert "recursive-refine-pre-ids.txt" not in action, (
                f"State {name!r} uses recursive-refine-pre-ids.txt; namespace as autodev-*"
            )
            assert "recursive-refine-post-ids.txt" not in action, (
                f"State {name!r} uses recursive-refine-post-ids.txt; namespace as autodev-*"
            )

    def test_context_passthrough_on_refine_current(self, data: dict) -> None:
        """refine_current must use context_passthrough so the captured input reaches the sub-loop."""
        state = data["states"].get("refine_current", {})
        assert state.get("context_passthrough") is True

    # BUG-1226: autodev-inflight handshake covers timeouts outside the
    # executor flush race window (Part 1). dequeue_next records the in-flight
    # issue ID; enqueue_or_skip and enqueue_children clear it on resolution;
    # init resets it at loop start; done surfaces it when non-empty so the
    # user knows which issue to re-queue.

    def test_init_resets_autodev_inflight(self, data: dict) -> None:
        """init must reset .loops/tmp/autodev-inflight alongside autodev-broke-down."""
        init = data["states"].get("init", {})
        action = init.get("action", "")
        assert "autodev-inflight" in action, (
            "init must reset autodev-inflight to clear stale handshake state "
            "from previous runs (BUG-1226)"
        )

    def test_dequeue_next_writes_autodev_inflight(self, data: dict) -> None:
        """dequeue_next must record the popped issue ID in autodev-inflight."""
        state = data["states"].get("dequeue_next", {})
        action = state.get("action", "")
        assert "autodev-inflight" in action, (
            "dequeue_next must write the dequeued issue ID to autodev-inflight "
            "so the loop can surface mid-flight issues on timeout (BUG-1226)"
        )

    def test_enqueue_or_skip_uses_shell_exit_fragment(self, data: dict) -> None:
        """enqueue_or_skip must use shell_exit fragment for conditional routing (BUG-1230)."""
        state = data["states"].get("enqueue_or_skip", {})
        assert state.get("fragment") == "shell_exit", (
            f"enqueue_or_skip.fragment should be 'shell_exit', got {state.get('fragment')!r}"
        )

    def test_enqueue_or_skip_on_yes_routes_to_dequeue_next(self, data: dict) -> None:
        """enqueue_or_skip.on_yes (children found) must route to dequeue_next."""
        state = data["states"].get("enqueue_or_skip", {})
        assert state.get("on_yes") == "dequeue_next", (
            f"enqueue_or_skip.on_yes should be 'dequeue_next', got {state.get('on_yes')!r}"
        )

    def test_enqueue_or_skip_on_no_routes_to_recheck_after_size_review(self, data: dict) -> None:
        """enqueue_or_skip.on_no (no children) must route to recheck_after_size_review (BUG-1230)."""
        state = data["states"].get("enqueue_or_skip", {})
        assert state.get("on_no") == "recheck_after_size_review", (
            f"enqueue_or_skip.on_no should be 'recheck_after_size_review', got {state.get('on_no')!r}"
        )

    def test_enqueue_or_skip_clears_autodev_inflight(self, data: dict) -> None:
        """enqueue_or_skip must clear autodev-inflight in the children-found branch (BUG-1226/1230).
        The skip-path inflight clear moved to recheck_after_size_review (BUG-1230)."""
        state = data["states"].get("enqueue_or_skip", {})
        action = state.get("action", "")
        assert "autodev-inflight" in action, (
            "enqueue_or_skip must clear autodev-inflight in the children-found branch (BUG-1226); "
            "the skip-path clear is handled by recheck_after_size_review (BUG-1230)"
        )

    def test_enqueue_children_clears_autodev_inflight(self, data: dict) -> None:
        """enqueue_children must clear autodev-inflight after decomposition."""
        state = data["states"].get("enqueue_children", {})
        action = state.get("action", "")
        assert "autodev-inflight" in action, (
            "enqueue_children resolves the current issue by decomposition and "
            "must clear autodev-inflight (BUG-1226)"
        )

    def test_done_surfaces_autodev_inflight_warning(self, data: dict) -> None:
        """done must read autodev-inflight and emit a warning when non-empty."""
        state = data["states"].get("done", {})
        action = state.get("action", "")
        assert "autodev-inflight" in action, (
            "done must read autodev-inflight so the user knows which issue "
            "was in-flight at loop termination (BUG-1226)"
        )

    # BUG-1230: recheck_after_size_review — score check after size-review
    # declines to decompose. Routes to implement_current on pass so leaf-sized
    # ready issues are not silently skipped.

    def test_recheck_after_size_review_uses_shell_exit_fragment(self, data: dict) -> None:
        """recheck_after_size_review must use shell_exit fragment."""
        state = data["states"].get("recheck_after_size_review", {})
        assert state.get("fragment") == "shell_exit", (
            f"recheck_after_size_review.fragment should be 'shell_exit', "
            f"got {state.get('fragment')!r}"
        )

    def test_recheck_after_size_review_on_yes_routes_to_decide_current(self, data: dict) -> None:
        """recheck_after_size_review.on_yes (scores pass) must route to decide_current."""
        state = data["states"].get("recheck_after_size_review", {})
        assert state.get("on_yes") == "decide_current", (
            f"recheck_after_size_review.on_yes should be 'decide_current', "
            f"got {state.get('on_yes')!r}"
        )

    def test_recheck_after_size_review_on_no_routes_to_dequeue_next(self, data: dict) -> None:
        """recheck_after_size_review.on_no (scores fail) must route to dequeue_next."""
        state = data["states"].get("recheck_after_size_review", {})
        assert state.get("on_no") == "dequeue_next", (
            f"recheck_after_size_review.on_no should be 'dequeue_next', got {state.get('on_no')!r}"
        )

    def test_recheck_after_size_review_clears_autodev_inflight(self, data: dict) -> None:
        """recheck_after_size_review must clear autodev-inflight on the skip path."""
        state = data["states"].get("recheck_after_size_review", {})
        action = state.get("action", "")
        assert "autodev-inflight" in action, (
            "recheck_after_size_review must clear autodev-inflight when scores fail "
            "so done does not warn about a stale in-flight entry (BUG-1230)"
        )

    def test_recheck_scores_on_yes_routes_to_decide_current(self, data: dict) -> None:
        """recheck_scores.on_yes (scores pass) must route to decide_current."""
        state = data["states"].get("recheck_scores", {})
        assert state.get("on_yes") == "decide_current", (
            f"recheck_scores.on_yes should be 'decide_current', got {state.get('on_yes')!r}"
        )

    def test_recheck_scores_on_no_routes_to_check_decision_before_size_review(
        self, data: dict
    ) -> None:
        """recheck_scores.on_no (scores fail) must route to check_decision_before_size_review."""
        state = data["states"].get("recheck_scores", {})
        assert state.get("on_no") == "check_decision_before_size_review", (
            f"recheck_scores.on_no should be 'check_decision_before_size_review', got {state.get('on_no')!r}"
        )

    def test_check_decision_before_size_review_uses_shell_exit_fragment(self, data: dict) -> None:
        """check_decision_before_size_review must use shell_exit fragment to route on exit code."""
        state = data["states"].get("check_decision_before_size_review", {})
        assert state.get("fragment") == "shell_exit", (
            f"check_decision_before_size_review.fragment should be 'shell_exit', got {state.get('fragment')!r}"
        )

    def test_check_decision_before_size_review_on_yes_routes_to_run_decide(
        self, data: dict
    ) -> None:
        """check_decision_before_size_review.on_yes (decision_needed=true) must route to run_decide."""
        state = data["states"].get("check_decision_before_size_review", {})
        assert state.get("on_yes") == "run_decide", (
            f"check_decision_before_size_review.on_yes should be 'run_decide', got {state.get('on_yes')!r}"
        )

    def test_check_decision_before_size_review_on_no_routes_to_run_size_review(
        self, data: dict
    ) -> None:
        """check_decision_before_size_review.on_no (no decision needed) must route to run_size_review."""
        state = data["states"].get("check_decision_before_size_review", {})
        assert state.get("on_no") == "run_size_review", (
            f"check_decision_before_size_review.on_no should be 'run_size_review', got {state.get('on_no')!r}"
        )

    def test_triage_outcome_failure_uses_shell_exit_fragment(self, data: dict) -> None:
        """triage_outcome_failure must use shell_exit fragment to route on exit code."""
        state = data["states"].get("triage_outcome_failure", {})
        assert state.get("fragment") == "shell_exit", (
            f"triage_outcome_failure.fragment should be 'shell_exit', got {state.get('fragment')!r}"
        )

    def test_triage_outcome_failure_on_yes_routes_to_run_decide(self, data: dict) -> None:
        """triage_outcome_failure.on_yes (low ambiguity score) must route to run_decide."""
        state = data["states"].get("triage_outcome_failure", {})
        assert state.get("on_yes") == "run_decide", (
            f"triage_outcome_failure.on_yes should be 'run_decide', got {state.get('on_yes')!r}"
        )

    def test_triage_outcome_failure_on_no_routes_to_check_missing_artifacts(
        self, data: dict
    ) -> None:
        """triage_outcome_failure.on_no (not a decision) must route to check_missing_artifacts gate."""
        state = data["states"].get("triage_outcome_failure", {})
        assert state.get("on_no") == "check_missing_artifacts", (
            f"triage_outcome_failure.on_no should be 'check_missing_artifacts', got {state.get('on_no')!r}"
        )

    def test_triage_outcome_failure_on_error_routes_to_detect_children(self, data: dict) -> None:
        """triage_outcome_failure.on_error must fall back safely to detect_children."""
        state = data["states"].get("triage_outcome_failure", {})
        assert state.get("on_error") == "detect_children", (
            f"triage_outcome_failure.on_error should be 'detect_children', got {state.get('on_error')!r}"
        )

    def test_triage_outcome_failure_action_checks_decision_needed(self, data: dict) -> None:
        """triage_outcome_failure action must read decision_needed flag, not only score_ambiguity."""
        state = data["states"].get("triage_outcome_failure", {})
        action = state.get("action", "")
        assert "decision_needed" in action, (
            "triage_outcome_failure action must check 'decision_needed' flag as authoritative routing signal"
        )

    def test_check_missing_artifacts_uses_shell_exit_fragment(self, data: dict) -> None:
        """check_missing_artifacts must use shell_exit fragment to route on exit code."""
        state = data["states"].get("check_missing_artifacts", {})
        assert state.get("fragment") == "shell_exit", (
            f"check_missing_artifacts.fragment should be 'shell_exit', got {state.get('fragment')!r}"
        )

    def test_check_missing_artifacts_on_yes_routes_to_run_wire(self, data: dict) -> None:
        """check_missing_artifacts.on_yes (missing_artifacts=true) must route to run_wire."""
        state = data["states"].get("check_missing_artifacts", {})
        assert state.get("on_yes") == "run_wire", (
            f"check_missing_artifacts.on_yes should be 'run_wire', got {state.get('on_yes')!r}"
        )

    def test_check_missing_artifacts_on_no_routes_to_detect_children(self, data: dict) -> None:
        """check_missing_artifacts.on_no (no missing artifacts) must route to detect_children."""
        state = data["states"].get("check_missing_artifacts", {})
        assert state.get("on_no") == "detect_children", (
            f"check_missing_artifacts.on_no should be 'detect_children', got {state.get('on_no')!r}"
        )

    def test_run_wire_uses_with_rate_limit_handling_fragment(self, data: dict) -> None:
        """run_wire must use with_rate_limit_handling fragment (mirrors run_decide)."""
        state = data["states"].get("run_wire", {})
        assert state.get("fragment") == "with_rate_limit_handling", (
            f"run_wire.fragment should be 'with_rate_limit_handling', got {state.get('fragment')!r}"
        )

    def test_run_wire_action_type_is_slash_command(self, data: dict) -> None:
        """run_wire must use slash_command action_type."""
        state = data["states"].get("run_wire", {})
        assert state.get("action_type") == "slash_command", (
            f"run_wire.action_type should be 'slash_command', got {state.get('action_type')!r}"
        )

    def test_run_refine_uses_with_rate_limit_handling_fragment(self, data: dict) -> None:
        """run_refine must use with_rate_limit_handling fragment (mirrors run_decide)."""
        state = data["states"].get("run_refine", {})
        assert state.get("fragment") == "with_rate_limit_handling", (
            f"run_refine.fragment should be 'with_rate_limit_handling', got {state.get('fragment')!r}"
        )

    def test_run_refine_action_type_is_slash_command(self, data: dict) -> None:
        """run_refine must use slash_command action_type."""
        state = data["states"].get("run_refine", {})
        assert state.get("action_type") == "slash_command", (
            f"run_refine.action_type should be 'slash_command', got {state.get('action_type')!r}"
        )

    def test_decide_current_uses_shell_exit_fragment(self, data: dict) -> None:
        """decide_current must use shell_exit fragment to route on exit code."""
        state = data["states"].get("decide_current", {})
        assert state.get("fragment") == "shell_exit", (
            f"decide_current.fragment should be 'shell_exit', got {state.get('fragment')!r}"
        )

    def test_decide_current_on_yes_routes_to_run_decide(self, data: dict) -> None:
        """decide_current.on_yes (decision_needed=true) must route to run_decide."""
        state = data["states"].get("decide_current", {})
        assert state.get("on_yes") == "run_decide", (
            f"decide_current.on_yes should be 'run_decide', got {state.get('on_yes')!r}"
        )

    def test_decide_current_on_no_routes_to_implement_current(self, data: dict) -> None:
        """decide_current.on_no (no decision needed) must route to implement_current."""
        state = data["states"].get("decide_current", {})
        assert state.get("on_no") == "implement_current", (
            f"decide_current.on_no should be 'implement_current', got {state.get('on_no')!r}"
        )

    def test_run_decide_uses_with_rate_limit_handling_fragment(self, data: dict) -> None:
        """run_decide must use with_rate_limit_handling fragment."""
        state = data["states"].get("run_decide", {})
        assert state.get("fragment") == "with_rate_limit_handling"

    def test_run_decide_next_routes_to_mark_decide_ran(self, data: dict) -> None:
        """ENH-1415: run_decide.next must route to mark_decide_ran so the decide-ran flag is
        set before the refreshed-score gate; mark_decide_ran in turn routes to
        rerun_confidence_after_decide."""
        state = data["states"].get("run_decide", {})
        assert state.get("next") == "mark_decide_ran"

    def test_run_decide_on_error_routes_to_implement_current(self, data: dict) -> None:
        """run_decide.on_error must fall through to recheck_after_decide (degraded mode)."""
        state = data["states"].get("run_decide", {})
        assert state.get("on_error") == "recheck_after_decide"

    def test_run_decide_on_rate_limit_exhausted_routes_to_done(self, data: dict) -> None:
        """run_decide.on_rate_limit_exhausted must terminate the loop."""
        state = data["states"].get("run_decide", {})
        assert state.get("on_rate_limit_exhausted") == "done"

    def test_rerun_confidence_after_decide_state_exists(self, data: dict) -> None:
        """rerun_confidence_after_decide must be present in the state machine."""
        assert "rerun_confidence_after_decide" in data["states"], (
            "rerun_confidence_after_decide state missing — BUG-1378 fix not applied"
        )

    def test_rerun_confidence_after_decide_uses_with_rate_limit_handling_fragment(
        self, data: dict
    ) -> None:
        """rerun_confidence_after_decide must use with_rate_limit_handling fragment."""
        state = data["states"].get("rerun_confidence_after_decide", {})
        assert state.get("fragment") == "with_rate_limit_handling", (
            f"rerun_confidence_after_decide.fragment should be 'with_rate_limit_handling', got {state.get('fragment')!r}"
        )

    def test_rerun_confidence_after_decide_action_type_is_slash_command(self, data: dict) -> None:
        """rerun_confidence_after_decide must use slash_command action_type."""
        state = data["states"].get("rerun_confidence_after_decide", {})
        assert state.get("action_type") == "slash_command", (
            f"rerun_confidence_after_decide.action_type should be 'slash_command', got {state.get('action_type')!r}"
        )

    def test_rerun_confidence_after_decide_action_contains_confidence_check(
        self, data: dict
    ) -> None:
        """rerun_confidence_after_decide action must invoke /ll:confidence-check."""
        state = data["states"].get("rerun_confidence_after_decide", {})
        action = state.get("action", "")
        assert "/ll:confidence-check" in action, (
            f"rerun_confidence_after_decide.action should contain '/ll:confidence-check', got {action!r}"
        )

    def test_rerun_confidence_after_decide_next_routes_to_recheck_after_decide(
        self, data: dict
    ) -> None:
        """rerun_confidence_after_decide.next must route to recheck_after_decide."""
        state = data["states"].get("rerun_confidence_after_decide", {})
        assert state.get("next") == "recheck_after_decide", (
            f"rerun_confidence_after_decide.next should be 'recheck_after_decide', got {state.get('next')!r}"
        )

    def test_rerun_confidence_after_decide_on_error_routes_to_recheck_after_decide(
        self, data: dict
    ) -> None:
        """rerun_confidence_after_decide.on_error must fall back to recheck_after_decide."""
        state = data["states"].get("rerun_confidence_after_decide", {})
        assert state.get("on_error") == "recheck_after_decide", (
            f"rerun_confidence_after_decide.on_error should be 'recheck_after_decide', got {state.get('on_error')!r}"
        )

    def test_rerun_confidence_after_decide_on_rate_limit_exhausted_routes_to_done(
        self, data: dict
    ) -> None:
        """rerun_confidence_after_decide.on_rate_limit_exhausted must terminate the loop."""
        state = data["states"].get("rerun_confidence_after_decide", {})
        assert state.get("on_rate_limit_exhausted") == "done", (
            f"rerun_confidence_after_decide.on_rate_limit_exhausted should be 'done', got {state.get('on_rate_limit_exhausted')!r}"
        )

    # ENH-1415: route post-decide outcome failures to size-review instead of dropping the issue.

    def test_mark_decide_ran_state_exists(self, data: dict) -> None:
        """ENH-1415: mark_decide_ran must be present so decide_current can short-circuit
        on re-entry from recheck_after_size_review."""
        assert "mark_decide_ran" in data["states"], (
            "mark_decide_ran state missing — ENH-1415 fix not applied"
        )

    def test_mark_decide_ran_next_routes_to_rerun_confidence_after_decide(self, data: dict) -> None:
        """ENH-1415: mark_decide_ran.next must route to rerun_confidence_after_decide so the
        post-decide score refresh still runs."""
        state = data["states"].get("mark_decide_ran", {})
        assert state.get("next") == "rerun_confidence_after_decide"
        assert state.get("on_error") == "rerun_confidence_after_decide"

    def test_mark_decide_ran_writes_decide_ran_flag(self, data: dict) -> None:
        """ENH-1415: mark_decide_ran.action must write the .loops/tmp/autodev-decide-ran flag."""
        state = data["states"].get("mark_decide_ran", {})
        action = state.get("action", "")
        assert "autodev-decide-ran" in action, (
            f"mark_decide_ran.action must write autodev-decide-ran, got {action!r}"
        )

    def test_snap_and_size_review_state_exists(self, data: dict) -> None:
        """ENH-1415: snap_and_size_review must be present so recheck_after_decide can
        route outcome failures to decomposition rather than dropping them."""
        assert "snap_and_size_review" in data["states"], (
            "snap_and_size_review state missing — ENH-1415 fix not applied"
        )

    def test_snap_and_size_review_next_routes_to_run_size_review(self, data: dict) -> None:
        """ENH-1415: snap_and_size_review must hand off to run_size_review."""
        state = data["states"].get("snap_and_size_review", {})
        assert state.get("next") == "run_size_review"
        assert state.get("on_error") == "run_size_review"

    def test_snap_and_size_review_refreshes_pre_ids(self, data: dict) -> None:
        """ENH-1415: snap_and_size_review must snapshot current IDs into autodev-pre-ids.txt
        so enqueue_or_skip's diff captures only this size-review's children."""
        state = data["states"].get("snap_and_size_review", {})
        action = state.get("action", "")
        assert "autodev-pre-ids.txt" in action, (
            f"snap_and_size_review.action must write autodev-pre-ids.txt, got {action!r}"
        )

    def test_recheck_after_decide_on_no_routes_to_snap_and_size_review(self, data: dict) -> None:
        """ENH-1415: when outcome still fails after decide, route to snap_and_size_review so
        the issue gets a decomposition attempt rather than being silently dropped."""
        state = data["states"].get("recheck_after_decide", {})
        assert state.get("on_no") == "snap_and_size_review", (
            f"recheck_after_decide.on_no should be 'snap_and_size_review' "
            f"(was 'dequeue_next' pre-ENH-1415), got {state.get('on_no')!r}"
        )
        assert state.get("on_error") == "snap_and_size_review", (
            f"recheck_after_decide.on_error should also fall through to snap_and_size_review, "
            f"got {state.get('on_error')!r}"
        )

    def test_decide_current_checks_decide_ran_flag(self, data: dict) -> None:
        """ENH-1415: decide_current must check the autodev-decide-ran flag so it short-circuits
        to implement_current when re-entered from recheck_after_size_review."""
        state = data["states"].get("decide_current", {})
        action = state.get("action", "")
        assert "autodev-decide-ran" in action, (
            f"decide_current.action must check autodev-decide-ran, got {action!r}"
        )

    def test_dequeue_next_clears_autodev_decide_ran(self, data: dict) -> None:
        """ENH-1415: dequeue_next must clear the per-iteration autodev-decide-ran flag so
        the next issue starts without a stale decide-ran marker."""
        state = data["states"].get("dequeue_next", {})
        action = state.get("action", "")
        assert "autodev-decide-ran" in action, (
            f"dequeue_next.action must clear autodev-decide-ran, got {action!r}"
        )

    # BUG-1491: rerun confidence after wire+refine repair path

    def test_run_refine_next_routes_to_rerun_confidence_after_wire(self, data: dict) -> None:
        """BUG-1491: run_refine.next must route to rerun_confidence_after_wire, not enqueue_or_skip."""
        state = data["states"].get("run_refine", {})
        assert state.get("next") == "rerun_confidence_after_wire", (
            f"run_refine.next should be 'rerun_confidence_after_wire', got {state.get('next')!r}"
        )

    def test_run_refine_on_error_routes_to_rerun_confidence_after_wire(self, data: dict) -> None:
        """BUG-1491: run_refine.on_error must route to rerun_confidence_after_wire."""
        state = data["states"].get("run_refine", {})
        assert state.get("on_error") == "rerun_confidence_after_wire", (
            f"run_refine.on_error should be 'rerun_confidence_after_wire', got {state.get('on_error')!r}"
        )

    def test_rerun_confidence_after_wire_state_exists(self, data: dict) -> None:
        """BUG-1491: rerun_confidence_after_wire must be present in the state machine."""
        assert "rerun_confidence_after_wire" in data["states"], (
            "rerun_confidence_after_wire state missing — BUG-1491 fix not applied"
        )

    def test_rerun_confidence_after_wire_uses_with_rate_limit_handling_fragment(
        self, data: dict
    ) -> None:
        """rerun_confidence_after_wire must use with_rate_limit_handling fragment."""
        state = data["states"].get("rerun_confidence_after_wire", {})
        assert state.get("fragment") == "with_rate_limit_handling", (
            f"rerun_confidence_after_wire.fragment should be 'with_rate_limit_handling', got {state.get('fragment')!r}"
        )

    def test_rerun_confidence_after_wire_action_type_is_slash_command(self, data: dict) -> None:
        """rerun_confidence_after_wire must use slash_command action_type."""
        state = data["states"].get("rerun_confidence_after_wire", {})
        assert state.get("action_type") == "slash_command", (
            f"rerun_confidence_after_wire.action_type should be 'slash_command', got {state.get('action_type')!r}"
        )

    def test_rerun_confidence_after_wire_action_contains_confidence_check(self, data: dict) -> None:
        """rerun_confidence_after_wire action must invoke /ll:confidence-check."""
        state = data["states"].get("rerun_confidence_after_wire", {})
        action = state.get("action", "")
        assert "/ll:confidence-check" in action, (
            f"rerun_confidence_after_wire.action should contain '/ll:confidence-check', got {action!r}"
        )

    def test_rerun_confidence_after_wire_next_routes_to_enqueue_or_skip(self, data: dict) -> None:
        """rerun_confidence_after_wire.next must route to enqueue_or_skip."""
        state = data["states"].get("rerun_confidence_after_wire", {})
        assert state.get("next") == "enqueue_or_skip", (
            f"rerun_confidence_after_wire.next should be 'enqueue_or_skip', got {state.get('next')!r}"
        )

    def test_rerun_confidence_after_wire_on_error_routes_to_enqueue_or_skip(
        self, data: dict
    ) -> None:
        """rerun_confidence_after_wire.on_error must fall back to enqueue_or_skip."""
        state = data["states"].get("rerun_confidence_after_wire", {})
        assert state.get("on_error") == "enqueue_or_skip", (
            f"rerun_confidence_after_wire.on_error should be 'enqueue_or_skip', got {state.get('on_error')!r}"
        )

    def test_rerun_confidence_after_wire_on_rate_limit_exhausted_routes_to_done(
        self, data: dict
    ) -> None:
        """rerun_confidence_after_wire.on_rate_limit_exhausted must terminate the loop."""
        state = data["states"].get("rerun_confidence_after_wire", {})
        assert state.get("on_rate_limit_exhausted") == "done", (
            f"rerun_confidence_after_wire.on_rate_limit_exhausted should be 'done', got {state.get('on_rate_limit_exhausted')!r}"
        )

    def test_skip_inflight_shell_action_writes_skipped_and_clears_inflight(
        self, data: dict, tmp_path: Path
    ) -> None:
        """skip_inflight shell action must append the issue ID to autodev-skipped.txt and
        remove autodev-inflight (ENH-1679).  Modelled on TestAutoRefineAndImplementLoop
        shell-action tests and uses _bash() from test_loops_recursive_refine.py."""
        state = data["states"].get("skip_inflight", {})
        action = state.get("action", "")
        loops_tmp = tmp_path / ".loops" / "tmp"
        loops_tmp.mkdir(parents=True)
        (loops_tmp / "autodev-inflight").write_text("ENH-0001")
        (loops_tmp / "autodev-skipped.txt").write_text("")
        # Substitute the template variable with a concrete value before running
        script = action.replace("${captured.input.output}", "ENH-0001")
        result = subprocess.run(
            ["bash", "-c", script], cwd=tmp_path, capture_output=True, text=True
        )
        assert result.returncode == 0, f"skip_inflight action failed: {result.stderr}"
        skipped = (loops_tmp / "autodev-skipped.txt").read_text()
        assert "ENH-0001" in skipped, "skip_inflight must write the issue ID to autodev-skipped.txt"
        assert not (loops_tmp / "autodev-inflight").exists(), (
            "skip_inflight must remove autodev-inflight so done does not surface a stale warning"
        )


class TestRecursiveRefineLoop:
    """Structural tests for the recursive-refine FSM loop."""

    LOOP_FILE = BUILTIN_LOOPS_DIR / "recursive-refine.yaml"

    @pytest.fixture
    def data(self) -> dict:
        assert self.LOOP_FILE.exists(), f"Loop file not found: {self.LOOP_FILE}"
        return yaml.safe_load(self.LOOP_FILE.read_text())

    def test_required_top_level_fields(self, data: dict) -> None:
        """Loop must have name, initial, and states fields."""
        assert data.get("name") == "recursive-refine"
        assert data.get("initial") == "parse_input"
        assert isinstance(data.get("states"), dict)

    def test_required_states_exist(self, data: dict) -> None:
        """All required states must be present."""
        required = {
            "parse_input",
            "dequeue_next",
            "check_attempt_budget",
            "capture_baseline",
            "run_refine",
            "check_passed",
            "detect_children",
            "enqueue_children",
            "size_review_snap",
            "check_broke_down",
            "recheck_scores",
            "check_depth",
            "run_size_review",
            "enqueue_or_skip",
            "aggregate_decomposition",
            "done",
            "diagnose",
            "failed",
        }
        actual = set(data["states"].keys())
        missing = required - actual
        assert not missing, f"Missing states: {missing}"

    def test_done_state_is_terminal(self, data: dict) -> None:
        """done state must have terminal: true."""
        done_state = data["states"].get("done", {})
        assert done_state.get("terminal") is True

    def test_failed_state_is_terminal(self, data: dict) -> None:
        """failed state must have terminal: true."""
        failed_state = data["states"].get("failed", {})
        assert failed_state.get("terminal") is True

    def test_dequeue_next_captures_input(self, data: dict) -> None:
        """dequeue_next must capture as 'input' for context_passthrough to work."""
        state = data["states"].get("dequeue_next", {})
        assert state.get("capture") == "input"

    def test_dequeue_next_routes_to_check_attempt_budget(self, data: dict) -> None:
        """dequeue_next.on_yes must route to check_attempt_budget (not directly to capture_baseline)."""
        state = data["states"].get("dequeue_next", {})
        assert state.get("on_yes") == "check_attempt_budget"

    def test_dequeue_next_on_no_routes_to_aggregate_decomposition(self, data: dict) -> None:
        """dequeue_next.on_no must route to aggregate_decomposition (not directly to done)."""
        state = data["states"].get("dequeue_next", {})
        assert state.get("on_no") == "aggregate_decomposition"

    def test_aggregate_decomposition_state_exists(self, data: dict) -> None:
        """aggregate_decomposition state must be present in the FSM."""
        assert "aggregate_decomposition" in data["states"]

    def test_diagnose_routes_to_failed(self, data: dict) -> None:
        state = data["states"].get("diagnose", {})
        assert state.get("next") == "failed"

    def test_diagnose_is_not_terminal(self, data: dict) -> None:
        state = data["states"].get("diagnose", {})
        assert not state.get("terminal", False)

    def test_parse_input_on_error_routes_to_diagnose(self, data: dict) -> None:
        state = data["states"].get("parse_input", {})
        assert state.get("on_error") == "diagnose"
        assert state.get("on_no") == "diagnose"

    def test_aggregate_decomposition_routes_to_done(self, data: dict) -> None:
        """aggregate_decomposition.next must route to done."""
        state = data["states"].get("aggregate_decomposition", {})
        assert state.get("next") == "done"

    def test_check_attempt_budget_routes_to_capture_baseline(self, data: dict) -> None:
        """check_attempt_budget.on_yes must route to capture_baseline."""
        state = data["states"].get("check_attempt_budget", {})
        assert state.get("on_yes") == "capture_baseline"

    def test_run_refine_delegates_to_sub_loop(self, data: dict) -> None:
        """run_refine must delegate to refine-to-ready-issue with context_passthrough."""
        state = data["states"].get("run_refine", {})
        assert state.get("loop") == "refine-to-ready-issue"
        assert state.get("context_passthrough") is True

    def test_run_refine_has_success_and_failure_routes(self, data: dict) -> None:
        """run_refine must define on_success and on_failure routes."""
        state = data["states"].get("run_refine", {})
        assert "on_success" in state
        assert "on_failure" in state

    def test_queue_file_uses_loops_tmp(self, data: dict) -> None:
        """Queue file references must use .loops/tmp/ (not bare /tmp/)."""
        states = data.get("states", {})
        queue_ref = "recursive-refine-queue"
        found = False
        for state_data in states.values():
            action = state_data.get("action", "")
            if queue_ref in action:
                found = True
                assert ".loops/tmp/" in action, (
                    f"Queue file reference must use .loops/tmp/, got: {action[:200]}"
                )
        assert found, f"No state references {queue_ref!r}"

    def test_skipped_file_uses_loops_tmp(self, data: dict) -> None:
        """Skipped tracking file must use .loops/tmp/ path."""
        states = data.get("states", {})
        skipped_ref = "recursive-refine-skipped"
        found = False
        for state_data in states.values():
            action = state_data.get("action", "")
            if skipped_ref in action:
                found = True
                assert ".loops/tmp/" in action
        assert found, f"No state references {skipped_ref!r}"

    def test_parse_input_validates_context_input(self, data: dict) -> None:
        """parse_input must check that ${context.input} is non-empty."""
        state = data["states"].get("parse_input", {})
        action = state.get("action", "")
        assert "${context.input}" in action

    def test_run_size_review_uses_auto_flag(self, data: dict) -> None:
        """run_size_review must invoke issue-size-review with --auto flag."""
        state = data["states"].get("run_size_review", {})
        action = state.get("action", "")
        assert "issue-size-review" in action
        assert "--auto" in action

    def test_context_thresholds_defined(self, data: dict) -> None:
        """context block must define the three threshold/limit variables."""
        ctx = data.get("context", {})
        assert "readiness_threshold" in ctx
        assert "outcome_threshold" in ctx
        assert "max_refine_count" in ctx
        assert "max_depth" in ctx

    def test_size_review_snap_routes_to_check_broke_down(self, data: dict) -> None:
        """size_review_snap.next must route to check_broke_down to guard against duplicate size-review."""
        state = data["states"].get("size_review_snap", {})
        assert state.get("next") == "check_broke_down", (
            f"size_review_snap.next should be 'check_broke_down', got {state.get('next')!r}"
        )

    def test_check_broke_down_state_exists(self, data: dict) -> None:
        """check_broke_down state must exist to skip duplicate size-review after breakdown_issue."""
        assert "check_broke_down" in data["states"], (
            "State 'check_broke_down' not found in recursive-refine.yaml"
        )

    def test_check_broke_down_evaluate_output_numeric_lt_1(self, data: dict) -> None:
        """check_broke_down must use output_numeric lt 1 to detect whether breakdown_issue ran."""
        state = data["states"].get("check_broke_down", {})
        evaluate = state.get("evaluate", {})
        assert evaluate.get("type") == "output_numeric", (
            f"check_broke_down evaluate.type should be 'output_numeric', got {evaluate.get('type')!r}"
        )
        assert evaluate.get("operator") == "lt", (
            f"check_broke_down evaluate.operator should be 'lt', got {evaluate.get('operator')!r}"
        )
        assert evaluate.get("target") == 1, (
            f"check_broke_down evaluate.target should be 1, got {evaluate.get('target')!r}"
        )

    def test_check_broke_down_on_yes_routes_to_recheck_scores(self, data: dict) -> None:
        """check_broke_down.on_yes (flag=0, not broken down) must route to recheck_scores."""
        state = data["states"].get("check_broke_down", {})
        assert state.get("on_yes") == "recheck_scores", (
            f"check_broke_down.on_yes should be 'recheck_scores', got {state.get('on_yes')!r}"
        )

    def test_check_broke_down_on_no_routes_to_enqueue_or_skip(self, data: dict) -> None:
        """check_broke_down.on_no (flag=1, already broken down) must route to enqueue_or_skip."""
        state = data["states"].get("check_broke_down", {})
        assert state.get("on_no") == "enqueue_or_skip", (
            f"check_broke_down.on_no should be 'enqueue_or_skip', got {state.get('on_no')!r}"
        )

    def test_check_broke_down_on_error_routes_to_recheck_scores(self, data: dict) -> None:
        """check_broke_down.on_error must route to recheck_scores (fail-safe: treat as not broken down)."""
        state = data["states"].get("check_broke_down", {})
        assert state.get("on_error") == "recheck_scores", (
            f"check_broke_down.on_error should be 'recheck_scores', got {state.get('on_error')!r}"
        )

    def test_check_broke_down_requires_children_file(self, data: dict) -> None:
        """BUG-1183: shortcut must require flag=1 AND non-empty new-children file,
        not the flag alone. Action must reference recursive-refine-new-children.txt."""
        state = data["states"].get("check_broke_down", {})
        action = state.get("action", "")
        assert "recursive-refine-broke-down" in action
        assert "recursive-refine-new-children.txt" in action

    def test_broke_down_flag_cleared_in_capture_baseline(self, data: dict) -> None:
        """capture_baseline must clear recursive-refine-broke-down so each issue iteration starts clean."""
        state = data["states"].get("capture_baseline", {})
        assert "recursive-refine-broke-down" in state.get("action", ""), (
            "capture_baseline action must clear '.loops/tmp/recursive-refine-broke-down' flag"
        )

    def test_recheck_scores_routes_to_dequeue_next(self, data: dict) -> None:
        """recheck_scores.on_yes must route to dequeue_next when scores already pass."""
        state = data["states"].get("recheck_scores", {})
        assert state.get("on_yes") == "dequeue_next", (
            f"recheck_scores.on_yes should be 'dequeue_next', got {state.get('on_yes')!r}"
        )

    def test_recheck_scores_on_no_routes_to_run_size_review(self, data: dict) -> None:
        """recheck_scores.on_no must route to check_depth (which gates into run_size_review)."""
        state = data["states"].get("recheck_scores", {})
        assert state.get("on_no") == "check_depth", (
            f"recheck_scores.on_no should be 'check_depth', got {state.get('on_no')!r}"
        )

    def test_recheck_scores_on_error_routes_to_run_size_review(self, data: dict) -> None:
        """recheck_scores.on_error must route to check_depth on evaluation error."""
        state = data["states"].get("recheck_scores", {})
        assert state.get("on_error") == "check_depth", (
            f"recheck_scores.on_error should be 'check_depth', got {state.get('on_error')!r}"
        )

    def test_check_depth_evaluate_output_numeric_lt_1(self, data: dict) -> None:
        """check_depth must use output_numeric lt 1 to detect depth-cap breach."""
        state = data["states"].get("check_depth", {})
        evaluate = state.get("evaluate", {})
        assert evaluate.get("type") == "output_numeric", (
            f"check_depth evaluate.type should be 'output_numeric', got {evaluate.get('type')!r}"
        )
        assert evaluate.get("operator") == "lt", (
            f"check_depth evaluate.operator should be 'lt', got {evaluate.get('operator')!r}"
        )
        assert evaluate.get("target") == 1, (
            f"check_depth evaluate.target should be 1, got {evaluate.get('target')!r}"
        )

    def test_check_depth_on_yes_routes_to_check_decision_needed(self, data: dict) -> None:
        """check_depth.on_yes (depth < max_depth) must route to check_decision_needed."""
        state = data["states"].get("check_depth", {})
        assert state.get("on_yes") == "check_decision_needed", (
            f"check_depth.on_yes should be 'check_decision_needed', got {state.get('on_yes')!r}"
        )

    def test_check_depth_on_no_routes_to_dequeue_next(self, data: dict) -> None:
        """check_depth.on_no (depth >= max_depth) must route to dequeue_next, skipping size-review."""
        state = data["states"].get("check_depth", {})
        assert state.get("on_no") == "dequeue_next", (
            f"check_depth.on_no should be 'dequeue_next', got {state.get('on_no')!r}"
        )

    def test_check_depth_on_error_routes_to_check_decision_needed(self, data: dict) -> None:
        """check_depth.on_error must route to check_decision_needed (fail-safe: proceed normally)."""
        state = data["states"].get("check_depth", {})
        assert state.get("on_error") == "check_decision_needed", (
            f"check_depth.on_error should be 'check_decision_needed', got {state.get('on_error')!r}"
        )

    def test_detect_children_filters_by_parent_reference(self, data: dict) -> None:
        """detect_children must use diff-ids.txt intermediate and filter by Decomposed from."""
        state = data["states"].get("detect_children", {})
        action = state.get("action", "")
        assert "recursive-refine-diff-ids.txt" in action, (
            "detect_children must write comm output to diff-ids.txt before filtering"
        )
        assert "Decomposed from" in action, (
            "detect_children must filter candidates by 'Decomposed from' parent reference"
        )

    def test_enqueue_or_skip_filters_by_parent_reference(self, data: dict) -> None:
        """enqueue_or_skip must use diff-ids.txt intermediate and filter by Decomposed from."""
        state = data["states"].get("enqueue_or_skip", {})
        action = state.get("action", "")
        assert "recursive-refine-diff-ids.txt" in action, (
            "enqueue_or_skip must write comm output to diff-ids.txt before filtering"
        )
        assert "Decomposed from" in action, (
            "enqueue_or_skip must filter candidates by 'Decomposed from' parent reference"
        )

    def test_enqueue_children_moves_parent_to_completed(self, data: dict) -> None:
        """enqueue_children must find and move the parent file to .issues/completed/ after decomposition."""
        state = data["states"].get("enqueue_children", {})
        action = state.get("action", "")
        assert "find .issues" in action, (
            "enqueue_children must use 'find .issues' to locate the parent file"
        )
        assert "completed" in action, (
            "enqueue_children must reference 'completed' directory for the move"
        )
        assert "mv" in action, "enqueue_children must contain 'mv' to move the parent file"

    def test_enqueue_or_skip_moves_parent_to_completed_when_children_found(
        self, data: dict
    ) -> None:
        """enqueue_or_skip children-found branch must find and move the parent file to .issues/completed/."""
        state = data["states"].get("enqueue_or_skip", {})
        action = state.get("action", "")
        # The find+mv block must appear before the 'else' (no-children branch)
        children_branch = action.split("else")[0] if "else" in action else action
        assert "find .issues" in children_branch, (
            "enqueue_or_skip children-found branch must use 'find .issues' to locate the parent file"
        )
        assert "completed" in children_branch, (
            "enqueue_or_skip children-found branch must reference 'completed' directory"
        )
        assert "mv" in children_branch, (
            "enqueue_or_skip children-found branch must contain 'mv' to move the parent file"
        )

    def test_enqueue_or_skip_else_does_not_move_parent(self, data: dict) -> None:
        """enqueue_or_skip else branch (no children) must NOT move the parent to completed/."""
        state = data["states"].get("enqueue_or_skip", {})
        action = state.get("action", "")
        assert "else" in action, "enqueue_or_skip must have an else branch"
        else_branch = action.split("else", 1)[1]
        assert "completed" not in else_branch, (
            "enqueue_or_skip else branch must NOT move parent to completed/ — "
            "issue remains open for future retry"
        )

    def test_parse_input_initializes_dequeued_count_and_total_enqueued(self, data: dict) -> None:
        """parse_input action must reference both ENH-1348 counter files."""
        action = data["states"].get("parse_input", {}).get("action", "")
        assert "recursive-refine-dequeued-count.txt" in action, (
            "parse_input must initialize recursive-refine-dequeued-count.txt"
        )
        assert "recursive-refine-total-enqueued.txt" in action, (
            "parse_input must initialize recursive-refine-total-enqueued.txt"
        )

    def test_parse_input_initializes_decomposed_and_deadend_tracking_files(
        self, data: dict
    ) -> None:
        """parse_input action must reference both ENH-1350 per-reason tracking files."""
        action = data["states"].get("parse_input", {}).get("action", "")
        assert "recursive-refine-skipped-decomposed.txt" in action, (
            "parse_input must initialize recursive-refine-skipped-decomposed.txt"
        )
        assert "recursive-refine-skipped-deadend.txt" in action, (
            "parse_input must initialize recursive-refine-skipped-deadend.txt"
        )

    def test_dequeue_next_action_references_dequeued_count_file(self, data: dict) -> None:
        """dequeue_next action must read and write recursive-refine-dequeued-count.txt (ENH-1348)."""
        action = data["states"].get("dequeue_next", {}).get("action", "")
        assert "recursive-refine-dequeued-count.txt" in action, (
            "dequeue_next must maintain recursive-refine-dequeued-count.txt for progress line"
        )

    def test_dequeue_next_emits_progress_line_to_stderr(self, data: dict) -> None:
        """dequeue_next action must emit a [N/M] → ID progress line to stderr (ENH-1348)."""
        action = data["states"].get("dequeue_next", {}).get("action", "")
        assert "recursive-refine-total-enqueued.txt" in action, (
            "dequeue_next must read recursive-refine-total-enqueued.txt for the progress line"
        )
        assert ">&2" in action, (
            "dequeue_next must redirect the progress printf to stderr so it does not "
            "interfere with stdout capture"
        )


class TestSprintBuildAndValidateLoop:
    """Structural tests for the sprint-build-and-validate FSM loop."""

    LOOP_FILE = BUILTIN_LOOPS_DIR / "sprint-build-and-validate.yaml"

    @pytest.fixture
    def data(self) -> dict:
        assert self.LOOP_FILE.exists(), f"Loop file not found: {self.LOOP_FILE}"
        return yaml.safe_load(self.LOOP_FILE.read_text())

    def test_required_top_level_fields(self, data: dict) -> None:
        """Loop must have name, initial, and states fields."""
        assert data.get("name") == "sprint-build-and-validate"
        assert data.get("initial") == "route_input"
        assert isinstance(data.get("states"), dict)

    def test_required_states_exist(self, data: dict) -> None:
        """All required states must be present."""
        required = {
            "route_input",
            "failed",
            "create_sprint",
            "route_create",
            "extract_sprint_issues",
            "refine_issues",
            "map_dependencies",
            "audit_conflicts",
            "commit",
            "run_sprint",
            "extract_unresolved",
            "refine_unresolved",
            "done",
        }
        actual = set(data["states"].keys())
        missing = required - actual
        assert not missing, f"Missing states: {missing}"

    def test_route_review_removed(self, data: dict) -> None:
        """route_review state must not exist (replaced by shell_exit routing on run_sprint)."""
        assert "route_review" not in data.get("states", {}), (
            "route_review is a dead state and must be removed"
        )

    def test_route_create_on_yes_targets_extract_sprint_issues(self, data: dict) -> None:
        """route_create.on_yes must target extract_sprint_issues."""
        state = data["states"].get("route_create", {})
        assert state.get("on_yes") == "extract_sprint_issues", (
            f"route_create.on_yes should be 'extract_sprint_issues', got {state.get('on_yes')!r}"
        )

    def test_route_input_routes_to_extract_when_name_provided(self, data: dict) -> None:
        """route_input.on_yes (exit 0, sprint found) must route to extract_sprint_issues."""
        state = data["states"].get("route_input", {})
        assert state.get("on_yes") == "extract_sprint_issues", (
            f"route_input.on_yes should be 'extract_sprint_issues', got {state.get('on_yes')!r}"
        )

    def test_route_input_routes_to_create_when_no_name(self, data: dict) -> None:
        """route_input.on_no (exit 1, no sprint_name) must route to create_sprint."""
        state = data["states"].get("route_input", {})
        assert state.get("on_no") == "create_sprint", (
            f"route_input.on_no should be 'create_sprint', got {state.get('on_no')!r}"
        )

    def test_route_input_routes_to_failed_on_error(self, data: dict) -> None:
        """route_input.on_error (exit 2, sprint file missing) must route to failed terminal state."""
        state = data["states"].get("route_input", {})
        assert state.get("on_error") == "failed", (
            f"route_input.on_error should be 'failed', got {state.get('on_error')!r}"
        )

    def test_failed_is_terminal(self, data: dict) -> None:
        """failed state must be terminal."""
        state = data["states"].get("failed", {})
        assert state.get("terminal") is True, "failed state must have terminal: true"

    def test_run_sprint_uses_shell_exit_fragment(self, data: dict) -> None:
        """run_sprint must use fragment: shell_exit for exit-code-based routing."""
        state = data["states"].get("run_sprint", {})
        assert state.get("fragment") == "shell_exit", (
            f"run_sprint.fragment should be 'shell_exit', got {state.get('fragment')!r}"
        )

    def test_run_sprint_on_yes_routes_to_done(self, data: dict) -> None:
        """run_sprint.on_yes (exit 0) must route to done."""
        state = data["states"].get("run_sprint", {})
        assert state.get("on_yes") == "done", (
            f"run_sprint.on_yes should be 'done', got {state.get('on_yes')!r}"
        )

    def test_run_sprint_on_no_routes_to_extract_unresolved(self, data: dict) -> None:
        """run_sprint.on_no (non-zero exit) must route to extract_unresolved."""
        state = data["states"].get("run_sprint", {})
        assert state.get("on_no") == "extract_unresolved", (
            f"run_sprint.on_no should be 'extract_unresolved', got {state.get('on_no')!r}"
        )

    def test_extract_unresolved_captures_as_input(self, data: dict) -> None:
        """extract_unresolved must capture as 'input' for context_passthrough to work."""
        state = data["states"].get("extract_unresolved", {})
        assert state.get("capture") == "input", (
            f"extract_unresolved.capture should be 'input', got {state.get('capture')!r}"
        )

    def test_extract_unresolved_on_yes_routes_to_refine_unresolved(self, data: dict) -> None:
        """extract_unresolved.on_yes must route to refine_unresolved."""
        state = data["states"].get("extract_unresolved", {})
        assert state.get("on_yes") == "refine_unresolved", (
            f"extract_unresolved.on_yes should be 'refine_unresolved', got {state.get('on_yes')!r}"
        )

    def test_extract_unresolved_on_no_routes_to_done(self, data: dict) -> None:
        """extract_unresolved.on_no (no unresolved issues) must route to done."""
        state = data["states"].get("extract_unresolved", {})
        assert state.get("on_no") == "done", (
            f"extract_unresolved.on_no should be 'done', got {state.get('on_no')!r}"
        )

    def test_refine_unresolved_delegates_to_recursive_refine(self, data: dict) -> None:
        """refine_unresolved must delegate to recursive-refine sub-loop."""
        state = data["states"].get("refine_unresolved", {})
        assert state.get("loop") == "recursive-refine", (
            f"refine_unresolved.loop should be 'recursive-refine', got {state.get('loop')!r}"
        )

    def test_refine_unresolved_uses_context_passthrough(self, data: dict) -> None:
        """refine_unresolved must use context_passthrough to pass captured.input to child loop."""
        state = data["states"].get("refine_unresolved", {})
        assert state.get("context_passthrough") is True, (
            "refine_unresolved must have context_passthrough: true"
        )

    def test_done_state_is_terminal(self, data: dict) -> None:
        """done state must have terminal: true."""
        done_state = data["states"].get("done", {})
        assert done_state.get("terminal") is True


class TestHtmlWebsiteGeneratorLoop:
    """Structural tests for the html-website-generator FSM loop."""

    LOOP_FILE = BUILTIN_LOOPS_DIR / "html-website-generator.yaml"

    @pytest.fixture
    def data(self) -> dict:
        assert self.LOOP_FILE.exists(), f"Loop file not found: {self.LOOP_FILE}"
        return yaml.safe_load(self.LOOP_FILE.read_text())

    def test_required_top_level_fields(self, data: dict) -> None:
        """Loop must have name, initial, input_key, and states fields."""
        assert data.get("name") == "html-website-generator"
        assert data.get("initial") == "plan"
        assert data.get("input_key") == "description"
        assert isinstance(data.get("states"), dict)

    def test_required_states_exist(self, data: dict) -> None:
        """All required states must be present."""
        required = {"plan", "generate", "evaluate", "score", "done"}
        actual = set(data["states"].keys())
        missing = required - actual
        assert not missing, f"Missing states: {missing}"

    def test_done_state_is_terminal(self, data: dict) -> None:
        """done state must have terminal: true."""
        done_state = data["states"].get("done", {})
        assert done_state.get("terminal") is True

    def test_evaluate_state_is_shell(self, data: dict) -> None:
        """evaluate state must use action_type: shell for the Playwright CLI call."""
        state = data["states"].get("evaluate", {})
        assert state.get("action_type") == "shell"

    def test_evaluate_state_has_output_contains_evaluator(self, data: dict) -> None:
        """evaluate state must have an output_contains evaluator with pattern CAPTURED."""
        state = data["states"].get("evaluate", {})
        evaluator = state.get("evaluate", {})
        assert evaluator.get("type") == "output_contains"
        assert evaluator.get("pattern") == "CAPTURED"

    def test_evaluate_routes_to_score_on_yes(self, data: dict) -> None:
        """evaluate state must route to score when screenshot succeeds."""
        state = data["states"].get("evaluate", {})
        assert state.get("on_yes") == "score"

    def test_evaluate_routes_to_generate_on_no(self, data: dict) -> None:
        """evaluate state must route back to generate when screenshot fails."""
        state = data["states"].get("evaluate", {})
        assert state.get("on_no") == "generate"

    def test_score_state_routes_to_done_on_pass(self, data: dict) -> None:
        """score state must route to done when all criteria pass."""
        state = data["states"].get("score", {})
        assert state.get("on_yes") == "done"

    def test_score_state_routes_to_generate_on_iterate(self, data: dict) -> None:
        """score state must route back to generate when criteria are not met."""
        state = data["states"].get("score", {})
        assert state.get("on_no") == "generate"

    def test_context_has_description_and_output_dir(self, data: dict) -> None:
        """context block must define description and output_dir variables."""
        ctx = data.get("context", {})
        assert "description" in ctx
        assert "output_dir" in ctx

    def test_max_iterations_and_timeout_defined(self, data: dict) -> None:
        """Loop must define max_iterations and timeout."""
        assert data.get("max_iterations", 0) > 0
        assert data.get("timeout", 0) > 0


class TestSvgImageGeneratorLoop:
    """Structural tests for the svg-image-generator FSM loop."""

    LOOP_FILE = BUILTIN_LOOPS_DIR / "svg-image-generator.yaml"

    @pytest.fixture
    def data(self) -> dict:
        assert self.LOOP_FILE.exists(), f"Loop file not found: {self.LOOP_FILE}"
        return yaml.safe_load(self.LOOP_FILE.read_text())

    def test_required_top_level_fields(self, data: dict) -> None:
        """Loop must have name, initial, input_key, and states fields."""
        assert data.get("name") == "svg-image-generator"
        assert data.get("initial") == "init"
        assert data.get("input_key") == "description"
        assert isinstance(data.get("states"), dict)

    def test_required_states_exist(self, data: dict) -> None:
        """All required states must be present."""
        required = {"init", "plan", "generate", "evaluate", "score", "done", "diagnose", "failed"}
        actual = set(data["states"].keys())
        missing = required - actual
        assert not missing, f"Missing states: {missing}"

    def test_init_state_is_shell_with_capture(self, data: dict) -> None:
        """init state must be a shell action that captures the timestamped run directory."""
        state = data["states"].get("init", {})
        assert state.get("action_type") == "shell"
        assert state.get("capture") == "run_dir"
        assert state.get("next") == "plan"

    def test_done_state_is_terminal(self, data: dict) -> None:
        """done state must have terminal: true."""
        done_state = data["states"].get("done", {})
        assert done_state.get("terminal") is True

    def test_evaluate_state_is_shell(self, data: dict) -> None:
        """evaluate state must use action_type: shell for the Playwright CLI call."""
        state = data["states"].get("evaluate", {})
        assert state.get("action_type") == "shell"

    def test_evaluate_state_has_output_contains_evaluator(self, data: dict) -> None:
        """evaluate state must have an output_contains evaluator with pattern CAPTURED."""
        state = data["states"].get("evaluate", {})
        evaluator = state.get("evaluate", {})
        assert evaluator.get("type") == "output_contains"
        assert evaluator.get("pattern") == "CAPTURED"

    def test_evaluate_routes_to_score_on_yes(self, data: dict) -> None:
        """evaluate state must route to score when screenshot succeeds."""
        state = data["states"].get("evaluate", {})
        assert state.get("on_yes") == "score"

    def test_evaluate_routes_to_generate_on_no(self, data: dict) -> None:
        """evaluate state must route back to generate when screenshot fails."""
        state = data["states"].get("evaluate", {})
        assert state.get("on_no") == "generate"

    def test_score_state_routes_to_done_on_pass(self, data: dict) -> None:
        """score state must route to done when all criteria pass."""
        state = data["states"].get("score", {})
        assert state.get("on_yes") == "done"

    def test_score_state_routes_to_generate_on_iterate(self, data: dict) -> None:
        """score state must route back to generate when criteria are not met."""
        state = data["states"].get("score", {})
        assert state.get("on_no") == "generate"

    def test_context_has_description_and_output_dir(self, data: dict) -> None:
        """context block must define description and output_dir variables with correct defaults."""
        ctx = data.get("context", {})
        assert "description" in ctx
        assert ctx.get("output_dir") == ".loops/tmp/svg-image-generator"

    def test_max_iterations_and_timeout_defined(self, data: dict) -> None:
        """Loop must define max_iterations and timeout."""
        assert data.get("max_iterations", 0) > 0
        assert data.get("timeout", 0) > 0

    def test_init_action_uses_absolute_path(self, data: dict) -> None:
        """init action must echo an absolute path so file:// URIs are valid."""
        state = data["states"].get("init", {})
        action = state.get("action", "")
        assert "$(pwd)" in action, (
            f"init.action must use $(pwd) for an absolute path, got: {action!r}"
        )

    def test_evaluate_action_has_stderr_redirect(self, data: dict) -> None:
        """evaluate action must redirect stderr to stdout so playwright errors surface."""
        state = data["states"].get("evaluate", {})
        action = state.get("action", "")
        assert "2>&1" in action, f"evaluate.action must contain 2>&1, got: {action!r}"

    def test_score_on_error_routes_to_failed(self, data: dict) -> None:
        """score state must route to diagnose on error to surface LLM failures explicitly."""
        state = data["states"].get("score", {})
        assert state.get("on_error") == "diagnose"

    def test_diagnose_routes_to_failed(self, data: dict) -> None:
        """diagnose state must route to failed."""
        state = data["states"].get("diagnose", {})
        assert state.get("next") == "failed"

    def test_diagnose_is_not_terminal(self, data: dict) -> None:
        """diagnose state must not be a terminal state."""
        state = data["states"].get("diagnose", {})
        assert not state.get("terminal", False)


class TestSvgTextgradLoop:
    """Structural tests for the svg-textgrad FSM loop."""

    LOOP_FILE = BUILTIN_LOOPS_DIR / "svg-textgrad.yaml"

    @pytest.fixture
    def data(self) -> dict:
        assert self.LOOP_FILE.exists(), f"Loop file not found: {self.LOOP_FILE}"
        return yaml.safe_load(self.LOOP_FILE.read_text())

    def test_required_top_level_fields(self, data: dict) -> None:
        """Loop must have name, initial, input_key, and states fields."""
        assert data.get("name") == "svg-textgrad"
        assert data.get("initial") == "init"
        assert data.get("input_key") == "description"
        assert isinstance(data.get("states"), dict)

    def test_required_states_exist(self, data: dict) -> None:
        """All required states must be present."""
        required = {
            "init",
            "plan",
            "generate",
            "evaluate",
            "score",
            "verify_score",
            "record_scores",
            "compute_gradient",
            "route_convergence",
            "append_gradient",
            "apply_gradient",
            "done",
            "diagnose",
            "failed",
        }
        actual = set(data["states"].keys())
        missing = required - actual
        assert not missing, f"Missing states: {missing}"

    def test_init_state_is_shell_with_capture(self, data: dict) -> None:
        """init state must be a shell action that captures the timestamped run directory."""
        state = data["states"].get("init", {})
        assert state.get("action_type") == "shell"
        assert state.get("capture") == "run_dir"
        assert state.get("next") == "plan"

    def test_done_state_is_terminal(self, data: dict) -> None:
        """done state must have terminal: true."""
        done_state = data["states"].get("done", {})
        assert done_state.get("terminal") is True

    def test_generate_does_not_reference_critique(self, data: dict) -> None:
        """generate state must NOT reference critique.md (reads only brief.md)."""
        state = data["states"].get("generate", {})
        action = state.get("action", "")
        assert "critique" not in action, "generate state must not reference critique.md"

    def test_score_routes_to_verify_score(self, data: dict) -> None:
        """score state must route to verify_score (external pass/fail evaluator)."""
        state = data["states"].get("score", {})
        assert state.get("next") == "verify_score"

    def test_compute_gradient_captures_gradient(self, data: dict) -> None:
        """compute_gradient state must capture its output as 'gradient'."""
        state = data["states"].get("compute_gradient", {})
        assert state.get("capture") == "gradient"

    def test_compute_gradient_routes_to_route_convergence(self, data: dict) -> None:
        """compute_gradient state must route to route_convergence (not append_gradient directly)."""
        state = data["states"].get("compute_gradient", {})
        assert state.get("next") == "route_convergence"

    def test_append_gradient_is_shell_routes_to_apply_gradient(self, data: dict) -> None:
        """append_gradient state must be a shell state that routes to apply_gradient."""
        state = data["states"].get("append_gradient", {})
        assert state.get("action_type") == "shell"
        assert state.get("next") == "apply_gradient"

    def test_apply_gradient_routes_to_generate(self, data: dict) -> None:
        """apply_gradient state must route back to generate."""
        state = data["states"].get("apply_gradient", {})
        assert state.get("next") == "generate"

    def test_context_has_description_and_output_dir(self, data: dict) -> None:
        """context block must define description and output_dir with correct defaults."""
        ctx = data.get("context", {})
        assert "description" in ctx
        assert ctx.get("output_dir") == ".loops/tmp/svg-textgrad"

    def test_max_iterations_and_timeout_defined(self, data: dict) -> None:
        """Loop must define max_iterations and timeout."""
        assert data.get("max_iterations", 0) > 0
        assert data.get("timeout", 0) > 0

    def test_evaluate_state_is_shell(self, data: dict) -> None:
        """evaluate state must use action_type: shell for the Playwright CLI call."""
        state = data["states"].get("evaluate", {})
        assert state.get("action_type") == "shell"

    def test_evaluate_state_has_output_contains_evaluator(self, data: dict) -> None:
        """evaluate state must have an output_contains evaluator with pattern CAPTURED."""
        state = data["states"].get("evaluate", {})
        evaluator = state.get("evaluate", {})
        assert evaluator.get("type") == "output_contains"
        assert evaluator.get("pattern") == "CAPTURED"

    def test_evaluate_routes_to_score_on_yes(self, data: dict) -> None:
        """evaluate state must route to score when screenshot succeeds."""
        state = data["states"].get("evaluate", {})
        assert state.get("on_yes") == "score"

    def test_evaluate_routes_to_generate_on_no(self, data: dict) -> None:
        """evaluate state must route back to generate when screenshot fails."""
        state = data["states"].get("evaluate", {})
        assert state.get("on_no") == "generate"

    def test_init_action_uses_absolute_path(self, data: dict) -> None:
        """init action must echo an absolute path so file:// URIs are valid."""
        state = data["states"].get("init", {})
        action = state.get("action", "")
        assert "$(pwd)" in action, (
            f"init.action must use $(pwd) for an absolute path, got: {action!r}"
        )

    def test_evaluate_action_has_stderr_redirect(self, data: dict) -> None:
        """evaluate action must redirect stderr to stdout so playwright errors surface."""
        state = data["states"].get("evaluate", {})
        action = state.get("action", "")
        assert "2>&1" in action, f"evaluate.action must contain 2>&1, got: {action!r}"

    def test_failed_state_is_terminal(self, data: dict) -> None:
        """failed state must have terminal: true."""
        state = data["states"].get("failed", {})
        assert state.get("terminal") is True

    def test_diagnose_routes_to_failed(self, data: dict) -> None:
        """diagnose state must route to failed."""
        state = data["states"].get("diagnose", {})
        assert state.get("next") == "failed"

    def test_diagnose_is_not_terminal(self, data: dict) -> None:
        """diagnose state must not be a terminal state."""
        state = data["states"].get("diagnose", {})
        assert not state.get("terminal", False)

    def test_evaluate_on_error_routes_to_generate(self, data: dict) -> None:
        """evaluate state must route to generate on error so Playwright failures don't stall."""
        state = data["states"].get("evaluate", {})
        assert state.get("on_error") == "generate"

    def test_score_on_error_routes_to_failed(self, data: dict) -> None:
        """score state must route to diagnose on error to surface LLM failures explicitly."""
        state = data["states"].get("score", {})
        assert state.get("on_error") == "diagnose"

    def test_record_scores_is_shell(self, data: dict) -> None:
        """record_scores state must be a shell action."""
        state = data["states"].get("record_scores", {})
        assert state.get("action_type") == "shell"

    def test_record_scores_routes_to_compute_gradient(self, data: dict) -> None:
        """record_scores state must route to compute_gradient."""
        state = data["states"].get("record_scores", {})
        assert state.get("next") == "compute_gradient"

    def test_route_convergence_has_output_contains_evaluator(self, data: dict) -> None:
        """route_convergence must have an output_contains evaluator with pattern CONVERGED."""
        state = data["states"].get("route_convergence", {})
        evaluator = state.get("evaluate", {})
        assert evaluator.get("type") == "output_contains"
        assert evaluator.get("pattern") == "CONVERGED"

    def test_route_convergence_evaluator_source(self, data: dict) -> None:
        """route_convergence evaluate block must define source pointing to gradient capture."""
        state = data["states"].get("route_convergence", {})
        evaluator = state.get("evaluate", {})
        assert evaluator.get("source") == "${captured.gradient.output}", (
            "route_convergence.evaluate must have "
            "'source: \"${captured.gradient.output}\"' so the evaluator "
            "reads the prior compute_gradient output, not this state's (empty) output"
        )

    def test_route_convergence_on_yes_routes_to_done(self, data: dict) -> None:
        """route_convergence must route to done when CONVERGED is detected."""
        state = data["states"].get("route_convergence", {})
        assert state.get("on_yes") == "done"

    def test_route_convergence_on_no_routes_to_append_gradient(self, data: dict) -> None:
        """route_convergence must route to append_gradient when not converged."""
        state = data["states"].get("route_convergence", {})
        assert state.get("on_no") == "append_gradient"

    def test_route_convergence_has_on_error(self, data: dict) -> None:
        """route_convergence must define on_error to handle evaluator failures gracefully."""
        state = data["states"].get("route_convergence", {})
        assert "on_error" in state

    def test_done_reports_scores_md_and_best_artifacts(self, data: dict) -> None:
        """done state action must reference scores.md, best.svg, and best-brief.md."""
        state = data["states"].get("done", {})
        action = state.get("action", "")
        assert "scores.md" in action, "done.action must reference scores.md"
        assert "best.svg" in action, "done.action must reference best.svg"
        assert "best-brief.md" in action, "done.action must reference best-brief.md"

    def test_init_touches_scores_md(self, data: dict) -> None:
        """init action must touch scores.md so compute_gradient can read it on iteration 1."""
        state = data["states"].get("init", {})
        action = state.get("action", "")
        assert "scores.md" in action, (
            "init.action must touch scores.md to prevent read errors on iteration 1"
        )

    def test_verify_score_is_shell(self, data: dict) -> None:
        """verify_score state must use action_type: shell for external arithmetic."""
        state = data["states"].get("verify_score", {})
        assert state.get("action_type") == "shell"

    def test_verify_score_has_output_contains_evaluator(self, data: dict) -> None:
        """verify_score must have an output_contains evaluator with pattern SHELL_PASS."""
        state = data["states"].get("verify_score", {})
        evaluator = state.get("evaluate", {})
        assert evaluator.get("type") == "output_contains"
        assert evaluator.get("pattern") == "SHELL_PASS"

    def test_verify_score_routes_to_done_on_yes(self, data: dict) -> None:
        """verify_score must route to done when weighted average meets pass_threshold."""
        state = data["states"].get("verify_score", {})
        assert state.get("on_yes") == "done"

    def test_verify_score_routes_to_record_scores_on_no(self, data: dict) -> None:
        """verify_score must route to record_scores on SHELL_ITERATE."""
        state = data["states"].get("verify_score", {})
        assert state.get("on_no") == "record_scores"

    def test_verify_score_routes_to_record_scores_on_error(self, data: dict) -> None:
        """verify_score must route to record_scores on error so failures continue the loop."""
        state = data["states"].get("verify_score", {})
        assert state.get("on_error") == "record_scores"

    def test_verify_score_appends_scores_md(self, data: dict) -> None:
        """verify_score action must append to scores.md (moved from record_scores)."""
        state = data["states"].get("verify_score", {})
        action = state.get("action", "")
        assert "scores.md" in action, "verify_score.action must append to scores.md"

    def test_append_gradient_action_uses_temp_file(self, data: dict) -> None:
        """append_gradient must use temp-file pattern, not inline GRAD= assignment."""
        state = data["states"].get("append_gradient", {})
        action = state.get("action", "")
        assert 'GRAD="${captured.gradient.output}"' not in action, (
            "append_gradient.action must not assign gradient output to GRAD= directly "
            "(bash quoting breaks on backticks/colons in multi-line content)"
        )
        assert ".gradient_tmp.txt" in action, (
            "append_gradient.action must use a temp file to safely handle multi-line gradient output"
        )


class TestWorktreeHealthLoop:
    """Structural tests for the worktree-health FSM loop (ENH-1254)."""

    LOOP_FILE = BUILTIN_LOOPS_DIR / "worktree-health.yaml"

    def _collect_action_text(self, data: dict) -> list[str]:
        """Recursively collect all action strings from an FSM data dict."""
        texts: list[str] = []
        for state_data in data.get("states", {}).values():
            action = state_data.get("action", "")
            if isinstance(action, str):
                texts.append(action)
        return texts

    @pytest.fixture
    def data(self) -> dict:
        assert self.LOOP_FILE.exists(), f"Loop file not found: {self.LOOP_FILE}"
        return yaml.safe_load(self.LOOP_FILE.read_text())

    def test_uses_porcelain_worktree_list(self, data: dict) -> None:
        """check_worktrees action must use git worktree list --porcelain."""
        combined = "\n".join(self._collect_action_text(data))
        assert "git worktree list --porcelain" in combined, (
            "worktree-health.yaml must use 'git worktree list --porcelain' to count orphans"
        )

    def test_does_not_grep_for_ll_worktree(self, data: dict) -> None:
        """check_worktrees action must not grep for 'll-worktree' (broken pattern)."""
        combined = "\n".join(self._collect_action_text(data))
        assert "ll-worktree" not in combined, (
            "worktree-health.yaml must not grep for 'll-worktree'; it matches no worktree names"
        )


class TestHtmlAnythingLoop:
    """Structural tests for the html-anything FSM loop (FEAT-1541)."""

    LOOP_FILE = BUILTIN_LOOPS_DIR / "html-anything.yaml"

    @pytest.fixture
    def data(self) -> dict:
        assert self.LOOP_FILE.exists(), f"Loop file not found: {self.LOOP_FILE}"
        return yaml.safe_load(self.LOOP_FILE.read_text())

    def test_required_top_level_fields(self, data: dict) -> None:
        """Loop must have name, initial, input_key, and states fields."""
        assert data.get("name") == "html-anything"
        assert data.get("initial") == "init"
        assert data.get("input_key") == "description"
        assert isinstance(data.get("states"), dict)

    def test_required_states_exist(self, data: dict) -> None:
        """All required states must be present: init, plan, generate, evaluate, score, done, diagnose, failed."""
        required = {"init", "plan", "generate", "evaluate", "score", "done", "diagnose", "failed"}
        actual = set(data["states"].keys())
        missing = required - actual
        assert not missing, f"Missing states: {missing}"

    def test_init_state_is_shell_with_capture(self, data: dict) -> None:
        """init state must be a shell action that captures the timestamped run directory."""
        state = data["states"].get("init", {})
        assert state.get("action_type") == "shell"
        assert state.get("capture") == "run_dir"
        assert state.get("next") == "plan"

    def test_init_action_uses_absolute_path(self, data: dict) -> None:
        """init action must echo an absolute path so file:// URIs are valid."""
        state = data["states"].get("init", {})
        action = state.get("action", "")
        assert "$(pwd)" in action, (
            f"init.action must use $(pwd) for an absolute path, got: {action!r}"
        )

    def test_done_state_is_terminal(self, data: dict) -> None:
        """done state must have terminal: true."""
        done_state = data["states"].get("done", {})
        assert done_state.get("terminal") is True

    def test_failed_state_is_terminal(self, data: dict) -> None:
        """failed state must have terminal: true."""
        state = data["states"].get("failed", {})
        assert state.get("terminal") is True

    def test_diagnose_routes_to_failed(self, data: dict) -> None:
        """diagnose state must route to failed."""
        state = data["states"].get("diagnose", {})
        assert state.get("next") == "failed"

    def test_diagnose_is_not_terminal(self, data: dict) -> None:
        """diagnose state must not be a terminal state."""
        state = data["states"].get("diagnose", {})
        assert not state.get("terminal", False)

    def test_evaluate_state_is_shell(self, data: dict) -> None:
        """evaluate state must use action_type: shell for the Playwright CLI call."""
        state = data["states"].get("evaluate", {})
        assert state.get("action_type") == "shell"

    def test_evaluate_state_has_output_contains_evaluator(self, data: dict) -> None:
        """evaluate state must have an output_contains evaluator with pattern CAPTURED."""
        state = data["states"].get("evaluate", {})
        evaluator = state.get("evaluate", {})
        assert evaluator.get("type") == "output_contains"
        assert evaluator.get("pattern") == "CAPTURED"

    def test_evaluate_routes_to_score_on_yes(self, data: dict) -> None:
        """evaluate state must route to score when screenshot succeeds."""
        state = data["states"].get("evaluate", {})
        assert state.get("on_yes") == "score"

    def test_evaluate_routes_to_score_on_no(self, data: dict) -> None:
        """evaluate state must route to score for LLM-only fallback when screenshot fails."""
        state = data["states"].get("evaluate", {})
        assert state.get("on_no") == "score"

    def test_evaluate_on_error_routes_to_score(self, data: dict) -> None:
        """evaluate state must route to score on error so Playwright absence degrades gracefully."""
        state = data["states"].get("evaluate", {})
        assert state.get("on_error") == "score"

    def test_evaluate_action_has_stderr_redirect(self, data: dict) -> None:
        """evaluate action must redirect stderr to stdout so playwright errors surface."""
        state = data["states"].get("evaluate", {})
        action = state.get("action", "")
        assert "2>&1" in action, f"evaluate.action must contain 2>&1, got: {action!r}"

    def test_score_state_uses_all_pass_pattern(self, data: dict) -> None:
        """score state must use output_contains with pattern ALL_PASS."""
        state = data["states"].get("score", {})
        evaluator = state.get("evaluate", {})
        assert evaluator.get("type") == "output_contains"
        assert evaluator.get("pattern") == "ALL_PASS"

    def test_score_state_routes_to_done_on_pass(self, data: dict) -> None:
        """score state must route to done when all criteria pass."""
        state = data["states"].get("score", {})
        assert state.get("on_yes") == "done"

    def test_score_state_routes_to_generate_on_iterate(self, data: dict) -> None:
        """score state must route back to generate when criteria are not met."""
        state = data["states"].get("score", {})
        assert state.get("on_no") == "generate"

    def test_score_on_error_routes_to_failed(self, data: dict) -> None:
        """score state must route to diagnose on error to surface LLM failures explicitly."""
        state = data["states"].get("score", {})
        assert state.get("on_error") == "diagnose"

    def test_score_action_has_screenshot_or_html_fallback(self, data: dict) -> None:
        """score state action must have the screenshot-or-HTML fallback preamble for graceful Playwright degradation."""
        state = data["states"].get("score", {})
        action = state.get("action", "")
        assert "screenshot.png exists" in action, (
            "score.action must check if screenshot.png exists for graceful Playwright degradation"
        )
        assert "Otherwise read" in action, (
            "score.action must fall back to reading index.html when screenshot is absent"
        )

    def test_context_has_description_and_output_dir(self, data: dict) -> None:
        """context block must define description and output_dir with correct defaults."""
        ctx = data.get("context", {})
        assert "description" in ctx
        assert ctx.get("output_dir") == ".loops/tmp/html-anything"

    def test_context_pass_threshold_is_7(self, data: dict) -> None:
        """pass_threshold must be 7 — higher than SVG's 6 because platform constraints are binary."""
        ctx = data.get("context", {})
        assert ctx.get("pass_threshold") == 7

    def test_max_iterations_and_timeout_defined(self, data: dict) -> None:
        """Loop must define max_iterations and timeout."""
        assert data.get("max_iterations", 0) > 0
        assert data.get("timeout", 0) > 0

    def test_plan_action_references_brief_and_rubric(self, data: dict) -> None:
        """plan state must write both brief.md and rubric.md in a single atomic state."""
        state = data["states"].get("plan", {})
        action = state.get("action", "")
        assert "brief.md" in action, "plan.action must write brief.md"
        assert "rubric.md" in action, "plan.action must write rubric.md"

    def test_score_action_reads_rubric_dynamically(self, data: dict) -> None:
        """score state must read rubric.md to load per-criterion thresholds dynamically."""
        state = data["states"].get("score", {})
        action = state.get("action", "")
        assert "rubric.md" in action, (
            "score.action must read rubric.md to load per-criterion thresholds"
        )

    def test_done_reports_all_five_output_files(self, data: dict) -> None:
        """done state must reference all 5 output files: index.html, brief.md, rubric.md, critique.md, screenshot.png."""
        state = data["states"].get("done", {})
        action = state.get("action", "")
        assert "index.html" in action, "done.action must reference index.html"
        assert "brief.md" in action, "done.action must reference brief.md"
        assert "rubric.md" in action, "done.action must reference rubric.md"
        assert "critique.md" in action, "done.action must reference critique.md"
        assert "screenshot.png" in action, "done.action must reference screenshot.png"


class TestHitlCompareLoop:
    """Structural tests for the hitl-compare FSM loop (FEAT-1545)."""

    LOOP_FILE = BUILTIN_LOOPS_DIR / "hitl-compare.yaml"

    @pytest.fixture
    def data(self) -> dict:
        assert self.LOOP_FILE.exists(), f"Loop file not found: {self.LOOP_FILE}"
        return yaml.safe_load(self.LOOP_FILE.read_text())

    def test_required_top_level_fields(self, data: dict) -> None:
        """Loop must have name, initial, input_key, and states fields."""
        assert data.get("name") == "hitl-compare"
        assert data.get("initial") == "init"
        assert data.get("input_key") == "inputs"
        assert isinstance(data.get("states"), dict)

    def test_required_states_exist(self, data: dict) -> None:
        """All required states must be present: init, identify, prune, generate, evaluate, score, done, failed."""
        required = {"init", "identify", "prune", "generate", "evaluate", "score", "done", "failed"}
        actual = set(data["states"].keys())
        missing = required - actual
        assert not missing, f"Missing states: {missing}"

    def test_init_state_is_shell_with_capture(self, data: dict) -> None:
        """init state must be a shell action that captures the timestamped run directory."""
        state = data["states"].get("init", {})
        assert state.get("action_type") == "shell"
        assert state.get("capture") == "run_dir"
        assert state.get("next") == "identify"

    def test_init_action_uses_absolute_path(self, data: dict) -> None:
        """init action must echo an absolute path so file:// URIs are valid."""
        state = data["states"].get("init", {})
        action = state.get("action", "")
        assert "$(pwd)" in action, (
            f"init.action must use $(pwd) for an absolute path, got: {action!r}"
        )

    def test_done_state_is_terminal(self, data: dict) -> None:
        """done state must have terminal: true."""
        done_state = data["states"].get("done", {})
        assert done_state.get("terminal") is True

    def test_failed_state_is_terminal(self, data: dict) -> None:
        """failed state must have terminal: true."""
        state = data["states"].get("failed", {})
        assert state.get("terminal") is True

    def test_evaluate_state_is_shell(self, data: dict) -> None:
        """evaluate state must use action_type: shell for the Playwright CLI call."""
        state = data["states"].get("evaluate", {})
        assert state.get("action_type") == "shell"

    def test_evaluate_state_has_output_contains_evaluator(self, data: dict) -> None:
        """evaluate state must have an output_contains evaluator with pattern CAPTURED."""
        state = data["states"].get("evaluate", {})
        evaluator = state.get("evaluate", {})
        assert evaluator.get("type") == "output_contains"
        assert evaluator.get("pattern") == "CAPTURED"

    def test_evaluate_routes_to_score_on_yes(self, data: dict) -> None:
        """evaluate state must route to score when screenshot succeeds."""
        state = data["states"].get("evaluate", {})
        assert state.get("on_yes") == "score"

    def test_evaluate_routes_to_score_on_no(self, data: dict) -> None:
        """evaluate state must route to score for LLM-only fallback when screenshot fails."""
        state = data["states"].get("evaluate", {})
        assert state.get("on_no") == "score"

    def test_evaluate_on_error_routes_to_score(self, data: dict) -> None:
        """evaluate state must route to score on error so Playwright absence degrades gracefully."""
        state = data["states"].get("evaluate", {})
        assert state.get("on_error") == "score"

    def test_evaluate_action_has_stderr_redirect(self, data: dict) -> None:
        """evaluate action must redirect stderr to stdout so playwright errors surface."""
        state = data["states"].get("evaluate", {})
        action = state.get("action", "")
        assert "2>&1" in action, f"evaluate.action must contain 2>&1, got: {action!r}"

    def test_score_state_uses_all_pass_pattern(self, data: dict) -> None:
        """score state must use output_contains with pattern ALL_PASS."""
        state = data["states"].get("score", {})
        evaluator = state.get("evaluate", {})
        assert evaluator.get("type") == "output_contains"
        assert evaluator.get("pattern") == "ALL_PASS"

    def test_score_state_routes_to_done_on_pass(self, data: dict) -> None:
        """score state must route to done when all criteria pass."""
        state = data["states"].get("score", {})
        assert state.get("on_yes") == "done"

    def test_score_state_routes_to_generate_on_iterate(self, data: dict) -> None:
        """score state must route back to generate when criteria are not met."""
        state = data["states"].get("score", {})
        assert state.get("on_no") == "generate"

    def test_score_on_error_routes_to_failed(self, data: dict) -> None:
        """score state must route to failed on error to surface LLM failures explicitly."""
        state = data["states"].get("score", {})
        assert state.get("on_error") == "failed"

    def test_context_has_inputs_and_output_dir(self, data: dict) -> None:
        """context block must define inputs and output_dir with correct defaults."""
        ctx = data.get("context", {})
        assert "inputs" in ctx
        assert ctx.get("output_dir") == ".loops/tmp/hitl-compare"

    def test_max_iterations_and_timeout_defined(self, data: dict) -> None:
        """Loop must define max_iterations and timeout."""
        assert data.get("max_iterations", 0) > 0
        assert data.get("timeout", 0) > 0

    def test_identify_action_writes_items_md(self, data: dict) -> None:
        """identify state action must reference items.md as the output file."""
        state = data["states"].get("identify", {})
        action = state.get("action", "")
        assert "items.md" in action, "identify.action must write items.md"

    def test_prune_action_writes_review_md(self, data: dict) -> None:
        """prune state action must reference review.md as the output file."""
        state = data["states"].get("prune", {})
        action = state.get("action", "")
        assert "review.md" in action, "prune.action must write review.md"

    def test_generate_action_writes_index_html(self, data: dict) -> None:
        """generate state action must reference index.html as the output file."""
        state = data["states"].get("generate", {})
        action = state.get("action", "")
        assert "index.html" in action, "generate.action must write index.html"

    def test_done_reports_all_output_files(self, data: dict) -> None:
        """done state must reference all key output files."""
        state = data["states"].get("done", {})
        action = state.get("action", "")
        assert "index.html" in action, "done.action must reference index.html"
        assert "items.md" in action, "done.action must reference items.md"
        assert "review.md" in action, "done.action must reference review.md"
        assert "critique.md" in action, "done.action must reference critique.md"
        assert "screenshot.png" in action, "done.action must reference screenshot.png"

    def test_generate_action_has_write_in_affordance(self, data: dict) -> None:
        """generate state action must include write-in custom option affordance instructions (ENH-1604)."""
        state = data["states"].get("generate", {})
        action = state.get("action", "")
        assert "Write custom option" in action, (
            "generate.action must contain write-in affordance instructions ('Write custom option')"
        )

    def test_score_comparison_ergonomics_references_write_in(self, data: dict) -> None:
        """score state comparison_ergonomics must reference the write-in affordance (ENH-1604)."""
        state = data["states"].get("score", {})
        action = state.get("action", "")
        assert "write-in" in action, (
            "score.action comparison_ergonomics must reference the write-in affordance"
        )


class TestHitlMdLoop:
    """Structural tests for the hitl-md FSM loop (FEAT-1613)."""

    LOOP_FILE = BUILTIN_LOOPS_DIR / "hitl-md.yaml"

    @pytest.fixture
    def data(self) -> dict:
        assert self.LOOP_FILE.exists(), f"Loop file not found: {self.LOOP_FILE}"
        return yaml.safe_load(self.LOOP_FILE.read_text())

    def test_required_top_level_fields(self, data: dict) -> None:
        """Loop must have name, initial, input_key (singular), and states fields."""
        assert data.get("name") == "hitl-md"
        assert data.get("initial") == "init"
        assert data.get("input_key") == "input"
        assert isinstance(data.get("states"), dict)

    def test_required_states_exist(self, data: dict) -> None:
        """All required states must be present: init, segment, generate, evaluate, score, done, failed."""
        required = {"init", "segment", "generate", "evaluate", "score", "done", "failed"}
        actual = set(data["states"].keys())
        missing = required - actual
        assert not missing, f"Missing states: {missing}"

    def test_init_state_is_shell_with_capture(self, data: dict) -> None:
        """init state must be a shell action that captures the timestamped run directory."""
        state = data["states"].get("init", {})
        assert state.get("action_type") == "shell"
        assert state.get("capture") == "run_dir"
        assert state.get("next") == "segment"

    def test_init_action_uses_absolute_path(self, data: dict) -> None:
        """init action must echo an absolute path so file:// URIs are valid."""
        state = data["states"].get("init", {})
        action = state.get("action", "")
        assert "$(pwd)" in action, (
            f"init.action must use $(pwd) for an absolute path, got: {action!r}"
        )

    def test_done_state_is_terminal(self, data: dict) -> None:
        """done state must have terminal: true."""
        done_state = data["states"].get("done", {})
        assert done_state.get("terminal") is True

    def test_failed_state_is_terminal(self, data: dict) -> None:
        """failed state must have terminal: true."""
        state = data["states"].get("failed", {})
        assert state.get("terminal") is True

    def test_evaluate_state_is_shell(self, data: dict) -> None:
        """evaluate state must use action_type: shell for the Playwright CLI call."""
        state = data["states"].get("evaluate", {})
        assert state.get("action_type") == "shell"

    def test_evaluate_state_has_output_contains_evaluator(self, data: dict) -> None:
        """evaluate state must have an output_contains evaluator with pattern CAPTURED."""
        state = data["states"].get("evaluate", {})
        evaluator = state.get("evaluate", {})
        assert evaluator.get("type") == "output_contains"
        assert evaluator.get("pattern") == "CAPTURED"

    def test_evaluate_routes_to_score_on_yes(self, data: dict) -> None:
        """evaluate state must route to score when screenshot succeeds."""
        state = data["states"].get("evaluate", {})
        assert state.get("on_yes") == "score"

    def test_evaluate_routes_to_score_on_no(self, data: dict) -> None:
        """evaluate state must route to score for LLM-only fallback when screenshot fails."""
        state = data["states"].get("evaluate", {})
        assert state.get("on_no") == "score"

    def test_evaluate_on_error_routes_to_generate(self, data: dict) -> None:
        """evaluate on_error must route to generate — deliberate divergence from hitl-compare pattern."""
        state = data["states"].get("evaluate", {})
        assert state.get("on_error") == "generate", (
            "hitl-md routes on_error to generate (not score) so malformed HTML is regenerated"
        )

    def test_evaluate_action_has_stderr_redirect(self, data: dict) -> None:
        """evaluate action must redirect stderr to stdout so playwright errors surface."""
        state = data["states"].get("evaluate", {})
        action = state.get("action", "")
        assert "2>&1" in action, f"evaluate.action must contain 2>&1, got: {action!r}"

    def test_score_state_uses_all_pass_pattern(self, data: dict) -> None:
        """score state must use output_contains with pattern ALL_PASS."""
        state = data["states"].get("score", {})
        evaluator = state.get("evaluate", {})
        assert evaluator.get("type") == "output_contains"
        assert evaluator.get("pattern") == "ALL_PASS"

    def test_score_state_routes_to_done_on_pass(self, data: dict) -> None:
        """score state must route to done when all criteria pass."""
        state = data["states"].get("score", {})
        assert state.get("on_yes") == "done"

    def test_score_state_routes_to_generate_on_iterate(self, data: dict) -> None:
        """score state must route back to generate when criteria are not met."""
        state = data["states"].get("score", {})
        assert state.get("on_no") == "generate"

    def test_score_on_error_routes_to_failed(self, data: dict) -> None:
        """score state must route to failed on error to surface LLM failures explicitly."""
        state = data["states"].get("score", {})
        assert state.get("on_error") == "failed"

    def test_context_has_input_and_output_dir(self, data: dict) -> None:
        """context block must define input (singular) and output_dir with correct defaults."""
        ctx = data.get("context", {})
        assert "input" in ctx, "context must have 'input' key (singular, not 'inputs')"
        assert ctx.get("output_dir") == ".loops/tmp/hitl-md"

    def test_max_iterations_and_timeout_defined(self, data: dict) -> None:
        """Loop must define max_iterations and timeout."""
        assert data.get("max_iterations", 0) > 0
        assert data.get("timeout", 0) > 0

    def test_segment_action_writes_segments_json(self, data: dict) -> None:
        """segment state action must reference segments.json as the output file."""
        state = data["states"].get("segment", {})
        action = state.get("action", "")
        assert "segments.json" in action, "segment.action must write segments.json"

    def test_generate_action_writes_index_html(self, data: dict) -> None:
        """generate state action must reference index.html as the output file."""
        state = data["states"].get("generate", {})
        action = state.get("action", "")
        assert "index.html" in action, "generate.action must write index.html"

    def test_done_reports_all_output_files(self, data: dict) -> None:
        """done state must reference all key output files."""
        state = data["states"].get("done", {})
        action = state.get("action", "")
        assert "index.html" in action, "done.action must reference index.html"
        assert "segments.json" in action, "done.action must reference segments.json"
        assert "critique.md" in action, "done.action must reference critique.md"
        assert "screenshot.png" in action, "done.action must reference screenshot.png"


class TestRlCodingAgentLoop:
    """Structural tests for the rl-coding-agent FSM loop."""

    LOOP_FILE = BUILTIN_LOOPS_DIR / "rl-coding-agent.yaml"

    @pytest.fixture
    def data(self) -> dict:
        assert self.LOOP_FILE.exists(), f"Loop file not found: {self.LOOP_FILE}"
        return yaml.safe_load(self.LOOP_FILE.read_text())

    def test_required_top_level_fields(self, data: dict) -> None:
        """Loop must have name, initial, and states fields."""
        assert data.get("name") == "rl-coding-agent"
        assert data.get("initial") == "act"
        assert isinstance(data.get("states"), dict)

    def test_required_states_exist(self, data: dict) -> None:
        """All required states must be present."""
        required = {
            "act",
            "refine",
            "observe",
            "score",
            "improve",
            "persist_reward",
            "done",
            "diagnose",
            "failed",
        }
        actual = set(data["states"].keys())
        missing = required - actual
        assert not missing, f"Missing states: {missing}"

    def test_done_state_is_terminal(self, data: dict) -> None:
        """done state must have terminal: true."""
        assert data["states"].get("done", {}).get("terminal") is True

    def test_failed_state_is_terminal(self, data: dict) -> None:
        """failed state must have terminal: true."""
        assert data["states"].get("failed", {}).get("terminal") is True

    def test_diagnose_routes_to_failed(self, data: dict) -> None:
        """diagnose state must route to failed."""
        state = data["states"].get("diagnose", {})
        assert state.get("next") == "failed"

    def test_diagnose_is_not_terminal(self, data: dict) -> None:
        """diagnose state must not be a terminal state."""
        state = data["states"].get("diagnose", {})
        assert not state.get("terminal", False)

    def test_score_error_routes_to_diagnose(self, data: dict) -> None:
        """score state convergence evaluator error route must target diagnose, not failed."""
        state = data["states"].get("score", {})
        route = state.get("route", {})
        assert route.get("error") == "diagnose", (
            f"score.route.error should be 'diagnose', got {route.get('error')!r}"
        )


class TestAgentEvalImproveLoop:
    """Structural tests for the agent-eval-improve FSM loop."""

    LOOP_FILE = BUILTIN_LOOPS_DIR / "agent-eval-improve.yaml"

    @pytest.fixture
    def data(self) -> dict:
        assert self.LOOP_FILE.exists(), f"Loop file not found: {self.LOOP_FILE}"
        return yaml.safe_load(self.LOOP_FILE.read_text())

    def test_required_top_level_fields(self, data: dict) -> None:
        """Loop must have name, initial, and states fields."""
        assert data.get("name") == "agent-eval-improve"
        assert data.get("initial") == "run_eval"
        assert isinstance(data.get("states"), dict)

    def test_required_states_exist(self, data: dict) -> None:
        """All required states must be present."""
        required = {
            "run_eval",
            "score_results",
            "analyze_failures",
            "route_quality",
            "refine_config",
            "done",
            "diagnose",
            "failed",
        }
        actual = set(data["states"].keys())
        missing = required - actual
        assert not missing, f"Missing states: {missing}"

    def test_done_state_is_terminal(self, data: dict) -> None:
        """done state must have terminal: true."""
        assert data["states"].get("done", {}).get("terminal") is True

    def test_failed_state_is_terminal(self, data: dict) -> None:
        """failed state must have terminal: true."""
        assert data["states"].get("failed", {}).get("terminal") is True

    def test_diagnose_routes_to_failed(self, data: dict) -> None:
        """diagnose state must route to failed."""
        state = data["states"].get("diagnose", {})
        assert state.get("next") == "failed"

    def test_diagnose_is_not_terminal(self, data: dict) -> None:
        """diagnose state must not be a terminal state."""
        state = data["states"].get("diagnose", {})
        assert not state.get("terminal", False)

    def test_run_eval_retry_exhausted_routes_to_diagnose(self, data: dict) -> None:
        """run_eval.on_retry_exhausted must route to diagnose."""
        state = data["states"].get("run_eval", {})
        assert state.get("on_retry_exhausted") == "diagnose", (
            f"run_eval.on_retry_exhausted should be 'diagnose', got {state.get('on_retry_exhausted')!r}"
        )

    def test_score_results_retry_exhausted_routes_to_diagnose(self, data: dict) -> None:
        """score_results.on_retry_exhausted must route to diagnose."""
        state = data["states"].get("score_results", {})
        assert state.get("on_retry_exhausted") == "diagnose", (
            f"score_results.on_retry_exhausted should be 'diagnose', got {state.get('on_retry_exhausted')!r}"
        )

    def test_analyze_failures_retry_exhausted_routes_to_diagnose(self, data: dict) -> None:
        """analyze_failures.on_retry_exhausted must route to diagnose."""
        state = data["states"].get("analyze_failures", {})
        assert state.get("on_retry_exhausted") == "diagnose", (
            f"analyze_failures.on_retry_exhausted should be 'diagnose', got {state.get('on_retry_exhausted')!r}"
        )

    def test_analyze_failures_error_routes_to_diagnose(self, data: dict) -> None:
        """analyze_failures.on_error must route to diagnose."""
        state = data["states"].get("analyze_failures", {})
        assert state.get("on_error") == "diagnose", (
            f"analyze_failures.on_error should be 'diagnose', got {state.get('on_error')!r}"
        )

    def test_route_quality_error_routes_to_diagnose(self, data: dict) -> None:
        """route_quality convergence evaluator error route must target diagnose."""
        state = data["states"].get("route_quality", {})
        route = state.get("route", {})
        assert route.get("error") == "diagnose", (
            f"route_quality.route.error should be 'diagnose', got {route.get('error')!r}"
        )

    def test_refine_config_retry_exhausted_routes_to_diagnose(self, data: dict) -> None:
        """refine_config.on_retry_exhausted must route to diagnose."""
        state = data["states"].get("refine_config", {})
        assert state.get("on_retry_exhausted") == "diagnose", (
            f"refine_config.on_retry_exhausted should be 'diagnose', got {state.get('on_retry_exhausted')!r}"
        )
