"""Runner for isort import sorter.

Invokes isort as a subprocess and returns a FormatterResult.
"""

from mcp_coder_utils.subprocess_runner import execute_command

from mcp_tools_py.formatter.models import FormatterResult

_MAX_LINES = 200


def _truncate_output(text: str) -> str:
    """Truncate output to a maximum number of lines."""
    lines = text.splitlines()
    if len(lines) <= _MAX_LINES:
        return text
    truncated = lines[:_MAX_LINES]
    remaining = len(lines) - _MAX_LINES
    truncated.append(f"... (truncated, {remaining} more lines)")
    return "\n".join(truncated)


def _parse_isort_changed_files(output: str) -> list[str]:
    """Parse file paths from isort output.

    isort reports changed files as:
    - Normal mode: ``Fixing src/foo.py``
    - Check mode: ``ERROR: src/foo.py Imports are incorrectly sorted ...``
    """
    files: list[str] = []
    for line in output.splitlines():
        if line.startswith("Fixing "):
            files.append(line[len("Fixing ") :])
        elif line.startswith("ERROR: ") and " Imports are incorrectly sorted" in line:
            path = line[len("ERROR: ") : line.index(" Imports are incorrectly sorted")]
            files.append(path)
    return files


def run_isort(
    python_executable: str,
    target_dirs: list[str],
    project_dir: str,
    check_only: bool = False,
) -> FormatterResult:
    """Run isort on target directories.

    Args:
        python_executable: Path to the Python executable.
        target_dirs: List of directories to sort imports in.
        project_dir: Root project directory (cwd for subprocess).
        check_only: If True, pass --check-only to only verify sorting.

    Returns:
        FormatterResult with output, success status, and changed files.
    """
    command = [python_executable, "-m", "isort"]
    if check_only:
        command.append("--check-only")
    command.extend(target_dirs)

    result = execute_command(command, cwd=project_dir)

    output_parts: list[str] = []
    if result.stdout:
        output_parts.append(result.stdout)
    if result.stderr:
        output_parts.append(result.stderr)
    output = "\n".join(output_parts) if output_parts else ""

    return FormatterResult(
        output=_truncate_output(output),
        success=result.return_code == 0,
        files_changed=_parse_isort_changed_files(output),
    )
