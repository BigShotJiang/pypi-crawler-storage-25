"""
Sandflare Python SDK
====================
Two resource types, both backed by Firecracker microVMs:

    Database  — Managed PostgreSQL (psql-N)
    Sandbox   — Compute VM for AI agents (sb-N), can be wired to databases

Quick start:
    from sandflare import Database, Sandbox

    # Create a database
    db = Database.create("myapp", password="Secret#1",
                          schema_prompt="A todo app with users and tasks")

    # Create a sandbox
    sb = Sandbox.create("agent")

    # Wire the sandbox to the database
    sb.wire("psql-1")
    # Now inside sb-1: os.environ["DATABASE_URL"] = postgres://...

    # Run Python code in the sandbox that accesses the database
    result = sb.run_python('''
        import os, psycopg2
        conn = psycopg2.connect(os.environ["DATABASE_URL"])
        cur = conn.cursor()
        cur.execute("SELECT count(*) FROM users")
        print(cur.fetchone())
    ''')
    print(result.stdout)

    # Query database in natural language
    print(db.query_nl("How many users signed up today?"))

    # Clean up
    sb.delete()
    db.delete()
"""
from __future__ import annotations

import http.client
import json
import os
import ssl
import threading
import time
import urllib.error
import urllib.parse
import urllib.request
import base64
import shlex
from dataclasses import dataclass, field
from typing import Any, Generator

DEFAULT_BASE_URL = "https://api.sandflare.io"

# ---------------------------------------------------------------------------
# Connection pool — reuses HTTPS connections to avoid per-request TLS overhead
# ---------------------------------------------------------------------------

_pool_lock = threading.Lock()
_conn_pool: dict[str, http.client.HTTPSConnection] = {}
_ssl_ctx = ssl.create_default_context()


def _get_conn(host: str, port: int) -> http.client.HTTPSConnection:
    key = f"{host}:{port}"
    with _pool_lock:
        conn = _conn_pool.get(key)
        if conn is None:
            conn = http.client.HTTPSConnection(host, port, context=_ssl_ctx, timeout=60)
            _conn_pool[key] = conn
    return conn


def _http_request(method: str, url: str, body: bytes | None,
                  headers: dict, timeout: int) -> tuple[int, bytes]:
    """Perform an HTTP/HTTPS request, reusing connections via module-level pool."""
    parsed = urllib.parse.urlparse(url)
    host = parsed.hostname or ""
    port = parsed.port or (443 if parsed.scheme == "https" else 80)
    path = parsed.path or "/"
    if parsed.query:
        path += "?" + parsed.query

    hdrs = dict(headers)
    hdrs.setdefault("Connection", "keep-alive")

    for attempt in range(2):  # retry once on stale connection
        conn = _get_conn(host, port)
        conn.timeout = timeout
        try:
            conn.request(method, path, body=body, headers=hdrs)
            resp = conn.getresponse()
            data = resp.read()
            if resp.status == 502 and attempt == 0:
                # 502 Bad Gateway from Cloudflare — stale upstream connection.
                # Refresh pool entry and retry with a fresh connection.
                try:
                    conn.close()
                except Exception:
                    pass
                with _pool_lock:
                    _conn_pool[key] = http.client.HTTPSConnection(host, port, context=_ssl_ctx, timeout=60)
                continue
            return resp.status, data
        except (http.client.RemoteDisconnected, ConnectionResetError,
                BrokenPipeError, OSError):
            # Connection was stale — close and retry with fresh one
            try:
                conn.close()
            except Exception:
                pass
            key = f"{host}:{port}"
            with _pool_lock:
                new_conn = http.client.HTTPSConnection(host, port, context=_ssl_ctx, timeout=60)
                _conn_pool[key] = new_conn
            if attempt == 1:
                raise


def _first_env(*names: str) -> str:
    for name in names:
        value = os.environ.get(name, "")
        if value:
            return value
    return ""


def _resolve_base_url(base_url: str | None = None) -> str:
    return (base_url or _first_env("SANDFLARE_API_URL", "PANDAAGENT_BASE_URL") or DEFAULT_BASE_URL).rstrip("/")


def _resolve_api_key(api_key: str | None = None) -> str:
    return api_key or _first_env("SANDFLARE_API_KEY", "PANDAAGENT_API_KEY", "AGENTBOX_API_KEY")


# ---------------------------------------------------------------------------
# Data classes
# ---------------------------------------------------------------------------

@dataclass
class ExecResult:
    exit_code: int
    stdout:    str
    stderr:    str
    ok:        bool

    def __str__(self):
        parts = [f"exit_code={self.exit_code}"]
        if self.stdout:
            parts.append(f"stdout={self.stdout[:200]!r}")
        if self.stderr:
            parts.append(f"stderr={self.stderr[:200]!r}")
        return f"ExecResult({', '.join(parts)})"

    def raise_on_error(self):
        if not self.ok:
            raise RuntimeError(
                f"Command failed (exit {self.exit_code}):\n{self.stderr or self.stdout}"
            )
        return self


@dataclass
class CodeResult:
    """Result from run_code() — stateful kernel execution."""
    text:   str | None   # last expression value (e.g. "42", "DataFrame(...)")
    stdout: str          # print() output
    stderr: str          # stderr output
    png:    str | None   # base64-encoded PNG if a matplotlib plot was generated
    html:   str | None   # HTML output (reserved for future use)
    error:  str | None   # full traceback if execution raised an exception
    ok:     bool         # True if no exception was raised

    def raise_on_error(self):
        if not self.ok:
            raise RuntimeError(f"Kernel execution failed:\n{self.error or self.stderr}")
        return self

    def save_png(self, path: str) -> bool:
        """Save the base64 PNG to a file. Returns True if a plot was saved."""
        import base64 as _b64
        if not self.png:
            return False
        with open(path, "wb") as f:
            f.write(_b64.b64decode(self.png))
        return True


@dataclass
class FileEntry:
    name:   str
    path:   str
    is_dir: bool
    size:   int
    mtime:  int


class SandflareError(Exception):
    def __init__(self, status: int, message: str, body: dict):
        super().__init__(f"HTTP {status}: {message}")
        self.status  = status
        self.message = message
        self.body    = body


AgentBoxError = SandflareError


class TierLimitError(SandflareError):
    """Raised when a request exceeds the plan's resource limits (HTTP 429)."""
    def __init__(self, message: str, body: dict):
        super().__init__(429, message, body)
        self.upgrade_url = body.get("upgrade_url", "https://app.sandflare.io/upgrade")

    def __str__(self):
        return (
            f"\n  ⚠️  Plan limit reached: {self.message}\n"
            f"  → Upgrade at: {self.upgrade_url}\n"
        )


class AuthError(SandflareError):
    """Raised on authentication failure (HTTP 401/403)."""
    def __init__(self, message: str, body: dict):
        super().__init__(403, message, body)


# ---------------------------------------------------------------------------
# HTTP helpers
# ---------------------------------------------------------------------------

def _req(method: str, url: str, body: Any = None, headers: dict | None = None,
         timeout: int = 35) -> dict:
    data = json.dumps(body).encode() if body is not None else None
    hdrs: dict[str, str] = {
        "Content-Type": "application/json",
        "User-Agent": "sandflare-sdk/1.0",
    } if data else {"User-Agent": "sandflare-sdk/1.0"}
    if headers:
        hdrs.update(headers)
    try:
        status, raw = _http_request(method, url, data, hdrs, timeout)
    except OSError as e:
        raise SandflareError(0, str(e), {}) from e

    try:
        parsed_url = urllib.parse.urlparse(url)
        if b"error code: 1010" in raw or (status >= 400 and b"<!doctype html" in raw.lower()):
            raise AuthError(
                "Request blocked — check your API key and ensure you are using the sandflare-sdk/1.0 User-Agent",
                {"error": "cloudflare_block"}
            )
        err_body = json.loads(raw) if raw else {}
    except (AuthError, TierLimitError):
        raise
    except Exception:
        err_body = {"error": raw.decode(errors="replace") if raw else ""}

    if status == 429:
        raise TierLimitError(err_body.get("error", "Resource limit exceeded"), err_body)
    if status in (401, 403):
        raise AuthError(
            err_body.get("error", "Unauthorized — check your SANDFLARE_API_KEY (or legacy AGENTBOX_API_KEY)"),
            err_body,
        )
    if status >= 400:
        raise SandflareError(status, err_body.get("error", f"HTTP {status}"), err_body)
    return json.loads(raw) if raw else {}


# ---------------------------------------------------------------------------
# Database — wraps /instances/psql-N
# ---------------------------------------------------------------------------

@dataclass
class DatabaseInfo:
    name:       str
    ip:         str
    pg_port:    int
    agent_port: int
    panel_port: int
    psql_url:   str
    agent_url:  str
    panel_url:  str
    status:     str
    memory_mb:  int
    vcpus:      int
    root_gb:    int
    username:   str = "admin"
    expires_at: str | None = None
    raw:        dict = field(default_factory=dict)


@dataclass
class SnapshotInfo:
    name:       str
    created_at: str | None = None
    size_mb:    float | None = None
    vmstate:    str | None = None
    mem:        str | None = None
    raw:        dict = field(default_factory=dict)


class Database:
    """
    A managed PostgreSQL database backed by a Firecracker microVM.

    Create:  Database.create("psql-1", password="...")
    Attach:  Database.get("psql-1")
    List:    Database.list()
    """

    def __init__(self, info: DatabaseInfo, base_url: str | None = None,
                 api_key: str | None = None):
        self._info    = info
        self._base    = _resolve_base_url(base_url)
        self._api_key = _resolve_api_key(api_key)

    # -- Factory --

    @classmethod
    def create(
        cls,
        label:         str,
        password:      str | None = None,
        schema_prompt: str = "",
        ttl_hours:     int = 0,
        wait_timeout:  int = 120,
        base_url:      str | None = None,
        api_key:       str | None = None,
    ) -> "Database":
        """Provision a new Postgres 17 database VM.

        Resources (vCPU, RAM, disk) are determined by your plan tier.
        Use the dashboard or API to upgrade your plan.
        """
        payload: dict[str, Any] = {"label": label}
        if password:
            payload["password"] = password
        if schema_prompt:
            payload["schema_prompt"] = schema_prompt
        if ttl_hours:
            payload["ttl_hours"] = ttl_hours
        resolved_base_url = _resolve_base_url(base_url)
        key = _resolve_api_key(api_key)
        raw = _req("POST", f"{resolved_base_url}/instances", payload,
                   headers={"Authorization": f"Bearer {key}"} if key else None,
                   timeout=60)
        db = cls(_db_info_from_raw(raw), base_url=resolved_base_url, api_key=key)
        deadline = time.time() + max(wait_timeout, 1)
        while db.info.status == "starting" and time.time() < deadline:
            time.sleep(2)
            db = cls.get(db.name, base_url=resolved_base_url, api_key=key)
        if db.info.status == "starting":
            raise SandflareError(504, f"Database '{db.name}' did not become ready within {wait_timeout}s")
        if db.info.status == "error":
            detail = db.info.raw.get("error", "database failed to start")
            raise SandflareError(502, detail, db.info.raw)
        return db

    @classmethod
    def get(cls, name: str, base_url: str | None = None,
            api_key: str | None = None) -> "Database":
        """Attach to an existing database."""
        resolved_base_url = _resolve_base_url(base_url)
        key = _resolve_api_key(api_key)
        raw = _req("GET", f"{resolved_base_url}/instances/{name}",
                   headers={"Authorization": f"Bearer {key}"} if key else None, timeout=10)
        if raw.get("status") == "absent":
            raise SandflareError(404, f"Database '{name}' not found", raw)
        return cls(_db_info_from_raw(raw), base_url=resolved_base_url, api_key=key)

    @classmethod
    def list(cls, base_url: str | None = None,
             api_key: str | None = None) -> list["Database"]:
        """List all databases."""
        resolved_base_url = _resolve_base_url(base_url)
        key = _resolve_api_key(api_key)
        raw_list = _req("GET", f"{resolved_base_url}/instances",
                        headers={"Authorization": f"Bearer {key}"} if key else None, timeout=10)
        return [cls(_db_info_from_raw(r), base_url=resolved_base_url, api_key=key) for r in raw_list]

    # -- Properties --

    @property
    def name(self) -> str: return self._info.name
    @property
    def info(self) -> DatabaseInfo: return self._info
    @property
    def psql_url(self) -> str: return self._info.psql_url
    @property
    def pg_port(self) -> int: return self._info.pg_port

    # -- Queries --

    def query_nl(self, question: str) -> dict:
        """Ask a natural-language question. Returns {sql, columns, rows, row_count}."""
        try:
            return self._post(f"/instances/{self.name}/ai", {"prompt": question})
        except SandflareError as exc:
            if exc.status not in (400, 404, 405):
                raise
            return self._post(f"/instances/{self.name}/query", {"ask": question})

    def query_sql(self, sql: str) -> dict:
        """Execute raw SQL. Returns {sql, columns, rows, row_count}."""
        return self._post(f"/instances/{self.name}/query", {"sql": sql})

    def schema(self) -> dict:
        """Return the live database schema."""
        return self._get(f"/instances/{self.name}/schema")

    def migrate(self, description: str) -> dict:
        """Apply a natural-language migration (LLM generates DDL and applies it)."""
        return self._post(f"/instances/{self.name}/migrate", {"description": description}, timeout=40)

    # -- Lifecycle --

    def delete(self) -> None:
        """Stop the VM and delete all data."""
        hdrs = {**self._auth_headers(), "User-Agent": "sandflare-sdk/1.0"}
        req = urllib.request.Request(
            f"{self._base}/instances/{self.name}",
            method="DELETE", headers=hdrs,
        )
        try:
            urllib.request.urlopen(req, timeout=30)
        except urllib.error.HTTPError as e:
            if e.code != 404:
                raise

    def create_snapshot(self) -> SnapshotInfo:
        """Create a snapshot of this database VM."""
        r = self._post(f"/instances/{self.name}/snapshot", {})
        return _snapshot_info_from_raw(r)

    def list_snapshots(self) -> list[SnapshotInfo]:
        """List snapshots for this database VM."""
        r = self._get(f"/instances/{self.name}/snapshots")
        if isinstance(r, list):
            return [_snapshot_info_from_raw(item) for item in r]
        return []

    # -- Internals --

    def _auth_headers(self) -> dict:
        return {"Authorization": f"Bearer {self._api_key}"} if self._api_key else {}

    def _get(self, path: str, timeout: int = 10) -> dict:
        return _req("GET", f"{self._base}{path}", headers=self._auth_headers(), timeout=timeout)

    def _post(self, path: str, body: Any, timeout: int = 35) -> dict:
        return _req("POST", f"{self._base}{path}", body,
                    headers=self._auth_headers(), timeout=timeout)


# ---------------------------------------------------------------------------
# Sandbox — wraps /sandboxes/sb-N
# ---------------------------------------------------------------------------

@dataclass
class SandboxInfo:
    name:        str
    ip:          str
    agent_port:  int
    agent_url:   str
    status:      str
    memory_mb:   int
    vcpus:       int
    root_gb:     int
    public_url:  str = ""
    panel_url:   str = ""
    wires:       list[str] = field(default_factory=list)
    preview_url: str | None = None
    preview_port: int | None = None
    subdomain:   str | None = None
    subdomain_url: str | None = None
    template_id: str | None = None
    expires_at:  str | None = None
    ttl_hours:   int = 0
    label:       str = ""
    ephemeral:   bool = False
    size:        str = "nano"
    raw:         dict = field(default_factory=dict)


@dataclass
class StreamEvent:
    """A single SSE event from a streaming exec call."""
    event:     str       = ""
    data:      Any       = field(default_factory=dict)
    type:      str       = ""
    exit_code: int | None = None

    @property
    def line(self) -> str:
        """Convenience: return stdout/stderr line text."""
        if isinstance(self.data, dict):
            return self.data.get("line", "")
        return str(self.data)

    def __str__(self):
        return f"StreamEvent(event={self.event!r}, type={self.type!r}, data={self.data})"


@dataclass
class ProcessInfo:
    pid:            int
    command:        str
    cpu_percent:    float
    memory_percent: float


@dataclass
class SandboxMetrics:
    sandbox_id:   str
    status:       str
    cpu_count:    int
    cpu_used_pct: float
    mem_total:    int
    mem_used:     int
    disk_total:   int
    disk_used:    int
    ts:           int


@dataclass
class GitCloneResult:
    path:   str
    repo:   str
    branch: str | None
    output: str


@dataclass
class TemplateBuildJob:
    id:          str
    name:        str
    status:      str  # pending | building | ready | failed
    description: str = ''
    error:       str = ''
    team_id:     str = ''
    created_at:  str = ''
    updated_at:  str = ''
    logs:        list[str] = field(default_factory=list)


class Sandbox:
    """
    An isolated compute VM for running AI agent code.

    Create:  Sandbox.create("sb-1")
    Attach:  Sandbox.get("sb-1")
    Wire:    sb.wire("psql-1")   # injects DATABASE_URL into the VM

    Agent code inside the sandbox can then:
        import os, psycopg2
        conn = psycopg2.connect(os.environ["DATABASE_URL"])
    """

    def __init__(self, info: SandboxInfo, base_url: str | None = None,
                 api_key: str | None = None):
        self._info    = info
        self._base    = _resolve_base_url(base_url)
        self._api_key = _resolve_api_key(api_key)

    # -- Factory --

    @classmethod
    def create(
        cls,
        label:        str,
        template_id:  str = "",
        size:         str = "nano",
        ttl_hours:    int = 0,
        env:          dict[str, str] | None = None,
        ephemeral:    bool = False,
        base_url:     str | None = None,
        api_key:      str | None = None,
        wait:         bool = True,
        wait_timeout: int = 120,
        # Deprecated aliases kept for backwards-compat (ignored by server)
        template:     str = "",
    ) -> "Sandbox":
        """Provision a new compute sandbox.

        Args:
            label:       Human-readable name for the sandbox.
            template_id: Template to use. One of:
                         ""                 — base Ubuntu (default)
                         "code-interpreter" — Jupyter + pandas + numpy + matplotlib + scipy
            size:        VM size. One of:
                         "nano"   — 1 vCPU, 512 MB  (Free tier max)
                         "small"  — 1 vCPU, 1 GB
                         "medium" — 2 vCPU, 2 GB
                         "large"  — 4 vCPU, 4 GB    (Pro tier max)
                         "xl"     — 4 vCPU, 8 GB    (Teams tier max)
            ttl_hours:   Hard TTL. 0 = use plan default (1h free / 24h pro / unlimited teams).
            env:         Environment variables injected into the sandbox.
            ephemeral:   If True, sandbox auto-deletes when it stops.
        """
        payload: dict[str, Any] = {
            "label": label,
            "size": size,
            "ephemeral": ephemeral,
        }
        if ttl_hours:
            payload["ttl_hours"] = ttl_hours
        effective_template = template_id or template
        if effective_template:
            payload["template_id"] = effective_template
        if env:
            payload["env"] = env
        resolved_base_url = _resolve_base_url(base_url)
        key = _resolve_api_key(api_key)
        raw = _req("POST", f"{resolved_base_url}/sandboxes", payload,
                   headers={"Authorization": f"Bearer {key}"} if key else None,
                   timeout=60)
        sb = cls(_sb_info_from_raw(raw), base_url=resolved_base_url, api_key=key)
        if template_id:
            sb._info.template_id = template_id
        # The API already waits for agent readiness before returning 200.
        # _wait_for_agent is redundant and adds 300-500ms per create.
        if template_id:
            sb._provision_template(template_id)
        return sb

    @classmethod
    def get(cls, name: str, base_url: str | None = None,
            api_key: str | None = None) -> "Sandbox":
        """Attach to an existing sandbox."""
        resolved_base_url = _resolve_base_url(base_url)
        key = _resolve_api_key(api_key)
        raw = _req("GET", f"{resolved_base_url}/sandboxes/{name}",
                   headers={"Authorization": f"Bearer {key}"} if key else None, timeout=10)
        if raw.get("status") == "absent":
            raise SandflareError(404, f"Sandbox '{name}' not found", raw)
        return cls(_sb_info_from_raw(raw), base_url=resolved_base_url, api_key=key)

    @classmethod
    def list(cls, label: str | None = None, base_url: str | None = None,
             api_key: str | None = None) -> list["Sandbox"]:
        """List all sandboxes, optionally filtered by label (case-insensitive substring)."""
        resolved_base_url = _resolve_base_url(base_url)
        key = _resolve_api_key(api_key)
        url = f"{resolved_base_url}/sandboxes"
        if label:
            url += f"?label={label}"
        raw_list = _req("GET", url,
                        headers={"Authorization": f"Bearer {key}"} if key else None, timeout=10)
        return [cls(_sb_info_from_raw(r), base_url=resolved_base_url, api_key=key) for r in raw_list]

    # -- Properties --

    @property
    def name(self) -> str: return self._info.name
    @property
    def info(self) -> SandboxInfo: return self._info
    @property
    def agent_url(self) -> str: return self._info.agent_url
    @property
    def public_url(self) -> str: return self._info.public_url
    @property
    def panel_url(self) -> str: return self._info.panel_url
    @property
    def preview_url(self) -> str | None: return self._info.preview_url
    @property
    def preview_port(self) -> int | None: return self._info.preview_port
    @property
    def subdomain(self) -> str | None: return self._info.subdomain
    @property
    def subdomain_url(self) -> str | None: return self._info.subdomain_url
    @property
    def wires(self) -> list[str]: return self._info.wires

    # -- Wiring --

    def wire(self, database: str) -> None:
        """
        Connect this sandbox to a database.
        Injects DATABASE_URL into /home/user/.env inside the VM so code
        running inside can access it via os.environ or by sourcing the file.
        """
        self._post(f"/sandboxes/{self.name}/wire", {"database": database})
        if database not in self._info.wires:
            self._info.wires.append(database)

    def unwire(self, database: str) -> None:
        """Disconnect this sandbox from a database."""
        req = urllib.request.Request(
            f"{self._base}/sandboxes/{self.name}/wire/{database}",
            method="DELETE", headers={**self._auth_headers(), "User-Agent": "sandflare-sdk/1.0"},
        )
        try:
            urllib.request.urlopen(req, timeout=10)
        except urllib.error.HTTPError as e:
            if e.code != 404:
                raise
        if database in self._info.wires:
            self._info.wires.remove(database)

    def list_wires(self) -> list[dict]:
        """List databases connected to this sandbox with connection details."""
        r = self._get(f"/sandboxes/{self.name}/wires")
        # API returns a list directly
        if isinstance(r, list):
            return r
        return r.get("wires", [])

    # -- Code execution --

    def exec(self, cmd: str, timeout: int = 30, cwd: str = "/home/user") -> ExecResult:
        """Run a shell command inside the sandbox."""
        wrapped_cmd = f"bash -lc {shlex.quote(f'cd {shlex.quote(cwd)} && {cmd}')}"
        r = self._post(f"/sandboxes/{self.name}/exec",
                       {"cmd": wrapped_cmd, "timeout": timeout, "cwd": "/home/user"},
                       timeout=timeout + 5)
        return ExecResult(exit_code=r.get("exit_code", -1), stdout=r.get("stdout", ""),
                          stderr=r.get("stderr", ""), ok=r.get("ok", False))

    def run_python(self, code: str, timeout: int = 30) -> ExecResult:
        """Execute Python 3 code inside the sandbox (stateless — each call is isolated)."""
        r = self._post(f"/sandboxes/{self.name}/run/python",
                       {"code": code, "timeout": timeout}, timeout=timeout + 5)
        return ExecResult(exit_code=r.get("exit_code", -1), stdout=r.get("stdout", ""),
                          stderr=r.get("stderr", ""), ok=r.get("ok", False))

    def run_code(self, code: str, context: str = "default", timeout: int = 60) -> CodeResult:
        """Execute Python code in a **stateful** kernel — variables persist across calls.

        This is the enterprise-grade execution method. Unlike run_python(), the kernel
        maintains a shared namespace so ``x = 1`` in one call is visible as ``x`` in the next.

        Args:
            code:    Python source code to execute.
            context: Kernel context ID — use multiple contexts for isolated namespaces.
                     Defaults to "default".
            timeout: Execution timeout in seconds. Defaults to 60.

        Returns:
            CodeResult with text (last expression), stdout, stderr, png (base64 plot), error.

        Example::

            sb.run_code("x = 42")
            result = sb.run_code("x * 2")
            print(result.text)   # "84"

            # Plots are captured automatically
            r = sb.run_code("import matplotlib.pyplot as plt; plt.plot([1,2,3]); plt.show()")
            r.save_png("/tmp/plot.png")
        """
        r = self._post(
            f"/sandboxes/{self.name}/run/kernel",
            {"code": code, "context_id": context, "timeout": timeout},
            timeout=timeout + 10,
        )
        return CodeResult(
            text=r.get("text"),
            stdout=r.get("stdout", ""),
            stderr=r.get("stderr", ""),
            png=r.get("png"),
            html=r.get("html"),
            error=r.get("error"),
            ok=r.get("ok", True),
        )

    def checkpoint(self, label: str = "", context: str = "default") -> str:
        """Serialize the kernel namespace and persist it in the wired Postgres database.

        The sandbox must have a wired database (call ``sb.wire(db)`` first). The kernel
        state (all variables, imports, etc.) is serialized with dill and stored in the
        ``kernel_snapshots`` table of the wired database.

        Args:
            label:   Human-readable label for this checkpoint.
            context: Kernel context ID to checkpoint. Defaults to "default".

        Returns:
            checkpoint_id (str) — use this with ``sb.restore()`` to reload state.

        Raises:
            RuntimeError: If no database is wired or the checkpoint fails.

        Example::

            sb.run_code("import pandas as pd; df = pd.DataFrame({'x': [1,2,3]})")
            ckpt_id = sb.checkpoint("after-data-load")
            # ...later, in a new sandbox:
            sb2.restore(ckpt_id)
            sb2.run_code("df")   # DataFrame is back
        """
        if not self._info.wires:
            raise RuntimeError("No wired database — call sb.wire(db_name) first")

        # 1. Serialize kernel namespace → base64 blob
        r = self._post(f"/sandboxes/{self.name}/kernel/checkpoint",
                       {"context_id": context}, timeout=40)
        data_b64 = r.get("data", "")
        if not data_b64:
            raise RuntimeError("Kernel returned empty checkpoint data")

        # 2. Store in wired Postgres using run_code in an isolated internal context
        import uuid as _uuid
        cp_id = f"ckpt-{_uuid.uuid4().hex[:12]}"
        store_code = f"""
import psycopg2, os
_conn = psycopg2.connect(os.environ["DATABASE_URL"])
_cur = _conn.cursor()
_cur.execute('''CREATE TABLE IF NOT EXISTS kernel_snapshots (
    id          TEXT PRIMARY KEY,
    sandbox_id  TEXT NOT NULL,
    context_id  TEXT NOT NULL DEFAULT 'default',
    label       TEXT NOT NULL DEFAULT '',
    data        TEXT NOT NULL,
    created_at  TIMESTAMPTZ NOT NULL DEFAULT NOW()
)''')
_cur.execute(
    "INSERT INTO kernel_snapshots (id, sandbox_id, context_id, label, data) VALUES (%s, %s, %s, %s, %s)",
    ({cp_id!r}, {self.name!r}, {context!r}, {label!r}, {data_b64!r})
)
_conn.commit()
_cur.close()
_conn.close()
print("stored")
"""
        result = self.run_code(store_code, context="__ckpt_internal__", timeout=30)
        if result.error:
            raise RuntimeError(f"Failed to store checkpoint in Postgres: {result.error}")
        return cp_id

    def restore(self, checkpoint_id: str, context: str = "default") -> None:
        """Restore a previously checkpointed kernel namespace from the wired Postgres database.

        Fetches the serialized state for ``checkpoint_id`` and loads it into the kernel
        for the given ``context``. After this call, all variables from the original session
        are available as if the code had been re-run.

        Args:
            checkpoint_id: ID returned by a previous ``sb.checkpoint()`` call.
            context:       Kernel context to restore into. Defaults to "default".

        Raises:
            ValueError:   If the checkpoint ID is not found in the database.
            RuntimeError: If no database is wired or the restore fails.

        Example::

            sb2 = Sandbox.create("python")
            sb2.wire("memory-db")
            sb2.restore("ckpt-abc123")
            result = sb2.run_code("df.describe()")   # original DataFrame is back
        """
        if not self._info.wires:
            raise RuntimeError("No wired database — call sb.wire(db_name) first")

        # 1. Fetch blob from Postgres using run_code in an isolated internal context
        fetch_code = f"""
import psycopg2, os
_conn = psycopg2.connect(os.environ["DATABASE_URL"])
_cur = _conn.cursor()
_cur.execute("SELECT data FROM kernel_snapshots WHERE id = %s", ({checkpoint_id!r},))
_row = _cur.fetchone()
_conn.close()
print(_row[0] if _row else "")
"""
        fetch_result = self.run_code(fetch_code, context="__ckpt_internal__", timeout=20)
        if fetch_result.error:
            raise RuntimeError(f"Failed to fetch checkpoint from Postgres: {fetch_result.error}")
        data_b64 = (fetch_result.stdout or "").strip()
        if not data_b64:
            raise ValueError(f"Checkpoint {checkpoint_id!r} not found in the wired database")

        # 2. Load the blob into the target kernel
        self._post(f"/sandboxes/{self.name}/kernel/restore",
                   {"context_id": context, "data": data_b64}, timeout=30)


        """Execute Node.js code inside the sandbox."""
        try:
            r = self._post(f"/sandboxes/{self.name}/run/node",
                           {"code": code, "timeout": timeout}, timeout=timeout + 5)
            return ExecResult(exit_code=r.get("exit_code", -1), stdout=r.get("stdout", ""),
                              stderr=r.get("stderr", ""), ok=r.get("ok", False))
        except AgentBoxError as e:
            if e.status != 408:
                raise
            time.sleep(3)
            try:
                r = self._post(f"/sandboxes/{self.name}/run/node",
                               {"code": code, "timeout": timeout}, timeout=timeout + 5)
                return ExecResult(exit_code=r.get("exit_code", -1), stdout=r.get("stdout", ""),
                                  stderr=r.get("stderr", ""), ok=r.get("ok", False))
            except AgentBoxError:
                pass
        script_b64 = base64.b64encode(code.encode("utf-8")).decode("ascii")
        cmd = f"printf %s '{script_b64}' | base64 -d >/tmp/_agentbox_run.js && node /tmp/_agentbox_run.js"
        return self.exec(cmd, timeout=timeout, cwd="/home/user")

    def stream(
        self, cmd: str, timeout: int = 30, cwd: str = "/home/user"
    ) -> "Generator[StreamEvent, None, None]":
        """
        Stream a shell command's output in real-time via SSE.

        Yields :class:`StreamEvent` objects as lines arrive::

            for event in sb.stream("python3 train.py"):
                if event.event in ("stdout", "stderr"):
                    print(event.line, end="", flush=True)
                elif event.event == "done":
                    print(f"\\nexited {event.exit_code}")
        """
        import http.client
        from urllib.parse import quote, urlparse as _up

        qs     = f"cmd={quote(cmd)}&timeout={timeout}&cwd={quote(cwd)}"
        parsed = _up(self._base)
        # Use Connection: close so the server closes after all SSE events are
        # sent; this lets resp.read() return instead of waiting indefinitely.
        conn   = http.client.HTTPConnection(parsed.netloc, timeout=timeout + 20)
        emitted = False
        try:
            conn.request(
                "GET", f"/sandboxes/{self.name}/exec/stream?{qs}",
                headers={
                    **self._auth_headers(),
                    "Accept": "text/event-stream",
                    "Connection": "close",
                },
            )
            resp       = conn.getresponse()
            body       = resp.read().decode("utf-8", errors="replace")
            event_type = "message"
            for line in body.splitlines():
                line = line.rstrip("\r")
                if line.startswith("event:"):
                    event_type = line[6:].strip()
                elif line.startswith("data:"):
                    data_str = line[5:].strip()
                    try:
                        data = json.loads(data_str)
                    except Exception:
                        data = {"raw": data_str}
                    emitted = True
                    ec = data.get("exit_code") if isinstance(data, dict) else None
                    yield StreamEvent(event=event_type, data=data,
                                      exit_code=ec if event_type == "done" else None)
                    event_type = "message"
        finally:
            conn.close()
        if emitted:
            return
        result = self.exec(cmd, timeout=timeout, cwd=cwd)
        for line in result.stdout.splitlines():
            yield StreamEvent(event="stdout", data={"line": line})
        for line in result.stderr.splitlines():
            yield StreamEvent(event="stderr", data={"line": line})
        yield StreamEvent(event="done", data={"exit_code": result.exit_code, "ok": result.ok},
                          exit_code=result.exit_code)

    def _provision_template(self, template_id: str) -> None:
        _pip = "python3 -m pip install --quiet --prefer-binary --break-system-packages {pkgs}"
        _apk_or_apt = (
            "if command -v apk >/dev/null 2>&1; then apk add --no-cache {apk}; "
            "else apt-get update && DEBIAN_FRONTEND=noninteractive apt-get install -y {apt}; fi"
        )

        if template_id == "code-interpreter":
            self._ensure_packages(
                verify_cmd="python3 -c \"import pandas,numpy,matplotlib,scipy\"",
                install_cmd=_pip.format(pkgs="pandas numpy matplotlib scipy"),
                timeout=600,
                label=template_id,
            )
            return
        if template_id == "sandbox-python":
            self._ensure_packages(
                verify_cmd="python3 -c \"import requests\"",
                install_cmd=_pip.format(pkgs="requests"),
                timeout=300,
                label=template_id,
            )
            return
        if template_id == "sandbox-node":
            self._ensure_packages(
                verify_cmd="command -v node",
                install_cmd=_apk_or_apt.format(apk="nodejs npm", apt="nodejs npm"),
                timeout=300,
                label=template_id,
            )
            return
        if template_id in ("sandbox-full", "coding-agent"):
            self._ensure_packages(
                verify_cmd="command -v git && command -v node",
                install_cmd=_apk_or_apt.format(apk="git nodejs npm", apt="git nodejs npm python3-pip"),
                timeout=300,
                label=template_id,
            )
            if template_id == "coding-agent":
                self._ensure_packages(
                    verify_cmd="python3 -c \"import anthropic,openai\"",
                    install_cmd=_pip.format(pkgs="anthropic openai"),
                    timeout=300,
                    label=template_id,
                )
            return

    def _ensure_packages(self, verify_cmd: str, install_cmd: str, timeout: int, label: str) -> None:
        verify = self._exec_template_verify(verify_cmd, timeout)
        if verify.ok:
            return
        install = self.exec(install_cmd, timeout=timeout)
        if not install.ok:
            raise RuntimeError(
                f"template provisioning failed for {label}: {install.stderr or install.stdout or 'unknown error'}"
            )
        verify = self._exec_template_verify(verify_cmd, timeout)
        if not verify.ok:
            raise RuntimeError(
                f"template provisioning verification failed for {label}: "
                f"{verify.stderr or verify.stdout or 'packages still unavailable'}"
            )

    def _exec_template_verify(self, verify_cmd: str, timeout: int) -> ExecResult:
        last_err: Optional[AgentBoxError] = None
        for attempt in range(15):
            try:
                return self.exec(f"{verify_cmd} >/dev/null 2>&1", timeout=timeout)
            except AgentBoxError as exc:
                if exc.status not in (408, 503) or attempt == 14:
                    raise
                last_err = exc
                time.sleep(2)
        if last_err is not None:
            raise last_err
        return self.exec(f"{verify_cmd} >/dev/null 2>&1", timeout=timeout)

    # -- File I/O --

    def write_file(self, path: str, content: str) -> None:
        """Write a text file to the sandbox filesystem."""
        hdrs = {**self._auth_headers(), "Content-Type": "application/octet-stream"}
        url = f"{self._base}/sandboxes/{self.name}/files?path={urllib.parse.quote(path, safe='')}"
        status, _ = _http_request("POST", url, content.encode("utf-8"), hdrs, 15)
        if status >= 400:
            raise SandflareError(status, f"write_file failed (HTTP {status})", {})

    def read_file(self, path: str) -> str:
        """Read a text file from the sandbox filesystem."""
        hdrs = self._auth_headers()
        url = f"{self._base}/sandboxes/{self.name}/files?path={urllib.parse.quote(path, safe='')}"
        status, data = _http_request("GET", url, None, hdrs, 10)
        if status >= 400:
            raise SandflareError(status, f"read_file failed (HTTP {status})", {})
        return data.decode("utf-8", errors="replace")

    def upload(self, src: "str | bytes | os.PathLike", remote_path: str) -> None:
        """
        Upload a file to the sandbox.

        *src* can be:
        - a local file path (``str`` or ``os.PathLike``)
        - raw bytes / ``bytearray``

        Example::

            sb.upload("data.csv", "/home/user/data.csv")
            sb.upload(b"hello", "/home/user/hello.txt")
        """
        if isinstance(src, (bytes, bytearray)):
            raw = bytes(src)
        else:
            with open(src, "rb") as f:
                raw = f.read()
        hdrs = {**self._auth_headers(), "Content-Type": "application/octet-stream"}
        url = f"{self._base}/sandboxes/{self.name}/files?path={urllib.parse.quote(remote_path, safe='')}"
        status, _ = _http_request("POST", url, raw, hdrs, 30)
        if status >= 400:
            raise SandflareError(status, f"upload failed (HTTP {status})", {})

    def download(self, remote_path: str) -> bytes:
        """
        Download a file from the sandbox as raw bytes.

        Example::

            chart_png = sb.download("/home/user/chart.png")
            with open("chart.png", "wb") as f:
                f.write(chart_png)
        """
        hdrs = self._auth_headers()
        url = f"{self._base}/sandboxes/{self.name}/files?path={urllib.parse.quote(remote_path, safe='')}"
        status, data = _http_request("GET", url, None, hdrs, 15)
        if status >= 400:
            raise SandflareError(status, f"download failed (HTTP {status})", {})
        return data

    def ls(self, path: str = "/home/user") -> list[FileEntry]:
        """List directory contents inside the sandbox."""
        hdrs = self._auth_headers()
        url = f"{self._base}/sandboxes/{self.name}/ls?path={urllib.parse.quote(path, safe='')}"
        status, data = _http_request("GET", url, None, hdrs, 10)
        if status == 404:
            return []  # empty directory or not found
        if status >= 400:
            raise SandflareError(status, f"ls failed (HTTP {status})", {})
        try:
            parsed = json.loads(data)
        except Exception:
            return []
        if isinstance(parsed, list):
            # envd returns flat array: [{name, path, type}]
            return [FileEntry(
                name=e.get("name", ""),
                path=e.get("path", ""),
                is_dir=e.get("type") in ("dir", "directory"),
                size=int(e.get("size", 0)),
                mtime=int(e.get("mtime", 0)),
            ) for e in parsed]
        # Wrapped format: {"entries": [...]}
        return [FileEntry(
            name=e.get("name", ""),
            path=e.get("path", ""),
            is_dir=e.get("is_dir", False) or e.get("type") in ("dir", "directory"),
            size=int(e.get("size", 0)),
            mtime=int(e.get("mtime", 0)),
        ) for e in parsed.get("entries", [])]

    # -- Package management --

    def install(self, pkg: str, runtime: str = "apt") -> ExecResult:
        """Install a package. runtime: 'apt' | 'pip' | 'npm'"""
        r = self._post(f"/sandboxes/{self.name}/install",
                       {"pkg": pkg, "runtime": runtime}, timeout=200)
        return ExecResult(exit_code=r.get("exit_code", 0 if r.get("ok") else 1),
                          stdout=r.get("stdout", ""), stderr=r.get("stderr", ""),
                          ok=r.get("ok", False))

    # -- Lifecycle --

    def health(self) -> dict:
        """Check the guest agent health."""
        return self._get(f"/sandboxes/{self.name}/health", timeout=5)

    def delete(self) -> None:
        """Stop the VM and delete all data."""
        hdrs = {**self._auth_headers(), "User-Agent": "sandflare-sdk/1.0"}
        req = urllib.request.Request(
            f"{self._base}/sandboxes/{self.name}",
            method="DELETE", headers=hdrs,
        )
        try:
            urllib.request.urlopen(req, timeout=30)
        except urllib.error.HTTPError as e:
            if e.code != 404:
                raise

    def pause(self) -> None:
        """Suspend the sandbox VM (CPU + memory frozen, billed at reduced rate)."""
        self._post(f"/sandboxes/{self.name}/pause", {})

    def resume(self) -> None:
        """Resume a previously paused sandbox VM."""
        self._post(f"/sandboxes/{self.name}/resume", {})

    def get_env(self) -> dict[str, str]:
        """Return current environment variables inside the sandbox."""
        return self._get(f"/sandboxes/{self.name}/agent/env")  # type: ignore[return-value]

    def set_env(self, vars: dict[str, str]) -> None:
        """Set environment variables inside the running sandbox."""
        self._post(f"/sandboxes/{self.name}/agent/env", vars)

    def create_snapshot(self) -> SnapshotInfo:
        """Create a snapshot of this sandbox."""
        r = self._post(f"/sandboxes/{self.name}/snapshot", {})
        return _snapshot_info_from_raw(r)

    def list_snapshots(self) -> list[SnapshotInfo]:
        """List snapshots for this sandbox."""
        r = self._get(f"/sandboxes/{self.name}/snapshots")
        if isinstance(r, list):
            return [_snapshot_info_from_raw(item) for item in r]
        return []

    # -- Internals --

    def _wait_for_agent(self, timeout: int = 120) -> None:
        deadline = time.time() + timeout
        last_err = None
        interval = 0.5  # start with 500ms, backoff up to 2s
        while time.time() < deadline:
            try:
                self.health()
                return
            except Exception as e:
                last_err = e
                time.sleep(interval)
                interval = min(interval * 1.5, 2.0)
        raise TimeoutError(f"Agent not reachable after {timeout}s for {self.name}: {last_err}")

    def _auth_headers(self) -> dict:
        return {"Authorization": f"Bearer {self._api_key}"} if self._api_key else {}

    def _get(self, path: str, timeout: int = 10) -> dict:
        return _req("GET", f"{self._base}{path}", headers=self._auth_headers(), timeout=timeout)

    def _post(self, path: str, body: Any, timeout: int = 35) -> dict:
        return _req("POST", f"{self._base}{path}", body,
                    headers=self._auth_headers(), timeout=timeout)

    def _delete(self, path: str, timeout: int = 10) -> dict:
        url = f"{self._base}{path}"
        req = urllib.request.Request(url, method="DELETE", headers=self._auth_headers())
        try:
            with urllib.request.urlopen(req, timeout=timeout) as resp:
                try:
                    return json.loads(resp.read())
                except Exception:
                    return {}
        except urllib.error.HTTPError as e:
            body = {}
            try:
                body = json.loads(e.read())
            except Exception:
                pass
            raise SandflareError(e.code, body.get("error", e.reason), body) from e

    # -- Metrics & process management --

    def metrics(self) -> SandboxMetrics:
        """Return live CPU, memory, and disk metrics for this sandbox."""
        raw = self._get(f"/sandboxes/{self._info.name}/metrics")
        return SandboxMetrics(
            sandbox_id=str(raw.get("sandbox_id", self._info.name)),
            status=str(raw.get("status", "")),
            cpu_count=int(raw.get("cpu_count", 0)),
            cpu_used_pct=float(raw.get("cpu_used_pct", 0)),
            mem_total=int(raw.get("mem_total", 0)),
            mem_used=int(raw.get("mem_used", 0)),
            disk_total=int(raw.get("disk_total", 0)),
            disk_used=int(raw.get("disk_used", 0)),
            ts=int(raw.get("ts", 0)),
        )

    def kill_process(self, pid: int) -> None:
        """Send SIGKILL to a process inside the sandbox by PID."""
        self._delete(f"/sandboxes/{self._info.name}/processes/{pid}")

    def git_clone(
        self,
        repo: str,
        path: str | None = None,
        branch: str | None = None,
        depth: int = 1,
        token: str | None = None,
        ssh_key: str | None = None,
    ) -> GitCloneResult:
        """Clone a git repository into the sandbox."""
        body: dict[str, Any] = {"repo": repo, "depth": depth}
        if path:    body["path"] = path
        if branch:  body["branch"] = branch
        if token:   body["token"] = token
        if ssh_key: body["ssh_key"] = ssh_key
        raw = self._post(f"/sandboxes/{self._info.name}/git/clone", body, timeout=300)
        return GitCloneResult(
            path=str(raw.get("path", "")),
            repo=str(raw.get("repo", repo)),
            branch=raw.get("branch"),
            output=str(raw.get("output", "")),
        )

    def exec_stream(self, cmd: str, timeout: int = 300) -> Generator[StreamEvent, None, None]:
        """Execute a command and yield StreamEvent objects for each stdout/stderr line."""
        import urllib.parse
        qs  = urllib.parse.urlencode({"cmd": cmd, "timeout": str(timeout)})
        url = f"{self._base}/sandboxes/{self._info.name}/exec/stream?{qs}"
        req = urllib.request.Request(url, headers=self._auth_headers())

        try:
            with urllib.request.urlopen(req, timeout=timeout + 5) as resp:
                buf = b""
                for chunk in iter(lambda: resp.read(1), b""):
                    buf += chunk
                    if b"\n\n" in buf:
                        parts = buf.split(b"\n\n")
                        buf   = parts[-1]
                        for part in parts[:-1]:
                            event_type = "stdout"
                            data       = ""
                            for line in part.decode("utf-8", errors="replace").splitlines():
                                if line.startswith("event:"):
                                    event_type = line[6:].strip()
                                elif line.startswith("data:"):
                                    data = line[5:].strip()
                            if event_type == "done":
                                exit_code = 0
                                try:
                                    import json as _json
                                    exit_code = _json.loads(data).get("exit_code", 0)
                                except Exception:
                                    pass
                                yield StreamEvent(type="done", data="", exit_code=exit_code)
                                return
                            if data:
                                yield StreamEvent(type=event_type, data=data)
        except urllib.error.URLError as e:
            raise SandflareError(0, str(e), {}) from e


# ---------------------------------------------------------------------------
# Template
# ---------------------------------------------------------------------------

class Template:
    """Manage custom Sandflare sandbox templates built from Dockerfiles."""

    def __init__(
        self,
        base_url: str | None = None,
        api_key:  str | None = None,
    ) -> None:
        self._base_url = _resolve_base_url(base_url)
        self._api_key  = _resolve_api_key(api_key)

    @classmethod
    def build(
        cls,
        name:        str,
        dockerfile:  str,
        *,
        description: str = "",
        team_id:     str = "",
        base_url:    str | None = None,
        api_key:     str | None = None,
    ) -> TemplateBuildJob:
        """Submit a Dockerfile to build a custom template. Returns immediately with build job."""
        t = cls(base_url=base_url, api_key=api_key)
        body: dict[str, Any] = {"name": name, "dockerfile": dockerfile}
        if description: body["description"] = description
        if team_id:     body["team_id"]     = team_id
        raw = t._post("/templates/build", body)
        return t._parse_job(raw)

    @classmethod
    def get_build_status(
        cls,
        template_id: str,
        base_url:    str | None = None,
        api_key:     str | None = None,
    ) -> TemplateBuildJob:
        t = cls(base_url=base_url, api_key=api_key)
        raw = t._get(f"/templates/{template_id}/build-status")
        return t._parse_job(raw)

    @classmethod
    def list(
        cls,
        team_id:  str | None = None,
        base_url: str | None = None,
        api_key:  str | None = None,
    ) -> list[TemplateBuildJob]:
        t  = cls(base_url=base_url, api_key=api_key)
        qs = f"?team_id={team_id}" if team_id else ""
        raw = t._get(f"/templates{qs}")
        return [t._parse_job(j) for j in raw.get("templates", [])]

    @classmethod
    def wait_for_build(
        cls,
        template_id:      str,
        timeout_seconds:  int   = 1800,
        poll_interval:    float = 3.0,
        base_url:         str | None = None,
        api_key:          str | None = None,
    ) -> TemplateBuildJob:
        """Poll until template build is ready or failed. Default timeout: 30 minutes."""
        deadline = time.time() + timeout_seconds
        while time.time() < deadline:
            job = cls.get_build_status(template_id, base_url=base_url, api_key=api_key)
            if job.status == "ready":
                return job
            if job.status == "failed":
                raise SandflareError(500, f"Template build failed: {job.error}", {})
            time.sleep(poll_interval)
        raise SandflareError(408, f"Template build timed out after {timeout_seconds}s", {})

    @classmethod
    def delete(
        cls,
        template_id: str,
        base_url:    str | None = None,
        api_key:     str | None = None,
    ) -> None:
        t = cls(base_url=base_url, api_key=api_key)
        t._delete(f"/templates/{template_id}")

    def _parse_job(self, raw: dict) -> TemplateBuildJob:
        return TemplateBuildJob(
            id=str(raw.get("id", "")),
            name=str(raw.get("name", "")),
            status=str(raw.get("status", "")),
            description=str(raw.get("description", "")),
            error=str(raw.get("error", "")),
            team_id=str(raw.get("team_id", "")),
            created_at=str(raw.get("created_at", "")),
            updated_at=str(raw.get("updated_at", "")),
            logs=raw.get("logs") or [],
        )

    def _auth_headers(self) -> dict:
        return {"X-API-Key": self._api_key, "Content-Type": "application/json"}

    def _get(self, path: str, timeout: int = 30) -> dict:
        url = f"{self._base_url}{path}"
        req = urllib.request.Request(url, headers={"X-API-Key": self._api_key})
        try:
            with urllib.request.urlopen(req, timeout=timeout) as resp:
                return json.loads(resp.read())
        except urllib.error.HTTPError as e:
            body = {}
            try: body = json.loads(e.read())
            except Exception: pass
            raise SandflareError(e.code, body.get("error", e.reason), body) from e

    def _post(self, path: str, body: Any, timeout: int = 60) -> dict:
        url  = f"{self._base_url}{path}"
        data = json.dumps(body).encode()
        req  = urllib.request.Request(url, data=data, headers=self._auth_headers(), method="POST")
        try:
            with urllib.request.urlopen(req, timeout=timeout) as resp:
                return json.loads(resp.read())
        except urllib.error.HTTPError as e:
            b = {}
            try: b = json.loads(e.read())
            except Exception: pass
            raise SandflareError(e.code, b.get("error", e.reason), b) from e

    def _delete(self, path: str, timeout: int = 30) -> dict:
        url = f"{self._base_url}{path}"
        req = urllib.request.Request(url, method="DELETE", headers={"X-API-Key": self._api_key})
        try:
            with urllib.request.urlopen(req, timeout=timeout) as resp:
                try: return json.loads(resp.read())
                except Exception: return {}
        except urllib.error.HTTPError as e:
            b = {}
            try: b = json.loads(e.read())
            except Exception: pass
            raise SandflareError(e.code, b.get("error", e.reason), b) from e

def _db_info_from_raw(raw: dict) -> DatabaseInfo:
    return DatabaseInfo(
        name=raw.get("name", ""),
        ip=raw.get("ip", ""),
        pg_port=raw.get("pg_port", 0),
        agent_port=raw.get("agent_port", 0),
        panel_port=raw.get("panel_port", 0),
        psql_url=raw.get("psql_url") or raw.get("conn_string", ""),
        agent_url=raw.get("agent_url", ""),
        panel_url=raw.get("panel_url", ""),
        status=raw.get("status", "unknown"),
        memory_mb=raw.get("memory_mb", 0),
        vcpus=raw.get("vcpus", 0),
        root_gb=raw.get("root_gb", 0),
        username=raw.get("username", "admin"),
        expires_at=raw.get("expires_at"),
        raw=raw,
    )


def _sb_info_from_raw(raw: dict) -> SandboxInfo:
    return SandboxInfo(
        name=raw.get("name", ""),
        ip=raw.get("ip", ""),
        agent_port=raw.get("agent_port", 0),
        agent_url=raw.get("agent_url", ""),
        public_url=raw.get("public_url", ""),
        panel_url=raw.get("panel_url", raw.get("subdomain_url", "")),
        preview_url=raw.get("preview_url"),
        preview_port=int(raw["preview_port"]) if raw.get("preview_port") is not None else None,
        subdomain=raw.get("subdomain"),
        subdomain_url=raw.get("subdomain_url"),
        status=raw.get("status", "unknown"),
        memory_mb=raw.get("memory_mb", 0),
        vcpus=raw.get("vcpus", 0),
        root_gb=raw.get("root_gb", 0),
        wires=raw.get("wires", []),
        template_id=raw.get("template") or raw.get("template_id"),
        expires_at=raw.get("expires_at"),
        ttl_hours=int(raw.get("ttl_hours", 0)),
        label=raw.get("label", ""),
        ephemeral=bool(raw.get("ephemeral", False)),
        size=raw.get("size", "nano"),
        raw=raw,
    )


def _snapshot_info_from_raw(raw: dict) -> SnapshotInfo:
    return SnapshotInfo(
        name=raw.get("name", ""),
        created_at=raw.get("created_at"),
        size_mb=raw.get("size_mb"),
        vmstate=raw.get("vmstate"),
        mem=raw.get("mem"),
        raw=raw,
    )
