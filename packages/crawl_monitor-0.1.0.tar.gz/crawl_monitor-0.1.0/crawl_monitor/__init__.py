from .stats     import CrawlStats
from .reporter  import Reporter
from .scheduler import CrawlScheduler
from typing import Optional

__version__ = '0.1.0'
__all__     = ['CrawlStats', 'Reporter', 'CrawlScheduler', 'create_monitor']


def create_monitor(
    job_name:        str,
    notify_urls:     list[str],
    accounts_total:  int = 0,
    interval_sec:    Optional[int] = 300,
    error_threshold: int = 20,
    cooldown_sec:    int = 120,
    daily_report_times: Optional[list[str]] = None,
    stocks_total: Optional[int] = None,
) -> tuple[CrawlStats, CrawlScheduler]:
    """
    一行代码完成初始化，返回 (stats, scheduler) 元组。

    用法：
        stats, scheduler = create_monitor(
            job_name       = 'media_crawler',
            notify_urls    = ['wecombot://你的Key'],
            accounts_total = len(account_ids),
            interval_sec   = 0,
            daily_report_times=['09:00'],
        )
        scheduler.start()
        # ... 采集逻辑中调用 stats.inc_* ...
        scheduler.stop()
    """
    # 兼容旧参数名（deprecated）
    if stocks_total is not None:
        if accounts_total and accounts_total != stocks_total:
            raise ValueError('accounts_total 与 stocks_total 不能同时设置不同值')
        accounts_total = stocks_total

    stats     = CrawlStats(job_name=job_name, accounts_total=accounts_total)
    reporter  = Reporter(notify_urls=notify_urls)
    scheduler = CrawlScheduler(
        stats           = stats,
        reporter        = reporter,
        interval_sec    = interval_sec,
        error_threshold = error_threshold,
        cooldown_sec    = cooldown_sec,
        daily_report_times=daily_report_times,
    )
    return stats, scheduler
