import time
import threading
from datetime import date, datetime, timedelta
from typing import Optional, TYPE_CHECKING

if TYPE_CHECKING:
    from .stats import CrawlStats
    from .reporter import Reporter


class CrawlScheduler:
    """
    后台调度线程，负责：
    1. 每隔 interval_sec 秒自动读取 stats 快照并推送进度报告
    2. 每次触发时检查错误数，超阈值则推送告警（带冷却）
    3. stop() 时推送最终完成报告
    """

    def __init__(
        self,
        stats:           'CrawlStats',
        reporter:        'Reporter',
        interval_sec:    Optional[int] = 300,
        error_threshold: int = 20,
        cooldown_sec:    int = 120,
        daily_report_times: Optional[list[str]] = None,
        alert_check_sec: int = 5,
    ):
        self._stats           = stats
        self._reporter        = reporter
        self._interval_sec    = max(0, int(interval_sec or 0))
        self._error_threshold = error_threshold
        self._cooldown_sec    = cooldown_sec
        self._daily_report_minutes = self._parse_daily_report_times(daily_report_times)
        self._daily_report_sent_dates: dict[int, date] = {}
        self._alert_check_sec = max(1, int(alert_check_sec))

        self._start_time      = 0.0
        self._last_alert_time = 0.0
        self._last_error_snap = 0
        self._next_interval_ts = 0.0
        self._next_alert_check_ts = 0.0
        self._stop_event      = threading.Event()
        self._thread          = threading.Thread(target=self._run, daemon=True, name='CrawlMonitor')

    def start(self, extra: Optional[dict] = None):
        self._start_time = time.time()
        self._next_interval_ts = (
            self._start_time + self._interval_sec
            if self._interval_sec > 0 else float('inf')
        )
        self._next_alert_check_ts = self._start_time + self._alert_check_sec
        self._thread.start()
        snap = self._stats.snapshot()
        start_extra = dict(extra) if extra else {}
        if self._daily_report_minutes:
            daily_times = ', '.join(
                f'{minute // 60:02d}:{minute % 60:02d}'
                for minute in self._daily_report_minutes
            )
            start_extra['daily_report_times'] = daily_times
        self._reporter.send_start(snap, self._interval_sec, extra=start_extra or None)

    def stop(self, extra: Optional[dict] = None):
        """停止调度并推送最终报告，建议放在 finally 块中"""
        self._stop_event.set()
        elapsed = time.time() - self._start_time
        snap    = self._stats.snapshot()
        self._reporter.send_finish(snap, elapsed, extra=extra)

    def _elapsed(self) -> float:
        return time.time() - self._start_time

    def _run(self):
        while not self._stop_event.is_set():
            now = time.time()
            should_send_progress = False
            label = '定时进度'

            if self._interval_sec > 0 and now >= self._next_interval_ts:
                should_send_progress = True
                while self._next_interval_ts <= now:
                    self._next_interval_ts += self._interval_sec

            daily_label = self._daily_report_label_if_due()
            if daily_label:
                should_send_progress = True
                label = daily_label

            snap: Optional[dict] = None
            if should_send_progress:
                snap = self._stats.snapshot()
                self._reporter.send_progress(snap, self._elapsed(), label=label)
                self._check_alert(snap)
                self._next_alert_check_ts = now + self._alert_check_sec
            elif now >= self._next_alert_check_ts:
                snap = self._stats.snapshot()
                self._check_alert(snap)
                self._next_alert_check_ts = now + self._alert_check_sec

            wait_sec = self._next_wait_seconds()
            if self._stop_event.wait(timeout=wait_sec):
                break

    def _check_alert(self, snap: dict):
        new_errors = snap['errors_total'] - self._last_error_snap
        now        = time.time()
        if (new_errors >= self._error_threshold and
                now - self._last_alert_time > self._cooldown_sec):
            self._reporter.send_error_alert(snap, self._elapsed())
            self._last_alert_time = now
            self._last_error_snap = snap['errors_total']

    def _daily_report_label_if_due(self) -> Optional[str]:
        if not self._daily_report_minutes:
            return None

        now = datetime.now()
        minute_of_day = now.hour * 60 + now.minute
        if minute_of_day not in self._daily_report_minutes:
            return None

        if self._daily_report_sent_dates.get(minute_of_day) == now.date():
            return None

        self._daily_report_sent_dates[minute_of_day] = now.date()
        return f'每日{now.hour:02d}:{now.minute:02d}进度'

    def _next_wait_seconds(self) -> float:
        now_ts = time.time()
        waits = [10.0]  # 防止睡眠过长错过整分钟时点

        if self._interval_sec > 0:
            waits.append(max(0.0, self._next_interval_ts - now_ts))

        waits.append(max(0.0, self._next_alert_check_ts - now_ts))

        if self._daily_report_minutes:
            waits.append(self._seconds_to_next_daily_time())

        return max(0.2, min(waits))

    def _seconds_to_next_daily_time(self) -> float:
        now = datetime.now()
        nearest = None
        for minute in self._daily_report_minutes:
            hour = minute // 60
            minute_in_hour = minute % 60
            target = now.replace(hour=hour, minute=minute_in_hour, second=0, microsecond=0)
            if target <= now:
                target += timedelta(days=1)
            delta = (target - now).total_seconds()
            if nearest is None or delta < nearest:
                nearest = delta
        return nearest if nearest is not None else 10.0

    @staticmethod
    def _parse_daily_report_times(daily_report_times: Optional[list[str]]) -> list[int]:
        if not daily_report_times:
            return []

        if isinstance(daily_report_times, str):
            daily_report_times = [daily_report_times]

        minutes: set[int] = set()
        for raw in daily_report_times:
            text = str(raw).strip()
            if ':' not in text:
                raise ValueError(f'非法时间格式: {raw}，请使用 HH:MM')
            hh_str, mm_str = text.split(':', 1)
            if (not hh_str.isdigit()) or (not mm_str.isdigit()):
                raise ValueError(f'非法时间格式: {raw}，请使用 HH:MM')
            hour = int(hh_str)
            minute = int(mm_str)
            if hour < 0 or hour > 23 or minute < 0 or minute > 59:
                raise ValueError(f'非法时间值: {raw}，小时范围 0-23，分钟范围 0-59')
            minutes.add(hour * 60 + minute)
        return sorted(minutes)
