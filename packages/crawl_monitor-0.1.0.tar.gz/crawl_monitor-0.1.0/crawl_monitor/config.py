# 所有默认值集中管理，用户可在初始化时覆盖

DEFAULT_INTERVAL_SEC    = 300   # 定时推送间隔（秒）
DEFAULT_ERROR_THRESHOLD = 20    # 触发告警的累计错误数
DEFAULT_COOLDOWN_SEC    = 120   # 告警冷却时间（秒，防刷屏）
DEFAULT_DAILY_REPORT_TIMES = None  # 每日定点推送时刻，如 ['09:00']
