import time
import apprise as _apprise_lib
from typing import Optional


def _progress_bar(pct: float, width: int = 20) -> str:
    filled = int(pct / 100 * width)
    return '█' * filled + '░' * (width - filled)


def _rate_color(rate: float) -> str:
    if rate >= 99:
        return f'<font color="info">{rate:.1f}%</font>'
    if rate >= 95:
        return f'<font color="warning">{rate:.1f}%</font>'
    return f'<font color="comment">{rate:.1f}%</font>'


def _pick(snap: dict, new_key: str, old_key: str, default=0):
    """优先读取新字段，兼容旧字段."""
    return snap.get(new_key, snap.get(old_key, default))


class Reporter:
    """
    封装 Apprise 推送，提供格式化报告方法。
    notify_urls: Apprise URL 列表，如 ['wecombot://KEY']
    """

    def __init__(self, notify_urls: list[str]):
        self._ap = _apprise_lib.Apprise()
        for url in notify_urls:
            self._ap.add(url)

    def push(
        self,
        title: str,
        body: str,
        notify_type=_apprise_lib.NotifyType.INFO,
    ) -> bool:
        try:
            return self._ap.notify(title=title, body=body, notify_type=notify_type)
        except Exception as e:
            print(f'[CrawlMonitor] 推送失败: {e}')
            return False

    # ── 各类报告 ──────────────────────────────────

    def send_start(self, snap: dict, interval_sec: int, extra: Optional[dict] = None):
        job = snap['job_name']
        accounts_total = _pick(snap, 'accounts_total', 'stocks_total')
        interval = interval_sec // 60 if interval_sec > 0 else 0
        interval_line = (
            f'- 推送间隔：每 **{interval}** 分钟'
            if interval_sec > 0 else
            '- 固定间隔推送：关闭'
        )
        extra_md = ''.join(f'\n- {k}：{v}' for k, v in extra.items()) if extra else ''
        self.push(
            f'【{job}】任务启动',
            f'## {job} 采集任务已启动\n'
            f'> 启动时间：**{time.strftime("%Y-%m-%d %H:%M:%S")}**\n'
            f'- 待处理账号：**{accounts_total}** 个\n'
            f'{interval_line}'
            f'{extra_md}',
        )

    def send_progress(
        self,
        snap: dict,
        elapsed_sec: float,
        label: str = '定时进度',
        extra: Optional[dict] = None,
    ):
        job = snap['job_name']
        accounts_total = _pick(snap, 'accounts_total', 'stocks_total')
        accounts_completed = _pick(snap, 'accounts_completed', 'stocks_completed')
        records_fetched = _pick(snap, 'records_fetched', 'notices_fetched')
        records_inserted = _pick(snap, 'records_inserted', 'notices_inserted')
        records_skipped = _pick(snap, 'records_skipped', 'notices_skipped')
        elapsed_str = time.strftime('%H:%M:%S', time.gmtime(elapsed_sec))
        extra_md = (
            '\n### 自定义指标' + ''.join(f'\n- {k}：{v}' for k, v in extra.items())
        ) if extra else ''

        self.push(
            f'【{job}】{label}报告',
            f'## {job} - {label}报告\n'
            f'> 运行时长：**{elapsed_str}**\n'
            f'### 整体进度\n'
            f'`{_progress_bar(snap["progress_pct"])}` **{snap["progress_pct"]:.1f}%**\n'
            f'- 已完成：**{accounts_completed}** / {accounts_total} 个\n'
            f'- 当前并发：**{snap["in_progress"]}** 线程\n'
            f'### 采集结果\n'
            f'- 采集记录：**{records_fetched:,}** 条\n'
            f'- 写入数据库：**{records_inserted:,}** 条\n'
            f'- 规则过滤：{records_skipped:,} 条\n'
            f'### 请求状态\n'
            f'- HTTP 成功率：{_rate_color(snap["http_success_rate"])}\n'
            f'- 成功 / 失败：{snap["http_ok"]:,} / {snap["http_err"]:,}\n'
            f'- 重试次数：{snap["http_retries"]:,}\n'
            f'- 平均响应：**{snap["avg_http_ms"]:.0f} ms**\n'
            f'### 数据库\n'
            f'- 写入成功 / 失败：{snap["db_ok"]} / {snap["db_err"]}\n'
            f'- 平均写入耗时：{snap["avg_db_ms"]:.0f} ms'
            f'{extra_md}',
        )

    def send_finish(self, snap: dict, elapsed_sec: float, extra: Optional[dict] = None):
        job = snap['job_name']
        accounts_completed = _pick(snap, 'accounts_completed', 'stocks_completed')
        records_fetched = _pick(snap, 'records_fetched', 'notices_fetched')
        records_inserted = _pick(snap, 'records_inserted', 'notices_inserted')
        elapsed_str = time.strftime('%H:%M:%S', time.gmtime(elapsed_sec))
        avg_per = elapsed_sec / max(accounts_completed, 1)
        extra_md = (
            '\n### 自定义指标' + ''.join(f'\n- {k}：{v}' for k, v in extra.items())
        ) if extra else ''

        self.push(
            f'【{job}】任务完成 ✅',
            f'## {job} - 任务完成\n'
            f'> 总耗时：**{elapsed_str}**\n'
            f'- 处理账号：**{accounts_completed}** 个\n'
            f'- 总采集记录：**{records_fetched:,}** 条\n'
            f'- 总写入数据库：**{records_inserted:,}** 条\n'
            f'- 平均每个账号耗时：**{avg_per:.1f} s**\n'
            f'- 累计 HTTP 错误：{snap["http_err"]}\n'
            f'- 累计重试：{snap["http_retries"]}'
            f'{extra_md}',
            notify_type=_apprise_lib.NotifyType.SUCCESS,
        )

    def send_error_alert(
        self,
        snap: dict,
        elapsed_sec: float,
        detail: Optional[str] = None,
    ):
        job = snap['job_name']
        accounts_total = _pick(snap, 'accounts_total', 'stocks_total')
        accounts_completed = _pick(snap, 'accounts_completed', 'stocks_completed')
        elapsed_str = time.strftime('%H:%M:%S', time.gmtime(elapsed_sec))
        detail_md = f'\n- 详情：{detail}' if detail else ''
        self.push(
            f'🚨 【{job}】错误告警',
            f'## ⚠️ {job} 采集错误告警\n'
            f'> 运行时长：{elapsed_str}\n'
            f'- 累计错误：<font color="comment">**{snap["errors_total"]}**</font>\n'
            f'- HTTP 失败：{snap["http_err"]}\n'
            f'- 重试次数：{snap["http_retries"]}\n'
            f'- DB 写入失败：{snap["db_err"]}'
            f'{detail_md}\n'
            f'当前进度：{accounts_completed} / {accounts_total}',
            notify_type=_apprise_lib.NotifyType.WARNING,
        )
