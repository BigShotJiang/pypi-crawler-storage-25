import threading
from dataclasses import dataclass, field
from typing import Optional


@dataclass
class CrawlStats:
    """
    线程安全的指标累加器。
    所有 inc_* / dec_* 方法均可在多线程环境中安全调用。
    snapshot() 返回当前指标的不可变快照字典。
    """
    job_name:       str
    accounts_total: int = 0
    # 兼容旧参数名（deprecated）
    stocks_total: Optional[int] = field(default=None, repr=False)

    _lock: threading.Lock = field(default_factory=threading.Lock, repr=False, init=False)

    # ── 内部计数字段 ──────────────────────────────
    _accounts_completed: int   = field(default=0, repr=False, init=False)
    _in_progress:        int   = field(default=0, repr=False, init=False)
    _records_fetched:    int   = field(default=0, repr=False, init=False)
    _records_inserted:   int   = field(default=0, repr=False, init=False)
    _records_skipped:    int   = field(default=0, repr=False, init=False)
    _http_ok:            int   = field(default=0, repr=False, init=False)
    _http_err:           int   = field(default=0, repr=False, init=False)
    _http_retries:       int   = field(default=0, repr=False, init=False)
    _http_ms_sum:        float = field(default=0.0, repr=False, init=False)
    _http_ms_cnt:        int   = field(default=0, repr=False, init=False)
    _db_ok:              int   = field(default=0, repr=False, init=False)
    _db_err:             int   = field(default=0, repr=False, init=False)
    _db_ms_sum:          float = field(default=0.0, repr=False, init=False)
    _db_ms_cnt:          int   = field(default=0, repr=False, init=False)
    _errors_total:       int   = field(default=0, repr=False, init=False)

    def __post_init__(self):
        """处理兼容参数名."""
        if self.stocks_total is not None:
            if self.accounts_total and self.accounts_total != self.stocks_total:
                raise ValueError('accounts_total 与 stocks_total 不能同时设置不同值')
            self.accounts_total = self.stocks_total
        # 保持旧属性可读
        self.stocks_total = self.accounts_total

    # ── 公开累加方法 ──────────────────────────────

    def inc_progress(self):
        """标记一个账号开始处理"""
        with self._lock:
            self._in_progress += 1

    def dec_progress(self):
        """标记一个账号处理完成（无论成功失败）"""
        with self._lock:
            self._in_progress        = max(0, self._in_progress - 1)
            self._accounts_completed += 1

    def inc_records(self, n: int = 1):
        """采集到 n 条记录"""
        with self._lock:
            self._records_fetched += n

    def inc_records_inserted(self, n: int = 1):
        """成功写入数据库 n 条"""
        with self._lock:
            self._records_inserted += n

    def inc_records_skipped(self, n: int = 1):
        """因过滤规则跳过 n 条"""
        with self._lock:
            self._records_skipped += n

    # ---- 兼容旧接口（deprecated） ----

    def inc_notices(self, n: int = 1):
        """兼容旧接口：采集到 n 条公告"""
        self.inc_records(n)

    def inc_inserted(self, n: int = 1):
        """兼容旧接口：成功写入数据库 n 条"""
        self.inc_records_inserted(n)

    def inc_skipped(self, n: int = 1):
        """兼容旧接口：因过滤规则跳过 n 条"""
        self.inc_records_skipped(n)

    def inc_http_ok(self, duration_ms: float = 0.0):
        """记录一次成功的 HTTP 请求及耗时"""
        with self._lock:
            self._http_ok      += 1
            self._http_ms_sum  += duration_ms
            self._http_ms_cnt  += 1

    def inc_http_err(self):
        """记录一次 HTTP 请求失败"""
        with self._lock:
            self._http_err += 1

    def inc_retry(self):
        """记录一次重试"""
        with self._lock:
            self._http_retries += 1

    def inc_db_ok(self, duration_ms: float = 0.0):
        """记录一次成功的数据库写入及耗时"""
        with self._lock:
            self._db_ok       += 1
            self._db_ms_sum   += duration_ms
            self._db_ms_cnt   += 1

    def inc_db_err(self):
        """记录一次数据库写入失败"""
        with self._lock:
            self._db_err += 1

    def inc_error(self):
        """记录一次通用错误（用于告警阈值判断）"""
        with self._lock:
            self._errors_total += 1

    # ── 快照读取 ──────────────────────────────────

    def snapshot(self) -> dict:
        """返回当前所有指标的线程安全快照"""
        with self._lock:
            total      = self.accounts_total or 1
            http_total = (self._http_ok + self._http_err) or 1
            return {
                'job_name':         self.job_name,
                'accounts_total':   self.accounts_total,
                'accounts_completed': self._accounts_completed,
                'in_progress':      self._in_progress,
                'progress_pct':     self._accounts_completed / total * 100,
                'records_fetched':  self._records_fetched,
                'records_inserted': self._records_inserted,
                'records_skipped':  self._records_skipped,
                'http_ok':          self._http_ok,
                'http_err':         self._http_err,
                'http_retries':     self._http_retries,
                'http_success_rate': self._http_ok / http_total * 100,
                'avg_http_ms':      (self._http_ms_sum / self._http_ms_cnt
                                     if self._http_ms_cnt else 0.0),
                'db_ok':            self._db_ok,
                'db_err':           self._db_err,
                'avg_db_ms':        (self._db_ms_sum / self._db_ms_cnt
                                     if self._db_ms_cnt else 0.0),
                'errors_total':     self._errors_total,
                # 兼容旧字段名（deprecated）
                'stocks_total':     self.accounts_total,
                'stocks_completed': self._accounts_completed,
                'notices_fetched':  self._records_fetched,
                'notices_inserted': self._records_inserted,
                'notices_skipped':  self._records_skipped,
            }
