﻿# crawl-monitor

轻量级采集程序监控推送库。在采集程序中埋入几行代码，即可将运行进度、采集统计、错误告警自动推送至企业微信（或任意 Apprise 支持的渠道），无需部署任何外部服务。适用于公众号文章、微博用户、资讯站点等媒体数据采集任务。

## 特性

- **零部署**：纯本地库，`pip install` 后直接 `import`，无需 Prometheus、Grafana 等外部依赖
- **线程安全**：所有指标累加操作均加锁，天然支持多线程采集程序
- **三类推送**：任务启动通知、进度报告（固定间隔或每日定点）、错误阈值告警，任务结束后自动推送最终汇总
- **多渠道**：基于 [Apprise](https://github.com/caronc/apprise) 推送，支持企业微信、钉钉、飞书、Telegram、邮件等 100+ 渠道
- **防刷屏**：错误告警内置冷却机制，同一任务短时间内不会重复告警
- **优雅退出**：`scheduler.stop()` 建议放在 `finally` 块，确保程序异常崩溃时也能推送最终报告

---

## 安装

```bash
pip install crawl-monitor
```

Python 版本要求：**>= 3.10**

---

## 快速开始

```python
from crawl_monitor import create_monitor

stats, scheduler = create_monitor(
    job_name     = 'my_crawler',
    notify_urls  = ['wecombot://你的企业微信机器人Key'],
    accounts_total = 5000,
)

scheduler.start()
try:
    for account_id in account_ids:
        stats.inc_progress()
        try:
            # ... 你的采集逻辑 ...
            stats.inc_records(10)
            stats.inc_http_ok(duration_ms=320.5)
        except Exception:
            stats.inc_error()
        finally:
            stats.dec_progress()
finally:
    scheduler.stop()
```

---

## API 文档

### `create_monitor()` — 一行完成初始化

```python
from crawl_monitor import create_monitor

stats, scheduler = create_monitor(
    job_name        = 'media_crawler',   # 任务名称，显示在推送标题中
    notify_urls     = ['wecombot://KEY'],# Apprise 推送 URL 列表，支持多个
    accounts_total  = len(account_ids),  # 本次任务总量（用于计算进度百分比）
    interval_sec    = 300,               # 定时推送间隔，单位秒，默认 300（5 分钟）
    daily_report_times = ['09:00'],      # 每日定点推送时刻（可选）
    error_threshold = 20,               # 触发错误告警的累计错误次数，默认 20
    cooldown_sec    = 120,              # 错误告警冷却时间，单位秒，默认 120
)
```

返回 `(CrawlStats, CrawlScheduler)` 元组。

说明：
- `interval_sec=0` 或 `interval_sec=None` 时，关闭固定间隔推送。
- `daily_report_times=['09:00']` 可实现“仅每天 09:00 推送一次进度”。
- `daily_report_times` 支持多个时点，如 `['09:00', '12:30', '18:00']`。

---

### `CrawlStats` — 指标累加器

在采集逻辑中调用对应方法记录指标，所有方法均线程安全。

#### 进度跟踪

| 方法 | 说明 |
|---|---|
| `inc_progress()` | 标记一个任务单元开始处理（并发数 +1） |
| `dec_progress()` | 标记一个任务单元处理完成，无论成功与否（并发数 -1，已完成数 +1） |

`dec_progress()` 建议始终放在 `finally` 块中调用，确保并发计数不泄漏。

#### 采集量统计

| 方法 | 参数 | 说明 |
|---|---|---|
| `inc_records(n=1)` | `n`: 条数 | 记录采集到的数据条数 |
| `inc_records_inserted(n=1)` | `n`: 条数 | 记录实际写入数据库的条数 |
| `inc_records_skipped(n=1)` | `n`: 条数 | 记录因过滤条件跳过的条数 |

#### HTTP 请求

| 方法 | 参数 | 说明 |
|---|---|---|
| `inc_http_ok(duration_ms=0.0)` | `duration_ms`: 耗时（毫秒） | 记录一次成功请求 |
| `inc_http_err()` | — | 记录一次请求失败 |
| `inc_retry()` | — | 记录一次重试 |

#### 数据库写入

| 方法 | 参数 | 说明 |
|---|---|---|
| `inc_db_ok(duration_ms=0.0)` | `duration_ms`: 耗时（毫秒） | 记录一次成功写入 |
| `inc_db_err()` | — | 记录一次写入失败 |

#### 错误计数

| 方法 | 说明 |
|---|---|
| `inc_error()` | 记录一次通用错误，用于触发告警阈值判断 |

#### 读取快照

```python
snap = stats.snapshot()
# 返回包含所有当前指标的字典，可自行使用
print(snap['progress_pct'])    # 完成百分比（float）
print(snap['records_fetched']) # 累计采集条数
print(snap['http_success_rate']) # HTTP 成功率（float，百分比）
```

`snapshot()` 快照字段完整列表：

```python
{
    'job_name':          str,    # 任务名
    'accounts_total':      int,    # 总任务量
    'accounts_completed':  int,    # 已完成数
    'in_progress':       int,    # 当前并发数
    'progress_pct':      float,  # 完成百分比 0~100
    'records_fetched':   int,    # 累计采集条数
    'records_inserted':  int,    # 累计写入条数
    'records_skipped':   int,    # 累计跳过条数
    'http_ok':           int,    # HTTP 成功次数
    'http_err':          int,    # HTTP 失败次数
    'http_retries':      int,    # 重试次数
    'http_success_rate': float,  # HTTP 成功率（百分比）
    'avg_http_ms':       float,  # 平均 HTTP 耗时（毫秒）
    'db_ok':             int,    # DB 写入成功次数
    'db_err':            int,    # DB 写入失败次数
    'avg_db_ms':         float,  # 平均 DB 写入耗时（毫秒）
    'errors_total':      int,    # 累计错误次数（告警依据）
}
```

兼容说明：历史接口 `stocks_total`、`inc_notices()`、`inc_inserted()`、`inc_skipped()` 仍可继续使用，但建议迁移到 `accounts_total` 和 `inc_records_*` 系列接口。

---

### `CrawlScheduler` — 推送调度器

#### `scheduler.start(extra=None)`

启动后台推送线程，并立即推送一条任务启动通知。

```python
scheduler.start(extra={
    'worker': 6,       # 可传入任意自定义键值，会附加在推送报告末尾
    'env':   'prod',
})
```

#### `scheduler.stop(extra=None)`

停止后台线程，并立即推送最终完成报告。**建议始终放在 `finally` 块中**，确保程序异常退出时也能收到报告。

```python
try:
    run_crawler()
finally:
    scheduler.stop()
```

#### 每日定点推送（例如每天 09:00）

```python
stats, scheduler = create_monitor(
    job_name='media_crawler',
    notify_urls=['wecombot://KEY'],
    accounts_total=len(account_ids),
    interval_sec=0,              # 关闭固定间隔
    daily_report_times=['09:00'] # 每天 09:00 推送一次进度
)
```

---

## 推送渠道配置

`notify_urls` 参数接受任意 Apprise 格式的 URL 列表，支持同时推送到多个渠道。

```python
stats, scheduler = create_monitor(
    job_name    = 'media_crawler',
    notify_urls = [
        'wecombot://企业微信机器人Key',    # 企业微信群机器人
        'tgram://BotToken/ChatID',          # Telegram
        'dingtalk://token/',                # 钉钉
        'feishu://token',                   # 飞书
        'mailto://user:pass@gmail.com',     # 邮件
    ],
    accounts_total = 5000,
)
```

完整渠道列表参见 [Apprise 文档](https://github.com/caronc/apprise#supported-notifications)。

---

## 完整使用示例

以多线程采集程序为例：

```python
import time
import requests
from concurrent.futures import ThreadPoolExecutor
from tqdm import tqdm
from crawl_monitor import create_monitor

WECOM_KEY    = 'wecombot://你的Key'
ACCOUNT_IDS  = [...]   # 账号列表

def crawl_one(account_id: str, stats):
    stats.inc_progress()
    try:
        t0 = time.time()
        resp = requests.get(f'https://example.com/api/{account_id}', timeout=15)
        resp.raise_for_status()
        stats.inc_http_ok(duration_ms=(time.time() - t0) * 1000)

        data = resp.json().get('list', [])
        stats.inc_records(len(data))

        # 写入数据库
        t_db = time.time()
        db_write(data)
        stats.inc_db_ok(duration_ms=(time.time() - t_db) * 1000)
        stats.inc_records_inserted(len(data))

    except requests.RequestException:
        stats.inc_http_err()
        stats.inc_error()
    except Exception:
        stats.inc_error()
    finally:
        stats.dec_progress()   # 必须在 finally 中调用


def main():
    stats, scheduler = create_monitor(
        job_name        = 'my_crawler',
        notify_urls     = [WECOM_KEY],
        accounts_total  = len(ACCOUNT_IDS),
        interval_sec    = 0,             # 关闭固定间隔推送
        daily_report_times=['09:00'],    # 每日 09:00 推送一次进度
        error_threshold = 20,
        cooldown_sec    = 120,
    )
    scheduler.start(extra={'workers': 6})

    try:
        with ThreadPoolExecutor(max_workers=6) as executor:
            results = tqdm(
                executor.map(lambda s: crawl_one(s, stats), ACCOUNT_IDS),
                total=len(ACCOUNT_IDS)
            )
            list(results)
    finally:
        scheduler.stop()


if __name__ == '__main__':
    main()
```

---

## 推送报告示例

**任务启动**
```
【my_crawler】任务启动
启动时间：2026-04-01 10:00:00
待处理账号：5,000 个
固定间隔推送：关闭
daily_report_times：09:00
```

**每日定点进度报告**
```
【my_crawler】每日09:00进度报告
运行时长：00:15:32

整体进度
████████░░░░░░░░░░░░ 42.3%
已完成：2,115 / 5,000 个 | 当前并发：6 线程

采集结果
采集记录：131,660 条 | 写入数据库：98,340 条 | 规则过滤：33,320 条

请求状态
HTTP 成功率：99.2% | 成功 / 失败：18,432 / 148
平均响应：342 ms

数据库
写入成功 / 失败：2,115 / 0 | 平均写入耗时：18 ms
```

**错误告警**
```
🚨 【my_crawler】错误告警
累计错误：21 次 | HTTP 失败：18 | 重试：54 | DB 写入失败：3
当前进度：1,230 / 5,000
```

**任务完成**
```
【my_crawler】任务完成 ✅
总耗时：01:12:44
处理账号：5,000 个 | 总采集记录：312,450 条
总写入数据库：241,380 条 | 平均每个账号耗时：8.7 s
```

---

## 依赖

| 包 | 版本要求 | 用途 |
|---|---|---|
| `apprise` | `>=1.7` | 多渠道消息推送 |

标准库：`threading`、`time`、`dataclasses`（均无需额外安装）

---

