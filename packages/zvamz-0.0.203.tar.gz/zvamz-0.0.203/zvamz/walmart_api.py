import os
import time
from datetime import datetime, timezone

import requests
import uuid


WM_REPORT_REQUESTS_URL = "https://marketplace.walmartapis.com/v3/reports/reportRequests"
WM_DOWNLOAD_REPORT_URL = "https://marketplace.walmartapis.com/v3/reports/downloadReport"


def _wm_rate_limit_snapshot(response):
    """Pull Walmart's rate-limit headers off any response. Returns (remaining, next_reset_str)."""
    remaining = response.headers.get("X-Current-Token-Count")
    next_reset = response.headers.get("X-Next-Replenishment-Time")
    return remaining, next_reset


def _wm_429_backoff(response, default=30):
    """
    Compute backoff seconds from a 429 response. Prefers Walmart's
    X-Next-Replenishment-Time (ISO 8601 or epoch ms), falls back to
    Retry-After, then to `default` seconds.
    """
    next_reset = response.headers.get("X-Next-Replenishment-Time")
    if next_reset:
        try:
            if next_reset.isdigit():
                target = datetime.fromtimestamp(int(next_reset) / 1000, tz=timezone.utc)
            else:
                target = datetime.fromisoformat(next_reset.replace("Z", "+00:00"))
            delta = (target - datetime.now(tz=timezone.utc)).total_seconds()
            if delta > 0:
                return min(delta + 5, 600)
        except (ValueError, TypeError):
            pass

    retry_after = response.headers.get("Retry-After")
    if retry_after and retry_after.isdigit():
        return int(retry_after)

    return default


def wm_client_access(username):
    """
    Fetches a fresh Walmart Marketplace API access token via zvdataautomation.com.

    Walmart uses OAuth2 client_credentials — the website performs the Basic-Auth
    token exchange using the user's stored client_id/client_secret and returns
    a short-lived (15 min) bearer token. No refresh token to rotate; just call
    this again when the token expires.
    """
    response = requests.post(
        "https://zvdataautomation.com/zvwalmartauth/",
        headers={"Content-Type": "application/json"},
        json={"username": username},
    )

    if response.status_code != 200:
        raise ValueError(f"wm_client_access failed: {response.status_code} - {response.text}")

    return response.json()['access_token']


def wm_default_headers(access_token):
    """
    Standard required headers for every Walmart Marketplace API request.
    Caller adds endpoint-specific Content-Type / Accept overrides as needed.
    """
    return {
        "WM_SEC.ACCESS_TOKEN": access_token,
        "WM_QOS.CORRELATION_ID": str(uuid.uuid4()),
        "WM_SVC.NAME": "Walmart Marketplace",
        "Accept": "application/json",
    }


def wm_request_report(access_token, report_type, report_version='v1',
                      data_start_time=None, data_end_time=None,
                      row_filters=None, exclude_columns=None):
    """
    Fires an async report request. Returns the requestId UUID to poll.

    reportType enum: ITEM, INVENTORY, CANCELLATION, DELIVERY_DEFECT,
        ITEM_PERFORMANCE, PROMO, RETURN_OVERRIDES, CPA, SHIPPING_CONFIGURATION,
        SHIPPING_PROGRAM, FITMENT_MISSING_ATTR, FITMENT_ACES_COVERAGE, BUYBOX,
        ASSORTMENT_RECOMMENDATIONS, LAGTIME, API_traffic_report,
        INVENTORY_RECOMMENDATIONS, SEM_PERFORMANCE, INVENTORY_RECON,
        SETTLEMENT, WFS_ORDERS, WFS_CUSTOMER_RETURNS

    reportVersion: 'v1' for everything; ITEM supports v1-v6.
    data_start_time / data_end_time: ISO 8601 'YYYY-MM-DDTHH:mm:ssZ'.
    """
    headers = wm_default_headers(access_token)
    headers["Content-Type"] = "application/json"

    params = {"reportType": report_type, "reportVersion": report_version}

    body = {}
    if data_start_time:
        body["dataStartTime"] = data_start_time
    if data_end_time:
        body["dataEndTime"] = data_end_time
    if row_filters:
        body["rowFilters"] = row_filters
    if exclude_columns:
        body["excludeColumns"] = exclude_columns

    response = requests.post(WM_REPORT_REQUESTS_URL, headers=headers, params=params, json=body)

    remaining, next_reset = _wm_rate_limit_snapshot(response)
    print(f'[wm_request_report] rate budget: tokens_left={remaining} next_reset={next_reset}')

    if response.status_code != 200:
        raise ValueError(f"wm_request_report failed: {response.status_code} - {response.text}")

    return response.json()["requestId"]


def wm_poll_report(access_token, request_id, max_wait_seconds=1800,
                   poll_interval=60, initial_wait=60):
    """
    Polls report status until READY (or ERROR / timeout). Returns the final
    status payload. requestStatus transitions: RECEIVED → INPROGRESS → READY|ERROR.

    Walmart rate-limits the poll endpoint, so:
    - initial_wait: skip the first 60s (reports rarely finish that fast)
    - poll_interval: 60s default (was 30s — too aggressive)
    - 429s back off using Retry-After header (default 30s), don't fail
    """
    url = f"{WM_REPORT_REQUESTS_URL}/{request_id}"
    headers = wm_default_headers(access_token)

    if initial_wait > 0:
        time.sleep(initial_wait)

    deadline = time.time() + max_wait_seconds
    status = None
    while time.time() < deadline:
        response = requests.get(url, headers=headers)
        remaining, next_reset = _wm_rate_limit_snapshot(response)

        if response.status_code == 429:
            backoff = _wm_429_backoff(response)
            print(f'[wm_poll_report] 429 — backing off {backoff:.0f}s (next_reset={next_reset})')
            time.sleep(backoff)
            continue

        if response.status_code != 200:
            raise ValueError(f"wm_poll_report failed: {response.status_code} - {response.text}")

        data = response.json()
        status = data.get("requestStatus")
        print(f'[wm_poll_report] status={status} tokens_left={remaining}')
        if status == "READY":
            return data
        if status == "ERROR":
            raise ValueError(f"Walmart report request errored: {data}")

        time.sleep(poll_interval)

    raise TimeoutError(f"wm_poll_report timed out after {max_wait_seconds}s — last status: {status}")


def wm_get_download_url(access_token, request_id):
    """
    Once a report is READY, gets the time-limited downloadURL for the file.
    Returns (download_url, expiration_time_string).
    """
    headers = wm_default_headers(access_token)
    params = {"requestId": request_id}

    response = requests.get(WM_DOWNLOAD_REPORT_URL, headers=headers, params=params)

    remaining, next_reset = _wm_rate_limit_snapshot(response)
    print(f'[wm_get_download_url] rate budget: tokens_left={remaining} next_reset={next_reset}')

    if response.status_code != 200:
        raise ValueError(f"wm_get_download_url failed: {response.status_code} - {response.text}")

    data = response.json()
    return data["downloadURL"], data.get("downloadURLExpirationTime")


def wm_download_report(access_token, report_type, save_dir,
                       report_version='v1', data_start_time=None, data_end_time=None,
                       row_filters=None, exclude_columns=None,
                       max_wait_seconds=1200, poll_interval=30):
    """
    Orchestrates request → poll → fetch downloadURL → save file.
    Saves the raw response bytes to <save_dir>/<report_type>_<requestId>.<ext>
    where extension is inferred from Content-Type (csv/tsv/zip/json/bin fallback).
    Returns the saved filepath.
    """
    request_id = wm_request_report(
        access_token, report_type, report_version,
        data_start_time, data_end_time, row_filters, exclude_columns,
    )

    wm_poll_report(access_token, request_id,
                   max_wait_seconds=max_wait_seconds, poll_interval=poll_interval)

    download_url, _expires = wm_get_download_url(access_token, request_id)

    response = requests.get(download_url)
    if response.status_code != 200:
        raise ValueError(f"download file fetch failed: {response.status_code} - {response.text[:200]}")

    ext_map = {
        "text/csv": "csv",
        "text/tab-separated-values": "tsv",
        "text/plain": "csv",
        "application/zip": "zip",
        "application/octet-stream": "bin",
        "application/json": "json",
    }
    content_type = response.headers.get("Content-Type", "").split(";")[0].strip().lower()
    ext = ext_map.get(content_type, "bin")

    os.makedirs(save_dir, exist_ok=True)
    save_path = os.path.join(save_dir, f"{report_type}_{request_id}.{ext}")
    with open(save_path, "wb") as f:
        f.write(response.content)

    return save_path
