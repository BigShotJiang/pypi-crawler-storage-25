"""Token-bucket rate limiter aligned to Amazon SP-API guidance.

Design references:
  https://developer-docs.amazon.com/sp-api/docs/usage-plans-and-rate-limits
  https://developer-docs.amazon.com/sp-api/docs/strategies-to-optimize-rate-limits-for-your-application-workloads

What this module gives you:

  * **Token bucket** — `tokens_per_second` refill rate, `capacity` burst — matches
    the model Amazon documents as their server-side enforcement.
  * **Exponential backoff with jitter** — Amazon: "Use an exponential back-off
    algorithm… use jitter, which is a random amount of time before making or
    retrying a request to help prevent large bursts."
  * **Adaptive rate from `x-amzn-RateLimit-Limit`** — Amazon publishes this
    header on 2xx/400/404 responses indicating the *currently applied* rate
    (dynamic usage plans differ per seller). We read it when present and update
    our local refill rate; we never crash when it's absent ("you must not
    depend on this header being present").
  * **Retries 429 + 5xx transient errors** — Amazon: "A 429 is a retry-able
    status code." HTTP 500/502/503/504 are treated as retry-able too.
    `Retry-After` is honored when present (Amazon doesn't reliably send it,
    so exponential backoff is the actual mechanism).
  * **Bounded retry budget** — `max_attempts` cap + `max_backoff_seconds`
    ceiling. Exhaustion raises `RuntimeError` with stats so cron error handlers
    can fail loudly instead of silently corrupting downstream loads.
  * **Observability counters** — `throttle_count`, `transient_error_count`,
    `total_backoff_seconds`, `.stats()`. Lets us audit how often a pipeline
    is bouncing off the wall.

Backward compatibility:
  Public surface `RateLimiter(tokens_per_second, capacity).send_request(action, *args, **kwargs)`
  is unchanged. New options are all kwargs with safe defaults. Existing
  callsites work without modification.
"""
from __future__ import annotations

import random
import threading
import time

import requests


class RateLimiter:
    def __init__(
        self,
        tokens_per_second: float,
        capacity: float,
        *,
        max_attempts: int = 10,
        base_backoff_seconds: float = 1.0,
        max_backoff_seconds: float = 300.0,
        jitter_seconds: float = 0.5,
        debug: bool = False,
    ):
        if tokens_per_second <= 0:
            raise ValueError("tokens_per_second must be > 0")
        if capacity <= 0:
            raise ValueError("capacity must be > 0")

        self.tokens_per_second = float(tokens_per_second)
        self.capacity          = float(capacity)
        self.tokens            = float(capacity)
        self.last_refill_time  = time.time()
        self.lock              = threading.Lock()

        self.max_attempts         = max_attempts
        self.base_backoff_seconds = base_backoff_seconds
        self.max_backoff_seconds  = max_backoff_seconds
        self.jitter_seconds       = jitter_seconds
        self.debug                = debug

        self.throttle_count         = 0
        self.transient_error_count  = 0
        self.total_backoff_seconds  = 0.0

    # ── bucket math ──────────────────────────────────────────────────────
    def refill(self):
        """Refill tokens proportional to elapsed time. Caller holds the lock."""
        now = time.time()
        elapsed = now - self.last_refill_time
        if elapsed > 0:
            self.tokens = min(
                self.capacity,
                self.tokens + elapsed * self.tokens_per_second,
            )
            self.last_refill_time = now

    def allow_request(self) -> bool:
        """Non-blocking — consume one token if available, else return False."""
        with self.lock:
            self.refill()
            if self.tokens >= 1:
                self.tokens -= 1
                return True
            return False

    def _acquire(self):
        """Block until one token is available, then consume it.
        Sleeps just long enough for the bucket to have a token, capped at 1s
        so adaptive rate changes propagate quickly."""
        while True:
            with self.lock:
                self.refill()
                if self.tokens >= 1:
                    self.tokens -= 1
                    return
                needed = 1 - self.tokens
                wait = needed / max(self.tokens_per_second, 1e-9)
            time.sleep(min(max(wait, 0.01), 1.0))

    # ── adaptive rate from Amazon's response header ──────────────────────
    def _maybe_update_rate_from_header(self, response):
        """Honor `x-amzn-RateLimit-Limit` when present (informational header).

        Amazon: "The x-amzn-RateLimit-Limit response header returns the usage
        plan rate limits that were applied to the requested operation, when
        available… you must not depend on this header being present."
        """
        hdr = response.headers.get("x-amzn-RateLimit-Limit")
        if hdr is None:
            return
        try:
            new_rate = float(hdr)
        except (TypeError, ValueError):
            return
        if new_rate <= 0:
            return
        # Only act if the change is meaningful (avoid lock thrashing on noise)
        if abs(new_rate - self.tokens_per_second) < 1e-3:
            return
        with self.lock:
            if self.debug:
                print(
                    f"[RateLimiter] x-amzn-RateLimit-Limit={new_rate} "
                    f"-> updating tokens_per_second from {self.tokens_per_second}"
                )
            self.tokens_per_second = new_rate

    # ── backoff ──────────────────────────────────────────────────────────
    def _backoff_seconds(self, attempt: int) -> float:
        """Exponential backoff with uniform jitter.

        attempt 0 → ~base_backoff_seconds (+jitter)
        attempt 1 → ~2× base
        attempt 2 → ~4× base
        ... capped at max_backoff_seconds.
        """
        exp = self.base_backoff_seconds * (2 ** attempt)
        return min(exp, self.max_backoff_seconds) + random.uniform(0, self.jitter_seconds)

    def _retry_after_or_backoff(self, response, attempt: int) -> float:
        """Prefer server's Retry-After hint when present and parseable."""
        retry_after = response.headers.get("Retry-After")
        if retry_after is not None:
            try:
                return max(0.0, float(retry_after))
            except (TypeError, ValueError):
                pass
        return self._backoff_seconds(attempt)

    # ── main entry point ─────────────────────────────────────────────────
    def send_request(self, action, *args, **kwargs):
        """Send a request through the bucket, retrying on 429 / 5xx / network.

        Returns the final response on:
          - Any 2xx (after updating adaptive rate if header present)
          - Any non-retryable 4xx — caller decides how to handle (validation,
            auth, not-found, etc.)

        Raises:
          - RuntimeError if max_attempts is exhausted
          - The underlying requests.RequestException if the LAST attempt was a
            network failure (no response object to return)
        """
        last_exc = None

        for attempt in range(self.max_attempts):
            self._acquire()

            try:
                response = action(*args, **kwargs)
            except requests.exceptions.RequestException as e:
                last_exc = e
                self.transient_error_count += 1
                if attempt == self.max_attempts - 1:
                    raise
                wait = self._backoff_seconds(attempt)
                self.total_backoff_seconds += wait
                if self.debug:
                    print(
                        f"[RateLimiter] network error: {e!r} - sleeping {wait:.2f}s "
                        f"(attempt {attempt + 1}/{self.max_attempts})"
                    )
                time.sleep(wait)
                continue

            # Adaptive rate signal lives on successful + some 4xx responses
            if 200 <= response.status_code < 300 or response.status_code in (400, 404):
                self._maybe_update_rate_from_header(response)

            if response.status_code == 429:
                self.throttle_count += 1
                wait = self._retry_after_or_backoff(response, attempt)
                self.total_backoff_seconds += wait
                if self.debug:
                    print(
                        f"[RateLimiter] 429 throttled - sleeping {wait:.2f}s "
                        f"(attempt {attempt + 1}/{self.max_attempts})"
                    )
                time.sleep(wait)
                continue

            if response.status_code in (500, 502, 503, 504):
                self.transient_error_count += 1
                wait = self._retry_after_or_backoff(response, attempt)
                self.total_backoff_seconds += wait
                if self.debug:
                    print(
                        f"[RateLimiter] {response.status_code} transient - "
                        f"sleeping {wait:.2f}s "
                        f"(attempt {attempt + 1}/{self.max_attempts})"
                    )
                time.sleep(wait)
                continue

            # Success or non-retryable 4xx → bubble up to caller
            return response

        raise RuntimeError(
            f"RateLimiter.send_request exhausted {self.max_attempts} attempts. "
            f"Stats: {self.stats()} last_exc={last_exc!r}"
        )

    # ── observability ────────────────────────────────────────────────────
    def stats(self) -> dict:
        """Snapshot of cumulative counters for the lifetime of this limiter."""
        return {
            "tokens_per_second":      self.tokens_per_second,
            "capacity":               self.capacity,
            "throttle_count":         self.throttle_count,
            "transient_error_count":  self.transient_error_count,
            "total_backoff_seconds":  round(self.total_backoff_seconds, 2),
        }
