# suneord

<div align="center">

### Асинхронный Discord-фреймворк поверх raw HTTP + Gateway API

**Без `discord.py`, `disnake`, `hikari` и других тяжёлых обёрток.**  
`suneord` даёт низкий уровень контроля, но при этом уже умеет cogs, prefix/slash-команды, checks, permissions, embeds, moderation helpers и расширяемый DX для собственных команд.

</div>

---

## Что это такое

`suneord` — это Python-фреймворк для Discord-ботов, который работает **напрямую с Discord HTTP API и Gateway API**.

Он не навязывает готовую “магическую” админку из коробки. Вместо этого он даёт нормальные строительные блоки, чтобы **ты сам писал свои команды**:

- `!ban`
- `/ban`
- `!kick`
- `/unban`
- `!timeout`
- `/purge`
- и любые свои workflow-команды поверх raw API

Именно это и есть идея проекта:  
**не готовые встроенные команды, а сильный toolkit для своих команд.**

---

## Ключевые возможности

### Командный слой

- prefix-команды с алиасами и несколькими префиксами
- slash-команды с ручными `SlashOption`
- автоинференс slash-опций из сигнатуры функции
- quoted-аргументы для prefix-команд через `shlex`
- конвертация аргументов по аннотациям: `str`, `int`, `float`, `bool`, `Literal[...]`
- `*args`, keyword-only остаток строки (`*, reason: str | None = None`)
- usage/examples/hidden-метаданные для собственных help-команд

### Checks и контроль доступа

- `@guild_only()`
- `@dm_only()`
- `@has_permissions(...)`
- `@bot_has_permissions(...)`
- `@cooldown(rate, per, bucket=...)`
- `Permissions` bitfield helper
- auto-resolve guild permissions через роли, если Discord не прислал их прямо в payload

### Slash / App Commands

- `SlashOption.string(...)`
- `SlashOption.integer(...)`
- `SlashOption.boolean(...)`
- `SlashOption.user(...)`
- `SlashOption.channel(...)`
- `SlashOption.role(...)`
- `SlashOption.mentionable(...)`
- `SlashOption.number(...)`
- `SlashOption.attachment(...)`
- `@describe(...)` для описаний параметров
- `default_member_permissions` для slash-команд

### Context helpers

- `ctx.send()`, `ctx.reply()`, `ctx.edit()`, `ctx.delete()`
- `ctx.send_success()`, `ctx.reply_error()` и другие status-helper'ы
- `ctx.resolve_user()`
- `ctx.fetch_member()`
- `ctx.author_permissions()`
- `ctx.bot_permissions()`
- `ctx.kick()`
- `ctx.ban()`
- `ctx.unban()`
- `ctx.timeout()`
- `ctx.remove_timeout()`
- `ctx.send_dm()`
- `ctx.typing()`

### REST / Gateway / инфраструктура

- reconnect + resume сессии gateway
- direct REST helpers для сообщений, реакций, DM, банов, таймаутов, ролей и участников
- встроенный rate pacing через `aiolimiter`
- быстрый JSON через `orjson`
- `run_from_env()` / `start_from_env()` через `python-dotenv`
- кэш guild/roles для permission resolution
- structured logger с консолью и файлами

---

## Зависимости проекта

В проекте используются:

- `aiohttp`
- `aiolimiter`
- `orjson`
- `python-dotenv`

Никаких сторонних Discord-фреймворков здесь нет.

---

## Установка

### Локально из проекта

```bash
pip install .
```

### Для разработки

```bash
pip install -e .
```

---

## Быстрый старт

```python
from suneord import Bot, Colors, Embed, Intents

intents = Intents.for_commands()
intents.guild_members = True

bot = Bot(
    prefix=("!", "?"),
    intents=intents,
    enable_logging=True,
    status="idle",
    status_text="watching the server",
)


@bot.event
async def on_ready():
    print(f"Ready as {bot.user['username']}")


@bot.command(
    description="Показывает задержку gateway",
    usage="ping",
    examples=("ping",),
)
async def ping(ctx):
    embed = (
        Embed(title="Pong", colour=Colors.SUCCESS)
        .set_description(f"Latency: {round(bot.latency * 1000)} ms")
        .set_footer(text="suneord")
    )
    await ctx.reply(embed=embed, mention_author=False)


bot.run("TOKEN")
```

---

## Пример: свои moderation-команды

Ниже важный момент:  
`suneord` **не вшивает** тебе `ban`, `kick`, `unban` как готовые команды.  
Вместо этого он даёт **checks + permissions + context helpers**, чтобы ты написал их сам за несколько строк.

### Prefix `!ban`

```python
from suneord import Bot, Intents, bot_has_permissions, guild_only, has_permissions

bot = Bot(prefix="!", intents=Intents.for_commands())


@bot.command(
    description="Бан пользователя",
    usage="ban <@user|id> [reason]",
    examples=("ban @tox spam links", "ban 123456789012345678 raids"),
)
@guild_only()
@has_permissions("ban_members")
@bot_has_permissions("ban_members")
async def ban(ctx, target: str, *, reason: str | None = None):
    await ctx.ban(target, reason=reason or "Причина не указана")
    await ctx.reply_success(f"Пользователь `{target}` забанен.")
```

### Prefix `!kick`

```python
@bot.command(
    description="Кик пользователя",
    usage="kick <@user|id> [reason]",
)
@guild_only()
@has_permissions("kick_members")
@bot_has_permissions("kick_members")
async def kick(ctx, target: str, *, reason: str | None = None):
    await ctx.kick(target, reason=reason or "Причина не указана")
    await ctx.reply_success(f"Пользователь `{target}` кикнут.")
```

### Prefix `!unban`

```python
@bot.command(
    description="Разбан пользователя",
    usage="unban <id>",
)
@guild_only()
@has_permissions("ban_members")
@bot_has_permissions("ban_members")
async def unban(ctx, target: str, *, reason: str | None = None):
    await ctx.unban(target, reason=reason or "Причина не указана")
    await ctx.reply_success(f"Пользователь `{target}` разбанен.")
```

### Slash `/ban`

```python
from suneord import Permissions, SlashOption, describe


@bot.slash_command(
    name="ban",
    description="Бан пользователя",
    options=[
        SlashOption.user("target", "Кого забанить"),
        SlashOption.string("reason", "Причина", required=False, max_length=512),
    ],
    default_member_permissions=Permissions.from_names("ban_members"),
    dm_permission=False,
)
@describe(target="Пользователь", reason="Причина бана")
@guild_only()
@has_permissions("ban_members")
@bot_has_permissions("ban_members")
async def slash_ban(ctx, target: str, reason: str | None = None):
    await ctx.ban(target, reason=reason or "Причина не указана")
    await ctx.reply_success("Пользователь забанен.", ephemeral=True)
```

---

## Пример: cooldown + типизированные аргументы

```python
from typing import Literal
from suneord import cooldown


@bot.command(description="Чистка сообщений")
@guild_only()
@has_permissions("manage_messages")
@cooldown(2, 10, bucket="channel")
async def purge(ctx, amount: int, *, mode: Literal["soft", "hard"] = "soft"):
    await ctx.reply_info(f"Будет удалено {amount} сообщений, режим: {mode}")
```

Что здесь важно:

- `amount: int` автоматически конвертируется в число
- `Literal["soft", "hard"]` валидируется
- cooldown работает без дополнительной обвязки

---

## Пример: slash-команды можно описывать вручную или через сигнатуру

### Вариант 1. Ручные `SlashOption`

```python
from suneord import SlashOption


@bot.slash_command(
    name="warn",
    description="Предупреждение пользователю",
    options=[
        SlashOption.user("target", "Цель"),
        SlashOption.string("reason", "Причина", required=False),
        SlashOption.boolean("silent", "Тихий режим", required=False),
    ],
)
async def warn(ctx, target: str, reason: str | None = None, silent: bool = False):
    await ctx.reply_info(f"Warn: {target} | silent={silent}")
```

### Вариант 2. Автоинференс

```python
from typing import Literal
from suneord import describe


@bot.slash_command(name="mode", description="Смена режима")
@describe(state="Новый режим", retries="Сколько раз повторять")
async def mode(ctx, state: Literal["safe", "fast"], retries: int = 1):
    await ctx.reply_info(f"mode={state}, retries={retries}", ephemeral=True)
```

Что произойдёт:

- `state` станет string option с choices `safe` / `fast`
- `retries: int = 1` станет optional integer option

---

## Cogs

```python
from suneord import Embed, SlashOption
from suneord.ext.commands import Cog, command, listener, slash_command


class Utility(Cog):
    @listener()
    async def on_ready(self):
        print("Utility cog loaded")

    @command(description="Аватар пользователя")
    async def avatar(self, ctx, target: str | None = None):
        user = await ctx.resolve_user_or_none(target) or ctx.author
        embed = Embed(title=user.display_name or user.name).set_image(url=str(user.avatar))
        await ctx.reply(embed=embed, mention_author=False)

    @slash_command(
        name="avatar",
        description="Аватар пользователя",
        options=[SlashOption.user("target", "Кого показать", required=False)],
    )
    async def avatar_slash(self, ctx, target: str | None = None):
        user = await ctx.resolve_user_or_none(target) or ctx.author
        embed = Embed(title=user.display_name or user.name).set_image(url=str(user.avatar))
        await ctx.reply(embed=embed, ephemeral=True)


async def setup(bot):
    await bot.add_cog(Utility())
```

Загрузка:

```python
await bot.load_extension("bot.cogs.utility")
```

Или директории:

```python
await bot.load_extensions_from("bot/cogs", package="bot.cogs")
```

---

## Переменные окружения и `.env`

```python
from suneord import Bot

bot = Bot(prefix="!")
bot.run_from_env("DISCORD_TOKEN")
```

`.env`

```env
DISCORD_TOKEN=your_bot_token_here
```

---

## Logging

```python
from suneord import Bot

bot = Bot(prefix="!", enable_logging=True, log_level="DEBUG")
bot.logger.add_file("logs/bot.log")

bot.logger.debug("debug line")
bot.logger.info("connected")
bot.logger.success("commands synced")
bot.logger.warning("slow heartbeat")
bot.logger.error("api request failed")
```

Можно использовать и свой logger:

```python
from suneord import Bot, Logger

logger = Logger("mybot", enabled=True, level="INFO", autoconfigure=False)
logger.add_console()
logger.add_file("logs/mybot.log")

bot = Bot(prefix="!", logger=logger)
```

---

## Основной API

### `Bot`

- `command()`
- `slash_command()`
- `event()`
- `add_cog()`
- `remove_cog()`
- `load_extension()`
- `reload_extension()`
- `load_extensions_from()`
- `wait_until_ready()`
- `run()`
- `run_from_env()`
- `start_from_env()`
- `set_presence()`
- `sync_application_commands()`
- `send_message()`
- `edit_message()`
- `delete_message()`
- `fetch_message()`
- `fetch_messages()`
- `bulk_delete_messages()`
- `pin_message()`
- `unpin_message()`
- `create_dm()`
- `send_dm()`
- `fetch_channel()`
- `fetch_guild()`
- `fetch_guild_member()`
- `fetch_guild_roles()`
- `fetch_bans()`
- `fetch_user()`
- `fetch_me()`
- `fetch_bot_member()`
- `add_reaction()`
- `remove_reaction()`
- `trigger_typing()`
- `edit_guild_member()`
- `change_nickname()`
- `timeout_member()`
- `remove_timeout()`
- `kick_member()`
- `ban_member()`
- `unban_member()`
- `resolve_guild_permissions()`
- `clear_cache()`
- `create_task()`

### `Context`

- `send()`
- `reply()`
- `respond()`
- `edit()`
- `delete()`
- `fetch_message()`
- `fetch_member()`
- `history()`
- `pin()`
- `unpin()`
- `react()`
- `typing()`
- `send_dm()`
- `resolve_user()`
- `resolve_user_or_none()`
- `author_permissions()`
- `bot_permissions()`
- `kick()`
- `ban()`
- `unban()`
- `timeout()`
- `remove_timeout()`
- `send_success()`
- `send_info()`
- `send_warning()`
- `send_error()`
- `reply_success()`
- `reply_info()`
- `reply_warning()`
- `reply_error()`

### `SlashContext`

- `reply()`
- `send()`
- `respond()`
- `followup()`
- `defer()`
- `edit()`
- `delete()`
- `fetch_original_response()`
- `react()`
- `typing()`
- `send_dm()`
- `resolve_user()`
- `resolve_user_or_none()`
- `author_permissions()`
- `bot_permissions()`
- `kick()`
- `ban()`
- `unban()`
- `timeout()`
- `remove_timeout()`
- `subcommand_path`
- `options`

---

## Почему это удобно

### Если тебе нужен “свой” бот, а не чужая экосистема

`suneord` хорош, если ты хочешь:

- писать поверх raw Discord API
- контролировать, как именно работает gateway / REST
- не зависеть от `discord.py`-подобной архитектуры
- строить свои moderation/admin workflow-команды без встроенного “комбайна”
- иметь лёгкий код, который реально можно дочитать

### Если тебе нужны именно свои команды

Этот проект теперь заточен под сценарий:

- ты сам пишешь `!ban`, `/ban`, `!kick`, `/unban`
- библиотека даёт тебе checks, permission resolution, slash options, context helpers и REST-методы
- “готовая админка из коробки” не мешает и не диктует архитектуру

---

## Замечания

- Для prefix-команд нужен `Message Content Intent`.
- Для moderation-команд почти всегда стоит включить `guild_members`.
- Для некоторых privileged intents их нужно включить ещё и в Discord Developer Portal.
- Если токен утёк, его нужно сразу перевыпустить.

---

## License

MIT
