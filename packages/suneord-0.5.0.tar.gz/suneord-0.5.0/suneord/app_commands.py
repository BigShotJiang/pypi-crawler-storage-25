from __future__ import annotations

import inspect
from dataclasses import dataclass
from types import UnionType
from typing import Any, Literal, Union, get_args, get_origin


DESCRIPTIONS_ATTR = "__suneord_param_descriptions__"


class SlashOptionType:
    SUBCOMMAND = 1
    SUBCOMMAND_GROUP = 2
    STRING = 3
    INTEGER = 4
    BOOLEAN = 5
    USER = 6
    CHANNEL = 7
    ROLE = 8
    MENTIONABLE = 9
    NUMBER = 10
    ATTACHMENT = 11


@dataclass(slots=True)
class SlashChoice:
    name: str
    value: str | int | float

    def to_dict(self) -> dict[str, Any]:
        return {"name": self.name, "value": self.value}


@dataclass(slots=True)
class SlashOption:
    name: str
    description: str
    option_type: int = SlashOptionType.STRING
    required: bool = True
    choices: tuple[SlashChoice, ...] = ()
    min_value: int | float | None = None
    max_value: int | float | None = None
    min_length: int | None = None
    max_length: int | None = None
    channel_types: tuple[int, ...] = ()
    autocomplete: bool = False

    @classmethod
    def string(
        cls,
        name: str,
        description: str,
        *,
        required: bool = True,
        choices: list[SlashChoice] | tuple[SlashChoice, ...] | None = None,
        min_length: int | None = None,
        max_length: int | None = None,
        autocomplete: bool = False,
    ) -> "SlashOption":
        return cls(
            name=name,
            description=description,
            option_type=SlashOptionType.STRING,
            required=required,
            choices=tuple(choices or ()),
            min_length=min_length,
            max_length=max_length,
            autocomplete=autocomplete,
        )

    @classmethod
    def integer(
        cls,
        name: str,
        description: str,
        *,
        required: bool = True,
        choices: list[SlashChoice] | tuple[SlashChoice, ...] | None = None,
        min_value: int | None = None,
        max_value: int | None = None,
        autocomplete: bool = False,
    ) -> "SlashOption":
        return cls(
            name=name,
            description=description,
            option_type=SlashOptionType.INTEGER,
            required=required,
            choices=tuple(choices or ()),
            min_value=min_value,
            max_value=max_value,
            autocomplete=autocomplete,
        )

    @classmethod
    def boolean(cls, name: str, description: str, *, required: bool = True) -> "SlashOption":
        return cls(name=name, description=description, option_type=SlashOptionType.BOOLEAN, required=required)

    @classmethod
    def user(cls, name: str, description: str, *, required: bool = True) -> "SlashOption":
        return cls(name=name, description=description, option_type=SlashOptionType.USER, required=required)

    @classmethod
    def channel(
        cls,
        name: str,
        description: str,
        *,
        required: bool = True,
        channel_types: list[int] | tuple[int, ...] | None = None,
    ) -> "SlashOption":
        return cls(
            name=name,
            description=description,
            option_type=SlashOptionType.CHANNEL,
            required=required,
            channel_types=tuple(channel_types or ()),
        )

    @classmethod
    def role(cls, name: str, description: str, *, required: bool = True) -> "SlashOption":
        return cls(name=name, description=description, option_type=SlashOptionType.ROLE, required=required)

    @classmethod
    def mentionable(cls, name: str, description: str, *, required: bool = True) -> "SlashOption":
        return cls(name=name, description=description, option_type=SlashOptionType.MENTIONABLE, required=required)

    @classmethod
    def number(
        cls,
        name: str,
        description: str,
        *,
        required: bool = True,
        choices: list[SlashChoice] | tuple[SlashChoice, ...] | None = None,
        min_value: float | None = None,
        max_value: float | None = None,
        autocomplete: bool = False,
    ) -> "SlashOption":
        return cls(
            name=name,
            description=description,
            option_type=SlashOptionType.NUMBER,
            required=required,
            choices=tuple(choices or ()),
            min_value=min_value,
            max_value=max_value,
            autocomplete=autocomplete,
        )

    @classmethod
    def attachment(cls, name: str, description: str, *, required: bool = True) -> "SlashOption":
        return cls(name=name, description=description, option_type=SlashOptionType.ATTACHMENT, required=required)

    def to_dict(self) -> dict[str, Any]:
        payload = {
            "type": self.option_type,
            "name": self.name,
            "description": self.description,
            "required": self.required,
        }
        if self.choices:
            payload["choices"] = [choice.to_dict() for choice in self.choices]
        if self.min_value is not None:
            payload["min_value"] = self.min_value
        if self.max_value is not None:
            payload["max_value"] = self.max_value
        if self.min_length is not None:
            payload["min_length"] = self.min_length
        if self.max_length is not None:
            payload["max_length"] = self.max_length
        if self.channel_types:
            payload["channel_types"] = list(self.channel_types)
        if self.autocomplete:
            payload["autocomplete"] = True
        return payload


def describe(**parameter_descriptions: str) -> Any:
    def decorator(coro: Any) -> Any:
        current = dict(getattr(coro, DESCRIPTIONS_ATTR, {}))
        current.update(parameter_descriptions)
        setattr(coro, DESCRIPTIONS_ATTR, current)
        return coro

    return decorator


def get_parameter_descriptions(callback: Any) -> dict[str, str]:
    return dict(getattr(callback, DESCRIPTIONS_ATTR, {}))


def infer_slash_options(
    callback: Any,
    *,
    descriptions: dict[str, str] | None = None,
) -> tuple[SlashOption, ...]:
    signature = inspect.signature(callback)
    options: list[SlashOption] = []
    parameter_descriptions = descriptions or get_parameter_descriptions(callback)

    for parameter in tuple(signature.parameters.values())[1:]:
        if parameter.kind not in (
            inspect.Parameter.POSITIONAL_ONLY,
            inspect.Parameter.POSITIONAL_OR_KEYWORD,
            inspect.Parameter.KEYWORD_ONLY,
        ):
            continue
        annotation, required = _unwrap_annotation(parameter.annotation, parameter.default)
        option_type, literal_choices = _option_type_from_annotation(annotation)
        description = parameter_descriptions.get(parameter.name, _default_description(parameter.name))
        choices = tuple(SlashChoice(name=str(value), value=value) for value in literal_choices)
        options.append(
            SlashOption(
                name=parameter.name,
                description=description,
                option_type=option_type,
                required=required,
                choices=choices,
            )
        )

    return tuple(options)


def _unwrap_annotation(annotation: Any, default: Any) -> tuple[Any, bool]:
    if annotation is inspect._empty:
        return str, default is inspect._empty

    origin = get_origin(annotation)
    if origin is Literal:
        return annotation, default is inspect._empty

    if origin in (UnionType, Union):
        args = [item for item in get_args(annotation) if item is not type(None)]
        if len(args) == 1 and len(args) != len(get_args(annotation)):
            return args[0], False

    return annotation, default is inspect._empty


def _option_type_from_annotation(annotation: Any) -> tuple[int, tuple[str | int | float, ...]]:
    origin = get_origin(annotation)
    if origin is Literal:
        values = get_args(annotation)
        if not values:
            return SlashOptionType.STRING, ()
        first = values[0]
        if isinstance(first, bool):
            return SlashOptionType.BOOLEAN, tuple(values)
        if isinstance(first, int) and not isinstance(first, bool):
            return SlashOptionType.INTEGER, tuple(values)
        if isinstance(first, float):
            return SlashOptionType.NUMBER, tuple(values)
        return SlashOptionType.STRING, tuple(str(value) for value in values)

    if annotation is bool:
        return SlashOptionType.BOOLEAN, ()
    if annotation is int:
        return SlashOptionType.INTEGER, ()
    if annotation is float:
        return SlashOptionType.NUMBER, ()
    return SlashOptionType.STRING, ()


def _default_description(name: str) -> str:
    return name.replace("_", " ").capitalize()
