from __future__ import annotations

import asyncio
import contextlib
import importlib
import inspect
import os
import platform
import shlex
import sys
import time
import urllib.parse
from collections.abc import Awaitable, Callable, Iterable, Mapping
from datetime import datetime, timezone
from pathlib import Path
from types import ModuleType, UnionType
from typing import Any, Literal, Union, get_args, get_origin

import aiohttp
import orjson
from aiolimiter import AsyncLimiter
from dotenv import load_dotenv

from .app_commands import SlashOption, infer_slash_options
from .checks import get_callback_checks, get_callback_cooldown
from .cog import Cog, CommandDefinition, ListenerDefinition, SlashCommandDefinition
from .context import Context, SlashContext
from .errors import (
    BadArgument,
    CheckFailure,
    CogError,
    CommandOnCooldown,
    ExtensionAlreadyLoaded,
    ExtensionNotFound,
    ExtensionNotLoaded,
    GatewayError,
    HTTPException,
    MissingRequiredArgument,
    NoEntryPointError,
)
from .intents import Intents
from .logging import Logger, get_logger
from .permissions import Permissions, coerce_permissions
from .utils import chunked


DISCORD_API_BASE = "https://discord.com/api/v10"
DISCORD_GATEWAY_URL = "wss://gateway.discord.gg/?v=10&encoding=json"
DEFAULT_INTENTS = Intents.for_commands()
VALID_STATUSES = {"online", "idle", "dnd", "invisible"}
MISSING = object()


class Bot:
    def __init__(
        self,
        prefix: str | Iterable[str],
        intents: int | Intents | None = None,
        *,
        status: str = "online",
        status_text: str | None = None,
        auto_sync_commands: bool = True,
        enable_logging: bool = False,
        log_level: str | int = "INFO",
        logger: Logger | None = None,
        reconnect: bool = True,
        reconnect_delay: float = 5.0,
        max_reconnects: int | None = None,
        extensions: Iterable[str] | None = None,
        rest_rate_limit_per_second: int | None = 45,
        cache_ttl: float = 300.0,
    ) -> None:
        self.prefixes = self._normalize_prefixes(prefix)
        self.prefix = self.prefixes[0] if len(self.prefixes) == 1 else self.prefixes
        self.intents = self._coerce_intents(intents if intents is not None else DEFAULT_INTENTS.copy())
        self.status = self._validate_status(status)
        self.status_text = status_text
        self.auto_sync_commands = auto_sync_commands
        self.reconnect = reconnect
        self.reconnect_delay = reconnect_delay
        self.max_reconnects = max_reconnects
        self.cache_ttl = float(cache_ttl)
        self.token: str | None = None
        self.user: Mapping[str, Any] | None = None
        self.application_id: str | None = None
        self.session: aiohttp.ClientSession | None = None
        self.ws: aiohttp.ClientWebSocketResponse | None = None
        self.sequence: int | None = None
        self.session_id: str | None = None
        self._resume_gateway_url: str | None = None
        self._events: dict[str, list[ListenerDefinition]] = {}
        self._commands: dict[str, CommandDefinition] = {}
        self._aliases: dict[str, str] = {}
        self._slash_commands: dict[str, SlashCommandDefinition] = {}
        self._cogs: dict[str, Cog] = {}
        self._extensions: dict[str, ModuleType] = {}
        self._startup_extensions = list(extensions or ())
        self._startup_loaded = False
        self._extension_stack: list[str] = []
        self._heartbeat_interval: float | None = None
        self._heartbeat_task: asyncio.Task[None] | None = None
        self._heartbeat_ack = True
        self._last_heartbeat_sent_at: float | None = None
        self._gateway_started_at: float | None = None
        self._tasks: set[asyncio.Task[Any]] = set()
        self._ready = asyncio.Event()
        self._closing = False
        self._http_limiter = (
            AsyncLimiter(rest_rate_limit_per_second, time_period=1)
            if rest_rate_limit_per_second is not None
            else None
        )
        self._guild_cache: dict[str, tuple[float, Mapping[str, Any]]] = {}
        self._guild_roles_cache: dict[str, tuple[float, tuple[Mapping[str, Any], ...]]] = {}
        self.latency: float = 0.0
        self.logger = logger or get_logger("suneord", enabled=enable_logging, level=log_level)
        self.http = self.http_request

    @property
    def commands(self) -> dict[str, Callable[..., Awaitable[Any]]]:
        return {name: command.callback for name, command in self._commands.items()}

    @property
    def slash_commands(self) -> dict[str, dict[str, Any]]:
        return {
            name: {
                "callback": command.callback,
                "name": command.name,
                "description": command.description,
                "guild_id": command.guild_id,
                "options": command.options,
                "default_member_permissions": command.default_member_permissions,
                "dm_permission": command.dm_permission,
                "nsfw": command.nsfw,
                "cog": command.cog,
            }
            for name, command in self._slash_commands.items()
        }

    @property
    def cogs(self) -> dict[str, Cog]:
        return dict(self._cogs)

    @property
    def extensions(self) -> tuple[str, ...]:
        return tuple(self._extensions)

    @property
    def is_ready(self) -> bool:
        return self._ready.is_set()

    @property
    def is_closed(self) -> bool:
        return self._closing

    async def setup_hook(self) -> None:
        return None

    def event(self, coro: Callable[..., Awaitable[Any]]) -> Callable[..., Awaitable[Any]]:
        return self.add_listener(coro, name=coro.__name__)

    def add_listener(
        self,
        coro: Callable[..., Awaitable[Any]],
        *,
        name: str | None = None,
        cog: Cog | None = None,
    ) -> Callable[..., Awaitable[Any]]:
        if not inspect.iscoroutinefunction(coro):
            raise TypeError("Event handler must be async.")
        event_name = (name or coro.__name__).lower()
        if not event_name.startswith("on_"):
            event_name = f"on_{event_name}"
        listener = ListenerDefinition(
            callback=coro,
            event_name=event_name,
            cog=cog,
            extension=self._current_extension,
        )
        self._events.setdefault(event_name, []).append(listener)
        return coro

    def remove_listener(self, coro: Callable[..., Awaitable[Any]], *, name: str | None = None) -> None:
        event_name = (name or coro.__name__).lower()
        if not event_name.startswith("on_"):
            event_name = f"on_{event_name}"
        listeners = self._events.get(event_name, [])
        remaining = [listener for listener in listeners if listener.callback is not coro]
        if remaining:
            self._events[event_name] = remaining
        else:
            self._events.pop(event_name, None)

    def command(
        self,
        name: str | None = None,
        *,
        aliases: Iterable[str] | None = None,
        description: str | None = None,
        usage: str | None = None,
        examples: Iterable[str] | None = None,
        hidden: bool = False,
    ) -> Callable[[Callable[..., Awaitable[Any]]], Callable[..., Awaitable[Any]]]:
        def decorator(coro: Callable[..., Awaitable[Any]]) -> Callable[..., Awaitable[Any]]:
            self.add_command(
                coro,
                name=name,
                aliases=aliases,
                description=description,
                usage=usage,
                examples=examples,
                hidden=hidden,
            )
            return coro

        return decorator

    def add_command(
        self,
        coro: Callable[..., Awaitable[Any]],
        *,
        name: str | None = None,
        aliases: Iterable[str] | None = None,
        description: str | None = None,
        usage: str | None = None,
        examples: Iterable[str] | None = None,
        hidden: bool = False,
        cog: Cog | None = None,
    ) -> Callable[..., Awaitable[Any]]:
        if not inspect.iscoroutinefunction(coro):
            raise TypeError("Command handler must be async.")
        command_name = (name or coro.__name__).lower()
        alias_tuple = tuple(alias.lower() for alias in (aliases or ()))
        if command_name in self._commands or command_name in self._aliases:
            raise CogError(f"Command '{command_name}' is already registered.")
        for alias in alias_tuple:
            if alias in self._aliases or alias in self._commands:
                raise CogError(f"Alias '{alias}' is already registered.")
        function = getattr(coro, "__func__", coro)
        definition = CommandDefinition(
            callback=coro,
            name=command_name,
            aliases=alias_tuple,
            description=description,
            usage=usage,
            examples=tuple(examples or ()),
            hidden=hidden,
            checks=get_callback_checks(function),
            cooldown=get_callback_cooldown(function),
            cog=cog,
            extension=self._current_extension,
        )
        self._commands[command_name] = definition
        for alias in alias_tuple:
            self._aliases[alias] = command_name
        return coro

    def slash_command(
        self,
        *,
        name: str,
        description: str,
        guild_id: str | None = None,
        options: Iterable[SlashOption] | None = None,
        default_member_permissions: int | Permissions | None = None,
        dm_permission: bool = True,
        nsfw: bool = False,
    ) -> Callable[[Callable[..., Awaitable[Any]]], Callable[..., Awaitable[Any]]]:
        def decorator(coro: Callable[..., Awaitable[Any]]) -> Callable[..., Awaitable[Any]]:
            self.add_slash_command(
                coro,
                name=name,
                description=description,
                guild_id=guild_id,
                options=options,
                default_member_permissions=default_member_permissions,
                dm_permission=dm_permission,
                nsfw=nsfw,
            )
            return coro

        return decorator

    def add_slash_command(
        self,
        coro: Callable[..., Awaitable[Any]],
        *,
        name: str,
        description: str,
        guild_id: str | None = None,
        options: Iterable[SlashOption] | None = None,
        default_member_permissions: int | Permissions | None = None,
        dm_permission: bool = True,
        nsfw: bool = False,
        cog: Cog | None = None,
    ) -> Callable[..., Awaitable[Any]]:
        if not inspect.iscoroutinefunction(coro):
            raise TypeError("Slash command handler must be async.")
        command_name = name.lower()
        if command_name in self._slash_commands:
            raise CogError(f"Slash command '{command_name}' is already registered.")
        function = getattr(coro, "__func__", coro)
        resolved_options = tuple(options) if options is not None else infer_slash_options(function)
        self._slash_commands[command_name] = SlashCommandDefinition(
            callback=coro,
            name=command_name,
            description=description,
            guild_id=guild_id,
            options=resolved_options,
            default_member_permissions=coerce_permissions(default_member_permissions),
            dm_permission=dm_permission,
            nsfw=nsfw,
            checks=get_callback_checks(function),
            cooldown=get_callback_cooldown(function),
            cog=cog,
            extension=self._current_extension,
        )
        return coro

    def walk_commands(self) -> list[CommandDefinition]:
        return list(self._commands.values())

    def walk_slash_commands(self) -> list[SlashCommandDefinition]:
        return list(self._slash_commands.values())

    def get_command(self, name: str) -> Callable[..., Awaitable[Any]] | None:
        command_name = self._aliases.get(name.lower(), name.lower())
        command = self._commands.get(command_name)
        return None if command is None else command.callback

    def get_command_definition(self, name: str) -> CommandDefinition | None:
        command_name = self._aliases.get(name.lower(), name.lower())
        return self._commands.get(command_name)

    def get_slash_command(self, name: str) -> Mapping[str, Any] | None:
        command = self._slash_commands.get(name.lower())
        if command is None:
            return None
        return {
            "callback": command.callback,
            "name": command.name,
            "description": command.description,
            "guild_id": command.guild_id,
            "options": command.options,
            "default_member_permissions": command.default_member_permissions,
            "dm_permission": command.dm_permission,
            "nsfw": command.nsfw,
            "cog": command.cog,
        }

    def get_cog(self, name: str) -> Cog | None:
        return self._cogs.get(name)

    def remove_command(self, name: str) -> Callable[..., Awaitable[Any]] | None:
        command_name = self._aliases.pop(name.lower(), name.lower())
        definition = self._commands.pop(command_name, None)
        if definition is None:
            return None
        for alias in definition.aliases:
            self._aliases.pop(alias, None)
        return definition.callback

    def remove_slash_command(self, name: str) -> Mapping[str, Any] | None:
        command = self._slash_commands.pop(name.lower(), None)
        if command is None:
            return None
        return {
            "callback": command.callback,
            "name": command.name,
            "description": command.description,
            "guild_id": command.guild_id,
            "options": command.options,
            "default_member_permissions": command.default_member_permissions,
            "dm_permission": command.dm_permission,
            "nsfw": command.nsfw,
            "cog": command.cog,
        }

    async def add_cog(self, cog: Cog) -> Cog:
        cog_name = cog.qualified_name
        if cog_name in self._cogs:
            raise CogError(f"Cog '{cog_name}' is already loaded.")
        cog.bot = self
        setattr(cog, "__suneord_extension__", self._current_extension)
        self._cogs[cog_name] = cog
        try:
            for command in cog.walk_commands():
                self.add_command(
                    command.callback,
                    name=command.name,
                    aliases=command.aliases,
                    description=command.description,
                    usage=command.usage,
                    examples=command.examples,
                    hidden=command.hidden,
                    cog=cog,
                )
            for slash in cog.walk_slash_commands():
                self.add_slash_command(
                    slash.callback,
                    name=slash.name,
                    description=slash.description,
                    guild_id=slash.guild_id,
                    options=slash.options,
                    default_member_permissions=slash.default_member_permissions,
                    dm_permission=slash.dm_permission,
                    nsfw=slash.nsfw,
                    cog=cog,
                )
            for listener in cog.walk_listeners():
                self.add_listener(listener.callback, name=listener.event_name, cog=cog)
            await self._maybe_await(cog.cog_load())
        except Exception:
            await self._remove_cog_registrations(cog, call_hook=False)
            self._cogs.pop(cog_name, None)
            raise
        return cog

    async def remove_cog(self, name: str) -> Cog | None:
        cog = self._cogs.pop(name, None)
        if cog is None:
            return None
        await self._remove_cog_registrations(cog, call_hook=True)
        return cog

    async def load_extension(self, name: str) -> ModuleType:
        if name in self._extensions:
            raise ExtensionAlreadyLoaded(f"Extension '{name}' is already loaded.")
        try:
            module = importlib.import_module(name)
        except ModuleNotFoundError as exc:
            raise ExtensionNotFound(f"Extension '{name}' was not found.") from exc

        setup = getattr(module, "setup", None)
        if setup is None:
            raise NoEntryPointError(f"Extension '{name}' does not define setup(bot).")

        self._extension_stack.append(name)
        try:
            result = setup(self)
            if inspect.isawaitable(result):
                await result
        except Exception:
            with contextlib.suppress(Exception):
                await self._purge_extension(name)
            sys.modules.pop(name, None)
            raise
        finally:
            self._extension_stack.pop()

        self._extensions[name] = module
        self.logger.info("Loaded extension {}", name)
        return module

    async def unload_extension(self, name: str) -> None:
        module = self._extensions.pop(name, None)
        if module is None:
            raise ExtensionNotLoaded(f"Extension '{name}' is not loaded.")
        await self._purge_extension(name)
        teardown = getattr(module, "teardown", None)
        if teardown is not None:
            result = teardown(self)
            if inspect.isawaitable(result):
                await result
        sys.modules.pop(name, None)
        importlib.invalidate_caches()
        self.logger.info("Unloaded extension {}", name)

    async def reload_extension(self, name: str) -> ModuleType:
        await self.unload_extension(name)
        return await self.load_extension(name)

    async def load_extensions_from(
        self,
        directory: str | Path,
        *,
        package: str | None = None,
        recursive: bool = False,
    ) -> list[str]:
        path = Path(directory)
        if not path.is_absolute() and package is None:
            package = ".".join(path.parts)
        if path.is_absolute() and package is None:
            raise ValueError("package must be provided when loading extensions from an absolute path.")
        pattern = "**/*.py" if recursive else "*.py"
        loaded: list[str] = []
        for file in sorted(path.glob(pattern)):
            if file.name == "__init__.py" or file.name.startswith("_"):
                continue
            relative = file.with_suffix("").relative_to(path)
            module_name = ".".join(part for part in (package, *relative.parts) if part)
            await self.load_extension(module_name)
            loaded.append(module_name)
        return loaded

    def add_startup_extension(self, name: str) -> None:
        if name not in self._startup_extensions:
            self._startup_extensions.append(name)

    async def wait_until_ready(self) -> None:
        await self._ready.wait()

    def enable_logging(self) -> None:
        self.logger.enable()

    def disable_logging(self) -> None:
        self.logger.disable()

    def run(self, token: str) -> None:
        try:
            asyncio.run(self.start(token))
        except KeyboardInterrupt:
            pass

    def run_from_env(
        self,
        env_var: str = "DISCORD_TOKEN",
        *,
        dotenv_path: str | os.PathLike[str] | None = None,
        override: bool = False,
    ) -> None:
        try:
            asyncio.run(self.start_from_env(env_var=env_var, dotenv_path=dotenv_path, override=override))
        except KeyboardInterrupt:
            pass

    async def start_from_env(
        self,
        *,
        env_var: str = "DISCORD_TOKEN",
        dotenv_path: str | os.PathLike[str] | None = None,
        override: bool = False,
    ) -> None:
        load_dotenv(dotenv_path=dotenv_path, override=override)
        token = os.getenv(env_var)
        if not token:
            raise RuntimeError(f"Environment variable '{env_var}' is not set.")
        await self.start(token)

    async def start(self, token: str) -> None:
        self.token = token
        self._ready.clear()
        self._closing = False
        headers = {
            "Authorization": f"Bot {token}",
            "User-Agent": f"suneord (python aiohttp; {platform.system().lower()})",
        }
        async with aiohttp.ClientSession(
            headers=headers,
            json_serialize=_json_dumps,
        ) as session:
            self.session = session
            try:
                await self._load_startup_extensions()
                await self.setup_hook()
                attempts = 0
                while not self._closing:
                    try:
                        await self._connect_gateway()
                    except asyncio.CancelledError:
                        raise
                    except Exception as exc:
                        if self._closing:
                            break
                        if not self.reconnect:
                            raise
                        attempts += 1
                        if self.max_reconnects is not None and attempts > self.max_reconnects:
                            raise
                        self.logger.error(
                            "Gateway disconnected, retrying in {}s",
                            self.reconnect_delay,
                            exc_info=exc,
                        )
                        await self._cleanup_gateway()
                        await asyncio.sleep(self.reconnect_delay)
                        continue
                    else:
                        if self._closing or not self.reconnect:
                            break
                        attempts = 0
                        self.logger.warning("Gateway connection closed, reconnecting in {}s", self.reconnect_delay)
                        await self._cleanup_gateway()
                        await asyncio.sleep(self.reconnect_delay)
            finally:
                await self.close()

    async def close(self) -> None:
        self._closing = True
        self._ready.clear()
        await self._cleanup_gateway()
        if self._tasks:
            tasks = tuple(self._tasks)
            for task in tasks:
                task.cancel()
            for task in tasks:
                with contextlib.suppress(asyncio.CancelledError):
                    await task
            self._tasks.clear()
        if self.session is not None and not self.session.closed:
            await self.session.close()
        self.session = None

    async def http_request(self, method: str, path: str, *, retries: int = 3, **kwargs: Any) -> Any:
        if self.session is None:
            raise RuntimeError("HTTP session is not started.")

        url = path if path.startswith("https://") else f"{DISCORD_API_BASE}{path}"
        for attempt in range(retries + 1):
            limiter = self._http_limiter
            if limiter is None:
                result = await self._request_once(method, url, path, **kwargs)
            else:
                async with limiter:
                    result = await self._request_once(method, url, path, **kwargs)

            if isinstance(result, tuple):
                retry_after, payload = result
                self.logger.warning("Rate limited on {} {}, retry_after={}s", method, path, retry_after)
                if attempt >= retries:
                    raise HTTPException(429, str(payload), payload)
                await asyncio.sleep(retry_after)
                continue
            return result

        raise RuntimeError("HTTP request exhausted all retry attempts.")

    async def send_message(
        self,
        channel_id: str,
        content: str | None = None,
        *,
        embed: Any | None = None,
        embeds: list[Any] | None = None,
        tts: bool = False,
        allowed_mentions: Mapping[str, Any] | None = None,
    ) -> Any:
        payload = self._build_message_payload(
            content=content,
            embed=embed,
            embeds=embeds,
            allowed_mentions=allowed_mentions,
        )
        if tts:
            payload["tts"] = True
        return await self.http_request("POST", f"/channels/{channel_id}/messages", json=payload)

    async def edit_message(
        self,
        channel_id: str,
        message_id: str,
        *,
        content: str | None = None,
        embed: Any | None = None,
        embeds: list[Any] | None = None,
        allowed_mentions: Mapping[str, Any] | None = None,
    ) -> Any:
        payload = self._build_message_payload(
            content=content,
            embed=embed,
            embeds=embeds,
            allowed_mentions=allowed_mentions,
        )
        return await self.http_request("PATCH", f"/channels/{channel_id}/messages/{message_id}", json=payload)

    async def delete_message(self, channel_id: str, message_id: str) -> None:
        await self.http_request("DELETE", f"/channels/{channel_id}/messages/{message_id}")

    async def fetch_message(self, channel_id: str, message_id: str) -> Any:
        return await self.http_request("GET", f"/channels/{channel_id}/messages/{message_id}")

    async def fetch_messages(
        self,
        channel_id: str,
        *,
        limit: int = 50,
        before: str | None = None,
        after: str | None = None,
        around: str | None = None,
    ) -> Any:
        params: dict[str, Any] = {"limit": limit}
        if before is not None:
            params["before"] = before
        if after is not None:
            params["after"] = after
        if around is not None:
            params["around"] = around
        return await self.http_request("GET", f"/channels/{channel_id}/messages", params=params)

    async def bulk_delete_messages(self, channel_id: str, message_ids: Iterable[str]) -> None:
        messages = [str(message_id) for message_id in message_ids]
        if not messages:
            return
        if len(messages) == 1:
            await self.delete_message(channel_id, messages[0])
            return
        for batch in chunked(messages, 100):
            await self.http_request("POST", f"/channels/{channel_id}/messages/bulk-delete", json={"messages": batch})

    async def pin_message(self, channel_id: str, message_id: str) -> None:
        await self.http_request("PUT", f"/channels/{channel_id}/pins/{message_id}")

    async def unpin_message(self, channel_id: str, message_id: str) -> None:
        await self.http_request("DELETE", f"/channels/{channel_id}/pins/{message_id}")

    async def fetch_channel(self, channel_id: str) -> Any:
        return await self.http_request("GET", f"/channels/{channel_id}")

    async def fetch_guild(self, guild_id: str, *, force: bool = False) -> Any:
        cached = self._guild_cache.get(guild_id)
        if not force and cached is not None and (time.monotonic() - cached[0]) < self.cache_ttl:
            return cached[1]
        guild = await self.http_request("GET", f"/guilds/{guild_id}")
        self._guild_cache[guild_id] = (time.monotonic(), guild)
        return guild

    async def fetch_guild_member(self, guild_id: str, user_id: str) -> Any:
        return await self.http_request("GET", f"/guilds/{guild_id}/members/{user_id}")

    async def fetch_guild_roles(self, guild_id: str, *, force: bool = False) -> Any:
        cached = self._guild_roles_cache.get(guild_id)
        if not force and cached is not None and (time.monotonic() - cached[0]) < self.cache_ttl:
            return list(cached[1])
        roles = await self.http_request("GET", f"/guilds/{guild_id}/roles")
        self._guild_roles_cache[guild_id] = (time.monotonic(), tuple(roles))
        return roles

    async def fetch_bans(
        self,
        guild_id: str,
        *,
        limit: int = 1000,
        before: str | None = None,
        after: str | None = None,
    ) -> Any:
        params: dict[str, Any] = {"limit": limit}
        if before is not None:
            params["before"] = before
        if after is not None:
            params["after"] = after
        return await self.http_request("GET", f"/guilds/{guild_id}/bans", params=params)

    async def fetch_user(self, user_id: str) -> Any:
        return await self.http_request("GET", f"/users/{user_id}")

    async def fetch_me(self) -> Any:
        return await self.http_request("GET", "/users/@me")

    async def fetch_bot_member(self, guild_id: str) -> Any:
        if self.user is None:
            raise RuntimeError("Bot user is not available yet.")
        return await self.fetch_guild_member(guild_id, self.user["id"])

    async def create_dm(self, user_id: str) -> Any:
        return await self.http_request("POST", "/users/@me/channels", json={"recipient_id": user_id})

    async def send_dm(
        self,
        user_id: str,
        content: str | None = None,
        *,
        embed: Any | None = None,
        embeds: list[Any] | None = None,
        tts: bool = False,
        allowed_mentions: Mapping[str, Any] | None = None,
    ) -> Any:
        channel = await self.create_dm(user_id)
        return await self.send_message(
            channel["id"],
            content=content,
            embed=embed,
            embeds=embeds,
            tts=tts,
            allowed_mentions=allowed_mentions,
        )

    async def add_reaction(self, channel_id: str, message_id: str, emoji: str) -> None:
        encoded = urllib.parse.quote(emoji)
        await self.http_request("PUT", f"/channels/{channel_id}/messages/{message_id}/reactions/{encoded}/@me")

    async def remove_reaction(self, channel_id: str, message_id: str, emoji: str, user_id: str = "@me") -> None:
        encoded = urllib.parse.quote(emoji)
        await self.http_request("DELETE", f"/channels/{channel_id}/messages/{message_id}/reactions/{encoded}/{user_id}")

    async def trigger_typing(self, channel_id: str) -> None:
        await self.http_request("POST", f"/channels/{channel_id}/typing")

    async def edit_guild_member(
        self,
        guild_id: str,
        user_id: str,
        *,
        nick: str | None | object = MISSING,
        roles: Iterable[str] | None | object = MISSING,
        mute: bool | object = MISSING,
        deaf: bool | object = MISSING,
        channel_id: str | None | object = MISSING,
        communication_disabled_until: datetime | str | None | object = MISSING,
        reason: str | None = None,
    ) -> Any:
        payload: dict[str, Any] = {}
        if nick is not MISSING:
            payload["nick"] = nick
        if roles is not MISSING:
            payload["roles"] = list(roles or ())
        if mute is not MISSING:
            payload["mute"] = bool(mute)
        if deaf is not MISSING:
            payload["deaf"] = bool(deaf)
        if channel_id is not MISSING:
            payload["channel_id"] = channel_id
        if communication_disabled_until is not MISSING:
            payload["communication_disabled_until"] = _to_iso_datetime(communication_disabled_until)
        return await self.http_request(
            "PATCH",
            f"/guilds/{guild_id}/members/{user_id}",
            headers=_headers_with_reason(reason),
            json=payload,
        )

    async def change_nickname(self, guild_id: str, nick: str | None) -> Any:
        return await self.http_request("PATCH", f"/guilds/{guild_id}/members/@me", json={"nick": nick})

    async def timeout_member(
        self,
        guild_id: str,
        user_id: str,
        *,
        until: datetime | str | None,
        reason: str | None = None,
    ) -> Any:
        return await self.edit_guild_member(
            guild_id,
            user_id,
            communication_disabled_until=until,
            reason=reason,
        )

    async def remove_timeout(self, guild_id: str, user_id: str, *, reason: str | None = None) -> Any:
        return await self.timeout_member(guild_id, user_id, until=None, reason=reason)

    async def kick_member(self, guild_id: str, user_id: str, *, reason: str | None = None) -> None:
        await self.http_request(
            "DELETE",
            f"/guilds/{guild_id}/members/{user_id}",
            headers=_headers_with_reason(reason),
        )

    async def ban_member(
        self,
        guild_id: str,
        user_id: str,
        *,
        delete_message_seconds: int = 0,
        reason: str | None = None,
    ) -> None:
        delete_seconds = max(0, min(int(delete_message_seconds), 604800))
        await self.http_request(
            "PUT",
            f"/guilds/{guild_id}/bans/{user_id}",
            headers=_headers_with_reason(reason),
            json={"delete_message_seconds": delete_seconds},
        )

    async def unban_member(self, guild_id: str, user_id: str, *, reason: str | None = None) -> None:
        await self.http_request("DELETE", f"/guilds/{guild_id}/bans/{user_id}", headers=_headers_with_reason(reason))

    async def resolve_guild_permissions(self, guild_id: str, member: Mapping[str, Any]) -> Permissions:
        raw_permissions = member.get("permissions")
        if raw_permissions is not None:
            return Permissions(int(raw_permissions))

        guild = await self.fetch_guild(guild_id)
        user = member.get("user", member)
        user_id = user.get("id")
        if user_id is not None and guild.get("owner_id") == user_id:
            return Permissions.all()

        roles = await self.fetch_guild_roles(guild_id)
        role_map = {role["id"]: role for role in roles}
        value = 0

        everyone_role = role_map.get(guild_id)
        if everyone_role is not None:
            value |= int(everyone_role.get("permissions", 0))

        for role_id in member.get("roles", []):
            role = role_map.get(role_id)
            if role is not None:
                value |= int(role.get("permissions", 0))

        permissions = Permissions(value)
        if permissions.administrator:
            return Permissions.all()
        return permissions

    def clear_cache(self, *, guild_id: str | None = None) -> None:
        if guild_id is None:
            self._guild_cache.clear()
            self._guild_roles_cache.clear()
            return
        self._guild_cache.pop(guild_id, None)
        self._guild_roles_cache.pop(guild_id, None)

    async def sync_application_commands(self) -> None:
        if self.application_id is None:
            raise RuntimeError("Application ID is not available yet.")

        global_commands: list[dict[str, Any]] = []
        guild_commands: dict[str, list[dict[str, Any]]] = {}

        for command in self._slash_commands.values():
            payload = {
                "name": command.name,
                "description": command.description,
                "type": 1,
                "options": [option.to_dict() for option in command.options],
                "dm_permission": command.dm_permission,
                "nsfw": command.nsfw,
            }
            if command.default_member_permissions is not None:
                payload["default_member_permissions"] = str(command.default_member_permissions)
            if command.guild_id is None:
                global_commands.append(payload)
            else:
                guild_commands.setdefault(command.guild_id, []).append(payload)

        await self.http_request("PUT", f"/applications/{self.application_id}/commands", json=global_commands)
        for guild_id, commands in guild_commands.items():
            await self.http_request("PUT", f"/applications/{self.application_id}/guilds/{guild_id}/commands", json=commands)

    async def set_presence(self, *, status: str | None = None, text: str | None = None) -> None:
        if status is not None:
            self.status = self._validate_status(status)
        self.status_text = text
        if self.ws is not None:
            await self.ws.send_json({"op": 3, "d": self._presence_payload()})

    def create_task(self, coro: Awaitable[Any], *, name: str | None = None) -> asyncio.Task[Any]:
        task = asyncio.create_task(coro, name=name)
        self._tasks.add(task)
        task.add_done_callback(self._tasks.discard)
        task.add_done_callback(self._task_done_callback)
        return task

    def dispatch(self, event_name: str, *args: Any) -> None:
        normalized = event_name.lower()
        if not normalized.startswith("on_"):
            normalized = f"on_{normalized}"
        listeners = tuple(self._events.get(normalized, ()))
        for listener in listeners:
            self.create_task(self._run_listener(listener, *args), name=f"listener:{normalized}")

    async def _connect_gateway(self) -> None:
        if self.session is None:
            raise RuntimeError("HTTP session is not started.")
        async with self.session.ws_connect(self._gateway_url()) as ws:
            self.ws = ws
            self._gateway_started_at = time.perf_counter()
            self.logger.info("Connected to Discord gateway")
            await self._gateway_loop()

    async def _cleanup_gateway(self) -> None:
        self._ready.clear()
        if self._heartbeat_task is not None:
            self._heartbeat_task.cancel()
            with contextlib.suppress(asyncio.CancelledError):
                await self._heartbeat_task
            self._heartbeat_task = None
        if self.ws is not None and not self.ws.closed:
            await self.ws.close()
        self.ws = None
        self._heartbeat_interval = None
        self._heartbeat_ack = True
        self._last_heartbeat_sent_at = None

    async def _gateway_loop(self) -> None:
        if self.ws is None:
            raise RuntimeError("Gateway websocket is not started.")
        async for message in self.ws:
            if message.type == aiohttp.WSMsgType.TEXT:
                await self._handle_gateway_payload(_json_loads(message.data))
                continue
            if message.type == aiohttp.WSMsgType.CLOSED:
                return
            if message.type == aiohttp.WSMsgType.ERROR:
                raise GatewayError("Discord gateway websocket error.")

    async def _handle_gateway_payload(self, payload: Mapping[str, Any]) -> None:
        op = payload.get("op")
        event_name = payload.get("t")
        data = payload.get("d")
        self.sequence = payload.get("s", self.sequence)

        if op == 10:
            self._heartbeat_interval = data["heartbeat_interval"] / 1000
            await self._start_heartbeat()
            if self.session_id is not None and self.sequence is not None:
                await self._resume()
            else:
                await self._identify()
            await self._send_heartbeat()
            return

        if op == 11:
            self._heartbeat_ack = True
            if self._last_heartbeat_sent_at is not None:
                self.latency = time.perf_counter() - self._last_heartbeat_sent_at
            return

        if op == 1:
            await self._send_heartbeat()
            return

        if op == 0 and event_name is not None:
            await self._dispatch(event_name, data)
            return

        if op == 7:
            raise GatewayError("Discord gateway requested reconnect.")

        if op == 9:
            if not data:
                self.session_id = None
                self.sequence = None
            raise GatewayError("Discord gateway invalid session.")

    async def _dispatch(self, event_name: str, data: Mapping[str, Any]) -> None:
        if event_name == "READY":
            self.session_id = data["session_id"]
            self.user = data["user"]
            application = data.get("application", {})
            self.application_id = application.get("id") or data["user"].get("id")
            resume_url = data.get("resume_gateway_url")
            if resume_url:
                self._resume_gateway_url = f"{resume_url}/?v=10&encoding=json"
            if self._gateway_started_at is not None:
                self.latency = time.perf_counter() - self._gateway_started_at
            if self.auto_sync_commands and self._slash_commands:
                await self.sync_application_commands()
            self._ready.set()
            self.logger.success("Gateway ready as {}", self.user.get("username", "unknown"))
        elif event_name == "RESUMED":
            self._ready.set()
            self.logger.success("Gateway session resumed")

        self.dispatch(f"on_{event_name.lower()}", *self._build_event_args(event_name, data))

        if event_name == "MESSAGE_CREATE":
            await self._process_message(data)
        elif event_name == "INTERACTION_CREATE":
            await self._process_interaction(data)

    def _build_event_args(self, event_name: str, data: Mapping[str, Any]) -> tuple[Any, ...]:
        if event_name in {"READY", "RESUMED"}:
            return ()
        return (data,)

    async def _process_message(self, message: Mapping[str, Any]) -> None:
        author = message.get("author", {})
        if author.get("bot"):
            return

        content = message.get("content", "")
        prefix = self._match_prefix(content)
        if prefix is None:
            return

        command_line = content[len(prefix) :].strip()
        if not command_line:
            return

        parts = command_line.split(maxsplit=1)
        command_key = parts[0].lower()
        raw_arguments = parts[1] if len(parts) > 1 else ""
        command_name = self._aliases.get(command_key, command_key)
        command = self._commands.get(command_name)
        if command is None:
            return

        ctx = Context(
            self,
            message=message,
            command_name=command.name,
            args=[],
            raw_arguments=raw_arguments,
            prefix=prefix,
            invoked_with=command_key,
            command=command.callback,
            cog=command.cog,
        )
        self.dispatch("on_command", ctx)
        self.create_task(self._invoke_message_command(command, ctx), name=f"command:{command.name}")

    async def _invoke_message_command(self, command: CommandDefinition, ctx: Context) -> None:
        try:
            ctx.args = self._split_message_arguments(ctx.raw_arguments)
            await self._run_command_checks(command, ctx)
            args, kwargs = self._bind_message_command_args(command.callback, ctx.args)
            await command.callback(ctx, *args, **kwargs)
        except asyncio.CancelledError:
            raise
        except Exception as exc:
            await self._handle_command_error("on_command_error", ctx, command.cog, exc)
        else:
            self.dispatch("on_command_completion", ctx)

    async def _process_interaction(self, interaction: Mapping[str, Any]) -> None:
        if interaction.get("type") != 2:
            return
        data = interaction.get("data", {})
        command_name = data.get("name", "").lower()
        command = self._slash_commands.get(command_name)
        if command is None:
            return

        ctx = SlashContext(
            self,
            interaction=interaction,
            command_name=command.name,
            command=command.callback,
            cog=command.cog,
        )
        self.dispatch("on_slash_command", ctx)
        self.create_task(self._invoke_slash_command(command, ctx), name=f"slash:{command.name}")

    async def _invoke_slash_command(self, command: SlashCommandDefinition, ctx: SlashContext) -> None:
        try:
            await self._run_command_checks(command, ctx)
            args, kwargs = self._bind_slash_command_args(command.callback, ctx.options)
            await command.callback(ctx, *args, **kwargs)
        except asyncio.CancelledError:
            raise
        except Exception as exc:
            await self._handle_command_error("on_slash_command_error", ctx, command.cog, exc)
        else:
            self.dispatch("on_slash_command_completion", ctx)

    async def _handle_command_error(
        self,
        event_name: str,
        ctx: Context | SlashContext,
        cog: Cog | None,
        error: Exception,
    ) -> None:
        handled = False
        active_error = error
        if cog is not None:
            try:
                await cog.cog_command_error(ctx, active_error)
                handled = True
            except Exception as cog_error:
                if cog_error is not active_error:
                    active_error = cog_error
        if event_name in self._events:
            self.dispatch(event_name, ctx, active_error)
            handled = True
        if not handled:
            self.logger.exception("Unhandled command error in {}", ctx.command_name, exc_info=active_error)

    async def _run_listener(self, listener: ListenerDefinition, *args: Any) -> None:
        try:
            await listener.callback(*args)
        except asyncio.CancelledError:
            raise
        except Exception as exc:
            if listener.event_name != "on_error" and "on_error" in self._events:
                self.dispatch("on_error", listener.event_name, exc, *args)
                return
            self.logger.exception("Unhandled listener error in {}", listener.event_name, exc_info=exc)

    async def _run_command_checks(self, command: CommandDefinition | SlashCommandDefinition, ctx: Context | SlashContext) -> None:
        for check in command.checks:
            result = await self._maybe_await(check(ctx))
            if result is False:
                raise CheckFailure("A command check returned False.")
        if command.cooldown is not None:
            retry_after = command.cooldown.get_retry_after(ctx)
            if retry_after > 0:
                raise CommandOnCooldown(
                    retry_after,
                    rate=command.cooldown.rate,
                    per=command.cooldown.per,
                    bucket=command.cooldown.bucket,
                )

    async def _start_heartbeat(self) -> None:
        if self._heartbeat_interval is None:
            return
        if self._heartbeat_task is not None and not self._heartbeat_task.done():
            return
        self._heartbeat_task = asyncio.create_task(self._heartbeat_loop(), name="gateway:heartbeat")

    async def _heartbeat_loop(self) -> None:
        assert self._heartbeat_interval is not None
        while True:
            await asyncio.sleep(self._heartbeat_interval)
            if not self._heartbeat_ack:
                if self.ws is not None and not self.ws.closed:
                    await self.ws.close(code=4000, message=b"heartbeat not acknowledged")
                return
            await self._send_heartbeat()

    async def _send_heartbeat(self) -> None:
        if self.ws is None:
            return
        self._heartbeat_ack = False
        self._last_heartbeat_sent_at = time.perf_counter()
        await self.ws.send_json({"op": 1, "d": self.sequence})

    async def _identify(self) -> None:
        if self.ws is None or self.token is None:
            raise RuntimeError("Bot is not ready to identify.")
        await self.ws.send_json(
            {
                "op": 2,
                "d": {
                    "token": self.token,
                    "intents": int(self.intents),
                    "properties": {
                        "os": platform.system().lower(),
                        "browser": "suneord",
                        "device": "suneord",
                    },
                    "presence": self._presence_payload(),
                },
            }
        )

    async def _resume(self) -> None:
        if self.ws is None or self.token is None or self.session_id is None:
            raise RuntimeError("Bot is not ready to resume.")
        await self.ws.send_json(
            {
                "op": 6,
                "d": {
                    "token": self.token,
                    "session_id": self.session_id,
                    "seq": self.sequence,
                },
            }
        )

    def _presence_payload(self) -> dict[str, Any]:
        activities: list[dict[str, Any]] = []
        if self.status_text:
            activities.append({"name": "Custom Status", "type": 4, "state": self.status_text})
        return {
            "since": None,
            "activities": activities,
            "status": self.status,
            "afk": False,
        }

    def _build_message_payload(
        self,
        *,
        content: str | None = None,
        embed: Any | None = None,
        embeds: list[Any] | None = None,
        allowed_mentions: Mapping[str, Any] | None = None,
        message_reference: Mapping[str, Any] | None = None,
        flags: int | None = None,
    ) -> dict[str, Any]:
        payload: dict[str, Any] = {}
        if content is not None:
            payload["content"] = content
        if embed is not None:
            payload["embeds"] = [embed.to_dict() if hasattr(embed, "to_dict") else embed]
        elif embeds is not None:
            payload["embeds"] = [item.to_dict() if hasattr(item, "to_dict") else item for item in embeds]
        if allowed_mentions is not None:
            payload["allowed_mentions"] = dict(allowed_mentions)
        if message_reference is not None:
            payload["message_reference"] = dict(message_reference)
        if flags is not None:
            payload["flags"] = flags
        return payload

    def _validate_status(self, status: str) -> str:
        lowered = status.lower()
        if lowered not in VALID_STATUSES:
            raise ValueError("status must be one of: online, idle, dnd, invisible")
        return lowered

    def _bind_message_command_args(
        self,
        callback: Callable[..., Awaitable[Any]],
        tokens: list[str],
    ) -> tuple[list[Any], dict[str, Any]]:
        params = self._command_parameters(callback)
        remaining = list(tokens)
        args: list[Any] = []
        kwargs: dict[str, Any] = {}

        for parameter in params:
            if parameter.kind is inspect.Parameter.VAR_POSITIONAL:
                args.extend(self._convert_many(remaining, parameter.annotation, parameter.name, is_message=True))
                remaining.clear()
                continue

            if parameter.kind is inspect.Parameter.KEYWORD_ONLY:
                if remaining:
                    value = " ".join(remaining)
                    remaining.clear()
                    kwargs[parameter.name] = self._convert_argument(
                        value,
                        parameter.annotation,
                        parameter.name,
                        is_message=True,
                    )
                    continue
                if parameter.default is not inspect._empty:
                    kwargs[parameter.name] = parameter.default
                    continue
                raise MissingRequiredArgument(parameter.name)

            if not remaining:
                if parameter.default is not inspect._empty:
                    args.append(parameter.default)
                    continue
                raise MissingRequiredArgument(parameter.name)

            raw = remaining.pop(0)
            args.append(self._convert_argument(raw, parameter.annotation, parameter.name, is_message=True))

        if remaining:
            raise BadArgument("Too many arguments were provided.")

        return args, kwargs

    def _bind_slash_command_args(
        self,
        callback: Callable[..., Awaitable[Any]],
        options: Mapping[str, Any],
    ) -> tuple[list[Any], dict[str, Any]]:
        params = self._command_parameters(callback)
        if not params:
            return [], {}

        args: list[Any] = []
        kwargs: dict[str, Any] = {}

        for parameter in params:
            if parameter.kind is inspect.Parameter.VAR_POSITIONAL:
                raise TypeError("Slash commands do not support *args parameters.")

            if parameter.name in options:
                converted = self._convert_argument(
                    options[parameter.name],
                    parameter.annotation,
                    parameter.name,
                    is_message=False,
                )
            elif parameter.default is not inspect._empty:
                converted = parameter.default
            else:
                raise MissingRequiredArgument(parameter.name)

            if parameter.kind is inspect.Parameter.KEYWORD_ONLY:
                kwargs[parameter.name] = converted
            else:
                args.append(converted)

        return args, kwargs

    def _command_parameters(self, callback: Callable[..., Awaitable[Any]]) -> tuple[inspect.Parameter, ...]:
        signature = inspect.signature(callback)
        return tuple(signature.parameters.values())[1:]

    def _split_message_arguments(self, raw_arguments: str) -> list[str]:
        if not raw_arguments.strip():
            return []
        lexer = shlex.shlex(raw_arguments, posix=True)
        lexer.whitespace_split = True
        lexer.commenters = ""
        try:
            return list(lexer)
        except ValueError as exc:
            raise BadArgument(str(exc)) from exc

    def _convert_many(
        self,
        values: Iterable[Any],
        annotation: Any,
        parameter_name: str,
        *,
        is_message: bool,
    ) -> list[Any]:
        return [
            self._convert_argument(value, annotation, parameter_name, is_message=is_message)
            for value in values
        ]

    def _convert_argument(self, value: Any, annotation: Any, parameter_name: str, *, is_message: bool) -> Any:
        resolved = self._unwrap_annotation(annotation)

        literal_values = self._literal_values(resolved)
        if literal_values is not None:
            converted = self._convert_literal(value, literal_values, parameter_name, is_message=is_message)
            return converted

        if resolved in (inspect._empty, Any, object):
            return value
        if resolved is str:
            return str(value)
        if resolved is bool:
            return self._coerce_bool(value, parameter_name)
        if resolved is int:
            return self._coerce_number(int, value, parameter_name)
        if resolved is float:
            return self._coerce_number(float, value, parameter_name)
        if resolved is Permissions:
            return Permissions(self._coerce_number(int, value, parameter_name))
        if resolved is Intents:
            return Intents(self._coerce_number(int, value, parameter_name))
        if inspect.isclass(resolved) and issubclass(resolved, str):
            return resolved(value)
        if inspect.isclass(resolved) and issubclass(resolved, int):
            return resolved(self._coerce_number(int, value, parameter_name))
        return value

    def _unwrap_annotation(self, annotation: Any) -> Any:
        if annotation is inspect._empty:
            return annotation
        origin = get_origin(annotation)
        if origin is None:
            return annotation
        if origin in (UnionType, Union):
            args = [item for item in get_args(annotation) if item is not type(None)]
            if len(args) == 1:
                return args[0]
        return annotation

    def _literal_values(self, annotation: Any) -> tuple[Any, ...] | None:
        if get_origin(annotation) is Literal:
            return tuple(get_args(annotation))
        return None

    def _convert_literal(
        self,
        value: Any,
        literal_values: tuple[Any, ...],
        parameter_name: str,
        *,
        is_message: bool,
    ) -> Any:
        last_error: Exception | None = None
        for literal in literal_values:
            try:
                if isinstance(literal, bool):
                    converted = self._coerce_bool(value, parameter_name)
                elif isinstance(literal, int) and not isinstance(literal, bool):
                    converted = self._coerce_number(int, value, parameter_name)
                elif isinstance(literal, float):
                    converted = self._coerce_number(float, value, parameter_name)
                elif is_message:
                    converted = str(value)
                else:
                    converted = value
                if converted == literal:
                    return converted
            except Exception as exc:
                last_error = exc
        if last_error is not None:
            raise last_error
        raise BadArgument(f"Invalid value for '{parameter_name}'. Expected one of: {', '.join(map(str, literal_values))}.")

    def _coerce_bool(self, value: Any, parameter_name: str) -> bool:
        if isinstance(value, bool):
            return value
        normalized = str(value).strip().lower()
        truthy = {"1", "true", "yes", "y", "on", "enable", "enabled"}
        falsy = {"0", "false", "no", "n", "off", "disable", "disabled"}
        if normalized in truthy:
            return True
        if normalized in falsy:
            return False
        raise BadArgument(f"Could not convert '{parameter_name}' to bool.")

    def _coerce_number(self, converter: Callable[[Any], Any], value: Any, parameter_name: str) -> Any:
        try:
            return converter(value)
        except (TypeError, ValueError) as exc:
            raise BadArgument(f"Could not convert '{parameter_name}' to {converter.__name__}.") from exc

    def _coerce_intents(self, intents: int | Intents) -> Intents:
        if isinstance(intents, Intents):
            return intents.copy()
        return Intents(intents)

    def _normalize_prefixes(self, prefix: str | Iterable[str]) -> tuple[str, ...]:
        if isinstance(prefix, str):
            prefixes = (prefix,)
        else:
            prefixes = tuple(prefix)
        if not prefixes:
            raise ValueError("At least one prefix must be provided.")
        return tuple(sorted(prefixes, key=len, reverse=True))

    def _match_prefix(self, content: str) -> str | None:
        for prefix in self.prefixes:
            if content.startswith(prefix):
                return prefix
        return None

    def _gateway_url(self) -> str:
        return self._resume_gateway_url or DISCORD_GATEWAY_URL

    async def _request_once(self, method: str, url: str, path: str, **kwargs: Any) -> Any:
        assert self.session is not None
        async with self.session.request(method, url, **kwargs) as response:
            if response.status == 204:
                return None
            text = await response.text()
            payload = _try_json(response.content_type, text)
            if response.status == 429:
                retry_after = 1.0
                if isinstance(payload, Mapping):
                    retry_after = float(payload.get("retry_after", 1))
                return retry_after, payload if payload is not None else text
            if response.status >= 400:
                raise HTTPException(response.status, text, payload)
            if payload is not None:
                return payload
            return text

    @property
    def _current_extension(self) -> str | None:
        return self._extension_stack[-1] if self._extension_stack else None

    async def _load_startup_extensions(self) -> None:
        if self._startup_loaded:
            return
        for extension in self._startup_extensions:
            await self.load_extension(extension)
        self._startup_loaded = True

    async def _remove_cog_registrations(self, cog: Cog, *, call_hook: bool) -> None:
        if call_hook:
            await self._maybe_await(cog.cog_unload())

        for command_name, command in list(self._commands.items()):
            if command.cog is cog:
                self.remove_command(command_name)
        for slash_name, command in list(self._slash_commands.items()):
            if command.cog is cog:
                self.remove_slash_command(slash_name)
        for event_name, listeners in list(self._events.items()):
            remaining = [listener for listener in listeners if listener.cog is not cog]
            if remaining:
                self._events[event_name] = remaining
            else:
                self._events.pop(event_name, None)

    async def _purge_extension(self, name: str) -> None:
        for cog_name, cog in list(self._cogs.items()):
            if getattr(cog, "__suneord_extension__", None) == name:
                await self.remove_cog(cog_name)
        for command_name, command in list(self._commands.items()):
            if command.extension == name and command.cog is None:
                self.remove_command(command_name)
        for slash_name, command in list(self._slash_commands.items()):
            if command.extension == name and command.cog is None:
                self.remove_slash_command(slash_name)
        for event_name, listeners in list(self._events.items()):
            remaining = [listener for listener in listeners if listener.extension != name]
            if remaining:
                self._events[event_name] = remaining
            else:
                self._events.pop(event_name, None)

    def _task_done_callback(self, task: asyncio.Task[Any]) -> None:
        with contextlib.suppress(asyncio.CancelledError):
            exception = task.exception()
            if exception is not None:
                self.logger.exception("Background task failed", exc_info=exception)

    async def _maybe_await(self, value: Any) -> Any:
        if inspect.isawaitable(value):
            return await value
        return value


def _headers_with_reason(reason: str | None) -> dict[str, str] | None:
    if not reason:
        return None
    return {"X-Audit-Log-Reason": reason}


def _to_iso_datetime(value: datetime | str | None | object) -> str | None:
    if value is MISSING:
        raise RuntimeError("MISSING sentinel cannot be serialized.")
    if value is None:
        return None
    if isinstance(value, datetime):
        if value.tzinfo is None:
            value = value.replace(tzinfo=timezone.utc)
        return value.astimezone(timezone.utc).isoformat()
    return str(value)


def _json_dumps(data: Any) -> str:
    return orjson.dumps(data).decode("utf-8")


def _json_loads(data: str | bytes | bytearray) -> Any:
    return orjson.loads(data)


def _try_json(content_type: str, text: str) -> Any:
    if content_type == "application/json":
        return _json_loads(text)
    if text and text[:1] in {"{", "["}:
        with contextlib.suppress(orjson.JSONDecodeError):
            return _json_loads(text)
    return None
