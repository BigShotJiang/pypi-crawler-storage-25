from __future__ import annotations

from dataclasses import dataclass


PERMISSION_FLAGS = {
    "create_instant_invite": 1 << 0,
    "kick_members": 1 << 1,
    "ban_members": 1 << 2,
    "administrator": 1 << 3,
    "manage_channels": 1 << 4,
    "manage_guild": 1 << 5,
    "manage_server": 1 << 5,
    "add_reactions": 1 << 6,
    "view_audit_log": 1 << 7,
    "priority_speaker": 1 << 8,
    "stream": 1 << 9,
    "view_channel": 1 << 10,
    "read_messages": 1 << 10,
    "send_messages": 1 << 11,
    "send_tts_messages": 1 << 12,
    "manage_messages": 1 << 13,
    "embed_links": 1 << 14,
    "attach_files": 1 << 15,
    "read_message_history": 1 << 16,
    "mention_everyone": 1 << 17,
    "use_external_emojis": 1 << 18,
    "external_emojis": 1 << 18,
    "view_guild_insights": 1 << 19,
    "view_server_insights": 1 << 19,
    "connect": 1 << 20,
    "speak": 1 << 21,
    "mute_members": 1 << 22,
    "deafen_members": 1 << 23,
    "move_members": 1 << 24,
    "use_vad": 1 << 25,
    "change_nickname": 1 << 26,
    "manage_nicknames": 1 << 27,
    "manage_roles": 1 << 28,
    "manage_permissions": 1 << 28,
    "manage_webhooks": 1 << 29,
    "manage_expressions": 1 << 30,
    "manage_emojis_and_stickers": 1 << 30,
    "use_application_commands": 1 << 31,
    "request_to_speak": 1 << 32,
    "manage_events": 1 << 33,
    "manage_threads": 1 << 34,
    "create_public_threads": 1 << 35,
    "create_private_threads": 1 << 36,
    "use_external_stickers": 1 << 37,
    "send_messages_in_threads": 1 << 38,
    "use_embedded_activities": 1 << 39,
    "moderate_members": 1 << 40,
    "timeout_members": 1 << 40,
    "view_creator_monetization_analytics": 1 << 41,
    "use_soundboard": 1 << 42,
    "create_expressions": 1 << 43,
    "create_events": 1 << 44,
    "use_external_sounds": 1 << 45,
    "send_voice_messages": 1 << 46,
    "send_polls": 1 << 49,
    "use_external_apps": 1 << 50,
}

DEFAULT_PERMISSION_NAMES = (
    "view_channel",
    "send_messages",
    "embed_links",
    "attach_files",
    "read_message_history",
    "use_application_commands",
)

MODERATION_PERMISSION_NAMES = (
    "kick_members",
    "ban_members",
    "moderate_members",
    "manage_messages",
    "view_audit_log",
)


@dataclass(slots=True)
class PermissionInfo:
    name: str
    bit: int


class Permissions:
    """Bitfield helper for Discord guild permissions."""

    __slots__ = ("value",)

    def __init__(self, value: int = 0) -> None:
        self.value = int(value)

    def __repr__(self) -> str:
        enabled = ", ".join(name for name, state in self.to_dict().items() if state)
        return f"Permissions(value={self.value}, enabled=[{enabled}])"

    def __int__(self) -> int:
        return self.value

    def __index__(self) -> int:
        return self.value

    def __or__(self, other: int | "Permissions") -> "Permissions":
        return type(self)(self.value | int(other))

    def __and__(self, other: int | "Permissions") -> "Permissions":
        return type(self)(self.value & int(other))

    def __xor__(self, other: int | "Permissions") -> "Permissions":
        return type(self)(self.value ^ int(other))

    def __ior__(self, other: int | "Permissions") -> "Permissions":
        self.value |= int(other)
        return self

    def __iand__(self, other: int | "Permissions") -> "Permissions":
        self.value &= int(other)
        return self

    def __ixor__(self, other: int | "Permissions") -> "Permissions":
        self.value ^= int(other)
        return self

    def __getattr__(self, name: str) -> bool:
        if name in PERMISSION_FLAGS:
            return self.has(name)
        raise AttributeError(name)

    def __setattr__(self, name: str, value: bool | int) -> None:
        if name == "value":
            object.__setattr__(self, name, int(value))
            return
        if name in PERMISSION_FLAGS:
            self.set(name, bool(value))
            return
        object.__setattr__(self, name, value)

    @classmethod
    def none(cls) -> "Permissions":
        return cls(0)

    @classmethod
    def all(cls) -> "Permissions":
        value = 0
        for bit in PERMISSION_FLAGS.values():
            value |= bit
        return cls(value)

    @classmethod
    def default(cls) -> "Permissions":
        return cls.from_names(*DEFAULT_PERMISSION_NAMES)

    @classmethod
    def moderation(cls) -> "Permissions":
        return cls.from_names(*MODERATION_PERMISSION_NAMES)

    @classmethod
    def from_names(cls, *names: str) -> "Permissions":
        permissions = cls.none()
        permissions.enable(*names)
        return permissions

    @classmethod
    def describe(cls) -> tuple[PermissionInfo, ...]:
        return tuple(PermissionInfo(name=name, bit=bit) for name, bit in PERMISSION_FLAGS.items())

    def copy(self) -> "Permissions":
        return type(self)(self.value)

    def to_int(self) -> int:
        return self.value

    def to_dict(self) -> dict[str, bool]:
        return {name: self.has(name) for name in PERMISSION_FLAGS}

    def has(self, name: str) -> bool:
        bit = self._resolve(name)
        if self.administrator:
            return True
        return bool(self.value & bit)

    def has_all(self, *names: str) -> bool:
        return all(self.has(name) for name in names)

    def has_any(self, *names: str) -> bool:
        return any(self.has(name) for name in names)

    def enable(self, *names: str) -> "Permissions":
        for name in names:
            self.value |= self._resolve(name)
        return self

    def disable(self, *names: str) -> "Permissions":
        for name in names:
            self.value &= ~self._resolve(name)
        return self

    def set(self, name: str, enabled: bool) -> "Permissions":
        if enabled:
            return self.enable(name)
        return self.disable(name)

    def missing(self, *names: str) -> tuple[str, ...]:
        return tuple(name for name in names if not self.has(name))

    def _resolve(self, name: str) -> int:
        normalized = name.lower()
        if normalized not in PERMISSION_FLAGS:
            valid = ", ".join(sorted(PERMISSION_FLAGS))
            raise ValueError(f"Unknown permission '{name}'. Valid permissions: {valid}")
        return PERMISSION_FLAGS[normalized]


def coerce_permissions(value: int | Permissions | None) -> int | None:
    if value is None:
        return None
    return Permissions(int(value)).value
