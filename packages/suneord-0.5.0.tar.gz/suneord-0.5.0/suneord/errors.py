from __future__ import annotations

from typing import Any


class SuneordError(Exception):
    """Base exception for the library."""


class HTTPException(SuneordError):
    """Raised when the Discord API returns an error response."""

    def __init__(self, status: int, message: str, payload: Any | None = None) -> None:
        super().__init__(f"Discord API error {status}: {message}")
        self.status = status
        self.message = message
        self.payload = payload


class GatewayError(SuneordError):
    """Raised when the Discord gateway closes or becomes invalid."""


class CommandError(SuneordError):
    """Base exception for command related failures."""


class CommandNotFound(CommandError):
    """Raised when a command lookup fails."""


class CommandInvokeError(CommandError):
    """Raised when a command callback raises an exception."""

    def __init__(self, original: Exception) -> None:
        super().__init__(f"Command raised an exception: {original}")
        self.original = original


class CheckFailure(CommandError):
    """Raised when a command check fails."""


class BadArgument(CommandError):
    """Raised when argument parsing or conversion fails."""


class MissingRequiredArgument(BadArgument):
    """Raised when a required command argument is missing."""

    def __init__(self, parameter: str) -> None:
        super().__init__(f"Missing required argument: {parameter}")
        self.parameter = parameter


class MissingPermissions(CheckFailure):
    """Raised when the invoking user lacks permissions."""

    def __init__(self, permissions: tuple[str, ...] | list[str]) -> None:
        missing = tuple(permissions)
        super().__init__(f"Missing permissions: {', '.join(missing)}")
        self.missing_permissions = missing


class BotMissingPermissions(CheckFailure):
    """Raised when the bot lacks permissions."""

    def __init__(self, permissions: tuple[str, ...] | list[str]) -> None:
        missing = tuple(permissions)
        super().__init__(f"Bot is missing permissions: {', '.join(missing)}")
        self.missing_permissions = missing


class NoPrivateMessage(CheckFailure):
    """Raised when a guild-only command is used in DMs."""


class PrivateMessageOnly(CheckFailure):
    """Raised when a DM-only command is used in guild channels."""


class CommandOnCooldown(CheckFailure):
    """Raised when a command is on cooldown."""

    def __init__(self, retry_after: float, *, rate: int, per: float, bucket: str) -> None:
        super().__init__(f"Command is on cooldown. Retry in {retry_after:.2f}s.")
        self.retry_after = retry_after
        self.rate = rate
        self.per = per
        self.bucket = bucket


class ExtensionError(SuneordError):
    """Base exception for extension loading failures."""


class ExtensionAlreadyLoaded(ExtensionError):
    """Raised when an extension is already loaded."""


class ExtensionNotLoaded(ExtensionError):
    """Raised when an extension is not loaded."""


class ExtensionNotFound(ExtensionError):
    """Raised when the target extension cannot be imported."""


class NoEntryPointError(ExtensionError):
    """Raised when an extension does not provide setup(bot)."""


class CogError(SuneordError):
    """Raised when cog registration fails."""
