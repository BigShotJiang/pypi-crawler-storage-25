from __future__ import annotations

import inspect
from dataclasses import dataclass
from typing import Any

from .app_commands import SlashOption, get_parameter_descriptions, infer_slash_options
from .checks import get_callback_checks, get_callback_cooldown
from .permissions import coerce_permissions


COMMAND_ATTR = "__suneord_command_meta__"
SLASH_COMMAND_ATTR = "__suneord_slash_command_meta__"
LISTENER_ATTR = "__suneord_listener_meta__"


@dataclass(slots=True)
class CommandDefinition:
    callback: Any
    name: str
    aliases: tuple[str, ...]
    description: str | None = None
    usage: str | None = None
    examples: tuple[str, ...] = ()
    hidden: bool = False
    checks: tuple[Any, ...] = ()
    cooldown: Any | None = None
    cog: Any | None = None
    extension: str | None = None


@dataclass(slots=True)
class SlashCommandDefinition:
    callback: Any
    name: str
    description: str
    guild_id: str | None = None
    options: tuple[SlashOption, ...] = ()
    default_member_permissions: int | None = None
    dm_permission: bool = True
    nsfw: bool = False
    checks: tuple[Any, ...] = ()
    cooldown: Any | None = None
    cog: Any | None = None
    extension: str | None = None


@dataclass(slots=True)
class ListenerDefinition:
    callback: Any
    event_name: str
    cog: Any | None = None
    extension: str | None = None


def command(
    name: str | None = None,
    *,
    aliases: tuple[str, ...] | list[str] | None = None,
    description: str | None = None,
    usage: str | None = None,
    examples: tuple[str, ...] | list[str] | None = None,
    hidden: bool = False,
):
    def decorator(coro: Any) -> Any:
        if not inspect.iscoroutinefunction(coro):
            raise TypeError("Command handler must be async.")
        setattr(
            coro,
            COMMAND_ATTR,
            {
                "name": (name or coro.__name__).lower(),
                "aliases": tuple(alias.lower() for alias in (aliases or ())),
                "description": description,
                "usage": usage,
                "examples": tuple(examples or ()),
                "hidden": hidden,
            },
        )
        return coro

    return decorator


def slash_command(
    *,
    name: str,
    description: str,
    guild_id: str | None = None,
    options: tuple[SlashOption, ...] | list[SlashOption] | None = None,
    default_member_permissions: int | None = None,
    dm_permission: bool = True,
    nsfw: bool = False,
):
    def decorator(coro: Any) -> Any:
        if not inspect.iscoroutinefunction(coro):
            raise TypeError("Slash command handler must be async.")
        resolved_options = tuple(options) if options is not None else infer_slash_options(coro)
        setattr(
            coro,
            SLASH_COMMAND_ATTR,
            {
                "name": name.lower(),
                "description": description,
                "guild_id": guild_id,
                "options": resolved_options,
                "default_member_permissions": coerce_permissions(default_member_permissions),
                "dm_permission": dm_permission,
                "nsfw": nsfw,
                "parameter_descriptions": get_parameter_descriptions(coro),
            },
        )
        return coro

    return decorator


def listener(name: str | None = None):
    def decorator(coro: Any) -> Any:
        if not inspect.iscoroutinefunction(coro):
            raise TypeError("Listener must be async.")
        event_name = (name or coro.__name__).lower()
        if not event_name.startswith("on_"):
            event_name = f"on_{event_name}"
        setattr(coro, LISTENER_ATTR, {"event_name": event_name})
        return coro

    return decorator


class Cog:
    """Base class for class-based command groups."""

    bot: Any | None = None

    @property
    def qualified_name(self) -> str:
        return self.__class__.__name__

    @property
    def description(self) -> str:
        return inspect.getdoc(self.__class__) or ""

    async def cog_load(self) -> None:
        return None

    async def cog_unload(self) -> None:
        return None

    async def cog_command_error(self, ctx: Any, error: Exception) -> None:
        raise error

    def walk_commands(self) -> list[CommandDefinition]:
        commands: list[CommandDefinition] = []
        for _, member in inspect.getmembers(self):
            function = getattr(member, "__func__", member)
            meta = getattr(function, COMMAND_ATTR, None)
            if meta is None:
                continue
            commands.append(
                CommandDefinition(
                    callback=member,
                    name=meta["name"],
                    aliases=meta["aliases"],
                    description=meta["description"],
                    usage=meta["usage"],
                    examples=meta["examples"],
                    hidden=meta["hidden"],
                    checks=get_callback_checks(function),
                    cooldown=get_callback_cooldown(function),
                    cog=self,
                )
            )
        return commands

    def walk_slash_commands(self) -> list[SlashCommandDefinition]:
        commands: list[SlashCommandDefinition] = []
        for _, member in inspect.getmembers(self):
            function = getattr(member, "__func__", member)
            meta = getattr(function, SLASH_COMMAND_ATTR, None)
            if meta is None:
                continue
            commands.append(
                SlashCommandDefinition(
                    callback=member,
                    name=meta["name"],
                    description=meta["description"],
                    guild_id=meta["guild_id"],
                    options=tuple(meta["options"]),
                    default_member_permissions=meta["default_member_permissions"],
                    dm_permission=meta["dm_permission"],
                    nsfw=meta["nsfw"],
                    checks=get_callback_checks(function),
                    cooldown=get_callback_cooldown(function),
                    cog=self,
                )
            )
        return commands

    def walk_listeners(self) -> list[ListenerDefinition]:
        listeners: list[ListenerDefinition] = []
        for _, member in inspect.getmembers(self):
            function = getattr(member, "__func__", member)
            meta = getattr(function, LISTENER_ATTR, None)
            if meta is None:
                continue
            listeners.append(
                ListenerDefinition(
                    callback=member,
                    event_name=meta["event_name"],
                    cog=self,
                )
            )
        return listeners
