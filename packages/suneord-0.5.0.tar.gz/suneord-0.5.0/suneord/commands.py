from __future__ import annotations

from collections.abc import Awaitable, Callable, Iterable
from typing import Any

from .app_commands import describe
from .checks import bot_has_permissions, check, cooldown, dm_only, guild_only, has_permissions
from .cog import Cog, command, listener, slash_command


class Commands:
    def __init__(self, bot: Any) -> None:
        self.bot = bot

    def command(
        self,
        name: str | None = None,
        *,
        aliases: Iterable[str] | None = None,
        description: str | None = None,
        usage: str | None = None,
        examples: Iterable[str] | None = None,
        hidden: bool = False,
    ) -> Callable[[Callable[..., Awaitable[Any]]], Callable[..., Awaitable[Any]]]:
        return self.bot.command(
            name=name,
            aliases=aliases,
            description=description,
            usage=usage,
            examples=examples,
            hidden=hidden,
        )

    def slash_command(
        self,
        *,
        name: str,
        description: str,
        guild_id: str | None = None,
        options: Iterable[Any] | None = None,
        default_member_permissions: int | Any | None = None,
        dm_permission: bool = True,
        nsfw: bool = False,
    ) -> Callable[[Callable[..., Awaitable[Any]]], Callable[..., Awaitable[Any]]]:
        return self.bot.slash_command(
            name=name,
            description=description,
            guild_id=guild_id,
            options=options,
            default_member_permissions=default_member_permissions,
            dm_permission=dm_permission,
            nsfw=nsfw,
        )

    def event(self, coro: Callable[..., Awaitable[Any]]) -> Callable[..., Awaitable[Any]]:
        return self.bot.event(coro)

    async def add_cog(self, cog: Cog) -> Cog:
        return await self.bot.add_cog(cog)

    async def load_extension(self, name: str) -> Any:
        return await self.bot.load_extension(name)


__all__ = [
    "Cog",
    "Commands",
    "bot_has_permissions",
    "check",
    "command",
    "cooldown",
    "describe",
    "dm_only",
    "guild_only",
    "has_permissions",
    "listener",
    "slash_command",
]
