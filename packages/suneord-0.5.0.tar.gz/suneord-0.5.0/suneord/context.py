from __future__ import annotations

import asyncio
import re
from collections.abc import Mapping
from datetime import datetime
from typing import Any

from .colors import Colors
from .embeds import Embed
from .errors import NoPrivateMessage
from .permissions import Permissions


class TypingIndicator:
    def __init__(self, bot: Any, channel_id: str, *, interval: float = 8.0) -> None:
        self.bot = bot
        self.channel_id = channel_id
        self.interval = interval
        self._task: asyncio.Task[None] | None = None

    def __await__(self):
        return self._send_once().__await__()

    async def __aenter__(self) -> "TypingIndicator":
        await self._send_once()
        self._task = asyncio.create_task(self._loop())
        return self

    async def __aexit__(self, exc_type: Any, exc: Any, tb: Any) -> None:
        if self._task is not None:
            self._task.cancel()
            try:
                await self._task
            except asyncio.CancelledError:
                pass
            self._task = None

    async def _loop(self) -> None:
        while True:
            await asyncio.sleep(self.interval)
            await self._send_once()

    async def _send_once(self) -> None:
        await self.bot.trigger_typing(self.channel_id)


class _Asset:
    def __init__(self, url: str | None) -> None:
        self.url = url

    def __str__(self) -> str:
        return self.url or ""


class _Author:
    def __init__(self, data: Mapping[str, Any], member: Mapping[str, Any] | None = None) -> None:
        self._data = data
        self._member = member or {}
        avatar_hash = data.get("avatar")
        user_id = data.get("id")
        avatar_url = None
        if avatar_hash and user_id:
            avatar_url = f"https://cdn.discordapp.com/avatars/{user_id}/{avatar_hash}.png"
        self.avatar = _Asset(avatar_url)
        self.display_avatar = self.avatar

    @property
    def id(self) -> str | None:
        return self._data.get("id")

    @property
    def name(self) -> str | None:
        return self._data.get("username")

    @property
    def display_name(self) -> str | None:
        return self._member.get("nick") or self._data.get("global_name") or self._data.get("username")

    @property
    def bot(self) -> bool:
        return bool(self._data.get("bot"))

    @property
    def mention(self) -> str:
        return f"<@{self.id}>"

    @property
    def permissions(self) -> int | None:
        value = self._member.get("permissions")
        return None if value is None else int(value)

    @property
    def raw(self) -> Mapping[str, Any]:
        return self._data


class _Channel:
    def __init__(self, data: Mapping[str, Any] | None, channel_id: str | None) -> None:
        self._data = data or {}
        self.id = channel_id or self._data.get("id")

    @property
    def name(self) -> str | None:
        return self._data.get("name")

    @property
    def mention(self) -> str:
        return f"<#{self.id}>"

    @property
    def raw(self) -> Mapping[str, Any]:
        return self._data


class _Guild:
    def __init__(self, guild_id: str | None) -> None:
        self.id = guild_id

    @property
    def raw(self) -> dict[str, Any]:
        return {"id": self.id}


class _BaseContext:
    def __init__(
        self,
        bot: Any,
        *,
        command_name: str,
        command: Any | None,
        cog: Any | None,
        invoked_with: str | None = None,
    ) -> None:
        self.bot = bot
        self.command_name = command_name
        self.command = command
        self.cog = cog
        self.invoked_with = invoked_with or command_name

    @property
    def author_id(self) -> str | None:
        return self.author.id

    @property
    def guild(self) -> _Guild:
        return _Guild(self.guild_id)

    @property
    def channel(self) -> _Channel:
        return _Channel(None, self.channel_id)

    def typing(self) -> TypingIndicator:
        return TypingIndicator(self.bot, self.channel_id)

    def require_guild(self) -> str:
        if self.guild_id is None:
            raise NoPrivateMessage("This action requires a guild context.")
        return self.guild_id

    async def respond(self, *args: Any, **kwargs: Any) -> Mapping[str, Any]:
        return await self.reply(*args, **kwargs)

    async def fetch_message(self, message_id: str | None = None) -> Mapping[str, Any]:
        target = message_id or self.message_id
        if target is None:
            raise RuntimeError("No message_id is available.")
        return await self.bot.fetch_message(self.channel_id, target)

    async def history(
        self,
        *,
        limit: int = 50,
        before: str | None = None,
        after: str | None = None,
        around: str | None = None,
    ) -> Any:
        return await self.bot.fetch_messages(
            self.channel_id,
            limit=limit,
            before=before,
            after=after,
            around=around,
        )

    async def pin(self, message_id: str | None = None) -> None:
        target = message_id or self.message_id
        if target is None:
            raise RuntimeError("No message_id is available.")
        await self.bot.pin_message(self.channel_id, target)

    async def unpin(self, message_id: str | None = None) -> None:
        target = message_id or self.message_id
        if target is None:
            raise RuntimeError("No message_id is available.")
        await self.bot.unpin_message(self.channel_id, target)

    async def fetch_channel(self) -> Mapping[str, Any]:
        return await self.bot.fetch_channel(self.channel_id)

    async def fetch_guild(self) -> Mapping[str, Any]:
        return await self.bot.fetch_guild(self.require_guild())

    async def fetch_author(self) -> Mapping[str, Any]:
        if self.author_id is None:
            raise RuntimeError("No author_id is available.")
        return await self.bot.fetch_user(self.author_id)

    async def fetch_member(self, user_id: str | None = None) -> Mapping[str, Any]:
        guild_id = self.require_guild()
        target_id = user_id or self.author_id
        if target_id is None:
            raise RuntimeError("No user_id is available.")
        return await self.bot.fetch_guild_member(guild_id, target_id)

    async def author_permissions(self) -> Permissions:
        guild_id = self.require_guild()
        if self.author.permissions is not None:
            return Permissions(self.author.permissions)
        member = await self.fetch_member(self.author_id)
        return await self.bot.resolve_guild_permissions(guild_id, member)

    async def bot_permissions(self) -> Permissions:
        guild_id = self.require_guild()
        member = await self.bot.fetch_bot_member(guild_id)
        return await self.bot.resolve_guild_permissions(guild_id, member)

    async def send_dm(
        self,
        content: str | None = None,
        *,
        embed: Embed | None = None,
        embeds: list[Embed] | None = None,
    ) -> Mapping[str, Any]:
        if self.author_id is None:
            raise RuntimeError("No author_id is available.")
        return await self.bot.send_dm(self.author_id, content=content, embed=embed, embeds=embeds)

    async def sleep(self, seconds: float) -> None:
        await asyncio.sleep(seconds)

    async def kick(self, target: str | None = None, *, reason: str | None = None) -> None:
        guild_id = self.require_guild()
        user = await self.resolve_user(target)
        if user.id is None:
            raise RuntimeError("Resolved user does not have an id.")
        await self.bot.kick_member(guild_id, user.id, reason=reason)

    async def ban(
        self,
        target: str | None = None,
        *,
        delete_message_seconds: int = 0,
        reason: str | None = None,
    ) -> None:
        guild_id = self.require_guild()
        user = await self.resolve_user(target)
        if user.id is None:
            raise RuntimeError("Resolved user does not have an id.")
        await self.bot.ban_member(
            guild_id,
            user.id,
            delete_message_seconds=delete_message_seconds,
            reason=reason,
        )

    async def unban(self, target: str | None = None, *, reason: str | None = None) -> None:
        guild_id = self.require_guild()
        user = await self.resolve_user(target)
        if user.id is None:
            raise RuntimeError("Resolved user does not have an id.")
        await self.bot.unban_member(guild_id, user.id, reason=reason)

    async def timeout(self, target: str | None = None, *, until: datetime | str | None, reason: str | None = None) -> None:
        guild_id = self.require_guild()
        user = await self.resolve_user(target)
        if user.id is None:
            raise RuntimeError("Resolved user does not have an id.")
        await self.bot.timeout_member(guild_id, user.id, until=until, reason=reason)

    async def remove_timeout(self, target: str | None = None, *, reason: str | None = None) -> None:
        guild_id = self.require_guild()
        user = await self.resolve_user(target)
        if user.id is None:
            raise RuntimeError("Resolved user does not have an id.")
        await self.bot.remove_timeout(guild_id, user.id, reason=reason)

    async def resolve_user(self, value: str | None = None) -> _Author:
        resolved = await self.resolve_user_or_none(value)
        if resolved is not None:
            return resolved
        raise ValueError("Could not resolve a user from the provided mention or ID.")

    async def resolve_user_or_none(self, value: str | None = None) -> _Author | None:
        user_id = self._extract_user_id(value)
        local = self._find_local_user(user_id)
        if local is not None:
            return local
        if user_id is None:
            return None

        if self.guild_id is not None:
            try:
                member = await self.bot.fetch_guild_member(self.guild_id, user_id)
            except Exception:
                member = None
            if member is not None:
                return _Author(member.get("user", {}), member)

        user = await self.bot.fetch_user(user_id)
        return _Author(user)

    async def send_success(
        self,
        description: str,
        *,
        title: str = "Success",
        ephemeral: bool = False,
    ) -> Mapping[str, Any]:
        embed = self._status_embed(title, description, Colors.SUCCESS)
        return await self.send(embed=embed, ephemeral=ephemeral)

    async def send_info(
        self,
        description: str,
        *,
        title: str = "Info",
        ephemeral: bool = False,
    ) -> Mapping[str, Any]:
        embed = self._status_embed(title, description, Colors.INFO)
        return await self.send(embed=embed, ephemeral=ephemeral)

    async def send_warning(
        self,
        description: str,
        *,
        title: str = "Warning",
        ephemeral: bool = False,
    ) -> Mapping[str, Any]:
        embed = self._status_embed(title, description, Colors.WARNING)
        return await self.send(embed=embed, ephemeral=ephemeral)

    async def send_error(
        self,
        description: str,
        *,
        title: str = "Error",
        ephemeral: bool = False,
    ) -> Mapping[str, Any]:
        embed = self._status_embed(title, description, Colors.ERROR)
        return await self.send(embed=embed, ephemeral=ephemeral)

    async def reply_success(
        self,
        description: str,
        *,
        title: str = "Success",
        ephemeral: bool = False,
    ) -> Mapping[str, Any]:
        embed = self._status_embed(title, description, Colors.SUCCESS)
        return await self.reply(embed=embed, ephemeral=ephemeral)

    async def reply_info(
        self,
        description: str,
        *,
        title: str = "Info",
        ephemeral: bool = False,
    ) -> Mapping[str, Any]:
        embed = self._status_embed(title, description, Colors.INFO)
        return await self.reply(embed=embed, ephemeral=ephemeral)

    async def reply_warning(
        self,
        description: str,
        *,
        title: str = "Warning",
        ephemeral: bool = False,
    ) -> Mapping[str, Any]:
        embed = self._status_embed(title, description, Colors.WARNING)
        return await self.reply(embed=embed, ephemeral=ephemeral)

    async def reply_error(
        self,
        description: str,
        *,
        title: str = "Error",
        ephemeral: bool = False,
    ) -> Mapping[str, Any]:
        embed = self._status_embed(title, description, Colors.ERROR)
        return await self.reply(embed=embed, ephemeral=ephemeral)

    def _status_embed(self, title: str, description: str, colour: int) -> Embed:
        return Embed(title=title, description=description, colour=colour)

    def _find_local_user(self, user_id: str | None) -> _Author | None:
        for user, member in self._iter_local_users():
            author = _Author(user, member)
            if user_id is None or author.id == user_id:
                return author
        return None

    def _iter_local_users(self) -> list[tuple[Mapping[str, Any], Mapping[str, Any] | None]]:
        return []

    def _extract_user_id(self, value: str | None) -> str | None:
        if value is None:
            return None
        candidate = str(value).strip()
        if not candidate:
            return None
        match = re.fullmatch(r"<@!?(\d+)>", candidate)
        if match is not None:
            return match.group(1)
        if candidate.isdigit():
            return candidate
        return None


class Context(_BaseContext):
    def __init__(
        self,
        bot: Any,
        *,
        message: Mapping[str, Any],
        command_name: str,
        args: list[str],
        raw_arguments: str = "",
        prefix: str | None = None,
        invoked_with: str | None = None,
        command: Any | None = None,
        cog: Any | None = None,
    ) -> None:
        super().__init__(bot, command_name=command_name, command=command, cog=cog, invoked_with=invoked_with)
        self.message = message
        self.args = args
        self.raw_arguments = raw_arguments
        self.prefix = prefix

    @property
    def author(self) -> _Author:
        return _Author(self.message["author"], self.message.get("member"))

    @property
    def channel_id(self) -> str:
        return self.message["channel_id"]

    @property
    def guild_id(self) -> str | None:
        return self.message.get("guild_id")

    @property
    def message_id(self) -> str | None:
        return self.message.get("id")

    @property
    def content(self) -> str:
        return self.message.get("content", "")

    @property
    def mentions(self) -> list[_Author]:
        return [_Author(user) for user in self.message.get("mentions", [])]

    @property
    def is_dm(self) -> bool:
        return self.guild_id is None

    @property
    def is_slash(self) -> bool:
        return False

    @property
    def options(self) -> dict[str, Any]:
        return {}

    @property
    def raw(self) -> Mapping[str, Any]:
        return self.message

    async def send(
        self,
        content: str | None = None,
        *,
        embed: Embed | None = None,
        embeds: list[Embed] | None = None,
        tts: bool = False,
        allowed_mentions: Mapping[str, Any] | None = None,
        ephemeral: bool = False,
    ) -> Mapping[str, Any]:
        if ephemeral:
            raise TypeError("ephemeral is only supported in SlashContext.")
        return await self.bot.send_message(
            self.channel_id,
            content=content,
            embed=embed,
            embeds=embeds,
            tts=tts,
            allowed_mentions=allowed_mentions,
        )

    async def reply(
        self,
        content: str | None = None,
        *,
        embed: Embed | None = None,
        embeds: list[Embed] | None = None,
        mention_author: bool = True,
        allowed_mentions: Mapping[str, Any] | None = None,
        ephemeral: bool = False,
    ) -> Mapping[str, Any]:
        if ephemeral:
            raise TypeError("ephemeral is only supported in SlashContext.")
        mentions = dict(allowed_mentions or {})
        mentions["replied_user"] = mention_author
        payload = self.bot._build_message_payload(
            content=content,
            embed=embed,
            embeds=embeds,
            allowed_mentions=mentions,
            message_reference={"message_id": self.message["id"]},
        )
        return await self.bot.http_request("POST", f"/channels/{self.channel_id}/messages", json=payload)

    async def edit(
        self,
        message_id: str,
        *,
        content: str | None = None,
        embed: Embed | None = None,
        embeds: list[Embed] | None = None,
        allowed_mentions: Mapping[str, Any] | None = None,
    ) -> Mapping[str, Any]:
        return await self.bot.edit_message(
            self.channel_id,
            message_id,
            content=content,
            embed=embed,
            embeds=embeds,
            allowed_mentions=allowed_mentions,
        )

    async def delete(self, message_id: str | None = None) -> None:
        target = message_id or self.message_id
        if target is None:
            raise RuntimeError("No message_id is available.")
        await self.bot.delete_message(self.channel_id, target)

    async def fetch_reply(self) -> Mapping[str, Any]:
        return await self.fetch_message()

    async def react(self, emoji: str) -> None:
        if self.message_id is None:
            raise RuntimeError("No message_id is available.")
        await self.bot.add_reaction(self.channel_id, self.message_id, emoji)

    def _iter_local_users(self) -> list[tuple[Mapping[str, Any], Mapping[str, Any] | None]]:
        return [(user, None) for user in self.message.get("mentions", [])]


class SlashContext(_BaseContext):
    def __init__(
        self,
        bot: Any,
        *,
        interaction: Mapping[str, Any],
        command_name: str,
        command: Any | None = None,
        cog: Any | None = None,
    ) -> None:
        super().__init__(bot, command_name=command_name, command=command, cog=cog)
        self.interaction = interaction
        self._responded = False

    @property
    def id(self) -> str:
        return self.interaction["id"]

    @property
    def token(self) -> str:
        return self.interaction["token"]

    @property
    def application_id(self) -> str:
        return self.interaction["application_id"]

    @property
    def channel_id(self) -> str:
        return self.interaction["channel_id"]

    @property
    def guild_id(self) -> str | None:
        return self.interaction.get("guild_id")

    @property
    def message_id(self) -> None:
        return None

    @property
    def is_dm(self) -> bool:
        return self.guild_id is None

    @property
    def is_slash(self) -> bool:
        return True

    @property
    def data(self) -> Mapping[str, Any]:
        return self.interaction.get("data", {})

    @property
    def subcommand_path(self) -> tuple[str, ...]:
        items = self.data.get("options", [])
        path: list[str] = []
        while items:
            item = items[0]
            if item.get("type") not in (1, 2):
                break
            path.append(item["name"])
            items = item.get("options", [])
        return tuple(path)

    @property
    def options(self) -> dict[str, Any]:
        return _flatten_options(self.data.get("options", []))

    @property
    def args(self) -> list[Any]:
        return list(self.options.values())

    @property
    def content(self) -> str:
        return ""

    @property
    def author(self) -> _Author:
        member = self.interaction.get("member", {})
        user = member.get("user") or self.interaction.get("user") or {}
        return _Author(user, member)

    @property
    def raw(self) -> Mapping[str, Any]:
        return self.interaction

    async def reply(
        self,
        content: str | None = None,
        *,
        embed: Embed | None = None,
        embeds: list[Embed] | None = None,
        mention_author: bool = False,
        allowed_mentions: Mapping[str, Any] | None = None,
        ephemeral: bool = False,
    ) -> Mapping[str, Any]:
        if self._responded:
            return await self.send(
                content=content,
                embed=embed,
                embeds=embeds,
                allowed_mentions=allowed_mentions,
                ephemeral=ephemeral,
            )
        mentions = dict(allowed_mentions or {})
        if mention_author:
            mentions["replied_user"] = True
        payload = self.bot._build_message_payload(
            content=content,
            embed=embed,
            embeds=embeds,
            allowed_mentions=mentions or None,
            flags=(1 << 6) if ephemeral else None,
        )
        await self.bot.http_request(
            "POST",
            f"/interactions/{self.id}/{self.token}/callback",
            json={"type": 4, "data": payload},
        )
        self._responded = True
        return {}

    async def send(
        self,
        content: str | None = None,
        *,
        embed: Embed | None = None,
        embeds: list[Embed] | None = None,
        tts: bool = False,
        allowed_mentions: Mapping[str, Any] | None = None,
        ephemeral: bool = False,
    ) -> Mapping[str, Any]:
        if not self._responded:
            return await self.reply(
                content=content,
                embed=embed,
                embeds=embeds,
                allowed_mentions=allowed_mentions,
                ephemeral=ephemeral,
            )
        payload = self.bot._build_message_payload(
            content=content,
            embed=embed,
            embeds=embeds,
            allowed_mentions=allowed_mentions,
            flags=(1 << 6) if ephemeral else None,
        )
        if tts:
            payload["tts"] = True
        return await self.bot.http_request("POST", f"/webhooks/{self.application_id}/{self.token}", json=payload)

    async def defer(self, *, ephemeral: bool = False) -> None:
        if self._responded:
            return
        data: dict[str, Any] = {}
        if ephemeral:
            data["flags"] = 1 << 6
        await self.bot.http_request(
            "POST",
            f"/interactions/{self.id}/{self.token}/callback",
            json={"type": 5, "data": data},
        )
        self._responded = True

    async def edit(
        self,
        *,
        content: str | None = None,
        embed: Embed | None = None,
        embeds: list[Embed] | None = None,
        allowed_mentions: Mapping[str, Any] | None = None,
    ) -> Mapping[str, Any]:
        payload = self.bot._build_message_payload(
            content=content,
            embed=embed,
            embeds=embeds,
            allowed_mentions=allowed_mentions,
        )
        return await self.bot.http_request(
            "PATCH",
            f"/webhooks/{self.application_id}/{self.token}/messages/@original",
            json=payload,
        )

    async def delete(self) -> None:
        await self.bot.http_request("DELETE", f"/webhooks/{self.application_id}/{self.token}/messages/@original")

    async def fetch_original_response(self) -> Mapping[str, Any]:
        return await self.bot.http_request("GET", f"/webhooks/{self.application_id}/{self.token}/messages/@original")

    async def react(self, emoji: str) -> None:
        message = await self.fetch_original_response()
        await self.bot.add_reaction(self.channel_id, message["id"], emoji)

    async def followup(
        self,
        content: str | None = None,
        *,
        embed: Embed | None = None,
        embeds: list[Embed] | None = None,
        ephemeral: bool = False,
        allowed_mentions: Mapping[str, Any] | None = None,
    ) -> Mapping[str, Any]:
        return await self.send(
            content=content,
            embed=embed,
            embeds=embeds,
            ephemeral=ephemeral,
            allowed_mentions=allowed_mentions,
        )

    def _iter_local_users(self) -> list[tuple[Mapping[str, Any], Mapping[str, Any] | None]]:
        resolved = self.data.get("resolved", {})
        users = resolved.get("users", {})
        members = resolved.get("members", {})
        items: list[tuple[Mapping[str, Any], Mapping[str, Any] | None]] = []
        for user_id, user in users.items():
            member = members.get(user_id)
            if member is not None:
                member = dict(member)
                member.setdefault("user", user)
            items.append((user, member))
        return items


def _flatten_options(options: list[Mapping[str, Any]]) -> dict[str, Any]:
    flattened: dict[str, Any] = {}
    for item in options:
        name = item["name"]
        nested = item.get("options")
        if nested:
            flattened.update(_flatten_options(nested))
            continue
        flattened[name] = item.get("value")
    return flattened
