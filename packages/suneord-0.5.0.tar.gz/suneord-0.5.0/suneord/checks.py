from __future__ import annotations

import time
from collections import deque
from collections.abc import Awaitable, Callable, Iterable
from typing import Any

from .errors import (
    BotMissingPermissions,
    CommandOnCooldown,
    MissingPermissions,
    NoPrivateMessage,
    PrivateMessageOnly,
)


CHECKS_ATTR = "__suneord_checks__"
COOLDOWN_ATTR = "__suneord_cooldown__"

CheckCallable = Callable[[Any], Awaitable[None] | None]


class Cooldown:
    def __init__(self, rate: int, per: float, *, bucket: str = "user") -> None:
        if rate <= 0:
            raise ValueError("rate must be greater than 0")
        if per <= 0:
            raise ValueError("per must be greater than 0")
        self.rate = int(rate)
        self.per = float(per)
        self.bucket = bucket
        self._entries: dict[Any, deque[float]] = {}

    def copy(self) -> "Cooldown":
        return type(self)(self.rate, self.per, bucket=self.bucket)

    def get_retry_after(self, ctx: Any) -> float:
        key = self._bucket_key(ctx)
        now = time.monotonic()
        window = self._entries.setdefault(key, deque())
        self._purge(window, now)
        if len(window) < self.rate:
            window.append(now)
            return 0.0
        retry_after = self.per - (now - window[0])
        return max(retry_after, 0.0)

    def _purge(self, entries: deque[float], now: float) -> None:
        while entries and (now - entries[0]) >= self.per:
            entries.popleft()

    def _bucket_key(self, ctx: Any) -> Any:
        if self.bucket == "global":
            return "global"
        if self.bucket == "user":
            return ctx.author_id or "anonymous"
        if self.bucket == "guild":
            return ctx.guild_id or f"dm:{ctx.author_id}"
        if self.bucket == "channel":
            return ctx.channel_id
        if self.bucket == "member":
            return (ctx.guild_id, ctx.author_id)
        raise ValueError("bucket must be one of: global, user, guild, channel, member")


def check(predicate: CheckCallable) -> Callable[[Any], Any]:
    def decorator(coro: Any) -> Any:
        checks = list(getattr(coro, CHECKS_ATTR, ()))
        checks.append(predicate)
        setattr(coro, CHECKS_ATTR, tuple(checks))
        return coro

    return decorator


def cooldown(rate: int, per: float, *, bucket: str = "user") -> Callable[[Any], Any]:
    def decorator(coro: Any) -> Any:
        setattr(coro, COOLDOWN_ATTR, Cooldown(rate, per, bucket=bucket))
        return coro

    return decorator


def guild_only() -> Callable[[Any], Any]:
    async def predicate(ctx: Any) -> None:
        if ctx.guild_id is None:
            raise NoPrivateMessage("This command can only be used in guild channels.")

    return check(predicate)


def dm_only() -> Callable[[Any], Any]:
    async def predicate(ctx: Any) -> None:
        if ctx.guild_id is not None:
            raise PrivateMessageOnly("This command can only be used in direct messages.")

    return check(predicate)


def has_permissions(*permissions: str) -> Callable[[Any], Any]:
    async def predicate(ctx: Any) -> None:
        current = await ctx.author_permissions()
        missing = current.missing(*permissions)
        if missing:
            raise MissingPermissions(missing)

    return check(predicate)


def bot_has_permissions(*permissions: str) -> Callable[[Any], Any]:
    async def predicate(ctx: Any) -> None:
        current = await ctx.bot_permissions()
        missing = current.missing(*permissions)
        if missing:
            raise BotMissingPermissions(missing)

    return check(predicate)


def get_callback_checks(callback: Any) -> tuple[CheckCallable, ...]:
    return tuple(getattr(callback, CHECKS_ATTR, ()))


def get_callback_cooldown(callback: Any) -> Cooldown | None:
    template = getattr(callback, COOLDOWN_ATTR, None)
    if template is None:
        return None
    return template.copy()
