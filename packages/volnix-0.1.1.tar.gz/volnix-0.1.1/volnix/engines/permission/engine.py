"""Permission engine implementation.

Checks actor permissions, computes visibility scopes, and enforces
authority boundaries as a pipeline step. All permission rules come
from the actor's YAML-defined permissions — no hardcoded conditions.
"""

from __future__ import annotations

import logging
from datetime import UTC, datetime
from typing import Any, ClassVar

from volnix.core import (
    ActionContext,
    ActorId,
    BaseEngine,
    EntityId,
    Event,
    StepResult,
    StepVerdict,
    WorldMode,
)
from volnix.core.events import PermissionDeniedEvent
from volnix.core.types import Timestamp

logger = logging.getLogger(__name__)


def _now_timestamp() -> Timestamp:
    """Create a Timestamp for the current moment."""
    now = datetime.now(UTC)
    return Timestamp(world_time=now, wall_time=now, tick=0)


class PermissionEngine(BaseEngine):
    """Checks actor permissions against the ActorRegistry.

    Also acts as the ``permission`` pipeline step.
    """

    engine_name: ClassVar[str] = "permission"
    subscriptions: ClassVar[list[str]] = []
    dependencies: ClassVar[list[str]] = ["state"]

    def __init__(self) -> None:
        super().__init__()
        self._actor_registry: Any = None
        self._pack_registry: Any = None
        self._world_mode: str = "governed"
        from volnix.engines.permission.config import PermissionConfig

        self._typed_config: PermissionConfig = PermissionConfig()

    # -- PipelineStep interface ------------------------------------------------

    @property
    def step_name(self) -> str:
        """Return the pipeline step name."""
        return "permission"

    async def execute(self, ctx: ActionContext) -> StepResult:
        """Check actor permissions for this action.

        Looks up the actor from the ActorRegistry and checks:
        1. Write access to the target service
        2. Read access to the target service (for read-like actions)

        In ungoverned mode, permission violations are logged but not blocked.
        Unknown actors (not in registry) are allowed through.
        """
        actor = self._get_actor(ctx.actor_id)
        logger.debug(
            "Permission check: actor_id=%s, found=%s",
            ctx.actor_id,
            actor is not None,
        )
        if actor is None:
            if self._is_ungoverned() or self._actor_registry is None:
                # Ungoverned mode or no registry injected: allow unknown actors
                return StepResult(
                    step_name=self.step_name,
                    verdict=StepVerdict.ALLOW,
                    message="actor not in registry — allowed",
                )
            # Governed mode: unknown actors are denied
            event = PermissionDeniedEvent(
                event_type="permission.denied",
                timestamp=_now_timestamp(),
                actor_id=ctx.actor_id,
                action=ctx.action,
                reason=f"Unknown actor '{ctx.actor_id}' not registered",
            )
            return StepResult(
                step_name=self.step_name,
                verdict=StepVerdict.DENY,
                events=[event],
                message=f"Unknown actor '{ctx.actor_id}' not registered",
            )

        perms = actor.permissions
        if not perms:
            # No permissions defined — allow
            return StepResult(
                step_name=self.step_name,
                verdict=StepVerdict.ALLOW,
                message="no permissions defined — allowed",
            )

        # Observer actors: read-only — deny all non-read actions
        actor_type = str(getattr(actor, "type", ""))
        if actor_type == "observer":
            action_lower = str(ctx.action).lower()
            read_prefixes = self._typed_config.observer_read_prefixes
            is_read_action = any(action_lower.startswith(p) for p in read_prefixes)
            if not is_read_action:
                event = PermissionDeniedEvent(
                    event_type="permission.denied",
                    timestamp=_now_timestamp(),
                    actor_id=ctx.actor_id,
                    action=ctx.action,
                    reason=f"Observer actor cannot perform write action '{ctx.action}'",
                )
                return StepResult(
                    step_name=self.step_name,
                    verdict=StepVerdict.DENY,
                    events=[event],
                    message=f"Observer '{ctx.actor_id}' denied: {ctx.action}",
                )

        service_str = str(ctx.service_id)

        # Classify action as read or write using pack tool metadata.
        # GET = read, POST/PUT/PATCH/DELETE = write.
        is_write = self._is_write_action(ctx.action)

        if is_write:
            write_access = perms.get("write", [])
            if not self._has_access(write_access, service_str):
                reason = f"No write access to service '{service_str}'"
                event = PermissionDeniedEvent(
                    event_type="permission.denied",
                    timestamp=_now_timestamp(),
                    actor_id=ctx.actor_id,
                    action=ctx.action,
                    reason=reason,
                )
                if self._is_ungoverned():
                    return StepResult(
                        step_name=self.step_name,
                        verdict=StepVerdict.ALLOW,
                        events=[event],
                        message=f"ungoverned: {reason}",
                    )
                return StepResult(
                    step_name=self.step_name,
                    verdict=StepVerdict.DENY,
                    events=[event],
                    message=reason,
                )
        else:
            read_access = perms.get("read", [])
            if not self._has_access(read_access, service_str):
                reason = f"No read access to service '{service_str}'"
                event = PermissionDeniedEvent(
                    event_type="permission.denied",
                    timestamp=_now_timestamp(),
                    actor_id=ctx.actor_id,
                    action=ctx.action,
                    reason=reason,
                )
                if self._is_ungoverned():
                    return StepResult(
                        step_name=self.step_name,
                        verdict=StepVerdict.ALLOW,
                        events=[event],
                        message=f"ungoverned: {reason}",
                    )
                return StepResult(
                    step_name=self.step_name,
                    verdict=StepVerdict.DENY,
                    events=[event],
                    message=reason,
                )

        # Check action-specific constraints
        actions = perms.get("actions", {})
        if ctx.action in actions:
            constraint = actions[ctx.action]
            if isinstance(constraint, dict):
                for key, limit in constraint.items():
                    field_name = key.replace("max_", "")
                    input_val = ctx.input_data.get(field_name, ctx.input_data.get(key))
                    if (
                        input_val is not None
                        and isinstance(input_val, (int, float))
                        and isinstance(limit, (int, float))
                        and input_val > limit
                    ):
                        reason = (
                            f"Action '{ctx.action}' exceeds authority: "
                            f"{field_name}={input_val} > {key}={limit}"
                        )
                        event = PermissionDeniedEvent(
                            event_type="permission.denied",
                            timestamp=_now_timestamp(),
                            actor_id=ctx.actor_id,
                            action=ctx.action,
                            reason=reason,
                        )
                        if self._is_ungoverned():
                            return StepResult(
                                step_name=self.step_name,
                                verdict=StepVerdict.ALLOW,
                                events=[event],
                                message=f"ungoverned: {reason}",
                            )
                        return StepResult(
                            step_name=self.step_name,
                            verdict=StepVerdict.DENY,
                            events=[event],
                            message=reason,
                        )

        return StepResult(step_name=self.step_name, verdict=StepVerdict.ALLOW)

    # -- BaseEngine hook -------------------------------------------------------

    async def _handle_event(self, event: Event) -> None:
        """Process inbound events."""
        logger.debug("%s: received event %s", self.engine_name, event.event_type)

    # -- Permission operations -------------------------------------------------

    async def check_permission(self, ctx: ActionContext) -> StepResult:
        """Alias for execute — check permissions for the action."""
        return await self.execute(ctx)

    async def get_visible_entities(
        self,
        actor_id: ActorId,
        entity_type: str,
    ) -> list[EntityId]:
        """Return entity IDs visible to the given actor.

        Queries ``visibility_rule`` entities from State Engine, resolves
        ``$self`` references, builds filters, returns matching entity IDs.

        Returns empty list ``[]`` when no rules exist — callers interpret
        this as "no filtering, return all entities" (backward compat).
        """
        state_engine = self._dependencies.get("state")
        if state_engine is None:
            return []

        actor = self._get_actor(actor_id)
        if actor is None:
            return []

        rule_entity_type = self._typed_config.visibility_rule_entity_type
        try:
            rules = await state_engine.query_entities(
                rule_entity_type,
                {"actor_role": actor.role},
            )
        except Exception:
            return []

        if not rules:
            return []

        applicable = [r for r in rules if r.get("target_entity_type") in (entity_type, "*")]
        if not applicable:
            return []

        visible_ids: list[EntityId] = []
        for rule in applicable:
            filter_field = rule.get("filter_field")
            filter_value = rule.get("filter_value")
            include_unmatched = rule.get("include_unmatched", False)

            if filter_field is None:
                # No filter = see all entities of this type
                entities = await state_engine.query_entities(entity_type)
                visible_ids.extend(EntityId(e.get("id", "")) for e in entities if e.get("id"))
            else:
                resolved = self._resolve_self_ref(filter_value, actor_id)
                entities = await state_engine.query_entities(
                    entity_type,
                    {filter_field: resolved},
                )
                visible_ids.extend(EntityId(e.get("id", "")) for e in entities if e.get("id"))

                if include_unmatched:
                    all_ents = await state_engine.query_entities(entity_type)
                    for e in all_ents:
                        if not e.get(filter_field):
                            eid = EntityId(e.get("id", ""))
                            if eid and eid not in visible_ids:
                                visible_ids.append(eid)

        return visible_ids

    async def has_visibility_rules(
        self,
        actor_id: ActorId,
        entity_type: str,
    ) -> bool:
        """Check if visibility rules exist for this actor and entity type."""
        state_engine = self._dependencies.get("state")
        if state_engine is None:
            return False
        actor = self._get_actor(actor_id)
        if actor is None:
            return False

        rule_entity_type = self._typed_config.visibility_rule_entity_type
        try:
            rules = await state_engine.query_entities(
                rule_entity_type,
                {"actor_role": actor.role},
            )
        except Exception:
            return False

        return any(r.get("target_entity_type") in (entity_type, "*") for r in rules)

    @staticmethod
    def _resolve_self_ref(value: str | None, actor_id: ActorId) -> str:
        """Resolve ``$self.actor_id`` references in filter values."""
        if value is None:
            return ""
        return value.replace("$self.actor_id", str(actor_id))

    async def get_actor_permissions(self, actor_id: ActorId) -> dict[str, Any]:
        """Return the actor's permission definition."""
        actor = self._get_actor(actor_id)
        if actor is None:
            return {}
        return dict(actor.permissions)

    # -- Internal helpers ------------------------------------------------------

    def _get_actor(self, actor_id: ActorId) -> Any:
        """Look up an actor from the registry, returning None if not found."""
        if self._actor_registry is None:
            return None
        return self._actor_registry.get_or_none(actor_id)

    def _is_ungoverned(self) -> bool:
        """Check if the world is in ungoverned mode."""
        return self._world_mode == WorldMode.UNGOVERNED or self._world_mode == "ungoverned"

    def _is_write_action(self, action: str) -> bool:
        """Determine if an action is a write operation from pack tool metadata.

        Uses ``http_method`` from the tool definition (set by every pack):
        GET = read, POST/PUT/PATCH/DELETE = write.
        Falls back to write (safer default — denies rather than leaks).
        """
        if self._pack_registry is None:
            return True
        try:
            pack = self._pack_registry.get_pack_for_tool(action)
            for tool in pack.get_tools():
                if tool.get("name") == action:
                    method = tool.get("http_method", "POST").upper()
                    return method != "GET"
        except Exception:
            pass
        return True

    @staticmethod
    def _has_access(access_config: Any, service: str) -> bool:
        """Check if access config grants access to the given service.

        access_config is one of:
        - "all" (string) → universal access
        - ["email", "chat"] (list) → service must be in list
        - anything else → no access (deny)
        """
        if access_config == "all":
            return True
        if isinstance(access_config, list):
            return service in access_config
        return False
