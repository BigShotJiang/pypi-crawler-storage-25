"""VIP - Verified Installation of Posit."""

__version__ = "0.20.0"
