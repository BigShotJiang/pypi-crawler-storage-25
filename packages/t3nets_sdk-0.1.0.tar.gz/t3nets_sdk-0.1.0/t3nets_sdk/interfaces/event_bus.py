"""
Event Bus Interface

Cloud-agnostic abstraction for async event publishing.
Implementations: EventBridgeBus (AWS), DirectBus (local), etc.
"""

from abc import ABC, abstractmethod
from typing import Any


class EventBus(ABC):
    """
    Abstract base class for event publishing.

    Used by the router to dispatch skill invocations asynchronously.
    The local implementation calls skills directly (no queue).
    """

    @abstractmethod
    async def publish(
        self,
        source: str,
        detail_type: str,
        detail: dict[str, Any],
    ) -> None:
        """
        Publish an event.

        Args:
            source: Event source (e.g., "agent.router")
            detail_type: Event type (e.g., "skill.invoke")
            detail: Event payload (must include tenant_id)
        """
        ...

    async def publish_skill_invocation(
        self,
        tenant_id: str,
        skill_name: str,
        params: dict[str, Any],
        session_id: str,
        request_id: str,
        reply_channel: str,
        reply_target: str,
        *,
        is_raw: bool = False,
    ) -> None:
        """
        Convenience method for the most common event type.

        `is_raw` is forwarded so worker hosts (DirectBus, Lambda handler)
        can populate `SkillContext.raw`. Skills that render their own
        output use this to skip the rendering step when the user asked
        for the raw payload.
        """
        await self.publish(
            source="agent.router",
            detail_type="skill.invoke",
            detail={
                "tenant_id": tenant_id,
                "skill_name": skill_name,
                "params": params,
                "session_id": session_id,
                "request_id": request_id,
                "reply_channel": reply_channel,
                "reply_target": reply_target,
                "is_raw": is_raw,
            },
        )
