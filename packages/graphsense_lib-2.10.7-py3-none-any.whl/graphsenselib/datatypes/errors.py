class BadUserInputError(Exception):
    pass
