"""
tests/test_calculearn.py
========================
pytest test suite for the calculearn library.

Run with:
    pytest tests/ -v
"""

import math
import sympy as sp
import pytest

from calculearn import derivative, limit, integrate, taylor, critical_points
from calculearn.critical_points import CriticalPoint


# ══════════════════════════════════════════════════════════════════════════════
# Helpers
# ══════════════════════════════════════════════════════════════════════════════

def approx_equal(sym_expr, expected_float, tol=1e-9):
    """Return True if sym_expr evaluates to approximately expected_float."""
    try:
        return abs(float(sp.N(sym_expr)) - expected_float) < tol
    except (TypeError, ValueError):
        return False


# ══════════════════════════════════════════════════════════════════════════════
# 1. Derivatives
# ══════════════════════════════════════════════════════════════════════════════

class TestDerivatives:

    def test_power_rule_cubic(self):
        """d/dx[x³] = 3x²"""
        result = derivative("x**3", var="x", steps=False, plot=False)
        x = sp.Symbol("x", real=True)
        assert sp.simplify(result - 3 * x**2) == 0

    def test_polynomial(self):
        """d/dx[x³ + 2x² + x] = 3x² + 4x + 1"""
        result = derivative("x**3 + 2*x**2 + x", var="x", steps=False, plot=False)
        x = sp.Symbol("x", real=True)
        expected = 3 * x**2 + 4 * x + 1
        assert sp.simplify(result - expected) == 0

    def test_sin_derivative(self):
        """d/dx[sin(x)] = cos(x)"""
        result = derivative("sin(x)", var="x", steps=False, plot=False)
        x = sp.Symbol("x", real=True)
        assert sp.simplify(result - sp.cos(x)) == 0

    def test_product_rule(self):
        """d/dx[sin(x)*exp(x)] = sin(x)*exp(x) + cos(x)*exp(x)"""
        result = derivative("sin(x)*exp(x)", var="x", steps=False, plot=False)
        x = sp.Symbol("x", real=True)
        expected = sp.diff(sp.sin(x) * sp.exp(x), x)
        assert sp.simplify(result - expected) == 0

    def test_chain_rule(self):
        """d/dx[cos(x²)] = -2x*sin(x²)"""
        result = derivative("cos(x**2)", var="x", steps=False, plot=False)
        x = sp.Symbol("x", real=True)
        expected = -2 * x * sp.sin(x**2)
        assert sp.simplify(result - expected) == 0

    def test_constant_derivative(self):
        """d/dx[7] = 0"""
        result = derivative("7", var="x", steps=False, plot=False)
        assert result == 0

    def test_returns_sympy_expr(self):
        """Return type should be a SymPy expression."""
        result = derivative("x**2", var="x", steps=False, plot=False)
        assert isinstance(result, sp.Expr)

    def test_steps_output(self, capsys):
        """steps=True should produce non-empty printed output."""
        derivative("x**2", var="x", steps=True, plot=False)
        captured = capsys.readouterr()
        assert "Power Rule" in captured.out or "derivative" in captured.out.lower()


# ══════════════════════════════════════════════════════════════════════════════
# 2. Limits
# ══════════════════════════════════════════════════════════════════════════════

class TestLimits:

    def test_sinx_over_x(self):
        """lim[x→0] sin(x)/x = 1"""
        result = limit("sin(x)/x", var="x", at=0, steps=False)
        assert result == 1

    def test_factoring_limit(self):
        """lim[x→1] (x²-1)/(x-1) = 2"""
        result = limit("(x**2 - 1)/(x - 1)", var="x", at=1, steps=False)
        assert result == 2

    def test_constant_limit(self):
        """lim[x→5] 3 = 3"""
        result = limit("3", var="x", at=5, steps=False)
        assert result == 3

    def test_limit_at_infinity(self):
        """lim[x→∞] 1/x = 0"""
        result = limit("1/x", var="x", at=sp.oo, steps=False)
        assert result == 0

    def test_polynomial_limit(self):
        """lim[x→2] x²+1 = 5"""
        result = limit("x**2 + 1", var="x", at=2, steps=False)
        assert result == 5

    def test_one_sided_limit_right(self):
        """lim[x→0⁺] 1/x = +∞"""
        result = limit("1/x", var="x", at=0, direction="+", steps=False)
        assert result == sp.oo

    def test_one_sided_limit_left(self):
        """lim[x→0⁻] 1/x = −∞"""
        result = limit("1/x", var="x", at=0, direction="-", steps=False)
        assert result == -sp.oo

    def test_returns_sympy_expr(self):
        """Return type should be a SymPy expression."""
        result = limit("x**2", var="x", at=3, steps=False)
        assert isinstance(result, sp.Basic)


# ══════════════════════════════════════════════════════════════════════════════
# 3. Integration
# ══════════════════════════════════════════════════════════════════════════════

class TestIntegrals:

    def test_indefinite_power(self):
        """∫ x² dx = x³/3"""
        result = integrate("x**2", var="x", steps=False)
        x = sp.Symbol("x", real=True)
        expected = x**3 / 3
        assert sp.simplify(result - expected) == 0

    def test_definite_integral(self):
        """∫[0,3] (x²+1) dx = 12"""
        result = integrate("x**2 + 1", var="x", lower=0, upper=3, steps=False)
        assert result == 12

    def test_definite_sin(self):
        """∫[0,π] sin(x) dx = 2"""
        result = integrate("sin(x)", var="x", lower=0, upper=sp.pi, steps=False)
        assert sp.simplify(result - 2) == 0

    def test_indefinite_exp(self):
        """∫ exp(x) dx = exp(x)"""
        result = integrate("exp(x)", var="x", steps=False)
        x = sp.Symbol("x", real=True)
        assert sp.simplify(result - sp.exp(x)) == 0

    def test_constant_integral(self):
        """∫[0,5] 2 dx = 10"""
        result = integrate("2", var="x", lower=0, upper=5, steps=False)
        assert result == 10

    def test_definite_returns_number(self):
        """Definite integral should return a numeric SymPy value."""
        result = integrate("x", var="x", lower=0, upper=4, steps=False)
        assert approx_equal(result, 8.0)

    def test_indefinite_returns_expr(self):
        """Indefinite integral should return a SymPy expression."""
        result = integrate("cos(x)", var="x", steps=False)
        assert isinstance(result, sp.Expr)

    def test_steps_output(self, capsys):
        """steps=True should print working."""
        integrate("x**2", var="x", steps=True)
        captured = capsys.readouterr()
        assert "INTEGRAL" in captured.out or "Power" in captured.out


# ══════════════════════════════════════════════════════════════════════════════
# 4. Taylor Series
# ══════════════════════════════════════════════════════════════════════════════

class TestTaylor:

    def test_cos_maclaurin_terms(self):
        """Taylor series of cos(x) at 0 with 3 terms (k=0,1,2) = 1 - x²/2.
        k=2 gives coeff f''(0)/2! = -1/2, so degree-2 polynomial."""
        result = taylor("cos(x)", var="x", around=0, terms=3,
                        steps=False, plot=False, animate=False)
        x = sp.Symbol("x", real=True)
        # terms=3 → k=0,1,2: cos k=1 term is 0, k=2 gives -x²/2
        expected = 1 - x**2 / 2
        assert sp.simplify(result - expected) == 0

    def test_exp_maclaurin_2terms(self):
        """Taylor series of exp(x) at 0 with 2 terms = 1 + x"""
        result = taylor("exp(x)", var="x", around=0, terms=2,
                        steps=False, plot=False, animate=False)
        x = sp.Symbol("x", real=True)
        expected = 1 + x
        assert sp.simplify(result - expected) == 0

    def test_sin_maclaurin_terms(self):
        """Taylor series of sin(x) at 0 with 4 terms (k=0..3) = x - x³/6.
        Even k terms vanish for sin."""
        result = taylor("sin(x)", var="x", around=0, terms=4,
                        steps=False, plot=False, animate=False)
        x = sp.Symbol("x", real=True)
        # k=0→0, k=1→x, k=2→0, k=3→-x³/6
        expected = x - x**3 / 6
        assert sp.simplify(result - expected) == 0

    def test_returns_poly(self):
        """Result should be a polynomial (SymPy expression)."""
        result = taylor("exp(x)", var="x", around=0, terms=3,
                        steps=False, plot=False, animate=False)
        assert isinstance(result, sp.Expr)

    def test_steps_output(self, capsys):
        """steps=True should print term-by-term working."""
        taylor("cos(x)", var="x", around=0, terms=2,
               steps=True, plot=False, animate=False)
        captured = capsys.readouterr()
        assert "Taylor" in captured.out or "Term" in captured.out or "k =" in captured.out


# ══════════════════════════════════════════════════════════════════════════════
# 5. Critical Points
# ══════════════════════════════════════════════════════════════════════════════

class TestCriticalPoints:

    def test_cubic_two_critical_points(self):
        """x³ - 3x has critical points at x=-1 (max) and x=1 (min)."""
        cps = critical_points("x**3 - 3*x", var="x", steps=False, plot=False)
        x_vals = sorted([float(cp.x_val) for cp in cps])
        assert len(cps) == 2
        assert abs(x_vals[0] - (-1.0)) < 1e-9
        assert abs(x_vals[1] -  1.0)  < 1e-9

    def test_cubic_classification(self):
        """x=-1 is a maximum, x=1 is a minimum for x³-3x."""
        cps = critical_points("x**3 - 3*x", var="x", steps=False, plot=False)
        cp_dict = {round(float(cp.x_val), 6): cp.classification for cp in cps}
        assert cp_dict[-1.0] == "local maximum"
        assert cp_dict[1.0]  == "local minimum"

    def test_parabola_one_min(self):
        """x² has one critical point at x=0 (local minimum)."""
        cps = critical_points("x**2", var="x", steps=False, plot=False)
        assert len(cps) == 1
        assert float(cps[0].x_val) == 0.0
        assert cps[0].classification == "local minimum"

    def test_returns_list_of_cp(self):
        """Return type should be a list of CriticalPoint objects."""
        cps = critical_points("x**2", var="x", steps=False, plot=False)
        assert isinstance(cps, list)
        assert all(isinstance(cp, CriticalPoint) for cp in cps)

    def test_no_critical_points(self):
        """f(x) = x has no critical points."""
        cps = critical_points("x", var="x", steps=False, plot=False)
        assert cps == []

    def test_quartic_critical_points(self):
        """x⁴ - 4x² has critical points at x=-√2, 0, √2."""
        cps = critical_points("x**4 - 4*x**2", var="x", steps=False, plot=False)
        x_vals = sorted([float(cp.x_val) for cp in cps])
        assert len(cps) == 3
        assert abs(x_vals[0] - (-math.sqrt(2))) < 1e-6
        assert abs(x_vals[1] -  0.0)            < 1e-6
        assert abs(x_vals[2] -  math.sqrt(2))   < 1e-6

    def test_steps_output(self, capsys):
        """steps=True should print the second derivative test."""
        critical_points("x**2", var="x", steps=True, plot=False)
        captured = capsys.readouterr()
        assert "second" in captured.out.lower() or "derivative" in captured.out.lower()


# ══════════════════════════════════════════════════════════════════════════════
# 6. Parser robustness
# ══════════════════════════════════════════════════════════════════════════════

class TestParser:

    def test_caret_notation(self):
        """x^3 should be parsed as x**3."""
        from calculearn._parser import parse_expr
        expr = parse_expr("x^3", var="x")
        x = sp.Symbol("x", real=True)
        assert sp.simplify(expr - x**3) == 0

    def test_implicit_multiplication(self):
        """2x should be parsed as 2*x."""
        from calculearn._parser import parse_expr
        expr = parse_expr("2x", var="x")
        x = sp.Symbol("x", real=True)
        assert sp.simplify(expr - 2 * x) == 0

    def test_invalid_expr_raises(self):
        """A completely invalid expression should raise ValueError."""
        from calculearn._parser import parse_expr
        with pytest.raises((ValueError, sp.SympifyError, Exception)):
            parse_expr("@@@@", var="x")
