"""
calculearn.integrals  (v0.2)
============================
Symbolic integration with LaTeX-formatted steps and rich visualisation
(function plot + shaded area + antiderivative panel).
"""

from __future__ import annotations

import sympy as sp
import numpy as np
import matplotlib.pyplot as plt
import matplotlib
matplotlib.use("Agg")
from matplotlib.gridspec import GridSpec

from ._parser import parse_expr, symvar
from ._latex_printer import (
    section, step, substep, rule_box, result_line, divider, info, to_latex
)


# ── rule detection ─────────────────────────────────────────────────────────────

def _rule(expr, var):
    if not expr.has(var):                          return "constant"
    if expr == var:                                return "power1"
    if isinstance(expr, sp.Pow):
        b, e = expr.args
        if b == var and e.is_number:
            return "reciprocal" if e == -1 else "power"
    if isinstance(expr, sp.Add):                   return "sum"
    if isinstance(expr, sp.Mul):
        vf = [f for f in expr.args if f.has(var)]
        return "constant_multiple" if len(vf) == 1 else "by_parts_or_sub"
    if isinstance(expr, sp.exp):                   return "exponential"
    if isinstance(expr, sp.log):                   return "by_parts"
    if isinstance(expr, (sp.sin, sp.cos)):         return "trig"
    return "general"


# ── indefinite step printer ───────────────────────────────────────────────────

def _indef_steps(expr, var, anti):
    rule = _rule(expr, var)

    if rule == "sum":
        rule_box("Sum/Difference Rule",
                 "\\int [f(x) \\pm g(x)]\\,dx = \\int f(x)\\,dx \\pm \\int g(x)\\,dx")
        print("      Split the integral into individual terms:\n")
        for i, term in enumerate(expr.args, 1):
            sub_anti = sp.integrate(term, var)
            sub_rule = _rule(term, var)
            substep(
                f"Term {i}:  $ \\int {to_latex(term)}\\,d{var} $",
                f"\\int {to_latex(term)}\\,d{var} = {to_latex(sub_anti)}",
                f"({_rule_desc(sub_rule)})"
            )
        print(f"      Combine all terms:\n")
        print(f"      $ \\int ({to_latex(expr)})\\,d{var} = {to_latex(sp.expand(anti))} + C $\n")

    elif rule in ("power", "power1"):
        b, e = (expr.args if isinstance(expr, sp.Pow) else (var, sp.Integer(1)))
        rule_box("Power Rule", "\\int x^n\\,dx = \\frac{x^{n+1}}{n+1} + C \\quad (n \\neq -1)")
        new_e = e + 1
        print(f"      Exponent: $ n = {to_latex(e)} $")
        print(f"      New exponent: $ n+1 = {to_latex(new_e)} $")
        print(f"      $ \\int {var}^{{{to_latex(e)}}}\\,d{var} = \\frac{{{var}^{{{to_latex(new_e)}}}}}{{{to_latex(new_e)}}} + C = {to_latex(sp.simplify(anti))} + C $\n")

    elif rule == "reciprocal":
        rule_box("Reciprocal Rule", "\\int \\frac{1}{x}\\,dx = \\ln|x| + C")
        print(f"      $ \\int \\frac{{1}}{{{var}}}\\,d{var} = \\ln|{var}| + C $\n")

    elif rule == "exponential":
        inner = expr.args[0]
        rule_box("Exponential Rule", "\\int e^{ax}\\,dx = \\frac{e^{ax}}{a} + C")
        coeff = sp.diff(inner, var)
        print(f"      Inner function: $ u = {to_latex(inner)} $,  $ u' = {to_latex(coeff)} $")
        print(f"      $ \\int e^{{{to_latex(inner)}}}\\,d{var} = \\frac{{e^{{{to_latex(inner)}}}}}{{{to_latex(coeff)}}} + C = {to_latex(sp.simplify(anti))} + C $\n")

    elif rule == "trig":
        if isinstance(expr, sp.sin):
            rule_box("Trig Integral", "\\int \\sin(x)\\,dx = -\\cos(x) + C")
        else:
            rule_box("Trig Integral", "\\int \\cos(x)\\,dx = \\sin(x) + C")
        print(f"      $ \\int {to_latex(expr)}\\,d{var} = {to_latex(sp.simplify(anti))} + C $\n")

    elif rule == "constant_multiple":
        cf = [f for f in expr.args if not f.has(var)]
        vf = [f for f in expr.args if f.has(var)]
        c  = sp.Mul(*cf)
        inner = sp.Mul(*vf)
        rule_box("Constant Multiple Rule", "\\int c \\cdot f(x)\\,dx = c \\int f(x)\\,dx")
        inner_anti = sp.integrate(inner, var)
        print(f"      Factor out constant $ {to_latex(c)} $:")
        print(f"      $ {to_latex(c)} \\times \\int {to_latex(inner)}\\,d{var} = {to_latex(c)} \\times {to_latex(inner_anti)} = {to_latex(sp.simplify(anti))} + C $\n")

    elif rule == "by_parts":
        rule_box("Integration by Parts", "\\int u\\,dv = u \\cdot v - \\int v\\,du")
        du = sp.diff(expr, var)
        print(f"      Choose  $ u = {to_latex(expr)} $  (LIATE: logarithm first)")
        print(f"      Then    $ dv = d{var} $  →  $ v = {var} $")
        print(f"      Differentiate: $ du = {to_latex(du)}\\,d{var} $")
        print(f"      Apply formula: $ {to_latex(expr)} \\cdot {var} - \\int {var} \\cdot {to_latex(du)}\\,d{var} $")
        print(f"      Result: $ {to_latex(sp.simplify(anti))} + C $\n")

    else:
        print(f"      $ \\int {to_latex(expr)}\\,d{var} $  —  applying symbolic integration\n")
        print(f"      $ = {to_latex(sp.simplify(anti))} + C $\n")


def _rule_desc(r):
    return {
        "constant": "Constant Rule",
        "power": "Power Rule",
        "power1": "Power Rule (n=1)",
        "reciprocal": "Reciprocal Rule",
        "exponential": "Exponential Rule",
        "trig": "Trig Integral",
        "constant_multiple": "Constant Multiple Rule",
        "by_parts": "Integration by Parts",
        "sum": "Sum Rule",
        "general": "Standard form",
    }.get(r, "Standard form")


# ── definite step printer ─────────────────────────────────────────────────────

def _def_steps(expr, var, lower, upper, anti, value):
    lo_tex = to_latex(lower)
    hi_tex = to_latex(upper)

    step(1, "Find the Antiderivative  (Indefinite Integral)",
         f"F({var}) = \\int {to_latex(expr)}\\,d{var}")
    _indef_steps(expr, var, anti)

    step(2, "Apply the Fundamental Theorem of Calculus",
         "\\int_a^b f(x)\\,dx = F(b) - F(a)")
    rule_box("Fundamental Theorem of Calculus",
             "\\int_a^b f(x)\\,dx = F(b) - F(a)")

    F_hi = sp.simplify(anti.subs(var, upper))
    F_lo = sp.simplify(anti.subs(var, lower))
    print(f"      $ F({hi_tex}) = {to_latex(anti)} \\Big|_{{{var}={hi_tex}}} = {to_latex(F_hi)} $")
    print(f"      $ F({lo_tex}) = {to_latex(anti)} \\Big|_{{{var}={lo_tex}}} = {to_latex(F_lo)} $\n")

    step(3, f"Subtract  F({hi_tex}) − F({lo_tex})",
         f"{to_latex(F_hi)} - {to_latex(F_lo)} = {to_latex(sp.simplify(value))}")

    try:
        print(f"      Numerical value: $ {float(sp.N(value)):.6f} $\n")
    except Exception:
        pass

    divider()
    result_line(
        f"$\\int_{{{lo_tex}}}^{{{hi_tex}}} {to_latex(expr)}\\,d{var}$",
        to_latex(sp.simplify(value))
    )


# ── public API ────────────────────────────────────────────────────────────────

def integrate(
    expr_str: str,
    var: str = "x",
    lower=None,
    upper=None,
    steps: bool = True,
    plot: bool = False,
    x_range: tuple[float, float] | None = None,
    save_path: str | None = None,
) -> sp.Expr:
    """
    Compute the symbolic integral of *expr_str*.
    If *lower* and *upper* are given → definite integral.
    Otherwise → indefinite integral.
    """
    x    = symvar(var)
    expr = parse_expr(expr_str, var)
    anti = sp.integrate(expr, x)

    if lower is not None and upper is not None:
        lower  = sp.sympify(lower)
        upper  = sp.sympify(upper)
        value  = sp.integrate(expr, (x, lower, upper))
        lo_tex = to_latex(lower)
        hi_tex = to_latex(upper)

        if steps:
            section(
                f"DEFINITE INTEGRAL  —  $\\int_{{{lo_tex}}}^{{{hi_tex}}} {to_latex(expr)}\\,d{var}$",
                "We find the antiderivative, then apply the Fundamental Theorem of Calculus."
            )
            _def_steps(expr, x, lower, upper, anti, value)

        if plot:
            _plot_integral(expr, x, lower, upper, x_range, save_path)
        return value

    else:
        if steps:
            section(
                f"INDEFINITE INTEGRAL  —  $\\int {to_latex(expr)}\\,d{var}$",
                "We identify the integration rule and apply it step by step."
            )
            step(1, "Identify the Integration Rule")
            _indef_steps(expr, x, anti)
            divider()
            result_line(
                f"$\\int {to_latex(expr)}\\,d{var}$",
                f"{to_latex(sp.simplify(anti))} + C"
            )

        if plot:
            _plot_integral(expr, x, None, None, x_range, save_path)
        return anti


# ── rich 2-panel plot ─────────────────────────────────────────────────────────

def _plot_integral(expr, var, lower, upper, x_range, save_path):
    try:
        lo_n = float(lower) if lower is not None else -4.0
        hi_n = float(upper) if upper is not None else  4.0
    except (TypeError, ValueError):
        lo_n, hi_n = -4.0, 4.0

    margin = max((hi_n - lo_n) * 0.6, 2.0)
    plot_lo = (lo_n - margin) if x_range is None else x_range[0]
    plot_hi = (hi_n + margin) if x_range is None else x_range[1]

    f    = sp.lambdify(var, expr, modules=["numpy"])
    anti = sp.integrate(expr, var)
    F    = sp.lambdify(var, anti, modules=["numpy"])

    xs = np.linspace(plot_lo, plot_hi, 800)

    def safe(fn, arr):
        try:
            y = fn(arr)
            return np.where(np.isfinite(y), y, np.nan)
        except Exception:
            return np.full_like(arr, np.nan)

    ys = safe(f, xs)
    Ys = safe(F, xs)

    fig = plt.figure(figsize=(14, 5))
    gs  = GridSpec(1, 2, figure=fig, wspace=0.35)
    ax1 = fig.add_subplot(gs[0])
    ax2 = fig.add_subplot(gs[1])

    # Left panel — function + shaded area
    ax1.plot(xs, ys, color="#2563eb", linewidth=2.2, label=f"$f({var}) = {sp.latex(expr)}$")
    if lower is not None and upper is not None:
        xs_s = np.linspace(lo_n, hi_n, 500)
        ys_s = safe(f, xs_s)
        ax1.fill_between(xs_s, ys_s, 0, alpha=0.25, color="#2563eb",
                         label=f"Area = ${sp.latex(sp.simplify(sp.integrate(expr,(var,lower,upper))))}$")
        ax1.axvline(lo_n, color="gray", linestyle="--", linewidth=0.9)
        ax1.axvline(hi_n, color="gray", linestyle="--", linewidth=0.9)
        ax1.text(lo_n, ax1.get_ylim()[0] if ax1.get_ylim()[0] else 0,
                 f"  ${sp.latex(lower)}$", fontsize=9, color="gray", va="bottom")
        ax1.text(hi_n, ax1.get_ylim()[0] if ax1.get_ylim()[0] else 0,
                 f"  ${sp.latex(upper)}$", fontsize=9, color="gray", va="bottom")
    ax1.axhline(0, color="black", linewidth=0.7)
    ax1.set_xlabel(f"${var}$", fontsize=11)
    lo_tex = to_latex(lower) if lower is not None else ""
    hi_tex = to_latex(upper) if upper is not None else ""
    ax1.set_title(
        f"$\\int_{{{lo_tex}}}^{{{hi_tex}}} {sp.latex(expr)}\\,d{var}$" if lower is not None
        else f"$f({var}) = {sp.latex(expr)}$",
        fontsize=11, fontweight="bold"
    )
    ax1.legend(fontsize=9)
    ax1.grid(True, alpha=0.25)
    ys_f = ys[np.isfinite(ys)]
    if len(ys_f):
        rng = ys_f.max() - ys_f.min() or 1
        ax1.set_ylim(ys_f.min() - rng * 0.15, ys_f.max() + rng * 0.25)

    # Right panel — antiderivative
    ax2.plot(xs, Ys, color="#16a34a", linewidth=2.2, label=f"$F({var}) = {sp.latex(sp.simplify(anti))}$")
    if lower is not None and upper is not None:
        try:
            F_lo = float(F(lo_n))
            F_hi = float(F(hi_n))
            ax2.scatter([lo_n, hi_n], [F_lo, F_hi], s=80, color="#dc2626", zorder=5)
            Ys_f2 = Ys[np.isfinite(Ys)]
            y_range = (Ys_f2.max() - Ys_f2.min()) if len(Ys_f2) else 1
            # place labels well away from the curve using bbox
            ax2.annotate(
                f"$F({sp.latex(lower)}) = {sp.latex(sp.simplify(anti.subs(var, lower)))}$",
                xy=(lo_n, F_lo),
                xytext=(-60, -25), textcoords="offset points",
                fontsize=8, color="#dc2626",
                arrowprops=dict(arrowstyle="->", color="#dc2626", lw=0.8),
                bbox=dict(boxstyle="round,pad=0.2", fc="white", ec="#dc2626", alpha=0.9),
            )
            ax2.annotate(
                f"$F({sp.latex(upper)}) = {sp.latex(sp.simplify(anti.subs(var, upper)))}$",
                xy=(hi_n, F_hi),
                xytext=(8, 15), textcoords="offset points",
                fontsize=8, color="#dc2626",
                arrowprops=dict(arrowstyle="->", color="#dc2626", lw=0.8),
                bbox=dict(boxstyle="round,pad=0.2", fc="white", ec="#dc2626", alpha=0.9),
            )
            val_str = sp.latex(sp.simplify(sp.integrate(expr, (var, lower, upper))))
            ax2.text(0.05, 0.95,
                     f"$F(b) - F(a) = {val_str}$",
                     transform=ax2.transAxes,
                     fontsize=9, color="#dc2626", va="top",
                     bbox=dict(boxstyle="round,pad=0.3", fc="white", ec="#dc2626", alpha=0.92))
        except Exception:
            pass
    ax2.axhline(0, color="black", linewidth=0.7)
    ax2.set_xlabel(f"${var}$", fontsize=11)
    ax2.set_title(f"Antiderivative  $F({var})$", fontsize=11, fontweight="bold")
    ax2.legend(fontsize=9)
    ax2.grid(True, alpha=0.25)
    Ys_f = Ys[np.isfinite(Ys)]
    if len(Ys_f):
        rng = Ys_f.max() - Ys_f.min() or 1
        ax2.set_ylim(Ys_f.min() - rng * 0.15, Ys_f.max() + rng * 0.25)

    fig.suptitle(
        "Integration  —  Function and its Antiderivative",
        fontsize=13, fontweight="bold"
    )
    plt.tight_layout()
    if save_path:
        plt.savefig(save_path, dpi=150, bbox_inches="tight")
        info(f"Plot saved → {save_path}")
    else:
        plt.show()
    plt.close(fig)
