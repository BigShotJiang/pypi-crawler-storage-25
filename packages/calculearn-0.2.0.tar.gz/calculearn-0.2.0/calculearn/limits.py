"""
calculearn.limits  (v0.2)
=========================
Symbolic limit evaluation with LaTeX-formatted, strategy-aware explanations
and rich plots (function + approach zoom).
"""

from __future__ import annotations

import sympy as sp
import numpy as np
import matplotlib.pyplot as plt
import matplotlib
matplotlib.use("Agg")
from matplotlib.gridspec import GridSpec

from ._parser import parse_expr, symvar
from ._latex_printer import (
    section, step, substep, rule_box, result_line, divider, warn, info, to_latex
)


# ── indeterminate form detection ──────────────────────────────────────────────

def _sub_val(expr, var, at):
    try:
        v = expr.subs(var, at)
        return v if v.is_finite else None
    except Exception:
        return None


def _ind_form(expr, var, at):
    try:
        num, den = sp.fraction(sp.together(expr))
        n = num.subs(var, at)
        d = den.subs(var, at)
        if n == 0 and d == 0:    return "0/0"
        if d == 0 and n != 0:   return "c/0"
        if n.is_infinite and d.is_infinite: return "∞/∞"
    except Exception:
        pass
    return "other"


# ── full step-by-step printer ─────────────────────────────────────────────────

def _print_steps(expr, var, at, direction, result):
    at_tex  = "\\infty" if at == sp.oo else ("-\\infty" if at == -sp.oo else to_latex(at))
    dir_str = {"+" : "from the right  $(x \\to a^+)$",
               "-" : "from the left   $(x \\to a^-)$",
               "±" : "two-sided"}.get(direction, "two-sided")

    section(
        f"LIMIT  —  $\\lim_{{{var} \\to {at_tex}}} {to_latex(expr)}$",
        f"Direction: {dir_str}"
    )

    # ── Step 1: direct substitution ──────────────────────────────────────────
    step(1, "Try Direct Substitution",
         f"\\text{{Replace }} {var} \\text{{ with }} {at_tex} \\text{{ directly.}}")

    direct = _sub_val(expr, var, at)
    if direct is not None:
        print(f"      Substituting $ {var} = {at_tex} $:")
        print(f"      $ {to_latex(expr.subs(var, at))} = {to_latex(direct)} $\n")
        print("      ✓  Direct substitution works — no indeterminate form.\n")
        divider()
        result_line(f"$\\lim_{{{var} \\to {at_tex}}}$", to_latex(sp.simplify(result)))
        return

    form = _ind_form(expr, var, at)
    print(f"      Substituting $ {var} = {at_tex} $ gives the indeterminate form:  $ {form} $\n")
    print(f"      We need a resolution strategy.\n")

    num, den = sp.fraction(sp.together(expr))

    # ── Step 2: strategy ─────────────────────────────────────────────────────
    if form == "0/0":
        step(2, "Strategy: Factor & Cancel  (for 0/0 form)",
             "\\text{Factor numerator and denominator, then cancel common factors.}")

        num_f = sp.factor(num)
        den_f = sp.factor(den)
        print(f"      Numerator factored:   $ {to_latex(num_f)} $")
        print(f"      Denominator factored: $ {to_latex(den_f)} $\n")

        cancelled = sp.simplify(num_f / den_f)
        if sp.simplify(cancelled - expr) != 0:
            print(f"      Cancel common factor → simplified expression:")
            print(f"      $ {to_latex(cancelled)} $\n")
            step(3, "Re-apply Direct Substitution on simplified expression",
                 f"{to_latex(cancelled)} \\Big|_{{{var}={at_tex}}} = {to_latex(sp.simplify(cancelled.subs(var, at)))}")
        else:
            print("      Factoring did not cancel.  Applying L'Hôpital's Rule instead.\n")
            step(3, "L'Hôpital's Rule  —  for 0/0 or ∞/∞ forms",
                 "\\lim_{x \\to a} \\frac{f(x)}{g(x)} = \\lim_{x \\to a} \\frac{f'(x)}{g'(x)}")

            rule_box("L'Hôpital's Rule",
                     "\\lim \\frac{f}{g} \\stackrel{\\frac{0}{0}}{=} \\lim \\frac{f'}{g'}")

            dn = sp.diff(num, var)
            dd = sp.diff(den, var)
            print(f"      Differentiate numerator:   $ \\frac{{d}}{{d{var}}}[{to_latex(num)}] = {to_latex(dn)} $")
            print(f"      Differentiate denominator: $ \\frac{{d}}{{d{var}}}[{to_latex(den)}] = {to_latex(dd)} $\n")
            lh = sp.simplify(dn / dd)
            val = lh.subs(var, at)
            print(f"      New expression: $ \\frac{{{to_latex(dn)}}}{{{to_latex(dd)}}} = {to_latex(lh)} $")
            print(f"      Substitute $ {var} = {at_tex} $:  $ {to_latex(lh)} = {to_latex(val)} $\n")

    elif form == "c/0":
        step(2, "Strategy: One-sided Analysis  (for c/0 form)",
             "\\text{Check the sign of the denominator from each side.}")
        lp = sp.limit(expr, var, at, "+")
        lm = sp.limit(expr, var, at, "-")
        print(f"      $ \\lim_{{{var} \\to {at_tex}^+}} {to_latex(expr)} = {to_latex(lp)} $")
        print(f"      $ \\lim_{{{var} \\to {at_tex}^-}} {to_latex(expr)} = {to_latex(lm)} $\n")
        if sp.simplify(lp - lm) == 0:
            print("      Both sides agree → two-sided limit exists.\n")
        else:
            warn("Left-hand and right-hand limits differ → two-sided limit does NOT exist.")

    elif form == "∞/∞":
        step(2, "Strategy: L'Hôpital's Rule  (for ∞/∞ form)",
             "\\lim \\frac{f}{g} \\stackrel{\\infty/\\infty}{=} \\lim \\frac{f'}{g'}")
        rule_box("L'Hôpital's Rule", "\\lim \\frac{f}{g} = \\lim \\frac{f'}{g'}")
        dn = sp.diff(num, var)
        dd = sp.diff(den, var)
        print(f"      $ \\frac{{d}}{{d{var}}}[{to_latex(num)}] = {to_latex(dn)} $")
        print(f"      $ \\frac{{d}}{{d{var}}}[{to_latex(den)}] = {to_latex(dd)} $\n")
        lh = sp.simplify(dn / dd)
        print(f"      Simplified: $ {to_latex(lh)} $\n")

    else:
        step(2, "Strategy: Symbolic Methods",
             "\\text{Apply trigonometric identities or Taylor expansion.}")

    divider()
    if result is sp.nan or result == sp.zoo:
        warn("The two-sided limit does NOT exist  — left and right limits differ.")
        lp = sp.limit(expr, var, at, "+")
        lm = sp.limit(expr, var, at, "-")
        print(f"      $ \\lim^+ = {to_latex(lp)} $,  $ \\lim^- = {to_latex(lm)} $\n")
    else:
        result_line(f"$\\lim_{{{var} \\to {at_tex}}}$", to_latex(sp.simplify(result)))


# ── public API ────────────────────────────────────────────────────────────────

def limit(
    expr_str: str,
    var: str = "x",
    at=0,
    direction: str = "±",
    steps: bool = True,
    plot: bool = False,
    x_range: tuple[float, float] | None = None,
    save_path: str | None = None,
) -> sp.Expr:
    x = symvar(var)
    if isinstance(at, str):
        at = sp.sympify(at)
    else:
        at = sp.sympify(at)

    expr = parse_expr(expr_str, var)

    if direction == "±":
        r_right = sp.limit(expr, x, at, "+")
        r_left  = sp.limit(expr, x, at, "-")
        result  = r_right if sp.simplify(r_right - r_left) == 0 else sp.nan
    else:
        result = sp.limit(expr, x, at, direction)

    if steps:
        _print_steps(expr, x, at, direction, result)

    if plot:
        _plot_limit(expr, x, at, result, x_range, save_path)

    return result


# ── rich 2-panel plot ─────────────────────────────────────────────────────────

def _plot_limit(expr, var, at, result, x_range, save_path):
    try:
        at_num = float(at)
    except (TypeError, ValueError):
        at_num = 0.0

    if x_range is None:
        lo, hi = at_num - 5, at_num + 5
    else:
        lo, hi = x_range

    f   = sp.lambdify(var, expr, modules=["numpy"])
    xs  = np.linspace(lo, hi, 1200)
    xs  = xs[np.abs(xs - at_num) > 1e-7]

    def safe(arr):
        try:
            y = f(arr)
            return np.where(np.isfinite(y), y, np.nan)
        except Exception:
            return np.full_like(arr, np.nan)

    ys = safe(xs)

    # zoom window around limit point
    z_lo, z_hi = at_num - 1.2, at_num + 1.2
    mask = (xs > z_lo) & (xs < z_hi)
    xs_z, ys_z = xs[mask], ys[mask]

    fig = plt.figure(figsize=(14, 5))
    gs  = GridSpec(1, 2, figure=fig, wspace=0.35)
    ax1 = fig.add_subplot(gs[0])
    ax2 = fig.add_subplot(gs[1])

    at_tex = "\\infty" if at == sp.oo else str(at)

    for ax, x_data, y_data, title in [
        (ax1, xs,  ys,  f"$f({var}) = {sp.latex(expr)}$"),
        (ax2, xs_z, ys_z, f"Zoom near ${var} \\to {at_tex}$"),
    ]:
        ax.plot(x_data, y_data, color="#2563eb", linewidth=2)
        if result not in (sp.oo, -sp.oo, sp.nan, sp.zoo):
            try:
                ry = float(result)
                ax.axhline(ry, color="#dc2626", linewidth=1.2, linestyle="--",
                           label=f"Limit = {sp.simplify(result)}", alpha=0.8)
                ax.scatter([at_num], [ry], s=90, color="#dc2626", zorder=5)
            except (TypeError, ValueError):
                pass
        ax.axvline(at_num, color="gray", linewidth=0.8, linestyle=":")
        ax.set_xlabel(f"${var}$", fontsize=11)
        ax.set_title(title, fontsize=11, fontweight="bold")
        ax.legend(fontsize=9)
        ax.grid(True, alpha=0.25)
        finite = y_data[np.isfinite(y_data)] if hasattr(y_data, '__len__') else []
        if len(finite):
            rng = finite.max() - finite.min() or 1
            ax.set_ylim(finite.min() - rng * 0.15, finite.max() + rng * 0.15)

    # annotate approach arrows on zoom panel
    if result not in (sp.oo, -sp.oo, sp.nan, sp.zoo):
        try:
            ry = float(result)
            ax2.annotate("", xy=(at_num, ry),
                         xytext=(at_num - 0.8, ry),
                         arrowprops=dict(arrowstyle="->", color="#16a34a", lw=1.5))
            ax2.annotate("", xy=(at_num, ry),
                         xytext=(at_num + 0.8, ry),
                         arrowprops=dict(arrowstyle="->", color="#16a34a", lw=1.5))
            ax2.text(at_num, ry + rng * 0.08 if 'rng' in dir() else ry + 0.1,
                     f"Approaches {sp.simplify(result)}", ha="center",
                     fontsize=8, color="#16a34a")
        except Exception:
            pass

    fig.suptitle(
        f"$\\lim_{{{var} \\to {at_tex}}} {sp.latex(expr)} = {sp.latex(sp.simplify(result))}$",
        fontsize=13, fontweight="bold"
    )
    plt.tight_layout()
    if save_path:
        plt.savefig(save_path, dpi=150, bbox_inches="tight")
        info(f"Plot saved → {save_path}")
    else:
        plt.show()
    plt.close(fig)
