"""
calculearn._parser
==================
Shared utilities: expression parsing and symbol management.
"""

from __future__ import annotations

import sympy as sp

# Pre-defined local symbols to pass to sympify so user doesn't need to import sympy
_SYMPY_LOCALS = {
    "sin": sp.sin, "cos": sp.cos, "tan": sp.tan,
    "asin": sp.asin, "acos": sp.acos, "atan": sp.atan,
    "sinh": sp.sinh, "cosh": sp.cosh, "tanh": sp.tanh,
    "exp": sp.exp, "log": sp.log, "ln": sp.log,
    "sqrt": sp.sqrt, "Abs": sp.Abs, "abs": sp.Abs,
    "pi": sp.pi, "e": sp.E, "E": sp.E,
    "oo": sp.oo, "inf": sp.oo,
    "factorial": sp.factorial,
}


def symvar(name: str) -> sp.Symbol:
    """Return a SymPy symbol for *name* (assumed real)."""
    return sp.Symbol(name, real=True)


def parse_expr(expr_str: str, var: str = "x") -> sp.Expr:
    """
    Parse a string expression into a SymPy expression.

    Handles common student shorthand:
      - implicit multiplication:  "2x"  →  "2*x",   "x2"  →  "x**2"
      - caret notation:           "x^3" →  "x**3"
    """
    s = expr_str.strip()

    # Replace ^ with ** for exponentiation
    s = s.replace("^", "**")

    # Convert implicit multiplication patterns like "2x", "3sin", "xsin" etc.
    import re
    # number followed by letter/function: 2x → 2*x
    s = re.sub(r"(\d)([A-Za-z])", r"\1*\2", s)
    # letter followed by letter that starts a known function (rare, be conservative)
    # closing paren followed by var: )x → )*x
    s = re.sub(r"\)([A-Za-z0-9])", r")*\1", s)
    # var followed by (: x( → x*(
    s = re.sub(r"([A-Za-z0-9])\(", lambda m: m.group(1) + "*(", s)

    # But restore known functions that got mangled: sin*(x) → sin(x)
    known_funcs = [
        "sin", "cos", "tan", "asin", "acos", "atan",
        "sinh", "cosh", "tanh", "exp", "log", "ln", "sqrt",
        "Abs", "abs", "factorial",
    ]
    for fn in known_funcs:
        # fn*( → fn(
        s = s.replace(f"{fn}*(", f"{fn}(")

    locals_map = {**_SYMPY_LOCALS, var: symvar(var)}

    try:
        return sp.sympify(s, locals=locals_map)
    except sp.SympifyError as exc:
        raise ValueError(
            f"Could not parse expression '{expr_str}'.\n"
            f"  Processed form: '{s}'\n"
            f"  Hint: Use Python-style syntax, e.g. 'x**3 + 2*x' or 'sin(x)*exp(x)'.\n"
            f"  SymPy error: {exc}"
        ) from exc
