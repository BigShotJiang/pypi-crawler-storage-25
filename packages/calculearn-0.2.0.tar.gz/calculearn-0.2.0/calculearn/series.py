"""
calculearn.series  (v0.2)
=========================
Taylor / Maclaurin series with LaTeX term-by-term steps,
convergence error plot, and optional GIF animation.
"""

from __future__ import annotations

import sympy as sp
import numpy as np
import matplotlib.pyplot as plt
import matplotlib
matplotlib.use("Agg")
from matplotlib.gridspec import GridSpec
from matplotlib.animation import FuncAnimation, PillowWriter

from ._parser import parse_expr, symvar
from ._latex_printer import (
    section, step, substep, rule_box, result_line, divider, info, to_latex
)


# ── symbolic helpers ──────────────────────────────────────────────────────────

def _term(expr, var, a, k):
    dk = sp.diff(expr, var, k)
    c  = sp.simplify(dk.subs(var, a) / sp.factorial(k))
    return c * (var - a) ** k


def _partial_sums(expr, var, a, n):
    sums, acc = [], sp.Integer(0)
    for k in range(n):
        acc = sp.expand(acc + _term(expr, var, a, k))
        sums.append(acc)
    return sums


# ── step printer ──────────────────────────────────────────────────────────────

def _print_steps(expr, var, a, n, psums):
    a_tex = to_latex(a)

    section(
        f"TAYLOR SERIES  —  $f({var}) = {to_latex(expr)}$  around ${var} = {a_tex}$",
        f"Expanding to {n} terms using the Taylor formula."
    )

    rule_box(
        "Taylor Series Formula",
        "T(x) = \\sum_{k=0}^{\\infty} \\frac{f^{(k)}(a)}{k!}(x-a)^k"
    )

    print(f"  We compute each term  $ \\frac{{f^{{(k)}}({a_tex})}}{{k!}} \\cdot ({var} - {a_tex})^k $  for $ k = 0, 1, \\ldots, {n-1} $\n")

    for k in range(n):
        dk     = sp.diff(expr, var, k)
        val    = dk.subs(var, a)
        fact_k = sp.factorial(k)
        coeff  = sp.simplify(val / fact_k)
        term   = sp.simplify(_term(expr, var, a, k))

        print(f"  {'─'*60}")
        print(f"  k = {k}")
        print(f"      $ f^{{({k})}}({var}) = {to_latex(sp.simplify(dk))} $")
        print(f"      $ f^{{({k})}}({a_tex}) = {to_latex(val)} $")
        print(f"      $ {k}! = {to_latex(fact_k)} $")
        print(f"      Term:  $ \\frac{{{to_latex(val)}}}{{{to_latex(fact_k)}}} \\cdot ({var} - {a_tex})^{k} = {to_latex(term)} $")
        print(f"      Running sum  $ T_{{{k}}}({var}) = {to_latex(sp.simplify(psums[k]))} $\n")

    divider()
    result_line(
        f"Final Taylor Polynomial  $T_{{{n-1}}}({var})$",
        to_latex(sp.simplify(psums[-1]))
    )


# ── public API ────────────────────────────────────────────────────────────────

def taylor(
    expr_str: str,
    var: str = "x",
    around=0,
    terms: int = 6,
    steps: bool = True,
    plot: bool = True,
    animate: bool = False,
    x_range: tuple[float, float] = (-4, 4),
    save_path: str | None = None,
    anim_path: str | None = None,
) -> sp.Expr:
    """
    Expand *expr_str* as a Taylor series around *around* up to *terms* terms.
    """
    x     = symvar(var)
    a     = sp.sympify(around)
    expr  = parse_expr(expr_str, var)
    psums = _partial_sums(expr, x, a, terms)

    if steps:
        _print_steps(expr, x, a, terms, psums)

    if plot or animate:
        _plot_taylor(expr, psums, x, a, x_range, save_path, animate, anim_path)

    return psums[-1]


# ── rich 2-panel plot (approximation + error) ─────────────────────────────────

def _plot_taylor(expr, psums, var, a, x_range, save_path, animate, anim_path):
    xs = np.linspace(x_range[0], x_range[1], 600)
    f  = sp.lambdify(var, expr, modules=["numpy"])

    def safe(fn):
        try:
            y = fn(xs)
            y = np.broadcast_to(np.atleast_1d(y), xs.shape).copy().astype(float)
            return np.where(np.isfinite(y), y, np.nan)
        except Exception:
            return np.full_like(xs, np.nan)

    ys = safe(f)

    poly_funcs = [sp.lambdify(var, p, modules=["numpy"]) for p in psums]

    # ── static (2-panel) ──────────────────────────────────────────────────────
    if not animate:
        fig = plt.figure(figsize=(15, 5))
        gs  = GridSpec(1, 2, figure=fig, wspace=0.35)
        ax1 = fig.add_subplot(gs[0])   # approximations
        ax2 = fig.add_subplot(gs[1])   # absolute error

        ax1.plot(xs, ys, color="black", linewidth=2.5,
                 label=f"$f({var}) = {sp.latex(expr)}$", zorder=4)
        colors = plt.cm.plasma(np.linspace(0.05, 0.85, len(psums)))

        errors = []
        for i, (pf, col) in enumerate(zip(poly_funcs, colors)):
            pys = safe(pf)
            clipped = np.where(np.abs(pys) < 15, pys, np.nan)
            ax1.plot(xs, clipped, color=col, linewidth=1.5, alpha=0.75,
                     label=f"$T_{{{i}}}$  ({i+1} term{'s' if i else ''})")
            err = np.abs(ys - pys)
            errors.append(err)

        ax1.set_ylim(-3, 3)
        ax1.set_xlabel(f"${var}$", fontsize=11)
        ax1.set_title(f"Taylor Approximations of  $f({var}) = {sp.latex(expr)}$",
                      fontsize=11, fontweight="bold")
        ax1.legend(fontsize=7, ncol=2, loc="upper right")
        ax1.grid(True, alpha=0.25)
        ax1.axhline(0, color="gray", linewidth=0.6)

        # error panel
        for i, (err, col) in enumerate(zip(errors, colors)):
            ax2.semilogy(xs, err + 1e-12, color=col, linewidth=1.5, alpha=0.75,
                         label=f"$|f - T_{{{i}}}|$")
        ax2.set_xlabel(f"${var}$", fontsize=11)
        ax2.set_title("Absolute Error  $|f(x) - T_n(x)|$  (log scale)",
                      fontsize=11, fontweight="bold")
        ax2.legend(fontsize=7, ncol=2, loc="upper right")
        ax2.grid(True, alpha=0.25)
        ax2.set_ylim(1e-12, 10)

        fig.suptitle(
            f"Taylor Series  —  $f({var}) = {sp.latex(expr)}$  around ${var} = {sp.latex(a)}$",
            fontsize=13, fontweight="bold"
        )
        plt.tight_layout()
        if save_path:
            plt.savefig(save_path, dpi=150, bbox_inches="tight")
            info(f"Plot saved → {save_path}")
        else:
            plt.show()
        plt.close(fig)
        return

    # ── animated GIF ─────────────────────────────────────────────────────────
    fig, ax = plt.subplots(figsize=(10, 5))
    ax.plot(xs, ys, color="black", linewidth=2.5,
            label=f"$f({var}) = {sp.latex(expr)}$", zorder=4)
    ax.axhline(0, color="gray", linewidth=0.5)
    ax.set_ylim(-3, 3)
    ax.set_xlabel(f"${var}$", fontsize=11)
    ax.grid(True, alpha=0.25)

    line,       = ax.plot([], [], color="#e63946", linewidth=2)
    title_text  = ax.set_title("", fontsize=12, fontweight="bold")

    def _init():
        line.set_data([], [])
        return line,

    def _update(frame):
        pys = safe(poly_funcs[frame])
        clipped = np.where(np.abs(pys) < 15, pys, np.nan)
        line.set_data(xs, clipped)
        title_text.set_text(
            f"Taylor Series  —  $T_{{{frame}}}$  ({frame+1} term{'s' if frame else ''})"
        )
        return line, title_text

    anim = FuncAnimation(fig, _update, frames=len(psums),
                         init_func=_init, interval=700, blit=False, repeat=True)
    path = anim_path or "/tmp/taylor_anim.gif"
    anim.save(path, writer=PillowWriter(fps=1.5), dpi=120)
    info(f"Animation saved → {path}")
    plt.close(fig)
