"""
calculearn._latex_printer
==========================
Pretty-print LaTeX math to the terminal using Unicode box-drawing characters.
No external dependencies beyond SymPy.

Usage
-----
    from ._latex_printer import lprint, lbox, section, step, result_line

    section("DERIVATIVE")
    step(1, "Apply the Power Rule", r"\\frac{d}{dx}[x^3] = 3x^2")
    result_line(r"f'(x) = 3x^2 + 4x + 1")
"""

from __future__ import annotations
import sympy as sp

# ── SymPy → LaTeX helper ──────────────────────────────────────────────────────

def to_latex(expr) -> str:
    """Convert a SymPy expression to a LaTeX string."""
    try:
        return sp.latex(expr)
    except Exception:
        return str(expr)


# ── terminal width ────────────────────────────────────────────────────────────

WIDTH = 68


# ── top-level section banner ──────────────────────────────────────────────────

def section(title: str, subtitle: str = "") -> None:
    """Print a bold section header."""
    bar = "═" * WIDTH
    print(f"\n{bar}")
    print(f"  {title}")
    if subtitle:
        print(f"  {subtitle}")
    print(f"{bar}\n")


# ── inline LaTeX renderer (Unicode approximation) ────────────────────────────

def lprint(latex_str: str, indent: int = 2) -> None:
    """
    Print a LaTeX string with an indent.
    Wraps in $...$ delimiters so the reader knows it's math.
    """
    pad = " " * indent
    print(f"{pad}  $  {latex_str}  $")


# ── numbered step ─────────────────────────────────────────────────────────────

def step(n: int, description: str, math: str = "", extra: str = "") -> None:
    """
    Print one numbered step.

      Step 1 ▸  description
               $  math  $
               extra text
    """
    print(f"  Step {n} ▸  {description}")
    if math:
        lprint(math, indent=4)
    if extra:
        print(f"          {extra}")
    print()


# ── sub-step (indented) ───────────────────────────────────────────────────────

def substep(label: str, math: str = "", note: str = "") -> None:
    """
    Print an indented sub-item.

        ◦ label
          $  math  $
    """
    print(f"      ◦  {label}")
    if math:
        lprint(math, indent=8)
    if note:
        print(f"         ↳  {note}")


# ── rule callout box ──────────────────────────────────────────────────────────

def rule_box(rule_name: str, formula: str) -> None:
    """
    Print a highlighted rule box.

    ┌─ Rule: Power Rule ──────────────────────────────────────┐
    │   $  \\frac{d}{dx}[x^n] = n x^{n-1}  $                  │
    └─────────────────────────────────────────────────────────┘
    """
    inner = f"  Rule: {rule_name}  —  $ {formula} $"
    pad_len = max(WIDTH - 2 - len(inner), 2)
    print(f"  ┌{'─' * (WIDTH - 2)}┐")
    print(f"  │{inner}{' ' * pad_len}│")
    print(f"  └{'─' * (WIDTH - 2)}┘")
    print()


# ── final result banner ───────────────────────────────────────────────────────

def result_line(label: str, math: str) -> None:
    """
    Print the final answer prominently.

  ╔══ Result ════════════════════════════════════════════════╗
  ║   f'(x)  =  $ 3x^2 + 4x + 1 $
  ╚══════════════════════════════════════════════════════════╝
    """
    bar = "═" * (WIDTH - 2)
    print(f"  ╔══ {label} {'═' * (WIDTH - 7 - len(label))}╗")
    print(f"  ║")
    print(f"  ║     $  {math}  $")
    print(f"  ║")
    print(f"  ╚{bar}╝\n")


# ── warning / info line ───────────────────────────────────────────────────────

def warn(msg: str) -> None:
    print(f"  ⚠  {msg}\n")


def info(msg: str) -> None:
    print(f"  ℹ  {msg}\n")


# ── divider ───────────────────────────────────────────────────────────────────

def divider(char: str = "─") -> None:
    print(f"  {char * (WIDTH - 2)}")
