"""
calculearn
==========
An interactive calculus toolkit for university students.

Provides step-by-step symbolic computation, plain-English explanations,
and clean Matplotlib visualisations for:

  • Derivatives         — derivative(expr, var, steps, plot)
  • Limits              — limit(expr, var, at, direction, steps, plot)
  • Integration         — integrate(expr, var, lower, upper, steps, plot)
  • Taylor Series       — taylor(expr, var, around, terms, animate)
  • Critical Points     — critical_points(expr, var, steps, plot)

Quick start
-----------
>>> from calculearn import derivative, limit, integrate, taylor, critical_points
>>> derivative("x**3 + 2*x**2 + x", var="x", steps=True, plot=False)
>>> limit("sin(x)/x", var="x", at=0, steps=True)
>>> integrate("x**2 + 1", var="x", lower=0, upper=3, steps=True, plot=False)
>>> taylor("cos(x)", var="x", around=0, terms=6)
>>> critical_points("x**3 - 3*x", var="x", steps=True, plot=False)
"""

from .derivatives     import derivative
from .limits          import limit
from .integrals       import integrate
from .series          import taylor
from .critical_points import critical_points, CriticalPoint

__version__ = "0.2.0"
__all__ = [
    "derivative",
    "limit",
    "integrate",
    "taylor",
    "critical_points",
    "CriticalPoint",
]
