"""
calculearn.derivatives  (v0.2)
==============================
Symbolic differentiation with LaTeX-formatted, rule-by-rule explanations
and rich multi-panel plots.
"""

from __future__ import annotations

import sympy as sp
import numpy as np
import matplotlib.pyplot as plt
import matplotlib
matplotlib.use("Agg")

from ._parser import parse_expr, symvar
from ._latex_printer import (
    section, step, substep, rule_box, result_line, divider, info, to_latex
)


# ── rule-by-rule step walker ──────────────────────────────────────────────────

def _walk(expr: sp.Expr, var: sp.Symbol, depth: int = 0) -> sp.Expr:
    """Recursively explain differentiation of *expr* with LaTeX output."""
    ind = "  " * depth

    # constant
    if not expr.has(var):
        print(f"{ind}      ◦  The expression  $ {to_latex(expr)} $  does not contain $ {var} $,")
        print(f"{ind}         so its derivative is zero by the Constant Rule.")
        print(f"{ind}         $ \\frac{{d}}{{d{var}}}[{to_latex(expr)}] = 0 $\n")
        return sp.Integer(0)

    # bare variable
    if expr == var:
        print(f"{ind}      ◦  $ \\frac{{d}}{{d{var}}}[{var}] = 1 $  (Identity Rule)\n")
        return sp.Integer(1)

    # ── sum / difference ──────────────────────────────────────────────────────
    if isinstance(expr, sp.Add):
        print(f"{ind}      ◦  Expression: $ {to_latex(expr)} $")
        print(f"{ind}         → Sum/Difference Rule: differentiate each term independently.\n")
        parts = [_walk(t, var, depth + 1) for t in expr.args]
        result = sp.Add(*parts)
        print(f"{ind}      ◦  Combining terms:  $ {to_latex(sp.simplify(result))} $\n")
        return result

    # ── quotient check ────────────────────────────────────────────────────────
    if isinstance(expr, sp.Mul):
        neg_pows = [a for a in expr.args
                    if isinstance(a, sp.Pow) and a.args[1].is_negative and a.args[0].has(var)]
        if neg_pows:
            denom = sp.Mul(*[sp.Pow(a.args[0], -a.args[1]) for a in neg_pows])
            numer = sp.simplify(expr * denom)
            u, v = numer, denom
            print(f"{ind}      ◦  Recognise a quotient: $ \\frac{{{to_latex(u)}}}{{{to_latex(v)}}} $")
            print(f"{ind}         → Quotient Rule:  $ \\left(\\frac{{u}}{{v}}\\right)' = \\frac{{v u' - u v'}}{{v^2}} $\n")
            print(f"{ind}         Let  $ u = {to_latex(u)} $,  $ v = {to_latex(v)} $\n")
            du = _walk(u, var, depth + 1)
            dv = _walk(v, var, depth + 1)
            result = sp.simplify((v * du - u * dv) / v**2)
            print(f"{ind}      ◦  Substituting into formula:")
            print(f"{ind}         $ \\frac{{{to_latex(v)} \\cdot {to_latex(du)} - {to_latex(u)} \\cdot {to_latex(dv)}}}{{{to_latex(v)}^2}} = {to_latex(result)} $\n")
            return result

    # ── product ───────────────────────────────────────────────────────────────
    if isinstance(expr, sp.Mul):
        var_factors = [f for f in expr.args if f.has(var)]
        const_factors = [f for f in expr.args if not f.has(var)]
        if len(var_factors) >= 2:
            u = var_factors[0]
            v = sp.Mul(*var_factors[1:])
            const = sp.Mul(*const_factors) if const_factors else sp.Integer(1)
            print(f"{ind}      ◦  Recognise a product: $ {to_latex(u)} \\cdot {to_latex(v)} $")
            print(f"{ind}         → Product Rule:  $ (uv)' = u'v + uv' $\n")
            print(f"{ind}         Let  $ u = {to_latex(u)} $,  $ v = {to_latex(v)} $\n")
            du = _walk(u, var, depth + 1)
            dv = _walk(v, var, depth + 1)
            result = sp.expand(const * (du * v + u * dv))
            print(f"{ind}      ◦  Substituting: $ {to_latex(const)}({to_latex(du)} \\cdot {to_latex(v)} + {to_latex(u)} \\cdot {to_latex(dv)}) = {to_latex(sp.simplify(result))} $\n")
            return result
        if const_factors:
            const = sp.Mul(*const_factors)
            inner = sp.Mul(*var_factors)
            print(f"{ind}      ◦  Constant Multiple Rule:  $ \\frac{{d}}{{d{var}}}[{to_latex(const)} \\cdot f] = {to_latex(const)} \\cdot f' $")
            print(f"{ind}         Factor: $ {to_latex(const)} \\times \\frac{{d}}{{d{var}}}[{to_latex(inner)}] $\n")
            di = _walk(inner, var, depth + 1)
            result = sp.expand(const * di)
            print(f"{ind}      ◦  $ {to_latex(const)} \\times {to_latex(di)} = {to_latex(result)} $\n")
            return result

    # ── power rule ────────────────────────────────────────────────────────────
    if isinstance(expr, sp.Pow):
        base, exp = expr.args
        if base == var and exp.is_number:
            result = exp * sp.Pow(var, exp - 1)
            print(f"{ind}      ◦  Power Rule:  $ \\frac{{d}}{{d{var}}}[{var}^{{{to_latex(exp)}}}] = {to_latex(exp)} \\cdot {var}^{{{to_latex(exp)}-1}} $")
            print(f"{ind}         Calculation: $ {to_latex(exp)} \\cdot {var}^{{{to_latex(exp - 1)}}} = {to_latex(sp.simplify(result))} $\n")
            return result
        # general power / exponential — chain rule
        print(f"{ind}      ◦  Chain Rule (general power):  $ \\frac{{d}}{{d{var}}}[{to_latex(expr)}] $")
        result = sp.diff(expr, var)
        print(f"{ind}         $ = {to_latex(sp.simplify(result))} $\n")
        return result

    # ── standard functions ────────────────────────────────────────────────────
    func_info = {
        sp.sin:  ("\\sin",  "\\cos({inner})",          "Standard: $ \\frac{{d}}{{dx}}[\\sin(x)] = \\cos(x) $"),
        sp.cos:  ("\\cos",  "-\\sin({inner})",          "Standard: $ \\frac{{d}}{{dx}}[\\cos(x)] = -\\sin(x) $"),
        sp.tan:  ("\\tan",  "\\sec^2({inner})",         "Standard: $ \\frac{{d}}{{dx}}[\\tan(x)] = \\sec^2(x) $"),
        sp.exp:  ("e^",     "e^{{{inner}}}",            "Standard: $ \\frac{{d}}{{dx}}[e^x] = e^x $"),
        sp.log:  ("\\ln",   "\\frac{{1}}{{{inner}}}",   "Standard: $ \\frac{{d}}{{dx}}[\\ln(x)] = \\frac{{1}}{{x}} $"),
        sp.asin: ("\\arcsin","\\frac{{1}}{{\\sqrt{{1-({inner})^2}}}}","Standard arcsine derivative"),
        sp.acos: ("\\arccos","\\frac{{-1}}{{\\sqrt{{1-({inner})^2}}}}","Standard arccosine derivative"),
        sp.atan: ("\\arctan","\\frac{{1}}{{1+({inner})^2}}","Standard arctangent derivative"),
    }
    for func_cls, (fname, template, note) in func_info.items():
        if isinstance(expr, func_cls):
            inner = expr.args[0]
            desc = template.format(inner=to_latex(inner))
            print(f"{ind}      ◦  {note}")
            if inner != var:
                du = sp.diff(inner, var)
                print(f"{ind}         Chain Rule: inner function $ u = {to_latex(inner)} $,  $ u' = {to_latex(du)} $")
                result = sp.simplify(sp.diff(expr, var))
                print(f"{ind}         $ \\frac{{d}}{{d{var}}}[{fname}({to_latex(inner)})] = {desc} \\cdot {to_latex(du)} = {to_latex(result)} $\n")
            else:
                result = sp.diff(expr, var)
                print(f"{ind}         $ \\frac{{d}}{{d{var}}}[{fname}({var})] = {desc} $\n")
            return result

    # fallback
    print(f"{ind}      ◦  $ \\frac{{d}}{{d{var}}}[{to_latex(expr)}] $ — applying symbolic differentiation\n")
    return sp.diff(expr, var)


# ── public API ────────────────────────────────────────────────────────────────

def derivative(
    expr_str: str,
    var: str = "x",
    steps: bool = True,
    plot: bool = False,
    x_range: tuple[float, float] = (-5, 5),
    save_path: str | None = None,
) -> sp.Expr:
    """
    Compute the symbolic derivative of *expr_str* with respect to *var*.

    Parameters
    ----------
    expr_str : str   e.g. ``"x**3 + 2*x"`` or ``"sin(x)*exp(x)"``
    var      : str   variable (default ``"x"``)
    steps    : bool  print LaTeX step-by-step working
    plot     : bool  produce multi-panel plot
    x_range  : tuple domain for plotting
    save_path: str   save plot to file instead of displaying
    """
    x = symvar(var)
    expr = parse_expr(expr_str, var)
    deriv = sp.diff(expr, x)

    if steps:
        section(
            f"DERIVATIVE  —  d/d{var} [ {to_latex(expr)} ]",
            "We differentiate the expression step by step, naming each rule used."
        )

        rule_box("Sum/Difference Rule", r"\frac{d}{dx}[f \pm g] = f' \pm g'")

        print("  Expanding the expression into individual terms:\n")
        _walk(expr, x, depth=0)

        divider()
        result_line(f"f'({var})", to_latex(sp.simplify(deriv)))

    if plot:
        _plot_derivative(expr, deriv, x, x_range, save_path)

    return deriv


# ── rich 3-panel plot ─────────────────────────────────────────────────────────

def _plot_derivative(expr, deriv, var, x_range, save_path):
    xs = np.linspace(x_range[0], x_range[1], 800)
    f  = sp.lambdify(var, expr,  modules=["numpy"])
    df = sp.lambdify(var, deriv, modules=["numpy"])
    d2 = sp.lambdify(var, sp.diff(deriv, var), modules=["numpy"])

    def safe(fn):
        try:
            y = fn(xs)
            return np.where(np.isfinite(y), y, np.nan)
        except Exception:
            return np.full_like(xs, np.nan)

    ys, dys, d2ys = safe(f), safe(df), safe(d2)

    fig, axes = plt.subplots(1, 3, figsize=(16, 5))
    fig.suptitle(
        f"$f({var}) = {sp.latex(expr)}$  and its Derivatives",
        fontsize=14, fontweight="bold", y=1.02
    )

    panels = [
        (ys,  "#2563eb", f"$f({var}) = {sp.latex(expr)}$",          "Function"),
        (dys, "#dc2626", f"$f'({var}) = {sp.latex(sp.simplify(deriv))}$", "First Derivative  $f'$"),
        (d2ys,"#16a34a", f"$f''({var})$",                             "Second Derivative  $f''$"),
    ]

    for ax, (y, color, title, ylabel) in zip(axes, panels):
        ax.plot(xs, y, color=color, linewidth=2.2)
        ax.axhline(0, color="black", linewidth=0.7, linestyle="--", alpha=0.5)
        ax.axvline(0, color="black", linewidth=0.7, linestyle="--", alpha=0.5)

        # shade positive / negative regions for f'
        if ylabel.startswith("First"):
            ax.fill_between(xs, y, 0, where=(y > 0), alpha=0.12, color=color, label="f' > 0 (increasing)")
            ax.fill_between(xs, y, 0, where=(y < 0), alpha=0.12, color="orange", label="f' < 0 (decreasing)")
            ax.legend(fontsize=8, loc="upper right")

        ax.set_title(title, fontsize=10, pad=8)
        ax.set_xlabel(f"${var}$", fontsize=11)
        ax.set_ylabel(ylabel, fontsize=10)
        ax.grid(True, alpha=0.25)
        finite = y[np.isfinite(y)]
        if len(finite):
            rng = finite.max() - finite.min() or 1
            ax.set_ylim(finite.min() - rng * 0.15, finite.max() + rng * 0.15)

    plt.tight_layout()
    if save_path:
        plt.savefig(save_path, dpi=150, bbox_inches="tight")
        info(f"Plot saved → {save_path}")
    else:
        plt.show()
    plt.close(fig)
