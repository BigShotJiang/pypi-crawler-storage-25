"""
calculearn.critical_points  (v0.2)
===================================
Find and classify critical points with LaTeX-formatted second-derivative-test
explanations and a rich 3-panel plot (f, f', f'').
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import List

import sympy as sp
import numpy as np
import matplotlib.pyplot as plt
import matplotlib
matplotlib.use("Agg")
from matplotlib.gridspec import GridSpec

from ._parser import parse_expr, symvar
from ._latex_printer import (
    section, step, substep, rule_box, result_line, divider, info, warn, to_latex
)


# ── data class ────────────────────────────────────────────────────────────────

@dataclass
class CriticalPoint:
    x_val: sp.Expr
    y_val: sp.Expr
    f2_val: sp.Expr
    classification: str

    def __str__(self):
        return (f"  x = {self.x_val}  |  f(x) = {self.y_val}  |  "
                f"f''(x) = {self.f2_val}  |  {self.classification}")


def _classify(f2_val):
    try:
        v = float(f2_val.evalf())
        if v > 1e-12:   return "local minimum"
        if v < -1e-12:  return "local maximum"
        return "saddle / inflection (inconclusive)"
    except (TypeError, ValueError):
        if f2_val.is_positive: return "local minimum"
        if f2_val.is_negative: return "local maximum"
        return "inconclusive"


# ── step printer ──────────────────────────────────────────────────────────────

def _print_steps(expr, var, f1, f2, cps):
    section(
        f"CRITICAL POINTS  —  $f({var}) = {to_latex(expr)}$",
        "We find where f'(x) = 0 and apply the Second Derivative Test."
    )

    step(1, "Compute the First Derivative  $f'(x)$",
         f"f'({var}) = {to_latex(sp.simplify(f1))}")

    step(2, f"Set $f'({var}) = 0$ and Solve",
         f"{to_latex(sp.simplify(f1))} = 0")

    sols = sp.solve(f1, var)
    real_sols = [s for s in sols if s.is_real]
    if not real_sols:
        print("      No real solutions → this function has no critical points.\n")
        return
    for s in real_sols:
        print(f"      $ {var} = {to_latex(s)} $")
    print()

    step(3, "Compute the Second Derivative  $f''(x)$",
         f"f''({var}) = {to_latex(sp.simplify(f2))}")

    rule_box(
        "Second Derivative Test",
        "f''(x_0) > 0 \\Rightarrow \\text{Local MIN} \\quad "
        "f''(x_0) < 0 \\Rightarrow \\text{Local MAX} \\quad "
        "f''(x_0) = 0 \\Rightarrow \\text{Inconclusive}"
    )

    step(4, f"Evaluate $f''({var})$ at each critical point and classify")

    for i, cp in enumerate(cps, 1):
        print(f"  {'─'*56}")
        print(f"  Critical Point {i}:  $ {var} = {to_latex(cp.x_val)} $\n")
        print(f"      $ f({to_latex(cp.x_val)}) = {to_latex(sp.simplify(cp.y_val))} $")
        print(f"      $ f''({to_latex(cp.x_val)}) = {to_latex(sp.simplify(cp.f2_val))} $\n")

        if cp.classification == "local minimum":
            print(f"      $ f'' > 0 $ → concave upward  ∪  →  **LOCAL MINIMUM**")
            print(f"      The function has a trough at $ ({to_latex(cp.x_val)},\\, {to_latex(sp.simplify(cp.y_val))}) $\n")
        elif cp.classification == "local maximum":
            print(f"      $ f'' < 0 $ → concave downward  ∩  →  **LOCAL MAXIMUM**")
            print(f"      The function has a peak at $ ({to_latex(cp.x_val)},\\, {to_latex(sp.simplify(cp.y_val))}) $\n")
        else:
            print(f"      $ f'' = 0 $ → Second derivative test is **INCONCLUSIVE**")
            print(f"      Further analysis (sign chart of $f'$) is needed.\n")

    divider()
    print("  Summary of all critical points:\n")
    for cp in cps:
        sym = "▼" if cp.classification == "local minimum" else ("▲" if cp.classification == "local maximum" else "◆")
        print(f"    {sym}  $ {var} = {to_latex(cp.x_val)} $  →  {cp.classification.upper()}")
        print(f"       Point: $ ({to_latex(cp.x_val)},\\, {to_latex(sp.simplify(cp.y_val))}) $\n")


# ── public API ────────────────────────────────────────────────────────────────

def critical_points(
    expr_str: str,
    var: str = "x",
    steps: bool = True,
    plot: bool = False,
    x_range: tuple[float, float] = (-5, 5),
    save_path: str | None = None,
) -> List[CriticalPoint]:
    """
    Find and classify critical points of *expr_str* using the second derivative test.
    """
    x    = symvar(var)
    expr = parse_expr(expr_str, var)
    f1   = sp.diff(expr, x)
    f2   = sp.diff(f1, x)

    cps: List[CriticalPoint] = []
    for sol in sp.solve(f1, x):
        if not sol.is_real:
            continue
        y_val  = sp.simplify(expr.subs(x, sol))
        f2_val = sp.simplify(f2.subs(x, sol))
        cps.append(CriticalPoint(sol, y_val, f2_val, _classify(f2_val)))

    if steps:
        _print_steps(expr, x, f1, f2, cps)

    if plot:
        _plot_critical(expr, f1, f2, x, cps, x_range, save_path)

    return cps


# ── rich 3-panel plot ─────────────────────────────────────────────────────────

_CP_STYLE = {
    "local minimum":  ("#16a34a", "v", "Local Min"),
    "local maximum":  ("#dc2626", "^", "Local Max"),
    "saddle / inflection (inconclusive)": ("#d97706", "D", "Inflection"),
    "inconclusive":   ("#d97706", "D", "Inconclusive"),
}


def _plot_critical(expr, f1, f2, var, cps, x_range, save_path):
    f   = sp.lambdify(var, expr, modules=["numpy"])
    df  = sp.lambdify(var, f1,   modules=["numpy"])
    d2f = sp.lambdify(var, f2,   modules=["numpy"])

    xs = np.linspace(x_range[0], x_range[1], 800)

    def safe(fn):
        try:
            y = fn(xs)
            return np.where(np.isfinite(y), y, np.nan)
        except Exception:
            return np.full_like(xs, np.nan)

    ys, dys, d2ys = safe(f), safe(df), safe(d2f)

    fig = plt.figure(figsize=(16, 5))
    gs  = GridSpec(1, 3, figure=fig, wspace=0.38)
    ax1 = fig.add_subplot(gs[0])   # f(x)
    ax2 = fig.add_subplot(gs[1])   # f'(x)
    ax3 = fig.add_subplot(gs[2])   # f''(x)

    panels = [
        (ax1, ys,   "#2563eb", f"$f({var}) = {sp.latex(expr)}$",    f"$f({var})$"),
        (ax2, dys,  "#dc2626", f"$f'({var}) = {sp.latex(sp.simplify(f1))}$", f"$f'({var})$  — zero at critical points"),
        (ax3, d2ys, "#16a34a", f"$f''({var}) = {sp.latex(sp.simplify(f2))}$", f"$f''({var})$  — sign gives concavity"),
    ]

    for ax, y, color, title, ylabel in panels:
        ax.plot(xs, y, color=color, linewidth=2.2)
        ax.axhline(0, color="black", linewidth=0.7, linestyle="--", alpha=0.5)
        ax.axvline(0, color="black", linewidth=0.7, linestyle="--", alpha=0.5)

        # shade concavity on f'' panel
        if ylabel.startswith("$f''"):
            ax.fill_between(xs, y, 0, where=(y > 0), alpha=0.12, color="#16a34a", label="Concave up")
            ax.fill_between(xs, y, 0, where=(y < 0), alpha=0.12, color="#dc2626", label="Concave down")
            ax.legend(fontsize=8)

        ax.set_title(title, fontsize=9, fontweight="bold", pad=6)
        ax.set_xlabel(f"${var}$", fontsize=11)
        ax.set_ylabel(ylabel, fontsize=9)
        ax.grid(True, alpha=0.25)
        finite = y[np.isfinite(y)]
        if len(finite):
            rng = finite.max() - finite.min() or 1
            ax.set_ylim(finite.min() - rng * 0.2, finite.max() + rng * 0.3)

    # mark critical points on all three panels
    added_labels = set()
    for cp in cps:
        try:
            cx = float(cp.x_val.evalf())
            cy = float(cp.y_val.evalf())
        except (TypeError, ValueError):
            continue
        if not (x_range[0] <= cx <= x_range[1]):
            continue

        style = _CP_STYLE.get(cp.classification, ("#7c3aed", "o", "Unknown"))
        color, marker, label = style

        for ax, y_arr in [(ax1, ys), (ax2, dys), (ax3, d2ys)]:
            idx = np.argmin(np.abs(xs - cx))
            plot_y = y_arr[idx] if np.isfinite(y_arr[idx]) else 0
            if ax == ax1:
                plot_y = cy  # exact symbolic value on f panel
            lbl = label if label not in added_labels else ""
            ax.scatter(cx, plot_y, s=100, color=color, marker=marker,
                       zorder=6, label=lbl, edgecolors="black", linewidths=0.8)
            added_labels.add(label)

        # annotate on f(x) panel only
        offset_x = 12 if cx >= 0 else -95
        offset_y = 18 if cy >= 0 else -30
        ax1.annotate(
            f"({cx:.2f}, {cy:.2f})\n{cp.classification}",
            xy=(cx, cy), fontsize=8, color="black", fontweight="bold",
            xytext=(offset_x, offset_y), textcoords="offset points",
            arrowprops=dict(arrowstyle="->", color="gray", lw=0.8),
            bbox=dict(boxstyle="round,pad=0.3", fc="white", ec=color, lw=1.5, alpha=0.92),
        )

    # unified legend on f panel
    handles, labels = ax1.get_legend_handles_labels()
    unique = dict(zip(labels, handles))
    ax1.legend(unique.values(), unique.keys(), fontsize=8, loc="upper right")

    fig.suptitle(
        f"Critical Point Analysis  —  $f({var}) = {sp.latex(expr)}$",
        fontsize=13, fontweight="bold"
    )
    plt.tight_layout()
    if save_path:
        plt.savefig(save_path, dpi=150, bbox_inches="tight")
        info(f"Plot saved → {save_path}")
    else:
        plt.show()
    plt.close(fig)
