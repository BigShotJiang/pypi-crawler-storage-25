# calculearn

> **An interactive calculus toolkit for university students.**  
> Solve calculus problems step-by-step in plain English, see symbolic working, and produce clean visualisations — all from Python.

---

## Installation

```bash
# From the project folder
pip install -e .

# Or install dependencies manually
pip install sympy matplotlib numpy
```

**Requirements:** Python ≥ 3.9, sympy ≥ 1.12, matplotlib ≥ 3.7, numpy ≥ 1.24

---

## Quick Import

```python
from calculearn import derivative, limit, integrate, taylor, critical_points
```

---

## Feature Guide

### 1. Derivatives

Compute the symbolic derivative, print each differentiation rule applied,
and optionally plot f(x) alongside f'(x).

```python
from calculearn import derivative

# Basic polynomial
result = derivative("x**3 + 2*x**2 + x", var="x", steps=True, plot=True)

# Product rule
derivative("sin(x) * exp(x)", var="x", steps=True)

# Chain rule
derivative("cos(x**2)", var="x", steps=True)

# Save the plot to a file
derivative("x**4 - 3*x**2", var="x", plot=True, save_path="deriv_plot.png")
```

**Output (excerpt):**
```
════════════════════════════════════════════════════════════
  DERIVATIVE  —  d/dx[x**3 + 2*x**2 + x]
════════════════════════════════════════════════════════════

── Step-by-step working ──

• d/dx[x**3 + 2*x**2 + x]
  Rule: Sum/Difference Rule → differentiate each term separately
    • d/dx[x**3]
      Rule: Power Rule → n·x^(n−1)
      ↳ 3·x^2 = 3*x**2
    ...

── Final answer ──
  f'(x) = 3*x**2 + 4*x + 1
```

---

### 2. Limits

Evaluate two-sided, one-sided, and infinite limits with strategy detection
(direct substitution → factoring → L'Hôpital's Rule).

```python
from calculearn import limit

# Classic 0/0 form
limit("sin(x)/x", var="x", at=0, steps=True)

# Factoring approach
limit("(x**2 - 1)/(x - 1)", var="x", at=1, steps=True)

# One-sided limit
limit("1/x", var="x", at=0, direction="+", steps=True)

# Limit at infinity
import sympy as sp
limit("(3*x**2 + 1)/(x**2 - 2)", var="x", at=sp.oo, steps=True)

# With plot
limit("sin(x)/x", var="x", at=0, steps=True, plot=True, save_path="limit_plot.png")
```

---

### 3. Integration

Definite and indefinite integration with antiderivative steps and shaded area plots.

```python
from calculearn import integrate

# Indefinite integral
integrate("x**2 + 1", var="x", steps=True)

# Definite integral with shaded area plot
integrate("x**2 + 1", var="x", lower=0, upper=3, steps=True, plot=True)

# Trigonometric
integrate("sin(x)", var="x", lower=0, upper=3.14159, steps=True)

# Save plot
integrate("exp(-x)", var="x", lower=0, upper=2, plot=True, save_path="integral_plot.png")
```

**Output (excerpt):**
```
════════════════════════════════════════════════════════════
  DEFINITE INTEGRAL  —  ∫[0 to 3] (x**2 + 1) dx
════════════════════════════════════════════════════════════

Step 2: Apply the Fundamental Theorem of Calculus
        F(x) = x**3/3 + x

Step 3: Evaluate at the bounds
        F(3) = 10
        F(0) = 0

Step 4: Subtract  F(3) − F(0) = 10
```

---

### 4. Taylor Series

Expand functions as Taylor/Maclaurin series, see each term being added,
and optionally animate how the polynomial converges.

```python
from calculearn import taylor

# Maclaurin series for cos(x), 6 terms
taylor("cos(x)", var="x", around=0, terms=6, steps=True, plot=True)

# Taylor series for exp(x) around x=1
taylor("exp(x)", var="x", around=1, terms=5, steps=True)

# Animated GIF showing convergence
taylor("sin(x)", var="x", around=0, terms=8, animate=True, anim_path="taylor.gif")

# Save static plot
taylor("cos(x)", var="x", around=0, terms=6, save_path="taylor_plot.png")
```

---

### 5. Critical Points

Find and classify local minima, maxima, and saddle points using the second
derivative test, with annotated plots.

```python
from calculearn import critical_points

# Cubic with one min and one max
cps = critical_points("x**3 - 3*x", var="x", steps=True, plot=True)

# Quartic
cps = critical_points("x**4 - 4*x**2", var="x", steps=True, plot=True)

# Access results programmatically
for cp in cps:
    print(f"x = {cp.x_val}, type = {cp.classification}")

# Save plot
critical_points("x**3 - 3*x", var="x", plot=True, save_path="crit_plot.png")
```

**Output (excerpt):**
```
Step 4: Evaluate f''(x) at each critical point

  Critical Point 1:  x = -1
    f(-1)  = 2
    f''(-1) = -6
    f'' < 0  →  concave down  →  LOCAL MAXIMUM at (-1, 2)

  Critical Point 2:  x = 1
    f(1)  = -2
    f''(1) = 6
    f'' > 0  →  concave up  →  LOCAL MINIMUM at (1, -2)
```

---

## Full API Reference

| Function | Key Parameters |
|---|---|
| `derivative(expr, var, steps, plot, x_range, save_path)` | `steps=True`, `plot=False` |
| `limit(expr, var, at, direction, steps, plot, save_path)` | `direction="±"`, `"+"`, `"-"` |
| `integrate(expr, var, lower, upper, steps, plot, save_path)` | omit `lower/upper` for indefinite |
| `taylor(expr, var, around, terms, steps, plot, animate, anim_path)` | `animate=False` by default |
| `critical_points(expr, var, steps, plot, x_range, save_path)` | returns list of `CriticalPoint` |

---

## Expression Syntax

All functions accept plain Python math strings:

| You write | Meaning |
|---|---|
| `x**3` | x³ |
| `x**2 - 4*x` | x² − 4x |
| `sin(x)`, `cos(x)`, `tan(x)` | trigonometric |
| `exp(x)`, `log(x)` | exponential / natural log |
| `sqrt(x)` | √x |
| `pi`, `E` | π, e |
| `oo` | ∞ (use with `limit`) |

---

## Running the Tests

```bash
pip install pytest
pytest tests/ -v
```

---

## License

MIT
