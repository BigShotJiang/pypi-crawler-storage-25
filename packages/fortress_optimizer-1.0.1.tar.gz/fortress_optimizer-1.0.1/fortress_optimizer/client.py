"""
Fortress Token Optimizer — Python Client

Safe HTTP wrapper around the Fortress API.
The optimization algorithm runs server-side only.
"""

import time
import requests
from typing import Optional, Dict, Any, List


class FortressClient:
    """Client for the Fortress Token Optimization API."""

    def __init__(
        self,
        api_key: str,
        base_url: str = "https://api.fortress-optimizer.com",
        timeout: int = 10,
        max_retries: int = 3,
    ):
        if not api_key:
            raise ValueError("API key is required")
        if not base_url.startswith("https://") and "localhost" not in base_url:
            raise ValueError("Fortress API requires HTTPS")

        self.base_url = base_url.rstrip("/")
        self.timeout = timeout
        self.max_retries = min(max_retries, 10)
        self.session = requests.Session()
        self.session.headers.update({
            "Authorization": f"Bearer {api_key}",
            "X-API-Key": api_key,
            "X-Client-Version": "1.0.0",
            "Content-Type": "application/json",
        })

    def optimize(
        self,
        prompt: str,
        level: str = "balanced",
        provider: str = "openai",
    ) -> Dict[str, Any]:
        """
        Optimize a prompt for token efficiency.

        Args:
            prompt: The prompt to optimize
            level: 'conservative', 'balanced', or 'aggressive'
            provider: LLM provider ('openai', 'anthropic', etc.)

        Returns:
            Dict with keys: request_id, status, optimization, tokens, timestamp
        """
        return self._request("POST", "/api/optimize", json={
            "prompt": prompt,
            "level": level,
            "provider": provider,
        })

    def get_usage(self) -> Dict[str, Any]:
        """Get token usage statistics for your API key."""
        return self._request("GET", "/api/usage")

    def get_providers(self) -> List[str]:
        """Get list of supported LLM providers."""
        data = self._request("GET", "/api/providers")
        return data.get("providers", [])

    def health_check(self) -> bool:
        """Check if the API is healthy."""
        try:
            data = self._request("GET", "/health")
            return data.get("status") == "healthy"
        except Exception:
            return False

    def _request(self, method: str, path: str, **kwargs) -> Dict[str, Any]:
        """Make an HTTP request with retry logic."""
        url = f"{self.base_url}{path}"
        last_error = None

        for attempt in range(self.max_retries + 1):
            try:
                resp = self.session.request(
                    method, url, timeout=self.timeout, **kwargs
                )

                if resp.status_code == 401:
                    raise ValueError("Invalid API key")
                if resp.status_code == 400:
                    raise ValueError(f"Invalid request: {resp.text}")

                resp.raise_for_status()
                return resp.json()

            except (requests.exceptions.Timeout, requests.exceptions.ConnectionError) as e:
                last_error = e
            except requests.exceptions.HTTPError as e:
                if resp.status_code == 429 or resp.status_code >= 500:
                    last_error = e
                else:
                    raise
            except ValueError:
                raise

            if attempt < self.max_retries:
                delay = min(2 ** attempt, 10)
                time.sleep(delay)

        raise last_error or Exception("Request failed after retries")
