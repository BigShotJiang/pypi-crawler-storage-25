"""
Fortress Token Optimizer — Python SDK

Reduce LLM API costs by 10-20% with real-time prompt optimization.

Usage:
    from fortress_optimizer import FortressClient

    client = FortressClient(api_key="fk_your_key_here")
    result = client.optimize("Your prompt here")
    print(result["optimization"]["optimized_prompt"])
    print(f"Saved {result['tokens']['savings_percentage']}% tokens")
"""

from .client import FortressClient

__version__ = "1.0.0"
__all__ = ["FortressClient"]
