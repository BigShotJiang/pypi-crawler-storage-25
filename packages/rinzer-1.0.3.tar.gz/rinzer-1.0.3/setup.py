from setuptools import setup, find_packages

with open("README.md", "r", encoding="utf-8") as f:
    long_description = f.read()

setup(
    name="rinzer",
    version="1.0.3",
    description="几何公理体系的连通性分析器 + 多路径证明发现器 + 形式化验证前端",
    long_description=long_description,
    long_description_content_type="text/markdown",
    packages=find_packages(),
    install_requires=["z3-solver"],
    python_requires=">=3.8",
)