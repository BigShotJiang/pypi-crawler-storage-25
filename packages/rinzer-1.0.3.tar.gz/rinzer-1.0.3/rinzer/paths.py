"""不变量依赖图上的路径搜索。"""

def find_all_paths(graph, start_type, end_type, max_depth=10):
    """找出所有从不变量类型 A 到 B 的路径。"""
    return []


def find_shortest_path(graph, start_type, end_type):
    """找出最短路径。"""
    return []