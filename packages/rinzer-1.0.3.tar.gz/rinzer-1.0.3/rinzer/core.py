"""
不变量依赖图与闭包计算核心。
14 个节点，63 条边，92.9% 连通度。
"""

from enum import Enum
from collections import deque
from typing import Dict, List, Tuple, Set


class InvariantType(Enum):
    MIDPOINT = "中点重合"
    PARALLEL = "平行关系"
    PERPENDICULAR = "垂直关系"
    EQUAL_LENGTH = "长度相等"
    VECTOR_EQUALITY = "向量相等"
    OPPOSITE_SIDES_PARALLEL = "对边平行"
    ANGLE_EQUALITY = "角度相等"
    COLLINEAR = "三点共线"
    CONCURRENT = "三线共点"
    RATIO_EQUALITY = "比例相等"
    TRIANGLE_CONGRUENT = "三角形全等"
    TRIANGLE_SIMILAR = "三角形相似"
    CYCLIC_QUADRILATERAL = "四点共圆"
    ISOSCELES = "等腰三角形"


class InvariantDependencyGraph:
    """不变量依赖图。63条边，14个节点。"""
    
    def __init__(self):
        self.nodes: Dict[str, InvariantType] = {}
        self.edges: Dict[str, List[Tuple[str, str, str]]] = {}
        self._build_full_graph()
    
    def add_edge(self, from_type: str, to_type: str, algebraic: str, geometric: str):
        if from_type not in self.edges:
            self.edges[from_type] = []
        self.edges[from_type].append((to_type, algebraic, geometric))
        for t in [from_type, to_type]:
            if t in InvariantType.__members__:
                self.nodes[t] = InvariantType[t]
    
    def _build_full_graph(self):
        # 中点相关
        self.add_edge("MIDPOINT", "VECTOR_EQUALITY", "中点公式", "中点→向量关系")
        self.add_edge("MIDPOINT", "EQUAL_LENGTH", "中点+直角→斜边中线", "斜边中线定理")
        self.add_edge("MIDPOINT", "PARALLEL", "中位线定理", "两边中点连线∥第三边")
        self.add_edge("MIDPOINT", "CYCLIC_QUADRILATERAL", "九点圆", "中点构造九点圆")
        self.add_edge("MIDPOINT", "CONCURRENT", "重心", "三中线交于重心")
        
        # 向量相等
        self.add_edge("VECTOR_EQUALITY", "PARALLEL", "等向量→平行", "向量相等蕴含平行")
        self.add_edge("VECTOR_EQUALITY", "EQUAL_LENGTH", "等向量→等长", "向量相等蕴含等长")
        self.add_edge("VECTOR_EQUALITY", "OPPOSITE_SIDES_PARALLEL", "对边向量等→平行四边形", "平行四边形向量特征")
        
        # 平行
        self.add_edge("PARALLEL", "OPPOSITE_SIDES_PARALLEL", "一组对边平行→另一组", "平行传递")
        self.add_edge("PARALLEL", "ANGLE_EQUALITY", "平行→同位角相等", "平行线的角性质")
        self.add_edge("PARALLEL", "RATIO_EQUALITY", "平行→截线成比例", "平行线分线段成比例")
        self.add_edge("PARALLEL", "TRIANGLE_SIMILAR", "平行截出相似三角形", "平行构造相似")
        
        # 对边平行
        self.add_edge("OPPOSITE_SIDES_PARALLEL", "PARALLEL", "平行四边形定义", "两组对边平行")
        self.add_edge("OPPOSITE_SIDES_PARALLEL", "VECTOR_EQUALITY", "平行四边形→对边向量等", "平行四边形向量性质")
        self.add_edge("OPPOSITE_SIDES_PARALLEL", "EQUAL_LENGTH", "平行四边形→对边等长", "平行四边形边长性质")
        self.add_edge("OPPOSITE_SIDES_PARALLEL", "ANGLE_EQUALITY", "平行四边形→对角相等", "平行四边形角性质")
        
        # 垂直
        self.add_edge("PERPENDICULAR", "EQUAL_LENGTH", "直角+中点→斜边定理", "斜边中线定理")
        self.add_edge("PERPENDICULAR", "ANGLE_EQUALITY", "垂直→余角相等", "垂直构造等角")
        self.add_edge("PERPENDICULAR", "RATIO_EQUALITY", "射影定理", "直角带来比例")
        self.add_edge("PERPENDICULAR", "TRIANGLE_SIMILAR", "高构造三个相似三角形", "射影定理相似")
        self.add_edge("PERPENDICULAR", "CYCLIC_QUADRILATERAL", "对角互补→四点共圆", "对角互补的四边形共圆")
        self.add_edge("PERPENDICULAR", "COLLINEAR", "欧拉线", "垂心/外心/重心共线")
        self.add_edge("PERPENDICULAR", "CONCURRENT", "垂心", "三高交于垂心")
        
        # 等长
        self.add_edge("EQUAL_LENGTH", "ISOSCELES", "两边等→等腰", "等腰定义")
        self.add_edge("EQUAL_LENGTH", "ANGLE_EQUALITY", "等边对等角", "等腰性质")
        self.add_edge("EQUAL_LENGTH", "TRIANGLE_CONGRUENT", "SSS全等", "三边等→全等")
        self.add_edge("EQUAL_LENGTH", "CYCLIC_QUADRILATERAL", "到定点等距→共圆", "圆的定义")
        
        # 等腰
        self.add_edge("ISOSCELES", "ANGLE_EQUALITY", "等边对等角", "等腰性质")
        self.add_edge("ISOSCELES", "PERPENDICULAR", "三线合一", "顶角平分线⊥底边")
        self.add_edge("ISOSCELES", "EQUAL_LENGTH", "等角对等边", "等腰判定")
        self.add_edge("ISOSCELES", "COLLINEAR", "三线合一", "顶角平分线/中线/高重合")
        
        # 角度相等
        self.add_edge("ANGLE_EQUALITY", "TRIANGLE_SIMILAR", "AA相似", "两角等→相似")
        self.add_edge("ANGLE_EQUALITY", "CYCLIC_QUADRILATERAL", "同弧圆周角等→共圆", "圆周角定理逆")
        self.add_edge("ANGLE_EQUALITY", "RATIO_EQUALITY", "角平分→对边成比例", "角平分线定理")
        self.add_edge("ANGLE_EQUALITY", "ISOSCELES", "等角对等边", "等腰判定")
        self.add_edge("ANGLE_EQUALITY", "PARALLEL", "同位角等→平行", "平行判定")
        self.add_edge("ANGLE_EQUALITY", "PERPENDICULAR", "邻补角等→直角", "平分平角")
        self.add_edge("ANGLE_EQUALITY", "CONCURRENT", "内心", "角平分线共点")
        
        # 共线
        self.add_edge("COLLINEAR", "PERPENDICULAR", "直径所对圆周角=90°", "直径→直角")
        self.add_edge("COLLINEAR", "RATIO_EQUALITY", "定比分点", "共线点分线段成比例")
        self.add_edge("COLLINEAR", "CONCURRENT", "梅涅劳斯定理", "共线→三边交点满足乘积=1")
        self.add_edge("COLLINEAR", "CYCLIC_QUADRILATERAL", "西姆松线", "垂足共线")
        
        # 共点
        self.add_edge("CONCURRENT", "RATIO_EQUALITY", "塞瓦定理", "共点→乘积=1")
        self.add_edge("CONCURRENT", "COLLINEAR", "梅涅劳斯-塞瓦对偶", "射影几何对偶")
        self.add_edge("CONCURRENT", "CYCLIC_QUADRILATERAL", "根心定理", "三圆根轴共点")
        self.add_edge("CONCURRENT", "EQUAL_LENGTH", "外心到三顶点等距", "垂直平分线共点→等距")
        
        # 全等
        self.add_edge("TRIANGLE_CONGRUENT", "EQUAL_LENGTH", "全等→对应边等", "全等性质")
        self.add_edge("TRIANGLE_CONGRUENT", "ANGLE_EQUALITY", "全等→对应角等", "全等性质")
        self.add_edge("TRIANGLE_CONGRUENT", "TRIANGLE_SIMILAR", "全等是相似比=1", "全等必相似")
        
        # 相似
        self.add_edge("TRIANGLE_SIMILAR", "RATIO_EQUALITY", "相似→对应边成比例", "相似性质")
        self.add_edge("TRIANGLE_SIMILAR", "ANGLE_EQUALITY", "相似→对应角等", "相似性质")
        self.add_edge("TRIANGLE_SIMILAR", "EQUAL_LENGTH", "相似比=1→全等", "相似的特殊情况")
        self.add_edge("TRIANGLE_SIMILAR", "COLLINEAR", "位似中心", "相似三角形对应点连线共点")
        
        # 共圆
        self.add_edge("CYCLIC_QUADRILATERAL", "ANGLE_EQUALITY", "圆周角定理", "同弧圆周角相等")
        self.add_edge("CYCLIC_QUADRILATERAL", "PERPENDICULAR", "直径所对圆周角=90°", "圆与直角")
        self.add_edge("CYCLIC_QUADRILATERAL", "EQUAL_LENGTH", "同圆半径相等", "圆定义")
        self.add_edge("CYCLIC_QUADRILATERAL", "CONCURRENT", "根心定理", "三圆根轴共点")
        
        # 比例
        self.add_edge("RATIO_EQUALITY", "TRIANGLE_SIMILAR", "SAS相似", "两边成比例→相似")
        self.add_edge("RATIO_EQUALITY", "PARALLEL", "线段成比例→平行", "平行线判定")
        self.add_edge("RATIO_EQUALITY", "ANGLE_EQUALITY", "角平分线逆定理", "比例→等角")
        self.add_edge("RATIO_EQUALITY", "COLLINEAR", "调和点列", "调和分割构造共线点")
        self.add_edge("RATIO_EQUALITY", "CONCURRENT", "塞瓦定理", "比例→三线共点")
    
    def compute_closure(self, start_types: List[str], max_depth: int = 10) -> Set[str]:
        """从给定起点出发，计算所有可到达的不变量类型。"""
        reachable = set(start_types)
        queue = deque(start_types)
        depth = {t: 0 for t in start_types}
        
        while queue:
            current = queue.popleft()
            if depth[current] >= max_depth:
                continue
            for neighbor, _, _ in self.edges.get(current, []):
                if neighbor not in reachable:
                    reachable.add(neighbor)
                    depth[neighbor] = depth[current] + 1
                    queue.append(neighbor)
        
        return reachable
    
    def find_all_paths(self, start_type: str, end_type: str, max_depth: int = 10) -> List[List[str]]:
        """找出所有从不变量类型 A 到 B 的路径。"""
        all_paths = []
        
        def dfs(current, path, visited_set):
            if len(path) > max_depth:
                return
            if current == end_type:
                all_paths.append(path[:])
                return
            for neighbor, _, _ in self.edges.get(current, []):
                if neighbor not in visited_set:
                    visited_set.add(neighbor)
                    dfs(neighbor, path + [neighbor], visited_set)
                    visited_set.remove(neighbor)
        
        dfs(start_type, [start_type], {start_type})
        return all_paths


def analyze_closure(axioms=None):
    """分析不变量依赖图的连通性。"""
    if axioms is None:
        axioms = ["MIDPOINT", "PARALLEL", "PERPENDICULAR", "EQUAL_LENGTH", 
                  "COLLINEAR", "CYCLIC_QUADRILATERAL"]
    
    graph = InvariantDependencyGraph()
    all_nodes = set(graph.nodes.keys())
    closure = graph.compute_closure(axioms)
    outside = all_nodes - closure
    
    return {
        "total_nodes": len(all_nodes),
        "total_edges": sum(len(v) for v in graph.edges.values()),
        "axiom_closure_coverage": f"{len(closure)}/{len(all_nodes)}",
        "outside_closure": list(outside),
        "is_complete": len(outside) == 0
    }