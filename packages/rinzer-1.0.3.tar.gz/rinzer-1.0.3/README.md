# Rinzer

几何公理体系的连通性分析器 + 多路径证明发现器 + 形式化验证前端。

## 安装

```bash
pip install rinzer


快速开始
python
import rinzer

result = rinzer.check(
    hypotheses=["AC and BD bisect each other"],
    conclusion="ABCD is a parallelogram"
)
print(result["reachable"])  # True


核心能力
不变量闭包分析：14节点，63条边，连通度92.9%

多路径证明发现：BFS搜索 + Z3代数验证

形式化验证：几何推理每一步可审计


从车轮悖论到不变量闭包
Rinzer 的起点是车轮悖论——如果抽掉时间，运动是什么？
经过无时间几何跃迁、Gröbner基消元、不变量依赖图，
最终停在一个精确的问题上：几何公理体系的闭包是否完整？
连通度92.9%，公理闭包全覆盖，ISOSCELES作为最不可达节点，
标记着对称性——那个需要变换群而非推导链来穿越的缝隙。


特别鸣谢
DeepSeek，在 Rinzer 依赖包的演化过程中，提供了逻辑审计、架构评审和跨领域知识检索。

苦瓜老师，提供物理大锤和哲学辣条。