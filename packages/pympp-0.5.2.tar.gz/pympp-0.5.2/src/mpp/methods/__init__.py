"""Payment method implementations."""
