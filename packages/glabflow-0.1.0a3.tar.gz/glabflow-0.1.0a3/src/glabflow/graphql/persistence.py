"""
GraphQL Query Persistence

Persist frequently-used queries for reuse and versioning.
"""

from __future__ import annotations

import hashlib
import json
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any


@dataclass
class PersistedQuery:
    """Persisted query definition."""

    name: str
    query: str
    variables: dict[str, Any] = field(default_factory=dict)
    description: str = ""
    tags: list[str] = field(default_factory=list)
    version: str = "1.0"
    created_at: float = field(default_factory=lambda: 0.0)
    updated_at: float = field(default_factory=lambda: 0.0)
    usage_count: int = 0
    last_used: float = field(default_factory=lambda: 0.0)

    @property
    def hash(self) -> str:
        """Calculate query hash for automatic persistence."""
        return hashlib.blake2b(self.query.encode(), digest_size=16).hexdigest()

    def to_dict(self) -> dict[str, Any]:
        """Convert to dictionary."""
        return {
            "name": self.name,
            "query": self.query,
            "variables": self.variables,
            "description": self.description,
            "tags": self.tags,
            "version": self.version,
            "created_at": self.created_at,
            "updated_at": self.updated_at,
            "usage_count": self.usage_count,
            "last_used": self.last_used,
        }

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> PersistedQuery:
        """Create from dictionary."""
        return cls(**data)


class QueryPersistence:
    """
    Persist and manage frequently-used GraphQL queries.

    Features:
    - Save queries to file system
    - Load queries by name or hash
    - Track usage statistics
    - Version management
    - Query organization with tags

    Example:
        persistence = QueryPersistence("queries.json")

        # Save query
        persistence.save(PersistedQuery(
            name="get_project",
            query="query($path: ID!) { project(fullPath: $path) { id name } }",
            description="Get project by path",
            tags=["project", "common"],
        ))

        # Load query
        pq = persistence.get_by_name("get_project")
        result = await client.execute(pq.query, pq.variables)
    """

    def __init__(self, storage_path: str | Path | None = None) -> None:
        """
        Initialize query persistence.

        Args:
            storage_path: Path to storage file (default: memory only)
        """
        self._queries: dict[str, PersistedQuery] = {}
        self._storage_path = Path(storage_path) if storage_path else None

        # Load from storage if exists
        if self._storage_path and self._storage_path.exists():
            self._load_from_file()

    def save(self, query: PersistedQuery) -> None:
        """
        Save a persisted query.

        Args:
            query: Query to save
        """
        import time

        if query.created_at == 0.0:
            query.created_at = time.time()
        query.updated_at = time.time()

        # Save by name
        self._queries[query.name] = query

        # Save by hash
        self._queries[f"hash:{query.hash}"] = query

        # Persist to file if configured
        if self._storage_path:
            self._save_to_file()

    def get_by_name(self, name: str) -> PersistedQuery | None:
        """
        Get query by name.

        Args:
            name: Query name

        Returns:
            PersistedQuery or None
        """
        query = self._queries.get(name)
        if query:
            self._record_usage(query)
        return query

    def get_by_hash(self, query_hash: str) -> PersistedQuery | None:
        """
        Get query by hash.

        Args:
            query_hash: Query hash

        Returns:
            PersistedQuery or None
        """
        return self._queries.get(f"hash:{query_hash}")

    def get_by_tag(self, tag: str) -> list[PersistedQuery]:
        """
        Get queries by tag.

        Args:
            tag: Tag to filter by

        Returns:
            List of matching queries
        """
        return [
            q
            for q in self._queries.values()
            if tag in q.tags and not q.name.startswith("hash:")
        ]

    def list_all(self) -> list[PersistedQuery]:
        """
        List all persisted queries.

        Returns:
            List of all queries
        """
        return [q for q in self._queries.values() if not q.name.startswith("hash:")]

    def delete(self, name: str) -> bool:
        """
        Delete a persisted query.

        Args:
            name: Query name

        Returns:
            True if deleted, False if not found
        """
        query = self._queries.get(name)
        if not query:
            return False

        # Remove by name
        del self._queries[name]

        # Remove by hash
        hash_key = f"hash:{query.hash}"
        if hash_key in self._queries:
            del self._queries[hash_key]

        # Persist to file if configured
        if self._storage_path:
            self._save_to_file()

        return True

    def exists(self, name: str) -> bool:
        """Check if query exists."""
        return name in self._queries

    def _record_usage(self, query: PersistedQuery) -> None:
        """Record query usage."""
        import time

        query.usage_count += 1
        query.last_used = time.time()

    def _save_to_file(self) -> None:
        """Save queries to file."""
        if not self._storage_path:
            return

        data = {
            name: query.to_dict()
            for name, query in self._queries.items()
            if not name.startswith("hash:")
        }

        self._storage_path.parent.mkdir(parents=True, exist_ok=True)
        with open(self._storage_path, "w") as f:
            json.dump(data, f, indent=2)

    def _load_from_file(self) -> None:
        """Load queries from file."""
        if not self._storage_path or not self._storage_path.exists():
            return

        with open(self._storage_path) as f:
            data = json.load(f)

        for name, query_data in data.items():
            query = PersistedQuery.from_dict(query_data)
            self._queries[name] = query
            self._queries[f"hash:{query.hash}"] = query

    def get_stats(self) -> dict[str, Any]:
        """Get persistence statistics."""
        queries = self.list_all()
        return {
            "total_queries": len(queries),
            "total_usage": sum(q.usage_count for q in queries),
            "storage_path": str(self._storage_path) if self._storage_path else "memory",
            "most_used": max(queries, key=lambda q: q.usage_count).name
            if queries
            else None,
        }


class QueryLibrary:
    """
    Pre-built query library with common patterns.

    Provides a collection of commonly-used queries that can be
    persisted and reused.
    """

    @staticmethod
    def get_common_queries() -> list[PersistedQuery]:
        """Get common query templates."""
        import time

        now = time.time()

        return [
            PersistedQuery(
                name="get_project_basic",
                query="""
                    query GetProject($fullPath: ID!) {
                        project(fullPath: $fullPath) {
                            id
                            name
                            fullPath
                            description
                            webUrl
                        }
                    }
                """,
                description="Get basic project information",
                tags=["project", "basic"],
                created_at=now,
            ),
            PersistedQuery(
                name="get_project_with_stats",
                query="""
                    query GetProjectWithStats($fullPath: ID!) {
                        project(fullPath: $fullPath) {
                            id
                            name
                            openIssuesCount
                            openMergeRequestsCount
                            packagesCount
                        }
                    }
                """,
                description="Get project with statistics",
                tags=["project", "statistics"],
                created_at=now,
            ),
            PersistedQuery(
                name="get_merge_requests",
                query="""
                    query GetMRs($fullPath: ID!, $after: String, $first: Int, $state: MergeRequestState) {
                        project(fullPath: $fullPath) {
                            mergeRequests(after: $after, first: $first, state: $state) {
                                pageInfo { hasNextPage endCursor }
                                nodes { iid title state webUrl }
                            }
                        }
                    }
                """,
                description="Stream merge requests with pagination",
                tags=["merge-requests", "pagination"],
                created_at=now,
            ),
            PersistedQuery(
                name="get_user_details",
                query="""
                    query GetUser($username: String!) {
                        user(username: $username) {
                            id
                            username
                            name
                            avatarUrl
                            bio
                            location
                        }
                    }
                """,
                description="Get detailed user information",
                tags=["user", "details"],
                created_at=now,
            ),
            PersistedQuery(
                name="get_group_hierarchy",
                query="""
                    query GetGroupHierarchy($fullPath: ID!) {
                        group(fullPath: $fullPath) {
                            id
                            name
                            fullPath
                            parent {
                                id
                                name
                                fullPath
                            }
                        }
                    }
                """,
                description="Get group with parent hierarchy",
                tags=["group", "hierarchy"],
                created_at=now,
            ),
        ]


# Convenience functions


def create_persistence(storage_path: str | Path | None = None) -> QueryPersistence:
    """Create query persistence instance."""
    return QueryPersistence(storage_path)


def load_common_queries(persistence: QueryPersistence) -> int:
    """Load common queries into persistence."""
    queries = QueryLibrary.get_common_queries()
    for query in queries:
        persistence.save(query)
    return len(queries)
