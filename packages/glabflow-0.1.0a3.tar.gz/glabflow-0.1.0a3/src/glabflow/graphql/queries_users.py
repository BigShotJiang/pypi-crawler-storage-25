"""
Users, Members & Roles GraphQL Queries

Coverage: All 12 Users, Members & Roles QUERY.* endpoints
"""

from glabflow.graphql.builder import Field, Query, fragment, query

# ========== Fragments ==========

MEMBER_ROLE_FRAGMENT = (
    fragment("MemberRoleFields", "MemberRole")
    .field("id")
    .field("name")
    .field("description")
    .field("baseAccessLevel")
    .field("createdAt")
)

STANDARD_ROLE_FRAGMENT = (
    fragment("StandardRoleFields", "StandardRole")
    .field("id")
    .field("name")
    .field("description")
    .field("accessLevel")
)


# ========== User Queries ==========


def get_current_user() -> Field | Query:
    """
    Get current authenticated user.

    QUERY.CURRENTUSER

    Example:
        q = get_current_user()
        result = await gl.graphql.execute(str(q))
        print(f"Logged in as: {result['currentUser']['username']}")
    """
    return (
        query("GetCurrentUser")
        .field("currentUser")
        .field("id")
        .field("username")
        .field("name")
        .field("avatarUrl")
        .field("webUrl")
        .field("email")
        .field("bio")
        .field("location")
        .field("organization")
        .field("createdAt")
        .field("publicEmail")
        .field("publicPosition")
        .field("websiteUrl")
        .field("pronouns")
        .field("bot")
        .field("isAdmin")
        .end()
    )


def get_users(
    limit: int = 100,
    state: str = "active",
) -> Field | Query:
    """
    Get users list.

    QUERY.USERS

    Example:
        q = get_users(state="active")
        async for user in gl.graphql.stream(
            str(q),
            connection_path=["users"]
        ):
            print(user["username"], user["name"])
    """
    return (
        query("GetUsers")
        .arg("after", "$after", "String")
        .arg("first", "$first", "Int")
        .field(
            "users",
            args={
                "after": "$after",
                "first": "$first",
                "state": state,
            },
        )
        .field("pageInfo", fields=["hasNextPage", "endCursor"])
        .field(
            "nodes", fields=["id", "username", "name", "avatarUrl", "webUrl", "state"]
        )
        .end()
    )


def get_frequent_groups(limit: int = 20) -> Field | Query:
    """
    Get frequently accessed groups.

    QUERY.FRECENTGROUPS

    Example:
        q = get_frequent_groups()
        result = await gl.graphql.execute(str(q))
    """
    return (
        query("GetFrequentGroups")
        .field("frequentGroups", args={"first": "$first"})
        .field("nodes", fields=["id", "name", "fullPath", "webUrl"])
        .end()
    )


def get_frequent_projects(limit: int = 20) -> Field | Query:
    """
    Get frequently accessed projects.

    QUERY.FRECENTPROJECTS

    Example:
        q = get_frequent_projects()
        result = await gl.graphql.execute(str(q))
    """
    return (
        query("GetFrequentProjects")
        .field("frequentProjects", args={"first": "$first"})
        .field("nodes", fields=["id", "name", "fullPath", "webUrl"])
        .end()
    )


# ========== Member Role Queries ==========


def get_member_role() -> Field | Query:
    """
    Get member role details.

    QUERY.MEMBERROLE

    Example:
        q = get_member_role()
        result = await gl.graphql.execute(str(q), variables={
            "memberRoleId": "gid://gitlab/MemberRole/123"
        })
    """
    return (
        query("GetMemberRole")
        .arg("memberRoleId", "$memberRoleId", "ID!")
        .field("memberRole", args={"id": "$memberRoleId"})
        .field("id")
        .field("name")
        .field("description")
        .field("baseAccessLevel")
        .field("createdAt")
        .field("updatedAt")
        .field("sourceType")
        .end()
    )


def get_member_role_permissions() -> Field | Query:
    """
    Get member role permissions.

    QUERY.MEMBERROLEPERMISSIONS

    Example:
        q = get_member_role_permissions()
        result = await gl.graphql.execute(str(q), variables={
            "memberRoleId": "gid://gitlab/MemberRole/123"
        })
    """
    return (
        query("GetMemberRolePermissions")
        .arg("memberRoleId", "$memberRoleId", "ID!")
        .field("memberRole", args={"id": "$memberRoleId"})
        .field("permissions")
        .field("canCreateProject")
        .field("canCreateGroup")
        .field("canManageMembers")
        .field("canManageRunners")
        .field("canManageVariables")
        .end()
    )


def get_member_roles(limit: int = 100) -> Field | Query:
    """
    Get member roles list.

    QUERY.MEMBERROLES

    Example:
        q = get_member_roles()
        async for role in gl.graphql.stream(
            str(q),
            connection_path=["memberRoles"]
        ):
            print(role["name"], role["baseAccessLevel"])
    """
    return (
        query("GetMemberRoles")
        .arg("after", "$after", "String")
        .arg("first", "$first", "Int")
        .field("memberRoles", args={"after": "$after", "first": "$first"})
        .field("pageInfo", fields=["hasNextPage", "endCursor"])
        .field(
            "nodes",
            fields=["id", "name", "description", "baseAccessLevel", "createdAt"],
        )
        .end()
    )


# ========== Standard Role Queries ==========


def get_standard_role() -> Field | Query:
    """
    Get standard role details.

    QUERY.STANDARDROLE

    Example:
        q = get_standard_role()
        result = await gl.graphql.execute(str(q), variables={
            "roleId": "gid://gitlab/StandardRole/123"
        })
    """
    return (
        query("GetStandardRole")
        .arg("roleId", "$roleId", "ID!")
        .field("standardRole", args={"id": "$roleId"})
        .field("id")
        .field("name")
        .field("description")
        .field("accessLevel")
        .end()
    )


def get_standard_roles() -> Field | Query:
    """
    Get standard roles list.

    QUERY.STANDARDROLES

    Example:
        q = get_standard_roles()
        result = await gl.graphql.execute(str(q))
    """
    return (
        query("GetStandardRoles")
        .field("standardRoles")
        .field("nodes", fields=["id", "name", "description", "accessLevel"])
        .end()
    )


# ========== Self-Managed User Queries ==========


def get_self_managed_addon_eligible_users(limit: int = 100) -> Field | Query:
    """
    Get self-managed addon eligible users.

    QUERY.SELFMANAGEDADDONELIGIBLEUSERS

    Example:
        q = get_self_managed_addon_eligible_users()
        async for user in gl.graphql.stream(
            str(q),
            connection_path=["selfManagedAddonEligibleUsers"]
        ):
            print(user["username"])
    """
    return (
        query("GetSelfManagedAddonEligibleUsers")
        .arg("after", "$after", "String")
        .arg("first", "$first", "Int")
        .field(
            "selfManagedAddonEligibleUsers", args={"after": "$after", "first": "$first"}
        )
        .field("pageInfo", fields=["hasNextPage", "endCursor"])
        .field("nodes", fields=["id", "username", "name", "email"])
        .end()
    )


def get_self_managed_users_queued_for_role_promotion(limit: int = 100) -> Field | Query:
    """
    Get self-managed users queued for role promotion.

    QUERY.SELFMANAGEDUSERSQUEUEDFORROLEPROMOTION

    Example:
        q = get_self_managed_users_queued_for_role_promotion()
        async for user in gl.graphql.stream(
            str(q),
            connection_path=["selfManagedUsersQueuedForRolePromotion"]
        ):
            print(user["username"])
    """
    return (
        query("GetSelfManagedUsersQueuedForRolePromotion")
        .arg("after", "$after", "String")
        .arg("first", "$first", "Int")
        .field(
            "selfManagedUsersQueuedForRolePromotion",
            args={"after": "$after", "first": "$first"},
        )
        .field("pageInfo", fields=["hasNextPage", "endCursor"])
        .field("nodes", fields=["id", "username", "name", "queuedAt"])
        .end()
    )


# ========== Export Constants ==========

GET_CURRENT_USER = str(get_current_user())
GET_USERS = str(get_users())
GET_FREQUENT_GROUPS = str(get_frequent_groups())
GET_FREQUENT_PROJECTS = str(get_frequent_projects())
GET_MEMBER_ROLE = str(get_member_role())
GET_MEMBER_ROLE_PERMISSIONS = str(get_member_role_permissions())
GET_MEMBER_ROLES = str(get_member_roles())
GET_STANDARD_ROLE = str(get_standard_role())
GET_STANDARD_ROLES = str(get_standard_roles())
GET_SELF_MANAGED_ADDON_ELIGIBLE_USERS = str(get_self_managed_addon_eligible_users())
GET_SELF_MANAGED_USERS_QUEUED_FOR_ROLE_PROMOTION = str(
    get_self_managed_users_queued_for_role_promotion()
)
