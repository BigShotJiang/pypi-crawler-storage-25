"""
Security, Compliance & Vulnerabilities GraphQL Queries

Coverage: All 31 Security QUERY.* endpoints
"""

from glabflow.graphql.builder import Field, Query, fragment, query

# ========== Fragments ==========

VULNERABILITY_FRAGMENT = (
    fragment("VulnerabilityFields", "Vulnerability")
    .field("id")
    .field("severity")
    .field("state")
    .field("title")
    .field("description")
    .field("webUrl")
    .field("createdAt")
    .field("updatedAt")
    .field("resolvedAt")
    .field("resolvedBy", fields=["username", "name"])
)

COMPLIANCE_VIOLATION_FRAGMENT = (
    fragment("ComplianceViolationFields", "ComplianceViolation")
    .field("id")
    .field("violationType")
    .field("severity")
    .field("state")
    .field("description")
    .field("createdAt")
)

SECRET_FRAGMENT = (
    fragment("SecretFields", "Secret")
    .field("id")
    .field("name")
    .field("secretType")
    .field("createdAt")
    .field("lastRotatedAt")
    .field("expiresAt")
    .field("rotationStatus")
)


# ========== Vulnerability Queries ==========


def get_vulnerabilities(
    severity: str = "CRITICAL",
    state: str = "DETECTED",
    limit: int = 100,
) -> Field | Query:
    """
    Get vulnerabilities for a project.

    QUERY.VULNERABILITIES

    Example:
        q = get_vulnerabilities(severity="CRITICAL")
        async for vuln in gl.graphql.stream(
            str(q),
            connection_path=["project", "vulnerabilities"],
            variables={"fullPath": "group/project"}
        ):
            print(vuln["severity"], vuln["title"])
    """
    return (
        query("GetVulnerabilities")
        .arg("fullPath", "$fullPath", "ID!")
        .arg("after", "$after", "String")
        .arg("first", "$first", "Int")
        .field("project", args={"fullPath": "$fullPath"})
        .field(
            "vulnerabilities",
            args={
                "after": "$after",
                "first": "$first",
                "severity": severity,
                "state": state,
            },
        )
        .field("pageInfo", fields=["hasNextPage", "endCursor"])
        .field(
            "nodes",
            fields=[
                "id",
                "severity",
                "state",
                "title",
                "description",
                "webUrl",
                "createdAt",
                "reportType",
            ],
        )
        .end()
    )


def get_vulnerability() -> Field | Query:
    """
    Get specific vulnerability details.

    QUERY.VULNERABILITY

    Example:
        q = get_vulnerability()
        result = await gl.graphql.execute(str(q), variables={
            "vulnerabilityId": "gid://gitlab/Vulnerability/123"
        })
    """
    return (
        query("GetVulnerability")
        .arg("vulnerabilityId", "$vulnerabilityId", "ID!")
        .field("vulnerability", args={"id": "$vulnerabilityId"})
        .field("id")
        .field("severity")
        .field("state")
        .field("title")
        .field("description")
        .field("webUrl")
        .field("createdAt")
        .field("updatedAt")
        .field("resolvedAt")
        .field("resolvedBy", fields=["username", "name"])
        .field("author", fields=["username", "name"])
        .field("project", fields=["id", "name", "fullPath"])
        .field(
            "finding", fields=["id", "confidence", "scanner", "location", "identifiers"]
        )
        .end()
    )


def get_vulnerabilities_count_by_day() -> Field | Query:
    """
    Get vulnerabilities count by day.

    QUERY.VULNERABILITIESCOUNTBYDAY

    Example:
        q = get_vulnerabilities_count_by_day()
        result = await gl.graphql.execute(str(q), variables={
            "fullPath": "group/project"
        })
    """
    return (
        query("GetVulnerabilitiesCountByDay")
        .arg("fullPath", "$fullPath", "ID!")
        .field("project", args={"fullPath": "$fullPath"})
        .field("vulnerabilitiesCountByDay")
        .field("nodes", fields=["date", "count", "severity"])
        .end()
    )


# ========== Compliance Queries ==========


def get_project_compliance_violation() -> Field | Query:
    """
    Get project compliance violation.

    QUERY.PROJECTCOMPLIANCEVIOLATION

    Example:
        q = get_project_compliance_violation()
        result = await gl.graphql.execute(str(q), variables={
            "fullPath": "group/project",
            "violationId": "gid://gitlab/ComplianceViolation/123"
        })
    """
    return (
        query("GetProjectComplianceViolation")
        .arg("fullPath", "$fullPath", "ID!")
        .arg("violationId", "$violationId", "ID!")
        .field("project", args={"fullPath": "$fullPath"})
        .field("complianceViolation", args={"id": "$violationId"})
        .field("id")
        .field("violationType")
        .field("severity")
        .field("state")
        .field("description")
        .field("createdAt")
        .field("resolvedAt")
        .end()
    )


def get_compliance_requirement_controls() -> Field | Query:
    """
    Get compliance requirement controls.

    QUERY.COMPLIANCEREQUIREMENTCONTROLS

    Example:
        q = get_compliance_requirement_controls()
        result = await gl.graphql.execute(str(q), variables={
            "fullPath": "group/project"
        })
    """
    return (
        query("GetComplianceRequirementControls")
        .arg("fullPath", "$fullPath", "ID!")
        .field("project", args={"fullPath": "$fullPath"})
        .field("complianceRequirementControls")
        .field("nodes", fields=["id", "name", "description", "status", "controlType"])
        .end()
    )


def add_project_to_security_dashboard() -> Field | Query:
    """
    Add project to security dashboard.

    Note: This is actually a mutation but listed under QUERY in some docs.
    May need to be implemented as mutation.

    Example:
        q = add_project_to_security_dashboard()
        result = await gl.graphql.execute(str(q), variables={
            "fullPath": "group/project"
        })
    """
    return (
        query("AddProjectToSecurityDashboard")
        .arg("fullPath", "$fullPath", "ID!")
        .field("addProjectToSecurityDashboard", args={"fullPath": "$fullPath"})
        .field("success")
        .field("message")
        .end()
    )


# ========== Security Configuration Queries ==========


def get_security_configuration() -> Field | Query:
    """
    Get security configuration.

    QUERY.SECURITYCONFIGURATION

    Example:
        q = get_security_configuration()
        result = await gl.graphql.execute(str(q), variables={
            "fullPath": "group/project"
        })
    """
    return (
        query("GetSecurityConfiguration")
        .arg("fullPath", "$fullPath", "ID!")
        .field("project", args={"fullPath": "$fullPath"})
        .field("securityConfiguration")
        .field("vulnerabilityResolutionEnabled")
        .field("dependencyScanningEnabled")
        .field("containerScanningEnabled")
        .field("sastEnabled")
        .field("dastEnabled")
        .end()
    )


def get_security_policies_sync_status() -> Field | Query:
    """
    Get security policies sync status.

    QUERY.SECURITYPOLICIESSYNCSTATUS

    Example:
        q = get_security_policies_sync_status()
        result = await gl.graphql.execute(str(q), variables={
            "fullPath": "group/project"
        })
    """
    return (
        query("GetSecurityPoliciesSyncStatus")
        .arg("fullPath", "$fullPath", "ID!")
        .field("project", args={"fullPath": "$fullPath"})
        .field("securityPoliciesSyncStatus")
        .field("lastSyncedAt")
        .field("syncStatus")
        .field("errors")
        .end()
    )


def get_security_scan_profile() -> Field | Query:
    """
    Get security scan profile.

    QUERY.SECURITYSCANPROFILE

    Example:
        q = get_security_scan_profile()
        result = await gl.graphql.execute(str(q), variables={
            "fullPath": "group/project"
        })
    """
    return (
        query("GetSecurityScanProfile")
        .arg("fullPath", "$fullPath", "ID!")
        .field("project", args={"fullPath": "$fullPath"})
        .field("securityScanProfile")
        .field("id")
        .field("name")
        .field("scanTypes")
        .field("schedule")
        .end()
    )


def get_namespace_security_projects() -> Field | Query:
    """
    Get namespace security projects.

    QUERY.NAMESPACESECURITYPROJECTS

    Example:
        q = get_namespace_security_projects()
        result = await gl.graphql.execute(str(q), variables={
            "namespaceId": "gid://gitlab/Namespace/123"
        })
    """
    return (
        query("GetNamespaceSecurityProjects")
        .arg("namespaceId", "$namespaceId", "ID!")
        .field("namespace", args={"id": "$namespaceId"})
        .field("securityProjects")
        .field("nodes", fields=["id", "name", "fullPath", "securityEnabled"])
        .end()
    )


def get_instance_security_dashboard() -> Field | Query:
    """
    Get instance security dashboard.

    QUERY.INSTANCESECURITYDASHBOARD

    Example:
        q = get_instance_security_dashboard()
        result = await gl.graphql.execute(str(q))
    """
    return (
        query("GetInstanceSecurityDashboard")
        .field("instanceSecurityDashboard")
        .field("totalVulnerabilities")
        .field("criticalVulnerabilities")
        .field("highVulnerabilities")
        .field("projectsAtRisk")
        .field("complianceRate")
        .end()
    )


# ========== Secret Management Queries ==========


def get_project_secrets() -> Field | Query:
    """
    Get project secrets.

    QUERY.PROJECTSECRETS

    Example:
        q = get_project_secrets()
        result = await gl.graphql.execute(str(q), variables={
            "fullPath": "group/project"
        })
    """
    return (
        query("GetProjectSecrets")
        .arg("fullPath", "$fullPath", "ID!")
        .field("project", args={"fullPath": "$fullPath"})
        .field("secrets")
        .field(
            "nodes",
            fields=[
                "id",
                "name",
                "secretType",
                "createdAt",
                "lastRotatedAt",
                "expiresAt",
                "rotationStatus",
            ],
        )
        .end()
    )


def get_project_secret() -> Field | Query:
    """
    Get specific project secret.

    QUERY.PROJECTSECRET

    Example:
        q = get_project_secret()
        result = await gl.graphql.execute(str(q), variables={
            "fullPath": "group/project",
            "secretId": "gid://gitlab/Secret/123"  # pragma: allowlist secret
        })
    """
    return (
        query("GetProjectSecret")
        .arg("fullPath", "$fullPath", "ID!")
        .arg("secretId", "$secretId", "ID!")
        .field("project", args={"fullPath": "$fullPath"})
        .field("secret", args={"id": "$secretId"})
        .field("id")
        .field("name")
        .field("secretType")
        .field("createdAt")
        .field("lastRotatedAt")
        .field("expiresAt")
        .field("rotationStatus")
        .end()
    )


def get_project_secrets_manager() -> Field | Query:
    """
    Get project secrets manager.

    QUERY.PROJECTSECRETSMANAGER

    Example:
        q = get_project_secrets_manager()
        result = await gl.graphql.execute(str(q), variables={
            "fullPath": "group/project"
        })
    """
    return (
        query("GetProjectSecretsManager")
        .arg("fullPath", "$fullPath", "ID!")
        .field("project", args={"fullPath": "$fullPath"})
        .field("secretsManager")
        .field("provider")
        .field("configured")
        .field("lastSyncedAt")
        .end()
    )


def get_project_secrets_needing_rotation() -> Field | Query:
    """
    Get project secrets needing rotation.

    QUERY.PROJECTSECRETSNEEDINGROTATION

    Example:
        q = get_project_secrets_needing_rotation()
        result = await gl.graphql.execute(str(q), variables={
            "fullPath": "group/project"
        })
    """
    return (
        query("GetProjectSecretsNeedingRotation")
        .arg("fullPath", "$fullPath", "ID!")
        .field("project", args={"fullPath": "$fullPath"})
        .field("secretsNeedingRotation")
        .field(
            "nodes", fields=["id", "name", "secretType", "expiresAt", "rotationStatus"]
        )
        .end()
    )


def get_project_secrets_permissions() -> Field | Query:
    """
    Get project secrets permissions.

    QUERY.PROJECTSECRETSPERMISSIONS

    Example:
        q = get_project_secrets_permissions()
        result = await gl.graphql.execute(str(q), variables={
            "fullPath": "group/project"
        })
    """
    return (
        query("GetProjectSecretsPermissions")
        .arg("fullPath", "$fullPath", "ID!")
        .field("project", args={"fullPath": "$fullPath"})
        .field("secretsPermissions")
        .field("canRead")
        .field("canWrite")
        .field("canRotate")
        .field("canDelete")
        .end()
    )


def get_group_secrets() -> Field | Query:
    """
    Get group secrets.

    QUERY.GROUPSECRETS

    Example:
        q = get_group_secrets()
        result = await gl.graphql.execute(str(q), variables={
            "fullPath": "group"
        })
    """
    return (
        query("GetGroupSecrets")
        .arg("fullPath", "$fullPath", "ID!")
        .field("group", args={"fullPath": "$fullPath"})
        .field("secrets")
        .field(
            "nodes",
            fields=[
                "id",
                "name",
                "secretType",
                "createdAt",
                "lastRotatedAt",
                "expiresAt",
                "rotationStatus",
            ],
        )
        .end()
    )


def get_group_secret() -> Field | Query:
    """
    Get specific group secret.

    QUERY.GROUPSECRET

    Example:
        q = get_group_secret()
        result = await gl.graphql.execute(str(q), variables={
            "fullPath": "group",
            "secretId": "gid://gitlab/Secret/123"  # pragma: allowlist secret
        })
    """
    return (
        query("GetGroupSecret")
        .arg("fullPath", "$fullPath", "ID!")
        .arg("secretId", "$secretId", "ID!")
        .field("group", args={"fullPath": "$fullPath"})
        .field("secret", args={"id": "$secretId"})
        .field("id")
        .field("name")
        .field("secretType")
        .field("createdAt")
        .field("lastRotatedAt")
        .field("expiresAt")
        .field("rotationStatus")
        .end()
    )


def get_group_secrets_manager() -> Field | Query:
    """
    Get group secrets manager.

    QUERY.GROUPSECRETSMANAGER

    Example:
        q = get_group_secrets_manager()
        result = await gl.graphql.execute(str(q), variables={
            "fullPath": "group"
        })
    """
    return (
        query("GetGroupSecretsManager")
        .arg("fullPath", "$fullPath", "ID!")
        .field("group", args={"fullPath": "$fullPath"})
        .field("secretsManager")
        .field("provider")
        .field("configured")
        .field("lastSyncedAt")
        .end()
    )


def get_group_secrets_needing_rotation() -> Field | Query:
    """
    Get group secrets needing rotation.

    QUERY.GROUPSECRETSNEEDINGROTATION

    Example:
        q = get_group_secrets_needing_rotation()
        result = await gl.graphql.execute(str(q), variables={
            "fullPath": "group"
        })
    """
    return (
        query("GetGroupSecretsNeedingRotation")
        .arg("fullPath", "$fullPath", "ID!")
        .field("group", args={"fullPath": "$fullPath"})
        .field("secretsNeedingRotation")
        .field(
            "nodes", fields=["id", "name", "secretType", "expiresAt", "rotationStatus"]
        )
        .end()
    )


def get_group_secrets_permissions() -> Field | Query:
    """
    Get group secrets permissions.

    QUERY.GROUPSECRETSPERMISSIONS

    Example:
        q = get_group_secrets_permissions()
        result = await gl.graphql.execute(str(q), variables={
            "fullPath": "group"
        })
    """
    return (
        query("GetGroupSecretsPermissions")
        .arg("fullPath", "$fullPath", "ID!")
        .field("group", args={"fullPath": "$fullPath"})
        .field("secretsPermissions")
        .field("canRead")
        .field("canWrite")
        .field("canRotate")
        .field("canDelete")
        .end()
    )


def get_secret_permissions() -> Field | Query:
    """
    Get secret permissions.

    QUERY.SECRETPERMISSIONS

    Example:
        q = get_secret_permissions()
        result = await gl.graphql.execute(str(q), variables={
            "secretId": "gid://gitlab/Secret/123"  # pragma: allowlist secret
        })
    """
    return (
        query("GetSecretPermissions")
        .arg("secretId", "$secretId", "ID!")
        .field("secret", args={"id": "$secretId"})
        .field("permissions")
        .field("canRead")
        .field("canWrite")
        .field("canRotate")
        .field("canDelete")
        .end()
    )


# ========== Audit & Access Queries ==========


def get_abuse_report() -> Field | Query:
    """
    Get abuse report.

    QUERY.ABUSEREPORT

    Example:
        q = get_abuse_report()
        result = await gl.graphql.execute(str(q), variables={
            "reportId": "gid://gitlab/AbuseReport/123"
        })
    """
    return (
        query("GetAbuseReport")
        .arg("reportId", "$reportId", "ID!")
        .field("abuseReport", args={"id": "$reportId"})
        .field("id")
        .field("reason")
        .field("description")
        .field("status")
        .field("createdAt")
        .field("reporter", fields=["username", "name"])
        .end()
    )


def get_access_token_permissions() -> Field | Query:
    """
    Get access token permissions.

    QUERY.ACCESSTOKENPERMISSIONS

    Example:
        q = get_access_token_permissions()
        result = await gl.graphql.execute(str(q), variables={
            "tokenId": "gid://gitlab/PersonalAccessToken/123"
        })
    """
    return (
        query("GetAccessTokenPermissions")
        .arg("tokenId", "$tokenId", "ID!")
        .field("personalAccessToken", args={"id": "$tokenId"})
        .field("permissions")
        .field("scopes")
        .end()
    )


def get_audit_event_definitions() -> Field | Query:
    """
    Get audit event definitions.

    QUERY.AUDITEVENTDEFINITIONS

    Example:
        q = get_audit_event_definitions()
        result = await gl.graphql.execute(str(q))
    """
    return (
        query("GetAuditEventDefinitions")
        .field("auditEventDefinitions")
        .field("nodes", fields=["id", "name", "description", "category"])
        .end()
    )


def get_audit_events_instance_amazon_s3_configurations() -> Field | Query:
    """
    Get audit events instance Amazon S3 configurations (Deprecated).

    QUERY.AUDITEVENTSINSTANCEAMAZONS3CONFIGURATIONS

    Example:
        q = get_audit_events_instance_amazon_s3_configurations()
        result = await gl.graphql.execute(str(q))
    """
    return (
        query("GetAuditEventsInstanceAmazonS3Configurations")
        .field("auditEventsInstanceAmazonS3Configurations")
        .field("nodes", fields=["id", "bucketName", "region", "enabled"])
        .end()
    )


def get_audit_events_instance_streaming_destinations() -> Field | Query:
    """
    Get audit events instance streaming destinations.

    QUERY.AUDITEVENTSINSTANCESTREAMINGDESTINATIONS

    Example:
        q = get_audit_events_instance_streaming_destinations()
        result = await gl.graphql.execute(str(q))
    """
    return (
        query("GetAuditEventsInstanceStreamingDestinations")
        .field("auditEventsInstanceStreamingDestinations")
        .field("nodes", fields=["id", "name", "url", "enabled", "destinationType"])
        .end()
    )


def get_instance_external_audit_event_destinations() -> Field | Query:
    """
    Get instance external audit event destinations (Deprecated).

    QUERY.INSTANCEEXTERNALAUDITEVENTDESTINATIONS

    Example:
        q = get_instance_external_audit_event_destinations()
        result = await gl.graphql.execute(str(q))
    """
    return (
        query("GetInstanceExternalAuditEventDestinations")
        .field("instanceExternalAuditEventDestinations")
        .field("nodes", fields=["id", "name", "url", "enabled"])
        .end()
    )


def get_instance_google_cloud_logging_configurations() -> Field | Query:
    """
    Get instance Google Cloud logging configurations (Deprecated).

    QUERY.INSTANCEGOOGLECLOUDLOGGINGCONFIGURATIONS

    Example:
        q = get_instance_google_cloud_logging_configurations()
        result = await gl.graphql.execute(str(q))
    """
    return (
        query("GetInstanceGoogleCloudLoggingConfigurations")
        .field("instanceGoogleCloudLoggingConfigurations")
        .field("nodes", fields=["id", "projectId", "logName", "enabled"])
        .end()
    )


# ========== Dependency & Pipeline Test Queries ==========


def get_dependency() -> Field | Query:
    """
    Get dependency information.

    QUERY.DEPENDENCY

    Example:
        q = get_dependency()
        result = await gl.graphql.execute(str(q), variables={
            "fullPath": "group/project",
            "dependencyId": "123"
        })
    """
    return (
        query("GetDependency")
        .arg("fullPath", "$fullPath", "ID!")
        .arg("dependencyId", "$dependencyId", "ID!")
        .field("project", args={"fullPath": "$fullPath"})
        .field("dependency", args={"id": "$dependencyId"})
        .field("id")
        .field("name")
        .field("version")
        .field("packageManager")
        .field("direct")
        .end()
    )


def get_pipeline_execution_schedule_policy_test_run() -> Field | Query:
    """
    Get pipeline execution schedule policy test run.

    QUERY.PIPELINEEXECUTIONSCHEDULEPOLICYTESTRUN

    Example:
        q = get_pipeline_execution_schedule_policy_test_run()
        result = await gl.graphql.execute(str(q), variables={
            "fullPath": "group/project",
            "scheduleId": "gid://gitlab/PipelineSchedule/123"
        })
    """
    return (
        query("GetPipelineExecutionSchedulePolicyTestRun")
        .arg("fullPath", "$fullPath", "ID!")
        .arg("scheduleId", "$scheduleId", "ID!")
        .field("project", args={"fullPath": "$fullPath"})
        .field("pipelineSchedule", args={"id": "$scheduleId"})
        .field("policyTestRun")
        .field("status")
        .field("results")
        .end()
    )


# ========== Export Constants ==========

GET_VULNERABILITIES = str(get_vulnerabilities())
GET_VULNERABILITY = str(get_vulnerability())
GET_VULNERABILITIES_COUNT_BY_DAY = str(get_vulnerabilities_count_by_day())
GET_PROJECT_COMPLIANCE_VIOLATION = str(get_project_compliance_violation())
GET_COMPLIANCE_REQUIREMENT_CONTROLS = str(get_compliance_requirement_controls())
GET_SECURITY_CONFIGURATION = str(get_security_configuration())
GET_SECURITY_POLICIES_SYNC_STATUS = str(get_security_policies_sync_status())
GET_SECURITY_SCAN_PROFILE = str(get_security_scan_profile())
GET_NAMESPACE_SECURITY_PROJECTS = str(get_namespace_security_projects())
GET_INSTANCE_SECURITY_DASHBOARD = str(get_instance_security_dashboard())
GET_PROJECT_SECRETS = str(get_project_secrets())
GET_PROJECT_SECRET = str(get_project_secret())
GET_PROJECT_SECRETS_MANAGER = str(get_project_secrets_manager())
GET_PROJECT_SECRETS_NEEDING_ROTATION = str(get_project_secrets_needing_rotation())
GET_PROJECT_SECRETS_PERMISSIONS = str(get_project_secrets_permissions())
GET_GROUP_SECRETS = str(get_group_secrets())
GET_GROUP_SECRET = str(get_group_secret())
GET_GROUP_SECRETS_MANAGER = str(get_group_secrets_manager())
GET_GROUP_SECRETS_NEEDING_ROTATION = str(get_group_secrets_needing_rotation())
GET_GROUP_SECRETS_PERMISSIONS = str(get_group_secrets_permissions())
GET_SECRET_PERMISSIONS = str(get_secret_permissions())
GET_ABUSE_REPORT = str(get_abuse_report())
GET_ACCESS_TOKEN_PERMISSIONS = str(get_access_token_permissions())
GET_AUDIT_EVENT_DEFINITIONS = str(get_audit_event_definitions())
GET_AUDIT_EVENTS_INSTANCE_AMAZON_S3_CONFIGURATIONS = str(
    get_audit_events_instance_amazon_s3_configurations()
)
GET_AUDIT_EVENTS_INSTANCE_STREAMING_DESTINATIONS = str(
    get_audit_events_instance_streaming_destinations()
)
GET_INSTANCE_EXTERNAL_AUDIT_EVENT_DESTINATIONS = str(
    get_instance_external_audit_event_destinations()
)
GET_INSTANCE_GOOGLE_CLOUD_LOGGING_CONFIGURATIONS = str(
    get_instance_google_cloud_logging_configurations()
)
GET_DEPENDENCY = str(get_dependency())
GET_PIPELINE_EXECUTION_SCHEDULE_POLICY_TEST_RUN = str(
    get_pipeline_execution_schedule_policy_test_run()
)
