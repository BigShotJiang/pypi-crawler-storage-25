"""
Type Hints for GraphQL Results

Provides TypedDict definitions for common GraphQL query results.
"""

from __future__ import annotations

from typing import TypedDict

# ========== Base Types ==========


class GraphQLResponse(TypedDict, total=False):
    """Standard GraphQL response structure."""

    data: dict
    errors: list[dict]
    extensions: dict


# ========== User Types ==========


class User(TypedDict, total=False):
    """User object."""

    id: int
    username: str
    name: str
    avatarUrl: str
    webUrl: str
    bio: str
    location: str
    organization: str
    createdAt: str
    email: str
    publicEmail: str
    websiteUrl: str
    twitter: str
    linkedIn: str
    skype: str
    state: str
    isAdmin: bool
    isFollowing: bool
    isFollower: bool
    color: str
    commitEmail: str


class UserResult(TypedDict):
    """Result containing user data."""

    user: User


class UserConnection(TypedDict):
    """User connection for pagination."""

    nodes: list[User]
    pageInfo: PageInfo


class UserWithStatus(User, total=False):
    """User with additional status info."""

    status: UserStatus
    activity: UserActivity


class UserStatus(TypedDict, total=False):
    """User status information."""

    emoji: str
    message: str
    availability: str


class UserActivity(TypedDict, total=False):
    """User activity information."""

    lastActivityOn: str
    commitCount: int


# ========== Project Types ==========


class Project(TypedDict, total=False):
    """Project object."""

    id: int
    name: str
    path: str
    fullPath: str
    description: str
    webUrl: str
    createdAt: str
    updatedAt: str
    openIssuesCount: int
    openMergeRequestsCount: int
    closedIssuesCount: int
    mergedMergeRequestsCount: int
    packagesCount: int
    repositorySize: int
    archived: bool
    visibility: str
    nameWithNamespace: str
    issuesEnabled: bool
    mergeRequestsEnabled: bool
    wikiEnabled: bool
    snippetsEnabled: bool
    jobsEnabled: bool
    containerRegistryEnabled: bool
    serviceDeskEnabled: bool
    defaultBranch: str
    starCount: int
    forkCount: int
    lastActivityAt: str
    namespace: Namespace
    permissions: ProjectPermissions


class ProjectResult(TypedDict):
    """Result containing project data."""

    project: Project


class ProjectWithMembers(TypedDict, total=False):
    """Project with members."""

    id: int
    name: str
    fullPath: str
    members: MembersConnection


class MembersConnection(TypedDict):
    """Members connection."""

    nodes: list[Member]


class Member(TypedDict, total=False):
    """Project/group member."""

    id: int
    user: User
    accessLevel: str
    expiresAt: str


class Namespace(TypedDict, total=False):
    """Namespace (group/user) information."""

    id: int
    name: str
    fullPath: str
    kind: str


class ProjectPermissions(TypedDict, total=False):
    """Project permissions."""

    groupAccess: AccessLevel
    projectAccess: AccessLevel


class AccessLevel(TypedDict, total=False):
    """Access level information."""

    accessLevel: int
    notificationLevel: int


class ProjectStatistics(TypedDict, total=False):
    """Project statistics."""

    openIssuesCount: int
    closedIssuesCount: int
    openMergeRequestsCount: int
    mergedMergeRequestsCount: int
    packagesCount: int
    repositorySize: int
    storageSize: int
    wikiSize: int


# ========== Merge Request Types ==========


class MergeRequest(TypedDict, total=False):
    """Merge request object."""

    iid: int
    title: str
    state: str
    webUrl: str
    createdAt: str
    updatedAt: str
    mergedAt: str
    closedAt: str
    sourceBranch: str
    targetBranch: str
    author: User
    assignees: list[User]
    reviewers: list[User]
    labels: list[Label]
    description: str
    mergeStatus: str
    isLocked: bool
    shouldRemoveSourceBranch: bool
    forceRemoveSourceBranch: bool
    allowCollaboration: bool
    workInProgress: bool
    draft: bool
    mergeCommitSha: str
    squashCommitSha: str
    diffHeadSha: str
    changesCount: str
    userNotesCount: int
    upvotes: int
    downvotes: int
    milestone: Milestone
    timeStats: TimeStats


class MergeRequestResult(TypedDict):
    """Result containing MR data."""

    mergeRequest: MergeRequest


class MergeRequestConnection(TypedDict):
    """MR connection for pagination."""

    nodes: list[MergeRequest]
    pageInfo: PageInfo


class MergeRequestWithDiff(MergeRequest, total=False):
    """Merge request with diff information."""

    diffRefs: DiffRefs
    changes: list[MergeRequestChange]


class DiffRefs(TypedDict, total=False):
    """Diff references."""

    baseSha: str
    headSha: str
    startSha: str


class MergeRequestChange(TypedDict, total=False):
    """Merge request change."""

    oldPath: str
    newPath: str
    aMode: str
    bMode: str
    diff: str
    newFile: bool
    renamedFile: bool
    deletedFile: bool


# ========== Issue Types ==========


class Issue(TypedDict, total=False):
    """Issue object."""

    iid: int
    title: str
    state: str
    webUrl: str
    createdAt: str
    updatedAt: str
    closedAt: str
    closedBy: User
    author: User
    assignees: list[User]
    labels: list[Label]
    description: str
    confidential: bool
    dueDate: str
    weight: int
    severity: str
    epic: Epic
    milestone: Milestone
    userNotesCount: int
    upvotes: int
    downvotes: int
    timeEstimate: int
    totalTimeSpent: int
    humanTimeEstimate: str
    humanTotalTimeSpent: str


class IssueResult(TypedDict):
    """Result containing issue data."""

    issue: Issue


class IssueConnection(TypedDict):
    """Issue connection for pagination."""

    nodes: list[Issue]
    pageInfo: PageInfo


class Epic(TypedDict, total=False):
    """Epic object."""

    id: int
    iid: int
    title: str
    state: str
    webUrl: str
    description: str
    author: User
    labels: list[Label]
    startDate: str
    endDate: str
    dueDate: str


class Milestone(TypedDict, total=False):
    """Milestone object."""

    id: int
    iid: int
    title: str
    description: str
    state: str
    webUrl: str
    startDate: str
    dueDate: str
    createdAt: str
    updatedAt: str


class TimeStats(TypedDict, total=False):
    """Time tracking statistics."""

    timeEstimate: int
    totalTimeSpent: int
    humanTimeEstimate: str
    humanTotalTimeSpent: str


# ========== Group Types ==========


class Group(TypedDict, total=False):
    """Group object."""

    id: int
    name: str
    fullPath: str
    description: str
    webUrl: str
    createdAt: str
    parent: Group | None
    visibility: str
    avatarUrl: str
    webPath: str
    mentionAt: str
    shareWithGroupLock: bool
    requireTwoFactorAuthentication: bool
    twoFactorGracePeriod: int
    projectCreationLevel: str
    autoDevopsEnabled: bool
    subgroupCreationLevel: str
    emailsDisabled: bool
    mentionsDisabled: bool
    lfsEnabled: bool
    defaultBranchProtection: int
    sharedRunnersSetting: str
    extraSharedRunnersMinutes: int


class GroupResult(TypedDict):
    """Result containing group data."""

    group: Group


class GroupWithProjects(TypedDict, total=False):
    """Group with projects."""

    id: int
    name: str
    fullPath: str
    projects: ProjectConnection


class ProjectConnection(TypedDict):
    """Project connection for pagination."""

    nodes: list[Project]
    pageInfo: PageInfo


# ========== CI/CD Types ==========


class Pipeline(TypedDict, total=False):
    """Pipeline object."""

    iid: int
    status: str
    ref: str
    sha: str
    webUrl: str
    createdAt: str
    updatedAt: str
    startedAt: str
    finishedAt: str
    duration: int
    queuedDuration: int
    source: str
    author: User
    triggeredBy: PipelineTrigger
    stages: list[PipelineStage]


class PipelineResult(TypedDict):
    """Result containing pipeline data."""

    pipeline: Pipeline


class PipelineConnection(TypedDict):
    """Pipeline connection for pagination."""

    nodes: list[Pipeline]
    pageInfo: PageInfo


class PipelineStage(TypedDict, total=False):
    """Pipeline stage."""

    id: int
    name: str
    status: str
    jobs: list[Job]


class Job(TypedDict, total=False):
    """Job object."""

    id: int
    name: str
    status: str
    stage: str
    webUrl: str
    createdAt: str
    startedAt: str
    finishedAt: str
    duration: int
    queuedDuration: int
    coverage: float
    pipeline: Pipeline
    runner: Runner
    tagList: list[str]
    allowFailure: bool
    when: str
    manual: bool
    retryable: bool
    erasedBy: User
    erasedAt: str


class JobResult(TypedDict):
    """Result containing job data."""

    job: Job


class JobConnection(TypedDict):
    """Job connection for pagination."""

    nodes: list[Job]
    pageInfo: PageInfo


class Runner(TypedDict, total=False):
    """Runner object."""

    id: int
    description: str
    active: bool
    isShared: bool
    ipAddress: str
    online: bool
    status: str
    token: str
    tokenExpiresAt: str
    runnerType: str
    contactedAt: str
    projectsCount: int
    jobsCount: int
    maximumTimeout: int
    runUntagged: bool
    locked: bool
    accessLevel: str
    tagList: list[str]


class RunnerResult(TypedDict):
    """Result containing runner data."""

    runner: Runner


class RunnerConnection(TypedDict):
    """Runner connection for pagination."""

    nodes: list[Runner]
    pageInfo: PageInfo


class PipelineTrigger(TypedDict, total=False):
    """Pipeline trigger information."""

    createdAt: str
    token: str


# ========== Security Types ==========


class Vulnerability(TypedDict, total=False):
    """Vulnerability object."""

    id: str
    iid: int
    title: str
    state: str
    severity: str
    confidence: str
    reportType: str
    solution: str
    description: str
    createdAt: str
    updatedAt: str
    dismissedAt: str
    author: User
    assignees: list[User]
    labels: list[Label]
    project: Project
    identifiers: list[VulnerabilityIdentifier]
    location: VulnerabilityLocation


class VulnerabilityResult(TypedDict):
    """Result containing vulnerability data."""

    vulnerability: Vulnerability


class VulnerabilityConnection(TypedDict):
    """Vulnerability connection for pagination."""

    nodes: list[Vulnerability]
    pageInfo: PageInfo


class VulnerabilityIdentifier(TypedDict, total=False):
    """Vulnerability identifier."""

    type: str
    value: str
    url: str
    name: str


class VulnerabilityLocation(TypedDict, total=False):
    """Vulnerability location."""

    file: str
    startLine: int
    endLine: int
    className: str
    operatingSystem: str


class Secret(TypedDict, total=False):
    """Secret object."""

    id: str
    name: str
    createdAt: str
    updatedAt: str
    expiresAt: str
    secretType: str
    environmentScope: str


class SecretConnection(TypedDict):
    """Secret connection for pagination."""

    nodes: list[Secret]
    pageInfo: PageInfo


# ========== Common Types ==========


class Label(TypedDict, total=False):
    """Label object."""

    id: int
    name: str
    color: str
    description: str
    textColor: str
    priority: int
    isProjectLabel: bool
    isGroupLabel: bool
    subscribed: bool
    openIssuesCount: int
    closedIssuesCount: int
    openMergeRequestsCount: int
    mergedMergeRequestsCount: int


class PageInfo(TypedDict):
    """Pagination info."""

    hasNextPage: bool
    hasPreviousPage: bool
    startCursor: str
    endCursor: str


class Statistics(TypedDict, total=False):
    """Project/group statistics."""

    openIssuesCount: int
    closedIssuesCount: int
    openMergeRequestsCount: int
    mergedMergeRequestsCount: int
    packagesCount: int
    repositorySize: int


class Note(TypedDict, total=False):
    """Note/comment object."""

    id: int
    body: str
    createdAt: str
    updatedAt: str
    author: User
    system: bool
    resolvable: bool
    resolved: bool
    resolvedBy: User
    resolvedAt: str


class NoteConnection(TypedDict):
    """Note connection for pagination."""

    nodes: list[Note]
    pageInfo: PageInfo


class Todo(TypedDict, total=False):
    """Todo object."""

    id: int
    state: str
    createdAt: str
    project: Project
    group: Group
    author: User
    target: TodoTarget
    targetType: str
    actionName: str
    targetUrl: str
    body: str


class TodoConnection(TypedDict):
    """Todo connection for pagination."""

    nodes: list[Todo]
    pageInfo: PageInfo


class TodoTarget(TypedDict, total=False):
    """Todo target (can be MR, Issue, etc.)."""

    iid: int
    title: str
    state: str
    webUrl: str


class Snippet(TypedDict, total=False):
    """Snippet object."""

    id: int
    title: str
    fileName: str
    description: str
    visibility: str
    webUrl: str
    createdAt: str
    updatedAt: str
    author: User


class SnippetConnection(TypedDict):
    """Snippet connection for pagination."""

    nodes: list[Snippet]
    pageInfo: PageInfo


class WikiPage(TypedDict, total=False):
    """Wiki page object."""

    slug: str
    title: str
    format: str
    content: str
    createdAt: str
    updatedAt: str


class WikiPageConnection(TypedDict):
    """Wiki page connection for pagination."""

    nodes: list[WikiPage]
    pageInfo: PageInfo


class Board(TypedDict, total=False):
    """Issue board object."""

    id: int
    name: str
    project: Project
    group: Group
    lists: list[BoardList]


class BoardList(TypedDict, total=False):
    """Board list object."""

    id: int
    label: Label
    position: int
    maxIssueWeight: int
    maxIssueCount: int


class Iteration(TypedDict, total=False):
    """Iteration object."""

    id: int
    iid: int
    title: str
    description: str
    state: str
    webUrl: str
    startDate: str
    dueDate: str
    createdAt: str
    updatedAt: str


class IterationConnection(TypedDict):
    """Iteration connection for pagination."""

    nodes: list[Iteration]
    pageInfo: PageInfo


class WorkItem(TypedDict, total=False):
    """Work item object."""

    id: str
    iid: int
    title: str
    description: str
    state: str
    webUrl: str
    createdAt: str
    updatedAt: str
    author: User
    assignees: list[User]
    labels: list[Label]
    itemType: WorkItemType


class WorkItemType(TypedDict, total=False):
    """Work item type."""

    id: str
    name: str
    icon: str


class WorkItemConnection(TypedDict):
    """Work item connection for pagination."""

    nodes: list[WorkItem]
    pageInfo: PageInfo


class Package(TypedDict, total=False):
    """Package object."""

    id: int
    name: str
    version: str
    packageType: str
    status: str
    createdAt: str
    updatedAt: str
    project: Project
    links: PackageLinks


class PackageConnection(TypedDict):
    """Package connection for pagination."""

    nodes: list[Package]
    pageInfo: PageInfo


class PackageLinks(TypedDict, total=False):
    """Package download links."""

    webPath: str
    deletePath: str


class Environment(TypedDict, total=False):
    """Environment object."""

    id: int
    name: str
    externalUrl: str
    state: str
    tier: str
    autoStopAt: str
    lastDeployment: Deployment


class Deployment(TypedDict, total=False):
    """Deployment object."""

    id: int
    iid: int
    status: str
    createdAt: str
    updatedAt: str
    webUrl: str
    environment: Environment
    deployable: Job


# ========== Mutation Types ==========


class CreateIssueResult(TypedDict):
    """Result from createIssue mutation."""

    issueCreate: IssueResult


class UpdateIssueResult(TypedDict):
    """Result from updateIssue mutation."""

    issueUpdate: IssueResult


class CreateMergeRequestResult(TypedDict):
    """Result from createMergeRequest mutation."""

    mergeRequestCreate: MergeRequestResult


class DeleteResult(TypedDict):
    """Result from delete mutation."""

    clientMutationId: str | None
    success: bool


class MutationResult(TypedDict, total=False):
    """Generic mutation result."""

    clientMutationId: str | None
    errors: list[str]


# ========== Introspection Types ==========


class SchemaType(TypedDict, total=False):
    """GraphQL schema type."""

    kind: str
    name: str
    description: str
    fields: list[FieldInfo]
    inputFields: list[InputValue]
    interfaces: list[TypeRef]
    enumValues: list[EnumValue]
    possibleTypes: list[TypeRef]


class FieldInfo(TypedDict, total=False):
    """GraphQL field info."""

    name: str
    description: str
    args: list[InputValue]
    type: TypeRef
    isDeprecated: bool
    deprecationReason: str


class InputValue(TypedDict, total=False):
    """GraphQL input value."""

    name: str
    description: str
    type: TypeRef
    defaultValue: str


class TypeRef(TypedDict, total=False):
    """GraphQL type reference."""

    kind: str
    name: str
    ofType: TypeRef | None


class EnumValue(TypedDict, total=False):
    """GraphQL enum value."""

    name: str
    description: str
    isDeprecated: bool
    deprecationReason: str


class IntrospectionResult(TypedDict):
    """Result from introspection query."""

    __schema: SchemaInfo


class SchemaInfo(TypedDict, total=False):
    """Schema information."""

    queryType: dict
    mutationType: dict
    subscriptionType: dict
    types: list[SchemaType]
    directives: list[dict]


# ========== Error Types ==========


class GraphQLErrorInfo(TypedDict, total=False):
    """GraphQL error information."""

    message: str
    locations: list[dict]
    path: list[str | int]
    extensions: dict


class GraphQLErrorResponse(TypedDict, total=False):
    """GraphQL error response."""

    errors: list[GraphQLErrorInfo]
    data: dict | None


# ========== Utility Functions ==========


def extract_project(result: ProjectResult) -> Project:
    """Extract project from result."""
    return result["project"]


def extract_user(result: UserResult) -> User:
    """Extract user from result."""
    return result["user"]


def extract_mr(result: MergeRequestResult) -> MergeRequest:
    """Extract merge request from result."""
    return result["mergeRequest"]


def extract_issue(result: IssueResult) -> Issue:
    """Extract issue from result."""
    return result["issue"]


def extract_pipeline(result: PipelineResult) -> Pipeline:
    """Extract pipeline from result."""
    return result["pipeline"]


def extract_job(result: JobResult) -> Job:
    """Extract job from result."""
    return result["job"]


def extract_runner(result: RunnerResult) -> Runner:
    """Extract runner from result."""
    return result["runner"]


def extract_vulnerability(result: VulnerabilityResult) -> Vulnerability:
    """Extract vulnerability from result."""
    return result["vulnerability"]


def extract_nodes(connection: dict) -> list:
    """Extract nodes from connection."""
    return connection.get("nodes", [])


def has_next_page(connection: dict) -> bool:
    """Check if connection has next page."""
    page_info = connection.get("pageInfo", {})
    return page_info.get("hasNextPage", False)


def get_end_cursor(connection: dict) -> str | None:
    """Get end cursor from connection."""
    page_info = connection.get("pageInfo", {})
    return page_info.get("endCursor")
