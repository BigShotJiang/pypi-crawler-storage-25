"""
Issues, Boards & Work Items GraphQL Queries

Coverage: All 13 Issues, Boards & Work Items QUERY.* endpoints
"""

from glabflow.graphql.builder import Field, Query, fragment, query

# ========== Fragments ==========

WORK_ITEM_FRAGMENT = (
    fragment("WorkItemFields", "WorkItem")
    .field("id")
    .field("title")
    .field("description")
    .field("state")
    .field("webUrl")
    .field("createdAt")
    .field("updatedAt")
    .field("workItemType", fields=["name", "icon"])
)

BOARD_LIST_FRAGMENT = (
    fragment("BoardListFields", "BoardList")
    .field("id")
    .field("name")
    .field("position")
    .field("label", fields=["id", "name", "color"])
)

MILESTONE_FRAGMENT = (
    fragment("MilestoneFields", "Milestone")
    .field("id")
    .field("title")
    .field("description")
    .field("state")
    .field("webUrl")
    .field("startDate")
    .field("dueDate")
    .field("createdAt")
    .field("updatedAt")
)

ITERATION_FRAGMENT = (
    fragment("IterationFields", "Iteration")
    .field("id")
    .field("title")
    .field("description")
    .field("startDate")
    .field("dueDate")
    .field("state")
)


# ========== Issue Queries ==========


def get_issue() -> Field | Query:
    """
    Get issue details.

    QUERY.ISSUE

    Example:
        q = get_issue()
        result = await gl.graphql.execute(str(q), variables={
            "fullPath": "group/project",
            "iid": 1
        })
    """
    return (
        query("GetIssue")
        .arg("fullPath", "$fullPath", "ID!")
        .arg("iid", "$iid", "Int!")
        .field("project", args={"fullPath": "$fullPath"})
        .field("issue", args={"iid": "$iid"})
        .field("id")
        .field("iid")
        .field("title")
        .field("description")
        .field("state")
        .field("webUrl")
        .field("createdAt")
        .field("updatedAt")
        .field("closedAt")
        .field("closedBy", fields=["username", "name"])
        .field("author", fields=["username", "name", "avatarUrl"])
        .field("assignees")
        .field("nodes", fields=["username", "name"])
        .end()
        .field("labels")
        .field("nodes", fields=["name", "color"])
        .end()
        .field("milestone", fields=["id", "title", "dueDate"])
        .field("iteration", fields=["id", "title", "startDate", "dueDate"])
        .end()
    )


def get_notes(
    limit: int = 100,
) -> Field | Query:
    """
    Get notes (comments) for a project.

    QUERY.NOTE

    Example:
        q = get_notes()
        async for note in gl.graphql.stream(
            str(q),
            connection_path=["project", "notes"],
            variables={"fullPath": "group/project"}
        ):
            print(note["body"])
    """
    return (
        query("GetNotes")
        .arg("fullPath", "$fullPath", "ID!")
        .arg("after", "$after", "String")
        .arg("first", "$first", "Int")
        .field("project", args={"fullPath": "$fullPath"})
        .field("notes", args={"after": "$after", "first": "$first"})
        .field("pageInfo", fields=["hasNextPage", "endCursor"])
        .field("nodes", fields=["id", "body", "createdAt", "updatedAt", "system"])
        .field("author", fields=["username", "name"])
        .end()
        .end()
    )


def get_synthetic_note() -> Field | Query:
    """
    Get synthetic note (AI-generated).

    QUERY.SYNTHETICNOTE

    Example:
        q = get_synthetic_note()
        result = await gl.graphql.execute(str(q), variables={
            "noteId": "gid://gitlab/Note/123"
        })
    """
    return (
        query("GetSyntheticNote")
        .arg("noteId", "$noteId", "ID!")
        .field("note", args={"id": "$noteId"})
        .field("id")
        .field("body")
        .field("synthetic")
        .field("generatedAt")
        .end()
    )


# ========== Board Queries ==========


def get_board_list() -> Field | Query:
    """
    Get issue board list.

    QUERY.BOARDLIST

    Example:
        q = get_board_list()
        result = await gl.graphql.execute(str(q), variables={
            "fullPath": "group/project",
            "boardId": "gid://gitlab/Boards/123"
        })
    """
    return (
        query("GetBoardList")
        .arg("fullPath", "$fullPath", "ID!")
        .arg("boardId", "$boardId", "ID!")
        .field("project", args={"fullPath": "$fullPath"})
        .field("issueBoard", args={"id": "$boardId"})
        .field("lists")
        .field("nodes", fields=["id", "name", "position"])
        .field("label", fields=["id", "name", "color"])
        .end()
        .end()
    )


def get_epic_board_list() -> Field | Query:
    """
    Get epic board list.

    QUERY.EPICBOARDLIST

    Example:
        q = get_epic_board_list()
        result = await gl.graphql.execute(str(q), variables={
            "fullPath": "group",
            "boardId": "gid://gitlab/EpicBoard/123"
        })
    """
    return (
        query("GetEpicBoardList")
        .arg("fullPath", "$fullPath", "ID!")
        .arg("boardId", "$boardId", "ID!")
        .field("group", args={"fullPath": "$fullPath"})
        .field("epicBoard", args={"id": "$boardId"})
        .field("lists")
        .field("nodes", fields=["id", "name", "position"])
        .end()
        .end()
    )


# ========== Milestone Queries ==========


def get_milestone() -> Field | Query:
    """
    Get milestone details.

    QUERY.MILESTONE

    Example:
        q = get_milestone()
        result = await gl.graphql.execute(str(q), variables={
            "fullPath": "group/project",
            "iid": 1
        })
    """
    return (
        query("GetMilestone")
        .arg("fullPath", "$fullPath", "ID!")
        .arg("iid", "$iid", "Int!")
        .field("project", args={"fullPath": "$fullPath"})
        .field("milestone", args={"iid": "$iid"})
        .field("id")
        .field("iid")
        .field("title")
        .field("description")
        .field("state")
        .field("webUrl")
        .field("startDate")
        .field("dueDate")
        .field("createdAt")
        .field("updatedAt")
        .field("expired")
        .field("issuesCount")
        .field("mergeRequestsCount")
        .end()
    )


def get_milestones(
    state: str = "active",
    limit: int = 100,
) -> Field | Query:
    """
    Get milestones for a project.

    Example:
        q = get_milestones(state="active")
        async for milestone in gl.graphql.stream(
            str(q),
            connection_path=["project", "milestones"],
            variables={"fullPath": "group/project"}
        ):
            print(milestone["title"], milestone["dueDate"])
    """
    return (
        query("GetMilestones")
        .arg("fullPath", "$fullPath", "ID!")
        .arg("after", "$after", "String")
        .arg("first", "$first", "Int")
        .field("project", args={"fullPath": "$fullPath"})
        .field(
            "milestones", args={"after": "$after", "first": "$first", "state": state}
        )
        .field("pageInfo", fields=["hasNextPage", "endCursor"])
        .field(
            "nodes",
            fields=[
                "id",
                "iid",
                "title",
                "description",
                "state",
                "startDate",
                "dueDate",
                "expired",
            ],
        )
        .end()
    )


# ========== Iteration Queries ==========


def get_iteration() -> Field | Query:
    """
    Get iteration details.

    QUERY.ITERATION

    Example:
        q = get_iteration()
        result = await gl.graphql.execute(str(q), variables={
            "fullPath": "group",
            "iterationId": "gid://gitlab/Iterations/123"
        })
    """
    return (
        query("GetIteration")
        .arg("fullPath", "$fullPath", "ID!")
        .arg("iterationId", "$iterationId", "ID!")
        .field("group", args={"fullPath": "$fullPath"})
        .field("iteration", args={"id": "$iterationId"})
        .field("id")
        .field("title")
        .field("description")
        .field("startDate")
        .field("dueDate")
        .field("state")
        .field("elapsedDays")
        .end()
    )


def get_iterations(
    state: str = "current",
    limit: int = 100,
) -> Field | Query:
    """
    Get iterations for a group.

    Example:
        q = get_iterations(state="current")
        async for iteration in gl.graphql.stream(
            str(q),
            connection_path=["group", "iterations"],
            variables={"fullPath": "group"}
        ):
            print(iteration["title"], iteration["startDate"])
    """
    return (
        query("GetIterations")
        .arg("fullPath", "$fullPath", "ID!")
        .arg("after", "$after", "String")
        .arg("first", "$first", "Int")
        .field("group", args={"fullPath": "$fullPath"})
        .field(
            "iterations", args={"after": "$after", "first": "$first", "state": state}
        )
        .field("pageInfo", fields=["hasNextPage", "endCursor"])
        .field(
            "nodes",
            fields=["id", "title", "description", "startDate", "dueDate", "state"],
        )
        .end()
    )


# ========== Work Item Queries ==========


def get_work_item() -> Field | Query:
    """
    Get work item details.

    QUERY.WORKITEM

    Example:
        q = get_work_item()
        result = await gl.graphql.execute(str(q), variables={
            "workItemId": "gid://gitlab/WorkItem/123"
        })
    """
    return (
        query("GetWorkItem")
        .arg("workItemId", "$workItemId", "ID!")
        .field("workItem", args={"id": "$workItemId"})
        .field("id")
        .field("title")
        .field("description")
        .field("state")
        .field("webUrl")
        .field("createdAt")
        .field("updatedAt")
        .field("workItemType", fields=["name", "icon", "color"])
        .field("assignees")
        .field("nodes", fields=["username", "name"])
        .end()
        .field("author", fields=["username", "name"])
        .end()
    )


def get_work_items_by_reference() -> Field | Query:
    """
    Get work items by reference.

    QUERY.WORKITEMSBYREFERENCE

    Example:
        q = get_work_items_by_reference()
        result = await gl.graphql.execute(str(q), variables={
            "fullPath": "group/project",
            "reference": "PROJ-123"
        })
    """
    return (
        query("GetWorkItemsByReference")
        .arg("fullPath", "$fullPath", "ID!")
        .arg("reference", "$reference", "String!")
        .field("project", args={"fullPath": "$fullPath"})
        .field("workItemsByReference", args={"reference": "$reference"})
        .field("nodes", fields=["id", "title", "state"])
        .field("workItemType", fields=["name"])
        .end()
        .end()
    )


def get_work_item_allowed_statuses() -> Field | Query:
    """
    Get allowed statuses for work items.

    QUERY.WORKITEMALLOWEDSTATUSES

    Example:
        q = get_work_item_allowed_statuses()
        result = await gl.graphql.execute(str(q), variables={
            "fullPath": "group/project"
        })
    """
    return (
        query("GetWorkItemAllowedStatuses")
        .arg("fullPath", "$fullPath", "ID!")
        .field("project", args={"fullPath": "$fullPath"})
        .field("workItemAllowedStatuses")
        .field("nodes", fields=["id", "name", "color", "type"])
        .end()
    )


def get_work_item_type_icon_definitions() -> Field | Query:
    """
    Get work item type icon definitions.

    QUERY.WORKITEMTYPEICONDEFINITIONS

    Example:
        q = get_work_item_type_icon_definitions()
        result = await gl.graphql.execute(str(q))
    """
    return (
        query("GetWorkItemTypeIconDefinitions")
        .field("workItemTypeIconDefinitions")
        .field("nodes", fields=["name", "path", "color"])
        .end()
    )


def get_work_item_description_template_content() -> Field | Query:
    """
    Get work item description template content.

    QUERY.WORKITEMDESCRIPTIONTEMPLATECONTENT

    Example:
        q = get_work_item_description_template_content()
        result = await gl.graphql.execute(str(q), variables={
            "fullPath": "group/project"
        })
    """
    return (
        query("GetWorkItemDescriptionTemplateContent")
        .arg("fullPath", "$fullPath", "ID!")
        .field("project", args={"fullPath": "$fullPath"})
        .field("workItemDescriptionTemplateContent")
        .field("content")
        .end()
    )


# ========== Time Tracking Queries ==========


def get_time_logs(
    limit: int = 100,
) -> Field | Query:
    """
    Get time logs.

    QUERY.TIMELOGS

    Example:
        q = get_time_logs()
        async for timelog in gl.graphql.stream(
            str(q),
            connection_path=["project", "timeLogs"],
            variables={"fullPath": "group/project"}
        ):
            print(timelog["duration"], timelog["author"])
    """
    return (
        query("GetTimeLogs")
        .arg("fullPath", "$fullPath", "ID!")
        .arg("after", "$after", "String")
        .arg("first", "$first", "Int")
        .field("project", args={"fullPath": "$fullPath"})
        .field("timeLogs", args={"after": "$after", "first": "$first"})
        .field("pageInfo", fields=["hasNextPage", "endCursor"])
        .field("nodes", fields=["id", "duration", "createdAt"])
        .field("author", fields=["username", "name"])
        .end()
        .end()
    )


# ========== Todo Queries ==========


def get_todos(
    limit: int = 100,
) -> Field | Query:
    """
    Get todos.

    QUERY.TODO

    Example:
        q = get_todos()
        async for todo in gl.graphql.stream(
            str(q),
            connection_path=["todos"]
        ):
            print(todo["actionName"], todo["target"]["title"])
    """
    return (
        query("GetTodos")
        .arg("after", "$after", "String")
        .arg("first", "$first", "Int")
        .field("todos", args={"after": "$after", "first": "$first"})
        .field("pageInfo", fields=["hasNextPage", "endCursor"])
        .field("nodes", fields=["id", "actionName", "createdAt"])
        .field("target", fields=["id", "title", "webUrl"])
        .field("project", fields=["id", "name", "fullPath"])
        .end()
        .end()
    )


# ========== Custom Field Queries ==========


def get_custom_field() -> Field | Query:
    """
    Get custom field.

    QUERY.CUSTOMFIELD

    Example:
        q = get_custom_field()
        result = await gl.graphql.execute(str(q), variables={
            "fullPath": "group/project",
            "fieldId": "gid://gitlab/CustomField/123"
        })
    """
    return (
        query("GetCustomField")
        .arg("fullPath", "$fullPath", "ID!")
        .arg("fieldId", "$fieldId", "ID!")
        .field("project", args={"fullPath": "$fullPath"})
        .field("customField", args={"id": "$fieldId"})
        .field("id")
        .field("name")
        .field("fieldType")
        .field("required")
        .field("scope")
        .end()
    )


# ========== Export Constants ==========

GET_ISSUE = str(get_issue())
GET_NOTES = str(get_notes())
GET_SYNTHETIC_NOTE = str(get_synthetic_note())
GET_BOARD_LIST = str(get_board_list())
GET_EPIC_BOARD_LIST = str(get_epic_board_list())
GET_MILESTONE = str(get_milestone())
GET_MILESTONES = str(get_milestones())
GET_ITERATION = str(get_iteration())
GET_ITERATIONS = str(get_iterations())
GET_WORK_ITEM = str(get_work_item())
GET_WORK_ITEMS_BY_REFERENCE = str(get_work_items_by_reference())
GET_WORK_ITEM_ALLOWED_STATUSES = str(get_work_item_allowed_statuses())
GET_WORK_ITEM_TYPE_ICON_DEFINITIONS = str(get_work_item_type_icon_definitions())
GET_WORK_ITEM_DESCRIPTION_TEMPLATE_CONTENT = str(
    get_work_item_description_template_content()
)
GET_TIME_LOGS = str(get_time_logs())
GET_TODOS = str(get_todos())
GET_CUSTOM_FIELD = str(get_custom_field())
