"""
GraphQL Subscription Support

Implements polling-based subscriptions for real-time updates.
GitLab GraphQL doesn't support WebSocket subscriptions natively,
so this module provides a compatible polling mechanism.
"""

from __future__ import annotations

import asyncio
import logging
from collections.abc import AsyncIterator, Callable
from dataclasses import dataclass, field
from typing import TYPE_CHECKING, Any

import msgspec

from glabflow._errors import GraphQLError

if TYPE_CHECKING:
    from glabflow.graphql.client import GraphQLClient

logger = logging.getLogger(__name__)


@dataclass
class SubscriptionConfig:
    """Configuration for a subscription."""

    poll_interval_ms: int = 5000
    max_polls: int | None = None
    stop_on_error: bool = False
    deduplicate: bool = True
    error_handler: Callable[[Exception], None] | None = None


@dataclass
class Subscription:
    """Represents an active subscription."""

    id: str
    query: str
    variables: dict[str, Any]
    connection_path: list[str] | None = None
    config: SubscriptionConfig = field(default_factory=SubscriptionConfig)
    is_active: bool = False


class SubscriptionManager:
    """
    Manages GraphQL subscriptions via polling.

    Since GitLab doesn't support WebSocket-based GraphQL subscriptions,
    this manager implements a polling-based approach that yields new
    data when changes are detected.

    Example::

        # Subscribe to new merge requests
        async for mr in gl.graphql.subscriptions.subscribe(
            query=gl.graphql.get_merge_requests(),
            connection_path=["project", "mergeRequests"],
            variables={"fullPath": "group/project"},
            poll_interval_ms=3000,
        ):
            print(f"New MR: {mr['title']}")

    Args:
        client: GraphQL client instance
    """

    def __init__(self, client: GraphQLClient) -> None:
        self._client = client
        self._subscriptions: dict[str, Subscription] = {}
        self._active_tasks: dict[str, asyncio.Task] = {}
        self._subscription_counter = 0

    def subscribe(
        self,
        query: str,
        connection_path: list[str] | None = None,
        variables: dict[str, Any] | None = None,
        poll_interval_ms: int = 5000,
        max_polls: int | None = None,
        stop_on_error: bool = False,
        deduplicate: bool = True,
        error_handler: Callable[[Exception], None] | None = None,
    ) -> AsyncIterator[dict[str, Any]]:
        """
        Create a subscription that polls for updates.

        Args:
            query: GraphQL query string or builder
            connection_path: Path to connection for pagination
            variables: Query variables
            poll_interval_ms: Time between polls
            max_polls: Maximum number of polls (None = infinite)
            stop_on_error: Stop subscription on error
            deduplicate: Skip duplicate results
            error_handler: Custom error handler

        Yields:
            New or updated data on each poll
        """
        self._subscription_counter += 1
        sub_id = f"sub_{self._subscription_counter}"

        subscription = Subscription(
            id=sub_id,
            query=query,
            variables=variables or {},
            connection_path=connection_path,
            config=SubscriptionConfig(
                poll_interval_ms=poll_interval_ms,
                max_polls=max_polls,
                stop_on_error=stop_on_error,
                deduplicate=deduplicate,
                error_handler=error_handler,
            ),
        )

        self._subscriptions[sub_id] = subscription
        return self._poll_subscription(subscription)

    async def _poll_subscription(
        self, subscription: Subscription
    ) -> AsyncIterator[dict[str, Any]]:
        """Internal polling loop for a subscription."""
        subscription.is_active = True
        poll_count = 0
        seen_hashes: set[str] = set()

        try:
            while subscription.is_active:
                # Check max polls
                if subscription.config.max_polls is not None:
                    if poll_count >= subscription.config.max_polls:
                        break

                poll_count += 1

                try:
                    # Execute query
                    data = await self._client.execute(
                        subscription.query,
                        variables=subscription.variables,
                    )

                    # Navigate to connection if specified
                    if subscription.connection_path:
                        result = data
                        for key in subscription.connection_path:
                            if not isinstance(result, dict):
                                raise GraphQLError(
                                    f"Expected dict at path step {key!r}"
                                )
                            result = result.get(key)
                            if result is None:
                                break

                        if result is None:
                            await asyncio.sleep(
                                subscription.config.poll_interval_ms / 1000
                            )
                            continue

                        # Process nodes
                        nodes = result.get("nodes", [])
                        for node in nodes:
                            node_hash = self._hash_node(node)

                            # Deduplicate if enabled
                            if subscription.config.deduplicate:
                                if node_hash in seen_hashes:
                                    continue
                                seen_hashes.add(node_hash)

                            yield node

                    else:
                        # Yield entire result
                        result_hash = self._hash_node(data)
                        if subscription.config.deduplicate:
                            if result_hash in seen_hashes:
                                await asyncio.sleep(
                                    subscription.config.poll_interval_ms / 1000
                                )
                                continue
                            seen_hashes.add(result_hash)

                        yield data

                except Exception as e:
                    if subscription.config.error_handler:
                        subscription.config.error_handler(e)
                    elif subscription.config.stop_on_error:
                        raise
                    else:
                        logger.warning(f"Subscription {subscription.id} error: {e}")

                # Wait for next poll
                await asyncio.sleep(subscription.config.poll_interval_ms / 1000)

        finally:
            subscription.is_active = False
            self._subscriptions.pop(subscription.id, None)

    def unsubscribe(self, subscription_id: str) -> bool:
        """
        Cancel an active subscription.

        Args:
            subscription_id: Subscription ID to cancel

        Returns:
            True if subscription was found and cancelled
        """
        if subscription_id in self._subscriptions:
            self._subscriptions[subscription_id].is_active = False
            if subscription_id in self._active_tasks:
                self._active_tasks[subscription_id].cancel()
            return True
        return False

    def unsubscribe_all(self) -> int:
        """
        Cancel all active subscriptions.

        Returns:
            Number of subscriptions cancelled
        """
        count = 0
        for sub_id in list(self._subscriptions.keys()):
            if self.unsubscribe(sub_id):
                count += 1
        return count

    def get_active_subscriptions(self) -> list[dict[str, Any]]:
        """Get list of active subscriptions."""
        return [
            {
                "id": sub.id,
                "query": sub.query[:100] + "...",
                "variables": sub.variables,
                "is_active": sub.is_active,
            }
            for sub in self._subscriptions.values()
            if sub.is_active
        ]

    @staticmethod
    def _hash_node(node: dict[str, Any]) -> str:
        """Create a hash of a node for deduplication."""
        import hashlib

        # msgspec.encode is ~3x faster than json.dumps; blake2b is ~3x faster than MD5
        key_bytes = msgspec.json.encode(node)
        return hashlib.blake2b(key_bytes, digest_size=16).hexdigest()


# Pre-built subscription helpers


class MergeRequestSubscription:
    """
    Subscription for merge request changes.

    Example::

        sub = MergeRequestSubscription(gl.graphql, "group/project")
        async for mr in sub.subscribe():
            print(f"MR updated: {mr['title']}")
    """

    def __init__(
        self,
        client: GraphQLClient,
        project_path: str,
        state: str | None = None,
    ) -> None:
        self._client = client
        self._project_path = project_path
        self._state = state

    async def subscribe(
        self,
        poll_interval_ms: int = 5000,
        **kwargs: Any,
    ) -> AsyncIterator[dict[str, Any]]:
        """Subscribe to merge request updates."""
        query = """
            query SubscribeMergeRequests($fullPath: ID!, $state: MergeRequestState) {
                project(fullPath: $fullPath) {
                    mergeRequests(state: $state) {
                        nodes {
                            iid
                            title
                            state
                            webUrl
                            createdAt
                            updatedAt
                            author { username }
                        }
                        pageInfo {
                            hasNextPage
                            endCursor
                        }
                    }
                }
            }
        """
        variables = {"fullPath": self._project_path}
        if self._state:
            variables["state"] = self._state

        async for mr in self._client.subscriptions.subscribe(
            query=query,
            connection_path=["project", "mergeRequests"],
            variables=variables,
            poll_interval_ms=poll_interval_ms,
            **kwargs,
        ):
            yield mr


class PipelineSubscription:
    """
    Subscription for pipeline status changes.

    Example::

        sub = PipelineSubscription(gl.graphql, "group/project")
        async for pipeline in sub.subscribe():
            print(f"Pipeline {pipeline['iid']}: {pipeline['status']}")
    """

    def __init__(
        self,
        client: GraphQLClient,
        project_path: str,
        ref: str | None = None,
    ) -> None:
        self._client = client
        self._project_path = project_path
        self._ref = ref

    async def subscribe(
        self,
        poll_interval_ms: int = 3000,
        **kwargs: Any,
    ) -> AsyncIterator[dict[str, Any]]:
        """Subscribe to pipeline updates."""
        query = """
            query SubscribePipelines($fullPath: ID!, $ref: String) {
                project(fullPath: $fullPath) {
                    pipelines(ref: $ref) {
                        nodes {
                            iid
                            status
                            ref
                            sha
                            createdAt
                            updatedAt
                            webUrl
                        }
                        pageInfo {
                            hasNextPage
                            endCursor
                        }
                    }
                }
            }
        """
        variables = {"fullPath": self._project_path}
        if self._ref:
            variables["ref"] = self._ref

        async for pipeline in self._client.subscriptions.subscribe(
            query=query,
            connection_path=["project", "pipelines"],
            variables=variables,
            poll_interval_ms=poll_interval_ms,
            **kwargs,
        ):
            yield pipeline


class IssueSubscription:
    """
    Subscription for issue changes.

    Example::

        sub = IssueSubscription(gl.graphql, "group/project")
        async for issue in sub.subscribe():
            print(f"Issue updated: {issue['title']}")
    """

    def __init__(
        self,
        client: GraphQLClient,
        project_path: str,
        state: str | None = None,
    ) -> None:
        self._client = client
        self._project_path = project_path
        self._state = state

    async def subscribe(
        self,
        poll_interval_ms: int = 5000,
        **kwargs: Any,
    ) -> AsyncIterator[dict[str, Any]]:
        """Subscribe to issue updates."""
        query = """
            query SubscribeIssues($fullPath: ID!, $state: IssueState) {
                project(fullPath: $fullPath) {
                    issues(state: $state) {
                        nodes {
                            iid
                            title
                            state
                            webUrl
                            createdAt
                            updatedAt
                            author { username }
                        }
                        pageInfo {
                            hasNextPage
                            endCursor
                        }
                    }
                }
            }
        """
        variables = {"fullPath": self._project_path}
        if self._state:
            variables["state"] = self._state

        async for issue in self._client.subscriptions.subscribe(
            query=query,
            connection_path=["project", "issues"],
            variables=variables,
            poll_interval_ms=poll_interval_ms,
            **kwargs,
        ):
            yield issue
