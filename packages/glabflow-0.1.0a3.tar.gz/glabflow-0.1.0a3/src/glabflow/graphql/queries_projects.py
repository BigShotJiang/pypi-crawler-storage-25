"""
Projects, Repositories & Packages GraphQL Queries

Coverage: All 14 Projects & Repositories QUERY.* endpoints
"""

from glabflow.graphql.builder import Field, Query, fragment, query

# ========== Fragments ==========

PACKAGE_FRAGMENT = (
    fragment("PackageFields", "Package")
    .field("id")
    .field("name")
    .field("version")
    .field("packageType")
    .field("status")
    .field("webUrl")
    .field("createdAt")
    .field("updatedAt")
)

CONTAINER_REPOSITORY_FRAGMENT = (
    fragment("ContainerRepositoryFields", "ContainerRepository")
    .field("id")
    .field("name")
    .field("path")
    .field("tags")
    .field("createdAt")
    .field("updatedAt")
)

SNIPPET_FRAGMENT = (
    fragment("SnippetFields", "Snippet")
    .field("id")
    .field("title")
    .field("description")
    .field("webUrl")
    .field("createdAt")
    .field("updatedAt")
    .field("visibility")
)

WIKI_PAGE_FRAGMENT = (
    fragment("WikiPageFields", "WikiPage")
    .field("id")
    .field("title")
    .field("slug")
    .field("webUrl")
    .field("createdAt")
    .field("updatedAt")
)


# ========== Project Queries ==========


def get_projects(
    limit: int = 100,
    visibility: str | None = None,
    archived: bool | None = None,
) -> Field | Query:
    """
    Get projects list.

    QUERY.PROJECTS

    Example:
        q = get_projects(visibility="private")
        async for project in gl.graphql.stream(
            str(q),
            connection_path=["projects"]
        ):
            print(project["name"], project["fullPath"])
    """
    q = (
        query("GetProjects")
        .arg("after", "$after", "String")
        .arg("first", "$first", "Int")
        .field("projects", args={"after": "$after", "first": "$first"})
        .field("pageInfo", fields=["hasNextPage", "endCursor"])
        .field(
            "nodes",
            fields=[
                "id",
                "name",
                "path",
                "fullPath",
                "description",
                "webUrl",
                "visibility",
                "archived",
                "createdAt",
            ],
        )
        .end()
    )

    return q


def get_blob_search() -> Field | Query:
    """
    Search blobs in projects.

    QUERY.BLOBSEARCH

    Example:
        q = get_blob_search()
        result = await gl.graphql.execute(str(q), variables={
            "fullPath": "group/project",
            "query": "TODO"
        })
    """
    return (
        query("GetBlobSearch")
        .arg("fullPath", "$fullPath", "ID!")
        .arg("query", "$query", "String!")
        .arg("after", "$after", "String")
        .arg("first", "$first", "Int")
        .field("project", args={"fullPath": "$fullPath"})
        .field(
            "blobSearch", args={"query": "$query", "after": "$after", "first": "$first"}
        )
        .field("pageInfo", fields=["hasNextPage", "endCursor"])
        .field("nodes", fields=["id", "name", "path", "data", "sha"])
        .end()
    )


# ========== Package Queries ==========


def get_package() -> Field | Query:
    """
    Get package details.

    QUERY.PACKAGE

    Example:
        q = get_package()
        result = await gl.graphql.execute(str(q), variables={
            "fullPath": "group/project",
            "packageId": "gid://gitlab/Package/123"
        })
    """
    return (
        query("GetPackage")
        .arg("fullPath", "$fullPath", "ID!")
        .arg("packageId", "$packageId", "ID!")
        .field("project", args={"fullPath": "$fullPath"})
        .field("package", args={"id": "$packageId"})
        .field("id")
        .field("name")
        .field("version")
        .field("packageType")
        .field("status")
        .field("webUrl")
        .field("createdAt")
        .field("updatedAt")
        .field("links")
        .field("nodes", fields=["url"])
        .end()
        .end()
    )


def get_packages(
    package_type: str | None = None,
    limit: int = 100,
) -> Field | Query:
    """
    Get packages for a project.

    Example:
        q = get_packages(package_type="npm")
        async for pkg in gl.graphql.stream(
            str(q),
            connection_path=["project", "packages"],
            variables={"fullPath": "group/project"}
        ):
            print(pkg["name"], pkg["version"])
    """
    q = (
        query("GetPackages")
        .arg("fullPath", "$fullPath", "ID!")
        .arg("after", "$after", "String")
        .arg("first", "$first", "Int")
        .field("project", args={"fullPath": "$fullPath"})
    )

    args = {"after": "$after", "first": "$first"}
    if package_type:
        args["packageType"] = package_type

    q.field("packages", args=args)
    q.field("pageInfo", fields=["hasNextPage", "endCursor"])
    q.field(
        "nodes",
        fields=[
            "id",
            "name",
            "version",
            "packageType",
            "status",
            "webUrl",
            "createdAt",
        ],
    )

    return q


# ========== Container Registry Queries ==========


def get_container_repository() -> Field | Query:
    """
    Get container repository details.

    QUERY.CONTAINERREPOSITORY

    Example:
        q = get_container_repository()
        result = await gl.graphql.execute(str(q), variables={
            "fullPath": "group/project",
            "repositoryId": "gid://gitlab/ContainerRepository/123"
        })
    """
    return (
        query("GetContainerRepository")
        .arg("fullPath", "$fullPath", "ID!")
        .arg("repositoryId", "$repositoryId", "ID!")
        .field("project", args={"fullPath": "$fullPath"})
        .field("containerRepository", args={"id": "$repositoryId"})
        .field("id")
        .field("name")
        .field("path")
        .field("tags")
        .field("createdAt")
        .field("updatedAt")
        .end()
    )


def get_container_repositories(limit: int = 100) -> Field | Query:
    """
    Get container repositories for a project.

    Example:
        q = get_container_repositories()
        async for repo in gl.graphql.stream(
            str(q),
            connection_path=["project", "containerRepositories"],
            variables={"fullPath": "group/project"}
        ):
            print(repo["name"], repo["path"])
    """
    return (
        query("GetContainerRepositories")
        .arg("fullPath", "$fullPath", "ID!")
        .arg("after", "$after", "String")
        .arg("first", "$first", "Int")
        .field("project", args={"fullPath": "$fullPath"})
        .field("containerRepositories", args={"after": "$after", "first": "$first"})
        .field("pageInfo", fields=["hasNextPage", "endCursor"])
        .field("nodes", fields=["id", "name", "path", "tags", "createdAt", "updatedAt"])
        .end()
    )


# ========== Virtual Registries Queries ==========


def get_virtual_registries_container_registry() -> Field | Query:
    """
    Get virtual registries container registry.

    QUERY.VIRTUALREGISTRIESCONTAINERREGISTRY

    Example:
        q = get_virtual_registries_container_registry()
        result = await gl.graphql.execute(str(q), variables={
            "fullPath": "group"
        })
    """
    return (
        query("GetVirtualRegistriesContainerRegistry")
        .arg("fullPath", "$fullPath", "ID!")
        .field("group", args={"fullPath": "$fullPath"})
        .field("virtualRegistriesContainerRegistry")
        .field("enabled")
        .field("upstreams")
        .field("nodes", fields=["name", "url"])
        .end()
        .end()
    )


def get_virtual_registries_container_upstream() -> Field | Query:
    """
    Get virtual registries container upstream.

    QUERY.VIRTUALREGISTRIESCONTAINERUPSTREAM

    Example:
        q = get_virtual_registries_container_upstream()
        result = await gl.graphql.execute(str(q), variables={
            "fullPath": "group",
            "upstreamId": "gid://gitlab/VirtualRegistryUpstream/123"
        })
    """
    return (
        query("GetVirtualRegistriesContainerUpstream")
        .arg("fullPath", "$fullPath", "ID!")
        .arg("upstreamId", "$upstreamId", "ID!")
        .field("group", args={"fullPath": "$fullPath"})
        .field("virtualRegistriesContainerUpstream", args={"id": "$upstreamId"})
        .field("id")
        .field("name")
        .field("url")
        .field("enabled")
        .end()
    )


def get_virtual_registries_packages_maven_registry() -> Field | Query:
    """
    Get virtual registries packages Maven registry.

    QUERY.VIRTUALREGISTRIESPACKAGESMAVENREGISTRY

    Example:
        q = get_virtual_registries_packages_maven_registry()
        result = await gl.graphql.execute(str(q), variables={
            "fullPath": "group"
        })
    """
    return (
        query("GetVirtualRegistriesPackagesMavenRegistry")
        .arg("fullPath", "$fullPath", "ID!")
        .field("group", args={"fullPath": "$fullPath"})
        .field("virtualRegistriesPackagesMavenRegistry")
        .field("enabled")
        .field("upstreams")
        .field("nodes", fields=["name", "url"])
        .end()
        .end()
    )


def get_virtual_registries_packages_maven_upstream() -> Field | Query:
    """
    Get virtual registries packages Maven upstream.

    QUERY.VIRTUALREGISTRIESPACKAGESMAVENUPSTREAM

    Example:
        q = get_virtual_registries_packages_maven_upstream()
        result = await gl.graphql.execute(str(q), variables={
            "fullPath": "group",
            "upstreamId": "gid://gitlab/VirtualRegistryUpstream/123"
        })
    """
    return (
        query("GetVirtualRegistriesPackagesMavenUpstream")
        .arg("fullPath", "$fullPath", "ID!")
        .arg("upstreamId", "$upstreamId", "ID!")
        .field("group", args={"fullPath": "$fullPath"})
        .field("virtualRegistriesPackagesMavenUpstream", args={"id": "$upstreamId"})
        .field("id")
        .field("name")
        .field("url")
        .field("enabled")
        .end()
    )


# ========== Design Management Queries ==========


def get_design_management() -> Field | Query:
    """
    Get design management for an issue.

    QUERY.DESIGNMANAGEMENT

    Example:
        q = get_design_management()
        result = await gl.graphql.execute(str(q), variables={
            "fullPath": "group/project",
            "issueIid": 1
        })
    """
    return (
        query("GetDesignManagement")
        .arg("fullPath", "$fullPath", "ID!")
        .arg("issueIid", "$issueIid", "Int!")
        .field("project", args={"fullPath": "$fullPath"})
        .field("issue", args={"iid": "$issueIid"})
        .field("designs")
        .field("nodes", fields=["id", "filename", "path", "webUrl", "createdAt"])
        .end()
        .end()
    )


# ========== Snippet Queries ==========


def get_snippets(limit: int = 100) -> Field | Query:
    """
    Get snippets.

    QUERY.SNIPPETS

    Example:
        q = get_snippets()
        async for snippet in gl.graphql.stream(
            str(q),
            connection_path=["snippets"]
        ):
            print(snippet["title"], snippet["webUrl"])
    """
    return (
        query("GetSnippets")
        .arg("after", "$after", "String")
        .arg("first", "$first", "Int")
        .field("snippets", args={"after": "$after", "first": "$first"})
        .field("pageInfo", fields=["hasNextPage", "endCursor"])
        .field(
            "nodes",
            fields=["id", "title", "description", "webUrl", "visibility", "createdAt"],
        )
        .end()
    )


# ========== Wiki Queries ==========


def get_wiki_page() -> Field | Query:
    """
    Get wiki page.

    QUERY.WIKIPAGE

    Example:
        q = get_wiki_page()
        result = await gl.graphql.execute(str(q), variables={
            "fullPath": "group/project",
            "slug": "home"
        })
    """
    return (
        query("GetWikiPage")
        .arg("fullPath", "$fullPath", "ID!")
        .arg("slug", "$slug", "String!")
        .field("project", args={"fullPath": "$fullPath"})
        .field("wikiPage", args={"slug": "$slug"})
        .field("id")
        .field("title")
        .field("slug")
        .field("content")
        .field("webUrl")
        .field("createdAt")
        .field("updatedAt")
        .end()
    )


def get_wiki_pages(limit: int = 100) -> Field | Query:
    """
    Get wiki pages for a project.

    Example:
        q = get_wiki_pages()
        async for page in gl.graphql.stream(
            str(q),
            connection_path=["project", "wikiPages"],
            variables={"fullPath": "group/project"}
        ):
            print(page["title"])
    """
    return (
        query("GetWikiPages")
        .arg("fullPath", "$fullPath", "ID!")
        .arg("after", "$after", "String")
        .arg("first", "$first", "Int")
        .field("project", args={"fullPath": "$fullPath"})
        .field("wikiPages", args={"after": "$after", "first": "$first"})
        .field("pageInfo", fields=["hasNextPage", "endCursor"])
        .field("nodes", fields=["id", "title", "slug", "webUrl", "createdAt"])
        .end()
    )


# ========== Custom Dashboard Queries ==========


def get_custom_dashboard() -> Field | Query:
    """
    Get custom dashboard.

    QUERY.CUSTOMDASHBOARD

    Example:
        q = get_custom_dashboard()
        result = await gl.graphql.execute(str(q), variables={
            "fullPath": "group/project",
            "dashboardId": "gid://gitlab/CustomDashboard/123"
        })
    """
    return (
        query("GetCustomDashboard")
        .arg("fullPath", "$fullPath", "ID!")
        .arg("dashboardId", "$dashboardId", "ID!")
        .field("project", args={"fullPath": "$fullPath"})
        .field("customDashboard", args={"id": "$dashboardId"})
        .field("id")
        .field("name")
        .field("description")
        .field("widgets")
        .field("nodes", fields=["type", "config"])
        .end()
        .end()
    )


def get_custom_dashboards(limit: int = 100) -> Field | Query:
    """
    Get custom dashboards for a project.

    QUERY.CUSTOMDASHBOARDS

    Example:
        q = get_custom_dashboards()
        async for dashboard in gl.graphql.stream(
            str(q),
            connection_path=["project", "customDashboards"],
            variables={"fullPath": "group/project"}
        ):
            print(dashboard["name"])
    """
    return (
        query("GetCustomDashboards")
        .arg("fullPath", "$fullPath", "ID!")
        .arg("after", "$after", "String")
        .arg("first", "$first", "Int")
        .field("project", args={"fullPath": "$fullPath"})
        .field("customDashboards", args={"after": "$after", "first": "$first"})
        .field("pageInfo", fields=["hasNextPage", "endCursor"])
        .field("nodes", fields=["id", "name", "description", "createdAt"])
        .end()
    )


# ========== Google Cloud Artifact Registry Queries ==========


def get_google_cloud_artifact_registry_repository_artifact() -> Field | Query:
    """
    Get Google Cloud Artifact Registry repository artifact.

    QUERY.GOOGLECLOUDARTIFACTREGISTRYREPOSITORYARTIFACT

    Example:
        q = get_google_cloud_artifact_registry_repository_artifact()
        result = await gl.graphql.execute(str(q), variables={
            "fullPath": "group/project",
            "artifactId": "gid://gitlab/GcpArtifact/123"
        })
    """
    return (
        query("GetGoogleCloudArtifactRegistryRepositoryArtifact")
        .arg("fullPath", "$fullPath", "ID!")
        .arg("artifactId", "$artifactId", "ID!")
        .field("project", args={"fullPath": "$fullPath"})
        .field(
            "googleCloudArtifactRegistryRepositoryArtifact", args={"id": "$artifactId"}
        )
        .field("id")
        .field("name")
        .field("version")
        .field("repository")
        .end()
    )


# ========== Topics Queries ==========


def get_topics(limit: int = 100) -> Field | Query:
    """
    Get topics.

    QUERY.TOPICS

    Example:
        q = get_topics()
        async for topic in gl.graphql.stream(
            str(q),
            connection_path=["topics"]
        ):
            print(topic["name"], topic["description"])
    """
    return (
        query("GetTopics")
        .arg("after", "$after", "String")
        .arg("first", "$first", "Int")
        .field("topics", args={"after": "$after", "first": "$first"})
        .field("pageInfo", fields=["hasNextPage", "endCursor"])
        .field("nodes", fields=["id", "name", "description", "webUrl", "avatarUrl"])
        .end()
    )


# ========== Export Constants ==========

GET_PROJECTS = str(get_projects())
GET_BLOB_SEARCH = str(get_blob_search())
GET_PACKAGE = str(get_package())
GET_PACKAGES = str(get_packages())
GET_CONTAINER_REPOSITORY = str(get_container_repository())
GET_CONTAINER_REPOSITORIES = str(get_container_repositories())
GET_VIRTUAL_REGISTRIES_CONTAINER_REGISTRY = str(
    get_virtual_registries_container_registry()
)
GET_VIRTUAL_REGISTRIES_CONTAINER_UPSTREAM = str(
    get_virtual_registries_container_upstream()
)
GET_VIRTUAL_REGISTRIES_PACKAGES_MAVEN_REGISTRY = str(
    get_virtual_registries_packages_maven_registry()
)
GET_VIRTUAL_REGISTRIES_PACKAGES_MAVEN_UPSTREAM = str(
    get_virtual_registries_packages_maven_upstream()
)
GET_DESIGN_MANAGEMENT = str(get_design_management())
GET_SNIPPETS = str(get_snippets())
GET_WIKI_PAGE = str(get_wiki_page())
GET_WIKI_PAGES = str(get_wiki_pages())
GET_CUSTOM_DASHBOARD = str(get_custom_dashboard())
GET_CUSTOM_DASHBOARDS = str(get_custom_dashboards())
GET_GOOGLE_CLOUD_ARTIFACT_REGISTRY_REPOSITORY_ARTIFACT = str(
    get_google_cloud_artifact_registry_repository_artifact()
)
GET_TOPICS = str(get_topics())
