"""
GraphQL Query Complexity Analysis

Analyzes GraphQL queries to estimate their complexity and cost.
"""

from __future__ import annotations

import functools
import re
from collections.abc import Callable
from dataclasses import dataclass
from typing import Any


@dataclass
class ComplexityResult:
    """Query complexity analysis result."""

    query: str
    score: int
    estimated_cost: int
    field_count: int
    depth: int
    breadth: int
    warnings: list[str]
    recommendations: list[str]


class QueryComplexityAnalyzer:
    """
    Analyze GraphQL query complexity.

    GitLab GraphQL API uses a point-based system where different fields
    have different costs. This analyzer estimates query complexity.

    Example:
        analyzer = QueryComplexityAnalyzer()
        result = analyzer.analyze(query_string)
        print(f"Complexity score: {result.score}")
        print(f"Warnings: {result.warnings}")
    """

    # Default field costs (GitLab-like)
    DEFAULT_COSTS = {
        "scalar": 1,  # id, name, etc.
        "object": 5,  # nested objects
        "connection": 10,  # connections (lists with pageInfo)
        "expensive": 20,  # expensive fields (repositorySize, etc.)
    }

    # Expensive fields that cost more
    EXPENSIVE_FIELDS = {
        "repositorySize",
        "packagesCount",
        "repository",
        "commits",
        "blobs",
        "diff",
        "snippets",
        "issues",
        "mergeRequests",
    }

    # Maximum recommended values
    MAX_DEPTH = 10
    MAX_BREADTH = 20
    MAX_SCORE = 1000

    # Pre-compiled regex patterns — avoid recompilation on every analyze() call
    _COMMENT_RE = re.compile(r"#.*$", re.MULTILINE)
    _FIELD_BLOCK_RE = re.compile(r"(\w+)\s*(?:\([^)]*\))?\s*\{")
    _SCALAR_RE = re.compile(r"^\s*(\w+)\s*$")
    _WORD_RE = re.compile(r"\b(\w+)\b")
    _EXPENSIVE_RE = re.compile(
        r"\b(?:repositorySize|packagesCount|repository|commits|blobs|diff|snippets|issues|mergeRequests)\b"
    )

    @functools.lru_cache(maxsize=256)
    def analyze(self, query: str) -> ComplexityResult:
        """
        Analyze query complexity.

        Args:
            query: GraphQL query string

        Returns:
            ComplexityResult with score and recommendations
        """
        # Remove comments
        query = self._remove_comments(query)

        # Calculate metrics
        depth = self._calculate_depth(query)
        breadth = self._calculate_breadth(query)
        field_count = self._count_fields(query)
        score = self._calculate_score(query, depth, breadth)

        # Estimate cost
        estimated_cost = score * 10  # Rough estimate

        # Generate warnings and recommendations
        warnings = []
        recommendations = []

        if depth > self.MAX_DEPTH:
            warnings.append(
                f"Query depth ({depth}) exceeds recommended maximum ({self.MAX_DEPTH})"
            )
            recommendations.append("Consider flattening the query structure")

        if breadth > self.MAX_BREADTH:
            warnings.append(
                f"Query breadth ({breadth}) exceeds recommended maximum ({self.MAX_BREADTH})"
            )
            recommendations.append("Consider splitting into multiple queries")

        if score > self.MAX_SCORE:
            warnings.append(
                f"Complexity score ({score}) exceeds recommended maximum ({self.MAX_SCORE})"
            )
            recommendations.append("Consider using fragments or splitting the query")

        expensive_fields = self._find_expensive_fields(query)
        if expensive_fields:
            warnings.append(
                f"Contains {len(expensive_fields)} expensive field(s): {', '.join(expensive_fields)}"
            )
            recommendations.append("Consider caching results for expensive fields")

        return ComplexityResult(
            query=query,
            score=score,
            estimated_cost=estimated_cost,
            field_count=field_count,
            depth=depth,
            breadth=breadth,
            warnings=warnings,
            recommendations=recommendations,
        )

    def _remove_comments(self, query: str) -> str:
        """Remove GraphQL comments."""
        return self._COMMENT_RE.sub("", query)

    def _calculate_depth(self, query: str) -> int:
        """Calculate maximum nesting depth."""
        max_depth = 0
        current_depth = 0

        for char in query:
            if char == "{":
                current_depth += 1
                max_depth = max(max_depth, current_depth)
            elif char == "}":
                current_depth -= 1

        return max_depth

    def _calculate_breadth(self, query: str) -> int:
        """Calculate maximum breadth (fields at any level)."""
        # Find all field names
        matches = self._FIELD_BLOCK_RE.findall(query)

        # Also count scalar fields
        for line in query.split("\n"):
            match = self._SCALAR_RE.match(line.strip())
            if match and match.group(1) not in ("query", "mutation", "fragment"):
                matches.append(match.group(1))

        return len(matches)

    def _count_fields(self, query: str) -> int:
        """Count total number of fields."""
        # Count all field references
        matches = self._WORD_RE.findall(query)

        # Filter out GraphQL keywords
        keywords = {
            "query",
            "mutation",
            "subscription",
            "fragment",
            "on",
            "true",
            "false",
            "null",
        }
        fields = [m for m in matches if m.lower() not in keywords]

        return len(fields)

    def _calculate_score(self, query: str, depth: int, breadth: int) -> int:
        """Calculate complexity score."""
        base_score = 0

        # Add score for each field
        fields = self._WORD_RE.findall(query)

        for field in fields:
            if field in self.EXPENSIVE_FIELDS:
                base_score += self.DEFAULT_COSTS["expensive"]
            elif field[0].isupper():
                base_score += self.DEFAULT_COSTS["object"]
            else:
                base_score += self.DEFAULT_COSTS["scalar"]

        # Add multiplier for depth
        depth_multiplier = 1 + (depth * 0.5)

        # Add multiplier for breadth
        breadth_multiplier = 1 + (breadth * 0.1)

        score = int(base_score * depth_multiplier * breadth_multiplier)
        return score

    def _find_expensive_fields(self, query: str) -> list[str]:
        """Find expensive fields in query."""
        # Single regex pass instead of 10 separate re.search calls
        found_matches = set(self._EXPENSIVE_RE.findall(query))
        return [f for f in self.EXPENSIVE_FIELDS if f in found_matches]

    def is_acceptable(
        self, result: ComplexityResult, max_score: int | None = None
    ) -> bool:
        """Check if query complexity is acceptable."""
        if max_score is None:
            max_score = self.MAX_SCORE
        return result.score <= max_score and not result.warnings


class ComplexityAwareClient:
    """
    Mixin for GraphQL client with complexity awareness.

    Adds complexity checking before query execution.
    """

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self._complexity_analyzer = QueryComplexityAnalyzer()
        self._max_complexity: int | None = None
        self._complexity_callback: Callable[..., Any] | None = None

    async def execute(self, query: str, variables: dict | None = None) -> dict:
        """Override in subclass."""
        raise NotImplementedError

    def configure_complexity(
        self,
        max_score: int | None = 1000,
        callback: Callable[..., Any] | None = None,
    ) -> None:
        """
        Configure complexity checking.

        Args:
            max_score: Maximum acceptable complexity score (None to disable)
            callback: Callback for complexity analysis results
        """
        self._max_complexity = max_score
        self._complexity_callback = callback

    async def execute_with_complexity_check(
        self,
        query: str,
        variables: dict | None = None,
    ) -> dict:
        """
        Execute query with complexity checking.

        Args:
            query: GraphQL query string
            variables: Query variables

        Returns:
            Query result

        Raises:
            ValueError: If query complexity exceeds maximum
        """
        # Analyze complexity
        result = self._complexity_analyzer.analyze(query)

        # Call callback if provided
        if self._complexity_callback:
            self._complexity_callback(result)

        # Check if acceptable
        if self._max_complexity and result.score > self._max_complexity:
            raise ValueError(
                f"Query complexity ({result.score}) exceeds maximum "
                f"allowed ({self._max_complexity}). "
                f"Recommendations: {', '.join(result.recommendations)}"
            )

        # Log warnings
        if result.warnings:
            import logging

            logger = logging.getLogger(__name__)
            for warning in result.warnings:
                logger.warning(f"Query complexity warning: {warning}")

        # Execute query (call parent execute method)
        return await self.execute(query, variables)
