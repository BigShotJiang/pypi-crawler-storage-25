"""
GraphQL Result Caching

Provides LRU caching for GraphQL query results with configurable TTL.
"""

from __future__ import annotations

import hashlib
import time
from collections import OrderedDict
from dataclasses import dataclass
from enum import Enum
from typing import Any

import msgspec


class CachePolicy(Enum):
    """Cache policy for query execution."""

    CACHE_FIRST = "cache_first"  # Use cache if available, else network
    NETWORK_FIRST = "network_first"  # Use network, fallback to cache on error
    CACHE_ONLY = "cache_only"  # Use cache only, error if not found
    NETWORK_ONLY = "network_only"  # Always use network, don't cache
    CACHE_AND_NETWORK = "cache_and_network"  # Return cache immediately, then update


@dataclass
class CacheEntry:
    """Cached query result."""

    data: dict[str, Any]
    timestamp: float
    ttl: int
    query_hash: str

    def is_expired(self) -> bool:
        """Check if entry is expired."""
        return time.time() - self.timestamp > self.ttl


@dataclass
class CacheStats:
    """Cache statistics."""

    hits: int = 0
    misses: int = 0
    evictions: int = 0
    size: int = 0
    max_size: int = 0

    @property
    def hit_rate(self) -> float:
        """Calculate cache hit rate."""
        total = self.hits + self.misses
        if total == 0:
            return 0.0
        return self.hits / total


class GraphQLCache:
    """
    LRU cache for GraphQL query results.

    Example:
        cache = GraphQLCache(max_size=1000, default_ttl=300)

        # Store result
        cache.set(query_hash, result, ttl=300)

        # Get result
        result = cache.get(query_hash)

        # Get stats
        stats = cache.stats()
    """

    def __init__(
        self,
        max_size: int = 1000,
        default_ttl: int = 300,
        enabled: bool = True,
    ) -> None:
        """
        Initialize cache.

        Args:
            max_size: Maximum number of entries
            default_ttl: Default time-to-live in seconds
            enabled: Whether caching is enabled
        """
        self._cache: OrderedDict[str, CacheEntry] = OrderedDict()
        self._max_size = max_size
        self._default_ttl = default_ttl
        self._enabled = enabled
        self._stats = CacheStats(max_size=max_size)

    def _compute_hash(self, query: str, variables: dict[str, Any] | None) -> str:
        """Compute cache key from query and variables."""
        # msgspec.encode is ~3x faster than json.dumps; blake2b is ~3x faster than SHA-256
        key_bytes = msgspec.json.encode({"query": query, "variables": variables or {}})
        return hashlib.blake2b(key_bytes, digest_size=16).hexdigest()

    def get(
        self,
        query: str,
        variables: dict[str, Any] | None = None,
    ) -> dict[str, Any] | None:
        """
        Get cached result.

        Args:
            query: GraphQL query string
            variables: Query variables

        Returns:
            Cached result or None if not found/expired
        """
        if not self._enabled:
            self._stats.misses += 1
            return None

        key = self._compute_hash(query, variables)

        if key not in self._cache:
            self._stats.misses += 1
            return None

        entry = self._cache[key]

        # Check expiration
        if entry.is_expired():
            self._cache.pop(key)
            self._stats.evictions += 1
            self._stats.misses += 1
            return None

        # Move to end (most recently used)
        self._cache.move_to_end(key)
        self._stats.hits += 1
        return entry.data

    def set(
        self,
        query: str,
        data: dict[str, Any],
        variables: dict[str, Any] | None = None,
        ttl: int | None = None,
    ) -> None:
        """
        Cache result.

        Args:
            query: GraphQL query string
            data: Result data to cache
            variables: Query variables
            ttl: Time-to-live in seconds (uses default if None)
        """
        if not self._enabled:
            return

        key = self._compute_hash(query, variables)
        entry = CacheEntry(
            data=data,
            timestamp=time.time(),
            ttl=ttl or self._default_ttl,
            query_hash=key,
        )

        # Evict oldest if at capacity
        if len(self._cache) >= self._max_size:
            self._cache.popitem(last=False)
            self._stats.evictions += 1

        self._cache[key] = entry
        self._stats.size = len(self._cache)

    def delete(
        self,
        query: str,
        variables: dict[str, Any] | None = None,
    ) -> bool:
        """
        Delete cached result.

        Args:
            query: GraphQL query string
            variables: Query variables

        Returns:
            True if deleted, False if not found
        """
        key = self._compute_hash(query, variables)
        if key in self._cache:
            self._cache.pop(key)
            self._stats.size = len(self._cache)
            return True
        return False

    def clear(self) -> None:
        """Clear all cached results."""
        self._cache.clear()
        self._stats.size = 0
        self._stats.evictions += len(self._cache)

    def stats(self) -> CacheStats:
        """Get cache statistics."""
        self._stats.size = len(self._cache)
        return self._stats

    def configure(
        self,
        max_size: int | None = None,
        default_ttl: int | None = None,
        enabled: bool | None = None,
    ) -> None:
        """
        Configure cache settings.

        Args:
            max_size: New maximum size
            default_ttl: New default TTL
            enabled: Enable/disable caching
        """
        if max_size is not None:
            self._max_size = max_size
            self._stats.max_size = max_size
            # Evict if necessary
            while len(self._cache) > self._max_size:
                self._cache.popitem(last=False)
                self._stats.evictions += 1

        if default_ttl is not None:
            self._default_ttl = default_ttl

        if enabled is not None:
            self._enabled = enabled

    def keys(self) -> list[str]:
        """Get all cache keys."""
        return list(self._cache.keys())

    def values(self) -> list[dict[str, Any]]:
        """Get all cached values."""
        return [entry.data for entry in self._cache.values()]

    def items(self) -> list[tuple[str, CacheEntry]]:
        """Get all cache entries."""
        return list(self._cache.items())
