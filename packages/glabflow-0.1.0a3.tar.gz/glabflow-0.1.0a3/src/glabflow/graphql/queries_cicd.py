"""
CI/CD & Runners GraphQL Queries

Coverage: All 17 CI/CD & Runners QUERY.* endpoints
"""

from glabflow.graphql.builder import Field, Query, fragment, query

# ========== Fragments ==========

PIPELINE_FRAGMENT = (
    fragment("PipelineFields", "Pipeline")
    .field("id")
    .field("iid")
    .field("status")
    .field("ref")
    .field("sha")
    .field("webUrl")
    .field("createdAt")
    .field("updatedAt")
    .field("startedAt")
    .field("finishedAt")
    .field("duration")
    .field("queuedDuration")
)

JOB_FRAGMENT = (
    fragment("JobFields", "Job")
    .field("id")
    .field("name")
    .field("status")
    .field("stage")
    .field("webUrl")
    .field("createdAt")
    .field("startedAt")
    .field("finishedAt")
    .field("duration")
)

RUNNER_FRAGMENT = (
    fragment("RunnerFields", "Runner")
    .field("id")
    .field("name")
    .field("status")
    .field("runnerType")
    .field("description")
    .field("ipAddress")
    .field("version")
    .field("platform")
    .field("architecture")
    .field("isShared")
    .field("contactedAt")
)

CI_VARIABLE_FRAGMENT = (
    fragment("CIVariableFields", "CiVariable")
    .field("key")
    .field("value")
    .field("variableType")
    .field("protected")
    .field("masked")
    .field("raw")
    .field("environmentScope")
)


# ========== Pipeline Queries ==========


def get_pipeline_stage() -> Field | Query:
    """
    Get CI pipeline stage details.

    QUERY.CIPIPELINESTAGE

    Example:
        q = get_pipeline_stage()
        result = await gl.graphql.execute(str(q), variables={
            "fullPath": "group/project",
            "iid": 1
        })
    """
    return (
        query("GetPipelineStage")
        .arg("fullPath", "$fullPath", "ID!")
        .arg("iid", "$iid", "Int!")
        .field("project", args={"fullPath": "$fullPath"})
        .field("pipeline", args={"iid": "$iid"})
        .field("id")
        .field("iid")
        .field("status")
        .field("stages")
        .field(
            "nodes",
            fields=["id", "name", "status", "createdAt", "startedAt", "finishedAt"],
        )
        .end()
        .end()
    )


def get_pipelines(
    state: str = "running",
    limit: int = 100,
) -> Field | Query:
    """
    Get pipelines for a project.

    Example:
        q = get_pipelines(state="success", limit=50)
        async for pipeline in gl.graphql.stream(
            str(q),
            connection_path=["project", "pipelines"],
            variables={"fullPath": "group/project"}
        ):
            print(pipeline["status"])
    """
    return (
        query("GetPipelines")
        .arg("fullPath", "$fullPath", "ID!")
        .arg("after", "$after", "String")
        .arg("first", "$first", "Int")
        .field("project", args={"fullPath": "$fullPath"})
        .field(
            "pipelines", args={"after": "$after", "first": "$first", "status": state}
        )
        .field("pageInfo", fields=["hasNextPage", "endCursor"])
        .field(
            "nodes", fields=["id", "iid", "status", "ref", "sha", "webUrl", "createdAt"]
        )
        .end()
    )


def get_pipeline_details() -> Field | Query:
    """
    Get detailed pipeline information.

    Example:
        q = get_pipeline_details()
        result = await gl.graphql.execute(str(q), variables={
            "fullPath": "group/project",
            "iid": 1
        })
    """
    return (
        query("GetPipelineDetails")
        .arg("fullPath", "$fullPath", "ID!")
        .arg("iid", "$iid", "Int!")
        .field("project", args={"fullPath": "$fullPath"})
        .field("pipeline", args={"iid": "$iid"})
        .field("id")
        .field("iid")
        .field("status")
        .field("ref")
        .field("sha")
        .field("webUrl")
        .field("createdAt")
        .field("updatedAt")
        .field("startedAt")
        .field("finishedAt")
        .field("duration")
        .field("queuedDuration")
        .field("source")
        .field("yamlErrors")
        .field("user", fields=["id", "username", "name"])
        .field("jobs", args={"first": "100"})
        .field("nodes", fields=["id", "name", "status", "stage", "webUrl", "createdAt"])
        .end()
        .end()
    )


# ========== Job Queries ==========


def get_jobs(
    scope: list[str] | None = None,
    limit: int = 100,
) -> Field | Query:
    """
    Get CI jobs for a project.

    QUERY.JOBS

    Example:
        q = get_jobs(scope=["success", "failed"])
        async for job in gl.graphql.stream(
            str(q),
            connection_path=["project", "jobs"],
            variables={"fullPath": "group/project"}
        ):
            print(job["name"], job["status"])
    """
    if scope:
        scope_items = [f'"{s}"' for s in scope]
        scope_filter = "[" + ", ".join(scope_items) + "]"
    else:
        scope_filter = None

    q = (
        query("GetJobs")
        .arg("fullPath", "$fullPath", "ID!")
        .arg("after", "$after", "String")
        .arg("first", "$first", "Int")
        .field("project", args={"fullPath": "$fullPath"})
    )

    args = {"after": "$after", "first": "$first"}
    if scope_filter:
        args["scope"] = scope_filter

    q.field("jobs", args=args)
    q.field("pageInfo", fields=["hasNextPage", "endCursor"])
    q.field(
        "nodes",
        fields=[
            "id",
            "name",
            "status",
            "stage",
            "webUrl",
            "createdAt",
            "startedAt",
            "finishedAt",
            "duration",
        ],
    )

    return q


def get_job_details() -> Field | Query:
    """
    Get detailed job information.

    Example:
        q = get_job_details()
        result = await gl.graphql.execute(str(q), variables={
            "fullPath": "group/project",
            "jobId": "gid://gitlab/CiJob/123"
        })
    """
    return (
        query("GetJobDetails")
        .arg("fullPath", "$fullPath", "ID!")
        .arg("jobId", "$jobId", "ID!")
        .field("project", args={"fullPath": "$fullPath"})
        .field("job", args={"id": "$jobId"})
        .field("id")
        .field("name")
        .field("status")
        .field("stage")
        .field("webUrl")
        .field("createdAt")
        .field("startedAt")
        .field("finishedAt")
        .field("duration")
        .field("failureReason")
        .field("allowFailure")
        .field("runner", fields=["id", "name", "status"])
        .field("user", fields=["id", "username", "name"])
        .field("pipeline", fields=["id", "iid", "status"])
        .end()
    )


# ========== Runner Queries ==========


def get_runners(
    status: str = "online",
    limit: int = 100,
) -> Field | Query:
    """
    Get CI runners.

    QUERY.RUNNERS

    Example:
        q = get_runners(status="online")
        async for runner in gl.graphql.stream(
            str(q),
            connection_path=["runners"],
            variables={}
        ):
            print(runner["name"], runner["status"])
    """
    return (
        query("GetRunners")
        .arg("after", "$after", "String")
        .arg("first", "$first", "Int")
        .field(
            "runners",
            args={
                "after": "$after",
                "first": "$first",
                "status": status,
            },
        )
        .field("pageInfo", fields=["hasNextPage", "endCursor"])
        .field(
            "nodes",
            fields=[
                "id",
                "name",
                "status",
                "runnerType",
                "description",
                "ipAddress",
                "version",
                "platform",
                "architecture",
                "isShared",
                "contactedAt",
            ],
        )
        .end()
    )


def get_runner() -> Field | Query:
    """
    Get specific runner details.

    QUERY.RUNNER

    Example:
        q = get_runner()
        result = await gl.graphql.execute(str(q), variables={
            "runnerId": "gid://gitlab/CiRunner/123"
        })
    """
    return (
        query("GetRunner")
        .arg("runnerId", "$runnerId", "ID!")
        .field("runner", args={"id": "$runnerId"})
        .field("id")
        .field("name")
        .field("status")
        .field("runnerType")
        .field("description")
        .field("ipAddress")
        .field("version")
        .field("platform")
        .field("architecture")
        .field("isShared")
        .field("contactedAt")
        .field("tagList")
        .field("nodes", fields=["name"])
        .end()
        .field("projects", args={"first": "20"})
        .field("nodes", fields=["id", "name", "fullPath"])
        .end()
        .end()
    )


def get_runner_usage() -> Field | Query:
    """
    Get runner usage statistics.

    QUERY.RUNNERUSAGE

    Example:
        q = get_runner_usage()
        result = await gl.graphql.execute(str(q), variables={
            "runnerId": "gid://gitlab/CiRunner/123"
        })
    """
    return (
        query("GetRunnerUsage")
        .arg("runnerId", "$runnerId", "ID!")
        .field("runner", args={"id": "$runnerId"})
        .field("id")
        .field("name")
        .field(
            "jobStatistics",
            fields=[
                "totalJobs",
                "successfulJobs",
                "failedJobs",
                "totalDuration",
                "averageDuration",
            ],
        )
        .end()
    )


def get_runner_usage_by_project() -> Field | Query:
    """
    Get runner usage by project.

    QUERY.RUNNERUSAGEBYPROJECT

    Example:
        q = get_runner_usage_by_project()
        result = await gl.graphql.execute(str(q), variables={
            "runnerId": "gid://gitlab/CiRunner/123"
        })
    """
    return (
        query("GetRunnerUsageByProject")
        .arg("runnerId", "$runnerId", "ID!")
        .field("runner", args={"id": "$runnerId"})
        .field("id")
        .field("name")
        .field(
            "projectStatistics",
            fields=["totalProjects", "activeProjects", "jobsByProject"],
        )
        .end()
    )


def get_ci_dedicated_hosted_runner_filters() -> Field | Query:
    """
    Get CI dedicated hosted runner filters.

    QUERY.CIDEDICATEDHOSTEDRUNNERFILTERS

    Example:
        q = get_ci_dedicated_hosted_runner_filters()
        result = await gl.graphql.execute(str(q), variables={
            "fullPath": "group/project"
        })
    """
    return (
        query("GetCIDedicatedHostedRunnerFilters")
        .arg("fullPath", "$fullPath", "ID!")
        .field("project", args={"fullPath": "$fullPath"})
        .field("ciDedicatedHostedRunnerFilters")
        .field("nodes", fields=["id", "name", "filterType", "pattern", "isActive"])
        .end()
    )


def get_ci_dedicated_hosted_runner_usage() -> Field | Query:
    """
    Get CI dedicated hosted runner usage.

    QUERY.CIDEDICATEDHOSTEDRUNNERUSAGE

    Example:
        q = get_ci_dedicated_hosted_runner_usage()
        result = await gl.graphql.execute(str(q), variables={
            "fullPath": "group/project"
        })
    """
    return (
        query("GetCIDedicatedHostedRunnerUsage")
        .arg("fullPath", "$fullPath", "ID!")
        .field("project", args={"fullPath": "$fullPath"})
        .field("ciDedicatedHostedRunnerUsage")
        .field("totalJobs")
        .field("totalDuration")
        .field("monthlyUsage")
        .end()
    )


# ========== CI Configuration Queries ==========


def get_ci_config() -> Field | Query:
    """
    Get CI configuration.

    QUERY.CICONFIG (Deprecated but still available)

    Example:
        q = get_ci_config()
        result = await gl.graphql.execute(str(q), variables={
            "fullPath": "group/project"
        })
    """
    return (
        query("GetCIConfig")
        .arg("fullPath", "$fullPath", "ID!")
        .field("project", args={"fullPath": "$fullPath"})
        .field("ciConfig")
        .field("content")
        .field(
            "variables", fields=["key", "value", "variableType", "protected", "masked"]
        )
        .end()
    )


def get_ci_variables() -> Field | Query:
    """
    Get CI variables.

    QUERY.CIVARIABLES

    Example:
        q = get_ci_variables()
        result = await gl.graphql.execute(str(q), variables={
            "fullPath": "group/project"
        })
    """
    return (
        query("GetCIVariables")
        .arg("fullPath", "$fullPath", "ID!")
        .field("project", args={"fullPath": "$fullPath"})
        .field("ciVariables")
        .field(
            "nodes",
            fields=[
                "key",
                "value",
                "variableType",
                "protected",
                "masked",
                "raw",
                "environmentScope",
            ],
        )
        .end()
    )


def get_ci_minutes_usage() -> Field | Query:
    """
    Get CI minutes usage.

    QUERY.CIMINUTESUSAGE

    Example:
        q = get_ci_minutes_usage()
        result = await gl.graphql.execute(str(q), variables={
            "fullPath": "group"
        })
    """
    return (
        query("GetCIMinutesUsage")
        .arg("fullPath", "$fullPath", "ID!")
        .field("group", args={"fullPath": "$fullPath"})
        .field("ciMinutesUsage")
        .field("totalMinutes")
        .field("includedMinutes")
        .field("extraMinutes")
        .field("monthlyLimit")
        .field(
            "usageBreakdown", fields=["sharedRunners", "groupRunners", "projectRunners"]
        )
        .end()
    )


def get_ci_application_settings() -> Field | Query:
    """
    Get CI application settings.

    QUERY.CIAPPLICATIONSETTINGS

    Example:
        q = get_ci_application_settings()
        result = await gl.graphql.execute(str(q))
    """
    return (
        query("GetCIApplicationSettings")
        .field("ciApplicationSettings")
        .field("defaultArtifactsExpireIn")
        .field("defaultPipelineTimeout")
        .field("maxArtifactsSize")
        .field("maxPipelineTimeout")
        .field("autoDevopsEnabled")
        .end()
    )


def get_ci_queueing_history() -> Field | Query:
    """
    Get CI queueing history.

    QUERY.CIQUEUEINGHISTORY

    Example:
        q = get_ci_queueing_history()
        result = await gl.graphql.execute(str(q), variables={
            "fullPath": "group/project"
        })
    """
    return (
        query("GetCIQueueingHistory")
        .arg("fullPath", "$fullPath", "ID!")
        .field("project", args={"fullPath": "$fullPath"})
        .field("ciQueueingHistory")
        .field("nodes", fields=["timestamp", "queueDuration", "jobCount"])
        .end()
    )


# ========== CI Catalog Queries ==========


def get_ci_catalog_resource() -> Field | Query:
    """
    Get CI catalog resource.

    QUERY.CICATALOGRESOURCE

    Example:
        q = get_ci_catalog_resource()
        result = await gl.graphql.execute(str(q), variables={
            "fullPath": "group/component"
        })
    """
    return (
        query("GetCICatalogResource")
        .arg("fullPath", "$fullPath", "ID!")
        .field("ciCatalogResource", args={"fullPath": "$fullPath"})
        .field("id")
        .field("name")
        .field("description")
        .field("version")
        .field("status")
        .field("icon")
        .end()
    )


def get_ci_catalog_resources(
    limit: int = 100,
) -> Field | Query:
    """
    Get CI catalog resources.

    QUERY.CICATALOGRESOURCES

    Example:
        q = get_ci_catalog_resources()
        async for resource in gl.graphql.stream(
            str(q),
            connection_path=["ciCatalogResources"]
        ):
            print(resource["name"])
    """
    return (
        query("GetCICatalogResources")
        .arg("after", "$after", "String")
        .arg("first", "$first", "Int")
        .field("ciCatalogResources", args={"after": "$after", "first": "$first"})
        .field("pageInfo", fields=["hasNextPage", "endCursor"])
        .field(
            "nodes", fields=["id", "name", "description", "version", "status", "icon"]
        )
        .end()
    )


# ========== Export Constants ==========

GET_PIPELINE_STAGE = str(get_pipeline_stage())
GET_PIPELINES = str(get_pipelines())
GET_PIPELINE_DETAILS = str(get_pipeline_details())
GET_JOBS = str(get_jobs())
GET_JOB_DETAILS = str(get_job_details())
GET_RUNNERS = str(get_runners())
GET_RUNNER = str(get_runner())
GET_RUNNER_USAGE = str(get_runner_usage())
GET_RUNNER_USAGE_BY_PROJECT = str(get_runner_usage_by_project())
GET_CI_DEDICATED_HOSTED_RUNNER_FILTERS = str(get_ci_dedicated_hosted_runner_filters())
GET_CI_DEDICATED_HOSTED_RUNNER_USAGE = str(get_ci_dedicated_hosted_runner_usage())
GET_CI_CONFIG = str(get_ci_config())
GET_CI_VARIABLES = str(get_ci_variables())
GET_CI_MINUTES_USAGE = str(get_ci_minutes_usage())
GET_CI_APPLICATION_SETTINGS = str(get_ci_application_settings())
GET_CI_QUEUEING_HISTORY = str(get_ci_queueing_history())
GET_CI_CATALOG_RESOURCE = str(get_ci_catalog_resource())
GET_CI_CATALOG_RESOURCES = str(get_ci_catalog_resources())
