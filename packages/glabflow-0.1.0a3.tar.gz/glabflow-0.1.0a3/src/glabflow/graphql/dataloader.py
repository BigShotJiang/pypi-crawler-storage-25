"""
DataLoader for GraphQL

Implements batched field loading to prevent N+1 query problems.
Inspired by Facebook's DataLoader pattern.
"""

from __future__ import annotations

import asyncio
from collections.abc import Awaitable, Callable
from dataclasses import dataclass
from typing import TYPE_CHECKING, Any

if TYPE_CHECKING:
    from glabflow.graphql.client import GraphQLClient


@dataclass
class BatchedQuery:
    """Represents a batched GraphQL query."""

    query: str
    variables: dict[str, Any]
    key: Any


class DataLoader[K, V]:
    """
    DataLoader for batching GraphQL field requests.

    Prevents N+1 query problems by collecting individual field requests
    and executing them as a single batched query.

    Example::

        # Create a loader for fetching projects by path
        loader = DataLoader(
            client=gl.graphql,
            batch_fn=batch_get_projects,
            max_batch_size=100,
        )

        # Individual loads are batched automatically
        proj1 = await loader.load("group/project1")
        proj2 = await loader.load("group/project2")
        # Both resolved in a single batched request

    Args:
        client: GraphQL client instance
        batch_fn: Async function that takes a list of keys and returns results
        max_batch_size: Maximum number of keys per batch
        batch_schedule_ms: Time to wait for batching (milliseconds)
        cache_enabled: Enable per-loader caching
    """

    def __init__(
        self,
        client: GraphQLClient,
        batch_fn: Callable[[list[K]], Awaitable[list[V]]] | None = None,
        max_batch_size: int = 100,
        batch_schedule_ms: int = 10,
        cache_enabled: bool = True,
    ) -> None:
        self._client = client
        self._batch_fn = batch_fn
        self._max_batch_size = max_batch_size
        self._batch_schedule_ms = batch_schedule_ms
        self._cache_enabled = cache_enabled

        # Internal state
        self._queue: list[tuple[K, asyncio.Future[V]]] = []
        self._cache: dict[K, V] = {}
        self._scheduled_batch: asyncio.Task | None = None
        self._stats = DataLoaderStats()

    async def load(self, key: K) -> V:
        """
        Load a single key, batching with other concurrent requests.

        Args:
            key: The key to load

        Returns:
            The resolved value
        """
        # Check cache first
        if self._cache_enabled and key in self._cache:
            self._stats.cache_hits += 1
            return self._cache[key]

        self._stats.cache_misses += 1

        # Create a future for this key
        loop = asyncio.get_event_loop()
        future: asyncio.Future[V] = loop.create_future()

        # Add to queue
        self._queue.append((key, future))

        # Schedule batch if not already scheduled
        if self._scheduled_batch is None or self._scheduled_batch.done():
            self._scheduled_batch = asyncio.create_task(self._dispatch_queue_batch())

        # Wait for resolution
        return await future

    async def load_many(self, keys: list[K]) -> list[V]:
        """
        Load multiple keys, batching with other concurrent requests.

        Args:
            keys: List of keys to load

        Returns:
            List of resolved values in the same order as keys
        """
        return await asyncio.gather(*[self.load(key) for key in keys])

    def prime(self, key: K, value: V) -> None:
        """
        Prime the cache with a key-value pair.

        Args:
            key: Cache key
            value: Value to cache
        """
        if self._cache_enabled:
            self._cache[key] = value

    def clear(self, key: K | None = None) -> None:
        """
        Clear cache for a key or all keys.

        Args:
            key: Specific key to clear (None clears all)
        """
        if key is not None:
            self._cache.pop(key, None)
        else:
            self._cache.clear()

    def get_stats(self) -> dict[str, Any]:
        """Get loader statistics."""
        return {
            "cache_hits": self._stats.cache_hits,
            "cache_misses": self._stats.cache_misses,
            "cache_size": len(self._cache),
            "hit_rate": self._stats.hit_rate,
            "total_batches": self._stats.total_batches,
            "total_keys_loaded": self._stats.total_keys_loaded,
            "avg_batch_size": self._stats.avg_batch_size,
        }

    async def _dispatch_queue_batch(self) -> None:
        """Dispatch the current queue as a batch."""
        # Wait for the batch schedule window
        await asyncio.sleep(self._batch_schedule_ms / 1000)

        # Take current queue snapshot
        queue = self._queue[:]
        self._queue.clear()

        if not queue:
            return

        # Split into batches if exceeding max_batch_size
        for i in range(0, len(queue), self._max_batch_size):
            batch = queue[i : i + self._max_batch_size]
            await self._execute_batch(batch)

    async def _execute_batch(self, batch: list[tuple[K, asyncio.Future[V]]]) -> None:
        """Execute a batch of requests."""
        keys = [key for key, _ in batch]
        self._stats.total_batches += 1
        self._stats.total_keys_loaded += len(keys)

        try:
            if self._batch_fn is not None:
                # Use custom batch function
                results = await self._batch_fn(keys)
            else:
                # Default: execute each query individually (still batched in time)
                results = await self._execute_default_batch(keys)

            # Resolve futures with results
            for key, future, result in zip(keys, [f for _, f in batch], results):
                if not future.done():
                    if self._cache_enabled:
                        self._cache[key] = result
                    future.set_result(result)

        except Exception as e:
            # Resolve all futures with error
            for _, future in batch:
                if not future.done():
                    future.set_exception(e)

    async def _execute_default_batch(self, keys: list[K]) -> list[V]:
        """
        Default batch execution.

        Subclasses should override this or provide a batch_fn.
        """
        raise NotImplementedError(
            "Either provide a batch_fn or subclass DataLoader "
            "and override _execute_default_batch"
        )


@dataclass
class DataLoaderStats:
    """Statistics for a DataLoader instance."""

    cache_hits: int = 0
    cache_misses: int = 0
    total_batches: int = 0
    total_keys_loaded: int = 0

    @property
    def hit_rate(self) -> float:
        """Cache hit rate as a percentage."""
        total = self.cache_hits + self.cache_misses
        if total == 0:
            return 0.0
        return (self.cache_hits / total) * 100

    @property
    def avg_batch_size(self) -> float:
        """Average batch size."""
        if self.total_batches == 0:
            return 0.0
        return self.total_keys_loaded / self.total_batches


class ProjectDataLoader(DataLoader[str, dict[str, Any]]):
    """
    DataLoader for fetching projects by path.

    Example::

        loader = ProjectDataLoader(gl.graphql)
        project = await loader.load("group/project")
    """

    async def _execute_default_batch(self, keys: list[str]) -> list[dict[str, Any]]:
        """Batch fetch projects by path."""
        # Build a batched query
        fields = []
        for i, path in enumerate(keys):
            fields.append(
                f"project{i}: project(fullPath: {json_dumps(path)}) {{\n"
                f"  id\n  name\n  fullPath\n  description\n  webUrl\n"
                f"  openIssuesCount\n  openMergeRequestsCount\n"
                f"}}"
            )

        query = f"query BatchGetProjects {{\n{chr(10).join(fields)}\n}}"

        result = await self._client.execute(query)

        # Extract results in order
        return [result.get(f"project{i}", {}) for i in range(len(keys))]


class UserDataLoader(DataLoader[int, dict[str, Any]]):
    """
    DataLoader for fetching users by ID.

    Example::

        loader = UserDataLoader(gl.graphql)
        user = await loader.load(123)
    """

    async def _execute_default_batch(self, keys: list[int]) -> list[dict[str, Any]]:
        """Batch fetch users by ID."""
        fields = []
        for i, user_id in enumerate(keys):
            fields.append(
                f"user{i}: user(id: {user_id}) {{\n"
                f"  id\n  username\n  name\n  avatarUrl\n  webUrl\n"
                f"  bio\n  location\n}}"
            )

        query = f"query BatchGetUsers {{\n{chr(10).join(fields)}\n}}"

        result = await self._client.execute(query)

        return [result.get(f"user{i}", {}) for i in range(len(keys))]


class IssueDataLoader(DataLoader[int, dict[str, Any]]):
    """
    DataLoader for fetching issues by ID.

    Example::

        loader = IssueDataLoader(gl.graphql)
        issue = await loader.load(456)
    """

    def __init__(
        self,
        client: GraphQLClient,
        project_path: str,
        **kwargs: Any,
    ) -> None:
        super().__init__(client, **kwargs)
        self._project_path = project_path

    async def _execute_default_batch(self, keys: list[int]) -> list[dict[str, Any]]:
        """Batch fetch issues by IID."""
        fields = []
        for i, issue_iid in enumerate(keys):
            fields.append(
                f"issue{i}: project(fullPath: {json_dumps(self._project_path)}) {{\n"
                f"  issue(iid: {issue_iid}) {{\n"
                f"    iid\n  title\n  state\n  webUrl\n"
                f"    createdAt\n  author {{ username }}\n"
                f"  }}\n"
                f"}}"
            )

        query = f"query BatchGetIssues {{\n{chr(10).join(fields)}\n}}"

        result = await self._client.execute(query)

        return [result.get(f"issue{i}", {}).get("issue", {}) for i in range(len(keys))]


# Utility function for JSON serialization in query building
def json_dumps(value: str) -> str:
    """Serialize a string value for GraphQL."""
    return f'"{value}"'
