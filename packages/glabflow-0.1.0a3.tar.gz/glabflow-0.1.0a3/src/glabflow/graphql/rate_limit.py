"""
GraphQL Rate Limit Awareness and Automatic Throttling

Tracks GitLab GraphQL rate limits and automatically throttles requests.
"""

from __future__ import annotations

import asyncio
import time
from dataclasses import dataclass
from enum import Enum


class RateLimitState(Enum):
    """Rate limit state."""

    NORMAL = "normal"
    WARNING = "warning"
    CRITICAL = "critical"
    EXHAUSTED = "exhausted"


@dataclass
class RateLimitInfo:
    """Rate limit information."""

    limit: int = 1000  # GitLab GraphQL points limit
    remaining: int = 1000
    reset_time: float = 0.0
    used: int = 0
    cost: int = 0
    state: RateLimitState = RateLimitState.NORMAL

    @property
    def usage_percent(self) -> float:
        """Calculate usage percentage."""
        if self.limit == 0:
            return 0.0
        return (self.used / self.limit) * 100

    @property
    def time_until_reset(self) -> float:
        """Calculate time until rate limit reset."""
        if self.reset_time == 0:
            return 0.0
        return max(0, self.reset_time - time.time())

    def update_state(self) -> None:
        """Update rate limit state based on usage."""
        usage = self.usage_percent
        if usage >= 100:
            self.state = RateLimitState.EXHAUSTED
        elif usage >= 80:
            self.state = RateLimitState.CRITICAL
        elif usage >= 60:
            self.state = RateLimitState.WARNING
        else:
            self.state = RateLimitState.NORMAL


@dataclass
class ThrottleConfig:
    """Throttle configuration."""

    enabled: bool = True
    min_delay: float = 0.1  # Minimum delay between requests
    max_delay: float = 5.0  # Maximum delay between requests
    warning_threshold: float = 0.6  # Start throttling at 60% usage
    critical_threshold: float = 0.8  # Aggressive throttling at 80%
    backoff_multiplier: float = 2.0  # Multiplier for backoff


class RateLimitTracker:
    """
    Track GitLab GraphQL rate limits.

    GitLab GraphQL API uses a point-based rate limit system.
    This tracker monitors usage and provides rate limit information.

    Example:
        tracker = RateLimitTracker()
        tracker.update_from_headers(response_headers)
        print(f"Remaining: {tracker.info.remaining}")
        print(f"State: {tracker.info.state}")
    """

    def __init__(self, limit: int = 1000) -> None:
        """
        Initialize rate limit tracker.

        Args:
            limit: Rate limit (GitLab GraphQL default is 1000 points)
        """
        self.info = RateLimitInfo(limit=limit)
        self._history: list[RateLimitInfo] = []

    def update_from_headers(self, headers: dict[str, str]) -> None:
        """
        Update rate limit info from response headers.

        Args:
            headers: Response headers
        """
        # GitLab GraphQL headers
        if "RateLimit-Limit" in headers:
            self.info.limit = int(headers["RateLimit-Limit"])
        if "RateLimit-Remaining" in headers:
            self.info.remaining = int(headers["RateLimit-Remaining"])
        if "RateLimit-Reset" in headers:
            self.info.reset_time = float(headers["RateLimit-Reset"])
        if "RateLimit-Used" in headers:
            self.info.used = int(headers["RateLimit-Used"])

        # Update state
        self.info.update_state()

        # Save to history
        self._history.append(
            RateLimitInfo(
                limit=self.info.limit,
                remaining=self.info.remaining,
                reset_time=self.info.reset_time,
                used=self.info.used,
            )
        )

    def update_from_result(self, result: dict) -> None:
        """
        Update from GraphQL result extensions.

        Some GraphQL servers include rate limit info in extensions.

        Args:
            result: GraphQL result dict
        """
        extensions = result.get("extensions", {})
        rate_limit = extensions.get("rateLimit", {})

        if "limit" in rate_limit:
            self.info.limit = rate_limit["limit"]
        if "remaining" in rate_limit:
            self.info.remaining = rate_limit["remaining"]
        if "resetAt" in rate_limit:
            # Parse ISO timestamp
            from datetime import datetime

            try:
                reset_time = datetime.fromisoformat(
                    rate_limit["resetAt"].replace("Z", "+00:00")
                )
                self.info.reset_time = reset_time.timestamp()
            except (ValueError, AttributeError):
                pass

        self.info.update_state()

    def should_wait(self) -> bool:
        """Check if we should wait before next request."""
        return self.info.state in (RateLimitState.CRITICAL, RateLimitState.EXHAUSTED)

    def get_wait_time(self) -> float:
        """Get recommended wait time in seconds."""
        if self.info.state == RateLimitState.EXHAUSTED:
            return self.info.time_until_reset
        elif self.info.state == RateLimitState.CRITICAL:
            return max(1.0, self.info.time_until_reset / 10)
        elif self.info.state == RateLimitState.WARNING:
            return 0.5
        return 0.0

    def reset(self) -> None:
        """Reset rate limit tracker."""
        self.info = RateLimitInfo(limit=self.info.limit)
        self._history.clear()

    def get_stats(self) -> dict:
        """Get rate limit statistics."""
        return {
            "limit": self.info.limit,
            "remaining": self.info.remaining,
            "used": self.info.used,
            "usage_percent": self.info.usage_percent,
            "state": self.info.state.value,
            "time_until_reset": self.info.time_until_reset,
            "history_size": len(self._history),
        }


class AutomaticThrottler:
    """
    Automatically throttle GraphQL requests based on rate limits.

    Example:
        throttler = AutomaticThrottler()

        async with throttler.throttle():
            result = await client.execute(query)
            throttler.update_from_headers(response_headers)
    """

    def __init__(
        self,
        tracker: RateLimitTracker | None = None,
        config: ThrottleConfig | None = None,
    ) -> None:
        """
        Initialize automatic throttler.

        Args:
            tracker: Rate limit tracker
            config: Throttle configuration
        """
        self.tracker = tracker or RateLimitTracker()
        self.config = config or ThrottleConfig()
        self._last_request_time: float = 0.0
        self._consecutive_delays: int = 0

    async def throttle(self) -> None:
        """
        Apply throttling delay if necessary.

        Call this before making a GraphQL request.
        """
        if not self.config.enabled:
            return

        # Calculate base delay
        usage = self.tracker.info.usage_percent / 100

        if usage >= self.config.critical_threshold:
            # Critical: aggressive throttling
            delay = self.config.max_delay
            self._consecutive_delays += 1
        elif usage >= self.config.warning_threshold:
            # Warning: moderate throttling
            delay = self.config.min_delay * (1 + usage * self.config.backoff_multiplier)
            self._consecutive_delays += 1
        else:
            # Normal: minimal delay
            delay = self.config.min_delay
            self._consecutive_delays = 0

        # Add backoff for consecutive delays
        if self._consecutive_delays > 3:
            delay *= min(2.0, 1 + (self._consecutive_delays - 3) * 0.5)

        # Ensure minimum delay
        delay = max(self.config.min_delay, delay)

        # Apply delay
        elapsed = time.time() - self._last_request_time
        if elapsed < delay:
            await asyncio.sleep(delay - elapsed)

        self._last_request_time = time.time()

    def update_from_headers(self, headers: dict[str, str]) -> None:
        """Update from response headers."""
        self.tracker.update_from_headers(headers)

    def update_from_result(self, result: dict) -> None:
        """Update from GraphQL result."""
        self.tracker.update_from_result(result)

    def configure(
        self,
        enabled: bool | None = None,
        min_delay: float | None = None,
        max_delay: float | None = None,
        warning_threshold: float | None = None,
        critical_threshold: float | None = None,
    ) -> None:
        """Update throttle configuration."""
        if enabled is not None:
            self.config.enabled = enabled
        if min_delay is not None:
            self.config.min_delay = min_delay
        if max_delay is not None:
            self.config.max_delay = max_delay
        if warning_threshold is not None:
            self.config.warning_threshold = warning_threshold
        if critical_threshold is not None:
            self.config.critical_threshold = critical_threshold

    def get_stats(self) -> dict:
        """Get throttler statistics."""
        return {
            "enabled": self.config.enabled,
            "rate_limit": self.tracker.get_stats(),
            "consecutive_delays": self._consecutive_delays,
            "last_request": time.time() - self._last_request_time,
        }


class ThrottledGraphQLClient:
    """
    GraphQL client wrapper with automatic throttling.

    Wraps an existing GraphQL client to add automatic rate limit handling.

    Example:
        throttled = ThrottledGraphQLClient(gl.graphql)
        result = await throttled.execute(query)
    """

    def __init__(self, client) -> None:
        """
        Initialize throttled client.

        Args:
            client: GraphQL client to wrap
        """
        self._client = client
        self._throttler = AutomaticThrottler()
        self._enabled = True

    async def execute(
        self,
        query: str,
        variables: dict | None = None,
    ) -> dict:
        """
        Execute query with automatic throttling.

        Args:
            query: GraphQL query string
            variables: Query variables

        Returns:
            Query result
        """
        if self._enabled:
            await self._throttler.throttle()

        result = await self._client.execute(query, variables)

        if self._enabled:
            self._throttler.update_from_result(result)

        return result

    async def stream(self, *args, **kwargs):
        """Stream with automatic throttling."""
        async for item in self._client.stream(*args, **kwargs):
            if self._enabled:
                await self._throttler.throttle()
            yield item

    def configure_throttling(
        self,
        enabled: bool = True,
        min_delay: float = 0.1,
        max_delay: float = 5.0,
    ) -> None:
        """Configure throttling behavior."""
        self._throttler.configure(
            enabled=enabled,
            min_delay=min_delay,
            max_delay=max_delay,
        )

    def get_rate_limit_info(self) -> dict:
        """Get current rate limit information."""
        return self._throttler.get_stats()
