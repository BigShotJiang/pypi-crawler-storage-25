"""
Pre-built GraphQL Queries for Common Scenarios

Ready-to-use queries for frequently accessed data.
"""

from glabflow.graphql.builder import Field, Query, fragment, query

# ========== Fragments ==========

PROJECT_FRAGMENT = (
    fragment("ProjectFields", "Project")
    .field("id")
    .field("name")
    .field("path")
    .field("fullPath")
    .field("description")
    .field("webUrl")
    .field("createdAt")
    .field("updatedAt")
    .field("openIssuesCount")
    .field("archived")
    .field("visibility")
)

MR_FRAGMENT = (
    fragment("MergeRequestFields", "MergeRequest")
    .field("iid")
    .field("title")
    .field("state")
    .field("webUrl")
    .field("createdAt")
    .field("updatedAt")
    .field("mergedAt")
    .field("closedAt")
    .field("sourceBranch")
    .field("targetBranch")
)

ISSUE_FRAGMENT = (
    fragment("IssueFields", "Issue")
    .field("iid")
    .field("title")
    .field("state")
    .field("webUrl")
    .field("createdAt")
    .field("updatedAt")
    .field("closedAt")
    .field("closedBy")
)

USER_FRAGMENT = (
    fragment("UserFields", "User")
    .field("id")
    .field("username")
    .field("name")
    .field("avatarUrl")
    .field("webUrl")
)

# ========== Project Queries ==========


def get_project(
    with_members: bool = False, with_merge_requests: bool = False
) -> Field | Query:
    """
    Get project by full path.

    Args:
        with_members: Include project members
        with_merge_requests: Include recent merge requests

    Returns:
        Query builder

    Example:
        q = get_project(with_members=True)
        result = await gl.graphql.execute(str(q), variables={"fullPath": "group/project"})
    """
    q = (
        query("GetProject")
        .arg("fullPath", "$fullPath", "ID!")
        .field("project", args={"fullPath": "$fullPath"})
        .field("id")
        .field("name")
        .field("path")
        .field("fullPath")
        .field("description")
        .field("webUrl")
        .field("createdAt")
        .field("updatedAt")
        .field("openIssuesCount")
        .field("archived")
        .field("visibility")
    )

    if with_members:
        q.field("members").field("nodes").field(
            "user", fields=["username", "name"]
        ).end().end()

    if with_merge_requests:
        q.field(
            "mergeRequests",
            args={"first": "10", "sort": "UPDATED_DESC"},
        ).field("nodes", fields=["iid", "title", "state", "webUrl"]).end()

    return q


def get_project_hierarchy() -> Field | Query:
    """
    Get project with full group hierarchy.

    Returns:
        Query builder
    """
    return (
        query("GetProjectHierarchy")
        .arg("fullPath", "$fullPath", "ID!")
        .field("project", args={"fullPath": "$fullPath"})
        .field("id")
        .field("name")
        .field("fullPath")
        .field(
            "group",
            fields=[
                "id",
                "name",
                "fullPath",
                "parent",
            ],
        )
        .end()
    )


def get_project_statistics() -> Field | Query:
    """
    Get project with detailed statistics.

    Returns:
        Query builder
    """
    return (
        query("GetProjectStatistics")
        .arg("fullPath", "$fullPath", "ID!")
        .field("project", args={"fullPath": "$fullPath"})
        .field("id")
        .field("name")
        .field("openIssuesCount")
        .field("openMergeRequestsCount")
        .field("closedIssuesCount")
        .field("mergedMergeRequestsCount")
        .field("packagesCount")
        .field("repositorySize")
        .end()
    )


# ========== Merge Request Queries ==========


def get_merge_requests(
    state: str = "opened",
    limit: int = 100,
    with_details: bool = True,
) -> Field | Query:
    """
    Get merge requests for a project.

    Args:
        state: MR state (opened, merged, closed, all)
        limit: Number of MRs to fetch
        with_details: Include detailed fields

    Returns:
        Query builder for streaming
    """
    q = (
        query("GetMergeRequests")
        .arg("fullPath", "$fullPath", "ID!")
        .arg("after", "$after", "String")
        .arg("first", "$first", "Int")
        .field("project", args={"fullPath": "$fullPath"})
        .field(
            "mergeRequests",
            args={
                "after": "$after",
                "first": "$first",
                "state": state,
            },
        )
        .field("pageInfo", fields=["hasNextPage", "endCursor"])
    )

    if with_details:
        q.field("nodes").field("iid").field("title").field("state").field(
            "webUrl"
        ).field("author", fields=["username", "name"]).field("createdAt").field(
            "updatedAt"
        ).end()
    else:
        q.field("nodes", fields=["iid", "title", "webUrl"])

    return q


def get_merge_request_details() -> Field | Query:
    """
    Get detailed merge request information.

    Returns:
        Query builder
    """
    return (
        query("GetMergeRequestDetails")
        .arg("fullPath", "$fullPath", "ID!")
        .arg("iid", "$iid", "Int!")
        .field("project", args={"fullPath": "$fullPath"})
        .field("mergeRequest", args={"iid": "$iid"})
        .field("iid")
        .field("title")
        .field("description")
        .field("state")
        .field("webUrl")
        .field("sourceBranch")
        .field("targetBranch")
        .field("author", fields=["username", "name", "avatarUrl"])
        .field("assignees")
        .field("nodes", fields=["username", "name"])
        .end()
        .field("reviewers")
        .field("nodes", fields=["username", "name"])
        .end()
        .field("labels")
        .field("nodes", fields=["name", "color"])
        .end()
        .field("createdAt")
        .field("updatedAt")
        .field("mergedAt")
        .field("closedAt")
        .field("mergedBy", fields=["username"])
        .end()
    )


# ========== Issue Queries ==========


def get_issues(state: str = "opened", limit: int = 100) -> Field | Query:
    """
    Get issues for a project.

    Args:
        state: Issue state (opened, closed, all)
        limit: Number of issues to fetch

    Returns:
        Query builder for streaming
    """
    return (
        query("GetIssues")
        .arg("fullPath", "$fullPath", "ID!")
        .arg("after", "$after", "String")
        .arg("first", "$first", "Int")
        .field("project", args={"fullPath": "$fullPath"})
        .field(
            "issues",
            args={
                "after": "$after",
                "first": "$first",
                "state": state,
            },
        )
        .field("pageInfo", fields=["hasNextPage", "endCursor"])
        .field("nodes", fields=["iid", "title", "state", "webUrl", "createdAt"])
        .end()
    )


# ========== User Queries ==========


def get_user_details() -> Field | Query:
    """
    Get detailed user information.

    Returns:
        Query builder
    """
    return (
        query("GetUserDetails")
        .arg("username", "$username", "String!")
        .field("user", args={"username": "$username"})
        .field("id")
        .field("username")
        .field("name")
        .field("avatarUrl")
        .field("webUrl")
        .field("bio")
        .field("location")
        .field("organization")
        .field("createdAt")
        .end()
    )


def get_user_contributions() -> Field | Query:
    """
    Get user contribution data.

    Returns:
        Query builder
    """
    return (
        query("GetUserContributions")
        .arg("username", "$username", "String!")
        .field("user", args={"username": "$username"})
        .field("id")
        .field("username")
        .field("name")
        .field(
            "contributedProjects",
            args={"first": "20"},
        )
        .field("nodes", fields=["id", "name", "fullPath"])
        .end()
        .end()
    )


# ========== Group Queries ==========


def get_group_hierarchy() -> Field | Query:
    """
    Get group with parent hierarchy.

    Returns:
        Query builder
    """
    return (
        query("GetGroupHierarchy")
        .arg("fullPath", "$fullPath", "ID!")
        .field("group", args={"fullPath": "$fullPath"})
        .field("id")
        .field("name")
        .field("fullPath")
        .field("description")
        .field("webUrl")
        .field(
            "parent",
            fields=[
                "id",
                "name",
                "fullPath",
                "parent",
            ],
        )
        .end()
    )


def get_group_projects(limit: int = 100) -> Field | Query:
    """
    Get projects in a group.

    Args:
        limit: Number of projects to fetch

    Returns:
        Query builder for streaming
    """
    return (
        query("GetGroupProjects")
        .arg("fullPath", "$fullPath", "ID!")
        .arg("after", "$after", "String")
        .arg("first", "$first", "Int")
        .field("group", args={"fullPath": "$fullPath"})
        .field(
            "projects",
            args={
                "after": "$after",
                "first": "$first",
            },
        )
        .field("pageInfo", fields=["hasNextPage", "endCursor"])
        .field("nodes", fields=["id", "name", "path", "fullPath", "webUrl"])
        .end()
    )


# ========== Utility Queries ==========


def check_field_exists(type_name: str, field_name: str) -> Field | Query:
    """
    Check if a field exists on a type.

    Args:
        type_name: GraphQL type name
        field_name: Field name to check

    Returns:
        Query builder
    """
    return (
        query("CheckField")
        .field("__type", args={"name": f'"{type_name}"'})
        .field("fields", args={"includeDeprecated": "true"})
        .field("name")
        .end()
    )


# ========== Export common query strings ==========

GET_PROJECT = str(get_project())
GET_PROJECT_HIERARCHY = str(get_project_hierarchy())
GET_MERGE_REQUESTS = str(get_merge_requests())
GET_ISSUES = str(get_issues())
GET_USER_DETAILS = str(get_user_details())
GET_GROUP_HIERARCHY = str(get_group_hierarchy())
