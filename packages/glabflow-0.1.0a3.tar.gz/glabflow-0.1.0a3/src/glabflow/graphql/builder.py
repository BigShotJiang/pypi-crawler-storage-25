"""
GraphQL Query Builder DSL

Provides a type-safe, fluent interface for building GraphQL queries.
"""

from __future__ import annotations

from dataclasses import dataclass, field


@dataclass
class Directive:
    """GraphQL directive."""

    name: str
    arguments: dict[str, str] = field(default_factory=dict)

    def render(self) -> str:
        args = ", ".join(f"{k}: {v}" for k, v in self.arguments.items())
        if args:
            return f"@{self.name}({args})"
        return f"@{self.name}"


@dataclass
class Field:
    """GraphQL field with optional arguments and sub-fields."""

    name: str
    alias: str | None = None
    arguments: dict[str, str] = field(default_factory=dict)
    fields: list[Field] = field(default_factory=list)
    fragments: list[str] = field(default_factory=list)
    directives: list[Directive] = field(default_factory=list)
    _parent: Field | Query | None = field(default=None, repr=False, compare=False)

    def render(self, indent: int = 0) -> str:
        """Render field to GraphQL string."""
        indentation = "  " * indent

        # Build field name with optional alias
        if self.alias:
            result = f"{self.alias}: {self.name}"
        else:
            result = self.name

        # Add arguments
        if self.arguments:
            args = ", ".join(f"{k}: {v}" for k, v in self.arguments.items())
            result += f"({args})"

        # Add directives
        for directive in self.directives:
            result += f" {directive.render()}"

        # Add sub-fields
        if self.fields or self.fragments:
            result += " {\n"
            for f in self.fields:
                result += f"{f.render(indent + 1)}\n"
            for fragment in self.fragments:
                result += f"{indentation}  ...{fragment}\n"
            result += f"{indentation}}}"

        return result

    def field(
        self,
        name: str,
        alias: str | None = None,
        args: dict[str, str] | None = None,
        fields: list[str] | None = None,
    ) -> Field:
        """Add sub-field."""
        new_field = Field(
            name=name,
            alias=alias,
            arguments=args or {},
            fields=[Field(f) for f in (fields or [])],
            _parent=self,
        )
        self.fields.append(new_field)
        return new_field

    def directive(self, name: str, **arguments: str) -> Field:
        """
        Add directive to field.

        Args:
            name: Directive name (e.g., "gl_introduced", "deprecated")
            **arguments: Directive arguments as keyword args

        Returns:
            Self for chaining

        Example:
            q = query("GetProject") \\
                .field("project") \\
                .field("newFeature") \\
                .directive("gl_introduced", version='"18.0"') \\
                .end() \\
                .end()
        """
        self.directives.append(Directive(name, arguments))
        return self

    def end(self) -> Field | Query:
        """Return parent (for fluent interface)."""
        if self._parent is not None:
            return self._parent
        return self

    def build(self) -> Query:
        """Traverse up to the root Query."""
        node: Field | Query = self
        while isinstance(node, Field):
            if node._parent is None:
                raise ValueError("Field is not attached to a Query")
            node = node._parent
        return node


@dataclass
class Fragment:
    """GraphQL fragment definition."""

    name: str
    type_name: str
    fields: list[Field] = field(default_factory=list)

    def field(
        self,
        name: str,
        alias: str | None = None,
        args: dict[str, str] | None = None,
        fields: list[str] | None = None,
    ) -> Fragment:
        """Add field to fragment."""
        new_field = Field(
            name=name,
            alias=alias,
            arguments=args or {},
            fields=[Field(f) for f in (fields or [])],
        )
        self.fields.append(new_field)
        return self

    def directive(self, name: str, **arguments: str) -> Fragment:
        """Add directive to the last field in fragment."""
        if self.fields:
            self.fields[-1].directives.append(Directive(name, arguments))
        return self

    def render(self) -> str:
        """Render fragment definition."""
        fields_str = "\n".join(f.render(1) for f in self.fields)
        return f"fragment {self.name} on {self.type_name} {{\n{fields_str}\n}}"

    def spread(self) -> str:
        """Render fragment spread."""
        return f"...{self.name}"


@dataclass
class Query:
    """GraphQL query builder."""

    operation: str = "query"
    name: str | None = None
    variables: dict[str, tuple[str, str]] = field(
        default_factory=dict
    )  # name -> (type, default)
    fields: list[Field] = field(default_factory=list)
    fragments: list[Fragment] = field(default_factory=list)

    def arg(self, name: str, var_type: str, default: str | None = None) -> Query:
        """Add variable argument."""
        self.variables[name] = (var_type, default) if default else (var_type, "")
        return self

    def field(
        self,
        name: str,
        alias: str | None = None,
        args: dict[str, str] | None = None,
        fields: list[str] | None = None,
    ) -> Field:
        """Add root field."""
        new_field = Field(
            name=name,
            alias=alias,
            arguments=args or {},
            fields=[Field(f) for f in (fields or [])],
            _parent=self,
        )
        self.fields.append(new_field)
        return new_field

    def end(self) -> Query:
        """No-op for fluent interface (Query is the root)."""
        return self

    def fragment(self, name: str, type_name: str) -> Fragment:
        """Define fragment."""
        frag = Fragment(name=name, type_name=type_name)
        self.fragments.append(frag)
        return frag

    def render(self) -> str:
        """Render complete query."""
        parts = []

        # Add fragments first
        for frag in self.fragments:
            parts.append(frag.render())

        # Build operation
        if self.name:
            op = f"{self.operation} {self.name}"
        else:
            op = self.operation

        # Add variables
        if self.variables:
            var_strs = []
            for name, (var_type, default) in self.variables.items():
                if default:
                    var_strs.append(f"${name}: {var_type} = {default}")
                else:
                    var_strs.append(f"${name}: {var_type}")
            op += f"({', '.join(var_strs)})"

        # Add fields
        if self.fields:
            fields_str = "\n".join(f.render(1) for f in self.fields)
            parts.append(f"{op} {{\n{fields_str}\n}}")
        else:
            parts.append(op)

        return "\n\n".join(parts)

    def __str__(self) -> str:
        return self.render()

    def build(self) -> str:
        """Build and return query string."""
        return self.render()


def query(name: str | None = None) -> Query:
    """Create a new query builder."""
    return Query(operation="query", name=name)


def mutation(name: str | None = None) -> Query:
    """Create a new mutation builder."""
    return Query(operation="mutation", name=name)


def subscription(name: str | None = None) -> Query:
    """Create a new subscription builder."""
    return Query(operation="subscription", name=name)


def fragment(name: str, type_name: str) -> Fragment:
    """Create a new fragment."""
    return Fragment(name=name, type_name=type_name)


# Convenience functions for common patterns


def field_with_args(
    name: str,
    args: dict[str, str],
    fields: list[str] | None = None,
) -> Field:
    """Create field with arguments."""
    return Field(
        name=name,
        arguments=args,
        fields=[Field(f) for f in (fields or [])],
    )


def aliased_field(alias: str, name: str, fields: list[str] | None = None) -> Field:
    """Create aliased field."""
    return Field(
        name=name,
        alias=alias,
        fields=[Field(f) for f in (fields or [])],
    )


# Mutation-specific helpers


def create_mutation(
    name: str,
    mutation_type: str,
    input_type: str,
    input_fields: dict[str, str],
    result_fields: list[str],
) -> Query:
    """
    Create a standard create mutation.

    Args:
        name: Mutation name
        mutation_type: Type being created (e.g., "Issue", "MergeRequest")
        input_type: Input type name (e.g., "CreateIssueInput")
        input_fields: Input fields
        result_fields: Fields to return

    Returns:
        Query builder for the mutation

    Example:
        m = create_mutation(
            "CreateIssue",
            "issue",
            "CreateIssueInput",
            {"projectId": "$pid", "title": "$title"},
            ["id", "iid", "title"]
        )
    """
    q = mutation(name)

    # Add input variable
    q.arg("input", f"{input_type}!", "")

    # Build mutation field
    mutation_field = f"{mutation_type}Create"
    q.field(mutation_field, args={"input": "$input"})

    # Add result fields
    result = q.field(mutation_type.lower())
    for field_name in result_fields:
        result.field(field_name)

    return q


def update_mutation(
    name: str,
    mutation_type: str,
    input_type: str,
    input_fields: dict[str, str],
    result_fields: list[str],
) -> Query:
    """
    Create a standard update mutation.

    Args:
        name: Mutation name
        mutation_type: Type being updated
        input_type: Input type name
        input_fields: Input fields
        result_fields: Fields to return

    Returns:
        Query builder for the mutation
    """
    q = mutation(name)
    q.arg("input", f"{input_type}!", "")

    mutation_field = f"{mutation_type}Update"
    q.field(mutation_field, args={"input": "$input"})

    result = q.field(mutation_type.lower())
    for field_name in result_fields:
        result.field(field_name)

    return q


def delete_mutation(
    name: str,
    mutation_type: str,
    id_field: str = "id",
) -> Query:
    """
    Create a standard delete mutation.

    Args:
        name: Mutation name
        mutation_type: Type being deleted
        id_field: ID field name

    Returns:
        Query builder for the mutation
    """
    q = mutation(name)
    q.arg(id_field, "ID!", "")

    mutation_field = f"{mutation_type}Delete"
    q.field(mutation_field, args={id_field: f"${id_field}"})
    q.field("clientMutationId")

    return q
