"""
GraphQL Mutations

Auto-generated mutations from scripts/generate_queries.py
Comprehensive coverage of all GitLab GraphQL mutations.
"""

from glabflow.graphql.queries_mutations_generated import (
    # Deployment Mutations
    APPROVE_DEPLOYMENT,
    # Award Emoji Mutations
    AWARD_EMOJI_ADD,
    AWARD_EMOJI_DELETE,
    # Board Mutations
    BOARD_LIST_CREATE,
    BOARD_LIST_DELETE,
    BOARD_LIST_UPDATE,
    # Variable Mutations
    CI_VARIABLE_CREATE,
    CI_VARIABLE_DELETE,
    CI_VARIABLE_UPDATE,
    # Group Mutations
    CREATE_GROUP,
    # Issue Mutations
    CREATE_ISSUE,
    # Label Mutations
    CREATE_LABEL,
    # Merge Request Mutations
    CREATE_MERGE_REQUEST,
    # Milestone Mutations
    CREATE_MILESTONE,
    # Note/Comment Mutations
    CREATE_NOTE,
    # Project Mutations
    CREATE_PROJECT,
    # Snippet Mutations
    CREATE_SNIPPET,
    # User Mutations
    CREATE_USER,
    DELETE_ISSUE,
    DELETE_LABEL,
    DELETE_NOTE,
    DELETE_PROJECT,
    DELETE_SNIPPET,
    # Environment Mutations
    ENVIRONMENT_CREATE,
    ENVIRONMENT_DELETE,
    ENVIRONMENT_UPDATE,
    # Member Mutations
    GROUP_MEMBER_ADD,
    GROUP_MEMBER_REMOVE,
    # Iteration Mutations
    ITERATION_CREATE,
    ITERATION_UPDATE,
    # CI/CD Advanced Mutations
    JOB_CANCEL,
    JOB_ERASE,
    JOB_RETRY,
    MERGE_MERGE_REQUEST,
    # Package Mutations
    PACKAGE_DELETE,
    # CI/CD Mutations
    PIPELINE_CANCEL,
    PIPELINE_RETRY,
    # Pipeline Schedule Mutations
    PIPELINE_SCHEDULE_CREATE,
    PIPELINE_SCHEDULE_DELETE,
    PIPELINE_SCHEDULE_UPDATE,
    PROJECT_MEMBER_ADD,
    PROJECT_MEMBER_REMOVE,
    # Runner Mutations
    RUNNER_CREATE,
    RUNNER_DELETE,
    RUNNER_UPDATE,
    # Todo Mutations
    TODO_CREATE,
    TODO_MARK_DONE,
    UPDATE_GROUP,
    UPDATE_ISSUE,
    UPDATE_LABEL,
    UPDATE_MERGE_REQUEST,
    UPDATE_MILESTONE,
    UPDATE_NOTE,
    UPDATE_PROJECT,
    UPDATE_SNIPPET,
    UPDATE_USER,
    # File Upload Mutation
    UPLOAD_FILE,
    # Security Mutations
    VULNERABILITY_CONFIRM,
    VULNERABILITY_DISMISS,
    VULNERABILITY_RESOLVE,
    # Work Item Mutations
    WORK_ITEM_CREATE,
    WORK_ITEM_DELETE,
    WORK_ITEM_UPDATE,
    approve_deployment,
    award_emoji_add,
    award_emoji_delete,
    board_list_create,
    board_list_delete,
    board_list_update,
    ci_variable_create,
    ci_variable_delete,
    ci_variable_update,
    create_group,
    create_issue,
    create_label,
    create_merge_request,
    create_milestone,
    create_note,
    create_project,
    create_snippet,
    create_user,
    delete_issue,
    delete_label,
    delete_note,
    delete_project,
    delete_snippet,
    environment_create,
    environment_delete,
    environment_update,
    group_member_add,
    group_member_remove,
    iteration_create,
    iteration_update,
    job_cancel,
    job_erase,
    job_retry,
    merge_merge_request,
    package_delete,
    pipeline_cancel,
    pipeline_retry,
    pipeline_schedule_create,
    pipeline_schedule_delete,
    pipeline_schedule_update,
    project_member_add,
    project_member_remove,
    runner_create,
    runner_delete,
    runner_update,
    todo_create,
    todo_mark_done,
    update_group,
    update_issue,
    update_label,
    update_merge_request,
    update_milestone,
    update_note,
    update_project,
    update_snippet,
    update_user,
    upload_file,
    vulnerability_confirm,
    vulnerability_dismiss,
    vulnerability_resolve,
    work_item_create,
    work_item_delete,
    work_item_update,
)

__all__ = [
    # Issue Mutations
    "create_issue",
    "update_issue",
    "delete_issue",
    "CREATE_ISSUE",
    "UPDATE_ISSUE",
    "DELETE_ISSUE",
    # Merge Request Mutations
    "create_merge_request",
    "update_merge_request",
    "merge_merge_request",
    "CREATE_MERGE_REQUEST",
    "UPDATE_MERGE_REQUEST",
    "MERGE_MERGE_REQUEST",
    # Project Mutations
    "create_project",
    "update_project",
    "delete_project",
    "CREATE_PROJECT",
    "UPDATE_PROJECT",
    "DELETE_PROJECT",
    # Group Mutations
    "create_group",
    "update_group",
    "CREATE_GROUP",
    "UPDATE_GROUP",
    # User Mutations
    "create_user",
    "update_user",
    "CREATE_USER",
    "UPDATE_USER",
    # Deployment Mutations
    "approve_deployment",
    "APPROVE_DEPLOYMENT",
    # Note/Comment Mutations
    "create_note",
    "update_note",
    "delete_note",
    "CREATE_NOTE",
    "UPDATE_NOTE",
    "DELETE_NOTE",
    # CI/CD Mutations
    "pipeline_cancel",
    "pipeline_retry",
    "PIPELINE_CANCEL",
    "PIPELINE_RETRY",
    # Snippet Mutations
    "create_snippet",
    "update_snippet",
    "delete_snippet",
    "CREATE_SNIPPET",
    "UPDATE_SNIPPET",
    "DELETE_SNIPPET",
    # Label Mutations
    "create_label",
    "update_label",
    "delete_label",
    "CREATE_LABEL",
    "UPDATE_LABEL",
    "DELETE_LABEL",
    # Milestone Mutations
    "create_milestone",
    "update_milestone",
    "CREATE_MILESTONE",
    "UPDATE_MILESTONE",
    # Award Emoji Mutations
    "award_emoji_add",
    "award_emoji_delete",
    "AWARD_EMOJI_ADD",
    "AWARD_EMOJI_DELETE",
    # Todo Mutations
    "todo_create",
    "todo_mark_done",
    "TODO_CREATE",
    "TODO_MARK_DONE",
    # Security Mutations
    "vulnerability_confirm",
    "vulnerability_resolve",
    "vulnerability_dismiss",
    "VULNERABILITY_CONFIRM",
    "VULNERABILITY_RESOLVE",
    "VULNERABILITY_DISMISS",
    # Member Mutations
    "group_member_add",
    "group_member_remove",
    "project_member_add",
    "project_member_remove",
    "GROUP_MEMBER_ADD",
    "GROUP_MEMBER_REMOVE",
    "PROJECT_MEMBER_ADD",
    "PROJECT_MEMBER_REMOVE",
    # Board Mutations
    "board_list_create",
    "board_list_update",
    "board_list_delete",
    "BOARD_LIST_CREATE",
    "BOARD_LIST_UPDATE",
    "BOARD_LIST_DELETE",
    # Iteration Mutations
    "iteration_create",
    "iteration_update",
    "ITERATION_CREATE",
    "ITERATION_UPDATE",
    # Work Item Mutations
    "work_item_create",
    "work_item_update",
    "work_item_delete",
    "WORK_ITEM_CREATE",
    "WORK_ITEM_UPDATE",
    "WORK_ITEM_DELETE",
    # CI/CD Advanced Mutations
    "job_cancel",
    "job_retry",
    "job_erase",
    "JOB_CANCEL",
    "JOB_RETRY",
    "JOB_ERASE",
    # Pipeline Schedule Mutations
    "pipeline_schedule_create",
    "pipeline_schedule_update",
    "pipeline_schedule_delete",
    "PIPELINE_SCHEDULE_CREATE",
    "PIPELINE_SCHEDULE_UPDATE",
    "PIPELINE_SCHEDULE_DELETE",
    # Environment Mutations
    "environment_create",
    "environment_update",
    "environment_delete",
    "ENVIRONMENT_CREATE",
    "ENVIRONMENT_UPDATE",
    "ENVIRONMENT_DELETE",
    # Variable Mutations
    "ci_variable_create",
    "ci_variable_update",
    "ci_variable_delete",
    "CI_VARIABLE_CREATE",
    "CI_VARIABLE_UPDATE",
    "CI_VARIABLE_DELETE",
    # Runner Mutations
    "runner_create",
    "runner_update",
    "runner_delete",
    "RUNNER_CREATE",
    "RUNNER_UPDATE",
    "RUNNER_DELETE",
    # Package Mutations
    "package_delete",
    "PACKAGE_DELETE",
    # File Upload Mutation
    "upload_file",
    "UPLOAD_FILE",
]
