"""
Enhanced GraphQL Client with Production Features

Extends the basic GraphQL client with:
- Query builder support
- Result caching
- Automatic retry
- Batch execution
- Logging and tracing
- Schema introspection
"""

from __future__ import annotations

import logging
import time
from collections.abc import AsyncIterator, Awaitable, Callable
from dataclasses import dataclass
from typing import TYPE_CHECKING, Any

import msgspec

from glabflow._errors import GraphQLError, RateLimitError, ServerError
from glabflow.graphql.builder import Query
from glabflow.graphql.builder import query as make_query
from glabflow.graphql.cache import CachePolicy, GraphQLCache
from glabflow.graphql.complexity import QueryComplexityAnalyzer
from glabflow.graphql.dataloader import (
    DataLoader,
    IssueDataLoader,
    ProjectDataLoader,
    UserDataLoader,
)
from glabflow.graphql.persistence import QueryPersistence
from glabflow.graphql.rate_limit import AutomaticThrottler, RateLimitTracker
from glabflow.graphql.subscriptions import SubscriptionManager

if TYPE_CHECKING:
    from glabflow._client import GitLabClient

# Cached msgspec decoder for performance (avoid recreation on each call)
_GRAPHQL_RESPONSE_DECODER = msgspec.json.Decoder(type=dict[str, object])

_ENDPOINT = "/api/graphql"


@dataclass
class QueryTrace:
    """Query execution trace."""

    operation_name: str
    query: str
    variables: dict[str, Any]
    start_time: float
    end_time: float
    duration_ms: float
    cached: bool
    error: str | None = None


@dataclass
class BatchQuery:
    """Batch query definition."""

    name: str
    query: str
    variables: dict[str, Any] | None = None


class GraphQLClient:
    """
    Production-ready GraphQL client for GitLab.

    Features:
    - Query builder DSL
    - Result caching with configurable TTL
    - Automatic retry with exponential backoff
    - Batch query execution
    - Query logging and tracing
    - Schema introspection helpers

    Access via ``gl.graphql``.
    """

    def __init__(self, client: GitLabClient) -> None:
        self._client = client
        self._cache = GraphQLCache()
        self._logger: logging.Logger | None = None
        self._trace_callback: Callable[..., Any] | None = None
        self._retry_config = {
            "max_attempts": 3,
            "base_delay": 1.0,
            "max_delay": 30.0,
            "exponential_base": 2.0,
        }
        self._enabled = True

        # New features
        self._complexity_analyzer = QueryComplexityAnalyzer()
        self._max_complexity: int | None = 1000
        self._throttler = AutomaticThrottler()
        self._persistence = QueryPersistence()
        self._rate_limit_tracker = RateLimitTracker()
        self._subscriptions = SubscriptionManager(self)

    @property
    def subscriptions(self) -> SubscriptionManager:
        """Access the subscription manager."""
        return self._subscriptions

    # ========== Configuration ==========

    def configure_cache(
        self,
        enabled: bool = True,
        ttl: int = 300,
        max_size: int = 1000,
    ) -> None:
        """
        Configure result caching.

        Args:
            enabled: Enable/disable caching
            ttl: Default time-to-live in seconds
            max_size: Maximum number of cached entries
        """
        self._cache.configure(enabled=enabled, default_ttl=ttl, max_size=max_size)

    def configure_retry(
        self,
        max_attempts: int = 3,
        base_delay: float = 1.0,
        max_delay: float = 30.0,
        exponential_base: float = 2,
    ) -> None:
        """
        Configure automatic retry.

        Args:
            max_attempts: Maximum retry attempts
            base_delay: Base delay in seconds
            max_delay: Maximum delay in seconds
            exponential_base: Exponential backoff base
        """
        self._retry_config = {
            "max_attempts": max_attempts,
            "base_delay": base_delay,
            "max_delay": max_delay,
            "exponential_base": exponential_base,
        }

    def configure_logging(
        self,
        logger: logging.Logger | None = None,
        level: int = logging.DEBUG,
        log_variables: bool = True,
        log_results: bool = False,
    ) -> None:
        """
        Configure query logging.

        Args:
            logger: Logger instance (creates default if None)
            level: Log level
            log_variables: Log query variables
            log_results: Log query results (careful with sensitive data)
        """
        if logger is None:
            logger = logging.getLogger("glabflow.graphql")
            logger.setLevel(level)
            if not logger.handlers:
                handler = logging.StreamHandler()
                handler.setLevel(level)
                formatter = logging.Formatter(
                    "%(asctime)s - %(name)s - %(levelname)s - %(message)s"
                )
                handler.setFormatter(formatter)
                logger.addHandler(handler)

        self._logger = logger
        self._log_variables = log_variables
        self._log_results = log_results

    def configure_tracing(
        self,
        enabled: bool = True,
        trace_callback: Callable[..., Any] | None = None,
    ) -> None:
        """
        Configure query tracing.

        Args:
            enabled: Enable/disable tracing
            trace_callback: Callback for each query trace
        """
        self._enabled = enabled
        self._trace_callback = trace_callback

    def configure_complexity(
        self,
        max_score: int | None = 1000,
        callback: Callable[..., Any] | None = None,
    ) -> None:
        """
        Configure query complexity analysis.

        Args:
            max_score: Maximum acceptable complexity score (None to disable)
            callback: Callback for complexity analysis results
        """
        self._max_complexity = max_score
        if callback:
            self._complexity_callback = callback

    def configure_rate_limiting(
        self,
        enabled: bool = True,
        min_delay: float = 0.1,
        max_delay: float = 5.0,
    ) -> None:
        """
        Configure automatic rate limiting.

        Args:
            enabled: Enable/disable rate limiting
            min_delay: Minimum delay between requests
            max_delay: Maximum delay between requests
        """
        self._throttler.configure(
            enabled=enabled, min_delay=min_delay, max_delay=max_delay
        )

    def configure_persistence(
        self,
        storage_path: str | None = None,
    ) -> None:
        """
        Configure query persistence.

        Args:
            storage_path: Path to store persisted queries
        """
        self._persistence = QueryPersistence(storage_path)

    # ========== Query Builder ==========

    def query(self, name: str | None = None) -> Query:
        """
        Create a new query builder.

        Args:
            name: Optional query name

        Returns:
            Query builder instance

        Example:
            q = gl.graphql.query("GetProject") \\
                .arg("fullPath", "$path", "ID!") \\
                .field("project", args={"fullPath": "$path"}) \\
                    .field("id") \\
                    .field("name") \\
                .end()

            result = await gl.graphql.execute(str(q), variables={"path": "group/project"})
        """
        return make_query(name)

    # ========== Execution ==========

    async def execute(
        self,
        query: str | Query,
        variables: dict[str, Any] | None = None,
        cache_policy: CachePolicy = CachePolicy.CACHE_FIRST,
        ttl: int | None = None,
        skip_complexity_check: bool = False,
    ) -> dict[str, Any]:
        """
        Execute a GraphQL query.

        Args:
            query: Query string or Query builder
            variables: Query variables
            cache_policy: Cache policy
            ttl: Cache TTL in seconds (for caching results)
            skip_complexity_check: Skip complexity analysis

        Returns:
            Query result data

        Raises:
            GraphQLError: If query fails
            ValueError: If query complexity exceeds maximum
        """
        # Convert Query builder to string
        if isinstance(query, Query):
            query_str = query.build()
        else:
            query_str = query

        # Check cache first — avoid regex for operation name on cache hits
        if cache_policy != CachePolicy.NETWORK_ONLY:
            cached_result = self._cache.get(query_str, variables)
            if cached_result is not None:
                if self._logger:
                    operation_name = self._extract_operation_name(query_str)
                    self._logger.debug(f"Cache hit for {operation_name}")
                return cached_result

        # Get operation name for logging (only needed for network calls)
        operation_name = self._extract_operation_name(query_str)

        if cache_policy == CachePolicy.CACHE_ONLY:
            raise GraphQLError(
                f"Query result not found in cache: {operation_name}",
                url=f"{self._client.base_url}{_ENDPOINT}",
            )

        # Analyze complexity
        if not skip_complexity_check and self._max_complexity:
            complexity = self._complexity_analyzer.analyze(query_str)
            if complexity.score > self._max_complexity:
                raise ValueError(
                    f"Query complexity ({complexity.score}) exceeds maximum "
                    f"({self._max_complexity}). Recommendations: "
                    f"{', '.join(complexity.recommendations)}"
                )
            if self._logger and complexity.warnings:
                for warning in complexity.warnings:
                    self._logger.warning(f"Complexity warning: {warning}")

        # Apply rate limiting
        await self._throttler.throttle()

        # Execute with retry
        start_time = time.time()
        error: str | None = None

        try:
            result = await self._execute_with_retry(query_str, variables)
        except Exception as e:
            error = str(e)
            raise
        finally:
            end_time = time.time()
            duration_ms = (end_time - start_time) * 1000

            # Trace
            if self._enabled and self._trace_callback:
                trace = QueryTrace(
                    operation_name=operation_name,
                    query=query_str,
                    variables=variables or {},
                    start_time=start_time,
                    end_time=end_time,
                    duration_ms=duration_ms,
                    cached=False,
                    error=error,
                )
                self._trace_callback(trace)

            # Log
            if self._logger:
                log_msg = f"{operation_name}: {duration_ms:.2f}ms"
                if error:
                    self._logger.error(f"{log_msg} - Error: {error}")
                else:
                    self._logger.debug(log_msg)
                    if self._log_variables and variables:
                        self._logger.debug(f"Variables: {variables}")

        # Update rate limit from result (if extensions present)
        if "result" in locals():
            self._rate_limit_tracker.update_from_result(result)
            self._throttler.update_from_result(result)

        # Cache result
        if cache_policy != CachePolicy.NETWORK_ONLY and not error:
            self._cache.set(query_str, result, variables, ttl=ttl)

        return result

    async def _execute_with_retry(
        self,
        query: str,
        variables: dict[str, Any] | None,
    ) -> dict[str, Any]:
        """Execute query with automatic retry."""
        last_error: Exception | None = None

        for attempt in range(self._retry_config["max_attempts"]):
            try:
                return await self._execute_single(query, variables)
            except (RateLimitError, ServerError) as e:
                last_error = e
                if attempt < self._retry_config["max_attempts"] - 1:
                    delay = min(
                        self._retry_config["base_delay"]
                        * (self._retry_config["exponential_base"] ** attempt),
                        self._retry_config["max_delay"],
                    )
                    if self._logger:
                        self._logger.warning(
                            f"Query failed (attempt {attempt + 1}), "
                            f"retrying in {delay:.1f}s: {e}"
                        )
                    await asyncio.sleep(delay)
                else:
                    raise

        raise GraphQLError(
            f"Query failed after {self._retry_config['max_attempts']} attempts",
            errors=[{"message": str(last_error)}],
            url=f"{self._client.base_url}{_ENDPOINT}",
        )

    async def _execute_single(
        self,
        query: str,
        variables: dict[str, Any] | None,
    ) -> dict[str, Any]:
        """Execute single query without retry."""
        payload: dict[str, Any] = {"query": query}
        if variables:
            payload["variables"] = variables

        raw = await self._client.post(_ENDPOINT, json=payload)
        # Use cached decoder for performance
        response: dict[str, Any] = _GRAPHQL_RESPONSE_DECODER.decode(raw)

        if errors := response.get("errors"):
            messages = "; ".join(
                e.get("message", str(e))
                for e in errors  # type: ignore[union-attr]
            )
            raise GraphQLError(
                messages,
                errors=list(errors),  # type: ignore[arg-type]
                url=f"{self._client.base_url}{_ENDPOINT}",
            )

        data = response.get("data")
        if data is None:
            raise GraphQLError(
                "GraphQL response missing 'data' field",
                url=f"{self._client.base_url}{_ENDPOINT}",
            )
        return data  # type: ignore[return-value]

    # ========== Batch Execution ==========

    async def execute_batch(
        self,
        queries: list[tuple[str, str | Query, dict[str, Any] | None]],
    ) -> dict[str, Any]:
        """
        Execute multiple queries in batch.

        Args:
            queries: List of (name, query, variables) tuples

        Returns:
            Dict mapping query names to results

        Example:
            results = await gl.graphql.execute_batch([
                ("project", project_query, {"path": "group/project"}),
                ("users", users_query, {}),
                ("groups", groups_query, {}),
            ])
            print(results["project"]["name"])
        """
        import asyncio

        # Build batch query
        batch_payload = []
        result_map = {}

        for name, q, variables in queries:
            query_str = q.build() if isinstance(q, Query) else q
            batch_payload.append(
                {
                    "name": name,
                    "query": query_str,
                    "variables": variables,
                }
            )

        # Execute all queries in parallel
        async def execute_named(
            name: str,
            query_str: str,
            variables: dict[str, Any] | None,
        ) -> tuple[str, Any]:
            try:
                result = await self.execute(query_str, variables)
                return (name, result)
            except Exception as e:
                return (name, {"__error__": str(e)})

        tasks = [
            execute_named(
                str(item["name"]),
                str(item["query"]),
                item["variables"] if isinstance(item["variables"], dict) else None,
            )
            for item in batch_payload
        ]
        results = await asyncio.gather(*tasks)

        for name, result in results:
            result_map[name] = result

        return result_map

    # ========== Streaming ==========

    async def stream(
        self,
        query: str | Query,
        connection_path: list[str],
        variables: dict[str, Any] | None = None,
        page_size: int = 100,
    ) -> AsyncIterator[dict[str, Any]]:
        """
        Stream nodes from a paginated GraphQL connection.

        Args:
            query: Query string or builder with $after and $first variables
            connection_path: Path to connection (e.g., ["project", "mergeRequests"])
            variables: Extra variables (after/first managed automatically)
            page_size: Items per page

        Yields:
            Each node from the connection
        """

        # Convert Query builder to string
        if isinstance(query, Query):
            query_str = query.build()
        else:
            query_str = query

        cursor: str | None = None
        # Pre-allocate base vars dict — avoids 100+ allocations on large streams
        base_vars: dict[str, Any] = {**(variables or {}), "first": page_size}

        while True:
            vars_: dict[str, Any] = (
                base_vars if cursor is None else {**base_vars, "after": cursor}
            )

            data = await self.execute(query_str, variables=vars_)

            # Navigate to connection
            connection: Any = data
            for key in connection_path:
                if not isinstance(connection, dict):
                    raise GraphQLError(
                        f"Expected dict at path step {key!r}",
                        url=f"{self._client.base_url}{_ENDPOINT}",
                    )
                connection = connection.get(key)
                if connection is None:
                    raise GraphQLError(
                        f"Path key {key!r} not found",
                        url=f"{self._client.base_url}{_ENDPOINT}",
                    )

            nodes = connection.get("nodes") or []
            for node in nodes:
                yield node

            page_info: dict[str, Any] = connection.get("pageInfo") or {}
            if not page_info.get("hasNextPage"):
                break

            cursor = page_info.get("endCursor")
            if not cursor:
                break

    # ========== Introspection ==========

    async def introspect_schema(self) -> dict[str, Any]:
        """
        Get full GraphQL schema via introspection.

        Returns:
            Schema introspection result
        """
        introspection_query = """
            query IntrospectionQuery {
                __schema {
                    queryType { name }
                    mutationType { name }
                    subscriptionType { name }
                    types {
                        ...FullType
                    }
                    directives {
                        name
                        description
                        locations
                        args {
                            ...InputValue
                        }
                    }
                }
            }

            fragment FullType on __Type {
                kind
                name
                description
                fields(includeDeprecated: true) {
                    name
                    args { ...InputValue }
                    type { ...TypeRef }
                    isDeprecated
                    deprecationReason
                }
                inputFields { ...InputValue }
                interfaces { ...TypeRef }
                enumValues(includeDeprecated: true) {
                    name
                    isDeprecated
                    deprecationReason
                }
                possibleTypes { ...TypeRef }
            }

            fragment InputValue on __InputValue {
                name
                description
                type { ...TypeRef }
                defaultValue
            }

            fragment TypeRef on __Type {
                kind
                name
                ofType {
                    kind
                    name
                    ofType {
                        kind
                        name
                        ofType {
                            kind
                            name
                        }
                    }
                }
            }
        """

        return await self.execute(introspection_query)

    async def has_type(self, type_name: str) -> bool:
        """Check if type exists in schema."""
        result = await self.execute(f"""
            {{
                __type(name: "{type_name}") {{
                    name
                }}
            }}
        """)
        return result.get("__type") is not None

    async def get_type_fields(self, type_name: str) -> list[dict[str, Any]]:
        """Get fields for a type."""
        result = await self.execute(f"""
            {{
                __type(name: "{type_name}") {{
                    fields {{
                        name
                        type {{
                            name
                            kind
                        }}
                    }}
                }}
            }}
        """)
        type_info = result.get("__type", {})
        return type_info.get("fields") or []

    async def has_field(self, type_name: str, field_name: str) -> bool:
        """Check if field exists on a type."""
        fields = await self.get_type_fields(type_name)
        return any(f["name"] == field_name for f in fields)

    # ========== Cache Management ==========

    def clear_cache(self) -> None:
        """Clear all cached results."""
        self._cache.clear()

    def get_cache_stats(self) -> dict[str, Any]:
        """Get cache statistics."""
        stats = self._cache.stats()
        return {
            "hits": stats.hits,
            "misses": stats.misses,
            "evictions": stats.evictions,
            "size": stats.size,
            "max_size": stats.max_size,
            "hit_rate": stats.hit_rate,
        }

    # ========== Persistence ==========

    def save_query(
        self,
        name: str,
        query: str | Query,
        description: str = "",
        tags: list[str] | None = None,
    ) -> None:
        """
        Save query for persistence.

        Args:
            name: Query name
            query: Query string or builder
            description: Query description
            tags: Query tags
        """
        from glabflow.graphql.persistence import PersistedQuery

        query_str = query.build() if isinstance(query, Query) else query
        persisted = PersistedQuery(
            name=name,
            query=query_str,
            description=description,
            tags=tags or [],
        )
        self._persistence.save(persisted)

    def load_query(self, name: str) -> str | None:
        """
        Load persisted query.

        Args:
            name: Query name

        Returns:
            Query string or None
        """
        persisted = self._persistence.get_by_name(name)
        return persisted.query if persisted else None

    def list_queries(self) -> list[str]:
        """List all persisted query names."""
        return [q.name for q in self._persistence.list_all()]

    # ========== Rate Limiting ==========

    def get_rate_limit_info(self) -> dict[str, Any]:
        """Get current rate limit information."""
        return self._rate_limit_tracker.get_stats()

    def get_throttle_stats(self) -> dict[str, Any]:
        """Get throttler statistics."""
        return self._throttler.get_stats()

    # ========== Complexity ==========

    def analyze_query_complexity(self, query: str | Query) -> dict[str, Any]:
        """
        Analyze query complexity.

        Args:
            query: Query string or builder

        Returns:
            Complexity analysis result
        """
        query_str = query.build() if isinstance(query, Query) else query
        result = self._complexity_analyzer.analyze(query_str)
        return {
            "score": result.score,
            "estimated_cost": result.estimated_cost,
            "field_count": result.field_count,
            "depth": result.depth,
            "breadth": result.breadth,
            "warnings": result.warnings,
            "recommendations": result.recommendations,
            "acceptable": self._complexity_analyzer.is_acceptable(result),
        }

    # ========== DataLoader ==========

    def create_data_loader(
        self,
        batch_fn: Callable[[list[Any]], Awaitable[list[Any]]] | None = None,
        max_batch_size: int = 100,
        batch_schedule_ms: int = 10,
        cache_enabled: bool = True,
    ) -> DataLoader[Any, Any]:
        """
        Create a generic DataLoader for custom batching.

        Args:
            batch_fn: Async function that takes keys and returns results
            max_batch_size: Maximum number of keys per batch
            batch_schedule_ms: Time to wait for batching (milliseconds)
            cache_enabled: Enable per-loader caching

        Returns:
            DataLoader instance

        Example:
            loader = gl.graphql.create_data_loader(
                batch_fn=my_batch_function,
                max_batch_size=50,
            )
            result = await loader.load("some-key")
        """
        return DataLoader(
            client=self,
            batch_fn=batch_fn,
            max_batch_size=max_batch_size,
            batch_schedule_ms=batch_schedule_ms,
            cache_enabled=cache_enabled,
        )

    def create_project_loader(
        self,
        max_batch_size: int = 100,
        cache_enabled: bool = True,
    ) -> ProjectDataLoader:
        """
        Create a DataLoader for fetching projects by path.

        Args:
            max_batch_size: Maximum projects per batch
            cache_enabled: Enable caching

        Returns:
            ProjectDataLoader instance

        Example:
            loader = gl.graphql.create_project_loader()
            project = await loader.load("group/project")
        """
        return ProjectDataLoader(
            client=self,
            max_batch_size=max_batch_size,
            cache_enabled=cache_enabled,
        )

    def create_user_loader(
        self,
        max_batch_size: int = 100,
        cache_enabled: bool = True,
    ) -> UserDataLoader:
        """
        Create a DataLoader for fetching users by ID.

        Args:
            max_batch_size: Maximum users per batch
            cache_enabled: Enable caching

        Returns:
            UserDataLoader instance

        Example:
            loader = gl.graphql.create_user_loader()
            user = await loader.load(123)
        """
        return UserDataLoader(
            client=self,
            max_batch_size=max_batch_size,
            cache_enabled=cache_enabled,
        )

    def create_issue_loader(
        self,
        project_path: str,
        max_batch_size: int = 100,
        cache_enabled: bool = True,
    ) -> IssueDataLoader:
        """
        Create a DataLoader for fetching issues by IID within a project.

        Args:
            project_path: GitLab project path (e.g., "group/project")
            max_batch_size: Maximum issues per batch
            cache_enabled: Enable caching

        Returns:
            IssueDataLoader instance

        Example:
            loader = gl.graphql.create_issue_loader("group/project")
            issue = await loader.load(456)  # issue IID
        """
        return IssueDataLoader(
            client=self,
            project_path=project_path,
            max_batch_size=max_batch_size,
            cache_enabled=cache_enabled,
        )

    # ========== Subscriptions ==========

    async def subscribe(
        self,
        query: str,
        connection_path: list[str] | None = None,
        variables: dict[str, Any] | None = None,
        poll_interval_ms: int = 5000,
        max_polls: int | None = None,
        deduplicate: bool = True,
    ) -> AsyncIterator[dict[str, Any]]:
        """
        Create a polling subscription for real-time updates.

        Args:
            query: GraphQL query string or builder
            connection_path: Path to connection for pagination
            variables: Query variables
            poll_interval_ms: Time between polls
            max_polls: Maximum number of polls (None = infinite)
            deduplicate: Skip duplicate results

        Yields:
            New or updated data on each poll

        Example:
            async for mr in gl.graphql.subscribe(
                query=gl.graphql.get_merge_requests(),
                connection_path=["project", "mergeRequests"],
                variables={"fullPath": "group/project"},
                poll_interval_ms=3000,
            ):
                print(f"New MR: {mr['title']}")
        """
        async for result in self._subscriptions.subscribe(
            query=query,
            connection_path=connection_path,
            variables=variables,
            poll_interval_ms=poll_interval_ms,
            max_polls=max_polls,
            deduplicate=deduplicate,
        ):
            yield result

    def unsubscribe_all(self) -> int:
        """
        Cancel all active subscriptions.

        Returns:
            Number of subscriptions cancelled
        """
        return self._subscriptions.unsubscribe_all()

    def get_active_subscriptions(self) -> list[dict[str, Any]]:
        """Get list of active subscriptions."""
        return self._subscriptions.get_active_subscriptions()

    # ========== Utilities ==========

    def _extract_operation_name(self, query: str) -> str:
        """Extract operation name from query."""
        import re

        match = re.search(r"(?:query|mutation|subscription)\s+(\w+)", query)
        if match:
            return match.group(1)
        return "anonymous"


# Import asyncio at module level for retry logic
import asyncio  # noqa: E402
