from __future__ import annotations

import asyncio
import hashlib
import hmac
from abc import ABC, abstractmethod
from collections.abc import AsyncIterator, Awaitable, Callable
from dataclasses import dataclass
from typing import Any

import aiohttp
import aiohttp.web
import msgspec

_GITLAB_EVENT_TYPES = {
    "push",
    "tag_push",
    "issue",
    "merge_request",
    "note",
    "pull_request",
    "milestone",
    "pipeline",
    "build",
    "system_hook",
    "wiki",
}

# Cached msgspec decoder for performance (avoid recreation on each call)
_WEBHOOK_RESPONSE_DECODER = msgspec.json.Decoder(type=dict[str, Any])


@dataclass
class GitLabWebhookEvent:
    event_type: str
    object_kind: str | None
    payload: dict[str, Any]


class EventHandler(ABC):
    @abstractmethod
    async def handle(self, event: GitLabWebhookEvent) -> None: ...


class WebhookServer:
    """
    Async webhook server for receiving GitLab events.

    Example — basic usage::

        async def on_push(event):
            print(f"Push to {event.payload['ref']}")

        server = WebhookServer("0.0.0.0", 8080, secret_token="secret")
        server.on("push", on_push)

        async with server:
            await server.serve_forever()

    Example — event streaming::

        server = WebhookServer("0.0.0.0", 8080)
        async with server:
            async for event in server.events():
                print(f"Received: {event.event_type}")
    """

    def __init__(
        self,
        host: str = "0.0.0.0",
        port: int = 8080,
        secret_token: str | None = None,
        ssl_context: Any = None,
    ) -> None:
        self._host = host
        self._port = port
        self._secret_token = secret_token
        self._ssl_context = ssl_context
        self._handlers: dict[str, list[EventHandler]] = {}
        self._event_queue: asyncio.Queue[GitLabWebhookEvent] | None = None
        self._server: asyncio.Server | None = None
        self._runner: aiohttp.web.AppRunner | None = None

    def on(
        self, event_type: str, handler: Callable[[GitLabWebhookEvent], Awaitable[None]]
    ) -> None:
        if event_type not in _GITLAB_EVENT_TYPES:
            raise ValueError(f"Unknown event type: {event_type}")
        if event_type not in self._handlers:
            self._handlers[event_type] = []

        class CallbackHandler(EventHandler):
            async def handle(self, event: GitLabWebhookEvent) -> None:
                await handler(event)

        self._handlers[event_type].append(CallbackHandler())

    def _verify_secret(self, payload: bytes, token: str | None) -> bool:
        if self._secret_token is None:
            return True
        if token is None:
            return False
        # GitLab sends HMAC-SHA256 signature of payload
        expected_signature = hmac.new(
            self._secret_token.encode()
            if isinstance(self._secret_token, str)
            else self._secret_token,
            payload,
            hashlib.sha256,
        ).hexdigest()
        return hmac.compare_digest(expected_signature, token)

    def _get_event_type(
        self, headers: dict[str, str], payload: dict[str, Any] | None = None
    ) -> str:
        """Extract event type from headers or payload."""
        event_type = headers.get("X-Gitlab-Event", "")
        if event_type:
            return self._normalize_event_type(event_type)
        if payload and "object_kind" in payload:
            return str(payload["object_kind"])
        return "unknown"

    def _normalize_event_type(self, event_type: str) -> str:
        """Normalize GitLab event type to internal format."""
        mapping = {
            "Push Hook": "push",
            "Tag Push Hook": "tag_push",
            "Issue Hook": "issue",
            "Merge Request Hook": "merge_request",
            "Note Hook": "note",
            "Pipeline Hook": "pipeline",
            "Wiki Page Hook": "wiki",
        }
        return mapping.get(event_type, "unknown")

    async def _dispatch_event(self, event: GitLabWebhookEvent) -> None:
        """Dispatch event to registered handlers."""
        handlers = self._handlers.get(event.event_type, [])
        for handler in handlers:
            try:
                await handler.handle(event)
            except Exception:
                pass

    async def _handle_request(
        self, request: aiohttp.web.Request
    ) -> aiohttp.web.Response:
        if request.method != "POST":
            return aiohttp.web.Response(status=405, text="Method Not Allowed")

        token = request.headers.get("X-Gitlab-Token")
        if not self._verify_secret(await request.read(), token):
            return aiohttp.web.Response(status=401, text="Unauthorized")

        event_type = request.headers.get("X-Gitlab-Event", "unknown")
        try:
            payload = await request.json()
        except Exception:
            return aiohttp.web.Response(status=400, text="Invalid JSON")

        event = GitLabWebhookEvent(
            event_type=event_type,
            object_kind=payload.get("object_kind"),
            payload=payload,
        )

        if self._event_queue is not None:
            await self._event_queue.put(event)

        await self._dispatch_event(event)

        return aiohttp.web.Response(status=200, text="OK")

    async def run(self) -> None:
        """Start the webhook server."""
        app = aiohttp.web.Application()
        app.router.add_post("/", self._handle_request)
        self._runner = aiohttp.web.AppRunner(app)
        await self._runner.setup()
        site = aiohttp.web.TCPSite(
            self._runner,
            self._host,
            self._port,
            ssl_context=self._ssl_context,
        )
        await site.start()

    async def stop(self) -> None:
        """Stop the webhook server."""
        if self._runner is not None:
            await self._runner.cleanup()
            self._runner = None

    async def events(self) -> AsyncIterator[GitLabWebhookEvent]:
        if self._event_queue is None:
            self._event_queue = asyncio.Queue()
        while True:
            yield await self._event_queue.get()

    async def __aenter__(self) -> WebhookServer:
        app = aiohttp.web.Application()
        app.router.add_post("/", self._handle_request)
        self._runner = aiohttp.web.AppRunner(app)
        site = aiohttp.web.TCPSite(
            self._runner,
            self._host,
            self._port,
            ssl_context=self._ssl_context,
        )
        await site.start()
        return self

    async def __aexit__(
        self,
        exc_type: type[BaseException] | None,
        exc_val: BaseException | None,
        exc_tb: Any,
    ) -> None:
        if self._runner is not None:
            await self._runner.cleanup()
            self._runner = None


class EventStream:
    """
    Manages a stream of GitLab events from webhooks.

    Example::

        stream = EventStream(gl, webhook_url="https://myapp.com/webhooks")
        await stream.start()
        async for event in stream.events():
            process(event)
    """

    def __init__(
        self,
        client: Any,
        webhook_url: str,
        secret_token: str | None = None,
    ) -> None:
        self._client = client
        self._webhook_url = webhook_url
        self._secret_token = secret_token
        self._events: asyncio.Queue[GitLabWebhookEvent] = asyncio.Queue()
        self._running = False

    async def start(self) -> None:
        self._running = True

    async def stop(self) -> None:
        self._running = False

    async def add_webhook(self, project_id: int, events: list[str]) -> dict[str, Any]:
        url = f"/api/v4/projects/{project_id}/hooks"
        payload = {
            "url": self._webhook_url,
            "token": self._secret_token,
            "events": events,
        }
        raw = await self._client.post(url, json=payload)
        # Use cached decoder for performance
        return _WEBHOOK_RESPONSE_DECODER.decode(raw)

    async def remove_webhook(self, project_id: int, hook_id: int) -> None:
        url = f"/api/v4/projects/{project_id}/hooks/{hook_id}"
        await self._client.post(url, json={"url": self._webhook_url})

    async def events(self) -> AsyncIterator[GitLabWebhookEvent]:
        while self._running:
            yield await self._events.get()
