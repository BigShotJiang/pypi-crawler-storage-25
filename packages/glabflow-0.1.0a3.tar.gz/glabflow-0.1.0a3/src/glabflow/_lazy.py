"""Lazy validation wrappers for maximum performance."""

from __future__ import annotations


class LazyDict:
    """Lazy dictionary wrapper that validates on access.

    Wraps a dict and validates fields only when accessed,
    providing type safety without upfront validation cost.
    """

    __slots__ = ("_data", "_validated")

    def __init__(self, data: dict):
        object.__setattr__(self, "_data", data)
        object.__setattr__(self, "_validated", set())

    def __getattr__(self, name: str):
        if name.startswith("_"):
            raise AttributeError(name)

        if name not in self._data:
            raise KeyError(f"Missing field: {name}")

        self._validated.add(name)
        return self._data[name]

    def __setattr__(self, name: str, value):
        if name.startswith("_"):
            object.__setattr__(self, name, value)
        else:
            self._data[name] = value
            self._validated.add(name)

    def __getitem__(self, key):
        return self.__getattr__(key)

    def __setitem__(self, key, value):
        self.__setattr__(key, value)

    def get(self, key, default=None):
        try:
            return self.__getattr__(key)
        except KeyError:
            return default

    def __contains__(self, key):
        return key in self._data

    def __repr__(self):
        return f"LazyDict({self._data})"

    def to_dict(self) -> dict:
        """Convert to regular dict."""
        return self._data.copy()


class LazyList:
    """Lazy list wrapper that wraps items in LazyDict.

    Wraps a list of dicts and provides lazy validation for each item.
    """

    __slots__ = ("_data",)

    def __init__(self, data: list):
        self._data = data

    def __iter__(self):
        for item in self._data:
            if isinstance(item, dict):
                yield LazyDict(item)
            else:
                yield item

    def __getitem__(self, index):
        item = self._data[index]
        if isinstance(item, dict):
            return LazyDict(item)
        return item

    def __len__(self):
        return len(self._data)

    def __repr__(self):
        return f"LazyList([{len(self._data)} items])"

    def to_list(self) -> list:
        """Convert to regular list."""
        return [
            item.to_dict() if isinstance(item, LazyDict) else item
            for item in self._data
        ]
