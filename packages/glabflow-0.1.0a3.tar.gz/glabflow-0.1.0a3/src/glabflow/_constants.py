"""
Glabflow constants and configuration defaults.

Centralizes all magic numbers, URLs, and defaults for easy configuration.
"""

from __future__ import annotations

import os

# ============================================================================
# GitLab API URLs
# ============================================================================

#: Default GitLab.com API URL
GITLAB_COM_URL = "https://gitlab.com/api/v4"

#: Default URL used when no environment variable is set
DEFAULT_GITLAB_URL = os.environ.get("GITLAB_URL", GITLAB_COM_URL)

#: Default localhost URL for development/testing
LOCALHOST_URL = "http://localhost:8765"


# ============================================================================
# Concurrency Defaults
# ============================================================================

#: Default concurrency for gitlab.com (conservative to respect rate limits)
GITLAB_COM_DEFAULT_CONCURRENCY = 20

#: Default concurrency for self-hosted instances
DEFAULT_CONCURRENCY = 100

#: Maximum recommended concurrency
MAX_CONCURRENCY = 200

#: Concurrency for aggressive/turbo modes
AGGRESSIVE_CONCURRENCY = 200


# ============================================================================
# Pagination Defaults
# ============================================================================

#: Default items per page (GitLab API maximum)
DEFAULT_PER_PAGE = 100

#: Small page size for testing/demo
SMALL_PER_PAGE = 20

#: Maximum items per page allowed by GitLab API
MAX_PER_PAGE = 100


# ============================================================================
# Timeout Defaults
# ============================================================================

#: Default request timeout in seconds
DEFAULT_TIMEOUT = 30

#: Timeout for long-running operations
LONG_TIMEOUT = 120

#: Timeout for quick operations
SHORT_TIMEOUT = 10


# ============================================================================
# Authentication Headers
# ============================================================================

#: Private token header (personal access tokens)
PRIVATE_TOKEN_HEADER = "PRIVATE-TOKEN"

#: Authorization header (OAuth/bearer tokens)
AUTHORIZATION_HEADER = "Authorization"

#: Bearer token prefix
BEARER_PREFIX = "Bearer"


# ============================================================================
# Cache Defaults
# ============================================================================

#: Default cache TTL in seconds
DEFAULT_CACHE_TTL = 300

#: Default cache size (number of entries)
DEFAULT_CACHE_SIZE = 256


# ============================================================================
# Retry Defaults
# ============================================================================

#: Default number of retries
DEFAULT_RETRIES = 3

#: Default retry backoff factor
DEFAULT_BACKOFF_FACTOR = 2.0

#: Maximum retry delay in seconds
MAX_RETRY_DELAY = 60


# ============================================================================
# Prefetch Defaults
# ============================================================================

#: Default number of pages to prefetch
DEFAULT_PREFETCH_PAGES = 2

#: Disable prefetching
NO_PREFETCH = 0


# ============================================================================
# Benchmark/Testing Defaults
# ============================================================================

#: Default user limit for benchmarks
DEFAULT_BENCHMARK_USER_LIMIT = 500

#: Default benchmark iterations
DEFAULT_BENCHMARK_ITERATIONS = 5

#: Default benchmark concurrency
DEFAULT_BENCHMARK_CONCURRENCY = 200


# ============================================================================
# GitLab Version
# ============================================================================

#: Target GitLab version (auto-detected if not set)
GITLAB_VERSION = os.environ.get("GITLAB_VERSION", "18.x")


# ============================================================================
# Helper Functions
# ============================================================================


def get_gitlab_url() -> str:
    """Get GitLab API URL from environment or default.

    Returns:
        GitLab API URL
    """
    return os.environ.get("GITLAB_URL", GITLAB_COM_URL)


def get_gitlab_token() -> str:
    """Get GitLab API token from environment.

    Returns:
        GitLab API token

    Raises:
        ValueError: If GITLAB_TOKEN environment variable is not set
    """
    token = os.environ.get("GITLAB_TOKEN")
    if not token:
        raise ValueError(
            "GITLAB_TOKEN environment variable is required. "
            "Set it with: export GITLAB_TOKEN='your-token-here'"
        )
    return token


def get_gitlab_token_optional() -> str | None:
    """Get GitLab API token from environment (optional).

    Returns:
        GitLab API token or None
    """
    return os.environ.get("GITLAB_TOKEN")
