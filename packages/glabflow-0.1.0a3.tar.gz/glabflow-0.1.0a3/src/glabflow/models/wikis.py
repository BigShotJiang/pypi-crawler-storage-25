from __future__ import annotations

import msgspec


def decode_wiki(data: bytes) -> Wiki:
    """Decode a single Wiki from JSON bytes."""
    return _wiki_decoder.decode(data)


def decode_wiki_list(data: bytes) -> list[Wiki]:
    """Decode a list of Wiki from JSON bytes."""
    return _wiki_list_decoder.decode(data)


def decode_wiki_page(data: bytes) -> WikiPage:
    """Decode a single WikiPage from JSON bytes."""
    return _wiki_page_decoder.decode(data)


def decode_wiki_page_list(data: bytes) -> list[WikiPage]:
    """Decode a list of WikiPage from JSON bytes."""
    return _wiki_page_list_decoder.decode(data)


class Wiki(msgspec.Struct, gc=False, kw_only=True):
    """GitLab wikis model."""

    slug: str = ""
    title: str = ""
    format: str = ""
    content: str | None = None
    url: str = ""


class WikiPage(msgspec.Struct, gc=False, kw_only=True):
    """GitLab wiki page model."""

    slug: str = ""
    title: str = ""


_wiki_decoder = msgspec.json.Decoder(Wiki)
_wiki_list_decoder = msgspec.json.Decoder(list[Wiki])
_wiki_page_decoder = msgspec.json.Decoder(WikiPage)
_wiki_page_list_decoder = msgspec.json.Decoder(list[WikiPage])
