from __future__ import annotations

import msgspec


class RegistryRepositorie(msgspec.Struct, gc=False, kw_only=True):
    """GitLab registry_repositories model."""

    id: int = 0
    name: str = ""
    path: str = ""
    project_id: int = 0
    location: str = ""
    created_at: str = ""
    cleanup_policy_started_at: str | None = None
    tags_count: int = 0
    repository_storage: str = ""
    full_path: str = ""
