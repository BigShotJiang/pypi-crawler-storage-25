from __future__ import annotations

import msgspec


class PushRule(msgspec.Struct, gc=False, kw_only=True):
    """GitLab push_rules model."""

    id: int = 0
    created_at: str = ""
    commit_message_regex: str | None = None
    commit_message_negative_regex: str | None = None
    branch_name_regex: str | None = None
    deny_delete_tag: bool = False
    member_check: bool = False
    prevent_secrets: bool = False
    author_email_regex: str | None = None
    file_name_regex: str | None = None
    max_file_size: int = 0
    commit_committer_check: bool = False
    commit_committer_name_check: bool = False
    reject_unsigned_commits: bool = False
    pipeline_test_minimum_coverage: float | None = None
    pipeline_test_minimum_coverage_enforcement: str | None = None
    pipeline_test_minimum_coverage_enforcement_projects: list[dict] = []
    pipeline_test_minimum_coverage_enforcement_groups: list[dict] = []
    pipeline_test_minimum_coverage_enforcement_users: list[dict] = []
    pipeline_test_minimum_coverage_enforcement_roles: list[dict] = []
    pipeline_test_minimum_coverage_enforcement_labels: list[dict] = []
    pipeline_test_minimum_coverage_enforcement_milestones: list[dict] = []
    pipeline_test_minimum_coverage_enforcement_iterations: list[dict] = []
    pipeline_test_minimum_coverage_enforcement_epics: list[dict] = []
    pipeline_test_minimum_coverage_enforcement_boards: list[dict] = []
    pipeline_test_minimum_coverage_enforcement_sprints: list[dict] = []
    pipeline_test_minimum_coverage_enforcement_releases: list[dict] = []
    pipeline_test_minimum_coverage_enforcement_environments: list[dict] = []
    pipeline_test_minimum_coverage_enforcement_deployments: list[dict] = []
    pipeline_test_minimum_coverage_enforcement_pipelines: list[dict] = []
    pipeline_test_minimum_coverage_enforcement_jobs: list[dict] = []
    pipeline_test_minimum_coverage_enforcement_runners: list[dict] = []
    pipeline_test_minimum_coverage_enforcement_triggers: list[dict] = []
    pipeline_test_minimum_coverage_enforcement_variables: list[dict] = []
    pipeline_test_minimum_coverage_enforcement_schedules: list[dict] = []
    pipeline_test_minimum_coverage_enforcement_clusters: list[dict] = []
    pipeline_test_minimum_coverage_enforcement_packages: list[dict] = []
    pipeline_test_minimum_coverage_enforcement_registries: list[dict] = []
    pipeline_test_minimum_coverage_enforcement_snippets: list[dict] = []
    pipeline_test_minimum_coverage_enforcement_wikis: list[dict] = []
    pipeline_test_minimum_coverage_enforcement_boards: list[dict] = []
    pipeline_test_minimum_coverage_enforcement_sprints: list[dict] = []
    pipeline_test_minimum_coverage_enforcement_iterations: list[dict] = []
    pipeline_test_minimum_coverage_enforcement_epics: list[dict] = []
    pipeline_test_minimum_coverage_enforcement_releases: list[dict] = []
    pipeline_test_minimum_coverage_enforcement_environments: list[dict] = []
    pipeline_test_minimum_coverage_enforcement_deployments: list[dict] = []
    pipeline_test_minimum_coverage_enforcement_pipelines: list[dict] = []
    pipeline_test_minimum_coverage_enforcement_jobs: list[dict] = []
    pipeline_test_minimum_coverage_enforcement_runners: list[dict] = []
    pipeline_test_minimum_coverage_enforcement_triggers: list[dict] = []
    pipeline_test_minimum_coverage_enforcement_variables: list[dict] = []
    pipeline_test_minimum_coverage_enforcement_schedules: list[dict] = []
    pipeline_test_minimum_coverage_enforcement_clusters: list[dict] = []
    pipeline_test_minimum_coverage_enforcement_packages: list[dict] = []
    pipeline_test_minimum_coverage_enforcement_registries: list[dict] = []
    pipeline_test_minimum_coverage_enforcement_snippets: list[dict] = []
    pipeline_test_minimum_coverage_enforcement_wikis: list[dict] = []
