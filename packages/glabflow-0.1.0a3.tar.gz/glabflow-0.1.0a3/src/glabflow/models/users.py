from __future__ import annotations

import msgspec


def decode_user(data: bytes) -> User:
    """Decode a single User from JSON bytes."""
    return _user_decoder.decode(data)


def decode_user_list(data: bytes) -> list[User]:
    """Decode a list of User from JSON bytes."""
    return _user_list_decoder.decode(data)


class User(msgspec.Struct, gc=False, kw_only=True):
    """GitLab users model."""

    id: int = 0
    username: str = ""
    email: str = ""
    name: str = ""
    state: str = ""
    locked: bool = False
    avatar_url: str | None = None
    web_url: str = ""
    created_at: str = ""
    bio: str | None = None
    location: str | None = None
    public_email: str | None = None
    skype: str | None = None
    linkedin: str | None = None
    twitter: str | None = None
    website_url: str | None = None
    organization: str | None = None
    job_title: str | None = None
    pronouns: str | None = None
    bot: bool = False
    local_time: str | None = None
    last_sign_in_at: str | None = None
    confirmed_at: str | None = None
    last_activity_on: str | None = None
    color_scheme_id: int = 0
    theme_id: int = 0
    is_admin: bool = False
    is_external: bool = False


_user_decoder = msgspec.json.Decoder(User)
_user_list_decoder = msgspec.json.Decoder(list[User])
