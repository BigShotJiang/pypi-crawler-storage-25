from __future__ import annotations

import msgspec


def decode_issue(data: bytes) -> Issue:
    """Decode a single Issue from JSON bytes."""
    return _issue_decoder.decode(data)


def decode_issue_list(data: bytes) -> list[Issue]:
    """Decode a list of Issue from JSON bytes."""
    return _issue_list_decoder.decode(data)


class Issue(msgspec.Struct, gc=False, kw_only=True):
    """GitLab issues model."""

    id: int = 0
    iid: int = 0
    project_id: int = 0
    title: str = ""
    description: str | None = None
    state: str = ""
    created_at: str = ""
    updated_at: str = ""
    closed_at: str | None = None
    closed_by: dict | None = None
    labels: list[str] = []
    milestone: dict | None = None
    assignees: list[dict] = []
    assignee: dict | None = None
    author: dict = {}
    type: str | None = None
    user_notes_count: int = 0
    url: str = ""
    total_time_spent: int = 0
    time_estimate: int = 0
    estimated_time_remaining: int = 0
    human_total_time_spent: str | None = None
    human_time_estimate: str | None = None
    confidential: bool = False
    discussion_locked: bool = False
    due_date: str | None = None
    web_url: str = ""
    issue_type: str = ""
    severity: str = ""
    references: dict = {}
    moved_to_id: int | None = None
    service_desk_reply_to: str | None = None
    iteration: dict | None = None
    epic: dict | None = None


_issue_decoder = msgspec.json.Decoder(Issue)
_issue_list_decoder = msgspec.json.Decoder(list[Issue])
