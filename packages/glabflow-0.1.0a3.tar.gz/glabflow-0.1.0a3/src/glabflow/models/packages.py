from __future__ import annotations

import msgspec


class Package(msgspec.Struct, gc=False, kw_only=True):
    """GitLab packages model."""

    id: int = 0
    name: str = ""
    version: str = ""
    package_type: str = ""
    status: str = ""
    _links: dict = {}
    created_at: str = ""
    last_downloaded_at: str | None = None
    tags: list[dict] = []
