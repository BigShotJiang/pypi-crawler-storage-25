"""Alias for pipelines module - backwards compatibility."""

from .pipelines import (
    Pipeline,
    TestReport,
    TestReportSummary,
    decode_pipeline,
    decode_pipeline_list,
)

__all__ = [
    "Pipeline",
    "TestReport",
    "TestReportSummary",
    "decode_pipeline",
    "decode_pipeline_list",
]
