from __future__ import annotations

import msgspec


class ProtectedBranche(msgspec.Struct, gc=False, kw_only=True):
    """GitLab protected_branches model."""

    id: int = 0
    name: str = ""
    push_access_levels: list[dict] = []
    merge_access_levels: list[dict] = []
    unprotect_access_levels: list[dict] = []
    allow_force_push: bool = False
    code_owner_approval_required: bool = False
    prevent_stale_commits: bool = False
    allowed_to_push: list[dict] = []
    allowed_to_merge: list[dict] = []
    allowed_to_unprotect: list[dict] = []
