from __future__ import annotations

import msgspec


class LdapGroup(msgspec.Struct, gc=False, kw_only=True):
    """GitLab ldap_groups model."""

    name: str = ""
    filter: str | None = None
    group_access: int = 0
    provider: str = ""
    id: int | None = None
