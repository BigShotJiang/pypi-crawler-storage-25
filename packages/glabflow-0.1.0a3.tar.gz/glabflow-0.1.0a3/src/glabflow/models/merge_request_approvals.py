from __future__ import annotations

import msgspec


class MergeRequestApproval(msgspec.Struct, gc=False, kw_only=True):
    """GitLab merge_request_approvals model."""

    id: int = 0
    project_id: int = 0
    title: str = ""
    merge_requests_count: int = 0
    user_ids: list[int] = []
    group_ids: list[int] = []
    protected_branch_ids: list[int] = []
    contains_hidden_groups: bool = False
    approvals_required: int = 0
    rule_type: str = ""
    eligible_approvers: list[dict] = []
    approved_by: list[dict] = []
    approval_project_rule_id: int | None = None
