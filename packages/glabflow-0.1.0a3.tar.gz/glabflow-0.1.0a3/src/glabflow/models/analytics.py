from __future__ import annotations

import msgspec


def decode_code_coverage_activity(data: bytes) -> CodeCoverageActivity:
    """Decode a single CodeCoverageActivity from JSON bytes."""
    return _code_coverage_activity_decoder.decode(data)


def decode_code_coverage_activity_list(data: bytes) -> list[CodeCoverageActivity]:
    """Decode a list of CodeCoverageActivity from JSON bytes."""
    return _code_coverage_activity_list_decoder.decode(data)


def decode_contribution_stats(data: bytes) -> ContributionStats:
    """Decode a single ContributionStats from JSON bytes."""
    return _contribution_stats_decoder.decode(data)


def decode_contribution_stats_list(data: bytes) -> list[ContributionStats]:
    """Decode a list of ContributionStats from JSON bytes."""
    return _contribution_stats_list_decoder.decode(data)


class CodeCoverageActivity(msgspec.Struct, gc=False, kw_only=True):
    """Code coverage activity entry for a project."""

    project_id: int = 0
    build_id: int = 0
    build_url: str = ""
    ref_path: str = ""
    coverage: str = ""
    date: str = ""


class ContributionStats(msgspec.Struct, gc=False, kw_only=True):
    """Contribution analytics entry for a group member."""

    author_name: str = ""
    author_id: int = 0
    commits: int = 0
    additions: int = 0
    deletions: int = 0


_code_coverage_activity_decoder = msgspec.json.Decoder(CodeCoverageActivity)
_code_coverage_activity_list_decoder = msgspec.json.Decoder(list[CodeCoverageActivity])
_contribution_stats_decoder = msgspec.json.Decoder(ContributionStats)
_contribution_stats_list_decoder = msgspec.json.Decoder(list[ContributionStats])
