from __future__ import annotations

import msgspec


class Iteration(msgspec.Struct, gc=False, kw_only=True):
    """GitLab iterations model."""

    id: int = 0
    iid: int = 0
    group_id: int = 0
    title: str = ""
    description: str | None = None
    state: str = ""
    created_at: str = ""
    updated_at: str = ""
    starts_at: str | None = None
    ends_at: str | None = None
    duration: int | None = None
    iteration_type: int = 0
    parent_id: int | None = None
    path: str = ""
    progress: dict = {}
    web_url: str = ""
