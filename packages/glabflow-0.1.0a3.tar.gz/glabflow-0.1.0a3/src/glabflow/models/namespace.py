"""Alias for namespaces module - backwards compatibility."""

from .namespaces import (
    DeployKey,
    Namespace,
    decode_deploy_key,
    decode_deploy_key_list,
    decode_namespace,
    decode_namespace_list,
)

__all__ = [
    "DeployKey",
    "Namespace",
    "decode_deploy_key",
    "decode_deploy_key_list",
    "decode_namespace",
    "decode_namespace_list",
]
