from __future__ import annotations

import msgspec


class CoverageDefinition(msgspec.Struct, gc=False, kw_only=True):
    """GitLab coverage_definitions model."""

    id: int = 0
    project_id: int = 0
    coverage_regex: str = ""
    coverage_type: str = ""
    created_at: str = ""
    updated_at: str = ""
