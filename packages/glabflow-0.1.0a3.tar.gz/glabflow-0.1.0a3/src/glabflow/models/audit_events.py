from __future__ import annotations

import msgspec


class AuditEvent(msgspec.Struct, gc=False, kw_only=True):
    """GitLab audit_events model."""

    id: int = 0
    author: dict = {}
    author_details: dict = {}
    entity_type: str = ""
    entity_id: int = 0
    entity_path: str = ""
    created_at: str = ""
    events: list[dict] = []
    ip_address: str | None = None
    entity_title: str | None = None
