from __future__ import annotations

import msgspec


class Signature(msgspec.Struct, gc=False, kw_only=True):
    """GitLab signatures model."""

    id: int = 0
    signature: str = ""
    signing_key: dict | None = None
    verified: bool = False
    verification_status: str | None = None
    created_at: str = ""
