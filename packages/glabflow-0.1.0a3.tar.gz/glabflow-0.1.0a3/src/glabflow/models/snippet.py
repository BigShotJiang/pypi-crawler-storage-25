"""Alias for snippets module - backwards compatibility."""

from .snippets import Snippet, decode_snippet, decode_snippet_list

__all__ = ["Snippet", "decode_snippet", "decode_snippet_list"]
