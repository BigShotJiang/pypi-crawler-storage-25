from __future__ import annotations

import msgspec


def decode_tag(data: bytes) -> Tag:
    """Decode a single Tag from JSON bytes."""
    return _tag_decoder.decode(data)


def decode_tag_list(data: bytes) -> list[Tag]:
    """Decode a list of Tag from JSON bytes."""
    return _tag_list_decoder.decode(data)


class Tag(msgspec.Struct, gc=False, kw_only=True):
    """GitLab tags model."""

    name: str = ""
    message: str | None = None
    target: str | dict = ""
    commit: dict = {}
    release: dict | None = None
    protected: bool = False


_tag_decoder = msgspec.json.Decoder(Tag)
_tag_list_decoder = msgspec.json.Decoder(list[Tag])
