from __future__ import annotations

import msgspec


def decode_dora_metric(data: bytes) -> DoraMetric:
    """Decode a single DoraMetric from JSON bytes."""
    return _dora_metric_decoder.decode(data)


def decode_dora_list(data: bytes) -> list[DoraMetric]:
    """Decode a list of DoraMetric from JSON bytes."""
    return _dora_list_decoder.decode(data)


class DoraMetric(msgspec.Struct, gc=False, kw_only=True):
    """A single DORA metric data point."""

    date: str = ""
    value: float = 0.0


_dora_metric_decoder = msgspec.json.Decoder(DoraMetric)
_dora_list_decoder = msgspec.json.Decoder(list[DoraMetric])
