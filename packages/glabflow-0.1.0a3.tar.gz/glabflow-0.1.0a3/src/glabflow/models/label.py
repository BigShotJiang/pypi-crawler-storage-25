"""Alias for labels module - backwards compatibility."""

from .labels import Label, decode_label, decode_label_list

__all__ = ["Label", "decode_label", "decode_label_list"]
