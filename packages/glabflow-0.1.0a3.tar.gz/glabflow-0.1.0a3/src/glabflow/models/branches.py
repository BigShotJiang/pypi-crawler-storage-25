from __future__ import annotations

import msgspec


def decode_branche(data: bytes) -> Branche:
    """Decode a single Branche from JSON bytes."""
    return _branche_decoder.decode(data)


def decode_branche_list(data: bytes) -> list[Branche]:
    """Decode a list of Branche from JSON bytes."""
    return _branche_list_decoder.decode(data)


def decode_protected_branche(data: bytes) -> ProtectedBranche:
    """Decode a single ProtectedBranche from JSON bytes."""
    return _protected_branche_decoder.decode(data)


def decode_protected_branche_list(data: bytes) -> list[ProtectedBranche]:
    """Decode a list of ProtectedBranche from JSON bytes."""
    return _protected_branche_list_decoder.decode(data)


def decode_commit_ref(data: bytes) -> CommitRef:
    """Decode a single CommitRef from JSON bytes."""
    return _commit_ref_decoder.decode(data)


def decode_commit_ref_list(data: bytes) -> list[CommitRef]:
    """Decode a list of CommitRef from JSON bytes."""
    return _commit_ref_list_decoder.decode(data)


class Branche(msgspec.Struct, gc=False, kw_only=True):
    """GitLab branches model."""

    name: str = ""
    merged: bool = False
    protected: bool = False
    default: bool = False
    web_url: str = ""
    commit: dict = {}
    developers_can_push: bool = False
    developers_can_merge: bool = False
    can_push: bool = False


class ProtectedBranche(msgspec.Struct, gc=False, kw_only=True):
    """GitLab protected branches model."""

    name: str = ""
    protected: bool = False
    developers_can_push: bool = False
    developers_can_merge: bool = False
    can_push: bool = False


class CommitRef(msgspec.Struct, gc=False, kw_only=True):
    """GitLab commit reference model."""

    id: str = ""
    short_id: str = ""
    title: str = ""


_branche_decoder = msgspec.json.Decoder(Branche)
_branche_list_decoder = msgspec.json.Decoder(list[Branche])
_protected_branche_decoder = msgspec.json.Decoder(ProtectedBranche)
_protected_branche_list_decoder = msgspec.json.Decoder(list[ProtectedBranche])
_commit_ref_decoder = msgspec.json.Decoder(CommitRef)
_commit_ref_list_decoder = msgspec.json.Decoder(list[CommitRef])
