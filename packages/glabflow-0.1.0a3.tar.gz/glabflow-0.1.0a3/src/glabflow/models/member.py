"""Alias for members module - backwards compatibility."""

from .members import Member, decode_member, decode_member_list

__all__ = ["Member", "decode_member", "decode_member_list"]
