"""Alias for jobs module - backwards compatibility."""

from .jobs import (
    Job,
    Runner,
    decode_job,
    decode_job_list,
    decode_runner,
    decode_runner_list,
)

__all__ = [
    "Job",
    "Runner",
    "decode_job",
    "decode_job_list",
    "decode_runner",
    "decode_runner_list",
]
