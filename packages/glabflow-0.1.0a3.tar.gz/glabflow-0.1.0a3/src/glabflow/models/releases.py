from __future__ import annotations

import msgspec


def decode_release(data: bytes) -> Release:
    """Decode a single Release from JSON bytes."""
    return _release_decoder.decode(data)


def decode_release_list(data: bytes) -> list[Release]:
    """Decode a list of Release from JSON bytes."""
    return _release_list_decoder.decode(data)


def decode_release_link(data: bytes) -> ReleaseLink:
    """Decode a single ReleaseLink from JSON bytes."""
    return _release_link_decoder.decode(data)


def decode_release_link_list(data: bytes) -> list[ReleaseLink]:
    """Decode a list of ReleaseLink from JSON bytes."""
    return _release_link_list_decoder.decode(data)


class Release(msgspec.Struct, gc=False, kw_only=True):
    """GitLab releases model."""

    tag_name: str = ""
    description: str = ""
    name: str = ""
    created_at: str = ""
    released_at: str = ""
    upcoming_release: bool = False
    author: dict = {}
    commit: dict = {}
    milestones: list[dict] = []
    commit_path: str = ""
    tag_path: str = ""
    assets: dict | None = None
    evidence: dict | None = None
    _links: dict = {}
    user_can_create_release_branch: bool = False
    release_branch: str | None = None
    signed_by: dict | None = None


class ReleaseLink(msgspec.Struct, gc=False, kw_only=True):
    """GitLab release link model."""

    id: int = 0
    name: str = ""
    url: str = ""
    external: bool = False
    link_type: str = ""


_release_decoder = msgspec.json.Decoder(Release)
_release_list_decoder = msgspec.json.Decoder(list[Release])
_release_link_decoder = msgspec.json.Decoder(ReleaseLink)
_release_link_list_decoder = msgspec.json.Decoder(list[ReleaseLink])
