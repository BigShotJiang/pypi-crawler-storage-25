from __future__ import annotations

import msgspec


def decode_snippet(data: bytes) -> Snippet:
    """Decode a single Snippet from JSON bytes."""
    return _snippet_decoder.decode(data)


def decode_snippet_list(data: bytes) -> list[Snippet]:
    """Decode a list of Snippet from JSON bytes."""
    return _snippet_list_decoder.decode(data)


class Snippet(msgspec.Struct, gc=False, kw_only=True):
    """GitLab snippets model."""

    id: int = 0
    title: str = ""
    file_name: str = ""
    description: str | None = None
    visibility: str = ""
    author: dict = {}
    created_at: str = ""
    updated_at: str = ""
    project_id: int | None = None
    web_url: str = ""
    raw_url: str = ""
    files: list[dict] = []
    repository_storage: str = ""


_snippet_decoder = msgspec.json.Decoder(Snippet)
_snippet_list_decoder = msgspec.json.Decoder(list[Snippet])
