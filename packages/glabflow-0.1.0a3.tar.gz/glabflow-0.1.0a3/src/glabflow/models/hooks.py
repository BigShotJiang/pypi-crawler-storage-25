from __future__ import annotations

import msgspec


def decode_hook(data: bytes) -> Hook:
    """Decode a single Hook from JSON bytes."""
    return _hook_decoder.decode(data)


def decode_hook_list(data: bytes) -> list[Hook]:
    """Decode a list of Hook from JSON bytes."""
    return _hook_list_decoder.decode(data)


def decode_group_hook(data: bytes) -> GroupHook:
    """Decode a single GroupHook from JSON bytes."""
    return _group_hook_decoder.decode(data)


def decode_group_hook_list(data: bytes) -> list[GroupHook]:
    """Decode a list of GroupHook from JSON bytes."""
    return _group_hook_list_decoder.decode(data)


def decode_project_hook(data: bytes) -> ProjectHook:
    """Decode a single ProjectHook from JSON bytes."""
    return _project_hook_decoder.decode(data)


def decode_project_hook_list(data: bytes) -> list[ProjectHook]:
    """Decode a list of ProjectHook from JSON bytes."""
    return _project_hook_list_decoder.decode(data)


class Hook(msgspec.Struct, gc=False, kw_only=True):
    """GitLab hooks model."""

    id: int = 0
    url: str = ""
    push_events: bool = False
    push_events_branch_filter: str = ""
    issues_events: bool = False
    confidential_issues_events: bool = False
    merge_requests_events: bool = False
    tag_push_events: bool = False
    note_events: bool = False
    job_events: bool = False
    pipeline_events: bool = False
    wiki_page_events: bool = False
    deployment_events: bool = False
    releases_events: bool = False
    subgroups_events: bool = False
    confidential_note_events: bool = False
    created_at: str = ""
    enable_ssl_verification: bool = False
    token: str | None = None
    project_id: int | None = None
    group_id: int | None = None
    system_hook: bool = False
    resource_access_token_events: bool = False
    member_events: bool = False


class GroupHook(msgspec.Struct, gc=False, kw_only=True):
    """GitLab group hook model."""

    id: int = 0
    url: str = ""
    push_events: bool = False
    issues_events: bool = False
    confidential_issues_events: bool = False
    merge_requests_events: bool = False
    tag_push_events: bool = False
    note_events: bool = False
    job_events: bool = False
    pipeline_events: bool = False
    wiki_page_events: bool = False
    deployment_events: bool = False
    releases_events: bool = False
    subgroups_events: bool = False
    confidential_note_events: bool = False
    created_at: str = ""
    enable_ssl_verification: bool = False
    token: str | None = None
    group_id: int | None = None
    resource_access_token_events: bool = False
    member_events: bool = False


class ProjectHook(msgspec.Struct, gc=False, kw_only=True):
    """GitLab project hook model."""

    id: int = 0
    url: str = ""
    push_events: bool = False
    issues_events: bool = False
    confidential_issues_events: bool = False
    merge_requests_events: bool = False
    tag_push_events: bool = False
    note_events: bool = False
    job_events: bool = False
    pipeline_events: bool = False
    wiki_page_events: bool = False
    deployment_events: bool = False
    releases_events: bool = False
    subgroups_events: bool = False
    confidential_note_events: bool = False
    created_at: str = ""
    enable_ssl_verification: bool = False
    token: str | None = None
    project_id: int | None = None
    resource_access_token_events: bool = False
    member_events: bool = False


_hook_decoder = msgspec.json.Decoder(Hook)
_hook_list_decoder = msgspec.json.Decoder(list[Hook])
_group_hook_decoder = msgspec.json.Decoder(GroupHook)
_group_hook_list_decoder = msgspec.json.Decoder(list[GroupHook])
_project_hook_decoder = msgspec.json.Decoder(ProjectHook)
_project_hook_list_decoder = msgspec.json.Decoder(list[ProjectHook])
