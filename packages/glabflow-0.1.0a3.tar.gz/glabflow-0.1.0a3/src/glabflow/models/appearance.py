from __future__ import annotations

import msgspec


class Appearance(msgspec.Struct, gc=False, kw_only=True):
    """GitLab appearance model."""

    id: int = 0
    title: str = ""
    description: str | None = None
    logo: str | None = None
    header_logo: str | None = None
    favicon: str | None = None
    new_project_guidelines: str | None = None
    header_message: str | None = None
    footer_message: str | None = None
    message_background_color: str | None = None
    message_font_color: str | None = None
    email_header_and_footer_enabled: bool = False
    default_project_visibility: int = 0
    default_group_visibility: int = 0
    default_snippet_visibility: int = 0
    restricted_visibility_levels: list[int] = []
    max_attachment_size: int = 0
    session_expire_delay: int = 0
    default_branch_name: str = ""
    whitelist: list[str] = []
    home_page_url: str | None = None
    help_page_url: str | None = None
    help_text: str | None = None
    help_hide: bool = False
    terms: str | None = None
    privacy_policy_url: str | None = None
    admin_notification_email: str | None = None
    sign_in_text: str | None = None
    created_at: str = ""
    updated_at: str = ""
    logo_text: str | None = None
    footer_logo: str | None = None
    project_creation_level: str = ""
    auto_devops_enabled: bool = False
    subgroup_creation_level: str = ""
    emails_enabled: bool = False
    gravatar_enabled: bool = False
    default_projects_limit: int = 0
    signup_enabled: bool = False
    twitter_sharing_enabled: bool = False
    restricted_signup_domains: list[dict] = []
    user_oauth_applications: bool = False
    asset_proxy_allowlist: list[str] = []
    asset_proxy_url: str | None = None
    asset_proxy_enabled: bool = False
    asset_proxy_secret_key: str | None = None
    asset_proxy_cache_ttl: int | None = None
    web_ide_clientside_preview_enabled: bool = False
    require_two_factor_authentication: bool = False
    two_factor_grace_period: int = 0
    external_auth_client_cert: str | None = None
    external_auth_client_key: str | None = None
    external_auth_ca: str | None = None
    external_auth_client_key_pass: str | None = None
    asset_proxy_inline_images: bool = False
    sidekiq_job_limiter_mode: str = ""
    sidekiq_job_limiter_threshold_bytes: int = 0
    sidekiq_job_limiter_max_concurrency: int = 0
    asset_proxy_version: str = ""
