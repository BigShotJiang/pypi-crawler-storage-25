from __future__ import annotations

import msgspec


class Board(msgspec.Struct, gc=False, kw_only=True):
    """GitLab boards model."""

    id: int = 0
    project: dict = {}
    name: str = ""
    assignee: dict | None = None
    lists: list[dict] = []
    created_at: str = ""
    updated_at: str = ""
