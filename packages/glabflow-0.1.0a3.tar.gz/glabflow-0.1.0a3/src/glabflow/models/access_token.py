from __future__ import annotations

import msgspec


def decode_personal_access_token(data: bytes) -> PersonalAccessToken:
    """Decode a single PersonalAccessToken from JSON bytes."""
    return _personal_access_token_decoder.decode(data)


def decode_personal_access_token_list(data: bytes) -> list[PersonalAccessToken]:
    """Decode a list of PersonalAccessToken from JSON bytes."""
    return _personal_access_token_list_decoder.decode(data)


def decode_project_access_token(data: bytes) -> ProjectAccessToken:
    """Decode a single ProjectAccessToken from JSON bytes."""
    return _project_access_token_decoder.decode(data)


def decode_project_access_token_list(data: bytes) -> list[ProjectAccessToken]:
    """Decode a list of ProjectAccessToken from JSON bytes."""
    return _project_access_token_list_decoder.decode(data)


class PersonalAccessToken(msgspec.Struct, gc=False, kw_only=True):
    """GitLab personal access token."""

    id: int = 0
    name: str = ""
    revoked: bool = False
    created_at: str = ""
    scopes: list[str] = []
    active: bool = False
    user_id: int | None = None
    expires_at: str | None = None
    last_used_at: str | None = None
    description: str | None = None


class ProjectAccessToken(msgspec.Struct, gc=False, kw_only=True):
    """GitLab project or group access token."""

    id: int = 0
    name: str = ""
    revoked: bool = False
    created_at: str = ""
    scopes: list[str] = []
    active: bool = False
    access_level: int | None = None
    user_id: int | None = None
    expires_at: str | None = None
    last_used_at: str | None = None


_personal_access_token_decoder = msgspec.json.Decoder(PersonalAccessToken)
_personal_access_token_list_decoder = msgspec.json.Decoder(list[PersonalAccessToken])
_project_access_token_decoder = msgspec.json.Decoder(ProjectAccessToken)
_project_access_token_list_decoder = msgspec.json.Decoder(list[ProjectAccessToken])
