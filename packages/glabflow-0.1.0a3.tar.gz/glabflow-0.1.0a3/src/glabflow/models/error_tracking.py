from __future__ import annotations

import msgspec


class ErrorTracking(msgspec.Struct, gc=False, kw_only=True):
    """GitLab error_tracking model."""

    id: int = 0
    project_id: int = 0
    active: bool = False
    properties: dict | None = None
    client_key: str | None = None
    stacktrace_appearance: str | None = None
    sentry_enabled: bool = False
    sentry_dsn: str | None = None
    sentry_environment: str | None = None
