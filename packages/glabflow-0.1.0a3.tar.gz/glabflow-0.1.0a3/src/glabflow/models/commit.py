"""GitLab commit models."""

from __future__ import annotations

import msgspec


def decode_commit(data: bytes) -> Commit:
    """Decode a single Commit from JSON bytes."""
    return _commit_decoder.decode(data)


def decode_commit_list(data: bytes) -> list[Commit]:
    """Decode a list of Commit from JSON bytes."""
    return _commit_list_decoder.decode(data)


def decode_commit_comment_list(data: bytes) -> list[CommitComment]:
    """Decode a list of CommitComment from JSON bytes."""
    return _comment_decoder.decode(data)


def decode_commit_diff_list(data: bytes) -> list[CommitDiff]:
    """Decode a list of CommitDiff from JSON bytes."""
    return _diff_decoder.decode(data)


def decode_commit_status_list(data: bytes) -> list[CommitStatus]:
    """Decode a list of CommitStatus from JSON bytes."""
    return _status_decoder.decode(data)


class Commit(msgspec.Struct, gc=False, kw_only=True):
    """GitLab commit model."""

    id: str = ""
    short_id: str = ""
    title: str = ""
    message: str = ""
    author_name: str = ""
    author_email: str = ""
    authored_date: str = ""
    committer_name: str = ""
    committer_email: str = ""
    created_at: str = ""
    web_url: str = ""
    parent_ids: list[str] | None = None


class CommitComment(msgspec.Struct, gc=False, kw_only=True):
    """GitLab commit comment model."""

    note: str = ""
    path: str = ""
    line: int | None = None
    line_type: str | None = None


class CommitDiff(msgspec.Struct, gc=False, kw_only=True):
    """GitLab commit diff model."""

    diff: str = ""
    new_path: str | None = None
    old_path: str | None = None
    a_mode: str | None = None
    b_mode: str | None = None
    new_file: bool = False
    renamed_file: bool = False
    deleted_file: bool = False


class CommitStatus(msgspec.Struct, gc=False, kw_only=True):
    """GitLab commit status model."""

    status: str = ""
    name: str | None = None
    target_url: str | None = None
    description: str | None = None
    created_at: str | None = None
    started_at: str | None = None
    finished_at: str | None = None
    ref: str | None = None
    sha: str | None = None
    coverage: float | None = None


_commit_decoder = msgspec.json.Decoder(Commit)
_commit_list_decoder = msgspec.json.Decoder(list[Commit])
_comment_decoder = msgspec.json.Decoder(list[CommitComment])
_diff_decoder = msgspec.json.Decoder(list[CommitDiff])
_status_decoder = msgspec.json.Decoder(list[CommitStatus])
