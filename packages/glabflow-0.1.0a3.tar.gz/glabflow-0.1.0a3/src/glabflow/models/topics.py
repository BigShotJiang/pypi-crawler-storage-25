from __future__ import annotations

import msgspec


class Topic(msgspec.Struct, gc=False, kw_only=True):
    """GitLab topics model."""

    id: int = 0
    name: str = ""
    description: str | None = None
    created_at: str = ""
    updated_at: str = ""
    total_projects_count: int = 0
    avatar_url: str | None = None
    title: str = ""
