from __future__ import annotations

import msgspec


class Compare(msgspec.Struct, gc=False, kw_only=True):
    """GitLab compare model."""

    commit: dict | None = None
    commits: list[dict] = []
    diffs: list[dict] = []
    compare_timeout: bool = False
    compare_same_ref: bool = False
    web_url: str = ""
