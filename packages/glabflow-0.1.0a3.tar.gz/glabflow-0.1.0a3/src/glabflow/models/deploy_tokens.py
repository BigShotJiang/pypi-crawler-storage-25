from __future__ import annotations

import msgspec


class DeployToken(msgspec.Struct, gc=False, kw_only=True):
    """GitLab deploy_tokens model."""

    id: int = 0
    name: str = ""
    token: str | None = None
    scopes: list[str] = []
    created_at: str = ""
    expires_at: str | None = None
    revoked: bool = False
    expired: bool = False
    user: dict | None = None
