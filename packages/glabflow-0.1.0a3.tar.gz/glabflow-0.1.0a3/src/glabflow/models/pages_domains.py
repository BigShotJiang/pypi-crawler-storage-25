from __future__ import annotations

import msgspec


class PagesDomain(msgspec.Struct, gc=False, kw_only=True):
    """GitLab pages_domains model."""

    domain: str = ""
    url: str = ""
    project: dict | None = None
    enabled: bool = False
    verified: bool = False
    verification_code: str | None = None
    certificate: dict | None = None
    certificate_text: str | None = None
    auto_ssl_enabled: bool = False
    certificate_status: str | None = None
    certificate_expiration: str | None = None
    certificate_validity: str | None = None
