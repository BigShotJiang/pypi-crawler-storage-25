from __future__ import annotations

import msgspec


class Discussion(msgspec.Struct, gc=False, kw_only=True):
    """GitLab discussions model."""

    id: str = ""
    individual_note: bool = False
    notes: list[dict] = []
    participant: dict | None = None
    last_edited_at: str | None = None
    last_edited_by: dict | None = None
    resolved: bool = False
    resolved_by: dict | None = None
    resolved_at: str | None = None
    type: str | None = None
    position: dict | None = None
    commit_id: str | None = None
    references: dict | None = None
    command: str | None = None
    changes_count: str | None = None
    latest_build_started_at: str | None = None
    latest_build_finished_at: str | None = None
    first_deployed_to_production_at: str | None = None
    project_id: int | None = None
    noteable_id: int | None = None
    noteable_type: str | None = None
    noteable_title: str | None = None
