from __future__ import annotations

import msgspec


class AccessToken(msgspec.Struct, gc=False, kw_only=True):
    """GitLab access_tokens model."""

    id: int = 0
    name: str = ""
    revoked: bool = False
    created_at: str = ""
    expires_at: str | None = None
    user: dict | None = None
    active: bool = False
    scopes: list[str] = []
    last_used_at: str | None = None
    access_level: int | None = None
