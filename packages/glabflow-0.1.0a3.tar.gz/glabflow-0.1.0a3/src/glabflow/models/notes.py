from __future__ import annotations

import msgspec


def decode_note(data: bytes) -> Note:
    """Decode a single Note from JSON bytes."""
    return _note_decoder.decode(data)


def decode_note_list(data: bytes) -> list[Note]:
    """Decode a list of Note from JSON bytes."""
    return _note_list_decoder.decode(data)


class Note(msgspec.Struct, gc=False, kw_only=True):
    """GitLab notes model."""

    id: int = 0
    body: str = ""
    attachment: str | None = None
    author: dict = {}
    created_at: str = ""
    updated_at: str = ""
    system: bool = False
    noteable_id: int = 0
    noteable_type: str = ""
    resolvable: bool = False
    confidential: bool = False
    noteable_iid: int | None = None
    commands_changes: dict = {}
    type: str | None = None
    position: dict | None = None
    resolved: bool = False
    resolved_by: dict | None = None
    resolved_at: str | None = None
    participants: list[dict] = []
    award_emoji: list[dict] = []
    note_html: str = ""
    internal: bool = False


_note_decoder = msgspec.json.Decoder(Note)
_note_list_decoder = msgspec.json.Decoder(list[Note])
