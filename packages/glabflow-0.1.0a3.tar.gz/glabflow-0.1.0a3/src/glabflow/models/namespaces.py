from __future__ import annotations

import msgspec


def decode_namespace(data: bytes) -> Namespace:
    """Decode a single Namespace from JSON bytes."""
    return _namespace_decoder.decode(data)


def decode_namespace_list(data: bytes) -> list[Namespace]:
    """Decode a list of Namespace from JSON bytes."""
    return _namespace_list_decoder.decode(data)


def decode_deploy_key(data: bytes) -> DeployKey:
    """Decode a single DeployKey from JSON bytes."""
    return _deploy_key_decoder.decode(data)


def decode_deploy_key_list(data: bytes) -> list[DeployKey]:
    """Decode a list of DeployKey from JSON bytes."""
    return _deploy_key_list_decoder.decode(data)


class Namespace(msgspec.Struct, gc=False, kw_only=True):
    """GitLab namespaces model."""

    id: int = 0
    name: str = ""
    path: str = ""
    kind: str = ""
    full_path: str = ""
    parent_id: int | None = None
    avatar_url: str | None = None
    web_url: str = ""


class DeployKey(msgspec.Struct, gc=False, kw_only=True):
    """GitLab deploy key model."""

    id: int = 0
    title: str = ""
    key: str = ""
    created_at: str = ""
    can_push: bool = False


_namespace_decoder = msgspec.json.Decoder(Namespace)
_namespace_list_decoder = msgspec.json.Decoder(list[Namespace])
_deploy_key_decoder = msgspec.json.Decoder(DeployKey)
_deploy_key_list_decoder = msgspec.json.Decoder(list[DeployKey])
