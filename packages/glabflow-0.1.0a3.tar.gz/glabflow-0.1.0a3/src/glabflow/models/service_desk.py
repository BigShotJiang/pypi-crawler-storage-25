from __future__ import annotations

import msgspec


class ServiceDesk(msgspec.Struct, gc=False, kw_only=True):
    """GitLab service_desk model."""

    id: int = 0
    address: str = ""
    working_hours: dict | None = None
    operating_hours: dict | None = None
    project_id: int = 0
    enabled: bool = False
    use_service_desk_emails_as_comments: bool = False
    email_address: str = ""
    incoming_email_address: str = ""
    incoming_email_token: str = ""
    incoming_email_enabled: bool = False
    incoming_email_restricted: bool = False
    incoming_email_domain: str | None = None
    incoming_email_user: str | None = None
    incoming_email_host: str | None = None
    incoming_email_port: int | None = None
    incoming_email_ssl: bool = False
    incoming_email_start_tls: bool = False
    incoming_email_mailbox: str | None = None
    incoming_email_label: str | None = None
    incoming_email_search: str | None = None
    incoming_email_expunge: bool = False
    incoming_email_inbox_method: str | None = None
    incoming_email_inbox_options: dict | None = None
