"""GitLab registry models."""

from __future__ import annotations

import msgspec


def decode_package(data: bytes) -> Package:
    """Decode a single Package from JSON bytes."""
    return _package_decoder.decode(data)


def decode_package_list(data: bytes) -> list[Package]:
    """Decode a list of Package from JSON bytes."""
    return _package_list_decoder.decode(data)


def decode_registry_repository(data: bytes) -> RegistryRepository:
    """Decode a single RegistryRepository from JSON bytes."""
    return _repo_decoder.decode(data)


def decode_registry_repository_list(data: bytes) -> list[RegistryRepository]:
    """Decode a list of RegistryRepository from JSON bytes."""
    return _repo_list_decoder.decode(data)


def decode_registry_tag(data: bytes) -> RegistryTag:
    """Decode a single RegistryTag from JSON bytes."""
    return _tag_decoder.decode(data)


def decode_registry_tag_list(data: bytes) -> list[RegistryTag]:
    """Decode a list of RegistryTag from JSON bytes."""
    return _tag_list_decoder.decode(data)


class Package(msgspec.Struct, gc=False, kw_only=True):
    """GitLab package model."""

    id: int = 0
    name: str = ""
    version: str = ""
    package_type: str = ""
    status: str = ""
    created_at: str = ""
    updated_at: str | None = None
    links: dict | None = None


class RegistryRepository(msgspec.Struct, gc=False, kw_only=True):
    """GitLab registry repository model."""

    id: int = 0
    name: str = ""
    path: str = ""
    project_id: int = 0
    location: str = ""
    created_at: str = ""
    cleanup_policy_started_at: str | None = None
    tags_count: int | None = None
    tags: list[dict] | None = None


class RegistryTag(msgspec.Struct, gc=False, kw_only=True):
    """GitLab registry tag model."""

    name: str = ""
    path: str = ""
    location: str = ""
    revision: str | None = None
    short_revision: str | None = None
    digest: str | None = None
    created_at: str | None = None
    total_size: int | None = None
    protected: bool | None = None
    tags: list[str] | None = None


_package_decoder = msgspec.json.Decoder(Package)
_package_list_decoder = msgspec.json.Decoder(list[Package])
_repo_decoder = msgspec.json.Decoder(RegistryRepository)
_repo_list_decoder = msgspec.json.Decoder(list[RegistryRepository])
_tag_decoder = msgspec.json.Decoder(RegistryTag)
_tag_list_decoder = msgspec.json.Decoder(list[RegistryTag])
