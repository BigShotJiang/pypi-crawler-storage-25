"""GitLab search models."""

from __future__ import annotations

import msgspec


def decode_search_result(data: bytes) -> SearchResult:
    """Decode a single SearchResult from JSON bytes."""
    return _search_result_decoder.decode(data)


def decode_search_result_list(data: bytes) -> list[SearchResult]:
    """Decode a list of SearchResult from JSON bytes."""
    return _search_result_list_decoder.decode(data)


class Search(msgspec.Struct, gc=False, kw_only=True):
    """GitLab search result model."""

    id: int = 0
    name: str = ""
    description: str | None = None
    path: str | None = None
    project_id: int | None = None
    type: str | None = None


class SearchResult(msgspec.Struct, gc=False, kw_only=True):
    """GitLab search result model (alias for Search)."""

    id: int = 0
    name: str = ""
    description: str | None = None
    path: str | None = None
    project_id: int | None = None
    type: str | None = None


_search_result_decoder = msgspec.json.Decoder(SearchResult)
_search_result_list_decoder = msgspec.json.Decoder(list[SearchResult])
