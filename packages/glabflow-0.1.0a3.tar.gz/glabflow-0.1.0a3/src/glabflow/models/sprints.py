from __future__ import annotations

import msgspec


class Sprint(msgspec.Struct, gc=False, kw_only=True):
    """GitLab sprints model."""

    id: int = 0
    iid: int = 0
    group_id: int = 0
    name: str = ""
    state: str = ""
    created_at: str = ""
    updated_at: str = ""
    starts_at: str | None = None
    ends_at: str | None = None
    web_url: str = ""
