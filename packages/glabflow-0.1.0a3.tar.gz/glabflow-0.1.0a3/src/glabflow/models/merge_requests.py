from __future__ import annotations

import msgspec


def decode_mr(data: bytes) -> MergeRequest:
    """Decode a single MergeRequest from JSON bytes."""
    return _mr_decoder.decode(data)


def decode_mr_list(data: bytes) -> list[MergeRequest]:
    """Decode a list of MergeRequest from JSON bytes."""
    return _mr_list_decoder.decode(data)


def decode_merge_request(data: bytes) -> MergeRequest:
    """Decode a single MergeRequest from JSON bytes."""
    return _mr_decoder.decode(data)


def decode_merge_request_list(data: bytes) -> list[MergeRequest]:
    """Decode a list of MergeRequest from JSON bytes."""
    return _mr_list_decoder.decode(data)


class MergeRequest(msgspec.Struct, gc=False, kw_only=True):
    """GitLab merge_requests model."""

    id: int = 0
    iid: int = 0
    project_id: int = 0
    title: str = ""
    description: str | None = None
    state: str = ""
    created_at: str = ""
    updated_at: str = ""
    merged_at: str | None = None
    closed_at: str | None = None
    closed_by: dict | None = None
    target_branch: str = ""
    source_branch: str = ""
    user_notes_count: int = 0
    upvotes: int = 0
    downvotes: int = 0
    author: dict = {}
    assignees: list[dict] = []
    assignee: dict | None = None
    reviewers: list[dict] = []
    source_project_id: int = 0
    target_project_id: int = 0
    labels: list[str] = []
    draft: bool = False
    work_in_progress: bool = False
    milestone: dict | None = None
    merge_when_pipeline_succeeds: bool = False
    detailed_merge_status: str = ""
    merge_status: str = ""
    sha: str = ""
    merge_commit_sha: str | None = None
    squash_commit_sha: str | None = None
    discussion_locked: bool = False
    changes_count: str = ""
    should_remove_source_branch: bool | None = None
    force_remove_source_branch: bool = False
    allow_collaboration: bool = False
    web_url: str = ""
    references: dict = {}
    discussion_locked: bool = False
    changes: list[dict] = []
    user: dict | None = None
    blocking_discussions_resolved: bool = False
    approvals_before_merge: int | None = None
    squash: bool = False
    task_completion_status: dict = {}
    prepared_at: str | None = None
    has_conflicts: bool = False
    overflow: bool = False
    merge_error: str | None = None
    first_contribution: bool = False
    merge_trains_enabled: bool = False


_mr_decoder = msgspec.json.Decoder(MergeRequest)
_mr_list_decoder = msgspec.json.Decoder(list[MergeRequest])
