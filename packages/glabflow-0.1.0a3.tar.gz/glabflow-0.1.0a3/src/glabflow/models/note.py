"""Alias for notes module - backwards compatibility."""

from .notes import Note, decode_note, decode_note_list

__all__ = ["Note", "decode_note", "decode_note_list"]
