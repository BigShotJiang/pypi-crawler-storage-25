"""GitLab data models."""

from .access_tokens import AccessToken
from .appearance import Appearance
from .approval_rules import ApprovalRule
from .audit_events import AuditEvent
from .award_emoji import AwardEmoji
from .badges import Badge
from .boards import Board
from .branches import Branche
from .broadcast_messages import BroadcastMessage
from .changelog import Changelog
from .ci import Ci
from .code_owners import CodeOwner
from .compare import Compare
from .composer_packages import ComposerPackage
from .conan_packages import ConanPackage
from .coverage_definitions import CoverageDefinition
from .dependency_proxy import DependencyProxy
from .deploy_keys import DeployKey
from .deploy_tokens import DeployToken
from .deployments import Deployment
from .discussions import Discussion
from .dockerfile_templates import DockerfileTemplate
from .environments import Environment
from .epics import Epic
from .error_tracking import ErrorTracking
from .events import Event
from .external_status_checks import ExternalStatusCheck
from .generic_packages import GenericPackage
from .geo_nodes import GeoNode
from .groups import Group
from .helm_packages import HelmPackage
from .hooks import Hook
from .incident_management import IncidentManagement
from .issues import Issue
from .iterations import Iteration
from .jobs import Job
from .keys import Key
from .labels import Label
from .ldap_groups import LdapGroup
from .members import Member
from .merge_request_approvals import MergeRequestApproval
from .merge_requests import MergeRequest
from .merge_trains import MergeTrain
from .milestones import Milestone
from .namespaces import Namespace
from .notes import Note
from .npm_packages import NpmPackage
from .nuget_packages import NugetPackage
from .packages import Package
from .pages_domains import PagesDomain
from .pipeline_schedules import PipelineSchedule
from .pipelines import Pipeline
from .projects import Project
from .protected_branches import ProtectedBranche
from .push_rules import PushRule
from .pypi_packages import PypiPackage
from .registry_repositories import RegistryRepositorie
from .releases import Release
from .rubygems_packages import RubygemsPackage
from .runners import Runner
from .search import Search
from .service_desk import ServiceDesk
from .settings import Setting
from .signatures import Signature
from .snippets import Snippet
from .sprints import Sprint
from .statistics import Statistic
from .tags import Tag
from .templates import Template
from .terraform_packages import TerraformPackage
from .todos import Todo
from .topics import Topic
from .triggers import Trigger
from .users import User
from .variables import Variable
from .vulnerabilities import Vulnerabilitie
from .wikis import Wiki

__all__ = [
    "AccessToken",
    "Appearance",
    "ApprovalRule",
    "AuditEvent",
    "AwardEmoji",
    "Badge",
    "Board",
    "Branche",
    "BroadcastMessage",
    "Changelog",
    "Ci",
    "CodeOwner",
    "Compare",
    "ComposerPackage",
    "ConanPackage",
    "CoverageDefinition",
    "DependencyProxy",
    "DeployKey",
    "DeployToken",
    "Deployment",
    "Discussion",
    "DockerfileTemplate",
    "Environment",
    "Epic",
    "ErrorTracking",
    "Event",
    "ExternalStatusCheck",
    "GenericPackage",
    "GeoNode",
    "Group",
    "HelmPackage",
    "Hook",
    "IncidentManagement",
    "Issue",
    "Iteration",
    "Job",
    "Key",
    "Label",
    "LdapGroup",
    "Member",
    "MergeRequest",
    "MergeRequestApproval",
    "MergeTrain",
    "Milestone",
    "Namespace",
    "Note",
    "NpmPackage",
    "NugetPackage",
    "Package",
    "PagesDomain",
    "Pipeline",
    "PipelineSchedule",
    "Project",
    "ProtectedBranche",
    "PushRule",
    "PypiPackage",
    "RegistryRepositorie",
    "Release",
    "RubygemsPackage",
    "Runner",
    "Search",
    "ServiceDesk",
    "Setting",
    "Signature",
    "Snippet",
    "Sprint",
    "Statistic",
    "Tag",
    "Template",
    "TerraformPackage",
    "Todo",
    "Topic",
    "Trigger",
    "User",
    "Variable",
    "Vulnerabilitie",
    "Wiki",
]
