from __future__ import annotations

import msgspec


class Template(msgspec.Struct, gc=False, kw_only=True):
    """GitLab templates model."""

    name: str = ""
    slug: str = ""
