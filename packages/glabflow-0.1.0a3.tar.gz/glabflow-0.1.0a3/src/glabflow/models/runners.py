from __future__ import annotations

import msgspec


class Runner(msgspec.Struct, gc=False, kw_only=True):
    """GitLab runners model."""

    id: int = 0
    description: str = ""
    active: bool = False
    paused: bool = False
    is_shared: bool = False
    ip_address: str | None = None
    name: str = ""
    online: bool = False
    status: str = ""
    token: str | None = None
    token_expires_at: str | None = None
    runner_type: str = ""
    locked: bool = False
    access_level: str = ""
    maximum_timeout: int | None = None
    run_untagged: bool = False
    tag_list: list[str] = []
    tags: list[str] = []
    contacted_at: str = ""
    projects: list[dict] = []
    info: dict | None = None
    configuration: dict | None = None
    maintenance_note: str | None = None
    version: str | None = None
    revision: str | None = None
    platform: str | None = None
    architecture: str | None = None
    is_project_locked: bool = False
    web_url: str | None = None
