from __future__ import annotations

import msgspec


def decode_member(data: bytes) -> Member:
    """Decode a single Member from JSON bytes."""
    return _member_decoder.decode(data)


def decode_member_list(data: bytes) -> list[Member]:
    """Decode a list of Member from JSON bytes."""
    return _member_list_decoder.decode(data)


class Member(msgspec.Struct, gc=False, kw_only=True):
    """GitLab members model."""

    id: int = 0
    username: str = ""
    name: str = ""
    state: str = ""
    avatar_url: str | None = None
    web_url: str = ""
    created_at: str = ""
    created_by: dict | None = None
    expires_at: str | None = None
    access_level: int = 0
    email: str | None = None
    last_activity_on: str | None = None
    membership_type: str = ""
    imported: bool = False
    imported_from: str | None = None


_member_decoder = msgspec.json.Decoder(Member)
_member_list_decoder = msgspec.json.Decoder(list[Member])
