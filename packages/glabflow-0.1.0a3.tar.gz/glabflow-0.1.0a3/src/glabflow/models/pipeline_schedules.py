from __future__ import annotations

import msgspec


def decode_pipeline_schedule(data: bytes) -> PipelineSchedule:
    """Decode a single PipelineSchedule from JSON bytes."""
    return _pipeline_schedule_decoder.decode(data)


def decode_pipeline_schedule_list(data: bytes) -> list[PipelineSchedule]:
    """Decode a list of PipelineSchedule from JSON bytes."""
    return _pipeline_schedule_list_decoder.decode(data)


class PipelineSchedule(msgspec.Struct, gc=False, kw_only=True):
    """GitLab pipeline_schedules model."""

    id: int = 0
    description: str = ""
    ref: str = ""
    cron: str = ""
    cron_timezone: str = ""
    next_run_at: str | None = None
    active: bool = False
    created_at: str = ""
    updated_at: str = ""
    last_pipeline: dict | None = None
    owner: dict | None = None
    web_url: str = ""
    variables: list[dict] = []
    latest_pipeline: dict | None = None


_pipeline_schedule_decoder = msgspec.json.Decoder(PipelineSchedule)
_pipeline_schedule_list_decoder = msgspec.json.Decoder(list[PipelineSchedule])
