from __future__ import annotations

import msgspec


def decode_job(data: bytes) -> Job:
    """Decode a single Job from JSON bytes."""
    return _job_decoder.decode(data)


def decode_job_list(data: bytes) -> list[Job]:
    """Decode a list of Job from JSON bytes."""
    return _job_list_decoder.decode(data)


def decode_runner(data: bytes) -> Runner:
    """Decode a single Runner from JSON bytes."""
    return _runner_decoder.decode(data)


def decode_runner_list(data: bytes) -> list[Runner]:
    """Decode a list of Runner from JSON bytes."""
    return _runner_list_decoder.decode(data)


class Job(msgspec.Struct, gc=False, kw_only=True):
    """GitLab jobs model."""

    id: int = 0
    project_id: int = 0
    pipeline_id: int | None = None
    name: str = ""
    stage: str = ""
    status: str = ""
    created_at: str = ""
    started_at: str | None = None
    finished_at: str | None = None
    duration: float | None = None
    queued_duration: float | None = None
    tag: bool = False
    coverage: float | None = None
    allow_failure: bool = False
    erased_at: str | None = None
    user: dict | None = None
    runner: dict | None = None
    artifacts_expire_at: str | None = None
    artifacts: list[dict] = []
    artifacts_file: dict | None = None
    web_url: str = ""
    web_path: str = ""
    failure_reason: str | None = None
    tag_list: list[str] = []
    artifacts_file_format: str | None = None
    retryable: bool = False
    environment: dict | None = None
    seed: bool = False
    triggered: bool = False
    message: str | None = None
    when: str = ""
    manual: bool = False
    protected: bool = False
    needs: list[dict] | None = None


class Runner(msgspec.Struct, gc=False, kw_only=True):
    """GitLab runner model."""

    id: int = 0
    description: str = ""
    active: bool = False
    is_shared: bool = False
    ip_address: str | None = None
    name: str = ""
    online: bool = False
    status: str = ""
    token: str | None = None
    runner_type: str | None = None
    accessed_at: str | None = None
    contacted_at: str | None = None
    projects: list[dict] | None = None


_job_decoder = msgspec.json.Decoder(Job)
_job_list_decoder = msgspec.json.Decoder(list[Job])
_runner_decoder = msgspec.json.Decoder(Runner)
_runner_list_decoder = msgspec.json.Decoder(list[Runner])
