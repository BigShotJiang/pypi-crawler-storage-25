"""Alias for tags module - backwards compatibility."""

from .tags import Tag, decode_tag, decode_tag_list

__all__ = ["Tag", "decode_tag", "decode_tag_list"]
