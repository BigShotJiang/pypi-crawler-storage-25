from __future__ import annotations

import msgspec


class BroadcastMessage(msgspec.Struct, gc=False, kw_only=True):
    """GitLab broadcast_messages model."""

    id: int = 0
    message: str = ""
    starts_at: str = ""
    ends_at: str = ""
    color: str = ""
    font: str = ""
    target_access_levels: list[int] = []
    broadcast_type: str | None = None
    compress: bool = False
    active: bool = False
