"""Alias for merge_requests module - backwards compatibility."""

from .merge_requests import (
    MergeRequest,
    decode_merge_request,
    decode_merge_request_list,
    decode_mr,
    decode_mr_list,
)

__all__ = [
    "MergeRequest",
    "decode_mr",
    "decode_mr_list",
    "decode_merge_request",
    "decode_merge_request_list",
]
