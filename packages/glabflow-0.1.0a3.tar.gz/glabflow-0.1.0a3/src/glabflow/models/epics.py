from __future__ import annotations

import msgspec


class Epic(msgspec.Struct, gc=False, kw_only=True):
    """GitLab epics model."""

    id: int = 0
    iid: int = 0
    group_id: int = 0
    parent_id: int | None = None
    title: str = ""
    description: str | None = None
    state: str = ""
    created_at: str = ""
    updated_at: str = ""
    labels: list[str] = []
    author: dict = {}
    assignees: list[dict] = []
    start_date: str | None = None
    end_date: str | None = None
    due_date: str | None = None
    web_url: str = ""
    confidential: bool = False
    references: dict = {}
