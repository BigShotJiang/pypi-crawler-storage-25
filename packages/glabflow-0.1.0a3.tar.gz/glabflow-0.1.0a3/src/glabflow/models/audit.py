from __future__ import annotations

import msgspec


def decode_audit_event(data: bytes) -> AuditEvent:
    """Decode a single AuditEvent from JSON bytes."""
    return _audit_event_decoder.decode(data)


def decode_audit_event_list(data: bytes) -> list[AuditEvent]:
    """Decode a list of AuditEvent from JSON bytes."""
    return _audit_event_list_decoder.decode(data)


class AuditEvent(msgspec.Struct, gc=False, kw_only=True):
    """GitLab audit event (instance or group level)."""

    id: int = 0
    author_id: int = 0
    entity_id: int = 0
    entity_type: str = ""
    details: dict = {}
    created_at: str = ""
    ip_address: str | None = None
    author_name: str | None = None
    entity_path: str | None = None
    target_id: int | None = None
    target_type: str | None = None
    target_details: str | None = None


_audit_event_decoder = msgspec.json.Decoder(AuditEvent)
_audit_event_list_decoder = msgspec.json.Decoder(list[AuditEvent])
