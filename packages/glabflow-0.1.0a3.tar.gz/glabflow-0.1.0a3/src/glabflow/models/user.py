"""Alias for users module - backwards compatibility."""

from .users import User, decode_user, decode_user_list

__all__ = ["User", "decode_user", "decode_user_list"]
