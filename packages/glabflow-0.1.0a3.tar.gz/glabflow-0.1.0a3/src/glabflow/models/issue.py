"""Alias for issues module - backwards compatibility."""

from .issues import Issue, decode_issue, decode_issue_list

__all__ = ["Issue", "decode_issue", "decode_issue_list"]
