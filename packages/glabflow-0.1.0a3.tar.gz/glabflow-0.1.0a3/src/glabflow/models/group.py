"""Alias for groups module - backwards compatibility."""

from .groups import Group, decode_group, decode_group_list

__all__ = ["Group", "decode_group", "decode_group_list"]
