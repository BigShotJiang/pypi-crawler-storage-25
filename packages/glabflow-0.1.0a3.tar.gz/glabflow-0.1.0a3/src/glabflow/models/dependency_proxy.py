from __future__ import annotations

import msgspec


class DependencyProxy(msgspec.Struct, gc=False, kw_only=True):
    """GitLab dependency_proxy model."""

    id: int = 0
    project_id: int = 0
    enabled: bool = False
    created_at: str = ""
    updated_at: str = ""
