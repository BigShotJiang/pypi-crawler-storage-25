from __future__ import annotations

import msgspec


class Todo(msgspec.Struct, gc=False, kw_only=True):
    """GitLab todos model."""

    id: int = 0
    project: dict | None = None
    author: dict = {}
    action_name: str = ""
    target_type: str = ""
    target: dict | None = None
    target_url: str = ""
    body: str = ""
    state: str = ""
    created_at: str = ""
    updated_at: str = ""
