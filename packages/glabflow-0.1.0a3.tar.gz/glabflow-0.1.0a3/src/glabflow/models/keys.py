from __future__ import annotations

import msgspec


class Key(msgspec.Struct, gc=False, kw_only=True):
    """GitLab keys model."""

    id: int = 0
    title: str = ""
    key: str = ""
    created_at: str = ""
