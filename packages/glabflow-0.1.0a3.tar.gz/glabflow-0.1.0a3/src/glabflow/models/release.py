"""Alias for releases module - backwards compatibility."""

from .releases import (
    Release,
    ReleaseLink,
    decode_release,
    decode_release_link,
    decode_release_link_list,
    decode_release_list,
)

__all__ = [
    "Release",
    "ReleaseLink",
    "decode_release",
    "decode_release_list",
    "decode_release_link",
    "decode_release_link_list",
]
