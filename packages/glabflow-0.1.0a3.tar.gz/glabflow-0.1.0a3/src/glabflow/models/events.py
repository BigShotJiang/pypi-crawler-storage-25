from __future__ import annotations

import msgspec


def decode_event(data: bytes) -> Event:
    """Decode a single Event from JSON bytes."""
    return _event_decoder.decode(data)


def decode_event_list(data: bytes) -> list[Event]:
    """Decode a list of Event from JSON bytes."""
    return _event_list_decoder.decode(data)


class Event(msgspec.Struct, gc=False, kw_only=True):
    """GitLab events model."""

    id: int = 0
    title: str | None = None
    project_id: int = 0
    action_name: str = ""
    target_id: int | None = None
    target_type: str | None = None
    author_id: int = 0
    author: dict = {}
    author_username: str = ""
    data: dict | None = None
    target_title: str | None = None
    created_at: str = ""
    push_data: dict | None = None


_event_decoder = msgspec.json.Decoder(Event)
_event_list_decoder = msgspec.json.Decoder(list[Event])
