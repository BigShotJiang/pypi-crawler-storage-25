"""Alias for events module - backwards compatibility."""

from .events import Event, decode_event, decode_event_list

__all__ = ["Event", "decode_event", "decode_event_list"]
