"""Alias for hooks module - backwards compatibility."""

from .hooks import (
    GroupHook,
    Hook,
    ProjectHook,
    decode_group_hook,
    decode_group_hook_list,
    decode_hook,
    decode_hook_list,
    decode_project_hook,
    decode_project_hook_list,
)

__all__ = [
    "GroupHook",
    "Hook",
    "ProjectHook",
    "decode_group_hook",
    "decode_group_hook_list",
    "decode_hook",
    "decode_hook_list",
    "decode_project_hook",
    "decode_project_hook_list",
]
