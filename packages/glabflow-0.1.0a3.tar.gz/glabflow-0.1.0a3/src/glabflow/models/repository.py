"""GitLab repository models."""

from __future__ import annotations

import msgspec


def decode_tree_item(data: bytes) -> TreeItem:
    """Decode a single TreeItem from JSON bytes."""
    return _tree_item_decoder.decode(data)


def decode_tree_item_list(data: bytes) -> list[TreeItem]:
    """Decode a list of TreeItem from JSON bytes."""
    return _tree_item_list_decoder.decode(data)


def decode_file_content(data: bytes) -> FileContent:
    """Decode a single FileContent from JSON bytes."""
    return _file_content_decoder.decode(data)


def decode_compare_result(data: bytes) -> CompareResult:
    """Decode a single CompareResult from JSON bytes."""
    return _compare_result_decoder.decode(data)


def decode_contributor(data: bytes) -> Contributor:
    """Decode a single Contributor from JSON bytes."""
    return _contributor_decoder.decode(data)


def decode_contributor_list(data: bytes) -> list[Contributor]:
    """Decode a list of Contributor from JSON bytes."""
    return _contributor_list_decoder.decode(data)


class TreeItem(msgspec.Struct, gc=False, kw_only=True):
    """GitLab repository tree item model."""

    id: str = ""
    name: str = ""
    type: str = ""
    path: str = ""
    mode: str = ""


class FileContent(msgspec.Struct, gc=False, kw_only=True):
    """GitLab file content model."""

    file_name: str = ""
    file_path: str = ""
    size: int = 0
    encoding: str = ""
    content: str = ""
    content_sha256: str = ""
    ref: str = ""
    blob_id: str = ""
    last_commit_id: str = ""


class CompareResult(msgspec.Struct, gc=False, kw_only=True):
    """GitLab compare result model."""

    commit_id: str = ""
    short_id: str = ""
    title: str = ""
    message: str = ""
    author_name: str = ""
    author_email: str = ""
    created_at: str = ""
    web_url: str = ""
    commits: list[dict] = []
    diffs: list[dict] = []
    compare_timeout: bool | None = None
    compare_same_ref: bool | None = None


class Contributor(msgspec.Struct, gc=False, kw_only=True):
    """GitLab contributor model."""

    name: str = ""
    email: str = ""
    commits: int = 0
    additions: int = 0
    deletions: int = 0


_tree_item_decoder = msgspec.json.Decoder(TreeItem)
_tree_item_list_decoder = msgspec.json.Decoder(list[TreeItem])
_file_content_decoder = msgspec.json.Decoder(FileContent)
_compare_result_decoder = msgspec.json.Decoder(CompareResult)
_contributor_decoder = msgspec.json.Decoder(Contributor)
_contributor_list_decoder = msgspec.json.Decoder(list[Contributor])
