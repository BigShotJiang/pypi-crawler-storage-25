from __future__ import annotations

import msgspec


class Changelog(msgspec.Struct, gc=False, kw_only=True):
    """GitLab changelog model."""

    version: str = ""
    released_at: str = ""
    changes: list[dict] = []
