from __future__ import annotations

import msgspec


class AwardEmoji(msgspec.Struct, gc=False, kw_only=True):
    """GitLab award_emoji model."""

    id: int = 0
    name: str = ""
    user_id: int = 0
    created_at: str = ""
    updated_at: str = ""
    user: dict = {}
    awardable_id: int = 0
    awardable_type: str = ""
