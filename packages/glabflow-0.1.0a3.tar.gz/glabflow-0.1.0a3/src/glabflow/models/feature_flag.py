from __future__ import annotations

import msgspec


def decode_feature_flag(data: bytes) -> FeatureFlag:
    """Decode a single FeatureFlag from JSON bytes."""
    return _feature_flag_decoder.decode(data)


def decode_feature_flag_list(data: bytes) -> list[FeatureFlag]:
    """Decode a list of FeatureFlag from JSON bytes."""
    return _feature_flag_list_decoder.decode(data)


def decode_feature_flag_user_list(data: bytes) -> FeatureFlagUserList:
    """Decode a single FeatureFlagUserList from JSON bytes."""
    return _feature_flag_user_list_decoder.decode(data)


def decode_feature_flag_user_list_list(data: bytes) -> list[FeatureFlagUserList]:
    """Decode a list of FeatureFlagUserList from JSON bytes."""
    return _feature_flag_user_list_list_decoder.decode(data)


class FeatureFlag(msgspec.Struct, gc=False, kw_only=True):
    """GitLab feature flag."""

    name: str = ""
    description: str | None = None
    active: bool = False
    version: str = ""
    created_at: str = ""
    updated_at: str = ""
    scopes: list[dict] = []
    strategies: list[dict] = []


class FeatureFlagUserList(msgspec.Struct, gc=False, kw_only=True):
    """GitLab feature flag user list."""

    id: int = 0
    iid: int = 0
    name: str = ""
    user_xids: str = ""
    created_at: str = ""
    updated_at: str = ""


_feature_flag_decoder = msgspec.json.Decoder(FeatureFlag)
_feature_flag_list_decoder = msgspec.json.Decoder(list[FeatureFlag])
_feature_flag_user_list_decoder = msgspec.json.Decoder(FeatureFlagUserList)
_feature_flag_user_list_list_decoder = msgspec.json.Decoder(list[FeatureFlagUserList])
