"""Alias for branches module - backwards compatibility."""

from .branches import (
    Branche as Branch,
)
from .branches import (
    CommitRef,
    decode_commit_ref,
    decode_commit_ref_list,
)
from .branches import (
    ProtectedBranche as ProtectedBranch,
)
from .branches import (
    decode_branche as decode_branch,
)
from .branches import (
    decode_branche_list as decode_branch_list,
)
from .branches import (
    decode_protected_branche as decode_protected_branch,
)
from .branches import (
    decode_protected_branche_list as decode_protected_branch_list,
)

__all__ = [
    "Branch",
    "CommitRef",
    "ProtectedBranch",
    "decode_branch",
    "decode_branch_list",
    "decode_commit_ref",
    "decode_commit_ref_list",
    "decode_protected_branch",
    "decode_protected_branch_list",
]
