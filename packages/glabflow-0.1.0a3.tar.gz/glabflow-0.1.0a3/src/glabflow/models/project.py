"""Alias for projects module - backwards compatibility."""

from .projects import Project, decode_project, decode_project_list

__all__ = ["Project", "decode_project", "decode_project_list"]
