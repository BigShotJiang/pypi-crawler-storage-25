from __future__ import annotations

import msgspec


def decode_pipeline(data: bytes) -> Pipeline:
    """Decode a single Pipeline from JSON bytes."""
    return _pipeline_decoder.decode(data)


def decode_pipeline_list(data: bytes) -> list[Pipeline]:
    """Decode a list of Pipeline from JSON bytes."""
    return _pipeline_list_decoder.decode(data)


class Pipeline(msgspec.Struct, gc=False, kw_only=True):
    """GitLab pipelines model."""

    id: int = 0
    project_id: int = 0
    sha: str = ""
    ref: str = ""
    status: str = ""
    source: str = ""
    created_at: str = ""
    updated_at: str = ""
    web_url: str = ""
    started_at: str | None = None
    finished_at: str | None = None
    duration: int | None = None
    queued_duration: int | None = None
    coverage: float | None = None
    yaml_errors: str | None = None
    user: dict | None = None
    name: str | None = None
    before_sha: str = ""
    tag: bool = False
    detached_head: bool = False


class TestReport(msgspec.Struct, gc=False, kw_only=True):
    """GitLab test report model."""

    id: int = 0
    total_time: float = 0.0
    total_count: int = 0
    success_count: int = 0
    failed_count: int = 0
    skipped_count: int = 0
    error_count: int = 0
    job_summary: dict | None = None
    test_suites: list[dict] | None = None


class TestReportSummary(msgspec.Struct, gc=False, kw_only=True):
    """GitLab test report summary model."""

    total_time: float = 0.0
    total_count: int = 0
    success_count: int = 0
    failed_count: int = 0
    skipped_count: int = 0
    error_count: int = 0
    summary: dict | None = None


_pipeline_decoder = msgspec.json.Decoder(Pipeline)
_pipeline_list_decoder = msgspec.json.Decoder(list[Pipeline])
