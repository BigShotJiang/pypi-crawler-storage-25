from __future__ import annotations

import msgspec


class IncidentManagement(msgspec.Struct, gc=False, kw_only=True):
    """GitLab incident_management model."""

    id: int = 0
    title: str = ""
    description: str | None = None
    status: str = ""
    severity: str = ""
    created_at: str = ""
    updated_at: str = ""
    started_at: str | None = None
    resolved_at: str | None = None
    author: dict = {}
    assignees: list[dict] = []
    project: dict = {}
    issue: dict = {}
    resource_labels: list[dict] = []
    todo_users: list[dict] = []
    alert_management_alerts: list[dict] = []
    health_status: str | None = None
    escalation_policy: dict | None = None
    on_call_schedule: dict | None = None
    rotation: dict | None = None
    escalation_level: int | None = None
    escalation_target: dict | None = None
    escalation_target_type: str | None = None
    escalation_target_id: int | None = None
    escalation_target_name: str | None = None
    escalation_target_url: str | None = None
    escalation_target_enabled: bool = False
    escalation_target_delay: int | None = None
    escalation_target_repeat: int | None = None
    escalation_target_repeat_delay: int | None = None
