from __future__ import annotations

import msgspec


class Badge(msgspec.Struct, gc=False, kw_only=True):
    """GitLab badges model."""

    id: int = 0
    link_url: str = ""
    image_url: str = ""
    rendered_link_url: str = ""
    rendered_image_url: str = ""
    kind: str = ""
