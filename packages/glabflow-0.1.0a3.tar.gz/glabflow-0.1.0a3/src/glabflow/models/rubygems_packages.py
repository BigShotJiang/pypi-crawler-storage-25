from __future__ import annotations

import msgspec


class RubygemsPackage(msgspec.Struct, gc=False, kw_only=True):
    """GitLab rubygems_packages model."""

    id: int = 0
    name: str = ""
    version: str = ""
    package_type: str = ""
    status: str = ""
    created_at: str = ""
    last_downloaded_at: str | None = None
