from __future__ import annotations

import msgspec


def decode_variable(data: bytes) -> Variable:
    """Decode a single Variable from JSON bytes."""
    return _variable_decoder.decode(data)


def decode_variable_list(data: bytes) -> list[Variable]:
    """Decode a list of Variable from JSON bytes."""
    return _variable_list_decoder.decode(data)


def decode_ci_variable(data: bytes) -> Variable:
    """Decode a single CIVariable (alias for Variable) from JSON bytes."""
    return _variable_decoder.decode(data)


class Variable(msgspec.Struct, gc=False, kw_only=True):
    """GitLab variables model."""

    key: str = ""
    variable_type: str = ""
    value: str = ""
    protected: bool = False
    masked: bool = False
    raw: bool = False
    environment_scope: str = ""
    description: str | None = None
    created_at: str = ""
    updated_at: str = ""


# Alias for backwards compatibility
CIVariable = Variable

_variable_decoder = msgspec.json.Decoder(Variable)
_variable_list_decoder = msgspec.json.Decoder(list[Variable])
