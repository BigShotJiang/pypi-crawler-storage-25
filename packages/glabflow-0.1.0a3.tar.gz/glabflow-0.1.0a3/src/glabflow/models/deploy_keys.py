from __future__ import annotations

import msgspec


class DeployKey(msgspec.Struct, gc=False, kw_only=True):
    """GitLab deploy_keys model."""

    id: int = 0
    title: str = ""
    key: str = ""
    fingerprint: str = ""
    created_at: str = ""
    can_push: bool = False
    projects: list[dict] = []
    owner: dict | None = None
