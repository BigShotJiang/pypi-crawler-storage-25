from __future__ import annotations

import msgspec


def decode_deployment(data: bytes) -> Deployment:
    """Decode a single Deployment from JSON bytes."""
    return _deployment_decoder.decode(data)


def decode_deployment_list(data: bytes) -> list[Deployment]:
    """Decode a list of Deployment from JSON bytes."""
    return _deployment_list_decoder.decode(data)


def decode_environment(data: bytes) -> Environment:
    """Decode a single Environment from JSON bytes."""
    return _environment_decoder.decode(data)


def decode_environment_list(data: bytes) -> list[Environment]:
    """Decode a list of Environment from JSON bytes."""
    return _environment_list_decoder.decode(data)


class Deployment(msgspec.Struct, gc=False, kw_only=True):
    """GitLab deployments model."""

    id: int = 0
    iid: int = 0
    ref: str = ""
    sha: str = ""
    environment: dict = {}
    project_id: int = 0
    status: str = ""
    created_at: str = ""
    updated_at: str = ""
    user: dict | None = None
    pipeline: dict | None = None
    deployable: dict | None = None
    duration: int | None = None
    web_url: str = ""
    rendered_variables: dict | None = None
    status_details: str | None = None


class Environment(msgspec.Struct, gc=False, kw_only=True):
    """GitLab environment model."""

    id: int = 0
    name: str = ""
    slug: str = ""
    external_url: str = ""
    project_id: int = 0
    state: str = ""
    created_at: str = ""
    updated_at: str = ""
    environment_type: str | None = None
    tier: str | None = None


_deployment_decoder = msgspec.json.Decoder(Deployment)
_deployment_list_decoder = msgspec.json.Decoder(list[Deployment])
_environment_decoder = msgspec.json.Decoder(Environment)
_environment_list_decoder = msgspec.json.Decoder(list[Environment])
