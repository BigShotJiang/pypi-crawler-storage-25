from __future__ import annotations

import msgspec


def decode_label(data: bytes) -> Label:
    """Decode a single Label from JSON bytes."""
    return _label_decoder.decode(data)


def decode_label_list(data: bytes) -> list[Label]:
    """Decode a list of Label from JSON bytes."""
    return _label_list_decoder.decode(data)


class Label(msgspec.Struct, gc=False, kw_only=True):
    """GitLab labels model."""

    id: int = 0
    name: str = ""
    color: str = ""
    text_color: str = ""
    description: str | None = None
    description_html: str | None = None
    created_at: str = ""
    updated_at: str = ""
    priority: int | None = None
    is_project_label: bool = False


_label_decoder = msgspec.json.Decoder(Label)
_label_list_decoder = msgspec.json.Decoder(list[Label])
