from __future__ import annotations

import msgspec


class Trigger(msgspec.Struct, gc=False, kw_only=True):
    """GitLab triggers model."""

    id: int = 0
    description: str = ""
    created_at: str = ""
    last_used: str | None = None
    token: str | None = None
    updated_at: str = ""
    owner: dict | None = None
    push_events: bool = False
