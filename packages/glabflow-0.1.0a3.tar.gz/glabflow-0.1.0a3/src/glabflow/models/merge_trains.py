from __future__ import annotations

import msgspec


class MergeTrain(msgspec.Struct, gc=False, kw_only=True):
    """GitLab merge_trains model."""

    id: int = 0
    merge_train_id: int = 0
    status: str = ""
    merged_at: str | None = None
    duration: int | None = None
    user: dict = {}
    merge_request: dict = {}
    pipeline: dict | None = None
    created_at: str = ""
    updated_at: str = ""
    failure_reason: str | None = None
    failure_details: dict | None = None
    position: int = 0
    estimated_duration: int | None = None
    estimated_start_time: str | None = None
    estimated_merge_time: str | None = None
    merge_when_pipeline_succeeds: bool = False
    merge_method: str = ""
    squash: bool = False
    should_remove_source_branch: bool = False
    force_remove_source_branch: bool = False
    allow_collaboration: bool = False
    blocking_discussions_resolved: bool = False
    approvals_before_merge: int | None = None
    detailed_merge_status: str = ""
    merge_status: str = ""
    sha: str = ""
    merge_commit_sha: str | None = None
    squash_commit_sha: str | None = None
    discussion_locked: bool = False
    changes_count: str = ""
    web_url: str = ""
    references: dict = {}
    task_completion_status: dict = {}
    prepared_at: str | None = None
    has_conflicts: bool = False
    overflow: bool = False
    merge_error: str | None = None
    first_contribution: bool = False
    merge_trains_enabled: bool = False
