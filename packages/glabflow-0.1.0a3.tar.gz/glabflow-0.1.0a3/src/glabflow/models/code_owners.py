from __future__ import annotations

import msgspec


class CodeOwner(msgspec.Struct, gc=False, kw_only=True):
    """GitLab code_owners model."""

    id: int = 0
    path: str = ""
    owner: dict = {}
    created_at: str = ""
    updated_at: str = ""
