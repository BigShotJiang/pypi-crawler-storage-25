from __future__ import annotations

import msgspec


class ApprovalRule(msgspec.Struct, gc=False, kw_only=True):
    """GitLab approval_rules model."""

    id: int = 0
    name: str = ""
    rule_type: str = ""
    eligible_approvers: list[dict] = []
    approvals_required: int = 0
    users: list[dict] = []
    groups: list[dict] = []
    contains_hidden_groups: bool = False
    protected_branches: list[dict] = []
    approval_project_rule_id: int | None = None
