from __future__ import annotations

import msgspec


def decode_group(data: bytes) -> Group:
    """Decode a single Group from JSON bytes."""
    return _group_decoder.decode(data)


def decode_group_list(data: bytes) -> list[Group]:
    """Decode a list of Group from JSON bytes."""
    return _group_list_decoder.decode(data)


class Group(msgspec.Struct, gc=False, kw_only=True):
    """GitLab groups model."""

    id: int = 0
    name: str = ""
    path: str = ""
    description: str | None = None
    visibility: str = ""
    avatar_url: str | None = None
    web_url: str = ""
    request_access_enabled: bool = False
    full_name: str = ""
    full_path: str = ""
    file_template_project_id: int | None = None
    parent_id: int | None = None
    created_at: str = ""
    ldap_cn: str | None = None
    ldap_access: bool = False
    shared_runners_minutes_limit: int | None = None
    extra_shared_runners_minutes_limit: int | None = None
    prevent_forking_outside_group: bool = False
    shared_runners_setting: str = ""


_group_decoder = msgspec.json.Decoder(Group)
_group_list_decoder = msgspec.json.Decoder(list[Group])
