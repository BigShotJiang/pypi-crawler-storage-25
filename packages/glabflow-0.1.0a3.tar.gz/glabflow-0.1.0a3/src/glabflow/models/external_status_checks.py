from __future__ import annotations

import msgspec


class ExternalStatusCheck(msgspec.Struct, gc=False, kw_only=True):
    """GitLab external_status_checks model."""

    id: int = 0
    name: str = ""
    external_url: str = ""
    protected_branches: list[dict] = []
    status: str = ""
    required: bool = False
    allow_on_protected_branches: bool = False
    access_level: int = 0
