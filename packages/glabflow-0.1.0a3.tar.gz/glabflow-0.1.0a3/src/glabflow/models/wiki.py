"""Alias for wikis module - backwards compatibility."""

from .wikis import (
    Wiki,
    WikiPage,
    decode_wiki,
    decode_wiki_list,
    decode_wiki_page,
    decode_wiki_page_list,
)

__all__ = [
    "Wiki",
    "WikiPage",
    "decode_wiki",
    "decode_wiki_list",
    "decode_wiki_page",
    "decode_wiki_page_list",
]
