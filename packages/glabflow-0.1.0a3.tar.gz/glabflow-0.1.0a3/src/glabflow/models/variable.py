"""Alias for variables module - backwards compatibility."""

from .variables import (
    CIVariable,
    Variable,
    decode_ci_variable,
    decode_variable,
    decode_variable_list,
)

__all__ = [
    "CIVariable",
    "Variable",
    "decode_ci_variable",
    "decode_variable",
    "decode_variable_list",
]
