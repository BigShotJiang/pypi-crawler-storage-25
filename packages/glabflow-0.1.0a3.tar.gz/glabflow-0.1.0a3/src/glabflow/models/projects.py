from __future__ import annotations

import msgspec


def decode_project(data: bytes) -> Project:
    """Decode a single Project from JSON bytes."""
    return _project_decoder.decode(data)


def decode_project_list(data: bytes) -> list[Project]:
    """Decode a list of Project from JSON bytes."""
    return _project_list_decoder.decode(data)


class Project(msgspec.Struct, gc=False, kw_only=True):
    """GitLab projects model."""

    id: int = 0
    name: str = ""
    path: str = ""
    path_with_namespace: str = ""
    description: str | None = None
    created_at: str = ""
    default_branch: str | None = None
    tag_list: list[str] = []
    topics: list[str] = []
    ssh_url_to_repo: str = ""
    http_url_to_repo: str = ""
    web_url: str = ""
    readme_url: str | None = None
    avatar_url: str | None = None
    forks_count: int = 0
    star_count: int = 0
    last_activity_at: str = ""
    namespace: dict = {}
    archived: bool = False
    visibility: str = ""
    resolve_outdated_diff_discussions: bool = False
    container_registry_enabled: bool = False
    issues_enabled: bool = False
    merge_requests_enabled: bool = False
    wiki_enabled: bool = False
    jobs_enabled: bool = False
    snippets_enabled: bool = False
    service_desk_enabled: bool = False
    can_create_merge_request_in: bool = False
    issues_access_level: str = ""
    repository_access_level: str = ""
    merge_requests_access_level: str = ""
    forking_access_level: str = ""
    wiki_access_level: str = ""
    builds_access_level: str = ""
    snippets_access_level: str = ""
    pages_access_level: str = ""
    operations_access_level: str = ""
    analytics_access_level: str = ""
    emails_enabled: bool = False
    container_registry_access_level: str = ""
    security_and_compliance_access_level: str = ""
    creator_id: int = 0
    import_status: str = ""
    import_error: str | None = None
    open_issues_count: int = 0
    ci_default_git_depth: int = 0
    ci_forward_deployment_enabled: bool = False
    public_jobs: bool = False
    build_timeout: int = 0
    auto_cancel_pending_pipelines: str = ""
    build_coverage_regex: str | None = None
    shared_with_groups: list = []
    only_allow_merge_if_pipeline_succeeds: bool = False
    allow_merge_on_skipped_pipeline: bool = False
    restrict_user_defined_variables: bool = False
    only_allow_merge_if_all_discussions_are_resolved: bool = False
    remove_source_branch_after_merge: bool = False
    printing_merge_request_link_enabled: bool = False
    merge_method: str = ""
    squash_option: str = ""
    enforce_auth_checks_on_uploads: bool = False
    suggestion_commit_message: str | None = None
    merge_commit_template: str | None = None
    squash_commit_template: str | None = None
    issue_branch_template: str | None = None
    keep_latest_artifact: bool = False
    runner_token_expiration_interval: int | None = None
    has_issues: bool = False
    has_wiki: bool = False
    has_readme: bool = False
    approvals_before_merge: int = 0
    mirror: bool = False
    mirror_user_id: int | None = None
    mirror_trigger_builds: bool = False
    only_mirror_protected_branches: bool = False
    mirror_overwrites_diverged_branches: bool = False
    packages_enabled: bool = False
    service_desk_address: str | None = None
    autoclose_referenced_issues: bool = False
    repository_storage: str = ""
    license_url: str | None = None
    license: dict | None = None


_project_decoder = msgspec.json.Decoder(Project)
_project_list_decoder = msgspec.json.Decoder(list[Project])
