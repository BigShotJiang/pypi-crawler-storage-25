from __future__ import annotations

import msgspec


class Vulnerabilitie(msgspec.Struct, gc=False, kw_only=True):
    """GitLab vulnerabilities model."""

    id: int = 0
    title: str = ""
    description: str | None = None
    state: str = ""
    severity: str = ""
    confidence: str = ""
    report_type: str = ""
    created_at: str = ""
    updated_at: str = ""
    project: dict = {}
    scanner: dict = {}
    identifiers: list[dict] = []
    location: dict = {}
    solution: str | None = None
    fingerprint: str = ""
    project_fingerprint: str = ""
    has_issues: bool = False
    issue_links: list[dict] = []
    user_can_disable: bool = False
    retired: bool = False
    retired_at: str | None = None
    retired_by: dict | None = None
    vendor: dict | None = None
    instance: dict | None = None
    finding: dict | None = None
    pipeline: dict | None = None
    container: dict | None = None
    operating_system: dict | None = None
    package: dict | None = None
    external_links: list[dict] = []
    remediations: list[dict] = []
    feedback: dict | None = None
