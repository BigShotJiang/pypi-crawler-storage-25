"""Alias for deployments module - backwards compatibility."""

from .deployments import (
    Deployment,
    Environment,
    decode_deployment,
    decode_deployment_list,
    decode_environment,
    decode_environment_list,
)

__all__ = [
    "Deployment",
    "Environment",
    "decode_deployment",
    "decode_deployment_list",
    "decode_environment",
    "decode_environment_list",
]
