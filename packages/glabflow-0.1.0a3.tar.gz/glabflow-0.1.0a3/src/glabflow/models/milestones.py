from __future__ import annotations

import msgspec


def decode_milestone(data: bytes) -> Milestone:
    """Decode a single Milestone from JSON bytes."""
    return _milestone_decoder.decode(data)


def decode_milestone_list(data: bytes) -> list[Milestone]:
    """Decode a list of Milestone from JSON bytes."""
    return _milestone_list_decoder.decode(data)


def decode_milestone_detail(data: bytes) -> MilestoneDetail:
    """Decode a single MilestoneDetail from JSON bytes."""
    return _milestone_detail_decoder.decode(data)


def decode_milestone_detail_list(data: bytes) -> list[MilestoneDetail]:
    """Decode a list of MilestoneDetail from JSON bytes."""
    return _milestone_detail_list_decoder.decode(data)


class Milestone(msgspec.Struct, gc=False, kw_only=True):
    """GitLab milestones model."""

    id: int = 0
    iid: int = 0
    project_id: int = 0
    group_id: int | None = None
    title: str = ""
    description: str | None = None
    state: str = ""
    created_at: str = ""
    updated_at: str = ""
    due_date: str | None = None
    start_date: str | None = None
    expired: bool = False
    web_url: str = ""
    references: dict = {}


class MilestoneDetail(msgspec.Struct, gc=False, kw_only=True):
    """GitLab milestone detail model."""

    id: int = 0
    iid: int = 0
    project_id: int = 0
    title: str = ""
    description: str | None = None
    state: str = ""
    created_at: str = ""
    updated_at: str = ""
    due_date: str | None = None
    start_date: str | None = None
    expired: bool = False
    web_url: str = ""


_milestone_decoder = msgspec.json.Decoder(Milestone)
_milestone_list_decoder = msgspec.json.Decoder(list[Milestone])
_milestone_detail_decoder = msgspec.json.Decoder(MilestoneDetail)
_milestone_detail_list_decoder = msgspec.json.Decoder(list[MilestoneDetail])
