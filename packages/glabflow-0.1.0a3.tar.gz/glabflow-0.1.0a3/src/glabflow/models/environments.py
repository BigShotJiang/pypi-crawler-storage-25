from __future__ import annotations

import msgspec


class Environment(msgspec.Struct, gc=False, kw_only=True):
    """GitLab environments model."""

    id: int = 0
    name: str = ""
    slug: str = ""
    external_url: str | None = None
    project_id: int = 0
    state: str = ""
    created_at: str = ""
    updated_at: str = ""
    environment_access_level: str = ""
    deploy_access_level: str = ""
    auto_stop_at: str | None = None
    web_url: str = ""
    latest_deployment: dict | None = None
    current_user_can_push: bool | None = None
    has_forward_deployment: bool = False
    has_deployment_access: bool = False
    protected: bool = False
    can_create_deployment: bool = False
    pull_from_fork: bool = False
    tier: str = ""
    deployment_tier: str = ""
    action_access_level: str = ""


class ProtectedEnvironment(msgspec.Struct, gc=False, kw_only=True):
    """GitLab protected environments model."""

    id: int = 0
    name: str = ""
    environment_type: str | None = None
    deploy_access_level: str | None = None
    allowed_to_deploy: list[dict] | None = None
    prevent_fork_routes: bool | None = None
    timeout: int | None = None
    max_access_expiry: str | None = None
    required_approval_count: int | None = None
    required_approval_count_approvers: list[dict] | None = None
    project_id: int = 0
    created_at: str = ""
    updated_at: str = ""
