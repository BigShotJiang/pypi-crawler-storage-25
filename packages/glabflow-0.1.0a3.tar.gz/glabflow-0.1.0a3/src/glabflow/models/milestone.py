"""Alias for milestones module - backwards compatibility."""

from .milestones import (
    Milestone,
    MilestoneDetail,
    decode_milestone,
    decode_milestone_detail,
    decode_milestone_detail_list,
    decode_milestone_list,
)

__all__ = [
    "Milestone",
    "MilestoneDetail",
    "decode_milestone",
    "decode_milestone_list",
    "decode_milestone_detail",
    "decode_milestone_detail_list",
]
