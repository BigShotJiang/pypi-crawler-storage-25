from __future__ import annotations

import msgspec


class Ci(msgspec.Struct, gc=False, kw_only=True):
    """GitLab ci model."""

    id: int = 0
    project_id: int = 0
    ref: str = ""
    sha: str = ""
    status: str = ""
    created_at: str = ""
    updated_at: str = ""
    yaml_errors: str | None = None
    user: dict | None = None
    name: str | None = None
    before_sha: str = ""
    tag: bool = False
    detached_head: bool = False
    source: str = ""
