from __future__ import annotations

import msgspec


class DockerfileTemplate(msgspec.Struct, gc=False, kw_only=True):
    """GitLab dockerfile_templates model."""

    name: str = ""
    slug: str = ""
    content: str | None = None
