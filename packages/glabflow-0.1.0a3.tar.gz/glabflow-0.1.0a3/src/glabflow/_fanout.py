from __future__ import annotations

import asyncio
from collections.abc import AsyncIterator, Callable, Coroutine
from typing import TypeVar

T = TypeVar("T")
S = TypeVar("S")


async def fanout[T, S](
    source: AsyncIterator[S],
    task_fn: Callable[[S], Coroutine[None, None, T]],
    concurrency: int = 50,
    chunk_size: int = 200,
    on_error: Callable[[BaseException], None] | None = None,
) -> AsyncIterator[T]:
    """
    Fan out task_fn over every item yielded by source.

    Bounded by concurrency using asyncio.Semaphore.
    Yields results in order as they complete.
    By default, exceptions are re-raised. Pass on_error to handle them instead.

    Uses an asyncio.Queue for O(1) completion dispatch instead of
    asyncio.wait(FIRST_COMPLETED) which is O(n) per completion.
    """
    semaphore = asyncio.Semaphore(concurrency)
    done_queue: asyncio.Queue[tuple[int, T | None, BaseException | None]] = asyncio.Queue()

    results: dict[int, T | BaseException] = {}
    next_result_index = 0
    task_counter = 0
    in_flight = 0

    async def run_and_notify(idx: int, item: S) -> None:
        async with semaphore:
            try:
                result = await task_fn(item)
                await done_queue.put((idx, result, None))
            except BaseException as exc:
                await done_queue.put((idx, None, exc))

    async for item in source:
        asyncio.create_task(run_and_notify(task_counter, item))
        task_counter += 1
        in_flight += 1

        # Drain completed results without blocking if queue has items
        while not done_queue.empty():
            idx, value, exc = done_queue.get_nowait()
            in_flight -= 1
            if exc is not None:
                if on_error is not None:
                    on_error(exc)
                    results[idx] = exc  # sentinel to unblock ordering
                else:
                    raise exc
            else:
                results[idx] = value  # type: ignore[assignment]

            while next_result_index in results:
                item = results.pop(next_result_index)
                next_result_index += 1
                if not isinstance(item, BaseException):
                    yield item

        # If at concurrency cap, block until one slot frees
        if in_flight >= concurrency:
            idx, value, exc = await done_queue.get()
            in_flight -= 1
            if exc is not None:
                if on_error is not None:
                    on_error(exc)
                    results[idx] = exc  # sentinel to unblock ordering
                else:
                    raise exc
            else:
                results[idx] = value  # type: ignore[assignment]

            while next_result_index in results:
                item = results.pop(next_result_index)
                next_result_index += 1
                if not isinstance(item, BaseException):
                    yield item

    # Drain all remaining in-flight tasks
    while in_flight > 0:
        idx, value, exc = await done_queue.get()
        in_flight -= 1
        if exc is not None:
            if on_error is not None:
                on_error(exc)
                results[idx] = exc  # sentinel to unblock ordering
            else:
                raise exc
        else:
            results[idx] = value  # type: ignore[assignment]

        while next_result_index in results:
            item = results.pop(next_result_index)
            next_result_index += 1
            if not isinstance(item, BaseException):
                yield item
