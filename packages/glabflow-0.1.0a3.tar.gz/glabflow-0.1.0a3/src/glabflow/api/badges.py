from __future__ import annotations

from collections.abc import AsyncIterator
from typing import TYPE_CHECKING, Any

import msgspec

from glabflow.models.badges import Badge

if TYPE_CHECKING:
    from glabflow._client import GitLabClient


# Decoder for badges
_badges_decoder = msgspec.json.Decoder(list[Badge])
_badges_single_decoder = msgspec.json.Decoder(Badge)


class BadgesAPI:
    """Async API for accessing GitLab badges."""

    def __init__(self, client: GitLabClient) -> None:
        self._client = client

    async def stream(self, **params: Any) -> AsyncIterator[Badge]:
        """Stream all badges with keyset pagination.

        Args:
            **params: Additional query parameters

        Yields:
            Badge: GitLab badges resource items
        """
        async for page_bytes in self._client.paginate("/badges", **params):
            for item in _badges_decoder.decode(page_bytes):
                yield item

    async def get(self, id: int, **params: Any) -> Badge:
        """Get a specific badges by ID.

        Args:
            id: Badge ID
            **params: Additional query parameters

        Returns:
            Badge: The requested item
        """
        path = f"/badges/{id}"
        data = await self._client.get(path, **params)
        return _badges_single_decoder.decode(data)

    async def list_page(self, **params: Any) -> list[Badge]:
        """List a single page of badges.

        Args:
            **params: Query parameters (page, per_page, etc.)

        Returns:
            list[Badge]: List of items
        """
        data = await self._client.get("/badges", **params)
        return _badges_decoder.decode(data)
