from __future__ import annotations

from collections.abc import AsyncIterator
from typing import TYPE_CHECKING, Any

import msgspec

from glabflow.models.generic_packages import GenericPackage

if TYPE_CHECKING:
    from glabflow._client import GitLabClient


# Decoder for generic_packages
_generic_packages_decoder = msgspec.json.Decoder(list[GenericPackage])
_generic_packages_single_decoder = msgspec.json.Decoder(GenericPackage)


class GenericPackagesAPI:
    """Async API for accessing GitLab generic_packages."""

    def __init__(self, client: GitLabClient) -> None:
        self._client = client

    async def stream(self, **params: Any) -> AsyncIterator[GenericPackage]:
        """Stream all generic_packages with keyset pagination.

        Args:
            **params: Additional query parameters

        Yields:
            GenericPackage: GitLab generic_packages resource items
        """
        async for page_bytes in self._client.paginate("/generic_packages", **params):
            for item in _generic_packages_decoder.decode(page_bytes):
                yield item

    async def get(self, id: int, **params: Any) -> GenericPackage:
        """Get a specific generic_packages by ID.

        Args:
            id: GenericPackage ID
            **params: Additional query parameters

        Returns:
            GenericPackage: The requested item
        """
        path = f"/generic_packages/{id}"
        data = await self._client.get(path, **params)
        return _generic_packages_single_decoder.decode(data)

    async def list_page(self, **params: Any) -> list[GenericPackage]:
        """List a single page of generic_packages.

        Args:
            **params: Query parameters (page, per_page, etc.)

        Returns:
            list[GenericPackage]: List of items
        """
        data = await self._client.get("/generic_packages", **params)
        return _generic_packages_decoder.decode(data)
