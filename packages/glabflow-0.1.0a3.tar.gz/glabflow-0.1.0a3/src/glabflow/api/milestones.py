from __future__ import annotations

from collections.abc import AsyncIterator
from typing import TYPE_CHECKING, Any

import msgspec

from glabflow.models.milestones import Milestone, MilestoneDetail

if TYPE_CHECKING:
    from glabflow._client import GitLabClient


# Decoder for milestones
_milestone_decoder = msgspec.json.Decoder(Milestone)
_milestone_list_decoder = msgspec.json.Decoder(list[Milestone])
_milestone_detail_decoder = msgspec.json.Decoder(MilestoneDetail)
_milestone_detail_list_decoder = msgspec.json.Decoder(list[MilestoneDetail])


class MilestonesAPI:
    """Async API for accessing GitLab milestones."""

    def __init__(self, client: GitLabClient) -> None:
        self._client = client

    async def stream(self, **params: Any) -> AsyncIterator[Milestone]:
        """Stream all milestones with keyset pagination."""
        async for page_bytes in self._client.paginate("/milestones", **params):
            for item in _milestone_list_decoder.decode(page_bytes):
                yield item

    async def stream_project(
        self, project_id: int, **params: Any
    ) -> AsyncIterator[MilestoneDetail]:
        """Stream milestones for a project."""
        async for page_bytes in self._client.paginate(
            f"/projects/{project_id}/milestones", **params
        ):
            for item in _milestone_detail_list_decoder.decode(page_bytes):
                yield item

    async def stream_group(
        self, group_id: int, **params: Any
    ) -> AsyncIterator[MilestoneDetail]:
        """Stream milestones for a group."""
        async for page_bytes in self._client.paginate(
            f"/groups/{group_id}/milestones", **params
        ):
            for item in _milestone_detail_list_decoder.decode(page_bytes):
                yield item

    async def get(self, id: int, **params: Any) -> Milestone:
        """Get a specific milestone by ID."""
        path = f"/milestones/{id}"
        data = await self._client.get(path, **params)
        return _milestone_decoder.decode(data)

    async def get_project(
        self, project_id: int, milestone_iid: int, **params: Any
    ) -> MilestoneDetail:
        """Get a specific project milestone by IID."""
        path = f"/projects/{project_id}/milestones/{milestone_iid}"
        data = await self._client.get(path, **params)
        return _milestone_detail_decoder.decode(data)

    async def get_group(
        self, group_id: int, milestone_iid: int, **params: Any
    ) -> MilestoneDetail:
        """Get a specific group milestone by IID."""
        path = f"/groups/{group_id}/milestones/{milestone_iid}"
        data = await self._client.get(path, **params)
        return _milestone_detail_decoder.decode(data)

    async def list_page(self, **params: Any) -> list[Milestone]:
        """List a single page of milestones."""
        data = await self._client.get("/milestones", **params)
        return _milestone_list_decoder.decode(data)
