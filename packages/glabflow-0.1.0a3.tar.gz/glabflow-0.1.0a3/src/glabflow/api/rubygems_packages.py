from __future__ import annotations

from collections.abc import AsyncIterator
from typing import TYPE_CHECKING, Any

import msgspec

from glabflow.models.rubygems_packages import RubygemsPackage

if TYPE_CHECKING:
    from glabflow._client import GitLabClient


# Decoder for rubygems_packages
_rubygems_packages_decoder = msgspec.json.Decoder(list[RubygemsPackage])
_rubygems_packages_single_decoder = msgspec.json.Decoder(RubygemsPackage)


class RubygemsPackagesAPI:
    """Async API for accessing GitLab rubygems_packages."""

    def __init__(self, client: GitLabClient) -> None:
        self._client = client

    async def stream(self, **params: Any) -> AsyncIterator[RubygemsPackage]:
        """Stream all rubygems_packages with keyset pagination.

        Args:
            **params: Additional query parameters

        Yields:
            RubygemsPackage: GitLab rubygems_packages resource items
        """
        async for page_bytes in self._client.paginate("/rubygems_packages", **params):
            for item in _rubygems_packages_decoder.decode(page_bytes):
                yield item

    async def get(self, id: int, **params: Any) -> RubygemsPackage:
        """Get a specific rubygems_packages by ID.

        Args:
            id: RubygemsPackage ID
            **params: Additional query parameters

        Returns:
            RubygemsPackage: The requested item
        """
        path = f"/rubygems_packages/{id}"
        data = await self._client.get(path, **params)
        return _rubygems_packages_single_decoder.decode(data)

    async def list_page(self, **params: Any) -> list[RubygemsPackage]:
        """List a single page of rubygems_packages.

        Args:
            **params: Query parameters (page, per_page, etc.)

        Returns:
            list[RubygemsPackage]: List of items
        """
        data = await self._client.get("/rubygems_packages", **params)
        return _rubygems_packages_decoder.decode(data)
