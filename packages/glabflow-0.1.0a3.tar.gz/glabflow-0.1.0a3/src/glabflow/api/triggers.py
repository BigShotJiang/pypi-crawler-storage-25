from __future__ import annotations

from collections.abc import AsyncIterator
from typing import TYPE_CHECKING, Any

import msgspec

from glabflow.models.triggers import Trigger

if TYPE_CHECKING:
    from glabflow._client import GitLabClient


# Decoder for triggers
_triggers_decoder = msgspec.json.Decoder(list[Trigger])
_triggers_single_decoder = msgspec.json.Decoder(Trigger)


class TriggersAPI:
    """Async API for accessing GitLab triggers."""

    def __init__(self, client: GitLabClient) -> None:
        self._client = client

    async def stream(self, **params: Any) -> AsyncIterator[Trigger]:
        """Stream all triggers with keyset pagination.

        Args:
            **params: Additional query parameters

        Yields:
            Trigger: GitLab triggers resource items
        """
        async for page_bytes in self._client.paginate("/triggers", **params):
            for item in _triggers_decoder.decode(page_bytes):
                yield item

    async def get(self, id: int, **params: Any) -> Trigger:
        """Get a specific triggers by ID.

        Args:
            id: Trigger ID
            **params: Additional query parameters

        Returns:
            Trigger: The requested item
        """
        path = f"/triggers/{id}"
        data = await self._client.get(path, **params)
        return _triggers_single_decoder.decode(data)

    async def list_page(self, **params: Any) -> list[Trigger]:
        """List a single page of triggers.

        Args:
            **params: Query parameters (page, per_page, etc.)

        Returns:
            list[Trigger]: List of items
        """
        data = await self._client.get("/triggers", **params)
        return _triggers_decoder.decode(data)
