from __future__ import annotations

from collections.abc import AsyncIterator
from typing import TYPE_CHECKING, Any

import msgspec

from glabflow.models.labels import Label

if TYPE_CHECKING:
    from glabflow._client import GitLabClient


# Decoder for labels
_label_decoder = msgspec.json.Decoder(Label)
_label_list_decoder = msgspec.json.Decoder(list[Label])


class LabelsAPI:
    """Async API for accessing GitLab labels."""

    def __init__(self, client: GitLabClient) -> None:
        self._client = client

    async def stream(self, **params: Any) -> AsyncIterator[Label]:
        """Stream all labels with keyset pagination."""
        async for page_bytes in self._client.paginate("/labels", **params):
            for item in _label_list_decoder.decode(page_bytes):
                yield item

    async def stream_project(
        self, project_id: int, **params: Any
    ) -> AsyncIterator[Label]:
        """Stream labels for a project."""
        # Convert boolean with_counts to string
        if "with_counts" in params:
            params["with_counts"] = "true" if params["with_counts"] else "false"
        async for page_bytes in self._client.paginate(
            f"/projects/{project_id}/labels", **params
        ):
            for item in _label_list_decoder.decode(page_bytes):
                yield item

    async def stream_group(self, group_id: int, **params: Any) -> AsyncIterator[Label]:
        """Stream labels for a group."""
        async for page_bytes in self._client.paginate(
            f"/groups/{group_id}/labels", **params
        ):
            for item in _label_list_decoder.decode(page_bytes):
                yield item

    async def get(self, id: int, **params: Any) -> Label:
        """Get a specific label by ID."""
        path = f"/labels/{id}"
        data = await self._client.get(path, **params)
        return _label_decoder.decode(data)

    async def get_project(
        self, project_id: int, label_id: int | str, **params: Any
    ) -> Label:
        """Get a specific project label by ID."""
        path = f"/projects/{project_id}/labels/{label_id}"
        data = await self._client.get(path, **params)
        return _label_decoder.decode(data)

    async def get_group(
        self, group_id: int, label_id: int | str, **params: Any
    ) -> Label:
        """Get a specific group label by ID."""
        path = f"/groups/{group_id}/labels/{label_id}"
        data = await self._client.get(path, **params)
        return _label_decoder.decode(data)

    async def list_page(self, **params: Any) -> list[Label]:
        """List a single page of labels."""
        data = await self._client.get("/labels", **params)
        return _label_list_decoder.decode(data)
