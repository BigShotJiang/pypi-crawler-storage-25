from __future__ import annotations

from collections.abc import AsyncIterator
from typing import TYPE_CHECKING, Any

import msgspec

from glabflow.models.deploy_tokens import DeployToken

if TYPE_CHECKING:
    from glabflow._client import GitLabClient


# Decoder for deploy_tokens
_deploy_tokens_decoder = msgspec.json.Decoder(list[DeployToken])
_deploy_tokens_single_decoder = msgspec.json.Decoder(DeployToken)


class DeployTokensAPI:
    """Async API for accessing GitLab deploy_tokens."""

    def __init__(self, client: GitLabClient) -> None:
        self._client = client

    async def stream(self, **params: Any) -> AsyncIterator[DeployToken]:
        """Stream all deploy_tokens with keyset pagination.

        Args:
            **params: Additional query parameters

        Yields:
            DeployToken: GitLab deploy_tokens resource items
        """
        async for page_bytes in self._client.paginate("/deploy_tokens", **params):
            for item in _deploy_tokens_decoder.decode(page_bytes):
                yield item

    async def get(self, id: int, **params: Any) -> DeployToken:
        """Get a specific deploy_tokens by ID.

        Args:
            id: DeployToken ID
            **params: Additional query parameters

        Returns:
            DeployToken: The requested item
        """
        path = f"/deploy_tokens/{id}"
        data = await self._client.get(path, **params)
        return _deploy_tokens_single_decoder.decode(data)

    async def list_page(self, **params: Any) -> list[DeployToken]:
        """List a single page of deploy_tokens.

        Args:
            **params: Query parameters (page, per_page, etc.)

        Returns:
            list[DeployToken]: List of items
        """
        data = await self._client.get("/deploy_tokens", **params)
        return _deploy_tokens_decoder.decode(data)
