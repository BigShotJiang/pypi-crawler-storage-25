from __future__ import annotations

from collections.abc import AsyncIterator
from typing import TYPE_CHECKING, Any

import msgspec

from glabflow.models.keys import Key

if TYPE_CHECKING:
    from glabflow._client import GitLabClient


# Decoder for keys
_keys_decoder = msgspec.json.Decoder(list[Key])
_keys_single_decoder = msgspec.json.Decoder(Key)


class KeysAPI:
    """Async API for accessing GitLab keys."""

    def __init__(self, client: GitLabClient) -> None:
        self._client = client

    async def stream(self, **params: Any) -> AsyncIterator[Key]:
        """Stream all keys with keyset pagination.

        Args:
            **params: Additional query parameters

        Yields:
            Key: GitLab keys resource items
        """
        async for page_bytes in self._client.paginate("/keys", **params):
            for item in _keys_decoder.decode(page_bytes):
                yield item

    async def get(self, id: int, **params: Any) -> Key:
        """Get a specific keys by ID.

        Args:
            id: Key ID
            **params: Additional query parameters

        Returns:
            Key: The requested item
        """
        path = f"/keys/{id}"
        data = await self._client.get(path, **params)
        return _keys_single_decoder.decode(data)

    async def list_page(self, **params: Any) -> list[Key]:
        """List a single page of keys.

        Args:
            **params: Query parameters (page, per_page, etc.)

        Returns:
            list[Key]: List of items
        """
        data = await self._client.get("/keys", **params)
        return _keys_decoder.decode(data)
