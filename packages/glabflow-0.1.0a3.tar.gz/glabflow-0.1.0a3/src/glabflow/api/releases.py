from __future__ import annotations

from collections.abc import AsyncIterator
from typing import TYPE_CHECKING, Any

import msgspec

from glabflow.models.releases import Release, ReleaseLink

if TYPE_CHECKING:
    from glabflow._client import GitLabClient


# Decoder for releases
_release_decoder = msgspec.json.Decoder(Release)
_release_list_decoder = msgspec.json.Decoder(list[Release])
_release_link_decoder = msgspec.json.Decoder(ReleaseLink)
_release_link_list_decoder = msgspec.json.Decoder(list[ReleaseLink])


class ReleasesAPI:
    """Async API for accessing GitLab releases."""

    def __init__(self, client: GitLabClient) -> None:
        self._client = client

    async def stream(self, **params: Any) -> AsyncIterator[Release]:
        """Stream all releases with keyset pagination."""
        async for page_bytes in self._client.paginate("/releases", **params):
            for item in _release_list_decoder.decode(page_bytes):
                yield item

    async def stream_for_project(
        self, project_id: int, **params: Any
    ) -> AsyncIterator[Release]:
        """Stream releases for a project."""
        async for page_bytes in self._client.paginate(
            f"/projects/{project_id}/releases", **params
        ):
            for item in _release_list_decoder.decode(page_bytes):
                yield item

    async def stream_links(
        self, project_id: int, tag_name: str, **params: Any
    ) -> AsyncIterator[ReleaseLink]:
        """Stream release links."""
        async for page_bytes in self._client.paginate(
            f"/projects/{project_id}/releases/{tag_name}/assets/links", **params
        ):
            for item in _release_link_list_decoder.decode(page_bytes):
                yield item

    async def get(self, project_id: int, tag_name: str, **params: Any) -> Release:
        """Get a specific release by project ID and tag name."""
        path = f"/projects/{project_id}/releases/{tag_name}"
        data = await self._client.get(path, **params)
        return _release_decoder.decode(data)

    async def get_for_project(
        self, project_id: int, tag_name: str, **params: Any
    ) -> Release:
        """Get a specific project release by tag name."""
        path = f"/projects/{project_id}/releases/{tag_name}"
        data = await self._client.get(path, **params)
        return _release_decoder.decode(data)

    async def get_link(
        self, project_id: int, tag_name: str, link_id: int, **params: Any
    ) -> ReleaseLink:
        """Get a specific release link by ID."""
        path = f"/projects/{project_id}/releases/{tag_name}/assets/links/{link_id}"
        data = await self._client.get(path, **params)
        return _release_link_decoder.decode(data)

    async def list_page(self, **params: Any) -> list[Release]:
        """List a single page of releases."""
        data = await self._client.get("/releases", **params)
        return _release_list_decoder.decode(data)
