from __future__ import annotations

from collections.abc import AsyncIterator
from typing import TYPE_CHECKING, Any

import msgspec

from glabflow.models.todos import Todo

if TYPE_CHECKING:
    from glabflow._client import GitLabClient


# Decoder for todos
_todos_decoder = msgspec.json.Decoder(list[Todo])
_todos_single_decoder = msgspec.json.Decoder(Todo)


class TodosAPI:
    """Async API for accessing GitLab todos."""

    def __init__(self, client: GitLabClient) -> None:
        self._client = client

    async def stream(self, **params: Any) -> AsyncIterator[Todo]:
        """Stream all todos with keyset pagination.

        Args:
            **params: Additional query parameters

        Yields:
            Todo: GitLab todos resource items
        """
        async for page_bytes in self._client.paginate("/todos", **params):
            for item in _todos_decoder.decode(page_bytes):
                yield item

    async def get(self, id: int, **params: Any) -> Todo:
        """Get a specific todos by ID.

        Args:
            id: Todo ID
            **params: Additional query parameters

        Returns:
            Todo: The requested item
        """
        path = f"/todos/{id}"
        data = await self._client.get(path, **params)
        return _todos_single_decoder.decode(data)

    async def list_page(self, **params: Any) -> list[Todo]:
        """List a single page of todos.

        Args:
            **params: Query parameters (page, per_page, etc.)

        Returns:
            list[Todo]: List of items
        """
        data = await self._client.get("/todos", **params)
        return _todos_decoder.decode(data)
