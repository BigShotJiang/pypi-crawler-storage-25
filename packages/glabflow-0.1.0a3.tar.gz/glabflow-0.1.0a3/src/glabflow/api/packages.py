from __future__ import annotations

from collections.abc import AsyncIterator
from typing import TYPE_CHECKING, Any

import msgspec

from glabflow.models.packages import Package

if TYPE_CHECKING:
    from glabflow._client import GitLabClient


# Decoder for packages
_packages_decoder = msgspec.json.Decoder(list[Package])
_packages_single_decoder = msgspec.json.Decoder(Package)


class PackagesAPI:
    """Async API for accessing GitLab packages."""

    def __init__(self, client: GitLabClient) -> None:
        self._client = client

    async def stream(self, **params: Any) -> AsyncIterator[Package]:
        """Stream all packages with keyset pagination.

        Args:
            **params: Additional query parameters

        Yields:
            Package: GitLab packages resource items
        """
        async for page_bytes in self._client.paginate("/packages", **params):
            for item in _packages_decoder.decode(page_bytes):
                yield item

    async def get(self, id: int, **params: Any) -> Package:
        """Get a specific packages by ID.

        Args:
            id: Package ID
            **params: Additional query parameters

        Returns:
            Package: The requested item
        """
        path = f"/packages/{id}"
        data = await self._client.get(path, **params)
        return _packages_single_decoder.decode(data)

    async def list_page(self, **params: Any) -> list[Package]:
        """List a single page of packages.

        Args:
            **params: Query parameters (page, per_page, etc.)

        Returns:
            list[Package]: List of items
        """
        data = await self._client.get("/packages", **params)
        return _packages_decoder.decode(data)
