from __future__ import annotations

from collections.abc import AsyncIterator
from typing import TYPE_CHECKING, Any

import msgspec

from glabflow.models.environments import ProtectedEnvironment
from glabflow.models.protected_branches import ProtectedBranche

if TYPE_CHECKING:
    from glabflow._client import GitLabClient


# Decoder for protected_branches
_protected_branches_decoder = msgspec.json.Decoder(list[ProtectedBranche])
_protected_branches_single_decoder = msgspec.json.Decoder(ProtectedBranche)
_protected_environments_decoder = msgspec.json.Decoder(list[ProtectedEnvironment])


class ProtectedBranchesAPI:
    """Async API for accessing GitLab protected_branches."""

    def __init__(self, client: GitLabClient) -> None:
        self._client = client

    async def stream(
        self, project_id: int, **params: Any
    ) -> AsyncIterator[ProtectedBranche]:
        """Stream all protected_branches with keyset pagination.

        Args:
            project_id: Project ID
            **params: Additional query parameters

        Yields:
            ProtectedBranche: GitLab protected_branches resource items
        """
        path = f"/projects/{project_id}/protected_branches"
        async for page_bytes in self._client.paginate(path, **params):
            for item in _protected_branches_decoder.decode(page_bytes):
                yield item

    async def get(self, project_id: int, id: int, **params: Any) -> ProtectedBranche:
        """Get a specific protected_branches by ID.

        Args:
            project_id: Project ID
            id: ProtectedBranche ID
            **params: Additional query parameters

        Returns:
            ProtectedBranche: The requested item
        """
        path = f"/projects/{project_id}/protected_branches/{id}"
        data = await self._client.get(path, **params)
        return _protected_branches_single_decoder.decode(data)

    async def list_page(self, project_id: int, **params: Any) -> list[ProtectedBranche]:
        """List a single page of protected_branches.

        Args:
            project_id: Project ID
            **params: Query parameters (page, per_page, etc.)

        Returns:
            list[ProtectedBranche]: List of items
        """
        path = f"/projects/{project_id}/protected_branches"
        data = await self._client.get(path, **params)
        return _protected_branches_decoder.decode(data)

    async def stream_protected_environments(
        self, project_id: int, **params: Any
    ) -> AsyncIterator[ProtectedEnvironment]:
        """Stream all protected_environments with keyset pagination.

        Args:
            project_id: Project ID
            **params: Additional query parameters

        Yields:
            ProtectedEnvironment: GitLab protected_environments resource items
        """
        path = f"/projects/{project_id}/protected_environments"
        async for page_bytes in self._client.paginate(path, **params):
            for item in _protected_environments_decoder.decode(page_bytes):
                yield item

    async def list_protected_environments_page(
        self, project_id: int, **params: Any
    ) -> list[ProtectedEnvironment]:
        """List a single page of protected_environments.

        Args:
            project_id: Project ID
            **params: Query parameters (page, per_page, etc.)

        Returns:
            list[ProtectedEnvironment]: List of items
        """
        path = f"/projects/{project_id}/protected_environments"
        data = await self._client.get(path, **params)
        return _protected_environments_decoder.decode(data)
