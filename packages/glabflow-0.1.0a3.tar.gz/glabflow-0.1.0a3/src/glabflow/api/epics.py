from __future__ import annotations

from collections.abc import AsyncIterator
from typing import TYPE_CHECKING, Any

import msgspec

from glabflow.models.epics import Epic

if TYPE_CHECKING:
    from glabflow._client import GitLabClient


# Decoder for epics
_epics_decoder = msgspec.json.Decoder(list[Epic])
_epics_single_decoder = msgspec.json.Decoder(Epic)


class EpicsAPI:
    """Async API for accessing GitLab epics."""

    def __init__(self, client: GitLabClient) -> None:
        self._client = client

    async def stream(self, **params: Any) -> AsyncIterator[Epic]:
        """Stream all epics with keyset pagination.

        Args:
            **params: Additional query parameters

        Yields:
            Epic: GitLab epics resource items
        """
        async for page_bytes in self._client.paginate("/epics", **params):
            for item in _epics_decoder.decode(page_bytes):
                yield item

    async def get(self, id: int, **params: Any) -> Epic:
        """Get a specific epics by ID.

        Args:
            id: Epic ID
            **params: Additional query parameters

        Returns:
            Epic: The requested item
        """
        path = f"/epics/{id}"
        data = await self._client.get(path, **params)
        return _epics_single_decoder.decode(data)

    async def list_page(self, **params: Any) -> list[Epic]:
        """List a single page of epics.

        Args:
            **params: Query parameters (page, per_page, etc.)

        Returns:
            list[Epic]: List of items
        """
        data = await self._client.get("/epics", **params)
        return _epics_decoder.decode(data)
