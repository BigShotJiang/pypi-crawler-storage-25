from __future__ import annotations

from collections.abc import AsyncIterator
from typing import TYPE_CHECKING, Any

import msgspec

from glabflow.models.analytics import CodeCoverageActivity, ContributionStats

if TYPE_CHECKING:
    from glabflow._client import GitLabClient

_coverage_decoder = msgspec.json.Decoder(list[CodeCoverageActivity])
_contribution_decoder = msgspec.json.Decoder(list[ContributionStats])
_dict_decoder = msgspec.json.Decoder(dict)


class AnalyticsAPI:
    """Async API for GitLab analytics (code coverage, contribution stats)."""

    def __init__(self, client: GitLabClient) -> None:
        self._client = client

    async def stream_code_coverage(
        self, project_id: int, **params: Any
    ) -> AsyncIterator[CodeCoverageActivity]:
        """Stream code coverage activity for a project.

        Args:
            project_id: GitLab project ID
            **params: Filters: ref_path, start_date, end_date

        Yields:
            CodeCoverageActivity: Coverage data points per build
        """
        async for page_bytes in self._client.paginate(
            f"/projects/{project_id}/analytics/code_coverage", **params
        ):
            for item in _coverage_decoder.decode(page_bytes):
                yield item

    async def get_project_statistics(self, project_id: int) -> dict[str, Any]:
        """Get statistics for a project (stars, forks, open issues, etc.).

        Args:
            project_id: GitLab project ID

        Returns:
            dict: Raw statistics payload from GitLab
        """
        data = await self._client.get(f"/projects/{project_id}/statistics")
        return _dict_decoder.decode(data)

    async def stream_group_contribution_analytics(
        self, group_id: int, **params: Any
    ) -> AsyncIterator[ContributionStats]:
        """Stream contribution analytics for all members of a group.

        Args:
            group_id: GitLab group ID
            **params: Filters: from_date (translated to GitLab's ``from`` param)

        Yields:
            ContributionStats: Per-member commit/addition/deletion counts
        """
        # GitLab uses ``from`` which is a Python reserved keyword; accept
        # ``from_date`` as a convenience alias and translate before sending.
        translated: dict[str, Any] = dict(params)
        if "from_date" in translated:
            translated["from"] = translated.pop("from_date")

        async for page_bytes in self._client.paginate(
            f"/groups/{group_id}/analytics/contribution_analytics", **translated
        ):
            for item in _contribution_decoder.decode(page_bytes):
                yield item
