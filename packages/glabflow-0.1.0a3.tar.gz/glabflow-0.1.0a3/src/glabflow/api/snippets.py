from __future__ import annotations

from collections.abc import AsyncIterator
from typing import TYPE_CHECKING, Any

import msgspec

from glabflow.models.snippets import Snippet

if TYPE_CHECKING:
    from glabflow._client import GitLabClient


# Decoder for snippets
_snippet_decoder = msgspec.json.Decoder(Snippet)
_snippet_list_decoder = msgspec.json.Decoder(list[Snippet])


class SnippetsAPI:
    """Async API for accessing GitLab snippets."""

    def __init__(self, client: GitLabClient) -> None:
        self._client = client

    async def stream(self, **params: Any) -> AsyncIterator[Snippet]:
        """Stream all snippets with keyset pagination."""
        async for page_bytes in self._client.paginate("/snippets", **params):
            for item in _snippet_list_decoder.decode(page_bytes):
                yield item

    async def stream_public(self, **params: Any) -> AsyncIterator[Snippet]:
        """Stream public snippets."""
        async for page_bytes in self._client.paginate("/snippets/public", **params):
            for item in _snippet_list_decoder.decode(page_bytes):
                yield item

    async def stream_project(
        self, project_id: int, **params: Any
    ) -> AsyncIterator[Snippet]:
        """Stream snippets for a project."""
        async for page_bytes in self._client.paginate(
            f"/projects/{project_id}/snippets", **params
        ):
            for item in _snippet_list_decoder.decode(page_bytes):
                yield item

    async def get(self, id: int, **params: Any) -> Snippet:
        """Get a specific snippet by ID."""
        path = f"/snippets/{id}"
        data = await self._client.get(path, **params)
        return _snippet_decoder.decode(data)

    async def get_project_snippet(
        self, project_id: int, snippet_id: int, **params: Any
    ) -> Snippet:
        """Get a specific project snippet by ID."""
        path = f"/projects/{project_id}/snippets/{snippet_id}"
        data = await self._client.get(path, **params)
        return _snippet_decoder.decode(data)

    async def list_page(self, **params: Any) -> list[Snippet]:
        """List a single page of snippets."""
        data = await self._client.get("/snippets", **params)
        return _snippet_list_decoder.decode(data)
