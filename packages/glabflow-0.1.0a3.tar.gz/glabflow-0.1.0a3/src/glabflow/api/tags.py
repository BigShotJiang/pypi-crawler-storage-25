from __future__ import annotations

from collections.abc import AsyncIterator
from typing import TYPE_CHECKING, Any

import msgspec

from glabflow.models.tags import Tag

if TYPE_CHECKING:
    from glabflow._client import GitLabClient


# Decoder for tags
_tags_decoder = msgspec.json.Decoder(list[Tag])
_tags_single_decoder = msgspec.json.Decoder(Tag)


class TagsAPI:
    """Async API for accessing GitLab tags."""

    def __init__(self, client: GitLabClient) -> None:
        self._client = client

    async def stream(self, **params: Any) -> AsyncIterator[Tag]:
        """Stream all tags with keyset pagination.

        Args:
            **params: Additional query parameters

        Yields:
            Tag: GitLab tags resource items
        """
        async for page_bytes in self._client.paginate("/tags", **params):
            for item in _tags_decoder.decode(page_bytes):
                yield item

    async def get(self, id: int, **params: Any) -> Tag:
        """Get a specific tags by ID.

        Args:
            id: Tag ID
            **params: Additional query parameters

        Returns:
            Tag: The requested item
        """
        path = f"/tags/{id}"
        data = await self._client.get(path, **params)
        return _tags_single_decoder.decode(data)

    async def list_page(self, **params: Any) -> list[Tag]:
        """List a single page of tags.

        Args:
            **params: Query parameters (page, per_page, etc.)

        Returns:
            list[Tag]: List of items
        """
        data = await self._client.get("/tags", **params)
        return _tags_decoder.decode(data)
