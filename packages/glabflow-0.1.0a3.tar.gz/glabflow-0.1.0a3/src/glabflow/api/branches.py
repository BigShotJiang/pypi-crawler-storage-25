from __future__ import annotations

from collections.abc import AsyncIterator
from typing import TYPE_CHECKING, Any

import msgspec

from glabflow.models.branches import Branche

if TYPE_CHECKING:
    from glabflow._client import GitLabClient


# Decoder for branches
_branches_decoder = msgspec.json.Decoder(list[Branche])
_branches_single_decoder = msgspec.json.Decoder(Branche)


class BranchesAPI:
    """Async API for accessing GitLab branches."""

    def __init__(self, client: GitLabClient) -> None:
        self._client = client

    async def stream(self, **params: Any) -> AsyncIterator[Branche]:
        """Stream all branches with keyset pagination.

        Args:
            **params: Additional query parameters

        Yields:
            Branche: GitLab branches resource items
        """
        async for page_bytes in self._client.paginate("/branches", **params):
            for item in _branches_decoder.decode(page_bytes):
                yield item

    async def get(self, id: int, **params: Any) -> Branche:
        """Get a specific branches by ID.

        Args:
            id: Branche ID
            **params: Additional query parameters

        Returns:
            Branche: The requested item
        """
        path = f"/branches/{id}"
        data = await self._client.get(path, **params)
        return _branches_single_decoder.decode(data)

    async def list_page(self, **params: Any) -> list[Branche]:
        """List a single page of branches.

        Args:
            **params: Query parameters (page, per_page, etc.)

        Returns:
            list[Branche]: List of items
        """
        data = await self._client.get("/branches", **params)
        return _branches_decoder.decode(data)
