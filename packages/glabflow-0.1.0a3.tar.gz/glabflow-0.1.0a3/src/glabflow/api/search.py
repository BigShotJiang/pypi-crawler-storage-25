from __future__ import annotations

from collections.abc import AsyncIterator
from typing import TYPE_CHECKING, Any

import msgspec

from glabflow.models.search import SearchResult

if TYPE_CHECKING:
    from glabflow._client import GitLabClient


# Decoder for search
_search_result_decoder = msgspec.json.Decoder(list[SearchResult])
_search_result_single_decoder = msgspec.json.Decoder(SearchResult)


class SearchAPI:
    """Async API for accessing GitLab search."""

    def __init__(self, client: GitLabClient) -> None:
        self._client = client

    async def stream(self, **params: Any) -> AsyncIterator[SearchResult]:
        """Stream all search results with keyset pagination."""
        # Translate query to search
        if "query" in params:
            params["search"] = params.pop("query")
        async for page_bytes in self._client.paginate("/search", **params):
            for item in _search_result_decoder.decode(page_bytes):
                yield item

    async def stream_global(self, **params: Any) -> AsyncIterator[SearchResult]:
        """Stream global search results."""
        # Translate query to search
        if "query" in params:
            params["search"] = params.pop("query")
        async for page_bytes in self._client.paginate("/search", **params):
            for item in _search_result_decoder.decode(page_bytes):
                yield item

    async def stream_project(
        self, project_id: int, **params: Any
    ) -> AsyncIterator[SearchResult]:
        """Stream search results for a project."""
        # Translate query to search
        if "query" in params:
            params["search"] = params.pop("query")
        async for page_bytes in self._client.paginate(
            f"/projects/{project_id}/search", **params
        ):
            for item in _search_result_decoder.decode(page_bytes):
                yield item

    async def stream_group(
        self, group_id: int, **params: Any
    ) -> AsyncIterator[SearchResult]:
        """Stream search results for a group."""
        # Translate query to search
        if "query" in params:
            params["search"] = params.pop("query")
        async for page_bytes in self._client.paginate(
            f"/groups/{group_id}/search", **params
        ):
            for item in _search_result_decoder.decode(page_bytes):
                yield item

    async def get(self, id: int, **params: Any) -> SearchResult:
        """Get a specific search result by ID."""
        path = f"/search/{id}"
        data = await self._client.get(path, **params)
        return _search_result_single_decoder.decode(data)

    async def list_page(self, **params: Any) -> list[SearchResult]:
        """List a single page of search results."""
        data = await self._client.get("/search", **params)
        return _search_result_decoder.decode(data)
