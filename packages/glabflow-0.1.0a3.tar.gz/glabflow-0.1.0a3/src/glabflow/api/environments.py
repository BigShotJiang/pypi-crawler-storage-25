from __future__ import annotations

from collections.abc import AsyncIterator
from typing import TYPE_CHECKING, Any

import msgspec

from glabflow.models.environments import Environment

if TYPE_CHECKING:
    from glabflow._client import GitLabClient


# Decoder for environments
_environments_decoder = msgspec.json.Decoder(list[Environment])
_environments_single_decoder = msgspec.json.Decoder(Environment)


class EnvironmentsAPI:
    """Async API for accessing GitLab environments."""

    def __init__(self, client: GitLabClient) -> None:
        self._client = client

    async def stream(self, **params: Any) -> AsyncIterator[Environment]:
        """Stream all environments with keyset pagination.

        Args:
            **params: Additional query parameters

        Yields:
            Environment: GitLab environments resource items
        """
        async for page_bytes in self._client.paginate("/environments", **params):
            for item in _environments_decoder.decode(page_bytes):
                yield item

    async def get(self, id: int, **params: Any) -> Environment:
        """Get a specific environments by ID.

        Args:
            id: Environment ID
            **params: Additional query parameters

        Returns:
            Environment: The requested item
        """
        path = f"/environments/{id}"
        data = await self._client.get(path, **params)
        return _environments_single_decoder.decode(data)

    async def list_page(self, **params: Any) -> list[Environment]:
        """List a single page of environments.

        Args:
            **params: Query parameters (page, per_page, etc.)

        Returns:
            list[Environment]: List of items
        """
        data = await self._client.get("/environments", **params)
        return _environments_decoder.decode(data)
