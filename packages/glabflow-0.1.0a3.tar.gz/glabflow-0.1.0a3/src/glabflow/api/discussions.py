from __future__ import annotations

from collections.abc import AsyncIterator
from typing import TYPE_CHECKING, Any

import msgspec

from glabflow.models.discussions import Discussion

if TYPE_CHECKING:
    from glabflow._client import GitLabClient


# Decoder for discussions
_discussions_decoder = msgspec.json.Decoder(list[Discussion])
_discussions_single_decoder = msgspec.json.Decoder(Discussion)


class DiscussionsAPI:
    """Async API for accessing GitLab discussions."""

    def __init__(self, client: GitLabClient) -> None:
        self._client = client

    async def stream(self, **params: Any) -> AsyncIterator[Discussion]:
        """Stream all discussions with keyset pagination.

        Args:
            **params: Additional query parameters

        Yields:
            Discussion: GitLab discussions resource items
        """
        async for page_bytes in self._client.paginate("/discussions", **params):
            for item in _discussions_decoder.decode(page_bytes):
                yield item

    async def get(self, id: int, **params: Any) -> Discussion:
        """Get a specific discussions by ID.

        Args:
            id: Discussion ID
            **params: Additional query parameters

        Returns:
            Discussion: The requested item
        """
        path = f"/discussions/{id}"
        data = await self._client.get(path, **params)
        return _discussions_single_decoder.decode(data)

    async def list_page(self, **params: Any) -> list[Discussion]:
        """List a single page of discussions.

        Args:
            **params: Query parameters (page, per_page, etc.)

        Returns:
            list[Discussion]: List of items
        """
        data = await self._client.get("/discussions", **params)
        return _discussions_decoder.decode(data)
