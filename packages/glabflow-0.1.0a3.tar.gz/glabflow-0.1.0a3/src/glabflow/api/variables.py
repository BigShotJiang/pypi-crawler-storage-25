from __future__ import annotations

from collections.abc import AsyncIterator
from typing import TYPE_CHECKING, Any

import msgspec

from glabflow.models.variables import Variable

if TYPE_CHECKING:
    from glabflow._client import GitLabClient


# Decoder for variables
_variable_decoder = msgspec.json.Decoder(Variable)
_variable_list_decoder = msgspec.json.Decoder(list[Variable])


class VariablesAPI:
    """Async API for accessing GitLab variables."""

    def __init__(self, client: GitLabClient) -> None:
        self._client = client

    async def stream(self, **params: Any) -> AsyncIterator[Variable]:
        """Stream all variables with keyset pagination."""
        async for page_bytes in self._client.paginate("/variables", **params):
            for item in _variable_list_decoder.decode(page_bytes):
                yield item

    async def stream_instance(self, **params: Any) -> AsyncIterator[Variable]:
        """Stream instance-level variables."""
        async for page_bytes in self._client.paginate("/admin/variables", **params):
            for item in _variable_list_decoder.decode(page_bytes):
                yield item

    async def stream_group(
        self, group_id: int, **params: Any
    ) -> AsyncIterator[Variable]:
        """Stream group-level variables."""
        async for page_bytes in self._client.paginate(
            f"/groups/{group_id}/variables", **params
        ):
            for item in _variable_list_decoder.decode(page_bytes):
                yield item

    async def stream_project(
        self, project_id: int, **params: Any
    ) -> AsyncIterator[Variable]:
        """Stream project-level variables."""
        async for page_bytes in self._client.paginate(
            f"/projects/{project_id}/variables", **params
        ):
            for item in _variable_list_decoder.decode(page_bytes):
                yield item

    async def get(self, id: int, **params: Any) -> Variable:
        """Get a specific variable by ID."""
        path = f"/variables/{id}"
        data = await self._client.get(path, **params)
        return _variable_decoder.decode(data)

    async def get_instance(self, key: str, **params: Any) -> Variable:
        """Get a specific instance-level variable by key."""
        path = f"/admin/variables/{key}"
        data = await self._client.get(path, **params)
        return _variable_decoder.decode(data)

    async def get_group(self, group_id: int, key: str, **params: Any) -> Variable:
        """Get a specific group-level variable by key."""
        path = f"/groups/{group_id}/variables/{key}"
        data = await self._client.get(path, **params)
        return _variable_decoder.decode(data)

    async def get_project(self, project_id: int, key: str, **params: Any) -> Variable:
        """Get a specific project-level variable by key."""
        path = f"/projects/{project_id}/variables/{key}"
        data = await self._client.get(path, **params)
        return _variable_decoder.decode(data)

    async def list_page(self, **params: Any) -> list[Variable]:
        """List a single page of variables."""
        data = await self._client.get("/variables", **params)
        return _variable_list_decoder.decode(data)
