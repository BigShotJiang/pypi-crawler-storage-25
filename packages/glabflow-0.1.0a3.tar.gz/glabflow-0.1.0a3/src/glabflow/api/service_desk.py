from __future__ import annotations

from collections.abc import AsyncIterator
from typing import TYPE_CHECKING, Any

import msgspec

from glabflow.models.service_desk import ServiceDesk

if TYPE_CHECKING:
    from glabflow._client import GitLabClient


# Decoder for service_desk
_service_desk_decoder = msgspec.json.Decoder(list[ServiceDesk])
_service_desk_single_decoder = msgspec.json.Decoder(ServiceDesk)


class ServiceDeskAPI:
    """Async API for accessing GitLab service_desk."""

    def __init__(self, client: GitLabClient) -> None:
        self._client = client

    async def stream(self, **params: Any) -> AsyncIterator[ServiceDesk]:
        """Stream all service_desk with keyset pagination.

        Args:
            **params: Additional query parameters

        Yields:
            ServiceDesk: GitLab service_desk resource items
        """
        async for page_bytes in self._client.paginate("/service_desk", **params):
            for item in _service_desk_decoder.decode(page_bytes):
                yield item

    async def get(self, id: int, **params: Any) -> ServiceDesk:
        """Get a specific service_desk by ID.

        Args:
            id: ServiceDesk ID
            **params: Additional query parameters

        Returns:
            ServiceDesk: The requested item
        """
        path = f"/service_desk/{id}"
        data = await self._client.get(path, **params)
        return _service_desk_single_decoder.decode(data)

    async def list_page(self, **params: Any) -> list[ServiceDesk]:
        """List a single page of service_desk.

        Args:
            **params: Query parameters (page, per_page, etc.)

        Returns:
            list[ServiceDesk]: List of items
        """
        data = await self._client.get("/service_desk", **params)
        return _service_desk_decoder.decode(data)
