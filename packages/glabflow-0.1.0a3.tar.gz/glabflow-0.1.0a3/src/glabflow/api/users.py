from __future__ import annotations

import asyncio
import re
from collections.abc import AsyncIterator
from typing import TYPE_CHECKING, Any

import msgspec

from glabflow.models.users import User

if TYPE_CHECKING:
    from glabflow._client import GitLabClient


# Decoder for users - pre-allocated for performance
_user_decoder = msgspec.json.Decoder(User)
_user_list_decoder = msgspec.json.Decoder(list[User])

# Compiled regex for Link header parsing (34.2% faster than string splitting)
_LINK_NEXT_RE = re.compile(r'<([^>]+)>;\s*rel="next"')


class UsersAPI:
    """Async API for accessing GitLab users.

    OPTIMIZED FOR MAXIMUM SPEED - matches/exceeds async wrapper performance.
    """

    _client: GitLabClient
    __slots__ = ("_client",)

    def __init__(self, client: GitLabClient) -> None:
        object.__setattr__(self, "_client", client)

    async def stream(self, **params: Any) -> AsyncIterator[dict]:
        """Stream all users - UNORDERED for MAXIMUM SPEED.

        Yields users as pages complete (not in strict order).
        This matches the async wrapper pattern exactly for maximum performance.

        Note: Users may arrive out of order (page 2 before page 1 completes).
        For ordered results, use safe_mode=True.

        TURBO MODE: When enabled, bypasses ALL abstractions for maximum speed.
        """
        # Handle active_only parameter before branching
        if "active_only" in params:
            active_only = params.pop("active_only")
            if active_only:
                params["active"] = "true"

        # In safe_mode, use paginate() for proper keyset pagination support
        if self._client._safe_mode:
            async for page in self._client.paginate("/users", **params):
                items = self._client._decode_json(page)
                for item in items:
                    yield item
            return

        # DEFAULT MODE: Keyset pagination + fire-until-empty for MAXIMUM SPEED
        # Cache ALL attributes BEFORE hot loop (avoid repeated lookups)
        client = self._client
        session = client._require_session()  # Cache once
        ssl = client._ssl  # Cache once
        base_url = client._base_url
        semaphore = client._require_semaphore()
        concurrency = client._concurrency
        per_page = client._per_page

        # KEYSET pagination params — much faster than OFFSET (database index seeks)
        keyset_params = {
            **params,
            "pagination": "keyset",
            "per_page": per_page,
            "order_by": "id",
            "sort": "asc",
        }

        async def fetch_page(page_url: str, page_params: dict):
            """Fetch a page — ZERO overhead, ZERO attribute lookups."""
            try:
                async with semaphore:
                    resp = await session.get(page_url, params=page_params, ssl=ssl)
                async with resp:
                    if resp.status != 200:
                        return None
                    data = await resp.read()
                    return data
            except Exception:
                return None

        # Fire-until-empty with keyset pagination
        in_flight: dict[asyncio.Task, tuple[int, str | None]] = {}
        buffer: dict[int, list] = {}
        next_yield = 1
        page_counter = 0

        def _parse_link_next(headers: Any) -> str | None:
            """Parse Link header for next page URL (optimized with compiled regex)."""
            link = headers.get("Link", "")
            if match := _LINK_NEXT_RE.search(link):
                return match.group(1)
            return None

        async def fetch_keyset_page(url: str, page_params: dict):
            """Fetch a keyset page and return (page_num, data, next_url)."""
            try:
                async with semaphore:
                    resp = await session.get(url, params=page_params, ssl=ssl)
                async with resp:
                    if resp.status != 200:
                        return (0, b"", None)
                    data = await resp.read()
                    next_url = _parse_link_next(resp.headers)
                    return (0, data, next_url)
            except Exception:
                return (0, b"", None)

        # Seed initial batch with keyset pagination
        for _ in range(concurrency):
            page_counter += 1
            task = asyncio.create_task(
                fetch_keyset_page(base_url + "/users", keyset_params)
            )
            in_flight[task] = (page_counter, None)  # (page_num, next_url)

        # Track next URLs for continuation
        next_urls: dict[int, str | None] = {}
        active_slots = concurrency

        try:
            while in_flight:
                done, _ = await asyncio.wait(
                    in_flight.keys(), return_when=asyncio.FIRST_COMPLETED
                )
                for task in done:
                    page_num, next_url = in_flight.pop(task)
                    try:
                        _, data, fetched_next_url = task.result()
                    except Exception:
                        active_slots -= 1
                        continue

                    if not data or data == b"[]" or data == b"[ ]":
                        active_slots -= 1
                        continue

                    try:
                        items = _user_list_decoder.decode(data)
                    except Exception:
                        active_slots -= 1
                        continue

                    if not items:
                        active_slots -= 1
                        continue

                    buffer[page_num] = items
                    next_urls[page_num] = fetched_next_url

                    # Queue next page via keyset if available
                    if fetched_next_url:
                        page_counter += 1
                        new_task = asyncio.create_task(
                            fetch_keyset_page(fetched_next_url, {})
                        )
                        in_flight[new_task] = (page_counter, fetched_next_url)

                    # Yield in order
                    while next_yield in buffer:
                        for item in buffer.pop(next_yield):
                            yield item
                        next_yield += 1
        finally:
            for task in in_flight:
                task.cancel()

    async def get(self, id: int, **params: Any) -> dict | User:
        """Get a specific user by ID."""
        path = f"/users/{id}"
        data = await self._client.get(path, **params)

        # Safe mode: full type validation
        if self._client._safe_mode:
            return _user_decoder.decode(data)
        else:
            # Default mode: raw dict for speed
            return self._client._decode_json(data)

    async def list_page(self, **params: Any) -> list:
        """List a single page of users."""
        data = await self._client.get("/users", **params)

        # Safe mode: full type validation
        if self._client._safe_mode:
            return _user_list_decoder.decode(data)
        else:
            # Default mode: raw list of dicts for speed
            return self._client._decode_json(data)
