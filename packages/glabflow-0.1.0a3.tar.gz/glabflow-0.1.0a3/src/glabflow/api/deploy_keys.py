from __future__ import annotations

from collections.abc import AsyncIterator
from typing import TYPE_CHECKING, Any

import msgspec

from glabflow.models.deploy_keys import DeployKey

if TYPE_CHECKING:
    from glabflow._client import GitLabClient


# Decoder for deploy_keys
_deploy_keys_decoder = msgspec.json.Decoder(list[DeployKey])
_deploy_keys_single_decoder = msgspec.json.Decoder(DeployKey)


class DeployKeysAPI:
    """Async API for accessing GitLab deploy_keys."""

    def __init__(self, client: GitLabClient) -> None:
        self._client = client

    async def stream(self, **params: Any) -> AsyncIterator[DeployKey]:
        """Stream all deploy_keys with keyset pagination.

        Args:
            **params: Additional query parameters

        Yields:
            DeployKey: GitLab deploy_keys resource items
        """
        async for page_bytes in self._client.paginate("/deploy_keys", **params):
            for item in _deploy_keys_decoder.decode(page_bytes):
                yield item

    async def get(self, id: int, **params: Any) -> DeployKey:
        """Get a specific deploy_keys by ID.

        Args:
            id: DeployKey ID
            **params: Additional query parameters

        Returns:
            DeployKey: The requested item
        """
        path = f"/deploy_keys/{id}"
        data = await self._client.get(path, **params)
        return _deploy_keys_single_decoder.decode(data)

    async def list_page(self, **params: Any) -> list[DeployKey]:
        """List a single page of deploy_keys.

        Args:
            **params: Query parameters (page, per_page, etc.)

        Returns:
            list[DeployKey]: List of items
        """
        data = await self._client.get("/deploy_keys", **params)
        return _deploy_keys_decoder.decode(data)
