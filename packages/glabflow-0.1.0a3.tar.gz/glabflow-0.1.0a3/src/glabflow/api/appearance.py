from __future__ import annotations

from collections.abc import AsyncIterator
from typing import TYPE_CHECKING, Any

import msgspec

from glabflow.models.appearance import Appearance

if TYPE_CHECKING:
    from glabflow._client import GitLabClient


# Decoder for appearance
_appearance_decoder = msgspec.json.Decoder(list[Appearance])
_appearance_single_decoder = msgspec.json.Decoder(Appearance)


class AppearanceAPI:
    """Async API for accessing GitLab appearance."""

    def __init__(self, client: GitLabClient) -> None:
        self._client = client

    async def stream(self, **params: Any) -> AsyncIterator[Appearance]:
        """Stream all appearance with keyset pagination.

        Args:
            **params: Additional query parameters

        Yields:
            Appearance: GitLab appearance resource items
        """
        async for page_bytes in self._client.paginate("/appearance", **params):
            for item in _appearance_decoder.decode(page_bytes):
                yield item

    async def get(self, id: int, **params: Any) -> Appearance:
        """Get a specific appearance by ID.

        Args:
            id: Appearance ID
            **params: Additional query parameters

        Returns:
            Appearance: The requested item
        """
        path = f"/appearance/{id}"
        data = await self._client.get(path, **params)
        return _appearance_single_decoder.decode(data)

    async def list_page(self, **params: Any) -> list[Appearance]:
        """List a single page of appearance.

        Args:
            **params: Query parameters (page, per_page, etc.)

        Returns:
            list[Appearance]: List of items
        """
        data = await self._client.get("/appearance", **params)
        return _appearance_decoder.decode(data)
