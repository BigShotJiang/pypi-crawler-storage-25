from __future__ import annotations

from collections.abc import AsyncIterator
from typing import TYPE_CHECKING, Any

import msgspec

from glabflow.models.templates import Template

if TYPE_CHECKING:
    from glabflow._client import GitLabClient


# Decoder for templates
_templates_decoder = msgspec.json.Decoder(list[Template])
_templates_single_decoder = msgspec.json.Decoder(Template)


class TemplatesAPI:
    """Async API for accessing GitLab templates."""

    def __init__(self, client: GitLabClient) -> None:
        self._client = client

    async def stream(self, **params: Any) -> AsyncIterator[Template]:
        """Stream all templates with keyset pagination.

        Args:
            **params: Additional query parameters

        Yields:
            Template: GitLab templates resource items
        """
        async for page_bytes in self._client.paginate("/templates", **params):
            for item in _templates_decoder.decode(page_bytes):
                yield item

    async def get(self, id: int, **params: Any) -> Template:
        """Get a specific templates by ID.

        Args:
            id: Template ID
            **params: Additional query parameters

        Returns:
            Template: The requested item
        """
        path = f"/templates/{id}"
        data = await self._client.get(path, **params)
        return _templates_single_decoder.decode(data)

    async def list_page(self, **params: Any) -> list[Template]:
        """List a single page of templates.

        Args:
            **params: Query parameters (page, per_page, etc.)

        Returns:
            list[Template]: List of items
        """
        data = await self._client.get("/templates", **params)
        return _templates_decoder.decode(data)
