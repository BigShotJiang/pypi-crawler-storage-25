from __future__ import annotations

from collections.abc import AsyncIterator
from typing import TYPE_CHECKING, Any

import msgspec

from glabflow.models.ldap_groups import LdapGroup

if TYPE_CHECKING:
    from glabflow._client import GitLabClient


# Decoder for ldap_groups
_ldap_groups_decoder = msgspec.json.Decoder(list[LdapGroup])
_ldap_groups_single_decoder = msgspec.json.Decoder(LdapGroup)


class LdapGroupsAPI:
    """Async API for accessing GitLab ldap_groups."""

    def __init__(self, client: GitLabClient) -> None:
        self._client = client

    async def stream(self, **params: Any) -> AsyncIterator[LdapGroup]:
        """Stream all ldap_groups with keyset pagination.

        Args:
            **params: Additional query parameters

        Yields:
            LdapGroup: GitLab ldap_groups resource items
        """
        async for page_bytes in self._client.paginate("/ldap_groups", **params):
            for item in _ldap_groups_decoder.decode(page_bytes):
                yield item

    async def get(self, id: int, **params: Any) -> LdapGroup:
        """Get a specific ldap_groups by ID.

        Args:
            id: LdapGroup ID
            **params: Additional query parameters

        Returns:
            LdapGroup: The requested item
        """
        path = f"/ldap_groups/{id}"
        data = await self._client.get(path, **params)
        return _ldap_groups_single_decoder.decode(data)

    async def list_page(self, **params: Any) -> list[LdapGroup]:
        """List a single page of ldap_groups.

        Args:
            **params: Query parameters (page, per_page, etc.)

        Returns:
            list[LdapGroup]: List of items
        """
        data = await self._client.get("/ldap_groups", **params)
        return _ldap_groups_decoder.decode(data)
