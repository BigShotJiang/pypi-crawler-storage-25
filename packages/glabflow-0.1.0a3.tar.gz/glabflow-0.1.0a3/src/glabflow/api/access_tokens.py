from __future__ import annotations

from collections.abc import AsyncIterator
from typing import TYPE_CHECKING, Any

import msgspec

from glabflow.models.access_token import PersonalAccessToken, ProjectAccessToken

if TYPE_CHECKING:
    from glabflow._client import GitLabClient

_personal_list_decoder = msgspec.json.Decoder(list[PersonalAccessToken])
_personal_decoder = msgspec.json.Decoder(PersonalAccessToken)
_project_list_decoder = msgspec.json.Decoder(list[ProjectAccessToken])
_project_decoder = msgspec.json.Decoder(ProjectAccessToken)


class AccessTokensAPI:
    """Async API for auditing GitLab access tokens.

    Covers personal access tokens, project access tokens, and group access
    tokens — mapping directly to SOC 2 / ISO 27001 access control audit
    requirements (least-privilege review, expiry enforcement, revocation).
    """

    def __init__(self, client: GitLabClient) -> None:
        self._client = client

    async def stream_personal(
        self, **params: Any
    ) -> AsyncIterator[PersonalAccessToken]:
        """Stream all personal access tokens visible to the caller.

        Args:
            **params: Filters: user_id, state ("active" | "inactive"), revoked

        Yields:
            PersonalAccessToken: Personal access token records
        """
        async for page_bytes in self._client.paginate(
            "/personal_access_tokens", **params
        ):
            for item in _personal_list_decoder.decode(page_bytes):
                yield item

    async def get_personal(self, id: int, **params: Any) -> PersonalAccessToken:
        """Get a single personal access token by ID.

        Args:
            id: Token ID
            **params: Additional query parameters

        Returns:
            PersonalAccessToken: The requested token record
        """
        data = await self._client.get(f"/personal_access_tokens/{id}", **params)
        return _personal_decoder.decode(data)

    async def get_current(self) -> PersonalAccessToken:
        """Get the personal access token used to authenticate this request.

        Returns:
            PersonalAccessToken: The calling token's own record
        """
        data = await self._client.get("/personal_access_tokens/self")
        return _personal_decoder.decode(data)

    async def stream_project(
        self, project_id: int, **params: Any
    ) -> AsyncIterator[ProjectAccessToken]:
        """Stream all access tokens for a project.

        Args:
            project_id: GitLab project ID
            **params: Filters: state

        Yields:
            ProjectAccessToken: Project access token records
        """
        async for page_bytes in self._client.paginate(
            f"/projects/{project_id}/access_tokens", **params
        ):
            for item in _project_list_decoder.decode(page_bytes):
                yield item

    async def get_project(
        self, project_id: int, token_id: int, **params: Any
    ) -> ProjectAccessToken:
        """Get a single project access token by ID.

        Args:
            project_id: GitLab project ID
            token_id: Token ID

        Returns:
            ProjectAccessToken: The requested token record
        """
        data = await self._client.get(
            f"/projects/{project_id}/access_tokens/{token_id}", **params
        )
        return _project_decoder.decode(data)

    async def get_group(
        self, group_id: int, token_id: int, **params: Any
    ) -> ProjectAccessToken:
        """Get a single group access token by ID.

        Args:
            group_id: GitLab group ID
            token_id: Token ID

        Returns:
            ProjectAccessToken: The requested token record
        """
        data = await self._client.get(
            f"/groups/{group_id}/access_tokens/{token_id}", **params
        )
        return _project_decoder.decode(data)

    async def stream_group(
        self, group_id: int | str, **params: Any
    ) -> AsyncIterator[ProjectAccessToken]:
        """Stream all access tokens for a group.

        Args:
            group_id: GitLab group ID
            **params: Filters: state

        Yields:
            ProjectAccessToken: Group access token records
        """
        async for page_bytes in self._client.paginate(
            f"/groups/{group_id}/access_tokens", **params
        ):
            for item in _project_list_decoder.decode(page_bytes):
                yield item
