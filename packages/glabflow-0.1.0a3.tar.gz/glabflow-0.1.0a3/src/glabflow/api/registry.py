from __future__ import annotations

from collections.abc import AsyncIterator
from typing import TYPE_CHECKING, Any

import msgspec

from glabflow.models.registry import Package, RegistryRepository, RegistryTag

if TYPE_CHECKING:
    from glabflow._client import GitLabClient

_repo_decoder = msgspec.json.Decoder(RegistryRepository)
_repo_list_decoder = msgspec.json.Decoder(list[RegistryRepository])
_tag_decoder = msgspec.json.Decoder(RegistryTag)
_tag_list_decoder = msgspec.json.Decoder(list[RegistryTag])
_pkg_decoder = msgspec.json.Decoder(Package)
_pkg_list_decoder = msgspec.json.Decoder(list[Package])


class RegistryAPI:
    """Async API for the GitLab container registry and package registry."""

    def __init__(self, client: GitLabClient) -> None:
        self._client = client

    async def stream_repositories(
        self, project_id: int, **params: Any
    ) -> AsyncIterator[RegistryRepository]:
        """Stream container registry repositories for a project.

        Args:
            project_id: GitLab project ID

        Yields:
            RegistryRepository: Repository records
        """
        async for page_bytes in self._client.paginate(
            f"/projects/{project_id}/registry/repositories", **params
        ):
            for item in _repo_list_decoder.decode(page_bytes):
                yield item

    async def get_repository(
        self, repository_id: int, **params: Any
    ) -> RegistryRepository:
        """Get a single registry repository by ID.

        Args:
            repository_id: Registry repository ID

        Returns:
            RegistryRepository: The repository record
        """
        data = await self._client.get(
            f"/registry/repositories/{repository_id}", **params
        )
        return _repo_decoder.decode(data)

    async def stream_tags(
        self, project_id: int, repository_id: int, **params: Any
    ) -> AsyncIterator[RegistryTag]:
        """Stream tags for a registry repository.

        Args:
            project_id: GitLab project ID
            repository_id: Registry repository ID

        Yields:
            RegistryTag: Tag records
        """
        async for page_bytes in self._client.paginate(
            f"/projects/{project_id}/registry/repositories/{repository_id}/tags",
            **params,
        ):
            for item in _tag_list_decoder.decode(page_bytes):
                yield item

    async def get_tag(
        self, project_id: int, repository_id: int, tag_name: str, **params: Any
    ) -> RegistryTag:
        """Get details of a single registry tag.

        Args:
            project_id: GitLab project ID
            repository_id: Registry repository ID
            tag_name: Tag name

        Returns:
            RegistryTag: The tag record
        """
        data = await self._client.get(
            f"/projects/{project_id}/registry/repositories/{repository_id}/tags/{tag_name}",
            **params,
        )
        return _tag_decoder.decode(data)

    async def stream_project_packages(
        self, project_id: int, **params: Any
    ) -> AsyncIterator[Package]:
        """Stream packages published to a project.

        Args:
            project_id: GitLab project ID
            **params: Filters: package_type, package_name, order_by, sort

        Yields:
            Package: Package records
        """
        async for page_bytes in self._client.paginate(
            f"/projects/{project_id}/packages", **params
        ):
            for item in _pkg_list_decoder.decode(page_bytes):
                yield item

    async def get_project_package(
        self, project_id: int, package_id: int, **params: Any
    ) -> Package:
        """Get a single package by ID.

        Args:
            project_id: GitLab project ID
            package_id: Package ID

        Returns:
            Package: The package record
        """
        data = await self._client.get(
            f"/projects/{project_id}/packages/{package_id}", **params
        )
        return _pkg_decoder.decode(data)

    async def stream_group_packages(
        self, group_id: int, **params: Any
    ) -> AsyncIterator[Package]:
        """Stream packages across all projects in a group.

        Args:
            group_id: GitLab group ID
            **params: Filters: package_type, package_name

        Yields:
            Package: Package records
        """
        async for page_bytes in self._client.paginate(
            f"/groups/{group_id}/packages", **params
        ):
            for item in _pkg_list_decoder.decode(page_bytes):
                yield item
