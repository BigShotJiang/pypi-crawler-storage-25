from __future__ import annotations

from collections.abc import AsyncIterator
from typing import TYPE_CHECKING, Any

import msgspec

from glabflow.models.hooks import Hook

if TYPE_CHECKING:
    from glabflow._client import GitLabClient


# Decoder for hooks
_hooks_decoder = msgspec.json.Decoder(list[Hook])
_hooks_single_decoder = msgspec.json.Decoder(Hook)


class HooksAPI:
    """Async API for accessing GitLab hooks."""

    def __init__(self, client: GitLabClient) -> None:
        self._client = client

    async def stream(self, **params: Any) -> AsyncIterator[Hook]:
        """Stream all hooks with keyset pagination.

        Args:
            **params: Additional query parameters

        Yields:
            Hook: GitLab hooks resource items
        """
        async for page_bytes in self._client.paginate("/hooks", **params):
            for item in _hooks_decoder.decode(page_bytes):
                yield item

    async def get(self, id: int, **params: Any) -> Hook:
        """Get a specific hooks by ID.

        Args:
            id: Hook ID
            **params: Additional query parameters

        Returns:
            Hook: The requested item
        """
        path = f"/hooks/{id}"
        data = await self._client.get(path, **params)
        return _hooks_single_decoder.decode(data)

    async def list_page(self, **params: Any) -> list[Hook]:
        """List a single page of hooks.

        Args:
            **params: Query parameters (page, per_page, etc.)

        Returns:
            list[Hook]: List of items
        """
        data = await self._client.get("/hooks", **params)
        return _hooks_decoder.decode(data)
