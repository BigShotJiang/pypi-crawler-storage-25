from __future__ import annotations

from collections.abc import AsyncIterator
from typing import TYPE_CHECKING, Any

import msgspec

from glabflow.models.events import Event

if TYPE_CHECKING:
    from glabflow._client import GitLabClient


# Decoder for events
_events_decoder = msgspec.json.Decoder(list[Event])
_events_single_decoder = msgspec.json.Decoder(Event)


class EventsAPI:
    """Async API for accessing GitLab events."""

    def __init__(self, client: GitLabClient) -> None:
        self._client = client

    async def stream(self, **params: Any) -> AsyncIterator[Event]:
        """Stream all events with keyset pagination."""
        async for page_bytes in self._client.paginate("/events", **params):
            for item in _events_decoder.decode(page_bytes):
                yield item

    async def stream_current_user(self, **params: Any) -> AsyncIterator[Event]:
        """Stream current user events."""
        async for page_bytes in self._client.paginate("/events", **params):
            for item in _events_decoder.decode(page_bytes):
                yield item

    async def stream_for_user(
        self, user_id: int, **params: Any
    ) -> AsyncIterator[Event]:
        """Stream events for a user."""
        async for page_bytes in self._client.paginate(
            f"/users/{user_id}/events", **params
        ):
            for item in _events_decoder.decode(page_bytes):
                yield item

    async def stream_for_project(
        self, project_id: int, **params: Any
    ) -> AsyncIterator[Event]:
        """Stream events for a project."""
        async for page_bytes in self._client.paginate(
            f"/projects/{project_id}/events", **params
        ):
            for item in _events_decoder.decode(page_bytes):
                yield item

    async def get(self, id: int, **params: Any) -> Event:
        """Get a specific event by ID."""
        path = f"/events/{id}"
        data = await self._client.get(path, **params)
        return _events_single_decoder.decode(data)

    async def list_page(self, **params: Any) -> list[Event]:
        """List a single page of events."""
        data = await self._client.get("/events", **params)
        return _events_decoder.decode(data)
