from __future__ import annotations

from collections.abc import AsyncIterator
from typing import TYPE_CHECKING, Any

import msgspec

from glabflow.models.audit import AuditEvent

if TYPE_CHECKING:
    from glabflow._client import GitLabClient

_audit_event_decoder = msgspec.json.Decoder(list[AuditEvent])


class AuditAPI:
    """Async API for streaming GitLab audit events.

    Covers both instance-level and group-level audit events, mapping
    directly to SOC 2 / ISO 27001 audit log requirements.
    """

    def __init__(self, client: GitLabClient) -> None:
        self._client = client

    async def stream_instance_events(self, **params: Any) -> AsyncIterator[AuditEvent]:
        """Stream all instance-level audit events.

        Args:
            **params: Filters supported by GitLab API:
                created_after (str): ISO 8601 datetime lower bound
                created_before (str): ISO 8601 datetime upper bound
                entity_type (str): Filter by entity type (e.g. "Project", "User")
                entity_id (int): Filter by entity ID

        Yields:
            AuditEvent: Instance audit event records
        """
        async for page_bytes in self._client.paginate("/audit_events", **params):
            for item in _audit_event_decoder.decode(page_bytes):
                yield item

    async def stream_group_events(
        self, group_id: int, **params: Any
    ) -> AsyncIterator[AuditEvent]:
        """Stream audit events for a specific group.

        Args:
            group_id: GitLab group ID
            **params: Filters: created_after, created_before

        Yields:
            AuditEvent: Group-scoped audit event records
        """
        async for page_bytes in self._client.paginate(
            f"/groups/{group_id}/audit_events", **params
        ):
            for item in _audit_event_decoder.decode(page_bytes):
                yield item
