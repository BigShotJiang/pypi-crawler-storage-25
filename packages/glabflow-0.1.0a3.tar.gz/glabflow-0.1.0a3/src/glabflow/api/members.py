from __future__ import annotations

from collections.abc import AsyncIterator
from typing import TYPE_CHECKING, Any

import msgspec

from glabflow.models.hooks import GroupHook, Hook, ProjectHook
from glabflow.models.members import Member

if TYPE_CHECKING:
    from glabflow._client import GitLabClient


# Decoder for members
_member_decoder = msgspec.json.Decoder(Member)
_member_list_decoder = msgspec.json.Decoder(list[Member])
_hook_decoder = msgspec.json.Decoder(Hook)
_hook_list_decoder = msgspec.json.Decoder(list[Hook])
_group_hook_decoder = msgspec.json.Decoder(GroupHook)
_group_hook_list_decoder = msgspec.json.Decoder(list[GroupHook])
_project_hook_decoder = msgspec.json.Decoder(ProjectHook)
_project_hook_list_decoder = msgspec.json.Decoder(list[ProjectHook])


class MembersAPI:
    """Async API for accessing GitLab members."""

    def __init__(self, client: GitLabClient) -> None:
        self._client = client

    async def stream(self, **params: Any) -> AsyncIterator[Member]:
        """Stream all members with keyset pagination."""
        async for page_bytes in self._client.paginate("/members", **params):
            for item in _member_list_decoder.decode(page_bytes):
                yield item

    async def stream_project(
        self, project_id: int, **params: Any
    ) -> AsyncIterator[Member]:
        """Stream members of a project."""
        async for page_bytes in self._client.paginate(
            f"/projects/{project_id}/members", **params
        ):
            for item in _member_list_decoder.decode(page_bytes):
                yield item

    async def stream_project_hooks(
        self, project_id: int, **params: Any
    ) -> AsyncIterator[ProjectHook]:
        """Stream project hooks."""
        async for page_bytes in self._client.paginate(
            f"/projects/{project_id}/hooks", **params
        ):
            for item in _project_hook_list_decoder.decode(page_bytes):
                yield item

    async def stream_group_hooks(
        self, group_id: int, **params: Any
    ) -> AsyncIterator[GroupHook]:
        """Stream group hooks."""
        async for page_bytes in self._client.paginate(
            f"/groups/{group_id}/hooks", **params
        ):
            for item in _group_hook_list_decoder.decode(page_bytes):
                yield item

    async def get(self, id: int, **params: Any) -> Member:
        """Get a specific member by ID."""
        path = f"/members/{id}"
        data = await self._client.get(path, **params)
        return _member_decoder.decode(data)

    async def get_project(self, project_id: int, user_id: int, **params: Any) -> Member:
        """Get a specific project member by user ID."""
        path = f"/projects/{project_id}/members/{user_id}"
        data = await self._client.get(path, **params)
        return _member_decoder.decode(data)

    async def get_project_hook(
        self, project_id: int, hook_id: int, **params: Any
    ) -> ProjectHook:
        """Get a specific project hook by ID."""
        path = f"/projects/{project_id}/hooks/{hook_id}"
        data = await self._client.get(path, **params)
        return _project_hook_decoder.decode(data)

    async def get_group_hook(
        self, group_id: int, hook_id: int, **params: Any
    ) -> GroupHook:
        """Get a specific group hook by ID."""
        path = f"/groups/{group_id}/hooks/{hook_id}"
        data = await self._client.get(path, **params)
        return _group_hook_decoder.decode(data)

    async def list_page(self, **params: Any) -> list[Member]:
        """List a single page of members."""
        data = await self._client.get("/members", **params)
        return _member_list_decoder.decode(data)
