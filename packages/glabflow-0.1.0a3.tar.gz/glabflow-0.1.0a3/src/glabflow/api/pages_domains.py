from __future__ import annotations

from collections.abc import AsyncIterator
from typing import TYPE_CHECKING, Any

import msgspec

from glabflow.models.pages_domains import PagesDomain

if TYPE_CHECKING:
    from glabflow._client import GitLabClient


# Decoder for pages_domains
_pages_domains_decoder = msgspec.json.Decoder(list[PagesDomain])
_pages_domains_single_decoder = msgspec.json.Decoder(PagesDomain)


class PagesDomainsAPI:
    """Async API for accessing GitLab pages_domains."""

    def __init__(self, client: GitLabClient) -> None:
        self._client = client

    async def stream(self, **params: Any) -> AsyncIterator[PagesDomain]:
        """Stream all pages_domains with keyset pagination.

        Args:
            **params: Additional query parameters

        Yields:
            PagesDomain: GitLab pages_domains resource items
        """
        async for page_bytes in self._client.paginate("/pages_domains", **params):
            for item in _pages_domains_decoder.decode(page_bytes):
                yield item

    async def get(self, id: int, **params: Any) -> PagesDomain:
        """Get a specific pages_domains by ID.

        Args:
            id: PagesDomain ID
            **params: Additional query parameters

        Returns:
            PagesDomain: The requested item
        """
        path = f"/pages_domains/{id}"
        data = await self._client.get(path, **params)
        return _pages_domains_single_decoder.decode(data)

    async def list_page(self, **params: Any) -> list[PagesDomain]:
        """List a single page of pages_domains.

        Args:
            **params: Query parameters (page, per_page, etc.)

        Returns:
            list[PagesDomain]: List of items
        """
        data = await self._client.get("/pages_domains", **params)
        return _pages_domains_decoder.decode(data)
