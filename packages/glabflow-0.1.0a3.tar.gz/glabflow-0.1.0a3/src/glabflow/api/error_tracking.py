from __future__ import annotations

from collections.abc import AsyncIterator
from typing import TYPE_CHECKING, Any

import msgspec

from glabflow.models.error_tracking import ErrorTracking

if TYPE_CHECKING:
    from glabflow._client import GitLabClient


# Decoder for error_tracking
_error_tracking_decoder = msgspec.json.Decoder(list[ErrorTracking])
_error_tracking_single_decoder = msgspec.json.Decoder(ErrorTracking)


class ErrorTrackingAPI:
    """Async API for accessing GitLab error_tracking."""

    def __init__(self, client: GitLabClient) -> None:
        self._client = client

    async def stream(self, **params: Any) -> AsyncIterator[ErrorTracking]:
        """Stream all error_tracking with keyset pagination.

        Args:
            **params: Additional query parameters

        Yields:
            ErrorTracking: GitLab error_tracking resource items
        """
        async for page_bytes in self._client.paginate("/error_tracking", **params):
            for item in _error_tracking_decoder.decode(page_bytes):
                yield item

    async def get(self, id: int, **params: Any) -> ErrorTracking:
        """Get a specific error_tracking by ID.

        Args:
            id: ErrorTracking ID
            **params: Additional query parameters

        Returns:
            ErrorTracking: The requested item
        """
        path = f"/error_tracking/{id}"
        data = await self._client.get(path, **params)
        return _error_tracking_single_decoder.decode(data)

    async def list_page(self, **params: Any) -> list[ErrorTracking]:
        """List a single page of error_tracking.

        Args:
            **params: Query parameters (page, per_page, etc.)

        Returns:
            list[ErrorTracking]: List of items
        """
        data = await self._client.get("/error_tracking", **params)
        return _error_tracking_decoder.decode(data)
