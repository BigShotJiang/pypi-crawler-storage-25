from __future__ import annotations

from collections.abc import AsyncIterator
from typing import TYPE_CHECKING, Any

import msgspec

from glabflow.models.merge_request_approvals import MergeRequestApproval

if TYPE_CHECKING:
    from glabflow._client import GitLabClient


# Decoder for merge_request_approvals
_merge_request_approvals_decoder = msgspec.json.Decoder(list[MergeRequestApproval])
_merge_request_approvals_single_decoder = msgspec.json.Decoder(MergeRequestApproval)


class MergeRequestApprovalsAPI:
    """Async API for accessing GitLab merge_request_approvals."""

    def __init__(self, client: GitLabClient) -> None:
        self._client = client

    async def stream(self, **params: Any) -> AsyncIterator[MergeRequestApproval]:
        """Stream all merge_request_approvals with keyset pagination.

        Args:
            **params: Additional query parameters

        Yields:
            MergeRequestApproval: GitLab merge_request_approvals resource items
        """
        async for page_bytes in self._client.paginate(
            "/merge_request_approvals", **params
        ):
            for item in _merge_request_approvals_decoder.decode(page_bytes):
                yield item

    async def get(self, id: int, **params: Any) -> MergeRequestApproval:
        """Get a specific merge_request_approvals by ID.

        Args:
            id: MergeRequestApproval ID
            **params: Additional query parameters

        Returns:
            MergeRequestApproval: The requested item
        """
        path = f"/merge_request_approvals/{id}"
        data = await self._client.get(path, **params)
        return _merge_request_approvals_single_decoder.decode(data)

    async def list_page(self, **params: Any) -> list[MergeRequestApproval]:
        """List a single page of merge_request_approvals.

        Args:
            **params: Query parameters (page, per_page, etc.)

        Returns:
            list[MergeRequestApproval]: List of items
        """
        data = await self._client.get("/merge_request_approvals", **params)
        return _merge_request_approvals_decoder.decode(data)
