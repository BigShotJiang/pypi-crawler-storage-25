from __future__ import annotations

from collections.abc import AsyncIterator
from typing import TYPE_CHECKING, Any

import msgspec

from glabflow.models.signatures import Signature

if TYPE_CHECKING:
    from glabflow._client import GitLabClient


# Decoder for signatures
_signatures_decoder = msgspec.json.Decoder(list[Signature])
_signatures_single_decoder = msgspec.json.Decoder(Signature)


class SignaturesAPI:
    """Async API for accessing GitLab signatures."""

    def __init__(self, client: GitLabClient) -> None:
        self._client = client

    async def stream(self, **params: Any) -> AsyncIterator[Signature]:
        """Stream all signatures with keyset pagination.

        Args:
            **params: Additional query parameters

        Yields:
            Signature: GitLab signatures resource items
        """
        async for page_bytes in self._client.paginate("/signatures", **params):
            for item in _signatures_decoder.decode(page_bytes):
                yield item

    async def get(self, id: int, **params: Any) -> Signature:
        """Get a specific signatures by ID.

        Args:
            id: Signature ID
            **params: Additional query parameters

        Returns:
            Signature: The requested item
        """
        path = f"/signatures/{id}"
        data = await self._client.get(path, **params)
        return _signatures_single_decoder.decode(data)

    async def list_page(self, **params: Any) -> list[Signature]:
        """List a single page of signatures.

        Args:
            **params: Query parameters (page, per_page, etc.)

        Returns:
            list[Signature]: List of items
        """
        data = await self._client.get("/signatures", **params)
        return _signatures_decoder.decode(data)
