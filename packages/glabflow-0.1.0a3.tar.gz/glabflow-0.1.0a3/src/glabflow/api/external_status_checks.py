from __future__ import annotations

from collections.abc import AsyncIterator
from typing import TYPE_CHECKING, Any

import msgspec

from glabflow.models.external_status_checks import ExternalStatusCheck

if TYPE_CHECKING:
    from glabflow._client import GitLabClient


# Decoder for external_status_checks
_external_status_checks_decoder = msgspec.json.Decoder(list[ExternalStatusCheck])
_external_status_checks_single_decoder = msgspec.json.Decoder(ExternalStatusCheck)


class ExternalStatusChecksAPI:
    """Async API for accessing GitLab external_status_checks."""

    def __init__(self, client: GitLabClient) -> None:
        self._client = client

    async def stream(self, **params: Any) -> AsyncIterator[ExternalStatusCheck]:
        """Stream all external_status_checks with keyset pagination.

        Args:
            **params: Additional query parameters

        Yields:
            ExternalStatusCheck: GitLab external_status_checks resource items
        """
        async for page_bytes in self._client.paginate(
            "/external_status_checks", **params
        ):
            for item in _external_status_checks_decoder.decode(page_bytes):
                yield item

    async def get(self, id: int, **params: Any) -> ExternalStatusCheck:
        """Get a specific external_status_checks by ID.

        Args:
            id: ExternalStatusCheck ID
            **params: Additional query parameters

        Returns:
            ExternalStatusCheck: The requested item
        """
        path = f"/external_status_checks/{id}"
        data = await self._client.get(path, **params)
        return _external_status_checks_single_decoder.decode(data)

    async def list_page(self, **params: Any) -> list[ExternalStatusCheck]:
        """List a single page of external_status_checks.

        Args:
            **params: Query parameters (page, per_page, etc.)

        Returns:
            list[ExternalStatusCheck]: List of items
        """
        data = await self._client.get("/external_status_checks", **params)
        return _external_status_checks_decoder.decode(data)
