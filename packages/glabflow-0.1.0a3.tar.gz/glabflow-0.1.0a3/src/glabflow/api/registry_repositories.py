from __future__ import annotations

from collections.abc import AsyncIterator
from typing import TYPE_CHECKING, Any

import msgspec

from glabflow.models.registry_repositories import RegistryRepositorie

if TYPE_CHECKING:
    from glabflow._client import GitLabClient


# Decoder for registry_repositories
_registry_repositories_decoder = msgspec.json.Decoder(list[RegistryRepositorie])
_registry_repositories_single_decoder = msgspec.json.Decoder(RegistryRepositorie)


class RegistryRepositoriesAPI:
    """Async API for accessing GitLab registry_repositories."""

    def __init__(self, client: GitLabClient) -> None:
        self._client = client

    async def stream(self, **params: Any) -> AsyncIterator[RegistryRepositorie]:
        """Stream all registry_repositories with keyset pagination.

        Args:
            **params: Additional query parameters

        Yields:
            RegistryRepositorie: GitLab registry_repositories resource items
        """
        async for page_bytes in self._client.paginate(
            "/registry_repositories", **params
        ):
            for item in _registry_repositories_decoder.decode(page_bytes):
                yield item

    async def get(self, id: int, **params: Any) -> RegistryRepositorie:
        """Get a specific registry_repositories by ID.

        Args:
            id: RegistryRepositorie ID
            **params: Additional query parameters

        Returns:
            RegistryRepositorie: The requested item
        """
        path = f"/registry_repositories/{id}"
        data = await self._client.get(path, **params)
        return _registry_repositories_single_decoder.decode(data)

    async def list_page(self, **params: Any) -> list[RegistryRepositorie]:
        """List a single page of registry_repositories.

        Args:
            **params: Query parameters (page, per_page, etc.)

        Returns:
            list[RegistryRepositorie]: List of items
        """
        data = await self._client.get("/registry_repositories", **params)
        return _registry_repositories_decoder.decode(data)
