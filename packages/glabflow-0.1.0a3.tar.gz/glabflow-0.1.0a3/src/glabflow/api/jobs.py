from __future__ import annotations

from collections.abc import AsyncIterator
from typing import TYPE_CHECKING, Any

import msgspec

from glabflow.models.jobs import Job, Runner

if TYPE_CHECKING:
    from glabflow._client import GitLabClient


# Decoders for jobs
_job_decoder = msgspec.json.Decoder(Job)
_job_list_decoder = msgspec.json.Decoder(list[Job])
_runner_decoder = msgspec.json.Decoder(Runner)
_runner_list_decoder = msgspec.json.Decoder(list[Runner])


class JobsAPI:
    """Async API for accessing GitLab jobs."""

    def __init__(self, client: GitLabClient) -> None:
        self._client = client

    async def stream(self, **params: Any) -> AsyncIterator[Job]:
        """Stream all jobs with keyset pagination."""
        async for page_bytes in self._client.paginate("/jobs", **params):
            for item in _job_list_decoder.decode(page_bytes):
                yield item

    async def stream_for_project(
        self, project_id: int, **params: Any
    ) -> AsyncIterator[Job]:
        """Stream jobs for a project."""
        # Convert list scope to scope[]
        if "scope" in params and isinstance(params["scope"], list):
            params["scope[]"] = params.pop("scope")
        async for page_bytes in self._client.paginate(
            f"/projects/{project_id}/jobs", **params
        ):
            for item in _job_list_decoder.decode(page_bytes):
                yield item

    async def stream_for_pipeline(
        self, project_id: int, pipeline_id: int, **params: Any
    ) -> AsyncIterator[Job]:
        """Stream jobs for a pipeline."""
        # Convert list scope to scope[]
        if "scope" in params and isinstance(params["scope"], list):
            params["scope[]"] = params.pop("scope")
        async for page_bytes in self._client.paginate(
            f"/projects/{project_id}/pipelines/{pipeline_id}/jobs", **params
        ):
            for item in _job_list_decoder.decode(page_bytes):
                yield item

    async def stream_runner_jobs(
        self, runner_id: int, **params: Any
    ) -> AsyncIterator[Job]:
        """Stream jobs for a runner."""
        async for page_bytes in self._client.paginate(
            f"/runners/{runner_id}/jobs", **params
        ):
            for item in _job_list_decoder.decode(page_bytes):
                yield item

    async def stream_all_runners(self, **params: Any) -> AsyncIterator[Runner]:
        """Stream all runners."""
        async for page_bytes in self._client.paginate("/runners/all", **params):
            for item in _runner_list_decoder.decode(page_bytes):
                yield item

    async def stream_project_runners(
        self, project_id: int, **params: Any
    ) -> AsyncIterator[Runner]:
        """Stream runners for a project."""
        async for page_bytes in self._client.paginate(
            f"/projects/{project_id}/runners", **params
        ):
            for item in _runner_list_decoder.decode(page_bytes):
                yield item

    async def get(self, project_id: int, job_id: int, **params: Any) -> Job:
        """Get a specific job by project ID and job ID."""
        path = f"/projects/{project_id}/jobs/{job_id}"
        data = await self._client.get(path, **params)
        return _job_decoder.decode(data)

    async def get_runner(self, runner_id: int, **params: Any) -> Runner:
        """Get a specific runner by ID."""
        path = f"/runners/{runner_id}"
        data = await self._client.get(path, **params)
        return _runner_decoder.decode(data)

    async def list_page(self, **params: Any) -> list[Job]:
        """List a single page of jobs."""
        data = await self._client.get("/jobs", **params)
        return _job_list_decoder.decode(data)
