"""GitLab API modules."""

from .access_tokens import AccessTokensAPI
from .appearance import AppearanceAPI
from .approval_rules import ApprovalRulesAPI
from .audit_events import AuditEventsAPI
from .award_emoji import AwardEmojiAPI
from .badges import BadgesAPI
from .boards import BoardsAPI
from .branches import BranchesAPI
from .broadcast_messages import BroadcastMessagesAPI
from .changelog import ChangelogAPI
from .ci import CiAPI
from .code_owners import CodeOwnersAPI
from .compare import CompareAPI
from .composer_packages import ComposerPackagesAPI
from .conan_packages import ConanPackagesAPI
from .coverage_definitions import CoverageDefinitionsAPI
from .dependency_proxy import DependencyProxyAPI
from .deploy_keys import DeployKeysAPI
from .deploy_tokens import DeployTokensAPI
from .deployments import DeploymentsAPI
from .discussions import DiscussionsAPI
from .dockerfile_templates import DockerfileTemplatesAPI
from .environments import EnvironmentsAPI
from .epics import EpicsAPI
from .error_tracking import ErrorTrackingAPI
from .events import EventsAPI
from .external_status_checks import ExternalStatusChecksAPI
from .generic_packages import GenericPackagesAPI
from .geo_nodes import GeoNodesAPI
from .groups import GroupsAPI
from .helm_packages import HelmPackagesAPI
from .hooks import HooksAPI
from .incident_management import IncidentManagementAPI
from .issues import IssuesAPI
from .iterations import IterationsAPI
from .jobs import JobsAPI
from .keys import KeysAPI
from .labels import LabelsAPI
from .ldap_groups import LdapGroupsAPI
from .members import MembersAPI
from .merge_request_approvals import MergeRequestApprovalsAPI
from .merge_requests import MergeRequestsAPI
from .merge_trains import MergeTrainsAPI
from .milestones import MilestonesAPI
from .namespaces import NamespacesAPI
from .notes import NotesAPI
from .npm_packages import NpmPackagesAPI
from .nuget_packages import NugetPackagesAPI
from .packages import PackagesAPI
from .pages_domains import PagesDomainsAPI
from .pipeline_schedules import PipelineSchedulesAPI
from .pipelines import PipelinesAPI
from .projects import ProjectsAPI
from .protected_branches import ProtectedBranchesAPI
from .push_rules import PushRulesAPI
from .pypi_packages import PypiPackagesAPI
from .registry_repositories import RegistryRepositoriesAPI
from .releases import ReleasesAPI
from .rubygems_packages import RubygemsPackagesAPI
from .runners import RunnersAPI
from .search import SearchAPI
from .service_desk import ServiceDeskAPI
from .settings import SettingsAPI
from .signatures import SignaturesAPI
from .snippets import SnippetsAPI
from .sprints import SprintsAPI
from .statistics import StatisticsAPI
from .tags import TagsAPI
from .templates import TemplatesAPI
from .terraform_packages import TerraformPackagesAPI
from .todos import TodosAPI
from .topics import TopicsAPI
from .triggers import TriggersAPI
from .users import UsersAPI
from .variables import VariablesAPI
from .vulnerabilities import VulnerabilitiesAPI
from .wikis import WikisAPI

__all__ = [
    "AccessTokensAPI",
    "AppearanceAPI",
    "ApprovalRulesAPI",
    "AuditEventsAPI",
    "AwardEmojiAPI",
    "BadgesAPI",
    "BoardsAPI",
    "BranchesAPI",
    "BroadcastMessagesAPI",
    "ChangelogAPI",
    "CiAPI",
    "CodeOwnersAPI",
    "CompareAPI",
    "ComposerPackagesAPI",
    "ConanPackagesAPI",
    "CoverageDefinitionsAPI",
    "DependencyProxyAPI",
    "DeployKeysAPI",
    "DeployTokensAPI",
    "DeploymentsAPI",
    "DiscussionsAPI",
    "DockerfileTemplatesAPI",
    "EnvironmentsAPI",
    "EpicsAPI",
    "ErrorTrackingAPI",
    "EventsAPI",
    "ExternalStatusChecksAPI",
    "GenericPackagesAPI",
    "GeoNodesAPI",
    "GroupsAPI",
    "HelmPackagesAPI",
    "HooksAPI",
    "IncidentManagementAPI",
    "IssuesAPI",
    "IterationsAPI",
    "JobsAPI",
    "KeysAPI",
    "LabelsAPI",
    "LdapGroupsAPI",
    "MembersAPI",
    "MergeRequestApprovalsAPI",
    "MergeRequestsAPI",
    "MergeTrainsAPI",
    "MilestonesAPI",
    "NamespacesAPI",
    "NotesAPI",
    "NpmPackagesAPI",
    "NugetPackagesAPI",
    "PackagesAPI",
    "PagesDomainsAPI",
    "PipelineSchedulesAPI",
    "PipelinesAPI",
    "ProjectsAPI",
    "ProtectedBranchesAPI",
    "PushRulesAPI",
    "PypiPackagesAPI",
    "RegistryRepositoriesAPI",
    "ReleasesAPI",
    "RubygemsPackagesAPI",
    "RunnersAPI",
    "SearchAPI",
    "ServiceDeskAPI",
    "SettingsAPI",
    "SignaturesAPI",
    "SnippetsAPI",
    "SprintsAPI",
    "StatisticsAPI",
    "TagsAPI",
    "TemplatesAPI",
    "TerraformPackagesAPI",
    "TodosAPI",
    "TopicsAPI",
    "TriggersAPI",
    "UsersAPI",
    "VariablesAPI",
    "VulnerabilitiesAPI",
    "WikisAPI",
]
