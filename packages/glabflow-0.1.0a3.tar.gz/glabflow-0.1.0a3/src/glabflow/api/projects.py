from __future__ import annotations

from collections.abc import AsyncIterator
from typing import TYPE_CHECKING, Any

import msgspec

from glabflow.models.projects import Project

if TYPE_CHECKING:
    from glabflow._client import GitLabClient


# Decoder for projects - pre-allocated for performance
_project_decoder = msgspec.json.Decoder(Project)
_project_list_decoder = msgspec.json.Decoder(list[Project])


class ProjectsAPI:
    """Async API for accessing GitLab projects."""

    def __init__(self, client: GitLabClient) -> None:
        self._client = client

    async def stream(self, **params: Any) -> AsyncIterator[Project]:
        """Stream all projects with keyset pagination."""
        # Convert boolean membership and archived to string
        if "membership" in params:
            if params["membership"]:
                params["membership"] = "true"
            else:
                del params["membership"]
        if "archived" in params:
            if params["archived"]:
                params["archived"] = "true"
            else:
                del params["archived"]

        prefetch = getattr(self._client, "_prefetch_pages", 1)
        parallel = getattr(self._client, "_parallel_pages", 0)
        async for page_bytes in self._client.paginate(
            "/projects", prefetch=prefetch, parallel_pages=parallel, **params
        ):
            for item in _project_list_decoder.decode(page_bytes):
                yield item

    async def stream_for_group(
        self, group_id: int, **params: Any
    ) -> AsyncIterator[Project]:
        """Stream projects for a group."""
        prefetch = getattr(self._client, "_prefetch_pages", 1)
        parallel = getattr(self._client, "_parallel_pages", 0)
        async for page_bytes in self._client.paginate(
            f"/groups/{group_id}/projects",
            prefetch=prefetch,
            parallel_pages=parallel,
            **params,
        ):
            for item in _project_list_decoder.decode(page_bytes):
                yield item

    async def get(self, id: int, **params: Any) -> Project:
        """Get a specific project by ID."""
        path = f"/projects/{id}"
        data = await self._client.get(path, **params)
        return _project_decoder.decode(data)

    async def list_page(self, **params: Any) -> list[Project]:
        """List a single page of projects."""
        data = await self._client.get("/projects", **params)
        return _project_list_decoder.decode(data)
