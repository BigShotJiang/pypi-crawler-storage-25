"""Base API class for glabflow."""

from __future__ import annotations

from collections.abc import AsyncIterator
from typing import TYPE_CHECKING, Any, TypeVar

import msgspec

if TYPE_CHECKING:
    from glabflow._client import GitLabClient

T = TypeVar("T")


class BaseAPI:
    """Base class for all glabflow APIs."""

    def __init__(self, client: GitLabClient) -> None:
        self._client = client

    async def _stream(
        self,
        endpoint: str,
        decoder: msgspec.json.Decoder[list[T]],
        params: dict[str, Any] | None = None,
    ) -> AsyncIterator[T]:
        """Stream items from an endpoint.

        Args:
            endpoint: API endpoint path
            decoder: msgspec decoder for the item type
            params: Optional query parameters

        Yields:
            Decoded items from the endpoint
        """
        if params is None:
            params = {}
        async for page_bytes in self._client.paginate(endpoint, **params):
            for item in decoder.decode(page_bytes):
                yield item
