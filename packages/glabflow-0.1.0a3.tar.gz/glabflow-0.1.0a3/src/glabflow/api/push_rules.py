from __future__ import annotations

from collections.abc import AsyncIterator
from typing import TYPE_CHECKING, Any

import msgspec

from glabflow.models.push_rules import PushRule

if TYPE_CHECKING:
    from glabflow._client import GitLabClient


# Decoder for push_rules
_push_rules_decoder = msgspec.json.Decoder(list[PushRule])
_push_rules_single_decoder = msgspec.json.Decoder(PushRule)


class PushRulesAPI:
    """Async API for accessing GitLab push_rules."""

    def __init__(self, client: GitLabClient) -> None:
        self._client = client

    async def stream(self, **params: Any) -> AsyncIterator[PushRule]:
        """Stream all push_rules with keyset pagination.

        Args:
            **params: Additional query parameters

        Yields:
            PushRule: GitLab push_rules resource items
        """
        async for page_bytes in self._client.paginate("/push_rules", **params):
            for item in _push_rules_decoder.decode(page_bytes):
                yield item

    async def get(self, id: int, **params: Any) -> PushRule:
        """Get a specific push_rules by ID.

        Args:
            id: PushRule ID
            **params: Additional query parameters

        Returns:
            PushRule: The requested item
        """
        path = f"/push_rules/{id}"
        data = await self._client.get(path, **params)
        return _push_rules_single_decoder.decode(data)

    async def list_page(self, **params: Any) -> list[PushRule]:
        """List a single page of push_rules.

        Args:
            **params: Query parameters (page, per_page, etc.)

        Returns:
            list[PushRule]: List of items
        """
        data = await self._client.get("/push_rules", **params)
        return _push_rules_decoder.decode(data)
