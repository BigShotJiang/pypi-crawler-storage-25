from __future__ import annotations

from collections.abc import AsyncIterator
from typing import TYPE_CHECKING, Any

import msgspec

from glabflow.models.ci import Ci

if TYPE_CHECKING:
    from glabflow._client import GitLabClient


# Decoder for ci
_ci_decoder = msgspec.json.Decoder(list[Ci])
_ci_single_decoder = msgspec.json.Decoder(Ci)


class CiAPI:
    """Async API for accessing GitLab ci."""

    def __init__(self, client: GitLabClient) -> None:
        self._client = client

    async def stream(self, **params: Any) -> AsyncIterator[Ci]:
        """Stream all ci with keyset pagination.

        Args:
            **params: Additional query parameters

        Yields:
            Ci: GitLab ci resource items
        """
        async for page_bytes in self._client.paginate("/ci", **params):
            for item in _ci_decoder.decode(page_bytes):
                yield item

    async def get(self, id: int, **params: Any) -> Ci:
        """Get a specific ci by ID.

        Args:
            id: Ci ID
            **params: Additional query parameters

        Returns:
            Ci: The requested item
        """
        path = f"/ci/{id}"
        data = await self._client.get(path, **params)
        return _ci_single_decoder.decode(data)

    async def list_page(self, **params: Any) -> list[Ci]:
        """List a single page of ci.

        Args:
            **params: Query parameters (page, per_page, etc.)

        Returns:
            list[Ci]: List of items
        """
        data = await self._client.get("/ci", **params)
        return _ci_decoder.decode(data)
