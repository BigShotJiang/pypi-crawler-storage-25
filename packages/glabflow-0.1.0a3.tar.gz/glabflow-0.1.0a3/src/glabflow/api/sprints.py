from __future__ import annotations

from collections.abc import AsyncIterator
from typing import TYPE_CHECKING, Any

import msgspec

from glabflow.models.sprints import Sprint

if TYPE_CHECKING:
    from glabflow._client import GitLabClient


# Decoder for sprints
_sprints_decoder = msgspec.json.Decoder(list[Sprint])
_sprints_single_decoder = msgspec.json.Decoder(Sprint)


class SprintsAPI:
    """Async API for accessing GitLab sprints."""

    def __init__(self, client: GitLabClient) -> None:
        self._client = client

    async def stream(self, **params: Any) -> AsyncIterator[Sprint]:
        """Stream all sprints with keyset pagination.

        Args:
            **params: Additional query parameters

        Yields:
            Sprint: GitLab sprints resource items
        """
        async for page_bytes in self._client.paginate("/sprints", **params):
            for item in _sprints_decoder.decode(page_bytes):
                yield item

    async def get(self, id: int, **params: Any) -> Sprint:
        """Get a specific sprints by ID.

        Args:
            id: Sprint ID
            **params: Additional query parameters

        Returns:
            Sprint: The requested item
        """
        path = f"/sprints/{id}"
        data = await self._client.get(path, **params)
        return _sprints_single_decoder.decode(data)

    async def list_page(self, **params: Any) -> list[Sprint]:
        """List a single page of sprints.

        Args:
            **params: Query parameters (page, per_page, etc.)

        Returns:
            list[Sprint]: List of items
        """
        data = await self._client.get("/sprints", **params)
        return _sprints_decoder.decode(data)
