from __future__ import annotations

from collections.abc import AsyncIterator
from typing import TYPE_CHECKING, Any

import msgspec

from glabflow.models.pipelines import Pipeline, TestReport, TestReportSummary

if TYPE_CHECKING:
    from glabflow._client import GitLabClient


# Decoder for pipelines
_pipeline_decoder = msgspec.json.Decoder(Pipeline)
_pipeline_list_decoder = msgspec.json.Decoder(list[Pipeline])
_test_report_decoder = msgspec.json.Decoder(TestReport)
_test_report_summary_decoder = msgspec.json.Decoder(TestReportSummary)


class PipelinesAPI:
    """Async API for accessing GitLab pipelines."""

    def __init__(self, client: GitLabClient) -> None:
        self._client = client

    async def stream(self, **params: Any) -> AsyncIterator[Pipeline]:
        """Stream all pipelines with keyset pagination."""
        async for page_bytes in self._client.paginate("/pipelines", **params):
            for item in _pipeline_list_decoder.decode(page_bytes):
                yield item

    async def stream_for_project(
        self, project_id: int, **params: Any
    ) -> AsyncIterator[Pipeline]:
        """Stream all pipelines for a project with keyset pagination."""
        path = f"/projects/{project_id}/pipelines"
        async for page_bytes in self._client.paginate(path, **params):
            for item in _pipeline_list_decoder.decode(page_bytes):
                yield item

    async def get(self, project_id: int, pipeline_id: int, **params: Any) -> Pipeline:
        """Get a specific pipeline by project ID and pipeline ID."""
        path = f"/projects/{project_id}/pipelines/{pipeline_id}"
        data = await self._client.get(path, **params)
        return _pipeline_decoder.decode(data)

    async def get_for_project(
        self, project_id: int, pipeline_id: int, **params: Any
    ) -> Pipeline:
        """Get a specific project pipeline by ID."""
        path = f"/projects/{project_id}/pipelines/{pipeline_id}"
        data = await self._client.get(path, **params)
        return _pipeline_decoder.decode(data)

    async def list_page(self, **params: Any) -> list[Pipeline]:
        """List a single page of pipelines."""
        data = await self._client.get("/pipelines", **params)
        return _pipeline_list_decoder.decode(data)

    async def get_test_report(
        self, project_id: int, pipeline_id: int, **params: Any
    ) -> TestReport:
        """Get test report for a pipeline."""
        path = f"/projects/{project_id}/pipelines/{pipeline_id}/test_report"
        data = await self._client.get(path, **params)
        return _test_report_decoder.decode(data)

    async def get_test_report_summary(
        self, project_id: int, pipeline_id: int, **params: Any
    ) -> TestReportSummary:
        """Get test report summary for a pipeline."""
        path = f"/projects/{project_id}/pipelines/{pipeline_id}/test_report_summary"
        data = await self._client.get(path, **params)
        return _test_report_summary_decoder.decode(data)
