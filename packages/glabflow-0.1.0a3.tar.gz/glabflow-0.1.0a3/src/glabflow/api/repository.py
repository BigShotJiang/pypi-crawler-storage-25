from __future__ import annotations

from collections.abc import AsyncIterator
from typing import TYPE_CHECKING, Any

import msgspec

from glabflow.models.branches import Branche as Branch
from glabflow.models.branches import ProtectedBranche as ProtectedBranch
from glabflow.models.namespaces import DeployKey
from glabflow.models.repository import CompareResult, Contributor, FileContent, TreeItem
from glabflow.models.tag import Tag

if TYPE_CHECKING:
    from glabflow._client import GitLabClient

_branch_decoder = msgspec.json.Decoder(Branch)
_branch_list_decoder = msgspec.json.Decoder(list[Branch])
_protected_branch_decoder = msgspec.json.Decoder(ProtectedBranch)
_protected_branch_list_decoder = msgspec.json.Decoder(list[ProtectedBranch])
_tag_decoder = msgspec.json.Decoder(Tag)
_tag_list_decoder = msgspec.json.Decoder(list[Tag])
_deploy_key_decoder = msgspec.json.Decoder(DeployKey)
_deploy_key_list_decoder = msgspec.json.Decoder(list[DeployKey])
_tree_item_decoder = msgspec.json.Decoder(TreeItem)
_tree_item_list_decoder = msgspec.json.Decoder(list[TreeItem])
_file_content_decoder = msgspec.json.Decoder(FileContent)
_contributor_decoder = msgspec.json.Decoder(Contributor)
_contributor_list_decoder = msgspec.json.Decoder(list[Contributor])
_compare_result_decoder = msgspec.json.Decoder(CompareResult)
_protected_tag_list_decoder = msgspec.json.Decoder(list[dict])
_protected_tag_dict_decoder = msgspec.json.Decoder(dict)


class RepositoryAPI:
    """Async API for GitLab repository tree and file operations."""

    def __init__(self, client: GitLabClient) -> None:
        self._client = client

    async def stream_tree(
        self, project_id: int, **params: Any
    ) -> AsyncIterator[TreeItem]:
        """Stream the repository tree for a project."""
        # Convert boolean recursive to string
        if "recursive" in params:
            params["recursive"] = "true" if params["recursive"] else "false"
        async for page_bytes in self._client.paginate(
            f"/projects/{project_id}/repository/tree", **params
        ):
            for item in _tree_item_list_decoder.decode(page_bytes):
                yield item

    async def stream_branches(
        self, project_id: int, **params: Any
    ) -> AsyncIterator[Branch]:
        """Stream branches for a project."""
        async for page_bytes in self._client.paginate(
            f"/projects/{project_id}/repository/branches", **params
        ):
            for item in _branch_list_decoder.decode(page_bytes):
                yield item

    async def get_branch(self, project_id: int, branch: str, **params: Any) -> Branch:
        """Get a specific branch."""
        data = await self._client.get(
            f"/projects/{project_id}/repository/branches/{branch}", **params
        )
        return _branch_decoder.decode(data)

    async def stream_protected_branches(
        self, project_id: int, **params: Any
    ) -> AsyncIterator[ProtectedBranch]:
        """Stream protected branches for a project."""
        async for page_bytes in self._client.paginate(
            f"/projects/{project_id}/protected_branches", **params
        ):
            for item in _protected_branch_list_decoder.decode(page_bytes):
                yield item

    async def get_protected_branch(
        self, project_id: int, branch: str, **params: Any
    ) -> ProtectedBranch:
        """Get a specific protected branch."""
        data = await self._client.get(
            f"/projects/{project_id}/protected_branches/{branch}", **params
        )
        return _protected_branch_decoder.decode(data)

    async def stream_tags(self, project_id: int, **params: Any) -> AsyncIterator[Tag]:
        """Stream tags for a project."""
        async for page_bytes in self._client.paginate(
            f"/projects/{project_id}/repository/tags", **params
        ):
            for item in _tag_list_decoder.decode(page_bytes):
                yield item

    async def get_tag(self, project_id: int, tag: str, **params: Any) -> Tag:
        """Get a specific tag."""
        data = await self._client.get(
            f"/projects/{project_id}/repository/tags/{tag}", **params
        )
        return _tag_decoder.decode(data)

    async def stream_protected_tags(
        self, project_id: int, **params: Any
    ) -> AsyncIterator[dict[str, Any]]:
        """Stream protected tags for a project."""
        async for page_bytes in self._client.paginate(
            f"/projects/{project_id}/protected_tags", **params
        ):
            for item in _protected_tag_list_decoder.decode(page_bytes):
                yield item

    async def get_protected_tag(
        self, project_id: int, tag: str, **params: Any
    ) -> dict[str, Any]:
        """Get a specific protected tag."""
        data = await self._client.get(
            f"/projects/{project_id}/protected_tags/{tag}", **params
        )
        return _protected_tag_dict_decoder.decode(data)

    async def stream_deploy_keys(self, **params: Any) -> AsyncIterator[DeployKey]:
        """Stream deploy keys."""
        # Convert boolean public to string
        if "public" in params:
            params["public"] = "true" if params["public"] else "false"
        async for page_bytes in self._client.paginate("/deploy_keys", **params):
            for item in _deploy_key_list_decoder.decode(page_bytes):
                yield item

    async def stream_project_deploy_keys(
        self, project_id: int, **params: Any
    ) -> AsyncIterator[DeployKey]:
        """Stream deploy keys for a project."""
        # Convert boolean public to string
        if "public" in params:
            params["public"] = "true" if params["public"] else "false"
        async for page_bytes in self._client.paginate(
            f"/projects/{project_id}/deploy_keys", **params
        ):
            for item in _deploy_key_list_decoder.decode(page_bytes):
                yield item

    async def get_deploy_key(
        self, project_id: int, key_id: int, **params: Any
    ) -> DeployKey:
        """Get a specific deploy key."""
        data = await self._client.get(
            f"/projects/{project_id}/deploy_keys/{key_id}", **params
        )
        return _deploy_key_decoder.decode(data)

    async def get_project_deploy_key(
        self, project_id: int, key_id: int, **params: Any
    ) -> DeployKey:
        """Get a specific project deploy key."""
        data = await self._client.get(
            f"/projects/{project_id}/deploy_keys/{key_id}", **params
        )
        return _deploy_key_decoder.decode(data)

    async def get_file(
        self, project_id: int, file_path: str, ref: str, **params: Any
    ) -> FileContent:
        """Get a single file from the repository."""
        import urllib.parse

        encoded = urllib.parse.quote(file_path, safe="")
        data = await self._client.get(
            f"/projects/{project_id}/repository/files/{encoded}",
            ref=ref,
            **params,
        )
        return _file_content_decoder.decode(data)

    async def get_contributors(
        self, project_id: int, **params: Any
    ) -> list[Contributor]:
        """Get contributors for a project repository."""
        data = await self._client.get(
            f"/projects/{project_id}/repository/contributors", **params
        )
        return _contributor_list_decoder.decode(data)

    async def stream_contributors(
        self, project_id: int, **params: Any
    ) -> AsyncIterator[Contributor]:
        """Stream contributors for a project repository."""
        async for page_bytes in self._client.paginate(
            f"/projects/{project_id}/repository/contributors", **params
        ):
            for item in _contributor_list_decoder.decode(page_bytes):
                yield item

    async def get_compare(
        self, project_id: int, from_: str, to: str, **params: Any
    ) -> CompareResult:
        """Get a compare result between two refs."""
        data = await self._client.get(
            f"/projects/{project_id}/repository/compare",
            from_=from_,
            to=to,
            **params,
        )
        return _compare_result_decoder.decode(data)
