from __future__ import annotations

from collections.abc import AsyncIterator
from typing import TYPE_CHECKING, Any

import msgspec

from glabflow.models.changelog import Changelog

if TYPE_CHECKING:
    from glabflow._client import GitLabClient


# Decoder for changelog
_changelog_decoder = msgspec.json.Decoder(list[Changelog])
_changelog_single_decoder = msgspec.json.Decoder(Changelog)


class ChangelogAPI:
    """Async API for accessing GitLab changelog."""

    def __init__(self, client: GitLabClient) -> None:
        self._client = client

    async def stream(self, **params: Any) -> AsyncIterator[Changelog]:
        """Stream all changelog with keyset pagination.

        Args:
            **params: Additional query parameters

        Yields:
            Changelog: GitLab changelog resource items
        """
        async for page_bytes in self._client.paginate("/changelog", **params):
            for item in _changelog_decoder.decode(page_bytes):
                yield item

    async def get(self, id: int, **params: Any) -> Changelog:
        """Get a specific changelog by ID.

        Args:
            id: Changelog ID
            **params: Additional query parameters

        Returns:
            Changelog: The requested item
        """
        path = f"/changelog/{id}"
        data = await self._client.get(path, **params)
        return _changelog_single_decoder.decode(data)

    async def list_page(self, **params: Any) -> list[Changelog]:
        """List a single page of changelog.

        Args:
            **params: Query parameters (page, per_page, etc.)

        Returns:
            list[Changelog]: List of items
        """
        data = await self._client.get("/changelog", **params)
        return _changelog_decoder.decode(data)
