from __future__ import annotations

from collections.abc import AsyncIterator
from typing import TYPE_CHECKING, Any

import msgspec

from glabflow.models.broadcast_messages import BroadcastMessage

if TYPE_CHECKING:
    from glabflow._client import GitLabClient


# Decoder for broadcast_messages
_broadcast_messages_decoder = msgspec.json.Decoder(list[BroadcastMessage])
_broadcast_messages_single_decoder = msgspec.json.Decoder(BroadcastMessage)


class BroadcastMessagesAPI:
    """Async API for accessing GitLab broadcast_messages."""

    def __init__(self, client: GitLabClient) -> None:
        self._client = client

    async def stream(self, **params: Any) -> AsyncIterator[BroadcastMessage]:
        """Stream all broadcast_messages with keyset pagination.

        Args:
            **params: Additional query parameters

        Yields:
            BroadcastMessage: GitLab broadcast_messages resource items
        """
        async for page_bytes in self._client.paginate("/broadcast_messages", **params):
            for item in _broadcast_messages_decoder.decode(page_bytes):
                yield item

    async def get(self, id: int, **params: Any) -> BroadcastMessage:
        """Get a specific broadcast_messages by ID.

        Args:
            id: BroadcastMessage ID
            **params: Additional query parameters

        Returns:
            BroadcastMessage: The requested item
        """
        path = f"/broadcast_messages/{id}"
        data = await self._client.get(path, **params)
        return _broadcast_messages_single_decoder.decode(data)

    async def list_page(self, **params: Any) -> list[BroadcastMessage]:
        """List a single page of broadcast_messages.

        Args:
            **params: Query parameters (page, per_page, etc.)

        Returns:
            list[BroadcastMessage]: List of items
        """
        data = await self._client.get("/broadcast_messages", **params)
        return _broadcast_messages_decoder.decode(data)
