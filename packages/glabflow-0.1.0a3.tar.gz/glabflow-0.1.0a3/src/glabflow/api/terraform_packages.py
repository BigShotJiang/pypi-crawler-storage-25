from __future__ import annotations

from collections.abc import AsyncIterator
from typing import TYPE_CHECKING, Any

import msgspec

from glabflow.models.terraform_packages import TerraformPackage

if TYPE_CHECKING:
    from glabflow._client import GitLabClient


# Decoder for terraform_packages
_terraform_packages_decoder = msgspec.json.Decoder(list[TerraformPackage])
_terraform_packages_single_decoder = msgspec.json.Decoder(TerraformPackage)


class TerraformPackagesAPI:
    """Async API for accessing GitLab terraform_packages."""

    def __init__(self, client: GitLabClient) -> None:
        self._client = client

    async def stream(self, **params: Any) -> AsyncIterator[TerraformPackage]:
        """Stream all terraform_packages with keyset pagination.

        Args:
            **params: Additional query parameters

        Yields:
            TerraformPackage: GitLab terraform_packages resource items
        """
        async for page_bytes in self._client.paginate("/terraform_packages", **params):
            for item in _terraform_packages_decoder.decode(page_bytes):
                yield item

    async def get(self, id: int, **params: Any) -> TerraformPackage:
        """Get a specific terraform_packages by ID.

        Args:
            id: TerraformPackage ID
            **params: Additional query parameters

        Returns:
            TerraformPackage: The requested item
        """
        path = f"/terraform_packages/{id}"
        data = await self._client.get(path, **params)
        return _terraform_packages_single_decoder.decode(data)

    async def list_page(self, **params: Any) -> list[TerraformPackage]:
        """List a single page of terraform_packages.

        Args:
            **params: Query parameters (page, per_page, etc.)

        Returns:
            list[TerraformPackage]: List of items
        """
        data = await self._client.get("/terraform_packages", **params)
        return _terraform_packages_decoder.decode(data)
