"""Alias for merge_requests module - backwards compatibility."""

from .merge_requests import MergeRequestsAPI

__all__ = ["MergeRequestsAPI"]
