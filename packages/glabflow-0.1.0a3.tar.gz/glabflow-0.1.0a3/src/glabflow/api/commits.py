from __future__ import annotations

from collections.abc import AsyncIterator
from typing import TYPE_CHECKING, Any

import msgspec

from glabflow.models.commit import Commit, CommitComment, CommitDiff, CommitStatus

if TYPE_CHECKING:
    from glabflow._client import GitLabClient

_commit_decoder = msgspec.json.Decoder(Commit)
_commit_list_decoder = msgspec.json.Decoder(list[Commit])
_commit_status_decoder = msgspec.json.Decoder(CommitStatus)
_commit_status_list_decoder = msgspec.json.Decoder(list[CommitStatus])
_commit_diff_decoder = msgspec.json.Decoder(CommitDiff)
_commit_diff_list_decoder = msgspec.json.Decoder(list[CommitDiff])
_commit_comment_decoder = msgspec.json.Decoder(CommitComment)
_commit_comment_list_decoder = msgspec.json.Decoder(list[CommitComment])


class CommitsAPI:
    """Async API for streaming GitLab commit data."""

    def __init__(self, client: GitLabClient) -> None:
        self._client = client

    async def get(self, project_id: int, sha: str, **params: Any) -> Commit:
        """Get a single commit by SHA."""
        data = await self._client.get(
            f"/projects/{project_id}/repository/commits/{sha}", **params
        )
        return _commit_decoder.decode(data)

    async def stream_for_project(
        self, project_id: int, **params: Any
    ) -> AsyncIterator[Commit]:
        """Stream commits for a project."""
        translated = dict(params)
        if "ref" in translated:
            translated["ref_name"] = translated.pop("ref")

        async for page_bytes in self._client.paginate(
            f"/projects/{project_id}/repository/commits", **translated
        ):
            for item in _commit_list_decoder.decode(page_bytes):
                yield item

    async def stream_statuses(
        self, project_id: int, sha: str, **params: Any
    ) -> AsyncIterator[CommitStatus]:
        """Stream CI statuses for a commit."""
        async for page_bytes in self._client.paginate(
            f"/projects/{project_id}/repository/commits/{sha}/statuses", **params
        ):
            for item in _commit_status_list_decoder.decode(page_bytes):
                yield item

    async def stream_diff(
        self, project_id: int, sha: str, **params: Any
    ) -> AsyncIterator[CommitDiff]:
        """Stream the diff for a commit."""
        async for page_bytes in self._client.paginate(
            f"/projects/{project_id}/repository/commits/{sha}/diff", **params
        ):
            for item in _commit_diff_list_decoder.decode(page_bytes):
                yield item

    async def stream_comments(
        self, project_id: int, sha: str, **params: Any
    ) -> AsyncIterator[CommitComment]:
        """Stream comments on a commit."""
        async for page_bytes in self._client.paginate(
            f"/projects/{project_id}/repository/commits/{sha}/comments", **params
        ):
            for item in _commit_comment_list_decoder.decode(page_bytes):
                yield item
