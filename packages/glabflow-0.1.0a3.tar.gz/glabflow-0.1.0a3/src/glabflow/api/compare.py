from __future__ import annotations

from collections.abc import AsyncIterator
from typing import TYPE_CHECKING, Any

import msgspec

from glabflow.models.compare import Compare

if TYPE_CHECKING:
    from glabflow._client import GitLabClient


# Decoder for compare
_compare_decoder = msgspec.json.Decoder(list[Compare])
_compare_single_decoder = msgspec.json.Decoder(Compare)


class CompareAPI:
    """Async API for accessing GitLab compare."""

    def __init__(self, client: GitLabClient) -> None:
        self._client = client

    async def stream(self, **params: Any) -> AsyncIterator[Compare]:
        """Stream all compare with keyset pagination.

        Args:
            **params: Additional query parameters

        Yields:
            Compare: GitLab compare resource items
        """
        async for page_bytes in self._client.paginate("/compare", **params):
            for item in _compare_decoder.decode(page_bytes):
                yield item

    async def get(self, id: int, **params: Any) -> Compare:
        """Get a specific compare by ID.

        Args:
            id: Compare ID
            **params: Additional query parameters

        Returns:
            Compare: The requested item
        """
        path = f"/compare/{id}"
        data = await self._client.get(path, **params)
        return _compare_single_decoder.decode(data)

    async def list_page(self, **params: Any) -> list[Compare]:
        """List a single page of compare.

        Args:
            **params: Query parameters (page, per_page, etc.)

        Returns:
            list[Compare]: List of items
        """
        data = await self._client.get("/compare", **params)
        return _compare_decoder.decode(data)
