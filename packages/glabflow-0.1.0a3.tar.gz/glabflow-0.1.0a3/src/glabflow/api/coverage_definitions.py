from __future__ import annotations

from collections.abc import AsyncIterator
from typing import TYPE_CHECKING, Any

import msgspec

from glabflow.models.coverage_definitions import CoverageDefinition

if TYPE_CHECKING:
    from glabflow._client import GitLabClient


# Decoder for coverage_definitions
_coverage_definitions_decoder = msgspec.json.Decoder(list[CoverageDefinition])
_coverage_definitions_single_decoder = msgspec.json.Decoder(CoverageDefinition)


class CoverageDefinitionsAPI:
    """Async API for accessing GitLab coverage_definitions."""

    def __init__(self, client: GitLabClient) -> None:
        self._client = client

    async def stream(self, **params: Any) -> AsyncIterator[CoverageDefinition]:
        """Stream all coverage_definitions with keyset pagination.

        Args:
            **params: Additional query parameters

        Yields:
            CoverageDefinition: GitLab coverage_definitions resource items
        """
        async for page_bytes in self._client.paginate(
            "/coverage_definitions", **params
        ):
            for item in _coverage_definitions_decoder.decode(page_bytes):
                yield item

    async def get(self, id: int, **params: Any) -> CoverageDefinition:
        """Get a specific coverage_definitions by ID.

        Args:
            id: CoverageDefinition ID
            **params: Additional query parameters

        Returns:
            CoverageDefinition: The requested item
        """
        path = f"/coverage_definitions/{id}"
        data = await self._client.get(path, **params)
        return _coverage_definitions_single_decoder.decode(data)

    async def list_page(self, **params: Any) -> list[CoverageDefinition]:
        """List a single page of coverage_definitions.

        Args:
            **params: Query parameters (page, per_page, etc.)

        Returns:
            list[CoverageDefinition]: List of items
        """
        data = await self._client.get("/coverage_definitions", **params)
        return _coverage_definitions_decoder.decode(data)
