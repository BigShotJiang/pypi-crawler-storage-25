from __future__ import annotations

from collections.abc import AsyncIterator
from typing import TYPE_CHECKING, Any

import msgspec

from glabflow.models.helm_packages import HelmPackage

if TYPE_CHECKING:
    from glabflow._client import GitLabClient


# Decoder for helm_packages
_helm_packages_decoder = msgspec.json.Decoder(list[HelmPackage])
_helm_packages_single_decoder = msgspec.json.Decoder(HelmPackage)


class HelmPackagesAPI:
    """Async API for accessing GitLab helm_packages."""

    def __init__(self, client: GitLabClient) -> None:
        self._client = client

    async def stream(self, **params: Any) -> AsyncIterator[HelmPackage]:
        """Stream all helm_packages with keyset pagination.

        Args:
            **params: Additional query parameters

        Yields:
            HelmPackage: GitLab helm_packages resource items
        """
        async for page_bytes in self._client.paginate("/helm_packages", **params):
            for item in _helm_packages_decoder.decode(page_bytes):
                yield item

    async def get(self, id: int, **params: Any) -> HelmPackage:
        """Get a specific helm_packages by ID.

        Args:
            id: HelmPackage ID
            **params: Additional query parameters

        Returns:
            HelmPackage: The requested item
        """
        path = f"/helm_packages/{id}"
        data = await self._client.get(path, **params)
        return _helm_packages_single_decoder.decode(data)

    async def list_page(self, **params: Any) -> list[HelmPackage]:
        """List a single page of helm_packages.

        Args:
            **params: Query parameters (page, per_page, etc.)

        Returns:
            list[HelmPackage]: List of items
        """
        data = await self._client.get("/helm_packages", **params)
        return _helm_packages_decoder.decode(data)
