from __future__ import annotations

from collections.abc import AsyncIterator
from typing import TYPE_CHECKING, Any

import msgspec

from glabflow.models.iterations import Iteration

if TYPE_CHECKING:
    from glabflow._client import GitLabClient


# Decoder for iterations
_iterations_decoder = msgspec.json.Decoder(list[Iteration])
_iterations_single_decoder = msgspec.json.Decoder(Iteration)


class IterationsAPI:
    """Async API for accessing GitLab iterations."""

    def __init__(self, client: GitLabClient) -> None:
        self._client = client

    async def stream(self, **params: Any) -> AsyncIterator[Iteration]:
        """Stream all iterations with keyset pagination.

        Args:
            **params: Additional query parameters

        Yields:
            Iteration: GitLab iterations resource items
        """
        async for page_bytes in self._client.paginate("/iterations", **params):
            for item in _iterations_decoder.decode(page_bytes):
                yield item

    async def get(self, id: int, **params: Any) -> Iteration:
        """Get a specific iterations by ID.

        Args:
            id: Iteration ID
            **params: Additional query parameters

        Returns:
            Iteration: The requested item
        """
        path = f"/iterations/{id}"
        data = await self._client.get(path, **params)
        return _iterations_single_decoder.decode(data)

    async def list_page(self, **params: Any) -> list[Iteration]:
        """List a single page of iterations.

        Args:
            **params: Query parameters (page, per_page, etc.)

        Returns:
            list[Iteration]: List of items
        """
        data = await self._client.get("/iterations", **params)
        return _iterations_decoder.decode(data)
