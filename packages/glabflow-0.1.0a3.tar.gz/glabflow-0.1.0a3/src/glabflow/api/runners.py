from __future__ import annotations

from collections.abc import AsyncIterator
from typing import TYPE_CHECKING, Any

import msgspec

from glabflow.models.runners import Runner

if TYPE_CHECKING:
    from glabflow._client import GitLabClient


# Decoder for runners
_runners_decoder = msgspec.json.Decoder(list[Runner])
_runners_single_decoder = msgspec.json.Decoder(Runner)


class RunnersAPI:
    """Async API for accessing GitLab runners."""

    def __init__(self, client: GitLabClient) -> None:
        self._client = client

    async def stream(self, **params: Any) -> AsyncIterator[Runner]:
        """Stream all runners with keyset pagination.

        Args:
            **params: Additional query parameters

        Yields:
            Runner: GitLab runners resource items
        """
        async for page_bytes in self._client.paginate("/runners", **params):
            for item in _runners_decoder.decode(page_bytes):
                yield item

    async def get(self, id: int, **params: Any) -> Runner:
        """Get a specific runners by ID.

        Args:
            id: Runner ID
            **params: Additional query parameters

        Returns:
            Runner: The requested item
        """
        path = f"/runners/{id}"
        data = await self._client.get(path, **params)
        return _runners_single_decoder.decode(data)

    async def list_page(self, **params: Any) -> list[Runner]:
        """List a single page of runners.

        Args:
            **params: Query parameters (page, per_page, etc.)

        Returns:
            list[Runner]: List of items
        """
        data = await self._client.get("/runners", **params)
        return _runners_decoder.decode(data)
