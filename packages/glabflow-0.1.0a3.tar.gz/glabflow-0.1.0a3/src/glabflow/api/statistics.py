from __future__ import annotations

from collections.abc import AsyncIterator
from typing import TYPE_CHECKING, Any

import msgspec

from glabflow.models.statistics import Statistic

if TYPE_CHECKING:
    from glabflow._client import GitLabClient


# Decoder for statistics
_statistics_decoder = msgspec.json.Decoder(list[Statistic])
_statistics_single_decoder = msgspec.json.Decoder(Statistic)


class StatisticsAPI:
    """Async API for accessing GitLab statistics."""

    def __init__(self, client: GitLabClient) -> None:
        self._client = client

    async def stream(self, **params: Any) -> AsyncIterator[Statistic]:
        """Stream all statistics with keyset pagination.

        Args:
            **params: Additional query parameters

        Yields:
            Statistic: GitLab statistics resource items
        """
        async for page_bytes in self._client.paginate("/statistics", **params):
            for item in _statistics_decoder.decode(page_bytes):
                yield item

    async def get(self, id: int, **params: Any) -> Statistic:
        """Get a specific statistics by ID.

        Args:
            id: Statistic ID
            **params: Additional query parameters

        Returns:
            Statistic: The requested item
        """
        path = f"/statistics/{id}"
        data = await self._client.get(path, **params)
        return _statistics_single_decoder.decode(data)

    async def list_page(self, **params: Any) -> list[Statistic]:
        """List a single page of statistics.

        Args:
            **params: Query parameters (page, per_page, etc.)

        Returns:
            list[Statistic]: List of items
        """
        data = await self._client.get("/statistics", **params)
        return _statistics_decoder.decode(data)
