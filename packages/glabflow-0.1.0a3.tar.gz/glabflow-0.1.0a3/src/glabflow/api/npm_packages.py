from __future__ import annotations

from collections.abc import AsyncIterator
from typing import TYPE_CHECKING, Any

import msgspec

from glabflow.models.npm_packages import NpmPackage

if TYPE_CHECKING:
    from glabflow._client import GitLabClient


# Decoder for npm_packages
_npm_packages_decoder = msgspec.json.Decoder(list[NpmPackage])
_npm_packages_single_decoder = msgspec.json.Decoder(NpmPackage)


class NpmPackagesAPI:
    """Async API for accessing GitLab npm_packages."""

    def __init__(self, client: GitLabClient) -> None:
        self._client = client

    async def stream(self, **params: Any) -> AsyncIterator[NpmPackage]:
        """Stream all npm_packages with keyset pagination.

        Args:
            **params: Additional query parameters

        Yields:
            NpmPackage: GitLab npm_packages resource items
        """
        async for page_bytes in self._client.paginate("/npm_packages", **params):
            for item in _npm_packages_decoder.decode(page_bytes):
                yield item

    async def get(self, id: int, **params: Any) -> NpmPackage:
        """Get a specific npm_packages by ID.

        Args:
            id: NpmPackage ID
            **params: Additional query parameters

        Returns:
            NpmPackage: The requested item
        """
        path = f"/npm_packages/{id}"
        data = await self._client.get(path, **params)
        return _npm_packages_single_decoder.decode(data)

    async def list_page(self, **params: Any) -> list[NpmPackage]:
        """List a single page of npm_packages.

        Args:
            **params: Query parameters (page, per_page, etc.)

        Returns:
            list[NpmPackage]: List of items
        """
        data = await self._client.get("/npm_packages", **params)
        return _npm_packages_decoder.decode(data)
