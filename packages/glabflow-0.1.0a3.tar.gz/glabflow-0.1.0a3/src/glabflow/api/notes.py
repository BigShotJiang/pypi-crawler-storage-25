from __future__ import annotations

from collections.abc import AsyncIterator
from typing import TYPE_CHECKING, Any

import msgspec

from glabflow.models.notes import Note

if TYPE_CHECKING:
    from glabflow._client import GitLabClient


# Decoder for notes
_note_decoder = msgspec.json.Decoder(Note)
_note_list_decoder = msgspec.json.Decoder(list[Note])


class NotesAPI:
    """Async API for accessing GitLab notes."""

    def __init__(self, client: GitLabClient) -> None:
        self._client = client

    async def stream(self, **params: Any) -> AsyncIterator[Note]:
        """Stream all notes with keyset pagination."""
        async for page_bytes in self._client.paginate("/notes", **params):
            for item in _note_list_decoder.decode(page_bytes):
                yield item

    async def stream_mr_notes(
        self, project_id: int, mr_iid: int, **params: Any
    ) -> AsyncIterator[Note]:
        """Stream notes for a merge request."""
        async for page_bytes in self._client.paginate(
            f"/projects/{project_id}/merge_requests/{mr_iid}/notes", **params
        ):
            for item in _note_list_decoder.decode(page_bytes):
                yield item

    async def stream_issue_notes(
        self, project_id: int, issue_iid: int, **params: Any
    ) -> AsyncIterator[Note]:
        """Stream notes for an issue."""
        async for page_bytes in self._client.paginate(
            f"/projects/{project_id}/issues/{issue_iid}/notes", **params
        ):
            for item in _note_list_decoder.decode(page_bytes):
                yield item

    async def get(self, id: int, **params: Any) -> Note:
        """Get a specific note by ID."""
        path = f"/notes/{id}"
        data = await self._client.get(path, **params)
        return _note_decoder.decode(data)

    async def get_mr_note(
        self, project_id: int, mr_iid: int, note_id: int, **params: Any
    ) -> Note:
        """Get a specific merge request note by ID."""
        path = f"/projects/{project_id}/merge_requests/{mr_iid}/notes/{note_id}"
        data = await self._client.get(path, **params)
        return _note_decoder.decode(data)

    async def get_issue_note(
        self, project_id: int, issue_iid: int, note_id: int, **params: Any
    ) -> Note:
        """Get a specific issue note by ID."""
        path = f"/projects/{project_id}/issues/{issue_iid}/notes/{note_id}"
        data = await self._client.get(path, **params)
        return _note_decoder.decode(data)

    async def list_page(self, **params: Any) -> list[Note]:
        """List a single page of notes."""
        data = await self._client.get("/notes", **params)
        return _note_list_decoder.decode(data)
