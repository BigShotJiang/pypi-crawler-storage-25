from __future__ import annotations

from collections.abc import AsyncIterator
from typing import TYPE_CHECKING, Any

import msgspec

from glabflow.models.geo_nodes import GeoNode

if TYPE_CHECKING:
    from glabflow._client import GitLabClient


# Decoder for geo_nodes
_geo_nodes_decoder = msgspec.json.Decoder(list[GeoNode])
_geo_nodes_single_decoder = msgspec.json.Decoder(GeoNode)


class GeoNodesAPI:
    """Async API for accessing GitLab geo_nodes."""

    def __init__(self, client: GitLabClient) -> None:
        self._client = client

    async def stream(self, **params: Any) -> AsyncIterator[GeoNode]:
        """Stream all geo_nodes with keyset pagination.

        Args:
            **params: Additional query parameters

        Yields:
            GeoNode: GitLab geo_nodes resource items
        """
        async for page_bytes in self._client.paginate("/geo_nodes", **params):
            for item in _geo_nodes_decoder.decode(page_bytes):
                yield item

    async def get(self, id: int, **params: Any) -> GeoNode:
        """Get a specific geo_nodes by ID.

        Args:
            id: GeoNode ID
            **params: Additional query parameters

        Returns:
            GeoNode: The requested item
        """
        path = f"/geo_nodes/{id}"
        data = await self._client.get(path, **params)
        return _geo_nodes_single_decoder.decode(data)

    async def list_page(self, **params: Any) -> list[GeoNode]:
        """List a single page of geo_nodes.

        Args:
            **params: Query parameters (page, per_page, etc.)

        Returns:
            list[GeoNode]: List of items
        """
        data = await self._client.get("/geo_nodes", **params)
        return _geo_nodes_decoder.decode(data)
