from __future__ import annotations

from collections.abc import AsyncIterator
from typing import TYPE_CHECKING, Any

import msgspec

from glabflow.models.award_emoji import AwardEmoji

if TYPE_CHECKING:
    from glabflow._client import GitLabClient


# Decoder for award_emoji
_award_emoji_decoder = msgspec.json.Decoder(list[AwardEmoji])
_award_emoji_single_decoder = msgspec.json.Decoder(AwardEmoji)


class AwardEmojiAPI:
    """Async API for accessing GitLab award_emoji."""

    def __init__(self, client: GitLabClient) -> None:
        self._client = client

    async def stream(self, **params: Any) -> AsyncIterator[AwardEmoji]:
        """Stream all award_emoji with keyset pagination.

        Args:
            **params: Additional query parameters

        Yields:
            AwardEmoji: GitLab award_emoji resource items
        """
        async for page_bytes in self._client.paginate("/award_emoji", **params):
            for item in _award_emoji_decoder.decode(page_bytes):
                yield item

    async def get(self, id: int, **params: Any) -> AwardEmoji:
        """Get a specific award_emoji by ID.

        Args:
            id: AwardEmoji ID
            **params: Additional query parameters

        Returns:
            AwardEmoji: The requested item
        """
        path = f"/award_emoji/{id}"
        data = await self._client.get(path, **params)
        return _award_emoji_single_decoder.decode(data)

    async def list_page(self, **params: Any) -> list[AwardEmoji]:
        """List a single page of award_emoji.

        Args:
            **params: Query parameters (page, per_page, etc.)

        Returns:
            list[AwardEmoji]: List of items
        """
        data = await self._client.get("/award_emoji", **params)
        return _award_emoji_decoder.decode(data)
