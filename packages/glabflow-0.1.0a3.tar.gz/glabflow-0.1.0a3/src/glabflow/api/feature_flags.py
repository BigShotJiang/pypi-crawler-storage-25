from __future__ import annotations

from collections.abc import AsyncIterator
from typing import TYPE_CHECKING, Any

import msgspec

from glabflow.models.feature_flag import FeatureFlag, FeatureFlagUserList

if TYPE_CHECKING:
    from glabflow._client import GitLabClient

_flag_decoder = msgspec.json.Decoder(FeatureFlag)
_flag_list_decoder = msgspec.json.Decoder(list[FeatureFlag])
_user_list_decoder = msgspec.json.Decoder(list[FeatureFlagUserList])
_single_user_list_decoder = msgspec.json.Decoder(FeatureFlagUserList)


class FeatureFlagsAPI:
    """Async API for reading GitLab feature flags."""

    def __init__(self, client: GitLabClient) -> None:
        self._client = client

    async def stream_for_project(
        self, project_id: int, **params: Any
    ) -> AsyncIterator[FeatureFlag]:
        """Stream feature flags for a project.

        Args:
            project_id: GitLab project ID
            **params: Filters: scope

        Yields:
            FeatureFlag: Feature flag records
        """
        async for page_bytes in self._client.paginate(
            f"/projects/{project_id}/feature_flags", **params
        ):
            for item in _flag_list_decoder.decode(page_bytes):
                yield item

    async def get(self, project_id: int, name: str, **params: Any) -> FeatureFlag:
        """Get a single feature flag by name.

        Args:
            project_id: GitLab project ID
            name: Feature flag name

        Returns:
            FeatureFlag: The feature flag record
        """
        data = await self._client.get(
            f"/projects/{project_id}/feature_flags/{name}", **params
        )
        return _flag_decoder.decode(data)

    async def stream_user_lists(
        self, project_id: int, **params: Any
    ) -> AsyncIterator[FeatureFlagUserList]:
        """Stream user lists for a project's feature flags.

        Args:
            project_id: GitLab project ID

        Yields:
            FeatureFlagUserList: User list records
        """
        async for page_bytes in self._client.paginate(
            f"/projects/{project_id}/feature_flags_user_lists", **params
        ):
            for item in _user_list_decoder.decode(page_bytes):
                yield item

    async def get_user_list(
        self, project_id: int, iid: int, **params: Any
    ) -> FeatureFlagUserList:
        """Get a single feature flag user list by IID.

        Args:
            project_id: GitLab project ID
            iid: User list IID

        Returns:
            FeatureFlagUserList: The user list record
        """
        data = await self._client.get(
            f"/projects/{project_id}/feature_flags_user_lists/{iid}", **params
        )
        return _single_user_list_decoder.decode(data)
