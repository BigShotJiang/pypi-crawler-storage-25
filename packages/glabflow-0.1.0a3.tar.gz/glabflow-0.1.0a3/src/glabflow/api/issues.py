from __future__ import annotations

from collections.abc import AsyncIterator
from typing import TYPE_CHECKING, Any

import msgspec

from glabflow.models.issues import Issue

if TYPE_CHECKING:
    from glabflow._client import GitLabClient


# Decoder for issues
_issue_decoder = msgspec.json.Decoder(Issue)
_issue_list_decoder = msgspec.json.Decoder(list[Issue])


class IssuesAPI:
    """Async API for accessing GitLab issues."""

    def __init__(self, client: GitLabClient) -> None:
        self._client = client

    async def stream(self, **params: Any) -> AsyncIterator[Issue]:
        """Stream all issues with keyset pagination."""
        async for page_bytes in self._client.paginate("/issues", **params):
            for item in _issue_list_decoder.decode(page_bytes):
                yield item

    async def stream_for_project(
        self, project_id: int, **params: Any
    ) -> AsyncIterator[Issue]:
        """Stream issues for a project."""
        async for page_bytes in self._client.paginate(
            f"/projects/{project_id}/issues", **params
        ):
            for item in _issue_list_decoder.decode(page_bytes):
                yield item

    async def stream_for_user(
        self, user_id: int, **params: Any
    ) -> AsyncIterator[Issue]:
        """Stream issues for a user."""
        # Convert user_id to author_id
        params["author_id"] = user_id
        async for page_bytes in self._client.paginate("/issues", **params):
            for item in _issue_list_decoder.decode(page_bytes):
                yield item

    async def get(self, project_id: int, issue_iid: int, **params: Any) -> Issue:
        """Get a specific issue by project ID and issue IID."""
        path = f"/projects/{project_id}/issues/{issue_iid}"
        data = await self._client.get(path, **params)
        return _issue_decoder.decode(data)

    async def get_for_project(
        self, project_id: int, issue_iid: int, **params: Any
    ) -> Issue:
        """Get a specific issue by project ID and issue IID."""
        path = f"/projects/{project_id}/issues/{issue_iid}"
        data = await self._client.get(path, **params)
        return _issue_decoder.decode(data)

    async def list_page(self, **params: Any) -> list[Issue]:
        """List a single page of issues."""
        data = await self._client.get("/issues", **params)
        return _issue_list_decoder.decode(data)
