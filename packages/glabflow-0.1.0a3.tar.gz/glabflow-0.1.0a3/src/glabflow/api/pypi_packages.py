from __future__ import annotations

from collections.abc import AsyncIterator
from typing import TYPE_CHECKING, Any

import msgspec

from glabflow.models.pypi_packages import PypiPackage

if TYPE_CHECKING:
    from glabflow._client import GitLabClient


# Decoder for pypi_packages
_pypi_packages_decoder = msgspec.json.Decoder(list[PypiPackage])
_pypi_packages_single_decoder = msgspec.json.Decoder(PypiPackage)


class PypiPackagesAPI:
    """Async API for accessing GitLab pypi_packages."""

    def __init__(self, client: GitLabClient) -> None:
        self._client = client

    async def stream(self, **params: Any) -> AsyncIterator[PypiPackage]:
        """Stream all pypi_packages with keyset pagination.

        Args:
            **params: Additional query parameters

        Yields:
            PypiPackage: GitLab pypi_packages resource items
        """
        async for page_bytes in self._client.paginate("/pypi_packages", **params):
            for item in _pypi_packages_decoder.decode(page_bytes):
                yield item

    async def get(self, id: int, **params: Any) -> PypiPackage:
        """Get a specific pypi_packages by ID.

        Args:
            id: PypiPackage ID
            **params: Additional query parameters

        Returns:
            PypiPackage: The requested item
        """
        path = f"/pypi_packages/{id}"
        data = await self._client.get(path, **params)
        return _pypi_packages_single_decoder.decode(data)

    async def list_page(self, **params: Any) -> list[PypiPackage]:
        """List a single page of pypi_packages.

        Args:
            **params: Query parameters (page, per_page, etc.)

        Returns:
            list[PypiPackage]: List of items
        """
        data = await self._client.get("/pypi_packages", **params)
        return _pypi_packages_decoder.decode(data)
