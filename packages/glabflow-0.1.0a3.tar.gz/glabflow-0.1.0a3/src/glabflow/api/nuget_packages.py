from __future__ import annotations

from collections.abc import AsyncIterator
from typing import TYPE_CHECKING, Any

import msgspec

from glabflow.models.nuget_packages import NugetPackage

if TYPE_CHECKING:
    from glabflow._client import GitLabClient


# Decoder for nuget_packages
_nuget_packages_decoder = msgspec.json.Decoder(list[NugetPackage])
_nuget_packages_single_decoder = msgspec.json.Decoder(NugetPackage)


class NugetPackagesAPI:
    """Async API for accessing GitLab nuget_packages."""

    def __init__(self, client: GitLabClient) -> None:
        self._client = client

    async def stream(self, **params: Any) -> AsyncIterator[NugetPackage]:
        """Stream all nuget_packages with keyset pagination.

        Args:
            **params: Additional query parameters

        Yields:
            NugetPackage: GitLab nuget_packages resource items
        """
        async for page_bytes in self._client.paginate("/nuget_packages", **params):
            for item in _nuget_packages_decoder.decode(page_bytes):
                yield item

    async def get(self, id: int, **params: Any) -> NugetPackage:
        """Get a specific nuget_packages by ID.

        Args:
            id: NugetPackage ID
            **params: Additional query parameters

        Returns:
            NugetPackage: The requested item
        """
        path = f"/nuget_packages/{id}"
        data = await self._client.get(path, **params)
        return _nuget_packages_single_decoder.decode(data)

    async def list_page(self, **params: Any) -> list[NugetPackage]:
        """List a single page of nuget_packages.

        Args:
            **params: Query parameters (page, per_page, etc.)

        Returns:
            list[NugetPackage]: List of items
        """
        data = await self._client.get("/nuget_packages", **params)
        return _nuget_packages_decoder.decode(data)
