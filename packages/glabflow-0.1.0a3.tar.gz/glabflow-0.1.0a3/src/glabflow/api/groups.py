from __future__ import annotations

from collections.abc import AsyncIterator
from typing import TYPE_CHECKING, Any

import msgspec

from glabflow.models.groups import Group
from glabflow.models.members import Member

if TYPE_CHECKING:
    from glabflow._client import GitLabClient


# Decoder for groups
_group_decoder = msgspec.json.Decoder(Group)
_groups_decoder = msgspec.json.Decoder(list[Group])
_member_decoder = msgspec.json.Decoder(Member)
_members_decoder = msgspec.json.Decoder(list[Member])


class GroupsAPI:
    """Async API for accessing GitLab groups."""

    def __init__(self, client: GitLabClient) -> None:
        self._client = client

    async def stream(self, **params: Any) -> AsyncIterator[Group]:
        """Stream all groups with keyset pagination."""
        # Convert boolean top_level_only to string
        if "top_level_only" in params:
            params["top_level_only"] = "true" if params["top_level_only"] else "false"
        async for page_bytes in self._client.paginate("/groups", **params):
            for item in _groups_decoder.decode(page_bytes):
                yield item

    async def stream_subgroups(
        self, group_id: int, **params: Any
    ) -> AsyncIterator[Group]:
        """Stream subgroups of a group."""
        async for page_bytes in self._client.paginate(
            f"/groups/{group_id}/subgroups", **params
        ):
            for item in _groups_decoder.decode(page_bytes):
                yield item

    async def stream_descendants(
        self, group_id: int, **params: Any
    ) -> AsyncIterator[Group]:
        """Stream descendant groups of a group."""
        async for page_bytes in self._client.paginate(
            f"/groups/{group_id}/descendant_groups", **params
        ):
            for item in _groups_decoder.decode(page_bytes):
                yield item

    async def stream_members(
        self, group_id: int, **params: Any
    ) -> AsyncIterator[Member]:
        """Stream members of a group."""
        async for page_bytes in self._client.paginate(
            f"/groups/{group_id}/members", **params
        ):
            for item in _members_decoder.decode(page_bytes):
                yield item

    async def get(self, id: int, **params: Any) -> Group:
        """Get a specific group by ID."""
        path = f"/groups/{id}"
        data = await self._client.get(path, **params)
        return _group_decoder.decode(data)

    async def get_member(self, group_id: int, user_id: int, **params: Any) -> Member:
        """Get a specific member of a group."""
        path = f"/groups/{group_id}/members/{user_id}"
        data = await self._client.get(path, **params)
        return _member_decoder.decode(data)

    async def list_page(self, **params: Any) -> list[Group]:
        """List a single page of groups."""
        data = await self._client.get("/groups", **params)
        return _groups_decoder.decode(data)
