from __future__ import annotations

from collections.abc import AsyncIterator
from typing import TYPE_CHECKING, Any

import msgspec

from glabflow.models.dependency_proxy import DependencyProxy

if TYPE_CHECKING:
    from glabflow._client import GitLabClient


# Decoder for dependency_proxy
_dependency_proxy_decoder = msgspec.json.Decoder(list[DependencyProxy])
_dependency_proxy_single_decoder = msgspec.json.Decoder(DependencyProxy)


class DependencyProxyAPI:
    """Async API for accessing GitLab dependency_proxy."""

    def __init__(self, client: GitLabClient) -> None:
        self._client = client

    async def stream(self, **params: Any) -> AsyncIterator[DependencyProxy]:
        """Stream all dependency_proxy with keyset pagination.

        Args:
            **params: Additional query parameters

        Yields:
            DependencyProxy: GitLab dependency_proxy resource items
        """
        async for page_bytes in self._client.paginate("/dependency_proxy", **params):
            for item in _dependency_proxy_decoder.decode(page_bytes):
                yield item

    async def get(self, id: int, **params: Any) -> DependencyProxy:
        """Get a specific dependency_proxy by ID.

        Args:
            id: DependencyProxy ID
            **params: Additional query parameters

        Returns:
            DependencyProxy: The requested item
        """
        path = f"/dependency_proxy/{id}"
        data = await self._client.get(path, **params)
        return _dependency_proxy_single_decoder.decode(data)

    async def list_page(self, **params: Any) -> list[DependencyProxy]:
        """List a single page of dependency_proxy.

        Args:
            **params: Query parameters (page, per_page, etc.)

        Returns:
            list[DependencyProxy]: List of items
        """
        data = await self._client.get("/dependency_proxy", **params)
        return _dependency_proxy_decoder.decode(data)
