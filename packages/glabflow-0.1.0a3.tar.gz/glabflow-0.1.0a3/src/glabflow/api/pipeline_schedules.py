from __future__ import annotations

from collections.abc import AsyncIterator
from typing import TYPE_CHECKING, Any

import msgspec

from glabflow.models.pipeline_schedules import PipelineSchedule
from glabflow.models.pipelines import TestReport, TestReportSummary

if TYPE_CHECKING:
    from glabflow._client import GitLabClient


# Decoder for pipeline_schedules
_pipeline_schedule_decoder = msgspec.json.Decoder(PipelineSchedule)
_pipeline_schedule_list_decoder = msgspec.json.Decoder(list[PipelineSchedule])
_test_report_decoder = msgspec.json.Decoder(TestReport)
_test_report_summary_decoder = msgspec.json.Decoder(TestReportSummary)


class PipelineSchedulesAPI:
    """Async API for accessing GitLab pipeline schedules."""

    def __init__(self, client: GitLabClient) -> None:
        self._client = client

    async def stream(self, **params: Any) -> AsyncIterator[PipelineSchedule]:
        """Stream all pipeline schedules with keyset pagination."""
        async for page_bytes in self._client.paginate("/pipeline_schedules", **params):
            for item in _pipeline_schedule_list_decoder.decode(page_bytes):
                yield item

    async def stream_for_project(
        self, project_id: int, **params: Any
    ) -> AsyncIterator[PipelineSchedule]:
        """Stream pipeline schedules for a project."""
        async for page_bytes in self._client.paginate(
            f"/projects/{project_id}/pipeline_schedules", **params
        ):
            for item in _pipeline_schedule_list_decoder.decode(page_bytes):
                yield item

    async def get(
        self, project_id: int, schedule_id: int, **params: Any
    ) -> PipelineSchedule:
        """Get a specific pipeline schedule by project ID and schedule ID."""
        path = f"/projects/{project_id}/pipeline_schedules/{schedule_id}"
        data = await self._client.get(path, **params)
        return _pipeline_schedule_decoder.decode(data)

    async def get_test_report(
        self, project_id: int, schedule_id: int, **params: Any
    ) -> TestReport:
        """Get test report for a pipeline schedule."""
        path = f"/projects/{project_id}/pipeline_schedules/{schedule_id}/test_report"
        data = await self._client.get(path, **params)
        return _test_report_decoder.decode(data)

    async def get_test_report_summary(
        self, project_id: int, schedule_id: int, **params: Any
    ) -> TestReportSummary:
        """Get test report summary for a pipeline schedule."""
        path = f"/projects/{project_id}/pipeline_schedules/{schedule_id}/test_report_summary"
        data = await self._client.get(path, **params)
        return _test_report_summary_decoder.decode(data)

    async def list_page(self, **params: Any) -> list[PipelineSchedule]:
        """List a single page of pipeline schedules."""
        data = await self._client.get("/pipeline_schedules", **params)
        return _pipeline_schedule_list_decoder.decode(data)
