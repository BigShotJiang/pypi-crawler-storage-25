from __future__ import annotations

from collections.abc import AsyncIterator
from typing import TYPE_CHECKING, Any

import msgspec

from glabflow.models.dockerfile_templates import DockerfileTemplate

if TYPE_CHECKING:
    from glabflow._client import GitLabClient


# Decoder for dockerfile_templates
_dockerfile_templates_decoder = msgspec.json.Decoder(list[DockerfileTemplate])
_dockerfile_templates_single_decoder = msgspec.json.Decoder(DockerfileTemplate)


class DockerfileTemplatesAPI:
    """Async API for accessing GitLab dockerfile_templates."""

    def __init__(self, client: GitLabClient) -> None:
        self._client = client

    async def stream(self, **params: Any) -> AsyncIterator[DockerfileTemplate]:
        """Stream all dockerfile_templates with keyset pagination.

        Args:
            **params: Additional query parameters

        Yields:
            DockerfileTemplate: GitLab dockerfile_templates resource items
        """
        async for page_bytes in self._client.paginate(
            "/dockerfile_templates", **params
        ):
            for item in _dockerfile_templates_decoder.decode(page_bytes):
                yield item

    async def get(self, id: int, **params: Any) -> DockerfileTemplate:
        """Get a specific dockerfile_templates by ID.

        Args:
            id: DockerfileTemplate ID
            **params: Additional query parameters

        Returns:
            DockerfileTemplate: The requested item
        """
        path = f"/dockerfile_templates/{id}"
        data = await self._client.get(path, **params)
        return _dockerfile_templates_single_decoder.decode(data)

    async def list_page(self, **params: Any) -> list[DockerfileTemplate]:
        """List a single page of dockerfile_templates.

        Args:
            **params: Query parameters (page, per_page, etc.)

        Returns:
            list[DockerfileTemplate]: List of items
        """
        data = await self._client.get("/dockerfile_templates", **params)
        return _dockerfile_templates_decoder.decode(data)
