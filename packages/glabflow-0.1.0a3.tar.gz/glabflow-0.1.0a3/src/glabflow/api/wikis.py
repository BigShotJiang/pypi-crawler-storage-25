from __future__ import annotations

from collections.abc import AsyncIterator
from typing import TYPE_CHECKING, Any

import msgspec

from glabflow.models.wikis import WikiPage

if TYPE_CHECKING:
    from glabflow._client import GitLabClient


# Decoder for wikis
_wiki_page_decoder = msgspec.json.Decoder(WikiPage)
_wiki_page_list_decoder = msgspec.json.Decoder(list[WikiPage])


class WikisAPI:
    """Async API for accessing GitLab wikis."""

    def __init__(self, client: GitLabClient) -> None:
        self._client = client

    async def stream(self, **params: Any) -> AsyncIterator[WikiPage]:
        """Stream all wiki pages with keyset pagination."""
        # Convert boolean with_content to string
        if "with_content" in params:
            params["with_content"] = "true" if params["with_content"] else "false"
        async for page_bytes in self._client.paginate("/wikis", **params):
            for item in _wiki_page_list_decoder.decode(page_bytes):
                yield item

    async def stream_project(
        self, project_id: int, **params: Any
    ) -> AsyncIterator[WikiPage]:
        """Stream wiki pages for a project."""
        # Convert boolean with_content to string
        if "with_content" in params:
            params["with_content"] = "true" if params["with_content"] else "false"
        async for page_bytes in self._client.paginate(
            f"/projects/{project_id}/wikis", **params
        ):
            for item in _wiki_page_list_decoder.decode(page_bytes):
                yield item

    async def stream_group(
        self, group_id: int, **params: Any
    ) -> AsyncIterator[WikiPage]:
        """Stream wiki pages for a group."""
        # Convert boolean with_content to string
        if "with_content" in params:
            params["with_content"] = "true" if params["with_content"] else "false"
        async for page_bytes in self._client.paginate(
            f"/groups/{group_id}/wikis", **params
        ):
            for item in _wiki_page_list_decoder.decode(page_bytes):
                yield item

    async def get(self, id: int, **params: Any) -> WikiPage:
        """Get a specific wiki page by ID."""
        path = f"/wikis/{id}"
        data = await self._client.get(path, **params)
        return _wiki_page_decoder.decode(data)

    async def get_project_page(
        self, project_id: int, slug: str, **params: Any
    ) -> WikiPage:
        """Get a specific project wiki page by slug."""
        path = f"/projects/{project_id}/wikis/{slug}"
        data = await self._client.get(path, **params)
        return _wiki_page_decoder.decode(data)

    async def get_group_page(self, group_id: int, slug: str, **params: Any) -> WikiPage:
        """Get a specific group wiki page by slug."""
        path = f"/groups/{group_id}/wikis/{slug}"
        data = await self._client.get(path, **params)
        return _wiki_page_decoder.decode(data)

    async def list_page(self, **params: Any) -> list[WikiPage]:
        """List a single page of wiki pages."""
        data = await self._client.get("/wikis", **params)
        return _wiki_page_list_decoder.decode(data)
