from __future__ import annotations

from collections.abc import AsyncIterator
from typing import TYPE_CHECKING, Any

import msgspec

from glabflow.models.audit_events import AuditEvent

if TYPE_CHECKING:
    from glabflow._client import GitLabClient


# Decoder for audit_events
_audit_events_decoder = msgspec.json.Decoder(list[AuditEvent])
_audit_events_single_decoder = msgspec.json.Decoder(AuditEvent)


class AuditEventsAPI:
    """Async API for accessing GitLab audit_events."""

    def __init__(self, client: GitLabClient) -> None:
        self._client = client

    async def stream(self, **params: Any) -> AsyncIterator[AuditEvent]:
        """Stream all audit_events with keyset pagination.

        Args:
            **params: Additional query parameters

        Yields:
            AuditEvent: GitLab audit_events resource items
        """
        async for page_bytes in self._client.paginate("/audit_events", **params):
            for item in _audit_events_decoder.decode(page_bytes):
                yield item

    async def get(self, id: int, **params: Any) -> AuditEvent:
        """Get a specific audit_events by ID.

        Args:
            id: AuditEvent ID
            **params: Additional query parameters

        Returns:
            AuditEvent: The requested item
        """
        path = f"/audit_events/{id}"
        data = await self._client.get(path, **params)
        return _audit_events_single_decoder.decode(data)

    async def list_page(self, **params: Any) -> list[AuditEvent]:
        """List a single page of audit_events.

        Args:
            **params: Query parameters (page, per_page, etc.)

        Returns:
            list[AuditEvent]: List of items
        """
        data = await self._client.get("/audit_events", **params)
        return _audit_events_decoder.decode(data)
