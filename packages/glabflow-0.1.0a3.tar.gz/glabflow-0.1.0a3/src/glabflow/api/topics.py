from __future__ import annotations

from collections.abc import AsyncIterator
from typing import TYPE_CHECKING, Any

import msgspec

from glabflow.models.topics import Topic

if TYPE_CHECKING:
    from glabflow._client import GitLabClient


# Decoder for topics
_topics_decoder = msgspec.json.Decoder(list[Topic])
_topics_single_decoder = msgspec.json.Decoder(Topic)


class TopicsAPI:
    """Async API for accessing GitLab topics."""

    def __init__(self, client: GitLabClient) -> None:
        self._client = client

    async def stream(self, **params: Any) -> AsyncIterator[Topic]:
        """Stream all topics with keyset pagination.

        Args:
            **params: Additional query parameters

        Yields:
            Topic: GitLab topics resource items
        """
        async for page_bytes in self._client.paginate("/topics", **params):
            for item in _topics_decoder.decode(page_bytes):
                yield item

    async def get(self, id: int, **params: Any) -> Topic:
        """Get a specific topics by ID.

        Args:
            id: Topic ID
            **params: Additional query parameters

        Returns:
            Topic: The requested item
        """
        path = f"/topics/{id}"
        data = await self._client.get(path, **params)
        return _topics_single_decoder.decode(data)

    async def list_page(self, **params: Any) -> list[Topic]:
        """List a single page of topics.

        Args:
            **params: Query parameters (page, per_page, etc.)

        Returns:
            list[Topic]: List of items
        """
        data = await self._client.get("/topics", **params)
        return _topics_decoder.decode(data)
