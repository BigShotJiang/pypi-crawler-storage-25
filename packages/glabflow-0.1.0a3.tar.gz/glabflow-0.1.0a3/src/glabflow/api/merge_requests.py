from __future__ import annotations

import asyncio
from collections.abc import AsyncIterator
from typing import TYPE_CHECKING, Any

import msgspec

from glabflow.models.merge_requests import MergeRequest

if TYPE_CHECKING:
    from glabflow._client import GitLabClient


# Decoder for merge_requests - pre-allocated for performance
_mr_decoder = msgspec.json.Decoder(MergeRequest)
_mr_list_decoder = msgspec.json.Decoder(list[MergeRequest])


class MergeRequestsAPI:
    """Async API for accessing GitLab merge requests."""

    def __init__(self, client: GitLabClient) -> None:
        self._client = client

    async def stream(self, **params: Any) -> AsyncIterator[MergeRequest]:
        """Stream all merge requests with keyset pagination.

        Uses parallel decode: decodes the next page while yielding
        items from the current page for better performance.
        """
        async for item in self._stream_with_parallel_decode(
            "/merge_requests", **params
        ):
            yield item

    async def stream_for_project(
        self, project_id: int, **params: Any
    ) -> AsyncIterator[MergeRequest]:
        """Stream merge requests for a project.

        Uses parallel decode for better performance.
        """
        async for item in self._stream_with_parallel_decode(
            f"/projects/{project_id}/merge_requests", **params
        ):
            yield item

    async def stream_for_user(
        self, user_id: int, **params: Any
    ) -> AsyncIterator[MergeRequest]:
        """Stream merge requests for a user.

        Uses parallel decode for better performance.
        """
        async for item in self._stream_with_parallel_decode(
            f"/users/{user_id}/merge_requests", **params
        ):
            yield item

    async def _stream_with_parallel_decode(
        self, endpoint: str, **params: Any
    ) -> AsyncIterator[MergeRequest]:
        """Internal method for streaming with parallel decode."""
        queue: asyncio.Queue[bytes | None] = asyncio.Queue(maxsize=2)

        async def _fetch_pages():
            try:
                async for page_bytes in self._client.paginate(endpoint, **params):
                    await queue.put(page_bytes)
            finally:
                await queue.put(None)

        async def _decode_page(page_bytes: bytes) -> list[MergeRequest]:
            return _mr_list_decoder.decode(page_bytes)

        fetch_task = asyncio.create_task(_fetch_pages())

        try:
            decode_task: asyncio.Task | None = None

            while True:
                page_bytes = await queue.get()
                if page_bytes is None:
                    if decode_task is not None:
                        items = await decode_task
                        for item in items:
                            yield item
                    break

                current_decode = decode_task
                decode_task = asyncio.create_task(_decode_page(page_bytes))

                if current_decode is not None:
                    items = await current_decode
                    for item in items:
                        yield item
        finally:
            fetch_task.cancel()
            try:
                await fetch_task
            except asyncio.CancelledError:
                pass

    async def get(self, project_id: int, mr_iid: int, **params: Any) -> MergeRequest:
        """Get a specific merge request by project ID and IID."""
        path = f"/projects/{project_id}/merge_requests/{mr_iid}"
        data = await self._client.get(path, **params)
        return _mr_decoder.decode(data)

    async def get_for_project(
        self, project_id: int, mr_iid: int, **params: Any
    ) -> MergeRequest:
        """Get a specific merge request by project ID and IID."""
        path = f"/projects/{project_id}/merge_requests/{mr_iid}"
        data = await self._client.get(path, **params)
        return _mr_decoder.decode(data)

    async def list_page(self, **params: Any) -> list[MergeRequest]:
        """List a single page of merge requests."""
        data = await self._client.get("/merge_requests", **params)
        return _mr_list_decoder.decode(data)
