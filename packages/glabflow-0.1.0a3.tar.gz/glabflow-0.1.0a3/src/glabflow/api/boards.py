from __future__ import annotations

from collections.abc import AsyncIterator
from typing import TYPE_CHECKING, Any

import msgspec

from glabflow.models.boards import Board

if TYPE_CHECKING:
    from glabflow._client import GitLabClient


# Decoder for boards
_boards_decoder = msgspec.json.Decoder(list[Board])
_boards_single_decoder = msgspec.json.Decoder(Board)


class BoardsAPI:
    """Async API for accessing GitLab boards."""

    def __init__(self, client: GitLabClient) -> None:
        self._client = client

    async def stream(self, **params: Any) -> AsyncIterator[Board]:
        """Stream all boards with keyset pagination.

        Args:
            **params: Additional query parameters

        Yields:
            Board: GitLab boards resource items
        """
        async for page_bytes in self._client.paginate("/boards", **params):
            for item in _boards_decoder.decode(page_bytes):
                yield item

    async def get(self, id: int, **params: Any) -> Board:
        """Get a specific boards by ID.

        Args:
            id: Board ID
            **params: Additional query parameters

        Returns:
            Board: The requested item
        """
        path = f"/boards/{id}"
        data = await self._client.get(path, **params)
        return _boards_single_decoder.decode(data)

    async def list_page(self, **params: Any) -> list[Board]:
        """List a single page of boards.

        Args:
            **params: Query parameters (page, per_page, etc.)

        Returns:
            list[Board]: List of items
        """
        data = await self._client.get("/boards", **params)
        return _boards_decoder.decode(data)
