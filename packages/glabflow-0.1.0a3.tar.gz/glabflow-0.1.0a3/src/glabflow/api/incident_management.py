from __future__ import annotations

from collections.abc import AsyncIterator
from typing import TYPE_CHECKING, Any

import msgspec

from glabflow.models.incident_management import IncidentManagement

if TYPE_CHECKING:
    from glabflow._client import GitLabClient


# Decoder for incident_management
_incident_management_decoder = msgspec.json.Decoder(list[IncidentManagement])
_incident_management_single_decoder = msgspec.json.Decoder(IncidentManagement)


class IncidentManagementAPI:
    """Async API for accessing GitLab incident_management."""

    def __init__(self, client: GitLabClient) -> None:
        self._client = client

    async def stream(self, **params: Any) -> AsyncIterator[IncidentManagement]:
        """Stream all incident_management with keyset pagination.

        Args:
            **params: Additional query parameters

        Yields:
            IncidentManagement: GitLab incident_management resource items
        """
        async for page_bytes in self._client.paginate("/incident_management", **params):
            for item in _incident_management_decoder.decode(page_bytes):
                yield item

    async def get(self, id: int, **params: Any) -> IncidentManagement:
        """Get a specific incident_management by ID.

        Args:
            id: IncidentManagement ID
            **params: Additional query parameters

        Returns:
            IncidentManagement: The requested item
        """
        path = f"/incident_management/{id}"
        data = await self._client.get(path, **params)
        return _incident_management_single_decoder.decode(data)

    async def list_page(self, **params: Any) -> list[IncidentManagement]:
        """List a single page of incident_management.

        Args:
            **params: Query parameters (page, per_page, etc.)

        Returns:
            list[IncidentManagement]: List of items
        """
        data = await self._client.get("/incident_management", **params)
        return _incident_management_decoder.decode(data)
