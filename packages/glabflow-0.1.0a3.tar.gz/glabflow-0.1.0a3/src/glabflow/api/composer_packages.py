from __future__ import annotations

from collections.abc import AsyncIterator
from typing import TYPE_CHECKING, Any

import msgspec

from glabflow.models.composer_packages import ComposerPackage

if TYPE_CHECKING:
    from glabflow._client import GitLabClient


# Decoder for composer_packages
_composer_packages_decoder = msgspec.json.Decoder(list[ComposerPackage])
_composer_packages_single_decoder = msgspec.json.Decoder(ComposerPackage)


class ComposerPackagesAPI:
    """Async API for accessing GitLab composer_packages."""

    def __init__(self, client: GitLabClient) -> None:
        self._client = client

    async def stream(self, **params: Any) -> AsyncIterator[ComposerPackage]:
        """Stream all composer_packages with keyset pagination.

        Args:
            **params: Additional query parameters

        Yields:
            ComposerPackage: GitLab composer_packages resource items
        """
        async for page_bytes in self._client.paginate("/composer_packages", **params):
            for item in _composer_packages_decoder.decode(page_bytes):
                yield item

    async def get(self, id: int, **params: Any) -> ComposerPackage:
        """Get a specific composer_packages by ID.

        Args:
            id: ComposerPackage ID
            **params: Additional query parameters

        Returns:
            ComposerPackage: The requested item
        """
        path = f"/composer_packages/{id}"
        data = await self._client.get(path, **params)
        return _composer_packages_single_decoder.decode(data)

    async def list_page(self, **params: Any) -> list[ComposerPackage]:
        """List a single page of composer_packages.

        Args:
            **params: Query parameters (page, per_page, etc.)

        Returns:
            list[ComposerPackage]: List of items
        """
        data = await self._client.get("/composer_packages", **params)
        return _composer_packages_decoder.decode(data)
