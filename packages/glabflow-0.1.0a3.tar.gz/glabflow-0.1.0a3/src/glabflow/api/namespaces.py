from __future__ import annotations

from collections.abc import AsyncIterator
from typing import TYPE_CHECKING, Any

import msgspec

from glabflow.models.namespaces import Namespace

if TYPE_CHECKING:
    from glabflow._client import GitLabClient


# Decoder for namespaces
_namespace_decoder = msgspec.json.Decoder(Namespace)
_namespace_list_decoder = msgspec.json.Decoder(list[Namespace])


class NamespacesAPI:
    """Async API for accessing GitLab namespaces."""

    def __init__(self, client: GitLabClient) -> None:
        self._client = client

    async def stream(self, **params: Any) -> AsyncIterator[Namespace]:
        """Stream all namespaces with keyset pagination."""
        async for page_bytes in self._client.paginate("/namespaces", **params):
            for item in _namespace_list_decoder.decode(page_bytes):
                yield item

    async def get(self, id: int, **params: Any) -> Namespace:
        """Get a specific namespace by ID."""
        path = f"/namespaces/{id}"
        data = await self._client.get(path, **params)
        return _namespace_decoder.decode(data)

    async def list_page(self, **params: Any) -> list[Namespace]:
        """List a single page of namespaces."""
        data = await self._client.get("/namespaces", **params)
        return _namespace_list_decoder.decode(data)
