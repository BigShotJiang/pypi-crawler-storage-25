from __future__ import annotations

from typing import TYPE_CHECKING, Any

import msgspec

from glabflow.models.settings import License, Setting

if TYPE_CHECKING:
    from glabflow._client import GitLabClient


# Decoder for settings
_settings_decoder = msgspec.json.Decoder(list[Setting])


class SettingsAPI:
    """Async API for accessing GitLab settings."""

    def __init__(self, client: GitLabClient) -> None:
        self._client = client

    async def get(self, **params: Any) -> Setting:
        """Get instance settings.

        Args:
            **params: Additional query parameters

        Returns:
            Setting: GitLab settings
        """
        data = await self._client.get("/application/settings", **params)
        return _settings_decoder.decode(data)[0]

    async def get_license(self, **params: Any) -> License:
        """Get instance license.

        Args:
            **params: Additional query parameters

        Returns:
            License: GitLab license information
        """
        data = await self._client.get("/license", **params)
        decoder = msgspec.json.Decoder(License)
        return decoder.decode(data)

    async def list_page(self, **params: Any) -> list[Setting]:
        """List a single page of settings (legacy, use get() instead).

        Args:
            **params: Query parameters (page, per_page, etc.)

        Returns:
            list[Setting]: List of items
        """
        data = await self._client.get("/application/settings", **params)
        return _settings_decoder.decode(data)
