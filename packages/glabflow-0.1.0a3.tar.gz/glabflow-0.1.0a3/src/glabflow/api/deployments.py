from __future__ import annotations

from collections.abc import AsyncIterator
from typing import TYPE_CHECKING, Any

import msgspec

from glabflow.models.deployments import Deployment, Environment

if TYPE_CHECKING:
    from glabflow._client import GitLabClient


# Decoders for deployments
_deployment_decoder = msgspec.json.Decoder(Deployment)
_deployment_list_decoder = msgspec.json.Decoder(list[Deployment])
_environment_decoder = msgspec.json.Decoder(Environment)
_environment_list_decoder = msgspec.json.Decoder(list[Environment])


class DeploymentsAPI:
    """Async API for accessing GitLab deployments."""

    def __init__(self, client: GitLabClient) -> None:
        self._client = client

    async def stream(
        self, project_id: int | None = None, **params: Any
    ) -> AsyncIterator[Deployment]:
        """Stream all deployments with keyset pagination."""
        if project_id is not None:
            path = f"/projects/{project_id}/deployments"
        else:
            path = "/deployments"
        async for page_bytes in self._client.paginate(path, **params):
            for item in _deployment_list_decoder.decode(page_bytes):
                yield item

    async def stream_for_project(
        self, project_id: int, **params: Any
    ) -> AsyncIterator[Deployment]:
        """Stream deployments for a project."""
        async for page_bytes in self._client.paginate(
            f"/projects/{project_id}/deployments", **params
        ):
            for item in _deployment_list_decoder.decode(page_bytes):
                yield item

    async def stream_environments(
        self, project_id: int, **params: Any
    ) -> AsyncIterator[Environment]:
        """Stream environments for a project."""
        async for page_bytes in self._client.paginate(
            f"/projects/{project_id}/environments", **params
        ):
            for item in _environment_list_decoder.decode(page_bytes):
                yield item

    async def get(
        self, project_id: int, deployment_id: int, **params: Any
    ) -> Deployment:
        """Get a specific deployment by project ID and deployment ID."""
        path = f"/projects/{project_id}/deployments/{deployment_id}"
        data = await self._client.get(path, **params)
        return _deployment_decoder.decode(data)

    async def get_environment(
        self, project_id: int, environment_id: int, **params: Any
    ) -> Environment:
        """Get a specific environment by ID."""
        path = f"/projects/{project_id}/environments/{environment_id}"
        data = await self._client.get(path, **params)
        return _environment_decoder.decode(data)

    async def list_page(self, **params: Any) -> list[Deployment]:
        """List a single page of deployments."""
        data = await self._client.get("/deployments", **params)
        return _deployment_list_decoder.decode(data)
