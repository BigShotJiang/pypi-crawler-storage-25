from __future__ import annotations

from collections.abc import AsyncIterator
from typing import TYPE_CHECKING, Any

import msgspec

from glabflow.models.merge_trains import MergeTrain

if TYPE_CHECKING:
    from glabflow._client import GitLabClient


# Decoder for merge_trains
_merge_trains_decoder = msgspec.json.Decoder(list[MergeTrain])
_merge_trains_single_decoder = msgspec.json.Decoder(MergeTrain)


class MergeTrainsAPI:
    """Async API for accessing GitLab merge_trains."""

    def __init__(self, client: GitLabClient) -> None:
        self._client = client

    async def stream(self, **params: Any) -> AsyncIterator[MergeTrain]:
        """Stream all merge_trains with keyset pagination.

        Args:
            **params: Additional query parameters

        Yields:
            MergeTrain: GitLab merge_trains resource items
        """
        async for page_bytes in self._client.paginate("/merge_trains", **params):
            for item in _merge_trains_decoder.decode(page_bytes):
                yield item

    async def get(self, id: int, **params: Any) -> MergeTrain:
        """Get a specific merge_trains by ID.

        Args:
            id: MergeTrain ID
            **params: Additional query parameters

        Returns:
            MergeTrain: The requested item
        """
        path = f"/merge_trains/{id}"
        data = await self._client.get(path, **params)
        return _merge_trains_single_decoder.decode(data)

    async def list_page(self, **params: Any) -> list[MergeTrain]:
        """List a single page of merge_trains.

        Args:
            **params: Query parameters (page, per_page, etc.)

        Returns:
            list[MergeTrain]: List of items
        """
        data = await self._client.get("/merge_trains", **params)
        return _merge_trains_decoder.decode(data)
