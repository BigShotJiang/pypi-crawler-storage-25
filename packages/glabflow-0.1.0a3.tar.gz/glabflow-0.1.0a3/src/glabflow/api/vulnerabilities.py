from __future__ import annotations

from collections.abc import AsyncIterator
from typing import TYPE_CHECKING, Any

import msgspec

from glabflow.models.vulnerability import Vulnerability, VulnerabilityFinding

if TYPE_CHECKING:
    from glabflow._client import GitLabClient

_vuln_list_decoder = msgspec.json.Decoder(list[Vulnerability])
_vuln_decoder = msgspec.json.Decoder(Vulnerability)
_finding_decoder = msgspec.json.Decoder(list[VulnerabilityFinding])


class VulnerabilitiesAPI:
    """Async API for streaming GitLab vulnerability data.

    Supports project-level and group-level vulnerability exports and
    vulnerability finding details — covering ISO 27001 / SOC 2 security
    posture reporting requirements.
    """

    def __init__(self, client: GitLabClient) -> None:
        self._client = client

    async def get(self, id: int, **params: Any) -> Vulnerability:
        """Get a single vulnerability by ID.

        Args:
            id: Vulnerability ID
            **params: Additional query parameters

        Returns:
            Vulnerability: The requested vulnerability record
        """
        data = await self._client.get(f"/vulnerabilities/{id}", **params)
        return _vuln_decoder.decode(data)

    async def stream_for_project(
        self, project_id: int, **params: Any
    ) -> AsyncIterator[Vulnerability]:
        """Stream all vulnerabilities for a project.

        Args:
            project_id: GitLab project ID
            **params: Filters: severity, state, report_type, scanner

        Yields:
            Vulnerability: Project vulnerability records
        """
        async for page_bytes in self._client.paginate(
            f"/projects/{project_id}/vulnerabilities", **params
        ):
            for item in _vuln_list_decoder.decode(page_bytes):
                yield item

    async def stream_for_group(
        self, group_id: int, **params: Any
    ) -> AsyncIterator[Vulnerability]:
        """Stream all vulnerabilities across a group's projects.

        Args:
            group_id: GitLab group ID
            **params: Filters: severity, state, report_type, scanner

        Yields:
            Vulnerability: Group-wide vulnerability records
        """
        async for page_bytes in self._client.paginate(
            f"/groups/{group_id}/vulnerabilities", **params
        ):
            for item in _vuln_list_decoder.decode(page_bytes):
                yield item

    async def stream_findings(
        self, project_id: int, **params: Any
    ) -> AsyncIterator[VulnerabilityFinding]:
        """Stream vulnerability findings for a project.

        Findings are lower-level scanner results; use these for
        detailed remediation workflows or SIEM ingestion.

        Args:
            project_id: GitLab project ID
            **params: Filters: severity, report_type, scanner_id

        Yields:
            VulnerabilityFinding: Detailed finding records
        """
        async for page_bytes in self._client.paginate(
            f"/projects/{project_id}/vulnerability_findings", **params
        ):
            for item in _finding_decoder.decode(page_bytes):
                yield item
