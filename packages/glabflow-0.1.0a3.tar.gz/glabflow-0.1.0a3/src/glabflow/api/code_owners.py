from __future__ import annotations

from collections.abc import AsyncIterator
from typing import TYPE_CHECKING, Any

import msgspec

from glabflow.models.code_owners import CodeOwner

if TYPE_CHECKING:
    from glabflow._client import GitLabClient


# Decoder for code_owners
_code_owners_decoder = msgspec.json.Decoder(list[CodeOwner])
_code_owners_single_decoder = msgspec.json.Decoder(CodeOwner)


class CodeOwnersAPI:
    """Async API for accessing GitLab code_owners."""

    def __init__(self, client: GitLabClient) -> None:
        self._client = client

    async def stream(self, **params: Any) -> AsyncIterator[CodeOwner]:
        """Stream all code_owners with keyset pagination.

        Args:
            **params: Additional query parameters

        Yields:
            CodeOwner: GitLab code_owners resource items
        """
        async for page_bytes in self._client.paginate("/code_owners", **params):
            for item in _code_owners_decoder.decode(page_bytes):
                yield item

    async def get(self, id: int, **params: Any) -> CodeOwner:
        """Get a specific code_owners by ID.

        Args:
            id: CodeOwner ID
            **params: Additional query parameters

        Returns:
            CodeOwner: The requested item
        """
        path = f"/code_owners/{id}"
        data = await self._client.get(path, **params)
        return _code_owners_single_decoder.decode(data)

    async def list_page(self, **params: Any) -> list[CodeOwner]:
        """List a single page of code_owners.

        Args:
            **params: Query parameters (page, per_page, etc.)

        Returns:
            list[CodeOwner]: List of items
        """
        data = await self._client.get("/code_owners", **params)
        return _code_owners_decoder.decode(data)
