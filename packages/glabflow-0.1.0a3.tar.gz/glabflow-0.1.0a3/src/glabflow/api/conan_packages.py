from __future__ import annotations

from collections.abc import AsyncIterator
from typing import TYPE_CHECKING, Any

import msgspec

from glabflow.models.conan_packages import ConanPackage

if TYPE_CHECKING:
    from glabflow._client import GitLabClient


# Decoder for conan_packages
_conan_packages_decoder = msgspec.json.Decoder(list[ConanPackage])
_conan_packages_single_decoder = msgspec.json.Decoder(ConanPackage)


class ConanPackagesAPI:
    """Async API for accessing GitLab conan_packages."""

    def __init__(self, client: GitLabClient) -> None:
        self._client = client

    async def stream(self, **params: Any) -> AsyncIterator[ConanPackage]:
        """Stream all conan_packages with keyset pagination.

        Args:
            **params: Additional query parameters

        Yields:
            ConanPackage: GitLab conan_packages resource items
        """
        async for page_bytes in self._client.paginate("/conan_packages", **params):
            for item in _conan_packages_decoder.decode(page_bytes):
                yield item

    async def get(self, id: int, **params: Any) -> ConanPackage:
        """Get a specific conan_packages by ID.

        Args:
            id: ConanPackage ID
            **params: Additional query parameters

        Returns:
            ConanPackage: The requested item
        """
        path = f"/conan_packages/{id}"
        data = await self._client.get(path, **params)
        return _conan_packages_single_decoder.decode(data)

    async def list_page(self, **params: Any) -> list[ConanPackage]:
        """List a single page of conan_packages.

        Args:
            **params: Query parameters (page, per_page, etc.)

        Returns:
            list[ConanPackage]: List of items
        """
        data = await self._client.get("/conan_packages", **params)
        return _conan_packages_decoder.decode(data)
