from __future__ import annotations

from collections.abc import AsyncIterator
from typing import TYPE_CHECKING, Any

import msgspec

from glabflow.models.approval_rules import ApprovalRule

if TYPE_CHECKING:
    from glabflow._client import GitLabClient


# Decoder for approval_rules
_approval_rules_decoder = msgspec.json.Decoder(list[ApprovalRule])
_approval_rules_single_decoder = msgspec.json.Decoder(ApprovalRule)


class ApprovalRulesAPI:
    """Async API for accessing GitLab approval_rules."""

    def __init__(self, client: GitLabClient) -> None:
        self._client = client

    async def stream(self, **params: Any) -> AsyncIterator[ApprovalRule]:
        """Stream all approval_rules with keyset pagination.

        Args:
            **params: Additional query parameters

        Yields:
            ApprovalRule: GitLab approval_rules resource items
        """
        async for page_bytes in self._client.paginate("/approval_rules", **params):
            for item in _approval_rules_decoder.decode(page_bytes):
                yield item

    async def get(self, id: int, **params: Any) -> ApprovalRule:
        """Get a specific approval_rules by ID.

        Args:
            id: ApprovalRule ID
            **params: Additional query parameters

        Returns:
            ApprovalRule: The requested item
        """
        path = f"/approval_rules/{id}"
        data = await self._client.get(path, **params)
        return _approval_rules_single_decoder.decode(data)

    async def list_page(self, **params: Any) -> list[ApprovalRule]:
        """List a single page of approval_rules.

        Args:
            **params: Query parameters (page, per_page, etc.)

        Returns:
            list[ApprovalRule]: List of items
        """
        data = await self._client.get("/approval_rules", **params)
        return _approval_rules_decoder.decode(data)
