from __future__ import annotations

from typing import TYPE_CHECKING, Any

import msgspec

from glabflow.models.dora import DoraMetric

if TYPE_CHECKING:
    from glabflow._client import GitLabClient

_dora_decoder = msgspec.json.Decoder(list[DoraMetric])


class DoraAPI:
    """Async API for GitLab DORA metrics (project and group level)."""

    def __init__(self, client: GitLabClient) -> None:
        self._client = client

    async def get_project_metrics(
        self, project_id: int, metric: str, **params: Any
    ) -> list[DoraMetric]:
        """Get DORA metrics for a project.

        Args:
            project_id: GitLab project ID
            metric: Metric name — "deployment_frequency", "lead_time_for_changes",
                    "time_to_restore_service", or "change_failure_rate"
            **params: Filters: start_date, end_date, interval ("daily" | "weekly" | "monthly")

        Returns:
            list[DoraMetric]: Time-series data points
        """
        data = await self._client.get(
            f"/projects/{project_id}/dora/metrics", metric=metric, **params
        )
        return _dora_decoder.decode(data)

    async def get_group_metrics(
        self, group_id: int, metric: str, **params: Any
    ) -> list[DoraMetric]:
        """Get DORA metrics aggregated across a group.

        Args:
            group_id: GitLab group ID
            metric: Metric name — "deployment_frequency", "lead_time_for_changes",
                    "time_to_restore_service", or "change_failure_rate"
            **params: Filters: start_date, end_date, interval

        Returns:
            list[DoraMetric]: Time-series data points
        """
        data = await self._client.get(
            f"/groups/{group_id}/dora/metrics", metric=metric, **params
        )
        return _dora_decoder.decode(data)
