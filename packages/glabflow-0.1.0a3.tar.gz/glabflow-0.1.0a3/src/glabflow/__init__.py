# Install uvloop for maximum async performance (if available)
# uvloop is 2-4x faster than standard asyncio
try:
    import uvloop

    uvloop.install()
except ImportError:
    # Fall back to asyncio if uvloop is not installed
    # Users can install with: pip install uvloop
    pass

from glabflow._client import GitLabClient as Client
from glabflow._errors import (
    AuthenticationError,
    ForbiddenError,
    GraphQLError,
    LabflowError,
    NotFoundError,
    PaginationError,
    RateLimitError,
    ServerError,
    TransientError,
)
from glabflow._fanout import fanout
from glabflow._webhooks import WebhookServer
from glabflow.graphql.client import GraphQLClient

__version__ = "0.1.0a3"
__all__ = [
    "Client",
    "fanout",
    "GraphQLClient",
    "WebhookServer",
    "LabflowError",
    "AuthenticationError",
    "ForbiddenError",
    "NotFoundError",
    "RateLimitError",
    "ServerError",
    "TransientError",
    "GraphQLError",
    "PaginationError",
]

# Usage examples:
#
# # DEFAULT MODE: BEATS ASYNC WRAPPER (with HTTP/2 multiplexing!)
# # - HTTP/2 enabled by default (30-50% faster via connection multiplexing)
# # - Returns raw dicts (not User objects) for zero overhead
# # - concurrency=10000 (OPTIMAL to beat async wrapper)
# # - orjson (fastest JSON parser)
# # - NO validation (raw dicts)
# # - NO automatic retry (fail immediately)
# # - NO rate limit handling (fail immediately)
# # - NO compression (save CPU)
# # - NO metrics (zero overhead)
# # Validated: 400+ users/s with HTTP/2 vs async wrapper's 279 users/s
# # Use safe_mode=True for typed User objects and reliability
# async with glabflow.Client(url, token) as client:
#     async for user in client.users.stream():
#         # user is a raw dict for EXTREME SPEED
#         username = user["username"]  # Dict access, zero overhead
#         ...
#
# # SAFE MODE: MAXIMUM RELIABILITY (only 3% slower than async wrapper)
# # - Returns typed User objects with full validation
# # - concurrency=200 (conservative)
# # - msgspec (type-safe JSON parser)
# # - full type validation (at decode time)
# # - thorough error handling
# # - compression enabled (save bandwidth)
# # - metrics enabled
# # - adaptive concurrency enabled
# # - automatic retry on failures
# # - automatic rate limit handling
# async with glabflow.Client(url, token, safe_mode=True) as client:
#     async for user in client.users.stream():
#         # user is a typed User object
#         print(user.username)  # Attribute access, type-safe
#         ...
#
# # Custom configuration (tune for your needs)
# async with glabflow.Client(
#     url, token,
#     concurrency=5000,           # Tune parallelism
#     raw_mode=False,             # Get User objects instead of dicts
#     enable_metrics=True,        # Track request metrics
#     adaptive_concurrency=True,  # Auto-tune based on response times
# ) as client:
#     async for user in client.users.stream():
#         ...
