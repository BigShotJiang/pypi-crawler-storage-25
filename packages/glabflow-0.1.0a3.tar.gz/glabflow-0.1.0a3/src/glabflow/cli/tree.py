"""Repository tree builder and discovery from GitLab groups."""

import fnmatch
import re
from collections.abc import AsyncIterator
from dataclasses import dataclass, field
from enum import Enum

import glabflow


class FilterMode(Enum):
    """Filter matching mode."""

    GLOB = "glob"
    REGEX = "regex"


@dataclass
class FilterConfig:
    """Configuration for repository filtering."""

    include: list[str] = field(default_factory=list)
    exclude: list[str] = field(default_factory=list)
    mode: FilterMode = FilterMode.GLOB
    no_archived: bool = False

    def _compile_pattern(self, pattern: str) -> re.Pattern | str:
        """Compile pattern based on mode."""
        if self.mode == FilterMode.REGEX:
            return re.compile(pattern)
        return pattern

    def _matches_pattern(self, path: str, pattern: str) -> bool:
        """Check if path matches a single pattern."""
        compiled = self._compile_pattern(pattern)
        if isinstance(compiled, re.Pattern):
            return bool(compiled.search(path))
        return fnmatch.fnmatch(path, compiled)

    def matches(self, path: str) -> bool:
        """Check if path matches filter configuration.

        Args:
            path: Repository path (e.g., "group/subgroup/repo")

        Returns:
            True if repository should be included
        """
        # Check exclude patterns first
        for pattern in self.exclude:
            if self._matches_pattern(path, pattern):
                return False

        # If no include patterns, include everything not excluded
        if not self.include:
            return True

        # Check include patterns
        for pattern in self.include:
            if self._matches_pattern(path, pattern):
                return True

        return False


@dataclass
class RepoInfo:
    """Repository information."""

    id: int
    name: str
    path_with_namespace: str
    http_url: str
    ssh_url: str
    archived: bool
    default_branch: str | None = None


async def discover_repos(
    client: glabflow.Client,
    group_id: int | None = None,
    filter_config: FilterConfig | None = None,
) -> AsyncIterator[RepoInfo]:
    """Discover repositories from GitLab.

    Args:
        client: GitLab client
        group_id: Optional group ID to filter by
        filter_config: Optional filter configuration

    Yields:
        RepoInfo for each matching repository
    """
    filter_config = filter_config or FilterConfig()

    async with client:
        # Stream projects
        async for project in client.projects.stream():
            # Skip archived if configured
            if filter_config.no_archived and getattr(project, "archived", False):
                continue

            # Build path for filtering
            path = getattr(project, "path_with_namespace", "")

            # Apply filter
            if not filter_config.matches(path):
                continue

            # Get URLs
            http_url = getattr(project, "http_url_to_repo", "")
            ssh_url = getattr(project, "ssh_url_to_repo", "")

            yield RepoInfo(
                id=getattr(project, "id", 0),
                name=getattr(project, "name", ""),
                path_with_namespace=path,
                http_url=http_url,
                ssh_url=ssh_url,
                archived=getattr(project, "archived", False),
                default_branch=getattr(project, "default_branch", None),
            )


async def discover_repos_by_group(
    client: glabflow.Client,
    group_name: str,
    filter_config: FilterConfig | None = None,
) -> AsyncIterator[RepoInfo]:
    """Discover repositories from a specific group.

    Args:
        client: GitLab client
        group_name: Group name or path
        filter_config: Optional filter configuration

    Yields:
        RepoInfo for each matching repository
    """
    filter_config = filter_config or FilterConfig()

    async with client:
        # Find the group
        group_id = None
        async for group in client.groups.stream():
            if getattr(group, "path", "") == group_name or str(
                getattr(group, "id", "")
            ) == group_name:
                group_id = getattr(group, "id")
                break

        if group_id is None:
            raise ValueError(f"Group not found: {group_name}")

        # Stream projects in this group
        async for project in client.projects.stream_for_group(group_id):
            # Skip archived if configured
            if filter_config.no_archived and getattr(project, "archived", False):
                continue

            # Build path for filtering
            path = getattr(project, "path_with_namespace", "")

            # Apply filter
            if not filter_config.matches(path):
                continue

            # Get URLs
            http_url = getattr(project, "http_url_to_repo", "")
            ssh_url = getattr(project, "ssh_url_to_repo", "")

            yield RepoInfo(
                id=getattr(project, "id", 0),
                name=getattr(project, "name", ""),
                path_with_namespace=path,
                http_url=http_url,
                ssh_url=ssh_url,
                archived=getattr(project, "archived", False),
                default_branch=getattr(project, "default_branch", None),
            )


@dataclass
class TreeNode:
    """Tree node for repository listing."""

    name: str
    children: dict[str, "TreeNode"] = field(default_factory=dict)
    repos: list[RepoInfo] = field(default_factory=list)

    def add_repo(self, repo: RepoInfo) -> None:
        """Add a repository to the tree.

        Args:
            repo: Repository info to add
        """
        parts = repo.path_with_namespace.split("/")
        node = self

        # Navigate/create path
        for part in parts[:-1]:
            if part not in node.children:
                node.children[part] = TreeNode(name=part)
            node = node.children[part]

        # Add repo at leaf
        node.repos.append(repo)

    def render(self, prefix: str = "", is_last: bool = True) -> str:
        """Render tree as string.

        Args:
            prefix: Current prefix string
            is_last: Whether this is the last item at this level

        Returns:
            Formatted tree string
        """
        result = ""
        connector = "└── " if is_last else "├── "

        # Add this node's name if not root
        if self.name:
            result += f"{prefix}{connector}{self.name}/\n"
            prefix += "    " if is_last else "│   "

        # Add repositories
        for i, repo in enumerate(self.repos):
            repo_is_last = i == len(self.repos) - 1 and not self.children
            result += f"{prefix}{'└── ' if repo_is_last else '├── '}{repo.name}\n"

        # Add children
        children_list = list(self.children.items())
        for i, (name, child) in enumerate(children_list):
            child_is_last = i == len(children_list) - 1
            result += child.render(prefix, child_is_last)

        return result


def build_tree(repos: list[RepoInfo]) -> TreeNode:
    """Build a tree from repository list.

    Args:
        repos: List of repository info

    Returns:
        Root tree node
    """
    root = TreeNode(name="")
    for repo in repos:
        root.add_repo(repo)
    return root


def format_tree(root: TreeNode) -> str:
    """Format tree as string for display.

    Args:
        Root tree node

    Returns:
        Formatted tree string
    """
    result = ""
    for name, child in sorted(root.children.items()):
        is_last = name == sorted(root.children.keys())[-1]
        result += child.render("", is_last)
    return result.rstrip()


def format_json(repos: list[RepoInfo]) -> str:
    """Format repositories as JSON.

    Args:
        repos: List of repository info

    Returns:
        JSON string
    """
    import json

    data = [
        {
            "id": repo.id,
            "name": repo.name,
            "path": repo.path_with_namespace,
            "http_url": repo.http_url,
            "ssh_url": repo.ssh_url,
            "archived": repo.archived,
            "default_branch": repo.default_branch,
        }
        for repo in repos
    ]
    return json.dumps(data, indent=2)


def format_text(repos: list[RepoInfo]) -> str:
    """Format repositories as plain text list.

    Args:
        repos: List of repository info

    Returns:
        Formatted text string
    """
    lines = []
    for repo in repos:
        lines.append(repo.path_with_namespace)
    return "\n".join(lines)
