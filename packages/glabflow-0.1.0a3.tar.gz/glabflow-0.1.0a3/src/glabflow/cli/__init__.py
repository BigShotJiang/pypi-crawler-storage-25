"""CLI for bulk GitLab repository operations."""

__version__ = "0.1.0"
