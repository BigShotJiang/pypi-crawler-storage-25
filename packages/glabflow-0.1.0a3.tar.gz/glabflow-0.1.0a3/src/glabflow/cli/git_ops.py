"""Git operations for clone, pull, and fetch with async concurrency control."""

import asyncio
import subprocess
from collections.abc import AsyncIterator
from dataclasses import dataclass
from pathlib import Path

import rich.repr


@dataclass
class GitResult:
    """Result of a git operation."""

    path: str
    success: bool
    url: str | None = None
    error: str | None = None
    duration: float = 0.0


@rich.repr.auto
class GitOperations:
    """Async git operations with concurrency control."""

    def __init__(self, concurrency: int = 10, timeout: int = 300) -> None:
        """Initialize git operations.

        Args:
            concurrency: Maximum concurrent git operations
            timeout: Git command timeout in seconds
        """
        self._semaphore = asyncio.Semaphore(concurrency)
        self._timeout = timeout

    async def _run_git(
        self,
        args: list[str],
        cwd: Path | None = None,
        env: dict[str, str] | None = None,
    ) -> tuple[bool, str]:
        """Run a git command asynchronously.

        Args:
            args: Git command arguments
            cwd: Working directory
            env: Environment variables

        Returns:
            Tuple of (success, output/error message)
        """
        cmd = ["git", *args]
        try:
            process = await asyncio.create_subprocess_exec(
                *cmd,
                cwd=cwd,
                env=env,
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
            )
            stdout, stderr = await asyncio.wait_for(
                process.communicate(),
                timeout=self._timeout,
            )
            if process.returncode == 0:
                return True, stdout.decode() if stdout else ""
            return False, stderr.decode() if stderr else f"Exit code: {process.returncode}"
        except TimeoutError:
            try:
                process.kill()
                await process.wait()
            except ProcessLookupError:
                pass
            return False, f"Timeout after {self._timeout}s"
        except Exception as e:
            return False, str(e)

    async def clone(
        self,
        url: str,
        path: Path,
        token: str | None = None,
        depth: int = 0,
        branch: str | None = None,
        submodules: bool = False,
    ) -> GitResult:
        """Clone a repository.

        Args:
            url: Repository URL
            path: Destination path
            token: GitLab token for authentication
            depth: Clone depth (0 for full clone)
            branch: Branch to clone
            submodules: Clone submodules recursively

        Returns:
            GitResult with operation status
        """
        import time

        async with self._semaphore:
            start = time.monotonic()
            path.parent.mkdir(parents=True, exist_ok=True)

            args = ["clone", "--progress"]
            if depth > 0:
                args.extend(["--depth", str(depth)])
            if branch:
                args.extend(["--branch", branch])
            if submodules:
                args.append("--recurse-submodules")

            # Add token to URL if provided
            if token and url.startswith("http"):
                if "://" in url:
                    scheme, rest = url.split("://", 1)
                    url = f"{scheme}://oauth2:{token}@{rest}"

            args.extend([url, str(path)])

            success, output = await self._run_git(args)
            duration = time.monotonic() - start

            return GitResult(
                path=str(path),
                success=success,
                url=url,
                error=None if success else output,
                duration=duration,
            )

    async def pull(self, path: Path, token: str | None = None) -> GitResult:
        """Pull changes in a repository.

        Args:
            path: Repository path
            token: GitLab token for authentication

        Returns:
            GitResult with operation status
        """
        import time

        async with self._semaphore:
            start = time.monotonic()

            args = ["pull"]
            env: dict[str, str] | None = None
            if token:
                env = {"GIT_ASKPASS": "echo", "GIT_USERNAME": "oauth2", "GIT_PASSWORD": token}

            success, output = await self._run_git(args, cwd=path, env=env)
            duration = time.monotonic() - start

            return GitResult(
                path=str(path),
                success=success,
                error=None if success else output,
                duration=duration,
            )

    async def fetch(self, path: Path, token: str | None = None) -> GitResult:
        """Fetch changes in a repository (no merge).

        Args:
            path: Repository path
            token: GitLab token for authentication

        Returns:
            GitResult with operation status
        """
        import time

        async with self._semaphore:
            start = time.monotonic()

            args = ["fetch", "--all"]
            env: dict[str, str] | None = None
            if token:
                env = {"GIT_ASKPASS": "echo", "GIT_USERNAME": "oauth2", "GIT_PASSWORD": token}

            success, output = await self._run_git(args, cwd=path, env=env)
            duration = time.monotonic() - start

            return GitResult(
                path=str(path),
                success=success,
                error=None if success else output,
                duration=duration,
            )

    async def clone_batch(
        self,
        repos: list[tuple[str, Path]],
        token: str | None = None,
        depth: int = 0,
        branch: str | None = None,
        submodules: bool = False,
    ) -> AsyncIterator[GitResult]:
        """Clone multiple repositories with bounded concurrency.

        Args:
            repos: List of (url, path) tuples
            token: GitLab token for authentication
            depth: Clone depth (0 for full clone)
            branch: Branch to clone
            submodules: Clone submodules recursively

        Yields:
            GitResult for each repository
        """
        tasks = [
            asyncio.create_task(
                self.clone(url, path, token, depth, branch, submodules),
            )
            for url, path in repos
        ]
        for coro in asyncio.as_completed(tasks):
            yield await coro

    async def pull_batch(
        self,
        paths: list[Path],
        token: str | None = None,
    ) -> AsyncIterator[GitResult]:
        """Pull multiple repositories with bounded concurrency.

        Args:
            paths: List of repository paths
            token: GitLab token for authentication

        Yields:
            GitResult for each repository
        """
        tasks = [
            asyncio.create_task(self.pull(path, token))
            for path in paths
        ]
        for coro in asyncio.as_completed(tasks):
            yield await coro

    async def fetch_batch(
        self,
        paths: list[Path],
        token: str | None = None,
    ) -> AsyncIterator[GitResult]:
        """Fetch multiple repositories with bounded concurrency.

        Args:
            paths: List of repository paths
            token: GitLab token for authentication

        Yields:
            GitResult for each repository
        """
        tasks = [
            asyncio.create_task(self.fetch(path, token))
            for path in paths
        ]
        for coro in asyncio.as_completed(tasks):
            yield await coro
