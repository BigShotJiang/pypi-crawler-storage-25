"""CLI for bulk GitLab repository operations."""

import asyncio
import os
import sys
from pathlib import Path

import click
from rich.console import Console
from rich.progress import (
    BarColumn,
    Progress,
    SpinnerColumn,
    TaskProgressColumn,
    TextColumn,
    TimeElapsedColumn,
    TimeRemainingColumn,
)

from glabflow.cli.git_ops import GitOperations
from glabflow.cli.tree import (
    FilterConfig,
    FilterMode,
    RepoInfo,
    build_tree,
    discover_repos,
    discover_repos_by_group,
    format_json,
    format_text,
    format_tree,
)

console = Console()


def get_env_var(name: str, required: bool = False) -> str | None:
    """Get environment variable."""
    value = os.environ.get(name)
    if required and not value:
        raise click.BadParameter(f"Environment variable {name} is required")
    return value


@click.group()
@click.version_option(version="0.1.0", prog_name="glabflow")
def main() -> None:
    """glabflow - Bulk GitLab repository operations.

    A high-performance CLI tool for cloning, pulling, and managing
    multiple GitLab repositories. Drop-in replacement for gitlabber
    with 5-10x better performance.
    """
    pass


@main.command()
@click.argument("destination", type=click.Path())
@click.option(
    "-t",
    "--token",
    envvar="GITLAB_TOKEN",
    required=True,
    help="GitLab private token (or set GITLAB_TOKEN)",
)
@click.option(
    "-u",
    "--url",
    envvar="GITLAB_URL",
    default="https://gitlab.com",
    show_default=True,
    help="GitLab URL (or set GITLAB_URL)",
)
@click.option(
    "-g",
    "--group",
    "group_name",
    help="Group name or ID to clone from",
)
@click.option(
    "-c",
    "--concurrency",
    type=int,
    default=10,
    show_default=True,
    help="Concurrent git operations",
)
@click.option(
    "--api-concurrency",
    type=int,
    default=100,
    show_default=True,
    help="Concurrent API requests",
)
@click.option(
    "--depth",
    type=int,
    default=0,
    show_default=True,
    help="Clone depth (0 for full)",
)
@click.option(
    "--branch",
    help="Branch to clone",
)
@click.option(
    "--submodules",
    is_flag=True,
    help="Clone submodules",
)
@click.option(
    "--no-namespace",
    is_flag=True,
    help="Flat directory structure",
)
@click.option(
    "--timeout",
    type=int,
    default=300,
    show_default=True,
    help="Git timeout in seconds",
)
@click.option(
    "--include",
    "include_patterns",
    multiple=True,
    help="Include patterns (glob or regex)",
)
@click.option(
    "--exclude",
    "exclude_patterns",
    multiple=True,
    help="Exclude patterns (glob or regex)",
)
@click.option(
    "--regex",
    "use_regex",
    is_flag=True,
    help="Use regex for patterns",
)
@click.option(
    "--no-archived",
    is_flag=True,
    help="Skip archived projects",
)
@click.option(
    "-v",
    "--verbose",
    is_flag=True,
    help="Verbose output",
)
def clone(
    destination: str,
    token: str,
    url: str,
    group_name: str | None,
    concurrency: int,
    api_concurrency: int,
    depth: int,
    branch: str | None,
    submodules: bool,
    no_namespace: bool,
    timeout: int,
    include_patterns: tuple[str, ...],
    exclude_patterns: tuple[str, ...],
    use_regex: bool,
    no_archived: bool,
    verbose: bool,
) -> None:
    """Clone repositories from GitLab.

    DESTINATION is the directory where repositories will be cloned.

    Examples:

    \b
        # Clone all repos from a group
        glabflow clone -t TOKEN -u URL -g mygroup ./clones

        # Clone with filtering
        glabflow clone -t TOKEN -g group --include "*/backend/*" ./clones

        # Clone with shallow depth
        glabflow clone -t TOKEN -g group --depth 1 ./clones
    """
    import glabflow

    # Build filter config
    filter_config = FilterConfig(
        include=list(include_patterns),
        exclude=list(exclude_patterns),
        mode=FilterMode.REGEX if use_regex else FilterMode.GLOB,
        no_archived=no_archived,
    )

    dest_path = Path(destination)

    async def run() -> int:
        # Discover repositories
        console.print("[bold]Discovering repositories...[/bold]")

        repos: list[RepoInfo] = []
        try:
            async with glabflow.Client(url, token, concurrency=api_concurrency) as client:
                if group_name:
                    async for repo in discover_repos_by_group(
                        client, group_name, filter_config
                    ):
                        repos.append(repo)
                else:
                    async for repo in discover_repos(client, filter_config=filter_config):
                        repos.append(repo)
        except Exception as e:
            console.print(f"[red]Error discovering repositories: {e}[/red]")
            return 1

        if not repos:
            console.print("[yellow]No repositories found matching criteria[/yellow]")
            return 0

        console.print(f"[green]Found {len(repos)} repositories[/green]")

        # Clone repositories
        git_ops = GitOperations(concurrency=concurrency, timeout=timeout)

        # Prepare clone tasks
        clone_tasks: list[tuple[str, Path]] = []
        for repo in repos:
            if no_namespace:
                path = dest_path / repo.name
            else:
                path = dest_path / repo.path_with_namespace
            clone_tasks.append((repo.http_url, path))

        # Clone with progress
        success_count = 0
        fail_count = 0
        total_time = 0.0

        with Progress(
            SpinnerColumn(),
            TextColumn("[progress.description]{task.description}"),
            BarColumn(),
            TaskProgressColumn(),
            TimeElapsedColumn(),
            TimeRemainingColumn(),
            console=console,
        ) as progress:
            task = progress.add_task(
                f"Cloning {len(clone_tasks)} repositories...",
                total=len(clone_tasks),
            )

            async for result in git_ops.clone_batch(
                clone_tasks,
                token=token if not url.startswith("http://") or not url.startswith("https://") else None,
                depth=depth,
                branch=branch,
                submodules=submodules,
            ):
                total_time += result.duration
                if result.success:
                    success_count += 1
                    if verbose:
                        console.print(
                            f"[green]✓[/green] {result.path} ({result.duration:.1f}s)"
                        )
                else:
                    fail_count += 1
                    console.print(
                        f"[red]✗[/red] {result.path}: {result.error}"
                    )
                progress.advance(task)

        # Summary
        console.print()
        console.print("[bold]Summary:[/bold]")
        console.print(f"  Cloned: {success_count}/{len(repos)}")
        if fail_count > 0:
            console.print(f"  Failed: {fail_count}")
        console.print(f"  Total time: {total_time:.1f}s")
        console.print(f"  Rate: {len(repos) / total_time:.1f} repos/second")

        return 0 if fail_count == 0 else 1

    return asyncio.run(run())


@main.command()
@click.argument("directory", type=click.Path(exists=True))
@click.option(
    "-t",
    "--token",
    envvar="GITLAB_TOKEN",
    help="GitLab private token (or set GITLAB_TOKEN)",
)
@click.option(
    "-c",
    "--concurrency",
    type=int,
    default=10,
    show_default=True,
    help="Concurrent git operations",
)
@click.option(
    "--timeout",
    type=int,
    default=300,
    show_default=True,
    help="Git timeout in seconds",
)
@click.option(
    "-v",
    "--verbose",
    is_flag=True,
    help="Verbose output",
)
def pull(
    directory: str,
    token: str | None,
    concurrency: int,
    timeout: int,
    verbose: bool,
) -> None:
    """Pull changes in cloned repositories.

    DIRECTORY is the root directory containing cloned repositories.

    Examples:

    \b
        # Pull all repos in directory
        glabflow pull -t TOKEN ./clones

        # Pull with higher concurrency
        glabflow pull -t TOKEN ./clones -c 20
    """
    dest_path = Path(directory)

    # Find all git repositories
    repos = list(dest_path.rglob(".git"))

    if not repos:
        console.print("[yellow]No repositories found[/yellow]")
        return

    async def run() -> int:
        git_ops = GitOperations(concurrency=concurrency, timeout=timeout)

        success_count = 0
        fail_count = 0
        total_time = 0.0

        with Progress(
            SpinnerColumn(),
            TextColumn("[progress.description]{task.description}"),
            BarColumn(),
            TaskProgressColumn(),
            TimeElapsedColumn(),
            TimeRemainingColumn(),
            console=console,
        ) as progress:
            task = progress.add_task(
                f"Pulling {len(repos)} repositories...",
                total=len(repos),
            )

            paths = [repo.parent for repo in repos]
            async for result in git_ops.pull_batch(paths, token=token):
                total_time += result.duration
                if result.success:
                    success_count += 1
                    if verbose:
                        console.print(
                            f"[green]✓[/green] {result.path} ({result.duration:.1f}s)"
                        )
                else:
                    fail_count += 1
                    console.print(
                        f"[red]✗[/red] {result.path}: {result.error}"
                    )
                progress.advance(task)

        # Summary
        console.print()
        console.print("[bold]Summary:[/bold]")
        console.print(f"  Pulled: {success_count}/{len(repos)}")
        if fail_count > 0:
            console.print(f"  Failed: {fail_count}")
        console.print(f"  Total time: {total_time:.1f}s")

        return 0 if fail_count == 0 else 1

    return asyncio.run(run())


@main.command()
@click.argument("directory", type=click.Path(exists=True))
@click.option(
    "-t",
    "--token",
    envvar="GITLAB_TOKEN",
    help="GitLab private token (or set GITLAB_TOKEN)",
)
@click.option(
    "-c",
    "--concurrency",
    type=int,
    default=10,
    show_default=True,
    help="Concurrent git operations",
)
@click.option(
    "--timeout",
    type=int,
    default=300,
    show_default=True,
    help="Git timeout in seconds",
)
@click.option(
    "-v",
    "--verbose",
    is_flag=True,
    help="Verbose output",
)
def fetch(
    directory: str,
    token: str | None,
    concurrency: int,
    timeout: int,
    verbose: bool,
) -> None:
    """Fetch changes in cloned repositories (no merge).

    DIRECTORY is the root directory containing cloned repositories.

    Examples:

    \b
        # Fetch all repos in directory
        glabflow fetch -t TOKEN ./clones
    """
    dest_path = Path(directory)

    # Find all git repositories
    repos = list(dest_path.rglob(".git"))

    if not repos:
        console.print("[yellow]No repositories found[/yellow]")
        return

    async def run() -> int:
        git_ops = GitOperations(concurrency=concurrency, timeout=timeout)

        success_count = 0
        fail_count = 0
        total_time = 0.0

        with Progress(
            SpinnerColumn(),
            TextColumn("[progress.description]{task.description}"),
            BarColumn(),
            TaskProgressColumn(),
            TimeElapsedColumn(),
            TimeRemainingColumn(),
            console=console,
        ) as progress:
            task = progress.add_task(
                f"Fetching {len(repos)} repositories...",
                total=len(repos),
            )

            paths = [repo.parent for repo in repos]
            async for result in git_ops.fetch_batch(paths, token=token):
                total_time += result.duration
                if result.success:
                    success_count += 1
                    if verbose:
                        console.print(
                            f"[green]✓[/green] {result.path} ({result.duration:.1f}s)"
                        )
                else:
                    fail_count += 1
                    console.print(
                        f"[red]✗[/red] {result.path}: {result.error}"
                    )
                progress.advance(task)

        # Summary
        console.print()
        console.print("[bold]Summary:[/bold]")
        console.print(f"  Fetched: {success_count}/{len(repos)}")
        if fail_count > 0:
            console.print(f"  Failed: {fail_count}")
        console.print(f"  Total time: {total_time:.1f}s")

        return 0 if fail_count == 0 else 1

    return asyncio.run(run())


@main.command()
@click.option(
    "-t",
    "--token",
    envvar="GITLAB_TOKEN",
    required=True,
    help="GitLab private token (or set GITLAB_TOKEN)",
)
@click.option(
    "-u",
    "--url",
    envvar="GITLAB_URL",
    default="https://gitlab.com",
    show_default=True,
    help="GitLab URL (or set GITLAB_URL)",
)
@click.option(
    "-g",
    "--group",
    "group_name",
    help="Group name or ID to list from",
)
@click.option(
    "--include",
    "include_patterns",
    multiple=True,
    help="Include patterns (glob or regex)",
)
@click.option(
    "--exclude",
    "exclude_patterns",
    multiple=True,
    help="Exclude patterns (glob or regex)",
)
@click.option(
    "--regex",
    "use_regex",
    is_flag=True,
    help="Use regex for patterns",
)
@click.option(
    "--no-archived",
    is_flag=True,
    help="Skip archived projects",
)
@click.option(
    "--format",
    "output_format",
    type=click.Choice(["text", "json", "tree"]),
    default="text",
    show_default=True,
    help="Output format",
)
def list(
    token: str,
    url: str,
    group_name: str | None,
    include_patterns: tuple[str, ...],
    exclude_patterns: tuple[str, ...],
    use_regex: bool,
    no_archived: bool,
    output_format: str,
) -> None:
    """List repositories from GitLab.

    Examples:

    \b
        # List all repos as text
        glabflow list -t TOKEN -u URL -g group

        # List as JSON
        glabflow list -t TOKEN -g group --format json

        # List as tree
        glabflow list -t TOKEN -g group --format tree

        # List with filtering
        glabflow list -t TOKEN -g group --include "*/backend/*"
    """
    import glabflow

    # Build filter config
    filter_config = FilterConfig(
        include=list(include_patterns),
        exclude=list(exclude_patterns),
        mode=FilterMode.REGEX if use_regex else FilterMode.GLOB,
        no_archived=no_archived,
    )

    async def run() -> None:
        repos: list[RepoInfo] = []
        try:
            async with glabflow.Client(url, token) as client:
                if group_name:
                    async for repo in discover_repos_by_group(
                        client, group_name, filter_config
                    ):
                        repos.append(repo)
                else:
                    async for repo in discover_repos(client, filter_config=filter_config):
                        repos.append(repo)
        except Exception as e:
            console.print(f"[red]Error: {e}[/red]")
            sys.exit(1)

        if not repos:
            console.print("[yellow]No repositories found[/yellow]")
            return

        # Format output
        if output_format == "json":
            console.print(format_json(repos))
        elif output_format == "tree":
            tree = build_tree(repos)
            console.print(format_tree(tree))
        else:
            console.print(format_text(repos))

        console.print(f"\n[bold]Total:[/bold] {len(repos)} repositories")

    asyncio.run(run())


if __name__ == "__main__":
    main()
