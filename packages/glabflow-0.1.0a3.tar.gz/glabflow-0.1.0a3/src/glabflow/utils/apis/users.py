from __future__ import annotations

import msgspec

from glabflow._errors import NotFoundError


def _to_dict(obj):
    if isinstance(obj, msgspec.Struct):
        return msgspec.to_builtins(obj)
    return obj


class GraphQLUserMixin:
    """Base mixin for GraphQL-based user resource fetching."""

    SORT_MAPS = {
        "issues": {
            "created_desc": "CREATED_DESC",
            "created_asc": "CREATED_ASC",
            "updated_desc": "UPDATED_DESC",
            "updated_asc": "UPDATED_ASC",
            "closed_at": "CLOSED_AT_DESC",
            "due_date": "DUE_DATE_ASC",
        },
        "mrs": {
            "created_desc": "CREATED_DESC",
            "created_asc": "CREATED_ASC",
            "updated_desc": "UPDATED_DESC",
            "updated_asc": "UPDATED_ASC",
            "merged_at": "MERGED_AT_DESC",
        },
    }

    def __init__(self, client):
        self._client = client

    async def _execute_user_query(
        self,
        query: str,
        variables: dict,
        resource_key: str,
        transform_fn=None,
    ) -> list[dict]:
        """Execute GraphQL query for user resources."""
        result = await self._client.graphql.execute(query, variables=variables)
        data = result.get("data", {}).get("user", {})
        if not data:
            return []

        nodes = data.get(resource_key, {}).get("nodes", [])
        if transform_fn:
            return [transform_fn(n) for n in nodes]
        return nodes

    def _build_label_filter(self, labels: list | None) -> str:
        if not labels:
            return ""
        label_strs = [f'"{label}"' for label in labels]
        return f", label: [{', '.join(label_strs)}]"

    def _build_sort(self, sort_by: str, resource: str) -> str:
        sort_map = self.SORT_MAPS.get(resource, {})
        return sort_map.get(sort_by, list(sort_map.values())[0])


class UsersAPI(GraphQLUserMixin):
    """GraphQL-first methods for GitLab users."""

    def __init__(self, client):
        super().__init__(client)

    async def list(self) -> list[dict]:
        """List users (single page)."""
        users = await self._client.users.list_page()
        return [_to_dict(u) for u in users]

    async def list_all_async(self) -> list[dict]:
        """Fetch all users (uses stream internally)."""
        users = []
        async for user in self._client.users.stream():
            users.append(_to_dict(user))
        return users

    async def get_by_username(self, username: str) -> dict:
        """Get a user by username using GraphQL."""
        query = """
        query($username: String!) {
            user(username: $username) {
                id
                username
                name
                email
                avatarUrl
                webUrl
                state
                createdAt
                isAdmin
                biography
                location
                organizations { nodes { name } }
            }
        }
        """
        result = await self._client.graphql.execute(
            query, variables={"username": username}
        )
        user = result.get("data", {}).get("user", {})
        if not user:
            raise NotFoundError(f"User '{username}' not found.")
        return user

    async def get_by_userid(self, user_id: int) -> dict:
        """Get a user by ID."""
        return _to_dict(await self._client.users.get(user_id))

    async def get_user_project_count(self, user_id: int) -> int:
        """Get user's project count via REST."""
        data = self._client._decode_json(
            await self._client.get(f"/users/{user_id}/associations_count")
        )
        return data.get("projects_count", 0)

    async def get_user_group_count(self, user_id: int) -> int:
        """Get user's group count via REST."""
        data = self._client._decode_json(
            await self._client.get(f"/users/{user_id}/associations_count")
        )
        return data.get("groups_count", 0)

    async def get_user_issue_count(self, user_id: int) -> int:
        """Get user's issue count via REST."""
        data = self._client._decode_json(
            await self._client.get(f"/users/{user_id}/associations_count")
        )
        return data.get("issues_count", 0)

    async def get_user_mr_count(self, user_id: int) -> int:
        """Get user's MR count via REST."""
        data = self._client._decode_json(
            await self._client.get(f"/users/{user_id}/associations_count")
        )
        return data.get("merge_requests_count", 0)

    async def bulk_associations_count_async(
        self, user_ids: list[int], concurrency: int = 50
    ) -> dict[int, dict]:
        """Fetch associations_count for many users concurrently via REST."""
        import asyncio

        sem = asyncio.Semaphore(concurrency)

        async def fetch_one(user_id: int) -> tuple[int, dict]:
            async with sem:
                data = self._client._decode_json(
                    await self._client.get(f"/users/{user_id}/associations_count")
                )
                return user_id, data

        outcomes = await asyncio.gather(
            *[fetch_one(uid) for uid in user_ids],
            return_exceptions=True,
        )

        return {
            uid: data
            for outcome in outcomes
            if not isinstance(outcome, BaseException)
            for uid, data in [outcome]
        }

    async def get_user_projects(self, username: str) -> dict[str, list[dict]]:
        """Fetch user's projects (personal + contributed) using GraphQL."""
        query = """
        query($username: String!) {
            user(username: $username) {
                projects { nodes { id name nameWithNamespace path fullPath visibility archived createdAt namespace { kind fullPath } } }
                contributedProjects { nodes { id name nameWithNamespace path fullPath visibility archived createdAt namespace { kind fullPath } } }
            }
        }
        """
        result = await self._client.graphql.execute(
            query, variables={"username": username}
        )
        data = result.get("data", {}).get("user", {})
        if not data:
            return {"personal": [], "contributed": [], "all": []}

        personal = [
            p
            for p in data.get("projects", {}).get("nodes", [])
            if p.get("namespace", {}).get("kind") == "user"
        ]
        contributed = [
            p
            for p in data.get("projects", {}).get("nodes", [])
            if p.get("namespace", {}).get("kind") != "user"
        ]
        contributed.extend(data.get("contributedProjects", {}).get("nodes", []))

        return {
            "personal": personal,
            "contributed": contributed,
            "all": personal + contributed,
        }

    async def get_user_issues(
        self,
        username: str,
        state: str = "opened",
        labels: list | None = None,
        sort_by: str = "created_desc",
        include_milestone: bool = True,
        include_time_stats: bool = True,
    ) -> list[dict]:
        """Fetch user's issues with filtering/sorting using GraphQL."""
        labels_filter = self._build_label_filter(labels)
        sort_value = self._build_sort(sort_by, "issues")

        query = f"""
        query($username: String!, $state: IssueState) {{
            user(username: $username) {{
                issues(state: $state, sort: {sort_value}{labels_filter}) {{
                    nodes {{
                        id title description state webUrl createdAt updatedAt closedAt dueDate
                        labels {{ nodes {{ title color }} }}
                        project {{ id fullPath name }}
                        author {{ id username name avatarUrl }}
                        assignees {{ nodes {{ id username name avatarUrl }} }}
                        milestone {{ id title state dueDate }}
                        timeStats {{ humanTimeEstimate humanTotalTimeSpent timeEstimate totalTimeSpent }}
                        userNotesCount upvoteCount
                        linkedMergeRequests {{ nodes {{ id title state webUrl }} }}
                    }}
                }}
            }}
        }}
        """
        result = await self._client.graphql.execute(
            query, variables={"username": username, "state": state.upper()}
        )

        issues = []
        for issue in (
            result.get("data", {}).get("user", {}).get("issues", {}).get("nodes", [])
        ):
            issue_data = {
                "id": issue.get("id"),
                "title": issue.get("title"),
                "description": issue.get("description"),
                "state": issue.get("state"),
                "web_url": issue.get("webUrl"),
                "created_at": issue.get("createdAt"),
                "updated_at": issue.get("updatedAt"),
                "closed_at": issue.get("closedAt"),
                "due_date": issue.get("dueDate"),
                "labels": issue.get("labels", {}).get("nodes", []),
                "project": issue.get("project"),
                "author": issue.get("author"),
                "assignees": [
                    a.get("username")
                    for a in issue.get("assignees", {}).get("nodes", [])
                ],
                "user_notes_count": issue.get("userNotesCount", 0),
                "upvote_count": issue.get("upvoteCount", 0),
                "linked_mrs": issue.get("linkedMergeRequests", {}).get("nodes", []),
            }
            if include_milestone:
                issue_data["milestone"] = issue.get("milestone")
            if include_time_stats:
                issue_data["time_stats"] = issue.get("timeStats", {})
            issues.append(issue_data)

        return issues

    async def get_user_mrs(
        self,
        username: str,
        state: str = "opened",
        labels: list | None = None,
        sort_by: str = "created_desc",
        include_diff_stats: bool = True,
        include_approval_state: bool = True,
    ) -> list[dict]:
        """Fetch user's MRs with filtering/sorting/approval using GraphQL."""
        labels_filter = self._build_label_filter(labels)
        sort_value = self._build_sort(sort_by, "mrs")

        query = f"""
        query($username: String!, $state: MergeRequestState) {{
            user(username: $username) {{
                mergeRequests(state: $state, sort: {sort_value}{labels_filter}) {{
                    nodes {{
                        id title description state draft webUrl createdAt updatedAt mergedAt closedAt
                        labels {{ nodes {{ title }} }}
                        project {{ id fullPath name }}
                        author {{ id username name avatarUrl }}
                        reviewers {{ nodes {{ id username name avatarUrl reviewedBy {{ nodes {{ state }} }} }} }}
                        pipelines(first: 1) {{ nodes {{ id status createdAt finishedAt duration }} }}
                        diffRefs {{ headSha baseSha }}
                        userNotesCount
                        linkedIssues(first: 5) {{ nodes {{ id title webUrl }} }}
                        approvals {{ approved approvalsRequired approvalsLeft userHasApproved userCanApprove }}
                    }}
                }}
            }}
        }}
        """
        result = await self._client.graphql.execute(
            query, variables={"username": username, "state": state.upper()}
        )

        mrs = []
        for mr in (
            result.get("data", {})
            .get("user", {})
            .get("mergeRequests", {})
            .get("nodes", [])
        ):
            pipelines = mr.get("pipelines", {}).get("nodes", [])
            pipeline = pipelines[0] if pipelines else {}

            reviewers = []
            for r in mr.get("reviewers", {}).get("nodes", []):
                reviewed_by = r.get("reviewedBy", {}).get("nodes", [])
                reviewers.append(
                    {
                        "id": r.get("id"),
                        "username": r.get("username"),
                        "name": r.get("name"),
                        "avatar_url": r.get("avatarUrl"),
                        "approval_state": reviewed_by[0].get("state")
                        if reviewed_by
                        else None,
                    }
                )

            mr_data = {
                "id": mr.get("id"),
                "title": mr.get("title"),
                "description": mr.get("description"),
                "state": mr.get("state"),
                "draft": mr.get("draft"),
                "web_url": mr.get("webUrl"),
                "created_at": mr.get("createdAt"),
                "updated_at": mr.get("updatedAt"),
                "merged_at": mr.get("mergedAt"),
                "closed_at": mr.get("closedAt"),
                "labels": [
                    label.get("title")
                    for label in mr.get("labels", {}).get("nodes", [])
                ],
                "project": mr.get("project"),
                "author": mr.get("author"),
                "reviewers": reviewers,
                "user_notes_count": mr.get("userNotesCount", 0),
                "linked_issues": mr.get("linkedIssues", {}).get("nodes", []),
                "pipeline": {
                    "id": pipeline.get("id"),
                    "status": pipeline.get("status"),
                    "created_at": pipeline.get("createdAt"),
                    "finished_at": pipeline.get("finishedAt"),
                    "duration": pipeline.get("duration"),
                }
                if pipeline
                else None,
            }

            if include_approval_state:
                approvals = mr.get("approvals", {})
                mr_data["approval_state"] = {
                    "approved": approvals.get("approved"),
                    "approvals_required": approvals.get("approvalsRequired"),
                    "approvals_left": approvals.get("approvalsLeft"),
                    "user_has_approved": approvals.get("userHasApproved"),
                    "user_can_approve": approvals.get("userCanApprove"),
                }

            mrs.append(mr_data)

        return mrs
