class GroupsAPI:
    """GraphQL-first methods for GitLab groups."""

    def __init__(self, client):
        self._client = client

    async def get_user_groups(self, username: str) -> list[dict]:
        """Fetch user's groups with member counts using GraphQL."""
        query = """
        query($username: String!) {
            user(username: $username) {
                groupMemberships {
                    nodes {
                        group {
                            id
                            name
                            fullPath
                            visibility
                            stats { members }
                        }
                    }
                }
            }
        }
        """
        result = await self._client.graphql.execute(
            query, variables={"username": username}
        )

        groups = []
        for m in (
            result.get("data", {})
            .get("user", {})
            .get("groupMemberships", {})
            .get("nodes", [])
        ):
            g = m.get("group", {})
            groups.append(
                {
                    "id": g.get("id"),
                    "name": g.get("name"),
                    "full_path": g.get("fullPath"),
                    "visibility": g.get("visibility"),
                    "members": g.get("stats", {}).get("members", 0),
                }
            )

        return groups
