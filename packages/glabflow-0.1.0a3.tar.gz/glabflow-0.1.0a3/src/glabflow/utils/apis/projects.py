import msgspec

from glabflow._errors import NotFoundError


def _to_dict(obj):
    if isinstance(obj, msgspec.Struct):
        return msgspec.to_builtins(obj)
    return obj


class ProjectsAPI:
    """Convenience methods for GitLab projects - uses glabflow.Client internally."""

    def __init__(self, client):
        self._client = client

    async def list(self) -> list[dict]:
        """List projects (single page)."""
        projects = await self._client.projects.list_page()
        return [_to_dict(p) for p in projects]

    async def list_all_async(self) -> list[dict]:
        """Fetch all projects (uses stream internally)."""
        projects = []
        async for project in self._client.projects.stream():
            projects.append(_to_dict(project))
        return projects

    async def get(self, project_id: int) -> dict:
        """Get a project by ID."""
        return _to_dict(await self._client.projects.get(project_id))

    async def get_by_path(self, path: str) -> dict:
        """Get a project by path (e.g., 'namespace/project')."""
        from urllib.parse import quote

        r = await self._client.get(f"/projects/{quote(path, safe='')}")
        data = self._client._decode_json(r)
        if not data:
            raise NotFoundError(f"Project '{path}' not found.")
        return data

    async def search(self, query: str) -> list[dict]:
        """Search for projects by name."""
        projects = []
        async for page in self._client.paginate(
            "/projects",
            params={"search": query, "simple": "true", "per_page": 20},
        ):
            data = self._client._decode_json(page)
            if data:
                projects.extend(data)
        return projects
