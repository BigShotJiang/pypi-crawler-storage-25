import asyncio
from datetime import UTC, datetime, timedelta, timezone

import dateutil.parser


class CommitsAPI:
    """Convenience methods for GitLab commits - uses glabflow.Client internally."""

    def __init__(self, client):
        self._client = client

    async def get_user_commits(
        self,
        user: dict,
        projects: list[dict],
        since: str | None = None,
        until: str | None = None,
    ) -> tuple[list[dict], dict[int, int], dict]:
        """
        Fetch commits for a user across given projects concurrently.

        Returns:
            - all_commits: List of unique commit dicts
            - project_commit_counts: Dict {project_id: count}
            - stats: Dict {morning_commits, afternoon_commits, total}
        """
        author_name = user.get("name", "")
        author_email = user.get("email", "")
        username = user.get("username", "")

        ist = timezone(timedelta(hours=5, minutes=30))

        morn_start = datetime.strptime("09:00", "%H:%M").time()
        morn_end = datetime.strptime("12:29", "%H:%M").time()
        aft_start = datetime.strptime("12:30", "%H:%M").time()
        aft_end = datetime.strptime("17:00", "%H:%M").time()

        stats = {"total": 0, "morning_commits": 0, "afternoon_commits": 0}
        all_commits = []
        project_commit_counts = {}
        seen_shas = set()

        async def fetch_project_commits(project: dict) -> dict:
            pid = project.get("id")
            pname = project.get("name_with_namespace", project.get("name", ""))
            commits = []
            count = 0

            try:
                search_term = author_email or author_name or username
                if not search_term:
                    return {"pid": pid, "commits": [], "count": 0, "error": None}

                params = {"all": True, "with_stats": "false"}
                if since:
                    params["since"] = since
                if until:
                    params["until"] = until

                project_commits = []
                async for page in self._client.paginate(
                    f"/projects/{pid}/repository/commits",
                    params=params,
                    per_page=100,
                ):
                    data = self._client._decode_json(page)
                    if data:
                        project_commits.extend(data)

                project_seen_shas = set()
                for c in project_commits:
                    sha = c.get("id")
                    if not sha or sha in project_seen_shas:
                        continue

                    c_author_name = (c.get("author_name", "") or "").lower()
                    c_author_email = (c.get("author_email", "") or "").lower()

                    is_match = False
                    if author_email and c_author_email == author_email.lower():
                        is_match = True
                    elif author_name and c_author_name == author_name.lower():
                        is_match = True
                    elif username and c_author_email.startswith(f"{username.lower()}@"):
                        is_match = True
                    elif username and username.lower() in c_author_name.lower():
                        is_match = True
                    elif author_email:
                        email_local = author_email.split("@")[0].lower()
                        if (
                            email_local in c_author_email.lower()
                            or email_local in c_author_name.lower()
                        ):
                            is_match = True

                    if not is_match:
                        continue

                    project_seen_shas.add(sha)
                    count += 1
                    commits.append(
                        {
                            "sha": sha,
                            "pname": pname,
                            "title": c.get("title"),
                            "created_at": c.get("created_at"),
                            "author_name": c.get("author_name"),
                            "short_id": c.get("short_id"),
                            "web_url": c.get("web_url"),
                        }
                    )

            except Exception as e:
                return {"pid": pid, "commits": [], "count": 0, "error": str(e)}

            return {"pid": pid, "commits": commits, "count": count, "error": None}

        semaphore = asyncio.Semaphore(10)
        tasks = [fetch_project_commits(p) for p in projects]

        async def run_with_sem(t):
            async with semaphore:
                return await t

        results = await asyncio.gather(*[run_with_sem(t) for t in tasks])

        for res in results:
            pid = res["pid"]
            project_commit_counts[pid] = res["count"]

            if res["error"]:
                continue

            for c in res["commits"]:
                sha = c["sha"]
                if sha in seen_shas:
                    continue
                seen_shas.add(sha)
                stats["total"] += 1

                created_at_str = c["created_at"]
                try:
                    dt = dateutil.parser.isoparse(created_at_str)
                    if dt.tzinfo is None:
                        dt = dt.replace(tzinfo=UTC)
                    dt_ist = dt.astimezone(ist)

                    time_obj = dt_ist.time()

                    slot = "Other"
                    if morn_start <= time_obj <= morn_end:
                        slot = "Morning"
                        stats["morning_commits"] += 1
                    elif aft_start <= time_obj <= aft_end:
                        slot = "Afternoon"
                        stats["afternoon_commits"] += 1

                    date_str = dt_ist.strftime("%Y-%m-%d")
                    time_str = dt_ist.strftime("%I:%M %p")

                except Exception:
                    date_str = created_at_str
                    time_str = "N/A"
                    slot = "N/A"

                all_commits.append(
                    {
                        "project_name": c["pname"],
                        "message": c["title"],
                        "date": date_str,
                        "time": time_str,
                        "slot": slot,
                        "author_name": c["author_name"],
                        "short_id": c["short_id"],
                        "web_url": c["web_url"],
                    }
                )

        return all_commits, project_commit_counts, stats
