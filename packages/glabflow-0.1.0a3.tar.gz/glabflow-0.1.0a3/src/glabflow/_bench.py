"""
Shared benchmark utilities for glabflow.

This module provides common functionality for all benchmark scripts:
- Data classes for results and configuration
- Timing and measurement utilities
- Mock server lifecycle management
- Result formatting

Usage:
    from glabflow._bench import (
        BenchmarkResult,
        BenchmarkConfig,
        ClientConfig,
        BenchmarkRunner,
        format_benchmark_table,
        get_mock_server,
    )
"""

from __future__ import annotations

import asyncio
import json
import os
import time
import tracemalloc
from collections.abc import AsyncGenerator, Callable, Coroutine
from contextlib import asynccontextmanager
from dataclasses import asdict, dataclass, field
from enum import StrEnum
from pathlib import Path
from typing import Any, Protocol, TypeVar

__all__ = [
    "BenchmarkResult",
    "BenchmarkConfig",
    "ClientConfig",
    "BenchmarkMetrics",
    "ComparisonResult",
    "OutputFormat",
    "BenchmarkRunner",
    "BenchmarkFunc",
    "format_benchmark_table",
    "format_text_results",
    "format_json_results",
    "format_csv_results",
    "calculate_speedup",
    "get_mock_server",
    "wait_for_server",
    "create_labflow_client",
    "get_client_config",
]

DEFAULT_GITLAB_URL = "http://localhost:8765"
DEFAULT_GITLAB_TOKEN = "test-token"
DEFAULT_PORT = 8765


# =============================================================================
# Configuration
# =============================================================================


@dataclass
class ClientConfig:
    """Configuration for glabflow client."""

    base_url: str = DEFAULT_GITLAB_URL
    token: str = DEFAULT_GITLAB_TOKEN
    concurrency: int = 100
    enable_compression: bool = True
    adaptive_concurrency: bool = False
    timeout: float = 30.0

    @classmethod
    def from_env(cls) -> ClientConfig:
        """Create config from environment variables."""
        return cls(
            base_url=os.environ.get("GITLAB_URL", DEFAULT_GITLAB_URL),
            token=os.environ.get("GITLAB_TOKEN", DEFAULT_GITLAB_TOKEN),
            concurrency=int(os.environ.get("GITLAB_CONCURRENCY", "100")),
            enable_compression=os.environ.get("GITLAB_COMPRESSION", "true").lower()
            == "true",
            timeout=float(os.environ.get("GITLAB_TIMEOUT", "30")),
        )


@dataclass
class BenchmarkConfig:
    """Benchmark run configuration."""

    gitlab_url: str = DEFAULT_GITLAB_URL
    gitlab_token: str = DEFAULT_GITLAB_TOKEN
    max_users: int = 10000
    max_projects: int = 10000
    concurrency: int = 100
    sample_size: int = 50
    use_progress: bool = True
    output_format: str = "text"
    output_file: str | None = None


class OutputFormat(StrEnum):
    TEXT = "text"
    JSON = "json"
    CSV = "csv"


# =============================================================================
# Data Classes
# =============================================================================


@dataclass
class BenchmarkMetrics:
    """Performance metrics from a benchmark run."""

    name: str
    count: int
    duration: float
    items_per_second: float
    memory_peak_mb: float | None = None
    memory_current_mb: float | None = None
    errors: int = 0

    def __str__(self) -> str:
        base = f"{self.name}: {self.count} items in {self.duration:.3f}s ({self.items_per_second:.1f} items/s)"
        if self.memory_peak_mb:
            base += f" | Memory: {self.memory_peak_mb:.1f} MB peak"
        return base


@dataclass
class BenchmarkResult:
    """Result from a single benchmark run.

    Supports both naming conventions:
    - name/items/duration (canonical)
    - operation/items_processed/duration_seconds (legacy)
    """

    name: str = ""
    library: str = ""
    items: int = 0
    duration: float = 0.0
    items_per_second: float = 0.0
    success: bool = True
    error: str | None = None
    memory_peak_mb: float | None = None
    memory_current_mb: float | None = None
    metadata: dict[str, Any] = field(default_factory=dict)

    # Legacy field aliases
    operation: str = ""
    items_processed: int = 0
    duration_seconds: float = 0.0
    errors: list[str] = field(default_factory=list)
    approach: str = ""

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)

    def __str__(self) -> str:
        label = self.name or self.operation or self.library
        return (
            f"{label:35} | {self.items:6d} items | "
            f"{self.duration:7.2f}s | {self.items_per_second:8.1f}/s"
        )


@dataclass
class ComparisonResult:
    """Comparison between two benchmark implementations."""

    operation: str
    glabflow: BenchmarkResult
    python_gitlab: BenchmarkResult
    speedup: float

    def to_dict(self) -> dict[str, Any]:
        return {
            "operation": self.operation,
            "glabflow": self.glabflow.to_dict(),
            "python_gitlab": self.python_gitlab.to_dict(),
            "speedup": self.speedup,
        }


# =============================================================================
# Benchmark Functions Protocol
# =============================================================================


class BenchmarkFunc(Protocol):
    async def __call__(self, config: BenchmarkConfig) -> BenchmarkResult: ...


T = TypeVar("T")


# =============================================================================
# Benchmark Runner
# =============================================================================


class BenchmarkRunner:
    """Runner for executing and measuring benchmarks."""

    def __init__(self, name: str):
        self.name = name
        self.results: list[BenchmarkResult] = []

    @asynccontextmanager
    async def measure(
        self,
        name: str,
        track_memory: bool = False,
    ) -> AsyncGenerator[BenchmarkResult]:
        """Context manager for measuring benchmark execution."""
        result = BenchmarkResult(name=name, success=False)
        tracemalloc_started = False

        if track_memory:
            tracemalloc.start()
            tracemalloc_started = True

        start_time = time.perf_counter()

        try:
            yield result
            result.success = True
        except Exception as e:
            result.error = str(e)
            raise
        finally:
            result.duration = time.perf_counter() - start_time

            if tracemalloc_started:
                current, peak = tracemalloc.get_traced_memory()
                tracemalloc.stop()
                result.memory_current_mb = current / 1024 / 1024
                result.memory_peak_mb = peak / 1024 / 1024

    async def run_async(
        self,
        name: str,
        func: Callable[[], Coroutine[Any, Any, T]],
        track_memory: bool = False,
    ) -> BenchmarkResult:
        """Run an async benchmark function and collect metrics."""
        async with self.measure(name, track_memory) as result:
            output = await func()
            if isinstance(output, int):
                result.items = output
                result.items_per_second = (
                    output / result.duration if result.duration > 0 else 0
                )
            elif isinstance(output, tuple):
                result.items = output[0]
                result.items_per_second = (
                    result.items / result.duration if result.duration > 0 else 0
                )

        self.results.append(result)
        return result

    def run_sync(
        self,
        name: str,
        func: Callable[[], T],
        track_memory: bool = False,
    ) -> BenchmarkResult:
        """Run a sync benchmark function and collect metrics."""
        result = BenchmarkResult(name=name, success=False)
        tracemalloc_started = False

        if track_memory:
            tracemalloc.start()
            tracemalloc_started = True

        start_time = time.perf_counter()

        try:
            output = func()
            result.success = True
            if isinstance(output, int):
                result.items = output
        except Exception as e:
            result.error = str(e)
            raise
        finally:
            result.duration = time.perf_counter() - start_time

            if tracemalloc_started:
                current, peak = tracemalloc.get_traced_memory()
                tracemalloc.stop()
                result.memory_current_mb = current / 1024 / 1024
                result.memory_peak_mb = peak / 1024 / 1024

            if result.duration > 0:
                result.items_per_second = result.items / result.duration

        self.results.append(result)
        return result


# =============================================================================
# Timing Helper
# =============================================================================


@dataclass
class TimingResult:
    """Result from a timed operation."""

    count: int
    duration: float
    items_per_second: float


def time_operation(func: Callable[[], int]) -> TimingResult:
    """Time a sync operation that returns a count.

    Args:
        func: Sync callable that returns the number of items processed.

    Returns:
        TimingResult with count, duration, and items_per_second.
    """
    start = time.perf_counter()
    count = func()
    duration = time.perf_counter() - start
    return TimingResult(
        count=count,
        duration=duration,
        items_per_second=count / duration if duration > 0 else 0,
    )


async def atime_operation(func: Callable[[], Coroutine[Any, Any, int]]) -> TimingResult:
    """Time an async operation that returns a count.

    Args:
        func: Async callable that returns the number of items processed.

    Returns:
        TimingResult with count, duration, and items_per_second.
    """
    start = time.perf_counter()
    count = await func()
    duration = time.perf_counter() - start
    return TimingResult(
        count=count,
        duration=duration,
        items_per_second=count / duration if duration > 0 else 0,
    )


# =============================================================================
# Mock Server Management
# =============================================================================


@asynccontextmanager
async def get_mock_server(
    port: int = DEFAULT_PORT,
    users: int = 1000,
    projects: int = 1000,
    mrs_per_project: int = 10,
    latency_ms: float = 50.0,
) -> AsyncGenerator[tuple[asyncio.subprocess.Process, int]]:
    """Start mock server and yield process handle.

    Usage:
        async with get_mock_server() as (proc, port):
            # run benchmarks against localhost:port
    """
    script_path = Path(__file__).parent.parent.parent / "benchmarks" / "mock_server.py"
    if not script_path.exists():
        script_path = (
            Path(__file__).parent.parent.parent / "examples" / "mock_server.py"
        )

    proc = await asyncio.create_subprocess_exec(
        "uv",
        "run",
        str(script_path),
        "--users",
        str(users),
        "--projects",
        str(projects),
        "--mrs-per-project",
        str(mrs_per_project),
        "--latency",
        str(latency_ms),
        "--port",
        str(port),
        stdout=asyncio.subprocess.PIPE,
        stderr=asyncio.subprocess.PIPE,
    )

    await asyncio.sleep(2)

    try:
        reader, writer = await asyncio.wait_for(
            asyncio.open_connection("localhost", port),
            timeout=5.0,
        )
        writer.close()
        await writer.wait_closed()
    except (TimeoutError, ConnectionRefusedError, OSError) as e:
        proc.terminate()
        raise RuntimeError(f"Failed to start mock server: {e}") from e

    try:
        yield proc, port
    finally:
        proc.terminate()
        try:
            await asyncio.wait_for(proc.wait(), timeout=5)
        except TimeoutError:
            proc.kill()


async def wait_for_server(port: int = DEFAULT_PORT, wait_timeout: float = 10.0) -> bool:
    """Wait for server to become available."""
    try:
        async with asyncio.timeout(wait_timeout):
            reader, writer = await asyncio.open_connection("localhost", port)
            writer.close()
            await writer.wait_closed()
        return True
    except (TimeoutError, ConnectionRefusedError, OSError):
        return False


# =============================================================================
# Client Helpers
# =============================================================================


def get_client_config() -> ClientConfig:
    """Get client configuration from environment or defaults."""
    return ClientConfig.from_env()


def create_labflow_client(config: ClientConfig | None = None):
    """Create and return a glabflow client.

    Args:
        config: ClientConfig instance or None for defaults.

    Returns:
        glabflow.Client instance.
    """
    if config is None:
        config = get_client_config()

    import glabflow

    return glabflow.Client(
        config.base_url,
        config.token,
        concurrency=config.concurrency,
        enable_compression=config.enable_compression,
        timeout=config.timeout,
    )


# =============================================================================
# Result Formatting
# =============================================================================


def format_benchmark_table(results: list[BenchmarkResult], width: int = 80) -> str:
    """Format benchmark results as a table."""
    lines: list[str] = []
    lines.append("=" * width)
    lines.append(f"{'Benchmark':<35} | {'Count':>8} | {'Time':>8} | {'Items/s':>10}")
    lines.append("-" * width)

    for r in results:
        status = "✓" if r.success else "✗"
        count_str = f"{r.items:,}" if r.items else "N/A"
        time_str = f"{r.duration:.3f}s" if r.duration else "N/A"
        rate_str = f"{r.items_per_second:,.0f}" if r.items_per_second else "N/A"
        lines.append(
            f"{status} {r.name:<33} | {count_str:>8} | {time_str:>8} | {rate_str:>10}"
        )

    lines.append("=" * width)
    return "\n".join(lines)


def format_text_results(results: list[ComparisonResult]) -> str:
    """Format comparison results as text table."""
    lines = []
    lines.append("\n" + "=" * 80)
    lines.append("  BENCHMARK SUMMARY")
    lines.append("=" * 80)
    lines.append("")
    lines.append(
        f"  {'Operation':<25} | {'glabflow':>12} | {'python-gitlab':>13} | {'Speedup':>10}"
    )
    lines.append("  " + "─" * 80)

    for r in results:
        lf_rate = f"{r.glabflow.items_per_second:.1f}/s"
        pg_rate = f"{r.python_gitlab.items_per_second:.1f}/s"
        lines.append(
            f"  {r.operation:<25} | {lf_rate:>12} | {pg_rate:>13} | {r.speedup:>9.2f}x"
        )

    lines.append("  " + "─" * 80)
    avg_speedup = sum(r.speedup for r in results) / len(results) if results else 0
    lines.append(
        f"  {'Average Speedup':<25} | {'':>12} | {'':>13} | {avg_speedup:>9.2f}x"
    )
    lines.append("")

    return "\n".join(lines)


def format_json_results(results: list[ComparisonResult]) -> str:
    """Format comparison results as JSON."""
    return json.dumps([r.to_dict() for r in results], indent=2)


def format_csv_results(results: list[ComparisonResult]) -> str:
    """Format comparison results as CSV."""
    lines = ["operation,labflow_items_per_sec,python_gitlab_items_per_sec,speedup"]
    for r in results:
        lines.append(
            f"{r.operation},{r.glabflow.items_per_second:.2f},{r.python_gitlab.items_per_second:.2f},{r.speedup:.2f}"
        )
    return "\n".join(lines)


def calculate_speedup(
    baseline: BenchmarkResult, comparison: BenchmarkResult
) -> float | None:
    """Calculate speedup factor between two benchmarks."""
    if not baseline.success or not comparison.success:
        return None
    if baseline.duration <= 0 or comparison.duration <= 0:
        return None
    return baseline.duration / comparison.duration
