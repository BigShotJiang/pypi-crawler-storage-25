from __future__ import annotations

from typing import Any


class LabflowError(Exception):
    def __init__(
        self,
        message: str,
        status_code: int | None = None,
        url: str | None = None,
    ) -> None:
        super().__init__(message)
        self.message = message
        self.status_code = status_code
        self.url = url

    def __repr__(self) -> str:
        return (
            f"{type(self).__name__}("
            f"message={self.message!r}, "
            f"status_code={self.status_code!r}, "
            f"url={self.url!r})"
        )


class AuthenticationError(LabflowError): ...  # 401


class ForbiddenError(LabflowError): ...  # 403


class NotFoundError(LabflowError): ...  # 404


class RateLimitError(LabflowError):  # 429
    def __init__(
        self,
        message: str,
        status_code: int | None = None,
        url: str | None = None,
        retry_after: float | None = None,
    ) -> None:
        super().__init__(message, status_code=status_code, url=url)
        self.retry_after = retry_after


class GraphQLError(LabflowError):
    """Raised when a GraphQL response contains errors."""

    def __init__(
        self,
        message: str,
        errors: list[dict[str, Any]] | None = None,
        url: str | None = None,
    ) -> None:
        super().__init__(message, url=url)
        self.errors: list[dict[str, Any]] = errors or []


class ServerError(LabflowError): ...  # 5xx


class TransientError(LabflowError):
    """Retriable transient error (409 Resource Lock, Cloudflare 52x)."""

    ...  # 409 Resource Lock, 520-530 Cloudflare


class PaginationError(LabflowError): ...  # pagination contract violations
