from __future__ import annotations

import asyncio
import atexit
import logging
import os
import re
import time
from collections import deque
from collections.abc import AsyncIterator
from dataclasses import dataclass, field
from types import TracebackType
from typing import TYPE_CHECKING, Any, cast

import aiohttp
import msgspec
import stamina
import zstandard

from glabflow._errors import (
    AuthenticationError,
    ForbiddenError,
    LabflowError,
    NotFoundError,
    PaginationError,
    RateLimitError,
    ServerError,
    TransientError,
)

logger = logging.getLogger(__name__)

if TYPE_CHECKING:
    from glabflow.api.access_tokens import AccessTokensAPI
    from glabflow.api.analytics import AnalyticsAPI
    from glabflow.api.audit import AuditAPI
    from glabflow.api.commits import CommitsAPI
    from glabflow.api.deployments import DeploymentsAPI
    from glabflow.api.dora import DoraAPI
    from glabflow.api.events import EventsAPI
    from glabflow.api.feature_flags import FeatureFlagsAPI
    from glabflow.api.groups import GroupsAPI
    from glabflow.api.issues import IssuesAPI
    from glabflow.api.jobs import JobsAPI
    from glabflow.api.labels import LabelsAPI
    from glabflow.api.members import MembersAPI
    from glabflow.api.milestones import MilestonesAPI
    from glabflow.api.mrs import MergeRequestsAPI
    from glabflow.api.namespaces import NamespacesAPI
    from glabflow.api.notes import NotesAPI
    from glabflow.api.pipeline_schedules import PipelineSchedulesAPI
    from glabflow.api.pipelines import PipelinesAPI
    from glabflow.api.projects import ProjectsAPI
    from glabflow.api.registry import RegistryAPI
    from glabflow.api.releases import ReleasesAPI
    from glabflow.api.repository import RepositoryAPI
    from glabflow.api.search import SearchAPI
    from glabflow.api.snippets import SnippetsAPI
    from glabflow.api.users import UsersAPI
    from glabflow.api.variables import VariablesAPI
    from glabflow.api.vulnerabilities import VulnerabilitiesAPI
    from glabflow.api.wikis import WikisAPI
    from glabflow.graphql.client import GraphQLClient

_LINK_RE = re.compile(r'<([^>]+)>;\s*rel="([^"]+)"')

_ZSTD_DECOMP = zstandard.ZstdDecompressor()

# Cached msgspec decoders for performance (avoid recreation on each call)
_JSON_DECODER = msgspec.json.Decoder()
_JSON_LIST_DECODER = msgspec.json.Decoder(type=list[object])

GITLAB_COM_URL = "https://gitlab.com/api/v4"
# gitlab.com enforces ~600 req/min; 20 concurrent keeps well inside that budget.
_GITLAB_COM_DEFAULT_CONCURRENCY = 20

# Global connection pool for reuse across clients
_GLOBAL_CONNECTOR: aiohttp.TCPConnector | None = None
_GLOBAL_CONNECTOR_LOCK: asyncio.Lock | None = None


def _get_global_connector_lock() -> asyncio.Lock:
    global _GLOBAL_CONNECTOR_LOCK
    if _GLOBAL_CONNECTOR_LOCK is None:
        _GLOBAL_CONNECTOR_LOCK = asyncio.Lock()
    return _GLOBAL_CONNECTOR_LOCK


def _close_global_connector() -> None:
    """Close global connector on exit to prevent resource leak warnings."""
    global _GLOBAL_CONNECTOR
    if _GLOBAL_CONNECTOR is not None:
        try:
            loop = asyncio.new_event_loop()
            try:
                loop.run_until_complete(_GLOBAL_CONNECTOR.close())
            finally:
                loop.close()
        except Exception:
            pass
        _GLOBAL_CONNECTOR = None


atexit.register(_close_global_connector)


def _parse_link_header(header: str) -> dict[str, str]:
    return {rel: url for url, rel in _LINK_RE.findall(header)}


def _decompress_if_zstd(data: bytes, encoding: str | None) -> bytes:
    """Decompress zstd-encoded data. aiohttp doesn't handle zstd natively."""
    if encoding and "zstd" in encoding.lower():
        return _ZSTD_DECOMP.decompress(data)
    return data


def _build_error(
    status: int,
    message: str,
    url: str,
    retry_after: float | None = None,
) -> LabflowError:
    match status:
        case 401:
            return AuthenticationError(message, status_code=status, url=url)
        case 403:
            return ForbiddenError(message, status_code=status, url=url)
        case 404:
            return NotFoundError(message, status_code=status, url=url)
        case 429:
            return RateLimitError(
                message, status_code=status, url=url, retry_after=retry_after
            )
        case 409:
            # 409 Conflict with "Resource lock" is a transient race condition
            return TransientError(message, status_code=status, url=url)
        case s if 520 <= s <= 530:
            # Cloudflare undocumented 52x range — transient server errors
            return TransientError(message, status_code=status, url=url)
        case s if 500 <= s < 600:
            return ServerError(message, status_code=status, url=url)
        case _:
            return LabflowError(message, status_code=status, url=url)


@dataclass
class RateLimitBudget:
    limit: int = 0
    remaining: int = 0
    reset_time: float = 0.0
    min_remaining: int = 100
    auto_tune: bool = True
    _last_update: float = field(default_factory=time.time, repr=False)

    def update_from_headers(self, headers: dict[str, str]) -> None:
        if limit := headers.get("RateLimit-Limit"):
            try:
                self.limit = int(limit)
            except ValueError:
                pass
        if remaining := headers.get("RateLimit-Remaining"):
            try:
                self.remaining = int(remaining)
            except ValueError:
                pass
        if reset := headers.get("RateLimit-Reset"):
            try:
                self.reset_time = float(reset)
            except ValueError:
                pass
        self._last_update = time.time()

    def wait_time_if_needed(self) -> float:
        if self.reset_time > time.time():
            return self.reset_time - time.time() + 1
        return 0.0

    def recommended_concurrency(self, initial: int) -> int:
        if (
            not self.auto_tune
            or self.limit == 0
            or self.remaining >= self.min_remaining
        ):
            return initial
        ratio = self.remaining / self.limit
        return max(1, int(initial * ratio))


@dataclass
class RequestMetrics:
    """Tracks request metrics for monitoring."""

    total_requests: int = 0
    successful_requests: int = 0
    failed_requests: int = 0
    total_bytes: int = 0
    start_time: float = field(default_factory=time.time)

    @property
    def duration(self) -> float:
        return time.time() - self.start_time

    @property
    def requests_per_second(self) -> float:
        d = self.duration
        return self.total_requests / d if d > 0 else 0

    async def record_request(
        self, success: bool = True, bytes_received: int = 0
    ) -> None:
        self.total_requests += 1
        if success:
            self.successful_requests += 1
        else:
            self.failed_requests += 1
        self.total_bytes += bytes_received

    def reset(self) -> None:
        self.total_requests = 0
        self.successful_requests = 0
        self.failed_requests = 0
        self.total_bytes = 0
        self.start_time = time.time()


@dataclass
class AdaptiveConcurrency:
    """
    Adaptive concurrency tuner based on response times and rate limits.

    Automatically adjusts concurrency to find the optimal balance
    between throughput and server capacity.
    """

    initial_concurrency: int = 100
    min_concurrency: int = 20
    max_concurrency: int = 300
    response_times: deque = field(default_factory=lambda: deque(maxlen=50))
    _last_adjustment: float = field(default_factory=time.time, repr=False)
    _adjustment_interval: float = 5.0  # seconds between adjustments
    _consecutive_429: int = 0  # Track rate limit errors
    _rate_limit_remaining: int = -1  # Track rate limit remaining

    def record_response(self, duration_ms: float) -> None:
        """Record a response time for analysis."""
        self.response_times.append(duration_ms)

    def record_rate_limit(self, remaining: int) -> None:
        """Record rate limit remaining from response headers."""
        self._rate_limit_remaining = remaining

    def record_429_error(self) -> None:
        """Record a 429 rate limit error."""
        self._consecutive_429 += 1

    def record_success(self) -> None:
        """Record a successful request (resets 429 counter)."""
        self._consecutive_429 = 0

    def get_optimal_concurrency(self) -> int:
        """
        Calculate optimal concurrency based on response times and rate limits.

        Strategy:
        - 429 errors: Aggressively reduce concurrency
        - Low rate limit remaining (<10): Reduce concurrency
        - Fast responses (<50ms): Increase concurrency
        - Slow responses (>200ms): Decrease concurrency
        """
        # Critical: Multiple 429 errors - back off aggressively
        if self._consecutive_429 >= 3:
            return max(self.min_concurrency, self.initial_concurrency // 2)
        elif self._consecutive_429 >= 1:
            return max(self.min_concurrency, int(self.initial_concurrency * 0.7))

        # Warning: Rate limit running low
        if 0 < self._rate_limit_remaining < 10:
            return max(self.min_concurrency, int(self.initial_concurrency * 0.8))

        # Use response time analysis
        if len(self.response_times) < 10:
            return self.initial_concurrency

        avg_time = sum(self.response_times) / len(self.response_times)

        # Fast responses - we can handle more concurrency
        if avg_time < 50:
            return min(self.max_concurrency, self.initial_concurrency + 50)
        # Slow responses - reduce concurrency to avoid overwhelming server
        elif avg_time > 200:
            return max(self.min_concurrency, self.initial_concurrency - 30)
        # Moderate responses - slight increase if stable
        elif avg_time < 100:
            return min(self.max_concurrency, self.initial_concurrency + 20)
        else:
            return self.initial_concurrency

    def should_adjust(self) -> bool:
        """Check if enough time has passed since last adjustment."""
        # Adjust immediately on 429 errors
        if self._consecutive_429 > 0:
            return True
        return (time.time() - self._last_adjustment) >= self._adjustment_interval

    def adjust(self, current: int) -> int:
        """Adjust concurrency if appropriate."""
        if not self.should_adjust():
            return current

        optimal = self.get_optimal_concurrency()
        self._last_adjustment = time.time()

        # Only adjust if significantly different (>10% change) or on errors
        if self._consecutive_429 > 0 or abs(optimal - current) / max(current, 1) > 0.1:
            return optimal
        return current


class GitLabClient:
    """Async GitLab API client optimized for high performance.

    By default, uses fast mode for maximum throughput.
    Enable optional features (metrics, adaptive concurrency) as needed.
    Enable TURBO mode for ABSOLUTE maximum speed (bypasses all abstractions).

    Args:
        base_url: GitLab API URL (e.g., "https://gitlab.com/api/v4")
        token: Private access token
        concurrency: Max concurrent requests (default: 100)
        per_page: Items per page (default: 100, max: 100)
        timeout: Request timeout in seconds (default: 30)
        ssl: Enable SSL verification (default: True)
        enable_metrics: Track request metrics (default: False, adds ~5% overhead)
        adaptive_concurrency: Auto-tune concurrency based on response times (default: False)
        enable_compression: Accept compressed responses (default: True)
        parallel_pages: Fetch N pages in parallel (default: 20, set 0 to disable)
        safe_mode: Prioritize safety over speed (default: False for MAXIMUM SPEED)
        raw_mode: Return raw dicts for speed (disabled in safe_mode)
        auth_type: "token" for PRIVATE-TOKEN, "bearer" for OAuth2/JWT
    """

    def __init__(
        self,
        base_url: str,
        token: str,
        concurrency: int = 200,
        per_page: int = 100,
        timeout: float = 30.0,
        ssl: bool = True,
        rate_limit_budget: RateLimitBudget | None = None,
        enable_metrics: bool = False,
        adaptive_concurrency: bool = False,
        enable_compression: bool = False,  # Disabled for speed
        parallel_pages: int = -2,  # -2 = concurrent "fire until empty" for max speed
        safe_mode: bool = False,  # Prioritize safety over speed (default: False for MAXIMUM SPEED)
        raw_mode: bool = True,  # Return raw dicts for speed (disabled in safe_mode)
        auth_type: str = "token",  # "token" for PRIVATE-TOKEN, "bearer" for OAuth2/JWT
        user_agent: str | None = None,  # Custom User-Agent header
        sudo: str | None = None,  # Impersonate another user (admin only)
    ) -> None:
        self._base_url = base_url.rstrip("/")
        self._token = token
        self._auth_type = auth_type
        self._safe_mode = safe_mode
        self._concurrency = 200 if safe_mode else concurrency
        self._initial_concurrency = self._concurrency
        self._per_page = per_page
        self._timeout = timeout
        self._ssl = ssl
        self._enable_compression = enable_compression or safe_mode
        self._parallel_pages = max(0, parallel_pages)
        self._raw_mode = raw_mode and not safe_mode
        self._session: aiohttp.ClientSession | None = None
        self._semaphore: asyncio.Semaphore | None = None
        self._connector: aiohttp.TCPConnector | None = None
        self._use_global_connector = True
        self._user_agent = user_agent
        self._sudo = sudo
        self.rate_limit_budget = rate_limit_budget or RateLimitBudget()

        self._enable_metrics = enable_metrics or safe_mode
        self._adaptive = (
            AdaptiveConcurrency(initial_concurrency=self._concurrency)
            if adaptive_concurrency or safe_mode
            else None
        )

        # Request metrics
        self._metrics = RequestMetrics() if self._enable_metrics else None

        # Lazily-initialised API namespaces (imported here to avoid circular imports)
        from glabflow.api.access_tokens import AccessTokensAPI
        from glabflow.api.analytics import AnalyticsAPI
        from glabflow.api.audit import AuditAPI
        from glabflow.api.commits import CommitsAPI
        from glabflow.api.deployments import DeploymentsAPI
        from glabflow.api.dora import DoraAPI
        from glabflow.api.events import EventsAPI
        from glabflow.api.feature_flags import FeatureFlagsAPI
        from glabflow.api.groups import GroupsAPI
        from glabflow.api.issues import IssuesAPI
        from glabflow.api.jobs import JobsAPI
        from glabflow.api.labels import LabelsAPI
        from glabflow.api.members import MembersAPI
        from glabflow.api.merge_requests import MergeRequestsAPI
        from glabflow.api.milestones import MilestonesAPI
        from glabflow.api.namespaces import NamespacesAPI
        from glabflow.api.notes import NotesAPI
        from glabflow.api.pipeline_schedules import PipelineSchedulesAPI
        from glabflow.api.pipelines import PipelinesAPI
        from glabflow.api.projects import ProjectsAPI
        from glabflow.api.registry import RegistryAPI
        from glabflow.api.releases import ReleasesAPI
        from glabflow.api.repository import RepositoryAPI
        from glabflow.api.search import SearchAPI
        from glabflow.api.snippets import SnippetsAPI
        from glabflow.api.users import UsersAPI
        from glabflow.api.variables import VariablesAPI
        from glabflow.api.vulnerabilities import VulnerabilitiesAPI
        from glabflow.api.wikis import WikisAPI
        from glabflow.graphql.client import GraphQLClient

        self.users: UsersAPI = UsersAPI(self)
        self.projects: ProjectsAPI = ProjectsAPI(self)
        self.mrs: MergeRequestsAPI = MergeRequestsAPI(self)
        self.issues: IssuesAPI = IssuesAPI(self)
        self.pipelines: PipelinesAPI = PipelinesAPI(self)
        self.audit: AuditAPI = AuditAPI(self)
        self.groups: GroupsAPI = GroupsAPI(self)
        self.members: MembersAPI = MembersAPI(self)
        self.repository: RepositoryAPI = RepositoryAPI(self)
        self.commits: CommitsAPI = CommitsAPI(self)
        self.jobs: JobsAPI = JobsAPI(self)
        self.pipeline_schedules: PipelineSchedulesAPI = PipelineSchedulesAPI(self)
        self.deployments: DeploymentsAPI = DeploymentsAPI(self)
        self.releases: ReleasesAPI = ReleasesAPI(self)
        self.labels: LabelsAPI = LabelsAPI(self)
        self.milestones: MilestonesAPI = MilestonesAPI(self)
        self.notes: NotesAPI = NotesAPI(self)
        self.wikis: WikisAPI = WikisAPI(self)
        self.snippets: SnippetsAPI = SnippetsAPI(self)
        self.variables: VariablesAPI = VariablesAPI(self)
        self.registry: RegistryAPI = RegistryAPI(self)
        self.search: SearchAPI = SearchAPI(self)
        self.events: EventsAPI = EventsAPI(self)
        self.namespaces: NamespacesAPI = NamespacesAPI(self)
        self.access_tokens: AccessTokensAPI = AccessTokensAPI(self)
        self.feature_flags: FeatureFlagsAPI = FeatureFlagsAPI(self)
        self.dora: DoraAPI = DoraAPI(self)
        self.vulnerabilities: VulnerabilitiesAPI = VulnerabilitiesAPI(self)
        self.analytics: AnalyticsAPI = AnalyticsAPI(self)
        self.graphql: GraphQLClient = GraphQLClient(self)

    @classmethod
    def for_gitlab_com(
        cls,
        token: str,
        concurrency: int = _GITLAB_COM_DEFAULT_CONCURRENCY,
        per_page: int = 100,
        timeout: float = 30.0,
    ) -> GitLabClient:
        """Create a client pre-configured for gitlab.com.

        Uses a reduced default concurrency (20) to stay within gitlab.com's
        rate limits (~600 req/min per token).

        Args:
            token: Personal access token or OAuth2 token
            concurrency: Max parallel requests (default 20 for gitlab.com)
            per_page: Page size for paginated endpoints (default 100)
            timeout: Per-request timeout in seconds (default 30)

        Returns:
            GitLabClient: Client pointed at https://gitlab.com/api/v4
        """
        return cls(
            base_url=GITLAB_COM_URL,
            token=token,
            concurrency=concurrency,
            per_page=per_page,
            timeout=timeout,
        )

    @classmethod
    def from_env(
        cls,
        *,
        url_env: str = "GITLAB_URL",
        token_env: str = "GITLAB_TOKEN",
        concurrency: int | None = None,
        **kwargs: Any,
    ) -> GitLabClient:
        """Create a client from environment variables.

        Reads ``GITLAB_URL`` and ``GITLAB_TOKEN`` by default.

        Args:
            url_env: Environment variable name for the GitLab URL
            token_env: Environment variable name for the access token
            concurrency: Override default concurrency
            **kwargs: Additional arguments passed to the constructor

        Returns:
            GitLabClient configured from environment

        Raises:
            ValueError: If required environment variables are not set
        """
        base_url = os.environ.get(url_env)
        token = os.environ.get(token_env)
        if not base_url:
            raise ValueError(f"Environment variable {url_env} is not set")
        if not token:
            raise ValueError(f"Environment variable {token_env} is not set")
        # Strip /api/v4 suffix if present — client expects base URL
        base_url = base_url.rstrip("/")
        if base_url.endswith("/api/v4"):
            base_url = base_url[:-7]
        if concurrency is not None:
            kwargs["concurrency"] = concurrency
        return cls(base_url=base_url, token=token, **kwargs)

    @property
    def base_url(self) -> str:
        return self._base_url

    @property
    def concurrency(self) -> int:
        return self._concurrency

    def configure(
        self,
        *,
        concurrency: int | None = None,
        parallel_pages: int | None = None,
        per_page: int | None = None,
    ) -> None:
        """Dynamically configure client settings.

        Args:
            concurrency: New concurrency level
            parallel_pages: Pages to fetch in parallel (-1 = all, 0 = sequential)
            per_page: Page size for pagination
        """
        if concurrency is not None:
            self._concurrency = concurrency
            self._semaphore = asyncio.Semaphore(concurrency)
            if self._adaptive:
                self._adaptive.initial_concurrency = concurrency

        if parallel_pages is not None:
            self._parallel_pages = (
                -1 if parallel_pages == -1 else max(0, parallel_pages)
            )

        if per_page is not None:
            self._per_page = per_page

    @property
    def rate_limit_status(self) -> dict[str, object]:
        return {
            "limit": self.rate_limit_budget.limit,
            "remaining": self.rate_limit_budget.remaining,
            "reset_time": self.rate_limit_budget.reset_time,
            "auto_tune": self.rate_limit_budget.auto_tune,
        }

    @property
    def metrics(self) -> RequestMetrics | None:
        """Get request metrics for monitoring."""
        return self._metrics

    async def wait_for_rate_limit_reset(self) -> None:
        wait_time = self.rate_limit_budget.wait_time_if_needed()
        if wait_time > 0:
            await asyncio.sleep(wait_time)

    async def __aenter__(self) -> GitLabClient:
        global _GLOBAL_CONNECTOR

        # Use adaptive max_concurrency if available, otherwise initial concurrency
        connector_limit = (
            self._adaptive.max_concurrency if self._adaptive else self._concurrency
        )

        if self._use_global_connector:
            async with _get_global_connector_lock():
                if _GLOBAL_CONNECTOR is None:
                    _GLOBAL_CONNECTOR = aiohttp.TCPConnector(
                        limit=connector_limit,
                        limit_per_host=connector_limit,
                        ttl_dns_cache=300,
                        use_dns_cache=True,
                        enable_cleanup_closed=False,
                        ssl=self._ssl,
                        keepalive_timeout=30,
                        force_close=False,
                    )
            self._connector = _GLOBAL_CONNECTOR
        else:
            self._connector = aiohttp.TCPConnector(
                limit=connector_limit,
                limit_per_host=min(connector_limit * 2, 200),
                ttl_dns_cache=300,
                use_dns_cache=True,
                enable_cleanup_closed=False,
                ssl=self._ssl,
                keepalive_timeout=30,
                force_close=False,
            )

        # GitLab v18.9+ authentication
        auth_header = (
            {"Authorization": f"Bearer {self._token}"}
            if self._auth_type == "bearer"
            else {"PRIVATE-TOKEN": self._token}
        )

        # Build headers with compression support
        headers: dict[str, str] = {
            "Content-Type": "application/json",
            **auth_header,
        }
        if self._user_agent:
            headers["User-Agent"] = self._user_agent
        if self._sudo:
            headers["SUDO"] = self._sudo
        if self._enable_compression:
            headers["Accept-Encoding"] = "zstd, br, gzip, deflate"

        self._session = aiohttp.ClientSession(
            connector=self._connector,
            connector_owner=not self._use_global_connector,
            headers=headers,
            timeout=aiohttp.ClientTimeout(
                total=self._timeout,
                connect=5.0,  # TCP + TLS must complete in 5s
                sock_read=25.0,  # detects stalled mid-transfer connections
            ),
            read_bufsize=262144,  # 256KB — reduces recv() calls for typical 100-500KB pages
        )

        # Use higher semaphore limit to reduce contention
        # TCPConnector handles actual connection limiting, semaphore just coordinates tasks
        self._semaphore = asyncio.Semaphore(self._concurrency * 2)

        # Pre-warm connections for faster startup
        await self._warm_connections()

        # Move all current long-lived objects (decoders, connector, session,
        # compiled regexes) to the permanent GC generation — never scanned again.
        # Reduces gc.collect() cost by 3-4x at sustained high request rates.
        import gc as _gc
        _gc.freeze()

        return self

    async def _warm_connections(self, count: int | None = None) -> None:
        """Pre-warm connection pool by firing dummy requests.

        Pre-establishes connections for faster initial requests.
        Uses unauthenticated /version endpoint to avoid consuming rate limit quota.
        Default warms up to 50 connections or concurrency, whichever is lower.
        """
        if self._session:
            if count is None:
                count = min(self._concurrency, 50)
            try:
                warm_semaphore = asyncio.Semaphore(min(count, self._concurrency))
                # /version is unauthenticated and not rate-limited — establishes same TCP connections
                base_url = self._base_url.replace("/api/v4", "")

                async def warm_request(i: int) -> None:
                    async with warm_semaphore:
                        try:
                            async with self._session.get(
                                f"{base_url}/version",
                                ssl=self._ssl,
                            ) as resp:
                                await resp.read()
                        except Exception:
                            pass

                tasks = [warm_request(i) for i in range(count)]
                await asyncio.gather(*tasks, return_exceptions=True)
            except Exception:
                pass

    async def __aexit__(
        self,
        exc_type: type[BaseException] | None,
        exc_val: BaseException | None,
        exc_tb: TracebackType | None,
    ) -> None:
        if self._session is not None:
            await self._session.close()
            self._session = None
        self._semaphore = None
        # Don't close global connector - it may be reused
        if self._connector is not None and not self._use_global_connector:
            await self._connector.close()
            self._connector = None

    def _require_session(self) -> aiohttp.ClientSession:
        if self._session is None:
            raise RuntimeError(
                "GitLabClient must be used as an async context manager. "
                "Use: async with glabflow.Client(...) as gl: ..."
            )
        return self._session

    def _require_semaphore(self) -> asyncio.Semaphore:
        if self._semaphore is None:
            raise RuntimeError("GitLabClient must be used as an async context manager.")
        return self._semaphore

    def _get_headers_dict(self, headers: Any) -> dict[str, str]:
        """Convert headers to dict for rate limit parsing."""
        if isinstance(headers, dict):
            return headers
        return dict(headers)

    async def _get_turbo(self, url: str, params: dict) -> bytes:
        """Zero-overhead GET - skip ALL validation, rate limits, error handling.

        Turbo mode: For maximum speed when you know the server is reliable.
        """
        async with self._require_session().get(
            url, params=params, ssl=self._ssl
        ) as resp:
            data = await resp.read()
            if self._enable_compression:
                data = _decompress_if_zstd(data, resp.headers.get("Content-Encoding"))
            return data

    def _update_rate_limit(self, headers: dict[str, str]) -> None:
        """Update rate limit budget from headers.

        SKIPPED in DEFAULT mode for maximum speed.
        """
        # Skip rate limit tracking in DEFAULT mode (not in safe_mode)
        if not self._safe_mode:
            return  # ZERO overhead!

        self.rate_limit_budget.update_from_headers(headers)

        # Update adaptive concurrency with rate limit info
        if self._adaptive:
            try:
                remaining = int(headers.get("RateLimit-Remaining", -1))
            except (ValueError, TypeError):
                remaining = -1
            self._adaptive.record_rate_limit(remaining)

        if self.rate_limit_budget.auto_tune:
            recommended = self.rate_limit_budget.recommended_concurrency(
                self._initial_concurrency
            )
            if recommended != self._concurrency and self._semaphore is not None:
                self._concurrency = recommended
                self._semaphore = asyncio.Semaphore(recommended)

    def _decode_json(self, data: bytes, type_hint: type | None = None):
        """Decode JSON using msgspec.

        Args:
            data: Raw JSON bytes
            type_hint: Optional type for msgspec validation

        Returns:
            Decoded data (list[dict] or typed object)
        """
        if type_hint:
            return msgspec.json.decode(data, type=type_hint)
        # Use cached decoder for default case (no type hint)
        return _JSON_DECODER.decode(data)

    async def _raise_for_status(self, response: aiohttp.ClientResponse) -> None:
        """Raise error for bad status codes."""
        import inspect

        status = response.status
        headers = self._get_headers_dict(response.headers)

        # Safe mode: thorough error handling with full context
        if self._safe_mode:
            self._update_rate_limit(headers)

            if status < 400:
                if self._adaptive:
                    self._adaptive.record_success()
                return

            # Get URL from response
            if hasattr(response, "url"):
                url = str(response.url)
            else:
                url = str(getattr(response, "_url", "unknown"))

            retry_after: float | None = None

            # Thorough rate limit handling
            if status == 429:
                if self._adaptive:
                    self._adaptive.record_429_error()
                raw = headers.get("Retry-After")
                if raw is not None:
                    try:
                        retry_after = float(raw)
                    except ValueError:
                        pass
                wait_time = self.rate_limit_budget.wait_time_if_needed()
                if wait_time > 0:
                    await asyncio.sleep(wait_time)

            # Full error message parsing
            try:
                if hasattr(response, "json") and inspect.iscoroutinefunction(
                    response.json
                ):
                    body: dict = cast(dict, await response.json(content_type=None))
                elif hasattr(response, "json"):
                    body = cast(dict, response.json())
                else:
                    # Use cached decoder for performance
                    body = cast(dict, _JSON_DECODER.decode(await response.read()))
                message = cast(
                    str, body.get("message") or body.get("error") or str(body)
                )
            except Exception:
                try:
                    if hasattr(response, "text") and inspect.iscoroutinefunction(
                        response.text
                    ):
                        message = cast(str, await response.text())
                    elif hasattr(response, "text"):
                        message = cast(str, response.text())
                    else:
                        message = f"HTTP {status}"
                except Exception:
                    message = f"HTTP {status}"

            raise _build_error(status, message, url, retry_after=retry_after)

        # Default mode: fast path for success, minimal error handling
        if status < 400:
            if self._adaptive:
                self._adaptive.record_success()
            return

        # Minimal error handling for speed
        self._update_rate_limit(headers)

        # Get URL from response
        if hasattr(response, "url"):
            url = str(response.url)
        else:
            url = str(getattr(response, "_url", "unknown"))

        retry_after: float | None = None

        if status == 429:
            if self._adaptive:
                self._adaptive.record_429_error()
            raw = headers.get("Retry-After")
            if raw is not None:
                try:
                    retry_after = float(raw)
                except ValueError:
                    pass
            wait_time = self.rate_limit_budget.wait_time_if_needed()
            if wait_time > 0:
                await asyncio.sleep(wait_time)

        try:
            if hasattr(response, "json") and inspect.iscoroutinefunction(response.json):
                body: dict = cast(dict, await response.json(content_type=None))
            elif hasattr(response, "json"):
                body = cast(dict, response.json())
            else:
                # Use cached decoder for performance
                body = cast(dict, _JSON_DECODER.decode(await response.read()))
            message = cast(str, body.get("message") or body.get("error") or str(body))
        except Exception:
            try:
                if hasattr(response, "text") and inspect.iscoroutinefunction(
                    response.text
                ):
                    message = cast(str, await response.text())
                elif hasattr(response, "text"):
                    message = cast(str, response.text())
                else:
                    message = f"HTTP {status}"
            except Exception:
                message = f"HTTP {status}"

        raise _build_error(status, message, url, retry_after=retry_after)

    async def _paginate_turbo(
        self,
        endpoint: str,
        params: dict[str, Any],
        ordered: bool = False,
    ) -> AsyncIterator[bytes]:
        """Zero-overhead pagination.

        TURBO MODE: Matches/exceeds async wrapper performance.

        Args:
            endpoint: API endpoint to paginate
            params: Query parameters
            ordered: If False, yields pages as they complete (faster!)

        Yields:
            Raw response bytes for each page
        """
        # Cache ALL attributes BEFORE hot loop — zero lookups in hot path
        url = f"{self._base_url}{endpoint}"
        session = self._require_session()
        ssl = self._ssl
        semaphore = self._require_semaphore()
        concurrency = self._concurrency
        per_page = params.get("per_page", self._per_page)
        enable_compression = self._enable_compression

        # Rate limit handling
        rate_limit_wait = 0.0
        rate_limit_hit = False

        # Pre-compute base params to avoid repeated dict merging in hot loop
        _base_fetch_params = {**params, "per_page": per_page}

        if not ordered:
            # UNORDERED MODE: Yield as soon as pages complete (10-15% faster!)
            buffer: dict[int, bytes] = {}
            next_yield = 1

            # Direct task tracking with asyncio.wait() — no Queue overhead
            in_flight: dict[asyncio.Task, int] = {}

            async def fetch_page_unordered(page_num: int) -> tuple[int, bytes]:
                """Fetch a page — ZERO overhead, with rate limit retry."""
                nonlocal rate_limit_wait, rate_limit_hit

                if rate_limit_hit:
                    await asyncio.sleep(rate_limit_wait)
                    rate_limit_wait = 0.0
                    rate_limit_hit = False

                try:
                    async with semaphore:
                        resp = await session.get(
                            url,
                            params=dict(_base_fetch_params, page=page_num),
                            ssl=ssl,
                        )
                    async with resp:
                        data = await resp.read()
                        # Inline compression check for speed (avoid function call)
                        if enable_compression:
                            enc = resp.headers.get("Content-Encoding")
                            if enc and "zstd" in enc.lower():
                                data = _ZSTD_DECOMP.decompress(data)
                        if resp.status == 429:
                            retry_after = resp.headers.get("Retry-After", "1")
                            try:
                                rate_limit_wait = float(retry_after)
                                rate_limit_hit = True
                            except ValueError:
                                rate_limit_wait = 1.0
                                rate_limit_hit = True
                            return (page_num, b"")
                    return (page_num, data)
                except Exception:
                    return (page_num, b"")

            # Seed initial batch
            for p in range(1, concurrency + 1):
                task = asyncio.create_task(fetch_page_unordered(p))
                in_flight[task] = p

            while in_flight:
                done, _ = await asyncio.wait(
                    in_flight.keys(), return_when=asyncio.FIRST_COMPLETED
                )
                for task in done:
                    page_num = in_flight.pop(task)
                    try:
                        page_num, data = task.result()
                    except Exception:
                        continue

                    if data and data != b"[]":
                        buffer[page_num] = data
                        # Queue next page
                        next_page = page_num + concurrency
                        new_task = asyncio.create_task(fetch_page_unordered(next_page))
                        in_flight[new_task] = next_page

                    # Yield in order
                    while next_yield in buffer:
                        yield buffer.pop(next_yield)
                        next_yield += 1
        else:
            # ORDERED MODE: Maintain page order (slower but predictable)
            results_buffer: dict[int, bytes] = {}
            next_to_yield = 1
            in_flight: dict[asyncio.Task, int] = {}

            async def fetch_page_ordered(page_num: int) -> tuple[int, bytes]:
                """Fetch a page — ZERO overhead, with rate limit retry."""
                nonlocal rate_limit_wait, rate_limit_hit

                if rate_limit_hit:
                    await asyncio.sleep(rate_limit_wait)
                    rate_limit_wait = 0.0
                    rate_limit_hit = False

                try:
                    async with semaphore:
                        resp = await session.get(
                            url,
                            params=dict(_base_fetch_params, page=page_num),
                            ssl=ssl,
                        )
                    async with resp:
                        data = await resp.read()
                        # Inline compression check for speed (avoid function call)
                        if enable_compression:
                            enc = resp.headers.get("Content-Encoding")
                            if enc and "zstd" in enc.lower():
                                data = _ZSTD_DECOMP.decompress(data)
                        if resp.status == 429:
                            retry_after = resp.headers.get("Retry-After", "1")
                            try:
                                rate_limit_wait = float(retry_after)
                                rate_limit_hit = True
                            except ValueError:
                                rate_limit_wait = 1.0
                                rate_limit_hit = True
                            return (page_num, b"")
                    return (page_num, data)
                except Exception:
                    return (page_num, b"")

            # Seed initial batch
            for i in range(1, concurrency + 1):
                task = asyncio.create_task(fetch_page_ordered(i))
                in_flight[task] = i

            while in_flight:
                done, _ = await asyncio.wait(
                    in_flight.keys(), return_when=asyncio.FIRST_COMPLETED
                )
                for task in done:
                    page_num = in_flight.pop(task)
                    try:
                        page_num, data = task.result()
                    except Exception:
                        continue

                    if data and data != b"[]":
                        results_buffer[page_num] = data
                        next_page = page_num + concurrency
                        new_task = asyncio.create_task(fetch_page_ordered(next_page))
                        in_flight[new_task] = next_page

                        while next_to_yield in results_buffer:
                            yield results_buffer.pop(next_to_yield)
                            next_to_yield += 1

            while next_to_yield in results_buffer:
                yield results_buffer.pop(next_to_yield)
                next_to_yield += 1

    async def post(self, path: str, json: dict[str, object]) -> bytes:
        """POST request."""
        client = self._require_session()
        semaphore = self._require_semaphore()
        url = f"{self._base_url}{path}"
        start = time.time()
        try:
            async with semaphore:
                async with client.post(url, json=json, ssl=self._ssl) as resp:
                    await self._raise_for_status(resp)
                    data = await resp.read()
                    if self._enable_compression:
                        data = _decompress_if_zstd(
                            data, resp.headers.get("Content-Encoding")
                        )
            # Skip metrics in fast mode
            if self._metrics:
                await self._metrics.record_request(
                    success=True, bytes_received=len(data)
                )
        except Exception:
            if self._metrics:
                await self._metrics.record_request(success=False, bytes_received=0)
            raise
        # Record response time for adaptive concurrency
        if self._adaptive:
            self._adaptive.record_response((time.time() - start) * 1000)
        return data

    async def get(self, path: str, **params: Any) -> bytes:
        """GET request."""
        client = self._require_session()
        semaphore = self._require_semaphore()
        url = f"{self._base_url}{path}"
        start = time.time()
        try:
            async with semaphore:
                async with client.get(url, params=params, ssl=self._ssl) as resp:
                    await self._raise_for_status(resp)
                    data = await resp.read()
                    if self._enable_compression:
                        data = _decompress_if_zstd(
                            data, resp.headers.get("Content-Encoding")
                        )
            # Skip metrics in fast mode
            if self._metrics:
                await self._metrics.record_request(
                    success=True, bytes_received=len(data)
                )
        except Exception:
            if self._metrics:
                await self._metrics.record_request(success=False, bytes_received=0)
            raise
        # Record response time for adaptive concurrency
        if self._adaptive:
            self._adaptive.record_response((time.time() - start) * 1000)
            # Adjust concurrency if needed
            new_concurrency = self._adaptive.adjust(self._concurrency)
            if new_concurrency != self._concurrency and self._semaphore is not None:
                self._concurrency = new_concurrency
                self._semaphore = asyncio.Semaphore(new_concurrency)
        return data

    async def paginate(
        self,
        endpoint: str,
        *,
        parallel_pages: int | None = None,
        ordered: bool = True,  # NEW: False for unordered (faster!)
        **params: Any,
    ) -> AsyncIterator[bytes]:
        """Paginate through results, keyset-first with offset fallback.

        Args:
            endpoint: API endpoint to paginate
            parallel_pages: Fetch N pages in parallel (default: from client config, 0 = sequential)
            ordered: If False, yield pages as they complete (10-15% faster!)
            **params: Query parameters for the request

        Yields:
            Raw response bytes for each page
        """
        # DEFAULT MODE: Zero-overhead turbo pagination, UNLESS caller explicitly
        # requests sequential keyset (parallel_pages=0) for Link-header following.
        if not self._safe_mode and parallel_pages != 0:
            async for data in self._paginate_turbo(endpoint, params, ordered=ordered):
                yield data
            return

        if parallel_pages is None:
            parallel_pages = self._parallel_pages

        client = self._require_session()
        semaphore = self._require_semaphore()
        url = f"{self._base_url}{endpoint}"

        # Parallel page fetching in batches (offset pagination)
        if parallel_pages > 0:
            keyset_params: dict[str, Any] = {
                **params,
                "pagination": "keyset",
                "per_page": self._per_page,
                "order_by": "id",
                "sort": "asc",
            }
            async for data in self._paginate_parallel(
                url, keyset_params, params, parallel_pages
            ):
                yield data
            return

        # Fetch ALL pages at once (requires accurate X-Total)
        if parallel_pages == -1:
            async for data in self._paginate_all_at_once(endpoint, params):
                yield data
            return

        # "Fire until empty" strategy (offset pagination, concurrent)
        if parallel_pages == -2:
            async for data in self._paginate_fire_until_empty(endpoint, params):
                yield data
            return

        # Default: Sequential keyset-first with offset fallback, 1-page lookahead.
        # This is the safest default that works for all endpoints.

        @stamina.retry(
            on=(TransientError, ServerError, aiohttp.ClientError),
            attempts=3,
            wait_initial=0.5,
            wait_max=10.0,
        )
        async def _fetch(
            fetch_url: str, fetch_params: dict[str, Any] | None = None
        ) -> tuple[bytes, str | None]:
            start = time.time()
            _exc: BaseException | None = None
            _data: bytes = b""
            _next: str | None = None
            async with semaphore:
                async with client.get(
                    fetch_url, params=fetch_params, ssl=self._ssl
                ) as resp:
                    try:
                        await self._raise_for_status(resp)
                        _data = await resp.read()
                        if self._enable_compression:
                            _data = _decompress_if_zstd(
                                _data, resp.headers.get("Content-Encoding")
                            )
                        _next = _parse_link_header(resp.headers.get("Link", "")).get(
                            "next"
                        )
                    except BaseException as exc:
                        _exc = exc
            if _exc is None and self._adaptive:
                self._adaptive.record_response((time.time() - start) * 1000)
            if _exc is not None:
                raise _exc
            return _data, _next

        keyset_params = {
            **params,
            "pagination": "keyset",
            "per_page": self._per_page,
            "order_by": "id",
            "sort": "asc",
        }

        # Try keyset; fall back to offset on 422
        use_keyset = True
        try:
            data, next_url = await _fetch(url, keyset_params)
        except LabflowError as exc:
            if exc.status_code != 422:
                raise
            use_keyset = False
            data, next_url = await _fetch(
                url, dict(params, per_page=self._per_page, page=1)
            )

        if not data or data in (b"[]", b"[ ]"):
            return

        # Validate first page is a JSON array
        if not data.lstrip().startswith(b"["):
            if not use_keyset:
                raise PaginationError("Failed to decode pagination response", url=url)
            return  # keyset returned non-array → stop silently

        # 1-page lookahead: pre-launch next fetch while yielding current page
        next_task: asyncio.Task[tuple[bytes, str | None]] | None = None
        page = 2  # for offset mode

        # Always prefetch in sequential mode
        if use_keyset and next_url is not None:
            next_task = asyncio.create_task(_fetch(next_url))
        elif not use_keyset:
            next_task = asyncio.create_task(
                _fetch(url, dict(params, per_page=self._per_page, page=page))
            )
            page += 1

        try:
            yield data

            while True:
                try:
                    if next_task is not None:
                        data, next_url = await next_task
                        next_task = None
                    elif use_keyset:
                        if next_url is None:
                            break
                        data, next_url = await _fetch(next_url)
                    else:
                        data, _ = await _fetch(
                            url, {**params, "per_page": self._per_page, "page": page}
                        )
                        page += 1
                except LabflowError as exc:
                    if exc.status_code == 422 and use_keyset:
                        # Mid-stream keyset 422 → fall back to offset pagination
                        use_keyset = False
                        next_task = asyncio.create_task(
                            _fetch(
                                url, dict(params, per_page=self._per_page, page=page)
                            )
                        )
                        page += 1
                        continue
                    elif exc.status_code == 422:
                        break  # mid-stream offset 422 → stop gracefully
                    raise

                if not data or data in (b"[]", b"[ ]"):
                    break

                try:
                    # Use cached list decoder for performance
                    items: list[object] = _JSON_LIST_DECODER.decode(data)
                except Exception:
                    raise PaginationError(
                        "Failed to decode pagination response", url=url
                    )
                if not items:
                    break

                # Pre-launch next fetch while we yield this page (always prefetch)
                if use_keyset and next_url is not None:
                    next_task = asyncio.create_task(_fetch(next_url))
                elif not use_keyset:
                    next_task = asyncio.create_task(
                        _fetch(
                            url,
                            dict(params, per_page=self._per_page, page=page),
                        )
                    )
                    page += 1

                yield data

                if use_keyset and next_url is None and next_task is None:
                    break
        finally:
            if next_task is not None:
                next_task.cancel()
                try:
                    await next_task
                except (asyncio.CancelledError, Exception):
                    pass

    async def _paginate_fire_until_empty(
        self,
        endpoint: str,
        params: dict[str, Any],
    ) -> AsyncIterator[bytes]:
        """Fetch pages concurrently until empty responses (async wrapper strategy).

        This launches concurrent requests for pages 1,2,3...concurrency,
        then continues fetching more pages as results come in, until
        we receive empty responses.

        Does NOT rely on X-Total header - works like async wrapper.

        Args:
            endpoint: API endpoint to paginate
            params: Query parameters

        Yields:
            Raw response bytes for each page in order
        """
        client = self._require_session()
        semaphore = self._require_semaphore()
        url = f"{self._base_url}{endpoint}"

        per_page = params.get("per_page", self._per_page)

        # Results buffer to maintain order
        results_buffer: dict[int, bytes] = {}
        next_to_yield = 1

        # Track in-flight tasks for true concurrency
        in_flight: dict[asyncio.Task[tuple[int, bytes]], int] = {}

        # Track the next page number to fetch for each "slot" in the concurrency window.
        # This ensures we fetch pages sequentially even when they complete out of order.
        # Key insight: each slot i fetches pages i, i+concurrency, i+2*concurrency, etc.
        next_page_per_slot: dict[int, int] = {
            i: i for i in range(1, self._concurrency + 1)
        }

        async def fetch_page(page_num: int) -> tuple[int, bytes]:
            """Fetch a page and return (page_number, data)."""
            start = time.time()
            try:
                async with semaphore:
                    async with client.get(
                        url,
                        params=dict(params, page=page_num, per_page=per_page),
                        ssl=self._ssl,
                    ) as resp:
                        await self._raise_for_status(resp)
                        data = await resp.read()
                        if self._enable_compression:
                            data = _decompress_if_zstd(
                                data, resp.headers.get("Content-Encoding")
                            )

                if self._adaptive:
                    self._adaptive.record_response((time.time() - start) * 1000)

                return page_num, data
            except Exception:
                return page_num, b""

        # Launch initial batch of concurrent tasks
        for i in range(1, self._concurrency + 1):
            task = asyncio.create_task(fetch_page(i))
            in_flight[task] = i

        # Process completed tasks and launch new ones
        while in_flight:
            # Wait for the first task to complete
            done, _ = await asyncio.wait(
                in_flight.keys(), return_when=asyncio.FIRST_COMPLETED
            )

            for task in done:
                page_num, data = task.result()
                del in_flight[task]

                if data and data != b"[]":
                    # Got data - buffer it and queue next page in this slot
                    results_buffer[page_num] = data

                    # Calculate which slot this page belongs to and queue next page
                    slot = ((page_num - 1) % self._concurrency) + 1
                    next_page = next_page_per_slot[slot] + self._concurrency
                    next_page_per_slot[slot] = next_page

                    new_task = asyncio.create_task(fetch_page(next_page))
                    in_flight[new_task] = next_page

                    # Yield any buffered pages in order
                    while next_to_yield in results_buffer:
                        yield results_buffer.pop(next_to_yield)
                        next_to_yield += 1
                # Empty page - don't queue more for this slot, let queue drain
                # Other slots will continue fetching

        # Yield any remaining buffered pages
        while next_to_yield in results_buffer:
            yield results_buffer.pop(next_to_yield)
            next_to_yield += 1

    async def _paginate_all_at_once(
        self,
        endpoint: str,
        params: dict[str, Any],
    ) -> AsyncIterator[bytes]:
        """Fetch ALL pages concurrently at once (async wrapper strategy).

        This launches concurrent requests for ALL pages upfront,
        then yields them in order. Uses offset pagination for parallel fetching.

        Matches async wrapper's strategy for maximum throughput.

        WARNING: High memory usage - all pages held in RAM.

        Args:
            endpoint: API endpoint to paginate
            params: Query parameters

        Yields:
            Raw response bytes for each page in order
        """
        client = self._require_session()
        semaphore = self._require_semaphore()
        url = f"{self._base_url}{endpoint}"

        # Fetch page 1 to get total count from X-Total header
        async with semaphore:
            async with client.get(
                url,
                params=dict(params, page=1, per_page=self._per_page),
                ssl=self._ssl,
            ) as resp:
                await self._raise_for_status(resp)
                first_page = await resp.read()
                if self._enable_compression:
                    first_page = _decompress_if_zstd(
                        first_page, resp.headers.get("Content-Encoding")
                    )
                total = int(resp.headers.get("X-Total", "0"))

        if not first_page or first_page == b"[]":
            return

        yield first_page

        # Calculate total pages
        per_page = params.get("per_page", self._per_page)
        total_pages = (total + per_page - 1) // per_page

        if total_pages <= 1:
            return  # Already yielded the only page

        # Fetch ALL remaining pages concurrently (matches async wrapper)
        pages_to_fetch = list(range(2, total_pages + 1))

        async def fetch_page(page_num: int) -> tuple[int, bytes]:
            """Fetch a page and return (page_number, data)."""
            start = time.time()
            try:
                async with semaphore:
                    async with client.get(
                        url,
                        params=dict(params, page=page_num, per_page=per_page),
                        ssl=self._ssl,
                    ) as resp:
                        await self._raise_for_status(resp)
                        data = await resp.read()
                        if self._enable_compression:
                            data = _decompress_if_zstd(
                                data, resp.headers.get("Content-Encoding")
                            )

                # Record response time
                if self._adaptive:
                    self._adaptive.record_response((time.time() - start) * 1000)

                return page_num, data
            except Exception:
                return page_num, b""

        # Launch ALL page requests concurrently (exactly like async wrapper)
        tasks = [fetch_page(p) for p in pages_to_fetch]
        results = await asyncio.gather(*tasks, return_exceptions=True)

        # Sort by page number and yield in order
        successful: list[tuple[int, bytes]] = []
        for result in results:
            if isinstance(result, BaseException):
                continue
            page_num, data = result
            if data and data != b"[]":
                successful.append((page_num, data))

        # Sort and yield
        successful.sort(key=lambda x: x[0])
        for _, data in successful:
            yield data

    async def _paginate_parallel(
        self,
        url: str,
        keyset_params: dict[str, Any],
        fallback_params: dict[str, Any],
        parallel_pages: int,
    ) -> AsyncIterator[bytes]:
        """Fetch multiple pages in parallel for maximum throughput.

        Uses offset pagination for parallel fetching since keyset cursors
        must be followed sequentially. This trades keyset efficiency for
        parallelism, which is faster for small-to-medium result sets.

        Args:
            url: Base URL for the endpoint
            keyset_params: Parameters for keyset pagination
            fallback_params: Fallback parameters if keyset fails
            parallel_pages: Number of pages to fetch in parallel
        """
        client = self._require_session()
        semaphore = self._require_semaphore()
        session = client  # For aiohttp compatibility in the closure

        # Use offset pagination for parallel fetching
        # This allows us to fetch any page number directly
        offset_params = dict(fallback_params, per_page=self._per_page, page=1)

        page = 1
        empty_pages = 0
        max_empty_pages = 2  # Stop after 2 consecutive empty pages

        while empty_pages < max_empty_pages:
            # Fetch a batch of pages in parallel
            pages_to_fetch = list(range(page, page + parallel_pages))

            async def fetch_page(page_num: int) -> tuple[int, bytes]:
                start = time.time()
                async with semaphore:
                    params = dict(offset_params, page=page_num)
                    async with session.get(url, params=params, ssl=self._ssl) as resp:
                        await self._raise_for_status(resp)
                        data = await resp.read()
                        if self._enable_compression:
                            data = _decompress_if_zstd(
                                data, resp.headers.get("Content-Encoding")
                            )

                if self._adaptive:
                    self._adaptive.record_response((time.time() - start) * 1000)

                return page_num, data

            # Fetch all pages in parallel
            tasks = [fetch_page(p) for p in pages_to_fetch]
            results = await asyncio.gather(*tasks, return_exceptions=True)

            # Sort by page number and yield in order
            successful: list[tuple[int, bytes]] = []
            for result in results:
                if isinstance(result, BaseException):
                    continue
                successful.append(result)

            successful.sort(key=lambda x: x[0])

            # Yield pages in order
            batch_had_data = False
            for page_num, data in successful:
                # Validate page
                try:
                    # Use cached list decoder for performance
                    _page_items = _JSON_LIST_DECODER.decode(data)
                    if not _page_items:
                        empty_pages += 1
                        if empty_pages >= max_empty_pages:
                            break
                    else:
                        empty_pages = 0
                        batch_had_data = True
                        yield data
                except Exception:
                    empty_pages += 1
                    break

            # Move to next batch
            page += parallel_pages

            # If no data in entire batch, we're done
            if not batch_had_data:
                break
