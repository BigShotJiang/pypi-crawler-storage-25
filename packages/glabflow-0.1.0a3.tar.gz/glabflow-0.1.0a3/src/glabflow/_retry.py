from __future__ import annotations

import asyncio
import functools
import math
from collections.abc import Awaitable, Callable
from typing import Any, TypeVar

import aiohttp
import stamina

from glabflow._errors import RateLimitError, ServerError

F = TypeVar("F", bound=Callable[..., Awaitable[Any]])

_SERVER_ERRORS = (ServerError, aiohttp.ClientError)


def make_retry(
    on: tuple[type[Exception], ...] = _SERVER_ERRORS,
    attempts: int = 3,
    wait_initial: float = 0.5,
    wait_max: float = 10.0,
    wait_exp_base: float = 2.0,
) -> Callable[[F], F]:
    """
    Return a retry decorator for GitLab API calls.

    - RateLimitError (429): sleeps for the ``Retry-After`` header value when
      present, otherwise falls back to exponential backoff. Retried up to
      ``attempts`` times independently of server-error retries.
    - ServerError (5xx) and aiohttp.ClientError: retried via stamina with
      exponential backoff.
    - AuthenticationError, ForbiddenError, NotFoundError: never retried.
    """
    _stamina_retry = stamina.retry(
        on=on,
        attempts=attempts,
        wait_initial=wait_initial,
        wait_max=wait_max,
        wait_exp_base=wait_exp_base,
    )

    def decorator(fn: F) -> F:
        stamina_wrapped = _stamina_retry(fn)

        @functools.wraps(fn)
        async def wrapper(*args: Any, **kwargs: Any) -> Any:
            rl_attempt = 0
            while True:
                try:
                    return await stamina_wrapped(*args, **kwargs)
                except RateLimitError as exc:
                    rl_attempt += 1
                    if rl_attempt >= attempts:
                        raise
                    wait = (
                        exc.retry_after
                        if exc.retry_after is not None
                        else min(
                            wait_initial * math.pow(wait_exp_base, rl_attempt - 1),
                            wait_max,
                        )
                    )
                    await asyncio.sleep(wait)

        return wrapper  # type: ignore[return-value]

    return decorator


#: Default retry decorator for use on client methods
default_retry = make_retry()
