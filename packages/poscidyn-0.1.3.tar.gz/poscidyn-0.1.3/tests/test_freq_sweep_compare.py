import numpy as np
import poscidyn
import time
import h5py  # <-- NEW

import matplotlib.pyplot as plt
from matplotlib.lines import Line2D


# =========================
# NEW: load original A from file
# =========================
A_NPZ_PATH = "/home/raymo/Projects/nlsid/worst_b_case_A_only.npz"  # <-- set your npz path
HDF5_DATASET_PATH = "/home/raymo/Projects/nlsid/datasets/2026012301_string_2DOF/2026012301_string_2DOF_augmented_split.hdf5"  # <-- set your dataset file
SPLIT = "test"          # <-- set train/val/test
HDF5_INDEX = None       # <-- optional: override; if None we'll use worst_index from the npz

def F_max(eta, omega_0, Q, b):
    return np.sqrt(
        4 * omega_0**6
        / (3 * b * Q**2)
        * (eta + 1 / (2 * Q**2))
        * (1 + eta + 1 / (4 * Q**2))
    )


# 1 mode:
Q, omega_0, a, b = np.array([100.0]), np.array([1.00]), np.zeros((1, 1, 1)), np.zeros((1, 1, 1, 1))
b[0, 0, 0, 0] = 2.55
modal_forces = np.array([1.0])

# 2 modes:
Q, omega_0, a, b = (
    np.array([6.357357, 36.742565]),
    np.array([0.9946662, 2.1275177]),
    np.zeros((2, 2, 2)),
    np.zeros((2, 2, 2, 2)),
)
b[0, 0, 0, 0] = 1.9451260e01
b[0, 0, 1, 1] = 1.3927963e02
b[1, 1, 1, 1] = 2.6890811e02
b[1, 0, 0, 1] = 1.4860869e02

F_max_value = F_max(0.20, omega_0[0], Q[0], b[0, 0, 0, 0])
print(f"Calculated F_max: {F_max_value:.4f}")


# You can keep these as you had them:
driving_frequency = np.linspace(0.6322645545005798, 2.2314629554748535, 400)
driving_amplitude = np.linspace(0.1, 1.0, 10) * 1
modal_forces = np.array([0.01101661, 0.00740971])

MODEL = poscidyn.NonlinearOscillator(Q=Q, a=a, b=b, omega_0=omega_0)
EXCITOR = poscidyn.OneToneExcitation(driving_frequency, driving_amplitude, modal_forces)
MULTISTART = poscidyn.LinearResponseMultistart(n_init_cond=9, linear_response_factor=1.0)
SOLVER = poscidyn.TimeIntegrationSolver(
    max_steps=4096 * 5, n_time_steps=50, verbose=True, throw=False, rtol=1e-4, atol=1e-7
)
SWEEPER = poscidyn.NearestNeighbourSweep(sweep_direction=[poscidyn.Forward(), poscidyn.Backward()])
PRECISION = poscidyn.Precision.SINGLE


def _extract_b_entries(b: np.ndarray, max_entries: int = 3):
    arr = np.asarray(b)
    non_zero = np.argwhere(arr != 0)
    entries = []
    for idx in non_zero[:max_entries]:
        tuple_idx = tuple(idx.tolist())
        entries.append((tuple_idx, float(arr[tuple_idx])))
    return entries, int(non_zero.shape[0])


def _extract_a_entries(a: np.ndarray, max_entries: int = 3):
    arr = np.asarray(a)
    non_zero = np.argwhere(arr != 0)
    entries = []
    for idx in non_zero[:max_entries]:
        tuple_idx = tuple(idx.tolist())
        entries.append((tuple_idx, float(arr[tuple_idx])))
    return entries, int(non_zero.shape[0])


def _format_param_text(Q: np.ndarray, omega_0: np.ndarray, a: np.ndarray, b: np.ndarray, modal_forces: np.ndarray) -> str:
    q_vals = np.asarray(Q).ravel()
    omega_vals = np.asarray(omega_0).ravel()
    a_entries, a_total = _extract_a_entries(a)
    b_entries, b_total = _extract_b_entries(b)

    parts = []
    if q_vals.size:
        parts.append(f"Q=[{', '.join(f'{val:.2f}' for val in q_vals[:2])}]")
    if omega_vals.size:
        parts.append(f"omega0=[{', '.join(f'{val:.2f}' for val in omega_vals[:2])}]")
    if a_entries:
        formatted_a = ", ".join(f"{idx}={val:.2e}" for idx, val in a_entries)
        if a_total > len(a_entries):
            formatted_a += ", ..."
        parts.append(f"a={formatted_a}")
    if b_entries:
        formatted_b = ", ".join(f"{idx}={val:.2e}" for idx, val in b_entries)
        if b_total > len(b_entries):
            formatted_b += ", ..."
        parts.append(f"b={formatted_b}")
    if modal_forces.size:
        parts.append(f"modal_forces=[{', '.join(f'{val:.2f}' for val in modal_forces[:2])}]")
    return "\n".join(parts)


# =========================
# NEW: load the stored dataset curve + its omega range
# =========================
def load_dataset_curve():
    idx = HDF5_INDEX
    if idx is None:
        # Try to pull index from the npz you saved earlier
        d = np.load(A_NPZ_PATH)
        if "worst_index" in d:
            idx = int(d["worst_index"])
        else:
            raise ValueError("HDF5_INDEX is None and NPZ file does not contain 'worst_index'.")

    with h5py.File(HDF5_DATASET_PATH, "r") as f:
        g = f[SPLIT]
        A_ds = np.asarray(g["A"][idx, :], dtype=np.float64) * (50.0 / 2.347)* 0.9939844
        fmin = float(np.asarray(g["f_omega_min"][idx]))
        fmax = float(np.asarray(g["f_omega_max"][idx]))
        omega_axis = np.linspace(fmin, fmax, A_ds.shape[0], dtype=np.float64)

    return idx, omega_axis, A_ds, fmin, fmax


# =========================
# MODIFIED: plot_sweep now also plots dataset A
# =========================
def plot_sweep(ax, drive_freqs, drive_amps, sweeped_solutions, param_text: str) -> None:
    forward = sweeped_solutions.get("forward")
    backward = sweeped_solutions.get("backward")

    if forward is None and backward is None:
        raise ValueError("No sweeped solutions to plot.")

    drive_freqs = np.asarray(drive_freqs, dtype=np.float64)
    drive_amps = np.asarray(drive_amps)
    colors = plt.cm.viridis(np.linspace(0, 1, drive_amps.size))

    # --- simulation curves
    for idx, (amp, color) in enumerate(zip(drive_amps, colors)):
        if forward is not None:
            ax.plot(drive_freqs, forward[:, idx], color=color, linestyle="-", linewidth=1.3)
        if backward is not None:
            ax.plot(drive_freqs, backward[:, idx], color=color, linestyle="--", linewidth=1.1)

    # --- NEW: overlay dataset A (as saved)
    ds_idx, omega_ds, A_ds, _, _ = load_dataset_curve()

    A_ds_plot = A_ds

    ax.plot(
        omega_ds,
        A_ds_plot,
        color="black",
        linewidth=2.2,
        a=0.9,
        label=f"Dataset A (idx={ds_idx})",
        zorder=6,
    )

    # also mark the dataset reference point (0.9*omega0[0]) on the dataset curve
    target = 0.9 * float(omega_0[0])
    ref_idx_ds = int(np.argmin(np.abs(omega_ds - target)))
    ax.scatter(
        [omega_ds[ref_idx_ds]],
        [A_ds_plot[ref_idx_ds]],
        color="red",
        s=55,
        zorder=7,
        label="0.9·ω₀[0] ref (dataset)",
    )

    ax.set_title("Frequency sweep (simulation) + stored dataset A overlay")
    ax.set_xlabel("Drive frequency")
    ax.set_ylabel("Max displacement")
    ax.grid(a=0.25)

    if param_text:
        ax.text(
            0.02,
            0.98,
            param_text,
            transform=ax.transAxes,
            fontsize=8,
            va="top",
            ha="left",
            bbox=dict(facecolor="white", edgecolor="none", a=0.65),
        )

    # Legends
    amp_handles = [Line2D([0], [0], color=color, lw=1.8) for color in colors]
    amp_labels = [f"F={amp:.3f}" for amp in drive_amps]
    legend1 = ax.legend(
        amp_handles,
        amp_labels,
        title="Drive amplitude",
        loc="upper right",
        bbox_to_anchor=(1.0, 1.0),
        fontsize=7,
        frameon=False,
        ncol=2,
    )

    style_handles = [
        Line2D([0], [0], color="k", linestyle="-", lw=1.5),
        Line2D([0], [0], color="k", linestyle="--", lw=1.5),
        Line2D([0], [0], color="black", linestyle="-", lw=2.2),
        Line2D([0], [0], color="red", marker="o", linestyle="None", markersize=6),
    ]
    style_labels = ["Forward sweep", "Backward sweep", "Dataset A", "Dataset ref point"]

    legend2 = ax.legend(
        style_handles,
        style_labels,
        loc="lower right",
        fontsize=7,
        frameon=False,
    )
    ax.add_artist(legend1)


start_time = time.time()

frequency_sweep = poscidyn.frequency_sweep(
    model=MODEL,
    sweeper=SWEEPER,
    excitor=EXCITOR,
    solver=SOLVER,
    precision=PRECISION,
    multistarter=MULTISTART,
)  # n_freq, n_amp, n_init_disp, n_init_vel

end_time = time.time()
print(f"Frequency sweep completed in {end_time - start_time:.2f} seconds.")
print(
    f"Successful periodic solutions: {frequency_sweep.n_successful}/{frequency_sweep.n_total} "
    f"({frequency_sweep.success_rate:.1%})"
)

fig, ax = plt.subplots(figsize=(10, 6))
plot_sweep(
    ax=ax,
    drive_freqs=EXCITOR.drive_frequencies,
    drive_amps=EXCITOR.drive_amplitudes,
    sweeped_solutions=frequency_sweep.sweeped_periodic_solutions,
    param_text=_format_param_text(Q, omega_0, a, b, EXCITOR.modal_forces),
)
plt.tight_layout()
plt.show()
