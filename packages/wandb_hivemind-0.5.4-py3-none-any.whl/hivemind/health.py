"""Daemon health checks shared by the landing page and `hivemind doctor`."""

from __future__ import annotations

import json
import os
import platform
import subprocess
from pathlib import Path


def collect_status() -> list[dict]:
    """Collect daemon health status checks.

    Returns a list of dicts with keys: label, ok (bool | None), detail.
    """
    state_dir = Path.home() / ".hivemind"
    checks: list[dict] = []

    # Check 1: Daemon running
    lock_file = state_dir / "daemon.lock"
    daemon_running = False
    pid_str = ""
    if lock_file.exists():
        try:
            pid_str = lock_file.read_text().strip()
            if pid_str:
                pid = int(pid_str)
                os.kill(pid, 0)
                daemon_running = True
        except (ValueError, ProcessLookupError, PermissionError, OSError):
            pass

    if daemon_running:
        checks.append({"label": "Daemon running", "ok": True, "detail": f"PID {pid_str}"})
    else:
        checks.append(
            {
                "label": "Daemon not running",
                "ok": False,
                "detail": "Run `hivemind start` to begin syncing sessions",
            }
        )

    # Check 2: Credentials
    creds_file = state_dir / "credentials.json"
    if creds_file.exists():
        try:
            data = json.loads(creds_file.read_text())
            if isinstance(data, dict):
                checks.append({"label": "Credentials file", "ok": True, "detail": "Valid"})
            else:
                checks.append(
                    {
                        "label": "Credentials file",
                        "ok": False,
                        "detail": "Corrupted — run `hivemind doctor --fix`",
                    }
                )
        except Exception:
            checks.append(
                {
                    "label": "Credentials file",
                    "ok": False,
                    "detail": "Corrupted — run `hivemind doctor --fix`",
                }
            )
    else:
        checks.append({"label": "Credentials file", "ok": True, "detail": "Will be created"})

    # Check 3: Homebrew service (macOS)
    if platform.system() == "Darwin":
        try:
            result = subprocess.run(
                ["brew", "services", "info", "wandb/taps/hivemind", "--json"],
                capture_output=True,
                text=True,
                timeout=5,
            )
            if result.returncode == 0:
                svc = json.loads(result.stdout)
                if isinstance(svc, list):
                    svc = svc[0]
                status = svc.get("status", "unknown")
                if status == "started":
                    checks.append({"label": "Homebrew service", "ok": True, "detail": "Running"})
                else:
                    checks.append(
                        {
                            "label": "Homebrew service",
                            "ok": False,
                            "detail": f"Status: {status} — run `brew services start wandb/taps/hivemind`",
                        }
                    )
        except Exception:
            pass  # Not installed via Homebrew, skip

    return checks
