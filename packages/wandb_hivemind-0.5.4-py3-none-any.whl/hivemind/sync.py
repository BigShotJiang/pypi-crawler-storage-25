"""Daemon sync logic for incremental session uploads."""

from __future__ import annotations

import asyncio
import json
import logging
import sqlite3
import time
from dataclasses import dataclass
from enum import Enum
from pathlib import Path
from typing import Iterator

# Import library adapters for entry reading
from agentstream.adapters import get_adapter, get_adapter_for_path, parse_cursor_timestamp
from agentstream.adapters.base import Session

from hivemind.state import DaemonState, ServerState, SessionSyncState
from hivemind.uploader import HeartbeatResult, SessionIngestRequest, SourceEntryInput, Uploader

logger = logging.getLogger(__name__)

# Minimum entries required to upload a session on initial sync.
# Sessions with fewer entries are typically just initialized but never used
# (e.g., Claude sessions with only a file-history-snapshot).
# This only applies to *new* sessions, not incremental updates.
MIN_ENTRIES_FOR_INITIAL_UPLOAD = 2


def _normalize_repo(repo: str) -> str:
    """Normalize a repo identifier for comparison.

    Strips leading protocol, trailing .git, and lowercases.
    Returns e.g. "github.com/org/repo".
    """
    repo = repo.strip().lower()
    is_scp_like = repo.startswith("git@")
    for prefix in ("https://", "http://", "git@"):
        if repo.startswith(prefix):
            repo = repo[len(prefix) :]
    # git@github.com:org/repo → github.com/org/repo
    # Only apply colon→slash for SCP-like URLs (not host:port URLs)
    if is_scp_like and ":" in repo:
        repo = repo.replace(":", "/", 1)
    repo = repo.rstrip("/")
    if repo.endswith(".git"):
        repo = repo[:-4]
    return repo


def repo_matches(git_repo: str, repo_list: list[str]) -> bool:
    """Check if git_repo matches any entry in repo_list.

    Supports two formats in repo_list:
      - "github.com/org/repo" (full match)
      - "org/repo" (shorthand — matches any host)

    Both sides are normalized (case-insensitive, protocol/suffix stripped).
    """
    if not git_repo or not repo_list:
        return False
    normalized = _normalize_repo(git_repo)
    for entry in repo_list:
        entry_norm = _normalize_repo(entry)
        if not entry_norm:
            continue
        if normalized == entry_norm:
            return True
        # Shorthand: entry has no host (single slash like "org/repo")
        if "/" in entry_norm and entry_norm.count("/") == 1:
            # Match against the trailing "org/repo" part of the full repo
            if normalized.endswith("/" + entry_norm):
                return True
    return False


class SyncResult(Enum):
    """Result of a sync_session call."""

    SYNCED = "synced"  # Actually uploaded to server
    SKIPPED = "skipped"  # Skipped (trivial session or no new entries)
    FAILED = "failed"  # Upload failed


@dataclass
class SyncOutcome:
    """Full outcome of a sync_session call."""

    result: SyncResult
    needs_token_refresh: bool = False
    sso_required: bool = False
    sso_org_id: str = ""


def read_entries_after(
    file_path: Path,
    after_index: int = -1,
) -> Iterator[dict]:
    """Stream entries from session file after a given index.

    Uses library adapters for all agent formats.

    Args:
        file_path: Path to session file.
        after_index: Only yield entries with index > after_index.
            Use -1 to read all entries.

    Yields:
        Entry dicts with keys: entry_index, entry_content, entry_timestamp_ms
    """
    adapter = get_adapter_for_path(file_path)
    if not adapter:
        logger.warning(f"No adapter found for {file_path}")
        return

    if not file_path.exists():
        return

    session = Session(
        id=file_path.stem,
        path=file_path,
        format=adapter.name,
        modified_at=file_path.stat().st_mtime,
    )

    for entry in adapter.read_entries_after(session, after_index):
        yield entry


def read_cursor_entries_after(
    vscdb_path: Path,
    composer_id: str,
    cursor_user: str,
    after_index: int = -1,
    session_created_at: int | str | None = None,
    session_last_updated_at: int | str | None = None,
) -> list[dict]:
    """Read Cursor bubble entries after a given index.

    Uses library CursorAdapter.

    Args:
        vscdb_path: Path to workspace state.vscdb file (used to derive paths).
        composer_id: The composerId to read entries for.
        cursor_user: Path to Cursor User directory.
        after_index: Only return entries with index > after_index.
            Use -1 to read all entries.
        session_created_at: Session-level createdAt timestamp from composerData.
            Passed to adapter for synthetic timestamp computation when bubbles
            lack individual createdAt (Cursor v2 format).
        session_last_updated_at: Session-level lastUpdatedAt timestamp from composerData.

    Returns:
        List of entry dicts with keys: entry_index, entry_content, entry_timestamp_ms
    """
    adapter = get_adapter("cursor")
    if not adapter:
        logger.error("CursorAdapter not registered")
        return []

    metadata = {
        "composerId": composer_id,
        "cursor_user": cursor_user,
        "workspace_dir": str(vscdb_path.parent),
    }
    if session_created_at is not None:
        metadata["createdAt"] = session_created_at
    if session_last_updated_at is not None:
        metadata["lastUpdatedAt"] = session_last_updated_at

    session = Session(
        id=composer_id,
        path=vscdb_path,
        format="cursor",
        modified_at=vscdb_path.stat().st_mtime if vscdb_path.exists() else 0,
        metadata=metadata,
    )

    entries = adapter.read_entries_after(session, after_index)

    # Enrich entries with computed diffs for file edits (edit_file_v2 tool calls)
    # This resolves beforeContentId/afterContentId and computes unified diffs
    entries = adapter.enrich_entries(entries, session)

    return entries


class SessionSyncer:
    """Handles incremental session synchronization.

    Tracks per-session sync state and only uploads new entries
    since the last sync. State is scoped per-server endpoint.
    """

    def __init__(
        self,
        state: DaemonState,
        endpoint: str,
        auth_token: str,
        user_id: str = "",
        device_id: str = "",
        email: str = "",
        github_user: str = "",
        credential_created_at: int | None = None,
        private_sessions: bool = False,
        org_repos: list[str] | None = None,
        private_repos: list[str] | None = None,
    ):
        self.state = state
        self.endpoint = endpoint
        self.auth_token = auth_token
        self.user_id = user_id
        self.device_id = device_id
        self.email = email
        self.github_user = github_user
        self.private_sessions = private_sessions
        self.org_repos = org_repos or []
        self.private_repos = private_repos or []
        self._uploader = Uploader(
            endpoint=endpoint,
            auth_token=auth_token,
            credential_created_at=credential_created_at,
        )
        # Get server-scoped state for this endpoint
        self._server_state: ServerState = state.get_server_state(endpoint)

    async def heartbeat(self) -> "HeartbeatResult":
        """Send a keep-alive heartbeat to the backend for this endpoint.

        Thin pass-through so callers (e.g. the daemon main loop) don't have
        to reach into the private `_uploader` attribute.
        """
        return await self._uploader.heartbeat()

    def _resolve_codex_session_id(self, session_id: str, file_path: Path) -> str:
        """Resolve the effective session ID for a Codex session.

        If the session was already being tracked under the filename stem
        (legacy behavior), keep using that ID so the server-side session
        stays consistent. New sessions use the canonical payload.id.
        """
        legacy_id = file_path.stem
        if legacy_id == session_id:
            return session_id

        legacy = self._server_state.sessions.get(legacy_id)
        if not legacy:
            return session_id

        # Only keep legacy ID if the state points at this same file.
        if Path(legacy.file_path) != file_path:
            return session_id

        logger.debug(
            "Codex session %s... already tracked as %s..., keeping legacy ID",
            session_id[:16],
            legacy_id[:16],
        )
        return legacy_id

    def _read_entries(
        self,
        session_id: str,
        file_path: Path,
        source_format: str,
        metadata: dict,
        last_entry_idx: int,
        current_mtime: float,
    ) -> list[dict] | None:
        """Read new entries from disk (synchronous, intended for asyncio.to_thread).

        Returns a list of entry dicts, or None on hard failure.
        """
        if source_format == "cursor":
            composer_id = metadata.get("composerId", session_id)
            cursor_user = metadata.get("cursor_user", "")
            if not cursor_user:
                logger.error(f"Missing cursor_user in metadata for session {session_id[:16]}...")
                return None
            return read_cursor_entries_after(
                file_path,
                composer_id,
                cursor_user,
                last_entry_idx,
                session_created_at=metadata.get("createdAt"),
                session_last_updated_at=metadata.get("lastUpdatedAt"),
            )
        elif source_format == "opencode":
            adapter = get_adapter("opencode")
            if adapter:
                oc_session = Session(
                    id=session_id,
                    path=file_path,
                    format="opencode",
                    modified_at=current_mtime,
                )
                return adapter.read_entries_after(oc_session, last_entry_idx)
            return []
        else:
            return list(read_entries_after(file_path, last_entry_idx))

    async def sync_session(
        self,
        session_id: str,
        file_path: Path,
        source_format: str,
        metadata: dict,
    ) -> SyncOutcome:
        """Sync a single session, uploading only new entries.

        Args:
            session_id: Unique session identifier.
            file_path: Path to session file.
            source_format: Agent type (claude, cursor, etc.)
            metadata: Session metadata for API.

        Returns:
            SyncOutcome with result status and token refresh signal.
        """
        if source_format == "codex":
            session_id = self._resolve_codex_session_id(session_id, file_path)

        # Get or create session sync state (scoped to this server endpoint)
        if session_id not in self._server_state.sessions:
            self._server_state.sessions[session_id] = SessionSyncState(
                file_path=str(file_path),
                last_entry_idx=-1,
                last_mtime=0,
            )

        session_state = self._server_state.sessions[session_id]

        # Check if file exists and get mtime
        try:
            current_mtime = file_path.stat().st_mtime
        except OSError as e:
            logger.error(f"Cannot stat {file_path}: {e}")
            return SyncOutcome(SyncResult.FAILED)

        # Read entries in a thread so asyncio.wait_for can cancel if a
        # SQLite read or JSONL parse blocks longer than the per-session timeout.
        new_entries = await asyncio.to_thread(
            self._read_entries,
            session_id,
            file_path,
            source_format,
            metadata,
            session_state.last_entry_idx,
            current_mtime,
        )
        if new_entries is None:
            # _read_entries returns None on hard failure (e.g. missing metadata)
            return SyncOutcome(SyncResult.FAILED)

        if not new_entries:
            if session_state.last_entry_idx >= 0:
                # Only update mtime if session was previously synced successfully
                session_state.last_mtime = current_mtime
            logger.debug(f"No new entries for session {session_id[:16]}...")
            return SyncOutcome(SyncResult.SKIPPED)

        # Skip trivial sessions on initial sync (not incremental updates)
        # NOTE: We do NOT update last_entry_idx here - we only update it after
        # a successful upload. This ensures we retry trivial sessions if they
        # later get more entries and the upload fails.
        is_initial_sync = session_state.last_entry_idx == -1
        if is_initial_sync and len(new_entries) < MIN_ENTRIES_FOR_INITIAL_UPLOAD:
            logger.debug(
                f"Skipping trivial session {session_id[:16]}... (only {len(new_entries)} entries)"
            )
            # Don't update last_mtime for trivial sessions — they haven't been
            # synced yet and should be retried when they grow past threshold
            return SyncOutcome(SyncResult.SKIPPED)

        logger.info(
            f"Syncing session {session_id[:16]}... "
            f"({len(new_entries)} new entries after idx {session_state.last_entry_idx})"
        )

        # Build request with metadata
        full_metadata = {
            **metadata,
            "user_id": self.user_id,
            "device_id": self.device_id,
            "email": self.email,
            "github_user": self.github_user,
        }
        # Repo-level overrides take precedence over global setting.
        # private_repos (denylist) > org_repos (allowlist) > global private.
        git_repo = full_metadata.get("git_repo", "")
        if git_repo and repo_matches(git_repo, self.private_repos):
            full_metadata["private"] = True
        elif git_repo and repo_matches(git_repo, self.org_repos):
            full_metadata["private"] = False
        elif self.private_sessions:
            full_metadata["private"] = True

        request = SessionIngestRequest(
            agent_session_id=session_id,
            source_format=source_format,
            metadata=full_metadata,
            source_entries=[
                SourceEntryInput(
                    entry_index=entry["entry_index"],
                    entry_content=entry["entry_content"],
                    entry_timestamp_ms=entry["entry_timestamp_ms"],
                )
                for entry in new_entries
            ],
        )

        # Upload
        upload_result = await self._uploader.upload_session(request)

        if upload_result.success:
            # Update state with new high water mark - ONLY on confirmed success
            max_idx = max(e["entry_index"] for e in new_entries)
            old_idx = session_state.last_entry_idx
            session_state.last_entry_idx = max_idx
            session_state.last_mtime = current_mtime
            self._server_state.last_sync_ts = int(time.time() * 1000)
            logger.info(
                f"Session {session_id[:16]}... synced to index {max_idx} "
                f"(was {old_idx}, uploaded {len(new_entries)} entries)"
            )
            return SyncOutcome(
                SyncResult.SYNCED,
                needs_token_refresh=upload_result.needs_token_refresh,
                sso_required=upload_result.sso_required,
                sso_org_id=upload_result.sso_org_id,
            )

        # Upload failed - do NOT update last_entry_idx, will retry on next cycle
        logger.warning(
            f"Session {session_id[:16]}... upload failed, "
            f"last_entry_idx stays at {session_state.last_entry_idx}"
        )
        return SyncOutcome(
            SyncResult.FAILED,
            needs_token_refresh=upload_result.needs_token_refresh,
            sso_required=upload_result.sso_required,
            sso_org_id=upload_result.sso_org_id,
        )


# =============================================================================
# Cursor Incremental Scanning
# =============================================================================


@dataclass
class CursorScanResult:
    """Result of scanning globalStorage for recent Cursor bubbles."""

    composer_ids: set[str]  # ComposerIds with recent bubbles
    max_bubble_ts: int  # Maximum bubble timestamp found (for updating cursor_last_global_scan_ts)


def get_recent_cursor_composer_ids(
    global_state_db: Path,
    since_ts_ms: int,
) -> CursorScanResult:
    """Query globalStorage for composerIds with bubbles created after since_ts.

    This enables incremental scanning: instead of discovering ALL Cursor sessions
    when globalStorage changes, we only find sessions that actually have new bubbles.

    Args:
        global_state_db: Path to Cursor's globalStorage/state.vscdb
        since_ts_ms: Only return composerIds with bubbles created after this timestamp (ms)

    Returns:
        CursorScanResult with composer_ids and max_bubble_ts for state updates
    """
    composer_ids: set[str] = set()
    max_bubble_ts = since_ts_ms  # Start with current value as baseline

    if not global_state_db.exists():
        logger.debug(f"globalStorage DB not found: {global_state_db}")
        return CursorScanResult(composer_ids=composer_ids, max_bubble_ts=max_bubble_ts)

    try:
        conn = sqlite3.connect(f"file:{global_state_db}?mode=ro", uri=True, timeout=10)
        cursor = conn.cursor()

        # Query all bubble entries - keys are formatted as bubbleId:<composerId>:<bubbleId>
        cursor.execute("SELECT key, value FROM cursorDiskKV WHERE key LIKE 'bubbleId:%'")

        total_bubbles = 0
        bubbles_after_ts = 0
        bubbles_no_ts = 0

        for row in cursor.fetchall():
            total_bubbles += 1
            try:
                key = row[0]
                value = row[1]

                # Parse bubble data to get createdAt
                bubble_data = json.loads(value)
                created_at = bubble_data.get("createdAt")

                if created_at:
                    created_ms = parse_cursor_timestamp(created_at)
                    if created_ms:
                        # Track the maximum timestamp we've seen
                        max_bubble_ts = max(max_bubble_ts, created_ms)
                        if created_ms > since_ts_ms:
                            bubbles_after_ts += 1
                            # Extract composerId from key: bubbleId:<composerId>:<bubbleId>
                            parts = key.split(":", 2)
                            if len(parts) >= 2:
                                composer_ids.add(parts[1])
                else:
                    # If bubble has no createdAt, treat it as potentially new
                    # to avoid missing updates from older Cursor versions
                    bubbles_no_ts += 1
                    parts = key.split(":", 2)
                    if len(parts) >= 2:
                        composer_ids.add(parts[1])

            except (json.JSONDecodeError, TypeError, IndexError):
                continue

        conn.close()

        logger.debug(
            f"globalStorage scan: {total_bubbles} total bubbles, "
            f"{bubbles_after_ts} after since_ts, {bubbles_no_ts} without timestamp, "
            f"max_bubble_ts={max_bubble_ts}, since_ts_ms={since_ts_ms}"
        )

    except sqlite3.Error as e:
        logger.warning(f"Error querying globalStorage: {e}")

    return CursorScanResult(composer_ids=composer_ids, max_bubble_ts=max_bubble_ts)


def build_composer_workspace_map(
    workspace_storage: Path,
    target_composer_ids: set[str],
) -> dict[str, tuple[Path, str]]:
    """Build mapping from composerId to (state.vscdb path, folder_path).

    Scans workspace storage directories to find which workspaces contain
    the target composer sessions.

    Args:
        workspace_storage: Path to Cursor's workspaceStorage directory
        target_composer_ids: Set of composerIds to find

    Returns:
        Dict mapping composerId -> (state_db_path, folder_path)
    """
    result: dict[str, tuple[Path, str]] = {}

    if not workspace_storage.exists():
        return result

    remaining = set(target_composer_ids)

    for workspace_dir in workspace_storage.iterdir():
        if not remaining:
            break  # Found all target composers

        if not workspace_dir.is_dir():
            continue

        state_db = workspace_dir / "state.vscdb"
        if not state_db.exists():
            continue

        # Get folder_path from workspace.json
        workspace_json = workspace_dir / "workspace.json"
        folder_path = ""
        if workspace_json.is_file():
            try:
                workspace_data = json.loads(workspace_json.read_text())
                folder = workspace_data.get("folder", "")
                if folder.startswith("file://"):
                    folder_path = folder[7:]
            except (json.JSONDecodeError, OSError):
                # workspace.json may be corrupted or unreadable; folder_path
                # is optional metadata, so continue without it
                pass

        try:
            conn = sqlite3.connect(f"file:{state_db}?mode=ro", uri=True, timeout=10)
            conn.row_factory = sqlite3.Row
            cursor = conn.cursor()

            cursor.execute(
                "SELECT value FROM ItemTable WHERE key = ?",
                ("composer.composerData",),
            )
            row = cursor.fetchone()
            conn.close()

            if not row:
                continue

            # Parse composer data
            value = row["value"]
            if isinstance(value, bytes):
                value = value.decode("utf-8", errors="replace")
            composer_data = json.loads(value)

            if isinstance(composer_data, dict):
                composer_data = composer_data.get("allComposers", [])
            if not isinstance(composer_data, list):
                continue

            # Check each composer against our target set
            for composer in composer_data:
                if not isinstance(composer, dict):
                    continue
                composer_id = composer.get("composerId")
                if composer_id and composer_id in remaining:
                    result[composer_id] = (state_db, folder_path)
                    remaining.discard(composer_id)

        except (sqlite3.Error, json.JSONDecodeError, TypeError, OSError) as e:
            logger.debug(f"Error reading workspace {workspace_dir.name}: {e}")
            continue

    return result
