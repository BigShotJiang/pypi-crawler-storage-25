"""Authentication manager for Hivemind daemon."""

from __future__ import annotations

import base64
import json
import logging
import os
import shutil
import subprocess
import sys
import time
import uuid
from typing import Any

import click
import httpx

from hivemind.auth.credentials import CredentialStore, StoredCredentials
from hivemind.auth.device_flow import DeviceFlowAuth, get_github_client_id
from hivemind.auth.discovery import (
    AuthDiscovery,
    DeviceFlowAuthMethod,
    SSHAuthMethod,
    TokenAuthMethod,
)
from hivemind.auth.hardware import HardwareInfo, collect_hardware_info
from hivemind.auth.oidc import OIDCAuthError, auth_via_oidc_browser, auth_via_oidc_device
from hivemind.auth.ssh_sign import create_ssh_signature

logger = logging.getLogger(__name__)


def _get_git_email() -> str | None:
    """Get the user's email from git config."""
    try:
        result = subprocess.run(
            ["git", "config", "--global", "user.email"],
            capture_output=True,
            text=True,
            timeout=5,
        )
        if result.returncode == 0 and result.stdout.strip():
            return result.stdout.strip()
    except (subprocess.SubprocessError, FileNotFoundError):
        pass
    return None


class AuthError(Exception):
    """Authentication error."""

    pass


class PermanentAuthError(AuthError):
    """Auth error that should not be retried (e.g., org membership restriction).

    Used when the server returns 403 indicating the user is not authorized
    to use the service at all, not just a temporary auth failure.
    """

    pass


class AuthManager:
    """Manages daemon authentication lifecycle."""

    def __init__(
        self,
        endpoint: str,
        credential_store: CredentialStore | None = None,
        config: Any = None,
    ):
        self.endpoint = endpoint.rstrip("/")
        self.store = credential_store or CredentialStore()
        self.discovery = AuthDiscovery()
        self._device_id: str | None = None
        self._hardware_info: HardwareInfo | None = None
        self._config = config
        # Set by daemon when server signals SSO required with a specific org_id
        self.sso_org_id: str | None = None

    @property
    def device_id(self) -> str:
        """Get or create persistent device ID."""
        if self._device_id:
            return self._device_id

        device_file = self.store.config_dir / "device_id"

        if device_file.exists():
            self._device_id = device_file.read_text().strip()
        else:
            self._device_id = str(uuid.uuid4())
            self.store._ensure_config_dir()
            device_file.write_text(self._device_id)
            device_file.chmod(0o600)

        return self._device_id

    @property
    def hardware_info(self) -> HardwareInfo:
        """Get cached hardware information."""
        if self._hardware_info is None:
            self._hardware_info = collect_hardware_info()
        return self._hardware_info

    async def get_token(
        self,
        force_method: str | None = None,
        force_refresh: bool = False,
        preferred_method: str | None = None,
    ) -> str:
        """Get a valid authentication token, refreshing if needed.

        Args:
            force_method: If set, force a specific auth method instead of auto-detect.
                         Values: "ssh", "device", "credential", "gh"
            force_refresh: If True, force re-authentication even if token is still valid.
                          Used when server signals token needs refresh (secret rotation).
            preferred_method: If set, try this method first when auto-detecting.
                            Used to skip slower methods that previously failed.
        """
        # Try loading existing credentials for this endpoint (skip if forcing).
        # Use load_raw() to evaluate freshness against the BASE token's
        # expires_at — load() would apply a cached escalation token but
        # leave expires_at on the base (see _maybe_apply_escalation), which
        # is exactly what we want for refresh decisions. When the base is
        # still fresh, fetch with load() so the returned token is the
        # escalated one if present.
        if not force_method and not force_refresh:
            base = self.store.load_raw(self.endpoint)
            if base and not self.store.is_expired(base):
                escalated = self.store.load(self.endpoint)
                return (escalated or base).token
            creds = base

            if creds:
                logger.info(f"Token expired for {creds.github_user}, re-authenticating...")
                # Use previously successful method as preference for re-auth
                if not preferred_method:
                    preferred_method = creds.auth_method
                # If the stored credentials were OIDC, we MUST NOT silently
                # fall through to auth discovery — discover_all() returns
                # ssh/credential/gh/device methods in preference order, so
                # the daemon would "downgrade" to ssh_signature and the
                # next sync would hit 403 sso_required for SSO-enforced
                # orgs. Try the OIDC refresh path first; if that fails,
                # raise AuthError so the caller (sync loop) can pause and
                # wait for an interactive `hivemind login`.
                if creds.auth_method and creds.auth_method.startswith("oidc_"):
                    refreshed = await self.refresh_via_stored_token()
                    if refreshed:
                        self.store.save(refreshed, self.endpoint)
                        return refreshed.token
                    raise AuthError(
                        "OIDC credentials expired and could not be refreshed. "
                        "Run 'hivemind login' to re-authenticate."
                    )
        else:
            creds = self.store.load(self.endpoint) if force_refresh else None
            if force_refresh and creds:
                logger.info(f"Force refreshing token for {creds.github_user}...")
                if not preferred_method:
                    preferred_method = creds.auth_method
                # OIDC credentials can't be refreshed via SSH/credential discovery —
                # try the OIDC refresh token first to preserve the SSO session.
                # If refresh fails, raise instead of falling through (see the
                # expired-on-load branch above for the same reason).
                if creds.auth_method and creds.auth_method.startswith("oidc_"):
                    refreshed = await self.refresh_via_stored_token()
                    if refreshed:
                        self.store.save(refreshed, self.endpoint)
                        return refreshed.token
                    raise AuthError(
                        "OIDC credentials could not be refreshed. "
                        "Run 'hivemind login' to re-authenticate."
                    )

        new_creds = await self._authenticate(force_method, preferred_method=preferred_method)
        self.store.save(new_creds, self.endpoint)

        return new_creds.token

    async def _authenticate(
        self, force_method: str | None = None, preferred_method: str | None = None
    ) -> StoredCredentials:
        """Perform authentication using discovered or forced method.

        Args:
            force_method: If set, use this specific method instead of auto-detect.
                         Values: "ssh", "device", "credential", "gh"
            preferred_method: If set, try this method first when auto-detecting.
        """
        if force_method:
            return await self._authenticate_forced(force_method)

        auth_methods = self.discovery.discover_all(preferred=preferred_method)
        last_error: AuthError | None = None

        for auth_method in auth_methods:
            try:
                if isinstance(auth_method, SSHAuthMethod):
                    return await self._auth_via_ssh(auth_method)
                elif isinstance(auth_method, TokenAuthMethod):
                    return await self._auth_via_token_exchange(auth_method)
                elif isinstance(auth_method, DeviceFlowAuthMethod):
                    return await self._auth_via_device_flow()
            except PermanentAuthError:
                raise
            except AuthError as e:
                logger.info(f"Auth method failed, trying next: {e}")
                last_error = e
                continue

        if last_error:
            raise last_error
        raise AuthError("No authentication method available")

    async def _authenticate_forced(self, method: str) -> StoredCredentials:
        """Authenticate using a specific forced method."""
        if method == "ssh":
            ssh_method = self._try_ssh_method()
            if not ssh_method:
                raise AuthError("SSH authentication not available (no SSH key or GitHub user)")
            return await self._auth_via_ssh(ssh_method)

        elif method == "device":
            return await self._auth_via_device_flow()

        elif method == "credential":
            token_method = self._try_credential_method()
            if not token_method:
                raise AuthError("Git credential helper not available or no stored credentials")
            return await self._auth_via_token_exchange(token_method)

        elif method == "gh":
            token_method = self._try_gh_method()
            if not token_method:
                raise AuthError("GitHub CLI (gh) not available or not authenticated")
            return await self._auth_via_token_exchange(token_method)

        elif method == "oidc_browser":
            return await self._auth_via_oidc_sso()

        elif method == "oidc_device":
            return await self._auth_via_oidc_device()

        elif method == "oidc_refresh":
            result = await self.refresh_via_stored_token()
            if result:
                return result
            raise AuthError(
                "No refresh token available. "
                "Authenticate with oidc_browser first to obtain a refresh token."
            )

        else:
            raise AuthError(f"Unknown authentication method: {method}")

    def _try_ssh_method(self) -> SSHAuthMethod | None:
        """Try to get SSH auth method."""
        if ssh_key := self.discovery._find_ssh_key():
            if github_user := self.discovery._get_username_via_ssh():
                return SSHAuthMethod(key_path=ssh_key, github_user=github_user)
        return None

    def _try_credential_method(self) -> TokenAuthMethod | None:
        """Try to get git credential helper method."""
        if cred := self.discovery._get_git_credential():
            if github_user := self.discovery._get_username_via_api(cred.password):
                return TokenAuthMethod(
                    token=cred.password, github_user=github_user, source="credential_helper"
                )
        return None

    def _try_gh_method(self) -> TokenAuthMethod | None:
        """Try to get gh CLI method."""
        if gh_token := self.discovery._get_gh_token():
            if github_user := self.discovery._get_username_via_api(gh_token):
                return TokenAuthMethod(token=gh_token, github_user=github_user, source="gh_cli")
        return None

    def _get_github_token_locally(self) -> str | None:
        """Try to get a GitHub token from local sources.

        Probes gh CLI and git credential helper for a token. The token is
        included in the signed SSH payload so the server can query the GitHub
        API for org memberships server-side. This is more secure than sending
        pre-fetched org lists, which a manipulated client could spoof.

        Returns:
            GitHub token string, or None if no token available.
        """
        token = self.discovery._get_gh_token()
        if not token:
            cred = self.discovery._get_git_credential()
            if cred:
                token = cred.password

        if token:
            logger.debug("Found local GitHub token for SSH auth enrichment")

        return token

    async def _auth_via_ssh(self, method: SSHAuthMethod) -> StoredCredentials:
        """Authenticate using SSH signature."""
        git_email = _get_git_email()
        hw = self.hardware_info

        # Include a GitHub token in the signed payload (if available) so the
        # server can query the GitHub API for org memberships directly. This
        # replaces the previous approach of sending pre-fetched org lists,
        # which was vulnerable to spoofing by a manipulated client.
        github_token = self._get_github_token_locally()

        sig_data = create_ssh_signature(
            key_path=method.key_path,
            github_user=method.github_user,
            device_id=self.device_id,
            git_email=git_email,
            github_token=github_token,
        )

        async with httpx.AsyncClient() as client:
            response = await client.post(
                f"{self.endpoint}/v1/auth/ssh",
                json={
                    "github_user": method.github_user,
                    "payload": sig_data["payload"],
                    "signature": sig_data["signature"],
                    "git_email": git_email,
                    **hw.to_dict(),
                },
                timeout=30,
            )

        if response.status_code == 403:
            # Permanent auth failure - user not authorized (e.g., org restriction)
            try:
                detail = response.json().get("detail", response.text)
            except Exception:
                detail = response.text
            raise PermanentAuthError(f"Access denied: {detail}")

        if response.status_code != 200:
            raise AuthError(f"SSH auth failed: {response.text}")

        data = response.json()

        now = int(time.time())
        return StoredCredentials(
            token=data["token"],
            user_id=data["user_id"],
            github_user=data["github_user"],
            email=data["email"],
            expires_at=data["expires_at"],
            auth_method="ssh_signature",
            device_id=self.device_id,
            created_at=now,
            updated_at=now,
        )

    async def _auth_via_token_exchange(
        self,
        method: TokenAuthMethod,
        preserve_created_at: int | None = None,
    ) -> StoredCredentials:
        """Authenticate by exchanging GitHub token."""
        git_email = _get_git_email()
        hw = self.hardware_info

        async with httpx.AsyncClient() as client:
            response = await client.post(
                f"{self.endpoint}/v1/auth/exchange",
                json={
                    "github_token": method.token,
                    "auth_method": method.source,
                    "device_id": self.device_id,
                    "git_email": git_email,
                    **hw.to_dict(),
                },
                timeout=30,
            )

        if response.status_code == 403:
            # Permanent auth failure - user not authorized (e.g., org restriction)
            try:
                detail = response.json().get("detail", response.text)
            except Exception:
                detail = response.text
            raise PermanentAuthError(f"Access denied: {detail}")

        if response.status_code != 200:
            raise AuthError(f"Token exchange failed: {response.text}")

        data = response.json()

        # Determine refresh token: prefer what the method provides (e.g., GitHub device flow)
        refresh_fields: dict = {}
        if method.refresh_token:
            refresh_fields["refresh_token"] = method.refresh_token
            refresh_fields["refresh_token_type"] = "github"

        now = int(time.time())
        return StoredCredentials(
            token=data["token"],
            user_id=data["user_id"],
            github_user=data["github_user"],
            email=data["email"],
            expires_at=data["expires_at"],
            auth_method=method.source,
            device_id=self.device_id,
            created_at=preserve_created_at if preserve_created_at is not None else now,
            updated_at=now,
            **refresh_fields,
        )

    async def _auth_via_device_flow(self) -> StoredCredentials:
        """Authenticate using OAuth device flow."""
        device_flow = DeviceFlowAuth(endpoint=self.endpoint)
        method = await device_flow.authenticate()

        return await self._auth_via_token_exchange(method)

    async def _auth_via_oidc_sso(self) -> StoredCredentials:
        """Authenticate via SSO with smart flow selection.

        Picks the best OIDC flow based on the environment:
        - No TTY: fail immediately (can't do interactive auth)
        - SSH session: use device flow (browser won't open on remote machine)
        - Local TTY: try browser flow, fall back to device flow on timeout
        """
        if not sys.stdin.isatty():
            raise AuthError(
                "SSO authentication requires an interactive terminal. "
                "Run 'hivemind login' from a terminal."
            )

        # SSH session: browser won't work, go straight to device flow
        if os.environ.get("SSH_CLIENT") or os.environ.get("SSH_TTY"):
            logger.info("SSH session detected, using OIDC device flow")
            return await self._auth_via_oidc_device()

        # Local TTY: try browser, fall back to device on failure
        try:
            return await self._auth_via_oidc_browser()
        except OIDCAuthError as e:
            logger.info(f"Browser OIDC flow failed ({e}), falling back to device flow")
            return await self._auth_via_oidc_device()

    async def _auth_via_oidc_browser(self, acr_values: str = "") -> StoredCredentials:
        """Authenticate via OIDC browser PKCE flow.

        Opens the system browser to the OIDC login page. FastPass handles
        authentication silently on Macs with Okta Verify. The token is
        delivered back to a local loopback server.

        Args:
            acr_values: Optional ACR value (e.g. "phrh" for biometric).
        """
        org_id = self._get_sso_org_id()
        result = await auth_via_oidc_browser(
            endpoint=self.endpoint,
            org_id=org_id,
            acr_values=acr_values,
        )
        return self._credentials_from_oidc_result(result, "oidc_browser")

    async def auth_via_oidc_escalation(self) -> dict:
        """Run a phrh OIDC step-up flow to obtain an escalation token.

        Reuses the same loopback/browser machinery as regular OIDC login but
        requests ``purpose=escalation`` and parses the escalation-shaped
        form_post response. Returns a dict with ``escalation_token``,
        ``user_id``, ``expires_at``. The caller persists it via
        ``CredentialStore.save_escalation``.
        """
        org_id = self._get_sso_org_id()
        return await auth_via_oidc_browser(
            endpoint=self.endpoint,
            org_id=org_id,
            acr_values="phrh",
            purpose="escalation",
        )

    async def _auth_via_oidc_device(self) -> StoredCredentials:
        """Authenticate via OIDC Device Authorization Grant.

        Displays a URL and code for the user to enter on another device.
        Works over SSH and headless environments.
        """
        org_id = self._get_sso_org_id()

        cols = shutil.get_terminal_size().columns
        _was_spinner = False

        def _device_status(msg: str) -> None:
            nonlocal _was_spinner
            if "Waiting" in msg and "..." in msg:
                click.echo(f"\r{msg:{cols}}", nl=False)
                _was_spinner = True
            else:
                if _was_spinner:
                    click.echo(f"\r{'':{cols}}\r", nl=False)
                    _was_spinner = False
                click.echo(msg)

        result = await auth_via_oidc_device(
            endpoint=self.endpoint,
            org_id=org_id,
            on_status=_device_status,
        )
        return self._credentials_from_oidc_result(result, "oidc_device")

    async def refresh_via_stored_token(self) -> StoredCredentials | None:
        """Attempt to refresh credentials using a stored refresh token.

        Supports two refresh token types:
        - "okta": Uses Okta's token endpoint directly (preserves device IP recognition)
        - "github": Uses GitHub's token endpoint to refresh the access token

        Returns new StoredCredentials on success, None on failure.
        """
        creds = self.store.load(self.endpoint)
        if not creds or not creds.refresh_token or not creds.refresh_token_type:
            return None

        # Check if refresh token itself has expired
        if creds.refresh_token_expires_at and time.time() >= creds.refresh_token_expires_at:
            logger.info("Refresh token expired, cannot use for silent refresh")
            return None

        try:
            if creds.refresh_token_type == "okta":
                return await self._refresh_via_okta(creds)
            elif creds.refresh_token_type == "github":
                return await self._refresh_via_github(creds)
            else:
                logger.warning("Unknown refresh_token_type: %s", creds.refresh_token_type)
                return None
        except Exception as e:
            logger.info("Refresh token exchange failed: %s", e)
            return None

    async def _refresh_via_okta(self, creds: StoredCredentials) -> StoredCredentials | None:
        """Refresh using Okta's token endpoint directly.

        Calls Okta directly from the daemon (not proxied through our server)
        to preserve IP-based device recognition, matching the OOB auth pattern.
        """
        org_id = self._get_sso_org_id()

        # Fetch OIDC config from our server
        async with httpx.AsyncClient() as client:
            config_resp = await client.get(
                f"{self.endpoint}/v1/auth/oidc/config",
                params={"org_id": org_id},
                timeout=10,
            )
        if config_resp.status_code != 200:
            logger.warning("Failed to fetch OIDC config for token refresh")
            return None

        oidc_config = config_resp.json()
        issuer = oidc_config.get("issuer", "")
        client_id = oidc_config.get("client_id", "")
        client_secret = oidc_config.get("client_secret", "")
        if not issuer or not client_id:
            return None

        # Use the issuer's token endpoint (works for both org-level and custom
        # authorization servers like /oauth2/ausXXX).
        token_url = f"{issuer.rstrip('/')}/v1/token"

        # Call Okta directly with the refresh token
        assert creds.refresh_token is not None  # Guaranteed by caller
        token_data: dict[str, str] = {
            "client_id": client_id,
            "grant_type": "refresh_token",
            "refresh_token": creds.refresh_token,
            "scope": "openid email profile offline_access",
        }
        if client_secret:
            token_data["client_secret"] = client_secret

        async with httpx.AsyncClient() as client:
            resp = await client.post(
                token_url,
                data=token_data,
                headers={"Accept": "application/json"},
                timeout=10,
            )

        if resp.status_code != 200:
            logger.info("Okta refresh token exchange failed: %s", resp.text)
            return None

        okta_tokens = resp.json()
        id_token = okta_tokens.get("id_token", "")
        if not id_token:
            return None

        # Exchange the new ID token with our server for a fresh AgentStream JWT
        async with httpx.AsyncClient() as client:
            resp = await client.post(
                f"{self.endpoint}/v1/auth/oidc/exchange",
                json={
                    "id_token": id_token,
                    "org_id": org_id,
                    "auth_method": creds.auth_method,
                },
                timeout=10,
            )

        if resp.status_code != 200:
            logger.info("Server token exchange after Okta refresh failed: %s", resp.text)
            return None

        result = resp.json()

        # Capture the new refresh token (Okta may rotate it)
        new_refresh_token = okta_tokens.get("refresh_token", creds.refresh_token)

        new_creds = StoredCredentials(
            token=result["token"],
            user_id=result["user_id"],
            github_user=result["github_user"],
            email=result["email"],
            expires_at=result["expires_at"],
            auth_method=creds.auth_method,
            device_id=self.device_id,
            created_at=creds.created_at,  # preserve interactive-login timestamp across refresh
            updated_at=int(time.time()),
            refresh_token=new_refresh_token,
            refresh_token_type="okta",
        )

        self.store.save(new_creds, self.endpoint)
        logger.info("Token refreshed via Okta refresh token for %s", creds.github_user)
        return new_creds

    async def _refresh_via_github(self, creds: StoredCredentials) -> StoredCredentials | None:
        """Refresh using GitHub's token endpoint.

        Uses the stored GitHub refresh token to get a new access token,
        then exchanges it for a fresh AgentStream JWT.
        """
        client_id = get_github_client_id(self.endpoint)

        async with httpx.AsyncClient() as client:
            resp = await client.post(
                "https://github.com/login/oauth/access_token",
                data={
                    "client_id": client_id,
                    "grant_type": "refresh_token",
                    "refresh_token": creds.refresh_token,
                },
                headers={"Accept": "application/json"},
                timeout=30,
            )

        if resp.status_code != 200:
            logger.info("GitHub refresh token exchange failed: HTTP %s", resp.status_code)
            return None

        data = resp.json()
        if "access_token" not in data:
            logger.info("GitHub refresh response missing access_token: %s", data.get("error"))
            return None

        new_access_token = data["access_token"]
        new_refresh_token = data.get("refresh_token", creds.refresh_token)

        # Exchange the new GitHub token for an AgentStream JWT
        method = TokenAuthMethod(
            token=new_access_token,
            github_user=creds.github_user,
            source=creds.auth_method,
            refresh_token=new_refresh_token,
        )

        try:
            new_creds = await self._auth_via_token_exchange(
                method, preserve_created_at=creds.created_at
            )
            self.store.save(new_creds, self.endpoint)
            logger.info("Token refreshed via GitHub refresh token for %s", creds.github_user)
            return new_creds
        except (AuthError, PermanentAuthError):
            return None

    def _get_sso_org_id(self) -> str:
        """Get the SSO org ID from override, environment, stored creds, or JWT.

        Priority:
        1. sso_org_id attribute (set by daemon when server signals SSO required)
        2. HIVEMIND_ORG_ID environment variable (set by MDM or admin)
        3. Stored credentials for this endpoint (persisted per-endpoint from a
           previous sso_required signal)
        4. Existing JWT from a previous session
        """
        # Check override first (set by daemon run loop from 403 response)
        if self.sso_org_id:
            return self.sso_org_id

        # Check environment variable (MDM-provisioned devices)
        env_org_id = os.environ.get("HIVEMIND_ORG_ID", "")
        if env_org_id:
            return env_org_id

        # Check stored credentials (persisted per-endpoint from a previous
        # sso_required signal)
        existing = self.store.load(self.endpoint)
        if existing and existing.sso_org_id:
            return existing.sso_org_id

        # Check if we have it from the JWT of a previous session
        if existing:
            try:
                payload_b64 = existing.token.split(".")[1]
                payload_b64 += "=" * ((-len(payload_b64)) % 4)
                payload = json.loads(base64.urlsafe_b64decode(payload_b64))
                org_id = payload.get("org_id", "")
                if org_id:
                    return org_id
            except Exception:
                pass

        raise AuthError(
            "OIDC SSO requires an organization ID. "
            "Set HIVEMIND_ORG_ID environment variable or authenticate with "
            "another method first to establish your organization."
        )

    def _credentials_from_oidc_result(self, result: dict, auth_method: str) -> StoredCredentials:
        """Build StoredCredentials from an OIDC auth result dict."""
        now = int(time.time())
        return StoredCredentials(
            token=result["token"],
            user_id=result["user_id"],
            github_user=result["github_user"],
            email=result["email"],
            expires_at=result["expires_at"],
            auth_method=auth_method,
            device_id=self.device_id,
            created_at=now,
            updated_at=now,
            **self._extract_refresh_fields(result),
        )

    @staticmethod
    def _extract_refresh_fields(result: dict) -> dict:
        """Extract refresh token fields from an auth result dict."""
        fields: dict = {}
        if result.get("refresh_token"):
            fields["refresh_token"] = result["refresh_token"]
        if result.get("refresh_token_type"):
            fields["refresh_token_type"] = result["refresh_token_type"]
        if result.get("refresh_token_expires_at"):
            fields["refresh_token_expires_at"] = result["refresh_token_expires_at"]
        return fields

    def get_auth_header(self, token: str) -> dict[str, str]:
        """Get Authorization header for requests."""
        return {"Authorization": f"Bearer {token}"}

    async def whoami(self) -> dict | None:
        """Return current authenticated user info for this endpoint."""
        creds = self.store.load(self.endpoint)
        if not creds:
            return None

        return {
            "user_id": creds.user_id,
            "github_user": creds.github_user,
            "email": creds.email,
            "auth_method": creds.auth_method,
            "expires_at": creds.expires_at,
            "expired": self.store.is_expired(creds, buffer_seconds=0),
            "endpoint": self.endpoint,
        }

    def logout(self) -> None:
        """Clear stored credentials for this endpoint."""
        self.store.clear(self.endpoint)
        logger.info(f"Logged out from {self.endpoint}, credentials cleared")
