"""Authentication module for agentstream daemon."""

from hivemind.auth.credentials import CredentialStore, KeychainLockedError, StoredCredentials
from hivemind.auth.device_flow import DeviceFlowAuth
from hivemind.auth.discovery import (
    AuthDiscovery,
    Credential,
    DeviceFlowAuthMethod,
    SSHAuthMethod,
    TokenAuthMethod,
)
from hivemind.auth.manager import AuthError, AuthManager
from hivemind.auth.ssh_sign import SSHSignError, create_ssh_signature

__all__ = [
    "StoredCredentials",
    "CredentialStore",
    "KeychainLockedError",
    "AuthDiscovery",
    "SSHAuthMethod",
    "TokenAuthMethod",
    "DeviceFlowAuthMethod",
    "Credential",
    "create_ssh_signature",
    "SSHSignError",
    "AuthManager",
    "AuthError",
    "DeviceFlowAuth",
]
