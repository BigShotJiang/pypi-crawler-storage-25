"""Hardware information collection for device verification."""

from __future__ import annotations

import logging
import platform
import subprocess
from dataclasses import dataclass, field

logger = logging.getLogger(__name__)


@dataclass
class HardwareInfo:
    """Hardware identifiers for device verification."""

    serial_number: str | None
    hardware_uuid: str | None
    machine_id: str | None
    hostname: str
    os: str
    os_version: str
    mac_addresses: list[str] = field(default_factory=list)

    def to_dict(self) -> dict:
        """Return all fields as a dictionary."""
        return {
            "serial_number": self.serial_number,
            "hardware_uuid": self.hardware_uuid,
            "machine_id": self.machine_id,
            "hostname": self.hostname,
            "os": self.os,
            "os_version": self.os_version,
            "mac_addresses": self.mac_addresses,
        }


def collect_hardware_info() -> HardwareInfo:
    """Collect hardware information for the current platform.

    Returns:
        HardwareInfo with platform-specific identifiers.
    """
    system = platform.system().lower()

    if system == "darwin":
        return _collect_macos()
    elif system == "linux":
        return _collect_linux()
    elif system == "windows":
        return _collect_windows()
    else:
        return _collect_fallback()


def _collect_macos() -> HardwareInfo:
    """Collect hardware info on macOS using ioreg."""
    serial_number = None
    hardware_uuid = None

    try:
        # Get IOPlatformSerialNumber
        result = subprocess.run(
            ["ioreg", "-rd1", "-c", "IOPlatformExpertDevice"],
            capture_output=True,
            timeout=10,
        )
        if result.returncode == 0:
            output = result.stdout.decode()
            for line in output.split("\n"):
                if "IOPlatformSerialNumber" in line:
                    # Format: "IOPlatformSerialNumber" = "XXXXXX"
                    parts = line.split("=")
                    if len(parts) >= 2:
                        serial_number = parts[1].strip().strip('"')
                elif "IOPlatformUUID" in line:
                    # Format: "IOPlatformUUID" = "XXXXXXXX-XXXX-XXXX-XXXX-XXXXXXXXXXXX"
                    parts = line.split("=")
                    if len(parts) >= 2:
                        hardware_uuid = parts[1].strip().strip('"')
    except (subprocess.TimeoutExpired, FileNotFoundError, OSError) as e:
        logger.warning(f"Failed to run ioreg: {e}")

    return HardwareInfo(
        serial_number=serial_number,
        hardware_uuid=hardware_uuid,
        machine_id=None,  # macOS doesn't have machine-id
        hostname=platform.node(),
        os="darwin",
        os_version=platform.release(),
        mac_addresses=_get_mac_addresses(),
    )


def _collect_linux() -> HardwareInfo:
    """Collect hardware info on Linux from DMI and machine-id.

    Note: serial_number and hardware_uuid require root to read from
    /sys/class/dmi/id/. Falls back gracefully to machine_id which is
    always readable.
    """
    serial_number = None
    hardware_uuid = None
    machine_id = None

    # Try to read DMI info (requires root)
    try:
        with open("/sys/class/dmi/id/product_serial") as f:
            serial_number = f.read().strip() or None
    except (PermissionError, FileNotFoundError, OSError) as e:
        logger.debug(f"Could not read product_serial: {e}")

    try:
        with open("/sys/class/dmi/id/product_uuid") as f:
            hardware_uuid = f.read().strip() or None
    except (PermissionError, FileNotFoundError, OSError) as e:
        logger.debug(f"Could not read product_uuid: {e}")

    # machine-id is always readable
    try:
        with open("/etc/machine-id") as f:
            machine_id = f.read().strip() or None
    except (FileNotFoundError, OSError) as e:
        logger.warning(f"Could not read machine-id: {e}")

    return HardwareInfo(
        serial_number=serial_number,
        hardware_uuid=hardware_uuid,
        machine_id=machine_id,
        hostname=platform.node(),
        os="linux",
        os_version=platform.release(),
        mac_addresses=_get_mac_addresses(),
    )


def _collect_windows() -> HardwareInfo:
    """Collect hardware info on Windows using WMIC and registry."""
    serial_number = None
    hardware_uuid = None
    machine_id = None

    # Get BIOS serial number via WMIC
    try:
        result = subprocess.run(
            ["wmic", "bios", "get", "serialnumber"],
            capture_output=True,
            timeout=10,
        )
        if result.returncode == 0:
            lines = result.stdout.decode().strip().split("\n")
            if len(lines) >= 2:
                serial_number = lines[1].strip() or None
    except (subprocess.TimeoutExpired, FileNotFoundError, OSError) as e:
        logger.warning(f"Failed to get BIOS serial: {e}")

    # Get system UUID via WMIC
    try:
        result = subprocess.run(
            ["wmic", "csproduct", "get", "uuid"],
            capture_output=True,
            timeout=10,
        )
        if result.returncode == 0:
            lines = result.stdout.decode().strip().split("\n")
            if len(lines) >= 2:
                hardware_uuid = lines[1].strip() or None
    except (subprocess.TimeoutExpired, FileNotFoundError, OSError) as e:
        logger.warning(f"Failed to get system UUID: {e}")

    # Get MachineGuid from registry
    try:
        result = subprocess.run(
            [
                "reg",
                "query",
                "HKLM\\SOFTWARE\\Microsoft\\Cryptography",
                "/v",
                "MachineGuid",
            ],
            capture_output=True,
            timeout=10,
        )
        if result.returncode == 0:
            output = result.stdout.decode()
            for line in output.split("\n"):
                if "MachineGuid" in line:
                    parts = line.split()
                    if len(parts) >= 3:
                        machine_id = parts[-1].strip()
    except (subprocess.TimeoutExpired, FileNotFoundError, OSError) as e:
        logger.warning(f"Failed to get MachineGuid: {e}")

    return HardwareInfo(
        serial_number=serial_number,
        hardware_uuid=hardware_uuid,
        machine_id=machine_id,
        hostname=platform.node(),
        os="windows",
        os_version=platform.release(),
        mac_addresses=_get_mac_addresses(),
    )


def _collect_fallback() -> HardwareInfo:
    """Fallback for unknown platforms."""
    logger.warning(f"Unknown platform: {platform.system()}, using fallback collection")
    return HardwareInfo(
        serial_number=None,
        hardware_uuid=None,
        machine_id=None,
        hostname=platform.node(),
        os=platform.system().lower(),
        os_version=platform.release(),
        mac_addresses=_get_mac_addresses(),
    )


def _is_physical_interface(name: str) -> bool:
    """Check if interface name looks like a physical network interface.

    Filters out virtual, tunnel, bridge, and system interfaces to return
    only likely physical WiFi/Ethernet adapters.
    """
    name_lower = name.lower()

    # Loopback
    if name_lower in ("lo", "lo0", "loopback"):
        return False

    # macOS virtual/system interfaces
    if name_lower.startswith(
        (
            "awdl",  # AirDrop Wireless Direct Link
            "llw",  # Low Latency WLAN (AirPlay)
            "anpi",  # Apple Network Protocol Interface
            "ap",  # Access Point (hotspot mode)
            "bridge",  # Network bridges
            "utun",  # VPN tunnels
            "gif",  # Generic tunnel interface
            "stf",  # 6to4 tunnel interface
            "vmenet",  # VMware network
            "vnic",  # Virtual NIC
        )
    ):
        return False

    # Linux virtual interfaces
    if name_lower.startswith(
        (
            "virbr",  # libvirt bridge
            "docker",  # Docker bridge
            "br-",  # Docker/container bridge
            "veth",  # Virtual ethernet (containers)
            "tun",  # VPN tunnel
            "tap",  # TAP device
            "vbox",  # VirtualBox
            "vmnet",  # VMware
        )
    ):
        return False

    # Windows virtual interfaces (partial names in description)
    if any(v in name_lower for v in ("virtual", "vpn", "tunnel", "loopback")):
        return False

    return True


def _get_mac_addresses() -> list[str]:
    """Get MAC addresses of physical network interfaces using psutil.

    Returns:
        List of MAC addresses in standard colon-separated format.
        Only includes physical WiFi/Ethernet interfaces, excluding
        virtual, tunnel, bridge, and system interfaces.
    """
    try:
        import psutil  # noqa: PLC0415

        mac_addresses = []
        net_if_addrs = psutil.net_if_addrs()

        for interface_name, addrs in net_if_addrs.items():
            # Skip non-physical interfaces
            if not _is_physical_interface(interface_name):
                continue

            for addr in addrs:
                # AF_LINK (macOS) or AF_PACKET (Linux) contains MAC address
                # psutil uses family value 17 for AF_PACKET on Linux
                # and -1 for AF_LINK on macOS
                if addr.family in (psutil.AF_LINK, 17, -1):
                    mac = addr.address
                    # Validate MAC address format and skip empty/invalid
                    if mac and mac != "00:00:00:00:00:00" and ":" in mac:
                        # Normalize to uppercase
                        mac_addresses.append(mac.upper())

        return sorted(set(mac_addresses))
    except ImportError:
        logger.warning("psutil not available, cannot get MAC addresses")
        return []
    except Exception as e:
        logger.warning(f"Failed to get MAC addresses: {e}")
        return []
