"""Secure credential storage for Hivemind daemon.

Secrets (tokens) are stored in the system keychain when available (macOS Keychain,
Linux Secret Service). Non-sensitive metadata stays in ~/.hivemind/credentials.json.
Falls back to file-based storage when no keychain is available.
"""

from __future__ import annotations

import json
import logging
import platform
import stat
import subprocess
import sys
import time
from dataclasses import dataclass, field
from pathlib import Path
from typing import Protocol, runtime_checkable
from urllib.parse import urlparse

from pydantic import BaseModel, ValidationError

logger = logging.getLogger(__name__)

# Current credentials file format version
CREDENTIALS_VERSION = 2

# Sentinel value written to JSON when the real token is stored in the keychain
KEYCHAIN_SENTINEL = "__keychain__"

# Service name used for keychain storage (matches pattern of gh:github.com)
KEYCHAIN_SERVICE = "hivemind"


class StoredCredentials(BaseModel):
    """Persisted authentication credentials."""

    token: str
    user_id: str
    github_user: str
    email: str
    expires_at: int  # Unix timestamp
    auth_method: str  # ssh_signature, credential_helper, gh_cli, device_flow, oidc_*
    device_id: str
    created_at: int  # Unix timestamp of the last *interactive* login. Never bumped on refresh.
    updated_at: int | None = (
        None  # Unix timestamp of the last write (refresh or login). None for legacy creds.
    )
    # Refresh token fields (optional, populated when IDP provides them)
    refresh_token: str | None = None
    refresh_token_expires_at: int | None = None
    refresh_token_type: str | None = None  # "okta", "github"
    # Optional escalation token (super_admin opt-in via `hivemind login --sudo`).
    # Bound to the same user_id as the base token, short-lived (~1 hour).
    # When this token is present and unexpired, CredentialStore.load() returns
    # creds with `token` swapped to escalation_token so downstream HTTP calls
    # use the elevated session automatically.
    escalation_token: str | None = None
    escalation_expires_at: int | None = None
    # Org ID to use for SSO/OIDC flows against this endpoint. Populated when
    # the server signals `sso_required` (heartbeat, ingest 403, or /v1/auth/me).
    # Stored per-endpoint so switching endpoints (e.g. prod → localhost) does
    # not carry over a stale org_id.
    sso_org_id: str | None = None

    @property
    def last_refreshed_at(self) -> int:
        """When the credentials were last written. Falls back to created_at for legacy creds."""
        return self.updated_at if self.updated_at is not None else self.created_at

    @property
    def age_days(self) -> float:
        """Days since the last interactive login."""
        return (time.time() - self.created_at) / 86400.0


def _normalize_endpoint(endpoint: str) -> str:
    """Normalize endpoint URL for consistent key usage.

    Removes trailing slashes and path components, keeping only scheme://host:port.
    Falls back to the original endpoint (sans trailing slashes) if it cannot
    be parsed into a scheme and netloc.
    """
    # Normalize basic whitespace first
    endpoint = endpoint.strip()
    if not endpoint:
        # Empty endpoint; nothing to normalize
        return ""

    parsed = urlparse(endpoint)

    # If parsing did not produce a usable scheme and netloc, avoid constructing
    # malformed values like "://". Fall back to the original endpoint.
    if not parsed.scheme or not parsed.netloc:
        logger.warning("Unable to normalize endpoint %r: missing scheme or netloc", endpoint)
        return endpoint.rstrip("/")
    # Reconstruct with just scheme and netloc (host:port)
    normalized = f"{parsed.scheme}://{parsed.netloc}"
    return normalized.rstrip("/")


# ---------------------------------------------------------------------------
# Secret backend abstraction
# ---------------------------------------------------------------------------

# Fields that are considered secrets and should be stored in the keychain
_SECRET_FIELDS = ("token", "refresh_token", "escalation_token")


def _maybe_apply_escalation(creds: StoredCredentials) -> StoredCredentials:
    """Return a copy of *creds* with token swapped to escalation_token, if valid.

    Falls through silently when no escalation token is stored or it has expired.

    Only the ``token`` field is swapped — ``expires_at`` is left pointing at
    the base credential. Swapping ``expires_at`` to the escalation's ~1h
    expiry would trip ``CredentialStore.is_expired()``'s fixed 3600s refresh
    buffer on every call (``now >= exp - 3600``), causing downstream callers
    like ``AuthManager.get_token()`` to misidentify a freshly-minted
    escalation as expired and re-authenticate on every request — dropping
    the escalation in the process.

    Callers that need to reason about base-token freshness (for refresh
    decisions) should use ``load_raw()`` and check ``is_expired()`` against
    the base credential, then use ``load()`` to pick up the escalated token
    for the actual request.
    """
    if not creds.escalation_token or not creds.escalation_expires_at:
        return creds
    if time.time() >= creds.escalation_expires_at:
        return creds
    return creds.model_copy(update={"token": creds.escalation_token})


class KeychainLockedError(Exception):
    """Raised when the system keychain is available but locked.

    Callers can catch this to show a user-friendly message like
    "keychain is locked, please run `hivemind login`" instead of
    a generic authentication failure.
    """

    pass


@runtime_checkable
class SecretBackend(Protocol):
    """Protocol for storing secret credential fields."""

    def store(self, endpoint_key: str, secrets: dict[str, str]) -> None:
        """Store secrets for an endpoint."""
        ...

    def load(self, endpoint_key: str) -> dict[str, str] | None:
        """Load secrets for an endpoint. Returns None if not found."""
        ...

    def delete(self, endpoint_key: str) -> None:
        """Delete secrets for an endpoint."""
        ...

    @property
    def is_keychain(self) -> bool:
        """Whether this backend uses a real system keychain."""
        ...

    def is_unlocked(self) -> bool:
        """Whether the keychain is currently unlocked and usable."""
        ...

    @property
    def backend_name(self) -> str:
        """Human-readable name for the backend (e.g. 'GNOME Keyring', 'macOS Keychain')."""
        ...


class KeychainBackend:
    """Stores secrets in the system keychain via the `keyring` library.

    On macOS this uses Keychain, on Linux it uses Secret Service (GNOME Keyring,
    KWallet, KeePassXC). Falls back to raising RuntimeError if no usable
    backend is available.
    """

    def __init__(self) -> None:
        import keyring as _keyring  # noqa: PLC0415 — optional dep, lazy to avoid import-time cost when keychain unused
        from keyring.errors import KeyringLocked, NoKeyringError  # noqa: PLC0415 — optional dep

        self._keyring = _keyring
        self._KeyringLocked = KeyringLocked
        # Verify a real backend is available (not the fail/null backend)
        try:
            backend = _keyring.get_keyring()
            self._backend_class_name = type(backend).__name__
            backend_name = self._backend_class_name.lower()
            if "fail" in backend_name or "null" in backend_name:
                raise RuntimeError(f"No usable keyring backend: {backend_name}")
        except NoKeyringError:
            raise RuntimeError("No keyring backend available")

        logger.debug("Keychain backend: %s", self._backend_class_name)

    def store(self, endpoint_key: str, secrets: dict[str, str]) -> None:
        try:
            self._keyring.set_password(KEYCHAIN_SERVICE, endpoint_key, json.dumps(secrets))
        except self._KeyringLocked:
            raise KeychainLockedError(
                f"System keychain ({self.backend_name}) is locked. "
                "Unlock it or run `hivemind login` to re-authenticate."
            )

    def load(self, endpoint_key: str) -> dict[str, str] | None:
        try:
            data = self._keyring.get_password(KEYCHAIN_SERVICE, endpoint_key)
        except self._KeyringLocked:
            raise KeychainLockedError(
                f"System keychain ({self.backend_name}) is locked. "
                "Unlock it or run `hivemind login` to re-authenticate."
            )
        if data:
            try:
                return json.loads(data)
            except (json.JSONDecodeError, ValueError):
                logger.warning("Corrupted keychain entry for %s, deleting", endpoint_key)
                self.delete(endpoint_key)
        return None

    def delete(self, endpoint_key: str) -> None:
        try:
            self._keyring.delete_password(KEYCHAIN_SERVICE, endpoint_key)
        except self._KeyringLocked:
            logger.warning("Cannot delete keychain entry: keychain is locked")
        except Exception:
            pass  # Entry may not exist

    @property
    def is_keychain(self) -> bool:
        return True

    def is_unlocked(self) -> bool:
        """Probe whether the keychain is currently unlocked.

        Performs a no-op read of a non-existent key. If the keychain is locked,
        the read will raise KeyringLocked.
        """
        try:
            self._keyring.get_password(KEYCHAIN_SERVICE, "__unlock_probe__")
            return True
        except self._KeyringLocked:
            return False
        except Exception:
            # Any other error (e.g. D-Bus timeout) — assume not usable
            return False

    @property
    def backend_name(self) -> str:
        name = self._backend_class_name
        # Map class names to friendly names
        if "SecretService" in name:
            return "GNOME Keyring (Secret Service)"
        if "macOS" in name or "Keychain" in name:
            return "macOS Keychain"
        if "KWallet" in name:
            return "KDE Wallet (KWallet)"
        return name


class MacOSKeychainBackend:
    """Stores secrets in the macOS Keychain via the ``security`` CLI.

    This avoids the OS prompt ("Do you want to allow python to access…")
    that the ``keyring`` Python library triggers, because ``keyring`` creates
    items whose ACL is locked to the calling Python binary—and that path
    changes on every Homebrew upgrade.

    By calling ``/usr/bin/security`` directly (without ``-T``), the item's
    default ACL trusts ``/usr/bin/security`` itself for decrypt operations.
    Since all reads and writes go through the same stable system binary,
    no prompt is ever shown.

    Uses a distinct service name so that legacy items created by the
    ``keyring`` library are never touched—avoiding ACL prompts on any
    access to those old items.
    """

    # Distinct from KEYCHAIN_SERVICE ("hivemind") used by KeychainBackend.
    # Old keyring-created items under "hivemind" are simply orphaned and
    # never accessed, avoiding any macOS ACL prompts.
    SERVICE = "hivemind-cli"

    def __init__(self) -> None:
        if sys.platform != "darwin":
            raise RuntimeError("MacOSKeychainBackend is only available on macOS")
        # Verify the security CLI exists
        try:
            subprocess.run(
                ["security", "help"],
                capture_output=True,
                timeout=5,
            )
        except (FileNotFoundError, subprocess.SubprocessError) as e:
            raise RuntimeError(f"macOS security CLI not available: {e}") from e

    def _run_security(
        self, args: list[str], *, timeout: int = 30
    ) -> subprocess.CompletedProcess[str]:
        """Run a `security` CLI command, converting exceptions to safe messages.

        Timeout and subprocess errors are re-raised as RuntimeError with
        sanitized messages that never include command arguments (which may
        contain secrets).
        """
        try:
            return subprocess.run(
                args,
                capture_output=True,
                text=True,
                timeout=timeout,
            )
        except subprocess.TimeoutExpired:
            raise RuntimeError(
                f"Keychain operation timed out after {timeout}s. "
                "A macOS dialog may be waiting for input — check for a "
                "'security wants to access your keychain' prompt."
            )
        except subprocess.SubprocessError as e:
            raise RuntimeError(f"Keychain operation failed: {type(e).__name__}") from e

    def store(self, endpoint_key: str, secrets: dict[str, str]) -> None:
        payload = json.dumps(secrets)
        # -U: update if the item already exists (atomic, no gap where
        # the secret is missing).  Safe because all items under SERVICE
        # are created by /usr/bin/security with the default ACL that
        # trusts /usr/bin/security for decrypt — so updates succeed
        # without prompts.
        result = self._run_security(
            [
                "security",
                "add-generic-password",
                "-a",
                endpoint_key,
                "-s",
                self.SERVICE,
                "-w",
                payload,
                "-U",
            ],
        )
        if result.returncode != 0:
            stderr = result.stderr.strip()
            if "locked" in stderr.lower():
                raise KeychainLockedError(
                    "System keychain (macOS Keychain) is locked. "
                    "Unlock it or run `hivemind login` to re-authenticate."
                )
            raise RuntimeError(f"Failed to store keychain entry: {stderr}")

    def load(self, endpoint_key: str) -> dict[str, str] | None:
        result = self._run_security(
            [
                "security",
                "find-generic-password",
                "-a",
                endpoint_key,
                "-s",
                self.SERVICE,
                "-w",  # output password data only
            ],
        )
        if result.returncode != 0:
            stderr = result.stderr.strip()
            stderr_lower = stderr.lower()
            if "locked" in stderr_lower:
                raise KeychainLockedError(
                    "System keychain (macOS Keychain) is locked. "
                    "Unlock it or run `hivemind login` to re-authenticate."
                )
            if result.returncode == 44 or "could not be found" in stderr_lower:
                return None
            raise RuntimeError(f"Failed to load keychain entry: {stderr}")
        raw = result.stdout.strip()
        if not raw:
            return None
        try:
            return json.loads(raw)
        except (json.JSONDecodeError, ValueError):
            logger.warning("Corrupted keychain entry for %s, deleting", endpoint_key)
            self.delete(endpoint_key)
            return None

    def delete(self, endpoint_key: str) -> None:
        try:
            self._run_security(
                [
                    "security",
                    "delete-generic-password",
                    "-a",
                    endpoint_key,
                    "-s",
                    self.SERVICE,
                ],
            )
        except RuntimeError:
            pass  # Best-effort

    @property
    def is_keychain(self) -> bool:
        return True

    def is_unlocked(self) -> bool:
        """Probe by attempting a no-op read."""
        try:
            result = self._run_security(
                [
                    "security",
                    "find-generic-password",
                    "-a",
                    "__unlock_probe__",
                    "-s",
                    self.SERVICE,
                ],
                timeout=5,
            )
            stderr = result.stderr.lower()
            if result.returncode == 0:
                return True
            if "locked" in stderr:
                return False
            # Probe item not existing means the keychain is accessible
            if "could not be found" in stderr:
                return True
            return False
        except RuntimeError:
            return False

    @property
    def backend_name(self) -> str:
        return "macOS Keychain"


class FileBackend:
    """Fallback: secrets stay in the JSON credentials file (current behavior).

    This is a no-op backend — secrets are read/written directly in the JSON file
    by CredentialStore, so this backend just signals "no keychain available".
    """

    def store(self, endpoint_key: str, secrets: dict[str, str]) -> None:
        pass  # Secrets stay in JSON file

    def load(self, endpoint_key: str) -> dict[str, str] | None:
        return None  # Signals: read from JSON file

    def delete(self, endpoint_key: str) -> None:
        pass

    @property
    def is_keychain(self) -> bool:
        return False

    def is_unlocked(self) -> bool:
        return True  # File backend is always "unlocked"

    @property
    def backend_name(self) -> str:
        return "File (~/.hivemind/credentials.json)"


def _create_secret_backend() -> SecretBackend:
    """Create the best available secret backend.

    On macOS, uses the `security` CLI directly to store items with an open ACL
    (``-T ""``), avoiding the OS prompt that the keyring library triggers when
    the calling Python binary changes (e.g. after a Homebrew upgrade).

    On Linux, uses the `keyring` library (Secret Service / GNOME Keyring / KWallet).

    Falls back to file-based storage when no keychain is available.
    """
    if sys.platform == "darwin":
        try:
            backend = MacOSKeychainBackend()
            logger.debug("Using macOS Keychain (security CLI) for secret storage")
            return backend
        except Exception as e:
            logger.debug("macOS Keychain unavailable (%s), trying keyring library", e)

    try:
        backend = KeychainBackend()
        logger.debug("Using system keychain for secret storage")
        return backend
    except Exception as e:
        logger.debug("System keychain unavailable (%s), using file-based storage", e)
        return FileBackend()


class CredentialStore:
    """Secure local storage for Hivemind credentials.

    Credentials are stored per-server to support switching between
    different backends (e.g., localhost vs production) without
    credential conflicts.

    When a system keychain is available, secret fields (token, refresh_token)
    are stored there and the JSON file contains a sentinel value. When no
    keychain is available, everything is stored in the JSON file as before.

    File format (v2):
    {
        "version": 2,
        "servers": {
            "https://hivemind.wandb.tools": {
                "token": "..." or "__keychain__",
                "user_id": "...",
                ...
            },
            "http://localhost:8080": {
                ...
            }
        }
    }

    Legacy format (v1, auto-migrated):
    {
        "token": "...",
        "user_id": "...",
        ...
    }
    """

    def __init__(
        self,
        config_dir: Path | None = None,
        secret_backend: SecretBackend | None = None,
    ):
        self.config_dir = config_dir or Path.home() / ".hivemind"
        self.creds_file = self.config_dir / "credentials.json"
        self._cache: dict | None = None
        self._secrets = secret_backend if secret_backend is not None else _create_secret_backend()

    def _ensure_config_dir(self) -> None:
        """Create config directory with secure permissions."""
        if not self.config_dir.exists():
            self.config_dir.mkdir(mode=0o700, parents=True)
        else:
            # Check if permissions need fixing (only chmod if necessary)
            # This avoids issues on macOS where extended attributes can
            # prevent chmod even when you own the directory
            current_mode = self.config_dir.stat().st_mode & 0o777
            if current_mode != 0o700:
                try:
                    self.config_dir.chmod(0o700)
                except PermissionError:
                    # On macOS with com.apple.provenance or other extended
                    # attributes, chmod may fail even for owned directories.
                    # Log and continue if permissions are at least restrictive.
                    if current_mode & (stat.S_IRWXG | stat.S_IRWXO):
                        logger.warning(
                            f"Cannot fix permissions on {self.config_dir} "
                            f"(mode {oct(current_mode)}). Directory may be insecure."
                        )
                    else:
                        logger.debug(
                            f"Cannot chmod {self.config_dir} but permissions "
                            f"are acceptably restrictive ({oct(current_mode)})"
                        )

    def _reset_file(self, reason: str) -> dict:
        """Delete the credentials file and return an empty structure.

        This forces re-authentication on the next login attempt.
        """
        logger.warning(f"Resetting credentials file ({reason}), re-authentication required")
        try:
            self.creds_file.unlink(missing_ok=True)
        except OSError as e:
            logger.warning(f"Could not delete credentials file: {e}")
        self._cache = None
        return {"version": CREDENTIALS_VERSION, "servers": {}}

    def _read_file(self) -> dict:
        """Read and parse credentials file, handling migration."""
        if not self.creds_file.exists():
            return {"version": CREDENTIALS_VERSION, "servers": {}}

        # Check file permissions
        try:
            file_stat = self.creds_file.stat()
            if file_stat.st_mode & (stat.S_IRWXG | stat.S_IRWXO):
                try:
                    self.creds_file.chmod(0o600)
                    logger.info(f"Fixed insecure permissions on {self.creds_file}")
                except PermissionError:
                    logger.warning(
                        f"Credentials file {self.creds_file} has insecure permissions "
                        f"({oct(file_stat.st_mode & 0o777)}) but cannot be fixed."
                    )
        except OSError:
            return self._reset_file("cannot stat file")

        try:
            with open(self.creds_file) as f:
                data = json.load(f)
        except (json.JSONDecodeError, ValueError, OSError) as e:
            return self._reset_file(f"cannot parse: {e}")

        if not isinstance(data, dict):
            return self._reset_file("file content is not a JSON object")

        # Check if migration needed (no version = legacy v1 format)
        if "version" not in data:
            logger.info("Migrating credentials from v1 to v2 format")
            # Legacy format has creds at top level
            # Store as __pending_migration__ until we know the endpoint
            return {
                "version": CREDENTIALS_VERSION,
                "servers": {},
                "__pending_migration__": data,
            }

        # Validate v2 format structure - must have "servers" dict
        if not isinstance(data.get("servers"), dict):
            return self._reset_file("invalid v2 structure (missing servers)")

        return data

    def _write_file(self, data: dict) -> None:
        """Write credentials file securely."""
        self._ensure_config_dir()
        temp_file = self.creds_file.with_suffix(".tmp")
        try:
            with open(temp_file, "w") as f:
                json.dump(data, f, indent=2)
            temp_file.chmod(0o600)
            temp_file.rename(self.creds_file)
            self._cache = data
        except Exception:
            temp_file.unlink(missing_ok=True)
            raise

    def save(self, creds: StoredCredentials, endpoint: str) -> None:
        """Save credentials for a specific server endpoint.

        When a keychain backend is available and unlocked, secret fields are
        stored there and replaced with a sentinel in the JSON file. If the
        keychain is locked or unavailable, secrets are stored in the JSON file
        directly (with a warning).
        """
        key = _normalize_endpoint(endpoint)
        data = self._read_file()

        # Clear pending migration if we're saving for any endpoint
        data.pop("__pending_migration__", None)

        creds_dict = creds.model_dump()

        if self._secrets.is_keychain:
            # Extract secrets for keychain storage — fall back to file on failure
            secrets = {}
            for secret_field in _SECRET_FIELDS:
                value = creds_dict.get(secret_field)
                if value is not None:
                    secrets[secret_field] = value
                    creds_dict[secret_field] = KEYCHAIN_SENTINEL

            if secrets:
                try:
                    self._secrets.store(key, secrets)
                except KeychainLockedError:
                    logger.warning(
                        "System keychain (%s) is locked — storing secrets in file. "
                        "Unlock your keychain for more secure storage.",
                        self._secrets.backend_name,
                    )
                    creds_dict = creds.model_dump()
                except Exception as e:
                    logger.warning(f"Failed to store secrets in keychain: {e}")
                    creds_dict = creds.model_dump()

        data["servers"][key] = creds_dict
        self._write_file(data)
        logger.debug(f"Saved credentials for {key}")

    def load_raw(self, endpoint: str) -> StoredCredentials | None:
        """Load credentials WITHOUT applying the escalation override.

        Use this when you need the underlying base token (e.g. when calling
        /v1/auth/escalate to mint a new escalation token, or when inspecting
        the stored escalation fields directly).
        """
        return self._load(endpoint, apply_escalation=False)

    # Backwards-compatible alias — explicit name for "give me the base token".
    def load_base_only(self, endpoint: str) -> StoredCredentials | None:
        """Load credentials ignoring any stored escalation token."""
        return self._load(endpoint, apply_escalation=False)

    def load(self, endpoint: str) -> StoredCredentials | None:
        """Load credentials, transparently preferring an active escalation token.

        If the stored credentials carry a non-expired `escalation_token`, the
        returned StoredCredentials has its `token` field replaced with the
        escalation token so downstream HTTP calls are automatically elevated.
        Otherwise the base token is returned unchanged.
        """
        return self._load(endpoint, apply_escalation=True)

    def _load(self, endpoint: str, apply_escalation: bool) -> StoredCredentials | None:
        """Load credentials for a specific server endpoint.

        If legacy credentials exist (from v1 format) and no credentials
        exist for this endpoint, the legacy credentials are migrated
        to this endpoint.

        Raises:
            KeychainLockedError: If the token is stored in the keychain but the
                keychain is locked. Callers should catch this to show a
                user-friendly message prompting re-authentication or keychain
                unlock.
        """
        key = _normalize_endpoint(endpoint)
        data = self._read_file()

        # Check for existing credentials for this endpoint
        if key in data.get("servers", {}):
            creds_dict = dict(data["servers"][key])

            # If secrets are in keychain, load them
            if creds_dict.get("token") == KEYCHAIN_SENTINEL:
                keychain_secrets = None
                try:
                    keychain_secrets = self._secrets.load(key)
                except KeychainLockedError:
                    # Re-raise with context so callers can distinguish
                    # "locked" from "missing"
                    raise KeychainLockedError(
                        f"Credentials for {key} are stored in the system keychain, "
                        "but it is currently locked. Unlock your keychain or run "
                        "`hivemind login` to re-authenticate."
                    )
                except Exception as e:
                    logger.warning(f"Failed to load secrets from keychain: {e}")

                if not keychain_secrets:
                    logger.warning(
                        "Secrets missing from keychain for %s, re-authentication required", key
                    )
                    return None

                # Merge keychain secrets into the credential dict
                for secret_field in _SECRET_FIELDS:
                    if secret_field in keychain_secrets:
                        creds_dict[secret_field] = keychain_secrets[secret_field]
                    elif creds_dict.get(secret_field) == KEYCHAIN_SENTINEL:
                        # Secret was expected in keychain but not found
                        creds_dict.pop(secret_field, None)

            try:
                loaded = StoredCredentials(**creds_dict)
            except (ValidationError, ValueError, TypeError):
                self._reset_file(f"corrupted credentials for {key}")
                return None
            return _maybe_apply_escalation(loaded) if apply_escalation else loaded

        # Check for pending migration from v1 format
        pending = data.get("__pending_migration__")
        if pending:
            logger.info(f"Migrating legacy credentials to endpoint: {key}")
            try:
                creds = StoredCredentials(**pending)
                # Save migrated credentials (will move secrets to keychain if available)
                self.save(creds, endpoint)
                return creds
            except (ValidationError, ValueError, TypeError):
                self._reset_file("corrupted legacy credentials")
                return None

        return None

    def save_escalation(
        self, endpoint: str, escalation_token: str, escalation_expires_at: int
    ) -> None:
        """Persist a short-lived escalation token alongside the base credential.

        The base token/expires_at are not modified. Raises if no base credential
        exists for the endpoint (escalation requires a logged-in session).
        """
        creds = self.load_raw(endpoint)
        if creds is None:
            raise ValueError(
                f"Cannot save escalation token: no base credentials for {endpoint}. "
                "Run 'hivemind login' first."
            )
        updated = creds.model_copy(
            update={
                "escalation_token": escalation_token,
                "escalation_expires_at": escalation_expires_at,
            }
        )
        self.save(updated, endpoint)

    def save_sso_org_id(self, endpoint: str, sso_org_id: str | None) -> None:
        """Persist the SSO org_id on the stored credentials for *endpoint*.

        No-op if no base credentials exist yet (the next `save()` after login
        will carry whatever org_id the AuthManager attached in-memory).
        """
        creds = self.load_raw(endpoint)
        if creds is None:
            return
        if creds.sso_org_id == sso_org_id:
            return
        self.save(creds.model_copy(update={"sso_org_id": sso_org_id}), endpoint)

    def clear_escalation(self, endpoint: str) -> None:
        """Drop any cached escalation token for *endpoint*. Base creds untouched."""
        creds = self.load_raw(endpoint)
        if creds is None:
            return
        if creds.escalation_token is None and creds.escalation_expires_at is None:
            return
        updated = creds.model_copy(update={"escalation_token": None, "escalation_expires_at": None})
        self.save(updated, endpoint)

    def clear(self, endpoint: str | None = None) -> None:
        """Remove stored credentials.

        Args:
            endpoint: If provided, clear only credentials for this endpoint.
                     If None, clear all credentials.
        """
        if endpoint is None:
            # Clear all keychain entries for known endpoints
            data = self._read_file()
            for ep_key in data.get("servers", {}):
                try:
                    self._secrets.delete(ep_key)
                except Exception:
                    pass
            self.creds_file.unlink(missing_ok=True)
            self._cache = None
        else:
            key = _normalize_endpoint(endpoint)
            try:
                self._secrets.delete(key)
            except Exception:
                pass
            data = self._read_file()
            if key in data.get("servers", {}):
                del data["servers"][key]
                self._write_file(data)
                logger.debug(f"Cleared credentials for {key}")

    def is_expired(self, creds: StoredCredentials, buffer_seconds: int = 3600) -> bool:
        """Check if credentials are expired or expiring soon."""
        return time.time() >= (creds.expires_at - buffer_seconds)

    def list_endpoints(self) -> list[str]:
        """List all endpoints with stored credentials."""
        data = self._read_file()
        return list(data.get("servers", {}).keys())

    def diagnose(self, endpoint: str | None = None) -> CredentialDiagnosis:
        """Diagnose the health of the credential store.

        Returns a structured report suitable for `hivemind doctor` and
        `hivemind status`. If *endpoint* is provided, also checks whether
        secrets for that endpoint are accessible.
        """
        result = CredentialDiagnosis(
            backend_name=self._secrets.backend_name,
            is_keychain=self._secrets.is_keychain,
        )

        # Check keychain unlock state
        if self._secrets.is_keychain:
            result.keychain_unlocked = self._secrets.is_unlocked()

        # Check credentials file health
        if self.creds_file.exists():
            result.has_credentials_file = True
            try:
                data = self._read_file()
                endpoints = list(data.get("servers", {}).keys())
                result.stored_endpoints = endpoints

                # Check if any endpoint uses keychain sentinels
                for ep_data in data.get("servers", {}).values():
                    if isinstance(ep_data, dict) and ep_data.get("token") == KEYCHAIN_SENTINEL:
                        result.has_keychain_secrets = True
                        break
            except Exception as e:
                result.issues.append(f"Cannot read credentials file: {e}")

        # If a specific endpoint is given, check its secrets
        if endpoint:
            key = _normalize_endpoint(endpoint)
            try:
                creds = self.load(endpoint)
                if creds:
                    result.secrets_accessible = True
                    if self.is_expired(creds):
                        result.issues.append(f"Credentials for {key} are expired")
                else:
                    result.issues.append(f"No credentials found for {key}")
            except KeychainLockedError:
                result.secrets_accessible = False
                result.issues.append(f"Credentials for {key} are in the keychain but it is locked")
            except Exception as e:
                result.secrets_accessible = False
                result.issues.append(f"Error loading credentials for {key}: {e}")

        # Generate suggestions
        if self._secrets.is_keychain and not result.keychain_unlocked:
            if result.has_keychain_secrets:
                result.issues.append(
                    "Keychain is locked and some credentials are stored there — "
                    "they cannot be read until the keychain is unlocked"
                )
            if platform.system() == "Linux":
                result.suggestions.append(
                    "Ensure pam_gnome_keyring.so is configured in /etc/pam.d/sshd "
                    "to auto-unlock the keychain on SSH login"
                )
            result.suggestions.append(
                "Run `hivemind login` to re-authenticate (will store in file if keychain is locked)"
            )

        return result


@dataclass
class CredentialDiagnosis:
    """Structured result from CredentialStore.diagnose()."""

    backend_name: str
    is_keychain: bool
    keychain_unlocked: bool | None = None  # None if not a keychain backend
    has_credentials_file: bool = False
    stored_endpoints: list[str] = field(default_factory=list)
    has_keychain_secrets: bool = False
    secrets_accessible: bool | None = None  # None if no endpoint checked
    issues: list[str] = field(default_factory=list)
    suggestions: list[str] = field(default_factory=list)

    @property
    def healthy(self) -> bool:
        """True if no issues were detected."""
        return len(self.issues) == 0
