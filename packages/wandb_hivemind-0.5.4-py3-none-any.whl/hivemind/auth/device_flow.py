"""GitHub OAuth device flow for AgentStream daemon."""

from __future__ import annotations

import asyncio
import os
import time
import webbrowser

import httpx

from hivemind.auth.discovery import TokenAuthMethod


class AuthError(Exception):
    """Authentication error."""

    pass


# GitHub App client IDs per environment (used for device flow auth).
# These are the client IDs from the GitHub App's OAuth settings.
# When the GitHub App is set up, update these to the App's client IDs.
# The OAuth device flow works identically with GitHub App client IDs.
GITHUB_CLIENT_ID_PROD = "Ov23li9ZN6sUqmjFeDgL"
GITHUB_CLIENT_ID_QA = "Ov23li0ZNznwGrBpVf6Z"

DEVICE_FLOW_SCOPE = "read:user read:org"


def get_github_client_id(endpoint: str | None = None) -> str:
    """Get the appropriate GitHub OAuth client ID for the given endpoint.

    Priority:
    1. AGENTSTREAM_GITHUB_CLIENT_ID env var (explicit override)
    2. QA client ID for QA and local dev endpoints
    3. Production client ID (default)
    """
    env_override = os.getenv("HIVEMIND_GITHUB_CLIENT_ID")
    if env_override:
        return env_override

    if endpoint:
        # QA and local dev use the QA OAuth app
        if "qa.wandb.tools" in endpoint or "localhost" in endpoint or "127.0.0.1" in endpoint:
            return GITHUB_CLIENT_ID_QA

    return GITHUB_CLIENT_ID_PROD


class DeviceFlowAuth:
    """GitHub OAuth device flow."""

    DEVICE_CODE_URL = "https://github.com/login/device/code"
    ACCESS_TOKEN_URL = "https://github.com/login/oauth/access_token"

    def __init__(self, client_id: str | None = None, endpoint: str | None = None):
        self.client_id = client_id or get_github_client_id(endpoint)
        if not self.client_id:
            raise AuthError("GitHub OAuth client ID not configured")

    async def authenticate(self) -> TokenAuthMethod:
        """Run device flow and return token auth method."""

        # Request device code
        async with httpx.AsyncClient() as client:
            response = await client.post(
                self.DEVICE_CODE_URL,
                data={
                    "client_id": self.client_id,
                    "scope": DEVICE_FLOW_SCOPE,
                },
                headers={"Accept": "application/json"},
                timeout=30,
            )

        if response.status_code != 200:
            raise AuthError(f"Failed to start device flow: {response.text}")

        data = response.json()
        device_code = data["device_code"]
        user_code = data["user_code"]
        verification_uri = data["verification_uri"]
        interval = data.get("interval", 5)
        expires_in = data.get("expires_in", 900)

        # Prompt user and wait for them to copy the code before opening browser
        print()
        print("=" * 60)
        print("  GitHub Authentication Required")
        print("=" * 60)
        print()
        print(f"  Your device code: {user_code}")
        print()
        print(f"  Copy the code above, then press Enter to open {verification_uri}")
        print()

        # Wait for user to press Enter (run in executor to not block async loop)
        await asyncio.get_event_loop().run_in_executor(None, input)

        # Open browser after user is ready
        try:
            webbrowser.open(verification_uri)
        except Exception:
            pass

        print("  Waiting for authorization...")
        print()

        # Poll for token
        token_result = await self._poll_for_token(
            device_code=device_code,
            interval=interval,
            expires_in=expires_in,
        )

        access_token = token_result["access_token"]
        refresh_token = token_result.get("refresh_token")

        # Get GitHub username
        github_user = await self._get_github_user(access_token)

        print(f"  Authenticated as: {github_user}")
        print("=" * 60)
        print()

        return TokenAuthMethod(
            token=access_token,
            github_user=github_user,
            source="device_flow",
            refresh_token=refresh_token,
        )

    async def _poll_for_token(
        self,
        device_code: str,
        interval: int,
        expires_in: int,
    ) -> dict[str, str]:
        """Poll GitHub until user authorizes.

        Returns a dict with 'access_token' and optionally 'refresh_token'
        (if the GitHub App has expiring user tokens enabled).
        """
        deadline = time.time() + expires_in

        async with httpx.AsyncClient() as client:
            while time.time() < deadline:
                await asyncio.sleep(interval)

                response = await client.post(
                    self.ACCESS_TOKEN_URL,
                    data={
                        "client_id": self.client_id,
                        "device_code": device_code,
                        "grant_type": "urn:ietf:params:oauth:grant-type:device_code",
                    },
                    headers={"Accept": "application/json"},
                    timeout=30,
                )

                data = response.json()

                if "access_token" in data:
                    result = {"access_token": data["access_token"]}
                    # GitHub returns refresh_token when App has expiring tokens enabled
                    if data.get("refresh_token"):
                        result["refresh_token"] = data["refresh_token"]
                    return result

                error = data.get("error")

                if error == "authorization_pending":
                    continue
                elif error == "slow_down":
                    interval += 5
                elif error == "expired_token":
                    raise AuthError("Device code expired")
                elif error == "access_denied":
                    raise AuthError("Authorization denied")
                else:
                    raise AuthError(f"Device flow error: {error}")

        raise AuthError("Device flow timed out")

    async def _get_github_user(self, token: str) -> str:
        """Get GitHub username from access token."""
        async with httpx.AsyncClient() as client:
            response = await client.get(
                "https://api.github.com/user",
                headers={
                    "Authorization": f"Bearer {token}",
                    "Accept": "application/vnd.github+json",
                },
                timeout=10,
            )

        if response.status_code != 200:
            raise AuthError("Failed to get GitHub user info")

        return response.json()["login"]
