"""CLI telemetry -- fire-and-forget product usage tracking.

Posts events to POST /v1/telemetry/track using the same payload format as the
dashboard frontend.  Each CLI command invocation emits at most one event.

Design goals:
- Never block the CLI or add perceptible latency.
- Never raise exceptions to the caller.
- Silently no-op when the user is not authenticated or in test environments.
- Respect HIVEMIND_TELEMETRY=false or DO_NOT_TRACK=1 env vars.
"""

from __future__ import annotations

import atexit
import logging
import os
import threading
import time
import uuid
from typing import Any

import httpx

from hivemind.auth.credentials import CredentialStore
from hivemind.config import get_effective_endpoint
from hivemind.uploader import get_user_agent

logger = logging.getLogger(__name__)


def _telemetry_enabled() -> bool:
    """Check whether telemetry is enabled via environment variables."""
    # Auto-disable in test environments
    if os.getenv("PYTEST_CURRENT_TEST"):
        return False
    # Respect the standard DO_NOT_TRACK convention (https://consoledonottrack.com/)
    if os.getenv("DO_NOT_TRACK", "").strip().lower() in ("1", "true", "yes"):
        return False
    # Project-specific opt-out
    val = os.getenv("HIVEMIND_TELEMETRY", "true").strip().lower()
    return val in ("true", "1", "yes", "")


# ---------------------------------------------------------------------------
# Background sender
# ---------------------------------------------------------------------------

_pending_events: list[dict[str, Any]] = []
_lock = threading.Lock()
_flush_registered = False


def _send() -> None:
    """Send all pending events.  Best-effort, bounded by HTTP timeout."""
    with _lock:
        events = list(_pending_events)
        _pending_events.clear()
    if not events:
        return

    # All events share the same credentials (one CLI session = one user).
    endpoint = events[0].pop("_endpoint", "")
    token = events[0].pop("_token", "")
    for e in events[1:]:
        e.pop("_endpoint", None)
        e.pop("_token", None)
    if not endpoint or not token:
        return

    url = f"{endpoint}/v1/telemetry/track"
    headers = {
        "Content-Type": "application/json",
        "Authorization": f"Bearer {token}",
        "User-Agent": get_user_agent(),
    }
    payload = {"events": events}

    try:
        with httpx.Client(timeout=2.0) as client:
            client.post(url, json=payload, headers=headers)
    except Exception:
        # Fire-and-forget -- silently discard on any failure.
        pass


def _ensure_flush_registered() -> None:
    """Register an atexit handler (once) so events are flushed on exit."""
    global _flush_registered
    if _flush_registered:
        return

    def _flush() -> None:
        # Flush synchronously during interpreter shutdown.  Starting a new
        # daemon thread here is unreliable because thread creation can fail
        # during teardown, and daemon threads are not awaited before exit.
        # The 2s HTTP timeout bounds the worst-case delay.
        try:
            _send()
        except Exception:
            # Telemetry must never interfere with interpreter shutdown.
            pass

    atexit.register(_flush)
    _flush_registered = True


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------


def track(event_name: str, properties: dict[str, Any] | None = None) -> None:
    """Record a telemetry event.

    The event is buffered and sent synchronously at process exit so this
    call never blocks or throws during normal execution.

    Args:
        event_name: Short dot-separated name, e.g. ``cli.login``.
        properties: Optional dict of event-specific metadata.
    """
    try:
        if not _telemetry_enabled():
            return

        # Load credentials -- if the user is not authenticated we silently
        # skip telemetry rather than erroring out.
        endpoint = get_effective_endpoint()
        # Strip known path suffixes (same normalisation as cli.py)
        base = endpoint.rstrip("/")
        for suffix in ("/v1/ingest/sessions", "/v1/ingest"):
            if base.endswith(suffix):
                base = base[: -len(suffix)]
                break

        store = CredentialStore()
        creds = store.load(base)
        if creds is None or store.is_expired(creds):
            return

        event: dict[str, Any] = {
            "event_id": str(uuid.uuid4()),
            "event_name": event_name,
            "properties": properties or {},
            "page_url": "",
            "session_id": "",
            "timestamp": int(time.time() * 1000),
            # Internal fields stripped before sending:
            "_endpoint": base,
            "_token": creds.token,
        }

        with _lock:
            _pending_events.append(event)

        _ensure_flush_registered()
    except Exception:
        # Telemetry must never interfere with the CLI command.
        pass
