"""
snaptest CLI
------------
Review, approve, and manage snapshots from the terminal.

Usage:
    snaptest list
    snaptest show <key>
    snaptest update
    snaptest clean
"""

import argparse
import glob
import os
import sys
from pathlib import Path

from .store import SnapshotStore, SNAPSHOTS_DIR, SNAPSHOT_EXT


def main():
    parser = argparse.ArgumentParser(
        prog="snaptest",
        description="Manage snaptest snapshots.",
    )
    sub = parser.add_subparsers(dest="command")

    sub.add_parser("list", help="List all snapshot files and keys")

    show = sub.add_parser("show", help="Show a snapshot's stored value")
    show.add_argument("key", help="Snapshot key to display")
    show.add_argument("--file", "-f", help="Snapshot file (auto-detected if omitted)")

    sub.add_parser("update", help="Re-run tests with SNAPTEST_UPDATE=1 to update all snapshots")

    clean = sub.add_parser("clean", help="Delete all snapshot files")
    clean.add_argument("--yes", "-y", action="store_true", help="Skip confirmation")

    args = parser.parse_args()

    if args.command == "list":
        _list_snapshots()
    elif args.command == "show":
        _show_snapshot(args)
    elif args.command == "update":
        _update_snapshots()
    elif args.command == "clean":
        _clean_snapshots(args)
    else:
        parser.print_help()


def _find_snap_files():
    return list(glob.glob(f"**/{SNAPSHOTS_DIR}/*{SNAPSHOT_EXT}", recursive=True))


def _list_snapshots():
    files = _find_snap_files()
    if not files:
        print("  No snapshot files found.")
        return

    store = SnapshotStore()
    total = 0
    for f in sorted(files):
        # Derive the test file path from the snap file
        snap_path = Path(f)
        test_file = str(snap_path.parent.parent / snap_path.stem) + ".py"
        keys = store.all_keys(test_file)
        print(f"\n  📁 {f}  ({len(keys)} snapshots)")
        for key in keys:
            print(f"     • {key}")
        total += len(keys)

    print(f"\n  Total: {total} snapshot(s) in {len(files)} file(s)")


def _show_snapshot(args):
    store = SnapshotStore()
    files = _find_snap_files()
    if not files:
        print("  No snapshot files found.")
        return

    for f in files:
        snap_path = Path(f)
        test_file = str(snap_path.parent.parent / snap_path.stem) + ".py"
        value = store.get(test_file, args.key)
        if value:
            print(f"\n  Snapshot: '{args.key}'")
            print(f"  File: {f}\n")
            print(value)
            return

    print(f"  ❌ Snapshot '{args.key}' not found.")
    sys.exit(1)


def _update_snapshots():
    print("  To update all snapshots, run:\n")
    print("    SNAPTEST_UPDATE=1 pytest")
    print("  or")
    print("    pytest --snapshot-update\n")


def _clean_snapshots(args):
    files = _find_snap_files()
    if not files:
        print("  No snapshot files to clean.")
        return

    print(f"  Found {len(files)} snapshot file(s):")
    for f in files:
        print(f"    • {f}")

    if not args.yes:
        confirm = input("\n  Delete all? [y/N] ").strip().lower()
        if confirm != "y":
            print("  Aborted.")
            return

    for f in files:
        os.remove(f)
        print(f"  🗑️  Deleted: {f}")
    print(f"\n  ✅ Removed {len(files)} file(s).")


if __name__ == "__main__":
    main()
