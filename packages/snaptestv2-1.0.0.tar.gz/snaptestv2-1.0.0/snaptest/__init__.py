"""
snaptest — Snapshot testing for Python.
Auto-creates snapshots on first run, diffs on mismatch,
pytest plugin, and CLI to review/approve.
"""

from .core import snapshot, SnapshotMismatch, SnapshotStore
from .plugin import pytest_configure  # noqa: F401 — registers pytest plugin

__all__ = ["snapshot", "SnapshotMismatch", "SnapshotStore"]
__version__ = "1.0.0"
__author__ = "prabhay759"
