"""
snaptest.serializer
-------------------
Serialize any Python value to a stable, human-readable string for snapshotting.
"""

import dataclasses
import json
import pprint
from typing import Any


def serialize(value: Any) -> str:
    """
    Convert any Python value to a stable snapshot string.

    Handles: dict, list, tuple, set, str, int, float, bool, None,
             dataclasses, objects with __dict__, and anything else via repr.
    """
    normalized = _normalize(value)
    try:
        return json.dumps(normalized, indent=2, sort_keys=True, default=_json_default)
    except Exception:
        return pprint.pformat(value, width=80, sort_dicts=True)


def _normalize(value: Any) -> Any:
    """Recursively normalize a value for stable serialization."""
    if value is None or isinstance(value, (bool, int, float, str)):
        return value
    if isinstance(value, dict):
        return {str(k): _normalize(v) for k, v in sorted(value.items(), key=lambda x: str(x[0]))}
    if isinstance(value, (list, tuple)):
        return [_normalize(v) for v in value]
    if isinstance(value, set):
        return sorted([_normalize(v) for v in value], key=str)
    if isinstance(value, frozenset):
        return sorted([_normalize(v) for v in value], key=str)
    if dataclasses.is_dataclass(value) and not isinstance(value, type):
        return _normalize(dataclasses.asdict(value))
    if hasattr(value, "__dict__"):
        return _normalize(vars(value))
    return repr(value)


def _json_default(obj):
    if dataclasses.is_dataclass(obj) and not isinstance(obj, type):
        return dataclasses.asdict(obj)
    if hasattr(obj, "__dict__"):
        return vars(obj)
    return repr(obj)
