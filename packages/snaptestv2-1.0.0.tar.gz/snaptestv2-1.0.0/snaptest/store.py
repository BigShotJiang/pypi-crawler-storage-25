"""
snaptest.store
--------------
Reads and writes snapshot files.
"""

import os
from pathlib import Path
from typing import Dict, Optional


SNAPSHOTS_DIR = "__snapshots__"
SNAPSHOT_EXT = ".snap"


class SnapshotStore:
    """
    Manages snapshot files in a __snapshots__ directory.

    Snapshots are stored as plain text files, one per test file,
    with named sections for each snapshot key.

    File format:
    ─────────────────────────────
    # snaptest snapshot file
    # Do not edit manually

    [snapshot_key]
    <serialized value>
    [/snapshot_key]
    ─────────────────────────────
    """

    def __init__(self, base_dir: Optional[str] = None):
        self.base_dir = base_dir or os.getcwd()
        self._cache: Dict[str, Dict[str, str]] = {}

    def _snap_file(self, test_file: str) -> Path:
        """Return path to snapshot file for a given test file."""
        test_path = Path(test_file)
        snap_dir = test_path.parent / SNAPSHOTS_DIR
        snap_dir.mkdir(exist_ok=True)
        return snap_dir / (test_path.stem + SNAPSHOT_EXT)

    def _load(self, snap_file: Path) -> Dict[str, str]:
        """Load all snapshots from a file into a dict."""
        if str(snap_file) in self._cache:
            return self._cache[str(snap_file)]

        snapshots: Dict[str, str] = {}
        if not snap_file.exists():
            return snapshots

        content = snap_file.read_text(encoding="utf-8")
        lines = content.splitlines()
        current_key = None
        current_lines = []

        for line in lines:
            if line.startswith("[") and line.endswith("]") and not line.startswith("[/"):
                current_key = line[1:-1]
                current_lines = []
            elif line == f"[/{current_key}]" and current_key:
                snapshots[current_key] = "\n".join(current_lines).strip()
                current_key = None
                current_lines = []
            elif current_key is not None:
                current_lines.append(line)

        self._cache[str(snap_file)] = snapshots
        return snapshots

    def _save(self, snap_file: Path, snapshots: Dict[str, str]):
        """Write all snapshots to a file."""
        lines = [
            "# snaptest snapshot file",
            "# Do not edit manually — run with SNAPTEST_UPDATE=1 to regenerate",
            "",
        ]
        for key in sorted(snapshots.keys()):
            lines.append(f"[{key}]")
            lines.append(snapshots[key])
            lines.append(f"[/{key}]")
            lines.append("")

        snap_file.write_text("\n".join(lines), encoding="utf-8")
        self._cache[str(snap_file)] = snapshots

    def get(self, test_file: str, key: str) -> Optional[str]:
        """Return stored snapshot value, or None if not found."""
        snap_file = self._snap_file(test_file)
        return self._load(snap_file).get(key)

    def save(self, test_file: str, key: str, value: str):
        """Save or update a snapshot value."""
        snap_file = self._snap_file(test_file)
        snapshots = dict(self._load(snap_file))
        snapshots[key] = value
        self._save(snap_file, snapshots)
        # Invalidate cache
        self._cache.pop(str(snap_file), None)

    def delete(self, test_file: str, key: str) -> bool:
        """Delete a snapshot. Returns True if it existed."""
        snap_file = self._snap_file(test_file)
        snapshots = dict(self._load(snap_file))
        if key in snapshots:
            del snapshots[key]
            self._save(snap_file, snapshots)
            self._cache.pop(str(snap_file), None)
            return True
        return False

    def all_keys(self, test_file: str):
        """Return all snapshot keys for a test file."""
        snap_file = self._snap_file(test_file)
        return list(self._load(snap_file).keys())

    def snap_file_path(self, test_file: str) -> str:
        return str(self._snap_file(test_file))
