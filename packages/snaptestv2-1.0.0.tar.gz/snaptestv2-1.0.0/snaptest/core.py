"""
snaptest.core
-------------
Core snapshot() function and SnapshotMismatch exception.
"""

import difflib
import inspect
import os
from typing import Any, Optional

from .serializer import serialize
from .store import SnapshotStore

# Global store — shared across all tests in a session
_store = SnapshotStore()

# Set SNAPTEST_UPDATE=1 to auto-update all snapshots
_UPDATE_MODE = os.environ.get("SNAPTEST_UPDATE", "").lower() in ("1", "true", "yes")


class SnapshotMismatch(AssertionError):
    """
    Raised when a value doesn't match its stored snapshot.

    Attributes
    ----------
    key : str
        The snapshot key that failed.
    expected : str
        The stored snapshot value.
    actual : str
        The current serialized value.
    diff : str
        A unified diff between expected and actual.
    """

    def __init__(self, key: str, expected: str, actual: str, snap_file: str):
        self.key = key
        self.expected = expected
        self.actual = actual
        self.snap_file = snap_file
        self.diff = _make_diff(expected, actual)
        super().__init__(self._format_message())

    def _format_message(self) -> str:
        lines = [
            f"\nSnapshot mismatch: '{self.key}'",
            f"Snapshot file: {self.snap_file}",
            "",
            "─── Diff (- expected, + actual) ───────────────────────",
            self.diff or "(no diff — values are identical after normalization)",
            "────────────────────────────────────────────────────────",
            "",
            "To update this snapshot, run:",
            "  SNAPTEST_UPDATE=1 pytest",
            "  # or",
            "  snaptest update",
        ]
        return "\n".join(lines)


def snapshot(
    value: Any,
    key: Optional[str] = None,
    update: bool = False,
) -> Any:
    """
    Assert that `value` matches its stored snapshot.

    On the first run, the snapshot is created automatically.
    On subsequent runs, the value is compared to the stored snapshot.
    If they differ, SnapshotMismatch is raised with a diff.

    Parameters
    ----------
    value : Any
        The value to snapshot. Supports dicts, lists, strings,
        dataclasses, and any object with __dict__.
    key : str, optional
        Name for this snapshot. Auto-derived from caller location if omitted.
    update : bool
        If True, update the stored snapshot regardless of match.
        Also activated globally via SNAPTEST_UPDATE=1 env var.

    Returns
    -------
    The original value (for chaining).

    Examples
    --------
    >>> result = my_api_call()
    >>> snapshot(result)  # auto-named from test function

    >>> snapshot(result, key="my_api_call_result")

    >>> # In pytest:
    >>> def test_output(snap):
    ...     snap(my_function())
    """
    caller = _get_caller()
    test_file = caller["file"]
    snap_key = key or _auto_key(caller)
    should_update = update or _UPDATE_MODE

    serialized = serialize(value)
    stored = _store.get(test_file, snap_key)
    snap_file = _store.snap_file_path(test_file)

    if stored is None:
        # First run — create snapshot
        _store.save(test_file, snap_key, serialized)
        print(f"\n  📸 Snapshot created: '{snap_key}' → {snap_file}")
        return value

    if should_update:
        _store.save(test_file, snap_key, serialized)
        print(f"\n  🔄 Snapshot updated: '{snap_key}' → {snap_file}")
        return value

    if serialized != stored:
        raise SnapshotMismatch(snap_key, stored, serialized, snap_file)

    return value


def update_snapshot(value: Any, key: Optional[str] = None) -> Any:
    """Force-update a snapshot regardless of SNAPTEST_UPDATE env var."""
    return snapshot(value, key=key, update=True)


def _get_caller() -> dict:
    """Walk the call stack to find the calling test file and function."""
    frame = inspect.currentframe()
    try:
        # Walk up past snaptest internals to the test code
        for _ in range(10):
            frame = frame.f_back
            if frame is None:
                break
            filename = frame.f_code.co_filename
            # Stop at the first frame outside snaptest itself
            if "snaptest" not in filename.replace("\\", "/").split("/")[-2:]:
                return {
                    "file": filename,
                    "function": frame.f_code.co_name,
                    "lineno": frame.f_lineno,
                }
    finally:
        del frame
    return {"file": "unknown", "function": "unknown", "lineno": 0}


def _auto_key(caller: dict) -> str:
    """Generate a snapshot key from the caller's location."""
    func = caller["function"]
    lineno = caller["lineno"]
    return f"{func}_{lineno}"


def _make_diff(expected: str, actual: str) -> str:
    """Generate a unified diff between two strings."""
    expected_lines = expected.splitlines(keepends=True)
    actual_lines = actual.splitlines(keepends=True)
    diff = difflib.unified_diff(
        expected_lines, actual_lines,
        fromfile="expected (stored)",
        tofile="actual (current)",
        n=4,
    )
    return "".join(diff)
