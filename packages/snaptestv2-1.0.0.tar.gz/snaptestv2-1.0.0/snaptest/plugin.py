"""
snaptest.plugin
---------------
pytest plugin — provides the `snap` fixture and --snapshot-update flag.
"""

import os
import pytest

from .core import snapshot as _snapshot, _store, _UPDATE_MODE
from .serializer import serialize


def pytest_configure(config):
    """Register the snaptest plugin with pytest."""
    config.addinivalue_line(
        "markers", "snapshot: mark test as a snapshot test"
    )


def pytest_addoption(parser):
    """Add --snapshot-update CLI flag to pytest."""
    parser.addoption(
        "--snapshot-update",
        action="store_true",
        default=False,
        help="Update all snapshots instead of asserting",
    )


@pytest.fixture
def snap(request):
    """
    pytest fixture for snapshot testing.

    Usage
    -----
    def test_my_output(snap):
        result = my_function()
        snap(result)

    def test_named(snap):
        snap({"key": "value"}, key="my_named_snapshot")
    """
    update_mode = (
        request.config.getoption("--snapshot-update", default=False)
        or os.environ.get("SNAPTEST_UPDATE", "").lower() in ("1", "true", "yes")
    )
    test_file = str(request.fspath)
    test_name = request.node.name
    counter = {"n": 0}

    def _snap(value, key=None):
        counter["n"] += 1
        snap_key = key or f"{test_name}_{counter['n']}"
        return _snapshot(value, key=snap_key, update=update_mode)

    return _snap


@pytest.fixture
def snapshot_store():
    """Expose the SnapshotStore for advanced use."""
    return _store
