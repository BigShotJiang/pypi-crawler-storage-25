"""
Tests for snaptest.
Run with: pytest tests/ -v
"""

import dataclasses
import os
import tempfile
from pathlib import Path

import pytest

from snaptest.serializer import serialize
from snaptest.store import SnapshotStore
from snaptest.core import SnapshotMismatch, _make_diff


# ── Serializer ────────────────────────────────────────────────────────────────

class TestSerializer:
    def test_dict(self):
        s = serialize({"b": 2, "a": 1})
        assert '"a"' in s
        assert '"b"' in s
        # Keys sorted
        assert s.index('"a"') < s.index('"b"')

    def test_list(self):
        s = serialize([1, 2, 3])
        assert "1" in s and "2" in s and "3" in s

    def test_none(self):
        assert serialize(None) == "null"

    def test_bool(self):
        assert serialize(True) == "true"
        assert serialize(False) == "false"

    def test_string(self):
        assert serialize("hello") == '"hello"'

    def test_nested(self):
        s = serialize({"users": [{"id": 1, "name": "Alice"}]})
        assert "Alice" in s

    def test_set_sorted(self):
        s1 = serialize({3, 1, 2})
        s2 = serialize({1, 2, 3})
        assert s1 == s2

    def test_dataclass(self):
        @dataclasses.dataclass
        class User:
            id: int
            name: str

        s = serialize(User(id=1, name="Alice"))
        assert "Alice" in s
        assert "1" in s

    def test_object_with_dict(self):
        class Obj:
            def __init__(self):
                self.x = 10
                self.y = 20

        s = serialize(Obj())
        assert "10" in s

    def test_stable_output(self):
        """Same input always produces same output."""
        value = {"z": 3, "a": 1, "m": [5, 4, 3]}
        assert serialize(value) == serialize(value)


# ── SnapshotStore ─────────────────────────────────────────────────────────────

class TestSnapshotStore:
    def test_save_and_get(self, tmp_path):
        store = SnapshotStore(str(tmp_path))
        test_file = str(tmp_path / "test_example.py")
        store.save(test_file, "my_key", "hello world")
        assert store.get(test_file, "my_key") == "hello world"

    def test_missing_returns_none(self, tmp_path):
        store = SnapshotStore(str(tmp_path))
        test_file = str(tmp_path / "test_example.py")
        assert store.get(test_file, "nonexistent") is None

    def test_update_existing(self, tmp_path):
        store = SnapshotStore(str(tmp_path))
        test_file = str(tmp_path / "test_example.py")
        store.save(test_file, "key", "v1")
        store.save(test_file, "key", "v2")
        assert store.get(test_file, "key") == "v2"

    def test_multiple_keys(self, tmp_path):
        store = SnapshotStore(str(tmp_path))
        test_file = str(tmp_path / "test_example.py")
        store.save(test_file, "key1", "aaa")
        store.save(test_file, "key2", "bbb")
        assert store.get(test_file, "key1") == "aaa"
        assert store.get(test_file, "key2") == "bbb"

    def test_all_keys(self, tmp_path):
        store = SnapshotStore(str(tmp_path))
        test_file = str(tmp_path / "test_example.py")
        store.save(test_file, "a", "1")
        store.save(test_file, "b", "2")
        keys = store.all_keys(test_file)
        assert "a" in keys
        assert "b" in keys

    def test_delete(self, tmp_path):
        store = SnapshotStore(str(tmp_path))
        test_file = str(tmp_path / "test_example.py")
        store.save(test_file, "k", "v")
        assert store.delete(test_file, "k") is True
        assert store.get(test_file, "k") is None

    def test_delete_nonexistent(self, tmp_path):
        store = SnapshotStore(str(tmp_path))
        test_file = str(tmp_path / "test_example.py")
        assert store.delete(test_file, "ghost") is False

    def test_creates_snapshots_dir(self, tmp_path):
        store = SnapshotStore(str(tmp_path))
        test_file = str(tmp_path / "test_example.py")
        store.save(test_file, "k", "v")
        assert (tmp_path / "__snapshots__").exists()

    def test_snap_file_is_readable(self, tmp_path):
        store = SnapshotStore(str(tmp_path))
        test_file = str(tmp_path / "test_example.py")
        store.save(test_file, "key", '{"hello": "world"}')
        snap_file = Path(store.snap_file_path(test_file))
        content = snap_file.read_text()
        assert "key" in content
        assert "hello" in content


# ── SnapshotMismatch ──────────────────────────────────────────────────────────

class TestSnapshotMismatch:
    def test_has_diff(self):
        e = SnapshotMismatch("key", "old value", "new value", "/path/to.snap")
        assert e.diff != "" or e.expected == e.actual

    def test_message_contains_key(self):
        e = SnapshotMismatch("my_key", "a", "b", "/path")
        assert "my_key" in str(e)

    def test_message_contains_update_hint(self):
        e = SnapshotMismatch("k", "a", "b", "/p")
        assert "SNAPTEST_UPDATE" in str(e)

    def test_attributes(self):
        e = SnapshotMismatch("k", "expected", "actual", "/snap")
        assert e.key == "k"
        assert e.expected == "expected"
        assert e.actual == "actual"
        assert e.snap_file == "/snap"


# ── Diff ──────────────────────────────────────────────────────────────────────

class TestDiff:
    def test_identical_no_diff(self):
        diff = _make_diff("same", "same")
        assert diff == ""

    def test_diff_shows_change(self):
        diff = _make_diff("old line\n", "new line\n")
        assert "-old line" in diff
        assert "+new line" in diff


# ── pytest fixture ────────────────────────────────────────────────────────────

class TestSnapFixture:
    def test_snap_fixture_creates_snapshot(self, snap, tmp_path):
        """First call creates snapshot, second call matches."""
        # This will create a snapshot
        snap({"hello": "world"})

    def test_snap_fixture_named(self, snap):
        snap([1, 2, 3], key="my_list_snapshot")

    def test_snap_fixture_counter(self, snap):
        snap("first")
        snap("second")
