import asyncio
import json
import os
import sys
from typing import Any

from tethernotes.config import load_vertical_config, tool_desc, t
from tethernotes import tools


# ─────────────────────────────────────────────────────────
# MCP Protocol — minimal stdio implementation
# Compatible with Claude Desktop and Claude Code
# ─────────────────────────────────────────────────────────

TOOL_REGISTRY = {
    "switch_client": {
        "fn": tools.switch_client,
        "schema": {
            "type": "object",
            "properties": {
                "name": {"type": "string", "description": "Name of the client to switch to"},
            },
            "required": ["name"],
        },
    },
    "list_clients": {
        "fn": tools.list_clients,
        "schema": {"type": "object", "properties": {}},
    },
    "add_client": {
        "fn": tools.add_client,
        "schema": {
            "type": "object",
            "properties": {
                "name": {"type": "string"},
                "description": {"type": "string"},
            },
            "required": ["name"],
        },
    },
    "get_client_brief": {
        "fn": tools.get_client_brief,
        "schema": {"type": "object", "properties": {}},
    },
    "get_client_health": {
        "fn": tools.get_client_health,
        "schema": {"type": "object", "properties": {}},
    },
    "store_memory": {
        "fn": tools.store_memory,
        "schema": {
            "type": "object",
            "properties": {
                "content": {"type": "string", "description": "The note or information to save"},
                "memory_type": {
                    "type": "string",
                    "enum": ["note", "meeting", "email", "document", "quick_note"],
                    "default": "note",
                },
                "tags": {"type": "array", "items": {"type": "string"}, "default": []},
            },
            "required": ["content"],
        },
    },
    "search_memory": {
        "fn": tools.search_memory,
        "schema": {
            "type": "object",
            "properties": {
                "query": {"type": "string", "description": "What to search for — use natural language"},
                "memory_type": {
                    "type": "string",
                    "enum": ["note", "meeting", "email", "document", "quick_note"],
                },
            },
            "required": ["query"],
        },
    },
    "quick_note": {
        "fn": tools.quick_note,
        "schema": {
            "type": "object",
            "properties": {
                "note": {"type": "string"},
            },
            "required": ["note"],
        },
    },
    "log_meeting": {
        "fn": tools.log_meeting,
        "schema": {
            "type": "object",
            "properties": {
                "summary": {"type": "string", "description": "What was discussed and decided"},
                "attendees": {"type": "string", "description": "Who was in the meeting"},
                "topics": {"type": "string", "description": "Key topics covered"},
            },
            "required": ["summary"],
        },
    },
    "ingest_emails": {
        "fn": tools.ingest_emails,
        "schema": {
            "type": "object",
            "properties": {
                "raw_emails": {
                    "type": "string",
                    "description": "Raw email content already fetched from Gmail MCP",
                },
            },
            "required": ["raw_emails"],
        },
    },
    "ingest_meeting": {
        "fn": tools.ingest_meeting,
        "schema": {
            "type": "object",
            "properties": {
                "transcript": {
                    "type": "string",
                    "description": "Meeting transcript already fetched from Granola MCP",
                },
            },
            "required": ["transcript"],
        },
    },
    "seed_client": {
        "fn": tools.seed_client,
        "schema": {
            "type": "object",
            "properties": {
                "content": {
                    "type": "string",
                    "description": "Raw text content to load into this client's memory",
                },
            },
            "required": ["content"],
        },
    },
    "add_team_member": {
        "fn": tools.add_team_member,
        "schema": {
            "type": "object",
            "properties": {
                "email": {"type": "string", "description": "Email address to invite"},
                "role": {
                    "type": "string",
                    "enum": ["viewer", "contributor"],
                    "default": "viewer",
                    "description": "viewer = read only, contributor = can add notes (needs owner approval)",
                },
            },
            "required": ["email"],
        },
    },
    "list_pending": {
        "fn": tools.list_pending,
        "schema": {"type": "object", "properties": {}},
    },
    "export_client": {
        "fn": tools.export_client,
        "schema": {"type": "object", "properties": {}},
    },
}


def _build_tools_list() -> list[dict]:
    """Build the tools list using vertical-aware descriptions."""
    result = []
    for name, entry in TOOL_REGISTRY.items():
        description = tool_desc(name) or name.replace("_", " ").title()
        result.append({
            "name": name,
            "description": description,
            "inputSchema": entry["schema"],
        })
    return result


async def _call_tool(name: str, arguments: dict) -> str:
    if name not in TOOL_REGISTRY:
        return f"Unknown tool: {name}"
    try:
        fn = TOOL_REGISTRY[name]["fn"]
        return await fn(**arguments)
    except ValueError as e:
        return str(e)
    except Exception as e:
        return f"Error: {str(e)}"


async def run_server():
    """MCP stdio server loop."""
    _check_env()
    load_vertical_config()  # warm cache on startup

    reader = asyncio.StreamReader()
    protocol = asyncio.StreamReaderProtocol(reader)
    loop = asyncio.get_event_loop()
    await loop.connect_read_pipe(lambda: protocol, sys.stdin)
    writer_transport, writer_protocol = await loop.connect_write_pipe(
        asyncio.BaseProtocol, sys.stdout
    )

    async def send(msg: dict):
        line = json.dumps(msg) + "\n"
        sys.stdout.buffer.write(line.encode())
        sys.stdout.buffer.flush()

    async def handle(request: dict):
        method = request.get("method")
        req_id = request.get("id")

        if method == "initialize":
            await send({
                "jsonrpc": "2.0", "id": req_id,
                "result": {
                    "protocolVersion": "2024-11-05",
                    "capabilities": {"tools": {}},
                    "serverInfo": {"name": "tethernotes", "version": "1.0.0"},
                },
            })

        elif method == "tools/list":
            await send({
                "jsonrpc": "2.0", "id": req_id,
                "result": {"tools": _build_tools_list()},
            })

        elif method == "tools/call":
            params = request.get("params", {})
            result = await _call_tool(params.get("name", ""), params.get("arguments", {}))
            await send({
                "jsonrpc": "2.0", "id": req_id,
                "result": {"content": [{"type": "text", "text": result}]},
            })

        elif method == "notifications/initialized":
            pass  # no response needed

    while True:
        try:
            line = await reader.readline()
            if not line:
                break
            request = json.loads(line.decode().strip())
            await handle(request)
        except json.JSONDecodeError:
            continue
        except Exception as e:
            sys.stderr.write(f"Server error: {e}\n")
            sys.stderr.flush()


def _check_env():
    key = os.environ.get("TETHERNOTES_API_KEY", "")
    if not key or not key.startswith("cm_"):
        sys.stderr.write(
            "⚠️  TETHERNOTES_API_KEY not set or invalid. "
            "Add it to your Claude Desktop settings.\n"
        )
        sys.stderr.flush()
