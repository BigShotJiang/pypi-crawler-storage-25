from tethernotes.server import run_server
import asyncio

__version__ = "1.0.0"


def main():
    asyncio.run(run_server())
