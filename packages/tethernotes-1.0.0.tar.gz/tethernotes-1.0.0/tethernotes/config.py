import os
import yaml
from pathlib import Path

_config_cache = {}
_session = {"active_mind_id": None, "active_mind_name": None}


def load_vertical_config() -> dict:
    vertical = os.environ.get("TETHERNOTES_VERTICAL", "service")
    if vertical in _config_cache:
        return _config_cache[vertical]

    config_dir = Path(__file__).parent.parent / "config"
    config_file = config_dir / f"{vertical}.yaml"

    if not config_file.exists():
        # Fall back to service if the specified vertical doesn't exist
        config_file = config_dir / "service.yaml"

    with open(config_file) as f:
        config = yaml.safe_load(f)

    _config_cache[vertical] = config
    return config


def t(key: str) -> str:
    """Get a terminology string for the active vertical."""
    config = load_vertical_config()
    return config.get("terms", {}).get(key, key)


def tool_desc(tool_name: str) -> str:
    """Get the tool description for the active vertical."""
    config = load_vertical_config()
    return config.get("tools", {}).get(tool_name, {}).get("description", "")


def get_active_mind():
    return _session["active_mind_id"], _session["active_mind_name"]


def set_active_mind(mind_id: str, mind_name: str):
    _session["active_mind_id"] = mind_id
    _session["active_mind_name"] = mind_name


def require_active_mind() -> tuple[str, str]:
    mind_id, mind_name = get_active_mind()
    if not mind_id:
        project = t("project")
        projects = t("projects")
        raise ValueError(
            f"No active {project}. Say 'switch to [name]' or 'list my {projects}' first."
        )
    return mind_id, mind_name
