from datetime import datetime
from tethernotes.api import api_get, api_post, api_delete
from tethernotes.config import t, tool_desc, get_active_mind, set_active_mind, require_active_mind


# ─────────────────────────────────────────────────────────
# CLIENT / PROJECT MANAGEMENT (5 tools)
# ─────────────────────────────────────────────────────────

async def switch_client(name: str) -> str:
    """Switch active client context by name."""
    minds = await api_get("/minds/")
    matches = [m for m in minds if name.lower() in m["name"].lower()]

    if not matches:
        projects = t("projects")
        return f"No {t('project')} found matching '{name}'. Say 'list my {projects}' to see all."

    if len(matches) > 1:
        names = ", ".join(m["name"] for m in matches)
        return f"Multiple matches: {names}. Be more specific."

    mind = matches[0]
    set_active_mind(mind["id"], mind["name"])

    lines = [f"Switched to **{mind['name']}**."]
    lines.append(f"Memories: {mind['memory_count']} · Last activity: {_fmt_date(mind.get('last_activity'))}")
    if mind.get("description"):
        lines.append(mind["description"])
    return "\n".join(lines)


async def list_clients() -> str:
    """List all clients with health signals."""
    minds = await api_get("/minds/")

    if not minds:
        article = t("project_article")
        return f"No {t('projects')} yet. Say 'add {article}' to create your first one."

    lines = [f"**Your {t('projects')}** ({len(minds)} total)\n"]
    for m in minds:
        health_icon = {"active": "🟢", "quiet": "🟡", "stale": "🔴"}.get(m.get("health", "stale"), "⚪")
        last = _fmt_date(m.get("last_activity"))
        lines.append(f"{health_icon} **{m['name']}** — {m['memory_count']} memories · last activity {last}")

    active_id, active_name = get_active_mind()
    if active_name:
        lines.append(f"\nCurrently active: {active_name}")

    return "\n".join(lines)


async def add_client(name: str, description: str = "", vertical: str = "service") -> str:
    """Create a new client mind."""
    result = await api_post("/minds/", {
        "name": name,
        "description": description,
        "vertical": vertical,
    })
    set_active_mind(result["id"], result["name"])
    return (
        f"Created **{name}** and set as active {t('project')}.\n"
        f"Start adding notes: 'Remember that {name} prefers weekly updates' or "
        f"'Log a meeting with {name}'"
    )


async def get_client_brief() -> str:
    """Get a full pre-call brief for the active client."""
    mind_id, mind_name = require_active_mind()
    mind = await api_get(f"/minds/{mind_id}")

    # Pull recent memories
    recent = await api_post("/memories/search", {
        "mind_id": mind_id,
        "query": "recent updates decisions open items",
        "limit": 8,
    })

    lines = [f"## {t('brief').title()}: {mind_name}\n"]
    lines.append(f"**Memories:** {mind['memory_count']} · **Last activity:** {_fmt_date(mind.get('last_activity'))}")

    if mind.get("description"):
        lines.append(f"**About:** {mind['description']}\n")

    if mind.get("pending_count", 0) > 0:
        lines.append(f"⚠️ {mind['pending_count']} team notes awaiting your review (say 'show pending notes')\n")

    if recent:
        lines.append("**Recent notes:**")
        for m in recent:
            date = _fmt_date(m.get("created_at"), short=True)
            lines.append(f"- [{date}] {m['content'][:200]}")
    else:
        lines.append("No notes yet for this client.")

    return "\n".join(lines)


async def get_client_health() -> str:
    """Check health and risk signals for the active client."""
    mind_id, mind_name = require_active_mind()
    mind = await api_get(f"/minds/{mind_id}")

    last = mind.get("last_activity")
    days_since = None
    if last:
        last_dt = datetime.fromisoformat(last.replace("Z", "+00:00"))
        days_since = (datetime.utcnow().replace(tzinfo=last_dt.tzinfo) - last_dt).days

    health = mind.get("health", "unknown")
    icon = {"active": "🟢", "quiet": "🟡", "stale": "🔴"}.get(health, "⚪")

    lines = [f"{icon} **{mind_name}** — {health.upper()}\n"]
    lines.append(f"Memories stored: {mind['memory_count']}")

    if days_since is not None:
        lines.append(f"Last activity: {days_since} days ago ({_fmt_date(last)})")
    else:
        lines.append("Last activity: never recorded")

    if days_since is not None and days_since > 21:
        lines.append(f"\n⚠️ No activity in {days_since} days. Consider a check-in.")

    if mind.get("pending_count", 0) > 0:
        lines.append(f"⚠️ {mind['pending_count']} pending team notes need review.")

    return "\n".join(lines)


# ─────────────────────────────────────────────────────────
# MEMORY (4 tools)
# ─────────────────────────────────────────────────────────

async def store_memory(content: str, memory_type: str = "note", tags: list[str] = []) -> str:
    """Save a note to the active client."""
    mind_id, mind_name = require_active_mind()

    result = await api_post("/memories/", {
        "mind_id": mind_id,
        "content": content,
        "memory_type": memory_type,
        "tags": tags,
        "source": "manual",
    })

    if result.get("is_pending"):
        return f"Note saved and sent to {mind_name}'s owner for approval."
    return f"Saved to **{mind_name}**."


async def search_memory(query: str, memory_type: str = None) -> str:
    """Semantic search across the active client's memory."""
    mind_id, mind_name = require_active_mind()

    body = {"mind_id": mind_id, "query": query, "limit": 8}
    if memory_type:
        body["memory_type"] = memory_type

    results = await api_post("/memories/search", body)

    if not results:
        return f"Nothing found in **{mind_name}**'s memory for: '{query}'"

    lines = [f"**{len(results)} results** for '{query}' in {mind_name}:\n"]
    for m in results:
        date = _fmt_date(m.get("created_at"), short=True)
        tag_str = f" [{', '.join(m['tags'])}]" if m.get("tags") else ""
        lines.append(f"- [{date}]{tag_str} {m['content'][:300]}")

    return "\n".join(lines)


async def quick_note(note: str) -> str:
    """Fast unstructured capture — no type or tags needed."""
    return await store_memory(note, memory_type="quick_note")


async def log_meeting(summary: str, attendees: str = "", topics: str = "") -> str:
    """Log a structured meeting note."""
    mind_id, mind_name = require_active_mind()

    content_parts = [f"MEETING NOTE: {summary}"]
    if attendees:
        content_parts.append(f"Attendees: {attendees}")
    if topics:
        content_parts.append(f"Topics covered: {topics}")

    content = "\n".join(content_parts)
    result = await api_post("/memories/", {
        "mind_id": mind_id,
        "content": content,
        "memory_type": "meeting",
        "tags": ["meeting"],
        "source": "manual",
    })

    if result.get("is_pending"):
        return "Meeting note saved and sent for owner approval."
    return f"Meeting logged for **{mind_name}**."


# ─────────────────────────────────────────────────────────
# INGEST (3 tools)
# ─────────────────────────────────────────────────────────

async def ingest_emails(raw_emails: str, max_emails: int = 10) -> str:
    """
    Accepts raw email content (already fetched via Gmail MCP) and stores
    the relevant details to the active client's memory.
    """
    mind_id, mind_name = require_active_mind()

    if not raw_emails.strip():
        return "No email content provided. Fetch emails first using your Gmail connection."

    # Each email becomes a memory entry
    # In practice Claude will have already fetched the emails and passes content here
    result = await api_post("/memories/", {
        "mind_id": mind_id,
        "content": f"EMAIL THREAD SUMMARY:\n{raw_emails[:4000]}",
        "memory_type": "email",
        "tags": ["email", "ingest"],
        "source": "gmail",
    })

    return f"Email content ingested and saved to **{mind_name}**."


async def ingest_meeting(transcript: str) -> str:
    """
    Accepts a meeting transcript (already fetched via Granola MCP) and
    stores the key details to the active client's memory.
    """
    mind_id, mind_name = require_active_mind()

    if not transcript.strip():
        return "No transcript provided. Fetch the meeting from Granola first."

    result = await api_post("/memories/", {
        "mind_id": mind_id,
        "content": f"MEETING TRANSCRIPT:\n{transcript[:6000]}",
        "memory_type": "meeting",
        "tags": ["meeting", "transcript", "ingest"],
        "source": "granola",
    })

    return f"Meeting transcript ingested and saved to **{mind_name}**."


async def seed_client(content: str) -> str:
    """
    Bulk-load existing notes or file content for a client.
    Pass the raw text — it will be chunked and stored.
    """
    mind_id, mind_name = require_active_mind()

    # Simple chunking — split into ~800 char chunks on paragraph boundaries
    chunks = _chunk_text(content, max_chars=800)
    saved = 0

    for chunk in chunks:
        if chunk.strip():
            await api_post("/memories/", {
                "mind_id": mind_id,
                "content": chunk,
                "memory_type": "document",
                "tags": ["seed"],
                "source": "seed",
            })
            saved += 1

    return f"Loaded {saved} notes into **{mind_name}**. Ready to search."


# ─────────────────────────────────────────────────────────
# TEAM (3 tools)
# ─────────────────────────────────────────────────────────

async def add_team_member(email: str, role: str = "viewer") -> str:
    """Grant a team member access to the active client."""
    mind_id, mind_name = require_active_mind()

    valid_roles = ["viewer", "contributor"]
    if role not in valid_roles:
        return f"Invalid role '{role}'. Choose from: {', '.join(valid_roles)}"

    await api_post("/team/invite", {
        "mind_id": mind_id,
        "email": email,
        "role": role,
    })

    return (
        f"Invited **{email}** to {mind_name} as a {role}.\n"
        f"They'll get an email with setup instructions. "
        f"{'As a contributor, their notes will need your approval.' if role == 'contributor' else 'As a viewer, they can search and read notes.'}"
    )


async def list_pending() -> str:
    """List team notes awaiting owner approval for the active client."""
    mind_id, mind_name = require_active_mind()
    memories = await api_get(f"/memories/pending/{mind_id}")

    if not memories:
        return f"No pending notes for **{mind_name}**."

    lines = [f"**{len(memories)} pending notes** for {mind_name} — review each:\n"]
    for m in memories:
        date = _fmt_date(m.get("created_at"), short=True)
        lines.append(f"ID: `{m['id'][:8]}` · [{date}] {m['content'][:200]}")
        lines.append(f"  → Say 'approve {m['id'][:8]}' or 'dismiss {m['id'][:8]}'\n")

    return "\n".join(lines)


async def export_client() -> str:
    """Export the full active client record as a structured summary."""
    mind_id, mind_name = require_active_mind()
    data = await api_get(f"/export/{mind_id}")

    client = data["client"]
    memories = data["memories"]
    documents = data["documents"]

    lines = [
        f"# {t('brief').title()} Export: {client['name']}",
        f"Exported: {datetime.utcnow().strftime('%B %d, %Y')}\n",
        f"**Description:** {client.get('description') or 'None'}",
        f"**Created:** {_fmt_date(client.get('created_at'))}",
        f"**Last activity:** {_fmt_date(client.get('last_activity'))}",
        f"**Total notes:** {len(memories)}\n",
    ]

    if memories:
        lines.append("## Notes (chronological)\n")
        for m in memories:
            lines.append(f"[{_fmt_date(m['date'], short=True)}] **{m['type'].upper()}** — {m['content'][:400]}")
            if m.get("tags"):
                lines.append(f"  Tags: {', '.join(m['tags'])}")
            lines.append("")

    if documents:
        lines.append("## Documents\n")
        for d in documents:
            lines.append(f"- {d['filename']} ({d.get('source', 'upload')}) — {d.get('summary', '')[:100]}")

    return "\n".join(lines)


# ─────────────────────────────────────────────────────────
# Helpers
# ─────────────────────────────────────────────────────────

def _fmt_date(iso_str, short: bool = False) -> str:
    if not iso_str:
        return "never"
    try:
        dt = datetime.fromisoformat(iso_str.replace("Z", "+00:00"))
        if short:
            return dt.strftime("%b %d")
        return dt.strftime("%B %d, %Y")
    except Exception:
        return iso_str


def _chunk_text(text: str, max_chars: int = 800) -> list[str]:
    paragraphs = text.split("\n\n")
    chunks, current = [], ""
    for p in paragraphs:
        if len(current) + len(p) > max_chars:
            if current:
                chunks.append(current.strip())
            current = p
        else:
            current += "\n\n" + p
    if current.strip():
        chunks.append(current.strip())
    return chunks
