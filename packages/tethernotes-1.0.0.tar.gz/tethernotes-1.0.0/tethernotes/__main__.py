from tethernotes import main
main()
