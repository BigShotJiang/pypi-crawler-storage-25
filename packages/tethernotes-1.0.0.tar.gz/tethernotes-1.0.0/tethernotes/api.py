import httpx
import os
from tenacity import retry, stop_after_attempt, wait_exponential

API_BASE = os.environ.get("TETHERNOTES_API_URL", "https://api.tethernotes.app/api/v1")
API_KEY = os.environ.get("TETHERNOTES_API_KEY", "")

HEADERS = {
    "X-API-Key": API_KEY,
    "Content-Type": "application/json",
}


def _headers():
    # Re-read at call time in case key was set after import
    return {
        "X-API-Key": os.environ.get("TETHERNOTES_API_KEY", API_KEY),
        "Content-Type": "application/json",
    }


@retry(stop=stop_after_attempt(3), wait=wait_exponential(min=1, max=8))
async def api_get(path: str) -> dict:
    async with httpx.AsyncClient(timeout=30) as client:
        r = await client.get(f"{API_BASE}{path}", headers=_headers())
        r.raise_for_status()
        return r.json()


@retry(stop=stop_after_attempt(3), wait=wait_exponential(min=1, max=8))
async def api_post(path: str, body: dict) -> dict:
    async with httpx.AsyncClient(timeout=30) as client:
        r = await client.post(f"{API_BASE}{path}", json=body, headers=_headers())
        r.raise_for_status()
        return r.json()


@retry(stop=stop_after_attempt(3), wait=wait_exponential(min=1, max=8))
async def api_patch(path: str, body: dict) -> dict:
    async with httpx.AsyncClient(timeout=30) as client:
        r = await client.patch(f"{API_BASE}{path}", json=body, headers=_headers())
        r.raise_for_status()
        return r.json()


@retry(stop=stop_after_attempt(3), wait=wait_exponential(min=1, max=8))
async def api_delete(path: str) -> dict:
    async with httpx.AsyncClient(timeout=30) as client:
        r = await client.delete(f"{API_BASE}{path}", headers=_headers())
        r.raise_for_status()
        return r.json()
