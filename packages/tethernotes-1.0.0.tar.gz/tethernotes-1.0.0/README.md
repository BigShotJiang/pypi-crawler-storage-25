# Tethernotes

AI-powered client memory for service businesses. Every note connected, nothing forgotten.

Tethernotes is an MCP server that gives Claude persistent, client-scoped memory across conversations. Add notes, search history, prep for calls, and loop in your team — all by talking to Claude.

---

## Install

```
pip install tethernotes
```

## Setup

Add this to your Claude Desktop settings (`~/.claude/settings.json` on Mac/Linux, `%APPDATA%\Claude\settings.json` on Windows):

```json
{
  "mcpServers": {
    "tethernotes": {
      "command": "python",
      "args": ["-m", "tethernotes"],
      "env": {
        "TETHERNOTES_API_KEY": "your-key-here"
      }
    }
  }
}
```

Restart Claude Desktop. That's it.

---

## Quick start — 5 things to try first

```
Add a new client called Acme Co
Switch to Acme Co
Remember that Acme's main contact is Sarah and she prefers Slack over email
What do I know about Acme's communication preferences?
Get a brief on Acme before my call
```

---

## What you can say to Claude

| What you want to do | Say this |
|---|---|
| See all your clients | `List my clients` |
| Switch to a client | `Switch to [name]` |
| Add a new client | `Add a new client called [name]` |
| Save a note | `Remember that [client] [detail]` |
| Quick capture | `Quick note: [anything]` |
| Search history | `What do I know about [topic]?` |
| Pre-call prep | `Get a brief on [client]` |
| Check health | `How's [client] doing?` |
| Log a meeting | `Log a meeting with [client] — we discussed [topics]` |
| Pull in emails | `Ingest recent emails about [client]` |
| Pull in a meeting | `Ingest my last Granola meeting for [client]` |
| Export a client | `Export everything on [client]` |
| Add a team member | `Add sarah@myco.com to [client] as a viewer` |
| Review team notes | `Show pending notes for [client]` |

---

## Plans

| | Free | Starter | Pro |
|---|---|---|---|
| Clients | 3 | 20 | Unlimited |
| Memories per client | 100 | 2,000 | Unlimited |
| Team members | — | 2 | Unlimited |

Get your key at [tethernotes.com](https://tethernotes.com)

---

## Support

Reply to your welcome email or reach us at hello@tethernotes.com
