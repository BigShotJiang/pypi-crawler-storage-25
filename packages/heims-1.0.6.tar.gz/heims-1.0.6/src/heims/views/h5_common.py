from urllib import parse
from abc import ABC

from django.http import HttpResponseRedirect

from .common_views import BaseView
from .. import UserService
from ..common import config
from ..common.exceptions import RenderException
from ..utils.wechat.wechat_util import Wechat


class H5CommonView(BaseView, ABC):
    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.app_id = ""
        self.app_secret = ""
        self.client_type = "public_account"
        self.log_try_times = 0

    def get_info_from_request(self, request):
        self.log_try_times = request.session.get('log_try_times', 0)
        super().get_info_from_request(request)
        self.app_id = request.META.get("HTTP_APPID", "")
        if self.app_id:
            self.app_secret = config.WECHAT_INFO.get("public_account", {}).get(self.app_id, "")
            if not self.app_secret:
                self.app_secret = config.WECHAT_INFO.get("applet", {}).get(self.app_id, "")

    def other_login(self, login_type="base"):
        if login_type != "userinfo":
            login_type = "base"
        if not self.user_id and self.app_id and self.log_try_times < 3:
            if self.get_data.get('code', ''):
                wechat_info = Wechat(app_id=self.app_id, app_secret=self.app_secret).log_by_code(self.get_data['code'],
                                                                                                 client_type=self.client_type)
                self.log_try_times += 1
                if wechat_info:
                    self.log_try_times = 0
                    log_info = UserService.login(self.dao, self.cache, openid=wechat_info.get('openid'),
                                                 unionid=wechat_info.get('unionid'))
                    if log_info and log_info.get('code', 0) in (200, '200'):
                        self.user_info = log_info.get('data', {})
                        if self.user_info:
                            self.user_id = UserService.save_user_info(self.cache, self.user_info, self.auth_token)

                    if not self.user_id:
                        self.user_id = UserService.create_user(self.dao, {
                            "openid": wechat_info.get('openid'),
                            "unionid": wechat_info.get('unionid'),
                            "status": 0
                        })

                        if self.user_id:
                            log_info = UserService.login(self.dao, self.cache, user_id=self.user_id)
                            if log_info and log_info.get('code', 0) in (200, '200'):
                                self.user_info = log_info.get('data', {})
                                if self.user_info:
                                    UserService.save_user_info(self.cache, self.user_info, self.auth_token)
                self.request.session['log_try_times'] = self.log_try_times
            else:
                domain = self.request.scheme + "://" + self.request.get_host()
                url = self.request.get_full_path().replace('is_ajax', 'x')
                if url.startswith('/h5-api/'):
                    url = url[7:]
                url = domain + url
                jump_url = parse.quote(url)
                url = (
                    f"https://open.weixin.qq.com/connect/oauth2/authorize?appid={self.app_id}&redirect_uri={jump_url}&"
                    f"response_type=code&scope=snsapi_{login_type}&state=STATE#wechat_redirect")
                render = HttpResponseRedirect(url)
                raise RenderException(render, "")
