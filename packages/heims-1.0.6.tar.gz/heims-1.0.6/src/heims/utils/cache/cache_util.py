from abc import abstractmethod
from typing import Any, Dict, List, Callable


class CacheClient:
    @abstractmethod
    def get(self, key: str, default: Any = None) -> Any:
        pass

    @abstractmethod
    def set(self, key: str, value: Any, *, ex: int = None, px: int = None, nx: bool = False, xx: bool = False) -> bool:
        pass

    @abstractmethod
    def delete(self, *keys) -> int:
        pass

    @abstractmethod
    def exists(self, *keys) -> int:
        pass

    @abstractmethod
    def expire(self, key: str, _time: int) -> bool:
        pass

    @abstractmethod
    def ttl(self, key: str) -> int:
        pass

    @abstractmethod
    def incr(self, key: str, amount: int = 1) -> int:
        pass

    @abstractmethod
    def decr(self, key: str, amount: int = 1) -> int:
        pass

    @abstractmethod
    def hget(self, key: str, field: str, default: Any = None) -> Any:
        pass

    @abstractmethod
    def hset(self, key: str, field: str, value: Any) -> int:
        pass

    @abstractmethod
    def h_get_all(self, key: str) -> Dict:
        pass

    @abstractmethod
    def hm_set(self, key: str, mapping: Dict) -> bool:
        pass

    @abstractmethod
    def l_push(self, key: str, *values) -> int:
        pass

    @abstractmethod
    def r_push(self, key: str, *values) -> int:
        pass

    @abstractmethod
    def lrange(self, key: str, start: int = 0, end: int = -1) -> List:
        pass

    @abstractmethod
    def s_add(self, key: str, *values) -> int:
        pass

    @abstractmethod
    def s_members(self, key: str) -> set:
        pass

    @abstractmethod
    def z_add(self, key: str, mapping: Dict[Any, float]) -> int:
        pass

    @abstractmethod
    def z_range(self, key: str, start: int = 0, end: int = -1, with_scores: bool = False) -> List:
        pass

    @abstractmethod
    def pipeline(self, transaction: bool = True):
        pass

    @abstractmethod
    def mget(self, keys: List[str]) -> List:
        pass

    @abstractmethod
    def mset(self, mapping: Dict[str, Any]) -> bool:
        pass

    @abstractmethod
    def scan_iter(self, match: str = None, count: int = 100) -> List:
        pass

    @abstractmethod
    def get_keys(self, pattern: str = "*") -> List[str]:
        pass

    @abstractmethod
    def clear_db(self, pattern: str = "*") -> int:
        pass

    @abstractmethod
    def cached(self, key_func: Callable = None, ttl: int = 300, prefix: str = "cache"):
        pass

    @abstractmethod
    def cache_delete(self, key_func: Callable, *args, **kwargs):
        pass

    @abstractmethod
    def ping(self) -> bool:
        pass

    @abstractmethod
    def info(self, section: str = None) -> Dict:
        pass

    @abstractmethod
    def get_stats(self) -> Dict:
        pass

    @abstractmethod
    def get_connection_info(self) -> Dict:
        pass

    @abstractmethod
    def close(self):
        pass
