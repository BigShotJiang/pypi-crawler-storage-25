from abc import abstractmethod
from typing import Union, List, Dict, Optional

import MySQLdb


class DBClient:

    @abstractmethod
    def get_table_structure(self, table_name: str, db_name: str = "") -> dict:
        pass

    @abstractmethod
    def set_table_structure(self, table_name: str, db_name: str = ""):
        pass

    @abstractmethod
    def init_table_structure(self, db_name: str = ""):
        pass

    @abstractmethod
    def reset_table_structure(self, table_name: str = "", db_name: str = ""):
        pass

    @abstractmethod
    def filter_columns(self, table: str, columns: List[str], db_name: str = "") -> List[str]:
        pass

    @abstractmethod
    def check_columns(self, table: str, columns: List[str], db_name: str = "") -> bool:
        pass

    @abstractmethod
    def get_db_name(self):
        pass

    @abstractmethod
    def get_connection(self):
        pass

    @abstractmethod
    def execute(self, sql: str, params: Union[tuple, list, dict] = None, conn: MySQLdb.Connection = None) -> int:
        pass

    @abstractmethod
    def executemany(self, sql: str, params_list: List[Union[tuple, dict, list]],
                    conn: MySQLdb.Connection = None) -> int:
        pass

    @abstractmethod
    def query(self, sql: str, params: Union[tuple, list, dict] = None, conn: MySQLdb.Connection = None) -> List[Dict]:
        pass

    @abstractmethod
    def query_one(self, sql: str, params: Union[tuple, list, dict] = None, conn: MySQLdb.Connection = None) -> Optional[
        Dict]:
        pass

    @abstractmethod
    def query_value(self, sql: str, params: Union[tuple, list, dict] = None, default=None,
                    conn: MySQLdb.Connection = None):
        pass

    @abstractmethod
    def transaction(self, isolation_level: str = None):
        pass

    @abstractmethod
    def call_procedure(self, proc_name: str, args: tuple = None):
        pass

    @abstractmethod
    def table_exists(self, table_name: str, db_name: str = "") -> bool:
        pass

    @abstractmethod
    def batch_insert(self, table: str, columns: List[str], data: Union[List[List], List[Dict]], batch_size: int = 1000,
                     *, ignore_duplicates: bool = False, update_fields: List[str] = None, db_name:str="") -> int:
        pass

    @abstractmethod
    def set_data_time(self, table: str, data: Union[Dict, list, tuple], action_type: str = 'add', db_name: str = "", *,
                      columns: List[str] = None):
        pass

    @abstractmethod
    def upsert(self, table: str, data: Dict, *, conflict_columns: Union[List[str], str] = None,
               ignore_duplicate: bool = False, update_columns: List[str] = None,
               search_columns: List[str] = None) -> int:
        pass

    @abstractmethod
    def update(self, table_name: str, *, data: dict = None, where_condition: str = "", args: list = None,
               search_dict: dict = None, db_name="", set_str: str = "", _id: int = 0) -> int:
        pass

    @abstractmethod
    def delete(self, table_name: str, *, data: Union[dict, List[dict]] = None, where_condition: str = "",
               args: list = None, search_dict: dict = None, db_name="", _id: Union[int, List[int]] = 0):
        pass

    @abstractmethod
    def get_info(self, table: str, columns_str: str = "", *, columns: List[str] = None, where_condition: str = "",
                 args: list = None, _id: int = 0, search_dict: dict = None, db_name: str = "") -> dict:
        pass

    @abstractmethod
    def get_list(self, table: str, columns_str: str = "", *, columns: List[str] = None, where_condition: str = "",
                 args: list = None, search_dict: dict = None, db_name: str = "", offset: int = 0, size: int = 10,
                 group_by: str = "", having: str = "", order_by: str = None, filter_delete: bool = True) -> (
    int, List[dict]):
        pass

    @abstractmethod
    def build_select(self, table: str, columns_str: str = "", *, columns: List[str] = None, where_condition: str = "",
                     args: list = None, search_dict: dict = None, db_name: str = "", order_by: str = "",
                     offset: int = 0, size: int = 0, group_by: str = "", having: str = "", filter_delete: bool = True) -> (List, List):
        pass

    @abstractmethod
    def build_update(self, table_name: str, *, data: dict = None, where_condition: str = "", args: list = None,
                     search_dict: dict = None, db_name="", set_str: str = "", _id: Union[int, List[int]] = 0,
                     table_structure: dict = None) -> (List, List):
        pass

    @abstractmethod
    def create_where(self, search_dict: dict, table: str, db_name: str = "", table_structure: dict = None) -> (
            str, list):
        pass

    @abstractmethod
    def close(self):
        pass
