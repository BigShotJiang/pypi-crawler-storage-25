from typing import Dict

from .code_service import CodeService
from ..common import config
from ..common.functions import trans_str_to_arr, is_integer, crypt
from ..utils.db.mysql_util import DBClient
from ..utils.cache.cache_util import  CacheClient


class UserService:
    @classmethod
    def login(cls, dao: DBClient, cache: CacheClient, *, user_id:int=0, username: str="", password: str="", mobile: str="", email: str="", code: str="", openid:str="", unionid:str="")->Dict:
        user_tables = config.BASE_INFO.get("user_tables", {})
        if user_tables:
            user_table = user_tables.get("user", "")
            if user_table:
                search_dict = {}
                where_condition = ""
                args = []
                if user_id:
                    search_dict = {"id": user_id}
                elif openid or unionid:
                    user_table_structure = dao.get_table_structure(user_table)
                    if user_table_structure:
                        where_part = []
                        if "openid" in user_table_structure:
                            where_part.append("(openid!='' AND openid=%s)")
                            args.append(openid)
                        if "unionid" in user_table_structure:
                            where_part.append("(unionid!='' AND unionid=%s)")
                            args.append(unionid)
                        where_condition = " OR ".join(where_part)
                elif (username or mobile) and password:
                    if username:
                        search_dict = {"username": username, "password": password}
                    else:
                        search_dict = {"mobile": mobile, "password": password}
                elif (mobile or email) and code:
                    code_rlt = CodeService.confirm_code(dao, cache, mobile=mobile, code=code, email=email, code_type="login")
                    if code_rlt == 1:
                        search_dict = {"mobile": mobile} if mobile else {"email": email}
                    else:
                        return config.ERROR_INFO.get({2: "code_error", 3: "code_used", 4: "code_expired"}.get(code_rlt, "code_error"), {})
                user_info = dao.get_info(user_table, "", columns=["id", "status"], search_dict=search_dict, where_condition=where_condition, args=args)
                if user_info:
                    if user_info.get('id', 0):
                        cls.get_info_by_id(user_info.get('id', 0), dao, cache)
                        return {"code": 200, "msg": "success", "data": user_info}
                    else:
                        return config.ERROR_INFO.get("user_not_exist", {})
                else:
                    return config.ERROR_INFO.get("user_not_exist", {})

        return {"code": 500, "msg": "table not exists"}

    @classmethod
    def save_user_info(cls, cache:CacheClient, user_info:Dict, auth_token:str)->int:
        if user_info and isinstance(user_info, dict):
            user_id = user_info.get("id", 0)
            if user_id:
                cache.hset("user_info", str(user_id), user_info)
                cache.set(f"user_id_{auth_token}", str(user_id), ex=config.BASE_INFO.get('auth_token_expire_time', 3600))
            return user_id
        return 0

    @classmethod
    def create_user(cls, dao:DBClient, user_info:Dict)->int:
        user_tables = config.BASE_INFO.get("user_tables", {})
        if user_tables:
            user_table = user_tables.get("user", "")
            if user_table:
                _id = dao.upsert(user_table, user_info)
        return _id

    @classmethod
    def get_info_by_id(cls, user_id:int, dao:DBClient, cache:CacheClient):
        user_info = cache.hget("user_info", str(user_id), {})
        if not user_info:
            #     "user_tables": {
            #         "user": "user",
            #         "user_role": "user_role",
            #         "role": "role",
            #         "role_permission": "role_permission",
            #         "permission": "permission",
            #         "user_department": "user_department",
            #         "department": "department",
            #     }

            # 获取用户信息
            user_tables = config.BASE_INFO.get("user_tables", {})
            if user_tables:
                user_table = user_tables.get("user", "")
                if user_table:
                    row = dao.get_info(user_table,  "", _id=user_id)
                    if row:
                        user_info.update(row)
                        if 'role_list' in user_info:
                            user_info['role_list'] = trans_str_to_arr(user_info['role_list'])
                        elif "role_id" in user_info:
                            user_info['role_list'] = [user_info['role_id']]
                        else:
                            user_role_table = user_tables.get("user_role", "")
                            if user_role_table:
                                c, l = dao.get_list(user_role_table, "", search_dict={"user_id": user_id}, size=-1)
                                if c:
                                    user_info['role_list'] = [item['role_id'] for item in l if item.get("role_id", 0)]
                                else:
                                    user_info['role_list'] = []

                        if 'permission_list' in user_info:
                            user_info['permission_list'] = trans_str_to_arr(user_info['permission_list'])
                        else:
                            if "role_list" in user_info and isinstance(user_info['role_list'], (list, tuple)):
                                role_permission_table = user_tables.get("role_permission", "")
                                permission_table = user_tables.get("permission", '')
                                if role_permission_table and permission_table:
                                    _type = type(user_info['role_list'][0])
                                    if _type == int:
                                        role_ids = user_info['role_list']
                                    elif _type == str:
                                        role_ids = [int(item) for item in user_info['role_list'] if is_integer(str(item))]
                                    elif _type == dict:
                                        role_ids = [item['role_id'] for item in user_info['role_list'] if item.get('role_id', 0)]
                                    else:
                                        role_ids = None

                                    if role_ids:
                                        if config.BASE_INFO.get('admin_role_id', 0) and config.BASE_INFO['admin_role_id'] in role_ids:
                                            c, l = dao.get_list(permission_table, "id as permission_id", size=-1)
                                        else:
                                            c, l = dao.get_list(role_permission_table, "", search_dict={"role_id": {"IN", role_ids}}, size=-1)

                                        user_info['permission_list'] = [row['permission_id'] for row in l if row.get("permission_id", 0)]

                        if "department_list" in user_info:
                            user_info['department_list'] = trans_str_to_arr(user_info['department_list'])
                        elif "department_id" in user_info:
                            user_info['department_list'] = [user_info['department_id']]
                        else:
                            user_department_table = user_tables.get("user_department", "")
                            if user_department_table:
                                c, user_info['department_list'] = dao.get_list(user_department_table, "", search_dict={"user_id": user_id}, size=-1)


                        cache.hset("user_info", str(user_id), user_info)

        return user_info
