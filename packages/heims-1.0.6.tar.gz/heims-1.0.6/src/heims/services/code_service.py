from ..utils.cache.cache_util import CacheClient
from ..utils.db.mysql_util import DBClient

class CodeService:
    @classmethod
    def send_code(cls, dao:DBClient, cache:CacheClient, *, mobile:str="", email:str="", code:str="", code_type:str="", code_length:int=6)->str:
        return code

    @classmethod
    def confirm_code(cls, dao:DBClient, cache:CacheClient, *, mobile:str="", email:str="", code:str="", code_type:str="")->int:
        return 1
