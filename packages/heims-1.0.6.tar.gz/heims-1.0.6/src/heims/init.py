import os
import yaml
from .common.functions import read_yaml_file

# Ensure pyyaml is installed: pip install pyyaml


def initialize():
    folder = os.getcwd()
    file = os.path.join(folder, "config.yaml")
    if os.path.exists(file):
        from .common import config
        yaml_config = read_yaml_file(file)
        if yaml_config:
            for section, value in yaml_config.items():
                info = f"{section.upper()}_INFO"
                if info in config.__all__:
                    config_info = getattr(config, info)
                    update_by_type(config_info, value)


def update_by_type(old_data: dict, new_data: dict):
    for key, value in new_data.items():
        if key not in old_data:
            old_data.update({key: value})
        else:
            _type = type(old_data[key])
            if not isinstance(value, _type):
                try:
                    old_data[key] = _type(value)
                except Exception:
                    old_data[key] = value
            else:
                old_data[key] = value


if __name__ == '__main__':
    initialize()