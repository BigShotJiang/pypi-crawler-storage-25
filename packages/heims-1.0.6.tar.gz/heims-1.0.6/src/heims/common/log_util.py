import datetime
import logging
import os
from random import random

from . import config


class LogUtil:
    def __init__(self, *, base_dir:str="", name: str=""):
        if not name:
            name = str(random())[2:12]
        self.logger = []
        if not base_dir:
            base_dir = config.BASE_INFO['base_dir']
        log_folder = os.path.join(base_dir, "log")
        if not os.path.exists(log_folder):
            os.mkdir(log_folder)
        today = datetime.datetime.now().strftime('%Y%m%d')
        for i in range(2):
            logger = logging.getLogger(name)
            logger.setLevel(logging.DEBUG)


            file_handler = logging.FileHandler(os.path.join(log_folder, f"{today}-{'access' if i else 'error'}.log"), encoding="utf-8")
            file_handler.setFormatter(logging.Formatter(f'%(asctime)s - %(name)s - %(levelname)s - %(message)s'))
            logger.addHandler(file_handler)
            self.logger.append(logger)


    def __del__(self):
        for logger in self.logger:
            for handler in logger.handlers:
                try:
                    if isinstance(handler, logging.FileHandler):
                        handler.close()
                        logger.removeHandler(handler)
                except Exception:
                    pass

    def info(self, msg, *args, **kwargs):
        self.logger[1].info(msg, *args, **kwargs)


    def error(self, msg, *args, **kwargs):
        self.logger[0].error(msg, *args, **kwargs)

    def get_logger(self, index=0):
        return self.logger[index]
