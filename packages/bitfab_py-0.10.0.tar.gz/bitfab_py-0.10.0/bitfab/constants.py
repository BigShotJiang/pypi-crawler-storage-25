"""Constants for the Bitfab SDK."""

from contextvars import ContextVar
from importlib.metadata import PackageNotFoundError, version
from typing import Any

# Default service URL for Bitfab API
DEFAULT_SERVICE_URL = "https://www.bitfab.ai"

# Get SDK version from installed package metadata
try:
    __version__ = version("bitfab-py")
except PackageNotFoundError:
    __version__ = "unknown"

# Context variable used by replay to inject test_run_id and input_source_span_id
# into the span decorator without re-wrapping the function.
_replay_context: ContextVar[dict[str, Any] | None] = ContextVar(
    "bitfab_replay_context", default=None
)
