"""Bitfab client for provider-based API calls."""

from bitfab.client import (
    AllowedEnvVars,
    Bitfab,
    BitfabFunction,
    CurrentSpan,
    CurrentTrace,
    SpanType,
    flush_traces,
    get_current_span,
    get_current_trace,
)
from bitfab.replay import ReplayItem, ReplayResult

# Only export BitfabTracingProcessor if openai-agents is available
try:
    from bitfab.tracing import (
        BitfabOpenAITracingProcessor as BitfabTracingProcessor,
    )

    __all__ = [
        "AllowedEnvVars",
        "Bitfab",
        "BitfabFunction",
        "BitfabTracingProcessor",
        "CurrentSpan",
        "CurrentTrace",
        "ReplayItem",
        "ReplayResult",
        "SpanType",
        "flush_traces",
        "get_current_span",
        "get_current_trace",
    ]
except ImportError:
    # openai-agents not installed, skip tracing processor export
    __all__ = [
        "AllowedEnvVars",
        "Bitfab",
        "BitfabFunction",
        "CurrentSpan",
        "CurrentTrace",
        "ReplayItem",
        "ReplayResult",
        "SpanType",
        "flush_traces",
        "get_current_span",
        "get_current_trace",
    ]
