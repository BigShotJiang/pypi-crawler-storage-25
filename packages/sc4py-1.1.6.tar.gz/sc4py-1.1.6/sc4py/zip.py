"""
The MIT License (MIT)

Copyright (c) 2015 kelsoncm

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
"""

from csv import DictReader
from io import BytesIO, StringIO
from zipfile import ZipFile


class FileNotFoundInZipError(FileNotFoundError):
    pass


def unzip_content(content: bytes, file_id: int | str = 0, encoding: str = "utf-8") -> str | bytes:
    with ZipFile(BytesIO(content)) as zip_file:
        try:
            filename = file_id if isinstance(file_id, str) else zip_file.filelist[int(file_id)].filename
        except IndexError:
            raise FileNotFoundInZipError("Não existe arquivo no índice %d")
        try:
            with zip_file.open(filename) as zipped_file:
                binary_file_content = zipped_file.read()
            return binary_file_content if encoding is None else binary_file_content.decode(encoding)
        except KeyError:
            raise FileNotFoundInZipError("Não existe arquivo com o nome %s" % filename)


def unzip_csv_content(content: bytes, file_id: int | str = 0, encoding: str = "utf-8", **kwargs) -> list[dict]:
    file_content = unzip_content(content, file_id, encoding)
    if not isinstance(file_content, str):
        file_content = file_content.decode(encoding) if isinstance(file_content, bytes) else str(file_content)
    csv_stream_content = StringIO(file_content)
    return [dict(row) for row in DictReader(csv_stream_content, **kwargs)]
