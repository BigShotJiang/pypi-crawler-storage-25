# REAPER Check Library Inventory

| check_id | name | category | wedge | tier | frameworks | severity | ASI | status |
|----------|------|----------|-------|------|------------|----------|-----|--------|
| RPR-CONF-001 | MCP Server Missing Authentication | config | 1 | community | openclaw, mcp_generic | high | ASI04 | active |
