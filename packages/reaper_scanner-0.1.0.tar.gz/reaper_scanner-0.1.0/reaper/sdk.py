"""
REAPER SDK — Base classes and data types for detection checks.

Implements RFC-RPR-001 Check Contract v1.0.
Check authors import from this module only.
"""

from __future__ import annotations

import logging
from dataclasses import dataclass, field

logger = logging.getLogger("reaper")

# ---------------------------------------------------------------------------
# Taxonomy (Contract §4)
# ---------------------------------------------------------------------------

TAXONOMY_FRAMEWORKS = {"owasp_asi", "mitre_atlas", "cwe", "owasp_llm", "mcp_advisory"}


@dataclass
class TaxonomyEntry:
    framework: str
    entry_id: str
    justification: str

    def __post_init__(self) -> None:
        if self.framework not in TAXONOMY_FRAMEWORKS:
            raise ValueError(
                f"Unknown taxonomy framework '{self.framework}'. "
                f"Must be one of: {', '.join(sorted(TAXONOMY_FRAMEWORKS))}"
            )
        if not self.justification:
            raise ValueError("Taxonomy justification must not be empty.")


@dataclass
class TaxonomyMapping:
    primary: TaxonomyEntry
    secondary: list[TaxonomyEntry] = field(default_factory=list)

    def __post_init__(self) -> None:
        if self.primary.framework != "owasp_asi":
            raise ValueError("Primary taxonomy mapping must use 'owasp_asi'.")


# ---------------------------------------------------------------------------
# Severity (Contract §5)
# ---------------------------------------------------------------------------

SEVERITY_LEVELS = ("critical", "high", "medium", "low", "info")
AARF_VALUES = {0.0, 0.5, 1.0}


@dataclass
class AARFAssessment:
    autonomy: float
    tools: float
    language: float
    context: float
    non_determinism: float
    opacity: float
    persistence: float
    identity: float
    multi_agent: float
    self_modification: float

    def __post_init__(self) -> None:
        for name in (
            "autonomy", "tools", "language", "context", "non_determinism",
            "opacity", "persistence", "identity", "multi_agent", "self_modification",
        ):
            val = getattr(self, name)
            if val not in AARF_VALUES:
                raise ValueError(f"AARF factor '{name}' must be 0.0, 0.5, or 1.0, got {val}")


@dataclass
class SeverityRating:
    default: str
    cvss_base: float | None = None
    aarf: AARFAssessment | None = None

    def __post_init__(self) -> None:
        if self.default not in SEVERITY_LEVELS:
            raise ValueError(f"Severity must be one of {SEVERITY_LEVELS}, got '{self.default}'")
        if self.default != "info" and self.cvss_base is None:
            raise ValueError(f"CVSS base score is required for severity '{self.default}'.")


# ---------------------------------------------------------------------------
# Target Data (Contract §6.1)
# ---------------------------------------------------------------------------

@dataclass
class TargetConfig:
    framework: str
    config: dict
    tools: list[dict]
    mcp_servers: list[dict]
    system_prompt: str | None
    files: dict[str, str]
    metadata: dict


# ---------------------------------------------------------------------------
# Finding Output (Contract §6.3–6.5)
# ---------------------------------------------------------------------------

CONFIDENCE_LEVELS = ("high", "medium", "low")
EFFORT_LEVELS = ("trivial", "low", "medium", "high")


@dataclass
class Evidence:
    observable: str
    file_path: str | None
    line: int | None
    line_end: int | None
    raw_value: str
    context: dict[str, str] = field(default_factory=dict)


@dataclass
class Remediation:
    description: str
    steps: dict[str, str]
    references: list[str]
    effort: str

    def __post_init__(self) -> None:
        if self.effort not in EFFORT_LEVELS:
            raise ValueError(f"Effort must be one of {EFFORT_LEVELS}, got '{self.effort}'")


@dataclass
class Finding:
    check_id: str
    severity: str
    confidence: str
    evidence: Evidence
    remediation: Remediation
    taxonomy: TaxonomyMapping

    def __post_init__(self) -> None:
        if self.severity not in SEVERITY_LEVELS:
            raise ValueError(f"Severity must be one of {SEVERITY_LEVELS}, got '{self.severity}'")
        if self.confidence not in CONFIDENCE_LEVELS:
            raise ValueError(
                f"Confidence must be one of {CONFIDENCE_LEVELS}, got '{self.confidence}'"
            )


# ---------------------------------------------------------------------------
# Test Fixtures (Contract §7)
# ---------------------------------------------------------------------------

FIXTURE_EXPECTATIONS = ("vulnerable", "safe", "borderline")


@dataclass
class TestFixture:
    fixture_id: str
    description: str
    expected: str
    target: TargetConfig

    def __post_init__(self) -> None:
        if self.expected not in FIXTURE_EXPECTATIONS:
            raise ValueError(
                f"Expected must be one of {FIXTURE_EXPECTATIONS}, got '{self.expected}'"
            )


# ---------------------------------------------------------------------------
# Base Check Class (Contract §8, §13)
# ---------------------------------------------------------------------------

# Valid values for check metadata
CATEGORIES = ("config", "infra", "runtime")
WEDGES = (1, 2, 3)
TIERS = ("community", "pro")
CHECK_TYPES = ("deterministic", "heuristic")
CANONICAL_FRAMEWORKS = (
    "openclaw", "claude_code", "langchain", "crewai",
    "autogen", "mcp_generic", "hermes",
)


class ReaperCheck:
    """Base class for all REAPER detection checks."""

    # --- Identity (must be overridden) ---
    check_id: str = ""
    name: str = ""
    description: str = ""
    contract_version: str = "1.0"

    # --- Classification ---
    category: str = "config"
    wedge: int = 1
    tier: str = "community"
    frameworks: list[str] = []
    check_type: str = "deterministic"

    # --- Taxonomy ---
    taxonomy: TaxonomyMapping | None = None

    # --- Severity ---
    severity: SeverityRating | None = None

    def detect(self, target: TargetConfig) -> Finding | None:
        """Execute detection logic against target. Subclasses must override."""
        raise NotImplementedError

    def log(self, level: str, message: str) -> None:
        """Emit a diagnostic message captured by the engine."""
        allowed = ("debug", "info", "warning", "error")
        if level not in allowed:
            level = "info"
        getattr(logger, level)(f"[{self.check_id}] {message}")

    def validate_metadata(self) -> list[str]:
        """Return a list of contract violations found in this check's metadata."""
        errors: list[str] = []
        if not self.check_id:
            errors.append("check_id is required")
        if not self.name:
            errors.append("name is required")
        if len(self.name) > 80:
            errors.append(f"name exceeds 80 chars ({len(self.name)})")
        if not self.description:
            errors.append("description is required")
        if self.category not in CATEGORIES:
            errors.append(f"category '{self.category}' not in {CATEGORIES}")
        if self.wedge not in WEDGES:
            errors.append(f"wedge {self.wedge} not in {WEDGES}")
        if self.tier not in TIERS:
            errors.append(f"tier '{self.tier}' not in {TIERS}")
        if self.check_type not in CHECK_TYPES:
            errors.append(f"check_type '{self.check_type}' not in {CHECK_TYPES}")
        if not self.frameworks:
            errors.append("frameworks list is empty")
        else:
            for fw in self.frameworks:
                if fw != "universal" and fw not in CANONICAL_FRAMEWORKS:
                    errors.append(f"unknown framework '{fw}'")
        if self.taxonomy is None:
            errors.append("taxonomy mapping is required")
        if self.severity is None:
            errors.append("severity rating is required")
        return errors
