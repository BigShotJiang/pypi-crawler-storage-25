# SAMBA_ilum Copyright (C) 2025-2026
# GNU GPL-3.0 license


import shutil
import os


#---------------------------
poscar = open('POSCAR', 'r')
#--------------------------------
VTemp = poscar.readline().split()
label_materials = VTemp[1].replace('+', ' ').split()
n_Lattice = len(label_materials);  nion = 0
range_ion_Lattice = []; ntype_ions = ['']*n_Lattice
#--------------------------------------------------
for m in range(n_Lattice):
    range_ion_Lattice.append( str(1 + nion) + ' ')
    nion += int(VTemp[m+2])
    range_ion_Lattice[m] += str(nion)
#----------------------------------------------------
for m in range(6):  VTemp = poscar.readline().split()
#----------------------------------------------------
poscar.close()
#-------------
for m in range(n_Lattice):
    contador = 0
    for n in range(len(VTemp)):
        contador += int(VTemp[n])
        range_ion = range_ion_Lattice[m].split()
        ion_i = int(range_ion[0]);  ion_f = int(range_ion[1])
        if (contador >= ion_i and contador <= ion_f):
           ntype_ions[m] += str(VTemp[n]) + ' '

#================================================================================

shutil.copyfile('POSCAR', 'HeteroStructure' + '/POSCAR')

if os.path.exists('magmom.txt'):
   shutil.copyfile('magmom.txt', 'HeteroStructure/magmom.txt')
   mag = open('magmom.txt', 'r')
   MTemp = mag.readline().replace("="," = ").split()
   mag.close()
   fator = (len(MTemp) -2)/nion; fator = int(fator)

for m in range(n_Lattice):

    #---------------------------
    poscar = open('POSCAR', 'r')
    poscar_new = open('material_' + str(m+1) + '/POSCAR', 'w')
    #---------------------------------------------------------
    VTemp = poscar.readline()
    poscar_new.write(f'POSCAR \n')
    #-----------------------------
    for n in range(4):
        VTemp = poscar.readline()
        poscar_new.write(f'{VTemp}')
    #-------------------------------
    VTemp = poscar.readline()
    temp = label_materials[m].replace('_', ' ')
    poscar_new.write(f'{temp} \n')
    #-----------------------------
    VTemp = poscar.readline()
    poscar_new.write(f'{ntype_ions[m]} \n')
    #--------------------------------------
    VTemp = poscar.readline()
    if (VTemp[0] == 'S' or VTemp[0] == 's'):
       poscar_new.write(f'Selective dynamics \n')
       VTemp = poscar.readline()
    if (VTemp[0] == 'c' or VTemp[0] == 'C'): poscar_new.write(f'Cartesian \n')
    if (VTemp[0] == 'd' or VTemp[0] == 'D'): poscar_new.write(f'Direct \n')
    #---------------------------------------
    range_ion = range_ion_Lattice[m].split()
    ion_i = int(range_ion[0]);  ion_f = int(range_ion[1])
    #----------------------------------------------------
    for n in range(1,(nion+1)):
        VTemp = poscar.readline()
        if (n >= ion_i and n <= ion_f):  poscar_new.write(f'{VTemp}')
    #----------------------------------------------------------------
    poscar.close()
    poscar_new.close()
    #-----------------

    if os.path.exists('magmom.txt'):
       #--------------------------------------------------------------------------------------
       mag = open('magmom.txt', 'r');  MTemp = mag.readline().split();  VTemp = mag.readline()
       mag_new = open('material_' + str(m+1) + '/magmom.txt', 'w');  cont_mag = 0
       #-------------------------------------------------------------------------
       mag_new.write(f'MAGMOM = ')
       #--------------------------
       if (fator == 1):
          for n in range(1,(nion+1)):
              if (n >= ion_i and n <= ion_f): mag_new.write(f'{MTemp[n +1]} ')
       #---------------
       if (fator == 3):
          for n in range(1,((nion*3)+1)):
              if ( n >= ((ion_i*3) -2) and n <= (ion_f*3) ): mag_new.write(f'{MTemp[n +1]} ')
       #-------------------
       mag_new.write(f'\n')
       mag_new.write(f'------------------------ \n')
       #-------------------
       for n in range(1,(nion+1)):
           MTemp = mag.readline().split()
           #-----------------------------
           if (n >= ion_i and n <= ion_f):
              cont_mag += 1
              if (len(MTemp) == 2):
                 if (cont_mag < 10):                       mag_new.write(f'{cont_mag}   {float(MTemp[-1]):8.4f} \n')
                 if (cont_mag >= 10 and cont_mag < 100):   mag_new.write(f'{cont_mag}  {float(MTemp[-1]):8.4f} \n')
                 if (cont_mag >= 100 and cont_mag < 1000): mag_new.write(f'{cont_mag} {float(MTemp[-1]):8.4f} \n')
              if (len(MTemp) == 4):
                 if (cont_mag < 10):                       mag_new.write(f'{cont_mag}   {float(MTemp[-3]):8.4f} {float(MTemp[-2]):8.4f} {float(MTemp[-1]):8.4f} \n')
                 if (cont_mag >= 10 and cont_mag < 100):   mag_new.write(f'{cont_mag}  {float(MTemp[-3]):8.4f} {float(MTemp[-2]):8.4f} {float(MTemp[-1]):8.4f} \n')
                 if (cont_mag >= 100 and cont_mag < 1000): mag_new.write(f'{cont_mag} {float(MTemp[-3]):8.4f} {float(MTemp[-2]):8.4f} {float(MTemp[-1]):8.4f} \n')
       #----------
       mag.close()
       mag_new.close()
       #--------------