# SAMBA_ilum Copyright (C) 2025-2026
# GNU GPL-3.0 license


import os


try:
   #----------------------------------------------
   cut_off_energy = open('cut_off_energy.py', "w")
   #----------------------------------------------
   files = os.listdir()
   #-------------------
   for i in range(len(files)):
       #---------------------------
       potcar = open(files[i], "r")
       X = files[i].replace('POTCAR_', '')
       #------------------------------------------------------------
       if ((X != '_info_pseudo.py') and (X != 'cut_off_energy.py')):
          test = '@#$%¨&*()'
          while (test != 'ENMAX'):
                VTemp = potcar.readline().split()
                if (len(VTemp) > 0):  test = str(VTemp[0])
          #-----------------------------------------------
          ENMAX = float(VTemp[2].replace(';', ''))
          cut_off_energy.write(f'ENCUT_{X} = {ENMAX} \n')
       #-------------------------------------------------
       potcar.close()
   #---------------------
   cut_off_energy.close()
   #---------------------

except Exception as e:
   #----------------------------------------------------------------
   cut_off_energy = open('cut_off_energy.py', "w", encoding="utf-8")
   #----------------------------------------------------------------
   files = os.listdir()
   #-------------------
   for i in range(len(files)):
       #-------------------------------------
       if not files[i].startswith("POTCAR_"):
          continue
       #-----------------------------------------------------------------
       potcar = open(files[i], "r", encoding="latin-1", errors="replace")
       X = files[i].replace('POTCAR_', '')
       #----------------------------------
       test = '@#$%¨&*()'
       while test != 'ENMAX':
           line = potcar.readline()
           if line == "":
               break
           VTemp = line.split()
           if len(VTemp) > 0:
               test = str(VTemp[0])
       #---------------------------
       if test == 'ENMAX':
           ENMAX = float(VTemp[2].replace(';', ''))
           cut_off_energy.write(f'ENCUT_{X} = {ENMAX} \n')
       else:
           print(f"Warning: ENMAX not found in {files[i]}")
       #---------------------------------------------------
       potcar.close()
   #---------------------
   cut_off_energy.close()
   #---------------------
