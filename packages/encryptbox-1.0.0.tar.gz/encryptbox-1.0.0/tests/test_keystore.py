"""Tests for keystore management."""

import json

import pytest

from encryptbox.keystore import KeyMeta, Keystore, StoreConfig


@pytest.fixture
def store(tmp_path):
    ks = Keystore(tmp_path)
    ks.init()
    return ks


@pytest.fixture
def uninit_store(tmp_path):
    return Keystore(tmp_path)


class TestInit:
    def test_creates_directory(self, store):
        assert store.store_dir.exists()
        assert store.keys_dir.exists()

    def test_creates_config(self, store):
        config_path = store.store_dir / "config.json"
        assert config_path.exists()

    def test_double_init_raises(self, store):
        with pytest.raises(FileExistsError):
            store.init()

    def test_is_initialized(self, store):
        assert store.is_initialized is True

    def test_not_initialized(self, uninit_store):
        assert uninit_store.is_initialized is False


class TestKeyGeneration:
    def test_generate_returns_key_id(self, store):
        key_id, pub = store.generate_key()
        assert isinstance(key_id, str)
        assert len(key_id) == 16

    def test_first_key_becomes_default(self, store):
        key_id, _ = store.generate_key()
        assert store.get_default_key_id() == key_id

    def test_second_key_not_default(self, store):
        kid1, _ = store.generate_key()
        kid2, _ = store.generate_key()
        assert store.get_default_key_id() == kid1

    def test_generate_with_label(self, store):
        key_id, _ = store.generate_key(label="test-key")
        meta = store.get_key_meta(key_id)
        assert meta.label == "test-key"

    def test_key_files_created(self, store):
        key_id, _ = store.generate_key()
        key_dir = store.keys_dir / key_id
        assert (key_dir / "private.key").exists()
        assert (key_dir / "public.key").exists()
        assert (key_dir / "meta.json").exists()

    def test_generate_without_init_raises(self, uninit_store):
        with pytest.raises(FileNotFoundError):
            uninit_store.generate_key()


class TestKeyRetrieval:
    def test_get_private_key(self, store):
        key_id, _ = store.generate_key()
        priv = store.get_private_key(key_id)
        assert priv is not None

    def test_get_public_key(self, store):
        key_id, pub = store.generate_key()
        loaded = store.get_public_key(key_id)
        assert loaded.public_bytes_raw() == pub.public_bytes_raw()

    def test_missing_private_key_raises(self, store):
        with pytest.raises(FileNotFoundError):
            store.get_private_key("nonexistent")

    def test_missing_public_key_raises(self, store):
        with pytest.raises(FileNotFoundError):
            store.get_public_key("nonexistent")

    def test_round_trip_key(self, store):
        key_id, pub = store.generate_key()
        priv = store.get_private_key(key_id)
        derived_pub = priv.public_key()
        assert derived_pub.public_bytes_raw() == pub.public_bytes_raw()


class TestKeyMeta:
    def test_get_meta(self, store):
        key_id, _ = store.generate_key()
        meta = store.get_key_meta(key_id)
        assert meta.key_id == key_id
        assert meta.is_active is True

    def test_missing_meta_raises(self, store):
        with pytest.raises(FileNotFoundError):
            store.get_key_meta("nonexistent")

    def test_meta_to_dict(self):
        meta = KeyMeta(key_id="abc", created_at=1.0)
        d = meta.to_dict()
        assert d["key_id"] == "abc"
        assert d["is_active"] is True

    def test_meta_from_dict(self):
        d = {"key_id": "abc", "created_at": 1.0, "is_active": True, "rotated_at": None, "label": ""}
        meta = KeyMeta.from_dict(d)
        assert meta.key_id == "abc"

    def test_meta_ignores_extra_fields(self):
        d = {"key_id": "abc", "created_at": 1.0, "is_active": True, "rotated_at": None, "label": "", "extra": True}
        meta = KeyMeta.from_dict(d)
        assert meta.key_id == "abc"


class TestListKeys:
    def test_empty(self, store):
        assert store.list_keys() == []

    def test_lists_generated_keys(self, store):
        store.generate_key()
        store.generate_key()
        keys = store.list_keys()
        assert len(keys) == 2

    def test_list_returns_meta(self, store):
        kid, _ = store.generate_key(label="my-key")
        keys = store.list_keys()
        assert keys[0].key_id == kid
        assert keys[0].label == "my-key"


class TestDeactivateKey:
    def test_deactivate(self, store):
        kid, _ = store.generate_key()
        store.deactivate_key(kid)
        meta = store.get_key_meta(kid)
        assert meta.is_active is False
        assert meta.rotated_at is not None


class TestSetDefaultKey:
    def test_set_default(self, store):
        kid1, _ = store.generate_key()
        kid2, _ = store.generate_key()
        store.set_default_key(kid2)
        assert store.get_default_key_id() == kid2

    def test_set_nonexistent_raises(self, store):
        with pytest.raises(FileNotFoundError):
            store.set_default_key("nonexistent")

    def test_no_default_raises(self, store):
        with pytest.raises(ValueError):
            store.get_default_key_id()


class TestImportExportKey:
    def test_import_public_key(self, store):
        kid, pub = store.generate_key()
        raw = pub.public_bytes_raw()
        store.import_public_key("imported-1", raw)
        loaded = store.get_public_key("imported-1")
        assert loaded.public_bytes_raw() == raw

    def test_export_public_key(self, store):
        kid, pub = store.generate_key()
        raw = store.export_public_key(kid)
        assert raw == pub.public_bytes_raw()

    def test_import_without_init_raises(self, uninit_store):
        with pytest.raises(FileNotFoundError):
            uninit_store.import_public_key("test", b"x" * 32)


class TestStoreConfig:
    def test_to_dict(self):
        config = StoreConfig(version=1, default_key_id="abc")
        d = config.to_dict()
        assert d["version"] == 1
        assert d["default_key_id"] == "abc"

    def test_from_dict(self):
        d = {"version": 1, "default_key_id": "abc", "created_at": 1.0}
        config = StoreConfig.from_dict(d)
        assert config.version == 1
        assert config.default_key_id == "abc"
