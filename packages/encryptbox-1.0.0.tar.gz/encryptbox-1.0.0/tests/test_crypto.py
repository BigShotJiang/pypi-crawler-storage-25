"""Tests for core cryptographic operations."""

import os

import pytest
from cryptography.hazmat.primitives.asymmetric.x25519 import X25519PrivateKey

from encryptbox.crypto import (
    AES_KEY_SIZE,
    NONCE_SIZE,
    EncryptedBlob,
    WrappedKey,
    decrypt_data,
    encrypt_data,
    generate_data_key,
    generate_keypair,
    unwrap_key,
    wrap_key,
)


class TestGenerateDataKey:
    def test_returns_correct_length(self):
        key = generate_data_key()
        assert len(key) == AES_KEY_SIZE

    def test_keys_are_unique(self):
        keys = {generate_data_key() for _ in range(100)}
        assert len(keys) == 100

    def test_key_is_bytes(self):
        key = generate_data_key()
        assert isinstance(key, bytes)


class TestEncryptDecrypt:
    def test_round_trip(self):
        key = generate_data_key()
        plaintext = b"Hello, World!"
        blob = encrypt_data(key, plaintext)
        result = decrypt_data(key, blob)
        assert result == plaintext

    def test_empty_plaintext(self):
        key = generate_data_key()
        blob = encrypt_data(key, b"")
        result = decrypt_data(key, blob)
        assert result == b""

    def test_large_plaintext(self):
        key = generate_data_key()
        plaintext = os.urandom(10 * 1024 * 1024)  # 10MB
        blob = encrypt_data(key, plaintext)
        result = decrypt_data(key, blob)
        assert result == plaintext

    def test_binary_data(self):
        key = generate_data_key()
        plaintext = bytes(range(256)) * 10
        blob = encrypt_data(key, plaintext)
        result = decrypt_data(key, blob)
        assert result == plaintext

    def test_with_aad(self):
        key = generate_data_key()
        plaintext = b"secret data"
        aad = b"metadata"
        blob = encrypt_data(key, plaintext, aad=aad)
        result = decrypt_data(key, blob, aad=aad)
        assert result == plaintext

    def test_wrong_aad_fails(self):
        key = generate_data_key()
        plaintext = b"secret data"
        blob = encrypt_data(key, plaintext, aad=b"correct")
        with pytest.raises(Exception):
            decrypt_data(key, blob, aad=b"wrong")

    def test_wrong_key_fails(self):
        key1 = generate_data_key()
        key2 = generate_data_key()
        blob = encrypt_data(key1, b"data")
        with pytest.raises(Exception):
            decrypt_data(key2, blob)

    def test_invalid_key_size(self):
        with pytest.raises(ValueError, match="Key must be"):
            encrypt_data(b"short", b"data")

    def test_invalid_key_size_decrypt(self):
        key = generate_data_key()
        blob = encrypt_data(key, b"data")
        with pytest.raises(ValueError, match="Key must be"):
            decrypt_data(b"short", blob)

    def test_nonce_uniqueness(self):
        key = generate_data_key()
        blobs = [encrypt_data(key, b"same data") for _ in range(100)]
        nonces = {b.nonce for b in blobs}
        assert len(nonces) == 100

    def test_ciphertext_different_from_plaintext(self):
        key = generate_data_key()
        plaintext = b"A" * 100
        blob = encrypt_data(key, plaintext)
        assert blob.ciphertext != plaintext

    def test_tampered_ciphertext_fails(self):
        key = generate_data_key()
        blob = encrypt_data(key, b"data")
        tampered = EncryptedBlob(nonce=blob.nonce, ciphertext=blob.ciphertext[:-1] + bytes([blob.ciphertext[-1] ^ 0xFF]))
        with pytest.raises(Exception):
            decrypt_data(key, tampered)


class TestEncryptedBlobSerialization:
    def test_round_trip(self):
        key = generate_data_key()
        blob = encrypt_data(key, b"test")
        serialized = blob.serialize()
        restored = EncryptedBlob.deserialize(serialized)
        assert restored.nonce == blob.nonce
        assert restored.ciphertext == blob.ciphertext

    def test_too_short_data_raises(self):
        with pytest.raises(ValueError, match="too short"):
            EncryptedBlob.deserialize(b"short")

    def test_nonce_length_in_serialized(self):
        key = generate_data_key()
        blob = encrypt_data(key, b"test")
        serialized = blob.serialize()
        assert serialized[:NONCE_SIZE] == blob.nonce


class TestKeyWrapping:
    def test_wrap_unwrap_round_trip(self):
        private, public = generate_keypair()
        data_key = generate_data_key()
        wrapped = wrap_key(public, data_key)
        unwrapped = unwrap_key(private, wrapped)
        assert unwrapped == data_key

    def test_wrong_private_key_fails(self):
        _, public = generate_keypair()
        wrong_private = X25519PrivateKey.generate()
        data_key = generate_data_key()
        wrapped = wrap_key(public, data_key)
        with pytest.raises(Exception):
            unwrap_key(wrong_private, wrapped)

    def test_ephemeral_key_is_32_bytes(self):
        _, public = generate_keypair()
        data_key = generate_data_key()
        wrapped = wrap_key(public, data_key)
        assert len(wrapped.ephemeral_public) == 32

    def test_different_wrappings_are_unique(self):
        _, public = generate_keypair()
        data_key = generate_data_key()
        wraps = [wrap_key(public, data_key) for _ in range(10)]
        ephemerals = {w.ephemeral_public for w in wraps}
        assert len(ephemerals) == 10

    def test_multiple_recipients(self):
        priv1, pub1 = generate_keypair()
        priv2, pub2 = generate_keypair()
        data_key = generate_data_key()

        w1 = wrap_key(pub1, data_key)
        w2 = wrap_key(pub2, data_key)

        assert unwrap_key(priv1, w1) == data_key
        assert unwrap_key(priv2, w2) == data_key


class TestWrappedKeySerialization:
    def test_serialize(self):
        _, public = generate_keypair()
        data_key = generate_data_key()
        wrapped = wrap_key(public, data_key)
        serialized = wrapped.serialize()
        assert isinstance(serialized, bytes)
        assert len(serialized) > 0


class TestGenerateKeypair:
    def test_returns_pair(self):
        private, public = generate_keypair()
        assert private is not None
        assert public is not None

    def test_keys_are_unique(self):
        pairs = [generate_keypair() for _ in range(10)]
        pubs = {p[1].public_bytes_raw() for p in pairs}
        assert len(pubs) == 10

    def test_key_exchange_works(self):
        priv1, pub1 = generate_keypair()
        priv2, pub2 = generate_keypair()
        s1 = priv1.exchange(pub2)
        s2 = priv2.exchange(pub1)
        assert s1 == s2
