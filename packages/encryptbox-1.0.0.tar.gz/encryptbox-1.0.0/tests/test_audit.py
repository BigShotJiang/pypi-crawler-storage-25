"""Tests for audit log."""

import json

import pytest

from encryptbox.audit import CHAIN_SEED, AuditEntry, AuditLog


@pytest.fixture
def audit(tmp_path):
    return AuditLog(tmp_path)


class TestAuditLog:
    def test_log_entry(self, audit):
        entry = audit.log(action="test", key_id="k1", file_path="/test.txt")
        assert entry.action == "test"
        assert entry.key_id == "k1"

    def test_entry_has_hmac(self, audit):
        entry = audit.log(action="test")
        assert entry.entry_hmac
        assert entry.prev_hmac

    def test_read_all(self, audit):
        audit.log(action="a1")
        audit.log(action="a2")
        entries = audit.read_all()
        assert len(entries) == 2
        assert entries[0].action == "a1"
        assert entries[1].action == "a2"

    def test_empty_log(self, audit):
        assert audit.read_all() == []

    def test_entry_count(self, audit):
        assert audit.entry_count() == 0
        audit.log(action="a1")
        audit.log(action="a2")
        assert audit.entry_count() == 2

    def test_log_with_details(self, audit):
        entry = audit.log(action="test", details={"foo": "bar"})
        assert entry.details == {"foo": "bar"}

    def test_log_with_user(self, audit):
        entry = audit.log(action="test", user="alice")
        assert entry.user == "alice"

    def test_log_with_file_hash(self, audit):
        entry = audit.log(action="test", file_hash="abc123")
        assert entry.file_hash == "abc123"

    def test_timestamp_exists(self, audit):
        entry = audit.log(action="test")
        assert entry.timestamp > 0


class TestChainVerification:
    def test_empty_log_valid(self, audit):
        valid, msg = audit.verify_chain()
        assert valid is True

    def test_single_entry_valid(self, audit):
        audit.log(action="test")
        valid, msg = audit.verify_chain()
        assert valid is True

    def test_multiple_entries_valid(self, audit):
        for i in range(10):
            audit.log(action=f"action-{i}")
        valid, msg = audit.verify_chain()
        assert valid is True
        assert "10 entries verified" in msg

    def test_chain_links(self, audit):
        e1 = audit.log(action="first")
        e2 = audit.log(action="second")
        assert e2.prev_hmac == e1.entry_hmac

    def test_tampered_entry_detected(self, audit):
        audit.log(action="legit")
        audit.log(action="also-legit")

        # Tamper: modify the first entry's action
        lines = audit.log_path.read_text().strip().split("\n")
        entry = json.loads(lines[0])
        entry["action"] = "tampered"
        lines[0] = json.dumps(entry)
        audit.log_path.write_text("\n".join(lines) + "\n")

        valid, msg = audit.verify_chain()
        assert valid is False
        assert "HMAC mismatch" in msg

    def test_deleted_entry_detected(self, audit):
        audit.log(action="first")
        audit.log(action="second")
        audit.log(action="third")

        # Delete the middle entry
        lines = audit.log_path.read_text().strip().split("\n")
        lines.pop(1)
        audit.log_path.write_text("\n".join(lines) + "\n")

        valid, msg = audit.verify_chain()
        assert valid is False

    def test_modified_hmac_detected(self, audit):
        audit.log(action="test")

        lines = audit.log_path.read_text().strip().split("\n")
        entry = json.loads(lines[0])
        entry["entry_hmac"] = "0" * 64
        lines[0] = json.dumps(entry)
        audit.log_path.write_text("\n".join(lines) + "\n")

        valid, msg = audit.verify_chain()
        assert valid is False

    def test_inserted_entry_detected(self, audit):
        e1 = audit.log(action="first")
        e3 = audit.log(action="third")

        # Insert a fake entry between
        lines = audit.log_path.read_text().strip().split("\n")
        fake = {
            "timestamp": 999.0,
            "action": "fake",
            "key_id": "",
            "file_path": "",
            "file_hash": "",
            "user": "",
            "details": {},
            "prev_hmac": e1.entry_hmac,
            "entry_hmac": "fake_hmac",
        }
        lines.insert(1, json.dumps(fake))
        audit.log_path.write_text("\n".join(lines) + "\n")

        valid, msg = audit.verify_chain()
        assert valid is False


class TestAuditSecret:
    def test_secret_created(self, audit):
        audit.log(action="test")
        assert audit.secret_path.exists()

    def test_secret_is_32_bytes(self, audit):
        _ = audit.secret
        raw = audit.secret_path.read_bytes()
        assert len(raw) == 32

    def test_secret_persists(self, tmp_path):
        a1 = AuditLog(tmp_path)
        a1.log(action="test")
        s1 = a1.secret

        a2 = AuditLog(tmp_path)
        s2 = a2.secret
        assert s1 == s2


class TestAuditEntryDataclass:
    def test_to_dict(self):
        e = AuditEntry(
            timestamp=1.0, action="test", key_id="k1",
            file_path="/f", file_hash="h", user="u",
            details={}, prev_hmac="p", entry_hmac="e"
        )
        d = e.to_dict()
        assert d["action"] == "test"

    def test_from_dict(self):
        d = {
            "timestamp": 1.0, "action": "test", "key_id": "k1",
            "file_path": "/f", "file_hash": "h", "user": "u",
            "details": {}, "prev_hmac": "p", "entry_hmac": "e"
        }
        e = AuditEntry.from_dict(d)
        assert e.action == "test"
