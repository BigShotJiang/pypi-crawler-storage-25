"""Tests for envelope encryption."""

import os

import pytest
from cryptography.hazmat.primitives.asymmetric.x25519 import X25519PrivateKey

from encryptbox.crypto import generate_data_key, generate_keypair
from encryptbox.envelope import (
    EBOX_EXT,
    EncryptedFile,
    decrypt_file_envelope,
    encrypt_file_envelope,
    rewrap_for_new_key,
)


@pytest.fixture
def keypair():
    return generate_keypair()


@pytest.fixture
def two_keypairs():
    return generate_keypair(), generate_keypair()


class TestEnvelopeEncryptDecrypt:
    def test_round_trip(self, keypair):
        priv, pub = keypair
        plaintext = b"Hello, envelope encryption!"
        encrypted = encrypt_file_envelope(plaintext, [("key1", pub)])
        result = decrypt_file_envelope(encrypted, "key1", priv)
        assert result == plaintext

    def test_empty_data(self, keypair):
        priv, pub = keypair
        encrypted = encrypt_file_envelope(b"", [("key1", pub)])
        result = decrypt_file_envelope(encrypted, "key1", priv)
        assert result == b""

    def test_large_data(self, keypair):
        priv, pub = keypair
        plaintext = os.urandom(5 * 1024 * 1024)  # 5MB
        encrypted = encrypt_file_envelope(plaintext, [("key1", pub)])
        result = decrypt_file_envelope(encrypted, "key1", priv)
        assert result == plaintext

    def test_binary_data(self, keypair):
        priv, pub = keypair
        plaintext = bytes(range(256))
        encrypted = encrypt_file_envelope(plaintext, [("key1", pub)])
        result = decrypt_file_envelope(encrypted, "key1", priv)
        assert result == plaintext

    def test_no_recipients_raises(self):
        with pytest.raises(ValueError, match="At least one recipient"):
            encrypt_file_envelope(b"data", [])

    def test_wrong_key_id_raises(self, keypair):
        priv, pub = keypair
        encrypted = encrypt_file_envelope(b"data", [("key1", pub)])
        with pytest.raises(ValueError, match="No wrapped key found"):
            decrypt_file_envelope(encrypted, "wrong-key", priv)

    def test_wrong_private_key_raises(self, keypair):
        _, pub = keypair
        wrong_priv = X25519PrivateKey.generate()
        encrypted = encrypt_file_envelope(b"data", [("key1", pub)])
        with pytest.raises(Exception):
            decrypt_file_envelope(encrypted, "key1", wrong_priv)

    def test_original_hash_stored(self, keypair):
        _, pub = keypair
        plaintext = b"hash me"
        encrypted = encrypt_file_envelope(plaintext, [("key1", pub)])
        import hashlib
        expected = hashlib.sha256(plaintext).digest()
        assert encrypted.original_hash == expected


class TestMultiRecipient:
    def test_two_recipients(self, two_keypairs):
        (priv1, pub1), (priv2, pub2) = two_keypairs
        plaintext = b"shared secret"
        encrypted = encrypt_file_envelope(plaintext, [("key1", pub1), ("key2", pub2)])

        r1 = decrypt_file_envelope(encrypted, "key1", priv1)
        r2 = decrypt_file_envelope(encrypted, "key2", priv2)
        assert r1 == plaintext
        assert r2 == plaintext

    def test_three_recipients(self):
        pairs = [generate_keypair() for _ in range(3)]
        plaintext = b"group secret"
        recipients = [(f"key{i}", pub) for i, (_, pub) in enumerate(pairs)]
        encrypted = encrypt_file_envelope(plaintext, recipients)

        for i, (priv, _) in enumerate(pairs):
            result = decrypt_file_envelope(encrypted, f"key{i}", priv)
            assert result == plaintext


class TestSerialization:
    def test_round_trip(self, keypair):
        priv, pub = keypair
        plaintext = b"serialize me"
        encrypted = encrypt_file_envelope(plaintext, [("key1", pub)])

        serialized = encrypted.serialize()
        restored = EncryptedFile.deserialize(serialized)

        result = decrypt_file_envelope(restored, "key1", priv)
        assert result == plaintext

    def test_invalid_magic_raises(self):
        data = b"BAAD" + b"\x01" + b"\x00\x00"
        with pytest.raises(ValueError, match="Invalid magic"):
            EncryptedFile.deserialize(data)

    def test_invalid_version_raises(self):
        data = b"EBOX" + b"\xFF" + b"\x00\x00"
        with pytest.raises(ValueError, match="Unsupported version"):
            EncryptedFile.deserialize(data)

    def test_serialized_starts_with_magic(self, keypair):
        _, pub = keypair
        encrypted = encrypt_file_envelope(b"data", [("key1", pub)])
        serialized = encrypted.serialize()
        assert serialized[:4] == b"EBOX"

    def test_multi_recipient_serialization(self, two_keypairs):
        (priv1, pub1), (priv2, pub2) = two_keypairs
        plaintext = b"multi-recipient"
        encrypted = encrypt_file_envelope(plaintext, [("key1", pub1), ("key2", pub2)])

        serialized = encrypted.serialize()
        restored = EncryptedFile.deserialize(serialized)

        assert decrypt_file_envelope(restored, "key1", priv1) == plaintext
        assert decrypt_file_envelope(restored, "key2", priv2) == plaintext


class TestKeyRotation:
    def test_rewrap(self, two_keypairs):
        (priv1, pub1), (priv2, pub2) = two_keypairs
        plaintext = b"rotate me"
        encrypted = encrypt_file_envelope(plaintext, [("key1", pub1)])

        rotated = rewrap_for_new_key(encrypted, "key1", priv1, "key2", pub2)

        result = decrypt_file_envelope(rotated, "key2", priv2)
        assert result == plaintext

    def test_old_key_no_longer_works(self, two_keypairs):
        (priv1, pub1), (priv2, pub2) = two_keypairs
        plaintext = b"rotate me"
        encrypted = encrypt_file_envelope(plaintext, [("key1", pub1)])
        rotated = rewrap_for_new_key(encrypted, "key1", priv1, "key2", pub2)

        with pytest.raises(ValueError, match="No wrapped key found"):
            decrypt_file_envelope(rotated, "key1", priv1)

    def test_rewrap_wrong_key_id_raises(self, keypair):
        priv, pub = keypair
        encrypted = encrypt_file_envelope(b"data", [("key1", pub)])
        with pytest.raises(ValueError, match="No wrapped key found"):
            rewrap_for_new_key(encrypted, "wrong", priv, "key2", pub)

    def test_data_unchanged_after_rotation(self, two_keypairs):
        (priv1, pub1), (priv2, pub2) = two_keypairs
        plaintext = b"unchanged"
        encrypted = encrypt_file_envelope(plaintext, [("key1", pub1)])
        rotated = rewrap_for_new_key(encrypted, "key1", priv1, "key2", pub2)

        # The encrypted data blob itself should be identical
        assert rotated.encrypted_data.nonce == encrypted.encrypted_data.nonce
        assert rotated.encrypted_data.ciphertext == encrypted.encrypted_data.ciphertext

    def test_double_rotation(self):
        priv1, pub1 = generate_keypair()
        priv2, pub2 = generate_keypair()
        priv3, pub3 = generate_keypair()

        plaintext = b"double rotate"
        encrypted = encrypt_file_envelope(plaintext, [("key1", pub1)])
        rotated1 = rewrap_for_new_key(encrypted, "key1", priv1, "key2", pub2)
        rotated2 = rewrap_for_new_key(rotated1, "key2", priv2, "key3", pub3)

        result = decrypt_file_envelope(rotated2, "key3", priv3)
        assert result == plaintext
