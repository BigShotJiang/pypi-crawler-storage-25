"""Adversarial Cycle 3 — FINAL verification.

Targets:
1. Serialization roundtrips (encrypt -> serialize -> deserialize -> decrypt)
2. Key rotation edge cases (rotate twice, rotate with active encryptions)
3. Audit log with 1000 entries — performance
4. File permissions on keystore
5. Concurrent encrypt operations
"""

import hashlib
import json
import os
import shutil
import time
import threading
from concurrent.futures import ThreadPoolExecutor, as_completed
from pathlib import Path

import pytest
from cryptography.hazmat.primitives.asymmetric.x25519 import X25519PrivateKey

from encryptbox.crypto import (
    AES_KEY_SIZE,
    NONCE_SIZE,
    EncryptedBlob,
    WrappedKey,
    decrypt_data,
    encrypt_data,
    generate_data_key,
    generate_keypair,
    unwrap_key,
    wrap_key,
)
from encryptbox.envelope import (
    EBOX_EXT,
    EncryptedFile,
    RecipientEntry,
    decrypt_file_envelope,
    encrypt_file_envelope,
    rewrap_for_new_key,
)
from encryptbox.keystore import Keystore
from encryptbox.audit import AuditLog, AuditEntry
from encryptbox.operations import EncryptboxOps


# --- 1. SERIALIZATION ROUNDTRIPS ---

class TestSerializationRoundtrips:
    """Encrypt -> serialize -> deserialize -> decrypt must be lossless."""

    def test_basic_roundtrip_bytes_exact(self):
        priv, pub = generate_keypair()
        plaintext = b"The quick brown fox jumps over the lazy dog"
        encrypted = encrypt_file_envelope(plaintext, [("k1", pub)])
        raw = encrypted.serialize()
        restored = EncryptedFile.deserialize(raw)
        result = decrypt_file_envelope(restored, "k1", priv)
        assert result == plaintext

    def test_roundtrip_empty_plaintext(self):
        priv, pub = generate_keypair()
        encrypted = encrypt_file_envelope(b"", [("k1", pub)])
        raw = encrypted.serialize()
        restored = EncryptedFile.deserialize(raw)
        result = decrypt_file_envelope(restored, "k1", priv)
        assert result == b""

    def test_roundtrip_1mb_binary(self):
        priv, pub = generate_keypair()
        plaintext = os.urandom(1024 * 1024)
        encrypted = encrypt_file_envelope(plaintext, [("k1", pub)])
        raw = encrypted.serialize()
        restored = EncryptedFile.deserialize(raw)
        result = decrypt_file_envelope(restored, "k1", priv)
        assert result == plaintext

    def test_roundtrip_multi_recipient(self):
        pairs = [generate_keypair() for _ in range(5)]
        plaintext = b"shared secret for 5"
        recipients = [(f"k{i}", pub) for i, (_, pub) in enumerate(pairs)]
        encrypted = encrypt_file_envelope(plaintext, recipients)
        raw = encrypted.serialize()
        restored = EncryptedFile.deserialize(raw)
        for i, (priv, _) in enumerate(pairs):
            result = decrypt_file_envelope(restored, f"k{i}", priv)
            assert result == plaintext

    def test_double_serialize_deserialize(self):
        priv, pub = generate_keypair()
        plaintext = b"double roundtrip"
        encrypted = encrypt_file_envelope(plaintext, [("k1", pub)])
        raw1 = encrypted.serialize()
        restored1 = EncryptedFile.deserialize(raw1)
        raw2 = restored1.serialize()
        restored2 = EncryptedFile.deserialize(raw2)
        assert raw1 == raw2
        result = decrypt_file_envelope(restored2, "k1", priv)
        assert result == plaintext

    def test_roundtrip_preserves_original_hash(self):
        priv, pub = generate_keypair()
        plaintext = b"hash check"
        expected_hash = hashlib.sha256(plaintext).digest()
        encrypted = encrypt_file_envelope(plaintext, [("k1", pub)])
        assert encrypted.original_hash == expected_hash
        raw = encrypted.serialize()
        restored = EncryptedFile.deserialize(raw)
        assert restored.original_hash == expected_hash

    def test_serialization_with_long_key_id(self):
        priv, pub = generate_keypair()
        long_id = "k" * 255
        plaintext = b"long key id test"
        encrypted = encrypt_file_envelope(plaintext, [(long_id, pub)])
        raw = encrypted.serialize()
        restored = EncryptedFile.deserialize(raw)
        result = decrypt_file_envelope(restored, long_id, priv)
        assert result == plaintext

    def test_serialized_then_written_to_file_then_read_back(self, tmp_path):
        priv, pub = generate_keypair()
        plaintext = b"file roundtrip"
        encrypted = encrypt_file_envelope(plaintext, [("k1", pub)])
        raw = encrypted.serialize()
        ebox_file = tmp_path / "test.ebox"
        ebox_file.write_bytes(raw)
        read_back = ebox_file.read_bytes()
        restored = EncryptedFile.deserialize(read_back)
        result = decrypt_file_envelope(restored, "k1", priv)
        assert result == plaintext

    def test_all_zero_plaintext(self):
        priv, pub = generate_keypair()
        plaintext = b"\x00" * 4096
        encrypted = encrypt_file_envelope(plaintext, [("k1", pub)])
        raw = encrypted.serialize()
        restored = EncryptedFile.deserialize(raw)
        result = decrypt_file_envelope(restored, "k1", priv)
        assert result == plaintext

    def test_all_ff_plaintext(self):
        priv, pub = generate_keypair()
        plaintext = b"\xff" * 4096
        encrypted = encrypt_file_envelope(plaintext, [("k1", pub)])
        raw = encrypted.serialize()
        restored = EncryptedFile.deserialize(raw)
        result = decrypt_file_envelope(restored, "k1", priv)
        assert result == plaintext


# --- 2. KEY ROTATION EDGE CASES ---

class TestKeyRotationEdgeCases:

    def test_triple_rotation(self):
        keys = [generate_keypair() for _ in range(4)]
        plaintext = b"triple rotate"
        encrypted = encrypt_file_envelope(plaintext, [("k0", keys[0][1])])
        for i in range(3):
            encrypted = rewrap_for_new_key(
                encrypted, f"k{i}", keys[i][0], f"k{i+1}", keys[i+1][1]
            )
        result = decrypt_file_envelope(encrypted, "k3", keys[3][0])
        assert result == plaintext

    def test_rotation_then_serialize_then_decrypt(self):
        priv1, pub1 = generate_keypair()
        priv2, pub2 = generate_keypair()
        plaintext = b"rotate and serialize"
        encrypted = encrypt_file_envelope(plaintext, [("k1", pub1)])
        rotated = rewrap_for_new_key(encrypted, "k1", priv1, "k2", pub2)
        raw = rotated.serialize()
        restored = EncryptedFile.deserialize(raw)
        result = decrypt_file_envelope(restored, "k2", priv2)
        assert result == plaintext

    def test_rotate_multi_recipient_only_rotates_matched_key(self):
        priv1, pub1 = generate_keypair()
        priv2, pub2 = generate_keypair()
        priv3, pub3 = generate_keypair()
        priv_new, pub_new = generate_keypair()
        plaintext = b"multi-recipient rotate"
        encrypted = encrypt_file_envelope(
            plaintext, [("k1", pub1), ("k2", pub2), ("k3", pub3)]
        )
        rotated = rewrap_for_new_key(encrypted, "k1", priv1, "k_new", pub_new)
        assert decrypt_file_envelope(rotated, "k_new", priv_new) == plaintext
        assert decrypt_file_envelope(rotated, "k2", priv2) == plaintext
        assert decrypt_file_envelope(rotated, "k3", priv3) == plaintext
        with pytest.raises(ValueError, match="No wrapped key found"):
            decrypt_file_envelope(rotated, "k1", priv1)

    def test_rotate_same_key_id(self):
        priv1, pub1 = generate_keypair()
        priv2, pub2 = generate_keypair()
        plaintext = b"same id rotate"
        encrypted = encrypt_file_envelope(plaintext, [("k1", pub1)])
        rotated = rewrap_for_new_key(encrypted, "k1", priv1, "k1", pub2)
        result = decrypt_file_envelope(rotated, "k1", priv2)
        assert result == plaintext
        with pytest.raises(Exception):
            decrypt_file_envelope(rotated, "k1", priv1)

    def test_ops_double_rotation_decrypt_with_new_key(self, tmp_path):
        ops = EncryptboxOps(tmp_path)
        ops.init()
        ops.keygen()
        f = tmp_path / "secret.txt"
        f.write_text("double rotate ops")
        ops.encrypt_file(f)
        ops.rotate_keys()
        ops.rotate_keys()
        ebox = f.with_suffix(f.suffix + EBOX_EXT)
        f.unlink()
        decrypted = ops.decrypt_file(ebox)
        assert decrypted.read_text() == "double rotate ops"

    def test_ops_rotate_with_multiple_ebox_files(self, tmp_path):
        ops = EncryptboxOps(tmp_path)
        ops.init()
        ops.keygen()
        originals = {}
        for i in range(10):
            f = tmp_path / f"file{i}.txt"
            content = f"content-{i}-{os.urandom(16).hex()}"
            f.write_text(content)
            originals[f"file{i}.txt"] = content
            ops.encrypt_file(f)
        ops.rotate_keys()
        for name, expected in originals.items():
            ebox = tmp_path / (name + EBOX_EXT)
            orig = tmp_path / name
            if orig.exists():
                orig.unlink()
            decrypted = ops.decrypt_file(ebox)
            assert decrypted.read_text() == expected

    def test_rotate_preserves_encrypted_data_blob(self):
        priv1, pub1 = generate_keypair()
        priv2, pub2 = generate_keypair()
        plaintext = b"blob preservation"
        original = encrypt_file_envelope(plaintext, [("k1", pub1)])
        rotated = rewrap_for_new_key(original, "k1", priv1, "k2", pub2)
        assert rotated.encrypted_data.nonce == original.encrypted_data.nonce
        assert rotated.encrypted_data.ciphertext == original.encrypted_data.ciphertext
        assert rotated.original_hash == original.original_hash


# --- 3. AUDIT LOG WITH 1000 ENTRIES ---

class TestAuditPerformance:

    def test_1000_entries_write(self, tmp_path):
        audit = AuditLog(tmp_path)
        start = time.time()
        for i in range(1000):
            audit.log(
                action=f"test-{i}",
                key_id=f"key-{i % 10}",
                file_path=f"/file-{i}.txt",
                file_hash=hashlib.sha256(f"data-{i}".encode()).hexdigest(),
                user="perf-test",
                details={"index": i, "batch": i // 100},
            )
        elapsed = time.time() - start
        assert elapsed < 30, f"1000 entries took {elapsed:.2f}s"
        assert audit.entry_count() == 1000

    def test_1000_entries_verify_chain(self, tmp_path):
        audit = AuditLog(tmp_path)
        for i in range(1000):
            audit.log(action=f"action-{i}", key_id=f"k{i % 5}")
        start = time.time()
        valid, msg = audit.verify_chain()
        elapsed = time.time() - start
        assert valid is True
        assert "1000 entries verified" in msg
        assert elapsed < 30, f"Verification took {elapsed:.2f}s"

    def test_1000_entries_read_all(self, tmp_path):
        audit = AuditLog(tmp_path)
        for i in range(1000):
            audit.log(action=f"action-{i}")
        entries = audit.read_all()
        assert len(entries) == 1000
        assert entries[0].action == "action-0"
        assert entries[999].action == "action-999"

    def test_1000_entries_chain_integrity(self, tmp_path):
        audit = AuditLog(tmp_path)
        for i in range(1000):
            audit.log(action=f"action-{i}")
        entries = audit.read_all()
        for i in range(1, len(entries)):
            assert entries[i].prev_hmac == entries[i-1].entry_hmac, \
                f"Chain broken at entry {i}"

    def test_append_after_1000_entries(self, tmp_path):
        audit = AuditLog(tmp_path)
        for i in range(1000):
            audit.log(action=f"action-{i}")
        entry = audit.log(action="final")
        entries = audit.read_all()
        assert len(entries) == 1001
        assert entries[-1].prev_hmac == entries[-2].entry_hmac

    def test_1000_entries_tamper_middle_detected(self, tmp_path):
        audit = AuditLog(tmp_path)
        for i in range(1000):
            audit.log(action=f"action-{i}")
        lines = audit.log_path.read_text().strip().split("\n")
        entry = json.loads(lines[500])
        entry["action"] = "TAMPERED"
        lines[500] = json.dumps(entry)
        audit.log_path.write_text("\n".join(lines) + "\n")
        valid, msg = audit.verify_chain()
        assert valid is False
        assert "500" in msg


# --- 4. FILE PERMISSIONS ON KEYSTORE ---

class TestKeystoreFileHandling:

    def test_private_key_is_raw_32_bytes(self, tmp_path):
        store = Keystore(tmp_path)
        store.init()
        key_id, _ = store.generate_key()
        priv_path = store.keys_dir / key_id / "private.key"
        raw = priv_path.read_bytes()
        assert len(raw) == 32

    def test_public_key_is_raw_32_bytes(self, tmp_path):
        store = Keystore(tmp_path)
        store.init()
        key_id, _ = store.generate_key()
        pub_path = store.keys_dir / key_id / "public.key"
        raw = pub_path.read_bytes()
        assert len(raw) == 32

    def test_meta_is_valid_json(self, tmp_path):
        store = Keystore(tmp_path)
        store.init()
        key_id, _ = store.generate_key(label="test-label")
        meta_path = store.keys_dir / key_id / "meta.json"
        data = json.loads(meta_path.read_text())
        assert data["key_id"] == key_id
        assert data["is_active"] is True
        assert data["label"] == "test-label"
        assert "created_at" in data

    def test_config_is_valid_json(self, tmp_path):
        store = Keystore(tmp_path)
        store.init()
        config_path = store.store_dir / "config.json"
        data = json.loads(config_path.read_text())
        assert data["version"] == 1

    def test_audit_secret_is_32_bytes(self, tmp_path):
        audit = AuditLog(tmp_path)
        audit.log(action="test")
        raw = audit.secret_path.read_bytes()
        assert len(raw) == 32

    def test_corrupted_private_key_fails_gracefully(self, tmp_path):
        store = Keystore(tmp_path)
        store.init()
        key_id, _ = store.generate_key()
        priv_path = store.keys_dir / key_id / "private.key"
        priv_path.write_bytes(b"corrupted" * 4)
        with pytest.raises(Exception):
            store.get_private_key(key_id)

    def test_corrupted_meta_json_fails_gracefully(self, tmp_path):
        store = Keystore(tmp_path)
        store.init()
        key_id, _ = store.generate_key()
        meta_path = store.keys_dir / key_id / "meta.json"
        meta_path.write_text("not json at all")
        with pytest.raises(Exception):
            store.get_key_meta(key_id)

    def test_corrupted_config_json_fails_gracefully(self, tmp_path):
        store = Keystore(tmp_path)
        store.init()
        config_path = store.store_dir / "config.json"
        config_path.write_text("{broken")
        with pytest.raises(Exception):
            store._read_config()

    def test_missing_key_dir_after_generate(self, tmp_path):
        store = Keystore(tmp_path)
        store.init()
        key_id, _ = store.generate_key()
        shutil.rmtree(store.keys_dir / key_id)
        with pytest.raises(FileNotFoundError):
            store.get_private_key(key_id)

    def test_keystore_survives_multiple_instances(self, tmp_path):
        store1 = Keystore(tmp_path)
        store1.init()
        key_id, _ = store1.generate_key()
        store2 = Keystore(tmp_path)
        assert store2.is_initialized
        pub = store2.get_public_key(key_id)
        assert pub is not None


# --- 5. CONCURRENT ENCRYPT OPERATIONS ---

class TestConcurrentOperations:

    def test_concurrent_encrypt_data_calls(self):
        key = generate_data_key()
        results = {}
        errors = []

        def encrypt_task(idx):
            try:
                plaintext = f"thread-{idx}-data".encode()
                blob = encrypt_data(key, plaintext)
                decrypted = decrypt_data(key, blob)
                if decrypted != plaintext:
                    errors.append(f"Thread {idx}: data mismatch")
                results[idx] = True
            except Exception as e:
                errors.append(f"Thread {idx}: {e}")

        threads = [threading.Thread(target=encrypt_task, args=(i,)) for i in range(50)]
        for t in threads:
            t.start()
        for t in threads:
            t.join(timeout=10)
        assert not errors, f"Errors: {errors}"
        assert len(results) == 50

    def test_concurrent_envelope_encrypt(self):
        priv, pub = generate_keypair()
        errors = []

        def task(idx):
            try:
                plaintext = f"envelope-{idx}".encode()
                encrypted = encrypt_file_envelope(plaintext, [("k1", pub)])
                raw = encrypted.serialize()
                restored = EncryptedFile.deserialize(raw)
                result = decrypt_file_envelope(restored, "k1", priv)
                if result != plaintext:
                    errors.append(f"Thread {idx}: mismatch")
            except Exception as e:
                errors.append(f"Thread {idx}: {e}")

        with ThreadPoolExecutor(max_workers=10) as executor:
            futures = [executor.submit(task, i) for i in range(50)]
            for f in as_completed(futures):
                f.result()
        assert not errors, f"Errors: {errors}"

    def test_concurrent_audit_log_writes(self, tmp_path):
        audit = AuditLog(tmp_path)
        errors = []
        lock = threading.Lock()

        def log_task(idx):
            try:
                with lock:
                    audit.log(action=f"concurrent-{idx}", user=f"thread-{idx}")
            except Exception as e:
                errors.append(f"Thread {idx}: {e}")

        threads = [threading.Thread(target=log_task, args=(i,)) for i in range(100)]
        for t in threads:
            t.start()
        for t in threads:
            t.join(timeout=30)
        assert not errors, f"Errors: {errors}"
        assert audit.entry_count() == 100
        valid, msg = audit.verify_chain()
        assert valid is True

    def test_concurrent_file_encrypt_ops(self, tmp_path):
        ops = EncryptboxOps(tmp_path)
        ops.init()
        ops.keygen()
        for i in range(10):
            f = tmp_path / f"concurrent_{i}.txt"
            f.write_text(f"concurrent content {i}")
        errors = []
        lock = threading.Lock()

        def encrypt_task(idx):
            try:
                f = tmp_path / f"concurrent_{idx}.txt"
                with lock:
                    ops.encrypt_file(f)
            except Exception as e:
                errors.append(f"Thread {idx}: {e}")

        threads = [threading.Thread(target=encrypt_task, args=(i,)) for i in range(10)]
        for t in threads:
            t.start()
        for t in threads:
            t.join(timeout=30)
        assert not errors, f"Errors: {errors}"
        for i in range(10):
            ebox = tmp_path / f"concurrent_{i}.txt.ebox"
            assert ebox.exists(), f"Missing: {ebox}"
            orig = tmp_path / f"concurrent_{i}.txt"
            orig.unlink()
            decrypted = ops.decrypt_file(ebox)
            assert decrypted.read_text() == f"concurrent content {i}"


# --- BONUS: NASTY EDGE CASES ---

class TestNastyEdgeCases:

    def test_encrypt_decrypt_single_byte(self):
        priv, pub = generate_keypair()
        for b in [b"\x00", b"\xff", b"A"]:
            encrypted = encrypt_file_envelope(b, [("k1", pub)])
            raw = encrypted.serialize()
            restored = EncryptedFile.deserialize(raw)
            assert decrypt_file_envelope(restored, "k1", priv) == b

    def test_tampered_encrypted_data_after_serialize(self):
        priv, pub = generate_keypair()
        encrypted = encrypt_file_envelope(b"tamper test", [("k1", pub)])
        raw = bytearray(encrypted.serialize())
        raw[-1] ^= 0x01
        restored = EncryptedFile.deserialize(bytes(raw))
        with pytest.raises(Exception):
            decrypt_file_envelope(restored, "k1", priv)

    def test_wrapped_key_tampered(self):
        priv, pub = generate_keypair()
        data_key = generate_data_key()
        wrapped = wrap_key(pub, data_key)
        corrupted = WrappedKey(
            ephemeral_public=wrapped.ephemeral_public,
            encrypted_data_key=wrapped.encrypted_data_key[:-1] + bytes([wrapped.encrypted_data_key[-1] ^ 0xFF]),
        )
        with pytest.raises(Exception):
            unwrap_key(priv, corrupted)

    def test_ops_encrypt_decrypt_after_triple_rotation(self, tmp_path):
        ops = EncryptboxOps(tmp_path)
        ops.init()
        ops.keygen()
        f = tmp_path / "triple.txt"
        f.write_text("survive 3 rotations")
        ops.encrypt_file(f)
        for _ in range(3):
            ops.rotate_keys()
        ebox = f.with_suffix(f.suffix + EBOX_EXT)
        f.unlink()
        decrypted = ops.decrypt_file(ebox)
        assert decrypted.read_text() == "survive 3 rotations"

    def test_audit_log_survives_empty_lines(self, tmp_path):
        audit = AuditLog(tmp_path)
        audit.log(action="a1")
        audit.log(action="a2")
        content = audit.log_path.read_text()
        audit.log_path.write_text("\n" + content + "\n\n")
        entries = audit.read_all()
        assert len(entries) == 2
        valid, msg = audit.verify_chain()
        assert valid is True

    def test_keystore_many_keys(self, tmp_path):
        store = Keystore(tmp_path)
        store.init()
        ids = []
        for i in range(20):
            kid, _ = store.generate_key(label=f"key-{i}")
            ids.append(kid)
        keys = store.list_keys()
        assert len(keys) == 20
        assert store.get_default_key_id() == ids[0]
        store.set_default_key(ids[-1])
        assert store.get_default_key_id() == ids[-1]
