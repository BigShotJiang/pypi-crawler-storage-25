"""Tests for high-level operations."""

import os

import pytest

from encryptbox.envelope import EBOX_EXT
from encryptbox.operations import EncryptboxOps


@pytest.fixture
def ops(tmp_path):
    o = EncryptboxOps(tmp_path)
    o.init()
    o.keygen()
    return o


@pytest.fixture
def ops_no_key(tmp_path):
    o = EncryptboxOps(tmp_path)
    o.init()
    return o


@pytest.fixture
def sample_file(tmp_path):
    f = tmp_path / "secret.txt"
    f.write_text("This is secret data")
    return f


@pytest.fixture
def binary_file(tmp_path):
    f = tmp_path / "binary.dat"
    f.write_bytes(os.urandom(1024))
    return f


@pytest.fixture
def empty_file(tmp_path):
    f = tmp_path / "empty.txt"
    f.write_bytes(b"")
    return f


class TestInit:
    def test_init(self, tmp_path):
        ops = EncryptboxOps(tmp_path)
        msg = ops.init()
        assert "initialized" in msg.lower()

    def test_double_init_raises(self, ops):
        with pytest.raises(FileExistsError):
            ops.init()


class TestKeygen:
    def test_keygen(self, ops_no_key):
        key_id, msg = ops_no_key.keygen()
        assert len(key_id) == 16
        assert "Generated" in msg

    def test_keygen_with_label(self, ops_no_key):
        key_id, _ = ops_no_key.keygen(label="my-key")
        meta = ops_no_key.keystore.get_key_meta(key_id)
        assert meta.label == "my-key"


class TestEncryptFile:
    def test_encrypt_creates_ebox(self, ops, sample_file):
        out = ops.encrypt_file(sample_file)
        assert out.exists()
        assert out.suffix == EBOX_EXT

    def test_encrypt_nonexistent_raises(self, ops, tmp_path):
        with pytest.raises(FileNotFoundError):
            ops.encrypt_file(tmp_path / "nope.txt")

    def test_encrypt_already_encrypted_raises(self, ops, sample_file):
        out = ops.encrypt_file(sample_file)
        with pytest.raises(ValueError, match="already encrypted"):
            ops.encrypt_file(out)

    def test_encrypt_with_output_path(self, ops, sample_file, tmp_path):
        out_path = tmp_path / "custom.enc"
        out = ops.encrypt_file(sample_file, output_path=out_path)
        assert out == out_path
        assert out.exists()

    def test_encrypt_remove_original(self, ops, sample_file):
        ops.encrypt_file(sample_file, remove_original=True)
        assert not sample_file.exists()

    def test_encrypt_binary(self, ops, binary_file):
        out = ops.encrypt_file(binary_file)
        assert out.exists()

    def test_encrypt_empty(self, ops, empty_file):
        out = ops.encrypt_file(empty_file)
        assert out.exists()


class TestDecryptFile:
    def test_decrypt_round_trip(self, ops, sample_file):
        encrypted = ops.encrypt_file(sample_file)
        sample_file.unlink()  # remove original so decrypt can write to same name
        decrypted = ops.decrypt_file(encrypted)
        assert decrypted.read_text() == "This is secret data"

    def test_decrypt_nonexistent_raises(self, ops, tmp_path):
        with pytest.raises(FileNotFoundError):
            ops.decrypt_file(tmp_path / "nope.ebox")

    def test_decrypt_remove_encrypted(self, ops, sample_file):
        encrypted = ops.encrypt_file(sample_file)
        sample_file.unlink()
        ops.decrypt_file(encrypted, remove_encrypted=True)
        assert not encrypted.exists()

    def test_decrypt_with_output_path(self, ops, sample_file, tmp_path):
        encrypted = ops.encrypt_file(sample_file)
        out_path = tmp_path / "decrypted.txt"
        out = ops.decrypt_file(encrypted, output_path=out_path)
        assert out == out_path
        assert out.read_text() == "This is secret data"

    def test_decrypt_binary_round_trip(self, ops, binary_file):
        original = binary_file.read_bytes()
        encrypted = ops.encrypt_file(binary_file)
        binary_file.unlink()
        decrypted = ops.decrypt_file(encrypted)
        assert decrypted.read_bytes() == original

    def test_decrypt_empty_round_trip(self, ops, empty_file):
        encrypted = ops.encrypt_file(empty_file)
        empty_file.unlink()
        decrypted = ops.decrypt_file(encrypted)
        assert decrypted.read_bytes() == b""


class TestRotateKeys:
    def test_rotate(self, ops, sample_file):
        encrypted = ops.encrypt_file(sample_file)
        old_id, new_id, count = ops.rotate_keys()
        assert old_id != new_id
        assert count == 1

    def test_decrypt_after_rotation(self, ops, sample_file):
        encrypted = ops.encrypt_file(sample_file)
        ops.rotate_keys()
        sample_file.unlink()
        decrypted = ops.decrypt_file(encrypted)
        assert decrypted.read_text() == "This is secret data"

    def test_rotate_multiple_files(self, ops, tmp_path):
        for i in range(3):
            f = tmp_path / f"file{i}.txt"
            f.write_text(f"content {i}")
            ops.encrypt_file(f)
        _, _, count = ops.rotate_keys()
        assert count == 3

    def test_double_rotation(self, ops, sample_file):
        ops.encrypt_file(sample_file)
        ops.rotate_keys()
        ops.rotate_keys()
        # Should still be able to decrypt
        ebox = sample_file.with_suffix(sample_file.suffix + EBOX_EXT)
        sample_file.unlink()
        decrypted = ops.decrypt_file(ebox)
        assert decrypted.read_text() == "This is secret data"

    def test_old_key_deactivated(self, ops, sample_file):
        ops.encrypt_file(sample_file)
        old_id, _, _ = ops.rotate_keys()
        meta = ops.keystore.get_key_meta(old_id)
        assert meta.is_active is False


class TestBatchOperations:
    def test_encrypt_directory(self, ops, tmp_path):
        subdir = tmp_path / "data"
        subdir.mkdir()
        for i in range(3):
            (subdir / f"file{i}.txt").write_text(f"content {i}")
        results = ops.encrypt_directory(subdir)
        assert len(results) == 3

    def test_decrypt_directory(self, ops, tmp_path):
        subdir = tmp_path / "data"
        subdir.mkdir()
        for i in range(3):
            (subdir / f"file{i}.txt").write_text(f"content {i}")
        ops.encrypt_directory(subdir)
        # Remove originals
        for i in range(3):
            (subdir / f"file{i}.txt").unlink()
        results = ops.decrypt_directory(subdir)
        assert len(results) == 3

    def test_encrypt_directory_with_pattern(self, ops, tmp_path):
        subdir = tmp_path / "data"
        subdir.mkdir()
        (subdir / "a.txt").write_text("text")
        (subdir / "b.csv").write_text("csv")
        results = ops.encrypt_directory(subdir, pattern="*.txt")
        assert len(results) == 1

    def test_encrypt_not_a_dir_raises(self, ops, sample_file):
        with pytest.raises(NotADirectoryError):
            ops.encrypt_directory(sample_file)

    def test_encrypt_dir_remove_originals(self, ops, tmp_path):
        subdir = tmp_path / "data"
        subdir.mkdir()
        (subdir / "a.txt").write_text("text")
        ops.encrypt_directory(subdir, remove_originals=True)
        assert not (subdir / "a.txt").exists()
        assert (subdir / "a.txt.ebox").exists()


class TestStatus:
    def test_status_initialized(self, ops):
        st = ops.status()
        assert st["initialized"] is True
        assert st["total_keys"] == 1
        assert st["active_keys"] == 1

    def test_status_not_initialized(self, tmp_path):
        ops = EncryptboxOps(tmp_path)
        st = ops.status()
        assert st["initialized"] is False

    def test_status_audit_valid(self, ops):
        st = ops.status()
        assert st["audit_valid"] is True

    def test_status_after_operations(self, ops, sample_file):
        ops.encrypt_file(sample_file)
        st = ops.status()
        assert st["audit_entries"] >= 2  # init + keygen + encrypt


class TestAuditIntegration:
    def test_encrypt_logged(self, ops, sample_file):
        ops.encrypt_file(sample_file)
        entries = ops.audit.read_all()
        actions = [e.action for e in entries]
        assert "encrypt" in actions

    def test_decrypt_logged(self, ops, sample_file):
        encrypted = ops.encrypt_file(sample_file)
        sample_file.unlink()
        ops.decrypt_file(encrypted)
        entries = ops.audit.read_all()
        actions = [e.action for e in entries]
        assert "decrypt" in actions

    def test_rotate_logged(self, ops, sample_file):
        ops.encrypt_file(sample_file)
        ops.rotate_keys()
        entries = ops.audit.read_all()
        actions = [e.action for e in entries]
        assert "rotate" in actions

    def test_audit_chain_valid_after_operations(self, ops, sample_file):
        ops.encrypt_file(sample_file)
        encrypted = sample_file.with_suffix(sample_file.suffix + EBOX_EXT)
        sample_file.unlink()
        ops.decrypt_file(encrypted)
        ops.rotate_keys()
        valid, _ = ops.audit.verify_chain()
        assert valid is True
