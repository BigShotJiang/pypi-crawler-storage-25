"""Tests for CLI interface."""

import json
import os

import pytest
from click.testing import CliRunner

from encryptbox.cli import cli


@pytest.fixture
def runner():
    return CliRunner()


@pytest.fixture
def initialized(tmp_path, runner):
    """Initialize a keystore and generate a key."""
    result = runner.invoke(cli, ["--root", str(tmp_path), "init"])
    assert result.exit_code == 0
    result = runner.invoke(cli, ["--root", str(tmp_path), "keygen"])
    assert result.exit_code == 0
    return tmp_path


@pytest.fixture
def sample_file(tmp_path):
    f = tmp_path / "test.txt"
    f.write_text("hello world")
    return f


class TestInitCommand:
    def test_init(self, runner, tmp_path):
        result = runner.invoke(cli, ["--root", str(tmp_path), "init"])
        assert result.exit_code == 0
        assert "initialized" in result.output.lower()

    def test_double_init(self, runner, tmp_path):
        runner.invoke(cli, ["--root", str(tmp_path), "init"])
        result = runner.invoke(cli, ["--root", str(tmp_path), "init"])
        assert result.exit_code == 1


class TestKeygenCommand:
    def test_keygen(self, runner, tmp_path):
        runner.invoke(cli, ["--root", str(tmp_path), "init"])
        result = runner.invoke(cli, ["--root", str(tmp_path), "keygen"])
        assert result.exit_code == 0
        assert "Generated" in result.output

    def test_keygen_with_label(self, runner, tmp_path):
        runner.invoke(cli, ["--root", str(tmp_path), "init"])
        result = runner.invoke(cli, ["--root", str(tmp_path), "keygen", "--label", "test"])
        assert result.exit_code == 0
        assert "test" in result.output

    def test_keygen_without_init(self, runner, tmp_path):
        result = runner.invoke(cli, ["--root", str(tmp_path), "keygen"])
        assert result.exit_code == 1


class TestEncryptCommand:
    def test_encrypt(self, runner, initialized, sample_file):
        result = runner.invoke(cli, ["--root", str(initialized), "encrypt", str(sample_file)])
        assert result.exit_code == 0
        assert "Encrypted" in result.output

    def test_encrypt_with_output(self, runner, initialized, sample_file):
        out = initialized / "custom.enc"
        result = runner.invoke(cli, ["--root", str(initialized), "encrypt", str(sample_file), "-o", str(out)])
        assert result.exit_code == 0
        assert out.exists()

    def test_encrypt_nonexistent(self, runner, initialized):
        result = runner.invoke(cli, ["--root", str(initialized), "encrypt", str(initialized / "nope.txt")])
        assert result.exit_code != 0


class TestDecryptCommand:
    def test_decrypt(self, runner, initialized, sample_file):
        runner.invoke(cli, ["--root", str(initialized), "encrypt", str(sample_file)])
        ebox = sample_file.with_suffix(".txt.ebox")
        sample_file.unlink()
        result = runner.invoke(cli, ["--root", str(initialized), "decrypt", str(ebox)])
        assert result.exit_code == 0
        assert "Decrypted" in result.output
        assert sample_file.read_text() == "hello world"

    def test_decrypt_with_output(self, runner, initialized, sample_file):
        runner.invoke(cli, ["--root", str(initialized), "encrypt", str(sample_file)])
        ebox = sample_file.with_suffix(".txt.ebox")
        out = initialized / "restored.txt"
        result = runner.invoke(cli, ["--root", str(initialized), "decrypt", str(ebox), "-o", str(out)])
        assert result.exit_code == 0
        assert out.read_text() == "hello world"


class TestRotateCommand:
    def test_rotate(self, runner, initialized, sample_file):
        runner.invoke(cli, ["--root", str(initialized), "encrypt", str(sample_file)])
        result = runner.invoke(cli, ["--root", str(initialized), "rotate"])
        assert result.exit_code == 0
        assert "rotated" in result.output.lower()


class TestAuditCommand:
    def test_audit_empty(self, runner, initialized):
        result = runner.invoke(cli, ["--root", str(initialized), "audit"])
        assert result.exit_code == 0

    def test_audit_after_operations(self, runner, initialized, sample_file):
        runner.invoke(cli, ["--root", str(initialized), "encrypt", str(sample_file)])
        result = runner.invoke(cli, ["--root", str(initialized), "audit"])
        assert result.exit_code == 0
        assert "ENCRYPT" in result.output

    def test_audit_verify(self, runner, initialized, sample_file):
        runner.invoke(cli, ["--root", str(initialized), "encrypt", str(sample_file)])
        result = runner.invoke(cli, ["--root", str(initialized), "audit", "--verify"])
        assert result.exit_code == 0
        assert "verified" in result.output.lower()

    def test_audit_json(self, runner, initialized, sample_file):
        runner.invoke(cli, ["--root", str(initialized), "encrypt", str(sample_file)])
        result = runner.invoke(cli, ["--root", str(initialized), "audit", "--json-output"])
        assert result.exit_code == 0
        # Each line should be valid JSON
        for line in result.output.strip().split("\n"):
            if line:
                json.loads(line)

    def test_audit_last_n(self, runner, initialized, sample_file):
        runner.invoke(cli, ["--root", str(initialized), "encrypt", str(sample_file)])
        result = runner.invoke(cli, ["--root", str(initialized), "audit", "--last", "1"])
        assert result.exit_code == 0


class TestStatusCommand:
    def test_status(self, runner, initialized):
        result = runner.invoke(cli, ["--root", str(initialized), "status"])
        assert result.exit_code == 0
        assert "Keys:" in result.output

    def test_status_not_initialized(self, runner, tmp_path):
        result = runner.invoke(cli, ["--root", str(tmp_path), "status"])
        assert result.exit_code == 0
        assert "not initialized" in result.output.lower()


class TestExportImportKey:
    def test_export_key(self, runner, initialized):
        result = runner.invoke(cli, ["--root", str(initialized), "export-key"])
        assert result.exit_code == 0
        assert "Public key:" in result.output

    def test_import_key(self, runner, initialized):
        # Export first
        result = runner.invoke(cli, ["--root", str(initialized), "export-key"])
        # Parse the hex key from output
        for line in result.output.split("\n"):
            if "Public key:" in line:
                hex_key = line.split(":")[1].strip()
                break
        # Import with a new ID
        result = runner.invoke(cli, ["--root", str(initialized), "import-key", hex_key, "--id", "imported-1"])
        assert result.exit_code == 0
        assert "Imported" in result.output
