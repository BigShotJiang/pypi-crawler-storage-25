"""encryptbox — Encrypt files with envelope encryption, key rotation, and audit logging."""

__version__ = "1.0.0"
