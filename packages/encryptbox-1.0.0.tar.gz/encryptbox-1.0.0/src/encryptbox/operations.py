"""High-level file encryption/decryption and key rotation operations.

Orchestrates crypto, keystore, and audit modules.
"""

from __future__ import annotations

import getpass
import hashlib
import os
from pathlib import Path

from .audit import AuditLog
from .envelope import (
    EBOX_EXT,
    EncryptedFile,
    decrypt_file_envelope,
    encrypt_file_envelope,
    rewrap_for_new_key,
)
from .keystore import KEYSTORE_DIR, Keystore


def _file_hash(data: bytes) -> str:
    """SHA-256 hex digest of data."""
    return hashlib.sha256(data).hexdigest()


def _current_user() -> str:
    """Get current username."""
    try:
        return getpass.getuser()
    except Exception:
        return "unknown"


class EncryptboxOps:
    """High-level operations for encryptbox."""

    def __init__(self, root: Path | str) -> None:
        self.root = Path(root)
        self.keystore = Keystore(self.root)
        self.audit = AuditLog(self.root / KEYSTORE_DIR)

    def init(self) -> str:
        """Initialize the keystore."""
        config = self.keystore.init()
        self.audit.log(
            action="init",
            user=_current_user(),
            details={"version": config.version},
        )
        return "Keystore initialized"

    def keygen(self, label: str = "") -> tuple[str, str]:
        """Generate a new keypair.

        Returns:
            (key_id, message)
        """
        key_id, public_key = self.keystore.generate_key(label=label)
        pub_hex = public_key.public_bytes_raw().hex()

        self.audit.log(
            action="keygen",
            key_id=key_id,
            user=_current_user(),
            details={"label": label, "public_key": pub_hex[:32] + "..."},
        )
        return key_id, f"Generated key: {key_id}"

    def encrypt_file(
        self,
        file_path: Path | str,
        output_path: Path | str | None = None,
        key_ids: list[str] | None = None,
        remove_original: bool = False,
    ) -> Path:
        """Encrypt a file using envelope encryption.

        Args:
            file_path: Path to the file to encrypt.
            output_path: Output path (default: file_path + .ebox).
            key_ids: Recipient key IDs (default: default key).
            remove_original: Remove original file after encryption.

        Returns:
            Path to the encrypted file.
        """
        file_path = Path(file_path)
        if not file_path.exists():
            raise FileNotFoundError(f"File not found: {file_path}")

        if file_path.suffix == EBOX_EXT:
            raise ValueError("File is already encrypted (.ebox)")

        if output_path is None:
            output_path = file_path.with_suffix(file_path.suffix + EBOX_EXT)
        output_path = Path(output_path)

        # Determine recipient keys
        if key_ids is None:
            default_id = self.keystore.get_default_key_id()
            key_ids = [default_id]

        recipient_keys = []
        for kid in key_ids:
            pub = self.keystore.get_public_key(kid)
            recipient_keys.append((kid, pub))

        # Read and encrypt
        plaintext = file_path.read_bytes()
        encrypted = encrypt_file_envelope(plaintext, recipient_keys)

        # Write output
        output_path.write_bytes(encrypted.serialize())

        # Audit
        self.audit.log(
            action="encrypt",
            key_id=",".join(key_ids),
            file_path=str(file_path),
            file_hash=_file_hash(plaintext),
            user=_current_user(),
            details={
                "output": str(output_path),
                "size": len(plaintext),
                "recipients": len(key_ids),
            },
        )

        if remove_original:
            file_path.unlink()

        return output_path

    def decrypt_file(
        self,
        file_path: Path | str,
        output_path: Path | str | None = None,
        key_id: str | None = None,
        remove_encrypted: bool = False,
    ) -> Path:
        """Decrypt an encrypted file.

        Args:
            file_path: Path to the .ebox file.
            output_path: Output path (default: strip .ebox extension).
            key_id: Key ID to use (default: try all available keys).
            remove_encrypted: Remove encrypted file after decryption.

        Returns:
            Path to the decrypted file.
        """
        file_path = Path(file_path)
        if not file_path.exists():
            raise FileNotFoundError(f"File not found: {file_path}")

        # Determine output path
        if output_path is None:
            name = str(file_path)
            if name.endswith(EBOX_EXT):
                output_path = Path(name[: -len(EBOX_EXT)])
            else:
                output_path = file_path.with_suffix(".dec")
        output_path = Path(output_path)

        # Read and parse encrypted file
        raw = file_path.read_bytes()
        encrypted = EncryptedFile.deserialize(raw)

        # Try to decrypt
        plaintext = None
        used_key_id = key_id

        if key_id:
            # Use specified key
            private = self.keystore.get_private_key(key_id)
            plaintext = decrypt_file_envelope(encrypted, key_id, private)
        else:
            # Try each recipient's key
            last_error: Exception | None = None
            for entry in encrypted.recipients:
                try:
                    private = self.keystore.get_private_key(entry.key_id)
                except FileNotFoundError:
                    continue
                try:
                    plaintext = decrypt_file_envelope(encrypted, entry.key_id, private)
                    used_key_id = entry.key_id
                    break
                except Exception as e:
                    last_error = e
                    continue

        if plaintext is None:
            if last_error is not None:
                detail = str(last_error) or f"{type(last_error).__name__} (file may be corrupted or wrong key)"
                raise ValueError(f"Decryption failed: {detail}") from last_error
            raise ValueError("No matching key found for decryption")

        # Write output
        output_path.write_bytes(plaintext)

        # Audit
        self.audit.log(
            action="decrypt",
            key_id=used_key_id or "",
            file_path=str(file_path),
            file_hash=_file_hash(plaintext),
            user=_current_user(),
            details={"output": str(output_path), "size": len(plaintext)},
        )

        if remove_encrypted:
            file_path.unlink()

        return output_path

    def rotate_keys(self) -> tuple[str, str, int]:
        """Rotate the master key.

        Generates a new keypair, re-wraps all .ebox files in the directory
        tree, and deactivates the old key.

        Returns:
            (old_key_id, new_key_id, files_rotated)
        """
        old_key_id = self.keystore.get_default_key_id()
        old_private = self.keystore.get_private_key(old_key_id)

        # Generate new key
        new_key_id, new_public = self.keystore.generate_key(label="rotated")
        self.keystore.set_default_key(new_key_id)

        # Find and re-wrap all .ebox files
        files_rotated = 0
        for ebox_path in self.root.rglob(f"*{EBOX_EXT}"):
            # Skip files in the keystore directory
            try:
                ebox_path.relative_to(self.root / KEYSTORE_DIR)
                continue
            except ValueError:
                pass

            try:
                raw = ebox_path.read_bytes()
                encrypted = EncryptedFile.deserialize(raw)

                # Check if this file has a key entry for the old key
                has_old = any(e.key_id == old_key_id for e in encrypted.recipients)
                if not has_old:
                    continue

                new_encrypted = rewrap_for_new_key(
                    encrypted, old_key_id, old_private, new_key_id, new_public
                )
                ebox_path.write_bytes(new_encrypted.serialize())
                files_rotated += 1
            except Exception:
                # Skip files that can't be rotated
                continue

        # Deactivate old key
        self.keystore.deactivate_key(old_key_id)

        # Audit
        self.audit.log(
            action="rotate",
            key_id=new_key_id,
            user=_current_user(),
            details={
                "old_key_id": old_key_id,
                "files_rotated": files_rotated,
            },
        )

        return old_key_id, new_key_id, files_rotated

    def encrypt_directory(
        self,
        dir_path: Path | str,
        key_ids: list[str] | None = None,
        pattern: str = "*",
        remove_originals: bool = False,
    ) -> list[Path]:
        """Encrypt all files in a directory matching a pattern.

        Args:
            dir_path: Directory to encrypt.
            key_ids: Recipient key IDs.
            pattern: Glob pattern for files.
            remove_originals: Remove originals after encryption.

        Returns:
            List of encrypted file paths.
        """
        dir_path = Path(dir_path)
        if not dir_path.is_dir():
            raise NotADirectoryError(f"Not a directory: {dir_path}")

        results = []
        for fp in sorted(dir_path.glob(pattern)):
            if fp.is_file() and fp.suffix != EBOX_EXT:
                try:
                    out = self.encrypt_file(fp, key_ids=key_ids, remove_original=remove_originals)
                    results.append(out)
                except Exception:
                    continue
        return results

    def decrypt_directory(
        self,
        dir_path: Path | str,
        key_id: str | None = None,
        remove_encrypted: bool = False,
    ) -> list[Path]:
        """Decrypt all .ebox files in a directory.

        Returns:
            List of decrypted file paths.
        """
        dir_path = Path(dir_path)
        if not dir_path.is_dir():
            raise NotADirectoryError(f"Not a directory: {dir_path}")

        results = []
        for fp in sorted(dir_path.glob(f"*{EBOX_EXT}")):
            if fp.is_file():
                try:
                    out = self.decrypt_file(fp, key_id=key_id, remove_encrypted=remove_encrypted)
                    results.append(out)
                except Exception:
                    continue
        return results

    def status(self) -> dict:
        """Get keystore status."""
        if not self.keystore.is_initialized:
            return {"initialized": False}

        keys = self.keystore.list_keys()
        try:
            default_id = self.keystore.get_default_key_id()
        except ValueError:
            default_id = None

        audit_valid, audit_msg = self.audit.verify_chain()

        return {
            "initialized": True,
            "total_keys": len(keys),
            "active_keys": sum(1 for k in keys if k.is_active),
            "default_key": default_id,
            "audit_entries": self.audit.entry_count(),
            "audit_valid": audit_valid,
            "audit_message": audit_msg,
        }
