"""CLI interface using Click."""

from __future__ import annotations

import json
import sys
import time
from datetime import datetime
from pathlib import Path

import click

from .operations import EncryptboxOps

# Use ASCII-safe markers to avoid UnicodeEncodeError on non-UTF-8 terminals (e.g. cp949)
_OK = "[OK]"
_ERR = "[ERROR]"


def _get_ops(ctx: click.Context) -> EncryptboxOps:
    """Get or create the EncryptboxOps instance."""
    root = ctx.obj.get("root", Path.cwd())
    return EncryptboxOps(root)


@click.group()
@click.option(
    "--root", "-r",
    type=click.Path(exists=True, file_okay=False, resolve_path=True),
    default=".",
    help="Project root directory (default: current directory).",
)
@click.version_option(package_name="encryptbox")
@click.pass_context
def cli(ctx: click.Context, root: str) -> None:
    """encryptbox - Encrypt files with envelope encryption, key rotation, and audit logging."""
    ctx.ensure_object(dict)
    ctx.obj["root"] = Path(root)


@cli.command()
@click.pass_context
def init(ctx: click.Context) -> None:
    """Initialize the keystore in the current directory."""
    ops = _get_ops(ctx)
    try:
        msg = ops.init()
        click.echo(f"{_OK} {msg}")
        click.echo(f"  Keystore created at: {ops.keystore.store_dir}")
        click.echo("  Run 'encryptbox keygen' to generate your first keypair.")
    except FileExistsError:
        click.echo(f"{_ERR} Keystore already initialized.", err=True)
        sys.exit(1)


@cli.command()
@click.option("--label", "-l", default="", help="Optional label for the key.")
@click.pass_context
def keygen(ctx: click.Context, label: str) -> None:
    """Generate a new encryption keypair."""
    ops = _get_ops(ctx)
    try:
        key_id, msg = ops.keygen(label=label)
        click.echo(f"{_OK} {msg}")
        if label:
            click.echo(f"  Label: {label}")
        click.echo(f"  Key ID: {key_id}")
    except FileNotFoundError as e:
        click.echo(f"{_ERR} {e}", err=True)
        sys.exit(1)


@cli.command()
@click.argument("file", type=click.Path(exists=True))
@click.option("--output", "-o", type=click.Path(), default=None, help="Output file path.")
@click.option("--key", "-k", multiple=True, help="Recipient key ID (can specify multiple).")
@click.option("--remove", is_flag=True, help="Remove original file after encryption.")
@click.pass_context
def encrypt(ctx: click.Context, file: str, output: str | None, key: tuple[str, ...], remove: bool) -> None:
    """Encrypt a file."""
    ops = _get_ops(ctx)
    key_ids = list(key) if key else None
    try:
        out = ops.encrypt_file(file, output_path=output, key_ids=key_ids, remove_original=remove)
        click.echo(f"{_OK} Encrypted: {file}")
        click.echo(f"  Output: {out}")
    except Exception as e:
        click.echo(f"{_ERR} {e}", err=True)
        sys.exit(1)


@cli.command()
@click.argument("file", type=click.Path(exists=True))
@click.option("--output", "-o", type=click.Path(), default=None, help="Output file path.")
@click.option("--key", "-k", default=None, help="Key ID to use for decryption.")
@click.option("--remove", is_flag=True, help="Remove encrypted file after decryption.")
@click.pass_context
def decrypt(ctx: click.Context, file: str, output: str | None, key: str | None, remove: bool) -> None:
    """Decrypt a file."""
    ops = _get_ops(ctx)
    try:
        out = ops.decrypt_file(file, output_path=output, key_id=key, remove_encrypted=remove)
        click.echo(f"{_OK} Decrypted: {file}")
        click.echo(f"  Output: {out}")
    except Exception as e:
        click.echo(f"{_ERR} {e}", err=True)
        sys.exit(1)


@cli.command()
@click.pass_context
def rotate(ctx: click.Context) -> None:
    """Rotate the master key and re-wrap all encrypted files."""
    ops = _get_ops(ctx)
    try:
        old_id, new_id, count = ops.rotate_keys()
        click.echo(f"{_OK} Key rotated")
        click.echo(f"  Old key: {old_id} (deactivated)")
        click.echo(f"  New key: {new_id} (active)")
        click.echo(f"  Files re-wrapped: {count}")
    except Exception as e:
        click.echo(f"{_ERR} {e}", err=True)
        sys.exit(1)


@cli.command()
@click.option("--verify", is_flag=True, help="Verify audit log integrity.")
@click.option("--json-output", "json_out", is_flag=True, help="Output as JSON.")
@click.option("--last", "-n", default=0, type=int, help="Show last N entries.")
@click.pass_context
def audit(ctx: click.Context, verify: bool, json_out: bool, last: int) -> None:
    """Show the audit log."""
    ops = _get_ops(ctx)

    if verify:
        valid, msg = ops.audit.verify_chain()
        if valid:
            click.echo(f"{_OK} {msg}")
        else:
            click.echo(f"{_ERR} {msg}", err=True)
            sys.exit(1)
        return

    entries = ops.audit.read_all()
    if last > 0:
        entries = entries[-last:]

    if json_out:
        for entry in entries:
            click.echo(json.dumps(entry.to_dict()))
        return

    if not entries:
        click.echo("No audit entries.")
        return

    for entry in entries:
        ts = datetime.fromtimestamp(entry.timestamp).strftime("%Y-%m-%d %H:%M:%S")
        parts = [f"[{ts}]", entry.action.upper()]
        if entry.key_id:
            parts.append(f"key={entry.key_id}")
        if entry.file_path:
            parts.append(entry.file_path)
        if entry.user:
            parts.append(f"(by {entry.user})")
        click.echo("  ".join(parts))


@cli.command()
@click.pass_context
def status(ctx: click.Context) -> None:
    """Show keystore status."""
    ops = _get_ops(ctx)
    st = ops.status()

    if not st["initialized"]:
        click.echo("Keystore not initialized. Run 'encryptbox init'.")
        return

    click.echo("Keystore Status:")
    click.echo(f"  Keys: {st['total_keys']} total, {st['active_keys']} active")
    click.echo(f"  Default key: {st['default_key'] or 'none'}")
    click.echo(f"  Audit entries: {st['audit_entries']}")
    integrity = f"{_OK} valid" if st["audit_valid"] else f"{_ERR} INVALID"
    click.echo(f"  Audit integrity: {integrity}")


@cli.command("encrypt-dir")
@click.argument("directory", type=click.Path(exists=True, file_okay=False))
@click.option("--pattern", "-p", default="*", help="Glob pattern for files.")
@click.option("--key", "-k", multiple=True, help="Recipient key ID.")
@click.option("--remove", is_flag=True, help="Remove originals after encryption.")
@click.pass_context
def encrypt_dir(ctx: click.Context, directory: str, pattern: str, key: tuple[str, ...], remove: bool) -> None:
    """Encrypt all files in a directory."""
    ops = _get_ops(ctx)
    key_ids = list(key) if key else None
    try:
        results = ops.encrypt_directory(directory, key_ids=key_ids, pattern=pattern, remove_originals=remove)
        click.echo(f"{_OK} Encrypted {len(results)} files in {directory}")
        for r in results:
            click.echo(f"  {r}")
    except Exception as e:
        click.echo(f"{_ERR} {e}", err=True)
        sys.exit(1)


@cli.command("decrypt-dir")
@click.argument("directory", type=click.Path(exists=True, file_okay=False))
@click.option("--key", "-k", default=None, help="Key ID to use.")
@click.option("--remove", is_flag=True, help="Remove encrypted files after decryption.")
@click.pass_context
def decrypt_dir(ctx: click.Context, directory: str, key: str | None, remove: bool) -> None:
    """Decrypt all .ebox files in a directory."""
    ops = _get_ops(ctx)
    try:
        results = ops.decrypt_directory(directory, key_id=key, remove_encrypted=remove)
        click.echo(f"{_OK} Decrypted {len(results)} files in {directory}")
        for r in results:
            click.echo(f"  {r}")
    except Exception as e:
        click.echo(f"{_ERR} {e}", err=True)
        sys.exit(1)


@cli.command("export-key")
@click.option("--key", "-k", default=None, help="Key ID to export (default: default key).")
@click.pass_context
def export_key(ctx: click.Context, key: str | None) -> None:
    """Export a public key (hex-encoded)."""
    ops = _get_ops(ctx)
    try:
        kid = key or ops.keystore.get_default_key_id()
        raw = ops.keystore.export_public_key(kid)
        click.echo(f"Key ID: {kid}")
        click.echo(f"Public key: {raw.hex()}")
    except Exception as e:
        click.echo(f"{_ERR} {e}", err=True)
        sys.exit(1)


@cli.command("import-key")
@click.argument("public_key_hex")
@click.option("--id", "key_id", required=True, help="Key ID to assign.")
@click.pass_context
def import_key(ctx: click.Context, public_key_hex: str, key_id: str) -> None:
    """Import a public key from hex."""
    ops = _get_ops(ctx)
    try:
        raw = bytes.fromhex(public_key_hex)
        ops.keystore.import_public_key(key_id, raw)
        click.echo(f"{_OK} Imported public key: {key_id}")
    except Exception as e:
        click.echo(f"{_ERR} {e}", err=True)
        sys.exit(1)


def main() -> None:
    """Entry point."""
    cli()


if __name__ == "__main__":
    main()
