"""Envelope encryption: encrypt files with data keys wrapped by master keys.

File format (.ebox):
    MAGIC (4 bytes) || VERSION (1 byte) || num_recipients (2 bytes) ||
    for each recipient:
        key_id_len (1 byte) || key_id || wrapped_key_len (4 bytes) || wrapped_key
    || encrypted_data (nonce || ciphertext)
"""

from __future__ import annotations

import hashlib
import struct
from dataclasses import dataclass
from pathlib import Path

from cryptography.hazmat.primitives.asymmetric.x25519 import (
    X25519PrivateKey,
    X25519PublicKey,
)

from .crypto import (
    MAGIC,
    VERSION,
    EncryptedBlob,
    WrappedKey,
    decrypt_data,
    encrypt_data,
    generate_data_key,
    unwrap_key,
    wrap_key,
)

EBOX_EXT = ".ebox"


@dataclass(frozen=True)
class RecipientEntry:
    """A wrapped data key for a specific recipient."""

    key_id: str
    wrapped_key: WrappedKey


@dataclass(frozen=True)
class EncryptedFile:
    """Complete encrypted file with envelope metadata."""

    recipients: list[RecipientEntry]
    encrypted_data: EncryptedBlob
    original_hash: bytes  # SHA-256 of original plaintext

    def serialize(self) -> bytes:
        """Serialize to the .ebox binary format."""
        parts: list[bytes] = []

        # Header
        parts.append(MAGIC)
        parts.append(struct.pack("B", VERSION))
        parts.append(struct.pack("<H", len(self.recipients)))

        # Recipient entries
        for entry in self.recipients:
            key_id_bytes = entry.key_id.encode("utf-8")
            parts.append(struct.pack("B", len(key_id_bytes)))
            parts.append(key_id_bytes)

            wrapped_data = entry.wrapped_key.serialize()
            parts.append(struct.pack("<I", len(wrapped_data)))
            parts.append(wrapped_data)

        # Original hash
        parts.append(self.original_hash)

        # Encrypted data
        parts.append(self.encrypted_data.serialize())

        return b"".join(parts)

    @classmethod
    def deserialize(cls, data: bytes) -> "EncryptedFile":
        """Deserialize from the .ebox binary format."""
        offset = 0

        # Header
        magic = data[offset : offset + 4]
        offset += 4
        if magic != MAGIC:
            raise ValueError(f"Invalid magic bytes: expected {MAGIC!r}, got {magic!r}")

        (version,) = struct.unpack("B", data[offset : offset + 1])
        offset += 1
        if version != VERSION:
            raise ValueError(f"Unsupported version: {version}")

        (num_recipients,) = struct.unpack("<H", data[offset : offset + 2])
        offset += 2

        # Recipients
        recipients: list[RecipientEntry] = []
        for _ in range(num_recipients):
            (key_id_len,) = struct.unpack("B", data[offset : offset + 1])
            offset += 1
            key_id = data[offset : offset + key_id_len].decode("utf-8")
            offset += key_id_len

            (wrapped_len,) = struct.unpack("<I", data[offset : offset + 4])
            offset += 4
            wrapped_data = data[offset : offset + wrapped_len]
            offset += wrapped_len

            # Parse WrappedKey from wrapped_data
            (eph_len,) = struct.unpack("<H", wrapped_data[:2])
            ephemeral_public = wrapped_data[2 : 2 + eph_len]
            encrypted_data_key = wrapped_data[2 + eph_len :]

            wrapped_key = WrappedKey(
                ephemeral_public=ephemeral_public,
                encrypted_data_key=encrypted_data_key,
            )
            recipients.append(RecipientEntry(key_id=key_id, wrapped_key=wrapped_key))

        # Original hash (SHA-256 = 32 bytes)
        original_hash = data[offset : offset + 32]
        offset += 32

        # Encrypted data
        encrypted_data = EncryptedBlob.deserialize(data[offset:])

        return cls(
            recipients=recipients,
            encrypted_data=encrypted_data,
            original_hash=original_hash,
        )


def encrypt_file_envelope(
    plaintext: bytes,
    recipient_keys: list[tuple[str, X25519PublicKey]],
) -> EncryptedFile:
    """Encrypt data using envelope encryption.

    Generates a random data key, encrypts the plaintext with AES-256-GCM,
    then wraps the data key for each recipient using X25519.

    Args:
        plaintext: The data to encrypt.
        recipient_keys: List of (key_id, public_key) tuples.

    Returns:
        EncryptedFile ready for serialization.
    """
    if not recipient_keys:
        raise ValueError("At least one recipient is required")

    # Generate random data key
    data_key = generate_data_key()

    # Hash the original plaintext for integrity
    original_hash = hashlib.sha256(plaintext).digest()

    # Encrypt plaintext with data key
    aad = original_hash  # bind hash as additional authenticated data
    encrypted_data = encrypt_data(data_key, plaintext, aad=aad)

    # Wrap data key for each recipient
    recipients = []
    for key_id, public_key in recipient_keys:
        wrapped = wrap_key(public_key, data_key)
        recipients.append(RecipientEntry(key_id=key_id, wrapped_key=wrapped))

    return EncryptedFile(
        recipients=recipients,
        encrypted_data=encrypted_data,
        original_hash=original_hash,
    )


def decrypt_file_envelope(
    encrypted_file: EncryptedFile,
    key_id: str,
    private_key: X25519PrivateKey,
) -> bytes:
    """Decrypt an envelope-encrypted file.

    Finds the wrapped key for the given key_id, unwraps it, then
    decrypts the data.

    Args:
        encrypted_file: The encrypted file to decrypt.
        key_id: The key ID to use for decryption.
        private_key: The private key corresponding to key_id.

    Returns:
        Decrypted plaintext.

    Raises:
        ValueError: If no matching recipient entry found.
    """
    # Find our wrapped key
    wrapped_key = None
    for entry in encrypted_file.recipients:
        if entry.key_id == key_id:
            wrapped_key = entry.wrapped_key
            break

    if wrapped_key is None:
        raise ValueError(f"No wrapped key found for key_id: {key_id}")

    # Unwrap the data key
    data_key = unwrap_key(private_key, wrapped_key)

    # Decrypt the data
    plaintext = decrypt_data(data_key, encrypted_file.encrypted_data, aad=encrypted_file.original_hash)

    # Verify hash
    actual_hash = hashlib.sha256(plaintext).digest()
    if actual_hash != encrypted_file.original_hash:
        raise ValueError("Integrity check failed: plaintext hash mismatch")

    return plaintext


def rewrap_for_new_key(
    encrypted_file: EncryptedFile,
    old_key_id: str,
    old_private_key: X25519PrivateKey,
    new_key_id: str,
    new_public_key: X25519PublicKey,
) -> EncryptedFile:
    """Re-wrap a file's data key for a new master key (key rotation).

    Unwraps the data key with the old key, then wraps it for the new key.
    The encrypted data itself is NOT re-encrypted.

    Args:
        encrypted_file: The existing encrypted file.
        old_key_id: The old key ID.
        old_private_key: The old private key.
        new_key_id: The new key ID.
        new_public_key: The new public key.

    Returns:
        New EncryptedFile with the data key wrapped for the new key.
    """
    # Find and unwrap existing data key
    old_wrapped = None
    for entry in encrypted_file.recipients:
        if entry.key_id == old_key_id:
            old_wrapped = entry.wrapped_key
            break

    if old_wrapped is None:
        raise ValueError(f"No wrapped key found for key_id: {old_key_id}")

    data_key = unwrap_key(old_private_key, old_wrapped)

    # Wrap for new key
    new_wrapped = wrap_key(new_public_key, data_key)

    # Build new recipients list: replace old entry with new one
    new_recipients = []
    for entry in encrypted_file.recipients:
        if entry.key_id == old_key_id:
            new_recipients.append(RecipientEntry(key_id=new_key_id, wrapped_key=new_wrapped))
        else:
            new_recipients.append(entry)

    return EncryptedFile(
        recipients=new_recipients,
        encrypted_data=encrypted_file.encrypted_data,
        original_hash=encrypted_file.original_hash,
    )
