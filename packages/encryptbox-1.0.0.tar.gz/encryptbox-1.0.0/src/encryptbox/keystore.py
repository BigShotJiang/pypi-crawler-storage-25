"""Key storage and management.

Manages master keypairs, key metadata, and the keystore directory.
Keys are stored as raw bytes in files with restricted permissions.
"""

from __future__ import annotations

import json
import os
import time
from dataclasses import asdict, dataclass, field
from pathlib import Path
from typing import Iterator

from cryptography.hazmat.primitives.asymmetric.x25519 import (
    X25519PrivateKey,
    X25519PublicKey,
)

from .crypto import generate_keypair

KEYSTORE_DIR = ".encryptbox"
KEYS_DIR = "keys"
CONFIG_FILE = "config.json"
KEY_META_FILE = "meta.json"


@dataclass
class KeyMeta:
    """Metadata for a stored keypair."""

    key_id: str
    created_at: float
    is_active: bool = True
    rotated_at: float | None = None
    label: str = ""

    def to_dict(self) -> dict:
        return asdict(self)

    @classmethod
    def from_dict(cls, d: dict) -> "KeyMeta":
        return cls(**{k: v for k, v in d.items() if k in cls.__dataclass_fields__})


@dataclass
class StoreConfig:
    """Keystore configuration."""

    version: int = 1
    default_key_id: str = ""
    created_at: float = field(default_factory=time.time)

    def to_dict(self) -> dict:
        return asdict(self)

    @classmethod
    def from_dict(cls, d: dict) -> "StoreConfig":
        return cls(**{k: v for k, v in d.items() if k in cls.__dataclass_fields__})


class Keystore:
    """Manages encryption keys on disk.

    Directory structure:
        .encryptbox/
            config.json
            keys/
                <key_id>/
                    private.key
                    public.key
                    meta.json
    """

    def __init__(self, root: Path | str) -> None:
        self.root = Path(root)
        self.store_dir = self.root / KEYSTORE_DIR
        self.keys_dir = self.store_dir / KEYS_DIR
        self._config: StoreConfig | None = None

    @property
    def is_initialized(self) -> bool:
        return (self.store_dir / CONFIG_FILE).exists()

    def init(self) -> StoreConfig:
        """Initialize the keystore directory."""
        if self.is_initialized:
            raise FileExistsError("Keystore already initialized")

        self.store_dir.mkdir(parents=True, exist_ok=True)
        self.keys_dir.mkdir(parents=True, exist_ok=True)

        config = StoreConfig()
        self._write_config(config)
        self._config = config
        return config

    def _write_config(self, config: StoreConfig) -> None:
        config_path = self.store_dir / CONFIG_FILE
        config_path.write_text(json.dumps(config.to_dict(), indent=2))

    def _read_config(self) -> StoreConfig:
        config_path = self.store_dir / CONFIG_FILE
        if not config_path.exists():
            raise FileNotFoundError("Keystore not initialized — run 'encryptbox init'")
        data = json.loads(config_path.read_text())
        return StoreConfig.from_dict(data)

    @property
    def config(self) -> StoreConfig:
        if self._config is None:
            self._config = self._read_config()
        return self._config

    def _key_dir(self, key_id: str) -> Path:
        return self.keys_dir / key_id

    def generate_key(self, label: str = "") -> tuple[str, X25519PublicKey]:
        """Generate a new keypair, store it, and return (key_id, public_key).

        The first key generated becomes the default (active) key.
        """
        if not self.is_initialized:
            raise FileNotFoundError("Keystore not initialized — run 'encryptbox init'")

        private_key, public_key = generate_keypair()
        key_id = public_key.public_bytes_raw().hex()[:16]

        key_dir = self._key_dir(key_id)
        key_dir.mkdir(parents=True, exist_ok=True)

        # Write private key
        priv_path = key_dir / "private.key"
        priv_path.write_bytes(private_key.private_bytes_raw())

        # Write public key
        pub_path = key_dir / "public.key"
        pub_path.write_bytes(public_key.public_bytes_raw())

        # Write metadata
        meta = KeyMeta(key_id=key_id, created_at=time.time(), label=label)
        meta_path = key_dir / KEY_META_FILE
        meta_path.write_text(json.dumps(meta.to_dict(), indent=2))

        # Set as default if first key
        config = self._read_config()
        if not config.default_key_id:
            config.default_key_id = key_id
            self._write_config(config)
            self._config = config

        return key_id, public_key

    def get_private_key(self, key_id: str) -> X25519PrivateKey:
        """Load a private key by ID."""
        key_dir = self._key_dir(key_id)
        priv_path = key_dir / "private.key"
        if not priv_path.exists():
            raise FileNotFoundError(f"Private key not found: {key_id}")
        raw = priv_path.read_bytes()
        return X25519PrivateKey.from_private_bytes(raw)

    def get_public_key(self, key_id: str) -> X25519PublicKey:
        """Load a public key by ID."""
        key_dir = self._key_dir(key_id)
        pub_path = key_dir / "public.key"
        if not pub_path.exists():
            raise FileNotFoundError(f"Public key not found: {key_id}")
        raw = pub_path.read_bytes()
        return X25519PublicKey.from_public_bytes(raw)

    def get_key_meta(self, key_id: str) -> KeyMeta:
        """Load key metadata."""
        key_dir = self._key_dir(key_id)
        meta_path = key_dir / KEY_META_FILE
        if not meta_path.exists():
            raise FileNotFoundError(f"Key metadata not found: {key_id}")
        data = json.loads(meta_path.read_text())
        return KeyMeta.from_dict(data)

    def _update_key_meta(self, key_id: str, meta: KeyMeta) -> None:
        """Update key metadata on disk."""
        key_dir = self._key_dir(key_id)
        meta_path = key_dir / KEY_META_FILE
        meta_path.write_text(json.dumps(meta.to_dict(), indent=2))

    def get_default_key_id(self) -> str:
        """Return the current default key ID."""
        config = self._read_config()
        if not config.default_key_id:
            raise ValueError("No default key set — run 'encryptbox keygen'")
        return config.default_key_id

    def set_default_key(self, key_id: str) -> None:
        """Set the default key."""
        if not self._key_dir(key_id).exists():
            raise FileNotFoundError(f"Key not found: {key_id}")
        config = self._read_config()
        config.default_key_id = key_id
        self._write_config(config)
        self._config = config

    def list_keys(self) -> list[KeyMeta]:
        """List all stored keys with metadata."""
        if not self.keys_dir.exists():
            return []
        result = []
        for key_dir in sorted(self.keys_dir.iterdir()):
            if key_dir.is_dir():
                meta_path = key_dir / KEY_META_FILE
                if meta_path.exists():
                    data = json.loads(meta_path.read_text())
                    result.append(KeyMeta.from_dict(data))
        return result

    def deactivate_key(self, key_id: str) -> None:
        """Mark a key as inactive (after rotation)."""
        meta = self.get_key_meta(key_id)
        meta = KeyMeta(
            key_id=meta.key_id,
            created_at=meta.created_at,
            is_active=False,
            rotated_at=time.time(),
            label=meta.label,
        )
        self._update_key_meta(key_id, meta)

    def import_public_key(self, key_id: str, public_key_bytes: bytes) -> None:
        """Import a public key (for multi-recipient encryption)."""
        if not self.is_initialized:
            raise FileNotFoundError("Keystore not initialized")

        key_dir = self._key_dir(key_id)
        key_dir.mkdir(parents=True, exist_ok=True)

        pub_path = key_dir / "public.key"
        pub_path.write_bytes(public_key_bytes)

        meta = KeyMeta(key_id=key_id, created_at=time.time(), label="imported")
        meta_path = key_dir / KEY_META_FILE
        meta_path.write_text(json.dumps(meta.to_dict(), indent=2))

    def export_public_key(self, key_id: str) -> bytes:
        """Export a public key as raw bytes."""
        return self.get_public_key(key_id).public_bytes_raw()
