"""Core cryptographic operations using pyca/cryptography.

Provides AES-256-GCM symmetric encryption and X25519 key wrapping
for envelope encryption.
"""

from __future__ import annotations

import os
import struct
from dataclasses import dataclass

from cryptography.hazmat.primitives.asymmetric.x25519 import (
    X25519PrivateKey,
    X25519PublicKey,
)
from cryptography.hazmat.primitives.ciphers.aead import AESGCM
from cryptography.hazmat.primitives.hashes import SHA256
from cryptography.hazmat.primitives.kdf.hkdf import HKDF

# Constants
AES_KEY_SIZE = 32  # 256 bits
NONCE_SIZE = 12  # 96 bits for AES-GCM
TAG_SIZE = 16  # 128-bit authentication tag (included by AESGCM)

# Header magic bytes for encrypted files
MAGIC = b"EBOX"
VERSION = 1


@dataclass(frozen=True)
class EncryptedBlob:
    """An encrypted payload with all metadata needed for decryption."""

    nonce: bytes  # 12 bytes
    ciphertext: bytes  # includes GCM tag

    def serialize(self) -> bytes:
        """Serialize to bytes: nonce || ciphertext."""
        return self.nonce + self.ciphertext

    @classmethod
    def deserialize(cls, data: bytes) -> "EncryptedBlob":
        """Deserialize from bytes."""
        if len(data) < NONCE_SIZE + TAG_SIZE:
            raise ValueError("Data too short to be a valid encrypted blob")
        return cls(nonce=data[:NONCE_SIZE], ciphertext=data[NONCE_SIZE:])


@dataclass(frozen=True)
class WrappedKey:
    """A data key wrapped (encrypted) with a recipient's public key."""

    ephemeral_public: bytes  # 32-byte X25519 public key
    encrypted_data_key: bytes  # nonce || ciphertext of the wrapped data key

    def serialize(self) -> bytes:
        """Serialize: len(ephemeral) || ephemeral || encrypted_data_key."""
        return (
            struct.pack("<H", len(self.ephemeral_public))
            + self.ephemeral_public
            + self.encrypted_data_key
        )

    @classmethod
    def deserialize(cls, data: bytes) -> tuple["WrappedKey", int]:
        """Deserialize and return (WrappedKey, bytes_consumed)."""
        if len(data) < 2:
            raise ValueError("Data too short for WrappedKey")
        (eph_len,) = struct.unpack("<H", data[:2])
        offset = 2
        ephemeral_public = data[offset : offset + eph_len]
        offset += eph_len
        encrypted_data_key = data[offset:]
        return cls(ephemeral_public=ephemeral_public, encrypted_data_key=encrypted_data_key), len(data)


def generate_data_key() -> bytes:
    """Generate a random 256-bit data key using CSPRNG."""
    return os.urandom(AES_KEY_SIZE)


def encrypt_data(key: bytes, plaintext: bytes, aad: bytes | None = None) -> EncryptedBlob:
    """Encrypt plaintext with AES-256-GCM.

    Args:
        key: 32-byte AES key.
        plaintext: Data to encrypt.
        aad: Optional additional authenticated data.

    Returns:
        EncryptedBlob with nonce and ciphertext (includes GCM tag).
    """
    if len(key) != AES_KEY_SIZE:
        raise ValueError(f"Key must be {AES_KEY_SIZE} bytes, got {len(key)}")

    nonce = os.urandom(NONCE_SIZE)
    aesgcm = AESGCM(key)
    ciphertext = aesgcm.encrypt(nonce, plaintext, aad)
    return EncryptedBlob(nonce=nonce, ciphertext=ciphertext)


def decrypt_data(key: bytes, blob: EncryptedBlob, aad: bytes | None = None) -> bytes:
    """Decrypt an EncryptedBlob with AES-256-GCM.

    Args:
        key: 32-byte AES key.
        blob: The encrypted blob.
        aad: Optional additional authenticated data (must match encrypt).

    Returns:
        Decrypted plaintext.
    """
    if len(key) != AES_KEY_SIZE:
        raise ValueError(f"Key must be {AES_KEY_SIZE} bytes, got {len(key)}")

    aesgcm = AESGCM(key)
    return aesgcm.decrypt(blob.nonce, blob.ciphertext, aad)


def _derive_wrapping_key(shared_secret: bytes, info: bytes = b"encryptbox-wrap") -> bytes:
    """Derive a wrapping key from an X25519 shared secret using HKDF."""
    hkdf = HKDF(
        algorithm=SHA256(),
        length=AES_KEY_SIZE,
        salt=None,
        info=info,
    )
    return hkdf.derive(shared_secret)


def wrap_key(recipient_public: X25519PublicKey, data_key: bytes) -> WrappedKey:
    """Wrap a data key for a recipient using X25519 + HKDF + AES-256-GCM.

    Generates an ephemeral X25519 keypair, performs key exchange with the
    recipient's public key, derives a wrapping key via HKDF, and encrypts
    the data key.

    Args:
        recipient_public: Recipient's X25519 public key.
        data_key: The data key to wrap.

    Returns:
        WrappedKey containing ephemeral public key and encrypted data key.
    """
    ephemeral_private = X25519PrivateKey.generate()
    ephemeral_public = ephemeral_private.public_key()

    shared_secret = ephemeral_private.exchange(recipient_public)
    wrapping_key = _derive_wrapping_key(shared_secret)

    blob = encrypt_data(wrapping_key, data_key)

    return WrappedKey(
        ephemeral_public=ephemeral_public.public_bytes_raw(),
        encrypted_data_key=blob.serialize(),
    )


def unwrap_key(recipient_private: X25519PrivateKey, wrapped: WrappedKey) -> bytes:
    """Unwrap a data key using the recipient's private key.

    Args:
        recipient_private: Recipient's X25519 private key.
        wrapped: The wrapped key to unwrap.

    Returns:
        The unwrapped data key.
    """
    ephemeral_public = X25519PublicKey.from_public_bytes(wrapped.ephemeral_public)

    shared_secret = recipient_private.exchange(ephemeral_public)
    wrapping_key = _derive_wrapping_key(shared_secret)

    blob = EncryptedBlob.deserialize(wrapped.encrypted_data_key)
    return decrypt_data(wrapping_key, blob)


def generate_keypair() -> tuple[X25519PrivateKey, X25519PublicKey]:
    """Generate a new X25519 keypair."""
    private_key = X25519PrivateKey.generate()
    public_key = private_key.public_key()
    return private_key, public_key
