"""Append-only, tamper-evident audit log.

Each log entry is a JSON line with a chained HMAC.
The HMAC of each entry includes the previous entry's HMAC,
forming a hash chain that detects tampering or deletion.
"""

from __future__ import annotations

import hashlib
import hmac
import json
import os
import time
from dataclasses import asdict, dataclass
from pathlib import Path
from typing import Any

AUDIT_LOG_FILE = "audit.jsonl"
AUDIT_SECRET_FILE = "audit.secret"

# Chain seed for the first entry
CHAIN_SEED = "encryptbox-audit-chain-v1"


@dataclass
class AuditEntry:
    """A single audit log entry."""

    timestamp: float
    action: str  # encrypt, decrypt, rotate, keygen, init
    key_id: str
    file_path: str
    file_hash: str  # SHA-256 hex of the file
    user: str
    details: dict[str, Any]
    prev_hmac: str  # HMAC of the previous entry (chain)
    entry_hmac: str  # HMAC of this entry

    def to_dict(self) -> dict:
        return asdict(self)

    @classmethod
    def from_dict(cls, d: dict) -> "AuditEntry":
        return cls(**{k: v for k, v in d.items() if k in cls.__dataclass_fields__})


class AuditLog:
    """Append-only audit log with tamper detection via HMAC chaining."""

    def __init__(self, store_dir: Path) -> None:
        self.store_dir = store_dir
        self.log_path = store_dir / AUDIT_LOG_FILE
        self.secret_path = store_dir / AUDIT_SECRET_FILE
        self._secret: bytes | None = None

    @property
    def secret(self) -> bytes:
        """Load or generate the HMAC secret."""
        if self._secret is None:
            if self.secret_path.exists():
                self._secret = self.secret_path.read_bytes()
            else:
                self._secret = os.urandom(32)
                self.secret_path.write_bytes(self._secret)
        return self._secret

    def _compute_hmac(self, data: str) -> str:
        """Compute HMAC-SHA256 of data."""
        return hmac.new(self.secret, data.encode("utf-8"), hashlib.sha256).hexdigest()

    def _get_last_hmac(self) -> str:
        """Get the HMAC of the last log entry, or the chain seed."""
        if not self.log_path.exists():
            return self._compute_hmac(CHAIN_SEED)

        last_line = ""
        with open(self.log_path, "r") as f:
            for line in f:
                line = line.strip()
                if line:
                    last_line = line

        if not last_line:
            return self._compute_hmac(CHAIN_SEED)

        entry_data = json.loads(last_line)
        return entry_data.get("entry_hmac", self._compute_hmac(CHAIN_SEED))

    def _make_entry_payload(self, action: str, key_id: str, file_path: str,
                            file_hash: str, user: str, details: dict,
                            prev_hmac: str) -> str:
        """Create the canonical string to HMAC for an entry."""
        parts = [
            action, key_id, file_path, file_hash, user,
            json.dumps(details, sort_keys=True), prev_hmac,
        ]
        return "|".join(parts)

    def log(
        self,
        action: str,
        key_id: str = "",
        file_path: str = "",
        file_hash: str = "",
        user: str = "",
        details: dict[str, Any] | None = None,
    ) -> AuditEntry:
        """Append an entry to the audit log.

        Args:
            action: The action performed (encrypt, decrypt, rotate, etc.).
            key_id: The key ID used.
            file_path: The file involved.
            file_hash: SHA-256 hex of the file.
            user: The user who performed the action.
            details: Additional details.

        Returns:
            The logged AuditEntry.
        """
        if details is None:
            details = {}

        prev_hmac = self._get_last_hmac()

        payload = self._make_entry_payload(
            action, key_id, file_path, file_hash, user, details, prev_hmac
        )
        entry_hmac = self._compute_hmac(payload)

        entry = AuditEntry(
            timestamp=time.time(),
            action=action,
            key_id=key_id,
            file_path=file_path,
            file_hash=file_hash,
            user=user,
            details=details,
            prev_hmac=prev_hmac,
            entry_hmac=entry_hmac,
        )

        self.store_dir.mkdir(parents=True, exist_ok=True)
        with open(self.log_path, "a") as f:
            f.write(json.dumps(entry.to_dict()) + "\n")

        return entry

    def read_all(self) -> list[AuditEntry]:
        """Read all audit log entries."""
        if not self.log_path.exists():
            return []

        entries = []
        with open(self.log_path, "r") as f:
            for line in f:
                line = line.strip()
                if line:
                    entries.append(AuditEntry.from_dict(json.loads(line)))
        return entries

    def verify_chain(self) -> tuple[bool, str]:
        """Verify the integrity of the audit log chain.

        Returns:
            (is_valid, message) tuple.
        """
        entries = self.read_all()
        if not entries:
            return True, "Audit log is empty"

        expected_prev = self._compute_hmac(CHAIN_SEED)

        for i, entry in enumerate(entries):
            # Verify prev_hmac chain (constant-time comparison)
            if not hmac.compare_digest(entry.prev_hmac, expected_prev):
                return False, f"Chain broken at entry {i}: prev_hmac mismatch"

            # Verify entry_hmac (constant-time comparison)
            payload = self._make_entry_payload(
                entry.action, entry.key_id, entry.file_path,
                entry.file_hash, entry.user, entry.details, entry.prev_hmac
            )
            computed = self._compute_hmac(payload)
            if not hmac.compare_digest(entry.entry_hmac, computed):
                return False, f"Tampered entry at index {i}: HMAC mismatch"

            expected_prev = entry.entry_hmac

        return True, f"All {len(entries)} entries verified"

    def entry_count(self) -> int:
        """Count entries without loading all data."""
        if not self.log_path.exists():
            return 0
        count = 0
        with open(self.log_path, "r") as f:
            for line in f:
                if line.strip():
                    count += 1
        return count
