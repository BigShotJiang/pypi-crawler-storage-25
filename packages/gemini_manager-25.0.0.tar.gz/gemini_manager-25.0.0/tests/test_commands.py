# tests/test_commands.py

import pytest
from unittest.mock import patch, mock_open, MagicMock
import subprocess
import os
import sys

# Import commands individually
from gemini_manager.utils import run, read_file
from gemini_manager.reset_helpers import run_cmd_safe, save_reset_time_from_output
from gemini_manager.config import LOGIN_URL_PATH

# --- Tests for Reset Helpers ---
