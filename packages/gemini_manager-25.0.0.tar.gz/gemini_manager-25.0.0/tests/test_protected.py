import os
import pytest
from gemini_manager.protected import (
    PROTECTED_DIRS,
    copytree_excluding_protected,
    get_tar_excludes,
    get_diff_excludes,
    is_protected,
    remove_protected_children,
    ProtectedPathManager
)

def test_excludes_formatting():
    tar_excludes = get_tar_excludes()
    diff_excludes = get_diff_excludes()

    for name in PROTECTED_DIRS:
        assert f"--exclude={name}" in tar_excludes
        assert f"-x {name}" in diff_excludes

def test_is_protected():
    for name in PROTECTED_DIRS:
        assert is_protected(name) is True
    assert is_protected("tmp") is False
    assert is_protected("history") is False
    assert is_protected(".tmp") is False

def test_protected_path_manager_lifecycle(fs):
    target_dir = "/home/user/.gemini"
    fs.create_dir(target_dir)

    # Create a protected dir
    protected_dir = os.path.join(target_dir, PROTECTED_DIRS[0])
    fs.create_dir(protected_dir)
    fs.create_file(os.path.join(protected_dir, "data.txt"), contents="keep me")

    # Create some unprotected data
    fs.create_file(os.path.join(target_dir, "unprotected.txt"), contents="delete me")

    mgr = ProtectedPathManager(target_dir)

    # 1. Park protected paths
    mgr.park_protected_paths()

    # Assert protected dir is gone from target
    assert not os.path.exists(protected_dir)

    # Assert unprotected is still there
    assert os.path.exists(os.path.join(target_dir, "unprotected.txt"))

    # Assert parked path exists elsewhere
    parked_path = mgr.parked_paths[PROTECTED_DIRS[0]]
    assert os.path.exists(parked_path)
    assert os.path.exists(os.path.join(parked_path, "data.txt"))

    # Simulate a wipe of target_dir
    import shutil
    shutil.rmtree(target_dir)
    assert not os.path.exists(target_dir)

    # 2. Restore protected paths
    mgr.restore_protected_paths()

    # Target dir should be recreated just for the protected paths
    assert os.path.exists(target_dir)
    assert os.path.exists(protected_dir)
    assert os.path.exists(os.path.join(protected_dir, "data.txt"))

    # The unprotected file we deleted should be gone
    assert not os.path.exists(os.path.join(target_dir, "unprotected.txt"))

    # Parked paths dict should be cleared
    assert len(mgr.parked_paths) == 0

def test_protected_path_manager_cleanup(fs):
    target_dir = "/home/user/.gemini"
    fs.create_dir(target_dir)

    protected_dir = os.path.join(target_dir, PROTECTED_DIRS[0])
    fs.create_dir(protected_dir)
    fs.create_file(os.path.join(protected_dir, "data.txt"), contents="keep me")

    mgr = ProtectedPathManager(target_dir)

    # 1. Park protected paths
    mgr.park_protected_paths()

    parked_path = mgr.parked_paths[PROTECTED_DIRS[0]]
    assert os.path.exists(parked_path)

    # 2. Cleanup (e.g. abort during restore, or exception)
    mgr.cleanup()

    assert not os.path.exists(parked_path)
    assert len(mgr.parked_paths) == 0

def test_copytree_excluding_protected_skips_antigravity(fs):
    src = "/tmp/src"
    dst = "/tmp/dst"
    fs.create_dir(src)
    fs.create_file(os.path.join(src, "keep.txt"), contents="keep")
    protected_dir = os.path.join(src, "antigravity-cli")
    fs.create_dir(protected_dir)
    fs.create_file(os.path.join(protected_dir, "state.json"), contents="do not copy")

    copytree_excluding_protected(src, dst)

    assert os.path.exists(os.path.join(dst, "keep.txt"))
    assert not os.path.exists(os.path.join(dst, "antigravity-cli"))

def test_remove_protected_children_only_removes_top_level_protected(fs):
    root = "/tmp/tree"
    fs.create_dir(root)
    protected_dir = os.path.join(root, "antigravity-cli")
    fs.create_dir(protected_dir)
    fs.create_file(os.path.join(protected_dir, "state.json"), contents="remove")
    nested = os.path.join(root, "tmp", "antigravity-cli")
    fs.create_dir(nested)
    fs.create_file(os.path.join(nested, "state.json"), contents="keep")

    remove_protected_children(root)

    assert not os.path.exists(protected_dir)
    assert os.path.exists(nested)
