import os
import json
import pytest
from gemini_manager.reset_helpers import _save_store, _load_store, RESETS_FILE
from gemini_manager.history import record_event, HISTORY_FILE

def test_reset_pruning(fs):
    """
    Verify that _save_store keeps only 2 entries per email.
    """
    email = "test@example.com"
    entries = [
        {"id": "1", "email": email, "saved_at": "2026-05-16T10:00:00", "reset_ist": "2026-05-16T10:00:00"},
        {"id": "2", "email": email, "saved_at": "2026-05-16T11:00:00", "reset_ist": "2026-05-16T11:00:00"},
        {"id": "3", "email": email, "saved_at": "2026-05-16T12:00:00", "reset_ist": "2026-05-16T12:00:00"},
    ]
    
    _save_store(entries)
    
    saved = _load_store()
    # Should only have the 2 latest: "3" and "2"
    assert len(saved) == 2
    ids = [e["id"] for e in saved]
    assert "3" in ids
    assert "2" in ids
    assert "1" not in ids

def test_history_capping(fs):
    """
    Verify that record_event caps history at 50 events.
    """
    email = "test@example.com"
    
    # Pre-seed with 48 events
    initial_events = [{"timestamp": "2026-01-01T00:00:00Z", "email": email, "event": f"old_{i}"} for i in range(48)]
    os.makedirs(os.path.dirname(HISTORY_FILE), exist_ok=True)
    with open(HISTORY_FILE, "w") as f:
        json.dump(initial_events, f)

    # Add 3 more events (Total 51)
    record_event(email, "event_48")
    record_event(email, "event_49")
    record_event(email, "event_50")
        
    with open(HISTORY_FILE, "r") as f:
        events = json.load(f)
        
    assert len(events) == 50
    # Latest should be event_50
    assert events[-1]["event"] == "event_50"
    # Oldest should now be old_1 (old_0 should be capped)
    assert events[0]["event"] == "old_1"

