import pytest
from gemini_manager.protected import PROTECTED_DIRS, get_tar_excludes, get_diff_excludes, is_protected, ProtectedPathManager

def test_protected_dirs_type():
    assert isinstance(PROTECTED_DIRS, list)
    assert len(PROTECTED_DIRS) > 0

def test_is_protected_exact_match():
    for d in PROTECTED_DIRS:
        assert is_protected(d) is True

def test_is_protected_no_match():
    assert is_protected("not-protected") is False


def test_protected_path_manager_early_return(fs):
    mgr = ProtectedPathManager("/does/not/exist")
    mgr.park_protected_paths()
    assert len(mgr.parked_paths) == 0

def test_protected_path_manager_restore_empty():
    mgr = ProtectedPathManager("/home/user/.gemini")
    mgr.restore_protected_paths()
    assert len(mgr.parked_paths) == 0

def test_protected_path_manager_cleanup_empty():
    mgr = ProtectedPathManager("/home/user/.gemini")
    mgr.cleanup()
    assert len(mgr.parked_paths) == 0
