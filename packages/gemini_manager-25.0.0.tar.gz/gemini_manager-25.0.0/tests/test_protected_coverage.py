import os
import pytest
from gemini_manager.protected import ProtectedPathManager, PROTECTED_DIRS
import shutil

def test_protected_path_manager_cleanup_with_files(fs):
    target_dir = "/home/user/.gemini"
    fs.create_dir(target_dir)

    protected_dir = os.path.join(target_dir, PROTECTED_DIRS[0])
    fs.create_dir(protected_dir)
    fs.create_file(os.path.join(protected_dir, "data.txt"), contents="keep me")

    mgr = ProtectedPathManager(target_dir)

    # 1. Park protected paths
    mgr.park_protected_paths()

    parked_path = mgr.parked_paths.get(PROTECTED_DIRS[0])
    assert parked_path is not None
    assert os.path.exists(parked_path)

    # 2. Cleanup (should restore)
    mgr.cleanup()

    assert not os.path.exists(parked_path)
    assert os.path.exists(protected_dir)
    assert len(mgr.parked_paths) == 0

def test_protected_path_manager_cleanup_with_file_not_dir(fs):
    target_dir = "/home/user/.gemini"
    fs.create_dir(target_dir)

    # What if protected item is a file instead of dir
    protected_file = os.path.join(target_dir, PROTECTED_DIRS[0])
    fs.create_file(protected_file, contents="keep me")

    mgr = ProtectedPathManager(target_dir)

    mgr.park_protected_paths()

    parked_path = mgr.parked_paths.get(PROTECTED_DIRS[0])
    assert parked_path is not None
    assert os.path.exists(parked_path)

    mgr.cleanup()

    assert not os.path.exists(parked_path)
    assert os.path.exists(protected_file)
    assert len(mgr.parked_paths) == 0

def test_protected_path_manager_restore_with_file_not_dir(fs):
    target_dir = "/home/user/.gemini"
    fs.create_dir(target_dir)

    protected_file = os.path.join(target_dir, PROTECTED_DIRS[0])
    fs.create_file(protected_file, contents="keep me")

    mgr = ProtectedPathManager(target_dir)

    mgr.park_protected_paths()

    # Simulate a wipe of target_dir
    shutil.rmtree(target_dir)

    # recreate dest_path as a file to force the remove logic in restore
    fs.create_dir(target_dir)
    fs.create_file(protected_file, contents="dummy")

    mgr.restore_protected_paths()

    assert os.path.exists(protected_file)
    with open(protected_file, "r") as f:
        assert f.read() == "keep me"

def test_protected_path_manager_park_with_existing_tmp_dir(fs):
    target_dir = "/home/user/.gemini"
    fs.create_dir(target_dir)

    protected_dir = os.path.join(target_dir, PROTECTED_DIRS[0])
    fs.create_dir(protected_dir)

    mgr = ProtectedPathManager(target_dir)

    # Pre-create the temp dir to test the cleanup logic in park_protected_paths
    parent_dir = os.path.dirname(os.path.abspath(target_dir))
    target_basename = os.path.basename(os.path.abspath(target_dir))
    safe_dest = os.path.join(parent_dir, f".{target_basename}.{PROTECTED_DIRS[0]}.protected-tmp")
    fs.create_dir(safe_dest)

    mgr.park_protected_paths()

    parked_path = mgr.parked_paths[PROTECTED_DIRS[0]]
    assert os.path.exists(parked_path)

def test_get_tar_excludes():
    from gemini_manager.protected import get_tar_excludes
    excludes = get_tar_excludes()
    assert "--exclude=" in excludes

def test_get_diff_excludes():
    from gemini_manager.protected import get_diff_excludes
    excludes = get_diff_excludes()
    assert "-x " in excludes

def test_protected_path_manager_early_returns(fs):
    from gemini_manager.protected import ProtectedPathManager
    # directory doesn't exist
    mgr = ProtectedPathManager("/home/user/not_exist")
    mgr.park_protected_paths()
    assert len(mgr.parked_paths) == 0

def test_is_protected():
    from gemini_manager.protected import is_protected
    assert is_protected("antigravity-cli")
    assert not is_protected("not-protected")
