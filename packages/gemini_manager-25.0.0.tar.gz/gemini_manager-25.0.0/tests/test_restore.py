# tests/test_restore.py

import pytest
from unittest.mock import patch, MagicMock, ANY
import os
import argparse
import shutil
import tempfile
from gemini_manager import restore
from gemini_manager.restore import perform_restore
from gemini_manager.recommend import Recommendation, AccountStatus

# Fixture to mock the filesystem for all tests in this file
@pytest.fixture(autouse=True)
def fs_setup(fs):
    """Ensure basic directories exist."""
    pass

@patch("gemini_manager.restore.fcntl")
def test_acquire_lock_success(mock_fcntl):
    with patch("gemini_manager.restore.LOCKFILE", "/tmp/restore.lock"):
        fd = restore.acquire_lock()
        assert fd is not None
        mock_fcntl.flock.assert_called()

@patch("gemini_manager.restore.fcntl")
def test_acquire_lock_fail(mock_fcntl):
    with patch("gemini_manager.restore.LOCKFILE", "/tmp/restore.lock"):
        mock_fcntl.flock.side_effect = BlockingIOError
        with pytest.raises(SystemExit) as e:
            restore.acquire_lock()
        assert e.value.code == 2

def test_run():
    with patch("subprocess.run") as mock_run:
        restore.run("ls")
        mock_run.assert_called_with("ls", shell=True, check=True)

def test_parse_timestamp_from_name():
    ts = restore.parse_timestamp_from_name("2025-10-22_042211-test@test.gemini-manager")
    assert ts is not None
    assert ts.tm_year == 2025

    assert restore.parse_timestamp_from_name("invalid") is None

def test_find_oldest_archive_backup(fs):
    backup_dir = "/tmp/backups"
    os.makedirs(backup_dir, exist_ok=True)
    fs.create_file(os.path.join(backup_dir, "2025-10-23_042211-test.gemini-manager.tar.gz"))
    fs.create_file(os.path.join(backup_dir, "2025-10-22_042211-test.gemini-manager.tar.gz"))

    oldest = restore.find_oldest_archive_backup(backup_dir)
    assert "2025-10-22" in oldest

def test_find_oldest_archive_backup_none(fs):
    backup_dir = "/tmp/backups"
    os.makedirs(backup_dir, exist_ok=True)
    assert restore.find_oldest_archive_backup(backup_dir) is None

@patch("gemini_manager.restore.run")
def test_extract_archive(mock_run, fs):
    os.makedirs("/dest", exist_ok=True)
    fs.create_file("/archive.tar.gz")
    restore.extract_archive("/archive.tar.gz", "/dest")
    mock_run.assert_called()

@patch("gemini_manager.restore.acquire_lock")
@patch("gemini_manager.restore.run")
@patch("os.replace")
def test_main_from_dir(mock_replace, mock_run, mock_lock, fs):
    src_dir = "/tmp/backup_source"
    dest_dir = os.path.expanduser("~/.gemini-manager")
    os.makedirs(src_dir, exist_ok=True)
    os.makedirs(dest_dir, exist_ok=True)

    mock_run.return_value.returncode = 0

    with patch("shutil.move"):
        with patch("sys.argv", ["restore.py", "--full", "--from-dir", src_dir]):
            restore.main()

    assert mock_run.call_count >= 1

@patch("gemini_manager.restore.acquire_lock")
@patch("gemini_manager.restore.run")
@patch("os.replace")
def test_main_from_archive(mock_replace, mock_run, mock_lock, fs):
    archive = "/tmp/backup.tar.gz"
    fs.create_file(archive)
    dest_dir = os.path.expanduser("~/.gemini-manager")
    os.makedirs(dest_dir, exist_ok=True)

    mock_run.return_value.returncode = 0

    with patch("sys.argv", ["restore.py", "--full", "--from-archive", archive]):
        restore.main()

@patch("gemini_manager.restore.acquire_lock")
@patch("gemini_manager.restore.find_oldest_archive_backup", return_value="/tmp/oldest.tar.gz")
@patch("gemini_manager.restore.run")
@patch("os.replace")
def test_main_auto_oldest(mock_replace, mock_run, mock_find_oldest, mock_lock, fs):
    fs.create_file("/tmp/oldest.tar.gz")
    dest_dir = os.path.expanduser("~/.gemini-manager")
    os.makedirs(dest_dir, exist_ok=True)

    mock_run.return_value.returncode = 0

    with patch("sys.argv", ["restore.py", "--full"]):
        restore.main()
        mock_find_oldest.assert_called()

@patch("gemini_manager.restore.acquire_lock")
@patch("gemini_manager.restore.get_cloud_provider")
@patch("gemini_manager.restore.run")
@patch("gemini_manager.cooldown._sync_cooldown_file")
@patch("os.replace")
def test_main_cloud(mock_replace, mock_sync, mock_run, mock_get_provider, mock_lock, fs):
    dest_dir = os.path.expanduser("~/.gemini-manager")
    os.makedirs(dest_dir, exist_ok=True)

    with patch("sys.argv", ["restore.py", "--full", "--cloud", "--bucket", "b", "--b2-id", "i", "--b2-key", "k"]):
        mock_file = MagicMock()
        mock_file.name = "2025-10-22_042211-test.gemini-manager.tar.gz"
        mock_get_provider.return_value.list_files.return_value = [mock_file]

        mock_run.return_value.returncode = 0

        # Create temp file so os.remove doesn't fail if called, though we patch it usually
        # But here we want normal execution flow
        temp_path = os.path.join(tempfile.gettempdir(), mock_file.name)
        fs.create_file(temp_path)

        restore.main()
        mock_get_provider.return_value.download_file.assert_called()

@patch("gemini_manager.restore.acquire_lock")
@patch("gemini_manager.restore.run")
def test_main_verification_fail(mock_run, mock_lock, fs):
    archive = "/tmp/archive.tar.gz"
    fs.create_file(archive)
    dest_dir = os.path.expanduser("~/.gemini-manager")
    os.makedirs(dest_dir, exist_ok=True)

    with patch("sys.argv", ["restore.py", "--full", "--from-archive", archive]):
        mock_run.side_effect = [
            MagicMock(returncode=0),
            MagicMock(returncode=1, stdout="diff"),
        ]
        with pytest.raises(SystemExit) as e:
            restore.main()
        assert e.value.code == 3

@patch("gemini_manager.restore.acquire_lock")
@patch("gemini_manager.restore.run")
@patch("os.replace")
def test_main_post_verification_fail(mock_replace, mock_run, mock_lock, fs):
    archive = "/tmp/archive.tar.gz"
    fs.create_file(archive)
    dest_dir = os.path.expanduser("~/.gemini-manager")
    os.makedirs(dest_dir, exist_ok=True)

    with patch("sys.argv", ["restore.py", "--full", "--from-archive", archive]):
        mock_run.side_effect = [
            MagicMock(returncode=0),
            MagicMock(returncode=0),
            MagicMock(returncode=1, stdout="diff"),
        ]
        with pytest.raises(SystemExit) as e:
            restore.main()
        assert e.value.code == 4

@patch("gemini_manager.restore.acquire_lock")
@patch("gemini_manager.restore.run")
def test_main_dry_run(mock_run, mock_lock, fs):
    fs.create_file("/tmp/archive.tar.gz")
    os.makedirs(os.path.expanduser("~/.gemini-manager"), exist_ok=True)

    with patch("sys.argv", ["restore.py", "--full", "--from-archive", "/tmp/archive.tar.gz", "--dry-run"]):
        restore.main()
        mock_run.assert_not_called()

@patch("gemini_manager.restore.acquire_lock")
@patch("gemini_manager.restore.get_cloud_provider")
def test_main_cloud_missing_creds(mock_get_provider, mock_lock, fs):
    with patch("sys.argv", ["restore.py", "--full", "--cloud"]):
        mock_get_provider.return_value = None
        with pytest.raises(SystemExit):
            restore.main()

@patch("gemini_manager.restore.acquire_lock")
@patch("gemini_manager.restore.get_cloud_provider")
def test_main_cloud_no_backups(mock_get_provider, mock_lock, fs):
    with patch("sys.argv", ["restore.py", "--full", "--cloud", "--bucket", "b", "--b2-id", "i", "--b2-key", "k"]):
        mock_get_provider.return_value.list_files.return_value = []
        with pytest.raises(SystemExit):
            restore.main()

@patch("gemini_manager.restore.acquire_lock")
def test_main_from_dir_not_found(mock_lock, fs):
    with patch("sys.argv", ["restore.py", "--full", "--from-dir", "/tmp/notfound"]):
        with pytest.raises(SystemExit):
            restore.main()

@patch("gemini_manager.restore.acquire_lock")
@patch("os.replace")
def test_main_from_archive_search_dir(mock_replace, mock_lock, fs):
    os.makedirs(os.path.expanduser("~/.gemini-manager"), exist_ok=True)
    search_dir = os.path.expanduser("~/.gemini-manager/backups")
    os.makedirs(search_dir, exist_ok=True)
    fs.create_file(os.path.join(search_dir, "archive.tar.gz"))

    with patch("gemini_manager.restore.run") as mock_run:
        mock_run.return_value.returncode = 0

        with patch("sys.argv", ["restore.py", "--full", "--from-archive", "archive.tar.gz"]):
             restore.main()

@patch("gemini_manager.restore.acquire_lock")
def test_main_from_archive_not_found(mock_lock, fs):
    with patch("sys.argv", ["restore.py", "--full", "--from-archive", "archive.tar.gz"]):
        with pytest.raises(SystemExit):
             restore.main()

@patch("gemini_manager.restore.acquire_lock")
@patch("gemini_manager.restore.find_oldest_archive_backup", return_value=None)
def test_main_auto_no_backups(mock_find, mock_lock, fs):
    os.makedirs(os.path.expanduser("~/.gemini-manager"), exist_ok=True)
    with patch("sys.argv", ["restore.py", "--full"]):
        with pytest.raises(SystemExit):
            restore.main()

@patch("gemini_manager.restore.acquire_lock")
@patch("gemini_manager.restore.run")
@patch("os.replace")
def test_main_rollback_success(mock_replace, mock_run, mock_lock, fs):
     archive = "/tmp/archive.tar.gz"
     fs.create_file(archive)
     os.makedirs(os.path.expanduser("~/.gemini-manager"), exist_ok=True)

     with patch("sys.argv", ["restore.py", "--full", "--from-archive", archive]):
        mock_run.side_effect = [
            MagicMock(returncode=0),
            MagicMock(returncode=0),
            MagicMock(returncode=1, stdout="diff"),
        ]
        with pytest.raises(SystemExit) as e:
            restore.main()
        assert e.value.code == 4

@patch("gemini_manager.restore.acquire_lock")
@patch("gemini_manager.restore.run")
def test_main_rollback_fail(mock_run, mock_lock, fs):
     archive = "/tmp/archive.tar.gz"
     fs.create_file(archive)
     os.makedirs(os.path.expanduser("~/.gemini-manager"), exist_ok=True)

     with patch("sys.argv", ["restore.py", "--full", "--from-archive", archive]):
        mock_run.side_effect = [MagicMock(returncode=0), MagicMock(returncode=0), MagicMock(returncode=1)]

        with patch("os.replace", side_effect=[None, None, OSError("Rollback Error")]) as mock_replace:
            with pytest.raises(SystemExit) as e:
                restore.main()
            assert e.value.code == 4

@patch("gemini_manager.restore.acquire_lock")
@patch("gemini_manager.restore.get_cloud_provider")
@patch("gemini_manager.restore.run")
@patch("gemini_manager.cooldown._sync_cooldown_file")
@patch("os.replace")
def test_main_cloud_specific_archive(mock_replace, mock_sync, mock_run, mock_get_provider, mock_lock, fs):
    os.makedirs(os.path.expanduser("~/.gemini-manager"), exist_ok=True)
    specific_archive = "2025-11-21_231311-specific@test.gemini-manager.tar.gz"

    with patch("sys.argv", ["restore.py", "--full", "--cloud", "--bucket", "b", "--b2-id", "i", "--b2-key", "k", "--from-archive", specific_archive]):
        mock_file_specific = MagicMock()
        mock_file_specific.name = specific_archive
        
        mock_file_old = MagicMock()
        mock_file_old.name = "2025-10-22_042211-old@test.gemini-manager.tar.gz"
        
        mock_get_provider.return_value.list_files.return_value = [mock_file_old, mock_file_specific]

        mock_run.return_value.returncode = 0

        # Create temp file
        temp_path = os.path.join(tempfile.gettempdir(), specific_archive)
        fs.create_file(temp_path)

        restore.main()
        
        mock_get_provider.return_value.download_file.assert_called_with(specific_archive, ANY)

@patch("gemini_manager.restore.acquire_lock")
@patch("os.replace")
def test_main_lock_exception(mock_replace, mock_lock, fs):
    fs.create_file("/tmp/backup.tar.gz")
    os.makedirs(os.path.expanduser("~/.gemini-manager"), exist_ok=True)

    mock_fd = MagicMock()
    mock_lock.return_value = mock_fd

    with patch("gemini_manager.restore.find_oldest_archive_backup", return_value="/tmp/backup.tar.gz"):
        with patch("gemini_manager.restore.run", return_value=MagicMock(returncode=0)):
             with patch("sys.argv", ["restore.py", "--full"]):
                 with patch("gemini_manager.restore.fcntl.flock") as mock_flock:
                     mock_flock.side_effect = [None, Exception("Unlock fail")]
                     restore.main()

@patch("gemini_manager.restore.acquire_lock")
@patch("gemini_manager.restore.run")
def test_main_os_replace_fail_fallback(mock_run, mock_lock, fs):
    archive = "/tmp/archive.tar.gz"
    fs.create_file(archive)
    os.makedirs(os.path.expanduser("~/.gemini-manager"), exist_ok=True)

    mock_run.return_value.returncode = 0

    with patch("os.replace", side_effect=OSError(18, "Cross-device link")):
        with patch("shutil.move") as mock_move:
            with patch("sys.argv", ["restore.py", "--full", "--from-archive", archive]):
                restore.main()
                mock_move.assert_called()

@patch("gemini_manager.restore.acquire_lock")
@patch("gemini_manager.restore.run")
@patch("os.replace")
def test_main_temp_extraction_rmtree_fail(mock_replace, mock_run, mock_lock, fs):
    archive = "/tmp/archive.tar.gz"
    fs.create_file(archive)
    os.makedirs(os.path.expanduser("~/.gemini-manager"), exist_ok=True)
    mock_run.return_value.returncode = 0

    # Mock shutil.rmtree to fail
    with patch("shutil.rmtree", side_effect=Exception("Perm error")):
        with patch("sys.argv", ["restore.py", "--full", "--from-archive", archive]):
            restore.main()

@patch("gemini_manager.restore.acquire_lock")
@patch("gemini_manager.restore.run")
@patch("os.replace")
def test_main_dest_not_exists(mock_replace, mock_run, mock_lock, fs):
    # dest dir does not exist (we don't create it in fs)
    archive = "/tmp/archive.tar.gz"
    fs.create_file(archive)

    mock_run.return_value.returncode = 0

    with patch("sys.argv", ["restore.py", "--full", "--from-archive", archive]):
        restore.main()
        # Verify it created dest
        # Since we mocked os.replace, the actual move didn't happen, so dest isn't created by replace.
        # But `main` does verify verification success.
        # We can assert that `mock_replace` was called.
        mock_replace.assert_called()

@patch("gemini_manager.restore.acquire_lock")
@patch("gemini_manager.restore.run")
@patch("os.replace")
def test_main_tmp_dest_not_exists(mock_replace, mock_run, mock_lock, fs):
    archive = "/tmp/archive.tar.gz"
    fs.create_file(archive)
    os.makedirs(os.path.expanduser("~/.gemini-manager"), exist_ok=True)
    mock_run.return_value.returncode = 0

    with patch("sys.argv", ["restore.py", "--full", "--from-archive", archive]):
        restore.main()

@patch("gemini_manager.restore.acquire_lock")
@patch("gemini_manager.restore.run")
def test_main_force_replace(mock_run, mock_lock, fs):
    archive = "/tmp/archive.tar.gz"
    fs.create_file(archive)
    os.makedirs(os.path.expanduser("~/.gemini-manager"), exist_ok=True)
    mock_run.return_value.returncode = 0

    with patch("shutil.rmtree") as mock_rmtree:
        with patch("os.replace"):
            with patch("sys.argv", ["restore.py", "--full", "--from-archive", archive, "--force"]):
                restore.main()
                assert mock_rmtree.call_count >= 1

@patch("gemini_manager.restore.acquire_lock")
@patch("gemini_manager.restore.get_cloud_provider")
def test_main_cloud_specific_archive_not_found(mock_get_provider, mock_lock, fs):
    with patch("sys.argv", ["restore.py", "--full", "--cloud", "--bucket", "b", "--b2-id", "i", "--b2-key", "k", "--from-archive", "missing.tar.gz"]):
        mock_file = MagicMock()
        mock_file.name = "other.tar.gz"
        mock_get_provider.return_value.list_files.return_value = [mock_file]
        with pytest.raises(SystemExit) as e:
            restore.main()
        assert e.value.code == 1

@patch("gemini_manager.restore.acquire_lock")
@patch("gemini_manager.restore.run")
@patch("gemini_manager.cooldown._sync_cooldown_file")
@patch("os.replace")
def test_main_cleanup_temp_download(mock_replace, mock_sync, mock_run, mock_lock, fs):
    dest_dir = os.path.expanduser("~/.gemini-manager")
    os.makedirs(dest_dir, exist_ok=True)

    with patch("sys.argv", ["restore.py", "--full", "--cloud", "--bucket", "b", "--b2-id", "i", "--b2-key", "k"]):
        with patch("gemini_manager.restore.get_cloud_provider") as mock_get_provider:
            mock_file = MagicMock()
            mock_file.name = "2025-10-22_042211-test.gemini-manager.tar.gz"
            mock_get_provider.return_value.list_files.return_value = [mock_file]
            mock_run.return_value.returncode = 0

            # Create the temp file so it exists to be cleaned up
            temp_path = os.path.join(tempfile.gettempdir(), mock_file.name)
            fs.create_file(temp_path)

            with patch("os.remove") as mock_remove:
                # We need to manually simulate os.exists returning true for this path if fs doesn't handle it well
                # but fs SHOULD handle it.
                restore.main()
                mock_remove.assert_called()

@patch("gemini_manager.restore.acquire_lock")
@patch("gemini_manager.restore.run")
def test_main_verification_fail_with_stdout(mock_run, mock_lock, fs):
    archive = "/tmp/archive.tar.gz"
    fs.create_file(archive)
    os.makedirs(os.path.expanduser("~/.gemini-manager"), exist_ok=True)

    mock_run.side_effect = [
        MagicMock(returncode=0),
        MagicMock(returncode=1, stdout="diff output"),
    ]
    with patch("sys.argv", ["restore.py", "--full", "--from-archive", archive]):
        with pytest.raises(SystemExit) as e:
            restore.main()
        assert e.value.code == 3

# For perform_restore tests that use argparse.Namespace directly, we rely on fs setup too

def test_restore_auto_local_no_rec(fs, capsys):
    os.makedirs(os.path.expanduser("~/.gemini-manager"), exist_ok=True)

    args = argparse.Namespace(
        auto=True,
        cloud=False,
        dest="~/.gemini-manager",
        search_dir="~/gm/backups",
        from_dir=None,
        from_archive=None,
        dry_run=False,
        force=False,
        full=True,
        auth_only=False
    )

    with patch("gemini_manager.restore.get_recommendation", return_value=None):
        with pytest.raises(SystemExit):
            perform_restore(args)

def test_restore_auto_local_success(fs, capsys):
    os.makedirs(os.path.expanduser("~/.gemini-manager"), exist_ok=True)
    search_dir = os.path.expanduser("~/gm/backups")
    os.makedirs(search_dir, exist_ok=True)
    fs.create_file(os.path.join(search_dir, "2025-01-01_120000-test@example.com.gemini-manager.tar.gz"))

    args = argparse.Namespace(
        auto=True,
        cloud=False,
        dest="~/.gemini-manager",
        search_dir="~/gm/backups",
        from_dir=None,
        from_archive=None,
        dry_run=False,
        force=False,
        full=True,
        auth_only=False
    )

    rec = Recommendation(email="test@example.com", status=AccountStatus.READY, last_used=None, next_reset=None)

    with patch("gemini_manager.restore.get_recommendation", return_value=rec):
        with patch("gemini_manager.restore.acquire_lock"), \
             patch("gemini_manager.restore.extract_archive"), \
             patch("gemini_manager.restore.run") as mock_run, \
             patch("os.replace"), \
             patch("gemini_manager.restore.get_active_session", return_value=None):

            mock_run.return_value.returncode = 0
            perform_restore(args)

    captured = capsys.readouterr()
    # assert "Auto-switch recommendation: test@example.com" in captured.out

def test_restore_auto_local_not_found(fs, capsys):
    os.makedirs(os.path.expanduser("~/.gemini-manager"), exist_ok=True)
    search_dir = os.path.expanduser("~/gm/backups")
    os.makedirs(search_dir, exist_ok=True)

    args = argparse.Namespace(
        auto=True,
        cloud=False,
        dest="~/.gemini-manager",
        search_dir="~/gm/backups",
        from_dir=None,
        from_archive=None,
        dry_run=False,
        force=False,
        full=True,
        auth_only=False
    )

    rec = Recommendation(email="test@example.com", status=AccountStatus.READY, last_used=None, next_reset=None)

    with patch("gemini_manager.restore.get_recommendation", return_value=rec):
        with pytest.raises(SystemExit):
            perform_restore(args)

def test_restore_cloud_auto_success(fs, capsys):
    # ~./gemini-manager is already created by fixture

    args = argparse.Namespace(
        auto=True,
        cloud=True,
        dest="~/.gemini-manager",
        search_dir="~/gm/backups",
        from_dir=None,
        from_archive=None,
        dry_run=False,
        force=False,
        full=True,
        auth_only=False,
        b2_id="id",
        b2_key="key",
        bucket="bucket"
    )

    rec = Recommendation(email="test@example.com", status=AccountStatus.READY, last_used=None, next_reset=None)

    # No need to patch resolve_credentials as it's not used in restore.py
    with patch("gemini_manager.restore.get_cloud_provider") as mock_get_provider:

            provider = mock_get_provider.return_value
            file_version = MagicMock()
            file_version.name = "2025-01-01_120000-test@example.com.gemini-manager.tar.gz"
            provider.list_files.return_value = [file_version]

            with patch("gemini_manager.restore.get_recommendation", return_value=rec):
                 with patch("gemini_manager.restore.acquire_lock"), \
                     patch("gemini_manager.restore.extract_archive"), \
                     patch("gemini_manager.restore.run") as mock_run, \
                     patch("os.replace"), \
                     patch("gemini_manager.restore.get_active_session", return_value=None), \
                     patch("os.remove"): # Prevent temp file cleanup error

                     mock_run.return_value.returncode = 0
                     perform_restore(args)

def test_restore_cloud_auto_not_found(fs, capsys):
    os.makedirs(os.path.expanduser("~/.gemini-manager"), exist_ok=True)

    args = argparse.Namespace(
        auto=True,
        cloud=True,
        dest="~/.gemini-manager",
        search_dir="~/gm/backups",
        from_dir=None,
        from_archive=None,
        dry_run=False,
        force=False,
        full=True,
        auth_only=False
    )

    rec = Recommendation(email="test@example.com", status=AccountStatus.READY, last_used=None, next_reset=None)

    # No need to patch resolve_credentials as it's not used in restore.py
    with patch("gemini_manager.restore.get_cloud_provider") as mock_get_provider:

            provider = mock_get_provider.return_value
            file_version = MagicMock()
            file_version.name = "2025-01-01_120000-other@example.com.gemini-manager.tar.gz"
            provider.list_files.return_value = [file_version]

            with patch("gemini_manager.restore.get_recommendation", return_value=rec):
                with pytest.raises(SystemExit):
                    perform_restore(args)

def test_restore_from_archive_search_fallback(fs, capsys):
    os.makedirs(os.path.expanduser("~/.gemini-manager"), exist_ok=True)
    search_dir = os.path.expanduser("~/gm/backups")
    os.makedirs(search_dir, exist_ok=True)
    fs.create_file(os.path.join(search_dir, "mybackup.tar.gz"))

    args = argparse.Namespace(
        from_archive="mybackup.tar.gz",
        search_dir="~/gm/backups",
        dest="~/.gemini-manager",
        cloud=False,
        auto=False,
        from_dir=None,
        dry_run=False,
        force=False,
        full=True,
        auth_only=False
    )

    with patch("gemini_manager.restore.acquire_lock"), \
         patch("gemini_manager.restore.extract_archive"), \
         patch("gemini_manager.restore.run") as mock_run, \
         patch("os.replace"), \
         patch("gemini_manager.restore.get_active_session", return_value=None):

         mock_run.return_value.returncode = 0
         perform_restore(args)

def test_restore_from_archive_not_found_cli(fs, capsys):
    os.makedirs(os.path.expanduser("~/.gemini-manager"), exist_ok=True)

    args = argparse.Namespace(
        from_archive="nonexistent.tar.gz",
        search_dir="~/gm/backups",
        dest="~/.gemini-manager",
        cloud=False,
        auto=False,
        from_dir=None,
        dry_run=False,
        force=False,
        full=True,
        auth_only=False
    )

    with pytest.raises(SystemExit):
        perform_restore(args)

def test_restore_cloud_specific_success_cli(fs, capsys):
    os.makedirs(os.path.expanduser("~/.gemini-manager"), exist_ok=True)
    valid_name = "2025-01-01_120000-specific.gemini-manager.tar.gz"
    args = argparse.Namespace(
        cloud=True,
        from_archive=valid_name,
        auto=False,
        dest="~/.gemini-manager",
        search_dir="~/gm/backups",
        from_dir=None,
        dry_run=False,
        force=False,
        full=True,
        auth_only=False,
        b2_id="id",
        b2_key="key",
        bucket="bucket"
    )

    # No need to patch resolve_credentials as it's not used in restore.py
    with patch("gemini_manager.restore.get_cloud_provider") as mock_get_provider:

            provider = mock_get_provider.return_value
            fv = MagicMock()
            fv.name = valid_name
            provider.list_files.return_value = [fv]

            with patch("gemini_manager.restore.acquire_lock"), \
                 patch("gemini_manager.restore.extract_archive"), \
                 patch("gemini_manager.restore.run") as mock_run, \
                 patch("os.replace"), \
                 patch("gemini_manager.restore.get_active_session", return_value=None), \
                 patch("os.remove"):

                 mock_run.return_value.returncode = 0
                 perform_restore(args)

def test_restore_cloud_specific_fail_cli(fs, capsys):
    os.makedirs(os.path.expanduser("~/.gemini-manager"), exist_ok=True)
    args = argparse.Namespace(
        cloud=True,
        from_archive="missing.gemini-manager.tar.gz",
        auto=False,
        dest="~/.gemini-manager",
        search_dir="~/gm/backups",
        from_dir=None,
        dry_run=False,
        force=False,
        full=True,
        auth_only=False,
        b2_id="id",
        b2_key="key",
        bucket="bucket"
    )

    # No need to patch resolve_credentials as it's not used in restore.py
    with patch("gemini_manager.restore.get_cloud_provider") as mock_get_provider:

            provider = mock_get_provider.return_value
            fv = MagicMock()
            fv.name = "2025-01-01_120000-existing.gemini-manager.tar.gz"
            provider.list_files.return_value = [fv]

            with pytest.raises(SystemExit):
                 perform_restore(args)

def test_restore_auto_cooldown_outgoing(fs, capsys):
    os.makedirs(os.path.expanduser("~/.gemini-manager"), exist_ok=True)
    search_dir = os.path.expanduser("~/gm/backups")
    os.makedirs(search_dir, exist_ok=True)
    fs.create_file(os.path.join(search_dir, "2025-01-01_120000-test@example.com.gemini-manager.tar.gz"))

    args = argparse.Namespace(
        cloud=False,
        auto=False,
        dest="~/.gemini-manager",
        search_dir="~/gm/backups",
        from_dir=None,
        from_archive="2025-01-01_120000-test@example.com.gemini-manager.tar.gz",
        dry_run=False,
        force=False,
        full=True,
        auth_only=False
    )

    with patch("gemini_manager.restore.get_active_session", side_effect=["old@test.com", "new@test.com"]):
         # Patch resolve_credentials to prevent exit if called (it shouldn't be for local)
         with patch("gemini_manager.restore.acquire_lock"), \
             patch("gemini_manager.restore.extract_archive"), \
             patch("gemini_manager.restore.run") as mock_run, \
             patch("gemini_manager.restore.add_24h_cooldown_for_email") as mock_cooldown, \
             patch("gemini_manager.restore.record_switch") as mock_switch, \
             patch("os.replace"):

             mock_run.return_value.returncode = 0
             perform_restore(args)

             mock_cooldown.assert_called_with("old@test.com")
             mock_switch.assert_any_call("old@test.com", args=args)
             mock_switch.assert_any_call("new@test.com", args=args)


def test_restore_defaults_to_auth_only_and_preserves_session_files(fs):
    src_dir = "/tmp/backup_source"
    dest_dir = os.path.expanduser("~/.gemini")
    os.makedirs(src_dir, exist_ok=True)
    fs.create_file(os.path.join(src_dir, "google_accounts.json"), contents='{"active":"new@example.com"}')
    fs.create_file(os.path.join(src_dir, "oauth_creds.json"), contents='{"refresh_token":"new"}')
    fs.create_file(os.path.join(src_dir, "installation_id"), contents="new-install")
    fs.create_file(os.path.join(src_dir, "settings.json"), contents='{"security":{"auth":"oauth"}}')
    fs.create_file(os.path.join(src_dir, "state.json"), contents='{"from":"backup"}')

    os.makedirs(os.path.join(dest_dir, "tmp", "bot-platform", "chats"), exist_ok=True)
    fs.create_file(
        os.path.join(dest_dir, "tmp", "bot-platform", "chats", "session-current.jsonl"),
        contents='{"current":true}\n',
    )
    fs.create_file(os.path.join(dest_dir, "state.json"), contents='{"current":true}')

    args = argparse.Namespace(
        cloud=False,
        auto=False,
        email=None,
        dest=dest_dir,
        search_dir="~/gm/backups",
        from_dir=src_dir,
        from_archive=None,
        dry_run=False,
        force=False,
        full=False,
        auth_only=False,
    )

    with patch("gemini_manager.restore.acquire_lock"), \
         patch("gemini_manager.restore.get_active_session", return_value=None):
        perform_restore(args)

    assert open(os.path.join(dest_dir, "google_accounts.json")).read() == '{"active":"new@example.com"}'
    assert open(os.path.join(dest_dir, "oauth_creds.json")).read() == '{"refresh_token":"new"}'
    assert open(os.path.join(dest_dir, "installation_id")).read() == "new-install"
    assert open(os.path.join(dest_dir, "settings.json")).read() == '{"security":{"auth":"oauth"}}'
    assert open(os.path.join(dest_dir, "state.json")).read() == '{"current":true}'
    assert os.path.exists(os.path.join(dest_dir, "tmp", "bot-platform", "chats", "session-current.jsonl"))


def test_full_restore_preserves_existing_antigravity_cli(fs):
    src_dir = "/tmp/backup_source"
    dest_dir = os.path.expanduser("~/.gemini")
    os.makedirs(src_dir, exist_ok=True)
    os.makedirs(dest_dir, exist_ok=True)
    fs.create_file(os.path.join(src_dir, "state.json"), contents='{"from":"backup"}')
    os.makedirs(os.path.join(src_dir, "antigravity-cli"), exist_ok=True)
    fs.create_file(os.path.join(src_dir, "antigravity-cli", "state.json"), contents="backup-antigravity")
    os.makedirs(os.path.join(dest_dir, "antigravity-cli"), exist_ok=True)
    fs.create_file(os.path.join(dest_dir, "antigravity-cli", "state.json"), contents="current-antigravity")

    args = argparse.Namespace(
        cloud=False,
        auto=False,
        email=None,
        dest=dest_dir,
        search_dir="~/gm/backups",
        from_dir=src_dir,
        from_archive=None,
        dry_run=False,
        force=False,
        full=True,
        auth_only=False,
    )

    with patch("gemini_manager.restore.acquire_lock"), \
         patch("gemini_manager.restore.get_active_session", return_value=None), \
         patch("gemini_manager.restore.run") as mock_run:
        mock_run.return_value.returncode = 0
        perform_restore(args)

    assert open(os.path.join(dest_dir, "state.json")).read() == '{"from":"backup"}'
    assert open(os.path.join(dest_dir, "antigravity-cli", "state.json")).read() == "current-antigravity"


def test_full_restore_does_not_install_antigravity_cli_from_source(fs):
    src_dir = "/tmp/backup_source"
    dest_dir = os.path.expanduser("~/.gemini")
    os.makedirs(src_dir, exist_ok=True)
    fs.create_file(os.path.join(src_dir, "state.json"), contents='{"from":"backup"}')
    os.makedirs(os.path.join(src_dir, "antigravity-cli"), exist_ok=True)
    fs.create_file(os.path.join(src_dir, "antigravity-cli", "state.json"), contents="backup-antigravity")

    args = argparse.Namespace(
        cloud=False,
        auto=False,
        email=None,
        dest=dest_dir,
        search_dir="~/gm/backups",
        from_dir=src_dir,
        from_archive=None,
        dry_run=False,
        force=False,
        full=True,
        auth_only=False,
    )

    with patch("gemini_manager.restore.acquire_lock"), \
         patch("gemini_manager.restore.get_active_session", return_value=None), \
         patch("gemini_manager.restore.run") as mock_run:
        mock_run.return_value.returncode = 0
        perform_restore(args)

    assert open(os.path.join(dest_dir, "state.json")).read() == '{"from":"backup"}'
    assert not os.path.exists(os.path.join(dest_dir, "antigravity-cli"))


def test_restore_email_selects_latest_local_backup(fs):
    search_dir = os.path.expanduser("~/gm/backups")
    os.makedirs(search_dir, exist_ok=True)
    latest = os.path.join(search_dir, "2025-01-02_120000-test@example.com.gemini-manager.tar.gz")
    old = os.path.join(search_dir, "2025-01-01_120000-test@example.com.gemini-manager.tar.gz")
    fs.create_file(latest)
    fs.create_file(old)

    args = argparse.Namespace(
        cloud=False,
        auto=False,
        email="test@example.com",
        dest=os.path.expanduser("~/.gemini"),
        search_dir="~/gm/backups",
        from_dir=None,
        from_archive=None,
        dry_run=False,
        force=False,
        full=False,
        auth_only=False,
    )

    with patch("gemini_manager.restore.acquire_lock"), \
         patch("gemini_manager.restore.extract_archive") as mock_extract, \
         patch("gemini_manager.restore._copy_auth_only_files", return_value=["google_accounts.json"]), \
         patch("gemini_manager.restore.get_active_session", return_value=None):
        perform_restore(args)

    mock_extract.assert_called_once_with(latest, ANY)


def test_restore_cloud_email_selects_latest_backup(fs):
    dest_dir = os.path.expanduser("~/.gemini")
    os.makedirs(dest_dir, exist_ok=True)

    args = argparse.Namespace(
        cloud=True,
        auto=False,
        email="test@example.com",
        dest=dest_dir,
        search_dir="~/gm/backups",
        from_dir=None,
        from_archive=None,
        dry_run=False,
        force=False,
        full=False,
        auth_only=False,
        b2_id="id",
        b2_key="key",
        bucket="bucket",
    )

    latest_name = "2025-01-02_120000-test@example.com.gemini-manager.tar.gz"
    old_name = "2025-01-01_120000-test@example.com.gemini-manager.tar.gz"

    with patch("gemini_manager.restore.get_cloud_provider") as mock_get_provider:
        provider = mock_get_provider.return_value
        latest_file = MagicMock()
        latest_file.name = latest_name
        old_file = MagicMock()
        old_file.name = old_name
        provider.list_files.return_value = [old_file, latest_file]

        with patch("gemini_manager.restore.acquire_lock"), \
             patch("gemini_manager.restore.extract_archive"), \
             patch("gemini_manager.restore._copy_auth_only_files", return_value=["google_accounts.json"]), \
             patch("gemini_manager.restore.get_active_session", return_value=None), \
             patch("os.remove"):
            perform_restore(args)

    provider.download_file.assert_called_once_with(latest_name, ANY)


def test_restore_circular_move_fix(fs):
    """
    Test that restoring to a destination that contains the OLD_CONFIGS_DIR
    (circular move) is handled correctly by using a temporary move.
    """
    # We explicitly patch OLD_CONFIGS_DIR here to ensure we have a controlled scenario
    # that is guaranteed to be a circular move.
    my_old_configs_dir = "/tmp/gm-manager/old_configs"
    dest = "/tmp/gm-manager"
    
    os.makedirs(dest, exist_ok=True)
    fs.create_file(os.path.join(dest, "some_file"), contents="old content")
    
    src_dir = "/tmp/new_config"
    os.makedirs(src_dir, exist_ok=True)
    fs.create_file(os.path.join(src_dir, "some_file"), contents="new content")
    
    args = argparse.Namespace(
        dest=dest,
        from_dir=src_dir,
        full=True,
        force=False,
        dry_run=False,
        auth_only=False,
        search_dir="/tmp/backups"
    )
    
    with patch("gemini_manager.restore.OLD_CONFIGS_DIR", my_old_configs_dir), \
         patch("gemini_manager.restore.acquire_lock"), \
         patch("gemini_manager.restore.run") as mock_run, \
         patch("os.replace") as mock_replace, \
         patch("gemini_manager.restore.get_active_session", return_value=None):
        
        mock_run.return_value.returncode = 0
        restore.perform_restore(args)
    
    # Verify that the backup was created in our patched OLD_CONFIGS_DIR
    assert os.path.exists(my_old_configs_dir)
    bak_files = [f for f in os.listdir(my_old_configs_dir) if f.endswith(".gemini-manager.bak")]
    assert len(bak_files) == 1
    
    # Verify the backup contains the old file
    bak_path = os.path.join(my_old_configs_dir, bak_files[0])
    assert os.path.exists(os.path.join(bak_path, "some_file"))
    with open(os.path.join(bak_path, "some_file"), "r") as f:
        assert f.read() == "old content"
