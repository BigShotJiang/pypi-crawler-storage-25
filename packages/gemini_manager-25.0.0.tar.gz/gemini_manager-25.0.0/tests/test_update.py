# tests/test_update.py

import pytest
import sys
import json
from importlib.metadata import PackageNotFoundError
from unittest.mock import patch, MagicMock
from gemini_manager.update import do_update, do_check_update, get_latest_version

@patch("gemini_manager.update.run_cmd_safe")
@patch("gemini_manager.update.banner")
@patch("gemini_manager.update.cprint")
@patch("shutil.which")
def test_do_update_pip_success(mock_which, mock_cprint, mock_banner, mock_run):
    # Strategy 1 (pip) succeeds
    mock_run.return_value = (0, "Successfully installed gemini-manager-23.0.0", "")
    
    do_update()
    
    mock_banner.assert_called_once()
    # Check that pip was tried
    assert any("python3 -m pip install" in str(args) or "pip install" in str(args) for args, _ in mock_run.call_args_list)
    assert any("Update complete" in str(args) for args, _ in mock_cprint.call_args_list)

@patch("gemini_manager.update.run_cmd_safe")
@patch("gemini_manager.update.banner")
@patch("gemini_manager.update.cprint")
@patch("shutil.which")
def test_do_update_uv_fallback(mock_which, mock_cprint, mock_banner, mock_run):
    # Strategy 1 (pip) fails with "no module named pip"
    # Strategy 2 (uv) succeeds
    mock_run.side_effect = [
        (1, "", "No module named pip"),
        (0, "Successfully installed via uv", "")
    ]
    mock_which.side_effect = lambda x: "/usr/bin/uv" if x == "uv" else None
    
    do_update()
    
    assert mock_run.call_count == 2
    assert any("uv pip install" in str(args) for args, _ in mock_run.call_args_list)
    assert any("Update complete" in str(args) for args, _ in mock_cprint.call_args_list)

@patch("gemini_manager.update.run_cmd_safe")
@patch("gemini_manager.update.banner")
@patch("gemini_manager.update.cprint")
@patch("builtins.input", return_value="y")
def test_do_update_pep668_force(mock_input, mock_cprint, mock_banner, mock_run):
    # PEP 668 error -> user says 'y' -> success with --break-system-packages
    mock_run.side_effect = [
        (1, "", "externally-managed-environment"),
        (0, "Forced success", "")
    ]
    
    do_update()
    
    assert any("--break-system-packages" in str(args) for args, _ in mock_run.call_args_list)
    assert any("Update complete (forced)" in str(args) for args, _ in mock_cprint.call_args_list)

@patch("gemini_manager.update.run_cmd_safe")
@patch("gemini_manager.update.banner")
@patch("gemini_manager.update.cprint")
@patch("os.getenv")
def test_do_update_fail_hints(mock_getenv, mock_cprint, mock_banner, mock_run):
    # All strategies fail
    mock_run.return_value = (1, "", "total failure")
    mock_getenv.side_effect = lambda x, default=None: "/conda" if x == "CONDA_PREFIX" else default
    
    do_update()
    
    assert any("Automatic update failed" in str(args) for args, _ in mock_cprint.call_args_list)
    assert any("[CONDA]" in str(args) for args, _ in mock_cprint.call_args_list)

@patch("gemini_manager.update.get_latest_version", return_value="25.0.0")
@patch("gemini_manager.update.version", return_value="25.0.0")
@patch("gemini_manager.update.banner")
@patch("gemini_manager.update.cprint")
def test_do_check_update_up_to_date(mock_cprint, mock_banner, mock_ver, mock_latest):
    do_check_update()
    assert any("You already have the latest version" in str(args) for args in mock_cprint.call_args_list)

@patch("gemini_manager.update.get_latest_version", return_value="23.1.0")
@patch("gemini_manager.update.version", return_value="25.0.0")
@patch("gemini_manager.update.do_update")
@patch("builtins.input", return_value="y")
@patch("gemini_manager.update.banner")
@patch("gemini_manager.update.cprint")
def test_do_check_update_available_yes(mock_cprint, mock_banner, mock_input, mock_do_update, mock_ver, mock_latest):
    do_check_update()
    assert any("Update available" in str(args) for args in mock_cprint.call_args_list)
    mock_do_update.assert_called_once()

@patch("gemini_manager.update.get_latest_version", return_value="23.1.0")
@patch("gemini_manager.update.version", return_value="25.0.0")
@patch("builtins.input", return_value="n")
@patch("gemini_manager.update.banner")
@patch("gemini_manager.update.cprint")
def test_do_check_update_available_no(mock_cprint, mock_banner, mock_input, mock_ver, mock_latest):
    do_check_update()
    assert any("Update cancelled" in str(args) for args in mock_cprint.call_args_list)

@patch("gemini_manager.update.get_latest_version", return_value="(unknown)")
@patch("gemini_manager.update.version", return_value="25.0.0")
@patch("gemini_manager.update.banner")
@patch("gemini_manager.update.cprint")
def test_do_check_update_unknown(mock_cprint, mock_banner, mock_ver, mock_latest):
    do_check_update()
    assert any("Could not determine the latest version online" in str(args) for args in mock_cprint.call_args_list)

@patch("urllib.request.urlopen")
def test_get_latest_version_success(mock_urlopen):
    # Mock PyPI JSON response
    mock_response = MagicMock()
    mock_response.read.return_value = json.dumps({"info": {"version": "25.0.0"}}).encode()
    mock_response.__enter__.return_value = mock_response
    mock_urlopen.return_value = mock_response
    
    assert get_latest_version() == "25.0.0"

@patch("urllib.request.urlopen", side_effect=Exception("Network error"))
def test_get_latest_version_fail(mock_urlopen):
    assert get_latest_version() == "(unknown)"

@patch("gemini_manager.update.run_cmd_safe")
@patch("gemini_manager.update.banner")
@patch("gemini_manager.update.cprint")
@patch("shutil.which", return_value=None)
def test_do_update_pip_pep668_cancel(mock_which, mock_cprint, mock_banner, mock_run):
    # PEP 668 -> user says 'n' -> failure
    mock_run.return_value = (1, "", "externally-managed-environment")
    with patch("builtins.input", return_value="n"):
        do_update()
    assert any("Automatic update failed" in str(args) for args, _ in mock_cprint.call_args_list)
