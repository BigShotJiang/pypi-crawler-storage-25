
import pytest
from unittest.mock import patch, MagicMock
import os
import shutil
from gemini_manager.prune import do_prune
from gemini_manager.config import DEFAULT_GEMINI_HOME

def test_do_prune_workspace(fs):
    gemini_home = "/tmp/gemini"
    os.makedirs(gemini_home, exist_ok=True)
    
    # Files to prune
    fs.create_file(os.path.join(gemini_home, "logs.json"))
    fs.create_file(os.path.join(gemini_home, "history.jsonl"))
    
    # Directories to prune
    os.makedirs(os.path.join(gemini_home, "tmp"), exist_ok=True)
    fs.create_file(os.path.join(gemini_home, "tmp/file.txt"))
    
    os.makedirs(os.path.join(gemini_home, "history"), exist_ok=True)
    fs.create_file(os.path.join(gemini_home, "history/session.json"))
    
    # Files to preserve
    fs.create_file(os.path.join(gemini_home, "google_accounts.json"))
    fs.create_file(os.path.join(gemini_home, "settings.json"))

    args = MagicMock(src=gemini_home, dry_run=False)
    
    do_prune(args)
    
    # Verify pruned
    assert not os.path.exists(os.path.join(gemini_home, "logs.json"))
    assert not os.path.exists(os.path.join(gemini_home, "history.jsonl"))
    assert not os.path.exists(os.path.join(gemini_home, "tmp/file.txt"))
    assert not os.path.exists(os.path.join(gemini_home, "history"))
    
    # Verify preserved
    assert os.path.exists(os.path.join(gemini_home, "google_accounts.json"))
    assert os.path.exists(os.path.join(gemini_home, "settings.json"))

def test_do_prune_workspace_preserve_bin(fs):
    gemini_home = "/tmp/gemini"
    os.makedirs(gemini_home, exist_ok=True)
    
    os.makedirs(os.path.join(gemini_home, "tmp/bin"), exist_ok=True)
    fs.create_file(os.path.join(gemini_home, "tmp/bin/helper"))
    fs.create_file(os.path.join(gemini_home, "tmp/other.txt"))

    args = MagicMock(src=gemini_home, dry_run=False)
    do_prune(args)
    
    assert os.path.exists(os.path.join(gemini_home, "tmp/bin/helper"))
    assert not os.path.exists(os.path.join(gemini_home, "tmp/other.txt"))

def test_do_prune_with_protected_items(fs, capsys):
    from gemini_manager.prune import do_prune
    from gemini_manager.protected import PROTECTED_DIRS
    from argparse import Namespace

    gemini_home = "/home/user/.gm"
    fs.create_dir(gemini_home)

    fs.create_dir(os.path.join(gemini_home, "tmp"))
    for pd in PROTECTED_DIRS:
        fs.create_dir(os.path.join(gemini_home, pd))
        fs.create_file(os.path.join(gemini_home, pd, "chat_data.txt"), contents="data")
        # Setup protected item inside tmp to verify deep protection
        fs.create_dir(os.path.join(gemini_home, "tmp", pd))

    args = Namespace(src=gemini_home, dry_run=False)
    do_prune(args)

    captured = capsys.readouterr()
    assert "[DELETED DIR] tmp" in captured.out
    for pd in PROTECTED_DIRS:
        assert os.path.exists(os.path.join(gemini_home, pd, "chat_data.txt"))

def test_do_prune_dry_run(fs, capsys):
    from gemini_manager.prune import do_prune
    from argparse import Namespace

    gemini_home = "/home/user/.gm"
    fs.create_dir(gemini_home)
    fs.create_file(os.path.join(gemini_home, "logs.json"), contents="data")
    fs.create_dir(os.path.join(gemini_home, "tmp"))
    fs.create_dir(os.path.join(gemini_home, "tmp", "bin"))

    args = Namespace(src=gemini_home, dry_run=True)
    do_prune(args)

    captured = capsys.readouterr()
    assert "[DRY-RUN] Would delete file: logs.json" in captured.out
    assert "[DRY-RUN] Would prune directory: tmp (preserving bin/)" in captured.out or "[DRY-RUN] Would delete directory: tmp" in captured.out

def test_do_prune_tmp_prune(fs, capsys):
    from gemini_manager.prune import do_prune
    from argparse import Namespace

    gemini_home = "/home/user/.gm"
    fs.create_dir(gemini_home)
    fs.create_dir(os.path.join(gemini_home, "tmp"))
    fs.create_dir(os.path.join(gemini_home, "tmp", "bin"))
    fs.create_file(os.path.join(gemini_home, "tmp", "test.txt"))
    fs.create_dir(os.path.join(gemini_home, "tmp", "test_dir"))

    args = Namespace(src=gemini_home, dry_run=False)
    do_prune(args)

    captured = capsys.readouterr()
    assert "[PRUNED DIR] tmp (preserved bin/)" in captured.out

def test_do_prune_exception_file(fs, capsys):
    from gemini_manager.prune import do_prune
    from argparse import Namespace

    gemini_home = "/home/user/.gm"
    fs.create_dir(gemini_home)
    fs.create_file(os.path.join(gemini_home, "logs.json"), contents="data")

    args = Namespace(src=gemini_home, dry_run=False)
    from unittest.mock import patch
    with patch("os.remove", side_effect=Exception("Failed delete")):
        do_prune(args)

    captured = capsys.readouterr()
    assert "Failed to delete logs.json" in captured.out

def test_do_prune_exception_dir(fs, capsys):
    from gemini_manager.prune import do_prune
    from argparse import Namespace

    gemini_home = "/home/user/.gm"
    fs.create_dir(gemini_home)
    fs.create_dir(os.path.join(gemini_home, "cache"))

    args = Namespace(src=gemini_home, dry_run=False)
    from unittest.mock import patch
    with patch("shutil.rmtree", side_effect=Exception("Failed delete")):
        do_prune(args)

    captured = capsys.readouterr()
    assert "Failed to delete cache" in captured.out
