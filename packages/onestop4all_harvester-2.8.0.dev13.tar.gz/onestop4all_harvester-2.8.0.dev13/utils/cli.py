import logging

import click

from utils import cli_startup, config, run as run_harvesting, Solr

log = logging.getLogger(__name__)


@click.group()
@click.option("--debug/--no-debug", "-d", is_flag=True, default=False)
@click.option(
    "--logfile",
    default="/tmp/harvest.log",
    show_default=True,
    help="Define path of logfile",
)
@click.option(
    "--no_log",
    "-nl",
    default=False,
    is_flag=True,
    help="Set this option to see logs in stdout",
)
@click.pass_context
def main(ctx, debug, logfile, no_log):
    cli_startup(
        log_level=debug and logging.DEBUG or logging.INFO,
        logfile=None if no_log else logfile,
    )
    ctx.ensure_object(dict)
    ctx.obj["DEBUG"] = debug


@click.group()
def debug():
    cli_startup(log_level=logging.DEBUG)


@main.command()
@click.option("--no_reset", is_flag=True, default=False)
@click.option(
    "--harvester",
    "-h",
    help="Set one or more harvesters that should be indexed.",
    multiple=True,
    type=click.Choice(
        [
            "Article",
            "DataService",
            "Dataset",
            "Document",
            "Learningresource",
            "Metadatastandard",
            "Organization",
            "Repository",
            "Service",
            "Software",
        ],
        case_sensitive=False,
    ),
)
@click.pass_context
def run(ctx, no_reset, harvester, **kw):
    run_harvesting(
        # looks a bit strange, but is made this way, cause of using 'is_flag'
        # in combination with reset_index by default
        reset_index=no_reset is False and config["reset_index"] is True,
        requested_harvester=harvester,
        **kw,
    )


@debug.command()
@click.option("-s", "--iteration_start", help="Set start of iteration")
@click.option("-e", "--iteration_end", help="Set end of iteration")
@click.option("-p", "--page_size", help="Set page size for iteration")
@click.option(
    "-q",
    "--query",
    help='Set query, e.g. \'id:"n4e/dthb-GB_NERC_BAS_PDC_01437"',
)
@click.option(
    "-nsv",
    "--no_solr_validation",
    is_flag=True,
    default=None,
    help="Set this flag to turn off solr validation",
)
def datasets(**options):
    options["solr_validation"] = not options.pop("no_solr_validation")
    run_harvesting(
        reset_index=False,
        requested_harvester="Dataset",
        # filter out None values to avoid passing them to the harvester
        # to use the default values (defined in the harvester class)
        dataset_options={k: v for k, v in options.items() if v is not None},
    )


@debug.command()
@click.option("-s", "--iteration_start", help="Set start of iteration")
@click.option("-e", "--iteration_end", help="Set end of iteration")
@click.option("-p", "--page_size", help="Set page size for iteration")
@click.option(
    "-q",
    "--query",
    help="Set query, e.g. 'id:\"n4e/dataservice-example\"'",
)
@click.option(
    "-nsv",
    "--no_solr_validation",
    is_flag=True,
    default=None,
    help="Set this flag to turn off solr validation",
)
def dataservices(**options):
    options["solr_validation"] = not options.pop("no_solr_validation")
    run_harvesting(
        reset_index=False,
        requested_harvester="DataService",
        # filter out None values to avoid passing them to the harvester
        # to use the default values (defined in the harvester class)
        dataservice_options={
            k: v for k, v in options.items() if v is not None
        },
    )


@debug.command()
def dataservices_batched():
    from utils import config
    from harvesters.harvester_dataservice import DataService_HarvesterBatched
    from data_repositories import RepositoryPerson, RepositoryTheme

    print("und los")
    print(config)
    persons_repo = RepositoryPerson()
    themes_repo = RepositoryTheme()
    dsh_batched = DataService_HarvesterBatched(
        persons_repo=persons_repo,
        themes_repo=themes_repo,
        solr_validation=False,
    )
    ids = dsh_batched.get_all_ids()
    batch_size = 10
    for i in range(0, len(ids), batch_size):
        # print(f"Batch {i//batch_size}: IDs {i} to {i+batch_size}")
        ids_batched = ids[i : i + batch_size]
        print(f"Batch {i//batch_size}: IDs {ids_batched}")
        triples = dsh_batched.get_triples_for_subjects(ids_batched)
        print(f"Batch {i//batch_size}: Triples {len(triples)}")


@main.command()
@click.pass_context
def reset(ctx):
    Solr().reset_index()


# if __name__ == "__main__":
#     cli_startup(
#         log_level=debug and logging.DEBUG or logging.INFO,
#         logfile=None
#     )
#     run_harvesting(reset_index=False, requested_harvester="Service")
