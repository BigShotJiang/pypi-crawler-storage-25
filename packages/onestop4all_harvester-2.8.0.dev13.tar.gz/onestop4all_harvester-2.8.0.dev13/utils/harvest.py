import logging
import requests
import timeit
import traceback

from socket import gethostname
from typing import Optional

from data_repositories import (
    RepositoryTheme,
    RepositoryPerson,
    RepositoryResourceLinks,
    RepositoryN4EOrganization,
)
from harvesters import (
    Repository_Harvester,
    Organization_Harvester,
    Article_Harvester,
    Software_Harvester,
    Learningresource_Harvester,
    Metadatastandard_Harvester,
    Document_Harvester,
    Dataset_Harvester,
    DataService_Harvester,
    Service_Harvester,
)
from utils import config, Solr

log = logging.getLogger(__name__)


def get_harvester(
    harvester_name=None,
    dataset_options={},
    dataservice_options={},
):

    # Lazy initialization of repository singletons
    # Only one instance per repository type will be created and reused
    repo_singletons = {}
    repo_classes = {
        "themes_repo": RepositoryTheme,
        "persons_repo": RepositoryPerson,
        "links_repo": RepositoryResourceLinks,
        "n4e_orgas_repo": RepositoryN4EOrganization,
    }

    def get_repo(repo_name):
        # Returns a singleton instance of the requested repository.
        # Instantiates the repository only on first access.
        if repo_name not in repo_singletons:
            repo_singletons[repo_name] = repo_classes[repo_name]()
        return repo_singletons[repo_name]

    # Mapping from harvester name to factory function
    # Each factory uses get_repo to ensure repositories are only created once
    harvester_factories = {
        "Service": lambda: Service_Harvester(get_repo("n4e_orgas_repo")),
        "DataService": lambda: DataService_Harvester(
            get_repo("themes_repo"),
            get_repo("persons_repo"),
            **dataservice_options,
        ),
        "Repository": lambda: Repository_Harvester(
            get_repo("themes_repo"),
            get_repo("n4e_orgas_repo"),
        ),
        "Organization": lambda: Organization_Harvester(
            get_repo("persons_repo")
        ),
        "Article": lambda: Article_Harvester(
            get_repo("persons_repo"),
            get_repo("links_repo"),
            get_repo("themes_repo"),
        ),
        "Software": lambda: Software_Harvester(
            get_repo("persons_repo"),
            get_repo("links_repo"),
        ),
        "Learningresource": lambda: Learningresource_Harvester(
            get_repo("persons_repo"),
            get_repo("themes_repo"),
        ),
        "Metadatastandard": lambda: Metadatastandard_Harvester(
            get_repo("themes_repo")
        ),
        "Document": lambda: Document_Harvester(
            get_repo("persons_repo"),
            get_repo("links_repo"),
        ),
        "Dataset": lambda: Dataset_Harvester(
            get_repo("persons_repo"),
            get_repo("links_repo"),
            **dataset_options,
        ),
    }

    # If no harvester_name is given, instantiate all harvesters
    if not harvester_name:
        return [factory() for factory in harvester_factories.values()]

    # If a name or list/tuple of names is given, instantiate only those
    # This keeps compatibility with previous behavior
    if isinstance(harvester_name, (list, tuple)):
        names = harvester_name
    else:
        names = [harvester_name]

    return [
        harvester_factories[name]()
        for name in harvester_factories
        if name in names
    ]


def run(
    requested_harvester: Optional[tuple] = None,
    reset_index: Optional[bool] = None,
    **further_options,
):
    solr = Solr()

    if reset_index:
        solr.reset_index()

    stats = {}

    i = 1
    harvesters = get_harvester(
        harvester_name=requested_harvester, **further_options
    )
    log.info(f"Initialized {len(harvesters)} harvesters.")
    document_count = 0
    try:
        for harvester in harvesters:
            log.info(f"start harvester {harvester} ({i} of {len(harvesters)}")
            start_time = timeit.default_timer()
            documents = harvester.harvest()
            elapsed_time = timeit.default_timer() - start_time

            log.info(f"index harvested {len(documents)} documents")
            solr.index_documents(documents)
            document_count += len(documents)
            log.info(
                f"finished indexing for harvester {i} of {len(harvesters)})"
            )
            stats[harvester.get_type()] = {
                "document_count": len(documents),
                "processing_time": round(elapsed_time, 4),
            }
            if harvester.get_notes():
                stats[harvester.get_type()]["notes"] = harvester.get_notes()
            i += 1
    except Exception as e:
        data = {
            "exception": str(e),
            "traceback": traceback.format_exc(),
            "hostname": gethostname(),
        }
        if config["mailserver_url"]:
            requests.post(config["mailserver_url"], json=data, verify=False)
    else:
        log.info(
            "harvesting completed, indexed {} documents".format(document_count)
        )
        requests.post(
            config["mailserver_url"],
            json={"stats": stats, "hostname": gethostname()},
            verify=False,
        )


if __name__ == "__main__":
    run()
