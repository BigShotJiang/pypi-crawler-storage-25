import logging
import os
from jproperties import Properties

log = logging.getLogger(__name__)


app_properties = Properties()

try:
    with open("./application.properties", "rb") as config_file:
        app_properties.load(config_file)
except FileNotFoundError:
    app_properties = Properties()
    log.warning(
        "Warnung: application.properties not found! "
        "Using default values and environment variables only."
    )


def parse_bool_config(value):
    if value is None:
        return None
    if value.lower() in ["false", "0", "f", "no", "n"]:
        return False
    elif value.lower() in ["true", "1", "t", "yes", "y"]:
        return True


# merge env variables and application.properties
# if env varible is set override application.properties
config = {
    "cordra_endpoint": os.getenv(
        "CORDRA_ENDPOINT",
        default=(
            app_properties.get("cordra_endpoint").data
            if app_properties.get("cordra_endpoint")
            else None
        ),
    ),
    "sparql_endpoint": os.getenv(
        "SPARQL_ENDPOINT",
        default=(
            app_properties.get("sparql_endpoint").data
            if app_properties.get("sparql_endpoint")
            else None
        ),
    ),
    "solr_auth": os.getenv(
        "SOLR_AUTH",
        default=(
            app_properties.get("solr_auth").data
            if app_properties.get("solr_auth")
            else None
        ),
    ),
    "solr_core": os.getenv(
        "SOLR_CORE",
        default=(
            app_properties.get("solr_core").data
            if app_properties.get("solr_core")
            else None
        ),
    ),
    "solr_url": os.getenv(
        "SOLR_URL",
        default=(
            app_properties.get("solr_url").data
            if app_properties.get("solr_url")
            else None
        ),
    ),
    "mailserver_url": os.getenv(
        "MAILSERVER_URL",
        default=(
            app_properties.get("mailserver_url").data
            if app_properties.get("mailserver_url")
            else None
        ),
    ),
    "reset_index": parse_bool_config(
        os.getenv(
            "RESET_INDEX",
            default=(
                app_properties.get("reset_index").data
                if app_properties.get("reset_index")
                else None
            ),
        )
    ),
}
