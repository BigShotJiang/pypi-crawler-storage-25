import logging

from pysolr import Solr as SolrClient
from requests.auth import HTTPBasicAuth
from typing import List, Dict, Optional, Literal
from urllib.parse import urljoin

from utils import config

log = logging.getLogger(__name__)


class Solr(object):

    def __init__(
        self,
        solr_url: Optional[str] = None,
        solr_core: Optional[str] = None,
        solr_auth: Optional[str] = None,
        always_commit: bool = False,
        timeout: int = 5 * 60,
    ) -> None:
        self.solr_url = solr_url if solr_url else config["solr_url"]
        self.solr_core = solr_core if solr_core else config["solr_core"]
        self.auth = solr_auth if solr_auth else config["solr_auth"]
        self.client = SolrClient(
            self.endpoint,
            auth=self.authentication,
            always_commit=always_commit,
            timeout=timeout,
        )
        # test connection to solr endpoint
        # -> raises exception if connection fails
        self.client.ping()

    @property
    def endpoint(self):
        endpoint = urljoin(self.solr_url, self.solr_core)
        log.info(f"initialized solr client with endpoint: {endpoint}")
        return endpoint

    @property
    def authentication(self):
        if self.auth:
            username, password = self.auth.split(":")
            return HTTPBasicAuth(username, password)

    def index_documents(
        self, documents: List[Dict], commit=True, ping=True
    ) -> None:
        # solr_endpoint = coreurl(solr_url, solr_core)
        log.info(f"start indexing {len(documents)} documents")
        batch_size = 50000
        offset = 0
        iteration = 0
        while True:
            if len(documents) <= offset + batch_size:
                batch = documents[offset:]
            else:
                limit = offset + batch_size
                batch = documents[offset:limit]

            if len(batch) == 0:
                break

            self.client.ping()
            log.info("solr healtcheck successful")
            try:
                log.info(f"start adding batch of {len(batch)} documents")
                self.client.add(batch)
                log.info(f"finished adding batch of {len(batch)} documents")
            except Exception as e:
                log.error(e)
            log.info(f"current iteration: {iteration}")
            offset = offset + batch_size
            iteration += 1

            if len(batch) < batch_size:
                break

        if ping is True:
            self.client.ping()
            log.info("solr healtcheck successful")

        if commit is True:
            log.info("commit changes to index")
            self.client.commit()
            log.info("sucessfully commited changes to index")
        log.info("finished indexing")

    def commit(self):
        self.client.commit()

    def reset_index(self):
        self.client.delete(q="*:*")
        self.client.commit()

    def exists(self, document_id: str) -> bool:
        result = self.search(f"id:{document_id}")
        return result.hits > 0

    def search(self, *args, **kwargs):
        return self.client.search(*args, **kwargs)

    def delete(self, *args, **kwargs):
        self.client.delete(*args, **kwargs)
        self.client.commit()


class SolrValidator(Solr):
    def geometry(
        self, geometry, type: Literal["Dataset", "Dataservice"] = "Dataset"
    ) -> bool:
        dataset = {
            "id": "geomValidationTest",
            "type": ([f"http://www.w3.org/ns/dcat#{type}"]),
            "geometry": geometry,
            "mainTitle": "Geometry Validation Test",
        }

        try:
            self.client.add(dataset)
            return True
        except Exception as e:
            log.error(e)
            return False

    def close(self):
        # technically not necessary to check existence of test document,
        # but when urls are misconfigured, this will throw an error
        if self.exists("geomValidationTest"):
            self.delete(id="geomValidationTest")
