import logging
from .harvester_base import Harvester
from utils import sparql
from data_repositories.repository_n4eorganization import (
    RepositoryN4EOrganization,
)

log = logging.getLogger(__name__)


# harvester for Services https://nfdi4earth.pages.rwth-aachen.de/knowledgehub/nfdi4earth-kh-schema/Service/
class Service_Harvester(Harvester):
    sparql_query = """
        PREFIX fo: <http://www.w3.org/1999/XSL/Format#>
        PREFIX foaf: <http://xmlns.com/foaf/0.1/>
        PREFIX dc: <http://purl.org/dc/elements/1.1/>
        PREFIX vcard: <http://www.w3.org/2006/vcard/ns#>
        prefix dcat: <http://www.w3.org/ns/dcat#>
        prefix dct: <http://purl.org/dc/terms/>
        prefix n4e: <http://nfdi4earth.de/ontology/>
        PREFIX m4i: <http://w3id.org/nfdi4ing/metadata4ing#>
        PREFIX geo: <http://www.opengis.net/ont/geosparql#>
        prefix rdf: <http://www.w3.org/1999/02/22-rdf-syntax-ns#>
        PREFIX schema: <http://schema.org/>

        SELECT ?subject ?predicate ?object
            ?contactpoint_email
            ?contactpoint_url
            ?contact_fn
            ?contact_email
            ?serviceProvider_homepage ?serviceProvider_imprint ?serviceProvider_rorId ?serviceProvider_name
            ?serviceLocationPoint
            ?tangibleKPI_kpiType ?tangibleKPI_kpiValue ?tangibleKPI_kpiNotes
        WHERE {
            {
                # Page over distinct subjects first — avoids ORDER BY + OFFSET on the full
                # UNION result set which forces full materialization and causes timeouts.
                SELECT DISTINCT ?subject
                WHERE {
                    ?subject rdf:type n4e:Service .
                }
                OFFSET %d
                LIMIT %d
            }

            {
                ?subject ?predicate ?object .
                FILTER (?predicate NOT IN (dcat:contactPoint, n4e:sourceSystem))
            }
            UNION {
                VALUES ?predicate { dcat:contactPoint }
                ?subject dcat:contactPoint ?object .
                OPTIONAL { ?object vcard:hasEmail ?contactpoint_email . }
                OPTIONAL { ?object vcard:hasURL ?contactpoint_url . }
            }
            UNION {
                VALUES ?predicate { n4e:firstLevelSupportContact }
                ?subject n4e:firstLevelSupportContact ?object .
                OPTIONAL { ?object vcard:fn ?contact_fn . }
                OPTIONAL { ?object vcard:hasEmail ?contact_email . }
            }
            UNION {
                VALUES ?predicate { n4e:securityIncidentContact }
                ?subject n4e:securityIncidentContact ?object .
                OPTIONAL { ?object vcard:fn ?contact_fn . }
                OPTIONAL { ?object vcard:hasEmail ?contact_email . }
            }
            UNION {
                VALUES ?predicate { n4e:serviceOwner }
                ?subject n4e:serviceOwner ?object .
                OPTIONAL { ?object vcard:fn ?contact_fn . }
                OPTIONAL { ?object vcard:hasEmail ?contact_email . }
            }
            UNION {
                VALUES ?predicate { n4e:serviceManager }
                ?subject n4e:serviceManager ?object .
                OPTIONAL { ?object vcard:fn ?contact_fn . }
                OPTIONAL { ?object vcard:hasEmail ?contact_email . }
            }
            UNION {
                VALUES ?predicate { n4e:serviceProvider }
                ?subject n4e:serviceProvider ?object .
                OPTIONAL { ?object foaf:homepage ?serviceProvider_homepage . }
                OPTIONAL { ?object n4e:hasImprint ?serviceProvider_imprint . }
                OPTIONAL { ?object m4i:hasRorId ?serviceProvider_rorId . }
                OPTIONAL { ?object schema:name ?serviceProvider_name . }
            }
            UNION {
                VALUES ?predicate { n4e:serviceLocation }
                ?subject n4e:serviceLocation ?object .
                OPTIONAL { ?object geo:asWKT ?serviceLocationPoint . }
            }
            UNION {
                VALUES ?predicate { n4e:tangibleKPI }
                ?subject n4e:tangibleKPI ?object .
                OPTIONAL { ?object n4e:kpiType ?tangibleKPI_kpiType . }
                OPTIONAL { ?object n4e:kpiValue ?tangibleKPI_kpiValue . }
                OPTIONAL { ?object n4e:kpiNotes ?tangibleKPI_kpiNotes . }
            }
        }
    """

    def __init__(
        self, n4e_organizations_repo: RepositoryN4EOrganization, **kw
    ):
        super().__init__(**kw)
        self.n4e_organizations_repo = n4e_organizations_repo

    def harvest(self):
        limit = 5000
        # convert to list of repo documents for indexing
        services = {}  # repos dict

        i = 0
        # split sparql query by paging over distinct subjects
        # (sub-SELECT OFFSET/LIMIT)
        while True:
            query_splitted = self.sparql_query % (limit * i, limit)
            hits = sparql.execute_query(self.sparql_endpoint, query_splitted)

            subjects_before = len(services)
            self.parse_response(hits, services)
            new_subjects = len(services) - subjects_before

            i += 1

            # Stop when the sub-SELECT returned fewer subjects than the page size
            if new_subjects < limit:
                break

        services_list = []
        for (
            key,
            value,
        ) in services.items():  # transform repos dict to list for indexing
            service = value
            if "mainTitle" not in service and len(service["name"]) > 0:
                service["mainTitle"] = service["name"][0]
            service["mainTitle"] = service["mainTitle"].strip()
            services_list.append(service)

        return services_list

    def parse_response(
            self, hits, services
        ):
            for hit in hits:
                subject = hit["subject"]["value"]
                predicate = hit["predicate"]["value"]
                object = hit["object"]["value"]
                
                if subject not in services:
                    services[subject] = {}
                    services[subject]["uri"] = subject
                    services[subject]["id"] = self.getID(
                        subject
                    )  # use ID from triple store also in Solr to ensure stable IDs

                if predicate == "http://schema.org/name":  # name
                    if (
                        "xml:lang" not in hit["object"]
                        or hit["object"]["xml:lang"] == "en"
                    ):  # use international name for orga name
                        self.addValue(
                            dict=services[subject],
                            attribute="name",
                            value=object,
                        )
                        services[subject]["mainTitle"] = object  # mainTitle
                    if (
                        "name" not in services[subject]
                        or object not in services[subject]["name"]
                    ):  # prevent duplicates
                        self.addValue(
                            dict=services[subject],
                            attribute="name",
                            value=object,
                        )
                elif predicate == "http://schema.org/description":  # description
                    self.addValue(
                        dict=services[subject],
                        attribute="description",
                        value=object,
                    )
                elif predicate == "http://schema.org/additionalType":  # additionalType
                    self.addValue(
                        dict=services[subject],
                        attribute="additionalType",
                        value=object,
                    )
                elif predicate == "http://schema.org/keywords":  # keyword
                    self.addValue(
                        dict=services[subject],
                        attribute="keyword",
                        value=object,
                    )
                elif predicate == "http://schema.org/url":  # url
                    self.addValue(
                        dict=services[subject],
                        attribute="url",
                        value=object,
                    )
                elif predicate == "http://nfdi4earth.de/ontology/serviceType":  # serviceType
                    services[subject]["serviceType"] = object
                elif predicate == "http://nfdi4earth.de/ontology/serviceHost":  # serviceHost
                    services[subject]["serviceHost"] = object
                elif predicate == "http://www.w3.org/ns/dcat#contactPoint":  # contactPoint                   
                    if "contactpoint_email" in hit:
                        self.addValue(
                            services[subject],
                            "contactPoint" + self.flatten_separator + "email",
                            hit["contactpoint_email"]["value"],
                        )
                    if "contactpoint_url" in hit:
                        self.addValue(
                            services[subject],
                            "contactPoint" + self.flatten_separator + "url",
                            hit["contactpoint_url"]["value"],
                        )
                elif predicate == "http://nfdi4earth.de/ontology/firstLevelSupportContact":
                    if "contact_fn" in hit:
                        self.addValue(
                            services[subject],
                            "firstLevelSupportContact" + self.flatten_separator + "fullname",
                            hit["contact_fn"]["value"],
                        )
                    if "contact_email" in hit:
                        self.addValue(
                            services[subject],
                            "firstLevelSupportContact" + self.flatten_separator + "hasEmail",
                            hit["contact_email"]["value"],
                        )
                elif predicate == "http://nfdi4earth.de/ontology/serviceOwner":
                    if "contact_fn" in hit:
                        self.addValue(
                            services[subject],
                            "serviceOwner" + self.flatten_separator + "fullname",
                            hit["contact_fn"]["value"],
                        )
                    if "contact_email" in hit:
                        self.addValue(
                            services[subject],
                            "serviceOwner" + self.flatten_separator + "hasEmail",
                            hit["contact_email"]["value"],
                        )
                elif predicate == "http://nfdi4earth.de/ontology/serviceManager":
                    if "contact_fn" in hit:
                        self.addValue(
                            services[subject],
                            "serviceManager" + self.flatten_separator + "fullname",
                            hit["contact_fn"]["value"],
                        )
                    if "contact_email" in hit:
                        self.addValue(
                            services[subject],
                            "serviceManager" + self.flatten_separator + "hasEmail",
                            hit["contact_email"]["value"],
                        )
                elif predicate == "http://nfdi4earth.de/ontology/serviceProvider":
                    if "serviceProvider_homepage" in hit:
                        self.addValue(
                            services[subject],
                            "serviceProvider" + self.flatten_separator + "homepage",
                            hit["serviceProvider_homepage"]["value"],
                        )
                    if "serviceProvider_imprint" in hit:
                        self.addValue(
                            services[subject],
                            "serviceProvider" + self.flatten_separator + "imprint",
                            hit["serviceProvider_imprint"]["value"],
                        )
                    if "serviceProvider_rorId" in hit:
                        self.addValue(
                            services[subject],
                            "serviceProvider" + self.flatten_separator + "rorId",
                            hit["serviceProvider_rorId"]["value"],
                        )
                    if "serviceProvider_name" in hit:
                        self.addValue(
                            services[subject],
                            "serviceProvider" + self.flatten_separator + "name",
                            hit["serviceProvider_name"]["value"],
                        )
                elif predicate == "http://nfdi4earth.de/ontology/serviceLocation":
                    if "serviceLocationPoint" in hit:
                        self.addValue(
                            services[subject],
                            "serviceLocationPoint",
                            hit["serviceLocationPoint"]["value"],
                        )
                elif predicate == "http://nfdi4earth.de/ontology/securityIncidentContact":
                    if "contact_fn" in hit:
                        self.addValue(
                            services[subject],
                            "securityIncidentContact" + self.flatten_separator + "fullname",
                            hit["contact_fn"]["value"],
                        )
                    if "contact_email" in hit:
                        self.addValue(
                            services[subject],
                            "securityIncidentContact" + self.flatten_separator + "hasEmail",
                            hit["contact_email"]["value"],
                        )
                elif (
                    predicate == "http://nfdi4earth.de/ontology/sourceSystemID"
                ):  # sourceSystemID
                    self.addValue(
                        dict=services[subject],
                        attribute="sourceSystem" + self.flatten_separator + "id",
                        value=object,
                    )
                elif (
                    predicate == "http://nfdi4earth.de/ontology/sourceSystem"
                ):  # sourceSystem
                    if "sourceSystem_homepage" in hit:
                        self.addValue(
                            services[subject],
                            "sourceSystem" + self.flatten_separator + "homepage",
                            hit["sourceSystem_homepage"]["value"],
                        )
                    if "sourceSystem_title" in hit:
                        self.addValue(
                            services[subject],
                            "sourceSystem" + self.flatten_separator + "title",
                            hit["sourceSystem_title"]["value"],
                        )
                elif (
                    predicate == "http://nfdi4earth.de/ontology/sourceSystemURL"
                ):  # sourceSystemURL
                    self.addValue(
                        dict=services[subject],
                        attribute="sourceSystemURL",
                        value=object,
                    )
                elif (
                    predicate == "http://www.w3.org/2004/02/skos/core#altLabel"
                ):  # altLabel
                    self.addValue(
                        dict=services[subject],
                        attribute="altLabel",
                        value=object,
                    )
                elif (
                    predicate == "http://www.w3.org/1999/02/22-rdf-syntax-ns#type"
                ):  # type
                    self.addValue(
                        dict=services[subject], 
                        attribute="type", 
                        value=object
                    )
                elif (
                    predicate == "http://nfdi4earth.de/ontology/serviceType"
                ):  # serviceType
                    self.addValue(
                        dict=services[subject], 
                        attribute="serviceType", 
                        value=object
                    )
                elif (
                    predicate == "http://nfdi4earth.de/ontology/serviceCategory"
                ):  # serviceCategory
                    self.addValue(
                        dict=services[subject], 
                        attribute="serviceCategory", 
                        value=object
                    )
                elif (
                    predicate == "http://nfdi4earth.de/ontology/linkToDocumentation"
                ):  # linkToDocumentation
                    self.addValue(
                        dict=services[subject], 
                        attribute="linkToDocumentation", 
                        value=object
                    )
                elif (
                    predicate == "http://nfdi4earth.de/ontology/nameAbbreviation"
                ):  # nameAbbreviation
                    self.addValue(
                        dict=services[subject], 
                        attribute="nameAbbreviation", 
                        value=object
                    )
                elif (
                    predicate == "http://nfdi4earth.de/ontology/shortDescription"
                ):  # shortDescription
                    self.addValue(
                        dict=services[subject], 
                        attribute="shortDescription", 
                        value=object
                    )
                elif (
                    predicate == "http://nfdi4earth.de/ontology/chargeFree"
                ):  # chargeFree //BOOLEAN
                    if object == "1":
                        services[subject]["chargeFree"] = True
                    elif object == "0":
                        services[subject]["chargeFree"] = False 
                elif (
                    predicate == "http://nfdi4earth.de/ontology/nonProfit"
                ):  # nonProfit //BOOLEAN 
                    if object == "1":
                        services[subject]["nonProfit"] = True
                    elif object == "0":
                        services[subject]["nonProfit"] = False
                elif (
                    predicate == "http://nfdi4earth.de/ontology/adFree"
                ):  # adFree //BOOLEAN
                    if object == "1":
                        services[subject]["adFree"] = True
                    elif object == "0":
                        services[subject]["adFree"] = False
                elif (
                    predicate == "http://nfdi4earth.de/ontology/fees"
                ):  # fees 
                    self.addValue(
                        dict=services[subject], 
                        attribute="fees", 
                        value=object
                    )
                elif (
                    predicate == "http://nfdi4earth.de/ontology/serviceAccessType"
                ):  # serviceAccessType 
                    self.addValue(
                        dict=services[subject], 
                        attribute="serviceAccessType", 
                        value=object
                    )
                elif (
                    predicate == "http://nfdi4earth.de/ontology/logo"
                ):  # logo 
                    self.addValue(
                        dict=services[subject], 
                        attribute="logo", 
                        value=object
                    )
                elif (
                    predicate == "http://nfdi4earth.de/ontology/userEnablement"
                ):  # userEnablement 
                    self.addValue(
                        dict=services[subject], 
                        attribute="userEnablement", 
                        value=object
                    )
                elif (
                    predicate == "http://nfdi4earth.de/ontology/serviceEnablement"
                ):  # serviceEnablement 
                    self.addValue(
                        dict=services[subject], 
                        attribute="serviceEnablement", 
                        value=object
                    )
                elif (
                    predicate == "http://nfdi4earth.de/ontology/personalDataProcessingAndStorage"
                ):  # personalDataProcessingAndStorage 
                    self.addValue(
                        dict=services[subject], 
                        attribute="personalDataProcessingAndStorage", 
                        value=object
                    )
                elif (
                    predicate == "http://nfdi4earth.de/ontology/dataProtectionAndBackup"
                ):  # dataProtectionAndBackup 
                    self.addValue(
                        dict=services[subject], 
                        attribute="dataProtectionAndBackup", 
                        value=object
                    )
                elif (
                    predicate == "http://nfdi4earth.de/ontology/securityIncidentContact"
                ):  # securityIncidentContact  //ndoID
                    self.addValue(
                        dict=services[subject], 
                        attribute="securityIncidentContact", 
                        value=object
                    )
                elif (
                    predicate == "http://nfdi4earth.de/ontology/servicePrivacyPolicy"
                ):  # servicePrivacyPolicy 
                    self.addValue(
                        dict=services[subject], 
                        attribute="servicePrivacyPolicy", 
                        value=object
                    )
                elif (
                    predicate == "http://nfdi4earth.de/ontology/businessModel"
                ):  # businessModel 
                    self.addValue(
                        dict=services[subject], 
                        attribute="businessModel", 
                        value=object
                    )
                elif (
                    predicate == "http://nfdi4earth.de/ontology/GDPRCompliant"
                ):  # GDPRCompliant //BOOLEAN 
                    if object == "1":
                        services[subject]["GDPRCompliant"] = True
                    elif object == "0":
                        services[subject]["GDPRCompliant"] = False
                elif (
                    predicate == "http://nfdi4earth.de/ontology/servicePublicationConsent"
                ):  # servicePublicationConsent //BOOLEAN
                    if object == "1":
                        services[subject]["servicePublicationConsent"] = True
                    elif object == "0":
                        services[subject]["servicePublicationConsent"] = False
                elif (
                    predicate == "http://nfdi4earth.de/ontology/contactWithPortfolioManagement"
                ):  # contactWithPortfolioManagement 
                    self.addValue(
                        dict=services[subject], 
                        attribute="contactWithPortfolioManagement", 
                        value=object
                    )
                elif (
                    predicate == "http://nfdi4earth.de/ontology/limitations"
                ):  # limitations 
                    self.addValue(
                        dict=services[subject], 
                        attribute="limitations", 
                        value=object
                    )
                elif predicate == "http://nfdi4earth.de/ontology/tangibleKPI":
                    if "tangibleKPI_kpiType" in hit:
                        self.addValue(
                            services[subject],
                            "tangibleKPI" + self.flatten_separator + "kpiType",
                            hit["tangibleKPI_kpiType"]["value"],
                        )
                    if "tangibleKPI_kpiValue" in hit:
                        self.addValue(
                            services[subject],
                            "tangibleKPI" + self.flatten_separator + "kpiValue",
                            hit["tangibleKPI_kpiValue"]["value"],
                        )
                    if "tangibleKPI_kpiNotes" in hit:
                        self.addValue(
                            services[subject],
                            "tangibleKPI" + self.flatten_separator + "kpiNotes",
                            hit["tangibleKPI_kpiNotes"]["value"],
                        )
                elif (
                    predicate == "http://nfdi4earth.de/ontology/idHostingInstitution"
                ): #idHostingInstitution #hostingInstitution_name  #isN4EOperated
                    host_rorID = object
                    services[subject]["idHostingInstitution"] = host_rorID #idHostingInstitution

                    n4e_organization = self.n4e_organizations_repo.get_n4e_organization_by_rorID(host_rorID) #check if rorID belongs to a organization that is n4e member
                    if n4e_organization is not None:
                        services[subject]["isN4EOperated"] = True #isN4EOperated
                        services[subject]["hostingInstitution_name"] = n4e_organization["name"] #hostingInstitution_name  currently only for n4e operated services
                        #only index if `True`, do not index if `False`
