import logging

from data_repositories.repository_person import RepositoryPerson
from utils import sparql, flatten_dict, is_truthy

from .harvester_base import Harvester

log = logging.getLogger(__name__)


class Organization_Harvester(Harvester):
    sparql_query = """
        PREFIX fo: <http://www.w3.org/1999/XSL/Format#>
        PREFIX foaf: <http://xmlns.com/foaf/0.1/>
        PREFIX dc: <http://purl.org/dc/elements/1.1/>
        PREFIX geo: <http://www.opengis.net/ont/geosparql#>
        PREFIX dcat: <http://www.w3.org/ns/dcat#>
        PREFIX dct: <http://purl.org/dc/terms/>
        PREFIX n4e: <http://nfdi4earth.de/ontology/>
        PREFIX rdf: <http://www.w3.org/1999/02/22-rdf-syntax-ns#>
        PREFIX org: <http://www.w3.org/ns/org#>
        PREFIX schema: <http://schema.org/>
        PREFIX xsd: <http://www.w3.org/2001/XMLSchema#>

        SELECT ?subject ?predicate ?object ?geo_as_wkt ?isN4EMember
        WHERE {
            {
                SELECT DISTINCT ?subject
                WHERE {
                ?subject rdf:type foaf:Organization .
                BIND(STRAFTER(STR(?subject), "/objects/") AS ?id)
                FILTER(STRSTARTS(?id, "n4e/"))
                FILTER(!CONTAINS(?id, "jsonPointer"))
                FILTER EXISTS { ?subject n4e:sourceSystem ?source }
                }
                OFFSET %s
                LIMIT %s
            }

            ?subject ?predicate ?object .

            OPTIONAL {
                ?subject geo:hasGeometry ?geometry .
                ?geometry geo:asWKT ?geo_as_wkt .
            }

            OPTIONAL {
                ?subject org:hasMembership ?membership .
                ?membership org:organization ?n4eproject .
                ?n4eproject schema:url "https://nfdi4earth.de/"^^xsd:anyURI .
                BIND(true AS ?isN4EMember)
            }
        }
    """

    def __init__(self, persons_repo: RepositoryPerson, **kw):
        super().__init__(**kw)
        self.persons_repo = persons_repo

    def harvest(self):
        limit = 10000
        organizations = {}
        issuborganization = []
        hasN4Econtact = []

        i = 0
        hits = {}
        # split sparql query
        while True:
            query_splitted = self.sparql_query % (limit * i, limit)
            hits = sparql.execute_query(self.sparql_endpoint, query_splitted)
            self.parse_response(
                hits, organizations, issuborganization, hasN4Econtact
            )
            i = i + 1

            if len(hits) < limit:
                break

        self.resolve_organizations(
            issuborganization,
            organizations,
            organizations,
            attribute="subOrganizationOf",
        )  # assign name of parent to subOrganizationOf attribute
        self.resolve_contactperson(
            hasN4Econtact, organizations, attribute="nfdi4EarthContactPerson"
        )

        organization_list = []
        for key, value in organizations.items():  # transform orga dict to list for indexing
            organization = value

            # clean geometry: if more than one geometry is present,
            # keep only the first one (should not happen, but just in case)
            geom = organization.get("geometry", [])
            if len(geom) > 1:
                organization["geometry"] = geom[:1]

            # clean rorId: if more than one rorId is present,
            # keep only unique ones (should not happen, but just in case)
            rorid = organization.get("rorId", [])
            if len(rorid) > 1:
                organization["rorId"] = list(set(rorid))

            # Transform locations
            localities = organization.get("locality", [])
            countries = organization.get("countryName", [])
            complete_locations = []

            for loc, country in zip(localities, countries):
                complete_locations.append(f"{loc}, {country}")

            # Filter duplication
            organization["location"] = list(dict.fromkeys(complete_locations))
            organization["locality"] = list(dict.fromkeys(localities))
            organization["countryName"] = list(dict.fromkeys(countries))

            # ensure mainTitle
            if (
                "mainTitle" not in organization
                and len(organization["name_alt"]) > 0
            ):
                organization["mainTitle"] = organization["name_alt"][0]
            organization["mainTitle"] = organization["mainTitle"].strip()
            organization_list.append(organization)

        return organization_list

    def resolve_contactperson(
        self, hascontact_list, organizations_dict, attribute
    ):
        # person_list = [t[1] for t in hascontact_list]#all contact persons (URIs)
        # persons = self.query_persons(person_list, organizations_dict) #retrieve complete contact person info from sparql endpoint

        for (
            subject
        ) in hascontact_list:  # assign contact person to organization
            person_uri = subject[1]
            person = self.persons_repo.get_person(person_uri)
            if person is not None:
                organizations_dict[subject[0]][
                    attribute
                ] = person  # max. one contact person allowed according to schema
                organizations_dict[subject[0]] = flatten_dict(
                    organizations_dict[subject[0]], sep=self.flatten_separator
                )

    # get organization from harvested organizations and assign organization name to attribute (e.g isSubOrganizationOf, contact's affiliation)
    # subject_list -> list of tuple [(subj123, orgaXYZ)]
    # attribute -> assign organization name to this attribute
    def resolve_organizations(
        self, subject_list, lookup_dict, assignto_dict, attribute
    ):
        for subject in subject_list:
            if subject[1] in lookup_dict and "name" in lookup_dict[subject[1]]:
                organization_name = lookup_dict[subject[1]]["name"]
                # assign orga name
                if attribute not in assignto_dict[subject[0]]:
                    assignto_dict[subject[0]][attribute] = []
                assignto_dict[subject[0]][attribute].extend(organization_name)

    def does_object_exist(self, value, attribute: str, data: dict):
        return attribute in data and value in data[attribute]

    def parse_response(
        self, hits, organizations, issuborganization, hasN4Econtact
    ):
        PREDICATES = {
            "http://xmlns.com/foaf/0.1/homepage": "homepage",
            "http://www.w3.org/2002/07/owl#sameAs": "sameAs",
            "http://w3id.org/nfdi4ing/metadata4ing#hasRorId": "rorId",
            "http://www.w3.org/2004/02/skos/core#altLabel": "altLabel",
            "http://www.w3.org/1999/02/22-rdf-syntax-ns#type": "type",
            "http://nfdi4earth.de/ontology/sourceSystemURL": "sourceSystemURL",
            "http://nfdi4earth.de/ontology/hasSignedCommitment": "hasSignedCommitment",
            "http://nfdi4earth.de/ontology/sourceSystemID": "sourceSystem" + self.flatten_separator + "id"
        }

        for hit in hits:
            subject = hit["subject"]["value"]
            predicate = hit["predicate"]["value"]
            object = hit["object"]["value"]

            if subject not in organizations:
                organizations[subject] = {}
                organizations[subject]["uri"] = subject
                organizations[subject]["id"] = self.getID(
                    subject
                )  # use ID from triple store also in Solr to ensure stable IDs
                organizations[subject]["locality"] = []
                organizations[subject]["countryName"] = []

            # set geometry if available and not already set
            if (
                predicate == "http://www.opengis.net/ont/geosparql#hasGeometry"
                and (
                    "geometry" not in organizations[subject]
                    or hit["geo_as_wkt"]["value"]
                    not in organizations[subject]["geometry"]
                )
            ):
                self.addValue(
                    dict=organizations[subject],
                    attribute="geometry",
                    value=hit["geo_as_wkt"]["value"],
                )

            # set membership in N4E project
            is_n4e_member = hit.get("isN4EMember", {}).get("value", None)
            if (
                is_n4e_member is not None
                and "isN4EMember" not in organizations[subject]
            ):
                organizations[subject]["isN4EMember"] = is_truthy(
                    is_n4e_member
                )

            if predicate == "http://schema.org/name":  # name
                if (
                    ("xml:lang" not in hit["object"]
                    or hit["object"]["xml:lang"] == "en")
                    and not self.does_object_exist(object, "name", organizations[subject])
                ):  # use international name for orga name
                    self.addValue(
                        dict=organizations[subject],
                        attribute="name",
                        value=object,
                    )
                    organizations[subject]["mainTitle"] = object  # mainTitle
                if (
                    not self.does_object_exist(object, "name_alt", organizations[subject])
                ):  # prevent duplicates
                    self.addValue(
                        dict=organizations[subject],
                        attribute="name_alt",
                        value=object,
                    )

            elif predicate == "http://www.w3.org/2006/vcard/ns#locality":
                organizations[subject]["locality"].append(object)

            elif predicate == "http://www.w3.org/2006/vcard/ns#country-name":
                organizations[subject]["countryName"].append(object)

            elif predicate in PREDICATES:
                attribute = PREDICATES[predicate]
                if not self.does_object_exist(object, attribute, organizations[subject]):
                    self.addValue(
                        dict=organizations[subject],
                        attribute=attribute,
                        value=object)
            elif (
                predicate == "http://www.w3.org/ns/org#subOrganizationOf"
                and (subject, object) not in issuborganization
            ):  # subOrganizationOf
                issuborganization.append(
                    (subject, object)
                )  # store reference, resolve later
            elif (
                predicate
                == "http://nfdi4earth.de/ontology/hasNFDI4EarthContactPerson"
                and (subject, object) not in hasN4Econtact
            ):  # NFDI4EarthContactPerson
                hasN4Econtact.append(
                    (subject, object)
                )  # store, resolve contact info later
