from setuptools import find_packages, setup

setup(
    name="OneStop4All-Harvester",
    version="2.8.0.dev13",
    description="Library to harvest data from NFDI4Earth-KnowledgeHub to OneStop4All-Index",
    author="Markus Konkol, Arne Vogt, Tom Niers, Ralf Klammer",
    author_email="m.konkol@52north.org, a.vogt@52north.org, tom.niers@tu-dresden.de, ralf.klammer@tu-dresden.de",
    packages=find_packages(),
    install_requires=[
        "click",
        "sparqlwrapper~= 2.0.0",
        "pysolr~= 3.11.0",
        "jproperties~= 2.1.1 ",
        "geomet ~= 1.1.0",
        "shapely ~= 2.0.5",
    ],
    extras_require={
        "airflow": [
            "apache-airflow==3.1.7",
            "apache-airflow-providers-amazon[s3fs]",
        ],
    },
    include_package_data=True,
    entry_points={
        "console_scripts": [
            "harvest = utils.cli:main",
            "debug_indexing = utils.cli:debug",
        ]
    },
)
