import os
import stat
import subprocess
import sys
from pathlib import Path


def main():
    binary = Path(__file__).parent / "bin" / "pindock"

    if sys.platform != "win32":
        m = binary.stat().st_mode
        if not (m & stat.S_IXUSR):
            binary.chmod(m | stat.S_IXUSR | stat.S_IXGRP | stat.S_IXOTH)

    b = str(binary)

    if sys.platform == "win32":
        sys.exit(subprocess.call([b, *sys.argv[1:]]))
    else:
        os.execvp(b, [b, *sys.argv[1:]])
