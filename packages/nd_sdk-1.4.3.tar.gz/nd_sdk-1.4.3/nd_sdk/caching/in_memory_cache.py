from .base import CacheProvider
from .env_fallback import EnvFallbackMixin


class InMemoryCache(EnvFallbackMixin, CacheProvider):

    def __init__(self, environment: str = "dev"):
        self.store = {}
        self.environment = environment

    def get(self, key: str):
        value = self.store.get(key)
        if value is not None:
            return value

        normalized_key = self._normalize_cache_key(key)
        value = self.store.get(normalized_key)
        if value is not None:
            return value

        return self.get_from_env(normalized_key)

    def set(self, key: str, value, ttl=None):
        normalized_key = self._normalize_cache_key(key)
        self.store[normalized_key] = value
        return True
