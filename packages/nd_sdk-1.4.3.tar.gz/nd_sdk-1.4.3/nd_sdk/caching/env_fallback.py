"""Environment fallback helpers for cache providers.

When cache data is missing or the cache backend is unavailable, the SDK can
resolve the same logical key from environment variables by replacing ':' with
'__'.

Example:
    Cache key: dev:servicename:pkey
    Env key:   dev__servicename__pkey
"""

import fnmatch
import json
import os
from typing import Any, Dict, Optional


class EnvFallbackMixin:
    """Reusable fallback behavior for cache providers."""

    environment: str = "dev"

    def _normalize_cache_key(self, key: str) -> str:
        """Return a fully-qualified cache key with the environment prefix."""
        if key is None:
            return key

        key = str(key)
        env_prefix = f"{self.environment}:"

        # Avoid double-prefixing when caller already sends dev:service:key.
        if key == self.environment or key.startswith(env_prefix):
            return key

        return f"{env_prefix}{key}"

    def _cache_key_to_env_key(self, key: str) -> str:
        """Convert cache key format to environment variable format."""
        normalized_key = self._normalize_cache_key(key)
        return normalized_key.replace(":", "__")

    def _read_env_value(self, env_key: str) -> Optional[Any]:
        """Read an environment value with exact and uppercase fallback."""
        if env_key in os.environ:
            return self._deserialize_env_value(os.environ[env_key])

        upper_env_key = env_key.upper()
        if upper_env_key in os.environ:
            return self._deserialize_env_value(os.environ[upper_env_key])

        return None

    @staticmethod
    def _deserialize_env_value(value: str) -> Any:
        """Return ENV value, parsing only JSON object/array strings safely."""
        if value is None:
            return None

        stripped_value = value.strip()
        if stripped_value.startswith("{") or stripped_value.startswith("["):
            try:
                return json.loads(stripped_value)
            except json.JSONDecodeError:
                return value

        return value

    def get_from_env(self, key: str) -> Optional[Any]:
        """Fetch a single cache key from ENV using ':' -> '__' conversion."""
        env_key = self._cache_key_to_env_key(key)
        return self._read_env_value(env_key)

    def get_multiple_from_env_by_pattern(self, pattern: str) -> Dict[str, Any]:
        """Fetch ENV values matching a cache-style wildcard pattern."""
        env_pattern = self._cache_key_to_env_key(pattern)
        upper_env_pattern = env_pattern.upper()
        results: Dict[str, Any] = {}

        for env_key, env_value in os.environ.items():
            if fnmatch.fnmatch(env_key, env_pattern) or fnmatch.fnmatch(env_key, upper_env_pattern):
                cache_style_key = env_key.lower().replace("__", ":")
                results[cache_style_key] = self._deserialize_env_value(env_value)

        return results

    def get_from_env_by_pattern(self, pattern: str) -> Optional[Any]:
        """Fetch the first ENV value matching a cache-style wildcard pattern."""
        results = self.get_multiple_from_env_by_pattern(pattern)
        if not results:
            return None
        return next(iter(results.values()))
