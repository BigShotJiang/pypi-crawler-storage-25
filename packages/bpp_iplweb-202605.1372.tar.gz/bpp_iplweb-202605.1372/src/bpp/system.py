"""Ustawienia systemowe

groups - lista grup wraz z uprawnieniami do edycji poszczególnych obiektów.
"""

from dbtemplates.models import Template
from django.contrib.auth import get_user_model
from django.contrib.auth.models import Group, Permission
from django.contrib.contenttypes.models import ContentType
from django.contrib.sites.models import Site
from django.db import transaction
from dynamic_admin_columns.models import ModelAdmin, ModelAdminColumn
from favicon.models import Favicon, FaviconImg
from flexible_reports import models as flexible_models
from formdefaults.models import FormFieldRepresentation, FormRepresentation
from multiseek.models import SearchForm

from bpp.const import (
    GR_RAPORTY_WYSWIETLANIE,
    GR_WPROWADZANIE_DANYCH,
    GR_ZGLOSZENIA_PUBLIKACJI,
)
from bpp.models import (
    Autor,
    Autor_Dyscyplina,
    Autor_Jednostka,
    BppMultiseekVisibility,
    Charakter_Formalny,
    Crossref_Mapper,
    Dyscyplina_Naukowa,
    Dyscyplina_Zrodla,
    Element_Repozytorium,
    Funkcja_Autora,
    Grant,
    Grant_Rekordu,
    Grupa_Pracownicza,
    Jednostka,
    Jezyk,
    Kierunek_Studiow,
    Patent,
    Patent_Autor,
    Praca_Doktorska,
    Praca_Habilitacyjna,
    Punktacja_Zrodla,
    Redakcja_Zrodla,
    Rodzaj_Prawa_Patentowego,
    Rodzaj_Zrodla,
    Status_Korekty,
    Typ_KBN,
    Typ_Odpowiedzialnosci,
    Tytul,
    Uczelnia,
    Ukryj_Status_Korekty,
    Wydawnictwo_Ciagle,
    Wydawnictwo_Ciagle_Autor,
    Wydawnictwo_Ciagle_Streszczenie,
    Wydawnictwo_Ciagle_Zewnetrzna_Baza_Danych,
    Wydawnictwo_Zwarte,
    Wydawnictwo_Zwarte_Autor,
    Wydawnictwo_Zwarte_Streszczenie,
    Wydawnictwo_Zwarte_Zewnetrzna_Baza_Danych,
    Wydzial,
    Wymiar_Etatu,
    Zewnetrzna_Baza_Danych,
    Zrodlo,
    Zrodlo_Informacji,
)
from bpp.models.konferencja import Konferencja
from bpp.models.nagroda import Nagroda, OrganPrzyznajacyNagrody
from bpp.models.openaccess import (
    Czas_Udostepnienia_OpenAccess,
    Licencja_OpenAccess,
    Tryb_OpenAccess_Wydawnictwo_Ciagle,
    Tryb_OpenAccess_Wydawnictwo_Zwarte,
    Wersja_Tekstu_OpenAccess,
)
from bpp.models.praca_habilitacyjna import Publikacja_Habilitacyjna
from bpp.models.profile import BppUser
from bpp.models.seria_wydawnicza import Seria_Wydawnicza
from bpp.models.struktura import Jednostka_Wydzial
from bpp.models.system import Charakter_PBN
from bpp.models.wydawca import Poziom_Wydawcy, Wydawca
from deduplikator_autorow.models import IgnoredScientist, LogScalania, NotADuplicate
from ewaluacja_common.models import Rodzaj_Autora
from ewaluacja_liczba_n.models import IloscUdzialowDlaAutoraZaRok, LiczbaNDlaUczelni
from import_polon.models import ImportPolonOverride
from miniblog.models import Article
from pbn_api.models import (
    Conference,
    Discipline,
    Institution,
    Journal,
    OswiadczenieInstytucji,
    Publication,
    Publisher,
    Scientist,
    SentData,
)
from pbn_api.models.discipline import DisciplineGroup
from rozbieznosci_dyscyplin.models import RozbieznosciView, RozbieznosciZrodelView
from zglos_publikacje.models import (
    Obslugujacy_Zgloszenia_Wydzialow,
    Zgloszenie_Publikacji,
    Zgloszenie_Publikacji_Autor,
)

User = get_user_model()

groups = {
    "dane systemowe": [
        Charakter_Formalny,
        Crossref_Mapper,
        Kierunek_Studiow,
        Charakter_PBN,
        Funkcja_Autora,
        Zrodlo_Informacji,
        Jezyk,
        Typ_Odpowiedzialnosci,
        Rodzaj_Zrodla,
        Status_Korekty,
        Tytul,
        Typ_KBN,
        Tryb_OpenAccess_Wydawnictwo_Ciagle,
        Tryb_OpenAccess_Wydawnictwo_Zwarte,
        Czas_Udostepnienia_OpenAccess,
        Licencja_OpenAccess,
        Wersja_Tekstu_OpenAccess,
        OrganPrzyznajacyNagrody,
        Rodzaj_Prawa_Patentowego,
        Dyscyplina_Naukowa,
        Zewnetrzna_Baza_Danych,
        Grant,
        FormFieldRepresentation,
        FormRepresentation,
        Grupa_Pracownicza,
        Wymiar_Etatu,
        Journal,
        Institution,
        Conference,
        Publisher,
        Scientist,
        SentData,
        Discipline,
        Publication,
        OswiadczenieInstytucji,
        DisciplineGroup,
        BppMultiseekVisibility,
        Rodzaj_Autora,
        ImportPolonOverride,
    ],
    "struktura": [
        Uczelnia,
        LiczbaNDlaUczelni,
        Wydzial,
        Jednostka,
        Jednostka_Wydzial,
        Ukryj_Status_Korekty,
    ],
    GR_WPROWADZANIE_DANYCH: [
        Zrodlo,
        Autor,
        Autor_Dyscyplina,
        Wydawnictwo_Ciagle,
        Wydawnictwo_Zwarte,
        Punktacja_Zrodla,
        Dyscyplina_Zrodla,
        Wydawnictwo_Ciagle_Autor,
        Wydawnictwo_Zwarte_Autor,
        Autor_Jednostka,
        Redakcja_Zrodla,
        Praca_Doktorska,
        Praca_Habilitacyjna,
        Patent,
        Patent_Autor,
        Publikacja_Habilitacyjna,
        Konferencja,
        Seria_Wydawnicza,
        Nagroda,
        Wydawnictwo_Ciagle_Zewnetrzna_Baza_Danych,
        Wydawnictwo_Ciagle_Streszczenie,
        Wydawnictwo_Zwarte_Zewnetrzna_Baza_Danych,
        Wydawnictwo_Zwarte_Streszczenie,
        Wydawca,
        Poziom_Wydawcy,
        Grant_Rekordu,
        Element_Repozytorium,
        IloscUdzialowDlaAutoraZaRok,
        RozbieznosciView,
        RozbieznosciZrodelView,
        NotADuplicate,
        LogScalania,
        IgnoredScientist,
    ],
    "indeks autorów": [Autor, Autor_Jednostka],
    "administracja": [
        User,
        Group,
        SearchForm,
        Obslugujacy_Zgloszenia_Wydzialow,
        ModelAdminColumn,
        ModelAdmin,
    ],
    "web": [Site, Favicon, FaviconImg, Article, Template],
    "raporty": [
        flexible_models.Report,
        flexible_models.ReportElement,
        flexible_models.Table,
        flexible_models.Column,
        flexible_models.Datasource,
        flexible_models.ColumnOrder,
    ],
    GR_ZGLOSZENIA_PUBLIKACJI: [Zgloszenie_Publikacji, Zgloszenie_Publikacji_Autor],
    GR_RAPORTY_WYSWIETLANIE: [],
}

# Słownik na podstawie którego dodajemy użytkowników z danej grupy automatycznie
# do innej:
groups_auto_add = {
    GR_WPROWADZANIE_DANYCH: [
        GR_RAPORTY_WYSWIETLANIE,
    ]
}


@transaction.atomic
def odtworz_grupy(**kwargs):
    for name, models in groups.items():
        group, _ = Group.objects.get_or_create(name=name)

        permission_ids = list(
            Permission.objects.filter(
                content_type__in=[
                    ContentType.objects.get_for_model(model) for model in models
                ]
            ).values_list("id", flat=True)
        )
        group.permissions.set(permission_ids)

    all_groups = {g.name: g for g in Group.objects.all()}
    for trigger_name, extra_names in groups_auto_add.items():
        trigger_group = all_groups.get(trigger_name)
        if trigger_group is None:
            continue
        for extra_name in extra_names:
            extra_group = all_groups.get(extra_name)
            if extra_group is None:
                continue
            for user in BppUser.objects.filter(groups=trigger_group):
                user.groups.add(extra_group)
