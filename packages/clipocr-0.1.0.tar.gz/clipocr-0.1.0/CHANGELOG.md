# Changelog

All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.1.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [Unreleased]

## [0.1.0] - 2026-05-17

### Added
- Initial release.
- OCR from image file path: `ocr(path)`.
- OCR from system clipboard: `ocr_clipboard()` (macOS / Windows / Linux).
- Bounding box (`bbox`) for every recognized text block.
- CLI command `clipocr`:
  - `clipocr <path>`
  - `clipocr --clip`
  - `clipocr <path> --json`
- Cross-platform clipboard adapter (PIL `ImageGrab` on macOS/Windows, `xclip`/`wl-paste` on Linux).
- 90%+ test coverage with mocked engine and clipboard adapters.
- GitHub Actions CI on macOS / Windows / Ubuntu × Python 3.8–3.13.
