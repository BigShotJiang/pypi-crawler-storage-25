"""Core OCR logic. Wraps RapidOCR but isolates the hard dep behind a thin shim."""
from __future__ import annotations

import contextlib
import os
from pathlib import Path
from typing import Any, Protocol, Union

from .types import BBox, Block, OcrResult

PathLike = Union[str, os.PathLike]


class _OcrEngine(Protocol):
    """Minimal protocol the underlying engine must implement.

    Two output shapes are supported:

    * Legacy ``rapidocr-onnxruntime`` returns ``(items, elapse)`` where
      ``items`` is a list of ``[box, text, confidence]`` (or ``None``).
    * New ``rapidocr`` (>=2.x) returns a single ``RapidOCROutput`` object with
      ``.boxes`` / ``.txts`` / ``.scores`` attributes.
    """

    def __call__(self, img: Any) -> Any: ...


_engine_singleton: _OcrEngine | None = None


def _silence_third_party_logs() -> None:
    """RapidOCR is chatty by default. Silence its INFO logs unless the user
    explicitly sets ``CLIPOCR_VERBOSE=1``.

    Must be called both before and after importing the engine because the
    library re-acquires its logger inside the ``RapidOCR()`` constructor.
    """
    import logging
    import os

    if os.environ.get("CLIPOCR_VERBOSE"):
        return

    for name in ("RapidOCR", "rapidocr", "ppocr", "onnxruntime"):
        logger = logging.getLogger(name)
        logger.setLevel(logging.WARNING)
        # Drop any handlers the library installed on its own logger
        for handler in list(logger.handlers):
            logger.removeHandler(handler)
        logger.propagate = False


def _load_default_engine() -> _OcrEngine:
    """Lazy-import RapidOCR so the package can be imported without the heavy
    dep (e.g. for unit tests with a mocked engine)."""
    global _engine_singleton
    if _engine_singleton is not None:
        return _engine_singleton

    # Silence BEFORE importing — pre-creates the logger and removes its handlers
    # so the library does not get its INFO StreamHandler by default.
    _silence_third_party_logs()

    try:
        from rapidocr import RapidOCR  # type: ignore
    except ImportError:
        try:
            from rapidocr_onnxruntime import RapidOCR  # type: ignore
        except ImportError as exc:  # pragma: no cover - exercised in env without dep
            raise RuntimeError(
                "rapidocr is required. Install with: pip install clipocr"
            ) from exc

    # And again AFTER, in case the library re-attached handlers on import.
    _silence_third_party_logs()

    _engine_singleton = RapidOCR()  # type: ignore[call-arg]
    return _engine_singleton


def _to_int_bbox(box: Any) -> BBox:
    """RapidOCR returns a 4-point polygon: [[x1,y1],[x2,y2],[x3,y3],[x4,y4]].
    We collapse it into an axis-aligned (xmin, ymin, xmax, ymax)."""
    xs = [int(round(p[0])) for p in box]
    ys = [int(round(p[1])) for p in box]
    return (min(xs), min(ys), max(xs), max(ys))


def _image_size(image_path: PathLike) -> tuple[int, int]:
    try:
        from PIL import Image  # local import keeps cold start light
        with Image.open(image_path) as img:
            return img.size  # (width, height)
    except Exception:  # pragma: no cover - corrupt files / missing PIL backend
        return (0, 0)


def _parse_engine_result(
    raw: list[Any] | None,
    image_size: tuple[int, int],
) -> OcrResult:
    """Convert RapidOCR raw output into an OcrResult."""
    if not raw:
        return OcrResult(text="", blocks=[], confidence=0.0, image_size=image_size)

    blocks: list[Block] = []
    for item in raw:
        # Accept either [box, text, conf] or dict-like results for forward compat.
        if isinstance(item, dict):
            box = item.get("box") or item.get("bbox")
            text = item.get("text", "")
            conf = float(item.get("score", item.get("confidence", 0.0)))
        else:
            box, text, conf = item[0], item[1], float(item[2])

        if not text:
            continue
        blocks.append(Block(text=text, bbox=_to_int_bbox(box), confidence=conf))

    if not blocks:
        return OcrResult(text="", blocks=[], confidence=0.0, image_size=image_size)

    # Reading-order sort: top-to-bottom, then left-to-right, with row clustering.
    blocks_sorted = _sort_reading_order(blocks)
    text = "\n".join(b.text for b in blocks_sorted)
    avg_conf = sum(b.confidence for b in blocks_sorted) / len(blocks_sorted)

    return OcrResult(
        text=text,
        blocks=blocks_sorted,
        confidence=round(avg_conf, 4),
        image_size=image_size,
    )


def _sort_reading_order(blocks: list[Block], row_tolerance: float = 0.5) -> list[Block]:
    """Group blocks into rows by y-overlap, then order each row left-to-right."""
    if not blocks:
        return []
    # Sort by y first
    by_y = sorted(blocks, key=lambda b: b.bbox[1])
    rows: list[list[Block]] = []
    for blk in by_y:
        placed = False
        height = max(blk.bbox[3] - blk.bbox[1], 1)
        for row in rows:
            row_y = sum((b.bbox[1] + b.bbox[3]) / 2 for b in row) / len(row)
            blk_y = (blk.bbox[1] + blk.bbox[3]) / 2
            if abs(blk_y - row_y) <= height * row_tolerance:
                row.append(blk)
                placed = True
                break
        if not placed:
            rows.append([blk])
    out: list[Block] = []
    for row in rows:
        out.extend(sorted(row, key=lambda b: b.bbox[0]))
    return out


def _normalize_engine_output(raw: Any) -> list[Any] | None:
    """Reduce both legacy and new RapidOCR outputs to a single list shape.

    Returns a list of ``[box, text, score]`` triples, or ``None``/``[]`` when
    the engine found nothing.
    """
    if raw is None:
        return None

    # Legacy tuple shape: (items, elapse)
    if isinstance(raw, tuple) and len(raw) == 2 and not hasattr(raw, "boxes"):
        return raw[0]

    # New object shape: RapidOCROutput with boxes / txts / scores
    if hasattr(raw, "boxes") and hasattr(raw, "txts"):
        boxes = getattr(raw, "boxes", None)
        txts = getattr(raw, "txts", None)
        scores = getattr(raw, "scores", None)
        if boxes is None or txts is None:
            return None
        items: list[Any] = []
        for i, txt in enumerate(txts):
            if i >= len(boxes):
                break
            score = float(scores[i]) if scores is not None and i < len(scores) else 0.0
            items.append([boxes[i], txt, score])
        return items

    # Already a list-like of items
    if isinstance(raw, list):
        return raw

    return None


def ocr(
    image: PathLike,
    *,
    engine: _OcrEngine | None = None,
) -> OcrResult:
    """Run OCR on an image file.

    Parameters
    ----------
    image:
        Path to an image file (PNG / JPG / BMP / WEBP).
    engine:
        Optional injected engine. Useful for tests. If omitted, a singleton
        RapidOCR instance is created lazily and reused.
    """
    image_path = Path(image)
    if not image_path.exists():
        raise FileNotFoundError(f"image not found: {image_path}")
    if not image_path.is_file():
        raise IsADirectoryError(f"not a file: {image_path}")

    engine_to_use = engine if engine is not None else _load_default_engine()
    raw = engine_to_use(str(image_path))
    items = _normalize_engine_output(raw)
    return _parse_engine_result(items, _image_size(image_path))


def ocr_clipboard(
    *,
    engine: _OcrEngine | None = None,
    grabber: Any = None,
) -> OcrResult:
    """Run OCR on the image currently held in the system clipboard.

    Parameters
    ----------
    engine:
        Optional injected engine (same semantics as :func:`ocr`).
    grabber:
        Optional clipboard grabber callable returning a path to a temp PNG.
        Defaults to :func:`clipocr.clipboard.grab_clipboard_image`.
    """
    if grabber is None:
        from .clipboard import grab_clipboard_image as grabber  # type: ignore

    image_path = grabber()
    try:
        return ocr(image_path, engine=engine)
    finally:
        with contextlib.suppress(OSError):
            os.remove(image_path)
