"""Public typed data classes returned by clipocr."""
from __future__ import annotations

from dataclasses import asdict, dataclass, field
from typing import Any, Tuple

# Bounding box: (x_min, y_min, x_max, y_max)
BBox = Tuple[int, int, int, int]


@dataclass(frozen=True)
class Block:
    """A single recognized text region."""

    text: str
    bbox: BBox
    confidence: float

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


@dataclass(frozen=True)
class OcrResult:
    """The full OCR result for one image."""

    text: str
    blocks: list[Block]
    confidence: float
    engine: str = "rapidocr"
    image_size: tuple[int, int] = field(default=(0, 0))  # (width, height)

    def to_dict(self) -> dict[str, Any]:
        return {
            "text": self.text,
            "blocks": [b.to_dict() for b in self.blocks],
            "confidence": self.confidence,
            "engine": self.engine,
            "image_size": list(self.image_size),
        }

    @property
    def is_empty(self) -> bool:
        return not self.blocks
