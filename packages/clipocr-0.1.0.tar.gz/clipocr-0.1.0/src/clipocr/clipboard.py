"""Cross-platform clipboard image grabber.

Returns a path to a freshly-saved temp PNG file. The caller owns the file and
must delete it.

Strategy:
    * macOS / Windows: use Pillow's ImageGrab.grabclipboard().
    * Linux (Wayland):  use ``wl-paste`` if available.
    * Linux (X11):      use ``xclip`` if available.
"""
from __future__ import annotations

import contextlib
import os
import platform
import shutil
import subprocess
import tempfile


class ClipboardImageError(RuntimeError):
    """Raised when no image can be retrieved from the clipboard."""


def _save_pillow_image(image, suffix: str = ".png") -> str:
    fd, path = tempfile.mkstemp(prefix="clipocr-", suffix=suffix)
    os.close(fd)
    image.save(path, format="PNG")
    return path


def _grab_pillow() -> str:
    """macOS / Windows path. Lazily imports Pillow."""
    try:
        from PIL import ImageGrab  # type: ignore
    except ImportError as exc:  # pragma: no cover
        raise ClipboardImageError("Pillow is required for clipboard OCR") from exc

    img = ImageGrab.grabclipboard()
    if img is None:
        raise ClipboardImageError("clipboard does not contain an image")

    # On some platforms grabclipboard() returns a list of file paths instead.
    if isinstance(img, list):
        if not img:
            raise ClipboardImageError("clipboard does not contain an image")
        try:
            from PIL import Image  # type: ignore
            with Image.open(img[0]) as opened:
                return _save_pillow_image(opened.copy())
        except Exception as exc:
            raise ClipboardImageError(f"clipboard file not readable: {img[0]}") from exc

    return _save_pillow_image(img)


def _grab_linux() -> str:
    """Linux path. Tries Wayland first, then X11."""
    if shutil.which("wl-paste"):
        return _grab_via_command(["wl-paste", "--type", "image/png"])
    if shutil.which("xclip"):
        return _grab_via_command(["xclip", "-selection", "clipboard", "-t", "image/png", "-o"])
    raise ClipboardImageError(
        "no clipboard backend found on Linux. Install wl-paste (Wayland) or xclip (X11)."
    )


def _grab_via_command(cmd: list) -> str:
    fd, path = tempfile.mkstemp(prefix="clipocr-", suffix=".png")
    os.close(fd)
    try:
        with open(path, "wb") as out:
            proc = subprocess.run(cmd, stdout=out, stderr=subprocess.PIPE, check=False)
        if proc.returncode != 0 or os.path.getsize(path) == 0:
            err = proc.stderr.decode("utf-8", errors="replace") if proc.stderr else ""
            raise ClipboardImageError(
                f"clipboard read failed (cmd={cmd[0]}, rc={proc.returncode}): {err.strip()}"
            )
        return path
    except FileNotFoundError as exc:  # command vanished between which() and run()
        raise ClipboardImageError(f"command not found: {cmd[0]}") from exc
    except ClipboardImageError:
        # Re-raise after cleanup.
        with contextlib.suppress(OSError):
            os.remove(path)
        raise


def grab_clipboard_image(_platform_override: str | None = None) -> str:
    """Capture the clipboard image and return a path to a temp PNG.

    Parameters
    ----------
    _platform_override:
        Internal hook for tests; one of ``"darwin"``, ``"windows"``, ``"linux"``.
    """
    sysname = (_platform_override or platform.system()).lower()
    if sysname in ("darwin", "windows"):
        return _grab_pillow()
    if sysname == "linux":
        return _grab_linux()
    # Fallback: try Pillow anyway, it covers most desktop OSes.
    return _grab_pillow()
