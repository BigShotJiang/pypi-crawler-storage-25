"""clipocr - Cross-platform screenshot & clipboard OCR with bbox.

Public API:
    ocr(path)               Run OCR on an image file.
    ocr_clipboard()         Run OCR on the system clipboard image.
    OcrResult, Block        Typed result containers.
    ClipboardImageError     Raised when the clipboard has no image.
"""
from __future__ import annotations

from .clipboard import ClipboardImageError
from .core import ocr, ocr_clipboard
from .types import BBox, Block, OcrResult

__all__ = [
    "ocr",
    "ocr_clipboard",
    "OcrResult",
    "Block",
    "BBox",
    "ClipboardImageError",
    "__version__",
]

__version__ = "0.1.0"
