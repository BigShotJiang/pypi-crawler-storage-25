"""Command-line entry point for ``clipocr``."""
from __future__ import annotations

import argparse
import json
import sys

from . import __version__
from .core import ocr, ocr_clipboard


def _build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="clipocr",
        description="Cross-platform screenshot & clipboard OCR with bounding boxes.",
    )
    parser.add_argument("image", nargs="?", help="path to image file (omit when using --clip)")
    parser.add_argument(
        "--clip",
        "-c",
        action="store_true",
        help="read image from system clipboard instead of a file",
    )
    parser.add_argument(
        "--json",
        "-j",
        action="store_true",
        help="output full result as JSON (text + blocks + confidence + image_size)",
    )
    parser.add_argument(
        "--bbox",
        "-b",
        action="store_true",
        help="print each block with its bbox (ignored when --json is set)",
    )
    parser.add_argument(
        "-V",
        "--version",
        action="version",
        version=f"clipocr {__version__}",
    )
    return parser


def _format_text_with_bbox(blocks) -> str:
    lines = []
    for blk in blocks:
        x1, y1, x2, y2 = blk.bbox
        lines.append(
            f"[{x1:>4},{y1:>4} → {x2:>4},{y2:>4}] (conf={blk.confidence:.2f}) {blk.text}"
        )
    return "\n".join(lines)


def main(argv: list[str] | None = None) -> int:
    parser = _build_parser()
    args = parser.parse_args(argv)

    if args.clip and args.image:
        parser.error("--clip cannot be combined with a file path")
    if not args.clip and not args.image:
        parser.error("provide an image path or pass --clip")

    try:
        result = ocr_clipboard() if args.clip else ocr(args.image)
    except FileNotFoundError as exc:
        print(f"error: {exc}", file=sys.stderr)
        return 2
    except Exception as exc:  # pragma: no cover - unexpected runtime errors
        print(f"error: {exc}", file=sys.stderr)
        return 1

    if args.json:
        json.dump(result.to_dict(), sys.stdout, ensure_ascii=False, indent=2)
        sys.stdout.write("\n")
    elif args.bbox:
        sys.stdout.write(_format_text_with_bbox(result.blocks))
        sys.stdout.write("\n")
    else:
        sys.stdout.write(result.text)
        if not result.text.endswith("\n"):
            sys.stdout.write("\n")
    return 0


if __name__ == "__main__":  # pragma: no cover
    sys.exit(main())
