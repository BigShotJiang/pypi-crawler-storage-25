from __future__ import annotations

import dataclasses

import pytest

from clipocr.types import Block, OcrResult


def test_block_to_dict():
    b = Block(text="Hi", bbox=(1, 2, 3, 4), confidence=0.9)
    assert b.to_dict() == {"text": "Hi", "bbox": (1, 2, 3, 4), "confidence": 0.9}


def test_ocr_result_empty():
    empty = OcrResult(text="", blocks=[], confidence=0.0)
    assert empty.is_empty is True
    payload = empty.to_dict()
    assert payload["blocks"] == []
    assert payload["engine"] == "rapidocr"
    assert payload["image_size"] == [0, 0]


def test_ocr_result_full():
    blk = Block(text="Hi", bbox=(0, 0, 10, 10), confidence=0.9)
    full = OcrResult(text="Hi", blocks=[blk], confidence=0.9, image_size=(100, 50))
    assert full.is_empty is False
    payload = full.to_dict()
    assert payload["text"] == "Hi"
    assert payload["confidence"] == 0.9
    assert payload["image_size"] == [100, 50]
    assert payload["blocks"][0]["text"] == "Hi"


def test_ocr_result_is_immutable():
    res = OcrResult(text="x", blocks=[], confidence=1.0)
    with pytest.raises(dataclasses.FrozenInstanceError):
        res.text = "y"  # type: ignore[misc]
