from __future__ import annotations

import pytest

from clipocr import core, ocr, ocr_clipboard
from clipocr.types import OcrResult


def _box(x1, y1, x2, y2):
    return [[x1, y1], [x2, y1], [x2, y2], [x1, y2]]


def test_silence_third_party_logs_sets_warning_level(monkeypatch):
    import logging

    monkeypatch.delenv("CLIPOCR_VERBOSE", raising=False)
    # Pre-set to DEBUG so we can verify it is bumped up.
    # Also attach a fake handler to verify we strip it.
    fake_handler = logging.StreamHandler()
    for name in ("RapidOCR", "rapidocr", "ppocr", "onnxruntime"):
        log = logging.getLogger(name)
        log.setLevel(logging.DEBUG)
        log.addHandler(fake_handler)
        log.propagate = True

    core._silence_third_party_logs()

    for name in ("RapidOCR", "rapidocr", "ppocr", "onnxruntime"):
        log = logging.getLogger(name)
        assert log.level == logging.WARNING
        assert fake_handler not in log.handlers
        assert log.propagate is False


def test_silence_third_party_logs_respects_verbose_env(monkeypatch):
    import logging

    monkeypatch.setenv("CLIPOCR_VERBOSE", "1")
    logging.getLogger("RapidOCR").setLevel(logging.DEBUG)

    core._silence_third_party_logs()

    # Should remain at DEBUG, untouched.
    assert logging.getLogger("RapidOCR").level == logging.DEBUG


# ---------- _to_int_bbox ----------

def test_to_int_bbox_handles_floats_and_unordered_points():
    box = [[10.4, 20.6], [50.2, 19.9], [49.8, 60.1], [11.0, 60.4]]
    assert core._to_int_bbox(box) == (10, 20, 50, 60)


# ---------- _normalize_engine_output ----------

class _FakeRapidOCROutput:
    """Mimics the new rapidocr>=2.x output object."""

    def __init__(self, boxes, txts, scores):
        self.boxes = boxes
        self.txts = txts
        self.scores = scores


def test_normalize_handles_legacy_tuple():
    raw = ([(_box(0, 0, 5, 5), "hi", 0.9)], 0.01)
    out = core._normalize_engine_output(raw)
    assert out == [(_box(0, 0, 5, 5), "hi", 0.9)]


def test_normalize_handles_none():
    assert core._normalize_engine_output(None) is None


def test_normalize_handles_new_object():
    obj = _FakeRapidOCROutput(
        boxes=[_box(1, 2, 3, 4), _box(5, 6, 7, 8)],
        txts=("foo", "bar"),
        scores=[0.9, 0.8],
    )
    out = core._normalize_engine_output(obj)
    assert out is not None
    assert len(out) == 2
    assert out[0][1] == "foo"
    assert out[1][2] == 0.8


def test_normalize_new_object_with_none_boxes_returns_none():
    obj = _FakeRapidOCROutput(boxes=None, txts=("foo",), scores=[0.9])
    assert core._normalize_engine_output(obj) is None


def test_normalize_new_object_with_missing_scores_uses_zero():
    obj = _FakeRapidOCROutput(boxes=[_box(0, 0, 1, 1)], txts=("foo",), scores=None)
    out = core._normalize_engine_output(obj)
    assert out is not None
    assert out[0][2] == 0.0


def test_normalize_new_object_truncates_when_boxes_shorter_than_txts():
    obj = _FakeRapidOCROutput(
        boxes=[_box(0, 0, 1, 1)],
        txts=("a", "b", "c"),
        scores=[0.5, 0.6, 0.7],
    )
    out = core._normalize_engine_output(obj)
    assert out is not None
    assert len(out) == 1


def test_normalize_passthrough_for_plain_list():
    raw = [(_box(0, 0, 1, 1), "x", 0.5)]
    out = core._normalize_engine_output(raw)
    assert out == raw


def test_normalize_unknown_shape_returns_none():
    assert core._normalize_engine_output("not a result") is None
    assert core._normalize_engine_output(42) is None


def test_ocr_works_with_new_rapidocr_object_engine(sample_png):
    obj = _FakeRapidOCROutput(
        boxes=[_box(10, 10, 60, 30)],
        txts=("Hello",),
        scores=[0.95],
    )

    def engine(_img):
        return obj

    res = ocr(sample_png, engine=engine)
    assert res.text == "Hello"
    assert res.blocks[0].confidence == 0.95


# ---------- ocr() with injected engine ----------

def test_ocr_returns_empty_result_for_no_detections(sample_png, fake_engine_factory):
    engine = fake_engine_factory(None)
    res = ocr(sample_png, engine=engine)
    assert isinstance(res, OcrResult)
    assert res.text == ""
    assert res.blocks == []
    assert res.confidence == 0.0
    assert res.image_size == (200, 100)
    assert res.is_empty is True


def test_ocr_parses_single_block(sample_png, fake_engine_factory):
    engine = fake_engine_factory([(_box(10, 10, 60, 30), "Hello", 0.95)])
    res = ocr(sample_png, engine=engine)
    assert res.text == "Hello"
    assert len(res.blocks) == 1
    assert res.blocks[0].bbox == (10, 10, 60, 30)
    assert res.blocks[0].confidence == 0.95
    assert 0.94 < res.confidence < 0.96


def test_ocr_skips_blocks_with_empty_text(sample_png, fake_engine_factory):
    engine = fake_engine_factory(
        [
            (_box(10, 10, 60, 30), "Hello", 0.95),
            (_box(10, 40, 60, 60), "", 0.5),  # should be filtered out
        ]
    )
    res = ocr(sample_png, engine=engine)
    assert res.text == "Hello"
    assert len(res.blocks) == 1


def test_ocr_returns_empty_when_all_blocks_filtered(sample_png, fake_engine_factory):
    engine = fake_engine_factory([(_box(0, 0, 10, 10), "", 0.5)])
    res = ocr(sample_png, engine=engine)
    assert res.is_empty is True
    assert res.text == ""


def test_ocr_orders_blocks_top_to_bottom_then_left_to_right(
    sample_png, fake_engine_factory
):
    # Two rows. Inputs deliberately shuffled.
    items = [
        (_box(80, 5, 130, 25), "B", 0.9),  # row 1, right
        (_box(80, 60, 130, 80), "D", 0.9),  # row 2, right
        (_box(10, 5, 60, 25), "A", 0.9),  # row 1, left
        (_box(10, 60, 60, 80), "C", 0.9),  # row 2, left
    ]
    res = ocr(sample_png, engine=fake_engine_factory(items))
    assert res.text == "A\nB\nC\nD"


def test_ocr_accepts_dict_style_engine_output(sample_png, fake_engine_factory):
    engine = fake_engine_factory(
        [{"box": _box(0, 0, 30, 20), "text": "Hi", "score": 0.88}]
    )
    res = ocr(sample_png, engine=engine)
    assert res.text == "Hi"
    assert res.blocks[0].confidence == 0.88


def test_ocr_raises_on_missing_path(tmp_path, fake_engine_factory):
    missing = tmp_path / "does-not-exist.png"
    with pytest.raises(FileNotFoundError):
        ocr(missing, engine=fake_engine_factory([]))


def test_ocr_raises_when_path_is_directory(tmp_path, fake_engine_factory):
    with pytest.raises(IsADirectoryError):
        ocr(tmp_path, engine=fake_engine_factory([]))


def test_ocr_handles_unreadable_image_size(monkeypatch, sample_png, fake_engine_factory):
    """If PIL fails on the size probe, we still return a valid result with (0,0)."""

    def boom(_path):
        raise OSError("nope")

    monkeypatch.setattr(core, "_image_size", boom)
    with pytest.raises(OSError):
        ocr(sample_png, engine=fake_engine_factory([]))


def test_image_size_returns_zero_on_corrupt_file(tmp_path):
    bad = tmp_path / "broken.png"
    bad.write_bytes(b"not a real png")
    assert core._image_size(bad) == (0, 0)


# ---------- ocr_clipboard() ----------

def test_ocr_clipboard_uses_grabber_and_cleans_up(
    sample_png, fake_engine_factory, monkeypatch
):
    sample_path = str(sample_png)
    deleted = []

    def fake_grabber():
        return sample_path

    real_remove = __import__("os").remove

    def tracking_remove(p):
        deleted.append(p)
        return real_remove(p)

    monkeypatch.setattr(core.os, "remove", tracking_remove)

    engine = fake_engine_factory([(_box(0, 0, 30, 20), "Hi", 0.9)])
    res = ocr_clipboard(engine=engine, grabber=fake_grabber)
    assert res.text == "Hi"
    assert deleted == [sample_path]


def test_ocr_clipboard_cleanup_runs_even_when_ocr_raises(
    tmp_path, fake_engine_factory, monkeypatch
):
    fake_path = str(tmp_path / "missing.png")
    deleted = []
    monkeypatch.setattr(core.os, "remove", lambda p: deleted.append(p))

    with pytest.raises(FileNotFoundError):
        ocr_clipboard(
            engine=fake_engine_factory([]),
            grabber=lambda: fake_path,
        )

    assert deleted == [fake_path]


# ---------- engine singleton ----------

def test_load_default_engine_caches(monkeypatch):
    calls = {"n": 0}

    class _Fake:
        def __call__(self, *_a, **_k):
            return (None, 0.0)

    def factory():
        calls["n"] += 1
        return _Fake()

    monkeypatch.setattr(core, "_engine_singleton", None)
    # Patch the lazy importer to skip the real RapidOCR.
    lambda: factory()  # noqa: E731

    monkeypatch.setattr(core, "_load_default_engine", lambda: factory())
    # First call
    e1 = core._load_default_engine()
    e2 = core._load_default_engine()
    assert calls["n"] == 2  # our patched func runs each time, sanity check
    assert isinstance(e1, _Fake) and isinstance(e2, _Fake)
