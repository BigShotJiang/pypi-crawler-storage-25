"""Shared pytest fixtures."""
from __future__ import annotations

from pathlib import Path

import pytest

FIXTURES = Path(__file__).parent / "fixtures"


@pytest.fixture
def sample_png(tmp_path) -> Path:
    """Create a tiny valid PNG so PIL.Image.open() succeeds without external assets."""
    from PIL import Image

    p = tmp_path / "sample.png"
    img = Image.new("RGB", (200, 100), color="white")
    img.save(p, format="PNG")
    return p


@pytest.fixture
def fake_engine_factory():
    """Build a callable that mimics RapidOCR's signature.

    Usage::

        engine = fake_engine_factory([
            ([[10,10],[60,10],[60,30],[10,30]], "Hello", 0.95),
        ])
    """

    def _build(items, elapse=0.001):
        def _engine(_img):
            return (items if items is not None else None, elapse)

        return _engine

    return _build
