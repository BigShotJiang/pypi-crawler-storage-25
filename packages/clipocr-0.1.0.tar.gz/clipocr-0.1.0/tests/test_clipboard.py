from __future__ import annotations

import os
from unittest.mock import MagicMock

import pytest
from PIL import Image, ImageGrab

from clipocr import clipboard

# ---------- macOS / Windows (Pillow) path ----------

def test_grab_pillow_returns_temp_png(monkeypatch, tmp_path):
    fake_image = Image.new("RGB", (4, 4), "white")
    monkeypatch.setattr(ImageGrab, "grabclipboard", lambda: fake_image)

    out = clipboard._grab_pillow()
    try:
        assert os.path.exists(out)
        assert os.path.getsize(out) > 0
        # Verify it's a valid PNG
        with Image.open(out) as img:
            assert img.format == "PNG"
    finally:
        if os.path.exists(out):
            os.remove(out)


def test_grab_pillow_raises_when_clipboard_empty(monkeypatch):
    monkeypatch.setattr(ImageGrab, "grabclipboard", lambda: None)
    with pytest.raises(clipboard.ClipboardImageError, match="does not contain an image"):
        clipboard._grab_pillow()


def test_grab_pillow_handles_list_of_paths(monkeypatch, tmp_path):
    """Some platforms return a list of file paths instead of an Image."""
    src = tmp_path / "from-clip.png"
    Image.new("RGB", (4, 4), "white").save(src, format="PNG")

    monkeypatch.setattr(ImageGrab, "grabclipboard", lambda: [str(src)])

    out = clipboard._grab_pillow()
    try:
        assert os.path.exists(out)
        with Image.open(out) as img:
            assert img.format == "PNG"
    finally:
        if os.path.exists(out):
            os.remove(out)


def test_grab_pillow_raises_on_empty_list(monkeypatch):
    monkeypatch.setattr(ImageGrab, "grabclipboard", lambda: [])
    with pytest.raises(clipboard.ClipboardImageError):
        clipboard._grab_pillow()


def test_grab_pillow_raises_when_listed_file_unreadable(monkeypatch, tmp_path):
    bogus = tmp_path / "not-a-png"
    bogus.write_text("nope")
    monkeypatch.setattr(ImageGrab, "grabclipboard", lambda: [str(bogus)])
    with pytest.raises(clipboard.ClipboardImageError, match="not readable"):
        clipboard._grab_pillow()


# ---------- Linux path ----------

def test_grab_linux_prefers_wayland(monkeypatch, tmp_path):
    monkeypatch.setattr(
        clipboard.shutil,
        "which",
        lambda cmd: "/usr/bin/wl-paste" if cmd == "wl-paste" else None,
    )
    captured = {}

    def fake_grab_via(cmd):
        captured["cmd"] = cmd
        target = tmp_path / "out.png"
        target.write_bytes(b"\x89PNG")
        return str(target)

    monkeypatch.setattr(clipboard, "_grab_via_command", fake_grab_via)
    out = clipboard._grab_linux()
    assert captured["cmd"][0] == "wl-paste"
    assert os.path.exists(out)


def test_grab_linux_falls_back_to_xclip(monkeypatch, tmp_path):
    def which(cmd):
        return "/usr/bin/xclip" if cmd == "xclip" else None

    monkeypatch.setattr(clipboard.shutil, "which", which)

    def fake_grab_via(cmd):
        assert cmd[0] == "xclip"
        target = tmp_path / "out.png"
        target.write_bytes(b"\x89PNG")
        return str(target)

    monkeypatch.setattr(clipboard, "_grab_via_command", fake_grab_via)
    out = clipboard._grab_linux()
    assert os.path.exists(out)


def test_grab_linux_raises_when_no_backend(monkeypatch):
    monkeypatch.setattr(clipboard.shutil, "which", lambda _cmd: None)
    with pytest.raises(clipboard.ClipboardImageError, match="no clipboard backend"):
        clipboard._grab_linux()


def test_grab_via_command_writes_output(monkeypatch):
    def fake_run(cmd, stdout, stderr, check):
        stdout.write(b"\x89PNG\r\n\x1a\nfake-png-bytes")
        return MagicMock(returncode=0, stderr=b"")

    monkeypatch.setattr(clipboard.subprocess, "run", fake_run)
    out = clipboard._grab_via_command(["fake"])
    try:
        assert os.path.exists(out)
        assert os.path.getsize(out) > 0
    finally:
        if os.path.exists(out):
            os.remove(out)


def test_grab_via_command_raises_on_nonzero_rc(monkeypatch):
    def fake_run(cmd, stdout, stderr, check):
        return MagicMock(returncode=1, stderr=b"boom")

    monkeypatch.setattr(clipboard.subprocess, "run", fake_run)
    with pytest.raises(clipboard.ClipboardImageError, match="rc=1"):
        clipboard._grab_via_command(["fake"])


def test_grab_via_command_raises_on_empty_output(monkeypatch):
    def fake_run(cmd, stdout, stderr, check):
        return MagicMock(returncode=0, stderr=b"")

    monkeypatch.setattr(clipboard.subprocess, "run", fake_run)
    with pytest.raises(clipboard.ClipboardImageError):
        clipboard._grab_via_command(["fake"])


def test_grab_via_command_handles_missing_executable(monkeypatch):
    def fake_run(*_a, **_k):
        raise FileNotFoundError("nope")

    monkeypatch.setattr(clipboard.subprocess, "run", fake_run)
    with pytest.raises(clipboard.ClipboardImageError, match="command not found"):
        clipboard._grab_via_command(["does-not-exist"])


# ---------- public dispatcher ----------

def test_grab_clipboard_image_dispatch_macos(monkeypatch):
    monkeypatch.setattr(clipboard, "_grab_pillow", lambda: "/tmp/mac.png")
    assert clipboard.grab_clipboard_image(_platform_override="darwin") == "/tmp/mac.png"


def test_grab_clipboard_image_dispatch_windows(monkeypatch):
    monkeypatch.setattr(clipboard, "_grab_pillow", lambda: "/tmp/win.png")
    assert clipboard.grab_clipboard_image(_platform_override="windows") == "/tmp/win.png"


def test_grab_clipboard_image_dispatch_linux(monkeypatch):
    monkeypatch.setattr(clipboard, "_grab_linux", lambda: "/tmp/linux.png")
    assert clipboard.grab_clipboard_image(_platform_override="linux") == "/tmp/linux.png"


def test_grab_clipboard_image_unknown_platform_falls_back(monkeypatch):
    monkeypatch.setattr(clipboard, "_grab_pillow", lambda: "/tmp/fallback.png")
    assert (
        clipboard.grab_clipboard_image(_platform_override="haiku") == "/tmp/fallback.png"
    )


def test_grab_clipboard_image_uses_real_platform_when_no_override(monkeypatch):
    """Sanity check: without override, falls through to the real dispatcher."""
    called = {}

    def fake_grab():
        called["yes"] = True
        return "/tmp/auto.png"

    monkeypatch.setattr(clipboard, "_grab_pillow", fake_grab)
    monkeypatch.setattr(clipboard, "_grab_linux", fake_grab)
    out = clipboard.grab_clipboard_image()
    assert called["yes"]
    assert out == "/tmp/auto.png"
