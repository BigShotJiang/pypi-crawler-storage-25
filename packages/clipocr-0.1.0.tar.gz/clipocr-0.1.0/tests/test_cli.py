from __future__ import annotations

import json

import pytest

from clipocr import cli, types


def _make_result(text="hello", confidence=0.9):
    blk = types.Block(text=text, bbox=(0, 0, 10, 10), confidence=confidence)
    return types.OcrResult(
        text=text, blocks=[blk], confidence=confidence, image_size=(100, 50)
    )


def test_cli_path_plain_text(monkeypatch, sample_png, capsys):
    monkeypatch.setattr(cli, "ocr", lambda p: _make_result("Hello"))
    rc = cli.main([str(sample_png)])
    out = capsys.readouterr().out
    assert rc == 0
    assert out.strip() == "Hello"


def test_cli_path_json(monkeypatch, sample_png, capsys):
    monkeypatch.setattr(cli, "ocr", lambda p: _make_result("Hello"))
    rc = cli.main([str(sample_png), "--json"])
    out = capsys.readouterr().out
    assert rc == 0
    payload = json.loads(out)
    assert payload["text"] == "Hello"
    assert payload["blocks"][0]["bbox"] == [0, 0, 10, 10]


def test_cli_path_bbox(monkeypatch, sample_png, capsys):
    monkeypatch.setattr(cli, "ocr", lambda p: _make_result("Hello"))
    rc = cli.main([str(sample_png), "--bbox"])
    out = capsys.readouterr().out
    assert rc == 0
    assert "Hello" in out
    assert "conf=0.90" in out
    assert "→" in out


def test_cli_clip_branch(monkeypatch, capsys):
    monkeypatch.setattr(cli, "ocr_clipboard", lambda: _make_result("FromClip"))
    rc = cli.main(["--clip"])
    assert rc == 0
    assert capsys.readouterr().out.strip() == "FromClip"


def test_cli_clip_and_path_conflict(capsys):
    with pytest.raises(SystemExit) as exc:
        cli.main(["foo.png", "--clip"])
    err = capsys.readouterr().err
    assert exc.value.code == 2
    assert "--clip cannot be combined" in err


def test_cli_no_input_errors(capsys):
    with pytest.raises(SystemExit) as exc:
        cli.main([])
    err = capsys.readouterr().err
    assert exc.value.code == 2
    assert "image path or pass --clip" in err


def test_cli_handles_missing_file(monkeypatch, capsys):
    def raise_fnf(_p):
        raise FileNotFoundError("nope")

    monkeypatch.setattr(cli, "ocr", raise_fnf)
    rc = cli.main(["does-not-exist.png"])
    err = capsys.readouterr().err
    assert rc == 2
    assert "error: nope" in err


def test_cli_version(capsys):
    with pytest.raises(SystemExit) as exc:
        cli.main(["--version"])
    out = capsys.readouterr().out
    assert exc.value.code == 0
    assert out.startswith("clipocr ")


def test_cli_text_already_ends_with_newline(monkeypatch, sample_png, capsys):
    blk = types.Block(text="Hi\n", bbox=(0, 0, 10, 10), confidence=0.9)
    res = types.OcrResult(text="Hi\n", blocks=[blk], confidence=0.9)
    monkeypatch.setattr(cli, "ocr", lambda _p: res)
    rc = cli.main([str(sample_png)])
    out = capsys.readouterr().out
    assert rc == 0
    # Should NOT add a second newline
    assert out == "Hi\n"
