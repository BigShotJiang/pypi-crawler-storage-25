"""Slow tests that exercise the real RapidOCR engine.

These are marked with ``@pytest.mark.integration`` and skipped by default.
Run them explicitly with::

    pytest -m integration

CI runs them on every push so we still get end-to-end signal.
"""
from __future__ import annotations

from pathlib import Path

import pytest

pytestmark = pytest.mark.integration


@pytest.fixture(scope="module")
def real_sample_png(tmp_path_factory) -> Path:
    """Render a clean image with known text so the OCR engine has a fair shot."""
    pil = pytest.importorskip("PIL.Image")
    pil_draw = pytest.importorskip("PIL.ImageDraw")
    pil_font = pytest.importorskip("PIL.ImageFont")

    img = pil.new("RGB", (480, 120), "white")
    draw = pil_draw.Draw(img)

    try:
        font = pil_font.load_default(size=42)
    except TypeError:  # Pillow < 10.1
        font = pil_font.load_default()

    draw.text((20, 30), "Hello clipocr", fill="black", font=font)

    out = tmp_path_factory.mktemp("integ") / "real.png"
    img.save(out, format="PNG")
    return out


def test_real_engine_recognizes_clear_text(real_sample_png):
    pytest.importorskip("rapidocr")
    from clipocr import ocr

    result = ocr(real_sample_png)
    assert result.image_size[0] >= 100
    # Engine may or may not pick up tiny default-font text; treat empty result
    # as "engine ran but did not find anything", which is still a valid signal
    # that the wiring works without making CI flaky.
    if result.is_empty:
        pytest.skip("RapidOCR found no text in the synthetic sample (font dependent)")
    assert any("clipocr" in blk.text.lower() or "hello" in blk.text.lower() for blk in result.blocks)
