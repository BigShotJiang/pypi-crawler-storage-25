# clipocr

[![CI](https://github.com/lidongyangLeo/clipocr/actions/workflows/ci.yml/badge.svg)](https://github.com/lidongyangLeo/clipocr/actions/workflows/ci.yml)
[![PyPI version](https://img.shields.io/pypi/v/clipocr.svg)](https://pypi.org/project/clipocr/)
[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](LICENSE)

> 跨平台 Python 截图 / 剪贴板 OCR，基于 [RapidOCR](https://github.com/RapidAI/RapidOCR)。返回文本 + 文本框坐标。**macOS / Windows / Linux** 全平台可用。

[English](README.md)

## 为什么用它

你截了个图，想把里面的文字抠出来——但又不想把图传到任何云服务上。

`clipocr` 直接从剪贴板或文件读图，跑一个本地 ONNX OCR 模型，返回：

- 按阅读顺序拼好的纯文本
- 每段文本的 `bbox`（xmin, ymin, xmax, ymax）和置信度
- 整体元数据（引擎、图片尺寸、平均置信度）

适合做：报错截图转文字、代码截图、UI 截图改文案、文档片段抽取——所有不想把图传出去的场景。

## 安装

```bash
pip install clipocr
```

首次运行会下载约 15 MB 的 ONNX 模型到 site-packages（一次性，之后缓存）。

## 快速上手

### Python 调用

```python
from clipocr import ocr, ocr_clipboard

# 从文件路径
result = ocr("screenshot.png")
print(result.text)
for block in result.blocks:
    print(block.bbox, block.text, block.confidence)

# 从剪贴板
result = ocr_clipboard()
print(result.text)
```

`OcrResult` 是一个不可变 dataclass：

```python
result.text         # str  — 按阅读顺序拼好的全文（换行分隔）
result.blocks       # list[Block] — 每段文字的 text + bbox + confidence
result.confidence   # float — 平均置信度，0..1
result.engine       # "rapidocr"
result.image_size   # (width, height)
result.is_empty     # True 表示啥也没识别到
result.to_dict()    # 可 JSON 序列化的 dict
```

### 命令行

```bash
clipocr screenshot.png              # 纯文本
clipocr screenshot.png --bbox       # 文本 + 坐标框
clipocr screenshot.png --json       # 完整结果（JSON）
clipocr --clip                      # 从剪贴板读图
clipocr --version
```

如果想看 RapidOCR 的 INFO 日志，设环境变量 `CLIPOCR_VERBOSE=1`。

## 平台说明

| 平台 | 剪贴板后端 |
| --- | --- |
| macOS | Pillow `ImageGrab.grabclipboard()` |
| Windows | Pillow `ImageGrab.grabclipboard()` |
| Linux (Wayland) | `wl-paste --type image/png` |
| Linux (X11) | `xclip -selection clipboard -t image/png -o` |

Linux 用户使用 `--clip` 之前请确保已经装了 `wl-clipboard`（Wayland）或 `xclip`（X11）。

## 支持语言

clipocr 默认带 RapidOCR PP-OCRv4 移动端模型，支持：

- 简体 / 繁体中文
- 英文
- 数字、常见符号

中英文混排开箱即用。

## 开发

```bash
git clone https://github.com/lidongyangLeo/clipocr.git
cd clipocr

python3 -m venv .venv
source .venv/bin/activate
pip install -e ".[dev]"

pytest                       # 单元测试 + 覆盖率
pytest -m integration        # 跑真实 RapidOCR 引擎
ruff check src tests         # lint
```

测试套件强制 **覆盖率 ≥ 90%**。

## 工作原理

```
┌─────────────────┐     ┌──────────────────────┐     ┌──────────┐
│ 图片 / 剪贴板    │ --> │ RapidOCR             │ --> │ OcrResult │
└─────────────────┘     │ （ONNX，纯本地）      │     └──────────┘
                        └──────────────────────┘
```

clipocr 是 RapidOCR 之上的一层薄壳，提供：

1. 干净的 Python API（`ocr` / `ocr_clipboard` / `OcrResult`）
2. 跨平台剪贴板适配
3. 阅读顺序排序（按行聚类，行内左到右）
4. 兼容旧版 `rapidocr-onnxruntime` 和新版 `rapidocr` >= 2.x 的输出格式
5. CLI 命令 `clipocr`（默认 stdout 干净，不会被引擎日志污染）

## 贡献

Issues 和 PR 都欢迎。提交前请确认测试和 `ruff check` 都过。

## License

MIT — 详见 [LICENSE](LICENSE)。
