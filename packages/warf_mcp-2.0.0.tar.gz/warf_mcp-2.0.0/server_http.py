"""
WARF MCP Server — HTTP/SSE transport

Run this to expose the WARF MCP server over HTTP for remote clients
(claude.ai web, Cursor remote MCP, etc.).

Usage:
    py -3.8 server_http.py              # default: localhost:8080
    py -3.8 server_http.py --port 9000  # custom port

Add to claude.ai Settings → Integrations → Remote MCP:
    URL: http://localhost:8080/sse
"""
import argparse
import os
import sys

# Re-use the same mcp instance from server.py
sys.path.insert(0, os.path.dirname(__file__))
from server import mcp  # noqa: E402

if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--host", default="127.0.0.1")
    parser.add_argument("--port", type=int, default=8080)
    args = parser.parse_args()

    mcp.run(transport="sse", host=args.host, port=args.port)
