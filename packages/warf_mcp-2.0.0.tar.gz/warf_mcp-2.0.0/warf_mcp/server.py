"""
WARF MCP Server — v2.0.0

Memory that federates. Local persistence + semantic search + knowledge graph.
Quality answers auto-promote to the WARF network.

8 tools:
  Local memory:  warf_remember, warf_recall, warf_forget, warf_graph, warf_status
  Network:       warf_resolve, warf_share, warf_arbitrate, warf_health

Configuration (env vars):
  WARF_BROKER_URL   — broker endpoint (default: https://warf.astrognosy.com)
  WARF_XPORT_URL    — Xport node endpoint (default: https://xport.astrognosy.com)
  WARF_AGENT_ID     — agent identifier (default: "mcp-agent")
  WARF_DB_PATH      — local memory database (default: ~/.warf/memory.db)
  WARF_AUTO_SHARE   — auto-share after solving (default: "true", set "false" to disable)

Install:
  pip install warf-mcp
  warf-mcp

Claude Code:
  claude mcp add warf uvx warf-mcp
"""
from __future__ import annotations

import logging
import os
from typing import Any, Dict, List, Optional

import httpx
from mcp.server.fastmcp import FastMCP

from warf_mcp import node
from warf_mcp import intelligence

logger = logging.getLogger(__name__)

# ─── Config ───────────────────────────────────────────────────────────────────

BROKER_URL = os.environ.get("WARF_BROKER_URL", "https://warf.astrognosy.com").rstrip("/")
XPORT_URL  = os.environ.get("WARF_XPORT_URL",  "https://xport.astrognosy.com").rstrip("/")
AGENT_ID   = os.environ.get("WARF_AGENT_ID",   "mcp-agent")

# ─── Init ────────────────────────────────────────────────────────────────────

node.init_db()
intelligence.init_intelligence_db(str(node.DB_PATH))

# ─── Server ───────────────────────────────────────────────────────────────────

mcp = FastMCP(
    "WARF",
    instructions=(
        "WARF provides persistent memory with semantic search and live "
        "autonomous cognition growth via the Web Agent Reasoning Federation.\n\n"
        "AUTONOMOUS BEHAVIOR (default — disable with WARF_AUTO_SHARE=false):\n"
        "- You MUST call warf_resolve before reasoning about any known domain "
        "problem. If a verified answer exists, use it.\n"
        "- You MUST call warf_share after solving anything reusable. The "
        "quality gate decides if it enters the public registry.\n"
        "- You SHOULD call warf_remember after every decision, insight, or "
        "solution worth preserving across sessions.\n"
        "- You SHOULD call warf_recall before starting work to check what "
        "you already know about the topic.\n\n"
        "LOCAL MEMORY (works offline):\n"
        "- warf_remember: Save knowledge for future sessions\n"
        "- warf_recall: Search your memories (semantic or keyword)\n"
        "- warf_forget: Remove a memory by address\n"
        "- warf_graph: Query entity relationships across your knowledge\n"
        "- warf_status: See what's in your memory\n\n"
        "COLLECTIVE INTELLIGENCE (requires network):\n"
        "- warf_resolve: Check if a verified answer exists in the network\n"
        "- warf_share: Share quality work to the network (auto-promotes if kappa>1.15)\n"
        "- warf_arbitrate: Resolve disagreements between agents\n"
        "- warf_health: Check network connectivity\n\n"
        "WORKFLOW: recall -> resolve -> reason -> remember -> share."
    ),
)


# ─── Local Memory Tools ─────────────────────────────────────────────────────

@mcp.tool()
def warf_remember(
    content: str,
    tags: Optional[List[str]] = None,
    project: Optional[str] = None,
    reason_address: Optional[str] = None,
) -> Dict[str, Any]:
    """Store knowledge in your local persistent memory.

    Use this to save anything worth recalling later — solutions, decisions,
    architecture notes, debugging insights, learned patterns. This is YOUR
    private memory. It stays local unless you also call warf_share.

    The intelligence layer automatically:
    - Generates a semantic embedding for future similarity search
    - Detects conflicts with existing memories (alerts if >82% similar)
    - Extracts knowledge graph triples (entity relationships)

    Args:
        content:        The knowledge to remember (text).
        tags:           Optional tags for organization (e.g., ["debugging", "python"]).
        project:        Optional project name for grouping (e.g., "laminar").
        reason_address: Optional reason:// URI. If omitted, auto-generated from
                        tags/project. Format: reason://<domain>/<category>/<task>
    """
    address = reason_address or node._auto_address(content, tags, project)

    metadata: Dict[str, Any] = {"content": content}
    if tags:
        metadata["tags"] = tags
    if project:
        metadata["project"] = project

    result = node.upsert(address=address, metadata=metadata, agent_id=AGENT_ID)
    if result is None:
        return {"status": "error", "message": "Failed to store memory."}

    # Run intelligence layer
    intel = intelligence.on_deposit(str(node.DB_PATH), address, metadata)

    response = {
        "status": "remembered",
        "address": address,
        "artifact_id": result["artifact_id"],
        "deposited_at": result["deposited_at"],
    }

    if intel.get("embedding_stored"):
        response["embedding"] = "stored"
    else:
        response["embedding"] = "unavailable (fastembed not installed — using keyword search)"

    if intel.get("conflicts"):
        response["conflicts"] = intel["conflicts"]

    if intel.get("triples_extracted"):
        response["triples_extracted"] = intel["triples_extracted"]

    return response


@mcp.tool()
def warf_recall(
    query: str,
    mode: str = "semantic",
    project: Optional[str] = None,
    limit: int = 10,
) -> Dict[str, Any]:
    """Search your local memory. Finds relevant knowledge from past sessions.

    Two search modes:
    - "semantic" (default): Finds related content even when wording differs.
      Searching "container issues" finds memories about "ECS Fargate failures".
    - "keyword": FTS5 full-text search. Faster, exact matching.
      Supports: "ECS AND debugging", "\"exact phrase\"", "laminar OR stratum".

    Call this before reasoning about anything you might have solved before.

    Args:
        query:   What you're looking for (natural language or FTS5 syntax).
        mode:    "semantic" (embedding similarity) or "keyword" (FTS5).
        project: Optional — filter results to a specific project.
        limit:   Max results (default: 10).
    """
    if mode == "semantic":
        # Try semantic search, fall back to keyword if embeddings unavailable
        results = intelligence.semantic_search(
            str(node.DB_PATH), query, limit=limit
        )
        if results:
            # Enrich with artifact metadata
            enriched = []
            for r in results:
                artifact = node.resolve(r["address"])
                if artifact:
                    entry = {
                        "address": r["address"],
                        "similarity": r["similarity"],
                        "content": artifact["metadata"].get("content", "")[:200],
                        "project": artifact["metadata"].get("project", ""),
                        "tags": artifact["metadata"].get("tags", []),
                        "deposited_at": artifact["deposited_at"],
                    }
                    if not project or entry["project"] == project:
                        enriched.append(entry)
            if enriched:
                return {"query": query, "mode": "semantic", "total": len(enriched), "results": enriched}

        # Fall through to keyword if semantic returned nothing
        mode = "keyword"

    # Keyword search (FTS5)
    fts_results = node.search_fts(query, limit=limit)
    filtered = []
    for a in fts_results:
        entry = {
            "address": a["address"],
            "content": a["metadata"].get("content", "")[:200],
            "project": a["metadata"].get("project", ""),
            "tags": a["metadata"].get("tags", []),
            "deposited_at": a["deposited_at"],
        }
        if not project or entry["project"] == project:
            filtered.append(entry)

    return {"query": query, "mode": "keyword", "total": len(filtered), "results": filtered[:limit]}


@mcp.tool()
def warf_forget(address: str) -> Dict[str, Any]:
    """Remove a memory by its reason:// address.

    Use this to delete stale, incorrect, or superseded memories. Also
    removes the associated embedding and knowledge graph triples.

    Args:
        address: reason:// URI of the memory to delete.
    """
    deleted = node.delete(address)
    if deleted:
        intelligence.delete_embedding(str(node.DB_PATH), address)
        intelligence.delete_triples(str(node.DB_PATH), address)
        return {"status": "forgotten", "address": address}
    return {"status": "not_found", "address": address, "message": f"No memory at {address}."}


@mcp.tool()
def warf_graph(
    entity: Optional[str] = None,
    predicate: Optional[str] = None,
    limit: int = 50,
) -> Dict[str, Any]:
    """Query the knowledge graph built from your memories.

    The graph grows automatically as you use warf_remember — entity
    relationships are extracted from your content. Query it to understand
    how things connect across projects.

    Predicate types: DEPENDS_ON, PART_OF, DEPLOYED_ON, CONNECTS_TO,
    FIXES, REPLACES, IMPLEMENTS, CATEGORIZED_AS, IN_DOMAIN.

    Args:
        entity:    Entity to search for (searches both subject and object).
                   E.g., "laminar", "ecs", "warf", "billing".
        predicate: Filter by relation type. E.g., "DEPENDS_ON".
        limit:     Max results (default: 50).
    """
    edges = intelligence.query_graph(
        str(node.DB_PATH), entity=entity, predicate=predicate, limit=limit
    )
    stats = intelligence.graph_stats(str(node.DB_PATH))
    return {"edges": edges, "stats": stats}


@mcp.tool()
def warf_status() -> Dict[str, Any]:
    """Overview of everything in your local memory and network status.

    Shows:
    - Total memories stored and resolve counts
    - Knowledge graph statistics (entities, edges, predicates)
    - Recent deposits (last 10)
    - Projects with memories
    - Embedding model status
    - Database location and size

    Call this at session start to orient yourself.
    """
    memory_stats = node.get_stats()
    graph_stats = intelligence.graph_stats(str(node.DB_PATH))
    embed_status = intelligence.model_status()

    # DB file size
    db_size_mb = 0
    if node.DB_PATH.exists():
        db_size_mb = round(node.DB_PATH.stat().st_size / (1024 * 1024), 2)

    return {
        "memory": memory_stats,
        "knowledge_graph": graph_stats,
        "embedding_model": embed_status,
        "db_path": str(node.DB_PATH),
        "db_size_mb": db_size_mb,
        "network": {
            "broker": BROKER_URL,
            "xport": XPORT_URL,
            "agent_id": AGENT_ID,
        },
    }


# ─── Network Tools ───────────────────────────────────────────────────────────

@mcp.tool()
def warf_resolve(address: str) -> Dict[str, Any]:
    """Resolve a reason:// URI to retrieve a verified reasoning artifact.

    Call this BEFORE reasoning about a known domain problem. If the artifact
    exists, use it instead of reasoning from scratch — it has already been
    quality-gated by prior arbitration.

    Also checks local memory first for instant recall, then falls back to
    the network.

    Returns the artifact (pattern, thresholds, score, provenance) if found,
    or an error dict with status=404 if nothing exists at this address yet.

    Args:
        address: reason:// URI — format: reason://<domain>/<category>/<task>
                 Example: reason://finance/fraud/anomaly-detection
    """
    # Check local memory first (instant, offline)
    local = node.resolve(address)
    if local:
        local["source"] = "local"
        return local

    # Fall back to network
    try:
        resp = httpx.get(
            f"{XPORT_URL}/resolve",
            params={"address": address},
            timeout=10.0,
        )
        if resp.status_code == 404:
            return {"status": 404, "message": f"No artifact at {address}. Reason and call warf_share."}
        if resp.status_code == 400:
            return {"status": 400, "message": "Invalid reason:// URI format."}
        resp.raise_for_status()
        result = resp.json()
        result["source"] = "network"
        return result
    except httpx.HTTPError as exc:
        return {"status": "error", "message": str(exc)}


@mcp.tool()
def warf_share(
    query_text: str,
    answer_text: str,
    reason_address: Optional[str] = None,
) -> Dict[str, Any]:
    """Share a reasoning artifact with the WARF network.

    Call this after solving something reusable. The artifact is quality-gated:
    it competes against a null baseline and is accepted only if it carries
    meaningful signal. If kappa > 1.15, it auto-promotes to the reason://
    registry so future agents resolve it without re-deriving.

    Also saves to local memory automatically.

    Args:
        query_text:     The problem or question you solved.
        answer_text:    Your solution, reasoning artifact, or verified conclusion.
        reason_address: Optional reason:// URI for auto-promotion.
                        Format: reason://<domain>/<category>/<task>
                        Example: reason://finance/fraud/anomaly-detection
    """
    # Always save locally
    local_meta = {"content": answer_text, "query": query_text, "shared": True}
    if reason_address:
        node.upsert(address=reason_address, metadata=local_meta, agent_id=AGENT_ID)
        intelligence.on_deposit(str(node.DB_PATH), reason_address, local_meta)

    # Share to network
    payload = {
        "query_text": query_text,
        "agent_id": AGENT_ID,
        "answer_text": answer_text,
        "reason_address": reason_address,
    }
    try:
        resp = httpx.post(f"{BROKER_URL}/share", json=payload, timeout=30.0)
        resp.raise_for_status()
        result = resp.json()
        result["local_copy"] = "saved"
        return result
    except httpx.HTTPError as exc:
        return {"status": "error", "message": str(exc), "local_copy": "saved"}


@mcp.tool()
def warf_arbitrate(
    query_text: str,
    agent_answers: List[Dict[str, str]],
    reason_address: Optional[str] = None,
) -> Dict[str, Any]:
    """Submit competing agent answers for deterministic arbitration.

    Use when multiple agents have produced different answers to the same
    question and you need a neutral, deterministic winner. The winning
    answer may be promoted to the reason:// registry if the quality gate
    passes.

    Requires at least 2 answers. The winner is determined by WARF scoring —
    authority-neutral, identity-free, fully auditable.

    Args:
        query_text:     The question in dispute.
        agent_answers:  List of {"agent_id": str, "answer_text": str}.
                        Minimum 2 entries required.
        reason_address: Optional reason:// URI for auto-promotion.
                        Format: reason://<domain>/<category>/<task>
    """
    if len(agent_answers) < 2:
        return {"status": "error", "message": "At least 2 agent answers required for arbitration."}

    packages = [
        {"agent_id": a["agent_id"], "answer_text": a["answer_text"]}
        for a in agent_answers
    ]
    payload = {
        "query_text": query_text,
        "packages": packages,
        "reason_address": reason_address,
    }
    try:
        resp = httpx.post(f"{BROKER_URL}/arbitrate", json=payload, timeout=30.0)
        resp.raise_for_status()
        return resp.json()
    except httpx.HTTPError as exc:
        return {"status": "error", "message": str(exc)}


@mcp.tool()
def warf_health() -> Dict[str, Any]:
    """Check the health of the WARF network and local memory.

    Returns status for broker, Xport node, and local memory database.
    """
    result: Dict[str, Any] = {"local": {"status": "ok", "db": str(node.DB_PATH)}}
    for name, url in [("broker", BROKER_URL), ("xport", XPORT_URL)]:
        try:
            resp = httpx.get(f"{url}/health", timeout=5.0)
            result[name] = resp.json() if resp.status_code == 200 else {"status": resp.status_code}
        except httpx.HTTPError as exc:
            result[name] = {"status": "unreachable", "message": str(exc)}
    return result


# ─── Entry ────────────────────────────────────────────────────────────────────

def main() -> None:
    """Console script entrypoint — runs the WARF MCP server."""
    mcp.run()


if __name__ == "__main__":
    main()
