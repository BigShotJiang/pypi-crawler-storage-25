"""warf-mcp — Memory that federates. Persistent memory + semantic search + WARF arbitration."""

from warf_mcp.server import mcp, main

__version__ = "2.0.0"
__all__ = ["mcp", "main"]
