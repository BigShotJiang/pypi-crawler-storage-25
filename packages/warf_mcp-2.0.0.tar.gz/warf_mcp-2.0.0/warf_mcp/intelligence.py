"""
intelligence.py — Semantic search, conflict detection, and knowledge graph.

Enhancement layer for the embedded WARF node. Provides:
  1. Embedding computation + cosine similarity search
  2. Conflict detection on deposit (surfaces contradictions)
  3. Knowledge graph extraction (entity-relation triples)

Uses fastembed (ONNX) for local embeddings — no API calls, no network,
sub-100ms per embed. Model: BAAI/bge-small-en-v1.5 (384-dim).

All operations are fail-safe — if fastembed isn't installed or the model
fails to load, the module degrades gracefully to FTS5-only search.
"""
from __future__ import annotations

import hashlib
import json
import logging
import os
import re
import sqlite3
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

logger = logging.getLogger(__name__)

# ─── Embedding Model ─────────────────────────────────────────────────────────

_MODEL_NAME = "BAAI/bge-small-en-v1.5"
_EMBED_DIM = 384
_embedder = None
_model_available = False
_numpy_available = False

os.environ.setdefault("HF_HUB_DISABLE_SYMLINKS_WARNING", "1")

try:
    import numpy as np
    _numpy_available = True
except ImportError:
    np = None  # type: ignore


def _get_embedder():
    """Lazily load the embedding model on first use."""
    global _embedder, _model_available
    if _embedder is not None:
        return _embedder
    if not _numpy_available:
        return None
    try:
        from fastembed import TextEmbedding
        _embedder = TextEmbedding(_MODEL_NAME)
        _model_available = True
        logger.info("Embedding model loaded: %s (%d-dim)", _MODEL_NAME, _EMBED_DIM)
        return _embedder
    except Exception as e:
        logger.warning("Embedding model unavailable: %s", e)
        _model_available = False
        return None


def is_available() -> bool:
    """Check if the intelligence layer is operational."""
    _get_embedder()
    return _model_available


def model_status() -> Dict[str, Any]:
    """Return embedding model status for warf_status."""
    _get_embedder()
    return {
        "model": _MODEL_NAME,
        "dimensions": _EMBED_DIM,
        "loaded": _model_available,
        "numpy": _numpy_available,
        "status": "ready" if _model_available else (
            "numpy not installed" if not _numpy_available else "model not loaded"
        ),
    }


# ─── Vector Operations ───────────────────────────────────────────────────────

def _vec_to_bytes(vec) -> bytes:
    return vec.astype(np.float32).tobytes()


def _bytes_to_vec(data: bytes):
    return np.frombuffer(data, dtype=np.float32)


def _cosine_similarity(a, b) -> float:
    dot = np.dot(a, b)
    norm = np.linalg.norm(a) * np.linalg.norm(b)
    if norm == 0:
        return 0.0
    return float(dot / norm)


# ─── DB Schema ───────────────────────────────────────────────────────────────

def init_intelligence_db(db_path: str) -> None:
    """Create intelligence tables if they don't exist."""
    conn = sqlite3.connect(db_path)
    conn.executescript("""
        CREATE TABLE IF NOT EXISTS warf_embeddings (
            address      TEXT PRIMARY KEY,
            embedding    BLOB NOT NULL,
            text_hash    TEXT NOT NULL,
            updated_at   TEXT NOT NULL
        );

        CREATE TABLE IF NOT EXISTS knowledge_graph (
            id           INTEGER PRIMARY KEY AUTOINCREMENT,
            subject      TEXT NOT NULL,
            predicate    TEXT NOT NULL,
            object       TEXT NOT NULL,
            source_uri   TEXT NOT NULL,
            confidence   REAL NOT NULL DEFAULT 1.0,
            created_at   TEXT NOT NULL,
            UNIQUE(subject, predicate, object)
        );

        CREATE INDEX IF NOT EXISTS idx_kg_subject ON knowledge_graph(subject);
        CREATE INDEX IF NOT EXISTS idx_kg_object ON knowledge_graph(object);
        CREATE INDEX IF NOT EXISTS idx_kg_source ON knowledge_graph(source_uri);
    """)
    conn.commit()
    conn.close()


# ─── Embedding Operations ────────────────────────────────────────────────────

def _extract_text(address: str, metadata: Dict[str, Any]) -> str:
    """Build a single text string from artifact metadata for embedding."""
    parts = [address]
    for val in metadata.values():
        if isinstance(val, str) and len(val) > 2:
            parts.append(val)
        elif isinstance(val, list):
            for item in val:
                if isinstance(item, str) and len(item) > 2:
                    parts.append(item)
    return " ".join(parts)[:2000]


def compute_embedding(text: str):
    """Compute embedding for a text string. Returns None if model unavailable."""
    embedder = _get_embedder()
    if embedder is None:
        return None
    try:
        vectors = list(embedder.embed([text]))
        return np.array(vectors[0], dtype=np.float32)
    except Exception as e:
        logger.warning("Embedding failed: %s", e)
        return None


def store_embedding(db_path: str, address: str, metadata: Dict[str, Any]):
    """Compute and store embedding for an artifact. Returns the vector."""
    text = _extract_text(address, metadata)
    vec = compute_embedding(text)
    if vec is None:
        return None

    text_hash = hashlib.md5(text.encode()).hexdigest()
    conn = sqlite3.connect(db_path)
    conn.execute(
        "INSERT OR REPLACE INTO warf_embeddings (address, embedding, text_hash, updated_at) "
        "VALUES (?, ?, ?, ?)",
        (address, _vec_to_bytes(vec), text_hash, datetime.now(timezone.utc).isoformat()),
    )
    conn.commit()
    conn.close()
    return vec


def semantic_search(
    db_path: str,
    query: str,
    limit: int = 10,
    min_similarity: float = 0.3,
) -> List[Dict[str, Any]]:
    """Search artifacts by semantic similarity."""
    query_vec = compute_embedding(query)
    if query_vec is None:
        return []

    conn = sqlite3.connect(db_path)
    rows = conn.execute("SELECT address, embedding FROM warf_embeddings").fetchall()
    conn.close()

    results = []
    for address, emb_bytes in rows:
        stored_vec = _bytes_to_vec(emb_bytes)
        sim = _cosine_similarity(query_vec, stored_vec)
        if sim >= min_similarity:
            results.append({"address": address, "similarity": round(sim, 4)})

    results.sort(key=lambda x: x["similarity"], reverse=True)
    return results[:limit]


def delete_embedding(db_path: str, address: str) -> None:
    """Delete embedding for an artifact."""
    try:
        conn = sqlite3.connect(db_path)
        conn.execute("DELETE FROM warf_embeddings WHERE address = ?", (address,))
        conn.commit()
        conn.close()
    except Exception:
        pass


# ─── Conflict Detection ──────────────────────────────────────────────────────

def detect_conflicts(
    db_path: str,
    address: str,
    new_vec,
    threshold: float = 0.82,
    max_conflicts: int = 5,
) -> List[Dict[str, Any]]:
    """Detect artifacts with high similarity that may conflict."""
    if new_vec is None:
        return []

    conn = sqlite3.connect(db_path)
    rows = conn.execute(
        "SELECT address, embedding FROM warf_embeddings WHERE address != ?",
        (address,),
    ).fetchall()
    conn.close()

    conflicts = []
    for existing_address, emb_bytes in rows:
        stored_vec = _bytes_to_vec(emb_bytes)
        sim = _cosine_similarity(new_vec, stored_vec)
        if sim >= threshold:
            conflicts.append({
                "address": existing_address,
                "similarity": round(sim, 4),
                "judgment_required": sim >= 0.92,
            })

    conflicts.sort(key=lambda x: x["similarity"], reverse=True)
    return conflicts[:max_conflicts]


# ─── Knowledge Graph ─────────────────────────────────────────────────────────

_RELATION_PATTERNS = [
    (r"(\w[\w\s-]{1,40})\s+(?:depends on|requires|needs|relies on)\s+(\w[\w\s-]{1,40})", "DEPENDS_ON"),
    (r"(\w[\w\s-]{1,40})\s+(?:is part of|belongs to|is inside)\s+(\w[\w\s-]{1,40})", "PART_OF"),
    (r"(\w[\w\s-]{1,40})\s+(?:deployed on|deployed to|runs on|hosted on)\s+(\w[\w\s-]{1,40})", "DEPLOYED_ON"),
    (r"(\w[\w\s-]{1,40})\s+(?:connects to|calls|talks to|sends to|proxies to)\s+(\w[\w\s-]{1,40})", "CONNECTS_TO"),
    (r"(\w[\w\s-]{1,40})\s+(?:fixes|resolves|patches|addresses)\s+(\w[\w\s-]{1,40})", "FIXES"),
    (r"(\w[\w\s-]{1,40})\s+(?:replaces|supersedes|deprecates)\s+(\w[\w\s-]{1,40})", "REPLACES"),
    (r"(\w[\w\s-]{1,40})\s+(?:implements|provides|exposes|offers)\s+(\w[\w\s-]{1,40})", "IMPLEMENTS"),
]


def _clean_entity(s: str) -> str:
    return s.strip().strip("-").lower()


def extract_triples(
    address: str, metadata: Dict[str, Any],
) -> List[Tuple[str, str, str]]:
    """Extract knowledge graph triples from artifact metadata."""
    parts = []
    for val in metadata.values():
        if isinstance(val, str):
            parts.append(val)
        elif isinstance(val, list):
            parts.extend(item for item in val if isinstance(item, str))
    text = " ".join(parts)

    triples = []

    for pattern, predicate in _RELATION_PATTERNS:
        for match in re.finditer(pattern, text, re.IGNORECASE):
            subj = _clean_entity(match.group(1))
            obj = _clean_entity(match.group(2))
            if len(subj) > 2 and len(obj) > 2 and subj != obj:
                triples.append((subj, predicate, obj))

    # URI-derived triples
    uri_parts = address.replace("reason://", "").split("/")
    if len(uri_parts) >= 3:
        triples.append((uri_parts[2], "CATEGORIZED_AS", uri_parts[1]))
        triples.append((uri_parts[2], "IN_DOMAIN", uri_parts[0]))

    # Project association
    project = metadata.get("project", "")
    if project:
        triples.append((_clean_entity(uri_parts[2] if len(uri_parts) >= 3 else "unknown"),
                         "PART_OF", _clean_entity(project)))

    return triples


def store_triples(
    db_path: str, address: str,
    triples: List[Tuple[str, str, str]], confidence: float = 1.0,
) -> int:
    """Store extracted triples. Returns count stored."""
    if not triples:
        return 0
    conn = sqlite3.connect(db_path)
    stored = 0
    now = datetime.now(timezone.utc).isoformat()
    for subj, pred, obj in triples:
        try:
            conn.execute(
                "INSERT OR IGNORE INTO knowledge_graph "
                "(subject, predicate, object, source_uri, confidence, created_at) "
                "VALUES (?, ?, ?, ?, ?, ?)",
                (subj, pred, obj, address, confidence, now),
            )
            stored += 1
        except Exception:
            pass
    conn.commit()
    conn.close()
    return stored


def delete_triples(db_path: str, address: str) -> None:
    """Delete all triples sourced from a given artifact."""
    try:
        conn = sqlite3.connect(db_path)
        conn.execute("DELETE FROM knowledge_graph WHERE source_uri = ?", (address,))
        conn.commit()
        conn.close()
    except Exception:
        pass


def query_graph(
    db_path: str,
    entity: Optional[str] = None,
    predicate: Optional[str] = None,
    limit: int = 50,
) -> List[Dict[str, Any]]:
    """Query the knowledge graph."""
    conn = sqlite3.connect(db_path)
    conn.row_factory = sqlite3.Row

    conditions = []
    params: list = []
    if entity:
        conditions.append("(subject LIKE ? OR object LIKE ?)")
        params.extend([f"%{entity}%", f"%{entity}%"])
    if predicate:
        conditions.append("predicate = ?")
        params.append(predicate.upper())

    where = f"WHERE {' AND '.join(conditions)}" if conditions else ""
    params.append(limit)
    rows = conn.execute(
        f"SELECT * FROM knowledge_graph {where} ORDER BY created_at DESC LIMIT ?",
        params,
    ).fetchall()
    conn.close()

    return [
        {"subject": r["subject"], "predicate": r["predicate"],
         "object": r["object"], "source_uri": r["source_uri"],
         "confidence": r["confidence"]}
        for r in rows
    ]


def graph_stats(db_path: str) -> Dict[str, Any]:
    """Get knowledge graph statistics."""
    try:
        conn = sqlite3.connect(db_path)
        total = conn.execute("SELECT COUNT(*) FROM knowledge_graph").fetchone()[0]
        predicates = conn.execute(
            "SELECT predicate, COUNT(*) as cnt FROM knowledge_graph "
            "GROUP BY predicate ORDER BY cnt DESC"
        ).fetchall()
        entities = conn.execute(
            "SELECT COUNT(DISTINCT subject) + COUNT(DISTINCT object) FROM knowledge_graph"
        ).fetchone()[0]
        conn.close()
        return {
            "total_edges": total,
            "unique_entities": entities,
            "predicates": {r[0]: r[1] for r in predicates},
        }
    except Exception:
        return {"total_edges": 0, "unique_entities": 0, "predicates": {}}


# ─── Unified Deposit Hook ────────────────────────────────────────────────────

def on_deposit(
    db_path: str, address: str, metadata: Dict[str, Any],
    conflict_threshold: float = 0.82,
) -> Dict[str, Any]:
    """Called after every artifact deposit. Runs all intelligence operations."""
    result: Dict[str, Any] = {
        "embedding_stored": False,
        "conflicts": [],
        "triples_extracted": 0,
    }

    vec = store_embedding(db_path, address, metadata)
    if vec is not None:
        result["embedding_stored"] = True
        result["conflicts"] = detect_conflicts(
            db_path, address, vec, threshold=conflict_threshold
        )

    triples = extract_triples(address, metadata)
    result["triples_extracted"] = store_triples(db_path, address, triples)

    return result
