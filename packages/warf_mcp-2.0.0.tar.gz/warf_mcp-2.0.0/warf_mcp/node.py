"""
node.py — Embedded SQLite node for local persistent memory.

In-process reason:// registry. No HTTP, no daemon — direct function calls
from the MCP server to SQLite. WAL mode + synchronous=FULL for crash safety.

Database: ~/.warf/memory.db
Tables:
  - warf_artifacts: address, metadata, score, convergence_history
  - warf_fts: FTS5 full-text search index

All functions are thread-safe and exception-safe. Failures never propagate
to the caller — they return None or empty results.
"""
from __future__ import annotations

import hashlib
import json
import logging
import os
import re
import shutil
import sqlite3
import time
import uuid
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, List, Optional

logger = logging.getLogger(__name__)

# ─── Paths ───────────────────────────────────────────────────────────────────

DB_DIR = Path(os.environ.get("WARF_DB_DIR", str(Path.home() / ".warf")))
DB_PATH = Path(os.environ.get("WARF_DB_PATH", str(DB_DIR / "memory.db")))
BACKUP_DIR = DB_DIR / "backups"
MAX_BACKUPS = 5

REASON_URI_PATTERN = re.compile(
    r"^reason://([a-z][a-z0-9\-]*)/([a-z][a-z0-9\-]*)/([a-z][a-z0-9\-]*)$"
)

# ─── Connection Pool ─────────────────────────────────────────────────────────

_conn: Optional[sqlite3.Connection] = None


def _get_db() -> sqlite3.Connection:
    """Get or create the module-level SQLite connection."""
    global _conn
    if _conn is not None:
        return _conn

    DB_DIR.mkdir(parents=True, exist_ok=True)
    _conn = sqlite3.connect(str(DB_PATH), check_same_thread=False)
    _conn.row_factory = sqlite3.Row
    _conn.execute("PRAGMA journal_mode=WAL")
    _conn.execute("PRAGMA synchronous=FULL")
    _conn.execute("PRAGMA journal_size_limit=67108864")
    _conn.execute("PRAGMA wal_autocheckpoint=1000")
    return _conn


def init_db() -> None:
    """Create tables and indexes. Safe to call multiple times."""
    db = _get_db()
    db.executescript("""
        CREATE TABLE IF NOT EXISTS warf_artifacts (
            artifact_id          TEXT PRIMARY KEY,
            address              TEXT NOT NULL UNIQUE,
            domain               TEXT NOT NULL,
            category             TEXT NOT NULL,
            task                 TEXT NOT NULL,
            score                REAL NOT NULL DEFAULT 0.9,
            agent_id             TEXT NOT NULL DEFAULT 'mcp-agent',
            deposited_at         TEXT NOT NULL,
            audit_hash           TEXT NOT NULL,
            metadata_json        TEXT NOT NULL DEFAULT '{}',
            resolve_count        INTEGER NOT NULL DEFAULT 0,
            convergence_history  TEXT NOT NULL DEFAULT '[]'
        );

        CREATE UNIQUE INDEX IF NOT EXISTS idx_warf_address
            ON warf_artifacts(address);
    """)
    # FTS5 full-text search
    try:
        db.executescript("""
            CREATE VIRTUAL TABLE IF NOT EXISTS warf_fts USING fts5(
                address,
                domain,
                category,
                task,
                agent_id,
                metadata_text
            );
        """)
    except Exception:
        logger.warning("FTS5 not available")

    _rebuild_fts(db)
    db.commit()


# ─── Helpers ─────────────────────────────────────────────────────────────────

def _slugify(name: str) -> str:
    """Convert a name to a valid reason:// URI segment."""
    slug = name.lower()
    slug = re.sub(r"[^a-z0-9]+", "-", slug)
    slug = slug.strip("-")
    if not slug or not slug[0].isalpha():
        slug = "p-" + slug
    slug = slug[:63]
    if len(slug) < 2:
        slug = slug + "x"
    return slug


def _auto_address(
    content: str,
    tags: Optional[List[str]] = None,
    project: Optional[str] = None,
) -> str:
    """Generate a reason:// URI from content, tags, and project."""
    domain = _slugify(project) if project else "local"
    category = _slugify(tags[0]) if tags else "memory"
    # Generate task slug from content
    words = re.sub(r"[^a-z0-9\s]", "", content.lower()).split()[:5]
    task = _slugify("-".join(words)) if words else _slugify(uuid.uuid4().hex[:8])
    return f"reason://{domain}/{category}/{task}"


def _extract_metadata_text(metadata: Dict[str, Any]) -> str:
    """Extract searchable text from metadata for FTS indexing."""
    parts = []
    for val in metadata.values():
        if isinstance(val, str):
            parts.append(val)
        elif isinstance(val, list):
            for item in val:
                if isinstance(item, str):
                    parts.append(item)
    return " ".join(parts)


def _sync_fts(db: sqlite3.Connection, address: str, domain: str,
              category: str, task: str, agent_id: str, metadata: Dict[str, Any]) -> None:
    """Update FTS5 index for an artifact."""
    try:
        metadata_text = _extract_metadata_text(metadata)
        db.execute("DELETE FROM warf_fts WHERE address = ?", (address,))
        db.execute(
            "INSERT INTO warf_fts(address, domain, category, task, agent_id, metadata_text) "
            "VALUES (?, ?, ?, ?, ?, ?)",
            (address, domain, category, task, agent_id, metadata_text),
        )
    except Exception:
        pass


def _rebuild_fts(db: sqlite3.Connection) -> None:
    """Rebuild FTS5 index from all existing artifacts."""
    try:
        db.execute("DELETE FROM warf_fts")
        rows = db.execute(
            "SELECT address, domain, category, task, agent_id, metadata_json "
            "FROM warf_artifacts"
        ).fetchall()
        for r in rows:
            meta = json.loads(r["metadata_json"]) if r["metadata_json"] else {}
            metadata_text = _extract_metadata_text(meta)
            db.execute(
                "INSERT INTO warf_fts(address, domain, category, task, agent_id, metadata_text) "
                "VALUES (?, ?, ?, ?, ?, ?)",
                (r["address"], r["domain"], r["category"], r["task"],
                 r["agent_id"], metadata_text),
            )
    except Exception:
        logger.warning("FTS rebuild failed")


def _row_to_dict(row: sqlite3.Row) -> Dict[str, Any]:
    """Convert a database row to an artifact dict."""
    meta = json.loads(row["metadata_json"]) if row["metadata_json"] else {}
    history = json.loads(row["convergence_history"]) if row["convergence_history"] else []
    return {
        "artifact_id": row["artifact_id"],
        "address": row["address"],
        "domain": row["domain"],
        "category": row["category"],
        "task": row["task"],
        "score": row["score"],
        "agent_id": row["agent_id"],
        "deposited_at": row["deposited_at"],
        "audit_hash": row["audit_hash"],
        "metadata": meta,
        "resolve_count": row["resolve_count"],
        "convergence_history": history,
    }


# ─── Core Operations ────────────────────────────────────────────────────────

def upsert(
    address: str,
    metadata: Dict[str, Any],
    score: float = 0.9,
    agent_id: str = "mcp-agent",
) -> Optional[Dict[str, Any]]:
    """Insert or update an artifact at a reason:// address."""
    try:
        match = REASON_URI_PATTERN.match(address)
        if not match:
            return None

        domain, category, task = match.group(1), match.group(2), match.group(3)
        artifact_id = uuid.uuid4().hex
        deposited_at = datetime.now(timezone.utc).isoformat()

        audit_input = f"{artifact_id}|{address}|{score:.6f}|{agent_id}|{deposited_at}"
        audit_hash = hashlib.sha256(audit_input.encode()).hexdigest()

        # Get existing convergence history
        db = _get_db()
        existing = db.execute(
            "SELECT convergence_history FROM warf_artifacts WHERE address = ?",
            (address,),
        ).fetchone()
        history = []
        if existing and existing["convergence_history"]:
            try:
                history = json.loads(existing["convergence_history"])
            except Exception:
                history = []
        history.append(score)

        db.execute(
            "INSERT OR REPLACE INTO warf_artifacts "
            "(artifact_id, address, domain, category, task, score, agent_id, "
            "deposited_at, audit_hash, metadata_json, convergence_history) "
            "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)",
            (artifact_id, address, domain, category, task, score, agent_id,
             deposited_at, audit_hash, json.dumps(metadata), json.dumps(history)),
        )
        _sync_fts(db, address, domain, category, task, agent_id, metadata)
        db.commit()

        return {
            "artifact_id": artifact_id,
            "address": address,
            "deposited_at": deposited_at,
            "audit_hash": audit_hash,
            "score": score,
        }
    except Exception as e:
        logger.warning("Upsert failed: %s", e)
        return None


def resolve(address: str) -> Optional[Dict[str, Any]]:
    """Resolve a reason:// URI to its artifact."""
    try:
        db = _get_db()
        row = db.execute(
            "SELECT * FROM warf_artifacts WHERE address = ?", (address,)
        ).fetchone()
        if row is None:
            return None

        db.execute(
            "UPDATE warf_artifacts SET resolve_count = resolve_count + 1 WHERE address = ?",
            (address,),
        )
        db.commit()
        return _row_to_dict(row)
    except Exception as e:
        logger.warning("Resolve failed: %s", e)
        return None


def delete(address: str) -> bool:
    """Delete an artifact by address. Returns True if deleted."""
    try:
        db = _get_db()
        cur = db.execute("DELETE FROM warf_artifacts WHERE address = ?", (address,))
        db.execute("DELETE FROM warf_fts WHERE address = ?", (address,))
        db.commit()
        return cur.rowcount > 0
    except Exception:
        return False


def search_fts(query: str, limit: int = 20) -> List[Dict[str, Any]]:
    """Full-text search over artifact metadata via FTS5."""
    try:
        db = _get_db()
        fts_rows = db.execute(
            "SELECT address FROM warf_fts WHERE warf_fts MATCH ? "
            "ORDER BY rank LIMIT ?",
            (query, limit),
        ).fetchall()
        if not fts_rows:
            return []

        addresses = [r["address"] for r in fts_rows]
        placeholders = ",".join(["?"] * len(addresses))
        rows = db.execute(
            f"SELECT * FROM warf_artifacts WHERE address IN ({placeholders})",
            addresses,
        ).fetchall()
        return [_row_to_dict(r) for r in rows]
    except Exception:
        # FTS5 not available — fall back to LIKE
        try:
            db = _get_db()
            rows = db.execute(
                "SELECT * FROM warf_artifacts "
                "WHERE metadata_json LIKE ? OR address LIKE ? "
                "ORDER BY deposited_at DESC LIMIT ?",
                (f"%{query}%", f"%{query}%", limit),
            ).fetchall()
            return [_row_to_dict(r) for r in rows]
        except Exception:
            return []


def list_artifacts(
    domain: Optional[str] = None,
    category: Optional[str] = None,
    limit: int = 50,
) -> List[Dict[str, Any]]:
    """List artifacts with optional filters."""
    try:
        db = _get_db()
        conditions = []
        params: list = []
        if domain:
            conditions.append("domain = ?")
            params.append(domain)
        if category:
            conditions.append("category = ?")
            params.append(category)

        where = f"WHERE {' AND '.join(conditions)}" if conditions else ""
        params.append(limit)
        rows = db.execute(
            f"SELECT * FROM warf_artifacts {where} ORDER BY deposited_at DESC LIMIT ?",
            params,
        ).fetchall()
        return [_row_to_dict(r) for r in rows]
    except Exception:
        return []


def get_stats() -> Dict[str, Any]:
    """Get memory statistics."""
    try:
        db = _get_db()
        total = db.execute("SELECT COUNT(*) FROM warf_artifacts").fetchone()[0]
        resolves = db.execute(
            "SELECT COALESCE(SUM(resolve_count), 0) FROM warf_artifacts"
        ).fetchone()[0]
        domains = db.execute(
            "SELECT domain, COUNT(*) as cnt FROM warf_artifacts "
            "GROUP BY domain ORDER BY cnt DESC"
        ).fetchall()
        recent = db.execute(
            "SELECT address, deposited_at, metadata_json FROM warf_artifacts "
            "ORDER BY deposited_at DESC LIMIT 10"
        ).fetchall()

        return {
            "total_memories": total,
            "total_resolves": resolves,
            "db_path": str(DB_PATH),
            "domains": {r["domain"]: r["cnt"] for r in domains},
            "recent": [
                {
                    "address": r["address"],
                    "deposited_at": r["deposited_at"],
                    "preview": (json.loads(r["metadata_json"] or "{}").get("content", ""))[:100],
                }
                for r in recent
            ],
        }
    except Exception:
        return {"total_memories": 0, "error": "DB not initialized"}


def backup() -> Optional[str]:
    """Create an online backup. Returns backup path or None."""
    if not DB_PATH.exists():
        return None
    try:
        BACKUP_DIR.mkdir(parents=True, exist_ok=True)
        timestamp = datetime.now().strftime("%Y%m%d-%H%M%S")
        backup_path = BACKUP_DIR / f"memory-{timestamp}.db"

        src = sqlite3.connect(str(DB_PATH))
        dst = sqlite3.connect(str(backup_path))
        src.backup(dst)
        dst.close()
        src.close()

        # Rotate old backups
        backups = sorted(BACKUP_DIR.glob("memory-*.db"))
        while len(backups) > MAX_BACKUPS:
            backups.pop(0).unlink(missing_ok=True)

        return str(backup_path)
    except Exception as e:
        logger.warning("Backup failed: %s", e)
        return None
