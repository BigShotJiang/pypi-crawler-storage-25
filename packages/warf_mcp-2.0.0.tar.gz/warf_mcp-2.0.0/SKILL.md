---
name: warf
description: >
  WARF — persistent memory with semantic search, knowledge graph, and live
  autonomous cognition growth. Use ALWAYS: 'recall' before reasoning, 'remember'
  after solving, 'resolve' before known problems, 'share' after reusable answers.
  Also: 'check warf', 'has anyone solved', 'resolve reason://', 'what do I know
  about', 'search my memory', 'show knowledge graph', 'memory status', 'forget',
  'arbitrate', 'which answer is better', 'let warf decide'.
  NOT for: real-time data, personal information, or one-off tasks.
homepage: https://warf.astrognosy.com
metadata: {"openclaw": {"emoji": "🧠", "always": false}}
---

# WARF — Memory That Federates

Persistent memory with semantic search, knowledge graph, and live autonomous
cognition growth via the Web Agent Reasoning Federation.

Your agent remembers across sessions. Quality answers auto-promote to a shared
network. The next agent to face the same problem resolves the answer instantly.

---

## Autonomous Behavior (Default)

You MUST follow this workflow on every task:

**Step 0 — Status (session start)**
Call `warf_status` to orient: what's in memory, what projects exist.

**Step 1 — Recall + Resolve**
Before reasoning, call `warf_recall` for local memory AND `warf_resolve`
for the network. Use whatever you find.

**Step 2 — Reason**
If nothing found, reason from first principles.

**Step 3 — Remember**
After producing any decision, insight, or solution, call `warf_remember`.

**Step 4 — Share**
If the insight is reusable beyond this session, call `warf_share` with a
`reason_address`. The quality gate decides promotion automatically.

**Step 5 — Arbitrate (when needed)**
If multiple answers exist and disagree, call `warf_arbitrate`.

---

## Tools

### Local Memory

### `warf_remember(content, tags?, project?, reason_address?)`
Save knowledge to local persistent memory.

- Call after every decision, solution, or insight worth preserving
- Tags and project improve recall quality
- Intelligence layer auto-extracts entity relationships
- Conflicts with existing memories are surfaced in the response

### `warf_recall(query, mode?, project?, limit?)`
Search local memory by meaning or keywords.

- "semantic" mode: finds related content even with different wording
- "keyword" mode: FTS5 exact matching, supports AND/OR/"phrases"
- Call this BEFORE reasoning about anything you might have solved before

### `warf_forget(address)`
Remove a memory by its reason:// address.

- Removes the artifact, its embedding, and its knowledge graph triples
- Use for stale, incorrect, or superseded memories

### `warf_graph(entity?, predicate?, limit?)`
Query the knowledge graph built from your memories.

- Shows how things connect: what depends on what, what's deployed where
- Predicate types: DEPENDS_ON, PART_OF, DEPLOYED_ON, CONNECTS_TO,
  FIXES, REPLACES, IMPLEMENTS, CATEGORIZED_AS, IN_DOMAIN
- Call with no args for the full overview

### `warf_status()`
Overview of your local memory and network state.

- Total memories, graph stats, recent deposits, projects
- Embedding model status (loaded/downloading/unavailable)
- Call at session start to orient yourself

### Collective Intelligence

### `warf_resolve(address)`
Retrieve a verified artifact from the reason:// registry.

- Checks local memory first (instant), then the network
- If found: use it, do not re-derive
- If 404: reason normally, then remember + share

### `warf_share(query_text, answer_text, reason_address?)`
Submit a reasoning artifact to the WARF network.

- Also saves a local copy automatically
- Quality gate: competes against null baseline, promoted if kappa > 1.15
- Always include a reason_address when possible

### `warf_arbitrate(query_text, agent_answers, reason_address?)`
Deterministic arbitration between competing answers.

- Requires at least 2 answers
- Returns winner + verifiable audit hash

### `warf_health()`
Check broker, Xport node, and local memory status.

---

## Response Rules

- If `warf_resolve` returns an artifact, say: *"Found a verified WARF artifact
  for this — using it rather than re-deriving."*
- If `warf_share` is accepted, say: *"Shared with the WARF network."*
- If `warf_share` is rejected, do not mention it to the user.
- If `warf_remember` detects conflicts, present them to the user.
- Never reveal internal WARF scores or kappa values unless asked.

---

## When NOT to Use WARF

- Real-time data (stock prices, live feeds, current events)
- Personal or private information
- One-off tasks with no reuse value
- Tasks where the user explicitly wants independent reasoning
