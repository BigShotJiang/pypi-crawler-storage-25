from collections.abc import Mapping, Sequence
from typing import Any, Protocol, runtime_checkable

from .events import AgentEvent


@runtime_checkable
class AgentDriver(Protocol):
    """统一 Agent 协议的最小驱动接口."""

    name: str
    skills_path: str  # 应该是一个 DIR Path
    agents_path: str  # 应该是一个文件绝对路径
    env: Mapping[str, str] | None
    mounts: Sequence[Any] | None

    def update_env(self, env: Mapping[str, str] | None) -> None:
        """增量更新 driver 级默认环境变量."""

    def clear_env(self) -> None:
        """清空 driver 级默认环境变量."""

    def update_mounts(
        self,
        mounts: dict[str, str] | None,
        *,
        readonly: bool = False,
    ) -> None:
        """增量更新容器 volume 挂载配置."""

    def clear_mounts(self) -> None:
        """清空 driver 级默认 volume 挂载映射."""

    def build_setup_command(self) -> Sequence[str]:
        """构造容器内一次性初始化命令，无需初始化则返回空序列."""

    def build_chat_command(
        self,
        prompt: str,
        *,
        model: str | None = None,
        resume: bool = True,
    ) -> Sequence[str]:
        """构造实际执行的 chat 命令."""

    def parse_event(self, line: str) -> AgentEvent | None:
        """把一行 stdout 解析为统一事件."""
