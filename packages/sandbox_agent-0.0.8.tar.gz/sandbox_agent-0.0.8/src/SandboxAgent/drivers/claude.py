import os
from collections.abc import Mapping

from ..events import AgentEvent
from ..utils import _MountSpec, merge_mounts, normalize_env, normalize_mounts, validate_mounts


class ClaudeCodeDriver:
    """Claude Code 协议驱动."""

    name = "claude-code"
    skills_path = "/root/.claude/skills"
    agents_path = "/root/.claude/CLAUDE.md"

    def __init__(
        self,
        *,
        base_url: str | None = None,
        auth_token: str | None = None,
    ) -> None:
        env: dict[str, str] = {}
        if base_url:
            env["ANTHROPIC_BASE_URL"] = base_url
        if auth_token:
            env["ANTHROPIC_AUTH_TOKEN"] = auth_token
        self.env = normalize_env(env)
        self.mounts: list[_MountSpec] | None = None

    def update_env(self, env: Mapping[str, str] | None) -> None:
        new_env = normalize_env(env)
        if not new_env:
            return
        merged = dict(self.env or {})
        merged.update(new_env)
        self.env = merged

    def clear_env(self) -> None:
        self.env = None

    def _reserved_mount_paths(self) -> tuple[str, ...]:
        return (
            self.skills_path,
            self.agents_path,
            os.path.dirname(self.agents_path),
        )

    def update_mounts(
        self,
        mounts: dict[str, str] | None,
        *,
        readonly: bool = False,
    ) -> None:
        new_mounts = normalize_mounts(mounts, readonly=readonly)
        if not new_mounts:
            return
        merged = merge_mounts(self.mounts, new_mounts)
        self.mounts = validate_mounts(
            merged,
            reserved_paths=self._reserved_mount_paths(),
        )

    def clear_mounts(self) -> None:
        self.mounts = None

    def build_setup_command(self) -> Sequence[str]:
        return ()

    def build_chat_command(
        self,
        prompt: str,
        *,
        model: str | None = None,
        resume: bool = True,
    ) -> Sequence[str]:
        raise NotImplementedError(
            "ClaudeCodeDriver.build_chat_command() not implemented yet."
        )

    def parse_event(self, line: str) -> AgentEvent | None:
        raise NotImplementedError("ClaudeCodeDriver.parse_event() not implemented yet.")
