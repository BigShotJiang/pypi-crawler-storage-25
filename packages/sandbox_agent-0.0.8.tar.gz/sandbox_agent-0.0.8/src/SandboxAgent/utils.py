import base64
import os
from dataclasses import dataclass
from collections.abc import Mapping, Sequence


def shell_write_file(content: str | bytes, path: str) -> str:
    """构造 shell 命令片段, 通过 base64 编码将 content 安全写入指定路径.

    返回可直接嵌入 sh -c 的命令字符串片段, 不含 sh -c 前缀.

    Args:
        content: 要写入的文件内容.
        path: 容器内的目标文件路径.

    Returns:
        shell 命令片段, 如 "echo 'xxx' | base64 -d > /path/to/file".
    """
    if isinstance(content, str):
        content = content.encode("utf-8")
    encoded = base64.b64encode(content).decode("ascii")
    return f"echo '{encoded}' | base64 -d > {path}"


def normalize_env(env: Mapping[str, str] | None) -> dict[str, str] | None:
    """规范化环境变量映射.

    Args:
        env: 原始环境变量映射.

    Returns:
        规范化后的字典副本; 若为空则返回 None.

    Raises:
        TypeError: 当 key 或 value 不是字符串时抛出.
        ValueError: 当 key 为空或包含首尾空白时抛出.
    """
    if env is None:
        return None

    normalized: dict[str, str] = {}
    for key, value in env.items():
        if not isinstance(key, str):
            raise TypeError("Environment variable name must be str.")
        if not key or key != key.strip():
            raise ValueError("Environment variable name must be non-empty and trimmed.")
        if not isinstance(value, str):
            raise TypeError("Environment variable value must be str.")
        normalized[key] = value

    return normalized or None


@dataclass(frozen=True, slots=True)
class _MountSpec:
    """容器挂载的内部结构."""

    host_path: str
    container_path: str
    read_only: bool = False


def _normalize_abs_path(path: str, *, label: str) -> str:
    """规范化绝对路径字符串."""
    if not isinstance(path, str):
        raise TypeError(f"{label} must be str.")
    if not path or path != path.strip():
        raise ValueError(f"{label} must be non-empty and trimmed.")
    if path.endswith(":ro"):
        raise ValueError(f"{label} must not include ':ro' suffix.")
    if not os.path.isabs(path):
        raise ValueError(f"{label} must be absolute: {path!r}")
    return os.path.normpath(path)


def _paths_overlap(path_a: str, path_b: str) -> bool:
    """判断两个绝对路径是否存在父子覆盖关系."""
    common = os.path.commonpath([path_a, path_b])
    return common == path_a or common == path_b


def normalize_mounts(
    mounts: dict[str, str] | None,
    *,
    readonly: bool = False,
) -> list[_MountSpec] | None:
    """校验并规范化 volume 挂载输入.

    Args:
        mounts: {host_path: container_path} 映射.
        readonly: 此批次所有挂载是否只读.

    Returns:
        规范化后的挂载列表; 若为空则返回 None.

    Raises:
        TypeError: 输入类型不合法.
        ValueError: 路径非法、宿主机路径不存在.
    """
    if mounts is None:
        return None
    if not isinstance(mounts, dict):
        raise TypeError("Mounts must be a dict mapping host_path to container_path.")

    normalized: list[_MountSpec] = []
    for host, container in mounts.items():
        host_path = _normalize_abs_path(host, label="Mount host path")
        if not os.path.exists(host_path):
            raise ValueError(f"Mount host path does not exist: {host_path!r}")
        container_path = _normalize_abs_path(container, label="Mount container path")
        normalized.append(
            _MountSpec(
                host_path=host_path,
                container_path=container_path,
                read_only=readonly,
            )
        )

    return normalized or None


def merge_mounts(
    current: Sequence[_MountSpec] | None,
    updates: Sequence[_MountSpec] | None,
) -> list[_MountSpec] | None:
    """按 host_path 合并挂载配置."""
    merged: dict[str, _MountSpec] = {}
    for spec in current or ():
        merged[spec.host_path] = spec
    for spec in updates or ():
        merged[spec.host_path] = spec
    return list(merged.values()) or None


def validate_mounts(
    mounts: Sequence[_MountSpec] | None,
    *,
    reserved_paths: Sequence[str] | None = None,
) -> list[_MountSpec] | None:
    """校验挂载之间以及挂载与保留路径之间的冲突."""
    if mounts is None:
        return None

    normalized_reserved: list[str] = []
    for path in reserved_paths or ():
        normalized_reserved.append(
            _normalize_abs_path(path, label="Reserved container path")
        )

    mount_list = list(mounts)
    for index, spec in enumerate(mount_list):
        for other in mount_list[index + 1 :]:
            if spec.container_path == other.container_path:
                raise ValueError(
                    "Duplicate mount container path: "
                    f"{spec.container_path!r} is used by "
                    f"{spec.host_path!r} and {other.host_path!r}."
                )
            if _paths_overlap(spec.container_path, other.container_path):
                raise ValueError(
                    "Overlapping mount container paths are not allowed: "
                    f"{spec.container_path!r} <-> {other.container_path!r}."
                )

        for reserved_path in normalized_reserved:
            if _paths_overlap(spec.container_path, reserved_path):
                raise ValueError(
                    "Mount container path conflicts with reserved path: "
                    f"{spec.container_path!r} <-> {reserved_path!r}."
                )

    return mount_list or None
