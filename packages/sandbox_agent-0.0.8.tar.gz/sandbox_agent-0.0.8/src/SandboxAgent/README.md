# Sandbox Agent
---

### Env 规则
```
1. driver.env 是默认环境变量, 在容器启动时通过 docker run -e 注入.
2. SafeAgent.chat(..., env_override=...) 是单次 chat 覆盖, 仅作用于本次 docker exec.
3. chat 的 env_override 不会修改 driver.env.
4. driver.update_env(...) 是增量合并; driver.clear_env() 会清空默认环境变量.
5. 容器启动后再修改 driver.env, 不会影响当前已经运行的容器.
```

### Mount 规则
```
1. driver.update_mounts([...]) 是默认 volume 挂载配置, 在容器启动时通过 docker run -v 注入.
2. 每条 mount 都必须显式提供 host_path / container_path, read_only 默认为 False.
3. update_mounts(...) 是增量合并; 同一个 host_path 再次写入会覆盖旧配置.
4. 不接受 container_path:ro 这种字符串编码; 只读语义必须写在 read_only 字段里.
5. 不支持容器内父子路径重叠挂载, 也不支持多个 host_path 指向同一个 container_path.
6. 不支持覆盖 Agent 自己的关键路径, 包括 skills / AGENTS / auth 等内部路径.
7. host_path 和 container_path 都必须是绝对路径; host_path 必须已经存在.
8. 容器启动后再修改 driver.mounts, 不会影响当前已经运行的容器.
9. driver.clear_mounts() 会清空默认挂载配置.
```

### 通过 JSON Stream 调用 Agent
```bash
# codex
codex exec resume --last --json "我刚刚问你啥了"

# claude code
claude --continue --verbose --print --output-format "stream-json" "我刚刚问你啥了"

# opencode
opencode run --continue --format json --model "opencode/qwen3.6-plus-free" "我刚刚问你啥了"
```

### 配置系统
```
# codex
1. 全局配置文件
    - /root/.codex/config.toml
2. 身份认证文件
    - /root/.codex/auth.json
3. Skills 目录
    - /home/.agents/skills/<name>/SKILL.md
4. AGENTS 文件
    - /root/.codex/AGENTS.md

# claude code
1. 全局配置文件
    - /root/.claude/settings.json
2. 身份认证系统使用环境变量, 主要是下面的两个环境变量:
    - ANTHROPIC_BASE_URL
    - ANTHROPIC_AUTH_TOKEN
3. Skills 目录
    - /root/.claude/skills/<name>/SKILL.md
4. AGENTS 文件
    - /root/.claude/CLAUDE.md

# opencode
1. 全局配置文件
    - /root/.config/opencode/opencode.json
2. 身份认证文件
    - /root/.local/share/opencode/auth.json
3. Skills 目录
    - /root/.config/opencode/skills/<name>/SKILL.md
4. AGENTS 文件
    - /root/.config/opencode/AGENTS.md
```

### Mount 示例
```python
from SandboxAgent import OpenCodeDriver

driver = OpenCodeDriver(provider="demo", api_key="token")
driver.update_mounts(
    [
        {
            "host_path": "/workspace",
            "container_path": "/workspace",
        },
        {
            "host_path": "/srv/reference-data",
            "container_path": "/mnt/reference-data",
            "read_only": True,
        },
    ]
)

# 如果需要复用 driver 但不想继承旧挂载, 先清空
driver.clear_mounts()
driver.update_mounts(
    [
        {
            "host_path": "/workspace",
            "container_path": "/workspace",
        }
    ]
)
```
