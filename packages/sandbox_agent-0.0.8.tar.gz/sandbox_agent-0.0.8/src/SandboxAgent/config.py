import os

def _get_env(name: str, default, _type: type) -> str | int:
    """读取环境变量并按目标类型校验."""
    raw_value = os.environ.get(name)
    if raw_value is None:
        return _type(default)

    if _type is str:
        value = raw_value.strip()
        if not value:
            raise RuntimeError(f"{name} must be a non-empty string.")
        return str(value)

    if _type is int:
        try:
            value = int(raw_value)
        except ValueError as exc:
            raise RuntimeError(f"{name} must be an integer.") from exc
        return int(value)

    raise TypeError(f"Unsupported value_type: {_type!r}")


# 镜像名称
SANDBOX_AGENT_IMAGE_NAME = _get_env(
    "SANDBOX_AGENT_IMAGE_NAME",
    "donaldtrump/sandbox-agent:opencode-1.3.13-dev",
    str,
)

# 容器前缀
SANDBOX_AGENT_RESOURCE_PREFIX = _get_env(
    "SANDBOX_AGENT_RESOURCE_PREFIX",
    "safe-agent",
    str,
)

# 同时启动的容器数
SANDBOX_AGENT_MAX_CONTAINERS = _get_env(
    "SANDBOX_AGENT_MAX_CONTAINERS",
    20,
    int,
)
