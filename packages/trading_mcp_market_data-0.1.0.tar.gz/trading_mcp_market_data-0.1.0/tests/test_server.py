"""Tests for all 5 Market Data MCP tools."""

import httpx
import pytest

from market_data_server.providers import _circuit, is_crypto
from market_data_server.server import (
    _quote_cache,
    get_company_info,
    get_market_movers,
    get_ohlcv,
    get_quote,
    search_symbols,
)


# ═══════════════════════════════════════════════════════════════════
# Crypto detection
# ═══════════════════════════════════════════════════════════════════


class TestCryptoDetection:
    def test_known_symbols(self):
        assert is_crypto("BTC") is True
        assert is_crypto("ETH") is True
        assert is_crypto("SOL") is True

    def test_usd_suffix(self):
        assert is_crypto("BTC-USD") is True
        assert is_crypto("ETH-USDT") is True

    def test_stock_not_crypto(self):
        assert is_crypto("AAPL") is False
        assert is_crypto("MSFT") is False

    def test_case_insensitive(self):
        assert is_crypto("btc") is True
        assert is_crypto("Eth-usd") is True


# ═══════════════════════════════════════════════════════════════════
# Tool 1: get_quote
# ═══════════════════════════════════════════════════════════════════


class TestGetQuote:
    @pytest.mark.asyncio
    async def test_get_quote_happy_path(self, mock_routes, polygon_quote_response):
        mock_routes.get("https://api.polygon.io/v2/aggs/ticker/AAPL/prev").mock(
            return_value=httpx.Response(200, json=polygon_quote_response)
        )
        result = await get_quote("AAPL")
        assert result["symbol"] == "AAPL"
        assert result["price"] == 190.25
        assert "error" not in result
        assert result["source"] == "polygon"

    @pytest.mark.asyncio
    async def test_get_quote_fallback(self, mock_routes, finnhub_quote_response):
        mock_routes.get("https://api.polygon.io/v2/aggs/ticker/AAPL/prev").mock(
            return_value=httpx.Response(429)
        )
        mock_routes.get("https://finnhub.io/api/v1/quote").mock(
            return_value=httpx.Response(200, json=finnhub_quote_response)
        )
        result = await get_quote("AAPL")
        assert result["symbol"] == "AAPL"
        assert result["price"] == 190.25
        assert result["source"] == "finnhub"

    @pytest.mark.asyncio
    async def test_get_quote_all_providers_fail(self, mock_routes):
        mock_routes.get("https://api.polygon.io/v2/aggs/ticker/AAPL/prev").mock(
            return_value=httpx.Response(500)
        )
        mock_routes.get("https://finnhub.io/api/v1/quote").mock(
            return_value=httpx.Response(500)
        )
        mock_routes.get("https://www.alphavantage.co/query").mock(
            return_value=httpx.Response(500)
        )
        result = await get_quote("AAPL")
        assert "error" in result
        assert "Unable to fetch quote" in result["error"]

    @pytest.mark.asyncio
    async def test_get_quote_invalid_input(self):
        result = await get_quote("")
        assert "error" in result
        assert "required" in result["error"].lower()

    @pytest.mark.asyncio
    async def test_get_quote_no_api_key(self, mock_routes, monkeypatch):
        monkeypatch.setenv("POLYGON_API_KEY", "")
        monkeypatch.setenv("FINNHUB_API_KEY", "")
        monkeypatch.setenv("ALPHAVANTAGE_API_KEY", "")
        result = await get_quote("AAPL")
        assert "error" in result

    @pytest.mark.asyncio
    async def test_get_quote_crypto(self, mock_routes, coingecko_quote_response):
        mock_routes.get("https://api.coingecko.com/api/v3/simple/price").mock(
            return_value=httpx.Response(200, json=coingecko_quote_response)
        )
        result = await get_quote("BTC-USD")
        assert result["symbol"] == "BTC-USD"
        assert result["price"] == 43250.50
        assert result["source"] == "coingecko"


# ═══════════════════════════════════════════════════════════════════
# Tool 2: get_ohlcv
# ═══════════════════════════════════════════════════════════════════


class TestGetOHLCV:
    @pytest.mark.asyncio
    async def test_get_ohlcv_happy_path(self, mock_routes, polygon_ohlcv_response):
        mock_routes.get(url__regex=r"https://api\.polygon\.io/v2/aggs/ticker/.*").mock(
            return_value=httpx.Response(200, json=polygon_ohlcv_response)
        )
        result = await get_ohlcv("AAPL", "1d", "2024-01-01", "2024-01-15")
        assert result["symbol"] == "AAPL"
        assert result["interval"] == "1d"
        assert len(result["candles"]) == 2
        assert result["count"] == 2
        assert "error" not in result

    @pytest.mark.asyncio
    async def test_get_ohlcv_fallback(self, mock_routes, finnhub_ohlcv_response):
        mock_routes.get(url__regex=r"https://api\.polygon\.io/v2/aggs/ticker/.*").mock(
            return_value=httpx.Response(429)
        )
        mock_routes.get("https://finnhub.io/api/v1/stock/candle").mock(
            return_value=httpx.Response(200, json=finnhub_ohlcv_response)
        )
        result = await get_ohlcv("AAPL", "1d", "2024-01-01", "2024-01-15")
        assert len(result["candles"]) == 2
        assert result["source"] == "finnhub"

    @pytest.mark.asyncio
    async def test_get_ohlcv_all_providers_fail(self, mock_routes):
        mock_routes.get(url__regex=r"https://api\.polygon\.io/v2/aggs/ticker/.*").mock(
            return_value=httpx.Response(500)
        )
        mock_routes.get("https://finnhub.io/api/v1/stock/candle").mock(
            return_value=httpx.Response(500)
        )
        mock_routes.get("https://www.alphavantage.co/query").mock(
            return_value=httpx.Response(500)
        )
        result = await get_ohlcv("AAPL", "1d", "2024-01-01", "2024-01-15")
        assert "error" in result

    @pytest.mark.asyncio
    async def test_get_ohlcv_invalid_input(self):
        result = await get_ohlcv("AAPL", "invalid_tf")
        assert "error" in result
        assert "Invalid timeframe" in result["error"]

    @pytest.mark.asyncio
    async def test_get_ohlcv_no_api_key(self, monkeypatch):
        monkeypatch.setenv("POLYGON_API_KEY", "")
        monkeypatch.setenv("FINNHUB_API_KEY", "")
        monkeypatch.setenv("ALPHAVANTAGE_API_KEY", "")
        result = await get_ohlcv("AAPL", "1d", "2024-01-01", "2024-01-15")
        assert "error" in result

    @pytest.mark.asyncio
    async def test_get_ohlcv_defaults_dates(self, mock_routes, polygon_ohlcv_response):
        mock_routes.get(url__regex=r"https://api\.polygon\.io/v2/aggs/ticker/.*").mock(
            return_value=httpx.Response(200, json=polygon_ohlcv_response)
        )
        result = await get_ohlcv("AAPL", "1d")
        assert "error" not in result
        assert result["symbol"] == "AAPL"


# ═══════════════════════════════════════════════════════════════════
# Tool 3: search_symbols
# ═══════════════════════════════════════════════════════════════════


class TestSearchSymbols:
    @pytest.mark.asyncio
    async def test_search_symbols_happy_path(
        self, mock_routes, polygon_search_response
    ):
        mock_routes.get("https://api.polygon.io/v3/reference/tickers").mock(
            return_value=httpx.Response(200, json=polygon_search_response)
        )
        result = await search_symbols("Apple")
        assert "results" in result
        assert len(result["results"]) == 2
        assert result["results"][0]["symbol"] == "AAPL"

    @pytest.mark.asyncio
    async def test_search_symbols_fallback(self, mock_routes, finnhub_search_response):
        mock_routes.get("https://api.polygon.io/v3/reference/tickers").mock(
            return_value=httpx.Response(429)
        )
        mock_routes.get("https://finnhub.io/api/v1/search").mock(
            return_value=httpx.Response(200, json=finnhub_search_response)
        )
        result = await search_symbols("Apple")
        assert len(result["results"]) == 2
        assert result["source"] == "finnhub"

    @pytest.mark.asyncio
    async def test_search_symbols_all_providers_fail(self, mock_routes):
        mock_routes.get("https://api.polygon.io/v3/reference/tickers").mock(
            return_value=httpx.Response(500)
        )
        mock_routes.get("https://finnhub.io/api/v1/search").mock(
            return_value=httpx.Response(500)
        )
        result = await search_symbols("Apple")
        assert "error" in result

    @pytest.mark.asyncio
    async def test_search_symbols_invalid_input(self):
        result = await search_symbols("")
        assert "error" in result
        assert "required" in result["error"].lower()

    @pytest.mark.asyncio
    async def test_search_symbols_invalid_asset_type(self):
        result = await search_symbols("Apple", asset_type="invalid")
        assert "error" in result
        assert "Invalid asset_type" in result["error"]

    @pytest.mark.asyncio
    async def test_search_symbols_no_api_key(self, monkeypatch):
        monkeypatch.setenv("POLYGON_API_KEY", "")
        monkeypatch.setenv("FINNHUB_API_KEY", "")
        result = await search_symbols("Apple")
        assert "error" in result


# ═══════════════════════════════════════════════════════════════════
# Tool 4: get_market_movers
# ═══════════════════════════════════════════════════════════════════


class TestGetMarketMovers:
    @pytest.mark.asyncio
    async def test_get_market_movers_happy_path(
        self, mock_routes, polygon_movers_response
    ):
        mock_routes.get(url__regex=r"https://api\.polygon\.io/v2/snapshot/.*").mock(
            return_value=httpx.Response(200, json=polygon_movers_response)
        )
        result = await get_market_movers("gainers")
        assert "movers" in result
        assert len(result["movers"]) == 2
        assert result["type"] == "gainers"

    @pytest.mark.asyncio
    async def test_get_market_movers_fallback(self, mock_routes):
        # Polygon fails, Finnhub doesn't support movers — returns error
        mock_routes.get(url__regex=r"https://api\.polygon\.io/v2/snapshot/.*").mock(
            return_value=httpx.Response(429)
        )
        result = await get_market_movers("gainers")
        assert "error" in result

    @pytest.mark.asyncio
    async def test_get_market_movers_all_providers_fail(self, mock_routes):
        mock_routes.get(url__regex=r"https://api\.polygon\.io/v2/snapshot/.*").mock(
            return_value=httpx.Response(500)
        )
        result = await get_market_movers("gainers")
        assert "error" in result

    @pytest.mark.asyncio
    async def test_get_market_movers_invalid_input(self):
        result = await get_market_movers("invalid_type")
        assert "error" in result
        assert "Invalid mover_type" in result["error"]

    @pytest.mark.asyncio
    async def test_get_market_movers_invalid_market(self):
        result = await get_market_movers("gainers", market="forex")
        assert "error" in result
        assert "Invalid market" in result["error"]

    @pytest.mark.asyncio
    async def test_get_market_movers_no_api_key(self, monkeypatch):
        monkeypatch.setenv("POLYGON_API_KEY", "")
        monkeypatch.setenv("FINNHUB_API_KEY", "")
        result = await get_market_movers("gainers")
        assert "error" in result

    @pytest.mark.asyncio
    async def test_get_market_movers_crypto(
        self, mock_routes, coingecko_movers_response
    ):
        mock_routes.get("https://api.coingecko.com/api/v3/coins/markets").mock(
            return_value=httpx.Response(200, json=coingecko_movers_response)
        )
        result = await get_market_movers("gainers", market="crypto")
        assert "movers" in result
        assert result["movers"][0]["symbol"] == "BTC"


# ═══════════════════════════════════════════════════════════════════
# Tool 5: get_company_info
# ═══════════════════════════════════════════════════════════════════


class TestGetCompanyInfo:
    @pytest.mark.asyncio
    async def test_get_company_info_happy_path(
        self, mock_routes, polygon_company_response
    ):
        mock_routes.get("https://api.polygon.io/v3/reference/tickers/AAPL").mock(
            return_value=httpx.Response(200, json=polygon_company_response)
        )
        result = await get_company_info("AAPL")
        assert result["symbol"] == "AAPL"
        assert result["name"] == "Apple Inc."
        assert "error" not in result

    @pytest.mark.asyncio
    async def test_get_company_info_fallback(
        self, mock_routes, finnhub_company_response
    ):
        mock_routes.get("https://api.polygon.io/v3/reference/tickers/AAPL").mock(
            return_value=httpx.Response(429)
        )
        mock_routes.get("https://finnhub.io/api/v1/stock/profile2").mock(
            return_value=httpx.Response(200, json=finnhub_company_response)
        )
        result = await get_company_info("AAPL")
        assert result["name"] == "Apple Inc"
        assert result["source"] == "finnhub"

    @pytest.mark.asyncio
    async def test_get_company_info_all_providers_fail(self, mock_routes):
        mock_routes.get("https://api.polygon.io/v3/reference/tickers/AAPL").mock(
            return_value=httpx.Response(500)
        )
        mock_routes.get("https://finnhub.io/api/v1/stock/profile2").mock(
            return_value=httpx.Response(500)
        )
        result = await get_company_info("AAPL")
        assert "error" in result

    @pytest.mark.asyncio
    async def test_get_company_info_invalid_input(self):
        result = await get_company_info("")
        assert "error" in result
        assert "required" in result["error"].lower()

    @pytest.mark.asyncio
    async def test_get_company_info_crypto_rejected(self):
        result = await get_company_info("BTC-USD")
        assert "error" in result
        assert "only available for stocks" in result["error"]

    @pytest.mark.asyncio
    async def test_get_company_info_no_api_key(self, monkeypatch):
        monkeypatch.setenv("POLYGON_API_KEY", "")
        monkeypatch.setenv("FINNHUB_API_KEY", "")
        result = await get_company_info("AAPL")
        assert "error" in result


# ═══════════════════════════════════════════════════════════════════
# Cache behavior
# ═══════════════════════════════════════════════════════════════════


class TestCache:
    @pytest.mark.asyncio
    async def test_cache_hit(self, mock_routes, polygon_quote_response):
        route = mock_routes.get("https://api.polygon.io/v2/aggs/ticker/AAPL/prev").mock(
            return_value=httpx.Response(200, json=polygon_quote_response)
        )
        r1 = await get_quote("AAPL")
        r2 = await get_quote("AAPL")
        assert r1["price"] == r2["price"]
        assert route.call_count == 1  # second call hit cache


# ═══════════════════════════════════════════════════════════════════
# Circuit breaker
# ═══════════════════════════════════════════════════════════════════


class TestCircuitBreaker:
    @pytest.mark.asyncio
    async def test_circuit_breaker_skips_after_failures(
        self, mock_routes, finnhub_quote_response
    ):
        # Fail polygon 3 times to trip the breaker
        mock_routes.get("https://api.polygon.io/v2/aggs/ticker/AAPL/prev").mock(
            return_value=httpx.Response(500)
        )
        finnhub_route = mock_routes.get("https://finnhub.io/api/v1/quote").mock(
            return_value=httpx.Response(200, json=finnhub_quote_response)
        )
        mock_routes.get("https://www.alphavantage.co/query").mock(
            return_value=httpx.Response(500)
        )

        # First 3 calls trip polygon's circuit breaker
        for _ in range(3):
            _quote_cache.clear()
            await get_quote("AAPL")

        # Polygon breaker should now be open
        assert _circuit.is_open("polygon") is True

        # Next call should skip polygon entirely and go to finnhub
        _quote_cache.clear()
        prev_count = finnhub_route.call_count
        result = await get_quote("AAPL")
        assert result["source"] == "finnhub"
        assert finnhub_route.call_count > prev_count
