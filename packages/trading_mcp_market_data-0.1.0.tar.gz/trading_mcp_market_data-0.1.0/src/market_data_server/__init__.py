"""Market Data MCP server."""
