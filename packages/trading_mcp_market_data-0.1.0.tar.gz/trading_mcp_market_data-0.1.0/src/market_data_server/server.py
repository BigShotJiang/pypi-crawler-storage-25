"""Market Data MCP server — 5 tools for stock and crypto market data."""

from datetime import date, datetime, timedelta

from fastmcp import FastMCP

from trading_mcp_shared.cache import TTLCacheWrapper
from trading_mcp_shared.types import OHLCVCandle, OHLCVResponse, Quote

from market_data_server.providers import DataProviderPool, is_crypto

mcp = FastMCP("Market Data")

_pool = DataProviderPool()

# ── Caches with per-tool TTL ────────────────────────────────────

_quote_cache = TTLCacheWrapper(maxsize=512, ttl=5)
_ohlcv_intraday_cache = TTLCacheWrapper(maxsize=256, ttl=60)
_ohlcv_daily_cache = TTLCacheWrapper(maxsize=256, ttl=3600)
_search_cache = TTLCacheWrapper(maxsize=128, ttl=86400)
_movers_cache = TTLCacheWrapper(maxsize=64, ttl=180)
_company_cache = TTLCacheWrapper(maxsize=128, ttl=21600)

# ── Valid enum values ───────────────────────────────────────────

_VALID_TIMEFRAMES = {"1min", "5min", "15min", "30min", "1h", "4h", "1d", "1w"}
_INTRADAY_TIMEFRAMES = {"1min", "5min", "15min", "30min", "1h", "4h"}
_VALID_ASSET_TYPES = {"stock", "crypto", "etf", "all"}
_VALID_MOVER_TYPES = {"gainers", "losers", "active", "all"}
_VALID_MARKETS = {"stocks", "crypto"}


# ── Tool 1: get_quote ───────────────────────────────────────────


@mcp.tool()
async def get_quote(symbol: str, exchange: str = "AUTO") -> dict:
    """Get latest price quote for a stock or crypto symbol.

    Args:
        symbol: Ticker symbol e.g. "AAPL", "BTC-USD", "ETH-USDT"
        exchange: Optional exchange hint: "NYSE", "NASDAQ", "BINANCE", "COINBASE". Defaults to auto-detect.
    """
    try:
        symbol = symbol.upper().strip()
        if not symbol:
            return {"error": "Symbol is required."}

        cache_key = f"quote:{symbol}"
        cached = _quote_cache.get(cache_key)
        if cached is not None:
            return cached

        crypto = is_crypto(symbol)
        data = await _pool.fetch_quote(symbol, crypto=crypto)

        result = Quote(
            symbol=data["symbol"],
            price=data["price"],
            change=data["change"],
            changePercent=data["changePercent"],
            volume=data["volume"],
            high=data.get("high"),
            low=data.get("low"),
            open=data.get("open"),
            previousClose=data.get("previousClose"),
            marketCap=data.get("marketCap"),
            timestamp=datetime.fromisoformat(data["timestamp"]),
        ).model_dump(by_alias=True)
        result["source"] = data.get("source", "unknown")

        _quote_cache.set(cache_key, result)
        return result
    except Exception as e:
        print(f"[market_data] error: {e}")
        return {"error": f"Unable to fetch quote for {symbol} — {e}"}


# ── Tool 2: get_ohlcv ───────────────────────────────────────────


@mcp.tool()
async def get_ohlcv(
    symbol: str,
    timeframe: str,
    from_date: str = "",
    to_date: str = "",
    limit: int = 200,
) -> dict:
    """Fetch OHLCV candlestick data for a given symbol and timeframe.

    Args:
        symbol: Ticker symbol e.g. "AAPL", "BTC-USD"
        timeframe: Candle interval: 1min, 5min, 15min, 30min, 1h, 4h, 1d, 1w
        from_date: Start date in ISO 8601 format. Defaults to 30 days ago.
        to_date: End date in ISO 8601 format. Defaults to today.
        limit: Maximum candles to return (max 1000). Defaults to 200.
    """
    try:
        symbol = symbol.upper().strip()
        if not symbol:
            return {"error": "Symbol is required."}
        if timeframe not in _VALID_TIMEFRAMES:
            return {
                "error": f"Invalid timeframe '{timeframe}'. Must be one of: {', '.join(sorted(_VALID_TIMEFRAMES))}"
            }
        limit = max(1, min(limit, 1000))

        today = date.today()
        if not to_date:
            to_date = today.isoformat()
        if not from_date:
            from_date = (today - timedelta(days=30)).isoformat()

        cache_key = f"ohlcv:{symbol}:{timeframe}:{from_date}:{to_date}"
        cache = (
            _ohlcv_intraday_cache
            if timeframe in _INTRADAY_TIMEFRAMES
            else _ohlcv_daily_cache
        )
        cached = cache.get(cache_key)
        if cached is not None:
            return cached

        crypto = is_crypto(symbol)
        data = await _pool.fetch_ohlcv(
            symbol, timeframe, from_date, to_date, limit, crypto=crypto
        )

        candles = [
            OHLCVCandle(
                timestamp=datetime.fromisoformat(c["timestamp"]),
                open=c["open"],
                high=c["high"],
                low=c["low"],
                close=c["close"],
                volume=c["volume"],
            )
            for c in data.get("candles", [])
        ]
        result = OHLCVResponse(
            symbol=symbol,
            interval=timeframe,
            candles=candles,
        ).model_dump(by_alias=True, mode="json")
        result["count"] = len(candles)
        result["source"] = data.get("source", "unknown")

        cache.set(cache_key, result)
        return result
    except Exception as e:
        print(f"[market_data] error: {e}")
        return {"error": f"Unable to fetch OHLCV for {symbol} — {e}"}


# ── Tool 3: search_symbols ──────────────────────────────────────


@mcp.tool()
async def search_symbols(
    query: str,
    asset_type: str = "all",
    limit: int = 10,
) -> dict:
    """Search for stock or crypto symbols by name or ticker.

    Args:
        query: Search term e.g. "Apple", "AAPL", "bitcoin"
        asset_type: Filter by type: stock, crypto, etf, all. Defaults to "all".
        limit: Max results (max 30). Defaults to 10.
    """
    try:
        query = query.strip()
        if not query:
            return {"error": "Query is required."}
        if asset_type not in _VALID_ASSET_TYPES:
            return {
                "error": f"Invalid asset_type '{asset_type}'. Must be one of: {', '.join(sorted(_VALID_ASSET_TYPES))}"
            }
        limit = max(1, min(limit, 30))

        cache_key = f"search:{query}:{asset_type}"
        cached = _search_cache.get(cache_key)
        if cached is not None:
            return cached

        data = await _pool.fetch_search(query, asset_type, limit)
        result = {
            "results": data.get("results", [])[:limit],
            "source": data.get("source", "unknown"),
        }

        _search_cache.set(cache_key, result)
        return result
    except Exception as e:
        print(f"[market_data] error: {e}")
        return {"error": f"Unable to search for '{query}' — {e}"}


# ── Tool 4: get_market_movers ───────────────────────────────────


@mcp.tool()
async def get_market_movers(
    mover_type: str,
    market: str = "stocks",
    limit: int = 10,
) -> dict:
    """Get top gainers, losers, and most active tickers for the current session.

    Args:
        mover_type: Type of movers: gainers, losers, active, all
        market: Market to query: stocks, crypto. Defaults to "stocks".
        limit: Number of results. Defaults to 10.
    """
    try:
        if mover_type not in _VALID_MOVER_TYPES:
            return {
                "error": f"Invalid mover_type '{mover_type}'. Must be one of: {', '.join(sorted(_VALID_MOVER_TYPES))}"
            }
        if market not in _VALID_MARKETS:
            return {
                "error": f"Invalid market '{market}'. Must be one of: {', '.join(sorted(_VALID_MARKETS))}"
            }
        limit = max(1, min(limit, 25))

        if mover_type == "all":
            results = {}
            for mt in ("gainers", "losers", "active"):
                cache_key = f"movers:{mt}:{market}"
                cached = _movers_cache.get(cache_key)
                if cached is not None:
                    results[mt] = cached.get("movers", [])
                else:
                    data = await _pool.fetch_movers(mt, market, limit)
                    movers = data.get("movers", [])[:limit]
                    _movers_cache.set(cache_key, {"movers": movers})
                    results[mt] = movers
            return {
                "gainers": results["gainers"],
                "losers": results["losers"],
                "active": results["active"],
                "market": market,
            }

        cache_key = f"movers:{mover_type}:{market}"
        cached = _movers_cache.get(cache_key)
        if cached is not None:
            return cached

        data = await _pool.fetch_movers(mover_type, market, limit)
        result = {
            "movers": data.get("movers", [])[:limit],
            "type": mover_type,
            "market": market,
            "source": data.get("source", "unknown"),
        }

        _movers_cache.set(cache_key, result)
        return result
    except Exception as e:
        print(f"[market_data] error: {e}")
        return {"error": f"Unable to fetch market movers — {e}"}


# ── Tool 5: get_company_info ────────────────────────────────────


@mcp.tool()
async def get_company_info(symbol: str) -> dict:
    """Get company profile and fundamental information for a stock symbol.

    Args:
        symbol: Stock ticker symbol e.g. "AAPL", "MSFT"
    """
    try:
        symbol = symbol.upper().strip()
        if not symbol:
            return {"error": "Symbol is required."}

        if is_crypto(symbol):
            return {
                "error": "Company info is only available for stocks. For crypto use get_quote to see market data."
            }

        cache_key = f"company:{symbol}"
        cached = _company_cache.get(cache_key)
        if cached is not None:
            return cached

        data = await _pool.fetch_company_info(symbol)
        result = {
            "symbol": data.get("symbol", symbol),
            "name": data.get("name", ""),
            "description": data.get("description", ""),
            "sector": data.get("sector", ""),
            "industry": data.get("industry", ""),
            "marketCap": data.get("marketCap"),
            "employees": data.get("employees"),
            "url": data.get("url", ""),
            "exchange": data.get("exchange", ""),
            "country": data.get("country", ""),
            "source": data.get("source", "unknown"),
        }

        _company_cache.set(cache_key, result)
        return result
    except Exception as e:
        print(f"[market_data] error: {e}")
        return {"error": f"Unable to fetch company info for {symbol} — {e}"}


def main() -> None:
    mcp.run()
