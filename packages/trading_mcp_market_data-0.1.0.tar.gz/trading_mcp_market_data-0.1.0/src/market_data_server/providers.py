"""Data provider pool with failover and circuit breaker."""

import os
import time
from datetime import datetime, timezone

import httpx

from trading_mcp_shared.errors import ProviderError, RateLimitError

_TIMEOUT = 3.0

# ── Known crypto symbols for auto-detection ──────────────────────

KNOWN_CRYPTO = {
    "BTC",
    "ETH",
    "SOL",
    "XRP",
    "ADA",
    "DOGE",
    "DOT",
    "AVAX",
    "MATIC",
    "LINK",
}
CRYPTO_SUFFIXES = ("-USD", "-USDT", "-BTC")


def is_crypto(symbol: str) -> bool:
    upper = symbol.upper()
    base = upper.split("-")[0]
    if base in KNOWN_CRYPTO:
        return True
    return any(upper.endswith(s) for s in CRYPTO_SUFFIXES)


# ── Circuit breaker ──────────────────────────────────────────────


class CircuitBreaker:
    """Skip a provider after `threshold` failures within `window` seconds."""

    def __init__(self, threshold: int = 3, window: float = 60.0):
        self._threshold = threshold
        self._window = window
        self._failures: dict[str, list[float]] = {}

    def record_failure(self, provider: str) -> None:
        now = time.monotonic()
        fails = self._failures.setdefault(provider, [])
        fails.append(now)
        cutoff = now - self._window
        self._failures[provider] = [t for t in fails if t > cutoff]

    def is_open(self, provider: str) -> bool:
        fails = self._failures.get(provider, [])
        cutoff = time.monotonic() - self._window
        recent = [t for t in fails if t > cutoff]
        self._failures[provider] = recent
        return len(recent) >= self._threshold

    def reset(self, provider: str) -> None:
        self._failures.pop(provider, None)


# ── Provider implementations ─────────────────────────────────────


_circuit = CircuitBreaker()


def _polygon_key() -> str:
    return os.environ.get("POLYGON_API_KEY", "")


def _finnhub_key() -> str:
    return os.environ.get("FINNHUB_API_KEY", "")


def _alphavantage_key() -> str:
    return os.environ.get("ALPHAVANTAGE_API_KEY", "")


def _coingecko_key() -> str:
    return os.environ.get("COINGECKO_API_KEY", "")


async def _request(
    client: httpx.AsyncClient,
    provider: str,
    url: str,
    params: dict | None = None,
    headers: dict | None = None,
) -> dict:
    """Make a request, raising ProviderError/RateLimitError on failure."""
    resp = await client.get(url, params=params, headers=headers, timeout=_TIMEOUT)
    if resp.status_code == 429:
        raise RateLimitError(provider)
    if resp.status_code != 200:
        raise ProviderError(provider, f"HTTP {resp.status_code}", resp.status_code)
    return resp.json()


# ── Quote providers ──────────────────────────────────────────────


async def _polygon_quote(client: httpx.AsyncClient, symbol: str) -> dict:
    key = _polygon_key()
    if not key:
        raise ProviderError("polygon", "No API key")
    data = await _request(
        client,
        "polygon",
        f"https://api.polygon.io/v2/aggs/ticker/{symbol}/prev",
        params={"apiKey": key},
    )
    results = data.get("results", [{}])[0] if data.get("results") else {}
    return {
        "symbol": symbol,
        "price": results.get("c", 0),
        "change": results.get("c", 0) - results.get("o", 0),
        "changePercent": (
            ((results.get("c", 0) - results.get("o", 0)) / results.get("o", 1)) * 100
            if results.get("o")
            else 0
        ),
        "volume": int(results.get("v", 0)),
        "high": results.get("h"),
        "low": results.get("l"),
        "open": results.get("o"),
        "previousClose": results.get("o"),
        "marketCap": None,
        "timestamp": datetime.now(timezone.utc).isoformat(),
        "source": "polygon",
    }


async def _finnhub_quote(client: httpx.AsyncClient, symbol: str) -> dict:
    key = _finnhub_key()
    if not key:
        raise ProviderError("finnhub", "No API key")
    data = await _request(
        client,
        "finnhub",
        "https://finnhub.io/api/v1/quote",
        params={"symbol": symbol, "token": key},
    )
    return {
        "symbol": symbol,
        "price": data.get("c", 0),
        "change": data.get("d", 0),
        "changePercent": data.get("dp", 0),
        "volume": int(data.get("v", 0) or 0),
        "high": data.get("h"),
        "low": data.get("l"),
        "open": data.get("o"),
        "previousClose": data.get("pc"),
        "marketCap": None,
        "timestamp": datetime.now(timezone.utc).isoformat(),
        "source": "finnhub",
    }


async def _alphavantage_quote(client: httpx.AsyncClient, symbol: str) -> dict:
    key = _alphavantage_key()
    if not key:
        raise ProviderError("alphavantage", "No API key")
    data = await _request(
        client,
        "alphavantage",
        "https://www.alphavantage.co/query",
        params={"function": "GLOBAL_QUOTE", "symbol": symbol, "apikey": key},
    )
    gq = data.get("Global Quote", {})
    price = float(gq.get("05. price", 0))
    prev = float(gq.get("08. previous close", 0))
    return {
        "symbol": symbol,
        "price": price,
        "change": float(gq.get("09. change", 0)),
        "changePercent": float(gq.get("10. change percent", "0").rstrip("%") or 0),
        "volume": int(gq.get("06. volume", 0)),
        "high": float(gq.get("03. high", 0)) or None,
        "low": float(gq.get("04. low", 0)) or None,
        "open": float(gq.get("02. open", 0)) or None,
        "previousClose": prev or None,
        "marketCap": None,
        "timestamp": datetime.now(timezone.utc).isoformat(),
        "source": "alphavantage",
    }


async def _coingecko_quote(client: httpx.AsyncClient, symbol: str) -> dict:
    coin_id = symbol.upper().split("-")[0].lower()
    coin_map = {
        "btc": "bitcoin",
        "eth": "ethereum",
        "sol": "solana",
        "xrp": "ripple",
        "ada": "cardano",
        "doge": "dogecoin",
        "dot": "polkadot",
        "avax": "avalanche-2",
        "matic": "matic-network",
        "link": "chainlink",
    }
    coin_id = coin_map.get(coin_id, coin_id)
    params: dict = {
        "ids": coin_id,
        "vs_currencies": "usd",
        "include_24hr_change": "true",
        "include_24hr_vol": "true",
        "include_market_cap": "true",
    }
    key = _coingecko_key()
    headers = {}
    if key:
        headers["x-cg-demo-key"] = key
    data = await _request(
        client,
        "coingecko",
        "https://api.coingecko.com/api/v3/simple/price",
        params=params,
        headers=headers,
    )
    info = data.get(coin_id, {})
    price = info.get("usd", 0)
    change_pct = info.get("usd_24h_change", 0) or 0
    return {
        "symbol": symbol.upper(),
        "price": price,
        "change": price * change_pct / 100 if price else 0,
        "changePercent": change_pct,
        "volume": int(info.get("usd_24h_vol", 0) or 0),
        "high": None,
        "low": None,
        "open": None,
        "previousClose": None,
        "marketCap": info.get("usd_market_cap"),
        "timestamp": datetime.now(timezone.utc).isoformat(),
        "source": "coingecko",
    }


# ── OHLCV providers ─────────────────────────────────────────────


_POLYGON_TF_MAP = {
    "1min": ("1", "minute"),
    "5min": ("5", "minute"),
    "15min": ("15", "minute"),
    "30min": ("30", "minute"),
    "1h": ("1", "hour"),
    "4h": ("4", "hour"),
    "1d": ("1", "day"),
    "1w": ("1", "week"),
}

_FINNHUB_RESOLUTION_MAP = {
    "1min": "1",
    "5min": "5",
    "15min": "15",
    "30min": "30",
    "1h": "60",
    "4h": "240",
    "1d": "D",
    "1w": "W",
}


async def _polygon_ohlcv(
    client: httpx.AsyncClient,
    symbol: str,
    timeframe: str,
    from_date: str,
    to_date: str,
    limit: int,
) -> dict:
    key = _polygon_key()
    if not key:
        raise ProviderError("polygon", "No API key")
    mult, span = _POLYGON_TF_MAP.get(timeframe, ("1", "day"))
    data = await _request(
        client,
        "polygon",
        f"https://api.polygon.io/v2/aggs/ticker/{symbol}/range/{mult}/{span}/{from_date}/{to_date}",
        params={"apiKey": key, "limit": limit, "sort": "asc"},
    )
    candles = []
    for r in (data.get("results") or [])[:limit]:
        candles.append(
            {
                "timestamp": datetime.fromtimestamp(
                    r["t"] / 1000, tz=timezone.utc
                ).isoformat(),
                "open": r["o"],
                "high": r["h"],
                "low": r["l"],
                "close": r["c"],
                "volume": int(r.get("v", 0)),
            }
        )
    return {
        "symbol": symbol,
        "timeframe": timeframe,
        "candles": candles,
        "source": "polygon",
    }


async def _finnhub_ohlcv(
    client: httpx.AsyncClient,
    symbol: str,
    timeframe: str,
    from_date: str,
    to_date: str,
    limit: int,
) -> dict:
    key = _finnhub_key()
    if not key:
        raise ProviderError("finnhub", "No API key")
    resolution = _FINNHUB_RESOLUTION_MAP.get(timeframe, "D")
    from_ts = int(datetime.fromisoformat(from_date).timestamp())
    to_ts = int(datetime.fromisoformat(to_date).timestamp())
    data = await _request(
        client,
        "finnhub",
        "https://finnhub.io/api/v1/stock/candle",
        params={
            "symbol": symbol,
            "resolution": resolution,
            "from": from_ts,
            "to": to_ts,
            "token": key,
        },
    )
    if data.get("s") == "no_data":
        return {
            "symbol": symbol,
            "timeframe": timeframe,
            "candles": [],
            "source": "finnhub",
        }
    candles = []
    timestamps = data.get("t", [])
    for i in range(min(len(timestamps), limit)):
        candles.append(
            {
                "timestamp": datetime.fromtimestamp(
                    timestamps[i], tz=timezone.utc
                ).isoformat(),
                "open": data["o"][i],
                "high": data["h"][i],
                "low": data["l"][i],
                "close": data["c"][i],
                "volume": int(data["v"][i]),
            }
        )
    return {
        "symbol": symbol,
        "timeframe": timeframe,
        "candles": candles,
        "source": "finnhub",
    }


async def _alphavantage_ohlcv(
    client: httpx.AsyncClient,
    symbol: str,
    timeframe: str,
    from_date: str,
    to_date: str,
    limit: int,
) -> dict:
    key = _alphavantage_key()
    if not key:
        raise ProviderError("alphavantage", "No API key")
    if timeframe in ("1min", "5min", "15min", "30min", "1h"):
        func = "TIME_SERIES_INTRADAY"
        interval_map = {
            "1min": "1min",
            "5min": "5min",
            "15min": "15min",
            "30min": "30min",
            "1h": "60min",
        }
        params: dict = {
            "function": func,
            "symbol": symbol,
            "interval": interval_map[timeframe],
            "apikey": key,
            "outputsize": "full",
        }
    else:
        func = "TIME_SERIES_DAILY"
        params = {
            "function": func,
            "symbol": symbol,
            "apikey": key,
            "outputsize": "full",
        }
    data = await _request(
        client, "alphavantage", "https://www.alphavantage.co/query", params=params
    )
    ts_key = next((k for k in data if "Time Series" in k), None)
    if not ts_key:
        return {
            "symbol": symbol,
            "timeframe": timeframe,
            "candles": [],
            "source": "alphavantage",
        }
    candles = []
    from_dt = datetime.fromisoformat(from_date)
    to_dt = datetime.fromisoformat(to_date)
    for dt_str, vals in sorted(data[ts_key].items()):
        dt = datetime.fromisoformat(dt_str)
        if dt < from_dt or dt > to_dt:
            continue
        candles.append(
            {
                "timestamp": dt.isoformat(),
                "open": float(vals["1. open"]),
                "high": float(vals["2. high"]),
                "low": float(vals["3. low"]),
                "close": float(vals["4. close"]),
                "volume": int(vals["5. volume"]),
            }
        )
        if len(candles) >= limit:
            break
    return {
        "symbol": symbol,
        "timeframe": timeframe,
        "candles": candles,
        "source": "alphavantage",
    }


async def _coingecko_ohlcv(
    client: httpx.AsyncClient,
    symbol: str,
    timeframe: str,
    from_date: str,
    to_date: str,
    limit: int,
) -> dict:
    coin_id = symbol.upper().split("-")[0].lower()
    coin_map = {
        "btc": "bitcoin",
        "eth": "ethereum",
        "sol": "solana",
        "xrp": "ripple",
        "ada": "cardano",
        "doge": "dogecoin",
        "dot": "polkadot",
        "avax": "avalanche-2",
        "matic": "matic-network",
        "link": "chainlink",
    }
    coin_id = coin_map.get(coin_id, coin_id)
    from_ts = int(datetime.fromisoformat(from_date).timestamp())
    to_ts = int(datetime.fromisoformat(to_date).timestamp())
    params: dict = {"vs_currency": "usd", "from": from_ts, "to": to_ts}
    headers = {}
    key = _coingecko_key()
    if key:
        headers["x-cg-demo-key"] = key
    data = await _request(
        client,
        "coingecko",
        f"https://api.coingecko.com/api/v3/coins/{coin_id}/ohlc",
        params=params,
        headers=headers,
    )
    candles = []
    for row in (data if isinstance(data, list) else [])[:limit]:
        candles.append(
            {
                "timestamp": datetime.fromtimestamp(
                    row[0] / 1000, tz=timezone.utc
                ).isoformat(),
                "open": row[1],
                "high": row[2],
                "low": row[3],
                "close": row[4],
                "volume": 0,
            }
        )
    return {
        "symbol": symbol,
        "timeframe": timeframe,
        "candles": candles,
        "source": "coingecko",
    }


# ── Search providers ─────────────────────────────────────────────


async def _polygon_search(
    client: httpx.AsyncClient,
    query: str,
    asset_type: str,
    limit: int,
) -> dict:
    key = _polygon_key()
    if not key:
        raise ProviderError("polygon", "No API key")
    params: dict = {"apiKey": key, "search": query, "limit": limit, "active": "true"}
    if asset_type == "stock":
        params["market"] = "stocks"
    elif asset_type == "crypto":
        params["market"] = "crypto"
    elif asset_type == "etf":
        params["market"] = "stocks"
        params["type"] = "ETF"
    data = await _request(
        client, "polygon", "https://api.polygon.io/v3/reference/tickers", params=params
    )
    results = []
    for r in (data.get("results") or [])[:limit]:
        results.append(
            {
                "symbol": r.get("ticker", ""),
                "name": r.get("name", ""),
                "type": r.get("type", ""),
                "exchange": r.get("primary_exchange", ""),
                "currency": r.get("currency_name", "USD"),
            }
        )
    return {"results": results, "source": "polygon"}


async def _finnhub_search(
    client: httpx.AsyncClient,
    query: str,
    asset_type: str,
    limit: int,
) -> dict:
    key = _finnhub_key()
    if not key:
        raise ProviderError("finnhub", "No API key")
    data = await _request(
        client,
        "finnhub",
        "https://finnhub.io/api/v1/search",
        params={"q": query, "token": key},
    )
    results = []
    for r in (data.get("result") or [])[:limit]:
        sym_type = r.get("type", "")
        if asset_type != "all":
            if asset_type == "stock" and sym_type not in ("Common Stock", "EQS", ""):
                continue
            if asset_type == "crypto" and "crypto" not in sym_type.lower():
                continue
        results.append(
            {
                "symbol": r.get("symbol", ""),
                "name": r.get("description", ""),
                "type": sym_type,
                "exchange": r.get("displaySymbol", ""),
                "currency": "",
            }
        )
    return {"results": results[:limit], "source": "finnhub"}


# ── Market movers providers ─────────────────────────────────────


async def _polygon_movers(
    client: httpx.AsyncClient,
    mover_type: str,
    market: str,
    limit: int,
) -> dict:
    key = _polygon_key()
    if not key:
        raise ProviderError("polygon", "No API key")
    direction = "gainers" if mover_type == "gainers" else "losers"
    if mover_type == "active":
        direction = "gainers"
    data = await _request(
        client,
        "polygon",
        f"https://api.polygon.io/v2/snapshot/locale/us/markets/stocks/{direction}",
        params={"apiKey": key},
    )
    results = []
    for t in (data.get("tickers") or [])[:limit]:
        day = t.get("day", {})
        results.append(
            {
                "symbol": t.get("ticker", ""),
                "price": day.get("c", 0),
                "change": t.get("todaysChange", 0),
                "changePercent": t.get("todaysChangePerc", 0),
                "volume": int(day.get("v", 0)),
            }
        )
    return {
        "movers": results,
        "type": mover_type,
        "market": market,
        "source": "polygon",
    }


async def _finnhub_movers(
    client: httpx.AsyncClient,
    mover_type: str,
    market: str,
    limit: int,
) -> dict:
    key = _finnhub_key()
    if not key:
        raise ProviderError("finnhub", "No API key")
    # Finnhub doesn't have a direct movers endpoint for free tier;
    # use market news as a fallback signal
    raise ProviderError("finnhub", "Movers not available on free tier")


async def _coingecko_movers(
    client: httpx.AsyncClient,
    mover_type: str,
    market: str,
    limit: int,
) -> dict:
    params: dict = {
        "vs_currency": "usd",
        "order": "market_cap_desc",
        "per_page": 100,
        "page": 1,
        "sparkline": "false",
        "price_change_percentage": "24h",
    }
    headers = {}
    key = _coingecko_key()
    if key:
        headers["x-cg-demo-key"] = key
    data = await _request(
        client,
        "coingecko",
        "https://api.coingecko.com/api/v3/coins/markets",
        params=params,
        headers=headers,
    )
    coins = data if isinstance(data, list) else []
    if mover_type == "gainers":
        coins = sorted(
            coins, key=lambda c: c.get("price_change_percentage_24h") or 0, reverse=True
        )
    elif mover_type == "losers":
        coins = sorted(coins, key=lambda c: c.get("price_change_percentage_24h") or 0)
    elif mover_type == "active":
        coins = sorted(coins, key=lambda c: c.get("total_volume") or 0, reverse=True)
    results = []
    for c in coins[:limit]:
        results.append(
            {
                "symbol": (c.get("symbol") or "").upper(),
                "price": c.get("current_price", 0),
                "change": c.get("price_change_24h", 0),
                "changePercent": c.get("price_change_percentage_24h", 0),
                "volume": int(c.get("total_volume", 0) or 0),
            }
        )
    return {
        "movers": results,
        "type": mover_type,
        "market": market,
        "source": "coingecko",
    }


# ── Company info providers ───────────────────────────────────────


async def _polygon_company(client: httpx.AsyncClient, symbol: str) -> dict:
    key = _polygon_key()
    if not key:
        raise ProviderError("polygon", "No API key")
    data = await _request(
        client,
        "polygon",
        f"https://api.polygon.io/v3/reference/tickers/{symbol}",
        params={"apiKey": key},
    )
    r = data.get("results", {})
    return {
        "symbol": r.get("ticker", symbol),
        "name": r.get("name", ""),
        "description": r.get("description", ""),
        "sector": r.get("sic_description", ""),
        "industry": r.get("sic_description", ""),
        "marketCap": r.get("market_cap"),
        "employees": r.get("total_employees"),
        "url": r.get("homepage_url", ""),
        "exchange": r.get("primary_exchange", ""),
        "country": r.get("locale", ""),
        "source": "polygon",
    }


async def _finnhub_company(client: httpx.AsyncClient, symbol: str) -> dict:
    key = _finnhub_key()
    if not key:
        raise ProviderError("finnhub", "No API key")
    data = await _request(
        client,
        "finnhub",
        "https://finnhub.io/api/v1/stock/profile2",
        params={"symbol": symbol, "token": key},
    )
    return {
        "symbol": data.get("ticker", symbol),
        "name": data.get("name", ""),
        "description": "",
        "sector": data.get("finnhubIndustry", ""),
        "industry": data.get("finnhubIndustry", ""),
        "marketCap": data.get("marketCapitalization"),
        "employees": None,
        "url": data.get("weburl", ""),
        "exchange": data.get("exchange", ""),
        "country": data.get("country", ""),
        "source": "finnhub",
    }


# ── DataProviderPool ─────────────────────────────────────────────


class DataProviderPool:
    """Tries providers in priority order with circuit-breaker protection."""

    def __init__(self) -> None:
        self._client: httpx.AsyncClient | None = None

    async def _get_client(self) -> httpx.AsyncClient:
        if self._client is None or self._client.is_closed:
            self._client = httpx.AsyncClient()
        return self._client

    async def close(self) -> None:
        if self._client and not self._client.is_closed:
            await self._client.aclose()

    async def _try_chain(
        self, providers: list[tuple[str, object]], *args: object
    ) -> dict:
        last_err: Exception | None = None
        for name, fn in providers:
            if _circuit.is_open(name):
                continue
            try:
                client = await self._get_client()
                result = await fn(client, *args)
                _circuit.reset(name)
                return result
            except Exception as exc:
                _circuit.record_failure(name)
                last_err = exc
        raise ProviderError("all", f"All providers failed: {last_err}")

    async def fetch_quote(self, symbol: str, crypto: bool = False) -> dict:
        if crypto:
            chain = [("coingecko", _coingecko_quote), ("finnhub", _finnhub_quote)]
        else:
            chain = [
                ("polygon", _polygon_quote),
                ("finnhub", _finnhub_quote),
                ("alphavantage", _alphavantage_quote),
            ]
        return await self._try_chain(chain, symbol)

    async def fetch_ohlcv(
        self,
        symbol: str,
        timeframe: str,
        from_date: str,
        to_date: str,
        limit: int,
        crypto: bool = False,
    ) -> dict:
        if crypto:
            chain = [("coingecko", _coingecko_ohlcv), ("finnhub", _finnhub_ohlcv)]
        else:
            chain = [
                ("polygon", _polygon_ohlcv),
                ("finnhub", _finnhub_ohlcv),
                ("alphavantage", _alphavantage_ohlcv),
            ]
        return await self._try_chain(
            chain, symbol, timeframe, from_date, to_date, limit
        )

    async def fetch_search(self, query: str, asset_type: str, limit: int) -> dict:
        chain = [("polygon", _polygon_search), ("finnhub", _finnhub_search)]
        return await self._try_chain(chain, query, asset_type, limit)

    async def fetch_movers(self, mover_type: str, market: str, limit: int) -> dict:
        if market == "crypto":
            chain = [("coingecko", _coingecko_movers)]
        else:
            chain = [("polygon", _polygon_movers), ("finnhub", _finnhub_movers)]
        return await self._try_chain(chain, mover_type, market, limit)

    async def fetch_company_info(self, symbol: str) -> dict:
        chain = [("polygon", _polygon_company), ("finnhub", _finnhub_company)]
        return await self._try_chain(chain, symbol)
