"""Entry point: uv run python -m market_data_server"""

from market_data_server.server import mcp

mcp.run()
