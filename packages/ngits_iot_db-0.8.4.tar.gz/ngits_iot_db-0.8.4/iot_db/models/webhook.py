from sqlalchemy import Boolean, Column, DateTime, Index, String, Text, text
from sqlalchemy.dialects.postgresql import UUID

from iot_db.models.base import Base


class WebhookRegistration(Base):
    """
    Webhook registration for IoT data synchronization.

    Stores webhook endpoints that should be notified when new IoT measurements
    are processed. Supports multiple environments per tenant.
    """

    __tablename__ = "webhook_registrations"

    id = Column(
        UUID(as_uuid=True),
        primary_key=True,
        server_default=text("gen_random_uuid()"),
    )
    tenant_id = Column(String(128), nullable=False)
    env = Column(String(32), nullable=False, server_default="prod")
    app_name = Column(String(128), nullable=False)
    webhook_url = Column(Text, nullable=False)
    secret_token = Column(String(256), nullable=False)
    is_active = Column(Boolean, nullable=False, server_default=text("true"))
    created_at = Column(
        DateTime(timezone=True),
        nullable=False,
        server_default=text("now()"),
    )
    updated_at = Column(
        DateTime(timezone=True),
        nullable=False,
        server_default=text("now()"),
        onupdate=text("now()"),
    )

    __table_args__ = (
        Index(
            "idx_webhook_tenant_env",
            "tenant_id",
            "env",
            "is_active",
        ),
    )

    def __repr__(self):
        return (
            f"<WebhookRegistration(id={self.id}, "
            f"tenant_id={self.tenant_id}, env={self.env}, "
            f"app_name={self.app_name}, is_active={self.is_active})>"
        )
