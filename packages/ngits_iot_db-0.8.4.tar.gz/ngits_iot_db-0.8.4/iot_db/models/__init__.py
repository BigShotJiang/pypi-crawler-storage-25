"""IoT Database Models - SQLAlchemy models for IoT sensor data storage."""

from .ai_analysis import (
    AIAnalysisConfig,
    AnomalyDetection,
    AnomalyExecution,
    Recommendation,
    RecommendationExecution,
)
from .alert import Alert, AlertDefinition
from .base import (
    AlertBase,
    AlertLevels,
    AlertTypes,
    MeasurementBase,
    Sources,
    Types,
    Units,
)
from .commands import CommandDeviceMapping, CommandLog, CommandQueue
from .dimensions import DimChannelFunction, DimDataSource, DimDate, DimDevice, DimTime
from .electricity import (
    DailyElectricityUsage,
    ElectricityMeasurement,
    MonthlyElectricityUsage,
)
from .facts import FactMeasurement, FactState, FactUsage
from .heat import DailyHeatUsage, HeatMeasurement, MonthlyHeatUsage
from .raw import RawMeasurement
from .rules import ConditionOperator, Rule, RuleExecution, RuleExecutionStatus
from .temperature import TemperatureMeasurement
from .water import DailyWaterUsage, MonthlyWaterUsage, WaterMeasurement
from .webhook import WebhookRegistration

__all__ = [
    "AIAnalysisConfig",
    "Alert",
    "AlertDefinition",
    "AlertLevels",
    "AlertTypes",
    "AnomalyDetection",
    "AnomalyExecution",
    "CommandDeviceMapping",
    "CommandLog",
    "CommandQueue",
    "ConditionOperator",
    "DailyElectricityUsage",
    "DailyHeatUsage",
    "DailyWaterUsage",
    "DimChannelFunction",
    "DimDataSource",
    "DimDevice",
    "DimDate",
    "DimTime",
    "ElectricityMeasurement",
    "FactMeasurement",
    "FactState",
    "FactUsage",
    "HeatMeasurement",
    "map_daily_usage_class",
    "map_measurement_class",
    "map_monthly_usage_class",
    "MonthlyElectricityUsage",
    "MonthlyHeatUsage",
    "MonthlyWaterUsage",
    "RawMeasurement",
    "Recommendation",
    "RecommendationExecution",
    "Rule",
    "RuleExecution",
    "RuleExecutionStatus",
    "Sources",
    "TemperatureMeasurement",
    "Types",
    "Units",
    "WaterMeasurement",
    "WebhookRegistration",
]


def map_measurement_class(type_: Types):
    match type_:
        case Types.electricity:
            return ElectricityMeasurement
        case Types.water:
            return WaterMeasurement
        case Types.heat:
            return HeatMeasurement
        case Types.temperature:
            return TemperatureMeasurement
        case _:
            raise NotImplementedError


def map_daily_usage_class(type_: Types):
    match type_:
        case Types.electricity:
            return DailyElectricityUsage
        case Types.water:
            return DailyWaterUsage
        case Types.heat:
            return DailyHeatUsage
        case Types.temperature:
            return None
        case _:
            raise NotImplementedError


def map_monthly_usage_class(type_: Types):
    match type_:
        case Types.electricity:
            return MonthlyElectricityUsage
        case Types.water:
            return MonthlyWaterUsage
        case Types.heat:
            return MonthlyHeatUsage
        case Types.temperature:
            return None
        case _:
            raise NotImplementedError
