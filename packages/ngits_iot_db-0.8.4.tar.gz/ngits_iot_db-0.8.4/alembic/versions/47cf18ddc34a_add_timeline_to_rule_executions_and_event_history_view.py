"""Add timeline to rule_executions and create v_event_history view

Revision ID: 47cf18ddc34a
Revises: c1ca1623010a
Create Date: 2026-04-20 00:10:00

"""

from typing import Sequence, Union

import sqlalchemy as sa
from sqlalchemy.dialects.postgresql import JSONB

from alembic import op

# revision identifiers, used by Alembic.
revision: str = "47cf18ddc34a"
down_revision: Union[str, None] = "c1ca1623010a"
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None

EVENT_HISTORY_VIEW = """
CREATE OR REPLACE VIEW v_event_history AS

-- Auto rules (rule_executions)
SELECT
    re.id::text                                             AS id,
    re.evaluated_at                                         AS timestamp,
    CASE WHEN re.status = 'error' THEN 'error' ELSE 'auto' END AS mode,
    CASE
        WHEN re.status IN ('triggered', 'sent') THEN 'executed'
        WHEN re.status = 'error'                THEN 'error'
        ELSE 'skipped'
    END                                                     AS status,
    COALESCE(dd_target.device_name, 'Nieznane urządzenie')
        || ' → ' || UPPER(r.action)                         AS action,
    'Reguła: ' || r.name                                    AS context,
    r.name                                                  AS rule_name,
    dd_source.device_name                                   AS condition,
    r.condition_operator || ' ' || r.condition_value::text  AS condition_value,
    re.execution_time_ms::float / 1000.0                    AS execution_time_s,
    re.timeline                                             AS timeline,
    re.tenant::text                                         AS tenant
FROM rule_executions re
JOIN rules r ON re.rule_id = r.id
LEFT JOIN dim_device dd_target
    ON dd_target.meter_id = r.target_device_id
    AND dd_target.tenant = re.tenant
LEFT JOIN dim_device dd_source
    ON dd_source.meter_id = r.source_device_id
    AND dd_source.tenant = re.tenant

UNION ALL

-- Alerts (alert table)
SELECT
    a.id::text                                              AS id,
    a.detected_ts                                           AS timestamp,
    'alert'                                                 AS mode,
    'executed'                                              AS status,
    'Alert: ' || COALESCE(
        a.details->>'message',
        ad.device_name,
        'Alert'
    )                                                       AS action,
    'Reguła: ' || COALESCE(ad.device_name, 'Alert')         AS context,
    ad.device_name                                          AS rule_name,
    dd.device_name                                          AS condition,
    CASE a.type
        WHEN 10 THEN 'Urządzenie offline'
        WHEN 1  THEN 'Próg przekroczony (wysoki)'
        WHEN 2  THEN 'Próg przekroczony (niski)'
        WHEN 3  THEN 'Nagła zmiana wartości'
        WHEN 11 THEN 'Brak danych'
        WHEN 12 THEN 'Opóźnienie danych'
        ELSE COALESCE(a.details->>'message', 'Alert')
    END                                                     AS condition_value,
    NULL::float                                             AS execution_time_s,
    (a.details->'timeline')::jsonb                           AS timeline,
    a.tenant::text                                          AS tenant
FROM alert a
JOIN alert_definition ad ON a.alert_definition_id = ad.id
LEFT JOIN dim_device dd
    ON dd.meter_id = a.meter_id
    AND dd.tenant = a.tenant

UNION ALL

-- Manual commands (command_log — created_by is not a rule)
SELECT
    cl.id::text                                             AS id,
    cl.created_at                                           AS timestamp,
    CASE WHEN cl.event_type = 'failed' THEN 'error' ELSE 'manual' END AS mode,
    CASE
        WHEN cl.event_type = 'completed' THEN 'executed'
        WHEN cl.event_type = 'failed'    THEN 'error'
        ELSE 'skipped'
    END                                                     AS status,
    COALESCE(dd.device_name, cl.platform_device_id)
        || ' → ' || UPPER(cl.action)                        AS action,
    'Użytkownik: ' || COALESCE(cl.created_by, 'Nieznany')  AS context,
    NULL                                                    AS rule_name,
    NULL                                                    AS condition,
    cl.event_data->>'message'                               AS condition_value,
    cl.execution_time_ms::float / 1000.0                    AS execution_time_s,
    NULL::jsonb                                             AS timeline,
    cl.tenant::text                                         AS tenant
FROM command_log cl
LEFT JOIN dim_device dd
    ON dd.meter_id = cl.device_id
    AND dd.tenant::text = cl.tenant::text
WHERE cl.event_type IN ('completed', 'failed')
  AND (cl.created_by IS NULL OR cl.created_by NOT LIKE 'rule:%')

UNION ALL

-- AI anomaly detections (anomaly_detection)
SELECT
    anom.id::text                                           AS id,
    anom.detected_at                                        AS timestamp,
    'ai'                                                    AS mode,
    'executed'                                              AS status,
    'Anomalia: ' || anom.anomaly_type
        || ' — ' || COALESCE(dd.device_name, anom.device_id::text) AS action,
    'AI: ' || anom.algorithm_used                           AS context,
    NULL                                                    AS rule_name,
    COALESCE(dd.device_name, anom.device_id::text)          AS condition,
    ROUND(anom.deviation_percentage::numeric, 1)::text || '%'
        || ' (' || anom.severity || ')'                     AS condition_value,
    NULL::float                                             AS execution_time_s,
    NULL::jsonb                                             AS timeline,
    anom.tenant::text                                       AS tenant
FROM anomaly_detection anom
LEFT JOIN dim_device dd
    ON dd.id = anom.device_id
    AND dd.tenant = anom.tenant;
"""


def upgrade() -> None:
    op.add_column(
        "rule_executions",
        sa.Column("execution_time_ms", sa.Integer(), nullable=True),
    )
    op.add_column(
        "rule_executions",
        sa.Column("timeline", JSONB(), nullable=True),
    )
    op.execute(EVENT_HISTORY_VIEW)


def downgrade() -> None:
    op.execute("DROP VIEW IF EXISTS v_event_history")
    op.drop_column("rule_executions", "timeline")
    op.drop_column("rule_executions", "execution_time_ms")
