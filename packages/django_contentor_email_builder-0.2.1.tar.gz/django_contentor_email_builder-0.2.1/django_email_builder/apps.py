import logging
import threading
from django.apps import AppConfig

logger = logging.getLogger('django_email_builder')


class DjangoEmailBuilderConfig(AppConfig):
    name = 'django_email_builder'
    default_auto_field = 'django.db.models.BigAutoField'
    verbose_name = 'Email Builder'

    def ready(self):
        # Defer sync to a background thread so the server finishes booting first.
        # When calling our own API (EMAIL_BUILDER_API_URL = http://backend:8000),
        # the server must be listening before we can reach it.
        thread = threading.Timer(5.0, self._sync_variables)
        thread.daemon = True
        thread.start()

    def _sync_variables(self):
        try:
            from django_email_builder.conf import get_config
            from django_email_builder.client import MailCraftClient
            from django_email_builder.resolvers import variables_to_api_format

            config = get_config()
            if not config['variables']:
                return

            client = MailCraftClient(config['api_key'], config['api_url'])
            api_vars = variables_to_api_format(config['variables'])
            client.sync_variables(api_vars)
            logger.info('django-email-builder: synced %d variables to MailCraft', len(api_vars))
        except Exception as e:
            logger.warning('django-email-builder: failed to sync variables on startup: %s', e)
