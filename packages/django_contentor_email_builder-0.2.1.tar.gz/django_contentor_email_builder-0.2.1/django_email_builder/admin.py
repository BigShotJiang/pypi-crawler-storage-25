from django.contrib import admin
from django.contrib.auth import get_user_model
from django.contrib.auth.admin import UserAdmin
from django.http import HttpResponseRedirect
from django.urls import include, path, reverse

User = get_user_model()


@admin.action(description='Send email with Email Builder')
def send_email_with_builder(modeladmin, request, queryset):
    user_ids = list(queryset.values_list('pk', flat=True))
    request.session['email_builder_user_ids'] = user_ids
    return HttpResponseRedirect(reverse('admin:email_builder:builder'))


# Unregister default UserAdmin, re-register with our action
if admin.site.is_registered(User):
    admin.site.unregister(User)


@admin.register(User)
class EmailBuilderUserAdmin(UserAdmin):
    actions = list(UserAdmin.actions or []) + [send_email_with_builder]


# Register our URLs under admin
_original_get_urls = admin.AdminSite.get_urls


def _patched_get_urls(self):
    from django_email_builder import urls as eb_urls
    custom_urls = [
        path('email-builder/', include((eb_urls.urlpatterns, 'email_builder'))),
    ]
    return custom_urls + _original_get_urls(self)


admin.AdminSite.get_urls = _patched_get_urls


# Inject "Email" app into admin index
_original_get_app_list = admin.AdminSite.get_app_list


def _patched_get_app_list(self, request, app_label=None):
    app_list = _original_get_app_list(self, request, app_label=app_label)

    if app_label and app_label != 'email':
        return app_list

    email_app = {
        'name': 'Email',
        'app_label': 'email',
        'app_url': reverse('admin:email_builder:compose'),
        'has_module_perms': True,
        'models': [
            {
                'name': 'Compose Email',
                'object_name': 'compose',
                'admin_url': reverse('admin:email_builder:compose'),
                'view_only': False,
                'perms': {'add': True, 'change': True, 'delete': False, 'view': True},
            },
        ],
    }

    if app_label == 'email':
        return [email_app]

    app_list.insert(0, email_app)
    return app_list


admin.AdminSite.get_app_list = _patched_get_app_list
