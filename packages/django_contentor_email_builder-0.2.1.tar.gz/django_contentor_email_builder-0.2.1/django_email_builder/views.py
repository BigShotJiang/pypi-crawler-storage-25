import json
import logging
from django.contrib.admin.views.decorators import staff_member_required
from django.contrib.auth import get_user_model
from django.core.mail import send_mail
from django.conf import settings as django_settings
from django.http import HttpResponseRedirect, JsonResponse
from django.shortcuts import render
from django.urls import reverse
from django.views.decorators.http import require_GET, require_POST

from django_email_builder.client import MailCraftClient
from django_email_builder.conf import get_config
from django_email_builder.resolvers import resolve_variables

logger = logging.getLogger('django_email_builder')
User = get_user_model()


@staff_member_required
@require_GET
def compose_view(request):
    """Landing page: select users then proceed to builder."""
    users = User.objects.filter(is_active=True).order_by('first_name', 'last_name', 'email')
    return render(request, 'django_email_builder/compose.html', {
        'users': users,
        'title': 'Compose Email',
    })


@staff_member_required
def builder_view(request):
    # Accept user selection from compose form (POST) or session (GET from action)
    if request.method == 'POST':
        user_ids = request.POST.getlist('user_ids')
        user_ids = [int(uid) for uid in user_ids if uid.isdigit()]
        if user_ids:
            request.session['email_builder_user_ids'] = user_ids

    user_ids = request.session.get('email_builder_user_ids', [])
    if not user_ids:
        return HttpResponseRedirect(reverse('admin:email_builder:compose'))

    config = get_config()
    client = MailCraftClient(config['api_key'], config['api_url'])

    origin = request.build_absolute_uri('/').rstrip('/')
    try:
        session_data = client.create_session(origin)
    except Exception as e:
        logger.error('Failed to create MailCraft session: %s', e)
        return render(request, 'django_email_builder/builder.html', {
            'error': f'Could not connect to Email Builder: {e}',
            'user_count': len(user_ids),
        })

    session_token = session_data['token']
    builder_url = f"{config['builder_url']}/builder/?sessionToken={session_token}"

    return render(request, 'django_email_builder/builder.html', {
        'builder_url': builder_url,
        'builder_origin': config['builder_url'],
        'user_count': len(user_ids),
        'confirm_url': reverse('admin:email_builder:confirm'),
    })


@staff_member_required
@require_POST
def confirm_view(request):
    user_ids = request.session.get('email_builder_user_ids', [])
    if not user_ids:
        return HttpResponseRedirect(reverse('admin:auth_user_changelist'))

    template_json = json.loads(request.POST.get('template_json', '{}'))
    template_html = request.POST.get('template_html', '')

    users = User.objects.filter(pk__in=user_ids)

    return render(request, 'django_email_builder/confirm.html', {
        'users': users,
        'user_count': users.count(),
        'template_json': json.dumps(template_json),
        'template_html': template_html,
        'send_url': reverse('admin:email_builder:send'),
    })


@staff_member_required
@require_POST
def send_view(request):
    user_ids = request.session.get('email_builder_user_ids', [])
    if not user_ids:
        return JsonResponse({'error': 'No recipients selected'}, status=400)

    subject = request.POST.get('subject', '').strip()
    if not subject:
        return JsonResponse({'error': 'Subject is required'}, status=400)

    template_json = json.loads(request.POST.get('template_json', '{}'))

    config = get_config()
    client = MailCraftClient(config['api_key'], config['api_url'])
    users = User.objects.filter(pk__in=user_ids)
    from_email = getattr(django_settings, 'DEFAULT_FROM_EMAIL', 'webmaster@localhost')

    sent = 0
    failed = 0
    for user in users:
        try:
            variables = resolve_variables(user, config['variables'])
            html = client.render(template_json, variables)
            send_mail(
                subject=subject,
                message='',
                from_email=from_email,
                recipient_list=[user.email],
                html_message=html,
            )
            sent += 1
        except Exception as e:
            logger.error('Failed to send email to %s: %s', user.email, e)
            failed += 1

    # Clear session
    request.session.pop('email_builder_user_ids', None)

    return JsonResponse({'sent': sent, 'failed': failed, 'total': sent + failed})
