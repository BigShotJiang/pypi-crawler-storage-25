from forgeo import rigs


def _copy_node(tree_from, tree_to, node_id):
    # first / second = sides of node(id)
    children_first, children_second = tree_from.children(node_id)
    for child_id in children_first:
        tree_to.add_child(node_id, rigs.Side.first, child_id)
        _copy_node(tree_from, tree_to, child_id)
    for child_id in children_second:
        tree_to.add_child(node_id, rigs.Side.second, child_id)
        _copy_node(tree_from, tree_to, child_id)


def _extract_subtree_for_domain_evaluation(
    tree: rigs.BSPTree, domains_root: int, topography: int
):
    # FIXME Clearly not ideal, this is a temporary patch waiting for a
    # for longer-term solution
    # rigs.which_domain currently requires a "real" BSP. A BSPTree that has
    # faults does not respect this condition. We want the domain evaluation
    # to start from topography, so we recreate a tree that has only topography
    # and stratigraphy.
    roots = tree.roots()
    assert len(roots) == 1
    assert topography in roots
    subtree = rigs.BSPTree()
    subtree.add_node(topography)
    _, above_topography = tree.children(topography)
    assert len(above_topography) == 1
    subtree.add_child(topography, rigs.Side.second, above_topography.pop())
    subtree.add_child(topography, rigs.Side.first, domains_root)
    _copy_node(tree, subtree, domains_root)
    assert subtree.consistent_trees(verbose=True)
    return subtree, topography


def _convert(domains, map):
    for k, v in map.items():
        if k != v:
            domains[domains == k] = v


def which_domain(vertices, *, include_topography=True, **params):
    tree = params.pop("tree")
    domains_root = params["domains_root"]
    topography = params["topography"]
    if include_topography and topography is not None:
        tree, domains_root = _extract_subtree_for_domain_evaluation(
            tree, domains_root, topography
        )
    domains = rigs.which_domain(vertices, tree=tree, root=domains_root, **params)
    _convert(domains, params["domains_map"])
    return domains
