import abc
from collections.abc import Callable, Iterable
from dataclasses import dataclass

from forgeo.core import Interpolator


@dataclass
class DiscInfo:  # FIXME Unsure what to do with this class...
    # k = fault surface id (and index) in BSPTreeBuilder
    # v = fault surface drift function index in self.drifts
    along: dict  # dict[int: int]
    drifts: list  # list[pypot.Drift]


# Over-encapsulation, but best clean/quick compromise to integrate boundaries
# into the overall code logic
@dataclass
class BoundaryWrapper:
    """
    Wraps a callable representing the domain of existence of a surface as the
    0-isovalue of a scalar field

    Paramaters
    ----------
    method : str
        Name of the interpolation method to use to interpolate
    field : Callable
        The functor that will evaluate the scalar field
    """

    method: str
    field: Callable

    @property
    def value(self):
        return None  # Assumed to be 0

    @staticmethod
    def get_boundary_name(bounded_object_name: str):
        return bounded_object_name + "-boundary"


@dataclass
class FaultWrapper:
    """
    Wraps a callable representing a fault as the 0-isovalue of a scalar field

    Paramaters
    ----------
    method : str
        Name of the interpolation method to use to interpolate
    field : Callable
        The functor that will evaluate the scalar field
    boundary : BoundaryWrapper | None
        The scalar field limiting the extension of the fault, if any
    """

    method: str
    field: Callable
    boundary: BoundaryWrapper | None

    @property
    def value(self):
        return None  # Assumed to be 0

    @classmethod
    def wrap(cls, method: str, fault: Callable, boundary: Callable | None):
        if boundary is not None:
            boundary = BoundaryWrapper(method, boundary)
        return cls(method, fault, boundary)


@dataclass
class InterfaceWrapper:
    """
    Wraps a callable representing a stratigraphic interface as some isovalue of
    a scalar field

    Paramaters
    ----------
    method : str
        Name of the interpolation method to use to interpolate
    field : Callable
        The functor that will evaluate the scalar field
    value : float
        The isovalue that represents this interface in the scalar field
    discontinuities : DiscInfo
        The discontinuities (typically faults) affecting the scalar field, if any
    """

    method: str
    field: Callable
    value: float
    discontinuities: DiscInfo | None


@dataclass
class BSPTreeNode:
    id: int
    name: str
    functor: FaultWrapper | BoundaryWrapper | InterfaceWrapper | None
    color: str = None

    def is_fault(self):
        return isinstance(self.functor, FaultWrapper)


class InterpolationMethodBase(abc.ABC):
    @property
    def name(self) -> str:
        """Name of the interpolation method, used as a UID to identify the method

        Must be implemented in any derived class
        """

        msg = "Interpolation method classes must provide a name property"
        raise NotImplementedError(msg)

    @abc.abstractmethod
    def get_stratigraphic_series_functors(
        self, interpolator: Interpolator, nodes=Iterable[BSPTreeNode] | None
    ) -> dict[str:InterfaceWrapper]:
        """Given a stratigraphic series interpolator description, returns the
        functors associated to each element of the series

        Parameters
        ----------
        interpolator: forgeo.core.Interpolator
            The description of the interpolation parameters
        nodes: Iterable[forge.interpolation.BSPTreeNode]
            The already built model elements, if any (may be used e.g., to access
            to fault functors when building stratigraphic functors)

        Returns
        -------
        dict[str:InterfaceWrapper]
            A dict mapping (the name of) each element to its associated functor
            (wrapped in an `InterfaceWrapper` object)
        """

    @abc.abstractmethod
    def get_fault_functor(
        self, interpolator: Interpolator, nodes=Iterable[BSPTreeNode] | None
    ) -> tuple[str, FaultWrapper]:
        """Given a fault interpolator description, returns the functor associated
        to this fault

        Parameters
        ----------
        interpolator: forgeo.core.Interpolator
            The description of the interpolation parameters
        nodes: Iterable[forge.interpolation.BSPTreeNode]
            The already built model elements, if any (may be used e.g., to access
            to fault functors when building stratigraphic functors)

        Returns
        -------
        tuple[str,FaultWrapper]
            A 2-tuple containing the name of the fault and its associated functor
            (wrapped in a `FaultWrapper` object)
        """

    def get_boundary_functor(
        self,
        interpolator: Interpolator,  # noqa: ARG002
        nodes=Iterable[BSPTreeNode],  # noqa: ARG002
    ) -> dict[str:FaultWrapper] | None:
        # Note: we propose a default "no-op" implementation as all methods do not
        # implement such boundaries
        return 2 * (None,)
