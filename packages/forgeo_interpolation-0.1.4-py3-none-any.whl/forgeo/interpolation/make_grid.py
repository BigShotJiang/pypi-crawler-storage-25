import numpy as np

from .domains import which_domain


def evaluate_on_regular_grid(boundaries, nx, ny, nz, **params):
    """xmin, xmax, ymin, ymax, zmin, zmax"""
    xmin, xmax, ymin, ymax, zmin, zmax = boundaries
    X, Y, Z = np.meshgrid(
        np.linspace(xmin, xmax, nx),
        np.linspace(ymin, ymax, ny),
        np.linspace(zmin, zmax, nz),
        indexing="ij",
    )
    pts = np.column_stack((X.ravel(), Y.ravel(), Z.ravel()))
    domains = which_domain(pts, **params)
    return np.column_stack((X.ravel(), Y.ravel(), Z.ravel(), domains))
