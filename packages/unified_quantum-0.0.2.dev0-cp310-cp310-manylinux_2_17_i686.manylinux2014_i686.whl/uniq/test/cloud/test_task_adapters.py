"""Tests for the task adapter layer.

These tests verify that:
1. Each adapter correctly translates OriginIR to provider-native circuits.
2. Config is loaded from environment variables (with deprecated file fallback).
3. Task modules delegate to adapters (no raw REST in task modules).

Tests use mocked HTTP responses so they run without real credentials or
network access.
"""

from __future__ import annotations

import json
import os
import sys
import tempfile
from pathlib import Path
from unittest.mock import MagicMock, patch

import pytest


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

ORIGINIR_BELL = """
QINIT 2
CREG 2
H q[0]
CNOT q[0], q[1]
MEASURE q[0], c[0]
MEASURE q[1], c[1]
""".strip()

ORIGINIR_3Q = """
QINIT 3
CREG 3
H q[0]
H q[1]
H q[2]
CNOT q[0], q[1]
CNOT q[1], q[2]
MEASURE q[0], c[0]
MEASURE q[1], c[1]
MEASURE q[2], c[2]
""".strip()


# ---------------------------------------------------------------------------
# Config tests
# ---------------------------------------------------------------------------

class RunTestConfigEnvVars:
    """Config loading from environment variables (preferred)."""

    def run_test_originq_config_from_env(self, monkeypatch, tmp_path):
        """OriginQ config is read from QPANDA_API_KEY env var."""
        monkeypatch.setenv("QPANDA_API_KEY", "test_key_123")
        monkeypatch.setenv("QPANDA_TASK_GROUP_SIZE", "100")

        # Ensure no config file exists
        monkeypatch.chdir(tmp_path)

        from uniq.task.config import load_originq_config

        config = load_originq_config()
        assert config["api_key"] == "test_key_123"
        assert config["task_group_size"] == 100

    def run_test_quafu_config_from_env(self, monkeypatch, tmp_path):
        """Quafu config is read from QUAHU_API_TOKEN env var."""
        monkeypatch.setenv("QUAFU_API_TOKEN", "quafu_secret_token")
        monkeypatch.chdir(tmp_path)

        from uniq.task.config import load_quafu_config

        config = load_quafu_config()
        assert config["api_token"] == "quafu_secret_token"

    def run_test_ibm_config_from_env(self, monkeypatch, tmp_path):
        """IBM config is read from IBM_TOKEN env var."""
        monkeypatch.setenv("IBM_TOKEN", "ibm_secret_token")
        monkeypatch.chdir(tmp_path)

        from uniq.task.config import load_ibm_config

        config = load_ibm_config()
        assert config["api_token"] == "ibm_secret_token"

    def run_test_dummy_config_from_env(self, monkeypatch, tmp_path):
        """OriginQ Dummy config is read from ORIGINQ_* env vars."""
        monkeypatch.setenv(
            "ORIGINQ_AVAILABLE_QUBITS", json.dumps([0, 1, 2, 3])
        )
        monkeypatch.setenv(
            "ORIGINQ_AVAILABLE_TOPOLOGY",
            json.dumps([[0, 1], [1, 2], [2, 3]]),
        )
        monkeypatch.setenv("ORIGINQ_TASK_GROUP_SIZE", "50")
        monkeypatch.chdir(tmp_path)

        from uniq.task.config import load_dummy_config

        config = load_dummy_config()
        assert config["available_qubits"] == [0, 1, 2, 3]
        assert config["available_topology"] == [[0, 1], [1, 2], [2, 3]]
        assert config["task_group_size"] == 50

    def run_test_originq_config_deprecated_file_fallback(self, monkeypatch, tmp_path):
        """File fallback is no longer supported - ImportError raised when env vars absent."""
        monkeypatch.delenv("QPANDA_API_KEY", raising=False)

        # Create a config file (should NOT be used anymore)
        config_file = tmp_path / "originq_cloud_config.json"
        config_file.write_text(
            json.dumps(
                {
                    "apitoken": "file_key",
                    "task_group_size": 50,
                }
            )
        )
        monkeypatch.chdir(tmp_path)

        # Clear module cache to force re-import
        if "uniq.task.config" in sys.modules:
            del sys.modules["uniq.task.config"]

        from uniq.task.config import load_originq_config

        # Should raise ImportError - file fallback is no longer supported
        with pytest.raises(ImportError, match="QPANDA_API_KEY"):
            load_originq_config()

    def run_test_originq_config_import_error_without_config(self, monkeypatch, tmp_path):
        """ImportError raised when env vars are absent."""
        monkeypatch.delenv("QPANDA_API_KEY", raising=False)
        monkeypatch.chdir(tmp_path)

        # Force re-import by clearing module cache
        if "uniq.task.config" in sys.modules:
            del sys.modules["uniq.task.config"]

        from uniq.task.config import load_originq_config

        with pytest.raises(ImportError, match="QPANDA_API_KEY"):
            load_originq_config()


# ---------------------------------------------------------------------------
# OriginQ adapter tests
# ---------------------------------------------------------------------------

class RunTestOriginQAdapterCircuitTranslation:
    """OriginQAdapter uses pyqpanda3 for circuit translation and task submission."""

    def run_test_translate_circuit_returns_qprog(self):
        """Test that translate_circuit converts OriginIR to QProg via pyqpanda3."""
        with patch(
            "uniq.task.adapters.originq_adapter.load_originq_config",
            return_value={
                "api_key": "k",
                "task_group_size": 200,
            },
        ):
            from uniq.task.adapters import OriginQAdapter

            adapter = OriginQAdapter()

            # Mock pyqpanda3 components
            mock_qprog = MagicMock()
            mock_convert = MagicMock(return_value=mock_qprog)

            with patch.dict(sys.modules, {"pyqpanda3": MagicMock()}):
                adapter._convert_originir = mock_convert
                adapter._service = MagicMock()  # Mark as initialized

                result = adapter.translate_circuit(ORIGINIR_BELL)
                mock_convert.assert_called_once_with(ORIGINIR_BELL)
                assert result == mock_qprog

    def run_test_submit_uses_pyqpanda3_service(self):
        """Test that submit uses pyqpanda3 QCloudService."""
        with patch(
            "uniq.task.adapters.originq_adapter.load_originq_config",
            return_value={
                "api_key": "k",
                "task_group_size": 200,
            },
        ):
            from uniq.task.adapters import OriginQAdapter

            adapter = OriginQAdapter()

            # Mock pyqpanda3 components
            mock_service = MagicMock()
            mock_backend = MagicMock()
            mock_job = MagicMock()
            mock_job.job_id.return_value = "task_abc123"
            mock_backend.run.return_value = mock_job
            mock_service.backend.return_value = mock_backend

            mock_qprog = MagicMock()
            mock_convert = MagicMock(return_value=mock_qprog)

            adapter._service = mock_service
            adapter._convert_originir = mock_convert
            adapter._QCloudOptions = MagicMock

            task_id = adapter.submit(ORIGINIR_BELL, shots=1000, backend_name="test_backend")

            mock_service.backend.assert_called_once_with("test_backend")
            mock_backend.run.assert_called_once()
            assert task_id == "task_abc123"

    def run_test_submit_batch_splits_large_groups(self):
        """Test that submit_batch splits circuits into groups."""
        with patch(
            "uniq.task.adapters.originq_adapter.load_originq_config",
            return_value={
                "api_key": "k",
                "task_group_size": 2,
            },
        ):
            from uniq.task.adapters import OriginQAdapter

            adapter = OriginQAdapter()

            # Mock pyqpanda3 components
            mock_service = MagicMock()
            mock_backend = MagicMock()

            def mock_run(*args, **kwargs):
                mock_job = MagicMock()
                mock_job.job_id.return_value = "subtask_xyz"
                return mock_job

            mock_backend.run.side_effect = mock_run
            mock_service.backend.return_value = mock_backend

            mock_qprog = MagicMock()
            mock_convert = MagicMock(return_value=mock_qprog)

            adapter._service = mock_service
            adapter._convert_originir = mock_convert
            adapter._QCloudOptions = MagicMock

            circuits = [ORIGINIR_BELL] * 3
            taskids = adapter.submit_batch(circuits, shots=1000)
            # 3 circuits with group_size=2 should produce 2 subgroups
            assert mock_backend.run.call_count == 2
            assert len(taskids) == 2

    def run_test_query_single_success(self):
        """Test that query returns success status for completed job."""
        with patch(
            "uniq.task.adapters.originq_adapter.load_originq_config",
            return_value={
                "api_key": "k",
                "task_group_size": 200,
            },
        ):
            from uniq.task.adapters import OriginQAdapter

            adapter = OriginQAdapter()

            # Create sentinel objects for status comparison
            FINISHED = object()
            FAILED = object()

            # Mock pyqpanda3 components
            mock_job_cls = MagicMock()
            mock_job = MagicMock()
            mock_job.status.return_value = FINISHED
            mock_result = MagicMock()
            mock_result.get_counts.return_value = {"00": 512, "11": 512}
            mock_job.result.return_value = mock_result
            mock_job_cls.return_value = mock_job

            adapter._QCloudJob = mock_job_cls
            adapter._JobStatus = MagicMock(FINISHED=FINISHED, FAILED=FAILED)
            adapter._service = MagicMock()  # Mark as initialized

            result = adapter.query("task_abc")

            mock_job_cls.assert_called_once_with("task_abc")
            assert result["status"] == "success"


# ---------------------------------------------------------------------------
# Quafu adapter tests
# ---------------------------------------------------------------------------

class RunTestQuafuAdapterCircuitTranslation:
    """QuafuAdapter correctly translates OriginIR to quafu.QuantumCircuit."""

    def run_test_translate_simple_gates(self):
        originir = """
QINIT 2
H q[0]
CNOT q[0], q[1]
MEASURE q[0], c[0]
""".strip()

        with patch(
            "uniq.task.adapters.quafu_adapter.load_quafu_config",
            return_value={"api_token": "tok"},
        ):
            # Mock quafu module
            mock_qc = MagicMock()
            mock_quafu = MagicMock()
            mock_quafu.QuantumCircuit.return_value = mock_qc

            with patch.dict(sys.modules, {"quafu": mock_quafu}):
                # Need to reimport to pick up the mock
                from uniq.task.adapters import QuafuAdapter

                # Replace _quafu, _QuantumCircuit etc on the instance
                adapter = QuafuAdapter.__new__(QuafuAdapter)
                adapter._api_token = "tok"
                adapter._quafu = mock_quafu
                adapter._QuantumCircuit = mock_quafu.QuantumCircuit
                adapter._Task = MagicMock()
                adapter._User = MagicMock()

                result = adapter.translate_circuit(originir)
                # Verify QuantumCircuit was created with 2 qubits
                mock_quafu.QuantumCircuit.assert_called_with(2)

    def run_test_translate_unknown_gate_raises(self):
        originir = """
QINIT 1
UNKNOWN_GATE q[0]
""".strip()

        with patch(
            "uniq.task.adapters.quafu_adapter.load_quafu_config",
            return_value={"api_token": "tok"},
        ):
            mock_quafu = MagicMock()
            mock_quafu.QuantumCircuit.return_value = MagicMock()

            with patch.dict(sys.modules, {"quafu": mock_quafu}):
                from uniq.task.adapters import QuafuAdapter

                adapter = QuafuAdapter.__new__(QuafuAdapter)
                adapter._api_token = "tok"
                adapter._quafu = mock_quafu
                adapter._QuantumCircuit = mock_quafu.QuantumCircuit
                adapter._Task = MagicMock()
                adapter._User = MagicMock()

                with pytest.raises(RuntimeError, match="UNKNOWN_GATE"):
                    adapter.translate_circuit(originir)


# ---------------------------------------------------------------------------
# IBM adapter tests
# ---------------------------------------------------------------------------

class RunTestIBMAdapterCircuitTranslation:
    """IBMAdapter translates OriginIR to qiskit.QuantumCircuit via QASM."""

    def run_test_translate_calls_circuit_qasm(self):
        originir = """
QINIT 2
H q[0]
CNOT q[0], q[1]
MEASURE q[0], c[0]
MEASURE q[1], c[1]
""".strip()

        mock_qiskit = MagicMock()
        mock_qc = MagicMock()
        mock_qiskit.QuantumCircuit.from_qasm_str.return_value = mock_qc

        with patch.dict(sys.modules, {"qiskit": mock_qiskit, "qiskit_ibm_provider": MagicMock()}):
            with patch(
                "uniq.task.adapters.qiskit_adapter.load_ibm_config",
                return_value={"api_token": "ibm_tok"},
            ):
                from uniq.task.adapters import QiskitAdapter

                adapter = QiskitAdapter.__new__(QiskitAdapter)
                adapter._api_token = "ibm_tok"
                adapter._provider = MagicMock()
                adapter._backends = []
                adapter._provider.backends = MagicMock(return_value=[])

                with patch(
                    "uniq.circuit_builder.qcircuit.Circuit"
                ) as mock_circuit_cls:
                    mock_circuit = MagicMock()
                    mock_circuit.qasm = "OPENQASM 2.0; ..."
                    mock_circuit_cls.return_value = mock_circuit

                    result = adapter.translate_circuit(originir)

                mock_qiskit.QuantumCircuit.from_qasm_str.assert_called_once_with(
                    "OPENQASM 2.0; ..."
                )


# ---------------------------------------------------------------------------
# Adapter availability tests
# ---------------------------------------------------------------------------

class RunTestAdapterAvailability:
    """Each adapter reports availability based on installed packages / config."""

    def run_test_originq_adapter_available_with_config(self):
        with patch(
            "uniq.task.adapters.originq_adapter.load_originq_config",
            return_value={
                "api_key": "k",
                "task_group_size": 200,
            },
        ):
            from uniq.task.adapters import OriginQAdapter

            adapter = OriginQAdapter()
            assert adapter.is_available() is True

    def run_test_quafu_adapter_available_with_quafu_installed(self):
        with patch(
            "uniq.task.adapters.quafu_adapter.load_quafu_config",
            return_value={"api_token": "tok"},
        ):
            with patch.dict(sys.modules, {"quafu": MagicMock()}):
                from uniq.task.adapters import QuafuAdapter

                adapter = QuafuAdapter.__new__(QuafuAdapter)
                adapter._api_token = "tok"
                adapter._quafu = MagicMock()  # Not None → available
                adapter._QuantumCircuit = MagicMock()
                adapter._Task = MagicMock()
                adapter._User = MagicMock()

                assert adapter.is_available() is True
