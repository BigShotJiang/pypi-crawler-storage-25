"""Astron Douban MCP server."""

from __future__ import annotations

import os
import re
import xml.etree.ElementTree as ET
from datetime import datetime, timezone
from html import unescape
from typing import Any
from urllib.parse import parse_qs, quote, unquote, urljoin, urlparse

import requests
from mcp.server.fastmcp import Context, FastMCP

from douban_mcp import __version__


HOME_URL = "https://www.douban.com/"
MOBILE_HOME_URL = "https://m.douban.com/"
API_BASE = "https://m.douban.com/rexxar/api/v2"
MOVIE_HOT_URL = f"{API_BASE}/subject_collection/movie_hot/items"
TV_HOT_URL = f"{API_BASE}/subject_collection/tv_hot/items"
BOOK_HOT_URL = f"{API_BASE}/subject_collection/book_hot/items"
SEARCH_MOVIE_URL = f"{API_BASE}/search/movie"
SUBJECT_API_URL = f"{API_BASE}/subject/{{content_id}}/"
PROFILE_URL = "https://www.douban.com/people/{author_id}/"
PROFILE_FEED_URL = "https://www.douban.com/feed/people/{author_slug}/interests"
USER_INTERESTS_URL = f"{API_BASE}/user/{{author_id}}/interests"

COUNT_RE = re.compile(r"[\d,.]+")
DIV_TAG_RE = re.compile(r"</?div\b[^>]*>", re.IGNORECASE)
LI_TAG_RE = re.compile(r"</?li\b[^>]*>", re.IGNORECASE)
LINK2_RE = re.compile(r"/link2/\?url=([^&]+)")
TAG_RE = re.compile(r"<[^>]+>")
PEOPLE_RE = re.compile(r"/people/([^/?#]+)/?")
SUBJECT_RE = re.compile(r"/subject/(\d+)/?")
TOPIC_RE = re.compile(r"/(?:group/topic|topic)/(\d+)/?")
USER_ID_RE = re.compile(r"user_id:\s*(\d+)")

CHANNEL_TO_URL = {
    "movie_hot": MOVIE_HOT_URL,
    "tv_hot": TV_HOT_URL,
    "book_hot": BOOK_HOT_URL,
}


def _current_iso() -> str:
    return datetime.now(tz=timezone.utc).astimezone().isoformat()


def get_timeout_seconds() -> float:
    raw = os.getenv("DOUBAN_MCP_TIMEOUT_SECONDS", "30").strip()
    try:
        value = float(raw)
    except ValueError as exc:
        raise RuntimeError("DOUBAN_MCP_TIMEOUT_SECONDS 必须是数字") from exc
    if value <= 0:
        raise RuntimeError("DOUBAN_MCP_TIMEOUT_SECONDS 必须大于 0")
    return value


def get_user_agent() -> str:
    value = os.getenv("DOUBAN_MCP_USER_AGENT", "").strip()
    if value:
        return value
    return (
        "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 "
        "(KHTML, like Gecko) Chrome/135.0.0.0 Safari/537.36 "
        f"Astron-Douban-MCP/{__version__}"
    )


def create_session() -> requests.Session:
    session = requests.Session()
    session.headers.update(
        {
            "User-Agent": get_user_agent(),
            "Accept-Language": "zh-CN,zh;q=0.9",
        }
    )
    return session


def _request_json(
    session: requests.Session,
    url: str,
    *,
    params: dict[str, Any] | None = None,
    referer: str = MOBILE_HOME_URL,
) -> dict[str, Any]:
    try:
        response = session.get(
            url,
            params=params,
            headers={
                "Referer": referer,
                "Accept": "application/json, text/plain, */*",
            },
            timeout=get_timeout_seconds(),
        )
    except requests.RequestException as exc:
        raise RuntimeError(f"请求失败: {url}; error={exc}") from exc

    if response.status_code != 200:
        raise RuntimeError(
            f"调用失败: HTTP {response.status_code}; url={response.url}; body={response.text[:500]}"
        )

    try:
        payload = response.json()
    except ValueError as exc:
        raise RuntimeError(f"调用失败: 响应不是合法 JSON; url={response.url}") from exc

    if not isinstance(payload, dict):
        raise RuntimeError(f"调用失败: 响应不是对象; url={response.url}")
    return payload


def _request_text(
    session: requests.Session,
    url: str,
    *,
    accept: str = "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
    referer: str = HOME_URL,
) -> str:
    try:
        response = session.get(
            url,
            headers={
                "Referer": referer,
                "Accept": accept,
            },
            timeout=get_timeout_seconds(),
        )
    except requests.RequestException as exc:
        raise RuntimeError(f"请求失败: {url}; error={exc}") from exc

    if response.status_code != 200:
        raise RuntimeError(
            f"调用失败: HTTP {response.status_code}; url={response.url}; body={response.text[:500]}"
        )
    return response.text


def clean_text(value: Any) -> str:
    text = unescape(str(value or ""))
    text = TAG_RE.sub(" ", text)
    return " ".join(text.split())


def _to_int(value: Any) -> int | None:
    if value in (None, ""):
        return None
    if isinstance(value, bool):
        return None
    if isinstance(value, (int, float)):
        return int(value)
    text = clean_text(value)
    match = COUNT_RE.search(text)
    if not match:
        return None
    try:
        return int(float(match.group(0).replace(",", "")))
    except ValueError:
        return None


def _normalize_limit(limit: int, *, maximum: int = 50) -> int:
    value = _to_int(limit)
    if value is None:
        return 20
    return max(1, min(value, maximum))


def _parse_start(cursor: str) -> int:
    value = _to_int(cursor)
    if value is None or value < 0:
        return 0
    return value


def _normalize_url(value: str, base_url: str = "") -> str:
    text = clean_text(value)
    if not text:
        return ""
    if text.startswith(("http://", "https://")):
        return text
    return urljoin(base_url, text)


def _build_profile_url(author_id: str) -> str:
    return PROFILE_URL.format(author_id=author_id.strip())


def _build_profile_feed_url(author_slug: str) -> str:
    return PROFILE_FEED_URL.format(author_slug=author_slug.strip())


def _extract_content_id(content_id: str, url: str) -> str:
    text = clean_text(content_id)
    if text:
        return text
    for pattern in (SUBJECT_RE, TOPIC_RE):
        match = pattern.search(url.strip())
        if match:
            return match.group(1)
    return ""


def _extract_author_slug(author_id: str, url: str) -> str:
    text = clean_text(author_id)
    if text:
        return text
    match = PEOPLE_RE.search(url.strip())
    if match:
        return match.group(1)
    return ""


def _strip_tags(value: str) -> str:
    return clean_text(unescape(TAG_RE.sub(" ", value or "")))


def _extract_attr(pattern: str, html: str, *, flags: int = re.IGNORECASE | re.DOTALL) -> str:
    match = re.search(pattern, html, flags)
    if not match:
        return ""
    return clean_text(match.group(1))


def _extract_balanced_li_by_class(html: str, class_name: str) -> list[str]:
    class_re = re.compile(
        rf'<li\b(?=[^>]*\bclass=(["\'])[^"\']*\b{re.escape(class_name)}\b[^"\']*\1)[^>]*>',
        re.IGNORECASE,
    )
    result: list[str] = []
    for match in class_re.finditer(html):
        start = match.start()
        depth = 0
        cursor = start
        while True:
            tag_match = LI_TAG_RE.search(html, cursor)
            if not tag_match:
                break
            tag_text = tag_match.group(0)
            cursor = tag_match.end()
            if tag_text.lower().startswith("</li"):
                depth -= 1
            else:
                depth += 1
            if depth == 0:
                result.append(html[start:cursor])
                break
    return result


def _unwrap_link2_url(value: str) -> str:
    text = clean_text(value)
    if not text:
        return ""
    match = LINK2_RE.search(text)
    if match:
        return _normalize_url(unquote(match.group(1)))
    parsed = urlparse(text)
    if parsed.path.endswith("/link2/"):
        candidate = parse_qs(parsed.query).get("url", [""])[0]
        if candidate:
            return _normalize_url(unquote(candidate))
    return _normalize_url(text, HOME_URL)


def _extract_xml_text(element: ET.Element | None) -> str:
    if element is None:
        return ""
    text = "".join(element.itertext()) if list(element) else (element.text or "")
    return clean_text(text)


def _stringify_list(value: Any) -> str:
    if isinstance(value, list):
        return " / ".join(clean_text(item) for item in value if clean_text(item))
    return clean_text(value)


def _subject_page_url(subject_type: str, subject_id: str) -> str:
    if subject_type == "book":
        return f"https://book.douban.com/subject/{subject_id}/"
    return f"https://movie.douban.com/subject/{subject_id}/"


def _json_cover_url(value: Any) -> str:
    if isinstance(value, dict):
        for key in ("large", "url", "normal"):
            text = clean_text(value.get(key, ""))
            if text:
                return _normalize_url(text)
    if isinstance(value, str):
        return _normalize_url(value)
    return ""


def _subject_author_name(subject: dict[str, Any]) -> str:
    authors = subject.get("author")
    if isinstance(authors, list) and authors:
        return clean_text(authors[0])
    directors = subject.get("directors")
    if isinstance(directors, list) and directors:
        return clean_text(directors[0])
    subtitle = clean_text(subject.get("card_subtitle", ""))
    if subtitle:
        parts = [clean_text(part) for part in subtitle.split("/") if clean_text(part)]
        if len(parts) >= 4:
            return parts[3]
    owner = subject.get("owner")
    if isinstance(owner, dict):
        return clean_text(owner.get("name", ""))
    return ""


def _subject_tags(subject: dict[str, Any]) -> list[str]:
    tags = subject.get("tags")
    if isinstance(tags, list):
        return [clean_text(item) for item in tags if clean_text(item)]
    if isinstance(tags, str):
        return [clean_text(item) for item in re.split(r"[,\s/]+", tags) if clean_text(item)]
    genres = subject.get("genres")
    if isinstance(genres, list):
        return [clean_text(item) for item in genres if clean_text(item)]
    return []


def _subject_hot_value(subject: dict[str, Any]) -> int | None:
    rating = subject.get("rating")
    if isinstance(rating, dict):
        count = rating.get("count")
        if isinstance(count, (int, float)):
            return int(count)
    for key in ("wish_count", "vote_count", "comment_count", "review_count", "followers_count", "listeners_count"):
        value = _to_int(subject.get(key))
        if value is not None:
            return value
    return None


def _subject_hot_text(subject: dict[str, Any]) -> str:
    rating = subject.get("rating")
    if isinstance(rating, dict):
        count = _to_int(rating.get("count"))
        value = rating.get("value")
        if count is not None and value is not None:
            return f"{value}分 · {count}评分"
    for key, suffix in (
        ("wish_count", "想看"),
        ("vote_count", "票"),
        ("comment_count", "评论"),
        ("review_count", "评论"),
    ):
        parsed = _to_int(subject.get(key))
        if parsed is not None:
            return f"{parsed}{suffix}"
    return ""


def _build_subject_item(
    subject: dict[str, Any],
    *,
    source_type: str = "",
    author_name: str = "",
) -> dict[str, Any]:
    subject_id = clean_text(subject.get("id", "")) or clean_text(subject.get("target_id", ""))
    subject_type = clean_text(subject.get("type", "")) or clean_text(subject.get("target_type", ""))
    item_url = clean_text(subject.get("url", ""))
    if not item_url:
        item_url = _subject_page_url(subject_type, subject_id) if subject_id else ""
    if not author_name:
        author_name = _subject_author_name(subject)
    publish_time = (
        _stringify_list(subject.get("pubdate"))
        or _stringify_list(subject.get("year"))
        or clean_text(subject.get("release_date", ""))
    )
    summary = clean_text(subject.get("comment", "")) or clean_text(subject.get("card_subtitle", ""))
    content = (
        clean_text(subject.get("intro", ""))
        or clean_text(subject.get("description", ""))
        or summary
    )
    return {
        "id": subject_id or item_url,
        "title": clean_text(subject.get("title", "")),
        "summary": summary,
        "content": content,
        "url": item_url,
        "cover": _json_cover_url(subject.get("cover") or subject.get("pic") or subject.get("target", {}).get("cover_url", "")),
        "author_name": author_name,
        "author_id": "",
        "publish_time": publish_time,
        "rank": 0,
        "hot_value": _subject_hot_value(subject),
        "hot_text": _subject_hot_text(subject),
        "comment_count": _to_int(subject.get("comment_count")),
        "like_count": _to_int(subject.get("interest")),
        "share_count": None,
        "collect_count": _to_int(subject.get("wish_count")),
        "view_count": _to_int(subject.get("review_count")),
        "source_type": source_type or subject_type or "subject",
        "tags": _subject_tags(subject),
        "raw": subject,
    }


def _rank_items(items: list[dict[str, Any]]) -> list[dict[str, Any]]:
    ranked: list[dict[str, Any]] = []
    seen: set[str] = set()
    for item in items:
        item_id = clean_text(item.get("id", ""))
        if not item_id or item_id in seen:
            continue
        seen.add(item_id)
        ranked.append(item)
    for index, item in enumerate(ranked, start=1):
        item["rank"] = index
    return ranked


def _build_list_result(
    capability: str,
    items: list[dict[str, Any]],
    raw: dict[str, Any],
    *,
    has_more: bool = False,
    next_cursor: str = "",
) -> dict[str, Any]:
    return {
        "platform": "douban",
        "capability": capability,
        "update_time": _current_iso(),
        "items": items,
        "paging": {
            "has_more": bool(has_more),
            "next_cursor": next_cursor if has_more else "",
        },
        "raw": raw,
    }


def _build_detail_result(item: dict[str, Any], raw: dict[str, Any]) -> dict[str, Any]:
    return {
        "platform": "douban",
        "item": item,
        "raw": raw,
    }


def _build_author_result(author: dict[str, Any], raw: dict[str, Any]) -> dict[str, Any]:
    return {
        "platform": "douban",
        "author": author,
        "raw": raw,
    }


def _build_subject_list_data(
    payload: dict[str, Any],
    *,
    capability: str,
    source_type: str,
    limit: int,
) -> list[dict[str, Any]]:
    items: list[dict[str, Any]] = []
    for subject in (payload.get("subject_collection_items") or payload.get("items") or [])[:limit]:
        if not isinstance(subject, dict):
            continue
        if "target" in subject and isinstance(subject["target"], dict):
            target = dict(subject["target"])
            target.setdefault("id", clean_text(target.get("id", "")) or clean_text(subject.get("target_id", "")))
            target.setdefault("type", clean_text(subject.get("target_type", "")))
            target.setdefault("title", clean_text(target.get("title", "")))
            target.setdefault("comment", clean_text(target.get("abstract", "")) or clean_text(target.get("comment", "")))
            target.setdefault("card_subtitle", clean_text(target.get("card_subtitle", "")))
            target.setdefault("url", clean_text(target.get("url", "")))
            subject = target
        items.append(_build_subject_item(subject, source_type=source_type, author_name=_subject_author_name(subject)))
    return _rank_items(items)


def parse_author_profile_html(html: str, url: str, author_id: str) -> dict[str, Any]:
    title = _extract_attr(r'<meta\s+property="og:title"\s+content="([^"]+)"', html)
    if not title:
        title = _extract_attr(r"<title>(.*?)</title>", html)
    name = title.replace("的个人主页 - 豆瓣", "").replace("的个人主页", "").strip() or author_id
    bio = _extract_attr(r'<meta\s+property="og:description"\s+content="([^"]+)"', html)
    if not bio:
        bio = _extract_attr(r'<meta\s+name="description"\s+content="([^"]+)"', html)
    if not bio:
        bio = _extract_attr(r'<div[^>]*id="display"[^>]*class="[^"]*\bsignature_display\b[^"]*"[^>]*>(.*?)</div>', html)
    avatar = _extract_attr(r'<meta\s+property="og:image"\s+content="([^"]+)"', html)
    if not avatar:
        avatar = _extract_attr(r'<meta\s+itemprop="image"\s+content="([^"]+)"', html)
    if not avatar:
        avatar = _extract_attr(r'<div[^>]*class="pic"[^>]*>.*?<img[^>]+src="([^"]+)"', html)
    feed_url = _extract_attr(
        r'<link\s+rel="alternate"\s+href="([^"]+)"\s+type="application/rss\+xml"',
        html,
    )
    user_id_match = USER_ID_RE.search(html)
    numeric_user_id = user_id_match.group(1) if user_id_match else ""
    if not numeric_user_id:
        numeric_user_id = _extract_attr(r'<div[^>]*class="user-info"[^>]*>\s*.*?<div[^>]*class="pl"[^>]*>\s*(\d+)', html)
    if not bio:
        bio = _extract_attr(r'<div[^>]*class="user-info"[^>]*>(.*?)</div>', html)
    follower_count = _to_int(re.search(r"共有([\d,.]+)个人关注TA", bio).group(1) if re.search(r"共有([\d,.]+)个人关注TA", bio) else "")
    following_count = _to_int(re.search(r"关注了([\d,.]+)个人", bio).group(1) if re.search(r"关注了([\d,.]+)个人", bio) else "")
    content_count = _to_int(re.search(r"写了([\d,.]+)篇日记", bio).group(1) if re.search(r"写了([\d,.]+)篇日记", bio) else "")
    return {
        "id": numeric_user_id or author_id,
        "slug": author_id,
        "name": name,
        "url": url,
        "avatar": avatar,
        "bio": bio,
        "follower_count": follower_count,
        "following_count": following_count,
        "content_count": content_count,
        "raw": {
            "html": html,
            "feed_url": feed_url,
            "numeric_user_id": numeric_user_id,
        },
    }


def parse_author_content_list_html(
    html: str,
    url: str,
    author_id: str,
    *,
    author_name: str = "",
) -> list[dict[str, Any]]:
    source_type = "collection"
    if "/do" in url:
        source_type = "do"
    elif "/wish" in url:
        source_type = "wish"
    elif "/collect" in url:
        source_type = "collect"
    if "movie.douban.com" in url:
        source_type = f"movie_{source_type}"
    elif "book.douban.com" in url:
        source_type = f"book_{source_type}"
    items: list[dict[str, Any]] = []
    for block in _extract_balanced_li_by_class(html, "subject-item"):
        item_url = _unwrap_link2_url(_extract_attr(r'<a\s+class="nbg"[^>]*href="([^"]+)"', block))
        if not item_url:
            item_url = _normalize_url(_extract_attr(r'<a[^>]*title="[^"]+"[^>]*href="([^"]+)"', block))
        title = _strip_tags(
            _extract_attr(r'<a\s+class="nbg"[^>]*title="([^"]+)"', block)
            or _extract_attr(r'<a[^>]*href="[^"]+"[^>]*title="([^"]+)"', block)
            or _extract_attr(r'<a[^>]*title="([^"]+)"[^>]*href="[^"]+"', block)
        )
        cover = _extract_attr(r'<img[^>]+src="([^"]+)"', block)
        comment = _strip_tags(
            _extract_attr(r'<p\s+class="comment[^"]*"[^>]*>(.*?)</p>', block)
            or _extract_attr(r'<div\s+class="comment[^"]*"[^>]*>(.*?)</div>', block)
        )
        subject_id_match = SUBJECT_RE.search(item_url)
        subject_id = subject_id_match.group(1) if subject_id_match else item_url
        items.append(
            {
                "id": subject_id,
                "title": title,
                "summary": comment or title,
                "content": comment or title,
                "url": item_url,
                "cover": _normalize_url(cover),
                "author_name": author_name,
                "author_id": author_id,
                "publish_time": "",
                "rank": 0,
                "hot_value": None,
                "hot_text": comment,
                "comment_count": None,
                "like_count": None,
                "share_count": None,
                "collect_count": None,
                "view_count": None,
                "source_type": source_type,
                "tags": [],
                "raw": {"block": block},
            }
        )
    return _rank_items(items)


def parse_author_content_list_rss(
    xml_text: str,
    *,
    author_id: str,
    author_name: str = "",
    limit: int = 20,
) -> list[dict[str, Any]]:
    try:
        root = ET.fromstring(xml_text)
    except ET.ParseError:
        return []
    items: list[dict[str, Any]] = []
    namespace = {"dc": "http://purl.org/dc/elements/1.1/"}
    for item_node in root.findall("./channel/item")[:limit]:
        title = _extract_xml_text(item_node.find("title"))
        link = _normalize_url(_extract_xml_text(item_node.find("link")))
        description = _extract_xml_text(item_node.find("description"))
        creator = _extract_xml_text(item_node.find("dc:creator", namespace))
        pub_time = _extract_xml_text(item_node.find("pubDate"))
        cover = _extract_attr(r'<img[^>]+src="([^"]+)"', description)
        note = _strip_tags(_extract_attr(r'<p>\s*(?:备注|推荐):\s*(.*?)</p>', description))
        if not note:
            note = _strip_tags(_extract_attr(r'<p>(.*?)</p>', description))
        source_type = "rss"
        if "book.douban.com" in link:
            source_type = "rss_book"
        elif "movie.douban.com" in link:
            source_type = "rss_movie"
        elif "music.douban.com" in link:
            source_type = "rss_music"
        subject_id_match = SUBJECT_RE.search(link)
        subject_id = subject_id_match.group(1) if subject_id_match else link
        items.append(
            {
                "id": subject_id,
                "title": title,
                "summary": note or title,
                "content": note or description or title,
                "url": link,
                "cover": _normalize_url(cover),
                "author_name": author_name or creator,
                "author_id": author_id,
                "publish_time": pub_time,
                "rank": 0,
                "hot_value": None,
                "hot_text": "",
                "comment_count": None,
                "like_count": None,
                "share_count": None,
                "collect_count": None,
                "view_count": None,
                "source_type": source_type,
                "tags": [],
                "raw": {
                    "title": title,
                    "link": link,
                    "description": description,
                    "creator": creator,
                    "pubDate": pub_time,
                },
            }
        )
    return _rank_items(items)


def parse_user_interests_json(
    payload: dict[str, Any],
    *,
    author_id: str,
    author_name: str = "",
    limit: int = 20,
) -> list[dict[str, Any]]:
    items: list[dict[str, Any]] = []
    for interest in (payload.get("interests") or [])[:limit]:
        if not isinstance(interest, dict):
            continue
        subject = dict(interest.get("subject") or {})
        subject.setdefault("id", clean_text(subject.get("id", "")))
        subject.setdefault("type", clean_text(subject.get("type", "")) or clean_text(subject.get("target_type", "")))
        subject.setdefault("title", clean_text(subject.get("title", "")))
        subject.setdefault("comment", clean_text(interest.get("comment", "")))
        subject.setdefault("card_subtitle", clean_text(subject.get("card_subtitle", "")))
        subject.setdefault("url", clean_text(subject.get("url", "")))
        item = _build_subject_item(
            subject,
            source_type="interest",
            author_name=author_name,
        )
        item["summary"] = clean_text(interest.get("comment", "")) or item["summary"]
        item["content"] = (
            clean_text(interest.get("comment", ""))
            or clean_text(interest.get("sharing_text", ""))
            or item["content"]
        )
        item["url"] = clean_text(interest.get("sharing_url", "")) or item["url"]
        item["publish_time"] = clean_text(interest.get("create_time", "")) or item["publish_time"]
        item["hot_value"] = _to_int(interest.get("vote_count")) or item["hot_value"]
        item["hot_text"] = f"{item['hot_value']} 票" if item["hot_value"] is not None else item["hot_text"]
        item["author_name"] = author_name or item["author_name"]
        item["author_id"] = author_id
        item["raw"] = interest
        items.append(item)
    return _rank_items(items)


def parse_topic_detail_html(html: str, url: str, content_id: str) -> dict[str, Any]:
    title = _extract_attr(r'<h1[^>]*class="[^"]*\btitle\b[^"]*"[^>]*>(.*?)</h1>', html)
    if not title:
        title = _extract_attr(r'<meta\s+property="og:title"\s+content="([^"]+)"', html)
    author_name = _extract_attr(r'<span[^>]*class="[^"]*\bname\b[^"]*"[^>]*>(.*?)</span>', html)
    author_url = _extract_attr(r'<a[^>]*href="([^"]*?/people/[^"]+/?)"[^>]*class="[^"]*author[^"]*"', html)
    if not author_url:
        author_url = _extract_attr(r'<a[^>]*href="([^"]*?/people/[^"]+/?)"[^>]*>', html)
    author_match = PEOPLE_RE.search(author_url)
    author_slug = author_match.group(1) if author_match else ""
    publish_time = _extract_attr(r'<span[^>]*class="[^"]*\btimestamp\b[^"]*"[^>]*>(.*?)</span>', html)
    content = _strip_tags(_extract_attr(r'<div[^>]*id="content"[^>]*>(.*?)</div>', html))
    if not content:
        content = title
    summary = content[:120]
    cover = _extract_attr(r'<img[^>]+src="([^"]+)"', html)
    comment_count = _to_int(_extract_attr(r'(\d+)\s*条回复', html))
    return {
        "id": content_id or url,
        "title": title,
        "summary": summary,
        "content": content,
        "url": url,
        "cover": cover,
        "author_name": author_name,
        "author_id": author_slug,
        "publish_time": publish_time,
        "rank": 1,
        "hot_value": comment_count,
        "hot_text": f"{comment_count}回应" if comment_count is not None else "",
        "comment_count": comment_count,
        "like_count": None,
        "share_count": None,
        "collect_count": None,
        "view_count": None,
        "source_type": "group_topic",
        "tags": [],
        "raw": {"url": url},
    }


def _resolve_feed_channel(channel: str) -> str:
    value = clean_text(channel).lower()
    if value in {"", "feed", "tv", "tv_hot"}:
        return "tv_hot"
    if value in {"movie", "movie_hot", "film"}:
        return "movie_hot"
    if value in {"book", "book_hot"}:
        return "book_hot"
    return "tv_hot"


def fetch_hot_list_data(*, limit: int, refresh: bool) -> dict[str, Any]:
    del refresh
    safe_limit = _normalize_limit(limit)
    session = create_session()
    payload = _request_json(
        session,
        MOVIE_HOT_URL,
        params={"count": safe_limit, "start": 0},
        referer=MOBILE_HOME_URL,
    )
    items = _build_subject_list_data(payload, capability="hot_list", source_type="movie_hot", limit=safe_limit)
    return _build_list_result("hot_list", items, payload)


def fetch_feed_list_data(
    *,
    channel: str,
    cursor: str,
    limit: int,
    refresh: bool,
) -> dict[str, Any]:
    del refresh
    safe_limit = _normalize_limit(limit)
    start = _parse_start(cursor)
    feed_channel = _resolve_feed_channel(channel)
    session = create_session()
    payload = _request_json(
        session,
        CHANNEL_TO_URL[feed_channel],
        params={"count": safe_limit, "start": start},
        referer=MOBILE_HOME_URL,
    )
    items = _build_subject_list_data(payload, capability="feed_list", source_type=feed_channel, limit=safe_limit)
    total = _to_int(payload.get("total"))
    has_more = total is not None and (start + len(items) < total)
    return _build_list_result(
        "feed_list",
        items,
        {"channel": feed_channel, "payload": payload},
        has_more=has_more,
        next_cursor=str(start + len(items)) if has_more else "",
    )


def fetch_search_content_data(*, query: str, cursor: str, limit: int) -> dict[str, Any]:
    keyword = clean_text(query)
    if not keyword:
        raise RuntimeError("query 不能为空")
    safe_limit = _normalize_limit(limit)
    start = _parse_start(cursor)
    session = create_session()
    payload = _request_json(
        session,
        SEARCH_MOVIE_URL,
        params={"q": keyword, "count": safe_limit, "start": start},
        referer=MOBILE_HOME_URL,
    )
    items: list[dict[str, Any]] = []
    for raw_item in (payload.get("items") or [])[:safe_limit]:
        if not isinstance(raw_item, dict):
            continue
        target = raw_item.get("target") if isinstance(raw_item.get("target"), dict) else {}
        target = dict(target or {})
        target.setdefault("id", clean_text(target.get("id", "")) or clean_text(raw_item.get("target_id", "")))
        target.setdefault("type", clean_text(raw_item.get("target_type", "")))
        target.setdefault("title", clean_text(target.get("title", "")))
        target.setdefault("comment", clean_text(target.get("abstract", "")))
        target.setdefault("card_subtitle", clean_text(target.get("card_subtitle", "")))
        target.setdefault("url", clean_text(target.get("url", "")))
        items.append(
            _build_subject_item(
                target,
                source_type=clean_text(raw_item.get("layout", "")) or clean_text(raw_item.get("target_type", "")),
            )
        )
    items = _rank_items(items)
    total = _to_int(payload.get("total"))
    has_more = total is not None and (start + len(items) < total)
    return _build_list_result(
        "search",
        items,
        {"query": keyword, "payload": payload},
        has_more=has_more,
        next_cursor=str(start + len(items)) if has_more else "",
    )


def fetch_content_detail_data(*, content_id: str, url: str) -> dict[str, Any]:
    target_url = clean_text(url)
    resolved_content_id = _extract_content_id(content_id, target_url)
    session = create_session()

    if target_url and ("/group/topic/" in target_url or "/topic/" in target_url):
        html = _request_text(session, target_url, referer=HOME_URL)
        item = parse_topic_detail_html(html, target_url, resolved_content_id)
        return _build_detail_result(item, {"url": target_url, "source": "topic_html"})

    if not resolved_content_id:
        raise RuntimeError("content_id 或 url 至少提供一个有效 subject/topic 标识")

    payload = _request_json(
        session,
        SUBJECT_API_URL.format(content_id=resolved_content_id),
        referer=MOBILE_HOME_URL,
    )
    item = _build_subject_item(payload, source_type=clean_text(payload.get("type", "")) or "subject")
    item["id"] = clean_text(payload.get("id", "")) or resolved_content_id
    return _build_detail_result(
        item,
        {"content_id": resolved_content_id, "payload": payload},
    )


def fetch_author_profile_data(*, author_id: str, url: str) -> dict[str, Any]:
    author_slug = _extract_author_slug(author_id, url)
    if not author_slug:
        raise RuntimeError("author_id 或 url 至少提供一个")
    session = create_session()
    profile_url = _build_profile_url(author_slug)
    html = _request_text(session, profile_url, referer=HOME_URL)
    author = parse_author_profile_html(html, profile_url, author_slug)
    return _build_author_result(author, {"url": profile_url, "source": "profile_html"})


def fetch_author_content_list_data(
    *,
    author_id: str,
    url: str,
    cursor: str,
    limit: int,
) -> dict[str, Any]:
    author_slug = _extract_author_slug(author_id, url)
    if not author_slug:
        raise RuntimeError("author_id 或 url 至少提供一个")

    safe_limit = _normalize_limit(limit)
    start = _parse_start(cursor)
    session = create_session()
    profile_url = _build_profile_url(author_slug)
    profile_html = _request_text(session, profile_url, referer=HOME_URL)
    author = parse_author_profile_html(profile_html, profile_url, author_slug)
    author_name = clean_text(author.get("name", "")) or author_slug
    numeric_user_id = clean_text(author.get("raw", {}).get("numeric_user_id", ""))
    feed_url = clean_text(author.get("raw", {}).get("feed_url", "")) or _build_profile_feed_url(author_slug)
    target_url = clean_text(url)

    if target_url and ("book.douban.com/people/" in target_url or "movie.douban.com/people/" in target_url):
        collection_url = target_url
        if start > 0 and "start=" not in collection_url:
            separator = "&" if "?" in collection_url else "?"
            collection_url = f"{collection_url}{separator}start={start}"
        html = _request_text(session, collection_url, referer=HOME_URL)
        items = parse_author_content_list_html(
            html,
            collection_url,
            author_slug,
            author_name=author_name,
        )[:safe_limit]
        has_more = len(items) >= safe_limit
        return _build_list_result(
            "author_content_list",
            items,
            {"source": "collection_html", "author": author, "url": collection_url},
            has_more=has_more,
            next_cursor=str(start + len(items)) if has_more else "",
        )

    if numeric_user_id:
        try:
            payload = _request_json(
                session,
                USER_INTERESTS_URL.format(author_id=numeric_user_id),
                params={"count": safe_limit, "start": start},
                referer=MOBILE_HOME_URL,
            )
            items = parse_user_interests_json(
                payload,
                author_id=numeric_user_id,
                author_name=author_name,
                limit=safe_limit,
            )
            if items:
                total = _to_int(payload.get("total"))
                has_more = total is not None and (start + len(items) < total)
                return _build_list_result(
                    "author_content_list",
                    items,
                    {"source": "user_interests", "author": author, "payload": payload},
                    has_more=has_more,
                    next_cursor=str(start + len(items)) if has_more else "",
                )
        except RuntimeError:
            pass

    rss_text = _request_text(
        session,
        feed_url,
        accept="application/rss+xml, application/xml, text/xml, */*",
        referer=HOME_URL,
    )
    items = parse_author_content_list_rss(
        rss_text,
        author_id=clean_text(numeric_user_id or author_slug),
        author_name=author_name,
        limit=safe_limit,
    )
    if not items:
        raise RuntimeError("未找到作者公开内容")
    return _build_list_result(
        "author_content_list",
        items,
        {"source": "rss", "author": author, "feed_url": feed_url},
        has_more=False,
        next_cursor="",
    )


mcp = FastMCP(
    "DOUBAN_MCP",
    instructions=(
        "Astron Douban MCP server，基于豆瓣游客态公开接口和公开页面提供公开内容工具能力，"
        "无需额外部署后端服务。"
    ),
)


@mcp.tool()
def get_hot_list(
    ctx: Context,
    limit: int = 20,
    refresh: bool = False,
) -> dict[str, Any]:
    """
    获取豆瓣热榜。

    参数：
    - limit: 返回条数，范围建议 1-50。
    - refresh: 是否请求刷新数据。
    """
    del ctx
    return fetch_hot_list_data(limit=limit, refresh=refresh)


@mcp.tool()
def get_feed_list(
    ctx: Context,
    channel: str = "",
    cursor: str = "",
    limit: int = 20,
    refresh: bool = False,
) -> dict[str, Any]:
    """
    获取豆瓣内容流。

    参数：
    - channel: 渠道，可选 `tv_hot`、`movie_hot`、`book_hot`。
    - cursor: 分页游标，内部按 start 偏移处理。
    - limit: 返回条数，范围建议 1-50。
    - refresh: 是否请求刷新数据。
    """
    del ctx
    return fetch_feed_list_data(
        channel=channel,
        cursor=cursor,
        limit=limit,
        refresh=refresh,
    )


@mcp.tool()
def search_content(
    ctx: Context,
    query: str,
    cursor: str = "",
    limit: int = 20,
) -> dict[str, Any]:
    """
    搜索豆瓣公开内容。

    参数：
    - query: 搜索关键词。
    - cursor: 分页游标，内部按 start 偏移处理。
    - limit: 返回条数，范围建议 1-50。
    """
    del ctx
    return fetch_search_content_data(query=query, cursor=cursor, limit=limit)


@mcp.tool()
def get_content_detail(
    ctx: Context,
    content_id: str = "",
    url: str = "",
) -> dict[str, Any]:
    """
    获取豆瓣内容详情。

    参数：
    - content_id: subject/topic ID。
    - url: 内容完整 URL。
    """
    del ctx
    return fetch_content_detail_data(content_id=content_id, url=url)


@mcp.tool()
def get_author_profile(
    ctx: Context,
    author_id: str = "",
    url: str = "",
) -> dict[str, Any]:
    """
    获取豆瓣用户主页。

    参数：
    - author_id: 用户 slug 或数字用户 ID。
    - url: 用户主页 URL。
    """
    del ctx
    return fetch_author_profile_data(author_id=author_id, url=url)


@mcp.tool()
def get_author_content_list(
    ctx: Context,
    author_id: str = "",
    url: str = "",
    cursor: str = "",
    limit: int = 20,
) -> dict[str, Any]:
    """
    获取豆瓣用户公开内容列表。

    参数：
    - author_id: 用户 slug 或数字用户 ID。
    - url: 用户主页 URL，或显式收藏页 URL。
    - cursor: 分页游标，内部按 start 偏移处理。
    - limit: 返回条数，范围建议 1-50。
    """
    del ctx
    return fetch_author_content_list_data(
        author_id=author_id,
        url=url,
        cursor=cursor,
        limit=limit,
    )


def main() -> None:
    """Run the MCP server over stdio."""
    mcp.run()


if __name__ == "__main__":
    main()
