# 豆瓣公开内容 MCP Server

## 概述

`Astron-douban-mcp` 是一个基于 MCP 协议的豆瓣工具服务，直接调用豆瓣游客态公开接口、公开资料页和公开 RSS 获取公开内容，无需额外部署后端服务。

当前工程形态：
- 使用 `MCP Python SDK`
- 使用单文件 `server.py` 承载工具定义和 HTTP 调用
- 通过独立 `pyproject` 打包
- 支持 `uvx` 一键启动
- 通过环境变量配置超时和 User-Agent

当前提供 6 个原子工具：
- `get_hot_list`
- `get_feed_list`
- `search_content`
- `get_content_detail`
- `get_author_profile`
- `get_author_content_list`


## 工具

### 1. 获取热榜 `get_hot_list`
- 描述：读取豆瓣热榜，默认使用电影热榜。
- 参数：
  - `limit`：返回条数，默认 `20`
  - `refresh`：是否刷新，默认 `False`

### 2. 获取内容流 `get_feed_list`
- 描述：读取豆瓣公开内容流。
- 参数：
  - `channel`：可选 `tv_hot`、`movie_hot`、`book_hot`
  - `cursor`：分页游标，默认空，内部按 `start` 偏移处理
  - `limit`：返回条数，默认 `20`
  - `refresh`：是否刷新，默认 `False`

### 3. 搜索内容 `search_content`
- 描述：搜索豆瓣公开内容。
- 参数：
  - `query`：搜索词，必填
  - `cursor`：分页游标，默认空，内部按 `start` 偏移处理
  - `limit`：返回条数，默认 `20`

### 4. 获取内容详情 `get_content_detail`
- 描述：读取豆瓣 subject 或 topic 详情。
- 参数：
  - `content_id`：subject/topic ID
  - `url`：内容完整 URL

### 5. 获取用户主页 `get_author_profile`
- 描述：读取豆瓣用户公开主页。
- 参数：
  - `author_id`：用户 slug 或数字用户 ID
  - `url`：用户主页 URL

### 6. 获取用户公开内容列表 `get_author_content_list`
- 描述：读取豆瓣用户公开内容列表。
- 参数：
  - `author_id`：用户 slug 或数字用户 ID
  - `url`：用户主页 URL，或显式收藏页 URL
  - `cursor`：分页游标，默认空，内部按 `start` 偏移处理
  - `limit`：返回条数，默认 `20`


## 环境变量

这个包默认不需要认证信息。

可选环境变量：

```bash
export DOUBAN_MCP_TIMEOUT_SECONDS="30"
export DOUBAN_MCP_USER_AGENT="Mozilla/5.0 ..."
```

说明：
- `DOUBAN_MCP_TIMEOUT_SECONDS` 控制公开接口请求超时。
- `DOUBAN_MCP_USER_AGENT` 用于覆盖默认请求头。


## 开始

### 推荐方式：使用 uvx 一键启动

```bash
uvx --from Astron-douban-mcp douban-mcp
```

如果你还没有安装 `uv` / `uvx`，可先执行：

```bash
curl -fsSL https://install.astral.sh/uv | bash
```

### 使用 pip 安装

```bash
pip install Astron-douban-mcp
douban-mcp
```

### 本地源码运行

```bash
cd douban-mcp
PYTHONPATH=src python3 -m douban_mcp.server
```


## MCP 客户端配置

### 使用 uvx

```json
{
  "mcpServers": {
    "douban-mcp": {
      "command": "uvx",
      "args": ["--from", "Astron-douban-mcp", "douban-mcp"],
      "env": {
        "DOUBAN_MCP_TIMEOUT_SECONDS": "30"
      }
    }
  }
}
```

### 使用本地源码

```json
{
  "mcpServers": {
    "douban-mcp": {
      "command": "python3",
      "args": ["-m", "douban_mcp.server"],
      "env": {
        "PYTHONPATH": "/path/to/douban-mcp/src",
        "DOUBAN_MCP_TIMEOUT_SECONDS": "30"
      }
    }
  }
}
```


## 说明

1. 这个 MCP 直接请求豆瓣游客态公开接口、公开资料页和公开 RSS，不依赖额外的 Astron 后端服务。
2. 当前仅面向公开内容能力，不包含登录态、私有内容或用户专属数据。
3. 作者内容列表优先使用 `interests` JSON 接口，必要时回退到 RSS 或显式收藏页。
4. 游客态公开接口可能受网络、地区或平台风控影响，偶发失败时建议稍后重试。


## 发布到 PyPI

```bash
cd douban-mcp
rm -rf build dist src/*.egg-info
python3 -m build --no-isolation
python3 -m twine check dist/*
python3 -m twine upload dist/*
```


## License

Apache License 2.0. See `LICENSE`.
