import os
import subprocess
from pathlib import Path
import copy

import numpy as np

from airfoilgmesher.utils import (
    geom_functions,
    rotate_vector_90_clockwise,
    rotate_vector_90_anticlockwise,
    find_intersection_with_y_equals_0,
    arc_circle,
    rotate_curve_around_point,
    compute_length,
)
from airfoilgmesher.full_airfoil_definition import define_airfoil_geometry, split_airfoil, permute_3_piece_airfoil

from shapely.geometry import MultiPoint, Polygon, MultiPolygon
from shapely.ops import unary_union
from scipy.interpolate import UnivariateSpline

def _add_o_mesh(geometry_file, curve, point_TE, dx_airfoil, mesh_parameters):

    if isinstance(curve, tuple) or isinstance(curve, list):
        curves = "".join(str(i)+',' for i in curve[:-1])
        curves += str(curve[-1])
    else:
        curves = str(curve)

    growth = mesh_parameters.get("growth", 1.15)

    geometry_file.write(f"""
    // Boundary-layer field
    Field[1] = BoundaryLayer;
    Field[1].CurvesList = {{{curves}}};

    // First cell height normal to the wall
    Field[1].Size = {mesh_parameters["first_el_h"]:.16g};

    // Total boundary-layer thickness
    Field[1].Thickness = {mesh_parameters["BL_t"]/4:.16g};

    // Growth ratio
    Field[1].Ratio = {growth:.16g};

    // Generate quadrilateral boundary-layer elements
    Field[1].Quads = 1;

    // Activate field
    BoundaryLayer Field = 1;
    // Important for sharp leading/trailing edges
    Field[1].FanPointsList = {{{point_TE}}};
    Field[1].FanPointsSizesList = {{{int(np.pi*mesh_parameters["BL_t"]/4/dx_airfoil)}}};\n\n""")

def _as_points_2d(curve):
    """
    Accepts curve as shape (2, N) or (N, 2).
    Returns shape (N, 2).
    """
    curve = np.asarray(curve, dtype=float)

    if curve.ndim != 2:
        raise ValueError("curve must be a 2D array with shape (2, N) or (N, 2).")

    if curve.shape[0] == 2:
        return curve.T.copy()
    elif curve.shape[1] == 2:
        return curve.copy()
    else:
        raise ValueError("curve must have shape (2, N) or (N, 2).")

def _remove_closing_duplicate(P, tol=1e-12):
    """
    Removes the duplicated last point if P[0] == P[-1].
    """
    if len(P) > 1 and np.linalg.norm(P[0] - P[-1]) < tol:
        return P[:-1]
    return P

def _remove_near_duplicate_points(P, tol=1e-10):
    """
    Removes consecutive points that are too close.
    Closed-loop aware.
    """
    if len(P) < 3:
        raise ValueError("At least 3 points are required for a closed loop.")

    keep = [0]

    for i in range(1, len(P)):
        if np.linalg.norm(P[i] - P[keep[-1]]) > tol:
            keep.append(i)

    P = P[keep]

    # Also check last-to-first distance.
    if len(P) > 2 and np.linalg.norm(P[-1] - P[0]) < tol:
        P = P[:-1]

    if len(P) < 3:
        raise ValueError("Too few unique points after duplicate removal.")

    return P

def _resample_closed_curve(P, n_points):
    """
    Uniform arclength resampling of a closed polygonal curve.

    P is shape (N, 2), without duplicated final point.
    Returns shape (n_points, 2), also without duplicated final point.
    """
    P = np.asarray(P, dtype=float)

    # Segment lengths, including last-to-first.
    P_next = np.roll(P, -1, axis=0)
    ds = np.linalg.norm(P_next - P, axis=1)

    valid = ds > 1e-14
    if not np.all(valid):
        P = P[valid]
        P_next = np.roll(P, -1, axis=0)
        ds = np.linalg.norm(P_next - P, axis=1)

    L = np.sum(ds)

    if L <= 0.0:
        raise ValueError("Degenerate closed curve with zero perimeter.")

    s_edges = np.concatenate(([0.0], np.cumsum(ds)))

    s_new = np.linspace(0.0, L, n_points, endpoint=False)

    P_new = np.zeros((n_points, 2))

    for j, sj in enumerate(s_new):
        i = np.searchsorted(s_edges, sj, side="right") - 1

        if i >= len(P):
            i = len(P) - 1

        local_ds = ds[i]

        if local_ds <= 1e-14:
            P_new[j] = P[i]
        else:
            t = (sj - s_edges[i]) / local_ds
            P_new[j] = (1.0 - t) * P[i] + t * P[(i + 1) % len(P)]

    return P_new

def _signed_area(P):
    """
    Signed area of a closed polygon.
    P has shape (N, 2), without duplicated final point.
    """
    x = P[:, 0]
    y = P[:, 1]
    return 0.5 * np.sum(x * np.roll(y, -1) - y * np.roll(x, -1))

def _taubin_smooth_closed(P, n_iter=20, lam=0.5, mu=-0.53):
    """
    Taubin smoothing for closed curves.

    Positive lambda smooths the curve.
    Negative mu compensates shrinkage.
    """
    P = P.copy()

    for _ in range(n_iter):
        lap = 0.5 * (np.roll(P, 1, axis=0) + np.roll(P, -1, axis=0)) - P
        P = P + lam * lap

        lap = 0.5 * (np.roll(P, 1, axis=0) + np.roll(P, -1, axis=0)) - P
        P = P + mu * lap

    return P

def smooth_closed_loop_for_mesh(
    curve,
    n_points=None,
    n_iter=20,
    lam=0.45,
    mu=-0.48,
    duplicate_tol=1e-10,
    preserve_area=True,
    return_closed=False,
    ):
    """
    Smooth a 2D closed loop for meshing.

    Parameters
    ----------
    curve : ndarray
        Closed curve with shape (2, N) or (N, 2). The last point may or may not
        repeat the first point.
    n_points : int or None
        Number of output points. If None, keeps approximately the input number
        of unique points.
    n_iter : int
        Number of Taubin smoothing iterations.
    lam : float
        Forward smoothing coefficient. Typical values: 0.3--0.6.
    mu : float
        Backward smoothing coefficient. Typical values: -0.45-- -0.55.
    duplicate_tol : float
        Tolerance for removing duplicated or nearly duplicated points.
    preserve_area : bool
        If True, rescales the smoothed loop around its centroid to preserve
        enclosed area approximately.
    return_closed : bool
        If True, appends the first point at the end.

    Returns
    -------
    curve_smooth : ndarray
        Smoothed curve with shape (2, M).
    """

    P = _as_points_2d(curve)
    P = _remove_closing_duplicate(P, tol=duplicate_tol)
    P = _remove_near_duplicate_points(P, tol=duplicate_tol)

    if n_points is None:
        n_points = len(P)

    if n_points < 3:
        raise ValueError("n_points must be at least 3.")

    # Uniform spacing before smoothing is important for stability.
    P0 = _resample_closed_curve(P, n_points)

    area0 = _signed_area(P0)
    centroid0 = np.mean(P0, axis=0)

    P_s = _taubin_smooth_closed(P0, n_iter=n_iter, lam=lam, mu=mu)

    if preserve_area:
        area_s = _signed_area(P_s)

        if abs(area_s) > 1e-14 and abs(area0) > 1e-14:
            centroid_s = np.mean(P_s, axis=0)
            scale = np.sqrt(abs(area0 / area_s))
            P_s = centroid_s + scale * (P_s - centroid_s)

            # Recenter to avoid small drift.
            P_s = P_s + (centroid0 - np.mean(P_s, axis=0))

    # Resample once more to recover uniform spacing after smoothing.
    P_s = _resample_closed_curve(P_s, n_points)

    if return_closed:
        P_s = np.vstack((P_s, P_s[0]))

    return P_s.T

def prepare_inflation_line(inflation, main, flap=True, displacement=0.5):
    idx_LE = np.argmin(inflation[0, :])
    inflation = np.hstack((inflation[:, idx_LE:], inflation[:, :idx_LE]))
    front_ids = np.where(inflation[0, :] < 0.5)[0]
    back_ids  = np.where(inflation[0, :] > 0.5)[0]
    front = front_ids[np.argmin(inflation[1, front_ids])]
    back  = back_ids[np.argmin(inflation[1, back_ids])]

    if front<back:
        front_ = copy.deepcopy(back)
        back = copy.deepcopy(front)
        front = copy.deepcopy(front_)
        del front_
    slope = (inflation[1,back]-inflation[1,front])/(inflation[0,back]-inflation[0,front])
    xnew = np.linspace(0, inflation[0,back]-inflation[0,front], front-back)
    ynew = inflation[1,front] + slope*xnew
    inflation[0,back:front] = np.flip(xnew)+inflation[0,front]
    inflation[1,back:front] = np.flip(ynew)
    inflation[:,back-10:back+10] = smooth_curve(inflation[:,back-10:back+10], inflation[:,back-10:back+10].shape[1], 0.1)
    inflation[:,front-10:front+10] = smooth_curve(inflation[:,front-10:front+10], inflation[:,front-10:front+10].shape[1], 0.1)
    te_idx = np.argmax(inflation[0,:])
    inflation = np.hstack((np.flip(inflation[:,:te_idx],axis=1), np.flip(inflation[:,te_idx:],axis=1)))
    # From TE to LE anti-clockwise
    te_idx = np.argmax(inflation[0,:])
    le_idx = np.argmin(inflation[0,:])
    if flap:
        main_te_idx = np.argmax(main[0,:])
        idx_top = np.argmin(np.abs(inflation[0,:le_idx]-main[0,main_te_idx]))
        idx_bot = np.argmin(np.abs(inflation[0,le_idx:]-main[0,main_te_idx])) + le_idx
        # Separate the curve and move it back 0.5 chords
        inflation_front = inflation[:,idx_top:idx_bot+1]
        inflation_back = np.hstack((inflation[:,idx_bot+1:], inflation[:,:idx_top]))
        inflation_back[0,:] = inflation_back[0,:] + displacement
        inflation_back[1,:] = inflation_back[1,:] + slope*displacement
        xnew_top = np.linspace(0, inflation_back[0,-1]-inflation_front[0,0], 100)
        ynew_top = inflation_front[1,0] + slope*xnew_top
        xnew_bot = np.linspace(0, inflation_back[0,0]-inflation_front[0,-1], 100)
        ynew_bot = inflation_front[1,-1] + slope*xnew_bot
        top_new = np.vstack((xnew_bot+inflation_front[0,-1], ynew_bot))[:,1:-1]
        bot_new = np.flip(np.vstack((xnew_top+inflation_front[0,0], ynew_top))[:,1:-1],axis=1)
        inflation = np.hstack((inflation_front[:,1:-1],
                                top_new,
                                inflation_back[:,1:-1],
                                bot_new,
                                ))
        # Reorganize
        te_idx = np.argmax(inflation[0,:])
        inflation = np.hstack((np.flip(inflation[:,:te_idx],axis=1), np.flip(inflation[:,te_idx:],axis=1)))
        smooth_closed_loop_for_mesh(
                                    inflation,
                                    n_points=inflation.shape[1]-10,
                                    n_iter=100,)
    return inflation

def bezier_arc_with_start_tangent(
    x1_1,
    x1_2,
    x2,
    N=100,
    end_tangent="vertical",
    l1=None,
    l2=None,
    ):
    """
    Generate a cubic Bezier curve from x1_2 to x2.

    The tangent at x1_2 is given by the direction x1_1 -> x1_2.
    The tangent at x2 is prescribed, by default vertical upward.

    Parameters
    ----------
    x1_1 : array_like, shape (2,)
        Point before x1_2. Used only to define the starting tangent.
    x1_2 : array_like, shape (2,)
        Initial point of the curve.
    x2 : array_like, shape (2,)
        Final point of the curve.
    N : int
        Number of generated points.
    end_tangent : str or array_like
        If "vertical", uses [0, 1].
        Otherwise, provide a 2D vector.
    l1 : float or None
        Length scale of the first Bezier handle.
    l2 : float or None
        Length scale of the second Bezier handle.

    Returns
    -------
    pts : ndarray, shape (2, N)
        Curve points ordered from x1_2 to x2.
    control_points : ndarray, shape (2, 4)
        Bezier control points [P0, P1, P2, P3].
    """

    x1_1 = np.asarray(x1_1, dtype=float)
    x1_2 = np.asarray(x1_2, dtype=float)
    x2 = np.asarray(x2, dtype=float)

    P0 = x1_2
    P3 = x2

    # Start tangent: direction from x1_1 to x1_2
    t0 = x1_2 - x1_1
    n0 = np.linalg.norm(t0)

    if n0 < 1e-14:
        raise ValueError("x1_1 and x1_2 are too close to define a tangent.")

    t0 = t0 / n0

    # End tangent
    if isinstance(end_tangent, str):
        if end_tangent == "vertical":
            t3 = np.array([0.0, 1.0])
        elif end_tangent == "horizontal":
            t3 = np.array([1.0, 0.0])
        else:
            raise ValueError("Unknown end_tangent string.")
    else:
        t3 = np.asarray(end_tangent, dtype=float)
        n3 = np.linalg.norm(t3)
        if n3 < 1e-14:
            raise ValueError("The final tangent vector is too small.")
        t3 = t3 / n3

    chord = np.linalg.norm(P3 - P0)

    if l1 is None:
        l1 = chord / 3.0
    if l2 is None:
        l2 = chord / 3.0

    P1 = P0 + l1 * t0
    P2 = P3 - l2 * t3

    s = np.linspace(0.0, 1.0, N)

    pts = (
        (1.0 - s) ** 3 * P0[:, None]
        + 3.0 * (1.0 - s) ** 2 * s * P1[:, None]
        + 3.0 * (1.0 - s) * s**2 * P2[:, None]
        + s**3 * P3[:, None]
    )

    control_points = np.column_stack((P0, P1, P2, P3))

    return pts

def inflation_multi_part_airfoil(
    pts_2xn,
    gap,
    n_out=1000,
    simplify=0.0,
    auto_increase=True,
    max_iter=20,
    increase_factor=1.25,
    ):
    """
    Build a single rounded outer blob around a 2xN point cloud.

    mesh_parameters
    ----------
    pts_2xn : ndarray, shape (2, N)
        Input point cloud.
    gap : float
        Geometric connection/rounding scale.
        Two separated point regions closer than roughly `gap` tend to merge.
    n_out : int
        Number of output points on the final closed contour.
    simplify : float
        Optional Shapely simplification tolerance.
    auto_increase : bool
        If True, increase the buffer until a single polygon is obtained.
    max_iter : int
        Maximum number of automatic buffer increases.
    increase_factor : float
        Multiplicative increase of the buffer radius.

    Returns
    -------
    contour_2xm : ndarray, shape (2, n_out)
        Closed outer blob contour.
    used_gap : float
        Final effective gap used.
    """

    pts = np.asarray(pts_2xn, dtype=float)

    if pts.shape[0] != 2:
        raise ValueError("Input must have shape (2, N).")

    pts = pts.T  # (N, 2)

    # Remove NaNs and duplicate points
    pts = pts[np.isfinite(pts).all(axis=1)]
    pts = np.unique(pts, axis=0)

    if len(pts) < 3:
        raise ValueError("At least 3 valid points are required.")

    radius = gap / 2.0

    geom = None
    for _ in range(max_iter):
        geom = MultiPoint(pts).buffer(radius, resolution=32)
        geom = unary_union(geom)

        if isinstance(geom, Polygon):
            break

        if isinstance(geom, MultiPolygon):
            if auto_increase:
                radius *= increase_factor
            else:
                # Keep the largest connected component only
                geom = max(geom.geoms, key=lambda g: g.area)
                break
    else:
        if isinstance(geom, MultiPolygon):
            geom = max(geom.geoms, key=lambda g: g.area)

    if simplify > 0:
        geom = geom.simplify(simplify, preserve_topology=True)

    if isinstance(geom, MultiPolygon):
        geom = max(geom.geoms, key=lambda g: g.area)

    # Exterior boundary coordinates
    xy = np.asarray(geom.exterior.coords)

    # Resample by arclength
    d = np.sqrt(np.sum(np.diff(xy, axis=0)**2, axis=1))
    s = np.r_[0.0, np.cumsum(d)]

    s_new = np.linspace(0.0, s[-1], n_out)

    x_new = np.interp(s_new, s, xy[:, 0])
    y_new = np.interp(s_new, s, xy[:, 1])

    contour = np.vstack([x_new, y_new])

    used_gap = 2.0 * radius

    return contour, used_gap

def smooth_curve(curve, n_out=None, smooth=1e-4, closed=False, remove_duplicates=True):
    """
    Smooth a 2xN planar curve using arclength-parametric splines.

    mesh_parameters
    ----------
    curve : ndarray, shape (2, N)
        Input curve points ordered along the curve.
    n_out : int or None
        Number of output points. If None, keeps original N.
    smooth : float
        Spline smoothing factor. Larger means smoother.
        This is passed to scipy.interpolate.UnivariateSpline.
    closed : bool
        If True, treats the curve as closed by appending the first point.
    remove_duplicates : bool
        Remove consecutive duplicate points to avoid zero arclength steps.

    Returns
    -------
    smooth_curve : ndarray, shape (2, n_out)
        Smoothed curve.
    """

    p = np.asarray(curve, dtype=float)

    if p.shape[0] != 2:
        raise ValueError("curve must have shape (2, N)")

    if n_out is None:
        n_out = p.shape[1]

    if closed:
        if np.linalg.norm(p[:, 0] - p[:, -1]) > 1e-12:
            p = np.column_stack([p, p[:, 0]])

    if remove_duplicates:
        dp = np.diff(p, axis=1)
        ds = np.sqrt(np.sum(dp**2, axis=0))
        keep = np.r_[True, ds > 1e-14]
        p = p[:, keep]

    if p.shape[1] < 4:
        raise ValueError("Need at least 4 non-duplicate points for spline smoothing.")

    # Arclength parameter
    dp = np.diff(p, axis=1)
    ds = np.sqrt(np.sum(dp**2, axis=0))
    s = np.r_[0.0, np.cumsum(ds)]

    if s[-1] <= 0:
        raise ValueError("Degenerate curve with zero total length.")

    # Normalize arclength to improve numerical conditioning
    s = s / s[-1]

    # Smooth x(s), y(s)
    spl_x = UnivariateSpline(s, p[0], s=smooth)
    spl_y = UnivariateSpline(s, p[1], s=smooth)

    if closed:
        s_new = np.linspace(0.0, 1.0, n_out, endpoint=False)
    else:
        s_new = np.linspace(0.0, 1.0, n_out)

    x_new = spl_x(s_new)
    y_new = spl_y(s_new)

    return np.vstack([x_new, y_new])

def _validate_points(points: np.ndarray) -> np.ndarray:
    points = np.asarray(points, dtype=float)

    if points.ndim != 2 or points.shape[0] != 2:
        raise ValueError("points must have shape [2, N].")

    if points.shape[1] < 5:
        raise ValueError("points must contain at least 5 surface points.")

    return points

def _split_upper_lower_by_le(points: np.ndarray, le_idx: int = None):
    """
    Split a TE-upper-LE-lower-TE airfoil curve into upper and lower parts.
    The LE is detected as the minimum x-coordinate point.
    """

    upper = points[:, :le_idx + 1]      # TE -> LE
    lower = points[:, le_idx:]          # LE -> TE

    if upper.shape[1] < 2 or lower.shape[1] < 2:
        raise ValueError("Could not split airfoil into upper/lower surfaces.")

    return upper, lower

def _add_points(fig, points, point_number, mesh_size=1.0, skip_first=False):
    ids = []

    start = 1 if skip_first else 0

    for i in range(start, points.shape[1]):
        point_number += 1
        fig.Add_point(
            point_number,
            points[0, i],
            points[1, i],
            mesh_size,
        )
        ids.append(point_number)

    return np.array(ids), point_number

def _compute_offset(points:np.ndarray, offset: float, reverse:bool = False) -> np.ndarray:
    """
    Build approximate O-grid offset curve around the airfoil.
    """
    diff = np.zeros_like(points)

    for i in range(1, points.shape[1] - 1):
        tangent = points[:, i + 1] - points[:, i - 1]
        normal = rotate_vector_90_clockwise(tangent)
        norm = np.linalg.norm(normal)

        if norm > 0.0:
            diff[:, i] = normal / norm
    if reverse:
        diff = -diff

    o_points = points.copy()

    diff[:,0] = diff[:,1]
    diff[:,-1] = diff[:,-2]

    for i in range(points.shape[1]):
        o_points[:, i] += offset * diff[:, i]
    
    # import matplotlib.pyplot as plt
    # plt.scatter(points[0, :], points[1, :], s=np.linspace(5,50,points.shape[1]))
    # plt.scatter(o_points[0, :], o_points[1, :], s=np.linspace(5,50,o_points.shape[1]), c='k')
    # plt.savefig('test')
    # breakpoint()
    return o_points, diff

def _compute_offset_curve(points: np.ndarray, offset: float) -> np.ndarray:
    """
    Build approximate O-grid offset curve around the airfoil.
    """
    o_points, diff = _compute_offset(points, offset)

    # Close the wake-side rounded section
    tg1 = rotate_vector_90_clockwise(o_points[:, 0] - o_points[:, 1])
    tg2 = rotate_vector_90_anticlockwise(o_points[:, -1] - o_points[:, -2])

    p1 = find_intersection_with_y_equals_0(
        o_points[:, 0],
        tg1 / np.linalg.norm(tg1),
    )
    p2 = find_intersection_with_y_equals_0(
        o_points[:, -1],
        tg2 / np.linalg.norm(tg2),
    )

    centre = 0.5 * (p1 + p2)

    rounded_section, _ = arc_circle(
        centre,
        o_points[:, -1],
        o_points[:, 0],
    )

    o_points = np.hstack((o_points[:, 1:-1], rounded_section))

    n_back = int((rounded_section.shape[1] + 1) / 2)

    # Reorder so the curve starts near the upper wake side
    o_points = np.hstack((o_points[:, -n_back:], o_points[:, :-n_back]))

    # Close curve explicitly
    o_points = np.hstack((o_points, o_points[:, [0]]))

    return o_points

def _build_inflation_curve(mesh_parameters: dict) -> np.ndarray:
    top_h_points = np.array([
        [1.0 + mesh_parameters["Inflation-x"], 0.0],
        [mesh_parameters["Inflation-y"], mesh_parameters["Inflation-y"]],
    ])

    bot_h_points = np.array([
        [0.0, 1.0 + mesh_parameters["Inflation-x"]],
        [-mesh_parameters["Inflation-y"], -mesh_parameters["Inflation-y"]],
    ])

    back_v_points = np.array([
        [1.0 + mesh_parameters["Inflation-x"], 1.0 + mesh_parameters["Inflation-x"]],
        [-mesh_parameters["Inflation-y"], mesh_parameters["Inflation-y"]],
    ])

    front_points, _ = arc_circle(
        [0.0, 0.0],
        [0.0, mesh_parameters["Inflation-y"]],
        [0.0, -mesh_parameters["Inflation-y"]],
    )

    infl = np.hstack((
        top_h_points,
        front_points,
        bot_h_points,
        back_v_points,
    ))

    # Close curve explicitly
    # infl = np.hstack((infl, infl[:, [0]]))

    return infl

def write_gmsh_local_circular_threshold_fields(
    f,
    refinement_regions,
    first_point_id=50000,
    first_field_id=100,
    background_field_id=None,
    ):
    """
    Write local circular refinement fields for Gmsh without imposing a global
    VOut over the whole domain.

    Uses:
        Distance field to a center point
        Threshold field with StopAtDistMax = 1
        Min field to combine several local refinement zones

    Each region must contain:
        center   : (x, y) or (x, y, z)
        radius   : fully refined radius, DistMin
        lc_in    : mesh size inside radius, SizeMin

    Optional:
        transition_radius : radius where the field stops, DistMax
        lc_out            : transition size at DistMax, SizeMax

    Example:
        {
            "center": (0.0, 0.0, 0.0),
            "radius": 0.15,
            "transition_radius": 0.25,
            "lc_in": 0.001,
            "lc_out": 0.02,
        }
    """

    if not refinement_regions:
        return None

    threshold_field_ids = []

    for i, region in enumerate(refinement_regions):
        point_id = first_point_id + i
        distance_field_id = first_field_id + 2 * i
        threshold_field_id = first_field_id + 2 * i + 1

        center = region["center"]
        if len(center) == 2:
            x, y = center
            z = 0.0
        elif len(center) == 3:
            x, y, z = center
        else:
            raise ValueError("region['center'] must have length 2 or 3.")

        radius = float(region["radius"])
        transition_radius = float(region.get("transition_radius", 4*radius))
        lc_in = float(region["lc_in"])
        lc_out = float(region.get("lc_out", 10.0 * lc_in))

        if radius <= 0:
            raise ValueError("region['radius'] must be positive.")
        if transition_radius < radius:
            raise ValueError("transition_radius must be >= radius.")
        if lc_in <= 0 or lc_out <= 0:
            raise ValueError("lc_in and lc_out must be positive.")

        f.write(f"\n// Local circular refinement region {i}\n")
        f.write(f"Point({point_id}) = {{{x:.16g}, {y:.16g}, {z:.16g}, 1.0}};\n")

        f.write(f"Field[{distance_field_id}] = Distance;\n")
        f.write(f"Field[{distance_field_id}].PointsList = {{{point_id}}};\n")

        f.write(f"Field[{threshold_field_id}] = Threshold;\n")
        f.write(f"Field[{threshold_field_id}].InField = {distance_field_id};\n")
        f.write(f"Field[{threshold_field_id}].SizeMin = {lc_in:.16g};\n")
        f.write(f"Field[{threshold_field_id}].SizeMax = {lc_out:.16g};\n")
        f.write(f"Field[{threshold_field_id}].DistMin = {radius:.16g};\n")
        f.write(f"Field[{threshold_field_id}].DistMax = {transition_radius:.16g};\n")
        f.write(f"Field[{threshold_field_id}].StopAtDistMax = 1;\n")

        threshold_field_ids.append(threshold_field_id)

    if len(threshold_field_ids) == 1:
        f.write(f"\nBackground Field = {threshold_field_ids[0]};\n")
        return threshold_field_ids[0]

    if background_field_id is None:
        background_field_id = first_field_id + 2 * len(refinement_regions)

    field_list = ", ".join(str(fid) for fid in threshold_field_ids)

    f.write("\n// Combine local refinement fields\n")
    f.write(f"Field[{background_field_id}] = Min;\n")
    f.write(f"Field[{background_field_id}].FieldsList = {{{field_list}}};\n")
    f.write(f"Background Field = {background_field_id};\n")

    return background_field_id

def define_refinement_regions(refinement_parameters, mesh_data):
    regions = []

    for param in refinement_parameters:
        if param == 'LE' and "LE" in mesh_data.keys():
            regions.append({
                "type": "circle",
                "center": [mesh_data["LE"][0], mesh_data["LE"][1], 0],
                "radius": mesh_data["o_ring_d"]*2,
                "lc_in": mesh_data["o_ring_el_size"],
                "lc_out": mesh_data["o_ring_el_size_out"],
            })
        elif param == 'TE' and "TE" in mesh_data.keys():
            regions.append({
                "type": "circle",
                "center": [mesh_data["TE"][0], mesh_data["TE"][1], 0],
                "radius": mesh_data["o_ring_d"]*2,
                "lc_in": mesh_data["o_ring_el_size"],
                "lc_out": mesh_data["o_ring_el_size_out"],
            })
        elif param == 'flap_wake' and "flap_wake" in mesh_data.keys():
            regions.append({
                "type": "circle",
                "center": [mesh_data["flap_wake"][0], mesh_data["flap_wake"][1], 0],
                "radius": mesh_data["flap_wake_r"],
                "lc_in": mesh_data["o_ring_el_size"],
                "lc_out": mesh_data["o_ring_el_size_out"],
            })
        elif param == 'slat_gap' and "slat_gap" in mesh_data.keys():
            regions.append({
                "type": "circle",
                "center": [mesh_data["slat_gap"][0], mesh_data["slat_gap"][1], 0],
                "radius": mesh_data["slat_gap_r"],
                "lc_in": mesh_data["o_ring_el_size"],
                "lc_out": mesh_data["o_ring_el_size_out"],
            })
        elif param == 'flap_gap' and "flap_gap" in mesh_data.keys():
            regions.append({
                "type": "circle",
                "center": [mesh_data["flap_gap"][0], mesh_data["flap_gap"][1], 0],
                "radius": mesh_data["flap_gap_r"],
                "lc_in": mesh_data["o_ring_el_size"],
                "lc_out": mesh_data["o_ring_el_size_out"],
            })

    return regions

def build_full_airfoil_mesh(file, points, mesh_parameters, refinement_parameters=None):
    """
    Build a 3D Gmsh mesh around a 2D airfoil.

    Expected airfoil ordering:
        TE -> upper surface -> LE -> lower surface -> TE

    mesh_parameters
    ----------
    file : str or Path
        Output .geo file.
    points : ndarray, shape [2, N]
        Airfoil coordinates.
    mesh_parameters : dict
        Meshing and domain mesh_parameters.
    """

    points = _validate_points(points)
    file = Path(file)

    required_keys = [
        "xmin", "xmax", "ymax",
        "BL_t", "alpha",
        "AR_target", "infl_ratio",
        "Inflation-x", "Inflation-y",
        "boundary_ratio",
    ]

    missing = [key for key in required_keys if key not in mesh_parameters]
    if missing:
        raise KeyError(f"Missing mesh_parameters: {missing}")

    point_number = 0
    line_number = 1
    curve_number = 1

    with open(file, "w") as geometry_file:
        fig = geom_functions(file=geometry_file)

        geometry_file.write("// Airfoil mesh generated by Python\n\n")

        # ------------------------------------------------------------------
        # Domain points
        # ------------------------------------------------------------------
        geometry_file.write("// Define domain points\n")

        domain = {
            "Top-Left":  [mesh_parameters["xmin"],  mesh_parameters["ymax"]],
            "Top-Right": [mesh_parameters["xmax"],  mesh_parameters["ymax"]],
            "Bot-Right": [mesh_parameters["xmax"], -mesh_parameters["ymax"]],
            "Bot-Left":  [mesh_parameters["xmin"], -mesh_parameters["ymax"]],
        }

        domain_points = {}

        for name, pos in domain.items():
            point_number += 1
            fig.Add_point(point_number, pos[0], pos[1], 1.0)
            domain_points[name] = point_number

        geometry_file.write("\n")

        # ------------------------------------------------------------------
        # Offset curve and rotation
        # ------------------------------------------------------------------
        offset = 2.2 * mesh_parameters["BL_t"]
        o_points = _compute_offset_curve(points, offset)

        # Obtain the leading edge point index
        le_idx = int(np.argmin(points[0, :]))
        le_idx_o = int(np.argmin(o_points[0, :]))

        points = rotate_curve_around_point(
            points,
            mesh_parameters["alpha"],
            [0.25, 0.0],
        )

        o_points = rotate_curve_around_point(
            o_points,
            mesh_parameters["alpha"],
            [0.25, 0.0],
        )

        # ------------------------------------------------------------------
        # Mesh resolution
        # ------------------------------------------------------------------
        dx_o = mesh_parameters["AR_target"] * mesh_parameters["BL_t"]
        n_airfoil = int(np.ceil(compute_length(o_points) / (2.0 * dx_o)))

        if n_airfoil < 75:
            n_airfoil = 75
            dx_o = compute_length(o_points) / (2.0 * n_airfoil)

        n_infl = max(4, int(n_airfoil / mesh_parameters["infl_ratio"]))

        # ------------------------------------------------------------------
        # Split curves
        # ------------------------------------------------------------------
        airfoil_upper, airfoil_lower = _split_upper_lower_by_le(points, le_idx)
        o_airfoil_upper, o_airfoil_lower = _split_upper_lower_by_le(o_points, le_idx_o)

        # Define point TE for o_ring
        point_TE = copy.deepcopy(point_number+1)

        # ------------------------------------------------------------------
        # Add airfoil points
        # ------------------------------------------------------------------
        geometry_file.write("// Define airfoil points\n")

        airfoil_points_up, point_number = _add_points(
            fig,
            airfoil_upper,
            point_number,
        )

        lower_new_ids, point_number = _add_points(
            fig,
            airfoil_lower,
            point_number,
            skip_first=True,
        )

        # airfoil_points_low = [airfoil_points_up[-1]] + lower_new_ids
        airfoil_points_low = np.append(airfoil_points_up[-1],lower_new_ids)

        o_airfoil_points_up, point_number = _add_points(
            fig,
            o_airfoil_upper,
            point_number,
        )

        o_lower_new_ids, point_number = _add_points(
            fig,
            o_airfoil_lower,
            point_number,
            skip_first=True,
        )

        # o_airfoil_points_low = [o_airfoil_points_up[-1]] + o_lower_new_ids
        o_airfoil_points_low = np.append(o_airfoil_points_up[-1],o_lower_new_ids)

        geometry_file.write("\n")

        # ------------------------------------------------------------------
        # Inflation/refinement curve
        # ------------------------------------------------------------------
        geometry_file.write("// Define inflation curve points\n")

        infl = _build_inflation_curve(mesh_parameters)

        boundary_dx = compute_length(infl) / n_infl / mesh_parameters["boundary_ratio"]
        boundary_dx = min(boundary_dx, 0.8)

        infl_points, point_number = _add_points(
            fig,
            infl,
            point_number,
        )

        geometry_file.write("\n")

        # ------------------------------------------------------------------
        # Domain lines
        # ------------------------------------------------------------------
        geometry_file.write("// Define domain lines\n")

        domain_lines = {}

        fig.Add_line(line_number, domain_points["Top-Left"], domain_points["Top-Right"])
        domain_lines["Top"] = line_number
        line_number += 1

        fig.Add_line(line_number, domain_points["Top-Right"], domain_points["Bot-Right"])
        domain_lines["Wake"] = line_number
        line_number += 1

        fig.Add_line(line_number, domain_points["Bot-Right"], domain_points["Bot-Left"])
        domain_lines["Bottom"] = line_number
        line_number += 1

        fig.Add_line(line_number, domain_points["Bot-Left"], domain_points["Top-Left"])
        domain_lines["Front"] = line_number
        line_number += 1

        geometry_file.write("\n")

        # ------------------------------------------------------------------
        # Boundary curve loop
        # ------------------------------------------------------------------
        geometry_file.write("// Define outer boundary curve loop\n")

        fig.Add_CurveLoop(
            curve_number=curve_number,
            line_list=[
                domain_lines["Top"],
                domain_lines["Wake"],
                domain_lines["Bottom"],
                domain_lines["Front"],
            ],
        )

        boundary_loop = curve_number
        curve_number += 1

        geometry_file.write("\n")

        # ------------------------------------------------------------------
        # Airfoil and internal lines
        # ------------------------------------------------------------------
        geometry_file.write("// Define airfoil and refinement lines\n")

        fig.Add_custom_line(line_number, airfoil_points_up, close=False)
        airfoil_up_line = line_number
        line_number += 1

        fig.Add_custom_line(line_number, airfoil_points_low, close=False)
        airfoil_low_line = line_number
        line_number += 1

        fig.Add_custom_line(line_number, o_airfoil_points_up, close=False)
        o_airfoil_up_line = line_number
        line_number += 1

        fig.Add_custom_line(line_number, o_airfoil_points_low, close=False)
        o_airfoil_low_line = line_number
        line_number += 1

        fig.Add_custom_line(line_number, infl_points, close=True)
        infl_line = line_number
        line_number += 1

        geometry_file.write("\n")

        # ------------------------------------------------------------------
        # Transfinite lines
        # ------------------------------------------------------------------
        geometry_file.write("// Mesh refinement\n")

        fig.Add_Transfinite_Line(
            Lines_list=[airfoil_up_line],
            Transfinite_number=int(n_airfoil * 1.35),
            Progression=True,
            Progression_number=0.999,
        )

        fig.Add_Transfinite_Line(
            Lines_list=[airfoil_low_line],
            Transfinite_number=int(n_airfoil * 1.35),
            Progression=True,
            Progression_number=1.001,
        )

        fig.Add_Transfinite_Line(
            Lines_list=[o_airfoil_up_line],
            Transfinite_number=n_airfoil,
            Progression=False,
            Progression_number=1.0,
        )

        fig.Add_Transfinite_Line(
            Lines_list=[o_airfoil_low_line],
            Transfinite_number=n_airfoil,
            Progression=False,
            Progression_number=1.0,
        )

        fig.Add_Transfinite_Line(
            Lines_list=[infl_line],
            Transfinite_number=n_infl,
            Progression=False,
            Progression_number=1.0,
        )

        fig.Add_Transfinite_Line(
            Lines_list=[domain_lines["Top"], domain_lines["Bottom"]],
            Transfinite_number=max(
                2,
                int((mesh_parameters["xmax"] - mesh_parameters["xmin"]) / boundary_dx),
            ),
            Progression=False,
            Progression_number=1.0,
        )

        fig.Add_Transfinite_Line(
            Lines_list=[domain_lines["Front"], domain_lines["Wake"]],
            Transfinite_number=max(
                2,
                int((2.0 * mesh_parameters["ymax"]) / boundary_dx),
            ),
            Progression=False,
            Progression_number=1.0,
        )

        geometry_file.write("\n")

        # ------------------------------------------------------------------
        # Curve loops
        # ------------------------------------------------------------------
        geometry_file.write("// Define curve loops\n")

        fig.Add_CurveLoop(
            curve_number=curve_number,
            line_list=[o_airfoil_up_line, o_airfoil_low_line],
        )
        o_airfoil_loop = curve_number
        curve_number += 1

        fig.Add_CurveLoop(
            curve_number=curve_number,
            line_list=[airfoil_up_line, airfoil_low_line],
        )
        airfoil_loop = curve_number
        curve_number += 1

        fig.Add_CurveLoop(
            curve_number=curve_number,
            line_list=[infl_line],
        )
        infl_loop = curve_number
        curve_number += 1

        geometry_file.write("\n")

        # ------------------------------------------------------------------
        # Surfaces
        # ------------------------------------------------------------------
        geometry_file.write("// Define plane surfaces\n")

        fig.Add_PlaneSurface(
            surface_number=1,
            Loop_number=(boundary_loop, infl_loop),
        )

        fig.Add_PlaneSurface(
            surface_number=2,
            Loop_number=(infl_loop, o_airfoil_loop),
        )

        fig.Add_PlaneSurface(
            surface_number=3,
            Loop_number=(o_airfoil_loop, airfoil_loop),
        )

        geometry_file.write("\n")

        # ------------------------------------------------------------------
        # Refinement
        # ------------------------------------------------------------------

        refinement = mesh_parameters.get("refinement", None)
        if refinement is not None:
            write_gmsh_local_circular_threshold_fields(geometry_file, refinement)
        elif refinement_parameters is not None:
            le_idx = np.argmin(points[0, :])
            le_o_idx = np.argmin(o_points[0, :])
            te_idx = np.argmax(points[0, :])
            te_o_idx = np.argmax(o_points[0, :])
            mesh_data = {
                'LE': np.mean(np.hstack((points[:, le_idx].reshape(-1,1), o_points[:, le_o_idx].reshape(-1,1))), axis=1),
                'TE': np.mean(np.hstack((points[:, te_idx].reshape(-1,1), o_points[:, te_o_idx].reshape(-1,1))), axis=1),
                'o_ring_d': 0.1,
                'o_ring_el_size': compute_length(o_points)/(2*n_airfoil),
                'o_ring_el_size_out': 10*compute_length(o_points)/(2*n_airfoil),
            }
            refinement = define_refinement_regions(refinement_parameters, mesh_data)
            write_gmsh_local_circular_threshold_fields(geometry_file, refinement)

        #
        o_ring = mesh_parameters.get("o_ring", False)
        if o_ring and "first_el_h" in mesh_parameters.keys():
            dx_airfoil = compute_length(airfoil_upper)/(1.35*n_airfoil)
            _add_o_mesh(geometry_file, (airfoil_up_line, airfoil_low_line), point_TE, dx_airfoil, mesh_parameters)

        # ------------------------------------------------------------------
        # Extrusion
        # ------------------------------------------------------------------
        geometry_file.write("// Extrude\n")

        fig.Add_Extrude(
            extrude=1,
            Surface_list=[1, 2, 3],
        )

        geometry_file.write("\n")

        # ------------------------------------------------------------------
        # Physical groups
        # WARNING:
        # These IDs are still hard-coded and may depend on how Add_Extrude()
        # writes the Gmsh extrusion. If the geometry changes, verify them.
        # ------------------------------------------------------------------
        geometry_file.write("// Physical groups\n")

        physical_number = 1

        fig.Add_Physical_Surface("inlet", physical_number, [31])
        physical_number += 1

        fig.Add_Physical_Surface("outlet", physical_number, [23])
        physical_number += 1

        fig.Add_Physical_Surface("airfoil", physical_number, [70, 74])
        physical_number += 1

        fig.Add_Physical_Surface("front", physical_number, [36, 53, 75])
        physical_number += 1

        fig.Add_Physical_Surface("back", physical_number, [1, 2, 3])
        physical_number += 1

        fig.Add_Physical_Surface("Top_bot", physical_number, [19, 27])
        physical_number += 1

        fig.Add_Physical_Volume("internal", physical_number, [1, 2, 3])

        geometry_file.write("\n")
        geometry_file.write("Mesh.MshFileVersion = 2.2;\n")
        geometry_file.write("Geometry.Tolerance = 1e-9;\n")

    msh_file = file.with_suffix(".msh")

    subprocess.run(
        [
            "gmsh",
            str(file),
            "-o",
            str(msh_file),
            "-format",
            "msh2",
            "-3",
        ],
        check=True,
    )

def _compute_center(first,second):
    return np.mean(np.hstack((first.reshape(-1,1), second.reshape(-1,1))),axis=1)

def build_2piece_airfoil_mesh_slat(file, main, slat, split_info, mesh_parameters, refinement_parameters=None):
    file = Path(file)

    required_keys = [
        "xmin", "xmax", "ymax",
        "BL_t", "alpha",
        "AR_target", "infl_ratio", "infl_ratio_square",
        "Inflation-x", "Inflation-y",
        "boundary_ratio",
    ]

    missing = [key for key in required_keys if key not in mesh_parameters]
    if missing:
        raise KeyError(f"Missing mesh_parameters: {missing}")

    slat = np.flip(slat, axis=1)
    main = np.flip(main, axis=1)[:,:-1]
    point_number = 0
    line_number = 1
    curve_number = 1

    with open(file, "w") as geometry_file:
        fig = geom_functions(file=geometry_file)

        geometry_file.write("// Airfoil mesh generated by Python\n\n")

        # ------------------------------------------------------------------
        # Domain points
        # ------------------------------------------------------------------
        geometry_file.write("// Define domain points\n")

        domain = {
            "Top-Left":  [mesh_parameters["xmin"],  mesh_parameters["ymax"]],
            "Top-Right": [mesh_parameters["xmax"],  mesh_parameters["ymax"]],
            "Bot-Right": [mesh_parameters["xmax"], -mesh_parameters["ymax"]],
            "Bot-Left":  [mesh_parameters["xmin"], -mesh_parameters["ymax"]],
        }

        domain_points = {}

        for name, pos in domain.items():
            point_number += 1
            fig.Add_point(point_number, pos[0], pos[1], 1.0)
            domain_points[name] = point_number

        geometry_file.write("\n")

        # ------------------------------------------------------------------
        # Offset curve and rotation
        # ------------------------------------------------------------------
        ############### SLAT OFFSET CURVE WITH ROUNDED SECTIONS ###############
        offset = 0.012
        if mesh_parameters["BL_t"] >0.012:
            offset = 0.012
        else:
            offset = mesh_parameters["BL_t"]
        
        gap_slat_main = np.min(np.sqrt(np.sum((main[:, :, None] - slat[:, None, :])**2, axis=0)))
        if offset > gap_slat_main/2.0:
            offset_1 = 0.975*(gap_slat_main/2.0)
        else:
            offset_1=offset

        back,_ = _compute_offset(slat[:,(-split_info['idx_low_point_slat']-1):], offset_1)
        front,_ = _compute_offset(slat[:,:-split_info['idx_low_point_slat']], offset_1)
        
        rounded_section_1, _ = arc_circle(
                            _compute_center(front[:, -1], back[:, 0]),
                            front[:, -1],
                            back[:, 0],
                            N=100,
                        )
        rounded_section_2, _ = arc_circle(
                            # slat[:,0],
                            _compute_center(back[:, -1], front[:, 0]),
                            back[:, -1],
                            front[:, 0],
                            N=100,
                        )
        slat_o = np.hstack((front, rounded_section_1, back, rounded_section_2))
        del front, back, rounded_section_1, rounded_section_2

        slat = rotate_curve_around_point(
            slat,
            mesh_parameters["alpha"],
            [0.25, 0.0],
        )
        slat_o = rotate_curve_around_point(
            slat_o,
            mesh_parameters["alpha"],
            [0.25, 0.0],
        )        

        ############### MAIN OFFSET CURVE WITH ROUNDED SECTIONS ###############
        main_o_1,_ = _compute_offset(main, offset_1)
        rounded_section_1, _ = arc_circle(
                            # center,
                            _compute_center(main_o_1[:, -1], main_o_1[:, 0]),
                            main_o_1[:, -1],
                            main_o_1[:, 0],
                            N=50
                        )
        main_o = np.hstack((main_o_1, rounded_section_1))
        del main_o_1, rounded_section_1
        
        main = rotate_curve_around_point(
            main,
            mesh_parameters["alpha"],
            [0.25, 0.0],
        )
        main_o = rotate_curve_around_point(
            main_o,
            mesh_parameters["alpha"],
            [0.25, 0.0],
        )

        # ------------------------------------------------------------------
        # Inflation sections
        # ------------------------------------------------------------------

        ############### INFLATION AROUND THE 3 PIECES ###############

        inflation, _ = inflation_multi_part_airfoil(
                            np.hstack((slat_o, main_o)),      # shape (2, N)
                            gap=0.12,    # adapt to your airfoil coordinate scale
                            n_out=1500,
                            simplify=0.001,
                        )
        inflation = prepare_inflation_line(inflation, main, flap=False)

        ############### GENERAL INFLATION ###############
        inflation_square = _build_inflation_curve(mesh_parameters)

        # ------------------------------------------------------------------
        # Add points
        # ------------------------------------------------------------------
        slat_points, point_number = _add_points(
            fig,
            slat,
            point_number,
        )
        slat_o_points, point_number = _add_points(
            fig,
            slat_o,
            point_number,
        )
        main_points, point_number = _add_points(
            fig,
            main,
            point_number,
        )
        main_o_points, point_number = _add_points(
            fig,
            main_o,
            point_number,
        )
        inflation_points, point_number = _add_points(
            fig,
            inflation,
            point_number,
        )
        inflation_square_points, point_number = _add_points(
            fig,
            inflation_square,
            point_number,
        )

        geometry_file.write("\n")

        ################ COMPUTE LENGTHS AND SEGMENTATIONS #################
        dx_o = mesh_parameters["AR_target"] * mesh_parameters["BL_t"]

        n_slat = int(np.ceil(compute_length(slat) / (2.0 * dx_o)))
        if n_slat < 75:
            n_slat = 75
        n_slat_o = int(n_slat*0.95)

        n_main = int(np.ceil(compute_length(main) / (2.0 * dx_o)))
        if n_main < 75:
            n_main = 75
        n_main_o = int(n_main*0.95)

        n_inflation = max(50, int(n_main / mesh_parameters["infl_ratio"]))
        n_inflation_square = max(10, int(n_inflation / mesh_parameters["infl_ratio_square"]))

        boundary_dx = compute_length(inflation_square) / n_inflation_square / mesh_parameters["boundary_ratio"]
        boundary_dx = min(boundary_dx, 0.8)

        # ------------------------------------------------------------------
        # Domain lines
        # ------------------------------------------------------------------
        geometry_file.write("// Define domain lines\n")

        domain_lines = {}
        fig.Add_line(line_number, domain_points["Top-Left"], domain_points["Top-Right"])
        domain_lines["Top"] = line_number
        line_number += 1
        fig.Add_line(line_number, domain_points["Top-Right"], domain_points["Bot-Right"])
        domain_lines["Wake"] = line_number
        line_number += 1
        fig.Add_line(line_number, domain_points["Bot-Right"], domain_points["Bot-Left"])
        domain_lines["Bottom"] = line_number
        line_number += 1
        fig.Add_line(line_number, domain_points["Bot-Left"], domain_points["Top-Left"])
        domain_lines["Front"] = line_number
        line_number += 1

        geometry_file.write("\n")

        # ------------------------------------------------------------------
        # Airfoil and internal lines
        # ------------------------------------------------------------------
        geometry_file.write("// Define airfoil and refinement lines\n")

        fig.Add_custom_line(line_number, np.append(slat_points,slat_points[0]), close=False)
        slat_line = line_number
        line_number += 1

        fig.Add_custom_line(line_number, np.append(slat_o_points,slat_o_points[0]), close=False)
        slat_o_line = line_number
        line_number += 1

        fig.Add_custom_line(line_number, np.append(main_points,main_points[0]), close=False)
        main_line = line_number
        line_number += 1

        fig.Add_custom_line(line_number, np.append(main_o_points,main_o_points[0]), close=False)
        main_o_line = line_number
        line_number += 1

        fig.Add_custom_line(line_number, inflation_points, close=True)
        inflation_line = line_number
        line_number += 1

        fig.Add_custom_line(line_number, inflation_square_points, close=True)
        inflation_square_line = line_number
        line_number += 1

        geometry_file.write("\n")

        # ------------------------------------------------------------------
        # Transfinite lines
        # ------------------------------------------------------------------
        geometry_file.write("// Mesh refinement\n")

        fig.Add_Transfinite_Line(
            Lines_list=[slat_line],
            Transfinite_number=int(n_slat),
            Progression=True,
            Progression_number=1,
        )
        fig.Add_Transfinite_Line(
            Lines_list=[slat_o_line],
            Transfinite_number=int(n_slat_o),
            Progression=True,
            Progression_number=1,
        )

        fig.Add_Transfinite_Line(
            Lines_list=[main_line],
            Transfinite_number=int(n_main),
            Progression=True,
            Progression_number=1,
        )
        fig.Add_Transfinite_Line(
            Lines_list=[main_o_line],
            Transfinite_number=int(n_main_o),
            Progression=True,
            Progression_number=1,
        )

        fig.Add_Transfinite_Line(
            Lines_list=[inflation_line],
            Transfinite_number=n_inflation,
            Progression=False,
            Progression_number=1.0,
        )
        fig.Add_Transfinite_Line(
            Lines_list=[inflation_square_line],
            Transfinite_number=n_inflation_square,
            Progression=False,
            Progression_number=1.0,
        )

        fig.Add_Transfinite_Line(
            Lines_list=[domain_lines["Top"], domain_lines["Bottom"]],
            Transfinite_number=max(
                2,
                int((mesh_parameters["xmax"] - mesh_parameters["xmin"]) / boundary_dx),
            ),
            Progression=False,
            Progression_number=1.0,
        )

        fig.Add_Transfinite_Line(
            Lines_list=[domain_lines["Front"], domain_lines["Wake"]],
            Transfinite_number=max(
                2,
                int((2.0 * mesh_parameters["ymax"]) / boundary_dx),
            ),
            Progression=False,
            Progression_number=1.0,
        )

        geometry_file.write("\n")

        # ------------------------------------------------------------------
        # Curve loops
        # ------------------------------------------------------------------
        geometry_file.write("// Define curve loops\n")

        fig.Add_CurveLoop(
            curve_number=curve_number,
            line_list=[
                domain_lines["Top"],
                domain_lines["Wake"],
                domain_lines["Bottom"],
                domain_lines["Front"],
            ],
        )
        boundary_loop = copy.deepcopy(curve_number)
        curve_number += 1

        fig.Add_CurveLoop(
            curve_number=curve_number,
            line_list=[slat_line],
        )
        slat_loop = copy.deepcopy(curve_number)
        curve_number += 1
        fig.Add_CurveLoop(
            curve_number=curve_number,
            line_list=[slat_o_line],
        )
        slat_o_loop = copy.deepcopy(curve_number)
        curve_number += 1

        fig.Add_CurveLoop(
            curve_number=curve_number,
            line_list=[main_line],
        )
        main_loop = copy.deepcopy(curve_number)
        curve_number += 1
        fig.Add_CurveLoop(
            curve_number=curve_number,
            line_list=[main_o_line],
        )
        main_o_loop = copy.deepcopy(curve_number)
        curve_number += 1

        fig.Add_CurveLoop(
            curve_number=curve_number,
            line_list=[inflation_line],
        )
        inflation_loop = curve_number
        curve_number += 1
        fig.Add_CurveLoop(
            curve_number=curve_number,
            line_list=[inflation_square_line],
        )
        inflation_square_loop = curve_number
        curve_number += 1

        geometry_file.write("\n")

        

        # ------------------------------------------------------------------
        # Surfaces
        # ------------------------------------------------------------------
        geometry_file.write("// Define plane surfaces\n")

        fig.Add_PlaneSurface(
            surface_number=1,
            Loop_number=(boundary_loop, inflation_square_loop),
        )

        fig.Add_PlaneSurface(
            surface_number=2,
            Loop_number=(inflation_square_loop, inflation_loop),
        )

        fig.Add_PlaneSurface(
            surface_number=3,
            Loop_number=(inflation_loop, slat_o_loop, main_o_loop),
        )

        fig.Add_PlaneSurface(
            surface_number=4,
            Loop_number=(slat_loop, slat_o_loop),
        )

        fig.Add_PlaneSurface(
            surface_number=5,
            Loop_number=(main_loop, main_o_loop),
        )

        geometry_file.write("\n")

        # ------------------------------------------------------------------
        # Extrusion
        # ------------------------------------------------------------------
        geometry_file.write("// Extrude\n")

        fig.Add_Extrude(
            extrude=1,
            Surface_list=[1, 2, 3, 4, 5],
        )

        geometry_file.write("\n")

        # ------------------------------------------------------------------
        # Physical groups
        # WARNING:
        # These IDs are still hard-coded and may depend on how Add_Extrude()
        # writes the Gmsh extrusion. If the geometry changes, verify them.
        # ------------------------------------------------------------------
        geometry_file.write("// Physical groups\n")

        physical_number = 1

        fig.Add_Physical_Surface("inlet", physical_number, [32])
        physical_number += 1

        fig.Add_Physical_Surface("outlet", physical_number, [24])
        physical_number += 1

        # fig.Add_Physical_Surface("airfoil", physical_number, [73,85])
        # physical_number += 1
        fig.Add_Physical_Surface("airfoil_slat", physical_number, [73])
        physical_number += 1
        fig.Add_Physical_Surface("airfoil_flap", physical_number, [85])
        physical_number += 1

        fig.Add_Physical_Surface("front", physical_number, [37,49,66,78,90])
        physical_number += 1

        fig.Add_Physical_Surface("back", physical_number, [1,2,3,4,5])
        physical_number += 1

        fig.Add_Physical_Surface("Top_bot", physical_number, [20,28])
        physical_number += 1

        fig.Add_Physical_Volume("internal", physical_number, [1, 2, 3, 4, 5])

        geometry_file.write("\n")
        geometry_file.write("Mesh.MshFileVersion = 2.2;\n")
        geometry_file.write("Geometry.Tolerance = 1e-9;\n")

    msh_file = file.with_suffix(".msh")

    subprocess.run(
        [
            "gmsh",
            str(file),
            "-o",
            str(msh_file),
            "-format",
            "msh2",
            "-3",
        ],
        check=True,
    )

def build_2piece_airfoil_mesh_square_flap(file, main, flap, split_info, mesh_parameters, refinement_parameters=None):
    file = Path(file)

    required_keys = [
        "xmin", "xmax", "ymax",
        "BL_t", "alpha",
        "AR_target", "infl_ratio", "infl_ratio_square",
        "Inflation-x", "Inflation-y",
        "boundary_ratio",
    ]

    missing = [key for key in required_keys if key not in mesh_parameters]
    if missing:
        raise KeyError(f"Missing mesh_parameters: {missing}")

    main = np.flip(main, axis=1)
    flap = np.flip(flap, axis=1)
    point_number = 0
    line_number = 1
    curve_number = 1

    with open(file, "w") as geometry_file:
        fig = geom_functions(file=geometry_file)

        geometry_file.write("// Airfoil mesh generated by Python\n\n")

        # ------------------------------------------------------------------
        # Domain points
        # ------------------------------------------------------------------
        geometry_file.write("// Define domain points\n")

        domain = {
            "Top-Left":  [mesh_parameters["xmin"],  mesh_parameters["ymax"]],
            "Top-Right": [mesh_parameters["xmax"],  mesh_parameters["ymax"]],
            "Bot-Right": [mesh_parameters["xmax"], -mesh_parameters["ymax"]],
            "Bot-Left":  [mesh_parameters["xmin"], -mesh_parameters["ymax"]],
        }

        domain_points = {}

        for name, pos in domain.items():
            point_number += 1
            fig.Add_point(point_number, pos[0], pos[1], 1.0)
            domain_points[name] = point_number

        geometry_file.write("\n")

        # ------------------------------------------------------------------
        # Offset curve and rotation
        # ------------------------------------------------------------------   
        ############### MAIN OFFSET CURVE WITH ROUNDED SECTIONS ###############
        offset = 0.012
        if mesh_parameters["BL_t"] >0.012:
            offset = 0.012
        else:
            offset = mesh_parameters["BL_t"]
        
        gap_main_flap = np.min(np.sqrt(np.sum((main[:, :, None] - flap[:, None, :])**2, axis=0)))
        if offset > gap_main_flap/2.0:
            offset = 0.975*(gap_main_flap/2.0)
        
        main_o_1,_ = _compute_offset(main[:,:-split_info['idx_bot_straight_main']], offset)
        main_o_2,_ = _compute_offset(main[:,-split_info['idx_bot_straight_main']:-split_info['idx_top_straight_main']], offset)
        main_o_3,_ = _compute_offset(main[:,-split_info['idx_top_straight_main']:], offset)
        main_o_2 = main_o_2[:,main_o_2[1,:]<main_o_3[1,-1]]
        main_o_3 = main_o_3[:,main_o_3[0,:]>main_o_2[0,0]]
        corner = np.array([main_o_2[0,-1], main_o_3[1,0]]).reshape((-1,1))

        rounded_section_1 = bezier_arc_with_start_tangent(
                                                            main_o_1[:,-2],
                                                            main_o_1[:,-1],
                                                            main_o_2[:,0],
                                                            N=25
                                                            )
        rounded_section_2, _ = arc_circle(
                            _compute_center(main_o_3[:, -1], main_o_1[:, 0]),
                            main_o_3[:, -1],
                            main_o_1[:, 0],
                            N=50
                        )
        main_o = np.hstack((main_o_1, rounded_section_1, main_o_2, corner, main_o_3, rounded_section_2))
        del main_o_1, main_o_2, main_o_3, rounded_section_1, rounded_section_2
        
        main = rotate_curve_around_point(
            main,
            mesh_parameters["alpha"],
            [0.25, 0.0],
        )
        main_o = rotate_curve_around_point(
            main_o,
            mesh_parameters["alpha"],
            [0.25, 0.0],
        )

        ############### FLAP OFFSET CURVE WITH ROUNDED SECTIONS ###############
        flap_o,_ = _compute_offset(flap, offset)
        rounded_section_1, _ = arc_circle(
                            # center,
                            _compute_center(flap[:, -1], flap[:, 0]),
                            flap_o[:, -1],
                            flap_o[:, 0],
                            N=35
                        )
        rounded_section_2, _ = arc_circle(
                            _compute_center(flap[:, -1], flap[:, 0]),
                            flap[:, -1],
                            flap[:, 0],
                            N=35
                        )
        flap_o = np.hstack((flap_o, rounded_section_1))
        flap = np.hstack((flap, rounded_section_2))
        flap = rotate_curve_around_point(
            flap,
            mesh_parameters["alpha"],
            [0.25, 0.0],
        )
        flap_o = rotate_curve_around_point(
            flap_o,
            mesh_parameters["alpha"],
            [0.25, 0.0],
        )
        del rounded_section_1

        # ------------------------------------------------------------------
        # Inflation sections
        # ------------------------------------------------------------------

        ############### INFLATION AROUND THE 3 PIECES ###############

        inflation, _ = inflation_multi_part_airfoil(
                            np.hstack((main_o, flap_o)),      # shape (2, N)
                            gap=0.12,    # adapt to your airfoil coordinate scale
                            n_out=1500,
                            simplify=0.001,
                        )
        inflation = prepare_inflation_line(inflation, main)

        ############### GENERAL INFLATION ###############
        inflation_square = _build_inflation_curve(mesh_parameters)

        # ------------------------------------------------------------------
        # Add points
        # ------------------------------------------------------------------
        main_points, point_number = _add_points(
            fig,
            main,
            point_number,
        )
        main_o_points, point_number = _add_points(
            fig,
            main_o,
            point_number,
        )
        flap_points, point_number = _add_points(
            fig,
            flap,
            point_number,
        )
        flap_o_points, point_number = _add_points(
            fig,
            flap_o,
            point_number,
        )
        inflation_points, point_number = _add_points(
            fig,
            inflation,
            point_number,
        )
        inflation_square_points, point_number = _add_points(
            fig,
            inflation_square,
            point_number,
        )

        geometry_file.write("\n")

        ################ COMPUTE LENGTHS AND SEGMENTATIONS #################
        dx_o = mesh_parameters["AR_target"] * mesh_parameters["BL_t"]

        n_main = int(np.ceil(compute_length(main) / (2.0 * dx_o)))
        if n_main < 75:
            n_main = 75
        n_main_o = int(n_main*0.95)

        n_flap = int(np.ceil(compute_length(flap) / (2.0 * dx_o)))
        if n_flap < 75:
            n_flap = 75
        n_flap_o = int(n_flap*0.95)

        n_inflation = max(50, int(n_main / mesh_parameters["infl_ratio"]))
        n_inflation_square = max(10, int(n_inflation / mesh_parameters["infl_ratio_square"]))

        boundary_dx = compute_length(inflation_square) / n_inflation_square / mesh_parameters["boundary_ratio"]
        boundary_dx = min(boundary_dx, 0.8)

        # ------------------------------------------------------------------
        # Domain lines
        # ------------------------------------------------------------------
        geometry_file.write("// Define domain lines\n")

        domain_lines = {}
        fig.Add_line(line_number, domain_points["Top-Left"], domain_points["Top-Right"])
        domain_lines["Top"] = line_number
        line_number += 1
        fig.Add_line(line_number, domain_points["Top-Right"], domain_points["Bot-Right"])
        domain_lines["Wake"] = line_number
        line_number += 1
        fig.Add_line(line_number, domain_points["Bot-Right"], domain_points["Bot-Left"])
        domain_lines["Bottom"] = line_number
        line_number += 1
        fig.Add_line(line_number, domain_points["Bot-Left"], domain_points["Top-Left"])
        domain_lines["Front"] = line_number
        line_number += 1

        geometry_file.write("\n")

        # ------------------------------------------------------------------
        # Airfoil and internal lines
        # ------------------------------------------------------------------
        geometry_file.write("// Define airfoil and refinement lines\n")

        fig.Add_custom_line(line_number, np.append(main_points,main_points[0]), close=False)
        main_line = line_number
        line_number += 1

        fig.Add_custom_line(line_number, np.append(main_o_points,main_o_points[0]), close=False)
        main_o_line = line_number
        line_number += 1

        fig.Add_custom_line(line_number, np.append(flap_points,flap_points[0]), close=False)
        flap_line = line_number
        line_number += 1

        fig.Add_custom_line(line_number, np.append(flap_o_points,flap_o_points[0]), close=False)
        flap_o_line = line_number
        line_number += 1

        fig.Add_custom_line(line_number, inflation_points, close=True)
        inflation_line = line_number
        line_number += 1

        fig.Add_custom_line(line_number, inflation_square_points, close=True)
        inflation_square_line = line_number
        line_number += 1

        geometry_file.write("\n")

        # ------------------------------------------------------------------
        # Transfinite lines
        # ------------------------------------------------------------------
        geometry_file.write("// Mesh refinement\n")

        fig.Add_Transfinite_Line(
            Lines_list=[main_line],
            Transfinite_number=int(n_main),
            Progression=True,
            Progression_number=1,
        )
        fig.Add_Transfinite_Line(
            Lines_list=[main_o_line],
            Transfinite_number=int(n_main_o),
            Progression=True,
            Progression_number=1,
        )

        fig.Add_Transfinite_Line(
            Lines_list=[flap_line],
            Transfinite_number=int(n_flap),
            Progression=True,
            Progression_number=1,
        )
        fig.Add_Transfinite_Line(
            Lines_list=[flap_o_line],
            Transfinite_number=int(n_flap_o),
            Progression=True,
            Progression_number=1,
        )

        fig.Add_Transfinite_Line(
            Lines_list=[inflation_line],
            Transfinite_number=n_inflation,
            Progression=False,
            Progression_number=1.0,
        )
        fig.Add_Transfinite_Line(
            Lines_list=[inflation_square_line],
            Transfinite_number=n_inflation_square,
            Progression=False,
            Progression_number=1.0,
        )

        fig.Add_Transfinite_Line(
            Lines_list=[domain_lines["Top"], domain_lines["Bottom"]],
            Transfinite_number=max(
                2,
                int((mesh_parameters["xmax"] - mesh_parameters["xmin"]) / boundary_dx),
            ),
            Progression=False,
            Progression_number=1.0,
        )

        fig.Add_Transfinite_Line(
            Lines_list=[domain_lines["Front"], domain_lines["Wake"]],
            Transfinite_number=max(
                2,
                int((2.0 * mesh_parameters["ymax"]) / boundary_dx),
            ),
            Progression=False,
            Progression_number=1.0,
        )

        geometry_file.write("\n")

        # ------------------------------------------------------------------
        # Curve loops
        # ------------------------------------------------------------------
        geometry_file.write("// Define curve loops\n")

        fig.Add_CurveLoop(
            curve_number=curve_number,
            line_list=[
                domain_lines["Top"],
                domain_lines["Wake"],
                domain_lines["Bottom"],
                domain_lines["Front"],
            ],
        )
        boundary_loop = copy.deepcopy(curve_number)
        curve_number += 1

        fig.Add_CurveLoop(
            curve_number=curve_number,
            line_list=[main_line],
        )
        main_loop = copy.deepcopy(curve_number)
        curve_number += 1
        fig.Add_CurveLoop(
            curve_number=curve_number,
            line_list=[main_o_line],
        )
        main_o_loop = copy.deepcopy(curve_number)
        curve_number += 1

        fig.Add_CurveLoop(
            curve_number=curve_number,
            line_list=[flap_line],
        )
        flap_loop = copy.deepcopy(curve_number)
        curve_number += 1
        fig.Add_CurveLoop(
            curve_number=curve_number,
            line_list=[flap_o_line],
        )
        flap_o_loop = copy.deepcopy(curve_number)
        curve_number += 1

        fig.Add_CurveLoop(
            curve_number=curve_number,
            line_list=[inflation_line],
        )
        inflation_loop = curve_number
        curve_number += 1
        fig.Add_CurveLoop(
            curve_number=curve_number,
            line_list=[inflation_square_line],
        )
        inflation_square_loop = curve_number
        curve_number += 1

        geometry_file.write("\n")

        # ------------------------------------------------------------------
        # Surfaces
        # ------------------------------------------------------------------
        geometry_file.write("// Define plane surfaces\n")

        fig.Add_PlaneSurface(
            surface_number=1,
            Loop_number=(boundary_loop, inflation_square_loop),
        )

        fig.Add_PlaneSurface(
            surface_number=2,
            Loop_number=(inflation_square_loop, inflation_loop),
        )

        fig.Add_PlaneSurface(
            surface_number=3,
            Loop_number=(inflation_loop, main_o_loop, flap_o_loop),
        )

        fig.Add_PlaneSurface(
            surface_number=4,
            Loop_number=(main_loop, main_o_loop),
        )

        fig.Add_PlaneSurface(
            surface_number=5,
            Loop_number=(flap_loop, flap_o_loop),
        )

        geometry_file.write("\n")

        # ------------------------------------------------------------------
        # Extrusion
        # ------------------------------------------------------------------
        geometry_file.write("// Extrude\n")

        fig.Add_Extrude(
            extrude=1,
            Surface_list=[1, 2, 3, 4, 5],
        )

        geometry_file.write("\n")

        # ------------------------------------------------------------------
        # Physical groups
        # WARNING:
        # These IDs are still hard-coded and may depend on how Add_Extrude()
        # writes the Gmsh extrusion. If the geometry changes, verify them.
        # ------------------------------------------------------------------
        geometry_file.write("// Physical groups\n")

        physical_number = 1

        fig.Add_Physical_Surface("inlet", physical_number, [32])
        physical_number += 1

        fig.Add_Physical_Surface("outlet", physical_number, [24])
        physical_number += 1

        # fig.Add_Physical_Surface("airfoil", physical_number, [73,85])
        # physical_number += 1
        fig.Add_Physical_Surface("airfoil_main", physical_number, [73])
        physical_number += 1
        fig.Add_Physical_Surface("airfoil_flap", physical_number, [85])
        physical_number += 1

        fig.Add_Physical_Surface("front", physical_number, [37,49,66,78,90])
        physical_number += 1

        fig.Add_Physical_Surface("back", physical_number, [1,2,3,4,5])
        physical_number += 1

        fig.Add_Physical_Surface("Top_bot", physical_number, [20,28])
        physical_number += 1

        fig.Add_Physical_Volume("internal", physical_number, [1, 2, 3, 4, 5])

        geometry_file.write("\n")
        geometry_file.write("Mesh.MshFileVersion = 2.2;\n")
        geometry_file.write("Geometry.Tolerance = 1e-9;\n")

    msh_file = file.with_suffix(".msh")

    subprocess.run(
        [
            "gmsh",
            str(file),
            "-o",
            str(msh_file),
            "-format",
            "msh2",
            "-3",
        ],
        check=True,
    )

def build_3piece_airfoil_mesh_square_flap(file, slat, main, flap, split_info, mesh_parameters, refinement_parameters=None):
    file = Path(file)

    required_keys = [
        "xmin", "xmax", "ymax",
        "BL_t", "alpha",
        "AR_target", "infl_ratio", "infl_ratio_square",
        "Inflation-x", "Inflation-y",
        "boundary_ratio",
    ]

    missing = [key for key in required_keys if key not in mesh_parameters]
    if missing:
        raise KeyError(f"Missing mesh_parameters: {missing}")

    slat = np.flip(slat, axis=1)
    main = np.flip(main, axis=1)
    flap = np.flip(flap, axis=1)
    point_number = 0
    line_number = 1
    curve_number = 1

    with open(file, "w") as geometry_file:
        fig = geom_functions(file=geometry_file)

        geometry_file.write("// Airfoil mesh generated by Python\n\n")

        # ------------------------------------------------------------------
        # Domain points
        # ------------------------------------------------------------------
        geometry_file.write("// Define domain points\n")

        domain = {
            "Top-Left":  [mesh_parameters["xmin"],  mesh_parameters["ymax"]],
            "Top-Right": [mesh_parameters["xmax"],  mesh_parameters["ymax"]],
            "Bot-Right": [mesh_parameters["xmax"], -mesh_parameters["ymax"]],
            "Bot-Left":  [mesh_parameters["xmin"], -mesh_parameters["ymax"]],
        }

        domain_points = {}

        for name, pos in domain.items():
            point_number += 1
            fig.Add_point(point_number, pos[0], pos[1], 1.0)
            domain_points[name] = point_number

        geometry_file.write("\n")

        # ------------------------------------------------------------------
        # Offset curve and rotation
        # ------------------------------------------------------------------
        ############### SLAT OFFSET CURVE WITH ROUNDED SECTIONS ###############
        offset = 0.012
        if mesh_parameters["BL_t"] >0.012:
            offset = 0.012
        else:
            offset = mesh_parameters["BL_t"]
        
        gap_slat_main = np.min(np.sqrt(np.sum((slat[:, :, None] - main[:, None, :])**2, axis=0)))
        if offset > gap_slat_main/2.0:
            offset_1 = 0.975*(gap_slat_main/2.0)
        else:
            offset_1=offset

        back,_ = _compute_offset(slat[:,(-split_info['idx_low_point_slat']-1):], offset_1)
        front,_ = _compute_offset(slat[:,:-split_info['idx_low_point_slat']], offset_1)
        
        rounded_section_1, _ = arc_circle(
                            _compute_center(front[:, -1], back[:, 0]),
                            front[:, -1],
                            back[:, 0],
                            N=100,
                        )
        rounded_section_2, _ = arc_circle(
                            # slat[:,0],
                            _compute_center(back[:, -1], front[:, 0]),
                            back[:, -1],
                            front[:, 0],
                            N=100,
                        )
        slat_o = np.hstack((front, rounded_section_1, back, rounded_section_2))
        del front, back, rounded_section_1, rounded_section_2

        slat = rotate_curve_around_point(
            slat,
            mesh_parameters["alpha"],
            [0.25, 0.0],
        )
        slat_o = rotate_curve_around_point(
            slat_o,
            mesh_parameters["alpha"],
            [0.25, 0.0],
        )        

        ############### MAIN OFFSET CURVE WITH ROUNDED SECTIONS ###############
        gap_main_flap = np.min(np.sqrt(np.sum((main[:, :, None] - flap[:, None, :])**2, axis=0)))
        if offset > gap_main_flap/2.0:
            offset_2 = 0.975*(gap_main_flap/2.0)
        else:
            offset_2=offset
        offset_main = np.min([offset_1, offset_2])
        main_o_1,_ = _compute_offset(main[:,:-split_info['idx_bot_straight_main']], offset_main)
        main_o_2,_ = _compute_offset(main[:,-split_info['idx_bot_straight_main']:-split_info['idx_top_straight_main']], offset_main)
        main_o_3,_ = _compute_offset(main[:,-split_info['idx_top_straight_main']:], offset_main)
        main_o_2 = main_o_2[:,main_o_2[1,:]<main_o_3[1,-1]]
        main_o_3 = main_o_3[:,main_o_3[0,:]>main_o_2[0,0]]
        corner = np.array([main_o_2[0,-1], main_o_3[1,0]]).reshape((-1,1))
        
        rounded_section_1 = bezier_arc_with_start_tangent(
                                                            main_o_1[:,-2],
                                                            main_o_1[:,-1],
                                                            main_o_2[:,0],
                                                            N=25
                                                            )

        rounded_section_2, _ = arc_circle(
                            _compute_center(main_o_3[:, -1], main_o_1[:, 0]),
                            main_o_3[:, -1],
                            main_o_1[:, 0],
                            N=50
                        )
        main_o = np.hstack((main_o_1, rounded_section_1, main_o_2, corner, main_o_3, rounded_section_2))
        del main_o_1, main_o_2, main_o_3, rounded_section_1, rounded_section_2
        
        main = rotate_curve_around_point(
            main,
            mesh_parameters["alpha"],
            [0.25, 0.0],
        )
        main_o = rotate_curve_around_point(
            main_o,
            mesh_parameters["alpha"],
            [0.25, 0.0],
        )

        ############### FLAP OFFSET CURVE WITH ROUNDED SECTIONS ###############
        flap_o,_ = _compute_offset(flap, offset_2)
        rounded_section_1, _ = arc_circle(
                            # center,
                            _compute_center(flap[:, -1], flap[:, 0]),
                            flap_o[:, -1],
                            flap_o[:, 0],
                            N=35
                        )
        rounded_section_2, _ = arc_circle(
                            _compute_center(flap[:, -1], flap[:, 0]),
                            flap[:, -1],
                            flap[:, 0],
                            N=35
                        )
        flap_o = np.hstack((flap_o, rounded_section_1))
        flap = np.hstack((flap, rounded_section_2))
        flap = rotate_curve_around_point(
            flap,
            mesh_parameters["alpha"],
            [0.25, 0.0],
        )
        flap_o = rotate_curve_around_point(
            flap_o,
            mesh_parameters["alpha"],
            [0.25, 0.0],
        )
        del rounded_section_1

        # ------------------------------------------------------------------
        # Inflation sections
        # ------------------------------------------------------------------

        ############### INFLATION AROUND THE 3 PIECES ###############

        inflation, _ = inflation_multi_part_airfoil(
                            np.hstack((slat_o, main_o, flap_o)),      # shape (2, N)
                            gap=0.12,    # adapt to your airfoil coordinate scale
                            n_out=1500,
                            simplify=0.001,
                        )
        inflation = prepare_inflation_line(inflation, main)

        ############### GENERAL INFLATION ###############
        inflation_square = _build_inflation_curve(mesh_parameters)

        # ------------------------------------------------------------------
        # Add points
        # ------------------------------------------------------------------
        slat_points, point_number = _add_points(
            fig,
            slat,
            point_number,
        )
        slat_o_points, point_number = _add_points(
            fig,
            slat_o,
            point_number,
        )
        main_points, point_number = _add_points(
            fig,
            main,
            point_number,
        )
        main_o_points, point_number = _add_points(
            fig,
            main_o,
            point_number,
        )
        flap_points, point_number = _add_points(
            fig,
            flap,
            point_number,
        )
        flap_o_points, point_number = _add_points(
            fig,
            flap_o,
            point_number,
        )
        inflation_points, point_number = _add_points(
            fig,
            inflation,
            point_number,
        )
        inflation_square_points, point_number = _add_points(
            fig,
            inflation_square,
            point_number,
        )

        geometry_file.write("\n")

        ################ COMPUTE LENGTHS AND SEGMENTATIONS #################
        dx_o = mesh_parameters["AR_target"] * mesh_parameters["BL_t"]

        n_slat = int(np.ceil(compute_length(slat) / (2.0 * dx_o)))
        if n_slat < 75:
            n_slat = 75
        n_slat_o = int(n_slat*0.95)

        n_main = int(np.ceil(compute_length(main) / (2.0 * dx_o)))
        if n_main < 75:
            n_main = 75
        n_main_o = int(n_main*0.95)

        n_flap = int(np.ceil(compute_length(flap) / (2.0 * dx_o)))
        if n_flap < 75:
            n_flap = 75
        n_flap_o = int(n_flap*0.95)

        n_inflation = max(50, int(n_main / mesh_parameters["infl_ratio"]))
        n_inflation_square = max(10, int(n_inflation / mesh_parameters["infl_ratio_square"]))

        boundary_dx = compute_length(inflation_square) / n_inflation_square / mesh_parameters["boundary_ratio"]
        boundary_dx = min(boundary_dx, 0.8)

        # ------------------------------------------------------------------
        # Domain lines
        # ------------------------------------------------------------------
        geometry_file.write("// Define domain lines\n")

        domain_lines = {}
        fig.Add_line(line_number, domain_points["Top-Left"], domain_points["Top-Right"])
        domain_lines["Top"] = line_number
        line_number += 1
        fig.Add_line(line_number, domain_points["Top-Right"], domain_points["Bot-Right"])
        domain_lines["Wake"] = line_number
        line_number += 1
        fig.Add_line(line_number, domain_points["Bot-Right"], domain_points["Bot-Left"])
        domain_lines["Bottom"] = line_number
        line_number += 1
        fig.Add_line(line_number, domain_points["Bot-Left"], domain_points["Top-Left"])
        domain_lines["Front"] = line_number
        line_number += 1

        geometry_file.write("\n")

        # ------------------------------------------------------------------
        # Airfoil and internal lines
        # ------------------------------------------------------------------
        geometry_file.write("// Define airfoil and refinement lines\n")

        fig.Add_custom_line(line_number, np.append(slat_points,slat_points[0]), close=False)
        slat_line = line_number
        line_number += 1

        fig.Add_custom_line(line_number, np.append(slat_o_points,slat_o_points[0]), close=False)
        slat_o_line = line_number
        line_number += 1

        fig.Add_custom_line(line_number, np.append(main_points,main_points[0]), close=False)
        main_line = line_number
        line_number += 1

        fig.Add_custom_line(line_number, np.append(main_o_points,main_o_points[0]), close=False)
        main_o_line = line_number
        line_number += 1

        fig.Add_custom_line(line_number, np.append(flap_points,flap_points[0]), close=False)
        flap_line = line_number
        line_number += 1

        fig.Add_custom_line(line_number, np.append(flap_o_points,flap_o_points[0]), close=False)
        flap_o_line = line_number
        line_number += 1

        fig.Add_custom_line(line_number, inflation_points, close=True)
        inflation_line = line_number
        line_number += 1

        fig.Add_custom_line(line_number, inflation_square_points, close=True)
        inflation_square_line = line_number
        line_number += 1

        geometry_file.write("\n")

        # ------------------------------------------------------------------
        # Transfinite lines
        # ------------------------------------------------------------------
        geometry_file.write("// Mesh refinement\n")

        fig.Add_Transfinite_Line(
            Lines_list=[slat_line],
            Transfinite_number=int(n_slat),
            Progression=True,
            Progression_number=1,
        )
        fig.Add_Transfinite_Line(
            Lines_list=[slat_o_line],
            Transfinite_number=int(n_slat_o),
            Progression=True,
            Progression_number=1,
        )

        fig.Add_Transfinite_Line(
            Lines_list=[main_line],
            Transfinite_number=int(n_main),
            Progression=True,
            Progression_number=1,
        )
        fig.Add_Transfinite_Line(
            Lines_list=[main_o_line],
            Transfinite_number=int(n_main_o),
            Progression=True,
            Progression_number=1,
        )

        fig.Add_Transfinite_Line(
            Lines_list=[flap_line],
            Transfinite_number=int(n_flap),
            Progression=True,
            Progression_number=1,
        )
        fig.Add_Transfinite_Line(
            Lines_list=[flap_o_line],
            Transfinite_number=int(n_flap_o),
            Progression=True,
            Progression_number=1,
        )

        fig.Add_Transfinite_Line(
            Lines_list=[inflation_line],
            Transfinite_number=n_inflation,
            Progression=False,
            Progression_number=1.0,
        )
        fig.Add_Transfinite_Line(
            Lines_list=[inflation_square_line],
            Transfinite_number=n_inflation_square,
            Progression=False,
            Progression_number=1.0,
        )

        fig.Add_Transfinite_Line(
            Lines_list=[domain_lines["Top"], domain_lines["Bottom"]],
            Transfinite_number=max(
                2,
                int((mesh_parameters["xmax"] - mesh_parameters["xmin"]) / boundary_dx),
            ),
            Progression=False,
            Progression_number=1.0,
        )

        fig.Add_Transfinite_Line(
            Lines_list=[domain_lines["Front"], domain_lines["Wake"]],
            Transfinite_number=max(
                2,
                int((2.0 * mesh_parameters["ymax"]) / boundary_dx),
            ),
            Progression=False,
            Progression_number=1.0,
        )

        geometry_file.write("\n")

        # ------------------------------------------------------------------
        # Curve loops
        # ------------------------------------------------------------------
        geometry_file.write("// Define curve loops\n")

        fig.Add_CurveLoop(
            curve_number=curve_number,
            line_list=[
                domain_lines["Top"],
                domain_lines["Wake"],
                domain_lines["Bottom"],
                domain_lines["Front"],
            ],
        )
        boundary_loop = copy.deepcopy(curve_number)
        curve_number += 1

        fig.Add_CurveLoop(
            curve_number=curve_number,
            line_list=[slat_line],
        )
        slat_loop = copy.deepcopy(curve_number)
        curve_number += 1
        fig.Add_CurveLoop(
            curve_number=curve_number,
            line_list=[slat_o_line],
        )
        slat_o_loop = copy.deepcopy(curve_number)
        curve_number += 1

        fig.Add_CurveLoop(
            curve_number=curve_number,
            line_list=[main_line],
        )
        main_loop = copy.deepcopy(curve_number)
        curve_number += 1
        fig.Add_CurveLoop(
            curve_number=curve_number,
            line_list=[main_o_line],
        )
        main_o_loop = copy.deepcopy(curve_number)
        curve_number += 1

        fig.Add_CurveLoop(
            curve_number=curve_number,
            line_list=[flap_line],
        )
        flap_loop = copy.deepcopy(curve_number)
        curve_number += 1
        fig.Add_CurveLoop(
            curve_number=curve_number,
            line_list=[flap_o_line],
        )
        flap_o_loop = copy.deepcopy(curve_number)
        curve_number += 1

        fig.Add_CurveLoop(
            curve_number=curve_number,
            line_list=[inflation_line],
        )
        inflation_loop = curve_number
        curve_number += 1
        fig.Add_CurveLoop(
            curve_number=curve_number,
            line_list=[inflation_square_line],
        )
        inflation_square_loop = curve_number
        curve_number += 1

        geometry_file.write("\n")

        

        # ------------------------------------------------------------------
        # Surfaces
        # ------------------------------------------------------------------
        geometry_file.write("// Define plane surfaces\n")

        fig.Add_PlaneSurface(
            surface_number=1,
            Loop_number=(boundary_loop, inflation_square_loop),
        )

        fig.Add_PlaneSurface(
            surface_number=2,
            Loop_number=(inflation_square_loop, inflation_loop),
        )

        fig.Add_PlaneSurface(
            surface_number=3,
            Loop_number=(inflation_loop, slat_o_loop, main_o_loop, flap_o_loop),
        )

        fig.Add_PlaneSurface(
            surface_number=4,
            Loop_number=(slat_loop, slat_o_loop),
        )

        fig.Add_PlaneSurface(
            surface_number=5,
            Loop_number=(main_loop, main_o_loop),
        )

        fig.Add_PlaneSurface(
            surface_number=6,
            Loop_number=(flap_loop, flap_o_loop),
        )

        geometry_file.write("\n")

        # ------------------------------------------------------------------
        # Extrusion
        # ------------------------------------------------------------------
        geometry_file.write("// Extrude\n")

        fig.Add_Extrude(
            extrude=1,
            Surface_list=[1, 2, 3, 4, 5, 6],
        )

        geometry_file.write("\n")

        # ------------------------------------------------------------------
        # Physical groups
        # WARNING:
        # These IDs are still hard-coded and may depend on how Add_Extrude()
        # writes the Gmsh extrusion. If the geometry changes, verify them.
        # ------------------------------------------------------------------
        geometry_file.write("// Physical groups\n")

        physical_number = 1

        fig.Add_Physical_Surface("inlet", physical_number, [34])
        physical_number += 1

        fig.Add_Physical_Surface("outlet", physical_number, [26])
        physical_number += 1

        # fig.Add_Physical_Surface("airfoil", physical_number, [80,92,104])
        # physical_number += 1
        fig.Add_Physical_Surface("airfoil_slat", physical_number, [80])
        physical_number += 1
        fig.Add_Physical_Surface("airfoil_main", physical_number, [92])
        physical_number += 1
        fig.Add_Physical_Surface("airfoil_flap", physical_number, [104])
        physical_number += 1

        fig.Add_Physical_Surface("front", physical_number, [51,39,73,109,97,85])
        physical_number += 1

        fig.Add_Physical_Surface("back", physical_number, [1,2,3,4,5,6])
        physical_number += 1

        fig.Add_Physical_Surface("Top_bot", physical_number, [22,30])
        physical_number += 1

        fig.Add_Physical_Volume("internal", physical_number, [1, 2, 3, 4, 5, 6])

        geometry_file.write("\n")
        geometry_file.write("Mesh.MshFileVersion = 2.2;\n")
        geometry_file.write("Geometry.Tolerance = 1e-9;\n")

    msh_file = file.with_suffix(".msh")

    subprocess.run(
        [
            "gmsh",
            str(file),
            "-o",
            str(msh_file),
            "-format",
            "msh2",
            "-3",
        ],
        check=True,
    )

def build_2piece_airfoil_mesh_round_flap(file, main, flap, split_info, mesh_parameters, refinement_parameters=None):
    file = Path(file)

    required_keys = [
        "xmin", "xmax", "ymax",
        "BL_t", "alpha",
        "AR_target", "infl_ratio", "infl_ratio_square",
        "Inflation-x", "Inflation-y",
        "boundary_ratio",
    ]

    missing = [key for key in required_keys if key not in mesh_parameters]
    if missing:
        raise KeyError(f"Missing mesh_parameters: {missing}")

    main = np.flip(main, axis=1)
    flap = np.flip(flap, axis=1)
    point_number = 0
    line_number = 1
    curve_number = 1

    with open(file, "w") as geometry_file:
        fig = geom_functions(file=geometry_file)

        geometry_file.write("// Airfoil mesh generated by Python\n\n")

        # ------------------------------------------------------------------
        # Domain points
        # ------------------------------------------------------------------
        geometry_file.write("// Define domain points\n")

        domain = {
            "Top-Left":  [mesh_parameters["xmin"],  mesh_parameters["ymax"]],
            "Top-Right": [mesh_parameters["xmax"],  mesh_parameters["ymax"]],
            "Bot-Right": [mesh_parameters["xmax"], -mesh_parameters["ymax"]],
            "Bot-Left":  [mesh_parameters["xmin"], -mesh_parameters["ymax"]],
        }

        domain_points = {}

        for name, pos in domain.items():
            point_number += 1
            fig.Add_point(point_number, pos[0], pos[1], 1.0)
            domain_points[name] = point_number

        geometry_file.write("\n")

        # ------------------------------------------------------------------
        # Offset curve and rotation
        # ------------------------------------------------------------------   
        ############### MAIN OFFSET CURVE WITH ROUNDED SECTIONS ###############
        offset = 0.012
        if mesh_parameters["BL_t"] >0.012:
            offset = 0.012
        else:
            offset = mesh_parameters["BL_t"]
        
        gap_main_flap = np.min(np.sqrt(np.sum((main[:, :, None] - flap[:, None, :])**2, axis=0)))
        if offset > gap_main_flap/2.0:
            offset = 0.975*(gap_main_flap/2.0)
        
        main_o_1,_ = _compute_offset(main[:,:-split_info['idx_bot_point']], offset)
        main_o_2,_ = _compute_offset(main[:,-split_info['idx_bot_point']:], offset)
        
        rounded_section_1, _ = arc_circle(
                            # center,
                            _compute_center(main_o_1[:, -1], main_o_2[:, 0]),
                            main_o_1[:, -1],
                            main_o_2[:, 0],
                            N=25
                        )
        rounded_section_2, _ = arc_circle(
                            # main[:,0],
                            _compute_center(main_o_2[:, -1], main_o_1[:, 0]),
                            main_o_2[:, -1],
                            main_o_1[:, 0],
                            N=50
                        )
        main_o = np.hstack((main_o_1, rounded_section_1, main_o_2, rounded_section_2))
        del main_o_1, main_o_2, rounded_section_1, rounded_section_2
        
        main = rotate_curve_around_point(
            main,
            mesh_parameters["alpha"],
            [0.25, 0.0],
        )
        main_o = rotate_curve_around_point(
            main_o,
            mesh_parameters["alpha"],
            [0.25, 0.0],
        )

        ############### FLAP OFFSET CURVE WITH ROUNDED SECTIONS ###############
        flap_o,_ = _compute_offset(flap, offset)
        rounded_section_1, _ = arc_circle(
                            # center,
                            _compute_center(flap[:, -1], flap[:, 0]),
                            flap_o[:, -1],
                            flap_o[:, 0],
                            N=35
                        )
        rounded_section_2, _ = arc_circle(
                            _compute_center(flap[:, -1], flap[:, 0]),
                            flap[:, -1],
                            flap[:, 0],
                            N=35
                        )
        flap_o = np.hstack((flap_o, rounded_section_1))
        flap = np.hstack((flap, rounded_section_2))
        flap = rotate_curve_around_point(
            flap,
            mesh_parameters["alpha"],
            [0.25, 0.0],
        )
        flap_o = rotate_curve_around_point(
            flap_o,
            mesh_parameters["alpha"],
            [0.25, 0.0],
        )
        del rounded_section_1

        # ------------------------------------------------------------------
        # Inflation sections
        # ------------------------------------------------------------------

        ############### INFLATION AROUND THE 3 PIECES ###############

        inflation, _ = inflation_multi_part_airfoil(
                            np.hstack((main_o, flap_o)),      # shape (2, N)
                            gap=0.12,    # adapt to your airfoil coordinate scale
                            n_out=1500,
                            simplify=0.001,
                        )
        inflation = prepare_inflation_line(inflation, main)

        ############### GENERAL INFLATION ###############
        inflation_square = _build_inflation_curve(mesh_parameters)

        # ------------------------------------------------------------------
        # Add points
        # ------------------------------------------------------------------
        main_points, point_number = _add_points(
            fig,
            main,
            point_number,
        )
        main_o_points, point_number = _add_points(
            fig,
            main_o,
            point_number,
        )
        flap_points, point_number = _add_points(
            fig,
            flap,
            point_number,
        )
        flap_o_points, point_number = _add_points(
            fig,
            flap_o,
            point_number,
        )
        inflation_points, point_number = _add_points(
            fig,
            inflation,
            point_number,
        )
        inflation_square_points, point_number = _add_points(
            fig,
            inflation_square,
            point_number,
        )

        geometry_file.write("\n")

        ################ COMPUTE LENGTHS AND SEGMENTATIONS #################
        dx_o = mesh_parameters["AR_target"] * mesh_parameters["BL_t"]

        n_main = int(np.ceil(compute_length(main) / (2.0 * dx_o)))
        if n_main < 75:
            n_main = 75
        n_main_o = int(n_main*0.95)

        n_flap = int(np.ceil(compute_length(flap) / (2.0 * dx_o)))
        if n_flap < 75:
            n_flap = 75
        n_flap_o = int(n_flap*0.95)

        n_inflation = max(50, int(n_main / mesh_parameters["infl_ratio"]))
        n_inflation_square = max(10, int(n_inflation / mesh_parameters["infl_ratio_square"]))

        boundary_dx = compute_length(inflation_square) / n_inflation_square / mesh_parameters["boundary_ratio"]
        boundary_dx = min(boundary_dx, 0.8)

        # ------------------------------------------------------------------
        # Domain lines
        # ------------------------------------------------------------------
        geometry_file.write("// Define domain lines\n")

        domain_lines = {}
        fig.Add_line(line_number, domain_points["Top-Left"], domain_points["Top-Right"])
        domain_lines["Top"] = line_number
        line_number += 1
        fig.Add_line(line_number, domain_points["Top-Right"], domain_points["Bot-Right"])
        domain_lines["Wake"] = line_number
        line_number += 1
        fig.Add_line(line_number, domain_points["Bot-Right"], domain_points["Bot-Left"])
        domain_lines["Bottom"] = line_number
        line_number += 1
        fig.Add_line(line_number, domain_points["Bot-Left"], domain_points["Top-Left"])
        domain_lines["Front"] = line_number
        line_number += 1

        geometry_file.write("\n")

        # ------------------------------------------------------------------
        # Airfoil and internal lines
        # ------------------------------------------------------------------
        geometry_file.write("// Define airfoil and refinement lines\n")

        fig.Add_custom_line(line_number, np.append(main_points,main_points[0]), close=False)
        main_line = line_number
        line_number += 1

        fig.Add_custom_line(line_number, np.append(main_o_points,main_o_points[0]), close=False)
        main_o_line = line_number
        line_number += 1

        fig.Add_custom_line(line_number, np.append(flap_points,flap_points[0]), close=False)
        flap_line = line_number
        line_number += 1

        fig.Add_custom_line(line_number, np.append(flap_o_points,flap_o_points[0]), close=False)
        flap_o_line = line_number
        line_number += 1

        fig.Add_custom_line(line_number, inflation_points, close=True)
        inflation_line = line_number
        line_number += 1

        fig.Add_custom_line(line_number, inflation_square_points, close=True)
        inflation_square_line = line_number
        line_number += 1

        geometry_file.write("\n")

        # ------------------------------------------------------------------
        # Transfinite lines
        # ------------------------------------------------------------------
        geometry_file.write("// Mesh refinement\n")

        fig.Add_Transfinite_Line(
            Lines_list=[main_line],
            Transfinite_number=int(n_main),
            Progression=True,
            Progression_number=1,
        )
        fig.Add_Transfinite_Line(
            Lines_list=[main_o_line],
            Transfinite_number=int(n_main_o),
            Progression=True,
            Progression_number=1,
        )

        fig.Add_Transfinite_Line(
            Lines_list=[flap_line],
            Transfinite_number=int(n_flap),
            Progression=True,
            Progression_number=1,
        )
        fig.Add_Transfinite_Line(
            Lines_list=[flap_o_line],
            Transfinite_number=int(n_flap_o),
            Progression=True,
            Progression_number=1,
        )

        fig.Add_Transfinite_Line(
            Lines_list=[inflation_line],
            Transfinite_number=n_inflation,
            Progression=False,
            Progression_number=1.0,
        )
        fig.Add_Transfinite_Line(
            Lines_list=[inflation_square_line],
            Transfinite_number=n_inflation_square,
            Progression=False,
            Progression_number=1.0,
        )

        fig.Add_Transfinite_Line(
            Lines_list=[domain_lines["Top"], domain_lines["Bottom"]],
            Transfinite_number=max(
                2,
                int((mesh_parameters["xmax"] - mesh_parameters["xmin"]) / boundary_dx),
            ),
            Progression=False,
            Progression_number=1.0,
        )

        fig.Add_Transfinite_Line(
            Lines_list=[domain_lines["Front"], domain_lines["Wake"]],
            Transfinite_number=max(
                2,
                int((2.0 * mesh_parameters["ymax"]) / boundary_dx),
            ),
            Progression=False,
            Progression_number=1.0,
        )

        geometry_file.write("\n")

        # ------------------------------------------------------------------
        # Curve loops
        # ------------------------------------------------------------------
        geometry_file.write("// Define curve loops\n")

        fig.Add_CurveLoop(
            curve_number=curve_number,
            line_list=[
                domain_lines["Top"],
                domain_lines["Wake"],
                domain_lines["Bottom"],
                domain_lines["Front"],
            ],
        )
        boundary_loop = copy.deepcopy(curve_number)
        curve_number += 1

        fig.Add_CurveLoop(
            curve_number=curve_number,
            line_list=[main_line],
        )
        main_loop = copy.deepcopy(curve_number)
        curve_number += 1
        fig.Add_CurveLoop(
            curve_number=curve_number,
            line_list=[main_o_line],
        )
        main_o_loop = copy.deepcopy(curve_number)
        curve_number += 1

        fig.Add_CurveLoop(
            curve_number=curve_number,
            line_list=[flap_line],
        )
        flap_loop = copy.deepcopy(curve_number)
        curve_number += 1
        fig.Add_CurveLoop(
            curve_number=curve_number,
            line_list=[flap_o_line],
        )
        flap_o_loop = copy.deepcopy(curve_number)
        curve_number += 1

        fig.Add_CurveLoop(
            curve_number=curve_number,
            line_list=[inflation_line],
        )
        inflation_loop = curve_number
        curve_number += 1
        fig.Add_CurveLoop(
            curve_number=curve_number,
            line_list=[inflation_square_line],
        )
        inflation_square_loop = curve_number
        curve_number += 1

        geometry_file.write("\n")

        # ------------------------------------------------------------------
        # Surfaces
        # ------------------------------------------------------------------
        geometry_file.write("// Define plane surfaces\n")

        fig.Add_PlaneSurface(
            surface_number=1,
            Loop_number=(boundary_loop, inflation_square_loop),
        )

        fig.Add_PlaneSurface(
            surface_number=2,
            Loop_number=(inflation_square_loop, inflation_loop),
        )

        fig.Add_PlaneSurface(
            surface_number=3,
            Loop_number=(inflation_loop, main_o_loop, flap_o_loop),
        )

        fig.Add_PlaneSurface(
            surface_number=4,
            Loop_number=(main_loop, main_o_loop),
        )

        fig.Add_PlaneSurface(
            surface_number=5,
            Loop_number=(flap_loop, flap_o_loop),
        )

        geometry_file.write("\n")

        # ------------------------------------------------------------------
        # Extrusion
        # ------------------------------------------------------------------
        geometry_file.write("// Extrude\n")

        fig.Add_Extrude(
            extrude=1,
            Surface_list=[1, 2, 3, 4, 5],
        )

        geometry_file.write("\n")

        # ------------------------------------------------------------------
        # Physical groups
        # WARNING:
        # These IDs are still hard-coded and may depend on how Add_Extrude()
        # writes the Gmsh extrusion. If the geometry changes, verify them.
        # ------------------------------------------------------------------
        geometry_file.write("// Physical groups\n")

        physical_number = 1

        fig.Add_Physical_Surface("inlet", physical_number, [32])
        physical_number += 1

        fig.Add_Physical_Surface("outlet", physical_number, [24])
        physical_number += 1

        # fig.Add_Physical_Surface("airfoil", physical_number, [73,85])
        # physical_number += 1
        fig.Add_Physical_Surface("airfoil_main", physical_number, [73])
        physical_number += 1
        fig.Add_Physical_Surface("airfoil_flap", physical_number, [85])
        physical_number += 1

        fig.Add_Physical_Surface("front", physical_number, [37,49,66,78,90])
        physical_number += 1

        fig.Add_Physical_Surface("back", physical_number, [1,2,3,4,5])
        physical_number += 1

        fig.Add_Physical_Surface("Top_bot", physical_number, [20,28])
        physical_number += 1

        fig.Add_Physical_Volume("internal", physical_number, [1, 2, 3, 4, 5])

        geometry_file.write("\n")
        geometry_file.write("Mesh.MshFileVersion = 2.2;\n")
        geometry_file.write("Geometry.Tolerance = 1e-9;\n")

    msh_file = file.with_suffix(".msh")

    subprocess.run(
        [
            "gmsh",
            str(file),
            "-o",
            str(msh_file),
            "-format",
            "msh2",
            "-3",
        ],
        check=True,
    )

def build_3piece_airfoil_mesh_round_flap(file, slat, main, flap, split_info, mesh_parameters, refinement_parameters=None):
    file = Path(file)

    required_keys = [
        "xmin", "xmax", "ymax",
        "BL_t", "alpha",
        "AR_target", "infl_ratio", "infl_ratio_square",
        "Inflation-x", "Inflation-y",
        "boundary_ratio",
    ]

    missing = [key for key in required_keys if key not in mesh_parameters]
    if missing:
        raise KeyError(f"Missing mesh_parameters: {missing}")

    slat = np.flip(slat, axis=1)
    main = np.flip(main, axis=1)
    flap = np.flip(flap, axis=1)
    point_number = 0
    line_number = 1
    curve_number = 1

    with open(file, "w") as geometry_file:
        fig = geom_functions(file=geometry_file)

        geometry_file.write("// Airfoil mesh generated by Python\n\n")

        # ------------------------------------------------------------------
        # Domain points
        # ------------------------------------------------------------------
        geometry_file.write("// Define domain points\n")

        domain = {
            "Top-Left":  [mesh_parameters["xmin"],  mesh_parameters["ymax"]],
            "Top-Right": [mesh_parameters["xmax"],  mesh_parameters["ymax"]],
            "Bot-Right": [mesh_parameters["xmax"], -mesh_parameters["ymax"]],
            "Bot-Left":  [mesh_parameters["xmin"], -mesh_parameters["ymax"]],
        }

        domain_points = {}

        for name, pos in domain.items():
            point_number += 1
            fig.Add_point(point_number, pos[0], pos[1], 1.0)
            domain_points[name] = point_number

        geometry_file.write("\n")

        # ------------------------------------------------------------------
        # Offset curve and rotation
        # ------------------------------------------------------------------
        ############### SLAT OFFSET CURVE WITH ROUNDED SECTIONS ###############
        offset = 0.012
        if mesh_parameters["BL_t"] >0.012:
            offset = 0.012
        else:
            offset = mesh_parameters["BL_t"]
        
        gap_slat_main = np.min(np.sqrt(np.sum((main[:, :, None] - slat[:, None, :])**2, axis=0)))
        if offset > gap_slat_main/2.0:
            offset_1 = 0.975*(gap_slat_main/2.0)
        else:
            offset_1=offset

        back,_ = _compute_offset(slat[:,(-split_info['idx_low_point_slat']-1):], offset_1)
        front,_ = _compute_offset(slat[:,:-split_info['idx_low_point_slat']], offset_1)
        
        rounded_section_1, _ = arc_circle(
                            _compute_center(front[:, -1], back[:, 0]),
                            front[:, -1],
                            back[:, 0],
                            N=100,
                        )
        rounded_section_2, _ = arc_circle(
                            # slat[:,0],
                            _compute_center(back[:, -1], front[:, 0]),
                            back[:, -1],
                            front[:, 0],
                            N=100,
                        )
        slat_o = np.hstack((front, rounded_section_1, back, rounded_section_2))
        del front, back, rounded_section_1, rounded_section_2

        slat = rotate_curve_around_point(
            slat,
            mesh_parameters["alpha"],
            [0.25, 0.0],
        )
        slat_o = rotate_curve_around_point(
            slat_o,
            mesh_parameters["alpha"],
            [0.25, 0.0],
        )        

        ############### MAIN OFFSET CURVE WITH ROUNDED SECTIONS ###############
        gap_main_flap = np.min(np.sqrt(np.sum((main[:, :, None] - flap[:, None, :])**2, axis=0)))
        if offset > gap_main_flap/2.0:
            offset_2 = 0.975*(gap_main_flap/2.0)
        else:
            offset_2=offset
        offset_main = np.min([offset_1, offset_2])
        main_o_1,_ = _compute_offset(main[:,:-split_info['idx_bot_point']], offset_main)
        main_o_2,_ = _compute_offset(main[:,-split_info['idx_bot_point']:], offset_main)
        
        rounded_section_1, _ = arc_circle(
                            # center,
                            _compute_center(main_o_1[:, -1], main_o_2[:, 0]),
                            main_o_1[:, -1],
                            main_o_2[:, 0],
                            N=25
                        )
        rounded_section_2, _ = arc_circle(
                            # main[:,0],
                            _compute_center(main_o_2[:, -1], main_o_1[:, 0]),
                            main_o_2[:, -1],
                            main_o_1[:, 0],
                            N=50
                        )
        main_o = np.hstack((main_o_1, rounded_section_1, main_o_2, rounded_section_2))
        del main_o_1, main_o_2, rounded_section_1, rounded_section_2
        
        main = rotate_curve_around_point(
            main,
            mesh_parameters["alpha"],
            [0.25, 0.0],
        )
        main_o = rotate_curve_around_point(
            main_o,
            mesh_parameters["alpha"],
            [0.25, 0.0],
        )

        ############### FLAP OFFSET CURVE WITH ROUNDED SECTIONS ###############
        flap_o,_ = _compute_offset(flap, offset_2)
        rounded_section_1, _ = arc_circle(
                            # center,
                            _compute_center(flap[:, -1], flap[:, 0]),
                            flap_o[:, -1],
                            flap_o[:, 0],
                            N=35
                        )
        rounded_section_2, _ = arc_circle(
                            _compute_center(flap[:, -1], flap[:, 0]),
                            flap[:, -1],
                            flap[:, 0],
                            N=35
                        )
        flap_o = np.hstack((flap_o, rounded_section_1))
        flap = np.hstack((flap, rounded_section_2))
        flap = rotate_curve_around_point(
            flap,
            mesh_parameters["alpha"],
            [0.25, 0.0],
        )
        flap_o = rotate_curve_around_point(
            flap_o,
            mesh_parameters["alpha"],
            [0.25, 0.0],
        )
        del rounded_section_1

        # ------------------------------------------------------------------
        # Inflation sections
        # ------------------------------------------------------------------

        ############### INFLATION AROUND THE 3 PIECES ###############

        inflation, _ = inflation_multi_part_airfoil(
                            np.hstack((slat_o, main_o, flap_o)),      # shape (2, N)
                            gap=0.12,    # adapt to your airfoil coordinate scale
                            n_out=1500,
                            simplify=0.001,
                        )
        inflation = prepare_inflation_line(inflation, main)

        ############### GENERAL INFLATION ###############
        inflation_square = _build_inflation_curve(mesh_parameters)

        # ------------------------------------------------------------------
        # Add points
        # ------------------------------------------------------------------
        slat_points, point_number = _add_points(
            fig,
            slat,
            point_number,
        )
        slat_o_points, point_number = _add_points(
            fig,
            slat_o,
            point_number,
        )
        main_points, point_number = _add_points(
            fig,
            main,
            point_number,
        )
        main_o_points, point_number = _add_points(
            fig,
            main_o,
            point_number,
        )
        flap_points, point_number = _add_points(
            fig,
            flap,
            point_number,
        )
        flap_o_points, point_number = _add_points(
            fig,
            flap_o,
            point_number,
        )
        inflation_points, point_number = _add_points(
            fig,
            inflation,
            point_number,
        )
        inflation_square_points, point_number = _add_points(
            fig,
            inflation_square,
            point_number,
        )

        geometry_file.write("\n")

        ################ COMPUTE LENGTHS AND SEGMENTATIONS #################
        dx_o = mesh_parameters["AR_target"] * mesh_parameters["BL_t"]

        n_slat = int(np.ceil(compute_length(slat) / (2.0 * dx_o)))
        if n_slat < 75:
            n_slat = 75
        n_slat_o = int(n_slat*0.95)

        n_main = int(np.ceil(compute_length(main) / (2.0 * dx_o)))
        if n_main < 75:
            n_main = 75
        n_main_o = int(n_main*0.95)

        n_flap = int(np.ceil(compute_length(flap) / (2.0 * dx_o)))
        if n_flap < 75:
            n_flap = 75
        n_flap_o = int(n_flap*0.95)

        n_inflation = max(50, int(n_main / mesh_parameters["infl_ratio"]))
        n_inflation_square = max(10, int(n_inflation / mesh_parameters["infl_ratio_square"]))

        boundary_dx = compute_length(inflation_square) / n_inflation_square / mesh_parameters["boundary_ratio"]
        boundary_dx = min(boundary_dx, 0.8)

        # ------------------------------------------------------------------
        # Domain lines
        # ------------------------------------------------------------------
        geometry_file.write("// Define domain lines\n")

        domain_lines = {}
        fig.Add_line(line_number, domain_points["Top-Left"], domain_points["Top-Right"])
        domain_lines["Top"] = line_number
        line_number += 1
        fig.Add_line(line_number, domain_points["Top-Right"], domain_points["Bot-Right"])
        domain_lines["Wake"] = line_number
        line_number += 1
        fig.Add_line(line_number, domain_points["Bot-Right"], domain_points["Bot-Left"])
        domain_lines["Bottom"] = line_number
        line_number += 1
        fig.Add_line(line_number, domain_points["Bot-Left"], domain_points["Top-Left"])
        domain_lines["Front"] = line_number
        line_number += 1

        geometry_file.write("\n")

        # ------------------------------------------------------------------
        # Airfoil and internal lines
        # ------------------------------------------------------------------
        geometry_file.write("// Define airfoil and refinement lines\n")

        fig.Add_custom_line(line_number, np.append(slat_points,slat_points[0]), close=False)
        slat_line = line_number
        line_number += 1

        fig.Add_custom_line(line_number, np.append(slat_o_points,slat_o_points[0]), close=False)
        slat_o_line = line_number
        line_number += 1

        fig.Add_custom_line(line_number, np.append(main_points,main_points[0]), close=False)
        main_line = line_number
        line_number += 1

        fig.Add_custom_line(line_number, np.append(main_o_points,main_o_points[0]), close=False)
        main_o_line = line_number
        line_number += 1

        fig.Add_custom_line(line_number, np.append(flap_points,flap_points[0]), close=False)
        flap_line = line_number
        line_number += 1

        fig.Add_custom_line(line_number, np.append(flap_o_points,flap_o_points[0]), close=False)
        flap_o_line = line_number
        line_number += 1

        fig.Add_custom_line(line_number, inflation_points, close=True)
        inflation_line = line_number
        line_number += 1

        fig.Add_custom_line(line_number, inflation_square_points, close=True)
        inflation_square_line = line_number
        line_number += 1

        geometry_file.write("\n")

        # ------------------------------------------------------------------
        # Transfinite lines
        # ------------------------------------------------------------------
        geometry_file.write("// Mesh refinement\n")

        fig.Add_Transfinite_Line(
            Lines_list=[slat_line],
            Transfinite_number=int(n_slat),
            Progression=True,
            Progression_number=1,
        )
        fig.Add_Transfinite_Line(
            Lines_list=[slat_o_line],
            Transfinite_number=int(n_slat_o),
            Progression=True,
            Progression_number=1,
        )

        fig.Add_Transfinite_Line(
            Lines_list=[main_line],
            Transfinite_number=int(n_main),
            Progression=True,
            Progression_number=1,
        )
        fig.Add_Transfinite_Line(
            Lines_list=[main_o_line],
            Transfinite_number=int(n_main_o),
            Progression=True,
            Progression_number=1,
        )

        fig.Add_Transfinite_Line(
            Lines_list=[flap_line],
            Transfinite_number=int(n_flap),
            Progression=True,
            Progression_number=1,
        )
        fig.Add_Transfinite_Line(
            Lines_list=[flap_o_line],
            Transfinite_number=int(n_flap_o),
            Progression=True,
            Progression_number=1,
        )

        fig.Add_Transfinite_Line(
            Lines_list=[inflation_line],
            Transfinite_number=n_inflation,
            Progression=False,
            Progression_number=1.0,
        )
        fig.Add_Transfinite_Line(
            Lines_list=[inflation_square_line],
            Transfinite_number=n_inflation_square,
            Progression=False,
            Progression_number=1.0,
        )

        fig.Add_Transfinite_Line(
            Lines_list=[domain_lines["Top"], domain_lines["Bottom"]],
            Transfinite_number=max(
                2,
                int((mesh_parameters["xmax"] - mesh_parameters["xmin"]) / boundary_dx),
            ),
            Progression=False,
            Progression_number=1.0,
        )

        fig.Add_Transfinite_Line(
            Lines_list=[domain_lines["Front"], domain_lines["Wake"]],
            Transfinite_number=max(
                2,
                int((2.0 * mesh_parameters["ymax"]) / boundary_dx),
            ),
            Progression=False,
            Progression_number=1.0,
        )

        geometry_file.write("\n")

        # ------------------------------------------------------------------
        # Curve loops
        # ------------------------------------------------------------------
        geometry_file.write("// Define curve loops\n")

        fig.Add_CurveLoop(
            curve_number=curve_number,
            line_list=[
                domain_lines["Top"],
                domain_lines["Wake"],
                domain_lines["Bottom"],
                domain_lines["Front"],
            ],
        )
        boundary_loop = copy.deepcopy(curve_number)
        curve_number += 1

        fig.Add_CurveLoop(
            curve_number=curve_number,
            line_list=[slat_line],
        )
        slat_loop = copy.deepcopy(curve_number)
        curve_number += 1
        fig.Add_CurveLoop(
            curve_number=curve_number,
            line_list=[slat_o_line],
        )
        slat_o_loop = copy.deepcopy(curve_number)
        curve_number += 1

        fig.Add_CurveLoop(
            curve_number=curve_number,
            line_list=[main_line],
        )
        main_loop = copy.deepcopy(curve_number)
        curve_number += 1
        fig.Add_CurveLoop(
            curve_number=curve_number,
            line_list=[main_o_line],
        )
        main_o_loop = copy.deepcopy(curve_number)
        curve_number += 1

        fig.Add_CurveLoop(
            curve_number=curve_number,
            line_list=[flap_line],
        )
        flap_loop = copy.deepcopy(curve_number)
        curve_number += 1
        fig.Add_CurveLoop(
            curve_number=curve_number,
            line_list=[flap_o_line],
        )
        flap_o_loop = copy.deepcopy(curve_number)
        curve_number += 1

        fig.Add_CurveLoop(
            curve_number=curve_number,
            line_list=[inflation_line],
        )
        inflation_loop = curve_number
        curve_number += 1
        fig.Add_CurveLoop(
            curve_number=curve_number,
            line_list=[inflation_square_line],
        )
        inflation_square_loop = curve_number
        curve_number += 1

        geometry_file.write("\n")

        

        # ------------------------------------------------------------------
        # Surfaces
        # ------------------------------------------------------------------
        geometry_file.write("// Define plane surfaces\n")

        fig.Add_PlaneSurface(
            surface_number=1,
            Loop_number=(boundary_loop, inflation_square_loop),
        )

        fig.Add_PlaneSurface(
            surface_number=2,
            Loop_number=(inflation_square_loop, inflation_loop),
        )

        fig.Add_PlaneSurface(
            surface_number=3,
            Loop_number=(inflation_loop, slat_o_loop, main_o_loop, flap_o_loop),
        )

        fig.Add_PlaneSurface(
            surface_number=4,
            Loop_number=(slat_loop, slat_o_loop),
        )

        fig.Add_PlaneSurface(
            surface_number=5,
            Loop_number=(main_loop, main_o_loop),
        )

        fig.Add_PlaneSurface(
            surface_number=6,
            Loop_number=(flap_loop, flap_o_loop),
        )

        geometry_file.write("\n")

        # ------------------------------------------------------------------
        # Extrusion
        # ------------------------------------------------------------------
        geometry_file.write("// Extrude\n")

        fig.Add_Extrude(
            extrude=1,
            Surface_list=[1, 2, 3, 4, 5, 6],
        )

        geometry_file.write("\n")

        # ------------------------------------------------------------------
        # Physical groups
        # WARNING:
        # These IDs are still hard-coded and may depend on how Add_Extrude()
        # writes the Gmsh extrusion. If the geometry changes, verify them.
        # ------------------------------------------------------------------
        geometry_file.write("// Physical groups\n")

        physical_number = 1

        fig.Add_Physical_Surface("inlet", physical_number, [34])
        physical_number += 1

        fig.Add_Physical_Surface("outlet", physical_number, [26])
        physical_number += 1

        # fig.Add_Physical_Surface("airfoil", physical_number, [80,92,104])
        # physical_number += 1
        fig.Add_Physical_Surface("airfoil_slat", physical_number, [80])
        physical_number += 1
        fig.Add_Physical_Surface("airfoil_main", physical_number, [92])
        physical_number += 1
        fig.Add_Physical_Surface("airfoil_flap", physical_number, [104])
        physical_number += 1

        fig.Add_Physical_Surface("front", physical_number, [51,39,73,109,97,85])
        physical_number += 1

        fig.Add_Physical_Surface("back", physical_number, [1,2,3,4,5,6])
        physical_number += 1

        fig.Add_Physical_Surface("Top_bot", physical_number, [22,30])
        physical_number += 1

        fig.Add_Physical_Volume("internal", physical_number, [1, 2, 3, 4, 5, 6])

        geometry_file.write("\n")
        geometry_file.write("Mesh.MshFileVersion = 2.2;\n")
        geometry_file.write("Geometry.Tolerance = 1e-9;\n")

    msh_file = file.with_suffix(".msh")

    subprocess.run(
        [
            "gmsh",
            str(file),
            "-o",
            str(msh_file),
            "-format",
            "msh2",
            "-3",
        ],
        check=True,
    )

def build_3piece_airfoil_mesh(file, slat, main, flap, splitting_params, split_info, mesh_parameters, refinement_parameters=None):
    if splitting_params['flap_type']=='round':   
        build_3piece_airfoil_mesh_round_flap(file, slat, main, flap, split_info, mesh_parameters, refinement_parameters=refinement_parameters)
    elif splitting_params['flap_type']=='square':  
        build_3piece_airfoil_mesh_square_flap(file, slat, main, flap, split_info, mesh_parameters, refinement_parameters=refinement_parameters)

def build_2piece_airfoil_mesh(file, main, aux, splitting_params, split_info, mesh_parameters, refinement_parameters=None):
    if splitting_params['scenario'] == 'slat':
        build_2piece_airfoil_mesh_slat(file, main, aux, split_info, mesh_parameters, refinement_parameters=refinement_parameters)
    elif splitting_params['scenario'] == 'flap':
        if splitting_params['flap_type']=='round':   
            build_2piece_airfoil_mesh_round_flap(file, main, aux, split_info, mesh_parameters, refinement_parameters=refinement_parameters)
        elif splitting_params['flap_type']=='square':  
            build_2piece_airfoil_mesh_square_flap(file, main, aux, split_info, mesh_parameters, refinement_parameters=refinement_parameters)

def _add_domain_lines(geometry_file, fig, line_number, curve_number, domain_points):
    # ------------------------------------------------------------------
    # Domain lines
    # ------------------------------------------------------------------
    geometry_file.write("// Define domain lines\n")

    domain_lines = {}

    fig.Add_line(line_number, domain_points["Top-Left"], domain_points["Top-Right"])
    domain_lines["Top"] = line_number
    line_number += 1

    fig.Add_line(line_number, domain_points["Top-Right"], domain_points["Bot-Right"])
    domain_lines["Wake"] = line_number
    line_number += 1

    fig.Add_line(line_number, domain_points["Bot-Right"], domain_points["Bot-Left"])
    domain_lines["Bottom"] = line_number
    line_number += 1

    fig.Add_line(line_number, domain_points["Bot-Left"], domain_points["Top-Left"])
    domain_lines["Front"] = line_number
    line_number += 1

    geometry_file.write("\n")

    # ------------------------------------------------------------------
    # Boundary curve loop
    # ------------------------------------------------------------------
    geometry_file.write("// Define outer boundary curve loop\n")

    fig.Add_CurveLoop(
        curve_number=curve_number,
        line_list=[
            domain_lines["Top"],
            domain_lines["Wake"],
            domain_lines["Bottom"],
            domain_lines["Front"],
        ],
    )

    boundary_loop = curve_number
    curve_number += 1

    geometry_file.write("\n")

    return line_number, curve_number, boundary_loop, domain_lines

def _define_domain(geometry_file, mesh_parameters, fig, point_number):
# ------------------------------------------------------------------
    # Domain points
    # ------------------------------------------------------------------
    geometry_file.write("// Define domain points\n")

    domain = {
        "Top-Left":  [mesh_parameters["xmin"],  mesh_parameters["ymax"]],
        "Top-Right": [mesh_parameters["xmax"],  mesh_parameters["ymax"]],
        "Bot-Right": [mesh_parameters["xmax"], -mesh_parameters["ymax"]],
        "Bot-Left":  [mesh_parameters["xmin"], -mesh_parameters["ymax"]],
    }

    domain_points = {}

    for name, pos in domain.items():
        point_number += 1
        fig.Add_point(point_number, pos[0], pos[1], 1.0)
        domain_points[name] = point_number

    geometry_file.write("\n")

    return point_number, domain_points

def _build_structured_curve(mesh_parameters: dict) -> np.ndarray:
    front_displacement = mesh_parameters.get('front_displacement',-0.25)
    Te_top = np.array([1, mesh_parameters['Inflation-y']]).reshape((-1,1))
    Le_top = np.array([front_displacement, mesh_parameters['Inflation-y']]).reshape((-1,1))
    front_points, _ = arc_circle(
        [0.0, 0.0],
        [front_displacement, mesh_parameters["Inflation-y"]],
        [front_displacement, -mesh_parameters["Inflation-y"]],
    )
    Le_bot = np.array([front_displacement, -mesh_parameters['Inflation-y']]).reshape((-1,1))
    Te_bot = np.array([1, -mesh_parameters['Inflation-y']]).reshape((-1,1))
    Wake_bot = np.array([1+mesh_parameters['Inflation-x'], -mesh_parameters['Inflation-y']]).reshape((-1,1))
    Wake_mid = np.array([1+mesh_parameters['Inflation-x'], 0]).reshape((-1,1))
    Wake_top = np.array([1+mesh_parameters['Inflation-x'], mesh_parameters['Inflation-y']]).reshape((-1,1))

    infl = np.hstack((Te_top, Le_top,front_points, Le_bot, Te_bot, Wake_bot, Wake_mid, Wake_top))

    return infl

def build_single_airfoil_structured(file, airfoil, mesh_parameters):

    airfoil = _validate_points(airfoil)
    file = Path(file)

    required_keys = ['xmax', 'xmin', 'ymax', 'alpha', 'Inflation-y', 'Inflation-x', 'airfoil_divisions', 'wake_divisions', 'vertical_divisions', 'front_divisions', 'horizontal_boundary_divisions', 'vertical_boundary_divisions']

    missing = [key for key in required_keys if key not in mesh_parameters]
    if missing:
        raise KeyError(f"Missing mesh_parameters: {missing}")

    point_number = 0
    line_number = 1
    curve_number = 1

    with open(file, "w") as geometry_file:
        fig = geom_functions(file=geometry_file)

        geometry_file.write("// Airfoil mesh generated by Python\n\n")
        point_number, domain_points = _define_domain(geometry_file, mesh_parameters, fig, point_number)

        # Add airfoil points
        geometry_file.write("// Define airfoil points\n")
        idx_airfoil_LE = np.argmin(airfoil[0])

        airfoil = rotate_curve_around_point(
            airfoil,
            mesh_parameters["alpha"],
            [0.25, 0.0],
        )

        airfoil_points, point_number = _add_points(
            fig,
            airfoil,
            point_number,
        )
        airfoil_points = np.hstack((airfoil_points,airfoil_points[0]))

        point_airfoil_TE  = copy.deepcopy(airfoil_points[0])
        # point_airfoil_TE_low = copy.deepcopy(airfoil_points[-1])
        point_airfoil_LE  = copy.deepcopy(airfoil_points[idx_airfoil_LE])

        # Add airfoil points
        geometry_file.write("// Define inflation points\n")
        inflation = _build_structured_curve(mesh_parameters)
        inflation = rotate_curve_around_point(
            inflation,
            mesh_parameters["alpha"],
            [0.25, 0.0],
        )

        inflation_points, point_number = _add_points(
            fig,
            inflation,
            point_number,
        )

        point_Te_top, point_Le_top, point_Le_bot, point_Te_bot, point_Wake_bot, point_Wake_mid, point_Wake_top = inflation_points[[0,1,-5,-4,-3,-2,-1]]

        ################################## LINES ##################################

        # Define domain lines
        line_number, curve_number, boundary_loop, domain_lines = _add_domain_lines(geometry_file, fig, line_number, curve_number, domain_points)

        # Airfoil lines
        geometry_file.write("// Define airfoil and refinement lines\n")

        fig.Add_custom_line(line_number, airfoil_points[:idx_airfoil_LE+1], close=False)
        airfoil_up_line = copy.deepcopy(line_number)
        line_number += 1
        fig.Add_custom_line(line_number, airfoil_points[idx_airfoil_LE:], close=False)
        airfoil_low_line = copy.deepcopy(line_number)
        line_number += 1

        # Top of airfoil lines
        fig.Add_custom_line(line_number, [point_airfoil_LE,point_Le_top], close=False)
        airfoil_dom_top_front = copy.deepcopy(line_number)
        line_number += 1
        fig.Add_custom_line(line_number, [point_Le_top,point_Te_top], close=False)
        airfoil_dom_top_up = copy.deepcopy(line_number)
        line_number += 1
        fig.Add_custom_line(line_number, [point_Te_top, point_airfoil_TE], close=False)
        airfoil_dom_top_back = copy.deepcopy(line_number)
        line_number += 1

        # Bottom of airfoil lines
        fig.Add_custom_line(line_number, [point_airfoil_TE,point_Te_bot], close=False)
        airfoil_dom_bot_back = copy.deepcopy(line_number)
        line_number += 1
        fig.Add_custom_line(line_number, [point_Te_bot,point_Le_bot], close=False)
        airfoil_dom_bot_low = copy.deepcopy(line_number)
        line_number += 1
        fig.Add_custom_line(line_number, [point_Le_bot, point_airfoil_LE], close=False)
        airfoil_dom_bot_front = copy.deepcopy(line_number)
        line_number += 1

        # Front Inflation
        front_curve_points = [point_Le_top] + list(inflation_points[2:-5]) + [point_Le_bot]
        fig.Add_custom_line(line_number, front_curve_points, close=False)
        front_semicircle = copy.deepcopy(line_number)
        line_number += 1

        # Wake
        fig.Add_custom_line(line_number, [point_Te_bot, point_Wake_bot], close=False)
        wake_bot_low = copy.deepcopy(line_number)
        line_number += 1
        fig.Add_custom_line(line_number, [point_Wake_bot, point_Wake_mid], close=False)
        wake_ver_low = copy.deepcopy(line_number)
        line_number += 1
        fig.Add_custom_line(line_number, [point_Wake_mid, point_Wake_top], close=False)
        wake_ver_up = copy.deepcopy(line_number)
        line_number += 1
        fig.Add_custom_line(line_number, [point_Wake_top, point_Te_top], close=False)
        wake_top_up = copy.deepcopy(line_number)
        line_number += 1
        fig.Add_custom_line(line_number, [point_airfoil_TE, point_Wake_mid], close=False)
        wake_mid = copy.deepcopy(line_number)
        line_number += 1
        
        # ------------------------------------------------------------------
        # Transfinite lines
        # ------------------------------------------------------------------
        geometry_file.write("// Mesh refinement\n")

        airfoil_progression  = mesh_parameters.get('airfoil_progression',0.01)
        vertical_progression = mesh_parameters.get('vertical_progression',0.025)
        wake_progression     = mesh_parameters.get('wake_progression',0.01)

        fig.Add_Transfinite_Line(
            Lines_list=[airfoil_up_line],
            Transfinite_number=int(mesh_parameters['airfoil_divisions']),
            Progression=True,
            Progression_number=1-airfoil_progression,
        )
        fig.Add_Transfinite_Line(
            Lines_list=[airfoil_dom_top_up],
            Transfinite_number=int(mesh_parameters['airfoil_divisions']),
            Progression=True,
            Progression_number=1+airfoil_progression,
        )

        fig.Add_Transfinite_Line(
            Lines_list=[airfoil_low_line],
            Transfinite_number=int(mesh_parameters['airfoil_divisions']),
            Progression=True,
            Progression_number=1+airfoil_progression,
        )
        fig.Add_Transfinite_Line(
            Lines_list=[airfoil_dom_bot_low],
            Transfinite_number=int(mesh_parameters['airfoil_divisions']),
            Progression=True,
            Progression_number=1-airfoil_progression,
        )

        fig.Add_Transfinite_Line(
            Lines_list=[airfoil_dom_top_front],
            Transfinite_number=int(mesh_parameters['vertical_divisions']),
            Progression=True,
            Progression_number=1 + vertical_progression,
        )
        fig.Add_Transfinite_Line(
            Lines_list=[airfoil_dom_top_back],
            Transfinite_number=int(mesh_parameters['vertical_divisions']),
            Progression=True,
            Progression_number=1 - vertical_progression,
        )
        fig.Add_Transfinite_Line(
            Lines_list=[wake_ver_up],
            Transfinite_number=int(mesh_parameters['vertical_divisions']),
            Progression=True,
            Progression_number=1 + vertical_progression,
        )

        fig.Add_Transfinite_Line(
            Lines_list=[airfoil_dom_bot_front],
            Transfinite_number=int(mesh_parameters['vertical_divisions']),
            Progression=True,
            Progression_number=1 - vertical_progression,
        )
        fig.Add_Transfinite_Line(
            Lines_list=[airfoil_dom_bot_back],
            Transfinite_number=int(mesh_parameters['vertical_divisions']),
            Progression=True,
            Progression_number=1 + vertical_progression,
        )
        fig.Add_Transfinite_Line(
            Lines_list=[wake_ver_low],
            Transfinite_number=int(mesh_parameters['vertical_divisions']),
            Progression=True,
            Progression_number=1 - vertical_progression,
        )

        fig.Add_Transfinite_Line(
            Lines_list=[wake_top_up],
            Transfinite_number=int(mesh_parameters['wake_divisions']),
            Progression=True,
            Progression_number=1 - wake_progression,
        )
        fig.Add_Transfinite_Line(
            Lines_list=[wake_bot_low],
            Transfinite_number=int(mesh_parameters['wake_divisions']),
            Progression=True,
            Progression_number=1 + wake_progression,
        )
        fig.Add_Transfinite_Line(
            Lines_list=[wake_bot_low],
            Transfinite_number=int(mesh_parameters['wake_divisions']),
            Progression=True,
            Progression_number=1 + wake_progression,
        )
        fig.Add_Transfinite_Line(
            Lines_list=[wake_mid],
            Transfinite_number=int(mesh_parameters['wake_divisions']),
            Progression=True,
            Progression_number=1 + wake_progression,
        )

        fig.Add_Transfinite_Line(
            Lines_list=[front_semicircle],
            Transfinite_number=int(mesh_parameters['front_divisions']),
            Progression=False,
        )

        fig.Add_Transfinite_Line(
            Lines_list=[domain_lines["Top"], domain_lines["Bottom"]],
            Transfinite_number=max(
                2,
                int(mesh_parameters['horizontal_boundary_divisions']),
            ),
            Progression=False,
            Progression_number=1.0,
        )

        fig.Add_Transfinite_Line(
            Lines_list=[domain_lines["Front"], domain_lines["Wake"]],
            Transfinite_number=max(
                2,
                int(mesh_parameters['vertical_boundary_divisions']),
            ),
            Progression=False,
            Progression_number=1.0,
        )

        geometry_file.write("\n")

        # ------------------------------------------------------------------
        # Curve loops
        # ------------------------------------------------------------------
        geometry_file.write("// Define curve loops\n")

        fig.Add_CurveLoop(
            curve_number=curve_number,
            line_list=[airfoil_up_line, airfoil_dom_top_front, airfoil_dom_top_up, airfoil_dom_top_back],
        )
        top_airfoil_loop = curve_number
        curve_number += 1

        fig.Add_CurveLoop(
            curve_number=curve_number,
            line_list=[airfoil_low_line, airfoil_dom_bot_back, airfoil_dom_bot_low, airfoil_dom_bot_front],
        )
        bot_airfoil_loop = curve_number
        curve_number += 1

        fig.Add_CurveLoop(
            curve_number=curve_number,
            line_list=[airfoil_dom_top_front, front_semicircle, airfoil_dom_bot_front],
        )
        front_semicircle_loop = curve_number
        curve_number += 1

        fig.Add_CurveLoop(
            curve_number=curve_number,
            line_list=[airfoil_dom_top_back, wake_mid, wake_ver_up, wake_top_up],
        )
        wake_top_loop = curve_number
        curve_number += 1
        fig.Add_CurveLoop(
            curve_number=curve_number,
            line_list=[airfoil_dom_bot_back, wake_bot_low, wake_ver_low, -wake_mid],
        )
        wake_bot_loop = curve_number
        curve_number += 1

        fig.Add_CurveLoop(
            curve_number=curve_number,
            line_list=[front_semicircle, -airfoil_dom_bot_low, wake_bot_low, wake_ver_low, wake_ver_up, wake_top_up, -airfoil_dom_top_up],
        )
        external_loop = curve_number
        curve_number += 1

        geometry_file.write("\n")

        # ------------------------------------------------------------------
        # Surfaces
        # ------------------------------------------------------------------
        geometry_file.write("// Define plane surfaces\n")

        fig.Add_PlaneSurface(
            surface_number=1,
            Loop_number=(top_airfoil_loop),
            Recombine=True,
            Transfinite=True,
        )

        fig.Add_PlaneSurface(
            surface_number=2,
            Loop_number=(bot_airfoil_loop),
            Recombine=True,
            Transfinite=True,
        )

        fig.Add_PlaneSurface(
            surface_number=3,
            Loop_number=(front_semicircle_loop),
            Recombine=True,
            Transfinite=True,
        )

        fig.Add_PlaneSurface(
            surface_number=4,
            Loop_number=(wake_top_loop),
            Recombine=True,
            Transfinite=True,
        )
        fig.Add_PlaneSurface(
            surface_number=5,
            Loop_number=(wake_bot_loop),
            Recombine=True,
            Transfinite=True,
        )

        fig.Add_PlaneSurface(
            surface_number=6,
            Loop_number=(boundary_loop, external_loop),
        )

        geometry_file.write("\n")

        # ------------------------------------------------------------------
        # Extrusion
        # ------------------------------------------------------------------
        geometry_file.write("// Extrude\n")

        fig.Add_Extrude(
            extrude=1,
            Surface_list=[1, 2, 3, 4, 5, 6],
        )

        geometry_file.write("// Physical groups\n")

        physical_number = 1

        fig.Add_Physical_Surface("inlet", physical_number, [151])
        physical_number += 1

        fig.Add_Physical_Surface("outlet", physical_number, [143])
        physical_number += 1

        fig.Add_Physical_Surface("airfoil", physical_number, [49, 27])
        physical_number += 1

        fig.Add_Physical_Surface("front", physical_number, [180,79,40,101,62,123])
        physical_number += 1

        fig.Add_Physical_Surface("back", physical_number, [1,2,3,4,5,6])
        physical_number += 1

        fig.Add_Physical_Surface("Top_bot", physical_number, [139, 147])
        physical_number += 1

        fig.Add_Physical_Volume("internal", physical_number, [1, 2, 3, 4, 5, 6])

        geometry_file.write("\n")

        geometry_file.write("\n")
        geometry_file.write("Mesh.MshFileVersion = 2.2;\n")
        geometry_file.write("Geometry.Tolerance = 1e-9;\n")

    msh_file = file.with_suffix(".msh")

    subprocess.run(
        [
            "gmsh",
            str(file),
            "-o",
            str(msh_file),
            "-format",
            "msh2",
            "-3",
        ],
        check=True,
    )

def find_intersection(origin, vector, target, tol=1e-6):
    """
    Find the intersection between a ray and a target polyline.

    The ray is defined as:

        r(t) = origin + t * vector,   t >= 0

    The target is a polyline defined by ordered points:

        target[:, i] -> target[:, i+1]

    Parameters
    ----------
    origin : array_like, shape (2,)
        Ray origin [x, y].

    vector : array_like, shape (2,)
        Ray direction vector [vx, vy]. It does not need to be normalized.

    target : ndarray
        Target polyline. Accepted shapes:
        - (2, N): target[0, :] = x, target[1, :] = y
        - (N, 2): target[:, 0] = x, target[:, 1] = y

    tol : float
        Numerical tolerance.

    Returns
    -------
    intersection : ndarray, shape (2,)
        Closest intersection point along the positive ray.

    idx_segment : int
        Index i of the intersected segment target[:, i] -> target[:, i+1].

    t_ray : float
        Ray parameter.

    u_segment : float
        Segment parameter. The intersection satisfies:

            point = target_i + u_segment * (target_{i+1} - target_i)

        with 0 <= u_segment <= 1.

    Notes
    -----
    If no intersection is found, returns:

        None, None, None, None
    """

    origin = np.asarray(origin, dtype=float).reshape(2)
    vector = np.asarray(vector, dtype=float).reshape(2)

    if np.linalg.norm(vector) < tol:
        raise ValueError("The ray direction vector has near-zero norm.")

    target = np.asarray(target, dtype=float)

    if target.ndim != 2:
        raise ValueError("target must be a 2D array with shape (2, N) or (N, 2).")

    if target.shape[0] == 2:
        pts = target.T
    elif target.shape[1] == 2:
        pts = target
    else:
        raise ValueError("target must have shape (2, N) or (N, 2).")

    if pts.shape[0] < 2:
        raise ValueError("target must contain at least two points.")

    best_t = np.inf
    best_point = None
    best_idx = None
    best_u = None

    px, py = origin
    rx, ry = vector

    for i in range(pts.shape[0] - 1):

        q = pts[i]
        q_next = pts[i + 1]
        s = q_next - q

        qx, qy = q
        sx, sy = s

        # Solve:
        # origin + t * vector = q + u * s
        #
        # Equivalent 2x2 system:
        # [rx, -sx] [t] = [qx - px]
        # [ry, -sy] [u]   [qy - py]

        det = -rx * sy + ry * sx

        if abs(det) < tol:
            # Ray and segment are parallel or nearly parallel.
            continue

        dx = qx - px
        dy = qy - py

        t = (-sy * dx + sx * dy) / det
        u = (-ry * dx + rx * dy) / det

        if t >= -tol and u >= -tol and u <= 1.0 + tol:
            # Clamp small numerical deviations.
            t = max(0.0, t)
            u = min(1.0, max(0.0, u))

            if t < best_t:
                best_t = t
                best_u = u
                best_idx = i
                best_point = origin + t * vector

    if best_point is None:
        return None, None, None, None

    return best_idx

def build_single_airfoil_o_structured(file, airfoil, mesh_parameters):

    airfoil = _validate_points(airfoil)
    file = Path(file)

    required_keys = ['xmax', 'xmin', 'ymax', 'alpha', 'Inflation', 'airfoil_divisions', 'wake_divisions', 'vertical_divisions', 'horizontal_boundary_divisions', 'vertical_boundary_divisions']

    missing = [key for key in required_keys if key not in mesh_parameters]
    if missing:
        raise KeyError(f"Missing mesh_parameters: {missing}")

    point_number = 0
    line_number = 1
    curve_number = 1

    LE_cut_x = mesh_parameters.get('LE_cut_x', 0.03)

    with open(file, "w") as geometry_file:
        fig = geom_functions(file=geometry_file)

        geometry_file.write("// Airfoil mesh generated by Python\n\n")
        point_number, domain_points = _define_domain(geometry_file, mesh_parameters, fig, point_number)

        # Add airfoil points
        geometry_file.write("// Define airfoil points\n")
        airfoil_inflation,_ = _compute_offset(airfoil, mesh_parameters['Inflation'])

        valid = airfoil_inflation[0]<np.max(airfoil[0])
        airfoil_inflation = airfoil_inflation[:,valid]
        idx_airfoil_inflation_LE = np.argmin(airfoil_inflation[0])
        airfoil_inflation_top = airfoil_inflation[:,:idx_airfoil_inflation_LE]
        airfoil_inflation_bot = airfoil_inflation[:,idx_airfoil_inflation_LE:]

        increase, decrease = np.array([False]), np.array([False])
        while not increase.all() or not decrease.all():
            idx_airfoil_inflation_LE = np.argmin(airfoil_inflation[0])
            airfoil_inflation_top = airfoil_inflation[:,:idx_airfoil_inflation_LE]
            airfoil_inflation_bot = airfoil_inflation[:,idx_airfoil_inflation_LE:]
            increase = np.hstack(([True],airfoil_inflation_top[0,1:]<airfoil_inflation_top[0,:-1]))
            airfoil_inflation_top = airfoil_inflation_top[:,increase]
            decrease = np.hstack(([True],airfoil_inflation_bot[0,1:]>airfoil_inflation_bot[0,:-1]))
            airfoil_inflation_bot = airfoil_inflation_bot[:,decrease]
            airfoil_inflation = np.hstack((airfoil_inflation_top, airfoil_inflation_bot))

        front = np.array([np.max(airfoil[0]),airfoil_inflation[1,0]]).reshape((-1,1))
        back = np.array([np.max(airfoil[0]),airfoil_inflation[1,-1]]).reshape((-1,1))
        airfoil_inflation = np.hstack((front, airfoil_inflation, back))
        
        idx_airfoil_LE = np.argmin(airfoil[0])
        idx_airfoil_inflation_LE = np.argmin(airfoil_inflation[0])

        ## Find the new LE enforcement region
        idx_cut_airfoil_top = np.argmin(np.abs(airfoil[0,:idx_airfoil_LE] - LE_cut_x))
        tangent = airfoil[:,idx_cut_airfoil_top+1]-airfoil[:,idx_cut_airfoil_top-1]
        tangent = tangent/np.linalg.norm(tangent)
        normal = np.array(rotate_vector_90_clockwise(tangent.reshape((-1,1))))
        idx_cut_airfoil_inflation_top = find_intersection(airfoil[:,idx_cut_airfoil_top], normal, airfoil_inflation, tol=1e-6)
        
        idx_cut_airfoil_bot = np.argmin(np.abs(airfoil[0,idx_airfoil_LE:] - LE_cut_x))+idx_airfoil_LE
        tangent = airfoil[:,idx_cut_airfoil_bot+1]-airfoil[:,idx_cut_airfoil_bot-1]
        tangent = tangent/np.linalg.norm(tangent)
        normal = np.array(rotate_vector_90_clockwise(tangent.reshape((-1,1))))
        idx_cut_airfoil_inflation_bot = find_intersection(airfoil[:,idx_cut_airfoil_bot], normal, airfoil_inflation, tol=1e-6)

        airfoil = rotate_curve_around_point(
            airfoil,
            mesh_parameters["alpha"],
            [0.25, 0.0],
        )

        airfoil_inflation = rotate_curve_around_point(
            airfoil_inflation,
            mesh_parameters["alpha"],
            [0.25, 0.0],
        )

        Wake_bot = np.array([1+mesh_parameters['Inflation'], -mesh_parameters['Inflation']]).reshape((-1,1))
        Wake_mid = np.array([1+mesh_parameters['Inflation'], 0]).reshape((-1,1))
        Wake_top = np.array([1+mesh_parameters['Inflation'], mesh_parameters['Inflation']]).reshape((-1,1))

        R = np.array([[np.cos(np.deg2rad(mesh_parameters['alpha'])), np.sin(np.deg2rad(mesh_parameters['alpha']))],
                      [-np.sin(np.deg2rad(mesh_parameters['alpha'])), np.cos(np.deg2rad(mesh_parameters['alpha']))]])

        Wake_bot = np.matmul(R,Wake_bot)
        Wake_mid = np.matmul(R,Wake_mid)
        Wake_top = np.matmul(R,Wake_top)

        airfoil_points, point_number = _add_points(
            fig,
            airfoil,
            point_number,
        )
        airfoil_points = np.hstack((airfoil_points,airfoil_points[0]))

        airfoil_inflation_points, point_number = _add_points(
            fig,
            airfoil_inflation,
            point_number,
        )

        wake_bot_point, point_number = _add_points(
            fig,
            Wake_bot,
            point_number,
        )
        wake_mid_point, point_number = _add_points(
            fig,
            Wake_mid,
            point_number,
        )
        wake_top_point, point_number = _add_points(
            fig,
            Wake_top,
            point_number,
        )
        wake_bot_point = wake_bot_point[0]
        wake_mid_point = wake_mid_point[0]
        wake_top_point = wake_top_point[0]

        ################################## LINES ##################################

        # Define domain lines
        line_number, curve_number, boundary_loop, domain_lines = _add_domain_lines(geometry_file, fig, line_number, curve_number, domain_points)

        # Airfoil lines
        geometry_file.write("// Define airfoil and refinement lines\n")

        fig.Add_custom_line(line_number, airfoil_points[:idx_cut_airfoil_top+1], close=False)
        airfoil_up_line_back = copy.deepcopy(line_number)
        line_number += 1
        fig.Add_custom_line(line_number, airfoil_points[idx_cut_airfoil_top:idx_airfoil_LE+1], close=False)
        airfoil_up_line_front = copy.deepcopy(line_number)
        line_number += 1
        fig.Add_custom_line(line_number, airfoil_points[idx_airfoil_LE:idx_cut_airfoil_bot+1], close=False)
        airfoil_low_line_front = copy.deepcopy(line_number)
        line_number += 1
        fig.Add_custom_line(line_number, airfoil_points[idx_cut_airfoil_bot:], close=False)
        airfoil_low_line_back = copy.deepcopy(line_number)
        line_number += 1

        fig.Add_custom_line(line_number, airfoil_inflation_points[:idx_cut_airfoil_inflation_top+1], close=False)
        airfoil_inflation_up_line_back = copy.deepcopy(line_number)
        line_number += 1
        fig.Add_custom_line(line_number, airfoil_inflation_points[idx_cut_airfoil_inflation_top:idx_airfoil_inflation_LE+1], close=False)
        airfoil_inflation_up_line_front = copy.deepcopy(line_number)
        line_number += 1
        fig.Add_custom_line(line_number, airfoil_inflation_points[idx_airfoil_inflation_LE:idx_cut_airfoil_inflation_bot+1], close=False)
        airfoil_inflation_low_line_front = copy.deepcopy(line_number)
        line_number += 1
        fig.Add_custom_line(line_number, airfoil_inflation_points[idx_cut_airfoil_inflation_bot:], close=False)
        airfoil_inflation_low_line_back = copy.deepcopy(line_number)
        line_number += 1

        fig.Add_custom_line(line_number, [airfoil_points[idx_airfoil_LE], airfoil_inflation_points[idx_airfoil_inflation_LE]], close=False)
        front_horizontal_line = copy.deepcopy(line_number)
        line_number += 1
        fig.Add_custom_line(line_number, [airfoil_points[idx_cut_airfoil_top], airfoil_inflation_points[idx_cut_airfoil_inflation_top]], close=False)
        front_top_line = copy.deepcopy(line_number)
        line_number += 1
        fig.Add_custom_line(line_number, [airfoil_points[idx_cut_airfoil_bot], airfoil_inflation_points[idx_cut_airfoil_inflation_bot]], close=False)
        front_bot_line = copy.deepcopy(line_number)
        line_number += 1

        fig.Add_custom_line(line_number, [airfoil_points[0], airfoil_inflation_points[0]], close=False)
        wake_front_top_vertical = copy.deepcopy(line_number)
        line_number += 1
        fig.Add_custom_line(line_number, [airfoil_inflation_points[0], wake_top_point], close=False)
        wake_top_horizontal = copy.deepcopy(line_number)
        line_number += 1
        fig.Add_custom_line(line_number, [wake_top_point, wake_mid_point], close=False)
        wake_back_top_vertical = copy.deepcopy(line_number)
        line_number += 1

        fig.Add_custom_line(line_number, [wake_mid_point, wake_bot_point], close=False)
        wake_back_bot_vertical = copy.deepcopy(line_number)
        line_number += 1
        fig.Add_custom_line(line_number, [wake_bot_point, airfoil_inflation_points[-1]], close=False)
        wake_bot_horizontal = copy.deepcopy(line_number)
        line_number += 1
        fig.Add_custom_line(line_number, [airfoil_inflation_points[-1], airfoil_points[0]], close=False)
        wake_front_bot_vertical = copy.deepcopy(line_number)
        line_number += 1

        fig.Add_custom_line(line_number, [airfoil_points[0], wake_mid_point], close=False)
        wake_mid_horizontal = copy.deepcopy(line_number)
        line_number += 1

        # ------------------------------------------------------------------
        # Transfinite lines
        # ------------------------------------------------------------------
        geometry_file.write("// Mesh refinement\n")

        airfoil_progression  = mesh_parameters.get('airfoil_progression',0.01)
        vertical_progression = mesh_parameters.get('vertical_progression',0.025)
        wake_progression     = mesh_parameters.get('wake_progression',0.01)

        fig.Add_Transfinite_Line(
            Lines_list=[airfoil_up_line_back],
            Transfinite_number=int(mesh_parameters['airfoil_divisions']),
            Progression=True,
            Progression_number=1-airfoil_progression,
        )
        fig.Add_Transfinite_Line(
            Lines_list=[airfoil_up_line_front],
            Transfinite_number=int(mesh_parameters['airfoil_divisions']),
            Progression=False,
        )
        fig.Add_Transfinite_Line(
            Lines_list=[airfoil_low_line_back],
            Transfinite_number=int(mesh_parameters['airfoil_divisions']),
            Progression=True,
            Progression_number=1+airfoil_progression,
        )
        fig.Add_Transfinite_Line(
            Lines_list=[airfoil_low_line_front],
            Transfinite_number=int(mesh_parameters['airfoil_divisions']),
            Progression=False,
        )
        fig.Add_Transfinite_Line(
            Lines_list=[airfoil_inflation_up_line_back],
            Transfinite_number=int(mesh_parameters['airfoil_divisions']),
            Progression=True,
            Progression_number=1-airfoil_progression,
        )
        fig.Add_Transfinite_Line(
            Lines_list=[airfoil_inflation_up_line_front],
            Transfinite_number=int(mesh_parameters['airfoil_divisions']),
            Progression=False,
        )
        fig.Add_Transfinite_Line(
            Lines_list=[airfoil_inflation_low_line_back],
            Transfinite_number=int(mesh_parameters['airfoil_divisions']),
            Progression=True,
            Progression_number=1+airfoil_progression,
        )
        fig.Add_Transfinite_Line(
            Lines_list=[airfoil_inflation_low_line_front],
            Transfinite_number=int(mesh_parameters['airfoil_divisions']),
            Progression=False,
        )

        fig.Add_Transfinite_Line(
            Lines_list=[front_horizontal_line],
            Transfinite_number=int(mesh_parameters['vertical_divisions']),
            Progression=True,
            Progression_number=1+vertical_progression,
        )
        fig.Add_Transfinite_Line(
            Lines_list=[front_top_line],
            Transfinite_number=int(mesh_parameters['vertical_divisions']),
            Progression=True,
            Progression_number=1+vertical_progression,
        )
        fig.Add_Transfinite_Line(
            Lines_list=[front_bot_line],
            Transfinite_number=int(mesh_parameters['vertical_divisions']),
            Progression=True,
            Progression_number=1+vertical_progression,
        )
        fig.Add_Transfinite_Line(
            Lines_list=[wake_front_top_vertical],
            Transfinite_number=int(mesh_parameters['vertical_divisions']),
            Progression=True,
            Progression_number=1+vertical_progression,
        )
        fig.Add_Transfinite_Line(
            Lines_list=[wake_back_top_vertical],
            Transfinite_number=int(mesh_parameters['vertical_divisions']),
            Progression=True,
            Progression_number=1-vertical_progression,
        )
        fig.Add_Transfinite_Line(
            Lines_list=[wake_front_bot_vertical],
            Transfinite_number=int(mesh_parameters['vertical_divisions']),
            Progression=True,
            Progression_number=1-vertical_progression,
        )
        fig.Add_Transfinite_Line(
            Lines_list=[wake_back_bot_vertical],
            Transfinite_number=int(mesh_parameters['vertical_divisions']),
            Progression=True,
            Progression_number=1+vertical_progression,
        )

        fig.Add_Transfinite_Line(
            Lines_list=[wake_top_horizontal],
            Transfinite_number=int(mesh_parameters['wake_divisions']),
            Progression=True,
            Progression_number=1+wake_progression,
        )
        fig.Add_Transfinite_Line(
            Lines_list=[wake_mid_horizontal],
            Transfinite_number=int(mesh_parameters['wake_divisions']),
            Progression=True,
            Progression_number=1+wake_progression,
        )
        fig.Add_Transfinite_Line(
            Lines_list=[wake_bot_horizontal],
            Transfinite_number=int(mesh_parameters['wake_divisions']),
            Progression=True,
            Progression_number=1-wake_progression,
        )

        fig.Add_Transfinite_Line(
            Lines_list=[domain_lines["Top"], domain_lines["Bottom"]],
            Transfinite_number=max(
                2,
                int(mesh_parameters['horizontal_boundary_divisions']),
            ),
            Progression=False,
            Progression_number=1.0,
        )

        fig.Add_Transfinite_Line(
            Lines_list=[domain_lines["Front"], domain_lines["Wake"]],
            Transfinite_number=max(
                2,
                int(mesh_parameters['vertical_boundary_divisions']),
            ),
            Progression=False,
            Progression_number=1.0,
        )

        geometry_file.write("\n")

        # ------------------------------------------------------------------
        # Curve loops
        # ------------------------------------------------------------------
        geometry_file.write("// Define curve loops\n")

        fig.Add_CurveLoop(
            curve_number=curve_number,
            line_list=[airfoil_up_line_back, front_top_line, -airfoil_inflation_up_line_back, -wake_front_top_vertical],
        )
        top_airfoil_back_loop = curve_number
        curve_number += 1
        fig.Add_CurveLoop(
            curve_number=curve_number,
            line_list=[airfoil_up_line_front, front_horizontal_line, -airfoil_inflation_up_line_front, -front_top_line],
        )
        top_airfoil_front_loop = curve_number
        curve_number += 1

        fig.Add_CurveLoop(
            curve_number=curve_number,
            line_list=[-airfoil_low_line_back, front_bot_line, airfoil_inflation_low_line_back, wake_front_bot_vertical],
        )
        bot_airfoil_back_loop = curve_number
        curve_number += 1
        fig.Add_CurveLoop(
            curve_number=curve_number,
            line_list=[-airfoil_low_line_front, front_horizontal_line, airfoil_inflation_low_line_front, -front_bot_line],
        )
        bot_airfoil_front_loop = curve_number
        curve_number += 1

        fig.Add_CurveLoop(
            curve_number=curve_number,
            line_list=[wake_front_top_vertical, wake_top_horizontal, wake_back_top_vertical, -wake_mid_horizontal],
        )
        wake_top_loop = curve_number
        curve_number += 1
        fig.Add_CurveLoop(
            curve_number=curve_number,
            line_list=[wake_front_bot_vertical, wake_mid_horizontal, wake_back_bot_vertical, wake_bot_horizontal],
        )
        wake_bot_loop = curve_number
        curve_number += 1

        fig.Add_CurveLoop(
            curve_number=curve_number,
            line_list=[airfoil_inflation_up_line_back, airfoil_inflation_up_line_front,
                       airfoil_inflation_low_line_back, airfoil_inflation_low_line_front,
                       -wake_bot_horizontal, -wake_back_bot_vertical,
                       -wake_back_top_vertical, -wake_top_horizontal],
        )
        external_loop = curve_number
        curve_number += 1


        geometry_file.write("\n")

        # ------------------------------------------------------------------
        # Surfaces
        # ------------------------------------------------------------------
        geometry_file.write("// Define plane surfaces\n")

        fig.Add_PlaneSurface(
            surface_number=1,
            Loop_number=(top_airfoil_back_loop),
            Recombine=True,
            Transfinite=True,
        )
        fig.Add_PlaneSurface(
            surface_number=2,
            Loop_number=(top_airfoil_front_loop),
            Recombine=True,
            Transfinite=True,
        )
        fig.Add_PlaneSurface(
            surface_number=3,
            Loop_number=(bot_airfoil_back_loop),
            Recombine=True,
            Transfinite=True,
        )
        fig.Add_PlaneSurface(
            surface_number=4,
            Loop_number=(bot_airfoil_front_loop),
            Recombine=True,
            Transfinite=True,
        )
        fig.Add_PlaneSurface(
            surface_number=5,
            Loop_number=(wake_top_loop),
            Recombine=True,
            Transfinite=True,
        )
        fig.Add_PlaneSurface(
            surface_number=6,
            Loop_number=(wake_bot_loop),
            Recombine=True,
            Transfinite=True,
        )

        fig.Add_PlaneSurface(
            surface_number=7,
            Loop_number=(boundary_loop, external_loop),
        )

        # ------------------------------------------------------------------
        # Extrusion
        # ------------------------------------------------------------------
        geometry_file.write("// Extrude\n")

        fig.Add_Extrude(
            extrude=1,
            Surface_list=[1, 2, 3, 4, 5, 6, 7],
        )

        geometry_file.write("// Physical groups\n")

        physical_number = 1

        fig.Add_Physical_Surface("inlet", physical_number, [183])
        physical_number += 1

        fig.Add_Physical_Surface("outlet", physical_number, [175])
        physical_number += 1

        fig.Add_Physical_Surface("airfoil", physical_number, [31,53,97,75])
        physical_number += 1

        fig.Add_Physical_Surface("front", physical_number, [216,132,154,88,110,66,44])
        physical_number += 1

        fig.Add_Physical_Surface("back", physical_number, [1,2,3,4,5,6,7])
        physical_number += 1

        fig.Add_Physical_Surface("Top_bot", physical_number, [171, 179])
        physical_number += 1

        fig.Add_Physical_Volume("internal", physical_number, [1, 2, 3, 4, 5, 6, 7])

        geometry_file.write("\n")

        geometry_file.write("\n")
        geometry_file.write("Mesh.MshFileVersion = 2.2;\n")
        geometry_file.write("Geometry.Tolerance = 1e-9;\n")

    msh_file = file.with_suffix(".msh")

    subprocess.run(
        [
            "gmsh",
            str(file),
            "-o",
            str(msh_file),
            "-format",
            "msh2",
            "-3",
        ],
        check=True,
    )

def meshing_pipeline(name,geometry_parameters, mesh_parameters, splitting_parameters=None, permutation_parameters=None, refinement_parameters=None):
    airfoil = define_airfoil_geometry(geometry_parameters)

    if splitting_parameters is None and geometry_parameters['airfoil_type'] != '30P30N':
        type = mesh_parameters.get('type','Unstructured')
        if type=='Structured':
            build_single_airfoil_structured(name, airfoil, mesh_parameters=mesh_parameters)
        elif type=='Structured-o':
            build_single_airfoil_o_structured(name, airfoil, mesh_parameters=mesh_parameters)
        else:
            build_full_airfoil_mesh(name, airfoil, mesh_parameters, refinement_parameters=refinement_parameters)
    else:
        if geometry_parameters['airfoil_type'] == '30P30N':
            slat, main, flap, split_info = airfoil
            if splitting_parameters is not None:
                splitting_parameters['flap_type']='square'
            else:
                splitting_parameters = {'flap_type':'square'}
            build_3piece_airfoil_mesh(name, slat=slat, main=main, flap=flap, splitting_params=splitting_parameters, split_info=split_info, mesh_parameters=mesh_parameters, refinement_parameters=refinement_parameters)
        else:
            split_out = split_airfoil(airfoil, splitting_parameters)
            if splitting_parameters['scenario'] == 'slat':
                slat, main, split_info = split_out
                flap = None
            elif splitting_parameters['scenario'] == 'flap':
                main, flap, split_info = split_out
                slat = None
            elif splitting_parameters['scenario'] == 'slat-flap':
                slat, main, flap, split_info = split_out

            if permutation_parameters is not None:
                permute_out = permute_3_piece_airfoil(slat=slat,main=main, flap=flap,splitting_parameters=splitting_parameters,
                                                        split_info=split_info,permutation_params=permutation_parameters)

                if splitting_parameters['scenario'] == 'slat':
                    slat, main = permute_out
                elif splitting_parameters['scenario'] == 'flap':
                    main, flap = permute_out
                elif splitting_parameters['scenario'] == 'slat-flap':
                    slat, main, flap = permute_out
                
            if splitting_parameters['scenario'] == 'slat-flap':
                build_3piece_airfoil_mesh(name, slat=slat, main=main, flap=flap, splitting_params=splitting_parameters, split_info=split_info, mesh_parameters=mesh_parameters, refinement_parameters=refinement_parameters)
            elif splitting_parameters['scenario'] == 'slat':
                build_2piece_airfoil_mesh(name, main, aux = slat, splitting_params=splitting_parameters, split_info=split_info, mesh_parameters=mesh_parameters, refinement_parameters=refinement_parameters)
            elif splitting_parameters['scenario'] == 'flap':
                build_2piece_airfoil_mesh(name, main, aux = flap, splitting_params=splitting_parameters, split_info=split_info, mesh_parameters=mesh_parameters, refinement_parameters=refinement_parameters)