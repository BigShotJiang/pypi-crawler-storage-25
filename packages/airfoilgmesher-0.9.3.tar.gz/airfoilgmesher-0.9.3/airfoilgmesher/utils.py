# -*- coding: utf-8 -*-
"""
Created on Tue Jun 22 14:08:40 2021
"""
## Import section
import sys
import os
import meshio
import numpy as np
import matplotlib.pyplot as plt
from matplotlib.tri import Triangulation

cwd = os.getcwd()
sys.path.append(cwd + "/../")#

##
def point_to_polyline_distance(p, curve):
    """
    Minimum Euclidean distance from point p = [x, y] to a 2xN polyline curve.
    Uses segment projection, not only node distance.
    """
    p = np.asarray(p).reshape(2)
    A = curve[:, :-1].T      # [N-1, 2]
    B = curve[:, 1:].T       # [N-1, 2]

    AB = B - A
    AP = p[None, :] - A

    denom = np.sum(AB * AB, axis=1)
    denom = np.maximum(denom, 1e-30)

    t = np.sum(AP * AB, axis=1) / denom
    t = np.clip(t, 0.0, 1.0)

    Q = A + t[:, None] * AB
    d = np.linalg.norm(Q - p[None, :], axis=1)

    i = np.argmin(d)
    return d[i], Q[i], i

def enforce_slat_gap(
    main,
    new_slat,
    idx_TE_slat,
    g_s,
    max_iter=80,
    tol=1e-8,
    direction=-1.0,
):
    """
    Vertically translates the whole slat until the minimum distance between
    the slat trailing edge and the main-element polyline is g_s.

    Parameters
    ----------
    main : np.ndarray
        Main element coordinates, shape [2, N].
    new_slat : np.ndarray
        Slat coordinates, shape [2, N].
    idx_TE_slat : int
        Index of the slat trailing edge.
    g_s : float
        Target gap.
    direction : float
        -1.0 means try moving the slat downward first.
        +1.0 means try moving the slat upward first.

    Returns
    -------
    new_slat : np.ndarray
        Translated slat.
    info : dict
        Diagnostic information.
    """

    new_slat = new_slat.copy()

    def f(dy):
        p = new_slat[:, idx_TE_slat].copy()
        p[1] += dy
        dmin, q, iseg = point_to_polyline_distance(p, main)
        return dmin - g_s

    # Current error
    f0 = f(0.0)

    if abs(f0) < tol:
        dmin, q, iseg = point_to_polyline_distance(new_slat[:, idx_TE_slat], main)
        return new_slat, {
            "dy": 0.0,
            "gap": dmin,
            "closest_point": q,
            "segment": iseg,
            "converged": True,
        }

    # Bracket the solution in the selected vertical direction
    dy_low = 0.0
    f_low = f0

    step = direction * max(g_s, 1e-6)
    dy_high = step
    f_high = f(dy_high)

    # Expand bracket until sign change
    for _ in range(max_iter):
        if f_low * f_high <= 0.0:
            break
        dy_high *= 2.0
        f_high = f(dy_high)
    else:
        # Try opposite direction if first one failed
        dy_high = -step
        f_high = f(dy_high)

        for _ in range(max_iter):
            if f_low * f_high <= 0.0:
                break
            dy_high *= 2.0
            f_high = f(dy_high)
        else:
            raise RuntimeError(
                "Could not bracket a vertical displacement giving the required gap. "
                "Check whether the prescribed gap/overlap is geometrically feasible."
            )

    # Bisection
    a, b = dy_low, dy_high
    fa, fb = f_low, f_high

    for _ in range(max_iter):
        c = 0.5 * (a + b)
        fc = f(c)

        if abs(fc) < tol:
            break

        if fa * fc <= 0.0:
            b = c
            fb = fc
        else:
            a = c
            fa = fc

    dy = 0.5 * (a + b)
    new_slat[1, :] += dy

    p_TE = new_slat[:, idx_TE_slat]
    dmin, q, iseg = point_to_polyline_distance(p_TE, main)

    return new_slat

def enforce_flap_gap(
    main,
    new_flap,
    idx_LE_flap,
    g_f,
    max_iter=80,
    tol=1e-8,
    direction=-1.0,
):
    """
    Vertically translates the whole flap until the minimum distance between
    the flap leading edge and the main-element polyline is g_f.

    Parameters
    ----------
    main : np.ndarray
        Main element coordinates, shape [2, N].
    new_flap : np.ndarray
        Flap coordinates, shape [2, N].
    idx_LE_flap : int
        Index of flap leading edge.
    g_f : float
        Target flap gap.
    direction : float
        -1.0 means try moving the flap downward first.
        +1.0 means try moving it upward first.
    """

    new_flap = new_flap.copy()

    def f(dy):
        p = new_flap[:, idx_LE_flap].copy()
        p[1] += dy
        dmin, q, iseg = point_to_polyline_distance(p, main)
        return dmin - g_f

    f0 = f(0.0)

    if abs(f0) < tol:
        dmin, q, iseg = point_to_polyline_distance(new_flap[:, idx_LE_flap], main)
        return new_flap, {
            "dy": 0.0,
            "gap": dmin,
            "gap_error": dmin - g_f,
            "closest_point": q,
            "segment": iseg,
            "converged": True,
        }

    dy_low = 0.0
    f_low = f0

    step = direction * max(g_f, 1e-6)
    dy_high = step
    f_high = f(dy_high)

    for _ in range(max_iter):
        if f_low * f_high <= 0.0:
            break
        dy_high *= 2.0
        f_high = f(dy_high)
    else:
        dy_high = -step
        f_high = f(dy_high)

        for _ in range(max_iter):
            if f_low * f_high <= 0.0:
                break
            dy_high *= 2.0
            f_high = f(dy_high)
        else:
            raise RuntimeError(
                "Could not bracket a vertical displacement giving the required flap gap. "
                "Check whether the prescribed gap/overlap is geometrically feasible."
            )

    a, b = dy_low, dy_high
    fa, fb = f_low, f_high

    for _ in range(max_iter):
        c = 0.5 * (a + b)
        fc = f(c)

        if abs(fc) < tol:
            break

        if fa * fc <= 0.0:
            b = c
            fb = fc
        else:
            a = c
            fa = fc

    dy = 0.5 * (a + b)
    new_flap[1, :] += dy

    p_LE = new_flap[:, idx_LE_flap]
    dmin, q, iseg = point_to_polyline_distance(p_LE, main)

    return new_flap
##
class geom_functions:
    def __init__(self,file):
        global geometry_file
        self.file = file
        geometry_file = self.file
        
    def Add_point(self,point_number,x,y,size):
        string = "Point(" + str(point_number) + ") = {" + str(x) + ", " + str(y) + ", " + "0, "+ str(size) +"};\n"
        geometry_file.write(string)
        
    def Rotate_point_2D(self,point_number,angle):
        string = "Rotate{{0,0,1},{0,0,0},"+str(angle)+"}{Point{"+point_number+"};}\n"
        geometry_file.write(string)
        
    def Add_line(self,line_number,P1,P2, Transfinite = False, NbTr = 10, Progression = 1):
        string = "Line(" + str(line_number) + ") = {" + str(P1) + ", "+ str(P2) + "};"
        if Transfinite:
            string += " Transfinite Line {" + str(line_number) + "} "+ "= " + str(NbTr) + " Using Progression " + str(Progression) + ";"
        string += "\n"
        geometry_file.write(string)
    
    def Add_custom_line(self,line_number,P, close=True, Transfinite = False, NbTr = 10, Progression = 1):
        if close:
            string = "Line(" + str(line_number) + ") = {" + ''.join([str(p) + ", " for p in P])+ str(P[0])+"};"
        else:
            string = "Line(" + str(line_number) + ") = {" + ''.join([str(p) + ", " for p in P[:-1]])+ str(P[-1])+"};"
        if Transfinite:
            string += " Transfinite Line {" + str(line_number) + "} "+ "= " + str(NbTr) + " Using Progression " + str(Progression) + ";"
        string += "\n"
        geometry_file.write(string)
     
    def Add_spline(self,line_number,spline):
        # Spline is a vector that contains the Points to be included in the spline
        string = "Spline("+str(line_number)+") = {"
        for point in spline[0:-1]:
            string = string+str(point)+", "
        string = string+str(spline[-1])+"};\n"
        geometry_file.write(string)
        
    def Add_Circle(self,curve_number,PCenter,PRadius1,PRadius2, Transfinite = False, NbTr = 10, Progression = 1):
        string = "Circle(" + str(curve_number) + ") = { " + str(PRadius1) + ", "+ str(PCenter) + ", " + str(PRadius2) + "};"
        if Transfinite:
            string += " Transfinite Line {" + str(curve_number) + "} "+ "= " + str(NbTr) + " Using Progression " + str(Progression) + ";"
        string += "\n"
        geometry_file.write(string)
        
    def Add_CurveLoop(self,curve_number,line_list):
        string = "Curve Loop(" + str(curve_number) + ") = {"+ str(line_list)[1:-1] + "};\n"
        geometry_file.write(string)
        
    def Add_LineLoop(self,line_number,line_list):
        string = "Line Loop(" + str(line_number) + ") = {"+ str(line_list)[1:-1] + "};\n"

        geometry_file.write(string)
        
    def Add_PlaneSurface(self,surface_number,Loop_number, Transfinite = False, Recombine = False):
        if not type(Loop_number)==tuple:
            string = "Plane Surface(" + str(surface_number) + ") = {"+ str(Loop_number) + "};"
        else:
            string = "Plane Surface(" + str(surface_number) + ") = {"
            for loop in Loop_number:
                string += str(loop) + ', '
            string = string[:-2] + '};'
            #string = "Plane Surface(" + str(surface_number) + ") = {"+ str(Loop_number[0]) + ', '+ str(Loop_number[1]) + "};"
        
        if Transfinite:
                string += " Transfinite Surface {" + str(surface_number) + "}"+ ";"
        
        string += "\n"
            
        geometry_file.write(string)

        if Recombine:
            string = "Recombine Surface {" + str(surface_number) + "}"+ ";\n"
            geometry_file.write(string)
        
    def Add_Transfinite_Line(self,Lines_list,Transfinite_number, Progression = False, Progression_number = 1.):
        string = "Transfinite Line {" 
        for line in Lines_list:
            string += str(line) + ","
        string = string[:-1]
        string += '} = '+str(Transfinite_number)
        if Progression:
            string += ' Using Progression ' + str(Progression_number)
        string += ";\n"
        
        geometry_file.write(string)

    def Add_Transfinite_Surface(self,Surface_list,Transfinite_number = 1, Progression = False, Progression_number = 1.):
        string = "Transfinite Surface {" 
        for line in Surface_list:
            string += str(line) + ","
        string = string[:-1]
        string += "};\n"

        geometry_file.write(string)          
            
    def Add_Recombine_Surface(self,Surface_list):
        string = "Recombine Surface {" 
        for line in Surface_list:
            string += str(line) + ","
        string = string[:-1]
        string += "};\n"            
        
        geometry_file.write(string)
    
    def Add_Extrude(self,extrude,Surface_list,Layers_number = 1):
        string = "Extrude {0,0," + str(extrude) + "} { Surface{"
        
        for surface in Surface_list:
            string += str(surface) + ","
        string = string[:-1]
        string += "}; Layers{" + str(Layers_number) + "}; Recombine;}"
        
        geometry_file.write(string)

    def Add_Physical_Point(self,name,ID,Point_list):
        string = """Physical Point (" """ 
        string = string[:-1]
        string += str(name) 
        string += """", """
        string += str(ID) + ") = {"
        for point in Point_list:
            string += str(point) + ","
        string = string[:-1]
        string += "};\n"          
        
        geometry_file.write(string)
    
    def Add_Physical_Line(self,name,Line_list):
        string = """Physical Line (" """ 
        string = string[:-1]
        string += str(name) 
        string += """") = {"""
        for line in Line_list:
            string += str(line) + ","
        string = string[:-1]
        string += "};\n"            
        
        geometry_file.write(string)
       
    def Add_Physical_Curve(self,name,ID,Curve_list):
        string = "Physical Curve (\""+str(name)+"\""
        if type(ID) == str:
            string += ","+str(ID)
            
        string += ") = {"
        for curve in Curve_list:
            string += str(curve) + ","
        string = string[:-1]
        string += "};\n"          
        
        geometry_file.write(string)
      
    def Add_Physical_Surface(self,name,ID,Surface_list):
        string = "Physical Surface (\""+str(name)+"\""
        if type(ID) == str:
            string += ","+str(ID)
            
        string += ") = {"
        for surface in Surface_list:
            string += str(surface) + ","
        string = string[:-1]
        string += "};\n"          
        
        geometry_file.write(string)
        
    def Add_Physical_Volume(self,name,ID,Volume_list):
        string = """Physical Volume (" """ 
        string = string[:-1]
        string += str(name) 
        string += """", """
        string += str(ID) + ") = {"
        for volume in Volume_list:
            string += str(volume) + ","
        string = string[:-1]
        string += "};\n"          
        
        geometry_file.write(string)
        
    def Clear_file(self):
        geometry_file.truncate(0)

def compute_line(point1,point2):
    # Unpack the points
    x1, y1 = point1
    x2, y2 = point2
    # Calculate the slope
    if x1 == x2:
        raise ValueError("The line is vertical, slope is undefined.")
    m = (y2 - y1) / (x2 - x1)
    # Calculate the y-intercept using y = mx + b -> b = y - mx
    b = y1 - m * x1
    return m, b

def compute_length(points):
    if points.shape[0] != 2:
        raise ValueError("Input array must have 2 rows representing x and y coordinates.")
    if points.shape[1] < 2:
        return 0.0  # A single point or empty input has no length.
    
    # Compute the differences between consecutive points
    differences = np.diff(points, axis=1)
    
    # Compute the Euclidean distances between consecutive points
    distances = np.sqrt(np.sum(differences**2, axis=0))
    
    # Return the total length
    return np.sum(distances)

def rotate_vector_90_clockwise(vector):
    x, y = vector
    # Applying the 90� clockwise rotation
    rotated_vector = [y, -x]
    return rotated_vector

def rotate_vector_90_anticlockwise(vector):
    x, y = vector
    # Applying the 90° anticlockwise rotation
    rotated_vector = [-y, x]
    return rotated_vector

def find_intersection_with_y_equals_0(start_point, direction_vector):
    """
    Find the point where a vector intersects the y=0 line.

    Parameters:
    - start_point: tuple (x1, y1), the starting point of the vector.
    - direction_vector: tuple (vx, vy), the vector's direction.

    Returns:
    - A tuple (x, 0) representing the intersection point with the y=0 line.
    """
    x1, y1 = start_point
    vx, vy = direction_vector

    if vy == 0:
        # The vector is parallel to the y=0 line and does not intersect
        return None  # No intersection
    
    # Solve for t when y = 0
    t = -y1 / vy

    # Calculate x using the parametric equation
    x = x1 + t * vx

    return np.array([x, 0])

def compute_angles(vectors):
    """Compute the angles of 2D vectors with respect to the x-axis in the range [0, 2*pi]."""
    # Extract the x and y components of the vectors
    x = vectors[0, :]
    y = vectors[1, :]
    # Compute the angle in radians (-pi to pi)
    angles = np.arctan2(y, x)
    
    return angles

def rotate_curve_around_point(curve, alpha, center_point):
    """
    Rotates a 2xN curve around a given point by an angle alpha.
    
    Parameters:
    - curve: 2xN numpy array representing the points of the curve.
    - alpha: Rotation angle in degrees.
    - center_point: List or tuple [x, y] representing the point around which to rotate.
    
    Returns:
    - rotated_curve: 2xN numpy array of the rotated curve.
    """
    # Extract center point
    cx, cy = center_point

    # compute radians
    alpha = -np.deg2rad(alpha) # the - is becaise we are dealing with AoA

    # Translate curve to make center_point the origin
    shifted_curve = curve - np.array([[cx], [cy]])

    # Rotation matrix
    rotation_matrix = np.array([
        [np.cos(alpha), -np.sin(alpha)],
        [np.sin(alpha), np.cos(alpha)]
    ])

    # Rotate the shifted curve
    rotated_shifted_curve = np.dot(rotation_matrix, shifted_curve)

    # Translate back to the original position
    rotated_curve = rotated_shifted_curve + np.array([[cx], [cy]])

    return rotated_curve

# Function to calculate an arc-circle
def arc_circle(center, point1, point2, N=500):
    cx, cy = center
    x1, y1 = point1
    x2, y2 = point2

    # Calculate radius
    radius = np.sqrt((x1 - cx)**2 + (y1 - cy)**2)

    # Calculate angles for the points in polar coordinates relative to the center
    angle1 = np.arctan2(y1 - cy, x1 - cx)
    angle2 = np.arctan2(y2 - cy, x2 - cx)

    # Normalize angles to be in the range [0, 2π]
    if angle1 < 0:
        angle1 += 2 * np.pi
    if angle2 < 0:
        angle2 += 2 * np.pi

    # Ensure anti-clockwise movement
    if angle2 < angle1:
        angle2 += 2 * np.pi

    # Create an array of angles between angle1 and angle2
    theta = np.linspace(angle1, angle2, N)

    # Calculate points along the arc
    x_arc = cx + radius * np.cos(theta)
    y_arc = cy + radius * np.sin(theta)

    return np.vstack((x_arc,y_arc)), angle2-angle1

def plot_gmsh_mesh(path, name=None):
    mesh = meshio.read(path)

    points = mesh.points[:, :2]

    triangles = None
    for cell_block in mesh.cells:
        if cell_block.type == "triangle":
            triangles = cell_block.data
            break

    if triangles is None:
        raise ValueError("No triangular elements found in the mesh.")

    # tri = Triangulation(points[:, 0], points[:, 1], triangles)

    fig, ax = plt.subplots(figsize=(8, 4))
    # ax.triplot(tri, linewidth=0.4)

    ax.plot(points[:, 0], points[:, 1], ".", markersize=1)

    ax.set_aspect("equal", adjustable="box")
    ax.set_xlim([-0.5,1.5])
    ax.set_ylim([-0.5,0.5])
    ax.set_xlabel("x")
    ax.set_ylabel("y")
    ax.set_title(path)
    plt.tight_layout()
    if name is not None:
        plt.savefig(name)
    plt.show()