# NEBscape
[![ChemRxiv](https://img.shields.io/badge/ChemRxiv-Preprint-blue)](https://doi.org/10.26434/chemrxiv.15002133/v1)
[![DOI](https://img.shields.io/badge/DOI-10.26434%2Fchemrxiv.15000180-blue)](https://doi.org/10.26434/chemrxiv.15002133/v1)

[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](https://opensource.org/licenses/MIT)
[![PyPI version](https://img.shields.io/pypi/v/nebscape)](https://pypi.org/project/nebscape/)
[![Tests Passing](https://img.shields.io/badge/tests-passing-brightgreen.svg)](https://gitlab.mpcdf.mpg.de/hjung/nebscape)
![Ruff](https://img.shields.io/badge/lint-ruff-success?logo=ruff)

NEBscape automates the sampling of minimum energy paths (MEPs) for surface reactions, combining global geometry optimization, atom-mapping, and NEB calculations into a single workflow — requiring minimal human input.

![image](./docs/workflow.png)

## Installation from source
```
git clone https://gitlab.mpcdf.mpg.de/hjung/nebscape.git
pip install .
```

## Required Inputs
This workflow prepares initial and final geometry with global optimization (e.g. minima hopping) and provides automatic atom-mapping and generates possible permutation of symmetric atoms. Only following three inputs are required.

1. List of reaction SMILES string in `reaction_smiles.txt`
(e.g. `O=[C][CH2][O]>>[C-]#[O+].[CH2]=O`)
2. slab information in `slab.xyz`
(Slab should use tag to indicate which atoms are fixed (tag=0) and which atoms are relaxed(tag=1))
3. Calculator (e.g. MLIP like MACE)

## Setting
This workflow uses [wfl](https://github.com/libAtoms/workflow) and [expyre](https://github.com/libAtoms/ExPyRe) for remote submission, so configure the following related settings
- `config.json` file has to be set for remote submission to HPC (Can be found in `/example`)
- According to `config.json`, the `remote_info` entries should be adapted to your environment.

## Documentation

* **[Home](https://gitlab.mpcdf.mpg.de/hjung/nebscape/-/wikis/home)** - overview
* **[Installation](https://gitlab.mpcdf.mpg.de/hjung/nebscape/-/wikis/page-1)** - installation
* **[Setting up local environment](https://gitlab.mpcdf.mpg.de/hjung/nebscape/-/wikis/page-2)** - setting for wfl and expyre
* **[Input preparation](https://gitlab.mpcdf.mpg.de/hjung/nebscape/-/wikis/Input-Preparation)** - input file preparation
* **[Geometry generation](https://gitlab.mpcdf.mpg.de/hjung/nebscape/-/wikis/Geometry-generation)** - running minima hopping
* **[Interpolation generation](https://gitlab.mpcdf.mpg.de/hjung/nebscape/-/wikis/Interpolation-generation)** - generating initial minimum energy paths

(We are currently working on improving the documentation / tutorial. Let us know if you need help or suggestions.)


## References
If you use this code, please cite our paper:

Hyunwook Jung, Emanuel Colombi Manzi, Tiago J. Goncalves, et al. From Global Optimization to Transition State Search: An Automated Workflow for Surface Reaction Barriers. ChemRxiv. 17 April 2026.

https://doi.org/10.26434/chemrxiv.15002133/v1

```
@article{
doi:10.26434/chemrxiv.15002133/v1,
author = {Hyunwook Jung  and Emanuel Colombi Manzi  and Tiago J. Goncalves  and Vanessa J. Bukas  and Sandip De  and Johannes T. Margraf  and Karsten Reuter  and Hendrik H. Heenen },
title = {From Global Optimization to Transition State Search: An Automated Workflow for Surface Reaction Barriers},
journal = {ChemRxiv},
volume = {2026},
number = {0417},
pages = {},
year = {2026},
doi = {10.26434/chemrxiv.15002133/v1},
URL = {https://chemrxiv.org/doi/abs/10.26434/chemrxiv.15002133/v1},
eprint = {https://chemrxiv.org/doi/pdf/10.26434/chemrxiv.15002133/v1}}
```

## Contact
If you have any questions, please contact us at hjung@fhi.mpg.de
Also for any bugs or issues, you can use [gitlab issues](https://gitlab.mpcdf.mpg.de/hjung/nebscape/-/issues).

## License
The NEBscape code is published and distributed under the [MIT License](LICENSE).
