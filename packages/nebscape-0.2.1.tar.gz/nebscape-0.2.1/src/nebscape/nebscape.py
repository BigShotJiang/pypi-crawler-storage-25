"""
NEBscape class that wraps all the associated operations.
"""

from .wfl_minimahopping import minimahopping
from .wfl_stepwise_NEB import NEB as wflNEB
from wfl.generate.optimize import optimize as wfloptimize
from wfl.configset import ConfigSet, OutputSpec
from wfl.autoparallelize.autoparainfo import AutoparaInfo

from ase.io import read
from ase.constraints import FixAtoms
from pathlib import Path
from .objects import Molecule, ReactiveState, get_canonical_rxnsmi
from .neb_from_globalmin import (
    get_geometry_pairs,
    filter_geometry_pairs,
    apply_permutation_interpolate,
    sort_and_write_interpolations,
)
from .minimize_rmsd import improve_alignment
from .neb_helpers import AbortOnOscillation, adjust_spring_constants
from .minhop_helpers import (
    prepare_isolated_minima_hopping,
    prepare_dimer_minima_hopping,
    make_pickle,
    filter_minhop,
)
import numpy as np
import pandas as pd
import time
import pickle
import json


def get_molecules_reactive_states(reactions_list):
    """
    Get the reactive states of molecules in a list of reactions.

    Parameters
    ----------
    reactions_list : list
        A list of reaction SMILES strings.

    Returns
    -------
    molecules : dict
        A mapping of molecule SMILES to Molecule objects.
    reactive_states : dict
        A mapping of reactive state SMILES to their ReactiveState objects.
    """
    molecules = {}
    reactive_states = {}
    for rxnsmiles in reactions_list:
        #    rxnsmiles = get_canonical_rxnsmi(rxnsmiles)
        for side in rxnsmiles.split(">>"):
            side_molecules = [
                Molecule(molsmi, ID=f"{len(molecules) + 1}") for molsmi in side.split(".")
            ]
            reactive_states[side] = ReactiveState(*side_molecules)
            for mol in side_molecules:
                molecules[mol.smiles] = mol
    return molecules, reactive_states


def check_neb_convergence(images):  # numpydoc ignore=GL08
    if images[0].info["config_type"] == "neb_last_converged":
        return True
    elif images[0].info["config_type"] == "neb_last_exception":
        return False
    elif images[0].info["neb_n_steps"] < 500:
        #        print('weird, but converged.')
        return True
    else:
        return False


class NEBscape:
    """
    Workflow for preparation of reaction pathways for NEB calculations.

    Parameters
    ----------
    rootdir : str
        Root directory for the workflow.
    **kwargs : dict
        Additional keyword arguments.

    Attributes
    ----------
    reaction_smiles_file : str, optional
        Path to the file containing reaction SMILES.
    reactions_list : list
        List of reaction SMILES.
    slab_file : str, optional
        Path to the slab file.
    slab : ase.Atoms
        Slab structure.
    slab_indices : np.ndarray
        Indices of the slab atoms.
    fix_indices : list
        Indices of the fixed atoms in slab.
    slab_constraints : list
        List of constraints for the slab.
    numimages : int, optional
        Number of images for NEB calculation.
    calculator_tuple : tuple, optional
        Calculator settings for NEB calculation.
    molecules : list
        List of molecule structures.
    reactive_states : list
        List of reactive states for the each side of reaction.
    slab_deform_threshold : float
        Threshold for slab deformation.
    energy_cutoff : float
        Energy cutoff for the selecting geometry from minima hopping. Default is 1.2 eV.
    distance_cutoff : float
        Distance cutoff for the selecting geometry from minima hopping. Default is 4.5 Å.
    remote_info : dict, optional
        Information for remote submission of jobs.
    autopara_info : dict, optional
        Information for autoparallelization.

    Examples
    --------
    >>> rootdir = os.getcwd()
    >>> nebscp = NEBscape(
    >>>     rootdir,
    >>>     calculator_tuple=CALCULATOR_TUPLE,
    >>>     reaction_smiles_file="reaction_list.txt",
    >>>     slab_file="slab.xyz",
    >>>     remote_info=remote_info,
    >>> )
    """

    def __init__(self, rootdir, **kwargs):
        self.rootdir = Path(rootdir)
        self.reaction_smiles_file = kwargs.pop("reaction_smiles_file", "reactions_list.txt")
        with open(self.rootdir / self.reaction_smiles_file, "r") as f:
            reactions_list = f.read().splitlines()
        self.reactions_list = [get_canonical_rxnsmi(rxnsmiles) for rxnsmiles in reactions_list]
        self.slab_file = kwargs.pop("slab_file", "slab.xyz")
        self.slab = read(self.rootdir / self.slab_file)
        self.slab_indices = np.arange(len(self.slab))
        self.fix_indices = [i for i, tag in enumerate(self.slab.arrays["tags"]) if tag == 0]
        self.slab_constraints = [FixAtoms(indices=self.fix_indices)]
        self.numimages = kwargs.pop("numimages", 18)
        self.calculator_tuple = kwargs.pop("calculator_tuple", None)
        self.molecules, self.reactive_states = get_molecules_reactive_states(self.reactions_list)
        if Path(self.rootdir / "reactive_states.csv").is_file():
            self.df = pd.read_csv(self.rootdir / "reactive_states.csv")

        self.slab_deform_threshold = kwargs.pop("slab_deform_threshold", 1.2)
        self.remote_info = kwargs.pop("remote_info", None)
        self.autopara_info = kwargs.pop("autopara_info", None)

    def run_isolated_minima_hopping(self, index=None, submit=True, **minhop_params):
        """
        Run isolated (one adsorbate on surface) minima hopping.

        Parameters
        ----------
        index : int or list of int, optional
            Index or indices of initial structures to use.
        submit : bool, optional
            Whether to submit the job to the queue.
        **minhop_params : dict
            Additional parameters for minima hopping.
        """
        autoadsorbate = minhop_params.pop("autoadsorbate", False)
        autoadsorbate_kwargs = minhop_params.pop("autoadsorbate_kwargs", {})

        if self.remote_info is not None:
            self.remote_info.job_name = "isolated_minhop"

        if autoadsorbate:
            from .autoads_helpers import prepare_isolated_autoadsorbate, get_all_surrogate_smiles

            self.surrogate_smiles_dict = get_all_surrogate_smiles(self.reaction_smiles_file)

            initial_structures, output_dir = prepare_isolated_autoadsorbate(
                self.rootdir,
                self.molecules,
                self.slab,
                self.surrogate_smiles_dict,
                **autoadsorbate_kwargs,
            )
        else:
            initial_structures, output_dir = prepare_isolated_minima_hopping(
                self.rootdir, self.molecules, self.slab, self.fix_indices, k=20
            )

        if index:
            if not isinstance(index, list):
                index = [index]
            initial_structures = [initial_structures[i] for i in index]
            output_dir = [output_dir[i] for i in index]

        in_config = ConfigSet(initial_structures)
        out_config = OutputSpec(output_dir)
        minhop_params["slab_indices"] = self.slab_indices

        if submit:
            start = time.time()
            minimahopping(
                in_config.groups(),
                out_config,
                calculator=self.calculator_tuple,
                autopara_info=AutoparaInfo(
                    num_python_subprocesses=len(output_dir),
                    num_inputs_per_python_subprocess=2,
                    remote_info=self.remote_info,
                ),
                **minhop_params,
            )
            print("Isolated minima hopping finished\n", flush=True)
            print(f"Isolated minima hopping : {(time.time() - start) / 3600:0.3f} hr")

    def run_dimer_minima_hopping(self, index=None, submit=True, overwrite=False, **minhop_params):
        """
        Run dimer (two adsorbates on surface) minima hopping.

        Parameters
        ----------
        index : int or list of int, optional
            Index or indices of initial structures to use.
        submit : bool, optional
            Whether to submit the job to the queue.
        overwrite : bool, optional
            Whether to overwrite existing files.
        **minhop_params : dict
            Additional parameters for minima hopping.
        """
        autoadsorbate = minhop_params.pop("autoadsorbate", False)
        autoadsorbate_kwargs = minhop_params.pop("autoadsorbate_kwargs", {})

        if self.remote_info is not None:
            self.remote_info.job_name = "dimer_minhop"
            self.remote_info.resources.max_time = 24 * 3600  # 24h

        if autoadsorbate:
            from .autoads_helpers import (
                get_all_surrogate_smiles,
                prepare_dimer_autoadsorbate,
            )

            self.surrogate_smiles_dict = get_all_surrogate_smiles(self.reaction_smiles_file)

            start = time.time()
            initial_structures, output_dir = prepare_dimer_autoadsorbate(
                self.rootdir,
                self.reactive_states,
                self.slab,
                self.surrogate_smiles_dict,
                **autoadsorbate_kwargs,
            )
            print(
                f"Autoadsorbate geometry generation finished: {(time.time() - start) / 3600:0.3f} hr",
                flush=True,
            )
        else:
            initial_structures, output_dir, name_dict = prepare_dimer_minima_hopping(
                self.rootdir,
                self.reactive_states,
                self.slab,
                self.fix_indices,
                generate=True,
                num_initial_structures=10,
                overwrite=overwrite,
                k=10,
                threshold=1.2,
            )

        #        initial_structures, output_dir = prepare_dimer_autoadsorbate(
        #                                self.rootdir,
        #                                self.reactive_states,
        #                                self.slab,
        #                                self.surrogate_smiles_dict,
        #                                parallel=16)

        if index:
            initial_structures = [initial_structures[i] for i in index]
            output_dir = [output_dir[i] for i in index]

        print("preparation finished.", flush=True)
        in_config = ConfigSet(initial_structures)
        out_config = OutputSpec(output_dir)
        minhop_params["slab_indices"] = self.slab_indices

        if submit:
            start = time.time()
            minimahopping(
                in_config.groups(),
                out_config,
                calculator=self.calculator_tuple,
                autopara_info=AutoparaInfo(
                    num_python_subprocesses=len(output_dir),
                    num_inputs_per_python_subprocess=1,
                    remote_info=self.remote_info,
                ),
                **minhop_params,
            )
            print("Dimer minima hopping finished", flush=True)
            print(f"Dimer minima hopping : {(time.time() - start) / 3600:0.3f} hr")
            make_pickle(self.rootdir, self.reactive_states, self.molecules)

    def prepare_neb(
        self,
        index=None,
        max_num_groups=10,
        energy_cutoff=1.2,
        distance_cutoff=4.5,
        numimages=18,
        max_num_interpolations_per_mapping=5,
        max_num_permutation=2,
        max_num_pairs=20,
        reduce_method="decaf",
        num_kmeans=10,
        return_all=True,
        fmax=0.05,
        aligned_filename="aligned_relaxed.xyz",
        energy_key="last_op__optimize_energy",
        energy_threshold=0.1,
        autopara_info=None,
        verbose=False,
    ):
        """
        Generate interpolations for NEB using minima hopping results and atom-mapping info.

        Parameters
        ----------
        index : int or list of int, optional
            Index of reactions to include.
        max_num_groups : int, optional
            Maximum number of groups for clustering.
        energy_cutoff : float, optional
            Energy cutoff from global minimum energy for Pareto front, default is 1.2 eV
        distance_cutoff : float, optional
            Distance cutoff from the shortest donor-acceptor distance, default is 4.5 Angs.
        numimages : int, optional
            Number of images for NEB.
        max_num_interpolations_per_mapping : int, optional
            Maximum number of interpolations to be submitted per mapping.
        max_num_permutation : int, optional
            Maximum number of index permutations to be considered for given IS, FS geometry pairs.
        max_num_pairs : int, optional
            Maximum number of pairs per reaction to be filtered after FS-to-IS alignment.
        reduce_method : str, optional
            Geometry reduction method, either decaf or kmeans. For kmeans, num_kmeans should be defined. Default is decaf.
        num_kmeans : int, optional
            Number of minima to be selected using kmeans clustering from pareto front.
        return_all : bool, optional
            Whether to include all symmetric operations. Default is True.
        fmax : float, optional
            Maximum fmax for geometry relaxation in alignment.
        aligned_filename : str, optional
            Filename for aligned structures.
        energy_key : str, optional
            Energy key name that saves energy info. Default is "last_op__optimize_energy".
        energy_threshold : float, optional
            Energy threshold when comparing geometries before/after symmetric operation. Default is 0.1 eV.
        autopara_info : AutoparaInfo, optional
            Information for autoparallelization.
        verbose : bool, optional
            Whether to print verbose output. Default is False.
        """
        workdir = self.rootdir / "2_NEB"
        workdir.mkdir(exist_ok=True, parents=True)

        if Path(self.rootdir / "reactive_states.csv").is_file():
            self.df = pd.read_csv(self.rootdir / "reactive_states.csv")
        else:
            make_pickle(
                self.rootdir,
                self.reactive_states,
                self.molecules,
                self.slab_indices,
            )
            self.df = pd.read_csv(self.rootdir / "reactive_states.csv")

        if index:
            rxnsmiles_dict = {
                i: rxnsmi for i, rxnsmi in enumerate(self.reactions_list) if i in index
            }
        else:
            rxnsmiles_dict = {i: rxnsmi for i, rxnsmi in enumerate(self.reactions_list)}
        print("\n" + "=" * 50)
        print("1. Geometry selection.", flush=True)
        print("=" * 50)
        start = time.time()
        if Path(self.rootdir / "prepare_temp" / "geometry_pairs_before_align.pickle").is_file():
            with open(
                self.rootdir / "prepare_temp" / "geometry_pairs_before_align.pickle", "rb"
            ) as handle:
                geometry_pairs = pickle.load(handle)
        else:
            geometry_pairs = get_geometry_pairs(
                rxnsmiles_dict,
                workdir,
                self.df,
                self.slab,
                self.fix_indices,
                slab_deform_threshold=self.slab_deform_threshold,
                max_num_groups=max_num_groups,
                energy_cutoff=energy_cutoff,
                distance_cutoff=distance_cutoff,
                reduce_method=reduce_method,
                num_kmeans=num_kmeans,
            )
            Path(self.rootdir / "prepare_temp").mkdir(parents=True, exist_ok=True)
            with open(
                self.rootdir / "prepare_temp" / "geometry_pairs_before_align.pickle", "wb"
            ) as handle:
                pickle.dump(geometry_pairs, handle, protocol=pickle.HIGHEST_PROTOCOL)
        print(f"\nGeometry selection done: {time.time() - start:0.3f} sec", flush=True)

        print("\n" + "=" * 50)
        print("2. FS-to-IS alignment", flush=True)
        print("=" * 50)
        print(f"Total number of pairs: {len(geometry_pairs)}", flush=True)
        if autopara_info is not None:
            print(
                f"FS-to-IS Alignment is parallelized over {autopara_info.num_python_subprocesses} cores."
            )
        start = time.time()
        if Path(self.rootdir / "prepare_temp" / "align_output.pickle").is_file():
            with open(self.rootdir / "prepare_temp" / "align_output.pickle", "rb") as handle:
                aligned = pickle.load(handle)
        else:
            in_config = ConfigSet(geometry_pairs)
            output = improve_alignment(
                in_config.groups(),
                OutputSpec(),
                slab=self.slab,
                fix_indices=self.fix_indices,
                return_all=return_all,
                autopara_info=autopara_info,
                verbose=verbose,
            )
            with open(self.rootdir / "prepare_temp" / "align_output.pickle", "wb") as handle:
                pickle.dump(output.items, handle, protocol=pickle.HIGHEST_PROTOCOL)
            aligned = output.items
        print(f"\nAlignment done : {time.time() - start:0.3f} sec", flush=True)

        # Make empty template dict
        interpolations = {}
        filtered_interpolations = {}
        aligned = [pair for pair in aligned if len(pair) != 0]
        for geom_pairs in aligned:
            identifier = json.loads(geom_pairs[0][0][0].info["identifier"])
            for empty_dict in [interpolations, filtered_interpolations]:
                if identifier["rxn"] not in empty_dict:
                    empty_dict[identifier["rxn"]] = {}
                if identifier["map"] not in empty_dict[identifier["rxn"]]:
                    empty_dict[identifier["rxn"]][identifier["map"]] = {}

        # Fill in interpolation dict
        for geom_pairs in aligned:
            for symop_i, symops in enumerate(geom_pairs):
                for permute_i, images in enumerate(symops):
                    identifier = json.loads(images[0].info["identifier"])
                    identifier["symop"] = symop_i
                    identifier["permute"] = permute_i
                    interpolations[identifier["rxn"]][identifier["map"]][
                        f"{identifier['IS']}_{identifier['FS']}_{identifier['symop']}_{identifier['permute']}"
                    ] = images
        for rxni, map_dict in interpolations.items():
            for map_i, images_dict in map_dict.items():
                active_bonds = images_dict[list(images_dict.keys())[0]][-1].info["active_bonds"]
                filtered_interpolations[rxni][map_i] = filter_geometry_pairs(
                    images_dict.copy(),
                    active_bonds,
                    max_num_pairs=max_num_pairs,
                    verbose=True,
                )

        with open(self.rootdir / "prepare_temp" / "filtered_interpolations.pickle", "wb") as handle:
            pickle.dump(filtered_interpolations, handle, protocol=pickle.HIGHEST_PROTOCOL)
        #        with open(self.rootdir / "filtered_interpolations.pickle", "rb") as handle:
        #            filtered_interpolations = pickle.load(handle)
        print("\n" + "=" * 50)
        print("3. Geometry relaxation")
        print("=" * 50)
        if self.remote_info is not None:
            print(
                f"Geometry relaxation will be submitted to {self.remote_info.sys_name}.", flush=True
            )
        start = time.time()
        modified = {}
        original_FS = {}
        for rxni, map_dict in filtered_interpolations.items():
            for map_i, images_dict in map_dict.items():
                for key, images in images_dict.items():
                    IS_i, FS_i, symop_i, _ = tuple(map(int, key.split("_")))
                    mod_key = (rxni, map_i, IS_i, FS_i, symop_i)
                    fs_key = (rxni, map_i, FS_i)
                    if mod_key in modified:
                        continue
                    modified_final = images[-1].copy()
                    modified_final.info["aligned"] = True
                    identifier = json.loads(modified_final.info["identifier"])
                    identifier["symop"] = symop_i
                    modified_final.info["identifier"] = json.dumps(identifier)
                    modified[mod_key] = modified_final
                    if fs_key not in original_FS:
                        images[-1].info["aligned"] = False
                        original_FS[fs_key] = images[-1]

        to_optimize = list(original_FS.values()) + list(modified.values())

        inconfig = ConfigSet(to_optimize)
        outconfig = OutputSpec(self.rootdir / "prepare_temp" / aligned_filename)

        self.remote_info.job_name = "optimization"
        self.remote_info.num_inputs_per_queued_job = len(to_optimize)
        output = wfloptimize(
            inconfig,
            outconfig,
            calculator=self.calculator_tuple,
            fmax=fmax,
            traj_subselect="last_converged",
            verbose=False,
            update_config_type="overwrite",
            autopara_info=AutoparaInfo(
                num_python_subprocesses=1,
                num_inputs_per_python_subprocess=len(to_optimize),
                remote_info=self.remote_info,
            ),
        )
        print(f"\nGeometry relaxation done : {time.time() - start:0.3f} sec")
        #        raise
        finals_list = read(output.items, ":")
        original_IS = {}
        original_FS = {}  # original_FS is redefined: Now there should be energy info
        for initial, final in geometry_pairs:
            key_rxn_map_IS = tuple(
                [val for key, val in json.loads(initial.info["identifier"]).items() if key != "FS"]
            )
            original_IS[key_rxn_map_IS] = initial

        for at in finals_list:
            if not at.info["aligned"]:
                identifier = json.loads(at.info["identifier"])
                key_rxn_map_FS = tuple([val for key, val in identifier.items() if key != "IS"])
                identifier["symop"] = -1
                at.info["identifier"] = json.dumps(identifier)
                original_FS[key_rxn_map_FS] = at

        aligned_geometry_pairs = []
        for modified_final in finals_list:
            if modified_final.info["aligned"]:
                active_bonds = modified_final.info["active_bonds"]
                identifier = json.loads(modified_final.info["identifier"])
                key_rxn_map_IS = tuple(
                    [v for k, v in identifier.items() if k != "FS" and k != "symop"]
                )
                key_rxn_map_FS = tuple(
                    [v for k, v in identifier.items() if k != "IS" and k != "symop"]
                )
                initial = original_IS[key_rxn_map_IS]
                initial.info["active_bonds"] = json.dumps(active_bonds)
                energy_diff = np.abs(
                    original_FS[key_rxn_map_FS].info[energy_key] - modified_final.info[energy_key]
                )

                if energy_diff < energy_threshold:
                    # print(f'good {energy_diff}')
                    aligned_geometry_pairs.append([initial, modified_final])
                else:
                    print(
                        f"Energy difference is larger than threshold value : {energy_diff:0.2f} > {energy_threshold}!"
                    )
                    aligned_geometry_pairs.append([initial, original_FS[key_rxn_map_FS]])

        with open(
            self.rootdir / "prepare_temp" / "geometry_pairs_after_align.pickle", "wb"
        ) as handle:
            pickle.dump(aligned_geometry_pairs, handle, protocol=pickle.HIGHEST_PROTOCOL)
        #        with open(self.rootdir / "geometry_pair_dict.pickle", "rb") as handle:
        #            geometry_pair_dict = pickle.load(handle)

        print("\n" + "=" * 50)
        print("4. Index permutation")
        print("=" * 50)
        print(
            f"Interpolation will be generated with {numimages + 2} images including intial and final."
        )
        if autopara_info is not None:
            print(
                f"Index permutation is parallelized over {autopara_info.num_python_subprocesses} cores."
            )

        start = time.time()
        interpolations_dict = apply_permutation_interpolate(
            aligned_geometry_pairs,
            self.slab_indices,
            self.slab_constraints,
            numimages=numimages,
            #            max_num_interpolations_per_mapping=max_num_interpolations_per_mapping,
            max_num_permutation=max_num_permutation,
            autopara_info=autopara_info,
        )

        sort_and_write_interpolations(
            interpolations_dict,
            workdir,
            max_num_interpolations_per_mapping=max_num_interpolations_per_mapping,
        )
        print(f"\nIndex permutation done : {time.time() - start:0.3f} sec")

    def run_neb(self, workdirs=[], **neb_params):
        """
        Run NEB (Nudged Elastic Band) calculation.

        Parameters
        ----------
        workdirs : list of Path, optional
            List of working directories to use.
        **neb_params : dict
            Additional parameters for NEB calculation. All parameters are the same as ASE except following.
            - traj_subselect: str, optional
                Subselection of trajectory frames. specific to wfl package. Default is "last".
            - update_config_type: str, optional
                Type of configuration update: specific to wfl package. Default is "overwrite".
            - adjust_k: bool, optional
                Whether to adjust spring constants during optimization.
            - switch_climb: bool, optional
                Whether to switch to climbing image during optimization.
            - no_climb_step: int, optional
                Number of steps without climbing.
            - no_climb_fmax: float, optional
                Maximum force for non-climbing images.
            - climb_fmax: float, optional
                Maximum force for climbing images.
            - climb_step: int, optional
                Number of steps for climbing image.
            - pre_relax_fmax: float, optional
                Maximum force for pre-relaxation.
            - logfile: str, optional
                Path to the logfile.
        """
        if "adjust_k" in neb_params.keys() and neb_params["adjust_k"]:
            neb_params["attach_kwargs"] = {
                "attach_function": adjust_spring_constants,
                "k_max": 4.0,
                "k_min": 0.1,
            }
            neb_params["attach_interval"] = 40
            del neb_params["adjust_k"]
        neb_params["abort_check"] = AbortOnOscillation()
        neb_params["slab_indices"] = self.slab_indices

        workdir = Path(self.rootdir / "2_NEB")
        if len(workdirs) == 0:
            for subdir in Path(self.rootdir / "2_NEB").glob("*/[!backup]*/"):
                workdirs.append(subdir)

        list_of_images = []
        output_files = []
        for i, workdir in enumerate(workdirs):
            images = read(workdir / "idpp_interpolated.xyz", ":")
            for at in images:
                at.constraints = [FixAtoms(indices=self.fix_indices)]
            list_of_images.append(images)
            output_files.append(workdir / "NEB_climb.xyz")

        in_file = ConfigSet(list_of_images)
        out_files = OutputSpec(output_files)
        if self.remote_info is not None:
            self.remote_info.job_name = "neb"
            self.remote_info.resources.max_time = 24 * 3600

        start = time.time()
        wflNEB(
            in_file.groups(),
            out_files,
            calculator=self.calculator_tuple,
            autopara_info=AutoparaInfo(
                num_python_subprocesses=len(list_of_images),
                num_inputs_per_python_subprocess=1,
                remote_info=self.remote_info,
            ),
            **neb_params,
        )
        print(f"NEB calculation : {(time.time() - start) / 3600:0.3f} hr")

    def get_results(
        self,
        isolated_minhop_dir="0_isolated_adsorbates",
        dimer_minhop_dir="1_two_adsorbates",
        neb_dir="2_NEB",
        minhop_filename="minhop.xyz",
        neb_filename="NEB_climb.xyz",
        config_type="minhop_min",
        threshold=1.6,
        mult=1.5,
        disable_filter=[],
        verbose=False,
    ):
        """
        Get results from minima hopping and NEB calculations.

        Parameters
        ----------
        isolated_minhop_dir : str, optional
            Directory for isolated minima hopping results.
        dimer_minhop_dir : str, optional
            Directory for dimer minima hopping results.
        neb_dir : str, optional
            Directory for NEB results.
        minhop_filename : str, optional
            Filename for minima hopping results.
        neb_filename : str, optional
            Filename for NEB results.
        config_type : str, optional
            Type of configuration to use for minima hopping.
        threshold : float, optional
            Threshold for filtering slab deformation.
        mult : float, optional
            Multiplicative factor for filtering desorbed adsorbate.
        disable_filter : list, optional
            List of filters to disable.
        verbose : bool, optional
            Whether to print verbose output.
        """
        isolated_minhop_results = {}
        for subdir in Path(self.rootdir / isolated_minhop_dir).glob("*/"):
            #            print(f"{subdir = }")
            minhop_key = self.df.loc[self.df.path == str(subdir)].smiles.item()
            traj = read(subdir / minhop_filename, ":")
            traj = filter_minhop(
                traj,
                self.slab,
                self.fix_indices,
                config_type=config_type,
                threshold=threshold,
                mult=mult,
                disable_filter=disable_filter,
                verbose=verbose,
            )
            isolated_minhop_results[minhop_key] = traj
        self.isolated_minhop_results = isolated_minhop_results

        dimer_minhop_results = {}
        for subdir in Path(self.rootdir / dimer_minhop_dir).glob("*/"):
            #            print(f"{subdir = }")
            minhop_key = self.df.loc[self.df.path == str(subdir)].smiles.item()
            traj = read(subdir / minhop_filename, ":")
            traj = filter_minhop(
                traj,
                self.slab,
                self.fix_indices,
                config_type=config_type,
                threshold=threshold,
                mult=mult,
                disable_filter=disable_filter,
                verbose=verbose,
            )
            dimer_minhop_results[minhop_key] = traj
        self.dimer_minhop_results = dimer_minhop_results

        neb_results = {}
        if neb_dir == "2_NEB":
            for rxndir in Path(self.rootdir / neb_dir).glob("*/"):
                #                print(f"{rxndir = }")
                rxni = str(rxndir).split("/")[-1]
                reaction_dict = {}
                for subdir in rxndir.glob("[!backup]*/"):
                    #                    print(f"{subdir = }")
                    key = str(subdir).split("/")[-1]
                    if Path(subdir / neb_filename).is_file():
                        images = read(subdir / neb_filename, ":")
                        if check_neb_convergence(images):
                            reaction_dict[key] = images
                neb_results[rxni] = reaction_dict

            self.neb_results = neb_results

        elif neb_dir == "3_OCP_benchmark":
            reaction_dict = {}
            for subdir in Path(self.rootdir / neb_dir).glob("[!backup]*/"):
                #                print(f"{subdir = }")
                key = str(subdir).split("/")[-1]
                if Path(subdir / neb_filename).is_file():
                    images = read(subdir / neb_filename, ":")
                    if check_neb_convergence(images):
                        reaction_dict[int(key)] = images
            self.neb_results = reaction_dict

    def run(self, operations, args, params):
        """
        Run specified operations.

        Parameters
        ----------
        operations : list
            List of operations to perform.
        args : Namespace
            Command line arguments.
        params : dict
            Parameters for each operation.
        """
        run_map = {
            "isolated": lambda: self.run_isolated_minima_hopping(
                index=args.index, submit=args.nosubmit, **params["minhop1"]
            ),
            "dimers": lambda: self.run_dimer_minima_hopping(
                index=args.index, submit=args.nosubmit, **params["minhop2"]
            ),
            "prepare": lambda: self.prepare_neb(index=args.index, **params["prepare"]),
            "neb": lambda: self.run_neb(**params["neb"]),
        }
        for r in args.run:
            run_map[r]()
