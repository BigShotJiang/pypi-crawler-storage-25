"""
Use autoadsorbate for geometry generation.
"""

import numpy as np
from pathlib import Path
from typing import List
from itertools import combinations


from ase import Atoms
from ase.io import write, read
from ase.geometry import find_mic
from rdkit import Chem, RDLogger
from rdkit.Chem import AllChem
from autoadsorbate import Fragment

from nebscape.minhop_helpers import apply_constraints, tag_atoms, align_index_compounds
from ase.constraints import Hookean

from autoadsorbate import Surface
from types import SimpleNamespace
from joblib import Parallel, delayed

DEFAULTS = {
    "to_initialize": 2,
    "site_index": "all",
    "sample_rotation": True,
    "mode": "all",
    "conformers_per_site_cap": 2,
    "overlap_thr": 1.6,
    "distance_cutoff": 4.5,
    "mode2": "all",
    "conformers_per_site_cap2": 1,
    "parallel": None,
}


def get_unique_smiles_from_reaction_list(
    reaction_list_file: str | List[str],
) -> List[str]:  # numpydoc ignore=PR01,RT01
    """
    Read a reaction list file and extract unique individual SMILES in order.
    """
    unique_smiles = []

    reactions = []
    if isinstance(reaction_list_file, str):
        with open(reaction_list_file, "r", encoding="utf-8") as handle:
            for raw_line in handle:
                line = raw_line.strip()
                if not line:
                    continue
                reactions.append(line)

    elif isinstance(reaction_list_file, list):
        reactions = reaction_list_file

    for line in reactions:
        for side in line.split(">>"):
            for smiles in side.split("."):
                smiles = smiles.strip()
                if smiles and smiles not in unique_smiles:
                    unique_smiles.append(smiles)

    return unique_smiles


def _mol_to_prefixed_smiles(mol: Chem.Mol, cl_idx: int, anchor_idx: int) -> str:
    """
    Reorder a molecule so the surrogate marker is atom 0 and the anchor is atom 1.
    """
    fixed_order = [cl_idx, anchor_idx]
    fixed_order.extend(i for i in range(mol.GetNumAtoms()) if i not in {cl_idx, anchor_idx})
    reordered = Chem.RenumberAtoms(mol, fixed_order)
    return Chem.MolToSmiles(reordered, canonical=False)


def _mol_to_bidentate_prefixed_smiles(
    mol: Chem.Mol,
    s0_idx: int,
    s1_idx: int,
    anchor_idx: int,
) -> str:
    """
    Reorder a molecule so the two S surrogate markers are atoms 0 and 1.
    """
    fixed_order = [s0_idx, s1_idx, anchor_idx]
    fixed_order.extend(i for i in range(mol.GetNumAtoms()) if i not in {s0_idx, s1_idx, anchor_idx})
    reordered = Chem.RenumberAtoms(mol, fixed_order)
    return Chem.MolToSmiles(reordered, canonical=False, kekuleSmiles=True)


def _canonical_surrogate_key(smiles: str) -> str:
    """
    Canonicalize a surrogate SMILES for duplicate detection.
    """
    mol = Chem.MolFromSmiles(smiles)
    if mol is None:
        return smiles
    return Chem.MolToSmiles(mol, canonical=True, kekuleSmiles=True)


def _smiles_generates_3d(smiles: str, random_seed: int = 2104) -> bool:
    """
    Return True when RDKit can embed at least one 3D conformer for a SMILES.
    """
    mol = Chem.MolFromSmiles(smiles)
    if mol is None:
        return False

    mol = Chem.AddHs(mol)
    params = AllChem.ETKDGv3()
    params.randomSeed = random_seed
    params.useRandomCoords = True
    params.numThreads = 0
    conf_ids = AllChem.EmbedMultipleConfs(mol, numConfs=1, params=params)
    return len(conf_ids) > 0


def _sanitize_rw_mol(rw_mol: Chem.RWMol):
    mol = rw_mol.GetMol()
    try:
        Chem.SanitizeMol(mol)
    except Exception:
        return None
    return mol


def _soften_multiple_bonds(rw_mol: Chem.RWMol) -> None:
    """
    Reduce non-aromatic multiple bonds to single bonds for 3D fallback candidates.
    """
    for bond in rw_mol.GetBonds():
        if bond.GetIsAromatic():
            continue
        if bond.GetBondType() in (Chem.BondType.DOUBLE, Chem.BondType.TRIPLE):
            bond.SetBondType(Chem.BondType.SINGLE)


def _freeze_original_atoms(rw_mol: Chem.RWMol, original_atom_count: int) -> None:
    """Prevent RDKit from adding or removing implicit hydrogens on source atoms."""
    for atom_idx in range(original_atom_count):
        atom = rw_mol.GetAtomWithIdx(atom_idx)
        if atom.GetSymbol() == "H":
            continue
        atom.SetNoImplicit(True)


def _build_heavy_atom_surrogate_smiles(smiles: str, anchor_idx: int):
    """
    Build a Cl-prefixed surrogate on one heavy atom while preserving hydrogens.

    RDKit otherwise treats many hydrogens as implicit and may remove them when
    Cl is attached. Making hydrogens explicit keeps the represented adsorbate
    unchanged after autoadsorbate removes the Cl surrogate atom.
    """
    base_mol = Chem.MolFromSmiles(smiles)
    if base_mol is None:
        return None

    explicit_mol = Chem.AddHs(base_mol)
    candidates = []

    for formal_charge_delta in (0, 1):
        candidate = Chem.RWMol(explicit_mol)
        _freeze_original_atoms(candidate, explicit_mol.GetNumAtoms())
        cl_idx = candidate.AddAtom(Chem.Atom("Cl"))
        candidate.AddBond(cl_idx, anchor_idx, Chem.BondType.SINGLE)

        anchor = candidate.GetAtomWithIdx(anchor_idx)
        anchor.SetFormalCharge(anchor.GetFormalCharge() + formal_charge_delta)
        anchor.SetNoImplicit(True)
        candidates.append((candidate, cl_idx, anchor_idx))

    dative = Chem.RWMol(explicit_mol)
    _freeze_original_atoms(dative, explicit_mol.GetNumAtoms())
    dative_cl_idx = dative.AddAtom(Chem.Atom("Cl"))
    dative.AddBond(anchor_idx, dative_cl_idx, Chem.BondType.DATIVE)
    candidates.append((dative, dative_cl_idx, anchor_idx))

    for candidate_rw_mol, candidate_cl_idx, candidate_anchor_idx in candidates:
        mol = _sanitize_rw_mol(candidate_rw_mol)
        if mol is not None:
            return _mol_to_prefixed_smiles(
                mol,
                candidate_cl_idx,
                candidate_anchor_idx,
            )

    return None


def _build_h_surrogate_smiles(smiles: str):
    base_mol = Chem.MolFromSmiles(smiles)
    if base_mol is None:
        return None

    base_mol = Chem.AddHs(base_mol)
    h_candidates = []

    for atom in base_mol.GetAtoms():
        if atom.GetSymbol() != "H":
            continue
        has_heavy_neighbor = any(neighbor.GetSymbol() != "H" for neighbor in atom.GetNeighbors())
        h_candidates.append((0 if has_heavy_neighbor else 1, atom.GetIdx()))

    for _, anchor_idx in sorted(h_candidates):
        rw_mol = Chem.RWMol(base_mol)
        cl_idx = rw_mol.AddAtom(Chem.Atom("Cl"))
        rw_mol.AddBond(cl_idx, anchor_idx, Chem.BondType.SINGLE)
        anchor = rw_mol.GetAtomWithIdx(anchor_idx)
        anchor.SetFormalCharge(anchor.GetFormalCharge() + 1)

        mol = _sanitize_rw_mol(rw_mol)
        if mol is not None:
            return _mol_to_prefixed_smiles(mol, cl_idx, anchor_idx)

    return None


def _build_bidentate_surrogate_smiles(smiles: str, anchor_pair):
    """
    Build an S1S-prefixed surrogate on a pair of heavy atoms.

    The two S atoms are temporary markers used by autoadsorbate for bidentate
    placement. Conservative candidates are tried first and must also produce a
    3D RDKit embedding. If they do not, softened candidates with multiple bonds
    reduced to single bonds are tried as a fallback.
    """
    base_mol = Chem.MolFromSmiles(smiles)
    if base_mol is None:
        return None

    explicit_mol = Chem.AddHs(base_mol)
    anchor0_idx, anchor1_idx = anchor_pair
    candidates = []

    for soften_bonds in (False, True):
        for formal_charge_deltas in ((0, 0), (1, 0), (0, 1), (1, 1)):
            candidate = Chem.RWMol(explicit_mol)
            _freeze_original_atoms(candidate, explicit_mol.GetNumAtoms())

            if soften_bonds:
                _soften_multiple_bonds(candidate)

            s0_idx = candidate.AddAtom(Chem.Atom("S"))
            s1_idx = candidate.AddAtom(Chem.Atom("S"))
            candidate.AddBond(s0_idx, s1_idx, Chem.BondType.SINGLE)
            candidate.AddBond(s0_idx, anchor0_idx, Chem.BondType.SINGLE)
            candidate.AddBond(s1_idx, anchor1_idx, Chem.BondType.SINGLE)

            anchor0 = candidate.GetAtomWithIdx(anchor0_idx)
            anchor1 = candidate.GetAtomWithIdx(anchor1_idx)
            anchor0.SetFormalCharge(anchor0.GetFormalCharge() + formal_charge_deltas[0])
            anchor1.SetFormalCharge(anchor1.GetFormalCharge() + formal_charge_deltas[1])
            candidates.append((soften_bonds, candidate, s0_idx, s1_idx, anchor1_idx))

    valid_without_3d = []
    for require_softened in (False, True):
        for (
            softened,
            candidate_rw_mol,
            candidate_s0_idx,
            candidate_s1_idx,
            candidate_anchor_idx,
        ) in candidates:
            if softened != require_softened:
                continue

            mol = _sanitize_rw_mol(candidate_rw_mol)
            if mol is None:
                continue

            surrogate_smiles = _mol_to_bidentate_prefixed_smiles(
                mol,
                candidate_s0_idx,
                candidate_s1_idx,
                candidate_anchor_idx,
            )
            if _smiles_generates_3d(surrogate_smiles):
                return surrogate_smiles

            valid_without_3d.append(surrogate_smiles)

    if valid_without_3d:
        return valid_without_3d[0]

    return None


def _get_monodentate_surrogates_for_smiles(smiles: str):
    mol = Chem.MolFromSmiles(smiles)
    if mol is not None:
        heavy_atom_indices = [atom.GetIdx() for atom in mol.GetAtoms() if atom.GetSymbol() != "H"]
    else:
        heavy_atom_indices = []

    generated = []
    seen = set()

    for anchor_idx in heavy_atom_indices:
        surrogate_smiles = _build_heavy_atom_surrogate_smiles(smiles, anchor_idx)
        if surrogate_smiles is None or surrogate_smiles in seen:
            continue
        generated.append((mol.GetAtomWithIdx(anchor_idx).GetSymbol(), surrogate_smiles))
        seen.add(surrogate_smiles)

    if not generated:
        surrogate_smiles = _build_h_surrogate_smiles(smiles)
        if surrogate_smiles is not None and surrogate_smiles not in seen:
            generated.append(("H", surrogate_smiles))
            seen.add(surrogate_smiles)

    return generated


def _get_bidentate_surrogates_for_smiles(smiles: str):
    mol = Chem.MolFromSmiles(smiles)
    if mol is not None:
        heavy_atom_indices = [atom.GetIdx() for atom in mol.GetAtoms() if atom.GetSymbol() != "H"]
    else:
        heavy_atom_indices = []

    generated = []
    seen = set()

    for anchor_pair in combinations(heavy_atom_indices, 2):
        surrogate_smiles = _build_bidentate_surrogate_smiles(
            smiles,
            anchor_pair,
        )
        if surrogate_smiles is None:
            continue

        surrogate_key = _canonical_surrogate_key(surrogate_smiles)
        if surrogate_key in seen:
            continue

        anchor_symbols = tuple(
            mol.GetAtomWithIdx(anchor_idx).GetSymbol() for anchor_idx in anchor_pair
        )
        generated.append((anchor_symbols, surrogate_smiles))
        seen.add(surrogate_key)

    return generated


def get_preferred_surrogate_smiles(
    smiles_list: List[str],
    print_output: bool = False,
) -> List[str]:  # numpydoc ignore=PR01,RT01
    """
    Build surrogate SMILES by anchoring on every heavy atom in each molecule.

    Hydrogens are only used as fallback when the species contains no heavy atoms.
    """
    out_smiles = []

    RDLogger.DisableLog("rdApp.error")
    RDLogger.DisableLog("rdApp.warning")
    try:
        for smiles in smiles_list:
            generated = _get_monodentate_surrogates_for_smiles(smiles)

            if print_output:
                if not generated:
                    print(f"{smiles} -> failed")
                for anchor_symbol, surrogate_smiles in generated:
                    print(f"{smiles} -> {surrogate_smiles}")
                    print(f"  anchor: {anchor_symbol}")

            out_smiles.extend([surrogate_smiles for _, surrogate_smiles in generated])
    finally:
        RDLogger.EnableLog("rdApp.error")
        RDLogger.EnableLog("rdApp.warning")

    return out_smiles


def get_bidentate_surrogate_smiles(
    smiles_list: List[str],
    print_output: bool = False,
) -> List[str]:  # numpydoc ignore=PR01,RT01
    """
    Build S1S surrogate SMILES by anchoring on every heavy-atom pair.
    """
    out_smiles = []

    RDLogger.DisableLog("rdApp.error")
    RDLogger.DisableLog("rdApp.warning")
    try:
        for smiles in smiles_list:
            generated = _get_bidentate_surrogates_for_smiles(smiles)

            if print_output:
                if not generated:
                    print(f"{smiles} -> skipped")
                for anchor_symbols, surrogate_smiles in generated:
                    print(f"{smiles} -> {surrogate_smiles}")
                    print(f"  anchors: {anchor_symbols[0]}-{anchor_symbols[1]}")

            out_smiles.extend([surrogate_smiles for _, surrogate_smiles in generated])
    finally:
        RDLogger.EnableLog("rdApp.error")
        RDLogger.EnableLog("rdApp.warning")

    return out_smiles


def get_all_surrogate_smiles(
    reaction_smiles_file: str | List[str],
    include_monodentate: bool = True,
    include_bidentate: bool = True,
    print_output: bool = False,
) -> dict[str, list]:  # numpydoc ignore=PR01,RT01
    """
    Build monodentate and bidentate surrogate SMILES for each species.
    """
    smiles_list = get_unique_smiles_from_reaction_list(reaction_smiles_file)

    out_smiles = {}

    RDLogger.DisableLog("rdApp.error")
    RDLogger.DisableLog("rdApp.warning")
    try:
        for smiles in smiles_list:
            generated = []

            if include_monodentate:
                monodentate = _get_monodentate_surrogates_for_smiles(smiles)
                generated.extend(
                    ("monodentate", anchor_symbol, surrogate_smiles)
                    for anchor_symbol, surrogate_smiles in monodentate
                )

            if include_bidentate:
                bidentate = _get_bidentate_surrogates_for_smiles(smiles)
                generated.extend(
                    ("bidentate", anchor_symbols, surrogate_smiles)
                    for anchor_symbols, surrogate_smiles in bidentate
                )

            if print_output:
                if not generated:
                    print(f"{smiles} -> skipped")
                for denticity, anchor_info, surrogate_smiles in generated:
                    print(f"{smiles} -> {surrogate_smiles}")
                    if denticity == "monodentate":
                        print(f"  mode: monodentate; anchor: {anchor_info}")
                    else:
                        print(f"  mode: bidentate; anchors: {anchor_info[0]}-{anchor_info[1]}")

            out_smiles[smiles] = [surrogate_smiles for _, _, surrogate_smiles in generated]

    finally:
        RDLogger.EnableLog("rdApp.error")
        RDLogger.EnableLog("rdApp.warning")

    # filter out dative bond if there's alternative
    # Otherwise, just keep it.
    for smi, sursmi_list in out_smiles.items():
        if len(sursmi_list) != 1:
            out_smiles[smi] = [sursmi for sursmi in sursmi_list if "<-" not in sursmi]

    return out_smiles


def ensure_fragments(
    fragment_inputs,
    fragment_cls,
    to_initialize: int = 10,
    random_seed: int = 2104,
    sort_conformers: bool = False,
    prune_rms_thresh: float = 0.5,
):  # numpydoc ignore=PR01,RT01
    """
    Normalize strings or Fragment objects to a list of Fragment objects.
    """
    fragments = []

    for fragment_input in fragment_inputs:
        if isinstance(fragment_input, fragment_cls):
            fragments.append(fragment_input)
            continue

        if isinstance(fragment_input, str):
            fragments.append(
                fragment_cls(
                    fragment_input,
                    to_initialize=to_initialize,
                    random_seed=random_seed,
                    sort_conformers=sort_conformers,
                    prune_rms_thresh=prune_rms_thresh,
                )
            )
            continue

        raise TypeError(
            "fragment_inputs must contain Fragment objects or SMILES strings. "
            f"Received {type(fragment_input).__name__}."
        )

    return fragments


def prepare_adsorbed_structure_tags(
    atoms: Atoms, slab_template: Atoms
) -> Atoms:  # numpydoc ignore=PR01,RT01
    """
    Copy slab tags onto an adsorbed structure before writing extxyz output.

    Fixed/mobile semantics are represented only through tags: slab template
    tags are preserved and adsorbate atoms are marked as tag 1.
    """
    prepared = atoms.copy()
    slab_atom_count = len(slab_template)
    slab_tags = np.array(slab_template.get_tags(), dtype=int)

    if len(prepared) < slab_atom_count:
        raise ValueError(
            "Adsorbed structure has fewer atoms than the slab template. Cannot propagate slab tags."
        )

    adsorbate_count = len(prepared) - slab_atom_count
    prepared_tags = np.concatenate([slab_tags, np.ones(adsorbate_count, dtype=int)])
    prepared.set_tags(prepared_tags)

    if "fragments" in prepared.arrays:
        del prepared.arrays["fragments"]

    prepared.set_constraint()

    return prepared


def write_adsorbed_trajectory(
    trajectory,
    slab_template: Atoms,
    filename: str = "adsorbed_species.extxyz",
):  # numpydoc ignore=GL08
    prepared_trajectory = [
        prepare_adsorbed_structure_tags(atoms, slab_template) for atoms in trajectory
    ]
    write(Path(filename), prepared_trajectory, format="extxyz")
    return prepared_trajectory


def prepare_isolated_autoadsorbate(
    rootdir,
    molecules,
    slab,
    surrogate_smiles_dict,
    overwrite=False,
    fix_indices=None,
    k=4,
    input_filename="initial_structures.xyz",
    verbose=False,
    **kwargs,
):
    """
    Generate isolated adsorbate structures on a surface slab.

    This function prepares adsorption configurations by placing individual
    adsorbate fragments onto adsorption sites of a pristine slab surface.
    Generated structures are symmetry-reduced, constrained, and written
    to disk for subsequent geometry relaxation workflows.

    Parameters
    ----------
    rootdir : str or pathlib.Path
        Root directory where generated adsorption structures and outputs
        will be stored.

    molecules : dict
        Dictionary mapping SMILES strings to Molecule objects.

    slab : ase.Atoms
        Surface slab structure used as the adsorption substrate.

    surrogate_smiles_dict : dict
        Dictionary mapping molecule SMILES strings to lists of surrogate
        SMILES representations used to initialize Fragment objects.

    overwrite : bool, optional
        If False, existing structure files are reused instead of regenerated
        (default is False).

    fix_indices : list of int or None, optional
        Atom indices in the slab to constrain during relaxation.
        If None, indices are inferred from slab atom tags where tag == 0
        (default is None).

    k : float, optional
        Spring constant for Hookean constraints applied to relaxable
        slab atoms (default is 4).

    input_filename : str, optional
        Filename used to store generated initial structures
        (default is "initial_structures.xyz").

    verbose : bool, optional
        If True, print detailed progress information during structure
        generation (default is False).

    **kwargs
        Additional keyword arguments forwarded to
        ``Surface.get_populated_sites()``.

        Commonly used options include:

        - ``to_initialize`` : int
            Number of initial conformations generated per fragment.

        - ``site_index`` : str or list
            Adsorption site indices to consider.

        - ``sample_rotation`` : bool
            Whether to sample rotational orientations of adsorbates.

        - ``mode`` : str
            Placement strategy used during adsorption site population.

        - ``conformers_per_site_cap`` : int
            Maximum number of conformers generated per adsorption site.

        - ``overlap_thr`` : float
            Distance threshold used to detect overlap between adsorbates
            and slab atoms.

    Returns
    -------
    initial_structures : list of list of ase.Atoms
        Nested list containing generated isolated adsorbate structures
        for each input molecule.

    output_dir : list of pathlib.Path
        List of output file paths corresponding to generated adsorption
        structure sets.

    Notes
    -----
    - Symmetry reduction is applied to the pristine slab before adsorption
      site generation.
    - Hookean constraints are added to slab atoms not included in
      ``fix_indices`` to tether them near their original positions.
    - Metadata such as category, SMILES string, and molecular formula
      are stored in ``atoms.info`` for each generated structure.
    - Existing structures are reused when ``overwrite=False`` and the
      target input file already exists.
    """
    autoads_params = {**DEFAULTS, **kwargs}
    cfg = SimpleNamespace(**autoads_params)

    rootdir = Path(rootdir)
    print("Isolated minima hopping preparation started.", flush=True)
    workdir = rootdir / "0_isolated_adsorbates"
    workdir.mkdir(exist_ok=True, parents=True)

    pristine_slab = Surface(slab)
    pristine_slab.sym_reduce()
    slab_indices = np.arange(len(slab))
    if fix_indices is None:
        fix_indices = [i for i, tag in enumerate(slab.arrays["tags"]) if tag == 0]
    #    print("symmetry reduction to pristine slab done.")

    initial_structures = []
    output_dir = []
    for i, (smi, mol) in enumerate(molecules.items()):
        formula = mol.get_formula_rdkit()
        rundir = Path(workdir / f"{str(i).zfill(2)}_{formula}")
        Path(rundir).mkdir(exist_ok=True, parents=True)

        if not overwrite and Path(rundir / input_filename).is_file():
            print("already file exists, read from there.")
            isolated_adsorbate = read(rundir / f"{input_filename}", ":")

        else:
            fragments1 = [
                Fragment(sursmi, to_initialize=cfg.to_initialize)
                for sursmi in surrogate_smiles_dict[smi]
            ]
            NumAtoms1 = len(
                [at for at in fragments1[0].conformers[0] if at.symbol != "Cl" and at.symbol != "S"]
            )

            #            print("Start binding first adsorbate on surface.")
            isolated_adsorbate = []
            for fragment1 in fragments1:
                isolated_adsorbate += pristine_slab.get_populated_sites(
                    fragment1,
                    site_index=cfg.site_index,
                    sample_rotation=cfg.sample_rotation if NumAtoms1 > 1 else False,
                    mode=cfg.mode,
                    conformers_per_site_cap=cfg.conformers_per_site_cap if NumAtoms1 > 1 else 1,
                    overlap_thr=cfg.overlap_thr,
                    verbose=verbose,
                    parallel=cfg.parallel,
                )

        isolated_adsorbate = align_index_compounds(isolated_adsorbate, slab_indices=slab_indices)
        for atoms in isolated_adsorbate:
            atoms.info["category"] = "adsorbates"
            atoms.info["SMILES"] = smi
            atoms.info["formula"] = formula
            tag_atoms(atoms, slab_indices, fix_indices)

            apply_constraints(
                atoms,
                relax_slab=True,
                constrain_Hookean=True,
                method=None,
                volatilation=True,
                fix_indices=fix_indices,
                slab_indices=slab_indices,
            )
            # Add Hookean constraint tethered to original position
            relaxed_slab_constraints = [
                Hookean(a1=i, a2=atoms[i].position, rt=0.94, k=k)
                for i in slab_indices
                if i not in fix_indices
            ]
            atoms.constraints += relaxed_slab_constraints

        if not Path(rundir / input_filename).is_file() or overwrite:
            write(workdir / f"{str(i).zfill(2)}_{formula}/{input_filename}", isolated_adsorbate)
        initial_structures.append(isolated_adsorbate)
        output_dir.append(workdir / f"{str(i).zfill(2)}_{formula}" / "minhop.xyz")

    return initial_structures, output_dir


def prepare_dimer_autoadsorbate(
    rootdir,
    reactive_states,
    slab,
    surrogate_smiles_dict,
    input_filename="initial_structures.xyz",
    overwrite=False,
    fix_indices=None,
    k=4.0,
    verbose=False,
    **kwargs,
):
    """
    Generate two adsorbates structure on a surface slab.

    This function constructs adsorption configurations containing two adsorbates
    by sequentially placing fragments on adsorption sites of a pristine slab.
    The first adsorbate is placed on the slab surface, after which valid nearby
    sites are identified for placement of the second adsorbate while avoiding
    overlap with the first. Generated structures are constrained and written
    to disk for subsequent geometry relaxation workflows.

    Parameters
    ----------
    rootdir : str or pathlib.Path
        Root directory where generated structures and outputs
        will be stored.

    reactive_states : dict
        Dictionary mapping SMILES strings to reactive state objects.
        Only entries corresponding to two-molecule systems
        (``NumMols == 2``) are considered.

    slab : ase.Atoms
        Surface slab structure used as the adsorption substrate.

    surrogate_smiles_dict : dict
        Dictionary mapping molecule SMILES strings to lists of surrogate
        SMILES representations used to initialize Fragment objects.

    input_filename : str, optional
        Filename used to store generated initial structures
        (default is ``"initial_structures.xyz"``).

    overwrite : bool, optional
        If False, existing structure files are reused instead of regenerated
        (default is False).

    fix_indices : list of int or None, optional
        Atom indices in the slab to constrain during relaxation.
        If None, indices are inferred from slab atom tags where ``tag == 0``
        (default is None).

    k : float, optional
        Spring constant for Hookean constraints applied to relaxable
        slab atoms (default is 4.0).

    verbose : bool, optional
        If True, print detailed progress information during structure
        generation (default is False).

    **kwargs
        Additional keyword arguments forwarded to adsorption-site generation
        routines.

        Commonly used options include:

        - ``site_index`` : str or list
            Adsorption site indices to consider.

        - ``distance_cutoff`` : float
            Distance cutoff for selecting candidate sites for the second
            adsorbate, measured between the center of mass of the first
            adsorbate and adsorption site coordinates.

        - ``sample_rotation`` : bool
            Whether to sample rotational orientations of adsorbates.

        - ``overlap_thr`` : float
            Distance threshold used to detect overlap between adsorbates
            and slab atoms.

        - ``mode`` : str
            Placement strategy for the first adsorbate.

        - ``mode2`` : str
            Placement strategy for the second adsorbate.

        - ``conformers_per_site_cap`` : int
            Maximum number of conformers generated per site for the first
            adsorbate.

        - ``conformers_per_site_cap2`` : int
            Maximum number of conformers generated per site for the second
            adsorbate.

        - ``parallel`` : int or None
            Number of parallel processes used during placement of the
            second adsorbate.

        - ``to_initialize`` : int
            Number of initial conformations generated per fragment.

    Returns
    -------
    initial_structures : list of list of ase.Atoms
        Nested list containing generated dimer adsorption structures
        for each reactive state.

    output_dir : list of pathlib.Path
        List of output file paths corresponding to generated adsorption
        structure sets.

    Notes
    -----
    - Symmetry reduction is applied to both pristine and intermediate
      slab structures to reduce redundant adsorption sites.
    - The second adsorbate is only placed on valid sites that do not
      overlap with atoms belonging to the first adsorbate.
    - Hookean constraints are added to slab atoms not included in
      ``fix_indices`` to tether them near their original positions.
    - Existing structures are reused when ``overwrite=False`` and the
      target input file already exists.
    - Current implementation restricts sampling in several places
      (e.g., first fragment or first generated structure only),
      which may be expanded in future versions.
    """
    autoads_params = {**DEFAULTS, **kwargs}
    cfg = SimpleNamespace(**autoads_params)

    rootdir = Path(rootdir)
    slab_indices = np.arange(len(slab))
    if fix_indices is None:
        fix_indices = [i for i, tag in enumerate(slab.arrays["tags"]) if tag == 0]
    #    print("symmetry reduction to pristine slab done.")

    reactive_states_two_molecules = [rs for smi, rs in reactive_states.items() if rs.NumMols == 2]

    initial_structures = []
    output_dir = []
    pristine_slab = Surface(slab)
    pristine_slab.sym_reduce(method="soap")

    for i, rs in enumerate(reactive_states_two_molecules):
        rundir = Path(rootdir / "1_two_adsorbates" / f"{str(i).zfill(2)}")
        rundir.mkdir(exist_ok=True, parents=True)
        if not overwrite and Path(rundir / input_filename).is_file():
            print(f"{i} already input is generated.")
            two_adsorbates = read(rundir / f"{input_filename}", ":")

        else:
            mol1, mol2 = rs.smiles.split(".")

            fragments1 = [
                Fragment(sursmi, to_initialize=cfg.to_initialize)
                for sursmi in surrogate_smiles_dict[mol1]
            ]
            fragments2 = [
                Fragment(sursmi, to_initialize=cfg.to_initialize)
                for sursmi in surrogate_smiles_dict[mol2]
            ]

            NumAtoms1 = len(
                [at for at in fragments1[0].conformers[0] if at.symbol != "Cl" and at.symbol != "S"]
            )
            NumAtoms2 = len(
                [at for at in fragments2[0].conformers[0] if at.symbol != "Cl" and at.symbol != "S"]
            )

            out_trj = []
            two_adsorbates = []
            for fragment1 in fragments1:
                out_trj += pristine_slab.get_populated_sites(
                    fragment1,
                    site_index=cfg.site_index,
                    sample_rotation=cfg.sample_rotation if NumAtoms1 > 1 else False,
                    mode=cfg.mode,
                    conformers_per_site_cap=cfg.conformers_per_site_cap if NumAtoms1 > 1 else 1,
                    overlap_thr=cfg.overlap_thr,
                    parallel=cfg.parallel,
                    verbose=verbose,
                )
                adsorbate_indices = [at.index for at in out_trj[0] if at.index not in slab_indices]

            def process_second_adsorbate(second_idx, atoms):
                """Process a single already-attached configuration."""
                if verbose:
                    print(f"{second_idx + 1} / {len(out_trj)}")

                already_attached = Surface(atoms)

                com_adsorbate = atoms.get_center_of_mass(indices=adsorbate_indices)
                indices_only_with_slab = [
                    index
                    for index, row in already_attached.site_df.iterrows()
                    if (
                        not np.any([i in adsorbate_indices for i in row["topology"]])
                        and find_mic(
                            com_adsorbate - row["coordinates"], pbc=slab.pbc, cell=slab.cell
                        )[1]
                        < cfg.distance_cutoff
                    )
                ]

                results = []
                for fragment2 in fragments2:
                    results += already_attached.get_populated_sites(
                        fragment2,
                        site_index=indices_only_with_slab,
                        sample_rotation=cfg.sample_rotation if NumAtoms2 > 1 else False,
                        mode=cfg.mode2,
                        conformers_per_site_cap=cfg.conformers_per_site_cap2
                        if NumAtoms2 > 1
                        else 1,
                        overlap_thr=cfg.overlap_thr,
                        verbose=False,
                        parallel=None,
                    )
                return results

            if cfg.parallel is not None:
                # Parallelize over out_trj; disable inner parallel to avoid over-subscription
                nested_results = Parallel(n_jobs=cfg.parallel)(
                    delayed(process_second_adsorbate)(i, atoms) for i, atoms in enumerate(out_trj)
                )
                for r in nested_results:
                    two_adsorbates += r
            else:
                for i, atoms in enumerate(out_trj):
                    two_adsorbates += process_second_adsorbate(i, atoms)

        two_adsorbates = align_index_compounds(two_adsorbates, slab_indices=slab_indices)

        for atoms in two_adsorbates:
            atoms.info["category"] = "adsorbates"
            atoms.info["SMILES"] = rs.smiles
            atoms.info["formula"] = rs.get_formula()
            tag_atoms(atoms, slab_indices, fix_indices)

            apply_constraints(
                atoms,
                relax_slab=True,
                constrain_Hookean=True,
                method=None,
                volatilation=True,
                fix_indices=fix_indices,
                slab_indices=slab_indices,
            )
            # Add Hookean constraint tethered to original position
            relaxed_slab_constraints = [
                Hookean(a1=i, a2=atoms[i].position, rt=0.94, k=k)
                for i in slab_indices
                if i not in fix_indices
            ]
            atoms.constraints += relaxed_slab_constraints

        if not Path(rundir / input_filename).is_file() or overwrite:
            write(rundir / input_filename, two_adsorbates)
        initial_structures.append(two_adsorbates)
        output_dir.append(rundir / "minhop.xyz")

    return initial_structures, output_dir
