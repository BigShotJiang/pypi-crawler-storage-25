import numpy as np
import igraph as ig

# import networkx as nx
import pandas as pd
from functools import total_ordering

# RDKIT
from collections import Counter

from rdkit import Chem
from rdkit.Chem import rdmolops
from rdkit.Chem.Descriptors import NumRadicalElectrons
from rdkit.Chem.rdMolDescriptors import CalcMolFormula
from rdkit import RDLogger

# Silenece RDKit warnings
RDLogger.DisableLog("rdApp.*")
elements = {1: "H", 6: "C", 7: "N", 8: "O"}
reversed_elements = dict(map(reversed, elements.items()))

# mdf = pd.read_json("/work/home/hjung/Softwares/reaction_network_search/molecules/n3_mol_globalmin.json")
# mdf.at[86, "smiles"] = "[C-]#[O+]"
# Mol_dict = {str(i).zfill(4) : Molecule(smi, ID=str(i).zfill(4)) for i, smi in enumerate(mdf["smiles"])}


@total_ordering
class Molecule:
    """
    Molecule object.

    This Molecule object represent a molecule in the reaction network.
    Molecule can be initiated by providing SMILES string or adjacency matrix of molecule
    as molecular information. (Check if any case adjacency matrix as input is utilized...)

    Each molecule is asssigned with ID with four digits.
    Empty site is represented as '[x]' and it has ID 0000

    Parameters
    ----------
    smiles : str
        SMILES string of a molecule.
    **kwargs : dict
        Additional keyword arguments.

    Attributes
    ----------
    smiles : str
        SMILES string corresponding to molecule
    atomic_numbers : list
        Atomic number of atoms in molecule
        (e.g. [6,1,1,1,1] for CH4)
    atomic_symbols : list
        Atomic symbol of atoms in molecule
    atom_dict : dict
        Atom dictionary with index
        (e.g. {0: 'C', 1: 'H', 2: 'H', 3: 'H', 4: 'H'} for CH4)
    connectivity : numpy array
        Adjacency matrix of molecule
    formula : str
        Molecular formula of the molecule
    stoichiometry: dict
        Stoichiometry of consituting atoms.
        (e.g. C2H6 => {"C":2, "H":6 })
    radical_electron : int
        Number of radical electrons in the molecule
    ID : str
        Identifier for molecules. 4 digits (e.g. 0003)
        ID might vary depedning on how reaction network is initialized...
    """

    fragment_number = 1

    def __init__(self, smiles, **kwargs):  ## ID or atom_dict = {}
        if smiles == "[x]":
            self.mol = None
            self.smiles = smiles
            self.atomic_numbers = []
            self.atom_dict = {}
            self.connectivity = np.empty(0)
            self.formula = ""
            self.stoichiometry = {}
            self.radical_electron = 0
            self.ID = "0000"

        else:
            # RDKIT mol object
            self.mol = Chem.AddHs(Chem.MolFromSmiles(smiles))
            self.smiles = smiles
            self.atomic_numbers = [atom.GetAtomicNum() for atom in self.mol.GetAtoms()]
            self.atomic_symbols = [atom.GetSymbol() for atom in self.mol.GetAtoms()]
            self.atom_dict = {idx: symbol for idx, symbol in enumerate(self.atomic_symbols)}
            self.connectivity = rdmolops.GetAdjacencyMatrix(self.mol)
            self.formula = self.get_formula_rdkit()
            self.stoichiometry = self.get_stoichiometry()
            self.radical_electron = NumRadicalElectrons(self.mol)
            self.ID = kwargs["ID"].zfill(4)

    def __eq__(self, other):
        return self.is_equivalent(other) and self.stoichiometry == other.stoichiometry

    def __lt__(self, other):
        return self.smiles < other.smiles

    def __hash__(self):
        return hash("M" + str(self.ID))

    def __len__(self):
        return sum(self.stoichiometry.values())

    def get_dumb_formula(self):  # numpydoc ignore=GL08
        formula = ""
        for element in sorted(list(set(list(self.atom_dict.values())))):
            if Counter(self.atom_dict.values())[element] == 1:
                formula += element
            else:
                formula += element + str(Counter(self.atom_dict.values())[element])
        #        if self.site =="gas":
        #            formula += "(g)"

        return formula

    def get_formula_rdkit(self):  # numpydoc ignore=GL08
        return CalcMolFormula(self.mol)

    def get_formula(self):  # numpydoc ignore=GL08
        if self.mol is None:
            return ""
        elif self.smiles == "O":
            # Water is assigned uniquely
            return "H2O"

        from rdkit.Chem.rdMolDescriptors import CalcNumRings

        molecule_graph = self.get_igraph()

        if CalcNumRings(self.mol) > 0:
            # If there's ring within structure just use original formula
            return self.get_dumb_formula()
        elif "C" in molecule_graph.vs["atomic_symbol"]:
            backbone_atoms = molecule_graph.vs.select(atomic_symbol="C")
        elif "N" in molecule_graph.vs["atomic_symbol"]:
            return self.get_dumb_formula()
        elif "O" in molecule_graph.vs["atomic_symbol"]:
            backbone_atoms = molecule_graph.vs.select(atomic_symbol="O")
        else:  # only hydrogens
            return self.get_dumb_formula()
            # End routine

        structural_formula = ""

        for i, backbone in enumerate(backbone_atoms):
            structural_formula += backbone["atomic_symbol"]
            H_count = 0

            # If there's carbon in the speices, carbon is backbone
            if backbone["atomic_symbol"] == "C":
                O_group = ""
                for atom in backbone.neighbors():
                    if atom["atomic_symbol"] == "H":
                        H_count += 1

                    elif atom["atomic_symbol"] == "O":
                        # print('hi')
                        num_H_in_oxygen = len(
                            [
                                at["atomic_symbol"]
                                for at in atom.neighbors()
                                if at["atomic_symbol"] == "H"
                            ]
                        )
                        if num_H_in_oxygen == 1:
                            O_group = "OH"
                        else:
                            O_group = "O"

                    elif atom["atomic_symbol"] == "C":
                        continue

                if H_count == 1:
                    structural_formula += "H"
                elif H_count >= 1:
                    structural_formula += f"H{H_count}"

                structural_formula += f"{O_group}"

            # If there's no carbon in the speices, but oxygen, oxygen is backbone
            elif backbone["atomic_symbol"] == "O":
                for atom in backbone.neighbors():
                    if atom["atomic_symbol"] == "H":
                        H_count += 1

                if H_count == 1:
                    structural_formula += "H"
                elif H_count >= 1:
                    structural_formula += f"H{H_count}"

        # print(structural_formula)
        return structural_formula

    def get_stoichiometry(self):  # numpydoc ignore=RT01
        """
        Return stoichiometry of molecule as dictionary. e.g. C2H6 => {"C":2, "H":6 }.
        """
        stoichiometry = {}

        for element in sorted(list(set(self.atom_dict.values()))):
            stoichiometry[element] = Counter(self.atom_dict.values())[element]

        return stoichiometry

    def get_igraph(self):  # numpydoc ignore=RT01
        """
        Convert molecule into ig.graph.
        """
        #        print("dummy formula : ", self.get_dumb_formula())
        graph = ig.Graph.Adjacency(self.connectivity, mode="undirected")
        graph.vs["atomic_symbol"] = self.atomic_symbols
        graph.vs["atomic_number"] = self.atomic_numbers

        return graph

    def is_equivalent(self, other):  # numpydoc ignore=RT01
        """
        Check isomorphism of molecular graph and returns whether they are the same or not.

        Parameters
        ----------
                other : Molecule
            Other molecule to compare with.
        """
        m1 = ig.Graph.Adjacency(self.connectivity, mode="undirected")
        m2 = ig.Graph.Adjacency(other.connectivity, mode="undirected")

        return m1.isomorphic_vf2(m2, color1=self.atomic_numbers, color2=other.atomic_numbers)


@total_ordering
class ReactiveState(Molecule):
    """
    Combination of one or two molecules.

    Parameters
    ----------
    first : Molecule
        First molecule.
    second : Molecule
        Second molecule. It can be empty state(e.g. [x]), if there's only one molecule in ReactiveState
    ID : str, optional
        ID of Molecule.

    Attributes
    ----------
    connectivity : numpy array
        connectivity of molecules in one numpy array.
    atomic_numbers : list
        concatenated atomic number of molecules in ReactiveState
    atomic_symbols : list
        concatenated atomic symbol of molecules in ReactiveState
    atom_dict : dict
        Atom dictionary with index
    stoichiometry : dict
        Stoichiometry of consistuting atoms.
    ID : str
        Identifier for ReactiveState. 8 digist (e.g. 00030002 or 00000005)
        concatenattion of two molecular ID.
    mols : list of Molecules
        List of consisting Molecule object. If empty site is included only non-empty site Molecule is contained.
    NumMols : int
        Number of Molecules in ReactiveState. Excluding empty site.
    smiles : str
        SMILES representation of the ReactiveState.
    """

    Mol_dict = {}

    def __init__(self, first, second=Molecule("[x]"), ID=None):
        self.first, self.second = sorted([first, second])
        # RDKIT mol object
        self.connectivity = self.get_combined_connectivity(self.first, self.second)
        self.atomic_numbers = self.first.atomic_numbers + self.second.atomic_numbers
        self.atomic_symbols = [elements[atom] for atom in self.atomic_numbers]
        self.atom_dict = {idx: symbol for idx, symbol in enumerate(self.atomic_symbols)}
        self.stoichiometry = self.get_stoichiometry()
        self.ID = "".join(sorted([first.ID, second.ID]))
        self.mols = self.get_molecules()  ## ??
        self.NumMols = len(self.mols)
        self.smiles = ".".join([mol.smiles for mol in self.get_molecules()])

    def __eq__(self, other):
        return self.is_equivalent(other) and self.stoichiometry == other.stoichiometry

    def __lt__(self, other):
        return self.smiles < other.smiles

    def __hash__(self):
        return hash("RS" + str(self.ID))

    def get_combined_connectivity(self, first, second):  # numpydoc ignore=PR01,RT01
        """
        Merge adjacency matrix of two molecule to make combined adjacency matrix for ReactiveState.

        If One of molecule is Null molecule (i.e. "[x]"), then only other molecule's connectivity is returned.
        """
        n, p = len(first.connectivity), len(second.connectivity)

        if n * p != 0:
            new = np.block(
                [
                    [first.connectivity, np.zeros((n, p))],
                    [np.zeros((p, n)), second.connectivity],
                ]
            )

            return new

        elif n:
            return first.connectivity
        else:
            return second.connectivity

    def get_formula(self):  # numpydoc ignore=RT01
        """
        Get formula for ReactiveState. (e.g.) CH3 + CH2.
        """
        formulae = [i.get_formula() for i in self.get_molecules()]
        #        formulae =  [i.get_structural_formula() for i in self.get_molecules()]

        if len(formulae) == 1:
            return formulae[0]

        else:
            return " + ".join(formulae)

    def compare_stoichiometry(self, other):  # numpydoc ignore=PR01,RT01
        """
        Compare stoichiometry between two adsorbate instances.
        """

        # it two Binary object contains different elements
        if set(self.stoichiometry.keys()) != set(other.stoichiometry.keys()):
            return False

        # if contained elements are identical
        else:
            if all(
                [
                    self.stoichiometry[key] == other.stoichiometry[key]
                    for key in self.stoichiometry.keys()
                ]
            ):
                return True
            else:
                return False

    def is_redundant(self, other):  # numpydoc ignore=PR01,RT01
        """
        Check if two ReactiveStates have identical molecule on both sides.
        """
        left = set([mol.ID for mol in self.get_molecules()])
        right = set([mol.ID for mol in other.get_molecules()])

        if len(left.intersection(right)) != 0:
            return True
        else:
            return False

    def get_molecules(self):  # numpydoc ignore=RT01
        """
        From Adsorbate instance, this returns list of two molecules instance which derives from disconnected adjacency matrix.

        This currently does not include equivalency test among molecules.
        Therefore, this result may include equivalent molecules.
        """
        #        return [self.first, self.second]

        #        first = self.Mol_dict[self.ID[:4]]
        #        second = self.Mol_dict[self.ID[4:]]
        #
        return [mol for mol in [self.first, self.second] if mol.mol is not None]


def get_canonical_rxnsmi(rxnsmi):
    """
    Get the canonical representation of a reaction SMILES string.

    There are multiple ways to represent a reaction, and this function aims to find a unique
    representation by sorting the reactants and products. strings are sorted lexicographically.
    (e.g.) A + B = C + D (canonical)
           B + A = C + D
    For association/dissociation reaction, it is converted to dissociation reaction
        (e.g.) A + B = C
               C = A + B (canonical)

    Parameters
    ----------
    rxnsmi : str
        Reaction SMILES string.

    Returns
    -------
    str
        Canonical representation of the reaction SMILES string.
    """
    left, right = [side.split(".") for side in rxnsmi.split(">>")]

    if len(left) == 2 and len(right) == 2:
        # left, right = sorted([left, right])
        left, right = sorted(left), sorted(right)
    elif len(left) == 1 and len(right) == 2:
        right = sorted(right)
        return ".".join(left) + ">>" + ".".join(right)
    elif len(left) == 2 and len(right) == 1:
        left = sorted(left)
        return ".".join(right) + ">>" + ".".join(left)
    elif len(left) == 1 and len(right) == 1:
        pass
    else:
        raise ValueError(f"{rxnsmi} this should not happen")

    canonical_rxn_1 = ".".join(left) + ">>" + ".".join(right)
    canonical_rxn_2 = ".".join(right) + ">>" + ".".join(left)

    return min(canonical_rxn_1, canonical_rxn_2)


class Reaction:
    """
    Reaction object.

    Initiated by pair of reactant (ReactiveState) and product(s) (ReactiveState).
    There can be two types of Reactions.
    1) Chemical reaction with real chemical transformation. (ID with 16 digits)
        (e.g. 'CH4O + CHO = CH2O + CH3O')
    2) Not including real chemical reaction but only stoichiometrical connection. (ID with 24 digits)
        (e.g. 'CH4O + CH2O = CH4O* + CH2O*)

    Parameters
    ----------
    reactant : ReactiveState
        ReactiveState
    *product : tuple of ReactiveState
        tuple of ReactiveStates

    Attributes
    ----------
    rxnsmiles: str
        Reaction represented by SMILES string.
    ID: str
        Identifier for Reaction. 16 or 24 digits.
    stoichiometry: dict
        Stoichiometry of reactants and products.
    catmap_label: str
        CatMap label for the reaction.
    rate: float
        Reaction rate.
    forward_rate: float
        Forward reaction rate.
    reverse_rate: float
        Reverse reaction rate.
    """

    def __init__(self, reactant, *product):
        self.reactant = (reactant,)
        self.product = product
        if len(self.product) != 2:
            if self.reactant[0].NumMols == self.product[0].NumMols:
                self.reactant, self.product = sorted([self.reactant, self.product])
            elif self.reactant[0].NumMols > self.product[0].NumMols:
                self.reactant, self.product = self.product, self.reactant

        self.rxnsmiles = self.get_rxn_smiles()
        self.ID = "".join([r.ID for r in self.reactant]) + "".join([p.ID for p in self.product])
        self.stoichiometry_dict = None
        self.catmap_label = None
        self.rate = None
        self.forward_rate = None
        self.reverse_rate = None
        #        self.rxnsmiles = ">>".join([self.reactant.smiles, self.product.smiles])
        #        self.TS_expression = self.get_catmap_TS_expression()
        # self.passingmolecule = None if self.

        if not self.compare_stoichiometry():
            raise Exception("Stoichiometry is not balanced !")

    def __eq__(self, other):
        return self.reactant == other.reactant and self.product == other.product

    def __hash__(self):
        #        return  hash("Reaction" + str(self.reactant.ID) + str(self.product.ID) )
        return hash(
            "Reaction"
            + "".join([m.ID for m in self.reactant])
            + "".join([m.ID for m in self.product])
        )

    def get_molecules(self):
        return self.reactant[0].get_molecules(), self.product[0].get_molecules()

    def get_formula(self):
        formula = ""
        formula += self.reactant[0].get_formula() + " = "

        if len(self.product) != 1:
            product_formula = [product.get_formula() + "*" for product in self.product]
            formula += " + ".join(product_formula)

        else:
            formula += self.product[0].get_formula()

        return formula

    def compare_stoichiometry(self):
        """
        This compare stoichiometry between entered reactants and products
        """

        if len(self.product) != 1:
            prod_stoichiometry = dict(
                Counter(self.product[0].stoichiometry) + Counter(self.product[1].stoichiometry)
            )

        else:
            prod_stoichiometry = self.product[0].stoichiometry

        if set(self.reactant[0].stoichiometry.keys()) != set(prod_stoichiometry.keys()):
            return False

        # if contained elements are identical
        else:
            if all(
                [
                    self.reactant[0].stoichiometry[key] == prod_stoichiometry[key]
                    for key in prod_stoichiometry.keys()
                ]
            ):
                return True
            else:
                return False

    def is_equivalent_reaction(self, other):
        """
        Check whether two elementary reaction is equivalent.

        """
        # if self.reactant.is_equivalent(other.reactant) and self.product.is_equivalent(other.product):
        if self.reactant[0].is_equivalent(other.reactant[0]) and self.product[0].is_equivalent(
            other.product[0]
        ):
            return True
        else:
            return False

    #    def get_rxn_smiles(self, explicitHs = False):
    #
    #        if len(self.ID) == 16:
    #
    #            sequences = self.ID[:4], self.ID[4:8], self.ID[8:12], self.ID[12:]
    #            smiles = [ReactiveState.Mol_dict[mol].smiles for mol in sequences]
    #
    #            if explicitHs:
    #                smiles = [Chem.MolToSmiles(Chem.AddHs(Chem.MolFromSmiles(mol))) for mol in smiles if mol != "[x]"]
    #            else:
    #                smiles = [Chem.MolToSmiles(Chem.MolFromSmiles(mol)) for mol in smiles if mol != "[x]"]
    #
    #            if len(smiles) == 4:
    #                left, right = sorted([smiles[:2], smiles[2:]])
    #                reactionsmiles = ".".join(left) + ">>" + ".".join(right)
    #            elif len(smiles) <= 3:
    #                left = sorted(smiles[:1])
    #                right = sorted(smiles[1:])
    #                reactionsmiles = ".".join(left) + ">>" + ".".join(right)
    #
    #            return reactionsmiles
    #
    #        else:
    #
    #            return None

    def get_rxn_smiles(self, explicitHs=False):
        if len(self.product) != 2:
            return get_canonical_rxnsmi(
                [rs.smiles for rs in self.reactant][0]
                + ">>"
                + [rs.smiles for rs in self.product][0]
            )
        else:
            return None

    def get_catmap_TS_expression(self):
        """
        Automatically generate TS expression for catmap.
        This at least works for the reactions up to now but it could break down
        when a bit complicated cases are included.
        Verry messy but works for now.

        (e.g.) CH3OH + CH2O = CH2OH + CH2OH
               CH3O->H->CH2O  ==>  CH3O-H-CH2O
        (e.g.) CH2O + CH2O = CH2OH + CHO
               CH2O<-H<-CHO  ==> CH2O-H-CHO


        """
        reactants = [mol.get_formula() for mol in self.reactant[0].get_molecules()]
        products = [mol.get_formula() for mol in self.product[0].get_molecules()]

        if len(reactants) == len(products):
            a1 = []
            for item in reactants[0]:
                if item.isalpha():
                    a1.append(item)
                else:
                    a1[-1] += item

            a2 = []
            for item in products[0]:
                if item.isalpha():
                    a2.append(item)
                else:
                    a2[-1] += item

            # In case of isomerization
            if len(reactants) == 1:
                if a1[-1] == "H":
                    TS_expression = "H-" + "".join(a1[:-1])
                elif a2[-1] == "H":
                    TS_expression = "H-" + "".join(a2[:-1])
                return TS_expression

            diff = list(set(a1).symmetric_difference(set(a2)))

            if len(diff) == 1 and len(a2) <= len(a1):
                transferring_atom = "H"
                a1.remove(transferring_atom)
                TS_expression = "".join(a1) + f"-{transferring_atom}-" + f"{reactants[1]}"

            elif len(diff) == 1 and len(a2) > len(a1):
                transferring_atom = diff[0]
                a2.remove(transferring_atom)
                TS_expression = "".join(a2) + f"-{transferring_atom}-" + f"{products[1]}"

            else:
                for i, item in enumerate(a1):
                    if item in diff:
                        a1[i] = sorted(diff)[0]
                transferring_atom = "H"
                TS_expression = "".join(a1) + f"-{transferring_atom}-" + f"{reactants[1]}"
            # TS_expression = "".join(a2) + f"-{transferring_atom}-" + f"{products[1]}"

            return TS_expression

        elif len(reactants) < len(products):
            TS_expression = "-".join(products)

            return TS_expression


class Pathway:
    """
    A class for pathway or reaction network.

    This will require query for DFT calculations (adsorption, barrier etc)
    And convertible to catmap input file..

    Parameters
    ----------
    subnetwork: igraph.Graph or str
        Subnetwork graph or str if ig.graph is saved as file.
    name: str, optional
        Name of the pathway.

    Attributes
    ----------
    graph: igraph.Graph
        The graph representation of reaction network.
    name: str
        Name of the pathway.
    default_gas_molecules: list
        List of default gas molecules.
    starting_molecules: list
        List of starting molecules.
    rate_control: float
        Degree of rate control.
    selectivity_control: float
        Degree of selectivity control.
    coverage: float
        Coverage of each species from microkinetic model.
    tof: float
        Turnover frequency from microkinetic model.
    """

    def __init__(self, subnetwork, name=None):
        # If file path for pickle is given, igraph is loaded from there.
        if isinstance(subnetwork, str):
            self.graph = ig.load(subnetwork)
        else:  # if igraph object
            self.graph = subnetwork
        self.name = name
        self.default_gas_molecules = ["[H][H]", "O"]
        self.starting_molecules = self.get_starting_molecules()

        self.rate_control = None
        self.selectivity_control = None
        self.coverage = None
        self.tof = None

    def get_molecules(self):
        molecules = []
        for v in self.graph.vs:
            molecules += v["RS"].get_molecules()
        return list(set(molecules))

    def get_starting_molecules(self):
        starting_molecules = []
        for mol in self.get_molecules():
            if mol.get_formula() == "CO" or mol.get_formula() == "H":
                starting_molecules.append(mol)

        return starting_molecules

    def get_reactions(self):
        if "order" in self.graph.es.attribute_names():
            try:
                edges = sorted(
                    list(self.graph.es.select(is_real_elementary=True)),
                    key=lambda x: x["order"],
                )
                return [e["reaction"] for e in edges]
            except Exception as e:
                print(f"How exceptional! {e}")
                return [e["reaction"] for e in self.graph.es.select(is_real_elementary=True)]
        else:
            return [e["reaction"] for e in self.graph.es.select(is_real_elementary=True)]

    def get_rxnsmiles(self):
        return [rxn.rxnsmiles for rxn in self.get_reactions()]

    def get_causality_reactions(self):
        causality_reactions = []
        for item in self.get_causality_sequence(verbose=False):
            if type(item[0]).__name__ == "Reaction":
                causality_reactions += item

        return causality_reactions

    def print_formula(self):
        for rxn in self.get_reactions():
            print(rxn.get_formula())

    def get_causality_sequence(self, verbose=True):
        def can_reaction_happen2(reaction, current_molecules):
            left, right = (
                reaction.reactant[0].get_molecules(),
                reaction.product[0].get_molecules(),
            )
            for j, part in enumerate([left, right]):
                if len(set(part).difference(set(current_molecules))) == 0 and j == 0:
                    # return right
                    return [mol for mol in right if mol not in current_molecules]
                elif len(set(part).difference(set(current_molecules))) == 0 and j != 0:
                    # return left
                    return [mol for mol in left if mol not in current_molecules]
            return False

        current_molecules = []
        current_molecules += self.starting_molecules
        sequence = [self.starting_molecules]
        elementary_reactions = self.get_reactions().copy()
        success = True

        while len(elementary_reactions) != 0:
            possible_reactions = [True for rxn in elementary_reactions]
            for i, rxn in enumerate(elementary_reactions):
                if not can_reaction_happen2(rxn, current_molecules):
                    possible_reactions[i] = False
                    continue
                else:
                    new_molecules = can_reaction_happen2(rxn, current_molecules)
                    if len(new_molecules) == 0:
                        sequence[-2].append(elementary_reactions.pop(i))
                    else:
                        sequence.append([elementary_reactions.pop(i)])
                        sequence.append(new_molecules)
                    break
            if ~np.any(possible_reactions):
                if verbose:
                    print(f"There are {len(possible_reactions)} impossible reactions.")
                success = False
                break
            current_molecules += new_molecules
            current_molecules = list(set(current_molecules))

        if success:
            if verbose:
                for items in sequence:
                    print(", ".join([item.get_formula() for item in items]))
                    # print("="*30)
            return sequence
        else:
            return False

    def get_mkm_entries(self):
        print("get_mkm_entries")

    def save_pickle(self, savedir, name):
        if name is not None:
            self.graph.save(f"{savedir}/{self.name}.pickle")
        else:
            self.graph.save(f"{savedir}/path.pickle")
        # g = ig.load(r"/home/hjung/Calculation/Reaction_network2/molecules/methanol_toy_with_adsorption.pickle")

    def get_energetics(self):
        print("get energetics via foundation model or DFT")

    def convert2mkm(self):
        print("convert subnetwork to catmap microkinetics model")

    def get_mkm_results(self, model):
        self.rate_control = pd.DataFrame(
            data=np.array(model.rate_control_map[0][1]),
            index=model.output_labels["rate_control"][0],
            columns=model.output_labels["rate_control"][1],
        )
        self.selectivity_control = pd.DataFrame(
            data=np.array(model.selectivity_control_map[0][1]),
            index=model.output_labels["selectivity_control"][0],
            columns=model.output_labels["selectivity_control"][1],
        )
        self.coverage = pd.DataFrame(
            data=np.array(model.coverage_map[0][1]),
            index=model.output_labels["coverage"],
            columns=["coverage"],
        )
        self.tof = pd.DataFrame(
            data=np.array(model.turnover_frequency_map[0][1]),
            index=model.output_labels["turnover_frequency"],
            columns=["TOF"],
        )

    def merge(self, *others):
        # print("get union of several subnetwork")
        if "name" not in self.graph.vs.attribute_names():
            self.graph.vs["name"] = self.graph.vs["RSID"]
            self.graph.es["name"] = self.graph.es["RXNID"]
        tounion = [self.graph]

        for other in others:
            if "name" not in other.graph.vs.attribute_names():
                other.graph.vs["name"] = other.graph.vs["RSID"]
                other.graph.es["name"] = other.graph.es["RXNID"]
            tounion.append(other.graph)

        #        self.graph = ig.union(tounion, byname=True)
        return Pathway(ig.union(tounion, byname=True))

    def get_gas_phase_molecules(self):
        """
        Way of including gas phase molecules has to be modified later on
        """
        max_mol_id = max(sorted(list(map(int, [mol.ID for mol in self.get_molecules()])))) + 1
        default_gas_id = [f"{str(i).zfill(4)}" for i in range(max_mol_id, max_mol_id + 2)]
        gas_phases = [
            Molecule(smi, ID=idx) for smi, idx in zip(self.default_gas_molecules, default_gas_id)
        ]

        #        gas_phases = [ReactiveState.Mol_dict["0010"], ReactiveState.Mol_dict["0011"]]
        for mol in self.get_molecules():
            if mol.radical_electron == 0:
                gas_phases.append(mol)

        return gas_phases

    def prepare_catmap_input_file(self, surface="Cu"):
        gas_phases = self.get_gas_phase_molecules()

        categories = {
            "gas": gas_phases,
            "adsorbates": self.get_molecules(),
            "transition_states": self.get_reactions(),
        }

        energies_dict = []
        for category, entries in categories.items():
            for i, entry in enumerate(entries):
                row = {}
                if category == "gas":
                    row["surface_name"] = None
                    row["site_name"] = category
                else:
                    row["surface_name"] = surface
                    row["site_name"] = "h" if entry.get_formula() == "H" else "s"
                if category == "transition_states":
                    try:
                        row["species_name"] = entry.get_catmap_TS_expression()
                    except Exception as e:
                        print(f"How exceptional! {e}")
                        print("error ", entry.rxnsmiles)
                else:
                    row["species_name"] = entry.get_formula()
                row["formation_energy"] = np.nan
                row["frequencies"] = np.nan
                row["reference"] = np.nan
                row["category"] = category
                if category == "gas" or category == "adsorbates":
                    row["SMILES"] = entry.smiles
                    row["formula"] = entry.get_formula()
                else:
                    row["SMILES"] = entry.rxnsmiles
                    row["formula"] = entry.get_formula()

                energies_dict.append(row)

        return pd.DataFrame(energies_dict)

    def get_catmap_rxn_expressions(self, customized_label_dict, direct_desorption=["CO"]):
        """
        Parameters:
        -----------
        pathway : Pathway object
        direct_desorption : list
            list of SMILES string with molecules to be desorbed directly after their production.
            e.g. Methanol is assumed to desorb immediately.
        """
        direct_desorption = ["CO"]

        gas_phases = self.get_gas_phase_molecules()
        direct_desorption = [mol for mol in gas_phases if mol.smiles in direct_desorption]
        rxn_expressions = []

        for gas in gas_phases:
            if gas.get_formula() == "H2":
                rxn_expressions.append("H2_g + 2*_h -> 2H_h")
            elif gas.get_formula() == "H2O" or gas.get_formula() == "OH2":
                rxn_expressions.append("H2O_g -> H2O_g")
            elif gas not in direct_desorption:
                rxn_expressions.append(f"{gas.get_formula()}_s <-> {gas.get_formula()}_g + *_s")

        TS_formula = []
        for i, rxn in enumerate(self.get_reactions()):
            reactant_formula = [
                mol.get_formula() + "_g" if mol in direct_desorption else mol.get_formula()
                for mol in rxn.reactant[0].get_molecules()
            ]
            product_formula = [
                mol.get_formula() + "_g" if mol in direct_desorption else mol.get_formula()
                for mol in rxn.product[0].get_molecules()
            ]

            TS_formula = []
            if customized_label_dict:
                TS_formula.append(customized_label_dict[rxn.rxnsmiles])
            else:
                TS_formula.append(rxn.get_catmap_TS_expression())

            site_conservation = {
                "_s": max(
                    [
                        len([mol for mol in reactant_formula if mol != "H"]),
                        len([mol for mol in product_formula if mol != "H"]),
                    ]
                ),
                "_h": max(
                    [
                        len([mol for mol in reactant_formula if mol == "H"]),
                        len([mol for mol in product_formula if mol == "H"]),
                    ]
                ),
            }

            expression_dict = {"left": None, "TS": None, "right": None}

            for part, name in zip(
                [reactant_formula, TS_formula, product_formula], ["left", "TS", "right"]
            ):
                expression = []
                site_info = site_conservation.copy()
                for at in part:
                    # print("part", part)
                    if at.endswith("_g"):
                        expression.append(at)
                    elif at != "H":
                        expression.append(at + "_s")
                        site_info["_s"] -= 1
                    elif at == "H":
                        expression.append(at + "_h")
                        site_info["_h"] -= 1
                    else:
                        raise ValueError("What's this?")

                for site, remaining in site_info.items():
                    if remaining != 0:
                        expression.append("*" + site)
                        site_info[site] -= 1
                expression = " + ".join(expression)
                # print(site_info, flush=True)
                assert not np.any(list(site_info.values()))

                expression_dict[name] = expression

            catmap_rxn = ""
            catmap_rxn += expression_dict["left"]
            catmap_rxn += " <-> "
            catmap_rxn += expression_dict["TS"]
            catmap_rxn += " -> "
            catmap_rxn += expression_dict["right"]

            # print(catmap_rxn)
            rxn_expressions.append(catmap_rxn)

        # print(rxn_expressions)
        return rxn_expressions


def get_TS_expression(reaction):
    """
    Automatically generate TS expression for catmap.

    This at least works for the reactions up to now but it could break down
    when a bit complicated cases are included.
    Verry messy but works for now.
    In case of isomerization, TS expression is similar to dissociation but "H" is on left side^^

    (e.g.) CH3OH + CH2O = CH2OH + CH2OH
           CH3O->H->CH2O  ==>  CH3O-H-CH2O
    (e.g.) CH2O + CH2O = CH2OH + CHO
           CH2O<-H<-CHO  ==> CH2O-H-CHO


    """
    reactants = [mol.get_formula() for mol in reaction.reactant[0].get_molecules()]
    products = [mol.get_formula() for mol in reaction.product[0].get_molecules()]

    if len(reactants) == len(products):
        a1 = []
        for item in reactants[0]:
            if item.isalpha():
                a1.append(item)
            else:
                a1[-1] += item

        a2 = []
        for item in products[0]:
            if item.isalpha():
                a2.append(item)
            else:
                a2[-1] += item

        # In case of isomerization
        if len(reactants) == 1:
            if a1[-1] == "H":
                TS_expression = "H-" + "".join(a1[:-1])
            elif a2[-1] == "H":
                TS_expression = "H-" + "".join(a2[:-1])
            return TS_expression

        diff = list(set(a1).symmetric_difference(set(a2)))

        if len(diff) == 1 and len(a2) <= len(a1):
            transferring_atom = "H"
            a1.remove(transferring_atom)
            TS_expression = "".join(a1) + f"-{transferring_atom}-" + f"{reactants[1]}"

        elif len(diff) == 1 and len(a2) > len(a1):
            transferring_atom = diff[0]
            a2.remove(transferring_atom)
            TS_expression = "".join(a2) + f"-{transferring_atom}-" + f"{products[1]}"

        else:
            for i, item in enumerate(a1):
                if item in diff:
                    a1[i] = sorted(diff)[0]
            transferring_atom = "H"
            TS_expression = "".join(a1) + f"-{transferring_atom}-" + f"{reactants[1]}"
        # TS_expression = "".join(a2) + f"-{transferring_atom}-" + f"{products[1]}"

        return TS_expression

    elif len(reactants) < len(products):
        TS_expression = "-".join(products)

        return TS_expression
