"""
Get atom-mapping between reactant and product from reaction SMILES string.
"""

import numpy as np
from rdkit import Chem
from rdkit.Chem import rdMolDescriptors, rdChemReactions
import networkx as nx
from networkx.algorithms import isomorphism

# from IPython.display import SVG, display
from itertools import product
from rdkit.Chem import Draw

# def show_molecule(rdkitmol):
#    d = rdMolDraw2D.MolDraw2DSVG(500, 400)
#    dm = Draw.PrepareMolForDrawing(rdkitmol)
#    d.DrawMolecule(dm)
#    d.AddMoleculeMetadata(dm)
#    d.FinishDrawing()
#    svg = d.GetDrawingText()
#    # print(svg)
#    SVG(svg)
#    return display(SVG(svg))


def change_bond_order(mol):
    """
    Change all bond orders in the molecule to single bonds.

    Parameters
    ----------
    mol : RDKit Mol
        Input molecule.

    Returns
    -------
    RDKit Mol
        Modified molecule with all bond orders set to single.
    """
    for bond in mol.GetBonds():
        if bond.GetBondType() != Chem.BondType.SINGLE:
            bond.SetBondType(Chem.BondType.SINGLE)

    return mol


def change_formal_charge(mol):
    """
    Change all formal charges in the molecule to zero.

    Parameters
    ----------
    mol : RDKit Mol
        Input molecule.

    Returns
    -------
    RDKit Mol
        Modified molecule with all formal charges set to zero.
    """
    for atom in mol.GetAtoms():
        if atom.GetFormalCharge() != 0:
            atom.SetFormalCharge(0)

    return mol


def break_bonds(mol_dict, num_bonds):
    """
    Break specified bonds in a dictionary of molecules.

    Parameters
    ----------
    mol_dict : dict
        Dictionary of RDKit Mol objects.
    num_bonds : int
        Number of bonds to break in each molecule.

    Returns
    -------
    frag_smiles : list
        List of SMILES strings for the fragmented molecules.
    mol_frags : dict
        Dictionary mapping SMILES strings to their corresponding RDKit Mol objects.
    """
    frag_smiles = []
    mol_frags = {}
    for key in mol_dict:
        mol = mol_dict[key]
        for bond in range(num_bonds):
            mol_frag = Chem.FragmentOnBonds(mol, [bond], addDummies=False)
            smiles = Chem.MolToSmiles(mol_frag, isomericSmiles=False)
            if smiles not in frag_smiles:
                frag_smiles.append(smiles)
                mol_frags[smiles] = mol_frag

    return frag_smiles, mol_frags


def atom_mapper(react_smiles, prod_smiles, max_bonds_cut, verbose=False):
    """
    Map atoms from reactant to product based on SMILES strings.

    Parameters
    ----------
    react_smiles : str
        SMILES string for the reactant.
    prod_smiles : str
        SMILES string for the product.
    max_bonds_cut : int
        Maximum number of bonds to cut during mapping.
    verbose : bool, optional
        If True, print detailed information about the mapping process (default is False).

    Returns
    -------
    list
        List of dictionaries mapping atom indices from reactant to product.
    """
    react = Chem.MolFromSmiles(react_smiles)
    prod = Chem.MolFromSmiles(prod_smiles)

    # Remove aromaticity and work with single/double/triple bonds
    Chem.Kekulize(react, clearAromaticFlags=True)
    Chem.Kekulize(prod, clearAromaticFlags=True)

    react = Chem.AddHs(react)
    prod = Chem.AddHs(prod)

    react_numbonds = react.GetNumBonds()
    prod_numbonds = prod.GetNumBonds()

    # Change all bonds to single bonds and remove all charges on atoms
    # This allows us to compare molecule fragments based purely on connectivity
    react = change_bond_order(react)
    prod = change_bond_order(prod)
    react = change_formal_charge(react)
    prod = change_formal_charge(prod)

    # recanonicalize SMILES (sanitize=False prevets hydrogen deletion)
    react_smiles = Chem.MolToSmiles(Chem.MolFromSmiles(Chem.MolToSmiles(react), sanitize=False))
    prod_smiles = Chem.MolToSmiles(Chem.MolFromSmiles(Chem.MolToSmiles(prod), sanitize=False))

    # We identify active bonds based on SMILES comparisons and connect fragments to SMILES via dictionaries
    matches = []
    bonds_cut = 1
    react_frag_smiles = [react_smiles]
    prod_frag_smiles = [prod_smiles]
    react_frags = {}
    react_frags[react_smiles] = react
    prod_frags = {}
    prod_frags[prod_smiles] = prod

    # Keep cutting bonds until the fragments match each other.
    # If reactants and products have an unequal number of bonds, we cut the one with most bonds first
    # until they have an equal number of bonds
    while len(matches) == 0 and bonds_cut <= max_bonds_cut:
        if react_numbonds > prod_numbonds:
            react_frag_smiles, react_frags = break_bonds(react_frags, react_numbonds)
            react_numbonds += -1
        elif prod_numbonds > react_numbonds:
            prod_frag_smiles, prod_frags = break_bonds(prod_frags, prod_numbonds)
            prod_numbonds += -1
        else:
            react_frag_smiles, react_frags = break_bonds(react_frags, react_numbonds)
            react_numbonds += -1
            prod_frag_smiles, prod_frags = break_bonds(prod_frags, prod_numbonds)
            prod_numbonds += -1

        # Check if bond breaking produced idential set of fragments. There may be more than one way to do this
        # "matches" is a list of SMILES strings describing the fragments resuling from bond cutting
        for combi in product(react_frags.values(), prod_frags.values()):
            match = check_isomorphism(*combi)
            if match:
                matches.append(dict(sorted(match.items())))

        if len(matches) > 0:
            return matches

        bonds_cut += 1


def suggest_strategy(react, prod_ordered, verbose=True):
    """
    Suggest a strategy/recipe for how reaction can happen as indicated by atom-mapping.

    Indicators represents following reaction types.
    1 : A + B -> C + D
    2 : A -> B + C
    3 : A + B -> C
    4 : A -> B
    5 : A -> B

    Parameters
    ----------
    react : Chem.Mol
        The reactant molecule.
    prod_ordered : Chem.Mol
        The product molecule (ordered).
    verbose : bool, optional
        If True, print detailed information about the strategy (default is True).

    Returns
    -------
    indicator : int
        Indicator which represents reaction type.
    active_bonds : dict
        A dictionary indicating which bonds are formed or broken.
    """
    # A + B -> C + D
    if "." in Chem.MolToSmiles(react) and "." in Chem.MolToSmiles(prod_ordered):
        indicator = 1
        if verbose:
            print("Arbitrarily choose reactant")
        R, P = react, prod_ordered

    # A -> B + C
    if "." not in Chem.MolToSmiles(react) and "." in Chem.MolToSmiles(prod_ordered):
        indicator = 2
        if verbose:
            print("Choose reactant")
        R, P = react, prod_ordered

    # A + B -> C
    if "." in Chem.MolToSmiles(react) and "." not in Chem.MolToSmiles(prod_ordered):
        indicator = 3
        if verbose:
            print("Choose product")
        R, P = prod_ordered, react

    # A -> B
    if "." not in Chem.MolToSmiles(react) and "." not in Chem.MolToSmiles(prod_ordered):
        react_rotbonds = rdMolDescriptors.CalcNumRotatableBonds(react)
        # prod_rotbonds = rdMolDescriptors.CalcNumRotatableBonds(prod)
        prod_rotbonds = rdMolDescriptors.CalcNumRotatableBonds(prod_ordered)

        if react_rotbonds <= prod_rotbonds:
            indicator = 4
            if verbose:
                print("Choose reactant")
            R, P = react, prod_ordered
        else:
            if verbose:
                print("Choose product")
            indicator = 5
            #            R, P = prod_ordered, react
            P, R = prod_ordered, react

    R_bonds = R.GetSubstructMatches(Chem.MolFromSmarts("[*]~[*]"))
    P_bonds = P.GetSubstructMatches(Chem.MolFromSmarts("[*]~[*]"))
    # active_bonds = list(set(R_bonds)^set(P_bonds))
    bonds_broken = list(set(R_bonds) - set(P_bonds))
    bonds_formed = list(set(P_bonds) - set(R_bonds))

    if bonds_formed:
        if verbose:
            print("Form", bonds_formed)
        if len(bonds_broken) >= 1:
            if verbose:
                print("Break", bonds_broken)
            return indicator, {"Form": bonds_formed[0], "Break": bonds_broken[0]}
        #                return indicator, "Form", (bonds_formed[0], bonds_broken[0])

        else:
            #            pass
            return indicator, {"Form": bonds_formed[0]}

    else:
        if verbose:
            print("Break", bonds_broken)
        if len(bonds_formed) >= 1:
            if verbose:
                print("Form", bonds_formed)
            return indicator, {"Break": bonds_broken[0], "Form": bonds_formed[0]}
        else:
            #            pass
            return indicator, {"Break": bonds_broken[0]}


def mol_with_atom_index(mol):
    """
    Add atom mapping indices to the input RDKit molecule.

    Parameters
    ----------
    mol : Chem.Mol
        The input RDKit molecule.

    Returns
    -------
    Chem.Mol
        The RDKit molecule with atom mapping indices added.
    """
    atoms = mol.GetNumAtoms()
    for idx in range(atoms):
        mol.GetAtomWithIdx(idx).SetProp("molAtomMapNumber", str(mol.GetAtomWithIdx(idx).GetIdx()))
    return mol


def mol2graph(mol):  # molecule_fragment_smiles
    """
    Convert molecular fragments into networkx molecular graph representation.

    This adds explicit hydrogen and save atomic symbol into attribute "element".
    Bond connectivity is saved as edges.

    Parameters
    ----------
    mol : Chem.Mol
        The input RDKit molecule.

    Returns
    -------
    nx.Graph
        The networkx graph representation of the molecule.
    """
    # convert smiles string into rdkit mol object and add Hs on only explicit Hydrogen
    # This requires molecule_fragment_smiles to express every hydrogens in explicit mannner.
    # mol = Chem.AddHs(Chem.MolFromSmiles(mol), explicitOnly=True)

    # atoms --> nodes
    atoms = [atom.GetIdx() for atom in mol.GetAtoms()]
    # node attribute: atomic symbol
    atoms_symbol = [atom.GetSymbol() for atom in mol.GetAtoms()]
    attributes = [(atomidx, {"element": symbol}) for atomidx, symbol in zip(atoms, atoms_symbol)]
    # Bonds --> edges
    bonds = [(bond.GetBeginAtomIdx(), bond.GetEndAtomIdx()) for bond in mol.GetBonds()]

    # Create networkx graph
    G = nx.Graph()
    G.add_nodes_from(attributes)
    G.add_edges_from(bonds)

    return G


def check_isomorphism(react_frag, prod_frag):
    """
    Convert reactant and product's SMILES into networkx graph representation and check isomorphism between two molecular fragments.

    Also this addtionally checks whether atomic symbols match each other.
    If two tests are passed, returns atoming mapping as dictionary else returns None.
    Atomic indices of reactants are stored as "keys" in dictionary and those of products are stored as "values".

    Parameters
    ----------
    react_frag : Chem.Mol
        The reactant fragment as an RDKit molecule.
    prod_frag : Chem.Mol
        The product fragment as an RDKit molecule.

    Returns
    -------
    dict or None
        A dictionary mapping atomic indices from reactant to product if isomorphic, else None.
    """
    R_graph, P_graph = mol2graph(react_frag), mol2graph(prod_frag)

    GM = isomorphism.GraphMatcher(
        R_graph, P_graph, node_match=lambda n1, n2: n1["element"] == n2["element"]
    )
    if GM.is_isomorphic():
        return GM.mapping


def atommapping(rxn_smiles, max_bonds_cut=6, get_suggestion=True):
    """
    Map atomic indices between reactant and product fragments in a reaction.

    Parameters
    ----------
    rxn_smiles : str
        The reaction SMILES string.
    max_bonds_cut : int, optional
        The maximum number of bonds to cut for mapping (default is 6).
    get_suggestion : bool, optional
        Whether to get a suggestion for the mapping (default is True).

    Returns
    -------
    list
        A list of dictionaries containing the mapped reaction SMILES and other information.
    """
    react_smiles, prod_smiles = tuple(rxn_smiles.split(">>"))

    react_smiles = Chem.MolToSmiles(Chem.MolFromSmiles(react_smiles), isomericSmiles=False)
    prod_smiles = Chem.MolToSmiles(Chem.MolFromSmiles(prod_smiles), isomericSmiles=False)
    react, prod = Chem.MolFromSmiles(react_smiles), Chem.MolFromSmiles(prod_smiles)

    react = Chem.AddHs(react)
    prod = Chem.AddHs(prod)

    mapped_list = []
    matches = atom_mapper(react_smiles, prod_smiles, max_bonds_cut, verbose=False)
    for match_dict in matches:
        prod_ordered = Chem.RenumberAtoms(prod, tuple(match_dict.values()))
        prod_ordered = mol_with_atom_index(prod_ordered)

        indicator, active_bonds = suggest_strategy(react, prod_ordered, verbose=False)
        react = mol_with_atom_index(react)
        mapped_reaction_smiles = Chem.MolToSmiles(react) + ">>" + Chem.MolToSmiles(prod_ordered)
        CD = (
            np.sum(np.abs(Chem.GetAdjacencyMatrix(react) - Chem.GetAdjacencyMatrix(prod_ordered)))
            / 2
        )

        mapped_list.append(
            {
                "mapped_rxnsmiles": mapped_reaction_smiles,
                "CD": CD,
                "indicator": indicator,
                "active_bonds": active_bonds,
                "mapping_dict": match_dict,
            }
        )

    return mapped_list


def is_atom_mapped(rxnsmiles, slab_indices=None, get_suggestion=True):
    """
    Check if the provided reaction SMILES has atom mapping.

    Parameters
    ----------
    rxnsmiles : str
        The reaction SMILES string to check for atom mapping.
    slab_indices : list, optional
        The list of slab atom indices to consider for mapping.
    get_suggestion : bool, optional
        Whether to get suggestions for atom mapping if none exists.

    Returns
    -------
    dict or str
        If atom mapping exists, returns the original SMILES string.
        If not, returns a list of suggested mappings.
    """
    # If provided reaction smiles doesn't have any atom mapping,
    # Atom mapping is carried out
    rxn = rdChemReactions.ReactionFromSmarts(rxnsmiles, useSmiles=True)
    if len(rxn.GetReactants()) > 1:
        mol = Chem.CombineMols(*rxn.GetReactants())
    else:
        mol = rxn.GetReactants()[0]
    AtomMapNum = [atom.GetAtomMapNum() for atom in mol.GetAtoms()]
    if not any(AtomMapNum):  # if there's no atommaping
        mapped_list = atommapping(rxnsmiles, get_suggestion=get_suggestion)
        if slab_indices is not None:
            for mapping_dict in mapped_list:
                for action in mapping_dict["active_bonds"].keys():
                    mapping_dict["active_bonds"][action] = tuple(
                        np.array(mapping_dict["active_bonds"][action]) + len(slab_indices)
                    )
        return mapped_list
    else:
        return rxnsmiles


def draw_mapped_reaction(reactionsmiles, order=False):
    """
    Visualize a reaction SMILES as a reaction diagram image.

    When ``order=True``, the input SMILES is first passed through
    :func:`is_atom_mapped` and the best-scoring mapping is used for
    rendering. When ``order=False``, the SMILES is rendered as-is
    assuming atom-mapping is already done.

    Parameters
    ----------
    reactionsmiles : str
        Reaction SMILES string, with or without existing atom-map numbers.
        Example: ``"[CH]O>>[CH]=O.[H]"`` or
        ``"[C:0]([O:1][H:3])[H:2]>>[C:0](=[O:1])[H:2].[H:3]"``.
    order : bool, optional
        If ``True``, run :func:`is_atom_mapped` on the input and render
        the first (best) mapping returned. If ``False`` (default), render
        ``reactionsmiles`` directly without remapping.

    Returns
    -------
    PIL.Image.Image
        A reaction diagram image of the (optionally remapped) reaction.
    """
    if order:
        mapped_list = is_atom_mapped(reactionsmiles)
        mapping_dict = mapped_list[0]
        return Draw.ReactionToImage(
            rdChemReactions.ReactionFromSmarts(mapping_dict["mapped_rxnsmiles"], useSmiles=True)
        )

    else:
        return Draw.ReactionToImage(
            rdChemReactions.ReactionFromSmarts(reactionsmiles, useSmiles=True)
        )
