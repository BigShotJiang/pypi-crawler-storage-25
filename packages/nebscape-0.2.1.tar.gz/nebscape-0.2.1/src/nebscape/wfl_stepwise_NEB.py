import sys
import os

import numpy as np
from ase.optimize import FIRE
from ase.mep.dyneb import DyNEB
from ase.mep.neb import idpp_interpolate

from ase.atoms import Atoms
import ase.io

from wfl.autoparallelize import autoparallelize, autoparallelize_docstring
from wfl.utils.save_calc_results import at_copy_save_calc_results
from wfl.utils.parallel import construct_calculator_picklesafe
from wfl.generate.utils import save_config_type
from pathlib import Path
from .analysis import check_chemical_fidelity
from .utils import get_adjacency_matrix
from .resolve_pbc import get_optimal_linear_interpolation_pbc
from .neb_helpers import adjust_spring_constants


def split_neb_profile(
    previous_images,
    new_initial,
    new_final,
    calculator,
    slab_indices,
    fmax=0.05,
    steps=500,
):
    """Make a new interpolation starting from new initial and final points.

    Parameters
    ----------
    previous_images : list
        NEB Images before refinement
    new_initial : ASE atoms
        new initial image
    new_final : ASE atoms
        new final image
    calculator : ASE calculator
        ASE calculator
    slab_indices : list
        list of slab atom indices
    fmax : float, optional
        fmax for optimization, by default 0.05
    steps : int, optional
        max number of steps for optimization, by default 500

    Returns
    -------
    list
        Newly interpolated images.

    Raises
    ------
    ValueError
        If relaxation leads to different initial and final, it will raise error.
    """

    # Chemical identity should be preserved after relaxation.
    all_intact = []
    print("NEB trajectory is refined.")
    for target_at, trial_at in zip(
        [previous_images[0], previous_images[-1]], [new_initial, new_final]
    ):
        trial_at.calc = calculator
        dyn = FIRE(trial_at, trajectory=None)
        dyn.run(fmax=fmax, steps=steps)
        target_adjacency = get_adjacency_matrix(target_at, slab_indices=slab_indices)
        trial_adjacency = get_adjacency_matrix(trial_at, slab_indices=slab_indices)
        all_intact.append(np.all(target_adjacency == trial_adjacency))
    if not np.all(all_intact):
        raise ValueError("Chemical identity not preserved.")
    new_initial.info["changed_during_NEB"] = True
    new_final.info["changed_during_NEB"] = True
    refined_images, _ = get_optimal_linear_interpolation_pbc(
        new_initial, new_final, slab_indices, numimages=len(previous_images) - 2
    )
    idpp_interpolate(refined_images, log=None, traj=None, mic=True)

    return refined_images


def _run_autopara_wrappable(
    list_of_images,
    calculator,
    fmax=5e-2,
    steps=1000,
    traj_step_interval=1,
    traj_subselect=None,
    skip_failures=True,
    attach_kwargs=None,
    attach_interval=None,
    results_prefix="last_op__neb_",
    verbose=False,
    logfile=None,
    update_config_type="append",
    abort_check=None,
    _autopara_per_item_info=None,
    **neb_kwargs,
):
    """runs a structure optimization. By default calculator properties will be stored
    in keys prefixed with "last_op__neb_", which may be overwritten by next operation.

    Parameters
    ----------
    list_of_images: list(iterable(Atoms))
        input list of images, with each is an itereable of Atoms
        (i.e. [images1, images2, images3])
    calculator: Calculator / (initializer, args, kwargs)
        ASE calculator or initializer and arguments to call to create calculator
    fmax: float, default 5e-2
        force convergence tolerance
    steps: int, default 1000
        max number of steps
    traj_step_interval: int, default 1
        if present, interval between trajectory snapshots
    traj_subselect: "last_converged", default None
        rule for sub-selecting configs from the full trajectory.
        Currently implemented: "last_converged", which takes the last config, if converged.
    skip_failures: bool, default True
        just skip optimizations that raise an exception
    results_prefix: str, default "last_op__neb_"
        prefix to info/arrays keys where calculator properties will be stored
        Will overwrite any other properties that start with same "<str>__", so that by
        default only last op's properties will be stored.
    verbose: bool, default False
        verbose output
        optimisation logs are not printed unless this is True
    update_config_type: ["append" | "overwrite" | False], default "append"
        whether/how to add at.info['neb_config_type'] to at.info['config_type']
    neb_kwargs
        keyword arguments for DyNEB and FIRE

    Returns
    -------
        list(Atoms) trajectories
    """
    logfile = neb_kwargs.pop("logfile", None)
    switch_climb = neb_kwargs.pop("switch_climb", True)
    no_climb_step = neb_kwargs.pop("no_climb_step", 200)
    no_climb_fmax = neb_kwargs.pop("no_climb_fmax", 0.05)
    if switch_climb:
        steps = neb_kwargs.pop("climb_step", 2000)
        fmax = neb_kwargs.pop("climb_fmax", 0.05)
    pre_relax_fmax = neb_kwargs.pop("pre_relax_fmax", None)
    slab_indices = neb_kwargs.pop("slab_indices", None)
    refine_neb = neb_kwargs.pop("refine_neb", False)
    if "adjust_k" in neb_kwargs.keys() and neb_kwargs["adjust_k"]:
        attach_kwargs = {
            "attach_function": adjust_spring_constants,
            "k_max": neb_kwargs.pop("k_max", 4.0),
            "k_min": neb_kwargs.pop("k_min", 0.1),
        }
        attach_interval = neb_kwargs.pop("attach_interval", 40)

    if attach_kwargs is not None:
        attach_constructor = attach_kwargs.pop("attach_function", None)

    if logfile is None and verbose:
        logfile = "-"

    calculator = construct_calculator_picklesafe(calculator)

    all_trajs = []

    for at_i, images in enumerate(list_of_images):
        if (
            _autopara_per_item_info is not None
            and "workdir" in _autopara_per_item_info[at_i].keys()
        ):
            workdir = _autopara_per_item_info[at_i]["workdir"]
        else:
            workdir = Path(os.getcwd())

        assert all([isinstance(at, Atoms) for at in images]), (
            "Got images that is not an iterable(Atoms)"
        )

        orig_constraints = [at.constraints for at in images]
        for at_i, at in enumerate(images):
            at.calc = calculator
            at.info["neb_image_i"] = at_i

        if pre_relax_fmax is not None:
            print("relaxation for intial and final images")
            opt = FIRE(list(images)[0])
            opt.run(fmax=pre_relax_fmax)
            opt = FIRE(list(images)[-1])
            opt.run(fmax=pre_relax_fmax)

        traj = []

        def process_step():
            cur_images = []
            for at, constraints in zip(images, orig_constraints):
                # It seems some calculators doesn't save results dict and in that case properties should be given.
                new_config = at_copy_save_calc_results(
                    at, prefix=results_prefix, properties=["energy", "forces"]
                )
                new_config.set_constraint(constraints)
                new_config.info["neb_iter_i"] = opt.get_number_of_steps()
                cur_images.append(new_config)

            traj.append(cur_images)
            if abort_check is not None:
                if abort_check.stop(opt):
                    raise RuntimeError(
                        f"NEB was stopped by the NEB checker function {abort_check.__class__.__name__}"
                    )

        # for climb in climbs:
        # Without Climbing image
        if switch_climb:
            neb_kwargs["climb"] = False
            neb1 = DyNEB(list(images), **neb_kwargs)
            opt = FIRE(neb1, logfile=logfile)

            opt.attach(process_step, interval=traj_step_interval)

            if attach_kwargs is not None:
                attach_kwargs["neb"] = neb1
                opt.attach(attach_constructor, interval=attach_interval, **attach_kwargs)

            # preliminary value
            final_status = "unconverged"

            try:
                opt.run(fmax=no_climb_fmax, steps=no_climb_step)
            except Exception as exc:
                # label actual failed optimizations
                # when this happens, the atomic config somehow ends up with a 6-vector stress, which can't be
                # read by xyz reader.
                # that should probably never happen
                final_status = "exception"
                if skip_failures:
                    sys.stderr.write(
                        f"Nudged elastic band calculation failed with exception '{exc}'\n"
                    )
                    sys.stderr.flush()
                else:
                    raise

            if refine_neb:
                for at in neb1.images:
                    at.info[f"{results_prefix}_energy"] = at.get_potential_energy()

                single_step_criterion, energy_criterion, barrier_less, indices = check_chemical_fidelity(
                    neb1.images,
                    slab_indices=slab_indices,
                    energy_key=f"{results_prefix}_energy",
                    verbose=False,
                )
                # 1. Ideal case
                if single_step_criterion and energy_criterion:
                    images = neb1.images
                # 2. Less ideal case, sth can be tried.
                elif single_step_criterion and not energy_criterion:
                    new_initial, new_final = (
                        list(images)[indices[0]],
                        list(images)[indices[-1]],
                    )
                    images = split_neb_profile(
                        neb1.images, new_initial, new_final, calculator, slab_indices
                    )

                    neb_kwargs["climb"] = False
                    neb1 = DyNEB(list(images), **neb_kwargs)
                    opt = FIRE(neb1, logfile=logfile)

                    opt.attach(process_step, interval=traj_step_interval)

                    if attach_kwargs is not None:
                        attach_kwargs["neb"] = neb1
                        opt.attach(
                            attach_constructor,
                            interval=attach_interval,
                            **attach_kwargs,
                        )

                    # preliminary value
                    final_status = "unconverged"

                    try:
                        opt.run(fmax=no_climb_fmax, steps=no_climb_step)
                    except Exception as exc:
                        # label actual failed optimizations
                        # when this happens, the atomic config somehow ends up with a 6-vector stress, which can't be
                        # read by xyz reader.
                        # that should probably never happen
                        final_status = "exception"
                        if skip_failures:
                            sys.stderr.write(
                                f"Nudged elastic band calculation failed with exception '{exc}'\n"
                            )
                            sys.stderr.flush()
                        else:
                            raise

                # 3. Failed case: Actually no need to do further CI-NEB
                #    Perhaps it can be already terminated in this step, but for now it's not changed.
            #               elif not single_step:
            else:
                images = neb1.images

            for at in images:
                at.info[f"{results_prefix}_energy"] = at.get_potential_energy()

            ase.io.write(f"{workdir}/NEB.xyz", images)
            traj = []
            neb_kwargs["climb"] = True

        neb2 = DyNEB(list(images), **neb_kwargs)
        opt = FIRE(neb2, logfile=logfile)

        opt.attach(process_step, interval=traj_step_interval)

        if attach_kwargs is not None:
            attach_kwargs["neb"] = neb2
            opt.attach(attach_constructor, interval=attach_interval, **attach_kwargs)

        # preliminary value
        final_status = "unconverged"

        try:
            opt.run(fmax=fmax, steps=steps)
        except Exception as exc:
            # label actual failed optimizations
            # when this happens, the atomic config somehow ends up with a 6-vector stress, which can't be
            # read by xyz reader.
            # that should probably never happen
            final_status = "exception"
            if skip_failures:
                sys.stderr.write(f"Nudged elastic band calculation failed with exception '{exc}'\n")
                sys.stderr.flush()
            else:
                raise

        # set for first config, to be overwritten if it's also last config
        for at in traj[0]:
            at.info["neb_config_type"] = "neb_initial"

        if opt.converged():
            final_status = "converged"

        for intermed_images in traj[1:-1]:
            for at in intermed_images:
                at.info["neb_config_type"] = "neb_intermediate"

        for at in traj[-1]:
            at.info["neb_config_type"] = f"neb_last_{final_status}"
            at.info["neb_n_steps"] = opt.get_number_of_steps()

        for all_images in traj:
            for at in all_images:
                save_config_type(at, update_config_type, at.info["neb_config_type"])

        traj = subselect_from_traj(traj, subselect=traj_subselect)

        all_trajs.append(traj)

    return all_trajs


def NEB(*args, **kwargs):
    default_autopara_info = {"num_inputs_per_python_subprocess": 10}

    return autoparallelize(
        _run_autopara_wrappable,
        *args,
        default_autopara_info=default_autopara_info,
        **kwargs,
    )


autoparallelize_docstring(NEB, _run_autopara_wrappable, "Atoms")


def subselect_from_traj(traj, subselect=None):
    """Sub-selects configurations from trajectory.

    Parameters
    ----------
    subselect: int or string, default None

        - None: full trajectory is returned
        - int: (not implemented) how many samples to take from the trajectory.
        - str: specific method

          - "last_converged": returns [last_config] if converged, or None if not.

    """
    if subselect is None:
        return traj
    elif subselect == "last":
        return traj[-1]
    elif subselect == "last_converged":
        return traj[-1] if traj[-1][0].info["neb_config_type"] == "neb_last_converged" else None

    raise RuntimeError(
        f"Subselecting confgs from trajectory with rule "
        f'"subselect={subselect}" is not yet implemented'
    )
