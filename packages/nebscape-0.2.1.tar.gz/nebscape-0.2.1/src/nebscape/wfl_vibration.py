from wfl.autoparallelize import autoparallelize
from wfl.utils.misc import atoms_to_list
from wfl.utils.parallel import construct_calculator_picklesafe
from ase.vibrations import Vibrations
from ase import Atoms
import numpy as np


def _run_autopara_wrappable(
    atoms,
    calculator,
    delta=1e-5,
    linear=False,
    gas=False,
    rotation_threshold=12,
    imag_threshold=100,
    strict=False,
    transition_state=False,
    raise_calc_exceptions=False,
    verbose=False,
):
    at_out = []
    calculator_default = construct_calculator_picklesafe(calculator)
    if verbose:
        print(f"{delta = }")

    for at in atoms_to_list(atoms):
        at.calc = calculator_default
        if gas:
            vib = Vibrations(at, delta=delta)
        else:
            assert 1 in at.arrays["tags"] and 2 in at.arrays["tags"], "Check the tags"
            slab_indices = [i for i, tag in enumerate(at.arrays["tags"]) if tag != 2]
            adsorbate_indices = [a.index for a in at if a.index not in slab_indices]
            vib = Vibrations(at, indices=adsorbate_indices, delta=delta)

        try:
            if verbose:
                print("start vib freq")
            vib.run()
            freqs = vib.get_frequencies()
            if gas and linear:
                num_modes = 3 * len(at) - 5
                freqs = np.sort(freqs)[::-1][:num_modes]
            elif gas and not linear:
                num_modes = 3 * len(at) - 6
                freqs = np.sort(freqs)[::-1][:num_modes]

            real_freq = []
            imag_freq = []
            for freq in freqs:
                if freq.imag == 0:
                    real_freq.append(np.real(freq))
                else:
                    imag_freq.append(np.imag(freq))
            vib.clean()

            if transition_state and len(imag_freq) != 1:
                print(
                    f"Transition state has {len(imag_freq)} imaginary frequencies: {imag_freq = }."
                )
            calculation_succeeded = True
        except Exception as exc:
            print("sth went wrong")
            if raise_calc_exceptions:
                raise exc
            calculation_succeeded = False

        if verbose:
            print(f"{real_freq = }")
            print(f"{imag_freq = }")

        if calculation_succeeded:
            at.info["real_freq"] = real_freq
            at.info["imag_freq"] = imag_freq
        # avoid maintaining the reference to the calculator
        at.calc = None

        at_out.append(at)

    if isinstance(atoms, Atoms):
        return at_out[0]
    else:
        return at_out


def calc_frequency(*args, **kwargs):
    #    calculator = kwargs.get("calculator")
    #    if calculator is None:
    #        calculator = args[2]
    #
    #    default_autopara_info = getattr(calculator, "wfl_generic_default_autopara_info", {"num_inputs_per_python_subprocess": 10})
    default_autopara_info = {"num_inputs_per_python_subprocess": 10}

    return autoparallelize(
        _run_autopara_wrappable,
        *args,
        default_autopara_info=default_autopara_info,
        **kwargs,
    )


# autoparallelize_docstring(calc_frequency, _run_autopara_wrappable, "Atoms")
