"""
Helper functions for preparing and post-processing minima hopping simultaion.
"""

import numpy as np
import pandas as pd
from pathlib import Path
from ase.constraints import Hookean, FixAtoms
from ase.io import read, write
from ase import neighborlist
from ase import Atom, Atoms
from ase.geometry import find_mic
from ase.build import add_adsorbate
from rdkit import Chem
from rdkit.Chem import AllChem, rdDistGeom

from .utils import graphfromase
from .minimize_rmsd import get_slab_atom_classification
from .neb_helpers import check_adsorbate_isomorphism
from .utils import tag_atoms
from io import StringIO
import random
from dscribe.descriptors import SOAP
from sklearn.decomposition import KernelPCA
from sklearn.cluster import KMeans


def mol2Gen3D(smiles, nconf=100):
    """
    Convert rdkit mol object into 3d coordinate object via force field optimization.

    Parameters
    ----------
    smiles : str
        SMILES representation of the molecule.
    nconf : int
        Number of conformers to generate.

    Returns
    -------
    rdkit conformer object
        Mol object with 3D coordinate embedded.
    """
    mol = Chem.MolFromSmiles(smiles)
    mol = Chem.AddHs(mol)
    # Need to check whether hydrogens have been properly added !

    # Used default setting of rdDistGeom.ETKDGv2()
    # Embed 2D molecule into 3D coordinate using bounded distance matrix.
    # In particular,  useRandomCoords & boxSizeMult have been modified
    # useRandom Coord might not be critical issue in 3D coood generation.
    cids = rdDistGeom.EmbedMultipleConfs(
        mol,
        nconf,
        useRandomCoords=True,  # modified from default setting
        boxSizeMult=2.0,  # modified from default setting
        clearConfs=True,
        enforceChirality=True,
        ignoreSmoothingFailures=False,
        numZeroFail=1,
        pruneRmsThresh=-1.0,
        randNegEig=True,
        randomSeed=-1,
        useBasicKnowledge=True,
        useExpTorsionAnglePrefs=True,
    )

    try:
        AllChem.MMFFSanitizeMolecule(mol)
        mmff_props = AllChem.MMFFGetMoleculeProperties(mol)

        # Each conformers are optimized with MMFF
        energies = []
        for cid in cids:
            ff = AllChem.MMFFGetMoleculeForceField(mol, mmff_props, confId=cid)
            ff.Minimize()
            energy = ff.CalcEnergy()
            energies.append(energy)
    except Exception:
        # Each conformers are optimized with MMFF
        energies = []
        for cid in cids:
            ff = AllChem.UFFGetMoleculeForceField(mol, confId=cid)
            ff.Minimize()
            energy = ff.CalcEnergy()
            energies.append(energy)

    # conformer with the lowest energy is selected
    energies = np.asarray(energies)
    min_energy_idx = np.argsort(energies)[0]

    # Only lowest energy conformer is saved to mol object and returned.
    new_mol = Chem.Mol(mol)
    new_mol.RemoveAllConformers()
    min_conf = mol.GetConformer(cids[int(min_energy_idx)])
    new_mol.AddConformer(min_conf, assignId=True)
    mol = new_mol

    return mol


def mol2xyzfile(mol, filename="geometry.xyz", path="", comment="", write_file=False):
    """
    Accept rdkit conformer object with 3D coordinate and write xyz coordinate file. It is assumed that received mol object's atomic order has been refined.

    Parameters
    ----------
    mol : rdkit.Chem.rdchem.Mol
        Input molecule in RDKit format.
    filename : str
        Name of the output XYZ file.
    path : str
        Path to the directory where the XYZ file will be saved.
    comment : str
        Comment to include in the XYZ file.
    write_file : bool
        If True, write the XYZ file to disk. If False, return the XYZ string.

    Returns
    -------
    str
        XYZ coordinate as string.
    """
    if isinstance(mol, str):
        mol = mol2Gen3D(mol, nconf=100)
    # assertion whether it has 3D coordinate is reqiured.

    # atom_symbols = [atom.GetSymbol() for atom in mol.GetAtoms()]
    atom_symbols = [mol.GetAtomWithIdx(i).GetSymbol() for i in range(mol.GetNumAtoms())]
    positions = mol.GetConformer().GetPositions()

    # print(atom_symbols)
    if write_file:
        with open(path + "{}.xyz".format(filename), "w") as f:
            f.write("{}\n".format(len(atom_symbols)))
            f.write("{}\n".format(comment))
            for i in range(len(atom_symbols)):
                f.write(
                    " {symbol} {x:13.8f} {y:13.8f} {z:13.8f}\n".format(
                        symbol=atom_symbols[i],
                        x=positions[i][0],
                        y=positions[i][1],
                        z=positions[i][2],
                    )
                )
    else:
        xyz_string = ""
        xyz_string += f"{len(atom_symbols)}\n"
        xyz_string += f"{comment}\n"
        for i in range(len(atom_symbols)):
            if i != len(atom_symbols):
                xyz_string += f" {atom_symbols[i]} {positions[i][0]:13.8f} {positions[i][1]:13.8f} {positions[i][2]:13.8f}\n"
            else:
                xyz_string += f" {atom_symbols[i]} {positions[i][0]:13.8f} {positions[i][1]:13.8f} {positions[i][2]:13.8f}"
        #         print(xyz_string)

        return xyz_string


def attach_adsorbate_random(
    slab,
    adsorbate,
    randseed=None,
    position=None,
    max_height=2,
    min_height=-3.0,
    interval=20,
    offset=None,
):
    """
    Attach an adsorbate to a slab at a random position.

    It scans from max_height to min_height with interval and scan is stopped when molecule touchs the surface.

    Parameters
    ----------
    slab : ase.Atoms
        The slab to which the adsorbate will be attached.
    adsorbate : ase.Atoms
        The adsorbate molecule to be attached.
    randseed : int, optional
        Random seed for reproducibility.
    position : np.ndarray, optional
        The position at which to attach the adsorbate.
    max_height : float, optional
        The maximum height at which to place the adsorbate.
    min_height : float, optional
        The minimum height at which to place the adsorbate.
    interval : int, optional
        The number of height intervals to sample.
    offset : np.ndarray, optional
        Offset to apply to the adsorbate position.

    Returns
    -------
    ase.Atoms
        The slab with the attached adsorbate.
    """
    slab_indices = list(range(len(slab)))
    mol_index = np.argmin(np.array([atom.z for atom in adsorbate]))

    if randseed is not None:
        np.random.seed(randseed)
        vs = ["x", "-x", "y", "-y", "z", "-z"]
        adsorbate.rotate(a=90 * np.random.random(), v=vs[np.random.randint(0, 6)], center="COM")
        position = np.matmul(np.array(slab.get_cell())[:2, :2].T, np.random.rand(2, 1)).ravel()
    else:
        assert position is not None

    for height in np.linspace(max_height, min_height, interval):
        atoms = slab.copy()
        add_adsorbate(
            atoms,
            adsorbate,
            position=position,
            height=height,
            offset=offset,
            mol_index=mol_index,
        )

        adsorbate_indices = [i for i, at in enumerate(atoms) if i not in slab_indices]
        cutOff = neighborlist.natural_cutoffs(atoms)
        neighbor = neighborlist.NeighborList(cutOff, self_interaction=False, bothways=True)
        neighbor.update(atoms)
        matrix = neighbor.get_connectivity_matrix(sparse=False)
        if np.any(matrix[np.ix_(slab_indices, adsorbate_indices)]):
            # print("hi", height)
            break

    return atoms


def place_adsorbates(
    adsorbate1, adsorbate2, slab_indices=None, offset=None, return_all=False
):  # , offset=None
    """
    Place adsorbate1 on top of adsorbate2.

    Parameters
    ----------
    adsorbate1 : ase.Atoms
        The first adsorbate to place.
    adsorbate2 : ase.Atoms
        The second adsorbate to place on top of.
    slab_indices : list, optional
        Indices of the slab atoms.
    offset : np.ndarray, optional
        Offset to apply to the position of adsorbate1.
    return_all : bool, optional
        If True, return all combined structures.

    Returns
    -------
    list
        A list of combined structures.
    """

    mol_indices_1 = [at.index for at in adsorbate1 if at.index not in slab_indices]

    mol = adsorbate1[mol_indices_1]
    slab = adsorbate1[slab_indices]
    height = mol.positions[:, 2].min() - slab.positions[:, 2].max()
    if height < 1.0:
        height = 1.0

    combined_structures = []
    if offset is None:
        offsets = [(i / 3, j / 3) for i in range(-1, 2) for j in range(-1, 2)]
    else:
        offsets = [offset]

    for angle in np.linspace(0, 300, 6):
        rotated_mol = mol.copy()
        rotated_mol.rotate(angle, "z", "COM")
        for k, offset in enumerate(offsets):
            copied_adsorbate2 = adsorbate2.copy()
            copied_adsorbate1 = adsorbate1.copy()

            mol = copied_adsorbate1[mol_indices_1]

            adsorbate_info = {
                "top layer atom index": copied_adsorbate2[
                    [at.index for at in copied_adsorbate2 if at.index in slab_indices]
                ]
                .positions[:, 2]
                .argmax()
            }
            copied_adsorbate2.info["adsorbate_info"] = adsorbate_info

            copied_adsorbate2 = attach_adsorbate_random(
                copied_adsorbate2,
                rotated_mol,
                position=mol[0].position[:2],
                mol_index=0,
                offset=offset,
            )

            mol_indices_combined = [
                at.index for at in copied_adsorbate2 if at.index not in slab_indices
            ]

            mol_indices_2 = [at.index for at in adsorbate2 if at.index not in slab_indices]
            mol_indices_1_cobmined = sorted(
                set(mol_indices_combined).difference(set(mol_indices_2))
            )

            cutOff = neighborlist.natural_cutoffs(copied_adsorbate2)
            neighbor = neighborlist.NeighborList(cutOff, self_interaction=False, bothways=True)
            neighbor.update(copied_adsorbate2)
            adjacency = neighbor.get_connectivity_matrix(sparse=False)

            overlap = adjacency[np.ix_(mol_indices_2, mol_indices_1_cobmined)]

            if return_all:
                combined_structures.append(copied_adsorbate2)
            else:
                if np.any(overlap):
                    pass
                    # print(f"Two molecules are overlapping with offset : {offset}")
                else:
                    copied_adsorbate2.info["offset"] = f"{k}"
                    copied_adsorbate2.info["rotate_angle"] = f"{int(angle)}"
                    combined_structures.append(copied_adsorbate2)

    return combined_structures


def prepare_isolated_minima_hopping(
    rootdir,
    molecules,
    slab,
    fix_indices,
    overwrite=False,
    input_filename="initial_structures.xyz",
    k=4.0,
):
    """
    Place one adsorbate on surface awaring the site classification.

    Parameters
    ----------
    rootdir : str
        Path of workdirectory
    molecules : list
        list of Molecule objects
    slab : ASE atoms
        slab atoms
    fix_indices : list
        list of fixed slab atoms
    overwrite : bool, optional
        Whether to overwrite existing structures, by default False
    input_filename : str, optional
        name of initial structure file, by default "initial_structures.xyz"
    k : float, optional
        spring constant for relaxed slab, by default 4.0

    Returns
    -------
    list of list of Atoms
        Nested list of initial adsorbates on surface.
    """
    print("Isolated minima hopping preparation started.", flush=True)
    workdir = rootdir / "0_isolated_adsorbates"
    workdir.mkdir(exist_ok=True, parents=True)

    initial_structures = []
    output_dir = []
    slab_indices = list(range(len(slab)))
    groups, sym_dict = get_slab_atom_classification(slab, fix_indices=fix_indices)
    positions = [slab[group[0]].position for group in groups]

    for i, (smi, mol) in enumerate(molecules.items()):
        formula = mol.get_formula_rdkit()
        rundir = Path(workdir / f"{str(i).zfill(2)}_{formula}")
        Path(rundir).mkdir(exist_ok=True, parents=True)

        if Path(rundir / f"{input_filename}").is_file() and not overwrite:
            print("already file exists, read from there.")
            list_of_atoms = read(rundir / f"{input_filename}", ":")

        else:
            # Generate 3D coordinate of molecule from SMILES
            asemol = read(StringIO(mol2xyzfile(smi)), format="xyz")

            list_of_atoms = []
            # for j in range(num_initial_structures):
            for position in positions:
                atoms = slab.copy()
                # atoms = attach_adsorbate_random(atoms, asemol, randseed=j)
                atoms = attach_adsorbate_random(slab, asemol, position=position[:2])

                atoms.info["category"] = "adsorbates"
                atoms.info["SMILES"] = smi
                atoms.info["formula"] = formula

                tag_atoms(atoms, slab_indices, fix_indices)
                list_of_atoms.append(atoms.copy())

            if not Path(rundir / input_filename).is_file() or overwrite:
                write(workdir / f"{str(i).zfill(2)}_{formula}/{input_filename}", list_of_atoms)

        for atoms in list_of_atoms:
            apply_constraints(
                atoms,
                relax_slab=True,
                constrain_Hookean=True,
                method=None,
                volatilation=True,
                fix_indices=fix_indices,
                slab_indices=slab_indices,
            )
            # Add Hookean constraint tethered to original position
            relaxed_slab_constraints = [
                Hookean(a1=i, a2=atoms[i].position, rt=0.94, k=k)
                for i in slab_indices
                if i not in fix_indices
            ]
            atoms.constraints += relaxed_slab_constraints
        initial_structures.append(list_of_atoms)
        output_dir.append(workdir / f"{str(i).zfill(2)}_{formula}" / "minhop.xyz")

    print("Isolated minima hopping preparation finished.", flush=True)

    return initial_structures, output_dir


def prepare_dimer_minima_hopping(
    rootdir,
    reactive_states,
    slab,
    fix_indices,
    generate=True,
    num_initial_structures=20,
    input_filename="initial_structures.xyz",
    k=4.0,
    overwrite=False,
    threshold=1.0,
):
    """
    Prepare dimer (two adsorbates on surface) minima hopping.

    Parameters
    ----------
    rootdir : str
        Path of workdirectory
    reactive_states : dict
        dictionary with SMILES string as key and ReactiveState as value
    slab : ASE atoms
        slab atoms
    fix_indices : list
        list of fixed slab atom index
    generate : bool, optional
        generate from SMILES rather than using one adsorbate minima hopping , by default True
    num_initial_structures : int, optional
        Number of initial configs for minima hopping , by default 20
    input_filename : str
        name of initial structure file, by default "initial_structures.xyz".
    k : float, optional
        spring constant for relaxed slab atom Hookean , by default 4.0
    overwrite : bool, optional
        whether to overwrite already exisiting initial structures, by default False
    threshold : float, optional
        threshold for slab deformation in Angstrom, by default 1.0

    Returns
    -------
    initial_structures : list of list of Atoms
        List of list of two adsorbates on surface.
    output_dir : list
        List of output dir.
    name_dict : dict
        Names of chemical species saved in dictionary.
    """
    print("Dimer minima hopping preparation started.", flush=True)
    slab_indices = np.arange(len(slab))

    workdir = rootdir / "1_two_adsorbates"
    workdir.mkdir(exist_ok=True, parents=True)

    name_dict = {}
    for path in sorted(Path(rootdir / "0_isolated_adsorbates").glob("*")):
        index = str(path).split("/")[-1].split("_")[0]
        atoms = read(path / "initial_structures.xyz", "0")
        formula = atoms.info["formula"]
        name = f"{str(index).zfill(2)}_{formula}"
        name_dict[atoms.info["SMILES"]] = name

    reactive_states_two_molecules = [rs for rs in reactive_states.values() if rs.NumMols == 2]
    reactivestate_dict = {}
    for i, rs in enumerate(reactive_states_two_molecules):
        reactivestate_dict[i] = {
            "reactive_state": rs,
            "formula": rs.get_formula(),
            "smiles": rs.smiles,  # ".".join([mol.smiles for mol in rs.get_molecules()])
        }
    df = pd.DataFrame(reactivestate_dict).T

    initial_structures = []
    output_dir = []
    for (
        i,
        row,
    ) in df.iterrows():
        rundir = Path(workdir / f"{str(i).zfill(2)}")

        if Path(rundir / input_filename).is_file() and not overwrite:
            print("already file exists, read from there.")
            list_of_atoms = read(rundir / "initial_structures.xyz", ":")

        elif generate:
            list_of_atoms = generate_two_adsorbate_structures(
                row["reactive_state"].smiles, slab, fix_indices
            )

        else:
            list_of_atoms = reactive_states2combined_structures(
                row["reactive_state"],
                Path(rootdir / "0_isolated_adsorbates"),
                name_dict,
                minima_traj="minhop.xyz",
                energy_key="last_op__optimize_energy",
                minima_key="minhop_min",
                slab_indices=slab_indices,
                pristine_slab=slab,
                num_output=num_initial_structures,
                threshold=threshold,
            )

        for at in list_of_atoms:
            at.info = {}
            at.info["category"] = "adsorbates"
            at.info["SMILES"] = row["smiles"]
            at.info["formula"] = row["formula"]

            tag_atoms(at, slab_indices, fix_indices)
        rundir.mkdir(exist_ok=True, parents=True)
        if not Path(rundir / input_filename).is_file() or overwrite:
            write(rundir / input_filename, list_of_atoms)

        for atoms in list_of_atoms:
            apply_constraints(
                atoms,
                relax_slab=True,
                constrain_Hookean=True,
                method=None,
                volatilation=True,
                fix_indices=fix_indices,
                slab_indices=slab_indices,
            )
            # Add Hookean constraint tethered to original position
            relaxed_slab_constraints = [
                Hookean(a1=i, a2=atoms[i].position, rt=0.94, k=k)
                for i in slab_indices
                if i not in fix_indices
            ]
            atoms.constraints += relaxed_slab_constraints

        initial_structures.append(list_of_atoms)
        output_dir.append(rundir / "minhop.xyz")

    return initial_structures, output_dir, name_dict


def generate_two_adsorbate_structures(smiles, slab, fix_indices, mult=1.2):
    """
    Generate two adsorbates on surface awaring surface site uniqueness.

    Parameters
    ----------
    smiles : str
        SMILES string with two molecules (e.g. "C[C].[OH]")
    slab : ASE atoms
        slab atoms
    fix_indices : list
        list of fixed slab atoms
    mult : float
        mult for neighborlist , default 1.2

    Returns
    -------
    list
        List of structures with two adsorbates on surface.
    """
    groups, _ = get_slab_atom_classification(slab, fix_indices=fix_indices)
    positions = [slab[group[0]].position for group in groups]
    slab_indices = np.arange(len(slab))

    smi1, smi2 = smiles.split(".")
    # 1. attach one adsorbate on surface
    asemol1 = read(StringIO(mol2xyzfile(smi1)), format="xyz")
    asemol2 = read(StringIO(mol2xyzfile(smi2)), format="xyz")
    one_adsorbate1 = [
        attach_adsorbate_random(slab, asemol1, position=position[:2]) for position in positions
    ]
    adsorbate1_indices = [at.index for at in one_adsorbate1[0] if at.index not in slab_indices]

    # 2. for given one adsorbate attach the other adsorbate
    two_adsorbates = []
    for atoms in one_adsorbate1:
        groups, _ = get_slab_atom_classification(atoms, fix_indices=fix_indices)
        re_group = [group for group in groups if np.all([i in slab_indices for i in group])]
        positions = [slab[group[0]].position for group in re_group]
        two_adsorbates += [
            attach_adsorbate_random(atoms, asemol2, position=position[:2]) for position in positions
        ]
    adsorbate2_indices = [
        at.index
        for at in two_adsorbates[0]
        if at.index not in slab_indices and at.index not in adsorbate1_indices
    ]

    combined_structures = []
    for atoms in two_adsorbates:
        cutOff = neighborlist.natural_cutoffs(atoms, mult=mult)
        neighbor = neighborlist.NeighborList(cutOff, self_interaction=False, bothways=True)
        neighbor.update(atoms)
        adjacency = neighbor.get_connectivity_matrix(sparse=False)

        overlap = adjacency[np.ix_(adsorbate1_indices, adsorbate2_indices)]

        if not np.any(overlap):
            combined_structures.append(atoms)

    return combined_structures


def reactive_states2combined_structures(
    reactivestate,
    isolated_molecule_path,
    name_dict,
    minima_traj,
    pristine_slab,
    slab_indices,
    minima_key=None,
    energy_key=None,
    threshold=1,
    num_output=10,
):
    """
    Convert reaction states object into ASE geometries with two adsorbates on surface.

    Parameters
    ----------
    reactivestate : ReactiveState
        The reactive state object containing information about the two adsorbates.
    isolated_molecule_path : str
        Path to the directory containing isolated molecule geometries.
    name_dict : dict
        Dictionary mapping SMILES strings to molecule names.
    minima_traj : str
        Trajectory file containing minima geometries.
    pristine_slab : ase.Atoms
        The pristine slab geometry.
    slab_indices : list
        Indices of the slab atoms.
    minima_key : str, optional
        Key to filter minima based on their configuration type.
    energy_key : str, optional
        Key to retrieve energy values from minima.
    threshold : float, optional
        Threshold for slab deformation.
    num_output : int, optional
        Number of output structures to return.

    Returns
    -------
    list
        A list of ASE geometries with two adsorbates on the surface.
    """
    global_minima = []
    for mol in reactivestate.mols:
        smi = mol.smiles
        minima = read(f"{isolated_molecule_path}/{name_dict[smi]}/{minima_traj}", ":")
        if minima_key is not None:
            minima = [
                at for at in minima if minima_key in at.info["config_type"] and at.info["intact"]
            ]
        minima, _ = check_slab_deformation(pristine_slab, minima, threshold=threshold)

        if energy_key is None:
            energy = np.array([at.get_potential_energy() for at in minima])
        else:
            energy = np.array([at.info[energy_key] for at in minima])

        global_minima.append(minima[np.argmin(energy)])

    combined = place_adsorbates(global_minima[0], global_minima[1], slab_indices=slab_indices)
    combined += place_adsorbates(global_minima[1], global_minima[0], slab_indices=slab_indices)

    if len(combined) > num_output:
        combined = random.sample(combined, num_output)

    combined = align_index_compounds(combined, slab_indices=slab_indices)

    for at in combined:
        at.info["formula"] = reactivestate.get_formula()
        at.info["smiles"] = ".".join([mol.smiles for mol in reactivestate.get_molecules()])

    return combined


def change_adsorbate_indices(atoms, slab_indices, mapping_dict):
    """
    Change adsorbate index based on mapping dict.

    Parameters
    ----------
    atoms : ase.Atoms
        The atoms object containing the adsorbates.
    slab_indices : list
        Indices of the slab atoms.
    mapping_dict : dict
        Mapping dictionary for changing adsorbate indices.

    Returns
    -------
    ase.Atoms
        The modified atoms object with updated adsorbate indices.
    """
    adsorbate_indices = [atom.index for atom in atoms if atom.index not in slab_indices]

    atoms_old = []
    for atom in list(atoms[adsorbate_indices]):
        atoms_old.append([atom.symbol, atom.position])

    del atoms[adsorbate_indices]

    new_adsorbates = [atoms_old[idx] for idx in mapping_dict.keys()]
    for atom in new_adsorbates:
        atoms.append(Atom(atom[0], position=atom[1]))

    return atoms


def align_index_compounds(atoms_list, slab_indices, mult=0.8):
    """
    In case there are different atom index eventhough they are same adsorbate complexes, this fucntion impose same adsorbate index for adsorbates.

    It is aligned based on the first item of the list.

    Parameters
    ----------
    atoms_list : list
        list of ase.Atoms
    slab_indices : list
        Indices of the slab atoms.
    mult : float
        Multiplicative factor for the graph alignment.

    Returns
    -------
    list
        A list of ASE geometries with aligned adsorbate indices.
    """
    pivot = graphfromase(atoms_list[0], slab_indices=slab_indices, mult=mult)

    index_aligned_atoms_list = []
    for atoms in atoms_list:
        ase_graph2 = graphfromase(atoms, slab_indices=slab_indices, mult=mult)
        isomorphic, map12, map21 = pivot.isomorphic_vf2(
            ase_graph2,
            color1=pivot.vs["AtomicNums"],
            color2=ase_graph2.vs["AtomicNums"],
            return_mapping_12=True,
            return_mapping_21=True,
        )
        if not isomorphic:
            raise ValueError("Adsorbate should be isomorphic.")
        mapping_dict = dict(zip(map12, map21))
        index_aligned_atoms_list.append(change_adsorbate_indices(atoms, slab_indices, mapping_dict))
    #        index_aligned_atoms_list.append(swap_multiple_indices(atoms, list(mapping_dict.keys()), list(mapping_dict.values())))

    return index_aligned_atoms_list


def prevent_volatilation(atoms, slab_indices, padding=2.0, verbose=False, k=20):
    """
    Prevent volatilation of molecule.

    This calculates longest distance from center of mass atom and add it to maximum metal layer with padding (e.g. Angs)
    Ax + By + Cz + D = 0
    D = metal_z + max_dist_cm + padding

    Parameters
    ----------
    atoms : ase.Atoms
        The atoms object containing the molecular structure.
    slab_indices : list
        Indices of the slab atoms.
    padding : float
        Padding to be added to the maximum distance.
    verbose : bool
        If True, print detailed information.
    k : float
        Force constant for the Hookean potential.

    Returns
    -------
    list
        A list of Hookean constraints that prevents volatilization.
    """
    graph = graphfromase(atoms, slab_indices)
    fragment_indices = []
    for fragment in graph.decompose():
        fragment_indices.append([v["AtomIndex"] for v in fragment.vs])

    # molindices = [atom.index for atom in slab if atom.symbol != "Rh"]
    Hookeans = []
    slab_z = max([atoms[i].z for i in slab_indices])
    #    if indices is None:
    for molindices in fragment_indices:
        mol = Atoms([atom for atom in atoms if atom.index in molindices])
        cm_index = np.argmin(
            np.array([np.linalg.norm(atom.position - mol.get_center_of_mass()) for atom in mol])
        )
        farthest_index = np.argmax(
            np.array([np.linalg.norm(atom.position - mol.get_center_of_mass()) for atom in mol])
        )
        distance_cm = mol.get_distance(cm_index, farthest_index)

        d = (slab_z + distance_cm + padding) * -1

        Hookeans.append(Hookean(a1=molindices[cm_index], a2=(0, 0, 1, d), k=k))

        if verbose:
            print(f"cm_index : {molindices[cm_index]}")
            print(f"farthest_index : {farthest_index}")
            print(f"distance_cm : {distance_cm}")
            print(f"d : {d}\n")

    return Hookeans


def apply_constraints(atoms, **kwargs):
    """
    Apply constraints to the system.

    Parameters
    ----------
    atoms : ase object
        system where constraints will be imposed.
    **kwargs : dict
        Additional keyword arguments.
        - relax_slab : bool
          whether to relax upper two metal layer. If False, all metal atoms are fixed.
        - constrain_Hookean : bool
          Whether to impose Hookean constraint on adsorbate molecule.
        - method : str
          Hookean constraint is generated based on the SMILES string of adsorbate molecule if method="smiles".
        - volatilation : bool
          whether to impose Hookean constraint with respect to surface.
        - uppermost_layer_height : float
          The height of the uppermost layer of the slab to be fixed.
        - fix_indices : list
          List of atom indices to be fixed.
        - slab_indices : list
          List of slab atom indices.

    Returns
    -------
    None
        Constraints are imposed to give atoms inplace.
    """
    relax_slab = kwargs.get("relax_slab", False)
    constrain_Hookean = kwargs.get("constrain_Hookean", True)
    method = kwargs.get("method", "smiles")
    volatilation = kwargs.get("volatilation", True)
    uppermost_layer_height = kwargs.get("uppermost_layer_height", 19)
    fix_indices = kwargs.get("fix_indices", None)
    slab_indices = kwargs.get("slab_indices", None)

    cons = []
    default_rcuts = []
    del atoms.constraints  # Delete constraints first
    cutOff = neighborlist.natural_cutoffs(atoms)
    neighbor = neighborlist.NeighborList(cutOff, self_interaction=False, bothways=False)
    neighbor.update(atoms)
    matrix = neighbor.get_connectivity_matrix(sparse=False)

    adsorbate_indices = [i for i, at in enumerate(atoms) if i not in slab_indices]
    for i in adsorbate_indices:
        for j in adsorbate_indices:
            if matrix[i, j] == 1:
                d = atoms.get_distances(i, j, mic=True)
                default_rcuts.append([i, j, d[0]])

    cons = []
    if relax_slab:
        if fix_indices is not None:
            cons.append(FixAtoms(indices=fix_indices))
        elif uppermost_layer_height:
            cons.append(
                FixAtoms(indices=[atom.index for atom in atoms if atom.z < uppermost_layer_height])
            )
    else:
        cons.append(FixAtoms(indices=[atom.index for atom in atoms if atom.index in slab_indices]))

    if constrain_Hookean and method == "smiles":
        smiles = kwargs["smiles"]
        mapped_graph = check_adsorbate_isomorphism(smiles, atoms)

        if mapped_graph:
            for edge in mapped_graph.es:
                bond_pair = [mapped_graph.vs[vid]["AtomIndex"] for vid in edge.tuple]
                cons.append(
                    Hookean(
                        a1=bond_pair[0],
                        a2=bond_pair[1],
                        rt=1.05 * edge["bondlength"],
                        k=10,
                    )
                )
    elif constrain_Hookean and method != "smiles":
        for r in default_rcuts:
            cons.append(Hookean(a1=r[0], a2=r[1], rt=1.05 * r[2], k=20.0))
    else:
        # cons = constraints
        pass

    if volatilation:
        cons += prevent_volatilation(atoms, slab_indices)

    atoms.constraints = cons


def check_slab_deformation(pristine_slab, minima_list, relaxed_indices=None, threshold=1.0):
    """
    Check whether surface slab has been distorted as compared to pristine_slab. Returns only intact surfaces.

    Parameters
    ----------
    pristine_slab : ASE Atoms
        The pristine slab structure to compare against.
    minima_list : list of ASE atoms
        The list of slab structures to check for deformation.
    relaxed_indices : list
        list of indices indicating which atom indices are relaxed
    threshold : float
        threshold value to determine whether it's deformed.

    Returns
    -------
    intact_surface : list of ase.Atoms
        List of minima with intact surface.
    deformed_surface : list of ase.Atoms
        List of minima with distorted surface.
    """
    ref_positions = pristine_slab.positions

    intact_surface = []
    deformed_surface = []
    if relaxed_indices is None:
        relaxed_indices = np.arange(len(pristine_slab))

    for j, test_atoms in enumerate(minima_list):
        test_positions = test_atoms.positions
        slab_deformation = {
            i: np.linalg.norm(ref_positions[i] - test_positions[i]) for i in relaxed_indices
        }
        if np.all([disp < threshold for disp in slab_deformation.values()]):
            intact_surface.append(minima_list[j])
        else:
            deformed_surface.append(minima_list[j])
    return intact_surface, deformed_surface


def is_adsorbate_desorbed(atoms, slab_indices, mult=1.8):
    """
    Check whether adsorbates are desorbed from the surface.

    Parameters
    ----------
    atoms : ASE atoms
        adsorbates on surface
    slab_indices : list
        list of slab atom indices
    mult : float, optional
        mult for neighborlist, by default 0.8

    Returns
    -------
    bool
        True if at least one of adsorbates desorbed from the surface.
    """

    graph = graphfromase(atoms, slab_indices)

    cutOff = neighborlist.natural_cutoffs(atoms, mult=mult)
    neighbor = neighborlist.NeighborList(cutOff, self_interaction=False, bothways=True)
    neighbor.update(atoms)
    adjacency = neighbor.get_connectivity_matrix(sparse=False)

    bonding_between_slab_adsorbate = []
    for g in graph.decompose():
        adsorbate_indices = g.vs.get_attribute_values("AtomIndex")
        bonding_between_slab_adsorbate.append(
            np.any(adjacency[np.ix_(slab_indices, adsorbate_indices)])
        )

    if np.all(bonding_between_slab_adsorbate):
        return False
    else:
        return True


def is_adsorbate_intercalated(atoms, slab_indices, fix_indices, mult=1.0):
    """
    Check whether there's any intercalated adsorbate. This is following cattsunami's approach.

    Parameters
    ----------
    atoms : ASE atoms
        adsorbates on surface
    slab_indices : list
        list of slab indices
    fix_indices : list
        list of fixed atoms
    mult : float, optional
        mult for neighborlist, by default 1.0

    Returns
    -------
    bool
        True if there's any intercalation.
    """

    graph = graphfromase(atoms, slab_indices)

    cutOff = neighborlist.natural_cutoffs(atoms, mult=mult)
    neighbor = neighborlist.NeighborList(cutOff, self_interaction=False, bothways=True)
    neighbor.update(atoms)
    adjacency = neighbor.get_connectivity_matrix(sparse=False)

    intercalation = []
    for g in graph.decompose():
        adsorbate_indices = g.vs.get_attribute_values("AtomIndex")
        intercalation.append(np.any(adjacency[np.ix_(fix_indices, adsorbate_indices)]))

    if np.any(intercalation):
        return True
    else:
        return False


def filter_minhop(
    traj,
    slab,
    fix_indices,
    config_type="minhop_min",
    threshold=1.6,
    mult=1.5,
    disable_filter=[],
    verbose=False,
):
    """
    Filter the minima hopping trajectory based on various criteria.

    Parameters
    ----------
    traj : list of ase.Atoms
        The trajectory to filter.
    slab : ase.Atoms
        The pristine slab structure to compare against.
    fix_indices : list
        The indices of the atoms to fix during optimization.
    config_type : str
        The configuration type to filter by.
    threshold : float
        The threshold for slab deformation.
    mult : float
        The multiplier for chemical bond used for detection of desorption.
    disable_filter : list
        The list of filters to disable. Used to allow special cases.
    verbose : bool
        Whether to print verbose output.

    Returns
    -------
    list of ase.Atoms
        The filtered trajectory.
    """
    slab_indices = np.arange(len(slab))

    traj = [at for at in traj if "minhop_min" in at.info["config_type"]]
    numtraj = len(traj)
    if verbose:
        print(f"Starting with total number of : {numtraj}")

    traj = [at for at in traj if at.info["intact"]]
    if verbose:
        if len(traj) < numtraj:
            print(f"{numtraj - len(traj)} filtered due to intact")
    numtraj = len(traj)

    if "slab_deformation" not in disable_filter:
        traj, _ = check_slab_deformation(slab, traj, threshold=threshold)
        if verbose:
            if len(traj) < numtraj:
                print(f"{numtraj - len(traj)} filtered due to slab deformation")
        numtraj = len(traj)

    if "desorption" not in disable_filter:
        traj = [at for at in traj if not is_adsorbate_desorbed(at, slab_indices, mult=mult)]
        if verbose:
            if len(traj) < numtraj:
                print(f"{numtraj - len(traj)} filtered due to desorption")
        numtraj = len(traj)

    if "intercalation" not in disable_filter:
        traj = [at for at in traj if not is_adsorbate_intercalated(at, slab_indices, fix_indices)]
        if verbose:
            if len(traj) < numtraj:
                print(f"{numtraj - len(traj)} filtered due to intercalation")

    return traj


def make_pickle(rootdir, reactive_states, molecules, save_csv=True):
    """
    Create a CSV (or pickle) file from the reactive states and molecules.

    Produced CSV file is used for mapping molecule, reactive_states with the corresponding directory of minima hopping results.

    Parameters
    ----------
    rootdir : Path
        The root directory for the simulation data.
    reactive_states : dict
        A dictionary of reactive states.
    molecules : dict
        A dictionary of molecules.
    save_csv : bool
        Whether to save the data as a CSV file.

    Returns
    -------
    None
        File "reactive_states.csv" is written in rootdir.
    """
    name_dict = {}
    for path in sorted(Path(rootdir / "0_isolated_adsorbates").glob("*")):
        index = str(path).split("/")[-1].split("_")[0]
        atoms = read(path / "initial_structures.xyz", "0")
        formula = atoms.info["formula"]
        name = f"{str(index).zfill(2)}_{formula}"
        name_dict[atoms.info["SMILES"]] = name

    # Combine isolated + dimer minima hopping
    reactivestate_dict = {}
    count = 0
    for i, (smi, mol) in enumerate(molecules.items()):
        reactivestate_dict[count] = {
            "formula": mol.get_formula(),
            "smiles": mol.smiles,
            "path": rootdir / f"0_isolated_adsorbates/{name_dict[mol.smiles]}",
        }
        count += 1

    for path in sorted(Path(rootdir / "1_two_adsorbates").glob("*")):
        atoms = read(path / "initial_structures.xyz", "0")
        if "smiles" in atoms.info.keys():
            atoms.info["SMILES"] = atoms.info.pop("smiles")
        smiles = atoms.info["SMILES"]

        rs = reactive_states[smiles]
        reactivestate_dict[count] = {
            #            "reactive_state" : rs,
            "formula": rs.get_formula(),
            "smiles": smiles,
            "path": str(path),
        }

        count += 1

    df = pd.DataFrame(reactivestate_dict).T
    #    df.to_pickle(rootdir / f"reactive_states.pickle")
    df.to_csv(rootdir / "reactive_states.csv")

    print("reactive_states.csv saved\n", flush=True)


def build_SOAP_vector(list_of_atoms, rcut=6.0, nmax=9, lmax=3, sigma=0.23, average="inner"):
    """
    Build a SOAP vector for a list of atoms.

    Parameters
    ----------
    list_of_atoms : list
        A list of ASE atoms objects.
    rcut : float, optional
        The cutoff radius for the SOAP descriptor, by default 6.0
    nmax : int, optional
        The maximum radial basis function degree, by default 9
    lmax : int, optional
        The maximum angular momentum quantum number, by default 3
    sigma : float, optional
        The width of the Gaussian smearing, by default 0.23
    average : str, optional
        The averaging method to use, by default "inner"

    Returns
    -------
    np.ndarray
        The SOAP vector for the input atoms.
    """

    # Setting up the SOAP descriptor
    soap = SOAP(
        species=list(list_of_atoms[0].symbols.species()),
        periodic=True,
        r_cut=rcut,
        n_max=nmax,
        l_max=lmax,
        sigma=sigma,
        average=average,
    )

    return soap.create(list_of_atoms)


def sample_kmeans(
    minima,
    slab_indices,
    energy_key="last_op__optimize_energy",
    distance_cutoff=6.0,
    energy_cutoff=1.5,
    n_samples=20,
    mult=0.8,
):
    """
    Select minima based on distance and energy.

    Parameters
    ----------
    minima : list
        list of minima to be filtered
    slab_indices : list
        list of slab atom indices
    energy_key : str, optional
        energy key to be read from atoms.info , by default "last_op__optimize_energy"
    distance_cutoff : float, optional
        distance cutoff for filtering, by default 6.0 Angs
    energy_cutoff : float, optional
        energy cutoff for filtering, by default 1.5 eV
    n_samples : int, optional
        Number of samples to get, by default 20
    mult : float, optional
        mult for neighborlist

    Returns
    -------
    list
        List of atoms to be used for minima hopping.
    """
    if len(minima) <= n_samples:
        return minima

    #    print(f"start : {len(minima)}")

    minima_dict = {}
    for i, atoms in enumerate(minima):
        adsorbate_graph = graphfromase(atoms, slab_indices=slab_indices, mult=mult)
        graphs = adsorbate_graph.decompose()
        if len(graphs) == 1:
            minima_dict[i] = {
                "ase": atoms,
                "AE": atoms.info[energy_key],
            }
            df = pd.DataFrame.from_dict(minima_dict).transpose()
            df["AE"] = df.AE.astype("float")

            minima = df.loc[df.AE < np.min(df.AE.values) + energy_cutoff].ase.to_list()
        else:
            center_of_masses = []
            for graph in graphs:
                indices = graph.vs.get_attribute_values("AtomIndex")
                center_of_masses.append(atoms.get_center_of_mass(indices=indices))
            v, distance = find_mic(
                center_of_masses[0] - center_of_masses[1],
                cell=atoms.cell,
                pbc=atoms.pbc,
            )
            minima_dict[i] = {
                "ase": atoms,
                "AE": atoms.info[energy_key],
                "distance": distance,
            }
            df = pd.DataFrame.from_dict(minima_dict).transpose()
            df["AE"] = df.AE.astype("float")

            minima = df.loc[
                (df.distance < distance_cutoff) | (df.AE < np.min(df.AE.values) + energy_cutoff)
            ].ase.to_list()
    #    print(f"shrinked : {len(minima)}")

    if len(minima) <= n_samples:
        return minima

    minima_soap = build_SOAP_vector(minima)
    kernel_pca = KernelPCA(n_components=2, kernel="poly")
    minima_soap_kernel_pca = kernel_pca.fit_transform(minima_soap)
    clustering = KMeans(n_clusters=n_samples, random_state=1).fit(minima_soap_kernel_pca)

    groups = {}
    for i, at in enumerate(minima):
        group_key = clustering.labels_[i]
        if group_key not in groups.keys():
            groups[group_key] = [at]
        else:
            groups[group_key].append(at)
    return [atoms[0] for i, atoms in groups.items()]
