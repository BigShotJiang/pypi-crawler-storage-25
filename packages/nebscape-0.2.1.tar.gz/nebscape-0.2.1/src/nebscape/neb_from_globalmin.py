"""
Tools for generating interpolations using geometries from minima hopping.
"""

from ase.io import read, write
from ase.geometry import find_mic
import numpy as np
from .utils import (
    get_idpp_surface_area,
)
from .atommapper import is_atom_mapped 
from .neb_helpers import (
    get_atom_mapped_configs_list,
)
from .minhop_helpers import (
    check_slab_deformation,
    is_adsorbate_desorbed,
    is_adsorbate_intercalated,
    build_SOAP_vector,
    sample_kmeans,
)

# from wfl.descriptors.mace_desc import calculate as desc_calc
from pathlib import Path
import decaf
import pandas as pd

from .index_permutation import apply_permutation_parallel
from wfl.configset import ConfigSet, OutputSpec
import json
from operator import itemgetter


# class check_slab_distortion(ABC):
#    def __init__(self, clean_slab, slab_indices, threshold=1.7):
#        self.threshold = threshold
#        self.clean_slab = clean_slab
#        self.slab_indices = slab_indices
#
#    def stop(self, atoms):
#        if get_partial_displacements([atoms, self.clean_slab], self.slab_indices) > self.threshold:
#            print(
#                "displacement is : ",
#                get_partial_displacements([atoms, self.clean_slab], self.slab_indices),
#                flush=True,
#            )
#            return True
#        else:
#            return False


def select_from_SOAP(
    atoms_list,
    max_num_select=5,
    energy_key="last_op__optimize_energy",
    return_dict=False,
    rcut=6,
    nmax=9,
    lmax=3,
    sigma=0.23,
):
    """
    Select minima structure from minima hopping.

    This uses by default DECAF to get unique group of minima but if there are more than "num_select" groups, it falls back to KMeans clustering and returns only "num_select" number of structures.
    Only lowest energy structure from each group is selected.

    Parameters
    ----------
    atoms_list : list
        List of atoms which are minima
    max_num_select : int (default 5)
        Number of minima to be selected
    energy_key : str
        Key for Atoms.info where energy is stored.
    return_dict : bool
        If True, return a dictionary of all minima instead of just the representatives.
    rcut : float
        Cutoff radius for neighbor environment.
    nmax : int
        nmax for SOAP.
    lmax : int
        lmax for SOAP.
    sigma : float
        Sigma for SOAP.

    Returns
    -------
    list
        List of selected atomic structures.
    """
    minima_soap = build_SOAP_vector(
        atoms_list, rcut=rcut, nmax=nmax, lmax=lmax, sigma=sigma, average="inner"
    )

    # Use DECAF to get clustering
    embed_cluster = decaf.embed_cluster(minima_soap, embed_str="cMDS", cluster_str="MSC")
    embed_cluster.get_embed(dim=0, less_stick_seg=False)
    #    embed_cluster.get_cluster(bandwidth=0, bandwidth_estimate='Gaussian', label_all='Both', classify_mode='TrainingData')
    _, _, _, _, bandwidth_full = embed_cluster.get_bandwidth_Gaussian()
    for bandwidth in bandwidth_full:
        embed_cluster.get_cluster(
            bandwidth=bandwidth,
            bandwidth_estimate="Gaussian",
            label_all="Both",
            classify_mode="TrainingData",
        )
        if embed_cluster.groupnum <= max_num_select:
            break
    if embed_cluster.groupnum > max_num_select:
        raise ValueError

    print(f"{embed_cluster.groupnum} groups detected.")
    minima_dict = {}
    if return_dict:
        for group_id, str_id in enumerate(embed_cluster.t_gID):
            if len(str_id) != 0:
                minima_dict[group_id] = [atoms_list[i] for i in str_id]
        return minima_dict
    else:
        label_dict = {
            idx: group_id for group_id, str_id in enumerate(embed_cluster.t_gID) for idx in str_id
        }
        labels = [label_dict[idx] for idx in sorted(label_dict.keys())]

        minima_dict = {}
        for i, atoms in enumerate(atoms_list):
            minima_dict[i] = {
                "ase": atoms,
                "AE": atoms.info[energy_key],
                "label": labels[i],
            }
        df = pd.DataFrame.from_dict(minima_dict).transpose()
        df["AE"] = df.AE.astype("float")

        representatives = [df.loc[df.label == g].AE.idxmin() for g in np.unique(labels)]

        return [atoms_list[i] for i in representatives]


def get_low_minima(
    reaction,
    reactivestate_dataframe,
    path_key,
    slab,
    fix_indices,
    num_select=3,
    slab_deform_threshold=1.0,
    avoid_desorption=True,
    avoid_intercalation=True,
    minima_filename="reac_constraint_free_opt.xyz",
    minima_key="minhop_min",
    mult=1.5,
    verbose=False,
):
    """
    Select minima from minima hopping for NEB interpolation.

    Parameters
    ----------
    reaction : str or Reaction class object
        The reaction to be studied
    reactivestate_dataframe : pandas dataframe
        Its index will be used for searching corresponding reactive state minima hopping results
    path_key : str
        path key in dataframe
    slab : ASE atoms
        slab without adsorbates.
    fix_indices : list of int
        indices of atoms to be fixed during optimization.
    num_select : int
        if int, given number of lowest samples are selected.
        if float, given energy range above global minima are selected.
    slab_deform_threshold : float
        threshold for slab deformation
    avoid_desorption : bool
        whether to avoid desorption of adsorbates
    avoid_intercalation : bool
        whether to avoid intercalation of adsorbates
    minima_filename : str
        minima file name where minima structures are saved
    minima_key : str
        key to identify minima in the trajectory
    mult : float
        multiplier for identifying desorption from surface.
    verbose : bool
        whether to print verbose output

    Returns
    -------
    reactant_minima : list of ASE atoms
        Selected reactant minima for NEB interpolation.
    product_minima : list of ASE atoms
        Selected product minima for NEB interpolation.
    mapped_list : list of tuples
        List of atom mappings for the reaction.
    """
    slab_indices = np.arange(len(slab))

    if isinstance(reaction, str):
        rxnsmiles = reaction
    else:  # if ReactiveState object was given : type check might be needed
        rxnsmiles = reaction.rxnsmiles
    reactant_smi, product_smi = rxnsmiles.split(">>")
    # reactant_index = reactivestate_dataframe.loc[reactivestate_dataframe.smiles == reactant_smi].index.item()
    # product_index = reactivestate_dataframe.loc[reactivestate_dataframe.smiles == product_smi].index.item()

    # Get minima hopping results
    reactant_minima = read(
        f"{reactivestate_dataframe.loc[reactivestate_dataframe.smiles == reactant_smi][path_key].item()}/{minima_filename}",
        ":",
    )
    product_minima = read(
        f"{reactivestate_dataframe.loc[reactivestate_dataframe.smiles == product_smi][path_key].item()}/{minima_filename}",
        ":",
    )

    reactant_minima = [
        at for at in reactant_minima if minima_key in at.info["config_type"] and at.info["intact"]
    ]
    product_minima = [
        at for at in product_minima if minima_key in at.info["config_type"] and at.info["intact"]
    ]

    reactant_minima, _ = check_slab_deformation(
        slab, reactant_minima, threshold=slab_deform_threshold
    )
    product_minima, _ = check_slab_deformation(
        slab, product_minima, threshold=slab_deform_threshold
    )

    if avoid_desorption:
        reactant_minima = [
            at for at in reactant_minima if not is_adsorbate_desorbed(at, slab_indices, mult=mult)
        ]
        product_minima = [
            at for at in product_minima if not is_adsorbate_desorbed(at, slab_indices, mult=mult)
        ]
    if avoid_intercalation:
        reactant_minima = [
            at
            for at in reactant_minima
            if not is_adsorbate_intercalated(at, slab_indices, fix_indices)
        ]
        product_minima = [
            at
            for at in product_minima
            if not is_adsorbate_intercalated(at, slab_indices, fix_indices)
        ]

    for at in reactant_minima:
        del at.constraints
    for at in product_minima:
        del at.constraints

    # Get atom-mapping for the reaction
    mapped_list = is_atom_mapped(rxnsmiles, slab_indices=slab_indices, get_suggestion=True)

    for at in reactant_minima + product_minima:
        at.info["SMILES"] = rxnsmiles
    return reactant_minima, product_minima, mapped_list


def get_cluster_decaf(
    atoms_list,
    slab_indices,
    energy_key="last_op__optimize_energy",
    max_num_groups=5,
    scale_min=0.1,
    scale_max=0.9,
    return_decaf=False,
):
    """
    Get reduced number of minima using clustering with DECAF.

    Parameters
    ----------
    atoms_list : list of ASE atoms
        List of atomic structures to cluster.
    slab_indices : list of int
        Indices of the slab atoms.
    energy_key : str, optional
        Key to access energy information, by default "last_op__optimize_energy"
    max_num_groups : int, optional
        Maximum number of groups to form, by default 5
    scale_min : float, optional
        Minimum scale for bandwidth clustering, by default 0.1
    scale_max : float, optional
        Maximum scale for bandwidth clustering, by default 0.9
    return_decaf : bool, optional
        Return decaf object as well.

    Returns
    -------
    list of ASE atoms
        Reduced list of atomic structures after clustering.
    decaf object (optional)
        Decaf instance if return_decaf is True.
    """
    if len(atoms_list) == 1:
        return atoms_list

    #    rcut = 6
    #    nmax = 9
    #    lmax = 3
    #
    #    # Setting up the SOAP descriptor
    #    soap = SOAP(
    #        species=list(atoms_list[0].symbols.species()),
    #        periodic=True,
    #        r_cut=rcut,
    #        n_max=nmax,
    #        l_max=lmax,
    #        sigma=0.23,
    #        average="off",
    #    )
    #
    #    minima_soap = soap.create(atoms_list)
    minima_soap = build_SOAP_vector(atoms_list, rcut=6, nmax=9, lmax=3, sigma=0.23, average="off")

    adsorbate_indices = [i for i, at in enumerate(atoms_list[0]) if i not in slab_indices]
    minima_soap = np.average(minima_soap[:, adsorbate_indices, :], axis=1)
    # Use DECAF to get clustering

    embed_cluster = decaf.embed_cluster(minima_soap, embed_str="cMDS", cluster_str="MSC")
    embed_cluster.get_embed(dim=0, less_stick_seg=False)
    embed_cluster.get_cluster(
        bandwidth=0,
        bandwidth_estimate="Gaussian",
        label_all="Both",
        classify_mode="TrainingData",
    )

    if max_num_groups is not None:
        initial_bandwidth = embed_cluster.bandwidth
        embed_cluster.get_cluster(
            bandwidth=initial_bandwidth,
            bandwidth_estimate="Gaussian",
            label_all="Both",
            classify_mode="TrainingData",
        )
        if embed_cluster.groupnum > max_num_groups:
            bandwidth_scales = np.linspace(1 + scale_min, 5, 10)
            for i, bandwidth_scale in enumerate(bandwidth_scales):
                embed_cluster.get_cluster(
                    bandwidth=initial_bandwidth * bandwidth_scale,
                    bandwidth_estimate="Gaussian",
                    label_all="Both",
                    classify_mode="TrainingData",
                )
                if embed_cluster.groupnum <= max_num_groups:
                    break
        else:
            bandwidth_scales = np.linspace(scale_max, scale_min, 10)
            for i, bandwidth_scale in enumerate(bandwidth_scales):
                embed_cluster.get_cluster(
                    bandwidth=initial_bandwidth * bandwidth_scale,
                    bandwidth_estimate="Gaussian",
                    label_all="Both",
                    classify_mode="TrainingData",
                )
                #                print(i, f"{embed_cluster.groupnum = }")
                if embed_cluster.groupnum > max_num_groups:
                    if i != 0:
                        i -= 1
                    break

            embed_cluster.get_cluster(
                bandwidth=initial_bandwidth * bandwidth_scales[i],
                bandwidth_estimate="Gaussian",
                label_all="Both",
                classify_mode="TrainingData",
            )

    label_dict = {
        idx: group_id for group_id, str_id in enumerate(embed_cluster.t_gID) for idx in str_id
    }
    labels = [label_dict[idx] for idx in sorted(label_dict.keys())]

    minima_dict = {}
    for i, atoms in enumerate(atoms_list):
        minima_dict[i] = {
            "ase": atoms,
            "energy": atoms.info[energy_key],
            # "distance" : atoms.info["push_pull_distance"],
            "label": labels[i],
        }

    df = pd.DataFrame.from_dict(minima_dict).transpose()
    df["energy"] = df.energy.astype("float")
    representatives = [df.loc[df.label == g].energy.idxmin() for g in np.unique(labels)]

    if return_decaf:
        return [atoms_list[i] for i in representatives], embed_cluster
    else:
        return [atoms_list[i] for i in representatives]


def filter_geometry_pairs(
    interpolations,
    active_bonds,
    transfer_metric_cutoff=9.0,
    distance_cutoff=10,
    max_num_pairs=10,
    max_num_interpolations_per_mapping=5,
    verbose=False,
):
    """
    Filter geometry pairs using reaction metrics. It is only used for transfer reactions.

    Parameters
    ----------
    interpolations : dict
        dictionary with interpolation name as key and NEB interpolations as value
    active_bonds : dict
        dict of bonds broken and formed
    transfer_metric_cutoff : float, optional
        cutoff for sum of donor-transfer-acceptor distances, by default 9.0
    distance_cutoff : int, optional
        cutoff for sum of donor-transfer-acceptor distances, by default 10
    max_num_pairs : int, optional
        maximum number of geometry pairs for dissociation reaction, by default 10.
    max_num_interpolations_per_mapping : int, optional
        maximum number of interpolations per mapping, by default 5.
    verbose : bool, optional
        whether to print verbose output, by default False.

    Returns
    -------
    dict
        Dictionary of initial and final images pairs.
    """
    if len(interpolations) < max_num_interpolations_per_mapping:
        pairs = [[images[0], images[-1]] for images in interpolations.values()]
        return pairs

    if "Break" in active_bonds.keys() and "Form" not in active_bonds.keys():
        # Dissociation reaction
        reaction_type = "dissociation"
    elif "Break" in active_bonds.keys() and "Form" in active_bonds.keys():
        # transfer reaction
        push, transfer, pull = get_push_transfer_pull_indices(active_bonds)
        reaction_type = "transfer"

    if reaction_type == "transfer":
        if verbose:
            print(f"Start first filtering. number of geometry pairs : {len(interpolations)}")
        df = sort_interpolations(
            interpolations,
            active_bonds,
            print_metric=False,
            write_metric=False,
            normalize=True,
        )
        df = df.loc[df.avg_dist < transfer_metric_cutoff]

        if len(df) == 0:
            return interpolations

        filtered_interpolations = {
            idx: interpolations[idx] for idx in df.iloc[:max_num_pairs].index
        }
        if verbose:
            print(f"Final number of geometry pairs : {len(filtered_interpolations)}")

    else:
        if verbose:
            print(f"Start first filtering. number of geometry pairs : {len(interpolations)}")
        df = sort_interpolations(
            interpolations, active_bonds, print_metric=False, write_metric=False
        )
        filtered_interpolations = {
            idx: interpolations[idx] for idx in df.iloc[:max_num_pairs].index
        }
        if verbose:
            print(f"Final number of geometry pairs : {len(filtered_interpolations)}")

    return filtered_interpolations


# def compare_images_end_points(images1, images2):
#    """
#    To filter out duplicated interpolation, this function compares endpoints of two images.
#    It is assumed that interpolated images are identical if end points are the same.
#    This will give False even if with the same atomic geometry if atom index are different.
#    If geometry and atom index are both identical, this will return True.
#    """
#    initial1, final1 = images1[0], images1[-1]
#    initial2, final2 = images2[0], images2[-1]
#
#    initial_identity = np.all(
#        [np.all(np.isclose(at1.position, at2.position)) for at1, at2 in zip(initial1, initial2)]
#    )
#    final_identity = np.all(
#        [np.all(np.isclose(at1.position, at2.position)) for at1, at2 in zip(final1, final2)]
#    )
#
#    return np.all([initial_identity, final_identity])


# def sample_structures(
#    workdir, calculaotr_tuple, prev_training, outfilename, neb_sample=500
# ):
#    assert np.all(["desc" in at.info.keys() for at in prev_training]), (
#        "previous training set doesn't have MACE descriptor"
#    )
#
#    todft = []
#    workdir = Path(workdir)
#    # workdir = Path("/home/hjung/raven/2_BASF/iter_2") #/0_isolated_adsorbates"
#
#    category = "0_isolated_adsorbates"
#    for mol in sorted(next(os.walk(workdir / category))[1]):
#        traj = read(workdir / f"{category}/{mol}/minhop.xyz", ":")
#        mdtraj = [at for at in traj if at.info["config_type"] == "minhop_traj"]
#
#        minima = read(workdir / f"{category}/{mol}/reac_constraint_free_opt.xyz", ":")
#        minima = [at for at in minima if at.info["intact"]]
#
#        global_minimum_index = np.argmin(
#            [at.info["last_op__optimize_energy"] for at in minima]
#        )
#        global_minimum = minima.pop(global_minimum_index)
#
#        global_minimum.info["config_type"] = "global_min"
#        todft.append(global_minimum)
#
#        todft += random.sample(minima, 2)
#        todft += random.sample(mdtraj, 2)
#
#    category = "1_two_adsorbates"
#    for mol in sorted(next(os.walk(workdir / category))[1]):
#        # print(mol)
#        traj = read(workdir / f"{category}/{mol}/minhop.xyz", ":")
#        mdtraj = [at for at in traj if at.info["config_type"] == "minhop_traj"]
#
#        minima = read(workdir / f"{category}/{mol}/reac_constraint_free_opt.xyz", ":")
#        minima = [at for at in minima if at.info["intact"]]
#
#        global_minimum_index = np.argmin(
#            [at.info["last_op__optimize_energy"] for at in minima]
#        )
#        global_minimum = minima.pop(global_minimum_index)
#
#        global_minimum.info["config_type"] = "global_min"
#        todft.append(global_minimum)
#
#        todft += random.sample(minima, 2)
#        todft += random.sample(mdtraj, 2)
#
#    neb_traj = []
#    transition_states = []
#    category = "2_NEB"
#    for rxn in sorted(next(os.walk(workdir / category))[1]):
#        print(rxn, end=" ")
#        for subdir in sorted(next(os.walk(workdir / category / rxn))[1]):
#            if subdir.startswith("a") or subdir.startswith("b"):
#                continue
#            else:
#                if Path(
#                    workdir / category / rxn / subdir / "NEB_climb_refine.xyz"
#                ).is_file():
#                    images = read(
#                        workdir / category / rxn / subdir / "NEB_climb_refine.xyz", ":"
#                    )
#                elif Path(
#                    workdir / category / rxn / subdir / "NEB_climb.xyz"
#                ).is_file():
#                    images = read(
#                        workdir / category / rxn / subdir / "NEB_climb.xyz", ":"
#                    )
#                else:
#                    print(rxn, subdir, "problematic")
#
#                TS_index = np.argmax([at.info["last_op__neb_energy"] for at in images])
#                if TS_index != 0 and TS_index != len(images) - 1:
#                    # transition_states.pop(images[TS_index])
#                    transition_states.append(images.pop(TS_index))
#                else:
#                    print("TS is the same as either reactant or product")
#
#            neb_traj += images
#
#    todft += transition_states
#
#    # Calculate MACE descriptor for NEB trajectory
#    neb_traj = desc_calc(
#        ConfigSet(neb_traj),
#        OutputSpec(),
#        calculaotr_tuple,
#        "desc",
#        force=True,
#        autopara_info=AutoparaInfo(num_python_subprocesses=1),
#    )
#    neb_traj = neb_traj.items
#
#    # Calculate MACE descriptor for minima hopping + Transition states
#    todft = desc_calc(
#        ConfigSet(todft),
#        OutputSpec(),
#        calculaotr_tuple,
#        "desc",
#        force=True,
#        autopara_info=AutoparaInfo(num_python_subprocesses=1),
#    )
#    todft = todft.items
#
#    in_config = ConfigSet(neb_traj)
#    prev_descs = [at.info.get("desc") for at in prev_training + todft]
#    fps = greedy_fps_conf_global(
#        in_config,
#        OutputSpec(),
#        neb_sample - len(transition_states),
#        at_descs_info_key="desc",
#        verbose=True,
#        prev_selected_descs=prev_descs,
#    )
#
#    write(workdir / outfilename, todft + fps.items)


def get_push_transfer_pull_indices(active_bonds):
    """
    Get push, transfer, and pull indices from active bonds.

    Parameters
    ----------
    active_bonds : dict
        Dictionary of active bonds with keys "Form" and "Break".

    Returns
    -------
    tuple
        Push, transfer, and pull indices.
    """
    active_indices = np.unique([val for values in active_bonds.values() for val in values])
    for i in active_indices:
        if i in active_bonds["Form"] and i in active_bonds["Break"]:
            transfer = i
            continue
        if i in active_bonds["Break"]:
            push = i
            continue
        if i in active_bonds["Form"]:
            pull = i
            continue

    return push, transfer, pull


def sort_interpolations(
    interpolations,
    active_bonds,
    workdir="",
    print_metric=True,
    write_metric=True,
    normalize=False,
):
    """
    Sort interpolations based on two reaction metrics.

    Used reaction distance metrics:
    (1) mu: idpp area under the curve
    (2) tau : sum of donor-transfer-acceptor distances (used in case of transfer reaction)

    Parameters
    ----------
    interpolations : dict
        dictionary with interpolation name as key and NEB interpolations as value
    active_bonds : dict
        dict of bonds broken and formed
    workdir : str, optional
        directory where interpolations will be saved, by default ""
    print_metric : bool, optional
        print reaction metrics dataframe, by default True
    write_metric : bool, optional
        write reaction metrics dataframe, by default True
    normalize : bool, optional
        Normalize and sum idpp_auc and avg_distances, by default False

    Returns
    -------
    pandas dataframe
        Dataframe with keys of interpolation and sorted by the metrics.
    """

    if "Break" in active_bonds.keys() and "Form" not in active_bonds.keys():
        # Dissociation reaction
        reaction_type = "dissociation"
    elif "Break" in active_bonds.keys() and "Form" in active_bonds.keys():
        # transfer reaction
        push, transfer, pull = get_push_transfer_pull_indices(active_bonds)
        reaction_type = "transfer"

    avg_pull_push_dist = {}
    idpp_auc_metrics = {}
    AB_dict = {}
    for key, images in interpolations.items():
        if reaction_type == "transfer":
            pull_push_dist = []
            AB = []
            for at in images:
                v0, l0 = find_mic(
                    at[push].position - at[transfer].position, at.cell, at.pbc
                )  # push-transfer
                v1, l1 = find_mic(
                    at[transfer].position - at[pull].position, at.cell, at.pbc
                )  # transfer-pull
                v2, l2 = find_mic(
                    at[push].position - at[pull].position, at.cell, at.pbc
                )  # push-pull
                pull_push_dist.append(np.sum([l0, l1, l2]))
                AB.append(np.abs(l0 - l1))
            avg_pull_push_dist[key] = np.average(pull_push_dist)
            AB_dict[key] = np.average(AB)

        if "idpp_auc" in images[0].info.keys():
            idpp_auc_metrics[key] = images[0].info["idpp_auc"]
        else:
            idpp_auc_metrics[key] = get_idpp_surface_area(images)

    if reaction_type == "transfer":
        df = pd.DataFrame.from_dict([avg_pull_push_dist, idpp_auc_metrics, AB_dict]).T
        df.rename(columns={0: "avg_dist", 1: "idpp_auc", 2: "AB"}, inplace=True)
        if normalize:
            df["norm_avg_dist"] = (df["avg_dist"] - np.min(df["avg_dist"].values)) / (
                np.max(df["avg_dist"].values) - np.min(df["avg_dist"].values)
            )
            df["norm_idpp_auc"] = (df["idpp_auc"] - np.min(df["idpp_auc"].values)) / (
                np.max(df["idpp_auc"].values) - np.min(df["idpp_auc"].values)
            )
            df["sum_norm"] = df["norm_avg_dist"] + df["norm_idpp_auc"]
            df.sort_values("sum_norm", inplace=True)
        else:
            df.sort_values("avg_dist", inplace=True)
    else:
        df = pd.DataFrame.from_dict([idpp_auc_metrics]).T
        df.rename(columns={0: "idpp_auc"}, inplace=True)
        df.sort_values("idpp_auc", inplace=True)

    if print_metric:
        print(df.to_string(), flush=True)

    if write_metric:
        with open(f"{workdir}/sorted_interpolations.txt", "a+") as f:
            print(df.to_string(), file=f)

    return df


def pareto_front(points):
    """
    Compute strict Pareto front (minimization).

    Parameters
    ----------
    points : np.ndarray
        Array of shape (n_points, n_objectives) containing the points to evaluate.

    Returns
    -------
    np.ndarray
        Boolean array indicating which points are on the Pareto front.
    """
    is_efficient = np.ones(points.shape[0], dtype=bool)

    for i, c in enumerate(points):
        if is_efficient[i]:
            is_efficient[is_efficient] = np.any(points[is_efficient] < c, axis=1) | np.all(
                points[is_efficient] == c, axis=1
            )
            is_efficient[i] = True
    return is_efficient


def pareto_with_range(points, eps=0.1, return_indices=False):
    """
    Compute Pareto front with epsilon range (minimization).

    Parameters
    ----------
    points : np.ndarray
        Array of shape (n_points, n_objectives) containing the points to evaluate.
    eps : float
        Epsilon value for determining the range.
    return_indices : bool
        Whether to return the indices of the points in the Pareto front.

    Returns
    -------
    np.ndarray
        Boolean array indicating which points are in the Pareto front.
    """
    pareto = pareto_front(points)
    front_points = points[pareto]
    in_range = np.zeros(points.shape[0], dtype=bool)

    for p in front_points:
        # Mark all points within eps in both objectives as in-range
        mask = np.all(points <= p + eps, axis=1)
        in_range |= mask

    if return_indices:
        indices = [i for i, mask in enumerate(in_range) if mask]
        return indices
    else:
        return in_range


def get_pareto_front_layers(points, num_layers=2, eps=0.1, energy_cutoff=1.2, distance_cutoff=4.5):
    """
    Compute Pareto front with threshold layer of 0.1 Angstrom and 0.1 eV (eps).

    Parameters
    ----------
    points : np.ndarray
        Array of shape (n_points, n_objectives) containing the points to evaluate.
    num_layers : int, optional
        Number of layers to compute, by default 2
    eps : float, optional
        Epsilon value for determining the range, by default 0.1
    energy_cutoff : float, optional
        Energy cutoff value, by default 1.2
    distance_cutoff : int, optional
        Distance cutoff value, by default 4.5

    Returns
    -------
    list
        List of Pareto front layers with indices of minima.
    """
    # selected = []
    pareto_layers = []
    current_indices = np.arange(len(points))
    original_points = points.copy()

    # get energy cutoff: global min + energy_cutoff
    energy_cutoff = np.min(points[:, 1]) + energy_cutoff

    for _ in range(num_layers):
        # pareto = pareto_front(points)
        pareto = pareto_with_range(
            points, eps=eps, return_indices=False
        )  # distance_eps=0.1, energy_eps=0.1,
        front_indices = [
            i
            for i, mask, point in zip(current_indices, pareto, points)
            if mask and point[0] < distance_cutoff and point[1] < energy_cutoff
        ]
        pareto_layers.append(front_indices)
        current_indices = [i for i, point in zip(current_indices, points) if i not in front_indices]
        # print(f"{current_indices = }")
        points = np.array(
            [point for i, point in enumerate(original_points) if i in current_indices]
        )

    return pareto_layers


def get_distance_energy_info(
    IS, FS, slab_indices, mapping_dict, energy_key="last_op__optimize_energy", mult=0.8
):
    """
    Measure distance between adsorbates and energy for IS and FS.

    Parameters
    ----------
    IS : list
        list of initial states
    FS : list
        list of final states
    slab_indices : list
        list of slab atom indices
    mapping_dict : dict
        mapping info dict
    energy_key : str
        energy_key for atoms.info dict
    mult : float, optional
        mult for neighborlist, by default 0.8

    Returns
    -------
    dict
        Dictionary that contains minima information as following.
        info_dict = {
        "IS" : {"atoms" : mapped_IS, "energy" : np.array(energy1), "distance" : np.array(IS_distances)},
        "FS" : {"atoms" : mapped_FS, "energy" : np.array(energy2), "distance" : np.array(FS_distances)}
        }.
    """

    mapped_IS, mapped_FS = get_atom_mapped_configs_list(
        mapping_dict["mapped_rxnsmiles"], IS, FS, slab_indices, mult=mult
    )

    # Transfer
    if (
        "Break" in mapping_dict["active_bonds"].keys()
        and "Form" in mapping_dict["active_bonds"].keys()
    ):
        push, transfer, pull = get_push_transfer_pull_indices(mapping_dict["active_bonds"])
        IS_distances = [
            find_mic(at.positions[push] - at.positions[pull], at.cell, at.pbc)[1]
            for at in mapped_IS
        ]
        FS_distances = [
            find_mic(at.positions[push] - at.positions[pull], at.cell, at.pbc)[1]
            for at in mapped_FS
        ]
    # Dissociation
    elif (
        "Break" in mapping_dict["active_bonds"].keys()
        and "Form" not in mapping_dict["active_bonds"].keys()
    ):
        a, b = mapping_dict["active_bonds"]["Break"]
        IS_distances = [
            find_mic(at.positions[a] - at.positions[b], at.cell, at.pbc)[1] for at in mapped_IS
        ]
        FS_distances = [
            find_mic(at.positions[a] - at.positions[b], at.cell, at.pbc)[1] for at in mapped_FS
        ]
    # Isomerization ??

    energy1 = np.array([at.info[energy_key] for at in mapped_IS])
    energy2 = np.array([at.info[energy_key] for at in mapped_FS])

    info_dict = {
        "IS": {
            "atoms": mapped_IS,
            "energy": np.array(energy1),
            "distance": np.array(IS_distances),
        },
        "FS": {
            "atoms": mapped_FS,
            "energy": np.array(energy2),
            "distance": np.array(FS_distances),
        },
    }

    return info_dict


def select_minima_ranged_pareto_front(
    IS,
    FS,
    slab,
    fix_indices,
    mapping_dict,
    energy_cutoff=1.2,
    distance_cutoff=4.5,
    increase_factor=1.3,
    reduce_method="decaf",
    num_min_selection=5,
    num_layers=1,
    max_num_groups=5,
    num_kmeans=15,
    reduce_number=True,
    diversify=True,
    eps=0.1,
    mult=0.8,
):
    """
    Select minima from the ranged Pareto front.

    Parameters
    ----------
    IS : list
        List of initial structures.
    FS : list
        List of final structures.
    slab : list
        List of slab structures.
    fix_indices : list
        List of fixed indices.
    mapping_dict : dict
        Mapping dictionary.
    energy_cutoff : float, optional
        Energy cutoff value, by default 1.5
    distance_cutoff : float, optional
        Distance cutoff value, by default 5.0
    increase_factor : float, optional
        Factor by which to increase the cutoff values in case no minima were found within energy and distance cutoffs, by default 1.3
    reduce_method : str, optional
        Methods to reduce number of minima. With kmeans fixed number will be returned but decaf doesn't need specification.
    num_min_selection : int, optional
        Number of minimum minima to be selected, by default 5
    num_layers : int, optional
        Number of Pareto front layers to consider, by default 1
    max_num_groups : int, optional
        Maximum number of groups, by default 5
    num_kmeans : int, optional
        Number of samples to get from kmeans clustering, by default 15
    reduce_number : bool, optional
        Whether to reduce the number of selected minima, by default True
    diversify : bool, optional
        Whether to diversify the selected minima, by default True
    eps : float, optional
        Epsilon value for determining the range, by default 0.25
    mult : float, optional
        multiplier for chemical bond, by default 0.8

    Returns
    -------
    IS : list
        List of selected minima from initial state.
    FS : list
        List of selected minima from final state.
    """
    slab_indices = np.arange(len(slab))
    info_dict = get_distance_energy_info(IS, FS, slab_indices, mapping_dict, mult=mult)

    # distance_cutoff
    points1 = np.vstack([info_dict["IS"]["distance"], info_dict["IS"]["energy"]]).T
    points2 = np.vstack([info_dict["FS"]["distance"], info_dict["FS"]["energy"]]).T

    ## IS
    pareto_frontiers1 = get_pareto_front_layers(
        points1,
        num_layers=num_layers,
        energy_cutoff=energy_cutoff,
        distance_cutoff=distance_cutoff,
    )
    if num_layers == 1 and len(pareto_frontiers1[0]) < num_min_selection:
        pareto_frontiers1 = get_pareto_front_layers(
            points1,
            num_layers=2,
            energy_cutoff=energy_cutoff,
            distance_cutoff=distance_cutoff,
        )
    elif len(pareto_frontiers1[0]) == 0:
        print(f"IS : None of points are in cutoff. cutoff is increased by {increase_factor}")
        pareto_frontiers1 = get_pareto_front_layers(
            points1,
            num_layers=num_layers,
            energy_cutoff=energy_cutoff * increase_factor,
            distance_cutoff=distance_cutoff * increase_factor,
        )
    pareto_indices1 = [index for indices in pareto_frontiers1 for index in indices]

    ## FS
    pareto_frontiers2 = get_pareto_front_layers(
        points2,
        num_layers=num_layers,
        energy_cutoff=energy_cutoff,
        distance_cutoff=distance_cutoff,
    )
    if num_layers == 1 and len(pareto_frontiers2[0]) < num_min_selection:
        pareto_frontiers2 = get_pareto_front_layers(
            points2,
            num_layers=2,
            energy_cutoff=energy_cutoff,
            distance_cutoff=distance_cutoff,
        )
    elif len(pareto_frontiers2[0]) == 0:
        print(f"FS : None of points are in cutoff. cutoff is increased by {increase_factor}")
        pareto_frontiers2 = get_pareto_front_layers(
            points2,
            num_layers=num_layers,
            energy_cutoff=energy_cutoff * increase_factor,
            distance_cutoff=distance_cutoff * increase_factor,
        )

    pareto_indices2 = [index for indices in pareto_frontiers2 for index in indices]

    IS_ensemble = [at for i, at in enumerate(info_dict["IS"]["atoms"]) if i in pareto_indices1]
    FS_ensemble = [at for i, at in enumerate(info_dict["FS"]["atoms"]) if i in pareto_indices2]

    if reduce_number and reduce_method == "decaf":
        IS = get_cluster_decaf(IS_ensemble, slab_indices, max_num_groups=max_num_groups)
        if len(IS) == 1 and diversify:
            print("Got only one for IS, trying again.")
            IS = get_cluster_decaf(IS_ensemble, slab_indices, max_num_groups=5)

        FS = get_cluster_decaf(FS_ensemble, slab_indices, max_num_groups=max_num_groups)
        if len(FS) == 1 and diversify:
            print("Got only one for FS, trying again.")
            FS = get_cluster_decaf(FS_ensemble, slab_indices, max_num_groups=5)

        print(f"Number of IS reduced from {len(IS_ensemble)} to {len(IS)}", flush=True)
        print(f"Number of FS reduced from {len(FS_ensemble)} to {len(FS)}", flush=True)
        return IS, FS
    elif reduce_number and reduce_method == "kmeans":
        IS = sample_kmeans(
            IS_ensemble,
            slab_indices,
            n_samples=num_kmeans,
            distance_cutoff=distance_cutoff,
            energy_cutoff=energy_cutoff,
        )
        FS = sample_kmeans(
            FS_ensemble,
            slab_indices,
            n_samples=num_kmeans,
            distance_cutoff=distance_cutoff,
            energy_cutoff=energy_cutoff,
        )
        print(f"Number of IS reduced from {len(IS_ensemble)} to {len(IS)}", flush=True)
        print(f"Number of FS reduced from {len(FS_ensemble)} to {len(FS)}", flush=True)

        return IS, FS
    else:
        print(f"Number of IS : {len(IS_ensemble)}")
        print(f"Number of FS : {len(FS_ensemble)}")
        return IS_ensemble, FS_ensemble


def get_geometry_pairs(
    rxnsmiles_dict,
    workdir,
    dataframe,
    slab,
    fix_indices,
    slab_deform_threshold=1.2,
    max_num_groups=10,
    energy_cutoff=1.2,
    distance_cutoff=4.5,
    reduce_number=True,
    reduce_method="decaf",
    num_kmeans=10,
    minima_filename="minhop.xyz",
    minima_key="optimize_last_converged",
    mult=1.8,
):
    """
    Get geometry pairs for each reaction.

    Parameters
    ----------
    rxnsmiles_dict : dict
        Dictionary of reaction index as key and reaction SMILES strings as value.
    workdir : Path
        Working directory for output files.
    dataframe : pd.DataFrame
        DataFrame containing the reactive state information.
    slab : Atoms
        Slab atoms representing the surface.
    fix_indices : list
        List of indices to fix during optimization.
    slab_deform_threshold : float, optional
        How much slab deformation will be considered as intact surface (default 1.2 Angs).
    max_num_groups : int, optional
        Maximum number of groups for clustering (default is 10).
    energy_cutoff : float, optional
        Energy cutoff from global minimum for Pareto optimization.
    distance_cutoff : float, optional
        Distance cutoff from the shortest donor-acceptor distance for Pareto optimization.
    reduce_number : bool
        Whether the number of minima should be reduced using decaf (default is True).
    reduce_method : str
        Methods to reduce geometry decaf or kmeans. For kmeans "num_kmenas" should be provided.
    num_kmeans : int
        Number of minima to select using k-means clustering.
    minima_filename : str, optional
        Name of file containing minima geometry.
    minima_key : str, optional
        Key name for minima configureation in `minima_filename`.
    mult : float, optional
        Multiplicative factor for slab deformation (default is 1.8).

    Returns
    -------
    list of lists
        List of geometry pairs for each reaction.
    """
    pairs = []
    print(f"Total {len(rxnsmiles_dict)} reactions.")
    print(f"Using {reduce_method} to reduce geometries.")
    print("Follwing cutoffs are used for Pareto front optimization.")
    print(f"Energy cutoff : {energy_cutoff} eV")
    print(f"Distance cutoff : {distance_cutoff} Angs.")

    if reduce_method == "kmeans":
        print(f"{num_kmeans = }")
    else:
        print(f"{max_num_groups = }")

    for count, (rxni, rxnsmi) in enumerate(rxnsmiles_dict.items()):
        #        print("\n" + "=" * 50)
        print(f"\nReaction #{rxni} : {rxnsmi}  ({count + 1}/{len(rxnsmiles_dict)})")
        Path(workdir / str(rxni).zfill(2)).mkdir(exist_ok=True, parents=True)

        IS_list, FS_list, mapped_list = get_low_minima(
            rxnsmi,
            reactivestate_dataframe=dataframe,
            path_key="path",
            slab=slab,
            fix_indices=fix_indices,
            num_select=None,
            slab_deform_threshold=slab_deform_threshold,
            avoid_intercalation=False,
            minima_filename=minima_filename,
            minima_key=minima_key,
            mult=mult,
        )
        if len(mapped_list) > 1:
            print(f"{len(mapped_list)} distinct atom mappings found.")
            print("Geometry selection is done for each atom mapping.")

        for map_idx, mapping_dict in enumerate(mapped_list):
            IS, FS = select_minima_ranged_pareto_front(
                IS_list,
                FS_list,
                slab,
                fix_indices,
                mapping_dict,
                energy_cutoff=energy_cutoff,
                distance_cutoff=distance_cutoff,
                max_num_groups=max_num_groups,
                reduce_number=reduce_number,
                reduce_method=reduce_method,
                num_kmeans=num_kmeans,
            )
            pairidx = 0
            for i, initial in enumerate(IS):
                for j, final in enumerate(FS):
                    #                    initial.info["identifier"] = f" {rxni} / {map_idx} / {i} / {j}"
                    initial.info["identifier"] = json.dumps(
                        {"rxn": rxni, "map": map_idx, "IS": i, "FS": j}
                    )
                    final.info["identifier"] = json.dumps(
                        {"rxn": rxni, "map": map_idx, "IS": i, "FS": j}
                    )
                    final.info["mapped_rxnsmiles"] = mapping_dict["mapped_rxnsmiles"]
                    final.info["active_bonds"] = json.dumps(
                        {
                            key: tuple(map(int, indices))
                            for key, indices in mapping_dict["active_bonds"].items()
                        }
                    )
                    final.info["corrected"] = False
                    pairidx += 1
                    pairs.append([initial.copy(), final.copy()])
    return pairs


# def atoms_list2dictionary(
#    initial_list,
#    finals_list,
#    slab_indices,
#    energy_key="last_op__optimize_energy",
#    energy_threshold=0.1,
# ):
#    geometry_pair_dict = {}
#    pair_dict = {}
#    for at in finals_list:
#        if at.info["identifier"] not in pair_dict.keys():
#            pair_dict[at.info["identifier"]] = [at]
#        else:
#            pair_dict[at.info["identifier"]].append(at)
#
#    for initial in initial_list:
#        pair_dict[initial.info["identifier"]] = [initial] + pair_dict[initial.info["identifier"]]
#
#    # Make dictionary template to be filled in
#    for identifier, (initial, final, new_final) in pair_dict.items():
#        rxni, map_idx, pairidx = tuple(map(int, identifier.strip().split("/")))
#        if rxni not in geometry_pair_dict.keys():
#            geometry_pair_dict[rxni] = {}
#        if map_idx not in geometry_pair_dict[rxni].keys():
#            geometry_pair_dict[rxni][map_idx] = {}
#        if pairidx not in geometry_pair_dict[rxni][map_idx].keys():
#            geometry_pair_dict[rxni][map_idx][pairidx] = None
#
#    for identifier, (initial, final, new_final) in pair_dict.items():
#        active_bonds = json.loads(final.info["active_bonds"])
#        rxni, map_idx, pairidx = tuple(map(int, identifier.strip().split("/")))
#        energy_diff = np.abs(final.info[energy_key] - new_final.info[energy_key])
#        if energy_diff < energy_threshold:
#            images, _ = get_optimal_linear_interpolation_pbc(
#                initial, new_final, slab_indices, active_bonds, numimages=4
#            )
#        else:
#            print(
#                f"Energy difference is larger than threshold value : {energy_diff:0.2f} > {energy_threshold}!"
#            )
#            images, _ = get_optimal_linear_interpolation_pbc(
#                initial, final, slab_indices, active_bonds, numimages=4
#            )
#
#        geometry_pair_dict[rxni][map_idx][pairidx] = images
#        geometry_pair_dict[rxni][map_idx]["active_bonds"] = active_bonds
#
#    return geometry_pair_dict


def apply_permutation_interpolate(
    geometry_pairs,
    slab_indices,
    slab_constraints,
    numimages=18,
    max_num_permutation=2,
    idpp=True,
    autopara_info=None,
):
    """
    For given list of geometry pairs, (which are IS and aligned FS), apply index permutation and make interpolation with numimages and IDPP relaxation.

    Parameters
    ----------
    geometry_pairs : list of tuples
        List of geometry pairs (IS, FS) to be processed.
    slab_indices : list of int
        List of slab indices for each geometry pair.
    slab_constraints : list of dict
        List of slab constraints for each geometry pair.
    numimages : int, optional
        Number of images to generate for interpolation (default is 18).
    max_num_permutation : int, optional
        Maximum number of index permutations to apply (default is 2).
    idpp : bool, optional
        Whether to apply IDPP relaxation (default is True).
    autopara_info : dict, optional
        Additional information for autoparallelization (default is None).

    Returns
    -------
    dict
        Nested dictionary of interpolations (e.g. {rxni: {map_idx: {key: list[Atoms]}}} ).
    """
    ## Apply index permutation and generate IDPP interpolations.
    in_config = ConfigSet(geometry_pairs)
    index_permuted_image_list = apply_permutation_parallel(
        in_config.groups(),
        OutputSpec(),
        slab_indices,
        slab_constraints,
        numimages=numimages,
        max_num_permutation=max_num_permutation,
        idpp=idpp,
        autopara_info=autopara_info,
    )
    # index_permuted_image_list = [
    #     images for images in index_permuted_image_list.items if len(images) != 0
    # ]
    index_permuted_image_list = [
        images for permuted_list in index_permuted_image_list.items for images in permuted_list
    ]

    # Make empty nested dictionaries to accomodate images in hierarchial format
    interpolations_dict = {}
    geometry_keys_dict = {}
    for images in index_permuted_image_list:
        identifier = json.loads(images[0].info["identifier"])
        rxni, map_idx = itemgetter("rxn", "map")(identifier)
        #        geometry_keys = itemgetter("IS", "FS")(identifier)

        if rxni not in interpolations_dict.keys():
            interpolations_dict[rxni] = {}
            geometry_keys_dict[rxni] = {}
        if map_idx not in interpolations_dict[rxni].keys():
            interpolations_dict[rxni][map_idx] = {}
            geometry_keys_dict[rxni][map_idx] = []

    # IS_i, FS_i, symop_i Geometry pair indices are combined to one geometry index
    # {(1, 3, 4): 0,  (IS_i, FS_i, symop_i): New_combined_index
    # (1, 3, 5): 1,
    # (2, 3, 1): 2,
    # (2, 3, 4): 3,
    # (2, 3, 5): 4}
    for images in index_permuted_image_list:
        identifier = json.loads(images[0].info["identifier"])
        rxni, map_idx = itemgetter("rxn", "map")(identifier)
        geometry_keys_dict[rxni][map_idx].append((itemgetter("IS", "FS", "symop")(identifier)))
    for rxni, map_dict in geometry_keys_dict.items():
        for map_i, geom_keys in map_dict.items():
            geometry_keys_dict[rxni][map_i] = {
                geom_indices: geom_i
                for geom_i, geom_indices in enumerate(sorted(set(list(geom_keys))))
            }

    # Now fill `interpolations_dict` with interpolations
    for images in index_permuted_image_list:
        identifier = json.loads(images[0].info["identifier"])
        rxni, map_idx, IS_i, FS_i, symop_i, permut_key = itemgetter(
            "rxn", "map", "IS", "FS", "symop", "permute"
        )(identifier)
        geom_key = geometry_keys_dict[rxni][map_idx][(IS_i, FS_i, symop_i)]
        interpolations_dict[rxni][map_idx][f"{map_idx}_{geom_key}_{permut_key}"] = images

    return interpolations_dict


def sort_and_write_interpolations(
    interpolations_dict, workdir, max_num_interpolations_per_mapping=5
):
    """
    Sort and write interpolations to workdir.

    Parameters
    ----------
    interpolations_dict : dict
        Dictionary containing interpolations for each reaction and mapping.
    workdir : Path
        Directory to write the sorted interpolations.
    max_num_interpolations_per_mapping : int
        Maximum number of interpolations to keep per mapping.

    Returns
    -------
    None
        Nothing is returned.
    """
    # For each reaction (rxni), sort interpolations and classify them into good & bad interpolations
    # And writhe them respectively into different directories.
    for rxni, map_dict in interpolations_dict.items():
        good_interpolations = []
        bad_interpolations = []
        dataframes = []
        Path(workdir / str(rxni).zfill(2)).mkdir(exist_ok=True, parents=True)
        for map_i, interp_dict in map_dict.items():
            active_bonds = interp_dict[list(interp_dict.keys())[0]][0].info["active_bonds"]

            df = sort_interpolations(
                interp_dict,
                active_bonds,
                workdir=workdir / f"{str(rxni).zfill(2)}",
                normalize=True,
                print_metric=False,
                write_metric=True,
            )
            dataframes.append(df)

            # Split cases with good and bad interpolations based on sorting.
            good_interpolations.append(
                {
                    key: interp_dict[key]
                    for key in df.iloc[:max_num_interpolations_per_mapping].index
                }
            )
            bad_interpolations.append(
                {
                    key: interp_dict[key]
                    for key in df.iloc[max_num_interpolations_per_mapping:].index
                }
            )

            if len(dataframes) > 1:
                df = pd.concat(dataframes)

            # Get interpolations
            for images_dict in good_interpolations:
                for key, images in images_dict.items():
                    Path(workdir / str(rxni).zfill(2) / f"{key}").mkdir(exist_ok=True, parents=True)
                    write(
                        workdir / str(rxni).zfill(2) / f"{key}" / "idpp_interpolated.xyz",
                        images,
                    )

            Path(workdir / str(rxni).zfill(2) / "backup_candidates").mkdir(
                exist_ok=True, parents=True
            )
            for images_dict in bad_interpolations:
                for key, images in images_dict.items():
                    Path(workdir / str(rxni).zfill(2) / "backup_candidates" / f"{key}").mkdir(
                        exist_ok=True, parents=True
                    )
                    write(
                        workdir
                        / str(rxni).zfill(2)
                        / "backup_candidates"
                        / f"{key}"
                        / "idpp_interpolated.xyz",
                        images,
                    )
