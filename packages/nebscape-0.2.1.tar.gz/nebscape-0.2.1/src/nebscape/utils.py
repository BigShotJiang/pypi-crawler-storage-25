"""
Various helper functions for neighbor analysis, reaction distance metrics.
"""

from ase import neighborlist
import igraph as ig
import numpy as np
from sklearn.metrics import auc
from ase.geometry import find_mic
from ase.mep.neb import IDPP
from ase import Atom
from rdkit import Chem
from rdkit.Chem import rdmolops


def get_adjacency_matrix(atoms, adsorbates_only=True, slab_indices=None, mult=1):
    """
    If there are hydrogen bond, it could be detected as one covalent bond with mult = 1, but empirically found that mult = 0.8 reliably discern hydrogen bond as not convalent bond.

    Parameters
    ----------
    atoms : ase.Atoms
        Atoms object to consider for adjacency matrix
    adsorbates_only : bool, optional
        If True, only consider adsorbate atoms (default is True)
    slab_indices : list, optional
        Indices of slab atoms (default is None)
    mult : float, optional
        Multiplicative factor for bond length cutoff (default is 1)

    Returns
    -------
    np.ndarray
        Adjacency matrix representing the connectivity of the atoms.
    """
    cutOff = neighborlist.natural_cutoffs(atoms, mult=mult)
    neighbor = neighborlist.NeighborList(cutOff, self_interaction=False, bothways=True)
    neighbor.update(atoms)
    adjacency = neighbor.get_connectivity_matrix(sparse=False)

    if adsorbates_only:
        assert slab_indices is not None
        adsidx = [at.index for at in atoms if at.index not in slab_indices]

        return adjacency[np.ix_(adsidx, adsidx)]
    else:
        return adjacency


def graphfromsmiles(mol, networkx=False):
    """
    Generate igraph object from smiles.

    Convert 2D smiles into 3D geometry using embedding and subsequently optimize with MMFF
    From MMFF optimized geometry, bondlengths, etc are saved as graph edge attributes.
    This will be used for graph matching from ASE read adsorbate's molecular graph.

    Parameters
    ----------
    mol : str or RDkit Mol
        SMILES string for adsorbate or RDkit mol object
    networkx : bool, optional
        If True, return a NetworkX graph instead of an igraph object (default is False)

    Returns
    -------
    ig.Graph or nx.Graph
        Graph of molecule with bondtype, bondlengths, etc, are encoded as edge attributes.
    """
    if isinstance(mol, str):
        #        mol = Chem.AddHs(Chem.MolFromSmiles(mol))
        mol = Chem.MolFromSmarts(mol)

    else:
        Chem.SanitizeMol(mol)

    AtomMapNum = [atom.GetAtomMapNum() for atom in mol.GetAtoms()]
    #### Following is added because AtomIdx and AtomMapNum in RDkit mol is different.
    #### This renumbers Atom index according to AtomMapNum
    AtomIdx = [atom.GetIdx() for atom in mol.GetAtoms()]
    new_order = list(dict(sorted(dict(zip(AtomMapNum, AtomIdx)).items())).values())

    mol_reordered = Chem.RenumberAtoms(mol, newOrder=new_order)
    m = mol_reordered
    ############

    # initiate molecular graph
    molgraph = ig.Graph.Adjacency(rdmolops.GetAdjacencyMatrix(m), mode="undirected")
    molgraph.vs["Symbols"] = [m.GetAtomWithIdx(i).GetSymbol() for i in range(m.GetNumAtoms())]
    molgraph.vs["AtomicNums"] = [m.GetAtomWithIdx(i).GetAtomicNum() for i in range(m.GetNumAtoms())]
    molgraph.vs["AtomIndex"] = [atom.GetAtomMapNum() for atom in m.GetAtoms()]

    for bond in m.GetBonds():
        bondidxtuple = bond.GetBeginAtomIdx(), bond.GetEndAtomIdx()

        molgraph.es[molgraph.get_eid(*bondidxtuple)]["bondtype"] = str(bond.GetBondType())
        molgraph.es[molgraph.get_eid(*bondidxtuple)]["atomsymbols"] = tuple(
            [m.GetAtomWithIdx(i).GetSymbol() for i in bondidxtuple]
        )

    if networkx:
        return molgraph.to_networkx()
    else:
        return molgraph


def graphfromase(atoms, slab_indices, mult=1, networkx=False):
    """
    For given surface slab with adsorbate, this first calculate adjacency matrix and extract adsorbate's molecular graph as adjacency matrix.

    Parameters
    ----------
    atoms : ase object
        metal surface with adsorbate on top.
    slab_indices : list
        Indices of slab atoms.
    mult : float, optional
        Multiplicative factor for bond length cutoff (default is 1).
    networkx : bool, optional
        If True, return a NetworkX graph instead of an igraph object (default is False).

    Returns
    -------
    ig.Graph or nx.Graph
        Adsorbate molecule's graph object.
    """
    cutOff = neighborlist.natural_cutoffs(
        atoms, mult=mult
    )  # generate covalent radii for each elements in ase object
    neighbor = neighborlist.NeighborList(cutOff, self_interaction=False, bothways=True)
    neighbor.update(atoms)

    atom_dict = {
        i: symb for i, symb in enumerate(atoms.get_chemical_symbols()) if i not in slab_indices
    }
    adsorbateidx = sorted(list(atom_dict.keys()))[0]

    adjacency = neighbor.get_connectivity_matrix(sparse=False)[adsorbateidx:, adsorbateidx:]
    ase_graph = ig.Graph.Adjacency(adjacency, mode="undirected")
    ase_graph.vs["Symbols"] = [atom.symbol for atom in atoms[sorted(atom_dict.keys())]]
    ase_graph.vs["AtomicNums"] = [atom.number for atom in atoms[sorted(atom_dict.keys())]]
    ase_graph.vs["AtomIndex"] = sorted(list(atom_dict.keys()))

    if networkx:
        return ase_graph.to_networkx()
    else:
        return ase_graph


def get_bonds_to_preserve(initial, final, slab_indices, mult=0.8):
    """
    Get the bonds that should be preserved between two molecular graphs.

    Parameters
    ----------
    initial : ase.Atoms
        Initial state atoms.
    final : ase.Atoms
        Final state atoms.
    slab_indices : list
        Indices of slab atoms.
    mult : float, optional
        Multiplicative factor for bond length cutoff (default is 0.8).

    Returns
    -------
    list[tuple]
        List of tuple of atomic indices as bond that should be preserved.
    """
    cutOff = neighborlist.natural_cutoffs(initial, mult=mult)
    neighbor = neighborlist.NeighborList(cutOff, self_interaction=False, bothways=True)
    neighbor.update(initial)
    adjacency = neighbor.get_connectivity_matrix(sparse=False)

    adsorbate_indices = [at.index for at in initial if at.index not in slab_indices]
    initial_matrix = np.triu(adjacency[np.ix_(adsorbate_indices, adsorbate_indices)])

    cutOff = neighborlist.natural_cutoffs(final, mult=mult)
    neighbor = neighborlist.NeighborList(cutOff, self_interaction=False, bothways=True)
    neighbor.update(final)
    adjacency = neighbor.get_connectivity_matrix(sparse=False)

    adsorbate_indices = [at.index for at in final if at.index not in slab_indices]
    final_matrix = np.triu(adjacency[np.ix_(adsorbate_indices, adsorbate_indices)])

    bonds_to_preserve = []
    for bond in np.array(np.where(2 * initial_matrix - final_matrix == 1)).T + len(slab_indices):
        bonds_to_preserve.append(tuple(bond))

    return bonds_to_preserve


def is_interpolation_reasonable_bonds(images, slab_indices, mult=1.0):
    """
    Check if the interpolation between molecular graphs is reasonable by analyzing the bonds.

    Parameters
    ----------
    images : list[ase.Atoms]
        List of molecular graphs (initial and final states).
    slab_indices : list
        Indices of slab atoms.
    mult : float, optional
        Multiplicative factor for bond length cutoff (default is 1.0).

    Returns
    -------
    bool
        True if the interpolation is reasonable, False otherwise.
    list[tuple]
        List of unexpectedly broken bonds.
    """
    bonds_to_preserve = get_bonds_to_preserve(images[0], images[-1], slab_indices)
    unexpectedly_broken_bonds = []

    # bonds_to_preserved_per_image = []
    for image in images:
        cutOff = neighborlist.natural_cutoffs(image, mult=mult)
        neighbor = neighborlist.NeighborList(cutOff, self_interaction=False, bothways=True)
        neighbor.update(image)
        adjacency = neighbor.get_connectivity_matrix(sparse=False)

        #        adsorbate_indices = [at.index for at in image if at.symbol not in ["Rh", "Cu"]]
        adsorbate_indices = [at.index for at in image if at.index not in slab_indices]

        matrix = adjacency[np.ix_(adsorbate_indices, adsorbate_indices)]

        intermediate_bonds = [
            tuple(bond) for bond in np.array(list(np.nonzero(matrix))).T + len(slab_indices)
        ]

        any_bond_broken = [bond in intermediate_bonds for bond in bonds_to_preserve]
        if not np.all(any_bond_broken):
            for j in [i for i, a in enumerate(any_bond_broken) if not a]:
                # print(bonds_to_preserve[j])
                unexpectedly_broken_bonds.append(bonds_to_preserve[j])

    unexpectedly_broken_bonds = list(set(unexpectedly_broken_bonds))

    if len(unexpectedly_broken_bonds) == 0:
        return True, unexpectedly_broken_bonds
    else:
        return False, unexpectedly_broken_bonds


def get_partial_displacements(images, indices=[]):
    """
    Get the accumulated displacements of specified atoms between consecutive images.

    Parameters
    ----------
    images : list[ase.Atoms]
        List of molecular graphs (initial and final states).
    indices : list[int], optional
        List of atom indices to consider (default is all atoms).

    Returns
    -------
    float
        The total displacement along the path.
    """
    positions = [atoms.positions for atoms in images]
    n_images = len(images)
    cell = images[0].cell
    pbc = images[0].pbc

    path = [0]
    for i in range(n_images - 1):
        if len(indices) == 0:
            dR = positions[i + 1] - positions[i]
        else:
            dR = positions[i + 1][indices] - positions[i][indices]
        if cell is not None and pbc is not None:
            dR, _ = find_mic(dR, cell, pbc)
        path.append(path[i] + np.sqrt((dR**2).sum()))
    return path[-1]


def tag_atoms(atoms, slab_indices, fix_indices):
    """
    Tag atoms in the system based on constraints and slab/adsorbate distinction. Following cattsunami's convention.

    0 : Fixed slab atoms
    1 : Relaxed slab atoms
    2 : Adsorbate atoms

    Parameters
    ----------
    atoms : ase.Atoms
        The atomic structure to tag.
    slab_indices : list[int]
        Indices of slab atoms.
    fix_indices : list[int]
        Indices of fixed atoms.
    """
    tags = []
    for at_i in range(len(atoms)):
        if at_i in fix_indices:
            tags.append(0)
        elif at_i not in fix_indices and at_i in slab_indices:
            tags.append(1)
        else:
            tags.append(2)
    atoms.arrays["tags"] = np.array(tags)


def get_active_bonds_from_images(images, slab_indices):
    """
    Get the active bonds from the initial and final images.

    Parameters
    ----------
    images : list[ase.Atoms]
        List of molecular graphs (initial and final states).
    slab_indices : list[int]
        Indices of slab atoms.

    Returns
    -------
    dict
        A dictionary containing the active bonds (formed and broken) between the initial and final images.
    """
    ads_matrix = []
    for atoms in [images[0], images[-1]]:
        adsorbate_indices = [i for i, at in enumerate(atoms) if i not in slab_indices]
        cutOff = neighborlist.natural_cutoffs(atoms)
        neighbor = neighborlist.NeighborList(cutOff, self_interaction=False, bothways=True)
        neighbor.update(atoms)
        matrix = neighbor.get_connectivity_matrix(sparse=False)
        ads_matrix.append(matrix[np.ix_(adsorbate_indices, adsorbate_indices)])

    active_bonds = {}
    adsorbate_indices = np.array(adsorbate_indices)
    a, b = np.where(np.tril(ads_matrix[1] - ads_matrix[0]) == 1)
    if np.any([len(a), len(b)]):
        active_bonds["Form"] = (adsorbate_indices[a[0]], adsorbate_indices[b[0]])
    # else:
    #     active_bonds["Form"] = (adsorbate_indices[a[0]], adsorbate_indices[b[0]])
    a, b = np.where(np.tril(ads_matrix[1] - ads_matrix[0]) == -1)
    active_bonds["Break"] = (adsorbate_indices[a[0]], adsorbate_indices[b[0]])
    # print(active_bonds)

    return active_bonds


def swap_multiple_indices(atoms, old_indices, new_indices):
    """
    Swap the order of indices in the atoms.

    Parameters
    ----------
    atoms : ase.Atoms
        The atomic structure to modify.
    old_indices : list[int]
        The indices to swap.
    new_indices : list[int]
        The new indices to assign.

    Returns
    -------
    ase.Atoms
        The modified atomic structure with swapped indices.
    """
    copied_atoms = atoms.copy()
    indices = [atom.index for atom in copied_atoms]
    # indices[a], indices[b] = indices[b], indices[a]
    for j, oldidx in enumerate(old_indices):
        indices[oldidx] = new_indices[j]

    atoms_old = []
    for atom in copied_atoms:
        atoms_old.append([atom.symbol, atom.position])

    del copied_atoms[indices]
    # swapped = []

    new_adsorbates = [atoms_old[idx] for idx in indices]
    for atom in new_adsorbates:
        copied_atoms.append(Atom(atom[0], position=atom[1]))

    return copied_atoms


def get_neb_path(images):
    """
    Get the NEB path from the images.

    Parameters
    ----------
    images : list[ase.Atoms]
        The images representing the NEB path.

    Returns
    -------
    list[float]
        The NEB path as a list of distances.
    """
    positions = [atoms.positions for atoms in images]
    n_images = len(images)
    cell = images[0].cell
    pbc = images[0].pbc

    path = [0]
    for i in range(n_images - 1):
        dR = positions[i + 1] - positions[i]
        if cell is not None and pbc is not None:
            dR, _ = find_mic(dR, cell, pbc)
        path.append(path[i] + np.sqrt((dR**2).sum()))

    return path


def get_idpp_surface_area(images):
    """
    Get the area under the curve between IDPP energy and accumulated distance from the images.

    Parameters
    ----------
    images : list[ase.Atoms]
        The images representing the NEB path.

    Returns
    -------
    float
        The area under the curve between IDPP energy and accumulated distance.
    """
    real_calcs = []

    d1 = images[0].get_all_distances(mic=True)
    d2 = images[-1].get_all_distances(mic=True)
    d = (d2 - d1) / (len(images) - 1)
    for i, image in enumerate(images):
        real_calcs.append(image.calc)
        image.calc = IDPP(d1 + i * d, mic=True)

    energy = np.array([at.get_potential_energy() for at in images])

    for at, calc in zip(images, real_calcs):
        at.calc = calc

    return auc(get_neb_path(images), energy)


def get_idpp_energy(images):
    """
    Get the IDPP energy from the images.

    Parameters
    ----------
    images : list[ase.Atoms]
        The images representing the NEB path.

    Returns
    -------
    np.ndarray
        The IDPP energy as a numpy array.
    """
    real_calcs = []
    copied_images = [at.copy() for at in images]
    d1 = copied_images[0].get_all_distances(mic=True)
    d2 = copied_images[-1].get_all_distances(mic=True)
    d = (d2 - d1) / (len(copied_images) - 1)
    for i, image in enumerate(copied_images):
        real_calcs.append(image.calc)
        image.calc = IDPP(d1 + i * d, mic=True)

    energy = np.array([at.get_potential_energy() for at in copied_images])
    return energy
