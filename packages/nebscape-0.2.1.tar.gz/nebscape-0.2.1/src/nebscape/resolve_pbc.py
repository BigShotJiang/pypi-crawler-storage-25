"""
Functions to linearly interpolate between two images considering periodic boundary conditions without breaking bonds.
"""

import numpy as np
import itertools
from ase.geometry import complete_cell
from ase.geometry.minkowski_reduction import minkowski_reduce
from ase.geometry import wrap_positions
from ase import neighborlist
from .utils import (
    graphfromase,
    get_bonds_to_preserve,
    get_partial_displacements,
    get_active_bonds_from_images,
)


def find_mic_with_exception(v, cell, pbc=True, special_indices=None):
    """
    Find the minimum-image representation of vector(s) v. Using the Minkowski reduction the algorithm is relatively slow but safe for any cell.

    Parameters
    ----------
    v : numpy array
        vector matrix
    cell : cell
        simulation cell
    pbc : pbc
        periodic boundary conditions
    special_indices : dict
        dictonary with keys as atom index and values as special pbc index to be used.

    Returns
    -------
    vmin : numpy array
        Minimum image representation of the input vector(s).
    vlen : numpy array
        Lengths of the minimum images.
    lengths : numpy array
        Lengths of all images.
    indices : numpy array
        Indices of the minimum images.
    x : numpy array
        All images.
    """
    cell = complete_cell(cell)
    rcell, _ = minkowski_reduce(cell, pbc=pbc)
    positions = wrap_positions(v, rcell, pbc=pbc, eps=0)

    # In a Minkowski-reduced cell we only need to test nearest neighbors,
    # or "Voronoi-relevant" vectors. These are a subset of combinations of
    # [-1, 0, 1] of the reduced cell vectors.

    # Define ranges [-1, 0, 1] for periodic directions and [0] for aperiodic
    # directions.
    ranges = [np.arange(-1 * p, p + 1) for p in pbc]

    # Get Voronoi-relevant vectors.
    # Pre-pend (0, 0, 0) to resolve issue #772
    hkls = np.array([(0, 0, 0)] + list(itertools.product(*ranges)))
    # print("hkls : ", hkls)

    vrvecs = hkls @ rcell

    # Map positions into neighbouring cells.
    x = positions + vrvecs[:, None]

    # Find minimum images
    lengths = np.linalg.norm(x, axis=2)
    # print("lengths : ", lengths)

    indices = np.argmin(lengths, axis=0)

    if special_indices is not None:
        for j, index in special_indices.items():
            indices[j] = index

    vmin = x[indices, np.arange(len(positions)), :]
    vlen = lengths[indices, np.arange(len(positions))]
    return vmin, vlen, lengths, indices, x


def linear_interpolate(images, special_indices=None):
    """
    Linearly interpolate positions between the first and last image awaring periodic boundary conditions.

    Parameters
    ----------
    images : list
        List of images to interpolate between.
    special_indices : dict, optional
        Dictionary with keys as atom index and values as special pbc index to be used.
    """
    pos1 = images[0].get_positions()
    pos2 = images[-1].get_positions()
    d = pos2 - pos1
    d = find_mic_with_exception(
        d, images[0].get_cell(), pbc=images[0].pbc, special_indices=special_indices
    )[0]
    d /= len(images) - 1.0

    for i in range(1, len(images) - 1):
        new_pos = pos1 + i * d
        images[i].set_positions(new_pos, apply_constraint=None)


#    return np.linalg.norm(d)


def get_mic_indices(pbctensor, preserve_indices):
    """
    Get the minimum image convention (MIC) indices for a set of preserved indices.

    Parameters
    ----------
    pbctensor : np.ndarray
        The periodic boundary condition (PBC) tensor.
    preserve_indices : list
        The list of atom indices to preserve.

    Returns
    -------
    dict
        A dictionary mapping each preserved index to its MIC index.
    """
    minimum_image_indices = {}
    for i in preserve_indices:
        lengths = np.linalg.norm(pbctensor[:, i, :], axis=1)
        minimum_image_indices[i] = np.argmin(lengths)

    # keys are atom index and values are pbc mic index
    # print("minimum_image_indices : ", minimum_image_indices)

    return minimum_image_indices


def get_fragmented_groups(preserve_graph, unexpectedly_broken_bonds):
    """
    Based on one molecular graph, this function fragments molecule based on unexpectedly_broken_bonds to get each fragmented groups. And for each group, MIC vector can be fixed.

    Parameters
    ----------
    preserve_graph : ig.Graph
        The molecular graph to fragment.
    unexpectedly_broken_bonds : list of tuples
        The list of unexpectedly broken bonds, where each bond is represented as a tuple of atom indices.

    Returns
    -------
    list of list of int
        A list of fragmented groups, where each group is a list of atom indices.
    """
    preserve_graph_copied = preserve_graph.copy()
    for bonds in unexpectedly_broken_bonds:
        #        print("bonds :", bonds)
        broken_edge = [v.index for v in preserve_graph_copied.vs.select(AtomIndex_in=bonds)]
        broken_edge_index = preserve_graph_copied.get_eid(*broken_edge)
        preserve_graph_copied.delete_edges(broken_edge_index)

    fragmented_groups = [
        [v["AtomIndex"] for v in graph.vs] for graph in preserve_graph_copied.decompose()
    ]

    return fragmented_groups


def get_alternative_mic_indices(
    initial,
    final,
    preserve_indices,
    fragmented_groups,
    previous_unexpectedly_broken_bonds,
    bond_to_resolve,
    slab_indices,
    use_length=True,
    mult=0.8,
    minimum_image_indices=None,
    truncate=2,
):
    """
    Get alternative minimum image convention (MIC) indices for a set of atoms.

    NEB interpolation is not effective with PBC because mic for each individual atom
    breaks those group should be intact. When the artifact occurs, it calculates average
    vector of each groups that should stay together and find better pbc index and returns
    corresponding dictionary. (e.g. key as atom index and pbc index as values).

    Parameters
    ----------
    initial : Atoms
        The initial atomic configuration.
    final : Atoms
        The final atomic configuration.
    preserve_indices : list
        The list of atom indices to preserve.
    fragmented_groups : list of list of int
        A list of fragmented groups, where each group is a list of atom indices.
    previous_unexpectedly_broken_bonds : list of tuples
        The list of previously broken bonds, where each bond is represented as a tuple of atom indices.
    bond_to_resolve : list of tuples
        The list of bonds to resolve, where each bond is represented as a tuple of atom indices.
    slab_indices : list of int
        The list of slab indices.
    use_length : bool
        Whether to use length information for resolving bonds.
    mult : float
        The multiplier for length scaling.
    minimum_image_indices : dict
        Key as atom index and value as pbc index (e.g.) {66: 13, 67: 13, 68: 5, 69: 5, 73: 5}.
    truncate : int
        The number of minimum indices to consider for each atom.

    Returns
    -------
    list of dicts
        List of dicts of special indices that preserves the bonds over the intepolation.
    """
    pos1 = initial.get_positions()
    pos2 = final.get_positions()
    d = pos2 - pos1

    vmin, vlen, lengths, indices, pbctensor = find_mic_with_exception(d, initial.cell, final.pbc)
    if minimum_image_indices is None:
        minimum_image_indices = get_mic_indices(pbctensor, preserve_indices)

    candidate_mic_dicts = []

    for group_i, group in enumerate(fragmented_groups):
        maingroup = {atom_index: minimum_image_indices[atom_index] for atom_index in group}
        # print("maingroup : ", maingroup)

        ref_v = np.average(
            np.array(
                [pbctensor[pbc_index, atom_index, :] for atom_index, pbc_index in maingroup.items()]
            ),
            axis=0,
        )

        not_main_group = [
            group for group_j, group in enumerate(fragmented_groups) if group_j != group_i
        ]
        not_main_group = [x for xs in not_main_group for x in xs]
        min_indices_dict = {}
        for no_mic_atom_index in not_main_group:
            #            print("no_mic_atom_indices : ", no_mic_atom_index)
            # no_mic_atom_indices = [key for key, val in minimum_image_indices.items() if val == no_mic_idx]
            v2 = np.average(pbctensor[:, [no_mic_atom_index], :], axis=1)

            # Compute dot products (element-wise across 28 vectors)
            dot_products = np.einsum("i,ji->j", ref_v, v2)

            # Compute cosine values
            cosine_values = dot_products / (np.linalg.norm(ref_v) * np.linalg.norm(v2, axis=1))

            # Clamp values to avoid numerical errors (due to floating-point precision)
            cosine_values = np.clip(cosine_values, -1, 1)

            # Compute angles
            angles = np.arccos(cosine_values)
            # print("angles : ", angles)

            # Find the index of the minimum angle
            if use_length:  # 0.68 worked fine for most cases
                min_indices = np.argsort(
                    angles
                    + 0.68 * lengths[:, no_mic_atom_index] / np.min(lengths[:, no_mic_atom_index])
                )[:truncate]
            else:
                min_indices = np.argsort(angles)[:truncate]
            # print(min_indices)
            min_indices_dict[no_mic_atom_index] = min_indices

        for values in itertools.product(*min_indices_dict.values()):
            new_mic_indices = minimum_image_indices.copy()
            for atom_idx, value in zip(min_indices_dict.keys(), values):
                new_mic_indices[atom_idx] = value
            # print(new_mic_indices)

            images = [initial.copy()] + [initial.copy() for _ in range(10)] + [final.copy()]

            linear_interpolate(images, special_indices=new_mic_indices)
            is_reasonable, unexpectedly_broken_bonds = is_interpolation_reasonable_bonds_refactor(
                images,
                slab_indices,
                previous_unexpectedly_broken_bonds,
                mult=mult,
                bond_to_resolve=bond_to_resolve,
            )
            # print("unexpectedly_broken_bonds : ", unexpectedly_broken_bonds)
            if is_reasonable:
                # min_index = pbc_idx
                # print("reasonable!")
                # reasonables.append(images)
                candidate_mic_dicts.append(new_mic_indices)
                break

    return candidate_mic_dicts


def get_optimal_linear_interpolation_pbc(
    initial,
    final,
    slab_indices,
    active_bonds=None,
    special_indices=None,
    mult=0.8,
    numimages=20,
    shortest=True,
    ignore_bonds=None,
    truncate=2,
    verbose=False,
):
    """
    Try first with normal MIC but if it fails due to PBC, find better PBC vectors and provide reasonable linear interpolation.

    Parameters
    ----------
    initial : ASE atoms
        initial geometry
    final : ASE atoms
        final geometry
    slab_indices : list
        list of slab indices
    active_bonds : dict
        dict with active atoms
    special_indices : dict, optional
        key as atomic indices and values as PBC index that will not
        follow minimum image converntion, by default None
    mult : float, optional
        multiplying factor for neighborlist, by default 0.8
    numimages : int, optional
        Number of NEB images, by default 20
    shortest : bool, optional
        If True get only shortest distance case.
        If False, get all possible cases, by default True
    ignore_bonds : list(tuple), optional
        In some case hydrogen bonds are falsely detected as chemical bond
        by neighborlist but can be avoided by specifying which bonds should be
        ignored, by default None
    truncate : int, optional
        Trying all PBC indices is unnecessarily expensive so only those with
        2 lowest loss functions can be tried, by default 2
    verbose : bool, optional
        Enable verbose output print, by default False

    Returns
    -------
    images : list
        List of images with reasonable interpolations over periodic boundary condition.
    mic_dict : dict
        Dictionary of special indices that preserves the bonds over the interpolation.
    """

    images = [initial.copy()] + [initial.copy() for _ in range(numimages)] + [final.copy()]
    if active_bonds is None:
        active_bonds = get_active_bonds_from_images(images, slab_indices)

    linear_interpolate(images, special_indices=special_indices)

    is_reasonable, unexpectedly_broken_bonds = is_interpolation_reasonable_bonds_refactor(
        images, slab_indices, mult=mult, ignore_bonds=ignore_bonds
    )

    if is_reasonable:
        return images, None
    else:
        ## IF normal MIC fails ...
        for _ in range(3):
            images, mic_dict = get_resolved_images(
                unexpectedly_broken_bonds,
                initial,
                final,
                slab_indices,
                active_bonds,
                numimages=numimages,
                minimum_image_indices=special_indices,
                verbose=verbose,
                truncate=truncate,
            )
            is_reasonable, unexpectedly_broken_bonds = is_interpolation_reasonable_bonds_refactor(
                images, slab_indices, mult=mult, ignore_bonds=ignore_bonds
            )
            if mic_dict and is_reasonable:
                break
            elif len(mic_dict) == 0:
                truncate = 4
                if verbose:
                    print("trying with larger truncate")
            #                print("this case will be figured later.")
            else:
                #                print("New unexpectedly_broken_bonds : ", unexpectedly_broken_bonds)
                special_indices = mic_dict.copy()

        return images, mic_dict


def get_resolved_images(
    unexpectedly_broken_bonds,
    initial,
    final,
    slab_indices,
    active_bonds,
    minimum_image_indices=None,
    truncate=2,
    mult=0.8,
    numimages=10,
    verbose=False,
    shortest=True,
):
    """
    Get resolved images for NEB calculation with PBC handling.

    Parameters
    ----------
    unexpectedly_broken_bonds : list(tuple)
        Bonds that are broken due to PBC but should stay intact.
    initial : ASE atoms
        initial geometry
    final : ASE atoms
        final geometry
    slab_indices : list
        list of slab indices
    active_bonds : dict
        dict with active atoms
    minimum_image_indices : dict, optional  (It's the same as special_indices. Should be made consistent)
        key as atomic indices and values as PBC index that will not
        follow minimum image converntion, by default None
    truncate : int, optional
        Trying all PBC indices is unnecessarily expensive so only those with
        2 lowest loss functions can be tried, by default 2
    mult : float, optional
        multiplying factor for neighborlist, by default 0.8
    numimages : int, optional
        Number of NEB images, by default 20
    verbose : bool, optional
        Enabel verbose output print, by default False
    shortest : bool, optional
        If True get only shortest distance case.
        If False, get all possible cases, by default True

    Returns
    -------
    trials : list or list of lists
        List of images with reasonable interpolations over periodic boundary condition.
    special_indices_list : dict or list of dicts
        Dictionary of special indices that preserves the bonds over the interpolation.
    """

    ## IF normal MIC fails ...
    original_unexpectedly_broken_bonds = unexpectedly_broken_bonds.copy()
    if verbose:
        print("pbc problem", unexpectedly_broken_bonds)
    preserve_group_dict = get_indices2preserve(
        initial,
        slab_indices,
        active_bonds,
        original_unexpectedly_broken_bonds,
        mult=mult,
    )

    mic_dict_list = []
    for name, info_dict in preserve_group_dict.items():
        if len(info_dict["broken_bonds"]) > 0:
            preserve_indices = info_dict["graph"].vs.get_attribute_values("AtomIndex")
            fragmented_groups = get_fragmented_groups(info_dict["graph"], info_dict["broken_bonds"])
            candidate_mic_dicts = get_alternative_mic_indices(
                initial,
                final,
                preserve_indices,
                fragmented_groups,
                original_unexpectedly_broken_bonds,
                info_dict["broken_bonds"],
                slab_indices,
                minimum_image_indices=minimum_image_indices,
                mult=mult,
                truncate=truncate,
            )
            if len(candidate_mic_dicts) != 0:
                mic_dict_list.append(candidate_mic_dicts)
            else:
                if verbose:
                    print("mic dict not found.")

    trials = []
    special_indices_list = []
    special_indices = {}
    for dictionaries in itertools.product(*mic_dict_list):
        for d in dictionaries:
            special_indices.update(d)
        images = [initial.copy()] + [initial.copy() for _ in range(numimages)] + [final.copy()]
        for at in images:
            at.info["special_mic_indices"] = special_indices
        linear_interpolate(images, special_indices=special_indices)
        trials.append(images)
        special_indices_list.append(special_indices)

    if shortest:
        shortest_index = np.argmin([get_partial_displacements(images) for images in trials])
        return trials[shortest_index], special_indices_list[shortest_index]
    else:
        return trials, special_indices_list


def get_indices2preserve(initial, slab_indices, active_bonds, unexpectedly_broken_bonds, mult=0.8):
    """
    Get indices of pushing, transferring, pulling group. Identifies which groups should have their bonds intact.

    Parameters
    ----------
    initial : ASE Atoms
        initial geometry
    slab_indices : list
        list of indices of slab
    active_bonds : dict
        dict with active atoms
    unexpectedly_broken_bonds : list(tuples)
        Bonds that are broken due to PBC but should stay intact
    mult : float, optional
        _descripmultiplying factor for neighborlisttion_, by default 0.8

    Returns
    -------
    dict
        Dictionary with keys (push, transfer, pull) and values as dictionary of broken_bonds and igraph object that
        should stay intact.
        (ex.)
        preserve_group_dict = {'push': {'broken_bonds': [(36, 37)], 'graph': <igraph.Graph at 0x15268b381050>},
                                'transfer': {'broken_bonds': [], 'graph': <igraph.Graph at 0x15268b380d50>}}
    """
    # convert adsorbates into graph
    initial_graph = graphfromase(initial, slab_indices=slab_indices, mult=mult)

    # Somehow pushgroup and pull group should be identified ...
    for graph in initial_graph.decompose():
        if np.any([v["AtomIndex"] in active_bonds["Break"] for v in graph.vs]):
            dissociating_group = graph
        else:
            pull_group = graph

    num_initial_fragments = len(initial_graph.decompose())

    # Identify which bond should be broken and break bond
    bond2break = [v.index for v in dissociating_group.vs if v["AtomIndex"] in active_bonds["Break"]]
    dissociating_group.delete_edges(dissociating_group.get_eid(*bond2break))

    # Find transferring group
    # May not applicable to dissociation reaction
    dissociating_groups = dissociating_group.decompose()

    # transfer reaction
    if "Form" in active_bonds.keys() and num_initial_fragments == 2:
        for g in dissociating_groups:
            if np.any([v for v in g.vs if v["AtomIndex"] in active_bonds["Form"]]):
                transferring_group = g
            else:
                push_group = g
    #        pulling_group_indices = [v["AtomIndex"] for v in pull_group.vs]

    # Dissociation and isomerization reaction
    else:
        # Group with smaller number of atom is assumed to be transferring group
        i, j = np.argsort([len(g.vs) for g in dissociating_groups])
        transferring_group, push_group = dissociating_groups[i], dissociating_groups[j]
        pull_group = None
    #        pulling_group_indices = None

    #    pushing_group_indices = [v["AtomIndex"] for v in push_group.vs]
    #    transferring_group_indices = [v["AtomIndex"] for v in transferring_group.vs]

    preserve_group_dict = {}
    for name, graph in zip(
        ["push", "transfer", "pull"], [push_group, transferring_group, pull_group]
    ):
        if graph is not None:
            preserve_group_dict[name] = {"broken_bonds": [], "graph": graph}

    for name, info_dict in preserve_group_dict.items():
        for bond in unexpectedly_broken_bonds:
            if (
                len(
                    set(info_dict["graph"].vs.get_attribute_values("AtomIndex")).intersection(
                        set(bond)
                    )
                )
                != 0
            ):
                preserve_group_dict[name]["broken_bonds"].append(bond)

    return preserve_group_dict


def is_interpolation_reasonable_bonds_refactor(
    images,
    slab_indices,
    previous_unexpectedly_broken_bonds=[],
    bond_to_resolve=[],
    ignore_bonds=None,
    mult=0.8,
):
    """
    Check if the interpolation is reasonable by analyzing the bonds.

    Parameters
    ----------
    images : list
        List of images to analyze.
    slab_indices : list
        List of slab indices.
    previous_unexpectedly_broken_bonds : list, optional
        List of previously broken bonds.
    bond_to_resolve : list, optional
        List of bonds to resolve.
    ignore_bonds : list, optional
        List of bonds to ignore.
    mult : float, optional
        Multiplicative factor for bond lengths.

    Returns
    -------
    bool
        True if the interpolation is reasonable, False otherwise.
    list
        List of unexpectedly broken bonds.
    """
    bonds_to_preserve = get_bonds_to_preserve(images[0], images[-1], slab_indices, mult=mult)
    unexpectedly_broken_bonds = []

    for image in images:
        cutOff = neighborlist.natural_cutoffs(image, mult=mult)
        neighbor = neighborlist.NeighborList(cutOff, self_interaction=False, bothways=True)
        neighbor.update(image)
        adjacency = neighbor.get_connectivity_matrix(sparse=False)

        adsorbate_indices = [at.index for at in image if at.index not in slab_indices]

        matrix = adjacency[np.ix_(adsorbate_indices, adsorbate_indices)]

        intermediate_bonds = [
            tuple(bond) for bond in np.array(list(np.nonzero(matrix))).T + len(slab_indices)
        ]

        any_bond_broken = [bond in intermediate_bonds for bond in bonds_to_preserve]
        if not np.all(any_bond_broken):
            for j in [i for i, a in enumerate(any_bond_broken) if not a]:
                # print(bonds_to_preserve[j])
                unexpectedly_broken_bonds.append(bonds_to_preserve[j])

    unexpectedly_broken_bonds = list(set(unexpectedly_broken_bonds))
    if ignore_bonds is not None:
        unexpectedly_broken_bonds = list(
            set(unexpectedly_broken_bonds).difference(set(ignore_bonds))
        )

    if len(unexpectedly_broken_bonds) == 0:
        return True, unexpectedly_broken_bonds
    else:
        if len(set(bond_to_resolve).intersection(set(unexpectedly_broken_bonds))) == 0 and len(
            unexpectedly_broken_bonds
        ) < len(previous_unexpectedly_broken_bonds):
            return True, unexpectedly_broken_bonds
        return False, unexpectedly_broken_bonds
