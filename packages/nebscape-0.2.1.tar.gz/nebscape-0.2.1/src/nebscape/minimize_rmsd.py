"""
Improve Alignment between initial and final images by minimizing RMSD.
"""

import numpy as np
from ase.constraints import FixAtoms
from ase.geometry import find_mic, distance
from ase import neighborlist
from ase.build.rotate import rotation_matrix_from_points
from ase.optimize import FIRE
from ase.spacegroup.symmetrize import check_symmetry
import itertools
import copy
import json
import igraph as ig
from networkx.algorithms import isomorphism

from .utils import (
    graphfromase,
    swap_multiple_indices,
)
from .neb_helpers import get_atom_mapped_configs
from wfl.autoparallelize import autoparallelize
from pymatgen.io.ase import AseAtomsAdaptor
from pymatgen.symmetry.site_symmetries import get_site_symmetries
import warnings

warnings.filterwarnings("ignore", category=DeprecationWarning)
warnings.filterwarnings(
    "ignore",
    category=UserWarning,
    module=r"ase\.mep\.neb",
    message=r"The default method has changed from 'aseneb' to 'improvedtangent'",
)


def get_slab_atom_classification(ref_slab, fix_indices=None, symprec=1e-1):
    """
    Get equivalent atoms in slab and return list of indices of equivalent atoms.

    Parameters
    ----------
    ref_slab : ASE atoms
        slab atoms
    fix_indices : list
        indices of fixed atoms
    symprec : float
        symmetry precision threshold, default 1e-1.

    Returns
    -------
    numpy array
        Array of indices of equivalent atoms in the slab.
    sym_dict : dict
        Dictionary of symmetry information.
    """
    sym = check_symmetry(ref_slab, symprec=symprec)
    sym_dict = dict(sym)

    if "tags" in ref_slab.arrays.keys() and fix_indices is None:
        relax_indices = [i for i, tag in enumerate(ref_slab.arrays["tags"]) if tag == 1]
    elif fix_indices is not None:
        relax_indices = [at_i for at_i in range(len(ref_slab)) if at_i not in fix_indices]
    else:
        relax_indices = np.arange(len(ref_slab))

    group_dict = {}
    for at_i, group_i in enumerate(sym_dict["equivalent_atoms"]):
        if group_i not in group_dict.keys():
            group_dict[group_i] = [at_i]
        else:
            group_dict[group_i].append(at_i)

    group_list = []

    toremove = []
    for group_i, atom_indices in group_dict.items():
        relax_group = [at_i for at_i in atom_indices if at_i in relax_indices]
        if len(relax_group) == 0:
            toremove.append(group_i)
        else:
            group_list.append(relax_group)

    return group_list, sym_dict


def get_tiled_slab(atoms, center_atom_index, rcut=6):
    """
    Get a slab of atoms centered around a specific atom.

    Parameters
    ----------
    atoms : Atoms
        The atoms object to create the slab from.
    center_atom_index : int
        The index of the atom to center the slab around.
    rcut : float
        The cutoff radius for the slab.

    Returns
    -------
    repeated_atoms : Atoms
        The slab of atoms centered around the specified atom.
    new_center_index : int
        The index of the center atom in the new slab.
    """
    atoms.arrays["original_index"] = np.arange(len(atoms))

    vectors = [v for v in atoms.cell if ((round(v[0], 3) != 0) or (round(v[1], 3 != 0)))]
    repeats = list(itertools.product([-1, 0, 1], repeat=2))
    repeats.remove((0, 0))

    new_atoms_slab = copy.deepcopy(atoms)

    for repeat in repeats:
        atoms_shifted = copy.deepcopy(atoms)

        atoms_shifted.set_positions(
            atoms.get_positions() + vectors[0] * repeat[0] + vectors[1] * repeat[1]
        )
        new_atoms_slab += atoms_shifted
    center = new_atoms_slab[center_atom_index]
    atoms_within_radious = []
    for at_i, at in enumerate(new_atoms_slab):
        if np.linalg.norm(at.position - center.position) < rcut:
            atoms_within_radious.append(at_i)
    repeated_atoms = new_atoms_slab[atoms_within_radious]

    new_center_index = [
        new_i
        for new_i, orig_i in enumerate(repeated_atoms.arrays["original_index"])
        if orig_i == center_atom_index
    ][0]

    return repeated_atoms, new_center_index


def get_slab_graph(slab, mult=1):
    """
    Get the graph representation of the slab.

    Parameters
    ----------
    slab : Atoms
        The slab of atoms to create the graph from.
    mult : int
        The multiplicative factor for the cutoff radius.

    Returns
    -------
    ig.Graph
        The graph representation of the slab.
    """
    cutOff = neighborlist.natural_cutoffs(
        slab, mult=mult
    )  # generate covalent radii for each elements in ase object
    neighbor = neighborlist.NeighborList(cutOff, self_interaction=False, bothways=True)
    neighbor.update(slab)
    adjacency = neighbor.get_connectivity_matrix(sparse=False)

    # adjacency = adjacency[np.ix_(indices, indices)]
    ase_graph = ig.Graph.Adjacency(adjacency, mode="undirected")
    # ase_graph.vs["Symbols"] = [slab[i].symbol for i in indices]
    # ase_graph.vs["AtomicNums"] = [slab[i].number for i in indices]
    ase_graph.vs["Symbols"] = list(slab.symbols)
    ase_graph.vs["AtomicNums"] = slab.numbers
    ase_graph.vs["AtomIndex"] = slab.arrays["original_index"]

    return ase_graph


# def get_reflection_matrix(p1, p1_reflected):
#    """
#    p1 = tiled_slab_final.positions
#    p1_reflected = mapped_targets[0].positions
#
#    R, T = get_reflection_matrix(p1, p1_reflected)
#    x_reflected = (p1 @ R + T)
#
#    """
#    n = np.average(p1_reflected - p1, axis=0)
#    n = n / np.linalg.norm(n)
#
#    m = 0.5 * (p1 + p1_reflected)
#    R = np.eye(3) - 2 * np.outer(n, n)
#    T = m @ (np.eye(3) - R)
#
#    return R, T


def reflection_from_pairs(atoms1, atoms2, project_to_pure_plane=True):
    """
    Compute the reflection matrix and translation vector between two sets of atomic positions.

    Parameters
    ----------
    atoms1 : Atoms
        The first set of atomic positions.
    atoms2 : Atoms
        The second set of atomic positions.
    project_to_pure_plane : bool
        Whether to project the reflection to a pure plane.

    Returns
    -------
    R : ndarray
        The reflection matrix.
    t : ndarray
        The translation vector.
    n : ndarray
        The normal vector of the reflection plane.
    d : float
        The distance from the origin to the reflection plane.
    """
    X = atoms1.positions
    Y = atoms2.positions
    assert X.shape == Y.shape and X.shape[1] == 3 and X.shape[0] >= 3

    # Centroids
    mu_x = X.mean(axis=0)
    mu_y = Y.mean(axis=0)
    Xc = X - mu_x
    Yc = Y - mu_y

    # Cross-covariance and SVD
    H = Xc.T @ Yc
    U, S, Vt = np.linalg.svd(H)
    V = Vt.T

    # Enforce det(R) = -1
    M = np.eye(3)
    if np.linalg.det(V @ U.T) > 0:
        M[2, 2] = -1
    else:
        # Already negative; keep it that way
        M[2, 2] = 1  # switching sign would flip to +1; so keep identity
    R0 = V @ M @ U.T

    t0 = mu_y - R0 @ mu_x

    if not project_to_pure_plane:
        return R0, t0, None, None

    # Project to pure plane reflection: find eigenvector for eigenvalue ~ -1
    vals, vecs = np.linalg.eig(R0)
    i = np.argmin(np.abs(vals + 1))  # eigenvalue closest to -1
    n = vecs[:, i].real
    n /= np.linalg.norm(n)

    R = np.eye(3) - 2.0 * np.outer(n, n)

    # Estimate d from pairs and n
    d_vals = 0.5 * (X @ n + Y @ n)
    d = float(np.mean(d_vals))
    t = 2.0 * d * n
    # print('hi')
    return R, t, n, d


def get_translate_rotation_matrix(
    slab,
    initial_slab_atom_index,
    final_slab_atom_index,
    rotation_matrices=None,
    threshold=1.0,
    rcut=4,
    verbose=True,
):
    """
    Get translation vector and rotation matrix according to given slab symmetry. If list of rotation matrices are provided, finding rotation matrix from symmetry is skipped.

    Parameters
    ----------
    slab : ASE atoms
        pristine slab atoms
    initial_slab_atom_index : int
        anchoring slab atom for initial state adsorbates
    final_slab_atom_index : int
        anchoring slab atom for final state adsorbates
    rotation_matrices : list
        list of possible rotation matrices for given slab symmetry.
    threshold : float, optional
        Distance threshold for slab graph isomorphism, by default 0.1
    rcut : float, optional
        cutoff radius for tiling slab around anchoring slab atom., by default 4 Angstrom
    verbose : bool, optional
        verbose output, by default True

    Returns
    -------
    v_translate : numpy array
        The translation vector.
    rotation_matrices : list
        The list of rotation matrices.
    shift2origin : numpy array
        The shift to the origin.
    """

    for d in np.linspace(0, 1, 11):
        tiled_slab_final, new_center_index = get_tiled_slab(
            slab, final_slab_atom_index, rcut=rcut + d
        )
        tiled_slab_initial, new_center_index2 = get_tiled_slab(
            slab, initial_slab_atom_index, rcut=rcut + d
        )
        if len(tiled_slab_initial) == len(tiled_slab_final):
            rcut = rcut + d
            break

    #    if (
    #        len(np.unique([at.symbol for at in tiled_slab_initial])) == 1
    #        and len(np.unique([at.symbol for at in tiled_slab_final])) == 1
    #    ):
    #        if verbose:
    #            print("All elements are the same: Rotation matrix set to 0 angle.")
    #        rotation_matrices = [np.eye(3)]

    if rotation_matrices is None:
        mapped_targets, try_reflection = get_isomorphic_slab_part(
            slab,
            initial_slab_atom_index,
            final_slab_atom_index,
            threshold=threshold,
            rcut=rcut,
            verbose=verbose,
        )
        if verbose:
            print(f"number of mapped targets : {len(mapped_targets)}")
            print("mapping done")
            print(f"{try_reflection = }")

        if try_reflection:
            rotation_matrices = []
            shift2origin = tiled_slab_final[new_center_index].position
            c0 = mapped_targets[0][new_center_index].position
            v_translate, _ = find_mic(shift2origin - c0, cell=slab.cell, pbc=slab.pbc)

            for mapped_target in mapped_targets:
                #                R, T = get_reflection_matrix(tiled_slab_final.positions, mapped_target.positions)
                R, T, N, D = reflection_from_pairs(tiled_slab_final, mapped_target)
                rotation_matrices.append(R)

        else:
            rotation_matrices = []
            tiled_slab_final.pbc = [False] * 3
            p = tiled_slab_final.get_positions()
            shift2origin = tiled_slab_final[new_center_index].position
            c0 = mapped_targets[0][new_center_index].position
            v_translate, _ = find_mic(shift2origin - c0, cell=slab.cell, pbc=slab.pbc)
            p -= shift2origin

            for mapped_target in mapped_targets:
                mapped_target.pbc = [False] * 3
                p0 = mapped_target.get_positions()
                p0 -= c0
                # Compute rotation matrix
                rotation_matrices.append(rotation_matrix_from_points(p.T, p0.T))

    else:
        tiled_slab_final.pbc = [False] * 3
        tiled_slab_initial.pbc = [False] * 3

        p = tiled_slab_final.get_positions()
        p0 = tiled_slab_initial.get_positions()

        shift2origin = tiled_slab_final[new_center_index].position
        p -= shift2origin
        c0 = tiled_slab_initial[new_center_index2].position
        p0 -= c0

        v_translate, _ = find_mic(shift2origin - c0, cell=slab.cell, pbc=slab.pbc)

    return v_translate, rotation_matrices, shift2origin


def get_translate_rotated_final(slab, adsorbates, translate_vector, rotation_matrix, shift2origin):
    """
    Get the final positions of the adsorbates after translation and rotation.

    Parameters
    ----------
    slab : Atoms
        The slab atoms.
    adsorbates : Atoms
        The adsorbate atoms.
    translate_vector : ndarray
        The translation vector.
    rotation_matrix : ndarray
        The rotation matrix.
    shift2origin : ndarray
        The shifting vector to origin.

    Returns
    -------
    Atoms
        The final positions of the adsorbates.
    """
    p = adsorbates.positions
    shift2origin = shift2origin.copy()
    shift2origin[2] = 0
    # whether rotation matrix should be transposed and add translation
    # new_adsorbate_positions =  np.dot(p - c00, R.T) + c00 + v_translate
    new_adsorbate_positions = (
        np.dot(p - shift2origin, rotation_matrix.T) + shift2origin - translate_vector
    )

    copied_final = slab.copy()
    copied_adsorbate = adsorbates.copy()
    #    adsorbate_indices = [at_i for at_i, tag in enumerate(copied_final.arrays['tags']) if tag == 2]
    #    del copied_final[adsorbate_indices]

    for at, pos in zip(copied_adsorbate, new_adsorbate_positions):
        at.position = pos

    # new_adsorbate.arrays['original_index']
    for at in sorted(
        copied_adsorbate,
        key=lambda atom: adsorbates.arrays["original_index"][atom.index],
    ):
        copied_final.append(at)

    return copied_final


def get_distance_two_structures(s1, s2):
    """
    Get the distance between two structures.

    Parameters
    ----------
    s1 : Atoms
        The first structure.
    s2 : Atoms
        The second structure.

    Returns
    -------
    float
        The distance between the two structures.
    """
    s1 = s1.copy()
    s2 = s2.copy()
    for s in [s1, s2]:
        s.translate(-s.get_center_of_mass())
    return np.sum(
        [find_mic(at1.position - at2.position, s1.cell, s1.pbc)[1] for at1, at2 in zip(s1, s2)]
    )


def get_isomorphic_slab_part(
    slab,
    initial_slab_atom_index,
    final_slab_atom_index,
    rcut=4.0,
    threshold=1.0,
    verbose=True,
):
    """
    Find isomorphic part of slab using graph analysis. This is used for determining reference rotation which is associated with translation.

    Parameters
    ----------
    slab : ASE atom
        slab atoms
    initial_slab_atom_index : int
        anchoring slab atom for initial state adsorbates
    final_slab_atom_index : int
        anchoring slab atom for final state adsorbates
    rcut : int, optional
        cutoff radius around anchoring atom, by default 4.0
    threshold : float, optional
        Distance threshold for slab graph isomorphism, by default 1.0
    verbose : bool, optional
        verbosity of output, by default True

    Returns
    -------
    mapped_targets : list
        List of part of slab that is mapped.
    try_reflection : bool
        If distance from mapping is larger than threshold, this indicates reflection might be needed.
    """
    tiled_slab_final, new_center_index = get_tiled_slab(slab, final_slab_atom_index, rcut=rcut)
    tiled_slab_initial, _ = get_tiled_slab(slab, initial_slab_atom_index, rcut=rcut)

    if len(tiled_slab_initial) != len(tiled_slab_final):
        return []

    for mult in [1.0, 0.9, 0.8]:
        # convert cluster into graph for index mapping
        graph1 = get_slab_graph(tiled_slab_final, mult=mult)
        graph2 = get_slab_graph(tiled_slab_initial, mult=mult)

        if verbose:
            print("start finding mappings")

        # Get all possible mapping between part of the slab
        all_mappings = isomorphism.vf2pp_all_isomorphisms(
            graph1.to_networkx(), graph2.to_networkx(), node_label="Symbols"
        )
        all_mappings = list(all_mappings)
        if len(all_mappings) != 0:
            if verbose:
                print(f"Isormorphic slab part found with {mult = }")
            break
    if verbose:
        print(f"number of mappings : {len(all_mappings)}")

    mapping_distance1 = []
    mapping_distance2 = []
    for mapping in all_mappings:
        atoms = swap_multiple_indices(
            tiled_slab_initial, list(mapping.keys()), list(mapping.values())
        )
        mapping_distance1.append(distance(tiled_slab_final, atoms, permute=False))
        mapping_distance2.append(get_distance_two_structures(tiled_slab_final, atoms))
    if verbose:
        print("mapping_distance1 : ", sorted(mapping_distance1)[:5])
        print("mapping_distance2 : ", sorted(mapping_distance2)[:5])

    plausible_mappings1 = [
        i for i in np.argsort(mapping_distance1) if mapping_distance1[i] < threshold
    ]
    plausible_mappings2 = [
        i for i in np.argsort(mapping_distance2) if mapping_distance2[i] < threshold
    ]
    if len(plausible_mappings1) == 0 and len(plausible_mappings2) == 0:
        plausible_mappings = [np.argmin(mapping_distance1)]
        try_reflection = True
    elif len(plausible_mappings1) == 0 and len(plausible_mappings2) != 0:
        plausible_mappings = [np.argmin(mapping_distance2)]
        try_reflection = False
    else:
        plausible_mappings = plausible_mappings1
        try_reflection = False

    if verbose:
        print("plausible_mappings ", plausible_mappings)
    mapped_targets = []
    for i in plausible_mappings:
        mapping = all_mappings[i]
        mapped_targets.append(
            swap_multiple_indices(tiled_slab_initial, list(mapping.keys()), list(mapping.values()))
        )

    return mapped_targets, try_reflection


def extract_adsorbates(slab, atoms):
    """
    Extract the adsorbates from the slab and atoms.

    Parameters
    ----------
    slab : Atoms
        The slab atoms.
    atoms : Atoms
        The atoms to extract adsorbates from.

    Returns
    -------
    Atoms
        The extracted adsorbates.
    """
    copied = atoms.copy()
    copied.wrap()

    ads = copied[len(slab) :].copy()

    ads.arrays["original_index"] = np.array([a.index + len(slab) for a in copied[len(slab) :]])

    return ads


class AlignFinalToInitial:
    """
    Align the final structure to the initial structure.

    Parameters
    ----------
    slab : Atoms
        The slab atoms.
    fix_indices : list
        A list of indices of fixed atoms.
    initial_slab_atom_index : int
        The index of the initial slab atom.
    **kwargs : dict
        Additional keyword arguments.
    """

    def __init__(
        self,
        slab,
        #        initial,
        #        final,
        #        mapping_dict,
        fix_indices,
        initial_slab_atom_index=None,
        **kwargs,
    ):
        self.slab = slab
        #        self.initial = initial
        #        self.final = final
        #        self.mapping_dict = mapping_dict
        self.fix_indices = fix_indices
        self.slab_indices = np.arange(len(self.slab))

        defaults = {
            "symprec": 0.1,
            "distance_threshold": 0.15,
            "initial_slab_atom_index": None,
            "rcut": 4.0,
            "rotation_matrices": None,
            "optimize": False,
            "calculator": None,
            "energy_threshold": 0.1,
            "max_num_permutation": None,
            "numimages": 4,
            "force_return_optimized": False,
            "anchor2heavy": False,
            "verbose": False,
            "return_all": False,
            "mult": 0.8,
        }
        for key, default in defaults.items():
            setattr(self, key, kwargs.pop(key, default))

        #        if initial_slab_atom_index is None:
        #            self.initial_slab_atom_index = self.get_nearest_binding_slab_atom(self.initial)
        #        self.final_slab_atom_index = self.get_nearest_binding_slab_atom(self.final)

        if self.slab.constraints:
            del self.slab.constraints
        self.groups, self.symmetric_operations_all_sites = self.get_slab_symmetry()

        if self.optimize:
            assert self.calculator is not None, "Calculator should be provided for relaxation"
        if fix_indices is None:
            assert "tags" in slab.arrays.keys(), "tags should be defined in atoms.arrays"
            fix_indices = [at_i for at_i, tag in enumerate(slab.arrays["tags"]) if tag == 0]

    # tag_atoms(final, slab_indices=slab_indices, fix_indices=fix_indices)
    # tag_atoms(initial, slab_indices=slab_indices, fix_indices=fix_indices)

    def _log(self, msg):
        if self.verbose:
            print(msg)

    def get_slab_symmetry(self):
        """
        Compute symmetry information for the slab structure.

        This method classifies atoms in the slab into symmetry-equivalent
        groups and determines site symmetries based on the slab geometry.

        Returns
        -------
        groups : list[list[int]]
            List of groups of atom indices, where each group contains
            symmetry-equivalent atoms in the slab.

        symms : dict
            Site symmetry information for each atomic site, as returned by
            ``get_site_symmetries``.
        """
        groups, sym_dict = get_slab_atom_classification(
            self.slab, fix_indices=self.fix_indices, symprec=self.symprec
        )

        self._log(f"{sym_dict['international'] = }")
        for group in groups:
            self._log(group)
        symms = get_site_symmetries(
            AseAtomsAdaptor.get_structure(self.slab), precision=self.symprec
        )

        return groups, symms

    def find_middle_point_com(self, atoms, anchor2heavy=True):
        """
        Find the middle point of the center of mass (COM) of the given atoms.

        Parameters
        ----------
        atoms : ASE atoms
            The atoms for which to find the middle point.
        anchor2heavy : bool
            Whether to anchor the middle point to the heavy atom.

        Returns
        -------
        ndarray
            The coordinates of the middle point.
        """
        graphs = graphfromase(atoms, slab_indices=self.slab_indices, mult=self.mult)

        center_of_masses = []
        masses = []
        for graph in graphs.decompose():
            indices = graph.vs.get_attribute_values("AtomIndex")
            center_of_masses.append(atoms.get_center_of_mass(indices=indices))
            masses.append(np.sum(graph.vs.get_attribute_values("AtomicNums")))

        #    print(f"{anchor2heavy = }")
        #    print(f"{center_of_masses = }")
        if len(center_of_masses) == 2:
            if anchor2heavy:
                #            print("anchoring on heavy atom")
                return center_of_masses[np.argmax(masses)]
            else:
                #            print("using previous")
                v, L = find_mic(
                    center_of_masses[0] - center_of_masses[1],
                    cell=atoms.cell,
                    pbc=atoms.pbc,
                )
                middle_point = center_of_masses[0] - v / 2
                return middle_point

        elif len(center_of_masses) == 1:
            return center_of_masses[0]

    def get_nearest_binding_slab_atom(self, atoms):
        """
        Get the nearest binding slab atom of center of mass of adsobate.

        Parameters
        ----------
        atoms : ASE atoms
            slab + adsorbates

        Returns
        -------
        int
            Atom index which is the closest to COM of adsorbates.
        """

        copied_atoms = atoms.copy()

        com = self.find_middle_point_com(copied_atoms, anchor2heavy=self.anchor2heavy)

        distances = {}
        for i in self.slab_indices:
            if i not in self.fix_indices:
                v, L = find_mic(com - copied_atoms[i].position, copied_atoms.cell, copied_atoms.pbc)
                distances[i] = L

        return min(distances, key=distances.get)

    def _get_group(self, idx):
        return next(g for g in self.groups if idx in g)

    def translate_adsorbate(self, adsorbates, initial_slab_atom_index, final_slab_atom_index):
        """
        Translate the adsorbate to the initial position.

        Parameters
        ----------
        adsorbates : ASE atoms
            The adsorbates to translate.
        initial_slab_atom_index : int
            The index of slab atom that is closest to initial adsorbates.
        final_slab_atom_index : int
            The index of slab atom that is closest to final adsorbates.

        Returns
        -------
        ASE atoms
            The translated adsorbates.
        """
        v_translate, rot_mats, _ = get_translate_rotation_matrix(
            self.slab,
            initial_slab_atom_index,
            final_slab_atom_index,
            rotation_matrices=self.rotation_matrices,
            rcut=self.rcut,
            verbose=self.verbose,
        )

        ref_rotation = rot_mats[0]

        # if self.verbose:
        det = np.linalg.det(ref_rotation)
        if np.isclose(det, 1):
            angle = np.degrees(np.arccos((np.trace(ref_rotation) - 1) / 2))
            self._log(f"Rotation angle : {angle:0.2f} degree")
        elif np.isclose(det, -1):
            self._log("Reflection applied.")

        p = (
            self.slab.positions[final_slab_atom_index]
            - self.slab.positions[initial_slab_atom_index]
        )
        v_translate, _ = find_mic(p, cell=self.slab.cell, pbc=self.slab.pbc)

        shift2origin = self.slab.positions[final_slab_atom_index]

        copied_final = get_translate_rotated_final(
            self.slab,
            adsorbates,
            v_translate,
            ref_rotation,
            shift2origin,
        )

        return extract_adsorbates(self.slab, copied_final)

    def find_translation_candidates(self, initial, final):
        """
        Find the translation candidates for the adsorbates.

        Parameters
        ----------
        initial : Atoms
            The initial image of atoms.
        final : Atoms
            The final image of atoms.

        Returns
        -------
        translate_candidates : list
            The list of indices of the slab atoms that are candidates for translation.
        translated_adsorbates : list
            The list of translated adsorbates.
        """
        adsorbates = extract_adsorbates(self.slab, final)

        initial_slab_atom_index = self.get_nearest_binding_slab_atom(initial)
        final_slab_atom_index = self.get_nearest_binding_slab_atom(final)

        group = self._get_group(final_slab_atom_index)

        self._log(f"initial slab atom index :  {initial_slab_atom_index}")
        self._log(f"final slab atom index   : {final_slab_atom_index}")
        in_same_group = initial_slab_atom_index in group

        if in_same_group:
            self._log("in the same group")

            if len(group) == 1 and initial_slab_atom_index == final_slab_atom_index:
                self._log("There's no possible symmetric operation.")
                return None, None

            if initial_slab_atom_index == final_slab_atom_index:
                copied_final = final.copy()
                translated_adsorbates = [extract_adsorbates(self.slab, copied_final)]
            else:
                translated_adsorbates = [
                    self.translate_adsorbate(
                        adsorbates, initial_slab_atom_index, final_slab_atom_index
                    )
                ]

            translate_candidates = [initial_slab_atom_index]

        else:
            self._log("NOT in the same group")

            if len(group) == 1:
                self._log("There's no possible symmetric operation.")
                return None, None

            distances = [
                find_mic(
                    self.slab[i].position - self.slab.positions[initial_slab_atom_index],
                    cell=self.slab.cell,
                    pbc=self.slab.pbc,
                )[1]
                for i in group
            ]

            min_d = np.min(distances)

            translate_candidates = [
                group[i] for i, d in enumerate(distances) if d < min_d + self.distance_threshold
            ]

            self._log(f"{distances = }")
            self._log(f"{translate_candidates = }")

            translated_adsorbates = [
                self.translate_adsorbate(adsorbates, i, final_slab_atom_index)
                for i in translate_candidates
            ]

        return translate_candidates, translated_adsorbates

    def apply_symmetry_operations(
        self, initial, mapping_dict, translate_candidates, translated_adsorbates
    ):
        """
        Apply symmetry operations to the translated adsorbates.

        Parameters
        ----------
        initial : Atoms
            The initial image of atoms.
        mapping_dict : dict
            Dictionary of reaction mapping information.
        translate_candidates : list
            The list of indices of the slab atoms that are candidates for translation.
        translated_adsorbates : list
            The list of translated adsorbates.

        Returns
        -------
        symmetric_structures : list[list[list[Atoms]]]
            The nested list of interpolated images with symmetric structures generated from the translated adsorbates.
        displacements : list[list[float]]
            The list of displacements for each symmetric structure.
        """
        symmetric_structures = []
        displacements = []
        for initial_slab_atom_index, adsorbates in zip(translate_candidates, translated_adsorbates):
            symmetric_ops = self.symmetric_operations_all_sites[initial_slab_atom_index]
            self._log(f"Number of symmetric operations : {len(symmetric_ops)}")

            for u, symop in enumerate(symmetric_ops):
                #            print(f"{u = }")
                shift2origin = self.slab.positions[initial_slab_atom_index]
                new_adsorbates = adsorbates.copy()
                new_pos = symop.operate_multi(adsorbates.positions - shift2origin) + shift2origin
                new_adsorbates.set_positions(new_pos)
                new_atoms = self.slab.copy()
                new_atoms += new_adsorbates
                # It seems that naively using one mapping does not give the shortest distance possible for given geometry
                # Given mapping information, geometry needs "re-mapping" of given geometry before measuring ditance.
                # It seems to be quite critical for evaluating which geometry has the shortest distance between intial and final
                # Perhap re-mapping should be done later again during interpolation.

                images_dict = get_atom_mapped_configs(
                    mapping_dict["mapped_rxnsmiles"],
                    initial,
                    new_atoms,
                    self.slab_indices,
                    mapping_dict["active_bonds"],
                    fix_indices=self.fix_indices,
                    numimages=self.numimages,
                    return_images=True,
                    max_num_permutation=self.max_num_permutation,
                    mult=self.mult,
                )
                #                print(f"{images_dict = }")
                if images_dict is not None:
                    #                    print(f"{images_dict = }")
                    idpp_auc = [
                        images[0].info["idpp_auc"] for permut_i, images in images_dict.items()
                    ]
                    displacements.append(idpp_auc)
                    symmetric_structures.append(list(images_dict.values()))

        return symmetric_structures, displacements

    def select_geometries(self, symmetric_structures, displacements):
        """
        Select the geometries based on the displacements.

        Parameters
        ----------
        symmetric_structures : list[list[list[Atoms]]]
            The nested list of symmetric structures.
        displacements : list[list[float]]
            The list of displacements for each symmetric structure.

        Returns
        -------
        list[list[Atoms]]
            The list of selected geometries based on the displacements.
        """
        self._log(f"{displacements = }")
        # For modified final, add aligned=True into atoms.info
        for symop_i, symops in enumerate(symmetric_structures):
            for permute_i, images in enumerate(symops):
                images[-1].info["aligned"] = True

        if len(displacements) != 0:
            new_final = symmetric_structures[np.argmin([np.min(mus) for mus in displacements])]
        else:
            new_final = []

        if self.return_all:
            return symmetric_structures
        else:
            return [new_final]

    def optimize_modified_final(self, final):
        """
        Optimize the modified final structure.

        Parameters
        ----------
        final : Atoms
            The final image of atoms.

        Returns
        -------
        Atoms
            The optimized modified final structure.
        """
        assert len(self.aligned_interpolations) == 1, (
            "To optimize, it should have only one symmetric operation."
        )
        new_final = self.aligned_interpolations[0][0][-1]
        final.calc = self.calculator
        final_energy = final.get_potential_energy()

        new_final.calc = self.calculator
        opt = FIRE(new_final)
        opt.run(fmax=0.05, steps=200)

        energy_diff = np.abs(final_energy - new_final.get_potential_energy())
        if energy_diff < self.energy_threshold:
            if self.verbose:
                self._log(
                    f"Energy difference is : {energy_diff:0.3f} < {self.energy_threshold} eV : Modified final is accepted"
                )
            return new_final
        else:
            if self.verbose:
                self._log(
                    f"Energy difference is : {energy_diff:0.3f} > {self.energy_threshold} eV : Modified final is not accepted."
                )
            if self.force_return_optimized:
                return new_final
            else:
                #            raise ValueError("Energy difference is high, check the routine.")
                return final

    def run(self, initial, final, mapping_dict, **kwargs):
        """
        Run the alignment procedure.

        Parameters
        ----------
        initial : Atoms
            The initial image of atoms.
        final : Atoms
            The final image of atoms.
        mapping_dict : dict
            Dictionary of reaction mapping information.
        **kwargs : dict
            Additional keyword arguments.

        Returns
        -------
        list[list[Atoms]]
            The list of aligned interpolated images.
        """
        for key, val in kwargs.items():
            setattr(self, key, val)

        # Step 1: find translation candidates
        self.translate_candidates, self.translated_adsorbates = self.find_translation_candidates(
            initial, final
        )

        # In case there's no symmetry to apply
        # Just interpolate current IS and FS and return
        if self.translate_candidates is None and self.translated_adsorbates is None:
            # Even though there's no symmetric operation, permutation should be applied.
            images_dict = get_atom_mapped_configs(
                mapping_dict["mapped_rxnsmiles"],
                initial,
                final,
                self.slab_indices,
                mapping_dict["active_bonds"],
                fix_indices=self.fix_indices,
                numimages=self.numimages,
                return_images=True,
                max_num_permutation=self.max_num_permutation,
                mult=self.mult,
            )
            # If no valid intepolation was generated, return empty list
            if images_dict is None:
                return []
            else:
                return [list(images_dict.values())]

        # Step 2: apply site symmetry
        self.symmetric_structures, self.displacements = self.apply_symmetry_operations(
            initial,
            mapping_dict,
            self.translate_candidates,
            self.translated_adsorbates,
        )

        # Step 3: choose best structure
        self.aligned_interpolations = self.select_geometries(
            self.symmetric_structures, self.displacements
        )
        #        else:
        #           return []

        # Step 4: optional relaxation
        if self.optimize:
            self.new_final = self.optimize_modified_final(final)
            return self.new_final

        return self.aligned_interpolations


def _run_autopara_wrappable(
    pairs,
    slab,
    fix_indices,
    return_all=False,
    max_num_permutation=1,
    verbose=False,
    **kwargs,
):
    output_ats = []

    align = AlignFinalToInitial(
        slab,
        fix_indices,
        calculator=None,
        optimize=False,
        return_all=return_all,
        max_num_permutation=max_num_permutation,
        verbose=verbose,
    )

    for initial, final in pairs:
        final.constraints = [FixAtoms(indices=fix_indices)]
        mapping_dict = {
            "mapped_rxnsmiles": final.info["mapped_rxnsmiles"],
            "active_bonds": json.loads(final.info["active_bonds"]),
        }

        interpolations = align.run(initial, final, mapping_dict)

        for symop_i, symops in enumerate(interpolations):
            for permute_i, images in enumerate(symops):
                for atoms in images:
                    atoms.info["identifier"] = final.info["identifier"]

        output_ats.append(interpolations)

    return output_ats


def improve_alignment(*args, **kwargs):
    """
    Improve the alignment of the structures.

    Parameters
    ----------
    *args : tuple
        Positional arguments to pass to the underlying function.
    **kwargs : dict
        Keyword arguments to pass to the underlying function.

    Returns
    -------
    Any
        The result of the underlying function.
    """
    default_autopara_info = {"num_inputs_per_python_subprocess": 10}
    return autoparallelize(
        _run_autopara_wrappable,
        *args,
        default_autopara_info=default_autopara_info,
        **kwargs,
    )
