"""
Enumerate possible index permutations for given atom-mapping and reduce with active bond information.
"""

import numpy as np
from .utils import (
    graphfromase,
    graphfromsmiles,
    swap_multiple_indices,
    get_idpp_energy,
    is_interpolation_reasonable_bonds,
    get_idpp_surface_area,
)
import itertools
import json
from .resolve_pbc import get_optimal_linear_interpolation_pbc
from ase.mep.neb import idpp_interpolate
from wfl.autoparallelize import autoparallelize

import warnings

warnings.filterwarnings(
    "ignore",
    category=UserWarning,
    module=r"ase\.mep\.neb",
    message=r"The default method has changed from 'aseneb' to 'improvedtangent'",
)


def apply_permutation(
    initial,
    final,
    slab_indices,
    active_bonds,
    constraints,
    max_num_permutation=2,
    numimages=18,
    idpp=True,
    write_idpp_auc=True,
    mult=0.8,
):
    """
    Generate possible index permutation of the same chemical elements.

    If max_num_permutation is set, only the lowest {max_num_permutation} images will be returned based on reaction distance metric idpp_auc (mu).

    Parameters
    ----------
    initial : ase.Atoms
        Initial geometry
    final : ase.Atoms
        Final geometry
    slab_indices : list
        list of slab atom indices
    active_bonds : dict
        Dictionary of atoms participating in the reaction
    constraints : list
        List of constraints
    max_num_permutation : int, optional
        Maximum number of permutations to get, by default 3
    numimages : int, optional
        Number of NEB intermediate images , by default 18
    idpp : bool, optional
        Use IDPP for interpolation, by default True
    write_idpp_auc : bool, optional
        Write IDPP AUC to file, by default True
    mult : float, optional
        Multiplier for neighborlist, by default 0.8

    Returns
    -------
    dict
        Dictionary of interpolated images with possible index permutations.
    """
    swap_candidates = {}
    automorph_arrays = []
    for atoms, label in zip([initial, final], ["initial", "final"]):
        # print(label)
        graphs = graphfromase(atoms, slab_indices, mult=mult).decompose()

        indices_to_be_swapped = []
        # iterate through multiple adsorbates
        for j, graph in enumerate(graphs):
            # Get equivalent indices through graph automorphism
            automorph_array = graph.get_automorphisms_vf2(color=[v["AtomicNums"] for v in graph.vs])
            # map atom index of ASE object to igraph object)
            automorph_array = np.array(
                [[graph.vs[i]["AtomIndex"] for i in permute] for permute in automorph_array]
            )
            # print(f"graph {j} automorph_array : \n", automorph_array)
            automorph_arrays.append(automorph_array)
            indices_to_be_swapped.append(automorph_array)

        swap_candidates[label] = indices_to_be_swapped

    reduced_swap_candidates = {}
    reduced_swap_candidates["initial"] = []
    for automorph_array in swap_candidates["initial"]:
        reduced_swap_candidates["initial"].append(
            reduce_automorphic_array(
                automorph_array,
                initial,
                final,
                slab_indices,
                active_bonds,
                use_idpp=False,
            )
        )

    flattened_arrays = [arr.tolist() for arr in reduced_swap_candidates["initial"]]
    if len(flattened_arrays) == 1:
        initial_combinations = flattened_arrays[0]
    else:
        initial_combinations = [list(a + b) for a, b in itertools.product(*flattened_arrays)]
    new_initials = [
        swap_multiple_indices(initial, old_indices=initial_combinations[0], new_indices=indices)
        for indices in initial_combinations
    ]

    pairs = []
    for initial_indices, initiall in zip(initial_combinations, new_initials):
        final_pairs = []
        for automorph_array in swap_candidates["final"]:
            final_pairs.append(
                reduce_automorphic_array(
                    automorph_array,
                    initiall,
                    final,
                    slab_indices,
                    active_bonds,
                    use_idpp=True,
                )
            )
        flattened_arrays = [arr.tolist() for arr in final_pairs]
        if len(flattened_arrays) == 1:
            final_combinations = [arr[0] for arr in flattened_arrays]
        else:
            final_combinations = [list(a + b) for a, b in itertools.product(*flattened_arrays)]
        pairs.append([initial_indices, final_combinations])

    initial_old_indices = np.hstack([arr[0] for arr in swap_candidates["initial"]])
    final_old_indices = np.hstack([arr[0] for arr in swap_candidates["final"]])

    images_dict = {}
    count = 0
    for pair in pairs:
        initial_new_indices, final_new_indices = pair
        new_initial = swap_multiple_indices(
            initial, old_indices=initial_old_indices, new_indices=initial_new_indices
        )
        for final_indices in final_new_indices:
            new_final = swap_multiple_indices(
                final, old_indices=final_old_indices, new_indices=final_indices
            )

            new_initial.constraints = constraints
            new_final.constraints = constraints
            new_initial.info["active_bonds"] = active_bonds
            new_final.info["active_bonds"] = active_bonds
            new_initial.arrays["tags"] = initial.arrays["tags"].copy()
            new_final.arrays["tags"] = final.arrays["tags"].copy()

            images, mic_dict = get_optimal_linear_interpolation_pbc(
                new_initial,
                new_final,
                slab_indices,
                active_bonds,
                mult=mult,
                numimages=numimages,
            )
            images_dict[count] = images
            count += 1

    if max_num_permutation is None:
        if write_idpp_auc:
            for images in images_dict.values():
                idpp_interpolate(images, mic=True, traj=None, log=None)
                mu = get_idpp_surface_area(images)
                for at in images:
                    at.info["idpp_auc"] = mu
        return images_dict

    else:
        toremove = []
        idpp_auc = {}
        for key, images in images_dict.items():
            if idpp:
                idpp_interpolate(images, mic=True, traj=None, log=None)
            reasonable, _ = is_interpolation_reasonable_bonds(images, slab_indices, mult=mult)

            if not reasonable:
                toremove.append(key)
            else:
                mu = get_idpp_surface_area(images)
                idpp_auc[key] = mu
                if write_idpp_auc:
                    for at in images:
                        at.info["idpp_auc"] = mu

        reduced_images_dict = {
            i: images_dict[key]
            for i, key in enumerate(sorted(idpp_auc, key=idpp_auc.get)[:max_num_permutation])
        }
    return reduced_images_dict


def reduce_automorphic_array(
    automorph_array, initial, final, slab_indices, active_bonds, use_idpp=False
):
    """
    Identify symmetric atoms only within active indices and reduce the size of automorph_array.

    Parameters
    ----------
    automorph_array : numpy array
        array which has row as possible indices of atoms
    initial : ase.Atoms
        initial atomic configuration
    final : ase.Atoms
        final atomic configuration
    slab_indices : list
        list of indices defining the slab geometry
    active_bonds : dict
        dictionary of active bonds
    use_idpp : bool
        whether to use IDPP for interpolation

    Returns
    -------
    numpy.array
        Array with reduced rows with only those are related with active_indices.
    """
    #    print("active_indices : ", active_indices)
    # First row or automorph_array is original indices and saved as reference
    active_indices = list(set([i for sub in list(active_bonds.values()) for i in sub]))
    original_indices = automorph_array[0]
    reduced_arrays = []
    # reduced_arrays = [original_indices]

    # Identify column indices where active indices are included
    column_indices = np.where(np.isin(original_indices, active_indices))[0]
    #    print("column_indices : ", column_indices)

    # if there's no symmetric atom within active_indices, then there's no need to permute
    # therefore first row as original indices are returned
    if np.all(
        np.all(
            automorph_array[:, column_indices] == automorph_array[:, column_indices][0],
            axis=0,
        )
    ):
        if use_idpp:
            idpp_score = []
            for i, arr in enumerate(automorph_array):
                if not np.all(arr == original_indices):
                    new_final = swap_multiple_indices(
                        final, old_indices=original_indices, new_indices=arr
                    )
                else:
                    new_final = final
                images, _ = get_optimal_linear_interpolation_pbc(
                    initial,
                    new_final,
                    slab_indices=slab_indices,
                    active_bonds=active_bonds,
                    numimages=8,
                )
                idpp_score.append(np.max(get_idpp_energy(images[1:-1])))
            #            print("idpp_score : ", idpp_score)
            #            print("optimal : ", automorph_array[np.argmin(idpp_score)])
            return automorph_array[np.argmin(idpp_score)].reshape(1, -1)
        else:
            return original_indices.reshape(1, -1)

    # if there are symmetric atom within acitive_indices, reduction operation is performed.
    else:
        # determine which atom is symmetric within column_indices
        is_atom_symmetric = np.any(
            automorph_array[:, column_indices] != automorph_array[:, column_indices][0],
            axis=0,
        )
        #        print("is_atom_symmetric : ", is_atom_symmetric)

        # identify which column has symmetric atom
        column_index_with_symmetry = column_indices[is_atom_symmetric]
        #        print("column_index_with_symmetry : ", column_index_with_symmetry)

        # symmetric_atom_indices = np.unique(automorph_array[:,column_index_with_symmetry].flatten())
        # print("symmetric_atom_indices : ", symmetric_atom_indices)
        # numpy unique returns sorted form so undo sorting is needed.
        uniques, indices = np.unique(
            automorph_array[:, column_index_with_symmetry], return_index=True, axis=0
        )
        uniques = [uniques[index] for index in np.argsort(indices)]
        for unique in uniques:
            #            print("unique : ", unique)
            if use_idpp:
                temp = []
                for i, row in enumerate(automorph_array):
                    # if np.all(np.isin(unique, row[column_index_with_symmetry])):
                    if np.all(unique == row[column_index_with_symmetry]):
                        temp.append(row)
                        # automorph_array = np.delete(automorph_array, i, axis=0)
                #               print("temp : ", temp)
                idpp_score = []
                for arr in temp:
                    if not np.all(arr == original_indices):
                        new_final = swap_multiple_indices(
                            final, old_indices=original_indices, new_indices=arr
                        )
                    else:
                        new_final = final
                    #                        print('same indices')
                    images, _ = get_optimal_linear_interpolation_pbc(
                        initial,
                        new_final,
                        slab_indices=slab_indices,
                        active_bonds=active_bonds,
                        numimages=8,
                    )
                    idpp_score.append(np.max(get_idpp_energy(images[1:-1])))
                #                print("idpp_score : ", idpp_score)
                reduced_arrays.append(temp[np.argmin(idpp_score)])
            else:
                for i, row in enumerate(automorph_array):
                    if np.all(unique == row[column_index_with_symmetry]):
                        reduced_arrays.append(row)
                        automorph_array = np.delete(automorph_array, i, axis=0)
                        break

    return np.array(reduced_arrays)


def get_automorphic_indices(
    initial, final, slab_indices=None, reduce_array=True, active_bonds=None
):
    """
    Generate all possible automorphic index mapping of initial and final structures. Initial and final structures should have atom-mapped.

    swap_candidate should have following format.
    (e.g.) {'initial': [array([[36, 37, 38, 40, 41, 42, 43],
                                [36, 37, 38, 40, 42, 41, 43],
                                [36, 37, 38, 41, 40, 42, 43],
                                [36, 37, 38, 41, 42, 40, 43],
                                [36, 37, 38, 42, 40, 41, 43],
                                [36, 37, 38, 42, 41, 40, 43]]),
            array([[39, 44, 45],
                    [39, 45, 44]])],
            'final': [array([[36, 37, 38, 40, 41, 42, 43, 44],
                    [36, 37, 38, 40, 41, 42, 44, 43],
                    [36, 37, 38, 40, 42, 41, 43, 44],
                    [36, 37, 38, 40, 42, 41, 44, 43],
                    [36, 37, 38, 41, 40, 42, 43, 44],
                    [36, 37, 38, 41, 40, 42, 44, 43],
                    [36, 37, 38, 41, 42, 40, 43, 44],
                    [36, 37, 38, 41, 42, 40, 44, 43],
                    [36, 37, 38, 42, 40, 41, 43, 44],
                    [36, 37, 38, 42, 40, 41, 44, 43],
                    [36, 37, 38, 42, 41, 40, 43, 44],
                    [36, 37, 38, 42, 41, 40, 44, 43]]),
            array([[39, 45]])]}

    Parameters
    ----------
    initial : ase.Atoms
        Initial atomic structure
    final : ase.Atoms
        Final atomic structure
    slab_indices : list of int
        Indices of the slab atoms
    reduce_array : bool, default True
        Whether to reduce the pool of possible index permutations
    active_bonds : dict
        Dictionary of active bonds

    Returns
    -------
    dict
        Possible atom-mapping for initial and final structures.
    """
    swap_candidates = {}
    automorph_arrays = []
    if isinstance(initial, str) and slab_indices is not None:
        active_bonds = {
            key: tuple(np.array(val) - len(slab_indices)) for key, val in active_bonds.items()
        }

    for atoms, label in zip([initial, final], ["initial", "final"]):
        if isinstance(atoms, str):
            graphs = graphfromsmiles(atoms).decompose()
        else:
            # assert slab_indices is not None
            graphs = graphfromase(atoms, slab_indices).decompose()

        indices_to_be_swapped = []
        # iterate through multiple adsorbates
        # iterate through multiple adsorbates
        for j, graph in enumerate(graphs):
            # Get equivalent indices through graph automorphism
            automorph_array = graph.get_automorphisms_vf2(color=[v["AtomicNums"] for v in graph.vs])
            # map atom index of ASE object to igraph object)
            automorph_array = np.array(
                [[graph.vs[i]["AtomIndex"] for i in permute] for permute in automorph_array]
            )
            # print(f"graph {j} automorph_array : \n", automorph_array)
            automorph_arrays.append(automorph_array)
            indices_to_be_swapped.append(automorph_array)

        swap_candidates[label] = indices_to_be_swapped

    # return swap_candidates
    if reduce_array:
        assert active_bonds is not None, "active_bonds should be provided for reduction."
        #        related_indices = list(set([i for sub in list(active_bonds.values()) for i in sub]))

        reduced_swap_candidates = {}
        for key, list_of_indices in swap_candidates.items():
            reduced_swap_candidates[key] = []
            for automorph_array in list_of_indices:
                reduced_swap_candidates[key].append(
                    reduce_automorphic_array_old(automorph_array, active_bonds)
                )

        return reduced_swap_candidates  # , automorph_arrays
    else:
        return swap_candidates  # , automorph_arrays


def reduce_automorphic_array_old(automorph_array, active_bonds):
    """
    Identify symmetric atoms only within active indices and reduce the size of automorph_array (Outdated).

    Parameters
    ----------
    automorph_array : numpy array
        Array which has row as possible indices of atoms
    active_bonds : dict
        Dictionary of active bonds with atom indices.

    Returns
    -------
    numpy.array
        Array with reduced rows with only those are related with active_indices.
    """
    active_indices = list(set([i for sub in list(active_bonds.values()) for i in sub]))

    #    print("active_indices : ", active_indices)
    # First row or automorph_array is original indices and saved as reference
    original_indices = automorph_array[0]
    reduced_arrays = []
    # reduced_arrays = [original_indices]

    # Identify column indices where active indices are included
    column_indices = np.where(np.isin(original_indices, active_indices))[0]
    #    print("column_indices : ", column_indices)

    # if there's no symmetric atom within active_indices, then there's no need to permute
    # therefore first row as original indices are returned
    if np.all(
        np.all(
            automorph_array[:, column_indices] == automorph_array[:, column_indices][0],
            axis=0,
        )
    ):
        return original_indices.reshape(1, -1)

    # if there are symmetric atom within acitive_indices, reduction operation is performed.
    else:
        # determine which atom is symmetric within column_indices
        is_atom_symmetric = np.any(
            automorph_array[:, column_indices] != automorph_array[:, column_indices][0],
            axis=0,
        )
        #        print("is_atom_symmetric : ", is_atom_symmetric)

        # identify which column has symmetric atom
        column_index_with_symmetry = column_indices[is_atom_symmetric]
        #        print("column_index_with_symmetry : ", column_index_with_symmetry)

        # symmetric_atom_indices = np.unique(automorph_array[:,column_index_with_symmetry].flatten())
        # print("symmetric_atom_indices : ", symmetric_atom_indices)
        # numpy unique returns sorted form so undo sorting is needed.
        uniques, indices = np.unique(
            automorph_array[:, column_index_with_symmetry], return_index=True, axis=0
        )
        uniques = [uniques[index] for index in np.argsort(indices)]
        for unique in uniques:
            #            print("unique : ", unique)
            for i, row in enumerate(automorph_array):
                #                if np.all(np.isin(unique, row[column_index_with_symmetry])):
                if np.all(unique == row[column_index_with_symmetry]):
                    reduced_arrays.append(row)
                    automorph_array = np.delete(automorph_array, i, axis=0)
                    break

    return np.array(reduced_arrays)


def _run_autopara_wrappable(
    list_of_pairs,
    slab_indices,
    constraints,
    numimages=18,
    max_num_permutation=2,
    idpp=True,
    verbose=False,
):
    interpolations = []
    for i, (initial, final) in enumerate(list_of_pairs):
        identifier = json.loads(final.info["identifier"])
        active_bonds = final.info["active_bonds"]
        if not isinstance(active_bonds, dict):
            active_bonds = json.loads(final.info["active_bonds"])

        permut_dict = apply_permutation(
            initial,
            final,
            slab_indices,
            active_bonds,
            constraints=constraints,
            numimages=numimages,
            max_num_permutation=max_num_permutation,
            idpp=idpp,
        )
        if len(permut_dict) == 0:
            print(f"This pair #{i} led to unreasonable interpolation.")

        #        print(f"{permut_dict.keys() = }")
        permuted_images = []
        for permut_key, images in permut_dict.items():
            new_identifier = identifier.copy()
            new_identifier["permute"] = permut_key
            for atoms in images:
                atoms.info["identifier"] = json.dumps(new_identifier)
            permuted_images.append(images)
        interpolations.append(permuted_images)

    return interpolations


def apply_permutation_parallel(*args, **kwargs):  # numpydoc ignore=RT05
    """
    Apply permutation in parallel.

    Parameters
    ----------
    *args : list
        Positional arguments to pass to the wrapped function.
        - list_of_pairs : list
            List of pairs of initial and final structures.
        - slab_indices : list
            List of slab indices.
        - constraints : dict
            Dictionary of constraints for the permutation.

    **kwargs : dict
        Keyword arguments to pass to the wrapped function.
        - numimages : int
            Number of images to generate.
        - max_num_permutation : int
            Maximum number of permutations to apply.
        - idpp : bool
            Whether to use IDPP.
        - verbose : bool
            Whether to print verbose output.

    Returns
    -------
    list[list[list[Atoms]]]
        Nested list of interpolated atomic structures with permutations.

        Structure :
        [
            [
                images1, # index permutation0 (images = [Atoms, Atoms, ..., Atoms])
                images2, # index permutation1 (images = [Atoms, Atoms, ..., Atoms])
            ] # permutations
        ] # Geometry pairs
    """
    default_autopara_info = {"num_inputs_per_python_subprocess": 10}
    return autoparallelize(
        _run_autopara_wrappable,
        *args,
        default_autopara_info=default_autopara_info,
        **kwargs,
    )
