import os
import shutil
import tempfile
import random
from pathlib import Path

import numpy as np

# from ase.optimize.minimahopping import MinimaHopping
from .modified_minimahopping import MinimaHopping
from .minhop_helpers import sample_kmeans
from ase.optimize import FIRE
from ase.io.trajectory import Trajectory
import ase.io

from wfl.autoparallelize import autoparallelize, autoparallelize_docstring
from wfl.utils.save_calc_results import at_copy_save_calc_results
from wfl.generate.utils import save_config_type
from wfl.utils.parallel import construct_calculator_picklesafe
from wfl.configset import ConfigSet
from .utils import get_adjacency_matrix


def _relax(
    traj,
    intact_case,
    calculator,
    results_prefix="last_op__optimize_",
    update_config_type="append",
    remove_Hookean=False,
    mult=0.8,
    fmax=0.05,
    steps=500,
    slab_indices=None,
):
    if remove_Hookean:
        print("Relaxation without Hookean constraint started", flush=True)
    minima_results = traj
    if remove_Hookean:
        constraints_without_Hookean = [
            con for con in minima_results[0].constraints if con.todict()["name"] != "Hookean"
        ]
    else:
        constraints = minima_results[0].constraints

    for at in minima_results:
        final_status = "unconverged"
        at.calc = calculator
        if remove_Hookean:
            at.constraints = constraints_without_Hookean
        dyn = FIRE(at, trajectory=None, logfile=None)
        #        dyn.attach(process_step, interval=traj_step_interval)
        dyn.run(fmax=fmax, steps=steps)
        if dyn.converged():
            final_status = "converged"
        at.info["optimize_config_type"] = f"optimize_last_{final_status}"

    # # check whether relaxed structures are intact.
    intact_adjacency = get_adjacency_matrix(intact_case, slab_indices=slab_indices, mult=mult)
    num_intact = 0
    traj = []
    for at in minima_results:
        new_config = at_copy_save_calc_results(at, prefix=results_prefix)
        if remove_Hookean:
            new_config.set_constraint(constraints_without_Hookean)
        else:
            new_config.set_constraint(constraints)
        try:
            current_adjacency = get_adjacency_matrix(
                new_config, slab_indices=slab_indices, mult=mult
            )
        except Exception as e:
            print(f"How exceptional! {e}")
            continue
        if np.all(intact_adjacency == current_adjacency):
            new_config.info["intact"] = True
            num_intact += 1
        else:
            new_config.info["intact"] = False
        save_config_type(new_config, update_config_type, at.info["optimize_config_type"])
        traj.append(new_config)
    print("Relaxation without Hookean constraint started", flush=True)
    return traj


def _get_MD_trajectory(rundir, update_config_type, prefix, md_sample=10):
    md_traj = []
    mdtrajfiles = sorted([file for file in Path(rundir).glob("md*.traj")])
    for filename in mdtrajfiles:
        traj = ase.io.read(f"{filename}", ":")
        for at in traj:
            new_config = at_copy_save_calc_results(at, prefix=prefix)
            save_config_type(new_config, update_config_type, "minhop_traj")
            md_traj.append(new_config)
    if len(md_traj) > md_sample:
        md_traj = random.sample(md_traj, md_sample)

    return md_traj


# perform MinimaHopping on one ASE.atoms object
def _atom_opt_hopping(
    list_of_atoms,
    calculator,
    Ediff0,
    T0,
    minima_threshold,
    mdmin,
    minima_traj,
    fmax,
    timestep,
    totalsteps,
    maxtemp,
    check_minima,
    skip_failures,
    update_config_type,
    results_prefix,
    workdir=None,
    **opt_kwargs,
):
    save_tmpdir = opt_kwargs.pop("save_tmpdir", False)
    return_all_traj = opt_kwargs.pop("return_all_traj", False)
    md_sample = opt_kwargs.pop("md_sample", 10)
    mult = opt_kwargs.pop("mult", 0.8)
    share_minima_traj = opt_kwargs.pop("share_minima_traj", False)
    slab_indices = opt_kwargs.pop("slab_indices", None)
    optimize_only = opt_kwargs.pop("optimize_only", False)
    prerelax_sample = opt_kwargs.pop("prerelax_sample", False)
    n_kmeans = opt_kwargs.pop("n_kmeans", 20)

    intact_case = list_of_atoms.items[0].copy()

    origdir = Path.cwd()
    if workdir is None:
        workdir = Path.cwd()
    else:
        workdir = Path(workdir)

    traj = []
    if optimize_only:
        relaxed_traj = _relax(
            list_of_atoms.items,
            intact_case,
            calculator,
            slab_indices=slab_indices,
            remove_Hookean=True,
            mult=mult,
        )
        return relaxed_traj

    if prerelax_sample and not Path(workdir / "initial_structures.xyz").is_file():
        if not Path(workdir / minima_traj).is_file():
            print("pre-relaxation start.")
            relaxed_traj = _relax(
                list_of_atoms.items,
                intact_case,
                calculator,
                remove_Hookean=False,
                slab_indices=slab_indices,
                mult=mult,
            )
            relaxed_traj = [at for at in relaxed_traj if at.info["intact"]]
            ase.io.write(minima_traj, relaxed_traj)
        else:
            relaxed_traj = ase.io.read(workdir / minima_traj, ":")

        #        relaxed_traj = ase.io.read(workdir / minima_traj, ":")
        list_of_atoms = sample_kmeans(relaxed_traj, slab_indices, n_samples=n_kmeans)
        ase.io.write(workdir / "initial_structures.xyz", list_of_atoms)
        list_of_atoms = ConfigSet(list_of_atoms)

    traj = []
    for i, atom in enumerate(list_of_atoms):
        print(f"minima hopping {i} / {len(list_of_atoms.items)}", flush=True)

        rundir = Path(tempfile.mkdtemp(dir=workdir, prefix="Opt_hopping_"))
        os.chdir(rundir)

        if share_minima_traj:
            minima_traj = workdir / minima_traj

        atom.calc = calculator

        try:
            opt = MinimaHopping(
                atom,
                Ediff0=Ediff0,
                T0=T0,
                minima_threshold=minima_threshold,
                check_minima=check_minima,
                mdmin=mdmin,
                fmax=fmax,
                timestep=timestep,
                minima_traj=minima_traj,
                **opt_kwargs,
            )
            opt(totalsteps=totalsteps, maxtemp=maxtemp)
        except Exception:
            # optimization may sometimes fail to converge.
            print(f"distorted slab detected {i}/{len(list(list_of_atoms))}", flush=True)

        if return_all_traj:
            traj += _get_MD_trajectory(
                rundir, update_config_type, prefix=results_prefix, md_sample=md_sample
            )

        if not save_tmpdir:
            os.chdir(workdir)
            shutil.rmtree(rundir)

    minima = []
    for at in Trajectory(minima_traj):
        if at.calc is not None:
            new_config = at_copy_save_calc_results(at, prefix=results_prefix)
            save_config_type(new_config, update_config_type, "minhop_min")
            minima.append(new_config)
        else:
            minima.append(at)

    relaxed_traj = _relax(
        minima,
        intact_case,
        calculator,
        slab_indices=slab_indices,
        remove_Hookean=True,
        mult=mult,
    )
    traj += relaxed_traj

    os.chdir(origdir)

    return traj


def _run_autopara_wrappable(
    list_of_images,
    calculator,
    Ediff0=1,
    T0=1000,
    minima_threshold=0.5,
    mdmin=2,
    minima_traj="minima.traj",
    fmax=0.05,
    timestep=1,
    totalsteps=10,
    maxtemp=None,
    check_minima=None,
    skip_failures=True,
    update_config_type="append",
    results_prefix="last_op__minhop_",
    workdir=None,
    rng=None,
    _autopara_per_item_info=None,
    **opt_kwargs,
):
    """runs a structure optimization

    Parameters
    ----------
    atoms: list(Atoms)
        input configs
    calculator: Calculator / (initializer, args, kwargs)
        ASE calculator or routine to call to create calculator
    Ediff0: float, default 1 (eV)
        initial energy acceptance threshold
    T0: float, default 1000 (K)
        initial MD temperature
    minima_threshold: float, default 0.5 (A)
        threshold for identical configs
    mdmin: int, default 2
        criteria to stop MD simulation (number of minima)
    fmax: float, default 1 (eV/A)
        max force for optimizations
    timestep: float, default 1 (fs)
        timestep for MD simulations
    totalsteps: int, default 10
        number of steps
    skip_failures: bool, default True
        just skip optimizations that raise an exception
    update_config_type: ["append" | "overwrite" | False], default "append"
        whether/how to add at.info['optimize_config_type'] to at.info['config_type']
    workdir: str/Path default None
        workdir for saving files
    opt_kwargs
        keyword arguments for MinimaHopping
    rng: numpy.random.Generator, default None
        random number generator to use (needed for pressure sampling, initial temperature, or Langevin dynamics)
    _autopara_per_item_info: dict
        INTERNALLY used by autoparallelization framework to make runs reproducible (see
        wfl.autoparallelize.autoparallelize() docs)

    Returns
    -------
        list(Atoms) trajectories
    """

    calculator = construct_calculator_picklesafe(calculator)
    all_trajs = []

    for at_i, images in enumerate(list_of_images):
        #        if _autopara_per_item_info is not None:
        # minima hopping doesn't let you pass in a np.random.Generator, so set a global seed using
        # current generator
        #            np.random.seed(_autopara_per_item_info[at_i]["rng"].integers(2 ** 32))
        #                print(f"_autopara_per_item_info : {_autopara_per_item_info[at_i]}", flush=True)
        #                if "workdir" in _autopara_per_item_info[at_i]:
        #                    workdir = _autopara_per_item_info[at_i]["workdir"]
        #                if "minima_traj" in _autopara_per_item_info[at_i]:
        #                    minima_traj = _autopara_per_item_info[at_i]["minima_traj"]

        traj = _atom_opt_hopping(
            list_of_atoms=images,
            calculator=calculator,
            Ediff0=Ediff0,
            T0=T0,
            minima_threshold=minima_threshold,
            mdmin=mdmin,
            fmax=fmax,
            timestep=timestep,
            totalsteps=totalsteps,
            minima_traj=minima_traj,
            maxtemp=maxtemp,
            check_minima=check_minima,
            skip_failures=skip_failures,
            update_config_type=update_config_type,
            results_prefix=results_prefix,
            workdir=workdir,
            **opt_kwargs,
        )

        all_trajs.append(traj)

    return all_trajs


# run that operation on ConfigSet, for multiprocessing
def minimahopping(*args, **kwargs):
    default_autopara_info = {"num_inputs_per_python_subprocess": 10}

    return autoparallelize(
        _run_autopara_wrappable,
        *args,
        default_autopara_info=default_autopara_info,
        **kwargs,
    )


autoparallelize_docstring(minimahopping, _run_autopara_wrappable, "Atoms")
