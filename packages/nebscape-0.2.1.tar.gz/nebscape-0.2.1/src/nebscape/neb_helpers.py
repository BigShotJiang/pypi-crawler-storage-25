"""
Helper functions related to preparation and running NEB.
"""

import numpy as np
from rdkit import Chem
from ase.vibrations import Vibrations
from collections import Counter
from ase.constraints import FixAtoms
from ase import Atom
from rdkit.Chem import rdChemReactions

from abc import ABC
import argparse
from argparse import RawTextHelpFormatter
from wfl.autoparallelize.remoteinfo import RemoteInfo
from expyre.resources import Resources
from .utils import graphfromsmiles, graphfromase, swap_multiple_indices
from .index_permutation import apply_permutation


def get_argparse():  # numpydoc ignore=GL08
    description = "NEBscape: Automated workflow generating NEB inputs for surface reactions."
    epilog = """Operations:
   isolated   Run minima hopping for one adsorbate on surface.
   dimers      Run minima hopping for two adsorbates on surface.
   prepare    Generate interpolations for NEB.
   neb        Run NEB calculations.

Examples:
   python setting.py --run isolated
   python setting.py --run isolated dimers
   python setting.py --run prepare
   python setting.py --run neb
   python setting.py --run isolated dimers prepare neb
   python setting.py --run isolated -i 0 1 3
   python setting.py --run prepare -i 8 11
"""
    parser = argparse.ArgumentParser(
        description=description, formatter_class=RawTextHelpFormatter, epilog=epilog
    )
    parser.add_argument(
        "-r",
        "--run",
        choices=["isolated", "dimers", "prepare", "neb"],
        nargs="+",  # accept multiple values
        metavar="operation",
        required=True,
        help="Workflow operations to execute (one or more)",
    )
    parser.add_argument(
        "-ns",
        "--nosubmit",
        action="store_false",
        help="Prepare inputs only; do not submit jobs.",
    )
    #    parser.add_argument(
    #        "-ri",
    #        "--remote_info",
    #        default="cluster1",
    #        const="all",
    #        nargs="?",
    #        choices=["cluster1", "cluster2", "cluster3"],
    #        help="Remote cluster to be submitted",
    #    )
    parser.add_argument(
        "-i",
        "--index",
        nargs="+",
        type=int,
        help="Specific indices to process (space-separated integers)",
    )
    #    parser.add_argument(
    #        "-m",
    #        "--method",
    #        default="combined",
    #        const="all",
    #        nargs="?",
    #        choices=["no-climb", "climb", "combined", "sella"],
    #        help="type of operaitons to be performed.",
    #    )
    args = parser.parse_args()
    return args


def get_remote_info(name, num_inputs_per_queued_job=1, partition=None):  # numpydoc ignore=GL08
    if name == "viper":
        remote_info = RemoteInfo(
            sys_name="viper_gpu",
            #    sys_name = "viper_gpu_mace",
            #    sys_name = "raven_gpu",
            job_name="minhop",
            #    input_files = [f"umbrella_stagetwo.model"],
            #    output_files = [f"MD_traj.xyz"],
            num_inputs_per_queued_job=num_inputs_per_queued_job,
            timeout=3600 * 24,
            resources=Resources(max_time="24h", num_nodes=1, partitions=["gpu"]),
        )

        checkpoint_path = "/viper/u2/hjung/7_neb_protocol/eq2_31M_ec4_allmd.pt"

        return remote_info, checkpoint_path

    if name == "viper_dev":
        remote_info = RemoteInfo(
            sys_name="viper_gpu_dev",
            job_name="minhop",
            num_inputs_per_queued_job=num_inputs_per_queued_job,
            timeout=3600 * 1,
            resources=Resources(max_time="15m", num_nodes=1, partitions=["gpu"]),
        )

        checkpoint_path = "/viper/u2/hjung/7_neb_protocol/eq2_31M_ec4_allmd.pt"

        return remote_info, checkpoint_path

    elif name == "raccoon":
        remote_info = RemoteInfo(
            sys_name="fhi-raccoon_ocp",
            job_name="minhop",
            pre_cmds=[
                "mkdir -p /scratch/hjung_$SLURM_JOB_ID",
                "workpath=$(pwd)",
                "cp * /scratch/hjung_$SLURM_JOB_ID",
                "cd /scratch/hjung_$SLURM_JOB_ID",
            ],
            post_cmds=["cp * $workpath", "cd /scratch", "rm -r hjung_$SLURM_JOB_ID/"],
            num_inputs_per_queued_job=num_inputs_per_queued_job,
            timeout=3600 * 24,
            resources=Resources(max_time="24h", num_nodes=1, partitions=["gpubig"]),
        )
        checkpoint_path = "/fhi/home/hjung/7_neb_protocol/eq2_31M_ec4_allmd.pt"

        return remote_info, checkpoint_path

    elif name == "raven":
        remote_info = RemoteInfo(
            #            sys_name = "viper_gpu",
            #    sys_name = "viper_gpu_mace",
            sys_name="raven_gpu",
            job_name="minhop",
            num_inputs_per_queued_job=num_inputs_per_queued_job,
            timeout=3600 * 24,
            resources=Resources(max_time="18h", num_nodes=1, partitions=["gpu"]),
        )

        checkpoint_path = "/raven/u/hjung/7_NEB_protocol/eq2_31M_ec4_allmd.pt"

        return remote_info, checkpoint_path


class AbortOnOscillation(ABC):  # numpydoc ignore=GL08,GL01,GL02,GL03,SS06,PR01
    """Base class used for checking and aborting MD simulation of `wfl.generate.md.sample()`.
    See `stop` method docstring for its default behavior.

    """

    def __init__(self, n_failed_steps=15):
        self.fmax_list = []
        self.n_failed_steps = n_failed_steps

    def atoms_ok(self, opt):  # numpydoc ignore=GL01,SS06,PR01,PR02,PR10,RT03
        """Method returning a boolean indicating whether this trajectory step is acceptable.
        All derived classes must implement this method.

        Parameters
        ----------

        at: Atoms
            atomic configuration

        Returns
        -------
        is_ok: bool containing status
        """
        forces = opt.optimizable.neb.get_forces()
        fmax = np.sqrt((forces**2).sum(axis=1).max())
        return fmax

    def stop(self, opt):  # numpydoc ignore=GL01,SS06,PR01,PR02,PR10,RT03,GL02,SS05,RT01
        """Returns a boolean indicating whether `wfl.generate.md.sample()` should stop
        the simulation. Defaults to aborting if `n_failed_steps` in a row `atoms_ok()`
        are evaluated to False. Derrived classes may overwrite this."""
        self.fmax_list.append(self.atoms_ok(opt))
        if (
            len(self.fmax_list) > self.n_failed_steps
            and len(np.unique(np.round(self.fmax_list[-self.n_failed_steps :], decimals=8))) <= 2
        ):
            return True


def adjust_spring_constants(neb, calculator_tuple=None, k_max=2.5, k_min=0.5):
    """
    Adjust the spring constants for the NEB images based on their energies.

    Parameters
    ----------
    neb : ase.mep.NEB
        The NEB object containing the images.
    calculator_tuple : tuple, optional
        A tuple containing the calculator class and its arguments.
    k_max : float, optional
        The maximum spring constant, by default 2.5.
    k_min : float, optional
        The minimum spring constant, by default 0.5.

    Returns
    -------
    None
        The function modifies the spring constants of the NEB object in place.
    """
    if calculator_tuple is not None:
        calculator = calculator_tuple[0](**calculator_tuple[2])

        for at in neb.images:
            at.calc = calculator

    energy = np.array([at.get_potential_energy() for at in neb.images])
    delta_k = k_max - k_min

    E_ref = np.max([energy[0], energy[-1]])
    E_max = np.max(energy)

    spring_const = []
    for i, e in enumerate(energy[:-1]):
        E_i = np.max([energy[i], energy[i + 1]])
        if E_i > E_ref:
            spring_const.append(k_max - delta_k * (E_max - E_i) / (E_max - E_ref))
        else:
            spring_const.append(k_max - delta_k)

    neb.k = spring_const
    print("spring constants : ", neb.k)
    print("spring constants adjusted.")


def is_equivalent_rxn_smiles(rxn_smi1, rxn_smi2):
    """
    Check if two reaction SMILES strings are equivalent.

    Parameters
    ----------
    rxn_smi1 : str
        The first reaction SMILES string.
    rxn_smi2 : str
        The second reaction SMILES string.

    Returns
    -------
    bool
        True if the reaction SMILES strings are equivalent, False otherwise.
    """
    left1, right1 = [set(part.split(".")) for part in rxn_smi1.split(">>")]
    left2, right2 = [set(part.split(".")) for part in rxn_smi2.split(">>")]

    if (
        len(left1.symmetric_difference(left2)) == 0
        and len(right1.symmetric_difference(right2)) == 0
    ):
        return True
    elif (
        len(left1.symmetric_difference(right2)) == 0
        and len(right1.symmetric_difference(left2)) == 0
    ):
        print("second case")
        return True
    else:
        return False


def create_gas_molecule(atoms, a=15):  # numpydoc ignore=GL08
    #    atoms = mdf.loc[mdf.smiles == smiles].asemol.item()
    atoms.set_pbc([True, True, True])
    atoms.set_cell([[a, 0, 0], [0, a, 0], [0, 0, a]])

    return atoms


def calc_formation_energy(
    atoms, potential_energy, slab, gas_references, gas_species=False
):  # numpydoc ignore=GL08
    atoms_per_struc = Counter(
        [atom for atom in atoms.get_chemical_symbols() if atom not in ["Cu", "Rh"]]
    )
    if not gas_species:
        potential_energy -= slab

    for symb, atomic_energy in gas_references.items():
        potential_energy -= atoms_per_struc[symb] * atomic_energy

    return potential_energy


def get_vibrations(
    atoms,
    calculator,
    gas=False,
    linear=False,
    rotation_threshold=12,
    imag_threshold=100,
    transition_state=False,
):  # numpydoc ignore=GL08
    atoms.calc = calculator

    if gas:
        vib = Vibrations(atoms)
    else:
        adsorbate_indices = [atom.index for atom in atoms if atom.symbol not in ["Rh", "Cu"]]
        vib = Vibrations(atoms, indices=adsorbate_indices)

    vib.run()
    freqs = vib.get_frequencies()
    if gas and linear:
        num_modes = 3 * len(atoms) - 5
        freqs = np.sort(freqs)[::-1][:num_modes]
    elif gas and not linear:
        num_modes = 3 * len(atoms) - 6
        freqs = np.sort(freqs)[::-1][:num_modes]

    real_freq = []
    imag_freq = []
    for freq in freqs:
        if freq.imag == 0:
            if np.real(freq) < rotation_threshold:
                real_freq.append(rotation_threshold)
            else:
                real_freq.append(int(np.real(freq)))
            # print(np.real(freq))
        if freq.real == 0:
            if np.imag(freq) < imag_threshold:
                real_freq.append(rotation_threshold)
            else:
                imag_freq.append(np.imag(freq))
                # print("imaginary", np.imag(freq))
    vib.clean()

    if transition_state:
        assert len(imag_freq) == 1, (
            f"Transition state has {len(imag_freq)} frequencies: {imag_freq}."
        )

    return real_freq, imag_freq


def calculate_reference_energies(structures, energy_key="energy"):  # numpydoc ignore=GL08
    smidict = {"[H][H]": "H2", "O": "H2O", "[C-]#[O+]": "CO"}

    gas_references = {}
    for at in structures:
        if at.info["category"] == "slab":
            slab_energy = at.info[energy_key]

        elif at.info["SMILES"] in smidict.keys() and at.info["category"] == "gas":
            gas_references[smidict[at.info["SMILES"]]] = at.info[energy_key]

    gas_references["H"] = gas_references["H2"] / 2
    gas_references["O"] = gas_references["H2O"] - 2 * gas_references["H"]
    gas_references["C"] = gas_references["CO"] - gas_references["O"]

    return slab_energy, gas_references


def check_adsorbate_isomorphism(smiles, atoms, slab_indices, mult=1, raise_error=True):
    """
    Compare two molecular graph from smiles and from slab structure, and encode expected bondlength and other properties to slab structure.

    This information will be further used to generate Hookean constraints.

    Parameters
    ----------
    smiles : str
        SMILES string for adsorbate
    atoms : ase object
        metal surface with adsorbate on top.
    slab_indices : list
        list of slab atom indices.
    mult : float, optional
        multiplicity for chemical bonding
    raise_error : bool, optional
        whether to raise an error if not isomorphic, by default True

    Returns
    -------
    dict or bool
        With bond length saved as attribute, adsorbate graph is returned is isomorphism match was successful. If failed, False is returned.
    """
    molgraph = graphfromsmiles(smiles)

    ase_graph = graphfromase(atoms, slab_indices=slab_indices, mult=mult)

    isomorphic, map12, map21 = molgraph.isomorphic_vf2(
        ase_graph,
        color1=molgraph.vs["AtomicNums"],
        color2=ase_graph.vs["AtomicNums"],
        return_mapping_12=True,
        return_mapping_21=True,
    )

    mapping = dict(zip(map12, map21))

    if isomorphic:
        return mapping
    else:
        if raise_error:
            raise NameError("error: not isomorphic!")
        return False


def apply_mapped_smiles_to_geometry(smiles, atoms, slab_indices, mult=1):
    """
    For a given mapped SMILES, apply mapping to ASE atoms geometry. If there are multiple mappings, get all possible candidates.

    Parameters
    ----------
    smiles : str
        Mapped SMILES of string of either reactant or product
    atoms : ASE atoms
        atoms of initial or final
    slab_indices : list
        list of slab indices
    mult : float, optional
        multiplicity for chemical bonding, default is 1

    Returns
    -------
    list
        A list of candidate geometries for the mapped SMILES.
    """
    molgraph = graphfromsmiles(smiles)
    ase_graph = graphfromase(atoms, slab_indices=slab_indices, mult=mult)
    old_adsorbate_indices = [atom.index for atom in atoms if atom.index not in slab_indices]

    assert molgraph.isomorphic_vf2(
        ase_graph, color1=molgraph.vs["AtomicNums"], color2=ase_graph.vs["AtomicNums"]
    ), "error, not isomorphic!"

    mappings = molgraph.get_isomorphisms_vf2(
        ase_graph, color1=molgraph.vs["AtomicNums"], color2=ase_graph.vs["AtomicNums"]
    )
    map12 = list(range(len(molgraph.vs)))
    mapping_dicts = [dict(zip(mapping, map12)) for mapping in mappings]
    candidates = []
    for mapping in mapping_dicts:
        mapping = dict(sorted(mapping.items()))
        new_adsorbate_indices = [old_adsorbate_indices[val] for val in mapping.values()]
        candidates.append(
            swap_multiple_indices(atoms, old_adsorbate_indices, new_adsorbate_indices)
        )

    return candidates


def get_atom_mapped_configs(
    mapped_rxnsmiles,
    initial,
    final,
    slab_indices,
    active_bonds,
    fix_indices=None,
    numimages=4,
    return_images=False,
    max_num_permutation=1,
    verbose=False,
    mult=1,
):
    """
    Apply atom-mapping from reaction SMILES to ASE atoms.

    Parameters
    ----------
    mapped_rxnsmiles : str
        atom-mapped reaction SMILES string
    initial : ASE atoms
        Iniitial geometry
    final : ASE atoms
        Final geometry
    slab_indices : list
        list of slab atom indices
    active_bonds : dict
        dictionary of active atoms
    fix_indices : list
        list of fixed atom indices
    numimages : int
        number of images to generate
    return_images : bool
        whether to return images or not
    max_num_permutation : int
        maximum number of index permutations to consider
    verbose : bool
        whether to print verbose output
    mult : int, optional
        Mult for neighbor method, by default 1

    Returns
    -------
    dict or list[ase.Atoms]
        A dictionary of interpolated images with "max_num_permutation" if "return_images==True" or
        a list with initial and final images if "return_images==False".
    """
    rxn = rdChemReactions.ReactionFromSmarts(mapped_rxnsmiles, useSmiles=True)
    if len(rxn.GetReactants()) > 1:
        rdkit_reactants = Chem.CombineMols(*rxn.GetReactants())
    else:
        rdkit_reactants = rxn.GetReactants()[0]
    if len(rxn.GetProducts()) > 1:
        rdkit_products = Chem.CombineMols(*rxn.GetProducts())
    else:
        rdkit_products = rxn.GetProducts()[0]

    ### reactants
    initial_candidates = apply_mapped_smiles_to_geometry(
        rdkit_reactants, initial, slab_indices, mult=mult
    )
    ### products
    final_candidates = apply_mapped_smiles_to_geometry(
        rdkit_products, final, slab_indices, mult=mult
    )

    if fix_indices is None:
        constraints = []
    else:
        constraints = [FixAtoms(indices=fix_indices)]

    images_dict = apply_permutation(
        initial_candidates[0],
        final_candidates[0],
        slab_indices,
        active_bonds,
        max_num_permutation=max_num_permutation,
        numimages=numimages,
        constraints=constraints,
    )
    if return_images:
        if len(images_dict) == 0:
            return None
        else:
            return images_dict
    else:
        return initial_candidates[0], final_candidates[0]


def get_atom_mapped_configs_list(mapped_rxnsmiles, reactants, products, slab_indices, mult=1):
    """
    Get Atom-mapped ASE Atoms for reactant and product pair according to mapped reaction SMILES.

    This function takes **list** of atoms and apply the same atom-mapping to multiple structures.

    Parameters
    ----------
    mapped_rxnsmiles : str
        Reaction SMILES string with atom-mapped indices.
    reactants : list
        list of initial states ASE atoms
    products : list
        list of final states ASE atoms
    slab_indices : list
        list of slab atom indices
    mult : float, optional
        mult value for neighborlist, by default 1

    Returns
    -------
    mapped_IS : list
        List of ase.Atoms with IS.
    mapped_FS : list
        List of ase.Atoms with FS.
    """
    rxn = rdChemReactions.ReactionFromSmarts(mapped_rxnsmiles, useSmiles=True)
    if len(rxn.GetReactants()) > 1:
        rdkit_reactants = Chem.CombineMols(*rxn.GetReactants())
    else:
        rdkit_reactants = rxn.GetReactants()[0]
    if len(rxn.GetProducts()) > 1:
        rdkit_products = Chem.CombineMols(*rxn.GetProducts())
    else:
        rdkit_products = rxn.GetProducts()[0]

    if isinstance(reactants, list):
        returnlist = True
    else:
        returnlist = False
        reactants = [reactants]
    if isinstance(products, list):
        returnlist = True
    else:
        returnlist = False
        products = [products]

    ### reactants
    mapping_reactants = check_adsorbate_isomorphism(
        rdkit_reactants, reactants[0], slab_indices, mult=mult
    )
    adsorbate_indices = [atom.index for atom in reactants[0] if atom.index not in slab_indices]

    for reactant in reactants:
        reactant_old = []

        for atom in list(reactant[adsorbate_indices]):
            reactant_old.append([atom.symbol, atom.position])

        del reactant[adsorbate_indices]

        new_adsorbates = [reactant_old[idx] for idx in mapping_reactants.keys()]
        for atom in new_adsorbates:
            reactant.append(Atom(atom[0], position=atom[1]))

    ### products
    mapping_products = check_adsorbate_isomorphism(
        rdkit_products, products[0], slab_indices, mult=mult
    )
    adsorbate_indices = [atom.index for atom in products[0] if atom.index not in slab_indices]

    for product in products:
        product_old = []

        for atom in list(product[adsorbate_indices]):
            product_old.append([atom.symbol, atom.position])

        del product[adsorbate_indices]

        new_adsorbates = [product_old[idx] for idx in mapping_products.keys()]
        for atom in new_adsorbates:
            product.append(Atom(atom[0], position=atom[1]))

    if returnlist:
        return reactants, products
    else:
        return reactants[0], products[0]
