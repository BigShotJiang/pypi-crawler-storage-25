"""
### Tribulnation Independentreserve
> An SDK to connect Independentreserve with the Tribulnation ecosystem.

- Details
"""