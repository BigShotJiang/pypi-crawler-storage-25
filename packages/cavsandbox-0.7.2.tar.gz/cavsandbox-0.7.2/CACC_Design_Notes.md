# CACC Simulation — Design Notes

**Cooperative Adaptive Cruise Control · Python Simulation**

*Work in progress — April 2026*

***

# About This Document

CACC_Design_Notes.md is the authoritative architecture reference for CAVSandbox. It documents every significant design decision made during development so that maintainers and contributors can understand the system at the level needed to extend it confidently without inadvertently breaking existing behavior.

## Who Should Read This

**Maintainers and contributors** should read this document before making any changes to the core package (`cacc_sim/`). The design decisions recorded here represent thought-out choices about things like the Strategy Pattern structure, the four-level parameter resolution hierarchy, the fixed 0.01 s timestep, and the separation between sensor-level and driving-model-level filtering. Each design choice has a recorded rationale and changes that contradict them without good reason will create problems that may not be immediately obvious.

**Plugin authors** should read Sections [2 (Strategy Pattern)](#2-the-strategy-pattern), [4 (Driving Model Design)](#4-driving-model-design), [5 (Filter Design)](#5-filter-design), and [12 (Plugin System)](#12-plugin-system) carefully. These sections define the interfaces your plugin must implement and the conventions it must follow. [Section 15](#15-development-sequence) (Development Sequence) gives useful context for how the built-in models were built and tested.

**Advanced users** who want to understand why the simulation behaves the way it does, especially around sensor noise, V2V comms, and string stability will find Sections [6 (Sensor Architecture)](#6-sensor-comms-and-fusion-architecture), [7 (ACC/CACC Controller)](#7-acc--cacc-longitudinal-controller), and [3 (Vehicle Response Model)](#3-vehicle-response-model) useful background that goes deeper than the user guide.

## What This Document Is Not

This is not a user guide. It does not explain how to install CAVSandbox, how to set up an Excel input file, or how to interpret simulation results. For those topics see:

- **Quick-Start Guide** — installation and first run
- **User Guide** — full reference for all options and the Excel input format
- **Plugin Author Guide** — step-by-step instructions for writing new models and filters
- **Worked Examples** — pre-built scenarios with interpretation guidance

## How to Use This Document

The document is organized as a series of numbered sections, each covering one architectural subsystem. Sections are largely self-contained and can be read in isolation if you know which subsystem you're working on. Cross-references are explicit (e.g. "see [Section 12](#12-plugin-system)").

Decisions that have been finalized are marked ✅ **Decided:**. Notes that record important constraints or non-obvious choices are marked 📝 **Note:**. If you find yourself about to contradict something marked ✅ **Decided**, read the surrounding context first — there is almost always a reason recorded nearby.

The development sequence ([Section 15](#15-development-sequence)) and test strategy ([Section 16](#16-test-strategy)) together define the intended build order and validation approach. If you are adding a new capability, follow the same pattern: define the interface first, build passthrough stubs, validate with the simplest possible scenario, then add realism incrementally.

## Relationship to Other Developer Files

| File | Purpose | Audience |
|------|---------|---------|
| `CACC_Design_Notes.md` | Architecture decisions and rationale | Maintainers, contributors, plugin authors |
| `CLAUDE.md` | Instructions for Claude Code AI assistant | Claude Code only — not a human reference |
| `cacc_sim/` | The implementation | Read alongside this document |
| `tests/` | Unit and integration tests | Run with pytest before any commit |
| `plugins/` | User-extensible models and filters | Plugin authors |
| `Filter_tests/` | Step 17 sensor validation suite | See [Section 18](#18-step-17-sensor-validation-suite) for specification |

## Current Implementation Status

As of April 2026, all seventeen steps in the development sequence ([Section 15](#15-development-sequence)) are complete. The simulation supports:

- Four built-in driving models plus the Wiedemann99 plugin
- Passthrough and realistic (Kalman and low-pass filter) sensor pipelines
- Passthrough and DSRC V2V comms with multi-rate fusion Kalman filter
- Full five-panel post-run plotting and CSV/YAML output
- Real-time Pygame visualization and CSV playback
- Plugin system for user-extensible models and filters

Known limitations and planned enhancements are documented in Sections 11 and 19.

***

## Table of Contents

- [About This Document](#about-this-document)
- [1. Overall Architecture](#1-overall-architecture)
- [2. The Strategy Pattern](#2-the-strategy-pattern)
- [3. Vehicle Response Model](#3-vehicle-response-model)
- [4. Driving Model Design](#4-driving-model-design)
- [5. Filter Design](#5-filter-design)
- [6. Sensor, Comms, and Fusion Architecture](#6-sensor-comms-and-fusion-architecture)
- [7. ACC / CACC Longitudinal Controller](#7-acc--cacc-longitudinal-controller)
- [8. Mode Switch Logic](#8-mode-switch-logic)
- [9. Lead Vehicle Profile](#9-lead-vehicle-profile)
- [10. Excel Input File](#10-excel-input-file)
- [11. Road Representation and Multi-Lane Preparation](#11-road-representation-and-multi-lane-preparation)
- [12. Plugin System](#12-plugin-system)
- [13. Simulation Loop and Timestep](#13-simulation-loop-and-timestep)
- [14. Renderer Design (Step 8 — Pygame Prototype)](#14-renderer-design-step-8--pygame-prototype)
- [15. Development Sequence](#15-development-sequence)
- [16. Test Strategy](#16-test-strategy)
- [17. Performance](#17-performance)
- [18. Step 17 Sensor Validation Suite](#18-step-17-sensor-validation-suite)
- [19. Potential Future Enhancements](#19-potential-future-enhancements)

***

# 1. Overall Architecture

The simulation is built around five main class hierarchies — driving models, filters, sensor/comms stubs, vehicle response, and vehicles — plus a config loader and a simulation loop. The design goal is that adding a new driving model, filter, or sensor type should require no changes to the simulation loop or vehicle class.

| Component                                                | Role                                                                                            |
|----------------------------------------------------------|-------------------------------------------------------------------------------------------------|
| DrivingModel (ABC)                                       | Abstract base for all longitudinal control algorithms                                           |
| Filter (ABC)                                             | Abstract base for all sensor data filters                                                       |
| BaseSensor / BaseFusionEstimator / BaseBSMTracker (ABCs) | Abstract bases for sensor, fusion, and comms — start as passthroughs, replace later             |
| EgoSensor (ABC)                                          | Abstract base for ego vehicle state measurement (speed, accel); starts as passthrough           |
| VehicleResponseModel                                     | Models actuator lag between commanded and actual acceleration                                   |
| Vehicle                                                  | Holds a model + filter + sensor + ego sensor + response model; maintains position, speed, state |
| MODEL_REGISTRY / FILTER_REGISTRY                         | Maps config string names to classes; populated from plugins folder                              |
| load_vehicles()                                          | Reads Excel vehicles sheet, instantiates vehicles via factories                                 |
| LeadVehicleProfile                                       | Reads Excel profile sheet; provides time-triggered speed targets for lead vehicle               |
| SimulationLoop                                           | Advances time at 0.01 s steps, calls model/filter, logs state to list of dicts                  |

>   📝 **Note:** The registries are populated by scanning a plugins folder at startup (see [Section 12](#12-plugin-system)), so users can add new models or filters without editing core code.

***

# 2. The Strategy Pattern

The driving model, filter, and sensor/comms classes all use the Strategy Pattern. This is a standard design pattern where a family of algorithms is defined behind a common interface, so the code that uses them (Vehicle) doesn't need to know which one it's running.

## 2.1 The Three Roles

| Pattern Role       | In This Project                                                                                                            |
|--------------------|----------------------------------------------------------------------------------------------------------------------------|
| Strategy Interface | DrivingModel ABC / Filter ABC / BaseSensor ABC / EgoSensor ABC etc.                                                        |
| Concrete Strategy  | IDMHumanModel, IDMModel, CACCModel, Wiedemann99Model (plugin), KalmanFilter, PassthroughSensor, PassthroughEgoSensor, etc. |
| Context            | Vehicle (holds a reference to a model, a filter, and sensor/comms/ego sensor objects)                                      |

The Vehicle never contains if/elif logic to choose behaviour. It just calls `self.model.compute(...)` and gets back a `DrivingModelOutput`. Swapping in a different model requires no changes to Vehicle.

## 2.2 The Abstract Base Class

The ABC enforces the contract at object-creation time rather than mid-simulation:

```python
from abc import ABC, abstractmethod

class DrivingModel(ABC):
    @abstractmethod
    def compute(self, state: VehicleState) -> DrivingModelOutput: ...

    @classmethod
    @abstractmethod
    def required_inputs(cls) -> set[str]: ...
```

If a subclass forgets to implement `compute()`, Python raises `TypeError` immediately when you try to instantiate it — not later in the simulation loop.

## 2.3 Variable Inputs — the VehicleState Approach

Different models need different inputs (IDM needs gap and speed; CACC also needs V2V data). Rather than using loose `**kwargs` dicts, the preferred approach is a shared state dataclass with optional fields:

```python
@dataclass
class VehicleState:
    # ── Ego vehicle (universal) ─────────────────────────────────────
    speed:              float
    acceleration:       float           # current actual acceleration (m/s²)
    time:               float           # simulation time (s)
    position:           float           # position (m) — for gap derivation if needed

    # ── Immediately preceding vehicle (universal) ───────────────────
    gap:                float           # bumper-to-bumper gap (m)
    lead_speed:         float           # speed of immediately preceding vehicle (m/s)
    lead_acceleration:  float = 0.0     # acceleration of preceding vehicle (m/s²)
                                        # Gipps estimates this; CACC gets it from BSM
    lead_max_decel:     float | None = None  # Gipps only: assumed b̂ of leader (m/s²)

    # ── V2V / BSM fields (CACC and variants) ───────────────────────
    v2v_lead_accel:     float | None = None  # feedforward accel from BSM (m/s²)
    v2v_lead_brake_status: bool | None = None  # hard-braking flag from BSM
    v2v_bsm_age_s:      float | None = None  # age of most recent BSM (s)

    # ── Platoon leader fields (predecessor-leader topology) ─────────
    leader_speed:       float | None = None  # platoon leader speed (m/s)
    leader_acceleration: float | None = None  # platoon leader accel (m/s²)

    # ── Context ─────────────────────────────────────────────────────
    is_string_leader:   bool = False    # True if this vehicle leads the platoon
    driving_mode:       object = None   # DrivingMode enum, if mode switching active

    # ── Escape hatch ────────────────────────────────────────────────
    extras:             dict = field(default_factory=dict)
```

Design notes on VehicleState:

-   `lead_a_v2v: float = 0.0` — lead vehicle acceleration from BSM, used by CACC feedforward. Defaults to `0.0` so that `k_ff * 0.0 = 0` when BSM is unavailable — natural graceful degradation, no `None` check needed.
-   `lead_a_radar: float = 0.0` — Kalman-estimated lead acceleration from the radar pipeline, for future EIDM/CAH; always `0.0` in Step 16 (PassthroughFusionEstimator).
-   `second_predecessor_*` fields are left out of the top-level struct — they go in `extras` since they're research-territory that the built-in models don't use.
-   The `acceleration` field represents the *measured* acceleration (from EgoSensor), not the true plant acceleration. The BSM broadcasts this measured value, so IMU noise propagates into the feedforward term of following vehicles — physically correct and one reason the string stability condition is more conservative in practice than theory predicts.

>   📝 **Note:** This is better than `**kwargs` because the IDE can autocomplete field names, typos raise AttributeError rather than silently passing None, and the full input space is documented in one place.

***

# 3. Vehicle Response Model

The VehicleResponseModel sits between the driving model's commanded acceleration and the actual acceleration integrated by the vehicle plant. It captures the fact that real vehicles cannot instantaneously change acceleration. This is the minimum fidelity for realistic ACC/CACC modelling — without it, string stability results are optimistic.

## 3.1 Why It Matters

| Fidelity level                     | Description                                       | Use case                        |
|------------------------------------|---------------------------------------------------|---------------------------------|
| Level 1 — Kinematic                | Commanded acceleration applied instantly          | Quick prototyping only          |
| Level 2 — 1st-order lag ✅         | Low-pass filter on acceleration (tau ≈ 0.3–0.5 s) | ACC/CACC research — recommended |
| Level 3 — Throttle/brake asymmetry | Separate tau for throttle vs. brake + deadband    | Fuel/comfort studies            |
| Level 4+ — Full powertrain         | Engine torque curve, transmission, drag           | Out of scope                    |

## 3.2 Implementation

```python
class VehicleResponseModel:
    def __init__(self,
                 tau_throttle = 0.5,
                 tau_brake    = 0.3,
                 deadband     = 0.05,
                 crr          = 0.012,    # rolling resistance coefficient
                 k_aero       = 1.76e-4,  # aero drag: 0.5 * Cd * A * rho / m
                 a_max        = 2.5,
                 a_min        = -8.0,
                 j_max        = 5.0,
                 dt           = 0.01):
        ...

    def step(self, a_commanded, v_ego) -> float:
        a_sat = clip(a_commanded, self.a_min, self.a_max)
        if a_sat > self.deadband:
            tau = self.tau_throttle
        elif a_sat < -self.deadband:
            tau = self.tau_brake
        else:
            tau   = 0.1
            a_sat = -(self.crr * 9.81 + self.k_aero * v_ego ** 2)
        a_target = (self.dt / tau) * (a_sat - self.a_actual)
        j_lim = self.j_max * self.dt
        a_target = clip(a_target, -j_lim, j_lim)
        self.a_actual += a_target
        return clip(self.a_actual, self.a_min, self.a_max)
```

**Passive drag model** — the deadband coasting target uses a physically correct two-term formula:

```
a_drag(v) = -(crr * g + k_aero * v²)
```

| Term          | Meaning                                   | Dominates at  |
|---------------|-------------------------------------------|---------------|
| `crr * g`     | Rolling resistance (tyre + road friction) | Low speed     |
| `k_aero * v²` | Aerodynamic drag                          | Highway speed |

`k_aero = 0.5 * Cd * A * rho / m`. Default values (car): `Cd=0.3`, `A=2.2 m²`, `rho=1.2 kg/m³`, `m=1500 kg` → `k_aero ≈ 1.76×10⁻⁴ m⁻¹`. Trucks have larger frontal area and different `Cd`; `crr` and `k_aero` can be set per vehicle type. A linear drag model (proportional to v) overstates drag by 2–3× at 30 m/s and is not used.

>   📝 **Note:** tau_throttle, tau_brake, a_max, a_min, and j_max are all per-vehicle parameters in the vehicles sheet, with global defaults in the simulation sheet. This supports mixed fleets (e.g. cars and trucks) where these values differ meaningfully by vehicle type.

## 3.3 Vehicle Plant Integration

```python
class VehiclePlant:
    def __init__(self, x0, v0, length, dt=0.01):
        self.x, self.v, self.length, self.dt = x0, v0, length, dt

    def step(self, a_actual):
        self.v = max(0.0, self.v + a_actual * self.dt)
        self.x += self.v * self.dt
        return self.x, self.v

    def gap_to(self, leader: 'VehiclePlant') -> float:
        """Gap = leader rear bumper - ego front bumper."""
        return leader.x - self.x - leader.length
```

***

# 4. Driving Model Design

## 4.1 Base Class and Output

```python
@dataclass
class DrivingModelOutput:
    acceleration: float  # m/s^2
    # extend here if models produce other common outputs

class DrivingModel(ABC):
    @abstractmethod
    def compute(self, state: VehicleState) -> DrivingModelOutput: ...
```

## 4.2 Concrete Model Examples

The four built-in models are `IDMHumanModel`, `IDMModel`, `CACCModel`, and `LeadVehicleModel`. All are subclasses of DrivingModel and are registered by name. Additional models (e.g. Wiedemann) ship as plugins — see [Section 12](#12-plugin-system).

```python
class IDMHumanModel(DrivingModel):
    """IDM with perceived-quantity reaction time delay. Represents a human driver.

    Only gap, lead_speed, and lead_acceleration are delayed — the driver's
    perception of the vehicle ahead.  Ego speed (known from speedometer /
    proprioception) is always current.  On first call the buffer is seeded with
    the initial perceived quantities so there is no startup transient.
    """
    def __init__(self, desired_speed, time_headway, reaction_time=0.8,
                 s0=2.0, a_max=1.5, b=2.0, delta=4.0, a_min=-6.0, dt=0.01):
        ...
        self._delay  = DelayBuffer(reaction_time, dt)
        self._seeded = False

    def compute(self, state: VehicleState) -> DrivingModelOutput:
        perceived = (state.gap, state.lead_speed, state.lead_acceleration)
        if not self._seeded:
            self._delay.fill(perceived)   # seed so first call has no transient
            self._seeded = True
        gap, lead_speed, _ = self._delay.push_and_read(perceived)
        # IDM formula: current ego speed, delayed perceived quantities
        return DrivingModelOutput(acceleration=_idm_accel(
            state.speed, gap, lead_speed, ...
        ))

class IDMModel(DrivingModel):
    """Intelligent Driver Model — no reaction delay (ACC sensor replaces perception)."""
    def __init__(self, desired_speed: float, time_headway: float, ...):
        self.v0 = desired_speed
        self.T  = time_headway
        ...
    def compute(self, state: VehicleState) -> DrivingModelOutput:
        # IDM formula using state.speed, state.gap, state.lead_speed
        ...

class CACCModel(DrivingModel):
    """CACC with V2V feedforward acceleration term."""
    def compute(self, state: VehicleState) -> DrivingModelOutput:
        if state.v2v_lead_accel is None:
            raise ValueError('CACC requires V2V data')
        # CACC formula: PI feedback + k_ff * v2v_lead_accel
        ...

class LeadVehicleModel(DrivingModel):
    """Follows a time-triggered speed profile. Not a car-following model."""
    def __init__(self, profile: LeadVehicleProfile, kp: float = 0.5):
        self.profile = profile
        self.kp = kp
    def compute(self, state: VehicleState) -> DrivingModelOutput:
        target   = self.profile.get_speed_target(state.time)
        accel    = self.kp * (target - state.speed)
        return DrivingModelOutput(acceleration=clip(accel, -4.0, 2.0))
```

## 4.3 The time_headway Question

Whether time_headway is a per-vehicle input depends on modeling philosophy:

| Framing                                         | Implication                                                     |
|-------------------------------------------------|-----------------------------------------------------------------|
| Behavioral parameter (IDMHumanModel / IDMModel) | Varies by driver — belongs in Excel per-vehicle row             |
| Control output (CACC algorithm)                 | Computed internally — should NOT be a user input                |
| Fixed system policy                             | Same for all CACC vehicles — belongs in global parameters sheet |

>   ✅ **Decided:** For IDMHumanModel and IDMModel, time_headway is a per-vehicle behavioral parameter in the vehicles sheet. For CACC, the algorithm enforces a target headway as a design parameter in the simulation sheet, not per-vehicle.

***

# 5. Filter Design

Filters follow the same Strategy Pattern as driving models, with the same VehicleState-style input approach.

## 5.1 Base Classes

```python
@dataclass
class FilterInput:
    timestamp:      float
    raw_value:      float
    # optional extended fields:
    gps_covariance: float | None = None
    extras:         dict  = field(default_factory=dict)

@dataclass
class FilterOutput:
    filtered_value: float
    confidence:     float

class Filter(ABC):
    @abstractmethod
    def update(self, input: FilterInput) -> FilterOutput: ...

    @classmethod
    def required_fields(cls)  -> set[str]: return set()

    @classmethod
    def required_extras(cls)  -> set[str]: return set()
```

## 5.2 Adding a Custom Filter

A user adding a new filter type with non-standard inputs:

-   Subclasses Filter and implements `update()`
-   Declares `required_extras()` listing the keys it needs in `input.extras`
-   Drops the file in the plugins folder — the registry picks it up automatically
-   Populates `input.extras` with those keys before calling `update()`

No changes to FilterInput, Filter, or the simulation loop are needed.

## 5.3 IIR Filter Alpha Values

The IIR low-pass filter alpha parameter is timestep-dependent and must be derived from a desired cutoff frequency, not copied from other implementations. With a 0.01 s timestep:

```python
def alpha_from_cutoff(f_cutoff_hz, dt):
    """Convert desired cutoff frequency to IIR alpha for given timestep."""
    omega = 2 * np.pi * f_cutoff_hz
    tau   = 1 / omega
    return dt / (tau + dt)

# Example: 2 Hz cutoff at 0.01 s timestep
alpha = alpha_from_cutoff(2.0, 0.01)   # → 0.111
# The same 2 Hz cutoff at 0.1 s would give alpha ≈ 0.556 — very different!
```

>   📝 **Note:** Never copy alpha values from examples designed for a different timestep. Always derive from physical cutoff frequency.

## 5.4 Startup Validation

Because both models and filters declare their requirements, you can validate the full configuration before the simulation starts:

```python
def validate_filter(f: Filter, available_extras: set[str]):
    missing = f.required_extras() - available_extras
    if missing:
        raise ValueError(f'{type(f).__name__} needs: {missing}')
```

>   📝 **Note:** Fail fast at startup with a descriptive error rather than a cryptic KeyError 200 steps into a run.

***

# 6. Sensor, Comms, and Fusion Architecture

Sensor modelling (radar noise, delay), V2V comms (BSM delivery), and sensor fusion are the most complex subsystems. The architectural decision is to build them as proper ABCs from the start, but start with passthrough implementations that assume perfect sensing and perfect communications. This allows the control laws to be validated under ideal conditions first, then each layer of realism can be added independently.

## 6.1 Abstract Base Classes

```python
class BaseSensor(ABC):
    @abstractmethod
    def step(self, true_gap: float, true_gap_rate: float
             ) -> tuple[float, float, float, float]: ...
    # returns (gap_meas, rate_meas, gap_filtered, rate_filtered)

class BaseFusionEstimator(ABC):
    @abstractmethod
    def step(self, gap_f: float, rate_f: float,
             lead_a_v2v: float) -> tuple[float, float, float]: ...
    # returns (gap_fused, rate_fused, lead_a_radar)

class BaseBSMTracker(ABC):
    @abstractmethod
    def update(self, leader_accel: float) -> None: ...
    @property
    @abstractmethod
    def is_valid(self) -> bool: ...
    @property
    @abstractmethod
    def acceleration(self) -> float: ...

class BaseEgoSensor(ABC):
    @abstractmethod
    def step(self, true_speed: float, true_accel: float
             ) -> tuple[float, float]: ...
    # returns (speed_meas, accel_meas)
```

## 6.2 Passthrough and Realistic Implementations

```python
class PassthroughSensor(BaseSensor):
    """Perfect measurement — no noise, no delay."""
    def step(self, true_gap, true_gap_rate):
        return true_gap, true_gap_rate, true_gap, true_gap_rate

class RadarSensor(BaseSensor):
    """70 ms delay + AR(1) noise (σ=0.3 m, ρ=0.8) + Kalman or LPF filter."""
    def step(self, true_gap, true_gap_rate):
        ...  # see sensors.py

class PassthroughFusionEstimator(BaseFusionEstimator):
    """Pass filtered state directly; lead_a_radar always 0.0 (Step 16)."""
    def step(self, gap_f, rate_f, lead_a_v2v):
        return gap_f, rate_f, 0.0

class PassthroughBSMTracker(BaseBSMTracker):
    """Perfect V2V — stores and returns leader acceleration with no delay."""
    def update(self, leader_accel): self._accel = leader_accel
    @property
    def is_valid(self): return True
    @property
    def acceleration(self): return self._accel

class PassthroughEgoSensor(BaseEgoSensor):
    def step(self, true_speed, true_accel): return true_speed, true_accel

class NoisyEgoSensor(BaseEgoSensor):
    """Speed white noise + IMU bias drift + acceleration noise."""
    ...  # see sensors.py
```

## 6.3 Configuration and Passthrough Bypass

The active implementations are selected via `sensor_model` in the Excel simulation sheet. When `sensor_model = 'passthrough'`, `Vehicle.step()` bypasses all sensor objects entirely — no instances are created, no floating-point operations beyond the plant's own output. When `sensor_model = 'kalman'` or `'lpf'`, the full pipeline runs.

| Config value               | Implementation                                         | Future replacement                                          |
|----------------------------|--------------------------------------------------------|-------------------------------------------------------------|
| sensor_model = passthrough | Direct plant readout in Vehicle.step() — no objects    | —                                                           |
| sensor_model = kalman      | RadarSensor (delay+AR noise+KF) + NoisyEgoSensor       | LIDAR fusion, range-dependent noise σ(r)                    |
| sensor_model = lpf         | RadarSensor (delay+AR noise+LPF) + NoisyEgoSensor      | —                                                           |
| comms_model = passthrough  | PassthroughBSMTracker — perfect V2V, zero delay        | —                                                           |
| comms_model = dsrc         | DSRCBSMTracker — 10 Hz, per-packet drop, stale timeout | Higher drop rates, range-dependent packet loss              |
| fusion = passthrough       | PassthroughFusionEstimator — lead_a_radar always 0.0   | —                                                           |
| fusion = dsrc (via comms)  | FusionKalmanFilter — 3-state multi-rate radar + BSM KF | LIDAR fusion, platoon-level state                           |

Per-vehicle RNG is derived deterministically from `master_seed` (SimConfig, default 0, override via `--seed N`) using XOR with per-vehicle and per-process offsets (`cacc_sim/rng.py`). Seed metadata is recorded in the YAML output.

VehicleState carries two distinct lead-acceleration fields:
- `lead_a_v2v: float = 0.0` — from BSM, used by CACC feedforward; 0.0 when BSM unavailable (natural graceful degradation)
- `lead_a_radar: float = 0.0` — Kalman-estimated from radar, for future EIDM/CAH; always 0.0 in Step 16

>   📝 **Note:** Running with passthroughs is not just a shortcut — it establishes ideal-condition baselines. The progression passthrough → sensor noise → delay → comms dropout → full fusion is itself a meaningful sensitivity study.

## 6.4 Radar Sensor Model (Implemented — cacc_sim/sensors.py)

When sensors are moved beyond passthrough, the radar/lidar measures two quantities continuously: **range** (gap to preceding vehicle's rear) and **range rate** (relative velocity). From these the controller derives gap error and relative velocity. Everything else — lead vehicle acceleration, platoon state — comes from V2V, not the sensor.

Three effects need to be modeled:

**1. Detection delay** — Fixed processing latency (50–100 ms for automotive radar), modeled as a FIFO buffer:

```python
from collections import deque

class DelayBuffer:
    """
    Fixed-length FIFO that delays a signal by approximately delay_s seconds.

    push_and_read(value) inserts the new value at the front and returns the
    value from (n − 1) steps ago, where n = max(1, round(delay_s / dt)).
    Effective delay is therefore (n − 1) * dt ≈ delay_s − dt, which is
    negligible at typical reaction times (0.5–1.5 s) and dt = 0.01 s.

    All slots initialise to None.  Call fill(seed) before first use to avoid
    a None-valued startup transient (IDMHumanModel does this automatically).
    With n = 1 (delay_s < dt) the value is returned immediately (zero delay).
    """
    def __init__(self, delay_s: float, dt: float = 0.01) -> None:
        n = max(1, round(delay_s / dt))
        self._buf = deque([None] * n, maxlen=n)

    def push_and_read(self, value):
        self._buf.appendleft(value)
        return self._buf[-1]

    def fill(self, value) -> None:
        """Replace every slot with value (seed before first push)."""
        n = self._buf.maxlen
        self._buf.clear()
        self._buf.extend([value] * n)
```

**2. Measurement noise** — Zero-mean Gaussian, but with temporal correlation (AR(1) structure):

-   Range noise σ_d ≈ 0.1–0.5 m (better for FMCW radar, worse for pulsed)
-   Range-rate noise σ_ḋ ≈ 0.05–0.2 m/s (Doppler is quite accurate)
-   Noise is correlated across timesteps — ρ ≈ 0.7–0.9; correlated noise persists and can bias the gap estimate for hundreds of ms

```python
class ARNoise:
    """First-order autoregressive noise: x[k] = rho*x[k-1] + sigma*sqrt(1-rho²)*w[k]"""
    def __init__(self, sigma, rho=0.7):
        self.sigma = sigma
        self.rho = rho
        self.state = 0.0
    def sample(self):
        self.state = (self.rho * self.state +
                      self.sigma * np.sqrt(1 - self.rho**2) * np.random.randn())
        return self.state
```

Range-dependent nonlinearity: at long range (\>100 m), noise variance increases: σ_d(r) = σ₀ · (1 + r/r_ref) where r_ref ≈ 100 m.

**3. Filtering** — Three switchable levels:

-   **Moving average** — simplest, fixed group delay = half the window length
-   **Low-pass filter (1st-order IIR)** — most common real-world implementation; α controls noise rejection vs. lag tradeoff
-   **Kalman filter** — optimal fusion for the 1D case; state is [gap, gap_rate], standard linear KF (not EKF); provides smooth gap_rate estimate even though radar only directly measures range

```python
class SensorModel:
    """Full sensor pipeline: true value → delay → noise → filter → estimated value"""
    def __init__(self, delay_s, dt, noise_sigma=0.3, noise_rho=0.7,
                 filter_type="kalman"):
        self.delay  = DelayBuffer(delay_s, dt)
        self.noise  = ARNoise(sigma=noise_sigma, rho=noise_rho)
        if filter_type == "kalman":
            self.filter = GapKalmanFilter(dt, sigma_obs=noise_sigma)
        elif filter_type == "lpf":
            self.filter = LowPassFilter(alpha=0.7)
        else:
            self.filter = None

    def step(self, true_gap, true_gap_rate):
        delayed = self.delay.push_and_read(true_gap)
        if delayed is None:
            return true_gap, true_gap_rate
        noisy = delayed + self.noise.sample()
        if isinstance(self.filter, GapKalmanFilter):
            self.filter.predict()
            est_gap, est_gap_rate = self.filter.update(noisy)
        elif isinstance(self.filter, LowPassFilter):
            est_gap      = self.filter.update(noisy)
            est_gap_rate = (est_gap - self._prev_gap) / self.dt
            self._prev_gap = est_gap
        else:
            est_gap, est_gap_rate = noisy, true_gap_rate
        return est_gap, est_gap_rate
```

## 6.5 Ego Vehicle State Sensor (EgoSensor)

The ego vehicle's own state measurements also have noise, distinct from the radar/lidar:

**Speed** — from wheel speed sensors (ABS encoders). Quantization noise (\~0.1–0.5 km/h at low speeds) and wheel slip error on acceleration/braking. GPS-derived speed is accurate to \~0.1 m/s but has latency (100–200 ms). Model as low-amplitude white noise (σ ≈ 0.05–0.1 m/s).

**Acceleration** — from IMU (accelerometer). Bias drift (slowly varying DC offset, dominant MEMS error), vibration noise (high-frequency, filtered), and gravity coupling on grades (\~0.1 m/s² per 1% grade). This matters for CACC because the BSM acceleration field comes from the ego IMU, so IMU noise propagates into the feedforward term of following vehicles.

**Position** — integrated from speed, so it inherits speed noise rather than accumulating independent noise. GPS absolute position noise (\~1–3 m consumer, \~0.1 m RTK) mostly cancels in gap calculations since both vehicles have similar errors.

```python
class EgoSensor:
    """
    Models imperfection in ego vehicle's own state measurements.
    Speed: wheel encoder quantization + small white noise
    Acceleration: IMU bias drift + vibration noise
    Position: integrated from speed (no independent noise by default)
    """
    def __init__(self, speed_sigma=0.05, accel_bias_drift=0.02,
                 accel_noise_sigma=0.08, dt=0.01):
        self._accel_bias = 0.0
        self.speed_sigma = speed_sigma
        self.accel_bias_drift = accel_bias_drift
        self.accel_noise_sigma = accel_noise_sigma
        self.dt = dt

    def step(self, true_speed, true_accel) -> tuple[float, float]:
        noisy_speed = true_speed + np.random.normal(0, self.speed_sigma)
        noisy_speed = max(0.0, noisy_speed)
        self._accel_bias += np.random.normal(0, self.accel_bias_drift * self.dt)
        noisy_accel = true_accel + self._accel_bias + \
                      np.random.normal(0, self.accel_noise_sigma)
        return noisy_speed, noisy_accel

class PassthroughEgoSensor(EgoSensor):
    """Perfect ego state — no noise. Initial implementation."""
    def step(self, true_speed, true_accel):
        return true_speed, true_accel
```

## 6.6 DSRC/C-V2X BSM Channel Model (DSRCBSMTracker)

Activated when `comms_model = 'dsrc'` in the simulation sheet.

**BSM content:** The BSM carries the leader's ego-measured acceleration, not the true plant value. `Vehicle` stores `_last_a_meas` each step so that following vehicles' BSM trackers read the realistic (noisy) IMU output.

**Packet timing:** BSMs are broadcast every `bsm_interval_steps = round(1 / (bsm_rate_hz * dt))` steps (default 10 steps = 100 ms). Each vehicle has a randomised phase offset `rng.randint(0, interval_steps - 1)` seeded from `vehicle_rng(master_seed, vid, 'bsm_phase')`, ensuring staggered broadcasts — a more representative model of DSRC slot access. The phase offset is logged in `metadata.yaml` for reproducibility.

**Packet drop:** Each broadcast is independently dropped with probability `bsm_packet_drop_rate` (default 0.05), using RNG from `vehicle_rng(master_seed, vid, 'bsm_comms')`.

**Age and validity:** `age_s` tracks seconds since the last received packet. When `age_s ≥ bsm_max_age_s` (default 0.2 s), `is_valid` becomes False and `acceleration` returns 0.0 — graceful degradation to pure feedback exactly as designed.

>   ✅ **Decided:** `comms_model='dsrc'` activates both `DSRCBSMTracker` and `FusionKalmanFilter` together — the fusion KF has no purpose without BSM data. Running `comms_model='passthrough'` with `sensor_model='kalman'` gives the radar-only baseline for comparison.

## 6.7 Multi-Rate Fusion Kalman Filter (FusionKalmanFilter)

Activated with `comms_model = 'dsrc'`. Fuses radar (100 Hz) and BSM (10 Hz) into a single 3-state estimate.

**State:** `x = [gap, gap_rate, a_lead]ᵀ`

**State transition** with ego acceleration as a known input `u = a_ego`:

```
F = [[1, dt, ½dt²],     B = [−½dt²,
     [0,  1,    dt],         −dt,
     [0,  0,     1]]          0]
```

`x[k+1] = F @ x[k] + B * a_ego[k]`

**Observation model:**

| Source | Rate | H | R |
|--------|------|---|---|
| Radar | 100 Hz (every step) | `[[1,0,0],[0,1,0]]` | `diag(σ_gap², σ_rate²)` |
| BSM | 10 Hz (fresh packet only, `bsm_age_s < dt`) | `[[0,0,1]]` | `σ_bsm_a²` |

BSM R is derived from ego sensor parameters to maintain internal consistency:
```
σ_bsm_a² = accel_noise_sigma² + accel_bias_drift² × dt × bsm_interval_s
```
The second term is the variance accumulated by the IMU bias random walk between consecutive packets.

**Q matrix:**

```python
Q = diag([0,
          (sigma_q_rate × dt)²,   # gap_rate: unmodeled disturbances (default σ=0.3 m/s²)
          (j_max × dt)²])         # a_lead: jerk-bounded (default j_max=5 m/s³)
```

`Q[2,2] = (j_max × dt)²` anchors the a_lead process noise to the physical jerk limit. `Q[1,1]` is larger than the radar-only KF's value to absorb unmodeled disturbances (road grade, drag variation) that the explicit a_lead state does not capture.

**Multi-rate update protocol** each sim step:
1. Predict with F, B, Q.
2. Always apply radar measurement update (H_r, R_r).
3. If `bsm_age_s < dt` (packet received this step): apply BSM scalar update (h_b, R_b).
4. Return `(gap_fused, rate_fused, lead_a_radar)`.

`lead_a_radar = x[2]` is now populated non-zero, available to future EIDM/CAH models via `VehicleState.lead_a_radar`. CACC continues to use `lead_a_v2v` (the raw BSM value, 0.0 on dropout) for its feedforward term — the two fields remain distinct by design.

***

# 7. ACC / CACC Longitudinal Controller

The longitudinal controller converts the fused state estimate (gap, gap_rate, lead_accel) into a commanded acceleration. It is the mathematical core of the simulation. Three levels of sophistication are supported as switchable options.

## 7.1 The Constant Time Headway (CTH) Policy

Every ACC/CACC control law is built on the same desired-gap equation:

```
d*(v) = s0 + tau * v

where:
  s0  = standstill gap (m)        — minimum gap at v = 0
  tau = time headway (s)           — 1.4 s for ACC, 0.6 s for CACC
  v   = ego vehicle speed (m/s)

Gap error and relative velocity (the two controller inputs):
  e_gap = gap - d*(v_ego)          — positive = too much gap
  e_vel = v_leader - v_ego         — positive = leader pulling away
```

>   📝 **Note:** The 0.6 s CACC headway and 1.4 s ACC headway are system-level design parameters in the simulation sheet, not per-vehicle inputs. At headways below \~0.6 s, sensor imperfections dominate the error budget and string stability degrades — this is the canonical minimum from PATH field tests.

## 7.2 Level 1 — PI Controller (ACC)

Simple proportional-integral control on gap error plus a proportional term on relative velocity. The standard structure for production ACC systems and the baseline for this simulation.

```python
class PIController:
    """
    PI controller on gap error + proportional term on relative velocity.
    Standard structure for ACC. Used when BSM is unavailable.
    """
    def __init__(self, kp=0.4, ki=0.1, kd_rdv=0.5,
                 headway=1.4, s0=2.0,
                 a_max=2.0, a_min=-3.0,
                 integrator_limit=2.0, dt=0.01):
        self.kp = kp
        self.ki = ki
        self.kd = kd_rdv      # gain on relative velocity
        self.hw = headway
        self.s0 = s0
        self._integral = 0.0
        ...

    def desired_gap(self, v_ego):
        return self.s0 + self.hw * v_ego

    def step(self, gap, v_ego, v_leader) -> float:
        e_gap = gap - self.desired_gap(v_ego)
        e_vel = v_leader - v_ego
        # Anti-windup: only integrate when not saturated
        self._integral = clip(self._integral + e_gap * self.dt,
                              -self.integrator_limit, self.integrator_limit)
        a_cmd = self.kp * e_gap + self.ki * self._integral + self.kd * e_vel
        return clip(a_cmd, self.a_min, self.a_max)
```

## 7.3 Level 2 — CACC Controller with V2V Feedforward

The defining feature of CACC versus ACC is a **feedforward term on the lead vehicle's acceleration** from the BSM. This allows the follower to anticipate rather than react, which is what enables string-stable following at 0.6 s headway. Without it, pure feedback ACC amplifies disturbances as they propagate back through the string.

```python
class CACCController:
    """
    CACC controller: PI feedback on gap error + feedforward on lead accel.
    Based on PATH / Milanes & Shladover (2014) structure.
    k_ff * a_lead is the defining term that distinguishes CACC from ACC.
    """
    def __init__(self, k1=0.45, k2=0.25, k_ff=0.90,
                 headway=0.6, s0=2.0,
                 a_max=2.0, a_min=-4.0, dt=0.01):
        # k_ff=0.90 gives a string-stability margin at default headway (k_ff + k2*T_h = 1.05).
        # The PATH field-test value k_ff=0.45 is marginally unstable at 0.6 s
        # headway — set it deliberately to study instability, not as a default.
        self.k1   = k1      # gain on gap error
        self.k2   = k2      # gain on relative velocity
        self.k_ff = k_ff    # feedforward gain on lead acceleration
        self.hw   = headway
        self.s0   = s0
        ...

    def desired_gap(self, v_ego):
        return self.s0 + self.hw * v_ego

    def step(self, gap, v_ego, v_leader, a_leader,
             bsm_valid=True) -> float:
        e_gap = gap - self.desired_gap(v_ego)
        e_vel = v_leader - v_ego
        a_fb  = self.k1 * e_gap + self.k2 * e_vel   # feedback (same as ACC)
        a_ff  = self.k_ff * a_leader if bsm_valid else 0.0  # feedforward
        return clip(a_fb + a_ff, self.a_min, self.a_max)
```

When BSM is unavailable (`bsm_valid=False`), the feedforward term drops to zero and the controller degrades gracefully to pure ACC-style feedback behaviour — no mode switch required.

## 7.4 String Stability Condition

For the CACC controller above, the string stability condition (disturbance does not amplify as it propagates back through the platoon) requires:

```
Simplified condition (implementation uses): k_ff + k2 * T_h >= 1

With the default gains (k1=0.45, k2=0.25, k_ff=0.90) and T_h=0.6 s:
  0.90 + 0.25 * 0.6 = 0.90 + 0.15 = 1.05  ✓  string-stable (margin above boundary)

The PATH field-test value k_ff=0.45 gives:
  0.45 + 0.25 * 0.6 = 0.45 + 0.15 = 0.60  <  1.0  ← string-unstable at 0.6 s headway
```

>   📝 **Note:** The PATH-calibrated value k_ff=0.45 (Milanes & Shladover 2014) was derived at a different headway than the 0.6 s default used here. It is preserved in the comments as a reference point for studying instability — deliberately not the simulation default. The `CACCController.__init__()` warning fires whenever `k_ff + k2*T_h < 1`, which remains the correct safety net for any gain combination.

## 7.5 Level 3 — MPC Controller (Optional)

A Model Predictive Controller optimises a sequence of accelerations over a receding horizon, handling acceleration and jerk constraints naturally. It is architecturally cleaner for headway-expansion transitions (e.g. CACC→ACC fallback) because you simply change the desired-gap constraint and the optimiser finds the smooth trajectory. Included as a switchable option but not the default due to computational cost.

| Controller     | Config value      | Best for                                                                  |
|----------------|-------------------|---------------------------------------------------------------------------|
| PIController   | controller = pi   | ACC operation; simple, robust, easy to tune                               |
| CACCController | controller = cacc | CACC operation; feedforward requires valid BSM                            |
| MPCController  | controller = mpc  | Constraint-aware scenarios; headway expansion; research into jerk comfort |

***

# 8. Mode Switch Logic

Mode switching governs which control law is active at any moment. For the initial implementation, each vehicle has a fixed driving model for the full run (no runtime switching). This section documents the full FSM architecture that is the intended future evolution, so the class interfaces can be designed correctly from the start even if the logic is initially stubbed out.

>   ✅ **Decided:** Initial implementation: no runtime mode switching. Each vehicle's model is fixed at load time. The FSM below is future scope.

## 8.1 The State Machine

Four states with well-defined, asymmetric transition conditions:

```
MANUAL ──────────────────────────────────────────► MANUAL
   │  ▲                                               ▲
   │  │ driver override                   driver override
   ▼  │                                               │
  ACC ──── comms confirmed + headway OK ──────────► CACC
   ▲  │                                            │
   │  └──── comms lost / non-CV ahead ◄───────────┘
   │
   └──── driver override

Key asymmetry:
  INTO CACC:  requires positive confirmation (comms established,
              valid BSM received, headway >= min_cacc_headway)
  OUT OF CACC: defensive — any doubt falls back to ACC, not MANUAL
```

## 8.2 ModeSwitchLogic Class

```python
from enum import Enum, auto

class DrivingMode(Enum):
    MANUAL = auto()
    ACC    = auto()
    CACC   = auto()

class ModeSwitchLogic:
    def __init__(self,
                 comms_timeout_s  = 0.5,
                 min_cacc_headway = 0.6,
                 hysteresis_s     = 1.0,
                 dt               = 0.01):
        self.mode = DrivingMode.MANUAL
        self._comms_good_timer = 0.0
        self._comms_lost_timer = 0.0
        ...

    def step(self, driver_override, acc_engaged,
             bsm_received, bsm_age_s,
             current_speed, current_gap) -> DrivingMode:
        comms_ok = bsm_received and bsm_age_s < self.comms_timeout_s
        if comms_ok:
            self._comms_good_timer += self.dt
            self._comms_lost_timer  = 0.0
        else:
            self._comms_lost_timer  += self.dt
            self._comms_good_timer   = 0.0
        comms_confirmed = self._comms_good_timer >= self.hysteresis_s
        comms_lost      = self._comms_lost_timer  >= self.comms_timeout_s
        desired_hw = current_gap / current_speed if current_speed > 1.0 else 99.0

        if self.mode == DrivingMode.MANUAL:
            if acc_engaged and not driver_override:
                self.mode = DrivingMode.ACC
        elif self.mode == DrivingMode.ACC:
            if driver_override:
                self.mode = DrivingMode.MANUAL
            elif comms_confirmed and desired_hw >= self.min_cacc_headway:
                self.mode = DrivingMode.CACC
        elif self.mode == DrivingMode.CACC:
            if driver_override:
                self.mode = DrivingMode.MANUAL
            elif comms_lost:
                self.mode = DrivingMode.ACC
        return self.mode
```

## 8.3 Bumpless Transfer

```python
class BumplessTransfer:
    def __init__(self, ramp_time_s=1.0, dt=0.01):
        self.ramp_time = ramp_time_s
        self._blending = False
        self._timer    = 0.0
        self._a_from   = 0.0

    def trigger(self, a_outgoing):
        self._blending = True
        self._timer    = 0.0
        self._a_from   = a_outgoing

    def blend(self, a_new) -> float:
        if not self._blending: return a_new
        alpha = min(self._timer / self.ramp_time, 1.0)
        self._timer += self.dt
        if alpha >= 1.0:
            self._blending = False
            return a_new
        return (1.0 - alpha) * self._a_from + alpha * a_new
```

## 8.4 CACC→ACC Fallback: Headway Expansion

```python
class CACCtoACCFallback:
    """
    When CACC falls back to ACC, gradually expand target headway
    from CACC setpoint (0.6 s) to ACC setpoint (1.4 s).
    Without this, a platoon losing comms simultaneously produces
    a cascade of hard braking events.
    """
    def __init__(self, cacc_headway=0.6, acc_headway=1.4,
                 expand_rate=0.1, dt=0.01):
        self.cacc_hw     = cacc_headway
        self.acc_hw      = acc_headway
        self.expand_rate = expand_rate
        self._current_hw = cacc_headway
        self._expanding  = False

    def trigger_fallback(self):
        self._expanding  = True
        self._current_hw = self.cacc_hw

    def get_headway(self) -> float:
        if self._expanding:
            self._current_hw = min(
                self._current_hw + self.expand_rate * self.dt,
                self.acc_hw)
            if self._current_hw >= self.acc_hw:
                self._expanding = False
        return self._current_hw
```

## 8.5 VehicleController Coordinator (Future)

```python
class VehicleController:
    """
    Coordinates mode FSM, bumpless transfer, fallback headway,
    and controller selection. Future scope — not in initial build.
    """
    def __init__(self, dt=0.01):
        self.mode_fsm    = ModeSwitchLogic(dt=dt)
        self.bumpless    = BumplessTransfer(dt=dt)
        self.fallback_hw = CACCtoACCFallback(dt=dt)
        self.acc_ctrl    = PIController(headway=1.4, dt=dt)
        self.cacc_ctrl   = CACCController(headway=0.6, dt=dt)
        self._prev_mode  = None

    def step(self, obs, driver_inputs, comms) -> float:
        mode = self.mode_fsm.step(**driver_inputs, **comms,
                                   current_speed=obs.speed,
                                   current_gap=obs.gap)
        if mode != self._prev_mode:
            self.bumpless.trigger(obs.a_actual)
            if self._prev_mode == DrivingMode.CACC:
                self.fallback_hw.trigger_fallback()
        self._prev_mode = mode

        if mode == DrivingMode.MANUAL:
            a_cmd = driver_inputs['pedal_demand']
        elif mode == DrivingMode.ACC:
            a_cmd = self.acc_ctrl.step(obs.gap, obs.speed, obs.v_leader,
                                       headway=self.fallback_hw.get_headway())
        elif mode == DrivingMode.CACC:
            a_cmd = self.cacc_ctrl.step(obs.gap, obs.speed, obs.v_leader,
                                        obs.a_leader,
                                        bsm_valid=comms['bsm_valid'])
        return self.bumpless.blend(a_cmd)
```

***

# 9. Lead Vehicle Profile

The lead vehicle follows a prescribed speed profile rather than a car-following model. The profile is specified in a dedicated `profile` sheet in the Excel input file and is the primary forcing function for the entire platoon.

## 9.1 Profile Sheet Structure

| Column     | Type   | Notes                                                                              |
|------------|--------|------------------------------------------------------------------------------------|
| time_s     | float  | Simulation time at which this event takes effect                                   |
| command    | string | `set_speed` (target speed) or `set_acceleration` (direct, bypasses response model) |
| value      | float  | Target speed (m/s) or acceleration (m/s²) depending on command                     |
| transition | string | `ramp` (linear interpolation, default) or `step` (instantaneous jump)              |
| note       | string | Optional human-readable label — not used by simulation                             |

>   📝 **Note:** Triggers are time-based. Events are sorted by time_s at load time regardless of sheet row order. Before the first event the first value is held; after the last event the last value is held.

## 9.2 Profile Loader

```python
class LeadVehicleProfile:
    def __init__(self, df: pd.DataFrame):
        self._events = df.sort_values('time_s').reset_index(drop=True)

    @classmethod
    def from_excel(cls, path: str) -> 'LeadVehicleProfile':
        return cls(pd.read_excel(path, sheet_name='profile'))

    def get_speed_target(self, t: float) -> float:
        events = self._events
        if t <= events.iloc[0]['time_s']:  return events.iloc[0]['value']
        if t >= events.iloc[-1]['time_s']: return events.iloc[-1]['value']
        idx = events['time_s'].searchsorted(t) - 1
        e0, e1 = events.iloc[idx], events.iloc[idx + 1]
        if e0.get('transition', 'ramp') == 'ramp':
            alpha = (t - e0['time_s']) / (e1['time_s'] - e0['time_s'])
            return e0['value'] + alpha * (e1['value'] - e0['value'])
        return e0['value']
```

***

# 10. Excel Input File

## 10.1 Sheet Structure

| Sheet         | Required | Contents                                                                        |
|---------------|----------|---------------------------------------------------------------------------------|
| vehicles      | Yes      | One row per vehicle — id, model, filter, initial conditions, per-vehicle params |
| simulation    | Yes      | Global params: timestep, duration, road length, sensor_model, comms_model, etc. |
| profile       | Yes      | Lead vehicle drive cycle: time_s, command, value, transition                    |
| vehicle_types | No       | Named vehicle type presets for response model parameters (car, truck, etc.)     |

The `vehicle_types` sheet may be omitted entirely for simple single-type scenarios.

## 10.2 Vehicles Sheet Columns

### Required columns — must be present and non-null for every row

| Column             | Type         | Validation rule                                                                                  |
|--------------------|--------------|--------------------------------------------------------------------------------------------------|
| vehicle_id         | int          | Unique, no blanks                                                                                |
| model              | str          | Must exist in MODEL_REGISTRY                                                                     |
| initial_position_m | float        | ≥ 0                                                                                              |
| initial_speed_mps  | float        | ≥ 0                                                                                              |
| vehicle_length_m   | float        | \> 0                                                                                             |
| leader_id          | int or blank | If provided, must reference a valid vehicle_id; exactly one row must be blank (the lead vehicle) |
| filter             | str          | Must exist in FILTER_REGISTRY                                                                    |

### Conditionally required — required when a specific model is assigned

| Column            | Required when                                         | Validation rule           |
|-------------------|-------------------------------------------------------|---------------------------|
| desired_speed_mps | model is IDMHumanModel, IDMModel, or Wiedemann99Model | \> 0                      |
| time_headway_s    | model is IDMHumanModel or IDMModel                    | \> 0, typically 0.8–2.5 s |
| reaction_time_s   | model is IDMHumanModel                                | \> 0, typically 0.5–1.5 s |

### Optional columns — vehicle type and response parameter overrides

| Column         | Notes                                                                            |
|----------------|----------------------------------------------------------------------------------|
| vehicle_type   | String matching a `type_id` in the vehicle_types sheet; blank = skip type lookup |
| tau_throttle_s | Per-vehicle override; blank = fall through to type / global / hardcoded default  |
| tau_brake_s    | Same                                                                             |
| a_max_mps2     | Same                                                                             |
| a_min_mps2     | Same                                                                             |
| j_max_mps3     | Same                                                                             |

These five response parameters use a four-level resolution hierarchy — see [Section 10.2.1](#1021-vehicle-response-parameter-resolution).

### 10.2.1 Vehicle Response Parameter Resolution

The five response parameters (`tau_throttle_s`, `tau_brake_s`, `a_max_mps2`, `a_min_mps2`, `j_max_mps3`) are resolved in this priority order for each vehicle:

1.  **Per-vehicle override** — non-blank value in the vehicles sheet column wins immediately
2.  **Vehicle type lookup** — if `vehicle_type` is set and the `vehicle_types` sheet exists, use the matching row
3.  **Simulation sheet globals** — the global default values from the simulation sheet
4.  **Hardcoded defaults** — the `VehicleResponseModel.__init__()` parameter defaults

```python
def resolve_param(param, row, type_row, sim_config, default):
    if pd.notnull(row.get(param)):                    return float(row[param])          # level 1
    if type_row is not None and \
       pd.notnull(type_row.get(param)):               return float(type_row[param])     # level 2
    if hasattr(sim_config, param):                    return getattr(sim_config, param)  # level 3
    return default                                                                        # level 4
```

This means:

-   A simple homogeneous fleet needs no `vehicle_types` sheet and no per-vehicle override columns — the simulation sheet globals cover everything
-   A mixed fleet (cars + trucks) defines named types in `vehicle_types` and sets `vehicle_type` per row in the vehicles sheet
-   An individual vehicle that is anomalous within its type can still override a single parameter without defining a new type

## 10.2.2 Vehicle Types Sheet

Optional sheet. If absent, the loader silently skips level 2 and falls through to level 3.

| Column         | Type  | Validation rule                                                           |
|----------------|-------|---------------------------------------------------------------------------|
| type_id        | str   | Unique, no blanks — referenced by `vehicle_type` column in vehicles sheet |
| tau_throttle_s | float | \> 0                                                                      |
| tau_brake_s    | float | \> 0                                                                      |
| a_max_mps2     | float | \> 0                                                                      |
| a_min_mps2     | float | \< 0                                                                      |
| j_max_mps3     | float | \> 0                                                                      |

Example:

| type_id     | tau_throttle_s | tau_brake_s | a_max_mps2 | a_min_mps2 | j_max_mps3 |
|-------------|----------------|-------------|------------|------------|------------|
| car_default | 0.5            | 0.3         | 2.5        | -8.0       | 5.0        |
| heavy_truck | 0.9            | 0.5         | 1.2        | -5.0       | 3.0        |

All parameter columns in the vehicle_types sheet must be non-blank and numeric — partial rows are not permitted (unlike the vehicles sheet where blanks trigger fallthrough).

### Optional Wiedemann columns — blank means use class default

| Column | VISSIM default | Notes                               |
|--------|----------------|-------------------------------------|
| w_CC0  | 1.5 m          | Standstill distance                 |
| w_CC1  | 0.9 s          | Desired time headway                |
| w_CC2  | 4.0 m          | Following variation                 |
| w_CC3  | −8.0           | Threshold entering following        |
| w_CC4  | −0.35          | Negative speed-difference threshold |
| w_CC5  | 0.35           | Positive speed-difference threshold |
| w_CC6  | 6.0            | Influence of gap on oscillation     |
| w_CC7  | 0.25 m/s²      | Oscillation acceleration            |
| w_CC8  | 2.0 m/s²       | Standstill acceleration             |
| w_CC9  | 1.5 m/s²       | Desired acceleration at 80 km/h     |

### Optional ego sensor columns — blank means use passthrough

| Column               | Default           | Notes                                 |
|----------------------|-------------------|---------------------------------------|
| ego_speed_sigma      | 0.0 (passthrough) | Speed measurement noise std dev (m/s) |
| ego_accel_bias_drift | 0.0 (passthrough) | IMU bias drift rate (m/s² per √s)     |

### What NOT to include as per-vehicle columns

-   **CACC controller gains (k1, k2, k_ff, s0)** — system-level parameters in the simulation sheet. Per-vehicle CACC gains would prevent reasoning about string stability as a platoon property.
-   **Filter parameters (Kalman sigma, LPF alpha)** — belong in `extras` or filter-specific config, not as named columns that clutter the sheet for non-Kalman users.

>   ✅ **Decided:** leader_id is an explicit column rather than derived from row order. The Excel file is not locked or dropdown-validated — users can freely add columns for their own plugins.

## 10.3 Simulation Sheet Keys

| Key                   | Notes                                                                                        |
|-----------------------|----------------------------------------------------------------------------------------------|
| timestep_s            | 0.01 (fixed — see [Section 13](#13-simulation-loop-and-timestep))                                                                |
| duration_s            | Total run time                                                                               |
| road_length_m         | Length of simulated road                                                                     |
| render_interval_s     | How often to update graphics (e.g. 0.1 or 0.2 s)                                             |
| log_rate_hz           | CSV logging rate (default 10 Hz); sim always runs at 100 Hz — only every N-th step is logged  |
| playback_speed        | 1.0 = real time; 2.0 = 2x; 0 = unlimited (batch)                                             |
| sensor_model          | 'passthrough' initially; later 'kalman', 'lpf', etc.                                         |
| comms_model           | 'passthrough' initially; later 'dsrc', 'cv2x', etc.                                          |
| cacc_target_headway_s | System-level CACC headway (not per-vehicle)                                                  |
| a_max_mps2            | Level-3 default acceleration limit — overridden by vehicle_types sheet or per-vehicle column |
| a_min_mps2            | Level-3 default deceleration limit — same override hierarchy                                 |
| j_max_mps3            | Level-3 default jerk limit — same override hierarchy                                         |
| tau_throttle          | Level-3 default throttle time constant (s) — same override hierarchy                         |
| tau_brake             | Level-3 default brake time constant (s) — same override hierarchy                            |

## 10.4 The Loader

```python
import pandas as pd

_RESPONSE_PARAMS = ('tau_throttle_s', 'tau_brake_s', 'a_max_mps2', 'a_min_mps2', 'j_max_mps3')
_RESPONSE_DEFAULTS = dict(tau_throttle_s=0.5, tau_brake_s=0.3,
                          a_max_mps2=2.5, a_min_mps2=-8.0, j_max_mps3=5.0)

def resolve_param(param, row, type_row, sim_config):
    """Four-level resolution: per-vehicle → type → simulation sheet → hardcoded default."""
    if pd.notnull(row.get(param)):                  return float(row[param])
    if type_row is not None and \
       pd.notnull(type_row.get(param)):             return float(type_row[param])
    if hasattr(sim_config, param):                  return getattr(sim_config, param)
    return _RESPONSE_DEFAULTS[param]

def load_vehicles(path: str) -> list[Vehicle]:
    xl          = pd.ExcelFile(path)
    df          = xl.parse('vehicles')
    sim_config  = load_sim_config(xl)
    type_table  = (xl.parse('vehicle_types').set_index('type_id')
                   if 'vehicle_types' in xl.sheet_names else None)
    validate_vehicle_df(df, type_table)   # fail fast
    vehicles = []
    for _, row in df.iterrows():
        type_row = (type_table.loc[row['vehicle_type']]
                    if type_table is not None
                    and pd.notnull(row.get('vehicle_type')) else None)
        model      = load_model(row['model'], row)
        filter_    = load_filter(row['filter'], row)
        sensor     = build_sensor(sim_config)
        comms      = build_comms(sim_config)
        ego_sensor = build_ego_sensor(row, sim_config)
        response   = VehicleResponseModel(
            mode         = sim_config.response_model,
            tau_throttle = resolve_param('tau_throttle_s', row, type_row, sim_config),
            tau_brake    = resolve_param('tau_brake_s',    row, type_row, sim_config),
            a_max        = resolve_param('a_max_mps2',     row, type_row, sim_config),
            a_min        = resolve_param('a_min_mps2',     row, type_row, sim_config),
            j_max        = resolve_param('j_max_mps3',     row, type_row, sim_config),
        )
        vehicles.append(Vehicle(
            id         = row['vehicle_id'],
            model      = model,
            filter_    = filter_,
            sensor     = sensor,
            comms      = comms,
            ego_sensor = ego_sensor,
            response   = response,
            position   = row['initial_position_m'],
            speed      = row['initial_speed_mps'],
            length     = row['vehicle_length_m'],
        ))
    return vehicles
```

## 10.5 Validation (validate_vehicle_df)

The validation function performs 13 checks in category order, collecting all problems within each category before raising, so a user sees all issues of a given type at once rather than one at a time. Checks include:

1.  Drop completely empty rows (warn, don't error — almost always accidental Excel artifacts)
2.  Required columns present
3.  Coerce numeric columns; catch strings-stored-as-text (Excel locale issues)
4.  Required columns not null
5.  vehicle_id: unique integers
6.  Model names exist in registry (with typo suggestions via Levenshtein distance)
7.  Filter names exist in registry (with typo suggestions)
8.  Model-conditional required columns (e.g. reaction_time_s for IDMHumanModel)
9.  Range checks (positive values, non-negative positions/speeds)
10. leader_id topology (exactly one blank = lead vehicle, all references valid)
11. Lead vehicle must use LEAD_PROFILE model
12. No circular leader_id chains
13. Initial position overlap warnings (warn, don't error — may be intentional)
14. vehicle_types sheet (if present): type_id unique; all parameter columns numeric and non-blank; a_max_mps2 \> 0; a_min_mps2 \< 0; tau and j_max \> 0
15. vehicles sheet: if vehicle_type is non-blank, it must match a type_id in the vehicle_types sheet (error if sheet is absent but column is non-blank)
16. Per-vehicle response override columns: if present and non-blank, same range checks as above

Full implementation: see `validate_vehicle_df()` in the codebase.

***

# 11. Road Representation and Multi-Lane Preparation

## 11.1 Rationale

The initial simulation is single-lane. However, extensions to multiple lanes, lane changes, and ramp geometry are planned. Two design decisions made now — at near-zero cost — prevent a painful refactor later:

1.  `Road` **class with a** `lanes` **list** instead of a bare `road_length_m` scalar. Adding a lane today costs one list entry. Ripping out a scalar and replacing it with a class after the code is load-bearing costs far more.
2.  `Road.get_leader(vehicle, vehicles_by_id)` **as the single indirection point** for leader resolution. The `SimulationLoop` never resolves `leader_id → vehicle` directly; it always calls `road.get_leader()`. Today that method does a static dict lookup. In a multi-lane sim it will do a spatial search within the correct lane. The loop never changes.

Everything else (LaneChangeModel ABC, lateral VehicleState fields, SignalController, ramp geometry) is future scope and premature to add now.

## 11.2 Classes

```python
@dataclass
class Lane:
    lane_id: int
    width_m: float = 3.7    # stored for future lateral geometry

@dataclass
class Road:
    length_m: float
    lanes: list[Lane] = field(default_factory=lambda: [Lane(lane_id=0)])

    @classmethod
    def single_lane(cls, length_m: float) -> Road:
        """Convenience factory for the common single-lane case."""
        return cls(length_m=length_m, lanes=[Lane(lane_id=0)])

    def get_leader(
        self,
        vehicle: Vehicle,
        vehicles_by_id: dict[int, Vehicle],
    ) -> Vehicle | None:
        """
        Today: static lookup via vehicle.leader_id.
        Future: spatial lane-aware search (handles overtakes, lane changes).
        """
        if vehicle.leader_id is None:
            return None
        return vehicles_by_id.get(vehicle.leader_id)
```

## 11.3 SimulationLoop Integration

`Road` is an optional constructor parameter. If omitted, a single-lane road of `config.road_length_m` is created automatically — all existing call sites remain unchanged.

```python
class SimulationLoop:
    def __init__(self, vehicles, config, road: Road | None = None):
        ...
        self._road = road if road is not None else Road.single_lane(config.road_length_m)

    def _step(self, t):
        for vehicle in self.vehicles:
            leader = self._road.get_leader(vehicle, self._vehicle_map)
            ...
```

## 11.4 Future Extension Path

When multi-lane support is added, only `Road.get_leader()` changes. No changes to `SimulationLoop`, `Vehicle`, or any driving model.

The progression:

1.  **Now:** `get_leader()` returns `vehicles_by_id[vehicle.leader_id]` — static
2.  **Multi-lane:** `Road` maintains a per-lane sorted vehicle list; `get_leader()` finds the nearest vehicle ahead in `vehicle.lane_id`
3.  **Lane changes:** `Vehicle` gains a `lane_id` attribute; `Road` updates its lane index each step; `get_leader()` queries the new lane after a lane change

## 19.2 Doppler Range-Rate Measurement in RadarSensor

**Current state:** `RadarSensor` applies AR(1) noise to both gap and gap-rate, but treats gap-rate as a derived quantity (gap difference over time) rather than a direct Doppler measurement. The Kalman filter observes both, but the measurement noise covariance for range-rate is set at the same level as the range noise — not reflecting the actual physics.

**Enhancement:** Automotive FMCW radar measures range-rate (relative velocity) directly via the Doppler shift of the return signal. This is a fundamentally different — and in practice *more accurate* — measurement than range:

| Quantity | Typical σ (FMCW radar) | Physical source |
|---|---|---|
| Range (gap) | 0.1–0.5 m | Beat-frequency resolution, multipath |
| Range-rate | 0.02–0.1 m/s | Doppler frequency resolution |

Range-rate noise is roughly 3–10× smaller than range noise. Treating them as equally noisy (as the current model does) undersells the Kalman filter's ability to estimate relative velocity.

**Implementation:**

1. In `RadarSensor`, model range and range-rate as *separate* AR(1) noise processes with distinct sigmas:
   ```python
   self._range_noise      = ARNoise(sigma=sigma_range,      rho=rho, rng=rng)
   self._range_rate_noise = ARNoise(sigma=sigma_range_rate, rho=rho, rng=rng)
   ```
   Suggested defaults: `sigma_range=0.3 m`, `sigma_range_rate=0.05 m/s`.

2. In `GapKalmanFilter`, update the observation noise matrix `R` to reflect the asymmetry:
   ```python
   R = np.diag([sigma_range**2, sigma_range_rate**2])
   ```
   Currently `R` uses the same value for both diagonal entries.

3. The Kalman filter already has a 2-state observation model (`H = I₂`) that observes both gap and rate directly — no structural change is needed, only the `R` matrix values.

**Why it matters for CACC:** The gap-rate estimate feeds directly into the speed-error term `e_vel = v_lead - v_ego` in `CACCController`. A more accurate Doppler-derived rate measurement reduces speed-error noise, which in turn reduces unnecessary acceleration commands and improves ride comfort — measurable as lower RMS acceleration variance in the state log.

**Config surface:** Add `radar_sigma_range` and `radar_sigma_range_rate` as `SimConfig` fields (alongside the existing `sensor_model`), defaulting to the current values so the change is backwards-compatible.

*CACC Simulation Design Notes · Work in Progress · April 2026*

***

# 12. Plugin System

Users can add new driving models and filters by dropping Python files into a plugins folder. The plugin loader scans this folder at startup and registers any DrivingModel or Filter subclasses it finds.

## 12.1 Plugin Loader

```python
import importlib, pathlib, inspect

def load_plugins(plugin_dir: str = 'plugins') -> None:
    """Scan plugins/ folder and register any DrivingModel or Filter subclasses."""
    for path in pathlib.Path(plugin_dir).glob('*.py'):
        spec   = importlib.util.spec_from_file_location(path.stem, path)
        module = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(module)
        for name, obj in inspect.getmembers(module, inspect.isclass):
            if issubclass(obj, DrivingModel) and obj is not DrivingModel:
                MODEL_REGISTRY[name] = obj
            if issubclass(obj, Filter) and obj is not Filter:
                FILTER_REGISTRY[name] = obj

# Call once at startup before loading Excel file
load_plugins()
```

## 12.2 Writing a Plugin

```python
# plugins/my_model.py
from cacc_sim import DrivingModel, DrivingModelOutput, VehicleState

class MyCustomModel(DrivingModel):
    def required_inputs(cls): return {'speed', 'gap'}
    def compute(self, state: VehicleState) -> DrivingModelOutput:
        accel = ...
        return DrivingModelOutput(acceleration=accel)
```

The class name becomes the registry key. The user references it by name in the Excel model column.

## 12.3 Shipped Plugin: Wiedemann99Model

The Wiedemann 99 psychophysical model ships as a plugin rather than a built-in, both as a worked example for plugin authors and because it is the most realistic human driver model for mixed-traffic scenarios. It is PTV VISSIM's default model. The key difference from IDMHumanModel is that Wiedemann drivers don't react continuously — they only respond when their perception crosses a threshold, producing regime-switching behaviour observed in naturalistic driving data.

| Regime       | Condition                                      | Behaviour                                       |
|--------------|------------------------------------------------|-------------------------------------------------|
| Free driving | Gap \> perception threshold (SDX)              | Accelerate toward desired speed; ignores leader |
| Closing in   | Approaching leader, gap \> desired but closing | Begin braking to avoid overshoot                |
| Following    | Near equilibrium gap, small speed difference   | Small oscillations around desired gap           |
| Braking      | Gap \< desired gap (emergency)                 | Hard deceleration; near-collision               |

```python
# plugins/wiedemann99.py
from cacc_sim import DrivingModel, DrivingModelOutput, VehicleState
import numpy as np

class Wiedemann99Model(DrivingModel):
    """
    Wiedemann 99 psychophysical car-following model.
    Parameter names and defaults match VISSIM conventions.
    """
    def __init__(self,
                 CC0=1.5, CC1=0.9, CC2=4.0, CC3=-8.0,
                 CC4=-0.35, CC5=0.35, CC6=6.0, CC7=0.25,
                 CC8=2.0, CC9=1.5, desired_speed=30.0):
        self.CC0=CC0; self.CC1=CC1; self.CC2=CC2; self.CC3=CC3
        self.CC4=CC4; self.CC5=CC5; self.CC6=CC6; self.CC7=CC7
        self.CC8=CC8; self.CC9=CC9
        self.v_desired = desired_speed
        self.regime = 'free'

    @classmethod
    def required_inputs(cls): return {'speed', 'gap', 'lead_speed'}

    def _desired_gap(self, v):
        return self.CC0 + self.CC1 * v

    def compute(self, state: VehicleState) -> DrivingModelOutput:
        gap = max(state.gap, 0.1)
        v, v_l = state.speed, state.lead_speed
        dv = v - v_l
        d = self._desired_gap(v)
        SDX = d + self.CC2
        SDV = dv**2 / (2 * max(gap - d, 0.1)) if gap > d else 99.0

        if gap > SDX:           self.regime = 'free'
        elif dv < SDV and gap < d + self.CC2: self.regime = 'following'
        elif gap < d:           self.regime = 'braking'
        else:                   self.regime = 'closing'

        if self.regime == 'free':
            a = self.CC8 + (self.CC9 - self.CC8) * min(v / 22.2, 1.0)
            if v >= self.v_desired: a = 0.0
        elif self.regime == 'following':
            a = np.random.uniform(self.CC4, self.CC5) * self.CC7 \
                - self.CC6 * max(dv, 0) / gap
        elif self.regime == 'closing':
            a = max(-0.5 * dv**2 / max(gap - d, 0.5), -4.0)
        else:
            a = max(min(-2.0 * dv, -0.5), -6.0)

        return DrivingModelOutput(acceleration=float(a))
```

>   📝 **Note:** The `regime` attribute is worth including in the state log — it gives a rich picture of traffic behaviour directly comparable to naturalistic driving data.

***

# 13. Simulation Loop and Timestep

## 13.1 Timestep

The simulation runs at a fixed timestep of 0.01 seconds (100 Hz). This was chosen for three reasons:

-   Correct representation of sub-timestep delays: BSM transmission delay (\~10 ms) and radar processing latency (50–100 ms) are lost entirely at 0.1 s but represented accurately at 0.01 s
-   Multi-rate sensor fusion: radar updates every step while BSM updates every \~10 steps, which is the correct architecture for the fusion Kalman filter
-   Kalman filter Q and IIR filter alpha values derived from physical parameters are accurate at 0.01 s

## 13.2 Decoupled Graphics Loop

The simulation and graphics are fully decoupled. The sim runs as fast as Python can execute it. Graphics update at a configurable interval (`render_interval_s` in the simulation sheet, typically 0.1–0.2 s). Playback speed is controlled via a multiplier.

```python
SIM_DT    = 0.01
RENDER_DT = config.render_interval_s
SPEED     = config.playback_speed

sim_time        = 0.0
last_render_t   = 0.0
wall_start      = time.perf_counter()

while running:
    simulation.step(sim_time, SIM_DT)
    sim_time += SIM_DT

    if sim_time - last_render_t >= RENDER_DT:
        renderer.draw(simulation.state)
        last_render_t = sim_time

    if SPEED > 0:
        wall_elapsed = time.perf_counter() - wall_start
        sim_ahead = (sim_time / SPEED) - wall_elapsed
        if sim_ahead > 0:
            time.sleep(sim_ahead)
```

>   ✅ **Decided:** Graphics library: Pygame. Matplotlib FuncAnimation is too slow for real-time (2–5 Hz) but suitable for post-run playback.

## 13.3 Mode Switching

>   ✅ **Decided:** Out of scope for initial implementation. Each vehicle has a fixed driving model for the entire run. The full FSM ([Section 8](#8-mode-switch-logic)) is the intended future evolution.

## 13.4 State Logging

>   ✅ **Decided:** Runtime state is logged to a list of dicts, one dict per vehicle per log step. The sim runs at 100 Hz but only every N-th step is logged, where N = round(100 / log_rate_hz). Default log_rate_hz = 10 reduces a 100 s run from 1 M rows to 100 k rows. Collision rows are always logged regardless of the interval. Post-run: convert to pandas DataFrame and write to CSV. Autogenerate standard plots (all needed data is in the CSV).

```python
# Each timestep, per vehicle (vehicle.step() return value):
{
    't':            sim_time,
    'id':           vehicle.id,
    'x':            vehicle.plant.x,
    'v':            vehicle.plant.v,
    'a':            vehicle.plant.a,       # actual acceleration (post-response-model)
    'a_cmd':        a_cmd,                 # commanded acceleration (pre-response-model)
    'gap':          gap,
    'leader_id':    vehicle.leader_id,
    'model':        type(vehicle.model).__name__,
    'vehicle_type': vehicle.vehicle_type,
    'length':       vehicle.plant.length,
}
```

`a_cmd` is the driving model's raw output before actuator lag is applied; comparing it to `a` shows the response model's effect. `leader_id` is included so post-processing scripts can reconstruct platoon topology without re-reading the Excel file.

## 13.5 Run Output Format

>   ✅ **Decided:** Each run gets its own subfolder `results/<scenario>_<timestamp>/`. Files inside are named by role, not by run — keeps directory listings clean and makes file references in scripts stable.

```
results/
├── index.csv                          ← one line per run, appended after every run
├── my_scenario_20260421_143022/
│   ├── data.csv                       ← full state log
│   ├── input.xlsx                     ← verbatim copy of the input Excel
│   ├── metadata.yaml                  ← metadata record (see below)
│   ├── data.png                       ← five-panel composite plot
│   ├── data_speed.png
│   ├── data_gap.png
│   ├── data_accel.png
│   ├── data_lag.png
│   └── data_spacetime.png
└── my_scenario_20260421_150011/
    └── ...
```

**`results/index.csv`** — a single-line append after every run; lets you find a specific run without opening folders:

```
run_folder,scenario,timestamp,seed,duration_s,n_vehicles,cacc_k_ff
my_scenario_20260421_143022,my_scenario,2026-04-21 14:30:22,42,300,10,0.45
my_scenario_20260421_150011,my_scenario,2026-04-21 15:00:11,43,300,10,0.30
```

The Excel copy requires zero serialization effort and gives the student everything needed to reproduce the run exactly — the CSV captures what happened, the Excel captures why.

**YAML metadata fields:**

| Field | Notes |
|---|---|
| `run_name` | `<stem>_<timestamp>` |
| `timestamp` | `yyyymmdd_HHMMSS` |
| `version` | Package version string |
| `excel_input` | Original filename |
| `duration_s`, `timestep_s` | From SimConfig |
| `n_vehicles`, `n_steps` | Derived from output DataFrame |
| `response_model` | `'kinematic'` or `'lag'` |
| `string_stability` | Dict of `{vehicle_id: bool}` for CACC vehicles only |
| `response_params` | Dict of `{vehicle_id: {mode, tau_throttle_s, tau_brake_s, a_max_mps2, a_min_mps2, j_max_mps3}}` — the resolved values after the four-level hierarchy |

`string_stability` and `response_params` are the genuinely new information not already in the Excel file. Everything else is redundant with the Excel copy but included for quick inspection without opening the workbook.

## 13.6 Entry Point and Mode Dispatch

`cacc_sim/main.py` is the CLI entry point. It is intentionally thin — all logic lives in the modules it calls.

**Argument parsing:** `argparse` with `prog='cavsandbox'`. One positional argument `input`; one optional flag `--seed INT`.

**Input dispatch** (by file extension):

| Extension       | Action                                                                                      |
|-----------------|---------------------------------------------------------------------------------------------|
| `.xlsx`         | Load via `load_vehicles()`; apply `--seed` override if given; dispatch by `playback_speed` |
| `.csv`          | Route directly to `CSVPlayback.from_csv(path, PygameRenderer()).run()`; `--seed` ignored    |
| anything else   | `parser.error()` — clean usage message, exit 2                                              |

**`.xlsx` mode dispatch rule:** if `config.playback_speed == 0`, run headless (`SimulationLoop.run()`); otherwise open the Pygame window (`SimulationLoop.run_live(PygameRenderer())`). No command-line flag needed — the Excel simulation sheet already controls this.

`plot_run` is deliberately excluded from `cacc_sim/__init__.py` to avoid the `RuntimeWarning: 'cacc_sim.plot' found in sys.modules` that Python raises when a submodule is imported at package init time and then run as `python -m cacc_sim.plot`. Users who need `plot_run` programmatically import it directly from `cacc_sim.plot`.

## 13.7 Post-Run Plots

>   ✅ **Decided:** Five-panel composite PNG with a shared time axis, plus five individual panel PNGs saved alongside the CSV.  `plot_run(csv_path)` is called automatically by `save_run()` and is also a standalone entry point.

**Default panel set:**

| Panel | File suffix | What it answers |
|---|---|---|
| Speed vs. time | `_speed.png` | Is the platoon following the leader? String stability visible here. |
| Gap vs. time | `_gap.png` | Is the headway policy being maintained? |
| Actual acceleration vs. time | `_accel.png` | Is the ride comfortable? All vehicles shown. |
| Vehicle 2: actual vs. commanded acceleration | `_lag.png` | What is the response model contributing? Solid = actual, dashed = commanded, same color. Falls back to first follower if no vehicle 2. |
| Space-time diagram | `_spacetime.png` | Position (y) vs. time (x) for each vehicle. Slope = speed; horizontal spacing = gap; parallel lines = string stable. Note: axes are transposed from traffic engineering convention (time on x). |

**Excluded from defaults:** headway vs. time (redundant with gap for most purposes).

**Visual identity** — colors and line styles live in `cacc_sim/palette.py`. Two separate palettes are defined: `MODEL_COLORS` for the pygame renderer (light grey lead, cyan CACC — optimised for a black road canvas) and `MODEL_COLORS_PLOT` for matplotlib (black lead — legible on white paper, dark teal `#008080` CACC — richer than cyan in print). Line styles are shared: solid (lead), dashed (human IDM), dash-dot (ACC IDM), dotted (CACC). Line width is 2.0 (thicker than matplotlib default for print legibility).

**Standalone re-plot:**

```
python -m cacc_sim.plot results/my_scenario_20260421_143022/data.csv [--show]
```

Re-generating plots from an old CSV does not require re-running the simulation.

***

# 14. Renderer Design (Step 8 — Pygame Prototype)

## 14.1 View

Top-down road view: the road is drawn as a horizontal rectangle; vehicles are drawn as tinted PNG sprites on it. This maps directly to the 1D longitudinal physics — nothing is lost by the simplification.

**Road markings and furniture** (all rendered by `_draw_road(offset, px_per_m)`, which receives camera parameters from `draw()` each frame):

| Element | Specification |
|---|---|
| Centre-line dashes | 4 px wide, colour `(255, 255, 180)` warm white, 20 px dash / 40 px gap (2:1 ratio); scroll leftward at `lead_speed × px_per_m` px/s; offset tracked in `_dash_offset` instance state |
| Road edge lines | Solid white `(255, 255, 255)`, 2 px thick, at `y = ROAD_TOP` and `y = ROAD_TOP + ROAD_H`; static (do not scroll) |
| Roadside posts | 4 × 16 px rectangles placed 4 px outside each edge line, above and below the road strip; spacing 50 m in world coordinates; alternate red `(220, 30, 30)` / white `(255, 255, 255)` keyed to `floor(world_x / 50) % 2` where `world_x = (screen_x − offset) / px_per_m` — colour is a world property, not a screen property, so posts never flicker as they scroll; rendered from one spacing interval before the left edge to one after the right edge (no pop-in) |

All three scrolling elements stop when paused: dashes because `sim_dt = 0` prevents `_dash_offset` from updating; posts and edge lines because they are derived from `offset`, which does not change while the lead vehicle is stationary.

>   ✅ **Decided:** Road strip only for Step 8. Strip chart panels (speed-time, gap-time) are explicitly planned but deferred. The road view is designed so that chart panels can be added below it later without changing the road view code — the road view is told "draw into this Rect" rather than assuming a fixed window height.

## 14.2 Scale and Camera

Default window size: **1200 × 400 px**. This fits comfortably on a laptop screen alongside other windows, leaves room for HUD overlays, and provides adequate vertical space for chart panels if added later (window height would grow at that point rather than the road strip shrinking).

**Camera:** The lead vehicle's front bumper is pinned at a fixed position \~82% from the left edge of the window (`LEAD_ANCHOR_FRAC = 0.82`). Followers appear to the left. This keeps the forcing function always visible and makes relative gap sizes immediately readable.

**Auto-zoom:** `px_per_m` is computed each frame to fit all vehicles in the window:

```
span = lead.x − (rearmost.x − rearmost.length)   # bumper-to-bumper platoon length
px_per_m = anchor_px / (span × 1.1 + 5 m)         # 10% margin + 5 m padding
px_per_m = clamp(px_per_m, PX_PER_M_MIN=2.0, PX_PER_M=6.0)
```

The floor (`PX_PER_M_MIN = 2.0`) prevents vehicles from becoming unreadably small when a follower falls far behind. If the gap exceeds what the floor allows, the rearmost vehicle goes off the left edge — an acceptable degradation for extreme outlier scenarios.

Vehicle sprites are scaled to actual vehicle length: a 5 m car and a 15 m truck are drawn at proportionally different widths. This makes gap sizes visually meaningful even as zoom changes.

## 14.3 Per-Vehicle Display

| Element    | Detail                                                                                                                                                                                     |
|------------|--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| Vehicle ID | Drawn on the vehicle body, always visible. Font size 10–12 px; display the number only (e.g. `1`, not `Vehicle 1`) to avoid overlap on closely-spaced vehicles.                           |
| Color      | Coded by driver model per the palette below. Reserve red for future warning conditions (gap too small, emergency braking).                                                                 |
| Shape      | PNG sprites from `cacc_sim/assets/`: `car.png` for cars, `truck.png` for trucks (any `vehicle_type` containing `'truck'`). Sprites are white-on-transparent; tinted to the model color at load time using `pygame.BLEND_RGB_MULT` (white → model color, black outlines → black, transparency preserved). Scaled per-frame to the vehicle's pixel width × `VEH_H`. If a sprite file is missing the renderer falls back to the rectangle drawing used in earlier versions. |

**Color palette**

| Model          | Color              | Reasoning                                            |
|----------------|--------------------|------------------------------------------------------|
| LEAD_PROFILE   | White / light grey | Neutral — forcing function, not a control model      |
| IDMHumanModel  | Amber / orange     | Warm = human driver                                  |
| IDMModel (ACC) | Green              | Automated; familiar safe/go convention               |
| CACCModel      | Cyan / light blue  | Cooler variant of green = higher automation than ACC |

Road: dark grey. Background: black. Both chosen for projector legibility in a classroom setting. Red reserved for future warning states.

>   ✅ **Decided:** Speed is not shown as a per-vehicle label on the road view (too cluttered at 10+ vehicles). Speed is shown in the chart panel below.

## 14.4 HUD / Overlay

Persistent overlays shown at all times (top-left, stacked vertically):

| Element            | Notes                                                                                                                                                                                                                   |
|--------------------|-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| Simulation time    | Displayed as `mm:ss.d` (e.g. `01:23.4`)                                                                                                                                                                                 |
| Playback speed     | Current multiplier (e.g. `1×`, `2×`); `BATCH` when `playback_speed = 0`                                                                                                                                                 |
| Lead vehicle speed | Speed of the `LeadVehicleModel` vehicle in **km/h** (falls back to frontmost vehicle if no lead model present)                                                                                                          |
| Pause indicator    | `PAUSED` in red; absent when running                                                                                                                                                                                    |
| Keyboard hint line | Single dim-grey line just above the chart panel listing active keyboard controls; content differs between live and playback modes (see [Section 14.6](#146-keyboard-controls)). Constructed at renderer init time based on `playback_mode` flag. |

## 14.5 Pause / Resume

Spacebar toggles pause in both live and CSV playback modes.

**Live mode implementation detail:** when paused, `simulation.step()` is skipped but the pygame event loop and renderer continue to run (window stays responsive). On unpause, the wall-clock reference point must be reset to the current wall time — otherwise the pacing logic sees a large accumulated deficit and runs flat out until it catches up. Concretely:

```python
if not paused:
    simulation.step(sim_time, SIM_DT)
    sim_time += SIM_DT
else:
    wall_start = time.perf_counter() - (sim_time / SPEED)  # reset reference on unpause
```

**CSV playback:** pause simply stops advancing the DataFrame row pointer. No wall-clock correction needed since playback drives its own timing loop.

## 14.6 Keyboard Controls

| Key              | Live mode      | CSV playback                                          |
|------------------|----------------|-------------------------------------------------------|
| Space            | Pause / resume | Pause / resume                                        |
| `→` / `←`        | —              | Step forward / backward one render frame while paused |
| `+` / `-`        | —              | Increase / decrease playback speed                    |
| `R`              | —              | Rewind to start                                       |
| Left-click chart | —              | Seek to that time and pause                           |
| `Q` or `Esc`     | Quit           | Quit                                                  |

Playback speed steps in powers of two: 0.25×, 0.5×, 1×, 2×, 4×. Frame-step while paused (arrow keys) is particularly useful in a teaching context — the instructor can advance one frame at a time through a critical moment.

`PygameRenderer` accepts a `playback_mode: bool = False` constructor argument. When `True`, the keyboard hint line at the bottom of the window shows the full playback command set; when `False` (live mode), only `Space` and `Q/Esc` are shown. Callers creating a renderer for CSV playback must pass `playback_mode=True`.

## 14.7 Live vs. CSV Playback — Shared Renderer

Both modes are identical from the renderer's perspective: a sequence of frames, each frame being a snapshot of all vehicle states at time t. The only difference is where the frame data comes from.

| Mode         | Data source                                  | Pacing                                              |
|--------------|----------------------------------------------|-----------------------------------------------------|
| Live         | `vehicle.plant.x`, `.v`, `.a` read each step | `time.sleep()` in the sim loop                      |
| CSV playback | Row(s) from the DataFrame filtered by `t`    | Same `time.sleep()` logic, driven by the `t` column |

A `RenderFrame` dataclass is the common currency passed to the renderer regardless of source:

```python
@dataclass
class RenderFrame:
    sim_time:           float
    vehicles:           list[VehicleRenderState]  # x, v, a, gap, id, model_name, vehicle_type
    speed_traces:       dict | None = None         # id → iterable of (t, v_mps)
    v_max_display_kmh:  float = 0.0                # fixed y-axis ceiling
    chart_full_range:   tuple | None = None        # (t_min, t_max) for playback full-trace mode
    playback_cursor_t:  float | None = None        # vertical cursor position in playback mode
```

The sim loop constructs `RenderFrame` from live vehicle objects. The CSV playback constructs it from DataFrame rows. `PygameRenderer.draw(frame)` never knows or cares which source it came from.

**CSV playback specifics:** the CSV is logged at 100 Hz (every 0.01 s) but only `render_interval_s` rows need to be rendered. The playback loop steps through the DataFrame by sim time, rendering only rows where `t % render_interval_s < dt`. Playback supports variable speed and rewind; live mode supports pause only.

## 14.8 Speed Chart Panel

A 240 px panel below the 400 px road view brings the total window height to 640 px. The panel shows one speed line per vehicle, colored by the shared palette.

| Property       | Live mode                                      | CSV playback mode                                      |
|----------------|------------------------------------------------|--------------------------------------------------------|
| X-axis range   | Rolling 30 s window, scrolling left            | Full trace, t = 0 to end                               |
| X-axis ticks   | Auto-scaled to window (`_nice_x_tick()`)       | Auto-scaled to run duration                            |
| Y-axis range   | 0 – `v_max_display_kmh` (fixed at sim start)   | 0 – `v_max_display_kmh` (from CSV `v` column max)     |
| Cursor line    | None                                           | White vertical line at current playback position       |
| Click behavior | No action                                      | Snap playback to clicked time and pause                |

**`v_max_display_kmh` computation (live mode):** takes the maximum of each vehicle's initial plant speed, `desired_speed` attribute (IDM/CACC models), and lead profile peak speed; multiplies by 1.1 and rounds up to the nearest 10 km/h.

**Speed buffer (live mode):** `SimulationLoop` maintains a `collections.deque(maxlen=3000)` per vehicle (30 s × 100 Hz), populated in `_step()` alongside the full log. The deque reference is passed by pointer into each `RenderFrame`; no copying occurs. The render path reads at most 3000 × N points regardless of run length.

**Click-to-seek (playback mode):** `PygameRenderer.handle_events()` detects `MOUSEBUTTONDOWN` events within the chart plot area and calls `_chart_click_time(pos)`, which converts the pixel x-coordinate to a simulation time using the stored `_last_chart_t_range`. The time is returned as the third element of `handle_events()`'s `(paused, running, seek_time)` tuple. `CSVPlayback.run()` uses `bisect.bisect_left` to snap to the nearest pre-built render frame and resets the wall-clock reference so pacing is correct on resume.

## 14.9 Module Structure

```
cacc_sim/
    renderer.py       # RenderFrame + VehicleRenderState dataclasses; PygameRenderer class
    simulation.py     # SimulationLoop — constructs RenderFrame and feeds renderer each step
    playback.py       # CSVPlayback — reads DataFrame, constructs RenderFrame, feeds same renderer
```

-   `renderer.py` has no knowledge of where data comes from
-   `simulation.py` and `playback.py` both depend on `renderer.py` but not on each other
-   Passing `renderer=None` to `SimulationLoop` runs headless (batch mode, no window) — useful for parameter studies

***

***

# 15. Development Sequence

The recommended build order, confirmed by the pygame prototyping discussion:

1.  **Core data structures** — VehicleState, DrivingModelOutput, FilterInput/Output dataclasses ✅
2.  **VehiclePlant** — position/speed integration, gap_to() ✅
3.  **VehicleResponseModel** — actuator lag (start with Level 2, 1st-order lag) ✅
4.  **IDMModel** — the simplest car-following model; validates the compute() interface ✅
5.  **LeadVehicleProfile + LeadVehicleModel** — the forcing function ✅
6.  **Excel loader + validate_vehicle_df()** — reads vehicles, simulation, profile sheets ✅
7.  **Simulation loop** — the main time-stepping loop with passthrough sensors ✅
8.  **Pygame prototype** — minimal renderer to confirm physics and loop architecture ✅
9.  **IDMHumanModel** — perceived-quantity reaction delay; `DelayBuffer` utility in `core.py` ✅
10. **CACCModel + CACCController** — V2V feedforward ✅
11. **Plugin loader + Wiedemann99Model** — validates the plugin architecture ✅
12. **State logging + CSV output** — log dict with `a_cmd`/`leader_id`; `save_run()` writes CSV + YAML + Excel copy to `results/`; `main.py` entry point ✅
13. **Post-run plots** — five-panel composite PNG + individual panel PNGs (speed, gap, accel, lag, space-time); shared palette with renderer ✅
14. **Collision detection** — `_CollisionError` stops sim on gap < 0; `run()` prints warning and returns partial DataFrame; `run_live()` shows frozen overlay until Q/Esc ✅
15. **Live speed chart + playback chart** — rolling 30 s speed panel below road view in live mode; full-trace chart with cursor and click-to-seek in CSV playback mode; PNG sprite vehicle graphics ✅
16. **Realistic sensors** — replace passthroughs with noise/delay/filter models + EgoSensor ✅
17. **Realistic V2V comms** — replace `PassthroughBSMTracker` with a `DSRCChannel` model: 10 Hz BSM broadcast rate, configurable packet-drop probability, BSM age tracking (`bsm_age_s`); CACC feedforward drops to zero on timeout; multi-rate fusion KF (radar at 100 Hz, BSM at 10 Hz)

***

# 16. Test Strategy

Each step in the development sequence ([Section 15](#15-development-sequence)) gets its own pytest file. Steps 1–4 are already covered. The following notes describe the priority targets for the next steps.

## 16.1 Step 5 — LeadVehicleProfile + LeadVehicleModel

Profile loader edge cases are the priority:

-   **Before-first-event hold** — query at t \< first event time returns the first value, not an error
-   **After-last-event hold** — query at t \> last event time returns the last value
-   **Ramp interpolation accuracy** — query at the exact midpoint between two events returns the midpoint value (linear interpolation check)
-   **Out-of-order rows sort correctly** — construct a profile with rows in reverse time order; verify the output is identical to the correctly-ordered version

## 16.2 Step 6 — Excel Loader + validate_vehicle_df()

The validation function is the main target — one test per validation category is the right granularity. The following are particularly worth testing because they have the most branching and the most ways to get wrong:

-   **leader_id topology** — circular chains raise an error; a missing reference raises an error; exactly one blank is valid; two blanks raise an error; zero blanks raise an error
-   **Model-conditional required columns** — IDMModel with missing `desired_speed_mps` raises; IDMHumanModel with missing `reaction_time_s` raises; a column required by one model is not required for another
-   **Four-level parameter resolution** — level 1 (per-vehicle column) overrides level 2 (vehicle_types sheet); level 2 overrides level 3 (simulation sheet); absent vehicle_types sheet falls through to level 3; absent simulation sheet key falls through to level 4 (hardcoded default); all five parameters resolve independently

## 16.3 Step 7 — Simulation Loop

Focus on **conservation properties** rather than exact values. Exact values are fragile; properties are robust:

-   **Speed never goes negative** — run any scenario for N steps; assert all logged speeds ≥ 0
-   **Gap never goes negative** — with a reasonable scenario (leader not braking harder than follower can respond), assert gap stays positive throughout
-   **Single-vehicle profile tracking** — a single vehicle running LeadVehicleModel tracks the speed profile within a reasonable tolerance after transients settle
-   **Two-vehicle IDM gap convergence** — start with an initial gap error; after sufficient steps the gap error should be decreasing, not growing

## 16.4 Fixture Strategy

Sim loop tests need vehicle configurations without reading real files from disk. Two approaches, both have a place:

| Approach                                                   | Use for                                    | Trade-off                                                           |
|------------------------------------------------------------|--------------------------------------------|---------------------------------------------------------------------|
| Build DataFrames directly in the fixture                   | Unit tests of loader logic and validation  | Fast, portable, no I/O — preferred for the majority of tests        |
| Write a temporary Excel file (via `openpyxl` + `tmp_path`) | One integration test of the full load path | Slower, but tests the actual Excel parsing code that users exercise |

>   ✅ **Decided:** Unit tests construct DataFrames directly. One integration test per major component (loader, sim loop) writes a minimal real Excel file using pytest's built-in `tmp_path` fixture. This keeps the unit tests fast while ensuring the Excel parsing layer is exercised at least once end-to-end.

The Pygame step (Step 8) then becomes genuinely low-risk: if the property tests pass, the prototype is showing true behavior rather than masking bugs in the physics.

***

# 17. Performance

## 17.1 Target: Real-Time at 0.01 s Timestep

At dt = 0.01 s the loop needs 100 simulation steps per real second. Each step per vehicle involves filter update, driving model computation, response model, and plant integration — all microsecond-scale scalar operations.

| Fleet size    | Sim only (0.01 s dt) | Sim + Pygame graphics   |
|---------------|----------------------|-------------------------|
| 10 vehicles   | Easily 2000+ steps/s | Easily 30+ FPS          |
| 50 vehicles   | Easily 500+ steps/s  | 20–30 FPS               |
| 100 vehicles  | 100–200 steps/s      | Marginal; profile first |
| 500+ vehicles | Depends on algorithm | Needs vectorisation     |

## 17.2 Common Pitfalls

-   O(n²) leader lookup — maintain a dict keyed on vehicle_id, don't scan all vehicles each step
-   Allocating new dataclass/dict objects in the hot loop — reuse or mutate instead
-   Using NumPy for single scalar values — overhead dominates any benefit at small n

## 17.3 If You Hit a Wall

In rough order of effort:

-   Profile first — use cProfile or py-spy; don't optimise blind
-   Vectorise with NumPy — computing all accelerations as array ops gives 10–50x speedup for 50+ vehicles
-   Reduce render frequency — 5 Hz rendering with 100 Hz simulation is imperceptible
-   Separate processes — run sim and renderer in separate processes communicating via a queue

***

# 18. Step 17 Sensor Validation Suite

A standalone validation suite for the realistic sensor and V2V comms pipeline (Step 17) lives in `Filter_tests/`.  The authoritative validation specification is `Filter_tests/Filter Test Context.docx`.

## 18.1 Purpose and Scope

The suite validates that `DSRCBSMTracker` and `FusionKalmanFilter` work correctly **together** in a running simulation, producing physically sensible results across five qualitatively different drive profile stages.  This is distinct from the unit tests in `tests/test_sensors.py`, which verify individual filter mathematics in isolation.

## 18.2 Test Files

| File | Type | Contents |
|---|---|---|
| `Filter_tests/tests/test_sensors_step17.py` | pytest integration | 4 scenario-level tests: BSM warmup, KF convergence, NaN-safety under high drop rate, bsm_age_s column range |
| `Filter_tests/make_workbooks.py` | build script | Generates all 5 stage Excel workbooks in `Filter_tests/validation/` |
| `Filter_tests/validate_step17.py` | standalone script | Runs all 5 stages + produces diagnostic PNGs |
| `Filter_tests/conftest.py` | pytest config | Adds project root to sys.path for the integration tests |

## 18.3 Scenario Parameters

| Parameter | Value | Rationale |
|---|---|---|
| Vehicles | 4 (1 lead + 3 CACC) | Minimum platoon to observe string stability |
| Cruise speed | 30 m/s | Highway speed; consistent with CACC literature |
| Equilibrium gap | 20 m | `cacc_s0_m + cacc_target_headway_s × v = 2 + 0.6 × 30 = 20 m` |
| Initial positions | V1=100, V2=75, V3=50, V4=25 m | At-equilibrium start, minimal transient |
| CACC desired speed | 33 m/s | 10% above cruise — follower always closing gap error |
| sensor_model | `'kalman'` | Full radar + KF filter pipeline |
| comms_model | `'dsrc'` | DSRCBSMTracker + FusionKalmanFilter active |
| master_seed | 42 | Fixed for reproducibility |

## 18.4 Drive Profile Stages

| Stage | Profile | Duration | Extra panel |
|---|---|---|---|
| 1 | Constant speed 30 m/s | 30 s | — |
| 2 | Step change 30 → 25 m/s at t=10 s | 50 s | — |
| 3 | Linear ramp 30 → 24 m/s over t=10–30 s | 50 s | — |
| 4 | Sinusoidal: N=8 approx, ±2 m/s at 0.1 Hz, 60 s warmup + 5 cycles | 110 s | String stability amplitude |
| 5 | Emergency braking: hard decel to 5 m/s at t=10 s | 30 s | Gap vs. time (all followers) |

## 18.5 Diagnostic Plot Panels

All five stages produce a `stage{N}_diagnostic.png` with the following panels:

1. **Speed vs. time** — all 4 vehicles
2. **Gap tracking (V2)** — true gap (solid black), radar raw (dotted grey), KF estimate (dashed teal)
3. **Gap-rate tracking (V2)** — true rate = V1.v − V2.v; KF rate = `lead_v_meas` − V2.v
4. **Leader acceleration (V2)** — true V1.a (solid black), `lead_a_radar` KF estimate (dashed), `lead_a_v2v` BSM raw (dotted orange)
5. **BSM age timeline** — `bsm_age_s` per follower; sawtooth pattern shows packet arrivals; flat top at stale threshold indicates dropped packet

Stage 4 adds a **string stability amplitude** panel: acceleration amplitude = (max − min)/2 over the last 3 oscillation cycles, plotted vs. platoon position with a dashed reference line at the lead amplitude.

Stage 5 adds a **gap vs. time** panel for all followers, annotated with the minimum gap reached during the braking event.

## 18.6 Sinusoidal Profile Approximation

The sinusoidal speed perturbation uses a piecewise-linear approximation with N=8 waypoints per cycle:

```
t_i = t_warmup + i × (T / N)    for i = 0, 1, …, n_cycles × N
v_i = v₀ + A × sin(2π × i / N)
```

With T = 10 s, N = 8, the step size is 1.25 s/waypoint.  The resulting profile has 42 rows (2 warmup + 40 oscillation waypoints).

## 18.7 Running the Suite

```bash
# Integration tests (from project root)
pytest Filter_tests/tests/ -v

# Full validation with diagnostic plots
python Filter_tests/validate_step17.py

# Generate workbooks only (without running simulation)
python Filter_tests/make_workbooks.py
```

Generated Excel workbooks are gitignored (`Filter_tests/validation/*.xlsx`).
Generated PNGs are also gitignored (`**/*.png` rule in root `.gitignore`).

# 19. Potential Future Enhancements

Features not yet scheduled as numbered development steps, documented here so the interface implications can be considered in advance.

## 19.1 Sinusoidal Lead Input + String Stability Amplitude Plot

**Purpose:** Provide a direct empirical test of string stability. With a sinusoidal speed perturbation at the lead vehicle, string stability requires that peak acceleration amplitude *decreases* down the platoon; string instability manifests as amplitude growth.

### Lead vehicle profile extension

Add a `'sinusoidal'` profile type to `LeadVehicleProfile`. Parameters (added to the Excel simulation sheet or a dedicated profile sheet row):

| Parameter | Description |
|---|---|
| `sine_amplitude_mps` | Speed oscillation amplitude (m/s), e.g. 2.0 |
| `sine_frequency_hz` | Oscillation frequency (Hz), e.g. 0.1–0.5 Hz |
| `sine_offset_mps` | Mean speed around which the sine is centred (m/s) |
| `sine_warmup_s` | Seconds of constant speed before oscillation begins |

Speed profile: `v(t) = sine_offset_mps + sine_amplitude_mps * sin(2π * sine_frequency_hz * (t - sine_warmup_s))` for `t ≥ sine_warmup_s`, else `sine_offset_mps`.

The acceleration profile (derivative) drives the lead `DrivingModelOutput`, or the profile can drive position directly and let `VehiclePlant` integrate.

### String stability amplitude plot

Generated automatically after the run when the sinusoidal profile type is detected — not part of the default five-panel output.

**Layout:** Single panel, saved as `<stem>_stringstability.png` alongside the other individual panel PNGs.

- **X-axis:** Vehicle position in platoon (1 = lead, 2 = first follower, …); integer ticks, labelled with vehicle ID
- **Y-axis:** Peak acceleration amplitude (m/s²) measured over the steady-state oscillation window (after `sine_warmup_s`)
- **Series:** One dot per vehicle connected by a line, coloured by model using `MODEL_COLORS_PLOT`
- **Reference line:** Horizontal dashed line at the lead vehicle's amplitude — the boundary between stable (dots below) and unstable (dots above)
- **Annotation:** Text box (upper right) listing CACC gains (`k1`, `k2`, `k_ff`, `T_h`) and a pass/fail label: "String stable ✓" if all follower amplitudes ≤ lead amplitude, else "String unstable ✗ (gain = {max_ratio:.2f}×)" where `max_ratio` is the largest follower/lead amplitude ratio

**Peak detection:** Measure the last N complete cycles (N ≥ 3 recommended) after the warmup period. `max(|a|)` over that window is the amplitude for each vehicle. Exclude the warmup window entirely to avoid transient contamination.

**Implementation notes:**
- Add `profile_type` field to `SimConfig` (or detect from the profile sheet); `plot_run()` checks this before generating the plot
- The existing `output.py` `save_run()` call passes `config` through to `plot_run()` — no interface change needed if `SimConfig` carries the flag
- For the theoretical string-stability condition overlay, the closed-loop transfer function magnitude at the test frequency can be computed from the CACC gains and compared to 1.0; annotate as "Theoretical: stable" / "unstable" alongside the empirical result

***
