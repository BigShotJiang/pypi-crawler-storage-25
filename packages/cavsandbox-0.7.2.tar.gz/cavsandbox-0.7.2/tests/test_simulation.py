"""Tests for cacc_sim/simulation.py — SimulationLoop (Step 7)."""
import openpyxl
import pandas as pd
import pytest
from pathlib import Path

from cacc_sim.core import DrivingModel, DrivingModelOutput, VehicleState
from cacc_sim.driving_models import IDMModel, LeadVehicleModel
from cacc_sim.filters import PassthroughFilter
from cacc_sim.loader import SimConfig, load_vehicles
from cacc_sim.plant import VehiclePlant, VehicleResponseModel
from cacc_sim.profile import LeadVehicleProfile
from cacc_sim.simulation import SimulationLoop
from cacc_sim.vehicle import Vehicle


class _FullThrottleModel(DrivingModel):
    """Always commands a large acceleration — forces a collision for testing."""

    def compute(self, state: VehicleState) -> DrivingModelOutput:
        return DrivingModelOutput(acceleration=10.0)

    @classmethod
    def required_inputs(cls) -> set[str]:
        return set()

    @classmethod
    def from_excel_row(cls, row, sim_config):
        raise NotImplementedError


# ---------------------------------------------------------------------------
# Helpers — build vehicles directly (no Excel)
# ---------------------------------------------------------------------------

def _constant_profile(speed: float = 20.0) -> LeadVehicleProfile:
    """A flat profile that holds a single speed forever."""
    df = pd.DataFrame({'time_s': [0.0, 9999.0], 'value': [speed, speed], 'transition': ['ramp', 'ramp']})
    return LeadVehicleProfile(df)


def _ramp_profile(v_start: float = 20.0, v_end: float = 30.0, t_end: float = 10.0) -> LeadVehicleProfile:
    df = pd.DataFrame({'time_s': [0.0, t_end], 'value': [v_start, v_end], 'transition': ['ramp', 'ramp']})
    return LeadVehicleProfile(df)


def _kinematic_config(**overrides) -> SimConfig:
    """SimConfig with kinematic response model and short duration."""
    cfg = SimConfig(response_model='kinematic', duration_s=5.0)
    for k, v in overrides.items():
        setattr(cfg, k, v)
    return cfg


def _make_lead_vehicle(x0: float = 100.0, v0: float = 20.0, profile=None) -> Vehicle:
    if profile is None:
        profile = _constant_profile(v0)
    return Vehicle(
        id=1,
        model=LeadVehicleModel(profile=profile),
        response=VehicleResponseModel(mode='kinematic'),
        plant=VehiclePlant(x0=x0, v0=v0, length=5.0),
        filter_=PassthroughFilter(),
        leader_id=None,
    )


def _make_follower_vehicle(x0: float = 70.0, v0: float = 20.0,
                           desired_speed: float = 30.0, time_headway: float = 1.5) -> Vehicle:
    return Vehicle(
        id=2,
        model=IDMModel(desired_speed=desired_speed, time_headway=time_headway),
        response=VehicleResponseModel(mode='kinematic'),
        plant=VehiclePlant(x0=x0, v0=v0, length=5.0),
        filter_=PassthroughFilter(),
        leader_id=1,
    )


def _run(vehicles, duration_s=5.0) -> pd.DataFrame:
    config = _kinematic_config(duration_s=duration_s)
    loop = SimulationLoop(vehicles, config)
    return loop.run()


# ---------------------------------------------------------------------------
# Basic output structure
# ---------------------------------------------------------------------------

def test_run_returns_dataframe():
    vehicles = [_make_lead_vehicle()]
    df = _run(vehicles)
    assert isinstance(df, pd.DataFrame)


def test_output_has_required_columns():
    vehicles = [_make_lead_vehicle()]
    df = _run(vehicles)
    for col in ('t', 'id', 'x', 'v', 'a', 'gap', 'model'):
        assert col in df.columns, f"Missing column: {col}"


def test_row_count_matches_steps_times_vehicles():
    """With default log_rate_hz=10, rows = round(duration * log_rate_hz) * n_vehicles."""
    config = _kinematic_config(duration_s=1.0)  # log_rate_hz=10 by default
    vehicles = [_make_lead_vehicle(), _make_follower_vehicle()]
    loop = SimulationLoop(vehicles, config)
    df = loop.run()
    expected_logged = round(1.0 * config.log_rate_hz)   # 10 Hz × 1 s = 10
    assert len(df) == expected_logged * 2


def test_model_name_column_correct():
    vehicles = [_make_lead_vehicle(), _make_follower_vehicle()]
    df = _run(vehicles)
    lead_rows = df[df['id'] == 1]
    follow_rows = df[df['id'] == 2]
    assert (lead_rows['model'] == 'LeadVehicleModel').all()
    assert (follow_rows['model'] == 'IDMModel').all()


# ---------------------------------------------------------------------------
# Speed invariants
# ---------------------------------------------------------------------------

def test_speed_never_negative_single_vehicle():
    """Even with strong braking, speed stays ≥ 0."""
    # Start at rest with heavy braking command; plant clamps to 0
    vehicles = [_make_lead_vehicle(v0=0.0, profile=_constant_profile(0.0))]
    df = _run(vehicles, duration_s=2.0)
    assert (df['v'] >= 0.0).all()


def test_speed_never_negative_two_vehicles():
    lead   = _make_lead_vehicle(v0=20.0)
    follow = _make_follower_vehicle(v0=20.0)
    df = _run([lead, follow], duration_s=10.0)
    assert (df['v'] >= 0.0).all()


# ---------------------------------------------------------------------------
# Lead vehicle profile tracking
# ---------------------------------------------------------------------------

def test_single_lead_vehicle_constant_speed_stays_constant():
    """
    With a flat profile and kinematic response, lead vehicle should maintain
    speed within a small tolerance after a brief transient.
    """
    config = _kinematic_config(duration_s=5.0)
    lead = _make_lead_vehicle(v0=20.0, profile=_constant_profile(20.0))
    loop = SimulationLoop([lead], config)
    df = loop.run()
    lead_df = df[df['id'] == 1]
    # After settling, speed should be close to 20 m/s (LeadVehicleModel tracks profile)
    final_speeds = lead_df.tail(50)['v']
    assert (final_speeds - 20.0).abs().max() < 0.5


def test_lead_vehicle_position_increases_monotonically():
    """A moving lead vehicle's position should always increase."""
    lead = _make_lead_vehicle(v0=20.0, profile=_constant_profile(20.0))
    df = _run([lead], duration_s=5.0)
    positions = df[df['id'] == 1]['x'].to_numpy()
    assert (positions[1:] >= positions[:-1]).all()


# ---------------------------------------------------------------------------
# Two-vehicle gap dynamics
# ---------------------------------------------------------------------------

def test_initial_gap_reasonable():
    """Gap on first logged row should match initial geometry."""
    lead   = _make_lead_vehicle(x0=100.0, v0=20.0)
    follow = _make_follower_vehicle(x0=70.0, v0=20.0)
    df = _run([lead, follow])
    first_follow = df[(df['id'] == 2)].iloc[0]
    # gap = leader.x - follower.x - leader.length = 100 - 70 - 5 = 25
    assert first_follow['gap'] == pytest.approx(25.0, abs=0.5)


def test_gap_never_negative():
    """IDM gap constraint: follower should not ram the leader under normal conditions."""
    lead   = _make_lead_vehicle(x0=100.0, v0=20.0)
    follow = _make_follower_vehicle(x0=70.0, v0=20.0)
    df = _run([lead, follow], duration_s=30.0)
    follow_df = df[df['id'] == 2]
    assert (follow_df['gap'] >= 0.0).all()


def test_follower_gap_converges():
    """
    When started far from equilibrium headway, IDM gap error should decrease
    over the simulation window (convergence check).
    """
    # Lead steady at 20 m/s; follower desired 30 m/s, headway 1.5 s
    # IDM equilibrium gap = s0 + T*v = 2 + 1.5*20 = 32 m
    lead   = _make_lead_vehicle(x0=200.0, v0=20.0, profile=_constant_profile(20.0))
    follow = _make_follower_vehicle(x0=70.0, v0=20.0, desired_speed=30.0, time_headway=1.5)
    config = _kinematic_config(duration_s=60.0)
    loop = SimulationLoop([lead, follow], config)
    df = loop.run()
    follow_df = df[df['id'] == 2]
    equilibrium_gap = 2.0 + 1.5 * 20.0   # s0 + T * v
    early_error = abs(follow_df.iloc[0]['gap'] - equilibrium_gap)
    late_error  = abs(follow_df.iloc[-1]['gap'] - equilibrium_gap)
    assert late_error < early_error, (
        f"Gap error did not decrease: early={early_error:.2f}, late={late_error:.2f}"
    )


# ---------------------------------------------------------------------------
# Time column
# ---------------------------------------------------------------------------

def test_time_column_starts_at_zero():
    lead = _make_lead_vehicle()
    df = _run([lead])
    assert df['t'].iloc[0] == pytest.approx(0.0)


def test_time_column_increments_by_log_interval():
    lead = _make_lead_vehicle()
    # 0.5 s at default log_rate_hz=10 → 5 logged rows at t=0.0,0.1,0.2,0.3,0.4
    df = _run([lead], duration_s=0.5)
    times = df['t'].unique()
    diffs = pd.Series(sorted(times)).diff().dropna()
    # log interval = 1/log_rate_hz = 0.1 s
    assert (diffs - 0.1).abs().max() < 1e-9


# ---------------------------------------------------------------------------
# Integration test — real Excel file via tmp_path
# ---------------------------------------------------------------------------

def _write_minimal_excel(path: Path) -> None:
    """Write a minimal valid 2-vehicle Excel workbook (kinematic mode, short run)."""
    wb = openpyxl.Workbook()
    ws_v = wb.active
    ws_v.title = 'vehicles'
    headers = ['vehicle_id', 'model', 'initial_position_m', 'initial_speed_mps',
               'vehicle_length_m', 'leader_id', 'filter',
               'desired_speed_mps', 'time_headway_s']
    ws_v.append(headers)
    ws_v.append([1, 'LEAD_PROFILE', 100.0, 20.0, 5.0, None, 'passthrough', None, None])
    ws_v.append([2, 'IDMModel',      70.0, 20.0, 5.0,    1, 'passthrough', 30.0, 1.5])

    ws_s = wb.create_sheet('simulation')
    for key, val in [('duration_s', 2.0), ('response_model', 'kinematic')]:
        ws_s.append([key, val])

    ws_p = wb.create_sheet('profile')
    ws_p.append(['time_s', 'value', 'transition'])
    ws_p.append([0.0, 20.0, 'ramp'])
    ws_p.append([10.0, 20.0, 'ramp'])  # constant speed

    wb.save(str(path))


def test_end_to_end_via_excel(tmp_path):
    """Full pipeline: Excel → load_vehicles → SimulationLoop → DataFrame."""
    excel_path = tmp_path / 'sim_test.xlsx'
    _write_minimal_excel(excel_path)
    vehicles, config = load_vehicles(str(excel_path))

    loop = SimulationLoop(vehicles, config)
    df = loop.run()

    assert isinstance(df, pd.DataFrame)
    assert set(df['id'].unique()) == {1, 2}
    # 2 s at default log_rate_hz=10 → 20 logged steps × 2 vehicles = 40 rows
    assert len(df) == 40
    assert (df['v'] >= 0.0).all()


# ---------------------------------------------------------------------------
# Collision detection
# ---------------------------------------------------------------------------

def _make_collision_scenario() -> tuple[list[Vehicle], SimConfig]:
    """
    Lead vehicle at constant 20 m/s; follower starts 3 m behind and commands
    full-throttle (10 m/s²).  Gap will go negative well within 10 s.
    """
    profile = LeadVehicleProfile(pd.DataFrame({
        'time_s': [0.0, 9999.0], 'value': [20.0, 20.0], 'transition': ['ramp', 'ramp'],
    }))
    lead = Vehicle(
        id=1,
        model=LeadVehicleModel(profile=profile),
        response=VehicleResponseModel(mode='kinematic'),
        plant=VehiclePlant(x0=100.0, v0=20.0, length=5.0),
        filter_=PassthroughFilter(),
        leader_id=None,
    )
    # Start the follower only 3 m behind — gap = 100 - 95 - 5 = 0 m initially,
    # so place at x=90 giving gap = 100 - 90 - 5 = 5 m.
    follower = Vehicle(
        id=2,
        model=_FullThrottleModel(),
        response=VehicleResponseModel(mode='kinematic'),
        plant=VehiclePlant(x0=90.0, v0=20.0, length=5.0),
        filter_=PassthroughFilter(),
        leader_id=1,
    )
    config = SimConfig(duration_s=10.0, response_model='kinematic')
    return [lead, follower], config


def test_collision_stops_simulation_early():
    """Simulation returns a partial DataFrame when a collision is detected."""
    vehicles, config = _make_collision_scenario()
    loop = SimulationLoop(vehicles, config)
    df = loop.run()
    full_steps = round(config.duration_s / config.timestep_s)  # 1000
    # Collision must have occurred before the end; rows < full_steps * n_vehicles
    assert len(df) < full_steps * len(vehicles)


def test_collision_row_included_in_output():
    """The row that triggered the collision (gap < 0) must be present."""
    vehicles, config = _make_collision_scenario()
    loop = SimulationLoop(vehicles, config)
    df = loop.run()
    follower_df = df[df['id'] == 2]
    assert (follower_df['gap'] < 0).any(), 'Expected at least one negative-gap row'


def test_collision_warning_to_stderr(capsys):
    """run() must print a WARNING message to stderr when a collision occurs."""
    vehicles, config = _make_collision_scenario()
    loop = SimulationLoop(vehicles, config)
    loop.run()
    captured = capsys.readouterr()
    assert 'WARNING' in captured.err
    assert 'Collision' in captured.err or 'collision' in captured.err


def test_normal_run_no_collision_warning(capsys):
    """A well-behaved IDM run must not emit any collision warning."""
    lead   = _make_lead_vehicle(x0=100.0, v0=20.0)
    follow = _make_follower_vehicle(x0=70.0, v0=20.0)
    config = _kinematic_config(duration_s=5.0)
    loop   = SimulationLoop([lead, follow], config)
    loop.run()
    captured = capsys.readouterr()
    assert 'WARNING' not in captured.err
