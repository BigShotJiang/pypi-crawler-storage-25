"""Tests for cacc_sim/core.py — dataclasses and ABCs (Step 1)."""
import pytest

from cacc_sim.core import (
    DrivingModel,
    DrivingModelOutput,
    Filter,
    FilterInput,
    FilterOutput,
    VehicleState,
)


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _make_state(**overrides) -> VehicleState:
    """Build a VehicleState with sensible defaults for the 6 required fields."""
    defaults = dict(
        speed=20.0,
        acceleration=0.0,
        time=0.0,
        position=0.0,
        gap=10.0,
        lead_speed=20.0,
    )
    defaults.update(overrides)
    return VehicleState(**defaults)


# ---------------------------------------------------------------------------
# VehicleState — dataclass basics
# ---------------------------------------------------------------------------

def test_vehicle_state_required_fields_stored():
    s = _make_state()
    assert s.speed == 20.0
    assert s.acceleration == 0.0
    assert s.time == 0.0
    assert s.position == 0.0
    assert s.gap == 10.0
    assert s.lead_speed == 20.0


def test_vehicle_state_optional_field_defaults():
    s = _make_state()
    assert s.lead_a_radar == 0.0    # radar-estimated; 0.0 until EIDM is implemented
    assert s.lead_a_v2v   == 0.0    # BSM feedforward; 0.0 when unavailable
    assert s.lead_max_decel is None
    assert s.leader_speed is None
    assert s.leader_acceleration is None
    assert s.is_string_leader is False
    assert s.driving_mode is None
    assert s.extras == {}


def test_vehicle_state_extras_default_is_independent():
    """Two VehicleState instances must not share the same extras dict."""
    s1 = _make_state()
    s2 = _make_state()
    s1.extras["key"] = "value"
    assert "key" not in s2.extras


def test_vehicle_state_all_optional_fields_round_trip():
    s = _make_state(
        lead_a_radar=0.5,
        lead_a_v2v=1.2,
        lead_max_decel=4.0,
        leader_speed=25.0,
        leader_acceleration=0.3,
        is_string_leader=True,
        driving_mode="CACC",
        extras={"custom": 42},
    )
    assert s.lead_a_radar == 0.5
    assert s.lead_a_v2v   == 1.2
    assert s.lead_max_decel == 4.0
    assert s.leader_speed == 25.0
    assert s.leader_acceleration == 0.3
    assert s.is_string_leader is True
    assert s.driving_mode == "CACC"
    assert s.extras["custom"] == 42


# ---------------------------------------------------------------------------
# DrivingModelOutput
# ---------------------------------------------------------------------------

def test_driving_model_output_stores_acceleration():
    out = DrivingModelOutput(acceleration=1.5)
    assert out.acceleration == 1.5


def test_driving_model_output_zero():
    out = DrivingModelOutput(acceleration=0.0)
    assert out.acceleration == 0.0


# ---------------------------------------------------------------------------
# FilterInput and FilterOutput
# ---------------------------------------------------------------------------

def test_filter_input_required_fields():
    fi = FilterInput(timestamp=0.1, raw_value=5.0)
    assert fi.timestamp == 0.1
    assert fi.raw_value == 5.0
    assert fi.gps_covariance is None
    assert fi.extras == {}


def test_filter_input_extras_default_is_independent():
    fi1 = FilterInput(timestamp=0.0, raw_value=1.0)
    fi2 = FilterInput(timestamp=0.0, raw_value=2.0)
    fi1.extras["x"] = 99
    assert "x" not in fi2.extras


def test_filter_output_stores_fields():
    fo = FilterOutput(filtered_value=3.0, confidence=0.9)
    assert fo.filtered_value == 3.0
    assert fo.confidence == 0.9


# ---------------------------------------------------------------------------
# DrivingModel ABC enforcement
# ---------------------------------------------------------------------------

def test_driving_model_cannot_instantiate_directly():
    with pytest.raises(TypeError):
        DrivingModel()  # type: ignore[abstract]


def test_driving_model_missing_compute_raises():
    class NoCompute(DrivingModel):
        @classmethod
        def required_inputs(cls):
            return {"speed"}

    with pytest.raises(TypeError):
        NoCompute()


def test_driving_model_missing_required_inputs_raises():
    class NoRequiredInputs(DrivingModel):
        def compute(self, state):
            return DrivingModelOutput(acceleration=0.0)

    with pytest.raises(TypeError):
        NoRequiredInputs()


def test_driving_model_concrete_subclass_works():
    class MinimalModel(DrivingModel):
        @classmethod
        def required_inputs(cls):
            return {"speed", "gap"}

        def compute(self, state):
            return DrivingModelOutput(acceleration=0.0)

    m = MinimalModel()
    result = m.compute(_make_state())
    assert isinstance(result, DrivingModelOutput)
    assert MinimalModel.required_inputs() == {"speed", "gap"}


def test_driving_model_required_inputs_callable_on_class():
    class AModel(DrivingModel):
        @classmethod
        def required_inputs(cls):
            return {"speed"}

        def compute(self, state):
            return DrivingModelOutput(acceleration=0.0)

    # Must be callable without instantiation
    assert AModel.required_inputs() == {"speed"}


# ---------------------------------------------------------------------------
# Filter ABC enforcement
# ---------------------------------------------------------------------------

def test_filter_cannot_instantiate_directly():
    with pytest.raises(TypeError):
        Filter()  # type: ignore[abstract]


def test_filter_concrete_subclass_works():
    class MinimalFilter(Filter):
        def update(self, input: FilterInput) -> FilterOutput:
            return FilterOutput(filtered_value=input.raw_value, confidence=1.0)

    f = MinimalFilter()
    result = f.update(FilterInput(timestamp=0.0, raw_value=5.0))
    assert result.filtered_value == 5.0
    assert result.confidence == 1.0


def test_filter_required_fields_default_returns_empty_set():
    class MinimalFilter(Filter):
        def update(self, input):
            return FilterOutput(filtered_value=0.0, confidence=1.0)

    assert MinimalFilter.required_fields() == set()


def test_filter_required_extras_default_returns_empty_set():
    class MinimalFilter(Filter):
        def update(self, input):
            return FilterOutput(filtered_value=0.0, confidence=1.0)

    assert MinimalFilter.required_extras() == set()
