"""Tests for cacc_sim/loader.py — validation and parameter resolution (Step 6)."""
import io
import tempfile
from pathlib import Path

import numpy as np
import openpyxl
import pandas as pd
import pytest

from cacc_sim.loader import (
    SimConfig,
    _RESPONSE_DEFAULTS,
    load_vehicles,
    resolve_param,
    validate_vehicle_df,
)


# ---------------------------------------------------------------------------
# Helpers — build minimal valid DataFrames
# ---------------------------------------------------------------------------

_REQUIRED = dict(
    vehicle_id=1,
    model='LEAD_PROFILE',
    initial_position_m=100.0,
    initial_speed_mps=20.0,
    vehicle_length_m=5.0,
    leader_id=None,
    filter='passthrough',
)

_FOLLOWER = dict(
    vehicle_id=2,
    model='IDMModel',
    initial_position_m=70.0,
    initial_speed_mps=20.0,
    vehicle_length_m=5.0,
    leader_id=1,
    filter='passthrough',
    desired_speed_mps=30.0,
    time_headway_s=1.5,
)


def _df(*rows) -> pd.DataFrame:
    """Build a vehicles DataFrame from a list of row dicts."""
    return pd.DataFrame(rows)


def _valid_two_vehicle_df() -> pd.DataFrame:
    return _df(_REQUIRED, _FOLLOWER)


def _default_config() -> SimConfig:
    return SimConfig()


# ---------------------------------------------------------------------------
# validate_vehicle_df — required columns
# ---------------------------------------------------------------------------

def test_missing_required_column_raises():
    df = _valid_two_vehicle_df().drop(columns=['vehicle_length_m'])
    with pytest.raises(ValueError, match="vehicle_length_m"):
        validate_vehicle_df(df)


def test_valid_df_does_not_raise():
    validate_vehicle_df(_valid_two_vehicle_df())


# ---------------------------------------------------------------------------
# validate_vehicle_df — vehicle_id uniqueness
# ---------------------------------------------------------------------------

def test_duplicate_vehicle_id_raises():
    row_a = dict(_REQUIRED)
    row_b = dict(_REQUIRED)  # same id=1
    row_b['initial_position_m'] = 200.0
    df = _df(row_a, row_b)
    with pytest.raises(ValueError, match="Duplicate"):
        validate_vehicle_df(df)


# ---------------------------------------------------------------------------
# validate_vehicle_df — model and filter registry
# ---------------------------------------------------------------------------

def test_unknown_model_raises():
    row = dict(_REQUIRED, model='QuantumTunnelModel')
    df = _df(row, _FOLLOWER)
    with pytest.raises(ValueError, match="Unknown model"):
        validate_vehicle_df(df)


def test_unknown_filter_raises():
    row = dict(_REQUIRED, filter='magic_filter')
    df = _df(row, _FOLLOWER)
    with pytest.raises(ValueError, match="Unknown filter"):
        validate_vehicle_df(df)


# ---------------------------------------------------------------------------
# validate_vehicle_df — model-conditional required columns
# ---------------------------------------------------------------------------

def test_idm_missing_desired_speed_raises():
    follower = dict(_FOLLOWER)
    del follower['desired_speed_mps']
    df = _df(_REQUIRED, follower)
    with pytest.raises(ValueError, match="desired_speed_mps"):
        validate_vehicle_df(df)


def test_idm_missing_time_headway_raises():
    follower = dict(_FOLLOWER)
    del follower['time_headway_s']
    df = _df(_REQUIRED, follower)
    with pytest.raises(ValueError, match="time_headway_s"):
        validate_vehicle_df(df)


def test_lead_profile_does_not_require_idm_columns():
    """LEAD_PROFILE vehicle without IDM columns must not raise."""
    df = _df(_REQUIRED)   # single lead vehicle only, no follower
    # Modify so it's just a lead vehicle scenario (no topology error)
    validate_vehicle_df(df)


# ---------------------------------------------------------------------------
# validate_vehicle_df — range checks
# ---------------------------------------------------------------------------

def test_negative_position_raises():
    row = dict(_REQUIRED, initial_position_m=-1.0)
    df = _df(row, _FOLLOWER)
    with pytest.raises(ValueError, match="initial_position_m"):
        validate_vehicle_df(df)


def test_zero_vehicle_length_raises():
    row = dict(_REQUIRED, vehicle_length_m=0.0)
    df = _df(row, _FOLLOWER)
    with pytest.raises(ValueError, match="vehicle_length_m"):
        validate_vehicle_df(df)


def test_negative_speed_raises():
    row = dict(_REQUIRED, initial_speed_mps=-5.0)
    df = _df(row, _FOLLOWER)
    with pytest.raises(ValueError, match="initial_speed_mps"):
        validate_vehicle_df(df)


# ---------------------------------------------------------------------------
# validate_vehicle_df — leader_id topology
# ---------------------------------------------------------------------------

def test_no_blank_leader_id_raises():
    """Zero lead vehicles (all have a leader_id) → error."""
    row_a = dict(_FOLLOWER, vehicle_id=1, leader_id=2)
    row_b = dict(_FOLLOWER, vehicle_id=2, leader_id=1)
    row_a['model'] = 'IDMModel'
    row_b['model'] = 'IDMModel'
    df = _df(row_a, row_b)
    with pytest.raises(ValueError, match="No lead vehicle"):
        validate_vehicle_df(df)


def test_two_blank_leader_ids_raises():
    """Two lead vehicles → error."""
    lead_a = dict(_REQUIRED, vehicle_id=1)
    lead_b = dict(_REQUIRED, vehicle_id=2, initial_position_m=200.0)
    df = _df(lead_a, lead_b)
    with pytest.raises(ValueError, match="exactly one is required"):
        validate_vehicle_df(df)


def test_invalid_leader_id_reference_raises():
    follower = dict(_FOLLOWER, leader_id=99)  # 99 doesn't exist
    df = _df(_REQUIRED, follower)
    with pytest.raises(ValueError, match="does not reference a valid vehicle_id"):
        validate_vehicle_df(df)


def test_circular_chain_raises():
    """A → B → A is circular."""
    row_a = dict(_FOLLOWER, vehicle_id=1, leader_id=2, model='IDMModel')
    row_b = dict(_FOLLOWER, vehicle_id=2, leader_id=1, model='IDMModel')
    # Manufacture a lead vehicle to satisfy the one-blank rule separately;
    # here we just test circular detection — patch so validation reaches it.
    # Use a three-vehicle chain: lead(3)→A(1)→B(2)→A(1) circular
    lead   = dict(_REQUIRED, vehicle_id=3)
    row_a2 = dict(_FOLLOWER, vehicle_id=1, leader_id=2)
    row_b2 = dict(_FOLLOWER, vehicle_id=2, leader_id=1)
    df = _df(lead, row_a2, row_b2)
    with pytest.raises(ValueError, match="[Cc]ircular"):
        validate_vehicle_df(df)


def test_exactly_one_blank_leader_id_is_valid():
    validate_vehicle_df(_valid_two_vehicle_df())


# ---------------------------------------------------------------------------
# validate_vehicle_df — lead vehicle must use LEAD_PROFILE
# ---------------------------------------------------------------------------

def test_lead_vehicle_wrong_model_raises():
    lead = dict(_REQUIRED, model='IDMModel',
                desired_speed_mps=30.0, time_headway_s=1.5)
    df = _df(lead, _FOLLOWER)
    with pytest.raises(ValueError, match="LEAD_PROFILE"):
        validate_vehicle_df(df)


# ---------------------------------------------------------------------------
# validate_vehicle_df — vehicle_types sheet
# ---------------------------------------------------------------------------

def _type_table(rows: list[dict]) -> pd.DataFrame:
    return pd.DataFrame(rows).set_index('type_id')


def test_vehicle_type_not_in_table_raises():
    df = _valid_two_vehicle_df().copy()
    df['vehicle_type'] = [None, 'ghost_type']
    type_table = _type_table([{
        'type_id': 'car', 'tau_throttle_s': 0.5, 'tau_brake_s': 0.3,
        'a_max_mps2': 2.5, 'a_min_mps2': -8.0, 'j_max_mps3': 5.0,
    }])
    with pytest.raises(ValueError, match="ghost_type"):
        validate_vehicle_df(df, type_table)


def test_vehicle_type_column_without_sheet_raises():
    df = _valid_two_vehicle_df().copy()
    df['vehicle_type'] = [None, 'heavy_truck']
    with pytest.raises(ValueError, match="vehicle_types sheet is absent"):
        validate_vehicle_df(df, type_table=None)


def test_type_table_negative_a_max_raises():
    df = _valid_two_vehicle_df()
    type_table = _type_table([{
        'type_id': 'bad', 'tau_throttle_s': 0.5, 'tau_brake_s': 0.3,
        'a_max_mps2': -1.0, 'a_min_mps2': -8.0, 'j_max_mps3': 5.0,
    }])
    with pytest.raises(ValueError, match="a_max_mps2"):
        validate_vehicle_df(df, type_table)


def test_type_table_positive_a_min_raises():
    df = _valid_two_vehicle_df()
    type_table = _type_table([{
        'type_id': 'bad', 'tau_throttle_s': 0.5, 'tau_brake_s': 0.3,
        'a_max_mps2': 2.5, 'a_min_mps2': 3.0, 'j_max_mps3': 5.0,
    }])
    with pytest.raises(ValueError, match="a_min_mps2"):
        validate_vehicle_df(df, type_table)


# ---------------------------------------------------------------------------
# resolve_param — four-level hierarchy
# ---------------------------------------------------------------------------

def _row(**kwargs) -> pd.Series:
    return pd.Series(kwargs)


def _type_row(**kwargs) -> pd.Series:
    return pd.Series(kwargs)


def test_resolve_level1_per_vehicle_wins():
    """Non-blank per-vehicle value overrides everything."""
    row     = _row(tau_throttle_s=0.7)
    type_r  = _type_row(tau_throttle_s=0.9)
    config  = SimConfig(tau_throttle_s=0.6)
    assert resolve_param('tau_throttle_s', row, type_r, config) == pytest.approx(0.7)


def test_resolve_level2_type_wins_over_config():
    """Blank per-vehicle → type row value used."""
    row    = _row(tau_throttle_s=None)
    type_r = _type_row(tau_throttle_s=0.9)
    config = SimConfig(tau_throttle_s=0.6)
    assert resolve_param('tau_throttle_s', row, type_r, config) == pytest.approx(0.9)


def test_resolve_level3_config_wins_over_default():
    """No per-vehicle, no type row → sim config value used."""
    row    = _row(tau_throttle_s=None)
    config = SimConfig(tau_throttle_s=0.6)
    assert resolve_param('tau_throttle_s', row, None, config) == pytest.approx(0.6)


def test_resolve_level4_hardcoded_default():
    """Param absent from row, no type row, not on config → hardcoded default."""
    row    = _row()  # param not present
    config = SimConfig()
    # Remove the attribute to test level-4 fallback
    delattr(config, 'tau_throttle_s')
    result = resolve_param('tau_throttle_s', row, None, config)
    assert result == pytest.approx(_RESPONSE_DEFAULTS['tau_throttle_s'])


def test_resolve_all_five_params_independently():
    """Each of the five params resolves independently through the hierarchy."""
    row    = _row(tau_throttle_s=0.8, a_max_mps2=None)
    type_r = _type_row(a_max_mps2=1.2, tau_brake_s=None)
    config = SimConfig(tau_brake_s=0.4, a_min_mps2=-5.0, j_max_mps3=4.0)
    assert resolve_param('tau_throttle_s', row, type_r, config) == pytest.approx(0.8)  # L1
    assert resolve_param('a_max_mps2',     row, type_r, config) == pytest.approx(1.2)  # L2
    assert resolve_param('tau_brake_s',    row, type_r, config) == pytest.approx(0.4)  # L3
    assert resolve_param('a_min_mps2',     row, type_r, config) == pytest.approx(-5.0) # L3
    assert resolve_param('j_max_mps3',     row, type_r, config) == pytest.approx(4.0)  # L3


def test_resolve_level1_nan_treated_as_blank():
    """NaN in per-vehicle column should fall through to level 2."""
    row    = _row(tau_throttle_s=float('nan'))
    type_r = _type_row(tau_throttle_s=0.9)
    config = SimConfig()
    assert resolve_param('tau_throttle_s', row, type_r, config) == pytest.approx(0.9)


# ---------------------------------------------------------------------------
# Integration test — real Excel file via tmp_path
# ---------------------------------------------------------------------------

def _write_minimal_excel(path: Path) -> None:
    """Write a minimal valid 2-vehicle Excel workbook to path."""
    wb = openpyxl.Workbook()

    # vehicles sheet
    ws_v = wb.active
    ws_v.title = 'vehicles'
    headers = ['vehicle_id', 'model', 'initial_position_m', 'initial_speed_mps',
               'vehicle_length_m', 'leader_id', 'filter',
               'desired_speed_mps', 'time_headway_s']
    ws_v.append(headers)
    ws_v.append([1, 'LEAD_PROFILE', 100.0, 20.0, 5.0, None, 'passthrough', None, None])
    ws_v.append([2, 'IDMModel',       70.0, 20.0, 5.0, 1,    'passthrough', 30.0, 1.5])

    # simulation sheet (key-value pairs)
    ws_s = wb.create_sheet('simulation')
    for key, val in [('duration_s', 1.0), ('response_model', 'kinematic')]:
        ws_s.append([key, val])

    # profile sheet
    ws_p = wb.create_sheet('profile')
    ws_p.append(['time_s', 'value', 'transition'])
    ws_p.append([0.0, 20.0, 'ramp'])
    ws_p.append([10.0, 30.0, 'ramp'])

    wb.save(str(path))


def test_load_vehicles_integration(tmp_path):
    excel_path = tmp_path / 'test_scenario.xlsx'
    _write_minimal_excel(excel_path)
    vehicles, config = load_vehicles(str(excel_path))

    assert len(vehicles) == 2
    assert vehicles[0].leader_id is None        # lead vehicle first
    assert vehicles[1].leader_id == 1
    assert config.response_model == 'kinematic'
    assert config.duration_s == pytest.approx(1.0)
