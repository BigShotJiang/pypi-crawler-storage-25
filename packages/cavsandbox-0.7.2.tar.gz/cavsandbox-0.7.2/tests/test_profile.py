"""Tests for cacc_sim/profile.py — LeadVehicleProfile (Step 5)."""
import pandas as pd
import pytest

from cacc_sim.profile import LeadVehicleProfile


def _profile(*rows) -> LeadVehicleProfile:
    """Build a LeadVehicleProfile from (time_s, value, transition) tuples."""
    df = pd.DataFrame(rows, columns=['time_s', 'value', 'transition'])
    return LeadVehicleProfile(df)


def _ramp_profile() -> LeadVehicleProfile:
    """Simple two-event ramp: 20 m/s at t=0, 30 m/s at t=10."""
    return _profile((0.0, 20.0, 'ramp'), (10.0, 30.0, 'ramp'))


def _step_profile() -> LeadVehicleProfile:
    """Two-event step: 20 m/s until t=5, then 30 m/s."""
    return _profile((0.0, 20.0, 'step'), (5.0, 30.0, 'step'))


# ---------------------------------------------------------------------------
# Hold behaviour at boundaries
# ---------------------------------------------------------------------------

def test_before_first_event_returns_first_value():
    p = _ramp_profile()
    assert p.get_speed_target(-1.0) == pytest.approx(20.0)


def test_at_first_event_returns_first_value():
    p = _ramp_profile()
    assert p.get_speed_target(0.0) == pytest.approx(20.0)


def test_after_last_event_returns_last_value():
    p = _ramp_profile()
    assert p.get_speed_target(100.0) == pytest.approx(30.0)


def test_at_last_event_returns_last_value():
    p = _ramp_profile()
    assert p.get_speed_target(10.0) == pytest.approx(30.0)


# ---------------------------------------------------------------------------
# Ramp interpolation
# ---------------------------------------------------------------------------

def test_ramp_midpoint_is_average():
    """At t=5 (midpoint of [0,10]), result should be average of 20 and 30."""
    p = _ramp_profile()
    assert p.get_speed_target(5.0) == pytest.approx(25.0)


def test_ramp_quarter_point():
    """At t=2.5 (25% through [0,10]), result should be 20 + 0.25*10 = 22.5."""
    p = _ramp_profile()
    assert p.get_speed_target(2.5) == pytest.approx(22.5)


def test_ramp_just_before_end():
    p = _ramp_profile()
    v = p.get_speed_target(9.99)
    assert 29.0 < v < 30.0


def test_ramp_is_monotone_increasing():
    """For a speed-increasing ramp, values should be monotone."""
    p = _ramp_profile()
    times = [0.0, 2.5, 5.0, 7.5, 10.0]
    speeds = [p.get_speed_target(t) for t in times]
    assert speeds == sorted(speeds)


# ---------------------------------------------------------------------------
# Step transition
# ---------------------------------------------------------------------------

def test_step_holds_first_value_before_second_event():
    p = _step_profile()
    assert p.get_speed_target(4.99) == pytest.approx(20.0)


def test_step_transitions_at_second_event():
    p = _step_profile()
    assert p.get_speed_target(5.0) == pytest.approx(30.0)


def test_step_holds_after_last_event():
    p = _step_profile()
    assert p.get_speed_target(99.0) == pytest.approx(30.0)


# ---------------------------------------------------------------------------
# Out-of-order rows sort correctly
# ---------------------------------------------------------------------------

def test_out_of_order_rows_match_ordered():
    """Rows in reverse time order must produce the same profile as forward order."""
    forward = _profile(
        (0.0, 10.0, 'ramp'),
        (5.0, 20.0, 'ramp'),
        (10.0, 15.0, 'ramp'),
    )
    reversed_ = LeadVehicleProfile(pd.DataFrame(
        [(10.0, 15.0, 'ramp'), (0.0, 10.0, 'ramp'), (5.0, 20.0, 'ramp')],
        columns=['time_s', 'value', 'transition'],
    ))
    for t in [0.0, 2.5, 5.0, 7.5, 10.0]:
        assert forward.get_speed_target(t) == pytest.approx(reversed_.get_speed_target(t))


def test_three_event_ramp_middle_segment():
    """With three events, the middle segment interpolates between events 1 and 2."""
    p = _profile(
        (0.0,  0.0, 'ramp'),
        (10.0, 10.0, 'ramp'),
        (20.0, 30.0, 'ramp'),
    )
    # t=15 is halfway between event 1 (10 m/s) and event 2 (30 m/s)
    assert p.get_speed_target(15.0) == pytest.approx(20.0)


# ---------------------------------------------------------------------------
# Return type
# ---------------------------------------------------------------------------

def test_get_speed_target_returns_float():
    p = _ramp_profile()
    result = p.get_speed_target(5.0)
    assert type(result) is float


# ---------------------------------------------------------------------------
# Missing transition column defaults to ramp
# ---------------------------------------------------------------------------

def test_missing_transition_column_defaults_to_ramp():
    """If the transition column is absent, behaviour should default to ramp."""
    df = pd.DataFrame({'time_s': [0.0, 10.0], 'value': [20.0, 30.0]})
    p = LeadVehicleProfile(df)
    assert p.get_speed_target(5.0) == pytest.approx(25.0)
