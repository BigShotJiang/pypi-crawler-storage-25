"""Tests for cacc_sim/road.py — Lane, Road, and get_leader()."""
import pytest

from cacc_sim.road import Lane, Road


# ---------------------------------------------------------------------------
# Minimal vehicle stub — only the fields Road.get_leader() needs
# ---------------------------------------------------------------------------

class _V:
    def __init__(self, id_: int, leader_id: int | None):
        self.id = id_
        self.leader_id = leader_id


# ---------------------------------------------------------------------------
# Lane
# ---------------------------------------------------------------------------

class TestLane:
    def test_default_width(self):
        lane = Lane(lane_id=0)
        assert lane.width_m == pytest.approx(3.7)

    def test_custom_width(self):
        lane = Lane(lane_id=1, width_m=4.0)
        assert lane.width_m == pytest.approx(4.0)


# ---------------------------------------------------------------------------
# Road construction
# ---------------------------------------------------------------------------

class TestRoadConstruction:
    def test_single_lane_factory(self):
        road = Road.single_lane(1000.0)
        assert road.length_m == pytest.approx(1000.0)
        assert len(road.lanes) == 1
        assert road.lanes[0].lane_id == 0

    def test_explicit_multi_lane(self):
        road = Road(length_m=500.0, lanes=[Lane(0), Lane(1), Lane(2)])
        assert len(road.lanes) == 3

    def test_default_lanes_gives_single_lane(self):
        road = Road(length_m=200.0)
        assert len(road.lanes) == 1


# ---------------------------------------------------------------------------
# Road.get_leader
# ---------------------------------------------------------------------------

class TestGetLeader:
    def _map(self, *vehicles: _V) -> dict:
        return {v.id: v for v in vehicles}

    def test_returns_leader_by_id(self):
        lead = _V(1, None)
        follower = _V(2, 1)
        road = Road.single_lane(1000.0)
        assert road.get_leader(follower, self._map(lead, follower)) is lead

    def test_returns_none_for_lead_vehicle(self):
        lead = _V(1, None)
        road = Road.single_lane(1000.0)
        assert road.get_leader(lead, self._map(lead)) is None

    def test_returns_none_for_missing_leader_id(self):
        # leader_id references a vehicle not in the map
        follower = _V(2, 99)
        road = Road.single_lane(1000.0)
        assert road.get_leader(follower, self._map(follower)) is None

    def test_chain_of_three(self):
        v1 = _V(1, None)
        v2 = _V(2, 1)
        v3 = _V(3, 2)
        road = Road.single_lane(1000.0)
        vmap = self._map(v1, v2, v3)
        assert road.get_leader(v2, vmap) is v1
        assert road.get_leader(v3, vmap) is v2
        assert road.get_leader(v1, vmap) is None


# ---------------------------------------------------------------------------
# SimulationLoop uses Road (integration check)
# ---------------------------------------------------------------------------

def test_simulation_loop_default_road():
    """SimulationLoop creates a Road automatically when none is supplied."""
    import pandas as pd
    from cacc_sim.driving_models import LeadVehicleModel
    from cacc_sim.filters import PassthroughFilter
    from cacc_sim.loader import SimConfig
    from cacc_sim.plant import VehiclePlant, VehicleResponseModel
    from cacc_sim.profile import LeadVehicleProfile
    from cacc_sim.simulation import SimulationLoop
    from cacc_sim.vehicle import Vehicle

    profile = LeadVehicleProfile(pd.DataFrame({
        'time_s': [0.0, 10.0], 'value': [20.0, 20.0], 'transition': ['ramp', 'ramp'],
    }))
    lead = Vehicle(
        id=1, model=LeadVehicleModel(profile=profile),
        response=VehicleResponseModel(mode='kinematic'),
        plant=VehiclePlant(x0=100.0, v0=20.0, length=5.0),
        filter_=PassthroughFilter(), leader_id=None,
    )
    config = SimConfig(duration_s=1.0, response_model='kinematic')
    loop = SimulationLoop([lead], config)          # no road argument
    assert loop._road is not None
    assert loop._road.length_m == pytest.approx(config.road_length_m)
    df = loop.run()
    assert len(df) == 10    # 1 s at default log_rate_hz=10 → 10 logged rows


def test_simulation_loop_explicit_road():
    """SimulationLoop uses the Road passed in, not a default."""
    import pandas as pd
    from cacc_sim.driving_models import LeadVehicleModel
    from cacc_sim.filters import PassthroughFilter
    from cacc_sim.loader import SimConfig
    from cacc_sim.plant import VehiclePlant, VehicleResponseModel
    from cacc_sim.profile import LeadVehicleProfile
    from cacc_sim.simulation import SimulationLoop
    from cacc_sim.vehicle import Vehicle

    profile = LeadVehicleProfile(pd.DataFrame({
        'time_s': [0.0, 10.0], 'value': [20.0, 20.0], 'transition': ['ramp', 'ramp'],
    }))
    lead = Vehicle(
        id=1, model=LeadVehicleModel(profile=profile),
        response=VehicleResponseModel(mode='kinematic'),
        plant=VehiclePlant(x0=100.0, v0=20.0, length=5.0),
        filter_=PassthroughFilter(), leader_id=None,
    )
    config = SimConfig(duration_s=0.5, response_model='kinematic')
    road = Road(length_m=2000.0, lanes=[Lane(0), Lane(1)])
    loop = SimulationLoop([lead], config, road=road)
    assert loop._road is road
    assert loop._road.length_m == pytest.approx(2000.0)
    assert len(loop._road.lanes) == 2
