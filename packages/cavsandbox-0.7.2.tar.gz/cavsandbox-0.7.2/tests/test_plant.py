"""Tests for cacc_sim/plant.py — VehiclePlant (Step 2)."""
import pytest

from cacc_sim.plant import VehiclePlant


def _plant(x0=0.0, v0=20.0, length=5.0, dt=0.01) -> VehiclePlant:
    return VehiclePlant(x0=x0, v0=v0, length=length, dt=dt)


# ---------------------------------------------------------------------------
# Construction
# ---------------------------------------------------------------------------

def test_plant_initial_state():
    p = _plant(x0=10.0, v0=5.0, length=4.5)
    assert p.x == 10.0
    assert p.v == 5.0
    assert p.length == 4.5
    assert p.a == 0.0


def test_plant_default_dt():
    p = VehiclePlant(x0=0.0, v0=0.0, length=5.0)
    assert p.dt == 0.01


# ---------------------------------------------------------------------------
# step()
# ---------------------------------------------------------------------------

def test_plant_step_constant_acceleration():
    p = _plant(x0=0.0, v0=20.0, dt=0.01)
    x, v = p.step(1.0)
    assert v == pytest.approx(20.0 + 1.0 * 0.01)
    assert x == pytest.approx((20.0 + 1.0 * 0.01) * 0.01)


def test_plant_step_returns_tuple_matching_attributes():
    p = _plant()
    x, v = p.step(0.5)
    assert x == p.x
    assert v == p.v


def test_plant_step_updates_a_attribute():
    p = _plant()
    p.step(2.0)
    assert p.a == 2.0


def test_plant_step_negative_a_updates_a_attribute():
    p = _plant()
    p.step(-1.5)
    assert p.a == -1.5


def test_plant_speed_clamp_at_zero():
    """Applying large deceleration from rest must not produce negative speed."""
    p = _plant(v0=0.0)
    _, v = p.step(-100.0)
    assert v == 0.0


def test_plant_speed_clamp_does_not_affect_position_negatively():
    """Position must never decrease when speed is clamped at zero."""
    p = _plant(x0=50.0, v0=0.0)
    x_before = p.x
    p.step(-10.0)
    assert p.x >= x_before


# ---------------------------------------------------------------------------
# Integration accuracy
# ---------------------------------------------------------------------------

def test_plant_integration_100_steps():
    """
    100 steps at a=1.0 m/s², v0=0, dt=0.01 s → 1 simulated second.
    Expected final speed: v = 0 + 1.0 * 1.0 = 1.0 m/s.
    """
    p = _plant(v0=0.0, dt=0.01)
    for _ in range(100):
        p.step(1.0)
    assert p.v == pytest.approx(1.0, abs=1e-9)


def test_plant_integration_position_after_constant_speed():
    """
    100 steps at a=0, v0=10 m/s, dt=0.01 → 1 simulated second → x should advance by 10.0 m.
    """
    p = _plant(x0=0.0, v0=10.0, dt=0.01)
    for _ in range(100):
        p.step(0.0)
    assert p.x == pytest.approx(10.0, abs=1e-9)


# ---------------------------------------------------------------------------
# gap_to()
# ---------------------------------------------------------------------------

def test_gap_to_positive_gap():
    leader = VehiclePlant(x0=105.0, v0=20.0, length=5.0)
    follower = VehiclePlant(x0=0.0, v0=20.0, length=5.0)
    # gap = 105 - 0 - 5 = 100
    assert follower.gap_to(leader) == pytest.approx(100.0)


def test_gap_to_small_gap():
    leader = VehiclePlant(x0=12.0, v0=0.0, length=5.0)
    follower = VehiclePlant(x0=5.0, v0=0.0, length=5.0)
    # gap = 12 - 5 - 5 = 2
    assert follower.gap_to(leader) == pytest.approx(2.0)


def test_gap_to_negative_when_overlapping():
    """Negative gap indicates collision/overlap — not an error, used upstream."""
    leader = VehiclePlant(x0=0.0, v0=0.0, length=5.0)
    follower = VehiclePlant(x0=50.0, v0=0.0, length=5.0)
    assert follower.gap_to(leader) < 0.0


def test_gap_to_updates_after_step():
    leader = VehiclePlant(x0=105.0, v0=20.0, length=5.0, dt=0.01)
    follower = VehiclePlant(x0=0.0, v0=20.0, length=5.0, dt=0.01)
    gap_before = follower.gap_to(leader)
    leader.step(0.0)
    follower.step(0.0)
    gap_after = follower.gap_to(leader)
    # Both moving at the same speed — gap should be unchanged
    assert gap_after == pytest.approx(gap_before, abs=1e-9)
