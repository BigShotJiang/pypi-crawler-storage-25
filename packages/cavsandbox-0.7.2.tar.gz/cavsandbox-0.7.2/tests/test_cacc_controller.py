"""Tests for cacc_sim/controllers.py — CACCController."""
import warnings

import pytest

from cacc_sim.controllers import CACCController


def _ctrl(k1=0.2, k2=0.7, k_ff=1.0, T_h=0.6, s0=2.0) -> CACCController:
    """Return a string-stable controller with default gains."""
    return CACCController(k1=k1, k2=k2, k_ff=k_ff, target_headway_s=T_h, s0=s0)


# ---------------------------------------------------------------------------
# Instantiation
# ---------------------------------------------------------------------------

class TestCACCControllerInit:
    def test_stores_gains(self):
        c = _ctrl(k1=0.3, k2=0.5, k_ff=0.9, T_h=0.8, s0=3.0)
        assert c.k1  == pytest.approx(0.3)
        assert c.k2  == pytest.approx(0.5)
        assert c.k_ff == pytest.approx(0.9)
        assert c.T_h == pytest.approx(0.8)
        assert c.s0  == pytest.approx(3.0)

    def test_no_warning_when_stable(self):
        # k_ff + k2 * T_h = 1.0 + 0.7*0.6 = 1.42 >= 1 → no warning
        with warnings.catch_warnings():
            warnings.simplefilter("error")
            _ctrl()  # should not raise

    def test_warning_when_unstable(self):
        # k_ff=0.0 + k2=0.7 * T_h=0.6 = 0.42 < 1 → string-unstable
        with pytest.warns(UserWarning, match="string-unstable"):
            CACCController(k1=0.2, k2=0.7, k_ff=0.0, target_headway_s=0.6)

    def test_warning_shows_required_k_ff(self):
        # required = 1 - k2 * T_h = 1 - 0.7*0.6 = 0.58
        with pytest.warns(UserWarning, match="0.580"):
            CACCController(k1=0.2, k2=0.7, k_ff=0.0, target_headway_s=0.6)

    def test_exactly_at_stability_boundary(self):
        # k_ff + k2 * T_h exactly == 1.0 → stable (no warning)
        # k2=0.5, T_h=1.0, k_ff=0.5 → 0.5 + 0.5 = 1.0
        with warnings.catch_warnings():
            warnings.simplefilter("error")
            CACCController(k1=0.2, k2=0.5, k_ff=0.5, target_headway_s=1.0)


# ---------------------------------------------------------------------------
# Control law
# ---------------------------------------------------------------------------

class TestCACCControllerCompute:
    def test_zero_error_output_equals_feedforward(self):
        """When gap = desired gap and speeds match, output = k_ff * v2v_accel."""
        c = _ctrl(k1=0.2, k2=0.7, k_ff=1.0, T_h=0.6, s0=2.0)
        ego_speed = 20.0
        desired_gap = c.T_h * ego_speed + c.s0  # 0.6*20 + 2 = 14.0 m
        a = c.compute(
            gap=desired_gap,
            ego_speed=ego_speed,
            lead_speed=ego_speed,
            lead_a_v2v=1.5,
        )
        assert a == pytest.approx(1.5)  # k_ff * 1.5

    def test_positive_gap_error_increases_output(self):
        """Larger gap than desired → positive e_gap → higher a_cmd."""
        c = _ctrl(k1=0.2, k2=0.7, k_ff=1.0, T_h=0.6, s0=2.0)
        a_tight = c.compute(gap=14.0,  ego_speed=20.0, lead_speed=20.0, lead_a_v2v=0.0)
        a_large = c.compute(gap=25.0,  ego_speed=20.0, lead_speed=20.0, lead_a_v2v=0.0)
        assert a_large > a_tight

    def test_negative_gap_error_decreases_output(self):
        """Smaller gap than desired → negative e_gap → lower a_cmd."""
        c = _ctrl(k1=0.2, k2=0.7, k_ff=1.0, T_h=0.6, s0=2.0)
        a_desired = c.compute(gap=14.0, ego_speed=20.0, lead_speed=20.0, lead_a_v2v=0.0)
        a_close   = c.compute(gap=5.0,  ego_speed=20.0, lead_speed=20.0, lead_a_v2v=0.0)
        assert a_close < a_desired

    def test_lead_faster_increases_output(self):
        """Lead faster than ego → positive speed error → higher output."""
        c = _ctrl()
        a_matched  = c.compute(gap=14.0, ego_speed=20.0, lead_speed=20.0, lead_a_v2v=0.0)
        a_catching = c.compute(gap=14.0, ego_speed=18.0, lead_speed=20.0, lead_a_v2v=0.0)
        assert a_catching > a_matched

    def test_feedforward_scales_with_k_ff(self):
        """Doubling k_ff doubles the feedforward contribution (all else zero)."""
        c1 = _ctrl(k1=0.0, k2=0.0, k_ff=0.5, T_h=0.6, s0=2.0)
        c2 = _ctrl(k1=0.0, k2=0.0, k_ff=1.0, T_h=0.6, s0=2.0)
        ego, lead, gap = 20.0, 20.0, 14.0
        a1 = c1.compute(gap, ego, lead, lead_a_v2v=2.0)
        a2 = c2.compute(gap, ego, lead, lead_a_v2v=2.0)
        assert a2 == pytest.approx(2.0 * a1)

    def test_known_output(self):
        """Verify the exact arithmetic against hand calculation."""
        c = CACCController(k1=0.2, k2=0.7, k_ff=1.0, target_headway_s=0.6, s0=2.0)
        # gap=20, ego=20, lead=22, v2v_accel=1.0
        # desired_gap = 0.6*20 + 2 = 14.0
        # e_gap = 20 - 14 = 6.0
        # a = 0.2*6 + 0.7*(22-20) + 1.0*1.0 = 1.2 + 1.4 + 1.0 = 3.6
        a = c.compute(gap=20.0, ego_speed=20.0, lead_speed=22.0, lead_a_v2v=1.0)
        assert a == pytest.approx(3.6)
