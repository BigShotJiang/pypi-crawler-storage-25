"""Tests for cacc_sim/driving_models.py — IDMModel (Step 4)."""
import math

import pytest

from cacc_sim.core import DrivingModel, DrivingModelOutput, VehicleState
from cacc_sim.driving_models import IDMModel


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _state(speed: float, gap: float, lead_speed: float, **kwargs) -> VehicleState:
    return VehicleState(
        speed=speed,
        acceleration=0.0,
        time=0.0,
        position=0.0,
        gap=gap,
        lead_speed=lead_speed,
        **kwargs,
    )


def _idm(**kwargs) -> IDMModel:
    """IDMModel with explicit defaults so tests are self-documenting."""
    defaults = dict(desired_speed=30.0, time_headway=1.5)
    defaults.update(kwargs)
    return IDMModel(**defaults)


# ---------------------------------------------------------------------------
# ABC compliance
# ---------------------------------------------------------------------------

def test_idm_is_driving_model_subclass():
    assert isinstance(_idm(), DrivingModel)


def test_idm_required_inputs_as_classmethod():
    """Must be callable on the class without instantiation."""
    result = IDMModel.required_inputs()
    assert result == {'speed', 'gap', 'lead_speed'}


def test_idm_required_inputs_on_instance():
    assert _idm().required_inputs() == {'speed', 'gap', 'lead_speed'}


# ---------------------------------------------------------------------------
# Return type
# ---------------------------------------------------------------------------

def test_idm_compute_returns_driving_model_output():
    out = _idm().compute(_state(20.0, 30.0, 20.0))
    assert isinstance(out, DrivingModelOutput)


def test_idm_compute_returns_python_float():
    out = _idm().compute(_state(20.0, 30.0, 20.0))
    assert type(out.acceleration) is float


# ---------------------------------------------------------------------------
# Physics — free-flow regime
# ---------------------------------------------------------------------------

def test_idm_free_flow_accelerates():
    """Low speed, large gap, leader far ahead → positive acceleration."""
    out = _idm(desired_speed=30.0, time_headway=1.5).compute(
        _state(speed=5.0, gap=500.0, lead_speed=30.0)
    )
    assert out.acceleration > 0.0


def test_idm_at_desired_speed_large_gap_near_zero():
    """
    Ego at desired speed, leader matching speed far ahead.
    Free-flow term (v/v0)^delta ≈ 1, interaction term (s*/s)^2 ≈ 0 → a ≈ 0.
    """
    out = _idm(desired_speed=30.0).compute(
        _state(speed=30.0, gap=1000.0, lead_speed=30.0)
    )
    assert out.acceleration == pytest.approx(0.0, abs=0.05)


# ---------------------------------------------------------------------------
# Physics — car-following regime
# ---------------------------------------------------------------------------

def test_idm_too_close_decelerates():
    """
    Gap below standstill distance s0=2.0 with matched speeds
    → (s*/s)^2 > 1 → output strongly negative.
    """
    out = _idm(s0=2.0).compute(
        _state(speed=20.0, gap=1.0, lead_speed=20.0)
    )
    assert out.acceleration < 0.0


def test_idm_approaching_decelerates_harder_than_matched():
    """
    Closing on leader (dv > 0) at same gap → more negative than matched speed.
    gap=30 m keeps both cases away from the a_min clip so the comparison is meaningful.
    """
    model = _idm(s0=2.0)
    a_matched     = model.compute(_state(20.0, gap=30.0, lead_speed=20.0)).acceleration
    a_approaching = model.compute(_state(20.0, gap=30.0, lead_speed=15.0)).acceleration
    assert a_approaching < a_matched


def test_idm_receding_leader_less_braking():
    """Leader pulling away (dv < 0) reduces the interaction term → less braking."""
    model = _idm(s0=2.0)
    a_matched  = model.compute(_state(20.0, gap=5.0, lead_speed=20.0)).acceleration
    a_receding = model.compute(_state(20.0, gap=5.0, lead_speed=25.0)).acceleration
    assert a_receding > a_matched


# ---------------------------------------------------------------------------
# Physics — edge cases
# ---------------------------------------------------------------------------

def test_idm_zero_gap_no_exception():
    """gap=0 is floored to 0.1 internally — must not raise."""
    out = _idm().compute(_state(20.0, gap=0.0, lead_speed=20.0))
    assert isinstance(out, DrivingModelOutput)


def test_idm_zero_speed_no_exception():
    """Ego at standstill — free-flow term is 0, s* = s0 only."""
    out = _idm().compute(_state(speed=0.0, gap=5.0, lead_speed=0.0))
    assert isinstance(out, DrivingModelOutput)


# ---------------------------------------------------------------------------
# Output clipping
# ---------------------------------------------------------------------------

def test_idm_output_clipped_at_a_max():
    """Very low speed, large gap — raw IDM can exceed a_max; output must not."""
    m = _idm(a_max=1.5)
    out = m.compute(_state(speed=0.01, gap=1000.0, lead_speed=30.0))
    assert out.acceleration <= 1.5


def test_idm_output_clipped_at_a_min():
    """Near-zero gap at speed — strong braking; output must not exceed a_min."""
    m = _idm(a_min=-6.0)
    out = m.compute(_state(speed=30.0, gap=0.1, lead_speed=0.0))
    assert out.acceleration >= -6.0


# ---------------------------------------------------------------------------
# Arithmetic — known analytic case
# ---------------------------------------------------------------------------

def test_idm_dv_zero_s_star_formula():
    """
    When dv=0, s* = s0 + speed * T.  Verify the acceleration formula directly.
    """
    v0, T, s0, a_max, b, delta = 30.0, 1.5, 2.0, 1.5, 2.0, 4.0
    speed, gap = 20.0, 50.0
    m = IDMModel(desired_speed=v0, time_headway=T, s0=s0,
                 a_max=a_max, b=b, delta=delta)
    out = m.compute(_state(speed=speed, gap=gap, lead_speed=speed))  # dv = 0

    s_star = s0 + speed * T                              # = 2 + 30 = 32
    s      = max(gap, 0.1)                              # = 50
    expected = a_max * (1.0 - (speed / v0) ** delta - (s_star / s) ** 2)
    expected = max(min(expected, a_max), -6.0)

    assert out.acceleration == pytest.approx(expected, abs=1e-9)


# ---------------------------------------------------------------------------
# Custom parameters change output
# ---------------------------------------------------------------------------

def test_idm_custom_params_differ_from_defaults():
    default_out = IDMModel(desired_speed=30.0, time_headway=1.5).compute(
        _state(20.0, 20.0, 20.0)
    )
    custom_out = IDMModel(desired_speed=20.0, time_headway=0.8, a_max=2.0).compute(
        _state(20.0, 20.0, 20.0)
    )
    assert default_out.acceleration != custom_out.acceleration
