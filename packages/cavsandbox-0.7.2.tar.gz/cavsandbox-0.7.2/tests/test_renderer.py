"""Tests for cacc_sim/renderer.py and cacc_sim/playback.py (Step 8)."""
import os
import pytest
import pandas as pd

from cacc_sim.renderer import RenderFrame, VehicleRenderState, _format_time
from cacc_sim.playback import _frame_from_group, CSVPlayback


# ---------------------------------------------------------------------------
# RenderFrame and VehicleRenderState — data layer
# ---------------------------------------------------------------------------

def _make_vrs(**overrides) -> VehicleRenderState:
    defaults = dict(
        id=1, x=100.0, v=20.0, a=0.0, gap=25.0,
        model='IDMModel', vehicle_type=None, length=5.0,
    )
    defaults.update(overrides)
    return VehicleRenderState(**defaults)


def test_vehicle_render_state_stores_fields():
    v = _make_vrs(id=3, x=50.0, vehicle_type='heavy_truck', length=15.0)
    assert v.id == 3
    assert v.x == pytest.approx(50.0)
    assert v.vehicle_type == 'heavy_truck'
    assert v.length == pytest.approx(15.0)


def test_render_frame_stores_sim_time_and_vehicles():
    v1 = _make_vrs(id=1)
    v2 = _make_vrs(id=2)
    frame = RenderFrame(sim_time=5.5, vehicles=[v1, v2])
    assert frame.sim_time == pytest.approx(5.5)
    assert len(frame.vehicles) == 2


def test_render_frame_default_vehicles_is_empty():
    frame = RenderFrame(sim_time=0.0)
    assert frame.vehicles == []


def test_render_frame_vehicles_list_is_independent():
    """Two RenderFrame instances must not share the same vehicles list."""
    f1 = RenderFrame(sim_time=0.0)
    f2 = RenderFrame(sim_time=1.0)
    f1.vehicles.append(_make_vrs())
    assert len(f2.vehicles) == 0


# ---------------------------------------------------------------------------
# _format_time
# ---------------------------------------------------------------------------

def test_format_time_zero():
    assert _format_time(0.0) == '00:00.0'


def test_format_time_one_second():
    assert _format_time(1.0) == '00:01.0'


def test_format_time_one_minute():
    assert _format_time(60.0) == '01:00.0'


def test_format_time_fractional():
    # 1.5 s → 00:01.5
    assert _format_time(1.5) == '00:01.5'


def test_format_time_large():
    # 125.3 s → 02:05.3
    assert _format_time(125.3) == '02:05.3'


# ---------------------------------------------------------------------------
# _frame_from_group — CSV → RenderFrame conversion
# ---------------------------------------------------------------------------

def _make_df(*rows) -> pd.DataFrame:
    return pd.DataFrame(rows)


def test_frame_from_group_single_vehicle():
    df = _make_df(dict(
        t=1.0, id=1, x=100.0, v=20.0, a=0.5, gap=9999.0,
        model='LeadVehicleModel', vehicle_type=None, length=5.0,
    ))
    frame = _frame_from_group(1.0, df)
    assert frame.sim_time == pytest.approx(1.0)
    assert len(frame.vehicles) == 1
    v = frame.vehicles[0]
    assert v.id == 1
    assert v.x == pytest.approx(100.0)
    assert v.model == 'LeadVehicleModel'
    assert v.vehicle_type is None
    assert v.length == pytest.approx(5.0)


def test_frame_from_group_two_vehicles():
    df = _make_df(
        dict(t=2.0, id=1, x=110.0, v=20.0, a=0.0, gap=9999.0,
             model='LeadVehicleModel', vehicle_type=None, length=5.0),
        dict(t=2.0, id=2, x=80.0,  v=20.0, a=0.0, gap=25.0,
             model='IDMModel', vehicle_type='car', length=5.0),
    )
    frame = _frame_from_group(2.0, df)
    assert len(frame.vehicles) == 2
    assert {v.id for v in frame.vehicles} == {1, 2}


def test_frame_from_group_truck_vehicle_type():
    df = _make_df(dict(
        t=0.0, id=3, x=50.0, v=15.0, a=0.0, gap=30.0,
        model='IDMModel', vehicle_type='heavy_truck', length=15.0,
    ))
    frame = _frame_from_group(0.0, df)
    assert frame.vehicles[0].vehicle_type == 'heavy_truck'
    assert frame.vehicles[0].length == pytest.approx(15.0)


# ---------------------------------------------------------------------------
# CSVPlayback — data layer (no pygame window opened)
# ---------------------------------------------------------------------------

def _make_sim_df(n_steps: int = 10, dt: float = 0.1) -> pd.DataFrame:
    """Build a minimal 2-vehicle simulation DataFrame."""
    rows = []
    for i in range(n_steps):
        t = round(i * dt, 6)
        rows.append(dict(t=t, id=1, x=100.0 + i * 2.0, v=20.0, a=0.0,
                         gap=9999.0, model='LeadVehicleModel',
                         vehicle_type=None, length=5.0))
        rows.append(dict(t=t, id=2, x=70.0 + i * 2.0, v=20.0, a=0.0,
                         gap=25.0, model='IDMModel',
                         vehicle_type=None, length=5.0))
    return pd.DataFrame(rows)


class _FakeRenderer:
    """Minimal stand-in for PygameRenderer — no pygame required."""
    def __init__(self):
        self.drawn: list[RenderFrame] = []
        self._pygame = _FakePygame()

    def draw(self, frame, paused=False, playback_speed=1.0):
        self.drawn.append(frame)

    def handle_events(self, paused):
        return paused, True


class _FakePygame:
    """Enough of the pygame.event API to let handle_events work headlessly."""
    class event:
        @staticmethod
        def get():
            return []


def test_csvplayback_precomputes_render_frames():
    df = _make_sim_df(n_steps=20, dt=0.01)
    renderer = _FakeRenderer()
    pb = CSVPlayback(df, renderer, render_interval_s=0.1)
    # 20 steps × 0.01 s = 0.2 s total; render every 0.1 s → 2 or 3 render times
    assert len(pb._render_times) >= 2


def test_csvplayback_frames_have_correct_vehicle_count():
    df = _make_sim_df(n_steps=10, dt=0.1)
    renderer = _FakeRenderer()
    pb = CSVPlayback(df, renderer, render_interval_s=0.1)
    for frame in pb._frames.values():
        assert len(frame.vehicles) == 2


def test_csvplayback_sim_times_match_keys():
    df = _make_sim_df(n_steps=10, dt=0.1)
    renderer = _FakeRenderer()
    pb = CSVPlayback(df, renderer, render_interval_s=0.1)
    for t, frame in pb._frames.items():
        assert frame.sim_time == pytest.approx(t)


def test_csvplayback_from_csv(tmp_path):
    df = _make_sim_df(n_steps=5, dt=0.1)
    csv_path = tmp_path / 'sim.csv'
    df.to_csv(str(csv_path), index=False)
    renderer = _FakeRenderer()
    pb = CSVPlayback.from_csv(str(csv_path), renderer, render_interval_s=0.1)
    assert len(pb._render_times) >= 1
