"""Tests for cacc_sim/rng.py — per-vehicle RNG derivation."""
import pytest

from cacc_sim.rng import vehicle_rng


def test_same_inputs_give_same_sequence():
    rng1 = vehicle_rng(42, 1, 'sensor_noise')
    rng2 = vehicle_rng(42, 1, 'sensor_noise')
    seq1 = [rng1.gauss(0, 1) for _ in range(20)]
    seq2 = [rng2.gauss(0, 1) for _ in range(20)]
    assert seq1 == seq2


def test_different_vehicles_give_different_sequences():
    rng1 = vehicle_rng(42, 1, 'sensor_noise')
    rng2 = vehicle_rng(42, 2, 'sensor_noise')
    seq1 = [rng1.gauss(0, 1) for _ in range(20)]
    seq2 = [rng2.gauss(0, 1) for _ in range(20)]
    assert seq1 != seq2


def test_different_processes_give_different_sequences():
    rng1 = vehicle_rng(42, 1, 'sensor_noise')
    rng2 = vehicle_rng(42, 1, 'ego_noise')
    seq1 = [rng1.gauss(0, 1) for _ in range(20)]
    seq2 = [rng2.gauss(0, 1) for _ in range(20)]
    assert seq1 != seq2


def test_different_seeds_give_different_sequences():
    rng1 = vehicle_rng(1, 1, 'sensor_noise')
    rng2 = vehicle_rng(2, 1, 'sensor_noise')
    seq1 = [rng1.gauss(0, 1) for _ in range(20)]
    seq2 = [rng2.gauss(0, 1) for _ in range(20)]
    assert seq1 != seq2


def test_master_seed_zero_is_deterministic():
    rng1 = vehicle_rng(0, 1, 'sensor_noise')
    rng2 = vehicle_rng(0, 1, 'sensor_noise')
    assert rng1.gauss(0, 1) == rng2.gauss(0, 1)


def test_invalid_process_raises():
    with pytest.raises(ValueError, match='Unknown per-vehicle process'):
        vehicle_rng(0, 1, 'nonexistent_process')


def test_all_known_processes_work():
    for process in ('sensor_noise', 'ego_noise', 'wiedemann', 'idm_human',
                    'bsm_comms', 'bsm_phase'):
        rng = vehicle_rng(0, 1, process)
        assert rng.gauss(0, 1) is not None
