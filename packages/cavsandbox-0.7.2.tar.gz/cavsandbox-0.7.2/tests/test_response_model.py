"""Tests for cacc_sim/plant.py — VehicleResponseModel (Step 3)."""
import pytest

from cacc_sim.plant import VehicleResponseModel


def _lag(**kwargs) -> VehicleResponseModel:
    return VehicleResponseModel(mode='lag', **kwargs)


def _kinematic(**kwargs) -> VehicleResponseModel:
    return VehicleResponseModel(mode='kinematic', **kwargs)


# ---------------------------------------------------------------------------
# Construction
# ---------------------------------------------------------------------------

def test_default_mode_is_lag():
    m = VehicleResponseModel()
    assert m.mode == 'lag'


def test_default_dt():
    m = VehicleResponseModel()
    assert m.dt == 0.01


def test_invalid_mode_raises():
    with pytest.raises(ValueError, match="mode"):
        VehicleResponseModel(mode='full_powertrain')


def test_initial_a_actual_is_zero():
    assert _lag().a_actual == 0.0
    assert _kinematic().a_actual == 0.0


# ---------------------------------------------------------------------------
# 'lag' mode — basic path selection
# ---------------------------------------------------------------------------

def test_lag_throttle_path_increases_a_actual():
    m = _lag()
    m.step(2.0, v_ego=20.0)   # 2.0 > deadband=0.05 → throttle path
    assert m.a_actual > 0.0


def test_lag_brake_path_decreases_a_actual():
    m = _lag()
    m.step(-3.0, v_ego=20.0)  # -3.0 < -deadband → brake path
    assert m.a_actual < 0.0


def test_lag_deadband_with_moving_vehicle_applies_drag():
    """Deadband + v_ego > 0 → quadratic drag pulls a_actual negative."""
    m = _lag(crr=0.012, k_aero=1.76e-4)
    m.step(0.0, v_ego=20.0)
    assert m.a_actual < 0.0


def test_lag_deadband_at_zero_speed_rolling_resistance_only():
    """
    At v=0 drag = -(crr * g + k_aero * 0²) = -(0.012 * 9.81) ≈ -0.118 m/s².
    Rolling resistance still applies at standstill (models static friction / creep).
    a_actual should move negative after one step.
    """
    m = _lag(crr=0.012, k_aero=1.76e-4)
    m.step(0.0, v_ego=0.0)
    assert m.a_actual < 0.0


def test_lag_deadband_drag_larger_at_high_speed():
    """Quadratic drag at 30 m/s must exceed drag at 10 m/s."""
    def drag_after_one_step(v):
        m = _lag(crr=0.012, k_aero=1.76e-4)
        m.step(0.0, v_ego=v)
        return m.a_actual  # negative

    assert drag_after_one_step(30.0) < drag_after_one_step(10.0)


# ---------------------------------------------------------------------------
# 'lag' mode — jerk limiting
# ---------------------------------------------------------------------------

def test_lag_jerk_limit_one_step():
    """
    From a_actual=0, command a=5.0.
    j_max * dt = 5.0 * 0.01 = 0.05 → a_actual must not exceed 0.05 after 1 step.
    """
    m = _lag(j_max=5.0, dt=0.01, tau_throttle=0.5)
    m.step(5.0, v_ego=0.0)
    assert m.a_actual <= 0.05 + 1e-10


# ---------------------------------------------------------------------------
# 'lag' mode — saturation
# ---------------------------------------------------------------------------

def test_lag_saturates_at_a_max():
    m = _lag(a_max=2.5)
    for _ in range(500):
        m.step(100.0, v_ego=0.0)
    assert m.a_actual <= 2.5


def test_lag_saturates_at_a_min():
    m = _lag(a_min=-8.0)
    for _ in range(500):
        m.step(-100.0, v_ego=0.0)
    assert m.a_actual >= -8.0


# ---------------------------------------------------------------------------
# 'lag' mode — first-order lag convergence
# ---------------------------------------------------------------------------

def test_lag_converges_to_commanded():
    """
    tau_throttle=0.5 s, dt=0.01 → time constant 0.5 s.
    After 200 steps (2.0 s) the response should be within 0.05 of 1.0.
    """
    m = _lag(tau_throttle=0.5, dt=0.01, j_max=50.0)  # large j_max so jerk isn't binding
    for _ in range(200):
        m.step(1.0, v_ego=0.0)
    assert m.a_actual == pytest.approx(1.0, abs=0.05)


def test_lag_brake_settles_faster_than_throttle():
    """
    tau_brake (0.3 s) < tau_throttle (0.5 s) → brake reaches 50 % of target faster.
    Count steps to reach 50 % of the commanded magnitude.
    """
    def steps_to_half(mode_tau_key, tau_val, a_cmd):
        m = VehicleResponseModel(mode='lag', j_max=100.0, dt=0.01,
                                 **{mode_tau_key: tau_val})
        for i in range(1, 1000):
            result = m.step(a_cmd, v_ego=0.0)
            if abs(result) >= 0.5 * abs(a_cmd):
                return i
        return 1000

    throttle_steps = steps_to_half('tau_throttle', 0.5, 1.0)
    brake_steps    = steps_to_half('tau_brake',    0.3, -1.0)
    assert brake_steps < throttle_steps


# ---------------------------------------------------------------------------
# 'kinematic' mode
# ---------------------------------------------------------------------------

def test_kinematic_step_equals_commanded_immediately():
    m = _kinematic()
    result = m.step(1.5, v_ego=20.0)
    assert result == pytest.approx(1.5)
    assert m.a_actual == pytest.approx(1.5)


def test_kinematic_step_negative_command():
    m = _kinematic()
    result = m.step(-3.0, v_ego=20.0)
    assert result == pytest.approx(-3.0)


def test_kinematic_saturates_at_a_max():
    m = _kinematic(a_max=2.5)
    result = m.step(100.0, v_ego=0.0)
    assert result == pytest.approx(2.5)
    assert m.a_actual == pytest.approx(2.5)


def test_kinematic_saturates_at_a_min():
    m = _kinematic(a_min=-8.0)
    result = m.step(-100.0, v_ego=0.0)
    assert result == pytest.approx(-8.0)


def test_kinematic_settles_faster_than_lag():
    """After 1 step at a_cmd=1.0: kinematic returns 1.0, lag returns << 1.0."""
    km = _kinematic(j_max=5.0, dt=0.01)
    lg = _lag(tau_throttle=0.5, j_max=5.0, dt=0.01)
    km_result = km.step(1.0, v_ego=0.0)
    lg_result = lg.step(1.0, v_ego=0.0)
    assert km_result > lg_result


def test_kinematic_no_divide_by_zero_with_zero_tau_params():
    """Kinematic mode bypasses tau entirely — zero tau_throttle must not raise."""
    m = VehicleResponseModel(mode='kinematic', tau_throttle=0.0, tau_brake=0.0)
    result = m.step(1.0, v_ego=20.0)
    assert result == pytest.approx(1.0)


# ---------------------------------------------------------------------------
# Return type (both modes)
# ---------------------------------------------------------------------------

def test_lag_returns_python_float():
    m = _lag()
    result = m.step(1.0, v_ego=20.0)
    assert type(result) is float


def test_kinematic_returns_python_float():
    m = _kinematic()
    result = m.step(1.0, v_ego=20.0)
    assert type(result) is float
