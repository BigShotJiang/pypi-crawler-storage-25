"""Tests for plugins/wiedemann99.py — Wiedemann99Model."""
import sys
from pathlib import Path

import pandas as pd
import pytest

sys.path.insert(0, str(Path(__file__).parent.parent))

from cacc_sim.core import DrivingModel, VehicleState
from cacc_sim.loader import SimConfig, load_plugins, MODEL_REGISTRY
load_plugins('plugins')  # register Wiedemann99Model for these tests

from plugins.wiedemann99 import Wiedemann99Model


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _state(speed=20.0, gap=50.0, lead_speed=20.0) -> VehicleState:
    return VehicleState(
        speed=speed, acceleration=0.0, time=0.0, position=0.0,
        gap=gap, lead_speed=lead_speed, lead_a_radar=0.0,
    )


def _model(**kwargs) -> Wiedemann99Model:
    return Wiedemann99Model(**kwargs)


# ---------------------------------------------------------------------------
# Regime detection
# ---------------------------------------------------------------------------

class TestRegimes:
    def test_free_regime_when_gap_large(self):
        m = _model()
        m.compute(_state(speed=20.0, gap=500.0, lead_speed=20.0))
        assert m.regime == 'free'

    def test_braking_regime_when_gap_below_desired(self):
        m = _model(CC0=1.5, CC1=0.9)
        # desired_gap at 20 m/s = 1.5 + 0.9*20 = 19.5 m
        # gap=5 < 19.5 → braking
        m.compute(_state(speed=20.0, gap=5.0, lead_speed=20.0))
        assert m.regime == 'braking'

    def test_closing_regime(self):
        m = _model(CC0=1.5, CC1=0.9, CC2=4.0)
        # desired_gap at 20 = 19.5; SDX = 23.5
        # gap=23 < SDX → not free; gap=23 > d=19.5 → not braking
        # dv=5, SDV = 5²/(2*(23-19.5)) = 25/7 ≈ 3.57; dv=5 >= SDV → closing
        m.compute(_state(speed=20.0, gap=23.0, lead_speed=15.0))
        assert m.regime == 'closing'


# ---------------------------------------------------------------------------
# Free regime acceleration
# ---------------------------------------------------------------------------

class TestFreeRegime:
    def test_accelerates_when_below_desired_speed(self):
        m = _model(desired_speed=30.0, seed=0)
        a = m.compute(_state(speed=15.0, gap=500.0, lead_speed=15.0)).acceleration
        assert a > 0.0

    def test_zero_accel_at_or_above_desired_speed(self):
        m = _model(desired_speed=20.0, seed=0)
        a = m.compute(_state(speed=20.0, gap=500.0, lead_speed=20.0)).acceleration
        assert a == pytest.approx(0.0)

    def test_free_accel_interpolates_cc8_cc9(self):
        """At v=0 output = CC8; at v≥22.2 output = CC9."""
        m = _model(CC8=2.0, CC9=1.5, desired_speed=30.0, seed=0)
        # At v just above 0, very slow → free accel ≈ CC8
        a_slow = m.compute(_state(speed=0.01, gap=500.0, lead_speed=0.01)).acceleration
        assert a_slow == pytest.approx(2.0, abs=0.05)
        # At v=22.2 → free accel = CC9
        a_fast = m.compute(_state(speed=22.2, gap=500.0, lead_speed=22.2)).acceleration
        assert a_fast == pytest.approx(1.5, abs=0.05)


# ---------------------------------------------------------------------------
# Braking regime
# ---------------------------------------------------------------------------

class TestBrakingRegime:
    def test_braking_output_is_negative(self):
        m = _model(seed=0)
        # gap=2 < desired_gap at 25 m/s (= 1.5 + 0.9*25 = 24) → braking
        state = _state(speed=25.0, gap=2.0, lead_speed=15.0)
        a = m.compute(state).acceleration
        assert m.regime == 'braking'
        assert a < 0.0

    def test_braking_clipped_at_minus_six(self):
        m = _model(seed=0)
        # gap=0.5 < desired_gap at 30 m/s (= 1.5 + 27 = 28.5) → braking regime
        # dv = 30 - 0 = 30; -2*30 = -60; clipped to max(-60, -6) = -6
        state = VehicleState(speed=30.0, acceleration=0.0, time=0.0, position=0.0,
                             gap=0.5, lead_speed=0.0, lead_a_radar=0.0)
        a = m.compute(state).acceleration
        assert m.regime == 'braking'
        assert a >= -6.0


# ---------------------------------------------------------------------------
# Reproducibility
# ---------------------------------------------------------------------------

class TestReproducibility:
    def test_seeded_is_deterministic(self):
        """Same seed gives identical output across two instances."""
        state = _state(speed=20.0, gap=21.0, lead_speed=20.0)
        m1 = _model(seed=42)
        m2 = _model(seed=42)
        # Run enough steps to hit following regime
        for _ in range(5):
            a1 = m1.compute(state).acceleration
            a2 = m2.compute(state).acceleration
        assert a1 == pytest.approx(a2)

    def test_different_seeds_diverge_in_following_regime(self):
        """Different seeds produce different following-regime outputs over many steps."""
        m1 = _model(seed=1)
        m2 = _model(seed=99)
        # following regime: gap just above desired, speeds matched (dv=0 → not closing)
        # desired_gap at 20 = 1.5 + 18 = 19.5; gap=21 > 19.5 → not braking
        # dv=0, not > 0 → not closing → following
        state = _state(speed=20.0, gap=21.0, lead_speed=20.0)
        outputs1 = [m1.compute(state).acceleration for _ in range(50)]
        outputs2 = [m2.compute(state).acceleration for _ in range(50)]
        # Both should be in following regime
        assert m1.regime == 'following'
        assert outputs1 != outputs2


# ---------------------------------------------------------------------------
# from_excel_row
# ---------------------------------------------------------------------------

class TestFromExcelRow:
    def test_required_only(self):
        row = pd.Series({'desired_speed_mps': 22.0})
        m = Wiedemann99Model.from_excel_row(row, SimConfig())
        assert isinstance(m, Wiedemann99Model)
        assert m.v_desired == pytest.approx(22.0)
        # CC parameters should be VISSIM defaults
        assert m.CC0 == pytest.approx(1.5)
        assert m.CC1 == pytest.approx(0.9)

    def test_custom_cc_parameter_used(self):
        row = pd.Series({'desired_speed_mps': 22.0, 'CC0': 2.5, 'CC1': 1.2})
        m = Wiedemann99Model.from_excel_row(row, SimConfig())
        assert m.CC0 == pytest.approx(2.5)
        assert m.CC1 == pytest.approx(1.2)

    def test_blank_cc_uses_default(self):
        import numpy as np
        row = pd.Series({'desired_speed_mps': 22.0, 'CC0': float('nan')})
        m = Wiedemann99Model.from_excel_row(row, SimConfig())
        assert m.CC0 == pytest.approx(1.5)  # VISSIM default


# ---------------------------------------------------------------------------
# Plugin registry integration
# ---------------------------------------------------------------------------

def test_registered_in_model_registry():
    assert 'Wiedemann99Model' in MODEL_REGISTRY
    assert MODEL_REGISTRY['Wiedemann99Model'].__name__ == 'Wiedemann99Model'
    assert issubclass(MODEL_REGISTRY['Wiedemann99Model'], DrivingModel)
