"""
Tests for DelayBuffer (core.py) and IDMHumanModel (driving_models.py).
"""
import pytest

from cacc_sim.core import DelayBuffer, VehicleState
from cacc_sim.driving_models import IDMHumanModel, IDMModel


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _state(
    gap: float = 30.0,
    lead_speed: float = 20.0,
    speed: float = 20.0,
    lead_accel: float = 0.0,
) -> VehicleState:
    return VehicleState(
        speed=speed,
        acceleration=0.0,
        time=0.0,
        position=100.0,
        gap=gap,
        lead_speed=lead_speed,
        lead_a_radar=lead_accel,
    )


# ---------------------------------------------------------------------------
# DelayBuffer
# ---------------------------------------------------------------------------

class TestDelayBuffer:

    def test_returns_none_before_buffer_fills(self):
        # n = round(0.03/0.01) = 3; effective delay = n−1 = 2 steps
        # First 2 reads return None (unfilled slots)
        buf = DelayBuffer(delay_s=0.03, dt=0.01)
        assert buf.push_and_read('A') is None
        assert buf.push_and_read('B') is None

    def test_fifo_ordering(self):
        # n=3, delay=2 steps; value pushed at call k appears at call k+2
        buf = DelayBuffer(delay_s=0.03, dt=0.01)
        results = [buf.push_and_read(v) for v in [10, 20, 30, 40, 50]]
        assert results[0] is None
        assert results[1] is None
        assert results[2] == 10
        assert results[3] == 20
        assert results[4] == 30

    def test_fill_seeds_all_slots(self):
        # After fill(), first n−1 pushes return the seed; the n-th returns push[0]
        buf = DelayBuffer(delay_s=0.03, dt=0.01)   # n=3, delay=2
        buf.fill('seed')
        assert buf.push_and_read('A') == 'seed'
        assert buf.push_and_read('B') == 'seed'
        assert buf.push_and_read('C') == 'A'

    def test_fill_overwrites_existing_content(self):
        buf = DelayBuffer(delay_s=0.02, dt=0.01)   # n=2, delay=1
        buf.push_and_read('first')
        buf.fill('new')
        assert buf.push_and_read('X') == 'new'

    def test_single_slot_zero_delay(self):
        # delay_s < dt → n=max(1,0)=1 → value returned immediately (zero delay)
        buf = DelayBuffer(delay_s=0.001, dt=0.01)
        assert buf.push_and_read('A') == 'A'
        assert buf.push_and_read('B') == 'B'

    def test_works_with_arbitrary_value_types(self):
        buf = DelayBuffer(delay_s=0.01, dt=0.01)   # n=1
        tup = (1.0, 2.0, 3.0)
        assert buf.push_and_read(tup) == tup


# ---------------------------------------------------------------------------
# IDMHumanModel
# ---------------------------------------------------------------------------

class TestIDMHumanModelInterface:

    def test_required_inputs(self):
        assert IDMHumanModel.required_inputs() == {'speed', 'gap', 'lead_speed'}

    def test_is_driving_model_subclass(self):
        from cacc_sim.core import DrivingModel
        assert issubclass(IDMHumanModel, DrivingModel)


class TestIDMHumanModelStartup:

    def test_first_call_matches_idm(self):
        # Buffer pre-filled with initial perceived quantities → same output as IDMModel
        human = IDMHumanModel(desired_speed=30.0, time_headway=1.5, reaction_time=0.8)
        idm   = IDMModel(desired_speed=30.0, time_headway=1.5)
        state = _state(gap=30.0, lead_speed=20.0, speed=20.0)
        assert human.compute(state).acceleration == pytest.approx(
            idm.compute(state).acceleration
        )

    def test_no_none_output_on_first_call(self):
        # Even with a long reaction time, first call must return a valid float
        human = IDMHumanModel(desired_speed=30.0, time_headway=1.5, reaction_time=2.0)
        result = human.compute(_state()).acceleration
        assert isinstance(result, float)
        assert result == result   # not NaN


class TestIDMHumanModelDelay:

    def test_perceived_gap_is_delayed(self):
        # A sudden gap decrease should not be felt until reaction_time has elapsed.
        # n = round(0.03/0.01) = 3; effective delay = n−1 = 2 steps.
        dt            = 0.01
        reaction_time = 0.03
        human = IDMHumanModel(desired_speed=30.0, time_headway=1.5,
                              reaction_time=reaction_time, dt=dt)

        open_state  = _state(gap=50.0, lead_speed=20.0, speed=20.0)
        close_state = _state(gap=2.0,  lead_speed=20.0, speed=20.0)

        # Step 0: pre-fills buffer with open_state perceived quantities
        a_open = human.compute(open_state).acceleration

        # Step 1: switch to dangerously close gap — delay means model still sees open
        human.compute(close_state)
        # Step 2: still delayed
        a_still_delayed = human.compute(close_state).acceleration

        # Step 3: first step that sees the new gap (2 steps after the change)
        a_delayed_seen = human.compute(close_state).acceleration

        assert a_still_delayed == pytest.approx(a_open, rel=1e-6)
        assert a_delayed_seen  != pytest.approx(a_open, rel=1e-3)

    def test_perceived_lead_speed_is_delayed(self):
        # A sudden leader braking should not be felt immediately.
        dt            = 0.01
        reaction_time = 0.03    # n=3, delay=2 steps
        human = IDMHumanModel(desired_speed=30.0, time_headway=1.5,
                              reaction_time=reaction_time, dt=dt)

        normal_state = _state(gap=20.0, lead_speed=20.0, speed=20.0)
        braking_lead = _state(gap=20.0, lead_speed=5.0,  speed=20.0)

        a_normal = human.compute(normal_state).acceleration   # step 0, seeds buffer
        human.compute(braking_lead)                           # step 1, change not seen yet
        a_still_normal = human.compute(braking_lead).acceleration   # step 2, still normal
        a_reacted      = human.compute(braking_lead).acceleration   # step 3, now sees slow leader

        assert a_still_normal == pytest.approx(a_normal, rel=1e-6)
        # Slower leader = positive dv → larger s_star → stronger braking
        assert a_reacted < a_normal

    def test_ego_speed_is_not_delayed(self):
        # Ego speed changes the IDM output immediately, even with a long delay buffer.
        human = IDMHumanModel(desired_speed=30.0, time_headway=1.5,
                              reaction_time=5.0, dt=0.01)   # very long delay

        steady = _state(gap=40.0, lead_speed=20.0, speed=20.0)
        for _ in range(5):
            human.compute(steady)   # warm up — perceived quantities locked at steady

        a_slow = human.compute(_state(gap=40.0, lead_speed=20.0, speed=20.0)).acceleration
        a_fast = human.compute(_state(gap=40.0, lead_speed=20.0, speed=28.0)).acceleration

        # Faster ego speed → closer to v0=30 → smaller free-road term → less acceleration
        assert a_fast < a_slow


class TestIDMHumanModelPhysics:

    def test_free_road_acceleration(self):
        # With enormous gap and speed=0, interaction term ≈ 0 → a ≈ a_max
        human = IDMHumanModel(desired_speed=30.0, time_headway=1.5,
                              a_max=1.5, reaction_time=0.1)
        a = human.compute(_state(gap=10_000.0, lead_speed=30.0, speed=0.0)).acceleration
        assert a == pytest.approx(1.5, rel=0.01)

    def test_at_desired_speed_free_road_term_is_zero(self):
        # When speed == v0 and gap is large, free-road term = 1-(v0/v0)^4 = 0
        # Interaction term also small → output near zero
        human = IDMHumanModel(desired_speed=20.0, time_headway=1.5, reaction_time=0.1)
        a = human.compute(_state(gap=10_000.0, lead_speed=20.0, speed=20.0)).acceleration
        assert abs(a) < 0.05

    def test_output_clipped_to_a_min(self):
        # Dangerously small gap should never produce acceleration below a_min
        human = IDMHumanModel(desired_speed=30.0, time_headway=1.5,
                              a_min=-6.0, reaction_time=0.8)
        a = human.compute(_state(gap=0.1, lead_speed=0.0, speed=30.0)).acceleration
        assert a >= -6.0

    def test_output_clipped_to_a_max(self):
        # Very large gap + low speed should not exceed a_max
        human = IDMHumanModel(desired_speed=30.0, time_headway=1.5,
                              a_max=1.5, reaction_time=0.8)
        a = human.compute(_state(gap=10_000.0, lead_speed=30.0, speed=0.0)).acceleration
        assert a <= 1.5

    def test_matches_idm_at_zero_reaction_time(self):
        # reaction_time=0 → n=max(1,0)=1-slot buffer → zero delay → same as IDMModel
        human = IDMHumanModel(desired_speed=30.0, time_headway=1.5,
                              reaction_time=0.0, dt=0.01)
        idm   = IDMModel(desired_speed=30.0, time_headway=1.5)
        for gap, speed in [(30.0, 20.0), (5.0, 25.0), (100.0, 15.0)]:
            state = _state(gap=gap, lead_speed=20.0, speed=speed)
            assert human.compute(state).acceleration == pytest.approx(
                idm.compute(state).acceleration, rel=1e-6
            )
