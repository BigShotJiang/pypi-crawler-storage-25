"""Tests for cacc_sim/output.py — Step 12 state logging and CSV output."""
import matplotlib
matplotlib.use('Agg')   # must precede pyplot imports; ensures no display needed

from pathlib import Path

import openpyxl
import pandas as pd
import pytest
import yaml

from cacc_sim.controllers import CACCController
from cacc_sim.driving_models import CACCModel, IDMModel, LeadVehicleModel
from cacc_sim.filters import PassthroughFilter
from cacc_sim.loader import SimConfig
from cacc_sim.output import save_run
from cacc_sim.plant import VehiclePlant, VehicleResponseModel
from cacc_sim.profile import LeadVehicleProfile
from cacc_sim.simulation import SimulationLoop
from cacc_sim.vehicle import Vehicle


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _make_vehicles():
    profile = LeadVehicleProfile(pd.DataFrame({
        'time_s': [0.0, 9999.0], 'value': [20.0, 20.0], 'transition': ['ramp', 'ramp'],
    }))
    lead = Vehicle(
        id=1,
        model=LeadVehicleModel(profile=profile),
        response=VehicleResponseModel(mode='kinematic'),
        plant=VehiclePlant(x0=100.0, v0=20.0, length=5.0),
        filter_=PassthroughFilter(),
        leader_id=None,
    )
    follower = Vehicle(
        id=2,
        model=IDMModel(desired_speed=30.0, time_headway=1.5),
        response=VehicleResponseModel(mode='kinematic'),
        plant=VehiclePlant(x0=70.0, v0=20.0, length=5.0),
        filter_=PassthroughFilter(),
        leader_id=1,
    )
    return [lead, follower]


def _run_minimal(duration_s: float = 1.0):
    vehicles = _make_vehicles()
    config = SimConfig(duration_s=duration_s, response_model='kinematic')
    df = SimulationLoop(vehicles, config).run()
    return df, vehicles, config


def _write_minimal_excel(path: Path) -> None:
    wb = openpyxl.Workbook()
    ws = wb.active
    ws.title = 'vehicles'
    ws.append(['vehicle_id', 'model', 'initial_position_m', 'initial_speed_mps',
               'vehicle_length_m', 'leader_id', 'filter', 'desired_speed_mps', 'time_headway_s'])
    ws.append([1, 'LEAD_PROFILE', 100.0, 20.0, 5.0, None, 'passthrough', None, None])
    ws.append([2, 'IDMModel',      70.0, 20.0, 5.0,    1, 'passthrough', 30.0, 1.5])
    ws_s = wb.create_sheet('simulation')
    for k, v in [('duration_s', 1.0), ('response_model', 'kinematic')]:
        ws_s.append([k, v])
    ws_p = wb.create_sheet('profile')
    ws_p.append(['time_s', 'value', 'transition'])
    ws_p.append([0.0, 20.0, 'ramp'])
    ws_p.append([10.0, 20.0, 'ramp'])
    wb.save(str(path))


# ---------------------------------------------------------------------------
# DataFrame schema — a_cmd and leader_id additions
# ---------------------------------------------------------------------------

def test_log_has_a_cmd_column():
    df, _, _ = _run_minimal()
    assert 'a_cmd' in df.columns


def test_log_has_leader_id_column():
    df, _, _ = _run_minimal()
    assert 'leader_id' in df.columns


def test_leader_id_is_none_for_lead_vehicle():
    df, _, _ = _run_minimal()
    assert df.loc[df['id'] == 1, 'leader_id'].isna().all()


def test_leader_id_correct_for_follower():
    df, _, _ = _run_minimal()
    assert (df.loc[df['id'] == 2, 'leader_id'] == 1).all()


def test_a_cmd_present_every_row():
    df, _, _ = _run_minimal()
    assert df['a_cmd'].notna().all()


# ---------------------------------------------------------------------------
# save_run — subfolder structure and file names
# ---------------------------------------------------------------------------

_TS = '20260421_120000'


def test_run_dir_created(tmp_path):
    ep = tmp_path / 'scenario.xlsx'
    _write_minimal_excel(ep)
    df, vehicles, config = _run_minimal()
    run_dir = save_run(df, str(ep), vehicles, config, timestamp=_TS)
    assert run_dir.is_dir()
    assert run_dir.name == f'scenario_{_TS}'
    assert run_dir.parent.name == 'results'


def test_csv_file_created(tmp_path):
    ep = tmp_path / 'scenario.xlsx'
    _write_minimal_excel(ep)
    df, vehicles, config = _run_minimal()
    run_dir = save_run(df, str(ep), vehicles, config, timestamp=_TS)
    assert (run_dir / 'data.csv').exists()


def test_excel_copy_created(tmp_path):
    ep = tmp_path / 'scenario.xlsx'
    _write_minimal_excel(ep)
    df, vehicles, config = _run_minimal()
    run_dir = save_run(df, str(ep), vehicles, config, timestamp=_TS)
    assert (run_dir / 'input.xlsx').exists()


def test_yaml_file_created(tmp_path):
    ep = tmp_path / 'scenario.xlsx'
    _write_minimal_excel(ep)
    df, vehicles, config = _run_minimal()
    run_dir = save_run(df, str(ep), vehicles, config, timestamp=_TS)
    assert (run_dir / 'metadata.yaml').exists()


def test_auto_timestamp_produces_one_csv(tmp_path):
    ep = tmp_path / 'scenario.xlsx'
    _write_minimal_excel(ep)
    df, vehicles, config = _run_minimal()
    run_dir = save_run(df, str(ep), vehicles, config)
    assert (run_dir / 'data.csv').exists()


# ---------------------------------------------------------------------------
# Index file
# ---------------------------------------------------------------------------

def test_index_csv_created(tmp_path):
    ep = tmp_path / 'scenario.xlsx'
    _write_minimal_excel(ep)
    df, vehicles, config = _run_minimal()
    save_run(df, str(ep), vehicles, config, timestamp=_TS)
    assert (tmp_path / 'results' / 'index.csv').exists()


def test_index_csv_has_header_and_one_row(tmp_path):
    ep = tmp_path / 'scenario.xlsx'
    _write_minimal_excel(ep)
    df, vehicles, config = _run_minimal()
    save_run(df, str(ep), vehicles, config, timestamp=_TS)
    index = pd.read_csv(tmp_path / 'results' / 'index.csv')
    assert list(index.columns) == ['run_folder', 'scenario', 'timestamp',
                                    'seed', 'duration_s', 'n_vehicles', 'cacc_k_ff']
    assert len(index) == 1
    assert index.iloc[0]['run_folder'] == f'scenario_{_TS}'
    assert index.iloc[0]['scenario'] == 'scenario'


def test_index_csv_appends_across_runs(tmp_path):
    ep = tmp_path / 'scenario.xlsx'
    _write_minimal_excel(ep)
    df, vehicles, config = _run_minimal()
    save_run(df, str(ep), vehicles, config, timestamp='20260421_120000')
    save_run(df, str(ep), vehicles, config, timestamp='20260421_130000')
    index = pd.read_csv(tmp_path / 'results' / 'index.csv')
    assert len(index) == 2


# ---------------------------------------------------------------------------
# CSV content
# ---------------------------------------------------------------------------

def test_csv_row_count_matches_dataframe(tmp_path):
    ep = tmp_path / 'scenario.xlsx'
    _write_minimal_excel(ep)
    df, vehicles, config = _run_minimal()
    run_dir = save_run(df, str(ep), vehicles, config, timestamp=_TS)
    loaded = pd.read_csv(run_dir / 'data.csv')
    assert len(loaded) == len(df)


def test_csv_columns_match_dataframe(tmp_path):
    ep = tmp_path / 'scenario.xlsx'
    _write_minimal_excel(ep)
    df, vehicles, config = _run_minimal()
    run_dir = save_run(df, str(ep), vehicles, config, timestamp=_TS)
    loaded = pd.read_csv(run_dir / 'data.csv')
    assert set(loaded.columns) == set(df.columns)


# ---------------------------------------------------------------------------
# YAML content
# ---------------------------------------------------------------------------

def _load_yaml(tmp_path) -> dict:
    ep = tmp_path / 'scenario.xlsx'
    _write_minimal_excel(ep)
    df, vehicles, config = _run_minimal()
    run_dir = save_run(df, str(ep), vehicles, config, timestamp=_TS)
    with open(run_dir / 'metadata.yaml', encoding='utf-8') as fh:
        return yaml.safe_load(fh)


def test_yaml_required_keys_present(tmp_path):
    meta = _load_yaml(tmp_path)
    for key in ('run_name', 'timestamp', 'version', 'excel_input',
                'duration_s', 'log_rate_hz', 'n_vehicles', 'n_steps', 'response_model',
                'string_stability', 'response_params'):
        assert key in meta, f"Missing YAML key: {key}"


def test_yaml_n_vehicles(tmp_path):
    meta = _load_yaml(tmp_path)
    assert meta['n_vehicles'] == 2


def test_yaml_n_steps(tmp_path):
    meta = _load_yaml(tmp_path)
    # 1 s at log_rate_hz=10 (default) = 10 logged steps per vehicle
    assert meta['n_steps'] == 10


def test_yaml_response_params_both_vehicles(tmp_path):
    meta = _load_yaml(tmp_path)
    assert set(meta['response_params'].keys()) == {1, 2}


def test_yaml_response_params_has_expected_keys(tmp_path):
    meta = _load_yaml(tmp_path)
    for vid in (1, 2):
        params = meta['response_params'][vid]
        for key in ('mode', 'tau_throttle_s', 'tau_brake_s',
                    'a_max_mps2', 'a_min_mps2', 'j_max_mps3'):
            assert key in params, f"Missing response_params key for vehicle {vid}: {key}"


def test_yaml_string_stability_empty_for_non_cacc(tmp_path):
    meta = _load_yaml(tmp_path)
    assert meta['string_stability'] == {}


# ---------------------------------------------------------------------------
# string_stable property on CACCController
# ---------------------------------------------------------------------------

def test_string_stable_true_when_condition_met():
    ctrl = CACCController(k1=0.2, k2=0.7, k_ff=1.0, target_headway_s=0.6)
    # k_ff + k2 * T_h = 1.0 + 0.7 * 0.6 = 1.42 >= 1.0
    assert ctrl.string_stable is True


def test_string_stable_false_when_condition_violated():
    # Use gains that violate k_ff + k2 * T_h >= 1
    with pytest.warns(UserWarning):
        ctrl = CACCController(k1=0.45, k2=0.25, k_ff=0.45, target_headway_s=0.6)
    # k_ff + k2 * T_h = 0.45 + 0.25 * 0.6 = 0.60 < 1.0
    assert ctrl.string_stable is False


def test_yaml_string_stability_populated_for_cacc_vehicle(tmp_path):
    ep = tmp_path / 'scenario.xlsx'
    _write_minimal_excel(ep)
    profile = LeadVehicleProfile(pd.DataFrame({
        'time_s': [0.0, 9999.0], 'value': [20.0, 20.0], 'transition': ['ramp', 'ramp'],
    }))
    lead = Vehicle(
        id=1,
        model=LeadVehicleModel(profile=profile),
        response=VehicleResponseModel(mode='kinematic'),
        plant=VehiclePlant(x0=100.0, v0=20.0, length=5.0),
        filter_=PassthroughFilter(),
        leader_id=None,
    )
    ctrl = CACCController(k1=0.2, k2=0.7, k_ff=1.0, target_headway_s=0.6)
    cacc_v = Vehicle(
        id=2,
        model=CACCModel(desired_speed=30.0, controller=ctrl),
        response=VehicleResponseModel(mode='kinematic'),
        plant=VehiclePlant(x0=70.0, v0=20.0, length=5.0),
        filter_=PassthroughFilter(),
        leader_id=1,
    )
    config = SimConfig(duration_s=0.5, response_model='kinematic')
    df = SimulationLoop([lead, cacc_v], config).run()
    run_dir = save_run(df, str(ep), [lead, cacc_v], config, timestamp=_TS)
    with open(run_dir / 'metadata.yaml', encoding='utf-8') as fh:
        meta = yaml.safe_load(fh)
    assert 2 in meta['string_stability']
    assert meta['string_stability'][2] is True
