"""Tests for cacc_sim/plot.py — Step 13 post-run visualisation."""
import matplotlib
matplotlib.use('Agg')   # must precede pyplot imports; ensures no display needed

import pandas as pd
import pytest

from cacc_sim.driving_models import IDMModel, LeadVehicleModel
from cacc_sim.filters import PassthroughFilter
from cacc_sim.loader import SimConfig
from cacc_sim.plant import VehiclePlant, VehicleResponseModel
from cacc_sim.plot import plot_run
from cacc_sim.profile import LeadVehicleProfile
from cacc_sim.simulation import SimulationLoop
from cacc_sim.vehicle import Vehicle


# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------

def _run_sim(tmp_path, duration_s=1.0):
    """Run a minimal 2-vehicle sim, write CSV, return csv_path."""
    profile = LeadVehicleProfile(pd.DataFrame({
        'time_s': [0.0, 9999.0], 'value': [20.0, 20.0], 'transition': ['ramp', 'ramp'],
    }))
    lead = Vehicle(
        id=1, model=LeadVehicleModel(profile=profile),
        response=VehicleResponseModel(mode='kinematic'),
        plant=VehiclePlant(x0=100.0, v0=20.0, length=5.0),
        filter_=PassthroughFilter(), leader_id=None,
    )
    follower = Vehicle(
        id=2, model=IDMModel(desired_speed=30.0, time_headway=1.5),
        response=VehicleResponseModel(mode='kinematic'),
        plant=VehiclePlant(x0=70.0, v0=20.0, length=5.0),
        filter_=PassthroughFilter(), leader_id=1,
    )
    config = SimConfig(duration_s=duration_s, response_model='kinematic')
    df = SimulationLoop([lead, follower], config).run()
    csv_path = tmp_path / 'scenario_ts.csv'
    df.to_csv(str(csv_path), index=False)
    return csv_path


# ---------------------------------------------------------------------------
# File creation
# ---------------------------------------------------------------------------

def test_composite_png_created(tmp_path):
    csv = _run_sim(tmp_path)
    plot_run(str(csv))
    assert (tmp_path / 'scenario_ts.png').exists()


def test_speed_png_created(tmp_path):
    csv = _run_sim(tmp_path)
    plot_run(str(csv))
    assert (tmp_path / 'scenario_ts_speed.png').exists()


def test_gap_png_created(tmp_path):
    csv = _run_sim(tmp_path)
    plot_run(str(csv))
    assert (tmp_path / 'scenario_ts_gap.png').exists()


def test_accel_png_created(tmp_path):
    csv = _run_sim(tmp_path)
    plot_run(str(csv))
    assert (tmp_path / 'scenario_ts_accel.png').exists()


def test_lag_png_created(tmp_path):
    csv = _run_sim(tmp_path)
    plot_run(str(csv))
    assert (tmp_path / 'scenario_ts_lag.png').exists()


def test_all_files_nonzero(tmp_path):
    csv = _run_sim(tmp_path)
    plot_run(str(csv))
    suffixes = ['', '_speed', '_gap', '_accel', '_lag']
    for s in suffixes:
        p = tmp_path / f'scenario_ts{s}.png'
        assert p.stat().st_size > 0, f'{p.name} is empty'


# ---------------------------------------------------------------------------
# Edge cases
# ---------------------------------------------------------------------------

def test_single_vehicle_no_crash(tmp_path):
    """Lead-only run: gap panel should show 'no following vehicles', not crash."""
    profile = LeadVehicleProfile(pd.DataFrame({
        'time_s': [0.0, 9999.0], 'value': [20.0, 20.0], 'transition': ['ramp', 'ramp'],
    }))
    lead = Vehicle(
        id=1, model=LeadVehicleModel(profile=profile),
        response=VehicleResponseModel(mode='kinematic'),
        plant=VehiclePlant(x0=100.0, v0=20.0, length=5.0),
        filter_=PassthroughFilter(), leader_id=None,
    )
    config = SimConfig(duration_s=0.5, response_model='kinematic')
    df = SimulationLoop([lead], config).run()
    csv_path = tmp_path / 'lead_only.csv'
    df.to_csv(str(csv_path), index=False)
    plot_run(str(csv_path))   # must not raise
    assert (tmp_path / 'lead_only.png').exists()


def test_show_false_does_not_block(tmp_path):
    """show=False must return without waiting for user interaction."""
    csv = _run_sim(tmp_path, duration_s=0.5)
    plot_run(str(csv), show=False)   # returns immediately


# ---------------------------------------------------------------------------
# Palette
# ---------------------------------------------------------------------------

def test_palette_colors_are_hex_strings():
    from cacc_sim.palette import MODEL_COLORS, DEFAULT_COLOR
    for name, color in MODEL_COLORS.items():
        assert color.startswith('#') and len(color) == 7, f'{name}: bad hex {color!r}'
    assert DEFAULT_COLOR.startswith('#')


def test_palette_to_rgb255_roundtrip():
    from cacc_sim.palette import to_rgb255
    assert to_rgb255('#DCDCDC') == (220, 220, 220)
    assert to_rgb255('#000000') == (0, 0, 0)
    assert to_rgb255('#FFFFFF') == (255, 255, 255)


def test_renderer_colors_consistent_with_palette():
    """Renderer model colors must match the palette (no silent drift)."""
    from cacc_sim.palette import MODEL_COLORS, to_rgb255
    from cacc_sim.renderer import _MODEL_COLORS_PYGAME
    for model, hex_color in MODEL_COLORS.items():
        assert _MODEL_COLORS_PYGAME[model] == to_rgb255(hex_color), (
            f'{model}: renderer has {_MODEL_COLORS_PYGAME[model]}, '
            f'palette says {to_rgb255(hex_color)}'
        )
