"""Tests for CACCModel in cacc_sim/driving_models.py."""
import pytest

from cacc_sim.controllers import CACCController
from cacc_sim.core import VehicleState, DrivingModelOutput
from cacc_sim.driving_models import CACCModel


def _ctrl(k1=0.2, k2=0.7, k_ff=1.0, T_h=0.6, s0=2.0) -> CACCController:
    return CACCController(k1=k1, k2=k2, k_ff=k_ff, target_headway_s=T_h, s0=s0)


def _model(v0=25.0, a_max=2.5, a_min=-8.0, delta=4.0) -> CACCModel:
    return CACCModel(desired_speed=v0, controller=_ctrl(), a_max=a_max, a_min=a_min, delta=delta)


def _state(
    speed=20.0,
    gap=14.0,
    lead_speed=20.0,
    lead_a_v2v=0.0,
    acceleration=0.0,
    t=0.0,
    position=0.0,
) -> VehicleState:
    return VehicleState(
        speed=speed,
        acceleration=acceleration,
        time=t,
        position=position,
        gap=gap,
        lead_speed=lead_speed,
        lead_a_v2v=lead_a_v2v,
    )


# ---------------------------------------------------------------------------
# required_inputs
# ---------------------------------------------------------------------------

def test_required_inputs():
    assert CACCModel.required_inputs() == {'speed', 'gap', 'lead_speed', 'lead_a_v2v'}


# ---------------------------------------------------------------------------
# Returns DrivingModelOutput
# ---------------------------------------------------------------------------

def test_returns_driving_model_output():
    m = _model()
    result = m.compute(_state())
    assert isinstance(result, DrivingModelOutput)


# ---------------------------------------------------------------------------
# Free-road behaviour (lead_a_v2v = 0.0, huge gap)
# ---------------------------------------------------------------------------

class TestFreeRoad:
    def test_v2v_zero_at_huge_gap_free_road_wins(self):
        """With lead_a_v2v=0.0 and realistic gains, free-road cap dominates at large gap."""
        # a_follow = k1*e_gap + k2*e_vel + k_ff*0 => huge positive, clipped to a_max
        # free_road = 2.5*(1-(20/25)^4) = ~1.476; min(a_free, a_max) = a_free
        m = _model(v0=25.0)
        state = _state(speed=20.0, gap=9999.0, lead_speed=20.0, lead_a_v2v=0.0)
        a = m.compute(state).acceleration
        a_free = 2.5 * (1.0 - (20.0 / 25.0) ** 4)
        assert a == pytest.approx(a_free, rel=1e-5)

    def test_free_road_at_desired_speed_is_zero(self):
        """At desired speed with zero V2V, free-road term is zero and wins."""
        m = CACCModel(desired_speed=20.0, controller=_ctrl(), a_max=2.5)
        state = _state(speed=20.0, gap=9999.0, lead_speed=20.0, lead_a_v2v=0.0)
        assert m.compute(state).acceleration == pytest.approx(0.0, abs=1e-6)

    def test_free_road_positive_when_below_desired(self):
        """Below desired speed with zero V2V, output is positive."""
        m = _model(v0=25.0)
        state = _state(speed=15.0, gap=9999.0, lead_speed=15.0, lead_a_v2v=0.0)
        assert m.compute(state).acceleration > 0.0


# ---------------------------------------------------------------------------
# CACC following mode
# ---------------------------------------------------------------------------

class TestCACCFollowing:
    def test_v2v_braking_outweighs_free_road(self):
        """Negative V2V acceleration (leader braking) causes CACC to brake."""
        m = _model(v0=25.0)
        # At desired gap + matched speed: a_follow = k_ff * (-3.0) = -3.0
        # free-road ≈ +1.476 → min(-3.0, 1.476) = -3.0
        state = _state(speed=20.0, gap=14.0, lead_speed=20.0, lead_a_v2v=-3.0)
        assert m.compute(state).acceleration < 0.0

    def test_v2v_zero_vs_positive_differ(self):
        """Positive V2V acceleration increases output vs. zero feedforward."""
        m = _model(v0=25.0)
        a_zero = m.compute(_state(speed=20.0, gap=14.0, lead_speed=20.0, lead_a_v2v=0.0)).acceleration
        a_pos  = m.compute(_state(speed=20.0, gap=14.0, lead_speed=20.0, lead_a_v2v=2.0)).acceleration
        assert a_pos > a_zero

    def test_free_road_caps_follow_output(self):
        """When gap is huge, free-road term caps the CACC output (min selection)."""
        m = CACCModel(desired_speed=25.0, controller=_ctrl(k1=0.2, k2=0.7, k_ff=1.0),
                      a_max=2.5, delta=4.0)
        state = _state(speed=20.0, gap=9999.0, lead_speed=20.0, lead_a_v2v=0.0)
        a = m.compute(state).acceleration
        a_free = 2.5 * (1.0 - (20.0 / 25.0) ** 4)
        assert a == pytest.approx(a_free, rel=1e-5)

    def test_follow_wins_over_free_road_when_gap_tight(self):
        """When gap is much smaller than desired, CACC commands braking."""
        m = _model(v0=25.0)
        state = _state(speed=20.0, gap=2.0, lead_speed=20.0, lead_a_v2v=0.0)
        assert m.compute(state).acceleration < 0.0


# ---------------------------------------------------------------------------
# Output clipping
# ---------------------------------------------------------------------------

class TestOutputClipping:
    def test_clipped_at_a_max(self):
        m = CACCModel(desired_speed=25.0, controller=_ctrl(k1=100.0, k2=0.0, k_ff=0.0),
                      a_max=2.5, a_min=-8.0)
        state = _state(speed=10.0, gap=9999.0, lead_speed=10.0, lead_a_v2v=0.0)
        assert m.compute(state).acceleration <= 2.5

    def test_clipped_at_a_min(self):
        m = CACCModel(desired_speed=25.0, controller=_ctrl(k1=100.0, k2=0.0, k_ff=0.0),
                      a_max=2.5, a_min=-8.0)
        state = _state(speed=20.0, gap=0.0, lead_speed=20.0, lead_a_v2v=0.0)
        assert m.compute(state).acceleration >= -8.0


# ---------------------------------------------------------------------------
# Integration: load via loader
# ---------------------------------------------------------------------------

def test_loader_builds_cacc_model():
    """_build_model correctly instantiates CACCModel from a row + SimConfig."""
    import pandas as pd
    from cacc_sim.loader import SimConfig, _build_model

    row = pd.Series({'model': 'CACCModel', 'desired_speed_mps': 22.0})
    cfg = SimConfig()
    model = _build_model(row, None, cfg)
    assert isinstance(model, CACCModel)
    assert model.v0 == pytest.approx(22.0)
    assert isinstance(model.controller, CACCController)
    assert model.controller.k1  == pytest.approx(cfg.cacc_k1)
    assert model.controller.k2  == pytest.approx(cfg.cacc_k2)
    assert model.controller.k_ff == pytest.approx(cfg.cacc_k_ff)
    assert model.controller.T_h == pytest.approx(cfg.cacc_target_headway_s)
