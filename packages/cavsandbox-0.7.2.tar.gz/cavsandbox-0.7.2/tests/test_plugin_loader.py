"""Tests for the plugin loader (load_plugins) and from_excel_row dispatch."""
from __future__ import annotations

import sys
import warnings
from pathlib import Path
from textwrap import dedent

import pandas as pd
import pytest

# Ensure project root on path so plugins/ is resolvable
sys.path.insert(0, str(Path(__file__).parent.parent))

from cacc_sim.core import DrivingModel, DrivingModelOutput, VehicleState
from cacc_sim.driving_models import CACCModel, IDMHumanModel, IDMModel, LeadVehicleModel
from cacc_sim.loader import (
    FILTER_REGISTRY,
    MODEL_REGISTRY,
    SimConfig,
    _build_model,
    load_plugins,
)


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _row(**kwargs) -> pd.Series:
    return pd.Series(kwargs)


def _cfg(**kwargs) -> SimConfig:
    return SimConfig(**kwargs)


# ---------------------------------------------------------------------------
# from_excel_row — built-in models
# ---------------------------------------------------------------------------

class TestFromExcelRow:
    def test_idm_model(self):
        row = _row(desired_speed_mps=25.0, time_headway_s=1.5)
        m = IDMModel.from_excel_row(row, SimConfig())
        assert isinstance(m, IDMModel)
        assert m.v0 == pytest.approx(25.0)
        assert m.T  == pytest.approx(1.5)

    def test_idm_human_model(self):
        row = _row(desired_speed_mps=22.0, time_headway_s=1.2, reaction_time_s=0.8)
        m = IDMHumanModel.from_excel_row(row, SimConfig(timestep_s=0.01))
        assert isinstance(m, IDMHumanModel)
        assert m.v0 == pytest.approx(22.0)

    def test_cacc_model(self):
        row = _row(desired_speed_mps=28.0)
        cfg = SimConfig(cacc_k1=0.3, cacc_k2=0.8, cacc_k_ff=1.0,
                        cacc_target_headway_s=0.5, cacc_s0_m=2.0)
        m = CACCModel.from_excel_row(row, cfg)
        assert isinstance(m, CACCModel)
        assert m.v0 == pytest.approx(28.0)
        assert m.controller.k1 == pytest.approx(0.3)

    def test_lead_vehicle_model_raises(self):
        with pytest.raises(NotImplementedError, match="LeadVehicleProfile"):
            LeadVehicleModel.from_excel_row(_row(), SimConfig())

    def test_base_class_raises(self):
        class _Stub(DrivingModel):
            @classmethod
            def required_inputs(cls): return set()
            def compute(self, state): ...

        with pytest.raises(NotImplementedError, match="from_excel_row"):
            _Stub.from_excel_row(_row(), SimConfig())


# ---------------------------------------------------------------------------
# _build_model dispatch
# ---------------------------------------------------------------------------

class TestBuildModel:
    def test_dispatches_via_from_excel_row(self):
        row = _row(model='IDMModel', desired_speed_mps=20.0, time_headway_s=1.5)
        m = _build_model(row, None, SimConfig())
        assert isinstance(m, IDMModel)

    def test_lead_profile_special_case(self):
        from cacc_sim.driving_models import LeadVehicleModel
        from cacc_sim.profile import LeadVehicleProfile
        profile = LeadVehicleProfile(pd.DataFrame({
            'time_s': [0.0, 10.0], 'value': [20.0, 20.0], 'transition': ['ramp', 'ramp'],
        }))
        row = _row(model='LEAD_PROFILE')
        m = _build_model(row, profile, SimConfig())
        assert isinstance(m, LeadVehicleModel)

    def test_lead_profile_without_profile_raises(self):
        row = _row(model='LEAD_PROFILE')
        with pytest.raises(ValueError, match="profile sheet"):
            _build_model(row, None, SimConfig())


# ---------------------------------------------------------------------------
# load_plugins
# ---------------------------------------------------------------------------

class TestLoadPlugins:
    def test_loads_wiedemann_from_plugins_dir(self):
        """The shipped plugin registers Wiedemann99Model."""
        original = dict(MODEL_REGISTRY)
        try:
            # Remove if already registered from a previous test run
            MODEL_REGISTRY.pop('Wiedemann99Model', None)
            load_plugins('plugins')
            assert 'Wiedemann99Model' in MODEL_REGISTRY
        finally:
            # Restore registry to pre-test state
            MODEL_REGISTRY.clear()
            MODEL_REGISTRY.update(original)

    def test_idempotent_double_call(self):
        """Calling load_plugins() twice does not warn or double-register."""
        original = dict(MODEL_REGISTRY)
        try:
            MODEL_REGISTRY.pop('Wiedemann99Model', None)
            load_plugins('plugins')
            cls_first = MODEL_REGISTRY.get('Wiedemann99Model')
            with warnings.catch_warnings():
                warnings.simplefilter('error')
                load_plugins('plugins')          # second call must not warn
            assert MODEL_REGISTRY.get('Wiedemann99Model') is cls_first
        finally:
            MODEL_REGISTRY.clear()
            MODEL_REGISTRY.update(original)

    def test_missing_plugin_dir_is_noop(self, tmp_path):
        """A non-existent plugin dir produces no error and no registry change."""
        original = dict(MODEL_REGISTRY)
        try:
            load_plugins(str(tmp_path / 'nonexistent'))
            assert MODEL_REGISTRY == original
        finally:
            MODEL_REGISTRY.clear()
            MODEL_REGISTRY.update(original)

    def test_name_collision_warns_and_preserves_builtin(self, tmp_path):
        """A plugin whose class name matches a built-in triggers a warning; built-in kept."""
        # Write a plugin that defines IDMModel (collides with built-in)
        plugin = tmp_path / 'bad_plugin.py'
        plugin.write_text(dedent("""\
            from cacc_sim import DrivingModel, DrivingModelOutput, VehicleState
            class IDMModel(DrivingModel):
                @classmethod
                def required_inputs(cls): return set()
                def compute(self, state): return DrivingModelOutput(acceleration=0.0)
                @classmethod
                def from_excel_row(cls, row, sim_config): return cls()
        """))
        original_idm = MODEL_REGISTRY['IDMModel']
        try:
            with pytest.warns(UserWarning, match="collides"):
                load_plugins(str(tmp_path))
            assert MODEL_REGISTRY['IDMModel'] is original_idm
        finally:
            MODEL_REGISTRY['IDMModel'] = original_idm

    def test_valid_plugin_registers_and_dispatches(self, tmp_path):
        """A correctly written plugin is registered and instantiable via _build_model."""
        plugin = tmp_path / 'my_model.py'
        plugin.write_text(dedent("""\
            from cacc_sim import DrivingModel, DrivingModelOutput, VehicleState
            class ConstantModel(DrivingModel):
                def __init__(self, accel=0.0): self.accel = accel
                @classmethod
                def required_inputs(cls): return {'speed'}
                def compute(self, state): return DrivingModelOutput(acceleration=self.accel)
                @classmethod
                def from_excel_row(cls, row, sim_config):
                    return cls(accel=float(row.get('const_accel', 0.0)))
        """))
        original = dict(MODEL_REGISTRY)
        try:
            load_plugins(str(tmp_path))
            assert 'ConstantModel' in MODEL_REGISTRY
            row = _row(model='ConstantModel', const_accel=1.5)
            m = _build_model(row, None, SimConfig())
            assert m.accel == pytest.approx(1.5)
        finally:
            MODEL_REGISTRY.clear()
            MODEL_REGISTRY.update(original)
