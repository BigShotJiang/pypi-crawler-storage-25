"""
Integration tests for Step 17: DSRCBSMTracker + FusionKalmanFilter in a
running 4-vehicle CACC simulation.

These tests verify end-to-end properties — components working correctly
together — and are distinct from the unit tests in tests/test_sensors.py,
which verify individual filter math in isolation.

Run from project root:
    pytest Filter_tests/tests/test_sensors_step17.py -v
"""
from __future__ import annotations

import openpyxl
import pytest
from pathlib import Path

from cacc_sim.loader import load_vehicles
from cacc_sim.simulation import SimulationLoop


# ---------------------------------------------------------------------------
# Shared workbook helper
# ---------------------------------------------------------------------------

def _write_cacc_workbook(
    path: Path,
    profile_rows: list,
    duration_s: float,
    *,
    sensor_model: str = 'kalman',
    comms_model: str = 'dsrc',
    master_seed: int = 42,
    **sim_overrides,
) -> None:
    """
    Write a 4-vehicle CACC workbook at equilibrium initial conditions.

    V1 (lead) at x=100 m; V2-V4 (CACC followers) at x=75, 50, 25 m.
    Initial gap = 100-75-5 = 20 m = cacc_s0_m + cacc_target_headway_s * 30 m/s
    → starts essentially at equilibrium, minimising transient.
    """
    wb = openpyxl.Workbook()

    ws_v = wb.active
    ws_v.title = 'vehicles'
    ws_v.append([
        'vehicle_id', 'model', 'initial_position_m', 'initial_speed_mps',
        'vehicle_length_m', 'leader_id', 'filter', 'desired_speed_mps',
    ])
    ws_v.append([1, 'LEAD_PROFILE', 100.0, 30.0, 5.0, None, 'passthrough', None])
    for vid, x0 in [(2, 75.0), (3, 50.0), (4, 25.0)]:
        ws_v.append([vid, 'CACCModel', x0, 30.0, 5.0, vid - 1, 'passthrough', 33.0])

    ws_s = wb.create_sheet('simulation')
    for key, val in [
        ('duration_s',            duration_s),
        ('response_model',        'lag'),
        ('sensor_model',          sensor_model),
        ('comms_model',           comms_model),
        ('cacc_target_headway_s', 0.6),
        ('cacc_s0_m',             2.0),
        ('master_seed',           master_seed),
        ('log_rate_hz',           10.0),
    ]:
        ws_s.append([key, val])
    for key, val in sim_overrides.items():
        ws_s.append([key, val])

    ws_p = wb.create_sheet('profile')
    ws_p.append(['time_s', 'value', 'transition'])
    for row in profile_rows:
        ws_p.append(list(row))

    wb.save(str(path))


def _constant_profile(speed: float, duration_s: float) -> list:
    return [(0.0, speed, 'ramp'), (duration_s, speed, 'ramp')]


# ---------------------------------------------------------------------------
# Integration test 1: lead_a_radar becomes non-zero after BSM warmup
# ---------------------------------------------------------------------------

def test_lead_a_radar_nonzero_after_warmup(tmp_path):
    """
    With comms_model='dsrc', the fusion KF should produce non-zero
    lead_a_radar estimates for followers once BSM packets start arriving.
    DSRCBSMTracker starts stale, so the first several steps have
    lead_a_radar=0, but after a few packets arrive the KF state evolves.
    """
    xl = tmp_path / 'test_warmup.xlsx'
    _write_cacc_workbook(xl, _constant_profile(30.0, 15.0), duration_s=15.0)
    vehicles, config = load_vehicles(str(xl))
    df = SimulationLoop(vehicles, config).run()

    # Only followers; only after 3 s (time for first BSM cycle + KF settling)
    followers_late = df[(df['id'] > 1) & (df['t'] > 3.0)]
    assert (followers_late['lead_a_radar'] != 0.0).any(), (
        'Expected at least one non-zero lead_a_radar for followers after t=3 s'
    )


# ---------------------------------------------------------------------------
# Integration test 2: KF gap estimate within tolerance in constant-speed stage
# ---------------------------------------------------------------------------

def test_stage1_kf_gap_within_tolerance(tmp_path):
    """
    Stage 1 (constant speed): after KF convergence (t > 10 s) the fused
    gap estimate (gap_filtered) should track the true gap within 1.0 m
    for vehicle 2.

    At 30 m/s the equilibrium gap is exactly 20 m, so true gap should be
    approximately constant, and the KF should lock onto it quickly.
    """
    xl = tmp_path / 'test_stage1.xlsx'
    _write_cacc_workbook(xl, _constant_profile(30.0, 30.0), duration_s=30.0)
    vehicles, config = load_vehicles(str(xl))
    df = SimulationLoop(vehicles, config).run()

    v2_late = df[(df['id'] == 2) & (df['t'] > 10.0)]
    error = (v2_late['gap_filtered'] - v2_late['gap']).abs()
    assert error.max() < 1.0, (
        f'KF gap error exceeds 1.0 m after convergence: max={error.max():.3f} m'
    )


# ---------------------------------------------------------------------------
# Integration test 3: high packet-drop rate produces no NaN propagation
# ---------------------------------------------------------------------------

def test_bsm_drops_no_nan_propagation(tmp_path):
    """
    With packet_drop_rate=0.9 (most packets lost), the sensor pipeline
    must degrade gracefully — BSM goes stale, CACC falls back to pure
    feedback — but no NaN values should appear in any numeric column.
    """
    xl = tmp_path / 'test_highdrop.xlsx'
    _write_cacc_workbook(
        xl, _constant_profile(30.0, 10.0), duration_s=10.0,
        bsm_packet_drop_rate=0.9,
    )
    vehicles, config = load_vehicles(str(xl))
    df = SimulationLoop(vehicles, config).run()

    numeric_cols = [
        'v', 'a', 'gap', 'gap_meas', 'gap_filtered',
        'lead_v_meas', 'lead_a_v2v', 'lead_a_radar', 'bsm_age_s',
    ]
    for col in numeric_cols:
        n_nan = df[col].isna().sum()
        assert n_nan == 0, f"NaN found in column '{col}' ({n_nan} rows)"


# ---------------------------------------------------------------------------
# Integration test 4: bsm_age_s column range and packet-arrival evidence
# ---------------------------------------------------------------------------

def test_bsm_age_s_in_output_range(tmp_path):
    """
    bsm_age_s must be present, non-negative for all rows, and have at
    least one near-zero value for each follower (proving packets arrive).
    The lead vehicle uses a passthrough tracker so its age is always 0.0.
    """
    xl = tmp_path / 'test_bsmage.xlsx'
    _write_cacc_workbook(xl, _constant_profile(30.0, 15.0), duration_s=15.0)
    vehicles, config = load_vehicles(str(xl))
    df = SimulationLoop(vehicles, config).run()

    assert 'bsm_age_s' in df.columns, 'bsm_age_s column missing from output'

    # All values non-negative
    assert (df['bsm_age_s'] >= 0.0).all(), 'bsm_age_s has negative values'

    # Lead vehicle always has 0 (passthrough BSM)
    lead_ages = df[df['id'] == 1]['bsm_age_s']
    assert (lead_ages == 0.0).all(), 'Lead vehicle bsm_age_s is not always 0.0'

    # Each follower must receive at least one fresh packet.
    # The log runs at 10 Hz while BSM fires at 10 Hz, so the closest the log
    # can capture a packet arrival is 1–2 sim-steps after reception → ≈ 0.02 s.
    # Threshold: less than one BSM interval confirms packets are arriving.
    bsm_interval_s = 1.0 / config.bsm_rate_hz
    for vid in (2, 3, 4):
        follower_ages = df[df['id'] == vid]['bsm_age_s']
        assert follower_ages.min() < bsm_interval_s, (
            f'V{vid}: no fresh BSM packet observed '
            f'(min bsm_age_s = {follower_ages.min():.4f} s, '
            f'bsm_interval = {bsm_interval_s:.3f} s)'
        )
