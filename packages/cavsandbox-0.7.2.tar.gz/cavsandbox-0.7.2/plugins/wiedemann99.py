"""
Wiedemann 99 psychophysical car-following model — shipped as a worked plugin example.

Drop-in replacement for IDMHumanModel when a more realistic regime-switching
human driver is needed.  This is PTV VISSIM's default car-following model.

Unlike IDM-based models, Wiedemann drivers don't react continuously: they only
respond when their perception crosses a threshold, producing regime-switching
behaviour that matches naturalistic driving data.

Regime table
------------
free      gap > SDX (perception threshold)  →  accelerate toward desired speed
closing   approaching leader, gap manageable →  begin braking to avoid overshoot
following near equilibrium                  →  small stochastic oscillations
braking   gap < desired gap (emergency)     →  hard deceleration

Parameter names and defaults follow VISSIM conventions (CC0–CC9).

Usage
-----
In the Excel vehicles sheet, set model = 'Wiedemann99Model' and supply at least
desired_speed_mps.  All CC parameters are optional (VISSIM defaults used when
blank).
"""
from __future__ import annotations

import random

import pandas as pd

from cacc_sim import DrivingModel, DrivingModelOutput, VehicleState


class Wiedemann99Model(DrivingModel):
    """
    Wiedemann 99 psychophysical car-following model.

    Parameters
    ----------
    CC0 : float
        Standstill distance (m). Default 1.5.
    CC1 : float
        Headway time (s). Default 0.9.
    CC2 : float
        'Following' threshold addition (m). Default 4.0.
    CC3 : float
        Threshold for entering 'closing' regime. Default -8.0.
    CC4 : float
        Negative speed difference for oscillation lower bound. Default -0.35.
    CC5 : float
        Positive speed difference for oscillation upper bound. Default 0.35.
    CC6 : float
        Influence of speed difference on oscillation. Default 6.0.
    CC7 : float
        Oscillation acceleration. Default 0.25.
    CC8 : float
        Desired acceleration at standstill (m/s²). Default 2.0.
    CC9 : float
        Desired acceleration at 80 km/h (22.2 m/s) (m/s²). Default 1.5.
    desired_speed : float
        Free-road target speed (m/s). Default 30.0.
    seed : int or None
        RNG seed for the stochastic following-regime term.  None (default)
        gives non-reproducible output; an integer gives a reproducible run.
    """

    def __init__(
        self,
        CC0: float = 1.5,
        CC1: float = 0.9,
        CC2: float = 4.0,
        CC3: float = -8.0,
        CC4: float = -0.35,
        CC5: float = 0.35,
        CC6: float = 6.0,
        CC7: float = 0.25,
        CC8: float = 2.0,
        CC9: float = 1.5,
        desired_speed: float = 30.0,
        seed: int | None = None,
    ) -> None:
        self.CC0 = CC0
        self.CC1 = CC1
        self.CC2 = CC2
        self.CC3 = CC3
        self.CC4 = CC4
        self.CC5 = CC5
        self.CC6 = CC6
        self.CC7 = CC7
        self.CC8 = CC8
        self.CC9 = CC9
        self.v_desired = desired_speed
        self._rng = random.Random(seed)
        self.regime: str = 'free'

    @classmethod
    def required_inputs(cls) -> set[str]:
        return {'speed', 'gap', 'lead_speed'}

    @classmethod
    def from_excel_row(cls, row, sim_config) -> 'Wiedemann99Model':
        """
        Instantiate from one vehicles-sheet row.

        Only ``desired_speed_mps`` is required.  Any CC0–CC9 column present
        and non-blank overrides the VISSIM default for that parameter.
        """
        kwargs: dict = {'desired_speed': float(row['desired_speed_mps'])}
        for i in range(10):
            col = f'CC{i}'
            val = row.get(col)
            if val is not None and pd.notnull(val):
                kwargs[col] = float(val)
        return cls(**kwargs)

    # ── Internal helpers ───────────────────────────────────────────────────────

    def _desired_gap(self, v: float) -> float:
        """Desired following distance (m) at speed v."""
        return self.CC0 + self.CC1 * v

    # ── Control law ───────────────────────────────────────────────────────────

    def compute(self, state: VehicleState) -> DrivingModelOutput:
        gap = max(state.gap, 0.1)
        v   = state.speed
        v_l = state.lead_speed
        dv  = v - v_l                        # positive = approaching
        d   = self._desired_gap(v)
        SDX = d + self.CC2                   # perception threshold for 'free' regime
        SDV = (dv ** 2 / (2.0 * max(gap - d, 0.1))) if gap > d else 99.0

        # Regime transitions — priority order matters:
        # braking (emergency) must be evaluated before following so a very
        # small gap with matched speeds goes to braking, not following.
        if gap > SDX:
            self.regime = 'free'
        elif gap < d:
            self.regime = 'braking'
        elif dv > 0 and dv >= SDV:
            self.regime = 'closing'
        else:
            self.regime = 'following'

        # Acceleration by regime
        if self.regime == 'free':
            a = self.CC8 + (self.CC9 - self.CC8) * min(v / 22.2, 1.0)
            if v >= self.v_desired:
                a = 0.0
        elif self.regime == 'following':
            a = (self._rng.uniform(self.CC4, self.CC5) * self.CC7
                 - self.CC6 * max(dv, 0.0) / gap)
        elif self.regime == 'closing':
            a = max(-0.5 * dv ** 2 / max(gap - d, 0.5), -4.0)
        else:                                # braking
            a = max(min(-2.0 * dv, -0.5), -6.0)

        return DrivingModelOutput(acceleration=float(a))
