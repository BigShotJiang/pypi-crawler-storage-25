# CAVSandbox Quick-Start Guide

## Table of Contents

1.  [What Is CAVSandbox?](#1-what-is-cavsandbox)
2.  [Installation](#2-installation)
3.  [Run Your First Simulation](#3-run-your-first-simulation)
4.  [Look at the Results](#4-look-at-the-results)
5.  [Modify the Scenario](#5-modify-the-scenario)
6.  [Playback a Previous Run](#6-playback-a-previous-run)
7.  [Next Steps](#7-next-steps)
-   [Appendix A — Capabilities and Options at a Glance](#appendix-a--capabilities-and-options-at-a-glance)

***

## 1. What Is CAVSandbox?

CAVSandbox is a Python simulation of longitudinal car-following (vehicles traveling along a roadway in a single lane). It models three types of drivers: human drivers, vehicles equipped with Adaptive Cruise Control (ACC), and vehicles equipped with Cooperative Adaptive Cruise Control (CACC), which use Vehicle-to-Vehicle (V2V) communication to anticipate the leader's actions rather than just reacting to them. The simulation has one built-in model for each driver type, but users can add their own driver models through a plugin system.

The simulation is designed as a teaching and research tool. Students can run pre-built scenarios and observe how platoon behavior changes with different driver models, sensor configurations, and control gains. Researchers can extend the simulation with new driving models or sensor pipelines by dropping a single Python file into the `plugins/` folder — no core code changes required.

***

## 2. Installation

**Prerequisites:** Python 3.11 or later, and `uv` for package management.

If you don't have `uv` installed:

```bash
pip install uv
```

**Clone the repository and install:**

```bash
git clone https://github.com/ViennaMike/cavsandbox.git
cd cavsandbox
uv pip install -e .
```

**Verify the installation:**

```bash
python -m cacc_sim.main --help
```

You should see the command-line usage message. If you see a Python error instead, check that your Python version is 3.11 or later with `python --version`.

***

## 3. Run Your First Simulation

CAVSandbox reads its scenario from an Excel workbook. An example scenario is provided in the `examples/` folder.

**Run the quick-start scenario:**

```bash
python -m cacc_sim.main examples/quickstart.xlsx
```

A Pygame window will open showing a top-down view of the road. You will see:

-   **The road strip** — the lead vehicle is pinned near the right edge of the window and followers appear to its left. Vehicle color indicates driver type: grey for the lead vehicle, cyan for CACC followers. White edge lines mark the top and bottom of the road; alternating red and white roadside posts scroll past outside the edges to convey speed.
-   **The speed chart** — a rolling 30-second speed history for each vehicle, updated in real time. Watch for the speed drop when the lead vehicle decelerates at t = 10 s.
-   **The HUD** — simulation time, playback speed, and lead vehicle speed shown in the top-left corner.

Press **Space** to pause and resume. Press **Q** or **Escape** to quit.

The simulation runs for 50 seconds. When it finishes the window closes automatically and results are written to the `results/` folder.

***

## 4. Look at the Results

After the run, open the /`results/` folder. You will find a subfolder named `quickstart_<timestamp>/` containing:

`data.csv` — the full state log, one row per vehicle per logged timestep. Columns include position, speed, actual acceleration, commanded acceleration, gap to leader, and sensor measurements. This is the primary data file for analysis.

`data.png` — a five-panel composite plot. Each panel answers a specific question:

| Panel                      | File                 | What to look for                                                               |
|----------------------------|----------------------|--------------------------------------------------------------------------------|
| Speed vs. time             | `data_speed.png`     | Do followers track the leader's speed change? How much lag is there?           |
| Gap vs. time               | `data_gap.png`       | Does the headway policy hold? Does the gap recover after the disturbance?      |
| Acceleration vs. time      | `data_accel.png`     | Is the ride comfortable? Are accelerations smooth or jerky?                    |
| Actual vs. commanded accel | `data_lag.png`       | How much does actuator lag soften the commanded acceleration?                  |
| Space-time diagram         | `data_spacetime.png` | Parallel lines mean string-stable following; diverging lines mean instability. |

`metadata.yaml` — records every parameter used in the run, including the random seed, CACC gains, string stability result per vehicle, and the number of logged steps. Essential for reproducibility — if you share a results folder, anyone can reconstruct exactly what was run.

`input.xlsx` — a verbatim copy of the Excel input. The results folder is therefore self-contained: the CSV captures what happened, the Excel captures why.

**Regenerate plots from an existing CSV** (useful if you want to change plot appearance without re-running):

```bash
python -m cacc_sim.plot results/quickstart_<timestamp>/data.csv --show
```

***

## 5. Modify the Scenario

Open `examples/quickstart.xlsx` in Excel. It has three sheets: **vehicles**, **simulation**, and **profile**. Try each of the following changes in turn, re-running the simulation after each one to see the effect.

**Change 1 — Add a fifth vehicle.**

In the `vehicles` sheet, copy the last CACC follower row and paste it as a new row below. Change `vehicle_id` to `5`, set `leader_id` to `4`, and set `initial_position_m` to `0` (25 m behind vehicle 4). Re-run and observe whether the platoon remains string-stable with a longer chain.

**Change 2 — Switch to a ramp deceleration.**

In the `profile` sheet, change the t=10 row: set value to 30.0 and transition to ramp. Then add a new row below it with ti**me**\_s = 40, command = set_speed, value = 25.0, transition = ramp. The lead vehicle will now interpolate smoothly from 30 m/s at t=10 down to 25 ms/ at t=40.

**Change 3 — Enable realistic sensors.**

In the `simulation` sheet, change `sensor_model` from `passthrough` to `kalman`. Re-run and compare the gap tracking panel in the new results to the passthrough run. The radar noise and Kalman filter are now active — the KF-estimated gap will track the true gap with some lag and noise, rather than being identical to it. You can see the differences by looking at the gap, gap_meas, and gap_filtered column in the output data file found at results/quickstart_\<timestamp\>/data.csv

***

## 6. Playback a Previous Run

CAVSandbox can replay any saved run from its CSV without re-simulating:

```bash
python -m cacc_sim.main results/quickstart_<timestamp>/data.csv
```

In playback mode additional controls are available:

| Key              | Action                                         |
|------------------|------------------------------------------------|
| Space            | Pause / resume                                 |
| `→` / `←`        | Step forward / backward one frame while paused |
| `+` / `-`        | Increase / decrease playback speed             |
| `R`              | Rewind to start                                |
| Left-click chart | Seek to that time and pause                    |
| `Q` or `Esc`     | Quit                                           |

Click-to-seek is particularly useful for stepping through a braking event frame by frame.

***

## 7. Next Steps

| **If you want to…**                                                             | **See…**            |
|---------------------------------------------------------------------------------|---------------------|
| Understand all simulation sheet options, vehicle parameters, and output formats | User Guide          |
| Work through pre-built research scenarios with interpretation                   | Worked Examples     |
| Write a new driving model or sensor filter                                      | Plugin Author Guide |
| Understand the architecture before modifying core code                          | CACC Design Notes   |

***

## Appendix A — Capabilities and Options at a Glance

This appendix summarizes the set of features and options available in CAVSandbox. It is not a how-to reference. The User Guide provides full parameter descriptions and the Plugin Author Guide provides instructions for writing extensions.

### Driving Models

| **Model**          | **Type**                              | **Configured by**                                       |
|--------------------|---------------------------------------|---------------------------------------------------------|
| `IDMHumanModel`    | Human driver with reaction time delay | Per-vehicle: desired speed, time headway, reaction time |
| `IDMModel`         | ACC sensor-based (no reaction delay)  | Per-vehicle: desired speed, time headway                |
| `CACCModel`        | Cooperative ACC with V2V feedforward  | System-level gains in simulation sheet                  |
| `Wiedemann99Model` | Psychophysical human driver (plugin)  | Per-vehicle: CC0–CC9 parameters                         |
| `LeadVehicleModel` | Prescribed speed profile              | Profile sheet: time, speed targets, transition type     |

### Sensor and Comms Configurations

| **Configuration**    | `sensor_model`  | `comms_model` | **What it models**                                  |
|----------------------|-----------------|---------------|-----------------------------------------------------|
| Ideal baseline       | `passthrough`   | `passthrough` | Perfect sensing, perfect V2V — no noise             |
| Realistic radar only | `Kalman or lpf` | `passthrough` | Radar noise, delay, and filtering; perfect V2V      |
| Full realistic       | `kalman`        | `dsrc`        | Radar noise + IMU noise + BSM packet drop and delay |

### Vehicle Response Model

| **Mode**        | `response_model` | **Effect**                                                       |
|-----------------|------------------|------------------------------------------------------------------|
| Kinematic       | `kinematic`      | Commanded acceleration applied instantly — for quick prototyping |
| First-order lag | `lag` (default)  | Actuator lag with separate throttle and brake time constants     |

### Fleet Configuration Options

| **Feature**                 | **How**                                                                 |
|-----------------------------|-------------------------------------------------------------------------|
| Homogeneous fleet           | Set response parameters in simulation sheet; omit `vehicle_types` sheet |
| Mixed fleet (cars + trucks) | Add `vehicle_types` sheet; set `vehicle_type` column per vehicle        |
| Per-vehicle overrides       | Set individual parameter columns in vehicles sheet                      |
| Custom driving model        | Drop `.py` file in `plugins/`; reference by class name in Excel         |

### Output Files Produced Per Run

| **File**             | **Contents**                                                    |
|----------------------|-----------------------------------------------------------------|
| `data.csv`           | Full state log at configured rate (default 10 Hz)               |
| `metadata.yaml`      | All run parameters, string stability per vehicle, seed, version |
| `input.xlsx`         | Verbatim copy of input workbook                                 |
| `data.png`           | Five-panel composite plot                                       |
| `data_speed.png`     | Speed vs. time — all vehicles                                   |
| `data_gap.png`       | Gap vs. time — all vehicles                                     |
| `data_accel.png`     | Actual acceleration vs. time — all vehicles                     |
| `data_lag.png`       | Actual vs. commanded acceleration — first follower              |
| `data_spacetime.png` | Space-time diagram — position vs. time                          |
| `results/index.csv`  | One line appended per run — for finding runs across folders     |

### Key Simulation Sheet Parameters

| **Parameter**           | **Default**   | **Effect**                                                                               |
|-------------------------|---------------|------------------------------------------------------------------------------------------|
| `duration_s`            | —             | Total run time in seconds                                                                |
| `playback_speed`        | `1.0`         | `0` = headless batch; `1.0` = real time; `2.0` = 2× speed                                |
| `sensor_model`          | `passthrough` | `passthrough`, `kalman`, or `lpf`                                                        |
| `comms_model`           | `passthrough` | `passthrough` or `dsrc`                                                                  |
| `response_model`        | `lag`         | `lag` or `kinematic`                                                                     |
| `log_rate_hz`           | `10`          | CSV logging rate (simulation always runs at 100 Hz)                                      |
| `cacc_target_headway_s` | `0.6`         | CACC desired time headway (seconds)                                                      |
| `cacc_k_ff`             | `0.90`        | CACC feedforward gain — values below 0.742 produce string instability at default headway |
| `master_seed`           | `0`           | Random seed for reproducible stochastic runs                                             |
