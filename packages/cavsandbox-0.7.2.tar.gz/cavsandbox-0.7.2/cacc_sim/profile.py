"""
Lead vehicle speed profile — reads and interpolates a time-triggered drive cycle.
"""
from __future__ import annotations

import pandas as pd


class LeadVehicleProfile:
    """
    Time-triggered speed profile for the lead vehicle.

    Events are sorted by time_s at construction regardless of sheet row order.
    Before the first event the first value is held; after the last event the
    last value is held.  Between events, 'ramp' transitions linearly; 'step'
    transitions instantly at the earlier event time.

    DataFrame columns
    -----------------
    time_s      : float  — simulation time at which this event takes effect
    value       : float  — target speed (m/s)
    transition  : str    — 'ramp' (default) or 'step'
    note        : str    — optional label, ignored by simulation
    """

    def __init__(self, df: pd.DataFrame):
        self._events = df.sort_values('time_s').reset_index(drop=True)

    def get_speed_target(self, t: float) -> float:
        """
        Return the target speed at simulation time t (m/s).

        Parameters
        ----------
        t : float
            Current simulation time (s).
        """
        events = self._events

        # Hold at first / last value outside the profile range
        if t <= events.iloc[0]['time_s']:
            return float(events.iloc[0]['value'])
        if t >= events.iloc[-1]['time_s']:
            return float(events.iloc[-1]['value'])

        # Find the bracketing pair of events
        idx = int(events['time_s'].searchsorted(t)) - 1
        e0 = events.iloc[idx]
        e1 = events.iloc[idx + 1]

        transition = e0.get('transition', 'ramp')
        if pd.isna(transition):
            transition = 'ramp'

        if str(transition) == 'ramp':
            alpha = (t - e0['time_s']) / (e1['time_s'] - e0['time_s'])
            return float(e0['value'] + alpha * (e1['value'] - e0['value']))

        return float(e0['value'])  # 'step' — hold at e0 value until e1 time
