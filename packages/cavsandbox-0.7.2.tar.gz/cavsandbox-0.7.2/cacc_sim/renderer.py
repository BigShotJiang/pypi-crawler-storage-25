"""
Pygame renderer — RenderFrame dataclass and PygameRenderer.

Both the live SimulationLoop and the CSVPlayback feed RenderFrame objects
to PygameRenderer.draw(); the renderer never knows which source it came from.
"""
from __future__ import annotations

import math
import sys
from dataclasses import dataclass, field
from pathlib import Path

from cacc_sim.palette import DEFAULT_COLOR as _PALETTE_DEFAULT
from cacc_sim.palette import MODEL_COLORS as _PALETTE_COLORS
from cacc_sim.palette import to_rgb255 as _to_rgb255

_MODEL_COLORS_PYGAME: dict[str, tuple[int, int, int]] = {
    name: _to_rgb255(hex_) for name, hex_ in _PALETTE_COLORS.items()
}
_COLOR_DEFAULT_PYGAME: tuple[int, int, int] = _to_rgb255(_PALETTE_DEFAULT)

# ---------------------------------------------------------------------------
# Data types shared by simulation loop and CSV playback
# ---------------------------------------------------------------------------

@dataclass
class VehicleRenderState:
    """Per-vehicle snapshot passed to the renderer each frame."""
    id:           int
    x:            float          # front bumper position (m)
    v:            float          # speed (m/s)
    a:            float          # acceleration (m/s²)
    gap:          float          # bumper-to-bumper gap to leader (m)
    model:        str            # driving model class name
    vehicle_type: str | None     # vehicle type string, or None
    length:       float          # vehicle length (m) — drives rectangle width


@dataclass
class RenderFrame:
    """One complete frame snapshot passed to PygameRenderer.draw()."""
    sim_time: float
    vehicles: list[VehicleRenderState] = field(default_factory=list)
    speed_traces: dict | None = None          # id → iterable of (t, v_mps)
    v_max_display_kmh: float = 0.0            # fixed y-axis ceiling for speed chart
    chart_full_range: tuple | None = None     # (t_min, t_max); if set, shows full trace
    playback_cursor_t: float | None = None    # draws a vertical cursor at this time


# ---------------------------------------------------------------------------
# Renderer
# ---------------------------------------------------------------------------

class PygameRenderer:
    """
    Top-down road-strip renderer using Pygame.

    Draw loop
    ---------
    Caller constructs a RenderFrame and calls draw(frame, paused, speed).
    The renderer fills the window, draws the road and vehicles, overlays
    the HUD, then flips the display.  It never drives the sim or the clock.

    Camera
    ------
    The lead vehicle (LeadVehicleModel, or frontmost if none) is anchored at
    LEAD_ANCHOR_FRAC * WINDOW_W.  px_per_m auto-scales to keep all vehicles
    visible, floored at PX_PER_M_MIN.  Road dashes scroll at the lead vehicle's
    speed to convey absolute motion.

    Event handling
    --------------
    handle_events(paused) processes the pygame event queue and returns
    (paused, running).  The caller decides what to do with those values.
    """

    # ── Colors ────────────────────────────────────────────────────────────
    _COLOR_BG    = (0,   0,   0)    # black background
    _COLOR_ROAD  = (50,  50,  50)   # dark grey road
    _COLOR_LANE  = (80,  80,  80)   # slightly lighter lane markings
    _COLOR_HUD   = (220, 220, 220)  # HUD text
    _COLOR_PAUSED= (255, 80,  80)   # PAUSED indicator

    # Model name → vehicle body color (sourced from palette.py; shared with plot.py)
    _MODEL_COLORS  = _MODEL_COLORS_PYGAME
    _COLOR_DEFAULT = _COLOR_DEFAULT_PYGAME

    # Red reserved for future warning states — not used here.

    # ── Layout (pixels) ───────────────────────────────────────────────────
    WINDOW_W  = 1200
    WINDOW_H  = 640    # 400 road view + 240 speed chart panel
    ROAD_TOP  = 150    # top edge of road strip
    ROAD_H    = 100    # road strip height  → bottom at y=250
    VEH_H     = 50     # vehicle body height (fits inside road with 25 px margins)
    VEH_TOP   = 175    # top of vehicle body (centred on road: 150 + 100/2 - 50/2)
    CAB_RAISE = 12     # px the cab rises above the vehicle body
    CAB_FRAC  = 0.20   # cab length as fraction of vehicle length

    # ── Speed chart panel ─────────────────────────────────────────────────
    CHART_TOP      = 400    # y where chart section begins (= road view height)
    CHART_H        = 240    # chart section height
    CHART_WINDOW_S = 30.0   # rolling window width in seconds
    _CHART_ML      = 50     # left margin (y-axis labels)
    _CHART_MR      = 12     # right margin
    _CHART_MT      = 22     # top margin (title)
    _CHART_MB      = 28     # bottom margin (x-axis labels)
    _COLOR_CHART_BG = (20, 20, 20)

    # ── Scale ─────────────────────────────────────────────────────────────
    PX_PER_M      = 6.0   # default / maximum pixels per metre
    PX_PER_M_MIN  = 2.0   # zoom floor — vehicles never smaller than this scale

    # ── Camera ────────────────────────────────────────────────────────────
    LEAD_ANCHOR_FRAC = 0.82   # lead front bumper at this fraction of window width

    # ── Road markings ─────────────────────────────────────────────────────
    _DASH_LEN   = 20                  # pixels
    _DASH_GAP   = 40                  # pixels (2:1 gap-to-dash)
    _DASH_WIDTH = 4                   # pixels
    _COLOR_DASH = (255, 255, 180)     # warm white road paint
    _COLOR_EDGE = (255, 255, 255)     # solid white edge lines

    # Roadside posts
    _POST_SPACING_M = 50.0            # world spacing (m)
    _POST_W         = 4               # pixels wide
    _POST_H         = 16              # pixels tall
    _POST_MARGIN    = 4               # px gap between edge line and post
    _POST_COLOR_A   = (220,  30,  30) # red
    _POST_COLOR_B   = (255, 255, 255) # white

    # ── Fonts ─────────────────────────────────────────────────────────────
    _ID_FONT_SIZE         = 11
    _HUD_FONT_SIZE        = 16
    _HELP_FONT_SIZE       = 13
    _COLLISION_FONT_SIZE  = 22
    _CHART_FONT_SIZE      = 11

    _COLOR_HELP      = (120, 120, 120)   # dim grey for keyboard hint line
    _COLOR_COLLISION = (220,  40,  40)   # red headline

    _HELP_LIVE     = 'Space: Pause/Resume     Q/Esc: Quit'
    _HELP_PLAYBACK = ('Space: Pause/Resume     \u2190\u2192: Step (paused)'
                      '     +/-: Speed     R: Rewind     Q/Esc: Quit')

    _ASSETS_DIR = Path(__file__).parent / 'assets'

    def __init__(self, title: str = 'CAV Sandbox', playback_mode: bool = False) -> None:
        import pygame
        self._pygame = pygame
        pygame.init()
        self._surface = pygame.display.set_mode((self.WINDOW_W, self.WINDOW_H))
        pygame.display.set_caption(title)
        self._id_font        = pygame.font.SysFont('Arial', self._ID_FONT_SIZE)
        self._hud_font       = pygame.font.SysFont('Arial', self._HUD_FONT_SIZE)
        self._help_font      = pygame.font.SysFont('Arial', self._HELP_FONT_SIZE)
        self._collision_font = pygame.font.SysFont('Arial', self._COLLISION_FONT_SIZE, bold=True)
        self._chart_font     = pygame.font.SysFont('Arial', self._CHART_FONT_SIZE)
        self._help_text = self._HELP_PLAYBACK if playback_mode else self._HELP_LIVE
        self._dash_offset: float = 0.0
        self._last_sim_time: float | None = None
        self._last_chart_t_range: tuple | None = None  # updated each draw; used for click-to-seek
        # Sprites: white-on-transparent PNGs; tinted per model color at draw time.
        self._base_sprites: dict[str, object] = {
            'car':   self._load_sprite('car.png'),
            'truck': self._load_sprite('truck.png'),
        }
        self._tint_cache: dict[tuple, object] = {}  # (key, color) → tinted Surface

    # ── Public interface ───────────────────────────────────────────────────

    def handle_events(self, paused: bool) -> tuple[bool, bool, float | None]:
        """
        Process the pygame event queue.

        Returns
        -------
        (paused, running, seek_time)
            running is False when the user quits.
            seek_time is a simulation time if the user clicked the speed chart,
            otherwise None.  Space toggles pause; Q / Escape quits.
        """
        pg = self._pygame
        seek_time = None
        for event in pg.event.get():
            if event.type == pg.QUIT:
                return paused, False, None
            if event.type == pg.KEYDOWN:
                if event.key == pg.K_SPACE:
                    paused = not paused
                elif event.key in (pg.K_q, pg.K_ESCAPE):
                    return paused, False, None
            if event.type == pg.MOUSEBUTTONDOWN and event.button == 1:
                seek_time = self._chart_click_time(event.pos)
        return paused, True, seek_time

    def _chart_click_time(self, pos: tuple[int, int]) -> float | None:
        """Return simulation time for a click in the chart plot area, or None."""
        if self._last_chart_t_range is None:
            return None
        x, y = pos
        pl = self._CHART_ML
        pr = self.WINDOW_W - self._CHART_MR
        pt = self.CHART_TOP + self._CHART_MT
        pb = self.CHART_TOP + self.CHART_H - self._CHART_MB
        if not (pl <= x <= pr and pt <= y <= pb):
            return None
        t_min, t_max = self._last_chart_t_range
        return t_min + (x - pl) / (pr - pl) * (t_max - t_min)

    def draw(
        self,
        frame: RenderFrame,
        paused: bool = False,
        playback_speed: float = 1.0,
        collision_message: str | None = None,
    ) -> None:
        """
        Render one frame.

        Parameters
        ----------
        frame : RenderFrame
            Vehicle states and simulation time for this frame.
        paused : bool
            If True, draws the PAUSED indicator in the HUD.
        playback_speed : float
            Multiplier shown in the HUD (0 = batch / unlimited).
        collision_message : str or None
            If set, renders a frozen collision overlay with this text.
        """
        self._surface.fill(self._COLOR_BG)

        offset, px_per_m = self._compute_camera(frame.vehicles)
        lead_speed = self._lead_speed(frame.vehicles)

        sim_dt = 0.0
        if self._last_sim_time is not None and not paused:
            sim_dt = frame.sim_time - self._last_sim_time
        self._last_sim_time = frame.sim_time
        self._update_dash_offset(lead_speed, px_per_m, sim_dt)

        self._draw_road(offset, px_per_m)
        for v in frame.vehicles:
            self._draw_vehicle(v, offset, px_per_m)

        self._draw_hud(frame.sim_time, paused, playback_speed, lead_speed)
        self._draw_help()

        if frame.speed_traces and frame.v_max_display_kmh > 0:
            self._draw_speed_chart(frame)

        if collision_message is not None:
            self._draw_collision_overlay(collision_message)

        self._pygame.display.flip()

    def close(self) -> None:
        """Shut down pygame cleanly."""
        self._pygame.quit()

    # ── Camera helpers ─────────────────────────────────────────────────────

    def _compute_camera(
        self, vehicles: list[VehicleRenderState]
    ) -> tuple[float, float]:
        """
        Returns (offset_px, px_per_m).

        Lead front bumper is pinned at LEAD_ANCHOR_FRAC * WINDOW_W.
        px_per_m shrinks as the platoon spreads, floored at PX_PER_M_MIN.
        """
        if not vehicles:
            return 0.0, self.PX_PER_M

        lead = max(vehicles, key=lambda v: v.x)
        rear = min(vehicles, key=lambda v: v.x - v.length)

        anchor_px = self.LEAD_ANCHOR_FRAC * self.WINDOW_W

        # Span from rearmost rear bumper to lead front bumper, padded 10% + 5 m
        span = lead.x - (rear.x - rear.length)
        span_padded = span * 1.1 + 5.0

        required = anchor_px / max(span_padded, 1.0)
        px_per_m = max(self.PX_PER_M_MIN, min(self.PX_PER_M, required))

        offset = anchor_px - lead.x * px_per_m
        return offset, px_per_m

    def _lead_speed(self, vehicles: list[VehicleRenderState]) -> float:
        """Speed of the lead vehicle (LeadVehicleModel, or frontmost fallback)."""
        for v in vehicles:
            if v.model == 'LeadVehicleModel':
                return v.v
        if vehicles:
            return max(vehicles, key=lambda v: v.x).v
        return 0.0

    def _update_dash_offset(
        self, lead_speed: float, px_per_m: float, sim_dt: float
    ) -> None:
        period = self._DASH_LEN + self._DASH_GAP
        self._dash_offset = (
            self._dash_offset - lead_speed * px_per_m * sim_dt
        ) % period

    # ── Drawing helpers ────────────────────────────────────────────────────

    def _draw_road(self, offset: float, px_per_m: float) -> None:
        pg   = self._pygame
        surf = self._surface

        # Road surface
        pg.draw.rect(surf, self._COLOR_ROAD,
                     (0, self.ROAD_TOP, self.WINDOW_W, self.ROAD_H))

        # Centre-line dashes (scrolling)
        centre_y = self.ROAD_TOP + self.ROAD_H // 2
        period   = self._DASH_LEN + self._DASH_GAP
        x = self._dash_offset - period
        while x < self.WINDOW_W:
            x1 = int(x)
            x2 = int(x + self._DASH_LEN)
            if x2 > 0:
                pg.draw.line(surf, self._COLOR_DASH,
                             (max(0, x1), centre_y),
                             (min(x2, self.WINDOW_W), centre_y), self._DASH_WIDTH)
            x += period

        # Solid white edge lines (static)
        road_bottom = self.ROAD_TOP + self.ROAD_H
        pg.draw.line(surf, self._COLOR_EDGE,
                     (0, self.ROAD_TOP), (self.WINDOW_W, self.ROAD_TOP), 2)
        pg.draw.line(surf, self._COLOR_EDGE,
                     (0, road_bottom), (self.WINDOW_W, road_bottom), 2)

        # Scrolling roadside posts (world-coordinate colour keying — no flicker)
        spacing_m  = self._POST_SPACING_M
        spacing_px = spacing_m * px_per_m
        # First post index: one spacing_px before the left screen edge
        first_idx = math.floor((-spacing_px - offset) / spacing_px)
        n   = first_idx
        x_p = n * spacing_px + offset
        top_post_y = self.ROAD_TOP - self._POST_MARGIN - self._POST_H
        bot_post_y = road_bottom + self._POST_MARGIN
        while x_p < self.WINDOW_W + spacing_px:
            color = self._POST_COLOR_A if n % 2 == 0 else self._POST_COLOR_B
            cx = int(x_p) - self._POST_W // 2
            pg.draw.rect(surf, color, (cx, top_post_y, self._POST_W, self._POST_H))
            pg.draw.rect(surf, color, (cx, bot_post_y, self._POST_W, self._POST_H))
            n   += 1
            x_p += spacing_px

    def _draw_vehicle(
        self, v: VehicleRenderState, offset: float, px_per_m: float
    ) -> None:
        pg    = self._pygame
        surf  = self._surface
        color = self._MODEL_COLORS.get(v.model, self._COLOR_DEFAULT)

        body_left = int((v.x - v.length) * px_per_m + offset)
        body_w    = max(int(v.length * px_per_m), 4)
        body_rect = pg.Rect(body_left, self.VEH_TOP, body_w, self.VEH_H)

        sprite = self._get_sprite(v, body_w, color)
        if sprite is not None:
            surf.blit(sprite, body_rect.topleft)
        else:
            # Fallback rectangles when sprites are not available.
            pg.draw.rect(surf, color, body_rect)
            pg.draw.rect(surf, (0, 0, 0), body_rect, 1)
            is_truck = (
                v.vehicle_type is not None and
                'truck' in v.vehicle_type.lower()
            )
            if is_truck:
                cab_w    = max(int(body_w * self.CAB_FRAC), 4)
                cab_left = body_left + body_w - cab_w
                cab_top  = self.VEH_TOP - self.CAB_RAISE
                cab_rect = pg.Rect(cab_left, cab_top, cab_w, self.VEH_H + self.CAB_RAISE)
                pg.draw.rect(surf, color, cab_rect)
                pg.draw.rect(surf, (0, 0, 0), cab_rect, 1)

        label = self._id_font.render(str(v.id), True, (0, 0, 0))
        lx = body_rect.centerx - label.get_width() // 2
        ly = body_rect.centery - label.get_height() // 2
        surf.blit(label, (lx, ly))

    def _load_sprite(self, filename: str) -> object:
        """Load a PNG sprite; returns None if the file is missing."""
        path = self._ASSETS_DIR / filename
        try:
            return self._pygame.image.load(str(path)).convert_alpha()
        except Exception:
            return None

    def _get_sprite(
        self, v: VehicleRenderState, body_w: int, color: tuple
    ) -> object:
        """
        Return a tinted, scaled Surface for this vehicle.

        Tinted surfaces are cached by (sprite_key, color) so the multiply
        blend only runs once per model type.  Scaling to body_w is done
        per-call (cheap) from the cached tinted surface.
        """
        is_truck = (
            v.vehicle_type is not None and
            'truck' in v.vehicle_type.lower()
        )
        key  = 'truck' if is_truck else 'car'
        base = self._base_sprites.get(key)
        if base is None:
            return None

        cache_key = (key, color)
        if cache_key not in self._tint_cache:
            tinted = base.copy()
            # BLEND_RGB_MULT: white → color, black → black, alpha preserved.
            tinted.fill(color, special_flags=self._pygame.BLEND_RGB_MULT)
            self._tint_cache[cache_key] = tinted

        tinted = self._tint_cache[cache_key]
        return self._pygame.transform.scale(tinted, (body_w, self.VEH_H))

    def _draw_hud(
        self,
        sim_time: float,
        paused: bool,
        playback_speed: float,
        lead_speed: float,
    ) -> None:
        pg   = self._pygame
        surf = self._surface

        t_surf = self._hud_font.render(
            f't = {_format_time(sim_time)}', True, self._COLOR_HUD)
        surf.blit(t_surf, (10, 10))

        if playback_speed == 0:
            spd_str = 'BATCH'
        else:
            spd_str = f'{playback_speed:.2g}\u00d7'
        spd_surf = self._hud_font.render(spd_str, True, self._COLOR_HUD)
        surf.blit(spd_surf, (10, 32))

        lead_surf = self._hud_font.render(
            f'Lead: {lead_speed * 3.6:.1f} km/h', True, self._COLOR_HUD)
        surf.blit(lead_surf, (10, 54))

        if paused:
            p_surf = self._hud_font.render('PAUSED', True, self._COLOR_PAUSED)
            surf.blit(p_surf, (10, 76))

    def _draw_speed_chart(self, frame: RenderFrame) -> None:
        pg   = self._pygame
        surf = self._surface

        v_max    = frame.v_max_display_kmh
        sim_time = frame.sim_time
        traces   = frame.speed_traces

        # Plot area boundaries
        pl = self._CHART_ML
        pr = self.WINDOW_W - self._CHART_MR
        pt = self.CHART_TOP + self._CHART_MT
        pb = self.CHART_TOP + self.CHART_H - self._CHART_MB
        pw = pr - pl
        ph = pb - pt

        # Background and border
        pg.draw.rect(surf, self._COLOR_CHART_BG,
                     (0, self.CHART_TOP, self.WINDOW_W, self.CHART_H))
        pg.draw.rect(surf, self._COLOR_LANE, (pl, pt, pw, ph), 1)

        # Title
        title = self._chart_font.render('Platoon Speeds (km/h)', True, self._COLOR_HUD)
        surf.blit(title, ((self.WINDOW_W - title.get_width()) // 2,
                          self.CHART_TOP + 4))

        # Time window: full trace (playback) or rolling window (live)
        if frame.chart_full_range is not None:
            t_min, t_max = frame.chart_full_range
            window_s = max(t_max - t_min, 1.0)
        else:
            t_min = max(0.0, sim_time - self.CHART_WINDOW_S)
            t_max = t_min + self.CHART_WINDOW_S
            window_s = self.CHART_WINDOW_S
        self._last_chart_t_range = (t_min, t_max)

        # Y-axis ticks and labels
        tick_y = 10 if v_max <= 80 else 20
        y_val = 0
        while y_val <= v_max + 0.01:
            py = int(pb - (y_val / v_max) * ph)
            pg.draw.line(surf, self._COLOR_LANE, (pl - 4, py), (pl, py))
            lbl = self._chart_font.render(str(int(y_val)), True, self._COLOR_HELP)
            surf.blit(lbl, (pl - 6 - lbl.get_width(), py - lbl.get_height() // 2))
            y_val += tick_y

        # X-axis ticks and labels — interval auto-scaled to window width
        tick_x = _nice_x_tick(window_s)
        t_tick = math.ceil(t_min / tick_x) * tick_x
        while t_tick <= t_max + 0.01:
            px = int(pl + (t_tick - t_min) / window_s * pw)
            if pl <= px <= pr:
                pg.draw.line(surf, self._COLOR_LANE, (px, pb), (px, pb + 4))
                lbl = self._chart_font.render(f'{int(t_tick)}', True, self._COLOR_HELP)
                surf.blit(lbl, (px - lbl.get_width() // 2, pb + 6))
            t_tick += tick_x

        # Speed lines — one per vehicle
        id_to_model = {v.id: v.model for v in frame.vehicles}
        for vid, buf in traces.items():
            if len(buf) < 2:
                continue
            model = id_to_model.get(vid, '')
            color = self._MODEL_COLORS.get(model, self._COLOR_DEFAULT)

            points = []
            for t_pt, v_mps in buf:
                if t_pt < t_min:
                    continue
                v_kmh = v_mps * 3.6
                px = int(pl + (t_pt - t_min) / window_s * pw)
                py = int(pb - (v_kmh / v_max) * ph)
                py = max(pt, min(pb, py))
                points.append((px, py))

            if len(points) >= 2:
                pg.draw.lines(surf, color, False, points, 2)

        # Playback cursor — vertical white line at current position
        if frame.playback_cursor_t is not None:
            ct = frame.playback_cursor_t
            if t_min <= ct <= t_max:
                cx = int(pl + (ct - t_min) / window_s * pw)
                pg.draw.line(surf, (255, 255, 255), (cx, pt), (cx, pb), 1)

    def _draw_collision_overlay(self, message: str) -> None:
        pg   = self._pygame
        surf = self._surface

        lines = message.split('\n') + ['Press Q or Esc to quit']

        line_h   = self._collision_font.get_height() + 6
        box_w    = 420
        box_h    = len(lines) * line_h + 28
        box_x    = (self.WINDOW_W - box_w) // 2
        box_y    = (self.WINDOW_H - box_h) // 2

        # Semi-transparent dark background
        overlay = pg.Surface((box_w, box_h), pg.SRCALPHA)
        overlay.fill((20, 20, 20, 200))
        surf.blit(overlay, (box_x, box_y))
        pg.draw.rect(surf, self._COLOR_COLLISION, (box_x, box_y, box_w, box_h), 2)

        for i, line in enumerate(lines):
            if i == 0:
                color = self._COLOR_COLLISION
            elif i == len(lines) - 1:
                color = self._COLOR_HELP
            else:
                color = self._COLOR_HUD
            text_surf = self._collision_font.render(line, True, color)
            tx = box_x + (box_w - text_surf.get_width()) // 2
            ty = box_y + 14 + i * line_h
            surf.blit(text_surf, (tx, ty))

    def _draw_help(self) -> None:
        surf = self._pygame.display.get_surface()
        h_surf = self._help_font.render(self._help_text, True, self._COLOR_HELP)
        # Anchor just above the chart panel so it stays within the road view.
        y = self.CHART_TOP - h_surf.get_height() - 6
        self._surface.blit(h_surf, (10, y))


# ---------------------------------------------------------------------------
# Utility
# ---------------------------------------------------------------------------

def _nice_x_tick(range_s: float) -> float:
    """Pick a round x-axis tick interval targeting ~5–7 ticks."""
    for step in (1, 2, 5, 10, 15, 30, 60, 120, 300, 600):
        if range_s / step <= 7:
            return float(step)
    return 600.0


def _format_time(t: float) -> str:
    """Format simulation time as  mm:ss.t  (e.g. '01:23.4')."""
    total_ds = int(t * 10)   # deciseconds
    ds  =  total_ds % 10
    sec = (total_ds //  10) % 60
    mn  = (total_ds // 600)
    return f'{mn:02d}:{sec:02d}.{ds}'
