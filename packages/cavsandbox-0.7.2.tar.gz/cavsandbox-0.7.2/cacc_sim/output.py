"""
Run output: CSV state log, YAML metadata, and Excel input copy.
"""
from __future__ import annotations

import datetime
import shutil
from pathlib import Path

import pandas as pd
import yaml

from cacc_sim.loader import SimConfig
from cacc_sim.vehicle import Vehicle

_VERSION = '0.1.0'


def save_run(
    df: pd.DataFrame,
    excel_path: str,
    vehicles: list[Vehicle],
    config: SimConfig,
    timestamp: str | None = None,
) -> Path:
    """
    Write run artifacts into a per-run subfolder under results/.

    Creates results/<scenario>_<timestamp>/ containing:
      - data.csv       full state log
      - metadata.yaml  timestamp, version, string stability, resolved params
      - input.xlsx     verbatim copy of input Excel for reproducibility
      - *.png          composite and individual panel plots

    Also appends one line to results/index.csv for quick cross-run lookup.

    Parameters
    ----------
    df : pd.DataFrame
        Output of SimulationLoop.run() or run_live().
    excel_path : str
        Path to the input Excel file.
    vehicles : list[Vehicle]
        Loaded vehicle list (used for metadata extraction only).
    config : SimConfig
        Simulation configuration.
    timestamp : str or None
        Timestamp string (yyyymmdd_HHMMSS).  If None, uses current wall time.

    Returns
    -------
    Path
        The per-run directory that was created.
    """
    src = Path(excel_path).resolve()
    if timestamp is None:
        timestamp = datetime.datetime.now().strftime('%Y%m%d_%H%M%S')

    run_name = f'{src.stem}_{timestamp}'
    results_dir = Path(__file__).parent.parent / 'results'
    results_dir.mkdir(exist_ok=True)
    run_dir = results_dir / run_name
    run_dir.mkdir(exist_ok=True)

    csv_path = run_dir / 'data.csv'
    df.to_csv(csv_path, index=False)
    shutil.copy2(str(src), run_dir / 'input.xlsx')

    meta = _build_metadata(df, vehicles, config, timestamp, src.name, run_name)
    with open(run_dir / 'metadata.yaml', 'w', encoding='utf-8') as fh:
        yaml.dump(meta, fh, default_flow_style=False, sort_keys=False)

    from cacc_sim.plot import plot_run
    plot_run(str(csv_path))

    _append_index(results_dir, run_name, src.stem, timestamp, config, len(vehicles))

    return run_dir


def _append_index(
    results_dir: Path,
    run_name: str,
    scenario: str,
    timestamp: str,
    config: SimConfig,
    n_vehicles: int,
) -> None:
    index_path = results_dir / 'index.csv'
    write_header = not index_path.exists()
    ts_fmt = datetime.datetime.strptime(timestamp, '%Y%m%d_%H%M%S').strftime('%Y-%m-%d %H:%M:%S')
    with open(index_path, 'a', newline='', encoding='utf-8') as fh:
        if write_header:
            fh.write('run_folder,scenario,timestamp,seed,duration_s,n_vehicles,cacc_k_ff\n')
        fh.write(
            f'{run_name},{scenario},{ts_fmt},{config.master_seed},'
            f'{config.duration_s},{n_vehicles},{config.cacc_k_ff}\n'
        )


def _build_metadata(
    df: pd.DataFrame,
    vehicles: list[Vehicle],
    config: SimConfig,
    timestamp: str,
    excel_name: str,
    run_name: str,
) -> dict:
    from cacc_sim.driving_models import CACCModel

    string_stability: dict[int, bool] = {
        v.id: v.model.controller.string_stable
        for v in vehicles
        if isinstance(v.model, CACCModel)
    }

    response_params: dict[int, dict] = {
        v.id: {
            'mode':           v.response.mode,
            'tau_throttle_s': v.response.tau_throttle,
            'tau_brake_s':    v.response.tau_brake,
            'a_max_mps2':     v.response.a_max,
            'a_min_mps2':     v.response.a_min,
            'j_max_mps3':     v.response.j_max,
        }
        for v in vehicles
    }

    n_steps = len(df) // len(vehicles) if vehicles else 0

    # Record sensor configuration and RNG seeds for reproducibility
    sensor_info: dict = {'sensor_model': config.sensor_model,
                         'comms_model':  config.comms_model,
                         'master_seed':  config.master_seed}
    if config.sensor_model != 'passthrough':
        from cacc_sim.rng import vehicle_rng
        procs = ['sensor_noise', 'ego_noise']
        if config.comms_model == 'dsrc':
            procs += ['bsm_comms', 'bsm_phase']
        sensor_info['derived_seeds'] = {
            f'v{v.id}_{proc}': vehicle_rng(config.master_seed, v.id, proc).getstate()[1][0]
            for v in vehicles
            for proc in procs
        }
        if config.comms_model == 'dsrc':
            from cacc_sim.sensors import DSRCBSMTracker
            sensor_info['bsm_phase_offsets'] = {
                v.id: v.bsm_tracker.phase_offset_steps
                for v in vehicles
                if isinstance(v.bsm_tracker, DSRCBSMTracker)
            }

    return {
        'run_name':         run_name,
        'timestamp':        timestamp,
        'version':          _VERSION,
        'excel_input':      excel_name,
        'duration_s':       config.duration_s,
        'timestep_s':       config.timestep_s,
        'log_rate_hz':      config.log_rate_hz,
        'n_vehicles':       len(vehicles),
        'n_steps':          n_steps,
        'response_model':   config.response_model,
        'sensor':           sensor_info,
        'string_stability': string_stability,
        'response_params':  response_params,
    }
