"""
Vehicle class — wires model, response, plant, filter, and sensor pipeline.
"""
from __future__ import annotations

from cacc_sim.core import DrivingModel, Filter, VehicleState
from cacc_sim.plant import VehiclePlant, VehicleResponseModel


class Vehicle:
    """
    One simulated vehicle.

    Holds the strategy objects (model, response, plant, filter, sensors) and
    exposes a single step() method that the SimulationLoop calls each timestep.

    Sensor pipeline
    ---------------
    When sensor_model == 'passthrough' (default), the sensing layer is bypassed
    entirely inside step(): true plant values are assigned directly.  No sensor
    objects need to be instantiated for this path.

    When sensor_model is 'kalman' or 'lpf', the full pipeline runs:
      ego_sensor → radar → fusion → VehicleState

    Parameters
    ----------
    id : int
        Unique vehicle identifier matching the vehicles sheet.
    model : DrivingModel
        The longitudinal control algorithm.
    response : VehicleResponseModel
        Actuator lag model between commanded and actual acceleration.
    plant : VehiclePlant
        Kinematic integrator (position, speed).
    filter_ : Filter
        Sensor data filter (passthrough initially).
    leader_id : int or None
        vehicle_id of the immediately preceding vehicle; None for the lead vehicle.
    vehicle_type : str or None
        Optional vehicle type string from the vehicles sheet.
    sensor_model : str
        'passthrough' (default), 'kalman', or 'lpf'.
    ego_sensor : BaseEgoSensor or None
        Ego speed/accel sensor; None when sensor_model == 'passthrough'.
    radar : BaseSensor or None
        Gap/range-rate radar sensor; None when sensor_model == 'passthrough'.
    bsm_tracker : BaseBSMTracker or None
        V2V BSM receiver; None when sensor_model == 'passthrough'.
    fusion : BaseFusionEstimator or None
        Sensor fusion layer; None when sensor_model == 'passthrough'.
    """

    def __init__(
        self,
        id: int,
        model: DrivingModel,
        response: VehicleResponseModel,
        plant: VehiclePlant,
        filter_: Filter,
        leader_id: int | None = None,
        vehicle_type: str | None = None,
        sensor_model: str = 'passthrough',
        ego_sensor=None,
        radar=None,
        bsm_tracker=None,
        fusion=None,
    ):
        self.id            = id
        self.model         = model
        self.response      = response
        self.plant         = plant
        self.filter_       = filter_
        self.leader_id     = leader_id
        self.vehicle_type  = vehicle_type
        self.sensor_model  = sensor_model
        self.ego_sensor    = ego_sensor
        self.radar         = radar
        self.bsm_tracker   = bsm_tracker
        self.fusion        = fusion
        # Ego-measured acceleration from the last step; exposed so that
        # downstream BSM trackers on following vehicles can use it.
        self._last_a_meas: float = 0.0
        # Resolved by load_vehicles() after all vehicles are constructed.
        # Plugin models can read state.leader_speed / state.leader_acceleration.
        self.platoon_leader: Vehicle | None = None

    def step(self, t: float, leader: Vehicle | None) -> dict:
        """
        Advance this vehicle by one timestep.

        Parameters
        ----------
        t : float
            Current simulation time (s).
        leader : Vehicle or None
            The immediately preceding vehicle; None if this is the lead vehicle.

        Returns
        -------
        dict
            State record for logging.
        """
        # True plant quantities (always computed for logging and collision detection)
        if leader is not None:
            true_gap      = self.plant.gap_to(leader.plant)
            true_gap_rate = leader.plant.v - self.plant.v
        else:
            true_gap      = 9999.0
            true_gap_rate = 0.0

        # ── Sensor pipeline ───────────────────────────────────────────────────
        if self.sensor_model == 'passthrough':
            # Bypass all sensing — assign true values directly.
            # No sensor objects instantiated or called.
            v_meas        = self.plant.v
            a_meas        = self.plant.a
            gap_meas      = true_gap
            gap_filtered  = true_gap
            lead_v_meas   = leader.plant.v if leader is not None else self.plant.v
            lead_a_v2v    = leader.plant.a if leader is not None else 0.0
            lead_a_radar  = 0.0
            bsm_age_s     = 0.0
        else:
            # Full pipeline: ego sensor → radar → BSM → fusion
            v_meas, a_meas = self.ego_sensor.step(self.plant.v, self.plant.a)

            if leader is not None:
                # BSM uses the leader's ego-measured accel (not ground truth).
                self.bsm_tracker.update(leader._last_a_meas)
                lead_a_v2v = self.bsm_tracker.acceleration
                bsm_age_s  = self.bsm_tracker.age_s

                gap_meas, _, gap_filtered, rate_filtered = self.radar.step(
                    true_gap, true_gap_rate
                )
                gap_fused, rate_fused, lead_a_radar = self.fusion.step(
                    gap_filtered, rate_filtered, lead_a_v2v, bsm_age_s, a_meas
                )
                gap_filtered = gap_fused
                lead_v_meas  = v_meas + rate_fused
            else:
                lead_a_v2v   = 0.0
                lead_a_radar = 0.0
                bsm_age_s    = 0.0
                gap_meas     = 9999.0
                gap_filtered = 9999.0
                lead_v_meas  = v_meas

        # Store ego-measured accel so downstream BSM trackers can read it.
        self._last_a_meas = a_meas

        # ── Build VehicleState for the driving model ──────────────────────────
        pl = self.platoon_leader
        state = VehicleState(
            speed                = v_meas,
            acceleration         = a_meas,
            time                 = t,
            position             = self.plant.x,
            gap                  = gap_filtered,
            lead_speed           = lead_v_meas,
            lead_a_radar         = lead_a_radar,
            lead_a_v2v           = lead_a_v2v,
            leader_speed         = pl.plant.v        if pl is not None else None,
            leader_acceleration  = pl._last_a_meas   if pl is not None else None,
        )

        a_cmd    = self.model.compute(state).acceleration
        a_actual = self.response.step(a_cmd, self.plant.v)
        self.plant.step(a_actual)

        return {
            't':            t,
            'id':           self.id,
            'x':            self.plant.x,
            'v':            self.plant.v,
            'a':            self.plant.a,
            'a_cmd':        a_cmd,
            'gap':          true_gap,       # true bumper-to-bumper gap (collision detection)
            'gap_meas':     gap_meas,       # radar measurement before filter
            'gap_filtered': gap_filtered,   # fused estimate (what controller saw)
            'lead_v_meas':  lead_v_meas,
            'lead_a_v2v':   lead_a_v2v,     # BSM feedforward (0.0 when stale/dropped)
            'lead_a_radar': lead_a_radar,   # fusion KF estimate (0.0 in passthrough)
            'bsm_age_s':    bsm_age_s,      # seconds since last BSM packet (0.0 in passthrough)
            'leader_id':    self.leader_id,
            'model':        type(self.model).__name__,
            'vehicle_type': self.vehicle_type,
            'length':       self.plant.length,
        }
