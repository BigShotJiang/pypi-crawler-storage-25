# -*- coding: utf-8 -*-
__version__ = '1.3'
from .mysqlclass import grsegrsezgrgtrdrgregrsgrgssrgrdfrsgregsregre
mysql=grsegrsezgrgtrdrgregrsgrgssrgrdfrsgregsregre()