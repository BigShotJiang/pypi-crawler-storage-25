"""HTTP Basic Authentication testing CLI."""

__version__ = "0.1.0"
