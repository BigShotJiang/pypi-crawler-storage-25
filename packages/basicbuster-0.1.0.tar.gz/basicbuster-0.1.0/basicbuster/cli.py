from __future__ import annotations

import argparse
import sys

from basicbuster import __version__
from basicbuster.core import DEFAULT_TIMEOUT, run_attack


def build_parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(
        prog="basicbuster",
        description="HTTP Basic Authentication wordlist testing (authorized use only).",
    )
    p.add_argument("--version", action="version", version=f"%(prog)s {__version__}")
    p.add_argument("--url", required=True, help="Target URL protected by HTTP Basic Auth.")
    p.add_argument(
        "--username",
        metavar="FILE",
        help="Path to username wordlist (one per line).",
    )
    p.add_argument(
        "--password",
        metavar="FILE",
        help="Path to password wordlist (one per line).",
    )
    p.add_argument(
        "--userpass",
        metavar="FILE",
        help="Combined file: user:pass per line.",
    )
    p.add_argument(
        "--mode",
        choices=("pitchfork", "clusterbomb"),
        default="clusterbomb",
        help="pitchfork: zip usernames with passwords; clusterbomb: all pairs (default).",
    )
    p.add_argument(
        "--timeout",
        type=float,
        default=DEFAULT_TIMEOUT,
        help=f"Per-request timeout in seconds (default: {DEFAULT_TIMEOUT}).",
    )
    p.add_argument(
        "--proxy",
        metavar="URL",
        help="HTTP(S) proxy for all requests (e.g. http://127.0.0.1:8080).",
    )
    p.add_argument(
        "--quiet",
        action="store_true",
        help="Less verbose output (no probe line, no summary).",
    )
    return p


def main() -> None:
    parser = build_parser()
    args = parser.parse_args()
    try:
        code = run_attack(args)
    except KeyboardInterrupt:
        print("\n[!] Interrupted.", file=sys.stderr)
        code = 130
    sys.exit(code)


if __name__ == "__main__":
    main()
