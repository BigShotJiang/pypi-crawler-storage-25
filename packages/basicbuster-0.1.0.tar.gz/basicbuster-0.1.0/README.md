# basicbuster

**basicbuster** is a command-line tool for testing HTTP Basic Authentication with username and password wordlists. It can detect Basic Auth on a target URL, run pitchfork or clusterbomb-style attempts, and report credentials that return HTTP `200`.

## Disclaimer

Use **only** on systems and applications you are **explicitly authorized** to test. Unauthorized access to computer systems is illegal. The authors are not responsible for misuse.

## Requirements

- Python 3.10+

## Installation

After the package is [published on PyPI](https://pypi.org/project/basicbuster/), install from any machine:

```bash
pip install basicbuster
```

From a git checkout (repository root):

```bash
pip install .
```

Editable install while developing:

```bash
pip install -e .
```

### Publishing to PyPI (maintainers)

The name **basicbuster** is available on PyPI. Two common options:

**A — GitHub Release (recommended)**  
After you [enable trusted publishing](https://docs.pypi.org/trusted-publishers/) for this repo on PyPI:

1. In PyPI: your account → **Publishing** → add a pending publisher for `dhina016/basicbuster`, workflow file `publish.yml`.
2. On GitHub: create a **Release** (tag `v0.1.0` or similar) and publish it. The **Publish to PyPI** workflow uploads the built sdist and wheel automatically.

**B — Manual upload**

```bash
pip install build twine
python -m build
twine upload dist/*
```

Use a [PyPI API token](https://pypi.org/help/#apitoken) when `twine` prompts for credentials (or set `TWINE_USERNAME=__token__` and `TWINE_PASSWORD=pypi-...`).

## Usage

```text
basicbuster --url URL (--username FILE --password FILE | --userpass FILE) [--mode MODE] [--timeout SECONDS] [--proxy URL]
```

- **`--url`**: Target URL (resource protected by HTTP Basic Auth).
- **`--username` / `--password`**: Separate wordlists, one value per line.
- **`--userpass`**: Combined file with `user:pass` per line (password may contain `:`; only the first `:` separates user and password).
- **`--mode`**:
  - `pitchfork` — pair `username[i]` with `password[i]`.
  - `clusterbomb` — try every username with every password (default).
- **`--timeout`**: Request timeout in seconds (default: `15`).
- **`--quiet`**: Minimal output.
- **`--proxy`**: Forward all traffic through an HTTP(S) proxy (e.g. Burp: `http://127.0.0.1:8080`).

Successful guesses print as:

```text
[+] SUCCESS user:pass (HTTP 200)
```

### Examples

Separate wordlists, clusterbomb (default):

```bash
basicbuster --url https://example.com/secret --username users.txt --password passwords.txt
```

Pitchfork (zip by line index):

```bash
basicbuster --url https://example.com/secret --username users.txt --password passwords.txt --mode pitchfork
```

Combined user:pass file:

```bash
basicbuster --url https://example.com/secret --userpass combo.txt
```

Through a local intercepting proxy:

```bash
basicbuster --url https://example.com/secret --userpass combo.txt --proxy http://127.0.0.1:8080
```

## License

MIT — see [LICENSE](LICENSE).
