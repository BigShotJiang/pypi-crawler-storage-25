"""A collection of helper functions for time conversion and formatting."""

from __future__ import annotations

from collections.abc import Callable  # noqa: TC003
from inspect import BoundArguments, Signature, signature
from typing import TYPE_CHECKING, ParamSpec, TypeVar

if TYPE_CHECKING:
    from bear_epoch_time import EpochTimestamp
    from bear_epoch_time.tz import TimeZoneType

ORD_DAY = "%Do"


def add_ord_suffix(number: int) -> str:
    """Add an ordinal suffix to a given number, usually used for dates or rankings.

    Parameters:
    number: int - The number to add an ordinal suffix to.

    Returns:
    str - The number with its ordinal suffix.
    """
    eleventh = 11
    thirteenth = 13
    suffix: str = ["th", "st", "nd", "rd", "th"][min(number % 10, 4)]
    if eleventh <= (number % 100) <= thirteenth:
        suffix = "th"
    return f"{number}{suffix}"


def format_interception(fmt: str, bound_args: BoundArguments) -> str:
    """Intercept and modify certain format strings before they are processed.

    Args:
        fmt (str): The original format string.
        bound_args (BoundArguments): The bound arguments from the calling function.

    Returns:
        str: The modified format string with ordinal day suffixes if applicable.
    """
    if ORD_DAY in fmt:
        self: EpochTimestamp | None = bound_args.arguments.get("self")
        if self is not None:
            tz: TimeZoneType = bound_args.arguments.get("tz") or self._tz
            day_in_tz: int = self.to_datetime.astimezone(tz).day
            return fmt.replace(ORD_DAY, f"{add_ord_suffix(day_in_tz)}")
    return fmt


T = TypeVar("T")
P = ParamSpec("P")


def fmt_parse(func: Callable[P, T]) -> Callable[P, T]:  # noqa: UP047
    """A decorator to intercept and modify format strings before passing them to the decorated function."""

    def wrapper(*args: P.args, **kwargs: P.kwargs) -> T:
        sig: Signature = signature(func)
        bound_args: BoundArguments = sig.bind(*args, **kwargs)
        bound_args.apply_defaults()
        fmt: str = bound_args.arguments.get("fmt", "")
        modified_fmt: str = format_interception(fmt, bound_args) if fmt else fmt  # Pass bound_args!
        bound_args.arguments["fmt"] = modified_fmt
        return func(*bound_args.args, **bound_args.kwargs)

    return wrapper
