"""HBIA standardized API response format.

All HBIA endpoints return this envelope so the frontend service
layer can parse responses uniformly.  The format is:

    {"ok": true,  "data": ..., "meta": ...}           # success
    {"ok": false, "error": {"code": "...", "message": "..."}}  # error

Usage in custom endpoints::

    from honey_badgeria.integrations.fastapi.response import (
        hbia_success, hbia_error, hbia_paginated,
    )

    @app.get("/items")
    async def list_items():
        items = get_all_items()
        return hbia_paginated(items, total=100, page=1, page_size=20)
"""

from __future__ import annotations

from typing import Any


def hbia_success(data: Any = None, meta: dict[str, Any] | None = None) -> dict[str, Any]:
    """Build a success response."""
    resp: dict[str, Any] = {"ok": True, "data": data}
    if meta is not None:
        resp["meta"] = meta
    return resp


def hbia_error(
    code: str,
    message: str,
    status_code: int = 400,
) -> dict[str, Any]:
    """Build an error response.

    Note: ``status_code`` is informational for the caller — it is NOT
    embedded in the response body.  The caller should set the HTTP
    status code on the FastAPI response.
    """
    return {
        "ok": False,
        "error": {"code": code, "message": message},
    }


def hbia_paginated(
    items: list[Any],
    total: int,
    page: int = 1,
    page_size: int = 20,
) -> dict[str, Any]:
    """Build a paginated success response."""
    pages = max(1, -(-total // page_size))  # ceil division
    return hbia_success(
        data=items,
        meta={
            "total": total,
            "page": page,
            "page_size": page_size,
            "pages": pages,
        },
    )
