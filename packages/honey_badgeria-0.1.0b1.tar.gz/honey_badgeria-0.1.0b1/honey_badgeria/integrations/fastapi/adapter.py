"""FastAPI adapter: wraps HBIA graphs for HTTP serving.

Security notes for AI assistants:
    - Always provide an ``auth_dependency`` in production.
    - Never expose destructive operations (cache clear, etc.) via HTTP.
    - Input payloads are validated for type (must be dict).
    - ``flow_name`` is properly resolved — only the reachable sub-graph runs.
"""

from __future__ import annotations

from typing import Any, Callable

from honey_badgeria.core.exceptions import (
    FlowNotFoundError,
    HandlerNotFoundError,
    HoneyBadgeriaError,
)
from honey_badgeria.back.runtime.runner import run_flow

from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from honey_badgeria.back.graph.graph import Graph


class HoneyBadgeriaApp:
    """Wraps a graph and handlers for use with FastAPI.

    Usage::

        app = HoneyBadgeriaApp(graph, handlers)
        result = app.run_flow("my_flow", {"key": "value"})
    """

    def __init__(
        self,
        graph: Graph,
        handlers: dict[str, Callable[..., Any]] | None = None,
    ) -> None:
        self.graph: Graph = graph
        self.handlers: dict[str, Callable[..., Any]] = handlers or {}

    def run_flow(
        self,
        flow_name: str | None = None,
        payload: dict[str, Any] | None = None,
    ) -> dict[str, Any]:
        """Execute a flow and return results.

        If *flow_name* is given, only the reachable sub-graph runs.
        """
        return run_flow(
            self.graph,
            flow_name=flow_name,
            handlers=self.handlers,
            initial_data=payload,
        )

    def run_with_initial_data(
        self,
        initial_data: dict[str, Any] | None = None,
    ) -> dict[str, Any]:
        """Execute the full graph with initial data."""
        return run_flow(
            self.graph,
            handlers=self.handlers,
            initial_data=initial_data,
        )

    def list_flows(self) -> list[str]:
        """Return available flow names (safe for public listing)."""
        return list(self.graph.flows.keys())
