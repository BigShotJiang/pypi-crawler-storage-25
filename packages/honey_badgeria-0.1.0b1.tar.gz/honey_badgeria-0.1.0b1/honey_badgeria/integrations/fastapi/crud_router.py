"""CRUD router builder: generates RESTful endpoints for HBIA resources.

Maps standard CRUD operations to HBIA flows and wraps results in
the ``HBIAResponse`` envelope.

Usage::

    from honey_badgeria.integrations.fastapi.crud_router import build_crud_router

    crud = build_crud_router(
        hbia_app,
        resource="items",
        flows={
            "list": "list_items",
            "get": "get_item",
            "create": "create_item",
            "update": "update_item",
            "delete": "delete_item",
        },
    )
    app.include_router(crud)
"""

from __future__ import annotations

from typing import Any, TYPE_CHECKING

from honey_badgeria.integrations.fastapi.response import (
    hbia_success,
    hbia_error,
    hbia_paginated,
)
from honey_badgeria.conf.defaults import DEFAULT_API_PREFIX, DEFAULT_MAX_PAGE_SIZE

if TYPE_CHECKING:
    from honey_badgeria.integrations.fastapi.adapter import HoneyBadgeriaApp


def build_crud_router(
    hbia_app: HoneyBadgeriaApp,
    resource: str,
    flows: dict[str, str],
    prefix: str | None = None,
    auth_dependency: Any | None = None,
    id_field: str = "id",
) -> Any:
    """Build a FastAPI router with RESTful CRUD endpoints.

    Args:
        hbia_app:        HoneyBadgeriaApp instance.
        resource:        Resource name (used in URL path, e.g. ``"items"``).
        flows:           Mapping of operation to flow name.  Keys:
                         ``"list"``, ``"get"``, ``"create"``,
                         ``"update"``, ``"delete"``.
                         Only provided keys get endpoints.
        prefix:          URL prefix (defaults to Settings API_PREFIX).
        auth_dependency: Optional FastAPI auth dependency.
        id_field:        Name of the ID path parameter (default ``"id"``).

    Returns:
        FastAPI ``APIRouter``.
    """
    try:
        from fastapi import APIRouter, Body, Query
    except ImportError:
        raise ImportError(
            "FastAPI is required. Install with: pip install honey-badgeria[fastapi]"
        )

    from honey_badgeria.conf.settings import get_settings

    effective_prefix = prefix if prefix is not None else get_settings().API_PREFIX

    router = APIRouter(prefix=effective_prefix)

    dependencies: list[Any] = []
    if auth_dependency is not None:
        from fastapi import Depends
        dependencies.append(Depends(auth_dependency))

    if "list" in flows:
        _register_list(router, hbia_app, resource, flows["list"], dependencies, id_field)

    if "get" in flows:
        _register_get(router, hbia_app, resource, flows["get"], dependencies, id_field)

    if "create" in flows:
        _register_create(router, hbia_app, resource, flows["create"], dependencies)

    if "update" in flows:
        _register_update(router, hbia_app, resource, flows["update"], dependencies, id_field)

    if "delete" in flows:
        _register_delete(router, hbia_app, resource, flows["delete"], dependencies, id_field)

    return router


def _run_and_wrap(hbia_app, flow_name: str, payload: dict | None = None) -> dict[str, Any]:
    """Execute a flow and wrap in HBIAResponse envelope."""
    from honey_badgeria.core.exceptions import (
        FlowNotFoundError,
        HoneyBadgeriaError,
    )
    try:
        result = hbia_app.run_flow(flow_name, payload)
        return hbia_success(data=result)
    except FlowNotFoundError:
        return hbia_error("NOT_FOUND", f"Flow '{flow_name}' not found")
    except HoneyBadgeriaError as exc:
        return hbia_error("EXECUTION_ERROR", str(exc))
    except Exception as exc:
        return hbia_error("INTERNAL_ERROR", "An unexpected error occurred")


def _register_list(router, hbia_app, resource, flow_name, dependencies, id_field):
    from fastapi import Query as Q

    async def endpoint(
        page: int = Q(default=1, ge=1),
        page_size: int = Q(default=20, ge=1, le=DEFAULT_MAX_PAGE_SIZE),
    ) -> dict[str, Any]:
        payload = {"page": page, "page_size": page_size}
        from honey_badgeria.core.exceptions import HoneyBadgeriaError
        try:
            result = hbia_app.run_flow(flow_name, payload)
        except HoneyBadgeriaError as exc:
            return hbia_error("EXECUTION_ERROR", str(exc))
        except Exception:
            return hbia_error("INTERNAL_ERROR", "An unexpected error occurred")

        if isinstance(result, dict) and "items" in result:
            items = result["items"]
            total = result.get("total", len(items))
            return hbia_paginated(items, total=total, page=page, page_size=page_size)
        return hbia_success(data=result)

    router.add_api_route(
        f"/{resource}",
        endpoint,
        methods=["GET"],
        name=f"list_{resource}",
        dependencies=dependencies,
    )


def _register_get(router, hbia_app, resource, flow_name, dependencies, id_field):
    async def endpoint(item_id: str) -> dict[str, Any]:
        return _run_and_wrap(hbia_app, flow_name, {id_field: item_id})

    router.add_api_route(
        f"/{resource}/{{item_id}}",
        endpoint,
        methods=["GET"],
        name=f"get_{resource}",
        dependencies=dependencies,
    )


def _register_create(router, hbia_app, resource, flow_name, dependencies):
    from fastapi import Body

    async def endpoint(payload: dict[str, Any] = Body(...)) -> dict[str, Any]:
        return _run_and_wrap(hbia_app, flow_name, payload)

    router.add_api_route(
        f"/{resource}",
        endpoint,
        methods=["POST"],
        name=f"create_{resource}",
        dependencies=dependencies,
    )


def _register_update(router, hbia_app, resource, flow_name, dependencies, id_field):
    from fastapi import Body

    async def endpoint(item_id: str, payload: dict[str, Any] = Body(...)) -> dict[str, Any]:
        payload[id_field] = item_id
        return _run_and_wrap(hbia_app, flow_name, payload)

    router.add_api_route(
        f"/{resource}/{{item_id}}",
        endpoint,
        methods=["PUT"],
        name=f"update_{resource}",
        dependencies=dependencies,
    )


def _register_delete(router, hbia_app, resource, flow_name, dependencies, id_field):
    async def endpoint(item_id: str) -> dict[str, Any]:
        return _run_and_wrap(hbia_app, flow_name, {id_field: item_id})

    router.add_api_route(
        f"/{resource}/{{item_id}}",
        endpoint,
        methods=["DELETE"],
        name=f"delete_{resource}",
        dependencies=dependencies,
    )
