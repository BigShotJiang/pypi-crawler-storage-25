"""FastAPI integration for Honey Badgeria (optional)."""

try:
    from .adapter import HoneyBadgeriaApp
    from .router_builder import build_flow_router
    from .crud_router import build_crud_router
    from .response import hbia_success, hbia_error, hbia_paginated
    __all__ = [
        "HoneyBadgeriaApp",
        "build_flow_router",
        "build_crud_router",
        "hbia_success",
        "hbia_error",
        "hbia_paginated",
    ]
except ImportError:
    __all__ = []
