"""FastAPI router builder: creates API routes from HBIA flows.

Security rules enforced by this module:

1. **No mutable default arguments** — payload defaults to ``None``,
   never a shared ``{}``.
2. **Auth dependency hook** — pass ``auth_dependency`` to
   :func:`build_flow_router` to require authentication on every endpoint.
3. **Input validation** — payloads must be ``dict | None``.
4. **API versioning** — the default prefix is ``/api/v1`` (from Settings).
5. **No destructive endpoints** — only flow execution is exposed;
   cache management and admin operations are CLI-only.
"""

from __future__ import annotations

from typing import Any, TYPE_CHECKING

from honey_badgeria.conf.defaults import DEFAULT_API_PREFIX

if TYPE_CHECKING:
    from honey_badgeria.integrations.fastapi.adapter import HoneyBadgeriaApp


def build_flow_router(
    hbia_app: HoneyBadgeriaApp,
    prefix: str | None = None,
    auth_dependency: Any | None = None,
) -> Any:
    """Build a FastAPI APIRouter with endpoints for each flow.

    Args:
        hbia_app: :class:`HoneyBadgeriaApp` instance.
        prefix: URL prefix.  Defaults to ``Settings.API_PREFIX``
            (``/api/v1`` out of the box).
        auth_dependency: An optional FastAPI ``Depends(...)``-compatible
            callable.  When provided, **every** generated endpoint
            requires it — use this for authentication / authorization.

    Returns:
        FastAPI ``APIRouter`` instance.

    Requires:
        ``pip install honey-badgeria[fastapi]``
    """
    try:
        from fastapi import APIRouter, Body
    except ImportError:
        raise ImportError(
            "FastAPI is required for router building. "
            "Install with: pip install honey-badgeria[fastapi]"
        )

    from honey_badgeria.conf.settings import get_settings

    effective_prefix = prefix if prefix is not None else get_settings().API_PREFIX

    router = APIRouter(prefix=effective_prefix)

    for flow_name in hbia_app.graph.flows:
        _register_flow_endpoint(router, hbia_app, flow_name, auth_dependency)

    # Read-only list endpoint (no auth required by default)
    @router.get("/flows", name="list_flows")
    async def list_flows() -> dict[str, Any]:
        from honey_badgeria.integrations.fastapi.response import hbia_success
        return hbia_success(data={"flows": hbia_app.list_flows()})

    return router


def _register_flow_endpoint(
    router: Any,
    hbia_app: HoneyBadgeriaApp,
    flow_name: str,
    auth_dependency: Any | None = None,
) -> None:
    """Register a single flow endpoint.

    The generated endpoint:
    - Accepts ``POST`` only.
    - Payload defaults to ``None`` (not a mutable ``{}``).
    - Passes ``flow_name`` to the app so only the correct sub-graph runs.
    """
    try:
        from fastapi import Body
    except ImportError:
        raise ImportError("FastAPI is required")

    dependencies: list[Any] = []
    if auth_dependency is not None:
        try:
            from fastapi import Depends
        except ImportError:
            raise ImportError("FastAPI is required")
        dependencies.append(Depends(auth_dependency))

    async def endpoint(payload: dict[str, Any] | None = Body(default=None)) -> dict[str, Any]:
        from honey_badgeria.integrations.fastapi.response import hbia_success, hbia_error
        from honey_badgeria.core.exceptions import HoneyBadgeriaError
        try:
            result = hbia_app.run_flow(flow_name, payload)
            return hbia_success(data=result)
        except HoneyBadgeriaError as exc:
            return hbia_error("EXECUTION_ERROR", str(exc))
        except Exception:
            return hbia_error("INTERNAL_ERROR", "An unexpected error occurred")

    router.add_api_route(
        f"/{flow_name}",
        endpoint,
        methods=["POST"],
        name=f"run_{flow_name}",
        dependencies=dependencies,
    )
