"""Framework integrations (all optional)."""
