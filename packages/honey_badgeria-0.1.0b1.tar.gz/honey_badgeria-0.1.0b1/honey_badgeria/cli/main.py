"""Honey Badgeria CLI entry point.

All commands are implemented as modules in ``cli/commands/``.
The CLI requires ``typer`` (install with ``pip install honey-badgeria[cli]``).
"""

import sys


def main():
    """Main CLI entry point."""
    try:
        import typer
    except ImportError:
        print("Honey Badgeria CLI requires typer.")
        print("Install with: pip install honey-badgeria[cli]")
        sys.exit(1)

    app = typer.Typer(
        name="hbia",
        help="Honey Badgeria — Application framework designed for AI-assisted development.",
        add_completion=False,
    )

    # --- built-in version command ---
    @app.command("version")
    def version():
        """Show Honey Badgeria version."""
        from honey_badgeria import __version__
        typer.echo(f"Honey Badgeria v{__version__}")

    # --- register all command modules ---
    from honey_badgeria.cli.commands import (
        run,
        validate,
        inspect,
        explain,
        viz,
        cache_info,
        cache_prune,
        clear_cache,
        doctor,
        graph,
        graph_sync,
        graph_validate,
        vertex_create,
        flow_build,
        flow_create,
        flow_list,
        init_project,
        crud_create,
        context,
        health,
        lint,
        # Frontend commands
        ui_inspect,
        ui_graph,
        ui_codegen,
        ui_lint,
        ui_validate,
    )

    for cmd_module in (
        run,
        validate,
        inspect,
        explain,
        viz,
        cache_info,
        cache_prune,
        clear_cache,
        doctor,
        graph,
        graph_sync,
        graph_validate,
        vertex_create,
        flow_build,
        flow_create,
        flow_list,
        init_project,
        crud_create,
        context,
        health,
        lint,
        # Frontend commands
        ui_inspect,
        ui_graph,
        ui_codegen,
        ui_lint,
        ui_validate,
    ):
        cmd_module.register(app)

    app()


if __name__ == "__main__":
    main()
