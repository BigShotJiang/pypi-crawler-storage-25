"""CLI command: graph-validate - deep validation of graph YAML."""


def register(app):
    """Register the graph-validate command with a Typer app."""
    import typer

    @app.command("graph-validate")
    def graph_validate(
        path: str = typer.Argument(..., help="Path to graph YAML file."),
    ):
        """Validate a graph YAML file with both DSL and structural checks."""
        from honey_badgeria.utils.yaml_io import load_yaml
        from honey_badgeria.back.dsl.validator import DSLValidator
        from honey_badgeria.back.dsl.loader import load_graph_from_yaml
        from honey_badgeria.back.graph.validator import GraphValidator

        # Phase 1: DSL-level validation
        try:
            raw = load_yaml(path)
        except Exception as e:
            typer.echo(f"✘ Cannot read YAML: {e}", err=True)
            raise typer.Exit(1)

        dsl_errors = DSLValidator().validate(raw)
        if dsl_errors:
            typer.echo("✘ DSL validation errors:")
            for err in dsl_errors:
                typer.echo(f"  - {err}")
            raise typer.Exit(1)
        typer.echo("✔ DSL definition OK")

        # Phase 2: structural graph validation
        try:
            g = load_graph_from_yaml(path)
            GraphValidator(g).validate()
            typer.echo("✔ Graph structure OK")
        except Exception as e:
            typer.echo(f"✘ Structural validation failed: {e}", err=True)
            raise typer.Exit(1)

        typer.echo("✔ All validations passed.")
