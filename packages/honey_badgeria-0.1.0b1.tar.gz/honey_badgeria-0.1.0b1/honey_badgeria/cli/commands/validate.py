"""CLI command: validate - validate a graph definition."""


def register(app):
    """Register the validate command with a Typer app."""
    import typer

    @app.command("validate")
    def validate(
        graph: str = typer.Argument(..., help="Path to graph YAML file."),
        strict: bool = typer.Option(False, "--strict", help="Also run DSL validation."),
    ):
        """Validate a graph YAML file for structural correctness."""
        from honey_badgeria.back.dsl.loader import load_graph_from_yaml
        from honey_badgeria.back.graph.validator import GraphValidator

        try:
            g = load_graph_from_yaml(graph)
        except Exception as e:
            typer.echo(f"✘ Failed to load graph: {e}", err=True)
            raise typer.Exit(1)

        try:
            GraphValidator(g).validate()
            typer.echo("✔ Graph structure is valid")
        except Exception as e:
            typer.echo(f"✘ Validation failed: {e}", err=True)
            raise typer.Exit(1)

        if strict:
            from honey_badgeria.back.dsl.validator import DSLValidator
            from honey_badgeria.utils.yaml_io import load_yaml
            raw = load_yaml(graph)
            errors = DSLValidator().validate(raw)
            if errors:
                for err in errors:
                    typer.echo(f"  ✘ {err}", err=True)
                raise typer.Exit(1)
            typer.echo("✔ DSL definition is valid")
