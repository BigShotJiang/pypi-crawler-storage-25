"""CLI command: health - detect technical debt and module issues."""

from honey_badgeria.conf.defaults import MODULE_MAX_LINES


def register(app):
    """Register the health command with a Typer app."""
    import typer

    @app.command("health")
    def health(
        root: str = typer.Argument(".", help="Root directory to scan."),
        max_lines: int = typer.Option(
            MODULE_MAX_LINES, "--max-lines",
            help="Maximum allowed lines per module.",
        ),
        json_output: bool = typer.Option(False, "--json", help="Output as JSON."),
    ):
        """Detect technical debt: large modules, circular deps, duplicates."""
        from honey_badgeria.back.discovery.health_checker import ModuleHealthChecker

        checker = ModuleHealthChecker(root=root, max_lines=max_lines)
        issues = checker.run()

        if json_output:
            import json
            typer.echo(json.dumps(issues, indent=2))
            return

        if not issues:
            typer.echo("✔ No issues found.")
            return

        for issue in issues:
            icon = "⚠" if issue["severity"] == "warning" else "✘"
            file_info = f" ({issue['file']})" if issue["file"] else ""
            typer.echo(f"  {icon} [{issue['code']}]{file_info}: {issue['message']}")

        errors = sum(1 for i in issues if i["severity"] == "error")
        warnings = sum(1 for i in issues if i["severity"] == "warning")
        typer.echo(f"\n{errors} error(s), {warnings} warning(s)")

        if errors:
            raise typer.Exit(1)
