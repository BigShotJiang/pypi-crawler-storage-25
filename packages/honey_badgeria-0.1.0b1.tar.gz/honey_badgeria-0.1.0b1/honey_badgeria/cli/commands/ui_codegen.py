"""CLI command: ui-codegen — generate TypeScript runtime from YAML definitions.

Usage:
    hbia ui-codegen graph/ --output front/hbia-runtime
    hbia ui-codegen graph/dashboard --output front/hbia-runtime
"""

from __future__ import annotations


def register(app):
    """Register the ui-codegen command with a Typer app."""
    import typer

    @app.command("ui-codegen")
    def ui_codegen(
        graph_path: str = typer.Argument(
            "graph", help="Path to graph/ directory or a single domain."
        ),
        output: str = typer.Option(
            "hbia-runtime",
            "--output", "-o",
            help="Output directory for generated TypeScript files.",
        ),
    ):
        """Generate TypeScript runtime from YAML graph definitions.

        Reads all domain definitions under the graph/ directory and
        generates a complete HBIA runtime:

            hbia-runtime/
                index.ts   — Barrel exports
                types.ts   — TypeScript interfaces
                store.ts   — State store (pub/sub)
                effects.ts — Effect watcher system
                events.ts  — Event dispatchers
                react.tsx  — React hooks & provider
        """
        import os

        from honey_badgeria.front.dsl.loader import (
            load_frontend_domain,
            load_all_frontend_domains,
        )
        from honey_badgeria.front.codegen import FrontendCodegen

        try:
            # Detect if path is a single domain or the graph root
            if os.path.isdir(os.path.join(graph_path, "ui")) or \
               os.path.isdir(os.path.join(graph_path, "state")):
                # Single domain
                domains = [load_frontend_domain(graph_path, validate=True)]
            else:
                # Graph root with multiple domains
                domains = load_all_frontend_domains(graph_path, validate=True)

            if not domains:
                typer.echo("✘ No domains found.", err=True)
                raise typer.Exit(1)

            codegen = FrontendCodegen(domains=domains)
            generated = codegen.generate(output_dir=output)

            typer.echo(f"✔ Generated {len(generated)} files in {output}/")
            for path in generated:
                typer.echo(f"  {path}")

        except Exception as exc:
            typer.echo(f"✘ Code generation failed: {exc}", err=True)
            raise typer.Exit(1)
