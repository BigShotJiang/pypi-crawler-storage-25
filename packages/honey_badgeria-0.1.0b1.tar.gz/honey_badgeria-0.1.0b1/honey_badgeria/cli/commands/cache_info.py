"""CLI command: cache-info - display cache statistics."""

from honey_badgeria.conf.defaults import DEFAULT_CACHE_DIR


def register(app):
    """Register the cache-info command with a Typer app."""
    import typer

    @app.command("cache-info")
    def cache_info(
        cache_dir: str = typer.Option(DEFAULT_CACHE_DIR, "--dir", help="Cache directory."),
    ):
        """Display cache statistics: entry count, total size."""
        from honey_badgeria.back.runtime.cache.cache_manager import CacheManager

        cm = CacheManager(cache_dir)
        info = cm.info()

        typer.echo(f"Cache directory:  {info['dir']}")
        typer.echo(f"Entries:          {info['entries']}")
        size_kb = info['size_bytes'] / 1024
        typer.echo(f"Total size:       {size_kb:.1f} KB")
