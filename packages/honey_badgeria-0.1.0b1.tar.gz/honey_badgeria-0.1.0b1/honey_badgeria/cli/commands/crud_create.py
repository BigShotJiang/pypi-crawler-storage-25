"""CLI command: crud-create — scaffold a complete CRUD resource.

Generates backend flows, vertices, and frontend graph domain for a
standard CRUD resource with the HBIA response envelope.

Usage::

    hbia crud-create items --fields "name:str,price:float,active:bool" --domain inventory
    hbia crud-create users --fields "email:str,name:str" --back-only
    hbia crud-create posts --fields "title:str,body:str" --front-only
"""

from __future__ import annotations

import os


def register(app):
    """Register the crud-create command with a Typer app."""
    import typer

    @app.command("crud-create")
    def crud_create(
        resource: str = typer.Argument(..., help="Resource name (snake_case, e.g. 'items')."),
        fields: str = typer.Option(
            "name:str",
            "--fields",
            "-f",
            help="Comma-separated field:type pairs (e.g. 'name:str,price:float').",
        ),
        domain: str = typer.Option(
            "",
            "--domain",
            "-d",
            help="Domain directory name (defaults to resource name).",
        ),
        back_only: bool = typer.Option(False, "--back-only", help="Only generate backend files."),
        front_only: bool = typer.Option(False, "--front-only", help="Only generate frontend files."),
        project_dir: str = typer.Option(".", "--project-dir", "-p", help="Project root directory."),
    ):
        """Scaffold a complete CRUD resource (backend + frontend).

        This command generates all the files needed for standard
        Create, Read, Update, Delete operations on a resource.

        Backend:
          - Flow YAML with 5 vertices (list, get, create, update, delete)
          - Vertex handler stubs
          - Test file

        Frontend:
          - State node with typed fields
          - Events (load, create, update, delete)
          - Effects with on_event triggers
          - UI components (list + form)
          - Service file with typed CRUD helpers
        """
        domain_name = domain or resource
        parsed_fields = _parse_fields(fields)

        if not parsed_fields:
            typer.echo("✘ No fields provided. Use --fields 'name:str,price:float'", err=True)
            raise typer.Exit(1)

        generated: list[str] = []

        if not front_only:
            generated.extend(_scaffold_backend(project_dir, resource, domain_name, parsed_fields))

        if not back_only:
            generated.extend(_scaffold_frontend(project_dir, resource, domain_name, parsed_fields))

        typer.echo(f"✔ CRUD resource '{resource}' scaffolded ({len(generated)} files)")
        typer.echo("")
        for f in generated:
            typer.echo(f"  {f}")

        typer.echo("")
        if not front_only:
            typer.echo("  Next: implement vertex handlers in vertices/")
        if not back_only:
            typer.echo("  Next: implement effect handlers and views in graph/")
            typer.echo(f"  Next: hbia ui-codegen graph/ --output hbia-runtime/")


def _parse_fields(fields_str: str) -> list[tuple[str, str]]:
    """Parse 'name:str,price:float' into [('name', 'str'), ('price', 'float')]."""
    result = []
    for pair in fields_str.split(","):
        pair = pair.strip()
        if ":" in pair:
            name, typ = pair.split(":", 1)
            result.append((name.strip(), typ.strip()))
    return result


def _write(path: str, content: str) -> None:
    os.makedirs(os.path.dirname(path) or ".", exist_ok=True)
    with open(path, "w") as f:
        f.write(content)


def _pascal(name: str) -> str:
    return "".join(w.capitalize() for w in name.split("_"))


def _singular(name: str) -> str:
    if name.endswith("ies"):
        return name[:-3] + "y"
    if name.endswith("ses") or name.endswith("xes"):
        return name[:-2]
    if name.endswith("s") and not name.endswith("ss"):
        return name[:-1]
    return name


# ======================================================================
# Backend scaffolding
# ======================================================================

def _scaffold_backend(
    project_dir: str,
    resource: str,
    domain: str,
    fields: list[tuple[str, str]],
) -> list[str]:
    """Generate backend CRUD files."""
    generated = []

    # Detect back/ subdirectory (monorepo)
    back_dir = project_dir
    if os.path.isdir(os.path.join(project_dir, "back")):
        back_dir = os.path.join(project_dir, "back")

    singular = _singular(resource)

    # Flow YAML
    flow_dir = os.path.join(back_dir, "flows", domain)
    flow_path = os.path.join(flow_dir, f"crud_{resource}.yaml")
    _write(flow_path, _backend_flow_yaml(resource, singular, domain, fields))
    generated.append(flow_path)

    # Vertex handlers
    vert_dir = os.path.join(back_dir, "vertices", domain)
    for op in ("list", "get", "create", "update", "delete"):
        file_suffix = resource if op == "list" else singular
        handler_path = os.path.join(vert_dir, f"{op}_{file_suffix}.py")
        _write(handler_path, _backend_vertex_handler(resource, singular, op, fields))
        generated.append(handler_path)

    _write(os.path.join(vert_dir, "__init__.py"), "")

    # Test file
    test_dir = os.path.join(back_dir, "tests")
    os.makedirs(test_dir, exist_ok=True)
    test_path = os.path.join(test_dir, f"test_crud_{resource}.py")
    _write(test_path, _backend_test(resource, singular, domain, fields))
    generated.append(test_path)

    return generated


def _backend_flow_yaml(resource, singular, domain, fields):
    field_outputs = "\n".join(f"        {n}: {t}" for n, t in fields)
    return f"""\
# Flow: crud_{resource}
# Complete CRUD pipeline for {resource}.
# All endpoints use the HBIA Response Envelope.
# Pipeline per operation:
#   list: list_{resource} (paginated)
#   get:  get_{singular} (by id)
#   create: validate_{singular} → create_{singular}
#   update: validate_{singular} → update_{singular}
#   delete: delete_{singular}

flow:
  list_{resource}:
    list_{resource}:
      handler: vertices.{domain}.list_{resource}.list_{resource}
      effect: side_effect
      version: "1"
      inputs:
        page: int
        page_size: int
      outputs:
        items: list
        total: int

  get_{singular}:
    get_{singular}:
      handler: vertices.{domain}.get_{singular}.get_{singular}
      effect: side_effect
      version: "1"
      inputs:
        id: str
      outputs:
{field_outputs}

  create_{singular}:
    validate_{singular}:
      handler: vertices.{domain}.create_{singular}.validate_{singular}
      effect: pure
      version: "1"
      outputs:
        is_valid: bool
        errors: list
      next:
        - create_{singular}

    create_{singular}:
      handler: vertices.{domain}.create_{singular}.create_{singular}
      effect: side_effect
      version: "1"
      inputs:
        is_valid: validate_{singular}.is_valid
      outputs:
        id: str
{field_outputs}

  update_{singular}:
    update_{singular}:
      handler: vertices.{domain}.update_{singular}.update_{singular}
      effect: side_effect
      version: "1"
      inputs:
        id: str
      outputs:
{field_outputs}

  delete_{singular}:
    delete_{singular}:
      handler: vertices.{domain}.delete_{singular}.delete_{singular}
      effect: side_effect
      version: "1"
      inputs:
        id: str
      outputs:
        deleted: bool
"""


def _backend_vertex_handler(resource, singular, op, fields):
    pascal_name = _pascal(singular)
    if op == "list":
        return f"""\
\"\"\"Vertex handler: list_{resource}.\"\"\"

from honey_badgeria.decorators import vertex


@vertex
def list_{resource}(page=1, page_size=20):
    \"\"\"List all {resource} with pagination.\"\"\"
    # TODO: Replace with real data source
    items: list = []
    return {{"items": items, "total": len(items)}}
"""
    elif op == "get":
        return f"""\
\"\"\"Vertex handler: get_{singular}.\"\"\"

from honey_badgeria.decorators import vertex


@vertex
def get_{singular}(id=""):
    \"\"\"Get a single {singular} by ID.\"\"\"
    # TODO: Replace with real data source
    return {{"id": id, "error": "not implemented"}}
"""
    elif op == "create":
        field_params = ", ".join(f'{n}=""' for n, _ in fields)
        field_dict = ", ".join(f'"{n}": {n}' for n, _ in fields)
        return f"""\
\"\"\"Vertex handlers: create_{singular} pipeline.\"\"\"

from honey_badgeria.decorators import vertex


@vertex
def validate_{singular}({field_params}):
    \"\"\"Validate {singular} data before creation.\"\"\"
    errors = []
{chr(10).join(f'    if not {n}: errors.append("{n} is required")' for n, _ in fields)}
    return {{"is_valid": len(errors) == 0, "errors": errors, {field_dict}}}


@vertex
def create_{singular}(is_valid=False, errors=None, {field_params}):
    \"\"\"Persist a new {singular}.\"\"\"
    if not is_valid:
        return {{"error": errors}}
    # TODO: Replace with real persistence
    new_id = "new_id"
    return {{"id": new_id, {field_dict}}}
"""
    elif op == "update":
        field_params = ", ".join(f'{n}=""' for n, _ in fields)
        field_dict = ", ".join(f'"{n}": {n}' for n, _ in fields)
        return f"""\
\"\"\"Vertex handler: update_{singular}.\"\"\"

from honey_badgeria.decorators import vertex


@vertex
def update_{singular}(id="", {field_params}):
    \"\"\"Update an existing {singular}.\"\"\"
    # TODO: Replace with real persistence
    return {{"id": id, {field_dict}}}
"""
    else:  # delete
        return f"""\
\"\"\"Vertex handler: delete_{singular}.\"\"\"

from honey_badgeria.decorators import vertex


@vertex
def delete_{singular}(id=""):
    \"\"\"Delete a {singular} by ID.\"\"\"
    # TODO: Replace with real persistence
    return {{"deleted": True}}
"""


def _backend_test(resource, singular, domain, fields):
    return f"""\
\"\"\"Tests for CRUD {resource} flows.\"\"\"

from honey_badgeria.testing import GraphFactory, FlowTester


class TestCrud{_pascal(resource)}:
    \"\"\"Tests for the {resource} CRUD flow pipeline.\"\"\"

    def test_list_{resource}_returns_items(self):
        from vertices.{domain}.list_{resource} import list_{resource}

        graph = GraphFactory.create(
            vertices=[
                {{"name": "list_{resource}", "handler": list_{resource},
                 "effect": "side_effect", "version": "1"}},
            ],
        )
        tester = FlowTester(graph)
        result = tester.run(initial_data={{"page": 1, "page_size": 20}})
        assert "list_{resource}.items" in result

    def test_create_{singular}_validates(self):
        from vertices.{domain}.create_{singular} import validate_{singular}

        graph = GraphFactory.create(
            vertices=[
                {{"name": "validate", "handler": validate_{singular},
                 "effect": "pure", "version": "1"}},
            ],
        )
        tester = FlowTester(graph)
        result = tester.run()
        assert "validate.is_valid" in result

    def test_delete_{singular}_returns_deleted(self):
        from vertices.{domain}.delete_{singular} import delete_{singular}

        graph = GraphFactory.create(
            vertices=[
                {{"name": "delete", "handler": delete_{singular},
                 "effect": "side_effect", "version": "1"}},
            ],
        )
        tester = FlowTester(graph)
        result = tester.run(initial_data={{"id": "test_id"}})
        assert result.get("delete.deleted") is True
"""


# ======================================================================
# Frontend scaffolding
# ======================================================================

def _scaffold_frontend(
    project_dir: str,
    resource: str,
    domain: str,
    fields: list[tuple[str, str]],
) -> list[str]:
    """Generate frontend CRUD graph domain."""
    generated = []

    # Detect front/ subdirectory (monorepo)
    front_dir = project_dir
    if os.path.isdir(os.path.join(project_dir, "front")):
        front_dir = os.path.join(project_dir, "front")

    singular = _singular(resource)
    pascal = _pascal(resource)
    pascal_singular = _pascal(singular)
    state_name = f"{pascal}State"
    graph_dir = os.path.join(front_dir, "graph", domain)

    # ── State ─────────────────────────────────────────────────────
    state_dir = os.path.join(graph_dir, "state", state_name)

    ts_fields = {n: _py_to_ts(t) for n, t in fields}

    state_yaml = f"""\
state: {state_name}
interface: {state_name}Data
fields:
  items: list
  selected: "null | {pascal_singular}"
  loading: boolean
  error: "string | null"
mutations:
  - set_items
  - set_selected
  - set_loading
  - set_error
triggers: []
initial:
  loading: "false"
  error: "null"
"""
    _write(os.path.join(state_dir, "state.yaml"), state_yaml)
    generated.append(os.path.join(state_dir, "state.yaml"))

    interface_ts = f"""\
export interface {pascal_singular} {{
  id: string
{chr(10).join(f'  {n}: {t}' for n, t in ts_fields.items())}
}}

export interface {state_name}Data {{
  items: {pascal_singular}[]
  selected: {pascal_singular} | null
  loading: boolean
  error: string | null
}}
"""
    _write(os.path.join(state_dir, "interface.ts"), interface_ts)
    generated.append(os.path.join(state_dir, "interface.ts"))

    mutations_ts = f"""\
import type {{ {state_name}Data, {pascal_singular} }} from "./interface"

export function set_items(state: {state_name}Data, payload: {{ items: {pascal_singular}[]; error?: string | null }}): {state_name}Data {{
  return {{ ...state, items: payload.items, error: payload.error ?? null }}
}}

export function set_selected(state: {state_name}Data, payload: {{ selected: {pascal_singular} | null }}): {state_name}Data {{
  return {{ ...state, selected: payload.selected }}
}}

export function set_loading(state: {state_name}Data, payload: {{ loading: boolean }}): {state_name}Data {{
  return {{ ...state, loading: payload.loading }}
}}

export function set_error(state: {state_name}Data, payload: {{ error: string | null }}): {state_name}Data {{
  return {{ ...state, error: payload.error }}
}}
"""
    _write(os.path.join(state_dir, "mutations.ts"), mutations_ts)
    generated.append(os.path.join(state_dir, "mutations.ts"))

    # ── Events ────────────────────────────────────────────────────
    events_dir = os.path.join(graph_dir, "events")

    for event_name, mutation_flow in [
        (f"load_{resource}", f"{state_name}.set_loading"),
        (f"create_{singular}", f"{state_name}.set_loading"),
        (f"update_{singular}", f"{state_name}.set_loading"),
        (f"delete_{singular}", f"{state_name}.set_loading"),
    ]:
        event_yaml = f"""\
event: {event_name}
flow:
  - {mutation_flow}
source: {pascal}List
"""
        path = os.path.join(events_dir, f"{event_name}.yaml")
        _write(path, event_yaml)
        generated.append(path)

    # ── Effects ───────────────────────────────────────────────────
    for effect_name, on_event in [
        (f"fetch_{resource}", f"load_{resource}"),
        (f"create_{singular}_api", f"create_{singular}"),
        (f"update_{singular}_api", f"update_{singular}"),
        (f"delete_{singular}_api", f"delete_{singular}"),
    ]:
        eff_dir = os.path.join(graph_dir, "effects", effect_name)
        effect_yaml = f"""\
effect: {effect_name}
on_event:
  - {on_event}
handler: {effect_name}_handler
effect_type: side_effect
mutates:
  - {state_name}
"""
        _write(os.path.join(eff_dir, "effect.yaml"), effect_yaml)
        generated.append(os.path.join(eff_dir, "effect.yaml"))

        handler_ts = f"""\
import {{ {resource}Service }} from "@/services/{resource}_service"

export async function {effect_name}_handler(
  state: Record<string, unknown>,
  _services: Record<string, unknown>,
): Promise<void> {{
  // TODO: Implement {effect_name} logic
  // const result = await {resource}Service.list()
  // if (result.ok) {{ store.set_items({{ items: result.data }}) }}
  console.log("[HBIA Effect] {effect_name} triggered")
}}
"""
        _write(os.path.join(eff_dir, "handler.ts"), handler_ts)
        generated.append(os.path.join(eff_dir, "handler.ts"))

    # ── UI ────────────────────────────────────────────────────────
    list_ui_dir = os.path.join(graph_dir, "ui", f"{pascal}List")
    list_node_yaml = f"""\
component: {pascal}List
view: {resource}_list_view
reads:
  - {state_name}.items
  - {state_name}.loading
  - {state_name}.error
events:
  on_load: load_{resource}
  on_delete: delete_{singular}
children: []
"""
    _write(os.path.join(list_ui_dir, f"{resource}_list_node.yaml"), list_node_yaml)
    generated.append(os.path.join(list_ui_dir, f"{resource}_list_node.yaml"))

    list_view_tsx = f"""\
"use client"

import {{ useHBIA }} from "@/hbia-runtime"

export function {pascal}ListView() {{
  const items = useHBIA((s) => s.{state_name}.items)
  const loading = useHBIA((s) => s.{state_name}.loading)
  const error = useHBIA((s) => s.{state_name}.error)

  if (loading) {{
    return <div className="hbia-loading">Loading...</div>
  }}

  if (error) {{
    return <div className="hbia-error">{{error}}</div>
  }}

  return (
    <div className="hbia-list">
      {{items.map((item: any) => (
        <div key={{item.id}} className="hbia-list-item">
          {{JSON.stringify(item)}}
        </div>
      ))}}
    </div>
  )
}}
"""
    _write(os.path.join(list_ui_dir, f"{resource}_list_view.tsx"), list_view_tsx)
    generated.append(os.path.join(list_ui_dir, f"{resource}_list_view.tsx"))

    form_ui_dir = os.path.join(graph_dir, "ui", f"{pascal}Form")
    form_node_yaml = f"""\
component: {pascal}Form
view: {resource}_form_view
reads:
  - {state_name}.selected
  - {state_name}.loading
events:
  on_submit: create_{singular}
  on_update: update_{singular}
children: []
"""
    _write(os.path.join(form_ui_dir, f"{resource}_form_node.yaml"), form_node_yaml)
    generated.append(os.path.join(form_ui_dir, f"{resource}_form_node.yaml"))

    form_view_tsx = f"""\
"use client"

import {{ useHBIA }} from "@/hbia-runtime"

export function {pascal}FormView() {{
  const selected = useHBIA((s) => s.{state_name}.selected)
  const loading = useHBIA((s) => s.{state_name}.loading)

  return (
    <form className="hbia-form" onSubmit={{(e) => {{ e.preventDefault() }}}}>
{chr(10).join(f'      <label>{n}<input name="{n}" type="text" defaultValue={{selected?.{n} ?? ""}} /></label>' for n, _ in fields)}
      <button type="submit" disabled={{loading}}>
        {{selected ? "Update" : "Create"}}
      </button>
    </form>
  )
}}
"""
    _write(os.path.join(form_ui_dir, f"{resource}_form_view.tsx"), form_view_tsx)
    generated.append(os.path.join(form_ui_dir, f"{resource}_form_view.tsx"))

    # ── Service ───────────────────────────────────────────────────
    services_dir = os.path.join(front_dir, "services")
    service_ts = f"""\
import {{ createCrudService }} from "./api"
import type {{ {pascal_singular} }} from "@/graph/{domain}/state/{state_name}/interface"

export const {resource}Service = createCrudService<{pascal_singular}>("{resource}")
"""
    service_path = os.path.join(services_dir, f"{resource}_service.ts")
    _write(service_path, service_ts)
    generated.append(service_path)

    return generated


def _py_to_ts(py_type: str) -> str:
    """Convert Python type hint to TypeScript."""
    mapping = {
        "str": "string",
        "string": "string",
        "int": "number",
        "float": "number",
        "number": "number",
        "bool": "boolean",
        "boolean": "boolean",
        "list": "unknown[]",
        "dict": "Record<string, unknown>",
    }
    return mapping.get(py_type.lower().strip(), py_type)
