"""CLI command: init - scaffold a new HBIA project.

Supports three scaffolding modes:

    hbia init my_project                      # plain HBIA project
    hbia init my_project --framework fastapi  # FastAPI + HBIA
    hbia init my_project --framework monorepo # Full-stack monorepo (FastAPI backend)
"""

from __future__ import annotations

import os
import shutil


def register(app):
    """Register the init command with a Typer app."""
    import typer

    @app.command("init")
    def init_project(
        name: str = typer.Argument("my_hbia_project", help="Project directory name."),
        framework: str = typer.Option(
            "plain",
            "--framework",
            "-f",
            help="Framework scaffold: plain, fastapi, or monorepo.",
        ),
    ):
        """Scaffold a new Honey Badgeria project.

        Examples:

            hbia init my_app

            hbia init my_api --framework fastapi

            hbia init my_app --framework monorepo

        Note: HBIA does not install web frameworks for you.
        You must install FastAPI, Next.js, etc. yourself.
        """
        framework = framework.lower().strip()
        if framework not in ("plain", "fastapi", "monorepo"):
            typer.echo(
                f"✘ Unknown framework: {framework!r}. "
                "Choose: plain, fastapi, monorepo.",
                err=True,
            )
            raise typer.Exit(1)

        if os.path.exists(name):
            typer.echo(f"✘ Directory already exists: {name}", err=True)
            raise typer.Exit(1)

        # ── copy base template ────────────────────────────────────────
        template_dir = os.path.join(
            os.path.dirname(
                os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
            ),
            "project_template",
        )

        if os.path.exists(template_dir):
            shutil.copytree(template_dir, name)
        else:
            _scaffold_minimal(name)

        # Ensure __init__.py in tests/
        _touch(os.path.join(name, "tests", "__init__.py"))

        # Ensure conftest.py for PYTHONPATH resolution
        conftest_path = os.path.join(name, "conftest.py")
        if not os.path.exists(conftest_path):
            _write(conftest_path, _CONFTEST_TPL)

        # ── framework-specific overlay ────────────────────────────────
        if framework == "fastapi":
            _scaffold_fastapi(name)
        elif framework == "monorepo":
            _scaffold_monorepo(name)

        # ── replace placeholder project name ──────────────────────────
        _replace_project_name(name)

        # ── generate AI context files ─────────────────────────────────
        _write_ai_context(name, framework=framework)

        # ── summary ───────────────────────────────────────────────────
        typer.echo(f"✔ Project scaffolded: {name}/  (framework: {framework})")
        typer.echo("")
        typer.echo("  Next steps:")
        typer.echo(f"  cd {name}")
        if framework == "fastapi":
            typer.echo("  pip install fastapi uvicorn     # install your preferred versions")
            typer.echo("  uvicorn app:app --reload")
        elif framework == "monorepo":
            typer.echo("")
            typer.echo("  # Backend (FastAPI + HBIA):")
            typer.echo("  cd back")
            typer.echo("  pip install fastapi uvicorn")
            typer.echo("  python manage.py")
            typer.echo("")
            typer.echo("  # Frontend (Next.js — install Node.js 18+ first):")
            typer.echo("  cd front")
            typer.echo("  npm install")
            typer.echo("  npm run dev")
            typer.echo("")
            typer.echo("  # Generate TypeScript runtime from YAML:")
            typer.echo("  cd front && hbia ui-codegen graph/ --output hbia-runtime")
        else:
            typer.echo(
                "  hbia run flows/example_flow.yaml --handlers vertices"
            )
        typer.echo("  hbia doctor")


# ======================================================================
# Helpers
# ======================================================================


def _write(path: str, content: str) -> None:
    os.makedirs(os.path.dirname(path) or ".", exist_ok=True)
    with open(path, "w") as f:
        f.write(content)


def _read(path: str) -> str:
    with open(path) as f:
        return f.read()


def _touch(path: str) -> None:
    os.makedirs(os.path.dirname(path) or ".", exist_ok=True)
    if not os.path.exists(path):
        _write(path, "")


def _scaffold_minimal(name: str) -> None:
    """Create a minimal project when the package template is missing."""
    os.makedirs(name)
    for subdir in ("vertices", "flows", "tests", "infra"):
        os.makedirs(os.path.join(name, subdir))

    _write(os.path.join(name, "settings.py"), _SETTINGS_TPL)
    _write(os.path.join(name, "vertices", "__init__.py"), "")
    _write(os.path.join(name, "vertices", "greetings.py"), _VERTEX_TPL)
    _write(os.path.join(name, "flows", "example_flow.yaml"), _FLOW_TPL)
    _write(os.path.join(name, "tests", "__init__.py"), "")
    _write(os.path.join(name, "tests", "test_flow_example.py"), _TEST_TPL)
    _write(os.path.join(name, "infra", "__init__.py"), "")
    _write(os.path.join(name, "manage.py"), _MANAGE_TPL)
    _write(os.path.join(name, "conftest.py"), _CONFTEST_TPL)
    _write(os.path.join(name, "README.md"), _README_TPL)


def _replace_project_name(name: str) -> None:
    """Replace placeholders in hbia.yaml and README with the actual name."""
    basename = os.path.basename(name)
    title = basename.replace("_", " ").replace("-", " ").title()

    for relpath in ("hbia.yaml", "README.md"):
        fpath = os.path.join(name, relpath)
        if os.path.exists(fpath):
            content = _read(fpath)
            content = content.replace("my_hbia_project", basename)
            content = content.replace("My HBIA Project", title)
            _write(fpath, content)


def _write_ai_context(project_dir: str, framework: str = "plain") -> None:
    """Write AI context files so coding assistants understand HBIA."""
    from honey_badgeria.context import generate_context, KNOWN_TARGETS

    mode_map = {"monorepo": "monorepo", "front": "front"}
    mode = mode_map.get(framework, "back")

    document = generate_context(mode=mode)
    for _key, relpath in KNOWN_TARGETS.items():
        fullpath = os.path.join(project_dir, relpath)
        parent = os.path.dirname(fullpath)
        if parent:
            os.makedirs(parent, exist_ok=True)
        _write(fullpath, document)


# ======================================================================
# FastAPI overlay
# ======================================================================


def _scaffold_fastapi(name: str) -> None:
    """Overlay FastAPI files onto the base project."""
    _write(os.path.join(name, "app.py"), _FASTAPI_APP_TPL)
    _write(os.path.join(name, "manage.py"), _FASTAPI_MANAGE_TPL)
    _write(os.path.join(name, "requirements.txt"), _FASTAPI_REQUIREMENTS_TPL)
    _write(os.path.join(name, "settings.py"), _FASTAPI_SETTINGS_TPL)
    _write(os.path.join(name, "example.env"), _FASTAPI_EXAMPLE_ENV_TPL)
    _write(os.path.join(name, ".env"), _FASTAPI_EXAMPLE_ENV_TPL)

    # infra directory
    infra_dir = os.path.join(name, "infra")
    os.makedirs(infra_dir, exist_ok=True)
    _write(os.path.join(infra_dir, "__init__.py"), "")
    _write(os.path.join(infra_dir, "auth.py"), _INFRA_AUTH_TPL)

    # Patch README with FastAPI instructions
    readme_path = os.path.join(name, "README.md")
    if os.path.exists(readme_path):
        content = _read(readme_path)
        content = content.replace(
            "hbia run flows/example_flow.yaml --handlers vertices\n",
            "python manage.py                  # start the server\n"
            "\n"
            "# Or directly\n"
            "uvicorn app:app --reload\n"
            "\n"
            "# Or via HBIA CLI\n"
            "hbia run flows/example_flow.yaml --handlers vertices\n",
        )
        _write(readme_path, content)


# ======================================================================
# Monorepo overlay — full-stack HBIA (Next.js + Python backend)
# ======================================================================


def _scaffold_monorepo(name: str) -> None:
    """Scaffold a monorepo with /back and /front directories."""
    import shutil

    back_dir = os.path.join(name, "back")
    front_dir = os.path.join(name, "front")

    # ── Move existing backend scaffold into back/ ─────────────────
    # The base template was already copied to `name/`.  Move its
    # contents into `name/back/`.
    os.makedirs(back_dir, exist_ok=True)
    for item in os.listdir(name):
        if item in ("back", "front"):
            continue
        src = os.path.join(name, item)
        dst = os.path.join(back_dir, item)
        shutil.move(src, dst)

    # ── Apply FastAPI overlay on the backend ──────────────────────
    _scaffold_fastapi(back_dir)

    # ── Root monorepo files ───────────────────────────────────────
    _write(os.path.join(name, "hbia.yaml"), _MONOREPO_ROOT_YAML_TPL)
    _write(os.path.join(name, "README.md"), _MONOREPO_README_TPL)

    # ── Frontend scaffold ─────────────────────────────────────────
    os.makedirs(front_dir, exist_ok=True)

    # package.json
    _write(os.path.join(front_dir, "package.json"), _FRONT_PACKAGE_JSON_TPL)

    # TypeScript & Next.js config
    _write(os.path.join(front_dir, "tsconfig.json"), _FRONT_TSCONFIG_TPL)
    _write(os.path.join(front_dir, "next.config.ts"), _FRONT_NEXT_CONFIG_TPL)
    _write(os.path.join(front_dir, "tailwind.config.ts"), _FRONT_TAILWIND_CONFIG_TPL)
    _write(os.path.join(front_dir, "postcss.config.js"), _FRONT_POSTCSS_CONFIG_TPL)

    # hbia.yaml for frontend
    _write(os.path.join(front_dir, "hbia.yaml"), _FRONT_HBIA_YAML_TPL)

    # App directory (Next.js App Router)
    app_dir = os.path.join(front_dir, "app")
    os.makedirs(app_dir, exist_ok=True)
    _write(os.path.join(app_dir, "layout.tsx"), _FRONT_LAYOUT_TPL)
    _write(os.path.join(app_dir, "page.tsx"), _FRONT_PAGE_TPL)
    _write(os.path.join(app_dir, "globals.css"), _FRONT_GLOBALS_CSS_TPL)

    # Graph domain: counter (example)
    graph_dir = os.path.join(front_dir, "graph", "counter")

    # UI nodes
    ui_dir = os.path.join(graph_dir, "ui", "CounterPage")
    os.makedirs(ui_dir, exist_ok=True)
    _write(os.path.join(ui_dir, "counter_page_node.yaml"), _FRONT_UI_NODE_YAML_TPL)
    _write(os.path.join(ui_dir, "counter_page_view.tsx"), _FRONT_UI_VIEW_TPL)

    # State nodes
    state_dir = os.path.join(graph_dir, "state", "CounterState")
    os.makedirs(state_dir, exist_ok=True)
    _write(os.path.join(state_dir, "state.yaml"), _FRONT_STATE_YAML_TPL)
    _write(os.path.join(state_dir, "interface.ts"), _FRONT_STATE_INTERFACE_TPL)
    _write(os.path.join(state_dir, "mutations.ts"), _FRONT_STATE_MUTATIONS_TPL)

    # Effects
    effects_dir = os.path.join(graph_dir, "effects", "log_count")
    os.makedirs(effects_dir, exist_ok=True)
    _write(os.path.join(effects_dir, "effect.yaml"), _FRONT_EFFECT_YAML_TPL)
    _write(os.path.join(effects_dir, "handler.ts"), _FRONT_EFFECT_HANDLER_TPL)

    # Events
    events_dir = os.path.join(graph_dir, "events")
    os.makedirs(events_dir, exist_ok=True)
    _write(os.path.join(events_dir, "increment.yaml"), _FRONT_EVENT_INCREMENT_TPL)
    _write(os.path.join(events_dir, "decrement.yaml"), _FRONT_EVENT_DECREMENT_TPL)

    # Primitives
    primitives_dir = os.path.join(front_dir, "primitives")
    os.makedirs(primitives_dir, exist_ok=True)
    _write(os.path.join(primitives_dir, "button.tsx"), _FRONT_BUTTON_PRIMITIVE_TPL)
    _write(os.path.join(primitives_dir, "card.tsx"), _FRONT_CARD_PRIMITIVE_TPL)
    _write(os.path.join(primitives_dir, "input.tsx"), _FRONT_INPUT_PRIMITIVE_TPL)
    _write(os.path.join(primitives_dir, "modal.tsx"), _FRONT_MODAL_PRIMITIVE_TPL)
    _write(os.path.join(primitives_dir, "badge.tsx"), _FRONT_BADGE_PRIMITIVE_TPL)
    _write(os.path.join(primitives_dir, "spinner.tsx"), _FRONT_SPINNER_PRIMITIVE_TPL)
    _write(os.path.join(primitives_dir, "empty_state.tsx"), _FRONT_EMPTY_STATE_PRIMITIVE_TPL)

    # Services
    services_dir = os.path.join(front_dir, "services")
    os.makedirs(services_dir, exist_ok=True)
    _write(os.path.join(services_dir, "api.ts"), _FRONT_API_SERVICE_TPL)

    # HBIA Runtime (generated)
    runtime_dir = os.path.join(front_dir, "hbia-runtime")
    os.makedirs(runtime_dir, exist_ok=True)
    _write(
        os.path.join(runtime_dir, "README.md"),
        "# HBIA Runtime\n\n"
        "This directory contains generated TypeScript files.\n\n"
        "Regenerate with:\n\n"
        "```bash\n"
        "hbia ui-codegen graph/ --output hbia-runtime\n"
        "```\n",
    )


# ======================================================================
# Inline templates (fallback when project_template/ is absent)
# ======================================================================

_SETTINGS_TPL = '''\
"""Honey Badgeria project settings — single source of truth.

ALL configuration lives here.  NEVER use ``os.environ`` directly in
handlers, vertices, or application code.  Import from this module::

    from settings import SETTINGS
"""

import os
from pathlib import Path

BASE_DIR = Path(__file__).resolve().parent

try:
    from dotenv import load_dotenv
    load_dotenv(BASE_DIR / ".env")
except ImportError:
    pass


def _env(key: str, default: str = "") -> str:
    """Read an environment variable (centralized — use this, not os.environ)."""
    return os.environ.get(key, default)


def _env_bool(key: str, default: bool = False) -> bool:
    return _env(key, str(default)).strip().lower() in ("true", "1", "yes")


def _env_int(key: str, default: int = 0) -> int:
    try:
        return int(_env(key, str(default)))
    except (ValueError, TypeError):
        return default


SETTINGS = {
    "GRAPH_FILE": _env("HBIA_GRAPH_FILE", "flows/example_flow.yaml"),
    "HANDLER_MODULES": [m.strip() for m in _env("HBIA_HANDLER_MODULES", "vertices").split(",") if m.strip()],
    "CACHE_ENABLED": _env_bool("HBIA_CACHE_ENABLED", False),
    "PARALLEL_ENABLED": _env_bool("HBIA_PARALLEL_ENABLED", False),
    "ASYNC_ENABLED": _env_bool("HBIA_ASYNC_ENABLED", False),
    "MAX_WORKERS": _env_int("HBIA_MAX_WORKERS", 4),
}
'''

_VERTEX_TPL = '''\
"""Vertex handlers: greetings domain."""

from honey_badgeria.decorators import vertex


@vertex
def hello(name="World"):
    """Produce a greeting message."""
    return {"greeting": f"Hello, {name}!"}


@vertex
def shout(greeting):
    """Transform a greeting to uppercase."""
    return {"result": greeting.upper()}
'''

_FLOW_TPL = '''\
# Flow: greet
# A simple greeting pipeline that creates and transforms a message.
# Pipeline: hello → shout

flow:
  greet:
    # Step 1: Produce a greeting message
    hello:
      handler: vertices.greetings.hello
      effect: pure
      version: "1"
      outputs:
        greeting: str
      next:
        - shout

    # Step 2: Transform the greeting to uppercase
    shout:
      handler: vertices.greetings.shout
      effect: pure
      version: "1"
      inputs:
        greeting: hello.greeting
      outputs:
        result: str
'''

_TEST_TPL = '''\
"""Example test for the greet flow."""

from honey_badgeria.testing import GraphFactory, FlowTester


class TestGreetingFlow:
    """Tests for the greet flow pipeline: hello → shout."""

    def test_hello_shout_pipeline(self):
        """Verify that hello produces a greeting and shout uppercases it."""
        def hello(name="World"):
            return {"greeting": f"Hello, {name}!"}

        def shout(greeting):
            return {"result": greeting.upper()}

        graph = GraphFactory.create(
            vertices=[
                {"name": "hello", "handler": hello,
                 "effect": "pure", "version": "1"},
                {"name": "shout", "handler": shout,
                 "effect": "pure", "version": "1",
                 "inputs": {"greeting": "hello.greeting"}},
            ],
            edges=[("hello", "shout")],
        )
        tester = FlowTester(graph)
        result = tester.run()
        assert result["shout.result"] == "HELLO, WORLD!"

    def test_hello_with_custom_name(self):
        """Verify hello respects a custom name input."""
        def hello(name="World"):
            return {"greeting": f"Hello, {name}!"}

        graph = GraphFactory.create(
            vertices=[
                {"name": "hello", "handler": hello,
                 "effect": "pure", "version": "1"},
            ],
        )
        tester = FlowTester(graph)
        result = tester.run(initial_data={"name": "HBIA"})
        assert "HBIA" in result.get("hello.greeting", "")
'''

_MANAGE_TPL = '''\
#!/usr/bin/env python
"""HBIA project entry point — runs the default flow.

Usage:
    python manage.py                    # run the default graph
    python manage.py --flow greet       # run a specific flow
"""

import os
import sys

# ── Fix PYTHONPATH so imports work from the project root ──────────
PROJECT_ROOT = os.path.dirname(os.path.abspath(__file__))
if PROJECT_ROOT not in sys.path:
    sys.path.insert(0, PROJECT_ROOT)

from honey_badgeria.conf.settings import configure
from honey_badgeria.back.dsl.loader import load_graph_from_yaml
from honey_badgeria.back.runtime.runner import run_flow


def main():
    from settings import SETTINGS

    configure(SETTINGS)
    graph_file = SETTINGS.get("GRAPH_FILE", "flows/example_flow.yaml")
    graph = load_graph_from_yaml(graph_file)

    flow_name = None
    if "--flow" in sys.argv:
        idx = sys.argv.index("--flow")
        if idx + 1 < len(sys.argv):
            flow_name = sys.argv[idx + 1]

    result = run_flow(graph, flow_name=flow_name)

    print("=== Results ===")
    for key, value in sorted(result.items()):
        print(f"  {key}: {value}")


if __name__ == "__main__":
    main()
'''

_README_TPL = '''\
# My HBIA Project

> Built with Honey Badgeria — an Application framework designed for AI-assisted development.

## Quick Start

```bash
pip install honey-badgeria
hbia doctor
hbia run flows/example_flow.yaml --handlers vertices
```

See AGENTS.md for AI assistant instructions.
'''

_CONFTEST_TPL = '''\
import os
import sys

PROJECT_ROOT = os.path.dirname(os.path.abspath(__file__))
if PROJECT_ROOT not in sys.path:
    sys.path.insert(0, PROJECT_ROOT)
'''

# ======================================================================
# FastAPI templates
# ======================================================================

_FASTAPI_APP_TPL = '''\
"""FastAPI application powered by Honey Badgeria.

Start with:
    python manage.py                  # recommended
    uvicorn app:app --reload          # or directly
"""

from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware

from honey_badgeria.conf.settings import configure
from honey_badgeria.back.dsl.loader import load_graph_from_yaml
from honey_badgeria.integrations.fastapi.adapter import HoneyBadgeriaApp
from honey_badgeria.integrations.fastapi.router_builder import build_flow_router

from settings import SETTINGS, CORS_ORIGINS, DEBUG

# ── Configure HBIA ────────────────────────────────────────────────────
configure(SETTINGS)

# ── Load graph ────────────────────────────────────────────────────────
graph_file = SETTINGS.get("GRAPH_FILE", "flows/example_flow.yaml")
graph = load_graph_from_yaml(graph_file)

# ── Build HBIA app ────────────────────────────────────────────────────
hbia = HoneyBadgeriaApp(graph, handlers={})

# ── FastAPI app ───────────────────────────────────────────────────────
app = FastAPI(
    title="My HBIA API",
    version="0.1.0",
    debug=DEBUG,
)

# ── CORS ──────────────────────────────────────────────────────────────
app.add_middleware(
    CORSMiddleware,
    allow_origins=CORS_ORIGINS,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# ── Flow routes ───────────────────────────────────────────────────────
# For production auth, uncomment and configure infra/auth.py:
#   from infra.auth import require_auth
#   flow_router = build_flow_router(hbia, auth_dependency=require_auth)
flow_router = build_flow_router(hbia)
app.include_router(flow_router)


@app.get("/")
async def root():
    """Health check endpoint."""
    return {"status": "ok", "flows": hbia.list_flows()}


@app.get("/health")
async def health():
    """Health check for orchestrators (k8s, docker-compose, etc.)."""
    return {"status": "healthy"}
'''

_FASTAPI_SETTINGS_TPL = '''\
"""Honey Badgeria project settings — single source of truth.

ALL configuration lives here.  NEVER use ``os.environ`` directly in
handlers, vertices, or application code.  Import from this module::

    from settings import SETTINGS, HOST, PORT, DEBUG, CORS_ORIGINS
"""

import os
from pathlib import Path

# ── Load .env (copy example.env → .env and fill in values) ───────
BASE_DIR = Path(__file__).resolve().parent

try:
    from dotenv import load_dotenv
    load_dotenv(BASE_DIR / ".env")
except ImportError:
    pass  # python-dotenv is optional but recommended


def _env(key: str, default: str = "") -> str:
    """Read an environment variable (centralized — use this, not os.environ)."""
    return os.environ.get(key, default)


def _env_bool(key: str, default: bool = False) -> bool:
    return _env(key, str(default)).strip().lower() in ("true", "1", "yes")


def _env_int(key: str, default: int = 0) -> int:
    try:
        return int(_env(key, str(default)))
    except (ValueError, TypeError):
        return default


def _env_list(key: str, default: str = "") -> list[str]:
    raw = _env(key, default)
    return [item.strip() for item in raw.split(",") if item.strip()]


# ── Server ────────────────────────────────────────────────────────
DEBUG = _env_bool("DEBUG", True)
HOST = _env("HOST", "0.0.0.0")
PORT = _env_int("PORT", 8000)

# ── CORS ──────────────────────────────────────────────────────────
CORS_ORIGINS = _env_list("CORS_ORIGINS", "http://localhost:3000")

# ── HBIA Core ─────────────────────────────────────────────────────
SETTINGS = {
    "GRAPH_FILE": _env("HBIA_GRAPH_FILE", "flows/example_flow.yaml"),
    "HANDLER_MODULES": _env_list("HBIA_HANDLER_MODULES", "vertices"),
    "CACHE_ENABLED": _env_bool("HBIA_CACHE_ENABLED", False),
    "PARALLEL_ENABLED": _env_bool("HBIA_PARALLEL_ENABLED", False),
    "ASYNC_ENABLED": _env_bool("HBIA_ASYNC_ENABLED", True),
    "MAX_WORKERS": _env_int("HBIA_MAX_WORKERS", 4),
    "API_PREFIX": _env("HBIA_API_PREFIX", "/api/v1"),
}

# ── Auth / Keycloak ───────────────────────────────────────────────
# HBIA recommends Keycloak for production auth.  Fill these in when
# you set up your Keycloak instance (see infra/auth.py).
KEYCLOAK_URL = _env("KEYCLOAK_URL", "")
KEYCLOAK_REALM = _env("KEYCLOAK_REALM", "")
KEYCLOAK_CLIENT_ID = _env("KEYCLOAK_CLIENT_ID", "")
KEYCLOAK_CLIENT_SECRET = _env("KEYCLOAK_CLIENT_SECRET", "")
JWT_ALGORITHM = _env("JWT_ALGORITHM", "RS256")
JWT_AUDIENCE = _env("JWT_AUDIENCE", "")
'''

_FASTAPI_MANAGE_TPL = '''\
#!/usr/bin/env python
"""HBIA project entry point — starts the FastAPI development server.

Usage:
    python manage.py                    # start server (default)
    python manage.py runserver          # same
    python manage.py runserver --port 9000
    python manage.py routes             # list all routes
"""

import os
import sys

# ── Fix PYTHONPATH so imports work from the project root ──────────
PROJECT_ROOT = os.path.dirname(os.path.abspath(__file__))
if PROJECT_ROOT not in sys.path:
    sys.path.insert(0, PROJECT_ROOT)


def _runserver(args: list[str]) -> None:
    try:
        import uvicorn
    except ImportError:
        print("✘ uvicorn not installed. Run: pip install uvicorn[standard]")
        sys.exit(1)

    from settings import HOST, PORT, DEBUG

    host = HOST
    port = PORT

    for i, arg in enumerate(args):
        if arg == "--port" and i + 1 < len(args):
            port = int(args[i + 1])
        elif arg == "--host" and i + 1 < len(args):
            host = args[i + 1]

    print(f"Starting HBIA server on {host}:{port} (debug={DEBUG})")
    uvicorn.run("app:app", host=host, port=port, reload=DEBUG)


def _routes() -> None:
    from app import app
    print("\\nRegistered routes:")
    for route in app.routes:
        methods = getattr(route, "methods", {"WS"})
        path = getattr(route, "path", "???")
        print(f"  {', '.join(sorted(methods)):8s} {path}")


COMMANDS = {
    "runserver": _runserver,
    "routes": lambda _: _routes(),
}


def main() -> None:
    args = sys.argv[1:]
    command = args[0] if args else "runserver"
    rest = args[1:] if args else []

    handler = COMMANDS.get(command)
    if handler is None:
        print(f"✘ Unknown command: {command}")
        print(f"Available: {', '.join(COMMANDS)}")
        sys.exit(1)

    handler(rest)


if __name__ == "__main__":
    main()
'''

_FASTAPI_EXAMPLE_ENV_TPL = '''\
# ══════════════════════════════════════════════════════════════════
# HBIA Project Environment — copy to .env and fill in values
# ALL configuration is centralized in settings.py which reads these.
# NEVER use os.environ directly in handlers or application code.
# ══════════════════════════════════════════════════════════════════

# ── Server ────────────────────────────────────────────────────────
DEBUG=true
HOST=0.0.0.0
PORT=8000

# ── CORS (comma-separated origins) ───────────────────────────────
CORS_ORIGINS=http://localhost:3000

# ── HBIA Core ─────────────────────────────────────────────────────
HBIA_GRAPH_FILE=flows/example_flow.yaml
HBIA_HANDLER_MODULES=vertices
HBIA_CACHE_ENABLED=false
HBIA_PARALLEL_ENABLED=false
HBIA_ASYNC_ENABLED=true
HBIA_MAX_WORKERS=4
HBIA_API_PREFIX=/api/v1

# ── Auth / Keycloak ───────────────────────────────────────────────
# HBIA recommends Keycloak for production authentication.
# Set up your Keycloak instance, then fill in these values.
# See infra/auth.py for the integration code.
KEYCLOAK_URL=
KEYCLOAK_REALM=
KEYCLOAK_CLIENT_ID=
KEYCLOAK_CLIENT_SECRET=
JWT_ALGORITHM=RS256
JWT_AUDIENCE=

# ── Database (fill in when needed) ────────────────────────────────
# DATABASE_URL=postgresql://user:pass@localhost:5432/mydb
'''

_INFRA_AUTH_TPL = '''\
"""Authentication infrastructure — Keycloak integration.

HBIA recommends Keycloak as the identity provider for production
applications.  This module provides the connection boilerplate.

Setup:
    1. Deploy a Keycloak instance (Docker, k8s, or cloud).
    2. Create a realm and client for this application.
    3. Fill in KEYCLOAK_* values in your .env file.
    4. Uncomment the auth_dependency in app.py.

Usage in app.py::

    from infra.auth import require_auth
    flow_router = build_flow_router(hbia, auth_dependency=require_auth)

Usage in individual endpoints::

    from infra.auth import get_current_user

    @app.get("/me")
    async def me(user: dict = Depends(get_current_user)):
        return user
"""

from __future__ import annotations

from typing import Any

from settings import (
    KEYCLOAK_URL,
    KEYCLOAK_REALM,
    KEYCLOAK_CLIENT_ID,
    JWT_ALGORITHM,
    JWT_AUDIENCE,
)


def _keycloak_configured() -> bool:
    """Check if Keycloak settings are filled in."""
    return bool(KEYCLOAK_URL and KEYCLOAK_REALM and KEYCLOAK_CLIENT_ID)


# The actual implementation requires `python-jose` and `httpx`.
# Install with: pip install python-jose[cryptography] httpx
#
# Below is the boilerplate — uncomment and adapt when ready.

# ──────────────────────────────────────────────────────────────────
# Production implementation (uncomment when Keycloak is set up):
# ──────────────────────────────────────────────────────────────────
#
# import httpx
# from fastapi import Depends, HTTPException, status
# from fastapi.security import HTTPBearer, HTTPAuthorizationCredentials
# from jose import JWTError, jwt
#
# _bearer = HTTPBearer()
# _jwks_cache: dict[str, Any] = {}
#
#
# async def _get_jwks() -> dict[str, Any]:
#     """Fetch Keycloak JWKS (cached after first call)."""
#     if not _jwks_cache:
#         url = (
#             f"{KEYCLOAK_URL}/realms/{KEYCLOAK_REALM}"
#             f"/protocol/openid-connect/certs"
#         )
#         async with httpx.AsyncClient() as client:
#             resp = await client.get(url)
#             resp.raise_for_status()
#             _jwks_cache.update(resp.json())
#     return _jwks_cache
#
#
# async def get_current_user(
#     creds: HTTPAuthorizationCredentials = Depends(_bearer),
# ) -> dict[str, Any]:
#     """Decode and validate a Keycloak JWT token.
#
#     Returns the token payload (sub, email, roles, etc.).
#     """
#     token = creds.credentials
#     try:
#         jwks = await _get_jwks()
#         payload = jwt.decode(
#             token,
#             jwks,
#             algorithms=[JWT_ALGORITHM],
#             audience=JWT_AUDIENCE or KEYCLOAK_CLIENT_ID,
#         )
#         return payload
#     except JWTError as exc:
#         raise HTTPException(
#             status_code=status.HTTP_401_UNAUTHORIZED,
#             detail=f"Invalid token: {exc}",
#             headers={"WWW-Authenticate": "Bearer"},
#         )
#
#
# async def require_auth(
#     user: dict = Depends(get_current_user),
# ) -> dict[str, Any]:
#     """FastAPI dependency: require valid authentication.
#
#     Use as ``auth_dependency`` in ``build_flow_router``::
#
#         flow_router = build_flow_router(hbia, auth_dependency=require_auth)
#     """
#     return user
'''

_FASTAPI_REQUIREMENTS_TPL = '''\
honey-badgeria[fastapi,dev]
uvicorn[standard]
python-dotenv
'''

# ======================================================================
# Monorepo templates
# ======================================================================

_MONOREPO_ROOT_YAML_TPL = '''\
# HBIA Monorepo Configuration
# This project uses the Honey Badgeria AI-native architecture.
#
# Structure:
#   back/   — Python backend (HBIA DAG execution)
#   front/  — Next.js frontend (HBIA reactive graphs)
#
# Both sides follow HBIA principles:
#   - YAML definitions represent architecture
#   - Implementation files follow the graph contracts
#   - AI agents explore YAML first, code second

project: my_hbia_project
mode: monorepo

back:
  root: back/
  graph_file: back/flows/example_flow.yaml
  handler_modules:
    - back.vertices

front:
  root: front/
  graph_dir: front/graph/
  runtime_dir: front/hbia-runtime/

features:
  backend_proxy: false  # Set to true to proxy API calls through Next.js
'''

_MONOREPO_README_TPL = '''\
# My HBIA Project

> Full-stack AI-native application built with Honey Badgeria.

## Architecture

```
back/     — Python backend (FastAPI + HBIA DAG execution)
front/    — Next.js frontend (HBIA reactive graph system)
```

Both follow the same core principle:

> YAML definitions represent architecture.
> Code files represent implementation.
> AI agents read YAML first.

## Quick Start

### Backend

```bash
cd back
pip install fastapi uvicorn
pip install honey-badgeria[dev]
python manage.py
```

### Frontend

```bash
cd front
npm install
npm run dev
```

### Generate Frontend Runtime

```bash
cd front
hbia ui-codegen graph/ --output hbia-runtime
```

## HBIA Frontend Rules

1. Components never own state.
2. All state belongs to State Nodes.
3. All side effects must be declared as Effects.
4. All user actions must be Events.
5. UI components must remain pure.
6. Backend access only through Services.
7. All state mutations must be explicit.

## AI Navigation

1. Start with `hbia.yaml` (root config)
2. Backend: read `back/flows/` YAML files
3. Frontend: read `front/graph/` domain directories
4. Open implementation files only when needed
'''

# ── Frontend config ───────────────────────────────────────────────

_FRONT_HBIA_YAML_TPL = '''\
# HBIA Frontend Configuration
# This file configures the frontend reactive graph system.

mode: frontend
framework: nextjs

graph_dir: graph/
runtime_dir: hbia-runtime/

# Feature flags
features:
  backend_proxy: false
  strict_mode: true

# Domain list (auto-discovered from graph/ subdirectories)
domains:
  - counter
'''

# ── Next.js / TypeScript config ───────────────────────────────────

_FRONT_PACKAGE_JSON_TPL = '''\
{
  "name": "hbia-frontend",
  "version": "0.1.0",
  "private": true,
  "scripts": {
    "dev": "next dev",
    "build": "next build",
    "start": "next start",
    "lint": "next lint",
    "hbia:codegen": "cd .. && hbia ui-codegen front/graph/ --output front/hbia-runtime",
    "hbia:validate": "cd .. && hbia ui-validate front/graph/",
    "hbia:lint": "cd .. && hbia ui-lint front/graph/"
  },
  "dependencies": {
    "next": "^14.0.0",
    "react": "^18.2.0",
    "react-dom": "^18.2.0"
  },
  "devDependencies": {
    "@types/node": "^20.0.0",
    "@types/react": "^18.2.0",
    "@types/react-dom": "^18.2.0",
    "autoprefixer": "^10.4.0",
    "postcss": "^8.4.0",
    "tailwindcss": "^3.4.0",
    "typescript": "^5.0.0"
  }
}
'''

_FRONT_TSCONFIG_TPL = '''\
{
  "compilerOptions": {
    "target": "es5",
    "lib": ["dom", "dom.iterable", "esnext"],
    "allowJs": true,
    "skipLibCheck": true,
    "strict": true,
    "noEmit": true,
    "esModuleInterop": true,
    "module": "esnext",
    "moduleResolution": "bundler",
    "resolveJsonModule": true,
    "isolatedModules": true,
    "jsx": "preserve",
    "incremental": true,
    "plugins": [{ "name": "next" }],
    "paths": {
      "@/*": ["./*"],
      "@/hbia": ["./hbia-runtime/*"],
      "@/graph": ["./graph/*"],
      "@/primitives": ["./primitives/*"],
      "@/services": ["./services/*"]
    }
  },
  "include": ["next-env.d.ts", "**/*.ts", "**/*.tsx"],
  "exclude": ["node_modules"]
}
'''

_FRONT_NEXT_CONFIG_TPL = '''\
import type { NextConfig } from "next"

const nextConfig: NextConfig = {
  // HBIA: All rendering is client-side by default.
  // Backend proxy can be enabled via rewrites.
}

export default nextConfig
'''

_FRONT_TAILWIND_CONFIG_TPL = '''\
import type { Config } from "tailwindcss"

const config: Config = {
  content: [
    "./app/**/*.{js,ts,jsx,tsx,mdx}",
    "./graph/**/*.{js,ts,jsx,tsx,mdx}",
    "./primitives/**/*.{js,ts,jsx,tsx,mdx}",
  ],
  theme: {
    extend: {},
  },
  plugins: [],
}

export default config
'''

_FRONT_POSTCSS_CONFIG_TPL = '''\
module.exports = {
  plugins: {
    tailwindcss: {},
    autoprefixer: {},
  },
}
'''

# ── App directory ─────────────────────────────────────────────────

_FRONT_LAYOUT_TPL = '''\
import type { Metadata } from "next"
import "./globals.css"

export const metadata: Metadata = {
  title: "HBIA App",
  description: "Built with Honey Badgeria AI-native architecture",
}

export default function RootLayout({
  children,
}: {
  children: React.ReactNode
}) {
  return (
    <html lang="en">
      <body>{children}</body>
    </html>
  )
}
'''

_FRONT_PAGE_TPL = '''\
"use client"

// HBIA: This page imports the graph-defined view component.
// The page file is minimal — all logic lives in the graph.
import { CounterPageView } from "@/graph/counter/ui/CounterPage/counter_page_view"

export default function Home() {
  return (
    <main className="min-h-screen flex items-center justify-center">
      <CounterPageView />
    </main>
  )
}
'''

_FRONT_GLOBALS_CSS_TPL = '''\
@tailwind base;
@tailwind components;
@tailwind utilities;
'''

# ── Example graph domain: counter ─────────────────────────────────

_FRONT_UI_NODE_YAML_TPL = '''\
# UI Node: CounterPage
# This is the root component for the counter domain.
# It reads counter state and emits increment/decrement events.

component: CounterPage

view: counter_page_view

reads:
  - CounterState.count

events:
  on_increment: increment
  on_decrement: decrement

children: []
'''

_FRONT_UI_VIEW_TPL = '''\
"use client"

// HBIA UI View: CounterPage
// This is a PURE render function.
// It receives data from state and emits events.
// NO useState, NO useEffect, NO direct API calls.

import { useHBIA } from "@/hbia-runtime"

interface CounterPageViewProps {
  // Props are injected by the HBIA runtime
}

export function CounterPageView(_props: CounterPageViewProps) {
  // Read state through HBIA hooks
  const count = useHBIA((s) => s.CounterState.count)

  return (
    <div className="text-center space-y-4">
      <h1 className="text-4xl font-bold">HBIA Counter</h1>
      <p className="text-6xl font-mono">{count}</p>
      <div className="space-x-2">
        <button
          className="px-4 py-2 bg-blue-500 text-white rounded hover:bg-blue-600"
          onClick={() => {
            // Events are dispatched through the HBIA event system
            // import { increment } from "@/hbia-runtime"
            // increment()
          }}
        >
          +
        </button>
        <button
          className="px-4 py-2 bg-red-500 text-white rounded hover:bg-red-600"
          onClick={() => {
            // decrement()
          }}
        >
          -
        </button>
      </div>
      <p className="text-sm text-gray-500">
        Powered by HBIA — AI-native reactive architecture
      </p>
    </div>
  )
}
'''

_FRONT_STATE_YAML_TPL = '''\
# State Node: CounterState
# Owns the counter value. All mutations are declared here.

state: CounterState

interface: CounterStateData

fields:
  count: number

mutations:
  - set_count
  - increment_count
  - decrement_count
  - reset_count

triggers:
  - log_count

initial:
  count: "0"
'''

_FRONT_STATE_INTERFACE_TPL = '''\
// TypeScript interface for CounterState
// This is the contract — must match state.yaml fields.

export interface CounterStateData {
  count: number
}
'''

_FRONT_STATE_MUTATIONS_TPL = '''\
// Mutations for CounterState
// Each function corresponds to a declared mutation in state.yaml.

import type { CounterStateData } from "./interface"

export function set_count(state: CounterStateData, value: number): CounterStateData {
  return { ...state, count: value }
}

export function increment_count(state: CounterStateData): CounterStateData {
  return { ...state, count: state.count + 1 }
}

export function decrement_count(state: CounterStateData): CounterStateData {
  return { ...state, count: state.count - 1 }
}

export function reset_count(_state: CounterStateData): CounterStateData {
  return { count: 0 }
}
'''

_FRONT_EFFECT_YAML_TPL = '''\
# Effect: log_count
# Triggered when CounterState.count changes.
# Logs the new count value (example side effect).

effect: log_count

watch:
  - CounterState.count

handler: log_count_handler

effect_type: side_effect

mutates: []
'''

_FRONT_EFFECT_HANDLER_TPL = '''\
// Effect handler: log_count
// Triggered when CounterState.count changes.

export async function log_count_handler(
  state: { CounterState: { count: number } },
  _services: Record<string, unknown>
): Promise<void> {
  console.log(`[HBIA Effect] Counter changed to: ${state.CounterState.count}`)
}
'''

_FRONT_EVENT_INCREMENT_TPL = '''\
# Event: increment
# Triggered by the + button in CounterPage.
# Executes the increment_count mutation on CounterState.

event: increment

flow:
  - CounterState.increment_count

source: CounterPage
'''

_FRONT_EVENT_DECREMENT_TPL = '''\
# Event: decrement
# Triggered by the - button in CounterPage.
# Executes the decrement_count mutation on CounterState.

event: decrement

flow:
  - CounterState.decrement_count

source: CounterPage
'''

# ── Primitives ────────────────────────────────────────────────────

_FRONT_BUTTON_PRIMITIVE_TPL = '''\
interface ButtonProps {
  children: React.ReactNode
  onClick?: () => void
  variant?: "primary" | "secondary" | "danger" | "ghost"
  size?: "sm" | "md" | "lg"
  disabled?: boolean
  loading?: boolean
  className?: string
}

export function Button({
  children,
  onClick,
  variant = "primary",
  size = "md",
  disabled = false,
  loading = false,
  className = "",
}: ButtonProps) {
  const base =
    "inline-flex items-center justify-center font-semibold " +
    "rounded-2xl transition-all duration-200 active:scale-[0.97] " +
    "disabled:opacity-40 disabled:pointer-events-none select-none"

  const sizes = {
    sm: "px-3 py-1.5 text-sm",
    md: "px-5 py-2.5 text-base",
    lg: "px-8 py-3.5 text-lg",
  }

  const variants = {
    primary:
      "bg-[#0066FF] text-white shadow-lg shadow-blue-500/25 " +
      "hover:bg-[#0055DD] hover:shadow-blue-500/40",
    secondary:
      "bg-white/10 text-white backdrop-blur-xl border border-white/20 " +
      "hover:bg-white/20",
    danger:
      "bg-[#FF3B30] text-white shadow-lg shadow-red-500/25 " +
      "hover:bg-[#E0352B] hover:shadow-red-500/40",
    ghost:
      "bg-transparent text-white/70 hover:text-white hover:bg-white/5",
  }

  return (
    <button
      onClick={onClick}
      disabled={disabled || loading}
      className={`${base} ${sizes[size]} ${variants[variant]} ${className}`}
    >
      {loading ? (
        <span className="mr-2 inline-block w-4 h-4 border-2 border-current border-t-transparent rounded-full animate-spin" />
      ) : null}
      {children}
    </button>
  )
}
'''

_FRONT_CARD_PRIMITIVE_TPL = '''\
interface CardProps {
  children: React.ReactNode
  className?: string
  onClick?: () => void
  hoverable?: boolean
}

export function Card({
  children,
  className = "",
  onClick,
  hoverable = false,
}: CardProps) {
  return (
    <div
      onClick={onClick}
      className={
        "rounded-3xl bg-white/5 backdrop-blur-2xl " +
        "border border-white/[0.08] " +
        "shadow-[0_8px_32px_rgba(0,0,0,0.4)] " +
        "p-6 " +
        (hoverable
          ? "transition-all duration-300 cursor-pointer " +
            "hover:bg-white/10 hover:border-white/[0.15] " +
            "hover:shadow-[0_12px_40px_rgba(0,0,0,0.5)] " +
            "hover:-translate-y-0.5 "
          : "") +
        className
      }
    >
      {children}
    </div>
  )
}
'''

_FRONT_INPUT_PRIMITIVE_TPL = '''\
interface InputProps {
  label?: string
  placeholder?: string
  value?: string
  onChange?: (value: string) => void
  type?: "text" | "email" | "password" | "number" | "search"
  error?: string
  disabled?: boolean
  className?: string
}

export function Input({
  label,
  placeholder,
  value,
  onChange,
  type = "text",
  error,
  disabled = false,
  className = "",
}: InputProps) {
  return (
    <div className={`flex flex-col gap-1.5 ${className}`}>
      {label && (
        <label className="text-sm font-medium text-white/60 tracking-wide uppercase">
          {label}
        </label>
      )}
      <input
        type={type}
        placeholder={placeholder}
        value={value}
        disabled={disabled}
        onChange={(e) => onChange?.(e.target.value)}
        className={
          "w-full px-4 py-3 rounded-2xl bg-white/5 " +
          "border border-white/[0.08] text-white placeholder-white/30 " +
          "backdrop-blur-xl " +
          "outline-none transition-all duration-200 " +
          "focus:border-[#0066FF]/50 focus:bg-white/[0.08] " +
          "focus:shadow-[0_0_0_3px_rgba(0,102,255,0.15)] " +
          "disabled:opacity-40 disabled:cursor-not-allowed " +
          (error ? "border-[#FF3B30]/50 " : "")
        }
      />
      {error && (
        <span className="text-xs text-[#FF3B30] font-medium">{error}</span>
      )}
    </div>
  )
}
'''

_FRONT_MODAL_PRIMITIVE_TPL = '''\
interface ModalProps {
  open: boolean
  onClose: () => void
  title?: string
  children: React.ReactNode
  className?: string
}

export function Modal({
  open,
  onClose,
  title,
  children,
  className = "",
}: ModalProps) {
  if (!open) return null

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center">
      <div
        className="absolute inset-0 bg-black/60 backdrop-blur-sm"
        onClick={onClose}
      />
      <div
        className={
          "relative max-w-lg w-full mx-4 rounded-3xl " +
          "bg-[#1C1C1E]/90 backdrop-blur-3xl " +
          "border border-white/[0.1] " +
          "shadow-[0_24px_80px_rgba(0,0,0,0.7)] " +
          "p-8 " +
          "animate-[modal-in_0.3s_cubic-bezier(0.16,1,0.3,1)] " +
          className
        }
      >
        {title && (
          <h2 className="text-xl font-bold text-white mb-6 tracking-tight">
            {title}
          </h2>
        )}
        {children}
      </div>
    </div>
  )
}
'''

_FRONT_BADGE_PRIMITIVE_TPL = '''\
interface BadgeProps {
  children: React.ReactNode
  color?: "blue" | "green" | "red" | "orange" | "neutral"
  className?: string
}

export function Badge({
  children,
  color = "neutral",
  className = "",
}: BadgeProps) {
  const colors = {
    blue: "bg-[#0066FF]/15 text-[#4D9AFF] ring-[#0066FF]/20",
    green: "bg-[#34C759]/15 text-[#6EE090] ring-[#34C759]/20",
    red: "bg-[#FF3B30]/15 text-[#FF7B73] ring-[#FF3B30]/20",
    orange: "bg-[#FF9500]/15 text-[#FFB340] ring-[#FF9500]/20",
    neutral: "bg-white/10 text-white/70 ring-white/10",
  }

  return (
    <span
      className={
        "inline-flex items-center px-2.5 py-0.5 rounded-full " +
        "text-xs font-semibold tracking-wide ring-1 ring-inset " +
        colors[color] + " " +
        className
      }
    >
      {children}
    </span>
  )
}
'''

_FRONT_SPINNER_PRIMITIVE_TPL = '''\
interface SpinnerProps {
  size?: "sm" | "md" | "lg"
  className?: string
}

export function Spinner({ size = "md", className = "" }: SpinnerProps) {
  const sizes = {
    sm: "w-4 h-4 border-2",
    md: "w-8 h-8 border-[3px]",
    lg: "w-12 h-12 border-4",
  }

  return (
    <div
      className={
        `${sizes[size]} rounded-full ` +
        "border-white/20 border-t-[#0066FF] " +
        "animate-spin " +
        className
      }
    />
  )
}
'''

_FRONT_EMPTY_STATE_PRIMITIVE_TPL = '''\
interface EmptyStateProps {
  title: string
  description?: string
  action?: React.ReactNode
  className?: string
}

export function EmptyState({
  title,
  description,
  action,
  className = "",
}: EmptyStateProps) {
  return (
    <div
      className={
        "flex flex-col items-center justify-center py-16 px-8 " +
        "text-center " +
        className
      }
    >
      <div className="w-16 h-16 rounded-full bg-white/5 mb-6 flex items-center justify-center">
        <div className="w-6 h-6 rounded-full bg-white/10" />
      </div>
      <h3 className="text-lg font-semibold text-white/80 mb-2 tracking-tight">
        {title}
      </h3>
      {description && (
        <p className="text-sm text-white/40 max-w-sm mb-6">{description}</p>
      )}
      {action}
    </div>
  )
}
'''

# ── Services ──────────────────────────────────────────────────────

_FRONT_API_SERVICE_TPL = '''\
// HBIA Service: API
// Handles all backend communication.
// Effects interact with services. UI nodes never call services directly.
//
// IMPORTANT: All errors are wrapped in HBIAServiceError.
// NEVER expose raw errors, tracebacks, or server messages to the UI.
// Effect handlers receive { ok, data, error } — branch on `ok`.

const API_BASE = process.env.NEXT_PUBLIC_API_URL || "http://localhost:8000"

// ── HBIA Backend Response Envelope ───────────────────────────────
// All HBIA backend endpoints return this shape.
// The service layer unwraps it automatically.

interface HBIAResponse<T = unknown> {
  ok: boolean
  data?: T
  error?: { code: string; message: string }
  meta?: { total?: number; page?: number; page_size?: number; pages?: number }
}

// ── Error types ──────────────────────────────────────────────────
export class HBIAServiceError extends Error {
  status: number
  code: string
  userMessage: string

  constructor(status: number, userMessage: string, code = "UNKNOWN", debugMessage?: string) {
    super(debugMessage || userMessage)
    this.name = "HBIAServiceError"
    this.status = status
    this.code = code
    this.userMessage = userMessage
  }
}

export type ServiceResult<T> =
  | { ok: true; data: T; meta?: HBIAResponse["meta"] }
  | { ok: false; error: HBIAServiceError }

// ── Safe wrappers ────────────────────────────────────────────────
// These NEVER throw. They return { ok, data } or { ok, error }.
// Effect handlers should use these, not the raw methods.

function _userFriendlyMessage(status: number): string {
  if (status === 401) return "Please log in to continue."
  if (status === 403) return "You don\\\'t have permission for this action."
  if (status === 404) return "The requested resource was not found."
  if (status === 422) return "The submitted data is invalid."
  if (status >= 500) return "Something went wrong. Please try again later."
  return "An unexpected error occurred."
}

async function _safeFetch<T>(
  url: string,
  init?: RequestInit,
): Promise<ServiceResult<T>> {
  try {
    const response = await fetch(url, init)

    if (!response.ok) {
      let debugMsg = `${response.status} ${response.statusText}`
      let code = "HTTP_ERROR"
      try {
        const body = await response.json()
        if (body.error?.message) debugMsg = body.error.message
        if (body.error?.code) code = body.error.code
        if (body.detail) debugMsg = body.detail
      } catch {
        // response body not JSON
      }

      const err = new HBIAServiceError(
        response.status,
        _userFriendlyMessage(response.status),
        code,
        debugMsg,
      )

      if (process.env.NODE_ENV === "development") {
        console.error(`[HBIA Service] ${url}:`, debugMsg)
      }

      return { ok: false, error: err }
    }

    const body = await response.json()

    // Unwrap HBIA envelope if present
    if (typeof body === "object" && body !== null && "ok" in body) {
      const envelope = body as HBIAResponse<T>
      if (envelope.ok) {
        return { ok: true, data: envelope.data as T, meta: envelope.meta }
      }
      const err = new HBIAServiceError(
        response.status,
        envelope.error?.message || "Server error",
        envelope.error?.code || "SERVER_ERROR",
      )
      return { ok: false, error: err }
    }

    // Non-HBIA endpoint — return raw body
    return { ok: true, data: body as T }
  } catch (networkError) {
    const err = new HBIAServiceError(
      0,
      "Unable to connect to the server. Check your connection.",
      "NETWORK_ERROR",
      String(networkError),
    )
    if (process.env.NODE_ENV === "development") {
      console.error("[HBIA Service] Network error:", networkError)
    }
    return { ok: false, error: err }
  }
}

// ── Public API ───────────────────────────────────────────────────
export const apiService = {
  async get<T>(path: string): Promise<ServiceResult<T>> {
    return _safeFetch<T>(`${API_BASE}${path}`)
  },

  async post<T>(path: string, body: unknown): Promise<ServiceResult<T>> {
    return _safeFetch<T>(`${API_BASE}${path}`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(body),
    })
  },

  async put<T>(path: string, body: unknown): Promise<ServiceResult<T>> {
    return _safeFetch<T>(`${API_BASE}${path}`, {
      method: "PUT",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(body),
    })
  },

  async del<T>(path: string): Promise<ServiceResult<T>> {
    return _safeFetch<T>(`${API_BASE}${path}`, { method: "DELETE" })
  },
}

// ── CRUD Service Factory ─────────────────────────────────────────
// Creates a typed CRUD service for a resource.
// Usage in a service file:
//
//   import { createCrudService } from "./api"
//   export const itemsService = createCrudService<Item>("items")
//
// Usage in an effect handler:
//
//   const result = await itemsService.list()
//   if (result.ok) store.set_items({ items: result.data })

export function createCrudService<T>(resource: string) {
  const prefix = `/api/v1/${resource}`
  return {
    list(page = 1, pageSize = 20): Promise<ServiceResult<T[]>> {
      return apiService.get<T[]>(`${prefix}?page=${page}&page_size=${pageSize}`)
    },
    get(id: string): Promise<ServiceResult<T>> {
      return apiService.get<T>(`${prefix}/${id}`)
    },
    create(data: Partial<T>): Promise<ServiceResult<T>> {
      return apiService.post<T>(prefix, data)
    },
    update(id: string, data: Partial<T>): Promise<ServiceResult<T>> {
      return apiService.put<T>(`${prefix}/${id}`, data)
    },
    remove(id: string): Promise<ServiceResult<T>> {
      return apiService.del<T>(`${prefix}/${id}`)
    },
  }
}
'''
