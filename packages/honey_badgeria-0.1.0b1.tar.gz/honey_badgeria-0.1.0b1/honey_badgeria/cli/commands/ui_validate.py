"""CLI command: ui-validate — validate frontend YAML definitions.

Usage:
    hbia ui-validate graph/dashboard
    hbia ui-validate graph/
"""

from __future__ import annotations


def register(app):
    """Register the ui-validate command with a Typer app."""
    import typer

    @app.command("ui-validate")
    def ui_validate(
        graph_path: str = typer.Argument(
            "graph", help="Path to graph/ directory or a single domain."
        ),
    ):
        """Validate frontend YAML definitions for structural correctness.

        Checks all four graph types and cross-graph references:
          - UI reads → valid state fields
          - Events → valid state mutations
          - Effects → valid state watches
          - All references resolve correctly
        """
        import os

        from honey_badgeria.front.dsl.parser import (
            parse_domain_directory,
            parse_graph_directory,
        )
        from honey_badgeria.front.dsl.validator import FrontendDSLValidator

        try:
            if os.path.isdir(os.path.join(graph_path, "ui")) or \
               os.path.isdir(os.path.join(graph_path, "state")):
                schemas = [parse_domain_directory(graph_path)]
            else:
                schemas = parse_graph_directory(graph_path)
        except Exception as exc:
            typer.echo(f"✘ Failed to parse: {exc}", err=True)
            raise typer.Exit(1)

        validator = FrontendDSLValidator()
        total_errors = 0

        for schema in schemas:
            errors = validator.validate(schema)
            if errors:
                typer.echo(f"--- Domain: {schema.name} ---")
                for error in errors:
                    typer.echo(f"  ✘ {error}")
                total_errors += len(errors)

        if total_errors == 0:
            typer.echo("✔ All frontend definitions are valid.")
        else:
            typer.echo(f"\n{total_errors} validation error(s) found.")
            raise typer.Exit(1)
