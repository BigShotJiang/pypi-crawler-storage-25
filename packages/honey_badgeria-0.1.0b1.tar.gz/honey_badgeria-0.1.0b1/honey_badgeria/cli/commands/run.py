"""CLI command: run - execute a graph/flow."""

import sys


def register(app):
    """Register the run command with a Typer app."""
    import typer

    @app.command("run")
    def run(
        graph: str = typer.Argument(..., help="Path to graph YAML file."),
        flow: str = typer.Option(None, "--flow", "-f", help="Flow name to execute."),
        data: str = typer.Option(None, "--data", "-d", help="JSON string of initial data."),
        handler_module: str = typer.Option(
            None, "--handlers", "-m",
            help="Dotted path to a Python module with handler functions.",
        ),
        cache: bool = typer.Option(False, "--cache/--no-cache", help="Enable/disable caching."),
        parallel: bool = typer.Option(False, "--parallel/--no-parallel", help="Enable/disable parallel execution."),
    ):
        """Execute a graph or a specific flow inside it."""
        import json
        from honey_badgeria.back.dsl.loader import load_graph_from_yaml
        from honey_badgeria.back.runtime.runner import run_flow
        from honey_badgeria.back.registry.handler_resolver import HandlerResolver

        try:
            g = load_graph_from_yaml(graph)
        except Exception as e:
            typer.echo(f"✘ Failed to load graph: {e}", err=True)
            raise typer.Exit(1)

        # --- handler resolution ---
        resolver = None
        if handler_module:
            import importlib
            try:
                mod = importlib.import_module(handler_module)
            except ImportError as e:
                typer.echo(f"✘ Cannot import handler module: {e}", err=True)
                raise typer.Exit(1)
            hr = HandlerResolver()
            resolver = hr.resolve

        # --- initial data ---
        initial = None
        if data:
            try:
                initial = json.loads(data)
            except json.JSONDecodeError as e:
                typer.echo(f"✘ Invalid JSON data: {e}", err=True)
                raise typer.Exit(1)

        # --- execute ---
        try:
            result = run_flow(
                g,
                flow_name=flow,
                handlers=resolver,
                initial_data=initial,
                cache_enabled=cache,
                parallel_enabled=parallel,
            )
            typer.echo(json.dumps(result, indent=2, default=str))
        except Exception as e:
            typer.echo(f"✘ Execution failed: {e}", err=True)
            raise typer.Exit(1)
