"""CLI command: ui-graph — visualize frontend graph relationships.

Usage:
    hbia ui-graph graph/dashboard
    hbia ui-graph graph/dashboard --type state
    hbia ui-graph graph/dashboard --type effect
    hbia ui-graph graph/dashboard --chain apply_filters
"""

from __future__ import annotations


def register(app):
    """Register the ui-graph command with a Typer app."""
    import typer

    @app.command("ui-graph")
    def ui_graph(
        domain_path: str = typer.Argument(
            ..., help="Path to the domain directory."
        ),
        graph_type: str = typer.Option(
            "all", "--type", "-t",
            help="Graph type: all, ui, state, effect, event."
        ),
        chain: str = typer.Option(
            None, "--chain", help="Show full reactive chain for an event."
        ),
    ):
        """Visualize frontend graph relationships (ASCII).

        Shows the component hierarchy, state dependencies,
        effect triggers, or event flows as ASCII diagrams.
        """
        import json

        from honey_badgeria.front.dsl.loader import load_frontend_domain

        try:
            domain = load_frontend_domain(domain_path, validate=True)
        except Exception as exc:
            typer.echo(f"✘ Failed to load domain: {exc}", err=True)
            raise typer.Exit(1)

        if chain:
            data = domain.full_event_chain(chain)
            typer.echo(f"=== Reactive Chain: {chain} ===")
            typer.echo(json.dumps(data, indent=2))
            return

        _print_graph(typer, domain, graph_type)


def _print_graph(typer, domain, graph_type):
    """Print ASCII representation of selected graph."""

    if graph_type in ("all", "ui"):
        typer.echo("=== UI Graph ===")
        root = domain.ui_graph.root
        if root:
            _print_tree(typer, domain.ui_graph, root, "")
        else:
            for name in domain.ui_graph.nodes:
                typer.echo(f"  {name}")
        typer.echo("")

    if graph_type in ("all", "state"):
        typer.echo("=== State Graph ===")
        for name, node in domain.state_graph.nodes.items():
            fields = ", ".join(f"{k}: {v}" for k, v in node.fields.items())
            typer.echo(f"  [{name}] {{ {fields} }}")
            if node.mutations:
                typer.echo(f"    mutations: {node.mutations}")
            if node.triggers:
                typer.echo(f"    → triggers: {node.triggers}")
        typer.echo("")

    if graph_type in ("all", "effect"):
        typer.echo("=== Effect Graph ===")
        for name, node in domain.effect_graph.nodes.items():
            typer.echo(f"  [{name}] ({node.effect_type})")
            typer.echo(f"    watches: {node.watch}")
            if node.mutates:
                typer.echo(f"    → mutates: {node.mutates}")
        typer.echo("")

    if graph_type in ("all", "event"):
        typer.echo("=== Event Graph ===")
        for name, node in domain.event_graph.nodes.items():
            flow_str = " → ".join(node.flow)
            typer.echo(f"  [{name}] {flow_str}")
            if node.source:
                typer.echo(f"    source: {node.source}")
        typer.echo("")


def _print_tree(typer, ui_graph, name, indent):
    """Recursively print a component tree."""
    node = ui_graph.nodes.get(name)
    if node is None:
        return
    label = f"{name} (view: {node.view})"
    if node.reads:
        label += f" ← {node.reads}"
    typer.echo(f"{indent}├── {label}")
    for child in node.children:
        _print_tree(typer, ui_graph, child, indent + "│   ")
