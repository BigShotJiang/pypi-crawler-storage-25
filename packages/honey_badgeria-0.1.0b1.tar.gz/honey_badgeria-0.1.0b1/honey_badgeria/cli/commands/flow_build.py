"""CLI command: flow-build - auto-discover and build a flow graph."""


def register(app):
    """Register the flow-build command with a Typer app."""
    import typer

    @app.command("flow-build")
    def flow_build(
        module: str = typer.Argument(
            ..., help="Dotted path to module(s) with vertex handlers.",
        ),
        output: str = typer.Option("graph.yaml", "--output", "-o", help="Output YAML file."),
    ):
        """Auto-discover vertex handlers in a module and generate a graph."""
        from honey_badgeria.back.discovery.autodiscover import GraphAutoDiscover
        from honey_badgeria.back.discovery.flow_graph_writer import FlowGraphWriter

        discoverer = GraphAutoDiscover(handler_modules=[module])
        try:
            graph_dict = discoverer.run()
        except Exception as e:
            typer.echo(f"✘ Discovery failed: {e}", err=True)
            raise typer.Exit(1)

        flow_data = graph_dict.get("flow", {})
        vertex_count = sum(
            len(fd) for fd in flow_data.values() if isinstance(fd, dict)
        )
        if vertex_count == 0:
            typer.echo("✘ No vertices discovered.", err=True)
            raise typer.Exit(1)

        writer = FlowGraphWriter()
        writer.save(graph_dict, output)
        typer.echo(f"✔ Built graph with {vertex_count} vertices → {output}")
