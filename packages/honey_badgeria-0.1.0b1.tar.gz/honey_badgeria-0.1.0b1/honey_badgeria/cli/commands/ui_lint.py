"""CLI command: ui-lint — lint frontend graph definitions.

Usage:
    hbia ui-lint graph/dashboard
    hbia ui-lint graph/
"""

from __future__ import annotations


def register(app):
    """Register the ui-lint command with a Typer app."""
    import typer

    @app.command("ui-lint")
    def ui_lint(
        graph_path: str = typer.Argument(
            "graph", help="Path to graph/ directory or a single domain."
        ),
    ):
        """Lint frontend graph definitions for quality issues.

        Checks for:
          - localStorage/sessionStorage usage (FORBIDDEN — error)
          - Unused state nodes
          - Dead events (not emitted by any UI component)
          - Orphaned effects
          - Overly broad state (too many fields)
          - Missing TypeScript interfaces
          - Circular effect chains
          - Naming convention violations
        """
        import os

        from honey_badgeria.front.dsl.loader import (
            load_frontend_domain,
            load_all_frontend_domains,
        )
        from honey_badgeria.front.lint import FrontendLinter

        try:
            if os.path.isdir(os.path.join(graph_path, "ui")) or \
               os.path.isdir(os.path.join(graph_path, "state")):
                domains = [load_frontend_domain(graph_path, validate=False)]
            else:
                domains = load_all_frontend_domains(graph_path, validate=False)
        except Exception as exc:
            typer.echo(f"✘ Failed to load domains: {exc}", err=True)
            raise typer.Exit(1)

        linter = FrontendLinter()
        total_issues = 0
        has_errors = False

        # YAML-level checks (graph quality)
        for domain in domains:
            issues = linter.lint(domain)
            if issues:
                typer.echo(f"--- Domain: {domain.name} ---")
                for issue in issues:
                    icon = {"error": "✘", "warning": "⚠", "info": "ℹ"}.get(
                        issue.severity, "?"
                    )
                    typer.echo(
                        f"  {icon} [{issue.category}] {issue.message}"
                    )
                    if issue.severity == "error":
                        has_errors = True
                total_issues += len(issues)

        # File-level checks (scan .ts/.tsx for forbidden patterns)
        file_issues = linter.lint_files(graph_path)

        # Also scan parent directories for services/, primitives/ etc.
        parent = os.path.dirname(os.path.abspath(graph_path))
        for sibling in ("services", "primitives", "app"):
            sibling_path = os.path.join(parent, sibling)
            if os.path.isdir(sibling_path):
                file_issues.extend(linter.lint_files(sibling_path))

        if file_issues:
            typer.echo(f"\n--- File-level checks ---")
            for issue in file_issues:
                icon = {"error": "✘", "warning": "⚠", "info": "ℹ"}.get(
                    issue.severity, "?"
                )
                typer.echo(f"  {icon} [{issue.category}] {issue.message}")
                if issue.severity == "error":
                    has_errors = True
            total_issues += len(file_issues)

        if total_issues == 0:
            typer.echo("✔ No lint issues found.")
        else:
            typer.echo(f"\n{total_issues} issue(s) found.")

        if has_errors:
            raise typer.Exit(1)
