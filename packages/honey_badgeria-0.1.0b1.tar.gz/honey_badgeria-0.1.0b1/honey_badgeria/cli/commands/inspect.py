"""CLI command: inspect - inspect graph topology."""


def register(app):
    """Register the inspect command with a Typer app."""
    import typer

    @app.command("inspect")
    def inspect_cmd(
        graph: str = typer.Argument(..., help="Path to graph YAML file."),
        json_out: bool = typer.Option(False, "--json", help="Output as JSON."),
    ):
        """Inspect graph topology: vertices, edges, sources, sinks, stages."""
        from honey_badgeria.back.dsl.loader import load_graph_from_yaml
        from honey_badgeria.back.topology import GraphTopology

        try:
            g = load_graph_from_yaml(graph)
        except Exception as e:
            typer.echo(f"✘ Failed to load graph: {e}", err=True)
            raise typer.Exit(1)

        topo = GraphTopology(g)

        if json_out:
            import json as _json
            info = {
                "vertices": list(g.vertices.keys()),
                "edges": [{"from": e.source, "to": e.target} for e in g.edges],
                "sources": topo.sources(),
                "sinks": topo.sinks(),
                "stages": [
                    [v.name for v in stage]
                    for stage in topo.execution_stages()
                ],
            }
            typer.echo(_json.dumps(info, indent=2))
        else:
            typer.echo(f"Vertices: {len(g.vertices)}")
            typer.echo(f"Edges:    {len(g.edges)}")
            typer.echo(f"Sources:  {topo.sources()}")
            typer.echo(f"Sinks:    {topo.sinks()}")
            stages = topo.execution_stages()
            for i, stage in enumerate(stages):
                names = [v.name for v in stage]
                typer.echo(f"Stage {i}: {names}")
