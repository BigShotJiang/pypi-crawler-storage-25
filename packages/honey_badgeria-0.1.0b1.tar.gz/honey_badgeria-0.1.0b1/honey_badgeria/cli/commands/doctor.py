"""CLI command: doctor - check project health and dependencies."""

import sys


def register(app):
    """Register the doctor command with a Typer app."""
    import typer

    @app.command("doctor")
    def doctor():
        """Check project health: Python version, dependencies, settings."""
        from honey_badgeria import __version__
        from honey_badgeria.conf.settings import get_settings

        typer.echo(f"Honey Badgeria v{__version__}")
        typer.echo(f"Python {sys.version}")
        typer.echo("")

        # --- optional dependencies ---
        deps = {
            "pyyaml": "yaml",
            "typer": "typer",
            "graphviz": "graphviz",
            "fastapi": "fastapi",
            "httpx": "httpx",
        }

        typer.echo("Optional dependencies:")
        for name, module in deps.items():
            try:
                __import__(module)
                typer.echo(f"  ✔ {name}")
            except ImportError:
                typer.echo(f"  ✘ {name} (not installed)")

        typer.echo("")

        # --- settings ---
        s = get_settings()
        typer.echo("Settings:")
        for key, value in s.to_dict().items():
            typer.echo(f"  {key}: {value}")

        typer.echo("")
        typer.echo("✔ Doctor check complete.")
