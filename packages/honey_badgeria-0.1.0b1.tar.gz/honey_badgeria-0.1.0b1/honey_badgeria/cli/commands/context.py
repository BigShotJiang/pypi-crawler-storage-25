"""CLI command: context - output or write AI context files.

This command gives AI coding assistants full knowledge of the Honey Badgeria
framework by writing well-known context files into the project directory.

Supported targets (auto-detected by AI tools):

    AGENTS.md                          - multi-agent convention
    .github/copilot-instructions.md    - GitHub Copilot
    .cursor/rules/honey-badgeria.mdc   - Cursor
    CLAUDE.md                          - Claude Code
"""

import os


def register(app):
    """Register the context command with a Typer app."""
    import typer

    @app.command("context")
    def context_cmd(
        write: bool = typer.Option(
            False, "--write", "-w",
            help="Write AI context files into the current project directory.",
        ),
        target: str = typer.Option(
            "all",
            "--target", "-t",
            help="Which file(s) to write: all, agents, copilot, cursor, claude.",
        ),
        out_dir: str = typer.Option(
            ".",
            "--dir", "-d",
            help="Project root directory to write files into.",
        ),
        show: bool = typer.Option(
            False, "--show", "-s",
            help="Print the full context document to stdout.",
        ),
        mode: str = typer.Option(
            "back",
            "--mode", "-m",
            help="Context mode: back, front, or monorepo.",
        ),
    ):
        """Generate AI context files so coding assistants understand HBIA.

        By default prints a summary.  Use --write to create the files or
        --show to print the full document to stdout.

        Modes:
          back      Backend only (default).
          front     Frontend only.
          monorepo  Both platforms with symbiosis rules.
        """
        from honey_badgeria.context import generate_context, KNOWN_TARGETS

        if mode not in ("back", "front", "monorepo"):
            typer.echo(f"Unknown mode: {mode}. Choose from: back, front, monorepo")
            raise typer.Exit(code=1)

        document = generate_context(mode=mode)

        # --show: dump to stdout
        if show:
            typer.echo(document)
            return

        # --write: write files
        if write:
            targets = _resolve_targets(target, KNOWN_TARGETS)
            written = []
            for key, relpath in targets.items():
                fullpath = os.path.join(out_dir, relpath)
                _ensure_parent(fullpath)
                with open(fullpath, "w") as f:
                    f.write(document)
                written.append(relpath)
                typer.echo(f"  ✔ {relpath}")

            typer.echo(f"\n✔ Wrote {len(written)} AI context file(s).")
            typer.echo("  AI assistants will auto-read these when they open your project.")
            return

        # default: summary
        typer.echo("Honey Badgeria AI Context")
        typer.echo("=" * 40)
        typer.echo("")
        typer.echo("This command generates context files that give AI coding")
        typer.echo("assistants (Copilot, Cursor, Claude, etc.) full knowledge")
        typer.echo("of the Honey Badgeria framework.")
        typer.echo("")
        typer.echo("Target files:")
        for key, relpath in KNOWN_TARGETS.items():
            typer.echo(f"  {key:8s} → {relpath}")
        typer.echo("")
        typer.echo("Usage:")
        typer.echo("  hbia context --write          # write all context files")
        typer.echo("  hbia context --write -t copilot  # write only Copilot file")
        typer.echo("  hbia context --show           # print full document to stdout")
        typer.echo(f"\nDocument size: {len(document):,} characters")


def _resolve_targets(target, known):
    """Return the subset of KNOWN_TARGETS matching *target*."""
    if target == "all":
        return dict(known)
    if target in known:
        return {target: known[target]}
    raise SystemExit(f"Unknown target: {target}. Choose from: all, {', '.join(known)}")


def _ensure_parent(path):
    """Create parent directories if needed."""
    parent = os.path.dirname(path)
    if parent:
        os.makedirs(parent, exist_ok=True)
