"""CLI command: viz - visualize one or more flow graphs."""

from __future__ import annotations

import os
import pathlib
from typing import Optional


def _yaml_files_from(sources: list[str]) -> list[pathlib.Path]:
    """Expand *sources* (files, directories, or globs) into YAML paths."""
    import glob as _glob

    result: list[pathlib.Path] = []
    for src in sources:
        p = pathlib.Path(src)
        if p.is_dir():
            # Recursively collect all YAML files inside the directory
            result.extend(sorted(p.rglob("*.yaml")))
            result.extend(sorted(p.rglob("*.yml")))
        elif "*" in src or "?" in src:
            result.extend(pathlib.Path(f) for f in sorted(_glob.glob(src, recursive=True)))
        elif p.is_file():
            result.append(p)
        else:
            # Try as a glob pattern anyway
            matches = sorted(_glob.glob(src, recursive=True))
            if matches:
                result.extend(pathlib.Path(f) for f in matches)
            else:
                result.append(p)  # keep it so the loader can produce the error

    # Deduplicate preserving order
    seen: set[pathlib.Path] = set()
    unique: list[pathlib.Path] = []
    for f in result:
        if f not in seen:
            seen.add(f)
            unique.append(f)
    return unique


def _default_flows_dir() -> Optional[pathlib.Path]:
    """Return `./flows` or `./honey_badgeria/project_template/flows` if they exist."""
    for candidate in ("flows", "honey_badgeria/project_template/flows"):
        p = pathlib.Path(candidate)
        if p.is_dir():
            return p
    return None


def register(app):
    """Register the viz command with a Typer app."""
    import typer

    @app.command("viz")
    def viz(
        graphs: Optional[list[str]] = typer.Argument(
            None,
            help=(
                "YAML file(s), director(ies), or glob patterns to visualise. "
                "If omitted the ./flows directory (or project template flows) is scanned."
            ),
        ),
        output_dir: str = typer.Option(
            ".", "--output-dir", "-d",
            help="Directory where rendered files are written.",
        ),
        prefix: str = typer.Option(
            "", "--prefix", "-p",
            help="Optional prefix for output file names.",
        ),
        ascii_only: bool = typer.Option(False, "--ascii", help="Force ASCII rendering."),
        title: Optional[str] = typer.Option(
            None, "--title", "-t",
            help="Override the graph title (only useful when visualising a single file).",
        ),
    ):
        """Visualize flow graph(s) — accepts files, directories, or globs.

        Examples

            hbia viz                            # scans ./flows/
            hbia viz flows/                     # explicit directory
            hbia viz flows/order.yaml           # single file
            hbia viz "flows/*.yaml"             # glob
            hbia viz f1.yaml f2.yaml --ascii    # multiple files, ASCII mode
        """
        from honey_badgeria.back.dsl.loader import load_graph_from_yaml

        # ── Resolve sources ──────────────────────────────────────────────────
        sources: list[str]
        if graphs:
            sources = list(graphs)
        else:
            default = _default_flows_dir()
            if default:
                sources = [str(default)]
                typer.echo(f"  Scanning {default}/")
            else:
                typer.echo(
                    "✘ No flow files specified and no ./flows directory found.\n"
                    "  Usage: hbia viz <file|dir|glob> …",
                    err=True,
                )
                raise typer.Exit(1)

        yaml_files = _yaml_files_from(sources)

        if not yaml_files:
            typer.echo("✘ No YAML files found for the given sources.", err=True)
            raise typer.Exit(1)

        # ── Ensure output directory exists ───────────────────────────────────
        out_dir = pathlib.Path(output_dir)
        out_dir.mkdir(parents=True, exist_ok=True)

        successes: list[str] = []
        failures: list[tuple[str, str]] = []

        for yaml_path in yaml_files:
            # Derive a sensible output base name from the YAML file stem
            stem = yaml_path.stem  # e.g. "order_flow"
            out_base = str(out_dir / f"{prefix}{stem}")

            # Title: explicit override, or file stem prettified
            graph_title = title if (title and len(yaml_files) == 1) else _prettify(stem)

            try:
                g = load_graph_from_yaml(str(yaml_path))
            except Exception as exc:
                failures.append((str(yaml_path), str(exc)))
                typer.echo(f"  ✘ {yaml_path}  — {exc}", err=True)
                continue

            try:
                if ascii_only:
                    from honey_badgeria.visualization.ascii_renderer import AsciiRenderer
                    renderer = AsciiRenderer(g)
                    text = renderer.render(output=out_base, title=graph_title)
                    # Always print to stdout as well
                    typer.echo(text)
                    successes.append(f"{out_base}.txt")
                else:
                    from honey_badgeria.visualization.dag_visualizer import DagVisualizer
                    visualizer = DagVisualizer(g)
                    result = visualizer.render(out_base, title=graph_title)
                    successes.append(result)
                    typer.echo(f"  ✔ {yaml_path.name}  →  {result}")
            except Exception as exc:
                failures.append((str(yaml_path), str(exc)))
                typer.echo(f"  ✘ {yaml_path}  (render error) — {exc}", err=True)

        # ── Summary ──────────────────────────────────────────────────────────
        typer.echo("")
        if successes:
            typer.echo(f"✔ {len(successes)} graph(s) rendered successfully.")
        if failures:
            typer.echo(f"✘ {len(failures)} graph(s) failed.", err=True)
            raise typer.Exit(1)


def _prettify(stem: str) -> str:
    """Turn 'order_flow' → 'Order Flow'."""
    return stem.replace("_", " ").replace("-", " ").title()

