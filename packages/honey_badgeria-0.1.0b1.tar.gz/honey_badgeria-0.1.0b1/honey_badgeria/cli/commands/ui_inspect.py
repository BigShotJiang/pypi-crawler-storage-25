"""CLI command: ui-inspect — inspect a frontend domain's graph structure.

Usage:
    hbia ui-inspect graph/dashboard
    hbia ui-inspect graph/dashboard --component Chart
    hbia ui-inspect graph/dashboard --state FilterState
"""

from __future__ import annotations


def register(app):
    """Register the ui-inspect command with a Typer app."""
    import typer

    @app.command("ui-inspect")
    def ui_inspect(
        domain_path: str = typer.Argument(
            ..., help="Path to the domain directory (e.g. graph/dashboard)."
        ),
        component: str = typer.Option(
            None, "--component", "-c", help="Inspect a specific UI component."
        ),
        state: str = typer.Option(
            None, "--state", "-s", help="Inspect a specific state node."
        ),
        output_json: bool = typer.Option(
            False, "--json", help="Output as JSON (AI-friendly format)."
        ),
    ):
        """Inspect a frontend domain's graph structure.

        Shows the complete architecture of a frontend domain including
        all four graphs: UI, State, Effects, and Events.
        """
        import json

        from honey_badgeria.front.dsl.loader import load_frontend_domain
        from honey_badgeria.front.explain import FrontendExplainer

        try:
            domain = load_frontend_domain(domain_path, validate=True)
        except Exception as exc:
            typer.echo(f"✘ Failed to load domain: {exc}", err=True)
            raise typer.Exit(1)

        explainer = FrontendExplainer(domain)

        if output_json:
            data = explainer.to_dict()
            typer.echo(json.dumps(data, indent=2))
            return

        if component:
            lines = explainer.explain_component(component)
        elif state:
            lines = explainer.explain_state(state)
        else:
            lines = explainer.explain_lines()

        for line in lines:
            typer.echo(line)
