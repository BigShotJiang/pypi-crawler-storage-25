"""CLI command: graph - display graph summary."""


def register(app):
    """Register the graph command with a Typer app."""
    import typer

    @app.command("graph")
    def graph_cmd(
        path: str = typer.Argument(..., help="Path to graph YAML file."),
    ):
        """Display a quick summary of a graph file."""
        from honey_badgeria.back.dsl.loader import load_graph_from_yaml
        from honey_badgeria.back.topology import GraphTopology

        try:
            g = load_graph_from_yaml(path)
        except Exception as e:
            typer.echo(f"✘ Failed to load graph: {e}", err=True)
            raise typer.Exit(1)

        topo = GraphTopology(g)

        typer.echo(f"Graph: {path}")
        typer.echo(f"  Vertices : {len(g.vertices)}")
        typer.echo(f"  Edges    : {len(g.edges)}")
        typer.echo(f"  Flows    : {list(g.flows.keys()) or '(none)'}")
        typer.echo(f"  Sources  : {topo.sources()}")
        typer.echo(f"  Sinks    : {topo.sinks()}")
        typer.echo(f"  Stages   : {len(topo.execution_stages())}")
