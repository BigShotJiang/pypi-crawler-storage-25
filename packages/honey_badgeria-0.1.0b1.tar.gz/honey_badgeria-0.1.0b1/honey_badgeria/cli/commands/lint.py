"""CLI command: lint - AI-oriented linting of graph YAML files.

Checks that flow definitions follow best practices for AI comprehension:
consistent naming, explicit effect/version fields, proper edge wiring, etc.

Examples::

    hbia lint flows/                     # lint all YAML files in flows/
    hbia lint flows/payments.yaml        # lint a single file
    hbia lint --json                     # machine-readable output
"""

from __future__ import annotations

import pathlib
from typing import Optional


def _collect_yaml_files(sources: list[str]) -> list[pathlib.Path]:
    """Expand sources (files, dirs) into YAML paths."""
    result: list[pathlib.Path] = []
    for src in sources:
        p = pathlib.Path(src)
        if p.is_dir():
            result.extend(sorted(p.rglob("*.yaml")))
            result.extend(sorted(p.rglob("*.yml")))
        elif p.is_file():
            result.append(p)
        else:
            result.append(p)

    seen: set[pathlib.Path] = set()
    unique: list[pathlib.Path] = []
    for f in result:
        if f not in seen:
            seen.add(f)
            unique.append(f)
    return unique


def register(app):
    """Register the lint command with a Typer app."""
    import typer

    @app.command("lint")
    def lint(
        sources: Optional[list[str]] = typer.Argument(
            None,
            help=(
                "YAML files or directories to lint. "
                "If omitted, scans ./flows/ directory."
            ),
        ),
        json_output: bool = typer.Option(
            False, "--json", help="Output as JSON array.",
        ),
        strict: bool = typer.Option(
            False, "--strict",
            help="Treat warnings as errors (exit code 1).",
        ),
    ):
        """Lint graph YAML files for AI best-practice compliance.

        Checks: effect/version fields, naming conventions, edge wiring,
        handler declarations, and more.

        Examples:

            hbia lint                         # scan ./flows/
            hbia lint flows/payments.yaml     # single file
            hbia lint flows/ --strict         # warnings = errors
            hbia lint flows/ --json           # machine-readable
        """
        from honey_badgeria.utils.yaml_io import load_yaml
        from honey_badgeria.back.lint.ai_linter import AILinter

        if sources:
            paths = sources
        else:
            if pathlib.Path("flows").is_dir():
                paths = ["flows"]
            else:
                typer.echo(
                    "✘ No sources specified and no ./flows directory found.",
                    err=True,
                )
                raise typer.Exit(1)

        yaml_files = _collect_yaml_files(paths)
        if not yaml_files:
            typer.echo("✘ No YAML files found.", err=True)
            raise typer.Exit(1)

        linter = AILinter()
        all_issues: list[dict] = []
        total_errors = 0
        total_warnings = 0
        isolated_flows: list[dict] = []

        for fpath in yaml_files:
            try:
                data = load_yaml(str(fpath))
            except Exception as exc:
                typer.echo(f"✘ Cannot read {fpath}: {exc}", err=True)
                total_errors += 1
                continue

            issues = linter.lint(data)

            # Track isolated flows for cross-file analysis
            if isinstance(data, dict) and "flow" in data:
                for flow_name, flow_def in data.get("flow", {}).items():
                    if not isinstance(flow_def, dict):
                        continue
                    has_next = any(
                        isinstance(vc, dict) and vc.get("next")
                        for vc in flow_def.values()
                    )
                    if not has_next:
                        isolated_flows.append({
                            "file": str(fpath),
                            "flow": flow_name,
                            "vertices": len(flow_def),
                        })

            for issue in issues:
                entry = {
                    "file": str(fpath),
                    "code": issue.code,
                    "severity": issue.severity,
                    "message": issue.message,
                    "vertex": issue.vertex,
                    "flow": issue.flow,
                    "suggestion": issue.suggestion,
                }
                all_issues.append(entry)

                if issue.severity == "error":
                    total_errors += 1
                elif issue.severity == "warning":
                    total_warnings += 1

            if not json_output and issues:
                typer.echo(f"\n{fpath}:")
                for issue in issues:
                    typer.echo(f"  {issue}")

        # Cross-file check: too many isolated flows is a red flag
        isolation_threshold = 4
        if len(isolated_flows) >= isolation_threshold:
            flow_names = [f"{f['flow']} ({f['file']})" for f in isolated_flows]
            w008 = {
                "file": "",
                "code": "W008",
                "severity": "warning",
                "message": (
                    f"Project has {len(isolated_flows)} isolated flows "
                    f"with no 'next' connections. This is a red flag — "
                    f"real applications have flows that chain multiple "
                    f"steps. Isolated: {', '.join(flow_names)}"
                ),
                "vertex": None,
                "flow": None,
                "suggestion": (
                    "Combine related single-step flows into multi-step "
                    "pipelines using 'next'. For example, an 'add_comment' "
                    "flow should validate input → authenticate user → "
                    "persist comment → return result."
                ),
            }
            all_issues.append(w008)
            total_warnings += 1

            if not json_output:
                from honey_badgeria.back.lint.ai_linter import LintIssue
                issue_obj = LintIssue(
                    code="W008",
                    severity="warning",
                    message=w008["message"],
                    suggestion=w008["suggestion"],
                )
                typer.echo(f"\n[project-level]:")
                typer.echo(f"  {issue_obj}")

        if json_output:
            import json
            typer.echo(json.dumps(all_issues, indent=2))
        else:
            typer.echo("")
            if not all_issues:
                typer.echo("✔ All files pass lint checks.")
            else:
                typer.echo(
                    f"Found {total_errors} error(s), "
                    f"{total_warnings} warning(s)."
                )

        has_failures = total_errors > 0 or (strict and total_warnings > 0)
        if has_failures:
            raise typer.Exit(1)
