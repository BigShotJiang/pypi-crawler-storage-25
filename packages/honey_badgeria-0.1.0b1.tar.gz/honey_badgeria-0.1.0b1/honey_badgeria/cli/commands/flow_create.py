"""CLI command: flow-create - scaffold a new flow YAML + vertex stubs.

Creates a flow YAML file in the new flow format with vertices connected
sequentially, and generates matching vertex handler stub files.

Examples::

    hbia flow-create payment --vertices validate,charge,confirm --domain payments
    hbia flow-create greet --vertices hello,shout
"""

from __future__ import annotations

import os


def register(app):
    """Register the flow-create command with a Typer app."""
    import typer

    @app.command("flow-create")
    def flow_create(
        name: str = typer.Argument(..., help="Flow name (snake_case)."),
        vertices: str = typer.Option(
            ..., "--vertices", "-v",
            help="Comma-separated vertex names, in execution order.",
        ),
        domain: str = typer.Option(
            "", "--domain", "-D",
            help="Domain subfolder for vertices (e.g. auth, payments).",
        ),
        flows_dir: str = typer.Option(
            "flows", "--flows-dir", help="Root directory for flow YAML files.",
        ),
        vertices_dir: str = typer.Option(
            "vertices", "--vertices-dir", help="Root directory for vertex handlers.",
        ),
        effect: str = typer.Option(
            "pure", "--effect", "-e",
            help="Default effect for all vertices: pure or side_effect.",
        ),
    ):
        """Scaffold a new flow YAML and vertex handler stubs.

        Creates a flow YAML in the new sequential format and generates
        matching Python handler files for each vertex.

        Examples:

            hbia flow-create payment --vertices validate,charge,confirm -D payments

            hbia flow-create greet --vertices hello,shout

            hbia flow-create ingest --vertices fetch,parse,store -e side_effect
        """
        vertex_names = [v.strip() for v in vertices.split(",") if v.strip()]
        if not vertex_names:
            typer.echo("✘ At least one vertex name is required.", err=True)
            raise typer.Exit(1)

        domain = domain.strip()

        # Build flow YAML
        yaml_content = _build_flow_yaml(name, vertex_names, domain, vertices_dir, effect)

        # Determine output paths
        if domain:
            flow_out_dir = os.path.join(flows_dir, domain)
        else:
            flow_out_dir = flows_dir

        os.makedirs(flow_out_dir, exist_ok=True)
        flow_path = os.path.join(flow_out_dir, f"{name}.yaml")

        if os.path.exists(flow_path):
            typer.echo(f"✘ Flow file already exists: {flow_path}", err=True)
            raise typer.Exit(1)

        with open(flow_path, "w") as f:
            f.write(yaml_content)
        typer.echo(f"  ✔ Created flow: {flow_path}")

        # Create vertex stubs
        if domain:
            vdir = os.path.join(vertices_dir, domain)
        else:
            vdir = vertices_dir

        os.makedirs(vdir, exist_ok=True)
        _ensure_init(vertices_dir)
        if domain:
            _ensure_init(vdir)

        for vname in vertex_names:
            vpath = os.path.join(vdir, f"{vname}.py")
            if not os.path.exists(vpath):
                handler_path = _handler_path(vertices_dir, domain, vname)
                content = _build_vertex_stub(vname, handler_path, effect)
                with open(vpath, "w") as f:
                    f.write(content)
                typer.echo(f"  ✔ Created vertex: {vpath}")
            else:
                typer.echo(f"  ℹ Vertex exists: {vpath} (skipped)")

        typer.echo("")
        typer.echo(f"✔ Flow '{name}' scaffolded with {len(vertex_names)} vertices.")
        pipeline = " → ".join(vertex_names)
        typer.echo(f"  Pipeline: {pipeline}")
        typer.echo("")
        typer.echo("  Next steps:")
        typer.echo(f"  1. Implement handlers in {vdir}/")
        typer.echo(f"  2. hbia lint {flow_path}")
        typer.echo(f"  3. hbia validate {flow_path}")


def _handler_path(vertices_dir: str, domain: str, vname: str) -> str:
    """Build a dotted handler path."""
    parts = [vertices_dir.replace(os.sep, ".")]
    if domain:
        parts.append(domain)
    parts.extend([vname, vname])
    return ".".join(parts)


def _build_flow_yaml(
    name: str,
    vertex_names: list[str],
    domain: str,
    vertices_dir: str,
    default_effect: str,
) -> str:
    """Generate flow YAML content in the new sequential format."""
    lines: list[str] = []
    pipeline = " → ".join(vertex_names)
    domain_label = f"  {domain}" if domain else ""

    lines.append(f"# Flow: {name}")
    if domain:
        lines.append(f"# Domain: {domain}")
    lines.append(f"# Pipeline: {pipeline}")
    lines.append("")
    lines.append("flow:")
    lines.append(f"  {name}:")

    for i, vname in enumerate(vertex_names):
        handler = _handler_path(vertices_dir, domain, vname)
        is_last = i == len(vertex_names) - 1

        lines.append(f"    # Step {i + 1}: {vname}")
        lines.append(f"    {vname}:")
        lines.append(f"      handler: {handler}")
        lines.append(f"      effect: {default_effect}")
        lines.append(f'      version: "1"')
        lines.append(f"      inputs: {{}}")
        lines.append(f"      outputs: {{}}")

        if not is_last:
            next_vertex = vertex_names[i + 1]
            lines.append(f"      next:")
            lines.append(f"        - {next_vertex}")

        lines.append("")

    return "\n".join(lines)


def _build_vertex_stub(name: str, handler_path: str, effect: str) -> str:
    """Generate a vertex handler stub file."""
    return f'''"""Vertex handler: {name}

Handler path: {handler_path}
Effect: {effect}
"""

from honey_badgeria.decorators import vertex


@vertex
def {name}():
    """
    Handler for the '{name}' vertex.

    TODO: Define inputs as function parameters.
    TODO: Return a dict with output keys.
    """
    # TODO: implement
    return {{"result": None}}
'''


def _ensure_init(directory: str) -> None:
    """Create __init__.py if it doesn't exist."""
    init_path = os.path.join(directory, "__init__.py")
    if not os.path.exists(init_path):
        os.makedirs(directory, exist_ok=True)
        with open(init_path, "w") as f:
            f.write("")
