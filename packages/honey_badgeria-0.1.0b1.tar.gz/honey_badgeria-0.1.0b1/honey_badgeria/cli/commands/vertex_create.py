"""CLI command: vertex-create - scaffold a new vertex handler file.

Supports a ``--domain`` flag to organize vertices in subfolders::

    hbia vertex-create login --domain auth
    # → vertices/auth/login.py  (handler path: vertices.auth.login.login)
"""

from __future__ import annotations

import os


def register(app):
    """Register the vertex-create command with a Typer app."""
    import typer

    @app.command("vertex-create")
    def vertex_create(
        name: str = typer.Argument(..., help="Vertex name (snake_case)."),
        output_dir: str = typer.Option(
            "vertices", "--dir", "-d", help="Root vertices directory."
        ),
        domain: str = typer.Option(
            "",
            "--domain",
            "-D",
            help="Domain subfolder (e.g. auth, payments). Creates vertices/<domain>/.",
        ),
        inputs: str = typer.Option(
            "", "--inputs", "-i", help="Comma-separated input names."
        ),
        outputs: str = typer.Option(
            "result", "--outputs", "-o", help="Comma-separated output names."
        ),
    ):
        """Scaffold a new vertex handler Python file.

        Examples:

            hbia vertex-create greet

            hbia vertex-create login --domain auth --inputs email,password

            hbia vertex-create charge --domain payments --inputs amount,token --outputs success,charge_id
        """
        # Resolve target directory (with optional domain subfolder)
        domain = domain.strip()
        if domain:
            target_dir = os.path.join(output_dir, domain)
        else:
            target_dir = output_dir

        os.makedirs(target_dir, exist_ok=True)

        # Ensure __init__.py exists at every level
        _ensure_init(output_dir)
        if domain:
            _ensure_init(target_dir)

        filepath = os.path.join(target_dir, f"{name}.py")
        if os.path.exists(filepath):
            typer.echo(f"✘ File already exists: {filepath}", err=True)
            raise typer.Exit(1)

        input_names = [i.strip() for i in inputs.split(",") if i.strip()]
        output_names = [o.strip() for o in outputs.split(",") if o.strip()]

        # Build handler path for reference
        parts = [output_dir.replace(os.sep, ".")]
        if domain:
            parts.append(domain)
        parts.extend([name, name])
        handler_path = ".".join(parts)

        content = _build_vertex_file(name, input_names, output_names, handler_path)
        with open(filepath, "w") as f:
            f.write(content)

        typer.echo(f"✔ Created vertex: {filepath}")
        typer.echo(f"  handler path: {handler_path}")


def _ensure_init(directory: str) -> None:
    """Create __init__.py if it doesn't exist."""
    init_path = os.path.join(directory, "__init__.py")
    if not os.path.exists(init_path):
        os.makedirs(directory, exist_ok=True)
        with open(init_path, "w") as f:
            f.write("")


def _build_vertex_file(
    name: str,
    input_names: list[str],
    output_names: list[str],
    handler_path: str,
) -> str:
    """Generate the vertex handler Python file content."""
    params = ", ".join(input_names) if input_names else ""
    returns = ", ".join(f'"{o}": None' for o in output_names)

    lines = [
        f'"""Vertex handler: {name}.',
        "",
        f"Handler path: {handler_path}",
        '"""',
        "",
        "from honey_badgeria.decorators import vertex",
        "",
        "",
        "@vertex",
        f"def {name}({params}):",
        '    """',
        f"    Handler for the '{name}' vertex.",
        "",
    ]

    if input_names:
        lines.append(f"    Inputs: {', '.join(input_names)}")
    if output_names:
        lines.append(f"    Outputs: {', '.join(output_names)}")

    lines += [
        '    """',
        "    # TODO: implement",
        f"    return {{{returns}}}",
        "",
    ]

    return "\n".join(lines)
