"""CLI command: clear-cache - delete all cached data."""

from honey_badgeria.conf.defaults import DEFAULT_CACHE_DIR


def register(app):
    """Register the clear-cache command with a Typer app."""
    import typer

    @app.command("clear-cache")
    def clear_cache(
        cache_dir: str = typer.Option(DEFAULT_CACHE_DIR, "--dir", help="Cache directory."),
        force: bool = typer.Option(False, "--force", "-y", help="Skip confirmation."),
    ):
        """Remove all cached data."""
        from honey_badgeria.back.runtime.cache.cache_manager import CacheManager

        cm = CacheManager(cache_dir)
        info = cm.info()

        if info["entries"] == 0:
            typer.echo("Cache is already empty.")
            return

        if not force:
            typer.confirm(
                f"Delete {info['entries']} cache entries ({info['size_bytes']} bytes)?",
                abort=True,
            )

        cm.clear()
        typer.echo("✔ Cache cleared.")
