"""CLI command: cache-prune - remove old cache entries."""

from honey_badgeria.conf.defaults import DEFAULT_CACHE_DIR, DEFAULT_MAX_CACHE_ENTRIES


def register(app):
    """Register the cache-prune command with a Typer app."""
    import typer

    @app.command("cache-prune")
    def cache_prune(
        max_entries: int = typer.Option(DEFAULT_MAX_CACHE_ENTRIES, "--max", "-n", help="Keep at most N entries."),
        cache_dir: str = typer.Option(DEFAULT_CACHE_DIR, "--dir", help="Cache directory."),
    ):
        """Remove oldest cache entries, keeping at most --max entries."""
        from honey_badgeria.back.runtime.cache.cache_manager import CacheManager

        cm = CacheManager(cache_dir)
        removed = cm.prune(max_entries=max_entries)
        typer.echo(f"Removed {removed} old cache entries.")
