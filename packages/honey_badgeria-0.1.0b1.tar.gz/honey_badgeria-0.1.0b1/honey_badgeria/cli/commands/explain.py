"""CLI command: explain - human/AI-readable graph explanation."""


def register(app):
    """Register the explain command with a Typer app."""
    import typer

    @app.command("explain")
    def explain(
        graph: str = typer.Argument(..., help="Path to graph YAML file."),
        json_out: bool = typer.Option(False, "--json", help="Output as JSON dict."),
    ):
        """Produce a human and AI-readable explanation of a graph."""
        from honey_badgeria.back.dsl.loader import load_graph_from_yaml
        from honey_badgeria.back.explain.graph_explainer import GraphExplainer

        try:
            g = load_graph_from_yaml(graph)
        except Exception as e:
            typer.echo(f"✘ Failed to load graph: {e}", err=True)
            raise typer.Exit(1)

        explainer = GraphExplainer(g)

        if json_out:
            import json as _json
            typer.echo(_json.dumps(explainer.to_dict(), indent=2))
        else:
            explainer.explain()
