"""CLI command: flow-list - list all flows across YAML files.

Scans flow YAML files and prints a summary of each flow's pipeline.

Example output::

    flows/auth.yaml
      login: check_credentials → generate_token → store_session

    flows/payments.yaml
      charge: validate → process → confirm
"""

from __future__ import annotations

import pathlib
from typing import Optional


def register(app):
    """Register the flow-list command with a Typer app."""
    import typer

    @app.command("flow-list")
    def flow_list(
        sources: Optional[list[str]] = typer.Argument(
            None,
            help="YAML files or directories. Defaults to ./flows/.",
        ),
        json_output: bool = typer.Option(
            False, "--json", help="Output as JSON.",
        ),
    ):
        """List all flows found in YAML files.

        Examples:

            hbia flow-list                    # scan ./flows/
            hbia flow-list flows/ --json      # JSON output
        """
        from honey_badgeria.utils.yaml_io import load_yaml

        if sources:
            paths = sources
        else:
            if pathlib.Path("flows").is_dir():
                paths = ["flows"]
            else:
                typer.echo(
                    "✘ No sources specified and no ./flows directory found.",
                    err=True,
                )
                raise typer.Exit(1)

        yaml_files = _collect_yaml_files(paths)
        if not yaml_files:
            typer.echo("✘ No YAML files found.", err=True)
            raise typer.Exit(1)

        all_flows: list[dict] = []

        for fpath in yaml_files:
            try:
                data = load_yaml(str(fpath))
            except Exception:
                continue

            if not isinstance(data, dict):
                continue

            file_flows = _extract_flows(data, str(fpath))
            all_flows.extend(file_flows)

        if json_output:
            import json
            typer.echo(json.dumps(all_flows, indent=2))
            return

        if not all_flows:
            typer.echo("No flows found.")
            return

        current_file = None
        for flow in all_flows:
            if flow["file"] != current_file:
                current_file = flow["file"]
                typer.echo(f"\n{current_file}")

            pipeline = " → ".join(flow["vertices"])
            entry = flow.get("entry", "")
            entry_info = f" (entry: {entry})" if entry else ""
            typer.echo(f"  {flow['name']}: {pipeline}{entry_info}")

        typer.echo(f"\n✔ {len(all_flows)} flow(s) found.")


def _extract_flows(data: dict, filepath: str) -> list[dict]:
    """Extract flow info from a YAML dict."""
    flows: list[dict] = []

    for flow_name, flow_def in data.get("flow", {}).items():
        if not isinstance(flow_def, dict):
            continue

        vertex_names = list(flow_def.keys())

        # Determine pipeline order via topological walk
        ordered = _topo_order_from_next(flow_def)

        # Detect entry
        targets: set[str] = set()
        for vconfig in flow_def.values():
            if isinstance(vconfig, dict):
                for t in (vconfig.get("next") or []):
                    if isinstance(t, str):
                        targets.add(t)

        entries = [v for v in vertex_names if v not in targets]
        entry = entries[0] if entries else ""

        flows.append({
            "file": filepath,
            "name": flow_name,
            "entry": entry,
            "vertices": ordered or vertex_names,
            "vertex_count": len(vertex_names),
        })

    return flows


def _topo_order_from_next(flow_def: dict) -> list[str]:
    """Compute topological order from next fields."""
    vertex_names = list(flow_def.keys())
    targets: set[str] = set()
    adj: dict[str, list[str]] = {v: [] for v in vertex_names}

    for vname, vconfig in flow_def.items():
        if not isinstance(vconfig, dict):
            continue
        next_list = vconfig.get("next", [])
        if isinstance(next_list, str):
            next_list = [next_list]
        for t in next_list:
            if t in adj:
                adj[vname].append(t)
                targets.add(t)

    # Find entry (not a target)
    entries = [v for v in vertex_names if v not in targets]
    if not entries:
        return vertex_names

    ordered: list[str] = []
    visited: set[str] = set()

    def dfs(node: str) -> None:
        if node in visited:
            return
        visited.add(node)
        ordered.append(node)
        for nxt in adj.get(node, []):
            dfs(nxt)

    for entry in entries:
        dfs(entry)

    # Add any remaining vertices not reached
    for v in vertex_names:
        if v not in visited:
            ordered.append(v)

    return ordered


def _collect_yaml_files(sources: list[str]) -> list[pathlib.Path]:
    """Expand sources into YAML file paths."""
    result: list[pathlib.Path] = []
    for src in sources:
        p = pathlib.Path(src)
        if p.is_dir():
            result.extend(sorted(p.rglob("*.yaml")))
            result.extend(sorted(p.rglob("*.yml")))
        elif p.is_file():
            result.append(p)
        else:
            result.append(p)

    seen: set[pathlib.Path] = set()
    unique: list[pathlib.Path] = []
    for f in result:
        if f not in seen:
            seen.add(f)
            unique.append(f)
    return unique
