"""CLI command: graph-sync - sync graph from decorated Python code."""


def register(app):
    """Register the graph-sync command with a Typer app."""
    import typer

    @app.command("graph-sync")
    def graph_sync(
        output: str = typer.Option("graph.yaml", "--output", "-o", help="Output YAML file."),
        module: str = typer.Option(
            None, "--module", "-m",
            help="Dotted path to module(s) with @vertex/@flow decorators.",
        ),
    ):
        """Generate a graph YAML from decorated Python code.

        Scans @vertex and @flow decorators and writes the discovered
        graph definition to a YAML file.
        """
        from honey_badgeria.back.discovery.flow_builder import FlowGraphBuilder
        from honey_badgeria.back.discovery.flow_graph_writer import FlowGraphWriter

        if module:
            import importlib
            try:
                importlib.import_module(module)
            except ImportError as e:
                typer.echo(f"✘ Cannot import module: {e}", err=True)
                raise typer.Exit(1)

        builder = FlowGraphBuilder()
        graph_dict = builder.build()

        flow_data = graph_dict.get("flow", {})
        vertex_count = sum(
            len(fd) for fd in flow_data.values() if isinstance(fd, dict)
        )
        if vertex_count == 0:
            typer.echo("✘ No vertices discovered.  Did you import the right module?", err=True)
            raise typer.Exit(1)

        writer = FlowGraphWriter()
        writer.save(graph_dict, output)
        typer.echo(f"✔ Graph synced to {output} ({vertex_count} vertices)")
