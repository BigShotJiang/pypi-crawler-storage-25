"""CLI for Honey Badgeria."""
