"""
Honey Badgeria - Application framework designed for AI-assisted development.

Software that AIs can understand first.
"""

__version__ = "0.1.0b1"

from honey_badgeria.decorators.vertex import vertex
from honey_badgeria.decorators.flow import flow

__all__ = [
    "vertex",
    "flow",
    "__version__",
]
