"""Shared core for Honey Badgeria.

This package holds cross-platform foundations used by both ``back``
and ``front`` (and any future platform module).

    core/
    └── exceptions.py   Base exception hierarchy
"""
