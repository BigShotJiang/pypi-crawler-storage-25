"""Centralized exception hierarchy for Honey Badgeria.

Every exception raised by the library inherits from :class:`HoneyBadgeriaError`
so users can catch **all** framework errors with a single ``except`` clause::

    try:
        result = run_flow(graph)
    except HoneyBadgeriaError as exc:
        # guaranteed to come from HBIA, not from user code
        print(f"HBIA error: {exc}")

The hierarchy:

    HoneyBadgeriaError
    ├── GraphError
    │   ├── VertexAlreadyExistsError
    │   ├── VertexNotFoundError
    │   ├── EdgeInvalidError
    │   └── GraphCycleError
    ├── GraphValidationError
    ├── DSLValidationError
    ├── HandlerNotFoundError
    ├── HandlerResolutionError
    ├── FlowNotFoundError
    ├── DataResolutionError
    ├── ContractError
    │   ├── ContractInputError
    │   └── ContractOutputError
    ├── CacheError
    ├── ExecutionError
    │   ├── VertexExecutionError
    │   └── StageExecutionError
    ├── AtomicError
    │   ├── AtomicRollbackError
    │   ├── AtomicSnapshotError
    │   └── AtomicBoundaryError
    ├── SagaError
    │   ├── SagaCompensationError
    │   └── SagaStepError
    └── ConfigurationError
"""

from __future__ import annotations


# ======================================================================
# Base
# ======================================================================

class HoneyBadgeriaError(Exception):
    """Base error for **all** Honey Badgeria operations.

    Catch this to handle every error the library can raise while still
    letting unrelated exceptions propagate.
    """


# ======================================================================
# Graph structure
# ======================================================================

class GraphError(HoneyBadgeriaError):
    """Base for errors related to graph construction and structure."""


class VertexAlreadyExistsError(GraphError):
    """A vertex with this name has already been added to the graph."""


class VertexNotFoundError(GraphError):
    """The requested vertex does not exist in the graph."""


class EdgeInvalidError(GraphError):
    """An edge references a source or target that does not exist."""


class GraphCycleError(GraphError):
    """A cycle was detected — the graph is not a valid DAG."""


# ======================================================================
# Validation
# ======================================================================

class GraphValidationError(HoneyBadgeriaError):
    """Structural validation of a ``Graph`` instance failed.

    The ``errors`` attribute contains a list of individual error strings.
    """

    def __init__(self, message: str, errors: list[str] | None = None) -> None:
        super().__init__(message)
        self.errors: list[str] = errors or []


class DSLValidationError(HoneyBadgeriaError):
    """Validation of a YAML / dict graph definition failed.

    The ``errors`` attribute contains individual error strings.
    """

    def __init__(self, message: str, errors: list[str] | None = None) -> None:
        super().__init__(message)
        self.errors: list[str] = errors or []


# ======================================================================
# Handlers
# ======================================================================

class HandlerNotFoundError(HoneyBadgeriaError):
    """A handler could not be found in the registry or handler dict."""


class HandlerResolutionError(HoneyBadgeriaError):
    """A dotted handler path could not be resolved to a callable."""


# ======================================================================
# Flows
# ======================================================================

class FlowNotFoundError(HoneyBadgeriaError):
    """The requested flow name does not exist in the graph."""


# ======================================================================
# Data
# ======================================================================

class DataResolutionError(HoneyBadgeriaError):
    """An input data binding could not be resolved from the data store."""


# ======================================================================
# Contracts
# ======================================================================

class ContractError(HoneyBadgeriaError):
    """Base for contract validation errors."""


class ContractInputError(ContractError):
    """A vertex's input data violates its declared contract."""


class ContractOutputError(ContractError):
    """A vertex's output data violates its declared contract."""


# ======================================================================
# Execution
# ======================================================================

class ExecutionError(HoneyBadgeriaError):
    """Base for runtime execution errors."""


class VertexExecutionError(ExecutionError):
    """A vertex handler raised an exception during execution.

    Attributes:
        vertex_name: The name of the vertex that failed.
        original: The original exception raised by the handler.
    """

    def __init__(
        self,
        message: str,
        vertex_name: str = "",
        original: BaseException | None = None,
    ) -> None:
        super().__init__(message)
        self.vertex_name: str = vertex_name
        self.original: BaseException | None = original


class StageExecutionError(ExecutionError):
    """One or more vertices in an execution stage failed."""


# ======================================================================
# Cache
# ======================================================================

class CacheError(HoneyBadgeriaError):
    """An error occurred during cache read/write operations."""


# ======================================================================
# Atomicity
# ======================================================================

class AtomicError(HoneyBadgeriaError):
    """Base for errors related to atomic transaction execution."""


class AtomicRollbackError(AtomicError):
    """Rollback of an atomic group failed.

    Attributes:
        group_name: The atomic group that was being rolled back.
        original: The exception that triggered the rollback.
        rollback_error: The exception raised during the rollback itself.
    """

    def __init__(
        self,
        message: str,
        group_name: str = "",
        original: BaseException | None = None,
        rollback_error: BaseException | None = None,
    ) -> None:
        super().__init__(message)
        self.group_name: str = group_name
        self.original: BaseException | None = original
        self.rollback_error: BaseException | None = rollback_error


class AtomicSnapshotError(AtomicError):
    """Saving a snapshot before entering an atomic group failed."""


class AtomicBoundaryError(AtomicError):
    """An atomic group's vertices cross a boundary that violates consistency.

    For example, an atomic group shares vertices with a parallel stage.
    """


# ======================================================================
# Saga
# ======================================================================

class SagaError(HoneyBadgeriaError):
    """Base for errors related to the SAGA compensation pattern."""


class SagaCompensationError(SagaError):
    """One or more compensation steps failed during saga rollback.

    Attributes:
        failed_step: Name of the step whose compensation failed.
        compensation_errors: List of ``(step_name, exception)`` pairs.
    """

    def __init__(
        self,
        message: str,
        failed_step: str = "",
        compensation_errors: list[tuple[str, BaseException]] | None = None,
    ) -> None:
        super().__init__(message)
        self.failed_step: str = failed_step
        self.compensation_errors: list[tuple[str, BaseException]] = (
            compensation_errors or []
        )


class SagaStepError(SagaError):
    """A forward step in a saga failed.

    Attributes:
        step_name: The saga step that failed.
        original: The original exception.
    """

    def __init__(
        self,
        message: str,
        step_name: str = "",
        original: BaseException | None = None,
    ) -> None:
        super().__init__(message)
        self.step_name: str = step_name
        self.original: BaseException | None = original


# ======================================================================
# Configuration
# ======================================================================

class ConfigurationError(HoneyBadgeriaError):
    """Invalid configuration detected in Settings."""
