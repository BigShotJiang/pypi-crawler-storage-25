"""Flow decorator for defining execution flows."""

from __future__ import annotations

from typing import Any, Callable

FLOW_REGISTRY: dict[str, Callable[..., Any]] = {}


def flow(name: str) -> Callable[[Callable[..., Any]], Callable[..., Any]]:
    """Decorator to mark a function as a flow definition."""

    def wrapper(fn: Callable[..., Any]) -> Callable[..., Any]:
        FLOW_REGISTRY[name] = fn
        fn.__hbia_flow__ = True  # type: ignore[attr-defined]
        fn.__hbia_flow_name__ = name  # type: ignore[attr-defined]
        return fn

    return wrapper
