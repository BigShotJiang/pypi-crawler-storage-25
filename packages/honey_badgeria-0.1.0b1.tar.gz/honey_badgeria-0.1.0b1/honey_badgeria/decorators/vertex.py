"""Vertex decorator for marking functions as graph vertices."""

from __future__ import annotations

from typing import Any, Callable, overload

VERTEX_REGISTRY: dict[str, Callable[..., Any]] = {}


@overload
def vertex(fn: Callable[..., Any]) -> Callable[..., Any]: ...
@overload
def vertex(*, name: str) -> Callable[[Callable[..., Any]], Callable[..., Any]]: ...


def vertex(
    fn: Callable[..., Any] | None = None,
    *,
    name: str | None = None,
) -> Callable[..., Any] | Callable[[Callable[..., Any]], Callable[..., Any]]:
    """Decorator to mark a function as a vertex handler."""

    def wrapper(func: Callable[..., Any]) -> Callable[..., Any]:
        vertex_name = name or func.__name__
        VERTEX_REGISTRY[vertex_name] = func
        func.__hbia_vertex__ = True  # type: ignore[attr-defined]
        func.__hbia_vertex_name__ = vertex_name  # type: ignore[attr-defined]
        return func

    if fn is not None:
        return wrapper(fn)

    return wrapper
