"""Utility functions for Honey Badgeria."""
