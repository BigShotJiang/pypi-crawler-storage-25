"""YAML I/O utilities (optional, requires pyyaml)."""

from __future__ import annotations

from typing import Any


def load_yaml(path: str) -> Any:
    """Load a YAML file. Requires pyyaml."""
    try:
        import yaml
    except ImportError:
        raise ImportError(
            "pyyaml is required for YAML operations. "
            "Install with: pip install pyyaml"
        )
    with open(path) as f:
        return yaml.safe_load(f)


def save_yaml(data: Any, path: str) -> None:
    """Save data to a YAML file. Requires pyyaml."""
    try:
        import yaml
    except ImportError:
        raise ImportError(
            "pyyaml is required for YAML operations. "
            "Install with: pip install pyyaml"
        )
    with open(path, "w") as f:
        yaml.dump(data, f, sort_keys=False)


def parse_yaml_string(text: str) -> Any:
    """Parse a YAML string. Requires pyyaml."""
    try:
        import yaml
    except ImportError:
        raise ImportError(
            "pyyaml is required for YAML operations. "
            "Install with: pip install pyyaml"
        )
    return yaml.safe_load(text)
