"""Import utility functions."""

from __future__ import annotations

import importlib
from types import ModuleType
from typing import Any


def import_string(dotted_path: str) -> Any:
    """Import a dotted module path and return the attribute/class."""
    module_path, _, attr_name = dotted_path.rpartition(".")

    if not module_path:
        raise ImportError(f"Invalid dotted path: {dotted_path}")

    module: ModuleType = importlib.import_module(module_path)

    try:
        return getattr(module, attr_name)
    except AttributeError:
        raise ImportError(
            f"Module '{module_path}' has no attribute '{attr_name}'"
        )


def try_import(module_name: str) -> ModuleType | None:
    """Try to import a module, return None if not available."""
    try:
        return importlib.import_module(module_name)
    except ImportError:
        return None
