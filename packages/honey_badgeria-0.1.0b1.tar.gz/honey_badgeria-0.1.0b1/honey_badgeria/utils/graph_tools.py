"""Graph utility functions."""

from __future__ import annotations

from typing import Iterable

from honey_badgeria.back.graph.graph import Graph
from honey_badgeria.back.graph.vertex import Vertex
from honey_badgeria.back.graph.edge import Edge


def merge_graphs(*graphs: Graph) -> Graph:
    """Merge multiple graphs into one (first vertex wins)."""
    merged = Graph()

    for g in graphs:
        for name, vertex in g.vertices.items():
            if not merged.has_vertex(name):
                merged.add_vertex(vertex)

        for edge in g.edges:
            merged.add_edge(edge)

        merged.flows.update(g.flows)

    return merged


def subgraph(graph: Graph, vertex_names: Iterable[str]) -> Graph:
    """Extract a subgraph containing only the specified vertices."""
    sub = Graph()
    name_set = set(vertex_names)

    for name in name_set:
        if graph.has_vertex(name):
            sub.add_vertex(graph.get_vertex(name))

    for edge in graph.edges:
        if edge.source in name_set and edge.target in name_set:
            sub.add_edge(edge)

    return sub
