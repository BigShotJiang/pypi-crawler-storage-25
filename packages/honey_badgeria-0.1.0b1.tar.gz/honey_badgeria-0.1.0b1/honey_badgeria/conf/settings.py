"""Settings management for Honey Badgeria.

All optional features are DISABLED by default.

Every default value is imported from :mod:`honey_badgeria.conf.defaults`
so that the entire framework has a **single source of truth** for tuneable
constants.
"""

from __future__ import annotations

import importlib
import os
from types import ModuleType
from typing import Any

from honey_badgeria.conf.defaults import (
    DEFAULT_CACHE_DIR,
    DEFAULT_GRAPH_FILE,
    DEFAULT_MAX_CACHE_ENTRIES,
    DEFAULT_MAX_WORKERS,
    ALLOWED_HANDLER_PREFIXES,
    DEFAULT_API_PREFIX,
    DEFAULT_MAX_PAGE_SIZE,
)


def _env_bool(key: str, default: bool = False) -> bool:
    """Read an env var as a boolean ('true'/'1'/'yes' → True)."""
    raw = os.getenv(key, "")
    if not raw:
        return default
    return raw.strip().lower() in ("true", "1", "yes")


class Settings:
    """Configuration settings for Honey Badgeria.

    Every setting has a safe default, imported from
    :mod:`honey_badgeria.conf.defaults`.  Override via constructor kwargs,
    environment variables (``HBIA_*``), or a Python settings module.
    """

    def __init__(self, **kwargs: Any) -> None:
        self.GRAPH_FILE: str = kwargs.get("GRAPH_FILE", DEFAULT_GRAPH_FILE)
        self.HANDLER_MODULES: list[str] = kwargs.get("HANDLER_MODULES", [])
        self.CACHE_ENABLED: bool = kwargs.get("CACHE_ENABLED", False)
        self.CACHE_DIR: str = kwargs.get("CACHE_DIR", DEFAULT_CACHE_DIR)
        self.PARALLEL_ENABLED: bool = kwargs.get("PARALLEL_ENABLED", False)
        self.ASYNC_ENABLED: bool = kwargs.get("ASYNC_ENABLED", False)
        self.MAX_WORKERS: int = kwargs.get("MAX_WORKERS", DEFAULT_MAX_WORKERS)
        self.MAX_CACHE_ENTRIES: int = kwargs.get("MAX_CACHE_ENTRIES", DEFAULT_MAX_CACHE_ENTRIES)
        self.ALLOWED_HANDLER_PREFIXES: tuple[str, ...] = tuple(
            kwargs.get("ALLOWED_HANDLER_PREFIXES", ALLOWED_HANDLER_PREFIXES)
        )
        self.API_PREFIX: str = kwargs.get("API_PREFIX", DEFAULT_API_PREFIX)
        self.MAX_PAGE_SIZE: int = kwargs.get("MAX_PAGE_SIZE", DEFAULT_MAX_PAGE_SIZE)

    @classmethod
    def from_env(cls) -> Settings:
        """Load settings from environment variables."""
        max_w_raw = os.getenv("HBIA_MAX_WORKERS", str(DEFAULT_MAX_WORKERS))
        try:
            max_w = int(max_w_raw)
        except (ValueError, TypeError):
            max_w = DEFAULT_MAX_WORKERS

        prefixes_raw = os.getenv("HBIA_ALLOWED_HANDLER_PREFIXES", "")
        prefixes = tuple(p.strip() for p in prefixes_raw.split(",") if p.strip())

        return cls(
            GRAPH_FILE=os.getenv("HBIA_GRAPH_FILE", DEFAULT_GRAPH_FILE),
            HANDLER_MODULES=[
                m.strip()
                for m in os.getenv("HBIA_HANDLER_MODULES", "").split(",")
                if m.strip()
            ],
            CACHE_ENABLED=_env_bool("HBIA_CACHE_ENABLED"),
            CACHE_DIR=os.getenv("HBIA_CACHE_DIR", DEFAULT_CACHE_DIR),
            PARALLEL_ENABLED=_env_bool("HBIA_PARALLEL_ENABLED"),
            ASYNC_ENABLED=_env_bool("HBIA_ASYNC_ENABLED"),
            MAX_WORKERS=max_w,
            MAX_CACHE_ENTRIES=int(os.getenv("HBIA_MAX_CACHE_ENTRIES", str(DEFAULT_MAX_CACHE_ENTRIES))),
            ALLOWED_HANDLER_PREFIXES=prefixes or ALLOWED_HANDLER_PREFIXES,
            API_PREFIX=os.getenv("HBIA_API_PREFIX", DEFAULT_API_PREFIX),
            MAX_PAGE_SIZE=int(os.getenv("HBIA_MAX_PAGE_SIZE", str(DEFAULT_MAX_PAGE_SIZE))),
        )

    @classmethod
    def from_module(cls, module_path: str) -> Settings:
        """Load settings from a Python module."""
        module: ModuleType = importlib.import_module(module_path)
        settings_dict: dict[str, Any] = getattr(module, "SETTINGS", {})
        return cls(**settings_dict)

    def to_dict(self) -> dict[str, Any]:
        """Return all settings as a plain dict."""
        return {
            "GRAPH_FILE": self.GRAPH_FILE,
            "HANDLER_MODULES": self.HANDLER_MODULES,
            "CACHE_ENABLED": self.CACHE_ENABLED,
            "CACHE_DIR": self.CACHE_DIR,
            "PARALLEL_ENABLED": self.PARALLEL_ENABLED,
            "ASYNC_ENABLED": self.ASYNC_ENABLED,
            "MAX_WORKERS": self.MAX_WORKERS,
            "MAX_CACHE_ENTRIES": self.MAX_CACHE_ENTRIES,
            "ALLOWED_HANDLER_PREFIXES": list(self.ALLOWED_HANDLER_PREFIXES),
            "API_PREFIX": self.API_PREFIX,
            "MAX_PAGE_SIZE": self.MAX_PAGE_SIZE,
        }

    def __repr__(self) -> str:
        flags: list[str] = []
        if self.CACHE_ENABLED:
            flags.append("cache")
        if self.PARALLEL_ENABLED:
            flags.append("parallel")
        if self.ASYNC_ENABLED:
            flags.append("async")
        mode = ", ".join(flags) if flags else "serial"
        return f"<Settings mode=[{mode}]>"


# ======================================================================
# global singleton
# ======================================================================

_settings: Settings | None = None


def get_settings() -> Settings:
    """Get the global settings instance."""
    global _settings
    if _settings is None:
        _settings = Settings.from_env()
    return _settings


def configure(settings: Settings | dict[str, Any]) -> None:
    """Set the global settings instance (or pass a dict)."""
    global _settings
    if isinstance(settings, dict):
        _settings = Settings(**settings)
    else:
        _settings = settings


def reset_settings() -> None:
    """Reset global settings to None (useful in tests)."""
    global _settings
    _settings = None
