"""Framework-wide default constants.

Every magic value used across the codebase lives here so that:

1. There is a single source of truth.
2. AI assistants can find every tuneable in one place.
3. Settings, CLI defaults, and internal modules reference the same values.

Import constants directly::

    from honey_badgeria.conf.defaults import DEFAULT_CACHE_DIR
"""

from __future__ import annotations

# -- Graph ------------------------------------------------------------------
DEFAULT_GRAPH_FILE: str = "graph.yaml"
"""Default filename for graph YAML definitions."""

# -- Execution --------------------------------------------------------------
DEFAULT_MAX_WORKERS: int = 4
"""Thread-pool size when ``PARALLEL_ENABLED`` is True."""

# -- Cache ------------------------------------------------------------------
DEFAULT_CACHE_DIR: str = ".hbia_cache"
"""Directory for vertex output caching."""

DEFAULT_MAX_CACHE_ENTRIES: int = 500
"""Maximum cache entries before ``prune`` kicks in."""

CACHE_FILE_EXTENSION: str = ".json"
"""File extension for cache entries."""

# -- Security ---------------------------------------------------------------
ALLOWED_HANDLER_PREFIXES: tuple[str, ...] = ()
"""If non-empty, ``HandlerResolver`` only imports from these prefixes.

Example::

    ALLOWED_HANDLER_PREFIXES = ("myproject.vertices", "myproject.handlers")

Set via ``Settings.ALLOWED_HANDLER_PREFIXES`` or env var
``HBIA_ALLOWED_HANDLER_PREFIXES`` (comma-separated).
"""

# -- Server -----------------------------------------------------------------
DEFAULT_HOST: str = "0.0.0.0"
"""Default bind host for development servers."""

DEFAULT_PORT: int = 8000
"""Default port for development servers."""

# -- CORS -------------------------------------------------------------------
DEFAULT_CORS_ORIGINS: tuple[str, ...] = ("http://localhost:3000",)
"""Allowed CORS origins (frontend dev server by default)."""

# -- API --------------------------------------------------------------------
DEFAULT_API_PREFIX: str = "/api/v1"
"""Default URL prefix for auto-generated FastAPI routes."""

DEFAULT_MAX_PAGE_SIZE: int = 100
"""Maximum items in paginated API responses."""

# -- Auth / Keycloak --------------------------------------------------------
DEFAULT_KEYCLOAK_URL: str = ""
"""Keycloak server URL (e.g. ``https://auth.example.com``)."""

DEFAULT_KEYCLOAK_REALM: str = ""
"""Keycloak realm name."""

DEFAULT_KEYCLOAK_CLIENT_ID: str = ""
"""Keycloak client ID for this application."""

# -- Module health ----------------------------------------------------------
MODULE_MAX_LINES: int = 300
"""Recommended maximum lines per module (health check threshold)."""

MODULE_MAX_VERTICES: int = 20
"""Recommended maximum vertices per graph file."""

# -- Versioning -------------------------------------------------------------
SCHEMA_VERSION: str = "1"
"""Current schema version for YAML DSL and cache entries."""
