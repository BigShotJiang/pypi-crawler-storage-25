"""
Honey Badgeria Frontend — AI-native UI architecture.

This module provides the frontend counterpart to HBIA's backend
DAG execution framework. Instead of execution DAGs, the frontend
models four reactive graphs:

    1. UI Graph      — component hierarchy and rendering structure
    2. State Graph   — state ownership and dependencies
    3. Effect Graph  — side effects triggered by state changes
    4. Event Graph   — flows triggered by user events

The fundamental rule:

    Events mutate State.
    State triggers Effects.
    State drives UI.

All definitions are YAML-first. TypeScript implementation files
are generated or hand-written to match the YAML contracts.

Usage:

    from honey_badgeria.front import (
        FrontendDomain,
        load_frontend_domain,
        FrontendExplainer,
        FrontendValidator,
    )
"""

from honey_badgeria.front.dsl.schemas import (
    UINodeSchema,
    StateNodeSchema,
    EffectNodeSchema,
    EventFlowSchema,
    FrontendDomainSchema,
)
from honey_badgeria.front.graph.domain import FrontendDomain
from honey_badgeria.front.dsl.loader import load_frontend_domain
from honey_badgeria.front.dsl.validator import FrontendDSLValidator
from honey_badgeria.front.explain.frontend_explainer import FrontendExplainer

__all__ = [
    "UINodeSchema",
    "StateNodeSchema",
    "EffectNodeSchema",
    "EventFlowSchema",
    "FrontendDomainSchema",
    "FrontendDomain",
    "load_frontend_domain",
    "FrontendDSLValidator",
    "FrontendExplainer",
]
