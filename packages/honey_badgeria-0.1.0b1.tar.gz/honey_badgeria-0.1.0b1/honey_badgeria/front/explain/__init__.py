"""Frontend explain module — AI-readable graph explanations."""

from honey_badgeria.front.explain.frontend_explainer import FrontendExplainer

__all__ = ["FrontendExplainer"]
