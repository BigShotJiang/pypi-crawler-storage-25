"""Frontend graph explainer: AI-readable explanations of frontend domains.

Produces structured explanations that help AI agents understand the
entire frontend architecture without reading implementation files.

Usage::

    from honey_badgeria.front.explain import FrontendExplainer

    explainer = FrontendExplainer(domain)
    explainer.explain()           # prints to stdout
    lines = explainer.explain_lines()  # returns list[str]
    data = explainer.to_dict()         # returns dict
"""

from __future__ import annotations

from typing import Any, TYPE_CHECKING

if TYPE_CHECKING:
    from honey_badgeria.front.graph.domain import FrontendDomain


class FrontendExplainer:
    """Produces human and AI-readable explanations of a frontend domain."""

    def __init__(self, domain: FrontendDomain) -> None:
        self.domain = domain

    def explain(self) -> None:
        """Print a full explanation to stdout."""
        print("\n".join(self.explain_lines()))

    def explain_lines(self) -> list[str]:
        """Return explanation as a list of strings."""
        d = self.domain
        lines: list[str] = []

        lines.append(f"=== Frontend Domain: {d.name} ===")
        lines.append("")
        summary = d.summary()
        lines.append(f"Total nodes: {summary['total']}")
        lines.append(f"  UI components:  {summary['ui_nodes']}")
        lines.append(f"  State nodes:    {summary['state_nodes']}")
        lines.append(f"  Effects:        {summary['effect_nodes']}")
        lines.append(f"  Events:         {summary['event_nodes']}")
        lines.append("")

        # ── UI Graph ──────────────────────────────────────────────
        lines.append("--- UI Graph (Component Hierarchy) ---")
        if d.ui_graph.root:
            lines.append(f"  Root: {d.ui_graph.root}")
        for name, node in d.ui_graph.nodes.items():
            lines.append(f"  [{name}]")
            lines.append(f"    view: {node.view}")
            if node.reads:
                lines.append(f"    reads: {node.reads}")
            if node.events:
                lines.append(f"    events: {node.events}")
            if node.children:
                lines.append(f"    children: {node.children}")
        lines.append("")

        # ── State Graph ───────────────────────────────────────────
        lines.append("--- State Graph (State Ownership) ---")
        for name, node in d.state_graph.nodes.items():
            lines.append(f"  [{name}]")
            lines.append(f"    interface: {node.interface}")
            lines.append(f"    fields: {node.fields}")
            lines.append(f"    mutations: {node.mutations}")
            if node.triggers:
                lines.append(f"    triggers: {node.triggers}")
        lines.append("")

        # ── Effect Graph ──────────────────────────────────────────
        lines.append("--- Effect Graph (Side Effects) ---")
        for name, node in d.effect_graph.nodes.items():
            lines.append(f"  [{name}]")
            lines.append(f"    watch: {node.watch}")
            lines.append(f"    handler: {node.handler}")
            lines.append(f"    type: {node.effect_type}")
            if node.mutates:
                lines.append(f"    mutates: {node.mutates}")
            if node.debounce_ms:
                lines.append(f"    debounce: {node.debounce_ms}ms")
        lines.append("")

        # ── Event Graph ───────────────────────────────────────────
        lines.append("--- Event Graph (User Events) ---")
        for name, node in d.event_graph.nodes.items():
            lines.append(f"  [{name}]")
            lines.append(f"    flow: {' → '.join(node.flow)}")
            if node.source:
                lines.append(f"    source: {node.source}")
            if node.guards:
                lines.append(f"    guards: {node.guards}")
        lines.append("")

        # ── Reactive Data Flow ────────────────────────────────────
        lines.append("--- Reactive Data Flow ---")
        lines.append("  Event → State Mutation → Effect → (State Mutation) → UI Re-render")
        lines.append("")

        # Show full chains for each event
        for event_name in d.event_graph.nodes:
            chain = d.full_event_chain(event_name)
            lines.append(f"  Chain: {event_name}")
            for mut in chain.get("mutations", []):
                lines.append(f"    → {mut['state']}.{mut['mutation']}")
            for eff in chain.get("effects", []):
                lines.append(f"    → effect:{eff['effect']} ({eff['type']})")
                if eff.get("mutates"):
                    lines.append(f"      → mutates: {eff['mutates']}")
            ui_updates = chain.get("ui_updates", [])
            if ui_updates:
                lines.append(f"    → re-renders: {ui_updates}")
        lines.append("")

        return lines

    def to_dict(self) -> dict[str, Any]:
        """Return the domain as an AI-friendly dict."""
        d = self.domain
        result = d.to_dict()

        # Add computed fields
        result["reactive_chains"] = {}
        for event_name in d.event_graph.nodes:
            result["reactive_chains"][event_name] = d.full_event_chain(event_name)

        return result

    def explain_component(self, component_name: str) -> list[str]:
        """Explain a single UI component's relationships."""
        d = self.domain
        lines: list[str] = []

        node = d.ui_graph.nodes.get(component_name)
        if node is None:
            return [f"Component {component_name!r} not found in domain {d.name!r}"]

        lines.append(f"=== Component: {component_name} ===")
        lines.append(f"  View: {node.view}")
        lines.append("")

        # What state does it read?
        lines.append("Reads from state:")
        for read in node.reads:
            lines.append(f"  - {read}")
        lines.append("")

        # What events does it emit?
        lines.append("Emits events:")
        for event_label, event_ref in node.events.items():
            event = d.event_graph.nodes.get(event_ref)
            if event:
                lines.append(f"  - {event_label} → {event_ref}")
                lines.append(f"    flow: {' → '.join(event.flow)}")
        lines.append("")

        # What children does it have?
        if node.children:
            lines.append("Children:")
            for child in node.children:
                lines.append(f"  - {child}")
        lines.append("")

        return lines

    def explain_state(self, state_name: str) -> list[str]:
        """Explain a single state node's relationships."""
        d = self.domain
        lines: list[str] = []

        node = d.state_graph.nodes.get(state_name)
        if node is None:
            return [f"State {state_name!r} not found in domain {d.name!r}"]

        lines.append(f"=== State: {state_name} ===")
        lines.append(f"  Interface: {node.interface}")
        lines.append(f"  Fields: {node.fields}")
        lines.append("")

        # Who reads this state?
        readers = [
            ui_name for ui_name, ui_node in d.ui_graph.nodes.items()
            if state_name in ui_node.state_dependencies
        ]
        lines.append(f"Read by UI components: {readers}")

        # Who mutates this state?
        mutators = [
            event_name for event_name, event in d.event_graph.nodes.items()
            if state_name in event.affected_states
        ]
        lines.append(f"Mutated by events: {mutators}")

        # What effects does it trigger?
        effects = d.effect_graph.effects_for_state(state_name)
        effect_names = [e.name for e in effects]
        lines.append(f"Triggers effects: {effect_names}")
        lines.append("")

        return lines
