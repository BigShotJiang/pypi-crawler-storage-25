"""Frontend Domain — container for all four reactive graphs.

A FrontendDomain represents a functional area of the application
(e.g. ``dashboard``, ``auth``, ``reports``).  It aggregates:

    1. UIGraph      — component hierarchy
    2. StateGraph   — state ownership
    3. EffectGraph  — side effect triggers
    4. EventGraph   — user event flows

The domain is the primary unit of AI reasoning about the frontend.
An AI agent can understand the entire domain by reading its graph
structure without opening any TypeScript implementation files.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, TYPE_CHECKING

from honey_badgeria.front.graph.ui_graph import UIGraph, UINode
from honey_badgeria.front.graph.state_graph import StateGraph, StateNode
from honey_badgeria.front.graph.effect_graph import EffectGraph, EffectNode
from honey_badgeria.front.graph.event_graph import EventGraph, EventNode

if TYPE_CHECKING:
    from honey_badgeria.front.dsl.schemas import FrontendDomainSchema


@dataclass
class FrontendDomain:
    """A complete frontend graph domain.

    Attributes:
        name:         Domain name (snake_case), e.g. ``"dashboard"``.
        ui_graph:     The UI component hierarchy.
        state_graph:  The state ownership graph.
        effect_graph: The effect trigger graph.
        event_graph:  The event flow graph.
    """

    name: str
    ui_graph: UIGraph = field(default_factory=UIGraph)
    state_graph: StateGraph = field(default_factory=StateGraph)
    effect_graph: EffectGraph = field(default_factory=EffectGraph)
    event_graph: EventGraph = field(default_factory=EventGraph)

    # ------------------------------------------------------------------
    # Factory
    # ------------------------------------------------------------------

    @classmethod
    def from_schema(cls, schema: FrontendDomainSchema) -> FrontendDomain:
        """Build a FrontendDomain from a parsed schema."""
        domain = cls(name=schema.name)

        # UI nodes
        for name, ui_schema in schema.ui.items():
            node = UINode(
                name=ui_schema.component,
                view=ui_schema.view,
                reads=list(ui_schema.reads),
                events=dict(ui_schema.events),
                children=list(ui_schema.children),
                props=dict(ui_schema.props),
            )
            domain.ui_graph.add_node(node)

        # State nodes
        for name, state_schema in schema.state.items():
            node = StateNode(
                name=state_schema.state,
                interface=state_schema.interface,
                fields=dict(state_schema.fields),
                mutations=list(state_schema.mutations),
                triggers=list(state_schema.triggers),
                initial=dict(state_schema.initial),
            )
            domain.state_graph.add_node(node)

        # Effect nodes
        for name, effect_schema in schema.effects.items():
            node = EffectNode(
                name=effect_schema.effect,
                watch=list(effect_schema.watch),
                on_event=list(effect_schema.on_event),
                handler=effect_schema.handler,
                effect_type=effect_schema.effect_type,
                mutates=list(effect_schema.mutates),
                debounce_ms=effect_schema.debounce_ms,
            )
            domain.effect_graph.add_node(node)

        # Event nodes
        for name, event_schema in schema.events.items():
            node = EventNode(
                name=event_schema.event,
                flow=list(event_schema.flow),
                source=event_schema.source,
                guards=list(event_schema.guards),
            )
            domain.event_graph.add_node(node)

        return domain

    # ------------------------------------------------------------------
    # Queries
    # ------------------------------------------------------------------

    @property
    def total_nodes(self) -> int:
        """Total number of nodes across all four graphs."""
        return (
            len(self.ui_graph.nodes)
            + len(self.state_graph.nodes)
            + len(self.effect_graph.nodes)
            + len(self.event_graph.nodes)
        )

    def state_dependencies_for_ui(self, component: str) -> list[str]:
        """Get all state nodes a UI component depends on."""
        node = self.ui_graph.nodes.get(component)
        if node is None:
            return []
        return node.state_dependencies

    def full_event_chain(self, event_name: str) -> dict[str, Any]:
        """Trace the full chain from event to UI re-render.

        Returns a dict describing:
            event → mutations → state changes → effects → UI updates
        """
        event = self.event_graph.nodes.get(event_name)
        if event is None:
            return {"error": f"Event {event_name!r} not found"}

        chain: dict[str, Any] = {
            "event": event_name,
            "source": event.source,
            "guards": event.guards,
            "mutations": [],
            "effects": [],
            "ui_updates": [],
        }

        affected_states: set[str] = set()

        # Step 1: mutations
        for step in event.flow:
            parts = step.split(".", 1)
            if len(parts) == 2:
                state_name, mutation = parts
                chain["mutations"].append({
                    "state": state_name,
                    "mutation": mutation,
                })
                affected_states.add(state_name)

        # Step 1b: effects triggered directly by this event (on_event)
        event_effects = self.effect_graph.effects_for_event(event_name)
        for eff in event_effects:
            chain["effects"].append({
                "effect": eff.name,
                "handler": eff.handler,
                "type": eff.effect_type,
                "mutates": eff.mutates,
                "trigger": "on_event",
            })
            affected_states.update(eff.mutates)

        # Step 2: effects triggered by affected states
        for state_name in affected_states:
            effects = self.effect_graph.effects_for_state(state_name)
            for eff in effects:
                chain["effects"].append({
                    "effect": eff.name,
                    "handler": eff.handler,
                    "type": eff.effect_type,
                    "mutates": eff.mutates,
                })
                affected_states.update(eff.mutates)

        # Step 3: UI components that read affected state
        for ui_name, ui_node in self.ui_graph.nodes.items():
            for read in ui_node.reads:
                state_name = read.split(".")[0]
                if state_name in affected_states:
                    chain["ui_updates"].append(ui_name)
                    break

        return chain

    # ------------------------------------------------------------------
    # Serialization
    # ------------------------------------------------------------------

    def to_dict(self) -> dict[str, Any]:
        """Serialize the entire domain to an AI-friendly dict."""
        return {
            "domain": self.name,
            "total_nodes": self.total_nodes,
            "ui_graph": self.ui_graph.to_dict(),
            "state_graph": self.state_graph.to_dict(),
            "effect_graph": self.effect_graph.to_dict(),
            "event_graph": self.event_graph.to_dict(),
        }

    def summary(self) -> dict[str, int]:
        """Quick summary of node counts."""
        return {
            "ui_nodes": len(self.ui_graph.nodes),
            "state_nodes": len(self.state_graph.nodes),
            "effect_nodes": len(self.effect_graph.nodes),
            "event_nodes": len(self.event_graph.nodes),
            "total": self.total_nodes,
        }
