"""State Graph — state ownership and dependencies.

The state graph tracks all application state.  Each state node
defines:

    - fields (the data shape)
    - mutations (how state can change)
    - triggers (which effects fire on change)

State nodes are the **single source of truth** for application
data.  Components never own state — they only read from it.

Dependencies between state nodes are inferred from effects:
if Effect A watches StateX and mutates StateY, then StateY
depends on StateX.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any


@dataclass
class StateNode:
    """A node in the state graph.

    Attributes:
        name:       State name (PascalCase + "State" suffix).
        interface:  TypeScript interface name.
        fields:     Field name → TypeScript type mapping.
        mutations:  List of mutation function names.
        triggers:   Effect names triggered on state change.
        initial:    Optional default values for fields.
    """

    name: str
    interface: str = ""
    fields: dict[str, str] = field(default_factory=dict)
    mutations: list[str] = field(default_factory=list)
    triggers: list[str] = field(default_factory=list)
    initial: dict[str, str] = field(default_factory=dict)

    @property
    def field_names(self) -> list[str]:
        return list(self.fields.keys())

    @property
    def mutation_set(self) -> frozenset[str]:
        return frozenset(self.mutations)

    def has_mutation(self, name: str) -> bool:
        return name in self.mutations

    def __eq__(self, other: object) -> bool:
        if not isinstance(other, StateNode):
            return NotImplemented
        return self.name == other.name

    def __hash__(self) -> int:
        return hash(self.name)


class StateGraph:
    """The state ownership and dependency graph.

    Tracks all state nodes and computes dependency relationships
    between them based on effect declarations.
    """

    def __init__(self) -> None:
        self.nodes: dict[str, StateNode] = {}

    def add_node(self, node: StateNode) -> None:
        """Add a state node."""
        self.nodes[node.name] = node

    def get_node(self, name: str) -> StateNode:
        """Get a state node by name."""
        if name not in self.nodes:
            from honey_badgeria.front.exceptions import FrontendGraphError
            raise FrontendGraphError(f"State node {name!r} not found")
        return self.nodes[name]

    def all_fields(self) -> dict[str, list[str]]:
        """All fields grouped by state node name."""
        return {
            name: node.field_names
            for name, node in self.nodes.items()
        }

    def all_mutations(self) -> dict[str, list[str]]:
        """All mutations grouped by state node name."""
        return {
            name: node.mutations
            for name, node in self.nodes.items()
        }

    def all_triggers(self) -> dict[str, list[str]]:
        """All effect triggers grouped by state node name."""
        return {
            name: node.triggers
            for name, node in self.nodes.items()
        }

    def resolve_field(self, reference: str) -> tuple[str, str]:
        """Resolve a field reference like ``"FilterState.dateRange"``.

        Returns:
            Tuple of (state_name, field_name).

        Raises:
            FrontendGraphError: If the reference is invalid.
        """
        parts = reference.split(".", 1)
        if len(parts) != 2:
            from honey_badgeria.front.exceptions import FrontendGraphError
            raise FrontendGraphError(
                f"Invalid state field reference: {reference!r}"
            )
        state_name, field_name = parts
        node = self.get_node(state_name)
        if field_name not in node.fields:
            from honey_badgeria.front.exceptions import FrontendGraphError
            raise FrontendGraphError(
                f"Field {field_name!r} not found in state {state_name!r}"
            )
        return state_name, field_name

    def to_dict(self) -> dict[str, Any]:
        """Serialize to an AI-friendly dict."""
        return {
            "node_count": len(self.nodes),
            "nodes": {
                name: {
                    "interface": node.interface,
                    "fields": node.fields,
                    "mutations": node.mutations,
                    "triggers": node.triggers,
                }
                for name, node in self.nodes.items()
            },
        }
