"""Event Graph — flows triggered by user events.

Events represent user actions (click, submit, change, drag, etc.)
and trigger ordered sequences of mutations.  This maintains
conceptual symmetry with HBIA backend flows.

The event flow model:

    User Event → [Mutation 1, Mutation 2, ...] → State Changes
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any


@dataclass
class EventNode:
    """A node in the event graph.

    Attributes:
        name:    Event name (snake_case).
        flow:    Ordered list of mutation references to execute.
        source:  Optional UI component that emits this event.
        guards:  Optional state conditions that must be true.
    """

    name: str
    flow: list[str] = field(default_factory=list)
    source: str | None = None
    guards: list[str] = field(default_factory=list)

    @property
    def mutation_steps(self) -> list[tuple[str, str]]:
        """Parse flow steps into (state_name, mutation_name) tuples."""
        steps = []
        for step in self.flow:
            parts = step.split(".", 1)
            if len(parts) == 2:
                steps.append((parts[0], parts[1]))
        return steps

    @property
    def affected_states(self) -> list[str]:
        """All state nodes affected by this event."""
        return sorted(set(s for s, _ in self.mutation_steps))

    def __eq__(self, other: object) -> bool:
        if not isinstance(other, EventNode):
            return NotImplemented
        return self.name == other.name

    def __hash__(self) -> int:
        return hash(self.name)


class EventGraph:
    """The event flow graph.

    Maps user events to ordered mutation sequences.
    """

    def __init__(self) -> None:
        self.nodes: dict[str, EventNode] = {}

    def add_node(self, node: EventNode) -> None:
        """Add an event node."""
        self.nodes[node.name] = node

    def get_node(self, name: str) -> EventNode:
        """Get an event node by name."""
        if name not in self.nodes:
            from honey_badgeria.front.exceptions import FrontendGraphError
            raise FrontendGraphError(f"Event node {name!r} not found")
        return self.nodes[name]

    def events_for_state(self, state_name: str) -> list[EventNode]:
        """Get all events that mutate a given state."""
        return [
            node for node in self.nodes.values()
            if state_name in node.affected_states
        ]

    def events_from_source(self, component_name: str) -> list[EventNode]:
        """Get all events emitted by a given UI component."""
        return [
            node for node in self.nodes.values()
            if node.source == component_name
        ]

    def to_dict(self) -> dict[str, Any]:
        """Serialize to an AI-friendly dict."""
        return {
            "node_count": len(self.nodes),
            "nodes": {
                name: {
                    "flow": node.flow,
                    "source": node.source,
                    "guards": node.guards,
                    "affected_states": node.affected_states,
                }
                for name, node in self.nodes.items()
            },
        }
