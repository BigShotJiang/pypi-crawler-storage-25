"""Effect Graph — side effects triggered by state changes.

Effects are the bridge between state and the outside world.
They watch specific state fields and execute when those fields
change.

Effect types:
    - ``side_effect``: API calls, analytics, websocket events,
      persistence, etc.
    - ``derived``: Computed/derived state from other state fields.

The effect graph maps: state field → effect → optional state mutation.

    State change → triggers Effect → (optional) mutates other State
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any


@dataclass
class EffectNode:
    """A node in the effect graph.

    Attributes:
        name:         Effect name (snake_case).
        watch:        State field references that trigger this effect.
        handler:      Handler function name.
        effect_type:  ``"side_effect"`` or ``"derived"``.
        mutates:      State nodes this effect can write to.
        debounce_ms:  Optional debounce in milliseconds.
    """

    name: str
    watch: list[str] = field(default_factory=list)
    on_event: list[str] = field(default_factory=list)
    handler: str = ""
    effect_type: str = "side_effect"
    mutates: list[str] = field(default_factory=list)
    debounce_ms: int | None = None

    @property
    def watched_states(self) -> list[str]:
        """Extract unique state names from watch list."""
        states = set()
        for ref in self.watch:
            parts = ref.split(".", 1)
            if parts:
                states.add(parts[0])
        return sorted(states)

    @property
    def is_side_effect(self) -> bool:
        return self.effect_type == "side_effect"

    @property
    def is_derived(self) -> bool:
        return self.effect_type == "derived"

    def __eq__(self, other: object) -> bool:
        if not isinstance(other, EffectNode):
            return NotImplemented
        return self.name == other.name

    def __hash__(self) -> int:
        return hash(self.name)


class EffectGraph:
    """The side effect trigger graph.

    Maps state field changes to effects and tracks which state
    nodes effects can mutate.
    """

    def __init__(self) -> None:
        self.nodes: dict[str, EffectNode] = {}

    def add_node(self, node: EffectNode) -> None:
        """Add an effect node."""
        self.nodes[node.name] = node

    def get_node(self, name: str) -> EffectNode:
        """Get an effect node by name."""
        if name not in self.nodes:
            from honey_badgeria.front.exceptions import FrontendGraphError
            raise FrontendGraphError(f"Effect node {name!r} not found")
        return self.nodes[name]

    def effects_for_state(self, state_name: str) -> list[EffectNode]:
        """Get all effects triggered by a given state node."""
        return [
            node for node in self.nodes.values()
            if state_name in node.watched_states
        ]

    def effects_for_field(self, field_reference: str) -> list[EffectNode]:
        """Get all effects triggered by a specific state field."""
        return [
            node for node in self.nodes.values()
            if field_reference in node.watch
        ]

    def effects_for_event(self, event_name: str) -> list[EffectNode]:
        """Get all effects triggered by a given event."""
        return [
            node for node in self.nodes.values()
            if event_name in node.on_event
        ]

    def mutation_targets(self) -> dict[str, list[str]]:
        """Map of effect name → state nodes it can mutate."""
        return {
            name: node.mutates
            for name, node in self.nodes.items()
            if node.mutates
        }

    def trigger_chain(self, state_name: str) -> list[dict[str, Any]]:
        """Compute the full trigger chain from a state change.

        Returns a list of steps showing how a state change
        propagates through effects and back to state mutations.
        """
        chain: list[dict[str, Any]] = []
        visited: set[str] = set()
        queue = [state_name]

        while queue:
            current_state = queue.pop(0)
            if current_state in visited:
                continue
            visited.add(current_state)

            effects = self.effects_for_state(current_state)
            for effect in effects:
                step = {
                    "trigger": current_state,
                    "effect": effect.name,
                    "handler": effect.handler,
                    "type": effect.effect_type,
                    "mutates": effect.mutates,
                }
                chain.append(step)
                for target in effect.mutates:
                    if target not in visited:
                        queue.append(target)

        return chain

    def to_dict(self) -> dict[str, Any]:
        """Serialize to an AI-friendly dict."""
        return {
            "node_count": len(self.nodes),
            "nodes": {
                name: {
                    "watch": node.watch,
                    "on_event": node.on_event,
                    "handler": node.handler,
                    "effect_type": node.effect_type,
                    "mutates": node.mutates,
                    "debounce_ms": node.debounce_ms,
                }
                for name, node in self.nodes.items()
            },
        }
