"""UI Graph — component hierarchy and rendering structure.

The UI graph is a **tree** (not a DAG) representing the component
hierarchy.  Each node is a pure render function that:

    - receives data from state nodes (``reads``)
    - renders UI (``view``)
    - emits events (``events``)

UI nodes never own state, contain hooks, or execute side effects.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any


@dataclass
class UINode:
    """A node in the UI graph.

    Attributes:
        name:       Component name (PascalCase).
        view:       View file reference.
        reads:      State field references this component subscribes to.
        events:     Event name → event identifier mapping.
        children:   Child component names.
        props:      Static props passed from parent.
    """

    name: str
    view: str = ""
    reads: list[str] = field(default_factory=list)
    events: dict[str, str] = field(default_factory=dict)
    children: list[str] = field(default_factory=list)
    props: dict[str, str] = field(default_factory=dict)

    @property
    def state_dependencies(self) -> list[str]:
        """Extract unique state node names from reads.

        Example: ``["FilterState.dateRange", "ChartState.series"]``
        → ``["FilterState", "ChartState"]``
        """
        states = set()
        for read in self.reads:
            parts = read.split(".", 1)
            if parts:
                states.add(parts[0])
        return sorted(states)

    def __eq__(self, other: object) -> bool:
        if not isinstance(other, UINode):
            return NotImplemented
        return self.name == other.name

    def __hash__(self) -> int:
        return hash(self.name)


class UIGraph:
    """The UI component hierarchy graph.

    This is a tree structure where each node can have children.
    The root node is the top-level page/layout component.
    """

    def __init__(self) -> None:
        self.nodes: dict[str, UINode] = {}
        self._root: str | None = None

    def add_node(self, node: UINode) -> None:
        """Add a UI node to the graph."""
        self.nodes[node.name] = node

    @property
    def root(self) -> str | None:
        """The root component (the one not listed as any child)."""
        if self._root is not None:
            return self._root
        all_children: set[str] = set()
        for node in self.nodes.values():
            all_children.update(node.children)
        roots = [n for n in self.nodes if n not in all_children]
        return roots[0] if len(roots) == 1 else None

    @root.setter
    def root(self, value: str) -> None:
        self._root = value

    def get_subtree(self, name: str) -> list[str]:
        """Get all descendant names (BFS) from a given node."""
        visited: list[str] = []
        queue = [name]
        while queue:
            current = queue.pop(0)
            if current in self.nodes and current not in visited:
                visited.append(current)
                queue.extend(self.nodes[current].children)
        return visited

    def all_reads(self) -> list[str]:
        """All state field references across all UI nodes."""
        reads: set[str] = set()
        for node in self.nodes.values():
            reads.update(node.reads)
        return sorted(reads)

    def all_events(self) -> dict[str, str]:
        """All events emitted across all UI nodes."""
        events: dict[str, str] = {}
        for node in self.nodes.values():
            events.update(node.events)
        return events

    def to_dict(self) -> dict[str, Any]:
        """Serialize to an AI-friendly dict."""
        return {
            "root": self.root,
            "node_count": len(self.nodes),
            "nodes": {
                name: {
                    "view": node.view,
                    "reads": node.reads,
                    "events": node.events,
                    "children": node.children,
                }
                for name, node in self.nodes.items()
            },
        }
