"""Frontend-specific exceptions.

Hierarchy:

    HoneyBadgeriaError  (from core)
    └── FrontendError
        ├── FrontendDSLValidationError
        ├── FrontendGraphError
        ├── FrontendCodegenError
        └── FrontendLintError
"""

from __future__ import annotations

from honey_badgeria.core.exceptions import HoneyBadgeriaError


class FrontendError(HoneyBadgeriaError):
    """Base error for all frontend operations."""


class FrontendDSLValidationError(FrontendError):
    """Validation of a frontend YAML definition failed."""

    def __init__(self, message: str, errors: list[str] | None = None) -> None:
        super().__init__(message)
        self.errors: list[str] = errors or []


class FrontendGraphError(FrontendError):
    """Error in frontend graph construction or analysis."""


class FrontendCodegenError(FrontendError):
    """Error during TypeScript code generation."""


class FrontendLintError(FrontendError):
    """Lint issue detected in frontend definitions."""
