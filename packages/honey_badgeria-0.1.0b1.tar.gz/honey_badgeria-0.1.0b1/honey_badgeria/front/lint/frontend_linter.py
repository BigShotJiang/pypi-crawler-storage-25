"""Frontend linter: AI-oriented quality checks for frontend definitions.

Beyond structural validation, the linter checks for design quality
issues that affect AI comprehension:

    - Unused state (declared but never read by UI or effects)
    - Dead events (declared but not referenced by any UI component)
    - Orphaned effects (declared but never triggered)
    - Overly broad state (too many fields in a single state node)
    - Missing interfaces (state nodes without TypeScript interface)
    - Circular effect chains (effects that create infinite loops)

File-level checks (run via ``lint_files``):

    - localStorage/sessionStorage usage (FORBIDDEN)
    - Raw error exposure in UI components

Usage::

    from honey_badgeria.front.lint import FrontendLinter

    linter = FrontendLinter()
    issues = linter.lint(domain)
    for issue in issues:
        print(f"  [{issue.severity}] {issue.message}")
"""

from __future__ import annotations

import re
from dataclasses import dataclass
from pathlib import Path
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from honey_badgeria.front.graph.domain import FrontendDomain


@dataclass
class FrontendLintIssue:
    """A lint issue found in a frontend domain.

    Attributes:
        severity:  ``"error"``, ``"warning"``, or ``"info"``.
        category:  Issue category (e.g. ``"unused_state"``).
        message:   Human-readable description.
        node_type: The graph type involved (``"ui"``, ``"state"``, etc.).
        node_name: The specific node name.
    """

    severity: str
    category: str
    message: str
    node_type: str = ""
    node_name: str = ""


class FrontendLinter:
    """AI-oriented linter for frontend graph domains."""

    # Maximum fields before a state node is considered overly broad
    MAX_STATE_FIELDS = 10

    def lint(self, domain: FrontendDomain) -> list[FrontendLintIssue]:
        """Run all lint checks on a domain.

        Returns:
            List of lint issues (empty if clean).
        """
        issues: list[FrontendLintIssue] = []
        issues.extend(self._check_unused_state(domain))
        issues.extend(self._check_dead_events(domain))
        issues.extend(self._check_orphaned_effects(domain))
        issues.extend(self._check_broad_state(domain))
        issues.extend(self._check_missing_interfaces(domain))
        issues.extend(self._check_circular_effects(domain))
        issues.extend(self._check_naming_conventions(domain))
        issues.extend(self._check_effect_has_trigger(domain))
        return issues

    # ------------------------------------------------------------------
    # Checks
    # ------------------------------------------------------------------

    def _check_unused_state(self, domain: FrontendDomain) -> list[FrontendLintIssue]:
        """State nodes that are never read by any UI component or effect."""
        issues: list[FrontendLintIssue] = []

        # Collect all state references from UI reads
        referenced_states: set[str] = set()
        for ui_node in domain.ui_graph.nodes.values():
            for read in ui_node.reads:
                parts = read.split(".", 1)
                if parts:
                    referenced_states.add(parts[0])

        # Collect state references from effect watches
        for effect in domain.effect_graph.nodes.values():
            for watch in effect.watch:
                parts = watch.split(".", 1)
                if parts:
                    referenced_states.add(parts[0])

        # Collect state references from event flows
        for event in domain.event_graph.nodes.values():
            for step in event.flow:
                parts = step.split(".", 1)
                if parts:
                    referenced_states.add(parts[0])

        for state_name in domain.state_graph.nodes:
            if state_name not in referenced_states:
                issues.append(FrontendLintIssue(
                    severity="warning",
                    category="unused_state",
                    message=(
                        f"State '{state_name}' is declared but never read "
                        f"by any UI component, effect, or event"
                    ),
                    node_type="state",
                    node_name=state_name,
                ))

        return issues

    def _check_dead_events(self, domain: FrontendDomain) -> list[FrontendLintIssue]:
        """Events that are declared but not emitted by any UI component."""
        issues: list[FrontendLintIssue] = []

        # Collect all events referenced by UI components
        emitted_events: set[str] = set()
        for ui_node in domain.ui_graph.nodes.values():
            emitted_events.update(ui_node.events.values())

        for event_name in domain.event_graph.nodes:
            if event_name not in emitted_events:
                issues.append(FrontendLintIssue(
                    severity="warning",
                    category="dead_event",
                    message=(
                        f"Event '{event_name}' is declared but not emitted "
                        f"by any UI component"
                    ),
                    node_type="event",
                    node_name=event_name,
                ))

        return issues

    def _check_orphaned_effects(self, domain: FrontendDomain) -> list[FrontendLintIssue]:
        """Effects not referenced as triggers by any state node."""
        issues: list[FrontendLintIssue] = []

        # Collect all effect names referenced by state triggers
        triggered_effects: set[str] = set()
        for state in domain.state_graph.nodes.values():
            triggered_effects.update(state.triggers)

        # Also consider effects triggered by events (on_event)
        for effect in domain.effect_graph.nodes.values():
            if effect.on_event:
                triggered_effects.add(effect.name)

        for effect_name in domain.effect_graph.nodes:
            if effect_name not in triggered_effects:
                issues.append(FrontendLintIssue(
                    severity="info",
                    category="orphaned_effect",
                    message=(
                        f"Effect '{effect_name}' is not listed as a trigger "
                        f"in any state node — it will still run via watch, "
                        f"but the trigger chain may be unclear"
                    ),
                    node_type="effect",
                    node_name=effect_name,
                ))

        return issues

    def _check_broad_state(self, domain: FrontendDomain) -> list[FrontendLintIssue]:
        """State nodes with too many fields (reduces AI comprehension)."""
        issues: list[FrontendLintIssue] = []

        for name, node in domain.state_graph.nodes.items():
            if len(node.fields) > self.MAX_STATE_FIELDS:
                issues.append(FrontendLintIssue(
                    severity="warning",
                    category="broad_state",
                    message=(
                        f"State '{name}' has {len(node.fields)} fields — "
                        f"consider splitting into smaller state nodes "
                        f"(max recommended: {self.MAX_STATE_FIELDS})"
                    ),
                    node_type="state",
                    node_name=name,
                ))

        return issues

    def _check_missing_interfaces(self, domain: FrontendDomain) -> list[FrontendLintIssue]:
        """State nodes without TypeScript interface names."""
        issues: list[FrontendLintIssue] = []

        for name, node in domain.state_graph.nodes.items():
            if not node.interface:
                issues.append(FrontendLintIssue(
                    severity="warning",
                    category="missing_interface",
                    message=(
                        f"State '{name}' has no TypeScript interface declared — "
                        f"add an 'interface' field for type safety"
                    ),
                    node_type="state",
                    node_name=name,
                ))

        return issues

    def _check_circular_effects(self, domain: FrontendDomain) -> list[FrontendLintIssue]:
        """Detect circular effect chains that could cause infinite loops.

        A circular chain exists when:
        Effect A watches StateX, mutates StateY
        Effect B watches StateY, mutates StateX
        """
        issues: list[FrontendLintIssue] = []

        # Build a dependency graph: state → (via effect) → state
        state_deps: dict[str, set[str]] = {}
        for effect in domain.effect_graph.nodes.values():
            for watched_state in effect.watched_states:
                for mutated_state in effect.mutates:
                    state_deps.setdefault(watched_state, set()).add(mutated_state)

        # Detect cycles using DFS
        visited: set[str] = set()
        in_stack: set[str] = set()

        def dfs(state: str, path: list[str]) -> None:
            if state in in_stack:
                cycle = path[path.index(state):] + [state]
                issues.append(FrontendLintIssue(
                    severity="error",
                    category="circular_effects",
                    message=(
                        f"Circular effect chain detected: "
                        f"{' → '.join(cycle)}"
                    ),
                    node_type="effect",
                    node_name=state,
                ))
                return
            if state in visited:
                return

            visited.add(state)
            in_stack.add(state)

            for next_state in state_deps.get(state, set()):
                dfs(next_state, path + [state])

            in_stack.discard(state)

        for state in state_deps:
            visited.clear()
            in_stack.clear()
            dfs(state, [])

        return issues

    def _check_naming_conventions(self, domain: FrontendDomain) -> list[FrontendLintIssue]:
        """Check naming conventions for AI clarity."""
        issues: list[FrontendLintIssue] = []

        # State nodes should end with "State"
        for name in domain.state_graph.nodes:
            if not name.endswith("State"):
                issues.append(FrontendLintIssue(
                    severity="info",
                    category="naming",
                    message=(
                        f"State node '{name}' should follow PascalCase + "
                        f"'State' suffix convention (e.g. '{name}State')"
                    ),
                    node_type="state",
                    node_name=name,
                ))

        # UI components should be PascalCase
        for name in domain.ui_graph.nodes:
            if name and name[0].islower():
                issues.append(FrontendLintIssue(
                    severity="info",
                    category="naming",
                    message=(
                        f"UI component '{name}' should be PascalCase"
                    ),
                    node_type="ui",
                    node_name=name,
                ))

        return issues

    def _check_effect_has_trigger(self, domain: FrontendDomain) -> list[FrontendLintIssue]:
        """Effects must have at least one trigger mechanism (watch or on_event)."""
        issues: list[FrontendLintIssue] = []
        for name, node in domain.effect_graph.nodes.items():
            if not node.watch and not node.on_event:
                issues.append(FrontendLintIssue(
                    severity="warning",
                    category="untriggered_effect",
                    message=(
                        f"Effect '{name}' has no 'watch' or 'on_event' — "
                        f"it will never be triggered"
                    ),
                    node_type="effect",
                    node_name=name,
                ))
        return issues

    # ------------------------------------------------------------------
    # File-level checks (scan .ts/.tsx source files)
    # ------------------------------------------------------------------

    _LOCAL_STORAGE_RE = re.compile(
        r"\b(localStorage|sessionStorage|window\.localStorage|window\.sessionStorage)\b"
    )
    _RAW_ERROR_RE = re.compile(
        r"\b(error\.(stack|message|toString\(\))|\.stack\b|traceback|stackTrace)"
    )

    def lint_files(self, root: str) -> list[FrontendLintIssue]:
        """Scan TypeScript/TSX files for forbidden patterns.

        Checks:
        - ``localStorage`` / ``sessionStorage`` usage (FORBIDDEN)
        - Raw error exposure patterns in UI components

        Args:
            root: Directory to scan recursively.

        Returns:
            List of lint issues.
        """
        issues: list[FrontendLintIssue] = []
        root_path = Path(root)
        if not root_path.exists():
            return issues

        for ext in ("*.ts", "*.tsx"):
            for fpath in root_path.rglob(ext):
                try:
                    content = fpath.read_text(encoding="utf-8")
                except OSError:
                    continue
                issues.extend(self._check_localstorage(fpath, content))
        return issues

    def _check_localstorage(
        self, fpath: Path, content: str,
    ) -> list[FrontendLintIssue]:
        """Flag any localStorage/sessionStorage usage as an error."""
        issues: list[FrontendLintIssue] = []
        for i, line in enumerate(content.splitlines(), 1):
            if self._LOCAL_STORAGE_RE.search(line):
                issues.append(FrontendLintIssue(
                    severity="error",
                    category="localStorage_forbidden",
                    message=(
                        f"FORBIDDEN: localStorage/sessionStorage detected "
                        f"at {fpath}:{i} — localStorage is banned in HBIA "
                        f"projects. It creates invisible untracked state "
                        f"outside the graph. Use the HBIA State graph for "
                        f"persistence, React Context for ephemeral data, or "
                        f"HTTP-only cookies for auth tokens."
                    ),
                    node_type="file",
                    node_name=str(fpath),
                ))
        return issues
