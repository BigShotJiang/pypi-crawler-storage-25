"""Frontend lint module — AI-oriented linting for frontend definitions."""

from honey_badgeria.front.lint.frontend_linter import FrontendLinter, FrontendLintIssue

__all__ = ["FrontendLinter", "FrontendLintIssue"]
