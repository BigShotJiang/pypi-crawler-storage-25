"""Frontend code generation — TypeScript runtime from YAML definitions.

Exports:
    FrontendCodegen     — Main orchestrator for generating all files
    generate_runtime    — Generate the HBIA runtime module
    generate_types      — Generate TypeScript interfaces
    generate_store      — Generate state store code
"""

from honey_badgeria.front.codegen.runtime_gen import FrontendCodegen

__all__ = ["FrontendCodegen"]
