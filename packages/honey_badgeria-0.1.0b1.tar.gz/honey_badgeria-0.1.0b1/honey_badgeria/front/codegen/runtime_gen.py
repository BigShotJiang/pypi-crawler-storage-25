"""Frontend codegen: generates the complete HBIA TypeScript runtime.

The codegen reads FrontendDomain objects and produces:

    hbia-runtime/
        index.ts        — Re-exports everything
        store.ts        — Central state store (pub/sub, no external deps)
        effects.ts      — Effect watcher system
        events.ts       — Event dispatcher
        react.tsx       — React hooks & provider
        types.ts        — Generated TypeScript interfaces

The generated runtime is self-contained — no external state
management library required.  It uses:

    - Plain TypeScript for the store core
    - ``useSyncExternalStore`` for React integration
    - A pub/sub pattern for reactivity

This keeps the runtime completely auditable by AI agents.
"""

from __future__ import annotations

import os
from typing import Any

from honey_badgeria.front.graph.domain import FrontendDomain


class FrontendCodegen:
    """Generates the complete HBIA frontend runtime from domain definitions.

    Usage::

        codegen = FrontendCodegen(domains=[dashboard_domain, auth_domain])
        codegen.generate(output_dir="front/hbia-runtime")
    """

    def __init__(self, domains: list[FrontendDomain]) -> None:
        self.domains = domains

    def generate(self, output_dir: str) -> list[str]:
        """Generate all runtime files.

        Args:
            output_dir: Directory to write generated files to.

        Returns:
            List of generated file paths.
        """
        os.makedirs(output_dir, exist_ok=True)
        generated: list[str] = []

        files = {
            "types.ts": self._generate_types(),
            "store.ts": self._generate_store(),
            "effects.ts": self._generate_effects(),
            "events.ts": self._generate_events(),
            "react.tsx": self._generate_react(),
            "index.ts": self._generate_index(),
        }

        for filename, content in files.items():
            filepath = os.path.join(output_dir, filename)
            with open(filepath, "w") as f:
                f.write(content)
            generated.append(filepath)

        return generated

    # ------------------------------------------------------------------
    # Type Generation
    # ------------------------------------------------------------------

    def _generate_types(self) -> str:
        """Generate TypeScript interfaces for all state nodes."""
        lines = [
            "// ============================================================",
            "// HBIA Generated Types — DO NOT EDIT MANUALLY",
            "// Generated from YAML graph definitions.",
            "// ============================================================",
            "",
        ]

        for domain in self.domains:
            lines.append(f"// --- Domain: {domain.name} ---")
            lines.append("")

            for name, node in domain.state_graph.nodes.items():
                interface_name = node.interface or f"{name}Data"
                lines.append(f"export interface {interface_name} {{")
                for field_name, field_type in node.fields.items():
                    ts_type = _to_ts_type(field_type)
                    lines.append(f"  {field_name}: {ts_type}")
                lines.append("}")
                lines.append("")

        # Generate aggregate state type
        lines.append("// --- Aggregate State ---")
        lines.append("")
        lines.append("export interface HBIAState {")
        for domain in self.domains:
            for name, node in domain.state_graph.nodes.items():
                interface_name = node.interface or f"{name}Data"
                lines.append(f"  {name}: {interface_name}")
        lines.append("}")
        lines.append("")

        # Generate event payload types
        lines.append("// --- Event Types ---")
        lines.append("")
        for domain in self.domains:
            for event_name, event in domain.event_graph.nodes.items():
                type_name = _to_pascal(event_name) + "Payload"
                lines.append(f"export interface {type_name} {{")
                lines.append("  [key: string]: unknown")
                lines.append("}")
                lines.append("")

        return "\n".join(lines)

    # ------------------------------------------------------------------
    # Store Generation
    # ------------------------------------------------------------------

    def _generate_store(self) -> str:
        """Generate the central state store with pub/sub."""
        lines = [
            "// ============================================================",
            "// HBIA State Store — DO NOT EDIT MANUALLY",
            "// Pure TypeScript pub/sub store. No external dependencies.",
            "// ============================================================",
            "",
            'import type { HBIAState } from "./types"',
            "",
            "type Listener = () => void",
            "type Selector<T> = (state: HBIAState) => T",
            "",
            "// --- Initial State ---",
            "",
            "const initialState: HBIAState = {",
        ]

        for domain in self.domains:
            for name, node in domain.state_graph.nodes.items():
                lines.append(f"  {name}: {{")
                for field_name, field_type in node.fields.items():
                    default = node.initial.get(field_name)
                    if default is not None:
                        lines.append(f"    {field_name}: {_ts_literal(default, field_type)},")
                    else:
                        lines.append(f"    {field_name}: {_ts_default(field_type)},")
                lines.append("  },")

        lines.extend([
            "}",
            "",
            "// --- Store Implementation ---",
            "",
            "let state: HBIAState = { ...initialState }",
            "const listeners: Set<Listener> = new Set()",
            "",
            "function notify(): void {",
            "  listeners.forEach((listener) => listener())",
            "}",
            "",
            "export const store = {",
            "  getState(): HBIAState {",
            "    return state",
            "  },",
            "",
            "  getSnapshot(): HBIAState {",
            "    return state",
            "  },",
            "",
            "  subscribe(listener: Listener): () => void {",
            "    listeners.add(listener)",
            "    return () => listeners.delete(listener)",
            "  },",
            "",
            "  select<T>(selector: Selector<T>): T {",
            "    return selector(state)",
            "  },",
            "",
        ])

        # Generate mutation methods
        lines.append("  // --- Mutations ---")
        lines.append("")

        for domain in self.domains:
            for state_name, node in domain.state_graph.nodes.items():
                for mutation in node.mutations:
                    lines.append(
                        f"  {mutation}(payload: Partial<"
                        f"{node.interface or state_name + 'Data'}>): void {{"
                    )
                    lines.append(f"    state = {{")
                    lines.append(f"      ...state,")
                    lines.append(f"      {state_name}: {{")
                    lines.append(f"        ...state.{state_name},")
                    lines.append(f"        ...payload,")
                    lines.append(f"      }},")
                    lines.append(f"    }}")
                    lines.append(f"    notify()")
                    lines.append(f"  }},")
                    lines.append("")

        lines.extend([
            "  // --- Reset ---",
            "",
            "  reset(): void {",
            "    state = { ...initialState }",
            "    notify()",
            "  },",
            "}",
            "",
        ])

        return "\n".join(lines)

    # ------------------------------------------------------------------
    # Effects Generation
    # ------------------------------------------------------------------

    def _generate_effects(self) -> str:
        """Generate the effect watcher system."""
        lines = [
            "// ============================================================",
            "// HBIA Effect System — DO NOT EDIT MANUALLY",
            "// Watches state changes and triggers side effects.",
            "// ============================================================",
            "",
            'import { store } from "./store"',
            'import type { HBIAState } from "./types"',
            "",
            "type EffectHandler = (",
            "  state: HBIAState,",
            "  services: Record<string, unknown>",
            ") => void | Promise<void>",
            "",
            "interface EffectDefinition {",
            "  name: string",
            "  watch: ((state: HBIAState) => unknown)[]",
            "  handler: EffectHandler",
            "  debounceMs?: number",
            "}",
            "",
            "const effects: EffectDefinition[] = []",
            "const services: Record<string, unknown> = {}",
            "",
            "export function registerService(",
            "  name: string,",
            "  service: unknown",
            "): void {",
            "  services[name] = service",
            "}",
            "",
            "export function registerEffect(effect: EffectDefinition): void {",
            "  effects.push(effect)",
            "}",
            "",
            "// --- Effect Watcher ---",
            "",
            "let previousState: HBIAState = store.getState()",
            "const debounceTimers: Map<string, ReturnType<typeof setTimeout>> = new Map()",
            "",
            "function checkEffects(): void {",
            "  const currentState = store.getState()",
            "",
            "  for (const effect of effects) {",
            "    const changed = effect.watch.some(",
            "      (selector) => selector(previousState) !== selector(currentState)",
            "    )",
            "",
            "    if (changed) {",
            "      if (effect.debounceMs) {",
            "        const existing = debounceTimers.get(effect.name)",
            "        if (existing) clearTimeout(existing)",
            "        debounceTimers.set(",
            "          effect.name,",
            "          setTimeout(() => {",
            "            effect.handler(currentState, services)",
            "          }, effect.debounceMs)",
            "        )",
            "      } else {",
            "        effect.handler(currentState, services)",
            "      }",
            "    }",
            "  }",
            "",
            "  previousState = currentState",
            "}",
            "",
            "// Subscribe to store changes",
            "store.subscribe(checkEffects)",
            "",
            "// --- Pre-registered Effects from YAML ---",
            "",
        ]

        for domain in self.domains:
            for eff_name, eff in domain.effect_graph.nodes.items():
                watch_selectors = []
                for watch in eff.watch:
                    parts = watch.split(".", 1)
                    if len(parts) == 2:
                        watch_selectors.append(
                            f"(s: HBIAState) => s.{parts[0]}.{parts[1]}"
                        )

                lines.append(f"// Effect: {eff_name}")
                lines.append(
                    f"// Placeholder — import your handler and register it:"
                )
                lines.append(
                    f"// registerEffect({{ name: '{eff_name}', "
                    f"watch: [{', '.join(watch_selectors)}], "
                    f"handler: {eff.handler}"
                    f"{f', debounceMs: {eff.debounce_ms}' if eff.debounce_ms else ''}"
                    f" }})"
                )
                lines.append("")

        # --- Event-triggered effects infrastructure ---
        lines.extend([
            "// --- Event-triggered Effects ---",
            "",
            "const eventEffects: Map<string, EffectHandler[]> = new Map()",
            "",
            "export function registerEventEffect(",
            "  eventName: string,",
            "  handler: EffectHandler",
            "): void {",
            "  const handlers = eventEffects.get(eventName) || []",
            "  handlers.push(handler)",
            "  eventEffects.set(eventName, handlers)",
            "}",
            "",
            "export function triggerEventEffects(",
            "  eventName: string,",
            "): void {",
            "  const handlers = eventEffects.get(eventName) || []",
            "  const currentState = store.getState()",
            "  for (const handler of handlers) {",
            "    handler(currentState, services)",
            "  }",
            "}",
            "",
        ])

        # Register event-triggered effects from YAML definitions
        for domain in self.domains:
            for eff_name, eff in domain.effect_graph.nodes.items():
                for event_ref in eff.on_event:
                    lines.append(
                        f"// Effect: {eff_name} (triggered by event: {event_ref})"
                    )
                    lines.append(
                        f"// registerEventEffect(\"{event_ref}\", {eff.handler})"
                    )
                    lines.append("")

        return "\n".join(lines)

    # ------------------------------------------------------------------
    # Events Generation
    # ------------------------------------------------------------------

    def _generate_events(self) -> str:
        """Generate the event dispatcher."""
        lines = [
            "// ============================================================",
            "// HBIA Event Dispatcher — DO NOT EDIT MANUALLY",
            "// Maps user events to mutation sequences.",
            "// ============================================================",
            "",
            'import { store } from "./store"',
            'import { triggerEventEffects } from "./effects"',
            "",
        ]

        for domain in self.domains:
            for event_name, event in domain.event_graph.nodes.items():
                fn_name = _to_camel(event_name)
                lines.append(f"/**")
                lines.append(f" * Event: {event_name}")
                if event.source:
                    lines.append(f" * Source: {event.source}")
                lines.append(f" * Flow: {' → '.join(event.flow)}")
                lines.append(f" */")
                lines.append(
                    f"export function {fn_name}(payload: Record<string, unknown> = {{}}): void {{"
                )

                # Guards
                for guard in event.guards:
                    parts = guard.split(".", 1)
                    if len(parts) == 2:
                        lines.append(f"  if (!store.getState().{parts[0]}.{parts[1]}) return")

                # Mutation flow
                for step in event.flow:
                    parts = step.split(".", 1)
                    if len(parts) == 2:
                        state_name, mutation = parts
                        lines.append(f"  store.{mutation}(payload)")

                lines.append(f'  triggerEventEffects("{event_name}")')
                lines.append("}")
                lines.append("")

        return "\n".join(lines)

    # ------------------------------------------------------------------
    # React Hooks Generation
    # ------------------------------------------------------------------

    def _generate_react(self) -> str:
        """Generate React hooks and provider."""
        lines = [
            "// ============================================================",
            "// HBIA React Integration — DO NOT EDIT MANUALLY",
            "// Hooks and provider for connecting HBIA store to React.",
            "// Uses useSyncExternalStore — no external state library needed.",
            "// ============================================================",
            "",
            '"use client"',
            "",
            'import { useSyncExternalStore, useCallback } from "react"',
            'import { store } from "./store"',
            'import type { HBIAState } from "./types"',
            "",
            "// --- Core Hook ---",
            "",
            "/**",
            " * Subscribe to a slice of HBIA state.",
            " * Re-renders only when the selected value changes.",
            " */",
            "export function useHBIA<T>(selector: (state: HBIAState) => T): T {",
            "  return useSyncExternalStore(",
            "    store.subscribe,",
            "    () => selector(store.getState()),",
            "    () => selector(store.getState())",
            "  )",
            "}",
            "",
            "// --- Typed State Hooks ---",
            "",
        ]

        # Generate typed hooks per state node
        for domain in self.domains:
            for state_name, node in domain.state_graph.nodes.items():
                interface_name = node.interface or f"{state_name}Data"
                hook_name = f"use{state_name}"
                lines.append(f"/**")
                lines.append(f" * Read {state_name} from the HBIA store.")
                lines.append(f" * Re-renders when any field in {state_name} changes.")
                lines.append(f" */")
                lines.append(
                    f"export function {hook_name}(): {interface_name} {{"
                )
                lines.append(
                    f"  return useHBIA((s) => s.{state_name})"
                )
                lines.append("}")
                lines.append("")

        # Generate event dispatcher hooks
        lines.append("// --- Event Hooks ---")
        lines.append("")
        lines.append('import * as events from "./events"')
        lines.append("")

        for domain in self.domains:
            for event_name, event in domain.event_graph.nodes.items():
                hook_name = f"use{_to_pascal(event_name)}"
                fn_name = _to_camel(event_name)
                lines.append(f"/**")
                lines.append(f" * Dispatch the {event_name} event.")
                lines.append(f" * Flow: {' → '.join(event.flow)}")
                lines.append(f" */")
                lines.append(
                    f"export function {hook_name}() {{"
                )
                lines.append(
                    f"  return useCallback("
                    f"(payload?: Record<string, unknown>) => "
                    f"events.{fn_name}(payload ?? {{}}), [])"
                )
                lines.append("}")
                lines.append("")

        return "\n".join(lines)

    # ------------------------------------------------------------------
    # Index Generation
    # ------------------------------------------------------------------

    def _generate_index(self) -> str:
        """Generate the barrel export file."""
        lines = [
            "// ============================================================",
            "// HBIA Runtime — barrel export",
            "// ============================================================",
            "",
            'export { store } from "./store"',
            'export type { HBIAState } from "./types"',
            'export * from "./types"',
            'export * from "./events"',
            'export * from "./effects"',
            'export { triggerEventEffects, registerEventEffect } from "./effects"',
            'export { useHBIA } from "./react"',
            "",
            "// --- Typed hooks ---",
        ]

        for domain in self.domains:
            for state_name in domain.state_graph.nodes:
                lines.append(
                    f'export {{ use{state_name} }} from "./react"'
                )
            for event_name in domain.event_graph.nodes:
                hook_name = f"use{_to_pascal(event_name)}"
                lines.append(
                    f'export {{ {hook_name} }} from "./react"'
                )

        lines.append("")
        return "\n".join(lines)


# ======================================================================
# Helpers
# ======================================================================

def _to_ts_type(python_type: str) -> str:
    """Convert a Python/YAML type hint to TypeScript."""
    mapping = {
        "str": "string",
        "string": "string",
        "int": "number",
        "float": "number",
        "number": "number",
        "bool": "boolean",
        "boolean": "boolean",
        "list": "unknown[]",
        "dict": "Record<string, unknown>",
        "any": "unknown",
        "null": "null",
        "none": "null",
    }
    lower = python_type.lower().strip()
    # Handle arrays: "string[]" or "list[string]"
    if lower.endswith("[]"):
        inner = lower[:-2]
        return f"{_to_ts_type(inner)}[]"
    if lower.startswith("list[") and lower.endswith("]"):
        inner = lower[5:-1]
        return f"{_to_ts_type(inner)}[]"
    return mapping.get(lower, python_type)


def _ts_default(ts_type: str) -> str:
    """Get a TypeScript default value for a type."""
    lower = ts_type.lower().strip()
    if lower in ("str", "string"):
        return '""'
    if lower in ("int", "float", "number"):
        return "0"
    if lower in ("bool", "boolean"):
        return "false"
    if lower.endswith("[]") or lower.startswith("list"):
        return "[]"
    if lower in ("dict",) or lower.startswith("record"):
        return "{}"
    return "null as unknown"


def _ts_literal(value: str, type_hint: str) -> str:
    """Convert a YAML default value to a TypeScript literal."""
    lower_type = type_hint.lower()
    if lower_type in ("str", "string"):
        return f'"{value}"'
    if lower_type in ("bool", "boolean"):
        return "true" if str(value).lower() in ("true", "1") else "false"
    return str(value)


def _to_pascal(snake: str) -> str:
    """Convert snake_case to PascalCase."""
    return "".join(word.capitalize() for word in snake.split("_"))


def _to_camel(snake: str) -> str:
    """Convert snake_case to camelCase."""
    parts = snake.split("_")
    return parts[0] + "".join(w.capitalize() for w in parts[1:])
