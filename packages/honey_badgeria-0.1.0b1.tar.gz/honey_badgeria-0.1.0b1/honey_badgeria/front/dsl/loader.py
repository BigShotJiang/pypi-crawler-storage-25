"""Frontend DSL loader: high-level API for loading frontend domains.

Usage::

    from honey_badgeria.front.dsl.loader import load_frontend_domain

    # Load a single domain
    domain = load_frontend_domain("graph/dashboard")

    # Load all domains under graph/
    domains = load_all_frontend_domains("graph")

    # Load and validate
    domain = load_frontend_domain("graph/dashboard", validate=True)
"""

from __future__ import annotations

import os

from honey_badgeria.front.dsl.parser import (
    parse_domain_directory,
    parse_graph_directory,
)
from honey_badgeria.front.dsl.validator import FrontendDSLValidator
from honey_badgeria.front.graph.domain import FrontendDomain


def load_frontend_domain(
    domain_path: str,
    validate: bool = True,
) -> FrontendDomain:
    """Load a frontend domain from a directory.

    Args:
        domain_path: Path to the domain directory
                     (e.g. ``graph/dashboard``).
        validate:    If True, run validation and raise on errors.

    Returns:
        A FrontendDomain containing all four graphs.

    Raises:
        FrontendDSLValidationError: If validation fails.
    """
    schema = parse_domain_directory(domain_path)

    if validate:
        validator = FrontendDSLValidator()
        errors = validator.validate(schema)
        if errors:
            from honey_badgeria.front.exceptions import (
                FrontendDSLValidationError,
            )
            raise FrontendDSLValidationError(
                f"Domain {schema.name!r} has {len(errors)} validation error(s)",
                errors=errors,
            )

    return FrontendDomain.from_schema(schema)


def load_all_frontend_domains(
    graph_path: str,
    validate: bool = True,
) -> list[FrontendDomain]:
    """Load all frontend domains under a ``graph/`` directory.

    Args:
        graph_path: Path to the ``graph/`` root directory.
        validate:   If True, run validation and raise on first domain error.

    Returns:
        List of FrontendDomain objects.
    """
    schemas = parse_graph_directory(graph_path)
    domains: list[FrontendDomain] = []

    for schema in schemas:
        if validate:
            validator = FrontendDSLValidator()
            errors = validator.validate(schema)
            if errors:
                from honey_badgeria.front.exceptions import (
                    FrontendDSLValidationError,
                )
                raise FrontendDSLValidationError(
                    f"Domain {schema.name!r} has {len(errors)} validation error(s)",
                    errors=errors,
                )
        domains.append(FrontendDomain.from_schema(schema))

    return domains
