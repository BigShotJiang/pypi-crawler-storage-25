"""Schema definitions for the HBIA Frontend DSL.

These dataclasses represent the parsed YAML definitions for each
frontend node type.  They are the single source of truth for what
a valid YAML definition looks like.

Node Types:
    UINodeSchema       — A renderable component (pure view)
    StateNodeSchema    — A domain of application state
    EffectNodeSchema   — A side effect triggered by state changes
    EventFlowSchema    — A flow triggered by a user event

Container:
    FrontendDomainSchema — All nodes in a single graph domain
"""

from __future__ import annotations

from dataclasses import dataclass, field


# ======================================================================
# UI Node
# ======================================================================

@dataclass
class UINodeSchema:
    """A renderable component in the UI graph.

    UI nodes are **pure render functions**.  They cannot own state,
    contain hooks, or execute side effects.  They only:
        - receive data (via ``reads``)
        - render UI (via ``view``)
        - emit events (via ``events``)

    Attributes:
        component:  Unique component name (PascalCase).
        view:       TypeScript view file name (without extension).
        reads:      State references this component subscribes to,
                    e.g. ``["FilterState.dateRange", "ChartState.series"]``.
        events:     Mapping of event names to event handler identifiers,
                    e.g. ``{"refresh": "refresh_chart_event"}``.
        children:   Names of child UI components in the hierarchy.
        props:      Static props passed from parent, e.g. ``{"title": "string"}``.
    """

    component: str
    view: str
    reads: list[str] = field(default_factory=list)
    events: dict[str, str] = field(default_factory=dict)
    children: list[str] = field(default_factory=list)
    props: dict[str, str] = field(default_factory=dict)


# ======================================================================
# State Node
# ======================================================================

@dataclass
class StateNodeSchema:
    """A domain of application state.

    State nodes are the core of HBIA Frontend.  Every piece of
    application state must live inside a declared state node.

    All state changes must occur through **declared mutations**.

    Attributes:
        state:      Unique state name (PascalCase + "State" suffix).
        interface:  TypeScript interface name for this state's shape.
        fields:     Mapping of field names to TypeScript types,
                    e.g. ``{"dateRange": "DateRange", "region": "string"}``.
        mutations:  List of mutation function names that can modify
                    this state.
        triggers:   List of effect names triggered when this state
                    changes.
        initial:    Optional mapping of field names to default values.
    """

    state: str
    interface: str
    fields: dict[str, str] = field(default_factory=dict)
    mutations: list[str] = field(default_factory=list)
    triggers: list[str] = field(default_factory=list)
    initial: dict[str, str] = field(default_factory=dict)


# ======================================================================
# Effect Node
# ======================================================================

@dataclass
class EffectNodeSchema:
    """A side effect triggered by state changes.

    Effects watch specific state fields and execute when those
    fields change.  Effects may mutate other state nodes.

    Attributes:
        effect:       Unique effect name (snake_case).
        watch:        List of state field references to observe,
                      e.g. ``["FilterState.dateRange", "FilterState.region"]``.
        handler:      TypeScript handler function name.
        effect_type:  ``"side_effect"`` for API calls, persistence, etc.
                      ``"derived"`` for computed/derived state.
        mutates:      Optional list of state nodes this effect can
                      write to, e.g. ``["ChartState"]``.
        debounce_ms:  Optional debounce in milliseconds.
    """

    effect: str
    watch: list[str] = field(default_factory=list)
    on_event: list[str] = field(default_factory=list)
    handler: str = ""
    effect_type: str = "side_effect"
    mutates: list[str] = field(default_factory=list)
    debounce_ms: int | None = None


# ======================================================================
# Event Flow
# ======================================================================

@dataclass
class EventFlowSchema:
    """A flow triggered by a user event.

    Events represent user actions (click, submit, change, etc.)
    and trigger an ordered sequence of mutations, maintaining
    conceptual symmetry with HBIA backend flows.

    Attributes:
        event:   Unique event name (snake_case).
        flow:    Ordered list of mutation references to execute,
                 e.g. ``["FilterState.set_date_range", "ChartState.reset"]``.
        source:  Optional UI component that emits this event.
        guards:  Optional list of state conditions that must be true,
                 e.g. ``["AuthState.is_authenticated"]``.
    """

    event: str
    flow: list[str] = field(default_factory=list)
    source: str | None = None
    guards: list[str] = field(default_factory=list)


# ======================================================================
# Domain Container
# ======================================================================

@dataclass
class FrontendDomainSchema:
    """All nodes in a single graph domain.

    A domain represents a functional area of the application
    (e.g. ``dashboard``, ``auth``, ``reports``).  Each domain
    contains its own UI, state, effect, and event definitions.

    Attributes:
        name:     Domain name (snake_case).
        ui:       Dict of component name → UINodeSchema.
        state:    Dict of state name → StateNodeSchema.
        effects:  Dict of effect name → EffectNodeSchema.
        events:   Dict of event name → EventFlowSchema.
    """

    name: str
    ui: dict[str, UINodeSchema] = field(default_factory=dict)
    state: dict[str, StateNodeSchema] = field(default_factory=dict)
    effects: dict[str, EffectNodeSchema] = field(default_factory=dict)
    events: dict[str, EventFlowSchema] = field(default_factory=dict)
