"""Frontend DSL validator: validates graph definitions for structural correctness.

Validates all four graph types and cross-graph references:

    1. UI nodes must only read from declared state fields
    2. UI events must reference declared event flows
    3. State mutations must be explicitly listed
    4. Effects must watch declared state fields
    5. Effect mutates targets must be declared state nodes
    6. Event flows must reference declared state mutations
    7. No orphaned nodes (every node must be reachable)
"""

from __future__ import annotations

from typing import Any

from honey_badgeria.front.dsl.schemas import FrontendDomainSchema


class FrontendDSLValidator:
    """Validates a frontend domain for structural correctness.

    Usage::

        validator = FrontendDSLValidator()
        errors = validator.validate(domain_schema)
        if errors:
            for e in errors:
                print(f"  ✘ {e}")
    """

    def validate(self, domain: FrontendDomainSchema) -> list[str]:
        """Validate a complete domain schema.

        Returns:
            List of error strings (empty if valid).
        """
        errors: list[str] = []
        errors.extend(self._validate_state_nodes(domain))
        errors.extend(self._validate_ui_nodes(domain))
        errors.extend(self._validate_effects(domain))
        errors.extend(self._validate_events(domain))
        errors.extend(self._validate_cross_references(domain))
        return errors

    def validate_raw(self, data: dict[str, Any], node_type: str) -> list[str]:
        """Validate a raw dict before parsing into a schema.

        Args:
            data:      The raw YAML dict.
            node_type: One of ``"ui"``, ``"state"``, ``"effect"``, ``"event"``.

        Returns:
            List of error strings.
        """
        validators = {
            "ui": self._validate_raw_ui,
            "state": self._validate_raw_state,
            "effect": self._validate_raw_effect,
            "event": self._validate_raw_event,
        }
        validator = validators.get(node_type)
        if validator is None:
            return [f"Unknown node type: {node_type!r}"]
        return validator(data)

    # ------------------------------------------------------------------
    # Raw dict validation (pre-parse)
    # ------------------------------------------------------------------

    def _validate_raw_ui(self, data: dict[str, Any]) -> list[str]:
        errors: list[str] = []
        if "component" not in data:
            errors.append("UI node missing required field: 'component'")
        if "view" not in data:
            errors.append("UI node missing required field: 'view'")
        if "reads" in data and not isinstance(data["reads"], list):
            errors.append("UI node 'reads' must be a list")
        if "events" in data and not isinstance(data["events"], dict):
            errors.append("UI node 'events' must be a dict")
        if "children" in data and not isinstance(data["children"], list):
            errors.append("UI node 'children' must be a list")
        return errors

    def _validate_raw_state(self, data: dict[str, Any]) -> list[str]:
        errors: list[str] = []
        if "state" not in data:
            errors.append("State node missing required field: 'state'")
        if "fields" in data and not isinstance(data["fields"], dict):
            errors.append("State node 'fields' must be a dict")
        if "mutations" in data and not isinstance(data["mutations"], list):
            errors.append("State node 'mutations' must be a list")
        if "triggers" in data and not isinstance(data["triggers"], list):
            errors.append("State node 'triggers' must be a list")
        return errors

    def _validate_raw_effect(self, data: dict[str, Any]) -> list[str]:
        errors: list[str] = []
        if "effect" not in data:
            errors.append("Effect node missing required field: 'effect'")
        if "watch" in data and not isinstance(data["watch"], list):
            errors.append("Effect 'watch' must be a list")
        if "on_event" in data and not isinstance(data["on_event"], list):
            errors.append("Effect 'on_event' must be a list")
        valid_types = {"side_effect", "derived"}
        etype = data.get("effect_type", "side_effect")
        if etype not in valid_types:
            errors.append(
                f"Effect 'effect_type' must be one of {valid_types}, "
                f"got {etype!r}"
            )
        return errors

    def _validate_raw_event(self, data: dict[str, Any]) -> list[str]:
        errors: list[str] = []
        if "event" not in data:
            errors.append("Event missing required field: 'event'")
        if "flow" not in data or not isinstance(data.get("flow"), list):
            errors.append("Event must have a 'flow' list")
        return errors

    # ------------------------------------------------------------------
    # Schema-level validation
    # ------------------------------------------------------------------

    def _validate_state_nodes(self, domain: FrontendDomainSchema) -> list[str]:
        errors: list[str] = []
        for name, state in domain.state.items():
            if not state.state:
                errors.append(f"State node {name!r} has empty 'state' name")
            if not state.fields:
                errors.append(f"State node {name!r} has no fields declared")
            if not state.mutations:
                errors.append(
                    f"State node {name!r} has no mutations declared — "
                    f"state without mutations is immutable"
                )
        return errors

    def _validate_ui_nodes(self, domain: FrontendDomainSchema) -> list[str]:
        errors: list[str] = []
        for name, ui in domain.ui.items():
            if not ui.component:
                errors.append(f"UI node {name!r} has empty 'component' name")
            if not ui.view:
                errors.append(f"UI node {name!r} has empty 'view' reference")
            # Validate reads reference format: "StateName.fieldName"
            for read in ui.reads:
                if "." not in read:
                    errors.append(
                        f"UI node {name!r}: read {read!r} must be in "
                        f"format 'StateName.fieldName'"
                    )
            # Validate children exist
            for child in ui.children:
                if child not in domain.ui:
                    errors.append(
                        f"UI node {name!r}: child {child!r} not found "
                        f"in domain UI nodes"
                    )
        return errors

    def _validate_effects(self, domain: FrontendDomainSchema) -> list[str]:
        errors: list[str] = []
        for name, effect in domain.effects.items():
            if not effect.effect:
                errors.append(f"Effect {name!r} has empty 'effect' name")
            if not effect.watch and not effect.on_event:
                errors.append(
                    f"Effect {name!r} has no 'watch' or 'on_event' declarations — "
                    f"an effect must watch at least one state field or be triggered by an event"
                )
            if not effect.handler:
                errors.append(f"Effect {name!r} has no 'handler' declared")
            # Validate watch format
            for watch in effect.watch:
                if "." not in watch:
                    errors.append(
                        f"Effect {name!r}: watch {watch!r} must be in "
                        f"format 'StateName.fieldName'"
                    )
        return errors

    def _validate_events(self, domain: FrontendDomainSchema) -> list[str]:
        errors: list[str] = []
        for name, event in domain.events.items():
            if not event.event:
                errors.append(f"Event {name!r} has empty 'event' name")
            if not event.flow:
                errors.append(
                    f"Event {name!r} has no 'flow' steps — "
                    f"an event must trigger at least one mutation"
                )
            # Validate flow step format: "StateName.mutation_name"
            for step in event.flow:
                if "." not in step:
                    errors.append(
                        f"Event {name!r}: flow step {step!r} must be in "
                        f"format 'StateName.mutation_name'"
                    )
        return errors

    # ------------------------------------------------------------------
    # Cross-reference validation
    # ------------------------------------------------------------------

    def _validate_cross_references(self, domain: FrontendDomainSchema) -> list[str]:
        """Validate references across graph types."""
        errors: list[str] = []

        # Collect all declared state names and their fields/mutations
        state_names = set(domain.state.keys())
        state_fields: dict[str, set[str]] = {}
        state_mutations: dict[str, set[str]] = {}

        for name, state in domain.state.items():
            state_fields[name] = set(state.fields.keys())
            state_mutations[name] = set(state.mutations)

        # Collect all declared effect names
        effect_names = set(domain.effects.keys())

        # ── UI reads must reference existing state fields ─────────
        for ui_name, ui in domain.ui.items():
            for read in ui.reads:
                parts = read.split(".", 1)
                if len(parts) == 2:
                    sname, fname = parts
                    if sname not in state_names:
                        errors.append(
                            f"UI {ui_name!r}: reads {read!r} references "
                            f"unknown state {sname!r}"
                        )
                    elif fname not in state_fields.get(sname, set()):
                        errors.append(
                            f"UI {ui_name!r}: reads {read!r} references "
                            f"unknown field {fname!r} on {sname!r}"
                        )

        # ── UI events must reference declared events ──────────────
        event_names = set(domain.events.keys())
        for ui_name, ui in domain.ui.items():
            for _, event_ref in ui.events.items():
                if event_ref not in event_names:
                    errors.append(
                        f"UI {ui_name!r}: event handler {event_ref!r} "
                        f"not found in domain events"
                    )

        # ── Effect watches must reference existing state fields ───
        for eff_name, effect in domain.effects.items():
            for watch in effect.watch:
                parts = watch.split(".", 1)
                if len(parts) == 2:
                    sname, fname = parts
                    if sname not in state_names:
                        errors.append(
                            f"Effect {eff_name!r}: watches {watch!r} "
                            f"references unknown state {sname!r}"
                        )
                    elif fname not in state_fields.get(sname, set()):
                        errors.append(
                            f"Effect {eff_name!r}: watches {watch!r} "
                            f"references unknown field {fname!r} on {sname!r}"
                        )

        # ── Effect mutates must reference existing state nodes ────
        for eff_name, effect in domain.effects.items():
            for target in effect.mutates:
                if target not in state_names:
                    errors.append(
                        f"Effect {eff_name!r}: mutates {target!r} "
                        f"references unknown state node"
                    )

        # ── State triggers must reference existing effects ────────
        for state_name, state in domain.state.items():
            for trigger in state.triggers:
                if trigger not in effect_names:
                    errors.append(
                        f"State {state_name!r}: trigger {trigger!r} "
                        f"references unknown effect"
                    )

        # ── Event flow steps must reference existing mutations ────
        for event_name, event in domain.events.items():
            for step in event.flow:
                parts = step.split(".", 1)
                if len(parts) == 2:
                    sname, mname = parts
                    if sname not in state_names:
                        errors.append(
                            f"Event {event_name!r}: flow step {step!r} "
                            f"references unknown state {sname!r}"
                        )
                    elif mname not in state_mutations.get(sname, set()):
                        errors.append(
                            f"Event {event_name!r}: flow step {step!r} "
                            f"references unknown mutation {mname!r} "
                            f"on {sname!r}"
                        )

        # ── Effect on_event must reference declared events ────────
        for eff_name, effect in domain.effects.items():
            for event_ref in effect.on_event:
                if event_ref not in event_names:
                    errors.append(
                        f"Effect {eff_name!r}: on_event {event_ref!r} "
                        f"references unknown event"
                    )

        return errors
