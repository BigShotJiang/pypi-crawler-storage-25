"""Frontend DSL parser: reads YAML files and directories into schemas.

The parser handles two input modes:

1. **Single file** — parse one YAML file into the appropriate schema.
2. **Domain directory** — scan a domain folder (``graph/<domain>/``)
   and parse all YAML definitions into a ``FrontendDomainSchema``.

Folder conventions:

    graph/<domain>/
        ui/<component>/<component>_node.yaml
        state/<state_name>/state.yaml
        effects/<effect_name>/effect.yaml
        events/<event_name>.yaml
"""

from __future__ import annotations

import os
from typing import Any

from honey_badgeria.front.dsl.schemas import (
    UINodeSchema,
    StateNodeSchema,
    EffectNodeSchema,
    EventFlowSchema,
    FrontendDomainSchema,
)


def _load_yaml(path: str) -> dict[str, Any]:
    """Load a YAML file into a dict.  Requires pyyaml."""
    try:
        import yaml
    except ImportError:
        raise ImportError(
            "Frontend DSL parser requires pyyaml. "
            "Install with: pip install honey-badgeria[yaml]"
        )
    with open(path) as f:
        data = yaml.safe_load(f)
    if data is None:
        return {}
    if not isinstance(data, dict):
        raise ValueError(f"Expected a YAML mapping in {path}, got {type(data).__name__}")
    return data


# ======================================================================
# Single-node parsers
# ======================================================================

def parse_ui_node(data: dict[str, Any]) -> UINodeSchema:
    """Parse a dict into a UINodeSchema."""
    return UINodeSchema(
        component=data["component"],
        view=data.get("view", ""),
        reads=data.get("reads", []),
        events=data.get("events", {}),
        children=data.get("children", []),
        props=data.get("props", {}),
    )


def parse_state_node(data: dict[str, Any]) -> StateNodeSchema:
    """Parse a dict into a StateNodeSchema."""
    return StateNodeSchema(
        state=data["state"],
        interface=data.get("interface", ""),
        fields=data.get("fields", {}),
        mutations=data.get("mutations", []),
        triggers=data.get("triggers", []),
        initial=data.get("initial", {}),
    )


def parse_effect_node(data: dict[str, Any]) -> EffectNodeSchema:
    """Parse a dict into an EffectNodeSchema."""
    return EffectNodeSchema(
        effect=data["effect"],
        watch=data.get("watch", []),
        on_event=data.get("on_event", []),
        handler=data.get("handler", ""),
        effect_type=data.get("effect_type", "side_effect"),
        mutates=data.get("mutates", []),
        debounce_ms=data.get("debounce_ms"),
    )


def parse_event_flow(data: dict[str, Any]) -> EventFlowSchema:
    """Parse a dict into an EventFlowSchema."""
    return EventFlowSchema(
        event=data["event"],
        flow=data.get("flow", []),
        source=data.get("source"),
        guards=data.get("guards", []),
    )


# ======================================================================
# File-based parsers
# ======================================================================

def parse_ui_node_file(path: str) -> UINodeSchema:
    """Parse a UI node YAML file."""
    return parse_ui_node(_load_yaml(path))


def parse_state_node_file(path: str) -> StateNodeSchema:
    """Parse a state node YAML file."""
    return parse_state_node(_load_yaml(path))


def parse_effect_node_file(path: str) -> EffectNodeSchema:
    """Parse an effect node YAML file."""
    return parse_effect_node(_load_yaml(path))


def parse_event_flow_file(path: str) -> EventFlowSchema:
    """Parse an event flow YAML file."""
    return parse_event_flow(_load_yaml(path))


# ======================================================================
# Domain directory parser
# ======================================================================

def parse_domain_directory(domain_path: str) -> FrontendDomainSchema:
    """Parse a complete domain directory into a FrontendDomainSchema.

    Expected structure::

        domain_path/
            ui/<component>/<component>_node.yaml
            state/<state_name>/state.yaml
            effects/<effect_name>/effect.yaml
            events/<event_name>.yaml

    Args:
        domain_path: Absolute path to the domain directory.

    Returns:
        A fully populated FrontendDomainSchema.
    """
    domain_name = os.path.basename(domain_path)
    schema = FrontendDomainSchema(name=domain_name)

    # ── UI nodes ──────────────────────────────────────────────────
    ui_dir = os.path.join(domain_path, "ui")
    if os.path.isdir(ui_dir):
        for component_dir in sorted(os.listdir(ui_dir)):
            component_path = os.path.join(ui_dir, component_dir)
            if not os.path.isdir(component_path):
                continue
            yaml_file = _find_yaml(component_path, "_node.yaml")
            if yaml_file:
                node = parse_ui_node_file(yaml_file)
                schema.ui[node.component] = node

    # ── State nodes ───────────────────────────────────────────────
    state_dir = os.path.join(domain_path, "state")
    if os.path.isdir(state_dir):
        for state_subdir in sorted(os.listdir(state_dir)):
            state_path = os.path.join(state_dir, state_subdir)
            if not os.path.isdir(state_path):
                continue
            yaml_file = os.path.join(state_path, "state.yaml")
            if os.path.isfile(yaml_file):
                node = parse_state_node_file(yaml_file)
                schema.state[node.state] = node

    # ── Effects ───────────────────────────────────────────────────
    effects_dir = os.path.join(domain_path, "effects")
    if os.path.isdir(effects_dir):
        for effect_subdir in sorted(os.listdir(effects_dir)):
            effect_path = os.path.join(effects_dir, effect_subdir)
            if not os.path.isdir(effect_path):
                continue
            yaml_file = os.path.join(effect_path, "effect.yaml")
            if os.path.isfile(yaml_file):
                node = parse_effect_node_file(yaml_file)
                schema.effects[node.effect] = node

    # ── Events ────────────────────────────────────────────────────
    events_dir = os.path.join(domain_path, "events")
    if os.path.isdir(events_dir):
        for entry in sorted(os.listdir(events_dir)):
            if entry.endswith((".yaml", ".yml")):
                event_path = os.path.join(events_dir, entry)
                if os.path.isfile(event_path):
                    node = parse_event_flow_file(event_path)
                    schema.events[node.event] = node

    return schema


def parse_graph_directory(graph_path: str) -> list[FrontendDomainSchema]:
    """Parse all domains under a ``graph/`` directory.

    Args:
        graph_path: Path to the ``graph/`` root directory.

    Returns:
        List of FrontendDomainSchema, one per domain subdirectory.
    """
    domains: list[FrontendDomainSchema] = []
    if not os.path.isdir(graph_path):
        return domains
    for entry in sorted(os.listdir(graph_path)):
        domain_path = os.path.join(graph_path, entry)
        if os.path.isdir(domain_path):
            domains.append(parse_domain_directory(domain_path))
    return domains


# ======================================================================
# Helpers
# ======================================================================

def _find_yaml(directory: str, suffix: str) -> str | None:
    """Find the first YAML file in a directory matching a suffix."""
    for entry in os.listdir(directory):
        if entry.endswith(suffix):
            return os.path.join(directory, entry)
    # Fallback: any .yaml file
    for entry in os.listdir(directory):
        if entry.endswith((".yaml", ".yml")):
            return os.path.join(directory, entry)
    return None
