"""AI context generation for Honey Badgeria projects.

This module generates comprehensive context documents that AI coding
assistants (GitHub Copilot, Cursor, Claude, etc.) can read to understand
the Honey Badgeria framework without any external documentation.
"""

from honey_badgeria.context.ai_context import generate_context, KNOWN_TARGETS

__all__ = ["generate_context", "KNOWN_TARGETS"]
