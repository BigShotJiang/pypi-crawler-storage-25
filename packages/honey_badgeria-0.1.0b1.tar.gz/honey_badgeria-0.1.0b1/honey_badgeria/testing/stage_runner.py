"""Stage runner: execute individual stages for testing."""

from __future__ import annotations

from typing import Any, Callable, TYPE_CHECKING

from honey_badgeria.core.exceptions import HandlerNotFoundError
from honey_badgeria.back.runtime.data_store import DataStore
from honey_badgeria.back.runtime.data_flow import DataFlowEngine

if TYPE_CHECKING:
    from honey_badgeria.back.graph.vertex import Vertex


class StageRunner:
    """Runs individual vertices for isolated testing.

    Usage::

        runner = StageRunner(handlers={"my_handler": my_fn})
        result = runner.run_vertex(vertex, initial_data={"key": "val"})
    """

    def __init__(self, handlers: dict[str, Callable[..., Any]] | None = None) -> None:
        self.handlers: dict[str, Callable[..., Any]] = handlers or {}
        self.data_store: DataStore = DataStore()
        self.data_flow: DataFlowEngine = DataFlowEngine(self.data_store)

    def run_vertex(
        self,
        vertex: Vertex,
        initial_data: dict[str, Any] | None = None,
    ) -> dict[str, Any] | Any:
        """Run a single vertex with optional initial data."""
        if initial_data:
            for k, v in initial_data.items():
                self.data_store.set_output(k, v)

        handler = self._resolve(vertex.handler)
        inputs = self.data_flow.resolve_inputs(vertex)
        result = handler(**inputs)
        self.data_flow.store_outputs(vertex, result)
        return result

    def _resolve(self, handler: Any) -> Callable[..., Any]:
        if callable(handler):
            return handler
        if handler in self.handlers:
            return self.handlers[handler]
        raise HandlerNotFoundError(f"No handler: {handler}")
