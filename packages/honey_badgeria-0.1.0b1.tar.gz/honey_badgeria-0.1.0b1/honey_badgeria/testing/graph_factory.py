"""Factory for creating test graphs."""

from __future__ import annotations

from typing import Any, Callable

from honey_badgeria.back.graph.graph import Graph
from honey_badgeria.back.graph.vertex import Vertex
from honey_badgeria.back.graph.edge import Edge


class GraphFactory:
    """Factory for creating :class:`Graph` instances for testing."""

    @staticmethod
    def create(
        vertices: list[Vertex | dict[str, Any]] | None = None,
        edges: list[Edge | tuple[str, str] | list[str]] | None = None,
        flows: dict[str, dict[str, str]] | None = None,
    ) -> Graph:
        """Create a Graph from simple data.

        Args:
            vertices: List of dicts or Vertex objects.
            edges: List of ``(source, target)`` tuples or Edge objects.
            flows: ``{flow_name: {"entry": vertex_name}}``.
        """
        graph = Graph()
        graph.flows = flows or {}

        for v in (vertices or []):
            if isinstance(v, Vertex):
                graph.add_vertex(v)
            elif isinstance(v, dict):
                graph.add_vertex(Vertex(
                    name=v["name"],
                    handler=v.get("handler"),
                    inputs=v.get("inputs"),
                    outputs=v.get("outputs"),
                ))
            else:
                raise TypeError(f"Invalid vertex type: {type(v)}")

        for e in (edges or []):
            if isinstance(e, Edge):
                graph.add_edge(e)
            elif isinstance(e, (tuple, list)) and len(e) == 2:
                graph.add_edge(Edge(source=e[0], target=e[1]))
            else:
                raise TypeError(f"Invalid edge type: {type(e)}")

        return graph

    @staticmethod
    def linear(
        names: list[str],
        handlers: dict[str, Callable[..., Any]] | None = None,
    ) -> Graph:
        """Create a linear graph: A → B → C → ...

        Args:
            names: List of vertex names.
            handlers: Optional ``{name: handler}`` mapping.
        """
        handlers = handlers or {}
        graph = Graph()

        for name in names:
            handler = handlers.get(name)
            inputs: dict[str, str] = {}

            idx = names.index(name)
            if idx > 0:
                prev = names[idx - 1]
                inputs = {"input": f"{prev}.output"}

            graph.add_vertex(Vertex(
                name=name,
                handler=handler,
                inputs=inputs if idx > 0 else {},
            ))

        for i in range(len(names) - 1):
            graph.add_edge(Edge(source=names[i], target=names[i + 1]))

        return graph

    @staticmethod
    def diamond(
        top: str = "A",
        left: str = "B",
        right: str = "C",
        bottom: str = "D",
        handlers: dict[str, Callable[..., Any]] | None = None,
    ) -> Graph:
        """Create a diamond graph::

                A
               / \\
              B   C
               \\ /
                D
        """
        handlers = handlers or {}
        graph = Graph()

        for name in [top, left, right, bottom]:
            graph.add_vertex(Vertex(name=name, handler=handlers.get(name)))

        graph.add_edge(Edge(source=top, target=left))
        graph.add_edge(Edge(source=top, target=right))
        graph.add_edge(Edge(source=left, target=bottom))
        graph.add_edge(Edge(source=right, target=bottom))

        return graph
