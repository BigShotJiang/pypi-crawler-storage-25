"""Mock vertex handlers for testing.

Provides :class:`VertexMock` (sync) and :class:`AsyncVertexMock` (async)
for building deterministic test scenarios with full call tracking.
"""

from __future__ import annotations

import asyncio
from typing import Any, Callable


class VertexMock:
    """Synchronous mock handler for testing vertices.

    Usage::

        mock = VertexMock(return_value={"result": 42})
        result = mock(input_data="test")
        assert mock.call_count == 1
        assert mock.last_call == {"input_data": "test"}
    """

    def __init__(
        self,
        return_value: dict[str, Any] | None = None,
        side_effect: Exception | Callable[..., Any] | None = None,
    ) -> None:
        self.return_value: dict[str, Any] = return_value or {}
        self.side_effect: Exception | Callable[..., Any] | None = side_effect
        self.calls: list[dict[str, Any]] = []
        self._sequence: list[dict[str, Any]] | None = None
        self._seq_idx: int = 0

    def __call__(self, **kwargs: Any) -> dict[str, Any] | Any:
        self.calls.append(kwargs)

        if self.side_effect:
            if isinstance(self.side_effect, Exception):
                raise self.side_effect
            if callable(self.side_effect):
                return self.side_effect(**kwargs)

        if self._sequence is not None:
            idx = min(self._seq_idx, len(self._sequence) - 1)
            self._seq_idx += 1
            return self._sequence[idx]

        return self.return_value

    # ------------------------------------------------------------------
    # introspection
    # ------------------------------------------------------------------

    @property
    def call_count(self) -> int:
        return len(self.calls)

    @property
    def last_call(self) -> dict[str, Any] | None:
        return self.calls[-1] if self.calls else None

    @property
    def called(self) -> bool:
        return len(self.calls) > 0

    def reset(self) -> None:
        self.calls.clear()
        self._seq_idx = 0

    # ------------------------------------------------------------------
    # factories
    # ------------------------------------------------------------------

    @classmethod
    def with_sequence(cls, *responses: dict[str, Any]) -> VertexMock:
        """Create a mock that returns different values on successive calls.

        Usage::

            mock = VertexMock.with_sequence(
                {"step": 1},
                {"step": 2},
            )
            assert mock()["step"] == 1
            assert mock()["step"] == 2
        """
        instance = cls()
        instance._sequence = list(responses)
        return instance

    @classmethod
    def failing(cls, error: Exception | None = None) -> VertexMock:
        """Create a mock that always raises an exception.

        Usage::

            mock = VertexMock.failing(RuntimeError("boom"))
        """
        return cls(side_effect=error or RuntimeError("vertex failed"))


class AsyncVertexMock:
    """Async mock handler for testing async vertices.

    Usage::

        mock = AsyncVertexMock(return_value={"result": 42})
        result = await mock(input_data="test")
        assert mock.call_count == 1
    """

    def __init__(
        self,
        return_value: dict[str, Any] | None = None,
        side_effect: Exception | Callable[..., Any] | None = None,
    ) -> None:
        self.return_value: dict[str, Any] = return_value or {}
        self.side_effect: Exception | Callable[..., Any] | None = side_effect
        self.calls: list[dict[str, Any]] = []
        self._sequence: list[dict[str, Any]] | None = None
        self._seq_idx: int = 0

    async def __call__(self, **kwargs: Any) -> dict[str, Any] | Any:
        self.calls.append(kwargs)

        if self.side_effect:
            if isinstance(self.side_effect, Exception):
                raise self.side_effect
            if callable(self.side_effect):
                result = self.side_effect(**kwargs)
                if asyncio.iscoroutine(result):
                    return await result
                return result

        if self._sequence is not None:
            idx = min(self._seq_idx, len(self._sequence) - 1)
            self._seq_idx += 1
            return self._sequence[idx]

        return self.return_value

    @property
    def call_count(self) -> int:
        return len(self.calls)

    @property
    def last_call(self) -> dict[str, Any] | None:
        return self.calls[-1] if self.calls else None

    @property
    def called(self) -> bool:
        return len(self.calls) > 0

    def reset(self) -> None:
        self.calls.clear()
        self._seq_idx = 0

    @classmethod
    def with_sequence(cls, *responses: dict[str, Any]) -> AsyncVertexMock:
        """Create an async mock returning different values per call."""
        instance = cls()
        instance._sequence = list(responses)
        return instance

    @classmethod
    def failing(cls, error: Exception | None = None) -> AsyncVertexMock:
        """Create an async mock that always raises."""
        return cls(side_effect=error or RuntimeError("async vertex failed"))
