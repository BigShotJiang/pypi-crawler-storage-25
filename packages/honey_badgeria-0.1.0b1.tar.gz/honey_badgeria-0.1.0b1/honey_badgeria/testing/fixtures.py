"""Pytest fixtures and factory helpers for Honey Badgeria testing."""

from __future__ import annotations

from typing import Any, Callable, TYPE_CHECKING

from honey_badgeria.testing.graph_factory import GraphFactory
from honey_badgeria.testing.vertex_mock import VertexMock, AsyncVertexMock
from honey_badgeria.testing.flow_tester import FlowTester

if TYPE_CHECKING:
    from honey_badgeria.back.graph.graph import Graph


def make_graph_fixture(
    vertices: list[Any] | None = None,
    edges: list[Any] | None = None,
    flows: dict[str, dict[str, str]] | None = None,
) -> Graph:
    """Create a graph fixture for testing."""
    return GraphFactory.create(vertices=vertices, edges=edges, flows=flows)


def make_flow_tester(
    graph: Graph,
    handlers: dict[str, Callable[..., Any]] | None = None,
) -> FlowTester:
    """Create a FlowTester fixture."""
    return FlowTester(graph, handlers=handlers)


def make_vertex_mock(return_value: dict[str, Any] | None = None) -> VertexMock:
    """Create a VertexMock fixture."""
    return VertexMock(return_value=return_value)


def make_async_vertex_mock(return_value: dict[str, Any] | None = None) -> AsyncVertexMock:
    """Create an AsyncVertexMock fixture."""
    return AsyncVertexMock(return_value=return_value)
