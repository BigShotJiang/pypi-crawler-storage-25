"""Stubs and injection helpers for testing.

Provides lightweight factories that reduce boilerplate in test code:

- :func:`handler_stub` - one-liner handler creation.
- :class:`ResponseInjector` - pre-populate data stores for isolated tests.
- :func:`edge_stub` - shorthand for creating Edge instances.
"""

from __future__ import annotations

from typing import Any, Callable

from honey_badgeria.back.graph.edge import Edge
from honey_badgeria.back.graph.vertex import Vertex
from honey_badgeria.back.runtime.data_store import DataStore


# ------------------------------------------------------------------
# handler_stub
# ------------------------------------------------------------------


def handler_stub(
    return_value: dict[str, Any] | None = None,
    **fixed: Any,
) -> Callable[..., dict[str, Any]]:
    """Create a minimal handler that ignores its inputs and returns
    a fixed dict.

    Usage::

        h = handler_stub(username="alice", valid=True)
        assert h() == {"username": "alice", "valid": True}

    If *return_value* is given it is returned directly; otherwise
    the ``**fixed`` kwargs are returned as a dict.
    """
    rv = return_value if return_value is not None else fixed

    def _handler(**_kwargs: Any) -> dict[str, Any]:
        return dict(rv)  # type: ignore[arg-type]

    return _handler


# ------------------------------------------------------------------
# edge_stub
# ------------------------------------------------------------------


def edge_stub(source: str, target: str) -> Edge:
    """Shorthand for ``Edge(source=source, target=target)``."""
    return Edge(source=source, target=target)


# ------------------------------------------------------------------
# vertex_stub
# ------------------------------------------------------------------


def vertex_stub(
    name: str,
    handler: Callable[..., Any] | str | None = None,
    inputs: dict[str, str] | None = None,
    outputs: dict[str, str] | None = None,
) -> Vertex:
    """Shorthand for creating a :class:`Vertex` in tests."""
    return Vertex(name=name, handler=handler, inputs=inputs, outputs=outputs)


# ------------------------------------------------------------------
# ResponseInjector
# ------------------------------------------------------------------


class ResponseInjector:
    """Pre-populate a :class:`DataStore` with canned data.

    Useful when testing a vertex in isolation and you need to
    simulate outputs from upstream vertices.

    Usage::

        store = DataStore()
        injector = ResponseInjector(store)
        injector.inject("normalize_user.username", "alice")
        injector.inject("normalize_user.email", "a@b.com")

        # Now downstream vertices can resolve these references.

    Can also be used as a context dict::

        injector = ResponseInjector.from_dict({
            "normalize_user.username": "alice",
            "validate_user.valid": True,
        })
        assert injector.store.get_output("normalize_user.username") == "alice"
    """

    def __init__(self, store: DataStore | None = None) -> None:
        self.store: DataStore = store or DataStore()

    def inject(self, key: str, value: Any) -> ResponseInjector:
        """Inject a single key-value pair.  Chainable."""
        self.store.set_output(key, value)
        return self

    def inject_vertex_outputs(
        self,
        vertex_name: str,
        outputs: dict[str, Any],
    ) -> ResponseInjector:
        """Inject all outputs for a vertex.

        Each key in *outputs* is stored as ``vertex_name.key``.
        """
        for key, value in outputs.items():
            self.store.set_output(f"{vertex_name}.{key}", value)
        return self

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> ResponseInjector:
        """Create an injector pre-loaded from a flat dict."""
        injector = cls()
        for key, value in data.items():
            injector.store.set_output(key, value)
        return injector
