"""Flow tester: run flows with mock handlers and inspect results."""

from __future__ import annotations

from typing import Any, Callable

from honey_badgeria.core.exceptions import HandlerNotFoundError
from honey_badgeria.back.runtime.executor import GraphExecutor

from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from honey_badgeria.back.graph.graph import Graph


class FlowTestResult:
    """Wraps graph execution results with assertion helpers.

    Usage::

        result = FlowTestResult(data)
        result.assert_output("normalize_user.username", "alice")
        result.assert_has_key("validate_user.valid")
        result.assert_vertex_ran("normalize_user", tester)
    """

    def __init__(self, data: dict[str, Any]) -> None:
        self.data: dict[str, Any] = data

    def __getitem__(self, key: str) -> Any:
        return self.data[key]

    def __contains__(self, key: str) -> bool:
        return key in self.data

    # ------------------------------------------------------------------
    # assertions
    # ------------------------------------------------------------------

    def assert_has_key(self, key: str) -> FlowTestResult:
        """Assert that *key* is in the output data."""
        assert key in self.data, (
            f"Expected key '{key}' in output. "
            f"Got keys: {list(self.data.keys())}"
        )
        return self

    def assert_output(self, key: str, expected: Any) -> FlowTestResult:
        """Assert that ``data[key] == expected``."""
        self.assert_has_key(key)
        actual = self.data[key]
        assert actual == expected, (
            f"Expected output['{key}'] == {expected!r}, got {actual!r}"
        )
        return self

    def assert_vertex_ran(self, vertex_name: str, tester: FlowTester) -> FlowTestResult:
        """Assert that a vertex was executed (has state 'completed')."""
        state = tester.executor.state_store.get_state(vertex_name)
        assert state == "completed", (
            f"Expected vertex '{vertex_name}' to be completed, got '{state}'"
        )
        return self

    def assert_flow_completed(self, tester: FlowTester) -> FlowTestResult:
        """Assert that all tracked vertices completed."""
        assert tester.executor.state_store.all_completed(), (
            f"Not all vertices completed: "
            f"{tester.executor.state_store.dump()}"
        )
        return self


class FlowTester:
    """Test helper for running flows with mock handlers.

    Usage::

        tester = FlowTester(graph, handlers={"my_handler": mock_fn})
        result = tester.run(initial_data={"key": "value"})
        result.assert_has_key("my_handler.output")
    """

    def __init__(
        self,
        graph: Graph,
        handlers: dict[str, Callable[..., Any]] | None = None,
    ) -> None:
        self.graph: Graph = graph
        self.handlers: dict[str, Callable[..., Any]] = handlers or {}
        self.executor: GraphExecutor | None = None  # type: ignore[assignment]

    def run(self, initial_data: dict[str, Any] | None = None) -> FlowTestResult:
        """Run the graph with configured handlers and return results."""
        handler_dict = self.handlers

        def resolver(name: Any) -> Callable[..., Any]:
            if callable(name):
                return name
            if name in handler_dict:
                return handler_dict[name]
            raise HandlerNotFoundError(f"No handler registered for: {name}")

        self.executor = GraphExecutor(self.graph, resolver)
        raw = self.executor.execute(initial_data)
        return FlowTestResult(raw)
