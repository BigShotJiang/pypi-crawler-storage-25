"""Graphviz renderer (optional, requires graphviz package)."""

from __future__ import annotations

from typing import TYPE_CHECKING

try:
    from graphviz import Digraph
    HAS_GRAPHVIZ: bool = True
except ImportError:
    HAS_GRAPHVIZ = False

from honey_badgeria.back.topology import GraphTopology

if TYPE_CHECKING:
    from honey_badgeria.back.graph.graph import Graph


# Colour palette
_STAGE_COLORS = [
    "#D6EAF8", "#D5F5E3", "#FDEDEC", "#FEF9E7",
    "#F5EEF8", "#E8F8F5", "#FDF2E9", "#EAF2FF",
]
_ENTRY_COLOR    = "#FDEBD0"  # warm orange-ish for flow entry points
_SIDE_FX_COLOR  = "#FADBD8"  # light red for side-effect vertices
_BORDER_COLOR   = "#4A6FA5"


class GraphvizRenderer:
    """Renders a graph using Graphviz."""

    def __init__(self, graph: Graph) -> None:
        if not HAS_GRAPHVIZ:
            raise ImportError(
                "graphviz is required for Graphviz rendering. "
                "Install with: pip install honey-badgeria[viz]"
            )
        self.graph: Graph = graph
        self.topology: GraphTopology = GraphTopology(graph)

    def render(self, output: str = "graph", title: str | None = None) -> str:
        """Render the graph to a PNG file."""
        graph_label = title or (
            ", ".join(self.graph.flows.keys()) if self.graph.flows else "HBIA DAG"
        )

        dot = Digraph(graph_label)
        dot.attr(
            rankdir="TB",
            fontname="Helvetica",
            label=graph_label,
            labelloc="t",
            fontsize="18",
            pad="0.5",
            splines="ortho",
        )
        dot.attr(
            "node",
            shape="box",
            style="rounded,filled",
            color=_BORDER_COLOR,
            fontname="Helvetica",
            fontsize="12",
            margin="0.2,0.1",
        )
        dot.attr("edge", color="#555555", fontname="Helvetica", fontsize="10")

        # Collect flow entry vertices
        entry_vertices: set[str] = {
            meta["entry"]
            for meta in self.graph.flows.values()
            if "entry" in meta
        }

        stages = self.topology.execution_stages()

        for i, stage in enumerate(stages):
            stage_color = _STAGE_COLORS[i % len(_STAGE_COLORS)]
            parallel_hint = f" ({len(stage)} parallel)" if len(stage) > 1 else ""
            cluster_label = f"Step {i + 1}{parallel_hint}"

            with dot.subgraph(name=f"cluster_{i}") as sub:
                sub.attr(
                    label=cluster_label,
                    color="#AAAAAA",
                    style="rounded,dashed",
                    fontsize="11",
                    fontname="Helvetica",
                )
                for vertex in stage:
                    # Build node label: name + optional handler hint
                    node_label = vertex.name
                    if vertex.handler and isinstance(vertex.handler, str):
                        short_handler = vertex.handler.split(".")[-1]
                        node_label = f"{vertex.name}\\n<{short_handler}>"
                    elif vertex.handler and callable(vertex.handler):
                        node_label = f"{vertex.name}\\n<fn>"

                    # Choose fill colour by priority
                    if vertex.name in entry_vertices:
                        fill = _ENTRY_COLOR
                    elif vertex.effect != "pure":
                        fill = _SIDE_FX_COLOR
                    else:
                        fill = stage_color

                    sub.node(
                        vertex.name,
                        node_label,
                        fillcolor=fill,
                        tooltip=f"effect: {vertex.effect}",
                    )

        # Draw edges with labels showing data flow when inputs are declared
        adj_labels: dict[tuple[str, str], list[str]] = {}
        for vertex in self.graph.vertices.values():
            for param, binding in (vertex.inputs or {}).items():
                parts = binding.split(".")
                if len(parts) == 2:
                    src_name, output_key = parts
                    key = (src_name, vertex.name)
                    adj_labels.setdefault(key, []).append(f"{output_key}→{param}")

        for edge in self.graph.edges:
            label = ", ".join(adj_labels.get((edge.source, edge.target), []))
            dot.edge(edge.source, edge.target, label=label)

        # Legend for flow entry points
        if self.graph.flows:
            with dot.subgraph(name="cluster_legend") as leg:
                leg.attr(label="Flows", color="#CCCCCC", style="rounded,filled",
                         fillcolor="#FAFAFA", fontsize="11")
                for flow_name, meta in self.graph.flows.items():
                    entry = meta.get("entry", "?")
                    leg.node(
                        f"__flow_{flow_name}",
                        f"▶ {flow_name}\\nentry: {entry}",
                        shape="note",
                        style="filled",
                        fillcolor="#FDEBD0",
                        color="#E59866",
                        fontsize="10",
                    )

        dot.render(output, format="png", cleanup=True)
        return f"{output}.png"
