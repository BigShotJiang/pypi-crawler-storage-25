"""DAG visualizer with fallback to ASCII."""

from __future__ import annotations

from typing import TYPE_CHECKING

from honey_badgeria.visualization.ascii_renderer import AsciiRenderer
from honey_badgeria.visualization.graphviz_renderer import GraphvizRenderer

if TYPE_CHECKING:
    from honey_badgeria.back.graph.graph import Graph


class DagVisualizer:
    """Visualizes a graph. Uses graphviz if available, falls back to ASCII."""

    def __init__(self, graph: Graph) -> None:
        self.graph: Graph = graph
        self.renderer: AsciiRenderer = self._select_renderer()

    def _select_renderer(self) -> AsciiRenderer:
        try:
            return GraphvizRenderer(self.graph) # type: ignore
        except ImportError:
            return AsciiRenderer(self.graph)

    def render(self, output: str = "graph", title: str | None = None) -> str:
        """Render the graph."""
        return self.renderer.render(output, title=title)
