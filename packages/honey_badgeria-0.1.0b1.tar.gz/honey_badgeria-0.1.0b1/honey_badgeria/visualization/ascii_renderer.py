"""ASCII graph renderer (no dependencies)."""

from __future__ import annotations

from typing import TYPE_CHECKING

from honey_badgeria.back.topology import GraphTopology

if TYPE_CHECKING:
    from honey_badgeria.back.graph.graph import Graph

_BOX_WIDTH = 34


def _box(label: str, width: int = _BOX_WIDTH) -> list[str]:
    """Return the lines of a single ASCII box for *label*."""
    inner = width - 2  # subtract border chars
    text = label[:inner].center(inner)
    top    = "┌" + "─" * inner + "┐"
    middle = "│" + text         + "│"
    bottom = "└" + "─" * inner + "┘"
    return [top, middle, bottom]


def _arrow_down(width: int = _BOX_WIDTH) -> str:
    pad = (width - 1) // 2
    return " " * pad + "▼"


class AsciiRenderer:
    """Renders a graph as ASCII art."""

    def __init__(self, graph: Graph) -> None:
        self.graph: Graph = graph
        self.topology: GraphTopology = GraphTopology(graph)

    def render(self, output: str | None = None, title: str | None = None) -> str:
        """Render the graph and return the text."""
        lines: list[str] = []
        stages = self.topology.execution_stages()

        # ── Header ──────────────────────────────────────────────────────────
        heading = title or "HBIA DAG"
        separator = "═" * max(len(heading) + 4, _BOX_WIDTH)
        lines.append("")
        lines.append(separator)
        lines.append(f"  {heading}")
        if self.graph.flows:
            flow_names = ", ".join(self.graph.flows.keys())
            lines.append(f"  flows: {flow_names}")
        lines.append(f"  {len(self.graph.vertices)} vertices · {len(self.graph.edges)} edges")
        lines.append(separator)
        lines.append("")

        # ── Execution stages ─────────────────────────────────────────────────
        entry_vertices: set[str] = {
            meta["entry"]
            for meta in self.graph.flows.values()
            if "entry" in meta
        }
        adj = self.graph.adjacency_list()

        for i, stage in enumerate(stages):
            parallel = len(stage) > 1
            stage_label = (
                f"Step {i + 1}  ({len(stage)} parallel)"
                if parallel
                else f"Step {i + 1}"
            )
            lines.append(f"  ┌── {stage_label} {'─' * max(0, _BOX_WIDTH - len(stage_label) - 6)}┐")

            for vertex in stage:
                marker = "▶ " if vertex.name in entry_vertices else "  "
                handler_hint = ""
                if vertex.handler and isinstance(vertex.handler, str):
                    short = vertex.handler.split(".")[-1]
                    handler_hint = f"  → {short}"
                effect_badge = "" if vertex.effect == "pure" else "  ⚡"
                lines.append(f"  │  {marker}{vertex.name}{handler_hint}{effect_badge}")

            lines.append(f"  └{'─' * (_BOX_WIDTH - 1)}┘")

            # Draw arrows from this stage's vertices to the next
            next_targets: set[str] = set()
            if i < len(stages) - 1:
                for vertex in stage:
                    next_targets.update(adj.get(vertex.name, []))

            if next_targets:
                for t in sorted(next_targets):
                    lines.append(f"       ↓  {t}")
            lines.append("")

        # ── Edge list ────────────────────────────────────────────────────────
        if self.graph.edges:
            lines.append("  Connections")
            lines.append("  " + "─" * (_BOX_WIDTH - 2))
            for edge in self.graph.edges:
                lines.append(f"  {edge.source}  ──▶  {edge.target}")
            lines.append("")

        # ── Flow entry points ────────────────────────────────────────────────
        if self.graph.flows:
            lines.append("  Named flows")
            lines.append("  " + "─" * (_BOX_WIDTH - 2))
            for flow_name, meta in self.graph.flows.items():
                entry = meta.get("entry", "?")
                lines.append(f"  [{flow_name}]  entry → {entry}")
            lines.append("")

        text = "\n".join(lines)

        if output:
            with open(f"{output}.txt", "w") as fh:
                fh.write(text)

        return text
