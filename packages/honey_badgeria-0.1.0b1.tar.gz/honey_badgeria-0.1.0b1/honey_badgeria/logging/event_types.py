"""Event types for structured logging."""


class EventType:
    """Standard event types for HBIA logging."""

    GRAPH_LOADED = "graph.loaded"
    GRAPH_VALIDATED = "graph.validated"

    FLOW_STARTED = "flow.started"
    FLOW_COMPLETED = "flow.completed"
    FLOW_FAILED = "flow.failed"

    VERTEX_STARTED = "vertex.started"
    VERTEX_COMPLETED = "vertex.completed"
    VERTEX_FAILED = "vertex.failed"

    STAGE_STARTED = "stage.started"
    STAGE_COMPLETED = "stage.completed"

    CACHE_HIT = "cache.hit"
    CACHE_MISS = "cache.miss"
    CACHE_SAVED = "cache.saved"

    ATOMIC_GROUP_ENTERED = "atomic.group.entered"
    ATOMIC_SNAPSHOT_SAVED = "atomic.snapshot.saved"
    ATOMIC_COMMITTED = "atomic.committed"
    ATOMIC_ROLLBACK_STARTED = "atomic.rollback.started"
    ATOMIC_ROLLBACK_COMPLETED = "atomic.rollback.completed"
    ATOMIC_ROLLBACK_FAILED = "atomic.rollback.failed"

    SAGA_STARTED = "saga.started"
    SAGA_STEP_STARTED = "saga.step.started"
    SAGA_STEP_COMPLETED = "saga.step.completed"
    SAGA_STEP_FAILED = "saga.step.failed"
    SAGA_COMPENSATING = "saga.compensating"
    SAGA_COMPENSATION_COMPLETED = "saga.compensation.completed"
    SAGA_COMPENSATION_FAILED = "saga.compensation.failed"
    SAGA_COMPLETED = "saga.completed"
    SAGA_FAILED = "saga.failed"
