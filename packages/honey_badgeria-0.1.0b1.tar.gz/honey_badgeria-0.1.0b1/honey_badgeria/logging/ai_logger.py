"""AI-friendly structured logger."""

from __future__ import annotations

import json
import logging
from datetime import datetime, timezone
from typing import Any

from honey_badgeria.logging.event_types import EventType


class AILogger:
    """Structured logger optimized for AI consumption."""

    def __init__(self, name: str = "hbia", level: int = logging.INFO) -> None:
        self.logger: logging.Logger = logging.getLogger(name)
        self.logger.setLevel(level)
        self._events: list[dict[str, Any]] = []

    def log(self, event_type: str, data: dict[str, Any] | None = None, level: int = logging.INFO) -> None:
        """Log a structured event."""
        entry: dict[str, Any] = {
            "timestamp": datetime.now(timezone.utc).isoformat(),
            "event": event_type,
            "data": data or {},
        }
        self._events.append(entry)
        self.logger.log(level, json.dumps(entry))

    def vertex_started(self, vertex_name: str) -> None:
        self.log(EventType.VERTEX_STARTED, {"vertex": vertex_name})

    def vertex_completed(self, vertex_name: str, result_keys: list[str] | None = None) -> None:
        self.log(EventType.VERTEX_COMPLETED, {
            "vertex": vertex_name,
            "output_keys": result_keys or [],
        })

    def flow_started(self, flow_name: str) -> None:
        self.log(EventType.FLOW_STARTED, {"flow": flow_name})

    def flow_completed(self, flow_name: str) -> None:
        self.log(EventType.FLOW_COMPLETED, {"flow": flow_name})

    def get_events(self) -> list[dict[str, Any]]:
        """Return all logged events."""
        return list(self._events)

    def clear(self) -> None:
        """Clear event history."""
        self._events.clear()
