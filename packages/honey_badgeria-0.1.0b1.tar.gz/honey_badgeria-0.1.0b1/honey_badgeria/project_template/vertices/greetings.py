"""Vertex handlers: greetings domain.

Each function is a vertex handler — it receives keyword arguments
and returns a dict whose keys become `vertex_name.key` in the data store.
"""

from honey_badgeria.decorators import vertex


@vertex
def hello(name="World"):
    """Produce a greeting message.

    Inputs:
        name: The name to greet (default: "World").

    Outputs:
        greeting: The greeting string.
    """
    return {"greeting": f"Hello, {name}!"}


@vertex
def shout(greeting):
    """Transform a greeting to uppercase.

    Inputs:
        greeting: The greeting to transform.

    Outputs:
        result: The uppercased greeting.
    """
    return {"result": greeting.upper()}
