"""Example test for the greet flow."""

from honey_badgeria.testing import GraphFactory, FlowTester


class TestGreetingFlow:

    def test_hello_shout_pipeline(self):
        """Verify hello → shout produces an uppercased greeting."""

        def hello(name="World"):
            return {"greeting": f"Hello, {name}!"}

        def shout(greeting):
            return {"result": greeting.upper()}

        graph = GraphFactory.create(
            vertices=[
                {"name": "hello", "handler": hello},
                {
                    "name": "shout",
                    "handler": shout,
                    "inputs": {"greeting": "hello.greeting"},
                },
            ],
            edges=[("hello", "shout")],
        )
        tester = FlowTester(graph)
        result = tester.run()
        assert result["shout.result"] == "HELLO, WORLD!"

    def test_hello_with_custom_name(self):
        """Verify initial_data flows into the vertex."""

        def hello(name="World"):
            return {"greeting": f"Hello, {name}!"}

        def shout(greeting):
            return {"result": greeting.upper()}

        graph = GraphFactory.create(
            vertices=[
                {"name": "hello", "handler": hello},
                {
                    "name": "shout",
                    "handler": shout,
                    "inputs": {"greeting": "hello.greeting"},
                },
            ],
            edges=[("hello", "shout")],
        )
        tester = FlowTester(graph)
        result = tester.run(initial_data={"name": "Badger"})
        assert "BADGER" in result["shout.result"]
