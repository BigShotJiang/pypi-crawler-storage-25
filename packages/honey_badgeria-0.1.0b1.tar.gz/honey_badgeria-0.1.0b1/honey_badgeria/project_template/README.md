# My HBIA Project

> Built with [Honey Badgeria](https://github.com/your-org/honey-badgeria) — an Application framework designed for AI-assisted development.

## Quick Start

```bash
# Install dependencies
pip install honey-badgeria[all]

# Verify installation
hbia doctor

# Run the example flow
hbia run flows/example_flow.yaml --handlers vertices

# Or use manage.py
python manage.py
```

## Project Structure

```
├── README.md               ← You are here
├── settings.py             ← HBIA configuration
├── manage.py               ← Quick-run entry point
├── flows/                  ← Graph definitions (YAML) — the source of truth
│   └── example_flow.yaml
├── vertices/               ← Vertex handlers organized by domain
│   └── greetings.py
├── tests/                  ← pytest tests
│   └── test_flow_example.py
└── AGENTS.md               ← AI assistant instructions (auto-generated)
```

## Key Concepts

| Concept | What it is |
|---------|-----------|
| **Vertex** | A single operation (Python function) in the graph |
| **Edge** | A directed dependency between two vertices |
| **Flow** | A named entry point into the graph |
| **Graph** | The DAG connecting vertices via edges |

## Common Commands

| Command | What it does |
|---------|-------------|
| `hbia run <file>` | Execute a graph YAML file |
| `hbia validate <file>` | Check a YAML file for errors |
| `hbia inspect <file>` | Show topology, stages, data flow |
| `hbia explain <file>` | Human/AI-readable explanation |
| `hbia viz <file>` | Visualize the graph (ASCII or Graphviz) |
| `hbia health` | Detect tech debt (large files, cycles, dupes) |
| `hbia doctor` | Check environment and dependencies |
| `hbia vertex-create <name>` | Scaffold a new vertex handler |
| `hbia context --write` | Regenerate AI context files |

## How to Add a New Feature

1. **Define the flow** — create or edit a YAML file in `flows/`
2. **Write the handlers** — add vertex functions in `vertices/`
3. **Wire the edges** — connect vertices in the YAML
4. **Test** — write a test in `tests/` using `GraphFactory` + `FlowTester`
5. **Validate** — run `hbia validate flows/your_flow.yaml`
6. **Run** — `hbia run flows/your_flow.yaml --handlers vertices`

## Organizing Vertices

Group vertex handlers by **domain** in subfolders:

```
vertices/
├── __init__.py
├── auth/
│   ├── __init__.py
│   ├── login.py
│   └── register.py
├── payments/
│   ├── __init__.py
│   ├── charge.py
│   └── refund.py
└── users/
    ├── __init__.py
    └── profile.py
```

Handlers are referenced by dotted path: `vertices.auth.login.login_user`

## Running Tests

```bash
pytest tests/ -v
```

## Configuration

Edit `settings.py` to enable features:

```python
SETTINGS = {
    "CACHE_ENABLED": True,       # Cache pure vertex results
    "PARALLEL_ENABLED": True,    # Run independent vertices in parallel
    "ASYNC_ENABLED": True,       # Await async handlers natively
    "MAX_WORKERS": 8,            # Thread pool size for parallel mode
}
```

Or use environment variables: `HBIA_CACHE_ENABLED=true`
