"""Honey Badgeria project settings — single source of truth.

ALL configuration lives here.  NEVER use ``os.environ`` directly in
handlers, vertices, or application code.  Import from this module::

    from settings import SETTINGS
"""

import os
from pathlib import Path

BASE_DIR = Path(__file__).resolve().parent

try:
    from dotenv import load_dotenv
    load_dotenv(BASE_DIR / ".env")
except ImportError:
    pass


def _env(key: str, default: str = "") -> str:
    """Read an environment variable (centralized — use this, not os.environ)."""
    return os.environ.get(key, default)


def _env_bool(key: str, default: bool = False) -> bool:
    return _env(key, str(default)).strip().lower() in ("true", "1", "yes")


def _env_int(key: str, default: int = 0) -> int:
    try:
        return int(_env(key, str(default)))
    except (ValueError, TypeError):
        return default


SETTINGS = {
    "GRAPH_FILE": _env("HBIA_GRAPH_FILE", "flows/example_flow.yaml"),
    "HANDLER_MODULES": [m.strip() for m in _env("HBIA_HANDLER_MODULES", "vertices").split(",") if m.strip()],
    "CACHE_ENABLED": _env_bool("HBIA_CACHE_ENABLED", False),
    "PARALLEL_ENABLED": _env_bool("HBIA_PARALLEL_ENABLED", False),
    "ASYNC_ENABLED": _env_bool("HBIA_ASYNC_ENABLED", False),
    "MAX_WORKERS": _env_int("HBIA_MAX_WORKERS", 4),
}
