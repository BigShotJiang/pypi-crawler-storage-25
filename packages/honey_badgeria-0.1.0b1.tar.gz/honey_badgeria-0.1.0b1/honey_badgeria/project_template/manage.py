#!/usr/bin/env python
"""HBIA project entry point — runs the default flow.

Usage:
    python manage.py                    # run the default graph
    python manage.py --flow greet       # run a specific flow
"""

import os
import sys

# ── Fix PYTHONPATH so imports work from the project root ──────────
PROJECT_ROOT = os.path.dirname(os.path.abspath(__file__))
if PROJECT_ROOT not in sys.path:
    sys.path.insert(0, PROJECT_ROOT)

from honey_badgeria.conf.settings import configure
from honey_badgeria.back.dsl.loader import load_graph_from_yaml
from honey_badgeria.back.runtime.runner import run_flow


def main():
    from settings import SETTINGS

    configure(SETTINGS)
    graph_file = SETTINGS.get("GRAPH_FILE", "flows/example_flow.yaml")
    graph = load_graph_from_yaml(graph_file)

    flow_name = None
    if "--flow" in sys.argv:
        idx = sys.argv.index("--flow")
        if idx + 1 < len(sys.argv):
            flow_name = sys.argv[idx + 1]

    result = run_flow(graph, flow_name=flow_name)

    print("=== Results ===")
    for key, value in sorted(result.items()):
        print(f"  {key}: {value}")


if __name__ == "__main__":
    main()
