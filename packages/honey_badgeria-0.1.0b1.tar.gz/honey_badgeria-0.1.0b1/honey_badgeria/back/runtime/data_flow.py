"""Data flow engine: resolves inputs and stores outputs."""

from __future__ import annotations

from typing import Any, TYPE_CHECKING

if TYPE_CHECKING:
    from honey_badgeria.back.graph.vertex import Vertex
    from honey_badgeria.back.runtime.data_store import DataStore
    from honey_badgeria.back.runtime.lineage import DataLineage


class DataFlowEngine:
    """Manages data movement between vertices."""

    def __init__(
        self,
        data_store: DataStore,
        lineage: DataLineage | None = None,
    ) -> None:
        self.data_store = data_store
        self.lineage = lineage

    def resolve_inputs(self, vertex: Vertex) -> dict[str, Any]:
        """Resolve all input bindings for a vertex."""
        resolved: dict[str, Any] = {}

        if not vertex.inputs:
            return resolved

        for param_name, source_ref in vertex.inputs.items():
            if isinstance(source_ref, str) and "." in source_ref:
                resolved[param_name] = self.data_store.get_output(source_ref)
            elif self.data_store.has_output(param_name):
                resolved[param_name] = self.data_store.get_output(param_name)

        return resolved

    def store_outputs(self, vertex: Vertex, result: Any) -> None:
        """Store vertex outputs with qualified names."""
        if not isinstance(result, dict):
            return

        for key, value in result.items():
            qualified: str = f"{vertex.name}.{key}"
            self.data_store.set_output(qualified, value)

            if self.lineage:
                self.lineage.record(
                    output_name=qualified,
                    vertex_id=vertex.name,
                    inputs_used=list(vertex.inputs.keys()),
                )
