"""Execution scheduler for graph stages."""

from __future__ import annotations

from typing import TYPE_CHECKING

from honey_badgeria.back.topology import GraphTopology

if TYPE_CHECKING:
    from honey_badgeria.back.graph.graph import Graph
    from honey_badgeria.back.graph.vertex import Vertex


class ExecutionScheduler:
    """Schedules vertex execution based on graph topology."""

    def __init__(self, graph: Graph) -> None:
        self.graph: Graph = graph
        self.topology: GraphTopology = GraphTopology(graph)

    def schedule(self) -> list[list[Vertex]]:
        """Return execution stages (lists of :class:`Vertex`)."""
        return self.topology.execution_stages()

    def execution_order(self) -> list[str]:
        """Return vertex names in topological order."""
        return self.topology.topological_sort()
