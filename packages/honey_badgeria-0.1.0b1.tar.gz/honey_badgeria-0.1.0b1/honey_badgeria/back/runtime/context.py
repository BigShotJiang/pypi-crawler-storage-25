"""Execution context for graph runs."""

from __future__ import annotations

from typing import Any


class ExecutionContext:
    """Holds runtime state for a single graph execution."""

    def __init__(
        self,
        flow_name: str | None = None,
        metadata: dict[str, Any] | None = None,
    ) -> None:
        self.flow_name: str | None = flow_name
        self.metadata: dict[str, Any] = metadata or {}
        self._flags: dict[str, Any] = {}

    def set_flag(self, key: str, value: Any = True) -> None:
        """Set an execution flag."""
        self._flags[key] = value

    def get_flag(self, key: str, default: Any = None) -> Any:
        """Get an execution flag."""
        return self._flags.get(key, default)

    def __repr__(self) -> str:
        return f"<ExecutionContext flow={self.flow_name}>"
