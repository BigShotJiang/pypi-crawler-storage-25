"""Data lineage tracking."""

from __future__ import annotations

from typing import Any


class DataLineage:
    """Tracks the origin of every data output produced in the graph."""

    def __init__(self) -> None:
        self._lineage: dict[str, dict[str, Any]] = {}

    def record(
        self,
        output_name: str,
        vertex_id: str,
        inputs_used: list[str],
    ) -> None:
        self._lineage[output_name] = {
            "produced_by": vertex_id,
            "inputs": list(inputs_used),
        }

    def get_origin(self, output_name: str) -> dict[str, Any] | None:
        return self._lineage.get(output_name)

    def trace(self, output_name: str) -> list[dict[str, Any]]:
        chain: list[dict[str, Any]] = []
        current: str = output_name

        while current in self._lineage:
            node = self._lineage[current]
            chain.append({
                "output": current,
                "vertex": node["produced_by"],
                "inputs": node["inputs"],
            })
            if not node["inputs"]:
                break
            current = node["inputs"][0]

        return chain

    def dump(self) -> dict[str, dict[str, Any]]:
        return dict(self._lineage)
