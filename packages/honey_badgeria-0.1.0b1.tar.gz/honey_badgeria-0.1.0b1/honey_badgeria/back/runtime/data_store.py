"""Data store for intermediate graph data."""

from __future__ import annotations

from typing import Any

from honey_badgeria.core.exceptions import DataResolutionError


class DataStore:
    """Holds intermediate data produced by vertex executions."""

    def __init__(self) -> None:
        self._data: dict[str, Any] = {}

    def set_output(self, key: str, value: Any) -> None:
        """Store an output value."""
        self._data[key] = value

    def get_output(self, key: str) -> Any:
        """Get an output value.

        Raises:
            DataResolutionError: If the key is not in the store.
        """
        if key not in self._data:
            raise DataResolutionError(f"Missing data for key '{key}'")
        return self._data[key]

    def has_output(self, key: str) -> bool:
        """Check if an output exists."""
        return key in self._data

    def dump(self) -> dict[str, Any]:
        """Return all stored data as a dict."""
        return dict(self._data)

    def clear(self) -> None:
        """Clear all stored data."""
        self._data.clear()
