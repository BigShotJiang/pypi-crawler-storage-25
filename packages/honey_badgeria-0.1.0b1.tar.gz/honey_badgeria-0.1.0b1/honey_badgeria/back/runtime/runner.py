"""High-level API for running flows.

This is the simplest entry point for executing a graph.  All execution-mode
flags (cache, parallel, async) are inherited from the global ``Settings``
unless overridden with keyword arguments.
"""

from __future__ import annotations

import asyncio
from typing import Any, Callable, TYPE_CHECKING

from honey_badgeria.back.runtime.executor import GraphExecutor
from honey_badgeria.core.exceptions import HandlerNotFoundError

if TYPE_CHECKING:
    from honey_badgeria.back.graph.graph import Graph
    from honey_badgeria.back.atomicity.backends import TransactionBackend


def run_flow(
    graph: Graph,
    flow_name: str | None = None,
    handlers: dict[str, Callable[..., Any]] | Callable[..., Callable[..., Any]] | None = None,
    initial_data: dict[str, Any] | None = None,
    *,
    cache_enabled: bool | None = None,
    parallel_enabled: bool | None = None,
    async_enabled: bool | None = None,
    max_workers: int | None = None,
    transaction_backend: TransactionBackend | None = None,
) -> dict[str, Any]:
    """High-level API to run a flow synchronously.

    If *flow_name* is given, only the sub-graph reachable from the
    flow's entry vertex is executed.

    *transaction_backend* is an optional :class:`TransactionBackend`
    used by atomic groups for snapshot / commit / rollback.
    """
    target = _resolve_flow_graph(graph, flow_name)
    resolver = _build_resolver(handlers)
    executor = GraphExecutor(
        target,
        handler_resolver=resolver,
        cache_enabled=cache_enabled,
        parallel_enabled=parallel_enabled,
        async_enabled=async_enabled,
        max_workers=max_workers,
        transaction_backend=transaction_backend,
    )
    return executor.execute(initial_data)


async def run_flow_async(
    graph: Graph,
    flow_name: str | None = None,
    handlers: dict[str, Callable[..., Any]] | Callable[..., Callable[..., Any]] | None = None,
    initial_data: dict[str, Any] | None = None,
    *,
    cache_enabled: bool | None = None,
    parallel_enabled: bool | None = None,
    async_enabled: bool | None = None,
    max_workers: int | None = None,
    transaction_backend: TransactionBackend | None = None,
) -> dict[str, Any]:
    """High-level API to run a flow asynchronously.

    If *flow_name* is given, only the sub-graph reachable from the
    flow's entry vertex is executed.

    *transaction_backend* is an optional :class:`TransactionBackend`
    used by atomic groups for snapshot / commit / rollback.
    """
    target = _resolve_flow_graph(graph, flow_name)
    resolver = _build_resolver(handlers)
    executor = GraphExecutor(
        target,
        handler_resolver=resolver,
        cache_enabled=cache_enabled,
        parallel_enabled=parallel_enabled,
        async_enabled=True if async_enabled is None else async_enabled,
        max_workers=max_workers,
        transaction_backend=transaction_backend,
    )
    return await executor.execute_async(initial_data)


# ------------------------------------------------------------------
# helpers
# ------------------------------------------------------------------

def _resolve_flow_graph(graph: Graph, flow_name: str | None) -> Graph:
    """Return the sub-graph for *flow_name*, or the full graph if None.

    When a flow is specified, only vertices reachable from the flow's
    entry vertex are included.  This prevents executing unrelated
    vertices when a graph contains multiple flows.
    """
    if flow_name is None:
        return graph

    from honey_badgeria.back.graph.graph import Graph as GraphCls
    from honey_badgeria.back.graph.edge import Edge

    entry = graph.entry_vertex(flow_name)  # raises FlowNotFoundError

    # BFS to find reachable vertices
    adj = graph.adjacency_list()
    visited: set[str] = set()
    queue = [entry.name]
    while queue:
        current = queue.pop(0)
        if current in visited:
            continue
        visited.add(current)
        for neighbor in adj.get(current, []):
            if neighbor not in visited:
                queue.append(neighbor)

    # Build sub-graph
    sub = GraphCls()
    for name in visited:
        sub.add_vertex(graph.get_vertex(name))
    for edge in graph.edges:
        if edge.source in visited and edge.target in visited:
            sub.add_edge(Edge(source=edge.source, target=edge.target))
    sub.flows = {flow_name: graph.flows[flow_name]}

    # Carry over atomic groups whose vertices are fully within the sub-graph
    for gname, group in graph.atomic_groups.items():
        if set(group.vertices) <= visited:
            sub.atomic_groups[gname] = group

    return sub


def _build_resolver(
    handlers: dict[str, Callable[..., Any]] | Callable[..., Callable[..., Any]] | None,
) -> Callable[..., Callable[..., Any]] | None:
    """Turn *handlers* into a resolver callable accepted by GraphExecutor."""
    if isinstance(handlers, dict):
        handler_dict = handlers

        def resolver(name: Any) -> Callable[..., Any]:
            if callable(name):
                return name
            if name in handler_dict:
                return handler_dict[name]
            raise HandlerNotFoundError(f"No handler registered for: {name}")

        return resolver

    if handlers is not None:
        return handlers

    return None
