"""State store for tracking execution state."""

from __future__ import annotations


class StateStore:
    """Tracks execution state of vertices."""

    PENDING: str = "pending"
    RUNNING: str = "running"
    COMPLETED: str = "completed"
    FAILED: str = "failed"
    SKIPPED: str = "skipped"

    def __init__(self) -> None:
        self._states: dict[str, str] = {}

    def set_state(self, vertex_name: str, state: str) -> None:
        self._states[vertex_name] = state

    def get_state(self, vertex_name: str) -> str:
        return self._states.get(vertex_name, self.PENDING)

    def is_completed(self, vertex_name: str) -> bool:
        return self._states.get(vertex_name) == self.COMPLETED

    def all_completed(self) -> bool:
        return all(s == self.COMPLETED for s in self._states.values())

    def dump(self) -> dict[str, str]:
        return dict(self._states)
