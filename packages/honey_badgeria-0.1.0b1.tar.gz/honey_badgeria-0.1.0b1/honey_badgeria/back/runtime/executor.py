"""Graph executor: runs vertices through execution stages.

Supports three execution modes controlled by :class:`Settings`:

    Serial (default)
        Every vertex runs one at a time, in topological order.
        No threads, no asyncio.  Safest mode.

    Parallel (``PARALLEL_ENABLED=True``)
        Vertices in the same execution stage run concurrently
        inside a :class:`concurrent.futures.ThreadPoolExecutor`.
        ``MAX_WORKERS`` controls the pool size.

    Async (``ASYNC_ENABLED=True``)
        Async handler coroutines are ``await``-ed natively.
        When combined with ``PARALLEL_ENABLED`` the executor will
        ``asyncio.gather`` all vertices in a stage.

    Cache (``CACHE_ENABLED=True``)
        Before executing a vertex the executor checks the cache.
        On a hit the cached result is used; on a miss the handler
        runs and the result is stored.

    Atomic groups
        Vertices declared in an :class:`AtomicGroup` are wrapped
        inside an :class:`AtomicContext` which snapshots state before
        the group, commits on success, and rolls back on failure.
        Cache and parallelism are suppressed for vertices inside
        an atomic boundary (``no_cache`` / ``no_parallel``).
"""

from __future__ import annotations

import asyncio
import inspect
from concurrent.futures import ThreadPoolExecutor
from typing import Any, Callable, TYPE_CHECKING

from honey_badgeria.back.topology import GraphTopology
from honey_badgeria.back.runtime.data_store import DataStore
from honey_badgeria.back.runtime.data_flow import DataFlowEngine
from honey_badgeria.back.runtime.lineage import DataLineage
from honey_badgeria.back.runtime.state_store import StateStore
from honey_badgeria.back.runtime.cache.cache_manager import CacheManager
from honey_badgeria.core.exceptions import HandlerNotFoundError
from honey_badgeria.conf.settings import Settings, get_settings
from honey_badgeria.logging.ai_logger import AILogger
from honey_badgeria.logging.event_types import EventType

if TYPE_CHECKING:
    from honey_badgeria.back.graph.graph import Graph
    from honey_badgeria.back.graph.vertex import Vertex
    from honey_badgeria.back.atomicity.group import AtomicGroup
    from honey_badgeria.back.atomicity.backends import TransactionBackend


class GraphExecutor:
    """Executes a graph by running vertices stage by stage.

    Respects the global ``Settings`` for cache / parallel / async.
    All three can be overridden per-call via constructor kwargs.
    """

    def __init__(
        self,
        graph: Graph,
        handler_resolver: Callable[..., Callable[..., Any]] | None = None,
        *,
        settings: Settings | None = None,
        cache_enabled: bool | None = None,
        parallel_enabled: bool | None = None,
        async_enabled: bool | None = None,
        max_workers: int | None = None,
        logger: AILogger | None = None,
        transaction_backend: TransactionBackend | None = None,
    ) -> None:
        self.graph: Graph = graph
        self.handler_resolver: Callable[..., Callable[..., Any]] = (
            handler_resolver or self._default_resolver
        )

        # --- settings resolution (explicit kwarg > explicit settings > global) ---
        s = settings or get_settings()
        self._cache_enabled: bool = cache_enabled if cache_enabled is not None else s.CACHE_ENABLED
        self._parallel_enabled: bool = parallel_enabled if parallel_enabled is not None else s.PARALLEL_ENABLED
        self._async_enabled: bool = async_enabled if async_enabled is not None else s.ASYNC_ENABLED
        self._max_workers: int = max_workers if max_workers is not None else s.MAX_WORKERS

        # --- internal state ---
        self.data_store: DataStore = DataStore()
        self.lineage: DataLineage = DataLineage()
        self.data_flow: DataFlowEngine = DataFlowEngine(self.data_store, self.lineage)
        self.state_store: StateStore = StateStore()
        self.logger: AILogger = logger or AILogger()

        # --- cache ---
        self._cache: CacheManager | None = CacheManager(s.CACHE_DIR) if self._cache_enabled else None

        # --- atomicity ---
        self._transaction_backend: TransactionBackend | None = transaction_backend
        self._active_atomic_groups: set[str] = set()
        # Pre-compute set of vertices in any atomic group
        self._atomic_vertex_set: frozenset[str] = graph.vertices_in_atomic_groups()

        # --- topology ---
        topo = GraphTopology(graph)
        self.stages: list[list[Vertex]] = topo.execution_stages()
        self._source_vertices: set[str] = set(topo.sources())

    # ------------------------------------------------------------------
    # public API
    # ------------------------------------------------------------------

    def execute(self, initial_data: dict[str, Any] | None = None) -> dict[str, Any]:
        """Execute the graph synchronously (serial or parallel)."""
        self._seed(initial_data)
        self._seeded_data: dict[str, Any] = dict(initial_data) if initial_data else {}

        # Build a stage-execution plan that respects atomic boundaries.
        plan = self._build_execution_plan()
        for step in plan:
            if step["atomic_group"] is not None:
                # All stages in this chunk run inside one AtomicContext.
                self._execute_atomic_chunk(
                    step["atomic_group"],
                    step["stages"],
                )
            else:
                for stage in step["stages"]:
                    self._run_stage(stage)

        return self.data_store.dump()

    async def execute_async(self, initial_data: dict[str, Any] | None = None) -> dict[str, Any]:
        """Execute the graph asynchronously."""
        self._seed(initial_data)
        self._seeded_data: dict[str, Any] = dict(initial_data) if initial_data else {}

        plan = self._build_execution_plan()
        for step in plan:
            if step["atomic_group"] is not None:
                await self._execute_atomic_chunk_async(
                    step["atomic_group"],
                    step["stages"],
                )
            else:
                for stage in step["stages"]:
                    await self._run_stage_async(stage)

        return self.data_store.dump()

    # ------------------------------------------------------------------
    # internal - execution plan
    # ------------------------------------------------------------------

    def _build_execution_plan(self) -> list[dict[str, Any]]:
        """Group stages into an ordered plan of atomic / non-atomic chunks.

        Each entry is ``{"atomic_group": group | None, "stages": [...]}``.
        Consecutive stages that belong to the same atomic group are merged
        into one chunk so they can share a single AtomicContext.
        """
        plan: list[dict[str, Any]] = []

        for stage in self.stages:
            group = self._dominant_atomic_group(stage)

            # Try to merge with the previous chunk if it's the same group
            if plan and plan[-1]["atomic_group"] is not None and group is not None:
                if plan[-1]["atomic_group"].name == group.name:
                    plan[-1]["stages"].append(stage)
                    continue

            # Otherwise start a new chunk
            plan.append({"atomic_group": group, "stages": [stage]})

        return plan

    def _dominant_atomic_group(self, stage: list[Vertex]) -> AtomicGroup | None:
        """If any vertex in the stage belongs to an atomic group, return it.

        If the stage contains vertices from multiple atomic groups we
        return the first one found (the validator should have caught
        this case at build time).
        """
        for vertex in stage:
            g = self.graph.atomic_group_for_vertex(vertex.name)
            if g is not None:
                return g
        return None

    # ------------------------------------------------------------------
    # internal - seeding
    # ------------------------------------------------------------------

    def _seed(self, initial_data: dict[str, Any] | None) -> None:
        if initial_data:
            for key, value in initial_data.items():
                self.data_store.set_output(key, value)

    # ------------------------------------------------------------------
    # internal - stage dispatch (sync)
    # ------------------------------------------------------------------

    def _run_stage(self, stage: list[Vertex]) -> None:
        """Run a stage, respecting atomic group boundaries.

        If *any* vertex in the stage is inside an atomic group that
        declares ``no_parallel``, the entire stage runs serially.
        """
        force_serial = self._stage_forces_serial(stage)

        if self._parallel_enabled and len(stage) > 1 and not force_serial:
            self._run_stage_parallel(stage)
        else:
            self._run_stage_serial(stage)

    # ------------------------------------------------------------------
    # internal - serial execution
    # ------------------------------------------------------------------

    def _run_stage_serial(self, stage: list[Vertex]) -> None:
        for vertex in stage:
            self._execute_vertex(vertex)

    def _execute_vertex(self, vertex: Vertex) -> dict[str, Any] | Any:
        """Execute a single vertex (sync path)."""
        self.state_store.set_state(vertex.name, StateStore.RUNNING)
        self.logger.vertex_started(vertex.name)

        # If vertex is inside an atomic group, check cache/parallel policy
        in_atomic = vertex.name in self._active_atomic_groups

        try:
            handler = self.handler_resolver(vertex.handler)
            inputs = self.data_flow.resolve_inputs(vertex)

            # If this is a source vertex (no incoming edges), seed it with the
            # provided initial_data. This allows entrypoint handlers to accept
            # values from the external caller without requiring explicit
            # `inputs:` bindings in the YAML.
            if not inputs and vertex.name in self._source_vertices:
                inputs = dict(self._seeded_data)

            # --- contract: validate inputs ---
            self._validate_contract_inputs(vertex, inputs)

            # --- cache check (only for pure vertices, disabled inside atomic) ---
            if not in_atomic:
                cached = self._cache_lookup(vertex, inputs)
                if cached is not None:
                    self.data_flow.store_outputs(vertex, cached)
                    self.state_store.set_state(vertex.name, StateStore.COMPLETED)
                    return cached

            # --- actual execution ---
            if self._async_enabled and inspect.iscoroutinefunction(handler):
                result = asyncio.run(handler(**inputs))
            else:
                result = handler(**inputs)

            # --- contract: validate outputs ---
            self._validate_contract_outputs(vertex, result)

            self.data_flow.store_outputs(vertex, result)

            if not in_atomic:
                self._cache_save(vertex, inputs, result)

            self.state_store.set_state(vertex.name, StateStore.COMPLETED)
            self.logger.vertex_completed(vertex.name, list(result.keys()) if isinstance(result, dict) else [])
            return result

        except Exception:
            self.state_store.set_state(vertex.name, StateStore.FAILED)
            raise

    # ------------------------------------------------------------------
    # internal - atomic group execution
    # ------------------------------------------------------------------

    def _execute_atomic_chunk(
        self,
        group: AtomicGroup,
        stages: list[list[Vertex]],
    ) -> None:
        """Run all *stages* inside a single AtomicContext for *group*."""
        from honey_badgeria.back.atomicity.context import AtomicContext
        from honey_badgeria.back.atomicity.backends import InMemoryBackend

        backend = self._transaction_backend or InMemoryBackend()

        ctx = AtomicContext(
            group=group,
            backend=backend,
            data_store=self.data_store,
            state_store=self.state_store,
            lineage=self.lineage,
            logger=self.logger,
        )

        # Mark all vertices in the group as inside an atomic boundary
        vertex_names = {v.name for stage in stages for v in stage}
        self._active_atomic_groups |= vertex_names

        try:
            with ctx:
                for stage in stages:
                    # Force serial inside an atomic context
                    for vertex in stage:
                        self._execute_vertex(vertex)
        finally:
            self._active_atomic_groups -= vertex_names

    async def _execute_atomic_chunk_async(
        self,
        group: AtomicGroup,
        stages: list[list[Vertex]],
    ) -> None:
        """Async variant of _execute_atomic_chunk."""
        from honey_badgeria.back.atomicity.context import AtomicContext
        from honey_badgeria.back.atomicity.backends import InMemoryBackend

        backend = self._transaction_backend or InMemoryBackend()

        ctx = AtomicContext(
            group=group,
            backend=backend,
            data_store=self.data_store,
            state_store=self.state_store,
            lineage=self.lineage,
            logger=self.logger,
        )

        vertex_names = {v.name for stage in stages for v in stage}
        self._active_atomic_groups |= vertex_names

        try:
            with ctx:
                for stage in stages:
                    for vertex in stage:
                        await self._execute_vertex_async(vertex)
        finally:
            self._active_atomic_groups -= vertex_names

    # ------------------------------------------------------------------
    # internal - parallel execution (threads)
    # ------------------------------------------------------------------

    def _run_stage_parallel(self, stage: list[Vertex]) -> None:
        """Run all vertices in a stage concurrently using threads."""
        with ThreadPoolExecutor(max_workers=self._max_workers) as pool:
            futures = {pool.submit(self._execute_vertex, v): v for v in stage}
            for future in futures:
                future.result()  # propagate exceptions

    # ------------------------------------------------------------------
    # internal - async execution
    # ------------------------------------------------------------------

    async def _run_stage_async(self, stage: list[Vertex]) -> None:
        """Async stage dispatch — same atomic-aware logic as sync."""
        force_serial = self._stage_forces_serial(stage)

        if self._parallel_enabled and len(stage) > 1 and not force_serial:
            await self._run_stage_async_parallel(stage)
        else:
            for vertex in stage:
                await self._execute_vertex_async(vertex)

    async def _execute_vertex_async(self, vertex: Vertex) -> dict[str, Any] | Any:
        """Execute a single vertex (async path)."""
        self.state_store.set_state(vertex.name, StateStore.RUNNING)
        self.logger.vertex_started(vertex.name)

        in_atomic = vertex.name in self._active_atomic_groups

        try:
            handler = self.handler_resolver(vertex.handler)
            inputs = self.data_flow.resolve_inputs(vertex)

            # If this is a source vertex (no incoming edges), seed it with the
            # provided initial_data. This allows entrypoint handlers to accept
            # values from the external caller without requiring explicit
            # `inputs:` bindings in the YAML.
            if not inputs and vertex.name in self._source_vertices:
                inputs = dict(self._seeded_data)

            # --- contract: validate inputs ---
            self._validate_contract_inputs(vertex, inputs)

            if not in_atomic:
                cached = self._cache_lookup(vertex, inputs)
                if cached is not None:
                    self.data_flow.store_outputs(vertex, cached)
                    self.state_store.set_state(vertex.name, StateStore.COMPLETED)
                    return cached

            if inspect.iscoroutinefunction(handler):
                result = await handler(**inputs)
            else:
                result = handler(**inputs)

            # --- contract: validate outputs ---
            self._validate_contract_outputs(vertex, result)

            self.data_flow.store_outputs(vertex, result)

            if not in_atomic:
                self._cache_save(vertex, inputs, result)

            self.state_store.set_state(vertex.name, StateStore.COMPLETED)
            self.logger.vertex_completed(vertex.name, list(result.keys()) if isinstance(result, dict) else [])
            return result

        except Exception:
            self.state_store.set_state(vertex.name, StateStore.FAILED)
            raise

    async def _execute_atomic_group_async(
        self,
        group: AtomicGroup,
        vertices: list[Vertex],
    ) -> None:
        """Async variant of _execute_atomic_group."""
        from honey_badgeria.back.atomicity.context import AtomicContext
        from honey_badgeria.back.atomicity.backends import InMemoryBackend

        backend = self._transaction_backend or InMemoryBackend()

        ctx = AtomicContext(
            group=group,
            backend=backend,
            data_store=self.data_store,
            state_store=self.state_store,
            lineage=self.lineage,
            logger=self.logger,
        )

        vertex_names = {v.name for v in vertices}
        self._active_atomic_groups |= vertex_names

        try:
            with ctx:
                for vertex in vertices:
                    await self._execute_vertex_async(vertex)
        finally:
            self._active_atomic_groups -= vertex_names

    async def _run_stage_async_parallel(self, stage: list[Vertex]) -> None:
        """Gather all vertices in a stage concurrently via asyncio."""
        await asyncio.gather(*(self._execute_vertex_async(v) for v in stage))

    # ------------------------------------------------------------------
    # internal - atomicity helpers
    # ------------------------------------------------------------------

    def _stage_forces_serial(self, stage: list[Vertex]) -> bool:
        """Return True if the stage must run serially due to atomic groups."""
        for vertex in stage:
            group = self.graph.atomic_group_for_vertex(vertex.name)
            if group is not None and group.no_parallel:
                return True
        return False

    # ------------------------------------------------------------------
    # internal - contract enforcement
    # ------------------------------------------------------------------

    @staticmethod
    def _validate_contract_inputs(vertex: Vertex, inputs: dict[str, Any]) -> None:
        """Validate *inputs* against the vertex's declared output types.

        Only fires when the vertex has typed *outputs* declared (which
        HBIA treats as contract declarations).  Silently passes when
        no contract is present so that uncontracted vertices still work.
        """
        from honey_badgeria.back.contracts.contract import VertexContract

        if not vertex.inputs:
            return
        # Only validate when the declared types are actual type names,
        # not data-binding references (e.g. "step1.value").
        type_inputs = {
            k: v for k, v in vertex.inputs.items()
            if v in VertexContract.__init__.__code__.co_varnames  # cheap guard
            or v in ("str", "int", "float", "bool", "dict", "list",
                      "tuple", "set", "bytes", "none")
        }
        if type_inputs:
            contract = VertexContract(inputs=type_inputs)
            contract.validate_input(inputs)

    @staticmethod
    def _validate_contract_outputs(vertex: Vertex, result: Any) -> None:
        """Validate *result* against the vertex's declared output types."""
        from honey_badgeria.back.contracts.contract import VertexContract

        if not vertex.outputs:
            return
        contract = VertexContract(outputs=vertex.outputs)
        contract.validate_output(result)

    # ------------------------------------------------------------------
    # internal - caching
    # ------------------------------------------------------------------

    def _cache_lookup(self, vertex: Vertex, inputs: dict[str, Any]) -> dict[str, Any] | None:
        if self._cache is None:
            return None
        # Side-effect vertices must never be served from cache (Principle 8).
        if not vertex.is_pure:
            return None
        key = self._cache.build_key(vertex, inputs)
        cached = self._cache.load(key)
        if cached is not None:
            self.logger.log(EventType.CACHE_HIT, {"vertex": vertex.name, "key": key})
        else:
            self.logger.log(EventType.CACHE_MISS, {"vertex": vertex.name, "key": key})
        return cached

    def _cache_save(self, vertex: Vertex, inputs: dict[str, Any], result: Any) -> None:
        if self._cache is None:
            return
        if not isinstance(result, dict):
            return
        # Side-effect vertices must never be cached (Principle 8).
        if not vertex.is_pure:
            return
        key = self._cache.build_key(vertex, inputs)
        try:
            self._cache.save(key, result)
            self.logger.log(EventType.CACHE_SAVED, {"vertex": vertex.name, "key": key})
        except Exception as exc:
            # Cache failures are non-fatal but must be visible for debugging.
            self.logger.log(EventType.CACHE_MISS, {
                "vertex": vertex.name,
                "key": key,
                "error": f"cache save failed: {exc}",
            })

    # ------------------------------------------------------------------
    # internal - resolver
    # ------------------------------------------------------------------

    @staticmethod
    def _default_resolver(handler: Any) -> Callable[..., Any]:
        """Default resolver: only accepts callables."""
        if callable(handler):
            return handler
        raise HandlerNotFoundError(f"Cannot resolve handler: {handler!r}. Provide a handler_resolver.")

