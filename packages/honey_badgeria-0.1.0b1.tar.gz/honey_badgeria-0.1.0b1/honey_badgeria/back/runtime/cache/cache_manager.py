"""Cache manager for vertex output caching.

The cache is **disabled by default**.  It is enabled only when
``Settings.CACHE_ENABLED`` is True (or when the executor explicitly
passes ``cache_enabled=True``).
"""

from __future__ import annotations

import shutil
from pathlib import Path
from typing import Any, TYPE_CHECKING

from honey_badgeria.back.runtime.cache.cache_store import FileCacheStore
from honey_badgeria.back.runtime.cache.hash_utils import compute_vertex_hash
from honey_badgeria.conf.defaults import DEFAULT_CACHE_DIR

if TYPE_CHECKING:
    from honey_badgeria.back.graph.vertex import Vertex


class CacheManager:
    """Manages caching of vertex execution results."""

    def __init__(self, cache_dir: str = DEFAULT_CACHE_DIR) -> None:
        self.cache_dir: str = cache_dir
        self.store: FileCacheStore = FileCacheStore(cache_dir)

    def build_key(self, vertex: Vertex, inputs: dict[str, Any]) -> str:
        """Build a cache key for a vertex execution."""
        return compute_vertex_hash(vertex.name, str(vertex.handler), inputs)

    def load(self, key: str) -> dict[str, Any] | None:
        """Load a cached result. Returns *None* on miss."""
        if self.store.exists(key):
            return self.store.load(key)
        return None

    def save(self, key: str, result: dict[str, Any]) -> None:
        """Save a result to cache."""
        self.store.save(key, result)

    # ------------------------------------------------------------------
    # management
    # ------------------------------------------------------------------

    def list_keys(self) -> list[str]:
        """Return a list of all cached keys."""
        cache_path = Path(self.cache_dir)
        if not cache_path.exists():
            return []
        return [p.stem for p in cache_path.glob("*.json")]

    def info(self) -> dict[str, Any]:
        """Return cache statistics as a dict."""
        cache_path = Path(self.cache_dir)
        if not cache_path.exists():
            return {"entries": 0, "size_bytes": 0, "dir": self.cache_dir}
        files = list(cache_path.glob("*.json"))
        total = sum(f.stat().st_size for f in files)
        return {"entries": len(files), "size_bytes": total, "dir": self.cache_dir}

    def prune(self, max_entries: int | None = None) -> int:
        """Remove oldest entries exceeding *max_entries*."""
        cache_path = Path(self.cache_dir)
        if not cache_path.exists():
            return 0
        files = sorted(cache_path.glob("*.json"), key=lambda f: f.stat().st_mtime)
        if max_entries is None or len(files) <= max_entries:
            return 0
        to_remove = files[: len(files) - max_entries]
        for f in to_remove:
            f.unlink()
        return len(to_remove)

    def clear(self) -> bool:
        """Remove all cached data."""
        cache_path = Path(self.cache_dir)
        if cache_path.exists():
            shutil.rmtree(cache_path)
        return True
