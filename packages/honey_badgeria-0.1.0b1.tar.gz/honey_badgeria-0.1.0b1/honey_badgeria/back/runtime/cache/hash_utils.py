"""Hashing utilities for cache keys."""

from __future__ import annotations

import hashlib
import json
from typing import Any


def compute_vertex_hash(
    vertex_id: str,
    handler: str,
    inputs: dict[str, Any],
) -> str:
    """Compute a deterministic hash for a vertex execution."""
    payload = {
        "vertex": vertex_id,
        "handler": str(handler),
        "inputs": inputs,
    }
    raw = json.dumps(payload, sort_keys=True, default=str)
    return hashlib.sha256(raw.encode()).hexdigest()
