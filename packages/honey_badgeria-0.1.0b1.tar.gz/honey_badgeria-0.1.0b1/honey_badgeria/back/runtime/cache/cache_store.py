"""File-based cache store."""

from __future__ import annotations

import json
from pathlib import Path
from typing import Any


class FileCacheStore:
    """Stores cached data as JSON files."""

    def __init__(self, cache_dir: str = ".hbia_cache") -> None:
        self.cache_dir: Path = Path(cache_dir)

    def _ensure_dir(self) -> None:
        self.cache_dir.mkdir(exist_ok=True)

    def _path(self, key: str) -> Path:
        return self.cache_dir / f"{key}.json"

    def exists(self, key: str) -> bool:
        return self._path(key).exists()

    def load(self, key: str) -> dict[str, Any]:
        with open(self._path(key)) as f:
            return json.load(f)

    def save(self, key: str, value: dict[str, Any]) -> None:
        self._ensure_dir()
        with open(self._path(key), "w") as f:
            json.dump(value, f)
