"""Stage builder for execution planning."""

from __future__ import annotations

from collections import defaultdict, deque
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from honey_badgeria.back.graph.graph import Graph
    from honey_badgeria.back.graph.vertex import Vertex


class ExecutionStage:
    """A group of vertices that can be executed in parallel."""

    def __init__(self, level: int, vertices: list[Vertex]) -> None:
        self.level: int = level
        self.vertices: list[Vertex] = vertices

    def __repr__(self) -> str:
        names = [v.name for v in self.vertices]
        return f"<Stage {self.level}: {names}>"


class StageBuilder:
    """Builds execution stages from a graph."""

    @staticmethod
    def build(graph: Graph) -> list[ExecutionStage]:
        """Build execution stages from a graph."""
        in_degree: dict[str, int] = {name: 0 for name in graph.vertices}
        adjacency: dict[str, list[str]] = defaultdict(list)

        for e in graph.edges:
            adjacency[e.source].append(e.target)
            if e.target in in_degree:
                in_degree[e.target] += 1

        queue: deque[str] = deque(n for n in in_degree if in_degree[n] == 0)
        level_map: dict[str, int] = {n: 0 for n in queue}
        stages: dict[int, list[Vertex]] = defaultdict(list)

        while queue:
            name = queue.popleft()
            level = level_map[name]
            stages[level].append(graph.vertices[name])

            for neighbor in adjacency.get(name, []):
                in_degree[neighbor] -= 1
                if in_degree[neighbor] == 0:
                    level_map[neighbor] = level + 1
                    queue.append(neighbor)

        return [
            ExecutionStage(level, stages[level])
            for level in sorted(stages.keys())
        ]
