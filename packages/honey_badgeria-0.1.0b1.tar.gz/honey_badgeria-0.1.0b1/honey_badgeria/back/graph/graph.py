"""Graph: the core DAG structure."""

from __future__ import annotations

from typing import TYPE_CHECKING

from .vertex import Vertex
from .edge import Edge
from .exceptions import VertexAlreadyExistsError, VertexNotFoundError
from honey_badgeria.core.exceptions import FlowNotFoundError
from honey_badgeria.conf.defaults import SCHEMA_VERSION

if TYPE_CHECKING:
    from honey_badgeria.back.atomicity.group import AtomicGroup


class Graph:
    """Directed Acyclic Graph used by Honey Badgeria runtime.

    Vertices are stored in a dict keyed by name.
    Edges are stored as a list of :class:`Edge` objects.
    Flows define named entry points into the graph.

    ``schema_version`` tracks the DSL version so that cache entries,
    YAML files, and serialised graphs can be validated against the
    framework version that produced them (Principle 3).
    """

    def __init__(self) -> None:
        self.vertices: dict[str, Vertex] = {}
        self.edges: list[Edge] = []
        self.flows: dict[str, dict[str, str]] = {}
        self.atomic_groups: dict[str, AtomicGroup] = {}
        self.schema_version: str = SCHEMA_VERSION

    def add_vertex(self, vertex: Vertex) -> None:
        """Add a vertex to the graph.

        Raises:
            VertexAlreadyExistsError: If the name is already taken.
        """
        if vertex.name in self.vertices:
            raise VertexAlreadyExistsError(f"Vertex already exists: {vertex.name}")
        self.vertices[vertex.name] = vertex

    def get_vertex(self, name: str) -> Vertex:
        """Get a vertex by name.

        Raises:
            VertexNotFoundError: If the name is not in the graph.
        """
        if name not in self.vertices:
            raise VertexNotFoundError(f"Vertex not found: {name}")
        return self.vertices[name]

    def has_vertex(self, name: str) -> bool:
        """Check if a vertex exists."""
        return name in self.vertices

    def add_edge(self, edge: Edge) -> None:
        """Add a directed edge to the graph."""
        self.edges.append(edge)

    def get_sources(self) -> list[Vertex]:
        """Return vertices with no incoming edges."""
        targets: set[str] = {e.target for e in self.edges}
        return [v for v in self.vertices.values() if v.name not in targets]

    def get_sinks(self) -> list[Vertex]:
        """Return vertices with no outgoing edges."""
        sources: set[str] = {e.source for e in self.edges}
        return [v for v in self.vertices.values() if v.name not in sources]

    def entry_vertex(self, flow_name: str) -> Vertex:
        """Get the entry vertex for a named flow.

        Raises:
            FlowNotFoundError: If the flow name is not in the graph.
        """
        if flow_name not in self.flows:
            raise FlowNotFoundError(f"Flow not found: {flow_name}")
        entry: str = self.flows[flow_name]["entry"]
        return self.get_vertex(entry)

    def adjacency_list(self) -> dict[str, list[str]]:
        """Return adjacency list ``{vertex_name: [target_names]}``."""
        adj: dict[str, list[str]] = {name: [] for name in self.vertices}
        for e in self.edges:
            if e.source in adj:
                adj[e.source].append(e.target)
        return adj

    def reverse_adjacency_list(self) -> dict[str, list[str]]:
        """Return reverse adjacency list ``{vertex_name: [source_names]}``."""
        rev: dict[str, list[str]] = {name: [] for name in self.vertices}
        for e in self.edges:
            if e.target in rev:
                rev[e.target].append(e.source)
        return rev

    def __repr__(self) -> str:
        return f"<Graph vertices={len(self.vertices)} edges={len(self.edges)}>"

    # ------------------------------------------------------------------
    # Atomic-group helpers
    # ------------------------------------------------------------------

    def atomic_group_for_vertex(self, vertex_name: str) -> AtomicGroup | None:
        """Return the atomic group that contains *vertex_name*, or ``None``."""
        for group in self.atomic_groups.values():
            if group.contains(vertex_name):
                return group
        return None

    def vertices_in_atomic_groups(self) -> frozenset[str]:
        """All vertex names that belong to at least one atomic group."""
        names: set[str] = set()
        for group in self.atomic_groups.values():
            names.update(group.vertices)
        return frozenset(names)
