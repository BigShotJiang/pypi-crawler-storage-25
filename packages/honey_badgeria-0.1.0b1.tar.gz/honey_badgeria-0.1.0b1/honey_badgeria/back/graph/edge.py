"""Edge: a directed connection between two vertices."""

from __future__ import annotations


class Edge:
    """A directed edge connecting two vertices in the graph.

    Attributes:
        source: Name of the source vertex.
        target: Name of the target vertex.
    """

    __slots__ = ("source", "target")

    def __init__(self, source: str, target: str) -> None:
        self.source: str = source
        self.target: str = target

    def __repr__(self) -> str:
        return f"Edge({self.source} -> {self.target})"

    def __eq__(self, other: object) -> bool:
        if isinstance(other, Edge):
            return self.source == other.source and self.target == other.target
        return NotImplemented

    def __hash__(self) -> int:
        return hash((self.source, self.target))
