"""Vertex: a node in the execution graph."""

from __future__ import annotations

from typing import Any, Callable, Union

#: A handler is either a callable or a dotted-path string.
HandlerType = Union[Callable[..., dict[str, Any]], str, None]

#: Side-effect markers for idempotency enforcement (Principle 8).
PURE = "pure"
"""The handler has no side effects — safe to cache, retry, parallelise."""

SIDE_EFFECT = "side_effect"
"""The handler has explicit side effects — must not be cached."""


class Vertex:
    """A vertex represents a single operation in the execution graph.

    Attributes:
        name: Unique identifier for this vertex.
        handler: Callable or dotted-path string to the handler function.
        inputs: Input bindings ``{param_name: "source_vertex.output_key"}``.
        outputs: Output type declarations ``{output_name: "type_name"}``.
        version: Version tag for this vertex (e.g. ``"v2"``).
            Used for module-versioning (Principle 3: rewrite over patch).
        effect: ``"pure"`` or ``"side_effect"``.  Pure vertices can be
            cached and retried safely.
    """

    __slots__ = ("name", "handler", "inputs", "outputs", "version", "effect")

    def __init__(
        self,
        name: str,
        handler: HandlerType = None,
        inputs: dict[str, str] | None = None,
        outputs: dict[str, str] | None = None,
        version: str | None = None,
        effect: str = PURE,
    ) -> None:
        self.name: str = name
        self.handler: HandlerType = handler
        self.inputs: dict[str, str] = inputs or {}
        self.outputs: dict[str, str] = outputs or {}
        self.version: str | None = version
        self.effect: str = effect

    @property
    def is_pure(self) -> bool:
        """Return True if the vertex is declared pure (no side effects)."""
        return self.effect == PURE

    @property
    def id(self) -> str:
        """Alias for *name*, used by topology and algorithm modules."""
        return self.name

    def __repr__(self) -> str:
        return f"<Vertex {self.name}>"

    def __eq__(self, other: object) -> bool:
        if isinstance(other, Vertex):
            return self.name == other.name
        return NotImplemented

    def __hash__(self) -> int:
        return hash(self.name)
