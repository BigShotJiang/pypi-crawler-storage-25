"""Graph-specific exceptions.

All exceptions re-exported from the central hierarchy in
:mod:`honey_badgeria.core.exceptions` so that every HBIA error
is a subclass of :class:`HoneyBadgeriaError`.
"""

from honey_badgeria.core.exceptions import (  # noqa: F401 - re-exports
    GraphError,
    VertexAlreadyExistsError,
    VertexNotFoundError,
    EdgeInvalidError,
    GraphCycleError,
)
