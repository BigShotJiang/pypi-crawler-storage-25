"""Graph algorithms for DAG operations."""

from __future__ import annotations

from collections import deque
from typing import TYPE_CHECKING

from .exceptions import GraphCycleError

if TYPE_CHECKING:
    from honey_badgeria.back.graph.graph import Graph
    from honey_badgeria.back.graph.vertex import Vertex


def topological_sort(graph: Graph) -> list[Vertex]:
    """Return vertices in topological order using Kahn's algorithm.

    Raises:
        GraphCycleError: If the graph contains a cycle.
    """
    in_degree: dict[str, int] = {name: 0 for name in graph.vertices}

    for e in graph.edges:
        if e.target in in_degree:
            in_degree[e.target] += 1

    queue: deque[str] = deque(name for name, deg in in_degree.items() if deg == 0)
    order: list[Vertex] = []

    adjacency = graph.adjacency_list()

    while queue:
        node = queue.popleft()
        order.append(graph.vertices[node])

        for neighbor in adjacency.get(node, []):
            in_degree[neighbor] -= 1
            if in_degree[neighbor] == 0:
                queue.append(neighbor)

    if len(order) != len(graph.vertices):
        raise GraphCycleError("Graph contains a cycle")

    return order


def compute_execution_stages(graph: Graph) -> list[list[Vertex]]:
    """Compute execution stages (parallel groups) using BFS levels."""
    in_degree: dict[str, int] = {name: 0 for name in graph.vertices}

    for e in graph.edges:
        if e.target in in_degree:
            in_degree[e.target] += 1

    queue: deque[str] = deque(name for name, deg in in_degree.items() if deg == 0)
    stages: list[list[Vertex]] = []

    adjacency = graph.adjacency_list()

    while queue:
        stage_names = list(queue)
        queue = deque()

        stage_vertices = [graph.vertices[n] for n in stage_names]
        stages.append(stage_vertices)

        for name in stage_names:
            for neighbor in adjacency.get(name, []):
                in_degree[neighbor] -= 1
                if in_degree[neighbor] == 0:
                    queue.append(neighbor)

    return stages
