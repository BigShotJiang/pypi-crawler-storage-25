"""Graph structure validator."""

from __future__ import annotations

from collections import defaultdict, deque
from typing import TYPE_CHECKING

from honey_badgeria.core.exceptions import GraphValidationError

if TYPE_CHECKING:
    from honey_badgeria.back.graph.graph import Graph


class GraphValidator:
    """Validates structural integrity of a DAG."""

    def __init__(self, graph: Graph) -> None:
        self.graph: Graph = graph

    def validate(self) -> None:
        """Run all validations.

        Raises:
            GraphValidationError: On structural errors.
        """
        errors: list[str] = []
        errors.extend(self._validate_edges())
        errors.extend(self._validate_dag())
        errors.extend(self._validate_sources())
        errors.extend(self._validate_atomic_groups())
        if errors:
            raise GraphValidationError("\n".join(errors))

    def _validate_edges(self) -> list[str]:
        errors: list[str] = []
        for e in self.graph.edges:
            if e.source not in self.graph.vertices:
                errors.append(f"Edge references unknown source: {e.source}")
            if e.target not in self.graph.vertices:
                errors.append(f"Edge references unknown target: {e.target}")
        return errors

    def _validate_dag(self) -> list[str]:
        """Detect cycles using Kahn's algorithm."""
        in_degree: dict[str, int] = defaultdict(int)
        adjacency: dict[str, list[str]] = defaultdict(list)

        for name in self.graph.vertices:
            in_degree[name] = 0

        for e in self.graph.edges:
            adjacency[e.source].append(e.target)
            in_degree[e.target] += 1

        queue = deque(n for n in in_degree if in_degree[n] == 0)
        visited = 0

        while queue:
            node = queue.popleft()
            visited += 1
            for neighbor in adjacency[node]:
                in_degree[neighbor] -= 1
                if in_degree[neighbor] == 0:
                    queue.append(neighbor)

        if visited != len(self.graph.vertices):
            return ["Graph contains cycles — not a valid DAG"]
        return []

    def _validate_sources(self) -> list[str]:
        sources = self.graph.get_sources()
        if not sources:
            return ["Graph has no source vertices"]
        return []

    def _validate_atomic_groups(self) -> list[str]:
        """Validate atomic-group constraints on the built Graph.

        Checks:
        1. Every vertex referenced in a group actually exists.
        2. No vertex belongs to more than one group.
        3. Vertices in an atomic group form a connected sub-path
           (they must be reachable from the first vertex via edges
           within the group — prevents scattered atomicity).
        """
        errors: list[str] = []
        assigned: dict[str, str] = {}

        for group in self.graph.atomic_groups.values():
            for vname in group.vertices:
                if vname not in self.graph.vertices:
                    errors.append(
                        f"Atomic group '{group.name}' references "
                        f"unknown vertex: {vname}"
                    )
                if vname in assigned:
                    errors.append(
                        f"Vertex '{vname}' belongs to both "
                        f"'{assigned[vname]}' and '{group.name}'"
                    )
                assigned[vname] = group.name

            # Connectivity check — vertices must form a connected
            # subgraph (via the graph's edges restricted to the group).
            vset = set(group.vertices)
            if vset and not vset - set(self.graph.vertices.keys()):
                adj: dict[str, set[str]] = {v: set() for v in vset}
                for e in self.graph.edges:
                    if e.source in vset and e.target in vset:
                        adj[e.source].add(e.target)
                        adj[e.target].add(e.source)  # undirected for connectivity

                visited: set[str] = set()
                stack = [group.vertices[0]]
                while stack:
                    node = stack.pop()
                    if node in visited:
                        continue
                    visited.add(node)
                    stack.extend(adj[node] - visited)

                if visited != vset:
                    errors.append(
                        f"Atomic group '{group.name}' vertices are not "
                        f"connected in the graph — this would break "
                        f"atomicity guarantees"
                    )

        return errors
