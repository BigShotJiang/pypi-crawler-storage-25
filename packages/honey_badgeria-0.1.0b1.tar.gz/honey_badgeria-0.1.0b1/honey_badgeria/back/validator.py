"""Core graph validator (delegates to graph.validator)."""

from honey_badgeria.back.graph.validator import GraphValidator

__all__ = ["GraphValidator"]
