"""Write graph definitions to YAML files."""

from __future__ import annotations

from typing import Any


class FlowGraphWriter:
    """Writes a graph dict to a YAML file. Requires pyyaml."""

    def save(self, graph: dict[str, Any], path: str) -> None:
        """Write a graph definition to a YAML file.

        Args:
            graph: Graph dict in flow format.
            path: Output file path.
        """
        try:
            import yaml
        except ImportError:
            raise ImportError(
                "pyyaml is required for YAML writing. "
                "Install with: pip install honey-badgeria[yaml]"
            )

        with open(path, "w") as f:
            yaml.dump(graph, f, sort_keys=False, default_flow_style=False)
