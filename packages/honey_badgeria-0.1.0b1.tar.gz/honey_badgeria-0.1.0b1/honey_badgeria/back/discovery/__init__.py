"""Auto-discovery of vertices and flows."""
