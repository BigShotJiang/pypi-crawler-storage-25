"""Auto-discover vertices from Python modules."""

from __future__ import annotations

from typing import Any

from honey_badgeria.back.discovery.scanner import VertexScanner
from honey_badgeria.back.discovery.inspector import VertexInspector
from honey_badgeria.back.discovery.generator import GraphGenerator


class GraphAutoDiscover:
    """Auto-discovers vertices and generates a graph definition."""

    def __init__(self, handler_modules: list[str] | None = None) -> None:
        self.handler_modules: list[str] = handler_modules or []

    def run(self) -> dict[str, Any]:
        """Run auto-discovery and return a graph dict."""
        scanner = VertexScanner(self.handler_modules)
        inspector = VertexInspector()
        generator = GraphGenerator()

        modules = scanner.scan()
        vertices: list[dict[str, Any]] = []

        for m in modules:
            discovered = inspector.inspect_module(m)
            vertices.extend(discovered)

        return generator.generate(vertices)
