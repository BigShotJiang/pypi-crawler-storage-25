"""Generate graph definitions from discovered vertices."""

from __future__ import annotations

from typing import Any


class GraphGenerator:
    """Generates a graph dict from a list of vertex definitions."""

    def generate(self, vertices: list[dict[str, Any]]) -> dict[str, Any]:
        """Generate a flow-format graph dict from vertex dicts."""
        flow_def: dict[str, Any] = {}
        for v in vertices:
            if not isinstance(v, dict) or "name" not in v:
                continue
            vname = v["name"]
            vconfig: dict[str, Any] = {}
            if v.get("handler"):
                vconfig["handler"] = v["handler"]
            vconfig["effect"] = v.get("effect", "pure")
            vconfig["version"] = v.get("version", "1")
            if v.get("inputs"):
                vconfig["inputs"] = v["inputs"]
            if v.get("outputs"):
                vconfig["outputs"] = v["outputs"]
            flow_def[vname] = vconfig

        return {"flow": {"main": flow_def}}

    def save(self, graph: dict[str, Any], path: str) -> None:
        """Save a graph dict to a YAML file. Requires pyyaml."""
        try:
            import yaml
        except ImportError:
            raise ImportError(
                "pyyaml is required for YAML writing. "
                "Install with: pip install honey-badgeria[yaml]"
            )
        with open(path, "w") as f:
            yaml.dump(graph, f, sort_keys=False)
