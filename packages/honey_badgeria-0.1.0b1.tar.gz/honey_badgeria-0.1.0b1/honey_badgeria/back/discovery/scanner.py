"""Scan Python modules for vertex handlers."""

from __future__ import annotations

import importlib
import pkgutil
from types import ModuleType


class VertexScanner:
    """Scans Python modules for vertex handlers."""

    def __init__(self, modules: list[str] | None = None) -> None:
        self.modules: list[str] = modules or []

    def scan(self) -> list[ModuleType]:
        """Scan all configured modules and return imported modules."""
        result: list[ModuleType] = []

        for module_name in self.modules:
            module = importlib.import_module(module_name)

            if hasattr(module, "__path__"):
                for _loader, name, _ispkg in pkgutil.walk_packages(module.__path__):
                    full = f"{module_name}.{name}"
                    mod = importlib.import_module(full)
                    result.append(mod)
            else:
                result.append(module)

        return result
