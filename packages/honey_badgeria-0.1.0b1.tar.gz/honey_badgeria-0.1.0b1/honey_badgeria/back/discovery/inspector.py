"""Inspect Python modules for vertex definitions."""

from __future__ import annotations

import inspect
from types import ModuleType
from typing import Any, Callable


class VertexInspector:
    """Inspects Python modules to extract vertex definitions."""

    def inspect_module(self, module: ModuleType) -> list[dict[str, Any]]:
        """Extract vertex definitions from a module."""
        discovered: list[dict[str, Any]] = []

        for _name, obj in inspect.getmembers(module):
            if inspect.isfunction(obj):
                vertex = self.inspect_function(obj)
                discovered.append(vertex)

        return discovered

    def inspect_function(self, fn: Callable[..., Any]) -> dict[str, Any]:
        """Extract a vertex definition from a function."""
        sig = inspect.signature(fn)
        inputs: dict[str, str] = {}

        for name, param in sig.parameters.items():
            if param.annotation != inspect.Parameter.empty:
                inputs[name] = param.annotation.__name__
            else:
                inputs[name] = "any"

        outputs: dict[str, str] = {}
        if sig.return_annotation != inspect.Signature.empty:
            if sig.return_annotation == dict:
                outputs["result"] = "dict"

        return {
            "name": fn.__name__,
            "handler": fn.__name__,
            "inputs": inputs,
            "outputs": outputs,
        }
