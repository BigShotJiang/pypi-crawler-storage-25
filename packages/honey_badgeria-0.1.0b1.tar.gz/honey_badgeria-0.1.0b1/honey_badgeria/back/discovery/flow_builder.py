"""Build graph definitions from decorated functions."""

from __future__ import annotations

import inspect
from typing import Any, Callable

from honey_badgeria.decorators.vertex import VERTEX_REGISTRY
from honey_badgeria.decorators.flow import FLOW_REGISTRY


class FlowGraphBuilder:
    """Builds a flow-format graph dict from decorated vertex and flow functions."""

    def build(self) -> dict[str, Any]:
        result: dict[str, Any] = {"flow": {}}

        # Build vertex configs
        vertex_configs: dict[str, dict[str, Any]] = {}
        for name, fn in VERTEX_REGISTRY.items():
            vertex_configs[name] = self._build_vertex(fn)

        # Build flows
        for flow_name, fn in FLOW_REGISTRY.items():
            edges = self._build_edges(fn)
            # Add next fields based on edges
            flow_def: dict[str, Any] = {}
            for vname, vconfig in vertex_configs.items():
                cfg = dict(vconfig)
                next_list = [tgt for src, tgt in edges if src == vname]
                if next_list:
                    cfg["next"] = next_list
                flow_def[vname] = cfg
            result["flow"][flow_name] = flow_def

        # If no flows registered, put all vertices in a "main" flow
        if not FLOW_REGISTRY:
            result["flow"]["main"] = dict(vertex_configs)

        return result

    def _build_vertex(self, fn: Callable[..., Any]) -> dict[str, Any]:
        sig = inspect.signature(fn)
        inputs: dict[str, str] = {}

        for name, param in sig.parameters.items():
            if param.annotation != inspect.Parameter.empty:
                inputs[name] = param.annotation.__name__
            else:
                inputs[name] = "any"

        outputs: dict[str, str] = {}
        if sig.return_annotation != inspect.Signature.empty:
            outputs["result"] = sig.return_annotation.__name__

        config: dict[str, Any] = {
            "handler": fn.__name__,
            "effect": "pure",
            "version": "1",
        }
        if inputs:
            config["inputs"] = inputs
        if outputs:
            config["outputs"] = outputs
        return config

    def _build_edges(self, flow_fn: Callable[..., Any]) -> list[tuple[str, str]]:
        source = inspect.getsource(flow_fn)
        edges: list[tuple[str, str]] = []
        calls: list[str] = []

        for line in source.splitlines():
            if "(" in line and ")" in line:
                name = line.strip().split("(")[0]
                if name in VERTEX_REGISTRY:
                    calls.append(name)

        for i in range(len(calls) - 1):
            edges.append((calls[i], calls[i + 1]))

        return edges
