"""Module health checker — automatic tech-debt detection (Principle 7).

Detects:
    - Modules exceeding the recommended line count.
    - Circular dependencies in import graphs.
    - Vertices without contracts (low contract coverage).
    - Duplicate handler names across modules.

Usage::

    from honey_badgeria.back.discovery.health_checker import ModuleHealthChecker

    checker = ModuleHealthChecker(root="vertices")
    report = checker.run()
    for issue in report:
        print(f"[{issue['severity']}] {issue['code']}: {issue['message']}")
"""

from __future__ import annotations

import ast
import os
from pathlib import Path
from typing import Any

from honey_badgeria.conf.defaults import MODULE_MAX_LINES, MODULE_MAX_VERTICES


class ModuleHealthChecker:
    """Scans a project for common tech-debt patterns.

    Each issue is a dict with keys:
        - ``code``: Machine-readable identifier (e.g. ``MODULE_TOO_LARGE``).
        - ``severity``: ``"warning"`` or ``"error"``.
        - ``file``: Path to the offending file (when applicable).
        - ``message``: Human-readable explanation.
    """

    def __init__(
        self,
        root: str = ".",
        max_lines: int = MODULE_MAX_LINES,
        max_vertices: int = MODULE_MAX_VERTICES,
    ) -> None:
        self.root: str = root
        self.max_lines: int = max_lines
        self.max_vertices: int = max_vertices

    def run(self) -> list[dict[str, Any]]:
        """Run all health checks and return a list of issues."""
        issues: list[dict[str, Any]] = []
        issues.extend(self.check_module_sizes())
        issues.extend(self.check_circular_imports())
        issues.extend(self.check_duplicate_handlers())
        return issues

    # ------------------------------------------------------------------
    # Check 1: module size
    # ------------------------------------------------------------------

    def check_module_sizes(self) -> list[dict[str, Any]]:
        """Flag Python files exceeding ``max_lines``."""
        issues: list[dict[str, Any]] = []
        for py_file in self._python_files():
            try:
                lines = py_file.read_text(encoding="utf-8").count("\n") + 1
            except OSError:
                continue
            if lines > self.max_lines:
                issues.append({
                    "code": "MODULE_TOO_LARGE",
                    "severity": "warning",
                    "file": str(py_file),
                    "message": (
                        f"{py_file.name} has {lines} lines "
                        f"(limit: {self.max_lines}). "
                        f"Consider splitting into smaller modules."
                    ),
                })
        return issues

    # ------------------------------------------------------------------
    # Check 2: circular imports (AST-based)
    # ------------------------------------------------------------------

    def check_circular_imports(self) -> list[dict[str, Any]]:
        """Detect circular import chains via AST analysis.

        Builds a module-level import graph and reports cycles.
        """
        issues: list[dict[str, Any]] = []
        import_graph: dict[str, set[str]] = {}

        for py_file in self._python_files():
            module_name = self._path_to_module(py_file)
            if module_name is None:
                continue
            try:
                tree = ast.parse(py_file.read_text(encoding="utf-8"), filename=str(py_file))
            except SyntaxError:
                continue
            deps: set[str] = set()
            for node in ast.walk(tree):
                if isinstance(node, ast.Import):
                    for alias in node.names:
                        deps.add(alias.name.split(".")[0])
                elif isinstance(node, ast.ImportFrom):
                    if node.module:
                        deps.add(node.module.split(".")[0])
            import_graph[module_name] = deps

        # Detect cycles via DFS
        cycles = self._find_cycles(import_graph)
        for cycle in cycles:
            chain = " → ".join(cycle)
            issues.append({
                "code": "CIRCULAR_DEPENDENCY",
                "severity": "error",
                "file": "",
                "message": f"Circular import chain: {chain}",
            })
        return issues

    # ------------------------------------------------------------------
    # Check 3: duplicate handler names
    # ------------------------------------------------------------------

    def check_duplicate_handlers(self) -> list[dict[str, Any]]:
        """Detect duplicate ``@vertex`` handler names across files."""
        issues: list[dict[str, Any]] = []
        seen: dict[str, str] = {}  # handler_name → file

        for py_file in self._python_files():
            try:
                source = py_file.read_text(encoding="utf-8")
                tree = ast.parse(source, filename=str(py_file))
            except (OSError, SyntaxError):
                continue

            for node in ast.walk(tree):
                if isinstance(node, ast.FunctionDef):
                    for dec in node.decorator_list:
                        if self._is_vertex_decorator(dec):
                            name = node.name
                            if name in seen and seen[name] != str(py_file):
                                issues.append({
                                    "code": "DUPLICATE_HANDLER",
                                    "severity": "warning",
                                    "file": str(py_file),
                                    "message": (
                                        f"Handler '{name}' also defined in "
                                        f"{seen[name]}. Consider versioned "
                                        f"names (e.g. {name}_v2)."
                                    ),
                                })
                            seen[name] = str(py_file)
        return issues

    # ------------------------------------------------------------------
    # internal helpers
    # ------------------------------------------------------------------

    def _python_files(self) -> list[Path]:
        """Yield all .py files under ``self.root``."""
        root = Path(self.root)
        if not root.exists():
            return []
        return sorted(root.rglob("*.py"))

    @staticmethod
    def _path_to_module(path: Path) -> str | None:
        """Best-effort conversion of a file path to a module name."""
        parts = path.with_suffix("").parts
        if not parts:
            return None
        return ".".join(parts)

    @staticmethod
    def _find_cycles(graph: dict[str, set[str]]) -> list[list[str]]:
        """Return all unique cycles in a directed graph."""
        cycles: list[list[str]] = []
        visited: set[str] = set()
        rec_stack: set[str] = set()
        path: list[str] = []

        def dfs(node: str) -> None:
            visited.add(node)
            rec_stack.add(node)
            path.append(node)

            for neighbor in graph.get(node, set()):
                if neighbor not in graph:
                    continue
                if neighbor not in visited:
                    dfs(neighbor)
                elif neighbor in rec_stack:
                    idx = path.index(neighbor)
                    cycle = path[idx:] + [neighbor]
                    cycles.append(cycle)

            path.pop()
            rec_stack.discard(node)

        for node in graph:
            if node not in visited:
                dfs(node)

        return cycles

    @staticmethod
    def _is_vertex_decorator(node: ast.expr) -> bool:
        """Check if an AST node looks like ``@vertex``."""
        if isinstance(node, ast.Name) and node.id == "vertex":
            return True
        if isinstance(node, ast.Call):
            func = node.func
            if isinstance(func, ast.Name) and func.id == "vertex":
                return True
            if isinstance(func, ast.Attribute) and func.attr == "vertex":
                return True
        return False
