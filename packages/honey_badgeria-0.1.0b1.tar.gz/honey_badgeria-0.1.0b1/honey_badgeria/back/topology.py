"""Graph topology computation engine."""

from __future__ import annotations

from collections import defaultdict, deque
from typing import TYPE_CHECKING

from honey_badgeria.core.exceptions import GraphCycleError

if TYPE_CHECKING:
    from honey_badgeria.back.graph.graph import Graph
    from honey_badgeria.back.graph.vertex import Vertex


class GraphTopology:
    """Computes structural properties of a DAG."""

    def __init__(self, graph: Graph) -> None:
        self.graph: Graph = graph
        self._adjacency: dict[str, list[str]] = defaultdict(list)
        self._reverse: dict[str, list[str]] = defaultdict(list)
        self._in_degree: dict[str, int] = {}
        self._build()

    def _build(self) -> None:
        for name in self.graph.vertices:
            self._in_degree[name] = 0

        for e in self.graph.edges:
            self._adjacency[e.source].append(e.target)
            self._reverse[e.target].append(e.source)
            if e.target in self._in_degree:
                self._in_degree[e.target] += 1

    def sources(self) -> list[str]:
        """Vertex names with no incoming edges."""
        return [name for name, deg in self._in_degree.items() if deg == 0]

    def sinks(self) -> list[str]:
        """Vertex names with no outgoing edges."""
        return [
            name for name in self.graph.vertices
            if not self._adjacency.get(name)
        ]

    def topological_sort(self) -> list[str]:
        """Kahn's algorithm.  Returns vertex names in topological order.

        Raises:
            GraphCycleError: If cycles are detected.
        """
        in_deg = dict(self._in_degree)
        queue: deque[str] = deque(n for n in in_deg if in_deg[n] == 0)
        order: list[str] = []

        while queue:
            node = queue.popleft()
            order.append(node)
            for neighbor in self._adjacency.get(node, []):
                in_deg[neighbor] -= 1
                if in_deg[neighbor] == 0:
                    queue.append(neighbor)

        if len(order) != len(self.graph.vertices):
            raise GraphCycleError("Graph contains a cycle")

        return order

    def execution_stages(self) -> list[list[Vertex]]:
        """Return execution stages (lists of :class:`Vertex` objects)."""
        in_deg = dict(self._in_degree)
        queue: deque[str] = deque(n for n in in_deg if in_deg[n] == 0)
        stages: list[list[Vertex]] = []

        while queue:
            stage_names = list(queue)
            queue = deque()
            stage_vertices = [self.graph.vertices[n] for n in stage_names]
            stages.append(stage_vertices)

            for name in stage_names:
                for neighbor in self._adjacency.get(name, []):
                    in_deg[neighbor] -= 1
                    if in_deg[neighbor] == 0:
                        queue.append(neighbor)

        return stages

    def dependencies(self, vertex_name: str) -> list[str]:
        """Return upstream vertex names."""
        return list(self._reverse.get(vertex_name, []))

    def dependents(self, vertex_name: str) -> list[str]:
        """Return downstream vertex names."""
        return list(self._adjacency.get(vertex_name, []))
