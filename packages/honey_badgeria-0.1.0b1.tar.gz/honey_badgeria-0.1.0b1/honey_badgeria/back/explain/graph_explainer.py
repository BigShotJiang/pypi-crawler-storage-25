"""Graph explainer: produces human-readable graph descriptions."""

from __future__ import annotations

from typing import Any, TYPE_CHECKING

from honey_badgeria.back.topology import GraphTopology

if TYPE_CHECKING:
    from honey_badgeria.back.graph.graph import Graph


class GraphExplainer:
    """Produces a human and AI-readable explanation of a graph."""

    def __init__(self, graph: Graph) -> None:
        self.graph: Graph = graph
        self.topology: GraphTopology = GraphTopology(graph)

    def explain(self) -> None:
        """Print a full explanation of the graph."""
        lines = self.explain_lines()
        print("\n".join(lines))

    def explain_lines(self) -> list[str]:
        """Return explanation as list of strings."""
        lines: list[str] = []
        lines.append("=== Graph Explanation ===")
        lines.append(f"Vertices: {len(self.graph.vertices)}")
        lines.append(f"Edges: {len(self.graph.edges)}")
        lines.append("")

        sources = self.topology.sources()
        sinks = self.topology.sinks()
        lines.append(f"Sources (entry points): {sources}")
        lines.append(f"Sinks (exit points): {sinks}")
        lines.append("")

        stages = self.topology.execution_stages()
        lines.append("Execution Stages:")
        for i, stage in enumerate(stages):
            names = [v.name for v in stage]
            lines.append(f"  Stage {i}: {names}")

        lines.append("")
        lines.append("Edges:")
        for e in self.graph.edges:
            lines.append(f"  {e.source} -> {e.target}")

        return lines

    def to_dict(self) -> dict[str, Any]:
        """Return explanation as a dict (AI-friendly format)."""
        stages = self.topology.execution_stages()
        return {
            "vertex_count": len(self.graph.vertices),
            "edge_count": len(self.graph.edges),
            "sources": self.topology.sources(),
            "sinks": self.topology.sinks(),
            "stages": [
                [v.name for v in stage]
                for stage in stages
            ],
            "edges": [
                {"from": e.source, "to": e.target}
                for e in self.graph.edges
            ],
        }
