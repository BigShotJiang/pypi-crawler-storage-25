"""AI-oriented linter for Honey Badgeria graph definitions.

Checks that YAML graph definitions follow best practices that make them
easy for AI agents to read, generate, and maintain.

Issue codes
-----------
E001  vertex referenced in ``next`` not defined in flow
E002  flow has zero edges (vertices are disconnected)
W001  vertex missing ``effect`` field
W002  vertex missing ``version`` field
W003  vertex missing ``handler`` field
W005  vertex missing ``outputs`` declaration
W006  vertex name not in snake_case
W007  single-vertex flow (likely an incomplete pipeline)
"""

from __future__ import annotations

import re
from dataclasses import dataclass
from typing import Any


# ------------------------------------------------------------------
# Data model
# ------------------------------------------------------------------

@dataclass
class LintIssue:
    """A single linter diagnostic."""

    code: str
    severity: str          # "error", "warning", "info"
    message: str
    vertex: str | None = None
    flow: str | None = None
    suggestion: str | None = None

    def __str__(self) -> str:
        icon = {"error": "\u2718", "warning": "\u26a0", "info": "\u2139"}.get(self.severity, "?")
        loc = ""
        if self.flow:
            loc += f" flow={self.flow}"
        if self.vertex:
            loc += f" vertex={self.vertex}"
        line = f"{icon} [{self.code}]{loc}: {self.message}"
        if self.suggestion:
            line += f"  \u2192 {self.suggestion}"
        return line


_SNAKE_RE = re.compile(r"^[a-z][a-z0-9]*(_[a-z0-9]+)*$")


# ------------------------------------------------------------------
# Linter
# ------------------------------------------------------------------

class AILinter:
    """Validate a graph definition dict for AI best-practice compliance.

    Usage::

        linter = AILinter()
        issues = linter.lint(yaml_dict)
        errors = [i for i in issues if i.severity == "error"]
    """

    def lint(self, data: Any) -> list[LintIssue]:
        """Run all lint checks on a graph definition dict.

        Returns a list of :class:`LintIssue` objects, sorted by severity
        (errors first, then warnings, then info).
        """
        if not isinstance(data, dict):
            return [LintIssue("E000", "error", "Graph definition must be a dict")]

        issues: list[LintIssue] = []

        if "flow" in data:
            issues.extend(self._lint_flow_format(data))
        else:
            issues.append(LintIssue(
                "E000", "error",
                "Missing 'flow' top-level key.",
            ))

        # Sort: errors -> warnings -> info
        severity_order = {"error": 0, "warning": 1, "info": 2}
        issues.sort(key=lambda i: severity_order.get(i.severity, 3))
        return issues

    # ------------------------------------------------------------------
    # Flow format checks
    # ------------------------------------------------------------------

    def _lint_flow_format(self, data: dict[str, Any]) -> list[LintIssue]:
        issues: list[LintIssue] = []
        flows = data.get("flow", {})

        if not isinstance(flows, dict):
            issues.append(LintIssue("E000", "error", "'flow' must be a dict"))
            return issues

        for flow_name, flow_def in flows.items():
            if not isinstance(flow_def, dict):
                issues.append(LintIssue(
                    "E000", "error",
                    f"Flow definition must be a dict",
                    flow=flow_name,
                ))
                continue

            if not flow_def:
                issues.append(LintIssue(
                    "E002", "error",
                    "Flow has no vertices defined.",
                    flow=flow_name,
                ))
                continue

            has_edges = False
            vertex_names = set(flow_def.keys())

            for vname, vconfig in flow_def.items():
                if vconfig is None:
                    vconfig = {}

                issues.extend(
                    self._lint_vertex(vname, vconfig, flow_name)
                )

                # Check next references
                next_list = vconfig.get("next", [])
                if isinstance(next_list, str):
                    next_list = [next_list]

                for target in next_list:
                    has_edges = True
                    if target not in vertex_names:
                        issues.append(LintIssue(
                            "E001", "error",
                            f"Vertex '{target}' referenced in 'next' "
                            f"but not defined in flow.",
                            vertex=vname, flow=flow_name,
                            suggestion=f"Add '{target}' as a vertex in this flow.",
                        ))

            if not has_edges and len(flow_def) > 1:
                issues.append(LintIssue(
                    "E002", "error",
                    "Flow has multiple vertices but zero edges. "
                    "Add 'next' to connect them.",
                    flow=flow_name,
                    suggestion="Add 'next:' field to each vertex to define the pipeline.",
                ))

            if len(flow_def) == 1:
                issues.append(LintIssue(
                    "W007", "warning",
                    "Flow has only one vertex. Real business processes "
                    "typically require multiple steps (e.g. validate → "
                    "process → respond). A single-vertex flow suggests "
                    "either missing pipeline steps or a flow that should "
                    "be merged into a larger flow via 'next'.",
                    flow=flow_name,
                    suggestion=(
                        "Break this operation into a multi-step pipeline "
                        "or integrate it into an existing flow using 'next'."
                    ),
                ))

        return issues

    # ------------------------------------------------------------------
    # Per-vertex checks
    # ------------------------------------------------------------------

    def _lint_vertex(
        self,
        name: str,
        config: dict[str, Any],
        flow_name: str | None,
    ) -> list[LintIssue]:
        issues: list[LintIssue] = []

        # W006 - naming convention
        if not _SNAKE_RE.match(name):
            issues.append(LintIssue(
                "W006", "warning",
                f"Vertex name '{name}' is not snake_case.",
                vertex=name, flow=flow_name,
                suggestion="Use lowercase_with_underscores, e.g. 'create_user'.",
            ))

        # W001 - effect
        if "effect" not in config:
            issues.append(LintIssue(
                "W001", "warning",
                "Missing 'effect' field (defaults to 'pure').",
                vertex=name, flow=flow_name,
                suggestion="Add 'effect: pure' or 'effect: side_effect'.",
            ))

        # W002 - version
        if "version" not in config:
            issues.append(LintIssue(
                "W002", "warning",
                "Missing 'version' field.",
                vertex=name, flow=flow_name,
                suggestion="Add 'version: \"1\"' to enable cache invalidation.",
            ))

        # W003 - handler
        if "handler" not in config:
            issues.append(LintIssue(
                "W003", "warning",
                "Missing 'handler' field.",
                vertex=name, flow=flow_name,
                suggestion="Add handler dotted path, e.g. 'vertices.domain.module.func'.",
            ))

        # W005 - outputs
        if "outputs" not in config or not config.get("outputs"):
            issues.append(LintIssue(
                "W005", "warning",
                "Missing or empty 'outputs' declaration.",
                vertex=name, flow=flow_name,
                suggestion="Declare outputs for contract enforcement.",
            ))

        return issues
