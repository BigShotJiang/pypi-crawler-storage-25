"""Schema definitions for the DSL."""

from __future__ import annotations

from dataclasses import dataclass, field


@dataclass
class FlowVertexSchema:
    """Schema for a vertex inside a flow definition.

    Vertices are defined inline and edges are expressed via the
    ``next`` field.
    """
    name: str
    handler: str | None = None
    inputs: dict[str, str] | None = None
    outputs: dict[str, str] | None = None
    effect: str = "pure"
    version: str | None = None
    next: list[str] = field(default_factory=list)


@dataclass
class FlowSchema:
    """Schema for a complete flow definition."""
    name: str
    vertices: dict[str, FlowVertexSchema] = field(default_factory=dict)


@dataclass
class AtomicGroupSchema:
    """Schema for an atomic group definition."""
    name: str
    vertices: list[str] = field(default_factory=list)
    on_failure: str = "rollback"  # rollback | compensate | abort
    no_cache: bool = True
    no_parallel: bool = True
