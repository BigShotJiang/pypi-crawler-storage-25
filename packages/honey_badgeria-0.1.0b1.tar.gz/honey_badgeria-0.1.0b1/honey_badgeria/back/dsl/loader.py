"""DSL loader: loads graph definitions from YAML."""

from __future__ import annotations

from typing import Any, TYPE_CHECKING

from honey_badgeria.back.loader.graph_builder import GraphBuilder

if TYPE_CHECKING:
    from honey_badgeria.back.graph.graph import Graph


def load_graph_from_yaml(path: str) -> Graph:
    """Load a graph from a YAML DSL file."""
    return GraphBuilder.from_yaml(path)


def load_graph_from_dict(data: dict[str, Any]) -> Graph:
    """Load a graph from a dict."""
    return GraphBuilder.from_dict(data)
