"""DSL parser: parses graph definitions from YAML strings or files."""

from __future__ import annotations

from typing import Any, TYPE_CHECKING

from honey_badgeria.back.loader.graph_builder import GraphBuilder

if TYPE_CHECKING:
    from honey_badgeria.back.graph.graph import Graph


def parse_yaml(path: str) -> Graph:
    """Parse a YAML file into a Graph."""
    return GraphBuilder.from_yaml(path)


def parse_dict(data: dict[str, Any]) -> Graph:
    """Parse a dict into a Graph."""
    return GraphBuilder.from_dict(data)
