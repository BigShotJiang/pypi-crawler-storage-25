"""DSL validator: validates graph definitions before loading."""

from __future__ import annotations

from typing import Any


class DSLValidator:
    """Validates a graph definition dict for structural correctness."""

    def validate(self, data: Any) -> list[str]:
        """Validate a graph definition dict.

        Returns:
            List of error strings (empty if valid).
        """
        errors: list[str] = []
        errors.extend(self._validate_structure(data))

        if errors:
            return errors

        errors.extend(self._validate_flow_format(data))
        errors.extend(self._validate_atomic_groups(data))
        return errors

    # ------------------------------------------------------------------
    # Structure
    # ------------------------------------------------------------------

    def _validate_structure(self, data: Any) -> list[str]:
        errors: list[str] = []
        if not isinstance(data, dict):
            errors.append("Graph definition must be a dict")
            return errors
        if "flow" not in data:
            errors.append("Missing 'flow' key")
        return errors

    # ------------------------------------------------------------------
    # Flow format validation
    # ------------------------------------------------------------------

    def _validate_flow_format(self, data: dict[str, Any]) -> list[str]:
        """Validate the flow-centric format."""
        errors: list[str] = []
        flows = data.get("flow", {})

        if not isinstance(flows, dict):
            errors.append("'flow' must be a dict")
            return errors

        for flow_name, flow_def in flows.items():
            if not isinstance(flow_def, dict):
                errors.append(f"Flow '{flow_name}' must be a dict")
                continue

            for vertex_name, vertex_config in flow_def.items():
                if vertex_config is None:
                    vertex_config = {}

                if not isinstance(vertex_config, dict):
                    errors.append(
                        f"Flow '{flow_name}': vertex '{vertex_name}' "
                        f"config must be a dict or null"
                    )
                    continue

                # Validate 'next' references
                next_list = vertex_config.get("next", [])
                if isinstance(next_list, str):
                    next_list = [next_list]

                if not isinstance(next_list, list):
                    errors.append(
                        f"Flow '{flow_name}': vertex '{vertex_name}' "
                        f"'next' must be a list or string"
                    )
                    continue

                for target in next_list:
                    if not isinstance(target, str):
                        errors.append(
                            f"Flow '{flow_name}': vertex '{vertex_name}' "
                            f"'next' entries must be strings"
                        )
                    elif target not in flow_def:
                        errors.append(
                            f"Flow '{flow_name}': vertex '{vertex_name}' "
                            f"references unknown vertex in 'next': {target}"
                        )

        return errors

    # ------------------------------------------------------------------
    # Atomic groups
    # ------------------------------------------------------------------

    def _validate_atomic_groups(self, data: dict[str, Any]) -> list[str]:
        """Validate atomic_groups declarations."""
        errors: list[str] = []
        groups = data.get("atomic_groups", {})
        if not isinstance(groups, dict):
            errors.append("'atomic_groups' must be a dict")
            return errors

        # Collect all vertex names from flows
        vertex_names: set[str] = set()
        flow_data = data.get("flow", {})
        if isinstance(flow_data, dict):
            for flow_def in flow_data.values():
                if isinstance(flow_def, dict):
                    vertex_names.update(flow_def.keys())

        all_assigned: dict[str, str] = {}  # vertex -> group that owns it
        valid_policies = {"rollback", "compensate", "abort"}

        for group_name, gdef in groups.items():
            if not isinstance(gdef, dict):
                errors.append(
                    f"Atomic group '{group_name}' must be a dict"
                )
                continue

            verts = gdef.get("vertices", [])
            if not isinstance(verts, list) or len(verts) == 0:
                errors.append(
                    f"Atomic group '{group_name}' must declare "
                    f"a non-empty 'vertices' list"
                )
                continue

            for vname in verts:
                if vname not in vertex_names:
                    errors.append(
                        f"Atomic group '{group_name}' references "
                        f"unknown vertex: {vname}"
                    )
                if vname in all_assigned:
                    errors.append(
                        f"Vertex '{vname}' belongs to multiple atomic "
                        f"groups: '{all_assigned[vname]}' and '{group_name}'"
                    )
                all_assigned[vname] = group_name

            policy = gdef.get("on_failure", "rollback")
            if policy not in valid_policies:
                errors.append(
                    f"Atomic group '{group_name}': invalid on_failure "
                    f"policy '{policy}' (valid: {valid_policies})"
                )

        return errors
