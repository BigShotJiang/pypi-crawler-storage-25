"""Transaction backend ABCs — database-agnostic adapters.

Every external system that participates in atomic groups must implement
:class:`TransactionBackend`.  The framework calls these hooks at
well-defined points during the execution lifecycle:

    save_snapshot   → right before the first vertex in the group
    commit          → after the last vertex succeeds
    rollback        → when any vertex in the group fails

The :class:`InMemoryBackend` ships as a zero-dependency reference
implementation.  Users will plug in their own concrete backends::

    class PostgresBackend(TransactionBackend):
        def __init__(self, connection):
            self._conn = connection
        def save_snapshot(self, group, data):
            self._conn.execute("SAVEPOINT %s", group)
            ...

Design notes
~~~~~~~~~~~~
* ``save_snapshot`` receives a *copy* of the current ``DataStore``
  contents so the backend can persist them however it likes.
* ``rollback`` receives the original snapshot data so the backend
  can restore it.
* ``commit`` is intentionally lightweight — some backends (e.g. Redis)
  may choose to do nothing on commit because the writes are already
  in place.  Others (e.g. SQL) will ``RELEASE SAVEPOINT``.
"""

from __future__ import annotations

import copy
from abc import ABC, abstractmethod
from typing import Any


class TransactionBackend(ABC):
    """Abstract base for pluggable transaction adapters.

    Subclass this to connect Honey Badgeria's atomic groups
    to your database, message queue, or external system.
    """

    @abstractmethod
    def save_snapshot(
        self,
        group_name: str,
        data: dict[str, Any],
    ) -> None:
        """Persist a snapshot of *data* before the group begins.

        Args:
            group_name: Identifier of the atomic group.
            data: A **copy** of ``DataStore.dump()`` at the boundary.
        """

    @abstractmethod
    def rollback(
        self,
        group_name: str,
        snapshot_data: dict[str, Any],
    ) -> None:
        """Restore state to *snapshot_data*.

        Called when any vertex inside the group fails.

        Args:
            group_name: Identifier of the atomic group.
            snapshot_data: The data returned by the earlier
                ``save_snapshot`` call.
        """

    @abstractmethod
    def commit(self, group_name: str) -> None:
        """Finalise the transaction after all group vertices succeed.

        Args:
            group_name: Identifier of the atomic group.
        """

    # ------------------------------------------------------------------
    # Optional hooks — override as needed
    # ------------------------------------------------------------------

    def on_enter(self, group_name: str) -> None:
        """Called when execution enters the atomic boundary."""

    def on_exit(self, group_name: str, success: bool) -> None:
        """Called when execution leaves the atomic boundary.

        *success* is ``True`` when the group committed, ``False``
        when it rolled back.
        """


class InMemoryBackend(TransactionBackend):
    """Reference backend that keeps snapshots in memory.

    Suitable for tests and pipelines that don't persist to an
    external database.  The snapshot is simply a deep-copy of
    the data dict handed to ``save_snapshot``.
    """

    def __init__(self) -> None:
        self._snapshots: dict[str, dict[str, Any]] = {}
        self._committed: set[str] = set()
        self._rolled_back: set[str] = set()

    # -- ABC implementation -------------------------------------------

    def save_snapshot(
        self,
        group_name: str,
        data: dict[str, Any],
    ) -> None:
        self._snapshots[group_name] = copy.deepcopy(data)

    def rollback(
        self,
        group_name: str,
        snapshot_data: dict[str, Any],
    ) -> None:
        self._rolled_back.add(group_name)

    def commit(self, group_name: str) -> None:
        self._committed.add(group_name)
        # Snapshot no longer needed after commit.
        self._snapshots.pop(group_name, None)

    # -- Introspection helpers (useful in tests) -----------------------

    def get_snapshot(self, group_name: str) -> dict[str, Any] | None:
        """Return the saved snapshot for *group_name*, or ``None``."""
        return self._snapshots.get(group_name)

    def was_committed(self, group_name: str) -> bool:
        return group_name in self._committed

    def was_rolled_back(self, group_name: str) -> bool:
        return group_name in self._rolled_back

    def reset(self) -> None:
        """Clear all internal state."""
        self._snapshots.clear()
        self._committed.clear()
        self._rolled_back.clear()
