"""Atomicity subsystem for Honey Badgeria.

Provides ACID-like transaction semantics for groups of vertices and
a SAGA coordinator for long-running, multi-step compensating workflows.

Architecture
~~~~~~~~~~~~

* **AtomicGroup** — declares which vertices must run as a single unit.
* **TransactionBackend** — database-agnostic ABC that concrete adapters
  implement (Postgres, Mongo, Redis, in-memory, …).
* **InMemoryBackend** — ships with the framework; useful for tests and
  lightweight pipelines that don't touch an external database.
* **AtomicContext** — context-manager that wraps a group of vertex
  executions inside a snapshot → commit / rollback lifecycle.
* **SagaCoordinator** — orchestrates forward-step / compensate-step pairs
  across multiple atomic groups (SAGA pattern).
"""

from honey_badgeria.back.atomicity.backends import (
    TransactionBackend,
    InMemoryBackend,
)
from honey_badgeria.back.atomicity.group import AtomicGroup
from honey_badgeria.back.atomicity.context import AtomicContext
from honey_badgeria.back.atomicity.saga import SagaStep, SagaCoordinator

__all__ = [
    "TransactionBackend",
    "InMemoryBackend",
    "AtomicGroup",
    "AtomicContext",
    "SagaStep",
    "SagaCoordinator",
]
