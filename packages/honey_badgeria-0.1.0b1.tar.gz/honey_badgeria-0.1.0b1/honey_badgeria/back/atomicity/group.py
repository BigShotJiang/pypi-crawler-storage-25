"""AtomicGroup — declarative model for a group of vertices
that must execute as a single, all-or-nothing unit.

An AtomicGroup is defined either in YAML (DSL) or programmatically::

    # YAML
    atomic_groups:
      payment:
        vertices: [validate_card, charge_card, record_payment]
        on_failure: rollback          # or "compensate"
        no_cache: true
        no_parallel: true

    # Python
    group = AtomicGroup(
        name="payment",
        vertices=["validate_card", "charge_card", "record_payment"],
    )
"""

from __future__ import annotations

from dataclasses import dataclass, field
from enum import Enum


class FailurePolicy(str, Enum):
    """What to do when a vertex inside the group fails."""

    ROLLBACK = "rollback"
    """Restore data to the pre-group snapshot (default)."""

    COMPENSATE = "compensate"
    """Run the SAGA compensating actions for previously-completed vertices."""

    ABORT = "abort"
    """Stop execution immediately — no automatic rollback or compensation."""


@dataclass(frozen=True)
class AtomicGroup:
    """An immutable declaration of an atomic vertex group.

    Attributes:
        name: Unique identifier for this group.
        vertices: Ordered list of vertex names in this group.
        failure_policy: What to do on failure (default: rollback).
        no_cache: When ``True`` cache is bypassed for all vertices
            inside this group (avoids stale-read inconsistencies).
        no_parallel: When ``True`` parallelism is suppressed for every
            stage that contains a vertex from this group.
    """

    name: str
    vertices: list[str] = field(default_factory=list)
    failure_policy: FailurePolicy = FailurePolicy.ROLLBACK
    no_cache: bool = True
    no_parallel: bool = True

    # ------------------------------------------------------------------
    # Convenience helpers
    # ------------------------------------------------------------------

    def contains(self, vertex_name: str) -> bool:
        """Return ``True`` if *vertex_name* is part of this group."""
        return vertex_name in self.vertices

    @property
    def vertex_set(self) -> frozenset[str]:
        """The group's vertices as a frozen set for fast membership tests."""
        return frozenset(self.vertices)
