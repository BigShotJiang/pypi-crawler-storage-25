"""AtomicContext — runtime wrapper that enforces ACID semantics
around a group of vertex executions.

Usage inside the executor::

    ctx = AtomicContext(group, backend, data_store, state_store, logger)
    with ctx:
        for vertex in vertices_in_group:
            executor._execute_vertex(vertex)
    # On success → ctx.commit() is called automatically.
    # On exception → ctx.rollback() is called automatically.

The context manager protocol ensures that even if the executor forgets
to finalise, the ``__exit__`` will either commit or rollback.
"""

from __future__ import annotations

import copy
from typing import Any, TYPE_CHECKING

from honey_badgeria.core.exceptions import (
    AtomicRollbackError,
    AtomicSnapshotError,
)
from honey_badgeria.logging.event_types import EventType

if TYPE_CHECKING:
    from honey_badgeria.back.atomicity.backends import TransactionBackend
    from honey_badgeria.back.atomicity.group import AtomicGroup
    from honey_badgeria.back.runtime.data_store import DataStore
    from honey_badgeria.back.runtime.state_store import StateStore
    from honey_badgeria.back.runtime.lineage import DataLineage
    from honey_badgeria.logging.ai_logger import AILogger


class AtomicContext:
    """Wraps an :class:`AtomicGroup` execution in snapshot / commit / rollback.

    The caller creates the context, enters it with ``with``, and executes
    the group's vertices inside the block.  On success the block exits
    normally and the context commits.  On any exception the context
    rolls back the in-memory stores **and** delegates to the pluggable
    :class:`TransactionBackend` for external-system rollback.
    """

    def __init__(
        self,
        group: AtomicGroup,
        backend: TransactionBackend,
        data_store: DataStore,
        state_store: StateStore,
        lineage: DataLineage | None = None,
        logger: AILogger | None = None,
    ) -> None:
        self.group: AtomicGroup = group
        self.backend: TransactionBackend = backend
        self.data_store: DataStore = data_store
        self.state_store: StateStore = state_store
        self.lineage: DataLineage | None = lineage
        self.logger: AILogger | None = logger

        # Snapshot copies — taken on __enter__
        self._data_snapshot: dict[str, Any] = {}
        self._state_snapshot: dict[str, str] = {}
        self._lineage_snapshot: dict[str, dict[str, Any]] = {}
        self._committed: bool = False
        self._rolled_back: bool = False

    # ------------------------------------------------------------------
    # Context-manager protocol
    # ------------------------------------------------------------------

    def __enter__(self) -> AtomicContext:
        self._take_snapshot()
        return self

    def __exit__(
        self,
        exc_type: type[BaseException] | None,
        exc_val: BaseException | None,
        exc_tb: Any,
    ) -> bool:
        if exc_type is not None:
            # An exception occurred inside the group — rollback
            self.rollback(exc_val)
            # Do NOT suppress the original exception — let it propagate
            return False

        if not self._committed:
            self.commit()
        return False

    # ------------------------------------------------------------------
    # Snapshot
    # ------------------------------------------------------------------

    def _take_snapshot(self) -> None:
        """Capture current state so we can roll back later."""
        try:
            self._data_snapshot = copy.deepcopy(self.data_store.dump())
            self._state_snapshot = copy.deepcopy(self.state_store.dump())
            if self.lineage:
                self._lineage_snapshot = copy.deepcopy(self.lineage.dump())

            # Delegate to pluggable backend
            self.backend.save_snapshot(self.group.name, self._data_snapshot)
            self.backend.on_enter(self.group.name)

            self._log(EventType.ATOMIC_SNAPSHOT_SAVED, {
                "group": self.group.name,
                "vertices": self.group.vertices,
                "data_keys": list(self._data_snapshot.keys()),
            })
            self._log(EventType.ATOMIC_GROUP_ENTERED, {
                "group": self.group.name,
            })

        except Exception as exc:
            raise AtomicSnapshotError(
                f"Failed to save snapshot for atomic group "
                f"'{self.group.name}': {exc}"
            ) from exc

    # ------------------------------------------------------------------
    # Commit
    # ------------------------------------------------------------------

    def commit(self) -> None:
        """Mark the group as successfully completed."""
        if self._committed or self._rolled_back:
            return

        self.backend.commit(self.group.name)
        self.backend.on_exit(self.group.name, success=True)
        self._committed = True

        self._log(EventType.ATOMIC_COMMITTED, {
            "group": self.group.name,
        })

    # ------------------------------------------------------------------
    # Rollback
    # ------------------------------------------------------------------

    def rollback(self, original_error: BaseException | None = None) -> None:
        """Restore all in-memory stores to the snapshot and delegate
        to the backend for external-system rollback."""
        if self._committed or self._rolled_back:
            return

        from honey_badgeria.back.runtime.state_store import StateStore

        self._log(EventType.ATOMIC_ROLLBACK_STARTED, {
            "group": self.group.name,
            "reason": str(original_error) if original_error else "manual",
        })

        try:
            # 1. Restore DataStore
            self.data_store.clear()
            for key, value in self._data_snapshot.items():
                self.data_store.set_output(key, value)

            # 2. Restore StateStore
            for vname in self.group.vertices:
                prev = self._state_snapshot.get(vname, StateStore.PENDING)
                self.state_store.set_state(vname, prev)

            # 3. Restore Lineage
            if self.lineage:
                # LineageStore may not have a public "restore" method yet,
                # so we rebuild from the snapshot.
                self.lineage._lineage.clear()
                self.lineage._lineage.update(
                    copy.deepcopy(self._lineage_snapshot)
                )

            # 4. Delegate to pluggable backend
            self.backend.rollback(self.group.name, self._data_snapshot)
            self.backend.on_exit(self.group.name, success=False)

            self._rolled_back = True

            self._log(EventType.ATOMIC_ROLLBACK_COMPLETED, {
                "group": self.group.name,
            })

        except Exception as rollback_exc:
            self._log(EventType.ATOMIC_ROLLBACK_FAILED, {
                "group": self.group.name,
                "error": str(rollback_exc),
            })
            raise AtomicRollbackError(
                f"Rollback failed for group '{self.group.name}': "
                f"{rollback_exc}",
                group_name=self.group.name,
                original=original_error,
                rollback_error=rollback_exc,
            ) from rollback_exc

    # ------------------------------------------------------------------
    # Introspection
    # ------------------------------------------------------------------

    @property
    def is_committed(self) -> bool:
        return self._committed

    @property
    def is_rolled_back(self) -> bool:
        return self._rolled_back

    @property
    def snapshot_data(self) -> dict[str, Any]:
        """Return a copy of the snapshot (for debugging / tests)."""
        return dict(self._data_snapshot)

    # ------------------------------------------------------------------
    # Logging helper
    # ------------------------------------------------------------------

    def _log(self, event_type: str, data: dict[str, Any]) -> None:
        if self.logger:
            self.logger.log(event_type, data)
