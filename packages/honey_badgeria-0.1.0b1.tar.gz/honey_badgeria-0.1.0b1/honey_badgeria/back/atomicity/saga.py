"""SAGA coordinator — compensating transactions for complex workflows.

The SAGA pattern breaks a long-lived transaction into a sequence of
*steps*.  Each step has:

  * A **forward action** — the normal handler execution.
  * A **compensating action** — a handler that undoes the forward action
    if a later step fails.

If step N fails, the coordinator walks backwards from step N-1 to
step 0, calling each step's compensation.  This is the classic
"choreography SAGA" modelled as a DAG.

Usage::

    saga = SagaCoordinator("process_payment", backend, logger)

    saga.add_step(SagaStep(
        name="validate_card",
        vertex_name="validate_card",
        compensate_handler=noop,          # nothing to undo
    ))
    saga.add_step(SagaStep(
        name="charge_card",
        vertex_name="charge_card",
        compensate_handler=reverse_charge,  # refund
    ))
    saga.add_step(SagaStep(
        name="send_receipt",
        vertex_name="send_receipt",
        compensate_handler=cancel_receipt,
    ))

    result = saga.execute(executor)

Design notes
~~~~~~~~~~~~
* Steps are strictly **sequential** — SAGA semantics require total
  ordering so that compensations can unwind in reverse.
* Compensation handlers receive the *original inputs* and the
  *original result* of the forward step so they can decide how
  to undo it.
* If a compensation itself fails, the coordinator logs the failure
  and continues compensating earlier steps (best-effort), then raises
  :class:`SagaCompensationError`.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Callable, TYPE_CHECKING

from honey_badgeria.core.exceptions import (
    SagaCompensationError,
    SagaStepError,
)
from honey_badgeria.logging.event_types import EventType

if TYPE_CHECKING:
    from honey_badgeria.back.atomicity.backends import TransactionBackend
    from honey_badgeria.logging.ai_logger import AILogger


@dataclass
class SagaStep:
    """One step in a saga.

    Attributes:
        name: Human-readable identifier for this step.
        vertex_name: The vertex this step maps to in the graph.
        compensate_handler: Callable that undoes the forward action.
            Signature: ``(inputs: dict, result: dict) -> None``.
            Set to ``None`` when no compensation is needed.
    """

    name: str
    vertex_name: str
    compensate_handler: Callable[..., Any] | None = None


@dataclass
class _StepRecord:
    """Internal bookkeeping for an executed step."""

    step: SagaStep
    inputs: dict[str, Any] = field(default_factory=dict)
    result: dict[str, Any] = field(default_factory=dict)
    completed: bool = False


class SagaCoordinator:
    """Orchestrates a saga — forward steps with compensating rollback.

    The coordinator does **not** replace the normal executor.  Instead
    it *wraps* individual vertex executions, tracking which steps
    succeeded so that it can compensate them in reverse if a later
    step fails.
    """

    def __init__(
        self,
        name: str,
        backend: TransactionBackend | None = None,
        logger: AILogger | None = None,
    ) -> None:
        self.name: str = name
        self.backend: TransactionBackend | None = backend
        self.logger: AILogger | None = logger
        self._steps: list[SagaStep] = []
        self._records: list[_StepRecord] = []

    # ------------------------------------------------------------------
    # Step registration
    # ------------------------------------------------------------------

    def add_step(self, step: SagaStep) -> None:
        """Append a step to the saga (order matters)."""
        self._steps.append(step)

    @property
    def steps(self) -> list[SagaStep]:
        return list(self._steps)

    # ------------------------------------------------------------------
    # Execution
    # ------------------------------------------------------------------

    def execute(
        self,
        step_executor: Callable[[SagaStep], tuple[dict[str, Any], dict[str, Any]]],
    ) -> list[dict[str, Any]]:
        """Run all steps in order.

        *step_executor* is a callable that receives a :class:`SagaStep`
        and returns ``(inputs, result)`` for that step.  This keeps the
        coordinator decoupled from the graph executor.

        Returns:
            List of result dicts, one per step.

        Raises:
            SagaStepError: If a forward step fails (after compensation).
            SagaCompensationError: If compensation itself fails.
        """
        self._records.clear()
        self._log(EventType.SAGA_STARTED, {"saga": self.name})

        results: list[dict[str, Any]] = []

        for step in self._steps:
            record = _StepRecord(step=step)
            self._records.append(record)
            self._log(EventType.SAGA_STEP_STARTED, {
                "saga": self.name,
                "step": step.name,
            })

            try:
                inputs, result = step_executor(step)
                record.inputs = inputs
                record.result = result if isinstance(result, dict) else {}
                record.completed = True
                results.append(record.result)
                self._log(EventType.SAGA_STEP_COMPLETED, {
                    "saga": self.name,
                    "step": step.name,
                })

            except Exception as exc:
                self._log(EventType.SAGA_STEP_FAILED, {
                    "saga": self.name,
                    "step": step.name,
                    "error": str(exc),
                })
                # Compensate all previously-completed steps in reverse
                self._compensate(step.name)
                raise SagaStepError(
                    f"Saga '{self.name}' failed at step '{step.name}': {exc}",
                    step_name=step.name,
                    original=exc,
                ) from exc

        self._log(EventType.SAGA_COMPLETED, {"saga": self.name})
        return results

    # ------------------------------------------------------------------
    # Async execution
    # ------------------------------------------------------------------

    async def execute_async(
        self,
        step_executor: Callable[[SagaStep], Any],
    ) -> list[dict[str, Any]]:
        """Async variant of :meth:`execute`.

        *step_executor* must be an async callable returning
        ``(inputs, result)``.
        """
        self._records.clear()
        self._log(EventType.SAGA_STARTED, {"saga": self.name})

        results: list[dict[str, Any]] = []

        for step in self._steps:
            record = _StepRecord(step=step)
            self._records.append(record)
            self._log(EventType.SAGA_STEP_STARTED, {
                "saga": self.name,
                "step": step.name,
            })

            try:
                inputs, result = await step_executor(step)
                record.inputs = inputs
                record.result = result if isinstance(result, dict) else {}
                record.completed = True
                results.append(record.result)
                self._log(EventType.SAGA_STEP_COMPLETED, {
                    "saga": self.name,
                    "step": step.name,
                })

            except Exception as exc:
                self._log(EventType.SAGA_STEP_FAILED, {
                    "saga": self.name,
                    "step": step.name,
                    "error": str(exc),
                })
                self._compensate(step.name)
                raise SagaStepError(
                    f"Saga '{self.name}' failed at step '{step.name}': {exc}",
                    step_name=step.name,
                    original=exc,
                ) from exc

        self._log(EventType.SAGA_COMPLETED, {"saga": self.name})
        return results

    # ------------------------------------------------------------------
    # Compensation
    # ------------------------------------------------------------------

    def _compensate(self, failed_step_name: str) -> None:
        """Walk completed steps in reverse and call their compensations."""
        self._log(EventType.SAGA_COMPENSATING, {
            "saga": self.name,
            "failed_at": failed_step_name,
        })

        compensation_errors: list[tuple[str, BaseException]] = []

        for record in reversed(self._records):
            if not record.completed:
                continue
            if record.step.compensate_handler is None:
                continue

            try:
                record.step.compensate_handler(
                    record.inputs,
                    record.result,
                )
                self._log(EventType.SAGA_COMPENSATION_COMPLETED, {
                    "saga": self.name,
                    "step": record.step.name,
                })
            except Exception as comp_exc:
                compensation_errors.append((record.step.name, comp_exc))
                self._log(EventType.SAGA_COMPENSATION_FAILED, {
                    "saga": self.name,
                    "step": record.step.name,
                    "error": str(comp_exc),
                })
                # Continue compensating earlier steps — best effort

        if compensation_errors:
            raise SagaCompensationError(
                f"Saga '{self.name}': {len(compensation_errors)} "
                f"compensation(s) failed",
                failed_step=failed_step_name,
                compensation_errors=compensation_errors,
            )

    # ------------------------------------------------------------------
    # Introspection
    # ------------------------------------------------------------------

    @property
    def completed_steps(self) -> list[str]:
        """Names of steps that completed successfully."""
        return [r.step.name for r in self._records if r.completed]

    # ------------------------------------------------------------------
    # Logging
    # ------------------------------------------------------------------

    def _log(self, event_type: str, data: dict[str, Any]) -> None:
        if self.logger:
            self.logger.log(event_type, data)
