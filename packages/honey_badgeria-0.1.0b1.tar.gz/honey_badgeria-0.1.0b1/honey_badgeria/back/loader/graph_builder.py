"""Build Graph instances from dict data or YAML files.

Uses the **flow format** — a ``flow:`` top-level key where vertices are
defined inline and edges are inferred from ``next:`` fields::

    flow:
      my_flow:
        step_one:
          handler: vertices.mod.step_one
          next:
            - step_two
        step_two:
          handler: vertices.mod.step_two
"""

from __future__ import annotations

from typing import Any

from honey_badgeria.back.graph.graph import Graph
from honey_badgeria.back.graph.vertex import Vertex
from honey_badgeria.back.graph.edge import Edge
from honey_badgeria.back.atomicity.group import AtomicGroup, FailurePolicy


class GraphBuilder:
    """Builds a :class:`Graph` from a dictionary structure."""

    @staticmethod
    def from_dict(data: dict[str, Any]) -> Graph:
        """Build a Graph from a flow-format dict.

        The dict must contain a ``flow`` top-level key mapping flow names
        to vertex definitions.  Edges are inferred from ``next:`` fields.
        """
        graph = Graph()

        for flow_name, flow_def in data.get("flow", {}).items():
            if not isinstance(flow_def, dict):
                continue

            # Track which vertices are targets of 'next' within this flow
            referenced_targets: set[str] = set()

            for vertex_name, vertex_config in flow_def.items():
                if vertex_config is None:
                    vertex_config = {}

                # Create vertex if not already in graph (shared vertices)
                if not graph.has_vertex(vertex_name):
                    vertex = Vertex(
                        name=vertex_name,
                        handler=vertex_config.get("handler"),
                        inputs=vertex_config.get("inputs"),
                        outputs=vertex_config.get("outputs"),
                        version=vertex_config.get("version"),
                        effect=vertex_config.get("effect", "pure"),
                    )
                    graph.add_vertex(vertex)

                # Create edges from 'next'
                next_vertices = vertex_config.get("next", [])
                if isinstance(next_vertices, str):
                    next_vertices = [next_vertices]

                for target in next_vertices:
                    edge = Edge(source=vertex_name, target=target)
                    if edge not in graph.edges:
                        graph.add_edge(edge)
                    referenced_targets.add(target)

            # Auto-detect entry point: first vertex not referenced by
            # any 'next' within this flow (preserves definition order).
            flow_vertex_names = set(flow_def.keys())
            entry_candidates = flow_vertex_names - referenced_targets
            if entry_candidates:
                for vname in flow_def:
                    if vname in entry_candidates:
                        graph.flows[flow_name] = {"entry": vname}
                        break

        # Atomic groups
        GraphBuilder._load_atomic_groups(graph, data)

        return graph

    # ------------------------------------------------------------------
    # Helpers
    # ------------------------------------------------------------------

    @staticmethod
    def _load_atomic_groups(graph: Graph, data: dict[str, Any]) -> None:
        """Load atomic groups from data into graph."""
        for group_name, gdef in data.get("atomic_groups", {}).items():
            if isinstance(gdef, dict):
                policy_raw = gdef.get("on_failure", "rollback")
                try:
                    policy = FailurePolicy(policy_raw)
                except ValueError:
                    policy = FailurePolicy.ROLLBACK
                group = AtomicGroup(
                    name=group_name,
                    vertices=gdef.get("vertices", []),
                    failure_policy=policy,
                    no_cache=gdef.get("no_cache", True),
                    no_parallel=gdef.get("no_parallel", True),
                )
                graph.atomic_groups[group_name] = group

    @staticmethod
    def from_yaml(path: str) -> Graph:
        """Load a Graph from a YAML file. Requires pyyaml."""
        try:
            import yaml
        except ImportError:
            raise ImportError(
                "pyyaml is required for YAML loading. "
                "Install with: pip install honey-badgeria[yaml]"
            )

        with open(path) as f:
            data = yaml.safe_load(f)

        return GraphBuilder.from_dict(data)
