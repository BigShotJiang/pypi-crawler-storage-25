"""YAML graph loader (convenience wrapper)."""

from __future__ import annotations

from typing import TYPE_CHECKING

from honey_badgeria.back.loader.graph_builder import GraphBuilder

if TYPE_CHECKING:
    from honey_badgeria.back.graph.graph import Graph


def load_graph_from_yaml(path: str) -> Graph:
    """Load a graph from a YAML file."""
    return GraphBuilder.from_yaml(path)
