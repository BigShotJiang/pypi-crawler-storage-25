"""Input reference resolver for data bindings."""

from __future__ import annotations

from honey_badgeria.core.exceptions import DataResolutionError


class InputResolver:
    """Resolves input references like ``'vertex_name.output_key'``."""

    @staticmethod
    def is_reference(value: str) -> bool:
        """Check if a value is a data reference (contains '.')."""
        return isinstance(value, str) and "." in value

    @staticmethod
    def parse_reference(ref: str) -> tuple[str, str]:
        """Parse a reference string into ``(vertex_name, output_key)``.

        Raises:
            DataResolutionError: If the reference is invalid.
        """
        parts = ref.split(".", 1)
        if len(parts) != 2:
            raise DataResolutionError(f"Invalid reference: {ref}")
        return parts[0], parts[1]
