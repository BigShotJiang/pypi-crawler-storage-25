"""Vertex contracts for type validation."""

from .contract import VertexContract

__all__ = ["VertexContract"]
