"""Contract system for typed vertex communication.

Contracts declare:
- **Input types** — what keys a vertex expects and their types.
- **Output types** — what keys a vertex must produce.
- **Effect marker** — ``"pure"`` (cacheable) or ``"side_effect"``.
- **Version** — contract version for forward-compatible evolution.

Unknown type names (e.g. data-binding references like
``"fetch_user.user_id"``) are **skipped** during validation — they are
wiring instructions, not type declarations.
"""

from __future__ import annotations

import warnings
from typing import Any

from honey_badgeria.core.exceptions import ContractInputError, ContractOutputError


TYPE_MAP: dict[str, type] = {
    "str": str,
    "int": int,
    "float": float,
    "bool": bool,
    "dict": dict,
    "list": list,
    "tuple": tuple,
    "set": set,
    "bytes": bytes,
    "none": type(None),
}


class VertexContract:
    """Validates typed communication between vertices.

    Attributes:
        inputs: Mapping of ``{param: type_name}``.
        outputs: Mapping of ``{output_key: type_name}``.
        version: Optional version string (Principle 3).
        effect: ``"pure"`` or ``"side_effect"`` (Principle 8).
    """

    def __init__(
        self,
        inputs: dict[str, str] | None = None,
        outputs: dict[str, str] | None = None,
        version: str | None = None,
        effect: str = "pure",
    ) -> None:
        self.inputs: dict[str, str] = inputs or {}
        self.outputs: dict[str, str] = outputs or {}
        self.version: str | None = version
        self.effect: str = effect

    def validate_input(self, data: dict[str, Any]) -> None:
        """Validate input data against declared input types.

        Raises:
            ContractInputError: On missing key or type mismatch.
        """
        for key, expected_type_str in self.inputs.items():
            expected = TYPE_MAP.get(expected_type_str)
            if expected is None:
                # Not a known type — this is a data-binding reference, skip.
                continue
            if key not in data:
                raise ContractInputError(f"Missing input: {key}")
            if not isinstance(data[key], expected):
                raise ContractInputError(
                    f"Input '{key}': expected {expected_type_str}, "
                    f"got {type(data[key]).__name__}"
                )

    def validate_output(self, data: Any) -> None:
        """Validate output data against declared output types.

        Non-dict outputs emit a warning instead of silently passing.

        Raises:
            ContractOutputError: On missing key or type mismatch.
        """
        if not isinstance(data, dict):
            if self.outputs:
                warnings.warn(
                    f"VertexContract expected dict output with keys "
                    f"{list(self.outputs.keys())}, got {type(data).__name__}. "
                    f"Output validation skipped.",
                    stacklevel=2,
                )
            return
        for key, expected_type_str in self.outputs.items():
            expected = TYPE_MAP.get(expected_type_str)
            if expected is None:
                continue
            if key not in data:
                raise ContractOutputError(f"Missing output: {key}")
            if not isinstance(data[key], expected):
                raise ContractOutputError(
                    f"Output '{key}': expected {expected_type_str}, "
                    f"got {type(data[key]).__name__}"
                )
