"""
Honey Badgeria Backend — DAG execution engine.

This package contains the backend-specific modules for HBIA:

    back/
    ├── dsl/          YAML DSL schemas, parser, validator, loader
    ├── graph/        Graph data model (Vertex, Edge, Graph)
    ├── explain/      AI-readable graph explanations
    ├── lint/         AI-oriented design-quality linter
    ├── runtime/      Execution engine (executor, runner, cache)
    ├── atomicity/    Atomic group / saga support
    ├── contracts/    Vertex I/O contracts
    ├── discovery/    Auto-discovery and graph building
    ├── loader/       Graph builder from DSL
    ├── registry/     Handler and vertex registries
    ├── topology.py   Topological sort engine
    └── validator.py  Graph structural validator
"""
