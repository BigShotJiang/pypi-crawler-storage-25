"""Registry for vertex handlers."""

from __future__ import annotations

from typing import Any, Callable

from honey_badgeria.core.exceptions import (
    HandlerNotFoundError,
    VertexAlreadyExistsError,
)


class VertexRegistry:
    """Global registry of vertex handlers."""

    def __init__(self) -> None:
        self._registry: dict[str, Callable[..., Any]] = {}

    def register(self, name: str, handler: Callable[..., Any]) -> None:
        """Register a handler for a vertex name.

        Re-registering the **same** callable for an existing name is
        allowed (idempotent).  Registering a **different** callable
        raises an error.

        Raises:
            VertexAlreadyExistsError: If the name is already registered
                with a different handler.
        """
        if name in self._registry:
            if self._registry[name] is handler:
                return  # idempotent — same handler, no-op
            raise VertexAlreadyExistsError(f"Vertex '{name}' already registered")
        self._registry[name] = handler

    def get(self, name: str) -> Callable[..., Any]:
        """Get a handler by vertex name.

        Raises:
            HandlerNotFoundError: If the name is not registered.
        """
        if name not in self._registry:
            raise HandlerNotFoundError(f"Vertex '{name}' not registered")
        return self._registry[name]

    def has(self, name: str) -> bool:
        """Check if a vertex is registered."""
        return name in self._registry

    def list_vertices(self) -> list[str]:
        """List all registered vertex names."""
        return list(self._registry.keys())

    def clear(self) -> None:
        """Clear all registrations."""
        self._registry.clear()
