"""Resolves handler paths into Python callables.

Security: when ``allowed_prefixes`` is set (via :class:`Settings`),
only modules under those prefixes can be imported.  This prevents
arbitrary code execution through crafted YAML handler paths.
"""

from __future__ import annotations

import importlib
from typing import Any, Callable

from honey_badgeria.core.exceptions import HandlerResolutionError


class HandlerResolver:
    """Resolves handler paths into Python callables.

    Args:
        allowed_prefixes: If non-empty, ``resolve`` only accepts
            dotted paths that start with one of these prefixes.
            Set via ``Settings.ALLOWED_HANDLER_PREFIXES``.
    """

    def __init__(
        self,
        allowed_prefixes: tuple[str, ...] = (),
    ) -> None:
        self._cache: dict[str, Callable[..., Any]] = {}
        self._allowed_prefixes: tuple[str, ...] = allowed_prefixes

    def resolve(self, handler: Callable[..., Any] | str) -> Callable[..., Any]:
        """Resolve a handler to a callable.

        Raises:
            HandlerResolutionError: If the handler cannot be resolved or
                is blocked by the prefix allow-list.
        """
        if callable(handler):
            return handler

        if not isinstance(handler, str):
            raise HandlerResolutionError(
                f"Handler must be callable or string, got {type(handler)}"
            )

        if handler in self._cache:
            return self._cache[handler]

        if "." not in handler:
            raise HandlerResolutionError(
                f"Handler path must be a dotted path: {handler}"
            )

        # --- prefix allow-list ---
        if self._allowed_prefixes:
            if not any(handler.startswith(p) for p in self._allowed_prefixes):
                raise HandlerResolutionError(
                    f"Handler '{handler}' blocked by ALLOWED_HANDLER_PREFIXES. "
                    f"Allowed: {self._allowed_prefixes}"
                )

        module_path, function_name = handler.rsplit(".", 1)
        try:
            module = importlib.import_module(module_path)
        except ImportError as exc:
            raise HandlerResolutionError(
                f"Cannot import module '{module_path}': {exc}"
            ) from exc

        if not hasattr(module, function_name):
            raise HandlerResolutionError(
                f"Handler '{function_name}' not found in '{module_path}'"
            )

        fn = getattr(module, function_name)

        if not callable(fn):
            raise HandlerResolutionError(
                f"Handler '{handler}' is not callable"
            )

        self._cache[handler] = fn
        return fn
