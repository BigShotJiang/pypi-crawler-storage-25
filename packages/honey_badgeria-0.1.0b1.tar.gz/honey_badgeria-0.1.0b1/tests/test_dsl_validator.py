"""Tests for DSLValidator."""

from honey_badgeria.back.dsl.validator import DSLValidator


class TestDSLValidator:

    def test_valid_flow_dict(self):
        data = {
            "flow": {
                "main": {
                    "a": {"handler": "handler_a", "next": ["b"]},
                    "b": {"handler": "handler_b"},
                }
            }
        }
        errors = DSLValidator().validate(data)
        assert errors == []

    def test_missing_flow_key(self):
        errors = DSLValidator().validate({"random": "data"})
        assert any("flow" in e for e in errors)

    def test_not_a_dict(self):
        errors = DSLValidator().validate("not a dict")
        assert any("dict" in e for e in errors)

    def test_next_references_unknown_vertex(self):
        data = {
            "flow": {
                "main": {
                    "a": {"handler": "h.a", "next": ["nonexistent"]},
                }
            }
        }
        errors = DSLValidator().validate(data)
        assert any("unknown vertex" in e for e in errors)

    def test_flow_must_be_dict(self):
        data = {"flow": "not a dict"}
        errors = DSLValidator().validate(data)
        assert any("dict" in e for e in errors)

    def test_flow_definition_must_be_dict(self):
        data = {"flow": {"main": "not a dict"}}
        errors = DSLValidator().validate(data)
        assert any("dict" in e for e in errors)

    def test_vertex_config_must_be_dict(self):
        data = {"flow": {"main": {"a": "not a dict"}}}
        errors = DSLValidator().validate(data)
        assert any("dict" in e for e in errors)

    def test_empty_flow_valid(self):
        data = {"flow": {}}
        errors = DSLValidator().validate(data)
        assert errors == []

    def test_minimal_valid_single_vertex(self):
        data = {"flow": {"main": {"a": {}}}}
        errors = DSLValidator().validate(data)
        assert errors == []

    def test_null_vertex_config_valid(self):
        data = {"flow": {"main": {"a": None}}}
        errors = DSLValidator().validate(data)
        assert errors == []

    def test_next_as_string_valid(self):
        data = {
            "flow": {
                "main": {
                    "a": {"next": "b"},
                    "b": {},
                }
            }
        }
        errors = DSLValidator().validate(data)
        assert errors == []
