"""Tests for async and parallel execution modes."""

import asyncio
import time
import pytest
from honey_badgeria.back.graph import Graph, Vertex, Edge
from honey_badgeria.back.runtime.executor import GraphExecutor
from honey_badgeria.back.runtime.runner import run_flow, run_flow_async
from honey_badgeria.testing import GraphFactory
from honey_badgeria.conf.settings import Settings, configure, reset_settings


# ---------------------------------------------------------------------------
# helpers
# ---------------------------------------------------------------------------

def _diamond_graph():
    """
    source ─┬─ branch_a ─┬─ merge
            └─ branch_b ─┘
    """
    def source():
        return {"value": 10}

    def branch_a(value):
        return {"result": value * 2}

    def branch_b(value):
        return {"result": value * 3}

    def merge(a_result, b_result):
        return {"total": a_result + b_result}

    g = Graph()
    g.add_vertex(Vertex("source", handler=source))
    g.add_vertex(Vertex("branch_a", handler=branch_a,
        inputs={"value": "source.value"}))
    g.add_vertex(Vertex("branch_b", handler=branch_b,
        inputs={"value": "source.value"}))
    g.add_vertex(Vertex("merge", handler=merge,
        inputs={"a_result": "branch_a.result", "b_result": "branch_b.result"}))
    g.add_edge(Edge("source", "branch_a"))
    g.add_edge(Edge("source", "branch_b"))
    g.add_edge(Edge("branch_a", "merge"))
    g.add_edge(Edge("branch_b", "merge"))
    return g


# ===========================================================================
# Serial execution (default)
# ===========================================================================

class TestSerialExecution:
    """All optional flags off → fully serial, no threads, no async."""

    def setup_method(self):
        reset_settings()

    def teardown_method(self):
        reset_settings()

    def test_serial_diamond(self):
        g = _diamond_graph()
        executor = GraphExecutor(g, parallel_enabled=False, async_enabled=False)
        result = executor.execute()
        assert result["merge.total"] == 50  # 10*2 + 10*3

    def test_serial_is_default(self):
        g = _diamond_graph()
        executor = GraphExecutor(g)  # no flags
        result = executor.execute()
        assert result["merge.total"] == 50

    def test_run_flow_serial(self):
        g = _diamond_graph()
        result = run_flow(g, parallel_enabled=False)
        assert result["merge.total"] == 50


# ===========================================================================
# Parallel execution (threads)
# ===========================================================================

class TestParallelExecution:
    """PARALLEL_ENABLED=True → stage vertices run in threads."""

    def setup_method(self):
        reset_settings()

    def teardown_method(self):
        reset_settings()

    def test_parallel_diamond_correct_result(self):
        g = _diamond_graph()
        executor = GraphExecutor(g, parallel_enabled=True, max_workers=2)
        result = executor.execute()
        assert result["merge.total"] == 50

    def test_parallel_via_settings(self):
        configure(Settings(PARALLEL_ENABLED=True, MAX_WORKERS=2))
        g = _diamond_graph()
        executor = GraphExecutor(g)
        result = executor.execute()
        assert result["merge.total"] == 50

    def test_parallel_run_flow(self):
        g = _diamond_graph()
        result = run_flow(g, parallel_enabled=True, max_workers=4)
        assert result["merge.total"] == 50

    def test_parallel_override_settings(self):
        """Per-call kwarg overrides global settings."""
        configure(Settings(PARALLEL_ENABLED=False))
        g = _diamond_graph()
        result = run_flow(g, parallel_enabled=True)
        assert result["merge.total"] == 50

    def test_parallel_actually_runs_concurrently(self):
        """Verify parallel is faster than serial for slow handlers."""
        execution_log = []

        def slow_a(value):
            time.sleep(0.05)
            execution_log.append("a")
            return {"result": value}

        def slow_b(value):
            time.sleep(0.05)
            execution_log.append("b")
            return {"result": value}

        def source():
            return {"value": 1}

        def merge(a_result, b_result):
            return {"total": a_result + b_result}

        g = Graph()
        g.add_vertex(Vertex("source", handler=source))
        g.add_vertex(Vertex("a", handler=slow_a, inputs={"value": "source.value"}))
        g.add_vertex(Vertex("b", handler=slow_b, inputs={"value": "source.value"}))
        g.add_vertex(Vertex("merge", handler=merge,
            inputs={"a_result": "a.result", "b_result": "b.result"}))
        g.add_edge(Edge("source", "a"))
        g.add_edge(Edge("source", "b"))
        g.add_edge(Edge("a", "merge"))
        g.add_edge(Edge("b", "merge"))

        start = time.monotonic()
        executor = GraphExecutor(g, parallel_enabled=True, max_workers=2)
        result = executor.execute()
        elapsed = time.monotonic() - start

        assert result["merge.total"] == 2
        # Parallel should be ~0.05s, serial would be ~0.10s
        assert elapsed < 0.15  # generous margin

    def test_single_vertex_stage_no_pool(self):
        """Stages with 1 vertex don't spawn a thread pool."""
        def step():
            return {"x": 1}
        g = GraphFactory.create(vertices=[{"name": "step", "handler": step}])
        executor = GraphExecutor(g, parallel_enabled=True)
        result = executor.execute()
        assert result["step.x"] == 1


# ===========================================================================
# Async execution
# ===========================================================================

class TestAsyncExecution:
    """ASYNC_ENABLED=True → coroutine handlers are awaited."""

    def setup_method(self):
        reset_settings()

    def teardown_method(self):
        reset_settings()

    def test_async_handler(self):
        async def async_greet():
            return {"message": "hello async"}

        g = GraphFactory.create(
            vertices=[{"name": "greet", "handler": async_greet}],
        )
        executor = GraphExecutor(g, async_enabled=True)
        result = asyncio.run(executor.execute_async())
        assert result["greet.message"] == "hello async"

    def test_async_chained(self):
        async def step1():
            return {"value": 10}

        async def step2(value):
            return {"doubled": value * 2}

        g = GraphFactory.create(
            vertices=[
                {"name": "step1", "handler": step1},
                {"name": "step2", "handler": step2, "inputs": {"value": "step1.value"}},
            ],
            edges=[("step1", "step2")],
        )
        result = asyncio.run(
            GraphExecutor(g, async_enabled=True).execute_async()
        )
        assert result["step2.doubled"] == 20

    def test_async_mixed_sync_and_async_handlers(self):
        """Mix of sync and async handlers in the same graph."""
        def sync_source():
            return {"value": 5}

        async def async_double(value):
            return {"result": value * 2}

        g = GraphFactory.create(
            vertices=[
                {"name": "src", "handler": sync_source},
                {"name": "dbl", "handler": async_double,
                 "inputs": {"value": "src.value"}},
            ],
            edges=[("src", "dbl")],
        )
        result = asyncio.run(
            GraphExecutor(g, async_enabled=True).execute_async()
        )
        assert result["dbl.result"] == 10

    def test_run_flow_async(self):
        async def compute():
            return {"result": 42}

        g = GraphFactory.create(
            vertices=[{"name": "c", "handler": compute}],
        )
        result = asyncio.run(run_flow_async(g))
        assert result["c.result"] == 42

    def test_async_parallel_diamond(self):
        """async_enabled + parallel_enabled → asyncio.gather in stages."""
        async def source():
            return {"value": 3}

        async def branch_a(value):
            return {"result": value + 1}

        async def branch_b(value):
            return {"result": value + 2}

        async def merge(a_result, b_result):
            return {"total": a_result + b_result}

        g = Graph()
        g.add_vertex(Vertex("source", handler=source))
        g.add_vertex(Vertex("a", handler=branch_a, inputs={"value": "source.value"}))
        g.add_vertex(Vertex("b", handler=branch_b, inputs={"value": "source.value"}))
        g.add_vertex(Vertex("merge", handler=merge,
            inputs={"a_result": "a.result", "b_result": "b.result"}))
        g.add_edge(Edge("source", "a"))
        g.add_edge(Edge("source", "b"))
        g.add_edge(Edge("a", "merge"))
        g.add_edge(Edge("b", "merge"))

        result = asyncio.run(
            GraphExecutor(g, async_enabled=True, parallel_enabled=True).execute_async()
        )
        # (3+1) + (3+2) = 4 + 5 = 9
        assert result["merge.total"] == 9


# ===========================================================================
# State tracking
# ===========================================================================

class TestExecutionStateTracking:
    """Executor tracks vertex states through StateStore."""

    def setup_method(self):
        reset_settings()

    def teardown_method(self):
        reset_settings()

    def test_states_after_execution(self):
        def step():
            return {"done": True}

        g = GraphFactory.create(
            vertices=[{"name": "step", "handler": step}],
        )
        executor = GraphExecutor(g)
        executor.execute()
        assert executor.state_store.get_state("step") == "completed"

    def test_failed_state(self):
        def fail():
            raise RuntimeError("boom")

        g = GraphFactory.create(
            vertices=[{"name": "fail", "handler": fail}],
        )
        executor = GraphExecutor(g)
        with pytest.raises(RuntimeError):
            executor.execute()
        assert executor.state_store.get_state("fail") == "failed"

    def test_all_completed(self):
        def a():
            return {"x": 1}
        def b(x):
            return {"y": 2}

        g = GraphFactory.create(
            vertices=[
                {"name": "a", "handler": a},
                {"name": "b", "handler": b, "inputs": {"x": "a.x"}},
            ],
            edges=[("a", "b")],
        )
        executor = GraphExecutor(g)
        executor.execute()
        assert executor.state_store.all_completed()
