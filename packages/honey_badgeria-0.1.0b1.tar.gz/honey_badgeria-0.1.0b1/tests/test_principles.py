"""Tests for all features added during the 9-principles audit.

Covers:
    - conf/defaults.py — centralised constants
    - New Settings fields (MAX_CACHE_ENTRIES, ALLOWED_HANDLER_PREFIXES, etc.)
    - Vertex.version, Vertex.effect, Vertex.is_pure
    - Graph.schema_version
    - VertexContract.version, VertexContract.effect
    - _resolve_flow_graph (flow_name sub-graph extraction)
    - HandlerResolver with allowed_prefixes
    - VertexRegistry idempotent registration
    - ModuleHealthChecker (all 3 checks)
    - Executor: contract enforcement, cache skipping for side-effect vertices
    - Runner: async_enabled fix
"""

from __future__ import annotations

import os
import textwrap
import warnings
from pathlib import Path
from typing import Any

import pytest

# ---------------------------------------------------------------------------
# defaults.py — centralised constants
# ---------------------------------------------------------------------------

from honey_badgeria.conf.defaults import (
    DEFAULT_CACHE_DIR,
    DEFAULT_MAX_WORKERS,
    DEFAULT_GRAPH_FILE,
    DEFAULT_MAX_CACHE_ENTRIES,
    CACHE_FILE_EXTENSION,
    ALLOWED_HANDLER_PREFIXES,
    DEFAULT_API_PREFIX,
    DEFAULT_MAX_PAGE_SIZE,
    MODULE_MAX_LINES,
    MODULE_MAX_VERTICES,
    SCHEMA_VERSION,
)


class TestDefaults:
    """Every constant in defaults.py exists and has the expected type."""

    def test_default_cache_dir_is_str(self):
        assert isinstance(DEFAULT_CACHE_DIR, str)
        assert DEFAULT_CACHE_DIR == ".hbia_cache"

    def test_default_max_workers_is_int(self):
        assert isinstance(DEFAULT_MAX_WORKERS, int)
        assert DEFAULT_MAX_WORKERS == 4

    def test_default_graph_file(self):
        assert isinstance(DEFAULT_GRAPH_FILE, str)
        assert DEFAULT_GRAPH_FILE == "graph.yaml"

    def test_default_max_cache_entries(self):
        assert isinstance(DEFAULT_MAX_CACHE_ENTRIES, int)
        assert DEFAULT_MAX_CACHE_ENTRIES == 500

    def test_cache_file_extension(self):
        assert isinstance(CACHE_FILE_EXTENSION, str)
        assert CACHE_FILE_EXTENSION.startswith(".")

    def test_allowed_handler_prefixes_empty_by_default(self):
        assert isinstance(ALLOWED_HANDLER_PREFIXES, tuple)
        assert len(ALLOWED_HANDLER_PREFIXES) == 0

    def test_default_api_prefix(self):
        assert isinstance(DEFAULT_API_PREFIX, str)
        assert DEFAULT_API_PREFIX.startswith("/")

    def test_default_max_page_size(self):
        assert isinstance(DEFAULT_MAX_PAGE_SIZE, int)
        assert DEFAULT_MAX_PAGE_SIZE > 0

    def test_module_max_lines(self):
        assert isinstance(MODULE_MAX_LINES, int)
        assert MODULE_MAX_LINES == 300

    def test_module_max_vertices(self):
        assert isinstance(MODULE_MAX_VERTICES, int)
        assert MODULE_MAX_VERTICES == 20

    def test_schema_version(self):
        assert isinstance(SCHEMA_VERSION, str)
        assert SCHEMA_VERSION == "1"


# ---------------------------------------------------------------------------
# Settings — new fields
# ---------------------------------------------------------------------------

from honey_badgeria.conf.settings import Settings, reset_settings


class TestSettingsNewFields:
    """New settings introduced during the audit."""

    def test_max_cache_entries_default(self):
        s = Settings()
        assert s.MAX_CACHE_ENTRIES == DEFAULT_MAX_CACHE_ENTRIES

    def test_max_cache_entries_override(self):
        s = Settings(MAX_CACHE_ENTRIES=1000)
        assert s.MAX_CACHE_ENTRIES == 1000

    def test_allowed_handler_prefixes_default(self):
        s = Settings()
        assert s.ALLOWED_HANDLER_PREFIXES == ()

    def test_allowed_handler_prefixes_override(self):
        s = Settings(ALLOWED_HANDLER_PREFIXES=("my.pkg",))
        assert s.ALLOWED_HANDLER_PREFIXES == ("my.pkg",)

    def test_allowed_handler_prefixes_from_list(self):
        s = Settings(ALLOWED_HANDLER_PREFIXES=["a", "b"])
        assert s.ALLOWED_HANDLER_PREFIXES == ("a", "b")

    def test_api_prefix_default(self):
        s = Settings()
        assert s.API_PREFIX == DEFAULT_API_PREFIX

    def test_api_prefix_override(self):
        s = Settings(API_PREFIX="/v2")
        assert s.API_PREFIX == "/v2"

    def test_max_page_size_default(self):
        s = Settings()
        assert s.MAX_PAGE_SIZE == DEFAULT_MAX_PAGE_SIZE

    def test_max_page_size_override(self):
        s = Settings(MAX_PAGE_SIZE=50)
        assert s.MAX_PAGE_SIZE == 50

    def test_to_dict_includes_new_fields(self):
        s = Settings(ALLOWED_HANDLER_PREFIXES=("x",), MAX_CACHE_ENTRIES=42)
        d = s.to_dict()
        assert d["MAX_CACHE_ENTRIES"] == 42
        assert d["ALLOWED_HANDLER_PREFIXES"] == ["x"]
        assert "API_PREFIX" in d
        assert "MAX_PAGE_SIZE" in d


class TestSettingsNewFieldsFromEnv:
    """from_env() reads new environment variables."""

    def setup_method(self):
        reset_settings()

    def teardown_method(self):
        reset_settings()

    def test_env_max_cache_entries(self, monkeypatch):
        monkeypatch.setenv("HBIA_MAX_CACHE_ENTRIES", "200")
        s = Settings.from_env()
        assert s.MAX_CACHE_ENTRIES == 200

    def test_env_allowed_handler_prefixes(self, monkeypatch):
        monkeypatch.setenv("HBIA_ALLOWED_HANDLER_PREFIXES", "pkg_a,pkg_b")
        s = Settings.from_env()
        assert s.ALLOWED_HANDLER_PREFIXES == ("pkg_a", "pkg_b")

    def test_env_allowed_handler_prefixes_empty(self, monkeypatch):
        monkeypatch.delenv("HBIA_ALLOWED_HANDLER_PREFIXES", raising=False)
        s = Settings.from_env()
        assert s.ALLOWED_HANDLER_PREFIXES == ()

    def test_env_api_prefix(self, monkeypatch):
        monkeypatch.setenv("HBIA_API_PREFIX", "/custom/v3")
        s = Settings.from_env()
        assert s.API_PREFIX == "/custom/v3"

    def test_env_max_page_size(self, monkeypatch):
        monkeypatch.setenv("HBIA_MAX_PAGE_SIZE", "25")
        s = Settings.from_env()
        assert s.MAX_PAGE_SIZE == 25


# ---------------------------------------------------------------------------
# Vertex — version, effect, is_pure
# ---------------------------------------------------------------------------

from honey_badgeria.back.graph.vertex import Vertex, PURE, SIDE_EFFECT


class TestVertexVersionEffect:
    """Vertex version and effect attributes (Principles 3, 8)."""

    def test_default_version_is_none(self):
        v = Vertex("a")
        assert v.version is None

    def test_custom_version(self):
        v = Vertex("a", version="2.1")
        assert v.version == "2.1"

    def test_default_effect_is_pure(self):
        v = Vertex("a")
        assert v.effect == PURE

    def test_is_pure_true_by_default(self):
        v = Vertex("a")
        assert v.is_pure is True

    def test_side_effect_vertex(self):
        v = Vertex("a", effect=SIDE_EFFECT)
        assert v.effect == SIDE_EFFECT
        assert v.is_pure is False

    def test_pure_constant_value(self):
        assert PURE == "pure"

    def test_side_effect_constant_value(self):
        assert SIDE_EFFECT == "side_effect"


# ---------------------------------------------------------------------------
# Graph — schema_version
# ---------------------------------------------------------------------------

from honey_badgeria.back.graph.graph import Graph
from honey_badgeria.back.graph.edge import Edge


class TestGraphSchemaVersion:
    """Graph carries a schema_version (Principle 3)."""

    def test_default_schema_version(self):
        g = Graph()
        assert g.schema_version == SCHEMA_VERSION

    def test_schema_version_is_string(self):
        g = Graph()
        assert isinstance(g.schema_version, str)


# ---------------------------------------------------------------------------
# VertexContract — version, effect
# ---------------------------------------------------------------------------

from honey_badgeria.back.contracts.contract import VertexContract


class TestVertexContractVersionEffect:
    """VertexContract version and effect fields."""

    def test_default_version_none(self):
        c = VertexContract()
        assert c.version is None

    def test_custom_version(self):
        c = VertexContract(version="3")
        assert c.version == "3"

    def test_default_effect_pure(self):
        c = VertexContract()
        assert c.effect == "pure"

    def test_side_effect(self):
        c = VertexContract(effect="side_effect")
        assert c.effect == "side_effect"

    def test_non_dict_output_warns(self):
        c = VertexContract(outputs={"x": "str"})
        with warnings.catch_warnings(record=True) as w:
            warnings.simplefilter("always")
            c.validate_output("not a dict")
            assert len(w) == 1
            assert "expected dict output" in str(w[0].message)


# ---------------------------------------------------------------------------
# _resolve_flow_graph — flow_name sub-graph extraction
# ---------------------------------------------------------------------------

from honey_badgeria.back.runtime.runner import run_flow
from honey_badgeria.core.exceptions import FlowNotFoundError


class TestResolveFlowGraph:
    """run_flow with flow_name extracts a sub-graph."""

    def _make_multi_flow_graph(self):
        """Build a graph with two independent flows: flow_a and flow_b."""
        def fn_a1():
            return {"x": 1}

        def fn_a2(x):
            return {"y": x + 1}

        def fn_b1():
            return {"z": 99}

        g = Graph()
        g.add_vertex(Vertex("a1", handler=fn_a1))
        g.add_vertex(Vertex("a2", handler=fn_a2, inputs={"x": "a1.x"}))
        g.add_vertex(Vertex("b1", handler=fn_b1))
        g.add_edge(Edge("a1", "a2"))
        g.flows = {
            "flow_a": {"entry": "a1"},
            "flow_b": {"entry": "b1"},
        }
        return g

    def test_flow_name_none_runs_all(self):
        g = self._make_multi_flow_graph()
        result = run_flow(g)
        # All vertices executed
        assert "a1.x" in result
        assert "a2.y" in result
        assert "b1.z" in result

    def test_flow_name_restricts_to_subgraph(self):
        g = self._make_multi_flow_graph()
        result = run_flow(g, flow_name="flow_a")
        assert "a1.x" in result
        assert "a2.y" in result
        assert result["a2.y"] == 2
        # b1 should NOT have run
        assert "b1.z" not in result

    def test_flow_name_single_vertex(self):
        g = self._make_multi_flow_graph()
        result = run_flow(g, flow_name="flow_b")
        assert "b1.z" in result
        assert result["b1.z"] == 99
        # flow_a vertices should NOT have run
        assert "a1.x" not in result

    def test_invalid_flow_name_raises(self):
        g = self._make_multi_flow_graph()
        with pytest.raises(FlowNotFoundError):
            run_flow(g, flow_name="nonexistent")


# ---------------------------------------------------------------------------
# HandlerResolver — allowed_prefixes
# ---------------------------------------------------------------------------

from honey_badgeria.back.registry.handler_resolver import HandlerResolver
from honey_badgeria.core.exceptions import HandlerResolutionError


class TestHandlerResolverPrefixes:
    """HandlerResolver allowed_prefixes security gate."""

    def test_callable_bypasses_prefix_check(self):
        resolver = HandlerResolver(allowed_prefixes=("myproject.",))
        fn = lambda: None
        assert resolver.resolve(fn) is fn

    def test_no_prefixes_allows_anything(self):
        resolver = HandlerResolver()
        # Should attempt import (will fail because module doesn't exist),
        # but should NOT raise HandlerResolutionError about prefixes.
        with pytest.raises(HandlerResolutionError, match="Cannot import"):
            resolver.resolve("some.fake.module.func")

    def test_prefix_blocks_disallowed_module(self):
        resolver = HandlerResolver(allowed_prefixes=("myproject.vertices",))
        with pytest.raises(HandlerResolutionError, match="blocked"):
            resolver.resolve("os.path.join")

    def test_prefix_allows_matching_module(self):
        resolver = HandlerResolver(allowed_prefixes=("honey_badgeria.",))
        # This should pass the prefix check but may fail on actual import
        # because we're pointing at a real module
        try:
            resolver.resolve("honey_badgeria.back.graph.vertex.Vertex")
        except HandlerResolutionError as exc:
            # It passed the prefix check — might fail on callable check
            assert "blocked" not in str(exc)

    def test_multiple_prefixes(self):
        resolver = HandlerResolver(allowed_prefixes=("pkg_a.", "pkg_b."))
        with pytest.raises(HandlerResolutionError, match="blocked"):
            resolver.resolve("pkg_c.module.fn")


# ---------------------------------------------------------------------------
# VertexRegistry — idempotent registration
# ---------------------------------------------------------------------------

from honey_badgeria.back.registry.vertex_registry import VertexRegistry
from honey_badgeria.core.exceptions import VertexAlreadyExistsError


class TestVertexRegistryIdempotent:
    """Registering the same callable twice is a no-op (Principle 8)."""

    def test_same_handler_is_idempotent(self):
        reg = VertexRegistry()
        fn = lambda: {"x": 1}
        reg.register("v", fn)
        # Same callable — no error
        reg.register("v", fn)
        assert reg.get("v") is fn

    def test_different_handler_raises(self):
        reg = VertexRegistry()
        reg.register("v", lambda: {"x": 1})
        with pytest.raises(VertexAlreadyExistsError):
            reg.register("v", lambda: {"x": 2})


# ---------------------------------------------------------------------------
# ModuleHealthChecker
# ---------------------------------------------------------------------------

from honey_badgeria.back.discovery.health_checker import ModuleHealthChecker


class TestModuleHealthChecker:
    """Tests for ModuleHealthChecker (Principle 7)."""

    def test_check_module_sizes_clean(self, tmp_path):
        """No issues when files are small."""
        (tmp_path / "small.py").write_text("x = 1\n" * 10)
        checker = ModuleHealthChecker(root=str(tmp_path), max_lines=300)
        issues = checker.check_module_sizes()
        assert len(issues) == 0

    def test_check_module_sizes_over_limit(self, tmp_path):
        """Flags files exceeding max_lines."""
        (tmp_path / "big.py").write_text("x = 1\n" * 400)
        checker = ModuleHealthChecker(root=str(tmp_path), max_lines=300)
        issues = checker.check_module_sizes()
        assert len(issues) == 1
        assert issues[0]["code"] == "MODULE_TOO_LARGE"
        assert issues[0]["severity"] == "warning"
        assert "big.py" in issues[0]["message"]

    def test_check_duplicate_handlers_clean(self, tmp_path):
        """No issues when handler names are unique."""
        (tmp_path / "a.py").write_text(textwrap.dedent("""\
            from honey_badgeria.decorators import vertex

            @vertex
            def handler_a():
                return {"x": 1}
        """))
        (tmp_path / "b.py").write_text(textwrap.dedent("""\
            from honey_badgeria.decorators import vertex

            @vertex
            def handler_b():
                return {"y": 2}
        """))
        checker = ModuleHealthChecker(root=str(tmp_path))
        issues = checker.check_duplicate_handlers()
        assert len(issues) == 0

    def test_check_duplicate_handlers_detects_dupes(self, tmp_path):
        """Flags duplicate @vertex names across files."""
        content = textwrap.dedent("""\
            from honey_badgeria.decorators import vertex

            @vertex
            def my_handler():
                return {"x": 1}
        """)
        (tmp_path / "file1.py").write_text(content)
        (tmp_path / "file2.py").write_text(content)
        checker = ModuleHealthChecker(root=str(tmp_path))
        issues = checker.check_duplicate_handlers()
        assert len(issues) == 1
        assert issues[0]["code"] == "DUPLICATE_HANDLER"
        assert "my_handler" in issues[0]["message"]

    def test_check_circular_imports_clean(self, tmp_path):
        """No circular dependency issues."""
        (tmp_path / "a.py").write_text("import os\n")
        (tmp_path / "b.py").write_text("import sys\n")
        checker = ModuleHealthChecker(root=str(tmp_path))
        issues = checker.check_circular_imports()
        assert len(issues) == 0

    def test_check_circular_imports_detects_cycle(self):
        """The internal _find_cycles detects a cycle in a directed graph."""
        graph = {
            "a": {"b"},
            "b": {"c"},
            "c": {"a"},  # cycle: a → b → c → a
        }
        cycles = ModuleHealthChecker._find_cycles(graph)
        assert len(cycles) >= 1
        # Verify the cycle contains all three nodes
        cycle_nodes = set()
        for cycle in cycles:
            cycle_nodes.update(cycle)
        assert {"a", "b", "c"}.issubset(cycle_nodes)

    def test_run_combines_all_checks(self, tmp_path):
        """run() returns issues from all checks."""
        (tmp_path / "big.py").write_text("x = 1\n" * 400)
        checker = ModuleHealthChecker(root=str(tmp_path), max_lines=300)
        issues = checker.run()
        codes = {i["code"] for i in issues}
        assert "MODULE_TOO_LARGE" in codes

    def test_nonexistent_root(self):
        """No crash when root doesn't exist."""
        checker = ModuleHealthChecker(root="/nonexistent/path")
        issues = checker.run()
        assert issues == []

    def test_syntax_error_file_skipped(self, tmp_path):
        """Files with syntax errors are skipped, not crashed."""
        (tmp_path / "broken.py").write_text("def foo( :\n")
        checker = ModuleHealthChecker(root=str(tmp_path))
        # Should not raise
        issues = checker.run()
        # No crash — that's the assertion


# ---------------------------------------------------------------------------
# Executor — cache skipping for side-effect vertices
# ---------------------------------------------------------------------------

from honey_badgeria.back.runtime.executor import GraphExecutor


class TestExecutorSideEffectCaching:
    """Side-effect vertices must never be served from cache."""

    def test_pure_vertex_uses_cache(self, tmp_path):
        """Pure vertex results are cached on second run."""
        call_count = {"n": 0}

        def counting_handler():
            call_count["n"] += 1
            return {"v": call_count["n"]}

        g = Graph()
        g.add_vertex(Vertex("v", handler=counting_handler, effect=PURE))

        executor1 = GraphExecutor(g, cache_enabled=True, settings=Settings(
            CACHE_ENABLED=True, CACHE_DIR=str(tmp_path),
        ))
        result1 = executor1.execute()
        assert result1["v.v"] == 1

        # Second execution with same graph — cache hit
        executor2 = GraphExecutor(g, cache_enabled=True, settings=Settings(
            CACHE_ENABLED=True, CACHE_DIR=str(tmp_path),
        ))
        result2 = executor2.execute()
        assert result2["v.v"] == 1  # cached, handler not called again
        assert call_count["n"] == 1

    def test_side_effect_vertex_never_cached(self, tmp_path):
        """Side-effect vertices always re-execute."""
        call_count = {"n": 0}

        def counting_handler():
            call_count["n"] += 1
            return {"v": call_count["n"]}

        g = Graph()
        g.add_vertex(Vertex("v", handler=counting_handler, effect=SIDE_EFFECT))

        executor1 = GraphExecutor(g, cache_enabled=True, settings=Settings(
            CACHE_ENABLED=True, CACHE_DIR=str(tmp_path),
        ))
        result1 = executor1.execute()
        assert result1["v.v"] == 1

        # Second execution — handler must be called again
        executor2 = GraphExecutor(g, cache_enabled=True, settings=Settings(
            CACHE_ENABLED=True, CACHE_DIR=str(tmp_path),
        ))
        result2 = executor2.execute()
        assert result2["v.v"] == 2
        assert call_count["n"] == 2


# ---------------------------------------------------------------------------
# Executor — contract enforcement
# ---------------------------------------------------------------------------

from honey_badgeria.core.exceptions import ContractOutputError


class TestExecutorContractEnforcement:
    """Executor enforces contracts when outputs are declared."""

    def test_valid_outputs_pass(self):
        def handler():
            return {"greeting": "hello"}

        g = Graph()
        g.add_vertex(Vertex("v", handler=handler, outputs={"greeting": "str"}))
        executor = GraphExecutor(g)
        result = executor.execute()
        assert result["v.greeting"] == "hello"

    def test_wrong_output_type_raises(self):
        def handler():
            return {"count": "not_an_int"}

        g = Graph()
        g.add_vertex(Vertex("v", handler=handler, outputs={"count": "int"}))
        executor = GraphExecutor(g)
        with pytest.raises(ContractOutputError):
            executor.execute()

    def test_missing_output_key_raises(self):
        def handler():
            return {"wrong_key": 42}

        g = Graph()
        g.add_vertex(Vertex("v", handler=handler, outputs={"expected_key": "int"}))
        executor = GraphExecutor(g)
        with pytest.raises(ContractOutputError):
            executor.execute()


# ---------------------------------------------------------------------------
# Runner — async_enabled fix
# ---------------------------------------------------------------------------

import asyncio


class TestRunnerAsyncEnabledFix:
    """async_enabled=False must actually disable async (bug fix test)."""

    def test_async_enabled_false_stays_false(self):
        def handler():
            return {"ok": True}

        g = Graph()
        g.add_vertex(Vertex("v", handler=handler))
        # Explicitly pass async_enabled=False
        result = run_flow(g, async_enabled=False)
        assert result["v.ok"] is True

    def test_async_enabled_none_defaults_to_settings(self):
        """When None, should use Settings default (False)."""
        def handler():
            return {"ok": True}

        g = Graph()
        g.add_vertex(Vertex("v", handler=handler))
        result = run_flow(g, async_enabled=None)
        assert result["v.ok"] is True
