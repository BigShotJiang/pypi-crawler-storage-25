"""Tests for testing utilities (GraphFactory, FlowTester, VertexMock)."""

import pytest
from honey_badgeria.testing import GraphFactory, FlowTester, VertexMock, StageRunner
from honey_badgeria.back.graph.vertex import Vertex
from honey_badgeria.back.graph.edge import Edge


class TestGraphFactory:

    def test_create_from_dicts(self):
        g = GraphFactory.create(
            vertices=[
                {"name": "a", "handler": None},
                {"name": "b", "handler": None},
            ],
            edges=[("a", "b")],
        )
        assert g.has_vertex("a")
        assert g.has_vertex("b")
        assert len(g.edges) == 1

    def test_create_from_objects(self):
        g = GraphFactory.create(
            vertices=[Vertex("x"), Vertex("y")],
            edges=[Edge("x", "y")],
        )
        assert g.has_vertex("x")

    def test_create_with_flows(self):
        g = GraphFactory.create(
            vertices=[{"name": "start"}],
            flows={"main": {"entry": "start"}},
        )
        assert "main" in g.flows

    def test_linear_factory(self):
        g = GraphFactory.linear(["a", "b", "c"])
        assert g.has_vertex("a")
        assert g.has_vertex("b")
        assert g.has_vertex("c")
        assert len(g.edges) == 2

    def test_linear_with_handlers(self):
        def h():
            return {}
        g = GraphFactory.linear(["a", "b"], handlers={"a": h})
        assert g.get_vertex("a").handler is h


class TestVertexMock:

    def test_basic_mock(self):
        mock = VertexMock(return_value={"x": 1})
        result = mock(a=10, b=20)
        assert result == {"x": 1}
        assert mock.call_count == 1
        assert mock.last_call == {"a": 10, "b": 20}

    def test_multiple_calls(self):
        mock = VertexMock()
        mock(x=1)
        mock(x=2)
        mock(x=3)
        assert mock.call_count == 3
        assert mock.called is True

    def test_side_effect_callable(self):
        def effect(**kwargs):
            return {"doubled": kwargs.get("x", 0) * 2}

        mock = VertexMock(side_effect=effect)
        result = mock(x=5)
        assert result == {"doubled": 10}

    def test_side_effect_exception(self):
        mock = VertexMock(side_effect=ValueError("boom"))
        with pytest.raises(ValueError, match="boom"):
            mock()

    def test_reset(self):
        mock = VertexMock()
        mock(x=1)
        mock.reset()
        assert mock.call_count == 0
        assert mock.called is False


class TestFlowTester:

    def test_simple_flow(self):
        def source():
            return {"data": [1, 2, 3]}

        g = GraphFactory.create(
            vertices=[{"name": "source", "handler": "source"}],
        )
        tester = FlowTester(g, handlers={"source": source})
        result = tester.run()
        assert result["source.data"] == [1, 2, 3]

    def test_chained_flow(self):
        def step1():
            return {"value": 10}

        def step2(value):
            return {"result": value + 5}

        g = GraphFactory.create(
            vertices=[
                {"name": "step1", "handler": "step1"},
                {"name": "step2", "handler": "step2", "inputs": {"value": "step1.value"}},
            ],
            edges=[("step1", "step2")],
        )
        tester = FlowTester(g, handlers={"step1": step1, "step2": step2})
        result = tester.run()
        assert result["step2.result"] == 15

    def test_flow_with_mocks(self):
        mock_source = VertexMock(return_value={"data": "mocked"})
        mock_process = VertexMock(return_value={"result": "done"})

        g = GraphFactory.create(
            vertices=[
                {"name": "source", "handler": "source"},
                {"name": "process", "handler": "process", "inputs": {"data": "source.data"}},
            ],
            edges=[("source", "process")],
        )
        tester = FlowTester(g, handlers={"source": mock_source, "process": mock_process})
        result = tester.run()

        assert mock_source.call_count == 1
        assert mock_process.call_count == 1
        assert result["process.result"] == "done"


class TestStageRunner:

    def test_run_single_vertex(self):
        def handler():
            return {"value": 42}

        vertex = Vertex("v1", handler=handler)
        runner = StageRunner()
        result = runner.run_vertex(vertex)
        assert result == {"value": 42}

    def test_run_with_initial_data(self):
        def handler(x):
            return {"y": x + 1}

        vertex = Vertex("v1", handler=handler, inputs={"x": "seed.x"})
        runner = StageRunner()
        result = runner.run_vertex(vertex, initial_data={"seed.x": 10})
        assert result == {"y": 11}
