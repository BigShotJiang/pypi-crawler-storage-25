"""Tests for AI logger and event types."""

from honey_badgeria.logging.ai_logger import AILogger
from honey_badgeria.logging.event_types import EventType


class TestEventType:

    def test_event_types_exist(self):
        assert EventType.GRAPH_LOADED == "graph.loaded"
        assert EventType.VERTEX_STARTED == "vertex.started"
        assert EventType.FLOW_COMPLETED == "flow.completed"
        assert EventType.CACHE_HIT == "cache.hit"


class TestAILogger:

    def test_log_event(self):
        logger = AILogger()
        logger.log(EventType.GRAPH_LOADED, {"file": "graph.yaml"})
        events = logger.get_events()
        assert len(events) == 1
        assert events[0]["event"] == "graph.loaded"

    def test_vertex_events(self):
        logger = AILogger()
        logger.vertex_started("my_vertex")
        logger.vertex_completed("my_vertex", result_keys=["output_a"])
        events = logger.get_events()
        assert len(events) == 2
        assert events[0]["event"] == EventType.VERTEX_STARTED
        assert events[1]["data"]["output_keys"] == ["output_a"]

    def test_flow_events(self):
        logger = AILogger()
        logger.flow_started("pipeline")
        logger.flow_completed("pipeline")
        events = logger.get_events()
        assert events[0]["data"]["flow"] == "pipeline"

    def test_clear(self):
        logger = AILogger()
        logger.log("test", {})
        logger.clear()
        assert len(logger.get_events()) == 0

    def test_events_have_timestamps(self):
        logger = AILogger()
        logger.log("test", {})
        events = logger.get_events()
        assert "timestamp" in events[0]
