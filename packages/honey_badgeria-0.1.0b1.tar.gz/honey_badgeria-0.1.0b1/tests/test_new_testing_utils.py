"""Tests for new testing utilities added in the typing/exceptions pass.

Covers:
- VertexMock.with_sequence / VertexMock.failing
- AsyncVertexMock (basic, sequence, failing)
- FlowTestResult assertion helpers
- GraphFactory.diamond
- handler_stub, edge_stub, vertex_stub
- ResponseInjector
"""

import pytest
import asyncio

from honey_badgeria.testing import GraphFactory, FlowTester, VertexMock
from honey_badgeria.testing.vertex_mock import AsyncVertexMock
from honey_badgeria.testing.stubs import (
    handler_stub,
    edge_stub,
    vertex_stub,
    ResponseInjector,
)
from honey_badgeria.testing.flow_tester import FlowTestResult
from honey_badgeria.back.runtime.data_store import DataStore


# ======================================================================
# VertexMock.with_sequence
# ======================================================================


class TestVertexMockSequence:

    def test_returns_successive_values(self):
        mock = VertexMock.with_sequence(
            {"step": 1},
            {"step": 2},
            {"step": 3},
        )
        assert mock()["step"] == 1
        assert mock()["step"] == 2
        assert mock()["step"] == 3

    def test_repeats_last_value_on_overflow(self):
        mock = VertexMock.with_sequence({"val": "a"}, {"val": "b"})
        mock()
        mock()
        assert mock()["val"] == "b"

    def test_tracks_calls(self):
        mock = VertexMock.with_sequence({"x": 1})
        mock(input=10)
        assert mock.call_count == 1
        assert mock.last_call == {"input": 10}

    def test_reset_restarts_sequence(self):
        mock = VertexMock.with_sequence({"n": 1}, {"n": 2})
        mock()
        mock()
        mock.reset()
        assert mock()["n"] == 1


# ======================================================================
# VertexMock.failing
# ======================================================================


class TestVertexMockFailing:

    def test_raises_default_error(self):
        mock = VertexMock.failing()
        with pytest.raises(RuntimeError, match="vertex failed"):
            mock()

    def test_raises_custom_error(self):
        mock = VertexMock.failing(ValueError("custom boom"))
        with pytest.raises(ValueError, match="custom boom"):
            mock()


# ======================================================================
# AsyncVertexMock
# ======================================================================


class TestAsyncVertexMock:

    @pytest.mark.anyio
    async def test_basic_async(self):
        mock = AsyncVertexMock(return_value={"result": 99})
        result = await mock(x=1)
        assert result == {"result": 99}
        assert mock.call_count == 1
        assert mock.last_call == {"x": 1}

    @pytest.mark.anyio
    async def test_async_sequence(self):
        mock = AsyncVertexMock.with_sequence({"n": 1}, {"n": 2})
        r1 = await mock()
        r2 = await mock()
        assert r1["n"] == 1
        assert r2["n"] == 2

    @pytest.mark.anyio
    async def test_async_failing(self):
        mock = AsyncVertexMock.failing(ValueError("async boom"))
        with pytest.raises(ValueError, match="async boom"):
            await mock()

    @pytest.mark.anyio
    async def test_async_default_fail(self):
        mock = AsyncVertexMock.failing()
        with pytest.raises(RuntimeError, match="async vertex failed"):
            await mock()

    @pytest.mark.anyio
    async def test_async_side_effect_callable(self):
        def effect(**kwargs):
            return {"doubled": kwargs["x"] * 2}

        mock = AsyncVertexMock(side_effect=effect)
        result = await mock(x=5)
        assert result == {"doubled": 10}

    @pytest.mark.anyio
    async def test_async_reset(self):
        mock = AsyncVertexMock(return_value={"ok": True})
        await mock()
        await mock()
        assert mock.call_count == 2
        mock.reset()
        assert mock.call_count == 0
        assert mock.called is False


# ======================================================================
# FlowTestResult
# ======================================================================


class TestFlowTestResult:

    def test_getitem(self):
        result = FlowTestResult({"a.x": 1, "b.y": 2})
        assert result["a.x"] == 1

    def test_contains(self):
        result = FlowTestResult({"a.x": 1})
        assert "a.x" in result
        assert "z" not in result

    def test_assert_has_key_passes(self):
        result = FlowTestResult({"a.x": 1})
        ret = result.assert_has_key("a.x")
        assert ret is result  # chainable

    def test_assert_has_key_fails(self):
        result = FlowTestResult({"a.x": 1})
        with pytest.raises(AssertionError, match="Expected key 'z'"):
            result.assert_has_key("z")

    def test_assert_output_passes(self):
        result = FlowTestResult({"a.x": 42})
        ret = result.assert_output("a.x", 42)
        assert ret is result

    def test_assert_output_wrong_value(self):
        result = FlowTestResult({"a.x": 42})
        with pytest.raises(AssertionError, match="got 42"):
            result.assert_output("a.x", 99)

    def test_assert_output_missing_key(self):
        result = FlowTestResult({})
        with pytest.raises(AssertionError, match="Expected key"):
            result.assert_output("a.x", 1)

    def test_chained_assertions(self):
        result = FlowTestResult({"a.x": 1, "b.y": "hello"})
        result.assert_has_key("a.x").assert_output("b.y", "hello")

    def test_assert_vertex_ran(self):
        """Integration: run a real flow and check assert_vertex_ran."""
        g = GraphFactory.create(
            vertices=[{"name": "source", "handler": "source"}],
        )
        mock = VertexMock(return_value={"data": "ok"})
        tester = FlowTester(g, handlers={"source": mock})
        result = tester.run()
        ret = result.assert_vertex_ran("source", tester)
        assert ret is result

    def test_assert_flow_completed(self):
        g = GraphFactory.create(
            vertices=[{"name": "v1", "handler": "v1"}],
        )
        mock = VertexMock(return_value={"out": 1})
        tester = FlowTester(g, handlers={"v1": mock})
        result = tester.run()
        ret = result.assert_flow_completed(tester)
        assert ret is result


# ======================================================================
# GraphFactory.diamond
# ======================================================================


class TestGraphFactoryDiamond:

    def test_diamond_default_names(self):
        g = GraphFactory.diamond()
        for name in ["A", "B", "C", "D"]:
            assert g.has_vertex(name)
        assert len(g.edges) == 4

    def test_diamond_custom_names(self):
        g = GraphFactory.diamond(
            top="start",
            left="left",
            right="right",
            bottom="end",
        )
        assert g.has_vertex("start")
        assert g.has_vertex("end")

    def test_diamond_with_handlers(self):
        def my_handler():
            return {}

        g = GraphFactory.diamond(handlers={"A": my_handler})
        assert g.get_vertex("A").handler is my_handler


# ======================================================================
# handler_stub
# ======================================================================


class TestHandlerStub:

    def test_fixed_kwargs(self):
        h = handler_stub(username="alice", active=True)
        result = h()
        assert result == {"username": "alice", "active": True}

    def test_return_value_overrides(self):
        h = handler_stub(return_value={"custom": 42})
        assert h() == {"custom": 42}

    def test_ignores_inputs(self):
        h = handler_stub(x=1)
        assert h(anything="whatever") == {"x": 1}

    def test_returns_copy(self):
        h = handler_stub(x=1)
        r1 = h()
        r2 = h()
        assert r1 == r2
        assert r1 is not r2  # must be a fresh dict each time


# ======================================================================
# edge_stub
# ======================================================================


class TestEdgeStub:

    def test_creates_edge(self):
        e = edge_stub("a", "b")
        assert e.source == "a"
        assert e.target == "b"


# ======================================================================
# vertex_stub
# ======================================================================


class TestVertexStub:

    def test_creates_vertex(self):
        v = vertex_stub("my_vertex")
        assert v.name == "my_vertex"
        assert v.handler is None

    def test_with_handler(self):
        def h():
            return {}
        v = vertex_stub("v", handler=h)
        assert v.handler is h

    def test_with_inputs_outputs(self):
        v = vertex_stub(
            "v",
            inputs={"x": "a.x"},
            outputs={"y": "str"},
        )
        assert v.inputs == {"x": "a.x"}
        assert v.outputs == {"y": "str"}


# ======================================================================
# ResponseInjector
# ======================================================================


class TestResponseInjector:

    def test_inject_single_key(self):
        store = DataStore()
        inj = ResponseInjector(store)
        inj.inject("user.name", "Alice")
        assert store.get_output("user.name") == "Alice"

    def test_chainable(self):
        inj = ResponseInjector()
        ret = inj.inject("a", 1).inject("b", 2)
        assert ret is inj
        assert inj.store.get_output("a") == 1
        assert inj.store.get_output("b") == 2

    def test_inject_vertex_outputs(self):
        inj = ResponseInjector()
        inj.inject_vertex_outputs("user", {"name": "Bob", "age": 30})
        assert inj.store.get_output("user.name") == "Bob"
        assert inj.store.get_output("user.age") == 30

    def test_from_dict(self):
        inj = ResponseInjector.from_dict({
            "a.x": 10,
            "b.y": "hello",
        })
        assert inj.store.get_output("a.x") == 10
        assert inj.store.get_output("b.y") == "hello"

    def test_default_store(self):
        inj = ResponseInjector()
        assert isinstance(inj.store, DataStore)
