"""Tests for VertexContract."""

import pytest
from honey_badgeria.back.contracts.contract import VertexContract
from honey_badgeria.core.exceptions import ContractInputError, ContractOutputError


class TestVertexContract:

    def test_empty_contract(self):
        c = VertexContract()
        assert c.inputs == {}
        assert c.outputs == {}

    def test_validate_output_valid(self):
        c = VertexContract(outputs={"name": "str", "age": "int"})
        c.validate_output({"name": "Alice", "age": 30})

    def test_validate_output_missing_key(self):
        c = VertexContract(outputs={"name": "str", "age": "int"})
        with pytest.raises(ContractOutputError, match="Missing output"):
            c.validate_output({"name": "Alice"})

    def test_validate_output_wrong_type(self):
        c = VertexContract(outputs={"name": "str"})
        with pytest.raises(ContractOutputError, match="expected str"):
            c.validate_output({"name": 42})

    def test_validate_output_non_dict(self):
        """Non-dict results are silently skipped."""
        c = VertexContract(outputs={"x": "str"})
        c.validate_output("not a dict")  # should not raise

    def test_validate_input_valid(self):
        c = VertexContract(inputs={"x": "int", "y": "float"})
        c.validate_input({"x": 10, "y": 3.14})

    def test_validate_input_missing(self):
        c = VertexContract(inputs={"x": "int"})
        with pytest.raises(ContractInputError, match="Missing input"):
            c.validate_input({})

    def test_validate_input_wrong_type(self):
        c = VertexContract(inputs={"x": "int"})
        with pytest.raises(ContractInputError, match="expected int"):
            c.validate_input({"x": "not an int"})

    def test_unknown_type_skipped(self):
        """Unknown type strings (like data references) are skipped."""
        c = VertexContract(inputs={"x": "vertex_a.output_x"})
        # Should not raise even though value doesn't match a type
        c.validate_input({"x": "anything"})

    def test_all_supported_types(self):
        c = VertexContract(outputs={
            "s": "str",
            "i": "int",
            "f": "float",
            "b": "bool",
            "d": "dict",
            "l": "list",
        })
        c.validate_output({
            "s": "hello",
            "i": 42,
            "f": 3.14,
            "b": True,
            "d": {"key": "val"},
            "l": [1, 2, 3],
        })
