"""Tests for the cache layer: CacheManager, FileCacheStore, integration with executor."""

import json
import shutil
import pytest
from pathlib import Path

from honey_badgeria.back.graph import Graph, Vertex, Edge
from honey_badgeria.back.runtime.executor import GraphExecutor
from honey_badgeria.back.runtime.runner import run_flow
from honey_badgeria.back.runtime.cache.cache_manager import CacheManager
from honey_badgeria.back.runtime.cache.cache_store import FileCacheStore
from honey_badgeria.back.runtime.cache.hash_utils import compute_vertex_hash
from honey_badgeria.testing import GraphFactory
from honey_badgeria.conf.settings import Settings, configure, reset_settings


# ---------------------------------------------------------------------------
# hash_utils
# ---------------------------------------------------------------------------

class TestHashUtils:

    def test_deterministic_hash(self):
        h1 = compute_vertex_hash("v1", "handler_a", {"x": 1})
        h2 = compute_vertex_hash("v1", "handler_a", {"x": 1})
        assert h1 == h2

    def test_different_inputs_different_hash(self):
        h1 = compute_vertex_hash("v1", "handler_a", {"x": 1})
        h2 = compute_vertex_hash("v1", "handler_a", {"x": 2})
        assert h1 != h2

    def test_different_vertex_different_hash(self):
        h1 = compute_vertex_hash("v1", "handler_a", {"x": 1})
        h2 = compute_vertex_hash("v2", "handler_a", {"x": 1})
        assert h1 != h2

    def test_hash_is_hex_string(self):
        h = compute_vertex_hash("v1", "h", {})
        assert isinstance(h, str)
        assert len(h) == 64  # SHA-256


# ---------------------------------------------------------------------------
# FileCacheStore
# ---------------------------------------------------------------------------

class TestFileCacheStore:

    @pytest.fixture(autouse=True)
    def _cache_dir(self, tmp_path):
        self.cache_dir = tmp_path / "test_cache"
        self.store = FileCacheStore(str(self.cache_dir))

    def test_save_and_load(self):
        self.store.save("key1", {"result": 42})
        assert self.store.exists("key1")
        assert self.store.load("key1") == {"result": 42}

    def test_not_exists(self):
        assert not self.store.exists("nonexistent")

    def test_overwrite(self):
        self.store.save("key1", {"a": 1})
        self.store.save("key1", {"a": 2})
        assert self.store.load("key1") == {"a": 2}

    def test_creates_directory(self):
        assert not self.cache_dir.exists()
        self.store.save("key1", {})
        assert self.cache_dir.exists()


# ---------------------------------------------------------------------------
# CacheManager
# ---------------------------------------------------------------------------

class TestCacheManager:

    @pytest.fixture(autouse=True)
    def _cache(self, tmp_path):
        self.cache_dir = tmp_path / "cm_cache"
        self.cm = CacheManager(str(self.cache_dir))

    def test_build_key(self):
        v = Vertex("v1", handler="handler_a")
        key = self.cm.build_key(v, {"x": 1})
        assert isinstance(key, str)
        assert len(key) == 64

    def test_save_and_load(self):
        v = Vertex("v1", handler="h")
        key = self.cm.build_key(v, {})
        self.cm.save(key, {"result": 99})
        loaded = self.cm.load(key)
        assert loaded == {"result": 99}

    def test_miss_returns_none(self):
        assert self.cm.load("nonexistent") is None

    def test_info_empty(self):
        info = self.cm.info()
        assert info["entries"] == 0
        assert info["size_bytes"] == 0

    def test_info_with_entries(self):
        self.cm.save("k1", {"a": 1})
        self.cm.save("k2", {"b": 2})
        info = self.cm.info()
        assert info["entries"] == 2
        assert info["size_bytes"] > 0

    def test_list_keys(self):
        self.cm.save("key_alpha", {"a": 1})
        self.cm.save("key_beta", {"b": 2})
        keys = self.cm.list_keys()
        assert set(keys) == {"key_alpha", "key_beta"}

    def test_prune(self):
        import time
        self.cm.save("old", {"old": True})
        time.sleep(0.01)
        self.cm.save("new", {"new": True})
        removed = self.cm.prune(max_entries=1)
        assert removed == 1
        assert self.cm.load("new") is not None

    def test_prune_no_action(self):
        self.cm.save("k1", {})
        removed = self.cm.prune(max_entries=10)
        assert removed == 0

    def test_clear(self):
        self.cm.save("k1", {})
        self.cm.save("k2", {})
        self.cm.clear()
        assert self.cm.info()["entries"] == 0


# ---------------------------------------------------------------------------
# Cache integration with GraphExecutor
# ---------------------------------------------------------------------------

class TestCacheIntegration:
    """Cache integrated into the executor via CACHE_ENABLED setting."""

    @pytest.fixture(autouse=True)
    def _setup(self, tmp_path):
        reset_settings()
        self.cache_dir = str(tmp_path / "exec_cache")
        configure(Settings(CACHE_ENABLED=True, CACHE_DIR=self.cache_dir))
        yield
        reset_settings()

    def test_executor_caches_result(self):
        call_count = 0

        def counter():
            nonlocal call_count
            call_count += 1
            return {"n": call_count}

        g = GraphFactory.create(vertices=[{"name": "c", "handler": counter}])

        # First execution → calls handler
        ex1 = GraphExecutor(g)
        r1 = ex1.execute()
        assert r1["c.n"] == 1
        assert call_count == 1

        # Second execution → should hit cache
        ex2 = GraphExecutor(g)
        r2 = ex2.execute()
        assert r2["c.n"] == 1  # same result
        assert call_count == 1  # handler NOT called again

    def test_cache_disabled_forces_reexecution(self):
        call_count = 0

        def counter():
            nonlocal call_count
            call_count += 1
            return {"n": call_count}

        g = GraphFactory.create(vertices=[{"name": "c", "handler": counter}])

        # Cache disabled → always re-executes
        ex1 = GraphExecutor(g, cache_enabled=False)
        ex1.execute()
        assert call_count == 1

        ex2 = GraphExecutor(g, cache_enabled=False)
        ex2.execute()
        assert call_count == 2  # called again

    def test_different_inputs_no_cache_hit(self):
        call_count = 0

        def process(x):
            nonlocal call_count
            call_count += 1
            return {"result": x * 2}

        g = GraphFactory.create(
            vertices=[{"name": "p", "handler": process, "inputs": {"x": "x"}}],
        )

        ex1 = GraphExecutor(g)
        ex1.execute(initial_data={"x": 5})
        assert call_count == 1

        ex2 = GraphExecutor(g)
        ex2.execute(initial_data={"x": 10})  # different input
        assert call_count == 2  # cache miss

    def test_cache_with_chained_pipeline(self):
        call_counts = {"a": 0, "b": 0}

        def step_a():
            call_counts["a"] += 1
            return {"value": 10}

        def step_b(value):
            call_counts["b"] += 1
            return {"result": value + 5}

        g = GraphFactory.create(
            vertices=[
                {"name": "a", "handler": step_a},
                {"name": "b", "handler": step_b, "inputs": {"value": "a.value"}},
            ],
            edges=[("a", "b")],
        )

        # First run
        r1 = GraphExecutor(g).execute()
        assert r1["b.result"] == 15
        assert call_counts == {"a": 1, "b": 1}

        # Second run with cache
        r2 = GraphExecutor(g).execute()
        assert r2["b.result"] == 15
        assert call_counts == {"a": 1, "b": 1}  # both cached

    def test_run_flow_with_cache(self):
        counter = {"n": 0}

        def inc():
            counter["n"] += 1
            return {"v": counter["n"]}

        g = GraphFactory.create(vertices=[{"name": "i", "handler": inc}])
        r1 = run_flow(g, cache_enabled=True)
        r2 = run_flow(g, cache_enabled=True)
        assert r1["i.v"] == r2["i.v"]
        assert counter["n"] == 1

    def test_cache_with_parallel(self):
        """Cache works correctly even with parallel execution."""
        calls = {"a": 0, "b": 0}

        def source():
            return {"value": 1}

        def branch_a(value):
            calls["a"] += 1
            return {"result": value + 1}

        def branch_b(value):
            calls["b"] += 1
            return {"result": value + 2}

        g = Graph()
        g.add_vertex(Vertex("src", handler=source))
        g.add_vertex(Vertex("a", handler=branch_a, inputs={"value": "src.value"}))
        g.add_vertex(Vertex("b", handler=branch_b, inputs={"value": "src.value"}))
        g.add_edge(Edge("src", "a"))
        g.add_edge(Edge("src", "b"))

        r1 = GraphExecutor(g, parallel_enabled=True).execute()
        assert calls == {"a": 1, "b": 1}

        # Second run → cached
        r2 = GraphExecutor(g, parallel_enabled=True).execute()
        assert r2["a.result"] == r1["a.result"]
        assert calls == {"a": 1, "b": 1}  # not called again
