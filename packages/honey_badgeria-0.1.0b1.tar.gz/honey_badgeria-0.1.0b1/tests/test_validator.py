"""Tests for GraphValidator."""

import pytest
from honey_badgeria.back.graph.graph import Graph
from honey_badgeria.back.graph.vertex import Vertex
from honey_badgeria.back.graph.edge import Edge
from honey_badgeria.back.graph.validator import GraphValidator
from honey_badgeria.core.exceptions import GraphValidationError


class TestGraphValidator:

    def test_valid_graph(self):
        g = Graph()
        g.add_vertex(Vertex("a"))
        g.add_vertex(Vertex("b"))
        g.add_edge(Edge("a", "b"))
        validator = GraphValidator(g)
        validator.validate()  # should not raise

    def test_edge_unknown_source(self):
        g = Graph()
        g.add_vertex(Vertex("b"))
        g.add_edge(Edge("nonexistent", "b"))
        with pytest.raises(GraphValidationError, match="unknown source"):
            GraphValidator(g).validate()

    def test_edge_unknown_target(self):
        g = Graph()
        g.add_vertex(Vertex("a"))
        g.add_edge(Edge("a", "nonexistent"))
        with pytest.raises(GraphValidationError, match="unknown target"):
            GraphValidator(g).validate()

    def test_cycle_detected(self):
        g = Graph()
        g.add_vertex(Vertex("a"))
        g.add_vertex(Vertex("b"))
        g.add_edge(Edge("a", "b"))
        g.add_edge(Edge("b", "a"))
        with pytest.raises(GraphValidationError, match="cycle"):
            GraphValidator(g).validate()

    def test_no_source_vertices(self):
        """A graph where every vertex has incoming edges (cycle)."""
        g = Graph()
        g.add_vertex(Vertex("a"))
        g.add_vertex(Vertex("b"))
        g.add_edge(Edge("a", "b"))
        g.add_edge(Edge("b", "a"))
        with pytest.raises(GraphValidationError):
            GraphValidator(g).validate()

    def test_empty_graph_valid(self):
        """An empty graph should pass (no edges to validate)."""
        g = Graph()
        validator = GraphValidator(g)
        # No sources, but also no edges - this is degenerate but OK
        # Actually, _validate_sources checks for sources. An empty graph has no sources.
        # Let's see what happens:
        with pytest.raises(GraphValidationError, match="no source"):
            validator.validate()

    def test_single_vertex_valid(self):
        g = Graph()
        g.add_vertex(Vertex("only"))
        GraphValidator(g).validate()  # should pass
