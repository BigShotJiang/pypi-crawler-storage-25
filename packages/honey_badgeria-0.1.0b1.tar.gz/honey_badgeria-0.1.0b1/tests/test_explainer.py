"""Tests for GraphExplainer."""

from honey_badgeria.back.graph.graph import Graph
from honey_badgeria.back.graph.vertex import Vertex
from honey_badgeria.back.graph.edge import Edge
from honey_badgeria.back.explain.graph_explainer import GraphExplainer


class TestGraphExplainer:

    def _make_graph(self):
        g = Graph()
        g.add_vertex(Vertex("a"))
        g.add_vertex(Vertex("b"))
        g.add_vertex(Vertex("c"))
        g.add_edge(Edge("a", "b"))
        g.add_edge(Edge("b", "c"))
        return g

    def test_explain_lines(self):
        explainer = GraphExplainer(self._make_graph())
        lines = explainer.explain_lines()
        text = "\n".join(lines)
        assert "Vertices: 3" in text
        assert "Edges: 2" in text
        assert "Stage" in text

    def test_to_dict(self):
        explainer = GraphExplainer(self._make_graph())
        d = explainer.to_dict()
        assert d["vertex_count"] == 3
        assert d["edge_count"] == 2
        assert d["sources"] == ["a"]
        assert d["sinks"] == ["c"]
        assert len(d["stages"]) == 3
        assert len(d["edges"]) == 2
