"""Tests for the new flow-centric DSL format.

The flow format uses ``flow:`` as the top-level key with vertices
defined inline and ``next:`` fields replacing explicit edges.
"""

import pytest

from honey_badgeria.back.loader.graph_builder import GraphBuilder
from honey_badgeria.back.dsl.validator import DSLValidator


class TestFlowFormatParsing:
    """Test GraphBuilder.from_dict with the new flow format."""

    def test_simple_linear_flow(self):
        data = {
            "flow": {
                "greet": {
                    "hello": {
                        "handler": "vertices.greetings.hello",
                        "effect": "pure",
                        "version": "1",
                        "outputs": {"greeting": "str"},
                        "next": ["shout"],
                    },
                    "shout": {
                        "handler": "vertices.greetings.shout",
                        "effect": "pure",
                        "version": "1",
                        "inputs": {"greeting": "hello.greeting"},
                        "outputs": {"result": "str"},
                    },
                }
            }
        }
        graph = GraphBuilder.from_dict(data)

        assert len(graph.vertices) == 2
        assert "hello" in graph.vertices
        assert "shout" in graph.vertices
        assert len(graph.edges) == 1
        assert graph.edges[0].source == "hello"
        assert graph.edges[0].target == "shout"

    def test_entry_point_auto_detected(self):
        data = {
            "flow": {
                "pipeline": {
                    "a": {"next": ["b"]},
                    "b": {"next": ["c"]},
                    "c": {},
                }
            }
        }
        graph = GraphBuilder.from_dict(data)

        assert "pipeline" in graph.flows
        assert graph.flows["pipeline"]["entry"] == "a"

    def test_diamond_flow(self):
        data = {
            "flow": {
                "diamond": {
                    "top": {"next": ["left", "right"]},
                    "left": {"next": ["bottom"]},
                    "right": {"next": ["bottom"]},
                    "bottom": {},
                }
            }
        }
        graph = GraphBuilder.from_dict(data)

        assert len(graph.vertices) == 4
        assert len(graph.edges) == 4

        edge_set = {(e.source, e.target) for e in graph.edges}
        assert ("top", "left") in edge_set
        assert ("top", "right") in edge_set
        assert ("left", "bottom") in edge_set
        assert ("right", "bottom") in edge_set

        assert graph.flows["diamond"]["entry"] == "top"

    def test_multiple_flows(self):
        data = {
            "flow": {
                "flow_a": {
                    "step1": {"next": ["step2"]},
                    "step2": {},
                },
                "flow_b": {
                    "alpha": {"next": ["beta"]},
                    "beta": {},
                },
            }
        }
        graph = GraphBuilder.from_dict(data)

        assert len(graph.vertices) == 4
        assert len(graph.flows) == 2
        assert graph.flows["flow_a"]["entry"] == "step1"
        assert graph.flows["flow_b"]["entry"] == "alpha"

    def test_vertex_attributes_preserved(self):
        data = {
            "flow": {
                "test": {
                    "fetch": {
                        "handler": "vertices.data.fetch",
                        "effect": "side_effect",
                        "version": "2",
                        "inputs": {"url": "str"},
                        "outputs": {"data": "dict"},
                        "next": ["process"],
                    },
                    "process": {
                        "handler": "vertices.data.process",
                        "effect": "pure",
                        "version": "1",
                        "inputs": {"data": "fetch.data"},
                        "outputs": {"result": "list"},
                    },
                }
            }
        }
        graph = GraphBuilder.from_dict(data)

        fetch = graph.get_vertex("fetch")
        assert fetch.handler == "vertices.data.fetch"
        assert fetch.effect == "side_effect"
        assert fetch.version == "2"

        process = graph.get_vertex("process")
        assert process.inputs == {"data": "fetch.data"}

    def test_next_as_single_string(self):
        """next can be a string instead of a list."""
        data = {
            "flow": {
                "simple": {
                    "a": {"next": "b"},
                    "b": {},
                }
            }
        }
        graph = GraphBuilder.from_dict(data)

        assert len(graph.edges) == 1
        assert graph.edges[0].source == "a"
        assert graph.edges[0].target == "b"

    def test_null_vertex_config(self):
        """Vertex with null config (just a name)."""
        data = {
            "flow": {
                "simple": {
                    "a": {"next": ["b"]},
                    "b": None,
                }
            }
        }
        graph = GraphBuilder.from_dict(data)

        assert "b" in graph.vertices
        assert graph.vertices["b"].effect == "pure"

    def test_single_vertex_flow(self):
        data = {
            "flow": {
                "solo": {
                    "only_step": {
                        "handler": "vertices.solo.step",
                        "effect": "pure",
                        "version": "1",
                    },
                }
            }
        }
        graph = GraphBuilder.from_dict(data)

        assert len(graph.vertices) == 1
        assert len(graph.edges) == 0
        assert graph.flows["solo"]["entry"] == "only_step"

    def test_atomic_groups_in_flow_format(self):
        data = {
            "flow": {
                "payment": {
                    "reserve": {"next": ["charge"]},
                    "charge": {"next": ["confirm"]},
                    "confirm": {},
                }
            },
            "atomic_groups": {
                "payment_txn": {
                    "vertices": ["reserve", "charge", "confirm"],
                    "on_failure": "rollback",
                    "no_cache": True,
                    "no_parallel": True,
                }
            },
        }
        graph = GraphBuilder.from_dict(data)

        assert "payment_txn" in graph.atomic_groups
        assert graph.atomic_groups["payment_txn"].vertices == [
            "reserve", "charge", "confirm"
        ]

    def test_no_duplicate_edges(self):
        """If same edge implied twice, only one should be added."""
        data = {
            "flow": {
                "f1": {
                    "shared_a": {"next": ["shared_b"]},
                    "shared_b": {},
                },
                "f2": {
                    "shared_a": {"next": ["shared_b"]},
                    "shared_b": {},
                },
            }
        }
        graph = GraphBuilder.from_dict(data)

        # shared_a → shared_b should appear only once
        edge_pairs = [(e.source, e.target) for e in graph.edges]
        assert edge_pairs.count(("shared_a", "shared_b")) == 1


class TestFlowFormatTopology:
    """Test that flow-format graphs work with topology operations."""

    def test_sources_and_sinks(self):
        data = {
            "flow": {
                "pipeline": {
                    "start": {"next": ["middle"]},
                    "middle": {"next": ["end"]},
                    "end": {},
                }
            }
        }
        graph = GraphBuilder.from_dict(data)

        sources = graph.get_sources()
        sinks = graph.get_sinks()
        assert [v.name for v in sources] == ["start"]
        assert [v.name for v in sinks] == ["end"]

    def test_adjacency_list(self):
        data = {
            "flow": {
                "test": {
                    "a": {"next": ["b", "c"]},
                    "b": {"next": ["d"]},
                    "c": {"next": ["d"]},
                    "d": {},
                }
            }
        }
        graph = GraphBuilder.from_dict(data)
        adj = graph.adjacency_list()

        assert set(adj["a"]) == {"b", "c"}
        assert adj["b"] == ["d"]
        assert adj["c"] == ["d"]
        assert adj["d"] == []

    def test_execution_stages(self):
        from honey_badgeria.back.topology import GraphTopology

        data = {
            "flow": {
                "test": {
                    "a": {"next": ["b", "c"]},
                    "b": {"next": ["d"]},
                    "c": {"next": ["d"]},
                    "d": {},
                }
            }
        }
        graph = GraphBuilder.from_dict(data)
        topo = GraphTopology(graph)
        stages = topo.execution_stages()

        assert len(stages) == 3
        assert [v.name for v in stages[0]] == ["a"]
        assert set(v.name for v in stages[1]) == {"b", "c"}
        assert [v.name for v in stages[2]] == ["d"]


class TestFlowFormatValidation:
    """Test DSLValidator with the new flow format."""

    def test_valid_flow_format(self):
        data = {
            "flow": {
                "greet": {
                    "hello": {
                        "handler": "h.hello",
                        "next": ["shout"],
                    },
                    "shout": {
                        "handler": "h.shout",
                    },
                }
            }
        }
        errors = DSLValidator().validate(data)
        assert errors == []

    def test_next_references_unknown_vertex(self):
        data = {
            "flow": {
                "test": {
                    "a": {"next": ["nonexistent"]},
                }
            }
        }
        errors = DSLValidator().validate(data)
        assert any("nonexistent" in e for e in errors)

    def test_flow_must_be_dict(self):
        data = {"flow": "not a dict"}
        errors = DSLValidator().validate(data)
        assert any("dict" in e for e in errors)

    def test_flow_definition_must_be_dict(self):
        data = {"flow": {"bad": "not a dict"}}
        errors = DSLValidator().validate(data)
        assert any("dict" in e for e in errors)

    def test_empty_flow_is_valid(self):
        """A flow with a single vertex (no next) is valid."""
        data = {
            "flow": {
                "solo": {
                    "only": {"handler": "h.only"},
                }
            }
        }
        errors = DSLValidator().validate(data)
        assert errors == []

    def test_duplicate_vertex_across_flows(self):
        """Same vertex in multiple flows is OK (shared vertex)."""
        data = {
            "flow": {
                "f1": {
                    "shared": {"next": ["a"]},
                    "a": {},
                },
                "f2": {
                    "shared": {"next": ["b"]},
                    "b": {},
                },
            }
        }
        errors = DSLValidator().validate(data)
        assert errors == []
