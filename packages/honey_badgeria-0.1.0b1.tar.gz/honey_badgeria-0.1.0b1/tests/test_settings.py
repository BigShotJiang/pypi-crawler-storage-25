"""Tests for Settings: cache, parallel, async flags and defaults."""

import os
import pytest
from honey_badgeria.conf.settings import Settings, get_settings, configure, reset_settings


class TestSettingsDefaults:
    """All optional execution features must be OFF by default."""

    def test_cache_disabled_by_default(self):
        s = Settings()
        assert s.CACHE_ENABLED is False

    def test_parallel_disabled_by_default(self):
        s = Settings()
        assert s.PARALLEL_ENABLED is False

    def test_async_disabled_by_default(self):
        s = Settings()
        assert s.ASYNC_ENABLED is False

    def test_max_workers_default(self):
        s = Settings()
        assert s.MAX_WORKERS == 4

    def test_default_graph_file(self):
        s = Settings()
        assert s.GRAPH_FILE == "graph.yaml"

    def test_default_cache_dir(self):
        s = Settings()
        assert s.CACHE_DIR == ".hbia_cache"


class TestSettingsKwargs:
    """Settings can be overridden via keyword arguments."""

    def test_enable_cache(self):
        s = Settings(CACHE_ENABLED=True)
        assert s.CACHE_ENABLED is True

    def test_enable_parallel(self):
        s = Settings(PARALLEL_ENABLED=True, MAX_WORKERS=8)
        assert s.PARALLEL_ENABLED is True
        assert s.MAX_WORKERS == 8

    def test_enable_async(self):
        s = Settings(ASYNC_ENABLED=True)
        assert s.ASYNC_ENABLED is True

    def test_custom_cache_dir(self):
        s = Settings(CACHE_DIR="/tmp/test_cache")
        assert s.CACHE_DIR == "/tmp/test_cache"


class TestSettingsFromEnv:
    """Settings.from_env() reads environment variables."""

    def test_env_cache_enabled(self, monkeypatch):
        monkeypatch.setenv("HBIA_CACHE_ENABLED", "true")
        s = Settings.from_env()
        assert s.CACHE_ENABLED is True

    def test_env_parallel_enabled(self, monkeypatch):
        monkeypatch.setenv("HBIA_PARALLEL_ENABLED", "1")
        s = Settings.from_env()
        assert s.PARALLEL_ENABLED is True

    def test_env_async_enabled(self, monkeypatch):
        monkeypatch.setenv("HBIA_ASYNC_ENABLED", "yes")
        s = Settings.from_env()
        assert s.ASYNC_ENABLED is True

    def test_env_max_workers(self, monkeypatch):
        monkeypatch.setenv("HBIA_MAX_WORKERS", "16")
        s = Settings.from_env()
        assert s.MAX_WORKERS == 16

    def test_env_max_workers_invalid(self, monkeypatch):
        monkeypatch.setenv("HBIA_MAX_WORKERS", "not_a_number")
        s = Settings.from_env()
        assert s.MAX_WORKERS == 4  # falls back to default

    def test_env_cache_disabled_by_default(self, monkeypatch):
        monkeypatch.delenv("HBIA_CACHE_ENABLED", raising=False)
        s = Settings.from_env()
        assert s.CACHE_ENABLED is False

    def test_env_handler_modules(self, monkeypatch):
        monkeypatch.setenv("HBIA_HANDLER_MODULES", "mod_a,mod_b")
        s = Settings.from_env()
        assert s.HANDLER_MODULES == ["mod_a", "mod_b"]

    def test_env_handler_modules_empty(self, monkeypatch):
        monkeypatch.delenv("HBIA_HANDLER_MODULES", raising=False)
        s = Settings.from_env()
        assert s.HANDLER_MODULES == []


class TestSettingsGlobal:
    """Global settings singleton management."""

    def setup_method(self):
        reset_settings()

    def teardown_method(self):
        reset_settings()

    def test_get_settings_returns_singleton(self):
        s1 = get_settings()
        s2 = get_settings()
        assert s1 is s2

    def test_configure_with_settings_object(self):
        custom = Settings(CACHE_ENABLED=True, MAX_WORKERS=2)
        configure(custom)
        assert get_settings().CACHE_ENABLED is True
        assert get_settings().MAX_WORKERS == 2

    def test_configure_with_dict(self):
        configure({"PARALLEL_ENABLED": True})
        assert get_settings().PARALLEL_ENABLED is True

    def test_reset_settings(self):
        configure(Settings(CACHE_ENABLED=True))
        assert get_settings().CACHE_ENABLED is True
        reset_settings()
        s = get_settings()
        assert s.CACHE_ENABLED is False  # back to default from env


class TestSettingsHelpers:

    def test_to_dict(self):
        s = Settings(CACHE_ENABLED=True, PARALLEL_ENABLED=False)
        d = s.to_dict()
        assert d["CACHE_ENABLED"] is True
        assert d["PARALLEL_ENABLED"] is False
        assert "MAX_WORKERS" in d

    def test_repr(self):
        s = Settings()
        assert "serial" in repr(s)

    def test_repr_with_flags(self):
        s = Settings(CACHE_ENABLED=True, PARALLEL_ENABLED=True, ASYNC_ENABLED=True)
        r = repr(s)
        assert "cache" in r
        assert "parallel" in r
        assert "async" in r
