"""Tests for the centralized exception hierarchy."""

import pytest

from honey_badgeria.core.exceptions import (
    CacheError,
    ConfigurationError,
    ContractError,
    ContractInputError,
    ContractOutputError,
    DSLValidationError,
    DataResolutionError,
    EdgeInvalidError,
    ExecutionError,
    FlowNotFoundError,
    GraphCycleError,
    GraphError,
    GraphValidationError,
    HandlerNotFoundError,
    HandlerResolutionError,
    HoneyBadgeriaError,
    StageExecutionError,
    VertexAlreadyExistsError,
    VertexExecutionError,
    VertexNotFoundError,
)


class TestBaseHierarchy:
    """Every HBIA exception must be an instance of HoneyBadgeriaError."""

    @pytest.mark.parametrize(
        "exc_class",
        [
            GraphError,
            VertexAlreadyExistsError,
            VertexNotFoundError,
            EdgeInvalidError,
            GraphCycleError,
            GraphValidationError,
            DSLValidationError,
            HandlerNotFoundError,
            HandlerResolutionError,
            FlowNotFoundError,
            DataResolutionError,
            ContractError,
            ContractInputError,
            ContractOutputError,
            ExecutionError,
            VertexExecutionError,
            StageExecutionError,
            CacheError,
            ConfigurationError,
        ],
    )
    def test_isinstance_base(self, exc_class):
        exc = exc_class("test") if exc_class not in (
            GraphValidationError,
            DSLValidationError,
            VertexExecutionError,
        ) else exc_class("test", errors=[]) if exc_class in (
            GraphValidationError,
            DSLValidationError,
        ) else exc_class("test", vertex_name="v")
        assert isinstance(exc, HoneyBadgeriaError)
        assert isinstance(exc, Exception)

    def test_catch_all_with_base(self):
        """A single ``except HoneyBadgeriaError`` catches everything."""
        for exc in [
            GraphError("g"),
            FlowNotFoundError("f"),
            ContractInputError("c"),
            VertexExecutionError("v", vertex_name="x"),
        ]:
            with pytest.raises(HoneyBadgeriaError):
                raise exc


class TestGraphErrors:

    def test_graph_error_subtypes(self):
        for cls in [
            VertexAlreadyExistsError,
            VertexNotFoundError,
            EdgeInvalidError,
            GraphCycleError,
        ]:
            assert issubclass(cls, GraphError)

    def test_graph_error_message(self):
        exc = VertexNotFoundError("vertex 'foo' not found")
        assert "foo" in str(exc)


class TestValidationErrors:

    def test_graph_validation_error_stores_errors(self):
        errors = ["missing vertex A", "orphan edge B→C"]
        exc = GraphValidationError("Validation failed", errors=errors)
        assert exc.errors == errors
        assert "Validation failed" in str(exc)

    def test_graph_validation_error_default_errors(self):
        exc = GraphValidationError("fail")
        assert exc.errors == []

    def test_dsl_validation_error_stores_errors(self):
        errors = ["missing 'vertices' key"]
        exc = DSLValidationError("DSL invalid", errors=errors)
        assert exc.errors == errors

    def test_dsl_validation_error_default_errors(self):
        exc = DSLValidationError("bad")
        assert exc.errors == []


class TestContractErrors:

    def test_contract_error_subtypes(self):
        assert issubclass(ContractInputError, ContractError)
        assert issubclass(ContractOutputError, ContractError)

    def test_contract_input_message(self):
        exc = ContractInputError("Missing input: x")
        assert "Missing input" in str(exc)

    def test_contract_output_message(self):
        exc = ContractOutputError("Missing output: y")
        assert "Missing output" in str(exc)


class TestExecutionErrors:

    def test_vertex_execution_error_attributes(self):
        original = ValueError("inner boom")
        exc = VertexExecutionError(
            "vertex 'proc' failed",
            vertex_name="proc",
            original=original,
        )
        assert exc.vertex_name == "proc"
        assert exc.original is original
        assert "proc" in str(exc)
        assert isinstance(exc, ExecutionError)
        assert isinstance(exc, HoneyBadgeriaError)

    def test_vertex_execution_error_defaults(self):
        exc = VertexExecutionError("failed")
        assert exc.vertex_name == ""
        assert exc.original is None

    def test_stage_execution_error(self):
        exc = StageExecutionError("stage 2 failed")
        assert isinstance(exc, ExecutionError)


class TestMiscErrors:

    def test_handler_not_found(self):
        exc = HandlerNotFoundError("no handler")
        assert isinstance(exc, HoneyBadgeriaError)

    def test_handler_resolution_error(self):
        exc = HandlerResolutionError("bad.dotted.path")
        assert isinstance(exc, HoneyBadgeriaError)

    def test_flow_not_found(self):
        exc = FlowNotFoundError("flow 'main' missing")
        assert isinstance(exc, HoneyBadgeriaError)

    def test_data_resolution_error(self):
        exc = DataResolutionError("key 'a.b' not in store")
        assert isinstance(exc, HoneyBadgeriaError)

    def test_cache_error(self):
        exc = CacheError("cache corrupt")
        assert isinstance(exc, HoneyBadgeriaError)

    def test_configuration_error(self):
        exc = ConfigurationError("bad setting")
        assert isinstance(exc, HoneyBadgeriaError)
