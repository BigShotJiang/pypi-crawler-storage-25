"""Tests for decorators."""

from honey_badgeria.decorators.vertex import vertex, VERTEX_REGISTRY
from honey_badgeria.decorators.flow import flow, FLOW_REGISTRY


class TestVertexDecorator:

    def setup_method(self):
        VERTEX_REGISTRY.clear()

    def test_vertex_decorator_simple(self):
        @vertex
        def my_handler():
            return {"result": 1}

        assert "my_handler" in VERTEX_REGISTRY
        assert VERTEX_REGISTRY["my_handler"] is my_handler
        assert my_handler.__hbia_vertex__ is True

    def test_vertex_decorator_with_name(self):
        @vertex(name="custom_name")
        def handler():
            return {}

        assert "custom_name" in VERTEX_REGISTRY
        assert handler.__hbia_vertex_name__ == "custom_name"

    def test_vertex_still_callable(self):
        @vertex
        def adder(x=0, y=0):
            return {"sum": x + y}

        result = adder(x=3, y=4)
        assert result == {"sum": 7}

    def test_multiple_vertices(self):
        @vertex
        def handler_a():
            return {}

        @vertex
        def handler_b():
            return {}

        assert "handler_a" in VERTEX_REGISTRY
        assert "handler_b" in VERTEX_REGISTRY


class TestFlowDecorator:

    def setup_method(self):
        FLOW_REGISTRY.clear()

    def test_flow_decorator(self):
        @flow("my_flow")
        def my_flow_fn():
            pass

        assert "my_flow" in FLOW_REGISTRY
        assert FLOW_REGISTRY["my_flow"] is my_flow_fn
        assert my_flow_fn.__hbia_flow__ is True
        assert my_flow_fn.__hbia_flow_name__ == "my_flow"

    def test_flow_still_callable(self):
        @flow("test")
        def test_flow():
            return "executed"

        assert test_flow() == "executed"
