"""Tests for the AI context generation system.

Covers:
- Context document generation (content, version stamp, modes)
- CLI context command (--show, --write, --target, --mode, default summary)
- Init-project AI context file generation
- Known targets mapping
"""

import os
import pytest

typer = pytest.importorskip("typer")
from typer.testing import CliRunner

from honey_badgeria.context import generate_context, KNOWN_TARGETS
from honey_badgeria.context.ai_context import (
    _HEADER, _PHILOSOPHY, _BACK_WORKFLOW, _FRONT_WORKFLOW, _SYMBIOSIS,
)


runner = CliRunner()


def _make_app():
    """Build the full CLI app matching cli/main.py."""
    app = typer.Typer()

    @app.command("version")
    def version():
        from honey_badgeria import __version__
        typer.echo(f"Honey Badgeria v{__version__}")

    from honey_badgeria.cli.commands import (
        run, validate, inspect, explain, viz,
        cache_info, cache_prune, clear_cache,
        doctor, graph, graph_sync, graph_validate,
        vertex_create, flow_build, init_project,
        context,
    )
    for mod in (
        run, validate, inspect, explain, viz,
        cache_info, cache_prune, clear_cache,
        doctor, graph, graph_sync, graph_validate,
        vertex_create, flow_build, init_project,
        context,
    ):
        mod.register(app)

    return app


# ===========================================================================
# Context module unit tests
# ===========================================================================


class TestGenerateContext:

    def test_returns_string(self):
        doc = generate_context()
        assert isinstance(doc, str)
        assert len(doc) > 1000  # should be substantial

    def test_default_mode_is_back(self):
        doc = generate_context()
        assert "Backend — The HBIA Workflow" in doc
        assert "Frontend — The HBIA UI Workflow" not in doc
        assert "Symbiosis" not in doc

    def test_version_stamped(self):
        from honey_badgeria import __version__
        doc = generate_context()
        assert __version__ in doc
        assert "{{VERSION}}" not in doc

    def test_back_mode_contains_core_sections(self):
        doc = generate_context("back")
        assert "## 0. Why Honey Badgeria Exists" in doc
        assert "Backend — The HBIA Workflow" in doc
        assert "Backend Pit Stop" in doc
        assert "Backend Naming Conventions" in doc
        assert "Backend YAML DSL" in doc
        assert "Backend Settings" in doc
        assert "Backend Execution Modes" in doc
        assert "Backend CLI Commands Reference" in doc
        assert "Backend Exception Hierarchy" in doc
        assert "Backend Testing Utilities" in doc
        assert "Backend Handler Rules" in doc
        assert "Backend Module Map" in doc
        assert "Foundational Principles" in doc

    def test_front_mode_contains_frontend_sections(self):
        doc = generate_context("front")
        assert "## 0. Why Honey Badgeria Exists" in doc
        assert "Frontend — The HBIA UI Workflow" in doc
        assert "Frontend Pit Stop" in doc
        assert "Frontend Naming Conventions" in doc
        assert "Frontend YAML DSL" in doc
        assert "Frontend Reactive Rules" in doc
        assert "Frontend Hook Safety" in doc
        assert "Frontend Linting" in doc
        assert "Frontend Code Generation" in doc
        assert "Frontend CLI Commands Reference" in doc
        assert "Frontend Module Map" in doc
        assert "Foundational Principles" in doc
        # Should NOT contain backend
        assert "Backend — The HBIA Workflow" not in doc
        assert "Backend Pit Stop" not in doc

    def test_monorepo_mode_contains_all(self):
        doc = generate_context("monorepo")
        # Backend sections
        assert "Backend — The HBIA Workflow" in doc
        assert "Backend Pit Stop" in doc
        # Frontend sections
        assert "Frontend — The HBIA UI Workflow" in doc
        assert "Frontend Pit Stop" in doc
        # Symbiosis
        assert "Back + Front Symbiosis" in doc
        assert "services/" in doc

    def test_monorepo_is_largest(self):
        back_doc = generate_context("back")
        front_doc = generate_context("front")
        mono_doc = generate_context("monorepo")
        assert len(mono_doc) > len(back_doc)
        assert len(mono_doc) > len(front_doc)

    def test_contains_key_api_references(self):
        doc = generate_context("back")
        assert "from honey_badgeria.decorators import vertex" in doc
        assert "honey_badgeria.conf.settings" in doc
        assert "run_flow" in doc
        assert "GraphFactory" in doc
        assert "FlowTester" in doc
        assert "VertexMock" in doc

    def test_front_contains_key_references(self):
        doc = generate_context("front")
        assert "FrontendDomain" in doc
        assert "FrontendLinter" in doc
        assert "FrontendCodegen" in doc
        assert "useSyncExternalStore" in doc
        assert "UINodeSchema" in doc

    def test_back_contains_isolated_flow_antipattern(self):
        doc = generate_context("back")
        assert "BACK RULE #4" in doc
        assert "single-vertex flow" in doc.lower()
        assert "W007" in doc
        assert "W008" in doc

    def test_back_contains_next_backbone_emphasis(self):
        doc = generate_context("back")
        assert "next` is the backbone" in doc

    def test_front_contains_counter_example_warning(self):
        doc = generate_context("front")
        assert "FRONT RULE #1b" in doc
        assert "NEVER put real application code in the counter domain" in doc

    def test_front_contains_primitives_first_rule(self):
        doc = generate_context("front")
        assert "FRONT RULE #5" in doc
        assert "Primitives First" in doc
        assert "primitives/" in doc

    def test_front_mistakes_counter_and_primitives(self):
        doc = generate_context("front")
        assert "Putting code in the counter example domain" in doc
        assert "Skipping primitives" in doc

    def test_front_localstorage_forbidden(self):
        doc = generate_context("front")
        assert "localStorage" in doc
        assert "FORBIDDEN" in doc
        assert "Rule 7" in doc

    def test_front_error_handling_rules(self):
        doc = generate_context("front")
        assert "ServiceResult" in doc
        assert "NEVER Expose Raw Errors" in doc
        assert "userMessage" in doc

    def test_back_contains_settings_centralization_rule(self):
        doc = generate_context("back")
        assert "BACK RULE #5" in doc
        assert "NEVER use `os.environ` directly" in doc
        assert "example.env" in doc
        assert "Keycloak" in doc

    def test_back_contains_infra_auth(self):
        doc = generate_context("back")
        assert "infra/auth.py" in doc
        assert "KEYCLOAK_URL" in doc

    def test_contains_settings_table(self):
        doc = generate_context("back")
        assert "CACHE_ENABLED" in doc
        assert "PARALLEL_ENABLED" in doc
        assert "ASYNC_ENABLED" in doc
        assert "MAX_WORKERS" in doc
        assert "HBIA_CACHE_ENABLED" in doc
        assert "CORS_ORIGINS" in doc

    def test_contains_yaml_example(self):
        doc = generate_context("back")
        assert "handler:" in doc
        assert "effect:" in doc
        assert "version:" in doc

    def test_front_contains_dsl_examples(self):
        doc = generate_context("front")
        assert "component:" in doc
        assert "reads:" in doc
        assert "events:" in doc
        assert "state:" in doc
        assert "interface:" in doc
        assert "mutations:" in doc
        assert "triggers:" in doc
        assert "watch:" in doc

    def test_contains_handler_rules(self):
        doc = generate_context("back")
        assert "must return a dict" in doc
        assert "keyword arguments" in doc

    def test_raw_templates_have_placeholder(self):
        assert "{{VERSION}}" in _HEADER

    def test_security_in_all_modes(self):
        for mode in ("back", "front", "monorepo"):
            doc = generate_context(mode)
            assert "Security Rules" in doc


class TestKnownTargets:

    def test_all_targets_present(self):
        assert "agents" in KNOWN_TARGETS

    def test_target_paths(self):
        assert KNOWN_TARGETS["agents"] == "AGENTS.md"


# ===========================================================================
# CLI context command tests
# ===========================================================================


class TestContextCommandDefault:

    def test_default_shows_summary(self):
        app = _make_app()
        result = runner.invoke(app, ["context"])
        assert result.exit_code == 0
        assert "AI Context" in result.output
        assert "Target files" in result.output
        assert "AGENTS.md" in result.output

    def test_default_shows_usage(self):
        app = _make_app()
        result = runner.invoke(app, ["context"])
        assert "hbia context --write" in result.output
        assert "hbia context --show" in result.output

    def test_default_shows_doc_size(self):
        app = _make_app()
        result = runner.invoke(app, ["context"])
        assert "characters" in result.output


class TestContextCommandShow:

    def test_show_prints_full_document(self):
        app = _make_app()
        result = runner.invoke(app, ["context", "--show"])
        assert result.exit_code == 0
        assert "# Honey Badgeria" in result.output
        assert "## 0. Why Honey Badgeria Exists" in result.output

    def test_show_has_version(self):
        from honey_badgeria import __version__
        app = _make_app()
        result = runner.invoke(app, ["context", "--show"])
        assert __version__ in result.output

    def test_show_with_mode_front(self):
        app = _make_app()
        result = runner.invoke(app, ["context", "--show", "--mode", "front"])
        assert result.exit_code == 0
        assert "Frontend — The HBIA UI Workflow" in result.output
        assert "Backend — The HBIA Workflow" not in result.output

    def test_show_with_mode_monorepo(self):
        app = _make_app()
        result = runner.invoke(app, ["context", "--show", "--mode", "monorepo"])
        assert result.exit_code == 0
        assert "Symbiosis" in result.output

    def test_show_with_invalid_mode(self):
        app = _make_app()
        result = runner.invoke(app, ["context", "--show", "--mode", "invalid"])
        assert result.exit_code != 0


class TestContextCommandWrite:

    def test_write_all(self, tmp_path):
        app = _make_app()
        result = runner.invoke(app, ["context", "--write", "--dir", str(tmp_path)])
        assert result.exit_code == 0
        assert "Wrote" in result.output

        # All target files should exist
        for relpath in KNOWN_TARGETS.values():
            fullpath = tmp_path / relpath
            assert fullpath.exists(), f"Missing: {relpath}"
            content = fullpath.read_text()
            assert "# Honey Badgeria" in content

    def test_write_creates_target_files(self, tmp_path):
        app = _make_app()
        result = runner.invoke(app, ["context", "--write", "--dir", str(tmp_path)])
        assert result.exit_code == 0
        assert (tmp_path / "AGENTS.md").exists()

    def test_write_agents_only(self, tmp_path):
        app = _make_app()
        result = runner.invoke(app, [
            "context", "--write", "-t", "agents", "-d", str(tmp_path),
        ])
        assert result.exit_code == 0
        assert (tmp_path / "AGENTS.md").exists()

    def test_write_all_files_have_same_content(self, tmp_path):
        app = _make_app()
        runner.invoke(app, ["context", "--write", "--dir", str(tmp_path)])
        contents = set()
        for relpath in KNOWN_TARGETS.values():
            contents.add((tmp_path / relpath).read_text())
        assert len(contents) == 1  # all identical

    def test_write_unknown_target(self, tmp_path):
        app = _make_app()
        result = runner.invoke(app, [
            "context", "--write", "-t", "nonexistent", "-d", str(tmp_path),
        ])
        assert result.exit_code != 0

    def test_write_monorepo_mode(self, tmp_path):
        app = _make_app()
        result = runner.invoke(app, [
            "context", "--write", "--mode", "monorepo", "--dir", str(tmp_path),
        ])
        assert result.exit_code == 0
        content = (tmp_path / "AGENTS.md").read_text()
        assert "Symbiosis" in content


# ===========================================================================
# Init-project generates AI context files
# ===========================================================================


class TestInitProjectContext:

    def test_init_generates_ai_context_files(self, tmp_path):
        """hbia init should produce AI context files alongside the project."""
        app = _make_app()

        project_dir = str(tmp_path / "new_project")
        result = runner.invoke(app, ["init", project_dir])
        assert result.exit_code == 0

        # AI context files should exist inside the project
        for relpath in KNOWN_TARGETS.values():
            fullpath = os.path.join(project_dir, relpath)
            assert os.path.exists(fullpath), f"Missing AI context file: {relpath}"

        # Verify content is the real document
        agents_path = os.path.join(project_dir, "AGENTS.md")
        content = open(agents_path).read()
        assert "# Honey Badgeria" in content

    def test_init_context_files_contain_version(self, tmp_path):
        from honey_badgeria import __version__

        app = _make_app()

        project_dir = str(tmp_path / "versioned")
        runner.invoke(app, ["init", project_dir])

        content = open(os.path.join(project_dir, "AGENTS.md")).read()
        assert __version__ in content

    def test_init_monorepo_gets_monorepo_context(self, tmp_path):
        """hbia init --framework monorepo should produce monorepo context."""
        app = _make_app()

        project_dir = str(tmp_path / "mono_proj")
        result = runner.invoke(app, ["init", project_dir, "--framework", "monorepo"])
        assert result.exit_code == 0

        agents_path = os.path.join(project_dir, "AGENTS.md")
        content = open(agents_path).read()
        assert "Symbiosis" in content
        assert "Backend — The HBIA Workflow" in content
        assert "Frontend — The HBIA UI Workflow" in content
