"""Tests for the AI linter."""

from honey_badgeria.back.lint.ai_linter import AILinter, LintIssue


class TestAILinterFlowFormat:
    """Lint checks on the new flow format."""

    def test_clean_flow_no_issues(self):
        data = {
            "flow": {
                "greet": {
                    "hello": {
                        "handler": "vertices.greetings.hello",
                        "effect": "pure",
                        "version": "1",
                        "outputs": {"greeting": "str"},
                        "next": ["shout"],
                    },
                    "shout": {
                        "handler": "vertices.greetings.shout",
                        "effect": "pure",
                        "version": "1",
                        "inputs": {"greeting": "hello.greeting"},
                        "outputs": {"result": "str"},
                    },
                }
            }
        }
        issues = AILinter().lint(data)
        errors = [i for i in issues if i.severity == "error"]
        assert errors == []

    def test_missing_effect(self):
        data = {
            "flow": {
                "test": {
                    "step": {
                        "handler": "h.step",
                        "version": "1",
                        "outputs": {"x": "int"},
                    },
                }
            }
        }
        issues = AILinter().lint(data)
        codes = [i.code for i in issues]
        assert "W001" in codes

    def test_missing_version(self):
        data = {
            "flow": {
                "test": {
                    "step": {
                        "handler": "h.step",
                        "effect": "pure",
                        "outputs": {"x": "int"},
                    },
                }
            }
        }
        issues = AILinter().lint(data)
        codes = [i.code for i in issues]
        assert "W002" in codes

    def test_missing_handler(self):
        data = {
            "flow": {
                "test": {
                    "step": {
                        "effect": "pure",
                        "version": "1",
                        "outputs": {"x": "int"},
                    },
                }
            }
        }
        issues = AILinter().lint(data)
        codes = [i.code for i in issues]
        assert "W003" in codes

    def test_missing_outputs(self):
        data = {
            "flow": {
                "test": {
                    "step": {
                        "handler": "h.step",
                        "effect": "pure",
                        "version": "1",
                    },
                }
            }
        }
        issues = AILinter().lint(data)
        codes = [i.code for i in issues]
        assert "W005" in codes

    def test_bad_naming(self):
        data = {
            "flow": {
                "test": {
                    "BadName": {
                        "handler": "h.bad",
                        "effect": "pure",
                        "version": "1",
                        "outputs": {"x": "int"},
                    },
                }
            }
        }
        issues = AILinter().lint(data)
        codes = [i.code for i in issues]
        assert "W006" in codes

    def test_next_references_undefined_vertex(self):
        data = {
            "flow": {
                "test": {
                    "a": {
                        "handler": "h.a",
                        "effect": "pure",
                        "version": "1",
                        "outputs": {"x": "int"},
                        "next": ["nonexistent"],
                    },
                }
            }
        }
        issues = AILinter().lint(data)
        errors = [i for i in issues if i.severity == "error"]
        assert any(i.code == "E001" for i in errors)

    def test_disconnected_vertices_error(self):
        data = {
            "flow": {
                "test": {
                    "a": {
                        "handler": "h.a",
                        "effect": "pure",
                        "version": "1",
                        "outputs": {"x": "int"},
                    },
                    "b": {
                        "handler": "h.b",
                        "effect": "pure",
                        "version": "1",
                        "outputs": {"y": "int"},
                    },
                }
            }
        }
        issues = AILinter().lint(data)
        errors = [i for i in issues if i.severity == "error"]
        assert any(i.code == "E002" for i in errors)


    def test_single_vertex_flow_warns_w007(self):
        data = {
            "flow": {
                "add_comment": {
                    "add_comment": {
                        "handler": "vertices.comments.add_comment.add_comment",
                        "effect": "side_effect",
                        "version": "1",
                        "outputs": {"comment_id": "str"},
                    },
                }
            }
        }
        issues = AILinter().lint(data)
        codes = [i.code for i in issues]
        assert "W007" in codes

    def test_single_vertex_flow_w007_message_mentions_pipeline(self):
        data = {
            "flow": {
                "get_user": {
                    "get_user": {
                        "handler": "vertices.users.get_user.get_user",
                        "effect": "pure",
                        "version": "1",
                        "outputs": {"user_id": "str"},
                    },
                }
            }
        }
        issues = AILinter().lint(data)
        w007 = [i for i in issues if i.code == "W007"]
        assert len(w007) == 1
        assert "pipeline" in w007[0].message.lower()

    def test_multi_vertex_connected_flow_no_w007(self):
        data = {
            "flow": {
                "register": {
                    "validate": {
                        "handler": "h.validate",
                        "effect": "pure",
                        "version": "1",
                        "outputs": {"ok": "bool"},
                        "next": ["create"],
                    },
                    "create": {
                        "handler": "h.create",
                        "effect": "side_effect",
                        "version": "1",
                        "outputs": {"id": "str"},
                    },
                }
            }
        }
        issues = AILinter().lint(data)
        codes = [i.code for i in issues]
        assert "W007" not in codes


class TestAILinterEdgeCases:
    """Edge cases and error handling."""

    def test_not_a_dict(self):
        issues = AILinter().lint("not a dict")
        assert len(issues) == 1
        assert issues[0].code == "E000"

    def test_unknown_format(self):
        issues = AILinter().lint({"random": "data"})
        assert any(i.code == "E000" for i in issues)

    def test_empty_flow(self):
        data = {"flow": {"empty": {}}}
        issues = AILinter().lint(data)
        errors = [i for i in issues if i.severity == "error"]
        assert any(i.code == "E002" for i in errors)

    def test_issues_sorted_by_severity(self):
        data = {
            "flow": {
                "test": {
                    "a": {
                        "next": ["nonexistent"],
                    },
                }
            }
        }
        issues = AILinter().lint(data)
        severities = [i.severity for i in issues]
        # errors should come before warnings
        error_indices = [i for i, s in enumerate(severities) if s == "error"]
        warning_indices = [i for i, s in enumerate(severities) if s == "warning"]
        if error_indices and warning_indices:
            assert max(error_indices) < min(warning_indices)

    def test_lint_issue_str(self):
        issue = LintIssue(
            code="W001",
            severity="warning",
            message="Missing effect",
            vertex="hello",
            flow="greet",
            suggestion="Add effect: pure",
        )
        s = str(issue)
        assert "W001" in s
        assert "hello" in s
        assert "greet" in s
        assert "effect" in s.lower()
