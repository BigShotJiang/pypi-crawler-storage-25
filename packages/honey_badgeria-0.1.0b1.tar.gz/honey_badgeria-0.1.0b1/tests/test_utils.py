"""Tests for utility functions."""

import pytest
from honey_badgeria.back.graph import Graph, Vertex, Edge
from honey_badgeria.utils.graph_tools import merge_graphs, subgraph
from honey_badgeria.utils.import_tools import import_string, try_import


class TestGraphTools:

    def test_merge_graphs(self):
        g1 = Graph()
        g1.add_vertex(Vertex("a"))
        g1.add_vertex(Vertex("b"))
        g1.add_edge(Edge("a", "b"))

        g2 = Graph()
        g2.add_vertex(Vertex("c"))
        g2.add_edge(Edge("b", "c"))

        merged = merge_graphs(g1, g2)
        assert merged.has_vertex("a")
        assert merged.has_vertex("b")
        assert merged.has_vertex("c")
        assert len(merged.edges) == 2

    def test_merge_deduplicates(self):
        g1 = Graph()
        g1.add_vertex(Vertex("a"))

        g2 = Graph()
        g2.add_vertex(Vertex("a"))  # duplicate

        merged = merge_graphs(g1, g2)
        assert len(merged.vertices) == 1

    def test_subgraph(self):
        g = Graph()
        g.add_vertex(Vertex("a"))
        g.add_vertex(Vertex("b"))
        g.add_vertex(Vertex("c"))
        g.add_edge(Edge("a", "b"))
        g.add_edge(Edge("b", "c"))
        g.add_edge(Edge("a", "c"))

        sub = subgraph(g, ["a", "b"])
        assert sub.has_vertex("a")
        assert sub.has_vertex("b")
        assert not sub.has_vertex("c")
        assert len(sub.edges) == 1  # only a->b


class TestImportTools:

    def test_import_string(self):
        cls = import_string("collections.OrderedDict")
        from collections import OrderedDict
        assert cls is OrderedDict

    def test_import_string_invalid(self):
        with pytest.raises(ImportError):
            import_string("nonexistent")

    def test_try_import_success(self):
        mod = try_import("json")
        assert mod is not None

    def test_try_import_failure(self):
        mod = try_import("totally_nonexistent_module_xyz")
        assert mod is None
