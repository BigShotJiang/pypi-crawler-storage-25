"""Tests for atomicity: AtomicGroup, AtomicContext, SagaCoordinator,
executor integration, parallel suppression, cache bypass, and a
realistic payment-processing scenario.
"""

from __future__ import annotations

import copy
import pytest
from typing import Any

from honey_badgeria.back.graph.graph import Graph
from honey_badgeria.back.graph.vertex import Vertex, PURE, SIDE_EFFECT
from honey_badgeria.back.graph.edge import Edge
from honey_badgeria.back.graph.validator import GraphValidator
from honey_badgeria.back.atomicity.group import AtomicGroup, FailurePolicy
from honey_badgeria.back.atomicity.backends import InMemoryBackend, TransactionBackend
from honey_badgeria.back.atomicity.context import AtomicContext
from honey_badgeria.back.atomicity.saga import SagaStep, SagaCoordinator
from honey_badgeria.back.runtime.executor import GraphExecutor
from honey_badgeria.back.runtime.runner import run_flow
from honey_badgeria.back.runtime.data_store import DataStore
from honey_badgeria.back.runtime.state_store import StateStore
from honey_badgeria.back.runtime.lineage import DataLineage
from honey_badgeria.back.loader.graph_builder import GraphBuilder
from honey_badgeria.core.exceptions import (
    AtomicError,
    AtomicRollbackError,
    AtomicSnapshotError,
    AtomicBoundaryError,
    SagaError,
    SagaCompensationError,
    SagaStepError,
    GraphValidationError,
)
from honey_badgeria.back.dsl.validator import DSLValidator
from honey_badgeria.logging.ai_logger import AILogger
from honey_badgeria.testing.graph_factory import GraphFactory


# ======================================================================
# Helpers
# ======================================================================

def _ok_handler(**kwargs: Any) -> dict[str, Any]:
    """A handler that always succeeds."""
    return {"result": "ok", **kwargs}


def _fail_handler(**kwargs: Any) -> dict[str, Any]:
    """A handler that always raises."""
    raise RuntimeError("boom")


def _counter_handler(counter: dict[str, int], name: str):
    """Returns a handler that increments a counter."""
    def handler(**kwargs: Any) -> dict[str, Any]:
        counter[name] = counter.get(name, 0) + 1
        return {"count": counter[name]}
    return handler


def _build_linear_graph_with_atomic_group(
    vertex_names: list[str],
    group_name: str = "atomic_section",
    group_vertices: list[str] | None = None,
    handlers: dict[str, Any] | None = None,
    failure_policy: FailurePolicy = FailurePolicy.ROLLBACK,
) -> Graph:
    """Build a linear A→B→C graph with an atomic group on specified vertices."""
    handlers = handlers or {}
    graph = Graph()

    for i, name in enumerate(vertex_names):
        inputs = {}
        if i > 0:
            inputs = {"input": f"{vertex_names[i - 1]}.result"}
        graph.add_vertex(Vertex(
            name=name,
            handler=handlers.get(name, _ok_handler),
            inputs=inputs if i > 0 else {},
        ))

    for i in range(len(vertex_names) - 1):
        graph.add_edge(Edge(source=vertex_names[i], target=vertex_names[i + 1]))

    gv = group_vertices or vertex_names
    graph.atomic_groups[group_name] = AtomicGroup(
        name=group_name,
        vertices=gv,
        failure_policy=failure_policy,
    )
    return graph


# ======================================================================
# AtomicGroup model tests
# ======================================================================

class TestAtomicGroup:

    def test_create_group(self):
        group = AtomicGroup(name="pay", vertices=["a", "b", "c"])
        assert group.name == "pay"
        assert group.vertices == ["a", "b", "c"]
        assert group.failure_policy == FailurePolicy.ROLLBACK
        assert group.no_cache is True
        assert group.no_parallel is True

    def test_contains(self):
        group = AtomicGroup(name="g", vertices=["x", "y"])
        assert group.contains("x")
        assert not group.contains("z")

    def test_vertex_set(self):
        group = AtomicGroup(name="g", vertices=["a", "b", "a"])
        assert group.vertex_set == frozenset({"a", "b"})

    def test_failure_policies(self):
        assert FailurePolicy.ROLLBACK.value == "rollback"
        assert FailurePolicy.COMPENSATE.value == "compensate"
        assert FailurePolicy.ABORT.value == "abort"

    def test_immutable(self):
        group = AtomicGroup(name="g", vertices=["a"])
        with pytest.raises(AttributeError):
            group.name = "new"  # type: ignore[misc]


# ======================================================================
# InMemoryBackend tests
# ======================================================================

class TestInMemoryBackend:

    def test_snapshot_and_commit(self):
        backend = InMemoryBackend()
        data = {"a.result": 42}
        backend.save_snapshot("g", data)
        assert backend.get_snapshot("g") is not None
        backend.commit("g")
        assert backend.was_committed("g")
        assert backend.get_snapshot("g") is None  # cleaned after commit

    def test_snapshot_and_rollback(self):
        backend = InMemoryBackend()
        data = {"x": 1}
        backend.save_snapshot("g", data)
        backend.rollback("g", data)
        assert backend.was_rolled_back("g")

    def test_reset(self):
        backend = InMemoryBackend()
        backend.save_snapshot("g", {})
        backend.commit("g")
        backend.reset()
        assert not backend.was_committed("g")


# ======================================================================
# AtomicContext tests
# ======================================================================

class TestAtomicContext:

    def test_commit_on_success(self):
        group = AtomicGroup(name="g", vertices=["a"])
        backend = InMemoryBackend()
        ds = DataStore()
        ss = StateStore()
        ds.set_output("pre", 1)

        ctx = AtomicContext(group, backend, ds, ss)
        with ctx:
            ds.set_output("a.result", 42)
            ss.set_state("a", StateStore.COMPLETED)

        assert ctx.is_committed
        assert not ctx.is_rolled_back
        assert backend.was_committed("g")
        assert ds.get_output("a.result") == 42

    def test_rollback_on_failure(self):
        group = AtomicGroup(name="g", vertices=["a", "b"])
        backend = InMemoryBackend()
        ds = DataStore()
        ss = StateStore()
        ds.set_output("pre", 100)

        with pytest.raises(RuntimeError, match="boom"):
            ctx = AtomicContext(group, backend, ds, ss)
            with ctx:
                ds.set_output("a.result", 1)
                ss.set_state("a", StateStore.COMPLETED)
                raise RuntimeError("boom")

        assert ctx.is_rolled_back
        assert not ctx.is_committed
        assert backend.was_rolled_back("g")
        # DataStore should be restored to pre-group state
        assert ds.get_output("pre") == 100
        assert not ds.has_output("a.result")

    def test_rollback_restores_state_store(self):
        group = AtomicGroup(name="g", vertices=["a"])
        backend = InMemoryBackend()
        ds = DataStore()
        ss = StateStore()
        ss.set_state("a", StateStore.PENDING)

        with pytest.raises(RuntimeError):
            ctx = AtomicContext(group, backend, ds, ss)
            with ctx:
                ss.set_state("a", StateStore.RUNNING)
                raise RuntimeError("fail")

        assert ss.get_state("a") == StateStore.PENDING

    def test_rollback_restores_lineage(self):
        group = AtomicGroup(name="g", vertices=["a"])
        backend = InMemoryBackend()
        ds = DataStore()
        ss = StateStore()
        lineage = DataLineage()
        lineage.record("old.key", "old_vertex", ["x"])

        with pytest.raises(RuntimeError):
            ctx = AtomicContext(group, backend, ds, ss, lineage=lineage)
            with ctx:
                lineage.record("new.key", "a", ["y"])
                raise RuntimeError("fail")

        # Old lineage preserved, new lineage removed
        assert lineage.get_origin("old.key") is not None
        assert lineage.get_origin("new.key") is None

    def test_snapshot_data_property(self):
        group = AtomicGroup(name="g", vertices=["a"])
        backend = InMemoryBackend()
        ds = DataStore()
        ds.set_output("x", 1)
        ss = StateStore()

        ctx = AtomicContext(group, backend, ds, ss)
        with ctx:
            pass

        assert ctx.snapshot_data == {"x": 1}

    def test_double_commit_is_noop(self):
        group = AtomicGroup(name="g", vertices=["a"])
        backend = InMemoryBackend()
        ds = DataStore()
        ss = StateStore()

        ctx = AtomicContext(group, backend, ds, ss)
        with ctx:
            pass
        ctx.commit()  # second call — should not crash
        assert ctx.is_committed


# ======================================================================
# SagaCoordinator tests
# ======================================================================

class TestSagaCoordinator:

    def test_all_steps_succeed(self):
        saga = SagaCoordinator("test_saga")
        saga.add_step(SagaStep(name="s1", vertex_name="a"))
        saga.add_step(SagaStep(name="s2", vertex_name="b"))

        def executor(step: SagaStep):
            return ({}, {"done": True})

        results = saga.execute(executor)
        assert len(results) == 2
        assert saga.completed_steps == ["s1", "s2"]

    def test_compensation_on_failure(self):
        compensated: list[str] = []

        def compensate_s1(inputs, result):
            compensated.append("s1")

        def compensate_s2(inputs, result):
            compensated.append("s2")

        saga = SagaCoordinator("test_saga")
        saga.add_step(SagaStep("s1", "a", compensate_handler=compensate_s1))
        saga.add_step(SagaStep("s2", "b", compensate_handler=compensate_s2))
        saga.add_step(SagaStep("s3", "c"))  # this one fails

        call_count = 0
        def executor(step: SagaStep):
            nonlocal call_count
            call_count += 1
            if step.name == "s3":
                raise RuntimeError("step 3 failed")
            return ({}, {"ok": True})

        with pytest.raises(SagaStepError, match="step 3 failed"):
            saga.execute(executor)

        # s1 and s2 should have been compensated in reverse order
        assert compensated == ["s2", "s1"]

    def test_compensation_failure_raises_saga_compensation_error(self):
        def bad_compensate(inputs, result):
            raise RuntimeError("compensate failed")

        saga = SagaCoordinator("test_saga")
        saga.add_step(SagaStep("s1", "a", compensate_handler=bad_compensate))
        saga.add_step(SagaStep("s2", "b"))  # fails

        def executor(step: SagaStep):
            if step.name == "s2":
                raise RuntimeError("s2 failed")
            return ({}, {})

        with pytest.raises(SagaCompensationError):
            saga.execute(executor)

    def test_partial_compensation_continues(self):
        """Even if one compensation fails, earlier ones still run."""
        compensated: list[str] = []

        def ok_compensate(inputs, result):
            compensated.append("ok")

        def bad_compensate(inputs, result):
            raise RuntimeError("comp fail")

        saga = SagaCoordinator("test_saga")
        saga.add_step(SagaStep("s1", "a", compensate_handler=ok_compensate))
        saga.add_step(SagaStep("s2", "b", compensate_handler=bad_compensate))
        saga.add_step(SagaStep("s3", "c"))  # fails

        def executor(step: SagaStep):
            if step.name == "s3":
                raise RuntimeError("fail")
            return ({}, {})

        with pytest.raises(SagaCompensationError) as exc_info:
            saga.execute(executor)

        # bad_compensate failed, but ok_compensate still ran
        assert compensated == ["ok"]
        assert len(exc_info.value.compensation_errors) == 1

    def test_saga_step_without_compensator_is_skipped(self):
        compensated: list[str] = []

        def compensate_s1(inputs, result):
            compensated.append("s1")

        saga = SagaCoordinator("test_saga")
        saga.add_step(SagaStep("s1", "a", compensate_handler=compensate_s1))
        saga.add_step(SagaStep("s2", "b"))  # no compensator
        saga.add_step(SagaStep("s3", "c"))  # fails

        def executor(step: SagaStep):
            if step.name == "s3":
                raise RuntimeError("fail")
            return ({}, {})

        with pytest.raises(SagaStepError):
            saga.execute(executor)

        # s2 has no compensator, s1 does
        assert compensated == ["s1"]


# ======================================================================
# Exception hierarchy tests
# ======================================================================

class TestAtomicExceptions:

    def test_hierarchy(self):
        from honey_badgeria.core.exceptions import HoneyBadgeriaError
        assert issubclass(AtomicError, HoneyBadgeriaError)
        assert issubclass(AtomicRollbackError, AtomicError)
        assert issubclass(AtomicSnapshotError, AtomicError)
        assert issubclass(AtomicBoundaryError, AtomicError)
        assert issubclass(SagaError, HoneyBadgeriaError)
        assert issubclass(SagaCompensationError, SagaError)
        assert issubclass(SagaStepError, SagaError)

    def test_rollback_error_attributes(self):
        orig = RuntimeError("orig")
        rb_err = RuntimeError("rb")
        err = AtomicRollbackError(
            "msg", group_name="g", original=orig, rollback_error=rb_err,
        )
        assert err.group_name == "g"
        assert err.original is orig
        assert err.rollback_error is rb_err

    def test_saga_compensation_error_attributes(self):
        err = SagaCompensationError(
            "msg",
            failed_step="s3",
            compensation_errors=[("s2", RuntimeError("comp"))],
        )
        assert err.failed_step == "s3"
        assert len(err.compensation_errors) == 1


# ======================================================================
# DSL Validator tests
# ======================================================================

class TestDSLAtomicValidation:

    def _base_data(self):
        return {
            "flow": {
                "main": {
                    "a": {"handler": "h.a", "next": ["b"]},
                    "b": {"handler": "h.b", "next": ["c"]},
                    "c": {"handler": "h.c"},
                }
            }
        }

    def test_valid_atomic_group(self):
        data = self._base_data()
        data["atomic_groups"] = {
            "section": {"vertices": ["a", "b"]},
        }
        errors = DSLValidator().validate(data)
        assert errors == []

    def test_unknown_vertex_in_group(self):
        data = self._base_data()
        data["atomic_groups"] = {
            "section": {"vertices": ["a", "zzz"]},
        }
        errors = DSLValidator().validate(data)
        assert any("unknown vertex" in e for e in errors)

    def test_vertex_in_multiple_groups(self):
        data = self._base_data()
        data["atomic_groups"] = {
            "g1": {"vertices": ["a"]},
            "g2": {"vertices": ["a"]},
        }
        errors = DSLValidator().validate(data)
        assert any("multiple atomic groups" in e for e in errors)

    def test_empty_vertices_list(self):
        data = self._base_data()
        data["atomic_groups"] = {
            "g1": {"vertices": []},
        }
        errors = DSLValidator().validate(data)
        assert any("non-empty" in e for e in errors)

    def test_invalid_failure_policy(self):
        data = self._base_data()
        data["atomic_groups"] = {
            "g1": {"vertices": ["a"], "on_failure": "explode"},
        }
        errors = DSLValidator().validate(data)
        assert any("invalid on_failure" in e for e in errors)


# ======================================================================
# GraphValidator tests
# ======================================================================

class TestGraphValidatorAtomic:

    def test_valid_connected_group(self):
        graph = _build_linear_graph_with_atomic_group(
            ["a", "b", "c"], group_vertices=["a", "b"],
        )
        GraphValidator(graph).validate()  # should not raise

    def test_unknown_vertex_in_group(self):
        graph = _build_linear_graph_with_atomic_group(
            ["a", "b"], group_vertices=["a", "zzz"],
        )
        with pytest.raises(GraphValidationError, match="unknown vertex"):
            GraphValidator(graph).validate()

    def test_vertex_in_multiple_groups(self):
        graph = _build_linear_graph_with_atomic_group(
            ["a", "b", "c"], group_vertices=["a", "b"],
        )
        graph.atomic_groups["g2"] = AtomicGroup(
            name="g2", vertices=["b", "c"],
        )
        with pytest.raises(GraphValidationError, match="belongs to both"):
            GraphValidator(graph).validate()

    def test_disconnected_group_fails(self):
        """Vertices a and c are not directly connected — group is invalid."""
        graph = Graph()
        graph.add_vertex(Vertex(name="a", handler=_ok_handler))
        graph.add_vertex(Vertex(name="b", handler=_ok_handler))
        graph.add_vertex(Vertex(name="c", handler=_ok_handler))
        graph.add_edge(Edge(source="a", target="b"))
        graph.add_edge(Edge(source="b", target="c"))
        # Group has a and c but NOT b — they are not connected
        graph.atomic_groups["g"] = AtomicGroup(
            name="g", vertices=["a", "c"],
        )
        with pytest.raises(GraphValidationError, match="not connected"):
            GraphValidator(graph).validate()


# ======================================================================
# GraphBuilder / YAML integration tests
# ======================================================================

class TestGraphBuilderAtomic:

    def test_from_dict_with_atomic_groups(self):
        data = {
            "vertices": [
                {"name": "a"},
                {"name": "b"},
            ],
            "edges": [{"from": "a", "to": "b"}],
            "atomic_groups": {
                "pay": {
                    "vertices": ["a", "b"],
                    "on_failure": "compensate",
                    "no_cache": False,
                    "no_parallel": False,
                },
            },
        }
        graph = GraphBuilder.from_dict(data)
        assert "pay" in graph.atomic_groups
        group = graph.atomic_groups["pay"]
        assert group.failure_policy == FailurePolicy.COMPENSATE
        assert group.no_cache is False
        assert group.no_parallel is False

    def test_from_dict_defaults(self):
        data = {
            "vertices": [{"name": "a"}],
            "atomic_groups": {
                "g": {"vertices": ["a"]},
            },
        }
        graph = GraphBuilder.from_dict(data)
        group = graph.atomic_groups["g"]
        assert group.failure_policy == FailurePolicy.ROLLBACK
        assert group.no_cache is True
        assert group.no_parallel is True


# ======================================================================
# Executor integration tests
# ======================================================================

class TestExecutorAtomicIntegration:

    def test_atomic_group_commits_on_success(self):
        """All vertices in the group succeed → commit."""
        backend = InMemoryBackend()
        graph = _build_linear_graph_with_atomic_group(
            ["a", "b", "c"], group_vertices=["a", "b", "c"],
        )
        executor = GraphExecutor(
            graph, transaction_backend=backend,
        )
        result = executor.execute()
        assert "a.result" in result
        assert "c.result" in result
        assert backend.was_committed("atomic_section")

    def test_atomic_group_rolls_back_on_failure(self):
        """One vertex fails → data store rolled back to pre-group state."""
        backend = InMemoryBackend()
        handlers = {
            "a": _ok_handler,
            "b": _fail_handler,  # <-- fails
            "c": _ok_handler,
        }
        graph = _build_linear_graph_with_atomic_group(
            ["a", "b", "c"],
            group_vertices=["a", "b", "c"],
            handlers=handlers,
        )
        executor = GraphExecutor(
            graph, transaction_backend=backend,
        )
        with pytest.raises(RuntimeError, match="boom"):
            executor.execute()

        assert backend.was_rolled_back("atomic_section")
        # Data from vertex 'a' should have been rolled back
        assert not executor.data_store.has_output("a.result")

    def test_partial_atomic_group_in_graph(self):
        """Graph has vertices a→b→c→d, only b→c are atomic.
        If c fails, only b→c outputs are rolled back, a stays."""
        backend = InMemoryBackend()
        handlers = {
            "a": _ok_handler,
            "b": _ok_handler,
            "c": _fail_handler,
            "d": _ok_handler,
        }
        graph = _build_linear_graph_with_atomic_group(
            ["a", "b", "c", "d"],
            group_vertices=["b", "c"],
            handlers=handlers,
        )
        executor = GraphExecutor(
            graph, transaction_backend=backend,
        )
        with pytest.raises(RuntimeError, match="boom"):
            executor.execute()

        # Vertex 'a' completed before the atomic section — its data survives
        assert executor.data_store.has_output("a.result")
        assert backend.was_rolled_back("atomic_section")

    def test_parallel_suppressed_for_atomic_stage(self):
        """When an atomic group has no_parallel=True, the stage runs serially."""
        execution_order: list[str] = []

        def make_handler(name: str):
            def handler(**kwargs):
                execution_order.append(name)
                return {"result": name}
            return handler

        # Diamond graph: a → (b, c) → d
        # b and c are normally parallel, but b is atomic → serial
        graph = Graph()
        graph.add_vertex(Vertex(name="a", handler=make_handler("a")))
        graph.add_vertex(Vertex(name="b", handler=make_handler("b")))
        graph.add_vertex(Vertex(name="c", handler=make_handler("c")))
        graph.add_vertex(Vertex(name="d", handler=make_handler("d")))
        graph.add_edge(Edge("a", "b"))
        graph.add_edge(Edge("a", "c"))
        graph.add_edge(Edge("b", "d"))
        graph.add_edge(Edge("c", "d"))
        graph.atomic_groups["g"] = AtomicGroup(
            name="g", vertices=["b"],
            no_parallel=True,
        )

        executor = GraphExecutor(
            graph, parallel_enabled=True,
        )
        executor.execute()

        # b and c ran — we can't check thread vs serial directly,
        # but the executor should not crash and all 4 vertices complete
        assert executor.state_store.is_completed("a")
        assert executor.state_store.is_completed("b")
        assert executor.state_store.is_completed("c")
        assert executor.state_store.is_completed("d")

    def test_cache_bypassed_inside_atomic_group(self):
        """Cache must NOT serve results for vertices inside an atomic group."""
        call_count = {"a": 0, "b": 0}

        def handler_a(**kwargs):
            call_count["a"] += 1
            return {"result": "a_val"}

        def handler_b(**kwargs):
            call_count["b"] += 1
            return {"result": "b_val"}

        graph = _build_linear_graph_with_atomic_group(
            ["a", "b"],
            group_vertices=["a", "b"],
            handlers={"a": handler_a, "b": handler_b},
        )

        # Run twice — second run should STILL execute (not cache)
        executor1 = GraphExecutor(
            graph, cache_enabled=True,
        )
        executor1.execute()

        executor2 = GraphExecutor(
            graph, cache_enabled=True,
        )
        executor2.execute()

        # Both runs should have actually executed
        assert call_count["a"] == 2
        assert call_count["b"] == 2


# ======================================================================
# run_flow integration with atomic groups
# ======================================================================

class TestRunFlowAtomic:

    def test_run_flow_with_backend(self):
        backend = InMemoryBackend()
        graph = _build_linear_graph_with_atomic_group(
            ["a", "b"],
            group_vertices=["a", "b"],
        )
        graph.flows = {"main": {"entry": "a"}}
        result = run_flow(
            graph, flow_name="main",
            transaction_backend=backend,
        )
        assert "a.result" in result
        assert backend.was_committed("atomic_section")

    def test_run_flow_atomic_groups_propagated_to_subgraph(self):
        """Atomic groups should survive _resolve_flow_graph."""
        graph = _build_linear_graph_with_atomic_group(
            ["a", "b", "c"],
            group_vertices=["a", "b"],
        )
        graph.flows = {"main": {"entry": "a"}}
        backend = InMemoryBackend()
        result = run_flow(
            graph, flow_name="main",
            transaction_backend=backend,
        )
        assert backend.was_committed("atomic_section")


# ======================================================================
# Custom TransactionBackend test
# ======================================================================

class TestCustomBackend:

    def test_custom_backend_hooks_called(self):
        """Ensure that a user-provided backend's hooks fire correctly."""
        log: list[str] = []

        class TrackingBackend(TransactionBackend):
            def save_snapshot(self, group_name, data):
                log.append(f"snapshot:{group_name}")

            def rollback(self, group_name, snapshot_data):
                log.append(f"rollback:{group_name}")

            def commit(self, group_name):
                log.append(f"commit:{group_name}")

            def on_enter(self, group_name):
                log.append(f"enter:{group_name}")

            def on_exit(self, group_name, success):
                log.append(f"exit:{group_name}:{'ok' if success else 'fail'}")

        backend = TrackingBackend()
        graph = _build_linear_graph_with_atomic_group(
            ["a", "b"], group_vertices=["a", "b"],
        )
        executor = GraphExecutor(graph, transaction_backend=backend)
        executor.execute()

        assert "snapshot:atomic_section" in log
        assert "enter:atomic_section" in log
        assert "commit:atomic_section" in log
        assert "exit:atomic_section:ok" in log

    def test_custom_backend_rollback_on_failure(self):
        log: list[str] = []

        class TrackingBackend(TransactionBackend):
            def save_snapshot(self, g, d):
                log.append("snapshot")
            def rollback(self, g, d):
                log.append("rollback")
            def commit(self, g):
                log.append("commit")
            def on_exit(self, g, success):
                log.append(f"exit:{'ok' if success else 'fail'}")

        backend = TrackingBackend()
        graph = _build_linear_graph_with_atomic_group(
            ["a", "b"],
            group_vertices=["a", "b"],
            handlers={"a": _ok_handler, "b": _fail_handler},
        )
        executor = GraphExecutor(graph, transaction_backend=backend)
        with pytest.raises(RuntimeError):
            executor.execute()

        assert "snapshot" in log
        assert "rollback" in log
        assert "commit" not in log
        assert "exit:fail" in log


# ======================================================================
# Payment processing scenario — a realistic end-to-end test
# ======================================================================

class TestPaymentProcessingScenario:
    """Simulates a payment flow:
        validate_card → reserve_funds → charge_card → send_receipt

    The first three are atomic (any failure rolls back).
    send_receipt is outside the atomic boundary.
    """

    def _build_payment_graph(
        self, handlers: dict[str, Any],
    ) -> Graph:
        graph = Graph()
        graph.add_vertex(Vertex(
            name="validate_card",
            handler=handlers["validate_card"],
            effect=SIDE_EFFECT,
        ))
        graph.add_vertex(Vertex(
            name="reserve_funds",
            handler=handlers["reserve_funds"],
            inputs={"card": "validate_card.card_token"},
            effect=SIDE_EFFECT,
        ))
        graph.add_vertex(Vertex(
            name="charge_card",
            handler=handlers["charge_card"],
            inputs={"reservation": "reserve_funds.reservation_id"},
            effect=SIDE_EFFECT,
        ))
        graph.add_vertex(Vertex(
            name="send_receipt",
            handler=handlers["send_receipt"],
            inputs={"charge": "charge_card.charge_id"},
        ))

        graph.add_edge(Edge("validate_card", "reserve_funds"))
        graph.add_edge(Edge("reserve_funds", "charge_card"))
        graph.add_edge(Edge("charge_card", "send_receipt"))

        graph.atomic_groups["payment_core"] = AtomicGroup(
            name="payment_core",
            vertices=["validate_card", "reserve_funds", "charge_card"],
            failure_policy=FailurePolicy.ROLLBACK,
            no_cache=True,
            no_parallel=True,
        )

        graph.flows = {"process_payment": {"entry": "validate_card"}}
        return graph

    def test_successful_payment(self):
        """Happy path: all steps succeed."""
        handlers = {
            "validate_card": lambda: {"card_token": "tok_123"},
            "reserve_funds": lambda card: {"reservation_id": "res_456"},
            "charge_card": lambda reservation: {"charge_id": "chg_789"},
            "send_receipt": lambda charge: {"receipt": "sent"},
        }
        backend = InMemoryBackend()
        graph = self._build_payment_graph(handlers)

        result = run_flow(
            graph,
            flow_name="process_payment",
            transaction_backend=backend,
        )

        assert result["charge_card.charge_id"] == "chg_789"
        assert result["send_receipt.receipt"] == "sent"
        assert backend.was_committed("payment_core")

    def test_charge_fails_rolls_back(self):
        """charge_card fails → validate_card and reserve_funds rolled back."""
        handlers = {
            "validate_card": lambda: {"card_token": "tok_123"},
            "reserve_funds": lambda card: {"reservation_id": "res_456"},
            "charge_card": lambda reservation: (_ for _ in ()).throw(
                RuntimeError("declined")
            ),
            "send_receipt": lambda charge: {"receipt": "sent"},
        }
        backend = InMemoryBackend()
        graph = self._build_payment_graph(handlers)

        with pytest.raises(RuntimeError, match="declined"):
            run_flow(
                graph,
                flow_name="process_payment",
                transaction_backend=backend,
            )

        assert backend.was_rolled_back("payment_core")

    def test_payment_with_saga_compensation(self):
        """Use SagaCoordinator to model compensation logic."""
        compensated: list[str] = []

        def reverse_charge(inputs, result):
            compensated.append("reverse_charge")

        def release_funds(inputs, result):
            compensated.append("release_funds")

        saga = SagaCoordinator("payment_saga")
        saga.add_step(SagaStep(
            name="validate_card", vertex_name="validate_card",
        ))
        saga.add_step(SagaStep(
            name="reserve_funds", vertex_name="reserve_funds",
            compensate_handler=release_funds,
        ))
        saga.add_step(SagaStep(
            name="charge_card", vertex_name="charge_card",
            compensate_handler=reverse_charge,
        ))
        saga.add_step(SagaStep(
            name="send_receipt", vertex_name="send_receipt",
        ))

        call_idx = 0
        def executor(step: SagaStep):
            nonlocal call_idx
            call_idx += 1
            if step.name == "send_receipt":
                raise RuntimeError("email service down")
            return ({}, {"ok": True})

        with pytest.raises(SagaStepError, match="email service down"):
            saga.execute(executor)

        # Compensation runs in reverse: charge_card then reserve_funds
        assert compensated == ["reverse_charge", "release_funds"]


# ======================================================================
# Event logging tests
# ======================================================================

class TestAtomicEventLogging:

    def test_atomic_events_logged(self):
        logger = AILogger()
        backend = InMemoryBackend()
        graph = _build_linear_graph_with_atomic_group(
            ["a", "b"], group_vertices=["a", "b"],
        )
        executor = GraphExecutor(
            graph, transaction_backend=backend, logger=logger,
        )
        executor.execute()

        events = [e["event"] for e in logger.get_events()]
        assert "atomic.snapshot.saved" in events
        assert "atomic.group.entered" in events
        assert "atomic.committed" in events

    def test_rollback_events_logged(self):
        logger = AILogger()
        backend = InMemoryBackend()
        graph = _build_linear_graph_with_atomic_group(
            ["a", "b"],
            group_vertices=["a", "b"],
            handlers={"a": _ok_handler, "b": _fail_handler},
        )
        executor = GraphExecutor(
            graph, transaction_backend=backend, logger=logger,
        )
        with pytest.raises(RuntimeError):
            executor.execute()

        events = [e["event"] for e in logger.get_events()]
        assert "atomic.rollback.started" in events
        assert "atomic.rollback.completed" in events
