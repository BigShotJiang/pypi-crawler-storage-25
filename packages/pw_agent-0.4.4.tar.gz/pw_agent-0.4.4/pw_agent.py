#!/usr/bin/env python3
"""PW Agent — CLI coding assistant powered by your Ollama GPUs via PastaWater."""

import argparse
import os
import sys

from rich.console import Console
from rich.panel import Panel
from prompt_toolkit import prompt as pt_prompt
from prompt_toolkit import PromptSession
from prompt_toolkit.history import FileHistory
from prompt_toolkit.auto_suggest import AutoSuggestFromHistory
from prompt_toolkit.completion import Completer, Completion, PathCompleter
from prompt_toolkit.key_binding import KeyBindings

from llm_client import LLMClient
from agent import Agent
from config import load_config, save_config, has_config, DEFAULT_CONFIG_DIR


VERSION = "0.4.4"
console = Console()

BANNER = """[bold cyan]
 ╔═══════════════════════════════════════════════╗
 ║  PW Agent v{version}                              ║
 ║  Coding assistant on your own GPUs           ║
 ╚═══════════════════════════════════════════════╝
[/bold cyan]"""

HELP_TEXT = """[dim]
 Commands:
   /help     Show this help
   /add FILE  Add a file to context (@file also works)
   /clear     Clear conversation history
   /commit    Generate commit message and commit
   /diff      Show unstaged changes
   /models    Show all fleet GPUs and active models
   /switch N  Switch to a different GPU slot
   /update    Update pw-agent to latest version
   /config    Show saved config
   /logout    Clear saved token and config
   /quit      Exit (or Ctrl+D)

 Flags: -y/--yes (auto-approve all tools), -p "prompt" (one-shot)
[/dim]"""


# ─── First-run interactive setup ──────────────────────────────────────────────

def run_setup() -> dict:
    """Interactive first-run setup. Returns config dict."""
    console.print()
    console.print(Panel(
        "[bold]Welcome to PW Agent![/bold]\n\n"
        "Let's connect you to your GPU fleet.\n"
        "This only takes a few seconds.",
        border_style="cyan",
        padding=(1, 2),
    ))

    # Config directory — just use the default, don't ask
    config_dir = DEFAULT_CONFIG_DIR
    console.print(f"\n  [dim]Config: {config_dir}[/dim]")

    # Step 1: Connection mode
    console.print()
    console.print("  [bold]How do you want to connect?[/bold]")
    console.print("  [cyan]1[/cyan] — PastaWater Cloud [dim](use your API token)[/dim]")
    console.print("  [cyan]2[/cyan] — Direct to a brain [dim](local or remote Ollama)[/dim]")
    console.print()
    mode = pt_prompt("  Choose [1/2]: ").strip()

    cfg: dict = {"config_dir": config_dir}

    if mode == "2":
        # Direct brain mode
        console.print()
        brain_url = pt_prompt("  Brain URL [http://localhost:11434]: ").strip()
        if not brain_url:
            brain_url = "http://localhost:11434"
        cfg["brain_url"] = brain_url
        cfg["mode"] = "brain"

        # Detect models
        console.print(f"\n  [dim]Connecting to {brain_url}...[/dim]")
        try:
            import requests
            resp = requests.get(f"{brain_url}/api/tags", timeout=5)
            if resp.status_code == 200:
                models = [m["name"] for m in resp.json().get("models", [])]
                if models:
                    console.print(f"  [green]✓ Connected![/green]\n")
                    console.print("  [bold]Available models:[/bold]")
                    for i, m in enumerate(models, 1):
                        console.print(f"    [cyan]{i}[/cyan] — {m}")
                    console.print()
                    pick = pt_prompt(f"  Choose model [1-{len(models)}]: ").strip()
                    try:
                        cfg["model"] = models[int(pick) - 1]
                    except (ValueError, IndexError):
                        cfg["model"] = models[0]
                    console.print(f"  [green]✓ Selected: {cfg['model']}[/green]")
                else:
                    console.print("  [yellow]No models loaded. Pull a model first.[/yellow]")
            else:
                console.print(f"  [red]✗ Could not connect to {brain_url}[/red]")
        except Exception as e:
            console.print(f"  [red]✗ {e}[/red]")

    else:
        # PastaWater cloud mode
        cfg["mode"] = "cloud"
        console.print()
        console.print("  [dim]Get your token from:[/dim] [underline cyan]https://pastawater.io/settings?tab=cli[/underline cyan]")
        console.print()
        token = pt_prompt("  Paste your PW token: ").strip()
        if not token:
            console.print("  [red]No token provided.[/red]")
            sys.exit(1)
        cfg["token"] = token

        # Discover GPUs
        console.print(f"\n  [dim]Connecting to PastaWater...[/dim]")
        temp_client = LLMClient(token=token)
        devices = temp_client.list_devices()

        if not devices:
            console.print("  [yellow]⚠ No GPUs with LLM running found.[/yellow]")
            console.print("  [dim]Start an LLM model on https://pastawater.io/gpu-setup first.[/dim]")
        else:
            console.print(f"  [green]✓ Connected! Found {len(devices)} GPU(s) with LLM:[/green]\n")
            for i, d in enumerate(devices, 1):
                console.print(f"    [cyan]{i}[/cyan] — [bold]{d['device_name']}[/bold]  {d['gpu']} ({d['vram_gb']}GB)  [dim]{d['llm_model']}[/dim]")
            console.print()

            if len(devices) == 1:
                chosen = devices[0]
            else:
                pick = pt_prompt(f"  Choose GPU [1-{len(devices)}]: ").strip()
                try:
                    chosen = devices[int(pick) - 1]
                except (ValueError, IndexError):
                    chosen = devices[0]

            cfg["slot"] = chosen["slot"]
            cfg["device_id"] = chosen["device_id"]
            cfg["model"] = chosen["llm_model"]
            cfg["device_name"] = chosen["device_name"]
            console.print(f"  [green]✓ Selected: {chosen['device_name']} ({chosen['gpu']})[/green]")

    # Save
    path = save_config(cfg, config_dir)
    console.print(f"\n  [dim]Config saved to {path}[/dim]\n")
    return cfg


# ─── GPU listing ──────────────────────────────────────────────────────────────

def print_models(client: LLMClient):
    """Print a table of all fleet GPUs and their LLM status."""
    from rich.table import Table

    devices = client.list_devices()
    if not devices:
        console.print("  [yellow]No GPUs with LLM running found.[/yellow]")
        return

    table = Table(
        title="Active Engines on Your Fleet",
        title_style="bold white",
        border_style="dim",
        show_lines=False,
        pad_edge=False,
        padding=(0, 2),
    )
    table.add_column("Slot", style="cyan", width=5)
    table.add_column("GPU", style="white")
    table.add_column("Model", style="bold")
    table.add_column("VRAM", style="dim", justify="right")
    table.add_column("Status", justify="right")

    for d in devices:
        is_active = d["device_id"] == client.device_id
        status = "[bold green]● Active[/bold green]" if is_active else "[dim]Idle[/dim]"
        model_display = d["llm_model"] or "—"
        table.add_row(
            str(d["slot"]),
            f"{d['device_name']}\n[dim]{d['gpu']}[/dim]",
            model_display,
            f"{d['vram_gb']}GB",
            status,
        )

    console.print()
    console.print(table)
    console.print("\n  [dim]Type /switch <slot> to change active engine.[/dim]\n")


def check_for_update() -> str | None:
    """Check PyPI for a newer version. Returns new version string or None."""
    try:
        import requests
        resp = requests.get("https://pypi.org/pypi/pw-agent/json", timeout=5)
        if resp.status_code == 200:
            latest = resp.json()["info"]["version"]
            if latest != VERSION:
                return latest
    except Exception:
        pass
    return None


def do_update() -> bool:
    """Update pw-agent to latest. Tries pipx, pip --break-system-packages, pip."""
    import subprocess
    import shutil
    console.print("  [dim]Updating pw-agent...[/dim]")

    # Try pipx first (cleanest)
    if shutil.which("pipx"):
        result = subprocess.run(
            ["pipx", "upgrade", "pw-agent"],
            capture_output=True, text=True, timeout=60,
        )
        if result.returncode == 0:
            console.print(f"  [green]✓ Updated![/green] [dim]Restart pw-agent to use the new version.[/dim]")
            return True

    # Try pip with --break-system-packages (Debian/Ubuntu)
    for cmd in [
        ["pip", "install", "--upgrade", "--break-system-packages", "pw-agent"],
        ["pip3", "install", "--upgrade", "--break-system-packages", "pw-agent"],
        ["pip", "install", "--upgrade", "pw-agent"],
        ["pip3", "install", "--upgrade", "pw-agent"],
    ]:
        try:
            result = subprocess.run(cmd, capture_output=True, text=True, timeout=60)
            if result.returncode == 0:
                console.print(f"  [green]✓ Updated![/green] [dim]Restart pw-agent to use the new version.[/dim]")
                return True
        except FileNotFoundError:
            continue

    console.print(f"  [red]✗ Update failed. Try manually: pipx upgrade pw-agent[/red]")
    return False


def detect_brain_url() -> str | None:
    """Check if there's a local brain running."""
    import requests
    for port in [41789, 11434]:
        try:
            resp = requests.get(f"http://localhost:{port}/api/tags", timeout=2)
            if resp.status_code == 200:
                return f"http://localhost:{port}"
        except Exception:
            pass
    return None


# ─── Main ─────────────────────────────────────────────────────────────────────

def main():
    parser = argparse.ArgumentParser(
        description="PW Agent — CLI coding assistant powered by your Ollama GPUs",
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    parser.add_argument("--token", default=os.environ.get("PW_TOKEN"), help="PastaWater API token (or PW_TOKEN env)")
    parser.add_argument("--device", default=None, help="Device ID to use")
    parser.add_argument("--model", default=None, help="Ollama model name")
    parser.add_argument("--api-url", default=os.environ.get("PW_API_URL", "https://pastawater.io"), help="PastaWater API URL")
    parser.add_argument("--brain", default=os.environ.get("PW_BRAIN_URL", ""), help="Direct brain URL")
    parser.add_argument("--no-stream", action="store_true", help="Disable streaming output")
    parser.add_argument("--setup", action="store_true", help="Re-run first-time setup")
    parser.add_argument("-p", "--print", dest="one_shot", metavar="PROMPT", help="Non-interactive: send prompt, print response, exit")
    parser.add_argument("-y", "--yes", action="store_true", help="Auto-approve all tool actions (no confirmation prompts)")
    parser.add_argument("--no-resume", action="store_true", help="Start fresh, don't resume previous session")
    parser.add_argument("--version", action="version", version=f"pw-agent {VERSION}")

    args = parser.parse_args()

    console.print(BANNER.format(version=VERSION))

    # ─── Check for updates (non-blocking) ─────────────────────────────
    if not args.one_shot:
        latest = check_for_update()
        if latest:
            console.print(f"  [yellow]Update available: v{VERSION} → v{latest}[/yellow]  [dim]Run /update to install[/dim]")

    # ─── Load or run setup ────────────────────────────────────────────
    cfg = load_config()

    if args.setup or (not cfg and not args.token and not args.brain):
        # Check for local brain first
        brain_url = detect_brain_url()
        if brain_url and not args.setup:
            console.print(f"  [green]✓ Found local Ollama at {brain_url}[/green]")
            cfg = {"mode": "brain", "brain_url": brain_url, "config_dir": DEFAULT_CONFIG_DIR}
            try:
                import requests
                resp = requests.get(f"{brain_url}/api/tags", timeout=5)
                models = [m["name"] for m in resp.json().get("models", [])]
                if models:
                    cfg["model"] = models[0]
                    console.print(f"  [dim]Using model: {cfg['model']}[/dim]")
            except Exception:
                pass
            if "model" not in cfg:
                cfg = run_setup()
            else:
                save_config(cfg, DEFAULT_CONFIG_DIR)
        else:
            cfg = run_setup()

    # ─── Build client ─────────────────────────────────────────────────
    brain_url = args.brain or cfg.get("brain_url", "")
    token = args.token or cfg.get("token", "")
    device_id = args.device or cfg.get("device_id", "")
    slot = cfg.get("slot", 0)
    model = args.model or cfg.get("model", "")
    api_url = args.api_url

    if brain_url:
        if not model:
            try:
                import requests
                resp = requests.get(f"{brain_url}/api/tags", timeout=5)
                models = [m["name"] for m in resp.json().get("models", [])]
                if models:
                    model = models[0]
            except Exception:
                pass
        if not model:
            console.print("[red]No model found. Use --model to specify one.[/red]")
            sys.exit(1)
        client = LLMClient(brain_url=brain_url, model=model)
        console.print(f"  [dim]Mode: Direct brain ({brain_url})[/dim]")

    elif token:
        if not slot:
            temp = LLMClient(token=token, api_url=api_url)
            devices = temp.list_devices()
            if not devices:
                console.print("[red]No GPUs with LLM running found.[/red]")
                console.print("[dim]Start an LLM on https://pastawater.io/gpu-setup[/dim]")
                sys.exit(1)
            elif len(devices) == 1:
                slot = devices[0]["slot"]
                device_id = devices[0]["device_id"]
                model = model or devices[0]["llm_model"]
                console.print(f"  [green]✓ {devices[0]['device_name']}[/green] — {devices[0]['llm_model']} on {devices[0]['gpu']}")
            else:
                # Multiple models — let user pick
                console.print(f"\n  [bold]Multiple active models detected:[/bold]\n")
                for i, d in enumerate(devices, 1):
                    console.print(f"    [cyan]{i}[/cyan] — [bold]{d['device_name']}[/bold]  {d['llm_model']} on {d['gpu']} ({d['vram_gb']}GB)")
                console.print()
                pick = pt_prompt(f"  Choose engine [1-{len(devices)}]: ").strip()
                try:
                    chosen = devices[int(pick) - 1]
                except (ValueError, IndexError):
                    chosen = devices[0]
                slot = chosen["slot"]
                device_id = chosen["device_id"]
                model = model or chosen["llm_model"]
                console.print(f"  [green]✓ {chosen['device_name']}[/green] — {chosen['llm_model']} on {chosen['gpu']}")

        client = LLMClient(token=token, device_id=device_id, slot=slot, model=model, api_url=api_url)
        console.print(f"  [dim]Mode: PastaWater cloud ({cfg.get('device_name', device_id)})[/dim]")

    else:
        console.print("[red]No connection configured. Run: pw-agent --setup[/red]")
        sys.exit(1)

    # ─── Test connection ──────────────────────────────────────────────
    console.print("  [dim]Connecting...[/dim]")
    ok, msg = client.test_connection()
    if ok:
        console.print(f"  [green]✓ {msg}[/green]")
    else:
        console.print(f"  [red]✗ {msg}[/red]")
        console.print("  [dim]Run [bold]pw-agent --setup[/bold] to reconfigure.[/dim]")
        sys.exit(1)

    cwd = os.getcwd()
    console.print(f"  [dim]Working directory: {cwd}[/dim]")

    # ─── Auto-approve mode ────────────────────────────────────────────
    if args.yes:
        import tools as _tools
        _tools.AUTO_APPROVE = True
        console.print("  [bold red]⚠ Auto-approve mode — agent can modify files without asking[/bold red]")

    # ─── One-shot mode (-p "prompt") ──────────────────────────────────
    if args.one_shot:
        agent = Agent(client, stream=not args.no_stream)
        agent.run(args.one_shot)
        return

    # ─── Resume previous session ──────────────────────────────────────
    agent = Agent(client, stream=not args.no_stream)
    if not args.no_resume:
        from config import load_session
        prev = load_session(cwd)
        if prev:
            agent.load_session(prev)

    console.print(HELP_TEXT)

    history_file = os.path.join(cfg.get("config_dir", DEFAULT_CONFIG_DIR), "history")
    os.makedirs(os.path.dirname(history_file), exist_ok=True)
    session = PromptSession(
        history=FileHistory(history_file),
        auto_suggest=AutoSuggestFromHistory(),
        completer=PwCompleter(),
        complete_while_typing=False,
        key_bindings=_key_bindings(),
    )

    while True:
        try:
            user_input = session.prompt(
                [("class:prompt", "❯ ")],
                style=_prompt_style(),
            ).strip()
        except (KeyboardInterrupt, EOFError):
            console.print("\n[dim]Bye![/dim]")
            break

        if not user_input:
            continue

        while user_input.endswith("\\"):
            try:
                cont = session.prompt([("class:continuation", "… ")], style=_prompt_style())
                user_input = user_input[:-1] + "\n" + cont
            except (KeyboardInterrupt, EOFError):
                break

        # @file shorthand → /add file
        if user_input.startswith("@") and not user_input.startswith("@@"):
            filepath = user_input[1:].strip()
            if filepath:
                agent.add_file(filepath)
            continue

        if user_input.startswith("/"):
            parts = user_input.split(maxsplit=1)
            cmd = parts[0].lower()
            cmd_arg = parts[1].strip() if len(parts) > 1 else ""

            if cmd in ("/quit", "/exit", "/q"):
                console.print("[dim]Bye![/dim]")
                break
            elif cmd == "/help":
                console.print(HELP_TEXT)
            elif cmd == "/clear":
                agent.reset()
            elif cmd == "/add":
                if cmd_arg:
                    agent.add_file(cmd_arg)
                else:
                    console.print("  [yellow]Usage: /add <filepath>[/yellow]")
            elif cmd == "/diff":
                import subprocess
                result = subprocess.run(["git", "diff"], capture_output=True, text=True, timeout=10)
                if result.stdout.strip():
                    console.print(f"\n{result.stdout[:3000]}")
                else:
                    console.print("  [dim]No unstaged changes.[/dim]")
            elif cmd == "/commit":
                # Ask the LLM to generate a commit message from the diff
                import subprocess
                diff = subprocess.run(["git", "diff", "--staged"], capture_output=True, text=True, timeout=10)
                if not diff.stdout.strip():
                    diff = subprocess.run(["git", "diff"], capture_output=True, text=True, timeout=10)
                if not diff.stdout.strip():
                    console.print("  [dim]No changes to commit.[/dim]")
                else:
                    agent.run(f"Generate a concise git commit message for this diff, then run `git add -A && git commit -m \"<message>\"`. Here's the diff:\n\n```\n{diff.stdout[:3000]}\n```")
            elif cmd in ("/models", "/gpus", "/slots", "/model"):
                print_models(client)
            elif cmd == "/switch":
                if not cmd_arg:
                    console.print("  [yellow]Usage: /switch <slot number>[/yellow]")
                elif client.direct_mode:
                    console.print("  [yellow]Switch not available in direct brain mode.[/yellow]")
                else:
                    try:
                        new_slot = int(cmd_arg)
                    except ValueError:
                        console.print("  [yellow]Slot must be a number.[/yellow]")
                        continue
                    devices = client.list_devices()
                    target = next((d for d in devices if d["slot"] == new_slot), None)
                    if not target:
                        console.print(f"  [red]Slot {new_slot} not found or has no LLM running.[/red]")
                    else:
                        client.slot = new_slot
                        client.device_id = target["device_id"]
                        client.model = target["llm_model"]
                        console.print(f"  [green]✓ Switched to slot {new_slot}: {target['llm_model']} on {target['gpu']}[/green]")
            elif cmd == "/update":
                if do_update():
                    console.print("[dim]Bye![/dim]")
                    break
            elif cmd == "/config":
                for k, v in cfg.items():
                    val = v if k != "token" else f"{v[:12]}...{v[-4:]}"
                    console.print(f"  [cyan]{k}:[/cyan] {val}")
                console.print()
            elif cmd == "/logout":
                from config import _config_path
                path = _config_path(cfg.get("config_dir", ""))
                if os.path.exists(path):
                    os.remove(path)
                    console.print("  [dim]Config cleared. Run pw-agent --setup to reconfigure.[/dim]")
                else:
                    console.print("  [dim]No config found.[/dim]")
            else:
                console.print(f"  [yellow]Unknown command: {cmd}[/yellow]")
            continue

        agent.run(user_input)
        console.print()


class PwCompleter(Completer):
    """Tab-completes slash commands and file paths after /add or @."""

    COMMANDS = [
        ("/help", "Show help"),
        ("/add", "Add file to context"),
        ("/clear", "Clear conversation"),
        ("/commit", "Git commit with AI message"),
        ("/diff", "Show git diff"),
        ("/models", "Show fleet GPUs"),
        ("/switch", "Switch GPU slot"),
        ("/update", "Update to latest version"),
        ("/config", "Show config"),
        ("/logout", "Clear saved config"),
        ("/quit", "Exit"),
    ]

    def __init__(self):
        self._path_completer = PathCompleter(expanduser=True)

    def get_completions(self, document, complete_event):
        text = document.text_before_cursor

        # Slash command completion
        if text.startswith("/"):
            for cmd, desc in self.COMMANDS:
                if cmd.startswith(text):
                    yield Completion(cmd, start_position=-len(text), display_meta=desc)

            # File path after /add
            if text.startswith("/add "):
                sub_doc = document.__class__(text[5:], cursor_position=len(text) - 5)
                for c in self._path_completer.get_completions(sub_doc, complete_event):
                    yield c

            # Slot number after /switch
            if text.startswith("/switch "):
                for n in range(1, 10):
                    s = str(n)
                    partial = text[8:]
                    if s.startswith(partial):
                        yield Completion(s, start_position=-len(partial), display_meta=f"Slot {n}")
            return

        # @file path completion
        if text.startswith("@"):
            sub_doc = document.__class__(text[1:], cursor_position=len(text) - 1)
            for c in self._path_completer.get_completions(sub_doc, complete_event):
                yield c


def _key_bindings():
    """Custom key bindings — Tab accepts auto-suggestion."""
    kb = KeyBindings()

    @kb.add("tab")
    def _(event):
        buf = event.app.current_buffer
        suggestion = buf.suggestion
        if suggestion:
            buf.insert_text(suggestion.text)
        elif buf.complete_state:
            buf.complete_next()
        else:
            buf.start_completion()

    return kb


def _prompt_style():
    from prompt_toolkit.styles import Style
    return Style.from_dict({
        "prompt": "ansibrightcyan bold",
        "continuation": "ansigray",
    })


if __name__ == "__main__":
    main()
