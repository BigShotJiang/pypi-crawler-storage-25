"""Tests for the SecurityGate (BC.6.1).

Covers the three independent gates — allowlist, rate-limit, and pause —
in isolation, plus their interaction with handlers.handle dispatch.
"""
from __future__ import annotations

from unittest.mock import MagicMock

import pytest

from maestro_browser_bridge.handlers import handle
from maestro_browser_bridge.playwright_session import PlaywrightSession, TabState
from maestro_browser_bridge.protocol import BrowserCommand, BrowserCommandPayload
from maestro_browser_bridge.security import SecurityGate


# ── Allowlist ─────────────────────────────────────────────────────────


def test_allowlist_accepts_default_hosts():
    gate = SecurityGate()
    assert gate.check_navigate_allowed("https://github.com") is None
    assert gate.check_navigate_allowed("https://pypi.org/project/x") is None


def test_allowlist_accepts_subdomain_via_dot_suffix():
    gate = SecurityGate()
    # github.io is on the default list — foo.github.io matches by suffix.
    assert gate.check_navigate_allowed("https://foo.github.io/page") is None


def test_allowlist_rejects_unknown_host():
    gate = SecurityGate()
    err = gate.check_navigate_allowed("https://evil.test/")
    assert err is not None
    assert "allowlist" in err.lower()


def test_allowlist_rejects_lookalike_suffix():
    """``evil-github.com`` must not be accepted just because ``github.com`` is."""
    gate = SecurityGate()
    err = gate.check_navigate_allowed("https://evil-github.com/")
    assert err is not None


def test_allowlist_extra_normalizes_www_prefix():
    gate = SecurityGate(allowlist_extra=["www.example.com"])
    assert "example.com" in gate.allowlist
    assert gate.check_navigate_allowed("https://example.com/") is None
    assert gate.check_navigate_allowed("https://www.example.com/") is None


def test_allowlist_rejects_malformed_url():
    gate = SecurityGate()
    err = gate.check_navigate_allowed("not a url at all")
    assert err is not None


# ── Rate limit ────────────────────────────────────────────────────────


def test_rate_limit_allows_within_budget():
    gate = SecurityGate(rate_limit_per_min=3)
    assert gate.check_and_record_rate() is None
    assert gate.check_and_record_rate() is None
    assert gate.check_and_record_rate() is None


def test_rate_limit_rejects_when_budget_spent():
    gate = SecurityGate(rate_limit_per_min=2)
    assert gate.check_and_record_rate() is None
    assert gate.check_and_record_rate() is None
    err = gate.check_and_record_rate()
    assert err is not None
    assert "rate_limited" in err


def test_rate_limit_failing_call_does_not_count(monkeypatch):
    """A rejected call mustn't extend its own cooldown."""
    gate = SecurityGate(rate_limit_per_min=1)
    assert gate.check_and_record_rate() is None
    # Second call rejected.
    assert gate.check_and_record_rate() is not None
    # Internal deque should still only contain the one successful entry.
    assert len(gate._stamps) == 1


# ── Pause / kill switch ───────────────────────────────────────────────


def test_pause_state_round_trips():
    gate = SecurityGate()
    assert gate.paused is False
    gate.pause()
    assert gate.paused is True
    err = gate.check_paused()
    assert err is not None
    assert "bridge_paused" in err
    gate.resume()
    assert gate.paused is False
    assert gate.check_paused() is None


# ── Dispatch integration ──────────────────────────────────────────────


def _make_session(gate: SecurityGate) -> PlaywrightSession:
    """Build a session with the given gate + a mocked page."""
    session = PlaywrightSession(machine_id="test", security=gate)
    page = MagicMock(name="Page")
    page.url = "https://x.test"
    page.title = MagicMock(return_value="x")
    # Async methods need AsyncMock — but handle() never calls them on
    # the paused / rejected paths, so plain MagicMock is enough here.
    state = TabState(tab_id="test", page=page)
    session._tabs["test"] = state
    return session


def _cmd(action: str, **kwargs) -> BrowserCommand:
    return BrowserCommand(
        user_id="u",
        command_id=f"c-{action}",
        sandbox_id="test",
        payload=BrowserCommandPayload(action=action, **kwargs),  # type: ignore[arg-type]
    )


async def test_dispatch_returns_paused_error_when_kill_switch_active():
    gate = SecurityGate(allowlist_extra=["example.com"])
    gate.pause()
    session = _make_session(gate)
    result = await handle(_cmd("navigate", url="https://example.com"), session)
    assert result.payload.ok is False
    assert "bridge_paused" in (result.error or "")


async def test_dispatch_returns_allowlist_error_on_navigate():
    gate = SecurityGate()  # default allowlist, doesn't include example.com
    session = _make_session(gate)
    result = await handle(_cmd("navigate", url="https://example.com"), session)
    assert result.payload.ok is False
    assert "allowlist" in (result.error or "")


async def test_dispatch_rate_limits():
    gate = SecurityGate(allowlist_extra=["example.com"], rate_limit_per_min=2)
    session = _make_session(gate)
    # The two allowed nav calls reach the handler (which errors on the
    # mocked Page's missing async methods); both still consume a slot
    # because rate-record happens BEFORE handler dispatch.
    await handle(_cmd("navigate", url="https://example.com"), session)
    await handle(_cmd("navigate", url="https://example.com"), session)
    # Third should be rate-limited before the handler.
    result = await handle(_cmd("navigate", url="https://example.com"), session)
    assert result.payload.ok is False
    assert "rate_limited" in (result.error or "")
