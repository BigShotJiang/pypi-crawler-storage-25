"""CliRunner smoke tests — make sure the click surface is wired."""

from __future__ import annotations

import json
from pathlib import Path

import pytest
from click.testing import CliRunner

from maestro_browser_bridge import cli as cli_module
from maestro_browser_bridge.cli import cli


@pytest.fixture
def runner() -> CliRunner:
    return CliRunner()


# ---------------------------------------------------------------------------
# Top-level
# ---------------------------------------------------------------------------


def test_cli_version_prints_package_version(runner: CliRunner) -> None:
    result = runner.invoke(cli, ["--version"])
    assert result.exit_code == 0
    # Should print "maestro-browser-bridge, version X.Y.Z" or similar.
    assert "maestro-browser-bridge" in result.output


def test_cli_help_lists_subcommands(runner: CliRunner) -> None:
    result = runner.invoke(cli, ["--help"])
    assert result.exit_code == 0
    for sub in ("configure", "start", "stop", "status", "install-service"):
        assert sub in result.output


# ---------------------------------------------------------------------------
# Subcommand --help
# ---------------------------------------------------------------------------


@pytest.mark.parametrize("sub", ["configure", "start", "stop", "status", "install-service"])
def test_subcommand_help_works(runner: CliRunner, sub: str) -> None:
    result = runner.invoke(cli, [sub, "--help"])
    assert result.exit_code == 0
    assert sub in result.output or "Usage" in result.output


# ---------------------------------------------------------------------------
# configure
# ---------------------------------------------------------------------------


def test_configure_writes_file(
    runner: CliRunner, tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    """``configure`` should write the JSON config to the expected path."""
    # Redirect ~/.maestro to a temp dir for the duration of the test.
    fake_home = tmp_path / "home"
    fake_home.mkdir()
    monkeypatch.setenv("HOME", str(fake_home))

    # Reimport the config module so it re-reads HOME for its module-level
    # constants. ``importlib.reload`` is the official way to do this.
    import importlib

    from maestro_browser_bridge import config as config_module

    importlib.reload(config_module)
    # The CLI module captured a reference to the old CONFIG_FILE constant;
    # reload it too so subsequent CLI calls see the new path.
    importlib.reload(cli_module)

    try:
        result = runner.invoke(
            cli_module.cli,
            [
                "configure",
                "--relay-url",
                "wss://relay.example.com",
                "--user-id",
                "user-123",
                "--user-token",
                "tok-abc",
            ],
        )
        assert result.exit_code == 0, result.output

        config_file = fake_home / ".maestro" / "bridge-config.json"
        assert config_file.exists()
        data = json.loads(config_file.read_text())
        assert data["relay_url"] == "wss://relay.example.com"
        assert data["user_id"] == "user-123"
        assert data["user_token"] == "tok-abc"
        # Default port should come through.
        assert data["port"] == 7654

        # File permissions should be 0600 — same posture as the agent config.
        assert (config_file.stat().st_mode & 0o777) == 0o600
    finally:
        # Reset module-level state so other tests see the real ~/.maestro.
        importlib.reload(config_module)
        importlib.reload(cli_module)


# ---------------------------------------------------------------------------
# status when no config
# ---------------------------------------------------------------------------


def test_status_without_config(
    runner: CliRunner, tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    monkeypatch.setenv("HOME", str(tmp_path))

    import importlib

    from maestro_browser_bridge import config as config_module

    importlib.reload(config_module)
    importlib.reload(cli_module)

    try:
        result = runner.invoke(cli_module.cli, ["status"])
        assert result.exit_code == 0
        assert "maestro-browser-bridge" in result.output
        assert "NOT CONFIGURED" in result.output
    finally:
        importlib.reload(config_module)
        importlib.reload(cli_module)


# ---------------------------------------------------------------------------
# start --detach (currently exits non-zero with a stub message)
# ---------------------------------------------------------------------------


def test_start_detach_exits_non_zero(runner: CliRunner) -> None:
    result = runner.invoke(cli, ["start", "--detach"])
    assert result.exit_code == 1
    assert "detach not yet implemented" in result.output
