"""Tests for ``handlers.handle`` — dispatch + per-action coverage.

These tests use the ``fake_session`` fixture (see conftest.py) which
stubs Playwright with mocks so the suite runs without the runtime
installed. Per-handler tests assert the right Playwright primitives are
called with the right args, and that the returned ``BrowserResult`` is
shaped correctly.
"""

from __future__ import annotations

import base64
from unittest.mock import AsyncMock, MagicMock

import pytest

from maestro_browser_bridge.handlers import _HANDLERS, handle
from maestro_browser_bridge.playwright_session import PlaywrightSession
from maestro_browser_bridge.protocol import (
    BrowserAction,
    BrowserCommand,
    BrowserCommandPayload,
)


ALL_ACTIONS: list[BrowserAction] = [
    "navigate",
    "click",
    "type",
    "screenshot",
    "read_dom",
    "console_logs",
    "list_tabs",
    "keypress",
    "scroll",
    "allowlist_add",
]


def _cmd(action: BrowserAction, **payload_kwargs) -> BrowserCommand:
    """Build a syntactically-valid command targeting the default tab."""
    return BrowserCommand(
        user_id="u1",
        command_id=f"cmd-{action}",
        sandbox_id="test-tab",  # matches the pre-populated tab in fake_session
        payload=BrowserCommandPayload(action=action, **payload_kwargs),
    )


# ---------------------------------------------------------------------------
# Dispatch behaviour
# ---------------------------------------------------------------------------


async def test_dispatch_table_covers_every_action() -> None:
    """Guard against ``BrowserAction`` adding a value without a handler."""
    assert set(_HANDLERS.keys()) == set(ALL_ACTIONS)


async def test_handle_returns_json_serializable_envelope(
    fake_session: PlaywrightSession,
) -> None:
    cmd = _cmd("navigate", url="https://example.com")
    result = await handle(cmd, fake_session)
    dumped = result.model_dump(mode="json")
    assert dumped["type"] == "BROWSER_RESULT"
    assert dumped["command_id"] == cmd.command_id
    assert dumped["payload"]["ok"] is True


async def test_unknown_action_returns_error(
    fake_session: PlaywrightSession,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    """Bypass the pydantic Literal by patching the dispatch table directly."""
    monkeypatch.setitem(_HANDLERS, "navigate", None)  # type: ignore[arg-type]
    # Now pretend navigate isn't in the table — handle should still
    # return a clean BrowserResult.
    monkeypatch.delitem(_HANDLERS, "navigate")
    cmd = _cmd("navigate", url="https://example.com")
    result = await handle(cmd, fake_session)
    assert result.payload.ok is False
    assert result.error and "unknown action" in result.error


async def test_handler_value_error_surfaced_verbatim(
    fake_session: PlaywrightSession,
) -> None:
    """Missing required field → BrowserResult(ok=False, error=<msg>)."""
    cmd = _cmd("navigate")  # url omitted
    result = await handle(cmd, fake_session)
    assert result.payload.ok is False
    assert result.error == "navigate requires 'url'"


async def test_handler_generic_exception_caught(
    fake_session: PlaywrightSession,
    fake_page: MagicMock,
) -> None:
    """Unexpected exceptions are caught and wrapped with class name."""
    fake_page.goto = AsyncMock(side_effect=RuntimeError("boom"))
    cmd = _cmd("navigate", url="https://example.com")
    result = await handle(cmd, fake_session)
    assert result.payload.ok is False
    assert result.error == "RuntimeError: boom"


# ---------------------------------------------------------------------------
# Per-action handlers
# ---------------------------------------------------------------------------


async def test_navigate_calls_goto_and_returns_url_title(
    fake_session: PlaywrightSession,
    fake_page: MagicMock,
) -> None:
    fake_page.url = "https://example.com/after"
    fake_page.title.return_value = "Example"
    cmd = _cmd("navigate", url="https://example.com")
    result = await handle(cmd, fake_session)
    fake_page.goto.assert_awaited_once_with(
        "https://example.com", wait_until="domcontentloaded"
    )
    assert result.payload.ok is True
    assert result.payload.current_url == "https://example.com/after"
    assert result.payload.title == "Example"


async def test_navigate_missing_url_fails(
    fake_session: PlaywrightSession,
) -> None:
    cmd = _cmd("navigate")
    result = await handle(cmd, fake_session)
    assert result.payload.ok is False
    assert "url" in (result.error or "")


async def test_navigate_new_tab_spawns_fresh_tab(
    fake_session: PlaywrightSession,
) -> None:
    cmd = _cmd("navigate", url="https://example.com", new_tab=True)
    result = await handle(cmd, fake_session)
    assert result.payload.ok is True
    # The fixture's stub appends ``-fresh`` to the tab id when new_tab=True.
    assert "test-tab-fresh" in fake_session._tabs


async def test_click_calls_locator_click(
    fake_session: PlaywrightSession,
    fake_page: MagicMock,
) -> None:
    cmd = _cmd("click", selector="button#submit")
    result = await handle(cmd, fake_session)
    fake_page.locator.assert_called_once_with("button#submit")
    locator = fake_page.locator.return_value
    # We can't assert on the cached locator return_value directly because
    # ``side_effect`` builds a fresh mock per call. Verify the click via
    # the side_effect-returned object by re-inspecting call list.
    assert result.payload.ok is True
    # Regression: a normal CSS selector must NOT take the coords branch.
    fake_page.mouse.click.assert_not_called()


async def test_click_missing_selector_fails(
    fake_session: PlaywrightSession,
) -> None:
    cmd = _cmd("click")
    result = await handle(cmd, fake_session)
    assert result.payload.ok is False
    assert "selector" in (result.error or "")


async def test_click_coords_selector_dispatches_to_mouse_click(
    fake_session: PlaywrightSession,
    fake_page: MagicMock,
) -> None:
    """``__coords:x,y`` should call page.mouse.click(x, y), not page.locator."""
    cmd = _cmd("click", selector="__coords:100,200")
    result = await handle(cmd, fake_session)
    assert result.payload.ok is True
    fake_page.mouse.click.assert_awaited_once_with(100.0, 200.0)
    # The locator path must not be taken for coord-shaped selectors.
    fake_page.locator.assert_not_called()


async def test_click_coords_selector_malformed_returns_clean_error(
    fake_session: PlaywrightSession,
    fake_page: MagicMock,
) -> None:
    """Garbage after the ``__coords:`` prefix must produce ok=False, not crash."""
    cmd = _cmd("click", selector="__coords:abc,def")
    result = await handle(cmd, fake_session)
    assert result.payload.ok is False
    assert result.error and "coords" in result.error
    # Neither click path should have been invoked.
    fake_page.mouse.click.assert_not_called()
    fake_page.locator.assert_not_called()


async def test_type_calls_locator_type(
    fake_session: PlaywrightSession,
    fake_page: MagicMock,
) -> None:
    cmd = _cmd("type", selector="input[name=q]", text="hello")
    result = await handle(cmd, fake_session)
    fake_page.locator.assert_called_once_with("input[name=q]")
    assert result.payload.ok is True


async def test_type_missing_text_fails(
    fake_session: PlaywrightSession,
) -> None:
    cmd = _cmd("type", selector="input")
    result = await handle(cmd, fake_session)
    assert result.payload.ok is False
    assert "text" in (result.error or "")


async def test_type_focused_selector_uses_keyboard(
    fake_session: PlaywrightSession,
    fake_page: MagicMock,
) -> None:
    """``__focused`` should call page.keyboard.type, bypassing the locator."""
    cmd = _cmd("type", selector="__focused", text="hello")
    result = await handle(cmd, fake_session)
    assert result.payload.ok is True
    fake_page.keyboard.type.assert_awaited_once_with("hello")
    fake_page.locator.assert_not_called()


async def test_keypress_calls_keyboard_press(
    fake_session: PlaywrightSession,
    fake_page: MagicMock,
) -> None:
    cmd = _cmd("keypress", key="Enter")
    result = await handle(cmd, fake_session)
    assert result.payload.ok is True
    fake_page.keyboard.press.assert_awaited_once_with("Enter")


async def test_keypress_missing_key_fails(
    fake_session: PlaywrightSession,
) -> None:
    cmd = _cmd("keypress")
    result = await handle(cmd, fake_session)
    assert result.payload.ok is False
    assert "key" in (result.error or "")


async def test_scroll_calls_mouse_wheel_with_deltas(
    fake_session: PlaywrightSession,
    fake_page: MagicMock,
) -> None:
    cmd = _cmd("scroll", dx=10.0, dy=200.0)
    result = await handle(cmd, fake_session)
    assert result.payload.ok is True
    fake_page.mouse.wheel.assert_awaited_once_with(10.0, 200.0)


async def test_scroll_defaults_missing_deltas_to_zero(
    fake_session: PlaywrightSession,
    fake_page: MagicMock,
) -> None:
    cmd = _cmd("scroll", dy=120.0)  # dx omitted
    result = await handle(cmd, fake_session)
    assert result.payload.ok is True
    fake_page.mouse.wheel.assert_awaited_once_with(0.0, 120.0)


async def test_allowlist_add_grows_runtime_allowlist(
    fake_session: PlaywrightSession,
) -> None:
    """allowlist_add inserts into security.allowlist + lifts the gate."""
    assert "play.google.com" not in fake_session.security.allowlist
    cmd = _cmd("allowlist_add", host="play.google.com")
    result = await handle(cmd, fake_session)
    assert result.payload.ok is True
    assert "play.google.com" in fake_session.security.allowlist
    # Re-checking navigate against the now-allowed host should pass.
    assert fake_session.security.check_navigate_allowed("https://play.google.com/console") is None


async def test_allowlist_add_persists_via_callback() -> None:
    """The persist_extra_cb hook fires with the updated allowlist_extra."""
    from maestro_browser_bridge.security import SecurityGate
    captured: list[list[str]] = []
    gate = SecurityGate(
        allowlist_extra=["already-here.example"],
        rate_limit_per_min=10_000,
        persist_extra_cb=lambda updated: captured.append(updated),
    )
    gate.add_host("new.example")
    assert captured  # callback fired
    assert sorted(captured[-1]) == ["already-here.example", "new.example"]


async def test_allowlist_add_missing_host_fails(
    fake_session: PlaywrightSession,
) -> None:
    cmd = _cmd("allowlist_add")
    result = await handle(cmd, fake_session)
    assert result.payload.ok is False
    assert "host" in (result.error or "")


async def test_allowlist_add_malformed_host_fails(
    fake_session: PlaywrightSession,
) -> None:
    cmd = _cmd("allowlist_add", host="not a hostname at all")
    result = await handle(cmd, fake_session)
    assert result.payload.ok is False
    assert "invalid host" in (result.error or "")


async def test_navigate_block_populates_denied_host(
    fake_session: PlaywrightSession,
) -> None:
    """Allowlist-block result carries the bare host in BrowserResultPayload.denied_host."""
    # ``.invalid`` is reserved by RFC 2606 and won't suffix-match any
    # default or test-fixture allowlist entry.
    cmd = _cmd("navigate", url="https://blocked.invalid/foo")
    result = await handle(cmd, fake_session)
    assert result.payload.ok is False
    assert result.payload.denied_host == "blocked.invalid"
    assert "allowlist_block:" in (result.error or "")


async def test_screenshot_returns_base64(
    fake_session: PlaywrightSession,
    fake_page: MagicMock,
) -> None:
    fake_page.screenshot.return_value = b"\x89PNG-bytes"
    cmd = _cmd("screenshot", full_page=True)
    result = await handle(cmd, fake_session)
    fake_page.screenshot.assert_awaited_once_with(full_page=True)
    assert result.payload.ok is True
    assert result.payload.screenshot_b64 == base64.b64encode(b"\x89PNG-bytes").decode("ascii")


async def test_screenshot_includes_viewport_dimensions(
    fake_session: PlaywrightSession,
    fake_page: MagicMock,
) -> None:
    fake_page.evaluate = AsyncMock(return_value={"w": 1366, "h": 768})
    cmd = _cmd("screenshot")
    result = await handle(cmd, fake_session)
    assert result.payload.viewport_w == 1366
    assert result.payload.viewport_h == 768


async def test_screenshot_viewport_read_failure_does_not_abort(
    fake_session: PlaywrightSession,
    fake_page: MagicMock,
) -> None:
    """Viewport reporting is best-effort — a JS eval crash shouldn't fail the shot."""
    fake_page.evaluate = AsyncMock(side_effect=RuntimeError("eval blew up"))
    cmd = _cmd("screenshot")
    result = await handle(cmd, fake_session)
    assert result.payload.ok is True
    assert result.payload.screenshot_b64 is not None
    assert result.payload.viewport_w is None
    assert result.payload.viewport_h is None


async def test_screenshot_defaults_full_page_false(
    fake_session: PlaywrightSession,
    fake_page: MagicMock,
) -> None:
    cmd = _cmd("screenshot")
    await handle(cmd, fake_session)
    fake_page.screenshot.assert_awaited_once_with(full_page=False)


async def test_read_dom_with_selector_returns_outer_html(
    fake_session: PlaywrightSession,
    fake_page: MagicMock,
) -> None:
    cmd = _cmd("read_dom", selector="#root")
    result = await handle(cmd, fake_session)
    fake_page.locator.assert_called_once_with("#root")
    assert result.payload.ok is True
    assert result.payload.dom_snippet == "<div>html</div>"


async def test_read_dom_without_selector_returns_page_content(
    fake_session: PlaywrightSession,
    fake_page: MagicMock,
) -> None:
    fake_page.content.return_value = "<html><body>whole page</body></html>"
    cmd = _cmd("read_dom")
    result = await handle(cmd, fake_session)
    fake_page.content.assert_awaited_once()
    assert result.payload.dom_snippet == "<html><body>whole page</body></html>"


async def test_read_dom_truncates_huge_payload(
    fake_session: PlaywrightSession,
    fake_page: MagicMock,
) -> None:
    huge = "a" * 2_000_000
    fake_page.content.return_value = huge
    cmd = _cmd("read_dom")
    result = await handle(cmd, fake_session)
    assert result.payload.dom_snippet is not None
    assert len(result.payload.dom_snippet.encode("utf-8")) <= 1_000_000


async def test_console_logs_drains_buffer(
    fake_session: PlaywrightSession,
) -> None:
    # Seed the pre-populated tab's console buffer.
    state = fake_session._tabs["test-tab"]
    state.console.append({"ts": 1.0, "level": "log", "text": "hello"})
    state.console.append({"ts": 2.0, "level": "error", "text": "boom"})

    cmd = _cmd("console_logs")
    result = await handle(cmd, fake_session)
    assert result.payload.ok is True
    assert result.payload.console_logs is not None
    assert len(result.payload.console_logs) == 2


async def test_console_logs_filters_by_since_ts(
    fake_session: PlaywrightSession,
) -> None:
    state = fake_session._tabs["test-tab"]
    state.console.append({"ts": 1.0, "level": "log", "text": "old"})
    state.console.append({"ts": 5.0, "level": "log", "text": "new"})

    cmd = _cmd("console_logs", since_ts=2.0)
    result = await handle(cmd, fake_session)
    assert result.payload.console_logs is not None
    assert len(result.payload.console_logs) == 1
    assert result.payload.console_logs[0]["text"] == "new"


async def test_list_tabs_returns_tabs_via_console_logs_slot(
    fake_session: PlaywrightSession,
    fake_page: MagicMock,
) -> None:
    fake_page.url = "https://example.com"
    fake_page.title.return_value = "Example"
    cmd = _cmd("list_tabs")
    result = await handle(cmd, fake_session)
    assert result.payload.ok is True
    # BC.1.2 carries the list through console_logs until BC.3 adds a
    # typed field — see the comment in handlers.handle_list_tabs.
    assert result.payload.console_logs is not None
    assert any(t.get("tab_id") == "test-tab" for t in result.payload.console_logs)
