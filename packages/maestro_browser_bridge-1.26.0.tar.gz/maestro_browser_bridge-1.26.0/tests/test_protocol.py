"""Exercise the pydantic models for the BROWSER_* wire protocol."""

from __future__ import annotations

import pytest
from pydantic import ValidationError

from maestro_browser_bridge.protocol import (
    BrowserCommand,
    BrowserCommandPayload,
    BrowserEvent,
    BrowserEventPayload,
    BrowserResult,
    BrowserResultPayload,
)


# ---------------------------------------------------------------------------
# BrowserCommand
# ---------------------------------------------------------------------------


def test_browser_command_minimal_navigate_roundtrips() -> None:
    """A minimal navigate command should round-trip through JSON cleanly."""
    cmd = BrowserCommand(
        user_id="u1",
        command_id="c1",
        sandbox_id="s1",
        payload=BrowserCommandPayload(action="navigate", url="https://example.com"),
    )
    dumped = cmd.model_dump(mode="json")
    assert dumped["type"] == "BROWSER_COMMAND"
    assert dumped["payload"]["action"] == "navigate"
    assert dumped["payload"]["url"] == "https://example.com"
    # ts is auto-populated
    assert isinstance(dumped["ts"], float)

    roundtripped = BrowserCommand.model_validate(dumped)
    assert roundtripped.payload.action == "navigate"
    assert roundtripped.command_id == "c1"


def test_browser_command_click_with_selector() -> None:
    cmd = BrowserCommand(
        user_id="u1",
        command_id="c2",
        sandbox_id="s1",
        payload=BrowserCommandPayload(action="click", selector="#submit"),
    )
    assert cmd.payload.selector == "#submit"
    assert cmd.payload.url is None


def test_browser_command_screenshot_full_page() -> None:
    cmd = BrowserCommand(
        user_id="u1",
        command_id="c3",
        sandbox_id="s1",
        payload=BrowserCommandPayload(action="screenshot", full_page=True),
    )
    assert cmd.payload.full_page is True


def test_browser_command_rejects_unknown_action() -> None:
    """Strict Literal — anything outside the action set is a ValidationError."""
    with pytest.raises(ValidationError):
        BrowserCommandPayload(action="teleport")  # type: ignore[arg-type]


def test_browser_command_rejects_extra_fields() -> None:
    """``extra='forbid'`` should reject typos / protocol drift loudly."""
    with pytest.raises(ValidationError):
        BrowserCommand.model_validate({
            "type": "BROWSER_COMMAND",
            "user_id": "u1",
            "command_id": "c4",
            "sandbox_id": "s1",
            "payload": {"action": "navigate"},
            "unknown_extra_field": "boom",
        })


# ---------------------------------------------------------------------------
# BrowserResult
# ---------------------------------------------------------------------------


def test_browser_result_success() -> None:
    result = BrowserResult(
        command_id="c1",
        payload=BrowserResultPayload(
            ok=True,
            current_url="https://example.com/",
            title="Example",
        ),
    )
    dumped = result.model_dump(mode="json")
    assert dumped["type"] == "BROWSER_RESULT"
    assert dumped["payload"]["ok"] is True
    assert dumped["payload"]["current_url"] == "https://example.com/"
    assert dumped["error"] is None


def test_browser_result_failure_with_error() -> None:
    result = BrowserResult(
        command_id="c2",
        payload=BrowserResultPayload(ok=False),
        error="not yet implemented: navigate",
    )
    assert result.payload.ok is False
    assert "navigate" in (result.error or "")

    roundtripped = BrowserResult.model_validate(result.model_dump(mode="json"))
    assert roundtripped.error == result.error


def test_browser_result_with_console_logs() -> None:
    result = BrowserResult(
        command_id="c3",
        payload=BrowserResultPayload(
            ok=True,
            console_logs=[{"level": "log", "text": "hello"}],
        ),
    )
    assert result.payload.console_logs == [{"level": "log", "text": "hello"}]


# ---------------------------------------------------------------------------
# BrowserEvent
# ---------------------------------------------------------------------------


def test_browser_event_minimal() -> None:
    ev = BrowserEvent(
        payload=BrowserEventPayload(
            event="navigation_started",
            tab_id="tab-1",
            data={"url": "https://example.com"},
        ),
    )
    dumped = ev.model_dump(mode="json")
    assert dumped["type"] == "BROWSER_EVENT"
    assert dumped["payload"]["event"] == "navigation_started"
    assert dumped["payload"]["data"] == {"url": "https://example.com"}


def test_browser_event_data_defaults_to_empty_dict() -> None:
    ev = BrowserEvent(
        payload=BrowserEventPayload(event="console_message"),
    )
    assert ev.payload.data == {}
    assert ev.payload.tab_id is None
