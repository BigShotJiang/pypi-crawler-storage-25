"""Smoke tests for the bridge daemon's local 127.0.0.1 server (BC.3.1).

We don't spin up real Chromium — the test patches ``handlers.handle`` so
we can verify the on-wire surface (JSON in, JSON out, PING/PONG, errors)
without Playwright in the loop. The relay loop is asserted indirectly
via tests/test_bridge_lifecycle.py (relay side); here we just guarantee
the local-server dispatch is in shape for ``websocat`` debugging.
"""

from __future__ import annotations

import asyncio
import json
import socket
from unittest.mock import AsyncMock, patch

import pytest
import websockets

from maestro_browser_bridge.config import BridgeConfig
from maestro_browser_bridge.daemon import BridgeDaemon
from maestro_browser_bridge.protocol import BrowserResult, BrowserResultPayload

pytestmark = pytest.mark.asyncio


def _free_port() -> int:
    """Pick a random free loopback port. Avoids 7654 collisions on dev machines."""
    s = socket.socket()
    try:
        s.bind(("127.0.0.1", 0))
        return s.getsockname()[1]
    finally:
        s.close()


async def _run_daemon_in_background(daemon: BridgeDaemon) -> asyncio.Task:
    """Run daemon.run() in a task and wait until the local server binds."""
    task = asyncio.create_task(daemon.run())
    # Poll for the listener — _run_local_server emits a log line on bind
    # but we have no direct readiness flag. Connect-retry is simpler.
    for _ in range(50):
        try:
            ws = await websockets.connect(f"ws://127.0.0.1:{daemon.config.port}")
            await ws.close()
            return task
        except (ConnectionRefusedError, OSError):
            await asyncio.sleep(0.05)
    raise RuntimeError("local server did not bind in time")


@pytest.fixture
async def daemon():
    port = _free_port()
    cfg = BridgeConfig(
        relay_url="ws://127.0.0.1:1",  # unreachable on purpose — relay loop noisily fails
        user_id="u-1",
        user_token="t",
        port=port,
    )
    d = BridgeDaemon(cfg)

    # Patch the session start/stop so we don't try to launch Chromium.
    d.session.start = AsyncMock(return_value=None)
    d.session.stop = AsyncMock(return_value=None)

    task = await _run_daemon_in_background(d)
    try:
        yield d
    finally:
        d.stop()
        try:
            await asyncio.wait_for(task, timeout=3.0)
        except asyncio.TimeoutError:
            task.cancel()


async def test_local_server_ping_pong(daemon: BridgeDaemon) -> None:
    async with websockets.connect(f"ws://127.0.0.1:{daemon.config.port}") as ws:
        await ws.send(json.dumps({"type": "PING"}))
        reply = json.loads(await ws.recv())
        assert reply == {"type": "PONG"}


async def test_local_server_rejects_invalid_json(daemon: BridgeDaemon) -> None:
    async with websockets.connect(f"ws://127.0.0.1:{daemon.config.port}") as ws:
        await ws.send("not json")
        reply = json.loads(await ws.recv())
        assert reply["type"] == "ERROR"
        assert "invalid json" in reply["error"].lower()


async def test_local_server_unknown_type(daemon: BridgeDaemon) -> None:
    async with websockets.connect(f"ws://127.0.0.1:{daemon.config.port}") as ws:
        await ws.send(json.dumps({"type": "MYSTERY"}))
        reply = json.loads(await ws.recv())
        assert reply["type"] == "ERROR"


async def test_local_server_dispatches_browser_command(daemon: BridgeDaemon) -> None:
    """Send a BROWSER_COMMAND end-to-end through the local surface.

    handlers.handle is patched to return a known BrowserResult so we
    don't drive the actual Playwright path.
    """
    fake_result = BrowserResult(
        command_id="c-1",
        payload=BrowserResultPayload(ok=True, current_url="https://x.test"),
    )

    with patch(
        "maestro_browser_bridge.daemon.handle",
        new=AsyncMock(return_value=fake_result),
    ):
        async with websockets.connect(f"ws://127.0.0.1:{daemon.config.port}") as ws:
            await ws.send(json.dumps({
                "type": "BROWSER_COMMAND",
                "user_id": "u-1",
                "command_id": "c-1",
                "sandbox_id": "s-1",
                "payload": {"action": "navigate", "url": "https://x.test"},
            }))
            reply = json.loads(await ws.recv())
            assert reply["type"] == "BROWSER_RESULT"
            assert reply["command_id"] == "c-1"
            assert reply["payload"]["ok"] is True


async def test_local_server_validation_error(daemon: BridgeDaemon) -> None:
    """Malformed BROWSER_COMMAND (missing required fields) → ERROR reply."""
    async with websockets.connect(f"ws://127.0.0.1:{daemon.config.port}") as ws:
        await ws.send(json.dumps({"type": "BROWSER_COMMAND", "payload": {}}))
        reply = json.loads(await ws.recv())
        assert reply["type"] == "ERROR"
        assert "validation" in reply["error"].lower()
