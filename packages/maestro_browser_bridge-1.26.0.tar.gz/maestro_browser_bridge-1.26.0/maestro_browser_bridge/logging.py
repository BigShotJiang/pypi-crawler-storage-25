"""structlog configuration — JSON in production, console-friendly in dev.

Mirrors the pattern used in ``backend/app/logging.py`` and the agent so
operators can grep across services with the same field names (``event``,
``user_id``, ``command_id``, ``ts``).

Call ``configure_logging()`` once at process start; everywhere else use
``get_logger(__name__)``.

Implementation note: we route structlog output through the stdlib
``logging`` module (rather than ``PrintLoggerFactory``) so pytest's
``capsys`` fixture — which transiently swaps ``sys.stderr`` mid-test —
doesn't leave a captured-and-now-closed handle inside structlog. The
stdlib ``StreamHandler`` resolves ``sys.stderr`` lazily on each emit,
which sidesteps the problem.
"""

from __future__ import annotations

import logging
import os
import sys

import structlog


def _is_dev() -> bool:
    """Treat anything other than ``MAESTRO_ENV=prod`` as development.

    Production deployments should set ``MAESTRO_ENV=prod`` so logs ship as
    machine-parseable JSON. Local dev gets human-readable console output.
    """
    return os.environ.get("MAESTRO_ENV", "dev").lower() != "prod"


def configure_logging(level: str | int = "INFO") -> None:
    """Wire structlog + stdlib logging so both produce structured output.

    Idempotent — safe to call multiple times. The CLI calls it on every
    subcommand entry so even short-lived ``status`` / ``--version`` paths
    have correctly-formatted output if anything inside the library happens
    to log.
    """
    if isinstance(level, str):
        level = getattr(logging, level.upper(), logging.INFO)

    # Configure stdlib's root logger to write to stderr lazily. ``force=True``
    # so re-running configure_logging() in tests / REPLs reflows handlers
    # rather than stacking duplicates.
    logging.basicConfig(
        format="%(message)s",
        stream=sys.stderr,
        level=level,
        force=True,
    )

    processors: list = [
        structlog.contextvars.merge_contextvars,
        structlog.processors.add_log_level,
        structlog.processors.TimeStamper(fmt="iso", utc=True),
        structlog.processors.StackInfoRenderer(),
    ]

    if _is_dev():
        # Human-readable in dev — colors, tracebacks, pretty key=value.
        processors.append(structlog.dev.ConsoleRenderer(colors=sys.stderr.isatty()))
    else:
        # Machine-readable in prod — single-line JSON for log aggregators.
        processors.extend([
            structlog.processors.format_exc_info,
            structlog.processors.JSONRenderer(),
        ])

    structlog.configure(
        processors=processors,
        wrapper_class=structlog.make_filtering_bound_logger(level),
        # ``LoggerFactory`` builds stdlib loggers — emit is via
        # ``logger.info(rendered_string)``. The stdlib StreamHandler then
        # writes to whatever ``sys.stderr`` is at call time, which keeps
        # ``capsys`` and friends working.
        logger_factory=structlog.stdlib.LoggerFactory(),
        cache_logger_on_first_use=False,
    )


def get_logger(name: str | None = None) -> structlog.stdlib.BoundLogger:
    """Convenience accessor so callers don't need to import structlog."""
    return structlog.get_logger(name)
