"""Playwright Chromium lifecycle + tab management.

Owns a single Playwright + Chromium instance per bridge process and
exposes the tab-management primitives the handlers consume:

  - ``start()`` / ``stop()`` for the Chromium lifecycle.
  - ``get_or_create_tab(tab_id, new_tab=False)`` — returns the Playwright
    ``Page`` for a given tab. The default ``tab_id`` convention is one
    persistent tab per sandbox (caller passes ``sandbox_id`` as the
    ``tab_id``). ``new_tab=True`` minted a fresh tab with a synthesized
    id.
  - ``list_tabs()`` — what the ``browser_list_tabs`` tool returns.
  - ``drain_console_logs(tab_id, since_ts)`` — per-tab ring buffer of
    console messages, filtered to those newer than ``since_ts``.

Profile dir: ``~/.maestro/browser-profiles/<machine_id>``. Per-machine,
not per-sandbox, so cookies bleed across sandboxes on the *same* machine
in a controlled way and don't bleed across machines. Persistent context
(not incognito) so cookies survive bridge restarts.
"""

from __future__ import annotations

import time
import uuid
from collections import deque
from pathlib import Path
from typing import TYPE_CHECKING, Any, Optional

from .logging import get_logger
from .security import SecurityGate

if TYPE_CHECKING:
    # Type-only imports keep test imports from forcing Playwright to load
    # when the runtime isn't installed (CI, scaffold-only environments).
    from playwright.async_api import BrowserContext, Page, Playwright

logger = get_logger(__name__)

PROFILE_ROOT = Path.home() / ".maestro" / "browser-profiles"

# Ring-buffer size per tab. ~500 messages is generous for human-readable
# debugging and bounded enough that a runaway log loop won't OOM the
# bridge. Tune if real-world usage forces it.
CONSOLE_BUFFER_SIZE = 500


class TabState:
    """Per-tab state the session tracks alongside the Playwright Page.

    Holding this struct outside the Page object lets us survive tab
    re-creation (e.g. ``new_tab=True`` reusing a previous slot) and keeps
    the console listener decoupled from Playwright's own event plumbing.
    """

    __slots__ = ("tab_id", "page", "console")

    def __init__(self, tab_id: str, page: "Page") -> None:
        self.tab_id = tab_id
        self.page = page
        # deque with maxlen does the ring-buffer trim for us.
        self.console: deque[dict[str, Any]] = deque(maxlen=CONSOLE_BUFFER_SIZE)


class PlaywrightSession:
    """Wraps the Playwright + Chromium lifecycle and per-tab state."""

    def __init__(
        self,
        machine_id: Optional[str] = None,
        *,
        security: Optional[SecurityGate] = None,
        chrome_executable_path: Optional[str] = None,
        chrome_profile_dir: Optional[str] = None,
    ) -> None:
        self.machine_id: str = machine_id or str(uuid.uuid4())
        # An explicit profile dir overrides the per-machine default. Used
        # to point the bridge at an existing Chrome profile so the user
        # sees their already-signed-in sessions.
        self.profile_dir: Path = (
            Path(chrome_profile_dir) if chrome_profile_dir else PROFILE_ROOT / self.machine_id
        )
        self.chrome_executable_path: Optional[str] = chrome_executable_path
        # Security gate (allowlist + rate limit + pause flag). Default to
        # the no-extra-allowlist constructor so tests / dev paths that
        # don't care about security still work; the daemon builds one
        # from BridgeConfig.
        self.security: SecurityGate = security or SecurityGate()

        self._playwright: Optional["Playwright"] = None
        self._context: Optional["BrowserContext"] = None
        self._tabs: dict[str, TabState] = {}

    # ------------------------------------------------------------------
    # Lifecycle
    # ------------------------------------------------------------------

    async def start(self) -> None:
        """Launch Playwright + Chromium with the per-machine persistent context.

        Idempotent — calling on an already-started session is a no-op.
        """
        if self._context is not None:
            logger.warning("playwright_session.start_called_when_running")
            return

        self.profile_dir.mkdir(parents=True, exist_ok=True)
        logger.info(
            "playwright_session.start",
            machine_id=self.machine_id,
            profile_dir=str(self.profile_dir),
        )

        # Imported inline so the module is still importable in environments
        # without Playwright installed (tests mock the session wholesale).
        from playwright.async_api import async_playwright

        self._playwright = await async_playwright().start()
        # ``--disable-blink-features=AutomationControlled`` is the cheapest
        # piece of anti-detection — removes the ``navigator.webdriver=true``
        # signal that sites like Google sign-in flag as "automated browser".
        # Not bulletproof (real-Chrome via ``chrome_executable_path`` is
        # the proper fix for stubborn sites) but a useful baseline.
        launch_args = [
            "--no-first-run",
            "--no-default-browser-check",
            "--disable-blink-features=AutomationControlled",
        ]
        launch_kwargs: dict[str, Any] = {
            "user_data_dir": str(self.profile_dir),
            "headless": False,
            "args": launch_args,
        }
        if self.chrome_executable_path:
            # Real Chrome.app build is what e.g. Google's sign-in accepts.
            # Playwright bundles "Chrome for Testing" which Google flags.
            launch_kwargs["executable_path"] = self.chrome_executable_path
            logger.info("playwright_session.using_external_chrome", path=self.chrome_executable_path)
        self._context = await self._playwright.chromium.launch_persistent_context(**launch_kwargs)
        # Init script — runs in every new document before page scripts,
        # patches the residual automation signals Chrome leaks even with
        # AutomationControlled disabled. Tightens the stealth a bit
        # without breaking real-Chrome use.
        await self._context.add_init_script(
            "Object.defineProperty(navigator, 'webdriver', {get: () => undefined});"
        )

    async def stop(self) -> None:
        """Tear down the browser + Playwright runtime cleanly.

        Always safe to call. Errors are logged and swallowed.
        """
        logger.info("playwright_session.stop", machine_id=self.machine_id)

        if self._context is not None:
            try:
                await self._context.close()
            except Exception:  # noqa: BLE001
                logger.exception("playwright_session.context_close_failed")
        if self._playwright is not None:
            try:
                await self._playwright.stop()
            except Exception:  # noqa: BLE001
                logger.exception("playwright_session.playwright_stop_failed")

        self._context = None
        self._playwright = None
        self._tabs.clear()

    # ------------------------------------------------------------------
    # Async context manager
    # ------------------------------------------------------------------

    async def __aenter__(self) -> "PlaywrightSession":
        await self.start()
        return self

    async def __aexit__(self, exc_type, exc, tb) -> None:
        await self.stop()

    # ------------------------------------------------------------------
    # Tab management
    # ------------------------------------------------------------------

    async def get_or_create_tab(
        self,
        tab_id: str,
        *,
        new_tab: bool = False,
    ) -> TabState:
        """Return the TabState for ``tab_id``, creating a new page if needed.

        ``new_tab=True`` mints a fresh tab even if one already exists for the
        id — the synthesized id is ``f"{tab_id}-{short_uuid}"``. This matches
        the spec where ``BROWSER_NAVIGATE { new_tab: true }`` spawns extras
        without clobbering the default sandbox tab.
        """
        if self._context is None:
            raise RuntimeError("playwright session not started")

        if new_tab:
            tab_id = f"{tab_id}-{uuid.uuid4().hex[:8]}"

        existing = self._tabs.get(tab_id)
        if existing is not None:
            return existing

        page = await self._context.new_page()
        state = TabState(tab_id=tab_id, page=page)
        self._tabs[tab_id] = state
        self._wire_console_listener(state)
        return state

    async def list_tabs(self) -> list[dict[str, str]]:
        """Return ``[{tab_id, url, title}]`` for every live tab.

        Closed tabs are pruned lazily here so the result stays in sync
        with reality without a separate sweeper task.
        """
        out: list[dict[str, str]] = []
        dead: list[str] = []
        for tab_id, state in self._tabs.items():
            if state.page.is_closed():
                dead.append(tab_id)
                continue
            try:
                title = await state.page.title()
            except Exception:  # noqa: BLE001
                title = ""
            out.append({
                "tab_id": tab_id,
                "url": state.page.url,
                "title": title,
            })
        for tab_id in dead:
            self._tabs.pop(tab_id, None)
        return out

    def drain_console_logs(
        self, tab_id: str, since_ts: Optional[float]
    ) -> list[dict[str, Any]]:
        """Return console messages from ``tab_id`` newer than ``since_ts``.

        Returns an empty list if the tab is unknown — the handler turns
        that into a normal empty result, not an error, because "I haven't
        opened that tab" is indistinguishable from "no logs yet" from the
        caller's perspective.
        """
        state = self._tabs.get(tab_id)
        if state is None:
            return []
        if since_ts is None:
            return list(state.console)
        return [entry for entry in state.console if entry.get("ts", 0) > since_ts]

    # ------------------------------------------------------------------
    # Internals
    # ------------------------------------------------------------------

    def _wire_console_listener(self, state: TabState) -> None:
        """Attach a console listener that appends to the tab's ring buffer."""

        def _on_console(msg: Any) -> None:
            # Playwright's ConsoleMessage exposes .type, .text, .location.
            # Wrap defensively — a misbehaving page shouldn't break logging.
            try:
                entry: dict[str, Any] = {
                    "ts": time.time(),
                    "level": getattr(msg, "type", "log"),
                    "text": getattr(msg, "text", ""),
                }
                location = getattr(msg, "location", None)
                if isinstance(location, dict):
                    url = location.get("url")
                    if url:
                        entry["url"] = url
                state.console.append(entry)
            except Exception:  # noqa: BLE001
                logger.exception("playwright_session.console_listener_failed")

        state.page.on("console", _on_console)

    # ------------------------------------------------------------------
    # Accessors
    # ------------------------------------------------------------------

    @property
    def context(self) -> Optional["BrowserContext"]:
        return self._context

    @property
    def is_running(self) -> bool:
        return self._context is not None
