"""``BridgeDaemon`` — long-running async process for the Maestro Browser Bridge.

Wires together:

1. A ``PlaywrightSession`` (managed Chromium).
2. A *local* WS server on ``127.0.0.1:<port>`` (default 7654) — used for
   dev / debug. Same dispatch as the relay path.
3. An *outbound* WSS connection to the relay
   (``<relay_url>/ws/browser-bridge/<user_id>``) authenticated with
   ``X-Bridge-Token``.
4. A heartbeat loop that emits ``BROWSER_HEARTBEAT`` every 30s — keeps
   NAT mappings alive and lets the backend mark the bridge stale on miss.

The two surfaces (local + relay) share the same ``handlers.handle``
dispatch so behavior is identical.
"""

from __future__ import annotations

import asyncio
import json
import random
from typing import Optional

import websockets

from .config import BridgeConfig
from .handlers import handle
from .hmac_sig import sign_message, verify_message
from .logging import get_logger
from .playwright_session import PlaywrightSession
from .protocol import BrowserCommand
from .security import SecurityGate

logger = get_logger(__name__)

# Heartbeat cadence — matches agent's 30s HEARTBEAT/PONG cycle.
HEARTBEAT_INTERVAL_S = 30.0

# Reconnect backoff bounds — same shape as the agent's reconnect policy
# (see agent/remotedev_agent/daemon.py). Capped so a long outage doesn't
# stretch into hours-between-retries.
RECONNECT_MIN_S = 1.0
RECONNECT_MAX_S = 60.0


class BridgeDaemon:
    """Top-level async lifecycle for the bridge process."""

    def __init__(self, config: BridgeConfig) -> None:
        self.config = config

        def _persist_extra(updated: list[str]) -> None:
            # Hot-path: a single allowlist_add call shouldn't break the
            # gate's in-memory state if disk save fails — log and keep
            # going. Bridge restart will reconcile from the in-memory set
            # if the call eventually succeeds; otherwise the user re-adds
            # after restart.
            self.config.allowlist_extra = updated
            try:
                self.config.save()
            except Exception:  # noqa: BLE001
                logger.exception("config.save_failed", updated_len=len(updated))

        # Build the security gate from config so allowlist_extra +
        # rate_limit_per_min flow into the dispatch path. ``persist_extra_cb``
        # makes ``BROWSER_COMMAND allowlist_add`` durable across restarts.
        security = SecurityGate(
            allowlist_extra=config.allowlist_extra,
            rate_limit_per_min=config.rate_limit_per_min,
            persist_extra_cb=_persist_extra,
        )
        self.session = PlaywrightSession(
            security=security,
            chrome_executable_path=config.chrome_executable_path,
            chrome_profile_dir=config.chrome_profile_dir,
        )
        self._stop_event: asyncio.Event = asyncio.Event()
        self._tasks: list[asyncio.Task] = []
        # The outbound socket to the relay. None when between reconnects.
        self._relay_ws: Optional[websockets.WebSocketClientProtocol] = None

    # ------------------------------------------------------------------
    # Public lifecycle
    # ------------------------------------------------------------------

    async def run(self) -> None:
        """Start all subsystems and block until ``stop()`` is called."""
        logger.info(
            "bridge_daemon.start",
            relay_url=self.config.relay_url,
            user_id=self.config.user_id,
            local_port=self.config.port,
        )

        await self.session.start()

        local_task = asyncio.create_task(self._run_local_server(), name="bridge.local_server")
        self._tasks.append(local_task)

        relay_task = asyncio.create_task(self._run_relay_loop(), name="bridge.relay_loop")
        self._tasks.append(relay_task)

        heartbeat_task = asyncio.create_task(self._heartbeat_loop(), name="bridge.heartbeat")
        self._tasks.append(heartbeat_task)

        try:
            await self._stop_event.wait()
        finally:
            await self._shutdown()

    def stop(self) -> None:
        """Trigger graceful shutdown. Safe to call from a signal handler."""
        if not self._stop_event.is_set():
            logger.info("bridge_daemon.stop_requested")
            self._stop_event.set()

    # ------------------------------------------------------------------
    # Local WS server (127.0.0.1)
    # ------------------------------------------------------------------

    async def _run_local_server(self) -> None:
        """Run a loopback WS server on 127.0.0.1:<port>.

        Bound to loopback only — never exposed publicly. Same dispatch as
        the relay surface so a developer can poke the bridge with
        ``websocat ws://127.0.0.1:7654`` without standing up a relay.

        Messages are NOT HMAC-verified on this surface because the only
        thing that can talk to it is a process on the same machine. If
        that threat model changes (multi-user dev box), add a one-time
        local token in BC.6 follow-up.
        """
        async def _on_connection(ws: websockets.WebSocketServerProtocol) -> None:
            logger.info("bridge_daemon.local_client_connected")
            try:
                async for raw in ws:
                    await self._on_local_message(ws, raw if isinstance(raw, str) else raw.decode("utf-8"))
            except websockets.ConnectionClosed:
                pass
            except Exception:  # noqa: BLE001
                logger.exception("bridge_daemon.local_client_error")
            finally:
                logger.info("bridge_daemon.local_client_disconnected")

        try:
            async with websockets.serve(_on_connection, "127.0.0.1", self.config.port):
                logger.info(
                    "bridge_daemon.local_server_listening",
                    host="127.0.0.1",
                    port=self.config.port,
                )
                await self._stop_event.wait()
        except OSError as e:
            # Port collision is the most common failure here — surface a
            # clear log line, then keep the daemon running on the relay
            # surface (which is the production path).
            logger.error(
                "bridge_daemon.local_server_bind_failed",
                port=self.config.port,
                error=str(e),
            )
            await self._stop_event.wait()

    async def _on_local_message(self, ws, raw: str) -> None:
        try:
            msg = json.loads(raw)
        except json.JSONDecodeError:
            await ws.send(json.dumps({"type": "ERROR", "error": "invalid json"}))
            return

        msg_type = msg.get("type")
        if msg_type == "BROWSER_COMMAND":
            try:
                command = BrowserCommand.model_validate(msg)
            except Exception as e:  # noqa: BLE001
                await ws.send(json.dumps({"type": "ERROR", "error": f"validation: {e}"}))
                return
            result = await handle(command, self.session)
            await ws.send(json.dumps(result.model_dump(mode="json", exclude_none=False)))
            return

        if msg_type == "PING":
            await ws.send(json.dumps({"type": "PONG"}))
            return

        if msg_type == "BRIDGE_CONTROL":
            await ws.send(json.dumps(self._handle_bridge_control(msg)))
            return

        await ws.send(json.dumps({"type": "ERROR", "error": f"unknown type: {msg_type}"}))

    def _handle_bridge_control(self, msg: dict) -> dict:
        """Kill-switch toggle + status query (BC.6.1).

        Accepts ``{"type": "BRIDGE_CONTROL", "action": "pause"|"resume"|"status"}``.
        Returns the new state. Local-server-only — never reachable from
        the relay surface, so no authentication beyond filesystem-perm
        access to the loopback port (which the bridge configures to
        127.0.0.1 only).
        """
        action = msg.get("action")
        gate = self.session.security
        if action == "pause":
            gate.pause()
        elif action == "resume":
            gate.resume()
        elif action == "status":
            pass
        else:
            return {"type": "BRIDGE_CONTROL_RESULT", "ok": False, "error": f"unknown action: {action}"}
        return {
            "type": "BRIDGE_CONTROL_RESULT",
            "ok": True,
            "paused": gate.paused,
            "allowlist_size": len(gate.allowlist),
            "rate_limit_per_min": gate.rate_limit_per_min,
        }

    # ------------------------------------------------------------------
    # Relay outbound loop (production path)
    # ------------------------------------------------------------------

    async def _run_relay_loop(self) -> None:
        """Maintain an outbound WSS to the relay with auto-reconnect.

        Exponential backoff + jitter on failure (same shape as the agent's
        ``AgentDaemon.run`` retry policy). Failures here do not abort the
        local server — dev users may use the bridge without a relay.
        """
        # Normalize the URL so config can carry the host without the
        # trailing /ws/browser-bridge path. We accept both.
        relay_base = self.config.relay_url.rstrip("/")
        if relay_base.endswith("/ws/browser-bridge"):
            relay_base = relay_base[: -len("/ws/browser-bridge")]
        url = f"{relay_base}/ws/browser-bridge/{self.config.user_id}"

        # ``X-Bridge-Token`` mirrors the agent's ``X-Machine-Token`` header.
        headers = [("X-Bridge-Token", self.config.user_token)]
        backoff = RECONNECT_MIN_S

        while not self._stop_event.is_set():
            try:
                logger.info("bridge_daemon.relay_connecting", url=url)
                async with websockets.connect(
                    url,
                    additional_headers=headers,
                    max_size=8 * 1024 * 1024,  # 8MB — accommodates screenshot payloads
                    ping_interval=None,         # we have our own 30s heartbeat
                ) as ws:
                    self._relay_ws = ws
                    backoff = RECONNECT_MIN_S
                    logger.info("bridge_daemon.relay_connected", url=url)
                    async for raw in ws:
                        if isinstance(raw, bytes):
                            raw = raw.decode("utf-8", errors="replace")
                        await self._on_relay_message(raw)
            except asyncio.CancelledError:
                raise
            except Exception as e:  # noqa: BLE001
                logger.warning(
                    "bridge_daemon.relay_disconnected",
                    error=str(e),
                    error_type=type(e).__name__,
                )
            finally:
                self._relay_ws = None

            if self._stop_event.is_set():
                return

            # Jittered backoff. The ±25% jitter avoids reconnect storms
            # if many bridges drop at once (e.g. relay deploy).
            jitter = backoff * 0.25 * (random.random() * 2 - 1)
            sleep_for = max(RECONNECT_MIN_S, backoff + jitter)
            logger.info("bridge_daemon.relay_reconnect_sleep", seconds=round(sleep_for, 1))
            try:
                await asyncio.wait_for(self._stop_event.wait(), timeout=sleep_for)
                # _stop_event fired during sleep — bail.
                return
            except asyncio.TimeoutError:
                pass
            backoff = min(backoff * 2, RECONNECT_MAX_S)

    # ------------------------------------------------------------------
    # Heartbeat
    # ------------------------------------------------------------------

    async def _heartbeat_loop(self) -> None:
        """Emit ``BROWSER_HEARTBEAT`` every ``HEARTBEAT_INTERVAL_S`` seconds."""
        while not self._stop_event.is_set():
            try:
                await asyncio.wait_for(
                    self._stop_event.wait(),
                    timeout=HEARTBEAT_INTERVAL_S,
                )
                return
            except asyncio.TimeoutError:
                pass

            if self._relay_ws is not None:
                try:
                    await self._send_relay({"type": "BROWSER_HEARTBEAT"})
                except Exception:  # noqa: BLE001
                    logger.exception("bridge_daemon.heartbeat_send_failed")

    # ------------------------------------------------------------------
    # Message handling
    # ------------------------------------------------------------------

    async def _on_relay_message(self, raw: str) -> None:
        """Parse, HMAC-verify, dispatch, sign, send back."""
        try:
            msg = json.loads(raw)
        except json.JSONDecodeError:
            logger.warning("bridge_daemon.bad_json", raw_preview=raw[:200])
            return

        if not verify_message(msg, self.config.user_token):
            logger.warning("bridge_daemon.hmac_verify_failed", type=msg.get("type"))
            return

        msg_type = msg.get("type")
        if msg_type == "BROWSER_COMMAND":
            try:
                cleaned = {k: v for k, v in msg.items() if k != "hmac_sig"}
                command = BrowserCommand.model_validate(cleaned)
            except Exception:  # noqa: BLE001
                logger.exception("bridge_daemon.command_validation_failed")
                return
            result = await handle(command, self.session)
            # The result envelope rides the BROWSER_RESULT type; the relay
            # uses ``command_id`` for routing back to the originating
            # sandbox + audit-log update.
            await self._send_relay(result.model_dump(mode="json", exclude_none=False))
            return

        if msg_type == "PING":
            await self._send_relay({"type": "PONG"})
            return

        logger.debug("bridge_daemon.unhandled_message", type=msg_type)

    async def _send_relay(self, msg: dict) -> None:
        """HMAC-sign ``msg`` and forward over the relay WS if connected."""
        if self._relay_ws is None:
            logger.debug("bridge_daemon.relay_send_skipped_no_socket", type=msg.get("type"))
            return
        signed = sign_message(msg, self.config.user_token)
        try:
            await self._relay_ws.send(json.dumps(signed))
        except Exception as e:  # noqa: BLE001
            logger.warning(
                "bridge_daemon.relay_send_failed",
                type=msg.get("type"),
                error=str(e),
            )

    # ------------------------------------------------------------------
    # Shutdown
    # ------------------------------------------------------------------

    async def _shutdown(self) -> None:
        logger.info("bridge_daemon.shutdown")

        for task in reversed(self._tasks):
            task.cancel()
        if self._tasks:
            await asyncio.gather(*self._tasks, return_exceptions=True)
        self._tasks.clear()

        try:
            await self.session.stop()
        except Exception:  # noqa: BLE001
            logger.exception("bridge_daemon.session_stop_failed")
