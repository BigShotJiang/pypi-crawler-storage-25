"""Pydantic v2 models for the BROWSER_* wire protocol.

Sources of truth:
- ``_reference/11_BROWSER_CONTROL.md`` — full schema reference.
- ``CLAUDE.md`` § "Browser control (Phase 1/2)" — short-form mention.

Why strict models: the relay is HMAC-verified but the JSON shape is not
constrained by the relay itself — it pass-through routes typed messages. If
a malformed payload reaches the bridge we want it rejected at the dispatch
boundary with a clear pydantic error instead of crashing inside a handler.

``model_config = {"extra": "forbid"}`` makes pydantic reject unknown fields
so we catch protocol drift instead of silently dropping new server-side
keys. When we evolve the protocol we'll bump fields explicitly here.
"""

from __future__ import annotations

import time
from typing import Any, Literal, Optional

from pydantic import BaseModel, ConfigDict, Field

# ---------------------------------------------------------------------------
# Action enum
# ---------------------------------------------------------------------------

# The set of Playwright-facing operations Claude can request. Kept as a
# Literal (not a Python Enum) so pydantic emits clean discriminated errors
# like ``Input should be 'navigate', 'click', ...`` instead of cryptic
# membership messages.
BrowserAction = Literal[
    "navigate",
    "click",
    "type",
    "screenshot",
    "read_dom",
    "console_logs",
    "list_tabs",
    "keypress",
    "scroll",
    "allowlist_add",
]


# ---------------------------------------------------------------------------
# Command (sandbox → bridge)
# ---------------------------------------------------------------------------


class BrowserCommandPayload(BaseModel):
    """Inner payload of a ``BROWSER_COMMAND`` message.

    All fields beyond ``action`` are optional because each action only
    consumes a subset (e.g. ``navigate`` needs ``url``; ``click`` needs
    ``selector``). The dispatch layer in ``handlers.handle`` is responsible
    for asserting required-per-action fields and surfacing a friendly error
    when they're missing — keeping the model permissive avoids a giant
    union of per-action sub-models for now (we can tighten in BC.1.2 once
    handler shapes settle).
    """

    model_config = ConfigDict(extra="forbid")

    action: BrowserAction
    tab_id: Optional[str] = None
    url: Optional[str] = None
    selector: Optional[str] = None
    text: Optional[str] = None
    full_page: Optional[bool] = None
    since_ts: Optional[float] = None
    new_tab: Optional[bool] = None
    # keypress: Playwright key name (e.g. "Enter", "Tab", "ArrowDown",
    # "Backspace"). Sent as a single ``page.keyboard.press`` against the
    # currently focused element.
    key: Optional[str] = None
    # scroll: wheel delta in CSS pixels. Positive ``dy`` scrolls down;
    # positive ``dx`` scrolls right.
    dx: Optional[float] = None
    dy: Optional[float] = None
    # allowlist_add: bare hostname (no scheme, no path) to add to the
    # bridge's runtime + persisted allowlist.
    host: Optional[str] = None


class BrowserCommand(BaseModel):
    """Envelope for a ``BROWSER_COMMAND`` from a sandbox to the bridge."""

    model_config = ConfigDict(extra="forbid")

    type: Literal["BROWSER_COMMAND"] = "BROWSER_COMMAND"
    user_id: str
    command_id: str
    sandbox_id: str
    payload: BrowserCommandPayload
    ts: float = Field(default_factory=lambda: time.time())


# ---------------------------------------------------------------------------
# Result (bridge → sandbox)
# ---------------------------------------------------------------------------


class BrowserResultPayload(BaseModel):
    """Inner payload of a ``BROWSER_RESULT`` reply.

    Optional fields are intentionally typed so the same model can express:
      - success with a screenshot (`ok=True, screenshot_b64=...`),
      - success with only URL/title (`ok=True, current_url=..., title=...`),
      - failure (`ok=False` — the envelope-level ``error`` field carries
        the message).
    """

    model_config = ConfigDict(extra="forbid")

    ok: bool
    current_url: Optional[str] = None
    title: Optional[str] = None
    screenshot_b64: Optional[str] = None
    dom_snippet: Optional[str] = None
    console_logs: Optional[list[dict[str, Any]]] = None
    # Reported alongside ``screenshot_b64`` so the frontend can map a
    # click on the displayed image back to viewport coordinates the
    # bridge actually saw. Headed Chromium has no fixed viewport — these
    # come from ``window.innerWidth/innerHeight`` at capture time.
    viewport_w: Optional[int] = None
    viewport_h: Optional[int] = None
    # Populated when navigate is rejected by the allowlist gate. Lets
    # the frontend render an "Add <host> to allowlist" prompt instead of
    # surfacing the raw error message.
    denied_host: Optional[str] = None


class BrowserResult(BaseModel):
    """Envelope for a ``BROWSER_RESULT`` reply from the bridge to a sandbox."""

    model_config = ConfigDict(extra="forbid")

    type: Literal["BROWSER_RESULT"] = "BROWSER_RESULT"
    command_id: str
    payload: BrowserResultPayload
    error: Optional[str] = None
    ts: float = Field(default_factory=lambda: time.time())


# ---------------------------------------------------------------------------
# Streaming events (bridge → sandbox)
# ---------------------------------------------------------------------------


class BrowserEventPayload(BaseModel):
    """Inner payload of a ``BROWSER_EVENT`` stream message.

    ``data`` is a free-form dict because event payloads vary widely
    (request URLs, console line objects, navigation timing).
    """

    model_config = ConfigDict(extra="forbid")

    event: str
    tab_id: Optional[str] = None
    data: dict[str, Any] = Field(default_factory=dict)


class BrowserEvent(BaseModel):
    """Envelope for streaming browser-side events back to the sandbox."""

    model_config = ConfigDict(extra="forbid")

    type: Literal["BROWSER_EVENT"] = "BROWSER_EVENT"
    payload: BrowserEventPayload
    ts: float = Field(default_factory=lambda: time.time())
