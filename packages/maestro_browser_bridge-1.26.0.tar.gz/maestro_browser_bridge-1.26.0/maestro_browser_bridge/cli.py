"""Click CLI for the ``maestro-browser-bridge`` package.

Subcommands mirror the shape of ``remotedev-agent``'s CLI so the install
experience is familiar:

- ``configure`` — write config to ``~/.maestro/bridge-config.json``.
- ``start`` — load config and run the daemon (``--detach`` stubbed).
- ``stop`` — placeholder.
- ``status`` — print version + config path.
- ``install-service`` — placeholder (launchd/systemd installer lands in BC.1.4).
- ``--version`` — read from package metadata.

Only the bits required by the acceptance criteria are wired today; the
``daemon.py`` skeleton already documents the rest as TODOs.
"""

from __future__ import annotations

import asyncio
from importlib.metadata import PackageNotFoundError, version as _pkg_version

import click

from .config import CONFIG_FILE, DEFAULT_LOCAL_PORT, BridgeConfig
from .logging import configure_logging


def _package_version() -> str:
    """Resolve the installed package version, falling back to ``__init__.__version__``.

    Mirrors the pattern in ``agent/remotedev_agent/cli.py`` so source-checkout
    runs (without dist-info) still produce something useful.
    """
    try:
        return _pkg_version("maestro-browser-bridge")
    except PackageNotFoundError:
        from . import __version__
        return __version__


@click.group()
@click.version_option(version=_package_version(), prog_name="maestro-browser-bridge")
def cli() -> None:
    """Maestro Browser Bridge — local Playwright Chromium controller."""
    # Configure structlog once per CLI invocation. Cheap (idempotent), and
    # ensures even short-lived commands like ``status`` emit JSON in prod.
    configure_logging()


# ---------------------------------------------------------------------------
# configure
# ---------------------------------------------------------------------------


@cli.command()
@click.option(
    "--relay-url",
    required=True,
    help="WebSocket URL of the Maestro relay (e.g. wss://relay.thesavvydeveloper.com).",
)
@click.option(
    "--user-id",
    required=True,
    help="Maestro user UUID — determines relay routing (user_id → bridge).",
)
@click.option(
    "--user-token",
    required=True,
    help="Per-user bridge token issued by the backend.",
)
@click.option(
    "--port",
    type=int,
    default=DEFAULT_LOCAL_PORT,
    show_default=True,
    help="Local loopback port for the dev WS server.",
)
def configure(relay_url: str, user_id: str, user_token: str, port: int) -> None:
    """Persist bridge configuration to ``~/.maestro/bridge-config.json``.

    The file is written 0600 inside a 0700 directory — equivalent posture
    to the agent's config, since the bridge token is approximately as
    sensitive as a Maestro JWT.
    """
    config = BridgeConfig(
        relay_url=relay_url,
        user_id=user_id,
        user_token=user_token,
        port=port,
    )
    config.save()
    click.echo(f"Config saved to {CONFIG_FILE}.")
    click.echo("Start the bridge with: maestro-browser-bridge start")


# ---------------------------------------------------------------------------
# start
# ---------------------------------------------------------------------------


@cli.command()
@click.option(
    "--detach",
    "-d",
    is_flag=True,
    help="Run in the background (not yet implemented — exits non-zero).",
)
def start(detach: bool) -> None:
    """Launch the bridge daemon in the foreground.

    ``--detach`` is wired so the flag is visible in ``--help`` but the
    background-launch path (PID file, log rotation, daemonization) lands
    in a later milestone — see ``agent/remotedev_agent/process_manager.py``
    for the pattern we'll mirror.
    """
    if detach:
        click.echo("detach not yet implemented", err=True)
        raise SystemExit(1)

    try:
        config = BridgeConfig.load()
    except FileNotFoundError as e:
        click.echo(str(e), err=True)
        raise SystemExit(1)

    # Import inside the command so test collection (which doesn't run
    # ``start``) doesn't pay the cost of pulling in websockets / playwright
    # just to introspect ``--help``.
    from .daemon import BridgeDaemon

    click.echo(f"Starting bridge for user {config.user_id}...")
    daemon = BridgeDaemon(config)
    try:
        asyncio.run(daemon.run())
    except KeyboardInterrupt:
        # Ctrl-C is a normal exit path during dev; don't print a stack
        # trace at the user.
        click.echo("Bridge stopped.")


# ---------------------------------------------------------------------------
# stop
# ---------------------------------------------------------------------------


@cli.command("stop")
def cmd_stop() -> None:
    """Stop a detached bridge daemon (placeholder).

    Implementation lands alongside ``--detach`` in BC.1.4 — same
    process-manager surface as the agent.
    """
    click.echo("stop not yet implemented — run the bridge in the foreground for now.")


# ---------------------------------------------------------------------------
# status
# ---------------------------------------------------------------------------


@cli.command("status")
def cmd_status() -> None:
    """Print version + config path. Loads the saved config when available."""
    click.echo(f"maestro-browser-bridge {_package_version()}")
    click.echo(f"Config file: {CONFIG_FILE}")
    try:
        config = BridgeConfig.load()
    except FileNotFoundError:
        click.echo("Config: NOT CONFIGURED (run 'maestro-browser-bridge configure ...').")
        return
    click.echo(f"Relay URL:   {config.relay_url}")
    click.echo(f"User ID:     {config.user_id}")
    click.echo(f"Local port:  {config.port}")
    # NB — never print user_token; it's roughly as sensitive as a session JWT.


# ---------------------------------------------------------------------------
# install-service
# ---------------------------------------------------------------------------


@cli.command("install-service")
def install_service() -> None:
    """Install as a background service (placeholder).

    Plan: mirror ``agent/remotedev_agent/service/`` — launchd on macOS,
    systemd on Linux. Tracked in BC.1.4.
    """
    click.echo("install-service not yet implemented — see BC.1.4 in implementation_plan.md.")


# ---------------------------------------------------------------------------
# Kill switch — pause / resume (BC.6.1)
# ---------------------------------------------------------------------------


def _send_bridge_control(action: str) -> dict:
    """Send a BRIDGE_CONTROL command to the running bridge via 127.0.0.1.

    Synchronous — uses raw asyncio.run + websockets.connect so the CLI
    doesn't need to manage an event loop itself. Returns the parsed
    reply dict, raises ``ClickException`` on connect / I/O failure.
    """
    import asyncio
    import json as _json

    try:
        config = BridgeConfig.load()
    except FileNotFoundError as e:
        raise click.ClickException(str(e))

    async def _go() -> dict:
        # Import lazily so ``--help`` / ``status`` don't pay the websockets cost.
        import websockets

        url = f"ws://127.0.0.1:{config.port}"
        async with websockets.connect(url, open_timeout=2.0) as ws:
            await ws.send(_json.dumps({"type": "BRIDGE_CONTROL", "action": action}))
            reply_raw = await ws.recv()
            return _json.loads(reply_raw if isinstance(reply_raw, str) else reply_raw.decode("utf-8"))

    try:
        return asyncio.run(_go())
    except (ConnectionRefusedError, OSError) as e:
        raise click.ClickException(
            f"Could not reach bridge on 127.0.0.1:{config.port} ({e}). "
            "Is 'maestro-browser-bridge start' running?"
        )
    except Exception as e:  # noqa: BLE001
        raise click.ClickException(f"Bridge control failed: {e}")


@cli.command("pause")
def cmd_pause() -> None:
    """Pause the bridge — every BROWSER_COMMAND will fail until ``resume``.

    Use this as a kill switch if Claude is doing something you don't
    want it to. State is in-memory only, so a daemon restart implicitly
    resumes — that's intentional, so the recovery path is just
    ``maestro-browser-bridge start``.
    """
    reply = _send_bridge_control("pause")
    if not reply.get("ok"):
        raise click.ClickException(reply.get("error") or "Unknown error")
    click.echo("Bridge paused. Resume with 'maestro-browser-bridge resume'.")


@cli.command("resume")
def cmd_resume() -> None:
    """Resume the bridge after a ``pause``."""
    reply = _send_bridge_control("resume")
    if not reply.get("ok"):
        raise click.ClickException(reply.get("error") or "Unknown error")
    click.echo("Bridge resumed.")


@cli.command("bridge-status")
def cmd_bridge_status() -> None:
    """Print the running bridge's runtime state (paused / allowlist / rate)."""
    reply = _send_bridge_control("status")
    if not reply.get("ok"):
        raise click.ClickException(reply.get("error") or "Unknown error")
    click.echo(f"paused:             {reply.get('paused')}")
    click.echo(f"allowlist hosts:    {reply.get('allowlist_size')}")
    click.echo(f"rate limit / min:   {reply.get('rate_limit_per_min')}")


if __name__ == "__main__":
    cli()
