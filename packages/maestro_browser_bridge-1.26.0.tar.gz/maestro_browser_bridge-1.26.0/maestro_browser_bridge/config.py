"""Bridge configuration — persisted as JSON in the user's home dir.

Mirrors ``agent/remotedev_agent/config.py`` so the file-on-disk semantics
(0600 mode, parent dir 0700) are uniform across both daemons. We store the
config in ``~/.maestro/`` rather than ``~/.remotedev/`` because the bridge
is a *user-scoped* service (one per laptop, not per machine) while the agent
is *machine-scoped*. Sharing a dir would conflate two different identities.
"""

from __future__ import annotations

import json
import os
from dataclasses import asdict, dataclass, field
from pathlib import Path
from typing import Optional

# ``~/.maestro`` is the per-user config root for the bridge. The agent uses
# ``~/.remotedev`` instead — intentionally a different namespace so that an
# uninstall of one doesn't blow away the other's state.
CONFIG_DIR = Path.home() / ".maestro"
CONFIG_FILE = CONFIG_DIR / "bridge-config.json"

# Default port for the local WS server. ``127.0.0.1:7654`` is mentioned in
# the spec; bound to loopback only — never exposed on a public interface
# because the bridge can issue privileged Playwright commands.
DEFAULT_LOCAL_PORT = 7654


@dataclass
class BridgeConfig:
    """Configuration for the local browser bridge.

    Attributes:
        relay_url: WebSocket URL of the Maestro relay (e.g.
            ``wss://relay.thesavvydeveloper.com``). The bridge will dial
            ``<relay_url>/ws/browser-bridge/<user_id>`` on start.
        user_id: UUID of the Maestro user this bridge belongs to. Determines
            relay routing — one bridge per user (vs. agents which are
            per-machine).
        user_token: Bridge token issued by the backend (single-use issuance,
            see ``POST /browser-bridges`` in the BC.2 plan). Used both as the
            ``X-Bridge-Token`` header on connect and as the HMAC signing key
            for every WS message.
        port: Local loopback port for the in-process WS server. Defaults to
            7654. Bound to ``127.0.0.1`` — never a public interface.
        allowlist_extra: User-added hosts the bridge allows for navigate.
            Merged with the default allowlist in ``security.py``.
        rate_limit_per_min: Per-minute BROWSER_COMMAND budget. Defaults to
            60 — enough for an interactive user, low enough to bound a
            runaway script.
    """

    relay_url: str
    user_id: str
    user_token: str
    port: int = DEFAULT_LOCAL_PORT
    allowlist_extra: list[str] = field(default_factory=list)
    rate_limit_per_min: int = 60
    # Optional path to a real Chrome.app binary (e.g.
    # ``/Applications/Google Chrome.app/Contents/MacOS/Google Chrome``).
    # When set, the bridge launches that instead of Playwright's
    # bundled Chrome-for-Testing build — required for sites like
    # Google sign-in that block the CFT user-agent / fingerprint.
    chrome_executable_path: Optional[str] = None
    # Optional override for the user-data-dir Chrome uses. Default is
    # ``~/.maestro/browser-profiles/<machine_id>`` (per-machine, fresh).
    # Point this at an existing Chrome profile to inherit cookies +
    # extensions — note Chrome can only have one process per profile
    # so other Chrome windows on that profile must be closed first.
    chrome_profile_dir: Optional[str] = None

    def save(self) -> None:
        """Persist config to ``~/.maestro/bridge-config.json`` with 0600 mode.

        The 0600 / 0700 combo prevents other users on a shared machine from
        reading the bridge token, which is equivalent in blast radius to the
        user's Maestro JWT.
        """
        CONFIG_DIR.mkdir(parents=True, exist_ok=True)
        os.chmod(CONFIG_DIR, 0o700)
        CONFIG_FILE.write_text(json.dumps(asdict(self), indent=2))
        os.chmod(CONFIG_FILE, 0o600)

    @classmethod
    def load(cls) -> "BridgeConfig":
        """Read the saved config, or raise ``FileNotFoundError`` with a hint."""
        if not CONFIG_FILE.exists():
            raise FileNotFoundError(
                f"Config not found at {CONFIG_FILE}. "
                "Run 'maestro-browser-bridge configure --relay-url ... --user-id ... --user-token ...' first."
            )
        data = json.loads(CONFIG_FILE.read_text())
        # Tolerate older configs that don't carry ``port`` by letting the
        # dataclass default kick in.
        return cls(**data)
