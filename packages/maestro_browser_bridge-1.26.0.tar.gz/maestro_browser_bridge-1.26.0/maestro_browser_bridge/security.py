"""Security gates for BROWSER_COMMAND dispatch (BC.6.1).

Three independent checks, all enforced before any Playwright call:

1. **Allowlist** — ``navigate`` actions whose host is not on the
   allowlist are rejected. Other actions (click, type, read_dom etc.)
   are not subject to the allowlist because by the time they run, the
   page is already loaded and same-origin policy is doing the heavy
   lifting — re-checking would block useful flows on redirects.
2. **Rate limit** — sliding 60s window, default 60 commands per
   minute. Over-limit calls return ``error="rate_limited"`` without
   touching Playwright.
3. **Kill switch / paused state** — a runtime-toggleable flag. When
   paused, every BROWSER_COMMAND fails with ``error="bridge_paused"``.
   Toggled via the local 127.0.0.1 WS surface (BRIDGE_CONTROL message).
   Pause does NOT survive a restart — that's intentional, so a panicked
   user can recover with a simple ``maestro-browser-bridge start``.

All errors are surfaced verbatim in the BROWSER_RESULT envelope so the
sandbox-side caller (CLI / MCP / frontend) sees actionable text.
"""

from __future__ import annotations

import time
from collections import deque
from typing import Callable, Iterable, Optional
from urllib.parse import urlparse

# Default allowlist — a small starter set covering common dev / work
# domains. Real ~1000-host list lands in BC.6 polish; in the meantime
# users override via ``BridgeConfig.allowlist_extra``.
#
# We deliberately do NOT include arbitrary-content hosts (Google search,
# Twitter, YouTube etc.) because allow-listing them is essentially
# "allow the whole internet via this redirect" — keep the default tight
# and force off-list nav to be explicit.
DEFAULT_ALLOWLIST = frozenset({
    # Code hosting
    "github.com",
    "gitlab.com",
    "bitbucket.org",
    "codeberg.org",
    # Docs + reference
    "docs.python.org",
    "developer.mozilla.org",
    "stackoverflow.com",
    "wikipedia.org",
    # Package indexes (read-only browsing — install commands stay on the CLI)
    "pypi.org",
    "npmjs.com",
    "crates.io",
    "rubygems.org",
    # Cloud consoles + dashboards
    "vercel.com",
    "console.neon.tech",
    "console.aws.amazon.com",
    "console.cloud.google.com",
    "portal.azure.com",
    # Productivity tools
    "notion.so",
    "linear.app",
    "github.io",  # most personal sites + many docs
    # Loopback for dev preview
    "localhost",
    "127.0.0.1",
})

RATE_LIMIT_WINDOW_S = 60.0
DEFAULT_RATE_LIMIT_PER_MIN = 60


def _host_of(url: str) -> str | None:
    """Return the canonical host of ``url`` (lowercased, www-stripped)."""
    try:
        parsed = urlparse(url)
    except Exception:  # noqa: BLE001
        return None
    host = (parsed.hostname or "").lower()
    if host.startswith("www."):
        host = host[4:]
    return host or None


class SecurityGate:
    """Tracks rate-limit window, allowlist, and pause state.

    One instance per bridge process. The daemon constructs it from the
    saved ``BridgeConfig`` and passes it into ``handlers.handle`` via
    the shared ``PlaywrightSession`` (which holds it as an attribute).
    """

    def __init__(
        self,
        *,
        allowlist_extra: Optional[Iterable[str]] = None,
        rate_limit_per_min: int = DEFAULT_RATE_LIMIT_PER_MIN,
        persist_extra_cb: Optional[Callable[[list[str]], None]] = None,
    ) -> None:
        # Normalize user-provided hosts: lowercase, strip the literal
        # ``www.`` prefix (str.lstrip is character-by-character, not a
        # prefix strip — that was a latent bug here).
        self._normalized_extra: set[str] = {
            self._norm(h) for h in (allowlist_extra or ()) if h
        }
        # Mutable so ``add_host`` can extend it at runtime. Defaults stay
        # frozen — we only ever grow the user-extra set.
        self.allowlist: set[str] = set(DEFAULT_ALLOWLIST) | self._normalized_extra
        self.rate_limit_per_min = rate_limit_per_min
        # Monotonic timestamps of recent navigate-or-other commands. We
        # rate-limit the whole BROWSER_COMMAND surface, not just navigate,
        # because read_dom on a giant page is just as expensive.
        self._stamps: deque[float] = deque()
        self._paused: bool = False
        # Optional hook called with the updated ``allowlist_extra`` list
        # (defaults excluded) whenever ``add_host`` succeeds. Daemons wire
        # this to BridgeConfig.save() so user-added hosts survive restart.
        self._persist_extra_cb = persist_extra_cb

    @staticmethod
    def _norm(h: str) -> str:
        h = (h or "").strip().lower()
        return h[4:] if h.startswith("www.") else h

    # ------------------------------------------------------------------
    # Allowlist
    # ------------------------------------------------------------------

    def check_navigate_allowed(self, url: str) -> str | None:
        """Return error string if ``url``'s host is off-list, else None.

        Handles host suffixes too — ``foo.github.io`` matches an allowed
        ``github.io`` because dev / personal sites are a common case.

        Error format is ``allowlist_block: <host>: <message>`` — the
        leading token + bare host is what handler dispatch parses out
        into ``BrowserResultPayload.denied_host`` for the frontend's
        "Add to allowlist" prompt.
        """
        host = _host_of(url)
        if host is None:
            return f"navigate: could not parse host from URL {url!r}"
        if host in self.allowlist:
            return None
        # Suffix match: foo.github.io → github.io
        for allowed in self.allowlist:
            # Only match on dot-boundary so ``evil-github.com`` doesn't
            # masquerade as ``github.com``.
            if host.endswith("." + allowed):
                return None
        return (
            f"allowlist_block: {host}: host is not on the bridge allowlist. "
            "Add it via the workspace prompt, or edit allowlist_extra in "
            "~/.maestro/bridge-config.json and restart the bridge."
        )

    def add_host(self, raw_host: str) -> str:
        """Normalize + add a host to the runtime + persisted allowlist.

        Returns the normalized form actually inserted. Raises
        ``ValueError`` for empty / malformed input so the dispatch layer
        can surface a clean error.
        """
        host = self._norm(raw_host)
        if not host or "/" in host or " " in host or not "." in host:
            # Reject obvious garbage. A real host always has a dot
            # (we already strip protocol/path/whitespace via _norm).
            raise ValueError(f"invalid host: {raw_host!r}")
        self.allowlist.add(host)
        self._normalized_extra.add(host)
        if self._persist_extra_cb is not None:
            # Sorted for stable on-disk ordering, easier to diff configs.
            self._persist_extra_cb(sorted(self._normalized_extra))
        return host

    # ------------------------------------------------------------------
    # Rate limit
    # ------------------------------------------------------------------

    def check_and_record_rate(self) -> str | None:
        """Return error string if the per-minute budget is spent, else None.

        Records the timestamp on success so a passing call counts
        toward the next caller's budget. Failing calls do NOT record —
        otherwise a burst of rejected calls would extend the cooldown
        artificially.
        """
        now = time.monotonic()
        # Trim old entries before checking the budget.
        cutoff = now - RATE_LIMIT_WINDOW_S
        while self._stamps and self._stamps[0] < cutoff:
            self._stamps.popleft()

        if len(self._stamps) >= self.rate_limit_per_min:
            oldest_age = now - self._stamps[0]
            retry_in = max(1, int(RATE_LIMIT_WINDOW_S - oldest_age))
            return (
                f"rate_limited: {self.rate_limit_per_min} commands per minute exceeded "
                f"(retry in ~{retry_in}s)"
            )

        self._stamps.append(now)
        return None

    # ------------------------------------------------------------------
    # Pause / kill switch
    # ------------------------------------------------------------------

    @property
    def paused(self) -> bool:
        return self._paused

    def pause(self) -> None:
        self._paused = True

    def resume(self) -> None:
        self._paused = False

    def check_paused(self) -> str | None:
        return "bridge_paused: resume with 'maestro-browser-bridge resume'" if self._paused else None
