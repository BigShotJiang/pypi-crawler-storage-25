"""Maestro Browser Bridge — local Playwright-driven Chromium for the
Remote AI Maestro platform.

The bridge runs on the user's *local* laptop (not on a registered Maestro
"machine") and maintains an outbound WebSocket to the relay so AI agents
running inside remote sandboxes can drive a real browser the user can see
and intervene in.

See ``_reference/11_BROWSER_CONTROL.md`` for the design spec.
"""

__version__ = "0.1.0"
