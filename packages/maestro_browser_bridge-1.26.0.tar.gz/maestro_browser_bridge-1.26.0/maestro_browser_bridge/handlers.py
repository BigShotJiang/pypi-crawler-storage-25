"""Dispatch of ``BROWSER_COMMAND`` actions to Playwright handlers.

Each ``handle_<action>`` coroutine wraps a single Playwright primitive
against the per-sandbox tab managed by ``PlaywrightSession``. The dispatch
entry point ``handle()`` validates, calls the handler, and turns any
exception into a ``BrowserResult(ok=False, error=...)`` reply so the
daemon can always send *something* back to the originating sandbox.

Tab routing convention:
  - When ``payload.tab_id`` is set, it identifies the tab directly.
  - When unset, the handler falls back to ``command.sandbox_id`` — i.e.
    "one persistent tab per sandbox" as per the spec in
    ``_reference/11_BROWSER_CONTROL.md``.
  - ``payload.new_tab=True`` (navigate only) mints a fresh tab anchored
    to the resolved tab key.

Validation policy: handlers raise ``ValueError`` for missing required
fields (e.g. ``url`` for navigate, ``selector`` for click). Dispatch
turns that into a clean wire-format error.
"""

from __future__ import annotations

import base64
from typing import Awaitable, Callable

from .logging import get_logger
from .playwright_session import PlaywrightSession
from .protocol import (
    BrowserAction,
    BrowserCommand,
    BrowserResult,
    BrowserResultPayload,
)
from .security import _host_of

logger = get_logger(__name__)

# Cap returned DOM payloads so a careless ``read_dom`` on document.body
# can't blow past the relay's frame limits. Matches the agent's 1MB
# file-read cap so operators only learn one number.
DOM_SNIPPET_BYTE_CAP = 1_000_000


def _resolve_tab_key(command: BrowserCommand) -> str:
    """Resolve which tab a command targets.

    Explicit ``payload.tab_id`` wins; otherwise the sandbox's default tab
    (``tab_id == sandbox_id``) is used.
    """
    return command.payload.tab_id or command.sandbox_id


def _check_paused(session: PlaywrightSession) -> str | None:
    """Tiny helper so the dispatch site stays readable."""
    return session.security.check_paused()


# ---------------------------------------------------------------------------
# Per-action handlers
# ---------------------------------------------------------------------------


async def handle_navigate(
    session: PlaywrightSession,
    command: BrowserCommand,
) -> BrowserResultPayload:
    """Open or reuse the tab and navigate to ``payload.url``."""
    payload = command.payload
    if not payload.url:
        raise ValueError("navigate requires 'url'")

    tab_key = _resolve_tab_key(command)
    state = await session.get_or_create_tab(tab_key, new_tab=bool(payload.new_tab))
    # ``domcontentloaded`` is the right line between "page is interactive"
    # and "every late-loading image is in". Claude's next step usually
    # reads DOM or clicks something — DCL is enough for both.
    await state.page.goto(payload.url, wait_until="domcontentloaded")
    return BrowserResultPayload(
        ok=True,
        current_url=state.page.url,
        title=await state.page.title(),
    )


_COORDS_PREFIX = "__coords:"
_FOCUSED_SELECTOR = "__focused"


def _parse_coords_selector(selector: str) -> tuple[float, float]:
    """Parse a ``__coords:x,y`` selector into a float (x, y) pair.

    Frontend emits rounded integers (see ``MainArea.tsx``'s
    ``onScreenshotClick``), but we accept floats so future viewport-scaled
    callers don't have to round. Raises ``ValueError`` with a wire-friendly
    message on any malformed input.
    """
    raw = selector[len(_COORDS_PREFIX):]
    parts = raw.split(",")
    if len(parts) != 2:
        raise ValueError(f"invalid coords selector: {selector!r}")
    try:
        x = float(parts[0])
        y = float(parts[1])
    except ValueError:
        raise ValueError(f"invalid coords selector: {selector!r}") from None
    return x, y


async def handle_click(
    session: PlaywrightSession,
    command: BrowserCommand,
) -> BrowserResultPayload:
    """Click the element matching ``payload.selector``.

    Special-case: if the selector begins with ``__coords:`` (emitted by
    the frontend's screenshot click-mapping when no DOM selector is known)
    we parse it as ``__coords:x,y`` and dispatch via ``page.mouse.click``
    at viewport coordinates instead of a locator lookup.
    """
    payload = command.payload
    if not payload.selector:
        raise ValueError("click requires 'selector'")

    state = await session.get_or_create_tab(_resolve_tab_key(command))
    if payload.selector.startswith(_COORDS_PREFIX):
        x, y = _parse_coords_selector(payload.selector)
        await state.page.mouse.click(x, y)
    else:
        await state.page.locator(payload.selector).click()
    return BrowserResultPayload(
        ok=True,
        current_url=state.page.url,
        title=await state.page.title(),
    )


async def handle_type(
    session: PlaywrightSession,
    command: BrowserCommand,
) -> BrowserResultPayload:
    """Focus ``payload.selector`` and type ``payload.text`` character by character.

    ``type()`` (rather than ``fill()``) so keypress event listeners on
    pages like search-as-you-type inputs fire naturally — matters for
    sites that key off keydown.

    Special selector ``__focused`` skips the locator and types into
    whatever the page already has focused — used by the workspace
    take-control UX where the user clicked first to focus a field, then
    typed. Without this they'd need a CSS selector for every input,
    which the frontend doesn't have.
    """
    payload = command.payload
    if not payload.selector:
        raise ValueError("type requires 'selector'")
    if payload.text is None:
        raise ValueError("type requires 'text'")

    state = await session.get_or_create_tab(_resolve_tab_key(command))
    if payload.selector == _FOCUSED_SELECTOR:
        await state.page.keyboard.type(payload.text)
    else:
        await state.page.locator(payload.selector).type(payload.text)
    return BrowserResultPayload(ok=True)


async def handle_keypress(
    session: PlaywrightSession,
    command: BrowserCommand,
) -> BrowserResultPayload:
    """Press a single named key against the focused element.

    ``payload.key`` is a Playwright key name (``"Enter"``, ``"Tab"``,
    ``"Backspace"``, ``"ArrowDown"``, ``"a"``, ``"Control+a"`` for
    chords). The frontend's keystroke capture maps ``KeyboardEvent.key``
    values directly here for the names Playwright recognises.
    """
    payload = command.payload
    if not payload.key:
        raise ValueError("keypress requires 'key'")
    state = await session.get_or_create_tab(_resolve_tab_key(command))
    await state.page.keyboard.press(payload.key)
    return BrowserResultPayload(ok=True)


async def handle_scroll(
    session: PlaywrightSession,
    command: BrowserCommand,
) -> BrowserResultPayload:
    """Dispatch a wheel event with ``(dx, dy)`` CSS-pixel deltas."""
    payload = command.payload
    state = await session.get_or_create_tab(_resolve_tab_key(command))
    await state.page.mouse.wheel(payload.dx or 0.0, payload.dy or 0.0)
    return BrowserResultPayload(ok=True)


async def handle_allowlist_add(
    session: PlaywrightSession,
    command: BrowserCommand,
) -> BrowserResultPayload:
    """Add ``payload.host`` to the bridge's runtime + persisted allowlist.

    Triggered by the workspace UI's "Add to allowlist" button on the
    allowlist-block notification. Persists via the daemon-supplied
    callback so the host survives bridge restarts.
    """
    payload = command.payload
    if not payload.host:
        raise ValueError("allowlist_add requires 'host'")
    # SecurityGate.add_host raises ValueError on malformed input — that
    # falls through to dispatch's wire-level error handling.
    normalized = session.security.add_host(payload.host)
    logger.info("handler.allowlist_added", host=normalized, command_id=command.command_id)
    return BrowserResultPayload(ok=True)


async def handle_screenshot(
    session: PlaywrightSession,
    command: BrowserCommand,
) -> BrowserResultPayload:
    """Capture a screenshot — full-page when ``payload.full_page`` is True.

    Reports the live ``window.innerWidth/innerHeight`` so the frontend
    take-control UX can scale a click on the displayed image back to the
    coords Chromium actually saw. ``page.viewport_size`` is None for
    headed contexts (window-driven), so we evaluate the size at capture
    time. Failure to read the size shouldn't block the screenshot —
    we fall back to omitting the field.
    """
    payload = command.payload
    state = await session.get_or_create_tab(_resolve_tab_key(command))
    png_bytes = await state.page.screenshot(full_page=bool(payload.full_page))
    viewport_w: int | None = None
    viewport_h: int | None = None
    try:
        size = await state.page.evaluate(
            "() => ({w: window.innerWidth, h: window.innerHeight})"
        )
        viewport_w = int(size["w"])
        viewport_h = int(size["h"])
    except Exception:  # noqa: BLE001 — viewport reporting is best-effort
        logger.debug("handler.viewport_read_failed", command_id=command.command_id)
    return BrowserResultPayload(
        ok=True,
        current_url=state.page.url,
        screenshot_b64=base64.b64encode(png_bytes).decode("ascii"),
        viewport_w=viewport_w,
        viewport_h=viewport_h,
    )


async def handle_read_dom(
    session: PlaywrightSession,
    command: BrowserCommand,
) -> BrowserResultPayload:
    """Return the outerHTML of ``payload.selector`` (or whole page if None)."""
    payload = command.payload
    state = await session.get_or_create_tab(_resolve_tab_key(command))

    if payload.selector:
        html = await state.page.locator(payload.selector).evaluate(
            "el => el.outerHTML"
        )
    else:
        html = await state.page.content()

    if isinstance(html, str) and len(html.encode("utf-8")) > DOM_SNIPPET_BYTE_CAP:
        # Truncate at UTF-8 byte boundary by walking back from the cap
        # until we hit a valid prefix. Keeps the wire payload bounded
        # without slicing mid-codepoint.
        encoded = html.encode("utf-8")[:DOM_SNIPPET_BYTE_CAP]
        html = encoded.decode("utf-8", errors="ignore")

    return BrowserResultPayload(ok=True, dom_snippet=html)


async def handle_console_logs(
    session: PlaywrightSession,
    command: BrowserCommand,
) -> BrowserResultPayload:
    """Drain buffered console messages newer than ``payload.since_ts``."""
    payload = command.payload
    tab_key = _resolve_tab_key(command)
    logs = session.drain_console_logs(tab_key, payload.since_ts)
    return BrowserResultPayload(ok=True, console_logs=logs)


async def handle_list_tabs(
    session: PlaywrightSession,
    command: BrowserCommand,
) -> BrowserResultPayload:
    """Return the set of currently-open tabs.

    BC.1.2 carries the ``[{tab_id, url, title}]`` list through the
    ``console_logs`` slot of ``BrowserResultPayload`` — it's the only
    list-of-dicts field on the existing protocol. BC.3 will add a typed
    ``tabs`` field; until then the MCP/CLI surface reshapes this on the
    way out.
    """
    tabs = await session.list_tabs()
    return BrowserResultPayload(ok=True, console_logs=tabs)


# ---------------------------------------------------------------------------
# Dispatch table
# ---------------------------------------------------------------------------


_HandlerType = Callable[
    [PlaywrightSession, BrowserCommand], Awaitable[BrowserResultPayload]
]

_HANDLERS: dict[BrowserAction, _HandlerType] = {
    "navigate": handle_navigate,
    "click": handle_click,
    "type": handle_type,
    "screenshot": handle_screenshot,
    "read_dom": handle_read_dom,
    "console_logs": handle_console_logs,
    "list_tabs": handle_list_tabs,
    "keypress": handle_keypress,
    "scroll": handle_scroll,
    "allowlist_add": handle_allowlist_add,
}


async def handle(command: BrowserCommand, session: PlaywrightSession) -> BrowserResult:
    """Dispatch a validated ``BrowserCommand`` to the right handler.

    Behaviour:
      - On handler success: returns ``BrowserResult(ok=True, ...)``.
      - On ``ValueError`` from a handler (missing required field):
        returns ``BrowserResult(ok=False, error="<message>")``.
      - On any other exception: logs and returns
        ``BrowserResult(ok=False, error="<exception class>: <message>")``.

    Args:
        command: A pydantic-validated ``BROWSER_COMMAND`` envelope.
        session: The shared ``PlaywrightSession`` instance.
    """
    action = command.payload.action
    handler = _HANDLERS.get(action)
    if handler is None:
        # Defensive — pydantic should have rejected unknown actions at
        # parse time, but if it ever doesn't we want a clean error rather
        # than a KeyError traceback.
        logger.warning(
            "handler.unknown_action", action=action, command_id=command.command_id
        )
        return BrowserResult(
            command_id=command.command_id,
            payload=BrowserResultPayload(ok=False),
            error=f"unknown action: {action}",
        )

    # --- Security gates (BC.6.1) -----------------------------------------
    # Order matters: pause check first (cheapest, hardest reject),
    # allowlist next (action-specific), rate limit last (records on pass).
    paused_err = command and command.payload and _check_paused(session)
    if paused_err:
        logger.info("handler.paused", action=action, command_id=command.command_id)
        return BrowserResult(
            command_id=command.command_id,
            payload=BrowserResultPayload(ok=False),
            error=paused_err,
        )

    if action == "navigate" and command.payload.url:
        allow_err = session.security.check_navigate_allowed(command.payload.url)
        if allow_err:
            logger.info("handler.allowlist_block", url=command.payload.url, command_id=command.command_id)
            # Surface the bare host alongside the error so the frontend
            # can render an "Add <host> to allowlist" prompt without
            # parsing the message string.
            return BrowserResult(
                command_id=command.command_id,
                payload=BrowserResultPayload(
                    ok=False,
                    denied_host=_host_of(command.payload.url),
                ),
                error=allow_err,
            )

    rate_err = session.security.check_and_record_rate()
    if rate_err:
        logger.warning("handler.rate_limited", command_id=command.command_id)
        return BrowserResult(
            command_id=command.command_id,
            payload=BrowserResultPayload(ok=False),
            error=rate_err,
        )

    try:
        result_payload = await handler(session, command)
        return BrowserResult(command_id=command.command_id, payload=result_payload)
    except ValueError as e:
        # Per-action validation error — surface the message verbatim.
        logger.info(
            "handler.validation_error",
            action=action,
            command_id=command.command_id,
            error=str(e),
        )
        return BrowserResult(
            command_id=command.command_id,
            payload=BrowserResultPayload(ok=False),
            error=str(e),
        )
    except Exception as e:  # noqa: BLE001 — broad on purpose
        logger.exception(
            "handler.error",
            action=action,
            command_id=command.command_id,
        )
        return BrowserResult(
            command_id=command.command_id,
            payload=BrowserResultPayload(ok=False),
            error=f"{type(e).__name__}: {e}",
        )
