"""HMAC-SHA256 signing for relay ↔ bridge messages.

This mirrors ``agent/remotedev_agent/daemon.py``'s ``_compute_hmac`` /
``_verify_hmac`` so the relay can validate bridge messages with the same
code path it uses for agent messages.

Key derivation: the per-user bridge token is used directly as the HMAC key.
Wire format: every outbound message gets a top-level ``hmac_sig`` field
holding the hex digest of HMAC-SHA256(token, canonical_json_payload).

Canonical JSON = ``json.dumps(msg, sort_keys=True)`` *without* the
``hmac_sig`` field. Keep both sides identical or signatures will diverge
even on logically equivalent payloads.
"""

from __future__ import annotations

import hashlib
import hmac
import json
from typing import Any


def compute_hmac(payload_json: str, token: str) -> str:
    """Compute the hex HMAC-SHA256 digest of ``payload_json`` keyed by ``token``.

    Args:
        payload_json: Canonical-JSON serialization of the message body
            (with sorted keys, no ``hmac_sig`` field).
        token: The per-user bridge token used as the HMAC key.

    Returns:
        Hex digest string, suitable for direct assignment to ``hmac_sig``.
    """
    return hmac.new(
        token.encode(),
        payload_json.encode(),
        hashlib.sha256,
    ).hexdigest()


def sign_message(msg: dict[str, Any], token: str) -> dict[str, Any]:
    """Return a copy of ``msg`` with an ``hmac_sig`` field attached.

    The input dict is not mutated. We canonicalize via ``sort_keys=True`` so
    the receiving side can re-serialize and hit the same byte sequence.
    """
    # Defensive copy — callers may stash the unsigned dict elsewhere.
    body = {k: v for k, v in msg.items() if k != "hmac_sig"}
    payload = json.dumps(body, sort_keys=True)
    body["hmac_sig"] = compute_hmac(payload, token)
    return body


def verify_message(msg: dict[str, Any], token: str) -> bool:
    """Return True iff ``msg["hmac_sig"]`` is valid for ``msg`` under ``token``.

    Unsigned messages return False — there is no backwards-compat bypass.
    Uses ``hmac.compare_digest`` to avoid leaking match progress via timing.
    """
    sig = msg.get("hmac_sig")
    if not isinstance(sig, str):
        return False
    body = {k: v for k, v in msg.items() if k != "hmac_sig"}
    payload = json.dumps(body, sort_keys=True)
    expected = compute_hmac(payload, token)
    return hmac.compare_digest(sig, expected)
