# ⚡ AIVibe

**The Ultimate AI Coding Assistant for Modern Web Apps.**

AIVibe is a powerful CLI-based coding assistant designed to help you build modern, fast, and beautiful web applications. It understands your project structure, reads your files, and executes commands—all while keeping you in total control.

![AIVibe Demo Interface](demo.png)


## 🚀 Features

- **Multi-Provider Support**: Switch between OpenRouter, Groq, and Native Gemini via a beautiful local control panel.
- **Project Aware**: Automatically maps your directory tree to provide full context to the AI.
- **Native File Operations**: Creates, reads, and deletes files directly within your project.
- **Smart Command Execution**: Runs dev servers, installs dependencies, and manages builds with user confirmation.
- **Beautiful UI**: Powered by `Rich` and `Prompt-Toolkit` for a premium terminal experience.

## 🛠️ Installation

Simply install via pip:

```powershell
pip install aivibe-ai
```

## ⌨️ Usage

Launch AIVibe from any project directory:

```powershell
aivibe
```

On first launch, it will guide you through the setup of your API key and model selection.

### Commands inside AIVibe:
- `/tree`: View the full project file structure.
- `/clear`: Clear the local chat history to save context.
- `exit`: Quit the application.

## 🛡️ SECURITY WARNING

> [!CAUTION]
> **AIVibe executes AI-suggested shell commands directly on your machine.**
> *   **Always review commands** before hitting Enter.
> *   **Never run as root/administrator.**
> *   AI models can occasionally suggest destructive commands (e.g., `rm -rf /`). Use at your own risk.

## ⚖️ License

MIT License. See [LICENSE](LICENSE) for details.
