"""
AIVibe Configuration Manager
Handles API key storage, model preferences, and project settings.
All config stored in ~/.aivibe/config.json
"""

import json
import os
from pathlib import Path
from typing import Optional, Dict, Any

CONFIG_DIR = Path.home() / ".aivibe"
CONFIG_FILE = CONFIG_DIR / "config.json"
HISTORY_FILE = CONFIG_DIR / "history.json"

DEFAULT_CONFIG = {
    "api_key": "",
    "base_url": "https://openrouter.ai/api/v1",
    "default_model": "google/gemini-2.5-flash",
    "temperature": 0.7,
    "max_tokens": 16384,
    "stream": True,
    "theme": "dark",
    "auto_save": True,
    "project_root": ".",
    "preferred_models": [
        "google/gemini-2.5-flash",
        "google/gemini-2.5-pro",
        "anthropic/claude-sonnet-4",
        "anthropic/claude-3.5-sonnet",
        "openai/gpt-4o",
        "openai/gpt-4o-mini",
        "meta-llama/llama-3.1-405b-instruct",
        "meta-llama/llama-3.1-70b-instruct",
        "mistralai/mistral-large",
        "deepseek/deepseek-chat",
        "deepseek/deepseek-coder",
        "qwen/qwen-2.5-coder-32b-instruct",
        "google/lyria-3-pro-preview",
        "meta-llama/llama-3.3-70b-instruct:free",
        "qwen/qwen3-coder:free",
        "nousresearch/hermes-3-llama-3.1-405b:free",
        "openai/gpt-oss-120b:free",
    ],
}

AVAILABLE_MODELS = {
    "google/gemini-2.5-flash": {
        "name": "Gemini 2.5 Flash",
        "provider": "Google",
        "context": 1048576,
        "speed": "⚡ Ultra Fast",
        "cost": "$",
    },
    "google/gemini-2.5-pro": {
        "name": "Gemini 2.5 Pro",
        "provider": "Google",
        "context": 1048576,
        "speed": "🚀 Fast",
        "cost": "$$",
    },
    "anthropic/claude-sonnet-4": {
        "name": "Claude Sonnet 4",
        "provider": "Anthropic",
        "context": 200000,
        "speed": "🚀 Fast",
        "cost": "$$$",
    },
    "anthropic/claude-3.5-sonnet": {
        "name": "Claude 3.5 Sonnet",
        "provider": "Anthropic",
        "context": 200000,
        "speed": "🚀 Fast",
        "cost": "$$",
    },
    "openai/gpt-4o": {
        "name": "GPT-4o",
        "provider": "OpenAI",
        "context": 128000,
        "speed": "🚀 Fast",
        "cost": "$$",
    },
    "openai/gpt-4o-mini": {
        "name": "GPT-4o Mini",
        "provider": "OpenAI",
        "context": 128000,
        "speed": "⚡ Ultra Fast",
        "cost": "$",
    },
    "meta-llama/llama-3.1-405b-instruct": {
        "name": "Llama 3.1 405B",
        "provider": "Meta",
        "context": 131072,
        "speed": "🐢 Medium",
        "cost": "$$",
    },
    "meta-llama/llama-3.1-70b-instruct": {
        "name": "Llama 3.1 70B",
        "provider": "Meta",
        "context": 131072,
        "speed": "🚀 Fast",
        "cost": "$",
    },
    "mistralai/mistral-large": {
        "name": "Mistral Large",
        "provider": "Mistral",
        "context": 128000,
        "speed": "🚀 Fast",
        "cost": "$$",
    },
    "deepseek/deepseek-chat": {
        "name": "DeepSeek Chat",
        "provider": "DeepSeek",
        "context": 65536,
        "speed": "⚡ Ultra Fast",
        "cost": "$",
    },
    "deepseek/deepseek-coder": {
        "name": "DeepSeek Coder",
        "provider": "DeepSeek",
        "context": 65536,
        "speed": "⚡ Ultra Fast",
        "cost": "$",
    },
    "qwen/qwen-2.5-coder-32b-instruct": {
        "name": "Qwen 2.5 Coder 32B",
        "provider": "Alibaba",
        "context": 131072,
        "speed": "🚀 Fast",
        "cost": "$",
    },
    "google/lyria-3-pro-preview": {
        "name": "Google Lyria 3 Pro",
        "provider": "Google",
        "context": 1048576,
        "speed": "⚡ Ultra Fast",
        "cost": "FREE",
    },
    "meta-llama/llama-3.3-70b-instruct:free": {
        "name": "Llama 3.3 70B",
        "provider": "Meta",
        "context": 131072,
        "speed": "🚀 Fast",
        "cost": "FREE",
    },
    "qwen/qwen3-coder:free": {
        "name": "Qwen 3 Coder",
        "provider": "Alibaba",
        "context": 65536,
        "speed": "⚡ Ultra Fast",
        "cost": "FREE",
    },
    "nousresearch/hermes-3-llama-3.1-405b:free": {
        "name": "Hermes 3 (405B)",
        "provider": "NousResearch",
        "context": 128000,
        "speed": "🐢 Medium",
        "cost": "FREE",
    },
    "openai/gpt-oss-120b:free": {
        "name": "GPT OSS 120B",
        "provider": "OpenAI",
        "context": 32768,
        "speed": "🚀 Fast",
        "cost": "FREE",
    },
}

def ensure_config_dir():
    """Create config directory if it doesn't exist."""
    CONFIG_DIR.mkdir(parents=True, exist_ok=True)


def load_config() -> Dict[str, Any]:
    """Load configuration from JSON file."""
    ensure_config_dir()
    if CONFIG_FILE.exists():
        try:
            with open(CONFIG_FILE, "r") as f:
                saved = json.load(f)
            # Merge with defaults to pick up new keys
            config = {**DEFAULT_CONFIG, **saved}
            return config
        except (json.JSONDecodeError, IOError):
            return DEFAULT_CONFIG.copy()
    return DEFAULT_CONFIG.copy()


def save_config(config: Dict[str, Any]):
    """Save configuration to JSON file with restricted permissions."""
    ensure_config_dir()
    # Write to a temporary string first
    content = json.dumps(config, indent=2)
    
    # Create/Open file with specific permissions: 0600 (Owner read/write only)
    # This works on most Unix systems; on Windows, it uses the default secure ACLs for the user's home dir.
    mode = 0o600
    if os.path.exists(CONFIG_FILE):
        os.chmod(CONFIG_FILE, mode)
        
    with open(CONFIG_FILE, "w") as f:
        f.write(content)
        
    # Ensure permissions are set immediately after creation
    try:
        os.chmod(CONFIG_FILE, mode)
    except:
        pass # Some Windows environments might handle permissions differently via ACLs


def get_api_key() -> Optional[str]:
    """Get the OpenRouter API key."""
    config = load_config()
    key = config.get("api_key", "")
    if not key:
        key = os.environ.get("OPENROUTER_API_KEY", "")
    return key if key else None


def set_api_key(key: str):
    """Set the OpenRouter API key."""
    config = load_config()
    config["api_key"] = key
    save_config(config)


def get_model() -> str:
    """Get the current model."""
    config = load_config()
    return config.get("default_model", DEFAULT_CONFIG["default_model"])


def set_model(model: str):
    """Set the default model."""
    config = load_config()
    config["default_model"] = model
    save_config(config)


def get_base_url() -> str:
    """Get the OpenRouter base URL."""
    config = load_config()
    return config.get("base_url", DEFAULT_CONFIG["base_url"])


def save_conversation_history(history: list):
    """Save conversation history."""
    ensure_config_dir()
    with open(HISTORY_FILE, "w") as f:
        json.dump(history, f, indent=2)


def load_conversation_history() -> list:
    """Load conversation history."""
    if HISTORY_FILE.exists():
        try:
            with open(HISTORY_FILE, "r") as f:
                return json.load(f)
        except (json.JSONDecodeError, IOError):
            return []
    return []
