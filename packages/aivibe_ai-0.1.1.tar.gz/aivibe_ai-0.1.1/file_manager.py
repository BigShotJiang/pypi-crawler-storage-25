"""
AIVibe File Manager
Handles file creation, editing, reading, and project structure management.
Supports creating complete PHP + TailwindCSS + HTMX + Alpine.js projects.
"""

import os
import re
import difflib
from pathlib import Path
from typing import List, Dict, Optional, Tuple


class FileManager:
    """Manages file operations for AIVibe projects."""

    def __init__(self, project_root: str = "."):
        self.project_root = Path(project_root).resolve()

    def get_project_root(self) -> Path:
        return self.project_root

    def set_project_root(self, path: str):
        self.project_root = Path(path).resolve()

    def resolve_path(self, filepath: str) -> Path:
        """Resolve a filepath relative to project root and prevent traversal."""
        # Sanitize input: remove leading slashes and prevent ".." traversal
        clean_path = filepath.lstrip("\\/")
        if ".." in clean_path:
             raise ValueError(f"Security Warning: Path traversal detected in {filepath}")
             
        p = Path(clean_path)
        if p.is_absolute():
            # If absolute, it must be within project root
            try:
                p.relative_to(self.project_root)
                return p
            except ValueError:
                raise ValueError(f"Security Warning: Absolute path {filepath} is outside project root")
        
        return (self.project_root / clean_path).resolve()

    def read_file(self, filepath: str) -> Optional[str]:
        """Read file contents."""
        try:
            path = self.resolve_path(filepath)
            with open(path, "r", encoding="utf-8") as f:
                return f.read()
        except (IOError, OSError, UnicodeDecodeError):
            return None

    def write_file(self, filepath: str, content: str) -> bool:
        """Write content to a file, creating directories as needed."""
        try:
            path = self.resolve_path(filepath)
            path.parent.mkdir(parents=True, exist_ok=True)
            with open(path, "w", encoding="utf-8") as f:
                f.write(content)
            return True
        except (IOError, OSError):
            return False

    def file_exists(self, filepath: str) -> bool:
        """Check if a file exists."""
        return self.resolve_path(filepath).exists()

    def list_files(self, directory: str = ".", pattern: str = "*") -> List[str]:
        """List files in a directory."""
        try:
            path = self.resolve_path(directory)
            files = []
            for p in sorted(path.rglob(pattern)):
                if p.is_file() and not self._is_ignored(p):
                    files.append(str(p.relative_to(self.project_root)))
            return files
        except (IOError, OSError):
            return []

    def get_project_tree(self, max_depth: int = 4) -> str:
        """Get a tree representation of the project structure."""
        lines = []
        self._build_tree(self.project_root, "", lines, 0, max_depth)
        return "\n".join(lines) if lines else "(empty project)"

    def _build_tree(self, path: Path, prefix: str, lines: list, depth: int, max_depth: int):
        if depth > max_depth:
            return
        entries = sorted(path.iterdir(), key=lambda e: (not e.is_dir(), e.name.lower()))
        entries = [e for e in entries if not self._is_ignored(e)]

        for i, entry in enumerate(entries):
            is_last = i == len(entries) - 1
            connector = "└── " if is_last else "├── "
            icon = "📁 " if entry.is_dir() else self._file_icon(entry.name)
            lines.append(f"{prefix}{connector}{icon}{entry.name}")

            if entry.is_dir():
                extension = "    " if is_last else "│   "
                self._build_tree(entry, prefix + extension, lines, depth + 1, max_depth)

    def _file_icon(self, filename: str) -> str:
        ext = Path(filename).suffix.lower()
        icons = {
            ".php": "🐘 ", ".html": "🌐 ", ".css": "🎨 ",
            ".js": "⚡ ", ".json": "📋 ", ".py": "🐍 ",
            ".md": "📝 ", ".txt": "📄 ", ".sql": "🗃️ ",
            ".env": "🔒 ", ".htaccess": "⚙️ ", ".xml": "📰 ",
            ".svg": "🖼️ ", ".png": "🖼️ ", ".jpg": "🖼️ ",
        }
        return icons.get(ext, "📄 ")

    def _is_ignored(self, path: Path) -> bool:
        """Check if a path should be ignored."""
        ignore = {
            ".git", "__pycache__", "node_modules", ".vscode",
            ".idea", ".DS_Store", "vendor", ".env", ".aivibe_cache"
        }
        return any(part in ignore for part in path.parts)

    def create_diff(self, filepath: str, new_content: str) -> str:
        """Create a unified diff between existing and new content."""
        existing = self.read_file(filepath) or ""
        old_lines = existing.splitlines(keepends=True)
        new_lines = new_content.splitlines(keepends=True)

        diff = difflib.unified_diff(
            old_lines, new_lines,
            fromfile=f"a/{filepath}",
            tofile=f"b/{filepath}",
        )
        return "".join(diff)

    def apply_edit(self, filepath: str, search: str, replace: str) -> bool:
        """Apply a search-and-replace edit to a file."""
        content = self.read_file(filepath)
        if content is None:
            return False
        if search not in content:
            return False
        new_content = content.replace(search, replace, 1)
        return self.write_file(filepath, new_content)

    def delete_file(self, filepath: str) -> bool:
        """Delete a file."""
        try:
            path = self.resolve_path(filepath)
            if path.exists():
                path.unlink()
                return True
            return False
        except (IOError, OSError):
            return False

    def get_file_info(self, filepath: str) -> Optional[Dict]:
        """Get file metadata."""
        try:
            path = self.resolve_path(filepath)
            if not path.exists():
                return None
            stat = path.stat()
            return {
                "name": path.name,
                "path": str(path.relative_to(self.project_root)),
                "size": stat.st_size,
                "extension": path.suffix,
                "lines": len(self.read_file(filepath).splitlines()) if self.read_file(filepath) else 0,
            }
        except (IOError, OSError):
            return None

    def scaffold_php_project(self, project_name: str = "my-app") -> List[str]:
        """Create a basic PHP + Tailwind + HTMX + Alpine.js project structure."""
        dirs = [
            "assets/css", "assets/js", "assets/images",
            "components", "pages", "includes", "api",
        ]
        for d in dirs:
            (self.project_root / d).mkdir(parents=True, exist_ok=True)

        created = []
        # We don't write template content here — that's handled by the AI
        # Just create the directory structure
        for d in dirs:
            created.append(f"📁 {d}/")

        return created


def parse_file_blocks(response: str) -> List[Dict[str, str]]:
    """
    Parse AI response to extract file blocks.
    Supports formats:
      --- FILE: path/to/file.php ---
      ```language
      code
      ```
    """
    files = []

    # Pattern 1: --- FILE: path --- blocks
    file_pattern = re.compile(
        r'---\s*FILE:\s*(.+?)\s*---\s*\n(.*?)(?=---\s*FILE:|$)',
        re.DOTALL
    )

    matches = file_pattern.findall(response)
    if matches:
        for filepath, content in matches:
            # Strip code fences if present
            content = re.sub(r'^```\w*\n', '', content.strip())
            content = re.sub(r'\n```\s*$', '', content.strip())
            files.append({"path": filepath.strip(), "content": content.strip()})
        return files

    # Pattern 2: **`filepath`** followed by code blocks
    alt_pattern = re.compile(
        r'\*\*`(.+?)`\*\*\s*\n\s*```\w*\n(.*?)```',
        re.DOTALL
    )
    matches = alt_pattern.findall(response)
    if matches:
        for filepath, content in matches:
            files.append({"path": filepath.strip(), "content": content.strip()})
        return files

    # Pattern 3: filepath in heading followed by code block
    heading_pattern = re.compile(
        r'(?:#{1,4}|//)\s*(.+?\.\w+)\s*\n\s*```\w*\n(.*?)```',
        re.DOTALL
    )
    matches = heading_pattern.findall(response)
    if matches:
        for filepath, content in matches:
            fp = filepath.strip().strip('`').strip('*')
            files.append({"path": fp, "content": content.strip()})

    return files
