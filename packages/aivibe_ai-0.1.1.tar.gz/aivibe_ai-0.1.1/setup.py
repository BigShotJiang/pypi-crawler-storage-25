from setuptools import setup, find_packages

setup(
    name="aivibe-ai",
    version="0.1.1",


    py_modules=["aivibe", "config", "file_manager", "streaming", "templates", "server"],
    install_requires=[
        "httpx>=0.27.0",
        "rich>=13.7.0",
        "prompt_toolkit>=3.0.43",
        "click>=8.1.7",
        "watchdog>=4.0.0",
        "pygments>=2.17.0",
        "openai>=1.52.0",
        "fastapi>=0.104.0",
        "uvicorn>=0.23.0",
        "sse-starlette>=2.0.0",
        "pydantic>=2.0.0"
    ],


    entry_points={
        "console_scripts": [
            "aivibe=aivibe:cli",
        ],
    },
    author="AIVibe",
    description="The ultimate AI coding assistant for PHP/Tailwind/HTMX apps.",
)
