"""
AIVibe Local AI Panel & Relayer
Runs a FastAPI local gateway on port 7891. Provides a beautiful UI strictly for managing API configurations,
and dynamically proxies local agent traffic out to OpenRouter, Groq, or Native Gemini depending on frontend selections!
"""

import json
from fastapi import FastAPI, Request
from fastapi.responses import HTMLResponse, StreamingResponse, JSONResponse
from fastapi.middleware.cors import CORSMiddleware
import httpx
from pydantic import BaseModel

from config import load_config, save_config

app = FastAPI(title="AIVibe Gateway Panel")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["http://localhost:7891", "http://127.0.0.1:7891"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


class UpdateKeyModel(BaseModel):
    provider: str
    api_key: str

class SelectAgentModel(BaseModel):
    provider: str
    model: str


def ensure_config_schema():
    c = load_config()
    changed = False
    
    if "agent_keys" not in c:
        c["agent_keys"] = {"openrouter": "", "groq": "", "gemini": ""}
        changed = True
    if "active_provider" not in c:
        c["active_provider"] = "openrouter"
        changed = True
        
    # Migrate old key into agent_keys if missing
    if c.get("api_key") and not c["agent_keys"].get("openrouter"):
        c["agent_keys"]["openrouter"] = c["api_key"]
        changed = True
        
    if changed:
        save_config(c)
    return c


@app.get("/")
def ai_panel():
    """Beautiful local UI control panel."""
    c = ensure_config_schema()
    
    html = f"""
    <!DOCTYPE html>
    <html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>AIVibe - Local AI Panel</title>
        <script src="https://cdn.tailwindcss.com"></script>
        <script defer src="https://cdn.jsdelivr.net/npm/alpinejs@3.x.x/dist/cdn.min.js"></script>
        <style>
            body {{ background-color: #0d1117; color: #c9d1d9; }}
            .glass {{ background: rgba(30, 41, 59, 0.7); backdrop-filter: blur(16px); border: 1px solid rgba(255, 255, 255, 0.1); }}
        </style>
    </head>
    <body class="min-h-screen p-8 flex justify-center" x-data="panelApp()">
        <div class="w-full max-w-4xl space-y-8">
            <h1 class="text-4xl font-extrabold text-transparent bg-clip-text bg-gradient-to-r from-blue-400 to-purple-500">
                ⚡ AIVibe Control Panel
            </h1>
            
            <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                <!-- API Keys Card -->
                <div class="glass p-6 rounded-2xl shadow-xl space-y-4">
                    <h2 class="text-xl font-bold flex items-center space-x-2"><span class="text-indigo-400">🔑</span> <span>Provider API Keys</span></h2>
                    <p class="text-sm text-gray-400 mb-4">Set your secret keys securely. Stored strictly offline in ~/.aivibe/config.json</p>
                    
                    <template x-for="provider in ['openrouter', 'groq', 'gemini']">
                        <div class="flex flex-col space-y-1 mt-4">
                            <label class="text-sm font-semibold text-gray-300 capitalize" x-text="provider"></label>
                            <div class="flex space-x-2">
                                <input type="password" x-model="keys[provider]" class="flex-1 bg-gray-900 border border-gray-700 rounded-lg p-2 focus:ring-2 focus:ring-purple-500 outline-none text-white transition-all shadow-inner" placeholder="sk-...">
                                <button @click="saveKey(provider)" class="bg-indigo-600 hover:bg-indigo-500 px-4 rounded-lg font-medium transition-colors shadow-lg shadow-indigo-500/30">Save</button>
                            </div>
                        </div>
                    </template>
                </div>
                
                <!-- Active Agent Selection -->
                <div class="glass p-6 rounded-2xl shadow-xl flex flex-col space-y-4">
                    <h2 class="text-xl font-bold flex items-center space-x-2"><span class="text-emerald-400">🤖</span> <span>Active AI Agent</span></h2>
                    <p class="text-sm text-gray-400 mb-4">Select which massive intelligence powers your CLI locally.</p>
                    
                    <div class="flex-1 space-y-4 flex flex-col justify-center">
                        <div>
                            <label class="block text-sm font-semibold text-gray-300 mb-1">Provider Engine</label>
                            <select x-model="active_provider" @change="updateModels()" class="w-full bg-gray-900 border border-gray-700 rounded-lg p-2 focus:ring-2 focus:ring-emerald-500 outline-none capitalize">
                                <option value="openrouter">OpenRouter (Massive Selection)</option>
                                <option value="groq">Groq (Ultra-Fast LPUs)</option>
                                <option value="gemini">Google Gemini (Native API)</option>
                            </select>
                        </div>
                        
                        <div>
                            <label class="block text-sm font-semibold text-gray-300 mb-1">Target Model ID</label>
                            
                            <!-- OpenRouter Models -->
                            <select x-show="active_provider === 'openrouter'" x-model="active_model" class="w-full bg-gray-900 border border-gray-700 rounded-lg p-2 focus:ring-2 focus:ring-emerald-500 outline-none text-white text-sm">
                                <optgroup label="⚡ Free Tier">
                                    <option value="google/gemini-2.0-flash-exp:free">Gemini 2.0 Flash (Free)</option>

                                    <option value="meta-llama/llama-3.3-70b-instruct:free">Llama 3.3 70B (Free)</option>
                                    <option value="qwen/qwen3-coder:free">Qwen 3 Coder (Free)</option>
                                    <option value="nousresearch/hermes-3-llama-3.1-405b:free">Hermes 3 405B (Free)</option>
                                    <option value="openai/gpt-oss-120b:free">GPT OSS 120B (Free)</option>
                                </optgroup>
                                <optgroup label="🚀 Paid High-Performance">
                                    <option value="google/gemini-2.5-flash">Gemini 2.5 Flash (Ultra Fast / $)</option>
                                    <option value="google/gemini-2.5-pro">Gemini 2.5 Pro (Genius / $$)</option>
                                    <option value="anthropic/claude-sonnet-4">Claude Sonnet 4 (Best Coder / $$$)</option>
                                    <option value="openai/gpt-4o">GPT-4o (Fast & Smart / $$)</option>
                                    <option value="deepseek/deepseek-coder">DeepSeek Coder V2 (Coding / $)</option>
                                </optgroup>
                            </select>

                            <!-- Groq Models -->
                            <select x-show="active_provider === 'groq'" x-model="active_model" class="w-full bg-gray-900 border border-gray-700 rounded-lg p-2 focus:ring-2 focus:ring-emerald-500 outline-none text-white text-sm">
                                <optgroup label="🚀 High Speed Meta LPUs">
                                    <option value="llama-3.3-70b-versatile">Llama 3.3 70B (Most Stable)</option>
                                    <option value="llama-3.1-8b-instant">Llama 3.1 8B (Instant Speed)</option>
                                </optgroup>
                                <optgroup label="🧪 Experimental 2026 Models">
                                    <option value="openai/gpt-oss-120b">GPT OSS 120B (Reasoning)</option>
                                    <option value="openai/gpt-oss-20b">GPT OSS 20B (Standard)</option>
                                </optgroup>
                            </select>

                            <!-- Gemini Native Models -->
                            <select x-show="active_provider === 'gemini'" x-model="active_model" class="w-full bg-gray-900 border border-gray-700 rounded-lg p-2 focus:ring-2 focus:ring-emerald-500 outline-none text-white text-sm">
                                <optgroup label="🚀 High-Performance Native">
                                    <option value="gemini-2.5-flash">Gemini 2.5 Flash</option>
                                    <option value="gemini-2.5-pro">Gemini 2.5 Pro</option>
                                    <option value="gemini-2.0-flash-lite">Gemini 2.0 Flash Lite</option>
                                    <option value="gemini-1.5-pro-latest">Gemini 1.5 Pro</option>
                                </optgroup>
                            </select>
                            
                            <p class="text-xs text-gray-500 mt-2">Select the desired intelligence node.</p>
                        </div>
                    </div>
                    
                    <button @click="saveAgent()" class="w-full bg-emerald-600 hover:bg-emerald-500 py-3 mt-[auto] rounded-lg font-bold text-lg transition-colors shadow-lg shadow-emerald-500/30">
                        Map Active Agent
                    </button>
                    <p x-show="msg" x-text="msg" x-transition class="text-center text-sm font-bold text-green-400"></p>
                </div>
            </div>
        </div>

        <script>
            function panelApp() {{
                return {{
                    keys: {json.dumps(c.get('agent_keys', {}))},
                    active_provider: "{c.get('active_provider', 'openrouter')}",
                    active_model: "{c.get('default_model', 'google/gemini-2.5-flash')}",
                    msg: "",
                    
                    updateModels() {{
                        // Set strong defaults on tab switch
                        if(this.active_provider === 'groq') this.active_model = 'llama-3.3-70b-versatile';
                        else if(this.active_provider === 'gemini') this.active_model = 'gemini-2.5-flash';
                        else this.active_model = 'google/gemini-2.5-flash';
                    }},
                    
                    async saveKey(provider) {{
                        let res = await fetch('/api/keys', {{
                            method: 'POST',
                            headers: {{'Content-Type': 'application/json'}},
                            body: JSON.stringify({{provider: provider, api_key: this.keys[provider]}})
                        }});
                        this.showMsg("Key Saved!");
                    }},
                    
                    async saveAgent() {{
                        let res = await fetch('/api/select_agent', {{
                            method: 'POST',
                            headers: {{'Content-Type': 'application/json'}},
                            body: JSON.stringify({{provider: this.active_provider, model: this.active_model}})
                        }});
                        this.showMsg("Agent Mapped Successfully to CLI Engine!");
                    }},
                    
                    showMsg(text) {{
                        this.msg = text;
                        setTimeout(() => this.msg = '', 3000);
                    }}
                }}
            }}
        </script>
    </body>
    </html>
    """
    return HTMLResponse(content=html)


@app.post("/api/keys")
def update_key(data: UpdateKeyModel):
    c = ensure_config_schema()
    c["agent_keys"][data.provider] = data.api_key
    save_config(c)
    return {"status": "ok"}

@app.post("/api/select_agent")
def select_agent(data: SelectAgentModel):
    c = ensure_config_schema()
    c["active_provider"] = data.provider
    c["default_model"] = data.model
    save_config(c)
    return {"status": "ok"}


from sse_starlette.sse import EventSourceResponse

@app.post("/v1/chat/completions")
async def chat_proxy(request: Request):
    """
    Acts as an OpenAI proxy relay. Takes the AIVibe CLI request and dynamically routes it 
    to OpenRouter, Groq, or Gemini dynamically based on local UI configuration.
    """
    c = ensure_config_schema()
    payload = await request.json()
    
    provider = c.get("active_provider", "openrouter")
    
    # Provider mapping architecture
    if provider == "groq":
        base_url = "https://api.groq.com/openai/v1/chat/completions"
        api_key = c["agent_keys"].get("groq", "")
    elif provider == "gemini":
        base_url = "https://generativelanguage.googleapis.com/v1beta/openai/chat/completions"
        api_key = c["agent_keys"].get("gemini", "")
    else: # OpenRouter
        base_url = "https://openrouter.ai/api/v1/chat/completions"
        api_key = c["agent_keys"].get("openrouter", "")
        
    if not api_key:
        return JSONResponse({"error": {"message": f"API Key for {provider} not set in Panel!"}}, status_code=401)
        
    headers = {
        "Authorization": f"Bearer {api_key}",
        "Content-Type": "application/json",
        "HTTP-Referer": "https://aivibe.dev",
        "X-Title": "AIVibe Local Node"
    }
    
    # We dynamically override the model from payload with the configured one, 
    # so the UI governs CLI model choice truly dynamically.
    payload["model"] = c.get("default_model", payload.get("model"))
    
    is_stream = payload.get("stream", False)
    
    if is_stream:
        client = httpx.AsyncClient(timeout=120.0)
        req = client.build_request("POST", base_url, json=payload, headers=headers)
        
        try:
            response = await client.send(req, stream=True)
        except Exception as e:
            await client.aclose()
            return JSONResponse({"error": {"message": str(e)}}, status_code=500)
            
        if response.status_code != 200:
            err_txt = await response.aread()
            await response.aclose()
            await client.aclose()
            try:
                err_dict = json.loads(err_txt)
            except:
                err_dict = {"error": {"message": err_txt.decode()}}
            return JSONResponse(err_dict, status_code=response.status_code)
            
        async def event_generator():
            try:
                async for line in response.aiter_lines():
                    if line.startswith("data: "):
                        yield {"data": line[6:]}
            finally:
                await response.aclose()
                await client.aclose()
                
        return EventSourceResponse(event_generator())
    else:
        async with httpx.AsyncClient(timeout=120.0) as client:
            try:
                req = await client.post(base_url, json=payload, headers=headers)
                return JSONResponse(req.json(), status_code=req.status_code)
            except Exception as e:
                return JSONResponse({"error": {"message": str(e)}}, status_code=500)
