# Extra-P

**Automated performance modeling for HPC applications**

[![PyPI - Python Version](https://img.shields.io/pypi/pyversions/extrap?style=plastic)](https://badge.fury.io/py/extrap)
![GitHub release (latest by date)](https://img.shields.io/github/v/release/extra-p/extrap?style=plastic)
[![PyPI version](https://badge.fury.io/py/extrap.png)](https://badge.fury.io/py/extrap)
[![PyPI - License](https://img.shields.io/pypi/l/extrap?style=plastic)](https://badge.fury.io/py/extrap)
![GitHub issues](https://img.shields.io/github/issues/extra-p/extrap?style=plastic)
![GitHub pull requests](https://img.shields.io/github/issues-pr/extra-p/extrap?style=plastic)
![GitHub Workflow Status](https://img.shields.io/github/actions/workflow/status/extra-p/extrap/python-package.yml?style=plastic)

[<img alt="Screenshot of Extra-P" src="https://github.com/extra-p/extrap/raw/master/docs/images/extra-p-2d.png" height="200" align="right" title="Screenshot of Extra-P"/>](docs/images/extra-p-2d.png)
Extra-P is an automatic performance-modeling tool that supports the user in the identification of *scalability bugs*.
A scalability bug is a part of the program whose scaling behavior is unintentionally poor,
that is, much worse than expected. A performance model is a formula that expresses a performance metric of interest
such as execution time or energy consumption as a function of one or more execution parameters such as the size of the
input problem or the number of processors.

Extra-P uses measurements of various performance metrics at different execution configurations as input to generate
performance models of code regions (including their calling context) as a function of the execution parameters.
All it takes to search for scalability issues even in full-blown codes is to run a manageable number of small-scale
performance experiments, launch Extra-P, and compare the asymptotic or extrapolated performance of the worst instances
to the expectations.

Extra-P generates not only a list of potential scalability bugs but also human-readable models for all
performance metrics available such as floating-point operations or bytes sent by MPI calls that can be further
analyzed and compared to identify the root causes of scalability issues.

The following video on the Laboratory for Parallel Programming @ TUDa [YouTube](
https://www.youtube.com/@parallel_tuda) channel provides a quick introduction to Extra-P.

<a href="https://www.youtube.com/watch?v=Cv2YRCMWqBM"><img src="https://img.youtube.com/vi/Cv2YRCMWqBM/0.jpg"
alt="IMAGE ALT TEXT HERE" width="240" height="180" border="10" /></a>

Extra-P is developed by [TU Darmstadt](https://www.parallel.informatik.tu-darmstadt.de/) –
in collaboration with [ETH Zurich](https://spcl.inf.ethz.ch/).

*For questions regarding Extra-P, please send a message to <extra-p-support@lists.parallel.informatik.tu-darmstadt.de>.*

--------------------------------------------------------------------------------------------

### Table of Contents

1. [Requirements](#Requirements)
2. [Installation](#Installation)
3. [How to use it](#Usage)
4. [License](#License)
5. [Citation](#Citation)
6. [Publications](#Publications)

--------------------------------------------------------------------------------------------

### Requirements

* Python 3.8 or higher
* numpy
* pycubexr
* marshmallow
* packaging
* tqdm
* sklearn
* PySide6 (for GUI)
* matplotlib (for GUI)
* pyobjc-framework-Cocoa (only for GUI on macOS)

### Installation

Use the following command to install Extra-P and all required packages via `pip`.

```
python -m pip install extrap --upgrade
``` 

The `--upgrade` forces the installation of a new version if a previous version is already installed.

### Usage

Extra-P can be used in two ways, either using the command-line interface or the graphical user interface. More
information about the usage of Extra-P with both interfaces can be found in
the [quick start guide](docs/quick-start.md).

> **Note**  
> Extra-P is designed for weak-scaling, therefore, directly modeling of strong-scaling behaviour is not supported.
> Instead of modeling the runtime of your strong-scaling experiment, you can model the resource consumption, i.e.,
> the runtime *times* the number of processors. Extra-P automatically offers this conversion, if it detects that
> strong-scaling data was loaded. If you are loading files that contain per-thread/per-rank data you should select
> the scaling-type upfront to run the conversion already during the import.

#### Graphical user interface

The graphical user interface can be started by executing the `extrap-gui` command.

#### Command line interface

The command line interface is available under the `extrap` command:

`extrap` _OPTIONS_ (`--cube` | `--text` | `--talpas` | `--json` | `--extra-p-3` | `--experiment`) _FILEPATH_

You can use different input formats as shown in the examples below:

* Text files: `extrap --text test/data/text/one_parameter_1.txt`
* JSON files: `extrap --json test/data/json/input_1.JSON`
* Talpas files: `extrap --talpas test/data/talpas/talpas_1.txt`
* Create model and save it to text file at the given
  path: `extrap --out test.txt --text test/data/text/one_parameter_1.txt`

You can find an overview about all command line options under [docs/command-line-options.md](docs/command-line-options.md).

### License

[BSD 3-Clause "New" or "Revised" License](LICENSE)

### Citation

Please cite Extra-P in your publications if it helps your research:

Alexandru Calotoiu, Marcin Copik, Fabian Czappa, Alexander Geiß, Gustavo Morais, Marcus Ritter, Sergei Shudler, Torsten Hoefler, Felix Wolf: 
Extra-P – Empirical Performance Modeling Made Easy. *Frontiers in High Performance Computing*, 3–2025, 2026. [10.3389/fhpcp.2025.1714042](https://doi.org/10.3389/fhpcp.2025.1714042)

```
@Article{calotoiu_extra-p_2026,
  author          = {Calotoiu, Alexandru and Copik, Marcin and Czappa, Fabian and Geiß, Alexander and Morais, Gustavo and Ritter, Marcus and Shudler, Sergei and Hoefler, Torsten and Wolf, Felix},
  title           = {Extra-{P} – {Empirical} {Performance} {Modeling} {Made} {Easy}},
  journal         = {Frontiers in High Performance Computing},
  year            = {2026},
  volume          = {3–2025},
  issn            = {2813–7337},
  doi             = {10.3389/fhpcp.2025.1714042}
}
```

### Selected Publications

1. Alexandru Calotoiu, Torsten Hoefler, Marius Poke, Felix Wolf:
   *Using automated performance modeling to find scalability bugs in complex codes*. In Proc. of the International
   Conference on High Performance Computing, Networking, Storage and Analysis (SC '13), ACM, 2013.
   [DOI](https://doi.org/10.1145/2503210.2503277)

2. Alexandru Calotoiu, David Beckingsale, Christopher W. Earl, Torsten Hoefler, Ian Karlin, Martin Schulz, Felix Wolf:
   *Fast Multi-Parameter Performance Modeling*. In Proc. of the 2016 IEEE International Conference on Cluster Computing (
   CLUSTER), Taipei, Taiwan, pages 172–181, IEEE, September
    2016. [PDF](https://apps.fz-juelich.de/jsc-pubsystem/aigaion/attachments/fastmultiparam.pdf-f839eba376c6d61a8c4cab9860b6b3bf.pdf)

3. Marcus Ritter, Alexandru Calotoiu, Sebastian Rinke, Thorsten Reimann, Torsten Hoefler, Felix Wolf: *Learning
   Cost-Effective Sampling Strategies for Empirical Performance Modeling.* In Proc. of the 34th IEEE International
   Parallel and Distributed Processing Symposium (IPDPS), New Orleans, LA, USA, pages 884–895, IEEE, May
    2020. [PDF](https://apps.fz-juelich.de/jsc-pubsystem/aigaion/attachments/ritter_ea_2020_ipdps.pdf-01cbe96f7a170aba7c7ef941f966d292.pdf)

4. Marcus Ritter, Alexander Geiß, Johannes Wehrstein, Alexandru Calotoiu, Thorsten Reimann, Torsten Hoefler, Felix Wolf:
   *Noise-Resilient Empirical Performance Modeling with Deep Neural Networks.* In Proc. of the 35th IEEE International
   Parallel and Distributed Processing Symposium (IPDPS), Portland, Oregon, USA, pages 23–34, IEEE, May
    2021. [PDF](http://htor.inf.ethz.ch/publications/img/noiseresilientmodeling.pdf)

5. Alexander Geiß, Téodora Hovi, Alexandru Calotoiu, Felix Wolf:
   *Validating the Performance of GPU Ports Using Differential Performance Models*. Future Generation Computer Systems, 174: 1–17, January 2026.
   [DOI](https://doi.org/10.1016/j.future.2025.108018)

7. Marcus Ritter, Benedict Naumann, Alexandru Calotoiu, Sebastian Rinke, Thorsten Reimann, Torsten Hoefler, Felix Wolf:
   *Cost-Effective Empirical Performance Modeling*. Transactions on Parallel and Distributed Systems, 37: 575–592, February 2026.
   [PDF](https://www.parallel.informatik.tu-darmstadt.de/zotero-lists/attachments/GH3LJG4Z_Ritter%20et%20al.%20-%202026%20-%20Cost-Effective%20Empirical%20Performance%20Modeling.pdf)

9. Alexandru Calotoiu, Marcin Copik, Fabian Czappa, Alexander Geiß, Gustavo Morais, Marcus Ritter, Sergei Shudler, Torsten Hoefler, Felix Wolf:
   *Extra-P – Empirical Performance Modeling Made Easy*. Frontiers in High Performance Computing, 3–2025, March 2026.
   [DOI](https://doi.org/10.3389/fhpcp.2025.1714042)
