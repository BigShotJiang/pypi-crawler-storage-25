"""
Unit tests for ignis_lfx package
"""

import pytest

def test_package_imports():
    """Test that the package can be imported"""
    import ignis_lfx
    assert hasattr(ignis_lfx, '__version__')
    assert hasattr(ignis_lfx, '__author__')

def test_version():
    """Test version is properly set"""
    import ignis_lfx
    assert isinstance(ignis_lfx.__version__, str)
    assert len(ignis_lfx.__version__) > 0
