"""
IGNIS LFX - Langflow Executor

A powerful Python package for executing Langflow flows with advanced
component management, memory handling, and flow execution features.
"""

__version__ = "0.1.0"
__author__ = "Infogain"
__email__ = "nishanth.p@infogain.com"
__license__ = "MIT"
__url__ = "https://github.com/Infogain-GenAI/ignis-lfx"

# Core components
try:
    from ignis_lfx.core import execute_flow, FlowExecutor
    __all__ = ["execute_flow", "FlowExecutor"]
except ImportError:
    # Allow partial imports if core modules aren't available
    __all__ = []
