"""
Core execution engine for IGNIS LFX
"""

__all__ = ["execute_flow", "FlowExecutor"]

# Placeholder - users should implement their core modules
# This is where the main execution logic would go
