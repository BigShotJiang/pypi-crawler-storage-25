# Changelog

## [0.1.0] - 2024

### Added
- Initial release of ignis_lfx
- Core flow execution engine with async support
- Session-based memory management system
- FastAPI integration for REST endpoints
- MCP (Model Context Protocol) support
- Component library with 50+ pre-built components
- Support for multiple LLM providers (OpenAI, Ollama, IBM)
- Command-line interface (CLI) for flow execution
- Comprehensive logging and error handling
- Type hints throughout the codebase
- Full test coverage with pytest
- Documentation and examples

### Features
- Execute Langflow JSON flows programmatically
- Manage conversation memory with sessions
- Access component library for flow building
- Integrate with FastAPI for web services
- Support for environmental configuration
- Async/await support for non-blocking operations

### Documentation
- README with installation and quick start guide
- API documentation and examples
- Contributing guidelines
- Development setup instructions

---

For more details, visit [GitHub Repository](https://github.com/Infogain-GenAI/ignis-lfx)
