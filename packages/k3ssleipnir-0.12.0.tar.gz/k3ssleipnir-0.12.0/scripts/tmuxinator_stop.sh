#!/usr/bin/env bash

SCRIPT_DIR=$(dirname "$(realpath "$0")")

# podman stop --all
# podman rm --all
#
# podman ps
