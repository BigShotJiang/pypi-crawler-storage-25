#!/usr/bin/env bash

SCRIPT_DIR=$(dirname "$(realpath "$0")")

cd $SCRIPT_DIR/../
rm -frR .venv/ dist/

ehco "DIR: $(pwd)"

uv venv
source .venv/bin/activate

ls -lahrt

uv pip install -r requirements-dev.txt || true
uv pip install -r requirements.txt || true

# cd $SCRIPT_DIR/dist
# rm -vf *
#
# $SCRIPT_DIR/build.sh
#
# uv pip install --upgrade dist/*.tar.gz
