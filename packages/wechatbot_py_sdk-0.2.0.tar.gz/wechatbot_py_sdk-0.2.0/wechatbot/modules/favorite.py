
class FavoriteModule:
    def __init__(self, client):
        self.client = client

    def sync_favorite(self, sync_key: str, token):
        """
        同步收藏夹！
        :param sync_key: 翻页key，首次传空，获取下一页传接口返回的syncKey
        :param token: token值
        :return
        """
        payload = {
             "syncKey": sync_key
        }
        return self.client.request("POST", "/syncFavorite", token, json=payload)

    def get_favorite(self, fav_id: int, token):
        """
        获取收藏夹内容!
        :param fav_id: 收藏夹ID
        :param token: token值
        :return:
        """
        payload = {
            "favId": fav_id
        }
        return self.client.request("POST", "/getFavorite", token, json=payload)

    def delete_favorite(self, fav_id: int, token):
        """
        删除收藏夹!
        :param fav_id: 收藏夹ID
        :param token: token值
        :return
        """
        payload = {
            "favId": fav_id
        }
        return self.client.request("POST", "/deleteFavorite", token, json=payload)
