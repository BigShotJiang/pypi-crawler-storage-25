
from .auth import AuthModule
from .message import MessageModule
from .group import GroupModule
from .personal import PersonalModule
from .favorite import FavoriteModule
from .label import LabelModule
from .download import DownModule
from .contact import ContactModule
from .sns import SnsModule
from .finder import FinderModule
__all__ = ['AuthModule', 'MessageModule', 'GroupModule', 'PersonalModule', 'FavoriteModule', 'LabelModule', 'DownModule', 'ContactModule', 'SnsModule', 'FinderModule']
__version__ = '0.2.0'
__author__ = '花骨朵轻创'
__email__ = '2377349179@qq.com'
__license__ = 'MIT'




