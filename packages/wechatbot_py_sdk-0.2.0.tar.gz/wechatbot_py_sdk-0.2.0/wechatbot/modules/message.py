
class MessageModule:
    def __init__(self, client):
        self.client = client

    def send_text(self, to_wxid: str, content: str, token, at_list: list = None):
        """
        发送文本消息!
        :param to_wxid: 目标微信ID
        :param content: 消息内容
        :param token:   token值
        :param at_list: 群里添加@目标
        :return
        """
        payload = {
            "toWxid": to_wxid,
            "content": content,
            "atWxidList": at_list or []
        }
        return self.client.request("POST", "/sendTextMessage", token, json=payload)

    def send_image(self, to_wxid: str, image_url: str, token,):
        """
        发送图片消息！
        :param to_wxid: 目标微信ID
        :param image_url: 上传对象存储后获取
        :param token: token值
        :return
        """
        payload = {
            "toWxid": to_wxid,
            "imgUrl": image_url
        }
        return self.client.request("POST", "/sendImageMessage", token, json=payload)

    def send_voice(self, to_wxid: str, silk_url: str, voice_duration: int, token):
        """
        发送语音消息！
        :param to_wxid: 目标微信ID
        :param silk_url: 上传对象存储后获取
        :param voice_duration: 语音时长
        :param token: token值
        :return
        """
        payload = {
            "toWxid": to_wxid,
            "voiceUrl": silk_url,
            "voiceDuration": voice_duration
        }
        return self.client.request("POST", "/sendVoiceMessage", token, json=payload)

    def send_audio(self, to_wxid: str, audio_url: str, thumb_url: str, video_duration: int, token):
        """
        发送视频消息！
        :param to_wxid: 目标微信ID
        :param audio_url: 上传对象存储后获取
        :param thumb_url: 上传对象存储后获取(缩略图)
        :param video_duration: 视频时长
        :param token: token值
        :return
        """
        payload = {
            "toWxid": to_wxid,
            "videoUrl": audio_url,
            "thumbUrl": thumb_url,
            "videoDuration": video_duration
        }
        return self.client.request("POST", "/sendVedioMessage", token, json=payload)

    def send_file(self, to_wxid: str, file_name: str, file_url: str, token):
        """
        发送文件消息！
        :param to_wxid: 目标微信ID
        :param file_name: 文件名称
        :param file_url: 上传对象存储后获取
        :param token: token值
        :return
        """
        payload = {
            "toWxid": to_wxid,
            "fileName": file_name,
            "fileUrl": file_url
        }
        return self.client.request("POST", "/sendFileMessage", token, json=payload)

    def send_link(self, to_wxid: str, title: str, desc: str, link: str, thumb_url: str, token):
        """
        发送链接消息！
        :param to_wxid: 目标微信ID
        :param title: 链接标题
        :param desc: 链接描述
        :param link: 链接URL
        :param thumb_url 缩略图
        :param token: token值
        :return
        """
        payload = {
            "toWxid": to_wxid,
            "title": title,
            "desc": desc,
            "linkUrl": link,
            "thumbUrl": thumb_url
        }
        return self.client.request("POST", "/sendLinkMessage", token, json=payload)

    def send_card(self, to_wxid: str, nickname: str, target_wxid: str, token):
        """
        发送名片消息！
        :param to_wxid: 目标微信ID
        :param nickname: 昵称
        :param target_wxid: 被发送微信ID
        :param token: token值！
        :return:
        """
        payload = {
            "toWxid": to_wxid,
            "nickName": nickname,
            "nameCardWxid": target_wxid

        }
        return self.client.request("POST", "/sendCardMessage", token, json=payload)

    def send_emoji(self, to_wxid: str, md5: str, size: int, token):
        """
        发送emoji表情！
        :param to_wxid: 目标微信ID
        :param md5:  emoji图片的md5
        :param size: emoji的文件大小
        :param token: token值
        :return:
        """
        payload = {
            "toWxid": to_wxid,
            "emojiMd5": md5,
            "emojiSize": size,
            "token": token
        }
        return self.client.request("POST", "/sendEmojiMessage", token, json=payload)

    def send_app(self, to_wxid: str, app_msg: str, token):
        """
        :param to_wxid: 目标微信ID
        :param app_msg: 回调信息中获取
        :param token: token值
        :return:
        """
        payload = {
            "toWxid": to_wxid,
            "appmsg": app_msg
        }
        return self.client.request("POST", "/sendAppMessage", token, json=payload)

    def send_miniapp(self, to_wxid: str, mini_appid: str, username: str, title: str, img_url: str, page_url: str, dis_title: str, token):
        """
        发送小程序消息(参数回调中获取)
        :param to_wxid: 目标微信ID
        :param mini_appid: 小程序ID
        :param username: 小程序名称
        :param title: 小程序标题
        :param img_url: 小程序封面图链接
        :param page_url: 小程序打开的地址
        :param dis_title: 归属用户ID
        :param token: token值
        :return:
        """
        payload = {
            "toWxid": to_wxid,
            "miniAppId": mini_appid,
            "userName": username,
            "title": title,
            "coverImgUrl": img_url,
            "pagePath": page_url,
            "displayName": dis_title
        }
        return self.client.request("POST", "/sendMiniappMessage", token, json=payload)

    def send_location(self, to_wxid: str, content: str, token):
        """
        发送位置信息!
        :param to_wxid: 目标微信ID
        :param content: xml消息内容（可以从回调中获取）
        :param token: token值
        :return:
        """
        payload = {
            "toWxid": to_wxid,
            "content": content
        }
        return self.client.request("POST", "/sendLocationMessage", token, json=payload)

    def revoke_msg(self, to_wxid: str, msg_id: str, new_msgid: str, create_time: int, token):
        """
        撤回消息!(撤回有时效限制)
        :param to_wxid: 目标微信ID
        :param msg_id: 发送类接口返回的msgId
        :param new_msgid: 发送类接口返回的newMsgId
        :param create_time: 发送类接口返回的createTime
        :param token: token值
        :return
        """
        payload = {
            "toWxid": to_wxid,
            "msgId": msg_id,
            "newMsgId": new_msgid,
            "createTime": create_time
        }
        return self.client.request("POST", "/sendRevokeMessage", token, json=payload)

    def forward_file(self, to_wxid: str, xml: str, token):
        """
        转发文件!
        :param to_wxid: 目标微信ID
        :param xml: 文件消息的xml（回调中获取）
        :param token: token值
        :return:
        """
        payload = {
            "toWxid": to_wxid,
            "xml": xml
        }
        return self.client.request("POST", "/sendForwardFileMessage", token, json=payload)

    def forward_image(self, to_wxid: str, xml: str, token):
        """
        转发图片!
        :param to_wxid: 目标微信ID
        :param xml: 图片消息的xml（回调中获取）
        :param token: token值
        :return:
        """
        payload = {
            "toWxid": to_wxid,
            "xml": xml
        }
        return self.client.request("POST", "/sendForwardImageMessage", token, json=payload)

    def forward_video(self, to_wxid: str, xml: str, token):
        """
        转发视频!
        :param to_wxid: 目标微信ID
        :param xml: 视频消息的xml（回调中获取）
        :param token: token值
        :return:
        """
        payload = {
            "toWxid": to_wxid,
            "xml": xml
        }
        return self.client.request("POST", "/sendForwardVideoMessage", token, json=payload)

    def forward_link(self, to_wxid: str, xml: str, token):
        """
        转发链接!
        :param to_wxid: 目标微信ID
        :param xml: 链接消息的xml（回调中获取）
        :param token: token值
        :return:
        """
        payload = {
            "toWxid": to_wxid,
            "xml": xml
        }
        return self.client.request("POST", "/sendForwardUrlMessage", token, json=payload)

    def forward_miniapp(self, to_wxid: str, xml: str, cover_img_url: str, token):
        """
        转发小程序!
        :param to_wxid: 目标微信ID
        :param xml: 小程序消息的xml（回调中获取）
        :param cover_img_url: 小程序封面图链接
        :param token: token值
        :return:
        """
        payload = {
            "toWxid": to_wxid,
            "xml": xml,
            "coverImgUrl": cover_img_url
        }
        return self.client.request("POST", "/sendForwardMiniAppMessage", token, json=payload)
