

class FinderModule:
    def __init__(self, client):
        self.client = client

    def create_finder(self, proxy_ip: str, signature: str, head_img: str, nick_name: str, sex: int, token):
        """
        创建视频号！
        :param proxy_ip: 代理
        :param signature: 视频号签名
        :param head_img: 视频号头像链接
        :param nick_name: 视频号昵称
        :param sex: 性别 0/1
        :param token: token值
        :return
        """
        payload = {
            "proxyIp": proxy_ip,
            "signature": signature,
            "headImg": head_img,
            "nickName": nick_name,
            "sex": sex
        }
        return self.client.request("POST", "/createFinder", token, json=payload)

    def get_profile(self, token, proxy_ip: str = ""):
        """
        获取我的视频号信息!
        :param token: token值
        :param proxy_ip: 代理
        :return
        """
        payload = {
            "proxyIp": proxy_ip
        }
        return self.client.request("POST", "/getProfile", token, json=payload)

    def finder_search(self, content: str, token, proxy_ip: str = "", category: int = 1, filter: int = 0, page: int = 0, cookie: str = "", search_id: str = "", offset: int = 0):
        """
        搜索视频号!
        :param content: 搜索内容
        :param token: token值
        :param proxy_ip: 代理
        :param category: 搜索类型，1: 搜索全部 2: 搜索账号（视频号ID）
        :param filter: 筛选，0: 不限 1: 最新 2: 朋友赞过
        :param page: 首次传0，后续调用时每次加1
        :param cookie: 首次传空，后续传接口返回的data.cookies字段
        :param search_id: 首次传空，后续传接口返回的data.searchID字段
        :param offset: 首次传0，后续传接口返回的data.offset字段
        :return
        """
        payload = {
            "proxyIp": proxy_ip,
            "content": content,
            "category": category,
            "filter": filter,
            "page": page,
            "cookie": cookie,
            "searchId": search_id,
            "offset": offset
        }
        return self.client.request("POST", "/finderSearch", token, json=payload)

    def follow(self, my_username: str, my_role_type: int, op_type: int, to_username: str, token, proxy_ip: str = "", search_info: dict = None):
        """
        关注/取消关注!
        :param my_username: 自己的username
        :param my_role_type: 自己的roletype
        :param op_type: 1:关注 2:取消关注
        :param to_username: 对方的username
        :param token: token值
        :param proxy_ip: 代理
        :param search_info: 如果是通过搜索渠道关注，则传搜索接口返回的cookies、searchId、docId，格式：{"cookies":"","searchId":"","docId":""}
        :return
        """
        payload = {
            "proxyIp": proxy_ip,
            "myUserName": my_username,
            "myRoleType": my_role_type,
            "opType": op_type,
            "toUserName": to_username,
            "searchInfo": search_info or {"cookies": "", "searchId": "", "docId": ""}
        }
        return self.client.request("POST", "/follow", token, json=payload)

    def comment(self, my_username: str, op_type: int, object_nonce_id: str, session_buffer: str, object_id: int, my_role_type: int, content: str, comment_id: str, token, proxy_ip: str = "", reply_username: str = "", ref_comment_id: int = 0, root_comment_id: int = 0):
        """
        评论/删除评论!
        :param my_username: 自己的username
        :param op_type: 0评论 1删除评论
        :param object_nonce_id: 视频号的objectNonceId
        :param session_buffer: 视频号的sessionBuffer
        :param object_id: 视频号的objectId
        :param my_role_type: 自己的roletype
        :param content: 评论内容
        :param comment_id: 评论id
        :param token: token值
        :param proxy_ip: 代理
        :param reply_username: 回复评论的username
        :param ref_comment_id: 回复评论时传
        :param root_comment_id: 回复评论时传
        :return
        """
        payload = {
            "proxyIp": proxy_ip,
            "myUserName": my_username,
            "opType": op_type,
            "objectNonceId": object_nonce_id,
            "sessionBuffer": session_buffer,
            "objectId": object_id,
            "myRoleType": my_role_type,
            "content": content,
            "commentId": comment_id,
            "replyUserName": reply_username,
            "refCommentId": ref_comment_id,
            "rootCommentId": root_comment_id
        }
        return self.client.request("POST", "/comment", token, json=payload)

    def browse(self, my_username: str, object_nonce_id: str, session_buffer: str, object_id: int, my_role_type: int, token, proxy_ip: str = ""):
        """
        浏览视频!
        :param my_username: 自己的username
        :param object_nonce_id: 视频号的objectNonceId
        :param session_buffer: 视频号的sessionBuffer
        :param object_id: 视频号的objectId
        :param my_role_type: 自己的roletype
        :param token: token值
        :param proxy_ip: 代理
        :return
        """
        payload = {
            "proxyIp": proxy_ip,
            "myUserName": my_username,
            "objectNonceId": object_nonce_id,
            "sessionBuffer": session_buffer,
            "objectId": object_id,
            "myRoleType": my_role_type
        }
        return self.client.request("POST", "/browse", token, json=payload)

    def publish_finder_web(self, title: str, video_url: str, thumb_url: str, description: str, token):
        """
        发布视频-新！（请使用ipad协议登录微信，目前mac暂不支持此接口）
        :param title: 视频标题
        :param video_url: 视频链接
        :param thumb_url: 封面图链接
        :param description: 视频描述
        :param token: token值
        :return
        """
        payload = {
            "title": title,
            "videoUrl": video_url,
            "thumbUrl": thumb_url,
            "description": description
        }
        return self.client.request("POST", "/publishFinderWeb", token, json=payload)

    def user_page(self, to_username: str, token, proxy_ip: str = "", last_buffer: str = "", max_id: int = 0, search_info: dict = None):
        """
        用户主页!
        :param to_username: 用户的username
        :param token: token值
        :param proxy_ip: 代理
        :param last_buffer: 首次传空，后续传接口返回的lastBuffer
        :param max_id: 首次传0，后续传响应结果中最后一条的id
        :param search_info: 如果是通过搜索渠道获取用户主页，则传搜索接口返回的cookies、searchId，格式：{"cookies":"","searchId":""}
        :return
        """
        payload = {
            "proxyIp": proxy_ip,
            "lastBuffer": last_buffer,
            "toUserName": to_username,
            "maxId": max_id
        }
        if search_info:
            payload["searchInfo"] = search_info
        return self.client.request("POST", "/userPage", token, json=payload)

    def follow_list(self, my_username: str, my_role_type: int, token, proxy_ip: str = "", last_buffer: str = ""):
        """
        关注列表!
        :param my_username: 自己的username
        :param my_role_type: 自己的roletype
        :param token: token值
        :param proxy_ip: 代理
        :param last_buffer: 首次传空，后续传接口返回的lastBuffer
        :return
        """
        payload = {
            "proxyIp": proxy_ip,
            "myUserName": my_username,
            "lastBuffer": last_buffer,
            "myRoleType": my_role_type
        }
        return self.client.request("POST", "/followList", token, json=payload)

    def mention_list(self, my_username: str, my_role_type: int, req_scene: int, token, last_buff: str = ""):
        """
        消息列表!
        :param my_username: 自己的username
        :param my_role_type: 自己的roletype
        :param req_scene: 消息类型 3是点赞 4是评论 5是关注
        :param token: token值
        :param last_buff: 首次传空，后续传接口返回的lastBuffer
        :return
        """
        payload = {
            "myUserName": my_username,
            "lastBuff": last_buff,
            "myRoleType": my_role_type,
            "reqScene": req_scene
        }
        return self.client.request("POST", "/mentionList", token, json=payload)

    def comment_list(self, session_buffer: str, object_id: str, token, proxy_ip: str = "", root_comment_id: int = 0, ref_comment_id: int = 0, object_nonce_id: str = "", last_buffer: str = ""):
        """
        评论列表!
        :param session_buffer: 视频号的sessionBuffer
        :param object_id: 视频号ID
        :param token: token值
        :param proxy_ip: 代理
        :param root_comment_id: 获取评论回复时传
        :param ref_comment_id: 获取评论回复时传
        :param object_nonce_id: 视频号的objectNonceId
        :param last_buffer: 首次传空，后续传接口返回的lastBuffer
        :return
        """
        payload = {
            "proxyIp": proxy_ip,
            "rootCommentId": root_comment_id,
            "refCommentId": ref_comment_id,
            "objectNonceId": object_nonce_id,
            "sessionBuffer": session_buffer,
            "lastBuffer": last_buffer,
            "objectId": object_id
        }
        return self.client.request("POST", "/commentList", token, json=payload)

    def like_fav_list(self, my_username: str, my_role_type: int, flag: int, token, proxy_ip: str = "", last_buffer: str = ""):
        """
        获取赞与收藏的视频列表!
        :param my_username: 自己的username
        :param my_role_type: 自己的roletype
        :param flag: 7是全部 1是红心 2是大拇指 4是收藏
        :param token: token值
        :param proxy_ip: 代理
        :param last_buffer: 首次传空，后续传接口返回的lastBuffer
        :return
        """
        payload = {
            "proxyIp": proxy_ip,
            "myUserName": my_username,
            "lastBuffer": last_buffer,
            "myRoleType": my_role_type,
            "flag": flag
        }
        return self.client.request("POST", "/likeFavList", token, json=payload)

    def sync_private_letter_msg(self, token, proxy_ip: str = "", key_buff: str = ""):
        """
        同步私信消息!（请使用ipad协议登录微信，目前mac暂不支持此接口）
        :param token: token值
        :param proxy_ip: 代理
        :param key_buff: 首次传空，后续传接口返回的keyBuff
        :return
        """
        payload = {
            "proxyIp": proxy_ip,
            "keyBuff": key_buff
        }
        return self.client.request("POST", "/syncPrivateLetterMsg", token, json=payload)

    def id_fav(self, my_username: str, op_type: int, object_nonce_id: str, session_buffer: str, object_id: int, to_username: str, my_role_type: int, token, proxy_ip: str = ""):
        """
        根据id点赞!
        :param my_username: 自己的username
        :param op_type: 1点赞 2取消点赞
        :param object_nonce_id: 视频号的objectNonceId
        :param session_buffer: 视频号的sessionBuffer
        :param object_id: 视频号的ID
        :param to_username: 视频所有者userName
        :param my_role_type: 自己的roletype
        :param token: token值
        :param proxy_ip: 代理
        :return
        """
        payload = {
            "proxyIp": proxy_ip,
            "myUserName": my_username,
            "opType": op_type,
            "objectNonceId": object_nonce_id,
            "sessionBuffer": session_buffer,
            "objectId": object_id,
            "toUserName": to_username,
            "myRoleType": my_role_type
        }
        return self.client.request("POST", "/idFav", token, json=payload)

    def id_like(self, my_username: str, op_type: int, object_nonce_id: str, session_buffer: str, object_id: int, to_username: str, my_role_type: int, token, proxy_ip: str = ""):
        """
        根据id点小红心!
        :param my_username: 自己的username
        :param op_type: 3喜欢 4不喜欢
        :param object_nonce_id: 视频号的objectNonceId
        :param session_buffer: 视频号的sessionBuffer
        :param object_id: 视频号的objectId
        :param to_username: 视频所有者userName
        :param my_role_type: 自己的roletype
        :param token: token值
        :param proxy_ip: 代理
        :return
        """
        payload = {
            "proxyIp": proxy_ip,
            "myUserName": my_username,
            "opType": op_type,
            "objectNonceId": object_nonce_id,
            "sessionBuffer": session_buffer,
            "objectId": object_id,
            "toUserName": to_username,
            "myRoleType": my_role_type
        }
        return self.client.request("POST", "/idLike", token, json=payload)

    def update_profile(self, my_username: str, my_role_type: int, token, proxy_ip: str = "", signature: str = "", head_img: str = "", nick_name: str = "", sex: int = None, city: str = "", province: str = "", country: str = ""):
        """
        修改我的视频号信息!
        :param my_username: 自己的username，可通过获取视频号信息接口获取
        :param my_role_type: 自己的roletype，可通过获取视频号信息接口获取
        :param token: token值
        :param proxy_ip: 代理
        :param signature: 个性签名
        :param head_img: 头像链接
        :param nick_name: 昵称
        :param sex: 性别
        :param city: 城市
        :param province: 省份
        :param country: 国家
        :return
        """
        payload = {
            "proxyIp": proxy_ip,
            "myUserName": my_username,
            "myRoleType": my_role_type
        }
        if signature:
            payload["signature"] = signature
        if head_img:
            payload["headImg"] = head_img
        if nick_name:
            payload["nickName"] = nick_name
        if sex is not None:
            payload["sex"] = sex
        if city:
            payload["city"] = city
        if province:
            payload["province"] = province
        if country:
            payload["country"] = country
        return self.client.request("POST", "/updateProfile", token, json=payload)

    def send_finder_msg(self, to_wxid: str, vid_id: int, username: str, nickname: str, head_url: str, nonce_id: str, media_type: str, width: str, height: str, url: str, thumb_url: str, thumb_url_token: str, description: str, video_play_len: str, token, proxy_ip: str = ""):
        """
        发送视频号消息!
        :param to_wxid: 接收人wxid
        :param vid_id: 视频信息id
        :param username: 视频发布者username
        :param nickname: 视频发布者昵称
        :param head_url: 视频发布者头像
        :param nonce_id: 视频nonceId
        :param media_type: 视频类型
        :param width: 视频宽度
        :param height: 视频高度
        :param url: 视频url
        :param thumb_url: 缩略图url
        :param thumb_url_token: 缩略图token
        :param description: 视频描述
        :param video_play_len: 播放时长
        :param token: token值
        :param proxy_ip: 代理
        :return
        """
        payload = {
            "proxyIp": proxy_ip,
            "toWxid": to_wxid,
            "id": vid_id,
            "username": username,
            "nickname": nickname,
            "headUrl": head_url,
            "nonceId": nonce_id,
            "mediaType": media_type,
            "width": width,
            "height": height,
            "url": url,
            "thumbUrl": thumb_url,
            "thumbUrlToken": thumb_url_token,
            "description": description,
            "videoPlayLen": video_play_len
        }
        return self.client.request("POST", "/sendFinderMsg", token, json=payload)

    def send_finder_sns(self, allow_wx_ids: list, at_wx_ids: list, disable_wx_ids: list, vid_id: int, username: str, nickname: str, head_url: str, nonce_id: str, media_type: str, width: str, height: str, url: str, thumb_url: str, thumb_url_token: str, description: str, video_play_len: str, token, proxy_ip: str = ""):
        """
        发送视频号朋友圈!
        :param allow_wx_ids: 允许谁看
        :param at_wx_ids: 提醒谁看
        :param disable_wx_ids: 不给谁看
        :param vid_id: 视频id
        :param username: 视频作者username
        :param nickname: 视频作者昵称
        :param head_url: 作者头像
        :param nonce_id: nonceId
        :param media_type: 类型
        :param width: 宽度
        :param height: 高度
        :param url: 视频url
        :param thumb_url: 缩略图url
        :param thumb_url_token: 缩略图token
        :param description: 视频描述
        :param video_play_len: 播放时长
        :param token: token值
        :param proxy_ip: 代理
        :return
        """
        payload = {
            "proxyIp": proxy_ip,
            "allowWxIds": allow_wx_ids,
            "atWxIds": at_wx_ids,
            "disableWxIds": disable_wx_ids,
            "id": vid_id,
            "username": username,
            "nickname": nickname,
            "headUrl": head_url,
            "nonceId": nonce_id,
            "mediaType": media_type,
            "width": width,
            "height": height,
            "url": url,
            "thumbUrl": thumb_url,
            "thumbUrlToken": thumb_url_token,
            "description": description,
            "videoPlayLen": video_play_len
        }
        return self.client.request("POST", "/sendFinderSns", token, json=payload)

    def contact_list(self, my_username: str, query_info: str, my_role_type: int, token, proxy_ip: str = ""):
        """
        获取私信人信息!
        :param my_username: 自己的username
        :param query_info: 联系人的username
        :param my_role_type: 自己的roletype
        :param token: token值
        :param proxy_ip: 代理
        :return
        """
        payload = {
            "proxyIp": proxy_ip,
            "myUserName": my_username,
            "queryInfo": query_info,
            "myRoleType": my_role_type
        }
        return self.client.request("POST", "/contactList", token, json=payload)

    def post_private_letter(self, content: str, msg_session_id: str, my_username: str, to_username: str, token, proxy_ip: str = ""):
        """
        发私信文本消息!
        :param content: 私信内容
        :param msg_session_id: 可通过/contactList接口获取
        :param my_username: 自己的username
        :param to_username: 接收方的username
        :param token: token值
        :param proxy_ip: 代理
        :return
        """
        payload = {
            "proxyIp": proxy_ip,
            "content": content,
            "msgSessionId": msg_session_id,
            "myUserName": my_username,
            "toUserName": to_username
        }
        return self.client.request("POST", "/postPrivateLetter", token, json=payload)

    def post_private_letter_img(self, img_url: str, msg_session_id: str, my_username: str, to_username: str, token, proxy_ip: str = ""):
        """
        发私信图片消息!
        :param img_url: 私信图片链接地址
        :param msg_session_id: 可通过/contactList接口获取
        :param my_username: 自己的username
        :param to_username: 接收方的username
        :param token: token值
        :param proxy_ip: 代理
        :return
        """
        payload = {
            "proxyIp": proxy_ip,
            "imgUrl": img_url,
            "msgSessionId": msg_session_id,
            "myUserName": my_username,
            "toUserName": to_username
        }
        return self.client.request("POST", "/postPrivateLetterImg", token, json=payload)

    def scan_follow(self, my_username: str, my_role_type: int, qr_content: str, token, proxy_ip: str = "", object_id: str = "", object_nonce_id: str = ""):
        """
        扫码关注!
        :param my_username: 当前用户的userName
        :param my_role_type: 身份类型 1：微信 3：视频号
        :param qr_content: 内容信息，二维码链接或对方的userName
        :param token: token值
        :param proxy_ip: 代理
        :param object_id: 如果qrContent为对方userName则参数必传，内容从用户主页获取
        :param object_nonce_id: 如果qrContent为对方userName则参数必传，内容从用户主页获取
        :return
        """
        payload = {
            "proxyIp": proxy_ip,
            "myUserName": my_username,
            "myRoleType": my_role_type,
            "qrContent": qr_content,
            "objectId": object_id,
            "objectNonceId": object_nonce_id
        }
        return self.client.request("POST", "/scanFollow", token, json=payload)

    def search_follow(self, my_username: str, my_role_type: int, to_username: str, keyword: str, token):
        """
        搜索并关注!
        :param my_username: 自己的username
        :param my_role_type: 自己的roletype
        :param to_username: 对方的username
        :param keyword: 搜索关键词
        :param token: token值
        :return
        """
        payload = {
            "myUserName": my_username,
            "myRoleType": my_role_type,
            "toUserName": to_username,
            "keyword": keyword
        }
        return self.client.request("POST", "/searchFollow", token, json=payload)

    def scan_browse(self, my_username: str, my_role_type: int, qr_content: str, object_id: int, token, proxy_ip: str = ""):
        """
        扫码浏览!
        :param my_username: 自己的username
        :param my_role_type: 自己的roletype
        :param qr_content: 获取方式：官方视频号助手->内容管理->视频->复制视频链接
        :param object_id: 视频号的objectId
        :param token: token值
        :param proxy_ip: 代理
        :return
        """
        payload = {
            "proxyIp": proxy_ip,
            "myUserName": my_username,
            "myRoleType": my_role_type,
            "qrContent": qr_content,
            "objectId": object_id
        }
        return self.client.request("POST", "/scanBrowse", token, json=payload)

    def scan_comment(self, my_username: str, my_role_type: int, qr_content: str, object_id: int, comment_content: str, token, proxy_ip: str = "", reply_username: str = "", ref_comment_id: int = 0, root_comment_id: int = 0):
        """
        扫码评论!
        :param my_username: 自己的username
        :param my_role_type: 自己的roletype
        :param qr_content: 获取方式：官方视频号助手->内容管理->视频->复制视频链接
        :param object_id: 视频号的objectId（获取用户主页返回的视频id）
        :param comment_content: 评论内容
        :param token: token值
        :param proxy_ip: 代理
        :param reply_username: 回复的username
        :param ref_comment_id: 回复评论时传
        :param root_comment_id: 回复评论时传
        :return
        """
        payload = {
            "proxyIp": proxy_ip,
            "myUserName": my_username,
            "myRoleType": my_role_type,
            "qrContent": qr_content,
            "objectId": object_id,
            "commentContent": comment_content,
            "replyUsername": reply_username,
            "refCommentId": ref_comment_id,
            "rootCommentId": root_comment_id
        }
        return self.client.request("POST", "/scanComment", token, json=payload)

    def scan_fav(self, my_username: str, my_role_type: int, qr_content: str, object_id: int, token, proxy_ip: str = ""):
        """
        扫码点赞!
        :param my_username: 自己的username
        :param my_role_type: 自己的roletype
        :param qr_content: 获取方式：官方视频号助手->内容管理->视频->复制视频链接
        :param object_id: 视频号的objectId（获取用户主页返回的视频id）
        :param token: token值
        :param proxy_ip: 代理
        :return
        """
        payload = {
            "proxyIp": proxy_ip,
            "myUserName": my_username,
            "myRoleType": my_role_type,
            "qrContent": qr_content,
            "objectId": object_id
        }
        return self.client.request("POST", "/scanFav", token, json=payload)

    def scan_like(self, my_username: str, my_role_type: int, qr_content: str, object_id: int, token, proxy_ip: str = ""):
        """
        扫码点小红心!
        :param my_username: 自己的username
        :param my_role_type: 自己的roletype
        :param qr_content: 获取方式：官方视频号助手->内容管理->视频->复制视频链接
        :param object_id: 视频号的objectId（获取用户主页返回的视频id）
        :param token: token值
        :param proxy_ip: 代理
        :return
        """
        payload = {
            "proxyIp": proxy_ip,
            "myUserName": my_username,
            "myRoleType": my_role_type,
            "qrContent": qr_content,
            "objectId": object_id
        }
        return self.client.request("POST", "/scanLike", token, json=payload)

    def finder_opt(self, my_username: str, my_role_type: int, to_username: str, op_type: int, vid_id: str, remain: int, token):
        """
        延迟点赞、小红心!
        :param my_username: 自己的username
        :param my_role_type: 自己的roletype
        :param to_username: 对方的username
        :param op_type: 1点赞 3小红心
        :param vid_id: 视频id
        :param remain: remain值
        :param token: token值
        :return
        """
        payload = {
            "myUserName": my_username,
            "myRoleType": my_role_type,
            "toUserName": to_username,
            "opType": op_type,
            "id": vid_id,
            "remain": remain
        }
        return self.client.request("POST", "/finderOpt", token, json=payload)

    def scan_login_channels(self, qr_content: str, token, proxy_ip: str = ""):
        """
        扫码登录视频号助手!
        :param qr_content: 视频号助手官方二维码解析出来的内容
        :param token: token值
        :param proxy_ip: 代理
        :return
        """
        payload = {
            "proxyIp": proxy_ip,
            "qrContent": qr_content
        }
        return self.client.request("POST", "/scanLoginChannels", token, json=payload)

    def scan_qr_code(self, my_username: str, my_role_type: int, qr_content: str, token, proxy_ip: str = ""):
        """
        扫码获取视频详情!
        :param my_username: 自己的username
        :param my_role_type: 自己的roletype
        :param qr_content: 获取方式：官方视频号助手->内容管理->视频->复制视频链接
        :param token: token值
        :param proxy_ip: 代理
        :return
        """
        payload = {
            "proxyIp": proxy_ip,
            "myUserName": my_username,
            "myRoleType": my_role_type,
            "qrContent": qr_content
        }
        return self.client.request("POST", "/scanQrCode", token, json=payload)

    def get_qr_code(self, my_username: str, my_role_type: int, token, proxy_ip: str = ""):
        """
        我的视频号二维码!
        :param my_username: 自己的username
        :param my_role_type: 自己的roletype
        :param token: token值
        :param proxy_ip: 代理
        :return
        """
        payload = {
            "proxyIp": proxy_ip,
            "myUserName": my_username,
            "myRoleType": my_role_type
        }
        return self.client.request("POST", "/finderGetQrCode", token, json=payload)

    def upload_finder_video(self, video_url: str, cover_img_url: str, token, proxy_ip: str = ""):
        """
        上传CDN视频!（建议多个号批量发布时使用，某个号调用1次上传，其余号直接调用发布CDN视频，无需重复上传）
        :param video_url: 视频链接地址
        :param cover_img_url: 封面链接地址
        :param token: token值
        :param proxy_ip: 代理
        :return
        """
        payload = {
            "proxyIp": proxy_ip,
            "videoUrl": video_url,
            "coverImgUrl": cover_img_url
        }
        return self.client.request("POST", "/uploadFinderVideo", token, json=payload)

    def publish_finder_cdn(self, my_username: str, my_role_type: int, description: str, video_cdn: dict, token, proxy_ip: str = "", topic: list = None):
        """
        发布CDN视频!（建议多个号批量发布时使用，某个号调用1次上传CDN视频，其余号直接调用此接口，无需重复上传）
        :param my_username: 自己的username
        :param my_role_type: 自己的roletype
        :param description: 视频号描述
        :param video_cdn: 视频的cdn信息，通过/uploadFinderVideo接口获取，格式：{"fileUrl":"","thumbUrl":"","mp4Identify":"","fileSize":"","thumbMD5":"","fileKey":""}
        :param token: token值
        :param proxy_ip: 代理
        :param topic: 话题列表，如 ["#话题1", "#话题2"]
        :return
        """
        payload = {
            "proxyIp": proxy_ip,
            "topic": topic or [],
            "myUserName": my_username,
            "myRoleType": my_role_type,
            "description": description,
            "videoCdn": video_cdn
        }
        return self.client.request("POST", "/publishFinderCdn", token, json=payload)
