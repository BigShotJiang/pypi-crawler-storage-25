
class LabelModule:
    def __init__(self, client):
        self.client = client

    def add_label(self, label_name: str, token):
        """
        添加标签！
        :param label_name: 标签名称
        :param token: token值
        :return
        """
        payload = {
             "labelName": label_name
        }
        return self.client.request("POST", "/addLabel", token, json=payload)

    def list_label(self, token):
        """
        标签列表!
        :param token: token值
        :return:
        """
        payload = {}
        return self.client.request("POST", "/listLabel", token, json=payload)

    def delete_label(self, label_ids: str, token):
        """
        删除标签！
        :param label_ids: 标签ID，多个id就用逗号分隔
        :param token: token值
        :return
        """
        payload = {
            "labelIds": label_ids
        }
        return self.client.request("POST", "/deleteLabel", token, json=payload)

    def modify_friend_label(self, label_ids: str, wx_ids: list, token):
        """
        修改好友标签!
        :param label_ids: 标签ID，多个逗号分隔
        :param wx_ids: 修改的好友微信ID（列表）
        :param token: token值
        :return:
        """
        payload = {
            "labelIds": label_ids,
            "wxIds": wx_ids
        }
        return self.client.request("POST", "/modifyMemberList", token, json=payload)

