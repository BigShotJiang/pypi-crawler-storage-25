
class SnsModule:
    def __init__(self, client):
        self.client = client

    def sns_list(self, max_id: int, decrypt: bool, first_page_md5: str, token):
        """
        我的朋友圈列表!（上号1-3天后允许使用）

        :param max_id: 首次传0，第二页及以后传接口返回的maxId
        :param decrypt: 是否解密
        :param first_page_md5: 首次传空，第二页及以后传接口返回的firstPageMd5
        :param token: token值
        :return
        """
        payload = {
            "maxId": max_id,
            "decrypt": decrypt,
            "firstPageMd5": first_page_md5
        }
        return self.client.request("POST", "/snsList", token, json=payload)

    def sns_like(self, sns_id: int, ope_type: int, wx_id: str, token):
        """
        点赞/取消点赞!

        :param sns_id: 朋友圈ID
        :param ope_type: 1点赞 2取消点赞
        :param wx_id: 点赞的好友微信ID
        :param token: token值
        :return
        """
        payload = {
            "snsId": sns_id,
            "operType": ope_type,
            "wxid": wx_id
        }
        return self.client.request("POST", "/likeSns", token, json=payload)

    def sns_delete(self, sns_id: int, token):
        """
        删除朋友圈!

        :param sns_id: 朋友圈ID
        :param token: token值
        :return
        """
        payload = {
            "snsId": sns_id
        }
        return self.client.request("POST", "/delSns", token, json=payload)

    def sns_scope(self, option: int, token):
        """
        设置朋友圈可见范围!

        :param option: 朋友圈可见范围 option 可选项 1:全部 2:最近半年 3:最近一个月 4:最近三天
        :param token: token值
        :return:
        """
        payload = {
            "option": option
        }
        return self.client.request("POST", "/snsVisibleScope", token, json=payload)

    def sns_visibility_enable(self, enabled: bool, token):
        """
        是否允许陌生人查看朋友圈!

        :param enabled: True允许 False不允许
        :param token: token值
        :return
        """
        payload = {
            "enabled": enabled
        }
        return self.client.request("POST", "/strangerVisibilityEnabled", token, json=payload)

    def sns_set_status(self, sns_id: int, open_s: bool, token):
        """
        设置某条朋友圈为隐私/公开!

        :param sns_id: 朋友圈ID
        :param open_s: True公开False不公开
        :param token: token值
        :return
        """
        payload = {
            "snsId": sns_id,
            "open": open_s
        }
        return self.client.request("POST", "/snsSetPrivacy", token, json=payload)

    def sns_download_video(self, sns_xml: str, token):
        """
        下载朋友圈视频!

        :param sns_xml: 获取到的朋友圈XML
        :param token: token值
        :return
        """
        payload = {
            "snsXml": sns_xml
        }
        return self.client.request("POST", "/downloadSnsVideo", token, json=payload)

    def sns_send_text(self, allow_ids: list, at_ids: list, disable_ids: list, content: str, privacy: bool, allow_tag_ids: list, disable_tag_ids: list, token):
        """
        发送文字朋友圈!（上号1-3天后允许使用）

        :param allow_ids: 允许谁看
        :param at_ids: 提醒谁看
        :param disable_ids: 不给谁看
        :param content: 朋友圈文字内容
        :param privacy: 是否私密
        :param allow_tag_ids: 允许谁看（标签id）
        :param disable_tag_ids: 不给谁看（标签id）
        :param token: token值
        :return
        """
        payload = {
            "allowWxIds": allow_ids,
            "atWxIds": at_ids,
            "disableWxIds": disable_ids,
            "content": content,
            "privacy": privacy,
            "allowTagIds": allow_tag_ids,
            "disableTagIds": disable_tag_ids
        }
        return self.client.request("POST", "/sendTextSns", token, json=payload)

    def sns_send_img(self, allow_ids: list, at_ids: list, disable_ids: list, content: str, file_url: str, thumb_url: str, file_md5: str, length: int, width: int, height: int, privacy: bool, allow_tag_ids: list, disable_tag_ids: list, token):
        """
        发送图片朋友圈！（上号1-3天后允许使用）
        PS:通过上传朋友圈图片接口获取（1<= items <= 9 items）

        :param allow_ids: 允许谁看
        :param at_ids: 提醒谁看
        :param disable_ids: 不给谁看
        :param content: 朋友圈文字内容
        :param file_url: 图片链接
        :param thumb_url: 缩略图链接
        :param file_md5: Md5
        :param length:
        :param width: 图片宽度
        :param height: 图片高度
        :param privacy: 是否私密True/False
        :param allow_tag_ids: 允许谁看（标签id）
        :param disable_tag_ids: 不给谁看（标签id）
        :param token: token值
        :return:
        """
        payload = {
            "allowWxIds": allow_ids,
            "atWxIds": at_ids,
            "disableWxIds": disable_ids,
            "content": content,
            "imgInfos": [
                {
                    "fileUrl": file_url,
                    "thumbUrl": thumb_url,
                    "fileMd5": file_md5,
                    "length": length,
                    "width": width,
                    "height": height
                }
            ],
            "privacy": privacy,
            "allowTagIds": allow_tag_ids,
            "disableTagIds": disable_tag_ids
        }
        return self.client.request("POST", "/sendImgSns", token, json=payload)

    def sns_upload_image(self, urls: list, token):
        """
        上传朋友圈图片!

        :param urls: 图片链接列表(数量限制1-9张图)
        :param token: token值
        :return
        """
        payload = {
            "imgUrls": urls
        }
        return self.client.request("POST", "/uploadSnsImage", token, json=payload)

    def sns_send_video(self, allow_ids: list, at_ids: list, disable_ids: list, content: str, file_url: str, thumb_url: str, file_md5: str, length: int, privacy: bool, allow_tag_ids: list, disable_tag_ids: list, token):
        """
        发送视频朋友圈!（上号1-3天后允许使用）
        PS:通过上传朋友圈视频接口获取！

        :param allow_ids: 允许谁看
        :param at_ids: 提醒谁看
        :param disable_ids: 不给谁看
        :param content: 朋友圈文字内容
        :param file_url: 视频URL地址
        :param thumb_url: 缩略图URL地址
        :param file_md5: MD5
        :param length: 视频大小
        :param privacy: 是否私密True/False
        :param allow_tag_ids: 允许谁看（标签id）
        :param disable_tag_ids: 不给谁看（标签id）
        :param token: token值
        :return
        """
        payload = {
            "allowWxIds": allow_ids,
            "atWxIds": at_ids,
            "disableWxIds": disable_ids,
            "content": content,
            "videoInfo": {
                "fileUrl": file_url,
                "thumbUrl": thumb_url,
                "fileMd5": file_md5,
                "length": length
            },
            "privacy": privacy,
            "allowTagIds": allow_tag_ids,
            "disableTagIds": disable_tag_ids
        }
        return self.client.request("POST", "/sendVideoSns", token, json=payload)

    def sns_upload_video(self, thumb_url: str, video_url: str, token):
        """
        上传朋友圈视频!

        :param thumb_url: 视频封面图片链接
        :param video_url: 视频文件链接
        :param token: token值
        :return
        """
        payload = {
            "thumbUrl": thumb_url,
            "videoUrl": video_url
        }
        return self.client.request("POST", "/uploadSnsVideo", token, json=payload)

    def sns_send_url(self, allow_ids: list, at_ids: list, disable_ids: list, content: str, description: str, title: str, link_url: str, thumb_url: str, privacy: bool, allow_tag_ids: list, disable_tag_ids: list, token):
        """
        发送链接朋友圈!（上号1-3天后允许使用）

        :param allow_ids: 允许谁看
        :param at_ids: 提醒谁看
        :param disable_ids: 不给谁看
        :param content: 朋友圈文字内容
        :param description: 链接描述
        :param title: 链接标题
        :param link_url: 链接地址
        :param thumb_url: 链接缩略图
        :param privacy: 是否私密True/False
        :param allow_tag_ids: 允许谁看（标签id）
        :param disable_tag_ids: 不给谁看（标签id）
        :param token: token值
        :return
        """
        payload = {
            "allowWxIds": allow_ids,
            "atWxIds": at_ids,
            "disableWxIds": disable_ids,
            "content": content,
            "description": description,
            "title": title,
            "linkUrl": link_url,
            "thumbUrl": thumb_url,
            "privacy": privacy,
            "allowTagIds": allow_tag_ids,
            "disableTagIds": disable_tag_ids
        }
        return self.client.request("POST", "/sendUrlSns", token, json=payload)

    def sns_forward(self, allow_ids: list, at_ids: list, disable_ids: list, sns_xml: str, privacy: bool, allow_tag_ids: list, disable_tag_ids: list, token):
        """
        转发朋友圈（上号1-3天后允许使用）
        :param allow_ids: 允许谁看
        :param at_ids: 提醒谁看
        :param disable_ids: 不给谁看
        :param sns_xml: 朋友圈XML
        :param privacy: 是否私密True/False
        :param allow_tag_ids: 允许谁看（标签id）
        :param disable_tag_ids: 不给谁看（标签id）
        :param token: token值
        :return
        """
        payload = {
            "allowWxIds": allow_ids,
            "atWxIds": at_ids,
            "disableWxIds": disable_ids,
            "snsXml": sns_xml,
            "privacy": privacy,
            "allowTagIds": allow_tag_ids,
            "disableTagIds": disable_tag_ids
        }
        return self.client.request("POST", "/forwardSns", token, json=payload)

    def friends_sns_list(self, max_id: int, decrypt: bool, wx_id: str, first_page_md5: str, token):
        """
        指定好友的朋友圈列表!
        :param max_id: 首次传0，第二页及以后传接口返回的maxId
        :param decrypt: 是否私密True/False
        :param wx_id: 好友微信ID
        :param first_page_md5: 首次传空，第二页及以后传接口返回的firstPageMd5
        :param token: token值
        :return
        """
        payload = {
            "maxId": max_id,
            "decrypt": decrypt,
            "wxid": wx_id,
            "firstPageMd5": first_page_md5
        }
        return self.client.request("POST", "/contactsSnsList", token, json=payload)

    def sns_details(self, sns_id: int, token):
        """
        某条朋友圈详情!
        :param sns_id: 朋友圈ID
        :param token: token值
        :return
        """
        payload = {
            "snsId": sns_id
        }
        return self.client.request("POST", "/snsDetails", token, json=payload)

    def sns_comment(self, sns_id: int, ope_type: int, wx_id: str, comment_id: int, content: str, token):
        """
        评论/删除评论!（上号1-3天后允许使用）
        :param sns_id: 朋友圈ID
        :param ope_type: 1评论 2删除评论
        :param wx_id: 评论的好友微信ID
        :param comment_id: 回复某条评论或删除某条评论
        :param content: 评论内容
        :param token: token值
        :return
        """
        payload = {
            "snsId": sns_id,
            "operType": ope_type,
            "wxid": wx_id,
            "commentId": comment_id,
            "content": content
        }
        return self.client.request("POST", "/commentSns", token, json=payload)









