
class DownModule:
    def __init__(self, client):
        self.client = client

    def down_load_silk_base64(self, img_buf_base64: str, save_path: str):
        """
        下载语音文件！
        :param img_buf_base64: 语音消息回调中获取
        :param save_path: SILK保存路径
        :return
        """
        import base64
        audio_data = base64.b64decode(img_buf_base64)
        with open(save_path, 'wb') as f:
            f.write(audio_data)
        return True

    def down_load_silk_request(self, msg_id: str, xml: str, token):
        """
        下载语音文件！
        :param msg_id: 回调消息中的MsgId
        :param xml: 回调消息中的XML
        :param token: token值
        :return:
        """
        payload = {
            "msgId": msg_id,
            "xml": xml
        }
        return self.client.request("POST", "/downloadVoice", token, json=payload)

    def down_load_files(self, xml: str, token):
        """
        下载文件!
        :param xml: 回调消息中的XML
        :param token: token值
        :return:
        """
        payload = {
            "xml": xml
        }
        return self.client.request("POST", "/downloadFile", token, json=payload)

    def down_load_images(self, img_type: int, xml: str, token):
        """
        下载图片!
        :param img_type: 下载的图片类型 1:高清图片 2:常规图片 3:缩略图
        :param xml: 回调消息中的XML
        :param token: token值
        :return:
        """
        payload = {
            "type": img_type,
            "xml": xml
        }
        return self.client.request("POST", "/downloadImage", token, json=payload)

    def down_load_audio(self, xml: str, token):
        """
        下载视频!
        :param xml: 回调中的XML
        :param token: token值
        :return:
        """
        payload = {
            "xml": xml
        }
        return self.client.request("POST", "/downloadVideo", token, json=payload)

    def down_load_emoji(self, emoji_md5: str, token):
        """
        下载EMOJI!
        :param emoji_md5: emoji图片的md5
        :param token: token值
        :return:
        """
        payload = {
            "emojiMd5": emoji_md5
        }
        return self.client.request("POST", "/downloadEmoji", token, json=payload)

    def down_load_cdn(self, aes_key: str, total_size: str, file_type: str, file_id: str, suffix: str, token):
        """
        CDN下载!
        :param aes_key: cdn的aeskey
        :param total_size: 文件大小
        :param file_type: 下载的文件类型 1：高清图片 2：常规图片 3：缩略图 4：视频 5：文件
        :param file_id: cdn的fileid
        :param suffix: 下载类型为文件时，传文件的后缀（例：doc）
        :return:
        """
        payload = {
            "aesKey": aes_key,
            "totalSize": total_size,
            "type": file_type,
            "fileId": file_id,
            "suffix": suffix
        }
        return self.client.request("POST", "/downloadCdn", token, json=payload)


