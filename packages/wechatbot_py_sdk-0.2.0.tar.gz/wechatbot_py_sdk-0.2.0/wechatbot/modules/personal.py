
class PersonalModule:
    def __init__(self, client):
        self.client = client

    def get_info(self, token):
        """
        获取个人资料!
        :param token: token值
        :return
        """
        payload = {}
        return self.client.request("POST", "/getPersonalInfo", token, json=payload)

    def get_qrcode(self, token):
        """
        获取自己的二维码!
        :param token: token值
        :return:
        """
        payload = {}
        return self.client.request("POST", "/getQrCode", token, json=payload)

    def get_device_record(self, token):
        """
        获取使用设备记录!
        :param token: token值
        :return:
        """
        payload = {}
        return self.client.request("POST", "/getSafetyInfo", token, json=payload)

    def privacy_settings(self, boolean_style: bool, option: int, token):
        """
        隐私设置
        :param boolean_style:开关（布尔值）
        :param option: option说明
                    4: 加我为朋友时需要验证
                    7: 向我推荐通讯录朋友
                    8: 添加我的方式 手机号
                    25: 添加我的方式 微信号
                    38: 添加我的方式 群聊
                    39: 添加我的方式 我的二维码
                    40: 添加我的方式 名片
        :param token:
        :return:
        """
        payload = {
            "open": boolean_style,
            "option": option
        }
        return self.client.request("POST", "/privacySettings", token, json=payload)

    def update_info(self, city: str, country: str, nickname: str, province: str, sex: int, signature: str, token):
        """
        :param city: 城市
        :param country: 国家
        :param nickname: 昵称
        :param province: 省份
        :param sex: 性别  1:男 2:女 （int类型）
        :param signature: 个性签名
        :param token: token值
        :return:
        """
        payload = {
            "city": city,
            "country": country,
            "nickName": nickname,
            "province": province,
            "sex": sex,
            "signature": signature
        }
        return self.client.request("POST", "/updatePersonalInfo", token, json=payload)

    def update_head_img(self, img_url: str, token):
        """
        修改头像（修改头像后需要将手机的微信进程关掉，然后重启查看最新头像）
        :param img_url: 头像的图片地址（对象存储）
        :param token: token值
        :return:
        """
        payload = {
            "headImgUrl": img_url
        }
        return self.client.request("POST", "/updateHeadImg", token, json=payload)
