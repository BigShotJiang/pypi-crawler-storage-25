
class AuthModule:
    def __init__(self, client):
        self.client = client

    def get_qrcode(self, device_type: str = "", aid: str = "", token: str = ""):
        """获取登录二维码"""
        payload = {
            "type": device_type,
            "aid": aid
            }
        response = self.client.request("POST", "/getLoginQrCode", token, json=payload)
        if response.get("msg", "") == "token已过期！已自动强制下线，请重新获取":
            return {'ret': 404, 'msg': '请打开官网：www.wechatbot.online获取token或检查token是否过期！', 'data': None}
        return response

    def refresh_status(self, uuid: str = "",  token: str = "", cap_code: str = ""):
        """刷新并判断登录状态"""
        payload = {
            "uuid": uuid,
            "auto_sliding": "false",
            "cap_code": cap_code
        }
        return self.client.request("POST", "/refreshStatus", token, json=payload)

    def dialog_login(self, token):
        """已登录过的微信二次弹窗登录"""
        payload = {}
        return self.client.request("POST", "/dialogLogin", token, json=payload)

    def reconnection(self, token):
        """断线重连"""
        payload = {}
        return self.client.request("POST", "/reconnection", token, json=payload)

    def logout(self, token):
        """退出登录"""
        payload = {}
        return self.client.request("POST", "/logout", token, json=payload)

    def check_status(self, token):
        """检查微信是否在线"""
        payload = {}
        return self.client.request("POST", "/checkOnline", token, json=payload)
