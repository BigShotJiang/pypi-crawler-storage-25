
class GroupModule:
    def __init__(self, client):
        self.client = client

    def create_group(self, ids_list: list, token):
        """
        创建群聊！
        :param ids_list: 需要拉群的微信ID列表
        :param token: token值
        :return
        """
        payload = {
            "wxids": ids_list
        }
        return self.client.request("POST", "/createGroup", token, json=payload)

    def modify_group_name(self, room_name: str, room_id: str, token):
        """
        修改群名！
        :param room_name: 群名
        :param room_id: 群ID
        :param token: token值
        :return
        """
        payload = {
            "chatroomName": room_name,
            "chatroomId": room_id
        }
        return self.client.request("POST", "/modifyGroupName", token, json=payload)

    def modify_group_remark(self, room_remark: str, room_id: str, token):
        """
        修改群备注！
        :param room_remark: 群备注
        :param room_id: 群ID
        :param token: token值
        :return:
        """
        payload = {
            "chatroomRemark": room_remark,
            "chatroomId": room_id
        }
        return self.client.request("POST", "/modifyGroupRemark", token, json=payload)

    def modify_self_nickname_in_group(self, nickname: str, room_id: str, token):
        """
        修改我在群内的昵称!
        :param nickname: 微信昵称
        :param room_id: 群ID
        :param token: token值
        :return
        """
        payload = {
            "nickName": nickname,
            "chatroomId": room_id,
        }
        return self.client.request("POST", "/modifyGroupNickNameForSelf", token, json=payload)

    def invite_group_member(self, ids: str, room_id: str, reason: str, token):
        """
        邀请/添加 进群
        :param ids: 邀请进群的好友微信id,多个微信ID用逗号隔开
        :param room_id: 群ID
        :param reason: 邀请进群的说明
        :param token: token值
        :return:
        """
        payload = {
            "wxids": ids,
            "chatroomId": room_id,
            "reason": reason
        }
        return self.client.request("POST", "/inviteMember", token, json=payload)

    def remove_group(self, ids: str, room_id: str, token):
        """
        移出/请出 群聊
        :param ids: 移出群聊的好友微信id,多个微信ID用逗号隔开
        :param room_id: 群ID
        :param token: token值
        :return:
        """
        payload = {
            "wxids": ids,
            "chatroomId": room_id
        }
        return self.client.request("POST", "/removeMember", token, json=payload)

    def quit_group(self, room_id: str, token):
        """
        退出群聊
        :param room_id: 群ID
        :param token: token值
        :return
        """
        payload = {
            "chatroomId": room_id
        }
        return self.client.request("POST", "/quitGroup", token, json=payload)

    def disband_group(self, room_id: str, token):
        """
        解散群聊！
        :param room_id: 群ID
        :param token: token值
        :return:
        """
        payload = {
            "chatroomId": room_id
        }
        return self.client.request("POST", "/disbandGroup", token, json=payload)

    def group_info(self, room_id: str, token):
        """
        获取群信息!
        :param room_id: 群ID
        :param token: token值
        :return
        """
        payload = {
            "chatroomId": room_id
        }
        return self.client.request("POST", "/getGroupInfo", token, json=payload)

    def group_member(self, room_id: str, token):
        """
        获取群成员列表!
        :param room_id: 群ID
        :param token: token值
        :return
        """
        payload = {
            "chatroomId": room_id
        }
        return self.client.request("POST", "/getGroupMemberList", token, json=payload)

    def group_member_detail(self, room_id: str, member_list: list, token):
        """
        获取群成员详情!
        :param room_id: 群ID
        :param member_list: 需要查询成员微信ID（列表）
        :param token:
        :return:
        """
        payload = {
            "chatroomId": room_id,
            "memberWxids": member_list
        }
        return self.client.request("POST", "/getGroupMemberDetail", token, json=payload)

    def get_announcement(self, room_id: str, token):
        """
        获取群公告
        :param room_id: 群ID
        :param token: token值
        :return:
        """
        payload = {
            "chatroomId": room_id
        }
        return self.client.request("POST", "/getGroupAnnouncement", token, json=payload)

    def set_announcement(self, room_id: str, announcement: str, token):
        """
        设置群公告
        :param room_id: 群ID
        :param announcement: 群公告内容
        :param token: token值
        :return
        """
        payload = {
            "chatroomId": room_id,
            "content": announcement
        }
        return self.client.request("POST", "/setGroupAnnouncement", token, json=payload)

    def agree_join_group(self, url: str, token):
        """
        同意进群
        :param url: 申请入群的回调消息中的URL
        :param token: token值
        :return:
        """
        payload = {
            "url": url
        }
        return self.client.request("POST", "/agreeJoinGroup", token, json=payload)

    def add_group_member_as_friend(self, room_id: str, content: str, member_wxid: str, token):
        """
        添加群成员为好友！
        :param room_id 群ID
        :param content 加好友的招呼语
        :param member_wxid 成员微信ID
        :param token: token值
        :return
        """
        payload = {
            "chatroomId": room_id,
            "content": content,
            "memberWxid": member_wxid
        }
        return self.client.request("POST", "/addGroupMemberAsFriend", token, json=payload)

    def get_group_qr(self, room_id: str, token):
        """
        获取群二维码！
        :param room_id: 群ID
        :param token: token值
        :return:
        """
        payload = {
            "chatroomId": room_id
        }
        return self.client.request("POST", "/getGroupQrCode", token, json=payload)

    def save_contract_list(self, room_id: str, opertype: int, token):
        """
        群保存到通讯录!
        :param room_id: 群ID
        :param opertype: 操作类型: 3为保存到通讯录 2为从通讯录移除
        :param token: token值
        :return:
        """
        payload = {
            "chatroomId": room_id,
            "operType": opertype
        }
        return self.client.request("POST", "/saveContractList", token, json=payload)

    def admin_operate(self, room_id: str, opertype: int, ids_list: list, token):
        """
        管理员操作!
        :param room_id: 群ID
        :param opertype: 操作类型 1：添加群管理（可添加多个微信号） 2：删除群管理（可删除多个） 3：转让（只能转让一个微信号）
        :param ids_list: 微信ID（列表）
        :param token: token值
        """
        payload = {
            "chatroomId": room_id,
            "operType": opertype,
            "wxids": ids_list
        }
        return self.client.request("POST", "/adminOperate", token, json=payload)

    def pinned_chat(self, room_id: str, bool_type: bool, token):
        """
        聊天置顶!
        :param room_id: 群ID
        :param bool_type: True顶置 False取消
        :param token: token值
        :return
        """
        payload = {
             "chatroomId": room_id,
             "top": bool_type
        }
        return self.client.request("POST", "/pinnedChat", token, json=payload)

    def set_msg_silence(self, room_id: str, bool_type: bool, token):
        """
        设置消息免打扰!
        :param room_id: 群ID
        :param bool_type: True免打扰 False通知
        :param token: token值
        """
        payload = {
            "chatroomId": room_id,
            "silence": bool_type
        }
        return self.client.request("POST", "/setMsgSilence", token, json=payload)

    def us_qr_join_group(self, qr_url: str, token):
        """
        扫码进群!
        :param qr_url: 二维码链接
        :param token: token值
        :return
        """
        payload = {
            "qrUrl": qr_url
        }
        return self.client.request("POST", "/joinGroupUsingQRCode", token, json=payload)

    def apply_group_approve(self, room_id: str, content: str, msg_id: str, token):
        """
        确认进群申请！
        :param room_id: 群ID
        :param content: 消息内容
        :param msg_id: 消息ID
        :param token: token值
        :return:
        """
        payload = {
            "chatroomId": room_id,
            "msgContent": content,
            "newMsgId": msg_id
        }
        return self.client.request("POST", "/groupAccessApplyCheckApprove", token, json=payload)


