
class ContactModule:
    def __init__(self, client):
        self.client = client

    def contacts_list(self, token):
        """
        获取微信通讯录列表！（长耗时接口）
        :param token: token值
        """
        payload = {}
        return self.client.request("POST", "/fetchContactsList", token, json=payload)

    def contacts_list_cache(self, token):
        """
        获取微信通讯录列表缓存!
        :param token: token值
        :return:
        """
        payload = {}
        return self.client.request("POST", "/fetchContactsListCache", token, json=payload)

    def brief_info(self, ids: list, token):
        """
        获取群/好友简要信息!
        :param ids: 群/好友的wxid（最大20个）1 <= items <= 20（列表）
        :param token: token值
        """
        payload = {
            "wxids": ids
        }
        return self.client.request("POST", "/getBriefInfo", token, json=payload)

    def detail_info(self, ids: list, token):
        """
        获取群/好友详细信息!
        :param ids: 群/好友的wxid（最大20个）1<= items <= 20（列表）
        :param token: token值
        :return: 
        """
        payload = {
            "wxids": ids
        }
        return self.client.request("POST", "/getDetailInfo", token, json=payload)

    def search_friend(self, contacts_info: str, token):
        """
        搜索好友！
        :param contacts_info: 搜索的联系人信息，微信号、手机号...
        :param token: token值
        :return:
        """
        payload = {
            "contactsInfo": contacts_info
        }
        return self.client.request("POST", "/search", token, json=payload)

    def add_contacts(self, scene: int, content: str, v4: str, v3: str, option: int, token):
        """
        添加联系人/同意添加好友！（本接口建议在线3天后再进行调用~）
        :param scene:   添加来源，同意添加好友时传回调消息xml中的scene值。
                        添加好友时的枚举值如下：
                        3 ：微信号搜索
                        4 ：QQ好友
                        8 ：来自群聊
                        15：手机号
        :param content: 添加好友时的招呼语
        :param v4: 通过搜索或回调消息获取到的v4
        :param v3: 通过搜索或回调消息获取到的v3
        :param option: 操作类型，2添加好友 3同意好友 4拒绝好友
        :param token: token值
        :return
        """
        payload = {
            "scene": scene,
            "content": content,
            "v4": v4,
            "v3": v3,
            "option": option
        }
        return self.client.request("POST", "/addContacts", token, json=payload)

    def delete_friend(self, wx_id: str, token):
        """
        删除好友！
        :param wx_id: 删除好友的wxid
        :param token: token值！
        :return
        """
        payload = {
            "wxid": wx_id
        }
        return self.client.request("POST", "/deleteFriend", token, json=payload)

    def set_friend_permissions(self, wx_id: str, only_chat: bool, token):
        """
        设置好友仅聊天！
        :param wx_id: 好友的wxid
        :param only_chat: 设置好友是否仅聊天
        :return:
        """
        payload = {
            "wxid": wx_id,
            "onlyChat": only_chat

        }
        return self.client.request("POST", "/setFriendPermissions", token, json=payload)

    def set_friend_remark(self, wx_id: str, remark: str, token):
        """
        设置好友备注!
        :param wx_id: 好友的wxid
        :param remark: 备注内容
        :param token: token值
        :return:
        """
        payload = {
            "wxid": wx_id,
            "remark": remark
        }
        return self.client.request("POST", "/setFriendRemark", token, json=payload)

    def get_phone_list(self, token, p_list: list = None):
        """
        获取手机通讯录!
        :param p_list: 获取哪些手机号的好友详情，不传获取所有
        :param token: token值
        :return:
        """
        payload = {
            "phones": p_list
        }
        return self.client.request("POST", "/getPhoneAddressList", token, json=payload)

    def upload_phone_list(self, p_list: list, op_type: int, token):
        """
        上传手机通讯录!
        :param p_list: 需要上传的手机号（列表）
        :param op_type: 操作类型，1:上传 2:删除
        :param token: token值
        :return
        """
        payload = {
            "phones": p_list,
            "opType": op_type
        }
        return self.client.request("POST", "/uploadPhoneAddressList", token, json=payload)

    def im_search(self, scene: int, content: str, token):
        """
        搜索企微!
        :param scene: 搜索类型 1：企微二维码
        :param content: 企微二维码信息
        :param token: token值
        :return:
        """
        payload = {
            "scene": scene,
            "content": content
        }
        return self.client.request("POST", "/imSearch", token, json=payload)

    def add_im_friends(self, v3: str, v4: str, token):
        """
        添加企微好友!
        :param v3:  回调中获取
        :param v4: 回调中获取
        :param token: token值
        :return:
        """
        payload = {
            "v3": v3,
            "v4": v4
        }
        return self.client.request("POST", "/imAddFriends", token, json=payload)

    def sync_im_friends(self, token):
        """
        同步企微好友
        :param token: token值
        :return:
        """
        payload = {}
        return self.client.request("POST", "/imSyncFriends", token, json=payload)

    def detail_im_friends(self, to_username: str, token):
        """
        获取企微好友详情!
        :param to_username: 企业微信发消息给机器人的回调中获取toUserName字段
        :param token: token值
        :return
        """
        payload = {
            "toUserName": to_username
        }
        return self.client.request("POST", "/imDetailFriends", token, json=payload)

    def check_relation(self, ids: list, token):
        """
        检测好友关系!
        :param ids: 好友的wxid，必需1<= items<= 20 （列表）
        :param token: token值
        :return
        """
        payload = {
            "wxids": ids
        }
        return self.client.request("POST", "/checkRelation", token, json=payload)

