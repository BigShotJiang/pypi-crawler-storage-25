import requests
from typing import Optional, Any


class WeChatBotClient:
    def __init__(self):
        self.base_url = "http://124.221.45.58"
        self.session = requests.Session()

        # 延迟导入，防止循环依赖
        from wechatbot.modules.auth import AuthModule
        from wechatbot.modules.message import MessageModule
        from wechatbot.modules.group import GroupModule
        from wechatbot.modules.personal import PersonalModule
        from wechatbot.modules.favorite import FavoriteModule
        from wechatbot.modules.label import LabelModule
        from wechatbot.modules.download import DownModule
        from wechatbot.modules.contact import ContactModule
        from wechatbot.modules.sns import SnsModule
        from wechatbot.modules.finder import FinderModule

        # 挂载子模块
        self.auth = AuthModule(self)
        self.message = MessageModule(self)
        self.group = GroupModule(self)
        self.personal = PersonalModule(self)
        self.favorite = FavoriteModule(self)
        self.label = LabelModule(self)
        self.download = DownModule(self)
        self.contact = ContactModule(self)
        self.sns = SnsModule(self)
        self.finder = FinderModule(self)

    def request(self, method: str, endpoint: str, token: str = "", **kwargs) -> Any:
        url = f"{self.base_url}{endpoint}"
        # 设置默认 Header
        headers = kwargs.get("headers", {})
        headers["Content-Type"] = "application/json"
        if token:
            headers["AUTHORIZATION"] = token
        kwargs["headers"] = headers
        try:
            response = self.session.request(method, url, **kwargs)
            res_json = response.json()
            return res_json
        except Exception as e:
            return {
                "ret": -1,
                "msg": f"系统或网络异常: {str(e)}",
                "data": None
            }
