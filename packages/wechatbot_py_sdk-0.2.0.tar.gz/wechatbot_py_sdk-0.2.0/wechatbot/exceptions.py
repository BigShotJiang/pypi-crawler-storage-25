class WeChatAPIError(Exception):
    """API 返回错误时抛出的异常"""
    def __init__(self, ret, msg):
        self.ret = ret
        self.msg = msg
        super().__init__(f"Error {ret}: {msg}")

class NetworkError(Exception):
    """网络请求故障"""
    pass
