from setuptools import setup, find_packages

setup(
    name="wechatbot-py-sdk",
    version="0.2.0",
    author="花骨朵轻创",
    description="基于微信机器人 API 封装的 Python SDK",
    long_description=open("README.md", encoding="utf-8").read(),
    long_description_content_type="text/markdown",
    packages=find_packages(),
    install_requires=[
        "requests>=2.25.1",
    ],
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
    ],
    python_requires='>=3.6',
)
