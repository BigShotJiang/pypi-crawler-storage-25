from ..models import (
    CodingTaskCreating,
    CodingTaskDeleting,
    CodingTaskDetail,
    CodingTaskReading,
    CodingTaskSummary,
    CodingTaskUpdating,
)
from .base import ModelClient


class CodingTask(
    ModelClient[
        CodingTaskCreating,
        CodingTaskReading,
        CodingTaskUpdating,
        CodingTaskDeleting,
        CodingTaskSummary,
        CodingTaskDetail,
    ]
):
    Creating = CodingTaskCreating
    Reading = CodingTaskReading
    Updating = CodingTaskUpdating
    Deleting = CodingTaskDeleting
    Summary = CodingTaskSummary
    Detail = CodingTaskDetail
