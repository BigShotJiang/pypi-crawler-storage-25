"""
Domain metadata subpackage.
"""

