hcs-cli core component.
