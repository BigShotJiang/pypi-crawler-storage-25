"""
Copyright © 2025-2026 Omnissa, LLC.
"""

from abc import ABC, abstractmethod
from typing import Callable

from .actions import actions


class BaseProvider(ABC):
    def __init__(self, data: dict, state: dict, fn_save_state: Callable):
        self.data = data
        self.state = state
        self._save_state = fn_save_state

    def save(self, data: dict):
        self._save_state(data)

    def decide(self) -> str:
        return actions.create

    @abstractmethod
    def refresh(self) -> dict:
        pass

    @abstractmethod
    def create(self) -> dict:
        pass

    @abstractmethod
    def delete(self) -> dict:
        pass

    def eta_create(self):
        return "1m"

    def eta_delete(self):
        return "1m"
