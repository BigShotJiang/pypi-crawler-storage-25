"""
Copyright © 2025-2026 Omnissa, LLC.
"""

from typing import Any, Optional


def process(data: dict, state: dict) -> Any:
    n = data["n"]
    return _fibonacci(n)


def _fibonacci(n: int) -> int:
    if n <= 0:
        raise ValueError("n must be a positive integer.")
    if n == 1:
        return 0
    if n == 2:
        return 1

    prev, curr = 0, 1
    for _ in range(3, n + 1):
        prev, curr = curr, prev + curr
    return curr


def destroy(data: dict, state: dict, force: bool) -> Optional[dict]:
    return None


def eta(action: str, data: dict, state: dict) -> str:
    return "10s"
