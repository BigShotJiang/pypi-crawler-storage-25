"""
Copyright © 2025-2026 Omnissa, LLC.
"""

from .fstore import fstore
from .jsondot import dotdict

_store_impl: fstore = None


def init(config_path: str) -> None:
    global _store_impl
    _store_impl = fstore(config_path)


def get(name: str, reload: bool = False) -> dotdict:
    return _store_impl.get(name, reload)


def list() -> list:
    return _store_impl.keys()
