"""
Copyright © 2025-2026 Omnissa, LLC.
"""

import os
import pathlib
from typing import Any

from . import jsondot


class _StateFile:
    def __init__(self, file_path: str):
        self._path = file_path
        self._cache = None
        pathlib.Path(os.path.dirname(file_path)).mkdir(parents=True, exist_ok=True)

    def _data(self, reload: bool = False):
        if self._cache is None or reload:
            self._cache = jsondot.load(self._path, {}, lock=True)
        return self._cache

    def get(self, key: str, default: Any = None, reload: bool = False):
        return self._data(reload).get(key, default)

    def set(self, key: str, value: Any):
        self._data()[key] = value
        jsondot.save(self._cache, self._path, lock=True)


_file: _StateFile = None


def init(store_path: str, name: str):
    global _file
    _file = _StateFile(os.path.join(store_path, name))


def get(key: str, default: Any = None, reload: bool = False):
    return _file.get(key=key, default=default, reload=reload)


def set(key: str, value: Any):
    _file.set(key, value)
