"""
Copyright © 2025-2026 Omnissa, LLC.
"""

from . import auth as auth
from .ez_client import EzClient


def hcs_client(url: str, custom_auth: dict = None) -> EzClient:
    return EzClient(base_url=url, oauth_client=auth.oauth_client(custom_auth))
