"""
Copyright © 2025-2026 Omnissa, LLC.
"""

import threading

_flag = threading.Event()


def sleep(timeout):
    flag_set = _flag.wait(timeout)
    if flag_set:
        raise InterruptedError()


def is_set() -> bool:
    return _flag.is_set()


def set() -> None:
    _flag.set()
