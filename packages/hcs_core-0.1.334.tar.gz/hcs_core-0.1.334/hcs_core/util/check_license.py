"""
Copyright © 2025-2026 Omnissa, LLC.
"""

import os
import sys

license_header = """'''
Copyright 2025-2026 Omnissa, LLC.
'''
""".splitlines()

_hint = sum(len(s) for s in license_header) + 7
_fix = len(sys.argv) == 2 and sys.argv[1] == "--fix"


def _process_file(file_path):
    compliant, fixable = _check_file_license(file_path)
    if compliant:
        return

    if not _fix or not fixable:
        print("ERROR", file_path)
        sys.exit(1)

    print("Updating file", file_path)
    with open(file_path, "r+") as f:
        content = f.read()
        f.seek(0, 0)
        for line in license_header:
            f.write(line + "\n")
        f.write(content)


def _check_file_license(file_path):
    with open(file_path, "r") as f:
        lines = f.readlines(_hint)
        if len(lines) == 0:
            return True, False

        fixable = lines[0][0] != "#"
        if len(lines) < len(license_header):
            return False, fixable

        for i in range(len(license_header)):
            if lines[i].strip() != license_header[i]:
                return False, fixable
    return True, False


if __name__ == "__main__":
    for root, subdirs, files in os.walk("."):
        for filename in files:
            if not filename.endswith(".py"):
                continue
            file_path = os.path.join(root, filename)
            _process_file(file_path)
