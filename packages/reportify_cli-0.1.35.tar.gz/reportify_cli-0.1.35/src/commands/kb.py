"""KB (Knowledge Base) module commands."""

from typing import Annotated

import typer

from src import params
from src.client import get_client
from src.output import format_output
from src.utils import generate_epilog, parse_json_input

app = typer.Typer(
    help="Knowledge base - Search user-uploaded private documents", rich_markup_mode="rich"
)


@app.command(
    epilog=generate_epilog(
        params.KB_SEARCH_PARAMS,
        [
            'reportify-cli kb search --input \'{"query": "investment strategy", "num": 10}\'',
            'reportify-cli kb search --input \'{"query": "quarterly report", "folder_ids": ["folder_abc123"]}\'',
        ],
    )
)
def search(
    input: Annotated[str, typer.Option(help="JSON input parameters")] = "{}",
    format: Annotated[str, typer.Option(help="Output format: json, table, csv")] = "json",
):
    """Search documents in knowledge base"""
    try:
        params_dict = parse_json_input(input)
        client = get_client()
        result = client.kb.search(**params_dict)
        format_output(result, format)
    except Exception as e:
        typer.echo(f"Error: {e}", err=True)
        raise typer.Exit(1)
