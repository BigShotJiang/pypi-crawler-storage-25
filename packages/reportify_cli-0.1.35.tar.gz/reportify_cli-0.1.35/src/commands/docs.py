"""Docs module commands."""

from typing import Annotated

import typer

from src import params
from src.client import get_client
from src.output import format_output
from src.utils import generate_epilog, parse_json_input

app = typer.Typer(help="Document management", rich_markup_mode="rich")


@app.command(
    epilog=generate_epilog(
        params.DOCS_GET_PARAMS,
        [
            'reportify-cli docs get --input \'{"doc_id": "doc_abc123"}\'',
        ],
    )
)
def get(
    input: Annotated[str, typer.Option(help="JSON input parameters")] = "{}",
    format: Annotated[str, typer.Option(help="Output format: json, table, csv")] = "json",
):
    """Get document details"""
    try:
        params_dict = parse_json_input(input)
        client = get_client()
        # docs.get() takes doc_id as positional argument
        doc_id = params_dict.get("doc_id")
        if not doc_id:
            raise ValueError("doc_id is required")
        result = client.docs.get(doc_id)
        format_output(result, format)
    except Exception as e:
        typer.echo(f"Error: {e}", err=True)
        raise typer.Exit(1)


@app.command(
    epilog=generate_epilog(
        params.DOCS_SUMMARY_PARAMS,
        [
            'reportify-cli docs summary --input \'{"doc_id": "doc_abc123"}\'',
        ],
    )
)
def summary(
    input: Annotated[str, typer.Option(help="JSON input parameters")] = "{}",
    format: Annotated[str, typer.Option(help="Output format: json, table, csv")] = "json",
):
    """Get document summary"""
    try:
        params_dict = parse_json_input(input)
        client = get_client()
        # docs.summary() takes doc_id as positional argument
        doc_id = params_dict.get("doc_id")
        if not doc_id:
            raise ValueError("doc_id is required")
        result = client.docs.summary(doc_id)
        format_output(result, format)
    except Exception as e:
        typer.echo(f"Error: {e}", err=True)
        raise typer.Exit(1)


@app.command(
    name="list_by_symbols",
    epilog=generate_epilog(
        params.DOCS_LIST_BY_SYMBOLS_PARAMS,
        [
            'reportify-cli docs list_by_symbols --input \'{"symbol": "US:AAPL", "num": 20}\'',
            'reportify-cli docs list_by_symbols --input \'{"symbol": "US:AAPL", "categories": ["news", "filings"]}\'',
        ],
    ),
)
def list_by_symbols(
    input: Annotated[str, typer.Option(help="JSON input parameters")] = "{}",
    format: Annotated[str, typer.Option(help="Output format: json, table, csv")] = "json",
):
    """List documents by stock symbol"""
    try:
        params_dict = parse_json_input(input)
        client = get_client()
        result = client.docs.list_by_symbols(**params_dict)
        format_output(result, format)
    except Exception as e:
        typer.echo(f"Error: {e}", err=True)
        raise typer.Exit(1)


@app.command(
    name="raw_content",
    epilog=generate_epilog(
        params.DOCS_RAW_CONTENT_PARAMS,
        [
            'reportify-cli docs raw_content --input \'{"doc_id": "doc_abc123"}\'',
        ],
    ),
)
def raw_content(
    input: Annotated[str, typer.Option(help="JSON input parameters")] = "{}",
    format: Annotated[str, typer.Option(help="Output format: json, table, csv")] = "json",
):
    """Get document raw content"""
    try:
        params_dict = parse_json_input(input)
        client = get_client()
        doc_id = params_dict.get("doc_id")
        if not doc_id:
            raise ValueError("doc_id is required")
        result = client.docs.raw_content(doc_id)
        format_output(result, format)
    except Exception as e:
        typer.echo(f"Error: {e}", err=True)
        raise typer.Exit(1)


@app.command(
    name="list",
    epilog=generate_epilog(
        params.DOCS_LIST_PARAMS,
        [
            'reportify-cli docs list --input \'{"symbols": ["US:AAPL"], "page_size": 10}\'',
            'reportify-cli docs list --input \'{"categories": ["news", "reports"], "page_num": 1}\'',
        ],
    ),
)
def list_docs(
    input: Annotated[str, typer.Option(help="JSON input parameters")] = "{}",
    format: Annotated[str, typer.Option(help="Output format: json, table, csv")] = "json",
):
    """List documents with filters"""
    try:
        params_dict = parse_json_input(input)
        client = get_client()
        result = client.docs.list(**params_dict)
        format_output(result, format)
    except Exception as e:
        typer.echo(f"Error: {e}", err=True)
        raise typer.Exit(1)


@app.command(
    name="search",
    epilog=generate_epilog(
        params.DOCS_SEARCH_PARAMS,
        [
            'reportify-cli docs search --input \'{"query": "earnings", "num": 10}\'',
            'reportify-cli docs search --input \'{"symbols": ["US:AAPL"], "categories": ["reports"]}\'',
        ],
    ),
)
def search(
    input: Annotated[str, typer.Option(help="JSON input parameters")] = "{}",
    format: Annotated[str, typer.Option(help="Output format: json, table, csv")] = "json",
):
    """Search documents (v1)"""
    try:
        params_dict = parse_json_input(input)
        client = get_client()
        result = client.docs.search(**params_dict)
        format_output(result, format)
    except Exception as e:
        typer.echo(f"Error: {e}", err=True)
        raise typer.Exit(1)


@app.command(
    name="search_chunks",
    epilog=generate_epilog(
        params.DOCS_SEARCH_CHUNKS_PARAMS,
        [
            'reportify-cli docs search_chunks --input \'{"query": "revenue growth", "num": 10}\'',
            'reportify-cli docs search_chunks --input \'{"query": "AI strategy", "symbols": ["US:MSFT"]}\'',
        ],
    ),
)
def search_chunks(
    input: Annotated[str, typer.Option(help="JSON input parameters")] = "{}",
    format: Annotated[str, typer.Option(help="Output format: json, table, csv")] = "json",
):
    """Search document chunks"""
    try:
        params_dict = parse_json_input(input)
        client = get_client()
        result = client.docs.search_chunks(**params_dict)
        format_output(result, format)
    except Exception as e:
        typer.echo(f"Error: {e}", err=True)
        raise typer.Exit(1)


@app.command(
    name="create_folder",
    epilog=generate_epilog(
        params.DOCS_CREATE_FOLDER_PARAMS,
        [
            'reportify-cli docs create_folder --input \'{"name": "My Research"}\'',
        ],
    ),
)
def create_folder(
    input: Annotated[str, typer.Option(help="JSON input parameters")] = "{}",
    format: Annotated[str, typer.Option(help="Output format: json, table, csv")] = "json",
):
    """Create folder"""
    try:
        params_dict = parse_json_input(input)
        client = get_client()
        name = params_dict.get("name")
        if not name:
            raise ValueError("name is required")
        result = client.docs.create_folder(name)
        format_output(result, format)
    except Exception as e:
        typer.echo(f"Error: {e}", err=True)
        raise typer.Exit(1)


@app.command(
    name="delete_folder",
    epilog=generate_epilog(
        params.DOCS_DELETE_FOLDER_PARAMS,
        [
            'reportify-cli docs delete_folder --input \'{"folder_id": "folder_123"}\'',
        ],
    ),
)
def delete_folder(
    input: Annotated[str, typer.Option(help="JSON input parameters")] = "{}",
    format: Annotated[str, typer.Option(help="Output format: json, table, csv")] = "json",
):
    """Delete folder and all its files"""
    try:
        params_dict = parse_json_input(input)
        client = get_client()
        folder_id = params_dict.get("folder_id")
        if not folder_id:
            raise ValueError("folder_id is required")
        result = client.docs.delete_folder(folder_id)
        format_output(result, format)
    except Exception as e:
        typer.echo(f"Error: {e}", err=True)
        raise typer.Exit(1)


@app.command(
    name="upload",
    epilog=generate_epilog(
        params.DOCS_UPLOAD_PARAMS,
        [
            'reportify-cli docs upload --input \'{"docs": [{"url": "https://example.com/doc.pdf", "name": "My Doc"}]}\'',
        ],
    ),
)
def upload(
    input: Annotated[str, typer.Option(help="JSON input parameters")] = "{}",
    format: Annotated[str, typer.Option(help="Output format: json, table, csv")] = "json",
):
    """Upload documents"""
    try:
        params_dict = parse_json_input(input)
        client = get_client()
        result = client.docs.upload(**params_dict)
        format_output(result, format)
    except Exception as e:
        typer.echo(f"Error: {e}", err=True)
        raise typer.Exit(1)


@app.command(
    name="upload_async",
    epilog=generate_epilog(
        params.DOCS_UPLOAD_ASYNC_PARAMS,
        [
            'reportify-cli docs upload_async --input \'{"docs": [{"url": "https://example.com/doc.pdf", "name": "My Doc"}]}\'',
        ],
    ),
)
def upload_async(
    input: Annotated[str, typer.Option(help="JSON input parameters")] = "{}",
    format: Annotated[str, typer.Option(help="Output format: json, table, csv")] = "json",
):
    """Upload documents asynchronously"""
    try:
        params_dict = parse_json_input(input)
        client = get_client()
        result = client.docs.upload_async(**params_dict)
        format_output(result, format)
    except Exception as e:
        typer.echo(f"Error: {e}", err=True)
        raise typer.Exit(1)


@app.command(
    name="get_upload_status",
    epilog=generate_epilog(
        params.DOCS_GET_UPLOAD_STATUS_PARAMS,
        [
            'reportify-cli docs get_upload_status --input \'{"doc_id": "doc_abc123"}\'',
        ],
    ),
)
def get_upload_status(
    input: Annotated[str, typer.Option(help="JSON input parameters")] = "{}",
    format: Annotated[str, typer.Option(help="Output format: json, table, csv")] = "json",
):
    """Get document upload status"""
    try:
        params_dict = parse_json_input(input)
        client = get_client()
        doc_id = params_dict.get("doc_id")
        if not doc_id:
            raise ValueError("doc_id is required")
        result = client.docs.get_upload_status(doc_id)
        format_output(result, format)
    except Exception as e:
        typer.echo(f"Error: {e}", err=True)
        raise typer.Exit(1)


@app.command(
    name="delete",
    epilog=generate_epilog(
        params.DOCS_DELETE_PARAMS,
        [
            'reportify-cli docs delete --input \'{"doc_ids": ["doc_123", "doc_456"]}\'',
        ],
    ),
)
def delete(
    input: Annotated[str, typer.Option(help="JSON input parameters")] = "{}",
    format: Annotated[str, typer.Option(help="Output format: json, table, csv")] = "json",
):
    """Delete documents"""
    try:
        params_dict = parse_json_input(input)
        client = get_client()
        result = client.docs.delete(**params_dict)
        format_output(result, format)
    except Exception as e:
        typer.echo(f"Error: {e}", err=True)
        raise typer.Exit(1)
