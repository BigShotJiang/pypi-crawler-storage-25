"""Timeline module commands."""

from typing import Annotated

import typer

from src import params
from src.client import get_client
from src.output import format_output
from src.utils import generate_epilog, parse_json_input

app = typer.Typer(
    help="Timeline - Get latest updates from followed content", rich_markup_mode="rich"
)


@app.command(
    epilog=generate_epilog(
        params.TIMELINE_COMPANIES_PARAMS,
        ["reportify-cli timeline companies --input '{\"num\": 20}'"],
    )
)
def companies(
    input: Annotated[str, typer.Option(help="JSON input parameters")] = "{}",
    format: Annotated[str, typer.Option(help="Output format: json, table, csv")] = "json",
):
    """Get latest updates from followed companies"""
    try:
        params_dict = parse_json_input(input)
        client = get_client()
        result = client.timeline.companies(**params_dict)
        format_output(result, format)
    except Exception as e:
        typer.echo(f"Error: {e}", err=True)
        raise typer.Exit(1)


@app.command(
    epilog=generate_epilog(
        params.TIMELINE_TOPICS_PARAMS, ["reportify-cli timeline topics --input '{\"num\": 20}'"]
    )
)
def topics(
    input: Annotated[str, typer.Option(help="JSON input parameters")] = "{}",
    format: Annotated[str, typer.Option(help="Output format: json, table, csv")] = "json",
):
    """Get latest updates from followed topics"""
    try:
        params_dict = parse_json_input(input)
        client = get_client()
        result = client.timeline.topics(**params_dict)
        format_output(result, format)
    except Exception as e:
        typer.echo(f"Error: {e}", err=True)
        raise typer.Exit(1)


@app.command(
    epilog=generate_epilog(
        params.TIMELINE_INSTITUTES_PARAMS,
        ["reportify-cli timeline institutes --input '{\"num\": 20}'"],
    )
)
def institutes(
    input: Annotated[str, typer.Option(help="JSON input parameters")] = "{}",
    format: Annotated[str, typer.Option(help="Output format: json, table, csv")] = "json",
):
    """Get latest updates from followed institutions"""
    try:
        params_dict = parse_json_input(input)
        client = get_client()
        result = client.timeline.institutes(**params_dict)
        format_output(result, format)
    except Exception as e:
        typer.echo(f"Error: {e}", err=True)
        raise typer.Exit(1)


@app.command(
    name="public_media",
    epilog=generate_epilog(
        params.TIMELINE_PUBLIC_MEDIA_PARAMS,
        ["reportify-cli timeline public_media --input '{\"num\": 20}'"],
    ),
)
def public_media(
    input: Annotated[str, typer.Option(help="JSON input parameters")] = "{}",
    format: Annotated[str, typer.Option(help="Output format: json, table, csv")] = "json",
):
    """Get latest updates from followed public media"""
    try:
        params_dict = parse_json_input(input)
        client = get_client()
        result = client.timeline.public_media(**params_dict)
        format_output(result, format)
    except Exception as e:
        typer.echo(f"Error: {e}", err=True)
        raise typer.Exit(1)


@app.command(
    name="social_media",
    epilog=generate_epilog(
        params.TIMELINE_SOCIAL_MEDIA_PARAMS,
        ["reportify-cli timeline social_media --input '{\"num\": 20}'"],
    ),
)
def social_media(
    input: Annotated[str, typer.Option(help="JSON input parameters")] = "{}",
    format: Annotated[str, typer.Option(help="Output format: json, table, csv")] = "json",
):
    """Get latest updates from followed social media"""
    try:
        params_dict = parse_json_input(input)
        client = get_client()
        result = client.timeline.social_media(**params_dict)
        format_output(result, format)
    except Exception as e:
        typer.echo(f"Error: {e}", err=True)
        raise typer.Exit(1)
