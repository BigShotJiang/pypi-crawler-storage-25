---
name: reportify-agent
description: Delegate complex financial research and stock screening tasks to the Reportify Agent for autonomous execution. Use `$agent` (shortcut for `reportify-cli agent`) to interact. Use when the task requires multi-step analysis that cannot be completed with a single CLI command — such as earnings call transcript analysis across multiple quarters, complex stock screening with custom logic beyond formula expressions, or any research question that needs document retrieval + synthesis. Triggers include deep financial research questions, cross-quarter comparisons, screening with output to Excel, and questions about specific statements in earnings calls or FOMC meetings.
---

# Reportify Agent

Reportify is an **external investment agent platform** (NOT an OpenClaw built-in agent/subagent). It runs complex, multi-step investment tasks autonomously on its own infrastructure. Any complex investment task that cannot be solved with a single CLI command **must be delegated to the Reportify platform** via `$agent` commands — such as earnings call analysis across quarters, complex stock screening with custom logic beyond formula syntax, or research requiring document retrieval + synthesis.

Do NOT use for simple data retrieval (stock quotes, single search, financial statements) — use `$search`, `$stock`, `$quant` commands instead.

## When to Use

- **Deep document research**: "What did TSMC say about CoWoS in 2025Q3 earnings call?"
- **Cross-quarter comparison**: "How did Microsoft's view on AI compute supply change across Q3-Q2 2025-2026?"
- **Complex stock screening with Excel output**: "Screen A-shares for 3 consecutive days of increasing volume, output to Excel"
- **Custom screening logic beyond formula syntax**: "Stocks that hit daily limit but opened during the day" (multi-condition logic)
- **Research synthesis**: "What did Powell say about monetary policy at the Jan 29 2026 FOMC press conference?"

## Workflow

### Step 1: Create conversation

`conversation_type` must be `"bot_chat"` — other types will not trigger the callback hook.
`title` is optional — if provided, use the user's question (truncated). If omitted, auto-set from the first chat message.
`agent_id` is optional — if omitted, the system default agent is used.

```bash
RESULT=$($agent create_conversation --input "{\"conversation_type\": \"bot_chat\", \"title\": \"用户的问题\"}")
CONV_ID=$(echo "$RESULT" | python3 -c "import sys,json; print(json.load(sys.stdin)['id'])")
TASK_URL=$(echo "$RESULT" | python3 -c "import sys,json; print(json.load(sys.stdin).get('shared_url',''))")
```

### Step 2: Send task in background mode

**CRITICAL: Pass the user's original question verbatim as `message` — do NOT rephrase, translate, summarize, or modify it in any way.** The Reportify Agent needs the exact original text to work correctly.

Use `background: true` so the command returns immediately — the agent will process asynchronously.

```bash
CHAT_RESULT=$($agent chat --input "{\"conversation_id\": ${CONV_ID}, \"message\": \"用户的问题\", \"background\": true}")
MSG_ID=$(echo "$CHAT_RESULT" | python3 -c "import sys,json; print(json.load(sys.stdin)['assistant_message_id'])")
```

### Step 3: Notify user

Inform the user that the task has been delegated. Include `TASK_URL` so the user can check progress or view results:

> "已提交给 Reportify Agent 处理，完成后会通过消息通知你。"

Results are also delivered via callback hook automatically — no need to poll.

### Step 4: (Optional) Check progress or get files

```bash
$agent get_message_events --input "{\"conversation_id\": ${CONV_ID}, \"assistant_message_id\": \"${MSG_ID}\", \"stream\": false}"
$agent get_file --input "{\"file_id\": \"${FILE_ID}\"}"
```

## Task Phrasing Guidelines

Pass the user's question as-is when possible. Ensure:
1. **Specific time scope**: Include fiscal year/quarter, exact dates
2. **Specific companies**: Use full company names or stock codes
3. **Specify output format**: "output to Excel" / "输出到 Excel" when needed

## Applicable Task Types

- **Document research**: Earnings call analysis (single/cross-quarter), FOMC minutes, management commentary extraction, cross-company comparison
- **Stock screening (Excel output)**: Volume patterns, technical patterns (MACD/KDJ/RSI/MA/Bollinger), market cap/valuation, turnover rate, price patterns (new high/low, limit-up), complex multi-condition screening beyond `quant screen`
- **Other**: Multi-step quantitative analysis, research with document retrieval + synthesis, tasks requiring structured output (Excel, charts)
