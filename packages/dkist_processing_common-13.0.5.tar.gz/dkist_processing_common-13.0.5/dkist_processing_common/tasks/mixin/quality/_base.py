"""Base QualityMixin class that contains machinery common to all metric types."""

from typing import Iterable

import numpy as np

from dkist_processing_common.codecs.json import json_encoder
from dkist_processing_common.codecs.quality import QualityValueEncoder
from dkist_processing_common.models.tags import Tag
from dkist_processing_common.models.task_name import TaskName
from dkist_processing_common.tasks.mixin.quality._metrics import _PolcalQualityMixin
from dkist_processing_common.tasks.mixin.quality._metrics import _SimplePlotQualityMixin
from dkist_processing_common.tasks.mixin.quality._metrics import _TableQualityMixin
from dkist_processing_common.tasks.mixin.quality._metrics import _WavecalQualityMixin


class QualityMixin(
    _SimplePlotQualityMixin,
    _TableQualityMixin,
    _PolcalQualityMixin,
    _WavecalQualityMixin,
):
    """Mixin class supporting the generation of the quality reports."""

    def quality_assemble_data(self, polcal_label_list: list[str] | None = None) -> list[dict]:
        """Assemble the quality data by checking for the existence of each metric."""
        report = []
        report += self.quality_task_independent_metrics()

        polcal_labels = polcal_label_list or []
        report += self.quality_polcal_metrics(polcal_labels)

        return report

    def quality_task_independent_metrics(self) -> list[dict]:
        """Encapsulate task independent metric parsing."""
        result = []
        for metric_name, metric_func in self.quality_metrics_no_task_dependence.items():
            if self._quality_metric_exists(metric_name=metric_name):
                result.append(metric_func())
        return result

    def quality_polcal_metrics(self, label_list: list) -> list[dict]:
        """Encapsulate polcal metric parsing."""
        result = []
        for metric_name, metric_func in self.quality_metrics_polcal.items():
            for label in label_list:
                if self._quality_metric_exists(metric_name=metric_name, task_type=label):
                    result.append(metric_func(label=label))

        return result

    @property
    def quality_task_types(self) -> list[str]:
        """Task types to use in generating metrics that work on several task types."""
        return [
            TaskName.dark.value,
            TaskName.gain.value,
            TaskName.lamp_gain.value,
            TaskName.solar_gain.value,
        ]

    @property
    def quality_metrics_no_task_dependence(self) -> dict:
        """Return a dict of the quality metrics with no task dependence."""
        return {
            "TASK_TYPES": self.quality_build_task_type_counts,
            "WAVECAL_FIT": self.quality_build_wavecal_results,
        }

    @property
    def quality_metrics_polcal(self) -> dict:
        """Return a dict of polcal quality metrics."""
        return {
            "POLCAL_CONSTANT_PAR_VALS": self.quality_build_polcal_constant_parameter_values,
            "POLCAL_GLOBAL_PAR_VALS": self.quality_build_polcal_global_parameter_values,
            "POLCAL_LOCAL_PAR_VALS": self.quality_build_polcal_local_parameter_values,
            "POLCAL_FIT_RESIDUALS": self.quality_build_polcal_fit_residuals,
            "POLCAL_EFFICIENCY": self.quality_build_polcal_efficiency,
        }

    def _quality_metric_exists(self, metric_name: str, task_type: str = None) -> bool:
        """Look for the existence of data on disk for a quality metric."""
        tags = [Tag.quality(quality_metric=metric_name)]
        if task_type:
            tags.append(Tag.quality_task(quality_task_type=task_type))
        try:
            next(self.read(tags=tags))
            return True
        except StopIteration:
            return False

    @staticmethod
    def _format_warnings(warnings: list[str] | None) -> list[str] | None:
        """If warnings is an empty list, change its value to None."""
        return warnings or None

    def _record_values(self, values, tags: Iterable[str] | str):
        """Serialize and store distributed quality report values for."""
        self.write(
            data=values, tags=tags, encoder=json_encoder, allow_nan=False, cls=QualityValueEncoder
        )
