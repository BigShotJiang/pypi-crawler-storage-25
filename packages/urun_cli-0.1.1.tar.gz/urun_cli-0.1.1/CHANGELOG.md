# Changelog

## 0.1.0 - Unreleased

- Initial end-user `urun deploy` CLI.
- Manifest generation, file discovery, dependency declaration upload, and API deploy flow.
- Local fake Edge API and MinIO integration tests.
