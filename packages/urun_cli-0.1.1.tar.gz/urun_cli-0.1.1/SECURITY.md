# Security Policy

## Reporting vulnerabilities

Please report suspected vulnerabilities privately to the urun maintainers. Do not open a public issue with exploit details.

## CLI key handling

- Prefer `URUN_API_KEY` over shell history-visible command-line flags.
- Do not commit real API keys or `.env` files.
- The CLI validates the `urun_<32 lowercase hex>` shape locally, but the server remains authoritative for auth and revocation.

## Source upload behavior

`urun deploy` uploads selected source files and dependency declaration files to urun via presigned object-store URLs. Review `.urunignore` and `urun.toml` before deploying sensitive repositories.

The CLI enforces project-root containment for entrypoints, explicit mounts, and dependency files. Symlinks are resolved before that containment check.

## Local MinIO

MinIO is optional for local S3-compatible integration tests. The documented `minioadmin` credentials are development-only and must not be used for production services.
