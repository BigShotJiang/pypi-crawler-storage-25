# urun deploy external platform — SPEC v1

Status: implementation-ready draft. This document defines the platform pieces still needed around the already-implemented `urun-cli` deploy client. It complements `SPEC.md`; the CLI remains the source of truth for manifest construction and upload behavior.

---

## 1. Scope

This spec covers the external services required after `urun deploy` constructs a manifest and uploads blobs:

1. Supabase Edge Functions for auth, presigned upload URL issuance, finalize, and status reads.
2. API-key auth backed by Supabase Postgres.
3. OpenTofu infrastructure for S3-compatible object storage, SQS, DLQ, IAM, lifecycle, and event wiring.
4. A cluster sync worker that watches S3 manifest events and creates Kubernetes builder Jobs.
5. A light modification to the existing Kubernetes builder path in `../urun/urun/backends/k8s.py`: replace deploy-host `kubectl exec tar` source sync with S3/manifest-driven materialization.

Out of scope here:

- The end-user CLI implementation, except where its contract is referenced.
- ArgoCD/runtime serving beyond writing `ready` status with enough data for later consumers.
- API-key self-service UI.
- Cross-org blob dedup.

---

## 2. Existing code to reuse

The current urun Kubernetes backend already contains most builder mechanics:

- File: `../urun/urun/backends/k8s.py`
- Builder Job construction: `_build_builder_job_manifest(...)`
- Builder execution/wait path: `_run_build_phase(...)`
- Existing source sync path:
  - `_sync_urun_source_to_builder(...)` streams a tar archive into the builder pod via `kubectl exec tar xzf -`.
  - `_sync_app_source_via_builder(...)` streams app source into `/mnt/zerofs/.app-source/<app_hash>` and writes `.urun_app_source_complete`.
  - `_wrap_builder_script(...)` already waits for app source readiness via `/mnt/zerofs/.app-source/<hash>/.urun_app_source_complete` before dependency build.
- ZeroFS mount constants and env wiring already exist:
  - `ZEROFS_MOUNT = /mnt/zerofs`
  - builder Jobs mount ZeroFS and receive `urun-zerofs-config` / app-specific ZeroFS config/secret.

The new path should preserve builder images, resources, tolerations, ZeroFS mounting, venv caching, dependency install behavior, and status/log semantics. Only source ingestion changes: from deploy-host tar sync to S3 blob/manifest materialization.

---

## 3. End-to-end target flow

```text
CLI
  POST /register-manifest         -> Edge validates/auths, stores pending manifest, returns missing blob PUT URLs
  PUT presigned blob URLs         -> CLI uploads only missing content-addressed blobs
  POST /finalize/:manifest_hash   -> Edge verifies blobs, copies pending -> manifests, writes queued status

S3 event on manifests/<org_id>/<hash>.json
  -> SQS urun-build-events
  -> sync worker polls event
  -> sync worker creates/ensures Kubernetes builder Job
  -> builder materializes blobs to ZeroFS and runs existing dependency build flow
  -> builder/status writer updates status/<org_id>/<hash>.json to building/ready/failed
```

Canonical bucket layout for this spec uses flattened top-level prefixes for easier S3 event filters:

```text
s3://urun-uploads-<env>/
├── blobs/<org_id>/<sha256>
├── pending/<org_id>/<manifest_hash>.json
├── manifests/<org_id>/<manifest_hash>.json     # S3 event source
└── status/<org_id>/<manifest_hash>.json
```

The CLI/external protocol does not expose S3 keys directly, so this layout can differ from `SPEC.md` as long as API semantics remain identical.

---

## 4. Supabase database/auth

### 4.1 Schema

```sql
create table if not exists orgs (
  id          text primary key,         -- org_<random>
  name        text not null,
  created_at  timestamptz not null default now()
);

create table if not exists api_keys (
  id          text primary key,         -- key_<random>
  org_id      text not null references orgs(id),
  key_hash    text not null unique,     -- sha256(raw_key) lowercase hex
  label       text,
  created_at  timestamptz not null default now(),
  revoked_at  timestamptz
);

create index if not exists api_keys_active_hash_idx
  on api_keys(key_hash)
  where revoked_at is null;
```

### 4.2 Raw key format

```text
urun_<32 lowercase hex chars>
```

The raw key is shown once at bootstrap and never stored. Store only `sha256(raw_key)`.

### 4.3 Auth helper contract

All Edge Functions call the same helper:

```ts
type AuthContext = { org_id: string; key_id: string };

async function authenticate(req: Request): Promise<AuthContext | null> {
  const raw = req.headers.get("authorization")?.replace(/^Bearer\s+/i, "");
  if (!/^urun_[0-9a-f]{32}$/.test(raw ?? "")) return null;
  const keyHash = await sha256Hex(raw!);
  const { data, error } = await sb
    .from("api_keys")
    .select("id, org_id")
    .eq("key_hash", keyHash)
    .is("revoked_at", null)
    .single();
  if (error || !data) return null;
  return { org_id: data.org_id, key_id: data.id };
}
```

### 4.4 Auth requirements

- `401 unauthorized` for missing, malformed, revoked, or unknown keys.
- Never log raw API keys. Log only `key_id`, `org_id`, request id, endpoint, status, and latency.
- `org_id` in the submitted manifest must match authenticated `org_id`; otherwise return `403 forbidden`.
- CLI currently requires `URUN_ORG_ID` to construct the manifest. This remains a bootstrap-era requirement until a future `/whoami` or config bootstrap flow exists.

---

## 5. Edge Function API

Base URL: `https://api.urun.sh/v1`.

All responses use `application/json`. Error shape:

```json
{"error":{"code":"invalid_manifest","message":"..."}}
```

### 5.1 Common validation

Manifest limits:

- JSON body max: 1 MiB.
- `version == 1`.
- `manifest_hash` must be absent on `POST /register-manifest`.
- `org_id` equals authenticated org.
- File count across `files`, `mounts[*].files`, and dependency blob references: max 10,000.
- Declared total size: max 500 MiB.
- Paths are forward-slash relative paths, no leading `/`, no `..`, no empty segments, no control chars.
- SHA values are lowercase 64-char hex.
- Modes are regular-file POSIX modes, preserving executable bit only.
- `deps.kind` is one of `requirements_txt`, `pyproject_toml`, `none`.
- `python_version` supported values in v1: `3.11`, `3.12`; default expected from CLI is `3.12`.

Server recomputes:

```text
manifest_hash = sha256(canonical_json(manifest_without_manifest_hash))
```

Canonical JSON: sorted keys, compact separators, UTF-8, no trailing whitespace.

### 5.2 POST /register-manifest

Request body: manifest JSON without `manifest_hash`.

Response 200:

```json
{
  "manifest_hash": "<64hex>",
  "missing_blobs": [
    {
      "sha256": "<64hex>",
      "upload_url": "https://...",
      "expires_at": "2026-05-20T16:00:00Z"
    }
  ],
  "status_url": "https://api.urun.sh/v1/deployment-status/<hash>"
}
```

Behavior:

1. Authenticate request.
2. Validate manifest and org match.
3. Compute manifest hash.
4. For every unique blob SHA in the manifest, `HEAD blobs/<org_id>/<sha256>`.
5. For missing blobs, mint presigned PUT URLs:
   - Key: `blobs/<org_id>/<sha256>`.
   - TTL: 10 minutes.
   - Method: PUT.
   - Content-Length constrained to declared size if the provider supports signed length constraints.
   - Prefer checksum constraint: signed `x-amz-checksum-sha256` when supported.
   - No client API auth header is required or accepted by S3.
6. Write pending manifest to `pending/<org_id>/<manifest_hash>.json` with metadata:
   - `content-type: application/json`
   - `x-amz-meta-org-id`
   - `x-amz-meta-manifest-hash`
   - `x-amz-meta-key-id`
7. Return missing blob list.

Errors:

- `401 unauthorized`
- `403 forbidden`
- `400 invalid_manifest`
- `413 manifest_too_large`
- `500 internal`

### 5.3 POST /finalize/:manifest_hash

Request body: empty.

Response 200:

```json
{"manifest_hash":"<hash>","status":"queued"}
```

Behavior:

1. Authenticate request.
2. Validate `manifest_hash` path param is 64 lowercase hex.
3. Load `pending/<org_id>/<hash>.json`; if missing return `404 manifest_not_found`.
4. Verify every blob in the manifest exists at `blobs/<org_id>/<sha256>` and size matches declared size where available.
5. If missing, return `409 missing_blobs`:

```json
{"error":{"code":"missing_blobs","message":"missing 2 blobs","missing":["sha..."]}}
```

1. Copy pending manifest to `manifests/<org_id>/<hash>.json`. This write is the event trigger.
2. Write `status/<org_id>/<hash>.json` with queued status.
3. Delete pending manifest.

Queued status body:

```json
{
  "manifest_hash": "<hash>",
  "org_id": "org_...",
  "app_name": "my-app",
  "status": "queued",
  "zerofs_path": null,
  "queued_at": "2026-05-20T15:30:00Z",
  "started_at": null,
  "built_at": null,
  "replicas": 0,
  "image_refs": [],
  "error": null
}
```

### 5.4 GET /deployment-status/:manifest_hash

Response 200: the status JSON from `status/<org_id>/<hash>.json`.

Behavior:

1. Authenticate request.
2. Validate hash param.
3. Read `status/<org_id>/<hash>.json`.
4. Return `404 status_not_found` if missing.

### 5.5 Optional bootstrap endpoints

Out of v1 but recommended soon:

- `GET /whoami` -> `{org_id, key_id}` so the CLI no longer needs `URUN_ORG_ID`.
- `POST /api-keys` -> generate/bootstrap keys only after an authenticated admin mechanism exists.

---

## 6. OpenTofu infrastructure

Directory recommendation in the platform repo:

```text
infra/opentofu/urun-deploy/
├── main.tf
├── variables.tf
├── outputs.tf
├── iam.tf
├── s3.tf
├── sqs.tf
└── examples/dev.tfvars
```

### 6.1 Variables

```hcl
variable "env" { type = string } # dev | staging | prod
variable "aws_region" { type = string }
variable "bucket_name" { type = string } # default urun-uploads-${var.env}
variable "sync_worker_role_arn" { type = string }
variable "edge_function_role_arn" { type = string }
variable "builder_role_arn" { type = string }
variable "kms_key_arn" { type = string, default = null }
variable "pending_ttl_days" { type = number, default = 1 }
variable "sqs_visibility_timeout_seconds" { type = number, default = 600 }
variable "sqs_max_receive_count" { type = number, default = 3 }
```

### 6.2 S3 bucket

Required resources:

- `aws_s3_bucket.uploads`
- `aws_s3_bucket_public_access_block.uploads`
- `aws_s3_bucket_versioning.uploads` with versioning enabled
- `aws_s3_bucket_server_side_encryption_configuration.uploads`
  - SSE-S3 acceptable for dev.
  - SSE-KMS recommended for staging/prod.
- `aws_s3_bucket_lifecycle_configuration.uploads`
  - expire `pending/` after 1 day
  - abort incomplete multipart uploads after 1 day
  - retain `blobs/`, `manifests/`, `status/` indefinitely in v1
- `aws_s3_bucket_notification.uploads`
  - event: `s3:ObjectCreated:*`
  - prefix: `manifests/`
  - destination: SQS queue `urun-build-events-${env}`

Bucket policy:

- Deny non-TLS (`aws:SecureTransport = false`).
- Deny public ACLs/policies.
- Allow Edge role:
  - `s3:GetObject`, `s3:PutObject`, `s3:DeleteObject`, `s3:CopyObject`, `s3:HeadObject` on `pending/*`, `manifests/*`, `status/*`, `blobs/*`
  - `s3:ListBucket` constrained to prefixes required by implementation.
- Allow sync worker role:
  - read `manifests/*`, read/write `status/*`, read `blobs/*` if it validates before job creation.
- Allow builder role:
  - read `manifests/*`, read `blobs/*`, write `status/*`.
- No broad `s3:*` except for tightly scoped admin roles.

### 6.3 SQS

Resources:

- `aws_sqs_queue.build_events_dlq`
  - name: `urun-build-events-${env}-dlq`
  - retention: 14 days
- `aws_sqs_queue.build_events`
  - name: `urun-build-events-${env}`
  - standard queue, not FIFO
  - visibility timeout: 600 seconds
  - message retention: 4 days
  - redrive policy to DLQ with max receive count 3
- `aws_sqs_queue_policy.build_events`
  - allow only S3 bucket to `sqs:SendMessage`
  - condition `aws:SourceArn = bucket arn`

Queue consumer permissions for sync worker:

```hcl
sqs:ReceiveMessage
sqs:DeleteMessage
sqs:ChangeMessageVisibility
sqs:GetQueueAttributes
```

### 6.4 IAM for Kubernetes service accounts

Use IRSA (EKS) or Workload Identity equivalent.

Service accounts:

- `urun-deploy-sync-worker`
- `urun-builder`

Required annotations are environment/provider-specific and emitted as OpenTofu outputs.

### 6.5 Outputs

```hcl
output "uploads_bucket_name" {}
output "uploads_bucket_arn" {}
output "build_events_queue_url" {}
output "build_events_queue_arn" {}
output "build_events_dlq_url" {}
output "edge_s3_policy_json" {}
output "sync_worker_policy_json" {}
output "builder_policy_json" {}
```

### 6.6 LocalStack/MinIO note

OpenTofu should target AWS-compatible services in deployed envs. Local tests may use MinIO for S3 behavior and a fake SQS implementation, but production event wiring is AWS S3 -> SQS.

---

## 7. Sync worker

The sync worker is a long-running Kubernetes Deployment that consumes SQS S3 event messages and creates builder Jobs.

### 7.1 Runtime config

Environment variables:

```text
URUN_ENV=dev|staging|prod
URUN_UPLOADS_BUCKET=urun-uploads-<env>
URUN_BUILD_EVENTS_QUEUE_URL=https://sqs...
URUN_STATUS_PREFIX=status
URUN_MANIFEST_PREFIX=manifests
URUN_BLOBS_PREFIX=blobs
URUN_K8S_NAMESPACE=urun
URUN_BUILDER_SERVICE_ACCOUNT=urun-builder
URUN_BUILDER_IMAGE=<existing builder/runtime image>
URUN_SYNC_WORKER_CONCURRENCY=8
URUN_SYNC_WORKER_VISIBILITY_EXTENSION_SECONDS=300
URUN_ZEROFS_MOUNT=/mnt/zerofs
URUN_VALKEY_URL=redis://...
```

### 7.2 Message handling

Input is raw S3 event JSON delivered by SQS. The worker must handle:

- `Records[*].s3.bucket.name`
- `Records[*].s3.object.key`
- URL-encoded object keys
- duplicate records
- test events and unrelated prefixes

Only process keys matching:

```text
manifests/<org_id>/<manifest_hash>.json
```

Reject/ignore anything else after logging at info/debug.

### 7.3 Locking and idempotency

Before creating a builder Job, acquire a Valkey lock:

```text
SET urun:deploy-build:<manifest_hash> <worker_id> NX EX 900
```

If lock is held:

- Check status.
- If status is `ready` or `building`, delete SQS message.
- Otherwise leave message for retry or extend visibility, depending on status age.

Kubernetes Job name:

```text
urun-build-<manifest_hash[:12]>
```

If Job already exists:

- If active/running: treat as idempotent and monitor/ack based on status policy.
- If succeeded and status not ready: write ready if materialized output exists.
- If failed: write failed and ack, or delete/recreate only if failure is known transient and receive count < max.

### 7.4 Job creation

The sync worker should reuse/refactor the existing `K8sBackend._build_builder_job_manifest(...)` shape where practical:

- Same builder image selection defaults.
- Same ZeroFS volume and `envFrom` config.
- Same resource env defaults:
  - `URUN_K8S_BUILDER_CPU_REQUEST`
  - `URUN_K8S_BUILDER_MEMORY_REQUEST`
  - `URUN_K8S_BUILDER_MAX_JOBS`
- Same node selectors/tolerations if configured.

Additional builder Job env:

```yaml
env:
  - name: URUN_DEPLOY_MODE
    value: "s3-manifest"
  - name: URUN_UPLOADS_BUCKET
    valueFrom: ...
  - name: URUN_MANIFEST_KEY
    value: "manifests/<org_id>/<hash>.json"
  - name: URUN_ORG_ID
    value: "<org_id>"
  - name: URUN_MANIFEST_HASH
    value: "<hash>"
  - name: URUN_STATUS_KEY
    value: "status/<org_id>/<hash>.json"
  - name: URUN_ZEROFS_MOUNT
    value: "/mnt/zerofs"
```

### 7.5 Status writes

The worker writes only orchestration statuses if the builder cannot write them itself:

- `building` immediately before/after creating the Job.
- `failed` if Job creation fails.

The builder should write final `ready` or deterministic `failed` states after materialization/build.

Status update rules:

- Preserve existing `queued_at`.
- Set `started_at` on first transition to `building`.
- Use optimistic write when possible (`If-Match` on ETag); otherwise last-writer-wins is acceptable for v1 if transitions are monotonic.

### 7.6 Ack/retry policy

- Ack SQS message after:
  - status is `ready`, or
  - status is deterministic `failed`, or
  - another worker/job owns the same manifest and status is `building`.
- Do not ack on:
  - S3 5xx
  - Kubernetes API transient failures
  - Valkey connection failures before ownership is known
- Extend visibility while actively creating/watching a job.
- Let SQS redrive to DLQ after 3 receives.

---

## 8. Builder S3 materialization contract

### 8.1 Existing behavior to replace

Current builder path waits for deploy-host sync:

- `urun` source: `/mnt/zerofs/.urun-source/<urun_source_hash>`
- app source: `/mnt/zerofs/.app-source/<app_source_hash>`
- marker: `.urun_app_source_complete`

Current sync is done by `kubectl exec` streaming tar into the running builder pod. New external deploys must not require the developer machine to have Kubernetes access or stream tar.

### 8.2 New materialization behavior

In `URUN_DEPLOY_MODE=s3-manifest`, the builder container performs:

1. Read manifest from `s3://<bucket>/<manifest_key>`.
2. Validate manifest hash equals `URUN_MANIFEST_HASH`.
3. If `/mnt/zerofs/mounts/<manifest_hash>/.urun_manifest_complete` exists and matches hash:
   - skip source download,
   - ensure deps/build readiness,
   - write ready if appropriate.
4. Materialize application files:
   - staging dir: `/mnt/zerofs/staging/<manifest_hash>`
   - final dir: `/mnt/zerofs/mounts/<manifest_hash>`
5. For each `manifest.files[*]`:
   - GET `blobs/<org_id>/<sha256>`
   - stream to `staging/<path>`
   - hash while streaming
   - verify SHA-256 and size
   - chmod declared mode
6. For each mount:
   - materialize under staging according to mount contract.
   - Recommended v1: write explicit mount contents into `staging/.mounts/<remote_path-normalized>/...` and include mount metadata for runtime; or, if runtime always sees `/app`, merge only `files` into `/app` and defer arbitrary `remote_path` mounts to the runtime deploy layer.
7. Dependency declaration:
   - If `deps.kind != none`, download the dependency blob to a known path in staging:
     - `requirements_txt` -> `staging/requirements.txt` unless already present
     - `pyproject_toml` -> `staging/pyproject.toml` unless already present
   - Then call existing dependency builder logic using `deps.python_version` and dependency file.
8. Write `.urun_manifest_complete` containing manifest hash.
9. `fsync` files/directories where practical.
10. Atomic rename staging -> final.
11. Write ready status.

### 8.3 Status schema

Final ready status:

```json
{
  "manifest_hash": "<hash>",
  "org_id": "org_...",
  "app_name": "my-app",
  "status": "ready",
  "zerofs_path": "/mnt/zerofs/mounts/<hash>",
  "queued_at": "...",
  "started_at": "...",
  "built_at": "...",
  "replicas": 0,
  "image_refs": [],
  "error": null
}
```

Failed status:

```json
{
  "status": "failed",
  "error": {
    "code": "blob_corruption|missing_blob|deps_install_failed|k8s_job_failed|internal",
    "message": "..."
  }
}
```

Deterministic failures should be acked and not retried by SQS.

### 8.4 Suggested code shape

Add a small module in the main `urun` repo, not in `urun-cli`:

```text
urun/deploy_manifest/
├── __init__.py
├── materialize.py       # S3 -> ZeroFS materialization
├── status.py            # read/write status JSON
├── schema.py            # manifest/status validation
└── worker.py            # SQS sync worker entrypoint
```

Refactor `k8s.py` minimally:

- Add a builder mode that sets `URUN_DEPLOY_MODE=s3-manifest` and uses a materializer command before the existing build script.
- Keep `_build_builder_job_manifest(...)` as the Job manifest factory.
- Stop calling `_sync_urun_source_to_builder(...)` and `_sync_app_source_via_builder(...)` for external deploy manifests.
- Preserve the existing tar sync path for local/dev direct Kubernetes backend deployments.

---

## 9. Kubernetes manifests for sync worker

Deployment:

```yaml
apiVersion: apps/v1
kind: Deployment
metadata:
  name: urun-deploy-sync-worker
spec:
  replicas: 2
  selector:
    matchLabels: {app: urun-deploy-sync-worker}
  template:
    metadata:
      labels: {app: urun-deploy-sync-worker}
    spec:
      serviceAccountName: urun-deploy-sync-worker
      containers:
        - name: worker
          image: ghcr.io/urun-sh/urun-deploy-sync-worker:<tag>
          envFrom:
            - configMapRef: {name: urun-deploy-config}
            - secretRef: {name: urun-deploy-secrets}
          resources:
            requests: {cpu: "250m", memory: "256Mi"}
            limits: {cpu: "1", memory: "1Gi"}
```

RBAC:

- Create/get/list/watch/delete Jobs in target namespace.
- Create/get/list/watch Pods for status inspection.
- Get logs if worker streams/collects builder logs.
- Create/update ConfigMaps/Secrets only if builder Job config requires per-app resources; prefer pre-created shared config.

---

## 10. Observability

Metrics:

- `urun_sync_worker_messages_total{result}`
- `urun_sync_worker_job_create_total{result}`
- `urun_sync_worker_manifest_latency_seconds`
- `urun_sync_worker_build_duration_seconds`
- `urun_edge_requests_total{endpoint,status}`
- `urun_edge_latency_seconds{endpoint}`
- `urun_builder_materialized_bytes_total`
- `urun_builder_materialization_failures_total{code}`

Logs must include:

- `request_id` / `message_id`
- `org_id`
- `manifest_hash`
- `app_name`
- `job_name`
- status transition

Logs must not include:

- raw API keys
- presigned URLs with signatures
- dependency file contents
- environment secret values

---

## 11. Testing plan

### 11.1 Edge Function unit tests

- Auth success and 401 paths.
- Org mismatch -> 403.
- Invalid manifest -> 400.
- Oversize manifest/total size -> 413.
- Missing blob list generation with fake S3 HEAD results.
- Finalize missing pending -> 404.
- Finalize missing blobs -> 409.
- Finalize writes status and manifest object.
- Status GET returns status JSON and 404 on missing.

### 11.2 OpenTofu validation

- `tofu fmt -check`
- `tofu validate`
- policy snapshot tests for IAM least privilege.
- LocalStack or mocked plan tests where practical.

### 11.3 Sync worker tests

- Parses S3 event JSON and ignores irrelevant keys.
- Handles duplicate records idempotently.
- Creates exactly one Job for parallel duplicate messages.
- Does not ack transient S3/K8s/Valkey failures.
- Acks deterministic failed/ready states.
- DLQ behavior verified by integration test or documented manual smoke.

### 11.4 Builder materialization tests

Use MinIO + temp ZeroFS directory or PVC-equivalent local mount:

- Downloads all files and verifies bytes/modes.
- Rejects hash mismatch as `blob_corruption`.
- Missing blob -> failed `missing_blob`.
- Re-running same manifest is idempotent and skips materialization if complete marker exists.
- Dependency file is downloaded to expected path.
- Atomic staging cleanup after failure.

### 11.5 Staging acceptance

1. `urun deploy app.py` reaches `ready` against staging.
2. Re-running the same deploy only uploads missing blobs; existing blob uploads are skipped.
3. Killing a builder pod mid-build retries via SQS and reaches `ready`.
4. Two parallel finalizations of the same manifest result in one builder Job and two ready CLI pollers.
5. Invalid API key returns 401 quickly.
6. 600 MiB declared manifest is rejected with 413.

---

## 12. Rollout plan

1. Implement OpenTofu module in dev with S3/SQS/DLQ/IAM.
2. Implement Edge Functions against dev bucket and Supabase dev project.
3. Implement sync worker with fake builder Job first; prove SQS -> Job creation.
4. Add builder materializer mode and local MinIO materialization tests.
5. Wire sync worker to create real builder Jobs using existing `k8s.py` manifest factory/refactored shared code.
6. Run staging CLI E2E.
7. Add dashboards/alerts.
8. Promote to prod after acceptance criteria pass.

---

## 13. Open decisions

- Whether `created_at` remains part of `manifest_hash`; current CLI follows `SPEC.md` literally, so identical files deployed at different seconds produce different manifests.
- Whether `entrypoint` for `-m myapp.main` remains a module string or is normalized to a source path in the manifest.
- Whether arbitrary `mounts.remote_path` are materialized by builder or deferred to runtime/ArgoCD manifest generation.
- Whether Edge Functions run with AWS credentials directly or call a signing service in-cluster.
- Whether sync worker or builder is the sole writer of final `ready` status.
