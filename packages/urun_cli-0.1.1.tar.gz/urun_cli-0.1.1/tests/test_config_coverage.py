from __future__ import annotations

from pathlib import Path

import pytest

from urun.config import load_config, parse_config, validate_remote_path
from urun.errors import UrunError


def test_load_config_missing_returns_defaults(tmp_path, monkeypatch):
    monkeypatch.chdir(tmp_path)
    cfg = load_config(None)
    assert cfg.app.name is None
    assert cfg.mounts == []


def test_load_config_invalid_toml_is_user_error(tmp_path):
    config = tmp_path / "urun.toml"
    config.write_text("[app\n")
    with pytest.raises(UrunError, match="Invalid TOML"):
        load_config(config)


@pytest.mark.parametrize(
    ("data", "message"),
    [
        ({"app": "bad"}, r"\[app\] must be a table"),
        ({"deps": "bad"}, r"\[deps\] must be a table"),
        ({"app": {"name": 123}}, "name must be a string"),
        ({"mounts": ["bad"]}, "must be a table"),
        ({"mounts": [{"remote_path": "/x"}]}, "exactly one source"),
        (
            {"mounts": [{"local_path": "a", "local_file": "b", "remote_path": "/x"}]},
            "exactly one source",
        ),
        ({"mounts": [{"local_path": "a"}]}, "must set remote_path"),
    ],
)
def test_parse_config_validation_errors(data, message):
    with pytest.raises(UrunError, match=message):
        parse_config(data, Path("test.toml"))


@pytest.mark.parametrize(
    "remote_path", ["relative", "/", "/a//b", "/a/./b", "/a/../b", "/a\\b", "/a/\x01b"]
)
def test_validate_remote_path_rejects_non_normalized(remote_path):
    with pytest.raises(UrunError, match="remote_path"):
        validate_remote_path(remote_path, Path("urun.toml"), 0)


def test_validate_remote_path_rejects_too_long():
    with pytest.raises(UrunError, match="remote_path"):
        validate_remote_path("/" + "a" * 513, Path("urun.toml"), 0)
