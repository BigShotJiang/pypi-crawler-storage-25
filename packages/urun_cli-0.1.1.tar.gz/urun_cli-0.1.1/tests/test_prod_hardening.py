from __future__ import annotations

import json
import threading
import time
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

from urun.api import upload_missing_blobs
from urun.cli import main
from urun.config import MountConfig, parse_config
from urun.discovery import auto_include, discover_mounts
from urun.errors import UrunError
from urun.manifest import file_blob, manifest_hash


def test_cli_rejects_malformed_api_key(tmp_path, monkeypatch):
    (tmp_path / "app.py").write_text("print(1)\n")
    monkeypatch.chdir(tmp_path)
    assert main(["deploy", "app.py", "--api-key", "bad", "--org-id", "org_test"]) == 1


def test_auto_include_outside_project_is_user_facing_error(tmp_path):
    outside = tmp_path.parent / "outside_app.py"
    outside.write_text("print(1)\n")
    try:
        auto_include(outside, tmp_path)
    except UrunError as exc:
        assert "project" in str(exc)
    else:
        raise AssertionError("expected UrunError")


def test_remote_path_rejects_relative_and_traversal():
    for remote_path in ["app/assets", "/app/../secret", "/", "/app//x", "/app/.", "/app\\x"]:
        try:
            parse_config({"mounts": [{"local_path": "assets", "remote_path": remote_path}]})
        except UrunError:
            pass
        else:
            raise AssertionError("expected UrunError")


def test_duplicate_mount_remote_paths_rejected(tmp_path):
    (tmp_path / "assets").mkdir()
    (tmp_path / "more").mkdir()
    mounts = [
        MountConfig(local_path="assets", remote_path="/app/assets"),
        MountConfig(local_path="more", remote_path="/app/assets"),
    ]
    try:
        discover_mounts(mounts, tmp_path)
    except UrunError as exc:
        assert "duplicate" in str(exc)
    else:
        raise AssertionError("expected UrunError")


def test_finalize_missing_blobs_exits_nonzero(tmp_path, monkeypatch):
    (tmp_path / "app.py").write_text("print(1)\n")

    class Handler(BaseHTTPRequestHandler):
        def do_POST(self):
            if self.path == "/register-manifest":
                body = self.rfile.read(int(self.headers.get("content-length", "0")))
                mh = manifest_hash(json.loads(body.decode()))
                self._json({"manifest_hash": mh, "missing_blobs": [], "status_url": ""})
                return
            if self.path.startswith("/finalize/"):
                self._json({"error": {"code": "missing_blobs", "message": "missing abc"}}, 409)
                return
            self.send_error(404)

        def _json(self, payload, status=200):
            raw = json.dumps(payload).encode()
            self.send_response(status)
            self.send_header("content-type", "application/json")
            self.send_header("content-length", str(len(raw)))
            self.end_headers()
            self.wfile.write(raw)

        def log_message(self, *args):
            pass

    server = ThreadingHTTPServer(("127.0.0.1", 0), Handler)
    threading.Thread(target=server.serve_forever, daemon=True).start()
    monkeypatch.chdir(tmp_path)
    try:
        code = main(
            [
                "deploy",
                "app.py",
                "--api-url",
                f"http://127.0.0.1:{server.server_address[1]}",
                "--api-key",
                "urun_" + "a" * 32,
                "--org-id",
                "org_test",
            ]
        )
        assert code == 1
    finally:
        server.shutdown()


def test_upload_failure_prevents_finalize(tmp_path, monkeypatch):
    (tmp_path / "app.py").write_text("print(1)\n")
    finalize_called = False

    class Handler(BaseHTTPRequestHandler):
        def do_POST(self):
            nonlocal finalize_called
            if self.path == "/register-manifest":
                body = self.rfile.read(int(self.headers.get("content-length", "0")))
                manifest = json.loads(body.decode())
                mh = manifest_hash(manifest)
                sha = manifest["files"][0]["sha256"]
                self._json(
                    {
                        "manifest_hash": mh,
                        "missing_blobs": [
                            {
                                "sha256": sha,
                                "upload_url": f"http://127.0.0.1:{self.server.server_address[1]}/upload/{sha}",
                                "expires_at": "",
                            }
                        ],
                        "status_url": "",
                    }
                )
                return
            if self.path.startswith("/finalize/"):
                finalize_called = True
                self._json({"status": "queued"})
                return
            self.send_error(404)

        def do_PUT(self):
            self.send_response(500)
            self.end_headers()

        def _json(self, payload, status=200):
            raw = json.dumps(payload).encode()
            self.send_response(status)
            self.send_header("content-type", "application/json")
            self.send_header("content-length", str(len(raw)))
            self.end_headers()
            self.wfile.write(raw)

        def log_message(self, *args):
            pass

    server = ThreadingHTTPServer(("127.0.0.1", 0), Handler)
    threading.Thread(target=server.serve_forever, daemon=True).start()
    monkeypatch.chdir(tmp_path)
    try:
        code = main(
            [
                "deploy",
                "app.py",
                "--api-url",
                f"http://127.0.0.1:{server.server_address[1]}",
                "--api-key",
                "urun_" + "a" * 32,
                "--org-id",
                "org_test",
            ]
        )
        assert code == 1
        assert finalize_called is False
    finally:
        server.shutdown()


def test_upload_concurrency_is_bounded(tmp_path):
    blobs = []
    for i in range(12):
        p = tmp_path / f"{i}.txt"
        p.write_text(str(i))
        blobs.append(file_blob(p, tmp_path))

    active = 0
    max_active = 0
    lock = threading.Lock()

    class Handler(BaseHTTPRequestHandler):
        def do_PUT(self):
            nonlocal active, max_active
            with lock:
                active += 1
                max_active = max(max_active, active)
            time.sleep(0.05)
            self.rfile.read(int(self.headers.get("content-length", "0")))
            with lock:
                active -= 1
            self.send_response(200)
            self.end_headers()

        def log_message(self, *args):
            pass

    server = ThreadingHTTPServer(("127.0.0.1", 0), Handler)
    threading.Thread(target=server.serve_forever, daemon=True).start()
    try:
        missing = [
            {
                "sha256": b.sha256,
                "upload_url": f"http://127.0.0.1:{server.server_address[1]}/{b.sha256}",
            }
            for b in blobs
        ]
        upload_missing_blobs(missing, {b.sha256: b for b in blobs}, concurrency=4)
        assert max_active <= 4
    finally:
        server.shutdown()
