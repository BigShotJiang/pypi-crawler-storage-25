from urun.discovery import auto_include, derive_app_name


def test_derive_app_name_file_and_module():
    assert derive_app_name("app.py", None) == "app"
    assert derive_app_name("src/myapp/main.py", None) == "myapp"
    assert derive_app_name(None, "myapp.main") == "myapp"


def test_auto_include_single_file_outside_package(tmp_path):
    (tmp_path / "app.py").write_text("print(1)\n")
    (tmp_path / "helper.py").write_text("print(2)\n")
    blobs = auto_include(tmp_path / "app.py", tmp_path)
    assert [b.path for b in blobs] == ["app.py"]


def test_auto_include_whole_package_py_only(tmp_path):
    pkg = tmp_path / "src" / "myapp"
    pkg.mkdir(parents=True)
    (pkg / "__init__.py").write_text("")
    (pkg / "main.py").write_text("print(1)\n")
    (pkg / "data.txt").write_text("nope")
    (pkg / "__pycache__").mkdir()
    (pkg / "__pycache__" / "main.py").write_text("ignored")
    blobs = auto_include(pkg / "main.py", tmp_path)
    assert [b.path for b in blobs] == ["src/myapp/__init__.py", "src/myapp/main.py"]


def test_urunignore_applies(tmp_path):
    (tmp_path / ".urunignore").write_text("ignored.py\n")
    pkg = tmp_path / "pkg"
    pkg.mkdir()
    (pkg / "__init__.py").write_text("")
    (pkg / "main.py").write_text("")
    (pkg / "ignored.py").write_text("")
    blobs = auto_include(pkg / "main.py", tmp_path)
    assert [b.path for b in blobs] == ["pkg/__init__.py", "pkg/main.py"]
