from __future__ import annotations

import argparse

import pytest

from urun.cli import deploy, main, print_ready
from urun.errors import UrunError


def _args(**overrides):
    values = {
        "api_key": "urun_" + "a" * 32,
        "org_id": "org_test",
        "poll_interval": 1.0,
        "timeout": 10.0,
        "config": None,
        "entrypoint": "app.py",
        "module": None,
        "name": None,
        "api_url": "http://127.0.0.1:9",
        "no_wait": True,
    }
    values.update(overrides)
    return argparse.Namespace(**values)


@pytest.mark.parametrize(
    ("overrides", "message"),
    [
        ({"api_key": None}, "missing API key"),
        ({"api_key": "bad"}, "invalid API key"),
        ({"org_id": None}, "missing org id"),
        ({"org_id": "bad"}, "invalid org id"),
        ({"poll_interval": 0}, "poll-interval"),
        ({"timeout": 0}, "timeout"),
    ],
)
def test_deploy_validates_inputs_before_filesystem(overrides, message):
    with pytest.raises(UrunError, match=message):
        deploy(_args(**overrides))


def test_main_no_command_prints_help(capsys):
    assert main([]) == 2
    assert "usage: urun" in capsys.readouterr().out


def test_main_user_error_returns_one(capsys):
    assert main(["deploy", "app.py"]) == 1
    assert "missing API key" in capsys.readouterr().err


def test_main_keyboard_interrupt_returns_130(monkeypatch, capsys):
    def interrupt(_args):
        raise KeyboardInterrupt

    monkeypatch.setattr("urun.cli.deploy", interrupt)
    assert (
        main(["deploy", "app.py", "--api-key", "urun_" + "a" * 32, "--org-id", "org_test"]) == 130
    )
    assert "aborted" in capsys.readouterr().err


def test_deploy_uses_config_directory_as_project_root(tmp_path, monkeypatch):
    project = tmp_path / "project"
    project.mkdir()
    (project / "app.py").write_text("print('configured')\n")
    config = project / "urun.toml"
    config.write_text('[app]\nname = "configured"\nentrypoint = "app.py"\n')

    calls = {}

    class FakeClient:
        def __init__(self, api_url, api_key):
            calls["client"] = (api_url, api_key)

        def register_manifest(self, manifest):
            calls["manifest"] = manifest
            return {"manifest_hash": None, "missing_blobs": [], "status_url": "http://status"}

        def finalize(self, manifest_hash):
            calls["finalized"] = manifest_hash
            return {"status": "queued"}

    monkeypatch.setattr("urun.cli.ApiClient", FakeClient)
    monkeypatch.chdir(tmp_path)

    assert deploy(_args(config=config, entrypoint=None)) == 0
    assert calls["manifest"]["app_name"] == "configured"
    assert calls["manifest"]["files"][0]["path"] == "app.py"
    assert calls["client"] == ("http://127.0.0.1:9", "urun_" + "a" * 32)
    assert calls["finalized"]


def test_deploy_detects_server_manifest_hash_mismatch(tmp_path, monkeypatch):
    (tmp_path / "app.py").write_text("print('x')\n")

    class FakeClient:
        def __init__(self, *_args):
            pass

        def register_manifest(self, _manifest):
            return {"manifest_hash": "b" * 64, "missing_blobs": []}

    monkeypatch.setattr("urun.cli.ApiClient", FakeClient)
    monkeypatch.chdir(tmp_path)
    with pytest.raises(UrunError, match="server manifest hash mismatch"):
        deploy(_args())


def test_deploy_no_wait_prints_status_url(tmp_path, monkeypatch, capsys):
    (tmp_path / "app.py").write_text("print('x')\n")

    class FakeClient:
        def __init__(self, *_args):
            pass

        def register_manifest(self, _manifest):
            return {"missing_blobs": [], "status_url": "http://status.example/deploy"}

        def finalize(self, manifest_hash):
            return {"manifest_hash": manifest_hash, "status": "queued"}

    monkeypatch.setattr("urun.cli.ApiClient", FakeClient)
    monkeypatch.chdir(tmp_path)
    assert deploy(_args()) == 0
    assert "Status: http://status.example/deploy" in capsys.readouterr().out


def test_print_ready_includes_optional_url(capsys):
    print_ready({"status": "ready", "zerofs_path": "/mnt/app", "url": "https://app.example"})
    out = capsys.readouterr().out
    assert "Deployment ready" in out
    assert "ZeroFS: /mnt/app" in out
    assert "URL: https://app.example" in out
