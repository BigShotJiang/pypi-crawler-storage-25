from urun.config import parse_config
from urun.deps import resolve_deps


def test_parse_config_mounts():
    cfg = parse_config(
        {
            "app": {"name": "x", "entrypoint": "app.py", "python_version": "3.12"},
            "mounts": [{"local_path": "assets", "remote_path": "/app/assets"}],
            "deps": {"requirements": "req.txt"},
        }
    )
    assert cfg.app.name == "x"
    assert cfg.mounts[0].local_path == "assets"
    assert cfg.deps.requirements == "req.txt"


def test_resolve_requirements(tmp_path):
    (tmp_path / "requirements.txt").write_text("flask\n")
    cfg = parse_config({})
    deps, blob, py = resolve_deps(cfg, tmp_path)
    assert deps["kind"] == "requirements_txt"
    assert deps["blob_sha256"] == blob.sha256
    assert py == "3.12"


def test_resolve_pyproject_python_requires(tmp_path):
    (tmp_path / "pyproject.toml").write_text(
        '[project]\nrequires-python = ">=3.11"\ndependencies = ["flask"]\n'
    )
    cfg = parse_config({})
    deps, blob, py = resolve_deps(cfg, tmp_path)
    assert deps["kind"] == "pyproject_toml"
    assert py == "3.11"
