from __future__ import annotations

import json
import threading
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

from urun.cli import main
from urun.manifest import manifest_hash


class FakeEdgeState:
    def __init__(self):
        self.uploads: dict[str, bytes] = {}
        self.upload_auth_headers: list[str | None] = []
        self.finalized: list[str] = []
        self.manifests: dict[str, dict] = {}


def serve_fake_edge(state: FakeEdgeState):
    class Handler(BaseHTTPRequestHandler):
        def do_POST(self):
            if self.path == "/register-manifest":
                assert self.headers.get("Authorization") == "Bearer urun_" + "a" * 32
                body = self.rfile.read(int(self.headers.get("content-length", "0")))
                manifest = json.loads(body.decode())
                mh = manifest_hash(manifest)
                state.manifests[mh] = manifest
                shas = {f["sha256"] for f in manifest["files"]}
                for mount in manifest.get("mounts", []):
                    shas.update(f["sha256"] for f in mount["files"])
                if manifest.get("deps", {}).get("blob_sha256"):
                    shas.add(manifest["deps"]["blob_sha256"])
                self._json(
                    {
                        "manifest_hash": mh,
                        "missing_blobs": [
                            {
                                "sha256": sha,
                                "upload_url": f"http://{self.server.server_address[0]}:{self.server.server_address[1]}/upload/{sha}",
                                "expires_at": "2099-01-01T00:00:00Z",
                            }
                            for sha in sorted(shas)
                        ],
                        "status_url": f"http://fake/deployment-status/{mh}",
                    }
                )
                return
            if self.path.startswith("/finalize/"):
                mh = self.path.rsplit("/", 1)[1]
                missing = [
                    sha for sha in _manifest_shas(state.manifests[mh]) if sha not in state.uploads
                ]
                if missing:
                    self._json(
                        {"error": {"code": "missing_blobs", "message": ",".join(missing)}},
                        status=409,
                    )
                    return
                state.finalized.append(mh)
                self._json({"manifest_hash": mh, "status": "queued"})
                return
            self.send_error(404)

        def do_PUT(self):
            if self.path.startswith("/upload/"):
                sha = self.path.rsplit("/", 1)[1]
                state.upload_auth_headers.append(self.headers.get("Authorization"))
                state.uploads[sha] = self.rfile.read(int(self.headers.get("content-length", "0")))
                self.send_response(200)
                self.end_headers()
                return
            self.send_error(404)

        def do_GET(self):
            if self.path.startswith("/deployment-status/"):
                mh = self.path.rsplit("/", 1)[1]
                self._json(
                    {
                        "manifest_hash": mh,
                        "org_id": "org_test",
                        "app_name": state.manifests[mh]["app_name"],
                        "status": "ready",
                        "zerofs_path": f"/mounts/{mh}",
                        "replicas": 0,
                        "image_refs": [],
                        "error": None,
                    }
                )
                return
            self.send_error(404)

        def _json(self, payload, status=200):
            raw = json.dumps(payload).encode()
            self.send_response(status)
            self.send_header("content-type", "application/json")
            self.send_header("content-length", str(len(raw)))
            self.end_headers()
            self.wfile.write(raw)

        def log_message(self, *args):
            pass

    server = ThreadingHTTPServer(("127.0.0.1", 0), Handler)
    thread = threading.Thread(target=server.serve_forever, daemon=True)
    thread.start()
    return server


def _manifest_shas(manifest: dict) -> set[str]:
    shas = {f["sha256"] for f in manifest["files"]}
    for mount in manifest.get("mounts", []):
        shas.update(f["sha256"] for f in mount["files"])
    if manifest.get("deps", {}).get("blob_sha256"):
        shas.add(manifest["deps"]["blob_sha256"])
    return shas


def test_deploy_happy_path_against_fake_edge(tmp_path, monkeypatch):
    (tmp_path / "app.py").write_text("print('hello')\n")
    state = FakeEdgeState()
    server = serve_fake_edge(state)
    monkeypatch.chdir(tmp_path)

    code = main(
        [
            "deploy",
            "app.py",
            "--api-url",
            f"http://127.0.0.1:{server.server_address[1]}",
            "--api-key",
            "urun_" + "a" * 32,
            "--org-id",
            "org_test",
            "--poll-interval",
            "0.01",
        ]
    )

    server.shutdown()
    assert code == 0
    assert len(state.finalized) == 1
    assert len(state.uploads) == 1
    assert state.upload_auth_headers == [None]
    assert next(iter(state.uploads.values())) == b"print('hello')\n"


def test_deploy_failed_status_exits_nonzero(tmp_path, monkeypatch):
    (tmp_path / "app.py").write_text("print('hello')\n")

    class FailedStatusHandler(BaseHTTPRequestHandler):
        manifest = None
        mh = None

        def do_POST(self):
            if self.path == "/register-manifest":
                body = self.rfile.read(int(self.headers.get("content-length", "0")))
                self.__class__.manifest = json.loads(body.decode())
                self.__class__.mh = manifest_hash(self.__class__.manifest)
                self._json(
                    {"manifest_hash": self.__class__.mh, "missing_blobs": [], "status_url": ""}
                )
                return
            if self.path.startswith("/finalize/"):
                self._json({"manifest_hash": self.__class__.mh, "status": "queued"})
                return
            self.send_error(404)

        def do_GET(self):
            self._json(
                {
                    "manifest_hash": self.__class__.mh,
                    "status": "failed",
                    "error": {"code": "deps_install_failed", "message": "pip failed"},
                }
            )

        def _json(self, payload, status=200):
            raw = json.dumps(payload).encode()
            self.send_response(status)
            self.send_header("content-type", "application/json")
            self.send_header("content-length", str(len(raw)))
            self.end_headers()
            self.wfile.write(raw)

        def log_message(self, *args):
            pass

    server = ThreadingHTTPServer(("127.0.0.1", 0), FailedStatusHandler)
    thread = threading.Thread(target=server.serve_forever, daemon=True)
    thread.start()
    monkeypatch.chdir(tmp_path)

    code = main(
        [
            "deploy",
            "app.py",
            "--api-url",
            f"http://127.0.0.1:{server.server_address[1]}",
            "--api-key",
            "urun_" + "a" * 32,
            "--org-id",
            "org_test",
            "--poll-interval",
            "0.01",
        ]
    )

    server.shutdown()
    assert code == 1
