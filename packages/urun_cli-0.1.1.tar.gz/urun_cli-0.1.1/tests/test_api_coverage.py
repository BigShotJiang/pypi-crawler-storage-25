from __future__ import annotations

import json
import threading
import urllib.error
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

import pytest

from urun.api import ApiClient, poll_until_done, upload_blob, upload_missing_blobs
from urun.errors import ApiError, UrunError
from urun.manifest import file_blob


def _serve(handler_cls):
    server = ThreadingHTTPServer(("127.0.0.1", 0), handler_cls)
    threading.Thread(target=server.serve_forever, daemon=True).start()
    return server


def test_api_retries_transient_http_error(monkeypatch):
    monkeypatch.setattr("urun.api.time.sleep", lambda _seconds: None)

    class Handler(BaseHTTPRequestHandler):
        attempts = 0

        def do_GET(self):
            self.__class__.attempts += 1
            if self.__class__.attempts == 1:
                raw = json.dumps({"error": {"code": "busy", "message": "try again"}}).encode()
                self.send_response(503)
                self.send_header("content-length", str(len(raw)))
                self.end_headers()
                self.wfile.write(raw)
                return
            raw = json.dumps({"status": "ready"}).encode()
            self.send_response(200)
            self.send_header("content-length", str(len(raw)))
            self.end_headers()
            self.wfile.write(raw)

        def log_message(self, *args):
            pass

    server = _serve(Handler)
    try:
        client = ApiClient(f"http://127.0.0.1:{server.server_address[1]}", "urun_" + "a" * 32)
        assert client.deployment_status("a" * 64) == {"status": "ready"}
        assert Handler.attempts == 2
    finally:
        server.shutdown()


def test_api_empty_json_body_returns_empty_dict():
    class Handler(BaseHTTPRequestHandler):
        def do_POST(self):
            self.send_response(204)
            self.send_header("content-length", "0")
            self.end_headers()

        def log_message(self, *args):
            pass

    server = _serve(Handler)
    try:
        client = ApiClient(f"http://127.0.0.1:{server.server_address[1]}", "urun_" + "a" * 32)
        assert client.finalize("a" * 64) == {}
    finally:
        server.shutdown()


def test_api_network_error_is_user_facing(monkeypatch):
    def fail(*_args, **_kwargs):
        raise urllib.error.URLError("offline")

    monkeypatch.setattr("urun.api.urllib.request.urlopen", fail)
    monkeypatch.setattr("urun.api.time.sleep", lambda _seconds: None)
    client = ApiClient("http://127.0.0.1:9", "urun_" + "a" * 32, attempts=1)
    with pytest.raises(UrunError, match="network error"):
        client.deployment_status("a" * 64)


def test_upload_missing_rejects_bad_concurrency_and_non_dict(tmp_path):
    with pytest.raises(UrunError, match="at least 1"):
        upload_missing_blobs(
            [{"sha256": "a" * 64, "upload_url": "http://example.invalid"}], {}, concurrency=0
        )

    p = tmp_path / "app.py"
    p.write_text("print(1)\n")
    blob = file_blob(p, tmp_path)
    with pytest.raises(UrunError, match="invalid missing_blobs"):
        upload_missing_blobs(["bad"], {blob.sha256: blob})


def test_upload_missing_deduplicates_duplicate_server_items(tmp_path, monkeypatch):
    p = tmp_path / "app.py"
    p.write_text("print(1)\n")
    blob = file_blob(p, tmp_path)
    calls = []

    def fake_upload(url, uploaded_blob):
        calls.append((url, uploaded_blob.sha256))

    monkeypatch.setattr("urun.api.upload_blob", fake_upload)
    upload_missing_blobs(
        [
            {"sha256": blob.sha256, "upload_url": "http://example.invalid/one"},
            {"sha256": blob.sha256, "upload_url": "http://example.invalid/two"},
        ],
        {blob.sha256: blob},
    )
    assert calls == [("http://example.invalid/one", blob.sha256)]


def test_upload_blob_treats_precondition_failed_as_already_uploaded(tmp_path):
    p = tmp_path / "app.py"
    p.write_text("print(1)\n")
    blob = file_blob(p, tmp_path)

    class Handler(BaseHTTPRequestHandler):
        def do_PUT(self):
            self.send_response(412)
            self.end_headers()

        def log_message(self, *args):
            pass

    server = _serve(Handler)
    try:
        upload_blob(f"http://127.0.0.1:{server.server_address[1]}/blob", blob)
    finally:
        server.shutdown()


def test_upload_blob_retries_transient_put_failure(tmp_path, monkeypatch):
    monkeypatch.setattr("urun.api.time.sleep", lambda _seconds: None)
    p = tmp_path / "app.py"
    p.write_text("print(1)\n")
    blob = file_blob(p, tmp_path)

    class Handler(BaseHTTPRequestHandler):
        attempts = 0

        def do_PUT(self):
            self.__class__.attempts += 1
            if self.__class__.attempts == 1:
                self.send_response(500)
                self.end_headers()
                return
            self.send_response(200)
            self.end_headers()

        def log_message(self, *args):
            pass

    server = _serve(Handler)
    try:
        upload_blob(f"http://127.0.0.1:{server.server_address[1]}/blob", blob)
        assert Handler.attempts == 2
    finally:
        server.shutdown()


class _PollClient:
    def __init__(self, responses):
        self.responses = list(responses)

    def deployment_status(self, _manifest_hash):
        response = self.responses.pop(0)
        if isinstance(response, Exception):
            raise response
        return response


def test_poll_until_done_tolerates_initial_404(monkeypatch):
    monkeypatch.setattr("urun.api.time.sleep", lambda _seconds: None)
    client = _PollClient([ApiError(404, "not_found", "not yet"), {"status": "ready"}])
    assert poll_until_done(client, "a" * 64, interval=0.01, timeout=1)["status"] == "ready"


def test_poll_until_done_times_out(monkeypatch):
    times = iter([0.0, 0.0, 0.2, 0.2])
    monkeypatch.setattr("urun.api.time.time", lambda: next(times))
    monkeypatch.setattr("urun.api.time.sleep", lambda _seconds: None)
    client = _PollClient([{"status": "building"}])
    with pytest.raises(UrunError, match="timed out"):
        poll_until_done(client, "a" * 64, interval=0.01, timeout=0.1)
