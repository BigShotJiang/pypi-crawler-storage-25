from __future__ import annotations

import pytest

from urun.config import parse_config
from urun.deps import python_from_requires, resolve_deps
from urun.errors import UrunError


def test_configured_requirements_take_precedence_and_python_version(tmp_path):
    (tmp_path / "req.txt").write_text("flask\n")
    (tmp_path / "pyproject.toml").write_text('[project]\nrequires-python = ">=3.11"\n')
    cfg = parse_config({"app": {"python_version": "3.12"}, "deps": {"requirements": "req.txt"}})
    deps, blob, py = resolve_deps(cfg, tmp_path)
    assert deps["kind"] == "requirements_txt"
    assert blob is not None
    assert blob.path == "req.txt"
    assert py == "3.12"


def test_configured_requirements_must_exist(tmp_path):
    cfg = parse_config({"deps": {"requirements": "missing.txt"}})
    with pytest.raises(UrunError, match="requirements file not found"):
        resolve_deps(cfg, tmp_path)


def test_invalid_pyproject_toml_is_user_error(tmp_path):
    (tmp_path / "pyproject.toml").write_text("[project\n")
    with pytest.raises(UrunError, match="Invalid TOML"):
        resolve_deps(parse_config({}), tmp_path)


def test_dependency_files_reject_embedded_credential_urls(tmp_path):
    (tmp_path / "requirements.txt").write_text(
        "private @ https://user:token@example.invalid/pkg.whl\n"
    )
    with pytest.raises(UrunError, match="embedded credential URL"):
        resolve_deps(parse_config({}), tmp_path)


def test_no_deps_returns_none(tmp_path):
    deps, blob, py = resolve_deps(parse_config({}), tmp_path)
    assert deps == {"kind": "none", "python_version": "3.12"}
    assert blob is None
    assert py == "3.12"


def test_python_from_requires_common_cases():
    assert python_from_requires(">=3.11") == "3.11"
    assert python_from_requires("no version here") is None
