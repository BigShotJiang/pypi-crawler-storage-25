from __future__ import annotations

import sys

import pytest

from urun.config import MountConfig, UrunConfig
from urun.discovery import (
    auto_include,
    derive_app_name,
    discover_main_files,
    discover_mounts,
    ensure_project_on_path,
    ensure_under_root,
    is_ignored,
    load_urunignore,
    package_root_for,
)
from urun.errors import UrunError


def test_derive_app_name_special_cases():
    assert derive_app_name("pkg/__main__.py", None) == "pkg"
    with pytest.raises(UrunError, match="missing entrypoint"):
        derive_app_name(None, None)


def test_package_root_for_nested_package(tmp_path):
    pkg = tmp_path / "pkg"
    sub = pkg / "sub"
    sub.mkdir(parents=True)
    (pkg / "__init__.py").write_text("")
    (sub / "__init__.py").write_text("")
    entry = sub / "main.py"
    entry.write_text("")
    assert package_root_for(entry) == pkg


def test_load_urunignore_strips_comments_and_blank_lines(tmp_path):
    (tmp_path / ".urunignore").write_text("\n# comment\nignored.py\n  *.tmp  \n")
    assert load_urunignore(tmp_path) == ["ignored.py", "*.tmp"]


def test_is_ignored_defaults_and_outside_root(tmp_path):
    assert is_ignored(tmp_path / "__pycache__" / "x.py", tmp_path, []) is True
    assert is_ignored(tmp_path / ".git" / "config", tmp_path, []) is True
    assert is_ignored(tmp_path / ".env", tmp_path, []) is True
    assert is_ignored(tmp_path / "x.pyc", tmp_path, []) is True
    with pytest.raises(UrunError, match="outside the project root"):
        is_ignored(tmp_path.parent / "outside.py", tmp_path, [])


def test_auto_include_rejects_missing_non_py_and_ignored_entrypoint(tmp_path):
    with pytest.raises(UrunError, match="entrypoint not found"):
        auto_include(tmp_path / "missing.py", tmp_path)

    text = tmp_path / "app.txt"
    text.write_text("not python")
    with pytest.raises(UrunError, match="must be a .py"):
        auto_include(text, tmp_path)

    hidden = tmp_path / ".hidden.py"
    hidden.write_text("print(1)\n")
    with pytest.raises(UrunError, match="entrypoint is ignored"):
        auto_include(hidden, tmp_path)


def test_auto_include_package_size_limit(tmp_path, monkeypatch):
    pkg = tmp_path / "pkg"
    pkg.mkdir()
    (pkg / "__init__.py").write_text("")
    entry = pkg / "main.py"
    entry.write_text("print(1)\n")
    monkeypatch.setattr("urun.discovery.MAX_AUTO_INCLUDE_BYTES", 1)
    with pytest.raises(UrunError, match="above 50 MB"):
        auto_include(entry, tmp_path)


def test_discover_main_files_from_config_entrypoint_and_module(tmp_path, monkeypatch):
    (tmp_path / "app.py").write_text("print(1)\n")
    entrypoint, files = discover_main_files(UrunConfig(), "app.py", None, tmp_path)
    assert entrypoint == "app.py"
    assert [f.path for f in files] == ["app.py"]

    pkg = tmp_path / "pkg"
    pkg.mkdir()
    (pkg / "__init__.py").write_text("")
    (pkg / "main.py").write_text("print(1)\n")
    monkeypatch.syspath_prepend(str(tmp_path))
    entrypoint, files = discover_main_files(UrunConfig(), None, "pkg.main", tmp_path)
    assert entrypoint == "pkg.main"
    assert [f.path for f in files] == ["pkg/__init__.py", "pkg/main.py"]


def test_discover_main_files_errors(tmp_path):
    with pytest.raises(UrunError, match="provide an entrypoint"):
        discover_main_files(UrunConfig(), None, None, tmp_path)
    with pytest.raises(UrunError, match="module not found"):
        discover_main_files(UrunConfig(), None, "does_not_exist_urun", tmp_path)


def test_discover_mounts_local_file_local_path_and_duplicates(tmp_path):
    (tmp_path / "file.txt").write_text("file")
    assets = tmp_path / "assets"
    assets.mkdir()
    (assets / "a.txt").write_text("asset")
    mounts, blobs = discover_mounts(
        [
            MountConfig(local_file="file.txt", remote_path="/app/file.txt"),
            MountConfig(local_path="assets", remote_path="/app/assets"),
        ],
        tmp_path,
    )
    assert [m["remote_path"] for m in mounts] == ["/app/file.txt", "/app/assets"]
    assert sorted(b.path for b in blobs) == ["a.txt", "file.txt"]

    with pytest.raises(UrunError, match="duplicate mount"):
        discover_mounts(
            [
                MountConfig(local_file="file.txt", remote_path="/same"),
                MountConfig(local_file="file.txt", remote_path="/same"),
            ],
            tmp_path,
        )


def test_discover_mounts_python_source_package_and_module(tmp_path, monkeypatch):
    pkg = tmp_path / "mountpkg"
    pkg.mkdir()
    (pkg / "__init__.py").write_text("")
    (pkg / "data.py").write_text("x = 1\n")
    (tmp_path / "single_mount.py").write_text("x = 2\n")
    monkeypatch.syspath_prepend(str(tmp_path))

    mounts, blobs = discover_mounts(
        [MountConfig(python_source="mountpkg", remote_path="/pkg")],
        tmp_path,
    )
    assert [m["remote_path"] for m in mounts] == ["/pkg"]
    assert sorted(b.path for b in blobs) == ["__init__.py", "data.py"]

    with pytest.raises(UrunError, match="mount directory not found"):
        discover_mounts(
            [MountConfig(python_source="single_mount", remote_path="/single")],
            tmp_path,
        )


def test_discover_mounts_errors(tmp_path):
    with pytest.raises(UrunError, match="mount file not found"):
        discover_mounts([MountConfig(local_file="missing.txt", remote_path="/missing")], tmp_path)
    with pytest.raises(UrunError, match="mount directory not found"):
        discover_mounts([MountConfig(local_path="missing", remote_path="/missing")], tmp_path)
    with pytest.raises(UrunError, match="python_source not found"):
        discover_mounts([MountConfig(python_source="nope", remote_path="/nope")], tmp_path)
    with pytest.raises(UrunError, match="invalid mount source"):
        discover_mounts([MountConfig(remote_path="/bad")], tmp_path)


def test_ensure_project_on_path_adds_project_and_src(tmp_path, monkeypatch):
    src = tmp_path / "src"
    src.mkdir()
    old_path = list(sys.path)
    monkeypatch.setattr(sys, "path", [])
    ensure_project_on_path(tmp_path)
    assert str(tmp_path.resolve()) in sys.path
    assert str(src.resolve()) in sys.path
    monkeypatch.setattr(sys, "path", old_path)


def test_ensure_under_root_rejects_escape(tmp_path):
    outside = tmp_path.parent / "outside.txt"
    outside.write_text("x")
    with pytest.raises(UrunError, match="outside the project root"):
        ensure_under_root(outside, tmp_path, "test")
