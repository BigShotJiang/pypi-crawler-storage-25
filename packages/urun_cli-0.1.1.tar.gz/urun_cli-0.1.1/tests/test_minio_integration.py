from __future__ import annotations

import json
import os
import threading
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from typing import Any

import pytest

from urun.cli import main
from urun.manifest import manifest_hash

pytestmark = pytest.mark.minio


def _minio_configured() -> bool:
    return bool(os.getenv("URUN_TEST_MINIO_ENDPOINT"))


def _minio_client_and_bucket():
    from minio import Minio

    endpoint = os.environ["URUN_TEST_MINIO_ENDPOINT"]
    access_key = os.getenv("URUN_TEST_MINIO_ACCESS_KEY", "minioadmin")
    secret_key = os.getenv("URUN_TEST_MINIO_SECRET_KEY", "minioadmin")
    bucket = os.getenv("URUN_TEST_MINIO_BUCKET", "urun-cli-test")
    secure = os.getenv("URUN_TEST_MINIO_SECURE", "0") == "1"

    client = Minio(endpoint, access_key=access_key, secret_key=secret_key, secure=secure)
    if not client.bucket_exists(bucket):
        client.make_bucket(bucket)
    return client, bucket


class MinioEdgeState:
    def __init__(self):
        self.manifests: dict[str, dict[str, Any]] = {}
        self.blob_keys: set[str] = set()
        self.missing_counts: list[int] = []
        self.finalized: list[str] = []
        self.status_polls = 0


def _manifest_shas(manifest: dict[str, Any]) -> set[str]:
    shas = {f["sha256"] for f in manifest.get("files", [])}
    for mount in manifest.get("mounts", []):
        shas.update(f["sha256"] for f in mount.get("files", []))
    deps_sha = manifest.get("deps", {}).get("blob_sha256")
    if deps_sha:
        shas.add(deps_sha)
    return shas


def _serve_minio_edge(client, bucket: str, state: MinioEdgeState):
    from minio.error import S3Error

    class MinioEdgeHandler(BaseHTTPRequestHandler):
        def do_POST(self):
            if self.path == "/register-manifest":
                body = self.rfile.read(int(self.headers.get("content-length", "0")))
                manifest = json.loads(body.decode())
                mh = manifest_hash(manifest)
                state.manifests[mh] = manifest
                missing = []
                for sha in sorted(_manifest_shas(manifest)):
                    key = f"{manifest['org_id']}/blobs/{sha}"
                    state.blob_keys.add(key)
                    try:
                        client.stat_object(bucket, key)
                    except S3Error as exc:
                        if exc.code != "NoSuchKey":
                            raise
                        missing.append(
                            {
                                "sha256": sha,
                                "upload_url": client.presigned_put_object(bucket, key),
                                "expires_at": "2099-01-01T00:00:00Z",
                            }
                        )
                state.missing_counts.append(len(missing))
                self._json(
                    {
                        "manifest_hash": mh,
                        "missing_blobs": missing,
                        "status_url": f"/deployment-status/{mh}",
                    }
                )
                return
            if self.path.startswith("/finalize/"):
                mh = self.path.rsplit("/", 1)[1]
                manifest = state.manifests[mh]
                for sha in _manifest_shas(manifest):
                    client.stat_object(bucket, f"{manifest['org_id']}/blobs/{sha}")
                state.finalized.append(mh)
                self._json({"manifest_hash": mh, "status": "queued"})
                return
            self.send_error(404)

        def do_GET(self):
            if self.path.startswith("/deployment-status/"):
                state.status_polls += 1
                mh = self.path.rsplit("/", 1)[1]
                self._json(
                    {
                        "manifest_hash": mh,
                        "status": "ready",
                        "zerofs_path": f"/mounts/{mh}",
                        "error": None,
                    }
                )
                return
            self.send_error(404)

        def _json(self, payload, status=200):
            raw = json.dumps(payload).encode()
            self.send_response(status)
            self.send_header("content-type", "application/json")
            self.send_header("content-length", str(len(raw)))
            self.end_headers()
            self.wfile.write(raw)

        def log_message(self, *args):
            pass

    server = ThreadingHTTPServer(("127.0.0.1", 0), MinioEdgeHandler)
    thread = threading.Thread(target=server.serve_forever, daemon=True)
    thread.start()
    return server


def _deploy(tmp_path, monkeypatch, server, *extra_args: str) -> int:
    monkeypatch.chdir(tmp_path)
    return main(
        [
            "deploy",
            "app.py",
            "--api-url",
            f"http://127.0.0.1:{server.server_address[1]}",
            "--api-key",
            "urun_" + "a" * 32,
            "--org-id",
            "org_minio",
            "--poll-interval",
            "0.01",
            *extra_args,
        ]
    )


def _read_object(client, bucket: str, key: str) -> bytes:
    obj = client.get_object(bucket, key)
    try:
        return obj.read()
    finally:
        obj.close()
        obj.release_conn()


def _cleanup(client, bucket: str, keys: set[str]) -> None:
    for key in keys:
        try:
            client.remove_object(bucket, key)
        except Exception:
            pass


@pytest.mark.skipif(
    not _minio_configured(),
    reason="set URUN_TEST_MINIO_ENDPOINT to run local MinIO integration tests",
)
def test_cli_uploads_to_local_minio_via_presigned_urls(tmp_path, monkeypatch):
    client, bucket = _minio_client_and_bucket()
    state = MinioEdgeState()
    server = _serve_minio_edge(client, bucket, state)
    (tmp_path / "app.py").write_text("print('minio')\n")

    try:
        assert _deploy(tmp_path, monkeypatch, server) == 0
        assert state.missing_counts == [1]
        assert state.status_polls == 1
        key = next(iter(state.blob_keys))
        assert _read_object(client, bucket, key) == b"print('minio')\n"
    finally:
        server.shutdown()
        _cleanup(client, bucket, state.blob_keys)


@pytest.mark.skipif(
    not _minio_configured(),
    reason="set URUN_TEST_MINIO_ENDPOINT to run local MinIO integration tests",
)
def test_repeated_minio_deploy_reuses_existing_content_addressed_blob(tmp_path, monkeypatch):
    client, bucket = _minio_client_and_bucket()
    state = MinioEdgeState()
    server = _serve_minio_edge(client, bucket, state)
    (tmp_path / "app.py").write_text("print('dedup')\n")

    try:
        assert _deploy(tmp_path, monkeypatch, server) == 0
        assert _deploy(tmp_path, monkeypatch, server) == 0
        assert state.missing_counts == [1, 0]
        assert len(state.finalized) == 2
    finally:
        server.shutdown()
        _cleanup(client, bucket, state.blob_keys)


@pytest.mark.skipif(
    not _minio_configured(),
    reason="set URUN_TEST_MINIO_ENDPOINT to run local MinIO integration tests",
)
def test_minio_deploy_uploads_dependency_blob(tmp_path, monkeypatch):
    client, bucket = _minio_client_and_bucket()
    state = MinioEdgeState()
    server = _serve_minio_edge(client, bucket, state)
    (tmp_path / "app.py").write_text("print('deps')\n")
    (tmp_path / "requirements.txt").write_text("requests==2.32.0\n")

    try:
        assert _deploy(tmp_path, monkeypatch, server) == 0
        assert state.missing_counts == [2]
        uploaded = {_read_object(client, bucket, key) for key in state.blob_keys}
        assert b"print('deps')\n" in uploaded
        assert b"requests==2.32.0\n" in uploaded
    finally:
        server.shutdown()
        _cleanup(client, bucket, state.blob_keys)


@pytest.mark.skipif(
    not _minio_configured(),
    reason="set URUN_TEST_MINIO_ENDPOINT to run local MinIO integration tests",
)
def test_minio_no_wait_finalizes_without_status_polling(tmp_path, monkeypatch):
    client, bucket = _minio_client_and_bucket()
    state = MinioEdgeState()
    server = _serve_minio_edge(client, bucket, state)
    (tmp_path / "app.py").write_text("print('no wait')\n")

    try:
        assert _deploy(tmp_path, monkeypatch, server, "--no-wait") == 0
        assert len(state.finalized) == 1
        assert state.status_polls == 0
    finally:
        server.shutdown()
        _cleanup(client, bucket, state.blob_keys)
