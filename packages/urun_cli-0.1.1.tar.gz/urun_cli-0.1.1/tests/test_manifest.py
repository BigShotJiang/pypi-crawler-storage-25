from urun.manifest import canonical_json, file_blob, manifest_hash


def test_canonical_json_sorted_compact():
    assert canonical_json({"b": 1, "a": 2}) == b'{"a":2,"b":1}'


def test_manifest_hash_omits_manifest_hash_field():
    m = {"version": 1, "files": [], "manifest_hash": "ignored"}
    assert manifest_hash(m) == manifest_hash({"version": 1, "files": []})


def test_file_blob_hash_and_mode(tmp_path):
    p = tmp_path / "app.py"
    p.write_text("print('hi')\n")
    blob = file_blob(p, tmp_path)
    assert blob.path == "app.py"
    assert blob.size == len("print('hi')\n")
    assert blob.mode == 0o100644
    assert len(blob.sha256) == 64
