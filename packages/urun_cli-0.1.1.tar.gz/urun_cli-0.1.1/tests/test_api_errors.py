from __future__ import annotations

import json
import threading
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

from urun.api import ApiClient, upload_missing_blobs
from urun.errors import ApiError, UrunError
from urun.manifest import file_blob


def _serve(handler_cls):
    server = ThreadingHTTPServer(("127.0.0.1", 0), handler_cls)
    threading.Thread(target=server.serve_forever, daemon=True).start()
    return server


def test_api_error_codes_are_preserved():
    class Handler(BaseHTTPRequestHandler):
        def do_POST(self):
            raw = json.dumps({"error": {"code": "unauthorized", "message": "invalid key"}}).encode()
            self.send_response(401)
            self.send_header("content-type", "application/json")
            self.send_header("content-length", str(len(raw)))
            self.end_headers()
            self.wfile.write(raw)

        def log_message(self, *args):
            pass

    server = _serve(Handler)
    try:
        client = ApiClient(f"http://127.0.0.1:{server.server_address[1]}", "urun_" + "a" * 32)
        try:
            client.register_manifest({})
        except ApiError as exc:
            assert exc.status == 401
            assert exc.code == "unauthorized"
            assert exc.message == "invalid key"
        else:
            raise AssertionError("expected ApiError")
    finally:
        server.shutdown()


def test_invalid_json_response_is_user_facing_error():
    class Handler(BaseHTTPRequestHandler):
        def do_GET(self):
            raw = b"not json"
            self.send_response(200)
            self.send_header("content-length", str(len(raw)))
            self.end_headers()
            self.wfile.write(raw)

        def log_message(self, *args):
            pass

    server = _serve(Handler)
    try:
        client = ApiClient(f"http://127.0.0.1:{server.server_address[1]}", "urun_" + "a" * 32)
        try:
            client.deployment_status("a" * 64)
        except UrunError as exc:
            assert "invalid JSON" in str(exc)
        else:
            raise AssertionError("expected UrunError")
    finally:
        server.shutdown()


def test_invalid_missing_blobs_shape_is_user_facing_error(tmp_path):
    p = tmp_path / "app.py"
    p.write_text("print(1)\n")
    blob = file_blob(p, tmp_path)
    try:
        upload_missing_blobs([{"sha256": blob.sha256}], {blob.sha256: blob})
    except UrunError as exc:
        assert "invalid missing_blobs" in str(exc)
    else:
        raise AssertionError("expected UrunError")


def test_upload_rejects_file_changed_after_manifest(tmp_path):
    p = tmp_path / "app.py"
    p.write_text("print(1)\n")
    blob = file_blob(p, tmp_path)
    p.write_text("print(2)\n")
    try:
        upload_missing_blobs(
            [{"sha256": blob.sha256, "upload_url": "http://127.0.0.1:1/upload"}],
            {blob.sha256: blob},
        )
    except UrunError as exc:
        assert "file changed" in str(exc)
    else:
        raise AssertionError("expected UrunError")
