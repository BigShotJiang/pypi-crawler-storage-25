from urun.api import upload_missing_blobs
from urun.errors import UrunError
from urun.manifest import file_blob


def test_upload_missing_unknown_sha(tmp_path):
    p = tmp_path / "a.txt"
    p.write_text("a")
    blob = file_blob(p, tmp_path)
    try:
        upload_missing_blobs(
            [{"sha256": "b" * 64, "upload_url": "http://example.invalid"}], {blob.sha256: blob}
        )
    except UrunError as exc:
        assert "unknown blob" in str(exc)
    else:
        raise AssertionError("expected UrunError")
