from __future__ import annotations

from urun.config import MountConfig, UrunConfig, parse_config
from urun.deps import resolve_deps
from urun.discovery import discover_main_files, discover_mounts
from urun.errors import UrunError


def test_config_path_directory_is_project_root(tmp_path, monkeypatch):
    project = tmp_path / "project"
    project.mkdir()
    (project / "app.py").write_text("print(1)\n")
    (project / "urun.toml").write_text('[app]\nentrypoint = "app.py"\n')
    monkeypatch.chdir(tmp_path)

    assert (
        discover_main_files(parse_config({"app": {"entrypoint": "app.py"}}), None, None, project)[0]
        == "app.py"
    )


def test_module_discovery_supports_src_layout(tmp_path, monkeypatch):
    pkg = tmp_path / "src" / "myapp"
    pkg.mkdir(parents=True)
    (pkg / "__init__.py").write_text("")
    (pkg / "main.py").write_text("print(1)\n")
    monkeypatch.syspath_prepend(str(tmp_path))

    entrypoint, blobs = discover_main_files(UrunConfig(), None, "myapp.main", tmp_path)

    assert entrypoint == "myapp.main"
    assert [b.path for b in blobs] == ["src/myapp/__init__.py", "src/myapp/main.py"]


def test_local_mounts_must_stay_under_project_root(tmp_path):
    outside = tmp_path.parent / "outside_assets"
    outside.mkdir(exist_ok=True)
    mounts = [MountConfig(local_path="../outside_assets", remote_path="/app/assets")]

    try:
        discover_mounts(mounts, tmp_path)
    except UrunError as exc:
        assert "outside the project root" in str(exc)
    else:
        raise AssertionError("expected UrunError")


def test_requirements_path_must_stay_under_project_root(tmp_path):
    outside = tmp_path.parent / "secret-requirements.txt"
    outside.write_text("private @ https://user:token@example.invalid/pkg.whl\n")
    cfg = parse_config({"deps": {"requirements": "../secret-requirements.txt"}})

    try:
        resolve_deps(cfg, tmp_path)
    except UrunError as exc:
        assert "outside the project root" in str(exc)
    else:
        raise AssertionError("expected UrunError")
