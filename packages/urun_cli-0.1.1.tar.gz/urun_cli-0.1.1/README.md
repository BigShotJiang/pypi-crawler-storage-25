# urun CLI

End-user command line client for deploying Python apps to urun.

## Install

```bash
uv tool install urun-cli
# or
pip install urun-cli
```

The installed executable is still `urun`:

```bash
urun --version
```

PyPI does not allow the distribution name `urun`, so ephemeral uv runs need the
package name explicitly:

```bash
uvx --from urun-cli urun --version
# or use the package-matching alias
uvx urun-cli --version
```

## Deploy

```bash
export URUN_API_KEY=urun_<32hex>
export URUN_ORG_ID=org_...  # bootstrap-era requirement for v1 manifests
urun deploy app.py
```

## Development with uv / Nix

This repo includes `flake.nix` and `.envrc` for a reproducible dev shell with uv,
Python 3.12, Dagger, actionlint, and pre-commit.

```bash
direnv allow  # optional, if you use direnv/nix
uv sync
uv run pytest
uv run urun --version
uv build
```

CI uses the same centralized Dagger pre-commit pipeline pattern as `urun`:
`precommit.yaml` checks out `urun-sh/dagger-pipeline` and runs `recipes.precommit`.
Normal `ci` remains self-contained and runs on public/fork PRs.

Optional local MinIO integration test:

```bash
docker compose -f compose.minio.yml up -d
URUN_TEST_MINIO_ENDPOINT=127.0.0.1:9000 \
URUN_TEST_MINIO_ACCESS_KEY=minioadmin \
URUN_TEST_MINIO_SECRET_KEY=minioadmin \
uv run pytest -q -m minio
```

See `SPEC_TRACKING.md` for spec coverage and remaining gaps.

## Configuration

Configuration is read from `urun.toml` when present. CLI flags override config values.

```toml
[app]
name = "my-app"
entrypoint = "src/myapp/main.py"
python_version = "3.12"

[[mounts]]
local_path = "./assets"
remote_path = "/app/assets"

[deps]
requirements = "requirements.txt"
```

Common options:

| Option | Description |
| --- | --- |
| `-m, --module` | Deploy a Python module entrypoint, e.g. `myapp.main`. |
| `--name` | Override the derived app name. |
| `--config` | Use a specific `urun.toml`; relative paths resolve from its directory. |
| `--api-url` | Override the API URL. |
| `--api-key` | API key; prefer `URUN_API_KEY` for shell history safety. |
| `--org-id` | Bootstrap-era org ID required in v1 manifests. |
| `--no-wait` | Finalize but do not poll for readiness. |
| `--poll-interval`, `--timeout` | Control readiness polling. |

## Troubleshooting

| Error | Fix |
| --- | --- |
| `missing API key` | Set `URUN_API_KEY` or pass `--api-key`. |
| `invalid API key format` | Use `urun_<32 lowercase hex chars>`. |
| `missing org id` | Set `URUN_ORG_ID` while v1 bootstrap is manual. |
| `entrypoint not found` | Run from the project root or pass `--config`. |
| `path is outside the project root` | Move the file under the project or adjust `urun.toml`. |

## License

MIT. Local MinIO is used only as an optional S3-compatible test service.
