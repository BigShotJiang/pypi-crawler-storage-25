# urun CLI spec tracking

Status snapshot for the end-user CLI portion of `SPEC.md`.

## Implemented

- `urun deploy <entrypoint>` and `urun deploy -m <module>` CLI shape.
- `--name`, `--config`, `--api-url`, `--api-key`, `--org-id`, `--no-wait` flags.
- `urun.toml` parsing for `[app]`, `[[mounts]]`, and `[deps]`.
- CLI flags override config fields where applicable.
- App-name derivation for file and module entrypoints.
- Auto-include rules:
  - package discovery via `__init__.py` walk-up,
  - standalone file include,
  - Python files only for package auto-include,
  - excludes `__pycache__`, `.git`, dotfiles, `*.pyc`, `.urunignore`,
  - 50 MB package auto-include limit.
- Dependency resolution order:
  - `urun.toml [deps].requirements`,
  - `pyproject.toml`,
  - `requirements.txt`,
  - none.
- Default Python version `3.12`.
- SHA-256 file hashing, file size, and normalized POSIX mode bits.
- Canonical JSON manifest hashing with `manifest_hash` omitted.
- HTTP flow:
  - `POST /register-manifest`,
  - bounded-concurrency blob upload default `8`,
  - `POST /finalize/:manifest_hash`,
  - poll `GET /deployment-status/:manifest_hash`,
  - non-zero exit on failed deployment/API errors.
- uv-based development workflow.
- CI aligned with urun's centralized Dagger pre-commit workflow (`.dagger-pipeline.yaml` + `.github/workflows/precommit.yaml`).
- Hardening for malformed API keys/org IDs, out-of-project paths, duplicate mount remote paths, transient status 404 grace, and presigned upload retries.

## Tested

Run with:

```bash
uv sync
uv run pytest
```

Current tests cover:

- Manifest canonical JSON and hash behavior.
- File hashing/mode metadata.
- Config parsing and dependency precedence.
- App name derivation and auto-include discovery.
- `.urunignore` behavior.
- Fake Edge API happy-path deploy flow.
- Failed deployment status exits non-zero.
- Presigned upload path does not receive API `Authorization` header.
- Optional local MinIO integration for real presigned S3-compatible PUTs.
- Production-hardening tests for invalid API key format, out-of-project path handling, duplicate mount paths, finalize `409 missing_blobs`, upload failure behavior, and bounded upload concurrency.

## Optional local MinIO test

Requires a running MinIO server. Example:

```bash
docker compose -f compose.minio.yml up -d
URUN_TEST_MINIO_ENDPOINT=127.0.0.1:9000 \
URUN_TEST_MINIO_ACCESS_KEY=minioadmin \
URUN_TEST_MINIO_SECRET_KEY=minioadmin \
uv run pytest -q -m minio
```

## Gaps / not implemented yet

These are outside the current CLI-only implementation or need staging services:

- Edge Functions themselves (`register-manifest`, `finalize`, `deployment-status`).
- Real Supabase API key lookup/auth.
- S3 bucket lifecycle/policies/events and SQS queue.
- Builder SQS consumer, ZeroFS materialization, Valkey lock, pip/uv install in builder.
- ArgoCD plugin.
- End-to-end staging acceptance criteria from a real cluster.
- API key bootstrap flow.

## Known CLI follow-ups

- Add more API response negative tests: `403 forbidden`, `413 manifest_too_large`.
- Add duplicate manifest-path detection across app files and mounts if the builder materialization contract changes to share a root.
- Decide whether volatile fields like `created_at` should remain part of the manifest hash long term; current CLI follows SPEC v1 literally.
- Improve `pyproject.toml` dependency extraction if the builder expects exact dependency lists rather than the uploaded file.
- Consider status polling grace for transient 404 immediately after finalize.
