{
  description = "urun CLI development environment";

  inputs = {
    nixpkgs.url = "github:NixOS/nixpkgs/nixos-unstable";
    flake-utils.url = "github:numtide/flake-utils";
    dagger.url = "github:dagger/nix";
    dagger.inputs.nixpkgs.follows = "nixpkgs";
  };

  outputs = { nixpkgs, flake-utils, dagger, ... }:
    flake-utils.lib.eachDefaultSystem (system:
      let
        pkgs = import nixpkgs { inherit system; };
      in
      {
        devShells.default = pkgs.mkShell {
          packages = [
            pkgs.actionlint
            pkgs.nodejs_22
            pkgs.pre-commit
            pkgs.python312
            pkgs.ruff
            pkgs.uv
            dagger.packages.${system}.dagger
          ];

          shellHook = ''
            export UV_PYTHON="python3.12"
          '';
        };
      });
}
