# Contributing

## Setup

```bash
# Optional but recommended if you use Nix/direnv:
direnv allow

uv sync
uv run urun --version
```

## Checks

```bash
uv run ruff check .
uv run ruff format --check .
uv run pytest -q
uv run pytest -q -m "not minio" --cov=urun --cov-report=term-missing --cov-report=xml
uv build
```

The coverage command prints a missing-line report and writes `coverage.xml` for CI/artifact upload.

## Testing strategy

Follow a practical test pyramid:

- Prefer fast unit tests for parsing, path policy, manifest/dependency logic, and CLI validation.
- Use fake HTTP integration tests for the urun API contract and retry/error flows.
- Keep real-service tests small and explicit; MinIO is the local smoke for presigned upload behavior.
- Maintain more than three meaningful tests in each active layer: unit, fake-API integration, and real-service MinIO integration.
- Do not raise coverage by adding broad E2E tests or assertions against incidental implementation details.

To run the optional MinIO integration test locally:

```bash
docker compose -f compose.minio.yml up -d
URUN_TEST_MINIO_ENDPOINT=127.0.0.1:9000 \
URUN_TEST_MINIO_ACCESS_KEY=minioadmin \
URUN_TEST_MINIO_SECRET_KEY=minioadmin \
uv run pytest -q -m minio
```

## Pre-commit

This repo follows urun's centralized Dagger pre-commit pipeline in CI. Local hooks live in `.pre-commit-config.yaml`; CI invokes them through `urun-sh/dagger-pipeline`. The Nix/direnv shell provides Dagger and actionlint so maintainers can reproduce the same pre-commit environment locally.

## Scope

This repository owns the Python CLI package. Supabase Edge Functions, S3/SQS wiring, builder pods, ZeroFS materialization, and ArgoCD integration are platform components tracked separately.
