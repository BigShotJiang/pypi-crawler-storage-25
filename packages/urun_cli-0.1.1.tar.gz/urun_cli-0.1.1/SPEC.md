# urun deploy pipeline — SPEC v1

Status: implementation-ready. Scope is the path from `urun deploy` on a developer machine to a built, scaled-to-zero app on the urun cluster. Existing in-cluster builder is the target; this spec describes the new components in front of it.

---

## 1. Overview

```
┌──────────┐    ┌──────────────────┐    ┌──────────┐    ┌─────────────┐    ┌────────────┐    ┌─────────┐
│  urun    │───▶│ Supabase Edge Fn │───▶│   S3     │───▶│  SQS Queue  │───▶│  Builder   │───▶│ ZeroFS  │
│  CLI     │    │  (auth + URLs)   │    │ uploads  │    │  (events)   │    │   Pod      │    │ /mounts │
└──────────┘    └──────────────────┘    └────┬─────┘    └─────────────┘    └─────┬──────┘    └─────────┘
                                             │                                    │
                                             │                                    ▼
                                             │                            ┌──────────────┐
                                             └───────────────────────────▶│  S3 status/  │
                                                                          │  (readiness) │
                                                                          └──────┬───────┘
                                                                                 │
                                                                                 ▼
                                                                         ┌──────────────┐
                                                                         │   ArgoCD     │
                                                                         │   plugin     │
                                                                         └──────────────┘
```

**Design principles:**
- Content-addressed everything (SHA-256). Same file uploaded twice → uploaded once.
- Idempotent at every stage. Re-running any step is safe.
- Per-org isolation. No cross-org dedup in v1.
- Async handoffs via S3 events + SQS. No synchronous waiting on builds from the CLI.
- Bucket is authoritative; ZeroFS is a cache.

---

## 2. CLI behavior

### 2.1 Invocation

```
urun deploy <entrypoint> [--name <app-name>] [--config <path>]
urun deploy -m <module> [--name <app-name>] [--config <path>]
```

Examples:
- `urun deploy app.py`
- `urun deploy src/myapp/main.py`
- `urun deploy -m myapp.main`

If `--name` is omitted, derive from the entrypoint: `app.py` → `app`, `src/myapp/main.py` → `myapp`, `-m myapp.main` → `myapp`.

### 2.2 Auto-include rules

Mirror Modal's post-1.0 behavior: narrow auto-include, explicit opt-in for everything else.

**Auto-included:**
- If entrypoint is inside a package (walk up from entrypoint looking for `__init__.py`; stop at first directory without one), include the entire package directory.
- Otherwise, include only the entrypoint file.
- Only `*.py` files. Excludes: `__pycache__/`, `*.pyc`, `.git/`, dotfiles, anything matched by `.urunignore` if present.
- Maximum auto-include package size: 50 MB. Above this, fail with a clear error pointing the user at `urun.toml` for explicit configuration.

**Explicit includes (via `urun.toml`):**
```toml
[app]
name = "my-app"
entrypoint = "src/myapp/main.py"
python_version = "3.12"

[[mounts]]
local_path = "./assets"
remote_path = "/app/assets"

[[mounts]]
local_file = "./config.json"
remote_path = "/app/config.json"

[[mounts]]
python_source = "shared_lib"  # resolved via import machinery

[deps]
requirements = "requirements.txt"  # or omit and use pyproject.toml
```

If `urun.toml` exists, it's authoritative. CLI flags override fields in it. If absent, auto-include rules apply with sensible defaults.

### 2.3 Dependency declaration

Resolved in this order:
1. `urun.toml [deps] requirements` if present
2. `pyproject.toml` if present (use the project's `dependencies` + optional `python-requires`)
3. `requirements.txt` if present
4. No deps

The dependency file itself is uploaded as a blob and referenced from the manifest. Resolution (pip/uv install) happens in the builder, not the CLI.

Default Python version when none is declared in `urun.toml` or `pyproject.toml`: **3.12**.

### 2.4 CLI flow

```
1. Discover files (auto-include + explicit mounts)
2. Hash every file (SHA-256, streaming)
3. Build manifest (see §3)
4. POST /register-manifest → get missing-list + presigned URLs
5. For each missing blob: PUT to S3 via presigned URL (parallel, bounded concurrency = 8)
6. POST /finalize/:manifest_hash
7. Poll GET /deployment-status/:manifest_hash until status ∈ {ready, failed}
8. Print result + deployment URL
```

CLI exits non-zero on `failed` status with the builder's error message.

---

## 3. Manifest schema

Canonical JSON, sorted keys, no trailing whitespace. The `manifest_hash` is `sha256(canonical_json_with_manifest_hash_field_omitted)` rendered as lowercase hex.

```json
{
  "version": 1,
  "org_id": "org_a1b2c3d4",
  "app_name": "my-app",
  "entrypoint": "src/myapp/main.py",
  "python_version": "3.12",
  "files": [
    {
      "path": "src/myapp/main.py",
      "sha256": "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855",
      "size": 1234,
      "mode": 33188
    }
  ],
  "mounts": [
    {
      "remote_path": "/app/assets",
      "files": [
        {"path": "assets/logo.png", "sha256": "...", "size": 4096, "mode": 33188}
      ]
    }
  ],
  "deps": {
    "kind": "requirements_txt",
    "blob_sha256": "abc123...",
    "python_version": "3.12"
  },
  "created_at": "2026-05-20T15:30:00Z",
  "client_version": "urun-cli/0.1.0",
  "manifest_hash": "f00d..."
}
```

Notes:
- `path` is the path inside the materialized mount root (forward-slash, no leading slash).
- `mode` is POSIX mode bits. Default to `0o100644` for files; preserve executable bit if set.
- `deps.kind` ∈ `{"requirements_txt", "pyproject_toml", "none"}`.
- File paths must be sorted lexicographically before hashing.

---

## 4. Wire protocol (Supabase Edge Function endpoints)

Base URL: `https://api.urun.sh/v1` (Edge Function routed via Supabase custom domain).

All endpoints:
- Require `Authorization: Bearer urun_<32hex>` header.
- Return `application/json`.
- Errors as `{"error": {"code": "...", "message": "..."}}` with appropriate HTTP status.

### 4.1 `POST /register-manifest`

**Request body:** the manifest JSON (see §3), without `manifest_hash` field (server computes and verifies).

**Response 200:**
```json
{
  "manifest_hash": "f00d...",
  "missing_blobs": [
    {
      "sha256": "e3b0...",
      "upload_url": "https://s3.../uploads/org_a1b2c3d4/blobs/e3b0...?X-Amz-...",
      "expires_at": "2026-05-20T16:00:00Z"
    }
  ],
  "status_url": "https://api.urun.sh/v1/deployment-status/f00d..."
}
```

**Server behavior:**
1. Validate API key → resolve `org_id`. Reject if `manifest.org_id` doesn't match.
2. Validate manifest schema. Reject on size > 1 MB, file count > 10k, or total declared size > 500 MB.
3. For each unique blob `sha256` in manifest: `HEAD s3://urun-uploads/<org_id>/blobs/<sha256>`. If exists, omit from `missing_blobs`.
4. For each missing blob, mint presigned PUT URL with:
   - Key: `<org_id>/blobs/<sha256>`
   - `Content-Length` bound: declared size from manifest
   - `If-None-Match: *` to refuse overwrite
   - TTL: 10 minutes
5. Cache the validated manifest in a temporary S3 location (`<org_id>/pending/<manifest_hash>.json`) keyed by hash. Pending manifests TTL 24h via lifecycle rule.

**Errors:**
- `401 unauthorized` — invalid or revoked key
- `403 forbidden` — `org_id` mismatch
- `413 manifest_too_large` — limits exceeded
- `400 invalid_manifest` — schema violation, with details

### 4.2 `POST /finalize/:manifest_hash`

**Request body:** empty.

**Response 200:**
```json
{
  "manifest_hash": "f00d...",
  "status": "queued"
}
```

**Server behavior:**
1. Validate API key → resolve `org_id`.
2. Load `<org_id>/pending/<manifest_hash>.json`. 404 if not found.
3. For each blob in manifest, `HEAD s3://urun-uploads/<org_id>/blobs/<sha>`. Reject with `409 missing_blobs` listing absent SHAs.
4. Atomic copy: `pending/<hash>.json` → `manifests/<hash>.json`. This is the event trigger.
5. Write initial status: `status/<hash>.json` with `{"status": "queued", ...}`.
6. Delete `pending/<hash>.json`.

The `manifests/` write fires the S3 → SQS event that wakes the builder. Builder is the only consumer of that prefix.

### 4.3 `GET /deployment-status/:manifest_hash`

**Response 200:** the status JSON (see §6) verbatim from S3.

**Behavior:** read `<org_id>/status/<manifest_hash>.json`, return it. 404 if missing. Auth required and `org_id` must match.

### 4.4 Edge Function deployment

- Runtime: Supabase Edge Functions (Deno).
- Secrets (via `supabase secrets set`):
  - `S3_ACCESS_KEY`, `S3_SECRET_KEY`, `S3_ENDPOINT` (omit endpoint for AWS), `S3_REGION`, `S3_BUCKET`
  - `SUPABASE_SERVICE_ROLE_KEY` (for Postgres lookups)
- One function per endpoint, or a single function with internal routing — implementer's call.

---

## 5. S3 bucket layout

Single bucket: `urun-uploads-<env>` where env ∈ `{prod, staging, dev}`.

```
urun-uploads-prod/
├── <org_id>/
│   ├── blobs/
│   │   └── <sha256>                    # file content, content-addressed
│   ├── manifests/
│   │   └── <manifest_hash>.json        # WRITE TRIGGERS BUILDER (SQS event)
│   ├── pending/
│   │   └── <manifest_hash>.json        # pre-finalize staging, 24h TTL
│   └── status/
│       └── <manifest_hash>.json        # build readiness, written by builder
```

**S3 event configuration:**
- Event source: `s3:ObjectCreated:*`
- Prefix filter: any path matching `*/manifests/*.json` — implement via per-org notifications if multi-region, or single notification with prefix `manifests/` if bucket layout flattened (alternative below).
- Destination: SQS queue `urun-build-events` (standard queue, not FIFO — content-addressing makes ordering irrelevant).

**Lifecycle rules:**
- `*/pending/*` → expire after 1 day
- `*/blobs/*` → no expiry in v1 (revisit when storage costs matter)
- `*/manifests/*` and `*/status/*` → no expiry

**Bucket policy:**
- No public access.
- Presigned URLs are the only client write path.
- Builder reads via IAM role attached to its service account (IRSA on EKS / Workload Identity on GKE).

**Alternative flatter layout** (consider during impl): collapse `<org_id>` into the key prefix to make S3 event filtering trivial — `manifests/<org_id>/<hash>.json` etc. Pick whichever the implementer finds cleaner; doesn't affect external contracts.

---

## 6. Builder contract

The existing builder pod's interface changes only at the input edge: instead of `kubectl cp`-style ingestion, it consumes SQS messages and pulls from S3.

### 6.1 Input: SQS message

Raw S3 event notification JSON. Builder extracts:
- `bucket`
- `key` (matches `<org_id>/manifests/<manifest_hash>.json`)
- Parses `org_id` and `manifest_hash` from key

### 6.2 Materialization flow

```
1. Update status: status/<hash>.json → {"status": "building", started_at: <now>}
2. GET manifests/<hash>.json
3. Acquire Valkey lock: SETNX urun:build:<hash> <pod_id> EX 600
   - If lock held: ACK message (another builder owns it), return
4. mkdir -p /mnt/zerofs/staging/<hash>/
5. For each file in manifest (bounded parallelism = 16):
   a. GET blobs/<sha256> from S3
   b. Stream-hash while writing to /mnt/zerofs/staging/<hash>/<path>
   c. On hash mismatch: fail the build, write status
   d. chmod to declared mode
6. If deps present: run pip/uv install into /mnt/zerofs/staging/<hash>/.venv/
7. fsync directory
8. Atomic rename: /mnt/zerofs/staging/<hash>/ → /mnt/zerofs/mounts/<hash>/
9. Write status/<hash>.json → {"status": "ready", built_at: <now>, ...}
10. Release Valkey lock
11. ACK SQS message
```

### 6.3 Idempotency

If `/mnt/zerofs/mounts/<hash>/` already exists at start of step 4: skip to step 9, write ready status, ACK. This handles redelivery and lets identical deploys from different orgs (when we add global dedup later) short-circuit cheaply.

If `/mnt/zerofs/staging/<hash>/` exists from a previous crashed build: `rm -rf` and restart. The Valkey lock prevents two builders from racing.

### 6.4 Failure handling

- Hash mismatch on any blob → write `status: "failed"` with reason `blob_corruption`, ACK message (no retry — corruption is deterministic).
- Missing blob in S3 → write `status: "failed"` with reason `missing_blob`, ACK.
- pip install failure → write `status: "failed"` with stderr captured, ACK.
- S3 transient error (5xx, throttle) → don't ACK, let SQS redeliver. SQS visibility timeout: 10 min. Max receives: 3, then DLQ.
- Builder pod crash mid-build → Valkey lock expires after 600s, SQS redelivers, fresh build picks up.

### 6.5 Configuration

Builder pod needs:
- AWS/S3 credentials (IRSA)
- Valkey connection string (reuse existing JuiceFS-co-tenanted instance with `{ub}` hash tag for build keys)
- ZeroFS mount at `/mnt/zerofs`
- SQS queue URL

---

## 7. Status / readiness

Schema for `<org_id>/status/<manifest_hash>.json`:

```json
{
  "manifest_hash": "f00d...",
  "org_id": "org_a1b2c3d4",
  "app_name": "my-app",
  "status": "queued" | "building" | "ready" | "failed",
  "zerofs_path": "/mounts/f00d...",
  "queued_at": "2026-05-20T15:30:00Z",
  "started_at": "2026-05-20T15:30:05Z" | null,
  "built_at": "2026-05-20T15:32:10Z" | null,
  "replicas": 0,
  "image_refs": [],
  "error": null | {
    "code": "blob_corruption" | "missing_blob" | "deps_install_failed" | "internal",
    "message": "..."
  }
}
```

Writers:
- `register-manifest` / `finalize` Edge Function → writes `queued`
- Builder → writes `building`, `ready`, `failed`
- ArgoCD plugin → may update `replicas` after scale operations (out of v1 scope to formalize)

Status writes use `PutObject` with `If-Match` ETag for optimistic concurrency. On conflict, re-read and retry.

---

## 8. Database schema (Supabase Postgres)

```sql
create table orgs (
  id          text primary key,         -- "org_<random>"
  name        text not null,
  created_at  timestamptz not null default now()
);

create table api_keys (
  id          text primary key,         -- "key_<random>"
  org_id      text not null references orgs(id),
  key_hash    text not null unique,     -- sha256(raw_key) hex
  label       text,
  created_at  timestamptz not null default now(),
  revoked_at  timestamptz
);

create index api_keys_key_hash_idx on api_keys(key_hash) where revoked_at is null;
```

**Key format:** `urun_<32 lowercase hex chars>` (16 random bytes). Generated client-side via `/v1/api-keys` (out of scope for v1; bootstrap via SQL for now).

**Key lookup:** `select org_id from api_keys where key_hash = sha256(presented_key) and revoked_at is null`.

**Edge Function auth helper:**
```ts
async function authenticate(req: Request): Promise<{ org_id: string } | null> {
  const raw = req.headers.get("authorization")?.replace(/^Bearer\s+/, "");
  if (!raw?.startsWith("urun_")) return null;
  const hash = await sha256Hex(raw);
  const { data } = await sb.from("api_keys")
    .select("org_id")
    .eq("key_hash", hash)
    .is("revoked_at", null)
    .single();
  return data ? { org_id: data.org_id } : null;
}
```

---

## 9. ArgoCD plugin contract (interface only — implementation out of v1 scope)

**Input:** new `status/<hash>.json` with `status: "ready"`.

**Output:** Kubernetes Deployment + Service manifests, named `<app_name>-<manifest_hash[:8]>`, scaled to 0 replicas, with:
- Volume mount: `/mnt/zerofs/mounts/<manifest_hash>` → `/app` (read-only)
- Env: `URUN_APP_NAME`, `URUN_MANIFEST_HASH`, `URUN_ENTRYPOINT`
- Container image: existing urun runtime base (per python_version)

Discovery mechanism: polling `status/` prefix or S3 events fanout — implementer's choice. Document the chosen mechanism in the plugin's own README.

---

## 10. Out of scope for v1

Document these so we don't grow them by accident:

- **Rate limiting** on Edge Function (defer until abuse observed)
- **API key rotation UI** (raw SQL for now)
- **Audit logs** beyond Edge Function request logs
- **Cross-org blob dedup** (would require global namespace; explicitly per-org for now)
- **Multi-region buckets** (single region/env)
- **GPU work in builder** (no JIT, no model prefetch — builder is pure I/O + pip)
- **Incremental builds** (every manifest is a full rebuild)
- **Build caching beyond ZeroFS materialization** (e.g., no shared pip wheel cache between manifests — revisit when slow)
- **Webhook notifications** of build completion (polling only for v1)
- **Image layer caching / OCI image production** (we materialize to ZeroFS, not Docker images)

---

## 11. Acceptance criteria

Implementer is done when:

1. `urun deploy app.py` from a fresh checkout uploads, builds, and reports `ready` status end-to-end on staging.
2. Re-running `urun deploy` with no file changes returns `missing_blobs: []` from `register-manifest` (proves dedup works).
3. Killing the builder pod mid-build results in a successful retry within 10 minutes (proves crash recovery).
4. Two parallel `urun deploy` calls with identical manifests result in one build and two `ready` status responses (proves Valkey lock).
5. An invalid API key returns 401 in <100ms (proves auth path).
6. A 600 MB manifest is rejected with `413 manifest_too_large` (proves size limits).

---

## 12. Resolved decisions

- **CLI distribution:** PyPI (`pip install urun`). No Homebrew in v1.
- **Default Python version:** 3.12.

## 13. Configurable / TBD with implementer

These get decided during implementation and live in a config file or env, not hardcoded:

- Bucket naming + AWS account (same as JuiceFS or separate)
- DNS routing (Supabase custom domain vs. Cloudflare fronting)
- Org bootstrap flow (manual SQL vs. self-serve)

Implementer: bake these as env vars / config values from day one rather than hardcoding any of them.
