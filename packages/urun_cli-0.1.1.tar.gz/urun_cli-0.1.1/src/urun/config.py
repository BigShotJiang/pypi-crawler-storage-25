from __future__ import annotations

import re
import tomllib
from dataclasses import dataclass, field
from pathlib import Path, PurePosixPath
from typing import Any

from .errors import UrunError


@dataclass
class AppConfig:
    name: str | None = None
    entrypoint: str | None = None
    module: str | None = None
    python_version: str | None = None


@dataclass
class MountConfig:
    local_path: str | None = None
    local_file: str | None = None
    python_source: str | None = None
    remote_path: str | None = None


@dataclass
class DepsConfig:
    requirements: str | None = None


@dataclass
class UrunConfig:
    app: AppConfig = field(default_factory=AppConfig)
    mounts: list[MountConfig] = field(default_factory=list)
    deps: DepsConfig = field(default_factory=DepsConfig)


def load_config(path: Path | None) -> UrunConfig:
    if path is None:
        path = Path("urun.toml")
    if not path.exists():
        return UrunConfig()
    try:
        data = tomllib.loads(path.read_text())
    except tomllib.TOMLDecodeError as exc:
        raise UrunError(f"Invalid TOML in {path}: {exc}") from exc
    return parse_config(data, path)


def parse_config(data: dict[str, Any], path: Path = Path("urun.toml")) -> UrunConfig:
    app_data = data.get("app", {}) or {}
    if not isinstance(app_data, dict):
        raise UrunError(f"{path}: [app] must be a table")
    app = AppConfig(
        name=_str(app_data, "name", path),
        entrypoint=_str(app_data, "entrypoint", path),
        module=_str(app_data, "module", path),
        python_version=_str(app_data, "python_version", path),
    )

    mounts: list[MountConfig] = []
    for idx, mount_data in enumerate(data.get("mounts", []) or []):
        if not isinstance(mount_data, dict):
            raise UrunError(f"{path}: [[mounts]] item {idx} must be a table")
        sources = [k for k in ("local_path", "local_file", "python_source") if mount_data.get(k)]
        if len(sources) != 1:
            raise UrunError(f"{path}: [[mounts]] item {idx} must set exactly one source")
        remote_path = _str(mount_data, "remote_path", path)
        if not remote_path:
            raise UrunError(f"{path}: [[mounts]] item {idx} must set remote_path")
        validate_remote_path(remote_path, path, idx)
        mounts.append(
            MountConfig(
                local_path=_str(mount_data, "local_path", path),
                local_file=_str(mount_data, "local_file", path),
                python_source=_str(mount_data, "python_source", path),
                remote_path=remote_path,
            )
        )

    deps_data = data.get("deps", {}) or {}
    if not isinstance(deps_data, dict):
        raise UrunError(f"{path}: [deps] must be a table")
    return UrunConfig(
        app=app, mounts=mounts, deps=DepsConfig(requirements=_str(deps_data, "requirements", path))
    )


def validate_remote_path(remote_path: str, path: Path, idx: int) -> None:
    parts = PurePosixPath(remote_path).parts
    invalid = (
        not remote_path.startswith("/")
        or remote_path == "/"
        or "\\" in remote_path
        or "//" in remote_path
        or any(part in {".", ".."} for part in parts)
        or any(part in {".", ".."} for part in remote_path.split("/"))
        or bool(re.search(r"[\x00-\x1f\x7f]", remote_path))
        or len(remote_path) > 512
    )
    if invalid:
        raise UrunError(
            f"{path}: [[mounts]] item {idx} remote_path must be an absolute, normalized POSIX path"
        )


def _str(data: dict[str, Any], key: str, path: Path) -> str | None:
    value = data.get(key)
    if value is None:
        return None
    if not isinstance(value, str):
        raise UrunError(f"{path}: {key} must be a string")
    return value
