from __future__ import annotations

import fnmatch
import importlib.util
import sys
from pathlib import Path

from .config import MountConfig, UrunConfig
from .errors import UrunError
from .manifest import FileBlob, file_blob

MAX_AUTO_INCLUDE_BYTES = 50 * 1024 * 1024
DEFAULT_PYTHON_VERSION = "3.12"


def derive_app_name(entrypoint: str | None, module: str | None) -> str:
    if module:
        return module.split(".")[0]
    if not entrypoint:
        raise UrunError("missing entrypoint")
    p = Path(entrypoint)
    if p.name == "__main__.py" and p.parent.name:
        return p.parent.name
    if p.parent != Path("."):
        return p.parent.name
    return p.stem


def package_root_for(entrypoint: Path) -> Path | None:
    current = entrypoint.resolve().parent
    if not (current / "__init__.py").exists():
        return None
    root = current
    while (root.parent / "__init__.py").exists():
        root = root.parent
    return root


def load_urunignore(root: Path) -> list[str]:
    ignore = root / ".urunignore"
    if not ignore.exists():
        return []
    return [
        line.strip()
        for line in ignore.read_text().splitlines()
        if line.strip() and not line.lstrip().startswith("#")
    ]


def is_ignored(path: Path, project_root: Path, patterns: list[str]) -> bool:
    try:
        rel = path.resolve().relative_to(project_root.resolve()).as_posix()
    except ValueError as exc:
        raise UrunError(f"path is outside the project root: {path}") from exc
    parts = rel.split("/")
    if any(part == "__pycache__" for part in parts):
        return True
    if any(part == ".git" for part in parts):
        return True
    if path.name.startswith(".") or any(part.startswith(".") for part in parts):
        return True
    if path.suffix == ".pyc":
        return True
    return any(
        fnmatch.fnmatch(rel, pattern) or fnmatch.fnmatch(path.name, pattern) for pattern in patterns
    )


def auto_include(entrypoint: Path, project_root: Path) -> list[FileBlob]:
    if not entrypoint.exists() or not entrypoint.is_file():
        raise UrunError(f"entrypoint not found: {entrypoint}")
    if entrypoint.suffix != ".py":
        raise UrunError("entrypoint must be a .py file")
    patterns = load_urunignore(project_root)
    pkg = package_root_for(entrypoint)
    files: list[Path]
    if pkg:
        files = sorted(
            p
            for p in pkg.rglob("*.py")
            if p.is_file() and not is_ignored(p, project_root, patterns)
        )
        total = sum(p.stat().st_size for p in files)
        if total > MAX_AUTO_INCLUDE_BYTES:
            raise UrunError(
                f"auto-included package {pkg} is {total} bytes, above 50 MB; "
                "use urun.toml to configure explicit mounts"
            )
    else:
        if is_ignored(entrypoint, project_root, patterns):
            raise UrunError(f"entrypoint is ignored by defaults or .urunignore: {entrypoint}")
        files = [entrypoint]
    blobs: list[FileBlob] = []
    for p in files:
        try:
            blobs.append(file_blob(p, project_root))
        except ValueError as exc:
            raise UrunError(f"path is outside the project root: {p}") from exc
    return blobs


def discover_main_files(
    config: UrunConfig, entrypoint_arg: str | None, module_arg: str | None, project_root: Path
) -> tuple[str, list[FileBlob]]:
    ensure_project_on_path(project_root)
    module = module_arg or config.app.module
    entrypoint = entrypoint_arg or config.app.entrypoint
    if module:
        spec = importlib.util.find_spec(module)
        if spec is None or spec.origin is None:
            raise UrunError(f"module not found: {module}")
        entrypoint_path = ensure_under_root(Path(spec.origin), project_root, "module")
    elif entrypoint:
        entrypoint_path = Path(entrypoint)
    else:
        raise UrunError("provide an entrypoint, -m module, or [app].entrypoint in urun.toml")
    if not entrypoint_path.is_absolute():
        entrypoint_path = project_root / entrypoint_path
    files = auto_include(entrypoint_path, project_root)
    try:
        manifest_entrypoint = (
            module
            if module
            else entrypoint_path.resolve().relative_to(project_root.resolve()).as_posix()
        )
    except ValueError as exc:
        raise UrunError(f"entrypoint is outside the project root: {entrypoint_path}") from exc
    return manifest_entrypoint, files


def discover_mounts(
    mounts: list[MountConfig], project_root: Path
) -> tuple[list[dict], list[FileBlob]]:
    ensure_project_on_path(project_root)
    manifest_mounts: list[dict] = []
    all_blobs: list[FileBlob] = []
    patterns = load_urunignore(project_root)
    seen_remote_paths: set[str] = set()
    for mount in mounts:
        if mount.remote_path in seen_remote_paths:
            raise UrunError(f"duplicate mount remote_path: {mount.remote_path}")
        seen_remote_paths.add(str(mount.remote_path))
        source = _mount_source(mount, project_root)
        assert mount.remote_path is not None
        if mount.local_file:
            if not source.is_file():
                raise UrunError(f"mount file not found: {source}")
            blob = file_blob(source, source.parent, source.name)
            entries = [blob]
        else:
            if not source.is_dir():
                raise UrunError(f"mount directory not found: {source}")
            paths = sorted(
                p
                for p in source.rglob("*")
                if p.is_file() and not is_ignored(p, project_root, patterns)
            )
            entries = [file_blob(p, source) for p in paths]
        all_blobs.extend(entries)
        manifest_mounts.append(
            {
                "remote_path": mount.remote_path,
                "files": [b.manifest_entry() for b in sorted(entries, key=lambda b: b.path)],
            }
        )
    return manifest_mounts, all_blobs


def ensure_project_on_path(project_root: Path) -> None:
    candidates = [project_root.resolve()]
    src = project_root / "src"
    if src.is_dir():
        candidates.append(src.resolve())
    for candidate in reversed(candidates):
        path = str(candidate)
        if path not in sys.path:
            sys.path.insert(0, path)


def ensure_under_root(path: Path, project_root: Path, label: str = "path") -> Path:
    resolved = path.resolve()
    try:
        resolved.relative_to(project_root.resolve())
    except ValueError as exc:
        raise UrunError(f"{label} is outside the project root: {path}") from exc
    return resolved


def _mount_source(mount: MountConfig, project_root: Path) -> Path:
    if mount.local_path:
        return ensure_under_root(project_root / mount.local_path, project_root, "mount path")
    if mount.local_file:
        return ensure_under_root(project_root / mount.local_file, project_root, "mount file")
    if mount.python_source:
        spec = importlib.util.find_spec(mount.python_source)
        if spec is None:
            raise UrunError(f"python_source not found: {mount.python_source}")
        if spec.submodule_search_locations:
            return ensure_under_root(
                Path(next(iter(spec.submodule_search_locations))), project_root, "python_source"
            )
        if spec.origin:
            return ensure_under_root(Path(spec.origin), project_root, "python_source")
    raise UrunError("invalid mount source")
