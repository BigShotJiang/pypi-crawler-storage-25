class UrunError(Exception):
    """User-facing CLI error."""


class ApiError(UrunError):
    def __init__(self, status: int, code: str, message: str):
        super().__init__(f"{status} {code}: {message}")
        self.status = status
        self.code = code
        self.message = message
