from __future__ import annotations

import hashlib
import json
from collections.abc import Iterable
from dataclasses import dataclass
from pathlib import Path
from typing import Any


@dataclass(frozen=True)
class FileBlob:
    path: str
    source: Path
    sha256: str
    size: int
    mode: int

    def manifest_entry(self) -> dict[str, Any]:
        return {
            "path": self.path,
            "sha256": self.sha256,
            "size": self.size,
            "mode": self.mode,
        }


def posix_rel(path: Path, root: Path) -> str:
    return path.resolve().relative_to(root.resolve()).as_posix()


def normalized_mode(path: Path) -> int:
    st_mode = path.stat().st_mode
    return 0o100755 if (st_mode & 0o111) else 0o100644


def hash_file(path: Path, chunk_size: int = 1024 * 1024) -> tuple[str, int]:
    h = hashlib.sha256()
    size = 0
    with path.open("rb") as f:
        while True:
            chunk = f.read(chunk_size)
            if not chunk:
                break
            size += len(chunk)
            h.update(chunk)
    return h.hexdigest(), size


def file_blob(path: Path, root: Path, manifest_path: str | None = None) -> FileBlob:
    sha, size = hash_file(path)
    return FileBlob(
        path=manifest_path or posix_rel(path, root),
        source=path.resolve(),
        sha256=sha,
        size=size,
        mode=normalized_mode(path),
    )


def canonical_json(data: dict[str, Any]) -> bytes:
    """Canonical JSON: sorted keys, compact separators, UTF-8, no trailing whitespace."""
    return json.dumps(data, sort_keys=True, separators=(",", ":"), ensure_ascii=False).encode(
        "utf-8"
    )


def manifest_hash(manifest_without_hash: dict[str, Any]) -> str:
    data = dict(manifest_without_hash)
    data.pop("manifest_hash", None)
    return hashlib.sha256(canonical_json(data)).hexdigest()


def unique_blobs(files: Iterable[FileBlob]) -> dict[str, FileBlob]:
    out: dict[str, FileBlob] = {}
    for blob in files:
        out.setdefault(blob.sha256, blob)
    return out
