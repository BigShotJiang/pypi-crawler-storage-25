from __future__ import annotations

import re
import tomllib
from pathlib import Path
from typing import Any

from .config import UrunConfig
from .discovery import ensure_under_root
from .errors import UrunError
from .manifest import FileBlob, file_blob

DEFAULT_PYTHON_VERSION = "3.12"
CREDENTIAL_URL_RE = re.compile(r"https?://[^\s/@:]+:[^\s/@]+@", re.IGNORECASE)


def resolve_deps(
    config: UrunConfig, project_root: Path
) -> tuple[dict[str, Any], FileBlob | None, str]:
    python_version = config.app.python_version or DEFAULT_PYTHON_VERSION
    if config.deps.requirements:
        path = ensure_under_root(
            project_root / config.deps.requirements, project_root, "requirements file"
        )
        if not path.is_file():
            raise UrunError(f"requirements file not found: {path}")
        reject_embedded_dependency_credentials(path)
        blob = file_blob(path, project_root)
        return (
            {
                "kind": "requirements_txt",
                "blob_sha256": blob.sha256,
                "python_version": python_version,
            },
            blob,
            python_version,
        )

    pyproject = project_root / "pyproject.toml"
    if pyproject.is_file():
        reject_embedded_dependency_credentials(pyproject)
        blob = file_blob(pyproject, project_root)
        try:
            data = tomllib.loads(pyproject.read_text())
        except tomllib.TOMLDecodeError as exc:
            raise UrunError(f"Invalid TOML in pyproject.toml: {exc}") from exc
        requires = (data.get("project") or {}).get("requires-python")
        if not config.app.python_version and isinstance(requires, str):
            python_version = python_from_requires(requires) or python_version
        return (
            {
                "kind": "pyproject_toml",
                "blob_sha256": blob.sha256,
                "python_version": python_version,
            },
            blob,
            python_version,
        )

    req = project_root / "requirements.txt"
    if req.is_file():
        reject_embedded_dependency_credentials(req)
        blob = file_blob(req, project_root)
        return (
            {
                "kind": "requirements_txt",
                "blob_sha256": blob.sha256,
                "python_version": python_version,
            },
            blob,
            python_version,
        )

    return {"kind": "none", "python_version": python_version}, None, python_version


def reject_embedded_dependency_credentials(path: Path) -> None:
    text = path.read_text(errors="ignore")
    if CREDENTIAL_URL_RE.search(text):
        raise UrunError(
            f"dependency file contains an embedded credential URL: {path.name}; "
            "use token-free package references before deploying"
        )


def python_from_requires(spec: str) -> str | None:
    # Conservative extraction for common specs such as >=3.11 or ==3.12.*.
    versions = re.findall(r"(\d+)\.(\d+)", spec)
    if not versions:
        return None
    major, minor = versions[0]
    return f"{major}.{minor}"
