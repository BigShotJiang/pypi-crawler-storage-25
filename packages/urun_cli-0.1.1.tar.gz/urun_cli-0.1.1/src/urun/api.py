from __future__ import annotations

import json
import time
import urllib.error
import urllib.parse
import urllib.request
from concurrent.futures import ThreadPoolExecutor, as_completed
from typing import Any

from . import __version__
from .errors import ApiError, UrunError
from .manifest import FileBlob, hash_file

DEFAULT_API_URL = "https://api.urun.sh/v1"


class ApiClient:
    def __init__(self, base_url: str, api_key: str, timeout: float = 30.0, attempts: int = 3):
        require_safe_url(base_url, "API URL")
        self.base_url = base_url.rstrip("/")
        self.api_key = api_key
        self.timeout = timeout
        self.attempts = attempts

    def register_manifest(self, manifest: dict[str, Any]) -> dict[str, Any]:
        return self._json("POST", "/register-manifest", manifest)

    def finalize(self, manifest_hash: str) -> dict[str, Any]:
        return self._json("POST", f"/finalize/{manifest_hash}", None)

    def deployment_status(self, manifest_hash: str) -> dict[str, Any]:
        return self._json("GET", f"/deployment-status/{manifest_hash}", None)

    def _json(self, method: str, path: str, body: dict[str, Any] | None) -> dict[str, Any]:
        data = (
            None
            if body is None
            else json.dumps(body, sort_keys=True, separators=(",", ":")).encode("utf-8")
        )
        payload = b""
        for attempt in range(1, self.attempts + 1):
            req = urllib.request.Request(
                self.base_url + path,
                data=data,
                method=method,
                headers={
                    "Authorization": f"Bearer {self.api_key}",
                    "Accept": "application/json",
                    "Content-Type": "application/json",
                    "User-Agent": f"urun-cli/{__version__}",
                },
            )
            try:
                with urllib.request.urlopen(req, timeout=self.timeout) as resp:
                    payload = resp.read()
                    break
            except urllib.error.HTTPError as exc:
                payload = exc.read()
                code = "http_error"
                message = payload.decode("utf-8", "replace") or exc.reason
                try:
                    parsed = json.loads(payload.decode("utf-8"))
                    err = parsed.get("error") or {}
                    code = err.get("code") or code
                    message = err.get("message") or message
                except Exception:
                    pass
                if exc.code not in {429, 500, 502, 503, 504} or attempt == self.attempts:
                    raise ApiError(exc.code, code, message) from exc
            except (urllib.error.URLError, TimeoutError) as exc:
                if attempt == self.attempts:
                    reason = getattr(exc, "reason", exc)
                    raise UrunError(f"network error: {reason}") from exc
            time.sleep(0.25 * attempt)
        if not payload:
            return {}
        try:
            return json.loads(payload.decode("utf-8"))
        except json.JSONDecodeError as exc:
            raise UrunError("invalid JSON response from urun API") from exc


def upload_missing_blobs(
    missing_blobs: list[dict[str, Any]], by_sha: dict[str, FileBlob], concurrency: int = 8
) -> None:
    if not missing_blobs:
        return
    if concurrency < 1:
        raise UrunError("upload concurrency must be at least 1")
    with ThreadPoolExecutor(max_workers=concurrency) as executor:
        futures = []
        seen: set[str] = set()
        for item in missing_blobs:
            if not isinstance(item, dict):
                raise UrunError("invalid missing_blobs item from server")
            sha = item.get("sha256")
            upload_url = item.get("upload_url")
            if not isinstance(sha, str) or not isinstance(upload_url, str):
                raise UrunError("invalid missing_blobs item from server")
            if sha in seen:
                continue
            seen.add(sha)
            if sha not in by_sha:
                raise UrunError(f"server requested unknown blob: {sha}")
            futures.append(executor.submit(upload_blob, upload_url, by_sha[sha]))
        for fut in as_completed(futures):
            fut.result()


def upload_blob(upload_url: str, blob: FileBlob, attempts: int = 3) -> None:
    require_safe_url(upload_url, "upload URL")
    current_sha, current_size = hash_file(blob.source)
    if current_sha != blob.sha256 or current_size != blob.size:
        raise UrunError(f"file changed after manifest generation: {blob.path}")
    last_error: Exception | None = None
    for attempt in range(1, attempts + 1):
        try:
            with blob.source.open("rb") as f:
                req = urllib.request.Request(
                    upload_url,
                    data=f,
                    method="PUT",
                    headers={
                        "Content-Length": str(blob.size),
                        "If-None-Match": "*",
                    },
                )
                with urllib.request.urlopen(req, timeout=120) as resp:
                    if resp.status >= 300:
                        raise UrunError(f"upload failed for {blob.path}: HTTP {resp.status}")
                    return
        except urllib.error.HTTPError as exc:
            if exc.code == 412:
                # Another identical deploy may have won the content-addressed race.
                return
            if exc.code < 500 or attempt == attempts:
                raise UrunError(
                    f"upload failed for {blob.path}: HTTP {exc.code} {exc.reason}"
                ) from exc
            last_error = exc
        except (urllib.error.URLError, TimeoutError) as exc:
            if attempt == attempts:
                reason = getattr(exc, "reason", exc)
                raise UrunError(f"upload failed for {blob.path}: {reason}") from exc
            last_error = exc
        time.sleep(0.25 * attempt)
    if last_error is not None:
        raise UrunError(f"upload failed for {blob.path}: {last_error}") from last_error


def require_safe_url(raw_url: str, label: str) -> None:
    parsed = urllib.parse.urlparse(raw_url)
    host = (parsed.hostname or "").lower()
    if parsed.scheme == "https":
        return
    if parsed.scheme == "http" and host in {"127.0.0.1", "localhost", "::1"}:
        return
    raise UrunError(f"{label} must use HTTPS except for localhost development")


def poll_until_done(
    client: ApiClient,
    manifest_hash: str,
    interval: float = 2.0,
    timeout: float = 1800.0,
    not_found_grace: float = 30.0,
) -> dict[str, Any]:
    deadline = time.time() + timeout
    not_found_deadline = time.time() + min(not_found_grace, timeout)
    last_state = "unknown"
    while True:
        try:
            status = client.deployment_status(manifest_hash)
        except ApiError as exc:
            if exc.status == 404 and time.time() < not_found_deadline:
                last_state = "not_found"
                time.sleep(interval)
                continue
            raise
        state = status.get("status")
        last_state = str(state)
        if state in {"ready", "failed"}:
            return status
        if time.time() >= deadline:
            raise UrunError(
                f"timed out waiting for deployment {manifest_hash} (last status: {last_state})"
            )
        time.sleep(interval)
