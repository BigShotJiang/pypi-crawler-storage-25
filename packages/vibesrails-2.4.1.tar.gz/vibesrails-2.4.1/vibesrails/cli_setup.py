"""
CLI setup/config functions — extracted from cli.py.

Handles: find_config, init_config, install_hook, uninstall, run_senior_mode.
"""

import logging
import shutil
from pathlib import Path

from .scanner import BLUE, GREEN, NC, RED, YELLOW

logger = logging.getLogger(__name__)


def find_config() -> Path | None:
    """Find vibesrails.yaml in project or user home."""
    candidates = [
        Path("vibesrails.yaml"),
        Path("config/vibesrails.yaml"),
        Path.home() / ".config" / "vibesrails" / "vibesrails.yaml",
    ]
    for path in candidates:
        if path.exists():
            return path
    return None


def get_default_config_path() -> Path:
    """Get path to bundled default.yaml."""
    return Path(__file__).parent / "config" / "default.yaml"


def get_decisions_template_path() -> Path:
    """Get path to bundled decisions.md template."""
    return Path(__file__).parent / "config" / "decisions.md.template"


def create_decisions_md(project_root: Path) -> bool:
    """Create decisions.md from template if it doesn't exist anywhere."""
    candidates = [
        project_root / "docs" / "decisions.md",
        project_root / "decisions.md",
        project_root / ".vibesrails" / "decisions.md",
    ]
    for path in candidates:
        if path.exists():
            logger.info(f"{YELLOW}decisions.md already exists at {path}{NC}")
            return False

    template = get_decisions_template_path()
    if not template.exists():
        logger.debug("decisions.md template not found at %s", template)
        return False

    target_dir = project_root / "docs"
    target_dir.mkdir(exist_ok=True)
    target = target_dir / "decisions.md"
    shutil.copy(template, target)
    logger.info(f"{GREEN}Created {target}{NC}")
    return True


def init_config(target: Path = Path("vibesrails.yaml")) -> bool:
    """Initialize vibesrails.yaml in current project."""
    if target.exists():
        logger.info(f"{YELLOW}vibesrails.yaml already exists{NC}")
        return False

    default_config = get_default_config_path()
    if not default_config.exists():
        logger.error(f"{RED}ERROR: Default config not found at {default_config}{NC}")
        return False

    shutil.copy(default_config, target)
    logger.info(f"{GREEN}Created {target}{NC}")

    create_decisions_md(Path.cwd())

    logger.info("Next steps:")
    logger.info(f"  1. Edit {target} to customize patterns")
    logger.info("  2. Edit docs/decisions.md with your project decisions")
    logger.info("  3. Run: vibesrails --hook  (install git pre-commit)")
    logger.info("  4. Code freely - vibesrails runs on every commit")
    return True


def init_methodology(project_root: Path) -> bool:
    """Initialize methodology scaffolding (methodology.yaml, ADR/, ROADMAP.md).

    Does NOT overwrite existing files.
    """
    config_dir = Path(__file__).parent / "config"
    created = []

    # .vibesrails/methodology.yaml
    vr_dir = project_root / ".vibesrails"
    methodology_target = vr_dir / "methodology.yaml"
    if not methodology_target.exists():
        template = config_dir / "methodology.yaml.template"
        if template.exists():
            vr_dir.mkdir(exist_ok=True)
            shutil.copy(template, methodology_target)
            created.append(str(methodology_target.relative_to(project_root)))

    # ADR/ directory with template
    adr_dir = project_root / "ADR"
    if not adr_dir.exists():
        adr_dir.mkdir()
        adr_template = config_dir / "adr_template.md"
        if adr_template.exists():
            shutil.copy(adr_template, adr_dir / "001-template.md")
        created.append("ADR/001-template.md")

    # ROADMAP.md
    roadmap = project_root / "ROADMAP.md"
    if not roadmap.exists():
        roadmap_template = config_dir / "roadmap_template.md"
        if roadmap_template.exists():
            shutil.copy(roadmap_template, roadmap)
        created.append("ROADMAP.md")

    if created:
        for f in created:
            logger.info(f"{GREEN}Created {f}{NC}")
        logger.info("Next steps:")
        logger.info("  1. Edit ADR/001-template.md with your first architecture decision")
        logger.info("  2. Review ROADMAP.md phases")
        logger.info("  3. Run: vibesrails --preflight  (see current phase)")
        return True

    logger.info(f"{YELLOW}Methodology files already exist — nothing to create{NC}")
    return False


def uninstall() -> bool:
    """Uninstall vibesrails from current project."""
    removed = []
    config_file = Path("vibesrails.yaml")
    if config_file.exists():
        config_file.unlink()
        removed.append(str(config_file))
    hook_path = Path(".git/hooks/pre-commit")
    if hook_path.exists():
        content = hook_path.read_text()
        if "vibesrails" in content:
            lines = content.split("\n")
            new_lines = []
            in_vibesrails_block = False

            for line in lines:
                stripped = line.strip()

                # Inside vibesrails if-block: skip until closing fi
                if in_vibesrails_block:
                    if stripped == "fi":
                        in_vibesrails_block = False
                    continue

                # Detect start of if/elif block that references vibesrails
                if "vibesrails" in line.lower() and (
                    stripped.startswith("if ") or stripped.startswith("elif ")
                ):
                    in_vibesrails_block = True
                    continue

                # Skip individual vibesrails lines (comments, commands)
                if "vibesrails" in line.lower():
                    continue

                new_lines.append(line)

            new_content = "\n".join(new_lines).strip()

            # Check if only shebang/comments/whitespace remain
            meaningful = [
                line
                for line in new_content.split("\n")
                if line.strip() and not line.strip().startswith("#")
            ]

            if not meaningful:
                hook_path.unlink()
                removed.append(str(hook_path))
            else:
                hook_path.write_text(new_content + "\n")
                logger.info(f"{YELLOW}Removed vibesrails from pre-commit hook{NC}")
    vibesrails_dir = Path(".vibesrails")
    if vibesrails_dir.exists():
        shutil.rmtree(vibesrails_dir)
        removed.append(str(vibesrails_dir))

    if removed:
        logger.info(f"{GREEN}Removed:{NC}")
        for f in removed:
            logger.info(f"  - {f}")
        logger.info(f"{GREEN}vibesrails uninstalled from this project{NC}")
        logger.info("To uninstall the package: pip uninstall vibesrails")
    else:
        logger.info(f"{YELLOW}Nothing to uninstall{NC}")

    # Notify about files left behind intentionally
    leftovers = [
        p for p in [Path("CLAUDE.md"), Path(".claude/hooks.json")]
        if p.exists()
    ]
    if leftovers:
        logger.info(f"\n{YELLOW}Note: These files were left in place (not managed by vibesrails):{NC}")
        for p in leftovers:
            logger.info(f"  - {p}")
        logger.info("Remove them manually if no longer needed.")

    return True


def _get_cached_diff(*extra_args: str) -> str:
    """Get git staged diff output."""
    import subprocess
    cmd = ["git", "diff", "--cached"] + list(extra_args)
    return subprocess.run(cmd, capture_output=True, text=True).stdout


def _read_file_contents(files: list[str]) -> list[tuple[str, str]]:
    """Read file contents, skipping unreadable files."""
    contents = []
    for f in files:
        try:
            contents.append((f, Path(f).read_text()))
        except (OSError, UnicodeDecodeError) as e:
            logger.debug("Failed to read file for senior mode: %s (%s)", f, e)
    return contents


def run_senior_mode(files: list[str]) -> int:
    """Run Senior Mode checks."""
    from .senior_mode import ArchitectureMapper, ClaudeReviewer, SeniorGuards
    from .senior_mode.report import SeniorReport

    logger.info(f"{BLUE}Updating ARCHITECTURE.md...{NC}")
    ArchitectureMapper(Path.cwd()).save()

    code_diff = _get_cached_diff()
    test_diff = _get_cached_diff("--", "tests/")
    file_contents = _read_file_contents(files)

    issues = SeniorGuards().check_all(
        code_diff=code_diff, test_diff=test_diff, files=file_contents,
    )

    reviewer = ClaudeReviewer()
    review_result = None
    for filepath, content in file_contents:
        if reviewer.should_review(filepath, code_diff):
            logger.info(f"{BLUE}Running Claude review on {filepath}...{NC}")
            review_result = reviewer.review(content, filepath)
            break

    report = SeniorReport(
        guard_issues=issues, review_result=review_result, architecture_updated=True,
    )
    logger.info(report.generate())
    return 1 if report.has_blocking_issues() else 0


_ARCH_CHECK = """
# Architecture check (optional - fails silently if not installed)
if command -v lint-imports &> /dev/null; then
    echo "Checking architecture..."
    lint-imports || echo "Architecture check failed (non-blocking)"
fi
"""


def _update_existing_hook(hook_path: Path, architecture_enabled: bool) -> bool:
    """Update an existing pre-commit hook. Returns True if handled."""
    content = hook_path.read_text()
    if "vibesrails" not in content:
        return False
    if architecture_enabled and "lint-imports" not in content:
        hook_path.write_text(content.rstrip() + "\n" + _ARCH_CHECK)
        logger.info(f"{YELLOW}Updated pre-commit hook with architecture check{NC}")
    else:
        logger.info(f"{YELLOW}VibesRails hook already installed{NC}")
    return True


def install_hook(architecture_enabled: bool = False) -> bool:
    """Install git pre-commit hook."""
    git_dir = Path(".git")
    if not git_dir.exists():
        logger.error(f"{RED}ERROR: Not a git repository{NC}")
        return False

    hooks_dir = git_dir / "hooks"
    hooks_dir.mkdir(exist_ok=True)
    hook_path = hooks_dir / "pre-commit"
    arch_check = _ARCH_CHECK if architecture_enabled else ""

    if hook_path.exists():
        if _update_existing_hook(hook_path, architecture_enabled):
            return True
        logger.info(f"{YELLOW}Appending to existing pre-commit hook{NC}")
        with open(hook_path, "a") as f:
            f.write("\n\n# vibesrails security check\nvibesrails\n")
            if architecture_enabled:
                f.write(arch_check)
    else:
        hook_path.write_text(
            "#!/bin/bash\n# VibesRails pre-commit hook\n"
            "# Scale up your vibe coding - safely\n\n"
            "# Find vibesrails command (PATH, local venv, or python -m)\n"
            'if command -v vibesrails &> /dev/null; then\n    vibesrails\n'
            'elif [ -f ".venv/bin/vibesrails" ]; then\n    .venv/bin/vibesrails\n'
            'elif [ -f "venv/bin/vibesrails" ]; then\n    venv/bin/vibesrails\n'
            "else\n    python3 -m vibesrails\nfi\n" + arch_check
        )
        hook_path.chmod(0o755)

    logger.info(f"{GREEN}Git hook installed at {hook_path}{NC}")
    return True
