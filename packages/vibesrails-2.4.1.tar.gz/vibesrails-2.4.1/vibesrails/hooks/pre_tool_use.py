"""PreToolUse hook: scan BEFORE Claude Code writes or executes.

Blocks unsafe patterns in code (secrets, SQL injection, dangerous functions)
and leaked secrets in bash commands.
Run as: python3 -m vibesrails.hooks.pre_tool_use
"""

import json
import logging
import re
import sys
from pathlib import Path

logger = logging.getLogger(__name__)

# Throttle state directory
VIBESRAILS_DIR = Path.cwd() / ".vibesrails"

# Commands that count as "verification" — resets the write counter
CHECK_COMMANDS = ["pytest", "ruff", "vibesrails", "lint-imports", "bandit", "mypy"]

# Secret patterns — imported from central source of truth
try:
    from core.secret_patterns import SECRET_PATTERN_DEFS
    SECRET_PATTERNS = [(p, label) for p, label in SECRET_PATTERN_DEFS]
except ImportError:
    # Fallback if core not installed (standalone hook usage)
    SECRET_PATTERNS = [
        (
            r"(?:api_key|secret|token|password|passwd)\s*=\s*['\"][^'\"]{8,}['\"]",
            "Hardcoded secret detected",
        ),
        (
            r"(?:AKIA|sk-|ghp_|gho_)[A-Za-z0-9_\-]{10,}",
            "API key detected",
        ),
    ]

# Code patterns — applied to .py files ONLY (not relevant for config files)
CODE_PATTERNS = [
    (
        r"f['\"](?:SELECT|INSERT|UPDATE|DELETE)\b.*\{",
        "SQL injection via f-string",
    ),
    (
        r"(?:SELECT|INSERT|UPDATE|DELETE)\b.*\.format\s*\(",
        "SQL injection via .format()",
    ),
    (  # vibesrails: ignore
        r"eval\s*\(",
        "Use of " + "eval() is dangerous",
    ),
    (  # vibesrails: ignore
        r"exec\s*\(",
        "Use of " + "exec() is dangerous",
    ),
    (
        r"subprocess\.(?:call|run|Popen)\s*\(.*" + r"shell\s*=\s*True",  # vibesrails: ignore
        "shell" + "=True is dangerous",
    ),
]

# Combined for backward compat (used by .py scanning)
CRITICAL_PATTERNS = SECRET_PATTERNS + CODE_PATTERNS

COMPILED_SECRET_PATTERNS = [(re.compile(p, re.IGNORECASE), msg) for p, msg in SECRET_PATTERNS]
COMPILED_CODE_PATTERNS = [(re.compile(p, re.IGNORECASE), msg) for p, msg in CODE_PATTERNS]
COMPILED_PATTERNS = COMPILED_SECRET_PATTERNS + COMPILED_CODE_PATTERNS

# File extensions to scan for secrets (beyond .py)
SCANNABLE_EXTENSIONS = {
    ".py", ".env", ".yaml", ".yml", ".json", ".toml",
    ".cfg", ".ini", ".sh", ".bash", ".zsh",
    ".dockerfile", ".tf", ".tfvars",
}

# Binary extensions to always skip
BINARY_EXTENSIONS = {
    ".whl", ".zip", ".tar", ".gz", ".png", ".jpg", ".jpeg",
    ".gif", ".ico", ".pdf", ".pyc", ".pyo", ".egg",
    ".db", ".sqlite", ".sqlite3",
}

# Patterns for secrets leaked in bash commands
BASH_SECRET_PATTERNS = [
    (
        r"(?:AKIA|sk-|ghp_|gho_|glpat-|npm_|pypi-|sbp_)[A-Za-z0-9_\-]{10,}",
        "API key leaked in command",
    ),
    (
        r"(?:Bearer|token|Authorization)[:\s]+['\"]?[A-Za-z0-9_\-]{20,}",
        "Auth token leaked in command",
    ),
    (
        r"(?:password|passwd|pwd)[=:\s]+['\"]?[^\s'\"]{8,}",
        "Password leaked in command",
    ),
    (
        r"[0-9]{8,10}:[A-Za-z0-9_\-]{35,}",
        "Telegram bot token leaked in command",
    ),
]

COMPILED_BASH_PATTERNS = [(re.compile(p, re.IGNORECASE), msg) for p, msg in BASH_SECRET_PATTERNS]

DEFAULT_MAX_FILE_LINES = 300


def _load_max_file_lines() -> int:
    """Load max_file_lines from vibesrails.yaml guardian config, fallback to 300."""
    try:
        import yaml

        def _safe_yaml_load(stream):
            class _L(yaml.SafeLoader):
                def compose_node(self, parent, index):
                    if self.check_event(yaml.AliasEvent):
                        cnt = getattr(self, '_alias_count', 0) + 1
                        if cnt > 100:
                            raise yaml.YAMLError("YAML alias limit exceeded")
                        self._alias_count = cnt
                    return super().compose_node(parent, index)
            return yaml.load(stream, Loader=_L)

        config_path = Path.cwd() / "vibesrails.yaml"
        if not config_path.exists():
            return DEFAULT_MAX_FILE_LINES
        with open(config_path) as f:
            config = _safe_yaml_load(f)
        if not isinstance(config, dict):
            return DEFAULT_MAX_FILE_LINES
        guardian = config.get("guardian", {})
        if not isinstance(guardian, dict):
            return DEFAULT_MAX_FILE_LINES
        value = guardian.get("max_file_lines", DEFAULT_MAX_FILE_LINES)
        return int(value) if isinstance(value, (int, float, str)) else DEFAULT_MAX_FILE_LINES
    except Exception as e:  # noqa: BLE001
        logger.debug("Config load failed, using default: %s", e)
        return DEFAULT_MAX_FILE_LINES


def scan_bash_command(command: str) -> list[str]:
    """Scan a bash command for leaked secrets."""
    issues = []
    for pattern, message in COMPILED_BASH_PATTERNS:
        if pattern.search(command):
            # Redact the match in output
            redacted = pattern.sub("[REDACTED]", command)
            issues.append(f"  - {message}: {redacted[:80]}")
    return issues


def _should_skip_line(line: str) -> bool:
    """Return True if the line should be excluded from scanning.

    NOTE: The PreToolUse hook intentionally does NOT honor 'vibesrails: ignore'
    comments. That bypass is only for the offline scanner (vibesrails --all).
    An AI agent could inject '# vibesrails: ignore' to disable its own guardrails.
    """
    stripped = line.strip()
    if stripped.startswith("#"):
        return True
    return False


def scan_content(content: str, patterns=None) -> list[str]:
    """Scan content for patterns. Returns list of issues.

    Args:
        content: The text content to scan.
        patterns: Compiled patterns to use. Defaults to COMPILED_PATTERNS (all).
    """
    if patterns is None:
        patterns = COMPILED_PATTERNS
    issues = []
    for line in content.splitlines():
        if _should_skip_line(line):
            continue
        for pattern, message in patterns:
            if pattern.search(line):
                issues.append(f"  - {message}: {line.strip()[:80]}")
                break
    return issues


def main() -> None:
    """CLI entry point -- reads JSON from stdin, exits 1 to block."""
    try:
        data = json.loads(sys.stdin.read())
    except (json.JSONDecodeError, ValueError):
        sys.exit(0)

    tool_name = data.get("tool_name", "")
    tool_input = data.get("tool_input", {})

    # --- Throttle: anti-emballement ---
    try:
        from vibesrails.hooks.throttle import record_check, record_write, should_block

        if tool_name in ("Write", "Edit"):
            if should_block(VIBESRAILS_DIR):
                msg = (
                    "\U0001f6d1 VibesRails THROTTLE: Too many writes without verification.\n"  # vibesrails: ignore
                    "Run pytest, ruff, or vibesrails --all before continuing.\n"
                )
                reminder_path = Path(".claude") / "rules_reminder.md"
                if reminder_path.exists():
                    msg += "\n" + reminder_path.read_text(encoding="utf-8")
                sys.stdout.write(msg)
                sys.exit(1)
            record_write(VIBESRAILS_DIR)

        if tool_name == "Bash":
            command = tool_input.get("command", "")
            if any(cmd in command for cmd in CHECK_COMMANDS):
                record_check(VIBESRAILS_DIR)
    except ImportError:
        pass  # throttle module not installed, skip gracefully

    if tool_name == "Bash":
        command = tool_input.get("command", "")
        issues = scan_bash_command(command) if command else []
        if issues:
            sys.stdout.write("\U0001f534 VibesRails BLOCKED (secret in command):\n")  # vibesrails: ignore
            sys.stdout.write("\n".join(issues) + "\n")  # vibesrails: ignore
            sys.stdout.write("\nUse environment variables instead.\n")  # vibesrails: ignore
            sys.exit(1)
        sys.exit(0)

    # --- PEV: track Read operations ---
    if tool_name == "Read":
        try:
            from vibesrails.pev_tracker import record_read
            record_read()
        except Exception:
            pass
        sys.exit(0)

    if tool_name not in ("Write", "Edit"):
        sys.exit(0)

    file_path = tool_input.get("file_path", "")
    content = tool_input.get("content", "") or tool_input.get("new_string", "") or ""

    # --- For Edit: estimate final file size ---
    if tool_name == "Edit" and file_path:
        old_string = tool_input.get("old_string", "")
        new_string = tool_input.get("new_string", "")
        try:
            existing = Path(file_path).read_text(encoding="utf-8", errors="replace")
            content = existing.replace(old_string, new_string, 1) if old_string else existing
        except OSError:
            pass  # file doesn't exist yet, use new_string as content

    # --- Byte size check (1MB limit) ---
    if content and len(content.encode("utf-8", errors="replace")) > 1_000_000:
        sys.stdout.write("BLOCKED \u2014 Content exceeds 1MB. Split into smaller files.\n")
        sys.exit(1)

    # --- Line count + phase checks via unified session context ---
    session_ctx = None
    try:
        from vibesrails.context import get_session_context
        session_ctx = get_session_context(Path.cwd())
    except Exception:  # noqa: BLE001
        pass  # Graceful degradation

    # --- PEV: Plan enforcement (read-before-write) ---
    try:
        from vibesrails.pev_tracker import check_plan, load_state, record_write

        pev_state = load_state()
        mode_str = None
        if session_ctx:
            mode_str = session_ctx.mode.value if hasattr(session_ctx.mode, "value") else str(session_ctx.mode)
        plan_msg = check_plan(mode_str, pev_state.get("reads", 0))
        if plan_msg:
            if plan_msg.startswith("BLOCKED"):
                sys.stdout.write(f"\u26d4 VibesRails PEV: {plan_msg}\n")
                sys.exit(1)
            else:
                sys.stderr.write(f"\u26a0\ufe0f VibesRails PEV: {plan_msg}\n")
        # Track write operation
        record_write(file_path, pev_state)
    except Exception:  # noqa: BLE001
        pass  # Graceful degradation

    if content:
        line_count = len(content.splitlines())
        max_lines = _load_max_file_lines()
        # Adapt max_lines from session context (mode + phase)
        if session_ctx:
            ctx_max = session_ctx.adapted_config.get(
                "complexity", {}
            ).get("max_file_lines")
            if ctx_max:
                max_lines = ctx_max
        if line_count > max_lines:
            sys.stdout.write(
                f"BLOCKED \u2014 File exceeds {max_lines} lines "
                f"({line_count} lines). Split into modules.\n"
            )
            sys.exit(1)

    # Phase-aware blocking (opt-in via methodology.yaml override only)
    if session_ctx and session_ctx.phase_is_override:
        try:
            from vibesrails.context.phase import PhaseDetector, ProjectPhase

            phase = ProjectPhase(session_ctx.phase)

            if phase == ProjectPhase.DECIDE:
                signals = PhaseDetector(Path.cwd()).collect_signals()
                if not signals.has_adr:
                    sys.stdout.write(
                        "BLOCKED \u2014 Phase DECIDE requires ADR documentation.\n"
                        "Create ADR/ with architecture decisions before writing code.\n"
                        "Run: vibesrails --init-methodology\n"
                    )
                    sys.exit(1)
                if not signals.has_contracts:
                    sys.stdout.write(
                        "BLOCKED \u2014 Phase DECIDE requires contracts "
                        "(typed functions in 3+ files).\n"
                        "Define type annotations on public API "
                        "before implementation.\n"
                    )
                    sys.exit(1)

            if phase in (ProjectPhase.STABILIZE, ProjectPhase.DEPLOY):
                if tool_name == "Write" and file_path:
                    target = Path(file_path)
                    if target.suffix == ".py" and not target.exists():
                        sys.stdout.write(
                            f"BLOCKED \u2014 Phase {phase.name}: "
                            "no new Python files allowed.\n"
                            "Only bug fixes and edits to existing files.\n"
                        )
                        sys.exit(1)
        except Exception:  # noqa: BLE001
            pass  # Graceful degradation

    basename = file_path.rsplit("/", 1)[-1] if "/" in file_path else file_path

    # Determine file extension and scannability
    ext = Path(file_path).suffix.lower() if file_path else ""

    # Handle dotfiles without real extension (e.g. .env, .env.local, .env.production)
    is_dotenv = basename.startswith(".env")

    # Skip binary files explicitly
    if ext in BINARY_EXTENSIONS:
        sys.exit(0)

    # Determine which patterns to apply
    is_python = ext == ".py"
    is_scannable = is_python or ext in SCANNABLE_EXTENSIONS or is_dotenv

    if not is_scannable:
        sys.exit(0)

    if not content:
        sys.exit(0)

    # .py files get full scan (secrets + code patterns); others get secrets only
    if is_python:
        issues = scan_content(content)
    else:
        issues = scan_content(content, patterns=COMPILED_SECRET_PATTERNS)

    if issues:
        sys.stdout.write(f"\U0001f534 VibesRails BLOCKED ({len(issues)} issue(s)):\n")  # vibesrails: ignore
        sys.stdout.write("\n".join(issues) + "\n")  # vibesrails: ignore
        sys.stdout.write("\nFix the code. Add '# vibesrails: ignore' to suppress.\n")  # vibesrails: ignore
        sys.exit(1)

    sys.stdout.write(f"\U0001f7e2 VibesRails: {basename} pre-scan clean\n")  # vibesrails: ignore
    sys.exit(0)


if __name__ == "__main__":
    main()
