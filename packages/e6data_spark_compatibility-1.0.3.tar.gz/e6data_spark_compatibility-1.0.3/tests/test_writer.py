"""
Tests for DataFrameWriter write modes.

Tests cover:
- Write mode validation
- Mode propagation into generated SQL for file writes (parquet, csv, json, orc)
- Mode handling for table writes (saveAsTable, insertInto)
- SQL generation for WRITE INTO with MODE clause
"""
import pytest
from unittest.mock import Mock, MagicMock, patch, call

from e6_spark_compat.sql.writer import DataFrameWriter
from e6_spark_compat.core.sql_generator import SQLGenerator
from e6_spark_compat.core.connection import E6DataConnection
from e6_spark_compat.core.query_plan import TableScan


class TestWriterModeValidation:
    """Test that mode() validates and normalizes input correctly."""

    def setup_method(self):
        self.mock_conn = Mock(spec=E6DataConnection)
        self.plan = TableScan(table_name="sales", columns=["id", "amount"])
        self.writer = DataFrameWriter(self.mock_conn, self.plan)

    def test_default_mode_is_error(self):
        assert self.writer._mode == "error"

    def test_mode_overwrite(self):
        result = self.writer.mode("overwrite")
        assert self.writer._mode == "overwrite"
        assert result is self.writer  # returns self for chaining

    def test_mode_append(self):
        self.writer.mode("append")
        assert self.writer._mode == "append"

    def test_mode_ignore(self):
        self.writer.mode("ignore")
        assert self.writer._mode == "ignore"

    def test_mode_error(self):
        self.writer.mode("error")
        assert self.writer._mode == "error"

    def test_mode_errorifexists_normalizes_to_error(self):
        self.writer.mode("errorifexists")
        assert self.writer._mode == "error"

    def test_mode_case_insensitive(self):
        self.writer.mode("OVERWRITE")
        assert self.writer._mode == "overwrite"

        self.writer.mode("Append")
        assert self.writer._mode == "append"

        self.writer.mode("IGNORE")
        assert self.writer._mode == "ignore"

    def test_mode_invalid_raises_error(self):
        with pytest.raises(ValueError, match="Unknown save mode"):
            self.writer.mode("invalid")

    def test_mode_typo_raises_error(self):
        with pytest.raises(ValueError, match="Unknown save mode"):
            self.writer.mode("overwrit")

    def test_mode_chaining(self):
        result = self.writer.mode("overwrite").format("parquet").partitionBy("year")
        assert self.writer._mode == "overwrite"
        assert self.writer._format == "parquet"
        assert self.writer._partition_by == ["year"]


class TestSQLGeneratorWriteMode:
    """Test that SQLGenerator.build_copy_to_file includes MODE clause."""

    def setup_method(self):
        self.gen = SQLGenerator()
        self.select_sql = "SELECT id, amount FROM sales"
        self.path = "s3://bucket/output"

    def test_overwrite_mode_in_sql(self):
        result = self.gen.build_copy_to_file(
            self.select_sql, self.path, "PARQUET",
            {"SINGLE": "FALSE", "MODE": "OVERWRITE", "MAX_FILE_SIZE": 5000000000}
        )
        assert "MODE OVERWRITE" in result
        assert "WRITE INTO" in result

    def test_append_mode_in_sql(self):
        result = self.gen.build_copy_to_file(
            self.select_sql, self.path, "PARQUET",
            {"SINGLE": "FALSE", "MODE": "APPEND", "MAX_FILE_SIZE": 5000000000}
        )
        assert "MODE APPEND" in result

    def test_ignore_mode_in_sql(self):
        result = self.gen.build_copy_to_file(
            self.select_sql, self.path, "CSV",
            {"SINGLE": "FALSE", "MODE": "IGNORE", "MAX_FILE_SIZE": 5000000000}
        )
        assert "MODE IGNORE" in result

    def test_no_mode_when_not_specified(self):
        result = self.gen.build_copy_to_file(
            self.select_sql, self.path, "PARQUET",
            {"SINGLE": "FALSE", "MAX_FILE_SIZE": 5000000000}
        )
        assert "MODE" not in result

    def test_mode_appears_after_file_format(self):
        result = self.gen.build_copy_to_file(
            self.select_sql, self.path, "PARQUET",
            {"SINGLE": "FALSE", "MODE": "OVERWRITE", "MAX_FILE_SIZE": 5000000000}
        )
        file_format_pos = result.index("FILE_FORMAT")
        mode_pos = result.index("MODE OVERWRITE")
        max_file_pos = result.index("MAX_FILE_SIZE")
        assert file_format_pos < mode_pos < max_file_pos

    def test_mode_not_duplicated_in_other_options(self):
        result = self.gen.build_copy_to_file(
            self.select_sql, self.path, "PARQUET",
            {"SINGLE": "FALSE", "MODE": "OVERWRITE", "MAX_FILE_SIZE": 5000000000}
        )
        assert result.count("MODE") == 1

    def test_full_write_sql_structure(self):
        """Test that the complete WRITE INTO matches e6data syntax."""
        result = self.gen.build_copy_to_file(
            self.select_sql, self.path, "PARQUET",
            {"SINGLE": "FALSE", "MODE": "OVERWRITE", "MAX_FILE_SIZE": 5000000000}
        )
        lines = result.strip().split("\n")
        assert lines[0] == f"WRITE INTO '{self.path}'"
        assert lines[1].startswith("FROM (")
        assert "SINGLE FALSE" in result
        assert "FILE_FORMAT PARQUET" in result
        assert "MODE OVERWRITE" in result
        assert "MAX_FILE_SIZE 5000000000" in result


class TestWriterFileWriteModes:
    """Test that write modes flow through to SQL for file-based writes."""

    def setup_method(self):
        self.mock_conn = Mock(spec=E6DataConnection)
        self.mock_cursor = Mock()
        self.mock_conn.cursor.return_value = self.mock_cursor
        self.plan = TableScan(table_name="sales", columns=["id", "amount"])

    def _capture_executed_sql(self):
        """Return the SQL string passed to cursor.execute()."""
        return self.mock_cursor.execute.call_args[0][0]

    def test_parquet_overwrite(self):
        writer = DataFrameWriter(self.mock_conn, self.plan)
        writer.mode("overwrite").parquet("s3://bucket/output")
        sql = self._capture_executed_sql()
        assert "MODE OVERWRITE" in sql
        assert "FILE_FORMAT PARQUET" in sql

    def test_parquet_append(self):
        writer = DataFrameWriter(self.mock_conn, self.plan)
        writer.mode("append").parquet("s3://bucket/output")
        sql = self._capture_executed_sql()
        assert "MODE APPEND" in sql

    def test_parquet_ignore(self):
        writer = DataFrameWriter(self.mock_conn, self.plan)
        writer.mode("ignore").parquet("s3://bucket/output")
        sql = self._capture_executed_sql()
        assert "MODE IGNORE" in sql

    def test_parquet_default_error_mode_no_mode_clause(self):
        writer = DataFrameWriter(self.mock_conn, self.plan)
        writer.parquet("s3://bucket/output")
        sql = self._capture_executed_sql()
        assert "MODE" not in sql

    def test_csv_overwrite(self):
        writer = DataFrameWriter(self.mock_conn, self.plan)
        writer.mode("overwrite").csv("s3://bucket/output")
        sql = self._capture_executed_sql()
        assert "MODE OVERWRITE" in sql
        assert "FILE_FORMAT CSV" in sql

    def test_csv_append(self):
        writer = DataFrameWriter(self.mock_conn, self.plan)
        writer.mode("append").csv("s3://bucket/output")
        sql = self._capture_executed_sql()
        assert "MODE APPEND" in sql

    def test_json_overwrite(self):
        writer = DataFrameWriter(self.mock_conn, self.plan)
        writer.mode("overwrite").json("s3://bucket/output")
        sql = self._capture_executed_sql()
        assert "MODE OVERWRITE" in sql
        assert "FILE_FORMAT JSON" in sql

    def test_json_append(self):
        writer = DataFrameWriter(self.mock_conn, self.plan)
        writer.mode("append").json("s3://bucket/output")
        sql = self._capture_executed_sql()
        assert "MODE APPEND" in sql

    def test_save_with_format_overwrite(self):
        writer = DataFrameWriter(self.mock_conn, self.plan)
        writer.format("parquet").mode("overwrite").save("s3://bucket/output")
        sql = self._capture_executed_sql()
        assert "MODE OVERWRITE" in sql

    def test_save_with_format_append(self):
        writer = DataFrameWriter(self.mock_conn, self.plan)
        writer.format("parquet").mode("append").save("s3://bucket/output")
        sql = self._capture_executed_sql()
        assert "MODE APPEND" in sql

    def test_parquet_mode_via_param(self):
        """Test mode passed directly to parquet() method."""
        writer = DataFrameWriter(self.mock_conn, self.plan)
        writer.parquet("s3://bucket/output", mode="overwrite")
        sql = self._capture_executed_sql()
        assert "MODE OVERWRITE" in sql

    def test_csv_mode_via_param(self):
        """Test mode passed directly to csv() method."""
        writer = DataFrameWriter(self.mock_conn, self.plan)
        writer.csv("s3://bucket/output", mode="append")
        sql = self._capture_executed_sql()
        assert "MODE APPEND" in sql

    def test_parquet_with_partition_and_mode(self):
        writer = DataFrameWriter(self.mock_conn, self.plan)
        writer.mode("overwrite").partitionBy("region").parquet("s3://bucket/output")
        sql = self._capture_executed_sql()
        assert "MODE OVERWRITE" in sql
        assert "PARTITIONED_BY" in sql

    def test_overwrite_with_compression(self):
        writer = DataFrameWriter(self.mock_conn, self.plan)
        writer.mode("overwrite").parquet("s3://bucket/output", compression="snappy")
        sql = self._capture_executed_sql()
        assert "MODE OVERWRITE" in sql
        assert "COMPRESSION 'snappy'" in sql


class TestWriterTableWriteModes:
    """Test that write modes work correctly for table-based writes."""

    def setup_method(self):
        self.mock_conn = Mock(spec=E6DataConnection)
        self.mock_cursor = Mock()
        self.mock_conn.cursor.return_value = self.mock_cursor
        self.plan = TableScan(table_name="sales", columns=["id", "amount"])

    def _capture_executed_sql(self):
        return self.mock_cursor.execute.call_args[0][0]

    def test_save_as_table_overwrite(self):
        writer = DataFrameWriter(self.mock_conn, self.plan)
        writer.mode("overwrite").saveAsTable("output_table")
        sql = self._capture_executed_sql()
        assert "CREATE OR REPLACE TABLE" in sql
        assert "output_table" in sql

    def test_save_as_table_append(self):
        writer = DataFrameWriter(self.mock_conn, self.plan)
        writer.mode("append").saveAsTable("output_table")
        sql = self._capture_executed_sql()
        assert "INSERT INTO" in sql
        assert "output_table" in sql

    def test_save_as_table_ignore(self):
        writer = DataFrameWriter(self.mock_conn, self.plan)
        writer.mode("ignore").saveAsTable("output_table")
        sql = self._capture_executed_sql()
        assert "CREATE TABLE IF NOT EXISTS" in sql
        assert "output_table" in sql

    def test_save_as_table_error_default(self):
        writer = DataFrameWriter(self.mock_conn, self.plan)
        writer.saveAsTable("output_table")
        sql = self._capture_executed_sql()
        assert "CREATE TABLE " in sql
        assert "IF NOT EXISTS" not in sql
        assert "OR REPLACE" not in sql

    def test_insert_into_default(self):
        writer = DataFrameWriter(self.mock_conn, self.plan)
        writer.insertInto("output_table")
        sql = self._capture_executed_sql()
        assert "INSERT INTO" in sql
        assert "OVERWRITE" not in sql

    def test_insert_into_overwrite_param(self):
        writer = DataFrameWriter(self.mock_conn, self.plan)
        writer.insertInto("output_table", overwrite=True)
        sql = self._capture_executed_sql()
        assert "OVERWRITE" in sql

    def test_insert_into_with_mode_overwrite(self):
        writer = DataFrameWriter(self.mock_conn, self.plan)
        writer.mode("overwrite").insertInto("output_table")
        sql = self._capture_executed_sql()
        assert "OVERWRITE" in sql
