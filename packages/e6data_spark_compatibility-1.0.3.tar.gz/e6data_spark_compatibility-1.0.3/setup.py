from setuptools import setup, find_packages
import os

def get_version():
    """Read version from __init__.py"""
    init_path = os.path.join(os.path.dirname(__file__), 'e6_spark_compat', '__init__.py')
    with open(init_path, 'r') as f:
        for line in f:
            if line.startswith('__version__'):
                return line.split('=')[1].strip().strip('"').strip("'")
    raise RuntimeError("Unable to find version string")

with open("README.md", "r", encoding="utf-8") as fh:
    long_description = fh.read()

setup(
    name="e6data-spark-compatibility",
    version=get_version(),
    author="E6Data",
    author_email="support@e6data.com",
    description="PySpark and Sedona compatibility layer for e6data",
    long_description=long_description,
    long_description_content_type="text/markdown",
    url="https://github.com/e6data/e6-spark-compat",
    project_urls={
        "Bug Reports": "https://github.com/e6data/e6-spark-compat/issues",
        "Source": "https://github.com/e6data/e6-spark-compat",
        "Documentation": "https://github.com/e6data/e6-spark-compat/blob/main/README.md",
    },
    packages=find_packages(exclude=["tests*", "examples*", "docs*", "Azira-usecases-e6data*", "scripts*"]),
    classifiers=[
        "Development Status :: 4 - Beta",
        "Intended Audience :: Developers",
        "Intended Audience :: System Administrators",
        "Topic :: Database",
        "Topic :: Database :: Database Engines/Servers",
        "Topic :: Scientific/Engineering :: GIS",
        "Topic :: Software Development :: Libraries :: Python Modules",
        "License :: OSI Approved :: Apache Software License",
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.7",
        "Programming Language :: Python :: 3.8",
        "Programming Language :: Python :: 3.9",
        "Programming Language :: Python :: 3.10",
        "Programming Language :: Python :: 3.11",
        "Programming Language :: Python :: 3.12",
        "Operating System :: OS Independent",
    ],
    keywords="pyspark spark sql dataframe e6data compatibility sedona spatial",
    python_requires=">=3.7",
    install_requires=[
        "e6data-python-connector>=2.3.10",
        "pandas>=1.0.0",
        "numpy>=1.18.0",
        # sqlglot is vendored in e6_spark_compat/_vendor/sqlglot
    ],
    extras_require={
        "dev": [
            "pytest>=6.0",
            "pytest-cov>=2.0",
            "pytest-html>=3.0",
            "black>=22.0",
            "flake8>=3.8",
            "mypy>=0.910",
            "duckdb>=1.0.0",
            # Optional oracle dependency — pulls real Apache PySpark for the
            # tests/oracle/ suite which uses pyspark.local[*] as ground truth.
            # Requires Java 11/17 on PATH. tests/oracle/ skips cleanly without it.
            "pyspark>=3.5,<4.0",
        ],
        "spatial": [
            "geopandas>=0.10.0",
            "shapely>=1.8.0",
        ],
    },
)