"""
Schema cache for avoiding unnecessary SQL executions
"""
import json
import os
from typing import Dict, List, Optional
import re
import logging

logger = logging.getLogger(__name__)

class SchemaCache:
    """Cache for table schemas to avoid LIMIT 0 queries"""
    
    def __init__(self, schema_file_path: Optional[str] = None):
        self._schemas: Dict[str, List[Dict[str, str]]] = {}
        
        if schema_file_path and os.path.exists(schema_file_path):
            logger.debug(f"Loading schema cache from: {schema_file_path}")
            self.load_from_file(schema_file_path)
        else:
            # Try to load from default location
            default_path = os.getenv('SCHEMA_JSON_PATH', os.path.join(os.path.dirname(os.path.dirname(os.path.dirname(__file__))), 'table_schemas.json'))
            logger.debug(f"Looking for schema cache at default path: {default_path}")
            if os.path.exists(default_path):
                logger.debug(f"Found schema cache at: {default_path}")
                self.load_from_file(default_path)
            else:
                logger.warning(f"No schema cache found at: {default_path}")
    
    def load_from_file(self, file_path: str):
        """Load schemas from JSON file"""
        with open(file_path, 'r') as f:
            self._schemas = json.load(f)
            logger.debug(f"Loaded schemas for {len(self._schemas)} tables")
    
    def get_columns_for_table(self, table_name: str) -> Optional[List[str]]:
        """Get column names for a specific table"""
        if table_name in self._schemas:
            return [col['name'] for col in self._schemas[table_name]]
        return None
    
    def get_columns_from_path(self, path: str) -> Optional[List[str]]:
        """Try to extract table name from path and get columns"""
        # Extract the directory name before the last forward slash
        # Examples:
        # s3a://bucket/freecharge/global_transaction/global_transaction_1.parquet -> global_transaction
        # s3a://bucket/freecharge/merchant/* -> merchant
        # s3a://bucket/daily_transaction_summary_partitioned/* -> daily_transaction_summary_partitioned
        
        # Split the path and get the second-to-last component
        parts = path.rstrip('/').split('/')
        if len(parts) >= 2:
            # Get the directory name (second to last part if file, last part if directory)
            if parts[-1].endswith('.parquet') or parts[-1] == '*':
                # It's a file or wildcard, get the parent directory
                potential_table = parts[-2]
            else:
                # It's a directory path
                potential_table = parts[-1]
            
            logger.debug(f"Extracted potential table name: {potential_table} from path: {path}")
            
            # Try exact match first
            if potential_table in self._schemas:
                return self.get_columns_for_table(potential_table)
        
        return None
    
    def has_schema(self, table_name: str) -> bool:
        """Check if schema exists for table"""
        return table_name in self._schemas

