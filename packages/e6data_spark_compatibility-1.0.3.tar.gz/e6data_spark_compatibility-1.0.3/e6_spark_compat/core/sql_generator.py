"""
SQLGlot-based SQL generation and optimization for e6-spark-compat.

This module provides a central interface for generating and optimizing SQL
using the SQLGlot library, replacing manual string concatenation with
professional AST-based SQL generation.
"""
from e6_spark_compat._vendor import sqlglot as sg
from e6_spark_compat._vendor.sqlglot import optimizer, expressions as exp
from e6_spark_compat._vendor.sqlglot.dialects import e6
from typing import List, Optional, Dict, Any, Union, Tuple
import logging

# Global configuration for CTE usage
# Set to False to disable CTE creation globally
_GLOBAL_USE_CTE = True


def set_use_cte(enabled: bool):
    """
    Set whether to use CTEs globally.

    Args:
        enabled: If True, CTEs will be used. If False, nested queries will be used instead.

    Example:
        from e6_spark_compat.core.sql_generator import set_use_cte
        set_use_cte(False)  # Disable CTE creation
    """
    global _GLOBAL_USE_CTE
    _GLOBAL_USE_CTE = enabled


def get_use_cte() -> bool:
    """Get the current global CTE setting."""
    return _GLOBAL_USE_CTE


class SQLGenerator:
    """
    Central SQL generation service using SQLGlot package.
    
    This class provides methods to build and optimize SQL queries using
    SQLGlot's AST-based approach, ensuring proper SQL generation and
    automatic optimization.
    """
    
    def __init__(self, dialect: str = "e6", optimize: bool = False, use_cte: bool = None):
        """
        Initialize SQLGenerator with dialect and optimization settings.

        Args:
            dialect: Target SQL dialect (default: "e6" for e6data)
            optimize: Whether to apply SQLGlot optimization (default: False, due to column resolution issues)
            use_cte: Whether to use CTEs instead of nested queries (default: uses global setting)
        """
        self.dialect = dialect
        self.optimize_flag = optimize
        # Use global setting if not explicitly provided
        self.use_cte = use_cte if use_cte is not None else _GLOBAL_USE_CTE
        self.logger = logging.getLogger(__name__)
        
        # CTE tracking for building WITH clauses
        self.cte_counter = 0
        self.cte_definitions = []  # List of (name, sql) tuples
        self.cte_mode = False  # Flag to indicate we're in CTE building mode
    
    @staticmethod
    def quote_identifier(identifier: str) -> str:
        """
        Quote an identifier (column/table name) if not already quoted.
        
        Args:
            identifier: The identifier to quote
            
        Returns:
            Quoted identifier
        """
        if identifier.startswith('"') and identifier.endswith('"'):
            # Already quoted
            return identifier
        return f'"{identifier}"'
    
    def optimize_query(self, query: Union[str, exp.Expression],
                      pretty: bool = False) -> str:
        """
        Optimize a SQL query using SQLGlot optimizer if optimization is enabled.

        Args:
            query: SQL string or SQLGlot Expression to optimize
            pretty: Whether to format the output SQL nicely

        Returns:
            Optimized SQL string (or original if optimization is disabled/fails)
        """
        # Check if query contains functions that SQLGlot corrupts during parsing
        # Skip optimization entirely for such queries
        if isinstance(query, str) and self._contains_problematic_functions(query):
            fixed_sql = self._fix_join_column_qualification(query)
            fixed_sql = self._fix_column_ambiguity(fixed_sql)
            return fixed_sql

        if not self.optimize_flag:
            sql_result = self._to_sql(query, pretty)
            # Still apply JOIN qualification and column ambiguity fixes even when optimization is disabled
            fixed_sql = self._fix_join_column_qualification(sql_result)
            fixed_sql = self._fix_column_ambiguity(fixed_sql)
            return fixed_sql

        try:
            # Convert to AST and optimize
            ast = self._to_ast(query)
            optimized_ast = optimizer.optimize(ast)
            sql_result = optimized_ast.sql(dialect=self.dialect, pretty=pretty)

            # Post-process to fix JOIN column qualification and column ambiguity issues
            fixed_sql = self._fix_join_column_qualification(sql_result)
            fixed_sql = self._fix_column_ambiguity(fixed_sql)
            return fixed_sql

        except Exception as e:
            self.logger.error(f"Failed to optimize query: {e}")
            # Return original query if optimization fails
            return self._to_sql(query, pretty)
    
    def _to_ast(self, query: Union[str, exp.Expression]) -> exp.Expression:
        """
        Convert query to SQLGlot AST if needed.
        
        Args:
            query: SQL string or SQLGlot Expression
            
        Returns:
            SQLGlot Expression AST
        """
        if isinstance(query, str):
            return sg.parse_one(query)
        return query
    
    def _to_sql(self, query: Union[str, exp.Expression], pretty: bool = False) -> str:
        """
        Convert query to SQL string.
        
        Args:
            query: SQL string or SQLGlot Expression
            pretty: Whether to format the output SQL nicely
            
        Returns:
            SQL string
        """
        if isinstance(query, str):
            return query
        return query.sql(dialect=self.dialect, pretty=pretty)
    
    def build_select(self, columns: List[Union[str, exp.Expression]], 
                    from_table: Union[str, exp.Expression],
                    where: Optional[Union[str, exp.Expression]] = None,
                    order_by: Optional[List[Union[str, exp.Expression]]] = None,
                    limit: Optional[int] = None) -> str:
        """
        Build a SELECT statement using SQLGlot.
        
        Args:
            columns: List of column names or expressions to select
            from_table: Table name or subquery expression
            where: Optional WHERE condition
            order_by: Optional ORDER BY columns
            limit: Optional LIMIT value
            
        Returns:
            Optimized SELECT SQL string
        """
        # Build SELECT with columns
        query = sg.select(*columns).from_(from_table)
        
        # Add WHERE clause if provided
        if where:
            query = query.where(where)
        
        # Add ORDER BY if provided
        if order_by:
            query = query.order_by(*order_by)
        
        # Add LIMIT if provided
        if limit is not None:
            query = query.limit(limit)
        
        return self.optimize_query(query)
    
    def build_project(self, child_sql: str, 
                     expressions: Dict[str, str], alias_hint: Optional[str] = None) -> str:
        """
        Build a projection (SELECT with aliases) from a child query.
        
        Args:
            child_sql: Child query SQL string
            expressions: Dict of {alias: expression} for projections
            alias_hint: Optional hint for CTE naming
            
        Returns:
            Optimized projection SQL string
        """
        # Don't create CTE for simple projections that just select * or rename columns
        # Only create CTEs when there's actual complexity
        should_use_cte = self.use_cte and self.cte_mode and (
            len(child_sql) > 500 or  # Very complex query
            "JOIN" in child_sql or    # Has joins
            "GROUP BY" in child_sql   # Has aggregations
        )
        
        if should_use_cte:
            cte_ref = self.register_cte(child_sql, alias_hint)
            from_clause = cte_ref
        else:
            from_clause = f"({child_sql})"
        
        # Build projections with aliases
        projections = []
        has_dataframe_star = False
        
        for alias, expr in expressions.items():
            if alias == "__DATAFRAME_STAR__":
                # Special marker for df["*"] - we'll handle this differently
                has_dataframe_star = True
            elif alias == expr:
                # No alias needed - but still quote if it's a simple column name
                # Handle qualified star expressions like "a.*" 
                if expr.endswith(".*") and "." in expr:
                    # This is a qualified star expression like "a.*"
                    table_alias = expr[:-2]  # Remove ".*"
                    
                    # Check if we're in a context where this table alias might not be available
                    # This happens when we're selecting from a CTE that contains a JOIN
                    if should_use_cte and ("JOIN" in child_sql):
                        # In this case, convert the qualified star to unqualified star
                        # since the table alias is internal to the CTE and not accessible
                        projections.append("*")
                    else:
                        quoted_table = self.quote_identifier(table_alias)
                        projections.append(f'{quoted_table}.*')
                elif expr != "*" and not any(op in expr for op in ['(', '+', '-', '*', 'CASE', 'CAST']):
                    # Check if this is a struct field access pattern
                    if '.' in expr and not expr.startswith('"'):
                        # Possibly struct field access - don't quote the entire expression
                        # Add with alias to make the column referenceable later
                        quoted_alias = self.quote_identifier(alias)
                        projections.append(f'{expr} AS {quoted_alias}')
                    else:
                        projections.append(self.quote_identifier(expr))
                else:
                    projections.append(expr)
            else:
                # Add alias with quotes
                quoted_alias = self.quote_identifier(alias)
                projections.append(f'{expr} AS {quoted_alias}')
        
        # Handle the special case where we need to use * literally
        if has_dataframe_star:
            # If we also have other columns, we need to combine them
            if projections:
                # Build manually: SELECT *, other_columns FROM ...
                other_cols = ", ".join(projections)
                return f"SELECT *, {other_cols} FROM {from_clause}"
            else:
                # Just SELECT * FROM ...
                return f"SELECT * FROM {from_clause}"
        
        # Create SELECT from subquery/CTE
        proj_str = ", ".join(projections) if projections else "*"
        return f"SELECT {proj_str} FROM {from_clause}"
    
    def build_filter(self, child_sql: str, condition: str, alias_hint: Optional[str] = None) -> str:
        """
        Add a WHERE clause to a child query.
        
        Args:
            child_sql: Child query SQL string
            condition: WHERE condition string
            alias_hint: Optional hint for CTE naming
            
        Returns:
            Optimized filtered SQL string
        """
        # Don't create CTE for simple filters unless the child is complex
        should_use_cte = self.use_cte and self.cte_mode and (
            len(child_sql) > 500 or  # Very complex query
            "JOIN" in child_sql or    # Has joins
            child_sql.count("SELECT") > 2  # Multiple nested SELECTs
        )
        
        if should_use_cte:
            cte_ref = self.register_cte(child_sql, alias_hint)
            from_clause = cte_ref
        else:
            from_clause = f"({child_sql})"
        
        # Build SELECT with WHERE clause
        return f"SELECT * FROM {from_clause} WHERE {condition}"
    
    def build_join(self, left_sql: str, right_sql: str,
                  on_condition: str, join_type: str = "INNER",
                  left_alias: Optional[str] = None, right_alias: Optional[str] = None,
                  left_columns: Optional[List[str]] = None, right_columns: Optional[List[str]] = None) -> str:
        """
        Build a JOIN between two queries.
        
        Args:
            left_sql: Left query SQL string
            right_sql: Right query SQL string
            on_condition: JOIN ON condition
            join_type: Type of join (INNER, LEFT, RIGHT, FULL, CROSS)
            left_alias: Optional custom alias for left table
            right_alias: Optional custom alias for right table
            left_columns: Optional column list for left table (for intelligent qualification)
            right_columns: Optional column list for right table (for intelligent qualification)
            
        Returns:
            Optimized JOIN SQL string
        """
        # Create aliases for subqueries (use custom aliases if provided)
        left_alias_name = left_alias if left_alias else "left_t"
        right_alias_name = right_alias if right_alias else "right_t"
        
        # If using CTEs, register both queries with meaningful aliases
        if self.use_cte and self.cte_mode:
            # Check if left_sql and right_sql are already CTE references (simple names without spaces/parens)
            left_is_cte_ref = (left_sql and 
                             not left_sql.strip().startswith('(') and 
                             not ' ' in left_sql.strip() and 
                             not left_sql.strip().startswith('SELECT'))
            right_is_cte_ref = (right_sql and 
                              not right_sql.strip().startswith('(') and 
                              not ' ' in right_sql.strip() and 
                              not right_sql.strip().startswith('SELECT'))
            
            # For CTE references, use them directly; for complex queries, register as CTEs
            if left_is_cte_ref:
                left_ref = left_sql.strip()
            else:
                left_ref = self.register_cte(left_sql, left_alias_name)
                
            if right_is_cte_ref:
                right_ref = right_sql.strip()
            else:
                right_ref = self.register_cte(right_sql, right_alias_name)
            
            # When referencing CTEs, we can use them directly since they already have good names
            quoted_left_alias = self.quote_identifier(left_alias_name)
            quoted_right_alias = self.quote_identifier(right_alias_name)
            left_from = left_ref if left_ref == left_alias_name else f"{left_ref} AS {quoted_left_alias}"
            right_from = right_ref if right_ref == right_alias_name else f"{right_ref} AS {quoted_right_alias}"
        else:
            quoted_left_alias = self.quote_identifier(left_alias_name)
            quoted_right_alias = self.quote_identifier(right_alias_name)
            # If the inner SQL is already an aliased subquery (Alias plan node
            # rendered it as `(...) AS <name>`), don't wrap it again — that
            # produces invalid `((...) AS x) AS x` syntax. Use the inner SQL
            # as-is; the alias already matches what the JOIN needs to reference.
            import re

            def _is_already_aliased(sql: str, alias: str) -> bool:
                # Strip whitespace; check for trailing ` AS <alias>` (with or
                # without quotes), preceded by a closing paren.
                pattern = rf'\)\s+AS\s+"?{re.escape(alias)}"?\s*$'
                return bool(re.search(pattern, sql.strip(), re.IGNORECASE))

            if left_alias and _is_already_aliased(left_sql, left_alias):
                left_from = left_sql
            else:
                left_from = f"({left_sql}) AS {quoted_left_alias}"
            if right_alias and _is_already_aliased(right_sql, right_alias):
                right_from = right_sql
            else:
                right_from = f"({right_sql}) AS {quoted_right_alias}"

        # Qualify column names in ON condition to prevent ambiguous references
        qualified_condition = self._qualify_join_condition(on_condition, left_alias_name, right_alias_name, left_columns, right_columns)

        # Extract columns referenced in the ON condition to ensure they're included
        condition_columns = self._extract_columns_from_condition(qualified_condition)
        
        # For condition columns, we need to determine which table they belong to
        # We'll use a smarter approach: only add columns to tables that might logically have them
        
        # If we don't have column lists, we can't do smart inclusion, so use fallback
        if not left_columns or not right_columns:
            # Fallback to basic behavior when we don't have schema information
            pass
        else:
            # Strategy: analyze the qualified condition to determine column ownership
            # Look for patterns like "left_alias"."column" = "right_alias"."column"
            condition_mapping = self._analyze_condition_column_ownership(qualified_condition, left_alias_name, right_alias_name)
            
            for col in condition_columns:
                # Check if we can determine ownership from the condition structure
                if col in condition_mapping:
                    table_side = condition_mapping[col]
                    if table_side == 'left' and col not in left_columns:
                        left_columns.append(col)
                    elif table_side == 'right' and col not in right_columns:
                        right_columns.append(col)
                else:
                    # If we can't determine ownership, only add to tables that already have similar columns
                    # This prevents adding unrelated columns to the wrong table
                    
                    # Check if the column logically belongs to left table (exists or similar pattern)
                    if self._column_likely_belongs_to_table(col, left_columns) and col not in left_columns:
                        left_columns.append(col)
                    
                    # Check if the column logically belongs to right table
                    if self._column_likely_belongs_to_table(col, right_columns) and col not in right_columns:
                        right_columns.append(col)

        # Build JOIN query with explicit column selection to preserve table qualifications
        if join_type.upper() == "CROSS":
            # For CROSS JOIN, we still need qualified aliases when using table aliases to support col("a.column") references
            if self.use_cte and self.cte_mode and left_columns and right_columns and (left_alias or right_alias):
                left_cols = []
                right_cols = []
                
                for col in left_columns:
                    if col != "*":
                        # Check if this is already a qualified column name
                        is_qualified = '.' in col
                        if is_qualified:
                            # Skip already qualified columns
                            continue
                        else:
                            # Just select the column normally for CROSS JOIN
                            left_cols.append(f"{quoted_left_alias}.\"{col}\"")
                
                for col in right_columns:
                    if col != "*":
                        # Check if this is already a qualified column name
                        is_qualified = '.' in col
                        if is_qualified:
                            # Skip already qualified columns
                            continue
                        else:
                            # Just select the column normally for CROSS JOIN
                            right_cols.append(f"{quoted_right_alias}.\"{col}\"")
                
                if left_cols or right_cols:
                    all_cols = left_cols + right_cols
                    return f"SELECT {', '.join(all_cols)} FROM {left_from} CROSS JOIN {right_from}"
            
            # Fallback to SELECT * if no special handling needed
            return f"SELECT * FROM {left_from} CROSS JOIN {right_from}"
        else:
            # For Spark DataFrame JOINs, always use SELECT * 
            # Spark handles column conflicts automatically by keeping both columns
            # Only use explicit column selection for very specific edge cases
            
            # Always use SELECT * for DataFrame JOINs - this matches Spark behavior
            return f"SELECT * FROM {left_from} {join_type.upper()} JOIN {right_from} ON {qualified_condition}"
    
    def _qualify_join_condition(self, condition: str, left_alias: str, right_alias: str, 
                               left_columns: Optional[List[str]] = None, right_columns: Optional[List[str]] = None) -> str:
        """
        Qualify column names in JOIN ON condition with table aliases.
        
        This method parses patterns like:
        - "col1" = "col2" -> left_alias."col1" = right_alias."col2"
        - "col" = "col" -> left_alias."col" = right_alias."col"
        - col1 = col2 -> left_alias.col1 = right_alias.col2
        - users.id = user_id -> users.id = right_alias.user_id (mixed case)
        
        In CTE mode, qualified column references use underscore separators instead of dots.
        
        Already fully qualified columns (table.column = table.column) are left unchanged.
        
        Args:
            condition: Original JOIN condition
            left_alias: Left table alias
            right_alias: Right table alias
            
        Returns:
            Qualified JOIN condition
        """
        import re
        
        # Disabled CTE mode qualified column reference conversion as it creates more problems
        # The underscore strategy (a_txn_date) is incompatible with complex JOIN chains
        if False:  # self.use_cte and self.cte_mode:
            pass
        
        # Check for already qualified conditions with quoted table.column patterns
        # Pattern to detect "table"."column" references
        quoted_qualified_full_pattern = r'"([^"]+)"\."([^"]+)"'
        qualified_matches = re.findall(quoted_qualified_full_pattern, condition)
        if qualified_matches:
            # Extract unique table names from the condition
            table_names_in_condition = list(dict.fromkeys(tbl for tbl, _ in qualified_matches))

            if len(table_names_in_condition) >= 2:
                # In CTE mode, original table names must be replaced with CTE aliases
                # because the FROM clause references CTEs (left_t/right_t), not the original tables
                if self.use_cte and self.cte_mode:
                    first_table = table_names_in_condition[0]
                    second_table = table_names_in_condition[1]

                    table_to_alias = {}
                    if left_columns is not None and right_columns is not None:
                        for tbl, col_name in qualified_matches:
                            if tbl not in table_to_alias:
                                if col_name in left_columns:
                                    table_to_alias[tbl] = left_alias
                                elif col_name in right_columns:
                                    table_to_alias[tbl] = right_alias

                    # Fall back to positional mapping if column-based didn't resolve
                    if first_table not in table_to_alias:
                        table_to_alias[first_table] = left_alias
                    if second_table not in table_to_alias:
                        if left_alias not in table_to_alias.values():
                            table_to_alias[second_table] = left_alias
                        else:
                            table_to_alias[second_table] = right_alias

                    result = condition
                    for original_table, alias in table_to_alias.items():
                        result = result.replace(f'"{original_table}".', f'{alias}.')
                    self.logger.debug(f"Replaced table names in JOIN condition: {table_to_alias}")
                    return result
                else:
                    # Non-CTE mode: condition is already fully qualified, return as-is
                    self.logger.debug(f"JOIN condition already fully qualified with quoted table.column patterns: '{condition}'")
                    return condition
            elif len(table_names_in_condition) == 1:
                # Single table referenced on both sides — skip, let downstream logic handle
                pass

        # Check if condition is already fully qualified (both sides have dots) - for simple cases
        parts = condition.split('=')
        if len(parts) == 2:
            left_part = parts[0].strip()
            right_part = parts[1].strip()

            # Check for already qualified conditions like a.col = b.col patterns (simple qualified)
            if ('.' in left_part and '.' in right_part) and ('"' not in left_part and '"' not in right_part):
                self.logger.debug(f"JOIN condition already fully qualified: '{condition}'")
                return condition
        
        # Pattern to match quoted identifiers in equality conditions
        quoted_pattern = r'"([^"]+)"\s*=\s*"([^"]+)"'
        
        def qualify_quoted_match(match):
            """Qualify a quoted column comparison using intelligent column-based logic."""
            first_col = match.group(1)
            second_col = match.group(2)
            
            
            # If we have column information, use it to determine correct table assignment
            if left_columns is not None and right_columns is not None:
                # Check if we have qualified column aliases in the tables (like "a.txn_date")
                # This happens when CTEs contain qualified aliases from previous JOINs
                
                # Look for qualified aliases that match the column being referenced
                left_qualified_col = None
                right_qualified_col = None
                
                # For first_col, check if there's a qualified alias in either table
                # Check both for exact match and for qualified alias ending with the column name
                for col in left_columns:
                    if col == first_col or col.endswith('.' + first_col):  # exact match or "a.txn_date" ends with ".txn_date"
                        left_qualified_col = col
                        break
                
                for col in right_columns:
                    if col == second_col or col.endswith('.' + second_col):  # exact match or "b.txn_date" ends with ".txn_date"
                        right_qualified_col = col
                        break
                
                # If we found qualified aliases, use them
                if left_qualified_col and right_qualified_col:
                    left_qualified = f'{left_alias}."{left_qualified_col}"'
                    right_qualified = f'{right_alias}."{right_qualified_col}"'
                    self.logger.debug(f"Using qualified aliases: {left_qualified_col} -> left, {right_qualified_col} -> right")
                    return f'{left_qualified} = {right_qualified}'
                elif left_qualified_col:
                    # Left has qualified alias, right might be regular column
                    left_qualified = f'{left_alias}."{left_qualified_col}"'
                    if second_col in right_columns:
                        right_qualified = f'{right_alias}."{second_col}"'
                    else:
                        # Look for qualified alias for second_col too
                        for col in right_columns:
                            if col.endswith('.' + second_col):
                                right_qualified = f'{right_alias}."{col}"'
                                break
                        else:
                            right_qualified = f'{right_alias}."{second_col}"'
                    self.logger.debug(f"Mixed qualification: {left_qualified_col} -> left, {second_col} -> right")
                    return f'{left_qualified} = {right_qualified}'
                elif right_qualified_col:
                    # Right has qualified alias, left might be regular column
                    if first_col in left_columns:
                        left_qualified = f'{left_alias}."{first_col}"'
                    else:
                        # Look for qualified alias for first_col
                        for col in left_columns:
                            if col.endswith('.' + first_col):
                                left_qualified = f'{left_alias}."{col}"'
                                break
                        else:
                            left_qualified = f'{left_alias}."{first_col}"'
                    right_qualified = f'{right_alias}."{right_qualified_col}"'
                    self.logger.debug(f"Mixed qualification: {first_col} -> left, {right_qualified_col} -> right")
                    return f'{left_qualified} = {right_qualified}'
                
                # Check which table each column belongs to (original logic)
                first_in_left = first_col in left_columns
                first_in_right = first_col in right_columns
                second_in_left = second_col in left_columns
                second_in_right = second_col in right_columns
                
                # Also check for qualified column matches if direct match fails
                if not first_in_left and not first_in_right:
                    # Check if first_col exists as a qualified alias in either table
                    for col in left_columns:
                        if col.endswith('.' + first_col):
                            first_in_left = True
                            left_qualified_col = col
                            break
                    for col in right_columns:
                        if col.endswith('.' + first_col):
                            first_in_right = True
                            right_qualified_col = col
                            break
                            
                if not second_in_left and not second_in_right:
                    # Check if second_col exists as a qualified alias in either table
                    for col in left_columns:
                        if col.endswith('.' + second_col):
                            second_in_left = True
                            if not left_qualified_col:
                                left_qualified_col = col
                            break
                    for col in right_columns:
                        if col.endswith('.' + second_col):
                            second_in_right = True
                            if not right_qualified_col:
                                right_qualified_col = col
                            break
                
                # Handle the case where both columns have the same name (e.g., txn_date = txn_date)
                if first_col == second_col:
                    # Both sides reference the same column name, assign one to each table
                    # Prefer qualified column names if available
                    left_col_name = left_qualified_col if left_qualified_col and (left_qualified_col == first_col or left_qualified_col.endswith('.' + first_col)) else first_col
                    right_col_name = right_qualified_col if right_qualified_col and (right_qualified_col == second_col or right_qualified_col.endswith('.' + second_col)) else second_col
                    left_qualified = f'{left_alias}."{left_col_name}"'
                    right_qualified = f'{right_alias}."{right_col_name}"'
                    return f'{left_qualified} = {right_qualified}'

                # Handle the case where each column belongs to exactly one table
                elif first_in_left and not first_in_right and second_in_right and not second_in_left:
                    # first_col belongs to left, second_col belongs to right
                    # Use qualified column name if available, otherwise use the original name
                    left_col_name = left_qualified_col if left_qualified_col and left_qualified_col.endswith('.' + first_col) else first_col
                    right_col_name = right_qualified_col if right_qualified_col and right_qualified_col.endswith('.' + second_col) else second_col
                    left_qualified = f'{left_alias}."{left_col_name}"'
                    right_qualified = f'{right_alias}."{right_col_name}"'
                    self.logger.debug(f"Intelligent qualification: {first_col} -> left({left_col_name}), {second_col} -> right({right_col_name})")
                    return f'{left_qualified} = {right_qualified}'

                elif first_in_right and not first_in_left and second_in_left and not second_in_right:
                    # first_col belongs to right, second_col belongs to left  
                    left_col_name = left_qualified_col if left_qualified_col and left_qualified_col.endswith('.' + second_col) else second_col
                    right_col_name = right_qualified_col if right_qualified_col and right_qualified_col.endswith('.' + first_col) else first_col
                    left_qualified = f'{left_alias}."{left_col_name}"'
                    right_qualified = f'{right_alias}."{right_col_name}"'
                    self.logger.debug(f"Intelligent qualification: {first_col} -> right({right_col_name}), {second_col} -> left({left_col_name})")
                    return f'{left_qualified} = {right_qualified}'

                else:
                    # Ambiguous or unresolvable case, log warning and fall back to positional
                    self.logger.warning(f"Column resolution ambiguous: {first_col} in left={first_in_left}/right={first_in_right}, {second_col} in left={second_in_left}/right={second_in_right}")
            
            # Fallback to original positional logic
            left_qualified = f'{left_alias}."{first_col}"'
            right_qualified = f'{right_alias}."{second_col}"'
            return f'{left_qualified} = {right_qualified}'
        
        # Replace quoted patterns first
        qualified_condition = re.sub(quoted_pattern, qualify_quoted_match, condition)
        
        # If quoted patterns were found, we're done
        if qualified_condition != condition:
            self.logger.debug(f"Qualified JOIN condition (quoted): '{condition}' -> '{qualified_condition}'")
            return qualified_condition
        
        # Handle mixed qualified/unqualified and fully unqualified cases
        # Pattern to match: [table.]column = [table.]column
        mixed_pattern = r'(\b(?:[a-zA-Z_][a-zA-Z0-9_]*\.)?[a-zA-Z_][a-zA-Z0-9_]*)\s*=\s*(\b(?:[a-zA-Z_][a-zA-Z0-9_]*\.)?[a-zA-Z_][a-zA-Z0-9_]*)'
        
        def qualify_mixed_match(match):
            """Qualify mixed or unqualified column comparison."""
            left_expr = match.group(1)
            right_expr = match.group(2)
            
            # Skip SQL keywords
            sql_keywords = {'and', 'or', 'not', 'null', 'true', 'false', 'case', 'when', 'then', 'else', 'end'}
            left_col = left_expr.split('.')[-1]  # Get column name part
            right_col = right_expr.split('.')[-1]
            
            if left_col.lower() in sql_keywords or right_col.lower() in sql_keywords:
                return match.group(0)  # Return unchanged
            
            # Qualify left side if not already qualified, and quote column name
            if '.' not in left_expr:
                left_qualified = f'{left_alias}."{left_expr}"'
            else:
                parts = left_expr.split('.', 1)
                left_qualified = f'{parts[0]}."{parts[1]}"'

            # Qualify right side if not already qualified, and quote column name
            if '.' not in right_expr:
                right_qualified = f'{right_alias}."{right_expr}"'
            else:
                parts = right_expr.split('.', 1)
                right_qualified = f'{parts[0]}."{parts[1]}"'

            return f'{left_qualified} = {right_qualified}'
        
        # Apply mixed/unqualified pattern
        qualified_condition = re.sub(mixed_pattern, qualify_mixed_match, condition)
        
        self.logger.debug(f"Qualified JOIN condition: '{condition}' -> '{qualified_condition}'")
        return qualified_condition
    
    def _fix_join_column_qualification(self, sql: str) -> str:
        """
        Post-process SQL to fix JOIN column qualification issues.
        
        This method addresses cases where CTEs contain qualified column aliases 
        (like "a.txn_date") but JOIN conditions reference them as unqualified names.
        """
        import re
        
        
        # Pattern to match JOIN conditions with table aliases
        # Matches: FROM table1 AS "alias1" JOIN table2 AS "alias2" ON "alias1"."col" = "alias2"."col"
        join_pattern = r'FROM\s+(\w+(?:_\d+)?)\s+AS\s+"([^"]+)"\s+((?:FULL\s+|LEFT\s+|RIGHT\s+|INNER\s+)?JOIN)\s+(\w+(?:_\d+)?)\s+AS\s+"([^"]+)"\s+ON\s+"([^"]+)"\."([^"]+)"\s*=\s*"([^"]+)"\."([^"]+)"'
        
        def fix_join_condition(match):
            left_table = match.group(1)  # e.g., "a_3"
            left_alias = match.group(2)  # e.g., "a"
            join_type = match.group(3)   # e.g., "FULL JOIN"
            right_table = match.group(4) # e.g., "b_2"  
            right_alias = match.group(5) # e.g., "b"
            left_alias_in_on = match.group(6)  # e.g., "a"
            left_col = match.group(7)    # e.g., "txn_date"
            right_alias_in_on = match.group(8) # e.g., "b"
            right_col = match.group(9)   # e.g., "txn_date"

            
            # Check if the table contains qualified column aliases by looking earlier in the SQL
            # Look for patterns like SELECT "a"."col" AS "a.col" in the CTE definition
            left_cte_pattern = f'{left_table}\\s+AS\\s+\\(SELECT.*?"([^"]*{re.escape(left_col)}[^"]*)"'
            right_cte_pattern = f'{right_table}\\s+AS\\s+\\(SELECT.*?"([^"]*{re.escape(right_col)}[^"]*)"'
            
            # Search for qualified column names in the CTE definitions
            sql_before_join = sql[:match.start()]
            
            left_cte_match = re.search(left_cte_pattern, sql_before_join, re.DOTALL)
            right_cte_match = re.search(right_cte_pattern, sql_before_join, re.DOTALL)
            
            # Use qualified column names if they exist in the CTE
            final_left_col = left_col
            final_right_col = right_col
            
            if left_cte_match:
                found_col = left_cte_match.group(1)
                if "." in found_col and found_col.endswith(left_col):
                    final_left_col = found_col
            
            if right_cte_match:
                found_col = right_cte_match.group(1)
                if "." in found_col and found_col.endswith(right_col):
                    final_right_col = found_col
            
            # Reconstruct the JOIN
            fixed_join = f'FROM {left_table} AS "{left_alias}" {join_type} {right_table} AS "{right_alias}" ON "{left_alias_in_on}"."{final_left_col}" = "{right_alias_in_on}"."{final_right_col}"'
            return fixed_join
        
        # Apply the fix
        fixed_sql = re.sub(join_pattern, fix_join_condition, sql, flags=re.IGNORECASE | re.DOTALL)
        
        # Column ambiguity is now handled at the union level in unionByName()
        # No need for post-processing fixes that can create inconsistencies
        final_sql = fixed_sql
        
        return final_sql
    
    def _fix_column_ambiguity(self, sql: str) -> str:
        """
        Fix column ambiguity issues caused by case-sensitive duplicates.
        
        This addresses cases where columns with the same name but different case
        (e.g., 'column' and 'COLUMN') appear in the same scope, causing ambiguous 
        column reference errors.
        """
        import re
        from collections import defaultdict
        
        if len(sql) > 10000:  # Only process large queries
            
            # Generic approach: find all quoted column names and detect case conflicts
            # Pattern to match quoted identifiers like "column_name"
            column_pattern = r'"([^"]+)"'
            columns = re.findall(column_pattern, sql)
            
            # Group columns by their lowercase version to detect case conflicts
            case_groups = defaultdict(list)
            for col in set(columns):  # Use set to avoid duplicates
                case_groups[col.lower()].append(col)
            
            # Find columns that have case conflicts (same name, different case)
            conflicts = {base: variants for base, variants in case_groups.items() if len(variants) > 1}
            
            if conflicts:
                
                # For each conflict group, rename all but the first variant
                for base_name, variants in conflicts.items():
                    variants.sort()  # Ensure consistent ordering
                    for i, variant in enumerate(variants[1:], 1):  # Skip first variant
                        # Create unique name by appending case indicator
                        if variant.islower():
                            new_name = f"{variant}_lower"
                        elif variant.isupper():
                            new_name = f"{variant}_upper"
                        else:
                            new_name = f"{variant}_mixed_{i}"
                        
                        # Replace all occurrences of this specific variant (both quoted and unquoted)
                        # 1. Replace quoted references: "variant"
                        quoted_pattern = f'"{re.escape(variant)}"'
                        quoted_replacement = f'"{new_name}"'
                        sql = re.sub(quoted_pattern, quoted_replacement, sql)
                        
                        # 2. Replace unquoted references: variant (but be careful not to match parts of words)
                        # Use word boundaries to ensure we only match complete column names
                        unquoted_pattern = r'\b' + re.escape(variant) + r'\b'
                        sql = re.sub(unquoted_pattern, new_name, sql)

        return sql
    
    def _extract_select_columns(self, sql: str) -> List[str]:
        """Extract column names from a SELECT clause using sqlglot."""
        try:
            ast = sg.parse_one(sql)
            if not isinstance(ast, exp.Select):
                return []
            columns = []
            for expr in ast.expressions:
                if isinstance(expr, exp.Star):
                    return []
                alias = expr.alias
                if alias:
                    columns.append(alias)
                elif isinstance(expr, exp.Column):
                    columns.append(expr.name)
                else:
                    return []
            return columns
        except Exception:
            return []

    def _contains_problematic_functions(self, sql: str) -> bool:
        """Check if SQL contains functions that SQLGlot corrupts during parsing."""
        import re
        # Check for DATE_ADD, DATE_SUB, DATE_DIFF/DATEDIFF with nested function calls
        # These get corrupted by SQLGlot's dialect transformation (argument reordering)
        pattern = r'\bDATE_ADD\s*\(|DATE_SUB\s*\(|DATE_DIFF\s*\(|DATEDIFF\s*\(|TIMESTAMP_ADD\s*\(|TIMESTAMP_DIFF\s*\('
        return bool(re.search(pattern, sql, re.IGNORECASE))

    def _build_aggregate_string_fallback(self, child_sql: str,
                                         group_by: List[str],
                                         aggregates: Dict[str, str],
                                         having: Optional[str] = None) -> str:
        """Build aggregate query using string concatenation (fallback for problematic SQL)."""
        # Build SELECT clause
        select_parts = []
        for col in group_by:
            select_parts.append(f'"{col}"')
        for alias, agg_expr in aggregates.items():
            if alias != agg_expr:
                select_parts.append(f'{agg_expr} AS "{alias}"')
            else:
                select_parts.append(agg_expr)

        select_clause = ", ".join(select_parts)

        # Build GROUP BY clause
        group_by_clause = ", ".join([f'"{col}"' for col in group_by])

        # Build full query
        sql = f"SELECT {select_clause} FROM ({child_sql}) GROUP BY {group_by_clause}"

        if having:
            sql += f" HAVING {having}"

        return sql

    def build_aggregate(self, child_sql: str,
                       group_by: List[str],
                       aggregates: Dict[str, str],
                       having: Optional[str] = None,
                       group_aliases: Optional[Dict[str, str]] = None) -> str:
        """
        Build an aggregate query with GROUP BY.

        Args:
            child_sql: Child query SQL string
            group_by: List of GROUP BY columns
            aggregates: Dict of {alias: aggregate_expression}
            having: Optional HAVING clause
            group_aliases: Dict mapping original column names to aliases

        Returns:
            Optimized aggregate SQL string
        """
        # Check if child SQL contains functions that SQLGlot corrupts
        if self._contains_problematic_functions(child_sql):
            self.logger.debug("Using string fallback for aggregate due to DATE_ADD/DATE_SUB in child SQL")
            return self._build_aggregate_string_fallback(child_sql, group_by, aggregates, having)

        # Parse child query
        child_ast = sg.parse_one(child_sql)
        
        # Build SELECT with group by columns and aggregates
        select_exprs = []
        
        # Add group by columns with aliases if present
        group_aliases = group_aliases or {}
        for col in group_by:
            # Ensure column is quoted for reserved keywords like 'date' and regular columns like 'ims_id'
            # Force quoting by creating a quoted identifier directly
            if isinstance(col, str):
                # Handle "alias.column" — split-quote in non-CTE mode so the
                # GROUP BY reference matches the underlying JOIN's qualifier
                # form (`"alias"."column"`). In CTE mode the JOIN flattens
                # columns into literal-dot aliases like "a.txn_date", so
                # emit a single quoted identifier.
                if '.' in col and not col.startswith('"'):
                    from ..core.sql_generator import get_use_cte
                    table_part, column_part = col.split('.', 1)
                    if get_use_cte():
                        col_expr = sg.exp.Column(this=sg.exp.Identifier(this=col, quoted=True))
                    else:
                        col_expr = sg.exp.Column(
                            this=sg.exp.Identifier(this=column_part, quoted=True),
                            table=sg.exp.Identifier(this=table_part, quoted=True),
                        )
                else:
                    col_expr = sg.exp.Column(this=sg.exp.Identifier(this=col, quoted=True))
                # If this column has an alias, apply it
                if col in group_aliases:
                    alias_name = group_aliases[col]
                    quoted_id = sg.exp.Identifier(this=alias_name, quoted=True)
                    col_expr = col_expr.as_(quoted_id.this, quoted=True)
            else:
                # Handle Expression objects - convert to SQL
                from ..sql.column import Expression
                if isinstance(col, Expression) and hasattr(col, 'to_sql'):
                    # Use the expression's SQL representation
                    col_sql = col.to_sql()
                    col_expr = sg.parse_one(col_sql, into=sg.exp.Expression)
                    
                    # Check if this expression has an alias
                    col_str = str(col)
                    if col_str in group_aliases:
                        alias_name = group_aliases[col_str]
                        quoted_id = sg.exp.Identifier(this=alias_name, quoted=True)
                        col_expr = col_expr.as_(quoted_id.this, quoted=True)
                else:
                    # Fallback for other types
                    col_expr = sg.column(str(col), quoted=True)
                    
            select_exprs.append(col_expr)
        
        # Add aggregate expressions
        for alias, agg_expr in aggregates.items():
            # Parse aggregate expression
            agg_ast = sg.parse_one(agg_expr, into=exp.Expression)
            if alias != agg_expr:
                # Ensure alias is quoted
                quoted_id = sg.exp.Identifier(this=alias, quoted=True)
                agg_ast = agg_ast.as_(quoted_id.this, quoted=True)
            select_exprs.append(agg_ast)
        
        # Build query.
        #
        # Special-case: when the child is a JOIN (`SELECT * FROM ... JOIN ...`),
        # don't wrap it as a derived table — that would hide the JOIN's
        # alias scope from the outer SELECT and any GROUP BY references
        # to `"df1"."col"` would fail validation. Instead, splice the
        # JOIN's FROM clause directly into the aggregate's FROM so the
        # aliases stay visible.
        from_relation = None
        if isinstance(child_ast, sg.exp.Select):
            child_exprs = child_ast.args.get("expressions") or []
            from_expr = child_ast.args.get("from")
            where_expr = child_ast.args.get("where")
            joins = child_ast.args.get("joins") or []
            is_select_star = (
                len(child_exprs) == 1
                and isinstance(child_exprs[0], sg.exp.Star)
                and where_expr is None
                and joins
            )
            if is_select_star and from_expr is not None:
                # Reuse the child's FROM (left table) and its joins by
                # rebuilding the select with the same from + joins.
                query = sg.select(*select_exprs)
                query = query.from_(from_expr.expressions[0] if hasattr(from_expr, 'expressions') and from_expr.expressions else from_expr.this)
                for j in joins:
                    query.args.setdefault("joins", []).append(j)
                from_relation = "inlined-join"
        if from_relation is None:
            query = sg.select(*select_exprs).from_(child_ast.subquery())
        
        # Add GROUP BY
        if group_by:
            # Ensure GROUP BY columns are properly handled
            quoted_group_by = []
            for col in group_by:
                if isinstance(col, str):
                    # Mirror the SELECT-list logic for dotted refs.
                    if '.' in col and not col.startswith('"'):
                        from ..core.sql_generator import get_use_cte
                        table_part, column_part = col.split('.', 1)
                        if get_use_cte():
                            quoted_col = sg.column(col, quoted=True)
                        else:
                            quoted_col = sg.exp.Column(
                                this=sg.exp.Identifier(this=column_part, quoted=True),
                                table=sg.exp.Identifier(this=table_part, quoted=True),
                            )
                    else:
                        quoted_col = sg.column(col, quoted=True)
                    quoted_group_by.append(quoted_col)
                else:
                    # Handle Expression objects - convert to SQL for GROUP BY
                    from ..sql.column import Expression
                    if isinstance(col, Expression) and hasattr(col, 'to_sql'):
                        # Use the expression's SQL representation for GROUP BY
                        col_sql = col.to_sql()
                        col_expr = sg.parse_one(col_sql, into=sg.exp.Expression)
                        quoted_group_by.append(col_expr)
                    else:
                        # Fallback for other types
                        quoted_col = sg.column(str(col), quoted=True)
                        quoted_group_by.append(quoted_col)
            query = query.group_by(*quoted_group_by)
        
        # Add HAVING
        if having:
            query = query.having(having)
        
        return self.optimize_query(query)
    
    def build_sort(self, child_sql: str, 
                  order_by: List[Tuple[str, str]]) -> str:
        """
        Add ORDER BY to a child query.
        
        Args:
            child_sql: Child query SQL string
            order_by: List of (column, direction) tuples

        Returns:
            Optimized sorted SQL string
        """
        # No-op when no columns to sort by
        if not order_by:
            return child_sql

        # Check for problematic functions
        if self._contains_problematic_functions(child_sql):
            order_parts = [f'{col} {direction}' if '(' in col and ')' in col else f'"{col}" {direction}' for col, direction in order_by]
            return f"SELECT * FROM ({child_sql}) ORDER BY {', '.join(order_parts)}"

        # Parse child query
        child_ast = sg.parse_one(child_sql)

        # Build ORDER BY expressions
        order_exprs = []
        for col, direction in order_by:
            dir_upper = direction. upper ()
            # Parse direction and nulls ordering (e.g. "ASC NULLS FIRST")
            is_desc = dir_upper.startswith("DESC")
            # If col contains parentheses, it's a SQL expression (e.g. ABS("col")), not a column name
            if '(' in col and ')' in col:
                raw_expr = sg.parse_one(col)
                col_expr = raw_expr.desc() if is_desc else raw_expr.asc()
            else:
                col_expr = sg.column (col).desc() if is_desc else sg. column (col) .asc()
            # Handle NULLS FIRST / NULLS LAST modifiers
            if "NULLS FIRST" in dir_upper:
                col_expr = sg. exp.Ordered(this=col_expr.this, desc=is_desc, nulls_first=True)
            elif "NULLS LAST" in dir_upper:
                col_expr = sg. exp.Ordered(this=col_expr.this, desc=is_desc, nulls_first=False)
            order_exprs.append(col_expr)

        # Create SELECT with ORDER BY
        query = sg.select("*").from_(child_ast.subquery()).order_by(*order_exprs)

        return self.optimize_query(query)

    def build_limit(self, child_sql: str, n: int) -> str:
        """
        Add LIMIT to a child query.

        Args:
            child_sql: Child query SQL string
            n: Number of rows to limit

        Returns:
            Optimized limited SQL string
        """
        # Check for problematic functions
        if self._contains_problematic_functions(child_sql):
            return f"SELECT * FROM ({child_sql}) LIMIT {n}"

        # Parse child query
        child_ast = sg.parse_one(child_sql)

        # Add LIMIT
        query = sg.select("*").from_(child_ast.subquery()).limit(n)

        return self.optimize_query(query)

    def build_distinct(self, child_sql: str) -> str:
        """
        Add DISTINCT to a child query.

        Args:
            child_sql: Child query SQL string

        Returns:
            Optimized DISTINCT SQL string
        """
        # Check for problematic functions
        if self._contains_problematic_functions(child_sql):
            return f"SELECT DISTINCT * FROM ({child_sql})"

        # Parse child query
        child_ast = sg.parse_one(child_sql)

        # Add DISTINCT
        query = sg.select("*").distinct().from_(child_ast.subquery())

        return self.optimize_query(query)
    
    def build_union(self, left_sql: str, right_sql: str, 
                   union_type: str = "DISTINCT") -> str:
        """
        Build UNION between two queries with schema compatibility.
        
        Args:
            left_sql: Left query SQL string
            right_sql: Right query SQL string
            union_type: "DISTINCT" or "ALL"
            
        Returns:
            Optimized UNION SQL string
        """
        try:
            # Parse both queries
            left_ast = sg.parse_one(left_sql)
            right_ast = sg.parse_one(right_sql)
            
            # Try to get column information from both queries
            left_columns = self._extract_columns_from_query(left_sql)
            right_columns = self._extract_columns_from_query(right_sql)
            
            # If we can determine columns, check for schema mismatches
            if left_columns and right_columns and left_columns != right_columns:
                # Create unified schema
                all_columns = list(dict.fromkeys(left_columns + right_columns))  # Preserve order, remove duplicates
                
                # Build compatible queries
                left_sql = self._make_query_compatible(left_sql, left_columns, all_columns)
                right_sql = self._make_query_compatible(right_sql, right_columns, all_columns)
                
                # Re-parse with compatible schemas
                left_ast = sg.parse_one(left_sql)
                right_ast = sg.parse_one(right_sql)
            
            # Build UNION
            if union_type.upper() == "ALL":
                query = left_ast.union(right_ast, distinct=False)
            else:
                query = left_ast.union(right_ast, distinct=True)
            
            return self.optimize_query(query)
            
        except Exception as e:
            # Fallback to original behavior if schema compatibility fails
            left_ast = sg.parse_one(left_sql)
            right_ast = sg.parse_one(right_sql)
            
            if union_type.upper() == "ALL":
                query = left_ast.union(right_ast, distinct=False)
            else:
                query = left_ast.union(right_ast, distinct=True)
            
            return self.optimize_query(query)
    
    def _extract_columns_from_query(self, sql: str) -> List[str]:
        """Extract column names from a SQL query."""
        try:
            # Execute a LIMIT 0 query to get column metadata without data
            import re
            # Simple approach: look for SELECT clause patterns
            # This is a basic implementation - could be improved with proper SQL parsing
            
            # For now, return empty list to fall back to basic union
            # TODO: Implement proper column extraction
            return []
            
        except Exception:
            return []
    
    def _extract_columns_from_condition(self, condition: str) -> List[str]:
        """Extract column names from a JOIN condition.
        
        This method parses the condition to find column references like:
        - "column"
        - table."column" 
        - "table"."column"
        - l.legal_entity
        
        Returns:
            List of base column names (without table qualifiers)
        """
        import re
        
        columns = []
        
        # Pattern 1: Match quoted table.column patterns like "table"."column"
        # This pattern captures the column name from quoted qualified references
        qualified_quoted = re.findall(r'"[^"]+"\."([^"]+)"', condition)
        columns.extend(qualified_quoted)
        
        # Pattern 2: Match unquoted qualified patterns like l.legal_entity
        # Look for word.word patterns but exclude those already captured by quoted patterns
        unquoted_qualified = re.findall(r'(?<!")\b\w+\.(\w+)\b(?!")', condition)
        columns.extend(unquoted_qualified)
        
        # Pattern 3: Match standalone quoted column names like "status" that are not part of qualified references
        # This excludes columns that are already part of qualified references and literal values
        standalone_quoted = []
        all_quoted = re.findall(r'"([^"]+)"', condition)
        for match in all_quoted:
            # Check if this quoted string appears in a qualified context
            # Look for patterns like "something"."this_match" or this_match appears after a dot
            if not re.search(rf'"\w+"\."{ re.escape(match) }"', condition) and '.' not in match:
                # Also make sure it's not a table name in qualified pattern
                if not re.search(rf'"{re.escape(match)}"\."', condition):
                    # Additionally, check if it's not a literal value by looking for = before/after it
                    # Literal values typically appear after = or IN clauses
                    match_pattern = rf'"{re.escape(match)}"'
                    
                    # Check if this appears after an equals sign (likely a literal value)
                    if re.search(rf'=\s*{match_pattern}', condition):
                        continue  # Skip literal values
                    
                    # Check if this appears in an IN clause (likely literal values)
                    if re.search(rf'IN\s*\([^)]*{match_pattern}[^)]*\)', condition, re.IGNORECASE):
                        continue  # Skip literal values in IN clauses
                    
                    standalone_quoted.append(match)
        
        columns.extend(standalone_quoted)
        
        # Remove duplicates while preserving order
        unique_columns = []
        seen = set()
        for col in columns:
            if col not in seen:
                unique_columns.append(col)
                seen.add(col)
        
        return unique_columns
    
    def _analyze_condition_column_ownership(self, condition: str, left_alias: str, right_alias: str) -> Dict[str, str]:
        """Analyze JOIN condition to determine which columns belong to which table.
        
        Args:
            condition: The qualified JOIN condition
            left_alias: Left table alias name
            right_alias: Right table alias name
            
        Returns:
            Dictionary mapping column names to table side ('left' or 'right')
        """
        import re
        
        ownership = {}
        
        # Pattern to match "alias"."column" references
        pattern = rf'"({re.escape(left_alias)}|{re.escape(right_alias)})"\."([^"]+)"'
        matches = re.findall(pattern, condition)
        
        for alias, column in matches:
            if alias == left_alias:
                ownership[column] = 'left'
            elif alias == right_alias:
                ownership[column] = 'right'
        
        return ownership
    
    def _column_likely_belongs_to_table(self, column: str, table_columns: List[str]) -> bool:
        """Determine if a column likely belongs to a table based on existing columns.
        
        Args:
            column: Column name to check
            table_columns: List of known columns in the table
            
        Returns:
            True if the column likely belongs to this table
        """
        if not table_columns:
            return False
            
        # If the column already exists, it definitely belongs
        if column in table_columns:
            return True
            
        # Look for related column patterns
        # For example, if table has 'txn_id' and we're checking 'global_txn_id'
        # they might be related
        
        # Check for exact substring matches
        for existing_col in table_columns:
            if column in existing_col or existing_col in column:
                return True
                
        # Check for common prefixes/suffixes that suggest relationship
        common_patterns = ['_id', '_type', '_state', '_amount', '_time', '_date']
        
        for pattern in common_patterns:
            if column.endswith(pattern):
                # Check if any existing column has the same pattern
                for existing_col in table_columns:
                    if existing_col.endswith(pattern):
                        return True
        
        # If no clear relationship found, err on the side of caution
        return False
    
    def _make_query_compatible(self, sql: str, current_columns: List[str], target_columns: List[str]) -> str:
        """Make a query compatible with target schema by adding missing columns as NULL."""
        try:
            missing_columns = [col for col in target_columns if col not in current_columns]
            
            if not missing_columns:
                return sql  # Already compatible
            
            # Wrap the query and add NULL columns for missing ones
            select_list = []
            
            # Add existing columns
            for col in current_columns:
                if col in target_columns:
                    select_list.append(f'"{col}"')
            
            # Add NULL for missing columns in the right order
            for col in target_columns:
                if col not in current_columns:
                    select_list.append(f'NULL AS "{col}"')
                elif col not in [c.strip('"') for c in select_list]:
                    # Add column if not already added
                    select_list.append(f'"{col}"')
            
            # Create compatible query
            compatible_sql = f"SELECT {', '.join(select_list)} FROM ({sql}) AS subquery"
            return compatible_sql
            
        except Exception as e:
            self.logger.warning(f"Failed to make query compatible: {e}")
            return sql  # Return original if compatibility fails
    
    def build_with_column(self, child_sql: str, column_name: str, expression: str,
                          child_columns: List[str] = None) -> str:
        """
        Add or replace a single column in a child query.
        Handles a single WithColumn operation. For multiple columns use build_merged_with_columns.

        Args:
            child_sql: The SQL string of the child/inner query to add the column to.
            column_name: The name of the column to add or replace.
            expression: The SQL expression that computes the column value.
            child_columns: List of column names the child query produces.
                           replacement (exists in list) or a new addition.
                           If None or ['*'], the column is always treated as new.

        Returns:
            SQL string with the column added/replaced.
        """
        # Quote column name if not already quoted
        quoted_column = self.quote_identifier(column_name)

        # Resolve actual column list when child_columns is unknown
        resolved_columns = child_columns
        if not resolved_columns or resolved_columns == ["*"]:
            resolved_columns = self._extract_select_columns(child_sql)

        # Filter out bare "*" — it's an unresolved wildcard, not a real column name
        if resolved_columns:
            resolved_columns = [c for c in resolved_columns if c != "*"]

        # Check if we're replacing an existing column
        is_replacing = resolved_columns and column_name in resolved_columns and resolved_columns != ["*"]

        if is_replacing:
            # Build SELECT with explicit columns, substituting the target column
            select_parts = []
            for col in resolved_columns:
                if col == column_name:
                    select_parts.append(f"{expression} AS {quoted_column}")
                else:
                    select_parts.append(self.quote_identifier(col))
            select_clause = ", ".join(select_parts)

            if self.use_cte and self.cte_mode:
                cte_ref = self.register_cte(child_sql, f"before_{column_name}")
                return f"SELECT {select_clause} FROM {cte_ref}"
            else:
                return f"SELECT {select_clause} FROM ({child_sql})"

        # When columns are unknown (*) but the column name appears in the expression,
        # this is likely a self-referencing replacement (e.g., withColumn("x", upper(col("x")))).
        # Use SELECT * EXCEPT(col) to avoid producing a duplicate column.
        if not resolved_columns and child_columns == ["*"] and f'"{column_name}"' in expression:
            if self.use_cte and self.cte_mode:
                cte_ref = self.register_cte(child_sql, f"before_{column_name}")
                return f"SELECT * EXCEPT ({quoted_column}), {expression} AS {quoted_column} FROM {cte_ref}"
            else:
                return f"SELECT * EXCEPT ({quoted_column}), {expression} AS {quoted_column} FROM ({child_sql})"

        # Adding a new column - use SELECT *, expr AS col
        # Check for problematic functions - use simple string fallback
        if self._contains_problematic_functions(child_sql) or self._contains_problematic_functions(expression):
            # Use CTE approach for cleaner SQL
            if self.use_cte and self.cte_mode:
                cte_ref = self.register_cte(child_sql, f"before_{column_name}")
                return f"SELECT *, {expression} AS {quoted_column} FROM {cte_ref}"
            else:
                return f"SELECT *, {expression} AS {quoted_column} FROM ({child_sql})"

        # Only create CTE if child is complex (e.g., has JOIN)
        should_use_cte = self.use_cte and self.cte_mode and (
            "JOIN" in child_sql or
            child_sql.count("SELECT") > 3
        )

        if should_use_cte:
            # Register as CTE and build simpler query
            cte_ref = self.register_cte(child_sql, f"before_{column_name}")
            return f"SELECT *, {expression} AS {quoted_column} FROM {cte_ref}"
        else:
            # Use SQLGlot for non-CTE case
            try:
                # Parse child query
                child_ast = sg.parse_one(child_sql)

                # Parse expression as SQL rather than treating as identifier
                expr_ast = sg.parse_one(expression, into=exp.Expression)

                # Build SELECT with all existing columns plus the new one
                # Use Identifier to ensure proper quoting
                quoted_id = sg.exp.Identifier(this=column_name, quoted=True)
                query = sg.select("*", expr_ast.as_(quoted_id.this, quoted=True)).from_(child_ast.subquery())

                return self.optimize_query(query)
            except:
                # Fallback to simple string concatenation
                return f"SELECT *, {expression} AS {quoted_column} FROM ({child_sql})"
    
    def _absolute_column_replacement(self, child_sql: str, child_columns: List[str],
                                      replacement_map: Dict[str, str]) -> Optional[str]:
        """
        Inline all column replacements directly into the child's SELECT clause,
        avoiding extra nesting. Only used when every column being modified already
        exists in child_columns (pure replacements, no new additions).

        Uses sqlglot AST when safe, falls back to string-based parsing when
        DATE_ADD/DATE_SUB are present to avoid sqlglot corruption.

        Args:
            child_sql: The SQL string of the child query whose SELECT clause will be
            child_columns: List of column names the child query produces.
            replacement_map: Dict mapping column name -> new SQL expression.
                             with the LPAD expression.

        Returns:
            Rewritten SQL string with replacements inlined, or None if inlining
            is not possible (e.g. compound UNION query with problematic functions).
        """
        has_problematic = (self._contains_problematic_functions(child_sql) or
                           any(self._contains_problematic_functions(expr) for expr in replacement_map.values()))

        if has_problematic:
            # String-based: find top-level FROM in child_sql and rebuild SELECT for the date_add and date_sub
            depth = 0
            upper_sql = child_sql.upper()
            target = " FROM "
            from_pos = -1
            for i in range(len(upper_sql)):
                if upper_sql[i] == '(':
                    depth += 1
                elif upper_sql[i] == ')':
                    depth -= 1
                elif depth == 0 and upper_sql[i:i + len(target)] == target:
                    from_pos = i + 1
                    break
            if from_pos == -1:
                return None
            from_clause = child_sql[from_pos:]
            select_parts = []
            for col in child_columns:
                if col in replacement_map:
                    select_parts.append(f"{replacement_map[col]} AS {self.quote_identifier(col)}")
                else:
                    select_parts.append(self.quote_identifier(col))
            return f"SELECT {', '.join(select_parts)} {from_clause}"
        else:
            # sqlglot AST: structurally safe for UNIONs, CTEs, compound queries
            try:
                ast = sg.parse_one(child_sql)
                if not isinstance(ast, exp.Select):
                    return None
                new_expressions = []
                for col in child_columns:
                    if col in replacement_map:
                        quoted_col = self.quote_identifier(col)
                        new_expressions.append(
                            sg.parse_one(f"{replacement_map[col]} AS {quoted_col}", into=exp.Expression)
                        )
                    else:
                        new_expressions.append(
                            exp.Column(this=exp.Identifier(this=col, quoted=True))
                        )
                ast.set("expressions", new_expressions)
                return ast.sql(dialect=self.dialect)
            except Exception as e:
                self.logger.warning(f"sqlglot inline replacement failed: {e}")
                return None

    def _partial_column_replacement(self, child_sql: str, columns: List[Tuple[str, str]],
                                     child_columns: Optional[List[str]],
                                     replacement_map: Dict[str, str]) -> str:
        """
        Wrap child_sql in a subquery, handling both replacements and new column additions.
        Used when inlining is not possible (new columns, unknown schema, or inlining failed).

        Args:
            child_sql: The SQL string of the child query to wrap.
            columns: List of (column_name, expression) tuples for all columns to add/replace.
            child_columns: List of column names the child query produces.
                           When known, enumerates columns explicitly to avoid duplicates.
            replacement_map: Dict mapping column name -> new SQL expression.

        Returns:
            SQL string wrapping child_sql as a subquery with columns applied.
        """
        # handles when the query has only some columns to be replaced
        from_clause = f"({child_sql})"
        if child_columns and child_columns != ["*"]:
            # Filter out bare "*" wildcard mixed in with real column names
            child_columns = [c for c in child_columns if c != "*"]
            select_parts = []
            for col in child_columns:
                if col in replacement_map:
                    select_parts.append(f"{replacement_map[col]} AS {self.quote_identifier(col)}")
                else:
                    select_parts.append(self.quote_identifier(col))
            for col_name, expression in columns:
                if col_name not in child_columns:
                    select_parts.append(f"{expression} AS {self.quote_identifier(col_name)}")
            return f"SELECT {', '.join(select_parts)} FROM {from_clause}"
        else:
            # handles when the query has *
            column_exprs = [f"{expr} AS {self.quote_identifier(col)}" for col, expr in columns]
            return f"SELECT {', '.join(['*'] + column_exprs)} FROM {from_clause}"

    def build_merged_with_columns(self, child_sql: str, columns: List[Tuple[str, str]],
                                  child_columns: List[str] = None) -> str:
        """
        Build a single SELECT statement with multiple column additions/replacements.
        Merges multiple WithColumn operations into one SELECT to reduce nesting.
        Delegates to _absolute_column_replacement (inline, no nesting) when all columns
        are pure replacements, otherwise falls back to _partial_column_replacement (wrapping).

        Args:
            child_sql: The SQL string of the base/child query.
            columns: List of (column_name, expression) tuples to add/replace.
                     If all column names exist in child_columns, uses absolute replacement.
                     If any are new, uses partial replacement (wrapping).
            child_columns: List of column names the child query produces.
                           or additions. If None or ['*'], always uses partial replacement.

        Returns:
            SQL string with all columns applied in a single SELECT.
        """
        replacement_map = {col_name: expr for col_name, expr in columns}
        only_replacements = (child_columns and child_columns != ["*"] and
                             all(col_name in child_columns for col_name, _ in columns))
        # When CTE mode is active, always wrap the merged result in a CTE so
        # that set_use_cte(True) has a visible effect on chained withColumn.
        # Previously this was gated on a "complexity" heuristic (JOIN present
        # or > 2 nested SELECTs), which meant simple chains over a base table
        # silently ignored the global flag.
        cte_wrap = self.use_cte and self.cte_mode

        # works in the case all columns are replcaement columns
        if only_replacements:
            full_sql = self._absolute_column_replacement(child_sql, child_columns, replacement_map)
            if full_sql is not None:
                if cte_wrap:
                    cte_ref = self.register_cte(full_sql, "before_columns")
                    return f"SELECT * FROM {cte_ref}"
                return full_sql
        # used when all columns of the sql are not to be replaced
        full_sql = self._partial_column_replacement(child_sql, columns, child_columns, replacement_map)
        if cte_wrap:
            cte_ref = self.register_cte(full_sql, "before_columns")
            return f"SELECT * FROM {cte_ref}"
        return full_sql
    
    def build_drop(self, child_sql: str, child_columns: List[str], columns_to_drop: List[str]) -> str:
        """
        Drop specified columns from a child query.
        
        Args:
            child_sql: Child query SQL string
            child_columns: List of columns from child query
            columns_to_drop: List of column names to drop
            
        Returns:
            Optimized SQL string with dropped columns
            
        Raises:
            ValueError: If trying to drop all columns
        """
        # Calculate remaining columns
        # Handle duplicate column names in joins by keeping only the first occurrence
        remaining_columns = []
        seen_columns = set()
        has_wildcard = False
        
        for col in child_columns:
            if col == "*":
                # Special handling for wildcard - we'll need to expand it
                has_wildcard = True
                continue
            elif col not in columns_to_drop:
                if col not in seen_columns:
                    remaining_columns.append(f'"{col}"')  # Quote column names
                    seen_columns.add(col)
                # Skip duplicate column names (common after joins)
        
        # Handle the wildcard case specially
        if has_wildcard:
            # When we have a wildcard, we can't know which columns to exclude
            # We need to let the database handle this through column qualification
            # For now, return the child query as-is (this is a limitation)
            return child_sql
        
        if not remaining_columns:
            # If all columns would be dropped, keep at least one column with NULL value
            # This prevents the "Cannot drop all columns" error
            self.logger.warning("Attempted to drop all columns, keeping a placeholder column instead")
            remaining_columns = ["NULL AS __placeholder_column__"]

        # Check for problematic functions - use simple string fallback
        if self._contains_problematic_functions(child_sql):
            return f"SELECT {', '.join(remaining_columns)} FROM ({child_sql})"

        # Parse child query
        child_ast = sg.parse_one(child_sql)

        # Build SELECT with remaining columns only
        query = sg.select(*remaining_columns).from_(child_ast.subquery())

        return self.optimize_query(query)
    
    def build_intersect(self, left_sql: str, right_sql: str) -> str:
        """
        Build INTERSECT query.
        
        Args:
            left_sql: Left side SQL query
            right_sql: Right side SQL query
            
        Returns:
            Optimized INTERSECT SQL string
        """
        try:
            # Parse both queries
            left_ast = sg.parse_one(left_sql)
            right_ast = sg.parse_one(right_sql)
            
            # Build INTERSECT
            query = left_ast.intersect(right_ast)
            
            return self.optimize_query(query)
        except Exception as e:
            self.logger.warning(f"Failed to build INTERSECT with SQLGlot, falling back to string concatenation: {e}")
            return f"({left_sql}) INTERSECT ({right_sql})"
    
    def build_except(self, left_sql: str, right_sql: str, all_rows: bool = False) -> str:
        """
        Build EXCEPT/EXCEPT ALL query.
        
        Args:
            left_sql: Left side SQL query
            right_sql: Right side SQL query
            all_rows: Whether to use EXCEPT ALL (default: False for EXCEPT)
            
        Returns:
            Optimized EXCEPT SQL string
        """
        try:
            # Parse both queries
            left_ast = sg.parse_one(left_sql)
            right_ast = sg.parse_one(right_sql)
            
            # Build EXCEPT
            if all_rows:
                query = left_ast.except_(right_ast, distinct=False)
            else:
                query = left_ast.except_(right_ast, distinct=True)
            
            return self.optimize_query(query)
        except Exception as e:
            self.logger.warning(f"Failed to build EXCEPT with SQLGlot, falling back to string concatenation: {e}")
            except_type = "EXCEPT ALL" if all_rows else "EXCEPT"
            return f"({left_sql}) {except_type} ({right_sql})"
    
    def build_count_query(self, child_sql: str) -> str:
        """
        Build COUNT(*) query wrapping a subquery.

        Args:
            child_sql: Child SQL query to count

        Returns:
            Optimized COUNT query SQL string
        """
        # Check for problematic functions - use simple string fallback
        if self._contains_problematic_functions(child_sql):
            quoted_cnt = self.quote_identifier("cnt")
            return f"SELECT COUNT(*) AS {quoted_cnt} FROM ({child_sql})"

        try:
            # Parse child query
            child_ast = sg.parse_one(child_sql)
            
            # Build COUNT query with quoted alias
            count_func = sg.func("COUNT", "*")
            quoted_id = sg.exp.Identifier(this="cnt", quoted=True)
            query = sg.select(count_func.as_(quoted_id.this, quoted=True)).from_(child_ast.subquery())
            
            return self.optimize_query(query)
        except Exception as e:
            self.logger.warning(f"Failed to build COUNT query with SQLGlot, falling back to string concatenation: {e}")
            quoted_cnt = self.quote_identifier("cnt")
            quoted_t = self.quote_identifier("t")
            return f"SELECT COUNT(*) AS {quoted_cnt} FROM ({child_sql}) AS {quoted_t}"
    
    def build_describe_query(self, child_sql: str, columns: List[str]) -> str:
        """
        Build statistics query for DataFrame.describe().

        Args:
            child_sql: Child SQL query to describe
            columns: List of columns to compute statistics for

        Returns:
            Optimized statistics SQL string
        """
        # Check for problematic functions - use simple string fallback
        if self._contains_problematic_functions(child_sql):
            stats = []
            for col in columns:
                stats.extend([
                    f"'{col}' as {self.quote_identifier('summary')}",
                    f"COUNT({col}) as {self.quote_identifier('count')}",
                    f"AVG({col}) as {self.quote_identifier('mean')}",
                    f"STDDEV({col}) as {self.quote_identifier('stddev')}",
                    f"MIN({col}) as {self.quote_identifier('min')}",
                    f"MAX({col}) as {self.quote_identifier('max')}"
                ])
            return f"SELECT {', '.join(stats)} FROM ({child_sql})"

        try:
            # Parse child query
            child_ast = sg.parse_one(child_sql)
            
            # Build statistics expressions with quoted aliases
            select_exprs = []
            for col in columns:
                # Create quoted identifiers for aliases
                summary_id = sg.exp.Identifier(this="summary", quoted=True)
                count_id = sg.exp.Identifier(this="count", quoted=True)
                mean_id = sg.exp.Identifier(this="mean", quoted=True)
                stddev_id = sg.exp.Identifier(this="stddev", quoted=True)
                min_id = sg.exp.Identifier(this="min", quoted=True)
                max_id = sg.exp.Identifier(this="max", quoted=True)
                
                select_exprs.extend([
                    exp.Literal.string(col).as_(summary_id.this, quoted=True), 
                    sg.func("COUNT", col).as_(count_id.this, quoted=True),
                    sg.func("AVG", col).as_(mean_id.this, quoted=True),
                    sg.func("STDDEV", col).as_(stddev_id.this, quoted=True),
                    sg.func("MIN", col).as_(min_id.this, quoted=True),
                    sg.func("MAX", col).as_(max_id.this, quoted=True)
                ])
            
            # Build query
            query = sg.select(*select_exprs).from_(child_ast.subquery())
            
            return self.optimize_query(query)
        except Exception as e:
            self.logger.warning(f"Failed to build describe query with SQLGlot, falling back to string concatenation: {e}")
            # Fallback to manual construction
            stats = []
            for col in columns:
                stats.extend([
                    f"'{col}' as {self.quote_identifier('summary')}",
                    f"COUNT({col}) as {self.quote_identifier('count')}",
                    f"AVG({col}) as {self.quote_identifier('mean')}",
                    f"STDDEV({col}) as {self.quote_identifier('stddev')}",
                    f"MIN({col}) as {self.quote_identifier('min')}",
                    f"MAX({col}) as {self.quote_identifier('max')}"
                ])
            quoted_t = self.quote_identifier("t")
            return f"SELECT {', '.join(stats)} FROM ({child_sql}) AS {quoted_t}"
    
    def build_coalesce_sql(self, child_sql: str, value_to_fill,
                           child_columns: list = None, subset: list = None) -> str:
        """
        Build SQL with COALESCE to fill null values (fillna).

        Args:
            child_sql: Child SQL query
            value_to_fill: Scalar value or dict mapping column names to fill values
            child_columns: Full list of columns from the child query plan
            subset: For scalar fills, the subset of columns to apply the fill to.
                    If None, all child_columns are filled.

        Returns:
            SQL string with COALESCE expressions, projecting ALL child columns
        """
        def _format_value(val):
            if isinstance(val, str):
                escaped = val.replace("'", "''")
                return f"'{escaped}'"
            elif isinstance(val, bool):
                return "TRUE" if val else "FALSE"
            elif val is None:
                return "NULL"
            else:
                return str(val)

        if self.use_cte and self.cte_mode:
            cte_ref = self.register_cte(child_sql, "before_fillna")
            from_clause = cte_ref
        else:
            from_clause = f"({child_sql})"

        # to the dict-keys-only or scalar fallback paths below
        resolved_columns = child_columns
        if not resolved_columns or resolved_columns == ["*"]:
            resolved_columns = self._extract_select_columns(child_sql)

        # Filter out bare "*" — it's an unresolved wildcard, not a real column name
        if resolved_columns:
            resolved_columns = [c for c in resolved_columns if c != "*"]

        if isinstance(value_to_fill, dict):
            if resolved_columns:
                # Known columns: wrap dict keys in COALESCE, pass others through
                select_parts = []
                for col in resolved_columns:
                    quoted = self.quote_identifier(col)
                    if col in value_to_fill:
                        select_parts.append(
                            f"COALESCE({quoted}, {_format_value(value_to_fill[col])}) AS {quoted}"
                        )
                    else:
                        select_parts.append(quoted)
                return f"SELECT {', '.join(select_parts)} FROM {from_clause}"
            else:
                # Could not resolve columns at all — only select dict keys
                coalesce_parts = []
                for col, val in value_to_fill.items():
                    quoted = self.quote_identifier(col)
                    coalesce_parts.append(
                        f"COALESCE({quoted}, {_format_value(val)}) AS {quoted}"
                    )
                return f"SELECT {', '.join(coalesce_parts)} FROM {from_clause}"
        else:
            # Scalar fill
            fill_set = set(subset) if subset else None

            if resolved_columns:
                # Known columns: COALESCE target columns, pass others through
                select_parts = []
                for col in resolved_columns:
                    quoted = self.quote_identifier(col)
                    if fill_set is None or col in fill_set:
                        select_parts.append(
                            f"COALESCE({quoted}, {_format_value(value_to_fill)}) AS {quoted}"
                        )
                    else:
                        select_parts.append(quoted)
                return f"SELECT {', '.join(select_parts)} FROM {from_clause}"
            elif fill_set:
                # Unknown full column list but subset is specified:
                # use * EXCEPT to avoid duplicating the filled columns.
                except_cols = ", ".join(self.quote_identifier(c) for c in subset)
                coalesce_parts = []
                for c in subset:
                    quoted = self.quote_identifier(c)
                    coalesce_parts.append(
                        f"COALESCE({quoted}, {_format_value(value_to_fill)}) AS {quoted}"
                    )
                return (
                    f"SELECT * EXCEPT ({except_cols}), "
                    f"{', '.join(coalesce_parts)} FROM {from_clause}"
                )
            else:
                # Unknown columns: can't apply COALESCE without column names
                return f"SELECT * FROM {from_clause}"

    def build_statistical_query(self, child_sql: str, func_name: str, col1: str, col2: str = None) -> str:
        """
        Build statistical function query (CORR, COVAR_POP, etc.).
        
        Args:
            child_sql: Child SQL query
            func_name: Statistical function name (CORR, COVAR_POP, etc.)
            col1: First column name
            col2: Second column name (optional for single-column functions)
            
        Returns:
            Optimized statistical query SQL string
        """
        try:
            # Parse child query
            child_ast = sg.parse_one(child_sql)
            
            # Build statistical function call
            if col2:
                func_expr = sg.func(func_name, col1, col2)
            else:
                func_expr = sg.func(func_name, col1)
            
            # Build query
            query = sg.select(func_expr).from_(child_ast.subquery())
            
            return self.optimize_query(query)
        except Exception as e:
            self.logger.warning(f"Failed to build {func_name} query with SQLGlot, falling back to string concatenation: {e}")
            quoted_t = self.quote_identifier("t")
            if col2:
                return f"SELECT {func_name}({col1}, {col2}) FROM ({child_sql}) AS {quoted_t}"
            else:
                return f"SELECT {func_name}({col1}) FROM ({child_sql}) AS {quoted_t}"
    
    def build_binary_expression(self, left_expr: str, operator: str, right_expr: str) -> str:
        """
        Build binary expression using SQLGlot AST.

        Args:
            left_expr: Left expression SQL string
            operator: Binary operator (=, >, <, AND, OR, +, -, *, /, etc.)
            right_expr: Right expression SQL string

        Returns:
            Optimized binary expression SQL string
        """
        # When either operand contains a string literal with escaped quotes
        # (e.g. 'O''Brien'), skip the SQLGlot round-trip because the e6
        # Generator would re-escape them with backslashes, producing SQL
        # that is unparseable by the validator.
        if "''" in left_expr or "''" in right_expr:
            return f"{left_expr} {operator} {right_expr}"

        try:
            # Parse both expressions
            left_ast = sg.parse_one(left_expr, into=exp.Expression)
            right_ast = sg.parse_one(right_expr, into=exp.Expression)
            
            # Map operators to SQLGlot expression builders
            operator_map = {
                # Comparison operators
                "=": lambda l, r: exp.EQ(this=l, expression=r),
                "!=": lambda l, r: exp.NEQ(this=l, expression=r),
                "<": lambda l, r: exp.LT(this=l, expression=r),
                "<=": lambda l, r: exp.LTE(this=l, expression=r),
                ">": lambda l, r: exp.GT(this=l, expression=r),
                ">=": lambda l, r: exp.GTE(this=l, expression=r),
                
                # Logical operators
                "AND": lambda l, r: exp.And(this=l, expression=r),
                "OR": lambda l, r: exp.Or(this=l, expression=r),
                
                # Arithmetic operators
                "+": lambda l, r: exp.Add(this=l, expression=r),
                "-": lambda l, r: exp.Sub(this=l, expression=r),
                "*": lambda l, r: exp.Mul(this=l, expression=r),
                "/": lambda l, r: exp.Div(this=l, expression=r),
                "%": lambda l, r: exp.Mod(this=l, expression=r),
                
                # String operators
                "LIKE": lambda l, r: exp.Like(this=l, expression=r),
                "RLIKE": lambda l, r: exp.RegexpLike(this=l, expression=r),
                
                # Special operators
                "IS": lambda l, r: exp.Is(this=l, expression=r),
                "IS NOT": lambda l, r: exp.Not(this=exp.Is(this=l, expression=r)),
            }
            
            if operator.upper() in operator_map:
                binary_expr = operator_map[operator.upper()](left_ast, right_ast)
                return self.optimize_query(binary_expr)
            else:
                # Fallback for unknown operators
                self.logger.warning(f"Unknown operator '{operator}', using fallback")
                return f"({left_expr} {operator} {right_expr})"
                
        except Exception as e:
            self.logger.warning(f"Failed to build binary expression with SQLGlot, falling back to string concatenation: {e}")
            return f"({left_expr} {operator} {right_expr})"
    
    def build_function_call(self, func_name: str, *args) -> str:
        """
        Build function call using SQLGlot AST.

        Args:
            func_name: Function name (MAX, MIN, COUNT, SUM, etc.)
            *args: Function arguments as SQL strings

        Returns:
            Optimized function call SQL string
        """
        func_upper = func_name.upper()

        # Special handling for functions that SQLGlot transforms incorrectly
        # DATE_ADD/DATE_SUB/DATE_DIFF: SQLGlot converts to Trino-style which corrupts nested function args
        if func_upper in ('DATE_ADD', 'DATE_SUB', 'DATE_DIFF', 'DATEDIFF',
                          'TIMESTAMP_ADD', 'TIMESTAMP_DIFF'):
            arg_strs = [str(arg) for arg in args]
            # Ensure the second argument (days count) is cast to BIGINT for e6 compatibility.
            # The e6 dialect's generator normally adds this via _to_int(), but when we skip
            # SQLGlot round-tripping for problematic functions, the CAST is never added.
            if len(arg_strs) >= 2:
                days_arg = arg_strs[1].strip()
                if not days_arg.upper().startswith('CAST(') and not days_arg.lstrip('-').isdigit():
                    arg_strs[1] = f"CAST({days_arg} AS BIGINT)"
            return f"{func_upper}({', '.join(arg_strs)})"

        if func_upper in ('TO_DATE', 'DATE_FORMAT', 'TO_TIMESTAMP', 'ISNAN'):
            return f"{func_upper}({', '.join(str(arg) for arg in args)})"

        # FORMAT_NUMBER: pass through natively (supported on Java engine)
        if func_upper == 'FORMAT_NUMBER':
            return f"{func_upper}({', '.join(str(arg) for arg in args)})"

        # FORMAT_NUMBER: pass through natively (supported on Java engine)
        if func_upper == 'FORMAT_NUMBER':
            return f"{func_upper}({', '.join(str(arg) for arg in args)})"

        try:
            # Parse arguments as expressions
            arg_asts = []
            for arg in args:
                if isinstance(arg, str):
                    arg_asts.append(sg.parse_one(arg, into=exp.Expression))
                else:
                    # Handle literal values
                    arg_asts.append(exp.Literal.string(str(arg)))

            # Build function call using SQLGlot
            func_expr = sg.func(func_upper, *arg_asts)

            return self.optimize_query(func_expr)

        except Exception as e:
            self.logger.warning(f"Failed to build function call with SQLGlot, falling back to string concatenation: {e}")
            # Fallback to manual construction
            return f"{func_name}({', '.join(str(arg) for arg in args)})"
    
    def build_cast_expression(self, expression: str, data_type: str) -> str:
        """
        Build CAST expression using SQLGlot AST.

        Args:
            expression: Expression SQL string to cast
            data_type: Target data type (STRING, INTEGER, DECIMAL, etc.)

        Returns:
            Optimized CAST expression SQL string
        """
        # Check for problematic functions - use simple string fallback
        if self._contains_problematic_functions(expression):
            return f"CAST({expression} AS {data_type})"

        try:
            # Parse the expression - handle both identifiers and complex expressions
            try:
                expr_ast = sg.parse_one(expression, into=exp.Expression)
            except:
                # If parsing fails, treat it as a column identifier
                expr_ast = exp.Column(this=expression)

            # Build CAST expression using SQLGlot with proper DataType
            cast_expr = exp.Cast(
                this=expr_ast,
                to=exp.DataType.build(data_type.upper())
            )

            return self.optimize_query(cast_expr)

        except Exception as e:
            self.logger.warning(f"Failed to build cast expression with SQLGlot, falling back to string concatenation: {e}")
            # Fallback to manual construction
            return f"CAST({expression} AS {data_type})"
    
    def build_in_expression(self, expression: str, values: List[str]) -> str:
        """
        Build IN expression using e6-specific ARRAY_CONTAINS syntax.
        
        For e6 engine compatibility, converts:
            column IN ('A', 'B', 'C') 
        to:
            ARRAY_CONTAINS(array['A', 'B', 'C'], column)
        
        Args:
            expression: Left side expression SQL string
            values: List of values to check against (as SQL strings)
            
        Returns:
            e6-compatible ARRAY_CONTAINS expression
        """
        try:
            # Handle empty list case
            if not values:
                # Empty array - this will always return false
                return f"ARRAY_CONTAINS(array[], {expression})"
            
            # Handle single value case - still use array syntax for consistency
            if len(values) == 1:
                value = values[0]
                if value == "NULL":
                    # Special case for NULL - might need different handling
                    return f"ARRAY_CONTAINS(array[NULL], {expression})"
            
            # Check if all values are string literals (common case)
            # This helps us decide whether to use array['A', 'B'] syntax
            all_string_literals = all(
                (value.startswith("'") and value.endswith("'")) or 
                (value.startswith('"') and value.endswith('"'))
                for value in values if value != "NULL"
            )
            
            # Check for potential issues
            has_null = "NULL" in values
            has_column_refs = any(
                not (value.startswith("'") or value.startswith('"') or 
                     value.replace('.', '').replace('-', '').isdigit() or 
                     value == "NULL")
                for value in values
            )
            
            # For complex cases with column references or expressions,
            # we might want to fall back to standard IN syntax
            # But since e6 doesn't support it, we'll try our best with ARRAY_CONTAINS
            
            # Build the array part - always use lowercase 'array' for e6 engine compatibility
            # The uppercase 'ARRAY' constructor creates nested arrays which e6 doesn't support
            array_expr = f"array[{', '.join(values)}]"
            
            # Build ARRAY_CONTAINS expression
            result = f"ARRAY_CONTAINS({array_expr}, {expression})"
            
            # Log potential issues
            if has_null:
                self.logger.debug(f"IN expression contains NULL values, behavior might differ: {result}")
            if has_column_refs:
                self.logger.debug(f"IN expression contains column references or expressions: {result}")
            
            return result
            
        except Exception as e:
            self.logger.warning(f"Failed to build ARRAY_CONTAINS expression, falling back to e6 syntax: {e}")
            # Fallback to e6's expected format
            array_expr = f"array[{', '.join(values)}]"
            return f"ARRAY_CONTAINS({array_expr}, {expression})"
    
    def build_between_expression(self, expression: str, lower_bound: str, upper_bound: str) -> str:
        """
        Build BETWEEN expression using SQLGlot AST.

        Args:
            expression: Expression SQL string to check
            lower_bound: Lower bound value SQL string
            upper_bound: Upper bound value SQL string

        Returns:
            Optimized BETWEEN expression SQL string
        """
        try:
            # Parse all expressions
            expr_ast = sg.parse_one(expression, into=exp.Expression)
            lower_ast = sg.parse_one(lower_bound, into=exp.Expression)
            upper_ast = sg.parse_one(upper_bound, into=exp.Expression)
            
            # Build BETWEEN expression using SQLGlot
            between_expr = exp.Between(this=expr_ast, low=lower_ast, high=upper_ast)
            
            return self.optimize_query(between_expr)
            
        except Exception as e:
            self.logger.warning(f"Failed to build BETWEEN expression with SQLGlot, falling back to string concatenation: {e}")
            # Fallback to manual construction
            return f"{expression} BETWEEN {lower_bound} AND {upper_bound}"
    
    def build_case_expression(self, conditions: List[Tuple[str, str]], else_value: str = None) -> str:
        """
        Build CASE expression using SQLGlot AST.
        
        Args:
            conditions: List of (condition, value) tuples for WHEN clauses
            else_value: Optional ELSE value SQL string
            
        Returns:
            Optimized CASE expression SQL string
        """
        try:
            # Build CASE expression using SQLGlot
            case_expr = exp.Case()
            
            # Add WHEN clauses
            for condition_sql, value_sql in conditions:
                condition_ast = sg.parse_one(condition_sql, into=exp.Expression)
                value_ast = sg.parse_one(value_sql, into=exp.Expression)
                case_expr = case_expr.when(condition_ast, value_ast)
            
            # Add ELSE clause if provided
            if else_value:
                else_ast = sg.parse_one(else_value, into=exp.Expression)
                case_expr = case_expr.else_(else_ast)
            
            return self.optimize_query(case_expr)
            
        except Exception as e:
            self.logger.warning(f"Failed to build CASE expression with SQLGlot, falling back to string concatenation: {e}")
            # Fallback to manual construction
            sql_parts = ["CASE"]
            
            for condition_sql, value_sql in conditions:
                sql_parts.append(f"WHEN {condition_sql} THEN {value_sql}")
            
            if else_value:
                sql_parts.append(f"ELSE {else_value}")
            
            sql_parts.append("END")
            return " ".join(sql_parts)
    
    def build_window_expression(self, function_sql: str, window_spec_sql: str) -> str:
        """
        Build window function expression using SQLGlot AST.
        
        Args:
            function_sql: Function call SQL string (e.g., "COUNT(*)", "ROW_NUMBER()")
            window_spec_sql: Window specification SQL string (e.g., "PARTITION BY col ORDER BY col2")
            
        Returns:
            Optimized window function SQL string
        """
        try:
            # Parse function call
            func_ast = sg.parse_one(function_sql, into=exp.Expression)
            
            # Parse window specification - handle cases where it might be empty
            if window_spec_sql and window_spec_sql.strip():
                # If window spec looks like parentheses content, parse it as window spec
                if window_spec_sql.startswith("(") and window_spec_sql.endswith(")"):
                    window_spec_sql = window_spec_sql[1:-1]  # Remove outer parentheses
                
                # Build window specification
                # For window specs that start with "PARTITION BY" or "ORDER BY", 
                # we need to wrap them in a valid SQL context
                if window_spec_sql.upper().strip().startswith(('PARTITION BY', 'ORDER BY')):
                    # Add OVER keyword for proper parsing context
                    window_ast = sg.parse_one(f"SELECT ROW_NUMBER() OVER ({window_spec_sql})")
                else:
                    window_ast = sg.parse_one(f"SELECT * FROM t {window_spec_sql}")
                window_expr = exp.Window(this=func_ast)
                
                # Extract window specification from the parsed AST
                if hasattr(window_ast, 'find'):
                    # Find the Window expression in the parsed AST
                    window_node = window_ast.find(exp.Window)
                    if window_node:
                        # Copy partition by clause
                        if hasattr(window_node, 'partition_by') and window_node.partition_by:
                            window_expr = window_expr.partition_by(*window_node.partition_by)
                        # Copy order by clause
                        if hasattr(window_node, 'order') and window_node.order:
                            window_expr = window_expr.order_by(*window_node.order.expressions)
                
                # Check if window expression was properly built by verifying it has partition_by or order
                result_sql = self.optimize_query(window_expr)

                # If the result is just "FUNCTION() OVER ()" but we have window_spec_sql, fall back to string concatenation
                if window_spec_sql.strip() and result_sql.endswith("OVER ()"):
                    self.logger.warning("SQLGlot window AST generation incomplete, falling back to string concatenation")
                    return f"{function_sql} OVER ({window_spec_sql})"
                
                return result_sql
            else:
                # Empty window spec - just function with empty OVER()
                window_expr = exp.Window(this=func_ast)
                return self.optimize_query(window_expr)
            
        except Exception as e:
            self.logger.warning(f"Failed to build window expression with SQLGlot, falling back to string concatenation: {e}")
            # Fallback to manual construction with proper parentheses
            if window_spec_sql and not (window_spec_sql.startswith("(") and window_spec_sql.endswith(")")):
                # Add parentheses if not already present
                return f"{function_sql} OVER ({window_spec_sql})"
            else:
                return f"{function_sql} OVER {window_spec_sql}"
    
    def reset_cte_state(self):
        """Reset CTE tracking state for new query building."""
        self.cte_counter = 0
        self.cte_definitions = []
        self.cte_mode = False
    
    def register_cte(self, sql: str, alias: Optional[str] = None, force_exact_name: bool = False) -> str:
        """
        Register a subquery as a CTE and return the CTE reference.
        Content-based deduplication: returns existing CTE if identical SQL already exists.
        
        Args:
            sql: The SQL query to register as CTE
            alias: Optional alias for the CTE (auto-generated if not provided)
            force_exact_name: If True, use the exact alias name without sanitization or deduplication
            
        Returns:
            CTE reference name to use in queries
        """
        if not self.use_cte:
            # If CTE mode is disabled, return the subquery as-is
            return f"({sql})"
        
        # Check for existing CTE with identical content (content-based deduplication)
        sql_normalized = sql.strip()
        for existing_alias, existing_sql in self.cte_definitions:
            if existing_sql.strip() == sql_normalized:
                self.logger.debug(f"Found duplicate CTE content, reusing: {existing_alias}")
                # If force_exact_name is True but we found identical content with different name,
                # we need to handle this carefully to avoid conflicts
                if force_exact_name and alias and alias != existing_alias:
                    # Check if the requested alias is already taken by different content
                    alias_taken_by_different_content = any(
                        name == alias and sql != existing_sql 
                        for name, sql in self.cte_definitions
                    )
                    if not alias_taken_by_different_content:
                        # Safe to create an alias for the existing CTE
                        # But we should return the existing alias to avoid duplication
                        return existing_alias
                return existing_alias
        
        # Generate CTE name if not provided
        if alias is None:
            self.cte_counter += 1
            alias = f"cte_{self.cte_counter}"
        else:
            if not force_exact_name:
                # Sanitize alias to be a valid SQL identifier
                # Replace spaces and special characters with underscores
                import re
                alias = re.sub(r'[^a-zA-Z0-9_]', '_', alias)
                # Ensure it starts with a letter or underscore
                if not alias[0].isalpha() and alias[0] != '_':
                    alias = f"cte_{alias}"
                
                # Check if this alias already exists in our CTEs
                existing_cte_names = [name for name, _ in self.cte_definitions]
                if alias in existing_cte_names:
                    # If alias already exists, append a number to make it unique
                    base_alias = alias
                    counter = 2
                    while alias in existing_cte_names:
                        alias = f"{base_alias}_{counter}"
                        counter += 1
            else:
                # When force_exact_name is True, check for naming conflicts more carefully
                existing_cte_names = [name for name, _ in self.cte_definitions]
                if alias in existing_cte_names:
                    # Check if the existing CTE has the same content
                    existing_cte_with_name = next((sql for name, sql in self.cte_definitions if name == alias), None)
                    if existing_cte_with_name and existing_cte_with_name.strip() == sql_normalized:
                        # Same content, same name - just return the existing alias
                        self.logger.debug(f"CTE with name {alias} already exists with identical content, reusing")
                        return alias
                    else:
                        # Different content with same name - this is a real conflict
                        # Create a unique name instead of overriding
                        base_alias = alias
                        counter = 2
                        while alias in existing_cte_names:
                            alias = f"{base_alias}_{counter}"
                            counter += 1
                        self.logger.debug(f"CTE name conflict resolved: {base_alias} -> {alias}")
        
        # Store CTE definition
        self.cte_definitions.append((alias, sql_normalized))
        self.logger.debug(f"Registered new CTE: {alias}")
        
        # Return the CTE reference
        return alias
    
    def build_with_cte(self, final_query: str) -> str:
        """
        Build final query with all registered CTEs.
        
        Args:
            final_query: The main query that references the CTEs
            
        Returns:
            Complete SQL with WITH clause if CTEs exist
        """
        if not self.cte_definitions:
            return final_query
        
        # Build WITH clause - don't namespace qualify CTE names as it causes issues
        # The error was a red herring; the actual issue is elsewhere
        cte_parts = []
        for cte_name, cte_sql in self.cte_definitions:
            cte_parts.append(f"{cte_name} AS (\n{cte_sql}\n)")
        
        with_clause = "WITH " + ",\n".join(cte_parts)
        
        # Reset CTE state after building
        self.reset_cte_state()
        
        return f"{with_clause}\n{final_query}"
    
    def wrap_as_cte_or_subquery(self, sql: str, needs_alias: bool = True) -> str:
        """
        Wrap SQL as either a CTE (if enabled) or subquery.
        
        Args:
            sql: The SQL to wrap
            needs_alias: Whether the result needs an alias (for subqueries)
            
        Returns:
            CTE reference or subquery
        """
        if self.use_cte and self.cte_mode:
            # Register as CTE and return reference
            return self.register_cte(sql)
        else:
            # Return as subquery
            if needs_alias:
                alias = f"subq_{self.cte_counter + 1}"
                quoted_alias = self.quote_identifier(alias)
                return f"({sql}) AS {quoted_alias}"
            else:
                return f"({sql})"
    
    def build_bulk_column_alias(self, child_sql: str, suffix: str) -> str:
        """
        Build SQL that aliases all columns with a suffix without requiring schema discovery.
        
        This method creates a query that dynamically aliases all columns by using 
        SQL techniques that don't require knowing the column names in advance.
        
        Args:
            child_sql: The source query SQL
            suffix: The suffix to add to all column names (e.g., "_gt", "_m")
            
        Returns:
            SQL that aliases all columns with the suffix
        """
        # Use a subquery with a unique alias and let the engine handle column resolution
        # When this is used in JOINs or other operations, the columns will be accessible
        # with their original names, and the suffix logic will be handled at SQL generation time
        
        # Create a table alias that incorporates the suffix concept
        table_alias = f"src{suffix}"
        return f"SELECT * FROM ({child_sql}) AS {self.quote_identifier(table_alias)}"
    
    def start_cte_mode(self):
        """Start CTE mode for building a complex query."""
        self.reset_cte_state()
        self.cte_mode = True
    
    def end_cte_mode(self, final_query: str) -> str:
        """End CTE mode and build the final query with CTEs."""
        result = self.build_with_cte(final_query)
        self.cte_mode = False
        return result
    
    def optimize_final_query(self, sql: str, action: str = None) -> str:
        """
        Optimize final SQL query before execution.
        
        This is called by DataFrame action methods to optionally optimize
        the final SQL before sending to the database.
        
        Args:
            sql: The complete SQL query string
            action: The action being performed (collect, show, count, etc.)
            
        Returns:
            Optimized SQL string (or original if optimization is disabled/fails)
        """
        # First, resolve any BULK_ALIAS placeholders
        sql = self.resolve_bulk_alias_placeholders(sql)

        if not self.optimize_flag:
            return sql

        # Skip optimization for SQL containing functions that SQLGlot corrupts
        if self._contains_problematic_functions(sql):
            self.logger.debug(f"Skipping optimization for {action or 'action'} due to DATE_ADD/DATE_SUB in SQL")
            return sql

        try:
            # Parse the complete SQL
            ast = sg.parse_one(sql)
            
            # Apply optimizations
            optimized_ast = optimizer.optimize(ast)
            
            # Generate optimized SQL
            optimized_sql = optimized_ast.sql(dialect=self.dialect, pretty=False)
            
            self.logger.debug(f"Optimized SQL for {action or 'action'}: Original length={len(sql)}, Optimized length={len(optimized_sql)}")
            
            return optimized_sql
            
        except Exception as e:
            self.logger.warning(f"Failed to optimize final query for {action or 'action'}: {e}")
            return sql
    
    def resolve_bulk_alias_placeholders(self, sql: str) -> str:
        """
        Resolve BULK_ALIAS placeholders in the final SQL.
        
        This method finds patterns like:
        /* BULK_ALIAS_gt */ SELECT * FROM (...) /* END_BULK_ALIAS */
        
        And replaces them with actual column aliasing SQL.
        
        Args:
            sql: SQL string potentially containing BULK_ALIAS placeholders
            
        Returns:
            SQL string with placeholders resolved
        """
        import re
        
        # Pattern to match BULK_ALIAS placeholders
        pattern = r'/\* BULK_ALIAS([^*]+) \*/ SELECT \* FROM \(([^)]+(?:\([^)]*\))*[^)]*)\) /\* END_BULK_ALIAS \*/'
        
        def replace_bulk_alias(match):
            suffix = match.group(1)
            inner_sql = match.group(2)
            
            # For now, use a simpler approach that works with most SQL engines
            # This creates a subquery that can be used for column aliasing
            return f"SELECT * FROM ({inner_sql}) AS aliased_table{suffix}"
        
        # Replace all BULK_ALIAS patterns
        resolved_sql = re.sub(pattern, replace_bulk_alias, sql)
        
        return resolved_sql
    
    def build_create_table_as(self, table_name: str, select_sql: str, 
                             mode: str = "create", partition_by: list = None, 
                             if_not_exists: bool = False) -> str:
        """
        Build CREATE TABLE AS SELECT statement using SQLGlot AST construction.
        
        Args:
            table_name: Name of the table to create
            select_sql: SELECT query SQL string
            mode: create mode ("create", "replace", "create_if_not_exists")
            partition_by: List of partition columns
            if_not_exists: Whether to use IF NOT EXISTS
            
        Returns:
            Optimized CREATE TABLE AS SELECT SQL string built with SQLGlot
        """
        try:
            # Parse the SELECT query
            select_ast = sg.parse_one(select_sql)
            
            # Build CREATE TABLE AS using SQLGlot AST construction
            create_table = sg.exp.Create(
                this=sg.exp.Table(this=sg.exp.Identifier(this=table_name)),
                kind="TABLE",
                expression=select_ast,
                replace=(mode == "replace"),
                exists=(mode == "create_if_not_exists" or if_not_exists)
            )
            
            # Convert to SQL
            create_sql = create_table.sql(dialect=self.dialect)
            
            # Add partitioning if specified (SQLGlot doesn't have direct support for PARTITIONED BY)
            if partition_by:
                quoted_partition_cols = [self.quote_identifier(col) for col in partition_by]
                partition_cols = ", ".join(quoted_partition_cols)
                create_sql += f" PARTITIONED BY ({partition_cols})"
            
            return self.optimize_query(create_sql) if self.optimize_flag else create_sql
            
        except Exception as e:
            self.logger.warning(f"Failed to build CREATE TABLE AS with SQLGlot AST, falling back to string concatenation: {e}")
            # Fallback to manual construction
            if mode == "replace":
                fallback_sql = f"CREATE OR REPLACE TABLE {table_name} AS {select_sql}"
            elif mode == "create_if_not_exists" or if_not_exists:
                fallback_sql = f"CREATE TABLE IF NOT EXISTS {table_name} AS {select_sql}"
            else:
                fallback_sql = f"CREATE TABLE {table_name} AS {select_sql}"
            
            if partition_by:
                partition_cols = ", ".join(partition_by)
                fallback_sql += f" PARTITIONED BY ({partition_cols})"
            
            return fallback_sql
    
    def build_insert_into(self, table_name: str, select_sql: str, 
                         overwrite: bool = False, columns: list = None) -> str:
        """
        Build INSERT INTO statement using SQLGlot with proper column specification.
        
        Args:
            table_name: Name of the target table
            select_sql: SELECT query SQL string
            overwrite: Whether to use INSERT OVERWRITE
            columns: Optional list of target table columns for explicit column matching
            
        Returns:
            Optimized INSERT INTO SQL string with proper column specification
        """
        try:
            # Parse the SELECT query
            select_ast = sg.parse_one(select_sql)
            
            # Build INSERT using SQLGlot AST construction
            target_table = sg.exp.Table(this=sg.exp.Identifier(this=table_name))
            
            # Build column list if provided
            column_list = None
            if columns:
                column_list = [sg.exp.Identifier(this=col) for col in columns]
            
            # Create INSERT statement using SQLGlot AST
            insert_stmt = sg.exp.Insert(
                this=target_table,
                expression=select_ast,
                columns=column_list,
                overwrite=overwrite
            )
            
            # Convert to SQL
            insert_sql = insert_stmt.sql(dialect=self.dialect)
            
            return self.optimize_query(insert_sql) if self.optimize_flag else insert_sql
            
        except Exception as e:
            self.logger.warning(f"Failed to build INSERT INTO with SQLGlot, falling back to string concatenation: {e}")
            # Fallback to manual construction
            columns_clause = f"({', '.join(columns)})" if columns else ""
            if overwrite:
                return f"INSERT OVERWRITE TABLE {table_name} {columns_clause} {select_sql}"
            else:
                return f"INSERT INTO {table_name} {columns_clause} {select_sql}"
    
    def build_copy_to_file(self, select_sql: str, file_path: str, 
                          file_format: str = "PARQUET", options: dict = None) -> str:
        """
        Build WRITE INTO file statement using SQLGlot.
        
        Args:
            select_sql: SELECT query SQL string
            file_path: Target file path
            file_format: File format (PARQUET, CSV, JSON, etc.)
            options: Additional options for the WRITE statement
            
        Returns:
            Optimized WRITE INTO SQL string
        """
        try:
            # Parse the SELECT query
            select_ast = sg.parse_one(select_sql)
            
            # Build WRITE statement using SQLGlot components
            # Note: SQLGlot doesn't have direct WRITE support, so we build it manually but with proper AST handling
            
            # Build format options list in specific order: SINGLE, FILE_FORMAT, COMPRESSION, PARTITION BY, MAX_FILE_SIZE
            format_options = []
            
            # 1. SINGLE (first)
            if options and 'SINGLE' in options:
                value = options['SINGLE']
                # SINGLE should not have quotes around its value
                if isinstance(value, str):
                    format_options.append(f"SINGLE {value.upper()}")
                else:
                    format_options.append(f"SINGLE {str(value).upper()}")
            
            # 2. FILE_FORMAT (second)
            format_options.append(f"FILE_FORMAT {file_format.upper()}")

            # 3. MODE (third) - overwrite or append
            if options and 'MODE' in options:
                format_options.append(f"MODE {options['MODE'].upper()}")

            # 4. COMPRESSION (fourth)
            if options and 'COMPRESSION' in options:
                format_options.append(f"COMPRESSION '{options['COMPRESSION']}'")

            # 5. PARTITION BY (fifth)
            if options and 'partition_by' in options:
                partition_cols = options['partition_by']
                if isinstance(partition_cols, list) and partition_cols:
                    quoted_cols = [self.quote_identifier(col) for col in partition_cols]
                    format_options.append(f"PARTITION BY ({', '.join(quoted_cols)})")
            
            # 6. MAX_FILE_SIZE (last)
            if options and 'MAX_FILE_SIZE' in options:
                format_options.append(f"MAX_FILE_SIZE {options['MAX_FILE_SIZE']}")
            
            # Handle any other options not in the standard order
            if options:
                for key, value in options.items():
                    if key.upper() not in ['SINGLE', 'COMPRESSION', 'PARTITION_BY', 'MAX_FILE_SIZE', 'MODE']:
                        if isinstance(value, str):
                            format_options.append(f"{key.upper()} '{value}'")
                        elif isinstance(value, bool):
                            format_options.append(f"{key.upper()} {str(value).upper()}")
                        else:
                            format_options.append(f"{key.upper()} {value}")

            # Check for problematic functions - skip SQLGlot parsing to avoid corruption
            if self._contains_problematic_functions(select_sql):
                optimized_select = select_sql
            else:
                optimized_select = select_ast.sql(dialect=self.dialect)

            # Build WRITE statement with e6 syntax
            copy_sql = f"WRITE INTO '{file_path}'\nFROM ({optimized_select})"
            
            # Add format options as separate lines
            if format_options:
                for option in format_options:
                    copy_sql += f"\n{option}"

            return self.optimize_query(copy_sql)
            
        except Exception as e:
            self.logger.warning(f"Failed to build WRITE INTO with SQLGlot, falling back to string concatenation: {e}")
            # Fallback to manual construction with e6 syntax
            fallback_sql = f"WRITE INTO '{file_path}'\nFROM ({select_sql})"
            
            format_options = [f"FORMAT {file_format.upper()}"]
            if options:
                for key, value in options.items():
                    if key == 'partition_by':
                        # Handle partition_by specially - quote column names
                        if isinstance(value, list) and value:
                            quoted_cols = [self.quote_identifier(col) for col in value]
                            format_options.append(f"PARTITION BY ({', '.join(quoted_cols)})")
                    elif key in ('mode', 'MODE'):
                        # MODE is handled as a dedicated clause
                        if key == 'MODE':
                            format_options.append(f"MODE {value.upper()}")
                        continue
                    elif isinstance(value, str):
                        format_options.append(f"{key.upper()} '{value}'")
                    elif isinstance(value, bool):
                        format_options.append(f"{key.upper()} {str(value).upper()}")
                    else:
                        format_options.append(f"{key.upper()} {value}")
            
            # Add format options as separate lines for e6 syntax
            if format_options:
                for option in format_options:
                    fallback_sql += f"\n{option}"
            
            return fallback_sql
    
    def build_read_operation(self, format_type: str, path: str, options: Dict[str, Any]) -> str:
        """
        Build SQL for read operations using SQLGlot.
        
        Args:
            format_type: File format ('parquet', 'csv', 'json', 'orc', etc.)
            path: File path or URL
            options: Read options dictionary
            
        Returns:
            SQL string for reading data
        """
        try:
            # Build options string for the read function
            option_parts = []
            if options:
                for key, value in options.items():
                    if isinstance(value, str):
                        option_parts.append(f"{key}='{value}'")
                    elif isinstance(value, bool):
                        option_parts.append(f"{key}={str(value).lower()}")
                    else:
                        option_parts.append(f"{key}={value}")
            
            # Build the read function call
            # Use read_file for parquet and orc formats
            if format_type == 'parquet':
                func_name = 'read_file'
                file_type = 'PARQUET'
            elif format_type == 'orc':
                func_name = 'read_file'
                file_type = 'ORC'
            elif format_type == 'csv':
                func_name = 'read_csv'
                file_type = None
            elif format_type == 'json':
                func_name = 'read_json'
                file_type = None
            elif format_type == 'text':
                func_name = 'read_text'
                file_type = None
            else:
                func_name = f'read_{format_type}'
                file_type = None
            
            # Build arguments
            args = [f"'{path}'"]
            if file_type:
                args.append(f"'{file_type}'")
            if option_parts:
                args.extend(option_parts)
            
            # Use SQLGlot to build the query
            if file_type:
                # For read_file with file type
                func_call = exp.Anonymous(this=func_name, expressions=[
                    exp.Literal.string(path),
                    exp.Literal.string(file_type)
                ])
            else:
                func_call = exp.Anonymous(this=func_name, expressions=[exp.Literal.string(path)])
            
            # Add options as additional parameters if any
            if option_parts:
                # Add options to the function call expressions
                for option in option_parts:
                    func_call.expressions.append(exp.Literal.string(option))
            
            # Build SELECT statement using the AST function call
            select_ast = sg.select("*").from_(func_call)
            
            # Build fallback SQL string for error handling
            if option_parts:
                if file_type:
                    func_sql = f"{func_name}('{path}', '{file_type}', {', '.join(option_parts)})"
                else:
                    func_sql = f"{func_name}('{path}', {', '.join(option_parts)})"
            else:
                if file_type:
                    func_sql = f"{func_name}('{path}', '{file_type}')"
                else:
                    func_sql = f"{func_name}('{path}')"
            
            return self.optimize_query(select_ast)
            
        except Exception as e:
            self.logger.warning(f"Failed to build read operation with SQLGlot, using fallback: {e}")
            # Fallback to simple function call using the func_sql we built
            return f"SELECT * FROM {func_sql}"
    
    def build_write_operation(self, base_sql: str, operation_type: str, target: str, 
                            mode: str = "overwrite", options: Dict[str, Any] = None, 
                            partition_by: List[str] = None) -> str:
        """
        Build SQL for write operations using SQLGlot.
        
        Args:
            base_sql: The source query SQL
            operation_type: Type of write ('saveAsTable', 'insertInto', 'parquet', 'csv', etc.)
            target: Target table name or file path
            mode: Write mode ('overwrite', 'append', 'error', 'ignore')
            options: Write options dictionary
            partition_by: Partition columns list
            
        Returns:
            SQL string for writing data
        """
        try:
            options = options or {}
            partition_by = partition_by or []
            
            if operation_type == 'saveAsTable':
                if mode == "append":
                    return self.build_insert_into(target, base_sql, overwrite=False)
                else:
                    sql_mode = "replace" if mode == "overwrite" else "create"
                    return self.build_create_table_as(target, base_sql, sql_mode, partition_by=partition_by)
                    
            elif operation_type == 'insertInto':
                return self.build_insert_into(target, base_sql)
                
            elif operation_type in ['parquet', 'csv', 'json', 'orc']:
                # File format operations
                format_name = operation_type.upper()
                
                # Add partition_by to options if specified
                if partition_by:
                    options = options.copy() if options else {}
                    options['partition_by'] = partition_by
                    
                # Pass mode information
                options['mode'] = mode
                    
                return self.build_copy_to_file(base_sql, target, format_name, options)
                
            else:
                # Generic write operation
                return f"-- Write operation: {operation_type} to {target} (mode: {mode})\n{base_sql}"
                
        except Exception as e:
            self.logger.warning(f"Failed to build write operation with SQLGlot, using fallback: {e}")
            return f"-- Write operation failed: {operation_type} to {target}\n{base_sql}"

