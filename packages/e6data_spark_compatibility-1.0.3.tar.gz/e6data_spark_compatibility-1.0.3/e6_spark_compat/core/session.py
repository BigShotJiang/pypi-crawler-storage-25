"""
SparkSession implementation for e6data compatibility
"""
from typing import Dict, Any, Optional
from .connection import E6DataConnection
from ..sql.dataframe import DataFrame
from ..sql.reader import DataFrameReader
from .query_plan import TableScan, RawSQL
from .logging_config import logger
from .query_plan import ValuesTable
import pandas as pd

class SparkSession:
    """PySpark-compatible session for e6data"""
    
    def __init__(self, connection: E6DataConnection, configs: Dict[str, Any]):
        logger.info(f"Initializing SparkSession with app: {configs.get('spark.app.name', 'Unknown')}")
        self._connection = connection
        self._configs = configs
        self._temp_views: Dict[str, str] = {}
        logger.debug(f"SparkSession initialized with {len(configs)} configuration options")
    
    @staticmethod
    def builder():
        """Get a SparkSession builder"""
        return SparkSessionBuilder()
    
    def sql(self, query: str) -> DataFrame:
        """Execute a SQL query and return as DataFrame"""
        query_preview = query[:100].replace('\n', ' ').strip() + ('...' if len(query) > 100 else '')
        logger.info(f"Creating DataFrame from SQL: {query_preview}")
        
        # Check if query references any temp views and expand them
        logger.debug("Expanding temporary views in query")
        expanded_query = self._expand_temp_views(query)
        
        if expanded_query != query:
            logger.debug(f"Query expanded with {len(self._temp_views)} temp views")
        
        plan = RawSQL(expanded_query)
        df = DataFrame(self._connection, plan)
        logger.debug("SQL DataFrame created successfully")
        return df
    
    def table(self, table_name: str) -> DataFrame:
        """Read a table as DataFrame"""
        logger.info(f"Creating DataFrame from table: {table_name}")
        plan = TableScan(table_name)
        df = DataFrame(self._connection, plan)
        logger.debug(f"Table DataFrame created successfully for: {table_name}")
        return df
    
    @property
    def read(self) -> DataFrameReader:
        """Get a DataFrameReader"""
        return DataFrameReader(self)
    
    def stop(self):
        """Stop the SparkSession"""
        logger.info("Stopping SparkSession")
        try:
            self._connection.close()
            logger.info("SparkSession stopped successfully")
        except Exception as e:
            logger.warning(f"Error while stopping SparkSession: {e}")
    
    def _expand_temp_views(self, query: str) -> str:
        """Replace temp view references with their SQL"""
        # Simple implementation - in production, use proper SQL parsing
        result = query
        for view_name, view_sql in self._temp_views.items():
            result = result.replace(view_name, f"({view_sql}) AS {view_name}")
        return result
    
    def _register_temp_view(self, name: str, sql: str):
        """Register a temporary view"""
        logger.info(f"Registering temporary view: {name}")
        self._temp_views[name] = sql
        logger.debug(f"Temporary view '{name}' registered, total views: {len(self._temp_views)}")
    
    @property
    def conf(self):
        """Get configuration"""
        return SparkConf(self._configs)
    
    @property
    def catalog(self):
        """Get catalog interface"""
        return Catalog(self._connection)

    def range(self, start: int, end: int = None, step: int = 1, numPartitions: int = None) -> DataFrame:
        """Create a DataFrame with a single column 'id' containing a range of values.

        Args:
            start: Start of range (or end if end is None)
            end: End of range (exclusive)
            step: Step value
            numPartitions: Number of partitions (ignored, for API compatibility)

        Returns:
            DataFrame with single 'id' column
        """
        # Handle single argument case: range(10) means range(0, 10)
        if end is None:
            end = start
            start = 0

        logger.info(f"Creating range DataFrame: start={start}, end={end}, step={step}")
        from .query_plan import RangeValues
        plan = RangeValues(start, end, step)
        return DataFrame(self._connection, plan)

    def createDataFrame(self, data, schema=None):
        """Create a DataFrame from a list of data or a pandas DataFrame.

        Args:
            data: List of tuples, list of Row objects, or pandas DataFrame
            schema: Optional schema (list of column names or StructType)

        Returns:
            DataFrame
        """
        # Convert pandas DataFrame to list of tuples
        if isinstance(data, pd.DataFrame):
            if schema is None:
                schema = list(data.columns)
            data = [tuple(row) for row in data.itertuples(index=False, name=None)]

        logger.info(f"Creating DataFrame from {len(data)} rows")

        # Extract column names from schema if provided
        if schema is None:
            # Auto-generate column names
            if data is not None and len(data) > 0:
                num_cols = len(data[0]) if hasattr(data[0], '__len__') else 1
                col_names = [f"_c{i}" for i in range(num_cols)]
            else:
                col_names = []
        elif isinstance(schema, (list, tuple)):
            col_names = list(schema)
        else:
            # Assume it's a StructType-like object with field names
            col_names = [f.name if hasattr(f, 'name') else str(f) for f in schema]

        plan = ValuesTable(data, col_names)
        return DataFrame(self._connection, plan)


class SparkSessionBuilder:
    """Builder for SparkSession"""
    
    def __init__(self):
        self._configs = {}
        self._app_name = None
    
    def appName(self, name: str) -> 'SparkSessionBuilder':
        """Set application name"""
        self._app_name = name
        return self
    
    def config(self, key: str, value: Any) -> 'SparkSessionBuilder':
        """Set a configuration option"""
        self._configs[key] = value
        return self
    
    def getOrCreate(self) -> SparkSession:
        """Get or create a SparkSession"""
        logger.info(f"Creating SparkSession for app: {self._app_name or 'Unnamed'}")
        
        try:
            # Extract e6data connection parameters
            e6_params = {
                'host': self._configs.get('spark.e6data.host', 'localhost'),
                'port': int(self._configs.get('spark.e6data.port', 80)),
                'username': self._configs.get('spark.e6data.username'),
                'password': self._configs.get('spark.e6data.password'),
                'database': self._configs.get('spark.e6data.database'),
                'catalog': self._configs.get('spark.e6data.catalog'),
            }

            # Add cluster_name if provided
            if 'spark.e6data.cluster' in self._configs:
                e6_params['cluster_name'] = self._configs['spark.e6data.cluster']

            # Add secure flag if provided (defaults to False in e6data connector)
            if 'spark.e6data.secure' in self._configs:
                val = self._configs['spark.e6data.secure']
                e6_params['secure'] = str(val).lower() == 'true' if isinstance(val, str) else bool(val)
            
            # Extract grpc_options if provided
            grpc_options = {}
            grpc_option_mappings = {
                'spark.e6data.grpc_options.keepalive_time_ms': 'keepalive_time_ms',
                'spark.e6data.grpc_options.keepalive_timeout_ms': 'keepalive_timeout_ms',
                'spark.e6data.grpc_options.max_receive_message_length': 'max_receive_message_length',
                'spark.e6data.grpc_options.max_send_message_length': 'max_send_message_length',
                'spark.e6data.grpc_options.grpc_prepare_timeout': 'grpc_prepare_timeout'
            }
            
            for config_key, grpc_key in grpc_option_mappings.items():
                if config_key in self._configs:
                    grpc_options[grpc_key] = int(self._configs[config_key])
            
            if grpc_options:
                e6_params['grpc_options'] = grpc_options
                logger.debug(f"Using gRPC options: {grpc_options}")
            
            logger.debug(f"E6Data connection params: host={e6_params['host']}:{e6_params['port']}, "
                        f"database={e6_params['database']}, catalog={e6_params['catalog']}")
            
            # Create connection
            connection = E6DataConnection(**e6_params)
            
            # Add app name to configs
            if self._app_name:
                self._configs['spark.app.name'] = self._app_name
            
            # Enable colored log boxes if configured
            color_val = self._configs.get('spark.e6.log.colors', 'false')
            if str(color_val).lower() == 'true':
                from .logging_config import enable_log_colors
                enable_log_colors()

            session = SparkSession(connection, self._configs)
            logger.info("SparkSession created successfully")
            return session
            
        except Exception as e:
            logger.error(f"Failed to create SparkSession: {e}")
            raise


class SparkConf:
    """Spark configuration"""
    
    def __init__(self, configs: Dict[str, Any]):
        self._configs = configs
    
    def get(self, key: str, default: Optional[Any] = None) -> Any:
        """Get a configuration value"""
        return self._configs.get(key, default)
    
    def set(self, key: str, value: Any) -> 'SparkConf':
        """Set a configuration value"""
        self._configs[key] = value
        return self
    
    def getAll(self) -> Dict[str, Any]:
        """Get all configurations"""
        return self._configs.copy()


class Catalog:
    """Catalog interface for database operations"""
    
    def __init__(self, connection: E6DataConnection):
        self._connection = connection
    
    def listDatabases(self) -> DataFrame:
        """List all databases"""
        sql = "SHOW DATABASES"
        plan = RawSQL(sql, columns=['databaseName'])
        return DataFrame(self._connection, plan)
    
    def listTables(self, dbName: Optional[str] = None) -> DataFrame:
        """List tables in a database"""
        if dbName:
            sql = f"SHOW TABLES IN {dbName}"
        else:
            sql = "SHOW TABLES"
        plan = RawSQL(sql, columns=['database', 'tableName', 'isTemporary'])
        return DataFrame(self._connection, plan)
    
    def listColumns(self, tableName: str, dbName: Optional[str] = None) -> DataFrame:
        """List columns of a table"""
        full_name = f"{dbName}.{tableName}" if dbName else tableName
        sql = f"DESCRIBE {full_name}"
        plan = RawSQL(sql, columns=['col_name', 'data_type', 'comment'])
        return DataFrame(self._connection, plan)
    
    def tableExists(self, tableName: str, dbName: Optional[str] = None) -> bool:
        """Check if a table exists"""
        full_name = f"{dbName}.{tableName}" if dbName else tableName
        logger.debug(f"Checking if table exists: {full_name}")
        
        try:
            self._connection.execute(f"SELECT 1 FROM {full_name} LIMIT 0")
            logger.debug(f"Table exists: {full_name}")
            return True
        except Exception as e:
            logger.debug(f"Table does not exist: {full_name} - {e}")
            return False
    
    def dropTempView(self, viewName: str) -> bool:
        """Drop a temporary view"""
        # In e6data, we manage temp views in memory
        # This would be implemented based on how temp views are stored
        return True
    
    def dropGlobalTempView(self, viewName: str) -> bool:
        """Drop a global temporary view"""
        # Similar to dropTempView
        return True