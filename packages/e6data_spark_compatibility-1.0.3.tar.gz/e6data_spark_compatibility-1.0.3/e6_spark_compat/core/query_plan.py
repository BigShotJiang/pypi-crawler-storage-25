"""
Query plan nodes for building SQL queries with lazy evaluation
"""
import datetime
from abc import ABC, abstractmethod
from typing import List, Optional, Dict, Any, Union, Tuple
from dataclasses import dataclass, field
from .sql_generator import SQLGenerator
from .logging_config import logger


def generate_sql_with_cte(query_plan: 'QueryPlan', use_cte: bool = False) -> str:
    """
    Generate SQL for a query plan using CTEs when possible.
    
    This function enables CTE mode in the SQL generator, builds the query,
    and wraps it with CTEs to avoid deep nesting.
    
    Args:
        query_plan: The query plan to convert to SQL
        use_cte: Whether to use CTEs (default: True)
        
    Returns:
        SQL string with CTEs if applicable
    """
    if not use_cte:
        # Just return normal SQL without CTE optimization
        return query_plan.to_sql()
    
    # Create a new SQL generator with CTE mode
    sql_gen = SQLGenerator(use_cte=True)
    sql_gen.start_cte_mode()
    
    # Generate the main query (this will register CTEs)
    final_sql = _to_sql_recursive(query_plan, sql_gen)
    
    # Build the complete query with CTEs
    return sql_gen.end_cte_mode(final_sql)


def _project_has_window(project: 'Project') -> bool:
    """Check if a Project node contains any window function expressions."""
    for expr_sql in project.expressions.values():
        if isinstance(expr_sql, str) and " OVER (" in expr_sql.upper():
            return True
    return False


def _to_sql_recursive(plan: 'QueryPlan', sql_gen: SQLGenerator) -> str:
    """
    Recursively build SQL with a shared SQLGenerator to accumulate CTEs.
    
    Args:
        plan: The query plan node
        sql_gen: Shared SQLGenerator instance
        
    Returns:
        SQL string or CTE reference
    """
    # For each plan type, recursively handle children then build current level
    if isinstance(plan, TableScan):
        columns = plan.columns if plan.columns else ["*"]
        return sql_gen.build_select(columns=columns, from_table=plan.table_name)
    
    elif isinstance(plan, RawSQL):
        return plan.sql

    elif isinstance(plan, RangeValues):
        return plan.to_sql()

    elif isinstance(plan, ValuesTable):
        return plan.to_sql()

    elif isinstance(plan, Filter):
        child_sql = _to_sql_recursive(plan.child, sql_gen)
        return sql_gen.build_filter(child_sql=child_sql, condition=plan.condition)
    
    elif isinstance(plan, Project):
        child_sql = _to_sql_recursive(plan.child, sql_gen)
        # Try to extract a meaningful alias from the expressions
        alias_hint = None
        if "geometry" in plan.expressions and len(plan.expressions) == 1:
            alias_hint = "geometry_select"
        return sql_gen.build_project(child_sql=child_sql, expressions=plan.expressions, alias_hint=alias_hint)
    
    elif isinstance(plan, Join):
        left_sql = _to_sql_recursive(plan.left, sql_gen)
        right_sql = _to_sql_recursive(plan.right, sql_gen)
        
        left_alias = None
        right_alias = None
        if isinstance(plan.left, Alias):
            left_alias = plan.left.alias_name
        if isinstance(plan.right, Alias):
            right_alias = plan.right.alias_name
        
        # Get column information for intelligent JOIN qualification
        left_columns = plan.left.get_columns() if hasattr(plan.left, 'get_columns') else None
        right_columns = plan.right.get_columns() if hasattr(plan.right, 'get_columns') else None
        
        return sql_gen.build_join(left_sql=left_sql, right_sql=right_sql,
                                 on_condition=plan.on_condition, join_type=plan.join_type,
                                 left_alias=left_alias, right_alias=right_alias,
                                 left_columns=left_columns, right_columns=right_columns)
    
    elif isinstance(plan, Aggregate):
        child_sql = _to_sql_recursive(plan.child, sql_gen)
        return sql_gen.build_aggregate(child_sql=child_sql, group_by=plan.group_by,
                                      aggregates=plan.aggregates, having=plan.having,
                                      group_aliases=plan.group_aliases)
    
    elif isinstance(plan, Sort):
        child_sql = _to_sql_recursive(plan.child, sql_gen)
        return sql_gen.build_sort(child_sql=child_sql, order_by=plan.order_by)
    
    elif isinstance(plan, Limit):
        # If child is a Project with window functions, push LIMIT below the window
        if isinstance(plan.child, Project) and _project_has_window(plan.child):
            inner_sql = _to_sql_recursive(plan.child.child, sql_gen)
            limited_sql = f"{inner_sql} LIMIT {plan.n}"
            return sql_gen.build_project(child_sql=limited_sql, expressions=plan.child.expressions)
        child_sql = _to_sql_recursive(plan.child, sql_gen)
        return sql_gen.build_limit(child_sql=child_sql, n=plan.n)
    
    elif isinstance(plan, Distinct):
        child_sql = _to_sql_recursive(plan.child, sql_gen)
        return sql_gen.build_distinct(child_sql=child_sql)
    
    elif isinstance(plan, Union):
        left_sql = _to_sql_recursive(plan.left, sql_gen)
        right_sql = _to_sql_recursive(plan.right, sql_gen)
        return sql_gen.build_union(left_sql=left_sql, right_sql=right_sql, union_type=plan.union_type)
    
    elif isinstance(plan, WithColumn):
        # Check if we can merge consecutive WithColumn operations
        merged_columns = _collect_consecutive_with_columns(plan)
        if len(merged_columns) > 1:
            # Multiple consecutive WithColumn operations - try to merge them
            base_plan = _get_base_plan_from_with_columns(plan)
            base_sql = _to_sql_recursive(base_plan, sql_gen)
            base_columns = base_plan.get_columns()

            try:
                return sql_gen.build_merged_with_columns(base_sql, merged_columns,
                                                        child_columns=base_columns)
            except ValueError as e:
                if "Column conflicts detected" in str(e):
                    # Fall back to individual operations when conflicts are detected
                    # Extract conflict information from the error message
                    import re
                    conflict_match = re.search(r'Column conflicts detected for \[(.*?)\]', str(e))
                    conflicting_columns = set()
                    if conflict_match:
                        conflict_str = conflict_match.group(1)
                        # Parse the list format: ['col1', 'col2', 'col3']
                        conflicting_columns = set(col.strip(' "\'') for col in conflict_str.split(','))
                    
                    logger.debug(f"FALLBACK: Identified conflicting columns: {conflicting_columns}")
                    
                    # For now, just disable the conflict handling and use normal operations
                    # This will cause duplicates but at least we'll see where they come from
                    logger.debug(f"FALLBACK: Processing all columns normally (conflicts will be resolved at Project level)")
                    current_sql = base_sql
                    for col_name, expression in merged_columns:
                        current_sql = sql_gen.build_with_column(child_sql=current_sql, 
                                                              column_name=col_name, 
                                                              expression=expression,child_columns=base_columns)
                    return current_sql
                else:
                    raise
        else:
            # Single WithColumn operation
            child_sql = _to_sql_recursive(plan.child, sql_gen)
            child_columns = plan.resolved_child_columns or plan.child.get_columns()
            return sql_gen.build_with_column(child_sql=child_sql, column_name=plan.column_name,
                                           expression=plan.expression,
                                           child_columns=child_columns)
    
    elif isinstance(plan, Drop):
        child_sql = _to_sql_recursive(plan.child, sql_gen)
        child_columns = plan.child.get_columns()
        return sql_gen.build_drop(child_sql=child_sql, child_columns=child_columns, columns_to_drop=plan.columns_to_drop)
    
    elif isinstance(plan, Alias):
        # Create a CTE for aliases that represent DataFrames (used in JOINs)
        # This ensures the alias is available in the SQL context for JOIN conditions
        child_sql = _to_sql_recursive(plan.child, sql_gen)
        
        # Determine if this alias should create a CTE
        # Create CTEs for aliases that:
        # 1. Have meaningful operations (not just raw tables/reads)
        # 2. Will be used in JOINs (indicated by short alias names like 'g', 'l', 'm')
        should_create_cte = (
            # Short alias names typically used in JOINs
            len(plan.alias_name) <= 3 or
            # Or if child has transformations (Filter, Project, WithColumn, etc.)
            isinstance(plan.child, (Filter, Project, WithColumn, Aggregate, Join, Sort, Distinct))
        )
        
        if should_create_cte and sql_gen.use_cte and sql_gen.cte_mode:
            # Register as a CTE with the exact alias name
            # This is crucial for DataFrame aliases used in JOINs
            cte_name = sql_gen.register_cte(child_sql, alias=plan.alias_name, force_exact_name=True)
            return cte_name
        else:
            # For non-CTE aliases, return the child SQL with alias  
            return f"({child_sql}) AS {sql_gen.quote_identifier(plan.alias_name)}"
    
    elif isinstance(plan, Coalesce):
        # SQL doesn't have direct COALESCE for partitioning, pass through
        return _to_sql_recursive(plan.child, sql_gen)

    elif isinstance(plan, CoalesceSQL):
        child_sql = _to_sql_recursive(plan.child, sql_gen)
        child_columns = plan.resolved_columns or plan.child.get_columns()
        return sql_gen.build_coalesce_sql(child_sql, plan.value_to_fill,
                                          child_columns=child_columns,
                                          subset=plan.columns)

    elif isinstance(plan, ReadOperation):
        return sql_gen.build_read_operation(plan.format_type, plan.path, plan.options)
    
    elif isinstance(plan, WriteOperation):
        base_sql = _to_sql_recursive(plan.child, sql_gen)
        # Handle write operation (implementation depends on your needs)
        return sql_gen.build_write_operation(base_sql, plan.operation_type, plan.path, 
                                            plan.mode, plan.options, plan.partition_by)
    
    else:
        # Fallback to normal to_sql method
        return plan.to_sql()


def _collect_consecutive_with_columns(plan: 'QueryPlan') -> List[Tuple[str, str]]:
    """
    Collect consecutive WithColumn operations from the query plan.

    Stops early when a column name is repeated because chained overwrites
    (e.g. cast -> round -> format_number on the same column) each depend on
    the previous result and cannot be flattened into a single replacement dict.

    Args:
        plan: Starting WithColumn plan node

    Returns:
        List of (column_name, expression) tuples in user-execution order
        (innermost-added first, matching the order the user called .withColumn).
    """
    columns = []
    seen_names = set()
    current = plan

    while isinstance(current, WithColumn):
        if current.column_name in seen_names:
            # Same column overwritten again — stop merging here so the
            # earlier overwrites are handled as a separate nested layer.
            break
        seen_names.add(current.column_name)
        columns.append((current.column_name, current.expression))
        current = current.child

    # Plan tree puts the latest withColumn at the top (outermost). Reverse
    # to match user-execution order so SELECT projection lists the columns
    # in the order they were added — and so later expressions can be
    # rewritten to reference earlier ones consistently downstream.
    columns.reverse()
    return columns


def _get_base_plan_from_with_columns(plan: 'QueryPlan') -> 'QueryPlan':
    """
    Get the base plan by traversing through consecutive WithColumn operations.
    Stops at the same boundary as _collect_consecutive_with_columns (duplicate
    column names) so both functions agree on which nodes were merged.

    Args:
        plan: Starting WithColumn plan node
        
    Returns:
        The base query plan node (not WithColumn), or the first WithColumn
        node whose column name was already seen (start of the next chain).
    """
    seen_names = set()
    current = plan
    while isinstance(current, WithColumn):
        if current.column_name in seen_names:
            break
        seen_names.add(current.column_name)
        current = current.child
    return current


class QueryPlan(ABC):
    """Abstract base for query plan nodes"""
    @abstractmethod
    def to_sql(self) -> str:
        pass
    
    @abstractmethod
    def get_columns(self) -> List[str]:
        pass


@dataclass
class TableScan(QueryPlan):
    """Represents reading from a table"""
    table_name: str
    columns: Optional[List[str]] = None
    
    def to_sql(self) -> str:
        sql_gen = SQLGenerator()
        columns = self.columns if self.columns else ["*"]
        return sql_gen.build_select(columns=columns, from_table=self.table_name)
    
    def get_columns(self) -> List[str]:
        return self.columns or ["*"]


@dataclass
class RawSQL(QueryPlan):
    """Represents raw SQL query"""
    sql: str
    columns: Optional[List[str]] = None

    def to_sql(self) -> str:
        return self.sql

    def get_columns(self) -> List[str]:
        return self.columns or ["*"]


@dataclass
class RangeValues(QueryPlan):
    """Represents a range of values (spark.range())"""
    start: int
    end: int
    step: int = 1

    def to_sql(self) -> str:
        # Use e6data's native range() function
        if self.step == 1:
            return f"SELECT id FROM range({self.start}, {self.end})"
        else:
            # With step, use range(start, end, step)
            return f"SELECT id FROM range({self.start}, {self.end}, {self.step})"

    def get_columns(self) -> List[str]:
        return ["id"]


@dataclass
class ValuesTable(QueryPlan):
    """Represents inline values (createDataFrame)"""
    data: List[Any]
    columns: List[str]

    def to_sql(self) -> str:
        if not self.data:
            # Empty data - return empty result with correct columns
            null_cols = ", ".join([f"CAST(NULL AS STRING) AS {col}" for col in self.columns])
            return f"SELECT {null_cols} FROM (SELECT 1) AS _empty WHERE 1=0"

        # Generate VALUES clause using UNION ALL
        # Add dummy FROM clause for e6data compatibility
        rows = []
        for row in self.data:
            if hasattr(row, '__iter__') and not isinstance(row, str):
                values = []
                for v in row:
                    if v is None:
                        values.append("NULL")
                    elif isinstance(v, str):
                        escaped = v.replace("'", "''")
                        values.append(f"'{escaped}'")
                    elif isinstance(v, bool):
                        values.append("TRUE" if v else "FALSE")
                    elif isinstance(v, datetime.datetime):
                        values.append(f"CAST('{v.strftime('%Y-%m-%d %H:%M:%S')}' AS TIMESTAMP)")
                    elif isinstance(v, datetime.date):
                        values.append(f"CAST('{v.strftime('%Y-%m-%d')}' AS TIMESTAMP)")
                    else:
                        values.append(str(v))
                col_assigns = ", ".join([f"{v} AS {c}" for v, c in zip(values, self.columns)])
            else:
                # Single value row
                v = row
                if v is None:
                    val_str = "NULL"
                elif isinstance(v, str):
                    escaped = v.replace("'", "''")
                    val_str = f"'{escaped}'"
                elif isinstance(v, bool):
                    val_str = "TRUE" if v else "FALSE"
                elif isinstance(v, datetime.datetime):
                    val_str = f"CAST('{v.strftime('%Y-%m-%d %H:%M:%S')}' AS TIMESTAMP)"
                elif isinstance(v, datetime.date):
                    val_str = f"CAST('{v.strftime('%Y-%m-%d')}' AS TIMESTAMP)"
                else:
                    val_str = str(v)
                col_assigns = f"{val_str} AS {self.columns[0]}"
            # Add dummy FROM clause for e6data compatibility
            rows.append(f"SELECT {col_assigns} FROM (SELECT 1) AS _dual")

        return " UNION ALL ".join(rows)

    def get_columns(self) -> List[str]:
        return self.columns


@dataclass
class Filter(QueryPlan):
    """Represents a filter operation"""
    child: QueryPlan
    condition: str
    
    def to_sql(self) -> str:
        sql_gen = SQLGenerator()
        child_sql = self.child.to_sql()
        return sql_gen.build_filter(child_sql=child_sql, condition=self.condition)
    
    def get_columns(self) -> List[str]:
        return self.child.get_columns()


@dataclass
class Project(QueryPlan):
    """Represents a projection (select) operation"""
    child: QueryPlan
    expressions: Dict[str, str]  # alias -> expression
    
    def to_sql(self) -> str:
        sql_gen = SQLGenerator()
        child_sql = self.child.to_sql()
        return sql_gen.build_project(child_sql=child_sql, expressions=self.expressions)
    
    def get_columns(self) -> List[str]:
        return list(self.expressions.keys())


@dataclass
class Join(QueryPlan):
    """Represents a join operation"""
    left: QueryPlan
    right: QueryPlan
    on_condition: str
    join_type: str = "INNER"
    
    def to_sql(self) -> str:
        sql_gen = SQLGenerator()
        left_sql = self.left.to_sql()
        right_sql = self.right.to_sql()
        
        # Check if left or right is an Alias node
        left_alias = None
        right_alias = None
        if isinstance(self.left, Alias):
            left_alias = self.left.alias_name
        if isinstance(self.right, Alias):
            right_alias = self.right.alias_name
        
        # Qualify columns in ON condition if needed
        qualified_condition = self._qualify_on_condition(self.on_condition, left_alias, right_alias)
            
        # Get column information for intelligent JOIN qualification
        left_columns = self.left.get_columns()
        right_columns = self.right.get_columns()
        
        return sql_gen.build_join(left_sql=left_sql, right_sql=right_sql, 
                                 on_condition=qualified_condition, join_type=self.join_type,
                                 left_alias=left_alias, right_alias=right_alias,
                                 left_columns=left_columns, right_columns=right_columns)
    
    def _qualify_on_condition(self, condition: str, left_alias: str = None, right_alias: str = None) -> str:
        """Qualify columns in ON condition with table aliases to avoid ambiguity"""
        # Get column names from both sides
        left_cols = self.left.get_columns()
        right_cols = self.right.get_columns()
        
        # Find potentially ambiguous columns (exist in both sides)
        ambiguous = set(left_cols) & set(right_cols)
        
        # If there are ambiguous columns and they appear unqualified in the condition,
        # we need to determine which table they belong to based on context
        # For now, preserve the existing condition as SQLGlot optimizer will handle it
        return condition
    
    def get_columns(self) -> List[str]:
        # Return combined columns from both sides
        left_cols = self.left.get_columns()
        right_cols = self.right.get_columns()

        # If either side is unresolved ("*"), the full column list is unknown.
        # Return ["*"] so downstream nodes (e.g. CoalesceSQL) use their
        # fallback path instead of mixing "*" with real column names.
        if left_cols == ["*"] or right_cols == ["*"]:
            return ["*"]

        # Combine all columns
        all_cols = left_cols + right_cols

        # Create a result list that preserves order but avoids duplicates
        # and filters out qualified column aliases created for disambiguation
        result = []
        seen_unqualified = set()

        for col in all_cols:
                
            # If this is a qualified column name (contains dot), check if we should include it
            if '.' in col:
                # Extract the unqualified part
                unqualified = col.split('.')[-1]
                # Only include qualified names if we haven't seen the unqualified version
                # This prevents duplicating columns that were given qualified aliases
                if unqualified not in seen_unqualified:
                    result.append(col)
                    seen_unqualified.add(unqualified)
            else:
                # Unqualified column - always include if not already seen
                if col not in seen_unqualified:
                    result.append(col)
                    seen_unqualified.add(col)
        
        return result


@dataclass
class Aggregate(QueryPlan):
    """Represents aggregation operation"""
    child: QueryPlan
    group_by: List[str]
    aggregates: Dict[str, str]  # alias -> aggregate expression
    having: Optional[str] = None
    group_aliases: Optional[Dict[str, str]] = None  # column -> alias mapping
    
    def to_sql(self) -> str:
        sql_gen = SQLGenerator()
        child_sql = self.child.to_sql()
        return sql_gen.build_aggregate(child_sql=child_sql, group_by=self.group_by, 
                                     aggregates=self.aggregates, having=self.having,
                                     group_aliases=self.group_aliases)
    
    def get_columns(self) -> List[str]:
        # Return aliased names for group by columns if aliases exist
        group_aliases = self.group_aliases or {}
        aliased_group_cols = []
        for col in self.group_by:
            # Convert FunctionCall objects to their string representation
            col_key = str(col) if hasattr(col, '__str__') else col
            if col_key in group_aliases:
                aliased_group_cols.append(group_aliases[col_key])
            else:
                # If it's a string, use it as-is; if it's an object, convert to string
                aliased_group_cols.append(col if isinstance(col, str) else str(col))
        return aliased_group_cols + list(self.aggregates.keys())


@dataclass
class Sort(QueryPlan):
    """Represents sorting operation"""
    child: QueryPlan
    order_by: List[Tuple[str, str]]  # [(column, direction), ...]
    
    def to_sql(self) -> str:
        sql_gen = SQLGenerator()
        child_sql = self.child.to_sql()
        return sql_gen.build_sort(child_sql=child_sql, order_by=self.order_by)
    
    def get_columns(self) -> List[str]:
        return self.child.get_columns()


@dataclass
class Limit(QueryPlan):
    """Represents limit operation"""
    child: QueryPlan
    n: int
    
    def to_sql(self) -> str:
        sql_gen = SQLGenerator()
        # If child is a Project with window functions, push LIMIT below the window
        if isinstance(self.child, Project) and _project_has_window(self.child):
            inner_sql = self.child.child.to_sql()
            limited_sql = f"{inner_sql} LIMIT {self.n}"
            return sql_gen.build_project(child_sql=limited_sql, expressions=self.child.expressions)
        child_sql = self.child.to_sql()
        return sql_gen.build_limit(child_sql=child_sql, n=self.n)
    
    def get_columns(self) -> List[str]:
        return self.child.get_columns()


@dataclass
class Distinct(QueryPlan):
    """Represents distinct operation"""
    child: QueryPlan
    
    def to_sql(self) -> str:
        sql_gen = SQLGenerator()
        child_sql = self.child.to_sql()
        return sql_gen.build_distinct(child_sql=child_sql)
    
    def get_columns(self) -> List[str]:
        return self.child.get_columns()


@dataclass
class Union(QueryPlan):
    """Represents union operation"""
    left: QueryPlan
    right: QueryPlan
    union_type: str = "DISTINCT"  # DISTINCT or ALL
    
    def to_sql(self) -> str:
        sql_gen = SQLGenerator()
        left_sql = self.left.to_sql()
        right_sql = self.right.to_sql()
        return sql_gen.build_union(left_sql=left_sql, right_sql=right_sql, union_type=self.union_type)
    
    def get_columns(self) -> List[str]:
        return self.left.get_columns()


@dataclass
class WithColumn(QueryPlan):
    """Represents adding/replacing a column"""
    child: QueryPlan
    column_name: str
    expression: str
    resolved_child_columns: Optional[List[str]] = None

    def to_sql(self) -> str:
        sql_gen = SQLGenerator()
        child_sql = self.child.to_sql()
        child_columns = self.resolved_child_columns or self.child.get_columns()
        return sql_gen.build_with_column(child_sql=child_sql, column_name=self.column_name,
                                       expression=self.expression, child_columns=child_columns)

    def get_columns(self) -> List[str]:
        columns = self.child.get_columns().copy()  # Create a copy to avoid modifying the original
        # Don't mix "*" with real column names — keep only named columns
        columns = [c for c in columns if c != "*"]
        if self.column_name not in columns:
            columns.append(self.column_name)
        return columns


@dataclass
class Drop(QueryPlan):
    """Represents dropping columns"""
    child: QueryPlan
    columns_to_drop: List[str]
    
    def to_sql(self) -> str:
        sql_gen = SQLGenerator()
        child_sql = self.child.to_sql()
        child_columns = self.child.get_columns()
        return sql_gen.build_drop(child_sql=child_sql, child_columns=child_columns, columns_to_drop=self.columns_to_drop)
    
    def get_columns(self) -> List[str]:
        # When dropping columns after joins, we need to handle duplicate column names
        # Keep the first occurrence of each column that's not being dropped
        child_columns = self.child.get_columns()
        
        # Special handling for wildcard columns
        if child_columns == ["*"]:
            # Can't determine exact columns from wildcard
            # This is a limitation - return wildcard for now
            return ["*"]
        
        remaining_columns = []
        seen_columns = set()
        
        has_wildcard = False
        explicit_columns = []
        
        # First pass: separate wildcard from explicit columns
        for col in child_columns:
            if col == "*":
                has_wildcard = True
            else:
                explicit_columns.append(col)
        
        # Second pass: process explicit columns
        for col in explicit_columns:
            if col not in self.columns_to_drop:
                if col not in seen_columns:
                    remaining_columns.append(col)
                    seen_columns.add(col)
                # Skip duplicate occurrences
            elif col in self.columns_to_drop and col not in seen_columns:
                # If we're dropping this column but it's the first occurrence,
                # check if there are more occurrences we should keep
                remaining_occurrences = [c for c in explicit_columns[explicit_columns.index(col)+1:] if c == col]
                if remaining_occurrences:
                    # There are more occurrences, keep one
                    remaining_columns.append(col)
                    seen_columns.add(col)
        
        # If we have a wildcard and we're dropping some explicit columns,
        # we need to assume the wildcard contains those columns too
        if has_wildcard:
            # Add wildcard back, but note that we can't know what it contains
            remaining_columns.insert(0, "*")
        
        return remaining_columns


@dataclass
class ReadOperation(QueryPlan):
    """Represents a read operation (spark.read.*)"""
    format_type: str  # 'parquet', 'csv', 'json', 'orc', etc.
    path: str
    options: Dict[str, Any] = field(default_factory=dict)
    
    def to_sql(self) -> str:
        sql_gen = SQLGenerator()
        return sql_gen.build_read_operation(self.format_type, self.path, self.options)
    
    def get_columns(self) -> List[str]:
        # In a real implementation, we'd infer columns from schema
        # For now, return wildcard but mark it specially to handle in DataFrame.columns
        return ["*"]


@dataclass 
class WriteOperation(QueryPlan):
    """Represents a write operation (df.write.*)"""
    child: QueryPlan
    operation_type: str  # 'saveAsTable', 'insertInto', 'parquet', 'csv', etc.
    target: str  # table name or file path
    mode: str = "overwrite"  # 'overwrite', 'append', 'error', 'ignore'
    options: Dict[str, Any] = field(default_factory=dict)
    partition_by: List[str] = field(default_factory=list)
    
    def to_sql(self) -> str:
        sql_gen = SQLGenerator()
        # Use CTE generation for the child query to avoid deep nesting
        base_sql = generate_sql_with_cte(self.child, use_cte=True)
        
        # Prepare options - add default e6data optimization parameters for ORC
        options = self.options.copy() if self.options else {}
        if self.operation_type == 'orc':
            # Add default e6data optimization options for ORC
            if 'MAX_FILE_SIZE' not in options:
                options['MAX_FILE_SIZE'] = 5000000000  # 5GB
            if 'SINGLE' not in options:
                options['SINGLE'] = False
        
        return sql_gen.build_write_operation(
            base_sql=base_sql,
            operation_type=self.operation_type,
            target=self.target,
            mode=self.mode,
            options=options,
            partition_by=self.partition_by
        )
    
    def get_columns(self) -> List[str]:
        return self.child.get_columns()


@dataclass
class Alias(QueryPlan):
    """Represents table aliasing operation"""
    child: QueryPlan
    alias_name: str
    
    def to_sql(self) -> str:
        # Emit `(child_sql) AS "alias"` with the alias quoted.
        # Critical: downstream code (Column.to_sql for dotted refs,
        # build_aggregate, build_join's ON predicate) references the alias
        # as a *quoted* identifier — `"df1"."column"`. The FROM-clause
        # declaration must also be quoted, otherwise strict-ANSI validators
        # (Calcite) treat the quoted reference as case-sensitive and reject
        # it with `Table 'df1' not found`. Using string concatenation
        # directly avoids sqlglot's `.subquery()` which emits unquoted.
        child_sql = self.child.to_sql()
        if self.alias_name.startswith('"') and self.alias_name.endswith('"'):
            quoted_alias = self.alias_name
        else:
            quoted_alias = f'"{self.alias_name}"'
        return f"({child_sql}) AS {quoted_alias}"
    
    def get_columns(self) -> List[str]:
        # Prefix columns with alias when in a join context
        return self.child.get_columns()


@dataclass
class BulkColumnAlias(QueryPlan):
    """Represents bulk column aliasing without requiring schema discovery"""
    child: QueryPlan
    suffix: str  # The suffix to add to all columns (e.g., "_gt", "_m")
    
    def to_sql(self) -> str:
        # Generate SQL that aliases ALL columns with the suffix without knowing column names
        # We need to create actual column aliases, not just table aliases
        child_sql = self.child.to_sql()
        
        # Try to get column information from child if available without execution
        child_columns = self.child.get_columns()
        
        if child_columns and child_columns != ["*"]:
            # If we can get columns without execution, create explicit aliases
            aliased_columns = [f'"{col}" AS "{col}{self.suffix}"' for col in child_columns]
            columns_sql = ", ".join(aliased_columns)
            return f"SELECT {columns_sql} FROM ({child_sql}) AS src"
        else:
            # If columns are unknown, we need a different approach
            # Use a SQL pattern that creates the desired effect when resolved
            # This is a placeholder that will be handled specially during SQL generation
            return f"/* BULK_ALIAS{self.suffix} */ SELECT * FROM ({child_sql}) /* END_BULK_ALIAS */"
    
    def get_columns(self) -> List[str]:
        # Return the aliased column names if we can get them from child
        # Otherwise return ["*"] to indicate dynamic columns
        child_columns = self.child.get_columns()
        if child_columns and child_columns != ["*"]:
            return [f"{col}{self.suffix}" for col in child_columns]
        return ["*"]  # Indicates dynamic columns


@dataclass
class Coalesce(QueryPlan):
    """Represents coalesce/repartition operation"""
    child: QueryPlan
    num_partitions: int
    
    def to_sql(self) -> str:
        # Since SQL doesn't have a direct COALESCE operation for partitioning,
        # we just pass through the child SQL. The engine handles partitioning internally.
        return self.child.to_sql()
    
    def get_columns(self) -> List[str]:
        return self.child.get_columns()


@dataclass()
class CoalesceSQL(QueryPlan):
    """ Represents coalesce() in SQL that return first non-null value in a row """
    child: QueryPlan
    value_to_fill: Any
    columns: Optional[List]
    resolved_columns: Optional[List] = None

    def to_sql(self) -> str:
        sql_gen = SQLGenerator()
        child_sql = self.child.to_sql()
        child_columns = self.resolved_columns or self.child.get_columns()
        return sql_gen.build_coalesce_sql(child_sql, self.value_to_fill,
                                          child_columns=child_columns,
                                          subset=self.columns)

    def get_columns(self) -> List[str]:
        return self.resolved_columns or self.child.get_columns()