"""
E6Data connection wrapper
"""
import datetime
import time
from .logging_config import logger, sql_logger, generate_query_id, sql_fingerprint, log_box, format_sql
from e6data_python_connector import Connection
from typing import Dict, Any, Optional, List, Tuple

# e6data connector returns these type names as strings in cursor.description[1]
_DATE_TYPES = {"DATE"}
_TIMESTAMP_TYPES = {"TIMESTAMP", "DATETIME", "TIMESTAMP_TZ"}


def _sql_preview(query: str, max_len: int = 200) -> str:
    """Collapse whitespace and truncate SQL for log previews."""
    preview = query[:max_len].replace('\n', ' ').strip()
    if len(query) > max_len:
        preview += '...'
    return preview


class E6DataConnection:
    """Lightweight wrapper around e6data connection"""

    def __init__(self, **kwargs):
        logger.info(f"Initializing E6Data connection to {kwargs.get('host')}:{kwargs.get('port')} "
                   f"catalog={kwargs.get('catalog')} database={kwargs.get('database')}")
        try:
            self._connection = Connection(**kwargs)
            self._catalog = kwargs.get('catalog')
            self._database = kwargs.get('database')
        except Exception as e:
            logger.error(f"Failed to initialize E6Data connection: {e}")
            raise

    def execute(self, query: str, query_id: str = None,
                op: str = None, caller: str = None) -> List[Tuple]:
        """Execute query and return results"""
        query_id = query_id or generate_query_id()
        preview = _sql_preview(query)
        fingerprint = sql_fingerprint(query)

        logger.info(log_box("QUERY START",
                            query_fired=query_id, op=op, caller=caller,
                            sql_hash=fingerprint))
        sql_logger.info(f"SQL:\n{format_sql(query)}")

        t0 = time.perf_counter()
        cursor = self._connection.cursor(catalog_name=self._catalog, db_name=self._database)
        try:
            cursor.execute(query)
            results = cursor.fetchall()
            results = self._convert_types(cursor.description, results)
            duration_ms = int((time.perf_counter() - t0) * 1000)
            logger.info(log_box("QUERY END",
                                query_fired=query_id, op=op, caller=caller,
                                status="ok", duration_ms=duration_ms,
                                row_count=len(results)))
            return results
        except Exception as e:
            duration_ms = int((time.perf_counter() - t0) * 1000)
            logger.error(log_box("QUERY ERROR",
                                 query_fired=query_id, op=op, caller=caller,
                                 status="error", duration_ms=duration_ms,
                                 error=str(e)))
            raise
        finally:
            cursor.clear()
            cursor.close()
   
    @staticmethod
    def _convert_types(description, results):
        """Convert string dates/timestamps from e6data connector to Python date/datetime objects.

        The e6data connector returns DATE and TIMESTAMP/DATETIME values as strings.
        Other types (int, float, bool, Decimal) are already properly typed.
        """
        if not description or not results:
            return results

        # Find columns that need type conversion based on string type names
        date_cols = []
        timestamp_cols = []
        for i, desc in enumerate(description):
            type_name = desc[1].upper() if isinstance(desc[1], str) else str(desc[1]).upper()
            if type_name in _DATE_TYPES:
                date_cols.append(i)
            elif type_name in _TIMESTAMP_TYPES:
                timestamp_cols.append(i)

        if not date_cols and not timestamp_cols:
            return results

        converted = []
        for row in results:
            row = list(row)
            for i in date_cols:
                val = row[i]
                if val is not None and isinstance(val, str):
                    try:
                        row[i] = datetime.date.fromisoformat(val)
                    except (ValueError, TypeError):
                        pass
            for i in timestamp_cols:
                val = row[i]
                if val is not None and isinstance(val, str):
                    try:
                        row[i] = datetime.datetime.fromisoformat(val)
                    except (ValueError, TypeError):
                        pass
            converted.append(tuple(row))
        return converted

    def execute_async(self, query: str, query_id: str = None,
                       op: str = None, caller: str = None) -> str:
        """Execute query asynchronously and return query_id"""
        query_id = query_id or generate_query_id()
        preview = _sql_preview(query)
        fingerprint = sql_fingerprint(query)

        logger.info(log_box("ASYNC QUERY START",
                            query_fired=query_id, op=op, caller=caller,
                            sql_hash=fingerprint))
        sql_logger.info(f"SQL:\n{format_sql(query)}")

        cursor = self._connection.cursor(catalog_name=self._catalog, db_name=self._database)
        try:
            async_id = cursor.execute_async(query)
            logger.info(log_box("ASYNC QUERY SUBMITTED",
                                query_fired=query_id, async_id=async_id,
                                op=op, caller=caller))
            return async_id
        except Exception as e:
            logger.error(log_box("QUERY ERROR",
                                 query_fired=query_id, op=op, caller=caller,
                                 status="error", error=str(e)))
            raise
        finally:
            # Note: For async queries, cursor should be cleared after results are consumed
            # The caller is responsible for clearing the cursor after getting results
            cursor.clear()
            cursor.close()
    
    def get_columns(self, query: str) -> List[str]:
        """Get column names for a query"""
        logger.debug(f"Getting column names for query")
        cursor = self._connection.cursor(catalog_name=self._catalog, db_name=self._database)
        try:
            column_query = f"SELECT * FROM ({query}) AS t LIMIT 0"
            cursor.execute(column_query)
            columns = [desc[0] for desc in cursor.description]
            logger.debug(f"Retrieved {len(columns)} columns: {columns[:5]}{'...' if len(columns) > 5 else ''}")
            return columns
        except Exception as e:
            logger.error(f"Failed to get column names: {e}")
            raise
        finally:
            cursor.clear()
            cursor.close()
    
    def cursor(self, catalog_name=None, db_name=None):
        """Get a cursor with optional catalog and database context."""
        logger.debug("Creating new cursor")
        return self._connection.cursor(
            catalog_name=catalog_name or self._catalog,
            db_name=db_name or self._database,
        )
    
    def close(self):
        """Close the connection"""
        logger.info("Closing E6Data connection")
        try:
            self._connection.close()
            logger.info("E6Data connection closed successfully")
        except Exception as e:
            logger.warning(f"Error while closing connection: {e}")
    
    @property
    def catalog(self) -> Optional[str]:
        return self._catalog
    
    @property
    def database(self) -> Optional[str]:
        return self._database