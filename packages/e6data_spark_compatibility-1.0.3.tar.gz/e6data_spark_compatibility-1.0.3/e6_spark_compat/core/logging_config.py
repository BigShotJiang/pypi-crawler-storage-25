"""
Logging configuration for e6-spark-compat
"""
import hashlib
import logging
import os
import sys
import uuid
import warnings

def configure_logging():
    """
    Configure logging to suppress unnecessary warnings and provide better output.
    """
    # Suppress gRPC warnings
    os.environ['GRPC_VERBOSITY'] = 'ERROR'
    # Remove problematic poll strategy that can cause crashes on macOS
    # os.environ['GRPC_POLL_STRATEGY'] = 'epoll1'
    
    # Configure absl logging to avoid initialization warnings
    try:
        import absl.logging
        # Set absl logging level before it's initialized
        absl.logging.set_verbosity(absl.logging.ERROR)
        absl.logging.set_stderrthreshold(absl.logging.ERROR)
    except ImportError:
        pass
    
    # Configure Python logging
    logging.getLogger('grpc').setLevel(logging.ERROR)
    logging.getLogger('grpc._channel').setLevel(logging.ERROR)
    logging.getLogger('grpc._server').setLevel(logging.ERROR)
    
    # Suppress multiprocessing resource tracker warnings
    warnings.filterwarnings('ignore', message='resource_tracker: There appear to be')
    
    # Configure e6-spark-compat logging
    e6_logger = logging.getLogger('e6_spark_compat')
    if not e6_logger.handlers:
        handler = logging.StreamHandler()
        handler.setFormatter(
            logging.Formatter('%(message)s')
        )
        e6_logger.addHandler(handler)
        e6_logger.setLevel(logging.INFO)

    # Sub-logger for full SQL output — only visible when set to DEBUG independently
    # e.g. logging.getLogger('e6_spark_compat.query.sql').setLevel(logging.DEBUG)
    sql_logger = logging.getLogger('e6_spark_compat.query.sql')

    return e6_logger


# Resolve the package directory once, used by get_caller_info() to skip internal frames
_PACKAGE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))


_query_counter = 0

def generate_query_id() -> str:
    """Generate an incrementing query counter for correlating query start/end log lines."""
    global _query_counter
    _query_counter += 1
    return str(_query_counter)


def format_sql(sql: str) -> str:
    """Pretty-print SQL using sqlvalidator."""
    try:
        import sqlvalidator
        return sqlvalidator.format_sql(sql)
    except Exception:
        return sql


def sql_fingerprint(sql: str) -> str:
    """Return a short hash of the full SQL for log-line matching without exposing full text."""
    return hashlib.md5(sql.encode()).hexdigest()[:8]


def get_caller_info() -> str:
    """Walk the stack past e6_spark_compat frames to find the user's call site.

    Returns a string like 'my_script.py:47' or '<stdin>:1' for REPL usage.
    """
    frame = sys._getframe(1)
    while frame is not None:
        filepath = os.path.abspath(frame.f_code.co_filename)
        if not filepath.startswith(_PACKAGE_DIR):
            filename = os.path.basename(filepath)
            return f"{filename}:{frame.f_lineno}"
        frame = frame.f_back
    return "unknown:0"


# ANSI color codes — applied only when enable_log_colors() is called
_COLORS_ENABLED = False

_ANSI = {
    "blue":  "\033[34m",
    "cyan":  "\033[96m",
    "green": "\033[32m",
    "red":   "\033[31m",
    "white": "\033[37m",
    "reset": "\033[0m",
}

# Map box title keywords to colors
_BOX_COLORS = {
    "START":     "blue",
    "SUBMITTED": "blue",
    "ASYNC":     "blue",
    "END":       "green",
    "CACHED":    "green",
    "ERROR":     "red",
}


def enable_log_colors():
    """Enable colored log output for boxes. Call this to turn on colors."""
    global _COLORS_ENABLED
    _COLORS_ENABLED = True


def disable_log_colors():
    """Disable colored log output (default)."""
    global _COLORS_ENABLED
    _COLORS_ENABLED = False


def _color_for_title(title: str) -> str:
    """Pick a color based on keywords in the box title."""
    if not _COLORS_ENABLED:
        return ""
    upper = title.upper()
    for keyword, color in _BOX_COLORS.items():
        if keyword in upper:
            return _ANSI[color]
    return _ANSI["white"]


def log_box(title: str, max_width: int = 100, **fields) -> str:
    """Format a title and key=value fields into a bordered box string.

    Long values are wrapped to fit within max_width. The box never exceeds
    max_width characters total. Colors are applied only if enable_log_colors()
    has been called.

    Example output:
    ┌──────────────────────────────────────────┐
    │  QUERY START                             │
    │  query_id   : a3f1b2                     │
    │  op         : count                      │
    │  caller     : script.py:47               │
    └──────────────────────────────────────────┘
    """
    # inner_width = usable chars between "│ " and " │"
    inner_width = max_width - 4

    lines = []
    lines.append(title)
    if fields:
        max_key = max(len(str(k)) for k in fields)
        prefix_len = 2 + max_key + 3  # "  key  : "
        val_width = inner_width - prefix_len

        for k, v in fields.items():
            prefix = f"  {str(k).ljust(max_key)} : "
            val = str(v).replace('\n', ' ').replace('\r', ' ').replace('\t', ' ').strip()
            if len(val) <= val_width:
                lines.append(prefix + val)
            else:
                # wrap long values across multiple lines
                cont_prefix = " " * prefix_len
                while val:
                    chunk, val = val[:val_width], val[val_width:]
                    lines.append(prefix + chunk)
                    prefix = cont_prefix

    color = _color_for_title(title)
    reset = _ANSI["reset"] if color else ""

    box_lines = []
    box_lines.append(color + "┌" + "─" * (max_width - 2) + "┐" + reset)
    for line in lines:
        box_lines.append(color + "│ " + reset + line.ljust(inner_width) + color + " │" + reset)
    box_lines.append(color + "└" + "─" * (max_width - 2) + "┘" + reset)

    return "\n" + "\n".join(box_lines)


def colorize_show(text: str) -> str:
    """Wrap text in light cyan color if colors are enabled."""
    if not _COLORS_ENABLED:
        return text
    return _ANSI["cyan"] + text + _ANSI["reset"]


# Initialize logging when module is imported
logger = configure_logging()
sql_logger = logging.getLogger('e6_spark_compat.query.sql')