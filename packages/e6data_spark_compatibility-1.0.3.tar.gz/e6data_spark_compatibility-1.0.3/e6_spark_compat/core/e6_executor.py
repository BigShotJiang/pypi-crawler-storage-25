"""
E6 Engine Executor - Handles execution of generated SQL on E6 Engine
"""
from typing import Any, Dict, List, Optional
from .query_plan import QueryPlan, WriteOperation
from .logging_config import logger, sql_logger


class E6EngineExecutor:
    """Utility class to execute SQL operations on E6 Engine"""

    def __init__(self, connection):
        self.connection = connection

    def execute_write_operation(self, query_plan: QueryPlan, operation_type: str,
                               target: str, mode: str = "overwrite",
                               options: Dict[str, Any] = None,
                               partition_by: List[str] = None) -> bool:
        """
        Execute a write operation on E6 Engine

        Args:
            query_plan: The query plan to write
            operation_type: Type of write operation ('orc', 'parquet', etc.)
            target: Target path or table
            mode: Write mode ('append', 'overwrite', etc.)
            options: Write options (compression, etc.)
            partition_by: Partition columns

        Returns:
            bool: True if successful
        """
        # Create WriteOperation query plan
        write_plan = WriteOperation(
            child=query_plan,
            operation_type=operation_type,
            target=target,
            mode=mode,
            options=options or {},
            partition_by=partition_by or []
        )

        # Generate SQL
        sql = write_plan.to_sql()

        sql_logger.info(f"Generated SQL for {operation_type.upper()} write: {sql}")

        # Execute on E6 engine
        try:
            result = self.connection.execute(sql)
            return True
        except Exception as e:
            raise

    def execute_action(self, query_plan: QueryPlan, action_type: str = "collect"):
        """
        Execute an action operation (collect, show, count, etc.) on E6 Engine

        Args:
            query_plan: The query plan to execute
            action_type: Type of action ('collect', 'show', 'count')

        Returns:
            Results from E6 engine
        """
        # Generate SQL
        sql = query_plan.to_sql()

        sql_logger.info(f"Generated SQL for {action_type}: {sql}")

        # Execute on E6 engine
        try:
            result = self.connection.execute(sql)
            return result
        except Exception as e:
            raise


def create_e6_executor(connection):
    """Factory function to create E6EngineExecutor"""
    return E6EngineExecutor(connection)