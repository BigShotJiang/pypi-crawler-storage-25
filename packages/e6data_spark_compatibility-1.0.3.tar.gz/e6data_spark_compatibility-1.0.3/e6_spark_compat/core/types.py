"""
Type mappings between PySpark, E6Data, and NumPy
"""
from typing import Dict
import numpy as np


# E6Data to NumPy type mapping
E6DATA_TO_NUMPY_TYPES: Dict[str, np.dtype] = {
    "BOOLEAN": np.dtype("bool"),
    "TINYINT": np.dtype("int8"),
    "SMALLINT": np.dtype("int16"),
    "INTEGER": np.dtype("int32"),
    "BIGINT": np.dtype("int64"),
    "FLOAT": np.dtype("float32"),
    "DOUBLE": np.dtype("float64"),
    "VARCHAR": np.dtype("object"),
    "CHAR": np.dtype("object"),
    "DATE": np.dtype("datetime64[D]"),
    "TIMESTAMP": np.dtype("datetime64[ns]"),
    "VARBINARY": np.dtype("object"),
    "DECIMAL": np.dtype("object"),
    "ARRAY": np.dtype("object"),
    "MAP": np.dtype("object"),
    "STRUCT": np.dtype("object"),
    # Spatial types
    "GEOMETRY": np.dtype("object"),
    "POINT": np.dtype("object"),
    "POLYGON": np.dtype("object"),
    "MULTIPOLYGON": np.dtype("object"),
}

# PySpark to E6Data type mapping
PYSPARK_TO_E6DATA_TYPES = {
    "StringType": "VARCHAR",
    "IntegerType": "INTEGER",
    "LongType": "BIGINT",
    "FloatType": "FLOAT",
    "DoubleType": "DOUBLE",
    "BooleanType": "BOOLEAN",
    "DateType": "DATE",
    "TimestampType": "TIMESTAMP",
    "BinaryType": "VARBINARY",
    "ArrayType": "ARRAY",
    "MapType": "MAP",
    "StructType": "STRUCT",
    "DecimalType": "DECIMAL",
    # Spatial types
    "GeometryType": "GEOMETRY",
}

# E6Data to PySpark type mapping (reverse)
E6DATA_TO_PYSPARK_TYPES = {
    "BOOLEAN": "BooleanType",
    "TINYINT": "ByteType",
    "SMALLINT": "ShortType",
    "INTEGER": "IntegerType",
    "BIGINT": "LongType",
    "FLOAT": "FloatType",
    "DOUBLE": "DoubleType",
    "VARCHAR": "StringType",
    "CHAR": "StringType",
    "DATE": "DateType",
    "TIMESTAMP": "TimestampType",
    "VARBINARY": "BinaryType",
    "DECIMAL": "DecimalType",
    "ARRAY": "ArrayType",
    "MAP": "MapType",
    "STRUCT": "StructType",
    # Spatial types
    "GEOMETRY": "GeometryType",
    "POINT": "GeometryType",
    "POLYGON": "GeometryType",
    "MULTIPOLYGON": "GeometryType",
}