"""
Sedona compatibility module for e6-spark-compat
"""
from ..core.logging_config import logger

class SedonaRegistrator:
    """Register Sedona functions with Spark session"""

    @staticmethod
    def registerAll(spark):
        """Register all Sedona functions"""
        # In e6data, spatial functions should already be available
        # This is mainly for compatibility
        logger.info("Sedona functions registered with e6data")
        return True


class SedonaContext:
    """Sedona context for spatial operations"""
    
    @staticmethod
    def builder():
        """Get a SedonaContext builder"""
        return SedonaContextBuilder()
    
    @staticmethod
    def create(spark_session):
        """Create SedonaContext from SparkSession"""
        return SedonaSQLContext(spark_session)


class SedonaContextBuilder:
    """Builder for SedonaContext"""
    
    def __init__(self):
        self._configs = {}
    
    def config(self, key, value):
        """Set configuration"""
        self._configs[key] = value
        return self
    
    def getOrCreate(self):
        """Get or create SparkSession with Sedona"""
        from ..core.session import SparkSession
        
        spark_builder = SparkSession.builder()
        for k, v in self._configs.items():
            spark_builder = spark_builder.config(k, v)
        
        # Add Sedona-specific configs
        spark_builder = spark_builder.config("spark.sql.extensions", "org.apache.sedona.sql.SedonaSqlExtensions")
        
        return spark_builder.getOrCreate()


class SedonaSQLContext:
    """SQL context with Sedona support"""
    
    def __init__(self, spark_session):
        self.spark = spark_session
        # Register spatial functions
        SedonaRegistrator.registerAll(spark_session)
    
    def sql(self, query):
        """Execute SQL with spatial support"""
        return self.spark.sql(query)
    
    def read(self):
        """Get DataFrameReader with spatial support"""
        return self.spark.read
    
    def table(self, table_name):
        """Read table with spatial support"""
        return self.spark.table(table_name)
    
    def stop(self):
        """Stop the context"""
        self.spark.stop()


# Import spatial functions to make them available
from ..spatial.functions import *

__all__ = ['SedonaRegistrator', 'SedonaContext', 'SedonaSQLContext']