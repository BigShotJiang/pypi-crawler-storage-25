"""
e6-spark-compat: PySpark and Sedona compatibility layer for e6data
"""

# Fix multiprocessing issue on macOS/Windows before any imports
import multiprocessing
import os
import platform

# Only apply fix if:
# 1. We're on macOS (Darwin) or Windows
# 2. Not explicitly disabled via environment variable
# 3. The current method is 'spawn' (problematic)
if os.environ.get("E6_SPARK_COMPAT_NO_MP_FIX") != "1":
    try:
        current_method = multiprocessing.get_start_method(allow_none=True)
        system = platform.system()

        # macOS defaults to 'spawn' which causes re-imports
        # current_method can be None initially, which defaults to 'spawn' on macOS
        if system == "Darwin" and (current_method == "spawn" or current_method is None):
            multiprocessing.set_start_method("fork", force=True)
        # Windows only supports 'spawn', so we can't fix it this way
        elif system == "Windows" and current_method == "spawn":
            # Log a warning but continue
            import warnings

            warnings.warn(
                "e6-spark-compat: Windows detected. Scripts may execute multiple times. "
                "Use 'if __name__ == \"__main__\":' guard to prevent issues.",
                RuntimeWarning,
            )
    except (RuntimeError, ValueError):
        # Already set or platform doesn't support the change
        pass

# Initialize vendored dependencies first (patches sys.modules for sqlglot)
from . import _vendor

# Initialize logging configuration before importing other modules
from .core.logging_config import configure_logging

configure_logging()

from .core.session import SparkSession
from .core.sql_generator import set_use_cte
from .sql.column import Column
from .sql.dataframe import DataFrame
from .sql.row import Row


def display(df, n=20, truncate=True):
    """Global display function that delegates to df.display()"""
    if hasattr(df, "display"):
        df.display(n=n, truncate=truncate)
    else:
        print(df)


__version__ = "1.0.3"
__all__ = ["SparkSession", "DataFrame", "Column", "Row", "set_use_cte", "display"]
