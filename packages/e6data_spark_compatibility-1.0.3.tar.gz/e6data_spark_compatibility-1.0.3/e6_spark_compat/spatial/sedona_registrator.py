"""
Mock Sedona Registrator for e6-spark-compat
"""

class SedonaRegistrator:
    """Mock SedonaRegistrator that does nothing but allows code to run"""
    
    @staticmethod
    def registerAll(spark):
        """Mock registration - spatial functions are already available in e6_spark_compat"""
        # In e6_spark_compat, spatial functions are automatically available
        # This is just a compatibility stub
        pass