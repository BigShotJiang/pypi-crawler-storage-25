"""
Spatial functions compatible with Apache Sedona
"""
from typing import Union, List, Any
from ..sql.column import Column, FunctionCall, _to_expression
from ..sql.functions import _ensure_column, expr


# Geometry Constructors
def ST_Point(x: Union[Column, str, float], y: Union[Column, str, float]) -> FunctionCall:
    """Create a Point geometry from coordinates"""
    x_col = _to_expression(x) if not isinstance(x, Column) else x
    y_col = _to_expression(y) if not isinstance(y, Column) else y
    return FunctionCall("ST_Point", x_col, y_col)


def ST_PointFromText(wkt: Union[Column, str], srid: int = 0) -> FunctionCall:
    """Create a Point from WKT"""
    wkt_col = _ensure_column(wkt)
    if srid != 0:
        return FunctionCall("ST_PointFromText", wkt_col, _to_expression(srid))
    return FunctionCall("ST_PointFromText", wkt_col)


def ST_GeomFromText(wkt: Union[Column, str], srid: int = 0) -> FunctionCall:
    """Create geometry from WKT"""
    wkt_col = _ensure_column(wkt)
    if srid != 0:
        return FunctionCall("ST_GeomFromText", wkt_col, _to_expression(srid))
    return FunctionCall("ST_GeomFromText", wkt_col)


def ST_GeomFromWKT(wkt: Union[Column, str]) -> FunctionCall:
    """Create geometry from WKT"""
    wkt_col = _ensure_column(wkt)
    return FunctionCall("ST_GeomFromWKT", wkt_col)


def ST_GeomFromWKB(wkb: Union[Column, str]) -> FunctionCall:
    """Create geometry from WKB"""
    wkb_col = _ensure_column(wkb)
    return FunctionCall("ST_GeomFromWKB", wkb_col)


def ST_GeomFromGeoJSON(geojson: Union[Column, str]) -> FunctionCall:
    """Create geometry from GeoJSON"""
    json_col = _ensure_column(geojson)
    return FunctionCall("ST_GeomFromGeoJSON", json_col)


def ST_LineFromText(wkt: Union[Column, str], srid: int = 0) -> FunctionCall:
    """Create LineString from WKT"""
    wkt_col = _ensure_column(wkt)
    if srid != 0:
        return FunctionCall("ST_LineFromText", wkt_col, _to_expression(srid))
    return FunctionCall("ST_LineFromText", wkt_col)


def ST_PolygonFromText(wkt: Union[Column, str], srid: int = 0) -> FunctionCall:
    """Create Polygon from WKT"""
    wkt_col = _ensure_column(wkt)
    if srid != 0:
        return FunctionCall("ST_PolygonFromText", wkt_col, _to_expression(srid))
    return FunctionCall("ST_PolygonFromText", wkt_col)


def ST_MakeEnvelope(minX: float, minY: float, maxX: float, maxY: float, srid: int = 0) -> FunctionCall:
    """Create envelope (bounding box) polygon"""
    args = [_to_expression(minX), _to_expression(minY), _to_expression(maxX), _to_expression(maxY)]
    if srid != 0:
        args.append(_to_expression(srid))
    return FunctionCall("ST_MakeEnvelope", *args)


def ST_MakePolygon(linestring: Union[Column, str]) -> FunctionCall:
    """Create Polygon from LineString"""
    line_col = _ensure_column(linestring)
    return FunctionCall("ST_MakePolygon", line_col)


def ST_MakeLine(*points) -> FunctionCall:
    """Create LineString from points"""
    point_cols = [_ensure_column(p) for p in points]
    return FunctionCall("ST_MakeLine", *point_cols)


# Geometry Accessors
def ST_X(point: Union[Column, str]) -> FunctionCall:
    """Get X coordinate of Point"""
    pt_col = _ensure_column(point)
    return FunctionCall("ST_X", pt_col)


def ST_Y(point: Union[Column, str]) -> FunctionCall:
    """Get Y coordinate of Point"""
    pt_col = _ensure_column(point)
    return FunctionCall("ST_Y", pt_col)


def ST_Z(point: Union[Column, str]) -> FunctionCall:
    """Get Z coordinate of Point"""
    pt_col = _ensure_column(point)
    return FunctionCall("ST_Z", pt_col)


def ST_XMax(geometry: Union[Column, str]) -> FunctionCall:
    """Get maximum X coordinate"""
    geom_col = _ensure_column(geometry)
    return FunctionCall("ST_XMax", geom_col)


def ST_XMin(geometry: Union[Column, str]) -> FunctionCall:
    """Get minimum X coordinate"""
    geom_col = _ensure_column(geometry)
    return FunctionCall("ST_XMin", geom_col)


def ST_YMax(geometry: Union[Column, str]) -> FunctionCall:
    """Get maximum Y coordinate"""
    geom_col = _ensure_column(geometry)
    return FunctionCall("ST_YMax", geom_col)


def ST_YMin(geometry: Union[Column, str]) -> FunctionCall:
    """Get minimum Y coordinate"""
    geom_col = _ensure_column(geometry)
    return FunctionCall("ST_YMin", geom_col)


def ST_StartPoint(linestring: Union[Column, str]) -> FunctionCall:
    """Get start point of LineString"""
    line_col = _ensure_column(linestring)
    return FunctionCall("ST_StartPoint", line_col)


def ST_EndPoint(linestring: Union[Column, str]) -> FunctionCall:
    """Get end point of LineString"""
    line_col = _ensure_column(linestring)
    return FunctionCall("ST_EndPoint", line_col)


def ST_Boundary(geometry: Union[Column, str]) -> FunctionCall:
    """Get boundary of geometry"""
    geom_col = _ensure_column(geometry)
    return FunctionCall("ST_Boundary", geom_col)


def ST_ExteriorRing(polygon: Union[Column, str]) -> FunctionCall:
    """Get exterior ring of Polygon"""
    poly_col = _ensure_column(polygon)
    return FunctionCall("ST_ExteriorRing", poly_col)


def ST_InteriorRingN(polygon: Union[Column, str], n: int) -> FunctionCall:
    """Get Nth interior ring of Polygon"""
    poly_col = _ensure_column(polygon)
    return FunctionCall("ST_InteriorRingN", poly_col, _to_expression(n))


def ST_GeometryN(geometry: Union[Column, str], n: int) -> FunctionCall:
    """Get Nth geometry from collection"""
    geom_col = _ensure_column(geometry)
    return FunctionCall("ST_GeometryN", geom_col, _to_expression(n))


def ST_NumGeometries(geometry: Union[Column, str]) -> FunctionCall:
    """Get number of geometries in collection"""
    geom_col = _ensure_column(geometry)
    return FunctionCall("ST_NumGeometries", geom_col)


def ST_NumPoints(geometry: Union[Column, str]) -> FunctionCall:
    """Get number of points"""
    geom_col = _ensure_column(geometry)
    return FunctionCall("ST_NumPoints", geom_col)


def ST_PointN(linestring: Union[Column, str], n: int) -> FunctionCall:
    """Get Nth point of LineString"""
    line_col = _ensure_column(linestring)
    return FunctionCall("ST_PointN", line_col, _to_expression(n))


def ST_NPoints(geometry: Union[Column, str]) -> FunctionCall:
    """Get total number of points"""
    geom_col = _ensure_column(geometry)
    return FunctionCall("ST_NPoints", geom_col)


# Geometry Output
def ST_AsText(geometry: Union[Column, str]) -> FunctionCall:
    """Convert geometry to WKT"""
    geom_col = _ensure_column(geometry)
    return FunctionCall("ST_AsText", geom_col)


def ST_AsWKT(geometry: Union[Column, str]) -> FunctionCall:
    """Convert geometry to WKT (alias)"""
    return ST_AsText(geometry)


def ST_AsBinary(geometry: Union[Column, str]) -> FunctionCall:
    """Convert geometry to WKB"""
    geom_col = _ensure_column(geometry)
    return FunctionCall("ST_AsBinary", geom_col)


def ST_AsWKB(geometry: Union[Column, str]) -> FunctionCall:
    """Convert geometry to WKB (alias)"""
    return ST_AsBinary(geometry)


def ST_AsGeoJSON(geometry: Union[Column, str]) -> FunctionCall:
    """Convert geometry to GeoJSON"""
    geom_col = _ensure_column(geometry)
    return FunctionCall("ST_AsGeoJSON", geom_col)


def ST_AsEWKT(geometry: Union[Column, str]) -> FunctionCall:
    """Convert geometry to EWKT"""
    geom_col = _ensure_column(geometry)
    return FunctionCall("ST_AsEWKT", geom_col)


def ST_AsEWKB(geometry: Union[Column, str]) -> FunctionCall:
    """Convert geometry to EWKB"""
    geom_col = _ensure_column(geometry)
    return FunctionCall("ST_AsEWKB", geom_col)


# Spatial Relationships
def ST_Contains(geometry1: Union[Column, str], geometry2: Union[Column, str]) -> FunctionCall:
    """Test if geometry1 contains geometry2"""
    geom1_col = _ensure_column(geometry1)
    geom2_col = _ensure_column(geometry2)
    return FunctionCall("ST_Contains", geom1_col, geom2_col)


def ST_Crosses(geometry1: Union[Column, str], geometry2: Union[Column, str]) -> FunctionCall:
    """Test if geometries cross"""
    geom1_col = _ensure_column(geometry1)
    geom2_col = _ensure_column(geometry2)
    return FunctionCall("ST_Crosses", geom1_col, geom2_col)


def ST_Disjoint(geometry1: Union[Column, str], geometry2: Union[Column, str]) -> FunctionCall:
    """Test if geometries are disjoint"""
    geom1_col = _ensure_column(geometry1)
    geom2_col = _ensure_column(geometry2)
    return FunctionCall("ST_Disjoint", geom1_col, geom2_col)


def ST_Equals(geometry1: Union[Column, str], geometry2: Union[Column, str]) -> FunctionCall:
    """Test if geometries are equal"""
    geom1_col = _ensure_column(geometry1)
    geom2_col = _ensure_column(geometry2)
    return FunctionCall("ST_Equals", geom1_col, geom2_col)


def ST_Intersects(geometry1: Union[Column, str], geometry2: Union[Column, str]) -> FunctionCall:
    """Test if geometries intersect"""
    geom1_col = _ensure_column(geometry1)
    geom2_col = _ensure_column(geometry2)
    return FunctionCall("ST_Intersects", geom1_col, geom2_col)


def ST_Overlaps(geometry1: Union[Column, str], geometry2: Union[Column, str]) -> FunctionCall:
    """Test if geometries overlap"""
    geom1_col = _ensure_column(geometry1)
    geom2_col = _ensure_column(geometry2)
    return FunctionCall("ST_Overlaps", geom1_col, geom2_col)


def ST_Touches(geometry1: Union[Column, str], geometry2: Union[Column, str]) -> FunctionCall:
    """Test if geometries touch"""
    geom1_col = _ensure_column(geometry1)
    geom2_col = _ensure_column(geometry2)
    return FunctionCall("ST_Touches", geom1_col, geom2_col)


def ST_Within(geometry1: Union[Column, str], geometry2: Union[Column, str]) -> FunctionCall:
    """Test if geometry1 is within geometry2"""
    geom1_col = _ensure_column(geometry1)
    geom2_col = _ensure_column(geometry2)
    return FunctionCall("ST_Within", geom1_col, geom2_col)


def ST_Covers(geometry1: Union[Column, str], geometry2: Union[Column, str]) -> FunctionCall:
    """Test if geometry1 covers geometry2"""
    geom1_col = _ensure_column(geometry1)
    geom2_col = _ensure_column(geometry2)
    return FunctionCall("ST_Covers", geom1_col, geom2_col)


def ST_CoveredBy(geometry1: Union[Column, str], geometry2: Union[Column, str]) -> FunctionCall:
    """Test if geometry1 is covered by geometry2"""
    geom1_col = _ensure_column(geometry1)
    geom2_col = _ensure_column(geometry2)
    return FunctionCall("ST_CoveredBy", geom1_col, geom2_col)


# Spatial Analysis
def ST_Distance(geometry1: Union[Column, str], geometry2: Union[Column, str]) -> FunctionCall:
    """Calculate distance between geometries"""
    geom1_col = _ensure_column(geometry1)
    geom2_col = _ensure_column(geometry2)
    return FunctionCall("ST_Distance", geom1_col, geom2_col)


def ST_HausdorffDistance(geometry1: Union[Column, str], geometry2: Union[Column, str]) -> FunctionCall:
    """Calculate Hausdorff distance"""
    geom1_col = _ensure_column(geometry1)
    geom2_col = _ensure_column(geometry2)
    return FunctionCall("ST_HausdorffDistance", geom1_col, geom2_col)


def ST_Length(geometry: Union[Column, str]) -> FunctionCall:
    """Calculate length of LineString"""
    geom_col = _ensure_column(geometry)
    return FunctionCall("ST_Length", geom_col)


def ST_Area(geometry: Union[Column, str]) -> FunctionCall:
    """Calculate area of Polygon"""
    geom_col = _ensure_column(geometry)
    return FunctionCall("ST_Area", geom_col)


def ST_Centroid(geometry: Union[Column, str]) -> FunctionCall:
    """Calculate centroid"""
    geom_col = _ensure_column(geometry)
    return FunctionCall("ST_Centroid", geom_col)


def ST_Envelope(geometry: Union[Column, str]) -> FunctionCall:
    """Get envelope (bounding box)"""
    geom_col = _ensure_column(geometry)
    return FunctionCall("ST_Envelope", geom_col)


def ST_Buffer(geometry: Union[Column, str], radius: float) -> FunctionCall:
    """Create buffer around geometry"""
    geom_col = _ensure_column(geometry)
    return FunctionCall("ST_Buffer", geom_col, _to_expression(radius))


def ST_Intersection(geometry1: Union[Column, str], geometry2: Union[Column, str]) -> FunctionCall:
    """Calculate intersection"""
    geom1_col = _ensure_column(geometry1)
    geom2_col = _ensure_column(geometry2)
    return FunctionCall("ST_Intersection", geom1_col, geom2_col)


def ST_Union(geometry1: Union[Column, str], geometry2: Union[Column, str]) -> FunctionCall:
    """Calculate union"""
    geom1_col = _ensure_column(geometry1)
    geom2_col = _ensure_column(geometry2)
    return FunctionCall("ST_Union", geom1_col, geom2_col)


def ST_Difference(geometry1: Union[Column, str], geometry2: Union[Column, str]) -> FunctionCall:
    """Calculate difference"""
    geom1_col = _ensure_column(geometry1)
    geom2_col = _ensure_column(geometry2)
    return FunctionCall("ST_Difference", geom1_col, geom2_col)


def ST_SymDifference(geometry1: Union[Column, str], geometry2: Union[Column, str]) -> FunctionCall:
    """Calculate symmetric difference"""
    geom1_col = _ensure_column(geometry1)
    geom2_col = _ensure_column(geometry2)
    return FunctionCall("ST_SymDifference", geom1_col, geom2_col)


def ST_ConvexHull(geometry: Union[Column, str]) -> FunctionCall:
    """Calculate convex hull"""
    geom_col = _ensure_column(geometry)
    return FunctionCall("ST_ConvexHull", geom_col)


def ST_SimplifyPreserveTopology(geometry: Union[Column, str], tolerance: float) -> FunctionCall:
    """Simplify geometry preserving topology"""
    geom_col = _ensure_column(geometry)
    return FunctionCall("ST_SimplifyPreserveTopology", geom_col, _to_expression(tolerance))


def ST_IsValid(geometry: Union[Column, str]) -> FunctionCall:
    """Check if geometry is valid"""
    geom_col = _ensure_column(geometry)
    return FunctionCall("ST_IsValid", geom_col)


def ST_IsSimple(geometry: Union[Column, str]) -> FunctionCall:
    """Check if geometry is simple"""
    geom_col = _ensure_column(geometry)
    return FunctionCall("ST_IsSimple", geom_col)


def ST_IsEmpty(geometry: Union[Column, str]) -> FunctionCall:
    """Check if geometry is empty"""
    geom_col = _ensure_column(geometry)
    return FunctionCall("ST_IsEmpty", geom_col)


def ST_IsClosed(geometry: Union[Column, str]) -> FunctionCall:
    """Check if LineString is closed"""
    geom_col = _ensure_column(geometry)
    return FunctionCall("ST_IsClosed", geom_col)


# Spatial Indexing
def ST_GeoHash(geometry: Union[Column, str], precision: int) -> FunctionCall:
    """Calculate geohash"""
    geom_col = _ensure_column(geometry)
    return FunctionCall("ST_GeoHash", geom_col, _to_expression(precision))


def ST_H3CellIDs(geometry: Union[Column, str], resolution: int, fullCover: bool = True) -> FunctionCall:
    """Get H3 cell IDs covering geometry"""
    geom_col = _ensure_column(geometry)
    return FunctionCall("ST_H3CellIDs", geom_col, _to_expression(resolution), _to_expression(fullCover))


def ST_H3ToGeom(h3_indices: Union[Column, str, List]) -> FunctionCall:
    """Convert H3 indices to geometry"""
    h3_col = _ensure_column(h3_indices)
    return FunctionCall("ST_H3ToGeom", h3_col)


def ST_QuadKey(geometry: Union[Column, str], level: int) -> FunctionCall:
    """Calculate quadkey"""
    geom_col = _ensure_column(geometry)
    return FunctionCall("ST_QuadKey", geom_col, _to_expression(level))


# CRS Transformations
def ST_Transform(geometry: Union[Column, str], srid: int) -> FunctionCall:
    """Transform geometry to different CRS"""
    geom_col = _ensure_column(geometry)
    return FunctionCall("ST_Transform", geom_col, _to_expression(srid))


def ST_SetSRID(geometry: Union[Column, str], srid: int) -> FunctionCall:
    """Set SRID without transforming"""
    geom_col = _ensure_column(geometry)
    return FunctionCall("ST_SetSRID", geom_col, _to_expression(srid))


def ST_SRID(geometry: Union[Column, str]) -> FunctionCall:
    """Get SRID of geometry"""
    geom_col = _ensure_column(geometry)
    return FunctionCall("ST_SRID", geom_col)


# Aggregate Functions
def ST_Union_Aggr(geometry: Union[Column, str]) -> FunctionCall:
    """Aggregate union of geometries"""
    geom_col = _ensure_column(geometry)
    return FunctionCall("ST_Union_Aggr", geom_col)


def ST_Envelope_Aggr(geometry: Union[Column, str]) -> FunctionCall:
    """Aggregate envelope of geometries"""
    geom_col = _ensure_column(geometry)
    return FunctionCall("ST_Envelope_Aggr", geom_col)


# Grid Functions  
def ST_PointOnSurface(geometry: Union[Column, str]) -> FunctionCall:
    """Get point on surface"""
    geom_col = _ensure_column(geometry)
    return FunctionCall("ST_PointOnSurface", geom_col)


def ST_Reverse(geometry: Union[Column, str]) -> FunctionCall:
    """Reverse geometry"""
    geom_col = _ensure_column(geometry)
    return FunctionCall("ST_Reverse", geom_col)


def ST_LineInterpolatePoint(linestring: Union[Column, str], fraction: float) -> FunctionCall:
    """Interpolate point along line"""
    line_col = _ensure_column(linestring)
    return FunctionCall("ST_LineInterpolatePoint", line_col, _to_expression(fraction))


def ST_LineLocatePoint(linestring: Union[Column, str], point: Union[Column, str]) -> FunctionCall:
    """Locate point on line"""
    line_col = _ensure_column(linestring)
    pt_col = _ensure_column(point)
    return FunctionCall("ST_LineLocatePoint", line_col, pt_col)


def ST_Snap(geometry1: Union[Column, str], geometry2: Union[Column, str], tolerance: float) -> FunctionCall:
    """Snap geometry to another"""
    geom1_col = _ensure_column(geometry1)
    geom2_col = _ensure_column(geometry2)
    return FunctionCall("ST_Snap", geom1_col, geom2_col, _to_expression(tolerance))


def ST_ClosestPoint(geometry1: Union[Column, str], geometry2: Union[Column, str]) -> FunctionCall:
    """Find closest point"""
    geom1_col = _ensure_column(geometry1)
    geom2_col = _ensure_column(geometry2)
    return FunctionCall("ST_ClosestPoint", geom1_col, geom2_col)


# Export all functions
__all__ = [
    # Constructors
    'ST_Point', 'ST_PointFromText', 'ST_GeomFromText', 'ST_GeomFromWKT',
    'ST_GeomFromWKB', 'ST_GeomFromGeoJSON', 'ST_LineFromText', 'ST_PolygonFromText',
    'ST_MakeEnvelope', 'ST_MakePolygon', 'ST_MakeLine',
    
    # Accessors
    'ST_X', 'ST_Y', 'ST_Z', 'ST_XMax', 'ST_XMin', 'ST_YMax', 'ST_YMin',
    'ST_StartPoint', 'ST_EndPoint', 'ST_Boundary', 'ST_ExteriorRing',
    'ST_InteriorRingN', 'ST_GeometryN', 'ST_NumGeometries', 'ST_NumPoints',
    'ST_PointN', 'ST_NPoints',
    
    # Output
    'ST_AsText', 'ST_AsWKT', 'ST_AsBinary', 'ST_AsWKB', 'ST_AsGeoJSON',
    'ST_AsEWKT', 'ST_AsEWKB',
    
    # Relationships
    'ST_Contains', 'ST_Crosses', 'ST_Disjoint', 'ST_Equals', 'ST_Intersects',
    'ST_Overlaps', 'ST_Touches', 'ST_Within', 'ST_Covers', 'ST_CoveredBy',
    
    # Analysis
    'ST_Distance', 'ST_HausdorffDistance', 'ST_Length', 'ST_Area', 'ST_Centroid',
    'ST_Envelope', 'ST_Buffer', 'ST_Intersection', 'ST_Union', 'ST_Difference',
    'ST_SymDifference', 'ST_ConvexHull', 'ST_SimplifyPreserveTopology',
    'ST_IsValid', 'ST_IsSimple', 'ST_IsEmpty', 'ST_IsClosed',
    
    # Indexing
    'ST_GeoHash', 'ST_H3CellIDs', 'ST_H3ToGeom', 'ST_QuadKey',
    
    # CRS
    'ST_Transform', 'ST_SetSRID', 'ST_SRID',
    
    # Aggregates
    'ST_Union_Aggr', 'ST_Envelope_Aggr',
    
    # Other
    'ST_PointOnSurface', 'ST_Reverse', 'ST_LineInterpolatePoint',
    'ST_LineLocatePoint', 'ST_Snap', 'ST_ClosestPoint',
]