"""
GroupedData implementation for aggregations
"""
from typing import List, Dict, Union, Any
from ..core.query_plan import QueryPlan, Aggregate
from ..core.connection import E6DataConnection
from .column import Column, Expression, _to_expression


class GroupedData:
    """Represents grouped data for aggregation"""
    
    def __init__(self, connection: E6DataConnection, query_plan: QueryPlan, 
                 group_cols: List[str], group_aliases: Dict[str, str] = None):
        self._connection = connection
        self._query_plan = query_plan
        self._group_cols = group_cols
        self._group_aliases = group_aliases or {}
    
    def agg(self, *exprs) -> 'DataFrame':
        """Perform aggregation with expressions"""
        from .dataframe import DataFrame
        
        aggregates = {}
        
        for expr in exprs:
            if isinstance(expr, dict):
                # Dictionary of column -> aggregate function
                for col_name, agg_func in expr.items():
                    if isinstance(agg_func, str):
                        # Simple aggregate like 'sum', 'avg' - use SQLGlot
                        from ..core.sql_generator import SQLGenerator
                        sql_gen = SQLGenerator()
                        agg_expr = sql_gen.build_function_call(agg_func.upper(), col_name)
                        alias = f"{agg_func}_{col_name}"
                    else:
                        # Complex expression
                        agg_expr = agg_func.to_sql() if hasattr(agg_func, 'to_sql') else str(agg_func)
                        alias = f"agg_{len(aggregates)}"
                    aggregates[alias] = agg_expr
            elif hasattr(expr, 'to_sql'):
                # Expression with to_sql method
                alias = getattr(expr, '_alias', None) or f"agg_{len(aggregates)}"
                aggregates[alias] = expr.to_sql()
            else:
                # Assume it's a column name with default aggregation
                aggregates[f"agg_{len(aggregates)}"] = str(expr)
        
        agg_plan = Aggregate(self._query_plan, self._group_cols, aggregates, 
                           group_aliases=self._group_aliases)
        return DataFrame(self._connection, agg_plan)
    
    def count(self) -> 'DataFrame':
        """Count rows in each group"""
        from .dataframe import DataFrame
        
        # Use SQLGlot for COUNT(*) generation
        from ..core.sql_generator import SQLGenerator
        sql_gen = SQLGenerator()
        count_expr = sql_gen.build_function_call("COUNT", "*")
        
        aggregates = {"count": count_expr}
        agg_plan = Aggregate(self._query_plan, self._group_cols, aggregates, 
                           group_aliases=self._group_aliases)
        return DataFrame(self._connection, agg_plan)
    
    def sum(self, *cols) -> 'DataFrame':
        """Sum values in each group"""
        return self._apply_agg_func("SUM", *cols)
    
    def avg(self, *cols) -> 'DataFrame':
        """Average values in each group"""
        return self._apply_agg_func("AVG", *cols)
    
    def mean(self, *cols) -> 'DataFrame':
        """Alias for avg"""
        return self.avg(*cols)
    
    def max(self, *cols) -> 'DataFrame':
        """Maximum values in each group"""
        return self._apply_agg_func("MAX", *cols)
    
    def min(self, *cols) -> 'DataFrame':
        """Minimum values in each group"""
        return self._apply_agg_func("MIN", *cols)
    
    def pivot(self, pivot_col: str, values: List[Any] = None) -> 'GroupedData':
        """Pivot on a column"""
        # This would need a more complex implementation
        # For now, return self to allow chaining
        self._pivot_col = pivot_col
        self._pivot_values = values
        return self
    
    def _apply_agg_func(self, func_name: str, *cols) -> 'DataFrame':
        """Apply an aggregate function to columns"""
        from .dataframe import DataFrame
        
        if not cols:
            # If no columns specified, apply to all non-grouping columns
            # This is a simplification - use SQLGlot for COUNT(*)
            from ..core.sql_generator import SQLGenerator
            sql_gen = SQLGenerator()
            aggregates = {"count": sql_gen.build_function_call("COUNT", "*")}
        else:
            aggregates = {}
            for col in cols:
                col_name = col if isinstance(col, str) else col.name
                alias = f"{func_name.lower()}_{col_name}"
                # Use SQLGlot for aggregate function generation
                from ..core.sql_generator import SQLGenerator
                sql_gen = SQLGenerator()
                aggregates[alias] = sql_gen.build_function_call(func_name, col_name)
        
        agg_plan = Aggregate(self._query_plan, self._group_cols, aggregates, 
                           group_aliases=self._group_aliases)
        return DataFrame(self._connection, agg_plan)