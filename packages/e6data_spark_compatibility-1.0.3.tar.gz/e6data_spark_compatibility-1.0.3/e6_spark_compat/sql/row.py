"""
PySpark-compatible Row class that supports both index and key-based access.
"""


class Row(tuple):
    """A row in a DataFrame, compatible with PySpark's Row.

    Supports:
    - Index access: row[0], row[1]
    - Key access: row["col_name"]
    - Attribute access: row.col_name
    - dict conversion: row.asDict()
    - len, iter, repr
    """

    def __new__(cls, *args, **kwargs):
        if kwargs:
            # Row(name="Alice", age=30) style
            keys = tuple(kwargs.keys())
            values = tuple(kwargs.values())
            inst = super().__new__(cls, values)
            inst._fields = keys
            return inst
        elif len(args) == 2 and isinstance(args[0], (list, tuple)) and isinstance(args[1], (list, tuple)):
            # Internal: Row(fields, values)
            fields, values = args
            inst = super().__new__(cls, values)
            inst._fields = tuple(fields)
            return inst
        else:
            # Row(val1, val2, ...) — positional only, no field names
            inst = super().__new__(cls, args)
            inst._fields = None
            return inst

    def __getitem__(self, item):
        if isinstance(item, str):
            if self._fields is None:
                raise ValueError("Row does not have field names")
            try:
                idx = self._fields.index(item)
            except ValueError:
                raise KeyError(item)
            return super().__getitem__(idx)
        return super().__getitem__(item)

    def __getattr__(self, name):
        if name.startswith('_'):
            raise AttributeError(name)
        if self._fields is not None and name in self._fields:
            return self[name]
        raise AttributeError(f"Row has no field '{name}'")

    def asDict(self, recursive=False):
        """Convert to dictionary."""
        if self._fields is None:
            raise ValueError("Row does not have field names")
        return dict(zip(self._fields, self))

    def __repr__(self):
        if self._fields is not None:
            fields = ", ".join(f"{k}={v!r}" for k, v in zip(self._fields, self))
            return f"Row({fields})"
        return f"Row({', '.join(repr(v) for v in self)})"
