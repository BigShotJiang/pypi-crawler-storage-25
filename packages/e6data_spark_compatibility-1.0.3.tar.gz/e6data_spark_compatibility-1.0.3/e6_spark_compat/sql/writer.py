"""
DataFrameWriter for output operations
"""
import datetime
from typing import Optional, Dict, Any, List
from ..core.query_plan import QueryPlan
from ..core.connection import E6DataConnection

from ..core.logging_config import logger, sql_logger, generate_query_id, get_caller_info, sql_fingerprint, log_box, format_sql

class DataFrameWriter:
    """Handles writing DataFrame to various destinations"""

    def __init__(self, connection: E6DataConnection, query_plan: QueryPlan):
        self._connection = connection
        self._query_plan = query_plan
        self._mode = "error"  # error, append, overwrite, ignore
        self._format = None
        self._options = {}
        self._partition_by = []
        self._bucket_by = None
        self._sort_by = []
        self._path = None
        self._table_name = None
    
    VALID_MODES = {"append", "overwrite", "error", "errorifexists", "ignore"}

    def mode(self, saveMode: str) -> 'DataFrameWriter':
        """
        Set write mode:
        - 'append': Append to existing data
        - 'overwrite': Overwrite existing data
        - 'error' or 'errorifexists': Throw error if data exists (default)
        - 'ignore': Ignore write if data exists
        """
        normalized = saveMode.lower()
        if normalized not in self.VALID_MODES:
            raise ValueError(
                f"Unknown save mode: '{saveMode}'. "
                f"Accepted modes are: {', '.join(sorted(self.VALID_MODES))}"
            )
        # Normalize 'errorifexists' to 'error'
        if normalized == "errorifexists":
            normalized = "error"
        self._mode = normalized
        return self
    
    def format(self, source: str) -> 'DataFrameWriter':
        """Set output format (parquet, orc, csv, json, etc.)"""
        self._format = source.lower()
        return self
    
    def option(self, key: str, value: Any) -> 'DataFrameWriter':
        """Set a write option"""
        self._options[key] = value
        return self
    
    def options(self, **options) -> 'DataFrameWriter':
        """Set multiple write options"""
        self._options.update(options)
        return self
    
    def partitionBy(self, *cols: str) -> 'DataFrameWriter':
        """Set partition columns"""
        self._partition_by = list(cols)
        return self
    
    def bucketBy(self, numBuckets: int, col: str, *cols: str) -> 'DataFrameWriter':
        """Set bucketing"""
        self._bucket_by = (numBuckets, [col] + list(cols))
        return self
    
    def sortBy(self, col: str, *cols: str) -> 'DataFrameWriter':
        """Set sort columns within partitions"""
        self._sort_by = [col] + list(cols)
        return self
    
    def save(self, path: str = None):
        """Save to the specified path"""
        if self._format == "noop":
            return self._execute_noop()

        if path:
            self._path = path

        if not self._path:
            raise ValueError("Path is required for save operation")

        self._execute_write()
    
    def insertInto(self, tableName: str, overwrite: bool = None) -> None:
        """Insert into an existing table"""
        self._table_name = tableName
        if overwrite is not None:
            self._mode = "overwrite" if overwrite else "append"
        
        self._execute_insert()
    
    def saveAsTable(self, name: str, format: str = None, mode: str = None,
                    partitionBy: List[str] = None, **options) -> None:
        """Save as a table"""
        self._table_name = name
        
        if format:
            self._format = format
        if mode:
            self._mode = mode
        if partitionBy:
            self._partition_by = partitionBy
        if options:
            self._options.update(options)
        
        self._execute_write_table()
    
    # Format-specific convenience methods
    def parquet(self, path: str, mode: str = None, partitionBy: List[str] = None,
                compression: str = None) -> None:
        """Write as Parquet files"""
        self._format = "parquet"
        self._path = path
        
        if mode:
            self._mode = mode
        if partitionBy:
            self._partition_by = partitionBy
        if compression:
            self._options["compression"] = compression
        
        # Add default e6data options for Parquet
        self._options.setdefault("MAX_FILE_SIZE", 5000000000)
        self._options.setdefault("SINGLE", "FALSE")
        
        self._execute_write()
    
    def orc(self, path: str, mode: str = None, partitionBy: List[str] = None,
            compression: str = None):
        """Write as ORC files"""
        from ..core.query_plan import WriteOperation
        
        self._format = "orc"
        self._path = path
        
        if mode:
            self._mode = mode
        if partitionBy:
            self._partition_by = partitionBy
        if compression:
            self._options["compression"] = compression
        
        # Check if we should execute on E6 engine or return query plan
        if hasattr(self._connection, 'execute') and callable(getattr(self._connection, 'execute')):
            # Execute on E6 engine
            from ..core.e6_executor import E6EngineExecutor
            executor = E6EngineExecutor(self._connection)
            executor.execute_write_operation(
                query_plan=self._query_plan,
                operation_type='orc',
                target=path,
                mode=self._mode,
                options=self._options.copy(),
                partition_by=self._partition_by.copy()
            )
            return None  # PySpark-like behavior
        else:
            # Return query plan for SQL extraction (backward compatibility)
            write_plan = WriteOperation(
                child=self._query_plan,
                operation_type='orc',
                target=path,
                mode=self._mode,
                options=self._options.copy(),
                partition_by=self._partition_by.copy()
            )
            return write_plan
    
    def csv(self, path: str, mode: str = None, compression: str = None, sep: str = None,
            quote: str = None, escape: str = None, header: bool = None, nullValue: str = None,
            dateFormat: str = None, timestampFormat: str = None) -> None:
        """Write as CSV files"""
        self._format = "csv"
        self._path = path
        
        if mode:
            self._mode = mode
        
        # Set CSV-specific options
        if compression:
            self._options["compression"] = compression
        if sep:
            self._options["sep"] = sep
        if quote:
            self._options["quote"] = quote
        if escape:
            self._options["escape"] = escape
        if header is not None:
            self._options["header"] = str(header).lower()
        if nullValue:
            self._options["nullValue"] = nullValue
        if dateFormat:
            self._options["dateFormat"] = dateFormat
        if timestampFormat:
            self._options["timestampFormat"] = timestampFormat
        
        # Add default e6data optimization options for CSV
        self._options.setdefault("MAX_FILE_SIZE", 5000000000)  # 5GB
        self._options.setdefault("SINGLE", "FALSE")
        
        self._execute_write()
    
    def json(self, path: str, mode: str = None, compression: str = None,
             dateFormat: str = None, timestampFormat: str = None) -> None:
        """Write as JSON files"""
        self._format = "json"
        self._path = path
        
        if mode:
            self._mode = mode
        
        # Set JSON-specific options
        if compression:
            self._options["compression"] = compression
        if dateFormat:
            self._options["dateFormat"] = dateFormat
        if timestampFormat:
            self._options["timestampFormat"] = timestampFormat
        
        # Add default e6data optimization options for JSON
        self._options.setdefault("MAX_FILE_SIZE", 5000000000)  # 5GB
        self._options.setdefault("SINGLE", "FALSE")
        
        self._execute_write()
    
    def text(self, path: str, compression: str = None) -> None:
        """Write as text files"""
        self._format = "text"
        self._path = path
        
        if compression:
            self._options["compression"] = compression
        
        # Add default e6data optimization options for text files
        self._options.setdefault("MAX_FILE_SIZE", 5000000000)  # 5GB
        self._options.setdefault("SINGLE", "FALSE")
        
        self._execute_write()
    
    def jdbc(self, url: str, table: str, mode: str = None, properties: Dict[str, str] = None) -> None:
        """Write to JDBC destination"""
        self._format = "jdbc"
        self._options["url"] = url
        self._options["dbtable"] = table
        
        if mode:
            self._mode = mode
        if properties:
            self._options.update(properties)
        
        self._execute_write()
    
    def _execute_noop(self):
        raise NotImplementedError("noop write not supported")

    def _execute_write(self) -> None:
        """Execute the write operation to a path"""
        # Generate SQL using CTEs to avoid deep nesting
        from ..core.query_plan import generate_sql_with_cte
        from ..core.sql_generator import SQLGenerator, get_use_cte

        sql = generate_sql_with_cte(self._query_plan, use_cte=get_use_cte())
        
        # Apply column ambiguity fix (same as count() operation)
        sql_gen = SQLGenerator()
        sql = sql_gen._fix_column_ambiguity(sql)
        
        # Pass write mode into options so it's included in the SQL
        if self._mode and self._mode != "error":
            self._options["MODE"] = self._mode.upper()

        # Build the write SQL based on format and options
        if self._format == "parquet":
            write_sql = self._build_parquet_write_sql(sql)
        elif self._format == "orc":
            write_sql = self._build_orc_write_sql(sql)
        elif self._format == "csv":
            write_sql = self._build_csv_write_sql(sql)
        elif self._format == "json":
            write_sql = self._build_json_write_sql(sql)
        else:
            # Generic write
            write_sql = self._build_generic_write_sql(sql)

        import time
        qid = generate_query_id()
        caller = get_caller_info()
        preview = write_sql[:200].replace('\n', ' ').strip() + ('...' if len(write_sql) > 200 else '')
        fingerprint = sql_fingerprint(write_sql)
        logger.info(log_box("QUERY START",
                            query_fired=qid, op="write", caller=caller,
                            sql_preview=preview, sql_hash=fingerprint))
        sql_logger.info(f"SQL:\n{format_sql(write_sql)}")

        # Execute the write
        t0 = time.perf_counter()
        cursor = self._connection.cursor()
        try:
            cursor.execute(write_sql)
            cursor.fetchall()
            duration_ms = int((time.perf_counter() - t0) * 1000)
            logger.info(log_box("QUERY END",
                                query_fired=qid, op="write", caller=caller,
                                status="ok", duration_ms=duration_ms))
        finally:
            cursor.clear()
            cursor.close()

    
    def _execute_write_table(self) -> None:
        """Execute write to a table using SQLGlot"""
        from ..core.sql_generator import SQLGenerator, get_use_cte
        from ..core.query_plan import generate_sql_with_cte

        sql = generate_sql_with_cte(self._query_plan, use_cte=get_use_cte())
        sql_gen = SQLGenerator()
        
        # Apply column ambiguity fix (same as count() operation)
        sql = sql_gen._fix_column_ambiguity(sql)
        
        # Build CREATE TABLE or INSERT based on mode
        if self._mode == "append":
            # Use INSERT INTO for append mode
            write_sql = sql_gen.build_insert_into(
                table_name=self._table_name,
                select_sql=sql,
                overwrite=False
            )
        else:
            # Use CREATE TABLE AS for other modes
            if self._mode == "overwrite":
                mode = "replace"
            elif self._mode == "ignore":
                mode = "create_if_not_exists"
            else:  # error mode
                mode = "create"
            
            write_sql = sql_gen.build_create_table_as(
                table_name=self._table_name,
                select_sql=sql,
                mode=mode,
                partition_by=self._partition_by if self._partition_by else None
            )
        
        # Execute the table write
        import time
        qid = generate_query_id()
        caller = get_caller_info()
        preview = write_sql[:200].replace('\n', ' ').strip() + ('...' if len(write_sql) > 200 else '')
        fingerprint = sql_fingerprint(write_sql)
        logger.info(log_box("QUERY START",
                            query_fired=qid, op="write_table", caller=caller,
                            sql_preview=preview, sql_hash=fingerprint))
        sql_logger.info(f"SQL:\n{format_sql(write_sql)}")

        t0 = time.perf_counter()
        cursor = self._connection.cursor()
        try:
            cursor.execute(write_sql)
            cursor.fetchall()
            duration_ms = int((time.perf_counter() - t0) * 1000)
            logger.info(log_box("QUERY END",
                                query_fired=qid, op="write_table", caller=caller,
                                status="ok", duration_ms=duration_ms))
        finally:
            cursor.clear()
            cursor.close()

    
    def _execute_insert(self) -> None:
        """Execute INSERT INTO operation using SQLGlot with proper column handling"""
        from ..core.sql_generator import SQLGenerator, get_use_cte
        from ..core.query_plan import generate_sql_with_cte

        sql = generate_sql_with_cte(self._query_plan, use_cte=get_use_cte())
        sql_gen = SQLGenerator()
        
        # Use SQL as-is for now
        
        # Try to get target table schema for proper column matching
        target_columns = None
        try:
            # Attempt to get table schema from connection
            # This follows PySpark's insertInto() behavior of positional column matching
            schema_result = self._connection.cursor().execute(f"DESCRIBE {self._table_name}")
            if schema_result:
                target_columns = [row[0] for row in schema_result.fetchall()]  # Column names from DESCRIBE
        except Exception:
            # If we can't get schema, use default behavior (positional matching)
            pass
        
        # Use SQLGlot to build INSERT statement with column specification when available
        write_sql = sql_gen.build_insert_into(
            table_name=self._table_name,
            select_sql=sql,
            overwrite=(self._mode == "overwrite"),
            columns=target_columns
        )
        
        cursor = self._connection.cursor()
        try:
            cursor.execute(write_sql)
            cursor.fetchall()
        finally:
            cursor.clear()
            cursor.close()
    
    def _build_parquet_write_sql(self, select_sql: str) -> str:
        """Build SQL for writing Parquet files using SQLGlot"""
        from ..core.sql_generator import SQLGenerator
        
        sql_gen = SQLGenerator()
        
        # Prepare options for Parquet
        options = {}
        if self._options.get("compression"):
            options["COMPRESSION"] = self._options["compression"]
        if self._partition_by:
            options["PARTITIONED_BY"] = f"({', '.join(self._partition_by)})"
        
        # Add any other custom options
        for key, value in self._options.items():
            if key not in ["compression"]:
                options[key] = value
        
        return sql_gen.build_copy_to_file(
            select_sql=select_sql,
            file_path=self._path,
            file_format="PARQUET",
            options=options
        )
    
    def _build_orc_write_sql(self, select_sql: str) -> str:
        """Build SQL for writing ORC files using SQLGlot"""
        from ..core.sql_generator import SQLGenerator
        
        sql_gen = SQLGenerator()
        
        # Prepare options for ORC
        options = {}
        if self._options.get("compression"):
            options["COMPRESSION"] = self._options["compression"]
        
        # Add partitioning if specified
        if self._partition_by:
            options["partition_by"] = self._partition_by
        
        # Add default e6data optimization options for ORC
        options["MAX_FILE_SIZE"] = 5000000000  # 5GB
        options["SINGLE"] = False
        
        # Add any other custom options (can override defaults)
        for key, value in self._options.items():
            if key not in ["compression"]:
                options[key] = value
        
        return sql_gen.build_copy_to_file(
            select_sql=select_sql,
            file_path=self._path,
            file_format="ORC",
            options=options
        )
    
    def _build_csv_write_sql(self, select_sql: str) -> str:
        """Build SQL for writing CSV files using SQLGlot"""
        from ..core.sql_generator import SQLGenerator
        
        sql_gen = SQLGenerator()
        
        # Prepare options for CSV
        options = {}
        
        # Map PySpark CSV options to SQL options
        option_mapping = {
            "sep": "DELIMITER",
            "header": "HEADER", 
            "quote": "QUOTE",
            "escape": "ESCAPE",
            "nullValue": "NULL",
            "compression": "COMPRESSION"
        }
        
        for pyspark_opt, sql_opt in option_mapping.items():
            if self._options.get(pyspark_opt):
                options[sql_opt] = self._options[pyspark_opt]
        
        # Add default e6data optimization options for CSV
        options["MAX_FILE_SIZE"] = 5000000000  # 5GB
        options["SINGLE"] = False
        
        # Add any other custom options (can override defaults)
        for key, value in self._options.items():
            if key not in option_mapping:
                options[key] = value
        
        return sql_gen.build_copy_to_file(
            select_sql=select_sql,
            file_path=self._path,
            file_format="CSV",
            options=options
        )
    
    def _build_json_write_sql(self, select_sql: str) -> str:
        """Build SQL for writing JSON files using SQLGlot"""
        from ..core.sql_generator import SQLGenerator
        
        sql_gen = SQLGenerator()
        
        # Prepare options for JSON
        options = {}
        if self._options.get("compression"):
            options["COMPRESSION"] = self._options["compression"]
        
        # Add default e6data optimization options for JSON
        options["MAX_FILE_SIZE"] = 5000000000  # 5GB
        options["SINGLE"] = False
        
        # Add any other custom options (can override defaults)
        for key, value in self._options.items():
            if key not in ["compression"]:
                options[key] = value
        
        return sql_gen.build_copy_to_file(
            select_sql=select_sql,
            file_path=self._path,
            file_format="JSON",
            options=options
        )
    
    def _build_generic_write_sql(self, select_sql: str) -> str:
        """Build generic write SQL using SQLGlot"""
        from ..core.sql_generator import SQLGenerator
        
        sql_gen = SQLGenerator()
        
        # For formats not explicitly handled
        format_str = self._format.upper() if self._format else "PARQUET"
        
        return sql_gen.build_copy_to_file(
            select_sql=select_sql,
            file_path=self._path,
            file_format=format_str,
            options=self._options
        )