"""
DataFrame implementation with lazy evaluation
"""
from __future__ import annotations
from typing import List, Union, Optional, Any, Dict, Tuple
import pandas as pd
from ..core.query_plan import *
from ..core.connection import E6DataConnection
from ..core.logging_config import logger, sql_logger, generate_query_id, get_caller_info, log_box, colorize_show, format_sql
from .column import Column, Expression,SortExpression
from .group import GroupedData
from .writer import DataFrameWriter
from ..core.schema_cache import SchemaCache


class DataFrame:
    """Lazy DataFrame that builds query plan"""
    
    def __init__(self, connection: E6DataConnection, query_plan: QueryPlan):
        self._connection = connection
        self._query_plan = query_plan
        self._cached_result = None
        self._is_cached = False
        self._cached_columns = None  # Cache for column names
    
    def __getattr__(self, name: str) -> Column:
        """Enable dynamic column access like df.column_name (PySpark compatibility)"""
        # Avoid infinite recursion for internal attributes
        if name.startswith('_'):
            raise AttributeError(f"'{self.__class__.__name__}' object has no attribute '{name}'")
        
        # Return a Column object for the requested column name
        from .column import col
        return col(name)
    
    @classmethod
    def from_table(cls, connection: E6DataConnection, table_name: str) -> 'DataFrame':
        """Create DataFrame from table"""
        plan = TableScan(table_name)
        return cls(connection, plan)
    
    @classmethod
    def from_query(cls, connection: E6DataConnection, query: str) -> 'DataFrame':
        """Create DataFrame from SQL query"""
        plan = RawSQL(query)
        return cls(connection, plan)
    
    # Transformations (lazy)
    def select(self, *cols) -> 'DataFrame':
        """Lazy select operation"""
        from .column import DataFrameStarExpression
        expressions = {}
        
        for col in cols:
            if isinstance(col, str):
                # Simple column name
                expressions[col] = col
            elif isinstance(col, DataFrameStarExpression):
                # Special handling for df["*"] - expand to all columns from that DataFrame
                # Get columns from the source DataFrame's query plan
                source_columns = col.dataframe._query_plan.get_columns()
                if source_columns and source_columns[0] != "*":
                    # Add each column explicitly
                    for col_name in source_columns:
                        expressions[col_name] = col_name
                else:
                    # If we can't determine columns, this means "all columns from this DataFrame"
                    # We need a special marker in expressions to indicate this
                    expressions["__DATAFRAME_STAR__"] = "*"
            elif isinstance(col, Column):
                # Column with possible alias
                if col._alias:
                    alias = col._alias
                else:
                    # For struct field access, use just the field name as alias
                    if '.' in col.name and not col.name.startswith('"'):
                        # Extract field name after the dot for the alias
                        parts = col.name.split('.', 1)
                        alias = parts[1] if len(parts) == 2 else col.name
                    else:
                        alias = col.name
                
                # For struct field access, we need the raw column name without quotes
                # Check if this is a struct field pattern (e.g., data.category)
                if '.' in col.name and not col.name.startswith('"'):
                    # This looks like struct field access
                    # Use the raw column name for the expression
                    expressions[alias] = col.name
                else:
                    expressions[alias] = col.to_sql()
            elif isinstance(col, Expression):
                # Complex expression - generate alias
                if hasattr(col, '_alias') and col._alias:
                    alias = col._alias
                else:
                    alias = f"col_{len(expressions)}"
                expressions[alias] = col.to_sql()
            else:
                raise ValueError(f"Unsupported column type: {type(col)}")
        
        new_plan = Project(self._query_plan, expressions)
        return DataFrame(self._connection, new_plan)
    
    def selectExpr(self, *exprs) -> 'DataFrame':
        """Select with SQL expressions"""
        expressions = {}
        
        # Handle case where first argument is a list (common PySpark pattern)
        if len(exprs) == 1 and isinstance(exprs[0], list):
            exprs = exprs[0]
        
        for expr in exprs:
            # Ensure expr is a string
            expr = str(expr)
            
            # Parse expression like "column as alias" or just "column"
            if " as " in expr.lower():
                # Split on the last " as " to handle nested expressions
                parts = expr.lower().split(" as ")
                if len(parts) == 2:
                    sql_expr = expr[:expr.lower().rfind(" as ")].strip()
                    alias = expr[expr.lower().rfind(" as ") + 4:].strip()
                    expressions[alias] = sql_expr
                else:
                    # Fallback if parsing fails
                    expressions[f"col_{len(expressions)}"] = expr
            else:
                # No alias, use the expression as both key and value
                # Try to extract a reasonable column name
                clean_expr = expr.strip()
                if clean_expr.isidentifier():
                    expressions[clean_expr] = clean_expr
                else:
                    expressions[f"col_{len(expressions)}"] = expr
        
        new_plan = Project(self._query_plan, expressions)
        return DataFrame(self._connection, new_plan)
    
    def filter(self, condition: Union[str, Expression]) -> 'DataFrame':
        """Lazy filter operation"""
        if isinstance(condition, str):
            condition_sql = condition
        elif hasattr(condition, 'to_sql'):
            condition_sql = condition.to_sql()
        else:
            raise ValueError(f"Unsupported condition type: {type(condition)}")
        
        new_plan = Filter(self._query_plan, condition_sql)
        return DataFrame(self._connection, new_plan)
    
    def where(self, condition: Union[str, Expression]) -> 'DataFrame':
        """Alias for filter"""
        return self.filter(condition)
    
    def join(self, other: 'DataFrame', on: Union[str, List[str], Expression], 
             how: str = "inner") -> 'DataFrame':
        """Lazy join operation"""
        if isinstance(on, list):
            # List of column names - natural join (quote column names for consistency)
            conditions = [f'left_t."{col}" = right_t."{col}"' for col in on]
            on_condition = " AND ".join(conditions)
        elif isinstance(on, str):
            on_condition = on
        elif hasattr(on, 'to_sql'):
            on_condition = on.to_sql(preserve_qualifiers=True)
        else:
            raise ValueError(f"Unsupported join condition type: {type(on)}")
                # Map PySpark join type aliases to canonical forms
        _JOIN_TYPE_ALIASES = {
            "outer": "full_outer",
            "full": "full_outer",
        }
        how = _JOIN_TYPE_ALIASES.get(how.lower(), how)
        # Normalize join type: "full_outer" -> "FULL OUTER", "left_outer" -> "LEFT OUTER", etc.
        join_type = how.upper().replace("_", " ")
        new_plan = Join(self._query_plan, other._query_plan, on_condition, join_type)
        return DataFrame(self._connection, new_plan)
    
    def crossJoin(self, other: 'DataFrame') -> 'DataFrame':
        """Cross join with another DataFrame"""
        new_plan = Join(self._query_plan, other._query_plan, "1=1", "CROSS")
        return DataFrame(self._connection, new_plan)
    
    def groupBy(self, *cols) -> GroupedData:
        """Lazy groupBy operation"""
        group_cols = []
        group_aliases = {}  # Map of column_name -> alias
        
        for col in cols:
            if isinstance(col, str):
                group_cols.append(col)
            elif isinstance(col, Column):
                # Always use the original column name for GROUP BY
                group_cols.append(col.name)
                # But track the alias if present
                if col._alias:
                    group_aliases[col.name] = col._alias
            elif isinstance(col, Expression):
                # Handle FunctionCall and other Expression types
                # For expressions, we need to use the full expression for GROUP BY
                if hasattr(col, '_alias') and col._alias:
                    # Store the original expression for GROUP BY, and the alias for SELECT
                    group_cols.append(col)  # Keep the original expression
                    group_aliases[str(col)] = col._alias  # Map expression -> alias
                else:
                    # Use the expression as-is (will be converted to SQL)
                    group_cols.append(col)
            else:
                raise ValueError(f"Unsupported groupBy column type: {type(col)}")
        
        from .group import GroupedData
        return GroupedData(self._connection, self._query_plan, group_cols, group_aliases)
    
    def groupby(self, *cols) -> GroupedData:
        """Alias for groupBy (PySpark compatibility)"""
        return self.groupBy(*cols)
    
    def agg(self, *exprs) -> 'DataFrame':
        """Aggregate without grouping"""
        return self.groupBy().agg(*exprs)
    
    def orderBy(self, *cols, ascending: Union[bool, List[bool]] = True) -> 'DataFrame':
        """Lazy orderBy operation"""
        order_by = []
        
        # Handle ascending parameter
        if isinstance(ascending, bool):
            ascending_list = [ascending] * len(cols)
        else:
            ascending_list = ascending
        
        for i, col in enumerate(cols):
            asc = ascending_list[i] if i < len(ascending_list) else True
            
            if isinstance(col, SortExpression):
                direction = f"{col.direction} {col.nulls}" if col.nulls else col.direction
                expr_name = col.expression.name if hasattr(col.expression, 'name') else col.expression.to_sql()
                order_by.append((expr_name, direction))
            elif isinstance(col, str):
                order_by.append((col, "ASC" if asc else "DESC" ))
            elif isinstance(col, Column):
                # Check if column has explicit ordering
                if hasattr(col, '_desc') and col._desc:
                    order_by.append((col.name, "DESC"))
                elif hasattr(col, '_asc') and col._asc:
                    order_by.append((col.name, "ASC"))
                else:
                    order_by.append((col.name, "ASC" if asc else "DESC"))
            else:
                raise ValueError(f"Unsupported orderBy column type: {type(col)}")
        
        new_plan = Sort(self._query_plan, order_by)
        return DataFrame(self._connection, new_plan)
    
    def sort(self, *cols, ascending: Union[bool, List[bool]] = True) -> 'DataFrame':
        """Alias for orderBy"""
        return self.orderBy(*cols, ascending=ascending)
    
    def limit(self, n: int) -> 'DataFrame':
        """Lazy limit operation"""
        new_plan = Limit(self._query_plan, n)
        return DataFrame(self._connection, new_plan)
    
    def distinct(self) -> 'DataFrame':
        """Get distinct rows"""
        new_plan = Distinct(self._query_plan)
        return DataFrame(self._connection, new_plan)
    
    def dropDuplicates(self, subset: Optional[List[str]] = None) -> 'DataFrame':
        """Drop duplicate rows"""
        if subset:
            # Select distinct on specific columns
            # This is more complex - would need a custom query plan node
            return self.distinct()
        else:
            return self.distinct()

    drop_duplicates = dropDuplicates

    def union(self, other: 'DataFrame') -> 'DataFrame':
        """Union with another DataFrame (keeps all rows, equivalent to UNION ALL in SQL)"""
        # Note: Spark's union() does NOT remove duplicates - it keeps all rows like UNION ALL
        new_plan = Union(self._query_plan, other._query_plan, "ALL")
        return DataFrame(self._connection, new_plan)

    def unionAll(self, other: 'DataFrame') -> 'DataFrame':
        """Union all with another DataFrame (keeps all rows)"""
        new_plan = Union(self._query_plan, other._query_plan, "ALL")
        return DataFrame(self._connection, new_plan)
    
    def unionByName(self, other: 'DataFrame', allowMissingColumns: bool = False) -> 'DataFrame':
        """Union by column names"""
        if not allowMissingColumns:
            # Simple case - just regular union
            return self.union(other)
        
        # When allowMissingColumns=True, handle schema differences without conflicts
        # Use query plan get_columns() instead of .columns property to avoid triggering
        # column ambiguity fix prematurely
        try:
            # Get columns from query plans directly (avoids SQL execution)
            left_columns = self._query_plan.get_columns()
            right_columns = other._query_plan.get_columns()
            
            # Handle wildcard columns
            if left_columns == ["*"] or right_columns == ["*"]:
                # If either side has wildcard, fall back to regular union
                return self.union(other)
            
            # Convert to sets for comparison
            left_set = set(left_columns)
            right_set = set(right_columns)
            
            # If schemas are identical, check if column order matches
            if left_set == right_set:
                # Check if column order is the same
                if left_columns == right_columns:
                    logger.debug(f"DEBUG unionByName: Schemas and order identical, using regular union")
                    return self.union(other)
                else:
                    logger.debug(f"DEBUG unionByName: Schemas identical but order differs, need reordering")
                    logger.debug(f"  Left order: {left_columns}")
                    logger.debug(f"  Right order: {right_columns}")
                    # Continue to reorder columns to match
            
            # Create unified schema with all unique columns (no conflict resolution)
            all_columns = sorted(left_set.union(right_set))
            
            # Build select expressions for left DataFrame
            from .column import lit, col
            left_expressions = []
            for col_name in all_columns:
                if col_name in left_set:
                    # Use explicit aliasing to ensure column name is preserved
                    left_expressions.append(col(col_name).alias(col_name))
                else:
                    # Add NULL column with explicit alias
                    left_expressions.append(lit(None).alias(col_name))
            
            # Build select expressions for right DataFrame
            right_expressions = []
            for col_name in all_columns:
                if col_name in right_set:
                    # Use explicit aliasing to ensure column name is preserved
                    right_expressions.append(col(col_name).alias(col_name))
                else:
                    # Add NULL column with explicit alias
                    right_expressions.append(lit(None).alias(col_name))
            
            # Apply unified schema to both DataFrames and union
            left_df = self.select(*left_expressions)
            right_df = other.select(*right_expressions)
            
            # Use UNION ALL to preserve all rows when schema alignment adds NULL padding
            # Regular UNION eliminates duplicates which can cause data loss with NULL-padded rows
            return left_df.unionAll(right_df)
            
        except Exception as e:
            import traceback
            logger.exception(f'Exception while operating on unionByName {traceback.print_exc()}')
            # Fallback to regular union if schema introspection fails
            return self.union(other)
    
    def intersect(self, other: 'DataFrame') -> 'DataFrame':
        """Intersect with another DataFrame"""
        from ..core.sql_generator import SQLGenerator
        
        sql_gen = SQLGenerator()
        sql = sql_gen.build_intersect(self._query_plan.to_sql(), other._query_plan.to_sql())
        new_plan = RawSQL(sql, self._query_plan.get_columns())
        return DataFrame(self._connection, new_plan)
    
    def exceptAll(self, other: 'DataFrame') -> 'DataFrame':
        """Except all with another DataFrame"""
        from ..core.sql_generator import SQLGenerator
        
        sql_gen = SQLGenerator()
        sql = sql_gen.build_except(self._query_plan.to_sql(), other._query_plan.to_sql(), all_rows=True)
        new_plan = RawSQL(sql, self._query_plan.get_columns())
        return DataFrame(self._connection, new_plan)
    
    def subtract(self, other: 'DataFrame') -> 'DataFrame':
        """Subtract another DataFrame (EXCEPT operation)"""
        from ..core.sql_generator import SQLGenerator
        
        sql_gen = SQLGenerator()
        sql = sql_gen.build_except(self._query_plan.to_sql(), other._query_plan.to_sql(), all_rows=False)
        new_plan = RawSQL(sql, self._query_plan.get_columns())
        return DataFrame(self._connection, new_plan)
    
    def withColumn(self, colName: str, col: Union[Column, Expression]) -> 'DataFrame':
        """Add or replace a column"""
        from .column import FunctionCall, StructExpression, WindowExpression

        # e6data doesn't support IGNORE NULLS in window functions.
        # Rewrite first/last(..., ignorenulls=True).over(w) as a two-step
        # COUNT + MAX workaround using a CTE/subquery boundary.
        if isinstance(col, WindowExpression):
            func = col.function
            if isinstance(func, FunctionCall) and getattr(func, '_ignorenulls', False):
                return self._expand_ignorenulls_fill(colName, func, col.windowSpec)

        # e6data can't EXPLODE struct arrays — rewrite as UNION ALL.
        # explode(array(struct(k1,v1), struct(k2,v2))) becomes:
        #   SELECT *, k1 AS field1, v1 AS field2 FROM child
        #   UNION ALL
        #   SELECT *, k2 AS field1, v2 AS field2 FROM child
        if (isinstance(col, FunctionCall) and col.func_name.upper() == "EXPLODE"
                and col.args
                and isinstance(col.args[0], FunctionCall)
                and col.args[0].func_name.upper() == "ARRAY"):
            structs = [a for a in col.args[0].args if isinstance(a, StructExpression)]
            if structs:
                legs = []
                for struct_expr in structs:
                    leg = self
                    for field_val, field_name in struct_expr.fields:
                        leg = DataFrame(self._connection,
                                        WithColumn(leg._query_plan, field_name, field_val.to_sql()))
                    legs.append(leg)
                # Chain pairwise into Union(left, right, "ALL")
                result_plan = legs[0]._query_plan
                for leg in legs[1:]:
                    result_plan = Union(result_plan, leg._query_plan, "ALL")  # type: ignore[call-arg]
                return DataFrame(self._connection, result_plan)

        if isinstance(col, str):
            expression = col
        elif hasattr(col, 'to_sql'):
            expression = col.to_sql()
        else:
            raise ValueError(f"Unsupported column expression type: {type(col)}")

        new_plan = WithColumn(self._query_plan, colName, expression)
        return DataFrame(self._connection, new_plan)
    
    def withColumnRenamed(self, existing: str, new: str) -> 'DataFrame':
        """Rename a column"""
        # If the child is already a Project (e.g. from a previous withColumnRenamed),
        # merge the rename into it instead of wrapping with another SELECT layer.
        if isinstance(self._query_plan, Project):
            merged_expressions = {}
            found = False
            for alias, expr in self._query_plan.expressions.items():
                if alias == existing:
                    # Rename this column: keep the original expression, change the alias
                    merged_expressions[new] = expr
                    found = True
                else:
                    merged_expressions[alias] = expr

            if not found and "*" in merged_expressions:
                # Column not explicitly listed but covered by *, add as explicit rename
                merged_expressions[new] = existing

            new_plan = Project(self._query_plan.child, merged_expressions)
            return DataFrame(self._connection, new_plan)

        # Otherwise build a fresh Project
        columns = self._query_plan.get_columns()

        expressions = {}
        found = False
        for col in columns:
            if col == existing:
                expressions[new] = col
                found = True
            else:
                expressions[col] = col

        # If columns are ["*"] and the column wasn't found, still record the rename
        # alongside the wildcard so the SQL shows the rename expression
        if not found and "*" in expressions:
            expressions[new] = existing

        new_plan = Project(self._query_plan, expressions)
        return DataFrame(self._connection, new_plan)
    
    def drop(self, *cols) -> 'DataFrame':
        """Drop columns"""
        # Handle both string column names and Column objects
        # When a Column object is passed, it might have qualifier information
        # that we need to preserve to drop only specific instances
        columns_to_drop = []
        for col in cols:
            if isinstance(col, str):
                # Simple string column name - drop all instances
                columns_to_drop.append(col)
            elif isinstance(col, Column):
                # Column object - might have qualifier for specific instance
                # For now, just use the name (this is the current behavior)
                # TODO: Implement qualified column drop support
                columns_to_drop.append(col.name)
            else:
                raise ValueError(f"drop() expects column names as strings or Column objects, got {type(col)}")
        
        # For now, dropping by name drops all instances of that column
        # This is a limitation that needs to be addressed for proper join handling
        new_plan = Drop(self._query_plan, columns_to_drop)
        return DataFrame(self._connection, new_plan)
    
    def _expand_ignorenulls_fill(self, colName, func, windowSpec):
        """Expand first/last(col, ignorenulls=True).over(w) into COUNT+MAX two-step.

        e6data doesn't support IGNORE NULLS.  The workaround:
          Step 1 : COUNT(col) over an ordered window creates a group number that
                   increments only on non-null values.
          Step 2 : MAX(col) partitioned by that group returns the non-null value.

        LAST_VALUE+ignorenulls = ffill (look backward):
          grp = COUNT(col) OVER (PARTITION BY ... ORDER BY ... ROWS UNBOUNDED PRECEDING TO CURRENT ROW)
        FIRST_VALUE+ignorenulls = bfill (look forward):
          grp = COUNT(col) OVER (PARTITION BY ... ORDER BY ... ROWS CURRENT ROW TO UNBOUNDED FOLLOWING)
        """
        from .column import FunctionCall, Column
        from .window import WindowSpec

        # The source column is the first arg of the FIRST_VALUE/LAST_VALUE call
        src_col = func.args[0]
        src_sql = src_col.to_sql()

        # Build partition and order parts from the original window
        partition_parts = []
        for c in windowSpec._partition_by_cols:
            partition_parts.append(c.to_sql() if hasattr(c, 'to_sql') else str(c))

        order_parts = []
        for c in windowSpec._order_by_cols:
            order_parts.append(c.to_sql() if hasattr(c, 'to_sql') else str(c))

        is_bfill = func.func_name.upper() == "FIRST_VALUE"

        # Step 1: COUNT window to create group key
        if is_bfill:
            frame = "ROWS BETWEEN CURRENT ROW AND UNBOUNDED FOLLOWING"
        else:
            frame = "ROWS BETWEEN UNBOUNDED PRECEDING AND CURRENT ROW"

        parts = []
        if partition_parts:
            parts.append(f"PARTITION BY {', '.join(partition_parts)}")
        if order_parts:
            parts.append(f"ORDER BY {', '.join(order_parts)}")
        parts.append(frame)
        count_window = " ".join(parts)

        grp_col = f"__{colName}_grp"
        count_expr = f'COUNT({src_sql}) OVER ({count_window})'

        # Step 1 must be fully computed before Step 2 references it.
        # Use a Drop(nothing) barrier to break the consecutive WithColumn
        # chain that _collect_consecutive_with_columns would otherwise merge.
        step1_plan = WithColumn(self._query_plan, grp_col, count_expr)
        step1_plan = Drop(step1_plan, [])  # barrier — forces a subquery boundary

        # Step 2: MAX partitioned by original keys + group key
        grp_partition = partition_parts + [f'"{grp_col}"']
        max_window = f"PARTITION BY {', '.join(grp_partition)}"
        max_expr = f'MAX({src_sql}) OVER ({max_window})'
        step2 = DataFrame(self._connection,
                          WithColumn(step1_plan, colName, max_expr))

        # Drop the intermediate group column
        return step2.drop(grp_col)

    def _resolve_columns(self) -> List[str]:
        """Resolve column names when get_columns() returns ['*'].

        Uses the connection to execute a LIMIT 0 query and read column names
        from the cursor description.  Returns the resolved list or ['*'] if
        resolution is not possible (e.g. mock / offline mode).
        """
        columns = self._query_plan.get_columns()
        if columns != ["*"]:
            return columns
        if self._connection:
            try:
                resolved = self._connection.get_columns(self._query_plan.to_sql())
                if isinstance(resolved, list) and resolved:
                    return resolved
            except Exception:
                pass
        return columns                # fallback – still ["*"]

    def dropna(self, how: str = 'any', thresh: Optional[int] = None,
               subset: Optional[List[str]] = None) -> 'DataFrame':
        """Drop rows with null values"""
        # Build WHERE clause based on parameters
        if subset:
            columns = subset
        else:
            columns = self._resolve_columns()

        if thresh is not None:
            # thresh=N means keep rows with at least N non-null values.
            # Count non-nulls by subtracting the null count from the total.
            null_checks = [f"CASE WHEN {col} IS NULL THEN 1 ELSE 0 END" for col in columns]
            condition = f"({len(columns)} - ({' + '.join(null_checks)})) >= {thresh}"
        elif how == 'any':
            # Drop if any column is null
            conditions = [f"{col} IS NOT NULL" for col in columns]
            condition = " AND ".join(conditions)
        elif how == 'all':
            # Drop only if all columns are null
            conditions = [f"{col} IS NULL" for col in columns]
            condition = f"NOT ({' AND '.join(conditions)})"
        else:
            raise ValueError(f"how must be 'any' or 'all', got {how}")
        
        return self.filter(condition)
    
    def fillna(self, value: Any, subset: Optional= None) -> 'DataFrame':
        """Fill null values"""
        # Resolve columns via the connection when the child returns ["*"]
        resolved = None
        child_cols = self._query_plan.get_columns()
        if child_cols == ["*"] and self._connection:
            try:
                resolved = self._connection.get_columns(self._query_plan.to_sql())
            except Exception:
                pass
        new_plan = CoalesceSQL(self._query_plan, value, subset, resolved_columns=resolved)
        return DataFrame(self._connection, new_plan)
    
    def cache(self) -> 'DataFrame':
        """Mark DataFrame for caching"""
        self._is_cached = True
        return self
    
    def persist(self, storageLevel: Optional[Any] = None) -> 'DataFrame':
        """Persist DataFrame with specified storage level"""
        return self.cache()
    
    def unpersist(self, blocking: bool = False) -> 'DataFrame':
        """Remove cached data"""
        self._cached_result = None
        self._is_cached = False
        return self
    
    def repartition(self, numPartitions: Union[int, str], *cols) -> 'DataFrame':
        """Repartition DataFrame"""
        # E6Data handles partitioning internally
        return self
    
    def coalesce(self, numPartitions: int) -> 'DataFrame':
        """Coalesce partitions"""
        from ..core.query_plan import Coalesce
        return DataFrame(self._connection, Coalesce(self._query_plan, numPartitions))
    
    def hint(self, name: str, *parameters) -> 'DataFrame':
        """Add optimization hint to DataFrame"""
        # For now, we can use hints to control optimization
        if name == "no_optimize":
            # This would be used to disable optimization for specific queries
            # Implementation would require adding hint support to query plan
            pass
        return self
    
    # Actions (trigger execution)
    def collect(self) -> List[Any]:
        """Action: Execute query and collect all results"""
        import time
        from ..core.logging_config import sql_fingerprint
        qid = generate_query_id()
        caller = get_caller_info()

        if self._cached_result is not None:
            logger.info(log_box("QUERY CACHED",
                                query_fired=qid, op="collect", caller=caller))
            return self._cached_result

        try:
            # Generate SQL from query plan using CTEs
            from ..core.query_plan import generate_sql_with_cte
            from ..core.sql_generator import get_use_cte
            sql = generate_sql_with_cte(self._query_plan, use_cte=get_use_cte())

            # Optionally optimize the final SQL
            from ..core.sql_generator import SQLGenerator
            sql_gen = SQLGenerator()
            optimized_sql = sql_gen.optimize_final_query(sql, action="collect")

            preview = optimized_sql[:200].replace('\n', ' ').strip() + ('...' if len(optimized_sql) > 200 else '')
            fingerprint = sql_fingerprint(optimized_sql)
            logger.info(log_box("QUERY START",
                                query_fired=qid, op="collect", caller=caller,
                                sql_hash=fingerprint))
            sql_logger.info(f"SQL:\n{format_sql(optimized_sql)}")

            # Execute the optimized SQL
            t0 = time.perf_counter()
            cursor = self._connection.cursor()
            try:
                cursor.execute(optimized_sql)
                columns = [desc[0] for desc in cursor.description] if cursor.description else []
                results = cursor.fetchall()
                from ..core.connection import E6DataConnection
                results = E6DataConnection._convert_types(cursor.description, results)

                from .row import Row
                results = [Row(columns, row) for row in results]
            finally:
                cursor.clear()
                cursor.close()

            duration_ms = int((time.perf_counter() - t0) * 1000)

            if self._is_cached:
                self._cached_result = results

            logger.info(log_box("QUERY END",
                                query_fired=qid, op="collect", caller=caller,
                                status="ok", duration_ms=duration_ms,
                                row_count=len(results)))
            return results

        except Exception as e:
            logger.error(log_box("QUERY ERROR",
                                 query_fired=qid, op="collect", caller=caller,
                                 status="error", error=str(e)))
            raise
    
    def show(self, n: int = 20, truncate: Union[bool, int] = True,
             vertical: bool = False) -> None:
        """Action: Show first n rows"""
        import time
        from ..core.logging_config import sql_fingerprint
        qid = generate_query_id()
        caller = get_caller_info()

        try:
            # Add limit to query plan for efficiency
            limited_plan = Limit(self._query_plan, n)

            # Generate SQL using CTEs
            from ..core.query_plan import generate_sql_with_cte
            from ..core.sql_generator import get_use_cte
            sql = generate_sql_with_cte(limited_plan, use_cte=get_use_cte())

            # Optionally optimize the final SQL
            from ..core.sql_generator import SQLGenerator
            sql_gen = SQLGenerator()
            optimized_sql = sql_gen.optimize_final_query(sql, action="show")

            preview = optimized_sql[:200].replace('\n', ' ').strip() + ('...' if len(optimized_sql) > 200 else '')
            fingerprint = sql_fingerprint(optimized_sql)
            logger.info(log_box("QUERY START",
                                query_fired=qid, op="show", caller=caller,
                                sql_hash=fingerprint))
            sql_logger.info(f"SQL:\n{format_sql(optimized_sql)}")

            t0 = time.perf_counter()
            cursor = self._connection.cursor()
            try:
                cursor.execute(optimized_sql)

                # Get column names
                columns = [desc[0] for desc in cursor.description]

                # Fetch results
                results = cursor.fetchmany(n)

                duration_ms = int((time.perf_counter() - t0) * 1000)

                # Build the output as a string first
                output_lines = []

                if vertical:
                    # Vertical format
                    for i, row in enumerate(results):
                        output_lines.append(f"-RECORD {i}")
                        for col, val in zip(columns, row):
                            output_lines.append(f" {col} | {val}")
                else:
                    # Table format
                    border = "+" + "-" * 20 * len(columns) + "+"
                    header = "|" + " | ".join(f"{col:^18}" for col in columns) + "|"

                    output_lines.append(border)
                    output_lines.append(header)
                    output_lines.append(border)

                    for row in results:
                        formatted_row = []
                        for val in row:
                            # if isinstance(val, str) and truncate and len(val) > truncate:
                            #     val = val[:truncate-3] + "..."
                            formatted_row.append(f"{str(val):^18}")
                        output_lines.append("|" + " | ".join(formatted_row) + "|")

                    output_lines.append(border)
                    output_lines.append(f"only showing top {n} rows")

                # Print all at once to console (show() should display to user)
                print(colorize_show("\n".join(output_lines)))
                logger.info(log_box("QUERY END",
                                    query_fired=qid, op="show", caller=caller,
                                    status="ok", duration_ms=duration_ms,
                                    row_count=len(results)))

            finally:
                cursor.clear()
                cursor.close()

        except Exception as e:
            logger.error(log_box("QUERY ERROR",
                                 query_fired=qid, op="show", caller=caller,
                                 status="error", error=str(e)))
            raise

    def display(self, n: int = 20, truncate: bool = True):
        """Databricks-style display method. Alias for show()."""
        return self.show(n=n, truncate=truncate)

    def count(self) -> int:
        """Action: Count rows"""
        qid = generate_query_id()
        caller = get_caller_info()

        try:
            from ..core.sql_generator import SQLGenerator, get_use_cte
            from ..core.query_plan import generate_sql_with_cte

            base_sql = generate_sql_with_cte(self._query_plan, use_cte=get_use_cte())

            # Apply fixes to base SQL before wrapping in COUNT
            sql_gen = SQLGenerator()
            base_sql = sql_gen._fix_column_ambiguity(base_sql)

            count_sql = sql_gen.build_count_query(base_sql)

            results = self._connection.execute(count_sql, query_id=qid, op="count", caller=caller)
            return results[0][0]

        except Exception as e:
            logger.error(log_box("QUERY ERROR",
                                 query_fired=qid, op="count", caller=caller,
                                 status="error", error=str(e)))
            raise

    def isEmpty(self) -> bool:
        """Returns True if the DataFrame is empty, False otherwise"""
        try:
            rows = self.head(1)
            is_empty = len(rows) == 0
            return is_empty
        except Exception as e:
            logger.error(f"DataFrame.isEmpty() failed: {e}")
            raise

    def first(self) -> Optional[Any]:
        """Action: Get first row"""
        rows = self.head(1)
        return rows[0] if rows else None
    
    def head(self, n: int = 1) -> List[Any]:
        """Action: Get first n rows"""
        import time
        from ..core.logging_config import sql_fingerprint
        qid = generate_query_id()
        caller = get_caller_info()

        try:
            limited_plan = Limit(self._query_plan, n)

            # Generate SQL using CTEs
            from ..core.query_plan import generate_sql_with_cte
            from ..core.sql_generator import get_use_cte
            sql = generate_sql_with_cte(limited_plan, use_cte=get_use_cte())

            # Optionally optimize the final SQL
            from ..core.sql_generator import SQLGenerator
            sql_gen = SQLGenerator()
            optimized_sql = sql_gen.optimize_final_query(sql, action="head")

            preview = optimized_sql[:200].replace('\n', ' ').strip() + ('...' if len(optimized_sql) > 200 else '')
            fingerprint = sql_fingerprint(optimized_sql)
            logger.info(log_box("QUERY START",
                                query_fired=qid, op="head", caller=caller,
                                sql_hash=fingerprint))
            sql_logger.info(f"SQL:\n{format_sql(optimized_sql)}")

            t0 = time.perf_counter()
            cursor = self._connection.cursor()
            try:
                cursor.execute(optimized_sql)
                columns = [desc[0] for desc in cursor.description] if cursor.description else []
                results = cursor.fetchall()
                from ..core.connection import E6DataConnection
                results = E6DataConnection._convert_types(cursor.description, results)
                result = results[:n]

                from .row import Row
                result = [Row(columns, row) for row in result]

                duration_ms = int((time.perf_counter() - t0) * 1000)
                logger.info(log_box("QUERY END",
                                    query_fired=qid, op="head", caller=caller,
                                    status="ok", duration_ms=duration_ms,
                                    row_count=len(result)))
                return result
            finally:
                cursor.clear()
                cursor.close()

        except Exception as e:
            logger.error(log_box("QUERY ERROR",
                                 query_fired=qid, op="head", caller=caller,
                                 status="error", error=str(e)))
            raise
    
    def take(self, n: int) -> List[Any]:
        """Action: Take first n rows"""
        return self.head(n)
    
    def tail(self, n: int = 1) -> List[Any]:
        """Action: Get last n rows"""
        # This is complex without window functions
        # For now, just return head
        return self.head(n)
    
    def toPandas(self) -> pd.DataFrame:
        """Action: Convert to Pandas DataFrame"""
        import time
        from ..core.logging_config import sql_fingerprint
        qid = generate_query_id()
        caller = get_caller_info()

        try:
            # Generate SQL using CTEs
            from ..core.query_plan import generate_sql_with_cte
            from ..core.sql_generator import get_use_cte
            sql = generate_sql_with_cte(self._query_plan, use_cte=get_use_cte())

            # Optionally optimize the final SQL
            from ..core.sql_generator import SQLGenerator
            sql_gen = SQLGenerator()
            optimized_sql = sql_gen.optimize_final_query(sql, action="toPandas")

            preview = optimized_sql[:200].replace('\n', ' ').strip() + ('...' if len(optimized_sql) > 200 else '')
            fingerprint = sql_fingerprint(optimized_sql)
            logger.info(log_box("QUERY START",
                                query_fired=qid, op="toPandas", caller=caller,
                                sql_hash=fingerprint))
            sql_logger.info(f"SQL:\n{format_sql(optimized_sql)}")

            t0 = time.perf_counter()
            cursor = self._connection.cursor()
            try:
                cursor.execute(optimized_sql)

                # Get column names
                columns = [desc[0] for desc in cursor.description]

                # Fetch all results
                results = cursor.fetchall()

                pandas_df = pd.DataFrame(results, columns=columns)
                duration_ms = int((time.perf_counter() - t0) * 1000)
                logger.info(log_box("QUERY END",
                                    query_fired=qid, op="toPandas", caller=caller,
                                    status="ok", duration_ms=duration_ms,
                                    row_count=len(results)))
                return pandas_df

            finally:
                cursor.clear()
                cursor.close()

        except Exception as e:
            logger.error(log_box("QUERY ERROR",
                                 query_fired=qid, op="toPandas", caller=caller,
                                 status="error", error=str(e)))
            raise
    
    def explain(self, extended: bool = False, mode: Optional[str] = None) -> None:
        """Action: Explain query plan"""
        sql = self._query_plan.to_sql()
        
        # Optionally optimize the final SQL for explain
        from ..core.sql_generator import SQLGenerator
        sql_gen = SQLGenerator()
        optimized_sql = sql_gen.optimize_final_query(sql, action="explain")
        
        if mode == "simple":
            print("== Physical Plan ==")
            print(optimized_sql)
        elif mode == "extended" or extended:
            explain_sql = f"EXPLAIN ANALYZE {optimized_sql}"
            results = self._connection.execute(explain_sql)
            print("== Parsed Logical Plan ==")
            for row in results:
                print(row[0])
        else:
            explain_sql = f"EXPLAIN {optimized_sql}"
            results = self._connection.execute(explain_sql)
            print("== Physical Plan ==")
            for row in results:
                print(row[0])
    
    def createOrReplaceTempView(self, name: str) -> None:
        """Action: Create temporary view"""
        sql = self._query_plan.to_sql()
        
        # Register with the session
        if hasattr(self._connection, '_session'):
            self._connection._session._register_temp_view(name, sql)
        
        # Also try to create in database if supported
        try:
            create_view_sql = f"CREATE OR REPLACE TEMPORARY VIEW {name} AS {sql}"
            self._connection.execute(create_view_sql)
        except:
            # If database doesn't support temp views, that's okay
            # We already registered it in the session
            pass
    
    def createTempView(self, name: str) -> None:
        """Create temporary view (error if exists)"""
        self.createOrReplaceTempView(name)
    
    def createGlobalTempView(self, name: str) -> None:
        """Create global temporary view"""
        self.createOrReplaceTempView(f"global_temp.{name}")
    
    def createOrReplaceGlobalTempView(self, name: str) -> None:
        """Create or replace global temporary view"""
        self.createOrReplaceTempView(f"global_temp.{name}")
    
    def __getitem__(self, item):
        """Support DataFrame['column'] and DataFrame['*'] syntax"""
        if item == "*":
            # Return all columns from this DataFrame
            # This is used in patterns like: df1.select(df2["*"], "other_col")
            # We need a special marker that indicates "all columns from a specific DataFrame"
            from .column import DataFrameStarExpression
            return DataFrameStarExpression(self)
        else:
            # Return a Column object for a specific column
            return Column(item)
    
    @property
    def write(self) -> DataFrameWriter:
        """Get DataFrameWriter for output operations"""
        return DataFrameWriter(self._connection, self._query_plan)
    
    @property
    def schema(self) -> Any:
        """Get schema of the DataFrame"""
        # This would need proper implementation
        return None
    
    @property
    def columns(self) -> List[str]:
        """Get column names"""
        # Return cached columns if available
        if self._cached_columns is not None:
            return self._cached_columns
            
        columns = self._query_plan.get_columns()
        
        # Handle the case where get_columns() returns ["*"]
        # This happens with ReadOperation and causes issues with selectExpr aliasing
        if columns == ["*"]:
            # First, try to get columns from schema cache
            schema_cache = SchemaCache()
            
            # Helper function to check query plan recursively
            def check_plan_for_schema(plan):
                # Check if this is a ReadOperation (direct file read)
                if isinstance(plan, ReadOperation) and hasattr(plan, 'path'):
                    logger.debug(f"SCHEMA LOOKUP: Found ReadOperation, checking cache for path: {plan.path}")
                    cached_columns = schema_cache.get_columns_from_path(plan.path)
                    if cached_columns:
                        logger.debug(f"SCHEMA CACHE HIT: Using cached schema for path: {plan.path}")
                        return cached_columns
                    else:
                        logger.debug(f"SCHEMA CACHE MISS: No cached schema for path: {plan.path}")
                
                # Check if this is a TableScan with a table name
                elif isinstance(plan, TableScan) and hasattr(plan, 'table_name'):
                    logger.debug(f"🔍 SCHEMA LOOKUP: Checking cache for table: {plan.table_name}")
                    cached_columns = schema_cache.get_columns_for_table(plan.table_name)
                    if cached_columns:
                        logger.info(f"SCHEMA CACHE HIT: Using cached schema for table: {plan.table_name}")
                        logger.info(f"AVOIDED SQL EXECUTION: Found {len(cached_columns)} columns in cache")
                        return cached_columns
                    else:
                        logger.debug(f"❌ SCHEMA CACHE MISS: No cached schema for table: {plan.table_name}")
                
                # Recursively check child plans
                if hasattr(plan, 'child') and plan.child:
                    return check_plan_for_schema(plan.child)
                elif hasattr(plan, 'left') and plan.left:
                    # For joins, check left side first
                    result = check_plan_for_schema(plan.left)
                    if result:
                        return result
                    
                return None
            
            # Try to find schema from the query plan hierarchy
            cached_columns = check_plan_for_schema(self._query_plan)
            if cached_columns:
                self._cached_columns = cached_columns
                return cached_columns
            
            # If no cache hit, fall back to executing LIMIT 0 query
            # logger.warning(f"⚠️ SCHEMA CACHE MISS: Falling back to SQL execution (LIMIT 0 query)")
            try:
                # Try to get actual column names by executing a LIMIT 0 query
                sql = f"SELECT * FROM ({self._query_plan.to_sql()}) AS schema_check LIMIT 0"
                logger.debug(f"EXECUTING SQL: {sql[:100]}...")
                cursor = self._connection.cursor()
                cursor.execute(sql)
                
                # Get column names from cursor description
                if cursor.description:
                    actual_columns = [desc[0] for desc in cursor.description]
                    cursor.clear()
                    cursor.close()
                    logger.info(f"SQL EXECUTED: Retrieved {len(actual_columns)} columns from database")
                    # Cache the result
                    self._cached_columns = actual_columns
                    return actual_columns
                    
                cursor.clear()
                cursor.close()
            except Exception:
                # If we can't determine actual columns, return an empty list
                # This will cause selectExpr operations to fail more gracefully
                # rather than generating invalid SQL like "SELECT * AS \"*_gt\""
                pass
        
        # Cache the result
        self._cached_columns = columns        
        return columns
    
    @property
    def dtypes(self) -> List[Tuple[str, str]]:
        """Get column names and types"""
        # Execute a LIMIT 0 query to get schema
        sql = f"SELECT * FROM ({self._query_plan.to_sql()}) AS t LIMIT 0"
        cursor = self._connection.cursor()
        try:
            cursor.execute(sql)
            return [(desc[0], desc[1]) for desc in cursor.description]
        finally:
            cursor.clear()
            cursor.close()
    
    def printSchema(self) -> None:
        """Print the schema in tree format"""
        print("root")
        for col_name, col_type in self.dtypes:
            print(f" |-- {col_name}: {col_type}")
    
    def describe(self, *cols) -> 'DataFrame':
        """Compute basic statistics"""
        from ..core.sql_generator import SQLGenerator
        
        if not cols:
            cols = self.columns
        
        sql_gen = SQLGenerator()
        stats_sql = sql_gen.build_describe_query(self._query_plan.to_sql(), list(cols))
        plan = RawSQL(stats_sql)
        return DataFrame(self._connection, plan)
    
    def summary(self, *statistics) -> 'DataFrame':
        """Compute specified statistics"""
        # Similar to describe but with custom statistics
        return self.describe()
    
    # Aliases
    def toDF(self, *cols) -> 'DataFrame':
        """Returns a new DataFrame with renamed columns"""
        if cols:
            current_cols = self.columns
            if len(cols) != len(current_cols):
                raise ValueError(f"Number of columns mismatch: {len(current_cols)} vs {len(cols)}")
            
            expressions = {}
            for old, new in zip(current_cols, cols):
                expressions[new] = old
            
            new_plan = Project(self._query_plan, expressions)
            return DataFrame(self._connection, new_plan)
        return self
    
    def alias(self, alias: str) -> 'DataFrame':
        """Returns a new DataFrame with an alias set"""
        # This is mainly for joins
        from ..core.query_plan import Alias
        return DataFrame(self._connection, Alias(self._query_plan, alias))
    
    @property
    def na(self):
        """Returns a DataFrameNaFunctions for handling missing values"""
        return DataFrameNaFunctions(self)

    @property
    def stat(self):
        """Returns a DataFrameStatFunctions for statistical functions"""
        return DataFrameStatFunctions(self)
    
    def add_suffix_to_all_columns(self, suffix: str) -> 'DataFrame':
        """
        Add suffix to all columns without requiring schema discovery.
        
        This method provides lazy evaluation by deferring column aliasing until
        SQL generation time, avoiding the need to execute queries for schema discovery.
        
        Args:
            suffix: The suffix to add to all column names (e.g., "_gt", "_m")
            
        Returns:
            New DataFrame with all columns aliased with the suffix
        """
        from ..core.query_plan import BulkColumnAlias
        new_plan = BulkColumnAlias(self._query_plan, suffix)
        return DataFrame(self._connection, new_plan)


class DataFrameNaFunctions:
    """Functions for handling missing data"""
    
    def __init__(self, df: DataFrame):
        self._df = df
    
    def drop(self, how: str = 'any', thresh: Optional[int] = None,
             subset: Optional[List[str]] = None) -> DataFrame:
        """Drop rows with null values"""
        return self._df.dropna(how, thresh, subset)
    
    def fill(self, value: Any, subset: Optional[List[str]] = None) -> DataFrame:
        """Fill null values"""
        return self._df.fillna(value, subset)
    
    def replace(self, to_replace, value, subset: Optional[List[str]] = None) -> DataFrame:
        """Replace values"""
        # Would need implementation
        return self._df


class DataFrameStatFunctions:
    """Functions for statistics"""
    
    def __init__(self, df: DataFrame):
        self._df = df
    
    def corr(self, col1: str, col2: str) -> float:
        """Calculate correlation between two columns"""
        from ..core.sql_generator import SQLGenerator
        
        sql_gen = SQLGenerator()
        sql = sql_gen.build_statistical_query(self._df._query_plan.to_sql(), "CORR", col1, col2)
        results = self._df._connection.execute(sql)
        return results[0][0] if results else None
    
    def cov(self, col1: str, col2: str) -> float:
        """Calculate covariance between two columns"""
        from ..core.sql_generator import SQLGenerator
        
        sql_gen = SQLGenerator()
        sql = sql_gen.build_statistical_query(self._df._query_plan.to_sql(), "COVAR_POP", col1, col2)
        results = self._df._connection.execute(sql)
        return results[0][0] if results else None
    
    def crosstab(self, col1: str, col2: str) -> DataFrame:
        """Compute cross tabulation"""
        # Would need pivot implementation
        return self._df