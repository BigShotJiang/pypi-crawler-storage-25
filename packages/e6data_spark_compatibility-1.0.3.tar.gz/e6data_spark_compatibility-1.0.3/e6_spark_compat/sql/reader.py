"""
DataFrameReader for input operations
"""
from typing import Optional, Dict, Any, List, Union
from ..core.query_plan import TableScan, RawSQL
from .dataframe import DataFrame
from .types import StructType


class DataFrameReader:
    """Reads data from various sources into DataFrames"""
    
    def __init__(self, spark_session):
        self._spark = spark_session
        self._format = None
        self._schema = None
        self._options = {}
    
    def format(self, source: str) -> 'DataFrameReader':
        """Set the input format"""
        self._format = source.lower()
        return self
    
    def schema(self, schema: Union[StructType, str]) -> 'DataFrameReader':
        """Set the schema"""
        self._schema = schema
        return self
    
    def option(self, key: str, value: Any) -> 'DataFrameReader':
        """Set a single option"""
        self._options[key] = value
        return self
    
    def options(self, **options) -> 'DataFrameReader':
        """Set multiple options"""
        self._options.update(options)
        return self
    
    def load(self, path: str = None, format: str = None, schema: StructType = None,
             **options) -> DataFrame:
        """Load data from the specified path"""
        if format:
            self._format = format
        if schema:
            self._schema = schema
        if options:
            self._options.update(options)
        
        if not self._format:
            # Try to infer format from path
            if path:
                if path.endswith('.parquet'):
                    self._format = 'parquet'
                elif path.endswith('.orc'):
                    self._format = 'orc'
                elif path.endswith('.csv'):
                    self._format = 'csv'
                elif path.endswith('.json') or path.endswith('.jsonl'):
                    self._format = 'json'
                else:
                    self._format = 'parquet'  # Default
        
        # Build the read query based on format
        if self._format == 'parquet':
            return self._read_parquet(path)
        elif self._format == 'geoparquet':
            return self._read_geoparquet(path)
        elif self._format == 'orc':
            return self._read_orc(path)
        elif self._format == 'csv':
            return self._read_csv(path)
        elif self._format == 'json':
            return self._read_json(path)
        elif self._format == 'geojson':
            return self._read_geojson(path)
        elif self._format == 'text':
            return self._read_text(path)
        elif self._format == 'jdbc':
            return self._read_jdbc()
        elif self._format == 'delta':
            return self._read_delta(path)
        else:
            raise ValueError(f"Unsupported format: {self._format}")
    
    def table(self, tableName: str) -> DataFrame:
        """Read a table as DataFrame"""
        plan = TableScan(tableName)
        return DataFrame(self._spark._connection, plan)
    
    # Format-specific convenience methods
    def parquet(self, *paths: str) -> DataFrame:
        """Read Parquet files"""
        self._format = 'parquet'
        if len(paths) == 1:
            return self.load(paths[0])
        else:
            # Multiple paths - union them
            dfs = [self.load(path) for path in paths]
            result = dfs[0]
            for df in dfs[1:]:
                result = result.union(df)
            return result
    
    def orc(self, *paths: str) -> DataFrame:
        """Read ORC files"""
        self._format = 'orc'
        if len(paths) == 1:
            return self.load(paths[0])
        else:
            dfs = [self.load(path) for path in paths]
            result = dfs[0]
            for df in dfs[1:]:
                result = result.union(df)
            return result
    
    def csv(self, *paths: str, sep: str = None, encoding: str = None, quote: str = None,
            escape: str = None, comment: str = None, header: bool = None, inferSchema: bool = None,
            ignoreLeadingWhiteSpace: bool = None, ignoreTrailingWhiteSpace: bool = None,
            nullValue: str = None, nanValue: str = None, positiveInf: str = None,
            negativeInf: str = None, dateFormat: str = None, timestampFormat: str = None,
            maxColumns: int = None, maxCharsPerColumn: int = None, mode: str = None,
            columnNameOfCorruptRecord: str = None, multiLine: bool = None) -> DataFrame:
        """Read CSV files"""
        self._format = 'csv'
        
        # Set CSV-specific options
        if sep is not None:
            self.option("sep", sep)
        if encoding is not None:
            self.option("encoding", encoding)
        if quote is not None:
            self.option("quote", quote)
        if escape is not None:
            self.option("escape", escape)
        if comment is not None:
            self.option("comment", comment)
        if header is not None:
            self.option("header", str(header).lower())
        if inferSchema is not None:
            self.option("inferSchema", str(inferSchema).lower())
        if nullValue is not None:
            self.option("nullValue", nullValue)
        if dateFormat is not None:
            self.option("dateFormat", dateFormat)
        if timestampFormat is not None:
            self.option("timestampFormat", timestampFormat)
        if multiLine is not None:
            self.option("multiLine", str(multiLine).lower())
        
        if len(paths) == 1:
            return self.load(paths[0])
        else:
            dfs = [self.load(path) for path in paths]
            result = dfs[0]
            for df in dfs[1:]:
                result = result.union(df)
            return result
    
    def json(self, *paths: str, schema: StructType = None, primitivesAsString: bool = None,
             prefersDecimal: bool = None, allowComments: bool = None, allowUnquotedFieldNames: bool = None,
             allowSingleQuotes: bool = None, allowNumericLeadingZero: bool = None,
             allowBackslashEscapingAnyCharacter: bool = None, mode: str = None,
             columnNameOfCorruptRecord: str = None, dateFormat: str = None,
             timestampFormat: str = None, multiLine: bool = None) -> DataFrame:
        """Read JSON files"""
        self._format = 'json'
        
        if schema is not None:
            self.schema(schema)
        if multiLine is not None:
            self.option("multiLine", str(multiLine).lower())
        if dateFormat is not None:
            self.option("dateFormat", dateFormat)
        if timestampFormat is not None:
            self.option("timestampFormat", timestampFormat)
        if mode is not None:
            self.option("mode", mode)
        
        if len(paths) == 1:
            return self.load(paths[0])
        else:
            dfs = [self.load(path) for path in paths]
            result = dfs[0]
            for df in dfs[1:]:
                result = result.union(df)
            return result
    
    def text(self, *paths: str, wholetext: bool = False) -> DataFrame:
        """Read text files"""
        self._format = 'text'
        
        if wholetext:
            self.option("wholetext", "true")
        
        if len(paths) == 1:
            return self.load(paths[0])
        else:
            dfs = [self.load(path) for path in paths]
            result = dfs[0]
            for df in dfs[1:]:
                result = result.union(df)
            return result
    
    def jdbc(self, url: str, table: str, column: str = None, lowerBound: int = None,
             upperBound: int = None, numPartitions: int = None, predicates: List[str] = None,
             properties: Dict[str, str] = None) -> DataFrame:
        """Read from JDBC source"""
        self._format = 'jdbc'
        self.option("url", url)
        self.option("dbtable", table)
        
        if properties:
            self.options(**properties)
        
        return self.load()
    
    def delta(self, path: str) -> DataFrame:
        """Read Delta Lake table"""
        self._format = 'delta'
        return self.load(path)
    
    # Private methods for building read queries
    def _read_parquet(self, path: str) -> DataFrame:
        """Read Parquet files using e6data syntax"""
        # Create a temporary external table or use direct read
        table_name = f"_parquet_{hash(path)}"
        
        # Try direct read_file function with PARQUET type
        try:
            sql = f"SELECT * FROM parquet.'{path}'"
            plan = RawSQL(sql)
            return DataFrame(self._spark._connection, plan)
        except:
            # Fallback to external table - create lazily using CTE
            create_sql = f"""
            CREATE EXTERNAL TABLE IF NOT EXISTS {table_name}
            STORED AS PARQUET
            LOCATION '{path}'
            """
            
            # Create a lazy plan that will execute the CREATE statement when needed
            combined_sql = f"""
            {create_sql};
            SELECT * FROM {table_name}
            """
            plan = RawSQL(combined_sql)
            return DataFrame(self._spark._connection, plan)
    
    def _read_geoparquet(self, path: str) -> DataFrame:
        """Read GeoParquet files"""
        # Similar to Parquet but with spatial support
        try:
            sql = f"SELECT * FROM read_geoparquet('{path}')"
            plan = RawSQL(sql)
            return DataFrame(self._spark._connection, plan)
        except:
            # Fallback to regular parquet
            return self._read_parquet(path)
    
    def _read_orc(self, path: str) -> DataFrame:
        """Read ORC files"""
        table_name = f"_orc_{hash(path)}"
        
        try:
            sql = f"SELECT * FROM READ_FILE('{path}', 'ORC')"
            plan = RawSQL(sql)
            return DataFrame(self._spark._connection, plan)
        except:
            create_sql = f"""
            CREATE EXTERNAL TABLE IF NOT EXISTS {table_name}
            STORED AS ORC
            LOCATION '{path}'
            """
            
            # Create a lazy plan that will execute the CREATE statement when needed
            combined_sql = f"""
            {create_sql};
            SELECT * FROM {table_name}
            """
            plan = RawSQL(combined_sql)
            return DataFrame(self._spark._connection, plan)
    
    def _read_csv(self, path: str) -> DataFrame:
        """Read CSV files using csv.'path' syntax"""
        sql = f"SELECT * FROM csv.'{path}'"
        plan = RawSQL(sql)
        return DataFrame(self._spark._connection, plan)
    
    def _read_json(self, path: str) -> DataFrame:
        """Read JSON files"""
        multiline = self._options.get('multiLine', 'false')
        
        try:
            sql = f"SELECT * FROM read_json('{path}', multiline={multiline})"
            plan = RawSQL(sql)
            return DataFrame(self._spark._connection, plan)
        except:
            # Fallback
            table_name = f"_json_{hash(path)}"
            create_sql = f"""
            CREATE EXTERNAL TABLE IF NOT EXISTS {table_name}
            STORED AS JSON
            LOCATION '{path}'
            """
            
            # Create a lazy plan that will execute the CREATE statement when needed
            combined_sql = f"""
            {create_sql};
            SELECT * FROM {table_name}
            """
            plan = RawSQL(combined_sql)
            return DataFrame(self._spark._connection, plan)
    
    def _read_geojson(self, path: str) -> DataFrame:
        """Read GeoJSON files"""
        multiline = self._options.get('multiLine', 'true')
        
        try:
            sql = f"SELECT * FROM read_geojson('{path}', multiline={multiline})"
            plan = RawSQL(sql)
            return DataFrame(self._spark._connection, plan)
        except:
            # Try as regular JSON
            return self._read_json(path)
    
    def _read_text(self, path: str) -> DataFrame:
        """Read text files"""
        try:
            sql = f"SELECT * FROM read_text('{path}')"
            plan = RawSQL(sql)
            return DataFrame(self._spark._connection, plan)
        except:
            # Create line-based reader
            return self._read_csv(path)
    
    def _read_jdbc(self) -> DataFrame:
        """Read from JDBC source"""
        url = self._options.get('url')
        table = self._options.get('dbtable')
        
        if not url or not table:
            raise ValueError("JDBC read requires 'url' and 'dbtable' options")
        
        # This would need proper JDBC support in e6data
        sql = f"SELECT * FROM jdbc('{url}', '{table}')"
        plan = RawSQL(sql)
        return DataFrame(self._spark._connection, plan)
    
    def _read_delta(self, path: str) -> DataFrame:
        """Read Delta Lake tables"""
        # For Delta format, in e6data we can treat it as reading a table name
        # since the path typically represents a Delta table identifier
        
        # If path looks like a table name (no filesystem path), treat it as table scan
        if not ('/' in path or '\\' in path or path.startswith('s3://') or path.startswith('hdfs://')):
            # Treat as table name
            plan = TableScan(path)
            return DataFrame(self._spark._connection, plan)
        else:
            # Try to read as Delta directory - fallback to Parquet for now
            # In a full implementation, this would parse Delta log files
            try:
                # Try e6data Delta function if available
                sql = f"SELECT * FROM delta.'{path}'"
                plan = RawSQL(sql)
                return DataFrame(self._spark._connection, plan)
            except:
                # Fallback to reading as Parquet (Delta tables store data as Parquet)
                return self._read_parquet(path)