"""
PySpark-compatible SQL functions
"""
from typing import Union, List, Any, Optional
from .column import Column, Expression, FunctionCall, CaseExpression, StructExpression, UDFWrapper, lit, col
from .types import (
    DataType, ArrayType, FloatType, StringType, IntegerType, LongType,
    DoubleType, BooleanType, ShortType, ByteType, DateType, TimestampType,
    DecimalType, BinaryType, NullType, MapType, StructType, StructField,
)
import re


# Date format mappings from Spark/Java to e6/Python strftime format
# Focus on the main mappings requested by user
DATE_FORMAT_MAPPINGS = {
    'yyyy': '%Y',   # 4-digit year
    'MM': '%m',     # Month as zero-padded decimal (01-12)
    'dd': '%d',     # Day of month as zero-padded decimal
    'HH': '%H',     # Hour (00-23)
    'mm': '%M',     # Minute as zero-padded decimal
    'ss': '%S',     # Second as zero-padded decimal
}


def _convert_date_format(spark_format: str) -> str:
    """Convert Spark/Java date format to e6/Python strftime format"""
    # We need to be careful about replacement order to avoid conflicts
    # For example, 'MM' should be replaced before 'M'
    # Use a placeholder approach to avoid double-replacements
    
    result = spark_format
    replacements = []
    
    # Sort patterns by length (descending) to match longer patterns first
    patterns = sorted(DATE_FORMAT_MAPPINGS.keys(), key=len, reverse=True)
    
    # First pass: replace with placeholders
    for i, pattern in enumerate(patterns):
        placeholder = f"__PLACEHOLDER_{i}__"
        if pattern in result:
            result = result.replace(pattern, placeholder)
            replacements.append((placeholder, DATE_FORMAT_MAPPINGS[pattern]))
    
    # Second pass: replace placeholders with actual values
    for placeholder, replacement in replacements:
        result = result.replace(placeholder, replacement)
    
    return result


# String Functions
def upper(col: Union[Column, str]) -> FunctionCall:
    """Convert string to uppercase"""
    c = _ensure_column(col)
    return FunctionCall("UPPER", c)


def lower(col: Union[Column, str]) -> FunctionCall:
    """Convert string to lowercase"""
    c = _ensure_column(col)
    return FunctionCall("LOWER", c)


def trim(col: Union[Column, str]) -> FunctionCall:
    """Trim whitespace from both ends"""
    c = _ensure_column(col)
    return FunctionCall("TRIM", c)


def ltrim(col: Union[Column, str]) -> FunctionCall:
    """Trim whitespace from left"""
    c = _ensure_column(col)
    return FunctionCall("LTRIM", c)


def rtrim(col: Union[Column, str]) -> FunctionCall:
    """Trim whitespace from right"""
    c = _ensure_column(col)
    return FunctionCall("RTRIM", c)


def length(col: Union[Column, str]) -> FunctionCall:
    """Get string length"""
    c = _ensure_column(col)
    return FunctionCall("LENGTH", c)


def substring(col: Union[Column, str], pos: int, len: int) -> FunctionCall:
    """Extract substring"""
    c = _ensure_column(col)
    return FunctionCall("SUBSTRING", c, pos, len)


def concat(*cols) -> FunctionCall:
    """Concatenate strings"""
    if len(cols) == 1 and isinstance(cols[0], (list, tuple)):
        cols = cols[0]
    columns = [_ensure_column(c) for c in cols]
    return FunctionCall("CONCAT", *columns)


def concat_ws(sep: str, *cols) -> FunctionCall:
    """Concatenate with separator"""
    if len(cols) == 1 and isinstance(cols[0], (list, tuple)):
        cols = cols[0]
    columns = [_ensure_column(c) for c in cols]
    return FunctionCall("CONCAT_WS", lit(sep), *columns)


def split(col: Union[Column, str], pattern: str, limit: int = -1) -> FunctionCall:
    """Split string by pattern"""
    c = _ensure_column(col)
    if limit > 0:
        return FunctionCall("SPLIT", c, lit(pattern), lit(limit))
    else:
        return FunctionCall("SPLIT", c, lit(pattern))


def regexp_extract(col: Union[Column, str], pattern: str, idx: int) -> FunctionCall:
    """Extract regex group"""
    c = _ensure_column(col)
    return FunctionCall("REGEXP_EXTRACT", c, lit(pattern), lit(idx))


def regexp_replace(col: Union[Column, str], pattern: str, replacement: str) -> FunctionCall:
    """Replace regex matches"""
    c = _ensure_column(col)
    return FunctionCall("REGEXP_REPLACE", c, lit(pattern), lit(replacement))


def translate(col: Union[Column, str], matching: str, replace: str) -> FunctionCall:
    """Translate characters"""
    c = _ensure_column(col)
    return FunctionCall("TRANSLATE", c, lit(matching), lit(replace))


def lpad(col: Union[Column, str], len: int, pad: str) -> FunctionCall:
    """Left pad string"""
    c = _ensure_column(col)
    return FunctionCall("LPAD", c, lit(len), lit(pad))


def rpad(col: Union[Column, str], len: int, pad: str) -> FunctionCall:
    """Right pad string"""
    c = _ensure_column(col)
    return FunctionCall("RPAD", c, lit(len), lit(pad))


def repeat(col: Union[Column, str], n: int) -> FunctionCall:
    """Repeat string n times"""
    c = _ensure_column(col)
    return FunctionCall("REPEAT", c, lit(n))


def reverse(col: Union[Column, str]) -> FunctionCall:
    """Reverse string"""
    c = _ensure_column(col)
    return FunctionCall("REVERSE", c)


def format_string(format: str, *cols) -> FunctionCall:
    """Format string like printf"""
    args = [lit(format)] + [_ensure_column(c) for c in cols]
    return FunctionCall("FORMAT", *args)


def format_number(col: Union[Column, str], d: int) -> FunctionCall:
    """Formats numeric column to a string with d decimal places"""
    c = _ensure_column(col)
    return FunctionCall("FORMAT_NUMBER", c, lit(d))


# Math Functions
def abs(col: Union[Column, str]) -> FunctionCall:
    """Absolute value"""
    c = _ensure_column(col)
    return FunctionCall("ABS", c)


def sqrt(col: Union[Column, str]) -> FunctionCall:
    """Square root"""
    c = _ensure_column(col)
    return FunctionCall("SQRT", c)


def pow(col1: Union[Column, str], col2: Union[Column, str, float]) -> FunctionCall:
    """Power function"""
    c1 = _ensure_column(col1)
    c2 = _ensure_column(col2) if isinstance(col2, (Column, str)) else lit(col2)
    return FunctionCall("POWER", c1, c2)


def round(col: Union[Column, str], scale: int = 0) -> FunctionCall:
    """Round to scale"""
    c = _ensure_column(col)
    return FunctionCall("ROUND", c, lit(scale))


def bround(col: Union[Column, str], scale: int = 0) -> Expression:
    """Banker's rounding (round half to even).

    Emits a CASE expression because e6data does not support BROUND natively:
        value = col * 10^scale
        CASE
          WHEN value - FLOOR(value) = 0.5
            THEN CASE
                   WHEN FLOOR(value) % 2 = 0 THEN FLOOR(value) / 10^scale
                   ELSE CEIL(value) / 10^scale
                 END
          ELSE ROUND(col, scale)
        END
    """
    c = _ensure_column(col)
    factor = lit(10 ** scale)
    scaled = c * factor  # col * 10^scale

    frac_is_half = (scaled - FunctionCall("FLOOR", scaled)) == lit(0.5)
    floor_even = (FunctionCall("FLOOR", scaled) % lit(2)) == lit(0)

    inner_case = (
        CaseExpression()
        .when(floor_even, FunctionCall("FLOOR", scaled) / factor)
        .otherwise(FunctionCall("CEIL", scaled) / factor)
    )

    return (
        CaseExpression()
        .when(frac_is_half, inner_case)
        .otherwise(FunctionCall("ROUND", c, lit(scale)))
    )


def floor(col: Union[Column, str]) -> FunctionCall:
    """Floor value"""
    c = _ensure_column(col)
    return FunctionCall("FLOOR", c)


def ceil(col: Union[Column, str]) -> FunctionCall:
    """Ceiling value"""
    c = _ensure_column(col)
    return FunctionCall("CEIL", c)


def sin(col: Union[Column, str]) -> FunctionCall:
    """Sine"""
    c = _ensure_column(col)
    return FunctionCall("SIN", c)


def cos(col: Union[Column, str]) -> FunctionCall:
    """Cosine"""
    c = _ensure_column(col)
    return FunctionCall("COS", c)


def tan(col: Union[Column, str]) -> FunctionCall:
    """Tangent"""
    c = _ensure_column(col)
    return FunctionCall("TAN", c)


def asin(col: Union[Column, str]) -> FunctionCall:
    """Arc sine"""
    c = _ensure_column(col)
    return FunctionCall("ASIN", c)


def acos(col: Union[Column, str]) -> FunctionCall:
    """Arc cosine"""
    c = _ensure_column(col)
    return FunctionCall("ACOS", c)


def atan(col: Union[Column, str]) -> FunctionCall:
    """Arc tangent"""
    c = _ensure_column(col)
    return FunctionCall("ATAN", c)


def log(col: Union[Column, str], base: float = None) -> FunctionCall:
    """Logarithm"""
    c = _ensure_column(col)
    if base is None:
        return FunctionCall("LN", c)
    else:
        return FunctionCall("LOG", lit(base), c)


def exp(col: Union[Column, str]) -> FunctionCall:
    """Exponential"""
    c = _ensure_column(col)
    return FunctionCall("EXP", c)


def greatest(*cols) -> FunctionCall:
    """Greatest value among columns"""
    columns = [_ensure_column(c) for c in cols]
    return FunctionCall("GREATEST", *columns)


def least(*cols) -> FunctionCall:
    """Least value among columns"""
    columns = [_ensure_column(c) for c in cols]
    return FunctionCall("LEAST", *columns)


# Date/Time Functions
def current_date() -> FunctionCall:
    """Current date"""
    return FunctionCall("CURRENT_DATE")


def current_timestamp() -> FunctionCall:
    """Current timestamp"""
    return FunctionCall("CURRENT_TIMESTAMP")


def date_format(col: Union[Column, str], format: str) -> FunctionCall:
    """Format date - automatically casts column to timestamp and converts format for e6 compatibility"""
    c = _ensure_column(col)
    # Cast the column to timestamp for e6 engine compatibility
    c_timestamp = c.cast("timestamp")
    # Convert Spark date format to e6 format
    e6_format = _convert_date_format(format)
    return FunctionCall("DATE_FORMAT", c_timestamp, lit(e6_format))


def year(col: Union[Column, str]) -> FunctionCall:
    """Extract year"""
    c = _ensure_column(col)
    return FunctionCall("YEAR", c)


def month(col: Union[Column, str]) -> FunctionCall:
    """Extract month"""
    c = _ensure_column(col)
    return FunctionCall("MONTH", c)


def dayofmonth(col: Union[Column, str]) -> FunctionCall:
    """Extract day of month"""
    c = _ensure_column(col)
    return FunctionCall("DAY", c)


def dayofweek(col: Union[Column, str]) -> FunctionCall:
    """Extract day of week"""
    c = _ensure_column(col)
    return FunctionCall("DAYOFWEEK", c)


def dayofyear(col: Union[Column, str]) -> FunctionCall:
    """Extract day of year"""
    c = _ensure_column(col)
    return FunctionCall("DAYOFYEAR", c)


def hour(col: Union[Column, str]) -> FunctionCall:
    """Extract hour"""
    c = _ensure_column(col)
    return FunctionCall("HOUR", c)


def minute(col: Union[Column, str]) -> FunctionCall:
    """Extract minute"""
    c = _ensure_column(col)
    return FunctionCall("MINUTE", c)


def second(col: Union[Column, str]) -> FunctionCall:
    """Extract second"""
    c = _ensure_column(col)
    return FunctionCall("SECOND", c)


def weekofyear(col: Union[Column, str]) -> FunctionCall:
    """Extract week of year"""
    c = _ensure_column(col)
    return FunctionCall("WEEKOFYEAR", c)


def date_add(col: Union[Column, str], days: Union[int, Column, 'Expression']) -> FunctionCall:
    """Add days to date"""
    c = _ensure_column(col)
    # Handle days as either a literal int or a Column/Expression
    if isinstance(days, (Column, Expression)):
        d = days
    else:
        d = lit(days)
    return FunctionCall("DATE_ADD", c, d)


def date_sub(col: Union[Column, str], days: Union[int, Column, 'Expression']) -> FunctionCall:
    """Subtract days from date"""
    c = _ensure_column(col)
    # Handle days as either a literal int or a Column/Expression
    if isinstance(days, (Column, Expression)):
        d = days
    else:
        d = lit(days)
    return FunctionCall("DATE_SUB", c, d)


def datediff(end: Union[Column, str], start: Union[Column, str]) -> FunctionCall:
    """Difference in days"""
    e = _ensure_column(end)
    s = _ensure_column(start)
    return FunctionCall("DATEDIFF", e, s)


def to_date(col: Union[Column, str], format: str = None) -> FunctionCall:
    """Convert to date"""
    c = _ensure_column(col)
    if format:
        return FunctionCall("TO_DATE", c, lit(format))
    else:
        return FunctionCall("TO_DATE", c)


def to_timestamp(col: Union[Column, str], format: str = None) -> FunctionCall:
    """Convert to timestamp"""
    c = _ensure_column(col)
    if format:
        return FunctionCall("TO_TIMESTAMP", c, lit(format))
    else:
        return FunctionCall("TO_TIMESTAMP", c)


def from_unixtime(col: Union[Column, str], format: str = "yyyy-MM-dd HH:mm:ss") -> FunctionCall:
    """Convert Unix timestamp to string"""
    c = _ensure_column(col)
    return FunctionCall("FROM_UNIXTIME", c, lit(format))


def unix_timestamp(col: Union[Column, str] = None, pattern: str = "yyyy-MM-dd HH:mm:ss") -> FunctionCall:
    """Convert to Unix timestamp"""
    if col is None:
        return FunctionCall("UNIX_TIMESTAMP")
    else:
        c = _ensure_column(col)
        return FunctionCall("UNIX_TIMESTAMP", c, lit(pattern))


def to_utc_timestamp(col: Union[Column, str], tz: str) -> FunctionCall:
    """Convert to UTC timestamp"""
    c = _ensure_column(col)
    return FunctionCall("TO_UTC_TIMESTAMP", c, lit(tz))


def add_months(col: Union[Column, str], num_months: int) -> FunctionCall:
    """Add months to date"""
    c = _ensure_column(col)
    return FunctionCall("ADD_MONTHS", c, lit(num_months))


def last_day(col: Union[Column, str]) -> FunctionCall:
    """Get last day of the month"""
    c = _ensure_column(col)
    return FunctionCall("LAST_DAY", c)


def desc(col: Union[Column, str]):
    """Descending order for sorting"""
    from .column import SortExpression
    c = _ensure_column(col)
    return SortExpression(c, "DESC", "")


def asc(col: Union[Column, str]):
    """Ascending order for sorting"""
    from .column import SortExpression
    c = _ensure_column(col)
    return SortExpression(c, "ASC", "")


def from_utc_timestamp(col: Union[Column, str], tz: str) -> FunctionCall:
    """Convert from UTC timestamp"""
    c = _ensure_column(col)
    return FunctionCall("FROM_UTC_TIMESTAMP", c, lit(tz))


# Aggregate Functions
def count(col: Union[Column, str] = None) -> FunctionCall:
    """Count values"""
    if col is None:
        return FunctionCall("COUNT", lit("*"))
    else:
        c = _ensure_column(col)
        return FunctionCall("COUNT", c)


def count_distinct(col: Union[Column, str], *cols) -> FunctionCall:
    """Count distinct values"""
    columns = [_ensure_column(col)] + [_ensure_column(c) for c in cols]
    # COUNT DISTINCT is a special case - we need to generate COUNT(DISTINCT col1, col2, ...)
    # not COUNT(DISTINCT(col1, col2, ...))
    from ..sql.column import CountDistinct
    return CountDistinct(*columns)


def sum(col: Union[Column, str]) -> FunctionCall:
    """Sum values"""
    c = _ensure_column(col)
    return FunctionCall("SUM", c)


def sum_distinct(col: Union[Column, str]) -> FunctionCall:
    """Sum distinct values"""
    c = _ensure_column(col)
    return FunctionCall("SUM", FunctionCall("DISTINCT", c))


def avg(col: Union[Column, str]) -> FunctionCall:
    """Average values"""
    c = _ensure_column(col)
    return FunctionCall("AVG", c)


def mean(col: Union[Column, str]) -> FunctionCall:
    """Alias for avg"""
    return avg(col)


def max(col: Union[Column, str]) -> FunctionCall:
    """Maximum value"""
    c = _ensure_column(col)
    return FunctionCall("MAX", c)


def min(col: Union[Column, str]) -> FunctionCall:
    """Minimum value"""
    c = _ensure_column(col)
    return FunctionCall("MIN", c)


def stddev(col: Union[Column, str]) -> FunctionCall:
    """Standard deviation"""
    c = _ensure_column(col)
    return FunctionCall("STDDEV", c)


def stddev_pop(col: Union[Column, str]) -> FunctionCall:
    """Population standard deviation"""
    c = _ensure_column(col)
    return FunctionCall("STDDEV_POP", c)


def stddev_samp(col: Union[Column, str]) -> FunctionCall:
    """Sample standard deviation"""
    c = _ensure_column(col)
    return FunctionCall("STDDEV_SAMP", c)


def variance(col: Union[Column, str]) -> FunctionCall:
    """Variance"""
    c = _ensure_column(col)
    return FunctionCall("VARIANCE", c)


def var_pop(col: Union[Column, str]) -> FunctionCall:
    """Population variance"""
    c = _ensure_column(col)
    return FunctionCall("VAR_POP", c)


def var_samp(col: Union[Column, str]) -> FunctionCall:
    """Sample variance"""
    c = _ensure_column(col)
    return FunctionCall("VAR_SAMP", c)


def corr(col1: Union[Column, str], col2: Union[Column, str]) -> FunctionCall:
    """Pearson correlation coefficient between two columns"""
    c1 = _ensure_column(col1)
    c2 = _ensure_column(col2)
    return FunctionCall("CORR", c1, c2)


def covar_pop(col1: Union[Column, str], col2: Union[Column, str]) -> FunctionCall:
    """Population covariance of two columns"""
    c1 = _ensure_column(col1)
    c2 = _ensure_column(col2)
    return FunctionCall("COVAR_POP", c1, c2)


def covar_samp(col1: Union[Column, str], col2: Union[Column, str]) -> FunctionCall:
    """Sample covariance of two columns"""
    c1 = _ensure_column(col1)
    c2 = _ensure_column(col2)
    return FunctionCall("COVAR_SAMP", c1, c2)


def percentile_approx(col: Union[Column, str], percentage, accuracy=None) -> FunctionCall:
    """Approximate percentile aggregate function.

    Maps to APPROX_PERCENTILE(col, pct) on e6data. The accuracy parameter is
    accepted for PySpark API compatibility but not forwarded to the engine.

    Args:
        col: Column name or Column object.
        percentage: Percentile value (0.0 to 1.0), can be a float, string, or Expression.
        accuracy: Ignored by the e6data engine, accepted for PySpark compatibility.
    """
    c = _ensure_column(col).cast("double")
    pct = _ensure_column(percentage) if isinstance(percentage, Expression) else lit(float(percentage))
    return FunctionCall("APPROX_PERCENTILE", c, pct)


def percentile(col: Union[Column, str], percentage) -> FunctionCall:
    """Exact percentile aggregate function.

    Automatically casts the column to double for e6data compatibility.
    """
    c = _ensure_column(col).cast("double")
    pct = _ensure_column(percentage) if isinstance(percentage, Expression) else lit(float(percentage))
    return FunctionCall("PERCENTILE", c, pct)


def collect_list(col: Union[Column, str]) -> FunctionCall:
    """Collect values into list"""
    c = _ensure_column(col)
    return FunctionCall("COLLECT_LIST", c)


def collect_set(col: Union[Column, str]) -> FunctionCall:
    """Collect unique values into set"""
    c = _ensure_column(col)
    return FunctionCall("COLLECT_SET", c)


def first(col: Union[Column, str], ignorenulls: bool = False) -> FunctionCall:
    """First value"""
    c = _ensure_column(col)
    fc = FunctionCall("FIRST_VALUE", c)
    fc._ignorenulls = ignorenulls
    return fc


def last(col: Union[Column, str], ignorenulls: bool = False) -> FunctionCall:
    """Last value"""
    c = _ensure_column(col)
    fc = FunctionCall("LAST_VALUE", c)
    fc._ignorenulls = ignorenulls
    return fc


def approx_count_distinct(col: Union[Column, str], rsd: float = 0.05) -> FunctionCall:
    """Approximate count distinct"""
    c = _ensure_column(col)
    return FunctionCall("APPROX_COUNT_DISTINCT", c)


# Hash Functions
def md5(col: Union[Column, str]) -> FunctionCall:
    """MD5 hash"""
    c = _ensure_column(col)
    return FunctionCall("MD5", c)


def sha1(col: Union[Column, str]) -> FunctionCall:
    """SHA1 hash"""
    c = _ensure_column(col)
    return FunctionCall("SHA1", c)


def sha2(col: Union[Column, str], numBits: int) -> FunctionCall:
    """SHA2 hash"""
    c = _ensure_column(col)
    return FunctionCall("SHA2", c, lit(numBits))


def hash(*cols) -> FunctionCall:
    """Hash of columns"""
    columns = [_ensure_column(c) for c in cols]
    return FunctionCall("HASH", *columns)


def xxhash64(*cols) -> FunctionCall:
    """xxHash64 of columns"""
    columns = [_ensure_column(c) for c in cols]
    return FunctionCall("XXHASH64", *columns)


# Struct Functions
def struct(*cols) -> StructExpression:
    """Create a struct column from columns or column names.

    Supports the same calling conventions as PySpark:
        struct("col1", "col2")
        struct(col("a").alias("x"), col("b").alias("y"))
        struct(["col1", "col2"])

    Field names are derived from:
        1. The column's ``.alias()`` if set.
        2. The column name for ``Column`` objects.
        3. Auto-generated (``_0``, ``_1``, …) for unnamed expressions.
    """
    from .column import LiteralExpression

    # Handle single list/tuple argument (PySpark compatibility)
    if len(cols) == 1 and isinstance(cols[0], (list, tuple)):
        cols = cols[0]

    if not cols:
        raise ValueError("struct() requires at least one column or expression")

    fields = []
    for idx, c in enumerate(cols):
        if isinstance(c, str):
            c = Column(c)

        if isinstance(c, Expression):
            if c._alias:
                field_name = c._alias
            elif isinstance(c, Column):
                field_name = c.name
            else:
                field_name = f"_{idx}"
            fields.append((c, field_name))
        else:
            fields.append((LiteralExpression(c), f"_{idx}"))

    return StructExpression(fields)


# Array Functions
def array(*cols) -> FunctionCall:
    """Create array"""
    if len(cols) == 1 and isinstance(cols[0], (list, tuple)):
        cols = cols[0]
    columns = [_ensure_column(c) for c in cols]
    return FunctionCall("ARRAY", *columns)


def array_contains(col: Union[Column, str], value: Any) -> FunctionCall:
    """Check if array contains value"""
    c = _ensure_column(col)
    return FunctionCall("ARRAY_CONTAINS", c, lit(value))


def array_distinct(col: Union[Column, str]) -> FunctionCall:
    """Remove duplicates from array"""
    c = _ensure_column(col)
    return FunctionCall("ARRAY_DISTINCT", c)


def array_except(col1: Union[Column, str], col2: Union[Column, str]) -> FunctionCall:
    """Array difference"""
    c1 = _ensure_column(col1)
    c2 = _ensure_column(col2)
    return FunctionCall("ARRAY_EXCEPT", c1, c2)


def array_intersect(col1: Union[Column, str], col2: Union[Column, str]) -> FunctionCall:
    """Array intersection"""
    c1 = _ensure_column(col1)
    c2 = _ensure_column(col2)
    return FunctionCall("ARRAY_INTERSECT", c1, c2)


def array_join(col: Union[Column, str], delimiter: str, null_replacement: str = None) -> FunctionCall:
    """Join array elements"""
    c = _ensure_column(col)
    if null_replacement:
        return FunctionCall("ARRAY_JOIN", c, lit(delimiter), lit(null_replacement))
    else:
        return FunctionCall("ARRAY_JOIN", c, lit(delimiter))


def array_max(col: Union[Column, str]) -> FunctionCall:
    """Maximum in array"""
    c = _ensure_column(col)
    return FunctionCall("ARRAY_MAX", c)


def array_min(col: Union[Column, str]) -> FunctionCall:
    """Minimum in array"""
    c = _ensure_column(col)
    return FunctionCall("ARRAY_MIN", c)


def array_position(col: Union[Column, str], value: Any) -> FunctionCall:
    """Position of value in array"""
    c = _ensure_column(col)
    return FunctionCall("ARRAY_POSITION", c, lit(value))


def array_remove(col: Union[Column, str], element: Any) -> FunctionCall:
    """Remove element from array"""
    c = _ensure_column(col)
    return FunctionCall("ARRAY_REMOVE", c, lit(element))


def array_repeat(col: Union[Column, str], count: int) -> FunctionCall:
    """Repeat array elements"""
    c = _ensure_column(col)
    return FunctionCall("ARRAY_REPEAT", c, lit(count))


def array_sort(col: Union[Column, str]) -> FunctionCall:
    """Sort array"""
    c = _ensure_column(col)
    return FunctionCall("ARRAY_SORT", c)


def array_union(col1: Union[Column, str], col2: Union[Column, str]) -> FunctionCall:
    """Array union"""
    c1 = _ensure_column(col1)
    c2 = _ensure_column(col2)
    return FunctionCall("ARRAY_UNION", c1, c2)


def arrays_overlap(col1: Union[Column, str], col2: Union[Column, str]) -> FunctionCall:
    """Check if arrays overlap"""
    c1 = _ensure_column(col1)
    c2 = _ensure_column(col2)
    return FunctionCall("ARRAYS_OVERLAP", c1, c2)


def arrays_zip(*cols) -> FunctionCall:
    """Zip arrays"""
    columns = [_ensure_column(c) for c in cols]
    return FunctionCall("ARRAYS_ZIP", *columns)


def slice(col: Union[Column, str], start: int, length: int) -> FunctionCall:
    """Slice array"""
    c = _ensure_column(col)
    return FunctionCall("SLICE", c, lit(start), lit(length))


def explode(col: Union[Column, str]) -> FunctionCall:
    """Explode array to rows"""
    c = _ensure_column(col)
    return FunctionCall("EXPLODE", c)


def explode_outer(col: Union[Column, str]) -> FunctionCall:
    """Explode array to rows with nulls"""
    c = _ensure_column(col)
    return FunctionCall("EXPLODE_OUTER", c)


def posexplode(col: Union[Column, str]) -> FunctionCall:
    """Explode array with position"""
    c = _ensure_column(col)
    return FunctionCall("POSEXPLODE", c)


def posexplode_outer(col: Union[Column, str]) -> FunctionCall:
    """Explode array with position and nulls"""
    c = _ensure_column(col)
    return FunctionCall("POSEXPLODE_OUTER", c)


def size(col: Union[Column, str]) -> FunctionCall:
    """Size of array or map"""
    c = _ensure_column(col)
    return FunctionCall("SIZE", c)


# Map Functions
def map_keys(col: Union[Column, str]) -> FunctionCall:
    """Get map keys"""
    c = _ensure_column(col)
    return FunctionCall("MAP_KEYS", c)


def map_values(col: Union[Column, str]) -> FunctionCall:
    """Get map values"""
    c = _ensure_column(col)
    return FunctionCall("MAP_VALUES", c)


def map_from_arrays(keys: Union[Column, str], values: Union[Column, str]) -> FunctionCall:
    """Create map from arrays"""
    k = _ensure_column(keys)
    v = _ensure_column(values)
    return FunctionCall("MAP_FROM_ARRAYS", k, v)


def map_concat(*cols) -> FunctionCall:
    """Concatenate maps"""
    columns = [_ensure_column(c) for c in cols]
    return FunctionCall("MAP_CONCAT", *columns)


# JSON Functions
def get_json_object(col: Union[Column, str], path: str) -> FunctionCall:
    """Extract JSON object"""
    c = _ensure_column(col)
    return FunctionCall("GET_JSON_OBJECT", c, lit(path))

def json_extract(col: Union[Column, str], path: str) -> FunctionCall:
    """Extract JSON object"""
    c = _ensure_column(col)
    return FunctionCall("JSON_EXTRACT", c, lit(path))


def json_tuple(col: Union[Column, str], *fields) -> FunctionCall:
    """Extract JSON fields"""
    c = _ensure_column(col)
    field_lits = [lit(f) for f in fields]
    return FunctionCall("JSON_TUPLE", c, *field_lits)


def from_json(col: Union[Column, str], schema: Union[str, Any], options: dict = None) -> FunctionCall:
    """Parse JSON string"""
    c = _ensure_column(col)
    if isinstance(schema, str):
        return FunctionCall("FROM_JSON", c, lit(schema))
    else:
        # Handle StructType schema
        return FunctionCall("FROM_JSON", c, lit(str(schema)))


def to_json(col: Union[Column, str], options: dict = None) -> FunctionCall:
    """Convert to JSON string"""
    c = _ensure_column(col)
    return FunctionCall("TO_JSON", c)


# Null Functions
def coalesce(*cols) -> FunctionCall:
    """Return first non-null value"""
    columns = [_ensure_column(c) for c in cols]
    return FunctionCall("COALESCE", *columns)


def isnull(col: Union[Column, str]) -> Expression:
    """Check if null"""
    c = _ensure_column(col)
    return c.isNull()


def isnan(col: Union[Column, str]) -> FunctionCall:
    """Check if NaN"""
    c = _ensure_column(col)
    return FunctionCall("ISNAN", c)


def nanvl(col1: Union[Column, str], col2: Union[Column, str]) -> FunctionCall:
    """Replace NaN with value"""
    c1 = _ensure_column(col1)
    c2 = _ensure_column(col2)
    return FunctionCall("NANVL", c1, c2)


# Conditional Functions
def when(condition: Expression, value: Any) -> CaseExpression:
    """Start CASE expression"""
    case = CaseExpression()
    return case.when(condition, value)


def expr(expression: str) -> Expression:
    """Create expression from SQL string"""
    from .column import RawExpression
    
    # expr() should return SQL as-is without any double quotes
    return RawExpression(expression)


# Window Functions
def row_number() -> FunctionCall:
    """Row number window function"""
    return FunctionCall("ROW_NUMBER")


def rank() -> FunctionCall:
    """Rank window function"""
    return FunctionCall("RANK")


def dense_rank() -> FunctionCall:
    """Dense rank window function"""
    return FunctionCall("DENSE_RANK")


def percent_rank() -> FunctionCall:
    """Percent rank window function"""
    return FunctionCall("PERCENT_RANK")


def ntile(n: int) -> FunctionCall:
    """Ntile window function"""
    return FunctionCall("NTILE", lit(n))


def cume_dist() -> FunctionCall:
    """Cumulative distribution"""
    return FunctionCall("CUME_DIST")


def lag(col: Union[Column, str], offset: int = 1, default: Any = None) -> FunctionCall:
    """Lag window function"""
    c = _ensure_column(col)
    if default is not None:
        return FunctionCall("LAG", c, lit(offset), lit(default))
    else:
        return FunctionCall("LAG", c, lit(offset))


def lead(col: Union[Column, str], offset: int = 1, default: Any = None) -> FunctionCall:
    """Lead window function"""
    c = _ensure_column(col)
    if default is not None:
        return FunctionCall("LEAD", c, lit(offset), lit(default))
    else:
        return FunctionCall("LEAD", c, lit(offset))


# Type Functions
def cast(col: Union[Column, str], dataType: Union[str, Any]) -> Expression:
    """Cast column to type"""
    c = _ensure_column(col)
    return c.cast(dataType)


# Misc Functions
def broadcast(df) -> Any:
    """Mark DataFrame for broadcast join"""
    # This is handled at the DataFrame level
    df._broadcast_hint = True
    return df


def monotonically_increasing_id() -> FunctionCall:
    """Generate monotonically increasing 64-bit integers"""
    return FunctionCall("MONOTONICALLY_INCREASING_ID")


def spark_partition_id() -> FunctionCall:
    """Get partition ID"""
    return FunctionCall("SPARK_PARTITION_ID")


def input_file_name() -> FunctionCall:
    """Get input file name"""
    return FunctionCall("INPUT_FILE_NAME")


def rand(seed: int = None) -> FunctionCall:
    """Random value [0, 1)"""
    if seed is not None:
        return FunctionCall("RAND", lit(seed))
    else:
        return FunctionCall("RAND")


def randn(seed: int = None) -> FunctionCall:
    """Random normal distribution"""
    if seed is not None:
        return FunctionCall("RANDN", lit(seed))
    else:
        return FunctionCall("RANDN")


def udf(f=None, returnType=None):
    """Register a Python function as a UDF that gets translated to SQL.

    Supports three calling conventions:
        @udf(returnType=ArrayType(FloatType()))
        def my_func(x, y): ...

        my_udf = udf(my_func, ArrayType(FloatType()))

        my_udf = udf(my_func)
    """
    if callable(f):
        return UDFWrapper(f, returnType)
    elif f is None:
        def decorator(func):
            return UDFWrapper(func, returnType)
        return decorator
    elif isinstance(f, DataType):
        def decorator(func):
            return UDFWrapper(func, f)
        return decorator
    else:
        raise ValueError(f"udf() expects a callable or DataType, got {type(f)}")


def _ensure_column(col: Union[Column, str, Expression]) -> Expression:
    """Ensure we have a Column or Expression object"""
    from .column import Expression, LiteralExpression
    if isinstance(col, str):
        return Column(col)
    elif isinstance(col, (Column, Expression)):
        return col
    else:
        raise ValueError(f"Expected Column, Expression or str, got {type(col)}")


# Export all functions
__all__ = [
    # String functions
    'upper', 'lower', 'trim', 'ltrim', 'rtrim', 'length', 'substring',
    'concat', 'concat_ws', 'split', 'regexp_extract', 'regexp_replace',
    'translate', 'lpad', 'rpad', 'repeat', 'reverse', 'format_string', 'format_number',
    
    # Math functions
    'abs', 'sqrt', 'pow', 'round', 'bround', 'floor', 'ceil', 'sin', 'cos', 'tan',
    'asin', 'acos', 'atan', 'log', 'exp', 'greatest', 'least',
    
    # Date/time functions
    'current_date', 'current_timestamp', 'date_format', 'year', 'month',
    'dayofmonth', 'dayofweek', 'dayofyear', 'hour', 'minute', 'second',
    'weekofyear', 'date_add', 'date_sub', 'datediff', 'to_date',
    'to_timestamp', 'from_unixtime', 'unix_timestamp', 'to_utc_timestamp',
    'from_utc_timestamp', 'add_months', 'last_day', 'desc', 'asc',
    
    # Aggregate functions
    'count', 'count_distinct', 'sum', 'sum_distinct', 'avg', 'mean',
    'max', 'min', 'stddev', 'stddev_pop', 'stddev_samp', 'variance',
    'var_pop', 'var_samp', 'collect_list', 'collect_set', 'first', 'last',
    'approx_count_distinct', 'countDistinct',
    'corr', 'covar_pop', 'covar_samp', 'percentile_approx', 'percentile',
    
    # Hash functions
    'md5', 'sha1', 'sha2', 'hash', 'xxhash64',
    
    # Struct functions
    'struct',

    # Array functions
    'array', 'array_contains', 'array_distinct', 'array_except',
    'array_intersect', 'array_join', 'array_max', 'array_min',
    'array_position', 'array_remove', 'array_repeat', 'array_sort',
    'array_union', 'arrays_overlap', 'arrays_zip', 'slice',
    'explode', 'explode_outer', 'posexplode', 'posexplode_outer', 'size',
    
    # Map functions
    'map_keys', 'map_values', 'map_from_arrays', 'map_concat',
    
    # JSON functions
    'get_json_object', 'json_tuple', 'from_json', 'to_json',
    
    # Null functions
    'coalesce', 'isnull', 'isnan', 'nanvl',
    
    # Conditional functions
    'when', 'expr',
    
    # Window functions
    'row_number', 'rank', 'dense_rank', 'percent_rank', 'ntile',
    'cume_dist', 'lag', 'lead',
    
    # Type functions
    'cast',
    
    # Misc functions
    'col', 'lit', 'broadcast', 'monotonically_increasing_id',
    'spark_partition_id', 'input_file_name', 'rand', 'randn',

    # UDF
    'udf',

    # Type re-exports (for convenience: from functions import ArrayType, FloatType, ...)
    'DataType', 'ArrayType', 'FloatType', 'StringType', 'IntegerType', 'LongType',
    'DoubleType', 'BooleanType', 'ShortType', 'ByteType', 'DateType', 'TimestampType',
    'DecimalType', 'BinaryType', 'NullType', 'MapType', 'StructType', 'StructField',
]

# === PySpark Compatibility Aliases ===
_PYSPARK_ALIASES = {
    'count_distinct': ['countDistinct'],
    # Add more aliases here as needed
    # 'original_function_name': ['alias1', 'alias2', 'alias3'],
}

# Apply aliases
for original_func, aliases in _PYSPARK_ALIASES.items():
    original = globals()[original_func]
    for alias in aliases:
        globals()[alias] = original