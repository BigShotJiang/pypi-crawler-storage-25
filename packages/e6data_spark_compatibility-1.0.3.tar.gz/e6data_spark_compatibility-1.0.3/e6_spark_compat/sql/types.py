"""
PySpark-compatible data types
"""
from typing import List, Dict, Any, Optional, Union
from dataclasses import dataclass


class DataType:
    """Base class for data types"""
    def simpleString(self) -> str:
        return self.__class__.__name__
    
    def json(self) -> str:
        return f'{{"type": "{self.simpleString()}"}}'
    
    def __repr__(self):
        return f"{self.__class__.__name__}()"


class AtomicType(DataType):
    """Base class for atomic types"""
    pass


class NumericType(AtomicType):
    """Base class for numeric types"""
    pass


class IntegralType(NumericType):
    """Base class for integral types"""
    pass


class FractionalType(NumericType):
    """Base class for fractional types"""
    pass


# Concrete types
class NullType(AtomicType):
    def simpleString(self) -> str:
        return "null"


class BooleanType(AtomicType):
    def simpleString(self) -> str:
        return "boolean"


class ByteType(IntegralType):
    def simpleString(self) -> str:
        return "tinyint"


class ShortType(IntegralType):
    def simpleString(self) -> str:
        return "smallint"


class IntegerType(IntegralType):
    def simpleString(self) -> str:
        return "int"


class LongType(IntegralType):
    def simpleString(self) -> str:
        return "bigint"


class FloatType(FractionalType):
    def simpleString(self) -> str:
        return "float"


class DoubleType(FractionalType):
    def simpleString(self) -> str:
        return "double"


@dataclass
class DecimalType(FractionalType):
    precision: int = 10
    scale: int = 0
    
    def simpleString(self) -> str:
        return f"decimal({self.precision},{self.scale})"


class StringType(AtomicType):
    def simpleString(self) -> str:
        return "string"


class BinaryType(AtomicType):
    def simpleString(self) -> str:
        return "binary"


class DateType(AtomicType):
    def simpleString(self) -> str:
        return "date"


class TimestampType(AtomicType):
    def simpleString(self) -> str:
        return "timestamp"


# Complex types
@dataclass
class ArrayType(DataType):
    elementType: DataType
    containsNull: bool = True
    
    def simpleString(self) -> str:
        return f"array<{self.elementType.simpleString()}>"


@dataclass
class MapType(DataType):
    keyType: DataType
    valueType: DataType
    valueContainsNull: bool = True
    
    def simpleString(self) -> str:
        return f"map<{self.keyType.simpleString()},{self.valueType.simpleString()}>"


@dataclass
class StructField:
    name: str
    dataType: DataType
    nullable: bool = True
    metadata: Dict[str, Any] = None
    
    def simpleString(self) -> str:
        return f"{self.name}:{self.dataType.simpleString()}"


@dataclass
class StructType(DataType):
    fields: List[StructField] = None
    
    def __init__(self, fields: List[Union[StructField, tuple]] = None):
        if fields is None:
            self.fields = []
        else:
            self.fields = []
            for field in fields:
                if isinstance(field, StructField):
                    self.fields.append(field)
                elif isinstance(field, tuple):
                    # Convert tuple to StructField
                    if len(field) == 2:
                        self.fields.append(StructField(field[0], field[1]))
                    elif len(field) == 3:
                        self.fields.append(StructField(field[0], field[1], field[2]))
                    elif len(field) == 4:
                        self.fields.append(StructField(field[0], field[1], field[2], field[3]))
    
    def add(self, field: Union[StructField, str], data_type: DataType = None, 
            nullable: bool = True, metadata: Dict[str, Any] = None) -> 'StructType':
        """Add a field to the struct"""
        if isinstance(field, StructField):
            self.fields.append(field)
        else:
            self.fields.append(StructField(field, data_type, nullable, metadata))
        return self
    
    def simpleString(self) -> str:
        field_strs = [f.simpleString() for f in self.fields]
        return f"struct<{','.join(field_strs)}>"
    
    @property
    def fieldNames(self) -> List[str]:
        return [f.name for f in self.fields]


# Spatial types (for Sedona compatibility)
class GeometryType(AtomicType):
    def simpleString(self) -> str:
        return "geometry"


# Type shortcuts
def _create_type(scala_type_name: str) -> DataType:
    """Create type from Scala type name"""
    type_map = {
        "boolean": BooleanType(),
        "byte": ByteType(),
        "short": ShortType(),
        "int": IntegerType(),
        "integer": IntegerType(),
        "long": LongType(),
        "bigint": LongType(),
        "float": FloatType(),
        "double": DoubleType(),
        "decimal": DecimalType(),
        "string": StringType(),
        "binary": BinaryType(),
        "date": DateType(),
        "timestamp": TimestampType(),
        "null": NullType(),
        "geometry": GeometryType(),
    }
    
    return type_map.get(scala_type_name.lower())


# Type inference
def _infer_type(obj: Any) -> DataType:
    """Infer type from Python object"""
    if obj is None:
        return NullType()
    elif isinstance(obj, bool):
        return BooleanType()
    elif isinstance(obj, int):
        if -128 <= obj <= 127:
            return ByteType()
        elif -32768 <= obj <= 32767:
            return ShortType()
        elif -2147483648 <= obj <= 2147483647:
            return IntegerType()
        else:
            return LongType()
    elif isinstance(obj, float):
        return DoubleType()
    elif isinstance(obj, str):
        return StringType()
    elif isinstance(obj, bytes):
        return BinaryType()
    elif isinstance(obj, list):
        if len(obj) == 0:
            return ArrayType(NullType())
        else:
            element_type = _infer_type(obj[0])
            return ArrayType(element_type)
    elif isinstance(obj, dict):
        if len(obj) == 0:
            return MapType(NullType(), NullType())
        else:
            key = next(iter(obj.keys()))
            value = obj[key]
            return MapType(_infer_type(key), _infer_type(value))
    else:
        return StringType()


def _parse_datatype_string(s: str) -> DataType:
    """Parse a data type string"""
    # Simple implementation - in production use proper parser
    s = s.strip().lower()
    
    # Check for array
    if s.startswith("array<") and s.endswith(">"):
        element_type_str = s[6:-1]
        element_type = _parse_datatype_string(element_type_str)
        return ArrayType(element_type)
    
    # Check for map
    if s.startswith("map<") and s.endswith(">"):
        # Find the comma separating key and value types
        inner = s[4:-1]
        # Simple split - doesn't handle nested types well
        parts = inner.split(",", 1)
        if len(parts) == 2:
            key_type = _parse_datatype_string(parts[0])
            value_type = _parse_datatype_string(parts[1])
            return MapType(key_type, value_type)
    
    # Check for struct
    if s.startswith("struct<") and s.endswith(">"):
        # Parse struct fields - simplified
        return StructType()
    
    # Check for decimal
    if s.startswith("decimal"):
        if "(" in s and ")" in s:
            params = s[s.index("(")+1:s.index(")")].split(",")
            if len(params) == 2:
                return DecimalType(int(params[0]), int(params[1]))
            elif len(params) == 1:
                return DecimalType(int(params[0]))
        return DecimalType()
    
    # Simple types
    return _create_type(s)


# Export all types
__all__ = [
    'DataType', 'AtomicType', 'NumericType', 'IntegralType', 'FractionalType',
    'NullType', 'BooleanType', 'ByteType', 'ShortType', 'IntegerType',
    'LongType', 'FloatType', 'DoubleType', 'DecimalType', 'StringType',
    'BinaryType', 'DateType', 'TimestampType', 'ArrayType', 'MapType',
    'StructField', 'StructType', 'GeometryType',
]