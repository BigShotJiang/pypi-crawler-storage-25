"""
Column and Expression classes for building SQL expressions
"""
from abc import ABC, abstractmethod
from typing import Optional, Any, Union


class Expression(ABC):
    """Base class for expressions"""
    
    def __init__(self):
        self._alias = None
    
    @abstractmethod
    def to_sql(self, preserve_qualifiers: bool = False) -> str:
        pass
    
    def alias(self, alias: str) -> 'Expression':
        """Add alias to expression"""
        self._alias = alias
        return self
    
    def cast(self, dataType: Union[str, Any]) -> 'Expression':
        """Cast expression to a type"""
        return CastExpression(self, dataType)
    
    def isNull(self) -> 'Expression':
        """Check if null"""
        return BinaryExpression(self, "IS", LiteralExpression(None))
    
    def isNotNull(self) -> 'Expression':
        """Check if not null"""
        return BinaryExpression(self, "IS NOT", LiteralExpression(None))
    
    def isin(self, *values) -> 'Expression':
        """Check if value is in list
        
        Supports both:
        - isin("A", "B", "C") - multiple arguments
        - isin(["A", "B", "C"]) - single list argument
        """
        # If single argument is passed and it's a list/tuple, unpack it
        if len(values) == 1 and isinstance(values[0], (list, tuple)):
            values = tuple(values[0])
        if len(values) == 0:
            return LiteralExpression(False)
        return InExpression(self, values)
    
    def getItem(self, index: Any) -> 'Expression':
        """Get item from array or map by index/key (1-based in SQL)."""
        # PySpark uses 0-based indexing; Spark SQL ELEMENT_AT uses 1-based
        if isinstance(index, int):
            return FunctionCall("ELEMENT_AT", self, LiteralExpression(index + 1))
        return FunctionCall("ELEMENT_AT", self, _to_expression(index))

    def getField(self, name: str) -> 'Expression':
        """Access a struct field by name. Returns expr.name in SQL."""
        return StructFieldAccess(self, name)

    def __getitem__(self, key: Any) -> 'Expression':
        """Subscript operator: col['field'] for structs, col[0] for arrays."""
        if isinstance(key, str):
            return self.getField(key)
        return self.getItem(key)

    def between(self, lowerBound: Any, upperBound: Any) -> 'Expression':
        """Check if between values"""
        return BetweenExpression(self, lowerBound, upperBound)
    
    def otherwise(self, value: Any) -> 'Expression':
        """For case expressions"""
        # This should be handled by CaseExpression
        return self
    
    # Comparison operators
    def __eq__(self, other) -> 'Expression':
        return BinaryExpression(self, "=", _to_expression(other))
    
    def __ne__(self, other) -> 'Expression':
        return BinaryExpression(self, "!=", _to_expression(other))
    
    def __lt__(self, other) -> 'Expression':
        return BinaryExpression(self, "<", _to_expression(other))
    
    def __le__(self, other) -> 'Expression':
        return BinaryExpression(self, "<=", _to_expression(other))
    
    def __gt__(self, other) -> 'Expression':
        return BinaryExpression(self, ">", _to_expression(other))
    
    def __ge__(self, other) -> 'Expression':
        return BinaryExpression(self, ">=", _to_expression(other))
    
    # Arithmetic operators
    def __add__(self, other) -> 'Expression':
        return BinaryExpression(self, "+", _to_expression(other))
    
    def __sub__(self, other) -> 'Expression':
        return BinaryExpression(self, "-", _to_expression(other))
    
    def __mul__(self, other) -> 'Expression':
        return BinaryExpression(self, "*", _to_expression(other))
    
    def __truediv__(self, other) -> 'Expression':
        return BinaryExpression(self, "/", _to_expression(other))
    
    def __mod__(self, other) -> 'Expression':
        return BinaryExpression(self, "%", _to_expression(other))
    
    def __pow__(self, other) -> 'Expression':
        return FunctionCall("POWER", self, _to_expression(other))
    
    # Reverse operators
    def __radd__(self, other) -> 'Expression':
        return BinaryExpression(_to_expression(other), "+", self)
    
    def __rsub__(self, other) -> 'Expression':
        return BinaryExpression(_to_expression(other), "-", self)
    
    def __rmul__(self, other) -> 'Expression':
        return BinaryExpression(_to_expression(other), "*", self)
    
    def __rtruediv__(self, other) -> 'Expression':
        return BinaryExpression(_to_expression(other), "/", self)
    
    # Logical operators
    def __and__(self, other) -> 'Expression':
        return BinaryExpression(self, "AND", _to_expression(other))
    
    def __or__(self, other) -> 'Expression':
        return BinaryExpression(self, "OR", _to_expression(other))
    
    def __invert__(self) -> 'Expression':
        return UnaryExpression("NOT", self)
    
    # String operations
    def like(self, pattern: str) -> 'Expression':
        """SQL LIKE operation"""
        return BinaryExpression(self, "LIKE", LiteralExpression(pattern))
    
    def rlike(self, pattern: str) -> 'Expression':
        """SQL regex LIKE operation"""
        return BinaryExpression(self, "RLIKE", LiteralExpression(pattern))
    
    def startswith(self, prefix: str) -> 'Expression':
        """Check if string starts with prefix"""
        return self.like(f"{prefix}%")
    
    def endswith(self, suffix: str) -> 'Expression':
        """Check if string ends with suffix"""
        return self.like(f"%{suffix}")
    
    def contains(self, substring: str) -> 'Expression':
        """Check if string contains substring"""
        return self.like(f"%{substring}%")
    
    def substr(self, startPos: int, length: int) -> 'Expression':
        """Substring operation"""
        return FunctionCall("SUBSTRING", self, startPos, length)
    
    def substring(self, startPos: int, length: int) -> 'Expression':
        """Alias for substr"""
        return self.substr(startPos, length)
    
    # Sorting
    def asc(self) -> 'Expression':
        """Ascending sort"""
        # For Column instances, use the original name to avoid double-quoting
        if isinstance(self, Column):
            col = Column(self.name, self.table_alias)
        else:
            # For other expressions, use the SQL representation
            col = Column(self.to_sql())
        col._asc = True
        col._desc = False
        return col
    
    def desc(self) -> 'Expression':
        """Descending sort"""
        # For Column instances, use the original name to avoid double-quoting
        if isinstance(self, Column):
            col = Column(self.name, self.table_alias)
        else:
            # For other expressions, use the SQL representation
            col = Column(self.to_sql())
        col._asc = False
        col._desc = True
        return col
    
    def asc_nulls_first(self) -> 'Expression':
        """Ascending sort with nulls first"""
        return SortExpression(self, "ASC", "NULLS FIRST")
    
    def asc_nulls_last(self) -> 'Expression':
        """Ascending sort with nulls last"""
        return SortExpression(self, "ASC", "NULLS LAST")
    
    def desc_nulls_first(self) -> 'Expression':
        """Descending sort with nulls first"""
        return SortExpression(self, "DESC", "NULLS FIRST")
    
    def desc_nulls_last(self) -> 'Expression':
        """Descending sort with nulls last"""
        return SortExpression(self, "DESC", "NULLS LAST")


class Column(Expression):
    """Represents a column reference"""
    
    def __init__(self, name: str, table_alias: Optional[str] = None):
        super().__init__()
        self.name = name
        self.table_alias = table_alias
        self._desc = False
        self._asc = False
    
    def to_sql(self, preserve_qualifiers: bool = False) -> str:
        # Handle table.column notation in the name
        actual_name = self.name
        
        # Check if this is likely a struct field access pattern
        # Common patterns: data.field, parsed.attribute, json_col.property
        def is_struct_field_access(name):
            if '.' not in name:
                return False
            parts = name.split('.', 1)
            if len(parts) != 2:
                return False
            base_name = parts[0]
            # Common struct column names from FROM_JSON, struct types, etc.
            struct_indicators = ['data', 'parsed', 'json', 'struct', 'properties', 'metadata', 'params', 'attributes']
            # Check if base name matches common struct patterns
            if base_name.lower() in struct_indicators:
                return True
            # Check if base name contains these indicators
            for indicator in struct_indicators:
                if indicator in base_name.lower():
                    return True
            # If none of the above, check if this is NOT a known table alias pattern
            # Table aliases are typically short (1-3 chars) or follow specific patterns
            if len(base_name) <= 3:  # Likely a table alias like 'g', 'l', 'a', 'b'
                return False
            return False  # Conservative default
        
        # Handle qualified column names based on preserve_qualifiers setting
        if preserve_qualifiers and '.' in actual_name and not actual_name.startswith('"') and '(' not in actual_name:
            # For JOIN conditions, split table.column and quote both parts separately
            parts = actual_name.split('.', 1)
            if len(parts) == 2:
                table_part, column_part = parts
                # Quote both table and column parts
                quoted_table = f'"{table_part}"'
                quoted_column = f'"{column_part}"'
                return f'{quoted_table}.{quoted_column}'
        elif not preserve_qualifiers and '.' in actual_name and not actual_name.startswith('"') and '(' not in actual_name:
            # Check if this is struct field access
            if is_struct_field_access(actual_name):
                # For struct field access, return as-is without quotes
                # e.g., data.category remains data.category
                return actual_name
            else:
                # Two emission shapes for dotted col refs:
                #   1. Split form `"alias"."column"` — for non-CTE mode where the
                #      JOIN preserves table-qualified column refs natively.
                #   2. Single literal-dot id `"alias.column"` — for CTE mode where
                #      the JOIN flattens columns and creates aliases like
                #      "a.txn_date" (a literal column name with a dot in it).
                # Choose based on global CTE mode so the projection matches
                # what the JOIN emits.
                from ..core.sql_generator import get_use_cte
                parts = actual_name.split('.', 1)
                if len(parts) == 2:
                    table_part, column_part = parts
                    if get_use_cte():
                        # CTE mode: reference the flat alias literally
                        return f'"{table_part}.{column_part}"'
                    else:
                        # Non-CTE mode: emit `"alias"."column"` (split form)
                        return f'"{table_part}"."{column_part}"'
        
        # Quote column names to handle special characters and reserved words
        # But only if not already quoted or if it's a function expression
        if actual_name == "*":
            # Special case: wildcard selector should not be quoted
            quoted_name = "*"
        elif actual_name.startswith('"') and actual_name.endswith('"'):
            # Already quoted
            quoted_name = actual_name
        elif '(' in actual_name:
            # This looks like a function call, don't quote it
            quoted_name = actual_name
        else:
            quoted_name = f'"{actual_name}"'
        
        base_sql = f"{self.table_alias}.{quoted_name}" if self.table_alias else quoted_name
        
        # Handle DESC/ASC flags for ordering in window functions
        if hasattr(self, '_desc') and self._desc:
            return f"{base_sql} DESC"
        elif hasattr(self, '_asc') and self._asc:
            return f"{base_sql} ASC"
        else:
            return base_sql
    
    def __str__(self):
        return self.to_sql()
    
    def __repr__(self):
        return f"Column({self.name})"


class LiteralExpression(Expression):
    """Represents a literal value"""

    def __init__(self, value: Any):
        super().__init__()
        self.value = value

    def to_sql(self, preserve_qualifiers: bool = False) -> str:
        import datetime as _dt
        # If the value is already an Expression, delegate to its to_sql()
        if isinstance(self.value, Expression):
            return self.value.to_sql(preserve_qualifiers)
        elif isinstance(self.value, _dt.datetime):
            return f"CAST('{self.value.strftime('%Y-%m-%d %H:%M:%S')}' AS TIMESTAMP)"
        elif isinstance(self.value, _dt.date):
            return f"CAST('{self.value.strftime('%Y-%m-%d')}' AS TIMESTAMP)"
        elif isinstance(self.value, str):
            # Special handling for single-digit day values in date contexts for e6 compatibility
            # If value is a single digit (1-9), pad with zero for e6 date parsing
            if self.value.isdigit() and len(self.value) == 1:
                # Pad single digit with zero for e6 date compatibility
                padded = self.value.zfill(2)
                escaped = padded.replace("'", "''")
                return f"'{escaped}'"
            else:
                # Regular string handling
                escaped = self.value.replace("'", "''")
                return f"'{escaped}'"
        elif self.value is None:
            return "NULL"
        elif isinstance(self.value, bool):
            return "TRUE" if self.value else "FALSE"
        elif isinstance(self.value, (list, tuple)):
            # Handle lists/tuples - should not be converted as a literal
            # This is likely an error case - lists should be handled by InExpression
            # Return individual elements, not the list itself
            elements = []
            for v in self.value:
                if isinstance(v, str):
                    escaped = v.replace("'", "''")
                    elements.append(f"'{escaped}'")
                elif v is None:
                    elements.append("NULL")
                else:
                    elements.append(str(v))
            # Return as comma-separated values, not as array syntax
            return ', '.join(elements)
        else:
            return str(self.value)


class BinaryExpression(Expression):
    """Binary expression (left op right)"""
    
    def __init__(self, left: Expression, operator: str, right: Expression):
        super().__init__()
        self.left = left
        self.operator = operator
        self.right = right
    
    def to_sql(self, preserve_qualifiers: bool = False) -> str:
        from ..core.sql_generator import SQLGenerator
        
        # More nuanced approach: only preserve qualifiers for qualified columns
        # when we're in a JOIN context, not in CTE column reference contexts
        # The issue is that "l.legal_entity" might be an aliased column from a previous CTE
        
        def should_preserve_qualifiers_for_expr(expr):
            # Only preserve qualifiers if this looks like a table.column reference
            # AND we're not already in preserve_qualifiers=True context
            # In CTEs, qualified column names are usually aliased column references
            if (hasattr(expr, 'name') and 
                isinstance(expr.name, str) and 
                '.' in expr.name and 
                not expr.name.startswith('"')):
                # If preserve_qualifiers is already False (CTE context),
                # don't override it for qualified column names
                return preserve_qualifiers
            return preserve_qualifiers
        
        left_preserve = should_preserve_qualifiers_for_expr(self.left)
        right_preserve = should_preserve_qualifiers_for_expr(self.right)
        
        left_sql = self.left.to_sql(left_preserve)
        right_sql = self.right.to_sql(right_preserve)
        
        sql_gen = SQLGenerator()
        return sql_gen.build_binary_expression(left_sql, self.operator, right_sql)


class UnaryExpression(Expression):
    """Unary expression (op expr)"""
    
    def __init__(self, operator: str, expression: Expression):
        super().__init__()
        self.operator = operator
        self.expression = expression
    
    def to_sql(self, preserve_qualifiers: bool = False) -> str:
        expr_sql = self.expression.to_sql(preserve_qualifiers)
        return f"{self.operator} ({expr_sql})"


class FunctionCall(Expression):
    """Function call expression"""
    
    def __init__(self, func_name: str, *args, **kwargs):
        super().__init__()
        self.func_name = func_name
        self.args = args
        self.kwargs = kwargs
    
    def to_sql(self, preserve_qualifiers: bool = False) -> str:
        from ..core.sql_generator import SQLGenerator

        # Convert arguments to SQL strings
        arg_strs = []
        for arg in self.args:
            if isinstance(arg, Expression):
                arg_strs.append(arg.to_sql(preserve_qualifiers))
            else:
                arg_strs.append(_to_expression(arg).to_sql(preserve_qualifiers))

        sql_gen = SQLGenerator()
        result = sql_gen.build_function_call(self.func_name, *arg_strs)

        # Append IGNORE NULLS for first()/last() when ignorenulls=True
        if self.kwargs.get('ignorenulls'):
            result = f"{result} IGNORE NULLS"

        return result

    def over(self, windowSpec) -> 'WindowExpression':
        """Add window specification"""
        _UNSUPPORTED_WINDOW_FUNCS = {"CORR"}
        if self.func_name.upper() in _UNSUPPORTED_WINDOW_FUNCS:
            raise NotImplementedError(
                f"{self.func_name.upper()}() is not supported as a window function by the e6data engine. "
                f"Use it as a GROUP BY aggregate instead: df.groupBy(...).agg(corr(col1, col2))"
            )
        return WindowExpression(self, windowSpec)


class StructFieldAccess(Expression):
    """Access a field of a struct column: expr.field_name"""

    def __init__(self, expr: Expression, field_name: str):
        super().__init__()
        self.expr = expr
        self.field_name = field_name

    def to_sql(self, preserve_qualifiers: bool = False) -> str:
        return f'"{self.field_name}"'


class CastExpression(Expression):
    """Cast expression"""

    def __init__(self, expression: Expression, dataType: Union[str, Any]):
        super().__init__()
        self.expression = expression
        self.dataType = dataType
    
    def to_sql(self, preserve_qualifiers: bool = False) -> str:
        from ..core.sql_generator import SQLGenerator
        
        expr_sql = self.expression.to_sql(preserve_qualifiers)
        if isinstance(self.dataType, str):
            type_sql = self.dataType
        else:
            # Handle PySpark DataType objects
            type_sql = str(self.dataType)
        
        sql_gen = SQLGenerator()
        return sql_gen.build_cast_expression(expr_sql, type_sql)


class InExpression(Expression):
    """IN expression"""
    
    def __init__(self, expression: Expression, values: tuple):
        super().__init__()
        self.expression = expression
        self.values = values
    
    def to_sql(self, preserve_qualifiers: bool = False) -> str:
        from ..core.sql_generator import SQLGenerator
        
        expr_sql = self.expression.to_sql(preserve_qualifiers)
        value_strs = []
        for val in self.values:
            value_strs.append(_to_expression(val).to_sql(preserve_qualifiers))
        
        sql_gen = SQLGenerator()
        return sql_gen.build_in_expression(expr_sql, value_strs)


class BetweenExpression(Expression):
    """BETWEEN expression"""
    
    def __init__(self, expression: Expression, lower: Any, upper: Any):
        super().__init__()
        self.expression = expression
        self.lower = lower
        self.upper = upper
    
    def to_sql(self, preserve_qualifiers: bool = False) -> str:
        from ..core.sql_generator import SQLGenerator
        
        expr_sql = self.expression.to_sql(preserve_qualifiers)
        lower_sql = _to_expression(self.lower).to_sql(preserve_qualifiers)
        upper_sql = _to_expression(self.upper).to_sql(preserve_qualifiers)
        
        sql_gen = SQLGenerator()
        return sql_gen.build_between_expression(expr_sql, lower_sql, upper_sql)


class CaseExpression(Expression):
    """CASE expression"""
    
    def __init__(self):
        super().__init__()
        self.conditions = []
        self.else_value = None
    
    def when(self, condition: Expression, value: Any) -> 'CaseExpression':
        """Add WHEN condition"""
        self.conditions.append((condition, value))
        return self
    
    def otherwise(self, value: Any) -> 'CaseExpression':
        """Add ELSE clause"""
        self.else_value = value
        return self
    
    def to_sql(self, preserve_qualifiers: bool = False) -> str:
        from ..core.sql_generator import SQLGenerator
        
        # Convert conditions to SQL strings
        condition_tuples = []
        for condition, value in self.conditions:
            cond_sql = condition.to_sql(preserve_qualifiers) if isinstance(condition, Expression) else str(condition)
            val_sql = _to_expression(value).to_sql(preserve_qualifiers)
            condition_tuples.append((cond_sql, val_sql))
        
        # Convert else value to SQL string if present
        else_sql = None
        if self.else_value is not None:
            else_sql = _to_expression(self.else_value).to_sql(preserve_qualifiers)
        
        sql_gen = SQLGenerator()
        return sql_gen.build_case_expression(condition_tuples, else_sql)


class WindowExpression(Expression):
    """Window function expression"""
    
    def __init__(self, function: FunctionCall, windowSpec):
        super().__init__()
        self.function = function
        self.windowSpec = windowSpec
    
    def to_sql(self, preserve_qualifiers: bool = False) -> str:
        from ..core.sql_generator import SQLGenerator
        
        func_sql = self.function.to_sql()
        window_sql = self.windowSpec.to_sql() if hasattr(self.windowSpec, 'to_sql') else str(self.windowSpec)
        
        sql_gen = SQLGenerator()
        return sql_gen.build_window_expression(func_sql, window_sql)


class SortExpression(Expression):
    """Sort expression with null handling"""
    
    def __init__(self, expression: Expression, direction: str, nulls: str):
        super().__init__()
        self.expression = expression
        self.direction = direction
        self.nulls = nulls
    
    def to_sql(self, preserve_qualifiers: bool = False) -> str:
        expr_sql = self.expression.to_sql(preserve_qualifiers)
        if self.nulls:
            return f"{expr_sql} {self.direction} {self.nulls}"
        else:
            return f"{expr_sql} {self.direction}"


def _to_expression(value: Any) -> Expression:
    """Convert a value to an Expression"""
    if isinstance(value, Expression):
        return value
    else:
        return LiteralExpression(value)


# Factory function
def col(name: str) -> Column:
    """Create a column reference"""
    # If the name contains a dot and looks like table.column, 
    # store it in a way that we can extract just the column name later
    # This is needed because after a JOIN, table qualifiers are not valid
    return Column(name)


def lit(value: Any) -> Expression:
    """Create a literal expression"""
    return LiteralExpression(value)


class CountDistinct(Expression):
    """
    Special expression for COUNT(DISTINCT ...) to generate proper SQL syntax
    """
    
    def __init__(self, *columns):
        super().__init__()
        self.columns = columns
        self._alias = None
    
    def to_sql(self, preserve_qualifiers: bool = False) -> str:
        # Generate COUNT(DISTINCT col1, col2, ...) not COUNT(DISTINCT(col1, col2))
        from ..core.sql_generator import SQLGenerator
        sql_gen = SQLGenerator()
        
        # Get column expressions
        col_expressions = [col.to_sql() if hasattr(col, 'to_sql') else str(col) for col in self.columns]
        
        # Build SQL using SQLGlot
        try:
            from e6_spark_compat._vendor import sqlglot as sg
            # For COUNT DISTINCT, we need to generate the expression differently
            # Parse each column expression
            col_asts = []
            for col_expr in col_expressions:
                try:
                    col_asts.append(sg.parse_one(col_expr, into=sg.exp.Expression))
                except:
                    # If parsing fails, treat as identifier
                    col_asts.append(sg.exp.Column(this=col_expr))
            
            # Create COUNT with DISTINCT modifier
            count_expr = sg.exp.Count(
                this=sg.exp.Distinct(expressions=col_asts)
            )
            
            return sql_gen.optimize_query(count_expr)
        except Exception as e:
            # Fallback to manual construction
            return f"COUNT(DISTINCT {', '.join(col_expressions)})"
    
    def alias(self, name: str) -> 'CountDistinct':
        """Add an alias to the expression"""
        self._alias = name
        return self
    
    def __str__(self):
        sql = self.to_sql()
        return f"{sql} AS {self._alias}" if self._alias else sql


class StructExpression(Expression):
    """Represents a STRUCT expression with named fields.

    Builds a SQLGlot ``exp.Struct`` AST so that the e6 dialect renders it as
    ``NAMED_STRUCT('field1', value1, 'field2', value2, ...)``.
    """

    def __init__(self, fields):
        super().__init__()
        # fields: list of (expression, field_name_or_None) tuples
        self.fields = fields

    def to_sql(self, preserve_qualifiers: bool = False) -> str:
        from ..core.sql_generator import SQLGenerator
        from e6_spark_compat._vendor import sqlglot as sg
        from e6_spark_compat._vendor.sqlglot import expressions as sgexp

        props = []
        seen_names = set()
        for i, (field_expr, field_name) in enumerate(self.fields):
            expr_sql = field_expr.to_sql(preserve_qualifiers)

            try:
                expr_ast = sg.parse_one(expr_sql, into=sgexp.Expression)
            except Exception:
                expr_ast = sgexp.Column(this=sgexp.Identifier(this=expr_sql))

            # Use provided field_name, or auto-generate _0, _1, … as fallback
            name = field_name if field_name else f"_{i}"

            if name in seen_names:
                raise ValueError(
                    f"Duplicate field name '{name}' in struct. "
                    f"Use .alias() to give distinct names."
                )
            seen_names.add(name)

            prop = sgexp.PropertyEQ(
                this=sgexp.Identifier(this=name),
                expression=expr_ast,
            )

            props.append(prop)

        struct_expr = sgexp.Struct(expressions=props)
        sql_gen = SQLGenerator()
        return sql_gen.optimize_query(struct_expr)



class RawExpression(Expression):
    """Represents a raw SQL expression that should not be quoted"""
    
    def __init__(self, expression: str):
        super().__init__()
        self.expression = expression
    
    def to_sql(self, preserve_qualifiers: bool = False) -> str:
        # Return the raw expression without quoting
        return self.expression

    def over(self, windowSpec) -> 'WindowExpression':
        """Add window specification to a raw SQL expression."""
        return WindowExpression(self, windowSpec)

    def __str__(self):
        return self.expression
    
    def __repr__(self):
        return f"RawExpression({self.expression})"


class UDFExpression(Expression):
    """Expression that translates a Python UDF to SQL via AST translation."""

    def __init__(self, func, return_type, args):
        super().__init__()
        self.func = func
        self.return_type = return_type
        self._args = args

    def to_sql(self, preserve_qualifiers: bool = False) -> str:
        from .udf_translator import ASTTranslator
        translator = ASTTranslator(self.func)
        return translator.translate(*self._args)


class UDFWrapper:
    """Callable wrapper returned by @udf decorator. Produces UDFExpression on call."""

    def __init__(self, func, returnType=None):
        self.func = func
        self.returnType = returnType

    def __call__(self, *args):
        cols = [arg if isinstance(arg, Expression) else _to_expression(arg) for arg in args]
        return UDFExpression(self.func, self.returnType, cols)


class DataFrameStarExpression(Expression):
    """
    Special expression for DataFrame["*"] syntax.
    This represents all columns from a specific DataFrame.
    """
    
    def __init__(self, dataframe):
        super().__init__()
        self.dataframe = dataframe
        self._alias = None
    
    def to_sql(self, preserve_qualifiers: bool = False) -> str:
        # When used in select, this should expand to all columns from the DataFrame
        # For now, we'll return "*" but ideally we'd track which DataFrame it came from
        return "*"
    
    def __str__(self):
        return f"DataFrameStar({self.dataframe._query_plan.__class__.__name__})"