"""
Mock I/O classes for demo/interactive use
These classes build AST nodes instead of performing actual I/O operations
"""
from typing import Optional, Dict, Any, List, Union
from ..core.query_plan import ReadOperation, WriteOperation, QueryPlan
from .dataframe import DataFrame
from .types import StructType
from ..core.logging_config import sql_logger


class MockDataFrameReader:
    """Mock DataFrameReader that builds AST nodes instead of doing actual I/O"""
    
    def __init__(self, spark_session):
        self._spark = spark_session
        self._format = None
        self._schema = None
        self._options = {}
    
    def format(self, source: str) -> 'MockDataFrameReader':
        """Set the input format"""
        self._format = source.lower()
        return self
    
    def schema(self, schema: Union[StructType, str]) -> 'MockDataFrameReader':
        """Set the schema"""
        self._schema = schema
        return self
    
    def option(self, key: str, value: Any) -> 'MockDataFrameReader':
        """Set a single option"""
        self._options[key] = value
        return self
    
    def options(self, **options) -> 'MockDataFrameReader':
        """Set multiple options"""
        self._options.update(options)
        return self
    
    def load(self, path: str = None, format: str = None, schema: StructType = None,
             **options) -> DataFrame:
        """Create ReadOperation AST node instead of loading actual data"""
        if format:
            self._format = format
        if schema:
            self._schema = schema
        if options:
            self._options.update(options)
        
        if not self._format:
            # Try to infer format from path
            if path:
                if path.endswith('.parquet'):
                    self._format = 'parquet'
                elif path.endswith('.orc'):
                    self._format = 'orc'
                elif path.endswith('.csv'):
                    self._format = 'csv'
                elif path.endswith('.json') or path.endswith('.jsonl'):
                    self._format = 'json'
                else:
                    self._format = 'parquet'  # Default
        
        # Create ReadOperation AST node
        read_plan = ReadOperation(
            format_type=self._format,
            path=path or '/mock/path',
            options=self._options.copy()
        )
        
        return DataFrame(self._spark._connection, read_plan)
    
    def table(self, tableName: str) -> DataFrame:
        """Create table reference - delegate to actual implementation"""
        from ..core.query_plan import TableScan
        plan = TableScan(tableName)
        return DataFrame(self._spark._connection, plan)
    
    # Format-specific convenience methods
    def parquet(self, *paths: str) -> DataFrame:
        """Create ReadOperation for Parquet files"""
        self._format = 'parquet'
        if len(paths) == 1:
            return self.load(paths[0])
        else:
            # Multiple paths - create union of ReadOperations
            dfs = [self.load(path) for path in paths]
            result = dfs[0]
            for df in dfs[1:]:
                result = result.union(df)
            return result
    
    def orc(self, *paths: str) -> DataFrame:
        """Create ReadOperation for ORC files"""
        self._format = 'orc'
        if len(paths) == 1:
            return self.load(paths[0])
        else:
            dfs = [self.load(path) for path in paths]
            result = dfs[0]
            for df in dfs[1:]:
                result = result.union(df)
            return result
    
    def csv(self, *paths: str, sep: str = None, encoding: str = None, quote: str = None,
            escape: str = None, comment: str = None, header: bool = None, inferSchema: bool = None,
            ignoreLeadingWhiteSpace: bool = None, ignoreTrailingWhiteSpace: bool = None,
            nullValue: str = None, nanValue: str = None, positiveInf: str = None,
            negativeInf: str = None, dateFormat: str = None, timestampFormat: str = None,
            maxColumns: int = None, maxCharsPerColumn: int = None, mode: str = None,
            columnNameOfCorruptRecord: str = None, multiLine: bool = None) -> DataFrame:
        """Create ReadOperation for CSV files"""
        self._format = 'csv'
        
        # Set CSV-specific options
        if sep is not None:
            self.option("sep", sep)
        if encoding is not None:
            self.option("encoding", encoding)
        if quote is not None:
            self.option("quote", quote)
        if escape is not None:
            self.option("escape", escape)
        if comment is not None:
            self.option("comment", comment)
        if header is not None:
            self.option("header", str(header).lower())
        if inferSchema is not None:
            self.option("inferSchema", str(inferSchema).lower())
        if nullValue is not None:
            self.option("nullValue", nullValue)
        if dateFormat is not None:
            self.option("dateFormat", dateFormat)
        if timestampFormat is not None:
            self.option("timestampFormat", timestampFormat)
        if multiLine is not None:
            self.option("multiLine", str(multiLine).lower())
        
        if len(paths) == 1:
            return self.load(paths[0])
        else:
            dfs = [self.load(path) for path in paths]
            result = dfs[0]
            for df in dfs[1:]:
                result = result.union(df)
            return result
    
    def json(self, *paths: str, schema: StructType = None, primitivesAsString: bool = None,
             prefersDecimal: bool = None, allowComments: bool = None, allowUnquotedFieldNames: bool = None,
             allowSingleQuotes: bool = None, allowNumericLeadingZero: bool = None,
             allowBackslashEscapingAnyCharacter: bool = None, mode: str = None,
             columnNameOfCorruptRecord: str = None, dateFormat: str = None,
             timestampFormat: str = None, multiLine: bool = None) -> DataFrame:
        """Create ReadOperation for JSON files"""
        self._format = 'json'
        
        if schema is not None:
            self.schema(schema)
        if multiLine is not None:
            self.option("multiLine", str(multiLine).lower())
        if dateFormat is not None:
            self.option("dateFormat", dateFormat)
        if timestampFormat is not None:
            self.option("timestampFormat", timestampFormat)
        if mode is not None:
            self.option("mode", mode)
        
        if len(paths) == 1:
            return self.load(paths[0])
        else:
            dfs = [self.load(path) for path in paths]
            result = dfs[0]
            for df in dfs[1:]:
                result = result.union(df)
            return result
    
    def text(self, *paths: str, wholetext: bool = False) -> DataFrame:
        """Create ReadOperation for text files"""
        self._format = 'text'
        
        if wholetext:
            self.option("wholetext", "true")
        
        if len(paths) == 1:
            return self.load(paths[0])
        else:
            dfs = [self.load(path) for path in paths]
            result = dfs[0]
            for df in dfs[1:]:
                result = result.union(df)
            return result
    
    def jdbc(self, url: str, table: str, column: str = None, lowerBound: int = None,
             upperBound: int = None, numPartitions: int = None, predicates: List[str] = None,
             properties: Dict[str, str] = None) -> DataFrame:
        """Create ReadOperation for JDBC source"""
        self._format = 'jdbc'
        self.option("url", url)
        self.option("dbtable", table)
        
        if properties:
            self.options(**properties)
        
        return self.load()


class MockDataFrameWriter:
    """Mock DataFrameWriter that builds AST nodes instead of doing actual I/O"""
    
    def __init__(self, connection, query_plan: QueryPlan):
        self._connection = connection
        self._query_plan = query_plan
        self._mode = "overwrite"  # overwrite, append, error, ignore
        self._format = None
        self._options = {}
        self._partition_by = []
        self._bucket_by = None
        self._sort_by = []
        self._path = None
        self._table_name = None
    
    def mode(self, saveMode: str) -> 'MockDataFrameWriter':
        """Set write mode"""
        self._mode = saveMode.lower()
        return self
    
    def format(self, source: str) -> 'MockDataFrameWriter':
        """Set output format"""
        self._format = source.lower()
        return self
    
    def option(self, key: str, value: Any) -> 'MockDataFrameWriter':
        """Set a write option"""
        self._options[key] = value
        return self
    
    def options(self, **options) -> 'MockDataFrameWriter':
        """Set multiple write options"""
        self._options.update(options)
        return self
    
    def partitionBy(self, *cols: str) -> 'MockDataFrameWriter':
        """Set partition columns"""
        self._partition_by = list(cols)
        return self
    
    def bucketBy(self, numBuckets: int, col: str, *cols: str) -> 'MockDataFrameWriter':
        """Set bucketing"""
        self._bucket_by = (numBuckets, [col] + list(cols))
        return self
    
    def sortBy(self, col: str, *cols: str) -> 'MockDataFrameWriter':
        """Set sort columns within partitions"""
        self._sort_by = [col] + list(cols)
        return self
    
    def save(self, path: str = None) -> DataFrame:
        """Create WriteOperation AST node for save operation"""
        if path:
            self._path = path
        
        if not self._path:
            raise ValueError("Path is required for save operation")
        
        # Infer format from path if not set
        if not self._format:
            if self._path.endswith('.parquet'):
                self._format = 'parquet'
            elif self._path.endswith('.csv'):
                self._format = 'csv'
            elif self._path.endswith('.json'):
                self._format = 'json'
            elif self._path.endswith('.orc'):
                self._format = 'orc'
            else:
                self._format = 'parquet'  # Default
        
        write_plan = WriteOperation(
            child=self._query_plan,
            operation_type=self._format,
            target=self._path,
            mode=self._mode,
            options=self._options.copy(),
            partition_by=self._partition_by.copy()
        )
        
        return DataFrame(self._connection, write_plan)
    
    def insertInto(self, tableName: str, overwrite: bool = None) -> DataFrame:
        """Create WriteOperation AST node for insertInto operation"""
        if overwrite is not None:
            mode = "overwrite" if overwrite else "append"
        else:
            mode = self._mode
        
        write_plan = WriteOperation(
            child=self._query_plan,
            operation_type='insertInto',
            target=tableName,
            mode=mode,
            options=self._options.copy(),
            partition_by=self._partition_by.copy()
        )
        
        return DataFrame(self._connection, write_plan)
    
    def saveAsTable(self, name: str, format: str = None, mode: str = None,
                    partitionBy: List[str] = None, **options) -> DataFrame:
        """Create WriteOperation AST node for saveAsTable operation"""
        if format:
            self._format = format
        if mode:
            self._mode = mode
        if partitionBy:
            self._partition_by = partitionBy
        if options:
            self._options.update(options)
        
        write_plan = WriteOperation(
            child=self._query_plan,
            operation_type='saveAsTable',
            target=name,
            mode=self._mode,
            options=self._options.copy(),
            partition_by=self._partition_by.copy()
        )
        
        return DataFrame(self._connection, write_plan)
    
    # Format-specific convenience methods
    def parquet(self, path: str, mode: str = None, partitionBy: List[str] = None,
                compression: str = None) -> DataFrame:
        """Create WriteOperation AST node for Parquet output"""
        if mode:
            self._mode = mode
        if partitionBy:
            self._partition_by = partitionBy
        if compression:
            self.option("compression", compression)
        
        write_plan = WriteOperation(
            child=self._query_plan,
            operation_type='parquet',
            target=path,
            mode=self._mode,
            options=self._options.copy(),
            partition_by=self._partition_by.copy()
        )
        
        return DataFrame(self._connection, write_plan)
    
    def orc(self, path: str, mode: str = None, partitionBy: List[str] = None,
            compression: str = None) -> DataFrame:
        """Create WriteOperation AST node for ORC output"""
        if mode:
            self._mode = mode
        if partitionBy:
            self._partition_by = partitionBy
        if compression:
            self.option("compression", compression)
        
        write_plan = WriteOperation(
            child=self._query_plan,
            operation_type='orc',
            target=path,
            mode=self._mode,
            options=self._options.copy(),
            partition_by=self._partition_by.copy()
        )
        
        # Print the final SQL for demonstration
        final_sql = write_plan.to_sql()
        sql_logger.info(f"FINAL SQL QUERY GENERATED: {final_sql}")
        
        return DataFrame(self._connection, write_plan)
    
    def csv(self, path: str, mode: str = None, compression: str = None, sep: str = None,
            quote: str = None, escape: str = None, header: bool = None, 
            nullValue: str = None, dateFormat: str = None, timestampFormat: str = None) -> DataFrame:
        """Create WriteOperation AST node for CSV output"""
        if mode:
            self._mode = mode
        if compression:
            self.option("compression", compression)
        if sep:
            self.option("sep", sep)
        if quote:
            self.option("quote", quote)
        if escape:
            self.option("escape", escape)
        if header is not None:
            self.option("header", str(header).lower())
        if nullValue:
            self.option("nullValue", nullValue)
        if dateFormat:
            self.option("dateFormat", dateFormat)
        if timestampFormat:
            self.option("timestampFormat", timestampFormat)
        
        write_plan = WriteOperation(
            child=self._query_plan,
            operation_type='csv',
            target=path,
            mode=self._mode,
            options=self._options.copy(),
            partition_by=self._partition_by.copy()
        )
        
        return DataFrame(self._connection, write_plan)
    
    def json(self, path: str, mode: str = None, compression: str = None,
             dateFormat: str = None, timestampFormat: str = None) -> DataFrame:
        """Create WriteOperation AST node for JSON output"""
        if mode:
            self._mode = mode
        if compression:
            self.option("compression", compression)
        if dateFormat:
            self.option("dateFormat", dateFormat)
        if timestampFormat:
            self.option("timestampFormat", timestampFormat)
        
        write_plan = WriteOperation(
            child=self._query_plan,
            operation_type='json',
            target=path,
            mode=self._mode,
            options=self._options.copy(),
            partition_by=self._partition_by.copy()
        )
        
        return DataFrame(self._connection, write_plan)


def create_mock_dataframe_with_writer(df: DataFrame) -> DataFrame:
    """Create a DataFrame with MockDataFrameWriter instead of regular DataFrameWriter"""
    # Replace the write property with mock writer
    mock_writer = MockDataFrameWriter(df._connection, df._query_plan)
    df._mock_write = mock_writer
    return df