"""
Recursive AST-based UDF translator: converts Python functions to SQL expressions.

Supports: simple returns, assignments, arithmetic, comparisons,
if/else → CASE WHEN, and datetime operations (strptime, weekday, timedelta,
strftime, date arithmetic).
"""
import ast
import datetime as _dt
import inspect
import re
import textwrap
from dataclasses import dataclass
from enum import Enum, auto
from typing import Any, Callable, Dict, List, Optional, Tuple


# ---------------------------------------------------------------------------
# TypedSQL -- lightweight IR: SQL string + inferred Python type
# ---------------------------------------------------------------------------

class TypedSQL(str):
    """SQL expression fragment paired with its inferred Python type."""

    inferred_type: Optional[type]

    def __new__(cls, sql: str, inferred_type: Optional[type] = None):
        instance = super().__new__(cls, sql)
        instance.inferred_type = inferred_type
        return instance

    @property
    def sql(self) -> str:
        return str.__str__(self)

    def __repr__(self) -> str:
        return f"TypedSQL(sql={str.__repr__(self)}, inferred_type={self.inferred_type!r})"


class UntranslatableUDFError(Exception):
    """Raised when a UDF cannot be translated to SQL."""
    pass


# ---------------------------------------------------------------------------
# BodyResult -- structured output from body translation
# ---------------------------------------------------------------------------

class BodyAction(Enum):
    RETURN = auto()
    NULL = auto()


@dataclass
class BodyResult:
    action: BodyAction
    expr: Optional[TypedSQL] = None


# ---------------------------------------------------------------------------
# Constants
# ---------------------------------------------------------------------------

_PRECEDENCE: Dict[str, int] = {
    "OR": 1, "AND": 2, "NOT": 3,
    "=": 4, "!=": 4, "<": 4, "<=": 4, ">": 4, ">=": 4,
    "IS": 4, "IS NOT": 4, "IN": 4, "NOT IN": 4,
    "+": 5, "-": 5, "*": 6, "/": 6, "%": 6,
}

_MISSING = object()

_BINOP_MAP = {
    ast.Add: "+", ast.Sub: "-", ast.Mult: "*", ast.Div: "/", ast.Mod: "%",
}

_CMPOP_MAP = {
    ast.Eq: "=", ast.NotEq: "!=", ast.Lt: "<", ast.LtE: "<=",
    ast.Gt: ">", ast.GtE: ">=",
}


# ---------------------------------------------------------------------------
# ASTTranslator
# ---------------------------------------------------------------------------

class ASTTranslator:
    """Translates a Python function to a SQL expression string.

    Currently supports:
    - Simple returns, literals, variables, arithmetic
    - Assignments and augmented assignments
    - If/elif/else → CASE WHEN
    - Datetime: strptime, date, weekday, timedelta, strftime, date arithmetic
    """

    def __init__(self, func_or_source, externals: Optional[Dict[str, Any]] = None):
        """Create a translator from a function object or a source string.

        Usage:
            ASTTranslator(my_func)              # from a live function
            ASTTranslator('''def f(x): ...''')  # from source code
        """
        self._externals: Dict[str, Any] = externals or {}

        if callable(func_or_source):
            self.func = func_or_source
            self._ast_node = self._parse_function()
        elif isinstance(func_or_source, str):
            self.func = None
            self._ast_node = self._parse_source(func_or_source)
        else:
            raise UntranslatableUDFError(
                "Expected a callable or source string"
            )

        self._params, self._defaults = self._extract_params()
        self._type_hints: Dict[str, type] = self._extract_type_hints()

    # -- Parsing helpers ------------------------------------------------------
    # parse function
    def _parse_function(self) -> ast.AST:
        source = inspect.getsource(self.func)
        source = textwrap.dedent(source)
        return self._find_func_node(ast.parse(source))
    # parse function in string 
    def _parse_source(self, source: str) -> ast.AST:
        source = textwrap.dedent(source)
        return self._find_func_node(ast.parse(source))

    @staticmethod
    def _find_func_node(tree: ast.Module) -> ast.AST:
        '''extracting the meaningful part of the tree for parsing that is the function definitions/ lambda operations from here we strt the sql construction'''
        for node in ast.walk(tree):
            if isinstance(node, ast.Lambda):
                return node
            if isinstance(node, ast.FunctionDef):
                return node
        raise UntranslatableUDFError(
            "Could not find function or lambda definition in source"
        )

    def _extract_params(self) -> Tuple[List[str], Dict[str, ast.expr]]:
        args = self._ast_node.args
        # not acceting variable arguments
        if args.vararg:
            raise UntranslatableUDFError("*args cannot be translated to SQL")
        if args.kwarg:
            raise UntranslatableUDFError("**kwargs cannot be translated to SQL")
        param_names = [arg.arg for arg in args.args]
        defaults: Dict[str, ast.expr] = {}
        num_defaults = len(args.defaults)
        # assigning default values 
        if num_defaults:
            defaulted_params = param_names[-num_defaults:]
            for pname, default_node in zip(defaulted_params, args.defaults):
                defaults[pname] = default_node
        return param_names, defaults

    def _extract_type_hints(self) -> Dict[str, type]:
        #creates mapping for understanding the data type for binary and other operations
        hints: Dict[str, type] = {}
        if not isinstance(self._ast_node, ast.FunctionDef):
            return hints
        type_map = {"str": str, "int": int, "float": float, "bool": bool,
                     "list": list, "dict": dict, "tuple": tuple}
        for arg in self._ast_node.args.args:
            if arg.annotation and isinstance(arg.annotation, ast.Name):
                if arg.annotation.id in type_map:
                    hints[arg.arg] = type_map[arg.annotation.id]
        return hints

    # -- Public API -----------------------------------------------------------

    def translate(self, *args: Any) -> str:
        num_required = len(self._params) - len(self._defaults)
        if not self._defaults:
            if len(args) != len(self._params):
                raise UntranslatableUDFError(
                    f"Expected {len(self._params)} arguments, got {len(args)}"
                )
        else:
            if len(args) < num_required:
                raise UntranslatableUDFError(
                    f"Expected at least {num_required} arguments, got {len(args)}"
                )
            if len(args) > len(self._params):
                raise UntranslatableUDFError(
                    f"Expected at most {len(self._params)} arguments, got {len(args)}"
                )

        pm: Dict[str, TypedSQL] = {}
        for i, param_name in enumerate(self._params):
            if i < len(args):
                arg = args[i]
                sql = arg.to_sql() if hasattr(arg, "to_sql") else str(arg)
                inferred = self._type_hints.get(param_name)
                pm[param_name] = TypedSQL(sql, inferred)
            elif param_name in self._defaults:
                pm[param_name] = self._visit(self._defaults[param_name], pm)
            else:
                raise UntranslatableUDFError(
                    f"No value provided for required parameter '{param_name}'"
                )

        if isinstance(self._ast_node, ast.FunctionDef):
            result = self._translate_body(self._ast_node.body, pm)
        else:
            return self._visit(self._ast_node.body, pm).sql

        return self._body_result_to_sql(result, pm)

    def _body_result_to_sql(self, result: BodyResult,
                            pm: Dict[str, TypedSQL]) -> str:
        if result.action == BodyAction.RETURN:
            return result.expr.sql
        if result.action == BodyAction.NULL:
            return "NULL"
        raise UntranslatableUDFError("Function must end with a return statement")

    # ======================================================================
    # CENTRAL DISPATCHER
    # ======================================================================

    def _translate_body(
        self,
        stmts: List[ast.stmt],
        pm: Dict[str, TypedSQL],
    ) -> BodyResult:
        pm = dict(pm)

        for i, stmt in enumerate(stmts):
            remaining = stmts[i + 1:]

            # --- Assignments ---
            if isinstance(stmt, ast.Assign):
                self._handle_assign(stmt, pm)
                continue

            if isinstance(stmt, ast.AugAssign):
                self._handle_aug_assign(stmt, pm)
                continue

            # --- Bare expressions (docstrings, etc.) ---
            if isinstance(stmt, ast.Expr):
                # Handle list mutation statements: lst.append(x), lst.insert(0, x)
                if (isinstance(stmt.value, ast.Call)
                        and isinstance(stmt.value.func, ast.Attribute)):
                    self._handle_list_mutation(stmt.value, pm)
                continue

            if isinstance(stmt, ast.Pass):
                continue

            # --- Imports (e.g. `import re`, `from datetime import ...`) ---
            if isinstance(stmt, (ast.Import, ast.ImportFrom)):
                continue

            # --- Return ---
            if isinstance(stmt, ast.Return):
                expr = self._visit(stmt.value, pm)
                return BodyResult(action=BodyAction.RETURN, expr=expr)

            # --- If/elif/else ---
            if isinstance(stmt, ast.If):
                # Pattern: if only modifies variables → conditional update, continue
                if self._if_only_assigns(stmt) and remaining:
                    self._handle_conditional_assign(stmt, pm)
                    continue
                # Pattern: if cond: return a; return b (no else, trailing return)
                if (not stmt.orelse and remaining
                        and isinstance(remaining[-1], ast.Return)):
                    return self._handle_if_with_trailing_return(
                        stmt, remaining, pm
                    )
                # Pattern: if/elif/else assigns to var, then return var
                if (stmt.orelse and remaining
                        and isinstance(remaining[-1], ast.Return)
                        and isinstance(remaining[-1].value, ast.Name)):
                    ret_var = remaining[-1].value.id
                    if self._all_branches_assign_to(stmt, ret_var):
                        return self._build_assign_case_when(
                            stmt, pm, ret_var
                        )
                return self._handle_if(stmt, pm)

            raise UntranslatableUDFError(
                f"Unsupported statement type: {stmt.__class__.__name__}"
            )

        # Fell through — all statements were assignments/pass/etc.
        if all(isinstance(s, (ast.Pass, ast.Expr, ast.Assign, ast.AugAssign))
               for s in stmts):
            return BodyResult(action=BodyAction.NULL)

        raise UntranslatableUDFError("Function must end with a return statement")

    # ======================================================================
    # ASSIGNMENTS
    # ======================================================================

    def _handle_assign(self, stmt, pm):
        if len(stmt.targets) == 1 and isinstance(stmt.targets[0], ast.Name):
            var_name = stmt.targets[0].id # variable name
            val = self._visit(stmt.value, pm) # variable value
            if isinstance(stmt.value, ast.BinOp) and val.inferred_type is not _dt.timedelta:
                val = TypedSQL(f"({val.sql})", val.inferred_type)
            pm[var_name] = val
        elif (len(stmt.targets) == 1
              and isinstance(stmt.targets[0], ast.Tuple)
              and isinstance(stmt.value, ast.Tuple)):
            names = stmt.targets[0].elts
            values = stmt.value.elts
            if len(names) != len(values):
                raise UntranslatableUDFError(
                    f"Tuple unpacking length mismatch: "
                    f"{len(names)} targets vs {len(values)} values"
                )
            for name_node, val_node in zip(names, values):
                if not isinstance(name_node, ast.Name):
                    raise UntranslatableUDFError(
                        "Only simple variable names supported in tuple unpacking"
                    )
                val = self._visit(val_node, pm)
                if isinstance(val_node, ast.BinOp):
                    val = TypedSQL(f"({val.sql})", val.inferred_type)
                pm[name_node.id] = val
        else:
            raise UntranslatableUDFError("Only simple variable assignments are supported")

    def _handle_aug_assign(self, stmt, pm):
        if not isinstance(stmt.target, ast.Name):
            raise UntranslatableUDFError(
                "Only simple variable augmented assignments are supported"
            )   
        var_name = stmt.target.id # variable name
        old = pm.get(var_name, TypedSQL(var_name)) # checks for previous assginments
        new_val = self._visit(stmt.value, pm) # finds and assigns new value
        op_type = type(stmt.op) # operator for the assignment
        lhs = f"({old.sql})" if " " in old.sql else old.sql # handles wront assignment like when x*=a+b doesnt become a+b*c
        # creation of the operator method
        if op_type is ast.Mod:
            result_type = self._infer_binop_type(
                old.inferred_type, new_val.inferred_type, op_type
            )
            pm[var_name] = TypedSQL(
                f"MOD(MOD({lhs}, {new_val.sql}) + ({new_val.sql}), {new_val.sql})",
                result_type,
            )
        elif op_type is ast.FloorDiv:
            pm[var_name] = TypedSQL(f"FLOOR({lhs} / {new_val.sql})", int)
        elif op_type is ast.Pow:
            pm[var_name] = TypedSQL(f"POWER({lhs}, {new_val.sql})", float)
        elif op_type in _BINOP_MAP:
            op_str = _BINOP_MAP[op_type]
            result_type = self._infer_binop_type(
                old.inferred_type, new_val.inferred_type, op_type
            )
            pm[var_name] = TypedSQL(f"{lhs} {op_str} {new_val.sql}", result_type)
        else:
            raise UntranslatableUDFError(
                f"Unsupported augmented assignment operator: {op_type.__name__}"
            )

    # ======================================================================
    # LIST MUTATIONS (statement-level: lst.append(x), lst.insert(0, x))
    # ======================================================================

    def _handle_list_mutation(self, call_node, pm):
        """Handle list mutation statements: lst.append(x), lst.insert(0, x)."""
        attr = call_node.func.attr
        obj_node = call_node.func.value

        # Only handle if the object is a known list variable
        if not isinstance(obj_node, ast.Name):
            return
        var_name = obj_node.id
        if var_name not in pm or pm[var_name].inferred_type is not list:
            return

        obj = pm[var_name]

        # lst.append(x) → ARRAY_APPEND(arr, x)
        if attr == 'append' and len(call_node.args) == 1:
            elem = self._visit(call_node.args[0], pm)
            pm[var_name] = TypedSQL(f"ARRAY_APPEND({obj.sql}, {elem.sql})", list)
            return

        # lst.insert(0, x) → ARRAY_PREPEND(arr, x)
        if attr == 'insert' and len(call_node.args) == 2:
            idx = call_node.args[0]
            if isinstance(idx, ast.Constant) and idx.value == 0:
                elem = self._visit(call_node.args[1], pm)
                pm[var_name] = TypedSQL(f"ARRAY_PREPEND({obj.sql}, {elem.sql})", list)
                return
            raise UntranslatableUDFError(
                "list.insert() only supported with index 0 (prepend)"
            )

    # ======================================================================
    # IF / ELIF / ELSE → CASE WHEN
    # ======================================================================

    def _handle_if(
        self,
        node: ast.If,
        pm: Dict[str, TypedSQL],
    ) -> BodyResult:
        """Handle if/elif/else → CASE WHEN expressions."""
        return self._build_case_when(node, pm)

    def _build_case_when(
        self,
        node: ast.If,
        pm: Dict[str, TypedSQL],
    ) -> BodyResult:
        """Build a CASE WHEN expression from if/elif/else."""
        parts: List[str] = []
        result_type: Optional[type] = None
        current = node

        while True:
            cond = self._to_boolean_condition(self._visit(current.test, pm))
            body_result = self._translate_body(current.body, pm)
            body_val = body_result.expr if body_result.expr else TypedSQL("NULL")
            if result_type is None:
                result_type = body_val.inferred_type
            parts.append(f"WHEN {cond.sql} THEN {body_val.sql}")
            # only one if 
            if not current.orelse:
                parts.append("ELSE NULL")
                break
            # handeling elif
            elif (len(current.orelse) == 1
                  and isinstance(current.orelse[0], ast.If)):
                current = current.orelse[0]
            # handeling the last else 
            else:
                else_result = self._translate_body(current.orelse, pm)
                else_val = else_result.expr if else_result.expr else TypedSQL("NULL")
                parts.append(f"ELSE {else_val.sql}")
                break

        expr = TypedSQL(f"CASE {' '.join(parts)} END", result_type)
        return BodyResult(action=BodyAction.RETURN, expr=expr)

    def _handle_if_with_trailing_return(
        self,
        if_node: ast.If,
        remaining: List[ast.stmt],
        pm: Dict[str, TypedSQL],
    ) -> BodyResult:
        """Handle: if cond: return a; return b → CASE WHEN ... ELSE ... END"""
        cond = self._to_boolean_condition(self._visit(if_node.test, pm))
        then_result = self._translate_body(if_node.body, pm)
        then_val = then_result.expr if then_result.expr else TypedSQL("NULL")

        return_stmt = remaining[-1]
        else_val = self._visit(return_stmt.value, pm)

        expr = TypedSQL(
            f"CASE WHEN {cond.sql} THEN {then_val.sql} ELSE {else_val.sql} END",
            then_val.inferred_type,
        )
        return BodyResult(action=BodyAction.RETURN, expr=expr)

    def _if_only_assigns(self, if_node: ast.If) -> bool:
        """Check if an if block (and its else) only contains assignments."""
        for stmt in if_node.body:
            if not isinstance(stmt, (ast.Assign, ast.AugAssign)):
                return False
        if if_node.orelse:
            for stmt in if_node.orelse:
                if isinstance(stmt, ast.If):
                    if not self._if_only_assigns(stmt):
                        return False
                elif not isinstance(stmt, (ast.Assign, ast.AugAssign)):
                    return False
        return True

    def _handle_conditional_assign(self, if_node: ast.If,
                                    pm: Dict[str, TypedSQL]) -> None:
        """Handle if/elif/else that only modifies variables → update pm with CASE WHEN."""
        cond = self._to_boolean_condition(self._visit(if_node.test, pm))
        orig_pm = dict(pm)

        # Process if-body in a copy
        then_pm = dict(pm)
        for stmt in if_node.body:
            if isinstance(stmt, ast.Assign):
                self._handle_assign(stmt, then_pm)
            elif isinstance(stmt, ast.AugAssign):
                self._handle_aug_assign(stmt, then_pm)

        # Process else-body in a copy
        else_pm = dict(pm)
        if if_node.orelse:
            for stmt in if_node.orelse:
                if isinstance(stmt, ast.If):
                    self._handle_conditional_assign(stmt, else_pm)
                elif isinstance(stmt, ast.Assign):
                    self._handle_assign(stmt, else_pm)
                elif isinstance(stmt, ast.AugAssign):
                    self._handle_aug_assign(stmt, else_pm)

        # Build CASE WHEN for each modified variable
        # new temp/modified variables
        modified_vars = set()
        for var in then_pm:
            if var not in orig_pm or then_pm[var].sql != orig_pm[var].sql:
                modified_vars.add(var)
        for var in else_pm:
            if var not in orig_pm or else_pm[var].sql != orig_pm[var].sql:
                modified_vars.add(var)

        for var in modified_vars:
            then_val = then_pm.get(var, TypedSQL("NULL"))
            else_val = else_pm.get(var, orig_pm.get(var, TypedSQL("NULL")))
            pm[var] = TypedSQL(
                f"CASE WHEN {cond.sql} THEN {then_val.sql} ELSE {else_val.sql} END",
                then_val.inferred_type,
            )

    def _all_branches_assign_to(self, if_node: ast.If, var_name: str) -> bool:
        """Check if all branches of an if/elif/else assign to var_name."""
        current = if_node
        while True:
            if not self._branch_has_assign_to(current.body, var_name):
                return False
            if not current.orelse:
                return False
            if (len(current.orelse) == 1
                    and isinstance(current.orelse[0], ast.If)):
                current = current.orelse[0]
            else:
                return self._branch_has_assign_to(current.orelse, var_name)

    @staticmethod
    def _branch_has_assign_to(stmts: List[ast.stmt], var_name: str) -> bool:
        """Check if stmts contain an assignment to var_name."""
        for stmt in stmts:
            if (isinstance(stmt, ast.Assign)
                    and len(stmt.targets) == 1
                    and isinstance(stmt.targets[0], ast.Name)
                    and stmt.targets[0].id == var_name):
                return True
        return False

    def _build_assign_case_when(
        self,
        if_node: ast.If,
        pm: Dict[str, TypedSQL],
        ret_var: str,
    ) -> BodyResult:
        """Build CASE WHEN from if/elif/else that assigns to a variable.

        Pattern: if c1: v=e1; elif c2: v=e2; else: v=e3; return v
        → CASE WHEN c1 THEN e1 WHEN c2 THEN e2 ELSE e3 END
        """
        parts: List[str] = []
        result_type: Optional[type] = None
        current = if_node

        while True:
            cond = self._to_boolean_condition(self._visit(current.test, pm))
            val = self._extract_branch_assign_value(current.body, ret_var, pm)
            if result_type is None:
                result_type = val.inferred_type
            parts.append(f"WHEN {cond.sql} THEN {val.sql}")

            if not current.orelse:
                parts.append("ELSE NULL")
                break
            elif (len(current.orelse) == 1
                  and isinstance(current.orelse[0], ast.If)):
                current = current.orelse[0]
            else:
                val = self._extract_branch_assign_value(
                    current.orelse, ret_var, pm
                )
                parts.append(f"ELSE {val.sql}")
                break

        expr = TypedSQL(f"CASE {' '.join(parts)} END", result_type)
        return BodyResult(action=BodyAction.RETURN, expr=expr)

    def _extract_branch_assign_value(
        self,
        stmts: List[ast.stmt],
        var_name: str,
        pm: Dict[str, TypedSQL],
    ) -> TypedSQL:
        """Extract the value assigned to var_name in a branch body."""
        inner_pm = dict(pm)
        result = TypedSQL("NULL")
        for stmt in stmts:
            if (isinstance(stmt, ast.Assign)
                    and len(stmt.targets) == 1
                    and isinstance(stmt.targets[0], ast.Name)):
                val = self._visit(stmt.value, inner_pm)
                inner_pm[stmt.targets[0].id] = val
                if stmt.targets[0].id == var_name:
                    result = val
        return result

    def _to_boolean_condition(self, expr: TypedSQL) -> TypedSQL:
        """Ensure an expression is boolean for use in CASE WHEN conditions."""
        t = expr.inferred_type
        if t is bool or t is None:
            return expr
        if t is int or t is float:
            return TypedSQL(f"({expr.sql} != 0)", bool)
        if t is str:
            return TypedSQL(f"({expr.sql} IS NOT NULL AND {expr.sql} != '')", bool)
        if t is list:
            return TypedSQL(f"(SIZE({expr.sql}) > 0)", bool)
        return expr

    # ======================================================================
    # EXPRESSION VISITORS
    # ======================================================================

    def _visit(self, node: ast.AST, pm: Dict[str, TypedSQL]) -> TypedSQL:
        node_type = node.__class__.__name__
        visitor = getattr(self, f"_visit_{node_type}", None)
        if visitor is not None:
            return visitor(node, pm)
        raise UntranslatableUDFError(f"Unsupported AST node type: {node_type}")

    def _visit_Constant(self, node, pm):
        return self._translate_constant(node.value)

    def _visit_Name(self, node, pm):
        if node.id in pm:
            return pm[node.id]
        resolved = self._resolve_external(node.id)
        if resolved is not None:
            return resolved
        raise UntranslatableUDFError(
            f"Reference to external variable '{node.id}' cannot be translated to SQL"
        )

    def _visit_BinOp(self, node, pm):
        op_type = type(node.op)
        left = self._visit(node.left, pm)
        right = self._visit(node.right, pm)

        if op_type is ast.FloorDiv:
            return TypedSQL(f"FLOOR({left.sql} / {right.sql})", int)
        if op_type is ast.Pow:
            return TypedSQL(f"POWER({left.sql}, {right.sql})", float)
        if op_type is ast.Mod:
            result_type = self._infer_binop_type(
                left.inferred_type, right.inferred_type, op_type
            )
            return TypedSQL(
                f"MOD(MOD({left.sql}, {right.sql}) + ({right.sql}), {right.sql})",
                result_type,
            )
        # Date arithmetic: date +/- timedelta
        if (left.inferred_type in (_dt.date, _dt.datetime)
                and right.inferred_type is _dt.timedelta):
            unit = getattr(right, 'unit', 'DAY')
            if unit == "DAY":
                if op_type is ast.Add:
                    return TypedSQL(f"DATE_ADD({left.sql}, {right.sql})", _dt.date)
                if op_type is ast.Sub:
                    return TypedSQL(f"DATE_SUB({left.sql}, {right.sql})", _dt.date)
            elif unit == "MONTH":
                if op_type is ast.Add:
                    return TypedSQL(f"ADD_MONTHS({left.sql}, {right.sql})", _dt.date)
                if op_type is ast.Sub:
                    return TypedSQL(f"ADD_MONTHS({left.sql}, -({right.sql}))", _dt.date)
            else:  # HOUR, MINUTE, SECOND
                sign = "" if op_type is ast.Add else "-"
                return TypedSQL(
                    f"TIMESTAMP_ADD({unit}, {sign}({right.sql}), {left.sql})",
                    _dt.datetime,
                )
        if (op_type is ast.Add
                and right.inferred_type in (_dt.date, _dt.datetime)
                and left.inferred_type in (_dt.timedelta, int, float)):
            unit = getattr(left, 'unit', 'DAY')
            if unit == "DAY":
                return TypedSQL(f"DATE_ADD({right.sql}, {left.sql})", _dt.date)
            elif unit == "MONTH":
                return TypedSQL(f"ADD_MONTHS({right.sql}, {left.sql})", _dt.date)
            else:  # HOUR, MINUTE, SECOND
                return TypedSQL(
                    f"TIMESTAMP_ADD({unit}, {left.sql}, {right.sql})",
                    _dt.datetime,
                )
        # Date - Date → DATE_DIFF (returns timedelta)
        if (op_type is ast.Sub
                and left.inferred_type in (_dt.date, _dt.datetime)
                and right.inferred_type in (_dt.date, _dt.datetime)):
            result = TypedSQL(f"DATE_DIFF({left.sql}, {right.sql})", _dt.timedelta)
            result.unit = 'DAY'
            result._diff_left = left.sql
            result._diff_right = right.sql
            result._operands_are_datetime = (
                left.inferred_type is _dt.datetime
                or right.inferred_type is _dt.datetime
            )
            return result
        if op_type is ast.Add:
            if left.inferred_type is list and right.inferred_type is list:
                return TypedSQL(f"ARRAY_CONCAT({left.sql}, {right.sql})", list)
            if left.inferred_type is str or right.inferred_type is str:
                return TypedSQL(f"CONCAT({left.sql}, {right.sql})", str)
        if op_type is ast.Mult:
            if left.inferred_type is str:
                return TypedSQL(f"REPEAT({left.sql}, {right.sql})", str)
            if right.inferred_type is str:
                return TypedSQL(f"REPEAT({right.sql}, {left.sql})", str)
        if op_type in _BINOP_MAP:
            op_str = _BINOP_MAP[op_type]
            my_prec = _PRECEDENCE.get(op_str, 0)
            left_sql = self._maybe_paren(left.sql, node.left, my_prec)
            right_sql = self._maybe_paren(right.sql, node.right, my_prec)
            result_type = self._infer_binop_type(
                left.inferred_type, right.inferred_type, op_type
            )
            return TypedSQL(f"{left_sql} {op_str} {right_sql}", result_type)

        raise UntranslatableUDFError(
            f"Unsupported binary operator: {op_type.__name__}"
        )

    def _visit_UnaryOp(self, node, pm):
        operand = self._visit(node.operand, pm)
        if isinstance(node.op, ast.USub):
            return TypedSQL(f"-{operand.sql}", operand.inferred_type)
        if isinstance(node.op, ast.UAdd):
            return operand
        if isinstance(node.op, ast.Not):
            cond = self._to_boolean_condition(operand)
            return TypedSQL(f"NOT ({cond.sql})", bool)
        raise UntranslatableUDFError(
            f"Unsupported unary op: {node.op.__class__.__name__}"
        )

    def _visit_List(self, node, pm):
        elts = [self._visit(e, pm) for e in node.elts]
        if not elts:
            return TypedSQL("ARRAY()", list)
        return TypedSQL(f"ARRAY({', '.join(e.sql for e in elts)})", list)

    def _visit_ListComp(self, node, pm):
        """Handle [expr for x in iter] and [expr for x in iter if cond]."""
        if len(node.generators) != 1:
            raise UntranslatableUDFError(
                "Only single-loop list comprehensions supported"
            )
        gen = node.generators[0]
        if not isinstance(gen.target, ast.Name):
            raise UntranslatableUDFError(
                "Only simple variable targets in list comprehension"
            )

        var_name = gen.target.id
        iter_expr = self._visit(gen.iter, pm)

        # Create inner param map with lambda variable
        inner_pm = dict(pm)
        inner_pm[var_name] = TypedSQL(var_name, int)

        elt_expr = self._visit(node.elt, inner_pm)

        if gen.ifs:
            cond_parts = [
                self._to_boolean_condition(self._visit(c, inner_pm)).sql
                for c in gen.ifs
            ]
            cond_sql = " AND ".join(cond_parts)

            if isinstance(node.elt, ast.Name) and node.elt.id == var_name:
                # Simple filter: [x for x in lst if cond]
                return TypedSQL(
                    f"FILTER_ARRAY({iter_expr.sql}, {var_name} -> {cond_sql})",
                    list,
                )
            else:
                # Filter then transform
                return TypedSQL(
                    f"TRANSFORM(FILTER_ARRAY({iter_expr.sql}, {var_name} -> {cond_sql}), "
                    f"{var_name} -> {elt_expr.sql})",
                    list,
                )
        else:
            # [expr for x in lst] → TRANSFORM(lst, x -> expr)
            return TypedSQL(
                f"TRANSFORM({iter_expr.sql}, {var_name} -> {elt_expr.sql})",
                list,
            )

    def _visit_Subscript(self, node, pm):
        """Handle s[i], s[i:j], s[-n], s[-n:], s[::-1] subscript operations on strings."""
        obj = self._visit(node.value, pm)
        if obj.inferred_type is str:
            sl = node.slice
            # s[i] → SUBSTR(s, i+1, 1)
            if isinstance(sl, (ast.Constant, ast.Name, ast.BinOp)):
                idx = self._visit(sl, pm)
                return TypedSQL(f"SUBSTR({obj.sql}, {idx.sql} + 1, 1)", str)
            # s[-n] → SUBSTR(s, LENGTH(s) - n + 1, 1)
            if (isinstance(sl, ast.UnaryOp) and isinstance(sl.op, ast.USub)):
                n = self._visit(sl.operand, pm)
                return TypedSQL(f"SUBSTR({obj.sql}, LENGTH({obj.sql}) - {n.sql} + 1, 1)", str)
            if isinstance(sl, ast.Slice):
                # s[::-1] → REVERSE(s)
                if (sl.lower is None and sl.upper is None
                        and sl.step is not None
                        and isinstance(sl.step, ast.UnaryOp)
                        and isinstance(sl.step.op, ast.USub)
                        and isinstance(sl.step.operand, ast.Constant)
                        and sl.step.operand.value == 1):
                    return TypedSQL(f"REVERSE({obj.sql})", str)
                # s[-n:] → RIGHT(s, n)
                if (sl.lower is not None and sl.upper is None
                        and sl.step is None
                        and isinstance(sl.lower, ast.UnaryOp)
                        and isinstance(sl.lower.op, ast.USub)):
                    n = self._visit(sl.lower.operand, pm)
                    return TypedSQL(f"RIGHT({obj.sql}, {n.sql})", str)
                # s[i:j] → SUBSTR(s, i+1, j-i)
                if sl.lower is not None and sl.upper is not None:
                    lower = self._visit(sl.lower, pm)
                    upper = self._visit(sl.upper, pm)
                    return TypedSQL(f"SUBSTR({obj.sql}, {lower.sql} + 1, {upper.sql} - {lower.sql})", str)
                if sl.lower is not None and sl.upper is None:
                    lower = self._visit(sl.lower, pm)
                    return TypedSQL(f"SUBSTR({obj.sql}, {lower.sql} + 1)", str)
                if sl.lower is None and sl.upper is not None:
                    upper = self._visit(sl.upper, pm)
                    return TypedSQL(f"SUBSTR({obj.sql}, 1, {upper.sql})", str)
        # List subscript operations
        if obj.inferred_type is list:
            sl = node.slice
            # Special case: s.split(sep)[i] → SPLIT_PART(s, sep, i + 1)
            if (isinstance(node.value, ast.Call)
                    and isinstance(node.value.func, ast.Attribute)
                    and node.value.func.attr == 'split'
                    and len(node.value.args) == 1):
                orig_str = self._visit(node.value.func.value, pm)
                sep = self._visit(node.value.args[0], pm)
                idx = self._visit(sl, pm)
                return TypedSQL(f"SPLIT_PART({orig_str.sql}, {sep.sql}, {idx.sql} + 1)", str)
            # lst[i] → ELEMENT_AT(arr, i+1)
            if isinstance(sl, (ast.Constant, ast.Name, ast.BinOp, ast.UnaryOp)):
                idx = self._visit(sl, pm)
                return TypedSQL(f"ELEMENT_AT({obj.sql}, {idx.sql} + 1)", None)
        raise UntranslatableUDFError(f"Unsupported subscript operation on type {obj.inferred_type}")

    def _visit_Call(self, node, pm):
        """Handle function calls."""
        if isinstance(node.func, ast.Name):
            func_name = node.func.id

            # len()
            if func_name == "len" and len(node.args) == 1:
                arg = self._visit(node.args[0], pm)
                if arg.inferred_type is list:
                    return TypedSQL(f"SIZE({arg.sql})", int)
                return TypedSQL(f"LENGTH({arg.sql})", int)

            # from datetime import timedelta; timedelta(days)
            if func_name == "timedelta":
                return self._build_timedelta(node, pm)

            # int/float/str/bool casting
            if func_name == "int" and len(node.args) == 1:
                arg = self._visit(node.args[0], pm)
                return TypedSQL(f"CAST({arg.sql} AS INT)", int)
            if func_name == "float" and len(node.args) == 1:
                arg = self._visit(node.args[0], pm)
                return TypedSQL(f"CAST({arg.sql} AS DOUBLE)", float)
            if func_name == "str" and len(node.args) == 1:
                arg = self._visit(node.args[0], pm)
                return TypedSQL(f"CAST({arg.sql} AS STRING)", str)
            if func_name == "bool" and len(node.args) == 1:
                arg = self._visit(node.args[0], pm)
                return TypedSQL(f"CAST({arg.sql} AS BOOLEAN)", bool)

            # abs()
            if func_name == "abs" and len(node.args) == 1:
                arg = self._visit(node.args[0], pm)
                return TypedSQL(f"ABS({arg.sql})", arg.inferred_type)

            # round()
            if func_name == "round":
                if len(node.args) == 1:
                    arg = self._visit(node.args[0], pm)
                    return TypedSQL(f"ROUND({arg.sql})", int)
                elif len(node.args) == 2:
                    arg = self._visit(node.args[0], pm)
                    ndigits = self._visit(node.args[1], pm)
                    return TypedSQL(f"ROUND({arg.sql}, {ndigits.sql})", float)

            # min() → LEAST (scalar comparison of 2+ args)
            if func_name == "min":
                if len(node.args) >= 2:
                    args = [self._visit(a, pm) for a in node.args]
                    return TypedSQL(
                        f"LEAST({', '.join(a.sql for a in args)})",
                        args[0].inferred_type,
                    )
                if len(node.args) == 1 and isinstance(node.args[0], ast.List):
                    elts = [self._visit(e, pm) for e in node.args[0].elts]
                    return TypedSQL(
                        f"LEAST({', '.join(e.sql for e in elts)})",
                        elts[0].inferred_type if elts else None,
                    )

            # max() → GREATEST (scalar comparison of 2+ args)
            if func_name == "max":
                if len(node.args) >= 2:
                    args = [self._visit(a, pm) for a in node.args]
                    return TypedSQL(
                        f"GREATEST({', '.join(a.sql for a in args)})",
                        args[0].inferred_type,
                    )
                if len(node.args) == 1 and isinstance(node.args[0], ast.List):
                    elts = [self._visit(e, pm) for e in node.args[0].elts]
                    return TypedSQL(
                        f"GREATEST({', '.join(e.sql for e in elts)})",
                        elts[0].inferred_type if elts else None,
                    )

            # sum() → expand list literal to additions
            if func_name == "sum" and len(node.args) == 1:
                if isinstance(node.args[0], ast.List) and node.args[0].elts:
                    elts = [self._visit(e, pm) for e in node.args[0].elts]
                    sql = " + ".join(e.sql for e in elts)
                    return TypedSQL(f"({sql})", elts[0].inferred_type)

            # sorted() → SORT_ARRAY
            if func_name == "sorted" and len(node.args) == 1:
                arg = self._visit(node.args[0], pm)
                return TypedSQL(f"SORT_ARRAY({arg.sql})", list)

            # set() — ARRAY_DISTINCT is unsupported in e6data for all array types
            if func_name == "set":
                raise UntranslatableUDFError(
                    "set() is not supported: ARRAY_DISTINCT fails on integer arrays in e6data"
                )

            # ord() → ASCII()
            if func_name == "ord" and len(node.args) == 1:
                arg = self._visit(node.args[0], pm)
                return TypedSQL(f"ASCII({arg.sql})", int)

            # chr/hex — CHR, HEX not supported in e6data
            if func_name in ("chr", "hex"):
                raise UntranslatableUDFError(
                    f"{func_name}() is not supported: no equivalent function in e6data"
                )

            # from datetime import datetime; datetime(y, m, d, ...)
            if (func_name == "datetime" and len(node.args) >= 3
                    and func_name not in self._params):
                return self._build_datetime_constructor(node.args, pm)

            # from datetime import date; date(y, m, d)
            if (func_name == "date" and len(node.args) == 3
                    and func_name not in self._params):
                return self._build_date_constructor(node.args, pm)

        if isinstance(node.func, ast.Attribute):
            return self._visit_method_call(node, pm)

        raise UntranslatableUDFError(
            f"Unsupported function call: {ast.dump(node.func)}"
        )

    # -- Datetime / method call support ------------------------------------

    def _visit_method_call(self, node, pm):
        """Handle method/attribute calls like obj.method(args)."""
        attr = node.func.attr

        # --- datetime.datetime.strptime(d, fmt) ---
        if (attr == 'strptime' and len(node.args) == 2
                and self._is_datetime_class_ref(node.func.value)):
            arg = self._visit(node.args[0], pm)
            fmt = self._visit(node.args[1], pm)
            sql_fmt = self._python_to_sql_date_format(fmt.sql)
            return TypedSQL(f"TO_TIMESTAMP({arg.sql}, {sql_fmt})", _dt.datetime)

        # --- datetime.timedelta(days) ---
        if (attr == 'timedelta'
                and isinstance(node.func.value, ast.Name)
                and node.func.value.id == 'datetime'):
            return self._build_timedelta(node, pm)

        # --- datetime.datetime.now() ---
        if (attr == 'now' and not node.args
                and self._is_datetime_class_ref(node.func.value)):
            return TypedSQL("CURRENT_TIMESTAMP()", _dt.datetime)

        # --- datetime.datetime.utcnow() ---
        if (attr == 'utcnow' and not node.args
                and self._is_datetime_class_ref(node.func.value)):
            return TypedSQL("CURRENT_TIMESTAMP()", _dt.datetime)

        # --- datetime.datetime.today() / datetime.date.today() ---
        if attr == 'today' and not node.args:
            if self._is_datetime_class_ref(node.func.value):
                return TypedSQL("CURRENT_TIMESTAMP()", _dt.datetime)
            if self._is_date_class_ref(node.func.value):
                return TypedSQL("CURRENT_DATE()", _dt.date)

        # --- datetime.datetime.fromtimestamp(ts) ---
        if (attr == 'fromtimestamp' and len(node.args) == 1
                and self._is_datetime_class_ref(node.func.value)):
            ts = self._visit(node.args[0], pm)
            return TypedSQL(
                f"CAST(FROM_UNIXTIME_WITHUNIT({ts.sql}, 'seconds') AS TIMESTAMP)",
                _dt.datetime,
            )

        # --- datetime.date.fromtimestamp(ts) ---
        if (attr == 'fromtimestamp' and len(node.args) == 1
                and self._is_date_class_ref(node.func.value)):
            ts = self._visit(node.args[0], pm)
            return TypedSQL(
                f"TO_DATE(FROM_UNIXTIME_WITHUNIT({ts.sql}, 'seconds'))",
                _dt.date,
            )

        # --- datetime.datetime.fromisoformat(s) ---
        if (attr == 'fromisoformat' and len(node.args) == 1
                and self._is_datetime_class_ref(node.func.value)):
            s = self._visit(node.args[0], pm)
            return TypedSQL(f"CAST({s.sql} AS TIMESTAMP)", _dt.datetime)

        # --- datetime.date.fromisoformat(s) ---
        if (attr == 'fromisoformat' and len(node.args) == 1
                and self._is_date_class_ref(node.func.value)):
            s = self._visit(node.args[0], pm)
            return TypedSQL(f"CAST({s.sql} AS DATE)", _dt.date)

        # --- datetime.date(y, m, d) constructor ---
        if (attr == 'date' and len(node.args) == 3
                and isinstance(node.func.value, ast.Name)
                and node.func.value.id == 'datetime'
                and 'datetime' not in self._params):
            return self._build_date_constructor(node.args, pm)

        # --- datetime.datetime(y, m, d, ...) constructor ---
        if (attr == 'datetime' and len(node.args) >= 3
                and isinstance(node.func.value, ast.Name)
                and node.func.value.id == 'datetime'
                and 'datetime' not in self._params):
            return self._build_datetime_constructor(node.args, pm)

        # --- datetime.time(h[, m[, s]]) constructor ---
        if (attr == 'time' and len(node.args) >= 1
                and isinstance(node.func.value, ast.Name)
                and node.func.value.id == 'datetime'
                and 'datetime' not in self._params):
            return self._build_time_constructor(node.args, pm)

        # --- datetime.datetime.utcfromtimestamp(ts) ---
        if (attr == 'utcfromtimestamp' and len(node.args) == 1
                and self._is_datetime_class_ref(node.func.value)):
            ts = self._visit(node.args[0], pm)
            return TypedSQL(
                f"CAST(FROM_UNIXTIME_WITHUNIT({ts.sql}, 'seconds') AS TIMESTAMP)",
                _dt.datetime,
            )

        # --- datetime.datetime.combine(date, time) ---
        if (attr == 'combine' and len(node.args) == 2
                and self._is_datetime_class_ref(node.func.value)):
            date_arg = self._visit(node.args[0], pm)
            time_arg = self._visit(node.args[1], pm)
            return TypedSQL(
                f"TO_TIMESTAMP(CONCAT(CAST({date_arg.sql} AS STRING), ' ', "
                f"CAST({time_arg.sql} AS STRING)), 'yyyy-MM-dd HH:mm:ss')",
                _dt.datetime,
            )

        # --- datetime.date.fromordinal(n) ---
        if (attr == 'fromordinal' and len(node.args) == 1
                and self._is_date_class_ref(node.func.value)):
            n = self._visit(node.args[0], pm)
            return TypedSQL(
                f"DATE_ADD(DATE '0001-01-01', {n.sql} - 1)",
                _dt.date,
            )

        # --- math module functions ---
        if (isinstance(node.func.value, ast.Name)
                and node.func.value.id == 'math'):
            return self._handle_math_call(attr, node, pm)

        # --- re module functions ---
        if (isinstance(node.func.value, ast.Name)
                and node.func.value.id == 're'):
            return self._handle_re_call(attr, node, pm)

        # --- Instance method calls: visit the object ---
        obj = self._visit(node.func.value, pm)

        # .date() → TO_DATE
        if attr == 'date' and not node.args:
            return TypedSQL(f"TO_DATE({obj.sql})", _dt.date)

        # .time() → build time string from HOUR/MINUTE/SECOND
        # (DATE_FORMAT with 'HH:mm:ss' fails: e6data "Unsupported field: HourOfDay")
        if attr == 'time' and not node.args:
            if obj.inferred_type is _dt.datetime:
                return TypedSQL(
                    f"CONCAT(LPAD(CAST(HOUR({obj.sql}) AS STRING), 2, '0'), ':', "
                    f"LPAD(CAST(MINUTE({obj.sql}) AS STRING), 2, '0'), ':', "
                    f"LPAD(CAST(SECOND({obj.sql}) AS STRING), 2, '0'))",
                    str,
                )

        # .total_seconds() on timedelta result
        # (TIMESTAMP_DIFF(..., SECOND) fails: e6data treats SECOND as column name)
        if attr == 'total_seconds' and not node.args:
            if obj.inferred_type is _dt.timedelta:
                if getattr(obj, '_operands_are_datetime', False):
                    return TypedSQL(
                        f"(TO_UNIX_TIMESTAMP({obj._diff_left}) - TO_UNIX_TIMESTAMP({obj._diff_right})) / 1000",
                        float,
                    )
                return TypedSQL(f"({obj.sql}) * 86400", float)

        # .weekday() → MOD(DAYOFWEEK(d) + 5, 7)
        # Python: Monday=0..Sunday=6; SQL DAYOFWEEK: Sunday=1..Saturday=7
        if attr == 'weekday' and not node.args:
            return TypedSQL(f"MOD(DAYOFWEEK({obj.sql}) + 5, 7)", int)

        # .strftime(fmt) → DATE_FORMAT
        if attr == 'strftime' and len(node.args) == 1:
            fmt = self._visit(node.args[0], pm)
            sql_fmt = self._python_to_sql_date_format(fmt.sql)
            return TypedSQL(f"DATE_FORMAT({obj.sql}, {sql_fmt})", str)

        # .isoweekday() → DAYOFWEEKISO (Mon=1..Sun=7)
        if attr == 'isoweekday' and not node.args:
            return TypedSQL(f"DAYOFWEEKISO({obj.sql})", int)

        # .timestamp() → TO_UNIX_TIMESTAMP / 1000 (ms → seconds)
        if attr == 'timestamp' and not node.args:
            return TypedSQL(f"TO_UNIX_TIMESTAMP({obj.sql}) / 1000", float)

        # .isoformat() → date/datetime ISO string
        # (DATE_FORMAT with 'HH:mm:ss' fails: e6data "Unsupported field: HourOfDay")
        if attr == 'isoformat' and not node.args:
            if obj.inferred_type is _dt.date:
                return TypedSQL(f"DATE_FORMAT({obj.sql}, 'yyyy-MM-dd')", str)
            return TypedSQL(
                f"CONCAT(DATE_FORMAT({obj.sql}, 'yyyy-MM-dd'), 'T', "
                f"LPAD(CAST(HOUR({obj.sql}) AS STRING), 2, '0'), ':', "
                f"LPAD(CAST(MINUTE({obj.sql}) AS STRING), 2, '0'), ':', "
                f"LPAD(CAST(SECOND({obj.sql}) AS STRING), 2, '0'))",
                str,
            )

        # .replace(year=, month=, day=, ...) → reconstruct date/datetime
        if attr == 'replace' and node.keywords:
            return self._build_replace(obj, node, pm)

        # .toordinal() → DATE_DIFF from epoch
        if attr == 'toordinal' and not node.args:
            if obj.inferred_type in (_dt.date, _dt.datetime):
                return TypedSQL(
                    f"DATE_DIFF({obj.sql}, DATE '0001-01-01') + 1",
                    int,
                )

        # .join(list) → CONCAT_WS(sep, e1, e2, ...) — string method
        # Flatten list and cast elements to VARCHAR (CONCAT_WS requires STRING args)
        if attr == 'join' and len(node.args) == 1 and obj.inferred_type is str:
            if isinstance(node.args[0], ast.List):
                elts = [self._visit(e, pm) for e in node.args[0].elts]
                cast_elts = [f"CAST({e.sql} AS VARCHAR)" for e in elts]
                return TypedSQL(f"CONCAT_WS({obj.sql}, {', '.join(cast_elts)})", str)
            arg = self._visit(node.args[0], pm)
            return TypedSQL(f"CONCAT_WS({obj.sql}, {arg.sql})", str)

        # .upper() → UPPER
        if attr == 'upper' and not node.args and obj.inferred_type is str:
            return TypedSQL(f"UPPER({obj.sql})", str)

        # .lower() → LOWER
        if attr == 'lower' and not node.args and obj.inferred_type is str:
            return TypedSQL(f"LOWER({obj.sql})", str)

        # .title() → INITCAP
        if attr == 'title' and not node.args and obj.inferred_type is str:
            return TypedSQL(f"INITCAP({obj.sql})", str)

        # .strip() → TRIM, .lstrip() → LTRIM, .rstrip() → RTRIM
        if attr == 'strip' and not node.args and obj.inferred_type is str:
            return TypedSQL(f"TRIM({obj.sql})", str)
        if attr == 'lstrip' and not node.args and obj.inferred_type is str:
            return TypedSQL(f"LTRIM({obj.sql})", str)
        if attr == 'rstrip' and not node.args and obj.inferred_type is str:
            return TypedSQL(f"RTRIM({obj.sql})", str)

        # .startswith(prefix) → LIKE 'prefix%'
        if attr == 'startswith' and len(node.args) == 1 and obj.inferred_type is str:
            prefix = self._visit(node.args[0], pm)
            return TypedSQL(f"{obj.sql} LIKE CONCAT({prefix.sql}, '%')", bool)

        # .endswith(suffix) → LIKE '%suffix'
        if attr == 'endswith' and len(node.args) == 1 and obj.inferred_type is str:
            suffix = self._visit(node.args[0], pm)
            return TypedSQL(f"{obj.sql} LIKE CONCAT('%', {suffix.sql})", bool)

        # .replace(old, new) → REPLACE(s, old, new)
        if attr == 'replace' and len(node.args) == 2 and obj.inferred_type is str:
            old_str = self._visit(node.args[0], pm)
            new_str = self._visit(node.args[1], pm)
            return TypedSQL(f"REPLACE({obj.sql}, {old_str.sql}, {new_str.sql})", str)

        # .split(sep) → SPLIT(s, sep)
        if attr == 'split' and len(node.args) == 1 and obj.inferred_type is str:
            sep = self._visit(node.args[0], pm)
            return TypedSQL(f"SPLIT({obj.sql}, {sep.sql})", list)

        # .index(x) on list → ARRAY_POSITION(arr, x) - 1  (0-based like Python)
        # Note: e6data expects ARRAY_POSITION(elem, arr) but SQLGlot normalizes
        # the arg order, so we pass (arr, elem) to get the correct output.
        if attr == 'index' and len(node.args) == 1 and obj.inferred_type is list:
            elem = self._visit(node.args[0], pm)
            return TypedSQL(f"(ARRAY_POSITION({obj.sql}, {elem.sql}) - 1)", int)

        # .find(sub) / .index(sub) → INSTR(s, sub) - 1  (0-based like Python)
        if attr in ('find', 'index') and len(node.args) == 1 and obj.inferred_type is str:
            sub = self._visit(node.args[0], pm)
            return TypedSQL(f"(INSTR({obj.sql}, {sub.sql}) - 1)", int)

        # .count(sub) → (LENGTH(s) - LENGTH(REPLACE(s, sub, ''))) / LENGTH(sub)
        if attr == 'count' and len(node.args) == 1 and obj.inferred_type is str:
            sub = self._visit(node.args[0], pm)
            return TypedSQL(
                f"(LENGTH({obj.sql}) - LENGTH(REPLACE({obj.sql}, {sub.sql}, ''))) / LENGTH({sub.sql})",
                int,
            )

        # .zfill(n) → LPAD(s, n, '0')
        if attr == 'zfill' and len(node.args) == 1 and obj.inferred_type is str:
            width = self._visit(node.args[0], pm)
            return TypedSQL(f"LPAD({obj.sql}, {width.sql}, '0')", str)

        # .ljust(n) → RPAD(s, n), .ljust(n, c) → RPAD(s, n, c)
        if attr == 'ljust' and obj.inferred_type is str:
            if len(node.args) == 1:
                width = self._visit(node.args[0], pm)
                return TypedSQL(f"RPAD({obj.sql}, {width.sql})", str)
            if len(node.args) == 2:
                width = self._visit(node.args[0], pm)
                fill = self._visit(node.args[1], pm)
                return TypedSQL(f"RPAD({obj.sql}, {width.sql}, {fill.sql})", str)

        # .rjust(n) → LPAD(s, n), .rjust(n, c) → LPAD(s, n, c)
        if attr == 'rjust' and obj.inferred_type is str:
            if len(node.args) == 1:
                width = self._visit(node.args[0], pm)
                return TypedSQL(f"LPAD({obj.sql}, {width.sql})", str)
            if len(node.args) == 2:
                width = self._visit(node.args[0], pm)
                fill = self._visit(node.args[1], pm)
                return TypedSQL(f"LPAD({obj.sql}, {width.sql}, {fill.sql})", str)

        # .center(n) → LPAD(RPAD(s, LENGTH(s) + FLOOR((n - LENGTH(s)) / 2)), n)
        if attr == 'center' and obj.inferred_type is str:
            if len(node.args) == 1:
                width = self._visit(node.args[0], pm)
                return TypedSQL(
                    f"LPAD(RPAD({obj.sql}, LENGTH({obj.sql}) + FLOOR(({width.sql} - LENGTH({obj.sql})) / 2)), {width.sql})",
                    str,
                )
            if len(node.args) == 2:
                width = self._visit(node.args[0], pm)
                fill = self._visit(node.args[1], pm)
                return TypedSQL(
                    f"LPAD(RPAD({obj.sql}, LENGTH({obj.sql}) + FLOOR(({width.sql} - LENGTH({obj.sql})) / 2), {fill.sql}), {width.sql}, {fill.sql})",
                    str,
                )

        raise UntranslatableUDFError(f"Unsupported method call: .{attr}()")

    def _is_datetime_class_ref(self, node):
        """Check if node refers to the datetime.datetime class."""
        # import datetime; datetime.datetime.method()
        if (isinstance(node, ast.Attribute)
                and isinstance(node.value, ast.Name)
                and node.value.id == 'datetime'
                and node.attr == 'datetime'):
            return True
        # from datetime import datetime; datetime.method()
        if (isinstance(node, ast.Name) and node.id == 'datetime'
                and 'datetime' not in self._params):
            return True
        return False

    def _is_date_class_ref(self, node):
        """Check if node refers to the datetime.date class."""
        # import datetime; datetime.date.method()
        if (isinstance(node, ast.Attribute)
                and isinstance(node.value, ast.Name)
                and node.value.id == 'datetime'
                and node.attr == 'date'):
            return True
        # from datetime import date; date.method()
        if (isinstance(node, ast.Name) and node.id == 'date'
                and 'date' not in self._params):
            return True
        return False

    def _handle_math_call(self, func_name, node, pm):
        """Handle math.xxx() function calls."""
        # Single-argument math functions
        _MATH_1ARG = {
            'floor': ('FLOOR', int), 'ceil': ('CEIL', int),
            'sqrt': ('SQRT', float), 'exp': ('EXP', float),
            'log10': ('LOG10', float), 'log2': ('LOG2', float),
            'fabs': ('ABS', float),
            'sin': ('SIN', float), 'cos': ('COS', float),
            'degrees': ('DEGREES', float), 'radians': ('RADIANS', float),
        }
        if func_name in _MATH_1ARG and len(node.args) == 1:
            sql_func, rtype = _MATH_1ARG[func_name]
            arg = self._visit(node.args[0], pm)
            return TypedSQL(f"{sql_func}({arg.sql})", rtype)

        # math.log(x) → LN(x), math.log(x, base) → LOG(base, x)
        if func_name == 'log':
            if len(node.args) == 1:
                arg = self._visit(node.args[0], pm)
                return TypedSQL(f"LN({arg.sql})", float)
            if len(node.args) == 2:
                x = self._visit(node.args[0], pm)
                base = self._visit(node.args[1], pm)
                return TypedSQL(f"LOG({base.sql}, {x.sql})", float)

        # math.pow(x, y) → POWER(x, y)
        if func_name == 'pow' and len(node.args) == 2:
            x = self._visit(node.args[0], pm)
            y = self._visit(node.args[1], pm)
            return TypedSQL(f"POWER({x.sql}, {y.sql})", float)

        # math.tan(x) → SIN(x) / COS(x) (TAN not supported in e6data)
        if func_name == 'tan' and len(node.args) == 1:
            arg = self._visit(node.args[0], pm)
            return TypedSQL(f"(SIN({arg.sql}) / COS({arg.sql}))", float)

        # math.asin(x) → ATAN2(x, SQRT(1 - x*x))
        if func_name == 'asin' and len(node.args) == 1:
            arg = self._visit(node.args[0], pm)
            return TypedSQL(f"ATAN2({arg.sql}, SQRT(1 - ({arg.sql}) * ({arg.sql})))", float)

        # math.acos(x) → ATAN2(SQRT(1 - x*x), x)
        if func_name == 'acos' and len(node.args) == 1:
            arg = self._visit(node.args[0], pm)
            return TypedSQL(f"ATAN2(SQRT(1 - ({arg.sql}) * ({arg.sql})), {arg.sql})", float)

        # math.atan(x) → ATAN2(x, 1)
        if func_name == 'atan' and len(node.args) == 1:
            arg = self._visit(node.args[0], pm)
            return TypedSQL(f"ATAN2({arg.sql}, 1)", float)

        # math.trunc(x) → CASE truncation (TRUNCATE not supported in e6data)
        if func_name == 'trunc' and len(node.args) == 1:
            arg = self._visit(node.args[0], pm)
            return TypedSQL(
                f"CASE WHEN {arg.sql} >= 0 THEN FLOOR({arg.sql}) ELSE CEIL({arg.sql}) END",
                int,
            )

        # math.isnan(x) → ISNAN(x) (e6data syntax is ISNAN, not IS_NAN)
        if func_name == 'isnan' and len(node.args) == 1:
            arg = self._visit(node.args[0], pm)
            return TypedSQL(f"ISNAN({arg.sql})", bool)

        # math.copysign(x, y) → SIGN(y) * ABS(x)
        if func_name == 'copysign' and len(node.args) == 2:
            x = self._visit(node.args[0], pm)
            y = self._visit(node.args[1], pm)
            return TypedSQL(f"SIGN({y.sql}) * ABS({x.sql})", float)

        # math.atan2(y, x) → ATAN2(y, x)
        if func_name == 'atan2' and len(node.args) == 2:
            y = self._visit(node.args[0], pm)
            x = self._visit(node.args[1], pm)
            return TypedSQL(f"ATAN2({y.sql}, {x.sql})", float)

        raise UntranslatableUDFError(f"Unsupported math function: math.{func_name}()")

    def _handle_re_call(self, func_name, node, pm):
        """Handle re.search(pat, s) / re.match(pat, s) → s RLIKE pat."""
        if func_name in ('search', 'match') and len(node.args) == 2:
            pattern = self._visit(node.args[0], pm)
            string = self._visit(node.args[1], pm)
            return TypedSQL(f"{string.sql} RLIKE {pattern.sql}", bool)
        if func_name == 'fullmatch' and len(node.args) == 2:
            pattern = self._visit(node.args[0], pm)
            string = self._visit(node.args[1], pm)
            return TypedSQL(
                f"{string.sql} RLIKE CONCAT('^', {pattern.sql}, '$')", bool
            )
        raise UntranslatableUDFError(f"Unsupported re function: re.{func_name}()")

    def _build_time_constructor(self, args, pm):
        """datetime.time(h[, m[, s]]) → string representation 'HH:mm:ss'"""
        h = self._visit(args[0], pm)
        m = self._visit(args[1], pm) if len(args) > 1 else TypedSQL("0", int)
        s = self._visit(args[2], pm) if len(args) > 2 else TypedSQL("0", int)
        return TypedSQL(
            f"CONCAT(LPAD(CAST({h.sql} AS STRING), 2, '0'), ':', "
            f"LPAD(CAST({m.sql} AS STRING), 2, '0'), ':', "
            f"LPAD(CAST({s.sql} AS STRING), 2, '0'))",
            str,
        )

    def _build_timedelta(self, node, pm):
        """Build a timedelta expression with unit metadata for date arithmetic.

        Supports positional arg (days) and keyword args:
        days, weeks, hours, minutes, seconds, months, years.
        """
        def _make(sql, unit="DAY"):
            result = TypedSQL(sql, _dt.timedelta)
            result.unit = unit
            return result

        # Positional arg → days
        if node.args and not node.keywords:
            return _make(self._visit(node.args[0], pm).sql)

        for kw in node.keywords:
            val = self._visit(kw.value, pm).sql
            if kw.arg == 'days':
                return _make(val)
            if kw.arg == 'weeks':
                return _make(f"{val} * 7")
            if kw.arg == 'hours':
                return _make(val, "HOUR")
            if kw.arg == 'minutes':
                return _make(val, "MINUTE")
            if kw.arg == 'seconds':
                return _make(val, "SECOND")
            if kw.arg == 'months':
                return _make(val, "MONTH")
            if kw.arg == 'years':
                return _make(f"{val} * 12", "MONTH")

        # Fallback: positional arg is days (when mixed with keywords)
        if node.args:
            return _make(self._visit(node.args[0], pm).sql)

        raise UntranslatableUDFError(
            "datetime.timedelta requires a supported time argument "
            "(days, weeks, hours, minutes, seconds, months, years)"
        )

    def _build_date_constructor(self, args, pm):
        """datetime.date(y, m, d) → TO_DATE(CONCAT(...), 'yyyy-MM-dd')"""
        y = self._visit(args[0], pm)
        m = self._visit(args[1], pm)
        d = self._visit(args[2], pm)
        return TypedSQL(
            f"TO_DATE(CONCAT(CAST({y.sql} AS STRING), '-', "
            f"LPAD(CAST({m.sql} AS STRING), 2, '0'), '-', "
            f"LPAD(CAST({d.sql} AS STRING), 2, '0')), 'yyyy-MM-dd')",
            _dt.date,
        )

    def _build_datetime_constructor(self, args, pm):
        """datetime.datetime(y, m, d[, h, mi, s]) → TO_TIMESTAMP(CONCAT(...))"""
        y = self._visit(args[0], pm)
        m = self._visit(args[1], pm)
        d = self._visit(args[2], pm)
        h = self._visit(args[3], pm) if len(args) > 3 else TypedSQL("0", int)
        mi = self._visit(args[4], pm) if len(args) > 4 else TypedSQL("0", int)
        s = self._visit(args[5], pm) if len(args) > 5 else TypedSQL("0", int)
        return TypedSQL(
            f"TO_TIMESTAMP(CONCAT(CAST({y.sql} AS STRING), '-', "
            f"LPAD(CAST({m.sql} AS STRING), 2, '0'), '-', "
            f"LPAD(CAST({d.sql} AS STRING), 2, '0'), ' ', "
            f"LPAD(CAST({h.sql} AS STRING), 2, '0'), ':', "
            f"LPAD(CAST({mi.sql} AS STRING), 2, '0'), ':', "
            f"LPAD(CAST({s.sql} AS STRING), 2, '0')), "
            f"'yyyy-MM-dd HH:mm:ss')",
            _dt.datetime,
        )

    def _build_replace(self, obj, node, pm):
        """obj.replace(year=, month=, ...) → reconstruct date/datetime."""
        overrides = {}
        for kw in node.keywords:
            overrides[kw.arg] = self._visit(kw.value, pm)

        y = overrides.get('year', TypedSQL(f"YEAR({obj.sql})", int))
        m = overrides.get('month', TypedSQL(f"MONTH({obj.sql})", int))
        d = overrides.get('day', TypedSQL(f"DAYS({obj.sql})", int))

        if obj.inferred_type is _dt.date:
            return TypedSQL(
                f"TO_DATE(CONCAT(CAST({y.sql} AS STRING), '-', "
                f"LPAD(CAST({m.sql} AS STRING), 2, '0'), '-', "
                f"LPAD(CAST({d.sql} AS STRING), 2, '0')), 'yyyy-MM-dd')",
                _dt.date,
            )
        h = overrides.get('hour', TypedSQL(f"HOUR({obj.sql})", int))
        mi = overrides.get('minute', TypedSQL(f"MINUTE({obj.sql})", int))
        s = overrides.get('second', TypedSQL(f"SECOND({obj.sql})", int))
        return TypedSQL(
            f"TO_TIMESTAMP(CONCAT(CAST({y.sql} AS STRING), '-', "
            f"LPAD(CAST({m.sql} AS STRING), 2, '0'), '-', "
            f"LPAD(CAST({d.sql} AS STRING), 2, '0'), ' ', "
            f"LPAD(CAST({h.sql} AS STRING), 2, '0'), ':', "
            f"LPAD(CAST({mi.sql} AS STRING), 2, '0'), ':', "
            f"LPAD(CAST({s.sql} AS STRING), 2, '0')), "
            f"'yyyy-MM-dd HH:mm:ss')",
            _dt.datetime,
        )

    @staticmethod
    def _python_to_sql_date_format(fmt_sql):
        """Convert Python strftime format string to SQL date format."""
        if fmt_sql.startswith("'") and fmt_sql.endswith("'"):
            fmt = fmt_sql[1:-1]
        else:
            fmt = fmt_sql
        for py_code, sql_code in [
            ('%Y', 'yyyy'), ('%m', 'MM'), ('%d', 'dd'),
            ('%H', 'HH'), ('%M', 'mm'), ('%S', 'ss'),
            ('%A', 'EEEE'), ('%a', 'EEE'),
            ('%B', 'MMMM'), ('%b', 'MMM'),
            ('%j', 'D'),
        ]:
            fmt = fmt.replace(py_code, sql_code)
        # Reject any remaining %-codes that weren't translated
        import re as _re
        remaining = _re.findall(r'%[A-Za-z]', fmt)
        if remaining:
            raise UntranslatableUDFError(
                f"Unsupported strftime format code(s): {', '.join(remaining)}. "
                f"Supported: %Y, %m, %d, %H, %M, %S, %A, %a, %B, %b, %j"
            )
        return f"'{fmt}'"

    def _visit_Compare(self, node, pm):
        """Handle comparison operations: ==, !=, <, <=, >, >=, is, is not, in, not in."""
        # Special handling for `in` / `not in`
        if (len(node.ops) == 1
                and isinstance(node.ops[0], (ast.In, ast.NotIn))):
            return self._handle_in_compare(node, pm)

        if len(node.ops) > 1:
            # Chained comparison: a < x < b → a < x AND x < b
            parts = []
            left = self._visit(node.left, pm)
            for op, comp in zip(node.ops, node.comparators):
                right = self._visit(comp, pm)
                parts.append(self._format_comparison(left, op, right, comp))
                left = right
            return TypedSQL(" AND ".join(parts), bool)

        left = self._visit(node.left, pm)
        right = self._visit(node.comparators[0], pm)
        sql = self._format_comparison(left, node.ops[0], right, node.comparators[0])
        return TypedSQL(sql, bool)

    def _format_comparison(self, left, op, right, right_node):
        op_type = type(op)
        if op_type in _CMPOP_MAP:
            return f"{left.sql} {_CMPOP_MAP[op_type]} {right.sql}"
        if isinstance(op, ast.Is):
            if isinstance(right_node, ast.Constant) and right_node.value is None:
                return f"{left.sql} IS NULL"
            raise UntranslatableUDFError(
                "'is' with non-None value cannot be translated"
            )
        if isinstance(op, ast.IsNot):
            if isinstance(right_node, ast.Constant) and right_node.value is None:
                return f"{left.sql} IS NOT NULL"
            raise UntranslatableUDFError(
                "'is not' with non-None value cannot be translated"
            )
        raise UntranslatableUDFError(
            f"Unsupported comparison: {op_type.__name__}"
        )

    def _handle_in_compare(self, node, pm):
        """Handle `sub in s` and `x in [list]` comparisons."""
        is_not = isinstance(node.ops[0], ast.NotIn)
        left = self._visit(node.left, pm)
        right_node = node.comparators[0]
        right = self._visit(right_node, pm)

        # sub in string → CONTAINS_SUBSTR(s, sub)
        if right.inferred_type is str:
            neg = "NOT " if is_not else ""
            return TypedSQL(f"{neg}CONTAINS_SUBSTR({right.sql}, {left.sql})", bool)

        # x in [list literal] → x IN (e1, e2, ...)
        if isinstance(right_node, ast.List):
            elts = [self._visit(e, pm) for e in right_node.elts]
            vals = ', '.join(e.sql for e in elts)
            neg = "NOT " if is_not else ""
            return TypedSQL(f"{left.sql} {neg}IN ({vals})", bool)

        # x in array_expr → ARRAY_CONTAINS(arr, x)
        if right.inferred_type is list:
            neg = "NOT " if is_not else ""
            return TypedSQL(f"{neg}ARRAY_CONTAINS({right.sql}, {left.sql})", bool)

        raise UntranslatableUDFError(
            "'in' operator only supported for string membership, list literals, and array expressions"
        )

    def _visit_IfExp(self, node, pm):
        """Ternary: a if cond else b → CASE WHEN cond THEN a ELSE b END"""
        test = self._to_boolean_condition(self._visit(node.test, pm))
        body = self._visit(node.body, pm)
        orelse = self._visit(node.orelse, pm)
        return TypedSQL(
            f"CASE WHEN {test.sql} THEN {body.sql} ELSE {orelse.sql} END",
            body.inferred_type,
        )

    def _visit_BoolOp(self, node, pm):
        """Handle and/or → SQL AND/OR."""
        is_and = isinstance(node.op, ast.And)
        op_str = "AND" if is_and else "OR"
        values = [self._visit(v, pm) for v in node.values]

        my_prec = _PRECEDENCE.get(op_str, 0)
        parts = []
        for v, ast_v in zip(values, node.values):
            cond = self._to_boolean_condition(v)
            needs_parens = False
            if isinstance(ast_v, ast.BoolOp):
                child_op = "AND" if isinstance(ast_v.op, ast.And) else "OR"
                if _PRECEDENCE.get(child_op, 0) < my_prec:
                    needs_parens = True
            parts.append(f"({cond.sql})" if needs_parens else cond.sql)
        return TypedSQL(f" {op_str} ".join(parts), bool)

    def _visit_Attribute(self, node, pm):
        """Handle attribute access: dateObj.year, dateObj.month, etc."""
        attr = node.attr

        # --- Module-level constants (must check before visiting node.value) ---

        # math.pi, math.e
        if isinstance(node.value, ast.Name) and node.value.id == 'math':
            if attr == 'pi':
                return TypedSQL('PI()', float)
            if attr == 'e':
                return TypedSQL('2.718281828459045', float)
            if attr == 'inf':
                return TypedSQL('INFINITY', float)
            if attr == 'nan':
                return TypedSQL('NAN', float)
            raise UntranslatableUDFError(
                f"Unsupported math constant: math.{attr}"
            )

        # datetime.datetime.min / .max / datetime.date.min / .max
        if attr in ('min', 'max'):
            if self._is_datetime_class_ref(node.value):
                if attr == 'min':
                    return TypedSQL("TIMESTAMP '0001-01-01 00:00:00'", _dt.datetime)
                return TypedSQL("TIMESTAMP '9999-12-31 23:59:59'", _dt.datetime)
            if self._is_date_class_ref(node.value):
                if attr == 'min':
                    return TypedSQL("DATE '0001-01-01'", _dt.date)
                return TypedSQL("DATE '9999-12-31'", _dt.date)

        # --- Instance-level attributes (visit the object first) ---
        obj = self._visit(node.value, pm)

        # e6data extraction functions for date/datetime attributes
        _date_attrs = {
            'year': 'YEAR', 'month': 'MONTH', 'day': 'DAYS',
            'hour': 'HOUR', 'minute': 'MINUTE', 'second': 'SECOND',
        }

        if attr in _date_attrs and obj.inferred_type in (_dt.date, _dt.datetime):
            return TypedSQL(f"{_date_attrs[attr]}({obj.sql})", int)

        # .days on timedelta → return DATE_DIFF value directly
        if attr == 'days' and obj.inferred_type is _dt.timedelta:
            return TypedSQL(obj.sql, int)

        # .seconds on timedelta → seconds component (not total)
        # (TIMESTAMP_DIFF(..., SECOND) fails: e6data treats SECOND as column name)
        if attr == 'seconds' and obj.inferred_type is _dt.timedelta:
            if getattr(obj, '_operands_are_datetime', False):
                return TypedSQL(
                    f"CAST(MOD((TO_UNIX_TIMESTAMP({obj._diff_left}) - TO_UNIX_TIMESTAMP({obj._diff_right})) / 1000, 86400) AS INT)",
                    int,
                )
            # For date-only timedelta (DATE_DIFF returns days), seconds = 0
            return TypedSQL("0", int)

        # .microseconds on timedelta → microseconds component
        if attr == 'microseconds' and obj.inferred_type is _dt.timedelta:
            if getattr(obj, '_operands_are_datetime', False):
                return TypedSQL(
                    f"CAST(MOD(TO_UNIX_TIMESTAMP({obj._diff_left}) - TO_UNIX_TIMESTAMP({obj._diff_right}), 1000) * 1000 AS INT)",
                    int,
                )
            return TypedSQL("0", int)

        raise UntranslatableUDFError(
            f"Attribute '.{attr}' is not supported in UDF translation"
        )

    # ======================================================================
    # HELPERS
    # ======================================================================
    
    def _maybe_paren(self, sql, child_node, parent_prec):
        # fixing the parenthesis issue
        if isinstance(child_node, ast.BinOp):
            child_op_type = type(child_node.op)
            if child_op_type in _BINOP_MAP:
                child_prec = _PRECEDENCE.get(_BINOP_MAP[child_op_type], 0)
                if child_prec < parent_prec:
                    return f"({sql})"
        return sql

    @staticmethod
    def _translate_constant(value):
        if value is None:
            return TypedSQL("NULL")
        if isinstance(value, bool):
            return TypedSQL("TRUE" if value else "FALSE", bool)
        if isinstance(value, str):
            return TypedSQL(f"'{value.replace(chr(39), chr(39)*2)}'", str)
        if isinstance(value, int):
            return TypedSQL(str(value), int)
        if isinstance(value, float):
            return TypedSQL(str(value), float)
        return TypedSQL(str(value))
    
    def _resolve_external(self, name):
        # finding variable which will help us solve the equatioins
        if name in self._externals:
            val = self._externals[name]
            result = self._try_inline_value(val)
            if result is not None:
                return result
            raise UntranslatableUDFError(
                f"External '{name}' has mutable type {type(val).__name__}"
            )
        if self.func is None:
            return None
        val = self._lookup_external_value(name)
        if val is _MISSING:
            return None
        result = self._try_inline_value(val)
        if result is not None:
            return result
        raise UntranslatableUDFError(
            f"Captured variable '{name}' has mutable type {type(val).__name__}"
        )

    def _lookup_external_value(self, name):
        #does the searching of those values 
        if hasattr(self.func, '__closure__') and self.func.__closure__:
            code = self.func.__code__
            if name in code.co_freevars:
                idx = code.co_freevars.index(name)
                try:
                    return self.func.__closure__[idx].cell_contents
                except (ValueError, IndexError):
                    pass
        if hasattr(self.func, '__globals__') and name in self.func.__globals__:
            return self.func.__globals__[name]
        return _MISSING

    @staticmethod
    def _try_inline_value(val):
        if val is None:
            return TypedSQL("NULL")
        if isinstance(val, bool):
            return TypedSQL("TRUE" if val else "FALSE", bool)
        if isinstance(val, int):
            return TypedSQL(str(val), int)
        if isinstance(val, float):
            return TypedSQL(str(val), float)
        if isinstance(val, str):
            return TypedSQL(f"'{val.replace(chr(39), chr(39)*2)}'", str)
        return None

    @staticmethod
    def _infer_binop_type(left_type, right_type, op_type):
        if op_type is ast.Add and (left_type is str or right_type is str):
            return str
        if op_type is ast.FloorDiv:
            return int
        if op_type is ast.Div:
            return float
        if op_type is ast.Pow:
            return float
        if left_type is float or right_type is float:
            return float
        if left_type is int and right_type is int:
            return int
        return left_type or right_type
