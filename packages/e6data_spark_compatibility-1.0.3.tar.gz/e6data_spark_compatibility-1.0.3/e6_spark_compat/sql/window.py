"""
Window specification API for PySpark compatibility
"""
from typing import List, Union, Optional
from .column import Column, Expression


class WindowSpec:
    """
    A window specification that defines the partitioning, ordering, and frame boundaries for window functions.
    This is used with window functions to specify the window over which the function operates.
    """
    
    def __init__(self):
        self._partition_by_cols: List[Union[str, Column, Expression]] = []
        self._order_by_cols: List[Union[str, Column, Expression]] = []
        self._frame_type: Optional[str] = None  # ROWS or RANGE
        self._frame_start: Optional[str] = None
        self._frame_end: Optional[str] = None
    
    def partitionBy(self, *cols: Union[str, Column, Expression]) -> 'WindowSpec':
        """
        Define partitioning columns for the window specification.
        
        Args:
            *cols: Column names, Column objects, or expressions to partition by
            
        Returns:
            New WindowSpec with partitioning defined
        """
        new_spec = WindowSpec()
        # Flatten any list/tuple arguments (e.g. partitionBy(["a","b"]) -> ["a","b"])
        flat = []
        for c in cols:
            if isinstance(c, (list, tuple)):
                flat.extend(c)
            else:
                flat.append(c)
        new_spec._partition_by_cols = flat
        new_spec._order_by_cols = self._order_by_cols.copy()
        new_spec._frame_type = self._frame_type
        new_spec._frame_start = self._frame_start
        new_spec._frame_end = self._frame_end
        return new_spec
    
    def orderBy(self, *cols: Union[str, Column, Expression]) -> 'WindowSpec':
        """
        Define ordering columns for the window specification.
        
        Args:
            *cols: Column names, Column objects, or expressions to order by
            
        Returns:
            New WindowSpec with ordering defined
        """
        new_spec = WindowSpec()
        new_spec._partition_by_cols = self._partition_by_cols.copy()
        new_spec._order_by_cols = list(cols)
        new_spec._frame_type = self._frame_type
        new_spec._frame_start = self._frame_start
        new_spec._frame_end = self._frame_end
        return new_spec
    
    def rowsBetween(self, start: Union[int, str], end: Union[int, str]) -> 'WindowSpec':
        """
        Define a window frame using row boundaries.
        
        Args:
            start: Start boundary (int for offset, or special strings like 'UNBOUNDED_PRECEDING')
            end: End boundary (int for offset, or special strings like 'UNBOUNDED_FOLLOWING')
            
        Returns:
            New WindowSpec with row frame defined
        """
        new_spec = WindowSpec()
        new_spec._partition_by_cols = self._partition_by_cols.copy()
        new_spec._order_by_cols = self._order_by_cols.copy()
        new_spec._frame_type = "ROWS"
        new_spec._frame_start = self._convert_frame_boundary(start)
        new_spec._frame_end = self._convert_frame_boundary(end)
        return new_spec
    
    def rangeBetween(self, start: Union[int, str], end: Union[int, str]) -> 'WindowSpec':
        """
        Define a window frame using range boundaries.
        
        Args:
            start: Start boundary (int for offset, or special strings like 'UNBOUNDED_PRECEDING')
            end: End boundary (int for offset, or special strings like 'UNBOUNDED_FOLLOWING')
            
        Returns:
            New WindowSpec with range frame defined
        """
        new_spec = WindowSpec()
        new_spec._partition_by_cols = self._partition_by_cols.copy()
        new_spec._order_by_cols = self._order_by_cols.copy()
        new_spec._frame_type = "RANGE"
        new_spec._frame_start = self._convert_frame_boundary(start)
        new_spec._frame_end = self._convert_frame_boundary(end)
        return new_spec
    
    def _convert_frame_boundary(self, boundary: Union[int, str]) -> str:
        """Convert frame boundary to SQL representation"""
        if isinstance(boundary, int):
            if boundary == 0:
                return "CURRENT ROW"
            elif boundary > 0:
                return f"{boundary} FOLLOWING"
            else:
                return f"{abs(boundary)} PRECEDING"
        elif isinstance(boundary, str):
            # Handle special boundary strings
            boundary_map = {
                'UNBOUNDED_PRECEDING': 'UNBOUNDED PRECEDING',
                'UNBOUNDED_FOLLOWING': 'UNBOUNDED FOLLOWING',
                'CURRENT_ROW': 'CURRENT ROW'
            }
            return boundary_map.get(boundary.upper(), boundary)
        else:
            return str(boundary)
    
    def to_sql(self) -> str:
        """
        Generate SQL window specification using SQLGlot.
        
        Returns:
            SQL window specification string
        """
        from ..core.sql_generator import SQLGenerator
        
        sql_gen = SQLGenerator()
        parts = []
        
        # Build PARTITION BY clause
        if self._partition_by_cols:
            partition_cols = []
            for col in self._partition_by_cols:
                if hasattr(col, 'to_sql'):
                    partition_cols.append(col.to_sql())
                else:
                    partition_cols.append(sql_gen.quote_identifier(str(col)))
            parts.append(f"PARTITION BY {', '.join(partition_cols)}")

        # Build ORDER BY clause
        if self._order_by_cols:
            order_cols = []
            for col in self._order_by_cols:
                if hasattr(col, 'to_sql'):
                    order_cols.append(col.to_sql())
                else:
                    order_cols.append(sql_gen.quote_identifier(str(col)))
            parts.append(f"ORDER BY {', '.join(order_cols)}")
        
        # Build frame clause
        if self._frame_type and self._frame_start is not None and self._frame_end is not None:
            frame_clause = f"{self._frame_type} BETWEEN {self._frame_start} AND {self._frame_end}"
            parts.append(frame_clause)
        elif self._frame_type and self._frame_start is not None:
            # Single boundary frame
            frame_clause = f"{self._frame_type} {self._frame_start}"
            parts.append(frame_clause)
        
        # Join all parts
        window_spec = " ".join(parts)
        
        # Use SQLGlot to optimize if possible
        try:
            return sql_gen.optimize_query(window_spec) if sql_gen.optimize_flag else window_spec
        except Exception:
            # Fallback to manual construction
            return window_spec
    
    def __str__(self) -> str:
        """String representation of window specification"""
        return self.to_sql()


class Window:
    """
    Utility functions for defining window specifications.
    This provides the main entry point for creating window specifications, similar to PySpark's Window class.
    """
    
    # Frame boundary constants for convenience
    UNBOUNDED_PRECEDING = "UNBOUNDED_PRECEDING"
    UNBOUNDED_FOLLOWING = "UNBOUNDED_FOLLOWING" 
    CURRENT_ROW = "CURRENT_ROW"
    
    @staticmethod
    def partitionBy(*cols: Union[str, Column, Expression]) -> WindowSpec:
        """
        Create a window specification with partitioning columns.
        
        Args:
            *cols: Column names, Column objects, or expressions to partition by
            
        Returns:
            WindowSpec with partitioning defined
        
        Example:
            >>> from e6_spark_compat.sql.window import Window
            >>> w = Window.partitionBy("department").orderBy("salary")
            >>> # Use with window functions: rank().over(w)
        """
        return WindowSpec().partitionBy(*cols)
    
    @staticmethod
    def orderBy(*cols: Union[str, Column, Expression]) -> WindowSpec:
        """
        Create a window specification with ordering columns.
        
        Args:
            *cols: Column names, Column objects, or expressions to order by
            
        Returns:
            WindowSpec with ordering defined
        
        Example:
            >>> from e6_spark_compat.sql.window import Window
            >>> w = Window.orderBy("salary")
            >>> # Use with window functions: row_number().over(w)
        """
        return WindowSpec().orderBy(*cols)
    
    @staticmethod
    def rowsBetween(start: Union[int, str], end: Union[int, str]) -> WindowSpec:
        """
        Create a window specification with row-based frame.
        
        Args:
            start: Start boundary 
            end: End boundary
            
        Returns:
            WindowSpec with row frame defined
        
        Example:
            >>> from e6_spark_compat.sql.window import Window
            >>> w = Window.rowsBetween(Window.UNBOUNDED_PRECEDING, Window.CURRENT_ROW)
            >>> # Creates frame from start of partition to current row
        """
        return WindowSpec().rowsBetween(start, end)
    
    @staticmethod
    def rangeBetween(start: Union[int, str], end: Union[int, str]) -> WindowSpec:
        """
        Create a window specification with range-based frame.
        
        Args:
            start: Start boundary
            end: End boundary
            
        Returns:
            WindowSpec with range frame defined
        
        Example:
            >>> from e6_spark_compat.sql.window import Window
            >>> w = Window.rangeBetween(-1, 1)
            >>> # Creates frame from 1 preceding to 1 following in value range
        """
        return WindowSpec().rangeBetween(start, end)


# For convenience, also provide these functions at module level
def partitionBy(*cols: Union[str, Column, Expression]) -> WindowSpec:
    """Alias for Window.partitionBy()"""
    return Window.partitionBy(*cols)


def orderBy(*cols: Union[str, Column, Expression]) -> WindowSpec:
    """Alias for Window.orderBy()"""
    return Window.orderBy(*cols)


def rowsBetween(start: Union[int, str], end: Union[int, str]) -> WindowSpec:
    """Alias for Window.rowsBetween()"""
    return Window.rowsBetween(start, end)


def rangeBetween(start: Union[int, str], end: Union[int, str]) -> WindowSpec:
    """Alias for Window.rangeBetween()"""
    return Window.rangeBetween(start, end)