"""
PySpark compatibility wrapper for e6_spark_compat
This allows clients to use exact PySpark syntax without any code changes
"""
from .core.session import SparkSession as E6SparkSession
from .core.session import SparkSessionBuilder

# Create a wrapper class that adds PySpark-style builder attribute
class SparkSession(E6SparkSession):
    """PySpark-compatible SparkSession with builder as class attribute"""
    builder = SparkSessionBuilder()

# Re-export for compatibility
__all__ = ['SparkSession']