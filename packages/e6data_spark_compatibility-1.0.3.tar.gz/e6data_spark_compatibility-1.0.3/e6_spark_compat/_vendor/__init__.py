"""
Vendored dependencies for e6-spark-compat.

This directory contains vendored (bundled) copies of dependencies
to avoid external package requirements for PyPI publishing.
"""
import sys
import os
import importlib.util

# Pre-register sqlglot in sys.modules BEFORE importing it
# This is necessary because the vendored sqlglot uses internal imports like 'from sqlglot import ...'
def _setup_vendored_sqlglot():
    """Setup vendored sqlglot by pre-registering it in sys.modules."""
    vendor_dir = os.path.dirname(__file__)
    sqlglot_dir = os.path.join(vendor_dir, 'sqlglot')

    # Create a module spec for the vendored sqlglot
    spec = importlib.util.spec_from_file_location(
        'sqlglot',
        os.path.join(sqlglot_dir, '__init__.py'),
        submodule_search_locations=[sqlglot_dir]
    )

    # Create the module and add to sys.modules BEFORE executing it
    sqlglot_module = importlib.util.module_from_spec(spec)
    sys.modules['sqlglot'] = sqlglot_module

    # Now execute the module (this allows internal imports to work)
    spec.loader.exec_module(sqlglot_module)

    # Also make it available as e6_spark_compat._vendor.sqlglot
    sys.modules['e6_spark_compat._vendor.sqlglot'] = sqlglot_module

_setup_vendored_sqlglot()
