import diplotocus as dpl
import numpy as np
import matplotlib.pyplot as plt

fig,ax = plt.subplots(figsize=(7,5))
#ax.set_axis_off()

x = np.linspace(0,10,100)
y = np.cos(x)

a = dpl.scatter(x=x,y=y)

x2 = np.linspace(0,10,100)
y2 = np.sin(x2)
x2 = np.cos(x2)*2 + 5

b = dpl.plot(x=x2,y=y2,color='C1')

tl = dpl.Timeline(fig=fig,transparent=True,white=True)

b.translate((0,0),(0,1),duration=50,delay=0)
b.translate((0,0),(1,0),duration=50,delay=50)
b.morph(x,y,duration=50,delay=50)
#b.tween('c','C1','C2',duration=50,delay=25)

a.tweens(('color','lw'),('C3',1),('C4',10),duration=100)
a.draw(duration=100)

tl.animate((a,b))

tl.save_project('test.pkl')
tl.save_video('ee.mov')