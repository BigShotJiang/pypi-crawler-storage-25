import diplotocus as dpl
import numpy as np
import matplotlib.pyplot as plt

fig,ax = plt.subplots()
ax.set_xlim(0,2*np.pi)
ax.set_ylim(-1,1)

x = np.linspace(0,2*np.pi,100)
y = np.cos(x)

a = dpl.scatter(x,y)
a.sequence(100)

tl = dpl.Timeline(fig=fig,transparent=True,white=True)

tl.animate(a)

tl.save_video('ee2.mov')