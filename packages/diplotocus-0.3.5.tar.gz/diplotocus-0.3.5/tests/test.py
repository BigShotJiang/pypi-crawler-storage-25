import diplotocus as dpl
import numpy as np
import matplotlib.pyplot as plt

fig,ax = plt.subplots(figsize=(12,5))
ax.set_axis_off()

x = np.linspace(0,10,100)
y = np.cos(x)

a = dpl.scatter(x=x,y=y)

x2 = np.linspace(0,10,100)
y2 = np.sin(x2)
x2 = np.cos(x2)*2 + 5

b = dpl.plot(x=x2,y=y2,color='C1')

b.translate((0,0),(1,0),100)
b.scale((0,0),(1,0),100,10)

tl = dpl.Timeline(fig=fig,transparent=True,white=True)

GUI = dpl.GUI.GUI(seq=tl,plot_objects=
    [
        {
            'name':'scatter',
            'object':a
        },
        {
            'name':'plot',
            'object':b,
            'new_x':x,
            'new_y':y
        }
    ]
)
GUI.open()