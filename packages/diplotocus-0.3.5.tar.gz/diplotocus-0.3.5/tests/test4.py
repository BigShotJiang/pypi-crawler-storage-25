import diplotocus as dpl
import matplotlib.pyplot as plt
from matplotlib.cm import ScalarMappable
from matplotlib.colors import Normalize
import numpy as np
from proplot_cmaps import cmaps
import pandas as pd
import NEST

def base_fig():
    cluster = pd.read_csv('/Users/titanbin/Desktop/PhD/Neural-Network-Stellar-Ages/output_clusters_wZP_BPRPR_wFeH.csv')
    blue_stragglers = pd.read_csv('/Users/titanbin/Desktop/PhD/Neural-Network-Stellar-Ages/Cs_BSS.csv')
    binaries = pd.read_csv('/Users/titanbin/Desktop/PhD/Neural-Network-Stellar-Ages/OCs_BINARIES.csv')
    blue_stragglers_ids = blue_stragglers['source_id']
    binaries_ids = binaries['source_id']
    cluster = cluster[~cluster['source_id'].isin(blue_stragglers_ids) & ~cluster['source_id'].isin(binaries_ids)]
    cluster['Age_SPInS_err'] = (cluster['Age_SPInS_84'] - cluster['Age_SPInS_16'])/2
    cluster.loc[cluster['cluster'] == 'NGC_6397','FeH_scaled'] = -2.0

    ages_clusters_lit = np.array([0.1038749,0.2399611,0.67136099,0.14418133,0.89767028,0.19091284,6.53986446,0.20660812,0.56160998,3.7481988,0.37502679,0.27362404,2.20843028,12.8])

    df = pd.read_csv('/Users/titanbin/Desktop/PhD/Neural-Network-Stellar-Ages/cluster_ages_nest.csv')
    unique_clusters = df['cluster']
    ages_clusters_nest = df['age_nest_50']
    ages_clusters_nest_unc = np.zeros((len(unique_clusters),2))
    ages_clusters_nest_unc[:,0] = df['age_nest_16']
    ages_clusters_nest_unc[:,1] = df['age_nest_84']

    x = np.log10(ages_clusters_lit*1e9)

    spins_medians = [(8.01062416998672, 8.367713004484305), (8.156706507304117, 8.520179372197308), (8.260292164674635, 8.591928251121075), (8.308100929614874, 9.026905829596412), (8.374501992031872, 8.690582959641254), (8.430278884462151, 8.784753363228699), (8.57636122177955, 9.031390134529147), (8.751660026560426, 8.896860986547084), (8.828685258964144, 8.923766816143498), (8.953519256308102, 9.035874439461884), (9.341301460823374, 9.502242152466367), (9.575033200531209, 9.721973094170403), (9.814077025232404, 9.874439461883409), (10.108897742363878, 10.125560538116591)]
    spins_medians_down = [(8.01062416998672, 8.242152466367713), (8.159362549800797, 8.390134529147982), (8.257636122177955, 8.457399103139014), (8.308100929614874, 8.708520179372197), (8.369189907038512, 8.551569506726457), (8.427622841965471, 8.556053811659194), (8.57636122177955, 8.77578475336323), (8.749003984063746, 8.825112107623319), (8.828685258964144, 8.865470852017937), (8.950863213811422, 8.977578475336323), (9.338645418326694, 9.408071748878923), (9.572377158034529, 9.654708520179373), (9.808764940239044, 9.834080717488789), (10.106241699867198, 10.121076233183857)]
    spins_median_up = [(8.00796812749004, 8.573991031390134), (8.159362549800797, 8.699551569506726), (8.257636122177955, 9.044843049327355), (8.308100929614874, 9.421524663677129), (8.371845949535192, 8.73542600896861), (8.427622841965471, 9.188340807174887), (8.573705179282868, 9.403587443946188), (8.751660026560426, 9.076233183856502), (8.828685258964144, 9.040358744394618), (8.950863213811422, 9.116591928251122), (9.341301460823374, 9.609865470852018), (9.572377158034529, 9.807174887892376), (9.811420982735724, 9.941704035874439), (10.106241699867198, 10.147982062780269)]
    spins_mode = [(8.01062416998672, 8.179372197309416), (8.162018592297477, 8.551569506726457), (8.257636122177955, 8.547085201793722), (8.313413014608233, 8.820627802690582), (8.369189907038512, 8.654708520179373), (8.427622841965471, 8.547085201793722), (8.573705179282868, 8.816143497757848), (8.751660026560426, 8.820627802690582), (8.828685258964144, 8.878923766816143), (8.953519256308102, 8.977578475336323), (9.338645418326694, 9.475336322869955), (9.575033200531209, 9.654708520179373), (9.811420982735724, 9.834080717488789), (10.106241699867198, 10.130044843049328)]

    spins_names = [
        'Melotte_22',
        'NGC_1039',
        'NGC_3114',
        'NGC_2287',
        'NGC_2516',
        'NGC_6475',
        'NGC_3532',
        'NGC_2447',
        'NGC_2632',
        'NGC_5822',
        'NGC_6819',
        'NGC_2682',
        'NGC_188',
        'NGC_6397',
    ]

    unique_clusters = list(cluster['cluster'].unique())

    min_stars = 50
    nbs = []
    for cluster_name in unique_clusters:
        nbs.append(len(cluster[(cluster['cluster'] == cluster_name) & (cluster['MG'] < 4)]))
    nbs = np.array(nbs)
    x_col = (nbs-min_stars) / (max(nbs)-min_stars)
    colors = cmaps['acton'](np.log10(x_col+1)/np.log10(2))

    fig,ax = plt.subplots(1,2,figsize=(17,5),width_ratios=[1,1.25])
    age_model = NEST.BaSTIModel()
    mask = cluster['cluster'] == 'NGC_2447'
    mask_idx = unique_clusters.index('NGC_2447')

    met = cluster['FeH_scaled']
    met_err = cluster['e_FeH_scaled']
    col = cluster['GBP_GRP_0']
    col_err = cluster['GBP_GRP_0_error']
    mag = cluster['MG']
    mag_err = cluster['MG_error']
    age_model.ages_prediction(met=met[mask], emet=met_err[mask], col=col[mask], ecol=col_err[mask], mag=mag[mask], emag=mag_err[mask], n=1_000)
    col = col[mask].values
    mag = mag[mask].values
    age = age_model.median_ages()
    mask = np.argsort(mag)[::-1]
    col = col[mask]
    mag = mag[mask]
    age = age[mask]

    for i in range(len(ages_clusters_lit)):
        yerr = np.array([np.log10(ages_clusters_nest[i]*1e9) - np.log10(ages_clusters_nest_unc[i,0]*1e9),
                np.log10(ages_clusters_nest_unc[i,1]*1e9) - np.log10(ages_clusters_nest[i]*1e9)]).reshape(2,1)
        label=None
        lw = 1
        ecolor = 'black'
        if i == len(ages_clusters_lit)/2:
            label=r'BaSTI,NN $\tau$'
        if unique_clusters[i] == 'NGC_2447':
            ecolor = cmaps['Tempo_r'](0.5)
            lw = 2
        
        ax[1].errorbar(np.log10(ages_clusters_lit[i]*1e9),np.log10(ages_clusters_nest[i]*1e9),yerr=yerr,
            fmt='o',
            capsize=7,
            markersize=8,
            color=colors[i],
            ecolor=ecolor,
            elinewidth=lw,
            markeredgecolor=ecolor,
            label=label
        )

        spins_idx = spins_names.index(unique_clusters[i])

        text_pos = max(
            np.log10(ages_clusters_nest_unc[i,1]*1e9),
            spins_mode[spins_idx][1],spins_medians[spins_idx][1]
        )
        
        text_pos += .3
        text_align = 'center'
        x_offset = 0.01
        if np.log10(ages_clusters_lit[i]*1e9) > 9:
            text_pos = min(
                np.log10(ages_clusters_nest_unc[i,0]*1e9),
                spins_mode[spins_idx][0],spins_medians[spins_idx][0]
            )
            text_pos -= .3
            x_offset = 0.02
        if unique_clusters[i] == 'NGC_1039':
            x_offset = -0.01
        ax[1].text(np.log10(ages_clusters_lit[i]*1e9) + x_offset, text_pos, unique_clusters[i].replace('_', ' '),rotation=90,color=ecolor,va=text_align,ha='center')

    cb = plt.colorbar(plt.cm.ScalarMappable(cmap=cmaps['acton'], norm=plt.Normalize(vmin=np.log10(min_stars), vmax=np.log10(max(nbs)-min_stars))),ax=ax[1])
    cb.ax.tick_params(labelsize=14)
    cb.set_label(label=r'$\log_{10}(N_*)$',fontsize=14)

    ax[1].plot([7.75,10.5],[7.75,10.5], color='k', linestyle='--', lw=1)

    ax[1].set_xlim(7.9,10.5)
    ax[1].set_ylim(7.9,10.5)
    legend = ax[1].legend(fontsize=12,loc='lower right')
    legend.get_frame().set_edgecolor('black')
    legend.get_frame().set_linewidth(.5)
    ax[1].set_xlabel(r'$\log_{10}(\tau$ litterature [Gyr])', fontsize=14)
    ax[1].set_ylabel(r'$\log_{10}(\tau$ BaSTI [Gyr])', fontsize=14)

    ax[0].tick_params(labelsize=14)
    ax[1].tick_params(labelsize=14)

    age_model.HR_diagram(fig=fig,ax=ax[0],plot_isochrone=False,plot_stars=False,
                        isochrone_ages=ages_clusters_nest[mask_idx],
                        isochrone_ages_std=((
                            ages_clusters_nest_unc[mask_idx,0],
                            ages_clusters_nest_unc[mask_idx,1]
                        ),))

    cm = ScalarMappable(Normalize(0,2),cmap=cmaps['Tempo_r'])
    cbar = plt.colorbar(cm,ax=ax[0],location='left',pad=0.15)
    cbar.ax.tick_params(labelsize=14)
    cbar.set_label('Age [Gyr]',fontsize=14)

    ax[0].text(-0.45,5.75,'NGC 2447',fontsize=16,color=cmaps['Tempo_r'](0.5))

    ax[0].set_xlim(-0.5,2)
    ax[0].set_ylim(6, -4)
    ax[0].set_xlabel(r'$(G_{BP}-G_{RP})_0$ [mag]', fontsize=14)
    ax[0].set_ylabel(r'$M_G$ [mag]', fontsize=14)

    fig.subplots_adjust(wspace=0.15)

    return fig,ax,col,mag,age,spins_mode,spins_medians,x

fig,ax,col,mag,age,spins_mode,spins_medians,x = base_fig()

if True:
    a = dpl.plot(
        np.sort(x),
        [y[1] for y in spins_mode],
        marker='o',lw=0,
        label=r'SPInS Mode Age $\tau$',
        c=plt.cm.RdYlGn(0.15),
        axis=ax[1]
    )
    b = dpl.plot(
        np.sort(x),
        [y[1] for y in spins_medians],
        marker='o',lw=0,
        label=r'SPInS Median $\tau$',
        c=plt.cm.RdYlGn(0.75),
        axis=ax[1]
    )
    c = dpl.scatter(
        col,mag,
        marker='*',c=age,cmap=cmaps['Tempo_r'],
        axis=ax[0]
    )

    a.draw(duration=100,delay=50)
    b.draw(duration=100,delay=50)
    c.draw(duration=100,delay=50)

    tl = dpl.Timeline(fig=fig,transparent=False)

    if True:
        GUI = dpl.GUI(seq=tl,plot_objects=
            [
                {
                    'name':'SPInS mode age',
                    'object':a
                },
                {
                    'name':'SPInS median age',
                    'object':b
                },
                {
                    'name':'Scatter HR',
                    'object':c
                }
            ]
        )
        GUI.open()
    else:
        d = dpl.fig_width_ratio((.1,1),(1,1.25),50)
        e = dpl.axis_alpha(0,1,duration=25)
        tl.animate((a,b,c,e))
        tl.save_video('ee.mov')
else:
    ax[0].scatter(
        col,mag,
        marker='*',c=age,cmap=cmaps['Tempo_r']
    )
    ax[1].plot(
        np.sort(x),
        [y[1] for y in spins_mode],
        marker='o',lw=0,
        label=r'SPInS Mode Age $\tau$',
        c=plt.cm.RdYlGn(0.15)
    )
    ax[1].plot(
        np.sort(x),
        [y[1] for y in spins_medians],
        marker='o',lw=0,
        label=r'SPInS Median $\tau$',
        c=plt.cm.RdYlGn(0.75)
    )
    plt.savefig('test.png',dpi=200,bbox_inches='tight')