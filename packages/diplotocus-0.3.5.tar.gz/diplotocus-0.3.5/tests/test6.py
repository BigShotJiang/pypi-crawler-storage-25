import diplotocus as dpl
import matplotlib.pyplot as plt

fig,ax = plt.subplots(1,2,figsize=(17,5),width_ratios=(1,1.25))

a = dpl.scatter((0,1),(2,3))
b = dpl.plot((0,1),(2,3))
c = dpl.scatter((1,0),(2,3),axis=ax[1])
d = dpl.plot((1,0),(2,3),axis=ax[1])
a.show(100)
b.show(100)
c.show(100)
d.show(100)

a.hide(100,delay=150)

cb = plt.colorbar(plt.cm.ScalarMappable(norm=plt.Normalize(vmin=0, vmax=1)),ax=ax[1])
cb.ax.tick_params(labelsize=14)
cb.set_label(label=r'$\log_{10}(N_*)$',fontsize=14)

e = dpl.fig_width_ratio((1e-2,1),(1,1.25),50)
f = dpl.axis_alpha(0,1,10,axis=ax[1])

tl = dpl.Timeline(fig=fig,transparent=True,white=True)

#seq.animate((a,b,c,d,e,f))
tl.animate(a)

tl.save_video('ee2.mov')