import diplotocus as dpl
import matplotlib.pyplot as plt
import numpy as np

if False:
    fig,ax = plt.subplots(2,1)
    ax[0].set_xlim(0,4*np.pi)
    ax[0].set_ylim(-1,1)
    ax[1].set_xlim(0,4*np.pi)
    ax[1].set_ylim(-1,1)

    tl = dpl.Timeline(fig=fig,white=True,transparent=True)

    x = np.linspace(0,4*np.pi,100)
    y = np.cos(x)

    fill = dpl.fill_between(x,y1=-np.ones_like(x),y2=y,axis=ax[1])
    fill.draw(100)

    plot = dpl.step(x,y,axis=ax[0])
    plot.draw(100)

    axis = dpl.axis(ax[1])
    axis.axis_alpha(0,1,100)

    tl.save_project('/Users/titanbin/Downloads/test2.dpl')
else:
    tl,anims = dpl.load_project('/Users/titanbin/Downloads/test2.dpl')
    tl.animate(anims)
    tl.save_video('test5.mov')