import numpy as np
import matplotlib.pyplot as plt
import diplotocus as dpl

x = np.linspace(0,2*np.pi,100)
y = np.cos(x)

fig,ax = plt.subplots(1,2,figsize=(10,5))
ax[0].set_xlim(-0.1,x[-1]+0.1)
ax[0].set_ylim(-1.1,1.1)
ax[1].set_xlim(0,2*np.pi)
ax[1].set_ylim(0,300)
tl = dpl.Timeline(fig=fig,transparent=True,white=True)

s = dpl.scatter(x=x,y=y,axis=ax[0])
e1 = dpl.easeInOutQuad()

if True:
    a1 = dpl.axis_alpha(0,0,1,axis=ax[0])
    a2 = dpl.axis_alpha(0,0,1,axis=ax[1])
    f = dpl.fig_width_ratio((1,0),(1,0),1)
    tl.animate((a1,a2,f))

    s.draw(50,easing=e1)
    tl.animate(s)

    e2 = dpl.easeOutBounce()
    a1 = dpl.axis_alpha(0,1,50,axis=ax[0],alpha_objs=False)
    a2 = dpl.axis_alpha(0,1,50,axis=ax[1],alpha_objs=False)
    f = dpl.fig_width_ratio((1,0),(1,1),50,easing=e2,delay=25)
    tl.animate((a1,a2,f))

    x2 = np.cos(x)
    y2 = np.sin(x)
    s.morph(x2,y2,50,easing=e1)
    a1 = dpl.axis_limits(50,(-1.1,1.1),easing=e1)
    tl.animate((a1,s))

    s.rotate(0,360*3,100,easing=e1,center=(0,0))
    s.tween('color','C0','C1',50)
    s.tween('s',40,250,50)
    s.tween('color','C1','C2',50,delay=50)
    s.tween('s',250,0,50,delay=50)
    tl.animate(s)

x2 = np.random.normal(np.pi,1,10_000)
h = dpl.hist(x=x2,bins=np.linspace(0,2*np.pi,100),axis=ax[1])
h.draw(50,easing=e1)
tl.animate(h)

x3 = 2*x2-np.pi
h.morph(x3,50,easing=e1)
tl.animate(h)

tl.save_video('test.mov')