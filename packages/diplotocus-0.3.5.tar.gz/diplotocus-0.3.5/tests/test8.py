import diplotocus as dpl
import numpy as np
import matplotlib.pyplot as plt

x = np.linspace(0,2*np.pi,100)
y = np.cos(x)

a = dpl.scatter(x,y)
b = dpl.plot(x,y*2)

fig,ax = plt.subplots(figsize=(10,5))
#ax.set_axis_off()
ax.set_xlim(0,2*np.pi)
ax.set_ylim(-1,1)

tl = dpl.Timeline(fig=fig,transparent=True,white=True)

GUI = dpl.GUI(tl,[
        {
            'name':'scatter',
            'object':a,
            'new_x':x,
            'new_y':y/2
        },
        {
            'name':'plot',
            'object':b
        }
    ])