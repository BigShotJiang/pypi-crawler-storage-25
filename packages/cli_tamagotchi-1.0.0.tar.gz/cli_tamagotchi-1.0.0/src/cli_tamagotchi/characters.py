from __future__ import annotations

import random
from dataclasses import dataclass
from enum import Enum

FALLBACK_CHARACTER = "Cat"


class Rarity(str, Enum):
    COMMON = "common"
    UNCOMMON = "uncommon"
    RARE = "rare"
    EPIC = "epic"
    LEGENDARY = "legendary"


RARITY_DISPLAY = {
    Rarity.COMMON: "Common",
    Rarity.UNCOMMON: "Uncommon",
    Rarity.RARE: "Rare",
    Rarity.EPIC: "Epic",
    Rarity.LEGENDARY: "Legendary",
}


@dataclass(frozen=True)
class CharacterSpec:
    character_id: str
    rarity: Rarity
    roll_weight: int
    rich_style: str
    healthy_weight_min: int
    healthy_weight_max: int


CHARACTER_POOL: tuple[CharacterSpec, ...] = (
    CharacterSpec(
        character_id="Cat",
        rarity=Rarity.COMMON,
        roll_weight=48,
        rich_style="bright_cyan",
        healthy_weight_min=3,
        healthy_weight_max=26,
    ),
    CharacterSpec(
        character_id="Dog",
        rarity=Rarity.UNCOMMON,
        roll_weight=25,
        rich_style="bright_yellow",
        healthy_weight_min=3,
        healthy_weight_max=24,
    ),
    CharacterSpec(
        character_id="Fox",
        rarity=Rarity.RARE,
        roll_weight=17,
        rich_style="bright_magenta",
        healthy_weight_min=2,
        healthy_weight_max=20,
    ),
    CharacterSpec(
        character_id="Owl",
        rarity=Rarity.EPIC,
        roll_weight=10,
        rich_style="bright_blue",
        healthy_weight_min=2,
        healthy_weight_max=18,
    ),
)

_CHARACTER_RARITY: dict[str, Rarity] = {spec.character_id: spec.rarity for spec in CHARACTER_POOL}
_CHARACTER_WEIGHTS: tuple[tuple[str, int], ...] = tuple(
    (spec.character_id, spec.roll_weight) for spec in CHARACTER_POOL
)

CHARACTER_STYLE_BY_NAME: dict[str, str] = {spec.character_id: spec.rich_style for spec in CHARACTER_POOL}


def healthy_weight_bounds(character_id: str) -> tuple[int, int]:
    for spec in CHARACTER_POOL:
        if spec.character_id == character_id:
            return (spec.healthy_weight_min, spec.healthy_weight_max)
    return (3, 26)


def rarity_for_character(character_id: str) -> Rarity:
    return _CHARACTER_RARITY.get(character_id, Rarity.COMMON)


def rarity_display_for_character(character_id: str) -> str:
    return RARITY_DISPLAY[rarity_for_character(character_id)]


def character_status_label(character_id: str) -> str:
    return f"{character_id} ({rarity_display_for_character(character_id)})"


def roll_starting_character(rng: random.Random | None = None) -> str:
    random_source = rng if rng is not None else random.Random()
    character_ids = [pair[0] for pair in _CHARACTER_WEIGHTS]
    weights = [pair[1] for pair in _CHARACTER_WEIGHTS]
    chosen = random_source.choices(character_ids, weights=weights, k=1)[0]
    return chosen
