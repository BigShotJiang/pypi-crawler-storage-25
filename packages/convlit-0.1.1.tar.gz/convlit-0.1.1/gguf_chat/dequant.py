from __future__ import annotations

from typing import Callable, Dict, Tuple

import torch

# GGML tensor type ids (ggml/docs/gguf.md)
GGML_TYPE_F32 = 0
GGML_TYPE_F16 = 1
GGML_TYPE_Q4_K = 12
GGML_TYPE_Q5_K = 13
GGML_TYPE_Q6_K = 14
GGML_TYPE_IQ4_XS = 23

QK_K = 256
K_SCALE_SIZE = 12

# (From ggml-common.h) bytes per quant block
QUANT_BLOCK_SIZES: Dict[int, Tuple[int, int]] = {
    GGML_TYPE_F32: (1, 4),
    GGML_TYPE_F16: (1, 2),
    GGML_TYPE_Q4_K: (QK_K, 2 + 2 + K_SCALE_SIZE + QK_K // 2),  # 144
    GGML_TYPE_Q5_K: (QK_K, 2 + 2 + K_SCALE_SIZE + QK_K // 8 + QK_K // 2),  # 176
    GGML_TYPE_Q6_K: (QK_K, QK_K // 2 + QK_K // 4 + QK_K // 16 + 2),  # 210
    GGML_TYPE_IQ4_XS: (QK_K, 2 + 2 + QK_K // 64 + QK_K // 2),  # 136
}


def _to_uint32(x: torch.Tensor) -> torch.Tensor:
    # no uint32 :( - pack little-endian bytes into int32
    x = x.view(torch.uint8).to(torch.int32)
    return (x[:, 0] | (x[:, 1] << 8) | (x[:, 2] << 16) | (x[:, 3] << 24)).unsqueeze(1)


def _to_uint16(x: torch.Tensor) -> torch.Tensor:
    x = x.view(torch.uint8).to(torch.int32)
    return (x[:, 0] | (x[:, 1] << 8)).unsqueeze(1)


def _split_block_dims(blocks: torch.Tensor, *sizes: int) -> Tuple[torch.Tensor, ...]:
    n_max = blocks.shape[1]
    dims = list(sizes) + [n_max - sum(sizes)]
    return torch.split(blocks, dims, dim=1)


def _get_scale_min(scales: torch.Tensor) -> Tuple[torch.Tensor, torch.Tensor]:
    # Ported from city96/ComfyUI-GGUF (Apache-2.0), adapted for our runner.
    n_blocks = scales.shape[0]
    scales = scales.view(torch.uint8).reshape((n_blocks, 3, 4))
    d, m, m_d = torch.split(scales, scales.shape[-2] // 3, dim=-2)
    sc = torch.cat([d & 0x3F, (m_d & 0x0F) | ((d >> 2) & 0x30)], dim=-1)
    mn = torch.cat([m & 0x3F, (m_d >> 4) | ((m >> 2) & 0x30)], dim=-1)
    return sc.reshape((n_blocks, 8)), mn.reshape((n_blocks, 8))


def _dequantize_blocks_q6_k(blocks: torch.Tensor, *, dtype: torch.dtype) -> torch.Tensor:
    n_blocks = blocks.shape[0]
    ql, qh, scales, d = _split_block_dims(blocks, QK_K // 2, QK_K // 4, QK_K // 16)
    scales = scales.view(torch.int8).to(dtype)
    d = d.view(torch.float16).to(dtype)
    d = (d * scales).reshape((n_blocks, QK_K // 16, 1))

    ql = ql.reshape((n_blocks, -1, 1, 64)) >> torch.tensor([0, 4], device=d.device, dtype=torch.uint8).reshape(
        (1, 1, 2, 1)
    )
    ql = (ql & 0x0F).reshape((n_blocks, -1, 32))

    qh = qh.reshape((n_blocks, -1, 1, 32)) >> torch.tensor([0, 2, 4, 6], device=d.device, dtype=torch.uint8).reshape(
        (1, 1, 4, 1)
    )
    qh = (qh & 0x03).reshape((n_blocks, -1, 32))

    q = (ql | (qh << 4)).to(torch.int8) - 32
    q = q.reshape((n_blocks, QK_K // 16, -1))
    return (d * q).reshape((n_blocks, QK_K))


def _dequantize_blocks_q5_k(blocks: torch.Tensor, *, dtype: torch.dtype) -> torch.Tensor:
    n_blocks = blocks.shape[0]
    d, dmin, scales, qh, qs = _split_block_dims(blocks, 2, 2, K_SCALE_SIZE, QK_K // 8)
    d = d.view(torch.float16).to(dtype)
    dmin = dmin.view(torch.float16).to(dtype)
    sc, m = _get_scale_min(scales)
    d = (d * sc).reshape((n_blocks, -1, 1))
    dm = (dmin * m).reshape((n_blocks, -1, 1))

    ql = qs.reshape((n_blocks, -1, 1, 32)) >> torch.tensor([0, 4], device=d.device, dtype=torch.uint8).reshape(
        (1, 1, 2, 1)
    )
    qh = qh.reshape((n_blocks, -1, 1, 32)) >> torch.tensor([i for i in range(8)], device=d.device, dtype=torch.uint8).reshape(
        (1, 1, 8, 1)
    )
    ql = (ql & 0x0F).reshape((n_blocks, -1, 32))
    qh = (qh & 0x01).reshape((n_blocks, -1, 32))
    q = (ql | (qh << 4))
    return (d * q - dm).reshape((n_blocks, QK_K))


def _dequantize_blocks_q4_k(blocks: torch.Tensor, *, dtype: torch.dtype) -> torch.Tensor:
    n_blocks = blocks.shape[0]
    d, dmin, scales, qs = _split_block_dims(blocks, 2, 2, K_SCALE_SIZE)
    d = d.view(torch.float16).to(dtype)
    dmin = dmin.view(torch.float16).to(dtype)
    sc, m = _get_scale_min(scales)
    d = (d * sc).reshape((n_blocks, -1, 1))
    dm = (dmin * m).reshape((n_blocks, -1, 1))

    qs = qs.reshape((n_blocks, -1, 1, 32)) >> torch.tensor([0, 4], device=d.device, dtype=torch.uint8).reshape(
        (1, 1, 2, 1)
    )
    qs = (qs & 0x0F).reshape((n_blocks, -1, 32))
    return (d * qs - dm).reshape((n_blocks, QK_K))


_KVALUES = torch.tensor(
    [-127, -104, -83, -65, -49, -35, -22, -10, 1, 13, 25, 38, 53, 69, 89, 113],
    dtype=torch.int8,
)


def _dequantize_blocks_iq4_xs(blocks: torch.Tensor, *, dtype: torch.dtype) -> torch.Tensor:
    n_blocks = blocks.shape[0]
    d, scales_h, scales_l, qs = _split_block_dims(blocks, 2, 2, QK_K // 64)
    d = d.view(torch.float16).to(dtype)

    scales_h = _to_uint16(scales_h)
    shift_a = torch.tensor([0, 4], device=d.device, dtype=torch.uint8).reshape((1, 1, 2))
    shift_b = torch.tensor([2 * i for i in range(QK_K // 32)], device=d.device, dtype=torch.uint8).reshape((1, -1, 1))

    scales_l = scales_l.reshape((n_blocks, -1, 1)) >> shift_a.reshape((1, 1, 2))
    scales_h = scales_h.reshape((n_blocks, -1, 1)) >> shift_b.reshape((1, -1, 1))

    scales_l = scales_l.reshape((n_blocks, -1)) & 0x0F
    scales_h = scales_h.reshape((n_blocks, -1)).to(torch.uint8) & 0x03
    scales = (scales_l | (scales_h << 4)).to(torch.int8) - 32

    dl = (d * scales.to(dtype)).reshape((n_blocks, -1, 1))

    qs = qs.reshape((n_blocks, -1, 1, 16)) >> shift_a.reshape((1, 1, 2, 1))
    qs = qs.reshape((n_blocks, -1, 32, 1)) & 0x0F

    kvalues = _KVALUES.to(qs.device).expand(*qs.shape[:-1], 16)
    qs = torch.gather(kvalues, dim=-1, index=qs.to(torch.int64)).reshape((n_blocks, -1, 32))

    return (dl * qs).reshape((n_blocks, -1))


_DEQUANT_FUNCS: Dict[int, Callable[[torch.Tensor], torch.Tensor]] = {
    GGML_TYPE_Q4_K: lambda b, *, _dtype=None: _dequantize_blocks_q4_k(b, dtype=_dtype),  # type: ignore[misc]
    GGML_TYPE_Q5_K: lambda b, *, _dtype=None: _dequantize_blocks_q5_k(b, dtype=_dtype),  # type: ignore[misc]
    GGML_TYPE_Q6_K: lambda b, *, _dtype=None: _dequantize_blocks_q6_k(b, dtype=_dtype),  # type: ignore[misc]
    GGML_TYPE_IQ4_XS: lambda b, *, _dtype=None: _dequantize_blocks_iq4_xs(b, dtype=_dtype),  # type: ignore[misc]
}


def dequantize_blocks(blocks: torch.Tensor, ggml_type: int, *, dtype: torch.dtype) -> torch.Tensor:
    if ggml_type not in _DEQUANT_FUNCS:
        raise ValueError(f"Unsupported quant type for dequantize: {ggml_type}")
    return _DEQUANT_FUNCS[ggml_type](blocks, _dtype=dtype)  # type: ignore[call-arg]

