from __future__ import annotations

from pathlib import Path
from typing import List, Tuple

import torch

from .gguf_reader import GGUFReader
from .model import LlamaConfig, LlamaModel, LlamaWeights


def _find_special_id(tokens: List[str], s: str) -> int:
    try:
        return tokens.index(s)
    except ValueError as exc:
        raise KeyError(f"Special token not found in vocab: {s}") from exc


def load_llama_from_gguf(
    model_path: str | Path,
    *,
    n_ctx: int = 4096,
    dtype: torch.dtype = torch.float16,
    device: torch.device | None = None,
) -> Tuple[LlamaModel, "gguf_chat.tokenizer.LlamaBPETokenizer"]:  # type: ignore[name-defined]
    """
    Loads a GGUF `llama` architecture model (Llama-3.x style, GQA) into a small
    custom PyTorch runner. This does not use llama.cpp or llama-cpp-python.
    """
    device = device or torch.device("cpu")

    # NOTE:
    # We intentionally keep the GGUF mmap open for the lifetime of the model.
    # `GGUFReader.load_tensor()` uses `torch.frombuffer(self._mmap, ...)` for
    # F16/F32 tensors, which shares memory with the mmap. Closing the mmap would
    # invalidate those tensors and can crash the process (use-after-close).
    r = GGUFReader(model_path)
    try:
        arch = r.get_meta("general.architecture")
        if arch != "llama":
            raise ValueError(f"Unsupported architecture: {arch!r} (only 'llama' supported)")

        vocab_size = int(r.get_meta("llama.vocab_size"))
        dim = int(r.get_meta("llama.embedding_length"))
        n_layers = int(r.get_meta("llama.block_count"))
        n_heads = int(r.get_meta("llama.attention.head_count"))
        n_kv_heads = int(r.get_meta("llama.attention.head_count_kv"))
        ffn_dim = int(r.get_meta("llama.feed_forward_length"))
        rms_eps = float(r.get_meta("llama.attention.layer_norm_rms_epsilon"))
        rope_theta = float(r.get_meta("llama.rope.freq_base", 10000.0))
        rope_dim = int(r.get_meta("llama.rope.dimension_count", dim // n_heads))

        head_dim = dim // n_heads

        tokens: List[str] = r.get_meta("tokenizer.ggml.tokens")
        merges: List[str] = r.get_meta("tokenizer.ggml.merges")

        from .tokenizer import LlamaBPETokenizer  # local import to avoid cycles

        tok = LlamaBPETokenizer(tokens=tokens, merges=merges)

        bos_id = int(r.get_meta("tokenizer.ggml.bos_token_id", _find_special_id(tokens, "<|begin_of_text|>")))
        eos_id = int(r.get_meta("tokenizer.ggml.eos_token_id", _find_special_id(tokens, "<|end_of_text|>")))
        eot_id = _find_special_id(tokens, "<|eot_id|>")
        start_header_id = _find_special_id(tokens, "<|start_header_id|>")
        end_header_id = _find_special_id(tokens, "<|end_header_id|>")

        cfg = LlamaConfig(
            vocab_size=vocab_size,
            dim=dim,
            n_layers=n_layers,
            n_heads=n_heads,
            n_kv_heads=n_kv_heads,
            head_dim=head_dim,
            ffn_dim=ffn_dim,
            rms_eps=rms_eps,
            bos_id=bos_id,
            eos_id=eos_id,
            eot_id=eot_id,
            start_header_id=start_header_id,
            end_header_id=end_header_id,
        )

        # Load tensors
        tok_emb = r.load_tensor("token_embd.weight", dtype=dtype).to(device=device)
        out_norm = r.load_tensor("output_norm.weight", dtype=torch.float32).to(device=device)
        # Some GGUFs include `rope_freqs.weight` as a placeholder (often all 1s),
        # while the actual base frequency is provided via `llama.rope.freq_base`.
        # Compute the standard RoPE inverse frequencies from metadata to match
        # HF/Meta implementations: inv_freq[i] = 1/(theta**(2*i/rope_dim)).
        freq_seq = torch.arange(0, rope_dim, 2, dtype=torch.float32)
        rope_inv_freq = (1.0 / (rope_theta ** (freq_seq / float(rope_dim)))).to(device=device)

        attn_norm: List[torch.Tensor] = []
        ffn_norm: List[torch.Tensor] = []
        wq: List[torch.Tensor] = []
        wk: List[torch.Tensor] = []
        wv: List[torch.Tensor] = []
        wo: List[torch.Tensor] = []
        w_gate: List[torch.Tensor] = []
        w_up: List[torch.Tensor] = []
        w_down: List[torch.Tensor] = []

        for i in range(n_layers):
            attn_norm.append(r.load_tensor(f"blk.{i}.attn_norm.weight", dtype=torch.float32).to(device=device))
            ffn_norm.append(r.load_tensor(f"blk.{i}.ffn_norm.weight", dtype=torch.float32).to(device=device))

            wq.append(r.load_tensor(f"blk.{i}.attn_q.weight", dtype=dtype).to(device=device))
            wk.append(r.load_tensor(f"blk.{i}.attn_k.weight", dtype=dtype).to(device=device))
            wv.append(r.load_tensor(f"blk.{i}.attn_v.weight", dtype=dtype).to(device=device))
            wo.append(r.load_tensor(f"blk.{i}.attn_output.weight", dtype=dtype).to(device=device))

            w_gate.append(r.load_tensor(f"blk.{i}.ffn_gate.weight", dtype=dtype).to(device=device))
            w_up.append(r.load_tensor(f"blk.{i}.ffn_up.weight", dtype=dtype).to(device=device))
            w_down.append(r.load_tensor(f"blk.{i}.ffn_down.weight", dtype=dtype).to(device=device))
    except Exception:
        r.close()
        raise

    weights = LlamaWeights(
        tok_emb=tok_emb,
        out_norm=out_norm,
        rope_inv_freq=rope_inv_freq,
        attn_norm=attn_norm,
        ffn_norm=ffn_norm,
        wq=wq,
        wk=wk,
        wv=wv,
        wo=wo,
        w_gate=w_gate,
        w_up=w_up,
        w_down=w_down,
    )
    model = LlamaModel(cfg, weights, device=device, dtype=dtype)
    # Keep the reader alive to keep its mmap valid.
    model._gguf_reader = r  # type: ignore[attr-defined]
    return model, tok
