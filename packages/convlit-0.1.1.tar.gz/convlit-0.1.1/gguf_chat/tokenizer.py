from __future__ import annotations

import codecs
from dataclasses import dataclass
from typing import Dict, Iterable, List, Sequence, Set, Tuple

import regex as re


def bytes_to_unicode() -> Dict[int, str]:
    # Matches OpenAI GPT-2 / HF GPT2Tokenizer mapping.
    bs = list(range(ord("!"), ord("~") + 1)) + list(range(ord("¡"), ord("¬") + 1)) + list(range(ord("®"), ord("ÿ") + 1))
    cs = bs[:]
    n = 0
    for b in range(256):
        if b not in bs:
            bs.append(b)
            cs.append(256 + n)
            n += 1
    return dict(zip(bs, [chr(c) for c in cs]))


def get_pairs(word: Tuple[str, ...]) -> Set[Tuple[str, str]]:
    pairs: Set[Tuple[str, str]] = set()
    prev_char = word[0]
    for ch in word[1:]:
        pairs.add((prev_char, ch))
        prev_char = ch
    return pairs


# Llama 3 BPE pre-tokenizer regex (a CL100K-style pattern).
# NOTE: requires the `regex` module (Unicode properties like \\p{L})
CL100K_PATTERN = (
    r"(?i:'s|'t|'re|'ve|'m|'ll|'d)"
    r"|[^\r\n\p{L}\p{N}]?\p{L}+"
    r"|\p{N}{1,3}"
    r"| ?[^\s\p{L}\p{N}]+[\r\n]*"
    r"|\s*[\r\n]+"
    r"|\s+(?!\S)"
    r"|\s+"
)


@dataclass(frozen=True)
class SpecialTokens:
    bos: int
    eos: int
    eot: int
    start_header: int
    end_header: int


class LlamaBPETokenizer:
    def __init__(self, tokens: Sequence[str], merges: Sequence[str]):
        self.encoder: Dict[str, int] = {t: i for i, t in enumerate(tokens)}
        self.decoder: List[str] = list(tokens)
        self.bpe_ranks: Dict[Tuple[str, str], int] = {}

        for i, m in enumerate(merges):
            a, b = m.split(" ", 1)
            self.bpe_ranks[(a, b)] = i

        self.byte_encoder = bytes_to_unicode()
        self.byte_decoder = {v: k for k, v in self.byte_encoder.items()}
        self.cache: Dict[str, str] = {}
        self.pat = re.compile(CL100K_PATTERN)

    def bpe(self, token: str) -> str:
        cached = self.cache.get(token)
        if cached is not None:
            return cached

        word = tuple(token)
        pairs = get_pairs(word)
        if not pairs:
            self.cache[token] = token
            return token

        while True:
            bigram = min(pairs, key=lambda p: self.bpe_ranks.get(p, float("inf")))
            if bigram not in self.bpe_ranks:
                break
            first, second = bigram

            new_word: List[str] = []
            i = 0
            while i < len(word):
                try:
                    j = word.index(first, i)
                    new_word.extend(word[i:j])
                    i = j
                except ValueError:
                    new_word.extend(word[i:])
                    i = len(word)
                    break

                if i < len(word) - 1 and word[i] == first and word[i + 1] == second:
                    new_word.append(first + second)
                    i += 2
                else:
                    new_word.append(word[i])
                    i += 1

            word = tuple(new_word)
            if len(word) == 1:
                break
            pairs = get_pairs(word)

        out = " ".join(word)
        self.cache[token] = out
        return out

    def encode(self, text: str) -> List[int]:
        bpe_tokens: List[int] = []
        for piece in self.pat.findall(text):
            piece_bytes = piece.encode("utf-8")
            piece_transformed = "".join(self.byte_encoder[b] for b in piece_bytes)
            for bpe_tok in self.bpe(piece_transformed).split(" "):
                tok_id = self.encoder.get(bpe_tok)
                if tok_id is None:
                    raise KeyError(f"Token not in vocab: {bpe_tok!r}")
                bpe_tokens.append(tok_id)
        return bpe_tokens

    def decode_stream(self, token_ids: Iterable[int]) -> str:
        # Convenience: decode all at once
        buf = "".join(self.decoder[t] for t in token_ids)
        out_bytes = bytearray(self.byte_decoder[c] for c in buf)
        return out_bytes.decode("utf-8", errors="replace")

    def incremental_decoder(self) -> "IncrementalDecoder":
        return IncrementalDecoder(self.decoder, self.byte_decoder)


class IncrementalDecoder:
    def __init__(self, decoder: Sequence[str], byte_decoder: Dict[str, int]):
        self._decoder = decoder
        self._byte_decoder = byte_decoder
        self._utf8 = codecs.getincrementaldecoder("utf-8")(errors="replace")

    def decode_token(self, token_id: int) -> str:
        s = self._decoder[token_id]
        bs = bytes(self._byte_decoder[c] for c in s)
        return self._utf8.decode(bs)

    def flush(self) -> str:
        return self._utf8.decode(b"", final=True)

