from __future__ import annotations

import math
from dataclasses import dataclass
from typing import List

import torch
import torch.nn.functional as F


@dataclass(frozen=True)
class LlamaConfig:
    vocab_size: int
    dim: int
    n_layers: int
    n_heads: int
    n_kv_heads: int
    head_dim: int
    ffn_dim: int
    rms_eps: float

    bos_id: int
    eos_id: int
    eot_id: int
    start_header_id: int
    end_header_id: int


class KVCache:
    def __init__(self, cfg: LlamaConfig, max_seq_len: int, *, dtype: torch.dtype, device: torch.device):
        self.max_seq_len = max_seq_len
        self.k = torch.empty((cfg.n_layers, cfg.n_kv_heads, max_seq_len, cfg.head_dim), dtype=dtype, device=device)
        self.v = torch.empty((cfg.n_layers, cfg.n_kv_heads, max_seq_len, cfg.head_dim), dtype=dtype, device=device)
        self.pos = 0

    def reset(self) -> None:
        self.pos = 0


def rms_norm(x: torch.Tensor, weight: torch.Tensor, eps: float) -> torch.Tensor:
    # x: (..., dim)
    x32 = x.float()
    var = x32.pow(2).mean(dim=-1, keepdim=True)
    y = x32 * torch.rsqrt(var + eps)
    return (y * weight.float()).to(dtype=x.dtype)


def apply_rope(x: torch.Tensor, cos: torch.Tensor, sin: torch.Tensor) -> torch.Tensor:
    # x: (heads, head_dim), cos/sin: (head_dim/2,)
    x_ = x.view(x.shape[0], -1, 2)
    x1 = x_[..., 0]
    x2 = x_[..., 1]
    # broadcast cos/sin: (1, head_dim/2)
    cos = cos.unsqueeze(0)
    sin = sin.unsqueeze(0)
    o1 = x1 * cos - x2 * sin
    o2 = x1 * sin + x2 * cos
    return torch.stack((o1, o2), dim=-1).flatten(-2)


class LlamaWeights:
    def __init__(
        self,
        *,
        tok_emb: torch.Tensor,  # (vocab, dim)
        out_norm: torch.Tensor,  # (dim,)
        rope_inv_freq: torch.Tensor,  # (head_dim/2,)
        attn_norm: List[torch.Tensor],
        ffn_norm: List[torch.Tensor],
        wq: List[torch.Tensor],
        wk: List[torch.Tensor],
        wv: List[torch.Tensor],
        wo: List[torch.Tensor],
        w_gate: List[torch.Tensor],
        w_up: List[torch.Tensor],
        w_down: List[torch.Tensor],
    ):
        self.tok_emb = tok_emb
        self.out_norm = out_norm
        self.rope_inv_freq = rope_inv_freq

        self.attn_norm = attn_norm
        self.ffn_norm = ffn_norm
        self.wq = wq
        self.wk = wk
        self.wv = wv
        self.wo = wo
        self.w_gate = w_gate
        self.w_up = w_up
        self.w_down = w_down


class LlamaModel:
    def __init__(self, cfg: LlamaConfig, w: LlamaWeights, *, device: torch.device, dtype: torch.dtype):
        self.cfg = cfg
        self.w = w
        self.device = device
        self.dtype = dtype

    @torch.no_grad()
    def forward_one(self, token_id: int, cache: KVCache) -> torch.Tensor:
        cfg = self.cfg
        pos = cache.pos
        if pos >= cache.max_seq_len:
            raise RuntimeError(f"Context overflow: pos={pos} max_seq_len={cache.max_seq_len}")

        x = self.w.tok_emb[token_id].to(device=self.device, dtype=self.dtype)

        # precompute cos/sin for this position from inv_freq
        inv_freq = self.w.rope_inv_freq.to(device=self.device)
        freqs = (inv_freq * pos).to(dtype=torch.float32)
        cos = torch.cos(freqs).to(dtype=self.dtype)
        sin = torch.sin(freqs).to(dtype=self.dtype)

        n_rep = cfg.n_heads // cfg.n_kv_heads
        scale = 1.0 / math.sqrt(cfg.head_dim)

        for i in range(cfg.n_layers):
            # Attention
            x_norm = rms_norm(x, self.w.attn_norm[i], cfg.rms_eps)

            q = torch.matmul(self.w.wq[i], x_norm)  # (dim,)
            k = torch.matmul(self.w.wk[i], x_norm)  # (kv_dim,)
            v = torch.matmul(self.w.wv[i], x_norm)  # (kv_dim,)

            q = q.view(cfg.n_heads, cfg.head_dim)
            k = k.view(cfg.n_kv_heads, cfg.head_dim)
            v = v.view(cfg.n_kv_heads, cfg.head_dim)

            q = apply_rope(q, cos, sin)
            k = apply_rope(k, cos, sin)

            cache.k[i, :, pos, :] = k
            cache.v[i, :, pos, :] = v

            k_ctx = cache.k[i, :, : pos + 1, :]  # (kv_heads, seq, head_dim)
            v_ctx = cache.v[i, :, : pos + 1, :]

            # Grouped-query attention without kv repetition:
            qg = q.view(cfg.n_kv_heads, n_rep, cfg.head_dim)  # (kv_heads, rep, head_dim)
            out_groups: List[torch.Tensor] = []
            for h in range(cfg.n_kv_heads):
                # (rep, head_dim) @ (head_dim, seq) -> (rep, seq)
                scores = torch.matmul(qg[h], k_ctx[h].transpose(0, 1)) * scale
                attn = F.softmax(scores.float(), dim=-1).to(dtype=self.dtype)
                out = torch.matmul(attn, v_ctx[h])  # (rep, head_dim)
                out_groups.append(out)
            attn_out = torch.cat(out_groups, dim=0).reshape(cfg.dim)  # (dim,)

            x = x + torch.matmul(self.w.wo[i], attn_out)

            # FFN (SwiGLU)
            x_norm = rms_norm(x, self.w.ffn_norm[i], cfg.rms_eps)
            gate = torch.matmul(self.w.w_gate[i], x_norm)  # (ffn,)
            up = torch.matmul(self.w.w_up[i], x_norm)  # (ffn,)
            ff = F.silu(gate) * up
            x = x + torch.matmul(self.w.w_down[i], ff)

        x = rms_norm(x, self.w.out_norm, cfg.rms_eps)
        logits = torch.matmul(self.w.tok_emb, x)  # (vocab,)

        cache.pos += 1
        return logits

