from __future__ import annotations

import mmap
import struct
from dataclasses import dataclass
from pathlib import Path
from typing import Any, BinaryIO, Dict, List, Optional, Tuple

import torch

from .dequant import QUANT_BLOCK_SIZES, dequantize_blocks


GGUF_MAGIC = b"GGUF"
GGUF_DEFAULT_ALIGNMENT = 32


class GGUFValueType:
    UINT8 = 0
    INT8 = 1
    UINT16 = 2
    INT16 = 3
    UINT32 = 4
    INT32 = 5
    FLOAT32 = 6
    BOOL = 7
    STRING = 8
    ARRAY = 9
    UINT64 = 10
    INT64 = 11
    FLOAT64 = 12


@dataclass(frozen=True)
class TensorInfo:
    name: str
    shape: Tuple[int, ...]  # already reversed to logical shape
    ggml_type: int
    offset: int  # relative to data section start
    n_bytes: int


def _align(offset: int, alignment: int) -> int:
    if alignment <= 0:
        return offset
    rem = offset % alignment
    return offset if rem == 0 else offset + (alignment - rem)


def _read_u32(f: BinaryIO) -> int:
    return struct.unpack("<I", f.read(4))[0]


def _read_u64(f: BinaryIO) -> int:
    return struct.unpack("<Q", f.read(8))[0]


def _read_i64(f: BinaryIO) -> int:
    return struct.unpack("<q", f.read(8))[0]


def _read_string(f: BinaryIO) -> str:
    n = _read_u64(f)
    return f.read(n).decode("utf-8", errors="replace")


def _read_value(f: BinaryIO, t: int) -> Any:
    if t == GGUFValueType.UINT8:
        return struct.unpack("<B", f.read(1))[0]
    if t == GGUFValueType.INT8:
        return struct.unpack("<b", f.read(1))[0]
    if t == GGUFValueType.UINT16:
        return struct.unpack("<H", f.read(2))[0]
    if t == GGUFValueType.INT16:
        return struct.unpack("<h", f.read(2))[0]
    if t == GGUFValueType.UINT32:
        return struct.unpack("<I", f.read(4))[0]
    if t == GGUFValueType.INT32:
        return struct.unpack("<i", f.read(4))[0]
    if t == GGUFValueType.FLOAT32:
        return struct.unpack("<f", f.read(4))[0]
    if t == GGUFValueType.BOOL:
        return struct.unpack("<B", f.read(1))[0] != 0
    if t == GGUFValueType.STRING:
        return _read_string(f)
    if t == GGUFValueType.UINT64:
        return struct.unpack("<Q", f.read(8))[0]
    if t == GGUFValueType.INT64:
        return struct.unpack("<q", f.read(8))[0]
    if t == GGUFValueType.FLOAT64:
        return struct.unpack("<d", f.read(8))[0]
    if t == GGUFValueType.ARRAY:
        elem_t = _read_u32(f)
        ln = _read_u64(f)
        out: List[Any] = []
        for _ in range(ln):
            out.append(_read_value(f, elem_t))
        return out
    raise ValueError(f"Unknown GGUF value type: {t}")


class GGUFReader:
    def __init__(self, path: str | Path):
        self.path = Path(path)
        self._file = self.path.open("rb")
        self._mmap = mmap.mmap(self._file.fileno(), 0, access=mmap.ACCESS_READ)

        self.version: int
        self.tensor_count: int
        self.meta: Dict[str, Any] = {}
        self.tensors: Dict[str, TensorInfo] = {}
        self.data_start: int
        self.alignment: int = GGUF_DEFAULT_ALIGNMENT

        self._parse()

    def close(self) -> None:
        try:
            self._mmap.close()
        finally:
            self._file.close()

    def __enter__(self) -> "GGUFReader":
        return self

    def __exit__(self, exc_type, exc, tb) -> None:
        self.close()

    def _parse(self) -> None:
        f = self._file
        f.seek(0)
        magic = f.read(4)
        if magic != GGUF_MAGIC:
            raise ValueError(f"Not a GGUF file (magic={magic!r})")

        self.version = _read_u32(f)
        self.tensor_count = _read_u64(f)
        kv_count = _read_u64(f)

        meta: Dict[str, Any] = {}
        for _ in range(kv_count):
            k = _read_string(f)
            t = _read_u32(f)
            meta[k] = _read_value(f, t)

        self.alignment = int(meta.get("general.alignment", GGUF_DEFAULT_ALIGNMENT))
        self.meta = meta

        # Tensor infos
        tensors: Dict[str, TensorInfo] = {}
        for _ in range(self.tensor_count):
            name = _read_string(f)
            n_dims = _read_u32(f)
            dims = [_read_u64(f) for _ in range(n_dims)]
            ggml_type = _read_u32(f)
            offset = _read_u64(f)

            logical_shape = tuple(int(d) for d in reversed(dims))
            n_elems = 1
            for d in logical_shape:
                n_elems *= d

            if ggml_type not in QUANT_BLOCK_SIZES:
                raise ValueError(f"Unsupported ggml tensor type {ggml_type} for tensor {name!r}")

            block_elems, block_bytes = QUANT_BLOCK_SIZES[ggml_type]
            if ggml_type in (0, 1):  # f32/f16
                n_bytes = n_elems * block_bytes
            else:
                if n_elems % block_elems != 0:
                    raise ValueError(f"Tensor {name!r} elem count not divisible by block: {n_elems} % {block_elems}")
                n_bytes = (n_elems // block_elems) * block_bytes

            tensors[name] = TensorInfo(
                name=name,
                shape=logical_shape,
                ggml_type=ggml_type,
                offset=int(offset),
                n_bytes=int(n_bytes),
            )

        self.tensors = tensors

        # Compute data start (end of tensor infos, then padded to alignment)
        pos = f.tell()
        self.data_start = _align(pos, self.alignment)

    def get_meta(self, key: str, default: Any = None) -> Any:
        return self.meta.get(key, default)

    def load_tensor(self, name: str, *, dtype: torch.dtype) -> torch.Tensor:
        info = self.tensors[name]
        abs_off = self.data_start + info.offset

        if info.ggml_type == 0:  # F32
            n_elems = 1
            for d in info.shape:
                n_elems *= d
            t = torch.frombuffer(self._mmap, dtype=torch.float32, count=n_elems, offset=abs_off).reshape(info.shape)
            return t.to(dtype=dtype) if dtype != torch.float32 else t

        if info.ggml_type == 1:  # F16
            n_elems = 1
            for d in info.shape:
                n_elems *= d
            t = torch.frombuffer(self._mmap, dtype=torch.float16, count=n_elems, offset=abs_off).reshape(info.shape)
            return t.to(dtype=dtype) if dtype != torch.float16 else t

        # quantized blocks
        block_elems, block_bytes = QUANT_BLOCK_SIZES[info.ggml_type]
        n_elems = 1
        for d in info.shape:
            n_elems *= d
        n_blocks = n_elems // block_elems

        raw = torch.frombuffer(self._mmap, dtype=torch.uint8, count=info.n_bytes, offset=abs_off)
        blocks = raw.reshape((n_blocks, block_bytes))
        deq = dequantize_blocks(blocks, info.ggml_type, dtype=dtype)
        return deq.reshape(info.shape)

