from __future__ import annotations

import argparse
import json
import sys
import time
import warnings
from dataclasses import dataclass
from pathlib import Path
from typing import List, Optional, Sequence

import torch

from gguf_chat import load_llama_from_gguf
from gguf_chat.model import KVCache, LlamaModel
from gguf_chat.tokenizer import IncrementalDecoder, LlamaBPETokenizer

warnings.filterwarnings("ignore", message="The given buffer is not writable")

try:
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")  # type: ignore[attr-defined]
    sys.stderr.reconfigure(encoding="utf-8", errors="replace")  # type: ignore[attr-defined]
except Exception:
    pass


@dataclass
class RunnerConfig:
    model_path: Path
    n_ctx: int
    dtype: str
    temperature: float
    top_p: float
    repeat_penalty: float
    max_tokens: int
    system_prompt: str


def _now_ts() -> str:
    return time.strftime("%Y-%m-%d %H:%M:%S")


def _print_help() -> None:
    print(
        "\nCommands:\n"
        "  /exit            Quit\n"
        "  /reset           Clear conversation\n"
        "  /system <text>   Set system prompt\n"
        "  /save <path>     Save conversation JSON\n"
        "  /help            Show this help\n"
    )


def _parse_args(argv: Optional[List[str]] = None) -> RunnerConfig:
    p = argparse.ArgumentParser(
        prog="convlit",
        description="Convlit: GGUF chat runner (no llama.cpp). Supports Llama-3.x GGUF with K-quants + IQ4_XS.",
    )
    p.add_argument("--model", default="ai.gguf", help="Path to .gguf model file (default: ai.gguf)")
    p.add_argument("--n-ctx", type=int, default=4096, help="Max context length to allocate for KV cache")
    p.add_argument("--dtype", choices=("f16", "f32"), default="f16", help="Dequantize weights to fp16 or fp32")
    p.add_argument("--temp", type=float, default=0.7, help="Temperature")
    p.add_argument("--top-p", type=float, default=0.95, help="Top-p sampling")
    p.add_argument("--repeat-penalty", type=float, default=1.1, help="Repetition penalty (1.0 disables)")
    p.add_argument("--max-tokens", type=int, default=9216, help="Max tokens to generate per turn")
    p.add_argument("--system", default="You are a helpful assistant.", help="Initial system prompt")
    a = p.parse_args(argv)
    return RunnerConfig(
        model_path=Path(a.model),
        n_ctx=a.n_ctx,
        dtype=a.dtype,
        temperature=a.temp,
        top_p=a.top_p,
        repeat_penalty=a.repeat_penalty,
        max_tokens=a.max_tokens,
        system_prompt=a.system,
    )


def _encode_header(tok: LlamaBPETokenizer, model: LlamaModel, role: str) -> List[int]:
    cfg = model.cfg
    ids: List[int] = [cfg.start_header_id]
    ids.extend(tok.encode(role))
    ids.append(cfg.end_header_id)
    ids.extend(tok.encode("\n\n"))
    return ids


def _encode_message(tok: LlamaBPETokenizer, model: LlamaModel, role: str, content: str) -> List[int]:
    cfg = model.cfg
    ids = _encode_header(tok, model, role)
    ids.extend(tok.encode(content.strip()))
    ids.append(cfg.eot_id)
    return ids


def _sample_next_token(
    logits: torch.Tensor,
    *,
    temperature: float,
    top_p: float,
    repeat_penalty: float,
    recent_tokens: Sequence[int],
) -> int:
    scores = logits.float().clone()

    if repeat_penalty and repeat_penalty != 1.0 and recent_tokens:
        for t in set(recent_tokens[-512:]):
            val = scores[t]
            scores[t] = torch.where(val < 0, val * repeat_penalty, val / repeat_penalty)

    if temperature <= 0:
        return int(torch.argmax(scores).item())

    scores = scores / float(temperature)
    probs = torch.softmax(scores, dim=-1)

    if 0 < top_p < 1.0:
        sorted_probs, sorted_idx = torch.sort(probs, descending=True)
        cum = torch.cumsum(sorted_probs, dim=-1)
        to_remove = cum - sorted_probs > top_p
        sorted_probs[to_remove] = 0
        sorted_probs = sorted_probs / sorted_probs.sum()
        next_local = torch.multinomial(sorted_probs, num_samples=1).item()
        return int(sorted_idx[next_local].item())

    return int(torch.multinomial(probs, num_samples=1).item())


def _eval_tokens(model: LlamaModel, cache: KVCache, token_ids: Sequence[int]) -> torch.Tensor:
    logits: Optional[torch.Tensor] = None
    for t in token_ids:
        logits = model.forward_one(int(t), cache)
    assert logits is not None
    return logits


def run_chat(cfg: RunnerConfig) -> int:
    if not cfg.model_path.exists():
        print(f"Error: model not found: {cfg.model_path}", file=sys.stderr)
        return 1

    torch.set_grad_enabled(False)
    torch.set_num_threads(max(1, (torch.get_num_threads() or 1)))

    dtype = torch.float16 if cfg.dtype == "f16" else torch.float32

    print(f"[{_now_ts()}] Loading GGUF: {cfg.model_path}")
    model, tok = load_llama_from_gguf(cfg.model_path, n_ctx=cfg.n_ctx, dtype=dtype)
    cache = KVCache(model.cfg, cfg.n_ctx, dtype=dtype, device=torch.device("cpu"))

    end_of_text_id = tok.encoder.get("<|end_of_text|>")
    end_of_message_id = tok.encoder.get("<|eom_id|>")
    terminators = {model.cfg.eot_id, model.cfg.eos_id}
    if end_of_text_id is not None:
        terminators.add(end_of_text_id)
    if end_of_message_id is not None:
        terminators.add(end_of_message_id)

    messages = [{"role": "system", "content": cfg.system_prompt}]

    cache.reset()
    token_history: List[int] = [model.cfg.bos_id]
    token_history += _encode_message(tok, model, "system", cfg.system_prompt)
    _eval_tokens(model, cache, token_history)

    print(f"[{_now_ts()}] Ready. Type /help for commands.\n")

    while True:
        try:
            user_text = input("> ").strip()
        except (EOFError, KeyboardInterrupt):
            print()
            return 0

        if not user_text:
            continue

        if user_text.startswith("/"):
            parts = user_text.split(" ", 1)
            cmd = parts[0].lower()
            arg = parts[1] if len(parts) > 1 else ""

            if cmd in ("/exit", "/quit"):
                return 0
            if cmd == "/help":
                _print_help()
                continue
            if cmd == "/reset":
                messages = [{"role": "system", "content": cfg.system_prompt}]
                cache.reset()
                token_history = [model.cfg.bos_id]
                token_history += _encode_message(tok, model, "system", cfg.system_prompt)
                _eval_tokens(model, cache, token_history)
                print("(conversation cleared)")
                continue
            if cmd == "/system":
                if not arg.strip():
                    print("Usage: /system <text>")
                    continue
                cfg.system_prompt = arg.strip()
                messages = [{"role": "system", "content": cfg.system_prompt}]
                cache.reset()
                token_history = [model.cfg.bos_id]
                token_history += _encode_message(tok, model, "system", cfg.system_prompt)
                _eval_tokens(model, cache, token_history)
                print("(system prompt updated; conversation reset)")
                continue
            if cmd == "/save":
                if not arg.strip():
                    print("Usage: /save <path>")
                    continue
                out_path = Path(arg.strip())
                try:
                    out_path.write_text(json.dumps(messages, indent=2, ensure_ascii=False), encoding="utf-8")
                    print(f"(saved: {out_path})")
                except Exception as exc:
                    print(f"Error saving: {exc}", file=sys.stderr)
                continue

            print("Unknown command. Type /help.")
            continue

        messages.append({"role": "user", "content": user_text})

        to_add = _encode_message(tok, model, "user", user_text)
        to_add += _encode_header(tok, model, "assistant")
        token_history.extend(to_add)
        logits = _eval_tokens(model, cache, to_add)

        print("Assistant: ", end="", flush=True)
        dec: IncrementalDecoder = tok.incremental_decoder()
        out_text_parts: List[str] = []

        for _ in range(cfg.max_tokens):
            next_id = _sample_next_token(
                logits,
                temperature=cfg.temperature,
                top_p=cfg.top_p,
                repeat_penalty=cfg.repeat_penalty,
                recent_tokens=token_history,
            )

            token_history.append(next_id)
            logits = model.forward_one(next_id, cache)

            if next_id in terminators:
                break

            piece = dec.decode_token(next_id)
            if piece:
                out_text_parts.append(piece)
                sys.stdout.write(piece)
                sys.stdout.flush()

        tail = dec.flush()
        if tail:
            out_text_parts.append(tail)
            sys.stdout.write(tail)
            sys.stdout.flush()

        sys.stdout.write("\n")
        sys.stdout.flush()

        assistant_text = "".join(out_text_parts).strip()
        messages.append({"role": "assistant", "content": assistant_text})


def main(argv: Optional[List[str]] = None) -> int:
    cfg = _parse_args(argv)
    try:
        return run_chat(cfg)
    except Exception as exc:
        print(f"Error: {exc}", file=sys.stderr)
        return 1
