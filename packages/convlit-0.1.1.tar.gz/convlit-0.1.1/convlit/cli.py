from __future__ import annotations

from typing import List, Optional

from .chat import main as chat_main


def main(argv: Optional[List[str]] = None) -> int:
    return chat_main(argv)

