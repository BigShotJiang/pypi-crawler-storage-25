# datamasque

This package is a placeholder for any future DataMasque projects.
It serves as an alias for the official package at [DataMasque Python](https://pypi.org/project/datamasque-python).

## Install the official client

```
# pip
pip install datamasque-python

# poetry
poetry add datamasque-python

# uv
uv add datamasque-python
```

## Links

- Official client on PyPI: <https://pypi.org/project/datamasque-python/>
- Source code: <https://github.com/datamasque/datamasque-python>
- Documentation: <https://datamasque-python.readthedocs.io/>
- DataMasque product: <https://datamasque.com/>

## License

Apache-2.0. See [LICENSE](LICENSE).
