"""Eigen Ingenuity - Common Menu

This package deals with the Eigen Ingenuity Common Menu API.

To retrieve a CommonMenu instance use getCommonMenu:

  from eigeningenuity.commonmenu import get_common_menu
  from eigeningenuity import EigenServer

  eigenserver = EigenServer(ingenuity-base-url)

  common_menu = get_common_menu(eigenserver)

  assets = common_menu.getRelatedAssetsCommonMenu("System_01")

"""

import json
import pandas as pd
import datetime as dt
from eigeningenuity import EigenServer
from eigeningenuity.util import _do_eigen_json_request
from eigeningenuity.core import get_default_server
from typing import Union
from datetime import datetime
from eigeningenuity.util import force_list


class CommonMenu(object):
    """CommonMenu client for Ingenuity Common Menu API."""

    def __init__(self, baseurl, auth):
        """Initialize CommonMenu client.

        Args:
            baseurl (str): Base URL for Common Menu endpoint.
            auth: Authentication credentials or session.

        Returns:
            None

        Docs:
            https://docs.eigeningenuity.co/developing-with-eigen/python-library/common-menu/get-common-menu
        """
        self.baseurl = baseurl
        self.auth = auth

    def _doCommonMenuRequest(self, index, params):
        """Send request to Common Menu API.

        Args:
            index (str): CommonMenu API endpoint key (e.g., 'relatedAssets').
            params (dict): Query parameters.

        Returns:
            dict: Response JSON.

        Docs:
            https://docs.eigeningenuity.co/developing-with-eigen/python-library/common-menu/get-common-menu
        """
        # self._testConnection()
        url = self.baseurl + "commonmenu/asset/" + index + "?"
        return _do_eigen_json_request(url, self.auth, **params)

    def getRelatedAssets(self, node: str, output="json", filepath=None):
        """Fetch related assets for a given node.

        Args:
            node (str): Node code to query.
            output (str, optional): Output format: "json", "df", "raw", "file". Defaults to "json".
            filepath (str, optional): File path to save output when output="file".

        Returns:
            list|pandas.DataFrame|dict|None: Related assets. Returns None if output="file".

        Raises:
            KeyError: If API response is malformed or missing expected keys.

        Docs:
            https://docs.eigeningenuity.co/developing-with-eigen/python-library/common-menu/get-related-assets
        """
        args = {"asset": node}

        response = self._doCommonMenuRequest("relatedAssets", args)
        relatedAssets = response["relatedAssets"]["graphapi"]

        if output == "raw":
            return response

        newAssets = []

        for item in relatedAssets:
            relations = item["relations"]
            for relation in relations:
                newItem = {**item["asset"]}
                newItem["relationName"] = relation["relationName"]
                newItem["direction"] = relation["direction"]
                newAssets.append(newItem)

        if output == "json":
            return newAssets
        if output == "df":
            return pd.json_normalize(newAssets)
        if output == "file":
            if filepath is None:
                filepath = (
                    node
                    + "-RelatedAssets-"
                    + str(dt.datetime.now().strftime("%Y-%m-%dT%H:%M:%S"))
                )
            with open(filepath, "w") as f:
                f.write(json.dumps(newAssets, indent=4))

    def getMeasurements(
        self, node: str, source: str = "all", output: str = "json", filepath: str = None
    ):
        """Get measurement timeseries for an asset.

        Args:
            node (str): Node code to query.
            source (str, optional): "all", "merged", or specific source name. Defaults to "all".
            output (str, optional): Output format: "json", "df", "raw", "file". Defaults to "json".
            filepath (str, optional): File path to save output for output="file".

        Returns:
            list|pandas.DataFrame|dict|None: Measurements result. Returns None if output="file".

        Raises:
            KeyError: If API response is malformed or missing expected keys.

        Docs:
            https://docs.eigeningenuity.co/developing-with-eigen/python-library/common-menu/get-measurements
        """
        args = {}
        args["asset"] = node

        response = self._doCommonMenuRequest("timeseries", args)

        source = source.lower()

        if source == "merged":
            timeseries = response["allTimeseries"]
        elif source == "all":
            timeseries = response["timeseries"]
        else:
            timeseries = response["timeseries"][source]

        match output:
            case "raw":
                return response
            case "json":
                return timeseries
            case "df":
                if source == "all":
                    all_data = []
                    for src, items in response["timeseries"].items():
                        for item in items:
                            item["source"] = src
                            all_data.append(item)
                    return pd.DataFrame(all_data)
                else:
                    return pd.DataFrame(timeseries)
            case "file":
                if filepath is None:
                    filepath = (
                        node
                        + "-Measurements-"
                        + str(dt.datetime.now().strftime("%Y-%m-%dT%H:%M:%S"))
                    )
                with open(filepath, "w") as f:
                    f.write(json.dumps(timeseries, indent=4))

    def getDrivers(self):
        """Retrieve available measurement driver sources.

        Returns:
            list: Driver source names.

        Raises:
            KeyError: If expected API fields are missing.

        Docs:
            https://docs.eigeningenuity.co/developing-with-eigen/python-library/common-menu/get-drivers
        """
        args = {"asset": ""}

        response = self._doCommonMenuRequest("timeseries", args)

        sources = [driver["name"] for driver in response["drivers"]]

        return sources

    # Alias for getDrivers
    getMeasurementSources = getDrivers

    def getEvents(
        self,
        node: str,
        start: Union[str, int, float, datetime] = "24 hours ago",
        end: Union[str, int, float, datetime] = "now",
        limit: int = 1000,
        output: str = "json",
        filepath: str = None,
    ):
        """Query events for one or more assets.

        Args:
            node (str|list): Asset node(s) to query.
            start (str|int|float|datetime, optional): Start time. Defaults "24 hours ago".
            end (str|int|float|datetime, optional): End time. Defaults "now".
            limit (int, optional): Max events per query. Defaults to 1000.
            output (str, optional): Output format: "json", "df", "raw", "file". Defaults to "json".
            filepath (str, optional): File path for output="file".

        Returns:
            list|pandas.DataFrame|dict|None: Events data. Returns None if output="file".

        Raises:
            KeyError: If response is malformed.

        Docs:
            https://docs.eigeningenuity.co/developing-with-eigen/python-library/common-menu/get-events
        """
        nodes = force_list(node)
        results = []
        events = []
        for node in nodes:
            args = {"asset": node, "start": start, "end": end, "limit": limit}
            response = self._doCommonMenuRequest("events", args)
            results.append(response)
            events.append(response["events"])

        if events == []:
            return

        if output == "raw":
            return results
        if output == "json":
            return events[0]
        if output == "df":
            return pd.json_normalize(events[0])
        if output == "file":
            if filepath is None:
                filepath = (
                    node
                    + "-RelatedEvents-"
                    + str(dt.datetime.now().strftime("%Y-%m-%dT%H:%M:%S"))
                )
            with open(filepath + ".json", "w") as f:
                f.write(json.dumps(events[0], indent=4))

    def getProperties(
        self, node: str, source="all", output="json", filepath: str = None
    ):
        """Retrieve properties for a node.

        Args:
            node (str): Node code to query.
            source (str, optional): Property source ("all" or specific source). Defaults to "all".
            output (str, optional): Output format: "json", "df", "raw", "file". Defaults to "json".
            filepath (str, optional): File path for output="file".

        Returns:
            dict|pandas.DataFrame|None: Properties data. Returns None if output="file".

        Raises:
            KeyError: If response is malformed.

        Docs:
            https://docs.eigeningenuity.co/developing-with-eigen/python-library/common-menu/get-properties
        """

        properties = []
        args = {"asset": node}
        response = self._doCommonMenuRequest("properties", args)

        source = source.lower()

        if source == "all":
            properties = response["properties"]
        else:
            # Get the properties list from the specific source
            source_data = response["properties"].get(source, {})
            properties = source_data.get("properties", {})

        if output == "raw":
            return response
        if output == "json":
            return properties
        if output == "df":
            if source == "all":
                # When source is "all", properties is dict with source keys
                all_data = []
                for src, src_data in properties.items():
                    # Extract the actual properties dict from each source
                    props_dict = src_data.get("properties", {})
                    for key, value in props_dict.items():
                        all_data.append(
                            {"property": key, "value": value, "source": src}
                        )
                return pd.DataFrame(all_data)
            else:
                # When source is specified, properties is already a dict of key-value pairs
                all_data = []
                for key, value in properties.items():
                    all_data.append({"property": key, "value": value})
                return pd.DataFrame(all_data)
        if output == "file":
            if filepath is None:
                filepath = (
                    node
                    + "-Properties-"
                    + str(dt.datetime.now().strftime("%Y-%m-%dT%H:%M:%S"))
                )
            with open(filepath, "w") as f:
                f.write(json.dumps(properties, indent=4))

    def getDocuments(
        self, node: str, document_type: str = "all", output="json", filepath: str = None
    ):
        """Get documents for a node.

        Args:
            node (str): Node code to query.
            document_type (str, optional): "all", "merged", or type name. Defaults "all".
            output (str, optional): Output format: "json", "df", "raw", "file". Defaults "json".
            filepath (str, optional): File path for output="file".

        Returns:
            dict|pandas.DataFrame|list|None: Documents result. Returns None if output="file".

        Raises:
            KeyError: If response is malformed.

        Docs:
            https://docs.eigeningenuity.co/developing-with-eigen/python-library/common-menu/get-documents
        """
        args = {"asset": node}

        response = self._doCommonMenuRequest("documents", args)

        documents = response["documents"]

        # Build grouped documents dict
        final_documents = {}
        for type in documents:
            final_documents[type["description"]] = type["documents"]

        # Build flat list of all documents
        alldocs = []
        for type in documents:
            for doc in type["documents"]:
                alldocs.append(doc)

        # Determine which data to return based on source parameter
        source = document_type.lower() if document_type != "all" else document_type

        if source == "merged":
            data_to_return = alldocs
        elif source == "all":
            data_to_return = final_documents
        else:
            # Try to find specific document type (case-insensitive match)
            data_to_return = None
            for type_name, type_docs in final_documents.items():
                if type_name.lower() == source:
                    data_to_return = type_docs
                    break

            # If no match found, return empty list
            if data_to_return is None:
                data_to_return = []

        if output == "raw":
            return response
        if output == "json":
            return data_to_return
        if output == "df":
            if source == "all" or source == "merged":
                return pd.json_normalize(alldocs)
            else:
                return pd.json_normalize(data_to_return)
        if output == "file":
            if filepath is None:
                filepath = (
                    node
                    + "-Documents-"
                    + str(dt.datetime.now().strftime("%Y-%m-%dT%H:%M:%S"))
                )


def get_common_menu(eigenserver: EigenServer = None):
    """Create a CommonMenu client.

    Args:
        eigenserver (EigenServer|str|None): EigenServer instance or URL. Defaults to EIGENSERVER env var.

    Returns:
        CommonMenu: CommonMenu client.

    Docs:
        https://docs.eigeningenuity.co/developing-with-eigen/python-library/common-menu/get-common-menu
    """
    if eigenserver is None:
        eigenserver = get_default_server()
    elif isinstance(eigenserver, str):
        eigenserver = EigenServer(eigenserver)

    return CommonMenu(eigenserver.getEigenServerUrl(), eigenserver.auth)
