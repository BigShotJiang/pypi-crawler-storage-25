"""Eigen Ingenuity - SQL

This package deals with the Eigen Ingenuity SQL database.

To retrieve data execute a custom query with

  from eigeningenuity.assetmodel import matchNode
  from time import gmtime, asctime

  h = get_historian("Demo-influxdb","demo.eigen.co")

  cmd = "EXECUTE"
  db = "aveva-db",
  query = '''
    SELECT TAG_TISLOCATIONCODE, TAG_TISLOCATIONNAME, TAG_NUMBER, TAG_DESC, TAG_STATUS, TAG_STATUSDESC, TAG_BARRIERCODE, TAG_BARRIERNAME, TAG_BARRIERISACTIVE, TAG_BARRIERPERFORMANCESTD, TAG_BARRIERVERIFICATIONACT
    FROM VT_TAGBARRIER
    WHERE (ROWNUM <= 10)
    '''

  response = h.executeRawQuery(cmd,db,query)
"""

from eigeningenuity import EigenServer
from urllib.parse import quote as urlquote
from eigeningenuity.util import _do_eigen_json_request
from eigeningenuity.core import get_default_server
import requests
import json
import pandas as pd
import datetime as dt

from urllib3.exceptions import InsecureRequestWarning
requests.packages.urllib3.disable_warnings(category=InsecureRequestWarning)

class sqlConnection (object):
    """Connection object for Eigen Ingenuity SQL API."""

    def __init__(self, baseurl, auth):
        """Initialize SQL connection.

        Args:
            baseurl (str): Base URL for the SQL endpoint (e.g. http://demo.eigen.co/eigen-webtools-servlet/sqlquery).
            auth: Authentication object/tuple used by requests.

        Returns:
            None

        Docs:
            https://docs.eigeningenuity.co/developing-with-eigen/python-library/sql/get-sql
        """
        self.baseurl = baseurl
        self.auth = auth

    def _testConnection(self):
        """Preflight request to verify SQL connection.

        Raises:
            ConnectionError: If the endpoint cannot be reached.

        Docs:
            https://docs.eigeningenuity.co/developing-with-eigen/python-library/sql/get-sql
        """
        try:
            status = requests.get(self.baseurl, verify=False).status_code
        except ConnectionError:
            raise ConnectionError("Failed to connect to ingenuity instance at " + self.baseurl + ". Please check the url is correct and the instance is up.")

    def _doJsonRequest(self, cmd, params):
        """Send a JSON request to the SQL endpoint.

        Args:
            cmd (str): SQL command name (e.g., "EXECUTE", "LISTDBS", "LIST").
            params (dict): Parameters payload for the request.

        Returns:
            dict: Parsed JSON response.

        Docs:
            https://docs.eigeningenuity.co/developing-with-eigen/python-library/sql/get-sql
        """
        url = self.baseurl + "?cmd=" + urlquote(cmd)
        return _do_eigen_json_request(url, self.auth, **params)

    def executeRawQuery(self, cmd: str, db: str, query: str, output: str = "json", filepath: str = None):
        """Run a raw SQL query against an Ingenuity SQL database.

        Args:
            cmd (str): Command to run (usually "EXECUTE").
            db (str): SQL database name.
            query (str): SQL query string.
            output (str, optional): Response format. One of "json", "raw", "string", "df", "file". Defaults to "json".
            filepath (str, optional): Output path when `output="file"`. Defaults to None.

        Returns:
            list|dict|pandas.DataFrame|None: Query response interpreted by output mode.

        Raises:
            ValueError: If query parameters are invalid.
            URLError: If connection cannot be established.
            HTTPError: If request fails.

        Docs:
            https://docs.eigeningenuity.co/developing-with-eigen/python-library/sql/execute-raw-query
        """
        args = {}
        args['db'] = db
        args['query'] = query
        response = self._doJsonRequest(cmd,args)["results"]

        if output == "raw" or output == "json":
            return response
        elif output == "string":
            return json.dumps(response)
        elif output == "df":
            return pd.DataFrame(response)
        elif output == "file":
            if filepath is None:
                filepath = "eigenSQLResponse-" + db + "-" + str(dt.datetime.now().strftime("%Y-%m-%dT%H:%M:%S"))
            with open(filepath + ".json", "w") as f:
                f.write(json.dumps(response, indent=4))
        return None
    
    def listDatabases(self):
        """List available SQL databases on the server.

        Returns:
            list: SQL database names.

        Raises:
            URLError: If connection cannot be established.
            HTTPError: If request fails.

        Docs:
            https://docs.eigeningenuity.co/developing-with-eigen/python-library/sql/list-databases
        """
        args = {}
        cmd = "LISTDBS"
        response = self._doJsonRequest(cmd,args)["results"]

        return response
    
    def listTables(self, db):
        """List tables in a SQL database.

        Args:
            db (str): Name of the SQL database.

        Returns:
            list: Table names in the database.

        Raises:
            ValueError: If `db` is empty.
            URLError: If connection cannot be established.
            HTTPError: If request fails.

        Docs:
            https://docs.eigeningenuity.co/developing-with-eigen/python-library/sql/list-tables
        """
        args = {}
        cmd = "LIST"
        args["db"] = db
        response = self._doJsonRequest(cmd,args)["results"]

        return response


def get_sql(eigenserver: EigenServer = None):
    """Instantiate an SQL connection for the given EigenServer.

    Args:
        eigenserver (EigenServer|str|None, optional): EigenServer instance or URL. Uses `EIGENSERVER` env var if None.

    Returns:
        sqlConnection: Client object for SQL queries.

    Docs:
        https://docs.eigeningenuity.co/developing-with-eigen/python-library/sql/get-sql
    """
    if eigenserver is None:
        eigenserver = get_default_server()
    elif isinstance(eigenserver, str):
        eigenserver = EigenServer(eigenserver)
        
    return sqlConnection(eigenserver.getEigenServerUrl() + "eigen-webtools-servlet/sqlquery", eigenserver.auth)