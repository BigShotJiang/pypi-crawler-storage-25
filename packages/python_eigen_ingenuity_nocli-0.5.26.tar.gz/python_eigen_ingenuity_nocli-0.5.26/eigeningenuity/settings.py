import os
from getpass import getuser

_token_cache_enabled_ = True
_azure_auth_enabled_ = True
_azure_tenant_id_ = os.getenv("EIGEN_INGENUITY_TENANT_ID", "74efa022-e6d6-42ad-bc15-edc76c525bde")
_azure_client_id_ = os.getenv("EIGEN_INGENUITY_CLIENT_ID", "c2b9aa13-e178-4dde-bc2c-b6cc4c8391d2")
_azure_client_secret_ = os.getenv("EIGEN_INGENUITY_CLIENT_SECRET", None)
_api_token_value_ = os.getenv("EIGEN_INGENUITY_API_TOKEN", False)
_auth_scope_ = os.getenv("EIGEN_INGNEUITY_AUTH_SCOPE","user_impersonation")


def clear_auth_token_cache():
    """Delete cached tokens for the currently signed-in user.

    Returns:
        None

    Docs:
        https://docs.eigeningenuity.co/developing-with-eigen/python-library/authentication/
    """
    if os.path.exists(os.path.dirname(__file__) + f'/.azure/{getuser()}_cache.bin'):
        os.remove(os.path.dirname(__file__) + f'/.azure/{getuser()}_cache.bin')

def disable_auth_token_cache(state=True):
    """Enable or disable token cache usage for Azure auth.

    Args:
        state (bool, optional): If True, disable cache usage. Defaults to True.

    Returns:
        None

    Docs:
        https://docs.eigeningenuity.co/developing-with-eigen/python-library/authentication/
    """
    global _token_cache_enabled_
    _token_cache_enabled_ = not state

def disable_azure_auth(state=True):
    """Enable or disable Azure authentication behavior.

    Args:
        state (bool, optional): If True, disable Azure auth. Defaults to True.

    Returns:
        None

    Docs:
        https://docs.eigeningenuity.co/developing-with-eigen/python-library/authentication/
    """
    global _azure_auth_enabled_
    _azure_auth_enabled_ = not state

def set_azure_tenant_id(id):
    """Set the Azure tenant ID for authentication.

    Args:
        id (str): Azure tenant ID.

    Returns:
        None

    Docs:
        https://docs.eigeningenuity.co/developing-with-eigen/python-library/authentication/
    """
    global _azure_tenant_id_
    _azure_tenant_id_ = id

def set_azure_client_id(id):
    """Set the Azure client ID for authentication.

    Args:
        id (str): Azure client/application ID.

    Returns:
        None

    Docs:
        https://docs.eigeningenuity.co/developing-with-eigen/python-library/authentication/
    """
    global _azure_client_id_
    _azure_client_id_ = id

def set_azure_client_secret(secret):
    """Set the Azure client secret for CLIENT_CREDENTIALS authentication.

    Args:
        secret (str): Azure client secret.

    Returns:
        None

    Docs:
        https://docs.eigeningenuity.co/developing-with-eigen/python-library/authentication/
    """
    global _azure_client_secret_
    _azure_client_secret_ = secret

def set_api_token(token):
    """Set the API token for the eigenserver.

    Args:
        token (str): API token value.

    Returns:
        None

    Docs:
        https://docs.eigeningenuity.co/developing-with-eigen/python-library/authentication/
    """
    global _api_token_value_
    _api_token_value_ = token

def set_auth_scope(scope):
    """Set auth scope for Azure app registration token requests.

    Args:
        scope (str): OAuth scope string (default 'user_impersonation').

    Returns:
        None

    Docs:
        https://docs.eigeningenuity.co/developing-with-eigen/python-library/authentication/
    """
    global _auth_scope_
    _auth_scope_ = scope
