import datetime
import traceback
import sys
import logging
from eigeningenuity.util import _get_external_callsite

# Function to add the filename to each line of the traceback
def format_traceback(exc_type, exc_value, exc_traceback, filename, configfile):
    """Format an exception traceback with timestamp and file context.

    Args:
        exc_type (type): Exception type object.
        exc_value (Exception): Exception instance.
        exc_traceback (traceback): Traceback object.
        filename (str): Name of the file context for logging.
        configfile (str): Optional configfile suffix string.

    Returns:
        str: Formatted multiline traceback with timestamps and context.
    """
    tb_lines = traceback.format_exception(exc_type, exc_value, exc_traceback)
    tb_lines2 = []
    tb_lines2.append(
        datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S,%f")[:-3]
        + " - "
        + filename
        + configfile
        + " - ERROR - An Error Occurred\n"
    )
    for line in tb_lines:
        x = line.split("\n")
        for y in x:
            if y != "":
                tb_lines2.append(
                    datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S,%f")[:-3]
                    + " - "
                    + filename
                    + configfile
                    + " - ERROR - "
                    + y
                    + "\n"
                )
    tb_lines2.append(
        datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S,%f")[:-3]
        + " - "
        + filename
        + configfile
        + " - ERROR - Finished Executing\n"
    )
    return "".join(tb_lines2)


def exception_formatter(exc_type, exc_value, exc_traceback, filename, configfile=""):
    """Custom exception hook for printing formatted tracebacks.

    Args:
        exc_type (type): Exception type object.
        exc_value (Exception): Exception instance.
        exc_traceback (traceback): Traceback object.
        filename (str): Name of the file context for logging.
        configfile (str, optional): Optional configfile suffix. Defaults to "".

    Returns:
        None
    """
    if configfile != "":
        configfile = ":" + configfile
    tb_formatted = format_traceback(
        exc_type, exc_value, exc_traceback, filename, configfile
    )
    print(tb_formatted)


sys.excepthook = exception_formatter


def _resolve_log_level(log_level):
    """Resolve string/int log levels into a logging module level integer."""
    if isinstance(log_level, int):
        return log_level

    if isinstance(log_level, str):
        level_name = log_level.strip().upper()
        resolved = logging.getLevelName(level_name)
        if isinstance(resolved, int):
            return resolved

    raise ValueError(
        "Invalid log level. Use an int or one of: DEBUG, INFO, WARNING, ERROR, CRITICAL"
    )


def log_handler(filename, configfile="", log_level=logging.INFO):
    """Configure root logger to output formatted messages to stdout.

    Args:
        filename (str): Base filename context for log entries.
        configfile (str, optional): Configfile suffix. Defaults to "".

    Args:
        filename (str): Base filename context for log entries.
        configfile (str, optional): Configfile suffix. Defaults to "".
        log_level (Union[int, str], optional): Logging level. Defaults to logging.INFO.

    Returns:
        None
    """
    resolved_level = _resolve_log_level(log_level)

    if configfile != "":
        configfile = ":" + configfile
    stream_handler = logging.StreamHandler(
        sys.stdout
    )  # By default, it logs to sys.stderr, but you can specify stdout.
    stream_handler.setLevel(resolved_level)
    stream_formatter = logging.Formatter(
        f"%(asctime)s - {filename}{configfile} - %(levelname)s - %(message)s"
    )
    stream_handler.setFormatter(stream_formatter)

    # Get the root logger and add the stream handler to it
    root_logger = logging.getLogger()
    root_logger.setLevel(resolved_level)
    root_logger.addHandler(stream_handler)


def setup_logging(filename="", configfile="", log_level=logging.INFO, level=None):
    """Initialize logging, warning, and exception handlers. Fomratted to include timestamps and script filename.
    
    This function is for use in scripts that run on containers, where the only logging output is stdout, and the filename context is important for distinguishing log entries.
    
    It also makes logs compatible with the custom Ingenuity Script handler API.

    Args:
        filename (str): Base filename context for log entries.
        configfile (str, optional): Configfile suffix. Defaults to "".
        log_level (Union[int, str], optional): Logging level. Defaults to logging.INFO.
        level (Union[int, str], optional): Backward-compatible alias for log_level.

    Returns:
        None
    """
    import warnings
    import os
    import atexit
    
    if filename == "":
        caller = _get_external_callsite()
        filename = caller["file"] if caller and "file" in caller else "unknown"
        
    # Extract just the filename if a full path is provided
    if "/" in filename or "\\" in filename:
        filename = os.path.basename(filename)

    if "/" in configfile or "\\" in configfile:
        configfile = os.path.basename(configfile)

    # Backward-compatible alias support for existing callers.
    if level is not None:
        log_level = level

    # Set up logging handler
    log_handler(filename, configfile, log_level=log_level)

    # Set up custom warning handler
    def custom_warning_handler(
        message, category, warn_filename, lineno, file=None, line=None
    ):
        logging.warning(f"{message}\n")

    warnings.filterwarnings("always", category=Warning, append=True)
    warnings.showwarning = custom_warning_handler

    # Set up custom exception handler
    def custom_exception_handler(exc_type, exc_value, exc_traceback):
        exception_formatter(exc_type, exc_value, exc_traceback, filename, configfile)

    sys.excepthook = custom_exception_handler

    # Register function to log "Finished Executing" on normal exit
    def log_finish():
        logging.info("Finished Executing")

    atexit.register(log_finish)

    logging.info("Begin Execution")
