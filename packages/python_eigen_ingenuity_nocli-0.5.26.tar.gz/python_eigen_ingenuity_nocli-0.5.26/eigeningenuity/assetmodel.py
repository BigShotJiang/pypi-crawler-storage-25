"""Eigen Ingenuity - Asset Model

This package deals with the Eigen Ingenuity Asset Model API, by means
of the neo4j plugin endpoint.

To retrieve an AssetObject use getMatchingNodes, or execute a custom cypher query with executeRawQuery

from eigeningenuity.assetmodel import getAssetModel
from eigeningenuity import EigenServer

eigenserver = EigenServer(ingenuity-base-url)

model = getAssetModel(eigenserver)

nodes = model.getMatchingNodes("code","System_")


"""

import requests
import pandas as pd
from eigeningenuity import EigenServer
from eigeningenuity.util import (
    force_list,
    _do_eigen_post_request,
    get_eigenserver,
    EigenException,
)
from eigeningenuity.core import get_default_server
from requests.exceptions import ConnectionError
from urllib.error import URLError
from typing import Union

from urllib3.exceptions import InsecureRequestWarning

requests.packages.urllib3.disable_warnings(category=InsecureRequestWarning)


class AssetModel(object):
    """AssetModel client for Ingenuity Neo4j API endpoints."""

    def __init__(self, baseurl, auth, instance="default"):
        """Initialize AssetModel client.

        Args:
            baseurl (str): Base URL of the AssetModel service (e.g. https://demo.eigen.co/ei-applet/).
            auth: Authentication credentials or session.
            instance (str, optional): Neo4j instance name. Defaults to "default".

        Returns:
            None

        Docs:
            https://docs.eigeningenuity.co/developing-with-eigen/python-library/asset-model/get-assetmodel
        """
        self.baseurl = baseurl
        if instance == "default":
            self.instance = ""
        else:
            self.instance = instance + "/"
        self.eigenserver = get_eigenserver(baseurl)
        self.auth = auth

    def _testConnection(self):
        """Verify that the AssetModel endpoint is reachable.

        Raises:
            ConnectionError: If the endpoint cannot be reached.

        Docs:
            https://docs.eigeningenuity.co/developing-with-eigen/python-library/asset-model/get-assetmodel
        """
        try:
            status = requests.get(self.baseurl, verify=False).status_code
        except (URLError, ConnectionError):
            raise ConnectionError(
                "Failed to connect to ingenuity instance at "
                + self.baseurl
                + ". Please check the url is correct and the instance is up."
            )

    def _doNeo4jQueryRequest(self, data):
        """Execute a Neo4j query against the configured endpoint.

        Args:
            data (dict): Payload containing query information.

        Returns:
            dict: API response JSON.

        Docs:
            https://docs.eigeningenuity.co/developing-with-eigen/python-library/asset-model/get-assetmodel
        """
        # self._testConnection()

        url = f"{self.baseurl}neo4j/{self.instance}query"
        return _do_eigen_post_request(url, data, self.auth)

    def executeRawQuery(self, query: str, output: str = "json"):
        """Execute a raw Neo4j query via the AssetModel API.

        Args:
            query (str): Cypher query string.
            output (str, optional): Output format, either "json", "df", or "raw". Defaults to "json".

        Returns:
            list|pandas.DataFrame|dict|None: Query results in the requested format. Returns None if output="file".

        Raises:
            EigenException: If query fails.

        Docs:
            https://docs.eigeningenuity.co/developing-with-eigen/python-library/asset-model/execute-raw-query
        """
        payload = {"q": query}
        resp = self._doNeo4jQueryRequest(payload)

        if output == "raw":
            return resp

        if resp["success"]:
            response = resp["response"]
            data = response["data"]
            if isinstance(data, list) and len(data) >= 1:
                if output == "json":
                    return data
                if output == "df":
                    return pd.json_normalize(data)
            else:
                return response
        else:
            raise EigenException("Query failed: " + str(resp["errors"]))

    def getMeasurements(
        self, nodes: str, prop: str = "code", measurement: str = "", output="json"
    ):
        """Fetch measurement tags related to an asset node.

        Args:
            nodes (str|list): Node identifier(s) to query.
            prop (str, optional): Property to match on. Defaults to "code".
            measurement (str, optional): Measurement type filter. Defaults to all.
            output (str, optional): Output format: "json", "df", or "raw". Defaults to "json".

        Returns:
            list|pandas.DataFrame|dict|None: Measurements data. Returns None if output="file".

        Raises:
            EigenException: If query fails.

        Docs:
            https://docs.eigeningenuity.co/developing-with-eigen/python-library/asset-model/get-measurements
        """
        nodes_list = force_list(nodes)

        # Build a single efficient query for all nodes
        node_conditions = []
        for node in nodes_list:
            node_conditions.append(f"n.{prop} = '{node}'")

        # Combine all node conditions with OR
        node_match = " OR ".join(node_conditions)

        # Add measurement filter if provided
        measurement_filter = (
            f" AND r.measurementName CONTAINS '{measurement}'" if measurement else ""
        )

        # Single query to get all measurements for all nodes
        if prop != "code":
            code = "n.code as code,"
        else:
            code = ""

        query = f"""
        MATCH (n)-[r:hashistoriantag]->(m) 
        WHERE ({node_match}){measurement_filter}
        RETURN n.{prop} as {prop},{code} r.measurementName as measurementName, m.code as tag
        ORDER BY n.{prop}, r.measurementName
        """

        payload = {"q": query}
        resp = self._doNeo4jQueryRequest(payload)

        # Handle raw output - return full response even if success is false
        if output == "raw":
            return resp

        # Check if query was successful
        if not resp["success"]:
            raise EigenException(f"Query failed: {resp.get('errors', 'Unknown error')}")

        response_data = resp["response"]["data"]

        if output == "json":
            return response_data
        elif output == "df":
            return pd.DataFrame(response_data)
        else:
            raise EigenException(
                f"Unsupported output format: {output}. Use 'json', 'df', or 'raw'."
            )

    def getDocuments(self, nodes: Union[str, list], match=None, output="json"):
        """Fetch documents related to specified asset nodes.

        Args:
            nodes (str|list): Asset node identifier(s).
            match (str, optional): Filter documents by filename/description substring.
            output (str, optional): Output format: "json", "df", or "raw". Defaults to "json".

        Returns:
            dict|pandas.DataFrame|dict: Documents grouped by node or in raw response format.

        Raises:
            EigenException: If query fails.

        Docs:
            https://docs.eigeningenuity.co/developing-with-eigen/python-library/asset-model/get-documents
        """
        nodes_list = force_list(nodes)

        # Build a single efficient query for all nodes
        node_conditions = []
        for node in nodes_list:
            node_conditions.append(f"n.code = '{node}'")

        # Combine all node conditions with OR
        node_match = " OR ".join(node_conditions)

        # Single query to get all documents for all nodes, grouped by code
        query = f"""
        MATCH (n)-[r:hasdocument]->(d) 
        WHERE ({node_match})
        RETURN n.code as code, collect(d) as documents
        ORDER BY n.code
        """

        payload = {"q": query}
        resp = self._doNeo4jQueryRequest(payload)

        # Handle raw output - return full response even if success is false
        if output == "raw":
            return resp

        # Check if query was successful
        if not resp["success"]:
            raise EigenException(f"Query failed: {resp.get('errors', 'Unknown error')}")

        response_data = resp["response"]["data"]

        # Process documents and apply filtering
        grouped_documents = {}
        for item in response_data:
            code = item["code"]
            documents = item["documents"]

            # Apply filename/description filter if provided
            if match is not None:
                filtered_docs = []
                for document in documents:
                    if (
                        match in document.get("fileName", "")
                        or match in document.get("description", "")
                        or match in document.get("code", "")
                    ):
                        filtered_docs.append(document)
                grouped_documents[code] = filtered_docs
            else:
                grouped_documents[code] = documents

        if output == "json":
            return grouped_documents
        elif output == "df":
            # For DataFrame, flatten the grouped structure
            flattened = []
            for code, documents in grouped_documents.items():
                for doc in documents:
                    flattened.append({"code": code, **doc})
            return pd.json_normalize(flattened)
        else:
            raise EigenException(
                f"Unsupported output format: {output}. Use 'json', 'df', or 'raw'."
            )

    def getLabels(self, codes: Union[str, list] = None, output: str = "json"):
        """Retrieve asset node labels.

        Args:
            codes (str|list, optional): Node codes to filter by. Defaults to None (all labels).
            output (str, optional): Output format: "json", "df", or "raw". Defaults to "json".

        Returns:
            list|pandas.DataFrame|dict|None: Node labels in requested format. Returns None if output="file".

        Raises:
            EigenException: If query fails.

        Docs:
            https://docs.eigeningenuity.co/developing-with-eigen/python-library/asset-model/get-labels
        """
        if codes is None:
            # Get all labels in the database
            payload = {"q": "CALL db.labels()"}
            resp = self._doNeo4jQueryRequest(payload)

            if output == "raw":
                return resp

            if not resp["success"]:
                raise EigenException(
                    f"Query failed: {resp.get('errors', 'Unknown error')}"
                )

            response_data = resp["response"]["data"]
            labels = [item["label"] for item in response_data]

            if output == "json":
                return labels
            elif output == "df":
                return pd.DataFrame({"label": labels})
            else:
                raise EigenException(
                    f"Unsupported output format: {output}. Use 'json', 'df', or 'raw'."
                )
        else:
            # Get labels for specific nodes
            codes_list = force_list(codes)

            # Build a single efficient query for all codes
            code_conditions = []
            for code in codes_list:
                code_conditions.append(f"n.code = '{code}'")

            # Combine all code conditions with OR
            code_match = " OR ".join(code_conditions)

            # Single query to get labels for all nodes
            query = f"""
            MATCH (n:EI_CURRENT) 
            WHERE ({code_match})
            RETURN n.code as code, labels(n) as labels
            ORDER BY n.code
            """

            payload = {"q": query}
            resp = self._doNeo4jQueryRequest(payload)

            if output == "raw":
                return resp

            if not resp["success"]:
                raise EigenException(
                    f"Query failed: {resp.get('errors', 'Unknown error')}"
                )

            response_data = resp["response"]["data"]

            # Handle single code case for backward compatibility
            if isinstance(codes, str) and len(response_data) > 0:
                if output == "json":
                    return response_data[0]["labels"]
                elif output == "df":
                    return pd.DataFrame({"label": response_data[0]["labels"]})

            # Handle multiple codes case
            if output == "json":
                return response_data
            elif output == "df":
                return pd.json_normalize(response_data)
            else:
                raise EigenException(
                    f"Unsupported output format: {output}. Use 'json', 'df', or 'raw'."
                )

    def getMatchingNodes(
        self,
        criteria: dict,
        match_all: bool = True,
        exact: bool = False,
        output: str = "json",
    ):
        """Find nodes in AssetModel matching given criteria.

        Args:
            criteria (dict): Filter criteria with optional special keys:
                - "@labels" (str|list): Node labels to match.
                - "@ids" (str|list): Node IDs to match.
                - Any other property to match on node properties.
            match_all (bool, optional): All conditions (AND) if True, else any (OR). Defaults to True.
            exact (bool, optional): Exact match for strings if True; otherwise CONTAINS is used. Defaults to False.
            output (str, optional): Output format: "json", "df", or "raw". Defaults to "json".

        Returns:
            list|pandas.DataFrame|dict|None: Matching nodes in requested format. Returns None if output="file".

        Raises:
            EigenException: If query fails.
            ValueError: If criteria is empty or invalid.

        Docs:
            https://docs.eigeningenuity.co/developing-with-eigen/python-library/asset-model/get-matching-nodes
        """

        if not criteria:
            raise ValueError("Criteria dictionary cannot be empty")

        # Build match conditions
        conditions = []
        match_statement = "MATCH (n)"

        # Handle special @labels key
        if "@labels" in criteria:
            labels = force_list(criteria["@labels"])
            label_conditions = []
            for label in labels:
                # Build label matching - labels are specified in MATCH clause
                if not label_conditions:  # First label
                    match_statement = f"MATCH (n:{label})"
                else:
                    # For multiple labels, we need to check if node has all/any labels
                    label_conditions.append(f"'{label}' IN labels(n)")

            if label_conditions:  # Additional labels beyond the first
                if match_all:
                    conditions.extend(label_conditions)
                else:
                    conditions.append("(" + " OR ".join(label_conditions) + ")")

        # Handle special @ids key
        if "@ids" in criteria:
            ids = force_list(criteria["@ids"])
            id_conditions = []
            for node_id in ids:
                id_conditions.append(f"id(n) = {node_id}")

            if match_all:
                conditions.extend(id_conditions)
            else:
                conditions.append("(" + " OR ".join(id_conditions) + ")")

        # Handle regular properties
        for prop, value in criteria.items():
            if prop.startswith("@"):  # Skip special keys we already handled
                continue

            values = force_list(value)
            prop_conditions = []

            for val in values:
                # Handle different data types appropriately
                if isinstance(val, bool):
                    # Booleans: always use exact match (= operator)
                    prop_conditions.append(f"n.{prop} = {str(val).lower()}")
                elif isinstance(val, (int, float)):
                    # Numbers: always use exact match (= operator)
                    prop_conditions.append(f"n.{prop} = {val}")
                elif isinstance(val, str):
                    # Strings: use exact or CONTAINS based on exact parameter
                    if exact:
                        prop_conditions.append(f"n.{prop} = '{val}'")
                    else:
                        prop_conditions.append(f"n.{prop} CONTAINS '{val}'")
                else:
                    # Other types: convert to string and use exact match
                    prop_conditions.append(f"n.{prop} = '{str(val)}'")

            if match_all:
                conditions.extend(prop_conditions)
            else:
                conditions.append("(" + " OR ".join(prop_conditions) + ")")

        # Combine all conditions
        if conditions:
            if match_all:
                where_clause = " AND ".join(conditions)
            else:
                where_clause = " OR ".join(conditions)
            query = f"{match_statement} WHERE {where_clause} RETURN n ORDER BY n.code"
        else:
            query = f"{match_statement} RETURN n ORDER BY n.code"

        payload = {"q": query}
        resp = self._doNeo4jQueryRequest(payload)

        # Handle raw output - return full response even if success is false
        if output == "raw":
            return resp

        # Check if query was successful
        if not resp["success"]:
            raise EigenException(f"Query failed: {resp.get('errors', 'Unknown error')}")

        response_data = resp = [item["n"] for item in resp["response"]["data"]]

        if output == "json":
            return response_data
        elif output == "df":
            return pd.json_normalize(response_data)
        else:
            raise EigenException(
                f"Unsupported output format: {output}. Use 'json', 'df', or 'raw'."
            )

    def getRelatedAssets(
        self,
        nodes: Union[str, list],
        prop: str = "code",
        exact: bool = False,
        relation: str = None,
        output: str = "json",
    ):
        """Fetch assets related to given source asset nodes.

        Args:
            nodes (str|list): Asset identifiers to match.
            prop (str, optional): Property used for matching. Defaults to "code".
            exact (bool, optional): Exact matching when True, partial otherwise. Defaults to False.
            relation (str, optional): Relationship type filter. Defaults to None.
            output (str, optional): Output format: "json", "df", or "raw". Defaults to "json".

        Returns:
            list|pandas.DataFrame|dict|None: Related assets. Returns None if output="file".

        Raises:
            EigenException: If query fails.

        Docs:
            https://docs.eigeningenuity.co/developing-with-eigen/python-library/asset-model/get-related-assets
        """
        nodes_list = force_list(nodes)

        # Build a single efficient query for all nodes
        node_conditions = []
        for node in nodes_list:
            if exact:
                node_conditions.append(f"n.{prop} = '{node}'")
            else:
                node_conditions.append(f"n.{prop} CONTAINS '{node}'")

        # Combine all node conditions with OR
        node_match = " OR ".join(node_conditions)

        # Build relationship filter
        relation_filter = f":{relation}" if relation else ""

        # Single query to get all related assets for all nodes
        query = f"""
        MATCH (n)-[r{relation_filter}]-(m:AssetObject) 
        WHERE ({node_match})
        RETURN n.{prop} as sourceNode, m as relatedAsset, type(r) as relationshipType
        ORDER BY n.{prop}, m.code
        """

        payload = {"q": query}
        resp = self._doNeo4jQueryRequest(payload)

        # Handle raw output - return full response even if success is false
        if output == "raw":
            return resp

        # Check if query was successful
        if not resp["success"]:
            raise EigenException(f"Query failed: {resp.get('errors', 'Unknown error')}")

        response_data = resp["response"]["data"]

        if output == "json":
            return response_data
        elif output == "df":
            return pd.json_normalize(response_data)
        else:
            raise EigenException(
                f"Unsupported output format: {output}. Use 'json', 'df', or 'raw'."
            )


def get_assetmodel(
    eigenserver: EigenServer = None, instance: str = "default"
) -> AssetModel:
    """Convenience function to instantiate an AssetModel client.

    Args:
        eigenserver (EigenServer|str|None): EigenServer instance or base URL. Defaults to EIGENSERER env var if None.
        instance (str, optional): Neo4j instance name (default "default").

    Returns:
        AssetModel: Initialized AssetModel client.

    Docs:
        https://docs.eigeningenuity.co/developing-with-eigen/python-library/asset-model/get-assetmodel
    """
    if eigenserver is None:
        eigenserver = get_default_server()
    elif isinstance(eigenserver, str):
        eigenserver = EigenServer(eigenserver)

    return AssetModel(eigenserver.getEigenServerUrl() + "/", eigenserver.auth, instance)


# Aliases
Neo4J = AssetModel  # Alias for AssetModel class
get_neo4j = get_assetmodel  # Alias for get_assetmodel function
