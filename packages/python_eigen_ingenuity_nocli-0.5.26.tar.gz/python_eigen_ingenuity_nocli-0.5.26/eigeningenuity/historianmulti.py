"""Eigen Ingenuity - Historian

This package deals with the Eigen Ingenuity Historian API, mostly by means
of the JSON Bridge Historian.

To get a historian object to work with, use get_historian(xxx) with either
an instance name (which will be resolved via the the usual methods in
eigeningenuity.core) or a full URL to a JSON Bridge Historian instance.

  from eigeningenuity.historian import get_historian
  from time import gmtime, asctime

  h = get_historian("pi-opc")
  tags = h.listDataTags()
  for tag in tags:
      dp = h.getCurrentDataPoint(tag)
      print(asctime(time.gmtime(dp['timestamp'])), dp['value'])
"""

import requests
import re
from typing import Union
from datetime import datetime

from requests.exceptions import ConnectionError
from urllib.error import URLError
from eigeningenuity.core import get_default_server, EigenServer
from eigeningenuity.util import (
    force_list,
    time_to_epoch_millis,
    EigenException,
    merge_tags_from_response,
    update_keys,
    _do_historian_multi_request,
    format_output,
)


class HistorianMulti(object):
    """A Historian which talks the Eigen Historian Json Bridge protocol."""

    def __init__(self, baseurl, auth, historian, timestamp_format):
        """This is a constructor. It takes in a URL like http://infra:8080/historian-servlet/jsonbridge/Demo-influxdb"""
        self.baseurl = baseurl
        self.serverurl = baseurl + "multi/"
        self.writeurl = baseurl + "write/points"
        self.metaurl = baseurl + "metadata"
        self.listurl = baseurl + "list"
        self.searchurl = baseurl + "search"

        self.auth = auth
        self.historian = ""
        if historian:
            self.historian = historian + "/"
        self.timestamp_format = timestamp_format

    def _testConnection(self):
        try:
            status = requests.get(self.serverurl, verify=False).status_code
            if status != 200:
                raise ConnectionError(
                    "Invalid API Response from "
                    + self.serverurl
                    + ". Please check the url is correct and the instance is up."
                )
        except (URLError, ConnectionError):
            raise ConnectionError(
                "Failed to connect to ingenuity instance at "
                + self.serverurl
                + ". Please check the url is correct and the instance is up."
            )

    # SECTION Read Requests

    def getCurrentDataPoints(self, tags: Union[str, list], output: str = "json"):
        """Get the latest value for one or more tags.

        Args:
            tags (Union[str, list]): Tag name or list of tags to read the latest values from.
            output (str, optional): Output format selector. Accepts "json", "df", "raw", "string". Defaults to "json".

        Returns:
            dict|list|pandas.DataFrame|str: Latest values for the tags. Format depends on output parameter.

        Raises:
            ValueError: When invalid Output Type is given
            URLError: If no Ingenuity instance can be reached or no internet connection is available.
            RemoteServerException: If the historian cannot be found or the API returns an error.
            RuntimeError: If no response is received from the API.
            HTTPError: If the API request fails.
            
        Docs:
            https://docs.eigeningenuity.co/developing-with-eigen/python-library/historian-multi/reading-data/getcurrentdatapoints
        """
        tags = force_list(tags)
        body = {"requests": {}}

        for tag in tags:
            fulltag = tag
            if "/" not in tag:
                fulltag = self.historian + tag
            request = {"type": "CURRENT_POINT", "tag": fulltag, "details": {}}

            body["requests"][tag] = request

        response = _do_historian_multi_request(self.serverurl, body, self.auth)

        return format_output(
            output, response, tags, timestamp_format=self.timestamp_format
        )

    def getInterpolatedPoints(
        self,
        tags: Union[str, list],
        timestamps: Union[list, int, float, str, datetime],
        output: str = "json",
    ):
        """
        Get interpolated values for one or more tags at specific timestamps.

        Args:
            tags (Union[str, list]): Tag name or list of tags to interpolate.
            timestamps (Union[list, int, float, str, datetime]): One or more timestamps to query.
            output (str, optional): Output format selector. Accepts "json", "df", "raw", "string". Defaults to "json".

        Returns:
            dict|list|pandas.DataFrame|str: Interpolated values at the specified timestamps. Format depends on output parameter.

        Raises:
            ValueError: When invalid Output Type is given
            URLError: If no Ingenuity instance can be reached or no internet connection is available.
            RemoteServerException: If the historian cannot be found or the API returns an error.
            RuntimeError: If no response is received from the API.
            HTTPError: If the API request fails.
            
        Docs:
            https://docs.eigeningenuity.co/developing-with-eigen/python-library/historian-multi/reading-data/getinterpolatedpoints
        """
        body = {"requests": {}}

        tags = force_list(tags)
        timestamps = force_list(timestamps)
        timestamps = [time_to_epoch_millis(timestamp) for timestamp in timestamps]

        for tag in tags:
            fulltag = tag
            if "/" not in tag:
                fulltag = self.historian + tag
            for index, timestamp in enumerate(timestamps):
                request = {
                    "type": "HISTORICAL_POINT",
                    "tag": fulltag,
                    "details": {"at": timestamp},
                }

                body["requests"][tag + "-" + str(index)] = request

        response = _do_historian_multi_request(self.serverurl, body, self.auth)
        items = merge_tags_from_response(response["results"])

        return format_output(
            output, items, tags, timestamps, timestamp_format=self.timestamp_format
        )

    def getInterpolatedRange(
        self,
        tags: Union[str, list],
        start: Union[int, float, str, datetime],
        end: Union[int, float, str, datetime],
        count: int = 1000,
        output: str = "json",
    ):
        """Get evenly spaced points between a start and end time.

        Args:
            tags (Union[str, list]): Tag name or list of tags to interpolate.
            start (Union[int, float, str, datetime]): Start of time window.
            end (Union[int, float, str, datetime]): End of time window.
            count (int, optional): Number of points per tag. Defaults to 1000.
            output (str, optional): Output format selector. Accepts "json", "df", "raw", "string". Defaults to "json".

        Returns:
            dict|list|pandas.DataFrame|str: Evenly spaced interpolated points. Format depends on output parameter.

        Raises:
            ValueError: When invalid Output Type is given
            URLError: If no Ingenuity instance can be reached or no internet connection is available.
            RemoteServerException: If the historian cannot be found or the API returns an error.
            RuntimeError: If no response is received from the API.
            HTTPError: If the API request fails.
            
        Docs:
            https://docs.eigeningenuity.co/developing-with-eigen/python-library/historian-multi/reading-data/getinterpolatedrange
        """

        body = {"requests": {}}

        tags = force_list(tags)

        for tag in tags:
            fulltag = tag
            if "/" not in tag:
                fulltag = self.historian + tag
            request = {
                "type": "INTERPOLATED_POINTS",
                "tag": fulltag,
                "details": {
                    "from": time_to_epoch_millis(start),
                    "to": time_to_epoch_millis(end),
                    "count": count,
                },
            }

            body["requests"][tag] = request

        response = _do_historian_multi_request(self.serverurl, body, self.auth)

        return format_output(
            output, response, tags, timestamp_format=self.timestamp_format
        )

    def getRawDatapoints(
        self,
        tags: Union[str, list],
        start: Union[int, float, str, datetime],
        end: Union[int, float, str, datetime],
        maxpoints: int = 1000,
        output: str = "json",
    ):
        """Get raw stored points between a start and end time.

        Args:
            tags (Union[str, list]): Tag name or list of tags to read raw points for.
            start (Union[int, float, str, datetime]): Start of time window.
            end (Union[int, float, str, datetime]): End of time window.
            maxpoints (int, optional): Maximum number of points returned. Defaults to 1000.
            output (str, optional): Output format selector. Accepts "json", "df", "raw", "string". Defaults to "json".

        Returns:
            dict|list|pandas.DataFrame|str: Raw stored points. Format depends on output parameter.

        Raises:
            ValueError: When invalid Output Type is given
            URLError: If no Ingenuity instance can be reached or no internet connection is available.
            RemoteServerException: If the historian cannot be found or the API returns an error.
            RuntimeError: If no response is received from the API.
            HTTPError: If the API request fails.
            
        Docs:
            https://docs.eigeningenuity.co/developing-with-eigen/python-library/historian-multi/reading-data/getrawdatapoints
        """

        body = {"requests": {}}

        tags = force_list(tags)

        for tag in tags:
            fulltag = tag
            if "/" not in tag:
                fulltag = self.historian + tag
            request = {
                "type": "RAW_POINTS",
                "tag": fulltag,
                "details": {
                    "from": time_to_epoch_millis(start),
                    "to": time_to_epoch_millis(end),
                    "maxPoints": maxpoints,
                },
            }

            body["requests"][tag] = request

        response = _do_historian_multi_request(self.serverurl, body, self.auth)

        return format_output(
            output, response, tags, timestamp_format=self.timestamp_format
        )

    def getClosestRawPoint(
        self,
        tags: Union[str, list],
        timestamps: Union[int, float, str, datetime, list],
        before_or_after: str = "AFTER_OR_AT",
        output: str = "json",
    ):
        """Get the closest raw point to one or more timestamps.

            Args:
                tags (Union[str, list]): Tag name or list of tags to query.
                timestamps (Union[int, float, str, datetime, list]): One or more timestamps to find closest raw points for.
                before_or_after (str, optional): Selection rule for closest point. Defaults to "AFTER_OR_AT".
                output (str, optional): Output format selector. Accepts "json", "df", "raw", "string". Defaults to "json".

            Returns:
                dict|list|pandas.DataFrame|str: Closest raw points to the timestamps. Format depends on output parameter.

            Raises:
                ValueError: When invalid Output Type is given
                URLError: If no Ingenuity instance can be reached or no internet connection is available.
                RemoteServerException: If the historian cannot be found or the API returns an error.
                RuntimeError: If no response is received from the API.
                HTTPError: If the API request fails.
                
            Docs:
                https://docs.eigeningenuity.co/developing-with-eigen/python-library/historian-multi/reading-data/getclosestrawpoint
        """
        before_or_after = before_or_after.upper()

        if before_or_after.upper() not in [
            "BEFORE",
            "BEFORE_OR_AT",
            "AFTER",
            "AFTER_OR_AT",
        ]:
            raise EigenException(
                'before_or_after must be one of ["BEFORE", "BEFORE_OR_AT", "AFTER", "AFTER_OR_AT"]'
            )

        body = {"requests": {}}

        tags = force_list(tags)
        timestamps = force_list(timestamps)
        timestamps = [time_to_epoch_millis(timestamp) for timestamp in timestamps]

        for tag in tags:
            fulltag = tag
            if "/" not in tag:
                fulltag = self.historian + tag
            for index, timestamp in enumerate(timestamps):
                request = {
                    "type": f"POINT_{before_or_after.upper()}",
                    "tag": fulltag,
                    "details": {
                        "at": time_to_epoch_millis(timestamp),
                    },
                }

                body["requests"][tag + "-" + str(index)] = request

        response = _do_historian_multi_request(self.serverurl, body, self.auth)
        items = merge_tags_from_response(response["results"])

        return format_output(
            output, items, tags, timestamps, timestamp_format=self.timestamp_format
        )

    # SECTION - Tag Aggregation Requests

    def getAggregates(
        self,
        tags: Union[str, list],
        start: Union[int, float, str, datetime],
        end: Union[int, float, str, datetime],
        intervals: int = 1,
        aggregates: Union[str, list] = None,
        output: str = "json",
    ):
        """Get aggregate statistics over a time window.

        Args:
            tags (Union[str, list]): Tag name or list of tags to aggregate.
            start (Union[int, float, str, datetime]): Start of time window.
            end (Union[int, float, str, datetime]): End of time window.
            intervals (int, optional): Number of aggregate windows. Defaults to 1.
            aggregates (Union[str, list], optional): List of aggregate functions to return. Allowed values: "FIRST", "AVG", "NUMGOOD", "MAX", "LAST", "VAR", "MEDIAN", "NUMBAD", "MIN", "COUNT", "STDDEV". Defaults to all.
            output (str, optional): Output format selector. Accepts "json", "df", "raw", "string". Defaults to "json".

        Returns:
            dict|list|pandas.DataFrame|str: Aggregate statistics. Format depends on output parameter.

        Raises:
            ValueError: When invalid Output Type is given
            URLError: If no Ingenuity instance can be reached or no internet connection is available.
            RemoteServerException: If the historian cannot be found or the API returns an error.
            RuntimeError: If no response is received from the API.
            HTTPError: If the API request fails.
            
        Docs:
            https://docs.eigeningenuity.co/developing-with-eigen/python-library/historian-multi/reading-data/getaggregates
        """
        body = {"requests": {}}
        allowed_aggregates = [
            "FIRST",
            "AVG",
            "NUMGOOD",
            "MAX",
            "LAST",
            "VAR",
            "MEDIAN",
            "NUMBAD",
            "MIN",
            "COUNT",
            "STDDEV",
        ]

        if aggregates is None:
            aggregates = allowed_aggregates
        aggregates = list(map(lambda x: x.upper(), aggregates))
        aggregates = list(filter(lambda x: x in allowed_aggregates, aggregates))

        if aggregates == []:
            raise EigenException(
                "No valid aggregates provided. Allowed aggregates are: "
                + ", ".join(allowed_aggregates)
            )

        tags = force_list(tags)
        aggregates = force_list(aggregates)

        for tag in tags:
            fulltag = tag
            if "/" not in tag:
                fulltag = self.historian + tag
            request = {
                "type": "MULTIPLE_AGGREGATED_POINTS",
                "tag": fulltag,
                "details": {
                    "from": time_to_epoch_millis(start),
                    "to": time_to_epoch_millis(end),
                    "aggregates": aggregates,
                    "count": intervals,
                },
            }

            body["requests"][tag] = request

        response = _do_historian_multi_request(self.serverurl, body, self.auth)

        return format_output(
            output,
            response,
            tags,
            timestamp_format=self.timestamp_format,
            is_aggregate=True,
            aggregates=aggregates,
        )

    def getAggregateIntervals(
        self,
        tags: Union[str, list],
        start: Union[int, float, str, datetime],
        end: Union[int, float, str, datetime],
        interval_size: str = None,
        aggregates: Union[str, list] = None,
        final_interval_behavior: str = "EXCLUDE",
        output: str = "json",
    ):
        """Get aggregates split into fixed-length intervals (e.g. hourly).

        Args:
            tags (Union[str, list]): Tag name or list of tags to aggregate.
            start (Union[int, float, str, datetime]): Start of time window.
            end (Union[int, float, str, datetime]): End of time window.
            interval_size (str, optional): Interval size string (e.g. "1h").
            aggregates (Union[str, list], optional): List of aggregate functions to return. Allowed values: "FIRST", "AVG", "NUMGOOD", "MAX", "LAST", "VAR", "MEDIAN", "NUMBAD", "MIN", "COUNT", "STDDEV". If omitted returns all.
            final_interval_behavior (str, optional): How to handle partial final interval. Defaults to "EXCLUDE".
            output (str, optional): Output format selector. Accepts "json", "df", "raw", "string". Defaults to "json".

        Returns:
            dict|list|pandas.DataFrame|str: Aggregates split into intervals. Format depends on output parameter.

        Raises:
            ValueError: When invalid Output Type is given or invalid interval_size format.
            URLError: If no Ingenuity instance can be reached or no internet connection is available.
            RemoteServerException: If the historian cannot be found or the API returns an error.
            RuntimeError: If no response is received from the API.
            HTTPError: If the API request fails.
            
        Docs:
            https://docs.eigeningenuity.co/developing-with-eigen/python-library/historian-multi/reading-data/getaggregateintervals
        """
        start_ms = time_to_epoch_millis(start)
        end_ms = time_to_epoch_millis(end)

        allowed_final_interval_behaviors = ["INCLUDE", "EXCLUDE"]
        final_interval_behavior = final_interval_behavior.upper()
        if final_interval_behavior not in allowed_final_interval_behaviors:
            raise EigenException(
                f"final_interval_behavior must be one of: {', '.join(allowed_final_interval_behaviors)}"
            )

        # Calculate window duration in ms
        window_duration_ms = end_ms - start_ms

        # Parse interval_size (e.g., "1h", "30m", "5s")
        match = re.match(r"(\d+)(s|m|h|d|w|y)", interval_size)
        if not match:
            raise ValueError(f"Invalid interval_size format: {interval_size}")

        amount, unit = int(match.group(1)), match.group(2)

        # Convert interval to milliseconds
        unit_to_ms = {
            "s": 1000,
            "m": 60 * 1000,
            "h": 60 * 60 * 1000,
            "d": 24 * 60 * 60 * 1000,
            "w": 7 * 24 * 60 * 60 * 1000,
            "y": 365 * 24 * 60 * 60 * 1000,  # approximate
        }
        interval_ms = amount * unit_to_ms[unit]

        # Calculate number of intervals
        num_intervals = window_duration_ms / interval_ms

        # Adjust based on final_interval_behavior
        if final_interval_behavior == "INCLUDE":
            num_intervals = int(num_intervals) + (
                1 if num_intervals % 1 > 0 else 0
            )  # Ceiling
        elif final_interval_behavior == "EXCLUDE":
            num_intervals = int(num_intervals)  # Floor

        adjusted_end_ms = start_ms + (num_intervals * interval_ms)

        if num_intervals <= 0:
            raise EigenException(
                "Calculated number of intervals is zero or negative. Please check the interval_size and time range."
            )
        elif num_intervals > 1000:
            raise EigenException(
                f"Calculated number of intervals exceeds maximum limit of 1,000 ({num_intervals}). Please increase interval_size or reduce time range."
            )

        return self.getAggregates(
            tags,
            start_ms,
            adjusted_end_ms,
            intervals=num_intervals,
            aggregates=aggregates,
            output=output,
        )

    # SECTION - Tag Metadata Requests

    def listDataTags(self, historian: str = None, limit: int = 100, match: str = ""):
        """List tag names for a historian, optionally filtered with a wildcard.

        Args:
            historian (str, optional): Historian name to search.
            limit (int, optional): Max number of tags returned. Defaults to 100.
            match (str, optional): Wildcard pattern for tag names. Defaults to "".

        Returns:
            list[str]: List of tag names.

        Raises:
            URLError: If no Ingenuity instance can be reached or no internet connection is available.
            RemoteServerException: If the historian cannot be found or the API returns an error.
            RuntimeError: If no response is received from the API.
            HTTPError: If the API request fails.
            
        Docs:
            https://docs.eigeningenuity.co/developing-with-eigen/python-library/historian-multi/metadata/listdatatags
        """
        metadata = self.getMetaData(historian, limit, match)

        tags = [tag["tagName"] for tag in metadata]

        return tags

    def getMetaData(self, historian: str = None, limit: int = 100, match: str = ""):
        """Fetch tag metadata for a historian, optionally filtered with a wildcard.

        Args:
            historian (str, optional): Historian name to search.
            limit (int, optional): Max number of tags returned. Defaults to 100.
            match (str, optional): Wildcard pattern for tag names. Defaults to "".

        Returns:
            list[dict]: List of metadata dictionaries for each tag.

        Raises:
            URLError: If no Ingenuity instance can be reached or no internet connection is available.
            RemoteServerException: If the historian cannot be found or the API returns an error.
            RuntimeError: If no response is received from the API.
            HTTPError: If the API request fails.
            
        Docs:
            https://docs.eigeningenuity.co/developing-with-eigen/python-library/historian-multi/metadata/getmetadata
        """
        if historian is None:
            historian = self.historian

        resp = _do_historian_multi_request(
            self.searchurl + f"?historian={historian}&limit={limit}&search={match}",
            {},
            self.auth,
            get_request=True,
        )
        metadata = resp["tags"]

        return metadata

    def listHistorians(self, writable):
        """Retrieve all historians available on the Ingenuity instance.

        Optionally filters to only those that are writable.

        Args:
            writable (bool, optional): If True, only return historians that accept data points.

        Returns:
            list[str]: List of available historians.

        Raises:
            URLError: If no Ingenuity instance can be reached or no internet connection is available.
            RemoteServerException: If the historian cannot be found or the API returns an error.
            RuntimeError: If no response is received from the API.
            HTTPError: If the API request fails.
            
        Docs:
            https://docs.eigeningenuity.co/developing-with-eigen/python-library/historian-multi/metadata/listhistorians
        """

        resp = _do_historian_multi_request(
            self.listurl + "writable" if writable else self.listurl,
            {},
            self.auth,
            get_request=True,
        )
        
        historians = resp["historians"]
        
        metadata = [x["name"] for x in historians]

        return metadata

    def createTag(
        self,
        tag: str,
        description: str = None,
        units: str = None,
        stepped: bool = False,
        update_existing: bool = False,
    ):
        """Create a tag with metadata.

        Args:
            tag (str): Tag name to create.
            description (str, optional): Optional description.
            units (str, optional): Optional engineering units.
            stepped (bool, optional): Set true for discrete values. Defaults to False.
            update_existing (bool, optional): Overwrite metadata if tag exists. Defaults to False.

        Returns:
            dict: Success status and any errors.

        Raises:
            URLError: If no Ingenuity instance can be reached or no internet connection is available.
            RemoteServerException: If the historian cannot be found or the API returns an error.
            RuntimeError: If no response is received from the API.
            HTTPError: If the API request fails.
            
        Docs:
            https://docs.eigeningenuity.co/developing-with-eigen/python-library/historian-multi/metadata/createtag
        """
        url = self.metaurl + "/create"

        if "/" not in tag:
            tag = self.historian + tag

        metadata = {}

        for key, value in [
            ("description", description),
            ("units", units),
            ("stepped", stepped),
        ]:
            if value is not None:
                metadata[key] = value

        body = {"entries": {f"{tag}": metadata}, "updateIfExists": update_existing}

        resp = _do_historian_multi_request(url, body, self.auth)

        if len(resp["errors"].keys()):
            success = False
        else:
            success = True

        return {"success": success, "errors": resp["errors"]}

    def updateTag(
        self,
        tag: str,
        description: str = None,
        units: str = None,
        stepped: bool = False,
        create_missing: bool = False,
    ):
        """Update or create metadata for a tag.

        Args:
            tag (str): Tag name to update.
            description (str, optional): Optional description.
            units (str, optional): Optional engineering units.
            stepped (bool, optional): Set true for discrete values. Defaults to False.
            create_missing (bool, optional): Create tag if it does not exist. Defaults to False.

        Returns:
            dict: Success status and any errors.

        Raises:
            URLError: If no Ingenuity instance can be reached or no internet connection is available.
            RemoteServerException: If the historian cannot be found or the API returns an error.
            RuntimeError: If no response is received from the API.
            HTTPError: If the API request fails.
            
        Docs:
            https://docs.eigeningenuity.co/developing-with-eigen/python-library/historian-multi/metadata/updatetag
        """
        url = self.metaurl + "/update"

        if "/" not in tag:
            tag = self.historian + tag

        metadata = {}

        for key, value in [
            ("description", description),
            ("units", units),
            ("stepped", stepped),
        ]:
            if value is not None:
                metadata[key] = value

        body = {"entries": {f"{tag}": metadata}, "createIfMissing": create_missing}

        resp = _do_historian_multi_request(url, body, self.auth)

        if len(resp["errors"].keys()):
            success = False
        else:
            success = True

        return {"success": success, "errors": resp["errors"]}

    def createAndPopulateTag(
        self,
        tag: str,
        points: Union[dict, list],
        description: str = None,
        units: str = None,
        stepped: bool = False,
        update_existing: bool = True,
    ):
        """Create a tag with metadata and immediately write points.

        Args:
            tag (str): Tag name to create or update.
            points (Union[dict, list]): List of points to write after creation.
            description (str, optional): Optional description.
            units (str, optional): Optional engineering units.
            stepped (bool, optional): Set true for discrete values. Defaults to False.
            update_existing (bool, optional): Overwrite metadata if tag exists. Defaults to True.

        Returns:
            dict: Success status for creation and writing, with errors.

        Raises:
            URLError: If no Ingenuity instance can be reached or no internet connection is available.
            RemoteServerException: If the historian cannot be found or the API returns an error.
            RuntimeError: If no response is received from the API.
            HTTPError: If the API request fails.
            
        Docs:
            https://docs.eigeningenuity.co/developing-with-eigen/python-library/historian-multi/writing-data/createandpopulatetag
        """
        url = self.metaurl + "/create"

        if "/" not in tag:
            tag = self.historian + tag

        metadata = {}

        for key, value in [
            ("description", description),
            ("units", units),
            ("stepped", stepped),
        ]:
            if value is not None:
                metadata[key] = value

        body = {"entries": {f"{tag}": metadata}, "updateIfExists": update_existing}

        createResp = _do_historian_multi_request(url, body, self.auth)

        if len(createResp["errors"].keys()):
            createSuccess = False
        else:
            createSuccess = True

        body = {"points": {tag: force_list(points)}, "createTags": False}

        message = _do_historian_multi_request(self.writeurl, body, self.auth, True)

        if message == "All points written!":
            writeSuccess = True
        else:
            ret = writeSuccess = True

        return {
            "success": createSuccess and writeSuccess,
            "createTag": {"success": createSuccess, "errors": createResp["errors"]},
            "writePoints": {"success": writeSuccess, "message": message},
        }

    # SECTION - Write Requests

    def writePoints(self, tag: str, points: Union[dict, list]):
        """Write one or more points to a single tag. Tags are created automatically if missing.

        Args:
            tag (str): Tag name to write to.
            points (Union[dict, list]): One point dict or a list of points with `value`, `timestamp`, optional `status`.

        Returns:
            dict: Success status and message.

        Raises:
            URLError: If no Ingenuity instance can be reached or no internet connection is available.
            RemoteServerException: If the historian cannot be found or the API returns an error.
            RuntimeError: If no response is received from the API.
            HTTPError: If the API request fails.
            
        Docs:
            https://docs.eigeningenuity.co/developing-with-eigen/python-library/historian-multi/writing-data/writepoints
        """
        points = force_list(points)
        if "/" not in tag:
            tag = self.historian + tag

        for point in points:
            if "status" not in point.keys():
                point["status"] = "OK"
            point["timestamp"] = time_to_epoch_millis(point["timestamp"])

        body = {"points": {tag: points}, "createTags": True}

        message = _do_historian_multi_request(self.writeurl, body, self.auth, True)

        if message == "All points written!":
            ret = {"success": True, "message": message}
        else:
            ret = {"success": False, "message": message}

        return ret

    def writePointsBatch(self, data: Union[dict, list]):
        """Write points to multiple tags in a single request.

        Args:
            data (Union[dict, list]): Dict or list of dicts mapping tag names to lists of points.

        Returns:
            dict: Success status and message.

        Raises:
            URLError: If no Ingenuity instance can be reached or no internet connection is available.
            RemoteServerException: If the historian cannot be found or the API returns an error.
            RuntimeError: If no response is received from the API.
            HTTPError: If the API request fails.
            
        Docs:
            https://docs.eigeningenuity.co/developing-with-eigen/python-library/historian-multi/writing-data/writepointsbatch
        """
        data = force_list(data)

        payload = {}
        tags = []

        for item in data:
            if set(item.keys()).intersection(set(tags)):
                for tag in set(item.keys()).intersection(set(tags)):
                    payload[tag] += item[tag]
                    item.pop(tag)
            payload = payload | item
            tags += item.keys()

        for key in payload.keys():
            for datapoint in payload[key]:
                if "status" not in datapoint.keys():
                    datapoint["status"] = "OK"
                datapoint["timestamp"] = time_to_epoch_millis(datapoint["timestamp"])

        payload = update_keys(payload, self.historian)

        body = {"points": payload, "createTags": True}

        message = _do_historian_multi_request(self.writeurl, body, self.auth, True)

        if message == "All points written!":
            ret = {"success": True, "message": message}
        else:
            ret = {"success": False, "message": message}

        return ret


# SECTION - Utility Functions


def createPoint(
    value: Union[int, float], timestamp: Union[int, str, datetime], status: str = "OK"
):
    """Build a point payload for write requests.

    Args:
        value (Union[int, float]): Numeric value to store.
        timestamp (Union[int, str, datetime]): Timestamp for the value.
        status (str, optional): Quality flag (`OK` or `BAD`). Defaults to "OK".

    Returns:
        dict: Structured point dictionary.

    Raises:
        EigenException: If status is not "OK" or "BAD".
        
    Docs:
        https://docs.eigeningenuity.co/developing-with-eigen/python-library/historian-multi/writing-data/createpoint
    """
    if status not in ["OK", "BAD"]:
        raise EigenException("Bad Status Parameter, must be 'OK' or 'BAD'")
    return {"value": value, "timestamp": timestamp, "status": status}


def get_historian_multi(
    eigenserver=None, default_historian=None, timestamp_format="iso"
) -> HistorianMulti:
    """Create a Historian Multi client.

    Args:
        eigenserver (optional): EigenServer object or URL string.
        default_historian (str, optional): Default historian name.
        timestamp_format (str, optional): Timestamp format ("iso" or "epoch"). Defaults to "iso".

    Returns:
        HistorianMulti: An object that can be used to query historian data.
        
    Docs:
        https://docs.eigeningenuity.co/developing-with-eigen/python-library/historian-multi/get_historian_multi
    """
    if eigenserver is None:
        eigenserver = get_default_server()
    elif isinstance(eigenserver, str):
        eigenserver = EigenServer(eigenserver)

    return HistorianMulti(
        eigenserver.getEigenServerUrl() + "historian" + "/",
        eigenserver.auth,
        default_historian,
        timestamp_format,
    )
