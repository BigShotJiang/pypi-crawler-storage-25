import requests
from datetime import datetime
from eigeningenuity.core import get_default_server, EigenServer
from eigeningenuity.util import (
    force_list,
    get_eigenserver,
    parseEvents,
    _do_chunked_eigen_post_request,
    _do_eigen_post_request,
    validate_eventlog_query,
)

from typing import Union


class EventLog(object):
    """An elasticsearch instance which talks the Eigen elastic endpoint."""

    def __init__(self, baseurl: str, default_eventlog: str, auth: bool):
        """This is a constructor. It takes in a URL like http://infra:8080/ei-applet/search/"""
        self.baseurl = baseurl
        self.eigenserver = get_eigenserver(baseurl)
        self.auth = auth
        self.default_eventlog = default_eventlog

    def _testConnection(self):
        """Preflight Request to verify connection to ingenuity"""
        try:
            status = requests.get(self.baseurl, verify=False).status_code
        except ConnectionError:
            raise ConnectionError(
                "Failed to connect to ingenuity instance at "
                + self.eigenserver
                + ". Please check the url is correct and the instance is up."
            )

    def _doJsonWriteRequest(self, relative_url: str, data: dict, label: str):
        url = self.baseurl + relative_url
        return _do_chunked_eigen_post_request(url, data, label, self.auth)

    def _doJsonReadRequest(self, relative_url: str, data: dict):
        url = self.baseurl + relative_url
        response = _do_eigen_post_request(url, data, self.auth)

        if response["success"] is not True:
            raise ValueError("Query failed: " + str(response["errors"]))

        return response["response"]

    def getEvents(
        self, query: dict, eventlog: str = "default", size: int = 1000, page: int = 0
    ) -> list:
        """Execute a raw query against the eventlog.

        Args:
            query (dict): Eventlog query dictionary with required `start` and `end`, and optional filters.
            eventlog (str, optional): Eventlog name to query. Defaults to "default".
            size (int, optional): Maximum number of results returned. Defaults to 1000.
            page (int, optional): Page number for pagination. Defaults to 0.

        Returns:
            list: Events matching the query.

        Raises:
            ValueError: If required fields are missing or invalid.
            URLError: If no Ingenuity instance can be reached or no internet connection is available.
            HTTPError: If the API request fails.
            
        Docs:
            https://docs.eigeningenuity.co/developing-with-eigen/python-library/eventlog/get-events
        """

        if eventlog == "default":
            eventlog = self.default_eventlog

        # Validate the query structure and required fields
        validate_eventlog_query(query)

        relative_url = f"/list/{eventlog}"
        body = {"request": query, "size": size, "page": page}

        response = self._doJsonReadRequest(relative_url, body)

        return response

    def getEventsBySource(
        self,
        source: Union[str, list],
        eventlog: str = "default",
        exact_match: bool = False,
        start: Union[str, datetime] = "yesterday",
        end: Union[str, datetime] = "now",
        filter: Union[str, None] = None,
        size: int = 1000,
        page: int = 0,
    ) -> list:
        """Retrieve events filtered by source.

        Args:
            source (Union[str, list]): Source identifier(s) to filter by. Allows partial matches.
            eventlog (str, optional): Eventlog name to query. Defaults to "default".
            exact_match (bool, optional): If True, only exact matches on source. Defaults to False.
            start (Union[str, datetime], optional): Start time. Defaults to "yesterday".
            end (Union[str, datetime], optional): End time. Defaults to "now".
            filter (str, optional): Additional filter using Elasticsearch Query String syntax. Defaults to None.
            size (int, optional): Maximum number of results returned. Defaults to 1000.
            page (int, optional): Page number for pagination. Defaults to 0.

        Returns:
            list: Events matching the source.

        Raises:
            ValueError: If the source is not provided.
            URLError: If no Ingenuity instance can be reached or no internet connection is available.
            HTTPError: If the API request fails.
            
        Docs:
            https://docs.eigeningenuity.co/developing-with-eigen/python-library/eventlog/get-events-by-source
        """
        if not source or not isinstance(source, (str, list)):
            raise ValueError("Source must be a non-empty string or list")

        source = force_list(source)

        if eventlog == "default":
            eventlog = self.default_eventlog

        validate_eventlog_query({"start": start, "end": end, "sources": source})

        relative_url = f"/list/{eventlog}"
        body = {
            "request": {"start": start, "end": end, "sources": source},
            "size": size,
            "page": page,
        }

        # Only include contentFilter if it's not None
        if filter is not None:
            body["request"]["contentFilter"] = filter

        response = self._doJsonReadRequest(relative_url, body)

        if exact_match:
            # Filter results to only include exact matches on source
            filtered_events = [
                event for event in response["items"] if event.get("source") in source
            ]
            return filtered_events

        return response

    def getEventsByType(
        self,
        event_type: Union[str, list],
        eventlog: str = "default",
        start: Union[str, datetime] = "yesterday",
        end: Union[str, datetime] = "now",
        filter: Union[str, None] = None,
        size: int = 1000,
        page: int = 0,
    ) -> list:
        """Retrieve events filtered by event type.

        Args:
            event_type (Union[str, list]): Event type(s) to filter by. Exact matches only.
            eventlog (str, optional): Eventlog name to query. Defaults to "default".
            start (Union[str, datetime], optional): Start time. Defaults to "yesterday".
            end (Union[str, datetime], optional): End time. Defaults to "now".
            filter (str, optional): Additional filter using Elasticsearch Query String syntax. Defaults to None.
            size (int, optional): Maximum number of results returned. Defaults to 1000.
            page (int, optional): Page number for pagination. Defaults to 0.

        Returns:
            list: Events matching the event type.

        Raises:
            ValueError: If the event type is not provided.
            URLError: If no Ingenuity instance can be reached or no internet connection is available.
            HTTPError: If the API request fails.
            
        Docs:
            https://docs.eigeningenuity.co/developing-with-eigen/python-library/eventlog/get-events-by-type
        """
        if not event_type or not isinstance(event_type, (str, list)):
            raise ValueError("Event type must be a non-empty string or list")

        event_type = force_list(event_type)

        if eventlog == "default":
            eventlog = self.default_eventlog

        validate_eventlog_query({"start": start, "end": end, "types": event_type})

        relative_url = f"/list/{eventlog}"
        body = {
            "request": {"start": start, "end": end, "types": event_type},
            "size": size,
            "page": page,
        }

        # Only include contentFilter if it's not None
        if filter is not None:
            body["request"]["contentFilter"] = filter

        response = self._doJsonReadRequest(relative_url, body)

        return response

    def getEventsById(
        self,
        event_ids: Union[str, list],
        id_type: str = "eventId",
        eventlog: str = "default",
    ) -> list:
        """Retrieve events filtered by event IDs.

        Args:
            event_ids (Union[str, list]): Event ID(s) to retrieve.
            id_type (str, optional): Type of ID to filter by. Defaults to "eventId".
                - "eventId": Unique identifier generated by Ingenuity.
                - "externalId": Unique identifier assigned by uploader.
                - "episodeId": Episode identifier for event pairs (Start/End).
            eventlog (str, optional): Eventlog name to query. Defaults to "default".

        Returns:
            list: Events matching the event IDs.

        Raises:
            ValueError: If event_ids is not provided or id_type is invalid.
            URLError: If no Ingenuity instance can be reached or no internet connection is available.
            HTTPError: If the API request fails.
            
        Docs:
            https://docs.eigeningenuity.co/developing-with-eigen/python-library/eventlog/get-events-by-id
        """

        if not event_ids or not isinstance(event_ids, (str, list)):
            raise ValueError("Event IDs must be a non-empty string or list")
        event_ids = force_list(event_ids)

        # Most id types return one event per id
        size = len(event_ids)

        match id_type:
            case "eventId":
                id_type = "eventIds"
            case "externalId":
                id_type = "eventExternalIds"
            case "episodeId":
                id_type = "episodeIds"
                size *= 2  # Each episode can have a start and end event
            case _:
                raise ValueError(
                    "id_type must be one of: eventId, externalId, episodeId"
                )

        if eventlog == "default":
            eventlog = self.default_eventlog

        relative_url = f"/list/{eventlog}"
        body = {
            "request": {
                id_type: event_ids,
                "start": "1970-01-01T00:00:00.000Z",
                "end": datetime.now().strftime("%Y-%m-%dT%H:%M:%S.%fZ"),
            },
            "size": size,
            "page": 0,
        }

        response = self._doJsonReadRequest(relative_url, body)

        return response

    def deleteEventsById(
        self, event_ids: Union[str, list], eventlog: str = "default"
    ) -> bool:
        """Delete events from the eventlog by event IDs.
        
        Events deleted this way CANNOT be recovered, use with caution.

        Args:
            event_ids (Union[str, list]): Event ID(s) to delete.
            eventlog (str, optional): Eventlog name to query. Defaults to "default".

        Returns:
            dict|bool: Success status and any errors.

        Raises:
            ValueError: If event_ids is not provided.
            URLError: If no Ingenuity instance can be reached or no internet connection is available.
            HTTPError: If the API request fails.
            
        Docs:
            https://docs.eigeningenuity.co/developing-with-eigen/python-library/eventlog/delete-events-by-id
        """

        if not event_ids or not isinstance(event_ids, (str, list)):
            raise ValueError("Event IDs must be a non-empty string or list")
        event_ids = force_list(event_ids)

        if eventlog == "default":
            eventlog = self.default_eventlog

        relative_url = f"/delete/{eventlog}"

        failed_ids = []

        for event_id in event_ids:
            event_url = f"{relative_url}?eventId={event_id}&flush=true"
            response = self._doJsonDeleteRequest(event_url)

            if not response:
                failed_ids.append(event_id)

        if failed_ids:
            return {
                "success": False,
                "errors": {"failed to delete events with ids": failed_ids},
            }
        else:
            return {"success": True, "errors": {}}

    def pushToEventlog(self, events: Union[dict, list]) -> bool:
        """Push events to the eventlog.

        Args:
            events (Union[dict, list]): Single event dict, list of dicts, or filepath to file containing events.

        Returns:
            bool|dict: True if all events succeeded, else dict with errors.

        Raises:
            URLError: If no Ingenuity instance can be reached or no internet connection is available.
            HTTPError: If the API request fails.
            
        Docs:
            https://docs.eigeningenuity.co/developing-with-eigen/python-library/eventlog/push-to-eventlog
        """
        events = parseEvents(events)
        relative_url = "/save"
        label = "events"

        failures = self._doJsonWriteRequest(relative_url, events, label)

        if failures:
            print("Some Events failed to push")
            return failures
        else:
            return True


def get_eventlog(
    eigenserver: EigenServer = None, default_eventlog: Union[str, None] = None
) -> EventLog:
    """Create an EventLog client.

    Args:
        eigenserver (EigenServer, optional): EigenServer instance to query.
        default_eventlog (str, optional): Default eventlog name. Defaults to "eventlog".

    Returns:
        EventLog: An object defining a connection to the EventLog, that exposes methods to query and write to the eventlog.
        
    Docs:
        https://docs.eigeningenuity.co/developing-with-eigen/python-library/eventlog/get-eventlog
    """
    if eigenserver is None:
        eigenserver = get_default_server()
    elif isinstance(eigenserver, str):
        eigenserver = EigenServer(eigenserver)

    if default_eventlog is None:
        default_eventlog = "eventlog"
    else:
        default_eventlog = str(default_eventlog)

    return EventLog(
        eigenserver.getEigenServerUrl() + "events" + "/",
        default_eventlog,
        eigenserver.auth,
    )


# Alias for backward compatibility
get_events = get_eventlog
