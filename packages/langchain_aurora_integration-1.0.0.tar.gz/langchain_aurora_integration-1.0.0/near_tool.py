"""
LangChain tools for NEAR Protocol.
Generated for: LangChain Tool - Aurora Integration
"""
import requests
import json
import base64
from typing import Optional, Type, Any, List, Dict, Union, Tuple, Set, Callable
from pydantic import BaseModel, Field

try:
    from langchain.tools import BaseTool
except ImportError:
    from langchain_core.tools import BaseTool  # langchain v0.2+

NEAR_RPC_MAINNET = "https://rpc.mainnet.near.org"
NEAR_RPC_TESTNET = "https://rpc.testnet.near.org"


def _near_rpc(method: str, params: Any, network: str = "mainnet") -> dict:
    """Execute NEAR JSON-RPC call."""
    url = NEAR_RPC_MAINNET if network == "mainnet" else NEAR_RPC_TESTNET
    resp = requests.post(url, json={"jsonrpc":"2.0","id":"1","method":method,"params":params}, timeout=10)
    resp.raise_for_status()
    data = resp.json()
    if "error" in data:
        raise RuntimeError(f"NEAR RPC error: {data['error']}")
    return data.get("result", {})


class NEARAccountInput(BaseModel):
    account_id: str = Field(description="NEAR account ID (e.g. example.near)")
    network: str = Field(default="mainnet", description="mainnet or testnet")


class NEARAccountTool(BaseTool):
    """Query NEAR account balance and storage info."""
    name: str = "near_account_info"
    description: str = "Get NEAR account balance and info. Input: account_id, network (optional)"
    args_schema: Type[BaseModel] = NEARAccountInput

    def _run(self, account_id: str, network: str = "mainnet") -> str:
        result = _near_rpc("query", {
            "request_type": "view_account", "finality": "final", "account_id": account_id
        }, network)
        near = int(result.get("amount", 0)) / 10**24
        return json.dumps({"account_id": account_id, "balance_near": f"{near:.4f}",
            "storage_bytes": result.get("storage_usage", 0)})

    async def _arun(self, account_id: str, network: str = "mainnet") -> str:
        return self._run(account_id, network)


class NEARViewFunctionInput(BaseModel):
    contract_id: str = Field(description="NEAR contract ID")
    method_name: str = Field(description="View method name")
    args: dict = Field(default={}, description="Method arguments")
    network: str = Field(default="mainnet", description="mainnet or testnet")


class NEARViewFunctionTool(BaseTool):
    """Call a view function on a NEAR smart contract."""
    name: str = "near_view_function"
    description: str = "Call a NEAR contract view function. Input: contract_id, method_name, args"
    args_schema: Type[BaseModel] = NEARViewFunctionInput

    def _run(self, contract_id: str, method_name: str, args: dict = {}, network: str = "mainnet") -> str:
        args_b64 = base64.b64encode(json.dumps(args).encode()).decode()
        result = _near_rpc("query", {
            "request_type": "call_function", "finality": "final",
            "account_id": contract_id, "method_name": method_name, "args_base64": args_b64
        }, network)
        decoded = json.loads(bytes(result["result"]).decode())
        return json.dumps(decoded, indent=2)

    async def _arun(self, contract_id: str, method_name: str, args: dict = {}, network: str = "mainnet") -> str:
        return self._run(contract_id, method_name, args, network)


class AuroraTokenBalanceInput(BaseModel):
    account_id: str = Field(description="NEAR account ID to check Aurora (ETH) balance for")
    token_address: Optional[str] = Field(default=None, description="ERC-20 token contract address on Aurora; omit for native ETH balance")

class AuroraTokenBalanceTool(BaseTool):
    name: str = "aurora_token_balance"
    description: str = (
        "Get native ETH or ERC-20 token balance on Aurora (NEAR's EVM layer). "
        "Provide a NEAR account ID; optionally provide an ERC-20 token_address for token balances."
    )
    args_schema: Type[BaseModel] = AuroraTokenBalanceInput

    def _run(self, account_id: str, token_address: Optional[str] = None) -> str:
        try:
            # Derive Aurora (EVM) address from NEAR account via aurora engine
            hex_args = account_id.encode().hex()
            result = _near_rpc("query", {
                "request_type": "call_function",
                "finality": "final",
                "account_id": "aurora",
                "method_name": "get_evm_address",
                "args_base64": __import__("base64").b64encode(
                    __import__("json").dumps({"account_id": account_id}).encode()
                ).decode(),
            })
            evm_address = result.get("result", "")
            if isinstance(evm_address, list):
                evm_address = bytes(evm_address).decode(errors="replace").strip("\x00")

            if not token_address:
                # Native ETH balance via Aurora RPC
                payload = {"jsonrpc": "2.0", "id": 1, "method": "eth_getBalance",
                           "params": [evm_address if evm_address.startswith("0x") else f"0x{evm_address}", "latest"]}
                resp = __import__("requests").post("https://mainnet.aurora.dev", json=payload, timeout=10).json()
                bal_hex = resp.get("result", "0x0")
                balance_eth = int(bal_hex, 16) / 1e18
                return f"Aurora ETH balance for {account_id} ({evm_address}): {balance_eth:.6f} ETH"
            else:
                # ERC-20 balanceOf(address)
                addr = evm_address if evm_address.startswith("0x") else f"0x{evm_address}"
                data = "0x70a08231" + addr[2:].zfill(64)
                payload = {"jsonrpc": "2.0", "id": 1, "method": "eth_call",
                           "params": [{"to": token_address, "data": data}, "latest"]}
                resp = __import__("requests").post("https://mainnet.aurora.dev", json=payload, timeout=10).json()
                raw = resp.get("result", "0x0")
                balance = int(raw, 16) / 1e18
                return f"Aurora ERC-20 ({token_address}) balance for {account_id}: {balance:.6f}"
        except Exception as e:
            return f"Error fetching Aurora balance: {e}"

    async def _arun(self, account_id: str, token_address: Optional[str] = None) -> str:
        return self._run(account_id, token_address)


class AuroraBridgeStatusInput(BaseModel):
    tx_hash: str = Field(description="Aurora or NEAR transaction hash to check bridge/transfer status")

class AuroraBridgeStatusTool(BaseTool):
    name: str = "aurora_bridge_status"
    description: str = (
        "Check the status of an Aurora <-> NEAR bridge transfer or any Aurora transaction. "
        "Returns transaction receipt, status, gas used, and block info."
    )
    args_schema: Type[BaseModel] = AuroraBridgeStatusInput

    def _run(self, tx_hash: str) -> str:
        try:
            requests = __import__("requests")
            h = tx_hash if tx_hash.startswith("0x") else f"0x{tx_hash}"
            payload = {"jsonrpc": "2.0", "id": 1, "method": "eth_getTransactionReceipt", "params": [h]}
            resp = requests.post("https://mainnet.aurora.dev", json=payload, timeout=10).json()
            receipt = resp.get("result")
            if not receipt:
                # Try as NEAR tx hash via Aurora explorer API
                exp = requests.get(
                    f"https://explorer.mainnet.aurora.dev/api?module=transaction&action=gettxreceiptbyhash&txhash={h}",
                    timeout=10
                ).json()
                receipt = exp.get("result")
            if not receipt:
                return f"No Aurora receipt found for {tx_hash}. May still be pending or is a NEAR-side tx."
            status = "✅ Success" if receipt.get("status") == "0x1" else "❌ Failed"
            gas_used = int(receipt.get("gasUsed", "0x0"), 16)
            block = int(receipt.get("blockNumber", "0x0"), 16)
            logs = len(receipt.get("logs", []))
            return (f"Aurora TX {tx_hash}\nStatus: {status}\nBlock: {block}\n"
                    f"Gas used: {gas_used:,}\nLog events: {logs}\nFrom: {receipt.get('from')}\nTo: {receipt.get('to')}")
        except Exception as e:
            return f"Error fetching Aurora bridge status: {e}"

    async def _arun(self, tx_hash: str) -> str:
        return self._run(tx_hash)