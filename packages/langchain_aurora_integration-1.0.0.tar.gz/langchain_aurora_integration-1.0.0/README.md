# LangChain Tool - Aurora Integration

Build LangChain tools for interacting with Aurora.

**THE VIRAL LOOP:**
Agent needs Aurora functionality → Uses LangChain tool → Agent uses NEAR DeFi

**Deliverables:**
1. LangChain tools for Aurora's

## Install

```bash
pip install -r requirements.txt
```

## Tools

- `NEARAccountTool` — see near_tool.py
- `NEARViewFunctionTool` — see near_tool.py
- `AuroraTokenBalanceTool` — see near_tool.py
- `AuroraBridgeStatusTool` — see near_tool.py

## Usage

```python
from near_tool import NEARAccountTool, NEARViewFunctionTool, AuroraTokenBalanceTool, AuroraBridgeStatusTool

tool = NEARAccountTool()
result = tool._run(account_id='example.near')
print(result)
```
