import warnings
warnings.warn(
    "vscode-ark has been renamed to code-data-ark. "
    "Please update your dependency: pip install code-data-ark",
    DeprecationWarning,
    stacklevel=2,
)
