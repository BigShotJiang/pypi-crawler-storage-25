# vscode-ark (deprecated)

This package has been renamed to **code-data-ark**.

Please update your dependency:

```
pip install code-data-ark
```

https://pypi.org/project/code-data-ark
