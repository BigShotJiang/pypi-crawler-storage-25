# fasr-vad-marblenet

基于 NVIDIA MarbleNet ONNX 推理脚本封装的 VAD 插件，为 `fasr` 提供离线语音活动检测能力。插件已内置 `model.onnx`，默认可直接加载。

## 安装

```bash
pip install fasr-vad-marblenet
```

## 注册模型

| 注册名 | 类 | 说明 |
|---|---|---|
| `marblenet` | `MarbleNetForVAD` | NVIDIA MarbleNet 非流式 VAD，ONNX Runtime 推理 |

## 使用方式

### 在流水线中使用

```python
from fasr import AudioPipeline

pipeline = (
    AudioPipeline()
    .add_pipe("detector", model="marblenet", checkpoint_dir="/path/to/onnx_dir")
    .add_pipe("recognizer", model="paraformer")
)
```

### 单独使用模型

```python
from fasr.config import registry
from fasr.data import Waveform

model = registry.vad_models.get("marblenet")()
model.from_checkpoint()  # 默认加载插件内置 ONNX

waveform = Waveform.from_file("example.wav")
segments = model.detect(waveform)
for seg in segments:
    print(f"{seg.start_ms}ms - {seg.end_ms}ms")
```

## `from_checkpoint` 参数

| 参数 | 类型 | 默认值 | 说明 |
|---|---|---|---|
| `checkpoint_dir` | `str \| Path \| None` | 内置模型目录 | 模型目录或 `.onnx` 文件路径；目录下会自动选择首个 `.onnx` |
| `model_path` | `str \| Path \| None` | `None` | 直接指定 `.onnx` 文件路径，优先级高于 `checkpoint_dir` |
| `providers` | `list[str] \| None` | `["CPUExecutionProvider"]` | ONNX Runtime provider 列表 |
| `num_threads` | `int` | `2` | ONNX Runtime `intra_op_num_threads` |

## VAD 参数

| 参数 | 默认值 | 说明 |
|---|---|---|
| `speaking_score` | `0.5` | 语音激活阈值 |
| `silence_score` | `0.5` | 语音结束阈值 |
| `fusion_threshold` | `0.1` | 邻近片段合并阈值（秒） |
| `min_speech_duration` | `0.05` | 最小语音段时长（秒） |
| `output_frame_length` | `320` | 每帧采样点数，默认对应 20ms@16k |

## 依赖

- `fasr`
- `numpy >= 1.24`
- `onnxruntime >= 1.16.0`
- Python 3.10–3.12
