from __future__ import annotations

from pathlib import Path
from typing import Any, List

import numpy as np
import onnxruntime as ort
from pydantic import ConfigDict, Field
from typing_extensions import Self

from fasr.config import registry
from fasr.data import AudioSpan, AudioSpanList, Waveform
from fasr.model import VADModel

DEFAULT_CHECKPOINT_DIR = Path(__file__).parent.parent / "asset" / "marblenet"


@registry.vad_models.register("marblenet")
class MarbleNetForVAD(VADModel):
    """NVIDIA MarbleNet 非流式 VAD（ONNX Runtime）。"""

    checkpoint: str | None = None
    endpoint: str = "modelscope"

    sample_rate: int = 16000
    output_frame_length: int = 320
    speaking_score: float = 0.5
    silence_score: float = 0.5
    fusion_threshold: float = 0.1
    min_speech_duration: float = 0.05
    max_input_seconds: int = 3600

    session: Any | None = Field(default=None, exclude=True)
    input_name: str | None = Field(default=None, exclude=True)
    output_names: List[str] = Field(default_factory=list, exclude=True)

    model_config = ConfigDict(arbitrary_types_allowed=True, validate_assignment=True)

    def detect(self, waveform: Waveform) -> AudioSpanList:
        if (
            self.session is None
            or self.input_name is None
            or len(self.output_names) < 3
        ):
            raise RuntimeError(
                "Model is not initialized, call from_checkpoint() first."
            )
        wav = (
            waveform.resample(self.sample_rate)
            if waveform.sample_rate != self.sample_rate
            else waveform
        )
        audio = self._normalize_to_int16(wav.data)
        audio_len = int(audio.shape[0])
        if audio_len == 0:
            return AudioSpanList()
        audio_3d = audio.reshape(1, 1, -1)
        input_audio_length = self._resolve_input_audio_length(audio_len)
        aligned_audio = self._align_audio_length(audio_3d, input_audio_length)
        saved = self._infer_silence_states(aligned_audio, input_audio_length)
        timestamps = self._vad_to_timestamps(saved)
        timestamps = self._process_timestamps(timestamps)
        segments = AudioSpanList()
        for start_s, end_s in timestamps:
            start_ms = int(round(start_s * 1000))
            end_ms = int(round(end_s * 1000))
            if end_ms <= start_ms:
                continue
            segment = AudioSpan(start_ms=start_ms, end_ms=end_ms)
            segment.waveform = waveform.select_by_ms(start=start_ms, end=end_ms)
            segments.append(segment)
        return segments

    def from_checkpoint(
        self,
        checkpoint_dir: str | Path | None = None,
        model_path: str | Path | None = None,
        providers: list[str] | None = None,
        num_threads: int = 2,
        **kwargs,
    ) -> Self:
        _ = kwargs
        if model_path is not None:
            onnx_path = Path(model_path)
        else:
            if checkpoint_dir is None:
                if self.checkpoint:
                    checkpoint_dir = self.download_checkpoint()
                else:
                    checkpoint_dir = DEFAULT_CHECKPOINT_DIR
            checkpoint_dir = Path(checkpoint_dir)
            if checkpoint_dir.is_file():
                onnx_path = checkpoint_dir
            else:
                candidates = sorted(checkpoint_dir.glob("*.onnx"))
                if not candidates:
                    raise FileNotFoundError(
                        f"No .onnx model found in: {checkpoint_dir}"
                    )
                onnx_path = candidates[0]
        if not onnx_path.exists():
            raise FileNotFoundError(f"ONNX model not found: {onnx_path}")

        sess_opts = ort.SessionOptions()
        sess_opts.inter_op_num_threads = 0
        sess_opts.intra_op_num_threads = max(0, int(num_threads))
        sess_opts.enable_cpu_mem_arena = True
        sess_opts.execution_mode = ort.ExecutionMode.ORT_SEQUENTIAL
        sess_opts.graph_optimization_level = ort.GraphOptimizationLevel.ORT_ENABLE_ALL
        if providers is None:
            providers = ["CPUExecutionProvider"]

        session = ort.InferenceSession(
            str(onnx_path),
            sess_options=sess_opts,
            providers=providers,
        )
        self.session = session
        self.input_name = session.get_inputs()[0].name
        self.output_names = [output.name for output in session.get_outputs()]
        if len(self.output_names) < 3:
            raise RuntimeError(
                "MarbleNet ONNX outputs are invalid, expected >=3 outputs "
                "(score_silence, score_active, signal_len)."
            )
        return self

    def _normalize_to_int16(self, audio: np.ndarray) -> np.ndarray:
        arr = np.asarray(audio, dtype=np.float32).reshape(-1)
        max_val = float(np.max(np.abs(arr))) if arr.size > 0 else 0.0
        scale = 32767.0 / max_val if max_val > 0 else 1.0
        return (arr * scale).astype(np.int16)

    def _resolve_input_audio_length(self, raw_audio_len: int) -> int:
        shape_value = self.session.get_inputs()[0].shape[-1]
        if isinstance(shape_value, str) or shape_value is None:
            return min(self.sample_rate * self.max_input_seconds, raw_audio_len)
        return int(shape_value)

    def _align_audio_length(
        self,
        audio_3d: np.ndarray,
        input_audio_length: int,
    ) -> np.ndarray:
        audio_len = audio_3d.shape[-1]
        if audio_len == input_audio_length:
            return audio_3d
        if audio_len > input_audio_length:
            num_windows = (
                int(np.ceil((audio_len - input_audio_length) / input_audio_length)) + 1
            )
            total_length = (num_windows - 1) * input_audio_length + input_audio_length
            pad_amount = total_length - audio_len
            tail = audio_3d[:, :, -pad_amount:].astype(np.float32)
            rms = float(np.sqrt(np.mean(tail * tail)))
            noise = (rms * np.random.normal(0.0, 1.0, size=(1, 1, pad_amount))).astype(
                audio_3d.dtype
            )
            return np.concatenate((audio_3d, noise), axis=-1)

        arr = audio_3d.astype(np.float32)
        rms = float(np.sqrt(np.mean(arr * arr)))
        pad_amount = input_audio_length - audio_len
        noise = (rms * np.random.normal(0.0, 1.0, size=(1, 1, pad_amount))).astype(
            audio_3d.dtype
        )
        return np.concatenate((audio_3d, noise), axis=-1)

    def _infer_silence_states(
        self,
        aligned_audio: np.ndarray,
        input_audio_length: int,
    ) -> list[bool]:
        silence = True
        saved: list[bool] = []
        stride_step = input_audio_length
        slice_start = 0
        slice_end = input_audio_length
        while slice_end <= aligned_audio.shape[-1]:
            outputs = self.session.run(
                self.output_names[:3],
                {self.input_name: aligned_audio[:, :, slice_start:slice_end]},
            )
            score_silence, score_active, signal_len = outputs
            frame_count = int(np.asarray(signal_len).reshape(-1)[0])
            for i in range(frame_count):
                if silence:
                    if float(score_active[:, i]) >= self.speaking_score:
                        silence = False
                else:
                    if float(score_silence[:, i]) >= self.silence_score:
                        silence = True
                saved.append(silence)
            slice_start += stride_step
            slice_end = slice_start + input_audio_length
        return saved

    def _vad_to_timestamps(self, vad_output: list[bool]) -> list[tuple[float, float]]:
        frame_duration = self.output_frame_length / self.sample_rate
        timestamps: list[tuple[float, float]] = []
        start: float | None = None
        for i, is_silence in enumerate(vad_output):
            if is_silence:
                if start is not None:
                    end = i * frame_duration + frame_duration
                    timestamps.append((start, end))
                    start = None
            elif start is None:
                start = i * frame_duration
        if start is not None:
            timestamps.append((start, len(vad_output) * frame_duration))
        return timestamps

    def _process_timestamps(
        self,
        timestamps: list[tuple[float, float]],
    ) -> list[tuple[float, float]]:
        filtered = [
            (start, end)
            for start, end in timestamps
            if (end - start) >= self.min_speech_duration
        ]
        fused: list[tuple[float, float]] = []
        for start, end in filtered:
            if fused and (start - fused[-1][1] <= self.fusion_threshold):
                fused[-1] = (fused[-1][0], end)
            else:
                fused.append((start, end))
        fused_second_pass: list[tuple[float, float]] = []
        for start, end in fused:
            if fused_second_pass and (
                start - fused_second_pass[-1][1] <= self.fusion_threshold
            ):
                fused_second_pass[-1] = (fused_second_pass[-1][0], end)
            else:
                fused_second_pass.append((start, end))
        return fused_second_pass

    def get_config(self):
        raise NotImplementedError

    def load(self, save_dir, **kwargs):
        raise NotImplementedError

    def save(self, save_dir, **kwargs):
        raise NotImplementedError
