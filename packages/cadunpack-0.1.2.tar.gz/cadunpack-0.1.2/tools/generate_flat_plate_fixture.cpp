#include <Interface_Static.hxx>
#include <IFSelect_ReturnStatus.hxx>
#include <STEPControl_StepModelType.hxx>
#include <STEPControl_Writer.hxx>
#include <TopoDS_Shape.hxx>
#include <BRepPrimAPI_MakeBox.hxx>

#include <cstdlib>
#include <filesystem>
#include <iostream>
#include <string>

int main(int argc, char** argv) {
  if (argc != 2) {
    std::cerr << "usage: generate_flat_plate_fixture <output.step>\n";
    return 2;
  }

  const std::filesystem::path output_path = argv[1];
  std::filesystem::create_directories(output_path.parent_path());

  const TopoDS_Shape plate = BRepPrimAPI_MakeBox(100.0, 50.0, 2.0).Shape();

  Interface_Static::SetCVal("write.step.schema", "AP214IS");
  STEPControl_Writer writer;
  writer.Transfer(plate, STEPControl_AsIs);

  const IFSelect_ReturnStatus status = writer.Write(output_path.string().c_str());
  if (status != IFSelect_RetDone) {
    std::cerr << "failed to write STEP fixture\n";
    return 1;
  }

  std::cout << output_path << '\n';
  return 0;
}
