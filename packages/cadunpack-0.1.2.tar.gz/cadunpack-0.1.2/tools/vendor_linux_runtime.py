#!/usr/bin/env python3
from __future__ import annotations

import argparse
import importlib.util
import os
import shutil
import subprocess
import sys
from pathlib import Path


NON_VENDORED_LIBRARY_NAMES = {
    "linux-vdso.so.1",
    "libc.so.6",
    "libdl.so.2",
    "libm.so.6",
    "libpthread.so.0",
    "librt.so.1",
    "libutil.so.1",
    "libresolv.so.2",
    "libnsl.so.1",
    "libnsl.so.2",
    "ld-linux-x86-64.so.2",
    "ld-linux-aarch64.so.1",
}


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="Vendor native runtime shared libraries into an installed cadunpack package."
    )
    parser.add_argument(
        "--package-dir",
        type=Path,
        help="Installed cadunpack package directory. Defaults to the active interpreter's cadunpack package.",
    )
    return parser.parse_args()


def locate_package_dir(explicit: Path | None) -> Path:
    if explicit is not None:
        return explicit.resolve()

    spec = importlib.util.find_spec("cadunpack")
    if spec is None or spec.origin is None:
        raise RuntimeError("Could not locate an installed cadunpack package in the active interpreter.")
    return Path(spec.origin).resolve().parent


def find_extension(package_dir: Path) -> Path:
    matches = sorted(package_dir.glob("_cadunpack*.so"))
    if not matches:
        raise RuntimeError(f"Could not find a cadunpack extension in {package_dir}.")
    return matches[0]


def _parse_ldd_line(line: str) -> tuple[str | None, Path | None]:
    stripped = line.strip()
    if not stripped:
        return None, None
    if "=>" in stripped:
        name, target = [part.strip() for part in stripped.split("=>", 1)]
        resolved = target.split(" (", 1)[0].strip()
        if resolved == "not found":
            raise RuntimeError(f"Unresolved native dependency reported by ldd: {line.strip()}")
        if resolved.startswith("/"):
            return name, Path(resolved)
        return name, None

    token = stripped.split(" (", 1)[0].strip()
    if token.startswith("/"):
        return Path(token).name, Path(token)
    return token, None


def ldd_dependencies(binary_path: Path) -> list[tuple[str, Path]]:
    output = subprocess.check_output(["ldd", str(binary_path)], text=True)
    dependencies: list[tuple[str, Path]] = []
    for line in output.splitlines():
        name, resolved = _parse_ldd_line(line)
        if name is None or resolved is None:
            continue
        dependencies.append((name, resolved))
    return dependencies


def should_vendor(name: str, resolved: Path) -> bool:
    return name not in NON_VENDORED_LIBRARY_NAMES and resolved.name not in NON_VENDORED_LIBRARY_NAMES


def discover_runtime_dependencies(extension_path: Path) -> list[Path]:
    queue = [extension_path]
    discovered: dict[str, Path] = {}

    while queue:
        current_binary = queue.pop(0)
        for name, resolved in ldd_dependencies(current_binary):
            if not should_vendor(name, resolved):
                continue
            key = str(resolved)
            if key in discovered:
                continue
            discovered[key] = resolved
            queue.append(resolved)

    return sorted(discovered.values())


def copy_runtime_dependencies(runtime_dependencies: list[Path], copied_dir: Path) -> None:
    if copied_dir.exists():
        shutil.rmtree(copied_dir)
    copied_dir.mkdir(parents=True)

    for source in runtime_dependencies:
        shutil.copy2(source, copied_dir / source.name)


def patchelf_binary(binary_path: Path, rpath: str) -> None:
    patchelf = os.environ.get("CADUNPACK_PATCHELF", "patchelf")
    subprocess.check_call(
        [patchelf, "--set-rpath", rpath, str(binary_path)],
        stdout=subprocess.DEVNULL,
        stderr=subprocess.DEVNULL,
    )


def validate_rewritten_binaries(extension_path: Path, copied_dir: Path) -> None:
    binaries = [extension_path, *sorted(copied_dir.iterdir())]
    for binary_path in binaries:
        for name, resolved in ldd_dependencies(binary_path):
            if not should_vendor(name, resolved):
                continue
            if copied_dir not in resolved.parents:
                raise RuntimeError(
                    f"Vendored runtime still resolves outside the package for {binary_path.name}: {resolved}"
                )


def main() -> int:
    if sys.platform != "linux":
        raise RuntimeError("vendor_linux_runtime.py is only supported on Linux.")

    args = parse_args()
    package_dir = locate_package_dir(args.package_dir)
    extension_path = find_extension(package_dir)

    runtime_dependencies = discover_runtime_dependencies(extension_path)
    if not runtime_dependencies:
        print("No external native runtime dependencies were discovered.")
        return 0

    copied_dir = package_dir / ".libs"
    copy_runtime_dependencies(runtime_dependencies, copied_dir)

    for binary_path in sorted(copied_dir.iterdir()):
        patchelf_binary(binary_path, "$ORIGIN")
    patchelf_binary(extension_path, "$ORIGIN/.libs")
    validate_rewritten_binaries(extension_path, copied_dir)

    print(f"Vendored {len(runtime_dependencies)} native libraries into {copied_dir}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
