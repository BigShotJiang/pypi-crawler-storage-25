#!/usr/bin/env python3
from __future__ import annotations

import argparse
import importlib.util
import os
import shutil
import subprocess
import sys
from pathlib import Path


SYSTEM_LIBRARY_PREFIXES = ("/usr/lib/", "/System/Library/")


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="Vendor native runtime dylibs into an installed cadunpack package."
    )
    parser.add_argument(
        "--package-dir",
        type=Path,
        help="Installed cadunpack package directory. Defaults to the active interpreter's cadunpack package.",
    )
    parser.add_argument(
        "--search-dir",
        dest="search_dirs",
        type=Path,
        action="append",
        default=[],
        help="Additional dylib search directories. Can be passed multiple times.",
    )
    return parser.parse_args()


def locate_package_dir(explicit: Path | None) -> Path:
    if explicit is not None:
        return explicit.resolve()

    spec = importlib.util.find_spec("cadunpack")
    if spec is None or spec.origin is None:
        raise RuntimeError("Could not locate an installed cadunpack package in the active interpreter.")
    return Path(spec.origin).resolve().parent


def default_search_dirs() -> list[Path]:
    candidates = [
        os.environ.get("CADUNPACK_OCCT_LIB_DIR"),
        "/opt/homebrew/opt/opencascade/lib",
        "/opt/homebrew/Cellar/opencascade/7.9.3/lib",
        os.environ.get("CADUNPACK_TBB_LIB_DIR"),
        "/opt/homebrew/opt/tbb/lib",
        "/opt/homebrew/Cellar/tbb/2022.3.0/lib",
    ]
    result: list[Path] = []
    for candidate in candidates:
        if not candidate:
            continue
        path = Path(candidate)
        if path.exists():
            result.append(path.resolve())
    return result


def find_extension(package_dir: Path) -> Path:
    matches = sorted(package_dir.glob("_cadunpack*.so"))
    if not matches:
        raise RuntimeError(f"Could not find a cadunpack extension in {package_dir}.")
    return matches[0]


def otool_dependencies(binary_path: Path) -> list[str]:
    output = subprocess.check_output(["otool", "-L", str(binary_path)], text=True)
    dependencies: list[str] = []
    for line in output.splitlines()[1:]:
        line = line.strip()
        if not line:
            continue
        dependencies.append(line.split(" (compatibility version", 1)[0])
    return dependencies


def resolve_dependency(current_binary: Path, dependency: str, search_dirs: list[Path]) -> Path | None:
    if dependency.startswith("/"):
        candidate = Path(dependency)
        return candidate.resolve() if candidate.exists() else None

    if dependency.startswith("@rpath/") or dependency.startswith("@loader_path/"):
        name = dependency.rsplit("/", 1)[-1]
        candidates = [current_binary.parent / name, *[search_dir / name for search_dir in search_dirs]]
        for candidate in candidates:
            if candidate.exists():
                return candidate.resolve()

    return None


def discover_runtime_dependencies(extension_path: Path, search_dirs: list[Path]) -> list[Path]:
    queue = [extension_path]
    discovered: dict[str, Path] = {}

    while queue:
        current_binary = queue.pop(0)
        for dependency in otool_dependencies(current_binary):
            resolved = resolve_dependency(current_binary, dependency, search_dirs)
            if resolved is None:
                continue
            key = str(resolved)
            if key in discovered:
                continue
            discovered[key] = resolved
            queue.append(resolved)

    return sorted(discovered.values())


def copy_runtime_dependencies(runtime_dependencies: list[Path], copied_dir: Path) -> None:
    if copied_dir.exists():
        shutil.rmtree(copied_dir)
    copied_dir.mkdir(parents=True)

    for source in runtime_dependencies:
        destination = copied_dir / source.name
        shutil.copy2(source, destination)
        subprocess.run(
            ["xattr", "-d", "com.apple.provenance", str(destination)],
            check=False,
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
        )


def rewrite_binary(binary_path: Path, search_dirs: list[Path], extension_path: Path) -> None:
    loader_prefix = "@loader_path/.dylibs" if binary_path == extension_path else "@loader_path"

    for dependency in otool_dependencies(binary_path):
        resolved = resolve_dependency(binary_path, dependency, search_dirs)
        if resolved is None:
            continue

        target = f"{loader_prefix}/{resolved.name}"
        subprocess.run(
            ["install_name_tool", "-change", dependency, target, str(binary_path)],
            check=False,
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
        )
        subprocess.run(
            ["install_name_tool", "-change", str(resolved), target, str(binary_path)],
            check=False,
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
        )

    if binary_path != extension_path:
        subprocess.check_call(
            ["install_name_tool", "-id", f"@loader_path/{binary_path.name}", str(binary_path)],
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
        )

    subprocess.check_call(
        ["codesign", "--force", "--sign", "-", str(binary_path)],
        stdout=subprocess.DEVNULL,
        stderr=subprocess.DEVNULL,
    )


def validate_rewritten_binaries(extension_path: Path, copied_dir: Path) -> None:
    leftovers: list[tuple[str, str]] = []
    for binary_path in [extension_path, *sorted(copied_dir.iterdir())]:
        for dependency in otool_dependencies(binary_path):
            if dependency.startswith("@rpath/"):
                leftovers.append((binary_path.name, dependency))
                continue
            if dependency.startswith("/") and not dependency.startswith(SYSTEM_LIBRARY_PREFIXES):
                leftovers.append((binary_path.name, dependency))

    if leftovers:
        summary = "\n".join(f"{binary}: {dependency}" for binary, dependency in leftovers)
        raise RuntimeError(f"Vendored runtime still references external dylibs:\n{summary}")


def main() -> int:
    if sys.platform != "darwin":
        raise RuntimeError("vendor_macos_runtime.py is only supported on macOS.")

    args = parse_args()
    package_dir = locate_package_dir(args.package_dir)
    extension_path = find_extension(package_dir)

    search_dirs = [*args.search_dirs, *default_search_dirs()]
    deduped_search_dirs: list[Path] = []
    seen_search_dirs: set[str] = set()
    for search_dir in search_dirs:
        resolved_dir = search_dir.resolve()
        key = str(resolved_dir)
        if key in seen_search_dirs:
            continue
        seen_search_dirs.add(key)
        deduped_search_dirs.append(resolved_dir)

    if not deduped_search_dirs:
        raise RuntimeError("No runtime search directories were found.")

    copied_dir = package_dir / ".dylibs"
    runtime_dependencies = discover_runtime_dependencies(extension_path, deduped_search_dirs)
    if not runtime_dependencies:
        print("No external native runtime dependencies were discovered.")
        return 0

    copy_runtime_dependencies(runtime_dependencies, copied_dir)

    rewrite_search_dirs = [copied_dir, *deduped_search_dirs]
    for binary_path in sorted(copied_dir.iterdir()):
        rewrite_binary(binary_path, rewrite_search_dirs, extension_path)
    rewrite_binary(extension_path, rewrite_search_dirs, extension_path)
    validate_rewritten_binaries(extension_path, copied_dir)

    print(f"Vendored {len(runtime_dependencies)} native libraries into {copied_dir}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
