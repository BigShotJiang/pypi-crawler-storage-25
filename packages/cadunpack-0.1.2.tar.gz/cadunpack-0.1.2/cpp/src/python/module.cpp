#include <pybind11/pybind11.h>
#include <pybind11/stl.h>

#include <filesystem>
#include <string>

#include "cadunpack/core/error.hpp"
#include "cadunpack/step/step_unpacker.hpp"
#include "cadunpack/step/step_reader.hpp"
#include "cadunpack/step/types.hpp"

namespace py = pybind11;

namespace {

void BindStepTypes(py::module_& module) {
  py::enum_<cadunpack::step::ShapeKind>(module, "ShapeKind")
      .value("SOLID", cadunpack::step::ShapeKind::kSolid)
      .value("SHELL", cadunpack::step::ShapeKind::kShell)
      .value("SHAPE", cadunpack::step::ShapeKind::kShape);

  py::class_<cadunpack::step::StepComponent>(module, "NativeStepComponent")
      .def_readonly("component_id", &cadunpack::step::StepComponent::component_id)
      .def_readonly("source_name", &cadunpack::step::StepComponent::source_name)
      .def_readonly("component_name", &cadunpack::step::StepComponent::component_name)
      .def_readonly("assembly_path", &cadunpack::step::StepComponent::assembly_path)
      .def_readonly("owning_node_id", &cadunpack::step::StepComponent::owning_node_id)
      .def_readonly("shape_kind", &cadunpack::step::StepComponent::shape_kind);

  py::class_<cadunpack::step::AssemblyNode>(module, "NativeAssemblyNode")
      .def_readonly("node_id", &cadunpack::step::AssemblyNode::node_id)
      .def_readonly("label_entry", &cadunpack::step::AssemblyNode::label_entry)
      .def_readonly("name", &cadunpack::step::AssemblyNode::name)
      .def_readonly("is_reference", &cadunpack::step::AssemblyNode::is_reference)
      .def_readonly("is_assembly", &cadunpack::step::AssemblyNode::is_assembly)
      .def_readonly("has_shape", &cadunpack::step::AssemblyNode::has_shape)
      .def_readonly("component_ids", &cadunpack::step::AssemblyNode::component_ids)
      .def_readonly("children", &cadunpack::step::AssemblyNode::children);

  py::class_<cadunpack::step::StepModel>(module, "NativeStepModel")
      .def_readonly("file_name", &cadunpack::step::StepModel::file_name)
      .def_readonly("roots", &cadunpack::step::StepModel::roots)
      .def_readonly("components", &cadunpack::step::StepModel::components);

  py::class_<cadunpack::step::UnpackWarning>(module, "NativeUnpackWarning")
      .def_readonly("code", &cadunpack::step::UnpackWarning::code)
      .def_readonly("message", &cadunpack::step::UnpackWarning::message);

  py::class_<cadunpack::step::UnpackedComponent>(module, "NativeUnpackedComponent")
      .def_readonly("summary", &cadunpack::step::UnpackedComponent::summary)
      .def_readonly("generated_dxf_file_name", &cadunpack::step::UnpackedComponent::generated_dxf_file_name)
      .def_readonly("generated_dxf", &cadunpack::step::UnpackedComponent::generated_dxf)
      .def_readonly("has_bends", &cadunpack::step::UnpackedComponent::has_bends)
      .def_readonly("warnings", &cadunpack::step::UnpackedComponent::warnings);

  py::class_<cadunpack::step::UnpackResult>(module, "NativeUnpackResult")
      .def_readonly("model", &cadunpack::step::UnpackResult::model)
      .def_readonly("components", &cadunpack::step::UnpackResult::components);
}

}  // namespace

PYBIND11_MODULE(_cadunpack, module) {
  module.doc() = "cadunpack native STEP parsing bindings";

  py::register_exception<cadunpack::core::CadunpackError>(module, "CadunpackError");
  py::enum_<cadunpack::core::ErrorCode>(module, "ErrorCode")
      .value("INVALID_ARGUMENT", cadunpack::core::ErrorCode::kInvalidArgument)
      .value("IO_ERROR", cadunpack::core::ErrorCode::kIoError)
      .value("STEP_READ_FAILED", cadunpack::core::ErrorCode::kStepReadFailed)
      .value("UNSUPPORTED_TOPOLOGY", cadunpack::core::ErrorCode::kUnsupportedTopology)
      .value("UNFOLD_FAILED", cadunpack::core::ErrorCode::kUnfoldFailed);

  BindStepTypes(module);

  py::class_<cadunpack::step::StepReader>(module, "StepReader")
      .def(py::init<>())
      .def("read_file",
           [](const cadunpack::step::StepReader& reader, const std::string& path) {
             return reader.read_file(std::filesystem::path(path));
           },
           py::arg("path"))
      .def("read_bytes", &cadunpack::step::StepReader::read_bytes, py::arg("file_name"), py::arg("step_payload"));

  py::class_<cadunpack::step::StepUnpacker>(module, "StepUnpacker")
      .def(py::init<>())
      .def("unpack_file",
           [](const cadunpack::step::StepUnpacker& unpacker, const std::string& path) {
             return unpacker.unpack_file(std::filesystem::path(path));
           },
           py::arg("path"))
      .def("unpack_bytes", &cadunpack::step::StepUnpacker::unpack_bytes, py::arg("file_name"), py::arg("step_payload"));

  module.def("parse_step", [](const std::string& path) {
    cadunpack::step::StepReader reader;
    return reader.read_file(std::filesystem::path(path));
  });

  module.def("parse_step_bytes", [](const std::string& file_name, py::bytes payload) {
    cadunpack::step::StepReader reader;
    return reader.read_bytes(file_name, static_cast<std::string>(payload));
  });

  module.def("unpack_step", [](const std::string& path) {
    cadunpack::step::StepUnpacker unpacker;
    return unpacker.unpack_file(std::filesystem::path(path));
  });

  module.def("unpack_step_bytes", [](const std::string& file_name, py::bytes payload) {
    cadunpack::step::StepUnpacker unpacker;
    return unpacker.unpack_bytes(file_name, static_cast<std::string>(payload));
  });
}
