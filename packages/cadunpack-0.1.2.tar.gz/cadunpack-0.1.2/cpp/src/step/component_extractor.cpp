#include "cadunpack/step/component_extractor.hpp"

#include <IFSelect_ReturnStatus.hxx>
#include <STEPCAFControl_Reader.hxx>
#include <STEPControl_Reader.hxx>
#include <TCollection_AsciiString.hxx>
#include <TDF_Label.hxx>
#include <TDF_LabelSequence.hxx>
#include <TDF_Tool.hxx>
#include <TDataStd_Name.hxx>
#include <TDocStd_Document.hxx>
#include <TopAbs_ShapeEnum.hxx>
#include <TopExp_Explorer.hxx>
#include <TopoDS.hxx>
#include <TopoDS_Shape.hxx>
#include <XCAFApp_Application.hxx>
#include <XCAFDoc_DocumentTool.hxx>
#include <XCAFDoc_ShapeTool.hxx>

#include <algorithm>
#include <cctype>
#include <chrono>
#include <filesystem>
#include <fstream>
#include <map>
#include <random>
#include <set>
#include <string>
#include <system_error>
#include <utility>
#include <vector>

#include "cadunpack/core/error.hpp"

namespace cadunpack::step {

namespace {

struct ScopedTempFile {
  std::filesystem::path path;

  ScopedTempFile(const ScopedTempFile&) = delete;
  ScopedTempFile& operator=(const ScopedTempFile&) = delete;

  ScopedTempFile() = default;
  explicit ScopedTempFile(std::filesystem::path value) : path(std::move(value)) {}
  ScopedTempFile(ScopedTempFile&& other) noexcept : path(std::move(other.path)) { other.path.clear(); }
  ScopedTempFile& operator=(ScopedTempFile&& other) noexcept {
    if (this == &other) {
      return *this;
    }
    Cleanup();
    path = std::move(other.path);
    other.path.clear();
    return *this;
  }

  ~ScopedTempFile() { Cleanup(); }

  void Cleanup() noexcept {
    if (path.empty()) {
      return;
    }
    std::error_code error;
    std::filesystem::remove(path, error);
    path.clear();
  }
};

struct ExtractionContext {
  std::size_t next_node_index = 1;
  std::size_t next_component_index = 1;
  std::vector<SourceComponent> components;
};

constexpr std::size_t kMaxAssemblyTraversalDepth = 128;
constexpr std::size_t kMaxAssemblyNodes = 20000;

[[noreturn]] void ThrowUnsupportedTopology(const std::string& detail) {
  throw core::CadunpackError(
      core::ErrorCode::kUnsupportedTopology,
      "STEP parse failed: " + detail);
}

std::string SanitizeName(std::string value) {
  std::replace_if(value.begin(), value.end(), [](unsigned char ch) {
    return !(std::isalnum(ch) || ch == '.' || ch == '_' || ch == '-');
  }, '_');
  while (!value.empty() && value.back() == '_') {
    value.pop_back();
  }
  return value.empty() ? "component" : value;
}

std::string BaseNameWithoutExtension(const std::string& file_name) {
  std::string name = file_name;
  const std::size_t slash = name.find_last_of("/\\");
  if (slash != std::string::npos) {
    name = name.substr(slash + 1);
  }
  const std::size_t dot = name.find_last_of('.');
  if (dot != std::string::npos) {
    name = name.substr(0, dot);
  }
  return SanitizeName(name);
}

std::string Trim(std::string value) {
  const std::size_t first = value.find_first_not_of(" \t\r\n");
  if (first == std::string::npos) {
    return "";
  }
  const std::size_t last = value.find_last_not_of(" \t\r\n");
  return value.substr(first, last - first + 1);
}

std::string LabelName(const TDF_Label& label) {
  Handle(TDataStd_Name) name_attribute;
  if (!label.FindAttribute(TDataStd_Name::GetID(), name_attribute) || name_attribute.IsNull()) {
    return "";
  }

  const auto& extended = name_attribute->Get();
  std::string value;
  value.reserve(static_cast<std::size_t>(extended.Length()));
  for (Standard_Integer index = 1; index <= extended.Length(); ++index) {
    const Standard_ExtCharacter ch = extended.Value(index);
    value.push_back((ch >= 32 && ch <= 126) ? static_cast<char>(ch) : '_');
  }
  return Trim(value);
}

std::string LabelEntry(const TDF_Label& label) {
  TCollection_AsciiString entry;
  TDF_Tool::Entry(label, entry);
  return entry.IsEmpty() ? "" : std::string(entry.ToCString());
}

std::string JoinPath(const std::vector<std::string>& path_segments) {
  std::string joined;
  for (const auto& segment : path_segments) {
    if (segment.empty()) {
      continue;
    }
    if (!joined.empty()) {
      joined += "/";
    }
    joined += segment;
  }
  return joined;
}

ScopedTempFile WriteTempStepFile(const std::string& file_name, const std::string& payload) {
  const std::filesystem::path temp_dir = std::filesystem::temp_directory_path();
  const std::string stem = BaseNameWithoutExtension(file_name);
  std::random_device random_device;
  std::mt19937_64 generator(random_device());
  std::uniform_int_distribution<unsigned long long> distribution;

  for (int attempt = 0; attempt < 32; ++attempt) {
    const auto timestamp = static_cast<unsigned long long>(
        std::chrono::high_resolution_clock::now().time_since_epoch().count());
    const auto random_suffix = distribution(generator);
    const auto candidate =
        temp_dir / (stem + "_" + std::to_string(timestamp) + "_" + std::to_string(random_suffix) + ".step");

    std::ofstream out(candidate, std::ios::binary | std::ios::trunc);
    if (!out.is_open()) {
      continue;
    }
    out.write(payload.data(), static_cast<std::streamsize>(payload.size()));
    out.close();
    return ScopedTempFile(candidate);
  }

  throw core::CadunpackError(
      core::ErrorCode::kIoError,
      "STEP parse failed: the STEP payload could not be staged to a temporary file.");
}

TopoDS_Shape ReadStepShape(const std::string& step_path) {
  STEPControl_Reader reader;
  const IFSelect_ReturnStatus status = reader.ReadFile(step_path.c_str());
  if (status != IFSelect_RetDone) {
    throw core::CadunpackError(
        core::ErrorCode::kStepReadFailed,
        "STEP parse failed: the STEP file could not be read.");
  }
  if (reader.TransferRoots() == 0) {
    throw core::CadunpackError(
        core::ErrorCode::kStepReadFailed,
        "STEP parse failed: the STEP file did not contain transferable geometry.");
  }
  return reader.OneShape();
}

std::vector<std::pair<TopoDS_Shape, ShapeKind>> ExpandShape(const TopoDS_Shape& shape) {
  std::vector<std::pair<TopoDS_Shape, ShapeKind>> expanded_shapes;

  for (TopExp_Explorer explorer(shape, TopAbs_SOLID); explorer.More(); explorer.Next()) {
    expanded_shapes.push_back({explorer.Current(), ShapeKind::kSolid});
  }
  if (!expanded_shapes.empty()) {
    return expanded_shapes;
  }

  for (TopExp_Explorer explorer(shape, TopAbs_SHELL); explorer.More(); explorer.Next()) {
    expanded_shapes.push_back({explorer.Current(), ShapeKind::kShell});
  }
  if (!expanded_shapes.empty()) {
    return expanded_shapes;
  }

  if (!shape.IsNull()) {
    expanded_shapes.push_back({shape, ShapeKind::kShape});
  }
  return expanded_shapes;
}

std::string AppendComponent(const TopoDS_Shape& shape,
                            ShapeKind shape_kind,
                            const std::string& preferred_name,
                            const std::vector<std::string>& path_segments,
                            const std::string& owning_node_id,
                            ExtractionContext& context) {
  SourceComponent component;
  component.summary.component_id = "cmp_" + std::to_string(context.next_component_index++);
  component.summary.source_name = preferred_name.empty() ? "component" : preferred_name;
  component.summary.component_name = component.summary.source_name;
  component.summary.assembly_path = JoinPath(path_segments);
  component.summary.owning_node_id = owning_node_id;
  component.summary.shape_kind = shape_kind;
  component.shape = shape;

  const std::string component_id = component.summary.component_id;
  context.components.push_back(std::move(component));
  return component_id;
}

std::vector<std::string> AppendExpandedShapes(const TopoDS_Shape& shape,
                                              const std::string& preferred_name,
                                              const std::vector<std::string>& path_segments,
                                              const std::string& owning_node_id,
                                              ExtractionContext& context) {
  std::vector<std::string> component_ids;
  for (const auto& [expanded_shape, shape_kind] : ExpandShape(shape)) {
    component_ids.push_back(
        AppendComponent(expanded_shape, shape_kind, preferred_name, path_segments, owning_node_id, context));
  }
  return component_ids;
}

std::vector<std::string> ExtractNodeShape(const Handle(XCAFDoc_ShapeTool)& shape_tool,
                                          const TDF_Label& label,
                                          const TDF_Label& referred_label,
                                          const std::string& effective_name,
                                          const std::vector<std::string>& current_path,
                                          const std::string& owning_node_id,
                                          bool& has_shape,
                                          ExtractionContext& context) {
  TopoDS_Shape shape = shape_tool->GetShape(label);
  if (shape.IsNull() && !referred_label.IsNull()) {
    shape = shape_tool->GetShape(referred_label);
  }

  has_shape = !shape.IsNull();
  return AppendExpandedShapes(shape, effective_name, current_path, owning_node_id, context);
}

AssemblyNode CollectAssemblyNode(const Handle(XCAFDoc_ShapeTool)& shape_tool,
                                 const TDF_Label& label,
                                 const std::string& inherited_name,
                                 const std::vector<std::string>& parent_path,
                                 std::set<std::string>& active_labels,
                                 std::size_t depth,
                                 ExtractionContext& context) {
  if (depth > kMaxAssemblyTraversalDepth) {
    ThrowUnsupportedTopology("assembly traversal exceeded the supported depth limit.");
  }
  if (context.next_node_index > kMaxAssemblyNodes) {
    ThrowUnsupportedTopology("assembly traversal exceeded the supported node limit.");
  }

  std::string effective_name = inherited_name;
  const std::string label_name = LabelName(label);
  if (!label_name.empty()) {
    effective_name = label_name;
  }

  TDF_Label referred_label;
  bool is_reference = false;
  if (shape_tool->IsReference(label) && shape_tool->GetReferredShape(label, referred_label) && !referred_label.IsNull()) {
    is_reference = true;
    const std::string referred_name = LabelName(referred_label);
    if (effective_name.empty() && !referred_name.empty()) {
      effective_name = referred_name;
    }
  } else {
    referred_label = label;
  }

  if (effective_name.empty()) {
    effective_name = "component";
  }

  AssemblyNode node;
  node.node_id = "node_" + std::to_string(context.next_node_index++);
  node.label_entry = LabelEntry(label);
  node.name = effective_name;
  node.is_reference = is_reference;

  const std::string referred_entry = LabelEntry(referred_label);
  const std::string guard_key = referred_entry.empty() ? node.label_entry : referred_entry;
  const bool tracked = !guard_key.empty() && active_labels.insert(guard_key).second;
  if (!guard_key.empty() && !tracked) {
    ThrowUnsupportedTopology("unsupported recursive assembly/reference topology was detected.");
  }

  std::vector<std::string> current_path = parent_path;
  current_path.push_back(effective_name);

  TDF_LabelSequence children;
  shape_tool->GetComponents(label, children, Standard_False);
  if (children.Length() == 0 && !referred_label.IsNull() && !referred_label.IsEqual(label)) {
    shape_tool->GetComponents(referred_label, children, Standard_False);
  }

  node.is_assembly = children.Length() > 0;
  if (children.Length() > 0) {
    for (Standard_Integer index = 1; index <= children.Length(); ++index) {
      node.children.push_back(CollectAssemblyNode(
          shape_tool,
          children.Value(index),
          effective_name,
          current_path,
          active_labels,
          depth + 1,
          context));
    }
    if (tracked) {
      active_labels.erase(guard_key);
    }
    return node;
  }

  node.component_ids = ExtractNodeShape(
      shape_tool,
      label,
      referred_label,
      effective_name,
      current_path,
      node.node_id,
      node.has_shape,
      context);
  if (tracked) {
    active_labels.erase(guard_key);
  }
  return node;
}

void FinalizeComponentNames(std::vector<SourceComponent>& components, const std::string& file_name) {
  std::map<std::string, int> occurrences;
  const std::string file_stem = BaseNameWithoutExtension(file_name);

  for (std::size_t index = 0; index < components.size(); ++index) {
    std::string base_name = SanitizeName(components[index].summary.source_name);
    if (base_name.empty()) {
      base_name = components.size() == 1 ? file_stem : file_stem + "_" + std::to_string(index + 1);
    }

    const int sequence = ++occurrences[base_name];
    components[index].summary.component_name =
        sequence == 1 ? base_name : base_name + "_" + std::to_string(sequence);
  }
}

ExtractedStepData BuildFallbackModel(const std::string& file_name, const TopoDS_Shape& root_shape) {
  ExtractionContext context;
  ExtractedStepData result;
  result.model.file_name = file_name;

  const std::string root_name = BaseNameWithoutExtension(file_name);
  AssemblyNode root;
  root.node_id = "node_" + std::to_string(context.next_node_index++);
  root.name = root_name;
  root.is_assembly = true;
  root.has_shape = !root_shape.IsNull();

  const std::vector<std::string> root_path{root_name};
  const auto expanded_shapes = ExpandShape(root_shape);
  for (std::size_t index = 0; index < expanded_shapes.size(); ++index) {
    AssemblyNode child;
    child.node_id = "node_" + std::to_string(context.next_node_index++);
    child.name = expanded_shapes.size() == 1 ? root_name : root_name + "_" + std::to_string(index + 1);
    child.has_shape = true;
    child.component_ids.push_back(
        AppendComponent(expanded_shapes[index].first, expanded_shapes[index].second, root_name, root_path, child.node_id, context));
    root.children.push_back(std::move(child));
  }

  FinalizeComponentNames(context.components, file_name);
  result.model.roots.push_back(std::move(root));
  result.model.components.reserve(context.components.size());
  for (const auto& component : context.components) {
    result.model.components.push_back(component.summary);
  }
  result.source_components = std::move(context.components);
  return result;
}

ExtractedStepData ExtractStepData(const std::string& file_name, const std::string& step_path) {
  Handle(XCAFApp_Application) application = XCAFApp_Application::GetApplication();
  Handle(TDocStd_Document) document;
  application->NewDocument("MDTV-XCAF", document);

  STEPCAFControl_Reader reader;
  reader.SetColorMode(Standard_False);
  reader.SetLayerMode(Standard_False);
  reader.SetNameMode(Standard_True);
  reader.SetPropsMode(Standard_False);

  const IFSelect_ReturnStatus status = reader.ReadFile(step_path.c_str());
  if (status != IFSelect_RetDone) {
    throw core::CadunpackError(
        core::ErrorCode::kStepReadFailed,
        "STEP parse failed: the STEP file could not be read.");
  }
  if (!reader.Transfer(document)) {
    throw core::CadunpackError(
        core::ErrorCode::kStepReadFailed,
        "STEP parse failed: the STEP file did not contain transferable geometry.");
  }

  Handle(XCAFDoc_ShapeTool) shape_tool = XCAFDoc_DocumentTool::ShapeTool(document->Main());
  TDF_LabelSequence free_shapes;
  shape_tool->GetFreeShapes(free_shapes);

  ExtractionContext context;
  std::set<std::string> active_labels;
  ExtractedStepData result;
  result.model.file_name = file_name;

  const std::string file_stem = BaseNameWithoutExtension(file_name);
  for (Standard_Integer index = 1; index <= free_shapes.Length(); ++index) {
    result.model.roots.push_back(CollectAssemblyNode(
        shape_tool,
        free_shapes.Value(index),
        file_stem,
        {},
        active_labels,
        0,
        context));
  }

  if (context.components.empty()) {
    return BuildFallbackModel(file_name, ReadStepShape(step_path));
  }

  FinalizeComponentNames(context.components, file_name);
  result.model.components.reserve(context.components.size());
  for (const auto& component : context.components) {
    result.model.components.push_back(component.summary);
  }
  result.source_components = std::move(context.components);
  return result;
}

}  // namespace

ExtractedStepData ComponentExtractor::extract_file(const std::filesystem::path& path) const {
  if (path.empty()) {
    throw core::CadunpackError(
        core::ErrorCode::kInvalidArgument,
        "STEP parse failed: a STEP file path is required.");
  }
  if (!std::filesystem::exists(path)) {
    throw core::CadunpackError(
        core::ErrorCode::kIoError,
        "STEP parse failed: the STEP file does not exist.");
  }

  return ExtractStepData(path.filename().string(), path.string());
}

ExtractedStepData ComponentExtractor::extract_bytes(const std::string& file_name, const std::string& step_payload) const {
  if (file_name.empty()) {
    throw core::CadunpackError(
        core::ErrorCode::kInvalidArgument,
        "STEP parse failed: a source file name is required.");
  }
  if (step_payload.empty()) {
    throw core::CadunpackError(
        core::ErrorCode::kInvalidArgument,
        "STEP parse failed: the STEP payload is empty.");
  }

  const ScopedTempFile temp_file = WriteTempStepFile(file_name, step_payload);
  return ExtractStepData(file_name, temp_file.path.string());
}

}  // namespace cadunpack::step

