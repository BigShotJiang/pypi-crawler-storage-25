#include "cadunpack/step/step_unpacker.hpp"

#include <exception>

#include "cadunpack/core/error.hpp"

#include "cadunpack/step/component_extractor.hpp"

namespace cadunpack::step {

namespace {

UnpackedComponent ConvertComponent(const cadunpack::unfold::UnfoldedComponent& component) {
  UnpackedComponent result;
  result.summary.component_id = component.component_id;
  result.summary.source_name = component.source_name;
  result.summary.component_name = component.component_name;
  result.summary.assembly_path = component.assembly_path;
  result.summary.owning_node_id = component.owning_node_id;
  result.summary.shape_kind = component.shape_kind;
  result.generated_dxf_file_name = component.generated_dxf_file_name;
  result.generated_dxf = component.generated_dxf;
  result.has_bends = component.has_bends;
  result.warnings.reserve(component.warnings.size());
  for (const auto& warning : component.warnings) {
    result.warnings.push_back(UnpackWarning{
        .code = warning.code,
        .message = warning.message,
    });
  }
  return result;
}

}  // namespace

UnpackResult StepUnpacker::unpack_file(const std::filesystem::path& path) const {
  ComponentExtractor extractor;
  cadunpack::unfold::SheetMetalUnfolder unfolder;

  ExtractedStepData extracted = extractor.extract_file(path);
  std::vector<cadunpack::unfold::UnfoldedComponent> unfolded_components;
  try {
    unfolded_components = unfolder.unfold(path.filename().string(), extracted.source_components);
  } catch (const core::CadunpackError&) {
    throw;
  } catch (const std::exception& error) {
    throw core::CadunpackError(core::ErrorCode::kUnfoldFailed, error.what());
  }

  UnpackResult result;
  result.model = std::move(extracted.model);
  result.components.reserve(unfolded_components.size());
  for (const auto& component : unfolded_components) {
    result.components.push_back(ConvertComponent(component));
  }
  return result;
}

UnpackResult StepUnpacker::unpack_bytes(const std::string& file_name, const std::string& step_payload) const {
  ComponentExtractor extractor;
  cadunpack::unfold::SheetMetalUnfolder unfolder;

  ExtractedStepData extracted = extractor.extract_bytes(file_name, step_payload);
  std::vector<cadunpack::unfold::UnfoldedComponent> unfolded_components;
  try {
    unfolded_components = unfolder.unfold(file_name, extracted.source_components);
  } catch (const core::CadunpackError&) {
    throw;
  } catch (const std::exception& error) {
    throw core::CadunpackError(core::ErrorCode::kUnfoldFailed, error.what());
  }

  UnpackResult result;
  result.model = std::move(extracted.model);
  result.components.reserve(unfolded_components.size());
  for (const auto& component : unfolded_components) {
    result.components.push_back(ConvertComponent(component));
  }
  return result;
}

}  // namespace cadunpack::step
