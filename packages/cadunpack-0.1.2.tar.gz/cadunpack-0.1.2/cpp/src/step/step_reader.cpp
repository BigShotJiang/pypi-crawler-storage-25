#include "cadunpack/step/step_reader.hpp"

#include "cadunpack/step/component_extractor.hpp"

namespace cadunpack::step {

StepModel StepReader::read_file(const std::filesystem::path& path) const {
  ComponentExtractor extractor;
  return extractor.extract_file(path).model;
}

StepModel StepReader::read_bytes(const std::string& file_name, const std::string& step_payload) const {
  ComponentExtractor extractor;
  return extractor.extract_bytes(file_name, step_payload).model;
}

}  // namespace cadunpack::step

