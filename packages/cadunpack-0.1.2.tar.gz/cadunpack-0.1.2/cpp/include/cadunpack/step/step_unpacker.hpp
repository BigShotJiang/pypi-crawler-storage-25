#pragma once

#include <filesystem>
#include <string>
#include <vector>

#include "cadunpack/unfold/sheetmetal_unfolder.hpp"
#include "cadunpack/step/types.hpp"

namespace cadunpack::step {

struct UnpackWarning {
  std::string code;
  std::string message;
};

struct UnpackedComponent {
  StepComponent summary;
  std::string generated_dxf_file_name;
  std::string generated_dxf;
  bool has_bends = false;
  std::vector<UnpackWarning> warnings;
};

struct UnpackResult {
  StepModel model;
  std::vector<UnpackedComponent> components;
};

class StepUnpacker {
 public:
  [[nodiscard]] UnpackResult unpack_file(const std::filesystem::path& path) const;
  [[nodiscard]] UnpackResult unpack_bytes(const std::string& file_name, const std::string& step_payload) const;
};

}  // namespace cadunpack::step
