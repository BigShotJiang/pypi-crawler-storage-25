#pragma once

#include <TopoDS_Shape.hxx>

#include <string>
#include <vector>

namespace cadunpack::step {

enum class ShapeKind {
  kSolid,
  kShell,
  kShape,
};

struct StepComponent {
  std::string component_id;
  std::string source_name;
  std::string component_name;
  std::string assembly_path;
  std::string owning_node_id;
  ShapeKind shape_kind = ShapeKind::kShape;
};

struct AssemblyNode {
  std::string node_id;
  std::string label_entry;
  std::string name;
  bool is_reference = false;
  bool is_assembly = false;
  bool has_shape = false;
  std::vector<std::string> component_ids;
  std::vector<AssemblyNode> children;
};

struct StepModel {
  std::string file_name;
  std::vector<AssemblyNode> roots;
  std::vector<StepComponent> components;
};

struct SourceComponent {
  StepComponent summary;
  TopoDS_Shape shape;
};

struct ExtractedStepData {
  StepModel model;
  std::vector<SourceComponent> source_components;
};

inline const char* ToString(ShapeKind shape_kind) noexcept {
  switch (shape_kind) {
    case ShapeKind::kSolid:
      return "solid";
    case ShapeKind::kShell:
      return "shell";
    case ShapeKind::kShape:
      return "shape";
  }
  return "shape";
}

}  // namespace cadunpack::step
