#pragma once

#include <filesystem>
#include <string>

#include "cadunpack/step/types.hpp"

namespace cadunpack::step {

class ComponentExtractor {
 public:
  [[nodiscard]] ExtractedStepData extract_file(const std::filesystem::path& path) const;
  [[nodiscard]] ExtractedStepData extract_bytes(const std::string& file_name, const std::string& step_payload) const;
};

}  // namespace cadunpack::step

