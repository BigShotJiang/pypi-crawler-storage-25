#pragma once

#include <filesystem>
#include <string>

#include "cadunpack/step/types.hpp"

namespace cadunpack::step {

class StepReader {
 public:
  [[nodiscard]] StepModel read_file(const std::filesystem::path& path) const;
  [[nodiscard]] StepModel read_bytes(const std::string& file_name, const std::string& step_payload) const;
};

}  // namespace cadunpack::step

