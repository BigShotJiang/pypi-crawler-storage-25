#pragma once

#include <stdexcept>
#include <string>

namespace cadunpack::core {

enum class ErrorCode {
  kInvalidArgument,
  kIoError,
  kStepReadFailed,
  kUnsupportedTopology,
  kUnfoldFailed,
};

class CadunpackError : public std::runtime_error {
 public:
  CadunpackError(ErrorCode code, std::string message)
      : std::runtime_error(std::move(message)), code_(code) {}

  [[nodiscard]] ErrorCode code() const noexcept { return code_; }

 private:
  ErrorCode code_;
};

inline const char* ToString(ErrorCode code) noexcept {
  switch (code) {
    case ErrorCode::kInvalidArgument:
      return "invalid_argument";
    case ErrorCode::kIoError:
      return "io_error";
    case ErrorCode::kStepReadFailed:
      return "step_read_failed";
    case ErrorCode::kUnsupportedTopology:
      return "unsupported_topology";
    case ErrorCode::kUnfoldFailed:
      return "unfold_failed";
  }
  return "unknown";
}

}  // namespace cadunpack::core

