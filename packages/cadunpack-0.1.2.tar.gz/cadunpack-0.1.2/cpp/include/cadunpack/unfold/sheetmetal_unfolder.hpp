#pragma once

#include <string>
#include <vector>

#include "cadunpack/step/types.hpp"

namespace cadunpack::unfold {

struct UnfoldWarning {
  std::string code;
  std::string message;
};

struct UnfoldedComponent {
  std::string component_id;
  std::string source_name;
  std::string component_name;
  std::string assembly_path;
  std::string owning_node_id;
  cadunpack::step::ShapeKind shape_kind = cadunpack::step::ShapeKind::kShape;
  std::string generated_dxf_file_name;
  std::string generated_dxf;
  bool has_bends = false;
  std::vector<UnfoldWarning> warnings;
};

class SheetMetalUnfolder {
 public:
  [[nodiscard]] std::vector<UnfoldedComponent> unfold(const std::string& file_name,
                                                      const std::vector<cadunpack::step::SourceComponent>& components) const;
};

}  // namespace cadunpack::unfold
