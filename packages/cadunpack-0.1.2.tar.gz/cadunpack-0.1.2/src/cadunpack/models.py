from __future__ import annotations

from dataclasses import dataclass, field
from enum import Enum


class ShapeKind(str, Enum):
    SOLID = "solid"
    SHELL = "shell"
    SHAPE = "shape"


@dataclass(frozen=True)
class StepComponent:
    component_id: str
    source_name: str
    component_name: str
    assembly_path: str
    owning_node_id: str
    shape_kind: ShapeKind


@dataclass(frozen=True)
class AssemblyNode:
    node_id: str
    label_entry: str
    name: str
    is_reference: bool
    is_assembly: bool
    has_shape: bool
    component_ids: tuple[str, ...] = field(default_factory=tuple)
    children: tuple["AssemblyNode", ...] = field(default_factory=tuple)


@dataclass(frozen=True)
class StepModel:
    file_name: str
    roots: tuple[AssemblyNode, ...]
    components: tuple[StepComponent, ...]


@dataclass(frozen=True)
class UnpackWarning:
    code: str
    message: str


@dataclass(frozen=True)
class UnpackedComponent:
    summary: StepComponent
    generated_dxf_file_name: str
    generated_dxf_text: str
    has_bends: bool
    warnings: tuple[UnpackWarning, ...] = field(default_factory=tuple)


@dataclass(frozen=True)
class UnpackResult:
    model: StepModel
    components: tuple[UnpackedComponent, ...]
