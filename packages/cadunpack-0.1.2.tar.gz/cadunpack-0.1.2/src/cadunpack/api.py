from __future__ import annotations

from pathlib import Path
from typing import Any

from .models import (
    AssemblyNode,
    ShapeKind,
    StepComponent,
    StepModel,
    UnpackResult,
    UnpackWarning,
    UnpackedComponent,
)


class NativeBindingError(RuntimeError):
    """Raised when the compiled cadunpack extension is unavailable."""


def _load_native() -> Any:
    try:
        from . import _cadunpack
    except ImportError as exc:  # pragma: no cover - depends on local build state.
        raise NativeBindingError(
            "cadunpack is installed but its native extension is unavailable. "
            "Install a compatible cadunpack wheel for this platform or reinstall with the required native runtime."
        ) from exc
    return _cadunpack


def _shape_kind_from_native(value: Any) -> ShapeKind:
    name = getattr(value, "name", None)
    if name == "SOLID":
        return ShapeKind.SOLID
    if name == "SHELL":
        return ShapeKind.SHELL
    return ShapeKind.SHAPE


def _convert_node(node: Any) -> AssemblyNode:
    return AssemblyNode(
        node_id=node.node_id,
        label_entry=node.label_entry,
        name=node.name,
        is_reference=bool(node.is_reference),
        is_assembly=bool(node.is_assembly),
        has_shape=bool(node.has_shape),
        component_ids=tuple(node.component_ids),
        children=tuple(_convert_node(child) for child in node.children),
    )


def _convert_component(component: Any) -> StepComponent:
    return StepComponent(
        component_id=component.component_id,
        source_name=component.source_name,
        component_name=component.component_name,
        assembly_path=component.assembly_path,
        owning_node_id=component.owning_node_id,
        shape_kind=_shape_kind_from_native(component.shape_kind),
    )


def _convert_model(model: Any) -> StepModel:
    return StepModel(
        file_name=model.file_name,
        roots=tuple(_convert_node(node) for node in model.roots),
        components=tuple(_convert_component(component) for component in model.components),
    )


def _convert_warning(warning: Any) -> UnpackWarning:
    return UnpackWarning(code=warning.code, message=warning.message)


def _convert_unpacked_component(component: Any) -> UnpackedComponent:
    return UnpackedComponent(
        summary=_convert_component(component.summary),
        generated_dxf_file_name=component.generated_dxf_file_name,
        generated_dxf_text=component.generated_dxf,
        has_bends=bool(component.has_bends),
        warnings=tuple(_convert_warning(warning) for warning in component.warnings),
    )


def _convert_unpack_result(result: Any) -> UnpackResult:
    return UnpackResult(
        model=_convert_model(result.model),
        components=tuple(_convert_unpacked_component(component) for component in result.components),
    )


def parse_step(path: str | Path) -> StepModel:
    resolved_path = Path(path)
    if not resolved_path.exists():
        raise FileNotFoundError(resolved_path)
    native = _load_native()
    native_model = native.parse_step(str(resolved_path))
    return _convert_model(native_model)


def parse_step_bytes(data: bytes, file_name: str) -> StepModel:
    if not file_name:
        raise ValueError("file_name must not be empty.")
    native = _load_native()
    native_model = native.parse_step_bytes(file_name, bytes(data))
    return _convert_model(native_model)


def unpack_step(path: str | Path) -> UnpackResult:
    resolved_path = Path(path)
    if not resolved_path.exists():
        raise FileNotFoundError(resolved_path)
    native = _load_native()
    native_result = native.unpack_step(str(resolved_path))
    return _convert_unpack_result(native_result)


def unpack_step_bytes(data: bytes, file_name: str) -> UnpackResult:
    if not file_name:
        raise ValueError("file_name must not be empty.")
    native = _load_native()
    native_result = native.unpack_step_bytes(file_name, bytes(data))
    return _convert_unpack_result(native_result)
