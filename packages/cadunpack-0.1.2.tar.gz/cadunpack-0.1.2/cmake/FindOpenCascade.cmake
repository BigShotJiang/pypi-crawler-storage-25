include(FindPackageHandleStandardArgs)

set(_opencascade_default_components
  TKernel
  TKMath
  TKG2d
  TKG3d
  TKCDF
  TKLCAF
  TKCAF
  TKGeomBase
  TKGeomAlgo
  TKTopAlgo
  TKBRep
  TKPrim
  TKShHealing
  TKXSBase
  TKXCAF
  TKDESTEP
)

if(NOT OpenCascade_FIND_COMPONENTS)
  set(OpenCascade_FIND_COMPONENTS ${_opencascade_default_components})
endif()

find_path(
  OpenCascade_INCLUDE_DIR
  NAMES gp_Pnt.hxx
  PATH_SUFFIXES opencascade oce
)

set(OpenCascade_LIBRARIES "")
foreach(component IN LISTS OpenCascade_FIND_COMPONENTS)
  set(_opencascade_component_names "${component}")
  if(component STREQUAL "TKDESTEP")
    list(APPEND _opencascade_component_names TKXDESTEP)
  elseif(component STREQUAL "TKXDESTEP")
    list(APPEND _opencascade_component_names TKDESTEP)
  endif()

  find_library(OpenCascade_${component}_LIBRARY NAMES ${_opencascade_component_names})
  mark_as_advanced(OpenCascade_${component}_LIBRARY)
  if(OpenCascade_${component}_LIBRARY)
    set(OpenCascade_${component}_FOUND TRUE)
    list(APPEND OpenCascade_LIBRARIES "${OpenCascade_${component}_LIBRARY}")
  else()
    set(OpenCascade_${component}_FOUND FALSE)
  endif()
endforeach()

set(OpenCascade_INCLUDE_DIRS "${OpenCascade_INCLUDE_DIR}")

find_package_handle_standard_args(
  OpenCascade
  REQUIRED_VARS OpenCascade_INCLUDE_DIR OpenCascade_LIBRARIES
  HANDLE_COMPONENTS
)

if(OpenCascade_FOUND AND NOT TARGET OpenCascade::OpenCascade)
  add_library(OpenCascade::OpenCascade INTERFACE IMPORTED)
  set_target_properties(
    OpenCascade::OpenCascade
    PROPERTIES
      INTERFACE_INCLUDE_DIRECTORIES "${OpenCascade_INCLUDE_DIRS}"
      INTERFACE_LINK_LIBRARIES "${OpenCascade_LIBRARIES}"
  )
endif()
