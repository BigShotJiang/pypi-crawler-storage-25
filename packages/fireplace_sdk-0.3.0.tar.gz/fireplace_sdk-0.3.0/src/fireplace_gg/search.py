"""Search endpoints — ``/search/*``."""

from __future__ import annotations

from typing import Any, Optional

from fireplace_gg._transport import Transport


def _bool_str(value: Optional[bool]) -> Optional[str]:
    if value is None:
        return None
    return "true" if value else "false"


class Search:
    """Elasticsearch-powered market and event search with rich filtering."""

    def __init__(self, transport: Transport) -> None:
        self._t = transport

    def markets(
        self, *, q: Optional[str] = None, limit: Optional[int] = None,
        offset: Optional[int] = None,
        sort_by: Optional[str] = None, sort_order: Optional[str] = None,
        status: Optional[str] = None, category: Optional[str] = None,
        categories: Optional[str] = None,
        volume_min: Optional[float] = None, volume_max: Optional[float] = None,
        price_min: Optional[float] = None, price_max: Optional[float] = None,
        expires_in_seconds: Optional[int] = None,
        opened_seconds_back: Optional[int] = None,
        min_volume_1h: Optional[float] = None, max_volume_1h: Optional[float] = None,
        min_volume_1d: Optional[float] = None, max_volume_1d: Optional[float] = None,
        min_price_change_1h: Optional[float] = None, max_price_change_1h: Optional[float] = None,
        min_price_change_1d: Optional[float] = None, max_price_change_1d: Optional[float] = None,
    ) -> Any:
        """Elasticsearch-powered market search.

        Supports text search, volume/price/volatility range filters across
        multiple timeframes, category filters, status filters, and AI-powered
        search.

        All parameters are optional.

        Args:
            q: Text search query.
            limit: Max results.
            offset: Pagination offset.
            sort_by: Sort field (e.g. ``"volume_24h"``, ``"price"``, ``"end_date"``).
            sort_order: ``"asc"`` or ``"desc"``.
            status: ``"active"`` or ``"closed"``.
            category: Single category filter.
            categories: Multiple category filter (repeated param or comma-separated).
            volume_min / volume_max: Total volume filter.
            price_min / price_max: Price filter (0-1).
            expires_in_seconds: Markets closing within N seconds.
            opened_seconds_back: Markets opened within this many seconds ago.
            min_volume_1h / max_volume_1h: 1-hour volume filter.
            min_volume_1d / max_volume_1d: 24-hour volume filter.
            min_price_change_1h / max_price_change_1h: 1h price change (percentage).
            min_price_change_1d / max_price_change_1d: 24h price change (percentage).
        """
        return self._t.get("/search/search", params={
            "q": q, "limit": limit, "offset": offset,
            "sortBy": sort_by, "sortOrder": sort_order, "status": status,
            "category": category, "categories": categories,
            "volumeMin": volume_min, "volumeMax": volume_max,
            "priceMin": price_min, "priceMax": price_max,
            "expiresInSeconds": expires_in_seconds,
            "openedSecondsBack": opened_seconds_back,
            "min_volume_1h": min_volume_1h, "max_volume_1h": max_volume_1h,
            "min_volume_1d": min_volume_1d, "max_volume_1d": max_volume_1d,
            "min_price_change_1h": min_price_change_1h, "max_price_change_1h": max_price_change_1h,
            "min_price_change_1d": min_price_change_1d, "max_price_change_1d": max_price_change_1d,
        })

    def events(
        self, *, q: Optional[str] = None, limit: Optional[int] = None,
        offset: Optional[int] = None,
        sort_by: Optional[str] = None, sort_order: Optional[str] = None,
        status: Optional[str] = None, category: Optional[str] = None,
        categories: Optional[str] = None,
    ) -> Any:
        """Search events (grouped markets).

        Similar to :meth:`markets` but returns results grouped by event
        rather than individual markets. Supports the same query parameters.

        All parameters are optional.

        Args:
            q: Search query.
            limit: Max results.
            offset: Pagination offset.
            sort_by: Sort field.
            sort_order: ``"asc"`` or ``"desc"``.
            status: ``"active"`` or ``"closed"``.
            category: Category filter.
            categories: Multiple categories (comma-separated).
        """
        return self._t.get("/search/search-events", params={
            "q": q, "limit": limit, "offset": offset,
            "sortBy": sort_by, "sortOrder": sort_order, "status": status,
            "category": category, "categories": categories,
        })
