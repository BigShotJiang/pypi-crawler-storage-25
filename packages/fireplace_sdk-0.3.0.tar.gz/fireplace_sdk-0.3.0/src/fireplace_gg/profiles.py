"""Profile endpoints — ``/profile/*``."""

from __future__ import annotations

from typing import Any, Dict, Optional

from fireplace_gg._transport import Transport


class Profiles:
    """Trader profile data: portfolio overview, positions, trades, PnL, activity."""

    def __init__(self, transport: Transport) -> None:
        self._t = transport

    def overview(self, trader_address: str) -> Dict[str, Any]:
        """Portfolio overview and PnL summary.

        Returns aggregated portfolio statistics for a trader including total
        PnL, position value, win rate, volume traded, and cash balance
        (on-chain USDC).

        Args:
            trader_address: Wallet address. **Required.**
        """
        return self._t.get("/profile/overview", params={"trader_address": trader_address})

    def positions(
        self, trader_address: str, *, limit: Optional[int] = None,
        offset: Optional[int] = None, is_active: Optional[bool] = None,
        market_id: Optional[str] = None, sort_by: Optional[str] = None,
        sort_type: Optional[str] = None,
    ) -> Any:
        """Trader's positions.

        Args:
            trader_address: Wallet address. **Required.**
            limit: Defaults to all for active, 20 for closed.
            offset: Default 0.
            is_active: Filter active/inactive.
            market_id: Filter by market.
            sort_by: ``"bought_value"``, ``"sold_value"``, ``"avg_entry_price"``,
                ``"current_holdings"``, ``"current_price"``, ``"pnl"``,
                ``"last_updated"``.
            sort_type: ``"asc"`` or ``"desc"``.
        """
        return self._t.get("/profile/positions", params={
            "trader_address": trader_address, "limit": limit, "offset": offset,
            "isActive": is_active, "marketId": market_id,
            "sortBy": sort_by, "sortType": sort_type,
        })

    def recent_trades(
        self, trader_address: str, *, limit: Optional[int] = None,
        cursor: Optional[str] = None, market_id: Optional[str] = None,
        outcome: Optional[str] = None, side: Optional[str] = None,
        min_shares: Optional[float] = None, min_usd: Optional[float] = None,
        date_from: Optional[int] = None, date_to: Optional[int] = None,
    ) -> Any:
        """Recent trades for a trader.

        Returns recent trades, redemptions, splits, and merges for a given
        trader address. Results are sorted by block number descending (most
        recent first) and support cursor-based pagination.

        Args:
            trader_address: Wallet address. **Required.**
            limit: 1-1000 (default 50).
            cursor: Cursor (``blockNumber:txIndex:logIndex``).
            market_id: Filter by market.
            outcome: Filter by outcome (e.g. ``"Yes"``, ``"No"``).
                Requires ``market_id``.
            side: ``"BUY"`` or ``"SELL"``.
            min_shares: Minimum shares.
            min_usd: Minimum USD value.
            date_from: Start time filter (Unix seconds).
            date_to: End time filter (Unix seconds).
        """
        return self._t.get("/profile/recent-trades", params={
            "trader_address": trader_address, "limit": limit, "cursor": cursor,
            "market_id": market_id, "outcome": outcome, "side": side,
            "minShares": min_shares, "minUSD": min_usd,
            "dateFrom": date_from, "dateTo": date_to,
        })

    def historical_pnl(self, trader_address: str, *, time_period: Optional[str] = None) -> Any:
        """PnL over time.

        Returns time-series PnL data for charting. Data points are bucketed
        at a granularity determined by the time period:
        1d = 5min, 1w = 30min, 1m = 2hr, 1y/all = 12hr.

        Args:
            trader_address: Wallet address. **Required.**
            time_period: ``"all"``, ``"1d"``, ``"1w"``, ``"1m"``, ``"1y"``.
        """
        return self._t.get("/profile/historical-pnl", params={
            "trader_address": trader_address, "time_period": time_period,
        })

    def activity(
        self, trader_address: str, *, limit: Optional[int] = None,
        cursor: Optional[str] = None,
    ) -> Any:
        """Unified activity feed (deposits, withdrawals, maker rebates, fee refunds).

        Args:
            trader_address: Wallet address. **Required.**
            limit: 1-1000 (default 50).
            cursor: Pagination cursor (``blockNumber:txIndex:logIndex``).
        """
        return self._t.get("/profile/activity", params={
            "trader_address": trader_address, "limit": limit, "cursor": cursor,
        })

    def unredeemed_positions(self, trader_address: str) -> Any:
        """Get trader's unredeemed winning positions.

        Returns positions on resolved markets that have not been redeemed yet.
        Includes redemption transaction data for imported (SAFE/MAGIC) wallets.

        Args:
            trader_address: Wallet address. **Required.**
        """
        return self._t.get("/profile/unredeemed-positions", params={
            "trader_address": trader_address,
        })
