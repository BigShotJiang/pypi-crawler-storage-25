"""News API — market-matched tweets with significance scoring."""

from __future__ import annotations

from typing import Any, Optional

from fireplace_gg._transport import Transport


class News:
    """Market-matched news tweets with relevance scoring and cursor pagination.

    Usage::

        items = fp.news.get(min_significance=3, limit=10)
    """

    def __init__(self, transport: Transport) -> None:
        self._t = transport

    def get(
        self,
        *,
        limit: Optional[int] = None,
        cursor: Optional[str] = None,
        direction: Optional[str] = None,
        min_significance: Optional[int] = None,
        market_id: Optional[str] = None,
        tweet_id: Optional[str] = None,
    ) -> Any:
        """Get news tweets matched to prediction markets.

        Args:
            limit: Number of items to return.
            cursor: Unix timestamp cursor for pagination (from ``nextCursor``/``prevCursor``).
            direction: ``"older"`` or ``"newer"`` relative to cursor.
            min_significance: Minimum significance filter (1=Low … 5=Critical).
            market_id: Filter to news matched to a specific market.
            tweet_id: Fetch a specific tweet by ID.
        """
        return self._t.get("/news", params={
            "limit": limit,
            "cursor": cursor,
            "direction": direction,
            "min_significance": min_significance,
            "market_id": market_id,
            "tweet_id": tweet_id,
        })
