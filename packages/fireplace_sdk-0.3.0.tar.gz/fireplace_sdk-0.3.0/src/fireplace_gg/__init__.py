"""
fireplace-gg — Python SDK for the Fireplace External API.

Usage::

    from fireplace_gg import Fireplace

    fp = Fireplace(api_key="fp_pk_...", api_secret="fp_sk_...")
    events = fp.search.events(q="Bitcoin")
    market = fp.markets.get_by_id("12345")
"""

from fireplace_gg.client import Fireplace
from fireplace_gg.exceptions import (
    FireplaceError,
    AuthenticationError,
    ForbiddenError,
    RateLimitError,
    BadRequestError,
    ServerError,
)
from fireplace_gg.stream import StreamError

__version__ = "0.3.0"

__all__ = [
    "Fireplace",
    "FireplaceError",
    "AuthenticationError",
    "ForbiddenError",
    "RateLimitError",
    "BadRequestError",
    "ServerError",
    "StreamError",
]
