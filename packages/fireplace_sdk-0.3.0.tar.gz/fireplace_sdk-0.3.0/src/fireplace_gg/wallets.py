"""Wallet endpoints — ``/wallets/*``."""

from __future__ import annotations

from typing import Any, List, Optional, Union

from fireplace_gg._transport import Transport


def _join(value: Union[str, List[str]]) -> str:
    if isinstance(value, list):
        return ",".join(value)
    return value


class Wallets:
    """Wallet-centric data: trades and net flows for one or more addresses."""

    def __init__(self, transport: Transport) -> None:
        self._t = transport

    def trades(
        self, wallets: Union[str, List[str]], *,
        limit: Optional[int] = None, cursor: Optional[str] = None,
        market_id: Optional[str] = None, outcome: Optional[str] = None,
        side: Optional[str] = None, min_amount: Optional[float] = None,
        min_price: Optional[float] = None, max_price: Optional[float] = None,
        start_time: Optional[str] = None, end_time: Optional[str] = None,
    ) -> Any:
        """Get recent trades for a list of wallet addresses.

        Args:
            wallets: Single address or list (max 50). **Required.**
            limit: 1-100 (default 50).
            cursor: Pagination cursor (``blockNumber:txIndex:logIndex``).
            market_id: Filter to a specific market.
            outcome: Filter by outcome (requires ``market_id``).
            side: ``"BUY"`` or ``"SELL"``.
            min_amount: Min trade amount in USD.
            min_price / max_price: Trade price range (0-1).
            start_time / end_time: ISO 8601 time range.
        """
        return self._t.get("/wallets/trades", params={
            "wallets": _join(wallets), "limit": limit, "cursor": cursor,
            "market_id": market_id, "outcome": outcome, "side": side,
            "minAmount": min_amount, "minPrice": min_price, "maxPrice": max_price,
            "startTime": start_time, "endTime": end_time,
        })

    def net_flows(
        self, wallets: Union[str, List[str]], *,
        limit: Optional[int] = None, offset: Optional[int] = None,
        sort_by: Optional[str] = None, sort_order: Optional[str] = None,
        lookback: Optional[str] = None,
    ) -> Any:
        """Get net buy/sell flows aggregated by market for wallet addresses.

        Shows which markets the wallets are buying into (bullish) vs
        selling out of (bearish).

        Args:
            wallets: Single address or list (max 50). **Required.**
            limit: 1-100 (default 20).
            offset: Default 0.
            sort_by: ``"volume"``, ``"buyVolume"``, ``"sellVolume"``, ``"netFlows"`` (default).
            sort_order: ``"asc"`` or ``"desc"`` (default ``"desc"``).
            lookback: Time period -- ``"Nd"`` for days (1-30), ``"Nh"`` for hours (1-23). Omit for all-time.
        """
        return self._t.get("/wallets/net-flows", params={
            "wallets": _join(wallets), "limit": limit, "offset": offset,
            "sortBy": sort_by, "sortOrder": sort_order, "lookback": lookback,
        })
