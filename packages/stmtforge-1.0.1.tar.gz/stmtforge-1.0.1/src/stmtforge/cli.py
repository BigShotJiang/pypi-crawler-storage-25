"""StmtForge CLI - Credit Card Statement Parser & Analyzer."""

import argparse
import os
import subprocess
import sys


ENV_EXAMPLE_TEMPLATE = """# ============================================================
# StmtForge - Environment Variables
# ============================================================
# Copy this file as .env and fill in your details.
# NEVER commit .env to version control.

# ---- Google OAuth ----
# Path to the OAuth credentials JSON downloaded from Google Cloud Console
GOOGLE_CREDENTIALS_FILE=credentials.json

# ---- PDF passwords ----
# Date of Birth (DDMMYYYY format) - used to unlock bank PDFs
DOB=
# PAN card number (uppercase, e.g. ABCDE1234F)
PAN=
# Additional passwords, comma-separated
CUSTOM_PASSWORDS=

# ---- Per-bank PDF passwords (optional overrides) ----
SBI_PASSWORD=
HDFC_PASSWORD=
ICICI_PASSWORD=
AXIS_PASSWORD=
IDFC_PASSWORD=
FEDERAL_PASSWORD=
CSB_PASSWORD=
YESBANK_PASSWORD=

# ---- Privacy logging ----
# Salt used to pseudonymize PII in event logs (change in production)
STMTFORGE_LOG_SALT=
"""

CARDS_DB_REPO_DEFAULT = "https://github.com/madhav921/stmtforge-cards-db.git"


def _cards_repo_source() -> str:
    """Return the cards repository source to clone for local setup."""
    return os.getenv("STMTFORGE_CARDS_REPO", CARDS_DB_REPO_DEFAULT).strip() or CARDS_DB_REPO_DEFAULT


def _find_cards_source(repo_root):
    """Locate the YAML directory inside a checked-out cards repo."""
    candidates = [
        repo_root / "rules" / "cards",
        repo_root / "src" / "stmtforge_cards_db" / "rules" / "cards",
        repo_root / "src" / "stmtforge_cards_db" / "data" / "cards",
    ]
    for candidate in candidates:
        if candidate.exists():
            return candidate
    return None


def _clone_cards_repo(repo_source: str, repo_dst) -> bool:
    """Clone the public cards repository into the local project."""
    try:
        subprocess.run(
            ["git", "clone", "--depth", "1", repo_source, str(repo_dst)],
            check=True,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            text=True,
        )
        return True
    except FileNotFoundError:
        print("Git is not installed, so stmtforge will use the bundled card snapshot.")
    except subprocess.CalledProcessError as exc:
        detail = (exc.stderr or exc.stdout or str(exc)).strip()
        print(f"Could not clone card rules repo from {repo_source}: {detail}")
    return False


def main():
    parser = argparse.ArgumentParser(
        prog="stmtforge",
        description="StmtForge - Credit Card Statement Parser & Analyzer",
    )
    sub = parser.add_subparsers(dest="command", help="Available commands")

    # ── run ───────────────────────────────────────────────────
    run_parser = sub.add_parser("run", help="Run the processing pipeline")
    run_parser.add_argument("--full", action="store_true",
                            help="Full historical fetch (default: incremental)")
    run_parser.add_argument("--local", action="store_true",
                            help="Process only local PDFs, skip Gmail fetch")
    run_parser.add_argument("--dashboard", action="store_true",
                            help="Launch dashboard after processing")
    run_parser.add_argument("--folder", type=str, default=None,
                            help="Process all PDFs in a specific folder")
    run_parser.add_argument("--reprocess", action="store_true",
                            help="Re-process all previously completed statements")

    # ── dashboard ─────────────────────────────────────────────
    sub.add_parser("dashboard", help="Launch the Streamlit dashboard")

    # ── init ──────────────────────────────────────────────────
    sub.add_parser("init", help="Initialize project directory with config template")

    # ── suggest ───────────────────────────────────────────────
    suggest_parser = sub.add_parser(
        "suggest",
        help="Get credit card recommendations based on your spend history",
    )
    suggest_parser.add_argument(
        "--months", type=int, default=6, metavar="N",
        help="Number of recent months of transactions to analyse (default: 6)",
    )
    suggest_parser.add_argument(
        "--top", type=int, default=5, metavar="N",
        help="Number of top cards to show (default: 5)",
    )
    suggest_parser.add_argument(
        "--max-fee", type=int, default=None, metavar="INR",
        help="Maximum annual fee filter in ₹",
    )
    suggest_parser.add_argument(
        "--free-only", action="store_true",
        help="Show only lifetime-free cards (annual_fee == 0)",
    )
    suggest_parser.add_argument(
        "--goal", choices=["cashback", "travel", "lounge", "any"], default=None,
        help="Filter by card goal/category tag",
    )
    suggest_parser.add_argument(
        "--combo", action="store_true",
        help="Also show best 2-card portfolio recommendation",
    )
    suggest_parser.add_argument(
        "--export", metavar="PATH", default=None,
        help="Export HTML report to the given path",
    )
    suggest_parser.add_argument(
        "--verbose", "-v", action="store_true",
        help="Show per-category reward breakdown",
    )

    # ── cards ─────────────────────────────────────────────────
    cards_parser = sub.add_parser("cards", help="Manage the card benefits database")
    cards_sub = cards_parser.add_subparsers(dest="cards_action", help="cards sub-commands")
    cards_sub.add_parser("list", help="List all cards with last_verified date")
    cards_sub.add_parser("validate", help="Validate all card YAMLs against schema")

    # ── reset ─────────────────────────────────────────────────
    reset_parser = sub.add_parser(
        "reset",
        help="Delete parsed data (DPDP right to erasure)",
    )
    reset_parser.add_argument(
        "--delete-all", action="store_true",
        help="Delete all transaction data, logs, and revoke Google OAuth token",
    )

    args = parser.parse_args()

    if args.command is None:
        parser.print_help()
        sys.exit(0)

    if args.command == "run":
        from stmtforge.run_pipeline import run_pipeline
        run_pipeline(
            full=args.full,
            local_only=args.local,
            folder=args.folder,
            reprocess=args.reprocess,
        )
        if args.dashboard:
            _launch_dashboard()

    elif args.command == "dashboard":
        _launch_dashboard()

    elif args.command == "init":
        _init_project()

    elif args.command == "suggest":
        _run_suggest(args)

    elif args.command == "cards":
        _run_cards(args)

    elif args.command == "reset":
        _run_reset(args)


def _run_suggest(args) -> None:
    """Handle ``stmtforge suggest`` command."""
    from pathlib import Path

    from stmtforge.suggestor.card_db import CardDB
    from stmtforge.suggestor.spend_vector import SpendVector
    from stmtforge.suggestor.optimizer import rank_cards, best_n_card_combo
    from stmtforge.suggestor.report import format_cli_table, export_html_report

    # ── Build spend vector from DB ────────────────────────────
    try:
        import sqlite3
        db_path = Path("data/ccanalyser.db")
        if not db_path.exists():
            print(
                "No database found. Run `stmtforge run` first to parse your statements.",
                file=sys.stderr,
            )
            sys.exit(1)
        with sqlite3.connect(db_path) as conn:
            spend_vector = SpendVector.from_db(conn, months=args.months)
    except Exception as exc:
        print(f"Error reading transaction data: {exc}", file=sys.stderr)
        sys.exit(1)

    if not spend_vector.categories:
        print("No transactions found for the specified period.", file=sys.stderr)
        sys.exit(1)

    # ── Load card database ────────────────────────────────────
    card_db = CardDB()
    cards = card_db.all_cards()

    # ── Apply filters ─────────────────────────────────────────
    if args.free_only:
        cards = [c for c in cards if c.get("annual_fee", 0) == 0]
    elif args.max_fee is not None:
        cards = [c for c in cards if c.get("annual_fee", 0) <= args.max_fee]

    if args.goal and args.goal != "any":
        cards = [c for c in cards if args.goal in (c.get("tags") or [])]

    # ── Rank cards ────────────────────────────────────────────
    ranked = rank_cards(cards, spend_vector)
    top_n = ranked[: args.top]

    # ── Format output ─────────────────────────────────────────
    table_str = format_cli_table(top_n, verbose=args.verbose)
    print(table_str)

    # ── Combo analysis ────────────────────────────────────────
    if args.combo:
        combo_card_ids = [c["id"] for c in cards]
        combo = best_n_card_combo(spend_vector, card_db, n=2, card_ids=combo_card_ids)
        if combo and len(combo.cards) >= 2:
            names = " + ".join(r.card_name for r in combo.cards[:2])
            print("\n── Best 2-card combination ──────────────────────────────")
            print(f"  {names}")
            print(f"  Combined net annual value: \u20b9{combo.combined_net_annual_value:,.0f}")

    # ── HTML export ───────────────────────────────────────────
    if args.export:
        export_html_report(spend_vector, ranked, output_path=args.export)
        print(f"\nHTML report saved to {args.export}")


def _run_cards(args) -> None:
    """Handle ``stmtforge cards list|validate`` commands."""
    from stmtforge.suggestor.card_db import CardDB

    if args.cards_action is None:
        print("Usage: stmtforge cards {list|validate}", file=sys.stderr)
        sys.exit(1)

    card_db = CardDB()

    if args.cards_action == "list":
        from datetime import date
        cards = sorted(card_db.all_cards(), key=lambda c: c.get("name", c["id"]))
        header = f"{'Card':<40} {'Issuer':<18} {'Fee':>8}  {'Last verified':<15} {'Staleness'}"
        print(header)
        print("-" * len(header))
        today = date.today()
        for c in cards:
            lv_raw = c.get("last_verified", "")
            try:
                lv = date.fromisoformat(lv_raw)
                age = (today - lv).days
                staleness = (
                    "🔴 >180d" if age > 180
                    else "🟡 >90d" if age > 90
                    else "✅ fresh"
                )
            except (ValueError, TypeError):
                staleness = "⚠ unknown"
                lv_raw = "—"
            fee_str = f"₹{c.get('annual_fee', 0):,}"
            print(f"{c.get('name', c['id']):<40} {c.get('issuer',''):<18} {fee_str:>8}  {lv_raw:<15} {staleness}")

    elif args.cards_action == "validate":
        errors = card_db.validate()
        if errors:
            print("Validation errors:")
            for e in errors:
                print(f"  - {e}")
            sys.exit(1)
        else:
            print(f"All {len(card_db.all_cards())} cards are valid.")


def _run_reset(args) -> None:
    """Handle ``stmtforge reset --delete-all``."""
    if not args.delete_all:
        print("Use --delete-all to confirm erasure of all data.", file=sys.stderr)
        sys.exit(1)

    print("WARNING: This will permanently delete all parsed transaction data.")
    confirm = input("Type 'yes' to confirm: ").strip().lower()
    if confirm != "yes":
        print("Aborted.")
        return

    from pathlib import Path
    import sqlite3

    db_path = Path("data/ccanalyser.db")
    if db_path.exists():
        with sqlite3.connect(db_path) as conn:
            cur = conn.cursor()
            for table in ["transactions", "extraction_log", "gmail_messages", "statements_metadata"]:
                try:
                    cur.execute(f"DELETE FROM {table}")
                    print(f"  Cleared table: {table}")
                except sqlite3.OperationalError:
                    pass
            conn.commit()

    # Revoke Google OAuth token
    token_path = Path("token.json")
    if token_path.exists():
        try:
            import json
            token_data = json.loads(token_path.read_text())
            import urllib.request
            revoke_url = "https://oauth2.googleapis.com/revoke"
            token = token_data.get("token") or token_data.get("access_token", "")
            if token:
                req = urllib.request.Request(
                    f"{revoke_url}?token={token}",
                    method="POST",
                )
                with urllib.request.urlopen(req):  # noqa: S310
                    pass
        except Exception:
            pass  # Best-effort revoke; token file will still be deleted
        token_path.unlink(missing_ok=True)
        print("  Revoked and deleted OAuth token.")

    print("All data erased. Run `stmtforge run` to re-process from scratch.")


def _launch_dashboard():
    import subprocess
    try:
        import streamlit  # noqa: F401
    except ImportError:
        print(
            "Error: streamlit is not installed.\n"
            "Run: pip install stmtforge  (or pip install streamlit plotly)\n"
            "then try again.",
            file=sys.stderr,
        )
        sys.exit(1)
    from pathlib import Path
    import stmtforge.dashboard.app as _app_module
    app_path = str(Path(_app_module.__file__))
    subprocess.run([sys.executable, "-m", "streamlit", "run", app_path], check=False)


def _init_project():
    from pathlib import Path
    import shutil

    from stmtforge.suggestor.card_db import _bundled_cards_dir

    target = Path.cwd()
    config_dst = target / "config.yaml"
    env_example_dst = target / ".env.example"

    if config_dst.exists():
        print(f"config.yaml already exists in {target}")
    else:
        # Copy bundled template
        template = Path(__file__).parent / "config_template.yaml"
        if template.exists():
            shutil.copy2(template, config_dst)
            print(f"Created config.yaml in {target}")
        else:
            print("No config template found. Create config.yaml manually.")

    # Create data directories
    for d in ["data/raw_pdfs", "data/unlocked_pdfs", "data/processed",
              "data/logs", "data/logs/events"]:
        (target / d).mkdir(parents=True, exist_ok=True)

    # Clone the rules repo locally and seed the active data/cards snapshot.
    cards_repo_dst = target / "data" / "cards-db"
    cards_dst = target / "data" / "cards"
    cards_repo_source = _cards_repo_source()

    if not cards_repo_dst.exists():
        if _clone_cards_repo(cards_repo_source, cards_repo_dst):
            print(f"Cloned cards rules repo to {cards_repo_dst}")

    cards_src = _find_cards_source(cards_repo_dst) if cards_repo_dst.exists() else None

    if not cards_dst.exists() and cards_src is not None:
        shutil.copytree(
            cards_src,
            cards_dst,
            ignore=shutil.ignore_patterns("__pycache__", "*.pyc", "__init__.py"),
        )
        print(f"Copied card database to {cards_dst} ({len(list(cards_dst.glob('*.yaml')))} cards)")
    elif cards_dst.exists():
        print(f"data/cards/ already exists ({len(list(cards_dst.glob('*.yaml')))} cards)")
    else:
        bundled_cards = _bundled_cards_dir()
        if bundled_cards.exists():
            shutil.copytree(
                bundled_cards,
                cards_dst,
                ignore=shutil.ignore_patterns("__pycache__", "*.pyc", "__init__.py"),
            )
            print(f"Copied bundled card database to {cards_dst} ({len(list(cards_dst.glob('*.yaml')))} cards)")

    # Create .env.example for first-time setup convenience
    if not env_example_dst.exists():
        env_example_dst.write_text(ENV_EXAMPLE_TEMPLATE, encoding="utf-8")
        print(f"Created .env.example in {target}")

    print("To refresh card rules later, run `git -C data/cards-db pull` and re-run `stmtforge init`.")

    print("Project initialized. Edit config.yaml with your settings.")


if __name__ == "__main__":
    main()
