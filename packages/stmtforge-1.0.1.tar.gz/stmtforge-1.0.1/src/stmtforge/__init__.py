"""StmtForge - Credit Card Statement Parser & Analyzer."""

__version__ = "1.0.1"
