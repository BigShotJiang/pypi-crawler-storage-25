"""Reward value computation engine.

For each (SpendVector, card_definition) pair, computes the expected net annual
reward value in ₹.

Algorithm
---------
For each category in the spend vector:
  0. If the category is in ``excluded_categories``, skip it entirely — no fallback
     to the "Others" rate.  This models zero-earn categories (rent, EMI, wallet loads).
  1. Split monthly spend: merchant-specific spend at the override rate, remainder
     at the base category rate.  This fixes the bug where the override rate was
     applied to the entire category spend even when only part of it came from that
     merchant.
  2. Apply caps (cap_monthly_inr) independently to each spend segment.
  3. Multiply by 12 for an annual figure.

Add milestone bonuses (if projected annual spend hits thresholds).
Subtract effective annual fee (0 if spend qualifies for fee waiver).
Fee-waiver spend projection excludes ``fee_waiver.excluded_categories`` so that
zero-earn spend doesn't falsely qualify users for fee waivers.
"""

from __future__ import annotations

from dataclasses import dataclass, field

from stmtforge.suggestor.spend_vector import SpendVector


@dataclass
class CategoryBreakdown:
    """Reward earned from a single spending category."""
    category: str
    monthly_spend: float
    earn_rate: float
    raw_label: str         # human-readable rate description, e.g. "5% cashback"
    cap_monthly_inr: float | None
    monthly_reward_uncapped: float
    monthly_reward: float  # after applying cap
    annual_reward: float
    is_capped: bool
    matched_merchant: str | None = None  # non-None if a merchant override applied


@dataclass
class MilestoneBreakdown:
    """Bonus earned from a milestone."""
    description: str
    spend_threshold_inr: float
    projected_spend: float
    bonus_value_inr: float
    achieved: bool


@dataclass
class RewardResult:
    """Full reward computation result for one card against one spend vector.

    Attributes
    ----------
    card_id : str
    card_name : str
    issuer : str
    annual_fee : int
    effective_fee : float
        Annual fee after waiver (0 if waiver threshold met).
    fee_waived : bool
    gross_annual_reward : float
        Total reward before subtracting the fee.
    net_annual_value : float
        gross_annual_reward − effective_fee.
    category_breakdowns : list[CategoryBreakdown]
        Per-category breakdown, sorted by annual_reward descending.
    milestone_breakdowns : list[MilestoneBreakdown]
    caveats : list[str]
        Human-readable warnings (e.g. "Cap hit in Shopping category").
    """
    card_id: str
    card_name: str
    issuer: str
    annual_fee: int
    effective_fee: float
    fee_waived: bool
    gross_annual_reward: float
    net_annual_value: float
    category_breakdowns: list[CategoryBreakdown] = field(default_factory=list)
    milestone_breakdowns: list[MilestoneBreakdown] = field(default_factory=list)
    caveats: list[str] = field(default_factory=list)


def _compute_category_reward(
    cat_name: str,
    cat_def: dict,
    monthly_spend: float,
    spend_vector: SpendVector,
) -> tuple[float, float, float, float | None, str, str | None, bool]:
    """Compute monthly reward for a single category using the merchant-split model.

    Returns
    -------
    tuple of:
        earn_rate_effective  – blended effective rate (for display)
        monthly_reward       – after cap
        monthly_uncapped     – before cap
        cap_monthly_inr      – the cap that was applied (or None)
        raw_label            – human-readable description
        matched_merchant     – override merchant key or None
        is_capped            – True if cap was hit
    """
    base_rate: float = cat_def.get("earn_rate", 0.0)
    base_cap: float | None = cat_def.get("cap_monthly_inr")
    base_raw: str = cat_def.get("raw", f"{base_rate * 100:.1f}%")
    overrides: dict = cat_def.get("merchant_overrides") or {}

    # ── Merchant-split model ─────────────────────────────────────────────────
    # For each merchant override with relevant spend, apply the override rate
    # only to that merchant's spend.  The remainder of the category spend uses
    # the base rate.  Pick the single best override (highest earn_rate).
    best_merchant_key: str | None = None
    best_override: dict | None = None
    best_override_rate: float = -1.0

    for merchant_key, override_def in overrides.items():
        if not isinstance(override_def, dict):
            continue
        merchant_spend = spend_vector.merchant_spend(merchant_key)
        if merchant_spend <= 0:
            continue
        override_rate = override_def.get("earn_rate", 0.0)
        if override_rate > best_override_rate:
            best_override_rate = override_rate
            best_override = override_def
            best_merchant_key = merchant_key

    if best_override is not None:
        merchant_monthly = spend_vector.merchant_spend(best_merchant_key)
        # Clamp merchant spend to total category spend (can't exceed it)
        merchant_monthly = min(merchant_monthly, monthly_spend)
        remainder_monthly = max(0.0, monthly_spend - merchant_monthly)

        override_cap = best_override.get("cap_monthly_inr")
        override_raw = best_override.get("raw", f"{best_override_rate * 100:.1f}%")

        # Reward from merchant portion (with its own cap)
        override_uncapped = merchant_monthly * best_override_rate
        override_reward = (
            min(override_uncapped, override_cap)
            if override_cap is not None
            else override_uncapped
        )

        # Reward from remainder at base rate (with category cap, shared bucket)
        base_uncapped = remainder_monthly * base_rate
        # Category cap applies to total (override + base) if set
        if base_cap is not None:
            total_reward = min(override_reward + base_uncapped, base_cap)
            base_reward = max(0.0, total_reward - override_reward)
        else:
            base_reward = base_uncapped
            total_reward = override_reward + base_reward

        total_uncapped = override_uncapped + base_uncapped
        is_capped = total_uncapped > total_reward
        effective_earn = total_reward / monthly_spend if monthly_spend > 0 else 0.0
        cap_used = base_cap if base_cap is not None else override_cap

        raw_label = (
            f"{override_raw} on {best_merchant_key.title()} + {base_raw} on rest"
            if remainder_monthly > 0
            else override_raw
        )
        return (
            effective_earn, total_reward, total_uncapped,
            cap_used, raw_label, best_merchant_key, is_capped,
        )

    # ── Base rate only ────────────────────────────────────────────────────────
    uncapped = monthly_spend * base_rate
    if base_cap is not None:
        reward = min(uncapped, base_cap)
        is_capped = uncapped > base_cap
    else:
        reward = uncapped
        is_capped = False

    effective_earn = base_rate
    return effective_earn, reward, uncapped, base_cap, base_raw, None, is_capped


def compute_reward(card: dict, spend_vector: SpendVector) -> RewardResult:
    """Compute the expected net annual reward value for a card + spend vector.

    Parameters
    ----------
    card:
        A card definition dict as returned by :class:`~stmtforge.suggestor.card_db.CardDB`.
    spend_vector:
        The user's :class:`~stmtforge.suggestor.spend_vector.SpendVector`.

    Returns
    -------
    RewardResult
        Full breakdown of rewards, fees, and milestones.
    """
    card_id = card["id"]
    card_name = card.get("name", card_id)
    issuer = card.get("issuer", "")
    annual_fee = int(card.get("annual_fee", 0))
    categories_def: dict = card.get("categories", {})

    # Categories that earn ZERO — not even the Others fallback applies
    excluded: set[str] = set(card.get("excluded_categories") or [])

    category_breakdowns: list[CategoryBreakdown] = []
    gross_annual = 0.0
    caveats: list[str] = []

    # ── Per-category reward calculation ──────────────────────────────────────
    all_categories = set(spend_vector.categories.keys()) | {"Others"}

    for cat_name in all_categories:
        monthly_spend = spend_vector.category_spend(cat_name)
        if monthly_spend <= 0:
            continue

        # Skip explicitly excluded categories — zero earn, no Others fallback
        if cat_name in excluded:
            continue

        # Get the applicable category definition; fall back to Others
        cat_def = categories_def.get(cat_name) or categories_def.get("Others") or {}
        if not cat_def:
            continue

        (
            earn_rate, monthly_reward, monthly_uncapped,
            cap_monthly, raw_label, matched_merchant, is_capped,
        ) = _compute_category_reward(cat_name, cat_def, monthly_spend, spend_vector)

        if earn_rate <= 0 or monthly_reward <= 0:
            continue

        if is_capped:
            caveats.append(
                f"Cap hit in {cat_name} (earn ₹{monthly_uncapped:.0f}/month "
                f"but capped at ₹{monthly_reward:.0f}/month)"
            )

        annual_reward = monthly_reward * 12
        gross_annual += annual_reward

        category_breakdowns.append(CategoryBreakdown(
            category=cat_name,
            monthly_spend=monthly_spend,
            earn_rate=earn_rate,
            raw_label=raw_label,
            cap_monthly_inr=cap_monthly,
            monthly_reward_uncapped=monthly_uncapped,
            monthly_reward=monthly_reward,
            annual_reward=annual_reward,
            is_capped=is_capped,
            matched_merchant=matched_merchant,
        ))

    # Sort breakdowns by annual_reward descending for clean display
    category_breakdowns.sort(key=lambda x: x.annual_reward, reverse=True)

    # ── Milestone bonuses ────────────────────────────────────────────────────
    milestone_breakdowns: list[MilestoneBreakdown] = []
    # Total monthly avg minus excluded categories for more accurate projection
    eligible_monthly = sum(
        amt for cat, amt in spend_vector.categories.items()
        if cat not in excluded
    )
    projected_annual = eligible_monthly * 12

    for ms in card.get("milestones") or []:
        threshold = ms.get("spend_threshold_inr", 0)
        period_months = ms.get("period_months", 12)
        bonus = ms.get("bonus_value_inr", 0.0)
        desc = ms.get("description", "Milestone bonus")

        projected_period_spend = eligible_monthly * period_months
        achieved = projected_period_spend >= threshold

        if achieved:
            gross_annual += bonus

        milestone_breakdowns.append(MilestoneBreakdown(
            description=desc,
            spend_threshold_inr=threshold,
            projected_spend=projected_period_spend,
            bonus_value_inr=bonus,
            achieved=achieved,
        ))

    # ── Fee waiver ────────────────────────────────────────────────────────────
    fee_waived = False
    effective_fee = float(annual_fee)

    fw = card.get("fee_waiver")
    if fw and annual_fee > 0:
        # Subtract fee_waiver_excluded_categories from the annual spend projection
        fw_excluded: set[str] = set(fw.get("excluded_categories") or []) | excluded
        waiver_monthly = sum(
            amt for cat, amt in spend_vector.categories.items()
            if cat not in fw_excluded
        )
        projected_for_waiver = waiver_monthly * 12

        waiver_threshold = fw.get("annual_spend", float("inf"))
        if projected_for_waiver >= waiver_threshold:
            effective_fee = 0.0
            fee_waived = True
        else:
            shortfall = waiver_threshold - projected_for_waiver
            caveats.append(
                f"Annual fee of ₹{annual_fee} NOT waived "
                f"(need ₹{waiver_threshold:,.0f}/year; "
                f"you're ₹{shortfall:,.0f} short)"
            )

    net_annual = gross_annual - effective_fee

    return RewardResult(
        card_id=card_id,
        card_name=card_name,
        issuer=issuer,
        annual_fee=annual_fee,
        effective_fee=effective_fee,
        fee_waived=fee_waived,
        gross_annual_reward=gross_annual,
        net_annual_value=net_annual,
        category_breakdowns=category_breakdowns,
        milestone_breakdowns=milestone_breakdowns,
        caveats=caveats,
    )
