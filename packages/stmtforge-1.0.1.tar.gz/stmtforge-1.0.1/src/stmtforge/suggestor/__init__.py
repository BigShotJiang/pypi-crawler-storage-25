"""StmtForge suggestor package.

Provides credit card recommendation engine based on parsed transaction data.

Modules
-------
card_db      -- Card benefits YAML database loader and validator
spend_vector -- Build per-category spend vectors from the SQLite database
engine       -- Compute expected annual reward value for a card + spend vector
optimizer    -- Rank cards and compute optimal card portfolios
report       -- Format recommendations as CLI table or static HTML report
"""
