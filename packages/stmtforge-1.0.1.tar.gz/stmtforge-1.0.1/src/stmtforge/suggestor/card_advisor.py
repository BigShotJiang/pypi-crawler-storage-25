"""Per-transaction card advice engine.

For each transaction, determines which card from a given set earns the highest
effective reward rate, taking into account category rates and merchant overrides.

This module is READ-ONLY — it never touches the database.

Typical usage
-------------
    from stmtforge.suggestor.card_db import CardDB
    from stmtforge.suggestor.card_advisor import CardAdvisor

    card_db = CardDB()
    user_card_ids = ["sbi_cashback", "hdfc_swiggy", "idfc_first_select"]

    advisor = CardAdvisor(
        all_cards=card_db.all_cards(),
        user_card_ids=user_card_ids,
    )
    df = advisor.enrich_dataframe(transactions_df)
    # df now has: best_card_user, best_card_user_rate,
    #             best_card_market, best_card_market_rate
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Optional

import pandas as pd


@dataclass(frozen=True, slots=True)
class TransactionAdvice:
    """Best-card advice for a single transaction."""

    best_user_card_id: Optional[str]
    """card_id of the highest-earning card from the user's portfolio, or None."""

    best_user_card_name: Optional[str]
    """Display name of that card (short form for UI)."""

    best_user_earn_rate: float
    """Effective earn rate (₹ per ₹ spent) from the user's best card."""

    best_market_card_id: Optional[str]
    """card_id of the highest-earning card across ALL market cards, or None."""

    best_market_card_name: Optional[str]
    """Display name of the market-best card (short form for UI)."""

    best_market_earn_rate: float
    """Effective earn rate from the market-best card."""


def _short_name(card: dict) -> str:
    """Return a compact display name (issuer + card name without issuer prefix)."""
    issuer = card.get("issuer", "")
    name = card.get("name", card.get("id", ""))
    # Strip leading issuer words to keep it short
    for prefix in (issuer, issuer.replace(" Bank", ""), issuer.replace(" Card", "")):
        stripped = name.removeprefix(prefix).strip(" -–:")
        if stripped and stripped != name:
            return stripped
    return name


def _effective_earn_rate(card: dict, category: str, description: str) -> float:
    """Return the effective earn rate (₹/₹) for one card on a given transaction.

    Checks merchant overrides first; falls back to category rate, then Others.
    Excluded categories (e.g. "EMI & Loans", "Payments & Transfers") return 0.

    Parameters
    ----------
    card:
        A card definition dict as loaded by CardDB.
    category:
        Transaction category (must match config.yaml category keys).
    description:
        Raw transaction description string; used for merchant-keyword matching.
    """
    excluded: list[str] = card.get("excluded_categories") or []
    if category in excluded:
        return 0.0

    categories: dict = card.get("categories") or {}
    cat_def: dict = categories.get(category) or categories.get("Others") or {}
    if not cat_def:
        return 0.0

    base_rate: float = float(cat_def.get("earn_rate", 0.0))
    overrides: dict = cat_def.get("merchant_overrides") or {}

    if not overrides:
        return base_rate

    # Pick the highest-rate override whose keyword appears in the description
    desc_lower = description.lower()
    best_override_rate = base_rate
    for merchant_key, override_def in overrides.items():
        if not isinstance(override_def, dict):
            continue
        if merchant_key.lower() in desc_lower:
            rate = float(override_def.get("earn_rate", 0.0))
            if rate > best_override_rate:
                best_override_rate = rate

    return best_override_rate


class CardAdvisor:
    """Provides per-transaction best-card advice for two scopes: user cards and market cards.

    Parameters
    ----------
    all_cards:
        Full list of card dicts from CardDB.all_cards().
    user_card_ids:
        List of card_id strings the user actually owns.
        May be empty (in which case user-scope columns will be None/0.0).
    """

    def __init__(
        self,
        all_cards: list[dict],
        user_card_ids: list[str],
    ) -> None:
        self._all_cards: list[dict] = [c for c in all_cards if isinstance(c, dict)]
        _uid_set = set(user_card_ids or [])
        self._user_cards: list[dict] = [
            c for c in self._all_cards if c.get("id") in _uid_set
        ]
        # Short-name cache: card_id → short display name
        self._short: dict[str, str] = {c["id"]: _short_name(c) for c in self._all_cards}

    # ── Public API ────────────────────────────────────────────────

    def advise(self, category: str, description: str) -> TransactionAdvice:
        """Return the best card from each scope for this transaction.

        Parameters
        ----------
        category:
            Transaction category string.
        description:
            Raw transaction description.
        """
        best_u_card: dict | None = None
        best_u_rate = 0.0
        for card in self._user_cards:
            rate = _effective_earn_rate(card, category, description)
            if rate > best_u_rate:
                best_u_rate = rate
                best_u_card = card

        best_m_card: dict | None = None
        best_m_rate = 0.0
        for card in self._all_cards:
            rate = _effective_earn_rate(card, category, description)
            if rate > best_m_rate:
                best_m_rate = rate
                best_m_card = card

        return TransactionAdvice(
            best_user_card_id=best_u_card["id"] if best_u_card else None,
            best_user_card_name=self._short.get(best_u_card["id"]) if best_u_card else None,
            best_user_earn_rate=best_u_rate,
            best_market_card_id=best_m_card["id"] if best_m_card else None,
            best_market_card_name=self._short.get(best_m_card["id"]) if best_m_card else None,
            best_market_earn_rate=best_m_rate,
        )

    def enrich_dataframe(
        self,
        df: pd.DataFrame,
        category_col: str = "category",
        description_col: str = "description",
    ) -> pd.DataFrame:
        """Add best-card columns to a transactions DataFrame.

        Returns a copy of *df* with four additional columns:

        * ``best_card_user``         – short card name from user's portfolio
        * ``best_card_user_rate``    – earn rate (0.0–0.xx)
        * ``best_card_market``       – short card name from all market cards
        * ``best_card_market_rate``  – earn rate

        Rows with missing category/description are filled with empty strings.
        """
        if df.empty:
            out = df.copy()
            for col in ("best_card_user", "best_card_user_rate",
                        "best_card_market", "best_card_market_rate"):
                out[col] = None
            return out

        advise = self.advise  # local ref for speed

        user_names: list[str | None] = []
        user_rates: list[float] = []
        mkt_names: list[str | None] = []
        mkt_rates: list[float] = []

        for _, row in df.iterrows():
            cat = str(row.get(category_col) or "Others")
            desc = str(row.get(description_col) or "")
            a = advise(cat, desc)
            user_names.append(a.best_user_card_name)
            user_rates.append(a.best_user_earn_rate)
            mkt_names.append(a.best_market_card_name)
            mkt_rates.append(a.best_market_earn_rate)

        out = df.copy()
        out["best_card_user"]        = user_names
        out["best_card_user_rate"]   = user_rates
        out["best_card_market"]      = mkt_names
        out["best_card_market_rate"] = mkt_rates
        return out

    # ── Convenience properties ────────────────────────────────────

    @property
    def user_card_count(self) -> int:
        return len(self._user_cards)

    @property
    def market_card_count(self) -> int:
        return len(self._all_cards)

    def build_category_rate_table(self, card_ids: list[str] | None = None) -> pd.DataFrame:
        """Return a DataFrame of earn rates per card per category.

        Useful for displaying a comparison matrix in the dashboard.

        Columns: card_id, card_name, issuer, <category1>, <category2>, …
        """
        cards = (
            [c for c in self._all_cards if c.get("id") in set(card_ids)]
            if card_ids is not None
            else self._all_cards
        )
        if not cards:
            return pd.DataFrame()

        # Gather all category names from all cards
        all_categories: list[str] = []
        seen: set[str] = set()
        for card in cards:
            for cat in (card.get("categories") or {}):
                if cat not in seen and cat != "Others":
                    seen.add(cat)
                    all_categories.append(cat)
        all_categories.append("Others")

        rows = []
        for card in cards:
            row: dict = {
                "card_id": card.get("id", ""),
                "card_name": _short_name(card),
                "issuer": card.get("issuer", ""),
                "annual_fee": card.get("annual_fee", 0),
            }
            cats = card.get("categories") or {}
            for cat in all_categories:
                cat_def = cats.get(cat) or cats.get("Others") or {}
                row[cat] = float(cat_def.get("earn_rate", 0.0))
            rows.append(row)

        return pd.DataFrame(rows)
