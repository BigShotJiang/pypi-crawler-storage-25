"""Build per-category spend vectors from the existing SQLite database.

This module is READ-ONLY with respect to the database — it only queries,
never inserts or modifies any data.
"""

from __future__ import annotations

import re
from dataclasses import dataclass, field
from datetime import date, timedelta
from typing import Optional

import pandas as pd

from stmtforge.database.db import Database


# ── Merchant keyword map ──────────────────────────────────────────────────────
# Description keyword (lowercase, partial match) → canonical merchant name.
# These are used to populate SpendVector.merchants for merchant-specific
# card benefit matching in the reward engine.
_MERCHANT_KEYWORDS: list[tuple[str, str]] = [
    # Food delivery
    ("swiggy", "swiggy"),
    ("zomato", "zomato"),
    ("instamart", "instamart"),
    # Grocery
    ("blinkit", "blinkit"),
    ("bigbasket", "bigbasket"),
    ("grofers", "grofers"),
    ("zepto", "zepto"),
    ("jiomart", "jiomart"),
    # Shopping
    ("amazon", "amazon"),
    ("flipkart", "flipkart"),
    ("myntra", "myntra"),
    ("ajio", "ajio"),
    ("nykaa", "nykaa"),
    ("tata cliq", "tata"),
    ("tatacliq", "tata"),
    ("croma", "croma"),
    # Transport / ride
    ("uber", "uber"),
    ("ola cab", "ola"),
    ("rapido", "rapido"),
    # Fuel
    ("bpcl", "bpcl"),
    ("petrol", "petrol"),
    ("fuel", "fuel"),
    # Travel
    ("irctc", "irctc"),
    ("air india", "air india"),
    ("indigo", "indigo"),
    ("makemytrip", "makemytrip"),
    ("cleartrip", "cleartrip"),
    ("oyo", "oyo"),
    # Health
    ("1mg", "1mg"),
    ("pharmeasy", "pharmeasy"),
    ("apollo", "apollo"),
    # Entertainment
    ("bookmyshow", "bookmyshow"),
    ("pvr", "pvr"),
    ("inox", "inox"),
    ("netflix", "netflix"),
    ("hotstar", "hotstar"),
    ("spotify", "spotify"),
    # Utilities
    ("airtel", "airtel"),
    ("jio", "jio"),
    ("bsnl", "bsnl"),
    ("vodafone", "vodafone"),
    ("tata power", "tata power"),
    ("adani", "adani"),
    ("electricity", "electricity"),
    # Payments
    ("paytm", "paytm"),
    ("phonepe", "phonepe"),
    ("googlepay", "googlepay"),
    ("cred", "cred"),
]

# Pre-compiled patterns for performance (avoid recompiling per transaction)
_COMPILED_MERCHANTS: list[tuple[re.Pattern, str]] = [
    (re.compile(re.escape(kw), re.IGNORECASE), merchant)
    for kw, merchant in _MERCHANT_KEYWORDS
]


@dataclass
class SpendVector:
    """Per-category monthly average spend derived from real parsed transactions.

    All monetary values are in ₹ (Indian Rupees).

    Attributes
    ----------
    period_months : int
        Number of months of data analyzed.
    date_from : str
        Start date of the analysis window (YYYY-MM-DD).
    date_to : str
        End date of the analysis window (YYYY-MM-DD).
    transaction_count : int
        Total number of debit transactions analyzed.
    categories : dict[str, float]
        Category name → monthly average spend in ₹.
        Includes all config.yaml categories that had at least one transaction.
    merchants : dict[str, float]
        Canonical merchant name → monthly average spend in ₹.
        Only populated for known merchants defined in _MERCHANT_KEYWORDS.
    total_monthly_avg : float
        Total average monthly debit spend across all categories.
    """

    period_months: int
    date_from: str
    date_to: str
    transaction_count: int
    categories: dict[str, float] = field(default_factory=dict)
    merchants: dict[str, float] = field(default_factory=dict)
    total_monthly_avg: float = 0.0

    def category_spend(self, category: str) -> float:
        """Return monthly average spend for a category (0.0 if not present)."""
        return self.categories.get(category, 0.0)

    def merchant_spend(self, merchant_keyword: str) -> float:
        """Return monthly average spend matching a merchant keyword (case-insensitive).

        The keyword is matched against keys in ``self.merchants``.
        Returns 0.0 if no match.
        """
        kw_lower = merchant_keyword.lower()
        for merchant_name, amount in self.merchants.items():
            if kw_lower in merchant_name.lower():
                return amount
        return 0.0

    def as_dict(self) -> dict:
        """Serialise to a plain dict (for JSON export / dashboard display)."""
        return {
            "period_months": self.period_months,
            "date_from": self.date_from,
            "date_to": self.date_to,
            "transaction_count": self.transaction_count,
            "total_monthly_avg": round(self.total_monthly_avg, 2),
            "categories": {k: round(v, 2) for k, v in self.categories.items()},
            "merchants": {k: round(v, 2) for k, v in self.merchants.items()},
        }


def _extract_merchant(description: str) -> Optional[str]:
    """Return the first matching canonical merchant name, or None."""
    for pattern, merchant in _COMPILED_MERCHANTS:
        if pattern.search(description):
            return merchant
    return None


def build_spend_vector(
    db: Database,
    months: int = 6,
    card_names: Optional[list[str]] = None,
    banks: Optional[list[str]] = None,
) -> SpendVector:
    """Query the database and build a SpendVector for the given period.

    Parameters
    ----------
    db:
        An initialised :class:`~stmtforge.database.db.Database` instance.
    months:
        Number of months to look back from today.
    card_names:
        Optional list of card names to restrict analysis to (e.g. ``["Swiggy"]``).
        If None, all cards are included.
    banks:
        Optional list of bank names to restrict analysis to (e.g. ``["hdfc"]``).
        If None, all banks are included.

    Returns
    -------
    SpendVector
        Contains per-category and per-merchant monthly average spend.
    """
    today = date.today()
    date_from = (today - timedelta(days=months * 30)).strftime("%Y-%m-%d")
    date_to = today.strftime("%Y-%m-%d")

    filters: dict = {
        "type": "debit",
        "date_from": date_from,
        "date_to": date_to,
    }
    if card_names:
        filters["card_name"] = card_names
    if banks:
        filters["bank"] = banks

    df = db.get_transactions(filters=filters)

    if df.empty:
        return SpendVector(
            period_months=months,
            date_from=date_from,
            date_to=date_to,
            transaction_count=0,
        )

    # ── Per-category monthly averages ─────────────────────────────────────────
    cat_totals: dict[str, float] = (
        df.groupby("category")["amount"].sum().to_dict()
    )
    cat_monthly: dict[str, float] = {
        cat: total / months for cat, total in cat_totals.items()
    }

    # ── Per-merchant monthly averages ─────────────────────────────────────────
    merchant_totals: dict[str, float] = {}
    for _, row in df.iterrows():
        merchant = _extract_merchant(str(row.get("description", "")))
        if merchant:
            merchant_totals[merchant] = merchant_totals.get(merchant, 0.0) + float(row["amount"])

    merchant_monthly: dict[str, float] = {
        m: total / months for m, total in merchant_totals.items()
    }

    total_monthly = sum(cat_monthly.values())

    return SpendVector(
        period_months=months,
        date_from=date_from,
        date_to=date_to,
        transaction_count=len(df),
        categories=cat_monthly,
        merchants=merchant_monthly,
        total_monthly_avg=total_monthly,
    )


def build_spend_vector_from_df(df: pd.DataFrame, months: int) -> SpendVector:
    """Build a SpendVector directly from a transactions DataFrame.

    Useful for testing without a live database, or for building vectors
    from pre-filtered dataframes.

    Parameters
    ----------
    df:
        A DataFrame with columns: date, description, amount, type, category.
        Only rows with type == 'debit' are used.
    months:
        Number of months to divide totals by to get monthly averages.
    """
    debits = df[df["type"] == "debit"] if "type" in df.columns else df

    if debits.empty:
        date_from = date_to = date.today().strftime("%Y-%m-%d")
        return SpendVector(period_months=months, date_from=date_from,
                           date_to=date_to, transaction_count=0)

    date_from = str(debits["date"].min()) if "date" in debits.columns else ""
    date_to = str(debits["date"].max()) if "date" in debits.columns else ""

    cat_totals: dict[str, float] = (
        debits.groupby("category")["amount"].sum().to_dict()
        if "category" in debits.columns else {}
    )
    cat_monthly = {cat: total / months for cat, total in cat_totals.items()}

    merchant_totals: dict[str, float] = {}
    for _, row in debits.iterrows():
        merchant = _extract_merchant(str(row.get("description", "")))
        if merchant:
            merchant_totals[merchant] = merchant_totals.get(merchant, 0.0) + float(row["amount"])
    merchant_monthly = {m: total / months for m, total in merchant_totals.items()}

    return SpendVector(
        period_months=months,
        date_from=date_from,
        date_to=date_to,
        transaction_count=len(debits),
        categories=cat_monthly,
        merchants=merchant_monthly,
        total_monthly_avg=sum(cat_monthly.values()),
    )
