"""Card portfolio optimizer.

Ranks all cards in the database by expected net annual value for a given
SpendVector, and optionally finds the best two-card combination.

The key public interface is:
  - ``rank_cards(spend_vector, card_db, ...)`` → list[CardRecommendation]
  - ``best_two_card_combo(spend_vector, card_db, ...)`` → TwoCardCombo
"""

from __future__ import annotations

import itertools
from dataclasses import dataclass, field

from stmtforge.suggestor.card_db import CardDB
from stmtforge.suggestor.engine import RewardResult, compute_reward
from stmtforge.suggestor.spend_vector import SpendVector


@dataclass
class CardRecommendation:
    """A ranked card recommendation with human-readable rationale.

    Attributes
    ----------
    rank : int
        1-based rank (1 = best value card for this spend profile).
    result : RewardResult
        Full reward computation result (contains all category/milestone detail).
    vs_no_card : float
        How much better (₹/year) vs having no card at all.
    why : list[str]
        Short bullets explaining *why* this card ranks well, e.g.
        ``["5% cashback on Amazon (₹3,600/yr)", "Fee waived at ₹2L spend"]``.
    caveats : list[str]
        Warnings from the engine (caps hit, fee not waived, etc.).
    """
    rank: int
    result: RewardResult
    vs_no_card: float
    why: list[str] = field(default_factory=list)
    caveats: list[str] = field(default_factory=list)

    # Convenience aliases for easy access in templates/dashboard
    @property
    def card_id(self) -> str:
        return self.result.card_id

    @property
    def card_name(self) -> str:
        return self.result.card_name

    @property
    def issuer(self) -> str:
        return self.result.issuer

    @property
    def annual_fee(self) -> int:
        return self.result.annual_fee

    @property
    def net_annual_value(self) -> float:
        return self.result.net_annual_value


@dataclass
class TwoCardCombo:
    """Best two-card combination and the combined net annual value."""
    card_a: CardRecommendation
    card_b: CardRecommendation
    combined_net_annual_value: float
    vs_best_single: float   # extra value vs the single best card
    rationale: list[str]


def _build_why(result: RewardResult) -> list[str]:
    """Generate short bullet points explaining why a card is recommended."""
    why: list[str] = []

    # Top two earning categories
    for cb in result.category_breakdowns[:2]:
        if cb.annual_reward > 0:
            line = f"{cb.raw_label} on {cb.category} (₹{cb.annual_reward:,.0f}/yr)"
            if cb.matched_merchant:
                line = f"{cb.raw_label} on {cb.matched_merchant.title()} (₹{cb.annual_reward:,.0f}/yr)"
            why.append(line)

    # Fee waiver
    if result.fee_waived and result.annual_fee > 0:
        why.append(f"Annual fee ₹{result.annual_fee} waived (based on your spend)")
    elif result.annual_fee == 0:
        why.append("Lifetime free card — zero annual cost")

    # Milestones achieved
    for ms in result.milestone_breakdowns:
        if ms.achieved:
            why.append(f"{ms.description} (₹{ms.bonus_value_inr:,.0f} bonus)")

    return why or ["Broad base rewards on your spending pattern"]


def rank_cards(
    spend_vector: SpendVector,
    card_db: CardDB,
    *,
    max_fee: int | None = None,
    goal: str | None = None,
    free_only: bool = False,
    top_n: int = 10,
) -> list[CardRecommendation]:
    """Rank all cards in the DB by net annual value for this spend profile.

    Parameters
    ----------
    spend_vector:
        User spend profile built by :func:`~stmtforge.suggestor.spend_vector.build_spend_vector`.
    card_db:
        Loaded :class:`~stmtforge.suggestor.card_db.CardDB` instance.
    max_fee:
        Only include cards whose annual fee is ≤ this value (₹).
        Ignored when ``None``.
    goal:
        Optional filter: ``"cashback"``, ``"travel"``, ``"lounge"``, or ``None``
        (any/all). Filters card tags if the card YAML contains a ``tags`` list.
    free_only:
        If True, only include lifetime-free cards (annual_fee == 0).
    top_n:
        Return at most this many recommendations.

    Returns
    -------
    list[CardRecommendation]
        Sorted best-first by net_annual_value.
    """
    candidate_cards = card_db.all_cards()

    # Apply pre-computation filters
    if free_only:
        candidate_cards = [c for c in candidate_cards if c.get("annual_fee", 0) == 0]
    elif max_fee is not None:
        candidate_cards = [c for c in candidate_cards if c.get("annual_fee", 0) <= max_fee]

    if goal and goal != "any":
        candidate_cards = [
            c for c in candidate_cards
            if goal.lower() in [t.lower() for t in (c.get("tags") or [])]
        ]

    results: list[RewardResult] = [
        compute_reward(card, spend_vector) for card in candidate_cards
    ]

    # Sort by net annual value descending
    results.sort(key=lambda r: r.net_annual_value, reverse=True)

    recommendations: list[CardRecommendation] = []
    for rank, result in enumerate(results[:top_n], start=1):
        why = _build_why(result)
        recommendations.append(CardRecommendation(
            rank=rank,
            result=result,
            vs_no_card=result.net_annual_value,
            why=why,
            caveats=result.caveats,
        ))

    return recommendations


def best_two_card_combo(
    spend_vector: SpendVector,
    card_db: CardDB,
    *,
    max_fee_per_card: int | None = None,
    free_only: bool = False,
    top_n_candidates: int = 20,
) -> TwoCardCombo | None:
    """Find the best pair of complementary cards to maximise total net value.

    The algorithm uses an additive model: for each spending category the higher
    of the two cards' earn rates is applied (the user would use whichever card
    earns more for that category).  Fees for both cards are subtracted.

    Parameters
    ----------
    spend_vector:
        User spend profile.
    card_db:
        Loaded card DB.
    max_fee_per_card:
        Cap on annual fee for each individual card in the combo.
    free_only:
        Restrict to lifetime-free cards only.
    top_n_candidates:
        Number of top single-card candidates to form pairs from (controls
        combinatorial explosion; default 20 = at most 190 pairs evaluated).

    Returns
    -------
    TwoCardCombo or None (if fewer than 2 candidate cards exist).
    """
    # First get the top N individual cards to bound the search space
    single_rankings = rank_cards(
        spend_vector, card_db,
        max_fee=max_fee_per_card, free_only=free_only,
        top_n=top_n_candidates,
    )
    if len(single_rankings) < 2:
        return None

    best_single_value = single_rankings[0].net_annual_value

    best_combo: TwoCardCombo | None = None

    for rec_a, rec_b in itertools.combinations(single_rankings, 2):
        combined = _compute_combined_value(rec_a.result, rec_b.result, spend_vector)
        if best_combo is None or combined > best_combo.combined_net_annual_value:
            rationale = _combo_rationale(rec_a, rec_b, spend_vector)
            best_combo = TwoCardCombo(
                card_a=rec_a,
                card_b=rec_b,
                combined_net_annual_value=combined,
                vs_best_single=combined - best_single_value,
                rationale=rationale,
            )

    return best_combo


def _compute_combined_value(
    result_a: RewardResult,
    result_b: RewardResult,
    spend_vector: SpendVector,
) -> float:
    """Additive two-card model: best rate per category, both fees subtracted.

    For each category, apply the higher earn rate (the user will swipe whichever
    card earns more).  Then subtract both effective fees.
    """
    # Build category→annual_reward maps
    a_cat = {cb.category: (cb.earn_rate, cb.cap_monthly_inr) for cb in result_a.category_breakdowns}
    b_cat = {cb.category: (cb.earn_rate, cb.cap_monthly_inr) for cb in result_b.category_breakdowns}

    all_cats = set(a_cat) | set(b_cat)
    gross = 0.0

    for cat in all_cats:
        monthly_spend = spend_vector.category_spend(cat)
        if monthly_spend <= 0:
            continue

        a_rate, a_cap = a_cat.get(cat, (0.0, None))
        b_rate, b_cap = b_cat.get(cat, (0.0, None))

        if a_rate >= b_rate:
            earn_rate, cap = a_rate, a_cap
        else:
            earn_rate, cap = b_rate, b_cap

        monthly_uncapped = monthly_spend * earn_rate
        monthly_reward = min(monthly_uncapped, cap) if cap is not None else monthly_uncapped
        gross += monthly_reward * 12

    # Add milestone bonuses (both cards)
    for ms in result_a.milestone_breakdowns:
        if ms.achieved:
            gross += ms.bonus_value_inr
    for ms in result_b.milestone_breakdowns:
        if ms.achieved:
            gross += ms.bonus_value_inr

    # Subtract both effective fees
    gross -= result_a.effective_fee + result_b.effective_fee
    return gross


def _combo_rationale(
    rec_a: CardRecommendation,
    rec_b: CardRecommendation,
    spend_vector: SpendVector,
) -> list[str]:
    """Generate short rationale bullets for a two-card combination."""
    a_cats = {cb.category for cb in rec_a.result.category_breakdowns if cb.annual_reward > 100}
    b_cats = {cb.category for cb in rec_b.result.category_breakdowns if cb.annual_reward > 100}

    overlap = a_cats & b_cats
    a_only = a_cats - b_cats
    b_only = b_cats - a_cats

    lines: list[str] = []
    if a_only:
        lines.append(f"{rec_a.card_name} excels at: {', '.join(sorted(a_only))}")
    if b_only:
        lines.append(f"{rec_b.card_name} excels at: {', '.join(sorted(b_only))}")
    if overlap:
        lines.append(f"Both cover: {', '.join(sorted(overlap))} (use the higher-rate card)")
    return lines or ["Complementary spending categories covered"]


# ── N-Card Portfolio ──────────────────────────────────────────────────────────

@dataclass
class NCardPortfolio:
    """Optimal N-card portfolio and its combined net annual value.

    Attributes
    ----------
    cards:
        Ordered list of CardRecommendations (added greedily; first = highest
        standalone value, subsequent = highest marginal contributors).
    combined_net_annual_value:
        Total net annual value across all N cards (additive model; for each
        category the card with the highest earn rate is used).
    vs_best_single:
        Extra value the full N-card portfolio delivers beyond the single best card.
    rationale:
        Human-readable bullets explaining the composition.
    category_allocation:
        dict mapping category → card_name (the card in the portfolio that earns
        most for that category).
    """
    cards: list[CardRecommendation]
    combined_net_annual_value: float
    vs_best_single: float
    rationale: list[str]
    category_allocation: dict[str, str]


def _compute_portfolio_value(
    results: list[RewardResult],
    spend_vector: SpendVector,
) -> float:
    """Additive model: best rate per category across N cards, minus all fees.

    For each category, the highest earn rate among all *results* is applied.
    """
    # Build per-category best (rate, cap) across all cards in portfolio
    best: dict[str, tuple[float, float | None]] = {}
    for res in results:
        for cb in res.category_breakdowns:
            prev_rate, _ = best.get(cb.category, (0.0, None))
            if cb.earn_rate > prev_rate:
                best[cb.category] = (cb.earn_rate, cb.cap_monthly_inr)

    gross = 0.0
    for cat, (earn_rate, cap) in best.items():
        monthly_spend = spend_vector.category_spend(cat)
        if monthly_spend <= 0 or earn_rate <= 0:
            continue
        uncapped = monthly_spend * earn_rate
        monthly = min(uncapped, cap) if cap is not None else uncapped
        gross += monthly * 12

    # Add milestones
    for res in results:
        for ms in res.milestone_breakdowns:
            if ms.achieved:
                gross += ms.bonus_value_inr

    # Subtract all fees
    for res in results:
        gross -= res.effective_fee

    return gross


def _build_category_allocation(
    results: list[RewardResult],
) -> dict[str, str]:
    """Map each category to the card name that earns the most for it."""
    best_rate: dict[str, float] = {}
    best_name: dict[str, str] = {}
    for res in results:
        for cb in res.category_breakdowns:
            if cb.earn_rate > best_rate.get(cb.category, 0.0):
                best_rate[cb.category] = cb.earn_rate
                best_name[cb.category] = res.card_name
    return best_name


def best_n_card_combo(
    spend_vector: SpendVector,
    card_db: CardDB,
    n: int = 3,
    *,
    max_fee_per_card: int | None = None,
    free_only: bool = False,
    card_ids: list[str] | None = None,
) -> NCardPortfolio | None:
    """Find the best N-card portfolio using a greedy marginal-value algorithm.

    Algorithm
    ---------
    1. Evaluate all candidate cards individually against the spend vector.
    2. Greedily add the card that contributes the most *marginal* annual value
       to the current portfolio at each step, until N cards are selected.
    3. The marginal value is: combined_value(portfolio ∪ {card}) − combined_value(portfolio).

    This is O(N × M) in the number of candidates M, which is fast enough for
    typical card databases (< 30 cards).

    Parameters
    ----------
    spend_vector:
        User spend profile built by build_spend_vector().
    card_db:
        Loaded CardDB instance.
    n:
        Portfolio size (1–10 recommended).
    max_fee_per_card:
        Optional maximum annual fee for each card in the portfolio.
    free_only:
        If True, restrict to zero-annual-fee cards.
    card_ids:
        If provided, only consider cards whose card_id is in this list.
        Overrides max_fee_per_card / free_only filters when supplied.

    Returns
    -------
    NCardPortfolio or None if fewer than *n* candidate cards are available.
    """
    n = max(1, n)

    # Determine candidate pool
    if card_ids is not None:
        candidates = [c for c in card_db.all_cards() if c.get("id") in set(card_ids)]
    else:
        candidates = card_db.all_cards()
        if free_only:
            candidates = [c for c in candidates if c.get("annual_fee", 0) == 0]
        elif max_fee_per_card is not None:
            candidates = [c for c in candidates if c.get("annual_fee", 0) <= max_fee_per_card]

    if not candidates:
        return None

    # Pre-compute all reward results
    all_results: dict[str, RewardResult] = {
        c["id"]: compute_reward(c, spend_vector) for c in candidates
    }

    # Step 1 — greedy selection
    selected_ids: list[str] = []
    selected_results: list[RewardResult] = []
    remaining_ids = list(all_results.keys())

    current_value = 0.0

    for _ in range(min(n, len(candidates))):
        best_id: str | None = None
        best_marginal = float("-inf")

        for cid in remaining_ids:
            tentative = selected_results + [all_results[cid]]
            val = _compute_portfolio_value(tentative, spend_vector)
            marginal = val - current_value
            if marginal > best_marginal:
                best_marginal = marginal
                best_id = cid

        if best_id is None:
            break

        selected_ids.append(best_id)
        selected_results.append(all_results[best_id])
        remaining_ids.remove(best_id)
        current_value = _compute_portfolio_value(selected_results, spend_vector)

    if not selected_ids:
        return None

    best_single_value = _compute_portfolio_value([selected_results[0]], spend_vector)

    # Build CardRecommendation objects
    recs: list[CardRecommendation] = []
    for rank, (cid, res) in enumerate(zip(selected_ids, selected_results), start=1):
        recs.append(CardRecommendation(
            rank=rank,
            result=res,
            vs_no_card=res.net_annual_value,
            why=_build_why(res),
            caveats=res.caveats,
        ))

    allocation = _build_category_allocation(selected_results)

    # Build rationale
    rationale: list[str] = []
    for cat, cname in sorted(allocation.items()):
        spend = spend_vector.category_spend(cat)
        if spend > 0:
            rationale.append(f"{cat}: use **{cname}**")

    return NCardPortfolio(
        cards=recs,
        combined_net_annual_value=current_value,
        vs_best_single=current_value - best_single_value,
        rationale=rationale,
        category_allocation=allocation,
    )
