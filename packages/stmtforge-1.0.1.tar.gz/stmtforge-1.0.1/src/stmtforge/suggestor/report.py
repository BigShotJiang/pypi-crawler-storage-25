"""Report formatters for card recommendations.

Provides:
  - ``format_cli_table`` — pretty terminal table using ``tabulate``
  - ``format_spend_summary`` — one-liner spend profile summary
  - ``export_html_report`` — full self-contained HTML report
"""

from __future__ import annotations

import html
import json
from pathlib import Path

from stmtforge.suggestor.optimizer import CardRecommendation, TwoCardCombo
from stmtforge.suggestor.spend_vector import SpendVector


# ── Disclaimer ────────────────────────────────────────────────────────────────

DISCLAIMER = (
    "\n"
    "─" * 72 + "\n"
    "DISCLAIMER: Card benefits are subject to change. Verify with the issuer\n"
    "before applying. Last verified dates indicate data freshness. This tool\n"
    "earns NO referral fees from card approvals.\n"
    "─" * 72
)

_HTML_DISCLAIMER = """
<div class="disclaimer">
  <strong>⚠ Disclaimer</strong>: Card benefits are subject to change.
  Verify terms with the issuer before applying. Last verified dates indicate
  data freshness. <strong>This tool earns no referral fees from card approvals.</strong>
</div>
"""

def format_cli_table(
    recommendations: list[CardRecommendation],
    spend_vector: SpendVector,
) -> str:
    """Return a formatted text table of top recommendations.

    Uses ``tabulate`` if available; falls back to simple aligned columns.
    """
    if not recommendations:
        return "No cards matched the given criteria."

    headers = ["Rank", "Card", "Issuer", "Fee (₹)", "Gross/yr (₹)", "Net/yr (₹)", "Fee Waived?"]
    rows = []
    for rec in recommendations:
        r = rec.result
        rows.append([
            f"#{rec.rank}",
            r.card_name,
            r.issuer,
            f"{r.annual_fee:,}",
            f"{r.gross_annual_reward:,.0f}",
            f"{r.net_annual_value:,.0f}",
            "✓" if r.fee_waived else ("–" if r.annual_fee == 0 else "✗"),
        ])

    try:
        from tabulate import tabulate  # type: ignore
        table = tabulate(rows, headers=headers, tablefmt="rounded_outline")
    except ImportError:
        # Simple fallback
        col_widths = [max(len(str(r[i])) for r in ([headers] + rows)) for i in range(len(headers))]
        sep = "  ".join("-" * w for w in col_widths)
        lines = ["  ".join(str(h).ljust(col_widths[i]) for i, h in enumerate(headers)), sep]
        for row in rows:
            lines.append("  ".join(str(v).ljust(col_widths[i]) for i, v in enumerate(row)))
        table = "\n".join(lines)

    spend_line = format_spend_summary(spend_vector)
    return f"{spend_line}\n\n{table}\n{DISCLAIMER}\n"


def format_spend_summary(spend_vector: SpendVector) -> str:
    """Return a one-line summary of the spend profile."""
    period = f"{spend_vector.date_from} → {spend_vector.date_to}"
    total = spend_vector.total_monthly_avg
    top_cats = sorted(spend_vector.categories.items(), key=lambda x: x[1], reverse=True)[:3]
    cats_str = ", ".join(f"{cat} ₹{amt:,.0f}/mo" for cat, amt in top_cats)
    return (
        f"Spend profile: {period} | "
        f"Monthly avg ₹{total:,.0f} | "
        f"Top: {cats_str or 'no spend data'}"
    )


def format_why_bullets(rec: CardRecommendation) -> str:
    """Return a multi-line why/caveat string for a recommendation."""
    lines = []
    for bullet in rec.why:
        lines.append(f"  + {bullet}")
    for caveat in rec.caveats:
        lines.append(f"  ! {caveat}")
    return "\n".join(lines) if lines else "  (no details)"


def format_combo_summary(combo: TwoCardCombo) -> str:
    """Return a short text summary of a two-card combo recommendation."""
    lines = [
        f"Best 2-card combo: {combo.card_a.card_name} + {combo.card_b.card_name}",
        f"  Combined net value : ₹{combo.combined_net_annual_value:,.0f}/year",
        f"  vs best single card: +₹{combo.vs_best_single:,.0f}/year",
    ]
    for r in combo.rationale:
        lines.append(f"  → {r}")
    return "\n".join(lines)


# ── HTML report ──────────────────────────────────────────────────────────────

def export_html_report(
    recommendations: list[CardRecommendation],
    spend_vector: SpendVector,
    output_path: str | Path,
    combo: TwoCardCombo | None = None,
) -> None:
    """Write a self-contained HTML report to *output_path*.

    The report includes:
    - Spend profile summary
    - Ranked recommendations table with expandable per-card detail
    - Optional two-card combo recommendation
    """
    output_path = Path(output_path)
    output_path.parent.mkdir(parents=True, exist_ok=True)

    rows_html = _render_recommendation_rows(recommendations)
    spend_html = _render_spend_table(spend_vector)
    combo_html = _render_combo_section(combo) if combo else ""

    html_content = _HTML_TEMPLATE.format(
        title="Credit Card Recommendation Report",
        spend_summary=html.escape(format_spend_summary(spend_vector)),
        spend_table=spend_html,
        recommendation_rows=rows_html,
        combo_section=combo_html,
        disclaimer=_HTML_DISCLAIMER,
        date_from=html.escape(spend_vector.date_from),
        date_to=html.escape(spend_vector.date_to),
        period_months=spend_vector.period_months,
        total_monthly=f"{spend_vector.total_monthly_avg:,.0f}",
    )
    output_path.write_text(html_content, encoding="utf-8")


def _render_recommendation_rows(recommendations: list[CardRecommendation]) -> str:
    rows = []
    for rec in recommendations:
        r = rec.result
        fee_badge = (
            '<span class="badge free">FREE</span>'
            if r.annual_fee == 0
            else (
                '<span class="badge waived">WAIVED</span>'
                if r.fee_waived
                else f"₹{r.annual_fee:,}"
            )
        )
        why_html = "<ul>" + "".join(
            f"<li>{html.escape(b)}</li>" for b in rec.why
        ) + "</ul>"
        caveat_html = ""
        if rec.caveats:
            caveat_html = '<div class="caveats"><ul>' + "".join(
                f"<li>⚠ {html.escape(c)}</li>" for c in rec.caveats
            ) + "</ul></div>"

        cat_rows = "".join(
            f"<tr><td>{html.escape(cb.category)}</td>"
            f"<td>₹{cb.monthly_spend:,.0f}</td>"
            f"<td>{html.escape(cb.raw_label)}</td>"
            f"<td>₹{cb.annual_reward:,.0f}</td>"
            f"<td>{'⚠ capped' if cb.is_capped else '—'}</td></tr>"
            for cb in r.category_breakdowns
        )

        rows.append(f"""
        <tr class="summary-row" onclick="toggleDetail('detail-{rec.card_id}')">
          <td>#{rec.rank}</td>
          <td><strong>{html.escape(r.card_name)}</strong></td>
          <td>{html.escape(r.issuer)}</td>
          <td>{fee_badge}</td>
          <td>₹{r.gross_annual_reward:,.0f}</td>
          <td class="net-value">₹{r.net_annual_value:,.0f}</td>
          <td>{'▼ details' if r.category_breakdowns else ''}</td>
        </tr>
        <tr class="detail-row" id="detail-{rec.card_id}" style="display:none;">
          <td colspan="7">
            {why_html}
            {caveat_html}
            <table class="inner-table">
              <thead><tr>
                <th>Category</th><th>Monthly Spend</th>
                <th>Earn Rate</th><th>Annual Reward</th><th>Notes</th>
              </tr></thead>
              <tbody>{cat_rows}</tbody>
            </table>
          </td>
        </tr>""")
    return "\n".join(rows)


def _render_spend_table(sv: SpendVector) -> str:
    rows = "".join(
        f"<tr><td>{html.escape(cat)}</td><td>₹{amt:,.0f}/mo</td>"
        f"<td>₹{amt * 12:,.0f}/yr</td></tr>"
        for cat, amt in sorted(sv.categories.items(), key=lambda x: x[1], reverse=True)
        if amt > 0
    )
    return f"""<table class="spend-table">
      <thead><tr><th>Category</th><th>Monthly Avg</th><th>Annual Est.</th></tr></thead>
      <tbody>{rows}</tbody>
    </table>"""


def _render_combo_section(combo: TwoCardCombo) -> str:
    esc = html.escape
    rationale_html = "".join(f"<li>{esc(r)}</li>" for r in combo.rationale)
    return f"""
    <div class="combo-box">
      <h2>Best 2-Card Combo</h2>
      <p><strong>{esc(combo.card_a.card_name)}</strong> +
         <strong>{esc(combo.card_b.card_name)}</strong></p>
      <table class="combo-stats">
        <tr><td>Combined net value</td>
            <td><strong>₹{combo.combined_net_annual_value:,.0f}/year</strong></td></tr>
        <tr><td>Extra vs best single card</td>
            <td>+₹{combo.vs_best_single:,.0f}/year</td></tr>
      </table>
      <ul>{rationale_html}</ul>
    </div>"""


_HTML_TEMPLATE = """<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>{title}</title>
<style>
  body {{ font-family: system-ui, sans-serif; max-width: 1100px; margin: 2rem auto;
         padding: 0 1rem; color: #1a1a2e; background: #f0f4f8; }}
  h1 {{ color: #4a90d9; }}
  .meta {{ background:#e8f0fe; border-left:4px solid #4a90d9;
           padding:.6rem 1rem; border-radius:4px; margin-bottom:1.5rem; font-size:.9rem; }}
  table {{ border-collapse:collapse; width:100%; margin-bottom:1rem; }}
  th {{ background:#4a90d9; color:#fff; padding:.5rem .8rem; text-align:left; }}
  td {{ padding:.45rem .8rem; border-bottom:1px solid #d1dce8; }}
  .summary-row:hover {{ background:#dbeafe; cursor:pointer; }}
  .net-value {{ font-weight:700; color:#166534; }}
  .detail-row td {{ background:#f8fafc; padding:1rem; }}
  .inner-table {{ font-size:.85rem; margin-top:.5rem; }}
  .inner-table th {{ background:#94a3b8; }}
  .caveats {{ color:#92400e; background:#fef3c7; border-left:3px solid #f59e0b;
             padding:.4rem .8rem; margin:.4rem 0; border-radius:3px; }}
  .badge {{ padding:.15rem .45rem; border-radius:3px; font-size:.75rem; font-weight:700; }}
  .badge.free {{ background:#d1fae5; color:#065f46; }}
  .badge.waived {{ background:#dbeafe; color:#1e40af; }}
  .spend-table {{ font-size:.9rem; margin-bottom:2rem; }}
  .combo-box {{ background:#f0fdf4; border:2px solid #22c55e;
               padding:1rem 1.5rem; border-radius:8px; margin-top:2rem; }}
  .combo-stats td {{ border:none; padding:.2rem .5rem; }}
  section {{ background:#fff; padding:1.5rem; border-radius:8px;
            box-shadow:0 1px 4px rgba(0,0,0,.08); margin-bottom:1.5rem; }}
  .disclaimer {{ background:#fff7ed; border-left:4px solid #f97316;
               padding:.6rem 1rem; border-radius:4px; margin-bottom:1rem;
               font-size:.85rem; color:#7c2d12; }}
</style>
<script>
function toggleDetail(id) {{
  var el = document.getElementById(id);
  el.style.display = el.style.display === 'none' ? 'table-row' : 'none';
}}
</script>
</head>
<body>
<h1>Credit Card Recommendation Report</h1>
<div class="meta">
  Analysis period: {date_from} → {date_to} ({period_months} months) |
  Monthly spend: ₹{total_monthly}
</div>

<section>
  <h2>Spend Profile</h2>
  {spend_table}
</section>

<section>
  <h2>Top Card Recommendations</h2>
  {disclaimer}
  <p style="font-size:.85rem;color:#6b7280">Click a row to expand category-level detail.</p>
  <table>
    <thead>
      <tr>
        <th>#</th><th>Card</th><th>Issuer</th>
        <th>Annual Fee</th><th>Gross Reward/yr</th><th>Net Value/yr</th><th></th>
      </tr>
    </thead>
    <tbody>
      {recommendation_rows}
    </tbody>
  </table>
</section>

{combo_section}

<footer style="text-align:center;font-size:.75rem;color:#9ca3af;margin-top:2rem;">
  Generated by StmtForge Suggestor · Estimates based on historical spend data.
  Verify card benefits with the respective issuer before applying.
</footer>
</body>
</html>"""
