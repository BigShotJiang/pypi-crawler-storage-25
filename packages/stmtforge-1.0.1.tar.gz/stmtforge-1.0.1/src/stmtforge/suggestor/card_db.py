"""Card benefits database loader and query interface."""

from __future__ import annotations

import os
from pathlib import Path
from typing import Optional
import yaml


# ── Required fields every card YAML must have ────────────────────────────────
_REQUIRED_FIELDS = {"id", "issuer", "name", "network", "annual_fee", "joining_fee",
                    "reward_currency", "reward_unit_value", "categories"}
_REQUIRED_CATEGORY_FIELDS = {"earn_rate", "raw"}
_VALID_NETWORKS = {"Visa", "Mastercard", "RuPay", "Amex", "Diners"}
_VALID_CURRENCIES = {"cashback", "points", "miles", "neucoins", "coins"}


def _bundled_cards_dir() -> Path:
    """Return the path to the card YAMLs bundled inside the installed package."""
    return Path(__file__).parent.parent / "data" / "cards"


def _default_cards_dir() -> Path:
    """Resolve the cards directory.

    Resolution order:
      1. STMTFORGE_CARDS_DIR environment variable (explicit override)
      2. data/cards/ relative to STMTFORGE_PROJECT_DIR (if set)
      3. data/cards/ relative to current working directory
            4. Cards bundled inside the installed package (offline fallback)
    """
    env_override = os.getenv("STMTFORGE_CARDS_DIR", "").strip()
    if env_override:
        return Path(env_override).resolve()

    project_dir = os.getenv("STMTFORGE_PROJECT_DIR", "").strip()
    if project_dir:
        return Path(project_dir).resolve() / "data" / "cards"

    local = Path.cwd() / "data" / "cards"
    if local.exists():
        return local

    bundled = _bundled_cards_dir()
    if bundled.exists():
        return bundled

    return local  # will raise FileNotFoundError with a helpful message in __init__


class CardDB:
    """Loads, validates, and queries the card benefits YAML database.

    All card YAML files in the cards directory (excluding files starting with '_')
    are loaded at construction time. The loaded data is immutable after construction.

    Example
    -------
    >>> db = CardDB()
    >>> cards = db.all_cards()
    >>> card = db.get_card("axis_ace")
    >>> sbi_cards = db.cards_for_issuer("SBI Card")
    """

    def __init__(self, cards_dir: Optional[Path | str] = None):
        """Load all card YAML files from the given directory.

        Parameters
        ----------
        cards_dir:
            Path to the directory containing card YAML files.
            Defaults to the active project ``data/cards/`` folder,
            then the bundled copy shipped with stmtforge.
        """
        self._dir = Path(cards_dir) if cards_dir else _default_cards_dir()
        if not self._dir.exists():
            raise FileNotFoundError(
                f"Card DB directory not found: {self._dir}\n"
                f"Run 'stmtforge init' to set up your project directory, or\n"
                f"set STMTFORGE_CARDS_DIR environment variable to the cards directory."
            )
        self._cards: dict[str, dict] = {}
        self._point_values: dict[str, float] = {}
        self._load()

    # ── Loading ───────────────────────────────────────────────────────────────

    def _load(self) -> None:
        """Load all card YAML files and point values."""
        pv_path = self._dir / "_point_values.yaml"
        if pv_path.exists():
            with open(pv_path, "r", encoding="utf-8") as f:
                raw = yaml.safe_load(f) or {}
            self._point_values = {k: float(v) for k, v in raw.items()
                                  if not isinstance(v, str)}

        for path in sorted(self._dir.glob("*.yaml")):
            if path.stem.startswith("_"):
                continue
            with open(path, "r", encoding="utf-8") as f:
                data = yaml.safe_load(f)
            if not isinstance(data, dict):
                continue
            card_id = data.get("id") or path.stem
            data.setdefault("id", card_id)
            self._cards[card_id] = data

    # ── Queries ───────────────────────────────────────────────────────────────

    def all_cards(self) -> list[dict]:
        """Return all loaded card definitions as a list."""
        return list(self._cards.values())

    def get_card(self, card_id: str) -> Optional[dict]:
        """Return a card definition by ID, or None if not found."""
        return self._cards.get(card_id)

    def cards_for_issuer(self, issuer: str) -> list[dict]:
        """Return all cards for a given issuer (case-insensitive)."""
        issuer_lower = issuer.lower()
        return [c for c in self._cards.values()
                if c.get("issuer", "").lower() == issuer_lower]

    def all_card_ids(self) -> list[str]:
        """Return all card IDs."""
        return list(self._cards.keys())

    def count(self) -> int:
        """Return the number of loaded cards."""
        return len(self._cards)

    def get_point_value(self, key: str) -> Optional[float]:
        """Return the ₹ value of a reward unit by point value key."""
        return self._point_values.get(key)

    # ── Validation ────────────────────────────────────────────────────────────

    def validate(self) -> list[str]:
        """Validate all loaded cards against the schema.

        Returns
        -------
        list[str]
            A list of error messages. Empty list means all cards are valid.
        """
        errors: list[str] = []

        for card_id, card in self._cards.items():
            prefix = f"[{card_id}]"

            # Required top-level fields
            missing = _REQUIRED_FIELDS - set(card.keys())
            if missing:
                errors.append(f"{prefix} Missing required fields: {sorted(missing)}")
                continue

            # annual_fee must be non-negative integer or float
            fee = card.get("annual_fee")
            if not isinstance(fee, (int, float)) or fee < 0:
                errors.append(f"{prefix} annual_fee must be a non-negative number, got: {fee!r}")

            # reward_unit_value must be positive
            ruv = card.get("reward_unit_value")
            if not isinstance(ruv, (int, float)) or ruv <= 0:
                errors.append(f"{prefix} reward_unit_value must be > 0, got: {ruv!r}")

            # network
            network = card.get("network", "")
            if network not in _VALID_NETWORKS:
                errors.append(f"{prefix} network must be one of {_VALID_NETWORKS}, got: {network!r}")

            # reward_currency
            rc = card.get("reward_currency", "")
            if rc not in _VALID_CURRENCIES:
                errors.append(f"{prefix} reward_currency must be one of {_VALID_CURRENCIES}, got: {rc!r}")

            # categories
            categories = card.get("categories")
            if not isinstance(categories, dict) or not categories:
                errors.append(f"{prefix} categories must be a non-empty dict")
                continue

            # Must have 'Others' catch-all
            if "Others" not in categories:
                errors.append(f"{prefix} categories must include an 'Others' catch-all entry")

            for cat_name, cat_def in categories.items():
                if not isinstance(cat_def, dict):
                    errors.append(f"{prefix} category '{cat_name}' must be a dict")
                    continue
                for field in _REQUIRED_CATEGORY_FIELDS:
                    if field not in cat_def:
                        errors.append(f"{prefix} category '{cat_name}' missing field '{field}'")
                # earn_rate must be in [0, 1]
                er = cat_def.get("earn_rate")
                if er is not None:
                    if not isinstance(er, (int, float)) or not (0 <= er <= 1):
                        errors.append(
                            f"{prefix} category '{cat_name}' earn_rate={er!r} must be in [0, 1]"
                        )
                # cap_monthly_inr must be null or positive
                cap = cat_def.get("cap_monthly_inr")
                if cap is not None and (not isinstance(cap, (int, float)) or cap <= 0):
                    errors.append(
                        f"{prefix} category '{cat_name}' cap_monthly_inr={cap!r} must be null or > 0"
                    )
                # validate merchant_overrides if present
                overrides = cat_def.get("merchant_overrides", {})
                if overrides and isinstance(overrides, dict):
                    for merchant, mo_def in overrides.items():
                        if not isinstance(mo_def, dict):
                            errors.append(f"{prefix} merchant_override '{merchant}' must be a dict")
                            continue
                        mo_er = mo_def.get("earn_rate")
                        if mo_er is not None and not (0 <= mo_er <= 1):
                            errors.append(
                                f"{prefix} merchant_override '{merchant}' earn_rate={mo_er!r} out of range"
                            )

            # fee_waiver validation if present
            fw = card.get("fee_waiver")
            if fw is not None:
                if not isinstance(fw, dict):
                    errors.append(f"{prefix} fee_waiver must be a dict")
                elif fw.get("type") == "spend_threshold":
                    threshold = fw.get("annual_spend")
                    if not isinstance(threshold, (int, float)) or threshold <= 0:
                        errors.append(
                            f"{prefix} fee_waiver.annual_spend must be > 0, got: {threshold!r}"
                        )

            # milestones validation if present
            milestones = card.get("milestones", [])
            if milestones and not isinstance(milestones, list):
                errors.append(f"{prefix} milestones must be a list")
            for i, ms in enumerate(milestones or []):
                if not isinstance(ms, dict):
                    errors.append(f"{prefix} milestone[{i}] must be a dict")
                    continue
                for req in ("spend_threshold_inr", "period_months", "bonus_value_inr"):
                    if req not in ms:
                        errors.append(f"{prefix} milestone[{i}] missing field '{req}'")

        return errors

    # ── Filtering helpers ─────────────────────────────────────────────────────

    def filter_by_max_fee(self, max_fee: int) -> list[dict]:
        """Return cards whose annual_fee ≤ max_fee (or are waivable at any level)."""
        return [c for c in self._cards.values() if c.get("annual_fee", 0) <= max_fee]

    def filter_free_only(self) -> list[dict]:
        """Return cards with annual_fee == 0 (lifetime-free cards)."""
        return [c for c in self._cards.values() if c.get("annual_fee", 0) == 0]

    # ── Summary ───────────────────────────────────────────────────────────────

    def summary(self) -> list[dict]:
        """Return a condensed summary list for display.

        Each entry: id, name, issuer, network, annual_fee, last_verified.
        """
        return [
            {
                "id": c["id"],
                "name": c.get("name", c["id"]),
                "issuer": c.get("issuer", ""),
                "network": c.get("network", ""),
                "annual_fee": c.get("annual_fee", 0),
                "last_verified": c.get("last_verified", "unknown"),
            }
            for c in sorted(self._cards.values(), key=lambda x: x.get("name", ""))
        ]
