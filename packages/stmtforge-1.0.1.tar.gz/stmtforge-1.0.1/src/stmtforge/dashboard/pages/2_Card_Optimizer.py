"""Card Optimizer — Streamlit multipage dashboard page.

Auto-discovered by Streamlit as "2 Card Optimizer" when the dashboard is
launched via:
  streamlit run src/stmtforge/dashboard/app.py

Features
--------
- **Scope selector** (top-right): All Market Cards / My Cards Only / Custom Selection.
- **Recommendations tab**: Visual ranked card tiles + full list + per-card drill-down.
- **Spend Profile tab**: Category charts + per-transaction best-card advice columns.
- **N-Card Portfolio tab**: Greedy-optimal portfolio of N cards with allocation table.
- **Simulator tab**: Adjust spend per category and re-rank.
- **HTML export**: Full report download.
"""

from __future__ import annotations

import sys
from datetime import date
from pathlib import Path

import pandas as pd
import plotly.graph_objects as go
import streamlit as st

# ── Ensure src/ is importable when run via Streamlit directly ─────────────────
_SRC = Path(__file__).parent.parent.parent.parent
if str(_SRC) not in sys.path:
    sys.path.insert(0, str(_SRC))

from stmtforge.suggestor.card_advisor import CardAdvisor
from stmtforge.suggestor.card_db import CardDB
from stmtforge.suggestor.optimizer import best_n_card_combo, rank_cards
from stmtforge.suggestor.report import export_html_report
from stmtforge.suggestor.spend_vector import SpendVector, build_spend_vector

# ── Page config ───────────────────────────────────────────────────────────────
st.set_page_config(
    page_title="Card Optimizer | StmtForge",
    page_icon="💳",
    layout="wide",
)

# ── Design system (matches main app.py) ──────────────────────────────────────
CHART_COLORS = [
    "#0ea5e9", "#10b981", "#f59e0b", "#8b5cf6", "#ec4899",
    "#06b6d4", "#84cc16", "#f97316", "#a78bfa", "#fb7185",
    "#22d3ee", "#4ade80", "#fbbf24", "#c084fc", "#f472b6",
]
PLOTLY_LAYOUT = dict(
    paper_bgcolor="rgba(0,0,0,0)",
    plot_bgcolor="rgba(0,0,0,0)",
    font=dict(color="#e2e8f0", family="Inter, system-ui, sans-serif"),
    margin=dict(l=8, r=8, t=24, b=8),
    hoverlabel=dict(bgcolor="#1e293b", font_size=13, font_color="#e2e8f0", bordercolor="#334155"),
    xaxis=dict(gridcolor="#1e293b", zerolinecolor="#334155"),
    yaxis=dict(gridcolor="#1e293b", zerolinecolor="#334155"),
)

st.markdown("""
<style>
    @import url('https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap');
    html, body, [class*="css"], .stApp {
        background-color: #0f172a !important;
        color: #e2e8f0;
        font-family: 'Inter', system-ui, sans-serif;
    }
    section[data-testid="stSidebar"] {
        background-color: #0b1120 !important;
        border-right: 1px solid #1e293b;
    }
    section[data-testid="stSidebar"] * { color: #e2e8f0 !important; }

    .hero-banner {
        background: linear-gradient(135deg, #0f2545 0%, #1e3a5f 50%, #0f172a 100%);
        border: 1px solid #334155; border-radius: 16px;
        padding: 28px 32px; margin-bottom: 24px; position: relative; overflow: hidden;
    }
    .hero-banner::before {
        content: ""; position: absolute; top: -60px; right: -60px;
        width: 200px; height: 200px;
        background: radial-gradient(circle, rgba(14,165,233,0.12) 0%, transparent 70%);
        border-radius: 50%;
    }
    .hero-title { font-size:1.65rem; font-weight:700; color:#f1f5f9; letter-spacing:-0.025em; margin-bottom:6px; }
    .hero-sub { color:#94a3b8; font-size:0.9rem; margin-bottom:20px; }
    .hero-savings {
        display:inline-block; background:rgba(16,185,129,0.15);
        border:1px solid rgba(16,185,129,0.3); color:#10b981;
        font-size:2rem; font-weight:700; padding:10px 24px;
        border-radius:12px; letter-spacing:-0.02em;
    }
    .hero-savings-label { color:#64748b; font-size:0.75rem; text-transform:uppercase; letter-spacing:0.05em; margin-top:6px; }

    .card-tile {
        background:#1e293b; border:1px solid #334155; border-radius:14px;
        padding:20px; margin-bottom:16px; transition:border-color 0.2s, box-shadow 0.2s;
    }
    .card-tile:hover { border-color:#0ea5e9; box-shadow:0 0 0 1px rgba(14,165,233,0.3); }
    .card-tile-gold { border-color:#f59e0b !important; background:linear-gradient(135deg,#1e293b 80%,rgba(245,158,11,0.06) 100%); }
    .card-tile-silver { border-color:#94a3b8 !important; }

    .card-rank-badge {
        display:inline-flex; align-items:center; justify-content:center;
        width:28px; height:28px; border-radius:50%;
        font-size:0.75rem; font-weight:700; margin-right:10px; flex-shrink:0;
    }
    .rank-1 { background:#f59e0b; color:#1a1200; }
    .rank-2 { background:#94a3b8; color:#0f172a; }
    .rank-3 { background:#cd7f32; color:#0f172a; }
    .rank-other { background:#1e3a5f; color:#94a3b8; border:1px solid #334155; }

    .card-name { font-size:1rem; font-weight:600; color:#f1f5f9; }
    .card-issuer { font-size:0.78rem; color:#64748b; margin-top:2px; }
    .net-value-big { font-size:1.5rem; font-weight:700; color:#10b981; }
    .fee-badge { display:inline-block; font-size:0.72rem; padding:2px 8px; border-radius:6px; margin-top:4px; font-weight:500; }
    .fee-free  { background:rgba(16,185,129,0.15); color:#10b981; }
    .fee-waived{ background:rgba(14,165,233,0.15); color:#0ea5e9; }
    .fee-paid  { background:rgba(100,116,139,0.2); color:#94a3b8; }
    .why-bullet { font-size:0.82rem; color:#94a3b8; margin:2px 0; line-height:1.5; }
    .stale-ok   { color:#10b981; font-size:0.72rem; }
    .stale-warn { color:#f59e0b; font-size:0.72rem; }
    .stale-old  { color:#ef4444; font-size:0.72rem; }
    .chart-title { font-size:0.9rem; font-weight:600; color:#94a3b8; text-transform:uppercase; letter-spacing:0.06em; margin-bottom:12px; }

    /* ── Allocation table ──────────────────────────────── */
    .alloc-row { display:flex; align-items:center; justify-content:space-between; padding:8px 0; border-bottom:1px solid #1e293b; }
    .alloc-cat { font-size:0.85rem; color:#e2e8f0; }
    .alloc-card { font-size:0.82rem; color:#0ea5e9; font-weight:500; }

    .stTabs [data-baseweb="tab-list"] { background-color:#1e293b; border-radius:10px; padding:4px; border:1px solid #334155; }
    .stTabs [data-baseweb="tab"] { border-radius:8px; color:#94a3b8; font-weight:500; padding:8px 20px; }
    .stTabs [aria-selected="true"] { background-color:#0ea5e9 !important; color:#ffffff !important; }
    .stTabs [data-baseweb="tab-highlight"], .stTabs [data-baseweb="tab-border"] { display:none; }
    .stDataFrame { border:1px solid #334155; border-radius:8px; }
    .stAlert { border-radius:8px; }
    .stDownloadButton > button { background:linear-gradient(135deg,#0ea5e9,#0284c7); color:white; border:none; border-radius:8px; font-weight:600; padding:10px 24px; }
    footer { visibility:hidden; }
</style>
""", unsafe_allow_html=True)


# ── Sidebar controls ──────────────────────────────────────────────────────────
with st.sidebar:
    st.markdown("""
    <div style="text-align:center; padding:8px 0 4px 0;">
        <span style="font-size:1.5rem; font-weight:700; color:#f1f5f9; letter-spacing:-0.02em;">💳 Card Optimizer</span>
        <div style="font-size:0.7rem; color:#64748b; letter-spacing:0.05em; text-transform:uppercase; margin-top:4px;">StmtForge</div>
    </div>
    """, unsafe_allow_html=True)
    st.markdown("---")
    st.subheader("⚙️ Settings")
    months = st.slider("Analyse last N months", min_value=1, max_value=24, value=6)
    top_n = st.slider("Top recommendations", min_value=3, max_value=20, value=8)
    max_fee = st.number_input("Max annual fee (₹, 0 = any)", min_value=0, step=500, value=0)
    free_only = st.checkbox("Free cards only (₹0 annual fee)")
    goal = st.selectbox("Goal", options=["any", "cashback", "travel", "lounge"], index=0)
    st.divider()
    st.subheader("📦 N-Card Portfolio")
    portfolio_n = st.slider(
        "Cards in portfolio", min_value=1, max_value=8, value=3,
        help="Find the optimal set of N cards that maximise total rewards together.",
    )
    st.divider()
    export_button = st.button("📥 Export HTML report", use_container_width=True)


# ── Resource loaders ──────────────────────────────────────────────────────────

@st.cache_resource(show_spinner="Loading card database…")
def _load_card_db() -> CardDB | None:
    try:
        return CardDB()
    except FileNotFoundError as exc:
        st.error(f"Card database not found: {exc}")
        return None


def _load_database():
    """Try to load the stmtforge SQLite database from known paths."""
    try:
        from stmtforge.database.db import Database
    except ImportError:
        return None, "stmtforge package not found — run `pip install -e .`"

    for candidate in [
        Path.cwd() / "data" / "ccanalyser.db",
        Path(__file__).parent.parent.parent.parent.parent / "data" / "ccanalyser.db",
    ]:
        if candidate.exists():
            return Database(db_path=str(candidate)), None

    try:
        return Database(), None
    except Exception as exc:  # noqa: BLE001
        return None, str(exc)


# ── Helper functions ──────────────────────────────────────────────────────────

_today = date.today()


def _stale_badge(last_verified_str: str) -> str:
    try:
        lv = date.fromisoformat(last_verified_str)
        age = (_today - lv).days
        if age > 180:
            return f'<span class="stale-old">🔴 May be outdated ({age}d ago)</span>'
        if age > 90:
            return f'<span class="stale-warn">🟡 Verify benefits ({age}d ago)</span>'
        return f'<span class="stale-ok">✅ Recently verified ({age}d ago)</span>'
    except (ValueError, TypeError):
        return '<span class="stale-warn">⚠️ Verification date unknown</span>'


def _report_issue_url(card_name: str) -> str:
    import urllib.parse
    base = "https://github.com/madhav921/Card-Statement-Analyser/issues/new"
    title = urllib.parse.quote(f"Outdated benefit: {card_name}")
    body = urllib.parse.quote(
        f"The benefit information for **{card_name}** appears to be outdated.\n\nPlease describe what changed:\n\n"
    )
    return f"{base}?title={title}&body={body}&labels=data-quality"


def _fee_badge(annual_fee: float, fee_waived: bool) -> str:
    if annual_fee == 0:
        return '<span class="fee-badge fee-free">FREE</span>'
    if fee_waived:
        return f'<span class="fee-badge fee-waived">₹{annual_fee:,} WAIVED</span>'
    return f'<span class="fee-badge fee-paid">₹{annual_fee:,}/yr</span>'


def _rank_badge(rank: int) -> str:
    css = {1: "rank-1", 2: "rank-2", 3: "rank-3"}.get(rank, "rank-other")
    label = {1: "🥇", 2: "🥈", 3: "🥉"}.get(rank, f"#{rank}")
    return f'<span class="card-rank-badge {css}">{label}</span>'


def _tile_class(rank: int) -> str:
    """Return CSS class(es) for card tile based on rank."""
    if rank == 1:
        return "card-tile card-tile-gold"
    elif rank == 2:
        return "card-tile card-tile-silver"
    return "card-tile"


def _format_rate(rate: float) -> str:
    return f"{rate * 100:.1f}%" if rate > 0 else "—"


# ── Main logic ────────────────────────────────────────────────────────────────

card_db = _load_card_db()
if card_db is None:
    st.stop()

db, db_error = _load_database()
if db_error:
    st.warning(f"⚠️ Could not connect to database: {db_error}")
    with st.expander("📚 Card database (no transaction data)", expanded=True):
        st.metric("Cards loaded", card_db.count())
    st.info("Import some bank statements first, then come back here.")
    st.stop()

# Auto-sync user_cards registry from transaction history
db.sync_user_cards_from_transactions(card_db_cards=card_db.all_cards())
user_card_rows = db.get_user_cards(active_only=True)
user_card_ids_db = [r["card_id"] for r in user_card_rows]

# ── ══════════════════════════════════════════════════════════ ──
# ── SCOPE SELECTOR — primary UX control at top of page ────────
# ── ══════════════════════════════════════════════════════════ ──

all_card_ids_sorted = sorted(c["id"] for c in card_db.all_cards())
all_card_names_by_id = {c["id"]: c.get("name", c["id"]) for c in card_db.all_cards()}

header_col, scope_col = st.columns([2, 1])

with header_col:
    st.markdown("""
    <div style="margin-bottom:4px;">
        <span style="font-size:1.55rem; font-weight:700; color:#f1f5f9; letter-spacing:-0.025em;">💳 Card Optimizer</span>
    </div>
    <div style="color:#64748b; font-size:0.82rem; margin-bottom:8px;">
        Personalised recommendations based on your real spending history
    </div>
    """, unsafe_allow_html=True)

with scope_col:
    scope_mode = st.radio(
        "**Card scope**",
        options=["🌍 All Market Cards", "💳 My Cards Only", "🎯 Custom Selection"],
        index=0,
        help=(
            "**All Market Cards** — rank all cards in the database.\n\n"
            "**My Cards Only** — only consider cards detected from your statements.\n\n"
            "**Custom Selection** — pick exactly which cards to include."
        ),
    )

# Resolve active card ID list for this run
if scope_mode == "💳 My Cards Only":
    if not user_card_ids_db:
        st.warning(
            "No cards detected in your statement history. "
            "Import more statements or switch to **All Market Cards**.",
            icon="⚠️",
        )
        st.stop()
    active_card_ids: list[str] | None = user_card_ids_db
    scope_label = f"My Cards ({len(active_card_ids)})"

elif scope_mode == "🎯 Custom Selection":
    options_display = {all_card_names_by_id.get(cid, cid): cid for cid in all_card_ids_sorted}
    default_labels = [all_card_names_by_id.get(cid, cid) for cid in user_card_ids_db
                      if cid in all_card_names_by_id]
    selected_labels = st.multiselect(
        "Select cards to include",
        options=list(options_display.keys()),
        default=default_labels,
        placeholder="Choose one or more cards…",
    )
    if not selected_labels:
        st.info("Select at least one card to continue.")
        st.stop()
    active_card_ids = [options_display[lbl] for lbl in selected_labels]
    scope_label = f"Custom ({len(active_card_ids)} cards)"

else:  # All Market Cards
    active_card_ids = None   # None = all cards in card_db
    scope_label = f"All Market Cards ({card_db.count()})"

# Show detected user cards in sidebar after scope is known
with st.sidebar:
    if user_card_rows:
        st.divider()
        st.markdown("**🪪 Detected cards**")
        for row in user_card_rows:
            owned_icon = "✦" if row["card_id"] in set(active_card_ids or []) else "◦"
            st.caption(f"{owned_icon} {row['card_name']} ({row['issuer']})")

st.markdown("---")

# ── Build spend vector ────────────────────────────────────────────────────────
with st.spinner("Analysing your transaction history…"):
    try:
        sv = build_spend_vector(db, months=months)
    except Exception as exc:  # noqa: BLE001
        st.error(f"Error reading transactions: {exc}")
        st.stop()

if sv.transaction_count == 0:
    st.warning(
        f"No debit transactions found in the last {months} months. "
        "Try importing statements or increasing the analysis window."
    )
    st.stop()

# ── Compute recommendations respecting active scope ───────────────────────────
with st.spinner("Ranking cards…"):
    recs = rank_cards(
        sv, card_db,
        max_fee=max_fee if max_fee > 0 else None,
        goal=goal if goal != "any" else None,
        free_only=free_only,
        top_n=top_n,
    )
    if active_card_ids is not None:
        recs = [r for r in recs if r.card_id in set(active_card_ids)]

if not recs:
    st.warning("No cards match the selected filters. Try relaxing the fee, goal, or scope.")
    st.stop()

# ── Hero banner ────────────────────────────────────────────────────────────────
best = recs[0]
monthly_avg = sv.total_monthly_avg
annual_est = monthly_avg * 12
top_cat_entry = max(sv.categories.items(), key=lambda x: x[1]) if sv.categories else ("—", 0)

st.markdown(f"""
<div class="hero-banner">
    <div class="hero-title">💳 Best Card: <span style="color:#0ea5e9;">{best.card_name}</span></div>
    <div class="hero-sub">
        Scope: {scope_label} · Last {months} months · {sv.transaction_count:,} transactions ·
        ₹{monthly_avg:,.0f}/mo · ₹{annual_est:,.0f} est. annual spend
    </div>
    <div style="display:flex; gap:32px; flex-wrap:wrap; align-items:flex-start; margin-top:8px;">
        <div>
            <div class="hero-savings">₹{best.net_annual_value:,.0f}<span style="font-size:1rem;color:#86efac;">/yr</span></div>
            <div class="hero-savings-label">Best card net value</div>
        </div>
        <div style="padding-top:4px;">
            <div style="color:#94a3b8; font-size:0.82rem;">Issuer</div>
            <div style="color:#f1f5f9; font-weight:600; font-size:1rem;">{best.issuer}</div>
        </div>
        <div style="padding-top:4px;">
            <div style="color:#94a3b8; font-size:0.82rem;">Cards ranked</div>
            <div style="color:#f1f5f9; font-weight:600; font-size:1rem;">{len(recs)}</div>
        </div>
        <div style="padding-top:4px;">
            <div style="color:#94a3b8; font-size:0.82rem;">Top category</div>
            <div style="color:#f1f5f9; font-weight:600; font-size:1rem;">{top_cat_entry[0]}</div>
        </div>
        <div style="padding-top:4px;">
            <div style="color:#94a3b8; font-size:0.82rem;">My cards detected</div>
            <div style="color:#f1f5f9; font-weight:600; font-size:1rem;">{len(user_card_ids_db)}</div>
        </div>
    </div>
</div>
""", unsafe_allow_html=True)

st.warning(
    "⚠️ **Disclaimer**: Card benefits are subject to change. Verify with the issuer "
    "before applying. **This tool earns no referral fees.**",
    icon="⚠️",
)

# ── Tabs ──────────────────────────────────────────────────────────────────────
tab_recs, tab_profile, tab_portfolio, tab_sim = st.tabs([
    "🏆 Recommendations",
    "📊 Spend Profile",
    f"📦 {portfolio_n}-Card Portfolio",
    "🔧 Simulator",
])


# ═══════════════════ TAB 1 — Recommendations ═════════════════════════════════
with tab_recs:
    st.markdown("#### 🥇 Top Picks")
    top3 = recs[:3]
    cols_top = st.columns(len(top3))

    for col, rec in zip(cols_top, top3):
        r = rec.result
        card_raw = card_db.get_card(rec.card_id) or {}
        badge_html = _stale_badge(card_raw.get("last_verified", ""))
        fee_html = _fee_badge(rec.annual_fee, r.fee_waived)
        why_bullets = "".join(f'<div class="why-bullet">✅ {b}</div>' for b in rec.why[:3])
        with col:
            st.markdown(f"""
            <div class="{_tile_class(rec.rank)}">
                <div style="display:flex; align-items:center; margin-bottom:12px;">
                    {_rank_badge(rec.rank)}
                    <div>
                        <div class="card-name">{rec.card_name}</div>
                        <div class="card-issuer">{rec.issuer}</div>
                    </div>
                </div>
                <div class="net-value-big">₹{r.net_annual_value:,.0f}</div>
                <div style="color:#64748b; font-size:0.72rem; margin-bottom:8px;">net value / year</div>
                <div style="margin-bottom:8px;">{fee_html}</div>
                <div style="margin-bottom:10px;">{why_bullets}</div>
                <div>{badge_html}</div>
            </div>
            """, unsafe_allow_html=True)
            issue_url = _report_issue_url(rec.card_name)
            st.markdown(
                f'<a href="{issue_url}" target="_blank" '
                f'style="font-size:0.72rem; color:#64748b;">Report outdated benefit</a>',
                unsafe_allow_html=True,
            )

    st.markdown("---")

    # Full ranked table
    st.markdown("#### 📋 All Recommendations")
    rec_data = []
    for rec in recs:
        r = rec.result
        fee_display = (
            "FREE" if rec.annual_fee == 0
            else (f"₹{rec.annual_fee:,} (WAIVED)" if r.fee_waived else f"₹{rec.annual_fee:,}")
        )
        user_tag = "🪪 You have it" if rec.card_id in set(user_card_ids_db) else ""
        rec_data.append({
            "Rank": f"#{rec.rank}",
            "Card": rec.card_name,
            "Issuer": rec.issuer,
            "Yours": user_tag,
            "Annual Fee": fee_display,
            "Gross Reward/yr": f"₹{r.gross_annual_reward:,.0f}",
            "Net Value/yr": f"₹{rec.net_annual_value:,.0f}",
        })
    st.dataframe(pd.DataFrame(rec_data), use_container_width=True, hide_index=True)

    st.markdown("---")

    # Per-card drill-down
    st.markdown("#### 🔍 Card Details")
    for rec in recs:
        r = rec.result
        card_raw = card_db.get_card(rec.card_id) or {}
        lv_str = card_raw.get("last_verified", "")
        owned_tag = " 🪪" if rec.card_id in set(user_card_ids_db) else ""
        with st.expander(
            f"#{rec.rank} — {rec.card_name}{owned_tag}  |  "
            f"Net ₹{r.net_annual_value:,.0f}/yr  |  {rec.issuer}"
        ):
            issue_url = _report_issue_url(rec.card_name)
            st.markdown(
                f"{_stale_badge(lv_str)} · "
                f'<a href="{issue_url}" target="_blank" '
                f'style="font-size:0.72rem; color:#64748b;">Report outdated benefit</a>',
                unsafe_allow_html=True,
            )
            st.markdown("")
            detail_cols = st.columns([1, 1])
            with detail_cols[0]:
                st.markdown("**Why this card?**")
                for bullet in rec.why:
                    st.markdown(f"✅ {bullet}")
                if rec.caveats:
                    st.markdown("**Caveats:**")
                    for caveat in rec.caveats:
                        st.markdown(f"⚠️ {caveat}")
            with detail_cols[1]:
                if r.category_breakdowns:
                    cat_detail = [
                        {
                            "Category": cb.category,
                            "Monthly Spend": f"₹{cb.monthly_spend:,.0f}",
                            "Earn Rate": cb.raw_label,
                            "Annual Reward": f"₹{cb.annual_reward:,.0f}",
                            "Capped": "⚠️ yes" if cb.is_capped else "—",
                        }
                        for cb in r.category_breakdowns
                    ]
                    st.dataframe(
                        pd.DataFrame(cat_detail), use_container_width=True, hide_index=True
                    )
            if r.milestone_breakdowns:
                st.markdown("**Milestones:**")
                for ms in r.milestone_breakdowns:
                    icon = "🎯" if ms.achieved else "⏳"
                    st.markdown(
                        f"{icon} {ms.description}: ₹{ms.bonus_value_inr:,.0f} bonus "
                        f"at ₹{ms.spend_threshold_inr:,.0f} spend "
                        f"({'achieved' if ms.achieved else 'not reached'})"
                    )
            facts_cols = st.columns(4)
            facts_cols[0].metric("Annual Fee", f"₹{rec.annual_fee:,}" if rec.annual_fee else "FREE")
            facts_cols[1].metric("Network", card_raw.get("network", "—"))
            facts_cols[2].metric("Reward Currency", card_raw.get("reward_currency", "—").title())
            facts_cols[3].metric(
                "Lounge Access",
                str(card_raw.get("benefits", {}).get("domestic_lounge_per_year", 0)) + "/yr",
            )


# ═══════════════════ TAB 2 — Spend Profile ═══════════════════════════════════
with tab_profile:
    st.markdown("#### 📊 Your Spend Profile")
    st.caption(
        f"Scope: {scope_label} · Last {months} months · "
        f"{sv.transaction_count:,} transactions · ₹{sv.total_monthly_avg:,.0f}/month average"
    )

    cat_df = pd.DataFrame(
        [(cat, amt) for cat, amt in sorted(sv.categories.items(), key=lambda x: x[1], reverse=True) if amt > 0],
        columns=["Category", "Monthly Avg (₹)"],
    )

    if not cat_df.empty:
        prof_col1, prof_col2 = st.columns([3, 1])
        with prof_col1:
            st.markdown('<div class="chart-title">Monthly Average Spend by Category</div>', unsafe_allow_html=True)
            fig = go.Figure(data=[go.Bar(
                x=cat_df["Monthly Avg (₹)"],
                y=cat_df["Category"],
                orientation="h",
                marker=dict(
                    color=cat_df["Monthly Avg (₹)"],
                    colorscale=[[0, "#0ea5e9"], [1, "#10b981"]],
                    cornerradius=4, line=dict(width=0),
                ),
                hovertemplate="<b>%{y}</b><br>₹%{x:,.0f}/month<extra></extra>",
            )])
            fig.update_layout(
                **PLOTLY_LAYOUT,
                xaxis_tickprefix="₹",
                height=max(260, len(cat_df) * 32 + 40),
            )
            fig.update_yaxes(autorange="reversed", gridcolor="rgba(0,0,0,0)")
            st.plotly_chart(fig, use_container_width=True)
        with prof_col2:
            st.metric("Monthly avg", f"₹{sv.total_monthly_avg:,.0f}")
            st.metric("Annual est.", f"₹{sv.total_monthly_avg * 12:,.0f}")
            st.metric("Transactions", f"{sv.transaction_count:,}")
            st.metric("Top category", cat_df.iloc[0]["Category"])
            if sv.merchants:
                st.markdown("---")
                st.caption("**Top merchants:**")
                for m, amt in sorted(sv.merchants.items(), key=lambda x: x[1], reverse=True)[:5]:
                    st.caption(f"**{m.title()}** — ₹{amt:,.0f}/mo")

        st.markdown("---")
        st.markdown('<div class="chart-title">Spend Composition</div>', unsafe_allow_html=True)
        fig2 = go.Figure(data=[go.Pie(
            labels=cat_df["Category"],
            values=cat_df["Monthly Avg (₹)"],
            hole=0.55,
            marker=dict(colors=CHART_COLORS[:len(cat_df)], line=dict(color="#0f172a", width=2)),
            textinfo="percent+label", textposition="outside",
            textfont=dict(size=11, color="#e2e8f0"),
            hovertemplate="<b>%{label}</b><br>₹%{value:,.0f}/mo<br>%{percent}<extra></extra>",
        )])
        fig2.update_layout(**PLOTLY_LAYOUT, height=360, showlegend=False)
        st.plotly_chart(fig2, use_container_width=True)

    # ── Per-transaction best-card advice ──────────────────────────
    st.markdown("---")
    st.markdown("#### 💡 Per-Transaction Card Advice")
    st.caption(
        "For each debit transaction, the table below shows which card earns the most — "
        "once from your detected portfolio, and once from the selected scope."
    )

    market_cards_for_advisor = (
        [c for c in card_db.all_cards() if c.get("id") in set(active_card_ids)]
        if active_card_ids is not None
        else card_db.all_cards()
    )
    advisor = CardAdvisor(
        all_cards=market_cards_for_advisor,
        user_card_ids=user_card_ids_db,
    )

    with st.spinner("Loading transactions…"):
        try:
            raw_txn = db.get_transactions({"type": "debit"})
        except Exception:  # noqa: BLE001
            raw_txn = pd.DataFrame()

    if raw_txn.empty:
        st.info("No debit transactions found in the database.")
    else:
        txn_limit = st.select_slider(
            "Rows to display",
            options=[50, 100, 250, 500, 1000, "All"],
            value=100,
        )
        display_df = raw_txn if txn_limit == "All" else raw_txn.head(int(txn_limit))

        with st.spinner("Computing card advice…"):
            enriched = advisor.enrich_dataframe(display_df)

        cols_to_show = ["date", "description", "amount", "category", "bank",
                        "best_card_user", "best_card_user_rate",
                        "best_card_market", "best_card_market_rate"]
        enriched_display = enriched[[c for c in cols_to_show if c in enriched.columns]].copy()

        for rate_col in ("best_card_user_rate", "best_card_market_rate"):
            if rate_col in enriched_display.columns:
                enriched_display[rate_col] = enriched_display[rate_col].apply(_format_rate)

        enriched_display = enriched_display.rename(columns={
            "date": "Date",
            "description": "Description",
            "amount": "Amount (₹)",
            "category": "Category",
            "bank": "Bank",
            "best_card_user": "Best Card (Your Portfolio)",
            "best_card_user_rate": "Rate (Your Portfolio)",
            "best_card_market": f"Best Card ({scope_label})",
            "best_card_market_rate": f"Rate ({scope_label})",
        })
        st.dataframe(enriched_display, use_container_width=True, hide_index=True, height=420)

        if "Best Card (Your Portfolio)" in enriched_display.columns and user_card_ids_db:
            covered = enriched_display["Best Card (Your Portfolio)"].notna().sum()
            zero_earn = (enriched_display["Rate (Your Portfolio)"] == "—").sum()
            sm_col1, sm_col2 = st.columns(2)
            sm_col1.metric(
                "Transactions covered by your portfolio",
                f"{covered:,} / {len(enriched_display):,}",
            )
            sm_col2.metric(
                "Zero-earn transactions (your cards)",
                f"{zero_earn:,}",
                delta=f"{zero_earn / len(enriched_display) * 100:.1f}% of total",
                delta_color="inverse",
            )


# ═══════════════════ TAB 3 — N-Card Portfolio ════════════════════════════════
with tab_portfolio:
    st.markdown(f"#### 📦 Optimal {portfolio_n}-Card Portfolio")
    st.caption(
        f"Greedy algorithm: selects the {portfolio_n} cards that maximise total rewards "
        "when each category spend goes to the card with the highest earn rate. "
        f"Scope: {scope_label}."
    )

    with st.spinner(f"Building optimal {portfolio_n}-card portfolio…"):
        portfolio = best_n_card_combo(
            sv, card_db,
            n=portfolio_n,
            max_fee_per_card=max_fee if max_fee > 0 else None,
            free_only=free_only,
            card_ids=active_card_ids,
        )

    if portfolio is None or not portfolio.cards:
        st.warning("Not enough cards in the current scope to build a portfolio. Try a wider scope.")
    else:
        pf_m1, pf_m2, pf_m3, pf_m4 = st.columns(4)
        pf_m1.metric(
            f"Combined net value ({portfolio_n} cards)",
            f"₹{portfolio.combined_net_annual_value:,.0f}/yr",
        )
        pf_m2.metric(
            "Best single card alone",
            f"₹{portfolio.cards[0].net_annual_value:,.0f}/yr",
        )
        pf_m3.metric(
            "Extra from combining",
            f"₹{portfolio.vs_best_single:+,.0f}/yr",
            delta=f"{portfolio.vs_best_single / max(1, portfolio.cards[0].net_annual_value) * 100:+.1f}%",
        )
        total_fees = sum(c.annual_fee for c in portfolio.cards)
        pf_m4.metric("Total fees", f"₹{total_fees:,}/yr" if total_fees else "FREE")

        st.markdown("---")

        # Card tiles
        n_cols = min(portfolio_n, 4)
        tile_cols = st.columns(n_cols)
        for i, rec in enumerate(portfolio.cards):
            r = rec.result
            card_raw = card_db.get_card(rec.card_id) or {}
            fee_html = _fee_badge(rec.annual_fee, r.fee_waived)
            owned = rec.card_id in set(user_card_ids_db)
            with tile_cols[i % n_cols]:
                st.markdown(f"""
                <div class="{_tile_class(rec.rank)}">
                    <div style="display:flex; align-items:center; margin-bottom:10px;">
                        {_rank_badge(rec.rank)}
                        <div>
                            <div class="card-name">{rec.card_name}{"&nbsp;🪪" if owned else ""}</div>
                            <div class="card-issuer">{rec.issuer}</div>
                        </div>
                    </div>
                    <div class="net-value-big">₹{r.net_annual_value:,.0f}</div>
                    <div style="color:#64748b; font-size:0.72rem; margin-bottom:6px;">standalone value/yr</div>
                    <div>{fee_html}</div>
                </div>
                """, unsafe_allow_html=True)

        st.markdown("---")

        # Category allocation table
        st.markdown("#### 🗺️ Category Allocation — Which Card to Swipe")
        st.caption("Use the card in the right column to earn the highest reward for each category.")
        alloc_rows = []
        for cat in sorted(portfolio.category_allocation.keys()):
            spend = sv.category_spend(cat)
            if spend <= 0:
                continue
            alloc_rows.append({
                "Category": cat,
                "Swipe This Card": portfolio.category_allocation[cat],
                "Monthly Spend": f"₹{spend:,.0f}",
            })
        if alloc_rows:
            st.dataframe(pd.DataFrame(alloc_rows), use_container_width=True, hide_index=True)

        # Reward contribution chart
        if alloc_rows:
            st.markdown("---")
            st.markdown('<div class="chart-title">Annual Reward Contribution by Category</div>', unsafe_allow_html=True)
            card_cat_rewards: dict[str, dict[str, float]] = {}
            for rec in portfolio.cards:
                for cb in rec.result.category_breakdowns:
                    if cb.annual_reward > 0:
                        card_cat_rewards.setdefault(rec.card_name, {})[cb.category] = cb.annual_reward
            fig3 = go.Figure()
            for i, (cname, cat_rewards) in enumerate(card_cat_rewards.items()):
                fig3.add_trace(go.Bar(
                    name=cname,
                    x=list(cat_rewards.keys()),
                    y=list(cat_rewards.values()),
                    marker_color=CHART_COLORS[i % len(CHART_COLORS)],
                    hovertemplate=f"<b>{cname}</b><br>%{{x}}: ₹%{{y:,.0f}}/yr<extra></extra>",
                ))
            fig3.update_layout(
                **PLOTLY_LAYOUT,
                barmode="group",
                height=340,
                yaxis_tickprefix="₹",
                legend=dict(orientation="h", yanchor="bottom", y=1.01, xanchor="right", x=1),
            )
            st.plotly_chart(fig3, use_container_width=True)

        if portfolio.rationale:
            with st.expander("📖 Full category allocation detail"):
                for line in portfolio.rationale:
                    st.markdown(f"→ {line}")


# ═══════════════════ TAB 4 — Simulator ═══════════════════════════════════════
with tab_sim:
    st.markdown("#### 🔧 Spend Simulator")
    st.caption(
        f"Adjust monthly spend per category to see how card rankings change. Scope: {scope_label}."
    )
    sim_categories = list(sv.categories.keys()) or ["Others"]
    sim_values: dict[str, float] = {}
    slider_cols = st.columns(2)
    for i, cat in enumerate(sim_categories):
        with slider_cols[i % 2]:
            sim_values[cat] = st.slider(
                f"{cat} (₹/month)",
                min_value=0, max_value=100_000, step=1_000,
                value=int(sv.categories.get(cat, 0)),
                key=f"sim_{cat}",
            )
    sim_total = sum(sim_values.values())
    st.metric("Simulated monthly spend", f"₹{sim_total:,.0f}")

    if st.button("🔄 Re-rank with simulated spend", key="sim_run", use_container_width=True):
        sim_sv = SpendVector(
            period_months=6,
            date_from=sv.date_from,
            date_to=sv.date_to,
            transaction_count=sv.transaction_count,
            categories=sim_values,
            merchants=sv.merchants,
            total_monthly_avg=float(sim_total),
        )
        sim_recs = rank_cards(
            sim_sv, card_db,
            max_fee=max_fee if max_fee > 0 else None,
            goal=goal if goal != "any" else None,
            free_only=free_only,
            top_n=top_n,
        )
        if active_card_ids is not None:
            sim_recs = [r for r in sim_recs if r.card_id in set(active_card_ids)]

        sim_portfolio = best_n_card_combo(
            sim_sv, card_db, n=portfolio_n,
            max_fee_per_card=max_fee if max_fee > 0 else None,
            free_only=free_only,
            card_ids=active_card_ids,
        )

        sim_data = []
        for r in sim_recs:
            actual_nav = next(
                (x.net_annual_value for x in recs if x.card_id == r.card_id),
                r.net_annual_value,
            )
            sim_data.append({
                "Rank": f"#{r.rank}",
                "Card": r.card_name,
                "Issuer": r.issuer,
                "Yours": "🪪" if r.card_id in set(user_card_ids_db) else "",
                "Net Value/yr (sim)": f"₹{r.net_annual_value:,.0f}",
                "Delta vs actual": f"₹{r.net_annual_value - actual_nav:+,.0f}",
            })

        st.dataframe(pd.DataFrame(sim_data), use_container_width=True, hide_index=True)
        st.caption(f"Simulated annual spend: ₹{sim_total * 12:,.0f}")

        if sim_portfolio:
            st.markdown("---")
            st.markdown(
                f"**Simulated {portfolio_n}-card portfolio: "
                f"₹{sim_portfolio.combined_net_annual_value:,.0f}/yr**"
            )
            for rec in sim_portfolio.cards:
                st.markdown(f"  • {rec.card_name} — ₹{rec.net_annual_value:,.0f}/yr standalone")


# ── HTML export ────────────────────────────────────────────────────────────────
if export_button:
    export_path = Path("data") / "card_optimizer_report.html"
    try:
        all_recs = rank_cards(
            sv, card_db,
            max_fee=max_fee if max_fee > 0 else None,
            goal=goal if goal != "any" else None,
        )
        if active_card_ids is not None:
            all_recs = [r for r in all_recs if r.card_id in set(active_card_ids)]
        html_content = export_html_report(sv, all_recs, output_path=export_path)
        with open(export_path, "rb") as f:
            st.download_button(
                "⬇️ Download HTML Report",
                data=f,
                file_name="card_optimizer_report.html",
                mime="text/html",
            )
        st.success(f"Report saved to `{export_path}`")
    except Exception as exc:  # noqa: BLE001
        st.error(f"Export failed: {exc}")
