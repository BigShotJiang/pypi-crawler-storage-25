from __future__ import annotations
from collections.abc import Callable,Mapping
import httpx
from.api_url import resolve_api_url
from.auth_session import get_api_auth_header
UNAUTHORIZED_MESSAGE='Unauthorized. Run `gv auth --help` and try again.'
def api_base_url()->str:return resolve_api_url().rstrip('/')
def auth_headers()->dict[str,str]:return{'Authorization':get_api_auth_header()}
def _response_error_message(response:httpx.Response)->str:
	B=response
	try:A=B.json()
	except ValueError:A={}
	if isinstance(A,dict):
		C=A.get('error')or A.get('detail')
		if isinstance(C,str)and C:return C
	return f"HTTP {B.status_code} from {B.request.url}"
def raise_for_response(response:httpx.Response,*,error_factories:Mapping[int,Callable[[],Exception]]|None=None)->None:
	B=error_factories;A=response
	if A.is_success:return
	if B is not None:
		C=B.get(A.status_code)
		if C is not None:raise C()
	if A.status_code==401:raise RuntimeError(UNAUTHORIZED_MESSAGE)
	raise RuntimeError(_response_error_message(A))