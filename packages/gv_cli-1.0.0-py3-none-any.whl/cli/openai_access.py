from __future__ import annotations
import base64,json,subprocess,time
from pathlib import Path
from textwrap import dedent
from typing import Any
from.import ssh_access
LOCAL_CODEX_PATH=Path.home()/'.codex'/'auth.json'
REMOTE_OPENCODE_AUTH_PATH='/opt/nero/data/opencode/opencode/auth.json'
REMOTE_CODEX_AUTH_PATH='$HOME/.codex/auth.json'
LOCAL_CODEX_MISSING_HINT=f"Local Codex auth file not found at {LOCAL_CODEX_PATH}. Run `codex` and sign in with ChatGPT first."
def local_codex_auth_exists()->bool:return LOCAL_CODEX_PATH.is_file()
def read_local_codex_auth()->dict[str,Any]:
	if not LOCAL_CODEX_PATH.is_file():raise RuntimeError(LOCAL_CODEX_MISSING_HINT)
	try:E=LOCAL_CODEX_PATH.read_text(encoding='utf-8');A=json.loads(E)
	except(OSError,json.JSONDecodeError)as B:raise RuntimeError(f"Could not read Codex auth file {LOCAL_CODEX_PATH}: {B}")from B
	if not isinstance(A,dict):raise RuntimeError(f"Codex auth file {LOCAL_CODEX_PATH} is not a JSON object.")
	if A.get('auth_mode')!='chatgpt':raise RuntimeError('Codex auth file is not in ChatGPT oauth mode. Run `codex` and sign in with ChatGPT.')
	C=A.get('tokens')
	if not isinstance(C,dict):raise RuntimeError('Codex auth file is missing the `tokens` object.')
	for D in('access_token','refresh_token','account_id'):
		if not C.get(D):raise RuntimeError(f"Codex auth file is missing `tokens.{D}`.")
	return A
def codex_to_opencode(codex_auth:dict[str,Any])->dict[str,Any]:
	A=codex_auth['tokens'];C=str(A['access_token']);B=_expires_ms_from_access_token(C)
	if B is None:B=int(time.time()*1000)+2419200000
	return{'openai':{'type':'oauth','access':C,'refresh':str(A['refresh_token']),'expires':B,'accountId':str(A['account_id'])}}
def enable_openai(env_id:str,ssh_details:ssh_access.EnvSshAccess,codex_auth:dict[str,Any])->None:
	B=codex_auth;A=ssh_details;D=codex_to_opencode(B);C=ssh_access.run_ssh_process(env_id,A,('bash','-se'),input_text=_enable_script(codex_json=json.dumps(B,indent=2),opencode_json=json.dumps(D,indent=2),fallback_user=A.username),capture_output=True)
	if C.returncode!=0:raise RuntimeError(_stderr_message(C,'Failed to enable OpenAI auth.'))
def openai_status(env_id:str,ssh_details:ssh_access.EnvSshAccess)->dict[str,Any]:
	A=ssh_access.run_ssh_process(env_id,ssh_details,('bash','-se'),input_text=_status_script(),capture_output=True)
	if A.returncode==10:return{'state':'disabled','expires_ms':None,'account_id':None}
	if A.returncode!=0:raise RuntimeError(_stderr_message(A,'Failed to read OpenAI auth status.'))
	try:C=json.loads((A.stdout or'').strip())
	except json.JSONDecodeError as D:raise RuntimeError(f"Could not parse OpenAI status from env: {D}: {A.stdout!r}")from D
	B=C.get('expires');E=C.get('account_id');G=int(time.time()*1000)
	if isinstance(B,int)and B>G:F='enabled'
	else:F='expired'
	return{'state':F,'expires_ms':B if isinstance(B,int)else None,'account_id':E if isinstance(E,str)else None}
def format_status(status:dict[str,Any])->str:
	A=status;B=A.get('state');C=A.get('expires_ms')
	if B=='enabled'and isinstance(C,int):D=max(0,C//1000-int(time.time()));return f"enabled (expires in {_format_duration(D)})"
	if B=='expired':return'expired'
	return'disabled'
def _format_duration(seconds:int)->str:
	A=seconds
	if A>=86400:return f"{A//86400}d"
	if A>=3600:return f"{A//3600}h"
	if A>=60:return f"{A//60}m"
	return f"{A}s"
def _expires_ms_from_access_token(access_token:str)->int|None:
	try:C,A,C=access_token.split('.',2)
	except ValueError:return
	D='='*(-len(A)%4)
	try:E=base64.urlsafe_b64decode(A+D);F=json.loads(E)
	except(ValueError,json.JSONDecodeError):return
	B=F.get('exp')
	if not isinstance(B,(int,float)):return
	return int(B)*1000
def _enable_script(codex_json:str,opencode_json:str,fallback_user:str)->str:
	B=fallback_user;C=base64.b64encode(codex_json.encode('utf-8')).decode('ascii');D=base64.b64encode(opencode_json.encode('utf-8')).decode('ascii');A=''.join(A for A in B if A.isalnum()or A in'_-')
	if not A:raise RuntimeError(f"Refusing to use unsafe SSH username: {B!r}")
	return _join_script_sections('set -euo pipefail',dedent(f"            # Decode payloads uploaded as base64 to avoid shell quoting surprises.\n            codex_json=\"$(printf '%s' '{C}' | base64 -d)\"\n            opencode_json=\"$(printf '%s' '{D}' | base64 -d)\"\n            opencode_path=\"{REMOTE_OPENCODE_AUTH_PATH}\"\n            "),dedent('            # Write the Codex CLI auth file for the SSH user.\n            install -d -m 700 "$HOME/.codex"\n            umask 077\n            printf \'%s\\n\' "$codex_json" > "$HOME/.codex/auth.json"\n            chmod 600 "$HOME/.codex/auth.json"\n            '),dedent(rf"""            # Preserve the existing OpenCode auth.json ownership if the file is already there.
            if [[ -e "$opencode_path" ]]; then
              owner="$(stat -c '%U:%G' "$opencode_path")"
            else
              owner="{A}:{A}"
            fi
            tmp="$(mktemp)"
            printf '%s\n' "$opencode_json" > "$tmp"
            sudo install -D -m 600 -o "${{owner%:*}}" -g "${{owner#*:}}" "$tmp" "$opencode_path"
            rm -f "$tmp"
            """),dedent("            # Reload OpenCode so it picks up the new auth material.\n            if systemctl list-unit-files nero-opencode.service >/dev/null 2>&1; then\n              sudo systemctl restart nero-opencode.service\n            fi\n            printf 'OpenAI auth enabled.\\n'\n            "))
def _status_script()->str:A=REMOTE_OPENCODE_AUTH_PATH;return _join_script_sections('set -euo pipefail',dedent(f'            opencode_path="{A}"\n            if [[ ! -f "$opencode_path" ]]; then\n              exit 10\n            fi\n            '),f"""python3 - <<'PY'
import json, sys
path = {A!r}
try:
    with open(path, 'r', encoding='utf-8') as fh:
        data = json.load(fh)
except Exception as exc:
    sys.stderr.write(f'failed to read {{path}}: {{exc}}\\n')
    sys.exit(1)
openai = data.get('openai') if isinstance(data, dict) else None
if not isinstance(openai, dict):
    sys.exit(10)
out = {{
    'expires': openai.get('expires'),
    'account_id': openai.get('accountId'),
}}
print(json.dumps(out))
PY
""")
def _stderr_message(result:subprocess.CompletedProcess[str],fallback:str)->str:A=result;B=(A.stderr or A.stdout or'').strip();return B or fallback
def _join_script_sections(*A:str)->str:return'\n\n'.join(A.strip('\n')for A in A if A).strip()+'\n'