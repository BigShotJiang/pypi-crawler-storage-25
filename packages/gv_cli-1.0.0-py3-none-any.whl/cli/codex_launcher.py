from __future__ import annotations
import asyncio,json,shlex
from dataclasses import dataclass
from textwrap import dedent
from typing import Any,Protocol
import click,httpx
from.import remote_workspaces,ssh_access
class EnvLike(Protocol):id:str;name:str;url:str|None;opencode_username:str;opencode_password:str
@dataclass(frozen=True)
class SessionRecord:id:str;summary:str;updated_at:int
@dataclass(frozen=True)
class LaunchChoice:
	project_label:str;workspace_label:str;directory:str;session_id:str|None;session_summary:str|None
	@property
	def is_new_session(self)->bool:return self.session_id is None
def handle_codex(env:EnvLike,ssh_details:ssh_access.EnvSshAccess)->int:
	C=ssh_details;A=env;validate_env_supports_workspace_discovery(A)
	try:B=asyncio.run(remote_workspaces.discover_workspace_records(A))
	except httpx.HTTPError as D:raise RuntimeError(f"Failed to query remote OpenCode: {D}")from D
	if not B:raise RuntimeError('OpenCode has no known projects in this environment yet. Open the web UI first to initialize one.')
	E=fetch_sessions(A.id,C,tuple(A.directory for A in B));F=build_launch_choices(B,E);G=choose_launch_choice(A.name,F);exec_codex(A.id,C,G);return 0
def validate_env_supports_workspace_discovery(env:EnvLike)->None:
	if not env.url:raise RuntimeError('Environment does not have an OpenCode URL yet.')
def fetch_sessions(env_id:str,ssh_details:ssh_access.EnvSshAccess,directories:tuple[str,...])->dict[str,list[SessionRecord]]:
	A=directories
	if not A:return{}
	B=ssh_access.run_ssh_process(env_id,ssh_details,('bash','-se'),input_text=build_list_sessions_script(A),capture_output=True)
	if B.returncode!=0:raise RuntimeError(_stderr_message(B,'Failed to list Codex sessions on the env.'))
	return parse_remote_session_listing(B.stdout,A)
def build_list_sessions_script(directories:tuple[str,...])->str:A=json.dumps(list(directories));B=dedent(f"""import json
import sqlite3
from pathlib import Path


DIRECTORIES = json.loads({A!r})


def normalize_summary(text: str, fallback: str) -> str:
    compact = ' '.join(text.split())
    if not compact:
        return fallback
    if len(compact) > 80:
        return compact[:77] + '...'
    return compact


def extract_text(value) -> str | None:
    if isinstance(value, str) and value.strip():
        return value.strip()
    if isinstance(value, list):
        for item in value:
            extracted = extract_text(item)
            if extracted:
                return extracted
        return None
    if not isinstance(value, dict):
        return None
    for key in ('message', 'text', 'content', 'parts', 'payload'):
        extracted = extract_text(value.get(key))
        if extracted:
            return extracted
    return None


def fallback_rows_from_rollouts(codex_home: Path) -> list[dict[str, object]]:
    rows = []
    sessions_root = codex_home / 'sessions'
    if not sessions_root.is_dir():
        return rows
    for session_path in sessions_root.rglob('rollout-*.jsonl'):
        if not session_path.is_file():
            continue
        session_id = session_path.stem.rsplit('-', 1)[-1]
        cwd = None
        summary = None
        try:
            updated_at = int(session_path.stat().st_mtime * 1000)
        except OSError:
            continue
        try:
            with session_path.open(encoding='utf-8', errors='replace') as handle:
                for raw_line in handle:
                    raw_line = raw_line.strip()
                    if not raw_line:
                        continue
                    try:
                        entry = json.loads(raw_line)
                    except json.JSONDecodeError:
                        continue
                    entry_type = entry.get('type')
                    payload = entry.get('payload') if isinstance(entry, dict) else None
                    if entry_type == 'session_meta' and isinstance(payload, dict):
                        candidate_cwd = payload.get('cwd')
                        if isinstance(candidate_cwd, str) and candidate_cwd:
                            cwd = candidate_cwd
                    if summary is None and entry_type == 'event_msg' and isinstance(payload, dict):
                        if payload.get('type') == 'user_message':
                            summary = extract_text(payload)
        except OSError:
            continue
        if cwd not in DIRECTORIES:
            continue
        fallback = session_id[:8]
        rows.append(
            {{
                'directory': cwd,
                'id': session_id,
                'summary': normalize_summary(summary or fallback, fallback),
                'updatedAt': updated_at,
            }}
        )
    return rows


def load_rows_from_state_db(codex_home: Path) -> list[dict[str, object]]:
    rows_by_id = {{}}
    for sqlite_path in sorted(codex_home.glob('*.sqlite')):
        if not sqlite_path.is_file():
            continue
        try:
            connection = sqlite3.connect(f'file:{{sqlite_path}}?mode=ro', uri=True)
        except sqlite3.Error:
            continue
        try:
            cursor = connection.execute(
                \"SELECT name FROM sqlite_master WHERE type = 'table' AND name = 'threads'\"
            )
            if cursor.fetchone() is None:
                continue
            cursor = connection.execute(
                '''
                SELECT
                    id,
                    cwd,
                    title,
                    first_user_message,
                    COALESCE(updated_at_ms, updated_at * 1000, 0) AS updated_at
                FROM threads
                WHERE archived = 0 AND source = 'cli'
                '''
            )
            for session_id, cwd, title, first_user_message, updated_at in cursor.fetchall():
                if cwd not in DIRECTORIES or not session_id:
                    continue
                fallback = str(session_id)[:8]
                summary = normalize_summary(
                    str(title or first_user_message or fallback),
                    fallback,
                )
                record = {{
                    'directory': str(cwd),
                    'id': str(session_id),
                    'summary': summary,
                    'updatedAt': int(updated_at or 0),
                }}
                existing = rows_by_id.get(record['id'])
                if existing is None or record['updatedAt'] > existing['updatedAt']:
                    rows_by_id[record['id']] = record
        except sqlite3.Error:
            continue
        finally:
            connection.close()
    return list(rows_by_id.values())


codex_home = Path.home() / '.codex'
rows = load_rows_from_state_db(codex_home)
if not rows:
    rows = fallback_rows_from_rollouts(codex_home)
rows.sort(key=lambda item: (-item['updatedAt'], item['summary'].lower(), item['id']))
print(json.dumps({{'sessions': rows}}))
""");return'\n'.join(('set -euo pipefail','export PATH="$HOME/.local/bin:$PATH"','command -v codex >/dev/null 2>&1 || {',"  printf 'Codex CLI (`codex`) is not installed on the env. Install it there first.\\n' >&2",'  exit 1','}',"python3 - <<'PY'",B.rstrip('\n'),'PY'))
def parse_remote_session_listing(output:str,directories:tuple[str,...])->dict[str,list[SessionRecord]]:
	try:H=json.loads(output)
	except json.JSONDecodeError as I:raise RuntimeError('Codex session listing returned invalid JSON.')from I
	D=H.get('sessions')
	if not isinstance(D,list):raise RuntimeError('Codex session listing returned an invalid response.')
	A={A:[]for A in directories}
	for B in D:
		if not isinstance(B,dict):continue
		C=_string(B.get('directory'));E=_string(B.get('id'));F=_string(B.get('summary'));G=_int_value(B.get('updatedAt'))
		if not C or C not in A or not E or not F or G is None:continue
		A[C].append(SessionRecord(id=E,summary=F,updated_at=G))
	for(C,J)in A.items():A[C]=sorted(J,key=lambda session:(-session.updated_at,session.summary.lower(),session.id))
	return A
def build_launch_choices(workspace_records:list[remote_workspaces.WorkspaceRecord],sessions_by_directory:dict[str,list[SessionRecord]])->list[LaunchChoice]:
	B:list[LaunchChoice]=[]
	for A in workspace_records:
		for C in sessions_by_directory.get(A.directory,[]):B.append(LaunchChoice(project_label=A.project_label,workspace_label=A.workspace_label,directory=A.directory,session_id=C.id,session_summary=C.summary))
		B.append(LaunchChoice(project_label=A.project_label,workspace_label=A.workspace_label,directory=A.directory,session_id=None,session_summary=None))
	return B
def choose_launch_choice(env_name:str,choices:list[LaunchChoice])->LaunchChoice:
	B=choices;click.echo(f"\nCodex sessions for {env_name}\n");D:str|None=None;C:tuple[str,str]|None=None
	for(E,A)in enumerate(B,start=1):
		if A.project_label!=D:D=A.project_label;C=None;click.echo(remote_workspaces.display_directory(_project_directory_for_choice(A,B)))
		F=A.project_label,A.workspace_label
		if F!=C:C=F;click.echo(f"  {A.workspace_label}")
		if A.is_new_session:click.echo(f"    [{E}] New session")
		else:click.echo(f"    [{E}] Resume: {_resume_label(A)}")
	if len(B)==1:return B[0]
	G=click.prompt('Choose a session (input number)',type=click.IntRange(1,len(B)));return B[G-1]
def exec_codex(env_id:str,ssh_details:ssh_access.EnvSshAccess,choice:LaunchChoice)->None:A=build_remote_codex_command(choice);ssh_access.exec_ssh(env_id,ssh_details,(f"bash -lc {shlex.quote(A)}",),allocate_tty=True)
def build_remote_codex_command(choice:LaunchChoice)->str:
	A=choice;B=['export PATH="$HOME/.local/bin:$PATH"',"command -v codex >/dev/null 2>&1 || { printf 'Codex CLI (`codex`) is not installed on the env. Install it there first.\\n' >&2; exit 1; }",f"cd {shlex.quote(A.directory)}",'exec codex']
	if A.session_id:B[-1]=f"exec codex resume {shlex.quote(A.session_id)}"
	return' && '.join(B)
def _project_directory_for_choice(choice:LaunchChoice,choices:list[LaunchChoice])->str:
	B=choice
	for A in choices:
		if A.project_label==B.project_label and A.workspace_label=='main':return A.directory
	return B.directory
def _resume_label(choice:LaunchChoice)->str:
	A=choice
	if not A.session_id:return''
	B=A.session_id[:8]
	if not A.session_summary or A.session_summary==A.session_id:return B
	return f"{A.session_summary} [{B}]"
def _stderr_message(result:Any,fallback:str)->str:
	A=result;B=(getattr(A,'stderr','')or'').strip();C=(getattr(A,'stdout','')or'').strip()
	if B:return B
	if C:return C
	return fallback
def _string(value:Any)->str|None:
	A=value
	if A is None:return
	B=str(A);return B or None
def _int_value(value:Any)->int|None:
	A=value
	if A is None:return
	try:return int(A)
	except(TypeError,ValueError):return