from __future__ import annotations
import asyncio,re,time
from collections import Counter
from pathlib import Path
import click
from..import github_access,ssh_access
from..analytics import capture_repo_add_unsupported
from..repo_env.client import get_json
from..repo_env.format import build_opencode_session_url,format_sync_status,format_opencode_hints,normalize_github_remote_to_https
from..repo_env.format import preview_value as _preview_value
from..repo_env.resolve import RepoRef
from.classify import classify
from.env_values import RawEnvVar,collect_env_vars
from.remote import read_git_info
from.schema import EnvVarEntry,GitInfo,RepoAddOutcome,RepoAddRequest
from.sync import post_repo_add
__all__=['handle_repo_add']
def handle_repo_add(directory_arg:str|None,*,local_only:bool=False,auto_approve:bool=False,skip_env:bool=False,target_env_id:str|None=None,target_env_name:str|None=None,target_env_url:str|None=None,target_env_vm_user:str|None=None)->int:
	K=auto_approve;J=directory_arg;G=target_env_name;F=target_env_id;B=local_only
	if not J:raise RuntimeError('Usage: gv repo add <directory>')
	A=Path(J).expanduser().resolve()
	if not A.exists():raise RuntimeError(f"Directory not found: {A}")
	if not A.is_dir():raise RuntimeError(f"Not a directory: {A}")
	E=read_git_info(A);H=normalize_github_remote_to_https(E.remote_url)
	if B and not H:capture_repo_add_unsupported(directory=A,reason='missing_git_remote',local_only=True);raise RuntimeError('Only repositories with a git remote are supported for now.')
	if not B and F and G:_require_remote_access_preflight(remote_url=H,target_env_id=F,target_env_name=G)
	C:list[EnvVarEntry]=[];I=False
	if skip_env:I=True
	else:
		L=collect_env_vars(A)
		if L:
			C=_build_entries(L)
			if not K:_print_summary(C,local_only=B);C=_review_entries(C)
	if not B and not K and not I and not _ask_send_to_backend():B=True
	D=_build_outcome(directory=A,git_info=E,entries=C,skipped_env=I,local_only=B,target_env_name=G,target_env_url=target_env_url,target_env_vm_user=target_env_vm_user)
	if not B:
		N=RepoAddRequest(local_path=str(A),name=A.name,target_env_id=F,git_remote_url=H,active_branch=E.active_branch,default_branch=E.default_branch,env_vars=C)
		try:M=asyncio.run(post_repo_add(N));_apply_sync_state(D,M);_poll_repo_sync(D,M.id)
		except RuntimeError as O:D.backend_sync_error=str(O);D.exit_code=1
	_print_outcome(D);return D.exit_code
def _print_summary(entries:list[EnvVarEntry],*,local_only:bool)->None:
	A=entries;C=sorted({A.source_path for A in A});D=sum(1 for A in A if A.is_secret);E=len(A)-D;F='file'if len(C)==1 else'files';click.echo(f"Found {len(A)} env var(s) across {len(C)} {F}: {", ".join(C)}");click.echo(f"  {D} classified as secret, {E} as plain (by key name + value entropy).")
	if not local_only:click.echo('  All values are stored securely by gv.')
	click.echo('');click.echo('Classification (S=secret, P=plain):')
	for B in A:G='S'if B.is_secret else'P';H=_preview_value(B.value,B.is_secret);click.echo(f"  [{G}] {B.key} ({B.source_path})  {H}")
	click.echo('')
def _ask_send_to_backend()->bool:return click.confirm('Save to gv?',default=True)
def _require_remote_access_preflight(*,remote_url:str|None,target_env_id:str,target_env_name:str)->None:
	A=target_env_id
	if not _is_github_remote(remote_url):return
	C=get_json(f"/v1/envs/{A}/ssh");B=C.get('ssh')
	if not isinstance(B,dict):raise RuntimeError('gv returned an invalid SSH response')
	D=ssh_access.EnvSshAccess.from_payload(B);E=github_access.github_status(A,D)
	if E=='disabled':raise click.ClickException(f"GitHub auth is disabled on {target_env_name}. Run `gv github enable` and try again.")
def _is_github_remote(remote_url:str|None)->bool:A=remote_url;return bool(A and A.lower().startswith('https://github.com/'))
def _build_entries(raw_vars:list[RawEnvVar])->list[EnvVarEntry]:return[EnvVarEntry(key=A.key,value=A.value,source_path=A.source_path,is_secret=classify(A.key,A.value))for A in raw_vars]
def _review_entries(entries:list[EnvVarEntry])->list[EnvVarEntry]:
	A=entries;B=_detect_editor();D=f"Edit in {B}? (flip classifications or drop entries)"if B else'Edit interactively? (flip classifications)'
	if not click.confirm(D,default=False):return A
	if B is None:return _flip_loop(A)
	C=_editor_review(A)
	if C is not None:return C
	click.echo(f"{B} returned nothing — falling back to interactive flip.");return _flip_loop(A)
def _detect_editor()->str|None:
	try:from click._termui_impl import Editor as B;A=B().get_editor()
	except Exception:return
	if not A:return
	return A.split()[0]
_REVIEW_LINE_RE=re.compile('^\\[(?P<marker>[SPXspx])\\]\\s*\\|\\s*(?P<key>[^|]+?)\\s*\\|\\s*(?P<source>[^|]+?)\\s*(?:\\|.*)?$')
def _render_review_doc(entries:list[EnvVarEntry])->str:A=entries;B=['# Edit markers to classify each env var:','#   [S] secret  — masked below; encrypted at rest','#   [P] plain   — shown below; encrypted at rest too','#   [X] exclude — drop this var (or just delete the line)','#','# Fields: marker | key | source | value preview','# Save and exit to apply. Abort the editor to keep the original list.',''];C=max((len(A.key)for A in A),default=1);D=max((len(A.source_path)for A in A),default=1);E=['[{m}] | {k} | {s} | {v}'.format(m='S'if A.is_secret else'P',k=A.key.ljust(C),s=A.source_path.ljust(D),v=_preview_value(A.value,A.is_secret))for A in A];return'\n'.join(B+E)+'\n'
def _parse_review_doc(doc:str,entries:list[EnvVarEntry])->list[EnvVarEntry]:
	E=entries;H={(A.key,A.source_path):A for A in E};C:dict[tuple[str,str],EnvVarEntry]={}
	for I in doc.splitlines():
		D=I.strip()
		if not D or D.startswith('#'):continue
		A=_REVIEW_LINE_RE.match(D)
		if not A:continue
		F=A.group('marker').upper();G=A.group('key').strip(),A.group('source').strip();B=H.get(G)
		if B is None or F=='X':continue
		C[G]=EnvVarEntry(key=B.key,value=B.value,source_path=B.source_path,is_secret=F=='S')
	return[C[A.key,A.source_path]for A in E if(A.key,A.source_path)in C]
def _editor_review(entries:list[EnvVarEntry])->list[EnvVarEntry]|None:
	A=entries;C=_render_review_doc(A)
	try:B=click.edit(C,require_save=True,extension='.gv-env')
	except click.UsageError:return
	if B is None:return A
	return _parse_review_doc(B,A)
def _flip_loop(entries:list[EnvVarEntry])->list[EnvVarEntry]:
	D=entries;F=Counter(A.key for A in D);E={A for(A,B)in F.items()if B>1};B={_flip_identifier(A,include_source=A.key in E):A for A in D}
	while True:
		A=click.prompt('Enter a key to flip (use KEY@source for duplicates; blank to finish)',default='',show_default=False).strip()
		if not A:break
		if A not in B:click.echo(f"Unknown key: {A}");continue
		C=B[A];B[A]=EnvVarEntry(key=C.key,value=C.value,source_path=C.source_path,is_secret=not C.is_secret);G='S'if B[A].is_secret else'P';click.echo(f"  {A} -> {G}")
	return[B[_flip_identifier(A,include_source=A.key in E)]for A in D]
def _flip_identifier(entry:EnvVarEntry,*,include_source:bool)->str:
	A=entry
	if include_source:return f"{A.key}@{A.source_path}"
	return A.key
def _build_outcome(*,directory:Path,git_info:GitInfo,entries:list[EnvVarEntry],skipped_env:bool,local_only:bool,target_env_name:str|None,target_env_url:str|None,target_env_vm_user:str|None)->RepoAddOutcome:D=target_env_vm_user;C=target_env_url;B=directory;A=entries;E=sorted({A.source_path for A in A});F=sum(1 for A in A if A.is_secret);return RepoAddOutcome(exit_code=0,repo_name=B.name,target_env_name=target_env_name,target_env_url=C,target_env_vm_user=D,opencode_session_url=build_opencode_session_url(C,D,B.name,workspace_name='onboarding'),git_remote_url=git_info.remote_url,env_captured=len(A),secrets_captured=F,env_sources=E,skipped_env=skipped_env,dry_run=local_only)
def _apply_sync_state(outcome:RepoAddOutcome,repo:RepoRef)->None:
	B=repo;A=outcome;A.sync_status=B.sync_status;A.sync_step=B.sync_step
	if B.opencode_session_id:A.opencode_session_id=B.opencode_session_id;A.opencode_session_url=build_opencode_session_url(A.target_env_url,A.target_env_vm_user,A.repo_name,B.opencode_session_id,workspace_name='onboarding')
	if B.sync_status=='failed'and B.sync_error_message:A.backend_sync_error=B.sync_error_message;A.exit_code=1
def _poll_repo_sync(outcome:RepoAddOutcome,repo_id:str,*,timeout_seconds:float=8.,interval_seconds:float=1.)->None:
	A=outcome
	if A.backend_sync_error:return
	if A.sync_status in{'ready','failed'}:return
	C=time.monotonic()+timeout_seconds
	while time.monotonic()<C:
		time.sleep(interval_seconds);D=get_json(f"/v1/repos/{repo_id}");B=D.get('repo')
		if not isinstance(B,dict):break
		E=RepoRef.from_payload(B);_apply_sync_state(A,E)
		if A.sync_status in{'ready','failed'}:return
def _print_outcome(outcome:RepoAddOutcome)->None:
	A=outcome;click.echo('');click.echo(f"Repo: {A.repo_name}")
	if A.target_env_name:click.echo(f"Target env: {A.target_env_name}")
	if A.opencode_session_url:
		if A.dry_run:click.echo(f"OpenCode: {A.opencode_session_url}")
		else:
			for B in format_opencode_hints(A.opencode_session_url,A.repo_name,has_session_id=bool(A.opencode_session_id)):click.echo(B)
	if A.git_remote_url:click.echo(f"Remote: {A.git_remote_url}")
	if A.skipped_env:click.echo('Env capture: skipped')
	else:
		click.echo(f"Env captured: {A.env_captured} ({A.secrets_captured} secret, {A.env_captured-A.secrets_captured} plain)")
		if A.env_sources:click.echo(f"Sources: {", ".join(A.env_sources)}")
	if A.dry_run:click.echo('Mode: --dry-run (nothing saved)')
	elif A.backend_sync_error:click.echo(f"Repo setup failed: {A.backend_sync_error}",err=True)
	else:click.echo('Repo setup: ok')
	if A.sync_status:
		click.echo(f"Cloud workspace: {format_sync_status(A.sync_status,A.sync_step)}")
		if A.sync_status not in{'ready','failed'}:click.echo('Cloud setup is still running. You do not need to wait.');click.echo('Check progress later with `gv repo list`.')