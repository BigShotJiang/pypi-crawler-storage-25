from __future__ import annotations
import json,os,re,shlex,subprocess,sys,time,asyncio,io
from dataclasses import dataclass
from typing import Any
from urllib import error,parse,request
import click,httpx,qrcode
from.import auth_flow,claude_launcher,codex_launcher,cursor_launcher,github_access,openai_access,opencode_launcher,petname,remote_workspaces,vscode_launcher
from.api_url import normalize_api_url,resolve_api_url
from.auth_session import CONFIG_PATH,get_api_auth_header,load_cli_config,redact_cli_config,save_cli_config
from.profile import handle_profile_apply,handle_profile_job,handle_profile_pull,handle_profile_push,handle_profile_show
from.import ssh_access
from.repo_add import handle_repo_add
from.repo_env import handle_env_add,handle_env_list,handle_env_rm,handle_repo_onboard,handle_repo_list
ENV_NAME_RE=re.compile('^[a-z0-9](?:[a-z0-9-]{1,28}[a-z0-9])?$')
EMAIL_RE=re.compile('^[^\\s@]+@[^\\s@]+\\.[^\\s@]+$')
VM_USERNAME_RE=re.compile('^[a-z][a-z0-9_-]{0,31}$')
RESERVED_ENV_NAMES={'create','use','list','destroy'}
RESERVED_VM_USERNAMES={'root'}
HTTP_USER_AGENT='gv-cli/0.1'
CURRENT_ENV_CONFIG_KEY='current_env_by_api_url'
ENV_PHASE_LABELS={'ready':'Ready','failed':'Failed','queued':'Queued','waiting_for_instance_running':'Starting cloud machine','waiting_for_public_ip':'Connecting networking','creating_cloudflare_dns_record':'Preparing URL','waiting_for_cloud_init':'Installing system packages','waiting_for_traefik_http':'Starting web access','waiting_for_tls_certificate':'Securing URL','waiting_for_opencode_upstream':'Starting workspace'}
@dataclass(frozen=True)
class CreateEnvInput:
	name:str;git_user_name:str;git_user_email:str;vm_username:str|None=None
	def to_payload(A)->dict[str,str]:
		B={'name':A.name,'gitUserName':A.git_user_name,'gitUserEmail':A.git_user_email}
		if A.vm_username:B['vmUsername']=A.vm_username
		return B
@dataclass(frozen=True)
class EnvRecord:
	id:str;name:str;domain:str;status:str;step:str;instance_id:str|None;public_ip:str|None;cf_record_id:str|None;vm_username:str;opencode_username:str;opencode_password:str;git_user_name:str;git_user_email:str;error_message:str|None;created_at:str;updated_at:str;ssh_key_fingerprint:str|None=None;url:str|None=None
	@classmethod
	def from_payload(B,payload:dict[str,Any])->'EnvRecord':A=payload;return B(id=str(A['id']),name=str(A['name']),domain=str(A['domain']),status=str(A['status']),step=str(A['step']),instance_id=_optional_string(A.get('instanceId')),public_ip=_optional_string(A.get('publicIp')),cf_record_id=_optional_string(A.get('cfRecordId')),vm_username=str(A.get('vmUsername')or A['opencodeUsername']),opencode_username=str(A['opencodeUsername']),opencode_password=str(A['opencodePassword']),git_user_name=str(A['gitUserName']),git_user_email=str(A['gitUserEmail']),ssh_key_fingerprint=_optional_string(A.get('sshKeyFingerprint')),error_message=_optional_string(A.get('errorMessage')),created_at=str(A['createdAt']),updated_at=str(A['updatedAt']),url=_optional_string(A.get('url')))
class ApiRequestError(RuntimeError):
	def __init__(A,message:str,status_code:int):super().__init__(message);A.status_code=status_code
@dataclass(frozen=True)
class SshTargetChoice:label:str;directory:str|None;project_directory:str|None=None
def _optional_string(value:Any)->str|None:
	A=value
	if A is None:return
	return str(A)
def _display_env_phase(env:EnvRecord)->str:
	A=env
	if A.status=='ready':return ENV_PHASE_LABELS['ready']
	if A.status=='failed':return ENV_PHASE_LABELS['failed']
	return ENV_PHASE_LABELS.get(A.step,'Setting up')
def _opencode_basic_auth_url(env:EnvRecord)->str:
	B=env
	if not B.url:raise RuntimeError('Environment does not have a web URL yet.')
	A=parse.urlsplit(B.url);C=parse.quote(B.opencode_username,safe='');D=parse.quote(B.opencode_password,safe='');E=f"{C}:{D}@{A.netloc}";return parse.urlunsplit((A.scheme,E,A.path,A.query,A.fragment))
def _redact_url_credentials(url:str)->str:
	A=parse.urlsplit(url)
	if'@'not in A.netloc:return url
	B,B,C=A.netloc.rpartition('@');return parse.urlunsplit((A.scheme,C,A.path,A.query,A.fragment))
def print_env_qr(env:EnvRecord)->None:
	A=env
	if not A.url:raise RuntimeError('Environment does not have a web URL yet.')
	B=qrcode.QRCode(border=2);B.add_data(A.url);B.make(fit=True);C=io.StringIO();B.print_ascii(out=C,tty=False,invert=True);click.echo('\nOpen on mobile\n');click.echo(C.getvalue().rstrip());click.echo(f"\nScans to: {A.url}");click.echo('Sign in with:');click.echo(f"  Username: {A.opencode_username}");click.echo(f"  Password: {A.opencode_password}")
def normalize_env_name(value:str)->str:return value.strip().lower()
def validate_create_env_input(name:str,git_user_name:str,git_user_email:str,vm_username:str|None=None)->CreateEnvInput:
	B=normalize_env_name(name);C=git_user_name.strip();D=git_user_email.strip();A=(vm_username or'').strip().lower()or None
	if not ENV_NAME_RE.match(B):raise ValueError('Environment name must be 3-30 chars of lowercase letters, numbers, or hyphens, and cannot start or end with a hyphen.')
	if B in RESERVED_ENV_NAMES:raise ValueError('Environment name is reserved and cannot be used.')
	if len(C)<2:raise ValueError('Git author name must be at least 2 characters.')
	if not EMAIL_RE.match(D):raise ValueError('Git author email must look like an email address.')
	if A:
		if A in RESERVED_VM_USERNAMES:raise ValueError('Environment username is reserved and cannot be used.')
		if not VM_USERNAME_RE.match(A):raise ValueError('Environment username must start with a lowercase letter and use only lowercase letters, numbers, underscores, or hyphens.')
	return CreateEnvInput(name=B,git_user_name=C,git_user_email=D,vm_username=A)
def read_git_config(key:str)->str:
	try:A=subprocess.run(['git','config','--global','--get',key],check=True,capture_output=True,text=True)
	except(FileNotFoundError,subprocess.CalledProcessError):return''
	return A.stdout.strip()
def default_init_values(name_arg:str|None)->tuple[str,str,str]:return normalize_env_name(name_arg or os.getenv('USER','')),read_git_config('user.name'),read_git_config('user.email')
def read_local_whoami()->str:
	try:A=subprocess.run(['whoami'],check=True,capture_output=True,text=True)
	except(FileNotFoundError,subprocess.CalledProcessError):return os.getenv('USER','').strip()
	return A.stdout.strip()or os.getenv('USER','').strip()
def is_interactive_input()->bool:return click.get_text_stream('stdin').isatty()
def check_name_availability(api_url:str,name:str)->bool:
	B=request_api_json(api_url,'GET',f"/v1/envs/check-name/{normalize_env_name(name)}");A=B.get('available')
	if not isinstance(A,bool):raise RuntimeError('gv returned an invalid availability response')
	return A
def suggest_env_name(api_url:str)->str:
	for A in petname.generate_candidates():
		if check_name_availability(api_url,A):return A
	raise click.ClickException('Could not find an available suggested environment name.')
def missing_init_options(name:str|None,git_user_name:str|None,git_user_email:str|None)->list[str]:
	A=[]
	if not(name or'').strip():A.append('--name')
	if not(git_user_name or'').strip():A.append('--git-user-name')
	if not(git_user_email or'').strip():A.append('--git-user-email')
	return A
def collect_init_input(api_url:str|None,name_arg:str|None,git_user_name_arg:str|None,git_user_email_arg:str|None)->CreateEnvInput:
	I=git_user_email_arg;H=git_user_name_arg;C=api_url;A=name_arg;M,N,O=default_init_values(A);P=read_local_whoami();Q=A if A is not None else M;J=H if H is not None else N;K=I if I is not None else O
	if not is_interactive_input():
		R=missing_init_options(Q,J,K)
		if R:raise click.ClickException('Missing required options for non-interactive use: '+', '.join(R))
		try:return validate_create_env_input(Q,J,K,P)
		except ValueError as G:raise click.ClickException(str(G))from G
	if not N or not O:click.echo('Hint: local git defaults come from `git config --global --get user.name` and `git config --global --get user.email`.\n')
	L=A is None;S=H is None;T=I is None;B=A if A is not None else suggest_env_name(C)if C else M;D=J;E=K
	while True:
		U=click.prompt('Environment name',default=B,show_default=bool(B))if L else B;V=click.prompt('Git author name',default=D,show_default=bool(D))if S else D;W=click.prompt('Git author email',default=E,show_default=bool(E))if T else E
		try:F=validate_create_env_input(U,V,W,P)
		except ValueError as G:click.echo(f"\n{G}\n",err=True);B=U;D=V;E=W;L=True;S=True;T=True;continue
		if C and not check_name_availability(C,F.name):click.echo(f"\nEnvironment name {F.name} already exists.\n",err=True);B=suggest_env_name(C);D=F.git_user_name;E=F.git_user_email;click.echo(f"Suggested available name: {B}");L=True;continue
		return F
def _parse_error_message(payload:dict[str,Any],status_code:int)->str:
	B=payload;C=B.get('error')
	if isinstance(C,str)and C:
		D=B.get('error_description')
		if isinstance(D,str)and D:return D
		return C
	A=B.get('detail')
	if isinstance(A,str)and A:return A
	if isinstance(A,list):
		E=[]
		for F in A:
			if isinstance(F,dict)and F.get('msg'):E.append(str(F['msg']))
		if E:return'; '.join(E)
	return f"Request failed with {status_code}"
def _extract_error_message(raw:str,status_code:int)->str:
	B=status_code;A=raw
	try:D=json.loads(A)if A else{}
	except json.JSONDecodeError:D={}
	C=_parse_error_message(D,B)
	if C!=f"Request failed with {B}":return C
	if A.strip():return f"Request failed with {B}: {A.strip()}"
	return C
def _request_json(method:str,url:str,payload:dict[str,Any]|None=None,*,headers:dict[str,str]|None=None)->dict[str,Any]:
	C=headers;B=payload;E=json.dumps(B).encode('utf-8')if B is not None else None;D={'Content-Type':'application/json','Accept':'application/json','User-Agent':HTTP_USER_AGENT}
	if C:D.update(C)
	F=request.Request(url,method=method,data=E,headers=D)
	try:
		with request.urlopen(F,timeout=30)as G:return json.loads(G.read().decode('utf-8'))
	except error.HTTPError as A:H=A.read().decode('utf-8');raise ApiRequestError(_extract_error_message(H,A.code),A.code)from A
	except error.URLError as A:raise RuntimeError(str(A.reason))from A
def create_env(api_url:str,input_data:CreateEnvInput)->EnvRecord:
	B=request_api_json(api_url,'POST','/v1/envs',input_data.to_payload());A=B.get('env')
	if not isinstance(A,dict):raise RuntimeError('gv returned an invalid environment response')
	return EnvRecord.from_payload(A)
def fetch_env(api_url:str,env_id:str)->EnvRecord:
	B=request_api_json(api_url,'GET',f"/v1/envs/{env_id}");A=B.get('env')
	if not isinstance(A,dict):raise RuntimeError('gv returned an invalid environment response')
	return EnvRecord.from_payload(A)
def list_envs(api_url:str)->list[EnvRecord]:
	B=request_api_json(api_url,'GET','/v1/envs');A=B.get('envs')
	if not isinstance(A,list):raise RuntimeError('gv returned an invalid environment list response')
	return[EnvRecord.from_payload(A)for A in A if isinstance(A,dict)]
def find_env_by_name(envs:list[EnvRecord],name:str)->EnvRecord:
	A=normalize_env_name(name)
	for B in envs:
		if B.name==A:return B
	raise RuntimeError(f"Environment {A} not found.")
def _current_env_locks(config:dict[str,Any])->dict[str,Any]:
	A=config.get(CURRENT_ENV_CONFIG_KEY)
	if isinstance(A,dict):return A
	return{}
def read_current_env_lock(api_url:str)->dict[str,str]|None:
	A=_current_env_locks(load_cli_config()).get(api_url)
	if not isinstance(A,dict):return
	B=A.get('id');C=A.get('name')
	if not isinstance(B,str)or not B.strip():return
	if not isinstance(C,str)or not C.strip():return
	return{'id':B,'name':C}
def save_current_env_lock(api_url:str,env:EnvRecord)->None:A=load_cli_config();B=dict(_current_env_locks(A));B[api_url]={'id':env.id,'name':env.name};A[CURRENT_ENV_CONFIG_KEY]=B;save_cli_config(A)
def clear_current_env_lock(api_url:str)->None:
	A=load_cli_config();B=dict(_current_env_locks(A));B.pop(api_url,None)
	if B:A[CURRENT_ENV_CONFIG_KEY]=B
	else:A.pop(CURRENT_ENV_CONFIG_KEY,None)
	save_cli_config(A)
def _is_not_found_error(exc:RuntimeError)->bool:A=getattr(exc,'status_code',None);return A==404 or'not found'in str(exc).lower()
def _format_env_switch_list(envs:list[EnvRecord])->str:A=['Available environments:'];A.extend(f"- {A.name}: {_display_env_phase(A)} {A.url}"for A in envs);return'\n'.join(A)
def resolve_current_env(api_url:str)->EnvRecord:
	A=api_url;C=read_current_env_lock(A)
	if C is not None:
		try:D=fetch_env(A,C['id'])
		except RuntimeError as E:
			if _is_not_found_error(E):clear_current_env_lock(A);raise RuntimeError('No current env selected. Run gv env use <name>.')from E
			raise
		if D.name!=C['name']:save_current_env_lock(A,D)
		return D
	B=list_envs(A)
	if len(B)==1:save_current_env_lock(A,B[0]);return B[0]
	if not B:raise RuntimeError('No current env selected. Run gv env use <name>.')
	raise RuntimeError(f"{_format_env_switch_list(B)}\nRun gv env use <name> to choose one.")
def handle_env_use(name:str)->int:
	try:A=resolve_api_url();B=find_env_by_name(list_envs(A),name);save_current_env_lock(A,B)
	except RuntimeError as C:raise click.ClickException(str(C))from C
	click.echo(f"Current env: {B.name}");return 0
def _resolve_repo_add_env(directory:str)->tuple[str|None,str|None,str|None,str|None]:
	B=resolve_api_url();A=resolve_current_env(B)
	if A.status!='ready'or not A.public_ip:raise click.ClickException(f"Environment {A.name} is not ready yet: {_display_env_phase(A)}.")
	return A.id,A.name,A.url,A.vm_username
def request_api_json(api_url:str,method:str,path:str,payload:dict[str,Any]|None=None,*,authenticated:bool=True)->dict[str,Any]:
	B=authenticated;C:dict[str,str]={}
	if B:C['Authorization']=get_api_auth_header()
	try:return _request_json(method,f"{api_url}{path}",payload,headers=C)
	except ApiRequestError as A:
		if B and A.status_code==401:raise RuntimeError('Unauthorized. Run `gv auth --help` and try again.')from A
		raise A
def handle_login()->int:return auth_flow.login(resolve_api_url())
def handle_logout()->int:
	C=auth_flow.logout();A,B=ssh_access.clear_managed_ssh_state()
	if A or B:click.echo(f"Removed gv-managed SSH state ({A} key{"s"if A!=1 else""}, {B} config block{"s"if B!=1 else""}).")
	return C
def print_env_info(env:EnvRecord,*,title:str,sensitive:bool,github_status:str|None=None)->None:
	C=github_status;B=sensitive;A=env;click.echo(f"\n{title}\n");click.echo(f"Name: {A.name}");click.echo(f"Status: {_display_env_phase(A)}");click.echo(f"URL: {A.url}");click.echo(f"Web username: {A.opencode_username}");click.echo(f"Environment user: {A.vm_username}")
	if B:click.echo(f"Password: {A.opencode_password}")
	else:click.echo('Password: *** (reveal this with --reveal flag)')
	if A.public_ip:
		click.echo('SSH Command: gv ssh')
		if B:click.echo(f"Direct SSH host: {A.public_ip}");click.echo(f"Direct SSH user: {A.vm_username}")
	if B and A.ssh_key_fingerprint:click.echo(f"SSH key fingerprint: {A.ssh_key_fingerprint}")
	if C is not None:
		if C=='disabled':click.echo('GitHub: disabled (enable with `gv github enable`)')
		else:click.echo(f"GitHub: {C}")
	if A.error_message:click.echo(f"Error: {A.error_message}")
def select_env_interactively(envs:list[EnvRecord])->EnvRecord:
	B=[A.name for A in envs];C=click.prompt('Environment name',type=click.Choice(B,case_sensitive=False));D=normalize_env_name(C)
	for A in envs:
		if A.name==D:return A
	raise RuntimeError('Selected environment was not found')
def print_env_list(envs:list[EnvRecord])->None:
	click.echo('\nEnvironments\n')
	for A in envs:click.echo(f"- {A.name}: {_display_env_phase(A)} {A.url}")
	click.echo(f"\nUse `gv env use <name>` to choose one, for example `gv env use {envs[0].name}`.")
def print_ready_env(env:EnvRecord)->None:print_env_info(env,title='Environment ready',sensitive=True)
def handle_init(name_arg:str|None,git_user_name_arg:str|None,git_user_email_arg:str|None)->int:
	G=name_arg;N=30;C:str|None=None
	if is_interactive_input():
		try:C=resolve_api_url()
		except RuntimeError as B:raise click.ClickException(str(B))from B
	while True:
		O=collect_init_input(C,G,git_user_name_arg,git_user_email_arg)
		if C is None:
			try:C=resolve_api_url()
			except RuntimeError as B:raise click.ClickException(str(B))from B
		try:
			H=create_env(C,O);I=False
			if is_interactive_input()and openai_access.local_codex_auth_exists():I=click.confirm(f"Local Codex OpenAI auth detected at {openai_access.LOCAL_CODEX_PATH}. Enable it on the new env once it's ready?",default=True)
			J=False
			if is_interactive_input():J=click.confirm("Mirror your local shell, editor, Git settings, and common CLI tools into this cloud env when it's ready?",default=True)
			click.echo(f"\nCreating environment {H.name}...");K='';E=time.monotonic();L=E
			while True:
				A=fetch_env(C,H.id);M=f"{A.status}:{A.step}";D=time.monotonic()
				if M!=K:click.echo(f"- {_display_env_phase(A)}");K=M;L=D;E=D
				elif D-E>=N:P=int(D-L);click.echo(f"- still {_display_env_phase(A)} after {P}s");E=D
				if A.status=='ready':
					print_ready_env(A)
					if I:_apply_openai_enable(C,A)
					if is_interactive_input():
						if click.confirm(f"Switch current env to {A.name}?",default=False):save_current_env_lock(C,A);click.echo(f"Current env: {A.name}")
					else:click.echo(f"Switch to this env with: gv env use {A.name}")
					if J:_apply_profile_to_ready_env(A)
					return 0
				if A.status=='failed':raise RuntimeError(A.error_message or'Provisioning failed.')
				time.sleep(5)
		except RuntimeError as B:
			F=str(B)
			if'already exists'not in F:raise click.ClickException(F)from B
			if not is_interactive_input():raise click.ClickException(F)from B
			click.echo(f"\n{F}\n",err=True);G=None
def handle_info(reveal:bool,qr:bool=False)->int:
	C=reveal;D:str|None=None
	try:
		if C or qr:
			if not is_interactive_input():raise click.ClickException('`gv env info --reveal/--qr` requires a terminal confirmation prompt.')
			H='This will show a mobile QR code and the OpenCode password. Would you like to proceed?'if qr and not C else'This will show the OpenCode password. Would you like to proceed?'
			if not click.confirm(H,default=False):return 0
		E=resolve_api_url();A=resolve_current_env(E)
	except RuntimeError as G:raise click.ClickException(str(G))from G
	if A.public_ip:
		try:I=ssh_access.fetch_env_ssh_access(E,A.id,request_api_json);D=github_access.github_status(A.id,I)
		except RuntimeError:D='unknown'
	print_env_info(A,title='Environment info',sensitive=C,github_status=D);click.echo(f"Current env: {A.name}")
	if qr:print_env_qr(A)
	try:F=[B for B in list_envs(E)if B.id!=A.id]
	except RuntimeError:F=[]
	if F:
		click.echo('\nOther environments')
		for B in F:click.echo(f"- {B.name}: {_display_env_phase(B)} {B.url} (switch with `gv env use {B.name}`)")
	return 0
def destroy_env(api_url:str,env_id:str)->None:request_api_json(api_url,'DELETE',f"/v1/envs/{env_id}")
def handle_destroy(name:str|None,all_envs:bool,yes:bool)->int:
	F=all_envs;E=name
	if F and E:raise click.ClickException('Pass either NAME or --all, not both.')
	if not F and not E:raise click.ClickException('Pass an environment name, or --all.')
	try:C=resolve_api_url();G=list_envs(C)
	except RuntimeError as B:raise click.ClickException(str(B))from B
	if F:D=G
	else:
		try:D=[find_env_by_name(G,E)]
		except RuntimeError as B:raise click.ClickException(str(B))from B
	if not D:click.echo('No environments to destroy.');return 0
	if not yes:
		if not is_interactive_input():raise click.ClickException('Refusing to destroy without --yes in a non-interactive shell.')
		click.echo('The following environments will be destroyed:')
		for A in D:click.echo(f"- {A.name} ({A.status}) {A.url or""}".rstrip())
		if not click.confirm('This permanently deletes the selected cloud dev environment(s). Work stored only in the environment will be lost. Continue?',default=False):click.echo('Aborted.');return 1
	H=0
	for A in D:
		try:
			destroy_env(C,A.id);I=read_current_env_lock(C)
			if I and I['id']==A.id:clear_current_env_lock(C)
			click.echo(f"Destroyed {A.name}.")
		except RuntimeError as B:H=1;click.echo(f"Failed to destroy {A.name}: {B}",err=True)
	return H
def handle_ssh(ssh_args:tuple[str,...])->int:
	C=ssh_args
	try:
		D=resolve_api_url();A=resolve_current_env(D);B=ssh_access.fetch_env_ssh_access(D,A.id,request_api_json)
		if C or not is_interactive_input():return ssh_access.run_ssh(A.id,B,C)
		E=choose_ssh_target(A.name,discover_ssh_targets(A))
		if E.directory is None:ssh_access.exec_ssh(A.id,B,());return 0
		ssh_access.exec_ssh(A.id,B,(build_ssh_cd_command(E.directory),),allocate_tty=True);return 0
	except RuntimeError as F:raise click.ClickException(str(F))from F
def handle_opencode()->int:
	try:B=resolve_api_url();C=resolve_current_env(B);return opencode_launcher.handle_opencode(C)
	except RuntimeError as A:raise click.ClickException(str(A))from A
def handle_claude()->int:
	try:A=resolve_api_url();B=resolve_current_env(A);D=ssh_access.fetch_env_ssh_access(A,B.id,request_api_json);return claude_launcher.handle_claude(B,D)
	except RuntimeError as C:raise click.ClickException(str(C))from C
def handle_codex()->int:
	try:A=resolve_api_url();B=resolve_current_env(A);D=ssh_access.fetch_env_ssh_access(A,B.id,request_api_json);return codex_launcher.handle_codex(B,D)
	except RuntimeError as C:raise click.ClickException(str(C))from C
def handle_vscode()->int:
	try:A=resolve_api_url();B=resolve_current_env(A);D=ssh_access.fetch_env_ssh_access(A,B.id,request_api_json);return vscode_launcher.handle_vscode(B,D)
	except RuntimeError as C:raise click.ClickException(str(C))from C
def handle_cursor()->int:
	try:A=resolve_api_url();B=resolve_current_env(A);D=ssh_access.fetch_env_ssh_access(A,B.id,request_api_json);return cursor_launcher.handle_cursor(B,D)
	except RuntimeError as C:raise click.ClickException(str(C))from C
def discover_ssh_targets(env:EnvRecord)->list[SshTargetChoice]:
	A=[SshTargetChoice(label='~',directory=None)]
	if not env.url:return A
	try:C=asyncio.run(remote_workspaces.discover_workspace_records(env))
	except httpx.HTTPError:return A
	for B in C:A.append(SshTargetChoice(label=B.workspace_label,directory=B.directory,project_directory=B.project_directory))
	return A
def choose_ssh_target(env_name:str,choices:list[SshTargetChoice])->SshTargetChoice:
	A=choices
	if not A:raise RuntimeError('No SSH targets are available.')
	click.echo(f"\nSSH targets for {env_name}\n");C:str|None=None
	for(D,B)in enumerate(A,start=1):
		if B.directory is None:click.echo(f"  [{D}] {B.label}");continue
		if B.project_directory!=C:C=B.project_directory;click.echo(remote_workspaces.display_directory(B.project_directory or''))
		click.echo(f"  [{D}] {B.label}")
	if len(A)==1:return A[0]
	E=click.prompt('Choose an SSH target (input number)',type=click.IntRange(1,len(A)),default=1,show_default=True);return A[E-1]
def build_ssh_cd_command(directory:str)->str:A=f'cd {shlex.quote(directory)} && exec "${{SHELL:-/bin/bash}}" -i';return f"bash -lc {shlex.quote(A)}"
def handle_github_enable()->int:
	try:
		if not is_interactive_input():raise click.ClickException('`gv github enable` requires a terminal confirmation prompt before reading your local GitHub token.')
		if not click.confirm('This will read your GitHub token from the local `gh` CLI and send it to the selected environment to configure GitHub access. Do you want to continue?',default=False):return 0
		B=resolve_api_url();A=resolve_current_env(B);D=ssh_access.fetch_env_ssh_access(B,A.id,request_api_json);E=github_access.read_local_github_token();github_access.enable_github(A.id,D,E)
	except RuntimeError as C:raise click.ClickException(str(C))from C
	click.echo(f"GitHub auth enabled for {A.name}.");return 0
def handle_github_disable()->int:
	try:B=resolve_api_url();A=resolve_current_env(B);D=ssh_access.fetch_env_ssh_access(B,A.id,request_api_json);github_access.disable_github(A.id,D)
	except RuntimeError as C:raise click.ClickException(str(C))from C
	click.echo(f"GitHub auth disabled for {A.name}.");return 0
def handle_github_status()->int:
	try:B=resolve_api_url();A=resolve_current_env(B);D=ssh_access.fetch_env_ssh_access(B,A.id,request_api_json);E=github_access.github_status(A.id,D)
	except RuntimeError as C:raise click.ClickException(str(C))from C
	click.echo(f"{A.name}: {E}");return 0
def handle_openai_enable()->int:
	try:
		if not is_interactive_input():raise click.ClickException('`gv openai enable` requires a terminal confirmation prompt before reading your local Codex auth.')
		if not openai_access.local_codex_auth_exists():raise click.ClickException(openai_access.LOCAL_CODEX_MISSING_HINT)
		if not click.confirm(f"This will read {openai_access.LOCAL_CODEX_PATH} and upload its contents to the selected environment so OpenAI-powered tools are signed in there too. Continue?",default=False):return 0
		B=resolve_api_url();A=resolve_current_env(B);D=ssh_access.fetch_env_ssh_access(B,A.id,request_api_json);E=openai_access.read_local_codex_auth();openai_access.enable_openai(A.id,D,E)
	except RuntimeError as C:raise click.ClickException(str(C))from C
	click.echo(f"OpenAI auth enabled for {A.name}.");return 0
def handle_openai_status()->int:
	try:B=resolve_api_url();A=resolve_current_env(B);D=ssh_access.fetch_env_ssh_access(B,A.id,request_api_json);E=openai_access.openai_status(A.id,D)
	except RuntimeError as C:raise click.ClickException(str(C))from C
	click.echo(f"{A.name}: {openai_access.format_status(E)}");return 0
def _apply_openai_enable(api_url:str,env:'EnvRecord')->None:
	A=env;click.echo(f"\nEnabling OpenAI auth on {A.name}...")
	try:B=ssh_access.fetch_env_ssh_access(api_url,A.id,request_api_json);C=openai_access.read_local_codex_auth();openai_access.enable_openai(A.id,B,C)
	except RuntimeError as D:click.echo(f"OpenAI auth not enabled: {D}",err=True);return
	click.echo(f"OpenAI auth enabled for {A.name}.")
def _apply_profile_to_ready_env(env:'EnvRecord')->None:
	click.echo(f"\nMirroring your local dev setup to {env.name}...")
	try:handle_profile_push(json_out=False,env_name=env.name,no_wait=False)
	except Exception as A:click.echo(f"Dev setup was not mirrored: {A}",err=True);return
class OrderedGroup(click.Group):
	def list_commands(A,ctx:click.Context)->list[str]:return list(A.commands)
@click.group(cls=OrderedGroup,context_settings={'help_option_names':['-h','--help']},help='Provision always on cloud dev environments.\n\nAgent Instructions:\n  Some commands may prompt for missing required input.\n  Prompting is intended for human use.\n  For agent or CI usage, always pass required options explicitly.\n  If required options are missing in a non-interactive environment, the command will fail instead of prompting.\n\n')
def cli()->None:0
@cli.group('env',cls=OrderedGroup,help='Manage cloud dev environments.')
def env_group()->None:0
@env_group.command('create',help='Create a new environment. Prompts for missing required values when run in a terminal.')
@click.option('--name',help='Environment name.')
@click.option('--git-user-name',help='Git author name for commits made in the environment.')
@click.option('--git-user-email',help='Git author email for commits made in the environment.')
def env_create_command(name:str|None,git_user_name:str|None,git_user_email:str|None)->None:handle_init(name,git_user_name,git_user_email)
@env_group.command('list',help='List environments you own.')
@click.option('--json','json_out',is_flag=True,help='Emit JSON.')
def env_list_command(json_out:bool)->None:raise click.exceptions.Exit(handle_env_ls(json_out))
@env_group.command('info',help='Show current environment connection details.')
@click.option('--reveal',is_flag=True,help='Prompt before including sensitive fields like the OpenCode password.')
@click.option('--qr',is_flag=True,help='Prompt before showing a mobile login QR code for OpenCode.')
def env_info_command(reveal:bool,qr:bool)->None:raise click.exceptions.Exit(handle_info(reveal,qr))
@env_group.command('use',help='Select the current environment.')
@click.argument('name')
def env_use_command(name:str)->None:raise click.exceptions.Exit(handle_env_use(name))
@env_group.command('destroy',help='Permanently delete an environment and its cloud resources. Use --all to delete every env you own.')
@click.argument('name',required=False)
@click.option('--all','all_envs',is_flag=True,help='Destroy every environment you own.')
@click.option('--yes',is_flag=True,help='Skip the confirmation prompt.')
def env_destroy_command(name:str|None,all_envs:bool,yes:bool)->None:raise click.exceptions.Exit(handle_destroy(name,all_envs,yes))
_EDITOR_CHOICES='opencode','claude','codex','vscode','cursor'
def handle_env_ls(json_out:bool)->int:
	try:D=resolve_api_url();B=list_envs(D)
	except RuntimeError as E:raise click.ClickException(str(E))from E
	if json_out:click.echo(json.dumps([{'id':A.id,'name':A.name,'status':A.status,'step':A.step,'url':A.url,'public_ip':A.public_ip,'created_at':A.created_at}for A in B],indent=2,sort_keys=True));return 0
	if not B:click.echo('No environments.');return 0
	F=read_current_env_lock(D);C=[('NAME','STATUS','URL')]
	for A in B:G='*'if F and F['id']==A.id else' ';C.append((f"{G} {A.name}",_display_env_phase(A),A.url or'-'))
	H=[max(len(B[A])for B in C)for A in range(3)]
	for I in C:click.echo('  '.join(I[A].ljust(H[A])for A in range(3)))
	return 0
@cli.group('auth',cls=OrderedGroup,help='Log in to gv.')
def auth_group()->None:0
@auth_group.command('login',help='Log in to gv.')
def auth_login_command()->None:raise click.exceptions.Exit(handle_login())
@auth_group.command('logout',help='Log out of gv on this machine.')
def auth_logout_command()->None:raise click.exceptions.Exit(handle_logout())
@cli.command('info',help='Show current environment connection details.')
@click.option('--reveal',is_flag=True,help='Prompt before including sensitive fields like the OpenCode password.')
@click.option('--qr',is_flag=True,help='Prompt before showing a mobile login QR code for OpenCode.')
def info(reveal:bool,qr:bool)->None:raise click.exceptions.Exit(handle_info(reveal,qr))
@cli.command('ssh',context_settings={'ignore_unknown_options':True},help='SSH into the current environment. Pass a remote command after `--` to run it over SSH.')
@click.argument('ssh_args',nargs=-1,type=click.UNPROCESSED)
def ssh(ssh_args:tuple[str,...])->None:raise click.exceptions.Exit(handle_ssh(ssh_args))
@cli.command('open',help='Open a local editor attached to the current environment over SSH.')
@click.argument('editor',required=False,type=click.Choice(_EDITOR_CHOICES),default='opencode')
def open_command(editor:str)->None:
	A=editor
	if A=='opencode':raise click.exceptions.Exit(handle_opencode())
	if A=='claude':raise click.exceptions.Exit(handle_claude())
	if A=='codex':raise click.exceptions.Exit(handle_codex())
	if A=='vscode':raise click.exceptions.Exit(handle_vscode())
	if A=='cursor':raise click.exceptions.Exit(handle_cursor())
	raise click.ClickException(f"Unknown editor: {A}")
@cli.group(help='Manage CLI configuration.')
def config()->None:0
@cli.group('repo',cls=OrderedGroup,help='Repo onboarding commands.')
def repo_group()->None:0
@cli.group('github',cls=OrderedGroup,help='Manage GitHub access on an environment.')
def github_group()->None:0
@config.command('set-api-url',help='Save the gv API URL.')
@click.argument('url')
def config_set_api_url(url:str)->None:
	try:B=normalize_api_url(url);C=load_cli_config();C['api_url']=B;save_cli_config(C);click.echo(f"Saved api_url to {CONFIG_PATH}");click.echo(B)
	except ValueError as A:raise click.ClickException(str(A))from A
	except RuntimeError as A:raise click.ClickException(str(A))from A
@config.command('show',help='Show the saved CLI configuration.')
def config_show()->None:
	try:B=load_cli_config();click.echo(json.dumps(redact_cli_config(B),indent=2,sort_keys=True))
	except RuntimeError as A:raise click.ClickException(str(A))from A
@github_group.command('enable',help='Enable GitHub auth on an environment.')
def github_enable_command()->None:raise click.exceptions.Exit(handle_github_enable())
@github_group.command('disable',help='Remove GitHub auth from an environment.')
def github_disable_command()->None:raise click.exceptions.Exit(handle_github_disable())
@github_group.command('status',help='Show GitHub auth status on an environment.')
def github_status_command()->None:raise click.exceptions.Exit(handle_github_status())
@cli.group('openai',cls=OrderedGroup,help='Manage OpenAI auth on an environment.')
def openai_group()->None:0
@openai_group.command('enable',help='Push local Codex OpenAI auth (~/.codex/auth.json) to an environment.')
def openai_enable_command()->None:raise click.exceptions.Exit(handle_openai_enable())
@openai_group.command('status',help='Show OpenAI auth status on an environment.')
def openai_status_command()->None:raise click.exceptions.Exit(handle_openai_status())
@repo_group.command('add',help='Set up a repo in a cloud environment.')
@click.argument('directory',type=click.Path(exists=True,file_okay=False,path_type=str))
@click.option('--dry-run',is_flag=True,help='Preview what would be saved without changing anything.')
@click.option('--yes','auto_approve',is_flag=True,help='Accept the default classification without an interactive review.')
@click.option('--skip-env','skip_env',is_flag=True,help='Skip env var discovery entirely.')
def repo_add_command(directory:str,dry_run:bool,auto_approve:bool,skip_env:bool)->None:
	B=dry_run;A=directory;C:str|None=None;D:str|None=None;E:str|None=None;F:str|None=None
	if not B:
		try:C,D,E,F=_resolve_repo_add_env(A)
		except RuntimeError as G:raise click.ClickException(str(G))from G
	raise click.exceptions.Exit(handle_repo_add(A,local_only=B,auto_approve=auto_approve,skip_env=skip_env,target_env_id=C,target_env_name=D,target_env_url=E,target_env_vm_user=F))
@repo_group.command('list',help='List repos you have registered.')
@click.option('--json','json_out',is_flag=True,help='Emit JSON.')
def repo_list_command(json_out:bool)->None:raise click.exceptions.Exit(handle_repo_list(json_out=json_out))
@repo_group.group('env',cls=OrderedGroup,help='Manage env vars / secrets on a repo.')
def repo_env_group()->None:0
def _repo_flag(func):return click.option('--repo','repo',default=None,help='Repo id (or id-prefix / name). Defaults to the repo at $PWD.')(func)
@repo_group.command('onboard',help='Re-run cloud setup for an already-registered repo.')
@_repo_flag
def repo_onboard_command(repo:str|None)->None:raise click.exceptions.Exit(handle_repo_onboard(repo=repo))
@repo_env_group.command('list',help='List env vars / secrets on a repo.')
@_repo_flag
@click.option('--reveal',is_flag=True,help='Show secret values in plaintext.')
@click.option('--json','json_out',is_flag=True,help='Emit JSON.')
def repo_env_list_command(repo:str|None,reveal:bool,json_out:bool)->None:raise click.exceptions.Exit(handle_env_list(repo=repo,reveal=reveal,json_out=json_out))
@repo_env_group.command('add',help='Upsert an env var on a repo (KEY=VALUE).')
@_repo_flag
@click.argument('assignment')
@click.option('--source',default='.env',show_default=True,help='Source path recorded with the entry (relative to repo root).')
@click.option('--secret/--plain','mark_secret',default=None,help="Override auto-classification. If unset, the CLI's classifier decides.")
def repo_env_add_command(repo:str|None,assignment:str,source:str,mark_secret:bool|None)->None:raise click.exceptions.Exit(handle_env_add(repo=repo,assignment=assignment,source=source,mark_secret=mark_secret))
@repo_env_group.command('rm',help='Delete an env var from a repo.')
@_repo_flag
@click.argument('key')
@click.option('--source',default=None,help='Restrict delete to this source path. Required if the key is ambiguous.')
@click.option('--yes','yes',is_flag=True,help='Skip the confirmation prompt.')
def repo_env_rm_command(repo:str|None,key:str,source:str|None,yes:bool)->None:raise click.exceptions.Exit(handle_env_rm(repo=repo,key=key,source=source,yes=yes))
@cli.group('profile',cls=OrderedGroup,help='Capture your local dev environment.')
def profile_group()->None:0
@profile_group.command('show',help='Print your locally-detected profile. No upload.')
@click.option('--json','json_out',is_flag=True,help='Emit JSON.')
def profile_show_command(json_out:bool)->None:handle_profile_show(json_out)
@profile_group.command('push',help='Save your local dev profile to gv.')
@click.option('--apply','apply_current',is_flag=True,help='After pushing, install the profile on the current env.')
@click.option('--no-wait','no_wait',is_flag=True,help='With --apply, return immediately instead of waiting for mirroring to finish.')
@click.option('--json','json_out',is_flag=True,help='Emit JSON.')
def profile_push_command(apply_current:bool,no_wait:bool,json_out:bool)->None:
	B=no_wait;A=apply_current
	if B and not A:raise click.UsageError('--no-wait only makes sense with --apply.')
	C=None
	if A:
		try:C=resolve_current_env(resolve_api_url()).name
		except RuntimeError as D:raise click.ClickException(str(D))from D
	handle_profile_push(json_out=json_out,env_name=C,no_wait=B)
@profile_group.command('apply',help='Install the pushed profile on the current env (without re-pushing).')
@click.option('--no-wait','no_wait',is_flag=True,help='Return immediately instead of waiting for mirroring to finish.')
@click.option('--json','json_out',is_flag=True,help='Emit JSON.')
def profile_apply_command(no_wait:bool,json_out:bool)->None:
	try:B=resolve_current_env(resolve_api_url()).name
	except RuntimeError as A:raise click.ClickException(str(A))from A
	handle_profile_apply(B,json_out=json_out,no_wait=no_wait)
@profile_group.command('job',help='Show progress for a profile mirror operation.')
@click.argument('job_id')
@click.option('--watch',is_flag=True,help='Wait until the operation finishes.')
@click.option('--json','json_out',is_flag=True,help='Emit JSON.')
def profile_job_command(job_id:str,watch:bool,json_out:bool)->None:handle_profile_job(job_id,json_out=json_out,watch=watch)
@profile_group.command('pull',help='Show the dev profile saved in gv.')
@click.option('--json','json_out',is_flag=True,help='Emit JSON.')
def profile_pull_command(json_out:bool)->None:handle_profile_pull(json_out)
def main()->int:
	try:cli.main(args=sys.argv[1:],prog_name='gv',standalone_mode=False);return 0
	except click.ClickException as A:A.show();return A.exit_code
	except click.exceptions.Exit as A:return A.exit_code
	except KeyboardInterrupt:click.echo('',err=True);return 130
	except RuntimeError as A:click.echo(str(A),err=True);return 1
if __name__=='__main__':raise SystemExit(main())