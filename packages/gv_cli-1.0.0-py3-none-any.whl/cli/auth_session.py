from __future__ import annotations
import json,os,time
from dataclasses import dataclass
from pathlib import Path
from typing import Any
CONFIG_DIR=Path.home()/'.config'/'gv'
CONFIG_PATH=CONFIG_DIR/'config.json'
@dataclass(frozen=True)
class OAuthSession:
	access_token:str;expires_at:float|None
	def to_config(A)->dict[str,Any]:return{'access_token':A.access_token,'expires_at':A.expires_at}
	@classmethod
	def from_config(E,payload:Any)->'OAuthSession | None':
		A=payload
		if not isinstance(A,dict):return
		B=A.get('access_token')
		if not isinstance(B,str)or not B.strip():return
		C=A.get('expires_at');D=None
		if isinstance(C,(int,float)):D=float(C)
		return E(access_token=B,expires_at=D)
def load_cli_config()->dict[str,Any]:
	if not CONFIG_PATH.is_file():return{}
	try:return json.loads(CONFIG_PATH.read_text())
	except(OSError,json.JSONDecodeError)as A:raise RuntimeError(f"Failed to read CLI config from {CONFIG_PATH}: {A}")from A
def save_cli_config(config:dict[str,Any])->None:CONFIG_DIR.mkdir(parents=True,exist_ok=True);CONFIG_PATH.write_text(json.dumps(config,indent=2,sort_keys=True)+'\n');os.chmod(CONFIG_PATH,384)
def load_oauth_session()->OAuthSession|None:return OAuthSession.from_config(load_cli_config().get('oauth'))
def save_oauth_session(session:OAuthSession|None)->None:
	B=session;A=load_cli_config()
	if B is None:A.pop('oauth',None)
	else:A['oauth']=B.to_config()
	save_cli_config(A)
def get_valid_access_token()->str:
	A=load_oauth_session()
	if A is None:raise RuntimeError('Not logged in. Run `gv auth --help`.')
	if A.expires_at is None or A.expires_at>time.time()+60:return A.access_token
	raise RuntimeError('Your auth session has expired. Run `gv auth --help`.')
def get_api_auth_header()->str:return f"Bearer {get_valid_access_token().strip()}"
def redact_cli_config(config:dict[str,Any])->dict[str,Any]:
	B=dict(config);D=B.get('oauth')
	if isinstance(D,dict):
		A=dict(D)
		if'access_token'in A:C=str(A['access_token']);A['access_token']=f"{C[:4]}***{C[-4:]}"if len(C)>=8 else'***'
		B['oauth']=A
	return B