"""Prompting and conservative synthesis helpers for the fixed Codex moderator."""

from typing import Any

_STOP_WORDS = {
    "a",
    "an",
    "and",
    "because",
    "before",
    "for",
    "it",
    "now",
    "of",
    "the",
    "their",
    "to",
    "until",
    "we",
}
_RISK_KEYWORDS = {"blast", "cost", "danger", "failure", "migration", "risk", "risky", "safety"}
_RECOMMENDATION_KEYWORDS = {
    "adopt",
    "defer",
    "keep",
    "rewrite",
    "split",
    "wait",
}
_RECOMMENDATION_FRAMING_KEYWORDS = {
    "choose",
    "prefer",
    "recommend",
}


def build_participant_prompt(participant_id: str, topic: str) -> str:
    """Build a participant-specific review prompt for a discussion topic."""
    if participant_id == "claude":
        return (
            "Review the following topic with emphasis on correctness, "
            "maintainability, and long-term design quality.\n\n"
            f"Topic:\n{topic}"
        )
    if participant_id == "opencode":
        return (
            "Review the following topic with emphasis on implementation feasibility, "
            "execution risk, and engineering tradeoffs.\n\n"
            f"Topic:\n{topic}"
        )
    raise ValueError(f"Unsupported participant: {participant_id}")


def derive_follow_up_reason(successful_payloads: list[dict[str, Any]]) -> str | None:
    """Return a bounded follow-up reason when first-round responses do not converge."""
    points = _participant_points(successful_payloads)
    if len(points) < 2:
        return None

    token_sets = [_significant_tokens(response) for _, response in points]
    if _responses_converge(token_sets):
        return None

    risk_sets = [tokens & _RISK_KEYWORDS for tokens in token_sets]
    if any(risk_sets) and len({frozenset(risk_tokens) for risk_tokens in risk_sets}) > 1:
        return "clarify_risk"

    recommendation_actions = [_recommendation_action(response) for _, response in points]
    distinct_actions = {action for action in recommendation_actions if action is not None}
    if len(distinct_actions) == 1 and None not in recommendation_actions:
        return "clarify_recommendation"

    return "clarify_difference"


def build_follow_up_prompt(topic: str, successful_payloads: list[dict[str, Any]]) -> str | None:
    """Build the single fixed second-round prompt when a follow-up is justified."""
    reason = derive_follow_up_reason(successful_payloads)
    points = _participant_points(successful_payloads)
    if reason is None or not points:
        return None

    digests = "\n".join(f"- {participant_id}: {response}" for participant_id, response in points)
    return (
        "A second round is explicitly enabled for this discussion.\n"
        f"Follow-up reason: {reason}\n\n"
        f"Original topic:\n{topic}\n\n"
        "First-round participant digests:\n"
        f"{digests}\n\n"
        "Each successful participant should restate their recommendation briefly, "
        "give the strongest reason behind it, and state what condition would change "
        "their view."
    )


def synthesize_successful_responses(
    successful_payloads: list[dict[str, Any]],
) -> dict[str, list[str] | str]:
    """Produce a conservative, auditable synthesis from successful participant payloads."""
    points = _participant_points(successful_payloads)
    if not points:
        raise ValueError("No successful participant responses available for synthesis")

    if len(points) == 1:
        participant_id, response = points[0]
        return {
            "consensus": [],
            "disagreements": [f"{participant_id}: {response}"],
            "risks": [
                "Only one successful participant response was available; "
                "cross-participant confidence is limited."
            ],
            "recommendation": (
                "Use the available participant guidance as input, then perform manual review "
                "before committing to a decision."
            ),
            "confidence": "low",
        }

    participants = ", ".join(participant_id for participant_id, _ in points)
    return {
        "consensus": [
            f"Multiple successful participants provided input ({participants}); "
            "shared support should be confirmed manually."
        ],
        "disagreements": [f"{participant_id}: {response}" for participant_id, response in points],
        "risks": [
            "No semantic fusion was performed; participant outputs are listed verbatim for auditability."
        ],
        "recommendation": (
            "Compare participant-attributed points directly and choose options that satisfy both "
            "correctness and implementation feasibility constraints."
        ),
        "confidence": "medium",
    }


def _participant_points(payloads: list[dict[str, Any]]) -> list[tuple[str, str]]:
    points: list[tuple[str, str]] = []
    for payload in payloads:
        if payload.get("status") != "success":
            continue
        participant_id = str(payload.get("participant_id", "")).strip()
        response = str(payload.get("response", "")).strip()
        if not participant_id or not response:
            continue
        points.append((participant_id, response))
    points.sort(key=lambda item: (item[0], item[1]))
    return points


def _responses_converge(token_sets: list[set[str]]) -> bool:
    if len(token_sets) < 2:
        return True

    shared_tokens = set.intersection(*token_sets)
    if len(shared_tokens) >= 3:
        return True

    for index, left_tokens in enumerate(token_sets):
        for right_tokens in token_sets[index + 1 :]:
            union = left_tokens | right_tokens
            if not union:
                continue
            if len(left_tokens & right_tokens) / len(union) >= 0.35:
                return True
    return False


def _significant_tokens(response: str) -> set[str]:
    cleaned = "".join(character.lower() if character.isalnum() else " " for character in response)
    return {
        token
        for token in cleaned.split()
        if len(token) >= 4 and token not in _STOP_WORDS
    }


def _recommendation_action(response: str) -> str | None:
    cleaned = "".join(character.lower() if character.isalnum() else " " for character in response)
    for token in cleaned.split():
        if token in _RECOMMENDATION_KEYWORDS:
            return token
        if token in _RECOMMENDATION_FRAMING_KEYWORDS:
            continue
    return None
