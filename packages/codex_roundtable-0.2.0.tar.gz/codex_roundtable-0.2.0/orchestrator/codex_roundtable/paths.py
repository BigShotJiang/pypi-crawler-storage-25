import os
from pathlib import Path


def _validate_path_segment(value: str, label: str) -> str:
    if not value or value in {".", ".."}:
        msg = f"{label} must be a non-empty safe path segment"
        raise ValueError(msg)
    if "/" in value or "\\" in value:
        msg = f"{label} must not contain path separators"
        raise ValueError(msg)
    return value


def roundtable_home() -> Path:
    override = os.environ.get("CODEX_ROUNDTABLE_HOME")
    if override:
        return Path(override).expanduser().resolve()
    return (Path.home() / ".codex" / "codex-roundtable").resolve()


def sessions_dir() -> Path:
    return roundtable_home() / "sessions"


def runs_dir() -> Path:
    return roundtable_home() / "runs"


def logs_dir() -> Path:
    return roundtable_home() / "logs"


def session_dir(session_key: str) -> Path:
    session_key = _validate_path_segment(session_key, "session_key")
    return sessions_dir() / session_key


def session_state_path(session_key: str) -> Path:
    return session_dir(session_key) / "session.json"


def session_log_path(session_key: str) -> Path:
    session_key = _validate_path_segment(session_key, "session_key")
    return logs_dir() / "sessions" / f"{session_key}.jsonl"


def run_dir(session_key: str) -> Path:
    session_key = _validate_path_segment(session_key, "session_key")
    return runs_dir() / session_key


def run_log_path(session_key: str, run_id: str) -> Path:
    session_key = _validate_path_segment(session_key, "session_key")
    run_id = _validate_path_segment(run_id, "run_id")
    return logs_dir() / "runs" / session_key / f"{run_id}.jsonl"


def run_json_artifact_path(session_key: str, run_id: str) -> Path:
    session_key = _validate_path_segment(session_key, "session_key")
    run_id = _validate_path_segment(run_id, "run_id")
    return run_dir(session_key) / f"{run_id}.json"


def run_markdown_artifact_path(session_key: str, run_id: str) -> Path:
    session_key = _validate_path_segment(session_key, "session_key")
    run_id = _validate_path_segment(run_id, "run_id")
    return run_dir(session_key) / f"{run_id}.md"
