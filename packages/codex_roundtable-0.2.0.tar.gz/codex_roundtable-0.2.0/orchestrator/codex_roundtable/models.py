"""Shared data models used by the orchestrator runtime."""

from dataclasses import asdict, dataclass, field
from typing import Any


@dataclass(slots=True)
class ParticipantBinding:
    participant_id: str
    thread_name: str | None
    last_used_at: str | None
    run_count: int = 0


@dataclass(slots=True)
class RoundtableSession:
    session_key: str
    workspace_root: str
    session_name: str
    created_at: str
    last_used_at: str | None
    participant_bindings: list[ParticipantBinding] = field(default_factory=list)

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


@dataclass(slots=True)
class RoundtableRunArtifact:
    session_key: str
    run_id: str
    created_at: str
    markdown_path: str
    json_path: str

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)
