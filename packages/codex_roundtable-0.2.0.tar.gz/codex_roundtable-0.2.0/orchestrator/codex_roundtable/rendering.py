"""Artifact renderers for markdown and concise stdout output."""

from collections import Counter
from typing import Any


def render_artifact_markdown(artifact: dict[str, Any]) -> str:
    """Render a run artifact dictionary into deterministic markdown."""
    topic = _string_field(artifact, "topic", fallback="(unknown topic)")
    status = _string_field(artifact, "status", fallback="unknown")
    stop_reason = _optional_string_field(artifact, "stop_reason")
    participant_ids = _participant_ids(artifact)
    rounds = _rounds(artifact)
    synthesis = artifact.get("synthesis")

    lines: list[str] = [
        "# Codex Roundtable Artifact",
        "",
        f"**Topic:** {topic}",
        f"**Status:** {status}",
    ]
    if stop_reason is not None:
        lines.append(f"**Stop Reason:** {stop_reason}")

    lines.extend(["", "## Participants"])
    if participant_ids:
        for participant_id in participant_ids:
            lines.append(f"- {participant_id}")
    else:
        lines.append("- None")

    lines.extend(["", "## Round Responses"])
    if rounds:
        for round_payload in rounds:
            round_index = _string_field(round_payload, "round_index", fallback="?")
            prompt_role = _optional_string_field(round_payload, "prompt_role")
            heading = f"## Round {round_index}"
            if prompt_role is not None:
                heading += f" ({prompt_role})"
            lines.extend(["", heading])

            round_responses = round_payload.get("responses")
            if not isinstance(round_responses, list) or not round_responses:
                lines.append("No participant responses available.")
                continue

            for response_payload in round_responses:
                if not isinstance(response_payload, dict):
                    continue
                participant_id = _string_field(response_payload, "participant_id", fallback="unknown")
                response = _string_field(response_payload, "response", fallback="(no response)")
                if not response.strip():
                    response = "(no response)"
                lines.extend([f"### {participant_id}", response, ""])
    else:
        lines.extend(["No participant responses available.", ""])

    if isinstance(synthesis, dict):
        lines.extend(
            [
                "## Consensus",
                *_render_list(synthesis.get("consensus")),
                "",
                "## Disagreements",
                *_render_list(synthesis.get("disagreements")),
                "",
                "## Risks",
                *_render_list(synthesis.get("risks")),
                "",
                "## Recommendation",
                _string_field(synthesis, "recommendation", fallback="(none)"),
                "",
                "## Confidence",
                _string_field(synthesis, "confidence", fallback="unknown"),
            ]
        )
    else:
        lines.extend(
            [
                "## Synthesis",
                "No synthesis was produced for this artifact.",
            ]
        )

    return "\n".join(lines).rstrip() + "\n"


def render_artifact_stdout_summary(artifact: dict[str, Any]) -> str:
    """Render a concise single-line stdout summary for a run artifact."""
    topic = _string_field(artifact, "topic", fallback="(unknown topic)")
    status = _string_field(artifact, "status", fallback="unknown")
    round_count = len(_rounds(artifact))
    stop_reason = _optional_string_field(artifact, "stop_reason")
    responses = _summary_responses(artifact)
    status_counts = Counter(_string_field(item, "status", fallback="unknown") for item in responses)
    prefix = f"topic={topic} status={status} rounds={round_count}"
    if stop_reason is not None:
        prefix += f" stop_reason={stop_reason}"

    if status == "failed":
        return (
            f"{prefix} "
            f"No participant succeeded (success={status_counts.get('success', 0)})."
        )

    ordered_statuses = sorted(status_counts)
    counts_fragment = " ".join(
        f"{participant_status}={status_counts[participant_status]}"
        for participant_status in ordered_statuses
    )
    if not counts_fragment:
        counts_fragment = "participants=0"

    recommendation = _recommendation(artifact)
    if recommendation:
        return f"{prefix} {counts_fragment} recommendation={recommendation}"
    return f"{prefix} {counts_fragment}"


def _participant_ids(artifact: dict[str, Any]) -> list[str]:
    raw_participants = artifact.get("participants")
    if not isinstance(raw_participants, list):
        return []
    participant_ids: list[str] = []
    for item in raw_participants:
        if isinstance(item, str):
            participant_id = item.strip()
        elif isinstance(item, dict):
            participant_id = _string_field(item, "participant_id", fallback="")
        else:
            participant_id = ""
        if participant_id:
            participant_ids.append(participant_id)
    return participant_ids


def _responses(artifact: dict[str, Any]) -> list[dict[str, Any]]:
    rounds = artifact.get("rounds")
    if isinstance(rounds, list):
        responses: list[dict[str, Any]] = []
        for round_payload in rounds:
            if not isinstance(round_payload, dict):
                continue
            round_responses = round_payload.get("responses")
            if not isinstance(round_responses, list):
                continue
            for item in round_responses:
                if isinstance(item, dict):
                    responses.append(item)
        if responses:
            return responses

    # Backward compatibility for older artifact shape where participants held response payloads.
    raw_participants = artifact.get("participants")
    if not isinstance(raw_participants, list):
        return []
    responses = []
    for item in raw_participants:
        if isinstance(item, dict):
            responses.append(item)
    return responses


def _summary_responses(artifact: dict[str, Any]) -> list[dict[str, Any]]:
    rounds = _rounds(artifact)
    for round_payload in reversed(rounds):
        responses = _round_responses(round_payload)
        if any(_string_field(item, "status", fallback="unknown") == "success" for item in responses):
            return responses
    if rounds:
        return _round_responses(rounds[-1])
    return _responses(artifact)


def _rounds(artifact: dict[str, Any]) -> list[dict[str, Any]]:
    rounds = artifact.get("rounds")
    if not isinstance(rounds, list):
        return []
    return [round_payload for round_payload in rounds if isinstance(round_payload, dict)]


def _round_responses(round_payload: dict[str, Any]) -> list[dict[str, Any]]:
    round_responses = round_payload.get("responses")
    if not isinstance(round_responses, list):
        return []
    return [item for item in round_responses if isinstance(item, dict)]


def _render_list(value: Any) -> list[str]:
    if not isinstance(value, list) or not value:
        return ["- (none)"]
    lines: list[str] = []
    for item in value:
        text = str(item).strip()
        if text:
            lines.append(f"- {text}")
    return lines or ["- (none)"]


def _recommendation(artifact: dict[str, Any]) -> str | None:
    synthesis = artifact.get("synthesis")
    if not isinstance(synthesis, dict):
        return None
    recommendation = str(synthesis.get("recommendation", "")).strip()
    return recommendation or None


def _string_field(payload: dict[str, Any], key: str, fallback: str) -> str:
    value = payload.get(key)
    if value is None:
        return fallback
    rendered = str(value).strip()
    return rendered if rendered else fallback


def _optional_string_field(payload: dict[str, Any], key: str) -> str | None:
    value = payload.get(key)
    if value is None:
        return None
    rendered = str(value).strip()
    return rendered or None
