"""Discussion orchestration flow for codex-roundtable."""

from __future__ import annotations

from concurrent.futures import Future, ThreadPoolExecutor
from datetime import UTC, datetime
import hashlib
import json
from pathlib import Path
from typing import Any

from .errors import (
    RoundtableAllParticipantsFailedError,
    RoundtableInvalidArgumentsError,
)
from .locking import acquire_session_lock
from .logging_utils import append_jsonl, utc_now
from .models import ParticipantBinding, RoundtableSession
from . import moderator
from . import participants as participants_module
from . import paths
from .rendering import render_artifact_markdown
from .session_store import load_session, save_session

DEFAULT_PARTICIPANTS = ["claude", "opencode"]


def run_discussion(
    topic: str,
    workspace: str,
    session_name: str,
    participants: list[str] | None = None,
    timeout_seconds: int = 60,
    follow_up_once: bool = False,
) -> dict[str, Any]:
    """Run one discussion round, with one optional bounded follow-up round."""
    workspace_path = Path(workspace).expanduser().resolve()
    if not workspace_path.exists():
        raise RoundtableInvalidArgumentsError(f"workspace does not exist: {workspace}")
    workspace_root = str(workspace_path)
    participant_ids = _resolve_participants(participants)
    session_key = _derive_session_key(workspace_root, session_name)

    lock_path = paths.session_dir(session_key) / "session.lock"
    with acquire_session_lock(lock_path):
        started_at = utc_now()
        run_id = _generate_run_id()
        session = _load_or_create_session(
            session_key=session_key,
            workspace_root=workspace_root,
            session_name=session_name,
            created_at=started_at,
        )

        prompts: dict[str, str] = {}
        thread_names: dict[str, str | None] = {}
        for participant_id in participant_ids:
            prompts[participant_id] = moderator.build_participant_prompt(participant_id, topic)
            binding = _ensure_binding(session, participant_id)
            if binding.thread_name is None and _supports_threads(participant_id):
                binding.thread_name = _default_thread_name(session.session_key, participant_id)
            thread_names[participant_id] = binding.thread_name if _supports_threads(
                participant_id
            ) else None

        round_one_responses = _invoke_participants_parallel(
            participant_ids=participant_ids,
            prompts=prompts,
            workspace_root=workspace_root,
            thread_names=thread_names,
            timeout_seconds=timeout_seconds,
        )
        round_one_successful = [
            item for item in round_one_responses if item.get("status") == "success"
        ]

        json_path = paths.run_json_artifact_path(session_key, run_id)
        markdown_path = paths.run_markdown_artifact_path(session_key, run_id)
        artifact: dict[str, Any] = {
            "version": "2.1",
            "session_key": session_key,
            "session_name": session_name,
            "workspace_root": workspace_root,
            "topic": topic,
            "run_id": run_id,
            "moderator": "codex",
            "created_at": started_at,
            "started_at": started_at,
            "participants": participant_ids,
            "follow_up_enabled": follow_up_once,
            "follow_up_reason": None,
            "stop_reason": "round_one_complete",
            "rounds": [
                {
                    "round_index": 1,
                    "prompt_role": "initial",
                    "responses": round_one_responses,
                }
            ],
            "json_path": str(json_path),
            "markdown_path": str(markdown_path),
        }

        if not round_one_successful:
            artifact["status"] = "failed"
            artifact["stop_reason"] = "all_participants_failed"
        else:
            synthesis_payloads = round_one_successful
            artifact["status"] = (
                "ok" if len(round_one_successful) == len(round_one_responses) else "degraded"
            )
            if follow_up_once:
                follow_up_reason = moderator.derive_follow_up_reason(round_one_successful)
                artifact["follow_up_reason"] = follow_up_reason
                if follow_up_reason is None:
                    artifact["stop_reason"] = "follow_up_not_needed"
                else:
                    follow_up_prompt = moderator.build_follow_up_prompt(topic, round_one_successful)
                    follow_up_participant_ids = [
                        str(item["participant_id"]) for item in round_one_successful
                    ]
                    if follow_up_prompt is None:
                        artifact["stop_reason"] = "follow_up_not_needed"
                    else:
                        follow_up_responses = _invoke_participants_parallel(
                            participant_ids=follow_up_participant_ids,
                            prompts={
                                participant_id: follow_up_prompt
                                for participant_id in follow_up_participant_ids
                            },
                            workspace_root=workspace_root,
                            thread_names={
                                participant_id: thread_names.get(participant_id)
                                for participant_id in follow_up_participant_ids
                            },
                            timeout_seconds=timeout_seconds,
                        )
                        artifact["rounds"].append(
                            {
                                "round_index": 2,
                                "prompt_role": "follow_up",
                                "responses": follow_up_responses,
                            }
                        )
                        follow_up_successful = [
                            item for item in follow_up_responses if item.get("status") == "success"
                        ]
                        if follow_up_successful:
                            synthesis_payloads = follow_up_successful
                            artifact["stop_reason"] = "follow_up_complete"
                            artifact["status"] = (
                                "ok"
                                if len(round_one_successful) == len(round_one_responses)
                                and len(follow_up_successful) == len(follow_up_responses)
                                else "degraded"
                            )
                        else:
                            artifact["stop_reason"] = "follow_up_failed"
                            artifact["status"] = "degraded"

            artifact["synthesis"] = moderator.synthesize_successful_responses(synthesis_payloads)

        artifact["metadata"] = {"degraded": artifact["status"] != "ok"}

        finished_at = utc_now()
        artifact["ended_at"] = finished_at
        _write_artifact_files(artifact, json_path=json_path, markdown_path=markdown_path)
        _update_bindings(session, participant_ids, finished_at)
        save_session(paths.session_state_path(session_key), session)

        append_jsonl(
            paths.session_log_path(session_key),
            {
                "timestamp": finished_at,
                "event": "discussion.completed",
                "session_key": session_key,
                "run_id": run_id,
                "status": artifact["status"],
                "participants": participant_ids,
            },
        )
        append_jsonl(
            paths.run_log_path(session_key, run_id),
            {
                "timestamp": finished_at,
                "event": "run.artifact_written",
                "session_key": session_key,
                "run_id": run_id,
                "status": artifact["status"],
                "json_path": str(json_path),
                "markdown_path": str(markdown_path),
            },
        )

        if not round_one_successful:
            raise RoundtableAllParticipantsFailedError(
                "All requested participants failed for this discussion run"
            )

        return artifact


def _resolve_participants(requested: list[str] | None) -> list[str]:
    participant_ids = DEFAULT_PARTICIPANTS if requested is None else requested
    if not participant_ids:
        raise RoundtableInvalidArgumentsError("participants must not be empty")

    normalized: list[str] = []
    seen: set[str] = set()
    for value in participant_ids:
        participant_id = str(value).strip()
        if not participant_id:
            raise RoundtableInvalidArgumentsError("participant IDs must be non-empty strings")
        if participant_id in seen:
            raise RoundtableInvalidArgumentsError(
                f"Duplicate participant requested: {participant_id}"
            )
        if participant_id not in participants_module.PARTICIPANTS:
            raise RoundtableInvalidArgumentsError(
                f"Unsupported participant requested: {participant_id}"
            )
        normalized.append(participant_id)
        seen.add(participant_id)
    return normalized


def _derive_session_key(workspace_root: str, session_name: str) -> str:
    seed = f"{workspace_root}\n{session_name}".encode("utf-8")
    digest = hashlib.sha256(seed).hexdigest()
    return digest[:24]


def _load_or_create_session(
    session_key: str,
    workspace_root: str,
    session_name: str,
    created_at: str,
) -> RoundtableSession:
    state_path = paths.session_state_path(session_key)
    if state_path.exists():
        return load_session(state_path)
    return RoundtableSession(
        session_key=session_key,
        workspace_root=workspace_root,
        session_name=session_name,
        created_at=created_at,
        last_used_at=None,
        participant_bindings=[],
    )


def _ensure_binding(session: RoundtableSession, participant_id: str) -> ParticipantBinding:
    for binding in session.participant_bindings:
        if binding.participant_id == participant_id:
            return binding
    binding = ParticipantBinding(
        participant_id=participant_id,
        thread_name=None,
        last_used_at=None,
        run_count=0,
    )
    session.participant_bindings.append(binding)
    return binding


def _supports_threads(participant_id: str) -> bool:
    metadata = participants_module.PARTICIPANTS.get(participant_id, {})
    return bool(metadata.get("supports_threads", False))


def _default_thread_name(session_key: str, participant_id: str) -> str:
    return f"rt-{session_key}-{participant_id}"


def _invoke_participants_parallel(
    participant_ids: list[str],
    prompts: dict[str, str],
    workspace_root: str,
    thread_names: dict[str, str | None],
    timeout_seconds: int,
) -> list[dict[str, Any]]:
    by_participant: dict[str, dict[str, Any]] = {}
    with ThreadPoolExecutor(max_workers=max(1, len(participant_ids))) as executor:
        futures: dict[Future[dict[str, object]], str] = {}
        for participant_id in participant_ids:
            future = executor.submit(
                participants_module.invoke_participant,
                participant_id=participant_id,
                prompt=prompts[participant_id],
                workspace_root=workspace_root,
                thread_name=thread_names.get(participant_id),
                timeout_seconds=timeout_seconds,
            )
            futures[future] = participant_id

        for future, participant_id in futures.items():
            try:
                payload = future.result()
            except Exception as exc:
                by_participant[participant_id] = {
                    "participant_id": participant_id,
                    "status": "error",
                    "response": None,
                    "duration_ms": 0,
                    "error_detail": f"participant invocation crashed: {exc}",
                }
                continue
            by_participant[participant_id] = _normalize_response_payload(participant_id, payload)

    return [by_participant[participant_id] for participant_id in participant_ids]


def _normalize_response_payload(
    participant_id: str,
    payload: dict[str, object] | object,
) -> dict[str, Any]:
    if not isinstance(payload, dict):
        return {
            "participant_id": participant_id,
            "status": "error",
            "response": None,
            "duration_ms": 0,
            "error_detail": "participant returned malformed payload",
        }
    status = _coerce_text(payload.get("status"), fallback="error")
    response = _coerce_optional_text(payload.get("response"))
    error_detail = _coerce_optional_text(payload.get("error_detail"))
    duration_ms = _coerce_int(payload.get("duration_ms"))
    if status == "success" and response is None:
        return {
            "participant_id": str(payload.get("participant_id", participant_id)),
            "status": "error",
            "response": None,
            "duration_ms": duration_ms,
            "error_detail": "participant returned malformed success payload",
        }
    return {
        "participant_id": str(payload.get("participant_id", participant_id)),
        "status": status,
        "response": response,
        "duration_ms": duration_ms,
        "error_detail": error_detail,
    }


def _generate_run_id() -> str:
    return datetime.now(UTC).strftime("run-%Y%m%dT%H%M%S%fZ")


def _write_artifact_files(
    artifact: dict[str, Any],
    json_path: Path,
    markdown_path: Path,
) -> None:
    json_path.parent.mkdir(parents=True, exist_ok=True)
    json_path.write_text(
        json.dumps(artifact, indent=2, sort_keys=True),
        encoding="utf-8",
    )
    markdown_path.parent.mkdir(parents=True, exist_ok=True)
    markdown_path.write_text(
        render_artifact_markdown(artifact),
        encoding="utf-8",
    )


def _update_bindings(
    session: RoundtableSession,
    participant_ids: list[str],
    timestamp: str,
) -> None:
    for participant_id in participant_ids:
        binding = _ensure_binding(session, participant_id)
        binding.last_used_at = timestamp
        binding.run_count += 1
        if binding.thread_name is None and _supports_threads(participant_id):
            binding.thread_name = _default_thread_name(session.session_key, participant_id)
    session.last_used_at = timestamp


def _coerce_optional_text(value: object) -> str | None:
    if value is None:
        return None
    text = str(value).strip()
    return text or None


def _coerce_text(value: object, fallback: str) -> str:
    text = _coerce_optional_text(value)
    return text if text is not None else fallback


def _coerce_int(value: object) -> int:
    try:
        return int(value)
    except (TypeError, ValueError):
        return 0
