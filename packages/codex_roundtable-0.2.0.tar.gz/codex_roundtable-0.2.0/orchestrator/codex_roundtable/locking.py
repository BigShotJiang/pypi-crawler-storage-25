"""Session lock helpers for exclusive per-session operations."""

from __future__ import annotations

import fcntl
import time
from contextlib import contextmanager
from pathlib import Path
from typing import Iterator

from .errors import RoundtableLockConflictError

LockConflictError = RoundtableLockConflictError


def _read_lock_timestamp(handle) -> int | None:
    handle.seek(0)
    raw = handle.read().strip()
    if not raw:
        return None
    try:
        return int(raw)
    except ValueError:
        return None


@contextmanager
def acquire_session_lock(
    path: Path,
    stale_after_seconds: int = 600,
) -> Iterator[None]:
    """Acquire an exclusive, non-blocking lock for a session lock file."""
    path.parent.mkdir(parents=True, exist_ok=True)
    now = int(time.time())
    with path.open("a+", encoding="utf-8") as handle:
        try:
            fcntl.flock(handle.fileno(), fcntl.LOCK_EX | fcntl.LOCK_NB)
        except BlockingIOError as exc:
            locked_at = _read_lock_timestamp(handle)
            if locked_at is not None and (now - locked_at) > stale_after_seconds:
                raise LockConflictError(
                    "Session lock conflict for "
                    f"{path} (lock age={now - locked_at}s exceeds stale_after_seconds="
                    f"{stale_after_seconds}; holder may be stale)"
                ) from exc
            raise LockConflictError(f"Session lock conflict for {path}") from exc

        handle.seek(0)
        handle.truncate()
        handle.write(str(now))
        handle.flush()

        try:
            yield
        finally:
            fcntl.flock(handle.fileno(), fcntl.LOCK_UN)
