"""Shared exit codes and error-to-exit mapping for roundtable runtime."""

EXIT_OK = 0
EXIT_RUNTIME_ERROR = 1
EXIT_TIMEOUT = 2
EXIT_LOCK_CONFLICT = 3
EXIT_INVALID_ARGUMENTS = 4
EXIT_STATE_CORRUPTION = 5
EXIT_ALL_PARTICIPANTS_FAILED = 6


class RoundtableError(Exception):
    """Base class for roundtable runtime failures."""


class RoundtableTimeoutError(RoundtableError):
    """Raised when a participant or operation times out."""


class RoundtableLockConflictError(RoundtableError):
    """Raised when state locking cannot be acquired."""


class RoundtableInvalidArgumentsError(RoundtableError):
    """Raised when user arguments fail validation."""


class RoundtableStateCorruptionError(RoundtableError):
    """Raised when persisted state cannot be decoded safely."""


class RoundtableAllParticipantsFailedError(RoundtableError):
    """Raised when no participant successfully completes."""


def exit_code_for_error(exc: BaseException) -> int:
    """Map domain exceptions to process exit codes."""
    if isinstance(exc, RoundtableTimeoutError):
        return EXIT_TIMEOUT
    if isinstance(exc, RoundtableLockConflictError):
        return EXIT_LOCK_CONFLICT
    if isinstance(exc, RoundtableInvalidArgumentsError):
        return EXIT_INVALID_ARGUMENTS
    if isinstance(exc, RoundtableStateCorruptionError):
        return EXIT_STATE_CORRUPTION
    if isinstance(exc, RoundtableAllParticipantsFailedError):
        return EXIT_ALL_PARTICIPANTS_FAILED
    if isinstance(exc, RoundtableError):
        return EXIT_RUNTIME_ERROR
    return EXIT_RUNTIME_ERROR
