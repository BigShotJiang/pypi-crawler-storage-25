"""CLI entrypoint and command dispatch for codex-roundtable."""

from __future__ import annotations

import argparse
import fcntl
import json
from pathlib import Path
import sys
import time
from typing import Any

from .diagnostics import collect_doctor_payload
from .errors import (
    EXIT_INVALID_ARGUMENTS,
    EXIT_OK,
    EXIT_RUNTIME_ERROR,
    RoundtableError,
    exit_code_for_error,
)
from .orchestrator import _derive_session_key, run_discussion
from . import paths
from .rendering import render_artifact_stdout_summary
from .session_store import load_session


def main(argv: list[str] | None = None) -> int:
    parser = _build_parser()
    try:
        args = parser.parse_args(argv)
    except SystemExit as exc:
        return int(exc.code)

    command = getattr(args, "command", None)
    if command is None:
        parser.print_help()
        return EXIT_OK

    try:
        if command == "discuss":
            return _handle_discuss(args)
        if command == "doctor":
            return _handle_doctor(args)
        if command == "status":
            return _handle_status(args)
        if command == "show":
            return _handle_show(args)
        if command == "forget":
            return _handle_forget(args)
        if command == "gc":
            return _handle_gc(args)
    except RoundtableError as exc:
        _write_stderr(f"{exc}\n")
        return exit_code_for_error(exc)
    except OSError as exc:
        _write_stderr(f"{exc}\n")
        return EXIT_RUNTIME_ERROR
    return EXIT_INVALID_ARGUMENTS


def _build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="codex-roundtable",
        description="Local multi-participant discussion orchestrator.",
    )
    subparsers = parser.add_subparsers(dest="command")

    discuss = subparsers.add_parser("discuss", help="Run one discussion round.")
    discuss.add_argument("--topic", required=True)
    discuss.add_argument("--workspace", required=True)
    discuss.add_argument("--session", required=True)
    discuss.add_argument(
        "--participant",
        action="append",
        dest="participants",
        default=None,
    )
    discuss.add_argument("--timeout", type=int, default=60)
    discuss.add_argument("--follow-up-once", action="store_true")

    doctor = subparsers.add_parser("doctor", help="Run environment diagnostics.")
    doctor.add_argument("--workspace")
    doctor.add_argument("--session")

    status = subparsers.add_parser("status", help="Show persisted session state.")
    status.add_argument("--workspace", required=True)
    status.add_argument("--session", required=True)

    show = subparsers.add_parser("show", help="Show a persisted run artifact.")
    show.add_argument("--run-id", required=True)
    show.add_argument(
        "--format",
        choices=["json", "markdown"],
        default="json",
    )

    forget = subparsers.add_parser("forget", help="Remove persisted session state files.")
    forget.add_argument("--workspace", required=True)
    forget.add_argument("--session", required=True)

    gc = subparsers.add_parser("gc", help="Garbage collect old run and session files.")
    gc.add_argument("--max-age-days", type=int, default=30)

    return parser


def _handle_discuss(args: argparse.Namespace) -> int:
    artifact = run_discussion(
        topic=str(args.topic),
        workspace=str(args.workspace),
        session_name=str(args.session),
        participants=_normalize_participants(args.participants),
        timeout_seconds=int(args.timeout),
        follow_up_once=bool(args.follow_up_once),
    )
    summary = render_artifact_stdout_summary(artifact)
    _write_stdout(f"{summary}\n")
    return EXIT_OK


def _handle_doctor(args: argparse.Namespace) -> int:
    if bool(args.workspace) != bool(args.session):
        _write_stderr("doctor requires both --workspace and --session when one is provided\n")
        return EXIT_INVALID_ARGUMENTS
    payload = collect_doctor_payload(
        workspace=_optional_str(args.workspace),
        session_name=_optional_str(args.session),
    )
    _write_json(payload)
    return EXIT_OK if bool(payload.get("ok")) else EXIT_RUNTIME_ERROR


def _handle_status(args: argparse.Namespace) -> int:
    workspace_root = str(Path(str(args.workspace)).expanduser().resolve())
    session_name = str(args.session)
    session_key = _derive_session_key(workspace_root, session_name)
    path = paths.session_state_path(session_key)
    if not path.exists():
        _write_stderr(f"session state not found: workspace={workspace_root} session={session_name}\n")
        return EXIT_RUNTIME_ERROR
    session = load_session(path)
    _write_json(session.to_dict())
    return EXIT_OK


def _handle_show(args: argparse.Namespace) -> int:
    run_id = str(args.run_id)
    selected_format = str(args.format)
    artifact_path = _find_run_artifact(run_id=run_id, selected_format=selected_format)
    if artifact_path is None:
        _write_stderr(f"run artifact not found: {run_id}\n")
        return EXIT_INVALID_ARGUMENTS

    if selected_format == "json":
        payload = json.loads(artifact_path.read_text(encoding="utf-8"))
        if not isinstance(payload, dict):
            _write_stderr(f"run artifact is not a JSON object: {artifact_path}\n")
            return EXIT_RUNTIME_ERROR
        _write_json(payload)
        return EXIT_OK

    text = artifact_path.read_text(encoding="utf-8")
    if not text.endswith("\n"):
        text += "\n"
    _write_stdout(text)
    return EXIT_OK


def _handle_forget(args: argparse.Namespace) -> int:
    workspace_root = str(Path(str(args.workspace)).expanduser().resolve())
    session_key = _derive_session_key(workspace_root, str(args.session))
    targets = [
        paths.session_state_path(session_key),
        paths.session_dir(session_key) / "session.lock",
    ]
    for target in targets:
        if target.exists():
            target.unlink()
    return EXIT_OK


def _handle_gc(args: argparse.Namespace) -> int:
    max_age_days = int(args.max_age_days)
    if max_age_days < 0:
        _write_stderr("--max-age-days must be >= 0\n")
        return EXIT_INVALID_ARGUMENTS

    cutoff = time.time() - (max_age_days * 24 * 60 * 60)
    locked_session_keys = _collect_locked_session_keys()

    _gc_session_files(cutoff=cutoff, locked_session_keys=locked_session_keys)
    _gc_run_files(cutoff=cutoff, locked_session_keys=locked_session_keys)
    return EXIT_OK


def _find_run_artifact(run_id: str, selected_format: str) -> Path | None:
    suffix = ".json" if selected_format == "json" else ".md"
    filename = f"{run_id}{suffix}"
    candidates = sorted(paths.runs_dir().rglob(filename))
    if len(candidates) != 1:
        return None
    return candidates[0]


def _gc_session_files(cutoff: float, locked_session_keys: set[str]) -> None:
    sessions_root = paths.sessions_dir()
    if not sessions_root.exists():
        return
    for session_path in sessions_root.iterdir():
        if not session_path.is_dir():
            continue
        session_key = session_path.name
        if session_key in locked_session_keys:
            continue
        for candidate in session_path.iterdir():
            if not candidate.is_file():
                continue
            if candidate.stat().st_mtime < cutoff:
                candidate.unlink()
        _remove_empty_directories(session_path)


def _gc_run_files(cutoff: float, locked_session_keys: set[str]) -> None:
    runs_root = paths.runs_dir()
    if not runs_root.exists():
        return
    for session_path in runs_root.iterdir():
        if not session_path.is_dir():
            continue
        session_key = session_path.name
        if session_key in locked_session_keys:
            continue
        for candidate in session_path.iterdir():
            if not candidate.is_file():
                continue
            if candidate.stat().st_mtime < cutoff:
                candidate.unlink()
        _remove_empty_directories(session_path)


def _collect_locked_session_keys() -> set[str]:
    sessions_root = paths.sessions_dir()
    if not sessions_root.exists():
        return set()
    locked: set[str] = set()
    for session_path in sessions_root.iterdir():
        if not session_path.is_dir():
            continue
        lock_path = session_path / "session.lock"
        if _is_locked(lock_path):
            locked.add(session_path.name)
    return locked


def _is_locked(lock_path: Path) -> bool:
    if not lock_path.exists():
        return False
    try:
        with lock_path.open("a+", encoding="utf-8") as handle:
            try:
                fcntl.flock(handle.fileno(), fcntl.LOCK_EX | fcntl.LOCK_NB)
            except BlockingIOError:
                return True
            fcntl.flock(handle.fileno(), fcntl.LOCK_UN)
    except OSError:
        return True
    return False


def _remove_empty_directories(directory: Path) -> None:
    try:
        directory.rmdir()
    except OSError:
        return


def _normalize_participants(value: Any) -> list[str] | None:
    if value is None:
        return None
    if not isinstance(value, list):
        return None
    normalized: list[str] = []
    for item in value:
        text = str(item).strip()
        if text:
            normalized.append(text)
    return normalized if normalized else None


def _optional_str(value: object) -> str | None:
    if value is None:
        return None
    text = str(value).strip()
    return text or None


def _write_json(payload: dict[str, Any]) -> None:
    _write_stdout(json.dumps(payload, indent=2, sort_keys=True) + "\n")


def _write_stdout(text: str) -> None:
    sys.stdout.write(text)


def _write_stderr(text: str) -> None:
    sys.stderr.write(text)
