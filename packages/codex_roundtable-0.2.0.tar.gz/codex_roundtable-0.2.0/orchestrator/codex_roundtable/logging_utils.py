"""Lightweight logging helpers for append-only roundtable logs."""

from __future__ import annotations

import json
import os
import fcntl
from datetime import UTC, datetime
from pathlib import Path
from typing import Any


def utc_now() -> str:
    return datetime.now(UTC).isoformat().replace("+00:00", "Z")


def append_jsonl(path: Path, event: dict[str, Any]) -> None:
    """Append one JSON event line and ensure parent directories exist."""
    path.parent.mkdir(parents=True, exist_ok=True)
    line = json.dumps(event, ensure_ascii=True, sort_keys=True) + "\n"
    data = line.encode("utf-8")
    fd = os.open(path, os.O_WRONLY | os.O_APPEND | os.O_CREAT, 0o644)
    try:
        fcntl.flock(fd, fcntl.LOCK_EX)
        remaining = memoryview(data)
        while remaining:
            written = os.write(fd, remaining)
            if written <= 0:
                raise OSError("failed to write log line")
            remaining = remaining[written:]
    finally:
        fcntl.flock(fd, fcntl.LOCK_UN)
        os.close(fd)
