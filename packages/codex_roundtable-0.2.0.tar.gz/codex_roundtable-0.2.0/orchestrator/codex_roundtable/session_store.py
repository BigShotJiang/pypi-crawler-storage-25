"""Persistence helpers for session state and run artifacts."""

from __future__ import annotations

import json
from pathlib import Path
from typing import Any

from .errors import RoundtableStateCorruptionError
from .models import ParticipantBinding, RoundtableRunArtifact, RoundtableSession


def _atomic_write(path: Path, payload: dict[str, object]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    temp_path = path.with_suffix(".tmp")
    temp_path.write_text(
        json.dumps(payload, indent=2, sort_keys=True),
        encoding="utf-8",
    )
    temp_path.replace(path)


def _load_json(path: Path) -> dict[str, Any]:
    try:
        raw = path.read_text(encoding="utf-8")
        data = json.loads(raw)
    except (UnicodeDecodeError, json.JSONDecodeError) as exc:
        raise RoundtableStateCorruptionError(f"Invalid JSON in state file: {path}") from exc
    if not isinstance(data, dict):
        raise RoundtableStateCorruptionError(f"Expected JSON object in state file: {path}")
    return data


def _require_str(value: Any, field_name: str, path: Path) -> str:
    if not isinstance(value, str):
        raise RoundtableStateCorruptionError(
            f"{field_name} must be a string in state file: {path}"
        )
    return value


def _require_optional_str(value: Any, field_name: str, path: Path) -> str | None:
    if value is None:
        return None
    return _require_str(value, field_name, path)


def _require_int(value: Any, field_name: str, path: Path) -> int:
    if isinstance(value, bool) or not isinstance(value, int):
        raise RoundtableStateCorruptionError(
            f"{field_name} must be an integer in state file: {path}"
        )
    return value


def _parse_participant_bindings(
    value: Any,
    path: Path,
) -> list[ParticipantBinding]:
    if not isinstance(value, list):
        raise RoundtableStateCorruptionError(
            f"participant_bindings must be a list in state file: {path}"
        )
    parsed: list[ParticipantBinding] = []
    for item in value:
        if not isinstance(item, dict):
            raise RoundtableStateCorruptionError(
                f"participant_bindings must contain objects in state file: {path}"
            )
        try:
            parsed.append(
                ParticipantBinding(
                    participant_id=_require_str(
                        item["participant_id"], "participant_id", path
                    ),
                    thread_name=_require_optional_str(
                        item["thread_name"], "thread_name", path
                    ),
                    last_used_at=_require_optional_str(
                        item["last_used_at"], "last_used_at", path
                    ),
                    run_count=_require_int(item.get("run_count", 0), "run_count", path),
                )
            )
        except (KeyError, TypeError) as exc:
            raise RoundtableStateCorruptionError(
                f"Invalid participant binding in state file: {path}"
            ) from exc
    return parsed


def save_session(path: Path, session: RoundtableSession) -> None:
    _atomic_write(path, session.to_dict())


def load_session(path: Path) -> RoundtableSession:
    data = _load_json(path)
    try:
        participant_bindings = _parse_participant_bindings(
            data.get("participant_bindings", []),
            path,
        )
        return RoundtableSession(
            session_key=_require_str(data["session_key"], "session_key", path),
            workspace_root=_require_str(data["workspace_root"], "workspace_root", path),
            session_name=_require_str(data["session_name"], "session_name", path),
            created_at=_require_str(data["created_at"], "created_at", path),
            last_used_at=_require_optional_str(data["last_used_at"], "last_used_at", path),
            participant_bindings=participant_bindings,
        )
    except (KeyError, TypeError) as exc:
        raise RoundtableStateCorruptionError(f"Invalid session state in file: {path}") from exc


def save_run_artifact(path: Path, artifact: RoundtableRunArtifact) -> None:
    canonical_path = str(path)
    payload = artifact.to_dict()
    payload["json_path"] = canonical_path
    _atomic_write(path, payload)
    artifact.json_path = canonical_path


def load_run_artifact(path: Path) -> RoundtableRunArtifact:
    data = _load_json(path)
    try:
        _require_str(data["json_path"], "json_path", path)
        return RoundtableRunArtifact(
            session_key=_require_str(data["session_key"], "session_key", path),
            run_id=_require_str(data["run_id"], "run_id", path),
            created_at=_require_str(data["created_at"], "created_at", path),
            markdown_path=_require_str(data["markdown_path"], "markdown_path", path),
            json_path=str(path),
        )
    except (KeyError, TypeError) as exc:
        raise RoundtableStateCorruptionError(
            f"Invalid run artifact state in file: {path}"
        ) from exc
