"""Thin participant adapters for shelling out to local participant CLIs."""

from collections.abc import Callable
import subprocess
import time

CommandBuilder = Callable[[str, str, str | None, int], list[str]]
PROCESS_TIMEOUT_GRACE_SECONDS = 5


def build_claude_command(
    prompt: str,
    workspace_root: str,
    thread_name: str | None,
    timeout_seconds: int,
) -> list[str]:
    """Build a CLI command for invoking Claude through an external adapter."""
    command = [
        "codex2claude",
        "ask",
        "--prompt",
        prompt,
        "--workspace",
        workspace_root,
    ]
    if thread_name:
        command.extend(["--thread", thread_name])
    command.extend(["--timeout", str(timeout_seconds)])
    return command


def build_opencode_command(
    prompt: str,
    workspace_root: str,
    thread_name: str | None,
    timeout_seconds: int,
) -> list[str]:
    """Build a CLI command for invoking OpenCode through an external adapter."""
    command = [
        "codex2opencode",
        "ask",
        "--prompt",
        prompt,
        "--workspace",
        workspace_root,
    ]
    if thread_name:
        command.extend(["--thread", thread_name])
    command.extend(["--timeout", str(timeout_seconds)])
    return command


PARTICIPANTS: dict[str, dict[str, object]] = {
    "claude": {
        "command_builder": build_claude_command,
        "supports_threads": True,
    },
    "opencode": {
        "command_builder": build_opencode_command,
        "supports_threads": True,
    },
}


def invoke_participant(
    participant_id: str,
    prompt: str,
    workspace_root: str,
    thread_name: str | None,
    timeout_seconds: int,
) -> dict[str, object]:
    """Invoke a participant adapter command and normalize the result shape."""
    started = time.monotonic()
    metadata = PARTICIPANTS.get(participant_id)
    if metadata is None:
        finished = time.monotonic()
        return {
            "participant_id": participant_id,
            "status": "error",
            "response": None,
            "duration_ms": _duration_ms(started, finished),
            "error_detail": f"Unsupported participant: {participant_id}",
        }

    command_builder = metadata["command_builder"]
    if not callable(command_builder):
        finished = time.monotonic()
        return {
            "participant_id": participant_id,
            "status": "error",
            "response": None,
            "duration_ms": _duration_ms(started, finished),
            "error_detail": f"Invalid participant configuration for: {participant_id}",
        }
    effective_thread_name = thread_name if metadata["supports_threads"] else None
    command = command_builder(prompt, workspace_root, effective_thread_name, timeout_seconds)

    try:
        completed = subprocess.run(
            command,
            capture_output=True,
            check=False,
            text=False,
            timeout=timeout_seconds + PROCESS_TIMEOUT_GRACE_SECONDS,
        )
    except subprocess.TimeoutExpired:
        finished = time.monotonic()
        return {
            "participant_id": participant_id,
            "status": "timeout",
            "response": None,
            "duration_ms": _duration_ms(started, finished),
            "error_detail": f"Participant '{participant_id}' timed out after {timeout_seconds}s",
        }
    except FileNotFoundError:
        finished = time.monotonic()
        return {
            "participant_id": participant_id,
            "status": "error",
            "response": None,
            "duration_ms": _duration_ms(started, finished),
            "error_detail": f"Participant executable not found: {command[0]}",
        }
    except OSError as exc:
        finished = time.monotonic()
        return {
            "participant_id": participant_id,
            "status": "error",
            "response": None,
            "duration_ms": _duration_ms(started, finished),
            "error_detail": f"Participant invocation failed: {exc}",
        }

    finished = time.monotonic()
    if completed.returncode != 0:
        stderr, stderr_error = _decode_output(completed.stderr, "stderr")
        if stderr_error is not None:
            detail = stderr_error
        else:
            detail = stderr.strip()
        if not detail:
            detail = f"Participant exited with code {completed.returncode}"
        return {
            "participant_id": participant_id,
            "status": "error",
            "response": None,
            "duration_ms": _duration_ms(started, finished),
            "error_detail": detail,
        }

    response, stdout_error = _decode_output(completed.stdout, "stdout")
    if stdout_error is not None:
        return {
            "participant_id": participant_id,
            "status": "error",
            "response": None,
            "duration_ms": _duration_ms(started, finished),
            "error_detail": stdout_error,
        }
    if not response.strip():
        return {
            "participant_id": participant_id,
            "status": "error",
            "response": None,
            "duration_ms": _duration_ms(started, finished),
            "error_detail": "Participant returned malformed output (empty stdout)",
        }

    return {
        "participant_id": participant_id,
        "status": "success",
        "response": response,
        "duration_ms": _duration_ms(started, finished),
        "error_detail": None,
    }


def _duration_ms(started: float, finished: float) -> int:
    return max(0, int(round((finished - started) * 1000)))


def _decode_output(value: str | bytes, label: str) -> tuple[str, str | None]:
    if isinstance(value, str):
        return value, None
    try:
        return value.decode("utf-8"), None
    except UnicodeDecodeError:
        return "", f"Participant returned malformed output (undecodable {label})"
