"""Health diagnostics for codex-roundtable runtime dependencies."""

from __future__ import annotations

import os
from pathlib import Path
import shutil
from typing import Any

from .orchestrator import _derive_session_key
from . import paths
from .session_store import load_session


def collect_doctor_payload(
    workspace: str | None = None,
    session_name: str | None = None,
) -> dict[str, object]:
    """Collect a JSON-serializable health payload for doctor command output."""
    home_payload = _check_roundtable_home(paths.roundtable_home())
    participant_payload = _check_participant_bridges()
    session_payload = _check_session_state(workspace=workspace, session_name=session_name)

    all_participants_ok = all(
        participant_payload[participant_id]["status"] == "ok"
        for participant_id in sorted(participant_payload.keys())
    )
    session_ok = session_payload["status"] in {"ok", "missing", "skipped"}
    ok = bool(home_payload["ok"]) and all_participants_ok and session_ok
    return {
        "ok": ok,
        "roundtable_home": home_payload,
        "participants": participant_payload,
        "session_state": session_payload,
    }


def _check_roundtable_home(home: Path) -> dict[str, object]:
    error: str | None = None
    try:
        home.mkdir(parents=True, exist_ok=True)
    except OSError as exc:
        error = str(exc)

    readable = home.exists() and os.access(home, os.R_OK)
    writable = home.exists() and os.access(home, os.W_OK)
    status = "ok" if error is None and readable and writable else "error"
    payload: dict[str, object] = {
        "path": str(home),
        "exists": home.exists(),
        "readable": readable,
        "writable": writable,
        "status": status,
        "ok": status == "ok",
    }
    if error is not None:
        payload["error"] = error
    return payload


def _check_participant_bridges() -> dict[str, dict[str, object]]:
    mapping = {
        "claude": "codex2claude",
        "opencode": "codex2opencode",
    }
    payload: dict[str, dict[str, object]] = {}
    for participant_id in sorted(mapping.keys()):
        command = mapping[participant_id]
        resolved = shutil.which(command)
        payload[participant_id] = {
            "command": command,
            "status": "ok" if resolved is not None else "missing",
            "path": resolved,
        }
    return payload


def _check_session_state(
    workspace: str | None,
    session_name: str | None,
) -> dict[str, Any]:
    if workspace is None and session_name is None:
        return {"status": "skipped"}
    if workspace is None or session_name is None:
        return {
            "status": "invalid_arguments",
            "error": "workspace and session_name must be provided together",
        }

    workspace_path = Path(workspace).expanduser().resolve()
    if not workspace_path.exists():
        return {
            "status": "error",
            "error": f"workspace does not exist: {workspace}",
        }

    session_key = _derive_session_key(str(workspace_path), session_name)
    state_path = paths.session_state_path(session_key)
    if not state_path.exists():
        return {
            "status": "missing",
            "session_key": session_key,
            "path": str(state_path),
            "error": "session state missing",
        }

    try:
        load_session(state_path)
    except Exception as exc:  # pragma: no cover - covered via command-level tests.
        return {
            "status": "error",
            "session_key": session_key,
            "path": str(state_path),
            "error": str(exc),
        }

    return {
        "status": "ok",
        "session_key": session_key,
        "path": str(state_path),
    }
