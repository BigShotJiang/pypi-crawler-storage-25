import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import tempfile
import unittest


class RealRoundtableSmokeTest(unittest.TestCase):
    def test_doctor_with_real_bridges(self) -> None:
        if os.environ.get("CODEX_ROUNDTABLE_RUN_REAL_SMOKE") != "1":
            self.skipTest("Set CODEX_ROUNDTABLE_RUN_REAL_SMOKE=1 to enable real smoke checks.")
        if shutil.which("codex2claude") is None:
            self.skipTest("codex2claude not found in PATH")
        if shutil.which("codex2opencode") is None:
            self.skipTest("codex2opencode not found in PATH")

        root = Path(__file__).resolve().parents[1]
        env = os.environ.copy()
        existing = env.get("PYTHONPATH")
        orchestrator_path = str(root / "orchestrator")
        env["PYTHONPATH"] = (
            f"{orchestrator_path}{os.pathsep}{existing}"
            if existing
            else orchestrator_path
        )

        with tempfile.TemporaryDirectory() as temp_dir:
            env["CODEX_ROUNDTABLE_HOME"] = str(Path(temp_dir) / "state")
            result = subprocess.run(
                [sys.executable, "-m", "codex_roundtable", "doctor"],
                cwd=root,
                env=env,
                capture_output=True,
                text=True,
                check=False,
            )

        self.assertEqual(
            result.returncode,
            0,
            msg=f"stdout={result.stdout!r} stderr={result.stderr!r}",
        )
        payload = json.loads(result.stdout)
        self.assertIn("participants", payload)
        self.assertEqual(payload["participants"]["claude"]["status"], "ok")
        self.assertEqual(payload["participants"]["opencode"]["status"], "ok")
