import os
import json
import fcntl
import tempfile
import unittest
from datetime import datetime
from pathlib import Path
from unittest import mock


class PathsTest(unittest.TestCase):
    def test_roundtable_home_defaults_under_home_codex(self) -> None:
        from codex_roundtable.paths import roundtable_home

        with tempfile.TemporaryDirectory() as temp_dir:
            with mock.patch.dict(
                os.environ,
                {"HOME": temp_dir},
                clear=False,
            ):
                self.assertEqual(
                    roundtable_home(),
                    (Path(temp_dir) / ".codex" / "codex-roundtable").resolve(),
                )

    def test_roundtable_home_honors_override_env(self) -> None:
        from codex_roundtable.paths import roundtable_home

        with tempfile.TemporaryDirectory() as temp_dir:
            override = Path(temp_dir) / "state"
            with mock.patch.dict(
                os.environ,
                {"CODEX_ROUNDTABLE_HOME": str(override)},
                clear=False,
            ):
                self.assertEqual(roundtable_home(), override.resolve())

    def test_roundtable_layout_helpers(self) -> None:
        from codex_roundtable.paths import (
            logs_dir,
            roundtable_home,
            run_dir,
            run_markdown_artifact_path,
            run_json_artifact_path,
            run_log_path,
            runs_dir,
            session_dir,
            session_log_path,
            session_state_path,
            sessions_dir,
        )

        with tempfile.TemporaryDirectory() as temp_dir:
            with mock.patch.dict(
                os.environ,
                {"CODEX_ROUNDTABLE_HOME": str(Path(temp_dir) / "state-root")},
                clear=False,
            ):
                home = roundtable_home()
                self.assertEqual(sessions_dir(), home / "sessions")
                self.assertEqual(runs_dir(), home / "runs")
                self.assertEqual(logs_dir(), home / "logs")
                self.assertEqual(
                    session_state_path("abc123"),
                    home / "sessions" / "abc123" / "session.json",
                )
                self.assertEqual(session_dir("abc123"), home / "sessions" / "abc123")
                self.assertEqual(run_dir("abc123"), home / "runs" / "abc123")
                self.assertEqual(
                    session_log_path("abc123"),
                    home / "logs" / "sessions" / "abc123.jsonl",
                )
                self.assertEqual(
                    run_log_path("abc123", "run-1"),
                    home / "logs" / "runs" / "abc123" / "run-1.jsonl",
                )
                self.assertEqual(
                    run_json_artifact_path("abc123", "run-1"),
                    home / "runs" / "abc123" / "run-1.json",
                )
                self.assertEqual(
                    run_markdown_artifact_path("abc123", "run-1"),
                    home / "runs" / "abc123" / "run-1.md",
                )

    def test_path_helpers_reject_unsafe_segments(self) -> None:
        from codex_roundtable.paths import (
            run_dir,
            run_markdown_artifact_path,
            run_json_artifact_path,
            run_log_path,
            session_dir,
            session_log_path,
        )

        invalid_values = ("", ".", "..", "a/b", r"a\b")
        for value in invalid_values:
            with self.assertRaises(ValueError):
                session_dir(value)
            with self.assertRaises(ValueError):
                session_log_path(value)
            with self.assertRaises(ValueError):
                run_dir(value)
            with self.assertRaises(ValueError):
                run_log_path("safe-session", value)
            with self.assertRaises(ValueError):
                run_json_artifact_path("safe-session", value)
            with self.assertRaises(ValueError):
                run_markdown_artifact_path("safe-session", value)


class LoggingUtilsTest(unittest.TestCase):
    def test_append_jsonl_persists_full_line_with_short_writes(self) -> None:
        from codex_roundtable.logging_utils import append_jsonl

        with tempfile.TemporaryDirectory() as temp_dir:
            log_path = Path(temp_dir) / "logs" / "events.jsonl"
            event = {"event": "started", "seq": 1}

            real_write = os.write
            write_calls = 0

            def short_write(fd: int, data: bytes) -> int:
                nonlocal write_calls
                write_calls += 1
                if write_calls == 1:
                    first_chunk = max(1, len(data) // 2)
                    return real_write(fd, data[:first_chunk])
                return real_write(fd, data)

            flock_calls: list[int] = []

            def fake_flock(_fd: int, op: int) -> None:
                flock_calls.append(op)

            with mock.patch(
                "codex_roundtable.logging_utils.fcntl.flock",
                autospec=True,
                side_effect=fake_flock,
            ):
                with mock.patch(
                    "codex_roundtable.logging_utils.os.write",
                    autospec=True,
                    side_effect=short_write,
                ):
                    append_jsonl(log_path, event)

            self.assertGreaterEqual(write_calls, 2)
            self.assertEqual(
                flock_calls,
                [
                    fcntl.LOCK_EX,
                    fcntl.LOCK_UN,
                ],
            )

            lines = log_path.read_text(encoding="utf-8").splitlines()
            self.assertEqual(len(lines), 1)
            self.assertEqual(json.loads(lines[0]), event)

    def test_utc_now_is_zulu_iso8601(self) -> None:
        from codex_roundtable.logging_utils import utc_now

        timestamp = utc_now()
        self.assertTrue(timestamp.endswith("Z"))
        parsed = datetime.fromisoformat(timestamp.replace("Z", "+00:00"))
        self.assertIsNotNone(parsed.tzinfo)


class ModelsAndErrorsTest(unittest.TestCase):
    def test_roundtable_session_to_dict_is_typed(self) -> None:
        from codex_roundtable.models import ParticipantBinding, RoundtableSession

        session = RoundtableSession(
            session_key="session-key",
            workspace_root="/tmp/workspace",
            session_name="default",
            created_at="2026-03-28T00:00:00Z",
            last_used_at=None,
            participant_bindings=[
                ParticipantBinding(
                    participant_id="p1",
                    thread_name=None,
                    last_used_at=None,
                    run_count=1,
                )
            ],
        )

        self.assertEqual(
            session.to_dict(),
            {
                "session_key": "session-key",
                "workspace_root": "/tmp/workspace",
                "session_name": "default",
                "created_at": "2026-03-28T00:00:00Z",
                "last_used_at": None,
                "participant_bindings": [
                    {
                        "participant_id": "p1",
                        "thread_name": None,
                        "last_used_at": None,
                        "run_count": 1,
                    }
                ],
            },
        )

    def test_exit_code_mapping(self) -> None:
        from codex_roundtable.errors import (
            EXIT_ALL_PARTICIPANTS_FAILED,
            EXIT_INVALID_ARGUMENTS,
            EXIT_LOCK_CONFLICT,
            EXIT_RUNTIME_ERROR,
            EXIT_STATE_CORRUPTION,
            EXIT_TIMEOUT,
            RoundtableAllParticipantsFailedError,
            RoundtableInvalidArgumentsError,
            RoundtableLockConflictError,
            RoundtableError,
            RoundtableStateCorruptionError,
            RoundtableTimeoutError,
            exit_code_for_error,
        )

        self.assertEqual(exit_code_for_error(RoundtableTimeoutError()), EXIT_TIMEOUT)
        self.assertEqual(
            exit_code_for_error(RoundtableLockConflictError()),
            EXIT_LOCK_CONFLICT,
        )
        self.assertEqual(
            exit_code_for_error(RoundtableInvalidArgumentsError()),
            EXIT_INVALID_ARGUMENTS,
        )
        self.assertEqual(
            exit_code_for_error(RoundtableStateCorruptionError()),
            EXIT_STATE_CORRUPTION,
        )
        self.assertEqual(
            exit_code_for_error(RoundtableAllParticipantsFailedError()),
            EXIT_ALL_PARTICIPANTS_FAILED,
        )
        self.assertEqual(exit_code_for_error(RoundtableError("boom")), EXIT_RUNTIME_ERROR)
        self.assertEqual(exit_code_for_error(Exception("boom")), EXIT_RUNTIME_ERROR)
