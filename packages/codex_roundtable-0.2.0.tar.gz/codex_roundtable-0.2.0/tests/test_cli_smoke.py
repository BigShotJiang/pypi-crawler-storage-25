import io
import os
import subprocess
import sys
import tempfile
import unittest
from pathlib import Path
from unittest import mock


class CliSmokeTest(unittest.TestCase):
    def test_discuss_prints_concise_summary_when_artifact_is_returned(self) -> None:
        from codex_roundtable.cli import main

        artifact = {
            "topic": "Should we split repos?",
            "status": "degraded",
            "stop_reason": "follow_up_not_needed",
            "rounds": [
                {
                    "round_index": 1,
                    "responses": [
                        {"participant_id": "claude", "status": "success", "response": "A"},
                        {"participant_id": "opencode", "status": "error", "response": None},
                    ],
                }
            ],
            "synthesis": {
                "consensus": [],
                "disagreements": [],
                "risks": [],
                "recommendation": "Proceed with guardrails.",
                "confidence": "medium",
            },
        }

        with tempfile.TemporaryDirectory() as temp_dir:
            workspace = Path(temp_dir) / "workspace"
            workspace.mkdir(parents=True, exist_ok=True)
            stdout = io.StringIO()
            stderr = io.StringIO()
            with mock.patch(
                "codex_roundtable.cli.run_discussion",
                return_value=artifact,
            ), mock.patch("sys.stdout", stdout), mock.patch("sys.stderr", stderr):
                exit_code = main(
                    [
                        "discuss",
                        "--topic",
                        "Should we split repos?",
                        "--workspace",
                        str(workspace),
                        "--session",
                        "design",
                    ]
                )

        self.assertEqual(exit_code, 0)
        self.assertIn("topic=Should we split repos?", stdout.getvalue())
        self.assertIn("status=degraded", stdout.getvalue())
        self.assertIn("stop_reason=follow_up_not_needed", stdout.getvalue())
        self.assertEqual(stderr.getvalue(), "")

    def test_discuss_follow_up_once_flag_is_passed_into_run_discussion(self) -> None:
        from codex_roundtable.cli import main

        artifact = {
            "topic": "Should we split repos?",
            "status": "ok",
            "rounds": [
                {
                    "round_index": 1,
                    "responses": [
                        {"participant_id": "claude", "status": "success", "response": "A"},
                    ],
                }
            ],
            "synthesis": {
                "consensus": [],
                "disagreements": [],
                "risks": [],
                "recommendation": "Proceed.",
                "confidence": "medium",
            },
        }

        with tempfile.TemporaryDirectory() as temp_dir:
            workspace = Path(temp_dir) / "workspace"
            workspace.mkdir(parents=True, exist_ok=True)
            stdout = io.StringIO()
            stderr = io.StringIO()
            with mock.patch(
                "codex_roundtable.cli.run_discussion",
                return_value=artifact,
            ) as run_discussion_mock, mock.patch("sys.stdout", stdout), mock.patch(
                "sys.stderr", stderr
            ):
                exit_code = main(
                    [
                        "discuss",
                        "--topic",
                        "Should we split repos?",
                        "--workspace",
                        str(workspace),
                        "--session",
                        "design",
                        "--follow-up-once",
                    ]
                )

        self.assertEqual(exit_code, 0)
        self.assertEqual(run_discussion_mock.call_args.kwargs["follow_up_once"], True)
        self.assertEqual(stderr.getvalue(), "")

    def test_python_module_help_smoke(self) -> None:
        root = Path(__file__).resolve().parents[1]
        env = os.environ.copy()
        existing = env.get("PYTHONPATH")
        orchestrator_path = str(root / "orchestrator")
        env["PYTHONPATH"] = (
            f"{orchestrator_path}{os.pathsep}{existing}"
            if existing
            else orchestrator_path
        )

        result = subprocess.run(
            [sys.executable, "-m", "codex_roundtable", "--help"],
            cwd=root,
            env=env,
            capture_output=True,
            text=True,
            check=False,
        )
        self.assertEqual(
            result.returncode,
            0,
            msg=f"stdout={result.stdout!r} stderr={result.stderr!r}",
        )
        self.assertIn("usage:", result.stdout.lower())

    def test_discuss_maps_domain_exception_to_exit_code(self) -> None:
        from codex_roundtable.cli import main
        from codex_roundtable.errors import EXIT_INVALID_ARGUMENTS, RoundtableInvalidArgumentsError

        with tempfile.TemporaryDirectory() as temp_dir:
            workspace = Path(temp_dir) / "workspace"
            workspace.mkdir(parents=True, exist_ok=True)
            stdout = io.StringIO()
            stderr = io.StringIO()
            with mock.patch(
                "codex_roundtable.cli.run_discussion",
                side_effect=RoundtableInvalidArgumentsError("bad args"),
            ), mock.patch("sys.stdout", stdout), mock.patch("sys.stderr", stderr):
                exit_code = main(
                    [
                        "discuss",
                        "--topic",
                        "topic",
                        "--workspace",
                        str(workspace),
                        "--session",
                        "design",
                    ]
                )

        self.assertEqual(exit_code, EXIT_INVALID_ARGUMENTS)
        self.assertIn("bad args", stderr.getvalue())
