import tempfile
import unittest
import json
from pathlib import Path
from unittest import mock


class SessionStoreTest(unittest.TestCase):
    def test_session_state_roundtrip(self) -> None:
        from codex_roundtable.models import ParticipantBinding, RoundtableSession
        from codex_roundtable.session_store import load_session, save_session

        with tempfile.TemporaryDirectory() as temp_dir:
            path = Path(temp_dir) / "session.json"
            state = RoundtableSession(
                session_key="abc",
                workspace_root="/tmp/project",
                session_name="design",
                created_at="2026-03-28T00:00:00Z",
                last_used_at="2026-03-28T00:00:00Z",
                participant_bindings=[
                    ParticipantBinding(
                        participant_id="claude",
                        thread_name="thread-1",
                        last_used_at="2026-03-28T00:00:00Z",
                        run_count=2,
                    )
                ],
            )
            save_session(path, state)
            loaded = load_session(path)
            self.assertEqual(loaded, state)

    def test_run_artifact_roundtrip(self) -> None:
        from codex_roundtable.models import RoundtableRunArtifact
        from codex_roundtable.session_store import load_run_artifact, save_run_artifact

        with tempfile.TemporaryDirectory() as temp_dir:
            path = Path(temp_dir) / "runs" / "run-1.json"
            artifact = RoundtableRunArtifact(
                session_key="abc",
                run_id="run-1",
                created_at="2026-03-28T00:00:00Z",
                markdown_path="/tmp/project/runs/run-1.md",
                json_path="contradicting-input-path.json",
            )
            save_run_artifact(path, artifact)
            self.assertEqual(artifact.json_path, str(path))
            on_disk = json.loads(path.read_text(encoding="utf-8"))
            self.assertEqual(on_disk["json_path"], str(path))
            loaded = load_run_artifact(path)
            self.assertEqual(
                loaded,
                RoundtableRunArtifact(
                    session_key="abc",
                    run_id="run-1",
                    created_at="2026-03-28T00:00:00Z",
                    markdown_path="/tmp/project/runs/run-1.md",
                    json_path=str(path),
                ),
            )
            self.assertTrue(path.exists())

    def test_session_state_roundtrip_with_nullable_last_used_at(self) -> None:
        from codex_roundtable.models import RoundtableSession
        from codex_roundtable.session_store import load_session, save_session

        with tempfile.TemporaryDirectory() as temp_dir:
            path = Path(temp_dir) / "session.json"
            state = RoundtableSession(
                session_key="abc",
                workspace_root="/tmp/project",
                session_name="design",
                created_at="2026-03-28T00:00:00Z",
                last_used_at=None,
                participant_bindings=[],
            )
            save_session(path, state)
            loaded = load_session(path)
            self.assertIsNone(loaded.last_used_at)

    def test_save_functions_create_missing_parent_directories(self) -> None:
        from codex_roundtable.models import RoundtableRunArtifact, RoundtableSession
        from codex_roundtable.session_store import save_run_artifact, save_session

        with tempfile.TemporaryDirectory() as temp_dir:
            session_path = Path(temp_dir) / "a" / "b" / "session.json"
            run_path = Path(temp_dir) / "x" / "y" / "run.json"
            session = RoundtableSession(
                session_key="abc",
                workspace_root="/tmp/project",
                session_name="design",
                created_at="2026-03-28T00:00:00Z",
                last_used_at=None,
                participant_bindings=[],
            )
            artifact = RoundtableRunArtifact(
                session_key="abc",
                run_id="run-1",
                created_at="2026-03-28T00:00:00Z",
                markdown_path="/tmp/project/runs/run-1.md",
                json_path="/tmp/project/runs/run-1.json",
            )
            save_session(session_path, session)
            save_run_artifact(run_path, artifact)
            self.assertTrue(session_path.exists())
            self.assertTrue(run_path.exists())

    def test_session_corruption_raises_roundtable_state_corruption_error(self) -> None:
        from codex_roundtable.errors import RoundtableStateCorruptionError
        from codex_roundtable.session_store import load_session

        with tempfile.TemporaryDirectory() as temp_dir:
            path = Path(temp_dir) / "session.json"
            path.write_text("{not-json", encoding="utf-8")
            with self.assertRaises(RoundtableStateCorruptionError):
                load_session(path)

    def test_session_invalid_utf8_raises_roundtable_state_corruption_error(self) -> None:
        from codex_roundtable.errors import RoundtableStateCorruptionError
        from codex_roundtable.session_store import load_session

        with tempfile.TemporaryDirectory() as temp_dir:
            path = Path(temp_dir) / "session.json"
            path.write_bytes(b"\x80\x81")
            with self.assertRaises(RoundtableStateCorruptionError):
                load_session(path)

    def test_session_malformed_shape_raises_roundtable_state_corruption_error(self) -> None:
        from codex_roundtable.errors import RoundtableStateCorruptionError
        from codex_roundtable.session_store import load_session

        with tempfile.TemporaryDirectory() as temp_dir:
            path = Path(temp_dir) / "session.json"
            path.write_text(
                json.dumps(
                    {
                        "session_key": 123,
                        "workspace_root": "/tmp/project",
                        "session_name": "design",
                        "created_at": "2026-03-28T00:00:00Z",
                        "last_used_at": "2026-03-28T00:00:00Z",
                        "participant_bindings": [],
                    }
                ),
                encoding="utf-8",
            )
            with self.assertRaises(RoundtableStateCorruptionError):
                load_session(path)

    def test_run_artifact_malformed_shape_raises_roundtable_state_corruption_error(
        self,
    ) -> None:
        from codex_roundtable.errors import RoundtableStateCorruptionError
        from codex_roundtable.session_store import load_run_artifact

        with tempfile.TemporaryDirectory() as temp_dir:
            path = Path(temp_dir) / "run.json"
            path.write_text(
                json.dumps(
                    {
                        "session_key": "abc",
                        "run_id": "run-1",
                        "created_at": ["not-a-string"],
                        "markdown_path": "/tmp/project/runs/run-1.md",
                        "json_path": "/tmp/project/runs/run-1.json",
                    }
                ),
                encoding="utf-8",
            )
            with self.assertRaises(RoundtableStateCorruptionError):
                load_run_artifact(path)

    def test_load_run_artifact_normalizes_json_path_to_source_path(self) -> None:
        from codex_roundtable.session_store import load_run_artifact

        with tempfile.TemporaryDirectory() as temp_dir:
            path = Path(temp_dir) / "run.json"
            path.write_text(
                json.dumps(
                    {
                        "session_key": "abc",
                        "run_id": "run-1",
                        "created_at": "2026-03-28T00:00:00Z",
                        "markdown_path": "/tmp/project/runs/run-1.md",
                        "json_path": "/mismatched/from-disk.json",
                    }
                ),
                encoding="utf-8",
            )
            loaded = load_run_artifact(path)
            self.assertEqual(loaded.json_path, str(path))

    def test_session_malformed_participant_binding_raises_state_corruption_error(
        self,
    ) -> None:
        from codex_roundtable.errors import RoundtableStateCorruptionError
        from codex_roundtable.session_store import load_session

        with tempfile.TemporaryDirectory() as temp_dir:
            path = Path(temp_dir) / "session.json"
            path.write_text(
                json.dumps(
                    {
                        "session_key": "abc",
                        "workspace_root": "/tmp/project",
                        "session_name": "design",
                        "created_at": "2026-03-28T00:00:00Z",
                        "last_used_at": None,
                        "participant_bindings": [
                            {
                                "participant_id": "claude",
                                "thread_name": "thread-1",
                                "last_used_at": None,
                                "run_count": True,
                            }
                        ],
                    }
                ),
                encoding="utf-8",
            )
            with self.assertRaises(RoundtableStateCorruptionError):
                load_session(path)

    def test_save_session_leaves_destination_unchanged_when_temp_write_fails(self) -> None:
        from codex_roundtable.models import RoundtableSession
        from codex_roundtable.session_store import save_session

        with tempfile.TemporaryDirectory() as temp_dir:
            path = Path(temp_dir) / "session.json"
            path.write_text('{"sentinel":"old"}', encoding="utf-8")
            session = RoundtableSession(
                session_key="abc",
                workspace_root="/tmp/project",
                session_name="design",
                created_at="2026-03-28T00:00:00Z",
                last_used_at=None,
                participant_bindings=[],
            )
            with mock.patch("pathlib.Path.write_text", side_effect=OSError("disk full")):
                with self.assertRaises(OSError):
                    save_session(path, session)
            self.assertEqual(path.read_text(encoding="utf-8"), '{"sentinel":"old"}')

    def test_save_session_leaves_destination_unchanged_when_replace_fails(self) -> None:
        from codex_roundtable.models import RoundtableSession
        from codex_roundtable.session_store import save_session

        with tempfile.TemporaryDirectory() as temp_dir:
            path = Path(temp_dir) / "session.json"
            path.write_text('{"sentinel":"old"}', encoding="utf-8")
            session = RoundtableSession(
                session_key="abc",
                workspace_root="/tmp/project",
                session_name="design",
                created_at="2026-03-28T00:00:00Z",
                last_used_at=None,
                participant_bindings=[],
            )
            with mock.patch("pathlib.Path.replace", side_effect=OSError("replace failed")):
                with self.assertRaises(OSError):
                    save_session(path, session)
            self.assertEqual(path.read_text(encoding="utf-8"), '{"sentinel":"old"}')

    def test_save_run_artifact_leaves_destination_and_memory_unchanged_when_temp_write_fails(
        self,
    ) -> None:
        from codex_roundtable.models import RoundtableRunArtifact
        from codex_roundtable.session_store import save_run_artifact

        with tempfile.TemporaryDirectory() as temp_dir:
            path = Path(temp_dir) / "run.json"
            path.write_text('{"sentinel":"old"}', encoding="utf-8")
            artifact = RoundtableRunArtifact(
                session_key="abc",
                run_id="run-1",
                created_at="2026-03-28T00:00:00Z",
                markdown_path="/tmp/project/runs/run-1.md",
                json_path="before-failed-save.json",
            )
            with mock.patch("pathlib.Path.write_text", side_effect=OSError("disk full")):
                with self.assertRaises(OSError):
                    save_run_artifact(path, artifact)
            self.assertEqual(path.read_text(encoding="utf-8"), '{"sentinel":"old"}')
            self.assertEqual(artifact.json_path, "before-failed-save.json")

    def test_save_run_artifact_leaves_destination_and_memory_unchanged_when_replace_fails(
        self,
    ) -> None:
        from codex_roundtable.models import RoundtableRunArtifact
        from codex_roundtable.session_store import save_run_artifact

        with tempfile.TemporaryDirectory() as temp_dir:
            path = Path(temp_dir) / "run.json"
            path.write_text('{"sentinel":"old"}', encoding="utf-8")
            artifact = RoundtableRunArtifact(
                session_key="abc",
                run_id="run-1",
                created_at="2026-03-28T00:00:00Z",
                markdown_path="/tmp/project/runs/run-1.md",
                json_path="before-failed-save.json",
            )
            with mock.patch("pathlib.Path.replace", side_effect=OSError("replace failed")):
                with self.assertRaises(OSError):
                    save_run_artifact(path, artifact)
            self.assertEqual(path.read_text(encoding="utf-8"), '{"sentinel":"old"}')
            self.assertEqual(artifact.json_path, "before-failed-save.json")
