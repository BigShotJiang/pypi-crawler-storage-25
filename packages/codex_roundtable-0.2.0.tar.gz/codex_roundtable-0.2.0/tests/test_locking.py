import fcntl
import tempfile
import time
import unittest
from pathlib import Path


class LockingTest(unittest.TestCase):
    def test_lock_is_held_during_context_and_released_after_exit(self) -> None:
        from codex_roundtable.locking import LockConflictError, acquire_session_lock

        with tempfile.TemporaryDirectory() as temp_dir:
            lock_path = Path(temp_dir) / "session.lock"
            with acquire_session_lock(lock_path):
                with self.assertRaises(LockConflictError):
                    with acquire_session_lock(lock_path):
                        pass
            with acquire_session_lock(lock_path):
                pass

    def test_long_held_lock_over_threshold_uses_advisory_wording(self) -> None:
        from codex_roundtable.locking import LockConflictError, acquire_session_lock

        with tempfile.TemporaryDirectory() as temp_dir:
            lock_path = Path(temp_dir) / "session.lock"
            stale_timestamp = str(int(time.time()) - 3600)
            lock_path.write_text(stale_timestamp, encoding="utf-8")

            with lock_path.open("a+", encoding="utf-8") as holder:
                fcntl.flock(holder.fileno(), fcntl.LOCK_EX | fcntl.LOCK_NB)
                with self.assertRaisesRegex(
                    LockConflictError,
                    "may be stale",
                ):
                    with acquire_session_lock(lock_path, stale_after_seconds=10):
                        pass
                fcntl.flock(holder.fileno(), fcntl.LOCK_UN)
