import json
import os
import tempfile
import unittest
from pathlib import Path
from unittest import mock


class FailuresTest(unittest.TestCase):
    def test_run_discussion_all_participants_fail_writes_failed_artifact_and_raises(self) -> None:
        from codex_roundtable.errors import (
            EXIT_ALL_PARTICIPANTS_FAILED,
            RoundtableAllParticipantsFailedError,
            exit_code_for_error,
        )
        from codex_roundtable.orchestrator import run_discussion

        with tempfile.TemporaryDirectory() as temp_dir:
            state_root = Path(temp_dir) / "state"
            with mock.patch.dict(
                os.environ,
                {"CODEX_ROUNDTABLE_HOME": str(state_root)},
                clear=False,
            ):
                with mock.patch(
                    "codex_roundtable.participants.invoke_participant",
                    side_effect=[
                        {
                            "participant_id": "claude",
                            "status": "error",
                            "response": None,
                            "duration_ms": 9,
                            "error_detail": "claude failed",
                        },
                        {
                            "participant_id": "opencode",
                            "status": "timeout",
                            "response": None,
                            "duration_ms": 10,
                            "error_detail": "opencode timed out",
                        },
                    ],
                ):
                    with self.assertRaises(RoundtableAllParticipantsFailedError) as raised:
                        run_discussion(
                            topic="topic",
                            workspace=temp_dir,
                            session_name="all-failed-session",
                        )

                self.assertEqual(exit_code_for_error(raised.exception), EXIT_ALL_PARTICIPANTS_FAILED)

                json_artifacts = sorted((state_root / "runs").glob("*/*.json"))
                markdown_artifacts = sorted((state_root / "runs").glob("*/*.md"))
                self.assertEqual(len(json_artifacts), 1)
                self.assertEqual(len(markdown_artifacts), 1)

                payload = json.loads(json_artifacts[0].read_text(encoding="utf-8"))
                self.assertEqual(payload["version"], "2.1")
                self.assertEqual(payload["moderator"], "codex")
                self.assertIn("started_at", payload)
                self.assertIn("ended_at", payload)
                self.assertTrue(payload["metadata"]["degraded"])
                self.assertEqual(payload["status"], "failed")
                self.assertFalse(payload["follow_up_enabled"])
                self.assertIsNone(payload["follow_up_reason"])
                self.assertEqual(payload["stop_reason"], "all_participants_failed")
                self.assertNotIn("synthesis", payload)
                self.assertEqual(payload["participants"], ["claude", "opencode"])
                self.assertEqual(payload["rounds"][0]["round_index"], 1)
                self.assertEqual(payload["rounds"][0]["prompt_role"], "initial")
                self.assertEqual(len(payload["rounds"][0]["responses"]), 2)

    def test_run_discussion_normalizes_malformed_success_payload_to_error(self) -> None:
        from codex_roundtable.orchestrator import run_discussion

        with tempfile.TemporaryDirectory() as temp_dir:
            state_root = Path(temp_dir) / "state"
            with mock.patch.dict(
                os.environ,
                {"CODEX_ROUNDTABLE_HOME": str(state_root)},
                clear=False,
            ):
                with mock.patch(
                    "codex_roundtable.participants.invoke_participant",
                    side_effect=[
                        {
                            "participant_id": "claude",
                            "status": "success",
                            "response": None,
                            "duration_ms": "9",
                            "error_detail": {"detail": "bad-shape"},
                        },
                        {
                            "participant_id": "opencode",
                            "status": "success",
                            "response": "usable response",
                            "duration_ms": 10,
                            "error_detail": None,
                        },
                    ],
                ):
                    artifact = run_discussion(
                        topic="topic",
                        workspace=temp_dir,
                        session_name="malformed-success",
                    )

        responses = {item["participant_id"]: item for item in artifact["rounds"][0]["responses"]}
        self.assertEqual(artifact["status"], "degraded")
        self.assertEqual(artifact["version"], "2.1")
        self.assertFalse(artifact["follow_up_enabled"])
        self.assertIsNone(artifact["follow_up_reason"])
        self.assertEqual(artifact["stop_reason"], "round_one_complete")
        self.assertEqual(responses["claude"]["status"], "error")
        self.assertIsNone(responses["claude"]["response"])
        self.assertIn("malformed success payload", responses["claude"]["error_detail"])
        self.assertEqual(responses["opencode"]["status"], "success")

    def test_run_discussion_invalid_requested_participant_raises_invalid_arguments(self) -> None:
        from codex_roundtable.errors import RoundtableInvalidArgumentsError
        from codex_roundtable.orchestrator import run_discussion

        with tempfile.TemporaryDirectory() as temp_dir:
            state_root = Path(temp_dir) / "state"
            with mock.patch.dict(
                os.environ,
                {"CODEX_ROUNDTABLE_HOME": str(state_root)},
                clear=False,
            ):
                with self.assertRaises(RoundtableInvalidArgumentsError):
                    run_discussion(
                        topic="topic",
                        workspace=temp_dir,
                        session_name="invalid",
                        participants=["claude", "unknown"],
                    )

    def test_run_discussion_follow_up_round_all_failed_returns_degraded_success(self) -> None:
        from codex_roundtable.orchestrator import run_discussion

        with tempfile.TemporaryDirectory() as temp_dir:
            state_root = Path(temp_dir) / "state"
            with mock.patch.dict(
                os.environ,
                {"CODEX_ROUNDTABLE_HOME": str(state_root)},
                clear=False,
            ):
                with mock.patch(
                    "codex_roundtable.participants.invoke_participant",
                    side_effect=[
                        {
                            "participant_id": "claude",
                            "status": "success",
                            "response": "Recommend keeping the current interface and deferring the rewrite.",
                            "duration_ms": 9,
                            "error_detail": None,
                        },
                        {
                            "participant_id": "opencode",
                            "status": "success",
                            "response": "Recommend rewriting the interface now to reduce future complexity.",
                            "duration_ms": 10,
                            "error_detail": None,
                        },
                        {
                            "participant_id": "claude",
                            "status": "error",
                            "response": None,
                            "duration_ms": 12,
                            "error_detail": "claude follow-up failed",
                        },
                        {
                            "participant_id": "opencode",
                            "status": "timeout",
                            "response": None,
                            "duration_ms": 14,
                            "error_detail": "opencode follow-up timed out",
                        },
                    ],
                ):
                    artifact = run_discussion(
                        topic="topic",
                        workspace=temp_dir,
                        session_name="follow-up-round-failed",
                        follow_up_once=True,
                    )

        self.assertEqual(artifact["status"], "degraded")
        self.assertTrue(artifact["metadata"]["degraded"])
        self.assertEqual(artifact["version"], "2.1")
        self.assertTrue(artifact["follow_up_enabled"])
        self.assertEqual(artifact["follow_up_reason"], "clarify_difference")
        self.assertEqual(artifact["stop_reason"], "follow_up_failed")
        self.assertEqual(len(artifact["rounds"]), 2)
        self.assertEqual(artifact["rounds"][0]["prompt_role"], "initial")
        self.assertEqual(artifact["rounds"][1]["prompt_role"], "follow_up")
        statuses = sorted(response["status"] for response in artifact["rounds"][1]["responses"])
        self.assertEqual(statuses, ["error", "timeout"])
        self.assertIn("synthesis", artifact)

    def test_run_discussion_follow_up_all_round_one_fail_still_raises_existing_error(self) -> None:
        from codex_roundtable.errors import RoundtableAllParticipantsFailedError
        from codex_roundtable.orchestrator import run_discussion

        with tempfile.TemporaryDirectory() as temp_dir:
            state_root = Path(temp_dir) / "state"
            with mock.patch.dict(
                os.environ,
                {"CODEX_ROUNDTABLE_HOME": str(state_root)},
                clear=False,
            ):
                with mock.patch(
                    "codex_roundtable.participants.invoke_participant",
                    side_effect=[
                        {
                            "participant_id": "claude",
                            "status": "error",
                            "response": None,
                            "duration_ms": 9,
                            "error_detail": "claude failed",
                        },
                        {
                            "participant_id": "opencode",
                            "status": "timeout",
                            "response": None,
                            "duration_ms": 10,
                            "error_detail": "opencode timed out",
                        },
                    ],
                ):
                    with self.assertRaises(RoundtableAllParticipantsFailedError):
                        run_discussion(
                            topic="topic",
                            workspace=temp_dir,
                            session_name="all-failed-follow-up",
                            follow_up_once=True,
                        )

    def test_run_discussion_partial_success_follow_up_not_needed_stops_after_one_round(self) -> None:
        from codex_roundtable.orchestrator import run_discussion

        with tempfile.TemporaryDirectory() as temp_dir:
            state_root = Path(temp_dir) / "state"
            with mock.patch.dict(
                os.environ,
                {"CODEX_ROUNDTABLE_HOME": str(state_root)},
                clear=False,
            ):
                with mock.patch(
                    "codex_roundtable.participants.invoke_participant",
                    side_effect=[
                        {
                            "participant_id": "claude",
                            "status": "success",
                            "response": "Recommend the additive API path because it minimizes migration risk.",
                            "duration_ms": 9,
                            "error_detail": None,
                        },
                        {
                            "participant_id": "opencode",
                            "status": "error",
                            "response": None,
                            "duration_ms": 10,
                            "error_detail": "opencode failed",
                        },
                    ],
                ) as invoke_mock:
                    artifact = run_discussion(
                        topic="topic",
                        workspace=temp_dir,
                        session_name="partial-success-no-follow-up",
                        follow_up_once=True,
                    )

        self.assertEqual(invoke_mock.call_count, 2)
        self.assertEqual(artifact["status"], "degraded")
        self.assertTrue(artifact["follow_up_enabled"])
        self.assertIsNone(artifact["follow_up_reason"])
        self.assertEqual(artifact["stop_reason"], "follow_up_not_needed")
        self.assertEqual(len(artifact["rounds"]), 1)
        self.assertEqual(artifact["rounds"][0]["prompt_role"], "initial")
