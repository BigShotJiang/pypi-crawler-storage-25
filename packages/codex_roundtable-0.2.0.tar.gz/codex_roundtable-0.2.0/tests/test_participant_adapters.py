import subprocess
import unittest
from unittest import mock


class ParticipantAdaptersTest(unittest.TestCase):
    def test_build_claude_command_with_thread(self) -> None:
        from codex_roundtable.participants import build_claude_command

        command = build_claude_command(
            prompt="hello",
            workspace_root="/tmp/workspace",
            thread_name="thread-1",
            timeout_seconds=30,
        )

        self.assertEqual(
            command,
            [
                "codex2claude",
                "ask",
                "--prompt",
                "hello",
                "--workspace",
                "/tmp/workspace",
                "--thread",
                "thread-1",
                "--timeout",
                "30",
            ],
        )

    def test_build_opencode_command_without_thread_omits_thread_flag(self) -> None:
        from codex_roundtable.participants import build_opencode_command

        command = build_opencode_command(
            prompt="hello",
            workspace_root="/tmp/workspace",
            thread_name=None,
            timeout_seconds=11,
        )

        self.assertEqual(
            command,
            [
                "codex2opencode",
                "ask",
                "--prompt",
                "hello",
                "--workspace",
                "/tmp/workspace",
                "--timeout",
                "11",
            ],
        )

    def test_invoke_participant_claude_run_contract(self) -> None:
        from codex_roundtable.participants import invoke_participant

        completed = subprocess.CompletedProcess(
            args=["codex2claude"],
            returncode=0,
            stdout=b"ok\n",
            stderr=b"",
        )
        with (
            mock.patch("codex_roundtable.participants.time.monotonic", side_effect=[1.0, 1.1]),
            mock.patch("codex_roundtable.participants.subprocess.run", return_value=completed) as run_mock,
        ):
            invoke_participant(
                participant_id="claude",
                prompt="hi",
                workspace_root="/tmp/workspace",
                thread_name="thread-1",
                timeout_seconds=13,
            )

        run_mock.assert_called_once_with(
            [
                "codex2claude",
                "ask",
                "--prompt",
                "hi",
                "--workspace",
                "/tmp/workspace",
                "--thread",
                "thread-1",
                "--timeout",
                "13",
            ],
            capture_output=True,
            check=False,
            text=False,
            timeout=18,
        )

    def test_invoke_participant_opencode_run_contract_without_thread(self) -> None:
        from codex_roundtable.participants import invoke_participant

        completed = subprocess.CompletedProcess(
            args=["codex2opencode"],
            returncode=0,
            stdout=b"ok\n",
            stderr=b"",
        )
        with (
            mock.patch("codex_roundtable.participants.time.monotonic", side_effect=[2.0, 2.1]),
            mock.patch("codex_roundtable.participants.subprocess.run", return_value=completed) as run_mock,
        ):
            invoke_participant(
                participant_id="opencode",
                prompt="hello",
                workspace_root="/tmp/workspace",
                thread_name=None,
                timeout_seconds=7,
            )

        run_mock.assert_called_once_with(
            [
                "codex2opencode",
                "ask",
                "--prompt",
                "hello",
                "--workspace",
                "/tmp/workspace",
                "--timeout",
                "7",
            ],
            capture_output=True,
            check=False,
            text=False,
            timeout=12,
        )

    def test_invoke_participant_unsupported_participant_id(self) -> None:
        from codex_roundtable.participants import invoke_participant

        with mock.patch(
            "codex_roundtable.participants.time.monotonic",
            side_effect=[50.0, 50.03],
        ):
            result = invoke_participant(
                participant_id="unknown",
                prompt="hi",
                workspace_root="/tmp/workspace",
                thread_name=None,
                timeout_seconds=10,
            )

        self.assertEqual(result["participant_id"], "unknown")
        self.assertEqual(result["status"], "error")
        self.assertIsNone(result["response"])
        self.assertEqual(result["duration_ms"], 30)
        self.assertIn("Unsupported participant", str(result["error_detail"]))

    def test_invoke_participant_success(self) -> None:
        from codex_roundtable.participants import invoke_participant

        completed = subprocess.CompletedProcess(
            args=["claude", "reply"],
            returncode=0,
            stdout=b"hello from claude\n",
            stderr=b"",
        )
        with (
            mock.patch("codex_roundtable.participants.time.monotonic", side_effect=[10.0, 10.2]),
            mock.patch("codex_roundtable.participants.subprocess.run", return_value=completed),
        ):
            result = invoke_participant(
                participant_id="claude",
                prompt="hi",
                workspace_root="/tmp/workspace",
                thread_name="thread-1",
                timeout_seconds=30,
            )

        self.assertEqual(result["participant_id"], "claude")
        self.assertEqual(result["status"], "success")
        self.assertEqual(result["response"], "hello from claude\n")
        self.assertEqual(result["duration_ms"], 200)
        self.assertIsNone(result["error_detail"])

    def test_invoke_participant_success_preserves_raw_stdout(self) -> None:
        from codex_roundtable.participants import invoke_participant

        completed = subprocess.CompletedProcess(
            args=["claude", "reply"],
            returncode=0,
            stdout=b"\n  hello from claude  \n",
            stderr=b"",
        )
        with (
            mock.patch("codex_roundtable.participants.time.monotonic", side_effect=[10.0, 10.2]),
            mock.patch("codex_roundtable.participants.subprocess.run", return_value=completed),
        ):
            result = invoke_participant(
                participant_id="claude",
                prompt="hi",
                workspace_root="/tmp/workspace",
                thread_name="thread-1",
                timeout_seconds=30,
            )

        self.assertEqual(result["status"], "success")
        self.assertEqual(result["response"], "\n  hello from claude  \n")

    def test_invoke_participant_timeout(self) -> None:
        from codex_roundtable.participants import invoke_participant

        timeout_error = subprocess.TimeoutExpired(cmd=["claude"], timeout=1)
        with (
            mock.patch("codex_roundtable.participants.time.monotonic", side_effect=[20.0, 20.5]),
            mock.patch("codex_roundtable.participants.subprocess.run", side_effect=timeout_error),
        ):
            result = invoke_participant(
                participant_id="claude",
                prompt="hi",
                workspace_root="/tmp/workspace",
                thread_name="thread-1",
                timeout_seconds=1,
            )

        self.assertEqual(result["participant_id"], "claude")
        self.assertEqual(result["status"], "timeout")
        self.assertIsNone(result["response"])
        self.assertEqual(result["duration_ms"], 500)
        self.assertIn("timed out", str(result["error_detail"]))

    def test_invoke_participant_missing_binary(self) -> None:
        from codex_roundtable.participants import invoke_participant

        with (
            mock.patch("codex_roundtable.participants.time.monotonic", side_effect=[30.0, 30.1]),
            mock.patch(
                "codex_roundtable.participants.subprocess.run",
                side_effect=FileNotFoundError("No such file or directory: 'opencode'"),
            ),
        ):
            result = invoke_participant(
                participant_id="opencode",
                prompt="hi",
                workspace_root="/tmp/workspace",
                thread_name="thread-1",
                timeout_seconds=5,
            )

        self.assertEqual(result["participant_id"], "opencode")
        self.assertEqual(result["status"], "error")
        self.assertIsNone(result["response"])
        self.assertEqual(result["duration_ms"], 100)
        self.assertIn("not found", str(result["error_detail"]))
        self.assertIn("opencode", str(result["error_detail"]))

    def test_invoke_participant_malformed_output(self) -> None:
        from codex_roundtable.participants import invoke_participant

        completed = subprocess.CompletedProcess(
            args=["opencode", "reply"],
            returncode=0,
            stdout=b"   \n",
            stderr=b"",
        )
        with (
            mock.patch("codex_roundtable.participants.time.monotonic", side_effect=[40.0, 40.05]),
            mock.patch("codex_roundtable.participants.subprocess.run", return_value=completed),
        ):
            result = invoke_participant(
                participant_id="opencode",
                prompt="hi",
                workspace_root="/tmp/workspace",
                thread_name="thread-1",
                timeout_seconds=5,
            )

        self.assertEqual(result["participant_id"], "opencode")
        self.assertEqual(result["status"], "error")
        self.assertIsNone(result["response"])
        self.assertEqual(result["duration_ms"], 50)
        self.assertIn("malformed", str(result["error_detail"]))

    def test_invoke_participant_non_zero_exit_uses_stderr_detail(self) -> None:
        from codex_roundtable.participants import invoke_participant

        completed = subprocess.CompletedProcess(
            args=["codex2claude"],
            returncode=42,
            stdout=b"ignored\n",
            stderr=b"bridge failed\n",
        )
        with (
            mock.patch("codex_roundtable.participants.time.monotonic", side_effect=[60.0, 60.01]),
            mock.patch("codex_roundtable.participants.subprocess.run", return_value=completed),
        ):
            result = invoke_participant(
                participant_id="claude",
                prompt="hi",
                workspace_root="/tmp/workspace",
                thread_name="thread-1",
                timeout_seconds=5,
            )

        self.assertEqual(result["status"], "error")
        self.assertIsNone(result["response"])
        self.assertEqual(result["error_detail"], "bridge failed")

    def test_invoke_participant_non_zero_exit_with_empty_stderr_uses_fallback(self) -> None:
        from codex_roundtable.participants import invoke_participant

        completed = subprocess.CompletedProcess(
            args=["codex2opencode"],
            returncode=9,
            stdout=b"ignored\n",
            stderr=b"   ",
        )
        with (
            mock.patch("codex_roundtable.participants.time.monotonic", side_effect=[70.0, 70.02]),
            mock.patch("codex_roundtable.participants.subprocess.run", return_value=completed),
        ):
            result = invoke_participant(
                participant_id="opencode",
                prompt="hi",
                workspace_root="/tmp/workspace",
                thread_name="thread-1",
                timeout_seconds=5,
            )

        self.assertEqual(result["status"], "error")
        self.assertIsNone(result["response"])
        self.assertEqual(result["error_detail"], "Participant exited with code 9")

    def test_invoke_participant_undecodable_stdout_is_structured_error(self) -> None:
        from codex_roundtable.participants import invoke_participant

        completed = subprocess.CompletedProcess(
            args=["codex2claude"],
            returncode=0,
            stdout=b"\xff",
            stderr=b"",
        )
        with (
            mock.patch("codex_roundtable.participants.time.monotonic", side_effect=[80.0, 80.02]),
            mock.patch("codex_roundtable.participants.subprocess.run", return_value=completed),
        ):
            result = invoke_participant(
                participant_id="claude",
                prompt="hi",
                workspace_root="/tmp/workspace",
                thread_name="thread-1",
                timeout_seconds=5,
            )

        self.assertEqual(result["status"], "error")
        self.assertIsNone(result["response"])
        self.assertIn("undecodable", str(result["error_detail"]))

    def test_invoke_participant_os_error_is_structured_error(self) -> None:
        from codex_roundtable.participants import invoke_participant

        with (
            mock.patch("codex_roundtable.participants.time.monotonic", side_effect=[90.0, 90.03]),
            mock.patch(
                "codex_roundtable.participants.subprocess.run",
                side_effect=OSError("permission denied"),
            ),
        ):
            result = invoke_participant(
                participant_id="opencode",
                prompt="hi",
                workspace_root="/tmp/workspace",
                thread_name="thread-1",
                timeout_seconds=5,
            )

        self.assertEqual(result["status"], "error")
        self.assertIsNone(result["response"])
        self.assertIn("invocation failed", str(result["error_detail"]))
