import unittest


class RenderingTest(unittest.TestCase):
    def test_render_artifact_markdown_includes_round_sections_and_stop_reason(self) -> None:
        from codex_roundtable.rendering import render_artifact_markdown

        artifact = {
            "topic": "Should we split the API package?",
            "status": "ok",
            "stop_reason": "follow_up_complete",
            "participants": ["claude", "opencode"],
            "rounds": [
                {
                    "round_index": 1,
                    "prompt_role": "initial",
                    "responses": [
                        {
                            "participant_id": "claude",
                            "status": "success",
                            "response": "Prefer additive migration with compatibility shims.",
                        },
                        {
                            "participant_id": "opencode",
                            "status": "success",
                            "response": "Stage rollout and monitor migration blast radius.",
                        },
                    ],
                },
                {
                    "round_index": 2,
                    "prompt_role": "follow_up",
                    "responses": [
                        {
                            "participant_id": "claude",
                            "status": "success",
                            "response": "Keep the split deferred unless launch scope shrinks.",
                        },
                        {
                            "participant_id": "opencode",
                            "status": "success",
                            "response": "Split now only if migration owners are assigned this week.",
                        },
                    ],
                }
            ],
            "synthesis": {
                "consensus": ["Use staged rollout with explicit checkpoints."],
                "disagreements": ["claude favors longer compatibility windows."],
                "risks": ["Migration timeline could slip without strict ownership."],
                "recommendation": "Proceed with split after adding telemetry gates.",
                "confidence": "medium",
            },
        }

        markdown = render_artifact_markdown(artifact)

        self.assertIn("# Codex Roundtable Artifact", markdown)
        self.assertIn("**Topic:** Should we split the API package?", markdown)
        self.assertIn("**Stop Reason:** follow_up_complete", markdown)
        self.assertIn("- claude", markdown)
        self.assertIn("- opencode", markdown)
        self.assertIn("## Round 1 (initial)", markdown)
        self.assertIn("## Round 2 (follow_up)", markdown)
        self.assertIn("### claude", markdown)
        self.assertIn("### opencode", markdown)
        self.assertIn("Keep the split deferred unless launch scope shrinks.", markdown)
        self.assertIn("Split now only if migration owners are assigned this week.", markdown)
        self.assertIn("## Consensus", markdown)
        self.assertIn("## Disagreements", markdown)
        self.assertIn("Proceed with split after adding telemetry gates.", markdown)
        self.assertIn("## Confidence", markdown)

    def test_render_artifact_markdown_handles_missing_synthesis_for_failed_artifact(self) -> None:
        from codex_roundtable.rendering import render_artifact_markdown

        artifact = {
            "topic": "Should we split the API package?",
            "status": "failed",
            "participants": ["claude", "opencode"],
            "rounds": [
                {
                    "round_index": 1,
                    "responses": [
                        {
                            "participant_id": "claude",
                            "status": "error",
                            "response": "",
                        },
                        {
                            "participant_id": "opencode",
                            "status": "timeout",
                            "response": "",
                        },
                    ],
                }
            ],
        }

        markdown = render_artifact_markdown(artifact)

        self.assertIn("**Status:** failed", markdown)
        self.assertIn("## Synthesis", markdown)
        self.assertIn("No synthesis was produced", markdown)

    def test_render_artifact_markdown_handles_v1_artifact_without_follow_up_fields(self) -> None:
        from codex_roundtable.rendering import render_artifact_markdown

        artifact = {
            "topic": "Legacy artifact",
            "status": "degraded",
            "participants": ["claude"],
            "rounds": [
                {
                    "round_index": 1,
                    "responses": [
                        {"participant_id": "claude", "status": "success", "response": "Legacy response"}
                    ],
                }
            ],
            "synthesis": {
                "consensus": [],
                "disagreements": [],
                "risks": [],
                "recommendation": "Keep compatibility behavior.",
                "confidence": "low",
            },
        }

        markdown = render_artifact_markdown(artifact)

        self.assertIn("## Round 1", markdown)
        self.assertNotIn("**Stop Reason:**", markdown)
        self.assertIn("Legacy response", markdown)

    def test_render_artifact_stdout_summary_for_synthesized_artifact(self) -> None:
        from codex_roundtable.rendering import render_artifact_stdout_summary

        artifact = {
            "topic": "Should we split the API package?",
            "status": "degraded",
            "stop_reason": "follow_up_not_needed",
            "participants": ["claude", "opencode"],
            "rounds": [
                {
                    "round_index": 1,
                    "responses": [
                        {"participant_id": "claude", "status": "success", "response": "A"},
                        {"participant_id": "opencode", "status": "error", "response": ""},
                    ],
                }
            ],
            "synthesis": {
                "consensus": [],
                "disagreements": [],
                "risks": [],
                "recommendation": "Proceed with guardrails.",
                "confidence": "low",
            },
        }

        summary = render_artifact_stdout_summary(artifact)

        self.assertIn("topic=Should we split the API package?", summary)
        self.assertIn("status=degraded", summary)
        self.assertIn("rounds=1", summary)
        self.assertIn("stop_reason=follow_up_not_needed", summary)
        self.assertIn("success=1", summary)
        self.assertIn("error=1", summary)
        self.assertIn("recommendation=Proceed with guardrails.", summary)

    def test_render_artifact_stdout_summary_for_failed_artifact(self) -> None:
        from codex_roundtable.rendering import render_artifact_stdout_summary

        artifact = {
            "topic": "Should we split the API package?",
            "status": "failed",
            "participants": ["claude", "opencode"],
            "rounds": [
                {
                    "round_index": 1,
                    "responses": [
                        {"participant_id": "claude", "status": "error", "response": ""},
                        {"participant_id": "opencode", "status": "timeout", "response": ""},
                    ],
                }
            ],
        }

        summary = render_artifact_stdout_summary(artifact)

        self.assertIn("topic=Should we split the API package?", summary)
        self.assertIn("status=failed", summary)
        self.assertIn("rounds=1", summary)
        self.assertIn("No participant succeeded", summary)

    def test_render_artifact_stdout_summary_uses_latest_successful_round_counts(self) -> None:
        from codex_roundtable.rendering import render_artifact_stdout_summary

        artifact = {
            "topic": "Should we split the API package?",
            "status": "degraded",
            "stop_reason": "follow_up_complete",
            "participants": ["claude", "opencode"],
            "rounds": [
                {
                    "round_index": 1,
                    "prompt_role": "initial",
                    "responses": [
                        {"participant_id": "claude", "status": "success", "response": "Initial A"},
                        {"participant_id": "opencode", "status": "success", "response": "Initial B"},
                    ],
                },
                {
                    "round_index": 2,
                    "prompt_role": "follow_up",
                    "responses": [
                        {"participant_id": "claude", "status": "success", "response": "Follow-up A"},
                        {"participant_id": "opencode", "status": "error", "response": ""},
                    ],
                },
            ],
            "synthesis": {
                "consensus": [],
                "disagreements": [],
                "risks": [],
                "recommendation": "Use the follow-up answer.",
                "confidence": "low",
            },
        }

        summary = render_artifact_stdout_summary(artifact)

        self.assertIn("rounds=2", summary)
        self.assertIn("stop_reason=follow_up_complete", summary)
        self.assertIn("success=1", summary)
        self.assertIn("error=1", summary)
        self.assertNotIn("success=3", summary)
