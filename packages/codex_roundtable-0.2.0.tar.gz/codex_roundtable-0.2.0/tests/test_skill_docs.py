import pathlib
import unittest


class SkillDocsTest(unittest.TestCase):
    def test_readme_mentions_doctor_and_discuss(self) -> None:
        root = pathlib.Path(__file__).resolve().parents[1]
        readme = (root / "README.md").read_text(encoding="utf-8")
        self.assertIn("codex-roundtable discuss", readme)
        self.assertIn("codex-roundtable doctor", readme)
        self.assertIn("--follow-up-once", readme)
        self.assertIn("single-participant", readme)
        self.assertIn("~/.codex/skills/codex-roundtable", readme)

    def test_skill_doc_is_thin_cli_router(self) -> None:
        root = pathlib.Path(__file__).resolve().parents[1]
        skill_path = root / "skills" / "codex-roundtable" / "SKILL.md"
        self.assertTrue(skill_path.exists(), msg=f"Missing skill doc: {skill_path}")
        skill = skill_path.read_text(encoding="utf-8")
        self.assertIn("codex-roundtable discuss", skill)
        self.assertIn("codex-roundtable status", skill)
        self.assertIn("codex-roundtable doctor", skill)
        self.assertIn("--follow-up-once", skill)
        self.assertIn("roundtable 一下这个方案", skill)
        self.assertIn("让 cc 和 opencode 都看一下", skill)
        self.assertIn("问问 cc", skill)
        self.assertIn("给 opencode 看看", skill)
        self.assertNotIn("build prompts", skill.lower())
        self.assertNotIn("manage session state", skill.lower())

    def test_architecture_and_development_cover_follow_up_flow(self) -> None:
        root = pathlib.Path(__file__).resolve().parents[1]
        architecture = (root / "ARCHITECTURE.md").read_text(encoding="utf-8")
        development = (root / "DEVELOPMENT.md").read_text(encoding="utf-8")
        self.assertIn("optional second round", architecture)
        self.assertIn("follow_up_once", architecture)
        self.assertIn("--follow-up-once", development)
        self.assertIn("version=2.1", development)

    def test_agents_and_contributing_match_v21_behavior(self) -> None:
        root = pathlib.Path(__file__).resolve().parents[1]
        agents = (root / "AGENTS.md").read_text(encoding="utf-8")
        contributing = (root / "CONTRIBUTING.md").read_text(encoding="utf-8")
        self.assertIn("optional second round", agents)
        self.assertIn("--follow-up-once", agents)
        self.assertIn("v2.1", contributing)
        self.assertIn("--follow-up-once", contributing)
