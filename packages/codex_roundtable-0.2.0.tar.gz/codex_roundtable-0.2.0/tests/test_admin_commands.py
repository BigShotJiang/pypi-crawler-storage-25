import io
import json
import os
import tempfile
import time
import unittest
from pathlib import Path
from unittest import mock


class AdminCommandsTest(unittest.TestCase):
    def test_doctor_reports_ok_when_participants_are_available(self) -> None:
        from codex_roundtable.cli import main

        with tempfile.TemporaryDirectory() as temp_dir:
            state_root = Path(temp_dir) / "state"
            state_root.mkdir(parents=True, exist_ok=True)
            stdout = io.StringIO()
            stderr = io.StringIO()
            which_values = {
                "codex2claude": "/usr/bin/codex2claude",
                "codex2opencode": "/usr/bin/codex2opencode",
            }
            with mock.patch.dict(
                os.environ,
                {"CODEX_ROUNDTABLE_HOME": str(state_root)},
                clear=False,
            ), mock.patch(
                "codex_roundtable.diagnostics.shutil.which",
                side_effect=lambda name: which_values.get(name),
            ), mock.patch("sys.stdout", stdout), mock.patch("sys.stderr", stderr):
                exit_code = main(["doctor"])

        self.assertEqual(exit_code, 0)
        payload = json.loads(stdout.getvalue())
        self.assertTrue(payload["ok"])
        self.assertEqual(payload["participants"]["claude"]["status"], "ok")
        self.assertEqual(payload["participants"]["opencode"]["status"], "ok")
        self.assertTrue(stdout.getvalue().endswith("\n"))
        self.assertEqual(stderr.getvalue(), "")

    def test_doctor_nonzero_when_required_participant_binary_is_missing(self) -> None:
        from codex_roundtable.cli import main

        with tempfile.TemporaryDirectory() as temp_dir:
            state_root = Path(temp_dir) / "state"
            state_root.mkdir(parents=True, exist_ok=True)
            stdout = io.StringIO()
            stderr = io.StringIO()
            which_values = {
                "codex2claude": "/usr/bin/codex2claude",
                "codex2opencode": None,
            }
            with mock.patch.dict(
                os.environ,
                {"CODEX_ROUNDTABLE_HOME": str(state_root)},
                clear=False,
            ), mock.patch(
                "codex_roundtable.diagnostics.shutil.which",
                side_effect=lambda name: which_values.get(name),
            ), mock.patch("sys.stdout", stdout), mock.patch("sys.stderr", stderr):
                exit_code = main(["doctor"])

        self.assertNotEqual(exit_code, 0)
        payload = json.loads(stdout.getvalue())
        self.assertFalse(payload["ok"])
        self.assertEqual(payload["participants"]["opencode"]["status"], "missing")
        self.assertEqual(stderr.getvalue(), "")

    def test_status_prints_session_json_when_state_exists(self) -> None:
        from codex_roundtable.cli import main
        from codex_roundtable.models import RoundtableSession
        from codex_roundtable.orchestrator import _derive_session_key
        from codex_roundtable.paths import session_state_path
        from codex_roundtable.session_store import save_session

        with tempfile.TemporaryDirectory() as temp_dir:
            workspace = Path(temp_dir) / "workspace"
            workspace.mkdir(parents=True, exist_ok=True)
            state_root = Path(temp_dir) / "state"
            session_name = "design"
            session_key = _derive_session_key(str(workspace.resolve()), session_name)
            with mock.patch.dict(
                os.environ,
                {"CODEX_ROUNDTABLE_HOME": str(state_root)},
                clear=False,
            ):
                save_session(
                    session_state_path(session_key),
                    RoundtableSession(
                        session_key=session_key,
                        workspace_root=str(workspace.resolve()),
                        session_name=session_name,
                        created_at="2026-03-28T00:00:00Z",
                        last_used_at=None,
                        participant_bindings=[],
                    ),
                )
            stdout = io.StringIO()
            stderr = io.StringIO()
            with mock.patch.dict(
                os.environ,
                {"CODEX_ROUNDTABLE_HOME": str(state_root)},
                clear=False,
            ), mock.patch("sys.stdout", stdout), mock.patch("sys.stderr", stderr):
                exit_code = main(
                    [
                        "status",
                        "--workspace",
                        str(workspace),
                        "--session",
                        session_name,
                    ]
                )

        self.assertEqual(exit_code, 0)
        payload = json.loads(stdout.getvalue())
        self.assertEqual(payload["session_name"], session_name)
        self.assertEqual(payload["session_key"], session_key)
        self.assertEqual(stderr.getvalue(), "")

    def test_doctor_treats_missing_session_state_as_nonfatal(self) -> None:
        from codex_roundtable.cli import main

        with tempfile.TemporaryDirectory() as temp_dir:
            workspace = Path(temp_dir) / "workspace"
            workspace.mkdir(parents=True, exist_ok=True)
            state_root = Path(temp_dir) / "state"
            state_root.mkdir(parents=True, exist_ok=True)
            stdout = io.StringIO()
            stderr = io.StringIO()
            which_values = {
                "codex2claude": "/usr/bin/codex2claude",
                "codex2opencode": "/usr/bin/codex2opencode",
            }
            with mock.patch.dict(
                os.environ,
                {"CODEX_ROUNDTABLE_HOME": str(state_root)},
                clear=False,
            ), mock.patch(
                "codex_roundtable.diagnostics.shutil.which",
                side_effect=lambda name: which_values.get(name),
            ), mock.patch("sys.stdout", stdout), mock.patch("sys.stderr", stderr):
                exit_code = main(
                    [
                        "doctor",
                        "--workspace",
                        str(workspace),
                        "--session",
                        "new-session",
                    ]
                )

        self.assertEqual(exit_code, 0)
        payload = json.loads(stdout.getvalue())
        self.assertTrue(payload["ok"])
        self.assertEqual(payload["session_state"]["status"], "missing")
        self.assertEqual(stderr.getvalue(), "")

    def test_show_prints_json_artifact_content(self) -> None:
        from codex_roundtable.cli import main
        from codex_roundtable.paths import run_json_artifact_path

        with tempfile.TemporaryDirectory() as temp_dir:
            state_root = Path(temp_dir) / "state"
            run_id = "run-123"
            run_payload = {
                "run_id": run_id,
                "session_key": "abc",
                "status": "ok",
            }
            with mock.patch.dict(
                os.environ,
                {"CODEX_ROUNDTABLE_HOME": str(state_root)},
                clear=False,
            ):
                path = run_json_artifact_path("abc", run_id)
                path.parent.mkdir(parents=True, exist_ok=True)
                path.write_text(json.dumps(run_payload, sort_keys=True), encoding="utf-8")

            stdout = io.StringIO()
            stderr = io.StringIO()
            with mock.patch.dict(
                os.environ,
                {"CODEX_ROUNDTABLE_HOME": str(state_root)},
                clear=False,
            ), mock.patch("sys.stdout", stdout), mock.patch("sys.stderr", stderr):
                exit_code = main(["show", "--run-id", run_id, "--format", "json"])

        self.assertEqual(exit_code, 0)
        self.assertEqual(json.loads(stdout.getvalue())["run_id"], run_id)
        self.assertEqual(stderr.getvalue(), "")

    def test_show_prints_markdown_artifact_content(self) -> None:
        from codex_roundtable.cli import main
        from codex_roundtable.paths import run_markdown_artifact_path

        with tempfile.TemporaryDirectory() as temp_dir:
            state_root = Path(temp_dir) / "state"
            run_id = "run-456"
            with mock.patch.dict(
                os.environ,
                {"CODEX_ROUNDTABLE_HOME": str(state_root)},
                clear=False,
            ):
                path = run_markdown_artifact_path("abc", run_id)
                path.parent.mkdir(parents=True, exist_ok=True)
                path.write_text("# Artifact\n\ncontent\n", encoding="utf-8")

            stdout = io.StringIO()
            stderr = io.StringIO()
            with mock.patch.dict(
                os.environ,
                {"CODEX_ROUNDTABLE_HOME": str(state_root)},
                clear=False,
            ), mock.patch("sys.stdout", stdout), mock.patch("sys.stderr", stderr):
                exit_code = main(["show", "--run-id", run_id, "--format", "markdown"])

        self.assertEqual(exit_code, 0)
        self.assertEqual(stdout.getvalue(), "# Artifact\n\ncontent\n")
        self.assertEqual(stderr.getvalue(), "")

    def test_forget_removes_session_state_but_keeps_run_artifacts(self) -> None:
        from codex_roundtable.cli import main
        from codex_roundtable.orchestrator import _derive_session_key
        from codex_roundtable.paths import run_json_artifact_path, session_dir, session_state_path

        with tempfile.TemporaryDirectory() as temp_dir:
            workspace = Path(temp_dir) / "workspace"
            workspace.mkdir(parents=True, exist_ok=True)
            session_name = "design"
            session_key = _derive_session_key(str(workspace.resolve()), session_name)
            state_root = Path(temp_dir) / "state"

            with mock.patch.dict(
                os.environ,
                {"CODEX_ROUNDTABLE_HOME": str(state_root)},
                clear=False,
            ):
                state_path = session_state_path(session_key)
                state_path.parent.mkdir(parents=True, exist_ok=True)
                state_path.write_text('{"session_key":"sentinel"}', encoding="utf-8")
                lock_path = session_dir(session_key) / "session.lock"
                lock_path.write_text("locked", encoding="utf-8")

                run_path = run_json_artifact_path(session_key, "run-123")
                run_path.parent.mkdir(parents=True, exist_ok=True)
                run_path.write_text('{"run_id":"run-123"}', encoding="utf-8")

            stdout = io.StringIO()
            stderr = io.StringIO()
            with mock.patch.dict(
                os.environ,
                {"CODEX_ROUNDTABLE_HOME": str(state_root)},
                clear=False,
            ), mock.patch("sys.stdout", stdout), mock.patch("sys.stderr", stderr):
                exit_code = main(
                    [
                        "forget",
                        "--workspace",
                        str(workspace),
                        "--session",
                        session_name,
                    ]
                )

            self.assertEqual(exit_code, 0)
            self.assertFalse(state_path.exists())
            self.assertFalse(lock_path.exists())
            self.assertTrue(run_path.exists())
            self.assertEqual(stderr.getvalue(), "")

    def test_gc_removes_old_files_and_skips_locked_sessions(self) -> None:
        from codex_roundtable.cli import main
        from codex_roundtable.paths import run_json_artifact_path, session_dir, session_state_path
        import fcntl

        with tempfile.TemporaryDirectory() as temp_dir:
            state_root = Path(temp_dir) / "state"
            old_session_key = "old-session"
            locked_session_key = "locked-session"
            fresh_session_key = "fresh-session"

            with mock.patch.dict(
                os.environ,
                {"CODEX_ROUNDTABLE_HOME": str(state_root)},
                clear=False,
            ):
                old_state_path = session_state_path(old_session_key)
                old_state_path.parent.mkdir(parents=True, exist_ok=True)
                old_state_path.write_text('{"session_key":"old"}', encoding="utf-8")
                old_lock_path = session_dir(old_session_key) / "session.lock"
                old_lock_path.write_text("old", encoding="utf-8")
                old_run_path = run_json_artifact_path(old_session_key, "run-old")
                old_run_path.parent.mkdir(parents=True, exist_ok=True)
                old_run_path.write_text('{"run_id":"run-old"}', encoding="utf-8")

                locked_state_path = session_state_path(locked_session_key)
                locked_state_path.parent.mkdir(parents=True, exist_ok=True)
                locked_state_path.write_text('{"session_key":"locked"}', encoding="utf-8")
                locked_lock_path = session_dir(locked_session_key) / "session.lock"
                locked_lock_path.parent.mkdir(parents=True, exist_ok=True)
                locked_lock_path.write_text("locked", encoding="utf-8")
                locked_run_path = run_json_artifact_path(locked_session_key, "run-locked")
                locked_run_path.parent.mkdir(parents=True, exist_ok=True)
                locked_run_path.write_text('{"run_id":"run-locked"}', encoding="utf-8")

                fresh_state_path = session_state_path(fresh_session_key)
                fresh_state_path.parent.mkdir(parents=True, exist_ok=True)
                fresh_state_path.write_text('{"session_key":"fresh"}', encoding="utf-8")
                fresh_lock_path = session_dir(fresh_session_key) / "session.lock"
                fresh_lock_path.write_text("fresh", encoding="utf-8")
                fresh_run_path = run_json_artifact_path(fresh_session_key, "run-fresh")
                fresh_run_path.parent.mkdir(parents=True, exist_ok=True)
                fresh_run_path.write_text('{"run_id":"run-fresh"}', encoding="utf-8")

            old_epoch = time.time() - (10 * 24 * 60 * 60)
            for path in [
                old_state_path,
                old_lock_path,
                old_run_path,
                locked_state_path,
                locked_lock_path,
                locked_run_path,
            ]:
                os.utime(path, (old_epoch, old_epoch))

            with locked_lock_path.open("r+", encoding="utf-8") as lock_handle:
                fcntl.flock(lock_handle.fileno(), fcntl.LOCK_EX | fcntl.LOCK_NB)
                stdout = io.StringIO()
                stderr = io.StringIO()
                with mock.patch.dict(
                    os.environ,
                    {"CODEX_ROUNDTABLE_HOME": str(state_root)},
                    clear=False,
                ), mock.patch("sys.stdout", stdout), mock.patch("sys.stderr", stderr):
                    exit_code = main(["gc", "--max-age-days", "1"])

                fcntl.flock(lock_handle.fileno(), fcntl.LOCK_UN)

            self.assertEqual(exit_code, 0)
            self.assertFalse(old_state_path.exists())
            self.assertFalse(old_lock_path.exists())
            self.assertFalse(old_run_path.exists())
            self.assertTrue(locked_state_path.exists())
            self.assertTrue(locked_lock_path.exists())
            self.assertTrue(locked_run_path.exists())
            self.assertTrue(fresh_state_path.exists())
            self.assertTrue(fresh_lock_path.exists())
            self.assertTrue(fresh_run_path.exists())
            self.assertEqual(stderr.getvalue(), "")
