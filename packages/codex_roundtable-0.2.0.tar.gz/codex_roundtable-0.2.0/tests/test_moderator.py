import unittest


class ModeratorTest(unittest.TestCase):
    def test_build_participant_prompt_is_participant_specific(self) -> None:
        from codex_roundtable.moderator import build_participant_prompt

        topic = "Review this API split"
        claude_prompt = build_participant_prompt("claude", topic)
        opencode_prompt = build_participant_prompt("opencode", topic)

        self.assertNotEqual(claude_prompt, opencode_prompt)
        self.assertIn("correctness", claude_prompt.lower())
        self.assertIn("maintainability", claude_prompt.lower())
        self.assertIn("long-term design quality", claude_prompt.lower())
        self.assertIn("implementation feasibility", opencode_prompt.lower())
        self.assertIn("execution risk", opencode_prompt.lower())
        self.assertIn("engineering tradeoffs", opencode_prompt.lower())
        self.assertIn(topic, claude_prompt)
        self.assertIn(topic, opencode_prompt)

    def test_build_participant_prompt_unknown_participant_raises_value_error(self) -> None:
        from codex_roundtable.moderator import build_participant_prompt

        with self.assertRaises(ValueError):
            build_participant_prompt("unknown", "topic")

    def test_synthesize_successful_responses_single_success_shape(self) -> None:
        from codex_roundtable.moderator import synthesize_successful_responses

        synthesis = synthesize_successful_responses(
            [
                {
                    "participant_id": "claude",
                    "status": "success",
                    "response": "Prefer explicit error handling for safer evolution.",
                }
            ]
        )

        self.assertEqual(
            set(synthesis.keys()),
            {"consensus", "disagreements", "risks", "recommendation", "confidence"},
        )
        self.assertEqual(synthesis["consensus"], [])
        self.assertEqual(
            synthesis["disagreements"],
            ["claude: Prefer explicit error handling for safer evolution."],
        )
        self.assertIn("only one successful participant", synthesis["risks"][0].lower())
        self.assertIn("manual review", synthesis["recommendation"].lower())
        self.assertEqual(synthesis["confidence"], "low")

    def test_synthesize_successful_responses_multiple_success_shape(self) -> None:
        from codex_roundtable.moderator import synthesize_successful_responses

        synthesis = synthesize_successful_responses(
            [
                {
                    "participant_id": "opencode",
                    "status": "success",
                    "response": "Flag rollout and migration blast radius before changing APIs.",
                },
                {
                    "participant_id": "claude",
                    "status": "success",
                    "response": "Keep interfaces stable and prefer additive evolution.",
                },
            ]
        )

        self.assertEqual(
            set(synthesis.keys()),
            {"consensus", "disagreements", "risks", "recommendation", "confidence"},
        )
        self.assertIn("multiple successful participants", synthesis["consensus"][0].lower())
        self.assertEqual(
            synthesis["disagreements"],
            [
                "claude: Keep interfaces stable and prefer additive evolution.",
                "opencode: Flag rollout and migration blast radius before changing APIs.",
            ],
        )
        self.assertIn("no semantic fusion", synthesis["risks"][0].lower())
        self.assertEqual(synthesis["confidence"], "medium")

    def test_synthesize_successful_responses_zero_success_raises_value_error(self) -> None:
        from codex_roundtable.moderator import synthesize_successful_responses

        with self.assertRaises(ValueError):
            synthesize_successful_responses([])

    def test_derive_follow_up_reason_returns_none_for_converged_successes(self) -> None:
        from codex_roundtable.moderator import derive_follow_up_reason

        payloads = [
            {
                "participant_id": "claude",
                "status": "success",
                "response": "Recommend the additive API path because it minimizes migration risk.",
            },
            {
                "participant_id": "opencode",
                "status": "success",
                "response": "Recommend an additive API rollout because it keeps migration risk low.",
            },
        ]

        self.assertIsNone(derive_follow_up_reason(payloads))

    def test_derive_follow_up_reason_returns_clarify_difference_for_divergent_successes(
        self,
    ) -> None:
        from codex_roundtable.moderator import derive_follow_up_reason

        payloads = [
            {
                "participant_id": "claude",
                "status": "success",
                "response": "Recommend keeping the current interface and deferring the rewrite.",
            },
            {
                "participant_id": "opencode",
                "status": "success",
                "response": "Recommend rewriting the interface now to reduce future complexity.",
            },
        ]

        self.assertEqual(derive_follow_up_reason(payloads), "clarify_difference")

    def test_build_follow_up_prompt_includes_topic_and_participant_attributed_digests(
        self,
    ) -> None:
        from codex_roundtable.moderator import build_follow_up_prompt

        topic = "Should we split the API before launch?"
        payloads = [
            {
                "participant_id": "claude",
                "status": "success",
                "response": "Recommend waiting until after launch to avoid destabilizing contracts.",
            },
            {
                "participant_id": "opencode",
                "status": "success",
                "response": "Recommend splitting now because the migration cost will only grow.",
            },
        ]

        prompt = build_follow_up_prompt(topic, payloads)

        self.assertIsInstance(prompt, str)
        self.assertIn(topic, prompt)
        self.assertIn("claude: Recommend waiting until after launch", prompt)
        self.assertIn("opencode: Recommend splitting now because the migration cost will only grow.", prompt)
        self.assertIn("restate their recommendation briefly", prompt.lower())
        self.assertIn("strongest reason", prompt.lower())
        self.assertIn("what condition would change their view", prompt.lower())

    def test_follow_up_helpers_ignore_empty_or_invalid_successful_payloads(self) -> None:
        from codex_roundtable.moderator import build_follow_up_prompt, derive_follow_up_reason

        payloads = [
            {"participant_id": "claude", "status": "success", "response": ""},
            {"participant_id": "", "status": "success", "response": "Need more evidence."},
            {"participant_id": "opencode", "status": "error", "response": "Timed out."},
        ]

        self.assertIsNone(derive_follow_up_reason(payloads))
        self.assertIsNone(build_follow_up_prompt("Topic", payloads))
