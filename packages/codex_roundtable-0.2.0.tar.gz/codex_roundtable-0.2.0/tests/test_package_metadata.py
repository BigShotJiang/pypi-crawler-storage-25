import importlib
import os
import pathlib
import subprocess
import sys
import tempfile
import tomllib
import unittest
import venv


class PackageMetadataTest(unittest.TestCase):
    def test_project_metadata_and_entrypoint_exist(self) -> None:
        root = pathlib.Path(__file__).resolve().parents[1]
        data = tomllib.loads((root / "pyproject.toml").read_text(encoding="utf-8"))
        project = data["project"]
        script_target = project["scripts"]["codex-roundtable"]

        self.assertEqual(data["project"]["name"], "codex-roundtable")
        self.assertEqual(data["project"]["requires-python"], ">=3.11")
        self.assertEqual(script_target, "codex_roundtable.cli:main")

        self.assertEqual(project["version"], "0.2.0")
        with self.subTest("version matches package version module"):
            sys.path.insert(0, str(root / "orchestrator"))
            try:
                version_module = importlib.import_module("codex_roundtable.version")
                self.assertEqual(project["version"], version_module.__version__)
            finally:
                sys.path.pop(0)

        module_name, function_name = script_target.split(":", maxsplit=1)
        with self.subTest("script target is importable and callable"):
            sys.path.insert(0, str(root / "orchestrator"))
            try:
                module = importlib.import_module(module_name)
                entrypoint = getattr(module, function_name)
                self.assertTrue(callable(entrypoint))
                result = entrypoint([])
            finally:
                sys.path.pop(0)
            self.assertIsInstance(result, int)

    def test_source_tree_module_entrypoint_smoke_with_pythonpath(self) -> None:
        """Source-tree smoke contract: requires PYTHONPATH=<absolute orchestrator path>."""
        root = pathlib.Path(__file__).resolve().parents[1]
        env = os.environ.copy()
        existing = env.get("PYTHONPATH")
        orchestrator_path = str(root / "orchestrator")
        env["PYTHONPATH"] = (
            f"{orchestrator_path}{os.pathsep}{existing}"
            if existing
            else orchestrator_path
        )

        result = subprocess.run(
            [sys.executable, "-m", "codex_roundtable"],
            cwd=root,
            env=env,
            capture_output=True,
            text=True,
            check=False,
        )

        self.assertEqual(
            result.returncode,
            0,
            msg=f"stdout={result.stdout!r} stderr={result.stderr!r}",
        )

    def test_editable_install_entrypoint_smoke(self) -> None:
        """Installed contract: editable install exposes both module and console-script paths."""
        root = pathlib.Path(__file__).resolve().parents[1]
        egg_info_dir = root / "orchestrator" / "codex_roundtable.egg-info"

        def _delete_tree(path: pathlib.Path) -> None:
            if not path.exists():
                return
            for file_path in path.rglob("*"):
                if file_path.is_file() or file_path.is_symlink():
                    file_path.unlink()
            for dir_path in sorted((p for p in path.rglob("*") if p.is_dir()), reverse=True):
                dir_path.rmdir()
            path.rmdir()

        with tempfile.TemporaryDirectory() as tmpdir:
            venv_path = pathlib.Path(tmpdir) / ".venv"
            venv.EnvBuilder(with_pip=True).create(venv_path)

            bin_dir = venv_path / ("Scripts" if os.name == "nt" else "bin")
            python_bin = bin_dir / ("python.exe" if os.name == "nt" else "python")
            script_bin = bin_dir / (
                "codex-roundtable.exe" if os.name == "nt" else "codex-roundtable"
            )

            try:
                install = subprocess.run(
                    [str(python_bin), "-m", "pip", "install", "-e", str(root)],
                    cwd=root,
                    capture_output=True,
                    text=True,
                    check=False,
                )
                self.assertEqual(
                    install.returncode,
                    0,
                    msg=f"stdout={install.stdout!r} stderr={install.stderr!r}",
                )

                module_run = subprocess.run(
                    [str(python_bin), "-m", "codex_roundtable"],
                    cwd=root,
                    capture_output=True,
                    text=True,
                    check=False,
                )
                self.assertEqual(
                    module_run.returncode,
                    0,
                    msg=f"stdout={module_run.stdout!r} stderr={module_run.stderr!r}",
                )

                script_run = subprocess.run(
                    [str(script_bin)],
                    cwd=root,
                    capture_output=True,
                    text=True,
                    check=False,
                )
                self.assertEqual(
                    script_run.returncode,
                    0,
                    msg=f"stdout={script_run.stdout!r} stderr={script_run.stderr!r}",
                )
            finally:
                _delete_tree(egg_info_dir)
