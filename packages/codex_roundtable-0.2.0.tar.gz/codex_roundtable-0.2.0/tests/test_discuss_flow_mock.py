import json
import os
import tempfile
import unittest
from pathlib import Path
from unittest import mock


class DiscussFlowMockTest(unittest.TestCase):
    def test_run_discussion_all_success_status_ok_and_artifacts_written(self) -> None:
        from codex_roundtable.orchestrator import run_discussion

        with tempfile.TemporaryDirectory() as temp_dir:
            state_root = Path(temp_dir) / "state"
            with mock.patch.dict(
                os.environ,
                {"CODEX_ROUNDTABLE_HOME": str(state_root)},
                clear=False,
            ):
                with mock.patch(
                    "codex_roundtable.participants.invoke_participant",
                    side_effect=[
                        {
                            "participant_id": "claude",
                            "status": "success",
                            "response": "Claude response",
                            "duration_ms": 10,
                            "error_detail": None,
                        },
                        {
                            "participant_id": "opencode",
                            "status": "success",
                            "response": "OpenCode response",
                            "duration_ms": 11,
                            "error_detail": None,
                        },
                    ],
                ):
                    artifact = run_discussion(
                        topic="Should we split repos?",
                        workspace=temp_dir,
                        session_name="design",
                        follow_up_once=False,
                    )

                self.assertEqual(artifact["status"], "ok")
                self.assertEqual(artifact["version"], "2.1")
                self.assertEqual(artifact["moderator"], "codex")
                self.assertIn("started_at", artifact)
                self.assertIn("ended_at", artifact)
                self.assertIn("metadata", artifact)
                self.assertFalse(artifact["metadata"]["degraded"])
                self.assertFalse(artifact["follow_up_enabled"])
                self.assertIsNone(artifact["follow_up_reason"])
                self.assertEqual(artifact["stop_reason"], "round_one_complete")
                self.assertEqual(artifact["participants"], ["claude", "opencode"])
                self.assertIn("synthesis", artifact)
                self.assertIn("rounds", artifact)
                self.assertEqual(len(artifact["rounds"]), 1)
                self.assertEqual(artifact["rounds"][0]["round_index"], 1)
                self.assertEqual(artifact["rounds"][0]["prompt_role"], "initial")
                self.assertEqual(len(artifact["rounds"][0]["responses"]), 2)

                json_path = Path(str(artifact["json_path"]))
                markdown_path = Path(str(artifact["markdown_path"]))
                self.assertTrue(json_path.exists())
                self.assertTrue(markdown_path.exists())

                persisted = json.loads(json_path.read_text(encoding="utf-8"))
                self.assertEqual(persisted["version"], "2.1")
                self.assertEqual(persisted["moderator"], "codex")
                self.assertIn("started_at", persisted)
                self.assertIn("ended_at", persisted)
                self.assertFalse(persisted["metadata"]["degraded"])
                self.assertEqual(persisted["status"], "ok")
                self.assertFalse(persisted["follow_up_enabled"])
                self.assertIsNone(persisted["follow_up_reason"])
                self.assertEqual(persisted["stop_reason"], "round_one_complete")
                self.assertIn("synthesis", persisted)

    def test_run_discussion_partial_failure_status_degraded_with_synthesis(self) -> None:
        from codex_roundtable.orchestrator import run_discussion

        with tempfile.TemporaryDirectory() as temp_dir:
            state_root = Path(temp_dir) / "state"
            with mock.patch.dict(
                os.environ,
                {"CODEX_ROUNDTABLE_HOME": str(state_root)},
                clear=False,
            ):
                with mock.patch(
                    "codex_roundtable.participants.invoke_participant",
                    side_effect=[
                        {
                            "participant_id": "claude",
                            "status": "success",
                            "response": "Claude response",
                            "duration_ms": 10,
                            "error_detail": None,
                        },
                        {
                            "participant_id": "opencode",
                            "status": "error",
                            "response": None,
                            "duration_ms": 15,
                            "error_detail": "adapter failed",
                        },
                    ],
                ):
                    artifact = run_discussion(
                        topic="Should we split repos?",
                        workspace=temp_dir,
                        session_name="design",
                        follow_up_once=False,
                    )

        self.assertEqual(artifact["status"], "degraded")
        self.assertEqual(artifact["version"], "2.1")
        self.assertTrue(artifact["metadata"]["degraded"])
        self.assertFalse(artifact["follow_up_enabled"])
        self.assertIsNone(artifact["follow_up_reason"])
        self.assertEqual(artifact["stop_reason"], "round_one_complete")
        self.assertIn("synthesis", artifact)
        self.assertEqual(artifact["participants"], ["claude", "opencode"])
        responses = artifact["rounds"][0]["responses"]
        statuses = sorted(str(item["status"]) for item in responses)
        self.assertEqual(statuses, ["error", "success"])

    def test_run_discussion_reuses_thread_names_and_increments_binding_counters(self) -> None:
        from codex_roundtable.orchestrator import run_discussion
        from codex_roundtable.paths import session_state_path
        from codex_roundtable.session_store import load_session

        invocations: list[tuple[str, str | None]] = []

        def invoke_stub(
            participant_id: str,
            prompt: str,
            workspace_root: str,
            thread_name: str | None,
            timeout_seconds: int,
        ) -> dict[str, object]:
            _ = prompt, workspace_root, timeout_seconds
            invocations.append((participant_id, thread_name))
            return {
                "participant_id": participant_id,
                "status": "success",
                "response": f"{participant_id} response",
                "duration_ms": 5,
                "error_detail": None,
            }

        with tempfile.TemporaryDirectory() as temp_dir:
            state_root = Path(temp_dir) / "state"
            with mock.patch.dict(
                os.environ,
                {"CODEX_ROUNDTABLE_HOME": str(state_root)},
                clear=False,
            ):
                with mock.patch(
                    "codex_roundtable.participants.invoke_participant",
                    side_effect=invoke_stub,
                ):
                    first = run_discussion(
                        topic="topic-1",
                        workspace=temp_dir,
                        session_name="stable-session",
                    )
                    second = run_discussion(
                        topic="topic-2",
                        workspace=temp_dir,
                        session_name="stable-session",
                    )

                session = load_session(session_state_path(str(first["session_key"])))

        self.assertEqual(first["session_key"], second["session_key"])
        self.assertEqual(len(invocations), 4)
        first_run = invocations[:2]
        second_run = invocations[2:]

        first_threads = {participant_id: thread for participant_id, thread in first_run}
        second_threads = {participant_id: thread for participant_id, thread in second_run}
        self.assertEqual(set(first_threads.keys()), {"claude", "opencode"})
        self.assertEqual(first_threads, second_threads)
        self.assertTrue(all(thread for thread in first_threads.values()))

        bindings_by_participant = {
            binding.participant_id: binding for binding in session.participant_bindings
        }
        self.assertEqual(set(bindings_by_participant.keys()), {"claude", "opencode"})
        self.assertEqual(bindings_by_participant["claude"].thread_name, first_threads["claude"])
        self.assertEqual(bindings_by_participant["opencode"].thread_name, first_threads["opencode"])
        self.assertEqual(bindings_by_participant["claude"].run_count, 2)
        self.assertEqual(bindings_by_participant["opencode"].run_count, 2)

    def test_run_discussion_follow_up_once_executes_second_round_with_same_threads(self) -> None:
        from codex_roundtable.orchestrator import run_discussion

        invocations: list[dict[str, str | int | None]] = []

        def invoke_stub(
            participant_id: str,
            prompt: str,
            workspace_root: str,
            thread_name: str | None,
            timeout_seconds: int,
        ) -> dict[str, object]:
            _ = workspace_root, timeout_seconds
            invocations.append(
                {
                    "participant_id": participant_id,
                    "prompt": prompt,
                    "thread_name": thread_name,
                }
            )
            if "First-round participant digests" in prompt:
                return {
                    "participant_id": participant_id,
                    "status": "success",
                    "response": f"{participant_id} follow-up response",
                    "duration_ms": 8,
                    "error_detail": None,
                }
            if participant_id == "claude":
                return {
                    "participant_id": participant_id,
                    "status": "success",
                    "response": "Recommend keeping the current interface and deferring the rewrite.",
                    "duration_ms": 6,
                    "error_detail": None,
                }
            return {
                "participant_id": participant_id,
                "status": "success",
                "response": "Recommend rewriting the interface now to reduce future complexity.",
                "duration_ms": 7,
                "error_detail": None,
            }

        with tempfile.TemporaryDirectory() as temp_dir:
            state_root = Path(temp_dir) / "state"
            with mock.patch.dict(
                os.environ,
                {"CODEX_ROUNDTABLE_HOME": str(state_root)},
                clear=False,
            ):
                with mock.patch(
                    "codex_roundtable.participants.invoke_participant",
                    side_effect=invoke_stub,
                ):
                    artifact = run_discussion(
                        topic="Should we split the API before launch?",
                        workspace=temp_dir,
                        session_name="follow-up-needed",
                        follow_up_once=True,
                    )

        self.assertEqual(artifact["version"], "2.1")
        self.assertTrue(artifact["follow_up_enabled"])
        self.assertEqual(artifact["follow_up_reason"], "clarify_difference")
        self.assertEqual(artifact["stop_reason"], "follow_up_complete")
        self.assertEqual(len(artifact["rounds"]), 2)
        self.assertEqual(artifact["rounds"][0]["prompt_role"], "initial")
        self.assertEqual(artifact["rounds"][1]["prompt_role"], "follow_up")
        self.assertEqual(
            [response["participant_id"] for response in artifact["rounds"][1]["responses"]],
            ["claude", "opencode"],
        )
        self.assertEqual(len(invocations), 4)

        first_round = invocations[:2]
        second_round = invocations[2:]
        first_threads = {item["participant_id"]: item["thread_name"] for item in first_round}
        second_threads = {item["participant_id"]: item["thread_name"] for item in second_round}
        self.assertEqual(first_threads, second_threads)
        self.assertTrue(all(thread for thread in first_threads.values()))
        self.assertTrue(
            all("First-round participant digests" in str(item["prompt"]) for item in second_round)
        )
        self.assertTrue(
            all("Should we split the API before launch?" in str(item["prompt"]) for item in second_round)
        )

    def test_run_discussion_follow_up_not_needed_stops_after_one_round(self) -> None:
        from codex_roundtable.orchestrator import run_discussion

        with tempfile.TemporaryDirectory() as temp_dir:
            state_root = Path(temp_dir) / "state"
            with mock.patch.dict(
                os.environ,
                {"CODEX_ROUNDTABLE_HOME": str(state_root)},
                clear=False,
            ):
                with mock.patch(
                    "codex_roundtable.participants.invoke_participant",
                    side_effect=[
                        {
                            "participant_id": "claude",
                            "status": "success",
                            "response": "Recommend the additive API path because it minimizes migration risk.",
                            "duration_ms": 10,
                            "error_detail": None,
                        },
                        {
                            "participant_id": "opencode",
                            "status": "success",
                            "response": "Recommend an additive API rollout because it keeps migration risk low.",
                            "duration_ms": 11,
                            "error_detail": None,
                        },
                    ],
                ) as invoke_mock:
                    artifact = run_discussion(
                        topic="Should we split repos?",
                        workspace=temp_dir,
                        session_name="converged",
                        follow_up_once=True,
                    )

        self.assertEqual(invoke_mock.call_count, 2)
        self.assertEqual(artifact["status"], "ok")
        self.assertTrue(artifact["follow_up_enabled"])
        self.assertIsNone(artifact["follow_up_reason"])
        self.assertEqual(artifact["stop_reason"], "follow_up_not_needed")
        self.assertEqual(len(artifact["rounds"]), 1)
        self.assertEqual(artifact["rounds"][0]["prompt_role"], "initial")
