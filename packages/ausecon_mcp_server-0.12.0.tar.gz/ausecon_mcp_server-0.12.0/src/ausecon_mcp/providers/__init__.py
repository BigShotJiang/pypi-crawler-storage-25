"""Source provider implementations."""
