"""ausecon-mcp-server package."""
