"""
NeuralBridge SDK — Self-healing decision engine for AI API calls.
v1.1.2
"""

__version__ = "1.1.2"

from .engine import FlywheelEngine, NeuralBridgeEngine, DiagnosisEngine
from .types import (
    DiagnosisResult, ErrorCategory, RecoveryAction, RecoveryRecord,
    CascadeLevel, ModelPerformance, HealthStatus, RequestTrace,
)
from .circuit_breaker import CircuitBreaker, CircuitBreakerConfig, CircuitState
from .rate_limiter import RateLimiter, RateLimiterConfig
from .tiered_timeout import TieredTimeoutManager, TieredTimeoutConfig, TimeoutTier
from .jitter import JitterConfig, JitterStrategy
from .strategies import (
    RecoveryStrategy, RateLimitStrategy, AuthRefreshStrategy,
    ModelFallbackStrategy, NetworkRetryStrategy, StrategyRegistry,
)

try:
    from .adapters.openai_adapter import NeuralBridge as NeuralBridgeClient
except ImportError:
    NeuralBridgeClient = None

try:
    from .provider_profiles import ProviderType, detect_provider, get_profile, is_reasoning_model
except ImportError:
    pass

try:
    from .telemetry import NeuralBridgeTelemetry, TelemetryConfig
except ImportError:
    pass

__all__ = [
    "NeuralBridgeEngine", "FlywheelEngine", "DiagnosisEngine",
    "DiagnosisResult", "ErrorCategory", "RecoveryAction", "RecoveryRecord",
    "CascadeLevel", "ModelPerformance", "HealthStatus", "RequestTrace",
    "CircuitBreaker", "CircuitBreakerConfig", "CircuitState",
    "RateLimiter", "RateLimiterConfig",
    "TieredTimeoutManager", "TieredTimeoutConfig", "TimeoutTier",
    "JitterConfig", "JitterStrategy",
    "RecoveryStrategy", "RateLimitStrategy", "AuthRefreshStrategy",
    "ModelFallbackStrategy", "NetworkRetryStrategy", "StrategyRegistry",
]
