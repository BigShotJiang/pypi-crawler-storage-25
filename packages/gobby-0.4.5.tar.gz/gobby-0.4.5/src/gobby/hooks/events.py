"""Unified hook event models for multi-CLI session management.

This module defines the unified internal representation for hook events across
all supported CLIs (Claude Code, Droid CLI, Gemini CLI, Qwen CLI, Codex CLI).
Adapters translate between CLI-specific formats and these unified types.

Design Decision: This file coexists with hook_types.py. The existing HookType enum
in hook_types.py uses Claude-specific kebab-case names (session-start, pre-tool-use)
and Pydantic models for input validation. The HookEventType enum here is the unified
internal representation. Adapters translate between them.
"""

from dataclasses import dataclass, field
from datetime import datetime
from enum import Enum
from typing import Any, Literal


class HookEventType(str, Enum):
    """Unified hook event types across all CLI sources.

    These map to CLI-specific hook names via adapters:
    - Claude Code: kebab-case (session-start, pre-tool-use)
    - Droid CLI: PascalCase (SessionStart, PreToolUse)
    - Gemini CLI: PascalCase (SessionStart, BeforeTool)
    - Codex CLI: PascalCase hooks.json names (SessionStart, PreToolUse)
    """

    # Session lifecycle
    SESSION_START = "session_start"
    SESSION_END = "session_end"

    # Agent/turn lifecycle
    BEFORE_AGENT = "before_agent"
    AFTER_AGENT = "after_agent"
    STOP = "stop"  # Agent is about to stop/exit

    # Tool lifecycle
    BEFORE_TOOL = "before_tool"
    AFTER_TOOL = "after_tool"
    BEFORE_TOOL_SELECTION = "before_tool_selection"  # Gemini only

    # Model lifecycle (Gemini only)
    BEFORE_MODEL = "before_model"
    AFTER_MODEL = "after_model"

    # Context management
    PRE_COMPACT = "pre_compact"  # Claude/Codex: PreCompact, Gemini: PreCompress
    POST_COMPACT = "post_compact"  # Claude/Codex: PostCompact

    # Subagent lifecycle (Claude Code only)
    SUBAGENT_START = "subagent_start"
    SUBAGENT_STOP = "subagent_stop"

    # Permissions & notifications
    PERMISSION_REQUEST = "permission_request"
    PERMISSION_DENIED = "permission_denied"  # Claude Code only
    NOTIFICATION = "notification"

    # Claude-specific lifecycle and observability events
    STOP_FAILURE = "stop_failure"
    TASK_CREATED = "task_created"
    TASK_COMPLETED = "task_completed"
    TEAMMATE_IDLE = "teammate_idle"
    INSTRUCTIONS_LOADED = "instructions_loaded"
    CONFIG_CHANGE = "config_change"
    CWD_CHANGED = "cwd_changed"
    FILE_CHANGED = "file_changed"
    WORKTREE_CREATE = "worktree_create"
    WORKTREE_REMOVE = "worktree_remove"
    ELICITATION = "elicitation"
    ELICITATION_RESULT = "elicitation_result"


class SessionSource(str, Enum):
    """Identifies which CLI originated the session."""

    CLAUDE = "claude"
    DROID = "droid"
    GEMINI = "gemini"
    QWEN = "qwen"
    CODEX = "codex"
    PIPELINE = "pipeline"


@dataclass
class HookEvent:
    """Unified hook event from any CLI source.

    This dataclass represents a normalized hook event that can originate from
    any supported CLI. Adapters are responsible for translating CLI-specific
    payloads into this format.

    Attributes:
        event_type: The type of hook event (from HookEventType enum).
        session_id: External session identifier (external_id for Claude, thread_id for Codex).
        source: Which CLI originated this event.
        timestamp: When the event occurred.
        data: Event-specific payload in native format (adapter passes through).

        machine_id: Unique identifier for the machine (populated by adapter or manager).
        cwd: Current working directory for the session.

        user_id: Platform user ID (populated by HookManager after session lookup).
        project_id: Platform project ID (populated by HookManager).
        workflow_id: Future: ID of workflow evaluating this event.
        metadata: Extensible key-value store for adapter-specific data.
    """

    # Core required fields
    event_type: HookEventType
    session_id: str  # external_id / thread_id (external ID)
    source: SessionSource
    timestamp: datetime
    data: dict[str, Any]  # Event-specific payload (native format)

    # Context (populated by adapter or manager)
    machine_id: str | None = None
    cwd: str | None = None

    # Future extensibility
    user_id: str | None = None
    project_id: str | None = None
    task_id: str | None = None
    workflow_id: str | None = None
    metadata: dict[str, Any] = field(default_factory=dict)


@dataclass
class HookResponse:
    """Unified response returned to CLI.

    This dataclass represents the response that will be translated back to
    CLI-specific format by the adapter.

    Attributes:
        decision: Whether to allow, deny, or ask the user about the action.
        context: Text to inject into the agent's context (AI-only).
        system_message: User-visible message to display (e.g., handoff notification).
        reason: Explanation for the decision (useful for denials).

        modify_args: Future: Dict of argument modifications for the action.
        trigger_action: Future: Action to trigger in the CLI.
        metadata: Extensible key-value store for adapter-specific data.
    """

    decision: Literal["allow", "deny", "ask", "block", "modify"] = "allow"
    context: str | None = None  # Inject into agent context (AI-only)
    system_message: str | None = None  # User-visible message (e.g., handoff notification)
    reason: str | None = None  # Explanation for decision

    # Input rewriting (PreToolUse / PermissionRequest)
    modified_input: dict[str, Any] | None = None
    auto_approve: bool = False
    permission_decision: Literal["allow", "deny"] | None = None
    updated_permissions: list[dict[str, Any]] | None = None

    # Event-specific Claude outputs
    retry: bool = False
    watch_paths: list[str] | None = None
    worktree_path: str | None = None
    elicitation_action: Literal["accept", "decline", "cancel"] | None = None
    elicitation_content: dict[str, Any] | None = None
    elicitation_error: str | None = None

    # Future extensibility
    modify_args: dict[str, Any] | None = None
    trigger_action: str | None = None
    metadata: dict[str, Any] = field(default_factory=dict)


# Event type mapping table for documentation (see plan-multi-cli.md section 1.2)
# This is informational - actual mappings are in adapters
EVENT_TYPE_CLI_SUPPORT: dict[HookEventType, dict[str, str | None]] = {
    HookEventType.SESSION_START: {
        "claude": "SessionStart",
        "gemini": "SessionStart",
        "qwen": "SessionStart",
        "codex": "SessionStart",
    },
    HookEventType.SESSION_END: {
        "claude": "SessionEnd",
        "gemini": "SessionEnd",
        "qwen": "SessionEnd",
        "codex": None,
    },
    HookEventType.BEFORE_AGENT: {
        "claude": "UserPromptSubmit",
        "gemini": "BeforeAgent",
        "qwen": "BeforeAgent",
        "codex": "UserPromptSubmit",
    },
    HookEventType.AFTER_AGENT: {
        "claude": "Stop",
        "gemini": "AfterAgent",
        "qwen": "AfterAgent",
        "codex": None,
    },
    HookEventType.STOP: {
        "claude": "Stop",
        "gemini": None,
        "qwen": None,
        "codex": "Stop",
    },
    HookEventType.BEFORE_TOOL: {
        "claude": "PreToolUse",
        "gemini": "BeforeTool",
        "qwen": "BeforeTool",
        "codex": "PreToolUse",
    },
    HookEventType.AFTER_TOOL: {
        "claude": "PostToolUse",
        "gemini": "AfterTool",
        "qwen": "AfterTool",
        "codex": "PostToolUse",
    },
    HookEventType.BEFORE_TOOL_SELECTION: {
        "claude": None,
        "gemini": "BeforeToolSelection",
        "qwen": "BeforeToolSelection",
        "codex": None,
    },
    HookEventType.BEFORE_MODEL: {
        "claude": None,
        "gemini": "BeforeModel",
        "qwen": "BeforeModel",
        "codex": None,
    },
    HookEventType.AFTER_MODEL: {
        "claude": None,
        "gemini": "AfterModel",
        "qwen": "AfterModel",
        "codex": None,
    },
    HookEventType.PRE_COMPACT: {
        "claude": "PreCompact",
        "gemini": "PreCompress",
        "qwen": "PreCompress",
        "codex": "PreCompact",
    },
    HookEventType.POST_COMPACT: {
        "claude": "PostCompact",
        "gemini": None,
        "qwen": None,
        "codex": "PostCompact",
    },
    HookEventType.SUBAGENT_START: {
        "claude": "SubagentStart",
        "gemini": None,
        "qwen": None,
        "codex": None,
    },
    HookEventType.SUBAGENT_STOP: {
        "claude": "SubagentStop",
        "gemini": None,
        "qwen": None,
        "codex": None,
    },
    HookEventType.PERMISSION_REQUEST: {
        "claude": "PermissionRequest",
        "gemini": None,
        "qwen": None,
        "codex": "PermissionRequest",
    },
    HookEventType.PERMISSION_DENIED: {
        "claude": "PermissionDenied",
        "gemini": None,
        "qwen": None,
        "codex": None,
    },
    HookEventType.NOTIFICATION: {
        "claude": "Notification",
        "gemini": "Notification",
        "qwen": "Notification",
        "codex": None,
    },
    HookEventType.STOP_FAILURE: {
        "claude": "StopFailure",
        "gemini": None,
        "qwen": None,
        "codex": None,
    },
    HookEventType.TASK_CREATED: {
        "claude": "TaskCreated",
        "gemini": None,
        "qwen": None,
        "codex": None,
    },
    HookEventType.TASK_COMPLETED: {
        "claude": "TaskCompleted",
        "gemini": None,
        "qwen": None,
        "codex": None,
    },
    HookEventType.TEAMMATE_IDLE: {
        "claude": "TeammateIdle",
        "gemini": None,
        "qwen": None,
        "codex": None,
    },
    HookEventType.INSTRUCTIONS_LOADED: {
        "claude": "InstructionsLoaded",
        "gemini": None,
        "qwen": None,
        "codex": None,
    },
    HookEventType.CONFIG_CHANGE: {
        "claude": "ConfigChange",
        "gemini": None,
        "qwen": None,
        "codex": None,
    },
    HookEventType.CWD_CHANGED: {
        "claude": "CwdChanged",
        "gemini": None,
        "qwen": None,
        "codex": None,
    },
    HookEventType.FILE_CHANGED: {
        "claude": "FileChanged",
        "gemini": None,
        "qwen": None,
        "codex": None,
    },
    HookEventType.WORKTREE_CREATE: {
        "claude": "WorktreeCreate",
        "gemini": None,
        "qwen": None,
        "codex": None,
    },
    HookEventType.WORKTREE_REMOVE: {
        "claude": "WorktreeRemove",
        "gemini": None,
        "qwen": None,
        "codex": None,
    },
    HookEventType.ELICITATION: {
        "claude": "Elicitation",
        "gemini": None,
        "qwen": None,
        "codex": None,
    },
    HookEventType.ELICITATION_RESULT: {
        "claude": "ElicitationResult",
        "gemini": None,
        "qwen": None,
        "codex": None,
    },
}
