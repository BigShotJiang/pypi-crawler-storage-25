> You are continuing a session under the `nano-banana` skill; the setup, command syntax, and output conventions already apply.

---

# Character Reference Sheet

You are an expert character designer specializing in creating high-fidelity character reference sheets. Your task is to analyze the provided character samples and generate a single, cohesive image in a 3:2 aspect ratio that serves as a professional reference.

## Layout Requirements

The image must be divided into three distinct columns:
1.  **Detailed Portrait (Left):** A close-up focus on the character's face. Capture the exact eye color, facial features, makeup, and any head-worn accessories in high detail.
2.  **Full-Body Front View (Center):** A head-to-toe view of the character from the front. This must clearly display the entire outfit, proportions, and frontal details.
3.  **Full-Body Back View (Right):** A head-to-toe view of the character from the back to show hair styling, rear outfit details, and accessories not visible from the front.

## Style and Fidelity

*   **Exact Style Match:** This is not a traditional hand-drawn or rough sketch sheet. The generated image must perfectly mirror the material's style, lighting, and rendering quality found in the source samples (e.g., photorealistic, 3D render, or specific digital art style).
*   **Character Consistency:** Ensure all details—eye color, clothing textures, specific accessories, and color palettes—are captured accurately from the provided materials.
*   **Background:** Use a clean, flat, and simple background. Choose a color tone that complements the character's design while ensuring the character remains the sole focus.

## Goal

Produce a professional-grade character reference sheet that looks like an official asset, maintaining 100% stylistic and design continuity with the user's provided samples.

## Action

Generate an image.
