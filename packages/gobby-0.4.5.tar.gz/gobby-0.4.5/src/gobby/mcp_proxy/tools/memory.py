"""
Internal MCP tools for Gobby Memory System.

Exposes functionality for:
- Creating memories (create_memory)
- Searching memories (search_memories)
- Deleting memories (delete_memory)
- Listing memories (list_memories)
- Getting memory details (get_memory)
- Updating memories (update_memory)
- Memory statistics (memory_stats)

These tools are registered with the InternalToolRegistry and accessed
via the downstream proxy pattern (call_tool).
"""

from __future__ import annotations

import asyncio
import logging
from typing import TYPE_CHECKING, Any, Protocol

from gobby.mcp_proxy.tools.internal import InternalToolRegistry
from gobby.memory.digest import (
    bootstrap_session_title as _bootstrap_session_title,
)
from gobby.memory.digest import (
    build_turn_and_digest as _build_turn_and_digest,
)
from gobby.memory.digest import (
    memory_sync_export,
    memory_sync_import,
)
from gobby.memory.manager import MemoryManager
from gobby.sync.memories import is_ephemeral_implementation_note

if TYPE_CHECKING:
    from gobby.config.app import DaemonConfig
    from gobby.llm.service import LLMService

logger = logging.getLogger(__name__)


class SupportsTaskDecomposition(Protocol):
    def create_task_with_decomposition(
        self,
        *,
        project_id: str,
        title: str,
        **kwargs: Any,
    ) -> dict[str, Any]: ...


# Helper to get current project context
def get_current_project_id() -> str | None:
    """Get the current project ID from context, or None if not in a project."""
    from gobby.utils.project_context import get_project_context

    ctx = get_project_context()
    if ctx and ctx.get("id"):
        return str(ctx["id"])
    return None


def _speculative_memory_task_title(content: str) -> str | None:
    """Return a planning task title for narrow implementation-proposal memories."""
    normalized = " ".join(content.lower().split())
    has_session_start_pattern = (
        "sessionstart" in normalized
        and "ensure_session_activation" in normalized
        and "helper" in normalized
        and "replay raw sessionstart side effects" in normalized
    )
    has_proposal_language = any(
        marker in normalized
        for marker in (
            "proposed",
            "proposal",
            "call an idempotent",
            "call a helper",
        )
    )
    if has_session_start_pattern and has_proposal_language:
        return "gobby-session-start-reconciliation-proposal"
    return None


def _redirect_speculative_memory_to_task(
    *,
    memory_manager: MemoryManager,
    task_manager: SupportsTaskDecomposition | None,
    title: str,
    content: str,
    project_id: str | None,
    source_session_id: str | None,
) -> dict[str, Any]:
    from gobby.storage.projects import PERSONAL_PROJECT_ID
    from gobby.storage.session_tasks import SessionTaskManager
    from gobby.storage.tasks import LocalTaskManager

    manager = task_manager or LocalTaskManager(memory_manager.db)
    result = manager.create_task_with_decomposition(
        project_id=project_id or PERSONAL_PROJECT_ID,
        title=title,
        description=(
            "Redirected from gobby-memory.create_memory because this content is a "
            "speculative implementation proposal rather than durable memory.\n\n"
            f"{content}"
        ),
        priority=3,
        task_type="research_spike",
        labels=["memory-redirect", "planning-note"],
        category="planning",
        created_in_session_id=source_session_id,
    )
    task = result.get("task") if isinstance(result, dict) else None
    if not isinstance(task, dict) or not task.get("id"):
        raise RuntimeError("Speculative memory redirection did not create a task.")

    if source_session_id:
        try:
            SessionTaskManager(memory_manager.db).link_task(
                source_session_id, task["id"], "created"
            )
        except Exception as e:
            logger.debug("Failed to link redirected memory task to session: %s", e)

    seq_num = task.get("seq_num")
    return {
        "id": task["id"],
        "ref": f"#{seq_num}" if seq_num else task["id"],
    }


def create_memory_registry(
    memory_manager: MemoryManager,
    llm_service: LLMService | None = None,
    memory_sync_manager: Any | None = None,
    session_manager: Any | None = None,
    config: DaemonConfig | None = None,
    task_manager: SupportsTaskDecomposition | None = None,
) -> InternalToolRegistry:
    """
    Create a memory tool registry with all memory-related tools.

    Args:
        memory_manager: MemoryManager instance
        llm_service: LLM service for AI-powered extraction (optional)
        memory_sync_manager: MemorySyncManager for sync import/export (optional)
        session_manager: SessionManager for session lookups (optional)
        config: DaemonConfig for digest provider/model selection (optional)

    Returns:
        InternalToolRegistry with memory tools registered
    """
    registry = InternalToolRegistry(
        name="gobby-memory",
        description="Memory management - create_memory, search_memories, delete_memory, get_related_memories",
    )

    @registry.tool(
        name="create_memory",
        description="Create a new memory. Returns similar existing memories to help detect duplicates.",
    )
    async def create_memory(
        content: str,
        memory_type: str = "fact",
        tags: list[str] | None = None,
        session_id: str | None = None,
    ) -> dict[str, Any]:
        """
        Create a new memory.

        Args:
            content: The memory content to store
            memory_type: Type of memory (fact, preference, etc)
            tags: Optional list of tags
            session_id: Session ID that created this memory (accepts #N, N, UUID, or prefix)
        """
        try:
            if is_ephemeral_implementation_note(
                {"content": content, "type": memory_type, "tags": tags or []}
            ):
                return {
                    "success": True,
                    "skipped": True,
                    "reason": "ephemeral_implementation_note",
                }

            project_id = get_current_project_id()

            # Resolve session_id to UUID before passing to storage layer
            # (memories.source_session_id has FK constraint on sessions.id)
            resolved_session_id: str | None = None
            if session_id:
                try:
                    from gobby.storage.session_resolution import resolve_session_reference

                    resolved_session_id = resolve_session_reference(
                        memory_manager.db, session_id, project_id
                    )
                except Exception as e:
                    logger.warning(f"Could not resolve session_id '{session_id}': {e}")

            redirected_task_title = _speculative_memory_task_title(content)
            if redirected_task_title:
                try:
                    task = _redirect_speculative_memory_to_task(
                        memory_manager=memory_manager,
                        task_manager=task_manager,
                        title=redirected_task_title,
                        content=content,
                        project_id=project_id,
                        source_session_id=resolved_session_id,
                    )
                    return {
                        "success": True,
                        "redirected_to_task_note": True,
                        "task_id": task["id"],
                        "task_ref": task["ref"],
                    }
                except Exception as e:
                    logger.warning(
                        "Speculative memory redirection failed; storing original memory: %s",
                        e,
                        exc_info=True,
                    )

            memory = await memory_manager.create_memory(
                content=content,
                memory_type=memory_type,
                project_id=project_id,
                tags=tags,
                source_type="agent",
                source_session_id=resolved_session_id,
            )

            # Search for similar existing memories to surface potential duplicates
            similar_existing: list[dict[str, Any]] = []
            try:
                similar = await memory_manager.search_memories(
                    query=content,
                    project_id=project_id,
                    limit=4,  # fetch 4 since the new memory itself may appear
                )
                for m in similar:
                    if m.id != memory.id:
                        similar_existing.append(
                            {
                                "id": m.id,
                                "content": m.content,
                                "similarity": getattr(m, "similarity", None),
                            }
                        )
                similar_existing = similar_existing[:3]
            except Exception as e:
                logger.debug(
                    f"Similarity search failed during memory creation (project_id={project_id}, memory_id={memory.id}): {e}",
                    exc_info=True,
                )

            return {
                "success": True,
                "memory": {
                    "id": memory.id,
                },
                "similar_existing": similar_existing,
            }
        except Exception as e:
            return {"success": False, "error": str(e)}

    @registry.tool(
        name="search_memories",
        description="Search memories based on query and filters. Supports tag-based filtering.",
    )
    async def search_memories(
        query: str | None = None,
        limit: int = 10,
        min_score: float = 0.0,
        tags_all: list[str] | None = None,
        tags_any: list[str] | None = None,
        tags_none: list[str] | None = None,
    ) -> dict[str, Any]:
        """
        Search memories based on query and filters.

        Args:
            query: Search query string
            limit: Maximum number of memories to return
            min_score: Optional minimum semantic similarity score (0.0-1.0).
            tags_all: Memory must have ALL of these tags
            tags_any: Memory must have at least ONE of these tags
            tags_none: Memory must have NONE of these tags
        """
        try:
            effective_min_score = min_score if min_score > 0 else 0.0

            # Fetch extra candidates so we can report diagnostics when
            # nothing passes the threshold.
            candidates = await memory_manager.search_memories(
                query=query,
                project_id=get_current_project_id(),
                limit=limit * 2 if effective_min_score > 0 else limit,
                min_score=None,  # no threshold — filter below
                tags_all=tags_all,
                tags_any=tags_any,
                tags_none=tags_none,
            )

            # Split by threshold
            above: list[dict[str, Any]] = []
            below_count = 0
            max_score_seen = 0.0
            for m in candidates:
                similarity = getattr(m, "similarity", None)
                threshold_score = similarity or 0.0
                max_score_seen = max(max_score_seen, threshold_score)
                if effective_min_score > 0 and threshold_score < effective_min_score:
                    below_count += 1
                    continue
                if len(above) < limit:
                    above.append(
                        {
                            "id": m.id,
                            "content": m.content,
                            "type": m.memory_type,
                            "created_at": m.created_at,
                            "tags": m.tags,
                            "similarity": similarity,
                            "search_via": getattr(m, "search_via", None),
                            "ranking_score": getattr(m, "ranking_score", None),
                            "raw_semantic_score": getattr(m, "raw_semantic_score", None),
                            "temporal_decay_factor": getattr(m, "temporal_decay_factor", None),
                            "ranking_mode": getattr(m, "ranking_mode", None),
                        }
                    )

            result: dict[str, Any] = {
                "success": True,
                "memories": above,
            }
            if not above and below_count > 0:
                result["below_threshold_count"] = below_count
                result["max_score_seen"] = round(max_score_seen, 4)
                result["threshold"] = effective_min_score

            return result
        except Exception as e:
            return {"success": False, "error": str(e)}

    @registry.tool(
        name="delete_memory",
        description="Delete a memory by ID.",
    )
    async def delete_memory(memory_id: str) -> dict[str, Any]:
        """
        Delete a memory by ID.

        Args:
            memory_id: The ID of the memory to delete
        """
        try:
            success = await memory_manager.delete_memory(memory_id)
            if success:
                return {"success": True}
            else:
                return {"success": False, "error": f"Memory {memory_id} not found"}
        except Exception as e:
            return {"success": False, "error": str(e)}

    @registry.tool(
        name="list_memories",
        description="List all memories with optional filtering. Supports tag-based filtering.",
    )
    def list_memories(
        memory_type: str | None = None,
        limit: int = 50,
        tags_all: list[str] | None = None,
        tags_any: list[str] | None = None,
        tags_none: list[str] | None = None,
    ) -> dict[str, Any]:
        """
        List all memories with optional filtering.

        Args:
            memory_type: Filter by memory type (fact, preference, pattern, context)
            limit: Maximum number of memories to return
            tags_all: Memory must have ALL of these tags
            tags_any: Memory must have at least ONE of these tags
            tags_none: Memory must have NONE of these tags
        """
        try:
            memories = memory_manager.list_memories(
                project_id=get_current_project_id(),
                memory_type=memory_type,
                limit=limit,
                tags_all=tags_all,
                tags_any=tags_any,
                tags_none=tags_none,
            )
            return {
                "success": True,
                "memories": [
                    {
                        "id": m.id,
                        "content": m.content,
                        "type": m.memory_type,
                        "created_at": m.created_at,
                        "tags": m.tags,
                    }
                    for m in memories
                ],
                "count": len(memories),
            }
        except Exception as e:
            return {"success": False, "error": str(e)}

    @registry.tool(
        name="get_memory",
        description="Get details of a specific memory by ID.",
    )
    def get_memory(memory_id: str) -> dict[str, Any]:
        """
        Get details of a specific memory.

        Args:
            memory_id: The ID of the memory to retrieve
        """
        try:
            memory = memory_manager.get_memory(memory_id, project_id=get_current_project_id())
            if memory:
                return {
                    "success": True,
                    "memory": {
                        "id": memory.id,
                        "content": memory.content,
                        "type": memory.memory_type,
                        "created_at": memory.created_at,
                        "updated_at": memory.updated_at,
                        "project_id": memory.project_id,
                        "source_type": memory.source_type,
                        "access_count": memory.access_count,
                        "tags": memory.tags,
                    },
                }
            else:
                return {"success": False, "error": f"Memory {memory_id} not found"}
        except ValueError as e:
            return {"success": False, "error": str(e)}
        except Exception as e:
            return {"success": False, "error": str(e)}

    @registry.tool(
        name="get_related_memories",
        description="Get memories related to a specific memory via cross-references.",
    )
    async def get_related_memories(
        memory_id: str,
        limit: int = 5,
        min_similarity: float = 0.0,
    ) -> dict[str, Any]:
        """
        Get memories linked to a specific memory via cross-references.

        Cross-references are automatically created based on semantic similarity
        when memories are stored (if auto_crossref is enabled in config).

        Args:
            memory_id: The ID of the memory to find related memories for
            limit: Maximum number of related memories to return
            min_similarity: Minimum similarity threshold (0.0-1.0)
        """
        try:
            memories = await memory_manager.get_related(
                memory_id=memory_id,
                limit=limit,
                min_similarity=min_similarity,
                project_id=get_current_project_id(),
            )
            return {
                "success": True,
                "memory_id": memory_id,
                "related": [
                    {
                        "id": m.id,
                        "content": m.content,
                        "type": m.memory_type,
                        "created_at": m.created_at,
                        "tags": m.tags,
                    }
                    for m in memories
                ],
                "count": len(memories),
            }
        except ValueError as e:
            return {"success": False, "error": str(e)}
        except Exception as e:
            return {"success": False, "error": str(e)}

    @registry.tool(
        name="update_memory",
        description="Update an existing memory's content or tags.",
    )
    async def update_memory(
        memory_id: str,
        content: str | None = None,
        tags: list[str] | None = None,
    ) -> dict[str, Any]:
        """
        Update an existing memory.

        Args:
            memory_id: The ID of the memory to update
            content: New content (optional)
            tags: New list of tags (optional)
        """
        try:
            memory = await memory_manager.update_memory(
                memory_id=memory_id,
                content=content,
                tags=tags,
            )
            return {
                "success": True,
                "memory": {
                    "id": memory.id,
                    "updated_at": memory.updated_at,
                },
            }
        except ValueError as e:
            return {"success": False, "error": str(e)}
        except Exception as e:
            return {"success": False, "error": str(e)}

    @registry.tool(
        name="remember_with_image",
        description="Create a memory from an image. Uses LLM to describe the image and stores it with the description.",
    )
    async def remember_with_image(
        image_path: str,
        context: str | None = None,
        memory_type: str = "fact",
        tags: list[str] | None = None,
    ) -> dict[str, Any]:
        """
        Create a memory from an image file.

        Uses the configured LLM provider to generate a description of the image,
        then stores the memory with the description as content and the image
        as a media attachment.

        Args:
            image_path: Path to the image file
            context: Optional context to guide the image description (e.g., "This is a screenshot of an error")
            memory_type: Type of memory (fact, preference, etc)
            tags: Optional list of tags
        """
        if not llm_service:
            return {
                "success": False,
                "error": "LLM service not configured. Image memories require an LLM provider.",
            }

        try:
            memory = await memory_manager.remember_with_image(
                image_path=image_path,
                context=context,
                memory_type=memory_type,
                project_id=get_current_project_id(),
                tags=tags,
                source_type="agent",
            )
            return {
                "success": True,
                "memory": {
                    "id": memory.id,
                    "content": memory.content,
                    "media_path": image_path,
                },
            }
        except ValueError as e:
            return {"success": False, "error": str(e)}
        except Exception as e:
            return {"success": False, "error": str(e)}

    @registry.tool(
        name="remember_screenshot",
        description="Create a memory from raw screenshot bytes (base64 encoded). Saves to .gobby/resources/ and describes with LLM.",
    )
    async def remember_screenshot(
        screenshot_base64: str,
        context: str | None = None,
        memory_type: str = "observation",
        tags: list[str] | None = None,
    ) -> dict[str, Any]:
        """
        Create a memory from raw screenshot bytes.

        Saves the screenshot to .gobby/resources/ with a timestamp-based filename,
        uses LLM to describe it, and stores the memory with the description.

        Args:
            screenshot_base64: Base64-encoded PNG screenshot bytes
            context: Optional context to guide the image description
            memory_type: Type of memory (default: "observation")
            tags: Optional list of tags
        """
        import base64

        if not llm_service:
            return {
                "success": False,
                "error": "LLM service not configured. Screenshot memories require an LLM provider.",
            }

        try:
            # Decode base64 to bytes
            screenshot_bytes = base64.b64decode(screenshot_base64)

            memory = await memory_manager.remember_screenshot(
                screenshot_bytes=screenshot_bytes,
                context=context,
                memory_type=memory_type,
                project_id=get_current_project_id(),
                tags=tags,
                source_type="agent",
            )
            return {
                "success": True,
                "memory": {
                    "id": memory.id,
                    "content": memory.content,
                },
            }
        except ValueError as e:
            return {"success": False, "error": str(e)}
        except Exception as e:
            return {"success": False, "error": str(e)}

    @registry.tool(
        name="memory_stats",
        description="Get statistics about the memory system.",
    )
    def memory_stats() -> dict[str, Any]:
        """
        Get statistics about stored memories.
        """
        try:
            stats = memory_manager.get_stats(project_id=get_current_project_id())
            return {"success": True, "stats": stats}
        except Exception as e:
            return {"success": False, "error": str(e)}

    @registry.tool(
        name="search_knowledge_graph",
        description="Search the Neo4j knowledge graph for entities matching a query.",
    )
    async def search_knowledge_graph(
        query: str,
        limit: int = 10,
    ) -> dict[str, Any]:
        """
        Search the knowledge graph for entities matching a query.

        Args:
            query: Search query string
            limit: Maximum number of results to return
        """
        try:
            kg_service = memory_manager.kg_service
            if not kg_service:
                return {"success": True, "results": []}

            results = await kg_service.search_graph(query, limit=limit)
            return {"success": True, "results": results}
        except Exception as e:
            return {"success": False, "error": str(e)}

    @registry.tool(
        name="rebuild_crossrefs",
        description="Rebuild cross-references between all memories based on semantic similarity. Creates edges for the 2D memory graph.",
    )
    async def rebuild_crossrefs(
        project_id: str | None = None,
        limit: int = 500,
    ) -> dict[str, Any]:
        """
        Rebuild cross-references for all existing memories.

        Uses vector similarity to find related memories and create links.
        These links power the 2D memory graph visualization.

        Args:
            project_id: Optional project ID to filter memories
            limit: Maximum number of memories to process (default 500)
        """
        try:
            memories = memory_manager.list_memories(project_id=project_id, limit=limit)
            total_created = 0
            for i, memory in enumerate(memories):
                try:
                    created = await memory_manager.rebuild_crossrefs_for_memory(memory)
                    total_created += created
                except Exception as e:
                    logger.warning(f"Crossref failed for {memory.id}: {e}")
                if i % 10 == 9:
                    await asyncio.sleep(0)
            return {
                "success": True,
                "memories_processed": len(memories),
                "crossrefs_created": total_created,
            }
        except Exception as e:
            return {"success": False, "error": str(e)}

    @registry.tool(
        name="rebuild_knowledge_graph",
        description="Extract entities and relationships from all memories into the Neo4j knowledge graph. Powers the 3D graph visualization.",
    )
    async def rebuild_knowledge_graph(
        project_id: str | None = None,
        limit: int = 500,
    ) -> dict[str, Any]:
        """
        Rebuild the knowledge graph from all existing memories.

        Extracts entities and relationships using LLM and stores them in Neo4j.
        This powers the 3D knowledge graph visualization.

        Args:
            project_id: Optional project ID to filter memories
            limit: Max memories to process (default 500)
        """
        try:
            result = await memory_manager.rebuild_knowledge_graph(
                project_id=project_id,
                limit=limit,
            )
            return result
        except Exception as e:
            return {"success": False, "error": str(e)}

    @registry.tool(
        name="reindex_embeddings",
        description="Regenerate embedding vectors for all stored memories. Useful after changing embedding models or for initial setup.",
    )
    async def reindex_embeddings() -> dict[str, Any]:
        """
        Regenerate embeddings for all stored memories.
        """
        try:
            return await memory_manager.reindex_embeddings()
        except Exception as e:
            return {"success": False, "error": str(e)}

    # ─── Sync & extraction tools (thin wrappers around workflow actions) ───

    @registry.tool(
        name="bootstrap_session_title",
        description="Set a local heuristic session title from the first meaningful user prompt. Fired by a turn_start rule before the first completed turn.",
    )
    async def bootstrap_session_title_tool(
        session_id: str = "",
        prompt_text: str | None = None,
    ) -> dict[str, Any]:
        """
        Bootstrap a session title without an LLM call.

        Args:
            session_id: Platform session ID (injected by dispatch layer)
            prompt_text: User prompt text for heuristic title derivation
        """
        if not session_id:
            return {"success": False, "error": "session_id is required"}
        if session_manager is None:
            return {"success": False, "error": "session_manager is required"}
        try:
            title = await _bootstrap_session_title(session_manager, session_id, prompt_text)
            if not title:
                return {
                    "success": True,
                    "skipped": True,
                    "reason": "title already set or prompt unusable",
                }
            return {"success": True, "title": title}
        except Exception as e:
            return {"success": False, "error": str(e)}

    @registry.tool(
        name="sync_import",
        description="Import memories from .gobby/memories.jsonl into the database.",
    )
    async def sync_import() -> dict[str, Any]:
        """Import memories from filesystem JSONL into SQLite."""
        if not memory_sync_manager:
            return {"success": False, "error": "Memory sync manager not available"}
        try:
            result = await memory_sync_import(memory_sync_manager)
            if "error" in result:
                return {"success": False, "error": result["error"]}
            return {"success": True, "imported": result["imported"]["memories"]}
        except Exception as e:
            return {"success": False, "error": str(e)}

    @registry.tool(
        name="sync_export",
        description="Export memories from the database to .gobby/memories.jsonl.",
    )
    async def sync_export() -> dict[str, Any]:
        """Export memories from SQLite to filesystem JSONL for Git persistence."""
        if not memory_sync_manager:
            return {"success": False, "error": "Memory sync manager not available"}
        try:
            project_id = get_current_project_id()
            result = await memory_sync_export(memory_sync_manager, project_id=project_id)
            if "error" in result:
                return {"success": False, "error": result["error"]}
            return {"success": True, "exported": result["exported"]["memories"]}
        except Exception as e:
            return {"success": False, "error": str(e)}

    # NOTE: This tool is invoked via the `digest-on-response` DB rule (event=stop, mcp_call effect).
    # It is NOT called directly from Python code. Do not remove without also removing the DB rule.
    @registry.tool(
        name="build_turn_and_digest",
        description="Build a detailed turn record from the last agent response, append it to the session digest, and synthesize a title. Fired by digest-on-response rule on stop events.",
    )
    async def build_turn_and_digest_tool(
        session_id: str = "",
        prompt_text: str | None = None,
    ) -> dict[str, Any]:
        """
        Build turn record and append to digest after agent response.

        Reads the last user/assistant exchange from the transcript,
        generates a structured turn record via LLM, appends it to the
        session's rolling digest, and synthesizes a title via
        ``build_turn_and_digest``.

        Args:
            session_id: Platform session ID (injected by dispatch layer)
            prompt_text: Optional user prompt (usually None for stop events)
        """
        if not session_id:
            return {"success": False, "error": "session_id is required"}
        try:
            result = await _build_turn_and_digest(
                memory_manager=memory_manager,
                session_manager=session_manager,
                session_id=session_id,
                prompt_text=prompt_text,
                llm_service=llm_service,
                config=config,
            )
            if result is None:
                return {"success": True, "skipped": True, "reason": "disabled or no content"}
            if "error" in result:
                return {"success": False, "error": result["error"]}
            return {"success": True, **result}
        except Exception as e:
            return {"success": False, "error": str(e)}

    # ─── Cleanup tools for nightly memory hygiene (#10572) ───

    @registry.tool(
        name="audit_memories",
        description="Audit memories for stale, duplicate, code-derivable, and orphaned entries. Returns a report without deleting anything.",
    )
    async def audit_memories(
        max_stale_age_days: int = 30,
        max_stale_access_count: int = 1,
        stale_confidence_threshold: float = 0.85,
        limit_per_category: int = 500,
        use_stale_classifier: bool = True,
        categories: list[str] | None = None,
    ) -> dict[str, Any]:
        """
        Audit memories and report what would be cleaned up.

        Equivalent to cleanup_memories with dry_run=True.

        Args:
            max_stale_age_days: Memories inactive longer than this are stale candidates.
            max_stale_access_count: Maximum access_count still considered low-access.
            stale_confidence_threshold: Minimum classifier confidence for stale deletion.
            limit_per_category: Maximum candidates to scan per category.
            use_stale_classifier: Whether stale candidates require LLM classification.
            categories: Which categories to audit (default: all).
                Valid: "stale", "duplicates", "code_derivable", "orphaned"
        """
        from gobby.memory.services.maintenance import execute_cleanup

        try:
            stale_audit_config = (
                config.memory.stale_audit if config is not None and config.memory else None
            )
            report = await execute_cleanup(
                memory_manager=memory_manager,
                dry_run=True,
                categories=categories,
                max_stale_age_days=max_stale_age_days,
                max_stale_access_count=max_stale_access_count,
                stale_confidence_threshold=stale_confidence_threshold,
                limit_per_category=limit_per_category,
                project_id=get_current_project_id(),
                llm_service=llm_service,
                stale_audit_config=stale_audit_config,
                use_stale_classifier=use_stale_classifier,
            )
            if "error" in report:
                return {"success": False, "error": report["error"]}
            return {"success": True, **report}
        except Exception as e:
            return {"success": False, "error": str(e)}

    @registry.tool(
        name="cleanup_memories",
        description="Find and remove stale, duplicate, code-derivable, and orphaned memories. Supports dry_run mode and category filtering.",
    )
    async def cleanup_memories(
        dry_run: bool = False,
        max_stale_age_days: int = 30,
        max_stale_access_count: int = 1,
        stale_confidence_threshold: float = 0.85,
        similarity_threshold: float = 0.95,
        limit_per_category: int = 500,
        use_stale_classifier: bool = True,
        categories: list[str] | None = None,
    ) -> dict[str, Any]:
        """
        Run memory cleanup: find and optionally delete problematic memories.

        Args:
            dry_run: If true, report what would be cleaned without deleting (default: false)
            max_stale_age_days: Memories inactive longer than this are stale candidates.
            max_stale_access_count: Maximum access_count still considered low-access.
            stale_confidence_threshold: Minimum classifier confidence for stale deletion.
            similarity_threshold: Vector similarity threshold for duplicate detection (default: 0.95)
            limit_per_category: Maximum candidates to scan per category.
            use_stale_classifier: Whether stale candidates require LLM classification.
            categories: Which categories to clean (default: all).
                Valid: "stale", "duplicates", "code_derivable", "orphaned"
        """
        from gobby.memory.services.maintenance import execute_cleanup

        try:
            stale_audit_config = (
                config.memory.stale_audit if config is not None and config.memory else None
            )
            report = await execute_cleanup(
                memory_manager=memory_manager,
                dry_run=dry_run,
                categories=categories,
                max_stale_age_days=max_stale_age_days,
                max_stale_access_count=max_stale_access_count,
                stale_confidence_threshold=stale_confidence_threshold,
                similarity_threshold=similarity_threshold,
                limit_per_category=limit_per_category,
                project_id=get_current_project_id(),
                llm_service=llm_service,
                stale_audit_config=stale_audit_config,
                use_stale_classifier=use_stale_classifier,
            )
            if "error" in report:
                return {"success": False, "error": report["error"]}
            return {"success": True, **report}
        except Exception as e:
            return {"success": False, "error": str(e)}

    return registry
