"""Framework-native swarm, session, and checkpoint models."""

from __future__ import annotations

import copy
import inspect
import time
import uuid
from dataclasses import asdict, dataclass, field
from typing import Any, Callable, Dict, List


@dataclass
class SwarmSeedContext:
    """Read-only seeded context carried into an agent lane."""

    summary: str = ""
    verified_facts: List[str] = field(default_factory=list)
    constraints: List[str] = field(default_factory=list)
    preferences: List[str] = field(default_factory=list)

    @classmethod
    def from_raw(cls, value: Any) -> "SwarmSeedContext":
        if isinstance(value, cls):
            return copy.deepcopy(value)
        if isinstance(value, str):
            return cls(summary=value.strip())
        if not isinstance(value, dict):
            return cls()

        def normalize_list(candidate: Any) -> List[str]:
            if not isinstance(candidate, list):
                return []
            return [str(item).strip() for item in candidate if str(item).strip()]

        return cls(
            summary=str(value.get("summary") or "").strip(),
            verified_facts=normalize_list(value.get("verified_facts")),
            constraints=normalize_list(value.get("constraints")),
            preferences=normalize_list(value.get("preferences")),
        )

    def has_content(self) -> bool:
        return bool(self.summary or self.verified_facts or self.constraints or self.preferences)

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)


@dataclass
class SwarmNodeBehaviorConfig:
    """Behavior configuration for a swarm node."""

    response_style: str = "conversational"
    ask_mode: str = "single_missing_detail"
    allow_checklists: bool = False
    allow_escalation_payloads: bool = False
    next_step_policy: str = "concrete_first"
    scratchpad_policy: str = "task_focused"
    history_scope: str = "agent"
    seed_context: SwarmSeedContext = field(default_factory=SwarmSeedContext)

    @classmethod
    def from_raw(cls, value: Any) -> "SwarmNodeBehaviorConfig":
        defaults = cls()
        if isinstance(value, cls):
            return copy.deepcopy(value)
        if not isinstance(value, dict):
            return defaults

        result = cls()
        result.response_style = str(value.get("response_style") or defaults.response_style).strip() or defaults.response_style
        result.ask_mode = str(value.get("ask_mode") or defaults.ask_mode).strip() or defaults.ask_mode
        result.allow_checklists = bool(value.get("allow_checklists", defaults.allow_checklists))
        result.allow_escalation_payloads = bool(value.get("allow_escalation_payloads", defaults.allow_escalation_payloads))
        result.next_step_policy = str(value.get("next_step_policy") or defaults.next_step_policy).strip() or defaults.next_step_policy
        result.scratchpad_policy = str(value.get("scratchpad_policy") or defaults.scratchpad_policy).strip().lower() or defaults.scratchpad_policy
        result.history_scope = str(value.get("history_scope") or defaults.history_scope).strip().lower() or defaults.history_scope
        result.seed_context = SwarmSeedContext.from_raw(value.get("seed_context"))
        if result.history_scope not in {"agent", "shared", "full"}:
            result.history_scope = defaults.history_scope
        if result.scratchpad_policy not in {"disabled", "task_focused", "handoff_focus", "full_turn"}:
            result.scratchpad_policy = defaults.scratchpad_policy
        return result

    def to_dict(self) -> Dict[str, Any]:
        payload = asdict(self)
        payload["seed_context"] = self.seed_context.to_dict()
        return payload


@dataclass
class SwarmNode:
    """A single agent node in the swarm graph."""

    id: str
    node_key: str
    name: str
    system_prompt: str | Callable[..., str]
    intent: str = ""
    capabilities: List[str] = field(default_factory=list)
    persona: str = ""
    model_choice: str = ""
    enabled_tools: List[Dict[str, Any]] = field(default_factory=list)
    behavior_config: SwarmNodeBehaviorConfig = field(default_factory=SwarmNodeBehaviorConfig)
    is_entry_node: bool = False

    def __post_init__(self) -> None:
        self.behavior_config = SwarmNodeBehaviorConfig.from_raw(self.behavior_config)


@dataclass
class SwarmEdge:
    """A directed handoff edge between two nodes."""

    id: str
    source_node_id: str
    target_node_id: str
    handoff_description: str = ""
    required_variables: List[str] = field(default_factory=list)


@dataclass
class SwarmVariable:
    """Global variable definition with reducer behavior."""

    key_name: str
    description: str = ""
    reducer_rule: str = "overwrite"


@dataclass
class AgentRuntimeContext:
    """Mutable runtime context kept per agent lane."""

    agent_name: str = ""
    history_scope: str = "agent"
    scratchpad_policy: str = "task_focused"
    seed_context: SwarmSeedContext = field(default_factory=SwarmSeedContext)
    scratchpad: Dict[str, Any] = field(default_factory=dict)
    last_handoff_in: Dict[str, Any] = field(default_factory=dict)
    last_handoff_out: Dict[str, Any] = field(default_factory=dict)

    @classmethod
    def from_raw(cls, value: Any) -> "AgentRuntimeContext":
        if isinstance(value, cls):
            return copy.deepcopy(value)
        if not isinstance(value, dict):
            return cls()
        return cls(
            agent_name=str(value.get("agent_name") or "").strip(),
            history_scope=str(value.get("history_scope") or "agent").strip() or "agent",
            scratchpad_policy=str(value.get("scratchpad_policy") or "task_focused").strip() or "task_focused",
            seed_context=SwarmSeedContext.from_raw(value.get("seed_context")),
            scratchpad=copy.deepcopy(value.get("scratchpad") or {}),
            last_handoff_in=copy.deepcopy(value.get("last_handoff_in") or {}),
            last_handoff_out=copy.deepcopy(value.get("last_handoff_out") or {}),
        )

    def to_dict(self) -> Dict[str, Any]:
        payload = asdict(self)
        payload["seed_context"] = self.seed_context.to_dict()
        return payload


@dataclass
class SessionCheckpoint:
    """Append-only runtime checkpoint."""

    session_id: str
    step_number: int
    action_type: str
    acting_node_id: str | None
    state_snapshot: Dict[str, Any]
    created_at: float = field(default_factory=time.time)
    id: str = field(default_factory=lambda: uuid.uuid4().hex)


@dataclass
class SwarmDefinition:
    """Framework-native swarm graph definition."""

    id: str
    name: str
    graph_version: int = 1
    nodes: List[SwarmNode] = field(default_factory=list)
    edges: List[SwarmEdge] = field(default_factory=list)
    variables: List[SwarmVariable] = field(default_factory=list)

    def node_by_id(self, node_id: str | None) -> SwarmNode | None:
        if node_id is None:
            return None
        for node in self.nodes:
            if node.id == node_id:
                return node
        return None

    def node_by_name(self, name: str) -> SwarmNode | None:
        normalized = str(name or "").strip().lower()
        if not normalized:
            return None
        for node in self.nodes:
            if node.name.strip().lower() == normalized:
                return node
        return None

    def node_by_key(self, node_key: str) -> SwarmNode | None:
        normalized = str(node_key or "").strip().lower()
        if not normalized:
            return None
        for node in self.nodes:
            if node.node_key.strip().lower() == normalized:
                return node
        return None

    def entry_node(self) -> SwarmNode | None:
        for node in self.nodes:
            if node.is_entry_node:
                return node
        return self.nodes[0] if self.nodes else None

    def outgoing_edges(self, node_id: str) -> List[SwarmEdge]:
        return [edge for edge in self.edges if edge.source_node_id == node_id]

    def variable_rule_for(self, key_name: str) -> str:
        for variable in self.variables:
            if variable.key_name == key_name:
                return variable.reducer_rule
        return "overwrite"


@dataclass
class SwarmSession:
    """Framework-native session state for a swarm run."""

    id: str
    swarm: SwarmDefinition
    current_node_id: str | None = None
    global_variables: Dict[str, Any] = field(default_factory=dict)
    agent_histories: Dict[str, List[Dict[str, Any]]] = field(default_factory=dict)
    agent_contexts: Dict[str, AgentRuntimeContext] = field(default_factory=dict)
    rolling_summary: str = ""
    created_at: float = field(default_factory=time.time)
    updated_at: float = field(default_factory=time.time)

    def __post_init__(self) -> None:
        normalized_contexts: Dict[str, AgentRuntimeContext] = {}
        for key, value in (self.agent_contexts or {}).items():
            normalized_contexts[str(key)] = AgentRuntimeContext.from_raw(value)
        self.agent_contexts = normalized_contexts

        if self.current_node_id is None:
            entry_node = self.swarm.entry_node()
            self.current_node_id = entry_node.id if entry_node else None

    @property
    def current_node(self) -> SwarmNode | None:
        return self.swarm.node_by_id(self.current_node_id)

    def snapshot(self) -> Dict[str, Any]:
        return {
            "global_variables": copy.deepcopy(self.global_variables),
            "agent_histories": copy.deepcopy(self.agent_histories),
            "agent_contexts": {
                key: context.to_dict()
                for key, context in self.agent_contexts.items()
            },
            "rolling_summary": self.rolling_summary,
            "current_node_id": self.current_node_id,
        }

    def touch(self) -> None:
        self.updated_at = time.time()


@dataclass
class SystemPromptContext:
    """Context passed to code-defined system prompt builder functions."""

    session: SwarmSession
    swarm: SwarmDefinition
    agent_node: SwarmNode
    visible_global_variables: Dict[str, Any] = field(default_factory=dict)
    agent_context: AgentRuntimeContext | None = None


def serialize_system_prompt(value: str | Callable[..., str]) -> str:
    if isinstance(value, str):
        return value
    if not callable(value):
        return str(value or "")
    builder_name = str(getattr(value, "__name__", "dynamic_system_prompt") or "dynamic_system_prompt")
    summary = str(inspect.getdoc(value) or "").strip()
    if summary:
        return f"<callable:{builder_name}> {summary}"
    return f"<callable:{builder_name}>"


def invoke_system_prompt_builder(value: str | Callable[..., str], context: SystemPromptContext) -> str:
    if isinstance(value, str):
        return value.strip()
    if not callable(value):
        return str(value or "").strip()

    signature = inspect.signature(value)
    positional_params = [
        parameter
        for parameter in signature.parameters.values()
        if parameter.kind in {inspect.Parameter.POSITIONAL_ONLY, inspect.Parameter.POSITIONAL_OR_KEYWORD}
    ]
    accepts_var_kwargs = any(
        parameter.kind == inspect.Parameter.VAR_KEYWORD for parameter in signature.parameters.values()
    )
    kwargs: Dict[str, Any] = {}

    for name, parameter in signature.parameters.items():
        if parameter.kind in {inspect.Parameter.VAR_POSITIONAL, inspect.Parameter.VAR_KEYWORD}:
            continue
        if name == "context":
            kwargs[name] = context
        elif name == "session":
            kwargs[name] = context.session
        elif name == "swarm":
            kwargs[name] = context.swarm
        elif name in {"agent_node", "node"}:
            kwargs[name] = context.agent_node
        elif name == "visible_global_variables":
            kwargs[name] = copy.deepcopy(context.visible_global_variables)
        elif name == "agent_context":
            kwargs[name] = context.agent_context

    if accepts_var_kwargs:
        kwargs.setdefault("context", context)
        kwargs.setdefault("session", context.session)
        kwargs.setdefault("swarm", context.swarm)
        kwargs.setdefault("agent_node", context.agent_node)
        kwargs.setdefault("visible_global_variables", copy.deepcopy(context.visible_global_variables))
        kwargs.setdefault("agent_context", context.agent_context)

    if not signature.parameters:
        result = value()
    elif len(positional_params) == 1 and not kwargs:
        result = value(context)
    else:
        result = value(**kwargs)

    return str(result or "").strip()
