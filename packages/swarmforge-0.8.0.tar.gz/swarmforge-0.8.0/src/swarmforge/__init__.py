"""Headless multi-agent chat and evaluation framework."""

__version__ = "0.1.0"

__all__ = ["api", "authoring", "evaluation", "swarm"]
