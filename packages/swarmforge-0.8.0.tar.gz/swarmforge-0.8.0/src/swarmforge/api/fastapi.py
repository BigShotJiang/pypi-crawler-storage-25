"""FastAPI integration for exposing the swarm runtime over HTTP."""

from __future__ import annotations

import copy
import json
import uuid
from typing import Any, AsyncGenerator, Callable, Dict, List

from fastapi import Body, FastAPI, HTTPException, Response
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import StreamingResponse
from pydantic import BaseModel, Field

from ..authoring import build_swarm_definition
from ..evaluation import build_graph_snapshot
from ..evaluation.provider import ModelConfig, OpenAIClientWrapper
from ..evaluation.swarm import serialize_checkpoints
from ..swarm import GlobalVariableManager, InMemorySessionStore, SessionStore, SwarmDefinition, SwarmSession, process_swarm_stream
from ..swarm.orchestrator import AgentTurnConfig, AgentTurnResult, AgentTurnRunner, RequiredVariableExtractor
from ..swarm.tools import ToolRegistry

RUN_SWARM_OPENAPI_EXAMPLES = {
    "openrouter": {
        "summary": "Run a swarm turn with OpenRouter",
        "value": {
            "swarm": {
                "id": "support",
                "name": "Support Swarm",
                "nodes": [
                    {
                        "node_key": "assistant",
                        "name": "Assistant",
                        "system_prompt": "You are a helpful assistant.",
                        "intent": "Handle the full request",
                        "capabilities": ["Answer questions"],
                        "is_entry_node": True,
                    }
                ],
                "edges": [],
                "variables": [],
            },
            "user_input": "Give me a concise answer.",
            "provider": {
                "provider": "openrouter",
                "model": "openrouter/auto",
                "site_url": "https://your-app.example",
                "app_name": "Your App Name",
            },
        },
    },
    "gemini": {
        "summary": "Run a swarm turn with Gemini OpenAI-compat",
        "value": {
            "swarm": {
                "id": "support",
                "name": "Support Swarm",
                "nodes": [
                    {
                        "node_key": "assistant",
                        "name": "Assistant",
                        "system_prompt": "You are a helpful assistant.",
                        "intent": "Handle the full request",
                        "capabilities": ["Answer questions"],
                        "is_entry_node": True,
                    }
                ],
                "edges": [],
                "variables": [],
            },
            "user_input": "Explain the answer briefly.",
            "provider": {
                "provider": "gemini",
                "model": "gemini-3-flash-preview",
                "default_chat_params": {"reasoning_effort": "low"},
            },
        },
    },
}

SEND_MESSAGE_OPENAPI_EXAMPLES = {
    "openrouter": {
        "summary": "Send a session message with OpenRouter",
        "value": {
            "user_input": "Help me with this request.",
            "provider": {
                "provider": "openrouter",
                "model": "openrouter/auto",
                "site_url": "https://your-app.example",
                "app_name": "Your App Name",
            },
        },
    },
    "gemini": {
        "summary": "Send a session message with Gemini OpenAI-compat",
        "value": {
            "user_input": "Help me with this request.",
            "provider": {
                "provider": "gemini",
                "model": "gemini-3-flash-preview",
                "default_chat_params": {"reasoning_effort": "low"},
            },
        },
    },
}

CREATE_SESSION_OPENAPI_EXAMPLE = {
    "summary": "Create a swarm session",
    "value": {
        "session_id": "session-1",
        "swarm": {
            "id": "single-agent",
            "name": "Single Agent",
            "nodes": [
                {
                    "node_key": "assistant",
                    "name": "Assistant",
                    "system_prompt": "You are a helpful assistant.",
                    "intent": "Handle the full request",
                    "capabilities": ["Answer questions"],
                    "is_entry_node": True,
                }
            ],
            "edges": [],
            "variables": [],
        },
        "global_variables": {},
    },
}


class ProviderConfigPayload(BaseModel):
    provider: str | None = None
    base_url: str | None = None
    api_key: str | None = None
    model: str | None = None
    temperature: float | None = None
    max_tokens: int | None = None
    site_url: str | None = None
    app_name: str | None = None
    default_headers: Dict[str, str] | None = None
    default_chat_params: Dict[str, Any] | None = None

    def to_model_config(self, base: ModelConfig | None = None) -> ModelConfig:
        base = base or ModelConfig()
        provider = self.provider or base.provider
        same_provider = provider == base.provider
        return ModelConfig(
            provider=provider,
            base_url=self.base_url if self.base_url is not None else (base.base_url if same_provider else None),
            api_key=self.api_key if self.api_key is not None else (base.api_key if same_provider else None),
            model=self.model or base.model,
            temperature=self.temperature if self.temperature is not None else base.temperature,
            max_tokens=self.max_tokens if self.max_tokens is not None else base.max_tokens,
            site_url=self.site_url,
            app_name=self.app_name,
            default_headers=self.default_headers if self.default_headers is not None else (base.default_headers if same_provider else None),
            default_chat_params=self.default_chat_params if self.default_chat_params is not None else (base.default_chat_params if same_provider else None),
        )


class SwarmVariablePayload(BaseModel):
    key_name: str
    description: str = ""
    reducer_rule: str = "overwrite"


class SwarmEdgePayload(BaseModel):
    source_node_key: str
    target_node_key: str
    handoff_description: str
    required_variables: List[str] = Field(default_factory=list)


class SwarmNodePayload(BaseModel):
    node_key: str
    name: str
    system_prompt: str = ""
    intent: str = ""
    capabilities: List[str] = Field(default_factory=list)
    persona: str = ""
    model_choice: str = ""
    enabled_tools: List[Dict[str, Any]] = Field(default_factory=list)
    behavior_config: Dict[str, Any] = Field(default_factory=dict)
    is_entry_node: bool = False


class SwarmDefinitionPayload(BaseModel):
    id: str = "swarm"
    name: str = "Swarm"
    graph_version: int = 1
    nodes: List[SwarmNodePayload]
    edges: List[SwarmEdgePayload] = Field(default_factory=list)
    variables: List[SwarmVariablePayload] = Field(default_factory=list)

    def to_runtime(self):
        return build_swarm_definition(
            {
                "nodes": [node.model_dump(mode="python") for node in self.nodes],
                "edges": [edge.model_dump(mode="python") for edge in self.edges],
                "variables": [variable.model_dump(mode="python") for variable in self.variables],
            },
            swarm_id=self.id,
            name=self.name,
            graph_version=self.graph_version,
        )


class CreateSessionRequest(BaseModel):
    session_id: str | None = None
    swarm: SwarmDefinitionPayload
    global_variables: Dict[str, Any] = Field(default_factory=dict)


class SendMessageRequest(BaseModel):
    user_input: str
    provider: ProviderConfigPayload | None = None
    global_variables: Dict[str, Any] = Field(default_factory=dict)
    global_variable_mode: str = "merge"


class RunSwarmRequest(BaseModel):
    session_id: str | None = None
    swarm: SwarmDefinitionPayload
    user_input: str
    global_variables: Dict[str, Any] = Field(default_factory=dict)
    provider: ProviderConfigPayload | None = None


class CreateConfiguredSessionRequest(BaseModel):
    session_id: str | None = None
    global_variables: Dict[str, Any] = Field(default_factory=dict)


class SessionVariableUpdateRequest(BaseModel):
    values: Dict[str, Any] = Field(default_factory=dict)
    mode: str = "merge"


def _node_runtime_payload(session: SwarmSession, node) -> Dict[str, Any]:
    context = session.agent_contexts.get(str(node.id))
    context_payload = context.to_dict() if context is not None else {}
    return {
        "id": node.id,
        "node_key": node.node_key,
        "name": node.name,
        "intent": node.intent,
        "capabilities": list(node.capabilities or []),
        "is_entry_node": node.is_entry_node,
        "history": copy.deepcopy((session.agent_histories or {}).get(str(node.id), [])),
        "scratchpad": copy.deepcopy((context_payload or {}).get("scratchpad") or {}),
        "context": context_payload,
    }


def _runtime_payload(session: SwarmSession, variable_manager: GlobalVariableManager) -> Dict[str, Any]:
    nodes = [_node_runtime_payload(session, node) for node in session.swarm.nodes]
    entry_node = session.swarm.entry_node()
    current_node = session.current_node
    return {
        "global_state": variable_manager.snapshot(session, current_node=current_node),
        "nodes": nodes,
        "entry_node": _node_runtime_payload(session, entry_node) if entry_node is not None else None,
        "current_node": _node_runtime_payload(session, current_node) if current_node is not None else None,
    }


def _runtime_response(session: SwarmSession, variable_manager: GlobalVariableManager) -> Dict[str, Any]:
    return {"runtime": _runtime_payload(session, variable_manager)}


def _session_payload(session: SwarmSession, variable_manager: GlobalVariableManager) -> Dict[str, Any]:
    del variable_manager
    return {
        "id": session.id,
        "swarm_id": session.swarm.id,
        "swarm_name": session.swarm.name,
        "graph_version": session.swarm.graph_version,
        "current_node_id": session.current_node_id,
        "current_node_key": session.current_node.node_key if session.current_node else None,
        "current_agent": session.current_node.name if session.current_node else None,
        "snapshot": session.snapshot(),
    }


def _sse_event(event: str, payload: Dict[str, Any]) -> str:
    return f"event: {event}\ndata: {json.dumps(payload, ensure_ascii=False)}\n\n"


def _build_fastapi_app(*, title: str, version: str, cors_allow_origins: List[str] | None) -> FastAPI:
    app = FastAPI(title=title, version=version)
    app.add_middleware(
        CORSMiddleware,
        allow_origins=cors_allow_origins or ["*"],
        allow_credentials=False,
        allow_methods=["*"],
        allow_headers=["*"],
    )
    return app


class OpenAICompatibleTurnRunner:
    def __init__(self, client: OpenAIClientWrapper) -> None:
        self.client = client

    async def run_turn(
        self,
        *,
        agent_node,
        contents,
        config: AgentTurnConfig,
    ) -> AgentTurnResult:
        del agent_node
        messages: List[Dict[str, Any]] = []
        if config.system_instruction:
            messages.append({"role": "system", "content": config.system_instruction})

        for item in contents:
            role = str(item.get("role") or "user").strip()
            if role == "model":
                role = "assistant"
            message: Dict[str, Any] = {"role": role, "content": item.get("content", "")}
            if role == "tool":
                if item.get("tool_call_id"):
                    message["tool_call_id"] = item.get("tool_call_id")
                if item.get("name"):
                    message["name"] = item.get("name")
            messages.append(message)

        response = self.client.chat_completion(messages=messages, tools=config.tools)
        assistant_message = response.choices[0].message
        tool_calls: List[Dict[str, Any]] = []
        if assistant_message.tool_calls:
            for tool_call in assistant_message.tool_calls:
                args = tool_call.function.arguments
                if not isinstance(args, dict):
                    args = json.loads(args or "{}")
                tool_calls.append(
                    {
                        "id": tool_call.id,
                        "name": tool_call.function.name,
                        "args": args,
                    }
                )
        return AgentTurnResult(
            response_text=assistant_message.content or "",
            tool_calls=tool_calls,
            raw_response=response,
        )


def build_openai_compatible_turn_runner(client: OpenAIClientWrapper) -> AgentTurnRunner:
    return OpenAICompatibleTurnRunner(client)


def _default_turn_runner_factory(model_config: ModelConfig) -> AgentTurnRunner:
    return build_openai_compatible_turn_runner(OpenAIClientWrapper(model_config))


class _FastApiSessionService:
    def __init__(
        self,
        *,
        store: SessionStore,
        default_model_config: ModelConfig | None = None,
        turn_runner_factory: Callable[[ModelConfig], AgentTurnRunner] | None = None,
        extract_required_variables: RequiredVariableExtractor | None = None,
        global_variable_manager_factory: Callable[[SwarmDefinition], GlobalVariableManager] | None = None,
        tool_registry: ToolRegistry | None = None,
        tool_state: Any = None,
    ) -> None:
        self.store = store
        self.default_model_config = default_model_config
        self.turn_runner_factory = turn_runner_factory or _default_turn_runner_factory
        self.extract_required_variables = extract_required_variables
        self.global_variable_manager_factory = global_variable_manager_factory or GlobalVariableManager.from_swarm
        self.tool_registry = tool_registry
        self.tool_state = tool_state

    def variable_manager_for(self, swarm: SwarmDefinition) -> GlobalVariableManager:
        return self.global_variable_manager_factory(swarm)

    def session_payload(self, session: SwarmSession) -> Dict[str, Any]:
        return _session_payload(session, self.variable_manager_for(session.swarm))

    def variable_payload(self, session: SwarmSession) -> Dict[str, Any]:
        return self.variable_manager_for(session.swarm).snapshot(session, current_node=session.current_node)

    def runtime_payload(self, session: SwarmSession) -> Dict[str, Any]:
        return _runtime_response(session, self.variable_manager_for(session.swarm))

    def initialize_session_variables(self, session: SwarmSession, values: Dict[str, Any] | None) -> None:
        self.variable_manager_for(session.swarm).apply_updates(session, values, current_node=session.current_node)

    def update_session_variables(self, session: SwarmSession, request: SessionVariableUpdateRequest) -> None:
        manager = self.variable_manager_for(session.swarm)
        mode = str(request.mode or "merge").strip().lower() or "merge"
        if mode == "replace":
            manager.replace_visible(session, request.values, current_node=session.current_node)
        else:
            manager.apply_updates(session, request.values, current_node=session.current_node)
        session.touch()

    def apply_turn_variables(self, session: SwarmSession, values: Dict[str, Any] | None, *, mode: str = "merge") -> None:
        request = SessionVariableUpdateRequest(values=dict(values or {}), mode=mode)
        self.update_session_variables(session, request)

    def resolve_model_config(self, provider: ProviderConfigPayload | None) -> ModelConfig:
        base_config = self.default_model_config
        return provider.to_model_config(base_config) if provider is not None else (base_config or ModelConfig())

    async def run_turn(
        self,
        session: SwarmSession,
        *,
        user_input: str,
        provider: ProviderConfigPayload | None,
    ) -> Dict[str, Any]:
        turn_runner = self.turn_runner_factory(self.resolve_model_config(provider))
        variable_manager = self.variable_manager_for(session.swarm)
        events: List[Dict[str, Any]] = []
        async for event in process_swarm_stream(
            session,
            user_input,
            store=self.store,
            turn_runner=turn_runner,
            extract_required_variables=self.extract_required_variables,
            global_variable_manager=variable_manager,
            tool_registry=self.tool_registry,
            tool_state=self.tool_state,
        ):
            events.append(event)
        checkpoints = await self.store.list_checkpoints(session.id)
        return {
            "events": events,
            "session": _session_payload(session, variable_manager),
            "checkpoints": serialize_checkpoints(checkpoints),
        }

    def stream_turn(
        self,
        session: SwarmSession,
        *,
        user_input: str,
        provider: ProviderConfigPayload | None,
    ) -> StreamingResponse:
        async def event_generator() -> AsyncGenerator[str, None]:
            try:
                turn_runner = self.turn_runner_factory(self.resolve_model_config(provider))
                variable_manager = self.variable_manager_for(session.swarm)
                async for event in process_swarm_stream(
                    session,
                    user_input,
                    store=self.store,
                    turn_runner=turn_runner,
                    extract_required_variables=self.extract_required_variables,
                    global_variable_manager=variable_manager,
                    tool_registry=self.tool_registry,
                    tool_state=self.tool_state,
                ):
                    yield _sse_event(event["event"], event["data"])
                checkpoints = await self.store.list_checkpoints(session.id)
                yield _sse_event("session", _session_payload(session, variable_manager))
                yield _sse_event("checkpoints", {"items": serialize_checkpoints(checkpoints)})
            except Exception as exc:
                yield _sse_event("error", {"message": str(exc)})

        return StreamingResponse(
            event_generator(),
            media_type="text/event-stream",
            headers={
                "Cache-Control": "no-cache",
                "Connection": "keep-alive",
                "X-Accel-Buffering": "no",
            },
        )


class _SwarmApiRuntime:
    def __init__(self, store: SessionStore) -> None:
        self.store = store

    async def create_session(self, *, swarm, session_id: str | None, global_variables: Dict[str, Any]) -> SwarmSession:
        resolved_session_id = session_id or uuid.uuid4().hex
        existing = await self.store.get_session(resolved_session_id)
        if existing is not None:
            raise ValueError(f"Session '{resolved_session_id}' already exists")
        session = SwarmSession(
            id=resolved_session_id,
            swarm=swarm,
            global_variables=dict(global_variables or {}),
        )
        await self.store.save_session(session)
        return session

    async def get_session(self, session_id: str) -> SwarmSession:
        session = await self.store.get_session(session_id)
        if session is None:
            raise KeyError(session_id)
        return session


def create_fastapi_app(
    *,
    default_model_config: ModelConfig | None = None,
    session_store: SessionStore | None = None,
    turn_runner_factory: Callable[[ModelConfig], AgentTurnRunner] | None = None,
    extract_required_variables: RequiredVariableExtractor | None = None,
    global_variable_manager_factory: Callable[[SwarmDefinition], GlobalVariableManager] | None = None,
    tool_registry: ToolRegistry | None = None,
    tool_state: Any = None,
    cors_allow_origins: List[str] | None = None,
) -> FastAPI:
    resolved_store = session_store or InMemorySessionStore()
    app = _build_fastapi_app(title="SwarmForge API", version="0.1.0", cors_allow_origins=cors_allow_origins)
    app.state.runtime = _SwarmApiRuntime(resolved_store)
    app.state.session_service = _FastApiSessionService(
        store=app.state.runtime.store,
        default_model_config=default_model_config,
        turn_runner_factory=turn_runner_factory,
        extract_required_variables=extract_required_variables,
        global_variable_manager_factory=global_variable_manager_factory,
        tool_registry=tool_registry,
        tool_state=tool_state,
    )

    @app.get("/")
    async def root() -> Dict[str, str]:
        return {
            "name": "SwarmForge API",
            "status": "ok",
            "docs": "/docs",
            "health": "/health",
        }

    @app.get("/favicon.ico")
    async def favicon() -> Response:
        return Response(status_code=204)

    @app.get("/health")
    async def health() -> Dict[str, str]:
        return {"status": "ok"}

    @app.post("/v1/sessions")
    async def create_session(
        request: CreateSessionRequest = Body(..., openapi_examples={"default": CREATE_SESSION_OPENAPI_EXAMPLE})
    ) -> Dict[str, Any]:
        swarm = request.swarm.to_runtime()
        try:
            session = await app.state.runtime.create_session(
                swarm=swarm,
                session_id=request.session_id,
                global_variables=request.global_variables,
            )
        except ValueError as exc:
            raise HTTPException(status_code=409, detail=str(exc)) from exc
        app.state.session_service.initialize_session_variables(session, request.global_variables)
        await app.state.runtime.store.save_session(session)
        return {"session": app.state.session_service.session_payload(session)}

    @app.get("/v1/sessions/{session_id}")
    async def get_session(session_id: str) -> Dict[str, Any]:
        try:
            session = await app.state.runtime.get_session(session_id)
        except KeyError as exc:
            raise HTTPException(status_code=404, detail="Session not found") from exc
        checkpoints = await app.state.runtime.store.list_checkpoints(session.id)
        return {
            "session": app.state.session_service.session_payload(session),
            "checkpoints": serialize_checkpoints(checkpoints),
        }

    @app.get("/v1/sessions/{session_id}/variables")
    async def get_session_variables(session_id: str) -> Dict[str, Any]:
        try:
            session = await app.state.runtime.get_session(session_id)
        except KeyError as exc:
            raise HTTPException(status_code=404, detail="Session not found") from exc
        return {"variables": app.state.session_service.variable_payload(session)}

    @app.get("/v1/sessions/{session_id}/runtime")
    async def get_session_runtime(session_id: str) -> Dict[str, Any]:
        try:
            session = await app.state.runtime.get_session(session_id)
        except KeyError as exc:
            raise HTTPException(status_code=404, detail="Session not found") from exc
        return app.state.session_service.runtime_payload(session)

    @app.patch("/v1/sessions/{session_id}/variables")
    async def update_session_variables(session_id: str, request: SessionVariableUpdateRequest) -> Dict[str, Any]:
        try:
            session = await app.state.runtime.get_session(session_id)
        except KeyError as exc:
            raise HTTPException(status_code=404, detail="Session not found") from exc
        app.state.session_service.update_session_variables(session, request)
        await app.state.runtime.store.save_session(session)
        return {
            "variables": app.state.session_service.variable_payload(session),
            "session": app.state.session_service.session_payload(session),
        }

    @app.post("/v1/sessions/{session_id}/messages")
    async def send_message(
        session_id: str,
        request: SendMessageRequest = Body(..., openapi_examples=SEND_MESSAGE_OPENAPI_EXAMPLES),
    ) -> Dict[str, Any]:
        try:
            session = await app.state.runtime.get_session(session_id)
        except KeyError as exc:
            raise HTTPException(status_code=404, detail="Session not found") from exc
        app.state.session_service.apply_turn_variables(
            session,
            request.global_variables,
            mode=request.global_variable_mode,
        )
        await app.state.runtime.store.save_session(session)
        return await app.state.session_service.run_turn(
            session,
            user_input=request.user_input,
            provider=request.provider,
        )

    @app.post("/v1/sessions/{session_id}/messages/stream")
    async def stream_message(
        session_id: str,
        request: SendMessageRequest = Body(..., openapi_examples=SEND_MESSAGE_OPENAPI_EXAMPLES),
    ):
        try:
            session = await app.state.runtime.get_session(session_id)
        except KeyError as exc:
            raise HTTPException(status_code=404, detail="Session not found") from exc
        app.state.session_service.apply_turn_variables(
            session,
            request.global_variables,
            mode=request.global_variable_mode,
        )
        await app.state.runtime.store.save_session(session)
        return app.state.session_service.stream_turn(
            session,
            user_input=request.user_input,
            provider=request.provider,
        )

    @app.post("/v1/swarm/run")
    async def run_swarm(
        request: RunSwarmRequest = Body(..., openapi_examples=RUN_SWARM_OPENAPI_EXAMPLES)
    ) -> Dict[str, Any]:
        swarm = request.swarm.to_runtime()
        try:
            session = await app.state.runtime.create_session(
                swarm=swarm,
                session_id=request.session_id,
                global_variables=request.global_variables,
            )
        except ValueError as exc:
            raise HTTPException(status_code=409, detail=str(exc)) from exc
        app.state.session_service.initialize_session_variables(session, request.global_variables)
        return await app.state.session_service.run_turn(
            session,
            user_input=request.user_input,
            provider=request.provider,
        )

    @app.post("/v1/swarm/run/stream")
    async def stream_swarm_run(
        request: RunSwarmRequest = Body(..., openapi_examples=RUN_SWARM_OPENAPI_EXAMPLES)
    ):
        swarm = request.swarm.to_runtime()
        try:
            session = await app.state.runtime.create_session(
                swarm=swarm,
                session_id=request.session_id,
                global_variables=request.global_variables,
            )
        except ValueError as exc:
            raise HTTPException(status_code=409, detail=str(exc)) from exc
        return app.state.session_service.stream_turn(
            session,
            user_input=request.user_input,
            provider=request.provider,
        )

    return app


def create_swarm_app(
    swarm: SwarmDefinition,
    *,
    default_model_config: ModelConfig | None = None,
    session_store: SessionStore | None = None,
    turn_runner_factory: Callable[[ModelConfig], AgentTurnRunner] | None = None,
    extract_required_variables: RequiredVariableExtractor | None = None,
    global_variable_manager: GlobalVariableManager | None = None,
    tool_registry: ToolRegistry | None = None,
    tool_state: Any = None,
    cors_allow_origins: List[str] | None = None,
    title: str = "Swarm API",
    version: str = "0.1.0",
) -> FastAPI:
    resolved_store = session_store or InMemorySessionStore()
    app = _build_fastapi_app(title=title, version=version, cors_allow_origins=cors_allow_origins)
    app.state.runtime = _SwarmApiRuntime(resolved_store)
    app.state.session_service = _FastApiSessionService(
        store=app.state.runtime.store,
        default_model_config=default_model_config,
        turn_runner_factory=turn_runner_factory,
        extract_required_variables=extract_required_variables,
        global_variable_manager_factory=(lambda _swarm: global_variable_manager or GlobalVariableManager.from_swarm(_swarm)),
        tool_registry=tool_registry,
        tool_state=tool_state,
    )
    app.state.swarm = swarm

    @app.get("/")
    async def root() -> Dict[str, str]:
        return {
            "name": title,
            "health": "/health",
            "swarm": "/swarm",
        }

    @app.get("/health")
    async def health() -> Dict[str, str]:
        return {"status": "ok"}

    @app.get("/swarm")
    async def get_swarm() -> Dict[str, Any]:
        return {"swarm": build_graph_snapshot(app.state.swarm)}

    @app.post("/sessions")
    async def create_session(request: CreateConfiguredSessionRequest) -> Dict[str, Any]:
        try:
            session = await app.state.runtime.create_session(
                swarm=app.state.swarm,
                session_id=request.session_id,
                global_variables=request.global_variables,
            )
        except ValueError as exc:
            raise HTTPException(status_code=409, detail=str(exc)) from exc
        app.state.session_service.initialize_session_variables(session, request.global_variables)
        await app.state.runtime.store.save_session(session)
        return {"session": app.state.session_service.session_payload(session)}

    @app.get("/sessions/{session_id}")
    async def get_session(session_id: str) -> Dict[str, Any]:
        try:
            session = await app.state.runtime.get_session(session_id)
        except KeyError as exc:
            raise HTTPException(status_code=404, detail="Session not found") from exc
        checkpoints = await app.state.runtime.store.list_checkpoints(session.id)
        return {
            "session": app.state.session_service.session_payload(session),
            "checkpoints": serialize_checkpoints(checkpoints),
        }

    @app.get("/sessions/{session_id}/variables")
    async def get_session_variables(session_id: str) -> Dict[str, Any]:
        try:
            session = await app.state.runtime.get_session(session_id)
        except KeyError as exc:
            raise HTTPException(status_code=404, detail="Session not found") from exc
        return {"variables": app.state.session_service.variable_payload(session)}

    @app.get("/sessions/{session_id}/runtime")
    async def get_session_runtime(session_id: str) -> Dict[str, Any]:
        try:
            session = await app.state.runtime.get_session(session_id)
        except KeyError as exc:
            raise HTTPException(status_code=404, detail="Session not found") from exc
        return app.state.session_service.runtime_payload(session)

    @app.patch("/sessions/{session_id}/variables")
    async def update_session_variables(session_id: str, request: SessionVariableUpdateRequest) -> Dict[str, Any]:
        try:
            session = await app.state.runtime.get_session(session_id)
        except KeyError as exc:
            raise HTTPException(status_code=404, detail="Session not found") from exc
        app.state.session_service.update_session_variables(session, request)
        await app.state.runtime.store.save_session(session)
        return {
            "variables": app.state.session_service.variable_payload(session),
            "session": app.state.session_service.session_payload(session),
        }

    @app.post("/sessions/{session_id}/messages")
    async def send_message(session_id: str, request: SendMessageRequest) -> Dict[str, Any]:
        try:
            session = await app.state.runtime.get_session(session_id)
        except KeyError as exc:
            raise HTTPException(status_code=404, detail="Session not found") from exc
        app.state.session_service.apply_turn_variables(
            session,
            request.global_variables,
            mode=request.global_variable_mode,
        )
        await app.state.runtime.store.save_session(session)
        return await app.state.session_service.run_turn(
            session,
            user_input=request.user_input,
            provider=request.provider,
        )

    @app.post("/sessions/{session_id}/messages/stream")
    async def stream_message(session_id: str, request: SendMessageRequest):
        try:
            session = await app.state.runtime.get_session(session_id)
        except KeyError as exc:
            raise HTTPException(status_code=404, detail="Session not found") from exc
        app.state.session_service.apply_turn_variables(
            session,
            request.global_variables,
            mode=request.global_variable_mode,
        )
        await app.state.runtime.store.save_session(session)
        return app.state.session_service.stream_turn(
            session,
            user_input=request.user_input,
            provider=request.provider,
        )

    return app
