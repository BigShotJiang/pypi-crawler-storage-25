from pathlib import Path

import pytest

from swarmforge.env import get_env_int, require_env_vars, reset_local_env_loader


def test_require_env_vars_loads_from_dotenv(monkeypatch, tmp_path):
    monkeypatch.chdir(tmp_path)
    monkeypatch.delenv("MODEL_PROVIDER", raising=False)
    monkeypatch.delenv("OPENROUTER_API_KEY", raising=False)
    (tmp_path / ".env").write_text(
        "MODEL_PROVIDER=openrouter\nOPENROUTER_API_KEY=sk-or-dotenv\n",
        encoding="utf-8",
    )
    reset_local_env_loader()

    assert require_env_vars("MODEL_PROVIDER", "OPENROUTER_API_KEY") == {
        "MODEL_PROVIDER": "openrouter",
        "OPENROUTER_API_KEY": "sk-or-dotenv",
    }

    reset_local_env_loader()


def test_require_env_vars_raises_with_setup_guidance(monkeypatch, tmp_path):
    monkeypatch.chdir(tmp_path)
    monkeypatch.delenv("MODEL_PROVIDER", raising=False)
    monkeypatch.delenv("OPENROUTER_API_KEY", raising=False)
    reset_local_env_loader()

    with pytest.raises(ValueError, match=r"Copy \.env\.example to \.env"):
        require_env_vars("MODEL_PROVIDER", "OPENROUTER_API_KEY")

    reset_local_env_loader()


def test_get_env_int_reads_from_dotenv(monkeypatch, tmp_path):
    monkeypatch.chdir(tmp_path)
    monkeypatch.delenv("SWARMFORGE_PORT", raising=False)
    (tmp_path / ".env").write_text("SWARMFORGE_PORT=9001\n", encoding="utf-8")
    reset_local_env_loader()

    assert get_env_int("SWARMFORGE_PORT", default=8000) == 9001

    reset_local_env_loader()


def test_env_example_lists_required_example_variables():
    env_example = Path(__file__).resolve().parents[1] / ".env.example"
    content = env_example.read_text(encoding="utf-8")

    for key in (
        "MODEL_PROVIDER",
        "LLM_MODEL",
        "OPENROUTER_API_KEY",
        "OPENROUTER_SITE_URL",
        "OPENROUTER_APP_NAME",
        "GEMINI_API_KEY",
        "SWARMFORGE_HOST",
        "SWARMFORGE_PORT",
    ):
        assert f"{key}=" in content