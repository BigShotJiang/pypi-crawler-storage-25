"""OrderProcessingEngine library for order processing and stock management"""
import boto3
import uuid
import os
from datetime import datetime
from decimal import Decimal
from enum import Enum
from boto3.dynamodb.conditions import Key

class OrderStatus(Enum):
    PENDING = "PENDING"
    COMPLETED = "COMPLETED"
    CANCELLED = "CANCELLED"

class OrderProcessingEngine:
    def _get_dynamodb(self):
        """Return dynamodb resource with latest credentials"""
        session = boto3.Session(
            aws_access_key_id = os.environ.get('AWS_ACCESS_KEY_ID'),
            aws_secret_access_key = os.environ.get('AWS_SECRET_ACCESS_KEY'),
            aws_session_token = os.environ.get('AWS_SESSION_TOKEN'),
            region_name = os.environ.get('AWS_REGION')
        )
        return session.resource('dynamodb', region_name=os.environ.get('AWS_REGION'))

    def __init__(self):
        """Initialize OrderProcessingEngine"""
        self.low_stock_threshold = int('10')

    def _get_tables(self):
        """Get table references"""
        dynamodb = self._get_dynamodb()
        return (
            dynamodb.Table(os.environ.get('DYNAMODB_ORDERS_TABLE')),
            dynamodb.Table(os.environ.get('DYNAMODB_ORDER_ITEMS_TABLE')),
            dynamodb.Table(os.environ.get('DYNAMODB_INVENTORY_TABLE'))
        )

    def create_order(self, order_items, s3_file_path='N/A'):
        """Create order from lambda CSV"""
        orders_table, order_items_table, inventory_table = self._get_tables()

        order_id = str(uuid.uuid4())
        order_number = f"ORD-{datetime.now().strftime('%Y%m%d%H%M%S')}"
        timestamp = datetime.now().isoformat()
        total_amount = sum(Decimal(str(item['quantity'])) * Decimal(str(item['price'])) for item in order_items)


        try:
            # Create order only s3_file_path is not exist in the table -> not to duplicate
            orders_table.put_item(Item = {
                'order_id': order_id,
                'order_number': order_number,
                'status': OrderStatus.PENDING.value,
                'total_amount': total_amount,
                's3_file_path': s3_file_path,
                'created_at': timestamp,
                'updated_at': timestamp
            }, ConditionExpression='attribute_not_exists(s3_file_path)')

        except Exception as e:
            if 'ConditionalCheckFailedException' in str(type(e).__name__):
                print(f"Duplicate order for {s3_file_path}")
                return None, None
            raise e

        for item in order_items:
            order_items_table.put_item(Item = {
                'order_id': order_id,
                'item_id': str(uuid.uuid4()),
                'sku': item['sku'],
                'product_name': item['product_name'],
                'quantity': item['quantity'],
                'price': Decimal(str(item['price'])),
                'created_at': timestamp
            })

        return order_id, order_number

    def check_stock(self, order_id):
        """Check if sufficient stock"""
        orders_table, order_items_table, inventory_table = self._get_tables()

        items = order_items_table.query(
            KeyConditionExpression=Key('order_id').eq(order_id)
        ).get('Items', [])

        insufficient_items = []
        for item in items:
            product = inventory_table.get_item(Key={'sku': item['sku']}).get('Item')
            if not product or product['quantity'] < item['quantity']:
                insufficient_items.append({
                    'sku': item['sku'],
                    'required': int(item['quantity']),
                    'available': int(product['quantity']) if product else 0
                })
        return len(insufficient_items) == 0, insufficient_items

    def confirm_order(self, order_id):
        """Order confirmation"""
        orders_table, order_items_table, inventory_table = self._get_tables()

        order = orders_table.get_item(Key={'order_id': order_id}).get('Item')

        if not order:
            return False, "Order not found"

        if not self.check_status_transitions(order['status'], OrderStatus.COMPLETED.value):
            return False, "Invalid status workflow"

        available, insufficient = self.check_stock(order_id)
        if not available:
            return False, insufficient

        items = order_items_table.query(
            KeyConditionExpression = Key('order_id').eq(order_id)
        ).get('Items', [])

        low_stock_items = []
        try:
            for item in items:
                updated = inventory_table.update_item(
                    Key = {'sku': item['sku']},
                    UpdateExpression = 'SET quantity = quantity - :qty, updated_at = :updated',
                    ExpressionAttributeValues = {
                        ':qty': item['quantity'],
                        ':updated': datetime.now().isoformat()
                    },
                    ReturnValues = 'ALL_NEW'
                ).get('Attributes')

                if updated['quantity'] < self.low_stock_threshold:
                    low_stock_items.append({'sku': item['sku'], 'remaining': int(updated['quantity']) })

        except Exception as e:
            return False, f"Stock reservation failed: {str(e)}"

        # Update order status
        orders_table.update_item(
            Key = {'order_id': order_id},
            UpdateExpression = 'SET #status = :status, updated_at = :updated',
            ExpressionAttributeNames = {'#status': 'status'},
            ExpressionAttributeValues = {
                ':status': OrderStatus.COMPLETED.value,
                ':updated': datetime.now().isoformat()
            }
        )

        return True, low_stock_items

    def modify_order(self, order_id, item_id, new_qty):
        """Modify order item"""
        orders_table, order_items_table, inventory_table = self._get_tables()
        order = orders_table.get_item(Key={'order_id': order_id}).get('Item')

        if not order or order['status'] != OrderStatus.PENDING.value:
            return False, "You can modify Pending order only!"

        order_items_table.update_item(
            Key = {'order_id': order_id, 'item_id': item_id},
            UpdateExpression = 'SET quantity = :qty',
            ExpressionAttributeValues = {':qty': new_qty}
        )

        # Calculate order total
        items = order_items_table.query(
            KeyConditionExpression = Key('order_id').eq(order_id)
        ).get('Items', [])
        total = sum(Decimal(str(item['quantity'])) * item['price'] for item in items)

        orders_table.update_item(
            Key = {'order_id': order_id},
            UpdateExpression = 'SET total_amount = :total, updated_at = :updated',
            ExpressionAttributeValues = {
                ':total': total,
                ':updated': datetime.now().isoformat()
            }
        )

        return True, 'Order updated'

    def order_cancel(self, order_id):
        """Cancel order"""
        orders_table, order_items_table, inventory_table = self._get_tables()
        order = orders_table.get_item(Key={'order_id': order_id}).get('Item')

        if not order:
            return False, "Order not found"

        # can cancel only pending order
        if not self.check_status_transitions(order['status'], OrderStatus.CANCELLED.value):
            return False, "You are not allowed to cancel this order"

        orders_table.update_item(
            Key = {'order_id': order_id},
            UpdateExpression = 'SET #status = :status, updated_at = :updated',
            ExpressionAttributeNames = {'#status': 'status'},
            ExpressionAttributeValues = {
                ':status': OrderStatus.CANCELLED.value,
                ':updated': datetime.now().isoformat()
            }
        )
        return True, 'Order cancelled'


    def check_status_transitions(self, current_status, new_status):
        """Status transition workflow"""
        allowed_status = {
            OrderStatus.PENDING.value: [OrderStatus.COMPLETED.value, OrderStatus.CANCELLED.value],
            OrderStatus.COMPLETED.value: [],
            OrderStatus.CANCELLED.value: []
        }

        return new_status in allowed_status.get(current_status, [])
