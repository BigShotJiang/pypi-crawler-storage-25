# Order Processing Engine

Python library for order processing and inventory management.

## Installation

```bash
pip install order-processing-engine
```

## Requirements

- `boto3`
- AWS credentials configured
- DynamoDB tables set up

## Environment Variables

AWS region, Orders table, Order items table, Inventory table, Low stock threshold


## Quick Start

```python
from order_processing_engine_pkg.order_processing import OrderProcessingEngine

order_engine = OrderProcessingEngine()
```

## Usage

### Lambda — Create PENDING Order from CSV

```python
order_id, order_number = order_engine.create_order(
    order_items=[
        {'sku': 'LAP-001', 'product_name': 'Laptop', 'quantity': 2, 'price': 930.20},
        {'sku': 'MOU-001', 'product_name': 'Mouse',  'quantity': 5, 'price': 25.67}
    ],
    s3_file_path='my-bucket/orders/order.csv'
)
```

### Staff Confirm Order

```python
success, result = order_engine.confirm_order(order_id)

if success:
    low_stock_items = result  # list of {'sku': xxx, 'remaining': xxx}
else:
    error_message = result
```

### Staff Modify Order Item

```python
success, message = order_engine.modify_order(order_id, item_id, new_quantity=4)
```

### Staff Cancel Order

```python
success, message = order_engine.order_cancel(order_id)
```

## Allowed Status Transitions

```
PENDING -> COMPLETED  (confirm order)
PENDING -> CANCELLED  (cancel order)
COMPLETED -> (cannot change after completed)
CANCELLED -> (cannot change after cancelled)
```

## License

MIT