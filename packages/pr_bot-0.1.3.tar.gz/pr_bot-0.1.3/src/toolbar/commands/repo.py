"""toolbar repo <subcommand> — create and wire up GitHub repos."""

from __future__ import annotations

import os
from pathlib import Path
from typing import Annotated

from cyclopts import App, Parameter

from pr_bot.sh import require, run
from toolbar.env import resolve

app = App(name="repo", help="Create and wire up GitHub repos.")


def _default_name() -> str:
    return Path.cwd().name


def _ensure_gh_credential_helper(host: str) -> None:
    """If gh's git credential helper isn't wired for <host>, run 'gh auth setup-git'.

    Without this, the git push inside 'gh repo create --push' has no
    credentials and the remote 404s. Idempotent.
    """
    r = run(
        ["git", "config", "--get-all", f"credential.https://{host}.helper"],
        check=False,
    )
    if r.ok and "gh auth git-credential" in r.stdout:
        return
    print(f"toolbar: wiring gh as git credential helper for {host}...")
    _gh_with_host(host, "auth", "setup-git", capture=True, echo=False)


def _gh_with_host(host: str, *args: str, capture: bool = False, echo: bool = True):
    require("gh")
    env = dict(os.environ)
    env["GH_HOST"] = host
    cmd = ["gh", *args]
    if echo:
        import sys

        print("$", " ".join(cmd), f"  (GH_HOST={host})", file=sys.stderr)
    import subprocess

    proc = subprocess.run(cmd, env=env, capture_output=capture, text=True, check=False)
    if proc.returncode != 0:
        msg = (proc.stderr or proc.stdout or "").strip() or f"command failed: {' '.join(cmd)}"
        raise SystemExit(f"toolbar: {msg}")
    return proc


@app.command
def info(
    name: Annotated[str | None, Parameter(help="repo name (default: current dir name)")] = None,
    org: Annotated[str | None, Parameter(help="GitHub org/user (default: $GH_ORG or andrewrothstein)")] = None,
    mirror: Annotated[str | None, Parameter(help="GitHub URL (default: $GH_MIRROR or https://github.com)")] = None,
) -> None:
    """Print the resolved target repo (org/name, URL, host) without creating it."""
    t = resolve(name=name or _default_name(), org=org, mirror=mirror)
    print(f"name   : {t.name}")
    print(f"org    : {t.org}")
    print(f"mirror : {t.mirror}")
    print(f"host   : {t.host}")
    print(f"slug   : {t.slug}")
    print(f"url    : {t.browser_url}")


@app.command
def create(
    name: Annotated[str | None, Parameter(help="repo name (default: current dir name)")] = None,
    org: Annotated[str | None, Parameter(help="GitHub org/user (default: $GH_ORG or andrewrothstein)")] = None,
    mirror: Annotated[str | None, Parameter(help="GitHub URL (default: $GH_MIRROR or https://github.com)")] = None,
    public: Annotated[bool, Parameter(help="create public repo (default: private)")] = False,
    description: Annotated[str | None, Parameter(help="repo description")] = None,
    source: Annotated[str, Parameter(help="local path to wire as the repo source")] = ".",
    push: Annotated[bool, Parameter(help="also push the current branch to origin")] = False,
    remote: Annotated[str, Parameter(help="remote name to add")] = "origin",
) -> None:
    """Create a private GitHub repo and (optionally) push.

    Shells out to 'gh repo create <org>/<name> --private --source=<path> --remote=<name>'.
    Defaults honor GH_MIRROR and GH_ORG env vars.
    """
    t = resolve(name=name or _default_name(), org=org, mirror=mirror)
    visibility = "--public" if public else "--private"

    if push:
        _ensure_gh_credential_helper(t.host)

    args = [
        "repo",
        "create",
        t.slug,
        visibility,
        f"--source={source}",
        f"--remote={remote}",
    ]
    if description:
        args += ["--description", description]
    if push:
        args.append("--push")

    _gh_with_host(t.host, *args)

    print(f"toolbar: created {t.browser_url} ({'public' if public else 'private'})")
    print(f"toolbar: remote '{remote}' set on {source}")
    if not push:
        print("toolbar: nothing pushed yet. to push main:")
        print(f"        git push -u {remote} main")


@app.command
def push_main(
    remote: Annotated[str, Parameter(help="remote name (default: origin)")] = "origin",
) -> None:
    """Push local main to origin (sanity-checks clean tree + on main)."""
    require("git")
    status = run(["git", "status", "--porcelain"]).stdout.strip()
    if status:
        raise SystemExit("toolbar: working tree not clean; commit or stash first")
    branch = run(["git", "rev-parse", "--abbrev-ref", "HEAD"]).stdout.strip()
    if branch not in ("main", "master"):
        raise SystemExit(f"toolbar: expected to be on main/master, got {branch}")
    run(["git", "push", "-u", remote, branch], capture=False, echo=True)
