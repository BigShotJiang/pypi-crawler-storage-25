"""Thin wrappers over the GitHub CLI."""

from __future__ import annotations

import json

from pr_bot.sh import Result, require, run


def _gh(*args: str, check: bool = True, capture: bool = True, echo: bool = False) -> Result:
    require("gh")
    return run(["gh", *args], check=check, capture=capture, echo=echo)


def current_pr() -> dict | None:
    """Return metadata for the PR attached to the current branch, or None."""
    r = _gh(
        "pr",
        "view",
        "--json",
        "number,state,isDraft,title,url,baseRefName,headRefName,mergeable,mergeStateStatus",
        check=False,
    )
    if not r.ok:
        return None
    try:
        return json.loads(r.stdout)
    except json.JSONDecodeError:
        return None


def create_pr(
    *,
    base: str,
    title: str | None = None,
    body: str | None = None,
    draft: bool = False,
    fill: bool = True,
    web: bool = False,
) -> None:
    args = ["pr", "create", "--base", base]
    if draft:
        args.append("--draft")
    if web:
        args.append("--web")
    if title:
        args += ["--title", title]
    if body:
        args += ["--body", body]
    elif fill:
        args.append("--fill")
    _gh(*args, capture=False, echo=True)


def mark_ready() -> None:
    _gh("pr", "ready", capture=False, echo=True)


def merge_pr(*, squash: bool = True, delete_branch: bool = True, auto: bool = False) -> None:
    args = ["pr", "merge"]
    if squash:
        args.append("--squash")
    if delete_branch:
        args.append("--delete-branch")
    if auto:
        args.append("--auto")
    _gh(*args, capture=False, echo=True)


def create_release(tag: str, *, title: str | None = None, notes: str | None = None,
                   draft: bool = False, target: str | None = None) -> None:
    args = ["release", "create", tag]
    if title:
        args += ["--title", title]
    if notes is not None:
        args += ["--notes", notes]
    else:
        args.append("--generate-notes")
    if draft:
        args.append("--draft")
    if target:
        args += ["--target", target]
    _gh(*args, capture=False, echo=True)
