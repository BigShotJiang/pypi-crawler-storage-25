"""pr-bot doctor — sanity-check the repo against the pr-bot branching model."""

from __future__ import annotations

from pr_bot import git
from pr_bot.names import parse_pr_branch, parse_release_branch, parse_version
from pr_bot.sh import run


def check() -> int:
    """Run checks; return non-zero exit code if any fail."""
    problems: list[str] = []
    warnings: list[str] = []

    try:
        main = git.main_branch()
    except SystemExit as e:
        print(str(e))
        return 2

    print(f"main branch: {main}")

    if git.has_remote():
        git.fetch()
        print("remote 'origin': present")
    else:
        warnings.append("no 'origin' remote configured")

    r = run(["git", "log", "--merges", "--format=%H %s", f"{main}"], check=False)
    if r.ok and r.stdout.strip():
        merge_lines = r.stdout.strip().splitlines()
        problems.append(
            f"{main} has {len(merge_lines)} merge commit(s) — expected linear history (squash merges only)"
        )

    for br in git.list_branches("*"):
        if br in (main, "master"):
            continue
        if parse_release_branch(br) is not None:
            continue
        pb = parse_pr_branch(br)
        if pb is None:
            warnings.append(f"branch {br!r} does not match any pr-bot pattern")

    for t in git.list_tags("*"):
        if parse_version(t) is None:
            warnings.append(f"tag {t!r} is not X.Y.Z semver")

    if warnings:
        print()
        print("warnings:")
        for w in warnings:
            print(f"  - {w}")

    if problems:
        print()
        print("problems:")
        for p in problems:
            print(f"  - {p}")
        return 1

    print()
    print("ok.")
    return 0
