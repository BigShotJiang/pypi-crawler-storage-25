"""pr-bot release <subcommand> — cut release branches and tag semver versions."""

from __future__ import annotations

import re
from typing import Annotated

from cyclopts import App, Parameter

from pr_bot import gh, git
from pr_bot.names import (
    ReleaseLine,
    Version,
    parse_release_branch,
    parse_version,
    require_release_branch,
)
from pr_bot.pyproject import find_pyproject
from pr_bot.pyproject import read_version as read_pyproject_version

app = App(name="release", help="Cut release/X.Y branches and tag X.Y.Z versions.")


SERIES_RE = re.compile(r"^(\d+)\.(\d+)$")


def _parse_series(series: str) -> ReleaseLine:
    m = SERIES_RE.match(series)
    if not m:
        raise SystemExit(f"pr-bot: expected X.Y (e.g. 1.4), got {series!r}")
    return ReleaseLine(int(m.group(1)), int(m.group(2)))


@app.command
def cut(
    series: Annotated[str, Parameter(help="X.Y, e.g. '1.4'")],
    from_ref: Annotated[str | None, Parameter(name="--from", help="commit to cut from (default: main)")] = None,
    push: Annotated[bool, Parameter(help="push the new branch to origin")] = True,
) -> None:
    """Create a new release/X.Y branch from main (or --from <ref>)."""
    rl = _parse_series(series)
    if git.has_uncommitted():
        raise SystemExit("pr-bot: uncommitted changes; commit or stash first")
    main = git.main_branch()
    start = from_ref or main
    if git.has_remote():
        git.fetch()
    if git.branch_exists_local(rl.branch) or (git.has_remote() and git.branch_exists_remote(rl.branch)):
        raise SystemExit(f"pr-bot: {rl.branch} already exists")
    if from_ref is None:
        git.checkout(main)
        if git.has_remote():
            git.pull_ff()
    git.checkout_new(rl.branch, start)
    if push and git.has_remote():
        git.push(rl.branch)
    print(f"pr-bot: cut {rl.branch} from {start}")


@app.command
def tag(
    version: Annotated[str, Parameter(help="X.Y.Z, e.g. '1.4.0'")],
    ref: Annotated[str | None, Parameter(help="commit to tag (default: HEAD of release branch)")] = None,
    notes: Annotated[str | None, Parameter(help="release notes body")] = None,
    gh_release: Annotated[bool, Parameter(name="--gh-release", help="also create a GitHub release")] = True,
    push: Annotated[bool, Parameter(help="push the tag to origin")] = True,
    skip_version_check: Annotated[bool, Parameter(help="bypass pyproject.toml match (not recommended)")] = False,
) -> None:
    """Tag X.Y.Z on the matching release/X.Y branch.

    Refuses to tag unless pyproject.toml's [project].version matches X.Y.Z —
    prevents the drift where the git tag says 0.1.1 but the built wheel is
    labeled 0.1.0.
    """
    v = parse_version(version)
    if v is None:
        raise SystemExit(f"pr-bot: expected X.Y.Z, got {version!r}")
    rl = v.release_line

    br = git.current_branch()
    on_release = parse_release_branch(br)

    if on_release is None or on_release != rl:
        if not git.branch_exists_local(rl.branch):
            if git.has_remote() and git.branch_exists_remote(rl.branch):
                git.checkout(rl.branch)
            else:
                raise SystemExit(f"pr-bot: {rl.branch} does not exist; run 'pr-bot release cut {rl.series}' first")
        else:
            git.checkout(rl.branch)

    if git.has_remote():
        git.fetch()
        git.pull_ff()

    pyproject_version = read_pyproject_version(find_pyproject())
    if pyproject_version is not None and pyproject_version != str(v):
        if skip_version_check:
            print(
                f"pr-bot: WARNING pyproject.toml version {pyproject_version!r} != tag {v} "
                f"(--skip-version-check set)"
            )
        else:
            raise SystemExit(
                f"pr-bot: pyproject.toml [project].version is {pyproject_version!r}, but you're "
                f"tagging {v}. bump pyproject.toml on this branch first:\n"
                f'  sed -i \'s/^version = .*/version = "{v}"/\' pyproject.toml\n'
                f"  git commit -am 'chore: bump to {v}'\n"
                f"  git push\n"
                f"then re-run 'pr-bot release tag {v}'.\n"
                f"(use --skip-version-check to bypass — not recommended)"
            )

    if git.tag_exists(str(v)):
        raise SystemExit(f"pr-bot: tag {v} already exists")

    git.tag(str(v), ref or "HEAD", message=f"Release {v}")
    if push and git.has_remote():
        git.push_tag(str(v))
    print(f"pr-bot: tagged {v} on {rl.branch}")

    if gh_release and git.has_remote():
        gh.create_release(str(v), title=f"v{v}", notes=notes, target=rl.branch)


@app.command(name="list")
def list_() -> None:
    """List release branches and their highest tag."""
    if git.has_remote():
        git.fetch()
    local = {b for b in git.list_branches("release/*")}
    remote = set(git.list_remote_branches("release/*")) if git.has_remote() else set()
    branches = sorted(local | remote)
    if not branches:
        print("pr-bot: no release branches found")
        return

    for br in branches:
        rl = parse_release_branch(br)
        if rl is None:
            continue
        versions = []
        for t in git.list_tags(f"{rl.major}.{rl.minor}.*"):
            v = parse_version(t)
            if v is not None:
                versions.append(v)
        latest = max(versions, key=lambda v: (v.major, v.minor, v.patch)) if versions else None
        flags = []
        if br in local:
            flags.append("local")
        if br in remote:
            flags.append("remote")
        suffix = f"latest tag {latest}" if latest else "no tags yet"
        print(f"  {br:<20}  {suffix:<24}  ({', '.join(flags)})")


@app.command
def next_patch(
    series: Annotated[str | None, Parameter(help="X.Y (default: current release branch)")] = None,
) -> None:
    """Print the next unused patch version for release/X.Y."""
    rl = require_release_branch(git.current_branch()) if series is None else _parse_series(series)
    versions = [v for v in (parse_version(t) for t in git.list_tags(f"{rl.major}.{rl.minor}.*")) if v is not None]
    if not versions:
        nxt = Version(rl.major, rl.minor, 0)
    else:
        highest = max(versions, key=lambda v: v.patch)
        nxt = Version(rl.major, rl.minor, highest.patch + 1)
    print(nxt)
