# Project Instructions for AI Agents

This file provides instructions and context for AI coding agents working on this project.

<!-- BEGIN BEADS INTEGRATION v:1 profile:minimal hash:ca08a54f -->
## Beads Issue Tracker

This project uses **bd (beads)** for issue tracking. Run `bd prime` to see full workflow context and commands.

### Quick Reference

```bash
bd ready              # Find available work
bd show <id>          # View issue details
bd update <id> --claim  # Claim work
bd close <id>         # Complete work
```

### Rules

- Use `bd` for ALL task tracking — do NOT use TodoWrite, TaskCreate, or markdown TODO lists
- Run `bd prime` for detailed command reference and session close protocol
- Use `bd remember` for persistent knowledge — do NOT use MEMORY.md files

## Session Completion

**When ending a work session**, you MUST complete ALL steps below. Work is NOT complete until `git push` succeeds.

**MANDATORY WORKFLOW:**

1. **File issues for remaining work** - Create issues for anything that needs follow-up
2. **Run quality gates** (if code changed) - Tests, linters, builds
3. **Update issue status** - Close finished work, update in-progress items
4. **PUSH TO REMOTE** - This is MANDATORY:
   ```bash
   git pull --rebase
   bd dolt push
   git push
   git status  # MUST show "up to date with origin"
   ```
5. **Clean up** - Clear stashes, prune remote branches
6. **Verify** - All changes committed AND pushed
7. **Hand off** - Provide context for next session

**CRITICAL RULES:**
- Work is NOT complete until `git push` succeeds
- NEVER stop before pushing - that leaves work stranded locally
- NEVER say "ready to push when you are" - YOU must push
- If push fails, resolve and retry until it succeeds
<!-- END BEADS INTEGRATION -->


## Build & Test

```bash
uv sync                          # install deps + editable package
uv run pr-bot --help             # smoke test the pr-bot CLI
uv run toolbar --help            # smoke test the toolbar CLI
uv run pytest -q                 # run unit tests (must pass before merge)
uv run ruff check src tests      # lint (must pass before merge)
```

Before opening a PR: both `pytest` and `ruff check` must pass. There is no
CI yet — these are the only gates.

## Architecture Overview

Two CLIs ship from the same wheel:

- **pr-bot** (`src/pr_bot/`) — operates *inside* a repo that follows the
  `main + release/X.Y + {feat,fix,hotfix}/<slug>` model. Command groups:
  `pr`, `release`, `hotfix`, plus `doctor`.
- **toolbar** (`src/toolbar/`) — operates *around* a repo: `gh repo create`,
  wiring the remote, pushing. Currently one group: `repo`.

Shared primitives live in `src/pr_bot/`:

| module            | purpose                                                         |
| ----------------- | --------------------------------------------------------------- |
| `pr_bot.sh`       | `subprocess.run` wrapper with uniform `pr-bot:` / `toolbar:` error surfacing |
| `pr_bot.git`      | git wrappers — every imperative git op the CLI needs            |
| `pr_bot.gh`       | gh CLI wrappers (`pr view/create/merge`, `release create`)      |
| `pr_bot.names`    | branch/tag/slug parsers + validators (pure, heavily unit-tested)|
| `toolbar.env`     | resolves `GH_MIRROR` / `GH_ORG` / `GH_HOST` into a target repo  |

Command groups are plain Python modules that register a `cyclopts.App` and
get mounted under the top-level app in `cli.py`.

Slash commands in `.claude/commands/*.md` are thin — each one invokes the
CLI via `uvx --from "${PR_BOT_SOURCE:-pr-bot}" pr-bot <group> <subcommand>
$ARGUMENTS`. That means the CLI is the only source of truth; changing a
subcommand's behavior never requires editing its slash command twin.

## Conventions & Patterns

- **Error prefixes.** Every user-visible error raised by pr-bot starts with
  `pr-bot:`; toolbar uses `toolbar:`. Callers (including agents) can regex
  for these.
- **No subprocess escapes.** Don't call `subprocess.run` directly — use
  `pr_bot.sh.run` so errors land in a uniform shape.
- **Every destructive op is echoed.** `pr_bot.git` functions pass `echo=True`
  on any write (checkout, push, tag, rebase) so the user sees what ran.
- **Cyclopts parameters.** Use `Annotated[T, Parameter(help="...")]` for
  every subcommand argument; defaults go on the right with `= None`.
- **Validation, not transformation.** `pr_bot.names` parses and validates;
  it does not reach out to git to check if a branch exists.
- **Tests cover the pure layer.** 25 tests in `tests/` cover `names.py` and
  `toolbar.env`. The git/gh-calling layer is integration-tested manually
  for now.
- **Line length 120.** Configured in `pyproject.toml`; `ruff` enforces.
- **Python 3.14 floor.** `requires-python = ">=3.14"` — we're not backporting.

## PR Lifecycle (dogfood)

This repo follows its own model. For every change except the initial scaffold:

```bash
pr-bot pr start feat <slug>      # start the branch
# ...edit, commit...
pr-bot pr open --draft           # push + open PR
pr-bot pr sync                   # keep up with main
pr-bot pr ready
pr-bot pr merge                  # squash, delete branch, FF main
```

If a change is small enough to be one commit, that's fine — `pr merge`
squashes into one commit on main regardless.
