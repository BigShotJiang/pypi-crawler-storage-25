"""
Webhook and MCP tool registry and executors for TeLLMgramBot.

Provides build_tool_registry() for startup parsing of config.yaml 'tools:' webhook
entries, discover_mcp_tools() for async MCP server discovery, execute_webhook() for
dispatching webhook tool calls, and execute_mcp() for MCP tool calls at runtime.
"""
import ipaddress
import logging
import os
import re
import socket
from urllib.parse import quote, urlparse, urlunparse

import httpx

logger = logging.getLogger(__name__)

_RESPONSE_LOG_LIMIT = 200
_RESPONSE_BODY_LIMIT = 4000
_ENV_VAR_PATTERN = re.compile(r'\$([A-Z_][A-Z0-9_]*)')
_PLACEHOLDER_PATTERN = re.compile(r'\{(\w+)\}')


def _safe_log_url(url: str) -> str:
    """Return the URL with userinfo (user:pass@) stripped for safe logging."""
    p = urlparse(url)
    netloc = p.hostname or ''
    if p.port:
        netloc += f':{p.port}'
    return urlunparse(p._replace(netloc=netloc))


def _expand_env_vars(value: str) -> tuple:
    """
    Expand $UPPER_CASE_VAR references in a header value string.

    Returns a two-tuple (expanded_value, first_missing_var_or_None). If any
    referenced variable is not set, the first missing name is returned so the
    caller can disable the tool rather than continue with an incomplete header.
    """
    missing = None

    def _sub(m):
        nonlocal missing
        var = m.group(1)
        val = os.environ.get(var)
        if val is None and missing is None:
            missing = var
        return val or ''

    return _ENV_VAR_PATTERN.sub(_sub, value), missing


def _is_blocked_address(hostname: str) -> bool:
    """
    Return True if the hostname is, or resolves to, a loopback or link-local address.

    Raw IP literals are checked without DNS. Hostnames are resolved via
    socket.getaddrinfo; resolution failures are treated as not-blocked to avoid
    incorrectly disabling tools when DNS is temporarily unavailable.

    Only loopback (127.x.x.x, ::1) and link-local (169.254.x.x, fe80::/10) are
    blocked. Private LAN addresses (192.168.x.x, 10.x.x.x, etc.) are permitted.
    """
    try:
        addr = ipaddress.ip_address(hostname)
        return addr.is_loopback or addr.is_link_local
    except ValueError:
        pass
    try:
        for _, _, _, _, sockaddr in socket.getaddrinfo(hostname, None):
            try:
                addr = ipaddress.ip_address(sockaddr[0])
                if addr.is_loopback or addr.is_link_local:
                    return True
            except ValueError:
                continue
    except OSError:
        pass
    return False


def build_tool_registry(
    tools_config: list,
    allow_local: bool = False,
) -> tuple:
    """
    Parse raw tool config entries and build the webhook tool registry.

    Validates all required fields ('name', 'description', 'webhook') and skips
    entries missing any required field. Expands $ENV_VAR references in header
    values at startup; tools whose header values reference missing environment
    variables are excluded with a logged warning (graceful-degradation pattern).
    Non-dict entries, non-dict headers values, and non-dict parameter definitions
    are skipped with warnings. Duplicate tool names are deduplicated (first wins).

    Args:
        tools_config: List of raw tool definition dicts from config.yaml 'tools:' key.
                      Pass an empty list or None to produce an empty registry.
        allow_local: If True, the executor permits webhook URLs targeting loopback or
                     link-local addresses. Mirrors the 'allow_local_webhooks' config key.

    Returns:
        Tuple of (schemas, defs) where:
        - schemas: list of provider-compatible tool schema dicts (same shape as _SEARCH_TOOL).
        - defs: dict mapping tool name -> resolved definition dict with expanded headers.
    """
    schemas = []
    defs = {}

    for entry in (tools_config or []):
        if not isinstance(entry, dict):
            logger.warning("Webhook tool entry is not a dict; skipping.")
            continue
        if 'mcp_server' in entry:
            continue  # MCP entries are handled by discover_mcp_tools() at startup
        name = entry.get('name')
        if not name:
            logger.warning("Webhook tool entry missing 'name'; skipping.")
            continue

        # Expand $ENV_VAR references in header values; disable tool on first missing var
        raw_headers = entry.get('headers') or {}
        if not isinstance(raw_headers, dict):
            logger.warning(f"Webhook tool '{name}': 'headers' must be a dict; treating as empty.")
            raw_headers = {}
        expanded_headers = {}
        disabled = False
        for header_name, header_value in raw_headers.items():
            expanded, missing = _expand_env_vars(str(header_value))
            if missing:
                logger.warning(
                    f"Webhook tool '{name}': header '{header_name}' references "
                    f"missing env var ${missing}; tool disabled."
                )
                disabled = True
                break
            expanded_headers[header_name] = expanded
        if disabled:
            continue

        # Validate required fields
        webhook_url = entry.get('webhook', '')
        if not webhook_url:
            logger.warning(f"Webhook tool '{name}': missing 'webhook' URL; skipping.")
            continue
        description = entry.get('description', '')
        if not description:
            logger.warning(f"Webhook tool '{name}': missing 'description'; skipping.")
            continue

        # Duplicate name check - warn and skip to keep schemas/defs in sync
        if name in defs:
            logger.warning(f"Webhook tool '{name}': duplicate name; skipping.")
            continue

        # Build the provider-compatible schema from the parameters block
        raw_params = entry.get('parameters') or {}
        properties = {}
        required = []
        if isinstance(raw_params, dict):
            for param_name, param_def in raw_params.items():
                if not isinstance(param_def, dict):
                    logger.warning(
                        f"Webhook tool '{name}': parameter '{param_name}' definition "
                        f"is not a dict; skipping parameter."
                    )
                    continue
                prop = {'type': param_def.get('type', 'string')}
                if 'description' in param_def:
                    prop['description'] = param_def['description']
                properties[param_name] = prop
                if param_def.get('required', False):
                    required.append(param_name)

        schemas.append({
            'name': name,
            'description': description,
            'parameters': {
                'type': 'object',
                'properties': properties,
                'required': required,
            },
        })
        defs[name] = {
            'name': name,
            'webhook': webhook_url,
            'method': str(entry.get('method', 'POST')).upper(),
            'headers': expanded_headers,
            'normalize_args': entry.get('normalize_args'),
            'allow_local': allow_local,
        }

    return schemas, defs


async def discover_mcp_tools(
    mcp_entries: list,
    existing_names: set,
    allow_local: bool = False,
) -> tuple:
    """
    Discover tools from MCP server(s) and return them ready to merge into the registry.

    For each entry with an 'mcp_server:' key, calls POST /tools/list to fetch the
    server's tool list, translates MCP inputSchema to provider-compatible parameters,
    and returns (schemas, defs) for the discovered tools.

    Headers support $ENV_VAR expansion. Missing env vars disable the MCP source with a
    warning. Discovery failures (non-2xx, timeout, network error) log a warning and
    continue -- graceful degradation, matching the pattern for missing env vars in webhooks.

    An 'include:' list on an entry restricts which discovered tools are registered; omitting
    it registers all tools. Name collisions with existing_names (or with each other across
    MCP sources) are skipped with a warning; first-registered wins.

    SSRF guard applies to the tools/list call: loopback and link-local addresses are blocked
    unless allow_local is True.

    Args:
        mcp_entries: List of MCP entry dicts (each has 'mcp_server' key).
        existing_names: Set of already-registered tool names to check collisions against
                        (should include webhook tool names and 'search_messages').
        allow_local: If True, permits MCP server URLs targeting loopback or link-local addresses.

    Returns:
        Tuple of (schemas, defs) for newly discovered MCP tools.
    """
    schemas = []
    defs = {}
    all_registered = set(existing_names)

    for entry in (mcp_entries or []):
        if not isinstance(entry, dict):
            continue
        server_url = entry.get('mcp_server', '').rstrip('/')
        if not server_url:
            logger.warning("MCP entry missing 'mcp_server' URL; skipping.")
            continue

        parsed = urlparse(server_url)
        log_url = _safe_log_url(server_url)
        if parsed.scheme not in ('http', 'https') or not parsed.hostname:
            logger.warning(f"MCP server '{log_url}': invalid URL scheme; skipping.")
            continue
        if parsed.query or parsed.fragment:
            logger.warning(
                f"MCP server '{log_url}': URL must not contain a query string or fragment; skipping."
            )
            continue
        if not allow_local and _is_blocked_address(parsed.hostname):
            logger.warning(
                f"MCP server '{log_url}': SSRF block - loopback or link-local address "
                f"not permitted; set allow_local_webhooks: true to allow."
            )
            continue

        raw_headers = entry.get('headers') or {}
        if not isinstance(raw_headers, dict):
            logger.warning(f"MCP server '{server_url}': 'headers' must be a dict; treating as empty.")
            raw_headers = {}
        expanded_headers = {}
        disabled = False
        for header_name, header_value in raw_headers.items():
            expanded, missing = _expand_env_vars(str(header_value))
            if missing:
                logger.warning(
                    f"MCP server '{log_url}': header '{header_name}' references "
                    f"missing env var ${missing}; source disabled."
                )
                disabled = True
                break
            expanded_headers[header_name] = expanded
        if disabled:
            continue

        include_set = None
        if 'include' in entry:
            include_filter = entry.get('include')
            if not isinstance(include_filter, list) or not all(
                isinstance(tool_name, str) for tool_name in include_filter
            ):
                logger.warning(
                    f"MCP server '{log_url}': 'include' must be a list of strings; source disabled."
                )
                continue
            include_set = set(include_filter)

        list_url = f"{server_url}/tools/list"
        try:
            async with httpx.AsyncClient(timeout=15.0) as client:
                resp = await client.post(list_url, headers=expanded_headers)
            if not (200 <= resp.status_code < 300):
                logger.warning(
                    f"MCP server '{log_url}': tools/list returned HTTP {resp.status_code}; skipping source."
                )
                continue
            tools_data = resp.json().get('tools', [])
        except httpx.TimeoutException:
            logger.warning(f"MCP server '{log_url}': tools/list timed out; skipping source.")
            continue
        except httpx.RequestError as e:
            logger.warning(f"MCP server '{log_url}': tools/list failed ({type(e).__name__}); skipping source.")
            continue
        except Exception as e:
            logger.warning(f"MCP server '{log_url}': tools/list error ({type(e).__name__}); skipping source.")
            continue

        server_count = 0
        for tool in tools_data:
            if not isinstance(tool, dict):
                continue
            tool_name = tool.get('name')
            if not tool_name:
                logger.warning(f"MCP server '{log_url}': tool entry missing 'name'; skipping.")
                continue
            if include_set is not None and tool_name not in include_set:
                continue
            if tool_name in all_registered:
                logger.warning(
                    f"MCP server '{log_url}': tool '{tool_name}' collides with existing "
                    f"registration; skipping."
                )
                continue

            input_schema = tool.get('inputSchema')
            if isinstance(input_schema, dict):
                parameters = input_schema
            else:
                if input_schema is not None:
                    logger.warning(
                        f"MCP tool '{tool_name}': 'inputSchema' is malformed; "
                        f"registering with empty parameters."
                    )
                parameters = {'type': 'object', 'properties': {}, 'required': []}

            schemas.append({
                'name': tool_name,
                'description': tool.get('description', ''),
                'parameters': parameters,
            })
            defs[tool_name] = {
                'name': tool_name,
                '_mcp_server': server_url,
                'headers': expanded_headers,
                'allow_local': allow_local,
            }
            all_registered.add(tool_name)
            server_count += 1

        logger.info(f"MCP server '{server_url}': registered {server_count} tool(s).")

    return schemas, defs


async def execute_mcp(tool_def: dict, arguments: dict) -> str:
    """
    Execute an MCP tool call and return a framed result string for LLM injection.

    Posts to {mcp_server}/tools/call with the tool name and arguments dict, parses
    the MCP content array from the response, and frames the result for LLM injection.

    Applies the same SSRF guard as execute_webhook(). Request headers are never
    logged at any level. Response bodies are logged at DEBUG only, truncated to 200
    characters. LLM-facing response is truncated to 4000 characters.

    Args:
        tool_def: Resolved MCP tool definition dict (contains '_mcp_server', 'headers',
                  'allow_local' keys set by discover_mcp_tools).
        arguments: Arguments dict from the LLM ToolCall.

    Returns:
        '[Tool result from <name>]:\\n<body>' on success (2xx), or a descriptive
        '[Tool error: ...]' string on failure (non-2xx, timeout, network error,
        SSRF block). Never raises.
    """
    name = tool_def['name']
    server_url = tool_def['_mcp_server']
    headers = tool_def['headers']
    allow_local = tool_def.get('allow_local', False)

    parsed = urlparse(server_url)
    if parsed.scheme not in ('http', 'https') or not parsed.hostname:
        return f"[Tool error: '{name}' MCP server has an invalid or unsupported URL]"
    if not allow_local and _is_blocked_address(parsed.hostname):
        logger.warning(f"MCP '{name}': SSRF block - '{parsed.hostname}' is loopback or link-local")
        return (
            f"[Tool error: '{name}' targets a loopback or link-local address. "
            f"Set allow_local_webhooks: true in config.yaml to permit local addresses.]"
        )

    call_url = f"{server_url}/tools/call"
    log_url = _safe_log_url(call_url)
    logger.info(f"MCP '{name}': POST {log_url}")

    try:
        async with httpx.AsyncClient(timeout=15.0) as client:
            resp = await client.post(
                call_url,
                json={"name": name, "arguments": arguments},
                headers=headers,
            )

        if not (200 <= resp.status_code < 300):
            logger.warning(f"MCP '{name}': status {resp.status_code}")
            return f"[Tool error: '{name}' returned HTTP {resp.status_code}]"

        logger.info(f"MCP '{name}': status {resp.status_code}")
        logger.debug(f"MCP '{name}' response: {resp.text[:_RESPONSE_LOG_LIMIT]}")

        try:
            data = resp.json()
            content_items = data.get('content', [])
            body = '\n'.join(
                item.get('text', '') for item in content_items
                if isinstance(item, dict) and item.get('type') == 'text'
            )
            if not body:
                body = resp.text
        except Exception:
            body = resp.text

        if len(body) > _RESPONSE_BODY_LIMIT:
            body = body[:_RESPONSE_BODY_LIMIT] + f"\n[Response truncated at {_RESPONSE_BODY_LIMIT} characters]"
        return f"[Tool result from {name}]:\n{body}"

    except httpx.TimeoutException:
        logger.warning(f"MCP '{name}': request timed out")
        return f"[Tool error: '{name}' timed out]"
    except httpx.RequestError as e:
        logger.warning(f"MCP '{name}': {type(e).__name__}")
        return f"[Tool error: '{name}' request failed ({type(e).__name__})]"


async def execute_webhook(tool_def: dict, arguments: dict) -> str:
    """
    Execute a webhook tool call and return a framed result string for LLM injection.

    Applies argument normalization, URL template substitution ({param} -> value),
    and SSRF protection before firing the HTTP request. The response body is wrapped
    with a '[Tool result from <name>]:' framing line so the LLM can distinguish
    tool output from user instructions (prompt injection guard).

    Request headers are never logged at any level. Response bodies are logged at
    DEBUG only, truncated to 200 characters. Only tool name, HTTP method, base URL
    (no query string), and status code are logged at INFO. The response body sent
    to the LLM is truncated to 4000 characters to prevent overwhelming the context.

    Args:
        tool_def: Resolved tool definition dict from build_tool_registry defs.
        arguments: Arguments dict from the LLM ToolCall.

    Returns:
        '[Tool result from <name>]:\n<body>' on success (2xx), or a descriptive
        '[Tool error: ...]' string on failure (non-2xx, timeout, network error,
        missing placeholder, SSRF block). Never raises.
    """
    name = tool_def['name']
    url_template = tool_def['webhook']
    method = tool_def['method']
    headers = tool_def['headers']
    normalize = tool_def.get('normalize_args')
    allow_local = tool_def.get('allow_local', False)

    args = dict(arguments)

    # Normalize string arguments if requested (e.g. for case-sensitive resource IDs)
    if normalize == 'lowercase':
        args = {k: v.lower() if isinstance(v, str) else v for k, v in args.items()}

    # Substitute {param} placeholders; remove them so they are not also sent in body/query
    url = url_template
    substituted = set()
    for placeholder in _PLACEHOLDER_PATTERN.findall(url_template):
        if placeholder not in args:
            return f"[Tool error: required URL parameter '{placeholder}' was not provided]"
        url = url.replace(f'{{{placeholder}}}', quote(str(args[placeholder]), safe=''))
        substituted.add(placeholder)
    for p in substituted:
        args.pop(p, None)

    # SSRF protection: block loopback and link-local unless explicitly allowed
    parsed = urlparse(url)
    if parsed.scheme not in ('http', 'https') or not parsed.hostname:
        return f"[Tool error: '{name}' has an invalid or unsupported webhook URL]"
    hostname = parsed.hostname
    if not allow_local and _is_blocked_address(hostname):
        logger.warning(f"Webhook '{name}': SSRF block - '{hostname}' is loopback or link-local")
        return (
            f"[Tool error: '{name}' targets a loopback or link-local address. "
            f"Set allow_local_webhooks: true in config.yaml to permit local addresses.]"
        )

    host_part = f"{parsed.hostname}:{parsed.port}" if parsed.port else parsed.hostname
    base_url = f"{parsed.scheme}://{host_part}{parsed.path}"
    logger.info(f"Webhook '{name}': {method} {base_url}")

    try:
        async with httpx.AsyncClient(timeout=15.0) as client:
            if method == 'GET':
                resp = await client.get(url, params=args if args else None, headers=headers)
            else:
                resp = await client.request(method, url, json=args if args else None, headers=headers)

        if not (200 <= resp.status_code < 300):
            logger.warning(f"Webhook '{name}': status {resp.status_code}")
            return f"[Tool error: '{name}' returned HTTP {resp.status_code}]"

        logger.info(f"Webhook '{name}': status {resp.status_code}")
        logger.debug(f"Webhook '{name}' response: {resp.text[:_RESPONSE_LOG_LIMIT]}")

        body = resp.text
        if len(body) > _RESPONSE_BODY_LIMIT:
            body = body[:_RESPONSE_BODY_LIMIT] + f"\n[Response truncated at {_RESPONSE_BODY_LIMIT} characters]"
        return f"[Tool result from {name}]:\n{body}"

    except httpx.TimeoutException:
        logger.warning(f"Webhook '{name}': request timed out")
        return f"[Tool error: '{name}' timed out]"
    except httpx.RequestError as e:
        logger.warning(f"Webhook '{name}': {type(e).__name__}")
        return f"[Tool error: '{name}' request failed ({type(e).__name__})]"
