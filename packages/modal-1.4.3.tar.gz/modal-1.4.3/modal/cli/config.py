# Copyright Modal Labs 2022
import json

import click

from modal.config import _profile, _store_user_config, config
from modal.environments import Environment
from modal.output import OutputManager

from ._help import ModalGroup

config_cli = ModalGroup(
    name="config",
    help="""
    Manage client configuration for the current profile.

    Refer to https://modal.com/docs/reference/modal.config for a full explanation
    of what these options mean, and how to set them.
    """,
)


@config_cli.command("show", help="Show current configuration values (debugging command).")
@click.option("--redact/--no-redact", default=True, help="Redact the `token_secret` value.")
def show(redact: bool):
    # This is just a test command
    config_dict = config.to_dict()
    if redact and config_dict.get("token_secret"):
        config_dict["token_secret"] = "***"

    OutputManager.get().print_json(json.dumps(config_dict))


SET_DEFAULT_ENV_HELP = """Set the default Modal environment for the active profile

The default environment of a profile is used when no --env flag is passed to `modal run`, `modal deploy` etc.

If no default environment is set, and there exists multiple environments in a workspace, an error will be raised
when running a command that requires an environment.
"""


@config_cli.command("set-environment", help=SET_DEFAULT_ENV_HELP)
@click.argument("environment_name")
def set_environment(environment_name: str):
    # Confirm that the environment exists by looking it up
    Environment.from_name(environment_name).hydrate()
    _store_user_config({"environment": environment_name})
    click.echo(f"New default environment for profile {_profile}: {environment_name}")


@config_cli.command("set", hidden=True)
@click.argument("key")
@click.argument("value")
def set(key: str, value: str):
    _store_user_config({key: value})
