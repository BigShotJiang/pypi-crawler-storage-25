# Copyright Modal Labs 2022
import platform
import shlex
from pathlib import Path, PurePosixPath
from typing import Any, Callable, Iterable, Optional

import click
from click import ClickException

from .._environments import ensure_env
from .._functions import _FunctionSpec
from ..app import App
from ..exception import InvalidError, NotFoundError
from ..functions import Function
from ..image import Image
from ..mount import _Mount
from ..runner import interactive_shell
from ..sandbox import Sandbox
from ..secret import Secret
from ..stream_type import StreamType
from ..volume import Volume
from ._help import ModalCommand
from .container import _exec_impl
from .import_refs import (
    MethodReference,
    import_and_filter,
    parse_import_ref,
)
from .run import _get_runnable_list
from .utils import ENV_OPTION_HELP, is_tty


def _passed_forbidden_args(
    params: Iterable[click.Parameter],
    ctx: click.Context,
    passed_args: dict[str, Any],
    allowed: Callable[[str], bool],
) -> list[str]:
    """Return the CLI spelling of any parameter that was set without being allowed.

    Assumes every param has a concrete default that survives `process_value`
    (either via an explicit `default=` kwarg, or via `multiple=True` which
    click normalizes to `()`). `test_shell_params_have_concrete_defaults`
    enforces this invariant on the `shell` command itself.
    """
    passed_forbidden: list[str] = []
    for param in params:
        name = param.name
        if name is None or allowed(name):
            continue
        default = param.process_value(ctx, param.get_default(ctx))
        if passed_args.get(name) != default:
            if isinstance(param, click.Argument):
                cli_names = [name.upper()]
            else:
                cli_names = [*param.opts, *param.secondary_opts]
            passed_forbidden.append("/".join(cli_names))
    return passed_forbidden


def _parse_experimental_options(options: Iterable[str]) -> dict[str, bool]:
    parsed: dict[str, bool] = {}
    for option in options:
        key, sep, raw_value = option.partition("=")
        if not key or not sep:
            raise click.BadParameter("must use KEY=VALUE")

        value = raw_value.lower()
        if value in {"1", "true"}:
            parsed[key] = True
        elif value in {"0", "false"}:
            parsed[key] = False
        else:
            raise click.BadParameter("BOOL must be one of true, false, 1, or 0")
    return parsed


def _is_valid_modal_id(ref: str, prefix: str) -> bool:
    assert prefix.endswith("-")
    return ref.startswith(prefix) and len(ref[len(prefix) :]) > 0 and ref[len(prefix) :].isalnum()


def _parse_sandbox_container_ref(ref: str) -> tuple[str, Optional[str]]:
    """Parse a sandbox:container reference into (sandbox_id, container_name).

    Supports the pattern `sb-xyz:container_name` for accessing sandbox containers.
    Returns (ref, None) if no container name is specified.
    """
    if _is_valid_modal_id(ref, "sb-"):
        return ref, None

    if ":" in ref:
        parts = ref.split(":", 1)
        sandbox_id, container_name = parts[0], parts[1]
        if _is_valid_modal_id(sandbox_id, "sb-") and container_name:
            return sandbox_id, container_name

    return ref, None


def _is_running_container_ref(ref: Optional[str]) -> bool:
    if ref is None:
        return False
    sandbox_id, _ = _parse_sandbox_container_ref(ref)
    return _is_valid_modal_id(sandbox_id, "sb-") or _is_valid_modal_id(ref, "ta-")


def _start_shell_in_sandbox_container(sandbox_id: str, container_name: str, cmd: str, pty: bool) -> None:
    """Shell into a named container within a sandbox."""
    try:
        sandbox = Sandbox.from_id(sandbox_id)
    except NotFoundError:
        raise ClickException(f"Sandbox '{sandbox_id}' not found (is it still running?)")
    except Exception as e:
        raise ClickException(f"Error connecting to Sandbox '{sandbox_id}': {str(e)}")

    try:
        sandbox_container = sandbox._experimental_containers.get(name=container_name)
        if pty:
            # PTY output is raw terminal bytes, not text; strict UTF-8 decode
            # crashes on the first non-UTF-8 byte (e.g. vim drawing a Latin-1
            # file under LC_CTYPE=C). See the matching call in `_exec_impl`.
            process = sandbox_container.exec(*shlex.split(cmd), pty=pty, text=False)
            process.attach()
        else:
            process = sandbox_container.exec(
                *shlex.split(cmd), pty=pty, stdout=StreamType.STDOUT, stderr=StreamType.STDOUT
            )
            process.wait()
    except NotFoundError:
        raise ClickException(f"Container '{container_name}' not found in Sandbox '{sandbox_id}'.")
    except Exception as e:
        raise ClickException(f"Error exec-ing into container '{container_name}' in Sandbox '{sandbox_id}': {str(e)}")


def _start_shell_in_running_container(ref: str, cmd: str, pty: bool) -> None:
    sandbox_id, container_name = _parse_sandbox_container_ref(ref)

    if container_name is not None:
        return _start_shell_in_sandbox_container(sandbox_id, container_name, cmd, pty)

    if _is_valid_modal_id(sandbox_id, "sb-"):
        try:
            sandbox = Sandbox.from_id(sandbox_id)
            ref = sandbox._get_task_id()
        except NotFoundError:
            raise ClickException(f"Sandbox '{sandbox_id}' not found (is it still running?)")
        except Exception as e:
            raise ClickException(f"Error connecting to Sandbox '{sandbox_id}': {str(e)}")

    assert _is_valid_modal_id(ref, "ta-")
    try:
        _exec_impl(container_id=ref, command=shlex.split(cmd), pty=pty)
    except NotFoundError:
        raise ClickException(f"Container '{ref}' not found (is it still running?)")
    except Exception as e:
        raise ClickException(f"Error connecting to container '{ref}': {str(e)}")


def _function_spec_from_ref(ref: str, use_module_mode: bool) -> _FunctionSpec:
    import_ref = parse_import_ref(ref, use_module_mode=use_module_mode, command="modal shell")
    runnable, all_usable_commands = import_and_filter(
        import_ref,
        base_cmd="modal shell",
        accept_local_entrypoint=False,
        accept_webhook=True,
        accept_service_functions=True,
    )
    if not runnable:
        help_header = (
            "Specify a Modal function to start a shell session for. E.g.\n"
            f"> modal shell {import_ref.file_or_module}::my_function"
        )

        if all_usable_commands:
            help_footer = f"The selected module '{import_ref.file_or_module}' has the following choices:\n\n"
            help_footer += _get_runnable_list(all_usable_commands)
        else:
            help_footer = f"The selected module '{import_ref.file_or_module}' has no Modal functions or classes."

        raise ClickException(f"{help_header}\n\n{help_footer}")

    if isinstance(runnable, MethodReference):
        # TODO: let users specify a class instead of a method, since they use the same environment
        class_service_function = runnable.cls._get_class_service_function()
        return class_service_function.spec
    elif isinstance(runnable, Function):
        return runnable.spec

    raise ValueError("Referenced entity is not a Modal Function or Cls")


def _start_shell_from_function_spec(
    app: App,
    cmds: list[str],
    env: str,
    timeout: int,
    function_spec: _FunctionSpec,
    pty: bool,
    experimental_options: dict[str, bool],
) -> None:
    interactive_shell(
        app,
        cmds=cmds,
        environment_name=env,
        timeout=timeout,
        image=function_spec.image,
        mounts=function_spec.mounts,
        secrets=function_spec.secrets,
        network_file_systems=function_spec.network_file_systems,
        gpu=function_spec.gpus,
        cloud=function_spec.cloud,
        cpu=function_spec.cpu,
        memory=function_spec.memory,
        volumes=function_spec.volumes,
        region=function_spec.scheduler_placement.regions if function_spec.scheduler_placement else None,
        pty=pty,
        proxy=function_spec.proxy,
        experimental_options=experimental_options,
    )


def _start_shell_from_image(
    app: App,
    cmds: list[str],
    env: str,
    timeout: int,
    modal_image: Optional[Image],
    volume: list[str],
    secret: list[str],
    add_local: list[str],
    cpu: Optional[int],
    memory: Optional[int],
    gpu: Optional[str],
    cloud: Optional[str],
    region: Optional[str],
    pty: bool,
    experimental_options: dict[str, bool],
) -> None:
    volumes = {f"/mnt/{vol}": Volume.from_name(vol) for vol in volume}
    secrets = [Secret.from_name(s) for s in secret]

    mounts = []
    for local_path_str in add_local:
        local_path = Path(local_path_str).expanduser().resolve()
        remote_path = PurePosixPath(f"/mnt/{local_path.name}")

        if local_path.is_dir():
            m = _Mount._from_local_dir(local_path, remote_path=remote_path)
        else:
            m = _Mount._from_local_file(local_path, remote_path=remote_path)
        mounts.append(m)

    interactive_shell(
        app,
        cmds=cmds,
        environment_name=env,
        timeout=timeout,
        image=modal_image,
        mounts=mounts,
        cpu=cpu,
        memory=memory,
        gpu=gpu,
        cloud=cloud,
        volumes=volumes,
        secrets=secrets,
        region=region.split(",") if region else [],
        pty=pty,
        experimental_options=experimental_options,
    )


@click.command("shell", cls=ModalCommand)
@click.argument("ref", default=None, required=False)
@click.option("-c", "--cmd", default="/bin/bash", help="Command to run inside the Modal image.")
@click.option("-e", "--env", default=None, help=ENV_OPTION_HELP)
@click.option("--image", default=None, help="Container image tag for inside the shell (if not using REF).")
@click.option("--add-python", default=None, help="Add Python to the image (if not using REF).")
@click.option(
    "--volume",
    multiple=True,
    help="Name of a modal.Volume to mount inside the shell at /mnt/{name} (if not using REF). "
    "Can be used multiple times.",
)
@click.option(
    "--add-local",
    multiple=True,
    help="Local file or directory to mount inside the shell at /mnt/{basename} (if not using REF). "
    "Can be used multiple times.",
)
@click.option(
    "--secret",
    multiple=True,
    help="Name of a modal.Secret to mount inside the shell (if not using REF). Can be used multiple times.",
)
@click.option("--cpu", default=None, type=int, help="Number of CPUs to allocate to the shell (if not using REF).")
@click.option("--memory", default=None, type=int, help="Memory to allocate for the shell, in MiB (if not using REF).")
@click.option(
    "--gpu",
    default=None,
    help="GPUs to request for the shell, if any. Examples are `any`, `a10g`, `a100:4` (if not using REF).",
)
@click.option(
    "--cloud",
    default=None,
    help="Cloud provider to run the shell on. Possible values are `aws`, `gcp`, `oci`, `auto` (if not using REF).",
)
@click.option(
    "--region",
    default=None,
    help="Region(s) to run the container on. "
    "Can be a single region or a comma-separated list to choose from (if not using REF).",
)
@click.option("--pty/--no-pty", default=None, help="Run the command using a PTY.")
@click.option(
    "-m",
    "use_module_mode",
    is_flag=True,
    default=False,
    help="Interpret argument as a Python module path instead of a file/script path",
)
@click.option(
    "--experimental-option",
    "experimental_options",
    multiple=True,
    default=(),
    hidden=True,
    metavar="KEY=VALUE",
)
def shell(
    ref: Optional[str] = None,
    cmd: str = "/bin/bash",
    env: Optional[str] = None,
    image: Optional[str] = None,
    add_python: Optional[str] = None,
    volume: tuple[str, ...] = (),
    add_local: tuple[str, ...] = (),
    secret: tuple[str, ...] = (),
    cpu: Optional[int] = None,
    memory: Optional[int] = None,
    gpu: Optional[str] = None,
    cloud: Optional[str] = None,
    region: Optional[str] = None,
    pty: Optional[bool] = None,
    use_module_mode: bool = False,
    experimental_options: tuple[str, ...] = (),
):
    """Run a command or interactive shell inside a Modal container.

    **Examples:**

    Start an interactive shell inside the default Debian-based image:

    ```
    modal shell
    ```

    Start an interactive shell with the spec for `my_function` in your App
    (uses the same image, volumes, mounts, etc.):

    ```
    modal shell hello_world.py::my_function
    ```

    Or, if you're using a [modal.Cls](https://modal.com/docs/reference/modal.Cls)
    you can refer to a `@modal.method` directly:

    ```
    modal shell hello_world.py::MyClass.my_method
    ```

    Start a `python` shell:

    ```
    modal shell hello_world.py --cmd=python
    ```

    Run a command with your function's spec and pipe the output to a file:

    ```
    modal shell hello_world.py -c 'uv pip list' > env.txt
    ```

    Connect to a running Sandbox by ID:

    ```
    modal shell sb-abc123xyz
    ```
    """
    if pty is None:
        pty = is_tty()

    if platform.system() == "Windows":
        raise InvalidError("`modal shell` is currently not supported on Windows")

    if ref is not None and _is_running_container_ref(ref):
        # We're attaching to an already running container or Sandbox.
        ctx = click.get_current_context()
        if passed_forbidden := _passed_forbidden_args(
            shell.params, ctx, locals(), allowed=lambda p: p in {"cmd", "pty", "ref"}
        ):
            raise ClickException(
                f"Cannot specify container configuration arguments ({', '.join(passed_forbidden)}) "
                f"when attaching to an already running container or Sandbox ('{ref}')."
            )

        _start_shell_in_running_container(ref, cmd, pty)
        return

    # We're not attaching to an existing container, so we need to create a new one.
    env = ensure_env(env)
    app = App("modal shell")

    # NB: invoking under bash makes --cmd a lot more flexible.
    cmds = shlex.split(f'/bin/bash -c "{cmd}"')
    timeout = 3600
    parsed_experimental_options = _parse_experimental_options(experimental_options)

    if ref is not None and not _is_valid_modal_id(ref, "im-"):
        # If ref it not a Modal Image ID, then it's a function reference, and we'll start a new container from its spec.
        ctx = click.get_current_context()
        if passed_forbidden := _passed_forbidden_args(
            shell.params,
            ctx,
            locals(),
            allowed=lambda p: p in {"cmd", "env", "pty", "ref", "use_module_mode", "experimental_options"},
        ):
            raise ClickException(
                f"Cannot specify container configuration arguments ({', '.join(passed_forbidden)}) "
                f"when starting a new container from a function reference ('{ref}')."
            )

        function_spec = _function_spec_from_ref(ref, use_module_mode)
        _start_shell_from_function_spec(app, cmds, env, timeout, function_spec, pty, parsed_experimental_options)
        return

    if ref is not None and _is_valid_modal_id(ref, "im-"):
        ctx = click.get_current_context()
        if passed_forbidden := _passed_forbidden_args(
            shell.params, ctx, locals(), allowed=lambda p: p not in {"add_python", "image"}
        ):
            raise ClickException(
                f"Cannot specify {', '.join(passed_forbidden)} argument(s) "
                f"when starting a new container from a Modal Image ID ('{ref}')."
            )
        modal_image = Image.from_id(ref)
    else:
        modal_image = Image.from_registry(image, add_python=add_python) if image else None

    _start_shell_from_image(
        app,
        cmds,
        env,
        timeout,
        modal_image,
        list(volume),
        list(secret),
        list(add_local),
        cpu,
        memory,
        gpu,
        cloud,
        region,
        pty,
        parsed_experimental_options,
    )
