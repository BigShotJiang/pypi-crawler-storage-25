/**
 * DmComposerFull — full-featured DM composer (§23.47e).
 * Extends the basic input with media attachment, type picker, and mentions.
 */
import { signal } from '@preact/signals'
import { Button } from './Button'
import {
  EmojiAutocomplete,
  checkForEmojiTrigger,
  closeEmojiAutocomplete,
  handleEmojiAutocompleteKey,
} from './EmojiAutocomplete'
import { EmojiPickButton } from './EmojiPickButton'
import { SttButton } from './SttButton'
import { hasCapability } from '@/store/instance'
import { UploadProgressBar, uploadWithProgress } from './UploadProgress'
import { showToast } from './Toast'
import { sendTyping } from './TypingIndicator'

const content = signal('')
const msgType = signal('text')
// Canonical (unsigned) media URL, sent on the ``send_message`` API call.
const mediaUrl = signal<string | null>(null)
// Short-lived signed URL for the local preview ``<img>`` only.
const mediaPreviewUrl = signal<string | null>(null)
const sending = signal(false)

const TYPE_ICONS: Record<string, string> = {
  text: '🔤', image: '📷', video: '🎬', location: '📍',
}

export function DmComposerFull({ conversationId, onSend }: {
  conversationId: string
  onSend: (content: string, type: string, mediaUrl?: string) => Promise<void>
}) {
  const handleSend = async () => {
    if (sending.value || (!content.value.trim() && !mediaUrl.value)) return
    sending.value = true
    try {
      await onSend(content.value, msgType.value, mediaUrl.value || undefined)
      content.value = ''
      mediaUrl.value = null
      mediaPreviewUrl.value = null
      msgType.value = 'text'
    } finally { sending.value = false }
  }

  const handleAttach = async () => {
    const input = document.createElement('input')
    input.type = 'file'
    input.accept = 'image/*,video/*'
    input.onchange = async () => {
      const file = input.files?.[0]
      if (!file) return
      try {
        const result = await uploadWithProgress(file)
        mediaUrl.value = result.url
        mediaPreviewUrl.value = result.signed_url
        msgType.value = file.type.startsWith('video/') ? 'video' : 'image'
      } catch (err: unknown) {
        // Surface the failure rather than swallowing — a silent
        // ``catch {}`` here let the user think a file had attached
        // when it hadn't, and they only noticed on send.
        showToast(`Upload failed: ${(err as Error)?.message ?? err}`, 'error')
      }
    }
    input.click()
  }

  const splice = (emoji: string, range: [number, number]) => {
    const [start, end] = range
    content.value =
      content.value.slice(0, start) + emoji + content.value.slice(end)
  }

  const handleInput = (e: Event) => {
    const t = e.target as HTMLInputElement
    content.value = t.value
    sendTyping(conversationId)
    checkForEmojiTrigger(t.value, t.selectionStart ?? 0, t, splice)
  }

  return (
    <div class="sh-dm-composer-full">
      <UploadProgressBar />
      <div class="sh-dm-type-picker">
        {Object.entries(TYPE_ICONS).map(([type, icon]) => (
          <button key={type} type="button"
            class={`sh-type-btn ${msgType.value === type ? 'sh-type-btn--active' : ''}`}
            onClick={() => msgType.value = type}>{icon}</button>
        ))}
        <button class="sh-attach-btn" onClick={handleAttach} title="Attach file">📎</button>
      </div>
      {mediaUrl.value && (
        <div class="sh-dm-media-preview">
          <img
            src={mediaPreviewUrl.value ?? mediaUrl.value}
            alt=""
            class="sh-dm-thumb"
          />
          <button
            type="button"
            aria-label="Remove attachment"
            onClick={() => {
              mediaUrl.value = null
              mediaPreviewUrl.value = null
              msgType.value = 'text'
            }}
          >✕</button>
        </div>
      )}
      <div class="sh-dm-input-row">
        <input value={content.value} onInput={handleInput}
          placeholder="Type a message..." autocomplete="off"
          onKeyDown={(e) => {
            if (handleEmojiAutocompleteKey(e)) {
              e.preventDefault()
              return
            }
            if (e.key === 'Enter') handleSend()
          }}
          onBlur={() => closeEmojiAutocomplete()} />
        <EmojiPickButton
          openKey="dm-composer"
          onInsert={(emoji) => { content.value = content.value + emoji }}
        />
        {hasCapability('stt') && (
          <SttButton onText={(t) => {
            const sep = content.value && !/\s$/.test(content.value) ? ' ' : ''
            content.value = content.value + sep + t
          }} />
        )}
        <Button onClick={handleSend} loading={sending.value}
          disabled={!content.value.trim() && !mediaUrl.value}>Send</Button>
      </div>
      <EmojiAutocomplete />
    </div>
  )
}
