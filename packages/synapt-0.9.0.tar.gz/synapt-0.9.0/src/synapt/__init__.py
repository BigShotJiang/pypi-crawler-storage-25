"""Synapt: persistent conversational memory for AI coding assistants."""

__version__ = "0.9.0"
