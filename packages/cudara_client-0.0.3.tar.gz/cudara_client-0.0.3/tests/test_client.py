"""
Tests for cudara_client.

Requires: pytest, respx, httpx

    pip install pytest respx httpx

Run:
    pytest test_client.py -v
"""

from __future__ import annotations

import base64
import json
from pathlib import Path
from typing import Any, Iterator, cast

import httpx
import pytest
import respx

from cudara_client import (
    CudaraClient,
    EmbedResponse,
    Message,
    ModelDetails,
    Response,
    ShowResponse,
)

# ===================================================================
# Fixtures
# ===================================================================

BASE_URL = "http://localhost:8000"


@pytest.fixture()
def client() -> CudaraClient:
    """Return a throwaway client pointing at the mock base URL."""
    return CudaraClient(BASE_URL)


# -- Reusable server response payloads --------------------------------

GENERATE_RESPONSE: dict[str, Any] = {
    "model": "test-model",
    "response": "Sky is blue",
    "thinking": "because of Rayleigh scattering",
    "done": True,
    "done_reason": "stop",
    "total_duration": 500_000_000,
    "load_duration": 100_000_000,
    "prompt_eval_count": 6,
    "eval_count": 42,
    "eval_duration": 400_000_000,
}

CHAT_RESPONSE: dict[str, Any] = {
    "model": "chat-model",
    "message": {"role": "assistant", "content": "4"},
    "thinking": "2+2=4",
    "done": True,
    "done_reason": "stop",
    "total_duration": 300_000_000,
    "load_duration": 50_000_000,
    "prompt_eval_count": 10,
    "eval_count": 1,
    "eval_duration": 250_000_000,
}

EMBED_RESPONSE: dict[str, Any] = {
    "model": "embed-model",
    "embeddings": [[0.1, 0.2, 0.3], [0.4, 0.5, 0.6]],
    "total_duration": 200_000_000,
    "load_duration": 30_000_000,
    "prompt_eval_count": 8,
}

RERANK_RESPONSE: dict[str, Any] = {
    "model": "reranker",
    "scores": [0.95, 0.12],
    "total_duration": 150_000_000,
}

SHOW_RESPONSE: dict[str, Any] = {
    "parameters": "temperature 0.7",
    "license": "Apache-2.0",
    "modified_at": "2025-06-01T12:00:00Z",
    "details": {
        "format": "safetensors",
        "family": "text-generation",
        "families": ["text-generation"],
        "parameter_size": "7B",
        "quantization_level": "AWQ",
    },
    "capabilities": ["completion"],
    "model_info": {"general.architecture": "llama"},
    "template": None,
}

TAGS_RESPONSE: dict[str, Any] = {
    "models": [
        {
            "name": "my-model",
            "model": "my-model",
            "modified_at": "2025-06-01T00:00:00Z",
            "size": 4_000_000_000,
            "digest": "sha256:abcdef",
            "details": {
                "format": "safetensors",
                "family": "text-generation",
                "families": ["text-generation"],
                "parameter_size": "7B",
                "quantization_level": "None",
            },
        }
    ]
}

PS_RESPONSE: dict[str, Any] = {
    "models": [
        {
            "name": "my-model",
            "model": "my-model",
            "size": 4_000_000_000,
            "digest": "sha256:abcdef",
            "details": {
                "format": "safetensors",
                "family": "text-generation",
                "families": ["text-generation"],
            },
            "expires_at": "2025-06-01T01:00:00Z",
            "size_vram": 3_500_000_000,
            "context_length": 8192,
        }
    ]
}


# ===================================================================
# Message dataclass
# ===================================================================


class TestMessage:
    """Tests for the Message dataclass and its serialization."""

    def test_to_dict_minimal(self) -> None:
        """Minimal message serializes to role + content only."""
        msg = Message(role="user", content="hello")
        assert msg.to_dict() == {"role": "user", "content": "hello"}

    def test_to_dict_with_images(self) -> None:
        """Images list is included when present."""
        msg = Message(role="user", content="describe", images=["abc123"])
        d = msg.to_dict()
        assert d["images"] == ["abc123"]

    def test_to_dict_with_tool_calls(self) -> None:
        """Tool-call objects are included when present."""
        calls = [{"id": "1", "function": {"name": "get_weather"}}]
        msg = Message(role="assistant", content="", tool_calls=calls)
        d = msg.to_dict()
        assert d["tool_calls"] == calls

    def test_to_dict_omits_none_fields(self) -> None:
        """None-valued optional fields are excluded from the dict."""
        msg = Message(role="system", content="be helpful")
        d = msg.to_dict()
        assert "images" not in d
        assert "tool_calls" not in d


# ===================================================================
# Response dataclass
# ===================================================================


class TestResponse:
    """Tests for Response computed properties."""

    def test_duration_ms(self) -> None:
        """Nanoseconds are correctly converted to milliseconds."""
        r = Response(content="", model="m", total_duration_ns=2_500_000_000)
        assert r.duration_ms == 2500.0

    def test_duration_ms_zero(self) -> None:
        """Zero nanoseconds yields zero milliseconds."""
        r = Response(content="", model="m")
        assert r.duration_ms == 0.0

    def test_tokens_per_second(self) -> None:
        """Throughput is computed from eval_count and eval_duration_ns."""
        r = Response(content="", model="m", eval_count=100, eval_duration_ns=2_000_000_000)
        assert r.tokens_per_second == 50.0

    def test_tokens_per_second_zero_duration(self) -> None:
        """Zero eval duration returns 0.0 instead of raising."""
        r = Response(content="", model="m", eval_count=10, eval_duration_ns=0)
        assert r.tokens_per_second == 0.0

    def test_tokens_per_second_zero_count(self) -> None:
        """Zero eval count returns 0.0."""
        r = Response(content="", model="m", eval_count=0, eval_duration_ns=1_000_000)
        assert r.tokens_per_second == 0.0


# ===================================================================
# Generate endpoint
# ===================================================================


class TestGenerate:
    """Tests for CudaraClient.generate()."""

    @respx.mock
    def test_basic_payload(self, client: CudaraClient) -> None:
        """Core required fields are sent in the JSON body."""
        route = respx.post(f"{BASE_URL}/api/generate").mock(return_value=httpx.Response(200, json=GENERATE_RESPONSE))

        client.generate("test-model", "Why is the sky blue?")

        assert route.called
        payload = json.loads(route.calls.last.request.content)
        assert payload["model"] == "test-model"
        assert payload["prompt"] == "Why is the sky blue?"
        assert payload["stream"] is False

    @respx.mock
    def test_all_optional_params(self, client: CudaraClient) -> None:
        """Every optional parameter is forwarded in the payload."""
        route = respx.post(f"{BASE_URL}/api/generate").mock(return_value=httpx.Response(200, json=GENERATE_RESPONSE))

        client.generate(
            "test-model",
            "hello",
            system="be concise",
            suffix="</code>",
            images=["img64"],
            format="json",
            think=True,
            raw=True,
            keep_alive="5m",
            options={"temperature": 0.5},
            logprobs=True,
            top_logprobs=5,
        )

        payload = json.loads(route.calls.last.request.content)
        assert payload["system"] == "be concise"
        assert payload["suffix"] == "</code>"
        assert payload["images"] == ["img64"]
        assert payload["format"] == "json"
        assert payload["think"] is True
        assert payload["raw"] is True
        assert payload["keep_alive"] == "5m"
        assert payload["options"]["temperature"] == 0.5
        assert payload["logprobs"] is True
        assert payload["top_logprobs"] == 5

    @respx.mock
    def test_response_parsing(self, client: CudaraClient) -> None:
        """All server response fields are mapped to the Response dataclass."""
        respx.post(f"{BASE_URL}/api/generate").mock(return_value=httpx.Response(200, json=GENERATE_RESPONSE))

        resp = client.generate("test-model", "hello")
        assert isinstance(resp, Response)

        assert resp.content == "Sky is blue"
        assert resp.model == "test-model"
        assert resp.thinking == "because of Rayleigh scattering"
        assert resp.done is True
        assert resp.done_reason == "stop"
        assert resp.total_duration_ns == 500_000_000
        assert resp.load_duration_ns == 100_000_000
        assert resp.prompt_eval_count == 6
        assert resp.eval_count == 42
        assert resp.eval_duration_ns == 400_000_000
        assert resp.raw == GENERATE_RESPONSE

    @respx.mock
    def test_think_budget_level(self, client: CudaraClient) -> None:
        """String-valued think budget level is forwarded as-is."""
        route = respx.post(f"{BASE_URL}/api/generate").mock(return_value=httpx.Response(200, json=GENERATE_RESPONSE))

        client.generate("test-model", "solve this", think="high")

        payload = json.loads(route.calls.last.request.content)
        assert payload["think"] == "high"

    @respx.mock
    def test_json_schema_format(self, client: CudaraClient) -> None:
        """A dict format value is sent as a JSON schema object."""
        schema = {"type": "object", "properties": {"answer": {"type": "string"}}}
        route = respx.post(f"{BASE_URL}/api/generate").mock(return_value=httpx.Response(200, json=GENERATE_RESPONSE))

        client.generate("test-model", "respond", format=schema)

        payload = json.loads(route.calls.last.request.content)
        assert payload["format"] == schema

    @respx.mock
    def test_none_optionals_omitted(self, client: CudaraClient) -> None:
        """Keys for None-valued optional params are not sent in the payload."""
        route = respx.post(f"{BASE_URL}/api/generate").mock(return_value=httpx.Response(200, json=GENERATE_RESPONSE))

        client.generate("m", "p")

        payload = json.loads(route.calls.last.request.content)
        for key in (
            "system",
            "suffix",
            "images",
            "format",
            "think",
            "raw",
            "keep_alive",
            "options",
            "logprobs",
            "top_logprobs",
        ):
            assert key not in payload

    @respx.mock
    def test_http_error_propagates(self, client: CudaraClient) -> None:
        """Non-2xx responses raise httpx.HTTPStatusError."""
        respx.post(f"{BASE_URL}/api/generate").mock(return_value=httpx.Response(400, json={"error": "bad request"}))

        with pytest.raises(httpx.HTTPStatusError):
            client.generate("m", "p")


# ===================================================================
# Generate streaming
# ===================================================================


class TestGenerateStreaming:
    """Tests for streaming mode of CudaraClient.generate()."""

    @respx.mock
    def test_stream_yields_chunks(self, client: CudaraClient) -> None:
        """Each NDJSON line is yielded as a Response with correct fields."""
        chunks = [
            json.dumps({"model": "m", "response": "Hello", "done": False}),
            json.dumps({"model": "m", "response": " world", "done": False}),
            json.dumps(
                {
                    "model": "m",
                    "response": "",
                    "done": True,
                    "done_reason": "stop",
                    "total_duration": 100_000_000,
                    "eval_count": 2,
                    "eval_duration": 80_000_000,
                }
            ),
        ]
        body = "\n".join(chunks)
        respx.post(f"{BASE_URL}/api/generate").mock(return_value=httpx.Response(200, text=body))

        result = client.generate("m", "hi", stream=True)
        assert isinstance(result, Iterator)
        items = list(result)

        assert len(items) == 3
        assert items[0].content == "Hello"
        assert items[0].done is False
        assert items[1].content == " world"
        assert items[2].done is True
        assert items[2].done_reason == "stop"
        assert items[2].eval_count == 2

    @respx.mock
    def test_stream_request_payload(self, client: CudaraClient) -> None:
        """The stream flag is True in the outgoing payload."""
        respx.post(f"{BASE_URL}/api/generate").mock(
            return_value=httpx.Response(
                200,
                text=json.dumps({"model": "m", "response": "", "done": True}),
            )
        )

        result = client.generate("m", "hi", stream=True)
        assert isinstance(result, Iterator)
        list(result)  # consume the iterator to trigger the request

        payload = json.loads(respx.calls.last.request.content)
        assert payload["stream"] is True


# ===================================================================
# Chat endpoint
# ===================================================================


class TestChat:
    """Tests for CudaraClient.chat()."""

    @respx.mock
    def test_string_shorthand(self, client: CudaraClient) -> None:
        """A plain string is wrapped as a single user message."""
        route = respx.post(f"{BASE_URL}/api/chat").mock(return_value=httpx.Response(200, json=CHAT_RESPONSE))

        client.chat("chat-model", "What is 2+2?")

        payload = json.loads(route.calls.last.request.content)
        assert payload["messages"] == [{"role": "user", "content": "What is 2+2?"}]

    @respx.mock
    def test_message_objects(self, client: CudaraClient) -> None:
        """Message dataclass instances are serialized via to_dict()."""
        route = respx.post(f"{BASE_URL}/api/chat").mock(return_value=httpx.Response(200, json=CHAT_RESPONSE))

        msgs = [
            Message(role="system", content="be brief"),
            Message(role="user", content="hi"),
        ]
        client.chat("chat-model", msgs)

        payload = json.loads(route.calls.last.request.content)
        assert len(payload["messages"]) == 2
        assert payload["messages"][0]["role"] == "system"

    @respx.mock
    def test_dict_messages(self, client: CudaraClient) -> None:
        """Raw dicts are passed through unchanged."""
        route = respx.post(f"{BASE_URL}/api/chat").mock(return_value=httpx.Response(200, json=CHAT_RESPONSE))

        client.chat("chat-model", [{"role": "user", "content": "hey"}])

        payload = json.loads(route.calls.last.request.content)
        assert payload["messages"][0]["content"] == "hey"

    @respx.mock
    def test_images_in_messages(self, client: CudaraClient) -> None:
        """Base64 image strings in Message objects reach the payload."""
        route = respx.post(f"{BASE_URL}/api/chat").mock(return_value=httpx.Response(200, json=CHAT_RESPONSE))

        client.chat(
            "vlm",
            [Message(role="user", content="What is this?", images=["b64str"])],
        )

        payload = json.loads(route.calls.last.request.content)
        assert payload["messages"][0]["images"] == ["b64str"]

    @respx.mock
    def test_all_optional_params(self, client: CudaraClient) -> None:
        """Every optional parameter is forwarded in the payload."""
        route = respx.post(f"{BASE_URL}/api/chat").mock(return_value=httpx.Response(200, json=CHAT_RESPONSE))

        tools = [{"type": "function", "function": {"name": "search"}}]
        client.chat(
            "chat-model",
            "hi",
            format="json",
            think="medium",
            keep_alive=-1,
            options={"top_k": 40},
            tools=tools,
            logprobs=True,
            top_logprobs=3,
        )

        payload = json.loads(route.calls.last.request.content)
        assert payload["format"] == "json"
        assert payload["think"] == "medium"
        assert payload["keep_alive"] == -1
        assert payload["options"]["top_k"] == 40
        assert payload["tools"] == tools
        assert payload["logprobs"] is True
        assert payload["top_logprobs"] == 3

    @respx.mock
    def test_response_parsing(self, client: CudaraClient) -> None:
        """All server response fields are mapped to the Response dataclass."""
        respx.post(f"{BASE_URL}/api/chat").mock(return_value=httpx.Response(200, json=CHAT_RESPONSE))

        resp = client.chat("chat-model", "2+2?")
        assert isinstance(resp, Response)

        assert resp.content == "4"
        assert resp.model == "chat-model"
        assert resp.thinking == "2+2=4"
        assert resp.done is True
        assert resp.done_reason == "stop"
        assert resp.total_duration_ns == 300_000_000
        assert resp.load_duration_ns == 50_000_000
        assert resp.prompt_eval_count == 10
        assert resp.eval_count == 1
        assert resp.eval_duration_ns == 250_000_000

    @respx.mock
    def test_none_optionals_omitted(self, client: CudaraClient) -> None:
        """Keys for None-valued optional params are not sent."""
        respx.post(f"{BASE_URL}/api/chat").mock(return_value=httpx.Response(200, json=CHAT_RESPONSE))

        client.chat("m", "p")

        payload = json.loads(respx.calls.last.request.content)
        for key in (
            "format",
            "think",
            "keep_alive",
            "options",
            "tools",
            "logprobs",
            "top_logprobs",
        ):
            assert key not in payload


# ===================================================================
# Chat streaming
# ===================================================================


class TestChatStreaming:
    """Tests for streaming mode of CudaraClient.chat()."""

    @respx.mock
    def test_stream_yields_chunks(self, client: CudaraClient) -> None:
        """Each NDJSON line is yielded as a Response with message content."""
        chunks = [
            json.dumps(
                {
                    "model": "m",
                    "message": {"role": "assistant", "content": "Hi"},
                    "done": False,
                }
            ),
            json.dumps(
                {
                    "model": "m",
                    "message": {"role": "assistant", "content": ""},
                    "done": True,
                    "done_reason": "stop",
                }
            ),
        ]
        body = "\n".join(chunks)
        respx.post(f"{BASE_URL}/api/chat").mock(return_value=httpx.Response(200, text=body))

        result = client.chat("m", "hello", stream=True)
        assert isinstance(result, Iterator)
        items = list(result)

        assert len(items) == 2
        assert items[0].content == "Hi"
        assert items[0].done is False
        assert items[1].done is True


# ===================================================================
# Embed endpoint
# ===================================================================


class TestEmbed:
    """Tests for CudaraClient.embed()."""

    @respx.mock
    def test_single_string(self, client: CudaraClient) -> None:
        """A single string input is sent as-is and returns embeddings."""
        route = respx.post(f"{BASE_URL}/api/embed").mock(return_value=httpx.Response(200, json=EMBED_RESPONSE))

        resp = client.embed("embed-model", "hello world")

        payload = json.loads(route.calls.last.request.content)
        assert payload["input"] == "hello world"
        assert isinstance(resp, EmbedResponse)
        assert resp.embeddings == [[0.1, 0.2, 0.3], [0.4, 0.5, 0.6]]

    @respx.mock
    def test_list_of_strings(self, client: CudaraClient) -> None:
        """A list of strings is sent as a batch."""
        route = respx.post(f"{BASE_URL}/api/embed").mock(return_value=httpx.Response(200, json=EMBED_RESPONSE))

        client.embed("embed-model", ["foo", "bar"])

        payload = json.loads(route.calls.last.request.content)
        assert payload["input"] == ["foo", "bar"]

    @respx.mock
    def test_all_optional_params(self, client: CudaraClient) -> None:
        """Truncate, dimensions, keep_alive, and options are forwarded."""
        route = respx.post(f"{BASE_URL}/api/embed").mock(return_value=httpx.Response(200, json=EMBED_RESPONSE))

        client.embed(
            "embed-model",
            "text",
            truncate=False,
            dimensions=128,
            keep_alive="10m",
            options={"seed": 42},
        )

        payload = json.loads(route.calls.last.request.content)
        assert payload["truncate"] is False
        assert payload["dimensions"] == 128
        assert payload["keep_alive"] == "10m"
        assert payload["options"]["seed"] == 42

    @respx.mock
    def test_response_fields(self, client: CudaraClient) -> None:
        """Duration and token count fields are parsed into EmbedResponse."""
        respx.post(f"{BASE_URL}/api/embed").mock(return_value=httpx.Response(200, json=EMBED_RESPONSE))

        resp = client.embed("embed-model", "hello")

        assert resp.model == "embed-model"
        assert resp.total_duration_ns == 200_000_000
        assert resp.load_duration_ns == 30_000_000
        assert resp.prompt_eval_count == 8
        assert resp.raw == EMBED_RESPONSE

    @respx.mock
    def test_rerank(self, client: CudaraClient) -> None:
        """Reranking returns scores instead of embeddings."""
        respx.post(f"{BASE_URL}/api/embed").mock(return_value=httpx.Response(200, json=RERANK_RESPONSE))

        resp = client.embed(
            "reranker",
            ["query", "doc1", "doc2"],
            options={"is_rerank": True},
        )

        assert resp.scores == [0.95, 0.12]
        assert resp.embeddings is None


# ===================================================================
# Transcribe
# ===================================================================


class TestTranscribe:
    """Tests for CudaraClient.transcribe()."""

    @respx.mock
    def test_encodes_file_and_sets_audio_flag(
        self,
        client: CudaraClient,
        tmp_path: Path,
    ) -> None:
        """Audio bytes are base64-encoded and is_audio is set in options."""
        audio_file = tmp_path / "test.opus"
        audio_file.write_bytes(b"dummy-audio-data")

        route = respx.post(f"{BASE_URL}/api/generate").mock(
            return_value=httpx.Response(
                200,
                json={"model": "whisper", "response": "Hello world", "done": True},
            )
        )

        resp = client.transcribe("whisper", audio_file)

        payload = json.loads(route.calls.last.request.content)
        assert payload["options"]["is_audio"] is True
        assert len(payload["images"]) == 1
        assert payload["images"][0] == base64.b64encode(b"dummy-audio-data").decode()
        assert resp.content == "Hello world"

    @respx.mock
    def test_custom_prompt(self, client: CudaraClient, tmp_path: Path) -> None:
        """A custom prompt is forwarded to the generate endpoint."""
        audio_file = tmp_path / "clip.wav"
        audio_file.write_bytes(b"\x00")

        route = respx.post(f"{BASE_URL}/api/generate").mock(
            return_value=httpx.Response(
                200,
                json={"model": "w", "response": "", "done": True},
            )
        )

        client.transcribe("w", audio_file, prompt="Translate to English.")

        payload = json.loads(route.calls.last.request.content)
        assert payload["prompt"] == "Translate to English."

    @respx.mock
    def test_accepts_string_path(self, client: CudaraClient, tmp_path: Path) -> None:
        """A plain str path works the same as a Path object."""
        audio_file = tmp_path / "audio.mp3"
        audio_file.write_bytes(b"mp3data")

        respx.post(f"{BASE_URL}/api/generate").mock(
            return_value=httpx.Response(
                200,
                json={"model": "w", "response": "ok", "done": True},
            )
        )

        resp = client.transcribe("w", str(audio_file))
        assert resp.content == "ok"


# ===================================================================
# Model management endpoints
# ===================================================================


class TestTags:
    """Tests for CudaraClient.tags()."""

    @respx.mock
    def test_returns_models_list(self, client: CudaraClient) -> None:
        """The models list from the server is returned as-is."""
        respx.get(f"{BASE_URL}/api/tags").mock(return_value=httpx.Response(200, json=TAGS_RESPONSE))

        result = client.tags()

        assert len(result["models"]) == 1
        assert result["models"][0]["name"] == "my-model"


class TestShow:
    """Tests for CudaraClient.show()."""

    @respx.mock
    def test_basic(self, client: CudaraClient) -> None:
        """Model name is sent and the response is parsed into ShowResponse."""
        route = respx.post(f"{BASE_URL}/api/show").mock(return_value=httpx.Response(200, json=SHOW_RESPONSE))

        resp = client.show("my-model")

        payload = json.loads(route.calls.last.request.content)
        assert payload["model"] == "my-model"
        assert "verbose" not in payload

        assert isinstance(resp, ShowResponse)
        assert resp.modified_at == "2025-06-01T12:00:00Z"
        assert resp.parameters == "temperature 0.7"
        assert resp.license == "Apache-2.0"
        assert resp.capabilities == ["completion"]
        assert resp.model_info["general.architecture"] == "llama"
        assert resp.template is None
        assert resp.raw == SHOW_RESPONSE

    @respx.mock
    def test_details_parsing(self, client: CudaraClient) -> None:
        """Nested details dict is parsed into a ModelDetails dataclass."""
        respx.post(f"{BASE_URL}/api/show").mock(return_value=httpx.Response(200, json=SHOW_RESPONSE))

        resp = client.show("my-model")

        assert isinstance(resp.details, ModelDetails)
        assert resp.details.format == "safetensors"
        assert resp.details.family == "text-generation"
        assert resp.details.families == ["text-generation"]
        assert resp.details.parameter_size == "7B"
        assert resp.details.quantization_level == "AWQ"

    @respx.mock
    def test_verbose_flag(self, client: CudaraClient) -> None:
        """The verbose flag is included in the payload when True."""
        route = respx.post(f"{BASE_URL}/api/show").mock(return_value=httpx.Response(200, json=SHOW_RESPONSE))

        client.show("my-model", verbose=True)

        payload = json.loads(route.calls.last.request.content)
        assert payload["verbose"] is True


class TestPull:
    """Tests for CudaraClient.pull()."""

    @respx.mock
    def test_non_streaming(self, client: CudaraClient) -> None:
        """Non-streaming pull returns a single status dict."""
        respx.post(f"{BASE_URL}/api/pull").mock(return_value=httpx.Response(200, json={"status": "success"}))

        result = client.pull("new-model", stream=False)
        assert result == {"status": "success"}

    @respx.mock
    def test_streaming(self, client: CudaraClient) -> None:
        """Streaming pull yields progress events as dicts."""
        events = [
            json.dumps({"status": "downloading", "digest": "sha256:abc"}),
            json.dumps({"status": "success", "digest": "sha256:abc"}),
        ]
        body = "\n".join(events)
        respx.post(f"{BASE_URL}/api/pull").mock(return_value=httpx.Response(200, text=body))

        result = cast(Iterator[dict[str, Any]], client.pull("new-model", stream=True))

        items = list(result)
        assert len(items) == 2

        for item in items:
            assert isinstance(item, dict)

        assert items[0]["status"] == "downloading"
        assert items[1]["status"] == "success"

    @respx.mock
    def test_insecure_flag(self, client: CudaraClient) -> None:
        """The insecure flag is included in the payload when True."""
        route = respx.post(f"{BASE_URL}/api/pull").mock(return_value=httpx.Response(200, json={"status": "success"}))

        client.pull("m", stream=False, insecure=True)

        payload = json.loads(route.calls.last.request.content)
        assert payload["insecure"] is True

    @respx.mock
    def test_insecure_omitted_when_false(self, client: CudaraClient) -> None:
        """The insecure key is absent from the payload when False."""
        route = respx.post(f"{BASE_URL}/api/pull").mock(return_value=httpx.Response(200, json={"status": "success"}))

        client.pull("m", stream=False)

        payload = json.loads(route.calls.last.request.content)
        assert "insecure" not in payload


class TestDelete:
    """Tests for CudaraClient.delete()."""

    @respx.mock
    def test_sends_model_name(self, client: CudaraClient) -> None:
        """The model name is sent and the status dict is returned."""
        route = respx.delete(f"{BASE_URL}/api/delete").mock(
            return_value=httpx.Response(200, json={"status": "success"})
        )

        result = client.delete("old-model")

        payload = json.loads(route.calls.last.request.content)
        assert payload["model"] == "old-model"
        assert result["status"] == "success"


# ===================================================================
# System / introspection endpoints
# ===================================================================


class TestPs:
    """Tests for CudaraClient.ps()."""

    @respx.mock
    def test_returns_running_models(self, client: CudaraClient) -> None:
        """The running models list from the server is returned as-is."""
        respx.get(f"{BASE_URL}/api/ps").mock(return_value=httpx.Response(200, json=PS_RESPONSE))

        result = client.ps()
        models: list[dict[str, Any]] = result["models"]

        assert isinstance(models, list)
        first_model = models[0]
        assert isinstance(first_model, dict)
        assert first_model["size_vram"] == 3_500_000_000


class TestVersion:
    """Tests for CudaraClient.version()."""

    @respx.mock
    def test_returns_version_string(self, client: CudaraClient) -> None:
        """The version string is extracted from the JSON response."""
        respx.get(f"{BASE_URL}/api/version").mock(return_value=httpx.Response(200, json={"version": "0.0.1"}))

        assert client.version() == "0.0.1"

    @respx.mock
    def test_missing_key_returns_unknown(self, client: CudaraClient) -> None:
        """A missing version key falls back to 'unknown'."""
        respx.get(f"{BASE_URL}/api/version").mock(return_value=httpx.Response(200, json={}))

        assert client.version() == "unknown"


class TestHealth:
    """Tests for CudaraClient.health()."""

    @respx.mock
    def test_healthy(self, client: CudaraClient) -> None:
        """A status of 'ok' returns True."""
        respx.get(f"{BASE_URL}/health").mock(return_value=httpx.Response(200, json={"status": "ok"}))

        assert client.health() is True

    @respx.mock
    def test_unhealthy_status(self, client: CudaraClient) -> None:
        """A non-'ok' status returns False."""
        respx.get(f"{BASE_URL}/health").mock(return_value=httpx.Response(200, json={"status": "degraded"}))

        assert client.health() is False

    @respx.mock
    def test_connection_error_returns_false(self, client: CudaraClient) -> None:
        """A connection error is caught and returns False."""
        respx.get(f"{BASE_URL}/health").mock(side_effect=httpx.ConnectError("refused"))

        assert client.health() is False

    @respx.mock
    def test_server_error_returns_false(self, client: CudaraClient) -> None:
        """A 5xx HTTP error is caught and returns False."""
        respx.get(f"{BASE_URL}/health").mock(return_value=httpx.Response(500, json={"error": "boom"}))

        assert client.health() is False


# ===================================================================
# Client lifecycle
# ===================================================================


class TestClientLifecycle:
    """Tests for client construction, context manager, and close()."""

    def test_default_base_url(self) -> None:
        """The default base URL points at localhost:8000."""
        c = CudaraClient()
        assert c.base_url == "http://localhost:8000"

    def test_trailing_slash_stripped(self) -> None:
        """A trailing slash on the base URL is removed."""
        c = CudaraClient("http://example.com:9999/")
        assert c.base_url == "http://example.com:9999"

    def test_context_manager(self) -> None:
        """The context manager returns the client and closes on exit."""
        with CudaraClient() as c:
            assert isinstance(c, CudaraClient)
        # After __exit__, the httpx client should be closed.
        assert c._client.is_closed

    @respx.mock
    def test_close_is_idempotent(self) -> None:
        """Calling close() twice does not raise."""
        c = CudaraClient()
        c.close()
        c.close()  # should not raise


# ===================================================================
# Edge cases and error handling
# ===================================================================


class TestEdgeCases:
    """Tests for defensive behavior and edge-case handling."""

    @respx.mock
    def test_generate_model_fallback(self, client: CudaraClient) -> None:
        """When the server omits 'model', the client uses the requested name."""
        respx.post(f"{BASE_URL}/api/generate").mock(
            return_value=httpx.Response(200, json={"response": "hi", "done": True})
        )

        resp = client.generate("my-model", "p")
        assert isinstance(resp, Response)
        assert resp.model == "my-model"

    @respx.mock
    def test_chat_model_fallback(self, client: CudaraClient) -> None:
        """When the server omits 'model', the client uses the requested name."""
        respx.post(f"{BASE_URL}/api/chat").mock(
            return_value=httpx.Response(
                200,
                json={"message": {"content": "hi"}, "done": True},
            )
        )

        resp = client.chat("my-model", "p")
        assert isinstance(resp, Response)
        assert resp.model == "my-model"

    @respx.mock
    def test_embed_model_fallback(self, client: CudaraClient) -> None:
        """When the server omits 'model', the client uses the requested name."""
        respx.post(f"{BASE_URL}/api/embed").mock(return_value=httpx.Response(200, json={"embeddings": [[0.1]]}))

        resp = client.embed("my-model", "hello")
        assert resp.model == "my-model"

    @respx.mock
    def test_generate_missing_optional_response_fields(
        self,
        client: CudaraClient,
    ) -> None:
        """Minimal server JSON gives safe defaults for every optional field."""
        respx.post(f"{BASE_URL}/api/generate").mock(return_value=httpx.Response(200, json={"response": "ok"}))

        resp = client.generate("m", "p")
        assert isinstance(resp, Response)
        assert resp.thinking is None
        assert resp.done_reason is None
        assert resp.total_duration_ns == 0
        assert resp.load_duration_ns == 0
        assert resp.prompt_eval_count == 0
        assert resp.eval_count == 0
        assert resp.eval_duration_ns == 0

    @respx.mock
    def test_chat_empty_message_content(self, client: CudaraClient) -> None:
        """An empty message dict yields empty content string."""
        respx.post(f"{BASE_URL}/api/chat").mock(return_value=httpx.Response(200, json={"message": {}, "done": True}))

        resp = client.chat("m", "p")
        assert isinstance(resp, Response)
        assert resp.content == ""
