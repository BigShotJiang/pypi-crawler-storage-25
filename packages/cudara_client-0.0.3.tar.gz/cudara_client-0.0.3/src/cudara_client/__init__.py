"""
cudara_client: The definitive Python client for the Cudara API.

Provides a synchronous, thread-safe interface to every endpoint exposed by the
Cudara inference server, including text generation, chat, embeddings, audio
transcription, model management, and system introspection.

Usage::

    from cudara_client import CudaraClient

    client = CudaraClient("http://localhost:8000")
    response = client.generate("my-model", "Hello, world!")
    print(response.content)
    client.close()

The client can also be used as a context manager::

    with CudaraClient() as client:
        response = client.chat("my-model", "What is 2 + 2?")
        print(response.content)
"""

from __future__ import annotations

import base64
import json
import threading
from collections.abc import Sequence
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Iterator, Literal, Union, cast

import httpx

# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------
__all__ = [
    "CudaraClient",
    "Message",
    "Response",
    "EmbedResponse",
    "ShowResponse",
    "ModelDetails",
]


# ===================================================================
# Data models
# ===================================================================
@dataclass
class Message:
    """A single message in a conversation thread.

    Attributes:
        role: The author of the message.
        content: The textual body of the message.
        images: Optional list of base64-encoded images to include.
        tool_calls: Optional list of tool-call objects returned by the model.
    """

    role: Literal["system", "user", "assistant", "tool"]
    content: str
    images: list[str] | None = None
    tool_calls: list[dict[str, Any]] | None = None

    def to_dict(self) -> dict[str, Any]:
        """Serialize the message to a dictionary suitable for API payloads."""
        d: dict[str, Any] = {"role": self.role, "content": self.content}
        if self.images:
            d["images"] = self.images
        if self.tool_calls:
            d["tool_calls"] = self.tool_calls
        return d


@dataclass
class Response:
    """Standardized response for generation and chat endpoints.

    Attributes:
        content: The generated text.
        model: The model that produced the response.
        thinking: Optional chain-of-thought reasoning produced by the model.
        done: Whether the response is complete.
        done_reason: Why generation stopped (``"stop"``, ``"error"``, ``"unload"``).
        total_duration_ns: Total wall-clock time for the request in nanoseconds.
        load_duration_ns: Time spent loading the model in nanoseconds.
        prompt_eval_count: Number of tokens in the evaluated prompt.
        eval_count: Number of tokens generated.
        eval_duration_ns: Time spent generating tokens in nanoseconds.
        raw: The full, unprocessed JSON response from the server.
    """

    content: str
    model: str
    thinking: str | None = None
    done: bool = True
    done_reason: str | None = None
    total_duration_ns: int = 0
    load_duration_ns: int = 0
    prompt_eval_count: int = 0
    eval_count: int = 0
    eval_duration_ns: int = 0
    raw: dict[str, Any] | None = None

    @property
    def duration_ms(self) -> float:
        """Total request duration in milliseconds."""
        return self.total_duration_ns / 1_000_000

    @property
    def tokens_per_second(self) -> float:
        """Generation throughput (tokens/s), or ``0.0`` if unavailable."""
        if self.eval_duration_ns <= 0 or self.eval_count <= 0:
            return 0.0
        return self.eval_count / (self.eval_duration_ns / 1e9)


@dataclass
class EmbedResponse:
    """Response from the embedding or reranking endpoints.

    Attributes:
        model: The model used.
        embeddings: A list of embedding vectors (one per input text).
        scores: Relevance scores when the request was a rerank operation.
        total_duration_ns: Total wall-clock time in nanoseconds.
        load_duration_ns: Time spent loading the model in nanoseconds.
        prompt_eval_count: Total number of tokens across all inputs.
        raw: The full, unprocessed JSON response from the server.
    """

    model: str
    embeddings: list[list[float]] | None = None
    scores: list[float] | None = None
    total_duration_ns: int = 0
    load_duration_ns: int = 0
    prompt_eval_count: int = 0
    raw: dict[str, Any] | None = None


@dataclass
class ModelDetails:
    """Format and architecture metadata for a model.

    Attributes:
        format: Serialization format (e.g. ``"safetensors"``).
        family: Primary task family (e.g. ``"text-generation"``).
        families: All task families the model belongs to.
        parameter_size: Human-readable parameter count (e.g. ``"7B"``).
        quantization_level: Quantization scheme (e.g. ``"AWQ"``, ``"None"``).
    """

    format: str = ""
    family: str = ""
    families: list[str] = field(default_factory=list)
    parameter_size: str | None = None
    quantization_level: str | None = None


@dataclass
class ShowResponse:
    """Detailed information about a single model.

    Attributes:
        modified_at: ISO-8601 timestamp of last modification.
        details: Architecture and format metadata.
        capabilities: Supported capabilities (e.g. ``["completion", "vision"]``).
        model_info: Raw key-value model metadata from the config.
        parameters: Default parameter string (e.g. ``"temperature 0.7"``).
        license: License information.
        template: Chat template string, if any.
        raw: The full, unprocessed JSON response from the server.
    """

    modified_at: str = ""
    details: ModelDetails = field(default_factory=ModelDetails)
    capabilities: list[str] = field(default_factory=list)
    model_info: dict[str, Any] = field(default_factory=dict)
    parameters: str | None = None
    license: str | None = None
    template: str | None = None
    raw: dict[str, Any] | None = None


# ===================================================================
# Helpers
# ===================================================================


def _parse_response(data: dict[str, Any], model_fallback: str, *, is_chat: bool) -> Response:
    """Build a :class:`Response` from a non-streaming JSON payload.

    Args:
        data: Decoded JSON body from the server.
        model_fallback: Model name to use when the response omits it.
        is_chat: If ``True``, extract content from ``message.content``;
            otherwise from the top-level ``response`` field.

    Returns:
        A fully populated :class:`Response`.
    """
    if is_chat:
        content = data.get("message", {}).get("content", "")
    else:
        content = data.get("response", "")

    return Response(
        content=content,
        model=data.get("model", model_fallback),
        thinking=data.get("thinking"),
        done=data.get("done", True),
        done_reason=data.get("done_reason"),
        total_duration_ns=data.get("total_duration", 0),
        load_duration_ns=data.get("load_duration", 0),
        prompt_eval_count=data.get("prompt_eval_count", 0),
        eval_count=data.get("eval_count", 0),
        eval_duration_ns=data.get("eval_duration", 0),
        raw=data,
    )


def _parse_stream_chunk(data: dict[str, Any], model_fallback: str, *, is_chat: bool) -> Response:
    """Build a :class:`Response` from a single streaming JSON chunk.

    The final chunk in a stream carries aggregate metrics; intermediate chunks
    contain partial content only.
    """
    if is_chat:
        content = data.get("message", {}).get("content", "")
    else:
        content = data.get("response", "")

    return Response(
        content=content,
        model=data.get("model", model_fallback),
        thinking=data.get("thinking"),
        done=data.get("done", False),
        done_reason=data.get("done_reason"),
        total_duration_ns=data.get("total_duration", 0),
        load_duration_ns=data.get("load_duration", 0),
        prompt_eval_count=data.get("prompt_eval_count", 0),
        eval_count=data.get("eval_count", 0),
        eval_duration_ns=data.get("eval_duration", 0),
        raw=data,
    )


def _parse_model_details(data: dict[str, Any]) -> ModelDetails:
    """Extract a :class:`ModelDetails` from a raw details dict."""
    return ModelDetails(
        format=data.get("format", ""),
        family=data.get("family", ""),
        families=data.get("families") or [],
        parameter_size=data.get("parameter_size"),
        quantization_level=data.get("quantization_level"),
    )


# ===================================================================
# Client
# ===================================================================
class CudaraClient:
    """Synchronous, thread-safe client for the Cudara inference server.

    Args:
        base_url: Root URL of the Cudara server (default ``http://localhost:8000``).
        timeout: Default request timeout in seconds (default ``300.0``).

    The client wraps every public endpoint of the Cudara API and returns typed
    dataclass objects.  It can optionally be used as a context manager::

        with CudaraClient() as c:
            print(c.version())
    """

    def __init__(self, base_url: str = "http://localhost:8000", timeout: float = 300.0) -> None:
        self.base_url = base_url.rstrip("/")
        self._client = httpx.Client(timeout=timeout)
        self._lock = threading.Lock()

    # ------------------------------------------------------------------
    # Context manager
    # ------------------------------------------------------------------

    def __enter__(self) -> "CudaraClient":
        """Enter the runtime context and return the client instance."""
        return self

    def __exit__(self, *exc: object) -> None:
        """Exit the runtime context and close the underlying connection pool."""
        self.close()

    # ------------------------------------------------------------------
    # Internal helpers
    # ------------------------------------------------------------------

    def _encode_file(self, file_path: Union[str, Path]) -> str:
        """Read a binary file and return its contents as a base64 string.

        Args:
            file_path: Path to the file on disk.

        Returns:
            A single-line base64-encoded string.
        """
        with open(file_path, "rb") as f:
            return base64.b64encode(f.read()).decode("utf-8")

    def _request(self, method: str, endpoint: str, **kwargs: Any) -> dict[str, Any]:
        """Execute an HTTP request and return the decoded JSON body.

        Args:
            method: HTTP method (``GET``, ``POST``, ``DELETE``, …).
            endpoint: Server path (e.g. ``/api/tags``).
            **kwargs: Forwarded to :pymeth:`httpx.Client.request`.

        Returns:
            Decoded JSON response as a dictionary.

        Raises:
            httpx.HTTPStatusError: If the server returns a non-2xx status.
        """
        url = f"{self.base_url}{endpoint}"
        resp = self._client.request(method, url, **kwargs)
        resp.raise_for_status()
        return cast(dict[str, Any], resp.json())

    # ------------------------------------------------------------------
    # Generation endpoints
    # ------------------------------------------------------------------

    def generate(
        self,
        model: str,
        prompt: str,
        *,
        system: str | None = None,
        suffix: str | None = None,
        images: list[str] | None = None,
        format: Union[str, dict[str, Any]] | None = None,
        stream: bool = False,
        think: Union[bool, Literal["high", "medium", "low"]] | None = None,
        raw: bool | None = None,
        keep_alive: Union[str, int] | None = None,
        options: dict[str, Any] | None = None,
        logprobs: bool | None = None,
        top_logprobs: int | None = None,
    ) -> Union[Response, Iterator[Response]]:
        """Generate a completion for a single prompt.

        Args:
            model: Name of the model to use.
            prompt: The input prompt.
            system: Optional system prompt prepended to the conversation.
            suffix: Suffix text for fill-in-the-middle generation.
            images: List of base64-encoded images to include.
            format: Output format constraint (``"json"`` or a JSON schema dict).
            stream: If ``True``, return an iterator of partial responses.
            think: Enable chain-of-thought output (``True``, or a budget level).
            raw: If ``True``, skip chat-template wrapping on the server.
            keep_alive: Duration to keep the model loaded (e.g. ``"5m"``, ``0``, ``-1``).
            options: Runtime generation options (temperature, top_k, etc.).
            logprobs: If ``True``, include log-probabilities in the response.
            top_logprobs: Number of top log-probabilities per token (1–20).

        Returns:
            A :class:`Response` (non-streaming) or an ``Iterator[Response]``
            (streaming).
        """
        payload: dict[str, Any] = {"model": model, "prompt": prompt, "stream": stream}
        if system is not None:
            payload["system"] = system
        if suffix is not None:
            payload["suffix"] = suffix
        if images is not None:
            payload["images"] = images
        if format is not None:
            payload["format"] = format
        if think is not None:
            payload["think"] = think
        if raw is not None:
            payload["raw"] = raw
        if keep_alive is not None:
            payload["keep_alive"] = keep_alive
        if options is not None:
            payload["options"] = options
        if logprobs is not None:
            payload["logprobs"] = logprobs
        if top_logprobs is not None:
            payload["top_logprobs"] = top_logprobs

        if stream:
            return self._stream_generate(payload, model)

        data = self._request("POST", "/api/generate", json=payload)
        return _parse_response(data, model, is_chat=False)

    def _stream_generate(self, payload: dict[str, Any], model: str) -> Iterator[Response]:
        """Yield partial :class:`Response` objects from a streaming generate call."""
        with (
            self._lock,
            self._client.stream("POST", f"{self.base_url}/api/generate", json=payload) as r,
        ):
            for line in r.iter_lines():
                if not line:
                    continue
                data = json.loads(line)
                yield _parse_stream_chunk(data, model, is_chat=False)

    def chat(
        self,
        model: str,
        messages: Union[str, Sequence[Message], Sequence[dict[str, Any]]],
        *,
        format: Union[str, dict[str, Any]] | None = None,
        stream: bool = False,
        think: Union[bool, Literal["high", "medium", "low"]] | None = None,
        keep_alive: Union[str, int] | None = None,
        options: dict[str, Any] | None = None,
        tools: list[dict[str, Any]] | None = None,
        logprobs: bool | None = None,
        top_logprobs: int | None = None,
    ) -> Union[Response, Iterator[Response]]:
        """Generate the next message in a chat conversation.

        Args:
            model: Name of the model to use.
            messages: Either a plain string (wrapped as a single user message), a
                sequence of :class:`Message` objects, or a sequence of raw dicts.
            format: Output format constraint (``"json"`` or a JSON schema dict).
            stream: If ``True``, return an iterator of partial responses.
            think: Enable chain-of-thought output.
            keep_alive: Duration to keep the model loaded.
            options: Runtime generation options.
            tools: List of tool/function definitions available to the model.
            logprobs: If ``True``, include log-probabilities in the response.
            top_logprobs: Number of top log-probabilities per token (1–20).

        Returns:
            A :class:`Response` (non-streaming) or an ``Iterator[Response]``
            (streaming).
        """
        if isinstance(messages, str):
            msgs: list[dict[str, Any]] = [{"role": "user", "content": messages}]
        else:
            msgs = [m.to_dict() if isinstance(m, Message) else dict(m) for m in messages]

        payload: dict[str, Any] = {"model": model, "messages": msgs, "stream": stream}
        if format is not None:
            payload["format"] = format
        if think is not None:
            payload["think"] = think
        if keep_alive is not None:
            payload["keep_alive"] = keep_alive
        if options is not None:
            payload["options"] = options
        if tools is not None:
            payload["tools"] = tools
        if logprobs is not None:
            payload["logprobs"] = logprobs
        if top_logprobs is not None:
            payload["top_logprobs"] = top_logprobs

        if stream:
            return self._stream_chat(payload, model)

        data = self._request("POST", "/api/chat", json=payload)
        return _parse_response(data, model, is_chat=True)

    def _stream_chat(self, payload: dict[str, Any], model: str) -> Iterator[Response]:
        """Yield partial :class:`Response` objects from a streaming chat call."""
        with (
            self._lock,
            self._client.stream("POST", f"{self.base_url}/api/chat", json=payload) as r,
        ):
            for line in r.iter_lines():
                if not line:
                    continue
                data = json.loads(line)
                yield _parse_stream_chunk(data, model, is_chat=True)

    # ------------------------------------------------------------------
    # Embeddings
    # ------------------------------------------------------------------

    def embed(
        self,
        model: str,
        input: Union[str, list[str]],
        *,
        truncate: bool | None = None,
        dimensions: int | None = None,
        keep_alive: Union[str, int] | None = None,
        options: dict[str, Any] | None = None,
    ) -> EmbedResponse:
        """Generate vector embeddings for one or more texts.

        Args:
            model: Name of the embedding model.
            input: A single string or list of strings to embed.
            truncate: Truncate inputs that exceed the model's context window
                (server default is ``True``).
            dimensions: Reduce output embeddings to this many dimensions.
            keep_alive: Duration to keep the model loaded.
            options: Runtime options. Pass ``{"is_rerank": True}`` with a list
                input (query first, then documents) to perform reranking instead.

        Returns:
            An :class:`EmbedResponse` containing either ``embeddings`` or
            ``scores`` (for reranking).
        """
        payload: dict[str, Any] = {"model": model, "input": input}
        if truncate is not None:
            payload["truncate"] = truncate
        if dimensions is not None:
            payload["dimensions"] = dimensions
        if keep_alive is not None:
            payload["keep_alive"] = keep_alive
        if options is not None:
            payload["options"] = options

        data = self._request("POST", "/api/embed", json=payload)
        return EmbedResponse(
            model=data.get("model", model),
            embeddings=data.get("embeddings"),
            scores=data.get("scores"),
            total_duration_ns=data.get("total_duration", 0),
            load_duration_ns=data.get("load_duration", 0),
            prompt_eval_count=data.get("prompt_eval_count", 0),
            raw=data,
        )

    # ------------------------------------------------------------------
    # Audio transcription
    # ------------------------------------------------------------------

    def transcribe(
        self,
        model: str,
        audio_path: Union[str, Path],
        *,
        prompt: str = "Transcribe this audio.",
    ) -> Response:
        """Transcribe an audio file using a speech-recognition model.

        Internally this sends the audio as base64 through the ``/api/generate``
        endpoint with the ``is_audio`` option flag.

        Args:
            model: Name of the ASR model.
            audio_path: Path to the audio file (WAV, MP3, OGG, M4A, …).
            prompt: Optional prompt/instruction for the ASR model.

        Returns:
            A :class:`Response` whose ``content`` contains the transcribed text.
        """
        b64_audio = self._encode_file(audio_path)
        return cast(
            Response,
            self.generate(
                model=model,
                prompt=prompt,
                images=[b64_audio],
                options={"is_audio": True},
                stream=False,
            ),
        )

    # ------------------------------------------------------------------
    # Model management
    # ------------------------------------------------------------------

    def tags(self) -> dict[str, Any]:
        """List all models available in the local registry.

        Returns:
            A dict with a ``models`` key containing a list of model summaries,
            each with ``name``, ``model``, ``size``, ``digest``, ``modified_at``,
            and ``details``.
        """
        return self._request("GET", "/api/tags")

    def show(self, model: str, *, verbose: bool = False) -> ShowResponse:
        """Retrieve detailed information about a specific model.

        Args:
            model: Name of the model to inspect.
            verbose: Request additional verbose fields from the server.

        Returns:
            A :class:`ShowResponse` with capabilities, license, and architecture
            metadata.
        """
        payload: dict[str, Any] = {"model": model}
        if verbose:
            payload["verbose"] = True

        data = self._request("POST", "/api/show", json=payload)
        details_raw = data.get("details", {})

        return ShowResponse(
            modified_at=data.get("modified_at", ""),
            details=_parse_model_details(details_raw),
            capabilities=data.get("capabilities", []),
            model_info=data.get("model_info", {}),
            parameters=data.get("parameters"),
            license=data.get("license"),
            template=data.get("template"),
            raw=data,
        )

    def pull(
        self,
        model: str,
        *,
        stream: bool = True,
        insecure: bool = False,
    ) -> Union[dict[str, Any], Iterator[dict[str, Any]]]:
        """Download a model to the server's local registry.

        Args:
            model: Name of the model to pull.
            stream: If ``True`` (default), return an iterator of progress events.
            insecure: Allow insecure connections during download.

        Returns:
            A single status dict (non-streaming) or an ``Iterator[dict]`` of
            progress events (streaming).
        """
        payload: dict[str, Any] = {"model": model, "stream": stream}
        if insecure:
            payload["insecure"] = True

        if not stream:
            return self._request("POST", "/api/pull", json=payload)

        def stream_gen() -> Iterator[dict[str, Any]]:
            with self._client.stream("POST", f"{self.base_url}/api/pull", json=payload) as r:
                for line in r.iter_lines():
                    if line:
                        yield cast(dict[str, Any], json.loads(line))

        return stream_gen()

    def delete(self, model: str) -> dict[str, Any]:
        """Delete a model from the server's local registry.

        Args:
            model: Name of the model to remove.

        Returns:
            A dict with a ``status`` key (e.g. ``{"status": "success"}``).
        """
        return self._request("DELETE", "/api/delete", json={"model": model})

    # ------------------------------------------------------------------
    # System / introspection
    # ------------------------------------------------------------------

    def ps(self) -> dict[str, Any]:
        """List models currently loaded in GPU/CPU memory.

        Returns:
            A dict with a ``models`` key containing details about each loaded
            model, including VRAM usage and expiration time.
        """
        return self._request("GET", "/api/ps")

    def version(self) -> str:
        """Return the server's version string.

        Returns:
            The version (e.g. ``"0.0.1"``).
        """
        data: dict[str, Any] = self._request("GET", "/api/version")
        return str(data.get("version", "unknown"))

    def health(self) -> bool:
        """Check whether the server is alive and responsive.

        Returns:
            ``True`` if the server returned a healthy status, ``False`` otherwise.
        """
        try:
            data = self._request("GET", "/health")
            return data.get("status") == "ok"
        except (httpx.HTTPError, Exception):
            return False

    # ------------------------------------------------------------------
    # Lifecycle
    # ------------------------------------------------------------------

    def close(self) -> None:
        """Close the underlying HTTP connection pool.

        Safe to call multiple times.  After calling ``close()`` any further
        requests will raise an error.
        """
        self._client.close()
