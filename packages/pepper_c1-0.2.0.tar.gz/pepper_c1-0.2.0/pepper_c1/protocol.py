"""Binary protocol framing for Eccel Peeper C1.

Frame layout:
  [0xF5] [LEN_L] [LEN_H] [LEN_L^0xFF] [LEN_H^0xFF] [PAYLOAD...] [CRC_L] [CRC_H]

LEN = len(PAYLOAD) + 2  (includes the 2 CRC bytes)
CRC = CCITT-16 over PAYLOAD only, transmitted little-endian.
"""

from __future__ import annotations

from enum import auto, Enum
from .exceptions import ProtocolError

STX = 0xF5

# CCITT-16 lookup table (ported from ccittcrc.h)
_CCITT_TABLE = [
    0x0000, 0x1021, 0x2042, 0x3063, 0x4084, 0x50A5, 0x60C6, 0x70E7,
    0x8108, 0x9129, 0xA14A, 0xB16B, 0xC18C, 0xD1AD, 0xE1CE, 0xF1EF,
    0x1231, 0x0210, 0x3273, 0x2252, 0x52B5, 0x4294, 0x72F7, 0x62D6,
    0x9339, 0x8318, 0xB37B, 0xA35A, 0xD3BD, 0xC39C, 0xF3FF, 0xE3DE,
    0x2462, 0x3443, 0x0420, 0x1401, 0x64E6, 0x74C7, 0x44A4, 0x5485,
    0xA56A, 0xB54B, 0x8528, 0x9509, 0xE5EE, 0xF5CF, 0xC5AC, 0xD58D,
    0x3653, 0x2672, 0x1611, 0x0630, 0x76D7, 0x66F6, 0x5695, 0x46B4,
    0xB75B, 0xA77A, 0x9719, 0x8738, 0xF7DF, 0xE7FE, 0xD79D, 0xC7BC,
    0x48C4, 0x58E5, 0x6886, 0x78A7, 0x0840, 0x1861, 0x2802, 0x3823,
    0xC9CC, 0xD9ED, 0xE98E, 0xF9AF, 0x8948, 0x9969, 0xA90A, 0xB92B,
    0x5AF5, 0x4AD4, 0x7AB7, 0x6A96, 0x1A71, 0x0A50, 0x3A33, 0x2A12,
    0xDBFD, 0xCBDC, 0xFBBF, 0xEB9E, 0x9B79, 0x8B58, 0xBB3B, 0xAB1A,
    0x6CA6, 0x7C87, 0x4CE4, 0x5CC5, 0x2C22, 0x3C03, 0x0C60, 0x1C41,
    0xEDAE, 0xFD8F, 0xCDEC, 0xDDCD, 0xAD2A, 0xBD0B, 0x8D68, 0x9D49,
    0x7E97, 0x6EB6, 0x5ED5, 0x4EF4, 0x3E13, 0x2E32, 0x1E51, 0x0E70,
    0xFF9F, 0xEFBE, 0xDFDD, 0xCFFC, 0xBF1B, 0xAF3A, 0x9F59, 0x8F78,
    0x9188, 0x81A9, 0xB1CA, 0xA1EB, 0xD10C, 0xC12D, 0xF14E, 0xE16F,
    0x1080, 0x00A1, 0x30C2, 0x20E3, 0x5004, 0x4025, 0x7046, 0x6067,
    0x83B9, 0x9398, 0xA3FB, 0xB3DA, 0xC33D, 0xD31C, 0xE37F, 0xF35E,
    0x02B1, 0x1290, 0x22F3, 0x32D2, 0x4235, 0x5214, 0x6277, 0x7256,
    0xB5EA, 0xA5CB, 0x95A8, 0x8589, 0xF56E, 0xE54F, 0xD52C, 0xC50D,
    0x34E2, 0x24C3, 0x14A0, 0x0481, 0x7466, 0x6447, 0x5424, 0x4405,
    0xA7DB, 0xB7FA, 0x8799, 0x97B8, 0xE75F, 0xF77E, 0xC71D, 0xD73C,
    0x26D3, 0x36F2, 0x0691, 0x16B0, 0x6657, 0x7676, 0x4615, 0x5634,
    0xD94C, 0xC96D, 0xF90E, 0xE92F, 0x99C8, 0x89E9, 0xB98A, 0xA9AB,
    0x5844, 0x4865, 0x7806, 0x6827, 0x18C0, 0x08E1, 0x3882, 0x28A3,
    0xCB7D, 0xDB5C, 0xEB3F, 0xFB1E, 0x8BF9, 0x9BD8, 0xABBB, 0xBB9A,
    0x4A75, 0x5A54, 0x6A37, 0x7A16, 0x0AF1, 0x1AD0, 0x2AB3, 0x3A92,
    0xFD2E, 0xED0F, 0xDD6C, 0xCD4D, 0xBDAA, 0xAD8B, 0x9DE8, 0x8DC9,
    0x7C26, 0x6C07, 0x5C64, 0x4C45, 0x3CA2, 0x2C83, 0x1CE0, 0x0CC1,
    0xEF1F, 0xFF3E, 0xCF5D, 0xDF7C, 0xAF9B, 0xBFBA, 0x8FD9, 0x9FF8,
    0x6E17, 0x7E36, 0x4E55, 0x5E74, 0x2E93, 0x3EB2, 0x0ED1, 0x1EF0,
]


def calc_crc(data: bytes) -> int:
    """Compute CCITT-16 CRC (initial value 0xFFFF)."""
    crc = 0xFFFF
    for byte in data:
        temp = ((crc >> 8) ^ byte) & 0xFF
        crc = _CCITT_TABLE[temp] ^ ((crc << 8) & 0xFFFF)
    return crc


def build_frame(payload: bytes) -> bytes:
    """Wrap payload in a protocol frame (STX + length + XOR-check + payload + CRC)."""
    length = len(payload) + 2  # +2 for CRC bytes
    len_l = length & 0xFF
    len_h = (length >> 8) & 0xFF
    crc = calc_crc(payload)
    return bytes([
        STX,
        len_l, len_h,
        len_l ^ 0xFF, len_h ^ 0xFF,
        *payload,
        crc & 0xFF, (crc >> 8) & 0xFF,
    ])


def parse_frame(raw: bytes) -> bytes:
    """Validate a complete raw frame and return the payload (without CRC).

    Raises ProtocolError on any validation failure.
    The caller is responsible for passing a complete frame starting with STX.
    """
    if len(raw) < 7:
        raise ProtocolError("Frame too short")
    if raw[0] != STX:
        raise ProtocolError(f"Bad STX: 0x{raw[0]:02X}")
    len_l, len_h = raw[1], raw[2]
    if raw[3] != (len_l ^ 0xFF) or raw[4] != (len_h ^ 0xFF):
        raise ProtocolError("Length XOR check failed")
    declared_len = len_l | (len_h << 8)
    if len(raw) != 5 + declared_len:
        raise ProtocolError(f"Frame length mismatch: expected {5 + declared_len}, got {len(raw)}")
    payload = raw[5: 5 + declared_len - 2]
    crc_received = raw[-2] | (raw[-1] << 8)
    crc_calc = calc_crc(payload)
    if crc_calc != crc_received:
        raise ProtocolError(f"CRC mismatch: calculated 0x{crc_calc:04X}, received 0x{crc_received:04X}")
    return payload


class _State(Enum):
    WAIT4STX = auto()
    WAIT4LEN = auto()
    RECEIVING = auto()


class FrameParser:
    """Stateful incremental frame parser — mirrors the C implementation exactly."""

    def __init__(self) -> None:
        self.reset()

    def reset(self) -> None:
        self._state = _State.WAIT4STX
        self._buf: list[int] = []
        self._req_len = 0

    def feed(self, data: bytes) -> list[bytes]:
        """Feed bytes into the parser; returns a list of complete payload bytes objects."""
        completed: list[bytes] = []
        for byte in data:
            if self._state is _State.WAIT4STX:
                if byte == STX:
                    self._buf = []
                    self._state = _State.WAIT4LEN

            elif self._state is _State.WAIT4LEN:
                self._buf.append(byte)
                if len(self._buf) == 4:
                    len_l, len_h, chk_l, chk_h = self._buf
                    if len_l == (chk_l ^ 0xFF) and len_h == (chk_h ^ 0xFF):
                        self._req_len = len_l | (len_h << 8)
                        self._buf = []
                        self._state = _State.RECEIVING
                    else:
                        self._state = _State.WAIT4STX

            elif self._state is _State.RECEIVING:
                self._buf.append(byte)
                if len(self._buf) == self._req_len:
                    raw_payload = bytes(self._buf)
                    self._state = _State.WAIT4STX
                    payload_data = raw_payload[:-2]
                    crc_received = raw_payload[-2] | (raw_payload[-1] << 8)
                    if calc_crc(payload_data) == crc_received:
                        completed.append(payload_data)
        return completed
