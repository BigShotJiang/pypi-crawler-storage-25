class ProtocolError(Exception):
    """Malformed frame, bad CRC, or length mismatch."""


class TransportError(Exception):
    """Connection or I/O failure on UART or TCP transport."""


class CommandError(Exception):
    """Device responded with CMD_ERROR (0xFF)."""

    def __init__(self, cmd: int, error_code: int):
        self.cmd = cmd
        self.error_code = error_code
        super().__init__(f"Command 0x{cmd:02X} failed with error code 0x{error_code:04X}")
