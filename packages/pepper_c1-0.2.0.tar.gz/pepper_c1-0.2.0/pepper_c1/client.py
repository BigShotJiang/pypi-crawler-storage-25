"""High-level client for the Eccel Peeper C1 RFID reader."""

from __future__ import annotations

from typing import List

from .commands import Command, PollingEventFormat
from .exceptions import CommandError, ProtocolError
from .protocol import build_frame
from .transport import Transport


class PepperC1:
    """Driver for the Eccel Peeper C1 RFID reader.

    Usage::

        from pepper_c1 import PepperC1, UARTTransport
        with PepperC1(UARTTransport('/dev/ttyUSB0')) as reader:
            print(reader.get_version())
            print(reader.get_uid().hex())
    """

    def __init__(self, transport: Transport, response_timeout: float = 2.0) -> None:
        self._transport = transport
        self._timeout = response_timeout
        self.async_events: List[bytes] = []

    # ------------------------------------------------------------------
    # Low-level interface
    # ------------------------------------------------------------------

    def send_command(self, cmd: Command, data: bytes = b"") -> bytes:
        """Send a command frame and return the response payload (without CMD_ACK byte).

        Raises CommandError if the device responds with CMD_ERROR.
        Async events received while waiting are stored in self.async_events.
        """
        payload = bytes([cmd]) + data
        self._transport.write(build_frame(payload))
        return self._wait_response(cmd)

    def _wait_response(self, sent_cmd: Command) -> bytes:
        from .protocol import FrameParser
        parser = FrameParser()
        import time
        deadline = time.monotonic() + self._timeout
        buf = b""

        while time.monotonic() < deadline:
            chunk = self._transport._read_chunk(256)
            if not chunk:
                continue
            completed = parser.feed(chunk)
            for payload in completed:
                if not payload:
                    continue
                resp_byte = payload[0]
                if resp_byte == Command.ASYNC:
                    self.async_events.append(payload[1:])
                elif resp_byte == Command.ERROR:
                    failed_cmd = payload[1] if len(payload) > 1 else 0xFF
                    error_code = 0
                    if len(payload) >= 4:
                        error_code = payload[2] | (payload[3] << 8)
                    raise CommandError(failed_cmd, error_code)
                elif resp_byte == Command.ACK:
                    return payload[2:]  # skip ACK byte and echoed command byte
        raise TimeoutError(f"No response to command 0x{sent_cmd:02X} within {self._timeout}s")

    # ------------------------------------------------------------------
    # General commands
    # ------------------------------------------------------------------

    def get_version(self) -> str:
        """Return firmware version string."""
        data = self.send_command(Command.GET_VERSION)
        return data.decode("ascii", errors="replace").rstrip("\x00")

    def get_device_name(self) -> str:
        """Return the device name from the protocol general config (PROTO_CONFIG subcommand 0x00).

        Response layout: [subcmd, mdns_flag, udp_flag, name_len, name_bytes...]
        """
        data = self.send_command(Command.PROTO_CONFIG, bytes([0x00]))
        if len(data) < 4:
            raise ProtocolError(f"PROTO_CONFIG response too short: {len(data)} bytes")
        name_len = data[3]
        if len(data) < 4 + name_len:
            raise ProtocolError(
                f"PROTO_CONFIG name field truncated: expected {name_len} bytes, got {len(data) - 4}"
            )
        return data[4:4 + name_len].decode("utf-8", errors="replace")

    def get_tag_count(self) -> int:
        """Return number of tags in the RF field."""
        data = self.send_command(Command.GET_TAG_COUNT)
        return data[0] if data else 0

    def get_uid(self, tag_index: int = 0) -> bytes:
        """Return UID info for tag at tag_index (0-based).

        Response payload: [type, param, uid_bytes...]
        """
        return self.send_command(Command.GET_UID, bytes([tag_index]))

    def activate_tag(self, tag_index: int = 0) -> bytes:
        """Activate the tag at tag_index; returns response payload."""
        return self.send_command(Command.ACTIVATE_TAG, bytes([tag_index]))

    def halt(self) -> None:
        """Halt the active tag."""
        self.send_command(Command.HALT)

    def set_polling(self, enable: bool) -> None:
        """Enable or disable automatic tag polling.

        Args:
            enable: True to start polling, False to stop.
        """
        self.send_command(Command.SET_POLLING, bytes([1 if enable else 0]))

    def polling_setup_timeout(self, timeout_ms: int) -> None:
        """Set the inter-poll timeout.

        Args:
            timeout_ms: Timeout in milliseconds (0–65535).
        """
        self.send_command(Command.POLLING_SETUP,
                          bytes([0x03, timeout_ms & 0xFF, (timeout_ms >> 8) & 0xFF]))

    def polling_setup_async(
        self,
        known: bool,
        frame_format: PollingEventFormat | int = PollingEventFormat.NONE,
    ) -> None:
        """Configure async UID event packets sent by the reader during polling.

        Args:
            known: True to configure events for tags in the whitelist (known),
                   False for tags outside the whitelist (unknown).
            frame_format: Output format for the async UID frame.
                          Use PollingEventFormat.NONE (0) to disable.
        """
        known_flag = 0x00 if known else 0x01
        self.send_command(Command.POLLING_SETUP, bytes([0x06, known_flag, int(frame_format)]))

    def reboot(self) -> None:
        """Reboot the reader module."""
        self.send_command(Command.REBOOT)

    def set_active_antenna(self, antenna: int) -> None:
        """Select the active antenna (1–8).

        Args:
            antenna: Antenna number in the range 1–8.
        """
        if not 1 <= antenna <= 8:
            raise ValueError(f"Antenna number must be 1–8, got {antenna}")
        self.send_command(Command.SET_ACTIVE_ANTENNA, bytes([antenna]))

    # ------------------------------------------------------------------
    # Key management
    # ------------------------------------------------------------------

    def set_key(self, key_slot: int, key_type: int, key_data: bytes) -> None:
        """Store a key in the reader's key slot.

        Args:
            key_slot: Key slot index.
            key_type: One of the KEY_TYPE_* constants from pepper_c1.commands.
            key_data: Raw key bytes.
        """
        data = bytes([key_slot, key_type]) + key_data
        self.send_command(Command.SET_KEY, data)

    def save_keys(self) -> None:
        """Persist stored keys to non-volatile memory."""
        self.send_command(Command.SAVE_KEYS)

    # ------------------------------------------------------------------
    # MIFARE Classic
    # ------------------------------------------------------------------

    def mf_read_block(self, block: int, count: int = 1,
                      auth_param: int = 0x0A, key_no: int = 0) -> bytes:
        """Read one or more 16-byte MIFARE Classic blocks.

        Args:
            block:      First block number.
            count:      Number of consecutive blocks to read.
            auth_param: Firmware authentication parameter (empirically 0x0A).
            key_no:     Key slot index stored via set_key().
        """
        payload = bytes([block, count, auth_param, key_no])
        data = self.send_command(Command.MF_READ_BLOCK, payload)
        expected = 16 * count
        if len(data) != expected:
            raise ProtocolError(f"Expected {expected} bytes for MF block(s), got {len(data)}")
        return data

    def mf_write_block(self, block: int, data: bytes,
                       count: int = 1, auth_param: int = 0x0A, key_no: int = 0) -> None:
        """Write one or more 16-byte MIFARE Classic blocks.

        Args:
            block:      First block number.
            data:       Raw bytes; must be exactly count*16 bytes.
            count:      Number of consecutive blocks to write.
            auth_param: Firmware authentication parameter (empirically 0x0A).
            key_no:     Key slot index stored via set_key().
        """
        if len(data) != 16 * count:
            raise ValueError(f"MIFARE Classic write expects {16 * count} bytes, got {len(data)}")
        payload = bytes([block, count, auth_param, key_no]) + data
        self.send_command(Command.MF_WRITE_BLOCK, payload)

    def mf_read_value(self, block: int, auth_param: int = 0x0A, key_no: int = 0) -> int:
        """Read a MIFARE Classic value block; returns a signed 32-bit integer."""
        data = self.send_command(Command.MF_READ_VALUE, bytes([block, auth_param, key_no]))
        return int.from_bytes(data[:4], "little", signed=True)

    def mf_write_value(self, block: int, value: int,
                       auth_param: int = 0x0A, key_no: int = 0) -> None:
        """Write a MIFARE Classic value block."""
        payload = bytes([block, auth_param, key_no]) + value.to_bytes(4, "little", signed=True)
        self.send_command(Command.MF_WRITE_VALUE, payload)

    def mf_increment(self, block: int, delta: int,
                     auth_param: int = 0x0A, key_no: int = 0) -> None:
        """Increment a MIFARE Classic value block."""
        data = bytes([block, auth_param, key_no]) + delta.to_bytes(4, "little", signed=False)
        self.send_command(Command.MF_INCREMENT, data)

    # ------------------------------------------------------------------
    # MIFARE Ultralight
    # ------------------------------------------------------------------

    def mfu_read_page(self, page: int, count: int = 1) -> bytes:
        """Read one or more 4-byte MIFARE Ultralight pages."""
        data = self.send_command(Command.MFU_READ_PAGE, bytes([page, count]))
        return data[:4 * count]

    def mfu_write_page(self, page: int, data: bytes, count: int = 1) -> None:
        """Write one or more 4-byte MIFARE Ultralight pages."""
        if len(data) != 4 * count:
            raise ValueError(f"Ultralight write expects {4 * count} bytes, got {len(data)}")
        self.send_command(Command.MFU_WRITE_PAGE, bytes([page, count]) + data)

    def mfu_read_counter(self, counter: int) -> int:
        """Read a 3-byte NFC counter value."""
        data = self.send_command(Command.MFU_READ_COUNTER, bytes([counter]))
        return int.from_bytes(data[:3], "little")

    def mfu_increment_counter(self, counter: int, delta: int) -> None:
        """Increment an NFC counter."""
        data = bytes([counter]) + delta.to_bytes(3, "little")
        self.send_command(Command.MFU_INCREMENT_COUNTER, data)

    def mfu_passwd_auth(self, password: bytes, pack: bytes = b"\x00\x00") -> bytes:
        """Authenticate with a 4-byte password; returns 2-byte PACK."""
        if len(password) != 4:
            raise ValueError("Password must be 4 bytes")
        return self.send_command(Command.MFU_PASSWD_AUTH, password + pack)

    # ------------------------------------------------------------------
    # MIFARE DESFire
    # ------------------------------------------------------------------

    def mfdf_select_app(self, aid: bytes) -> None:
        """Select a DESFire application by its 3-byte AID."""
        if len(aid) != 3:
            raise ValueError("AID must be 3 bytes")
        self.send_command(Command.MFDF_SELECT_APP, aid)

    def mfdf_get_app_ids(self) -> list[bytes]:
        """Return list of 3-byte AIDs present on the card."""
        data = self.send_command(Command.MFDF_APP_IDS)
        return [data[i:i + 3] for i in range(0, len(data), 3)]

    def mfdf_auth(self, key_no: int, key_slot: int = 0) -> None:
        """Authenticate with a DESFire key (3DES/DES) stored in reader key slot."""
        self.send_command(Command.MFDF_AUTH, bytes([key_no, key_slot, 0]))

    def mfdf_auth_aes(self, key_no: int, key_slot: int = 0) -> None:
        """Authenticate with a DESFire AES key stored in reader key slot."""
        self.send_command(Command.MFDF_AUTH_AES, bytes([key_no, key_slot, 0]))

    def mfdf_read_data(self, file_no: int, offset: int, length: int,
                       comm_mode: int = 0x00) -> bytes:
        """Read data from a DESFire standard/backup data file."""
        payload = (
            bytes([file_no])
            + offset.to_bytes(3, "little")
            + length.to_bytes(3, "little")
            + bytes([comm_mode])
        )
        return self.send_command(Command.MFDF_READ_DATA, payload)

    def mfdf_write_data(self, file_no: int, offset: int, data: bytes,
                        comm_mode: int = 0x00) -> None:
        """Write data to a DESFire standard/backup data file.

        Data length is derived from the frame size; no explicit length field is sent.
        """
        header = (
            bytes([file_no])
            + offset.to_bytes(3, "little")
            + bytes([comm_mode])
        )
        self.send_command(Command.MFDF_WRITE_DATA, header + data)

    def mfdf_get_value(self, file_no: int) -> int:
        """Read a DESFire value file; returns a signed 32-bit integer."""
        data = self.send_command(Command.MFDF_GET_VALUE, bytes([file_no]))
        return int.from_bytes(data[:4], "little", signed=True)

    def mfdf_commit_transaction(self) -> None:
        """Commit the current DESFire transaction."""
        self.send_command(Command.MFDF_COMMIT_TRANSACTION)

    def mfdf_abort_transaction(self) -> None:
        """Abort the current DESFire transaction."""
        self.send_command(Command.MFDF_ABORT_TRANSACTION)

    def mfdf_format(self) -> None:
        """Erase all applications and files from the card."""
        self.send_command(Command.MFDF_FORMAT)

    def mfdf_get_free_mem(self) -> int:
        """Return available free memory in bytes."""
        data = self.send_command(Command.MFDF_GET_FREEMEM)
        return int.from_bytes(data[:4], "little")

    def mfdf_card_version(self) -> bytes:
        """Return 28-byte card hardware/software version info."""
        return self.send_command(Command.MFDF_GET_VERSION)

    def mfdf_create_app(self, aid: bytes, key_settings: int, num_keys: int) -> None:
        """Create a new application (AID must be 3 bytes)."""
        if len(aid) != 3:
            raise ValueError("AID must be 3 bytes")
        self.send_command(Command.MFDF_CREATE_APP, aid + bytes([key_settings, num_keys]))

    def mfdf_delete_app(self, aid: bytes) -> None:
        """Delete an application by its 3-byte AID."""
        if len(aid) != 3:
            raise ValueError("AID must be 3 bytes")
        self.send_command(Command.MFDF_DELETE_APP, aid)

    def mfdf_create_data_file(self, file_no: int, access_rights: int,
                               size: int, backup: bool = False) -> None:
        """Create a standard or backup data file."""
        payload = bytes([
            file_no,
            access_rights & 0xFF, (access_rights >> 8) & 0xFF,
            size & 0xFF, (size >> 8) & 0xFF, (size >> 16) & 0xFF,
            1 if backup else 0,
        ])
        self.send_command(Command.MFDF_CREATE_DATA_FILE, payload)

    def mfdf_create_value_file(self, file_no: int, access_rights: int,
                                lower_limit: int, upper_limit: int,
                                init_value: int, limited_credit: bool = False) -> None:
        """Create a value file with given limits and initial value."""
        payload = (
            bytes([file_no, access_rights & 0xFF, (access_rights >> 8) & 0xFF])
            + lower_limit.to_bytes(4, "little", signed=True)
            + upper_limit.to_bytes(4, "little", signed=True)
            + init_value.to_bytes(4, "little", signed=True)
            + bytes([1 if limited_credit else 0, 0x01])
        )
        self.send_command(Command.MFDF_CREATE_VALUE_FILE, payload)

    def mfdf_credit(self, file_no: int, amount: int) -> None:
        """Credit a value file by amount (signed 32-bit)."""
        self.send_command(Command.MFDF_CREDIT,
                          bytes([file_no]) + amount.to_bytes(4, "little", signed=True))

    def mfdf_debit(self, file_no: int, amount: int) -> None:
        """Debit a value file by amount (signed 32-bit)."""
        self.send_command(Command.MFDF_DEBIT,
                          bytes([file_no]) + amount.to_bytes(4, "little", signed=True))

    def mfdf_create_record_file(self, file_no: int, access_rights: int,
                                 record_size: int, max_records: int,
                                 cyclic: bool = True) -> None:
        """Create a linear or cyclic record file."""
        payload = (
            bytes([file_no, access_rights & 0xFF, (access_rights >> 8) & 0xFF])
            + record_size.to_bytes(2, "little")
            + max_records.to_bytes(2, "little")
            + bytes([1 if cyclic else 0])
        )
        self.send_command(Command.MFDF_CREATE_RECORD_FILE, payload)

    def mfdf_write_record(self, file_no: int, data: bytes) -> None:
        """Append a record to a record file."""
        self.send_command(Command.MFDF_WRITE_RECORD, bytes([file_no]) + data)

    def mfdf_read_record(self, file_no: int, offset: int, record_size: int) -> bytes:
        """Read records from a record file starting at offset.

        record_size must match the file's configured record size.
        The firmware returns all records from offset onwards concatenated;
        slice [:record_size] to extract just the first one.
        """
        payload = (
            bytes([file_no])
            + offset.to_bytes(2, "little")
            + record_size.to_bytes(2, "little")
        )
        return self.send_command(Command.MFDF_READ_RECORD, payload)

    def mfdf_clear_records(self, file_no: int) -> None:
        """Clear all records in a record file."""
        self.send_command(Command.MFDF_CLEAR_RECORDS, bytes([file_no]))

    def mfdf_delete_file(self, file_no: int) -> None:
        """Delete a file from the selected application."""
        self.send_command(Command.MFDF_DELETE_FILE, bytes([file_no]))

    # ------------------------------------------------------------------
    # ICODE
    # ------------------------------------------------------------------

    def icode_inventory_start(self) -> bytes:
        """Start ICODE inventory; returns UID of first tag found."""
        return self.send_command(Command.ICODE_INVENTORY_START)

    def icode_read_block(self, block: int, count: int = 1) -> bytes:
        """Read one or more ICODE blocks (4 bytes each)."""
        return self.send_command(Command.ICODE_READ_BLOCK, bytes([block, count]))

    def icode_write_block(self, block: int, data: bytes, count: int = 1) -> None:
        """Write one or more 4-byte ICODE blocks."""
        if len(data) != 4 * count:
            raise ValueError(f"ICODE write expects {4 * count} bytes, got {len(data)}")
        self.send_command(Command.ICODE_WRITE_BLOCK, bytes([block, count]) + data)

    def icode_get_system_information(self) -> bytes:
        """Return ICODE system information."""
        return self.send_command(Command.ICODE_GET_SYSTEM_INFORMATION)

    # ------------------------------------------------------------------
    # Context manager
    # ------------------------------------------------------------------

    def __enter__(self) -> "PepperC1":
        return self

    def __exit__(self, *_: object) -> None:
        self._transport.close()

    def close(self) -> None:
        """Close the underlying transport."""
        self._transport.close()
