"""Transport layer abstraction for UART and TCP communication."""

from __future__ import annotations

import socket
import time
from abc import ABC, abstractmethod

from .exceptions import TransportError
from .protocol import FrameParser, STX


class Transport(ABC):
    """Abstract base for all transport backends."""

    @abstractmethod
    def write(self, data: bytes) -> None:
        """Send raw bytes to the device."""

    @abstractmethod
    def _read_chunk(self, n: int) -> bytes:
        """Read up to n bytes; may return fewer. Raises TransportError on failure."""

    def read_frame(self, timeout: float = 2.0) -> bytes:
        """Read bytes until a complete, valid frame payload is returned.

        Returns the payload (without CRC) of the first valid frame received.
        Raises TransportError on timeout or I/O error.
        """
        parser = FrameParser()
        deadline = time.monotonic() + timeout
        while time.monotonic() < deadline:
            chunk = self._read_chunk(256)
            if chunk:
                completed = parser.feed(chunk)
                if completed:
                    return completed[0]
        raise TransportError("Timeout waiting for response frame")

    @abstractmethod
    def close(self) -> None:
        """Release the underlying connection."""

    def __enter__(self) -> "Transport":
        return self

    def __exit__(self, *_: object) -> None:
        self.close()


class UARTTransport(Transport):
    """UART transport using pyserial."""

    def __init__(self, port: str, baudrate: int = 115200, timeout: float = 0.1,
                 post_open_delay: float = 0.0) -> None:
        try:
            import serial  # type: ignore[import]
        except ImportError as exc:
            raise ImportError("pyserial is required for UARTTransport: pip install pyserial") from exc
        try:
            self._serial = serial.Serial(
                port=None, baudrate=baudrate, timeout=timeout,
                dsrdtr=False, rtscts=False,
            )
            self._serial.dtr = False
            self._serial.rts = False
            self._serial.port = port
            self._serial.open()
            if post_open_delay > 0:
                time.sleep(post_open_delay)
                self._serial.reset_input_buffer()
        except serial.SerialException as exc:
            raise TransportError(f"Cannot open {port}: {exc}") from exc

    def write(self, data: bytes) -> None:
        try:
            self._serial.write(data)
        except Exception as exc:
            raise TransportError(f"UART write error: {exc}") from exc

    def _read_chunk(self, n: int) -> bytes:
        try:
            return self._serial.read(n)
        except Exception as exc:
            raise TransportError(f"UART read error: {exc}") from exc

    def close(self) -> None:
        if self._serial.is_open:
            self._serial.close()


class TCPTransport(Transport):
    """TCP transport using the standard socket library."""

    def __init__(self, host: str, port: int, timeout: float = 2.0) -> None:
        try:
            self._sock = socket.create_connection((host, port), timeout=timeout)
            self._sock.settimeout(0.1)  # non-blocking reads inside read_frame loop
        except OSError as exc:
            raise TransportError(f"Cannot connect to {host}:{port}: {exc}") from exc

    @classmethod
    def from_socket(cls, sock: socket.socket, timeout: float = 0.1) -> "TCPTransport":
        """Wrap an already-connected socket (e.g. accepted by a server).

        Use this in server mode where HA accepts incoming connections from readers.
        """
        instance = cls.__new__(cls)
        sock.settimeout(timeout)
        instance._sock = sock
        return instance

    def write(self, data: bytes) -> None:
        try:
            self._sock.sendall(data)
        except OSError as exc:
            raise TransportError(f"TCP write error: {exc}") from exc

    def _read_chunk(self, n: int) -> bytes:
        try:
            return self._sock.recv(n)
        except socket.timeout:
            return b""
        except OSError as exc:
            raise TransportError(f"TCP read error: {exc}") from exc

    def close(self) -> None:
        try:
            self._sock.close()
        except OSError:
            pass
