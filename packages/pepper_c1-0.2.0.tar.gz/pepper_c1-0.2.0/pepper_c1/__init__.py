"""pepper_c1 — Python driver for the Eccel Peeper C1 RFID reader."""

from .client import PepperC1
from .commands import Command, PollingEventFormat
from .commands import KEY_TYPE_AES128, KEY_TYPE_AES192, KEY_TYPE_AES256
from .commands import KEY_TYPE_DES, KEY_TYPE_2K3DES, KEY_TYPE_3K3DES, KEY_TYPE_MIFARE
from .exceptions import CommandError, ProtocolError, TransportError
from .transport import TCPTransport, UARTTransport

__version__ = "0.2.0"
__all__ = [
    "PepperC1",
    "UARTTransport",
    "TCPTransport",
    "Command",
    "PollingEventFormat",
    "CommandError",
    "ProtocolError",
    "TransportError",
    "KEY_TYPE_AES128",
    "KEY_TYPE_AES192",
    "KEY_TYPE_AES256",
    "KEY_TYPE_DES",
    "KEY_TYPE_2K3DES",
    "KEY_TYPE_3K3DES",
    "KEY_TYPE_MIFARE",
]
