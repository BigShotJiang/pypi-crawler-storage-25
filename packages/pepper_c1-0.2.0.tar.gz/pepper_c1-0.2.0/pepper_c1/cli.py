"""
Command-line entry points installed by pip.

After `pip install pepper_c1` the following commands are available:

    c1-read-uid   uart COM3
    c1-classic    uart COM3 [--block N] [--vblock N] [--key FFFFFFFFFFFF]
    c1-ultralight uart COM3 [--page N] [--counter N]
    c1-icode      uart COM3 [--block N]
    c1-desfire    uart COM3

Replace `uart COM3` with `tcp --host 192.168.x.x --port 1234` for TCP transport.
"""

from __future__ import annotations

import argparse
import os
import struct
import sys

from .commands import KEY_TYPE_DES, KEY_TYPE_AES128, KEY_TYPE_MIFARE, Command
from .exceptions import CommandError, TransportError
from . import PepperC1
from .transport import UARTTransport, TCPTransport


# ── shared helpers ────────────────────────────────────────────────────

TAG_NAMES = {
    0x01: "MIFARE Ultralight",
    0x02: "MIFARE Ultralight-C",
    0x03: "MIFARE Classic",
    0x04: "MIFARE Classic 1K",
    0x05: "MIFARE Classic 4K",
    0x06: "MIFARE Plus",
    0x07: "MIFARE Plus 2K",
    0x08: "MIFARE Plus 4K",
    0x09: "MIFARE Plus 2K SL2",
    0x0A: "MIFARE Plus 4K SL2",
    0x0B: "MIFARE Plus 2K SL3",
    0x0C: "MIFARE Plus 4K SL3",
    0x0D: "MIFARE DESFire",
    0x0F: "JCOP",
    0x10: "MIFARE Mini",
    0x21: "ICODE SLI",
    0x22: "ICODE SLI-S",
    0x23: "ICODE SLI-L",
    0x24: "ICODE SLIX",
    0x25: "ICODE SLIX-S",
    0x26: "ICODE SLIX-X",
    0x27: "ICODE SLIX2",
    0x28: "ICODE DNA",
}

MF_CLASSIC_TYPES    = {0x03, 0x04, 0x05, 0x10}
MF_ULTRALIGHT_TYPES = {0x01, 0x02}
DESFIRE_TYPES       = {0x0D}
ICODE_TYPES         = set(range(0x21, 0x29))


def _make_transport(args):
    if args.transport == "uart":
        return UARTTransport(args.port, baudrate=args.baudrate)
    return TCPTransport(args.host, args.port)


def _add_transport_subparsers(ap: argparse.ArgumentParser):
    sub = ap.add_subparsers(dest="transport", required=True)
    u = sub.add_parser("uart", help="Connect via UART")
    u.add_argument("port", help="e.g. COM3 or /dev/ttyUSB0")
    u.add_argument("--baudrate", type=int, default=115200)
    t = sub.add_parser("tcp", help="Connect via TCP")
    t.add_argument("--host", default="192.168.100.1")
    t.add_argument("--port", type=int, default=1234)


def _run_with_error_handling(transport, fn):
    try:
        with PepperC1(transport) as reader:
            fn(reader)
    except TransportError as e:
        print(f"Transport error: {e}", file=sys.stderr)
        sys.exit(1)
    except CommandError as e:
        print(f"Command error: {e}", file=sys.stderr)
        sys.exit(1)


# ── c1-read-uid ───────────────────────────────────────────────────────

def _run_read_uid(reader: PepperC1) -> None:
    print(f"Firmware  : {reader.get_version()}")
    tag_count = reader.get_tag_count()
    print(f"Tags found: {tag_count}")
    if tag_count == 0:
        print("No tag in field.")
        return
    for i in range(tag_count):
        uid_info  = reader.get_uid(i)
        type_byte = uid_info[0]
        uid       = uid_info[2:]
        tag_name  = TAG_NAMES.get(type_byte, f"Unknown (0x{type_byte:02X})")
        print(f"  [{i}] {tag_name:30s}  UID: {uid.hex()}")


def read_uid_main() -> None:
    """c1-read-uid — read UID from tag(s) in the RF field."""
    ap = argparse.ArgumentParser(description=read_uid_main.__doc__)
    _add_transport_subparsers(ap)
    args = ap.parse_args()
    _run_with_error_handling(_make_transport(args), _run_read_uid)


# ── c1-classic ────────────────────────────────────────────────────────

def _run_classic(reader: PepperC1, block: int, vblock: int, key: bytes) -> None:
    print(f"Firmware : {reader.get_version()}")
    tag_count = reader.get_tag_count()
    if tag_count == 0:
        print("No tag in field.")
        return
    uid_info  = reader.get_uid(tag_count - 1)
    type_byte = uid_info[0]
    print(f"Tag type : 0x{type_byte:02X}  UID: {uid_info[2:].hex()}")
    if type_byte not in MF_CLASSIC_TYPES:
        print("Not a MIFARE Classic tag — aborting.")
        return
    reader.activate_tag(tag_count - 1)
    reader.set_key(0, KEY_TYPE_MIFARE, key + key)
    print(f"Key: {key.hex().upper()}")

    print(f"\n--- Data block {block} ---")
    original = reader.mf_read_block(block)
    print(f"  original : {original.hex()}")
    new_data = os.urandom(16)
    reader.mf_write_block(block, new_data)
    readback = reader.mf_read_block(block)
    print(f"  written  : {new_data.hex()}")
    print(f"  readback : {readback.hex()}")
    print(f"  {'PASS' if readback == new_data else 'FAIL'}")
    reader.mf_write_block(block, original)
    print(f"  restored : {original.hex()}")

    print(f"\n--- Value block {vblock} ---")
    reader.mf_write_value(vblock, 1000)
    print(f"  after write 1000  : {reader.mf_read_value(vblock)}")
    reader.mf_increment(vblock, 50)
    print(f"  after increment 50: {reader.mf_read_value(vblock)}")
    print("\nDone.")


def classic_main() -> None:
    """c1-classic — MIFARE Classic read/write/value block test."""
    ap = argparse.ArgumentParser(description=classic_main.__doc__)
    _add_transport_subparsers(ap)
    ap.add_argument("--block",  type=int, default=5,   help="Data block (default: 5)")
    ap.add_argument("--vblock", type=int, default=6,   help="Value block (default: 6)")
    ap.add_argument("--key", default="FFFFFFFFFFFF",   help="6-byte key as 12 hex chars")
    args = ap.parse_args()
    key = bytes.fromhex(args.key)
    if len(key) != 6:
        ap.error("--key must be exactly 12 hex characters (6 bytes)")
    _run_with_error_handling(_make_transport(args),
                             lambda r: _run_classic(r, args.block, args.vblock, key))


# ── c1-ultralight ─────────────────────────────────────────────────────

def _run_ultralight(reader: PepperC1, page: int, counter: int) -> None:
    print(f"Firmware : {reader.get_version()}")
    tag_count = reader.get_tag_count()
    if tag_count == 0:
        print("No tag in field.")
        return
    uid_info  = reader.get_uid(tag_count - 1)
    type_byte = uid_info[0]
    print(f"Tag type : 0x{type_byte:02X}  UID: {uid_info[2:].hex()}")
    if type_byte not in MF_ULTRALIGHT_TYPES:
        print("Not a MIFARE Ultralight tag — aborting.")
        return
    reader.activate_tag(tag_count - 1)

    print(f"\n--- Page {page} ---")
    original = reader.mfu_read_page(page)
    print(f"  original : {original.hex()}")
    new_data = os.urandom(4)
    reader.mfu_write_page(page, new_data)
    readback = reader.mfu_read_page(page)
    print(f"  written  : {new_data.hex()}")
    print(f"  readback : {readback.hex()}")
    print(f"  {'PASS' if readback == new_data else 'FAIL'}")
    reader.mfu_write_page(page, original)
    print(f"  restored : {original.hex()}")

    print(f"\n--- NFC counter {counter} ---")
    try:
        val = reader.mfu_read_counter(counter)
        print(f"  current : {val}")
        reader.mfu_increment_counter(counter, 1)
        print(f"  after +1: {reader.mfu_read_counter(counter)}")
    except CommandError as e:
        print(f"  counter not available: {e}")

    print("\n--- Card version (EV1 only) ---")
    try:
        ver = reader.send_command(Command.MFU_GET_VERSION)
        print(f"  version  : {ver.hex(' ')}")
        sig = reader.send_command(Command.MFU_READ_SIG)
        print(f"  signature: {sig.hex()}")
    except CommandError as e:
        print(f"  not available on this variant: {e}")
    print("\nDone.")


def ultralight_main() -> None:
    """c1-ultralight — MIFARE Ultralight page read/write/counter test."""
    ap = argparse.ArgumentParser(description=ultralight_main.__doc__)
    _add_transport_subparsers(ap)
    ap.add_argument("--page",    type=int, default=4, help="Page (default: 4)")
    ap.add_argument("--counter", type=int, default=0, help="NFC counter index (default: 0)")
    args = ap.parse_args()
    _run_with_error_handling(_make_transport(args),
                             lambda r: _run_ultralight(r, args.page, args.counter))


# ── c1-icode ──────────────────────────────────────────────────────────

def _run_icode(reader: PepperC1, block: int) -> None:
    print(f"Firmware : {reader.get_version()}")
    tag_count = reader.get_tag_count()
    if tag_count == 0:
        print("No tag in field.")
        return
    uid_info  = reader.get_uid(tag_count - 1)
    type_byte = uid_info[0]
    print(f"Tag type : 0x{type_byte:02X}  UID: {uid_info[2:].hex()}")
    if type_byte not in ICODE_TYPES:
        print("Not an ICODE tag — aborting.")
        return

    print("\n--- System information ---")
    try:
        info = reader.icode_get_system_information()
        print(f"  {info.hex(' ')}")
    except CommandError as e:
        print(f"  not available: {e}")

    print(f"\n--- Block {block} ---")
    original = reader.icode_read_block(block)
    print(f"  original : {original.hex()}")
    new_data = os.urandom(4)
    reader.icode_write_block(block, new_data)
    readback = reader.icode_read_block(block)
    print(f"  written  : {new_data.hex()}")
    print(f"  readback : {readback.hex()}")
    print(f"  {'PASS' if readback == new_data else 'FAIL'}")
    reader.icode_write_block(block, original)
    print(f"  restored : {original.hex()}")

    print("\n--- Block security status (blocks 0–9) ---")
    try:
        bss = reader.send_command(Command.ICODE_GET_MULTIPLE_BSS, bytes([0, 10]))
        for idx, b in enumerate(bss):
            print(f"  block {idx:2d}: {'LOCKED' if b else 'unlocked'}")
    except CommandError as e:
        print(f"  not available: {e}")
    print("\nDone.")


def icode_main() -> None:
    """c1-icode — ICODE SLI/SLIX block read/write test."""
    ap = argparse.ArgumentParser(description=icode_main.__doc__)
    _add_transport_subparsers(ap)
    ap.add_argument("--block", type=int, default=5, help="Block (default: 5)")
    args = ap.parse_args()
    _run_with_error_handling(_make_transport(args),
                             lambda r: _run_icode(r, args.block))


# ── c1-desfire ────────────────────────────────────────────────────────

_DESFIRE_TEST_AID   = bytes([0xAA, 0x55, 0xAA])
_DESFIRE_RECORD_SIZE = 34   # struct { uint16_t nr; char text[32]; }


def _run_desfire(reader: PepperC1) -> None:
    print(f"Firmware : {reader.get_version()}")
    tag_count = reader.get_tag_count()
    if tag_count == 0:
        print("No tag in field.")
        return
    uid_info  = reader.get_uid(tag_count - 1)
    type_byte = uid_info[0]
    print(f"Tag type : 0x{type_byte:02X}  UID: {uid_info[2:].hex()}")
    if type_byte not in DESFIRE_TYPES:
        print("Not a MIFARE DESFire tag — aborting.")
        return

    reader.set_key(0, KEY_TYPE_DES,    bytes(16))
    reader.set_key(1, KEY_TYPE_AES128, bytes(16))
    reader.set_key(2, KEY_TYPE_AES128, bytes([0x01] * 16))
    print("Keys loaded (slot 0=DES zeros, slot 1=AES zeros, slot 2=AES 0x01*16)")

    print("\n--- PICC master app ---")
    reader.mfdf_select_app(b'\x00\x00\x00')
    reader.mfdf_auth(0, key_slot=0)
    print("  auth OK")
    print("  formatting card ...")
    reader.mfdf_format()
    free = reader.mfdf_get_free_mem()
    ver  = reader.mfdf_card_version()
    print(f"  free memory  : {free} bytes")
    print(f"  card version : {ver.hex(' ')}")

    aid_str = _DESFIRE_TEST_AID.hex().upper()
    print(f"\n--- Create app AID={aid_str} ---")
    reader.mfdf_create_app(_DESFIRE_TEST_AID, key_settings=0xED, num_keys=0x84)
    reader.mfdf_select_app(_DESFIRE_TEST_AID)
    reader.mfdf_auth_aes(1, key_slot=0)
    print("  app selected and authenticated")

    print("\n--- Data file 0x01 (backup, 32 bytes) ---")
    reader.mfdf_create_data_file(0x01, access_rights=0xEEEE, size=32, backup=True)
    test_data = b"Ala ma kota"
    reader.mfdf_write_data(0x01, offset=0, data=test_data)
    reader.mfdf_commit_transaction()
    readback = reader.mfdf_read_data(0x01, offset=0, length=len(test_data))
    print(f"  wrote   : {test_data!r}")
    print(f"  readback: {readback!r}")
    ok = readback.rstrip(b'\x00') == test_data
    print(f"  {'PASS' if ok else 'FAIL'}")

    print("\n--- Value file 0x02 (range -100..100, init -5) ---")
    reader.mfdf_create_value_file(0x02, access_rights=0xEEEE,
                                  lower_limit=-100, upper_limit=100,
                                  init_value=-5, limited_credit=True)
    print(f"  initial value    : {reader.mfdf_get_value(0x02)}")
    reader.mfdf_credit(0x02, 10)
    reader.mfdf_commit_transaction()
    print(f"  after credit +10 : {reader.mfdf_get_value(0x02)}")
    reader.mfdf_debit(0x02, 25)
    reader.mfdf_commit_transaction()
    print(f"  after debit  -25 : {reader.mfdf_get_value(0x02)}")

    rs = _DESFIRE_RECORD_SIZE
    print(f"\n--- Cyclic record file 0x03 ({rs}B records, max 10) ---")
    reader.mfdf_create_record_file(0x03, access_rights=0xEEEE,
                                   record_size=rs, max_records=10, cyclic=True)
    for i in range(5):
        text   = f"This is record nr {i}".encode().ljust(32, b'\x00')
        reader.mfdf_write_record(0x03, struct.pack("<H", i) + text)
        reader.mfdf_commit_transaction()
        print(f"  wrote record {i}")
    for i in range(5):
        raw  = reader.mfdf_read_record(0x03, offset=i, record_size=rs)
        rec  = raw[:rs]
        nr,  = struct.unpack_from("<H", rec)
        text = rec[2:].rstrip(b'\x00').decode(errors="replace")
        print(f"  read  record {i}: nr={nr}, text={text!r}")
    reader.mfdf_clear_records(0x03)
    reader.mfdf_commit_transaction()
    print("  records cleared")

    print("\n--- Cleanup ---")
    for fno in (0x01, 0x02, 0x03):
        reader.mfdf_delete_file(fno)
        print(f"  deleted file 0x{fno:02X}")
    reader.mfdf_delete_app(_DESFIRE_TEST_AID)
    print(f"  deleted app {aid_str}")
    print("\nDone.")


def desfire_main() -> None:
    """c1-desfire — MIFARE DESFire full test (data file, value file, record file)."""
    ap = argparse.ArgumentParser(description=desfire_main.__doc__)
    _add_transport_subparsers(ap)
    args = ap.parse_args()
    _run_with_error_handling(_make_transport(args), _run_desfire)
