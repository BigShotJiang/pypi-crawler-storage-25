"""Tests for transport layer."""

import socket
from unittest.mock import MagicMock, patch

import pytest

from pepper_c1.transport import TCPTransport
from pepper_c1.exceptions import TransportError


class TestTCPTransportFromSocket:
    def _make_sock(self) -> MagicMock:
        sock = MagicMock(spec=socket.socket)
        sock.recv.return_value = b""
        return sock

    def test_returns_tcptransport_instance(self):
        sock = self._make_sock()
        t = TCPTransport.from_socket(sock)
        assert isinstance(t, TCPTransport)

    def test_sets_timeout_on_socket(self):
        sock = self._make_sock()
        TCPTransport.from_socket(sock, timeout=0.25)
        sock.settimeout.assert_called_once_with(0.25)

    def test_default_timeout_is_0_1(self):
        sock = self._make_sock()
        TCPTransport.from_socket(sock)
        sock.settimeout.assert_called_once_with(0.1)

    def test_write_delegates_to_socket(self):
        sock = self._make_sock()
        t = TCPTransport.from_socket(sock)
        t.write(b"\x01\x02\x03")
        sock.sendall.assert_called_once_with(b"\x01\x02\x03")

    def test_read_chunk_delegates_to_socket(self):
        sock = self._make_sock()
        sock.recv.return_value = b"\xAB\xCD"
        t = TCPTransport.from_socket(sock)
        result = t._read_chunk(64)
        assert result == b"\xAB\xCD"

    def test_close_closes_socket(self):
        sock = self._make_sock()
        t = TCPTransport.from_socket(sock)
        t.close()
        sock.close.assert_called_once()
