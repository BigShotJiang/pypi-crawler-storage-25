"""Tests for PepperC1 client using a mock transport."""

import pytest
from unittest.mock import MagicMock

from pepper_c1.client import PepperC1
from pepper_c1.commands import Command, PollingEventFormat
from pepper_c1.exceptions import CommandError
from pepper_c1.protocol import build_frame, calc_crc


def _ack_frame(cmd: Command, data: bytes = b"") -> bytes:
    """Build a well-formed ACK response frame."""
    payload = bytes([Command.ACK, cmd]) + data
    return build_frame(payload)


def _error_frame(cmd: Command, error_code: int = 0x0001) -> bytes:
    """Build a well-formed ERROR response frame."""
    payload = bytes([
        Command.ERROR,
        cmd,
        error_code & 0xFF,
        (error_code >> 8) & 0xFF,
    ])
    return build_frame(payload)


class MockTransport:
    """Minimal transport that returns pre-programmed response frames."""

    def __init__(self, response: bytes) -> None:
        self._response = response
        self._pos = 0
        self.written: list[bytes] = []

    def write(self, data: bytes) -> None:
        self.written.append(data)

    def _read_chunk(self, n: int) -> bytes:
        chunk = self._response[self._pos: self._pos + n]
        self._pos += len(chunk)
        return chunk

    def close(self) -> None:
        pass


class TestGetVersion:
    def test_returns_string(self):
        response = _ack_frame(Command.GET_VERSION, b"v1.2.3\x00")
        transport = MockTransport(response)
        client = PepperC1(transport, response_timeout=1.0)
        assert client.get_version() == "v1.2.3"

    def test_sends_correct_command(self):
        transport = MockTransport(_ack_frame(Command.GET_VERSION, b"v1"))
        client = PepperC1(transport, response_timeout=1.0)
        client.get_version()
        sent_payload = transport.written[0]
        # STX is first byte, then length bytes, then payload starting at index 5
        assert sent_payload[5] == Command.GET_VERSION


class TestGetDeviceName:
    def test_returns_device_name(self):
        name = b"Pepper_C1-1A64D4"
        payload = bytes([0x00, 0x00, 0x01, len(name)]) + name
        transport = MockTransport(_ack_frame(Command.PROTO_CONFIG, payload))
        client = PepperC1(transport, response_timeout=1.0)
        assert client.get_device_name() == "Pepper_C1-1A64D4"

    def test_sends_general_config_subcommand(self):
        name = b"TestDevice"
        payload = bytes([0x00, 0x00, 0x01, len(name)]) + name
        transport = MockTransport(_ack_frame(Command.PROTO_CONFIG, payload))
        client = PepperC1(transport, response_timeout=1.0)
        client.get_device_name()
        # Frame layout: STX(1) + LEN_L LEN_H ~LEN_L ~LEN_H(4) + CMD + SUBCMD + ...
        assert transport.written[0][5] == Command.PROTO_CONFIG
        assert transport.written[0][6] == 0x00  # general config subcommand

    def test_raises_on_truncated_response(self):
        from pepper_c1.exceptions import ProtocolError
        transport = MockTransport(_ack_frame(Command.PROTO_CONFIG, bytes([0x00, 0x00])))
        client = PepperC1(transport, response_timeout=1.0)
        with pytest.raises(ProtocolError):
            client.get_device_name()


class TestGetUid:
    def test_returns_bytes(self):
        uid = bytes([0xDE, 0xAD, 0xBE, 0xEF])
        transport = MockTransport(_ack_frame(Command.GET_UID, uid))
        client = PepperC1(transport, response_timeout=1.0)
        assert client.get_uid() == uid


class TestCommandError:
    def test_raises_on_error_response(self):
        transport = MockTransport(_error_frame(Command.GET_UID, 0x0005))
        client = PepperC1(transport, response_timeout=1.0)
        with pytest.raises(CommandError) as exc_info:
            client.get_uid()
        assert exc_info.value.error_code == 0x0005

    def test_error_contains_command(self):
        transport = MockTransport(_error_frame(Command.MF_READ_BLOCK, 0x0003))
        client = PepperC1(transport, response_timeout=1.0)
        with pytest.raises(CommandError) as exc_info:
            client.mf_read_block(4)
        assert exc_info.value.cmd == Command.MF_READ_BLOCK


class TestMifareClassic:
    def test_read_block_returns_16_bytes(self):
        block_data = bytes(range(16))
        transport = MockTransport(_ack_frame(Command.MF_READ_BLOCK, block_data))
        client = PepperC1(transport, response_timeout=1.0)
        result = client.mf_read_block(4)
        assert result == block_data

    def test_write_block_rejects_wrong_size(self):
        transport = MockTransport(b"")
        client = PepperC1(transport, response_timeout=1.0)
        with pytest.raises(ValueError):
            client.mf_write_block(4, b"\x00" * 15)

    def test_write_block_sends_block_number(self):
        transport = MockTransport(_ack_frame(Command.MF_WRITE_BLOCK))
        client = PepperC1(transport, response_timeout=1.0)
        client.mf_write_block(7, b"\xAB" * 16)
        sent_payload = transport.written[0]
        # payload starts at index 5: [CMD_WRITE_BLOCK, block_no, ...data...]
        assert sent_payload[6] == 7  # block number


class TestMifareUltralight:
    def test_read_page_returns_4_bytes(self):
        page_data = bytes([0x01, 0x02, 0x03, 0x04])
        transport = MockTransport(_ack_frame(Command.MFU_READ_PAGE, page_data))
        client = PepperC1(transport, response_timeout=1.0)
        assert client.mfu_read_page(5) == page_data

    def test_write_page_rejects_wrong_size(self):
        transport = MockTransport(b"")
        client = PepperC1(transport, response_timeout=1.0)
        with pytest.raises(ValueError):
            client.mfu_write_page(5, b"\x00" * 5)


class TestAsyncEvents:
    def test_async_events_stored(self):
        async_payload = bytes([Command.ASYNC, 0xDE, 0xAD])
        async_frame = build_frame(async_payload)
        normal_response = _ack_frame(Command.GET_TAG_COUNT, b"\x01")
        transport = MockTransport(async_frame + normal_response)
        client = PepperC1(transport, response_timeout=1.0)
        result = client.get_tag_count()
        assert result == 1
        assert len(client.async_events) == 1
        assert client.async_events[0] == bytes([0xDE, 0xAD])


class TestSetActiveAntenna:
    def test_sends_antenna_number(self):
        transport = MockTransport(_ack_frame(Command.SET_ACTIVE_ANTENNA))
        client = PepperC1(transport, response_timeout=1.0)
        client.set_active_antenna(3)
        sent_payload = transport.written[0]
        assert sent_payload[5] == Command.SET_ACTIVE_ANTENNA
        assert sent_payload[6] == 3

    def test_boundary_values(self):
        for antenna in (1, 8):
            transport = MockTransport(_ack_frame(Command.SET_ACTIVE_ANTENNA))
            client = PepperC1(transport, response_timeout=1.0)
            client.set_active_antenna(antenna)
            assert transport.written[0][6] == antenna

    def test_rejects_out_of_range(self):
        transport = MockTransport(b"")
        client = PepperC1(transport, response_timeout=1.0)
        with pytest.raises(ValueError):
            client.set_active_antenna(0)
        with pytest.raises(ValueError):
            client.set_active_antenna(9)


class TestContextManager:
    def test_closes_transport_on_exit(self):
        transport = MockTransport(_ack_frame(Command.GET_VERSION, b"v1"))
        transport.close = MagicMock()
        with PepperC1(transport, response_timeout=1.0) as client:
            client.get_version()
        transport.close.assert_called_once()


class TestPollingSetupAsync:
    def _sent_bytes(self, known: bool, fmt: int) -> bytes:
        transport = MockTransport(_ack_frame(Command.POLLING_SETUP))
        client = PepperC1(transport, response_timeout=1.0)
        client.polling_setup_async(known, fmt)
        return transport.written[0]

    def test_unknown_tag_binary_frame(self):
        raw = self._sent_bytes(known=False, fmt=PollingEventFormat.BINARY)
        # payload bytes: [POLLING_SETUP, 0x06, known_flag, frame_format]
        assert raw[5] == Command.POLLING_SETUP
        assert raw[6] == 0x06   # subcommand
        assert raw[7] == 0x01   # unknown flag
        assert raw[8] == 0x01   # binary format

    def test_known_tag_binary_frame(self):
        raw = self._sent_bytes(known=True, fmt=PollingEventFormat.BINARY)
        assert raw[7] == 0x00   # known flag
        assert raw[8] == 0x01   # binary format

    def test_disable_with_none_format(self):
        raw = self._sent_bytes(known=False, fmt=PollingEventFormat.NONE)
        assert raw[8] == 0x00

    def test_accepts_int_format(self):
        raw = self._sent_bytes(known=True, fmt=3)
        assert raw[8] == 0x03   # JSON
