"""Tests for binary protocol framing and CRC."""

import pytest
from pepper_c1.protocol import (
    STX,
    FrameParser,
    build_frame,
    calc_crc,
    parse_frame,
)
from pepper_c1.exceptions import ProtocolError


class TestCalcCrc:
    def test_empty(self):
        assert calc_crc(b"") == 0xFFFF

    def test_single_byte(self):
        # Regression: verify against known-good value derived from C implementation
        result = calc_crc(b"\x01")
        assert isinstance(result, int)
        assert 0 <= result <= 0xFFFF

    def test_deterministic(self):
        data = b"\x02\x01\x02\x03"
        assert calc_crc(data) == calc_crc(data)

    def test_differs_for_different_data(self):
        assert calc_crc(b"\x01") != calc_crc(b"\x02")


class TestBuildFrame:
    def test_starts_with_stx(self):
        frame = build_frame(b"\x0B")  # GET_VERSION
        assert frame[0] == STX

    def test_length_field(self):
        payload = b"\x0B"
        frame = build_frame(payload)
        len_l, len_h = frame[1], frame[2]
        declared_len = len_l | (len_h << 8)
        assert declared_len == len(payload) + 2

    def test_length_xor_check(self):
        frame = build_frame(b"\x03\x00")
        assert frame[3] == frame[1] ^ 0xFF
        assert frame[4] == frame[2] ^ 0xFF

    def test_total_frame_length(self):
        payload = b"\x0B"
        frame = build_frame(payload)
        # 1 STX + 4 length bytes + len(payload) + 2 CRC = 7 + len(payload)
        assert len(frame) == 7 + len(payload)

    def test_crc_appended(self):
        payload = b"\x0B"
        frame = build_frame(payload)
        crc_in_frame = frame[-2] | (frame[-1] << 8)
        assert crc_in_frame == calc_crc(payload)


class TestParseFrame:
    def test_round_trip(self):
        payload = b"\x00\x0B\xDE\xAD\xBE\xEF"
        frame = build_frame(payload)
        recovered = parse_frame(frame)
        assert recovered == payload

    def test_bad_stx_raises(self):
        frame = bytearray(build_frame(b"\x01"))
        frame[0] = 0xAA
        with pytest.raises(ProtocolError, match="STX"):
            parse_frame(bytes(frame))

    def test_bad_xor_raises(self):
        frame = bytearray(build_frame(b"\x01"))
        frame[3] ^= 0x01  # corrupt XOR byte
        with pytest.raises(ProtocolError, match="XOR"):
            parse_frame(bytes(frame))

    def test_bad_crc_raises(self):
        frame = bytearray(build_frame(b"\x01"))
        frame[-1] ^= 0xFF  # corrupt last CRC byte
        with pytest.raises(ProtocolError, match="CRC"):
            parse_frame(bytes(frame))

    def test_too_short_raises(self):
        with pytest.raises(ProtocolError, match="short"):
            parse_frame(b"\xF5\x03\x00")


class TestFrameParser:
    def _make_raw(self, payload: bytes) -> bytes:
        return build_frame(payload)

    def test_single_frame(self):
        parser = FrameParser()
        raw = self._make_raw(b"\x0B")
        result = parser.feed(raw)
        assert len(result) == 1
        assert result[0] == b"\x0B"

    def test_two_frames_in_one_feed(self):
        parser = FrameParser()
        raw = self._make_raw(b"\x0B") + self._make_raw(b"\x02")
        result = parser.feed(raw)
        assert len(result) == 2
        assert result[0] == b"\x0B"
        assert result[1] == b"\x02"

    def test_split_delivery(self):
        parser = FrameParser()
        raw = self._make_raw(b"\x03\x01\x02\x03")
        # Feed byte by byte
        collected = []
        for b in raw:
            collected.extend(parser.feed(bytes([b])))
        assert len(collected) == 1
        assert collected[0] == b"\x03\x01\x02\x03"

    def test_garbage_before_frame(self):
        parser = FrameParser()
        garbage = b"\x00\x11\x22\x33"
        raw = garbage + self._make_raw(b"\x0B")
        result = parser.feed(raw)
        assert len(result) == 1
        assert result[0] == b"\x0B"

    def test_bad_xor_skipped(self):
        parser = FrameParser()
        bad_frame = bytearray(self._make_raw(b"\x01"))
        bad_frame[3] ^= 0x01
        good_frame = self._make_raw(b"\x02")
        result = parser.feed(bytes(bad_frame) + good_frame)
        assert len(result) == 1
        assert result[0] == b"\x02"

    def test_bad_crc_discarded(self):
        parser = FrameParser()
        bad_frame = bytearray(self._make_raw(b"\x01"))
        bad_frame[-1] ^= 0xFF
        result = parser.feed(bytes(bad_frame))
        assert result == []
