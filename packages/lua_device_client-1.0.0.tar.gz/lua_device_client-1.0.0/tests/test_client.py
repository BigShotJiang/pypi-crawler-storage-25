"""Tests for the Lua Device Client."""

from __future__ import annotations

import asyncio
import json
from unittest.mock import AsyncMock, MagicMock, patch

import pytest

from lua_device import DeviceClient, DeviceCommandDefinition
from lua_device.types import DeviceClientConfig, ResponseMessage, CommandMessage, TriggerAckMessage


# =============================================================================
# Config Validation
# =============================================================================


class TestDeviceClientConfig:
    def test_minimal_config(self):
        config = DeviceClientConfig(
            agent_id="baseAgent_agent_abc123",
            api_key="api_test_key",
            device_name="test-device",
        )
        assert config.agent_id == "baseAgent_agent_abc123"
        assert config.mqtt_url == "wss://mqtt.heylua.ai/mqtt"
        assert config.cdn_url == "https://cdn.heylua.ai"
        assert config.commands == []
        assert config.group is None

    def test_full_config(self):
        config = DeviceClientConfig(
            agent_id="baseAgent_agent_abc123",
            api_key="api_test_key",
            device_name="test-device",
            mqtt_url="mqtt://localhost:1883",
            cdn_url="http://localhost:3001",
            group="warehouse-a",
            commands=[
                DeviceCommandDefinition(name="read_sensor", description="Read the sensor"),
            ],
        )
        assert config.mqtt_url == "mqtt://localhost:1883"
        assert config.group == "warehouse-a"
        assert len(config.commands) == 1


# =============================================================================
# Command Definition
# =============================================================================


class TestDeviceCommandDefinition:
    def test_minimal_definition(self):
        cmd = DeviceCommandDefinition(name="read_temp", description="Read temperature")
        d = cmd.to_dict()
        assert d == {"name": "read_temp", "description": "Read temperature"}

    def test_full_definition(self):
        cmd = DeviceCommandDefinition(
            name="set_led",
            description="Set LED color",
            input_schema={"type": "object", "properties": {"color": {"type": "string"}}},
            timeout_ms=5000,
            retry={"max_attempts": 3, "backoff_ms": 1000},
        )
        d = cmd.to_dict()
        assert d["name"] == "set_led"
        assert d["inputSchema"]["type"] == "object"
        assert d["timeoutMs"] == 5000
        assert d["retry"]["maxAttempts"] == 3

    def test_default_timeout_not_serialized(self):
        cmd = DeviceCommandDefinition(name="ping", description="Ping")
        d = cmd.to_dict()
        assert "timeoutMs" not in d


# =============================================================================
# Command Registration
# =============================================================================


class TestCommandRegistration:
    def test_register_command_handler(self):
        client = DeviceClient(
            agent_id="baseAgent_agent_abc123",
            api_key="api_test_key",
            device_name="test-device",
        )

        async def handler(payload):
            return {"result": "ok"}

        client.on_command("test_cmd", handler)
        assert "test_cmd" in client._command_handlers
        assert client._command_handlers["test_cmd"] is handler

    def test_register_multiple_handlers(self):
        client = DeviceClient(
            agent_id="baseAgent_agent_abc123",
            api_key="api_test_key",
            device_name="test-device",
        )

        async def handler_a(payload):
            return "a"

        async def handler_b(payload):
            return "b"

        client.on_command("cmd_a", handler_a)
        client.on_command("cmd_b", handler_b)
        assert len(client._command_handlers) == 2


# =============================================================================
# Message Parsing
# =============================================================================


class TestMessageParsing:
    def test_response_message_success(self):
        resp = ResponseMessage(command_id="cmd-123", success=True, data={"temp": 22.5})
        d = resp.to_dict()
        assert d == {"commandId": "cmd-123", "success": True, "data": {"temp": 22.5}}

    def test_response_message_error(self):
        resp = ResponseMessage(command_id="cmd-456", success=False, error="Sensor offline")
        d = resp.to_dict()
        assert d == {"commandId": "cmd-456", "success": False, "error": "Sensor offline"}

    def test_response_message_minimal(self):
        resp = ResponseMessage(command_id="cmd-789", success=True)
        d = resp.to_dict()
        assert d == {"commandId": "cmd-789", "success": True}
        assert "data" not in d
        assert "error" not in d

    def test_trigger_ack_message(self):
        ack = TriggerAckMessage(trigger_id="trg-001", received=True)
        assert ack.trigger_id == "trg-001"
        assert ack.received is True
        assert ack.error is None

    def test_command_message(self):
        msg = CommandMessage(command_id="cmd-100", command="read_sensor", payload={"unit": "celsius"})
        assert msg.command_id == "cmd-100"
        assert msg.command == "read_sensor"
        assert msg.payload == {"unit": "celsius"}


# =============================================================================
# Command Handling (unit test with mocked MQTT)
# =============================================================================


class TestCommandHandling:
    @pytest.mark.asyncio
    async def test_handle_known_command(self):
        client = DeviceClient(
            agent_id="baseAgent_agent_abc123",
            api_key="api_test_key",
            device_name="test-device",
        )
        client._mqtt_client = MagicMock()

        async def handler(payload):
            return {"temp": 22.5}

        client.on_command("read_temp", handler)

        await client._handle_command({
            "commandId": "cmd-001",
            "command": "read_temp",
            "payload": {},
        })

        client._mqtt_client.publish.assert_called_once()
        call_args = client._mqtt_client.publish.call_args
        response = json.loads(call_args[0][1])
        assert response["commandId"] == "cmd-001"
        assert response["success"] is True
        assert response["data"] == {"temp": 22.5}

    @pytest.mark.asyncio
    async def test_handle_unknown_command(self):
        client = DeviceClient(
            agent_id="baseAgent_agent_abc123",
            api_key="api_test_key",
            device_name="test-device",
        )
        client._mqtt_client = MagicMock()

        await client._handle_command({
            "commandId": "cmd-002",
            "command": "nonexistent",
            "payload": {},
        })

        call_args = client._mqtt_client.publish.call_args
        response = json.loads(call_args[0][1])
        assert response["success"] is False
        assert "Unknown command" in response["error"]

    @pytest.mark.asyncio
    async def test_handler_exception(self):
        client = DeviceClient(
            agent_id="baseAgent_agent_abc123",
            api_key="api_test_key",
            device_name="test-device",
        )
        client._mqtt_client = MagicMock()

        async def failing_handler(payload):
            raise ValueError("sensor disconnected")

        client.on_command("fail_cmd", failing_handler)

        await client._handle_command({
            "commandId": "cmd-003",
            "command": "fail_cmd",
            "payload": {},
        })

        call_args = client._mqtt_client.publish.call_args
        response = json.loads(call_args[0][1])
        assert response["success"] is False
        assert "sensor disconnected" in response["error"]

    @pytest.mark.asyncio
    async def test_idempotency_dedup(self):
        client = DeviceClient(
            agent_id="baseAgent_agent_abc123",
            api_key="api_test_key",
            device_name="test-device",
        )
        client._mqtt_client = MagicMock()
        call_count = 0

        async def handler(payload):
            nonlocal call_count
            call_count += 1
            return {"count": call_count}

        client.on_command("counted", handler)

        # First call
        await client._handle_command({
            "commandId": "dedup-001",
            "command": "counted",
            "payload": {},
        })
        # Second call with same commandId
        await client._handle_command({
            "commandId": "dedup-001",
            "command": "counted",
            "payload": {},
        })

        assert call_count == 1  # handler only called once
        assert client._mqtt_client.publish.call_count == 2  # response sent both times


# =============================================================================
# Topic Prefix
# =============================================================================


class TestTopicPrefix:
    def test_topic_prefix_format(self):
        client = DeviceClient(
            agent_id="baseAgent_agent_abc123",
            api_key="api_test_key",
            device_name="my-device",
        )
        assert client._topic_prefix == "lua/devices/baseAgent_agent_abc123/my-device/"
