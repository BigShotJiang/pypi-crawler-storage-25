"""
CDN Client -- upload and retrieve files from the Lua CDN.

Uses the same API key as the device client for authentication.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Optional

import httpx

DEFAULT_CDN_URL = "https://cdn.heylua.ai"


@dataclass
class CdnUploadResult:
    """Result from a CDN upload."""

    file_id: str
    media_type: str
    extension: str
    url: str


class CDN:
    """
    Upload and download files from the Lua CDN.

    Usage::

        cdn = CDN(api_key="api_your_key")
        result = await cdn.upload(screenshot_bytes, "screenshot.png", "image/png")
        print(result.url)

        data = await cdn.download(result.file_id)
    """

    def __init__(self, api_key: str, cdn_url: Optional[str] = None):
        self._api_key = api_key
        self._base_url = cdn_url or DEFAULT_CDN_URL

    async def upload(
        self,
        data: bytes,
        filename: str,
        content_type: str = "application/octet-stream",
    ) -> CdnUploadResult:
        """
        Upload a file to the CDN.

        Args:
            data: File content as bytes.
            filename: Filename (e.g. "screenshot.png").
            content_type: MIME type (e.g. "image/png").

        Returns:
            CdnUploadResult with file_id and public URL.
        """
        async with httpx.AsyncClient() as client:
            response = await client.post(
                f"{self._base_url}/upload",
                headers={"Authorization": f"Bearer {self._api_key}"},
                files={"file": (filename, data, content_type)},
            )

        if response.status_code >= 400:
            try:
                err = response.json()
                msg = err.get("message", f"CDN upload failed: {response.status_code}")
            except Exception:
                msg = f"CDN upload failed: {response.status_code}"
            raise RuntimeError(msg)

        result = response.json()
        return CdnUploadResult(
            file_id=result["fileId"],
            media_type=result["mediaType"],
            extension=result["extension"],
            url=f"{self._base_url}/{result['fileId']}",
        )

    async def download(self, file_id: str) -> bytes:
        """
        Download a file from the CDN.

        Args:
            file_id: The file ID returned from upload().

        Returns:
            File content as bytes.
        """
        async with httpx.AsyncClient() as client:
            response = await client.get(f"{self._base_url}/{file_id}")

        if response.status_code >= 400:
            raise RuntimeError(f"CDN download failed: {response.status_code}")

        return response.content

    def get_url(self, file_id: str) -> str:
        """Get the public URL for a file."""
        return f"{self._base_url}/{file_id}"
