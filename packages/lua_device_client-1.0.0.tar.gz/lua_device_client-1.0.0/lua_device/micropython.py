"""
Lua Device Client for MicroPython (Raspberry Pi Pico W)

Connects to the Lua AI platform via MQTT, enabling agents to send
commands to and receive triggers from constrained IoT devices.

Usage:
    from lua_device import LuaDevice

    device = LuaDevice(
        agent_id="baseAgent_agent_123",
        api_key="api_your_key",
        device_name="pico-sensor",
        server="mqtt.heylua.ai",
    )

    @device.command("read_sensor")
    def read_sensor(payload):
        return {"temperature": 22.5, "humidity": 60}

    device.connect()
    device.run()  # blocks, handles commands
"""

import json
import time
import ssl

try:
    from umqtt.robust import MQTTClient
except ImportError:
    from umqtt.simple import MQTTClient


class LuaDevice:
    def __init__(self, agent_id, api_key, device_name, server,
                 port=8883, group=None, use_ssl=True):
        self.agent_id = agent_id
        self.api_key = api_key
        self.device_name = device_name
        self.server = server
        self.port = port
        self.group = group
        self.use_ssl = use_ssl

        self._commands = {}
        self._connected = False
        self._client = None
        self._last_heartbeat = 0
        self._heartbeat_interval = 30  # seconds
        self._seen_ids = {}  # simple dedup: commandId -> timestamp
        self._dedup_ttl = 300  # 5 minutes

        # MQTT identifiers
        self._client_id = "lua-{}-{}".format(agent_id, device_name)
        self._username = "{}:{}".format(agent_id, device_name)
        self._topic_prefix = "lua/devices/{}/{}/".format(agent_id, device_name)

    def command(self, name):
        """Decorator to register a command handler."""
        def decorator(fn):
            self._commands[name] = fn
            return fn
        return decorator

    def on_command(self, name, handler):
        """Register a command handler (non-decorator style)."""
        self._commands[name] = handler

    def connect(self):
        """Connect to the MQTT broker with LWT for disconnect detection."""
        # LWT: broker publishes this if we disconnect unexpectedly
        will_topic = self._topic_prefix + "status"
        will_msg = json.dumps({"status": "offline", "timestamp": str(time.time())})

        ssl_params = {}
        if self.use_ssl:
            ssl_params = {"server_hostname": self.server}

        self._client = MQTTClient(
            client_id=self._client_id,
            server=self.server,
            port=self.port,
            user=self._username,
            password=self.api_key,
            keepalive=60,
            ssl=self.use_ssl,
            ssl_params=ssl_params,
        )

        # Set LWT before connecting
        self._client.set_last_will(will_topic, will_msg, retain=True, qos=1)

        # Set message callback
        self._client.set_callback(self._on_message)

        # Connect
        self._client.connect()
        self._connected = True

        # Subscribe to server -> device topics
        for suffix in ("command", "connected", "trigger_ack",
                       "trigger_result", "error", "pong"):
            topic = self._topic_prefix + suffix
            self._client.subscribe(topic, qos=1)

        # Publish online status (retained -- no secrets)
        online_payload = {
            "status": "online",
            "timestamp": str(time.time()),
        }
        if self.group:
            online_payload["group"] = self.group

        self._client.publish(
            self._topic_prefix + "status",
            json.dumps(online_payload),
            retain=True,
            qos=1,
        )

        # Send API key in separate non-retained message for server-side auth
        self._client.publish(
            self._topic_prefix + "status",
            json.dumps({
                "status": "online",
                "apiKey": self.api_key,
                "group": self.group,
            }),
            retain=False,
            qos=1,
        )

        print("[lua-device] Connected as", self.device_name)

    def disconnect(self):
        """Gracefully disconnect -- publish offline status first."""
        if self._client and self._connected:
            self._client.publish(
                self._topic_prefix + "status",
                json.dumps({"status": "offline", "timestamp": str(time.time())}),
                retain=True,
                qos=1,
            )
            self._client.disconnect()
            self._connected = False
            print("[lua-device] Disconnected")

    def trigger(self, name, payload=None):
        """Fire a trigger to the agent."""
        if not self._connected:
            raise RuntimeError("Not connected")

        msg = json.dumps({
            "triggerName": name,
            "payload": payload or {},
        })
        self._client.publish(
            self._topic_prefix + "trigger",
            msg,
            qos=1,
        )

    def run(self, check_interval_ms=100):
        """
        Main loop -- checks for incoming messages and sends heartbeats.
        Blocks forever. Call this after connect() and registering commands.
        """
        print("[lua-device] Listening for commands...")
        while self._connected:
            try:
                # Check for incoming messages (non-blocking)
                self._client.check_msg()

                # Send heartbeat every 30s
                now = time.time()
                if now - self._last_heartbeat >= self._heartbeat_interval:
                    self._client.publish(
                        self._topic_prefix + "heartbeat",
                        b"",
                        qos=0,
                    )
                    self._last_heartbeat = now

                # Clean expired dedup entries periodically
                if len(self._seen_ids) > 100:
                    self._clean_dedup()

                time.sleep_ms(check_interval_ms)

            except OSError as e:
                print("[lua-device] Connection lost:", e)
                self._reconnect()
            except Exception as e:
                print("[lua-device] Error:", e)
                time.sleep(1)

    def _on_message(self, topic, msg):
        """Callback for incoming MQTT messages."""
        try:
            topic_str = topic.decode() if isinstance(topic, bytes) else topic
            suffix = topic_str.replace(self._topic_prefix, "")

            if suffix == "command":
                self._handle_command(msg)
            elif suffix == "connected":
                data = json.loads(msg)
                print("[lua-device] Server confirmed connection:", data.get("message", ""))
            elif suffix == "trigger_ack":
                data = json.loads(msg)
                print("[lua-device] Trigger ACK:", data.get("triggerId", ""))
            elif suffix == "error":
                data = json.loads(msg)
                print("[lua-device] Error:", data.get("code", ""), data.get("message", ""))
            elif suffix == "pong":
                pass  # latency check response

        except Exception as e:
            print("[lua-device] Message handler error:", e)

    def _handle_command(self, msg):
        """Process an incoming command and publish the response."""
        try:
            data = json.loads(msg)
            command_id = data.get("commandId")
            command = data.get("command")
            payload = data.get("payload", {})

            if not command_id or not command:
                return

            # Idempotency check
            if command_id in self._seen_ids:
                return
            self._seen_ids[command_id] = time.time()

            handler = self._commands.get(command)
            if not handler:
                self._publish_response(command_id, False, error="Unknown command: " + command)
                return

            # Execute handler
            try:
                result = handler(payload)
                self._publish_response(command_id, True, data=result)
            except Exception as e:
                self._publish_response(command_id, False, error=str(e))

        except Exception as e:
            print("[lua-device] Command error:", e)

    def _publish_response(self, command_id, success, data=None, error=None):
        """Publish command response."""
        response = {
            "commandId": command_id,
            "success": success,
        }
        if data is not None:
            response["data"] = data
        if error is not None:
            response["error"] = error

        self._client.publish(
            self._topic_prefix + "response",
            json.dumps(response),
            qos=1,
        )

    def _reconnect(self):
        """Attempt to reconnect with exponential backoff."""
        delay = 1
        max_delay = 30
        while not self._connected:
            try:
                print("[lua-device] Reconnecting in", delay, "s...")
                time.sleep(delay)
                self._client.connect()
                self._connected = True

                # Re-subscribe
                for suffix in ("command", "connected", "trigger_ack",
                               "trigger_result", "error", "pong"):
                    self._client.subscribe(self._topic_prefix + suffix, qos=1)

                # Re-publish online status (retained)
                self._client.publish(
                    self._topic_prefix + "status",
                    json.dumps({"status": "online", "timestamp": str(time.time())}),
                    retain=True,
                    qos=1,
                )
                # Re-send API key (non-retained) for server-side auth
                self._client.publish(
                    self._topic_prefix + "status",
                    json.dumps({
                        "status": "online",
                        "apiKey": self.api_key,
                        "group": self.group,
                    }),
                    retain=False,
                    qos=1,
                )
                print("[lua-device] Reconnected")
            except Exception as e:
                print("[lua-device] Reconnect failed:", e)
                delay = min(delay * 2, max_delay)

    def _clean_dedup(self):
        """Remove expired command IDs from dedup cache."""
        now = time.time()
        expired = [k for k, v in self._seen_ids.items() if now - v > self._dedup_ttl]
        for k in expired:
            del self._seen_ids[k]
