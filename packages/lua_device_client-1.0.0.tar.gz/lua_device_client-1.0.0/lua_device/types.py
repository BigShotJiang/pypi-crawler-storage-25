"""Type definitions for the Lua Device Client."""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Awaitable, Callable, Dict, List, Optional


@dataclass
class DeviceCommandDefinition:
    """Describes a command this device supports (sent at connect time)."""

    name: str
    """Command name (used by agent to invoke)."""

    description: str
    """Human-readable description (shown to the AI agent as tool description)."""

    input_schema: Optional[Dict[str, Any]] = None
    """JSON Schema for command input parameters."""

    timeout_ms: int = 30_000
    """Command timeout in milliseconds."""

    retry: Optional[Dict[str, Any]] = None
    """Retry configuration: {"max_attempts": int, "backoff_ms": int}."""

    def to_dict(self) -> Dict[str, Any]:
        """Serialize to the wire format expected by the server."""
        d: Dict[str, Any] = {"name": self.name, "description": self.description}
        if self.input_schema is not None:
            d["inputSchema"] = self.input_schema
        if self.timeout_ms != 30_000:
            d["timeoutMs"] = self.timeout_ms
        if self.retry is not None:
            d["retry"] = {
                "maxAttempts": self.retry.get("max_attempts", 3),
                "backoffMs": self.retry.get("backoff_ms", 1000),
            }
        return d


@dataclass
class DeviceClientConfig:
    """Configuration for creating a DeviceClient."""

    agent_id: str
    """Agent ID to connect to."""

    api_key: str
    """API key for authentication."""

    device_name: str
    """Unique name for this device."""

    commands: List[DeviceCommandDefinition] = field(default_factory=list)
    """Commands this device supports."""

    mqtt_url: str = "wss://mqtt.heylua.ai/mqtt"
    """MQTT broker URL."""

    cdn_url: str = "https://cdn.heylua.ai"
    """CDN URL for file uploads."""

    group: Optional[str] = None
    """Optional device group."""


@dataclass
class CommandMessage:
    """Command message received from the server."""

    command_id: str
    command: str
    payload: Any = None
    timeout: Optional[int] = None


@dataclass
class ResponseMessage:
    """Response message sent back to the server."""

    command_id: str
    success: bool
    data: Any = None
    error: Optional[str] = None

    def to_dict(self) -> Dict[str, Any]:
        d: Dict[str, Any] = {"commandId": self.command_id, "success": self.success}
        if self.data is not None:
            d["data"] = self.data
        if self.error is not None:
            d["error"] = self.error
        return d


@dataclass
class TriggerAckMessage:
    """Trigger acknowledgment from the server."""

    trigger_id: str
    received: bool
    error: Optional[str] = None


# Type aliases for handler signatures
CommandHandler = Callable[[Any], Awaitable[Any]]
TriggerResultHandler = Callable[[Any], None]
