"""
Lua Device Client -- MQTT-based client for CPython.

Mirrors the behavior of the Node.js MqttTransport:
- Connects to MQTT broker with LWT for disconnect detection
- Sends online status with apiKey (non-retained) and command manifest
- Subscribes to command/connected/trigger_ack/trigger_result/error topics
- Handles incoming commands, calls registered async handlers
- Publishes responses
- Fires triggers with ACK waiting
- Heartbeat every 30s
- CDN upload via httpx
- Auto-reconnect with exponential backoff
"""

from __future__ import annotations

import asyncio
import json
import logging
import ssl
import time
from collections import OrderedDict
from typing import Any, Callable, Dict, Optional
from urllib.parse import urlparse

import paho.mqtt.client as mqtt

from .cdn import CDN
from .types import (
    CommandHandler,
    CommandMessage,
    DeviceClientConfig,
    DeviceCommandDefinition,
    ResponseMessage,
    TriggerAckMessage,
    TriggerResultHandler,
)

logger = logging.getLogger("lua_device")

DEFAULT_MQTT_URL = "wss://mqtt.heylua.ai/mqtt"
HEARTBEAT_INTERVAL_S = 30
TOPIC_PREFIX = "lua/devices/"
DEDUP_MAX_SIZE = 1000
DEDUP_TTL_S = 300  # 5 minutes
TRIGGER_ACK_TIMEOUT_S = 10


class _LRUDedup:
    """Simple LRU cache for command idempotency."""

    def __init__(self, max_size: int = DEDUP_MAX_SIZE, ttl_s: float = DEDUP_TTL_S):
        self._max_size = max_size
        self._ttl_s = ttl_s
        self._cache: OrderedDict[str, tuple[float, ResponseMessage]] = OrderedDict()

    def get(self, key: str) -> Optional[ResponseMessage]:
        entry = self._cache.get(key)
        if entry is None:
            return None
        ts, response = entry
        if time.monotonic() - ts > self._ttl_s:
            del self._cache[key]
            return None
        self._cache.move_to_end(key)
        return response

    def set(self, key: str, response: ResponseMessage) -> None:
        self._cache[key] = (time.monotonic(), response)
        self._cache.move_to_end(key)
        while len(self._cache) > self._max_size:
            self._cache.popitem(last=False)


class DeviceClient:
    """
    Async MQTT device client for Lua AI.

    Usage::

        client = DeviceClient(config)
        client.on_command("read_sensor", handle_read)
        await client.connect()
        ack = await client.trigger("alert", {"level": "high"})
        await client.disconnect()
    """

    def __init__(self, config: Optional[DeviceClientConfig] = None, **kwargs: Any):
        if config is None:
            config = DeviceClientConfig(**kwargs)
        self._config = config
        self._topic_prefix = f"{TOPIC_PREFIX}{config.agent_id}/{config.device_name}/"

        self._command_handlers: Dict[str, CommandHandler] = {}
        self._trigger_result_handlers: Dict[str, TriggerResultHandler] = {}
        self._dedup = _LRUDedup()
        self._connected = False
        self._intentional_disconnect = False
        self._mqtt_client: Optional[mqtt.Client] = None
        self._heartbeat_task: Optional[asyncio.Task] = None
        self._loop: Optional[asyncio.AbstractEventLoop] = None

        # Trigger serialization
        self._trigger_lock = asyncio.Lock()
        self._trigger_ack_future: Optional[asyncio.Future[TriggerAckMessage]] = None

        # Event callbacks
        self._event_handlers: Dict[str, list[Callable]] = {}

        # CDN client
        self.cdn = CDN(config.api_key, config.cdn_url)

    # =========================================================================
    # EVENT SYSTEM
    # =========================================================================

    def on(self, event: str, handler: Callable) -> None:
        """Register an event listener (connected, disconnected, error, trigger_ack, reconnected)."""
        self._event_handlers.setdefault(event, []).append(handler)

    def _emit(self, event: str, *args: Any) -> None:
        for handler in self._event_handlers.get(event, []):
            try:
                handler(*args)
            except Exception:
                logger.exception("Event handler error for '%s'", event)

    # =========================================================================
    # COMMAND REGISTRATION
    # =========================================================================

    def on_command(self, name: str, handler: CommandHandler) -> None:
        """Register an async handler for a command name."""
        self._command_handlers[name] = handler

    def on_trigger_result(self, name: str, handler: TriggerResultHandler) -> None:
        """Register a handler for trigger execution results."""
        self._trigger_result_handlers[name] = handler

    # =========================================================================
    # CONNECT / DISCONNECT
    # =========================================================================

    async def connect(self) -> None:
        """
        Connect to the MQTT broker.

        Resolves when connected and subscriptions are established.
        Auto-reconnects on disconnect unless disconnect() was called.
        """
        self._intentional_disconnect = False
        self._loop = asyncio.get_running_loop()
        url = self._config.mqtt_url or DEFAULT_MQTT_URL
        parsed = urlparse(url)
        host = parsed.hostname or "mqtt.heylua.ai"
        use_ws = parsed.scheme in ("ws", "wss")
        use_tls = parsed.scheme in ("wss", "mqtts", "ssl")
        port = parsed.port or (443 if use_ws and use_tls else 8083 if use_ws else 8883 if use_tls else 1883)
        ws_path = parsed.path or "/mqtt"

        client_id = f"lua-{self._config.agent_id}-{self._config.device_name}"
        self._mqtt_client = mqtt.Client(
            callback_api_version=mqtt.CallbackAPIVersion.VERSION2,
            client_id=client_id,
            clean_session=False,
            protocol=mqtt.MQTTv311,
            transport="websockets" if use_ws else "tcp",
        )

        if use_ws:
            self._mqtt_client.ws_set_options(path=ws_path)

        self._mqtt_client.username_pw_set(
            username=f"{self._config.agent_id}:{self._config.device_name}",
            password=self._config.api_key,
        )

        # LWT
        will_payload = json.dumps({"status": "offline", "timestamp": self._iso_now()})
        self._mqtt_client.will_set(
            topic=f"{self._topic_prefix}status",
            payload=will_payload,
            qos=1,
            retain=True,
        )

        if use_tls:
            self._mqtt_client.tls_set(cert_reqs=ssl.CERT_REQUIRED, tls_version=ssl.PROTOCOL_TLS_CLIENT)

        connect_future: asyncio.Future[None] = self._loop.create_future()
        first_connect = True

        def on_connect(client: mqtt.Client, userdata: Any, flags: Any, rc: Any, properties: Any = None) -> None:
            nonlocal first_connect
            reason_code = rc if isinstance(rc, int) else getattr(rc, "value", rc)
            if reason_code != 0:
                if first_connect and not connect_future.done():
                    self._loop.call_soon_threadsafe(
                        connect_future.set_exception,
                        ConnectionError(f"MQTT connect failed: rc={reason_code}"),
                    )
                return

            self._connected = True

            # Subscribe to server -> device topics
            topics = [(f"{self._topic_prefix}{s}", 1) for s in
                      ("command", "connected", "trigger_ack", "trigger_result", "error")]
            client.subscribe(topics)

            # Publish online status (retained -- no secrets)
            online_payload: Dict[str, Any] = {
                "status": "online",
                "timestamp": self._iso_now(),
            }
            if self._config.group:
                online_payload["group"] = self._config.group
            client.publish(f"{self._topic_prefix}status", json.dumps(online_payload), qos=1, retain=True)

            # Send API key + command manifest (non-retained) for server-side auth
            auth_payload: Dict[str, Any] = {
                "status": "online",
                "apiKey": self._config.api_key,
                "group": self._config.group,
                "commands": [cmd.to_dict() for cmd in self._config.commands],
            }
            client.publish(f"{self._topic_prefix}status", json.dumps(auth_payload), qos=1, retain=False)

            # Start heartbeat
            if self._loop:
                self._loop.call_soon_threadsafe(self._start_heartbeat)

            if first_connect:
                first_connect = False
                if not connect_future.done():
                    self._loop.call_soon_threadsafe(connect_future.set_result, None)
                self._emit("connected")
            else:
                self._emit("reconnected")

        def on_disconnect(client: mqtt.Client, userdata: Any, flags: Any, rc: Any, properties: Any = None) -> None:
            self._connected = False
            self._stop_heartbeat()
            if not self._intentional_disconnect:
                self._emit("disconnected", "connection closed")

        def on_message(client: mqtt.Client, userdata: Any, msg: mqtt.MQTTMessage) -> None:
            if self._loop:
                self._loop.call_soon_threadsafe(self._handle_message, msg.topic, msg.payload)

        self._mqtt_client.on_connect = on_connect
        self._mqtt_client.on_disconnect = on_disconnect
        self._mqtt_client.on_message = on_message

        self._mqtt_client.connect_async(host, port, keepalive=60)
        self._mqtt_client.loop_start()

        await connect_future

    async def disconnect(self) -> None:
        """Gracefully disconnect from the MQTT broker."""
        self._intentional_disconnect = True
        self._connected = False
        self._stop_heartbeat()

        if self._mqtt_client:
            # Publish offline status before disconnecting
            self._mqtt_client.publish(
                f"{self._topic_prefix}status",
                json.dumps({"status": "offline", "timestamp": self._iso_now()}),
                qos=1,
                retain=True,
            )
            self._mqtt_client.loop_stop()
            self._mqtt_client.disconnect()
            self._mqtt_client = None

    def is_connected(self) -> bool:
        """Check if currently connected."""
        return self._connected

    # =========================================================================
    # TRIGGERS (Device -> Agent)
    # =========================================================================

    async def trigger(self, name: str, payload: Any = None) -> TriggerAckMessage:
        """
        Fire a trigger to the agent.

        Serializes concurrent triggers and waits for server ACK.
        Raises TimeoutError if no ACK within 10 seconds.
        """
        if not self._connected or not self._mqtt_client:
            raise RuntimeError("Not connected to MQTT broker")

        async with self._trigger_lock:
            return await self._emit_trigger(name, payload)

    async def _emit_trigger(self, name: str, payload: Any) -> TriggerAckMessage:
        assert self._loop is not None
        self._trigger_ack_future = self._loop.create_future()

        self._mqtt_client.publish(  # type: ignore[union-attr]
            f"{self._topic_prefix}trigger",
            json.dumps({"triggerName": name, "payload": payload or {}}),
            qos=1,
        )

        try:
            return await asyncio.wait_for(self._trigger_ack_future, timeout=TRIGGER_ACK_TIMEOUT_S)
        except asyncio.TimeoutError:
            raise TimeoutError(f"Trigger '{name}' ACK timeout ({TRIGGER_ACK_TIMEOUT_S}s)")
        finally:
            self._trigger_ack_future = None

    # =========================================================================
    # MESSAGE HANDLING
    # =========================================================================

    def _handle_message(self, topic: str, payload: bytes) -> None:
        suffix = topic.replace(self._topic_prefix, "")

        try:
            data = json.loads(payload) if payload else {}
        except (json.JSONDecodeError, ValueError):
            return

        if suffix == "command":
            asyncio.ensure_future(self._handle_command(data))
        elif suffix == "connected":
            pass  # server confirmed connection
        elif suffix == "trigger_ack":
            ack = TriggerAckMessage(
                trigger_id=data.get("triggerId", ""),
                received=data.get("received", False),
                error=data.get("error"),
            )
            self._emit("trigger_ack", ack)
            if self._trigger_ack_future and not self._trigger_ack_future.done():
                self._trigger_ack_future.set_result(ack)
        elif suffix == "trigger_result":
            handler = self._trigger_result_handlers.get(data.get("triggerName", ""))
            if handler:
                handler(data.get("result"))
        elif suffix == "error":
            self._emit("error", data)

    async def _handle_command(self, data: Dict[str, Any]) -> None:
        command_id = data.get("commandId", "")
        command = data.get("command", "")
        payload = data.get("payload")

        # Idempotency check
        cached = self._dedup.get(command_id)
        if cached is not None:
            self._publish_response(cached)
            return

        handler = self._command_handlers.get(command)
        if not handler:
            response = ResponseMessage(command_id=command_id, success=False, error=f"Unknown command: {command}")
            self._dedup.set(command_id, response)
            self._publish_response(response)
            return

        try:
            result = await handler(payload)
            response = ResponseMessage(command_id=command_id, success=True, data=result)
        except Exception as exc:
            response = ResponseMessage(command_id=command_id, success=False, error=str(exc))

        self._dedup.set(command_id, response)
        self._publish_response(response)

    def _publish_response(self, response: ResponseMessage) -> None:
        if self._mqtt_client:
            self._mqtt_client.publish(
                f"{self._topic_prefix}response",
                json.dumps(response.to_dict()),
                qos=1,
            )

    # =========================================================================
    # HEARTBEAT
    # =========================================================================

    def _start_heartbeat(self) -> None:
        self._stop_heartbeat()
        if self._loop:
            self._heartbeat_task = self._loop.create_task(self._heartbeat_loop())

    def _stop_heartbeat(self) -> None:
        if self._heartbeat_task:
            self._heartbeat_task.cancel()
            self._heartbeat_task = None

    async def _heartbeat_loop(self) -> None:
        try:
            while self._connected and self._mqtt_client:
                await asyncio.sleep(HEARTBEAT_INTERVAL_S)
                if self._connected and self._mqtt_client:
                    self._mqtt_client.publish(f"{self._topic_prefix}heartbeat", b"", qos=0)
        except asyncio.CancelledError:
            pass

    # =========================================================================
    # UTILITIES
    # =========================================================================

    @staticmethod
    def _iso_now() -> str:
        from datetime import datetime, timezone
        return datetime.now(timezone.utc).isoformat()
