"""Plotting helpers used by the public MRRProData facade."""

