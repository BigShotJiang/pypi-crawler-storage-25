from __future__ import annotations

from datetime import datetime
from typing import Literal

from pydantic import BaseModel, Field, HttpUrl


FieldType = Literal["String", "Number", "Integer", "Date", "Boolean", "Array", "Object"]
TeamRole = Literal["owner", "admin", "member", "viewer"]
JobStatus = Literal["pending", "extracting", "awaiting_review", "complete", "failed"]
ReviewStatus = Literal["not_requested", "awaiting_review", "reviewed"]
FieldReviewStatus = Literal["not_requested", "pending", "approved", "edited", "flagged"]
ExtractionStatus = Literal["verified", "normalized", "needs-review", "not-found"]


class SchemaField(BaseModel):
    name: str
    display_name: str | None = None
    description: str = ""
    group: str | None = None
    path: str | None = None
    field_type: FieldType | None = None


class SchemaSuggestionEngine(BaseModel):
    provider: str
    model: str
    source_filename: str


class Schema(BaseModel):
    id: str
    name: str
    description: str
    fields: list[SchemaField]
    schema_hash: str
    created_at: datetime
    suggestion_engine: SchemaSuggestionEngine | None = None


class ApiKey(BaseModel):
    id: str
    name: str
    key_prefix: str
    role: TeamRole
    team_id: str
    team_slug: str
    team_name: str
    environment: str
    created_at: datetime
    last_used_at: datetime | None = None
    is_active: bool = True


class ApiKeyCreated(ApiKey):
    token: str


class Webhook(BaseModel):
    id: str
    url: HttpUrl
    description: str
    created_at: datetime


class WebhookTestResult(BaseModel):
    webhook_id: str
    success: bool
    status_code: int | None = None
    response_body: str | None = None
    error_message: str | None = None
    sent_at: datetime


class JobDocument(BaseModel):
    filename: str
    mime_type: str
    page_count: int | None = None
    retention_expires_at: datetime
    deleted_at: datetime | None = None


class JobProcessor(BaseModel):
    provider: str
    name: str
    display_name: str | None = None
    processor_type: str | None = None
    location: str | None = None
    version: str | None = None


class ResultFieldBounds(BaseModel):
    top: float
    left: float
    width: float
    height: float


class ResultFieldCandidate(BaseModel):
    value: str | None = None
    confidence: float | None = None
    page: int | None = None
    snippet: str | None = None
    source_ref: str | None = None
    bounds: ResultFieldBounds | None = None


class ResultField(BaseModel):
    id: str
    group: str
    label: str
    field_type: str
    description: str
    path: str
    value: str | None = None
    original_value: str | None = None
    extraction_status: ExtractionStatus
    review_status: FieldReviewStatus
    review_note: str | None = None
    confidence: float | None = None
    page: int | None = None
    section: str
    snippet: str | None = None
    source_ref: str | None = None
    bounds: ResultFieldBounds | None = None
    candidate_count: int = 0
    candidates: list[ResultFieldCandidate] = Field(default_factory=list)


class ReviewSummary(BaseModel):
    requires_review: bool
    status: ReviewStatus
    reviewer_email: str | None = None
    reviewer_team: str | None = None
    reviewer_name: str | None = None
    reviewed_at: datetime | None = None
    review_url: str | None = None


class ReviewerNotification(BaseModel):
    delivery_kind: Literal["deferred", "resend_email", "suppressed", "disabled", "failed"]
    recipient_email: str
    subject: str | None = None
    sign_in_url: str
    inbox_url: str
    review_job_id: str
    document_filename: str
    team_name: str
    detail_text: str
    provider: Literal["resend"] | None = None
    provider_message_id: str | None = None
    pending_review_count: int | None = None
    deferred_reason: str | None = None
    suppressed_reason: str | None = None
    error_message: str | None = None


class ResultSummary(BaseModel):
    field_count: int
    filled_field_count: int
    flagged_field_count: int
    not_found_field_count: int


class JobCreated(BaseModel):
    id: str
    status: JobStatus
    schema_id: str | None = None
    schema_hash: str
    created_at: datetime
    review_url: str | None = None
    reviewer_notification: ReviewerNotification | None = None
    usage_warning: str | None = None


class JobStatusInfo(BaseModel):
    id: str
    status: JobStatus
    schema_id: str | None = None
    schema_hash: str
    created_at: datetime
    updated_at: datetime
    completed_at: datetime | None = None
    error_message: str | None = None
    result_available: bool
    document: JobDocument
    review: ReviewSummary


class JobReviewRequestResult(JobStatusInfo):
    reviewer_notification: ReviewerNotification | None = None


class JobResult(BaseModel):
    job_id: str
    status: JobStatus
    schema_id: str | None = None
    schema_hash: str
    created_at: datetime
    completed_at: datetime | None = None
    document: JobDocument
    processor: JobProcessor
    review: ReviewSummary
    summary: ResultSummary
    fields: list[ResultField]
