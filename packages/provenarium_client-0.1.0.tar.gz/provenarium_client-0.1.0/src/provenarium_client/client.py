from __future__ import annotations

import json
import mimetypes
import time
from pathlib import Path
from typing import Any, Iterable, Mapping

import httpx

from provenarium_client.errors import (
    ProvenariumHTTPError,
    ProvenariumJobFailedError,
    ProvenariumTimeoutError,
)
from provenarium_client.models import (
    ApiKey,
    ApiKeyCreated,
    JobCreated,
    JobResult,
    JobReviewRequestResult,
    JobStatusInfo,
    Schema,
    SchemaField,
    TeamRole,
    Webhook,
    WebhookTestResult,
)


def _serialize_schema_fields(fields: Iterable[SchemaField | Mapping[str, Any]]) -> list[dict[str, Any]]:
    serialized: list[dict[str, Any]] = []
    for field in fields:
        if isinstance(field, SchemaField):
            serialized.append(field.model_dump(exclude_none=True))
            continue
        serialized.append(SchemaField.model_validate(field).model_dump(exclude_none=True))
    if not serialized:
        raise ValueError("Provide at least one schema field.")
    return serialized


def _guess_mime_type(filename: str) -> str:
    guessed, _ = mimetypes.guess_type(filename)
    return guessed or "application/octet-stream"


DEFAULT_BASE_URL = "https://api.provenarium.com"


class ProvenariumClient:
    def __init__(
        self,
        *,
        api_key: str,
        base_url: str = DEFAULT_BASE_URL,
        timeout: float = 30.0,
        http_client: Any | None = None,
    ) -> None:
        normalized_api_key = api_key.strip()
        if not normalized_api_key:
            raise ValueError("api_key must not be empty.")

        self.base_url = base_url.rstrip("/")
        self.api_key = normalized_api_key
        self.timeout = timeout
        self._owns_http_client = http_client is None
        self._http_client = http_client or httpx.Client(
            base_url=self.base_url,
            timeout=self.timeout,
            follow_redirects=True,
        )

    def close(self) -> None:
        close_method = getattr(self._http_client, "close", None)
        if self._owns_http_client and callable(close_method):
            close_method()

    def __enter__(self) -> "ProvenariumClient":
        return self

    def __exit__(self, exc_type, exc, tb) -> None:
        self.close()

    def list_api_keys(self) -> list[ApiKey]:
        response = self._request("GET", "/api/v1/api-keys")
        payload = response.json()
        return [ApiKey.model_validate(item) for item in payload["items"]]

    def create_api_key(
        self,
        *,
        name: str,
        role: TeamRole = "member",
    ) -> ApiKeyCreated:
        normalized_name = name.strip()
        if not normalized_name:
            raise ValueError("name must not be empty.")

        response = self._request(
            "POST",
            "/api/v1/api-keys",
            json={"name": normalized_name, "role": role},
            expected_status=201,
        )
        return ApiKeyCreated.model_validate(response.json())

    def delete_api_key(self, key_id: str) -> None:
        self._request("DELETE", f"/api/v1/api-keys/{key_id}", expected_status=204)

    def create_schema(
        self,
        *,
        name: str,
        fields: Iterable[SchemaField | Mapping[str, Any]],
        description: str = "",
    ) -> Schema:
        response = self._request(
            "POST",
            "/api/v1/schemas",
            json={
                "name": name,
                "description": description,
                "fields": _serialize_schema_fields(fields),
            },
            expected_status=201,
        )
        return Schema.model_validate(response.json())

    def suggest_schema(
        self,
        *,
        file_path: str | Path,
        name: str | None = None,
        description: str = "",
    ) -> Schema:
        path = Path(file_path)
        data = {}
        if name:
            data["name"] = name
        if description:
            data["description"] = description
        response = self._request(
            "POST",
            "/api/v1/schemas",
            data=data,
            files={
                "file": (
                    path.name,
                    path.read_bytes(),
                    _guess_mime_type(path.name),
                )
            },
            expected_status=201,
        )
        return Schema.model_validate(response.json())

    def list_schemas(self) -> list[Schema]:
        response = self._request("GET", "/api/v1/schemas")
        payload = response.json()
        return [Schema.model_validate(item) for item in payload["items"]]

    def get_schema(self, schema_id: str) -> Schema:
        response = self._request("GET", f"/api/v1/schemas/{schema_id}")
        return Schema.model_validate(response.json())

    def delete_schema(self, schema_id: str) -> None:
        self._request("DELETE", f"/api/v1/schemas/{schema_id}", expected_status=204)

    def create_webhook(self, *, url: str, description: str = "") -> Webhook:
        response = self._request(
            "POST",
            "/api/v1/webhooks",
            json={"url": url, "description": description},
            expected_status=201,
        )
        return Webhook.model_validate(response.json())

    def list_webhooks(self) -> list[Webhook]:
        response = self._request("GET", "/api/v1/webhooks")
        payload = response.json()
        return [Webhook.model_validate(item) for item in payload["items"]]

    def test_webhook(self, webhook_id: str) -> WebhookTestResult:
        response = self._request("POST", f"/api/v1/webhooks/{webhook_id}/test")
        return WebhookTestResult.model_validate(response.json())

    def delete_webhook(self, webhook_id: str) -> None:
        self._request("DELETE", f"/api/v1/webhooks/{webhook_id}", expected_status=204)

    def submit_job(
        self,
        *,
        file_path: str | Path | None = None,
        content: bytes | None = None,
        filename: str | None = None,
        mime_type: str | None = None,
        schema_id: str | None = None,
        schema_fields: Iterable[SchemaField | Mapping[str, Any]] | None = None,
        requires_review: bool = False,
        reviewer_email: str | None = None,
        reviewer_team: str | None = None,
    ) -> JobCreated:
        if (file_path is None) == (content is None):
            raise ValueError("Provide exactly one of file_path or content.")
        if (schema_id is None) == (schema_fields is None):
            raise ValueError("Provide exactly one of schema_id or schema_fields.")

        if file_path is not None:
            path = Path(file_path)
            payload_bytes = path.read_bytes()
            payload_filename = path.name
            payload_mime_type = mime_type or _guess_mime_type(path.name)
        else:
            if content is None:
                raise ValueError("content must not be None when file_path is omitted.")
            if not filename:
                raise ValueError("filename is required when submitting in-memory content.")
            payload_bytes = content
            payload_filename = filename
            payload_mime_type = mime_type or _guess_mime_type(filename)

        data: dict[str, str] = {}
        if schema_id is not None:
            data["schema_id"] = schema_id
        else:
            data["schema"] = json.dumps({"fields": _serialize_schema_fields(schema_fields or [])})
        if requires_review:
            data["requires_review"] = "true"
        if reviewer_email:
            data["reviewer_email"] = reviewer_email
        if reviewer_team:
            data["reviewer_team"] = reviewer_team

        response = self._request(
            "POST",
            "/api/v1/jobs",
            data=data,
            files={"file": (payload_filename, payload_bytes, payload_mime_type)},
            expected_status=202,
        )
        return JobCreated.model_validate(response.json())

    def get_job(self, job_id: str) -> JobStatusInfo:
        response = self._request("GET", f"/api/v1/jobs/{job_id}")
        return JobStatusInfo.model_validate(response.json())

    def get_job_result(self, job_id: str) -> JobResult:
        response = self._request("GET", f"/api/v1/jobs/{job_id}/result")
        return JobResult.model_validate(response.json())

    def request_review(
        self,
        job_id: str,
        *,
        reviewer_email: str,
        reviewer_team: str | None = None,
    ) -> JobReviewRequestResult:
        payload: dict[str, str] = {"reviewer_email": reviewer_email}
        if reviewer_team:
            payload["reviewer_team"] = reviewer_team
        response = self._request(
            "POST",
            f"/api/v1/jobs/{job_id}/request-review",
            json=payload,
        )
        return JobReviewRequestResult.model_validate(response.json())

    def wait_for_result(
        self,
        job_id: str,
        *,
        poll_interval_seconds: float = 2.0,
        timeout_seconds: float | None = 300.0,
    ) -> JobResult:
        if poll_interval_seconds < 0:
            raise ValueError("poll_interval_seconds must be non-negative.")
        if timeout_seconds is not None and timeout_seconds < 0:
            raise ValueError("timeout_seconds must be non-negative or None.")

        deadline = None if timeout_seconds is None else time.monotonic() + timeout_seconds
        while True:
            job = self.get_job(job_id)
            if job.status == "failed":
                raise ProvenariumJobFailedError(
                    job.error_message or "Job failed.",
                    job_id=job.id,
                    error_message=job.error_message,
                )
            if job.status == "complete" and job.result_available:
                return self.get_job_result(job_id)
            if deadline is not None and time.monotonic() >= deadline:
                raise ProvenariumTimeoutError(
                    f"Timed out while waiting for job {job_id} to complete. Last status: {job.status}."
                )
            time.sleep(poll_interval_seconds)

    def _request(
        self,
        method: str,
        path: str,
        *,
        params: Mapping[str, Any] | None = None,
        json: Any = None,
        data: Mapping[str, Any] | None = None,
        files: Any = None,
        expected_status: int | None = None,
    ):
        response = self._http_client.request(
            method,
            path,
            params=params,
            json=json,
            data=data,
            files=files,
            headers={
                "Accept": "application/json",
                "X-API-Key": self.api_key,
            },
        )

        if expected_status is not None:
            valid_statuses = {expected_status}
        else:
            valid_statuses = set(range(200, 300))
        if response.status_code not in valid_statuses:
            detail = None
            try:
                payload = response.json()
            except ValueError:
                payload = None
            if isinstance(payload, dict):
                detail = payload.get("detail")
            elif payload is not None:
                detail = payload

            message = self._format_error_message(response.status_code, detail, response.text)
            raise ProvenariumHTTPError(
                message,
                status_code=response.status_code,
                response_body=response.text,
                detail=detail,
            )
        return response

    @staticmethod
    def _format_error_message(status_code: int, detail: Any, response_text: str) -> str:
        if isinstance(detail, str) and detail.strip():
            return detail.strip()
        if detail is not None:
            return f"Provenarium API returned {status_code}: {json.dumps(detail, sort_keys=True)}"
        if response_text.strip():
            return f"Provenarium API returned {status_code}: {response_text.strip()}"
        return f"Provenarium API returned HTTP {status_code}."
