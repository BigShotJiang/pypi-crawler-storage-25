from __future__ import annotations

from typing import Any


class ProvenariumError(Exception):
    """Base error for the Provenarium Python client."""


class ProvenariumHTTPError(ProvenariumError):
    """Raised when the Provenarium API returns a non-success response."""

    def __init__(
        self,
        message: str,
        *,
        status_code: int,
        response_body: str | None = None,
        detail: Any = None,
    ) -> None:
        super().__init__(message)
        self.status_code = status_code
        self.response_body = response_body
        self.detail = detail


class ProvenariumTimeoutError(ProvenariumError):
    """Raised when polling for a job result times out."""


class ProvenariumJobFailedError(ProvenariumError):
    """Raised when a job reaches the failed terminal state."""

    def __init__(self, message: str, *, job_id: str, error_message: str | None = None) -> None:
        super().__init__(message)
        self.job_id = job_id
        self.error_message = error_message
