from __future__ import annotations

import json

import httpx
import pytest

from provenarium_client import (
    ProvenariumClient,
    ProvenariumHTTPError,
    ProvenariumJobFailedError,
    ProvenariumTimeoutError,
    SchemaField,
)


def _job_created_payload(job_id: str, *, usage_warning: str | None = None) -> dict[str, object]:
    return {
        "id": job_id,
        "status": "complete",
        "schema_id": "schema_123",
        "schema_hash": "schema_hash_123",
        "created_at": "2026-03-23T12:00:00Z",
        "review_url": None,
        "reviewer_notification": None,
        "usage_warning": usage_warning,
    }


def _job_status_payload(job_id: str, *, status: str, error_message: str | None = None) -> dict[str, object]:
    return {
        "id": job_id,
        "status": status,
        "schema_id": "schema_123",
        "schema_hash": "schema_hash_123",
        "created_at": "2026-03-23T12:00:00Z",
        "updated_at": "2026-03-23T12:00:05Z",
        "completed_at": "2026-03-23T12:00:05Z" if status == "complete" else None,
        "error_message": error_message,
        "result_available": status == "complete",
        "document": {
            "filename": "packet.txt",
            "mime_type": "text/plain",
            "page_count": 1,
            "retention_expires_at": "2026-04-22T12:00:00Z",
            "deleted_at": None,
        },
        "review": {
            "requires_review": False,
            "status": "not_requested",
            "reviewer_email": None,
            "reviewer_team": None,
            "reviewer_name": None,
            "reviewed_at": None,
            "review_url": None,
        },
    }


def _reviewer_notification_payload(job_id: str) -> dict[str, object]:
    return {
        "delivery_kind": "resend_email",
        "recipient_email": "reviewer@example.com",
        "subject": "You have a Provenarium review waiting",
        "sign_in_url": "https://review.provenarium.com/sign-in",
        "inbox_url": "https://review.provenarium.com/reviews",
        "review_job_id": job_id,
        "document_filename": "packet.txt",
        "team_name": "Test Team",
        "detail_text": "Open your inbox to review the extraction.",
        "provider": "resend",
        "provider_message_id": "msg_123",
        "pending_review_count": 1,
        "deferred_reason": None,
        "suppressed_reason": None,
        "error_message": None,
    }


def _job_result_payload(job_id: str) -> dict[str, object]:
    return {
        "job_id": job_id,
        "status": "complete",
        "schema_id": "schema_123",
        "schema_hash": "schema_hash_123",
        "created_at": "2026-03-23T12:00:00Z",
        "completed_at": "2026-03-23T12:00:05Z",
        "document": {
            "filename": "packet.txt",
            "mime_type": "text/plain",
            "page_count": 1,
            "retention_expires_at": "2026-04-22T12:00:00Z",
            "deleted_at": None,
        },
        "processor": {
            "provider": "google_document_ai_custom_extractor",
            "name": "custom-extractor",
            "display_name": "custom-extractor",
            "processor_type": "CUSTOM_EXTRACTION_PROCESSOR",
            "location": "us",
            "version": "rc",
        },
        "review": {
            "requires_review": False,
            "status": "not_requested",
            "reviewer_email": None,
            "reviewer_team": None,
            "reviewer_name": None,
            "reviewed_at": None,
            "review_url": None,
        },
        "summary": {
            "field_count": 2,
            "filled_field_count": 2,
            "flagged_field_count": 0,
            "not_found_field_count": 0,
        },
        "fields": [
            {
                "id": "study_id",
                "group": "study_info",
                "label": "Study ID",
                "field_type": "String",
                "description": "Internal study identifier.",
                "path": "study_info.study_id",
                "value": "BNT-PK-042",
                "original_value": None,
                "extraction_status": "verified",
                "review_status": "not_requested",
                "review_note": None,
                "confidence": 0.98,
                "page": 1,
                "section": "Study Info",
                "snippet": "BNT-PK-042",
                "source_ref": "Page 1 · custom extractor entity",
                "bounds": None,
                "candidate_count": 1,
                "candidates": [
                    {
                        "value": "BNT-PK-042",
                        "confidence": 0.98,
                        "page": 1,
                        "snippet": "BNT-PK-042",
                        "source_ref": "Page 1 · custom extractor entity",
                        "bounds": None,
                    }
                ],
            },
            {
                "id": "run_id",
                "group": "assay_run",
                "label": "Run ID",
                "field_type": "String",
                "description": "Instrument run identifier.",
                "path": "assay_run.run_id",
                "value": "PK24-0187",
                "original_value": None,
                "extraction_status": "verified",
                "review_status": "not_requested",
                "review_note": None,
                "confidence": 0.98,
                "page": 1,
                "section": "Assay Run",
                "snippet": "PK24-0187",
                "source_ref": "Page 1 · custom extractor entity",
                "bounds": None,
                "candidate_count": 1,
                "candidates": [
                    {
                        "value": "PK24-0187",
                        "confidence": 0.98,
                        "page": 1,
                        "snippet": "PK24-0187",
                        "source_ref": "Page 1 · custom extractor entity",
                        "bounds": None,
                    }
                ],
            },
        ],
    }


def _schema_payload(schema_id: str, *, suggested: bool = False) -> dict[str, object]:
    payload: dict[str, object] = {
        "id": schema_id,
        "name": "Assay Packet" if not suggested else "Suggested Packet",
        "description": "Fields for assay packets.",
        "fields": [
            {
                "name": "study_id" if not suggested else "run_id",
                "display_name": "Study ID" if not suggested else "Run ID",
                "description": "Internal study identifier." if not suggested else "Instrument run identifier.",
                "group": "study_info" if not suggested else "assay_run",
                "path": "study_info.study_id" if not suggested else "assay_run.run_id",
                "field_type": "String",
            }
        ],
        "schema_hash": "schema_hash_123",
        "created_at": "2026-03-23T12:00:00Z",
        "suggestion_engine": None,
    }
    if suggested:
        payload["suggestion_engine"] = {
            "provider": "openai",
            "model": "gpt-5-nano",
            "source_filename": "packet.pdf",
        }
    return payload


def _api_key_payload(key_id: str) -> dict[str, object]:
    return {
        "id": key_id,
        "name": "Ingestion Bot",
        "key_prefix": "pk_live_1234",
        "role": "member",
        "team_id": "team_123",
        "team_slug": "acme-bio",
        "team_name": "Acme Bio",
        "environment": "production",
        "created_at": "2026-03-23T12:00:00Z",
        "last_used_at": None,
        "is_active": True,
    }


def _webhook_payload(webhook_id: str) -> dict[str, object]:
    return {
        "id": webhook_id,
        "url": "https://example.com/hooks/provenarium",
        "description": "Primary webhook",
        "created_at": "2026-03-23T12:00:00Z",
    }


def _build_http_client(handler) -> httpx.Client:
    transport = httpx.MockTransport(handler)
    return httpx.Client(transport=transport, base_url="http://testserver")


def test_client_schema_job_and_webhook_flow(tmp_path) -> None:
    packet = tmp_path / "packet.txt"
    packet.write_text("Study ID: BNT-PK-042\nRun ID: PK24-0187")

    requests: list[tuple[str, str, bytes]] = []

    def handler(request: httpx.Request) -> httpx.Response:
        body = request.read()
        requests.append((request.method, request.url.path, body))
        assert request.headers["X-API-Key"] == "pk_test_123"

        if request.method == "POST" and request.url.path == "/api/v1/schemas":
            payload = json.loads(body.decode("utf-8"))
            assert payload["name"] == "Assay Packet"
            assert len(payload["fields"]) == 2
            return httpx.Response(201, json=_schema_payload("schema_123"))
        if request.method == "GET" and request.url.path == "/api/v1/schemas":
            return httpx.Response(200, json={"items": [_schema_payload("schema_123")]})
        if request.method == "POST" and request.url.path == "/api/v1/webhooks":
            payload = json.loads(body.decode("utf-8"))
            assert payload["url"] == "https://example.com/hooks/provenarium"
            return httpx.Response(201, json=_webhook_payload("wh_123"))
        if request.method == "POST" and request.url.path == "/api/v1/webhooks/wh_123/test":
            return httpx.Response(
                200,
                json={
                    "webhook_id": "wh_123",
                    "success": True,
                    "status_code": 202,
                    "response_body": "accepted",
                    "error_message": None,
                    "sent_at": "2026-03-23T12:00:05Z",
                },
            )
        if request.method == "GET" and request.url.path == "/api/v1/webhooks":
            if len([item for item in requests if item[0] == "DELETE" and item[1] == "/api/v1/webhooks/wh_123"]) > 0:
                return httpx.Response(200, json={"items": []})
            return httpx.Response(200, json={"items": [_webhook_payload("wh_123")]})
        if request.method == "POST" and request.url.path == "/api/v1/jobs":
            assert b'name="schema_id"' in body
            assert b"schema_123" in body
            assert b'name="file"; filename="packet.txt"' in body
            return httpx.Response(
                202,
                json=_job_created_payload("job_123", usage_warning="Approaching monthly page limit."),
            )
        if request.method == "GET" and request.url.path == "/api/v1/jobs/job_123":
            return httpx.Response(200, json=_job_status_payload("job_123", status="complete"))
        if request.method == "GET" and request.url.path == "/api/v1/jobs/job_123/result":
            return httpx.Response(200, json=_job_result_payload("job_123"))
        if request.method == "POST" and request.url.path == "/api/v1/jobs/job_123/request-review":
            payload = json.loads(body.decode("utf-8"))
            assert payload["reviewer_email"] == "reviewer@example.com"
            response_payload = _job_status_payload("job_123", status="awaiting_review")
            response_payload["review"] = {
                **response_payload["review"],
                "requires_review": True,
                "status": "awaiting_review",
                "reviewer_email": "reviewer@example.com",
                "review_url": "https://review.provenarium.com/reviews/job_123",
            }
            response_payload["reviewer_notification"] = _reviewer_notification_payload("job_123")
            return httpx.Response(200, json=response_payload)
        if request.method == "GET" and request.url.path == "/api/v1/schemas/schema_123":
            return httpx.Response(200, json=_schema_payload("schema_123"))
        if request.method == "DELETE" and request.url.path == "/api/v1/webhooks/wh_123":
            return httpx.Response(204)
        if request.method == "DELETE" and request.url.path == "/api/v1/schemas/schema_123":
            return httpx.Response(204)
        raise AssertionError(f"Unexpected request: {request.method} {request.url.path}")

    http_client = _build_http_client(handler)
    sdk = ProvenariumClient(
        base_url="http://testserver",
        api_key="pk_test_123",
        http_client=http_client,
    )

    schema = sdk.create_schema(
        name="Assay Packet",
        description="Fields for assay packets.",
        fields=[
            SchemaField(
                name="study_id",
                display_name="Study ID",
                description="Internal study identifier.",
                group="study_info",
                path="study_info.study_id",
                field_type="String",
            ),
            SchemaField(
                name="run_id",
                display_name="Run ID",
                description="Instrument run identifier.",
                group="assay_run",
                path="assay_run.run_id",
                field_type="String",
            ),
        ],
    )
    assert schema.id == "schema_123"
    assert sdk.list_schemas()[0].id == "schema_123"

    webhook = sdk.create_webhook(url="https://example.com/hooks/provenarium", description="Primary webhook")
    assert sdk.test_webhook(webhook.id).success is True
    assert sdk.list_webhooks()[0].id == "wh_123"

    job = sdk.submit_job(file_path=packet, schema_id="schema_123")
    assert job.id == "job_123"
    assert job.usage_warning == "Approaching monthly page limit."
    assert sdk.get_job(job.id).status == "complete"
    result = sdk.wait_for_result(job.id, poll_interval_seconds=0.0, timeout_seconds=1.0)
    assert result.summary.field_count == 2
    assert result.fields[0].source_ref == "Page 1 · custom extractor entity"
    review_request = sdk.request_review(job.id, reviewer_email="reviewer@example.com")
    assert review_request.review.status == "awaiting_review"
    assert review_request.reviewer_notification is not None
    assert review_request.reviewer_notification.delivery_kind == "resend_email"

    assert sdk.get_schema("schema_123").name == "Assay Packet"
    sdk.delete_webhook("wh_123")
    assert sdk.list_webhooks() == []
    sdk.delete_schema("schema_123")
    sdk.close()


def test_client_api_key_management_flow() -> None:
    requests: list[tuple[str, str, bytes]] = []

    def handler(request: httpx.Request) -> httpx.Response:
        body = request.read()
        requests.append((request.method, request.url.path, body))
        assert request.headers["X-API-Key"] == "pk_admin_123"

        if request.method == "GET" and request.url.path == "/api/v1/api-keys":
            if any(item[0] == "DELETE" and item[1] == "/api/v1/api-keys/key_123" for item in requests):
                return httpx.Response(200, json={"items": []})
            return httpx.Response(200, json={"items": [_api_key_payload("key_123")]})
        if request.method == "POST" and request.url.path == "/api/v1/api-keys":
            payload = json.loads(body.decode("utf-8"))
            assert payload == {"name": "Ingestion Bot", "role": "member"}
            return httpx.Response(201, json={**_api_key_payload("key_123"), "token": "pk_live_secret_123"})
        if request.method == "DELETE" and request.url.path == "/api/v1/api-keys/key_123":
            return httpx.Response(204)
        raise AssertionError(f"Unexpected request: {request.method} {request.url.path}")

    sdk = ProvenariumClient(
        base_url="http://testserver",
        api_key="pk_admin_123",
        http_client=_build_http_client(handler),
    )

    created = sdk.create_api_key(name="  Ingestion Bot  ", role="member")
    assert created.id == "key_123"
    assert created.token == "pk_live_secret_123"
    assert created.role == "member"
    assert sdk.list_api_keys()[0].team_slug == "acme-bio"

    sdk.delete_api_key("key_123")
    assert sdk.list_api_keys() == []
    sdk.close()


def test_client_inline_schema_and_suggest_schema_flow(tmp_path) -> None:
    packet = tmp_path / "packet.pdf"
    packet.write_bytes(b"%PDF-1.4 demo")

    def handler(request: httpx.Request) -> httpx.Response:
        body = request.read()

        if request.method == "POST" and request.url.path == "/api/v1/schemas":
            content_type = request.headers.get("content-type", "")
            assert "multipart/form-data" in content_type
            assert b'name="name"' in body
            assert b"Suggested Packet" in body
            assert b'name="file"; filename="packet.pdf"' in body
            return httpx.Response(201, json=_schema_payload("schema_suggested", suggested=True))
        if request.method == "POST" and request.url.path == "/api/v1/jobs":
            assert b'name="schema"' in body
            assert b'"fields"' in body
            assert b'"study_id"' in body
            return httpx.Response(202, json=_job_created_payload("job_inline"))
        if request.method == "GET" and request.url.path == "/api/v1/jobs/job_inline":
            return httpx.Response(200, json=_job_status_payload("job_inline", status="complete"))
        if request.method == "GET" and request.url.path == "/api/v1/jobs/job_inline/result":
            return httpx.Response(200, json=_job_result_payload("job_inline"))
        raise AssertionError(f"Unexpected request: {request.method} {request.url.path}")

    sdk = ProvenariumClient(
        base_url="http://testserver",
        api_key="pk_test_123",
        http_client=_build_http_client(handler),
    )

    suggested = sdk.suggest_schema(file_path=packet, name="Suggested Packet")
    assert suggested.suggestion_engine is not None
    assert suggested.fields[0].name == "run_id"

    job = sdk.submit_job(
        content=b"Study ID: BNT-PK-042",
        filename="packet.txt",
        schema_fields=[
            {
                "name": "study_id",
                "display_name": "Study ID",
                "description": "Internal study identifier.",
                "group": "study_info",
                "path": "study_info.study_id",
                "field_type": "String",
            }
        ],
    )
    result = sdk.wait_for_result(job.id, poll_interval_seconds=0.0, timeout_seconds=1.0)
    assert result.fields[0].label == "Study ID"
    sdk.close()


def test_client_wait_for_result_raises_when_job_fails() -> None:
    def handler(request: httpx.Request) -> httpx.Response:
        if request.method == "GET" and request.url.path == "/api/v1/jobs/job_failed":
            return httpx.Response(
                200,
                json=_job_status_payload("job_failed", status="failed", error_message="document ai unavailable"),
            )
        raise AssertionError(f"Unexpected request: {request.method} {request.url.path}")

    sdk = ProvenariumClient(
        base_url="http://testserver",
        api_key="pk_test_123",
        http_client=_build_http_client(handler),
    )

    with pytest.raises(ProvenariumJobFailedError) as exc_info:
        sdk.wait_for_result("job_failed", poll_interval_seconds=0.0, timeout_seconds=1.0)

    assert exc_info.value.job_id == "job_failed"
    assert exc_info.value.error_message == "document ai unavailable"
    sdk.close()


def test_client_create_api_key_rejects_empty_names() -> None:
    sdk = ProvenariumClient(
        base_url="http://testserver",
        api_key="pk_admin_123",
        http_client=_build_http_client(lambda request: httpx.Response(500)),
    )

    with pytest.raises(ValueError, match="name must not be empty"):
        sdk.create_api_key(name="   ")

    sdk.close()


def test_client_raises_http_error_with_api_detail() -> None:
    def handler(request: httpx.Request) -> httpx.Response:
        return httpx.Response(404, json={"detail": "API key not found."})

    sdk = ProvenariumClient(
        base_url="http://testserver",
        api_key="pk_admin_123",
        http_client=_build_http_client(handler),
    )

    with pytest.raises(ProvenariumHTTPError) as exc_info:
        sdk.delete_api_key("missing_key")

    assert exc_info.value.status_code == 404
    assert exc_info.value.detail == "API key not found."
    assert str(exc_info.value) == "API key not found."
    sdk.close()


def test_client_validates_common_inputs(tmp_path) -> None:
    packet = tmp_path / "packet.txt"
    packet.write_text("demo")

    with pytest.raises(ValueError, match="api_key must not be empty"):
        ProvenariumClient(api_key="   ")

    with ProvenariumClient(
        base_url="http://testserver",
        api_key="  pk_test_123  ",
        http_client=_build_http_client(lambda request: httpx.Response(200, json={"items": []})),
    ) as sdk:
        assert sdk.api_key == "pk_test_123"
        assert sdk.list_api_keys() == []

        with pytest.raises(ValueError, match="Provide at least one schema field"):
            sdk.create_schema(name="Empty Schema", fields=[])

        with pytest.raises(ValueError, match="Provide exactly one of file_path or content"):
            sdk.submit_job(
                file_path=packet,
                content=b"demo",
                filename="packet.txt",
                schema_id="schema_123",
            )

        with pytest.raises(ValueError, match="Provide exactly one of schema_id or schema_fields"):
            sdk.submit_job(file_path=packet, schema_id="schema_123", schema_fields=[{"name": "study_id"}])

        with pytest.raises(ValueError, match="filename is required when submitting in-memory content"):
            sdk.submit_job(content=b"demo", schema_fields=[{"name": "study_id"}])

        with pytest.raises(ValueError, match="poll_interval_seconds must be non-negative"):
            sdk.wait_for_result("job_123", poll_interval_seconds=-1.0)

        with pytest.raises(ValueError, match="timeout_seconds must be non-negative or None"):
            sdk.wait_for_result("job_123", timeout_seconds=-1.0)


def test_client_wait_for_result_times_out() -> None:
    def handler(request: httpx.Request) -> httpx.Response:
        if request.method == "GET" and request.url.path == "/api/v1/jobs/job_pending":
            return httpx.Response(200, json=_job_status_payload("job_pending", status="pending"))
        raise AssertionError(f"Unexpected request: {request.method} {request.url.path}")

    sdk = ProvenariumClient(
        base_url="http://testserver",
        api_key="pk_test_123",
        http_client=_build_http_client(handler),
    )

    with pytest.raises(ProvenariumTimeoutError, match="Timed out while waiting for job job_pending to complete"):
        sdk.wait_for_result("job_pending", poll_interval_seconds=0.0, timeout_seconds=0.0)

    sdk.close()


def test_client_submit_job_and_request_review_include_optional_review_fields() -> None:
    def handler(request: httpx.Request) -> httpx.Response:
        body = request.read()
        if request.method == "POST" and request.url.path == "/api/v1/jobs":
            assert b'name="requires_review"' in body
            assert b'true' in body
            assert b'name="reviewer_email"' in body
            assert b'reviewer@example.com' in body
            assert b'name="reviewer_team"' in body
            assert b'qa-team' in body
            return httpx.Response(202, json=_job_created_payload("job_review"))
        if request.method == "POST" and request.url.path == "/api/v1/jobs/job_review/request-review":
            payload = json.loads(body.decode("utf-8"))
            assert payload == {"reviewer_email": "reviewer@example.com", "reviewer_team": "qa-team"}
            response_payload = _job_status_payload("job_review", status="awaiting_review")
            response_payload["reviewer_notification"] = _reviewer_notification_payload("job_review")
            return httpx.Response(200, json=response_payload)
        raise AssertionError(f"Unexpected request: {request.method} {request.url.path}")

    sdk = ProvenariumClient(
        base_url="http://testserver",
        api_key="pk_test_123",
        http_client=_build_http_client(handler),
    )

    created = sdk.submit_job(
        content=b"Study ID: BNT-PK-042",
        filename="packet.unknown",
        schema_fields=[{"name": "study_id"}],
        requires_review=True,
        reviewer_email="reviewer@example.com",
        reviewer_team="qa-team",
    )
    assert created.id == "job_review"

    review_request = sdk.request_review(
        "job_review",
        reviewer_email="reviewer@example.com",
        reviewer_team="qa-team",
    )
    assert review_request.reviewer_notification is not None
    sdk.close()


def test_client_defaults_to_hosted_api_base_url() -> None:
    sdk = ProvenariumClient(api_key="pk_test_123")

    assert sdk.base_url == "https://api.provenarium.com"
    assert str(sdk._http_client.base_url) == "https://api.provenarium.com"

    sdk.close()
