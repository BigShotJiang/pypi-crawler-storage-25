"""Data models for long-form memory system."""

from dataclasses import dataclass, field
from datetime import datetime
from enum import Enum
from typing import Any, Optional


class ContradictionSeverity(str, Enum):
    WARNING = "warning"
    ERROR = "error"


class ContextSource(str, Enum):
    SEMANTIC = "semantic"
    GRAPH = "graph"
    WIKI = "wiki"


@dataclass
class SceneChunk:
    chunk_id: str
    chapter_num: int
    scene_num: int
    content: str
    token_count: int
    characters: list[str] = field(default_factory=list)
    locations: list[str] = field(default_factory=list)
    created_at: datetime = field(default_factory=lambda: datetime.now())

    def to_text(self) -> str:
        return f"[Chapter {self.chapter_num}, Scene {self.scene_num}]\n{self.content}"


@dataclass
class ScoredChunk:
    chunk: SceneChunk
    score: float
    source: ContextSource = ContextSource.SEMANTIC

    def to_text(self) -> str:
        return self.chunk.to_text()


@dataclass
class ContextBlock:
    source: ContextSource
    content: str
    token_count: int
    chapter_num: int
    score: float = 0.0
    metadata: dict[str, Any] = field(default_factory=dict)


@dataclass
class Contradiction:
    contradiction_type: str
    subject: str
    predicate: str
    object_ref: str
    established_in_chapter: int
    new_statement_in_chapter: int
    evidence: str
    new_evidence: str
    severity: ContradictionSeverity = ContradictionSeverity.WARNING
    confidence: float = 0.0


@dataclass
class LongFormStats:
    total_chapters_indexed: int = 0
    total_chunks: int = 0
    total_characters: int = 0
    total_locations: int = 0
    index_size_bytes: int = 0
    last_indexed_chapter: Optional[int] = None
    embedding_model: str = ""
