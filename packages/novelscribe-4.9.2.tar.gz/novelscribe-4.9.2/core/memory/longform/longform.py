"""Long-form memory facade — semantic recall of narrative prose across chapters."""

from __future__ import annotations

import logging
from pathlib import Path
from typing import Optional

from core.memory.longform.chapter_store import ChapterTextStore
from core.memory.longform.config import LongFormConfig
from core.memory.longform.embedding_index import EmbeddingIndex, is_embedding_available
from core.memory.longform.models import (
    ContextBlock,
    Contradiction,
    ContradictionSeverity,
    LongFormStats,
    SceneChunk,
)
from core.memory.longform.reranker import assemble_context, rerank

logger = logging.getLogger("scribe")


class LongFormMemory:
    """Semantic recall of narrative prose across chapters.

    Composes ChapterTextStore (scene storage) + EmbeddingIndex (vector search)
    + reranker (recency + relevance scoring).
    """

    def __init__(
        self,
        project_path: Path,
        config: Optional[LongFormConfig] = None,
    ):
        self._config = config or LongFormConfig()
        store_base = (
            Path(self._config.store_path)
            if self._config.store_path
            else project_path / "memory" / "longform"
        )

        self._store = ChapterTextStore(store_base, self._config)
        self._index = EmbeddingIndex(store_base / "vectors", self._config)
        self._initialized = False

    def _ensure_loaded(self) -> None:
        if self._initialized:
            return
        self._index.load()
        self._initialized = True

    def index_chapter(self, chapter_num: int, content: str) -> list[SceneChunk]:
        if not self._config.enabled:
            logger.debug("Long-form memory disabled, skipping index_chapter(%d)", chapter_num)
            return []

        self._ensure_loaded()

        existing = self._store.load_chapter(chapter_num)
        if existing:
            self._index.remove_chapter(chapter_num)

        chunks = self._store.store_chapter(chapter_num, content)

        if is_embedding_available():
            self._index.add_batch(chunks)
            self._index.save()
            logger.info(
                "Indexed chapter %d: %d scenes, %d total chunks",
                chapter_num,
                len(chunks),
                self._index.size,
            )
        else:
            logger.warning(
                "sentence-transformers not installed; chapter %d stored without embeddings",
                chapter_num,
            )

        return chunks

    def retrieve(
        self,
        query: str,
        chapter_hint: int = 0,
        max_tokens: int = 0,
        cross_chapter_weight: float = 0.0,
    ) -> list[ContextBlock]:
        if not self._config.enabled:
            return []

        self._ensure_loaded()

        if not is_embedding_available() or self._index.size == 0:
            return []

        max_tokens = max_tokens or self._config.max_context_tokens
        top_k = self._config.retrieval_top_k

        scored = self._index.search(query, top_k=top_k)

        if not scored:
            return []

        chapters = self._store.list_chapters()
        total_chapters = max(len(chapters), 1)

        scored = rerank(scored, chapter_hint, total_chapters, self._config)

        self._fill_chunk_content(scored)

        return assemble_context(scored, max_tokens)

    def stats(self) -> LongFormStats:
        self._ensure_loaded()

        chapters = self._store.list_chapters()
        all_chunks: list[SceneChunk] = []
        for ch in chapters:
            all_chunks.extend(self._store.load_chapter(ch))

        characters: set[str] = set()
        locations: set[str] = set()
        for chunk in all_chunks:
            characters.update(chunk.characters)
            locations.update(chunk.locations)

        index_size = 0
        npz = self._index._npz_path()
        if npz.exists():
            index_size = npz.stat().st_size

        return LongFormStats(
            total_chapters_indexed=len(chapters),
            total_chunks=len(all_chunks),
            total_characters=len(characters),
            total_locations=len(locations),
            index_size_bytes=index_size,
            last_indexed_chapter=max(chapters) if chapters else None,
            embedding_model=self._config.embedding_model,
        )

    def remove_chapter(self, chapter_num: int) -> bool:
        self._ensure_loaded()
        removed = self._store.delete_chapter(chapter_num)
        if removed:
            self._index.remove_chapter(chapter_num)
            self._index.save()
        return removed

    def find_contradictions(
        self,
        new_chapter_content: str,
        chapter_num: int,
        knowledge_graph: object | None = None,
    ) -> list[Contradiction]:
        if not self._config.contradiction_check:
            return []

        subjects: set[str] = set()
        for line in new_chapter_content.split("\n"):
            words = line.strip().split()
            if words and words[0][0].isupper() and len(words[0]) > 1:
                subjects.add(words[0])

        if not subjects or knowledge_graph is None:
            return []

        contradictions: list[Contradiction] = []

        for subject in subjects:
            node = knowledge_graph.find_by_name(subject)
            if node is None:
                continue

            rels = knowledge_graph.get_relationships(node.node_id, direction="outgoing")
            if not rels:
                continue

            for edge, target in rels:
                contradictions.append(
                    Contradiction(
                        contradiction_type="established_fact",
                        subject=subject,
                        predicate="exists_in_graph",
                        object_ref=target.name if hasattr(target, "name") else "",
                        established_in_chapter=(
                            edge.metadata.get("chapter", 0)
                            if hasattr(edge, "metadata") and edge.metadata
                            else 0
                        ),
                        new_statement_in_chapter=chapter_num,
                        evidence=f"Graph: {subject} has established relationships",
                        new_evidence=f"New chapter {chapter_num} mentions {subject}",
                        severity=ContradictionSeverity.WARNING,
                        confidence=0.0,
                    )
                )
                break

        return contradictions

    def _fill_chunk_content(self, scored_chunks: list) -> None:
        if not scored_chunks:
            return

        needed_chapters: set[int] = set()
        for sc in scored_chunks:
            needed_chapters.add(
                sc.chunk.chapter_num
                if sc.chunk.chapter_num
                else self._chapter_from_id(sc.chunk.chunk_id)
            )

        chapter_chunks: dict[int, dict[str, SceneChunk]] = {}
        for ch in needed_chapters:
            chunks = self._store.load_chapter(ch)
            chapter_chunks[ch] = {c.chunk_id: c for c in chunks}

        for sc in scored_chunks:
            cid = sc.chunk.chunk_id
            ch = sc.chunk.chapter_num or self._chapter_from_id(cid)
            stored = chapter_chunks.get(ch, {}).get(cid)
            if stored:
                sc.chunk = stored

    @staticmethod
    def _chapter_from_id(chunk_id: str) -> int:
        try:
            return int(chunk_id.split("_")[0][2:])
        except (ValueError, IndexError):
            return 0
