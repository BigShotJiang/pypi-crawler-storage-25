"""Multi-runtime LLM client for novel harness.

Supports OpenAI, Claude, Gemini, Ollama, LM Studio, MiniMax, ZhipuAI (z.ai),
and Moonshot (Kimi) providers.
"""

from __future__ import annotations

import asyncio
import logging
import os  # noqa: F401 — needed for test patch("core.llm_client.os.getenv")
import random
import time
from abc import ABC, abstractmethod
from collections.abc import AsyncIterator, Iterator
from enum import Enum
from typing import TYPE_CHECKING

from pydantic import BaseModel, field_validator

from core.errors import NovelScribeError

if TYPE_CHECKING:
    from core.resilience import CircuitConfig

logger = logging.getLogger(__name__)

_TRANSIENT_STATUS_CODES = {429, 500, 502, 503}
_RETRYABLE_MESSAGES = {"timeout", "timed out", "connection reset", "rate limit"}


def _is_transient_error(exc: LLMError) -> bool:
    """Check if an LLMError is transient and worth retrying."""
    msg = str(exc).lower()
    if any(keyword in msg for keyword in _RETRYABLE_MESSAGES):
        return True
    for code in _TRANSIENT_STATUS_CODES:
        if str(code) in msg:
            return True
    return False


class LLMProvider(Enum):
    """Supported LLM providers."""

    OPENAI = "openai"
    CLAUDE = "claude"
    GEMINI = "gemini"
    OLLAMA = "ollama"
    LM_STUDIO = "lm_studio"
    MINIMAX = "minimax"
    ZHIPU = "zhipu"
    MOONSHOT = "moonshot"


class LLMError(NovelScribeError):
    """Base exception for LLM operations."""


class ProviderNotFoundError(LLMError):
    """Raised when LLM provider is not found."""


class LLMConfig(BaseModel):
    """Configuration for LLM client."""

    provider: str = "openai"
    model: str = "gpt-4o"
    temperature: float = 0.7
    max_tokens: int = 4096
    api_key: str = ""
    base_url: str = ""
    timeout: int = 120
    streaming: bool = False

    @field_validator("temperature")
    @classmethod
    def _validate_temperature(cls, v: float) -> float:
        if not 0.0 <= v <= 2.0:
            raise ValueError("temperature must be between 0.0 and 2.0")
        return v

    @field_validator("max_tokens")
    @classmethod
    def _validate_max_tokens(cls, v: int) -> int:
        if v <= 0:
            raise ValueError("max_tokens must be positive")
        return v

    @field_validator("provider")
    @classmethod
    def _validate_provider(cls, v: str) -> str:
        provider = (v or "").strip()
        if not provider:
            raise ValueError("provider must be a non-empty string")
        return provider


class LLMResponse(BaseModel):
    """Response from LLM provider."""

    content: str
    model: str
    provider: str
    tokens_used: int | None = None
    finish_reason: str | None = None


class LLMClient(ABC):
    """Abstract base class for LLM clients."""

    def __init__(self, config: LLMConfig):
        self.config = config
        self.provider_name = config.provider

    @abstractmethod
    def generate(self, system_prompt: str, user_prompt: str) -> LLMResponse:
        """Generate response from LLM."""

    @abstractmethod
    def generate_with_history(self, messages: list[dict[str, str]]) -> LLMResponse:
        """Generate response from conversation history."""

    @abstractmethod
    def validate_config(self) -> bool:
        """Validate client configuration."""

    def generate_stream(self, system_prompt: str, user_prompt: str) -> Iterator[str]:
        """Stream response tokens from LLM.

        Yields text chunks as they arrive. Providers that do not support
        streaming should override this to raise LLMError.
        """
        raise LLMError(f"Streaming not supported by {self.provider_name}")

    async def generate_async(self, system_prompt: str, user_prompt: str) -> LLMResponse:
        """Async generate response from LLM.

        Default implementation runs the synchronous generate() in a thread pool.
        Providers with native async SDKs should override this.
        """
        return await asyncio.to_thread(self.generate, system_prompt, user_prompt)

    async def generate_with_history_async(self, messages: list[dict[str, str]]) -> LLMResponse:
        """Async generate response from conversation history.

        Default implementation runs the synchronous generate_with_history()
        in a thread pool. Providers with native async SDKs should override this.
        """
        return await asyncio.to_thread(self.generate_with_history, messages)

    async def generate_stream_async(
        self, system_prompt: str, user_prompt: str
    ) -> AsyncIterator[str]:
        """Async stream response tokens from LLM.

        Default implementation wraps the synchronous generator in a thread.
        Providers with native async streaming should override this.
        """
        stream = self.generate_stream(system_prompt, user_prompt)
        for chunk in stream:
            yield chunk
            await asyncio.sleep(0)

    def _format_messages(self, system_prompt: str, user_prompt: str) -> list[dict[str, str]]:
        """Format prompts as message list."""
        messages = []
        if system_prompt:
            messages.append({"role": "system", "content": system_prompt})
        if user_prompt:
            messages.append({"role": "user", "content": user_prompt})
        return messages


# Re-import provider classes from llm_providers package
from core.llm_providers import (  # noqa: E402
    ClaudeClient,
    GeminiClient,
    LMStudioClient,
    MiniMaxClient,
    MoonshotClient,
    OllamaClient,
    OpenAIClient,
    ZhipuClient,
)


class LLMClientFactory:
    """Factory for creating LLM clients."""

    _providers: dict[str, type[LLMClient]] = {
        "openai": OpenAIClient,
        "claude": ClaudeClient,
        "gemini": GeminiClient,
        "ollama": OllamaClient,
        "lm_studio": LMStudioClient,
        "minimax": MiniMaxClient,
        "zhipu": ZhipuClient,
        "moonshot": MoonshotClient,
    }

    @classmethod
    def create(cls, config: LLMConfig) -> LLMClient:
        """Create LLM client from configuration."""
        provider_class = cls._providers.get(config.provider)
        if provider_class is None and config.provider == "lmstudio":
            provider_class = cls._providers.get("lm_studio")

        if not provider_class:
            raise ProviderNotFoundError(f"Unknown LLM provider: {config.provider}")

        return provider_class(config)

    @classmethod
    def register_provider(cls, name: str, provider_class: type[LLMClient]) -> None:
        """Register a new LLM provider."""
        cls._providers[name] = provider_class

    @classmethod
    def list_providers(cls) -> list[str]:
        """List available providers."""
        return list(cls._providers.keys())


class MultiLLMClient:
    """Multi-runtime LLM client with fallback, circuit breaker, and retry support."""

    MAX_RETRIES: int = 3
    BACKOFF_BASE: float = 1.0
    BACKOFF_MAX: float = 30.0

    def __init__(
        self,
        primary_config: LLMConfig,
        fallback_config: LLMConfig | None = None,
        circuit_config: CircuitConfig | None = None,
    ):
        from core.resilience import CircuitBreaker

        self.primary_config = primary_config
        self.fallback_config = fallback_config
        self.primary_client = LLMClientFactory.create(primary_config)
        self.primary_circuit = CircuitBreaker(circuit_config)

        if fallback_config:
            self.fallback_client = LLMClientFactory.create(fallback_config)
            self.fallback_circuit = CircuitBreaker(circuit_config)
        else:
            self.fallback_client = None
            self.fallback_circuit = None

    def _execute_with_fallback(self, primary_fn, fallback_fn=None, *args, **kwargs) -> LLMResponse:
        """Execute an LLM call with circuit breaker, retry, and fallback.

        Args:
            primary_fn: Primary provider callable
            fallback_fn: Fallback provider callable (optional)
            *args: Positional arguments forwarded to fn
            **kwargs: Keyword arguments forwarded to fn

        Returns:
            LLMResponse from the first successful call.

        Raises:
            LLMError: When all providers are unavailable.
        """
        last_error: Exception | None = None

        if self.primary_circuit.can_execute():
            try:
                result = self._retry_transient(primary_fn, *args, **kwargs)
                self.primary_circuit.record_success()
                return result
            except LLMError as exc:
                last_error = exc
                self.primary_circuit.record_failure()
                logger.warning("Primary provider failed: %s", exc)

        if self.fallback_client and self.fallback_circuit and self.fallback_circuit.can_execute():
            try:
                target_fn = fallback_fn if fallback_fn is not None else primary_fn
                result = self._retry_transient(target_fn, *args, **kwargs)
                self.fallback_circuit.record_success()
                return result
            except LLMError as exc:
                last_error = exc
                self.fallback_circuit.record_failure()
                logger.warning("Fallback provider failed: %s", exc)

        raise LLMError(
            f"All LLM providers unavailable. "
            f"Primary circuit: {self.primary_circuit.state.value}, "
            f"Fallback: "
            f"{self.fallback_circuit.state.value if self.fallback_circuit else 'N/A'}. "
            f"Wait for cooldown or check provider status."
        ) from last_error

    async def _execute_with_fallback_async(
        self, primary_fn, fallback_fn=None, *args, **kwargs
    ) -> LLMResponse:
        """Async version of _execute_with_fallback."""
        last_error: Exception | None = None

        if self.primary_circuit.can_execute():
            try:
                result = await self._retry_transient_async(primary_fn, *args, **kwargs)
                self.primary_circuit.record_success()
                return result
            except LLMError as exc:
                last_error = exc
                self.primary_circuit.record_failure()
                logger.warning("Primary provider failed: %s", exc)

        if self.fallback_client and self.fallback_circuit and self.fallback_circuit.can_execute():
            try:
                target_fn = fallback_fn if fallback_fn is not None else primary_fn
                result = await self._retry_transient_async(target_fn, *args, **kwargs)
                self.fallback_circuit.record_success()
                return result
            except LLMError as exc:
                last_error = exc
                self.fallback_circuit.record_failure()
                logger.warning("Fallback provider failed: %s", exc)

        raise LLMError(
            f"All LLM providers unavailable. "
            f"Primary circuit: {self.primary_circuit.state.value}, "
            f"Fallback: "
            f"{self.fallback_circuit.state.value if self.fallback_circuit else 'N/A'}. "
            f"Wait for cooldown or check provider status."
        ) from last_error

    def _retry_transient(self, fn, *args, **kwargs) -> LLMResponse:
        """Retry a sync call on transient errors with exponential backoff + jitter."""
        for attempt in range(self.MAX_RETRIES + 1):
            try:
                return fn(*args, **kwargs)
            except LLMError as exc:
                if not _is_transient_error(exc) or attempt == self.MAX_RETRIES:
                    raise
                delay = min(
                    self.BACKOFF_BASE * (2**attempt) + random.uniform(0, 1), self.BACKOFF_MAX
                )
                logger.info(
                    "Transient error (attempt %d/%d), retrying in %.1fs: %s",
                    attempt + 1,
                    self.MAX_RETRIES + 1,
                    delay,
                    exc,
                )
                time.sleep(delay)

    async def _retry_transient_async(self, fn, *args, **kwargs) -> LLMResponse:
        """Retry an async call on transient errors with exponential backoff + jitter."""
        for attempt in range(self.MAX_RETRIES + 1):
            try:
                return await fn(*args, **kwargs)
            except LLMError as exc:
                if not _is_transient_error(exc) or attempt == self.MAX_RETRIES:
                    raise
                delay = min(
                    self.BACKOFF_BASE * (2**attempt) + random.uniform(0, 1), self.BACKOFF_MAX
                )
                logger.info(
                    "Transient error (attempt %d/%d), retrying in %.1fs: %s",
                    attempt + 1,
                    self.MAX_RETRIES + 1,
                    delay,
                    exc,
                )
                await asyncio.sleep(delay)

    def generate(self, system_prompt: str, user_prompt: str) -> LLMResponse:
        """Generate response with circuit breaker, retry, and fallback."""
        return self._execute_with_fallback(
            self.primary_client.generate,
            self.fallback_client.generate if self.fallback_client else None,
            system_prompt,
            user_prompt,
        )

    async def generate_async(self, system_prompt: str, user_prompt: str) -> LLMResponse:
        """Async generate response with circuit breaker, retry, and fallback."""
        return await self._execute_with_fallback_async(
            self.primary_client.generate_async,
            self.fallback_client.generate_async if self.fallback_client else None,
            system_prompt,
            user_prompt,
        )

    async def generate_with_history_async(self, messages: list[dict[str, str]]) -> LLMResponse:
        """Async generate with history, circuit breaker, retry, and fallback."""
        return await self._execute_with_fallback_async(
            self.primary_client.generate_with_history_async,
            self.fallback_client.generate_with_history_async if self.fallback_client else None,
            messages,
        )

    def generate_with_history(self, messages: list[dict[str, str]]) -> LLMResponse:
        """Generate with history, circuit breaker, retry, and fallback."""
        return self._execute_with_fallback(
            self.primary_client.generate_with_history,
            self.fallback_client.generate_with_history if self.fallback_client else None,
            messages,
        )

    def reset_circuits(self) -> None:
        """Reset all circuit breakers to CLOSED state."""
        self.primary_circuit.reset()
        if self.fallback_circuit:
            self.fallback_circuit.reset()

    async def stream_complete(
        self,
        system_prompt: str,
        user_prompt: str,
        phase: str | None = None,
        project: str | None = None,
    ) -> LLMResponse:
        """Generate response with optional streaming to PipelineEventBus.

        When the primary config has streaming=True, tokens are emitted as chunks
        via the PipelineEventBus as they arrive. When streaming=False (default),
        falls back to standard generate_async() with zero overhead.

        Args:
            system_prompt: System prompt
            user_prompt: User prompt
            phase: Current phase name (for streaming event metadata)
            project: Project name (for streaming event broadcast target)

        Returns:
            LLMResponse with full generated content
        """
        if not self.primary_config.streaming:
            return await self.generate_async(system_prompt, user_prompt)

        from core.streaming import get_streaming_event_bus

        event_bus = get_streaming_event_bus()

        accumulated_content: list[str] = []

        async def _stream_and_collect() -> LLMResponse:
            nonlocal accumulated_content

            if not self.primary_circuit.can_execute():
                raise LLMError(f"Primary circuit is {self.primary_circuit.state.value}")

            try:
                client = self.primary_client

                if hasattr(client, "generate_stream_async"):
                    stream: AsyncIterator[str] = client.generate_stream_async(
                        system_prompt, user_prompt
                    )
                    async for token in stream:
                        accumulated_content.append(token)
                        if project and phase:
                            event_bus.emit_stream_chunk(project, phase, token, is_final=False)
                elif hasattr(client, "generate_stream"):
                    for token in client.generate_stream(system_prompt, user_prompt):
                        accumulated_content.append(token)
                        if project and phase:
                            event_bus.emit_stream_chunk(project, phase, token, is_final=False)
                        import asyncio

                        await asyncio.sleep(0)
                else:
                    raise LLMError(
                        f"Provider {self.primary_config.provider} does not support streaming"
                    )

                if project and phase:
                    event_bus.emit_stream_chunk(project, phase, "", is_final=True)

                return LLMResponse(
                    content="".join(accumulated_content),
                    model=self.primary_config.model,
                    provider=self.primary_config.provider,
                    tokens_used=None,
                    finish_reason="stop",
                )
            except LLMError:
                self.primary_circuit.record_failure()
                raise

        return await self._retry_transient_async(_stream_and_collect)


__all__ = [
    "LLMError",
    "ProviderNotFoundError",
    "LLMConfig",
    "LLMResponse",
    "LLMClient",
    "OpenAIClient",
    "ClaudeClient",
    "GeminiClient",
    "OllamaClient",
    "LMStudioClient",
    "MiniMaxClient",
    "ZhipuClient",
    "MoonshotClient",
    "LLMClientFactory",
    "MultiLLMClient",
]
