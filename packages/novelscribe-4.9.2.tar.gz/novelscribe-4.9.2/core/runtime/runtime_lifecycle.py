"""Runtime lifecycle helpers: checkpoint, hooks, context, subagents, errors, config."""

from enum import Enum
from pathlib import Path
from typing import Any, Optional

from pydantic import BaseModel

from core.errors import NovelScribeError
from core.hooks import HookEventPayload, HookSubscription
from core.runtime.models import RuntimeOutcome, RuntimeState, RuntimeTask, SubagentResult
from core.runtime.subagent_manager import SubagentManager
from core.runtime.turn_checkpoint import RuntimeTurnCheckpointStore


class RuntimeErrorCategory(str, Enum):
    """Unified runtime error categories."""

    TRANSIENT = "transient_error"
    RECOVERABLE_MODEL = "recoverable_model_error"
    USER_FIXABLE = "user_fixable_error"
    UNEXPECTED = "unexpected_error"


class RuntimeExecutionError(NovelScribeError):
    """Typed runtime execution error with explicit category."""

    def __init__(self, message: str, category: RuntimeErrorCategory, retryable: bool = False):
        super().__init__(message)
        self.category = category
        self.retryable = retryable


def classify_exception(exc: Exception) -> tuple[RuntimeErrorCategory, bool]:
    """Classify runtime exception into taxonomy category and retryability."""
    if isinstance(exc, TimeoutError | ConnectionError):
        return RuntimeErrorCategory.TRANSIENT, True
    if isinstance(exc, (PermissionError, ValueError, TypeError)):
        return RuntimeErrorCategory.USER_FIXABLE, False
    if isinstance(exc, RuntimeExecutionError):
        return exc.category, exc.retryable
    return RuntimeErrorCategory.UNEXPECTED, False


def build_error_payload(
    message: str,
    category: RuntimeErrorCategory,
    retryable: bool,
) -> dict[str, Any]:
    """Build structured error payload stored in runtime state metadata."""
    return {
        "error_category": category.value,
        "retryable": retryable,
        "message": message,
    }


class RuntimeConfig(BaseModel):
    """Consolidated configuration for AgentRuntime / RuntimeKernel.

    Extracts the 14-parameter constructor data clump from AgentRuntime.__init__
    into a single injectable object. Preserves backward compatibility — callers
    can still pass individual parameters; the runtime accepts either.
    """

    model_config = {"arbitrary_types_allowed": True}

    prompt_assembler: Optional[Any] = None
    output_parser: Optional[Any] = None
    context_bus: Any = None
    memory_bridge: Optional[Any] = None
    tool_registry: Optional[Any] = None
    tool_executor: Optional[Any] = None
    guardrail_engine: Optional[Any] = None
    turn_checkpoint_store: Optional[Any] = None
    verification_suite: Optional[Any] = None
    subagent_manager: Optional[Any] = None
    hook_event_bus: Optional[Any] = None
    auto_feedback_enabled: bool = True
    max_feedback_rounds: int = 1
    parallel_subagents: bool = False
    concurrency_limit: int = 3


def ensure_checkpoint_store(
    store: RuntimeTurnCheckpointStore | None, task: RuntimeTask
) -> RuntimeTurnCheckpointStore:
    if store is not None:
        return store
    project_dir = task.metadata.get("project_dir")
    checkpoint_dir = (
        Path(project_dir) / ".runtime_checkpoints"
        if project_dir
        else Path.cwd() / ".runtime_checkpoints"
    )
    return RuntimeTurnCheckpointStore(checkpoint_dir=checkpoint_dir)


def save_checkpoint(
    store: RuntimeTurnCheckpointStore | None,
    task: RuntimeTask,
    state: RuntimeState,
    phase: str,
) -> None:
    if store is None:
        return
    store.save(task=task, state=state, phase=phase)


def load_latest_state(
    store: RuntimeTurnCheckpointStore | None, task_id: str
) -> RuntimeState | None:
    if store is None:
        return None
    return store.load_latest_state(task_id)


def emit_runtime_hook(
    event_bus: Any,
    event: str,
    task: RuntimeTask,
    state: RuntimeState,
    metadata: dict[str, Any],
    subscriptions: list[HookSubscription],
    *,
    raise_on_required_failure: bool = True,
) -> None:
    if not subscriptions:
        return
    payload = HookEventPayload(event=event, context_id=task.task_id, metadata=metadata)
    report = event_bus.dispatch(
        event=event,
        payload=payload,
        subscriptions=subscriptions,
        raise_on_required_failure=raise_on_required_failure,
    )
    reports = state.metadata.setdefault("runtime_hook_reports", [])
    if isinstance(reports, list):
        reports.append(report.model_dump(mode="json"))


def resolve_runtime_subscriptions(task: RuntimeTask) -> list[HookSubscription]:
    raw_subscriptions = task.metadata.get("hooks_subscriptions", [])
    if not isinstance(raw_subscriptions, list):
        return []
    subscriptions: list[HookSubscription] = []
    for item in raw_subscriptions:
        if isinstance(item, HookSubscription):
            subscriptions.append(item)
            continue
        if isinstance(item, dict):
            try:
                subscriptions.append(HookSubscription(**item))
            except Exception:
                continue
    return subscriptions


def build_context(context_bus: Any, task: RuntimeTask) -> tuple[str, dict[str, Any]]:
    if context_bus is None:
        return "", {}

    try:
        result = context_bus.build_context_with_metadata(
            agent_name=task.agent_name,
            provider=task.provider,
            model_config=task.llm_config,
        )
        metadata = {
            "original_tokens": result.original_tokens,
            "compressed_tokens": result.compressed_tokens,
            "tier_used": str(result.tier_used),
        }
        return result.context_str, metadata
    except Exception:
        return "", {}


def build_memory_context(
    memory_bridge: Any,
    task: RuntimeTask,
    state: RuntimeState,
    context_str: str,
) -> tuple[str, dict[str, Any]]:
    memory_text = ""
    metadata: dict[str, Any] = {}
    if memory_bridge is not None:
        memory_text, metadata = memory_bridge.build_memory_context(task, state)

    if context_str:
        context_block = f"### Runtime Context\n{context_str}"
        memory_text = f"{context_block}\n\n{memory_text}".strip()

    return memory_text, metadata


def build_history_context(state: RuntimeState) -> str:
    recent = state.conversation_history[-6:]
    if not recent:
        return ""
    return "\n".join(
        f"- {item.get('role', 'unknown')}: {item.get('content', '')}" for item in recent
    ).strip()


def write_memory(
    memory_bridge: Any,
    task: RuntimeTask,
    state: RuntimeState,
    final_output: str,
) -> None:
    if memory_bridge is None:
        return
    memory_bridge.writeback(task, state, final_output)


def execute_subagents_if_needed(
    task: RuntimeTask,
    state: RuntimeState,
    subagent_manager: Any,
    runtime_ref: Any,
) -> RuntimeOutcome | None:
    if task.metadata.get("is_subagent"):
        return None

    manager = subagent_manager or SubagentManager()
    parsed_tasks = manager.parse_tasks(task.metadata.get("subagents"))
    if not parsed_tasks:
        return None

    batch = manager.execute(
        parsed_tasks, runner=lambda sub_task: _run_subagent(sub_task, task, runtime_ref)
    )
    state.metadata["subagent_execution"] = batch.model_dump(mode="json")

    failed = [record for record in batch.records if not record.success]
    if failed:
        first_error = failed[0].error or "Subagent execution failed"
        return RuntimeOutcome(
            success=False,
            turns_executed=0,
            final_output=None,
            error=first_error,
            state=state,
        )

    if batch.teammate_notes:
        teammate_context = "\n".join(batch.teammate_notes)
        task.user_input = f"{task.user_input}\n\nSubagent teammate context:\n{teammate_context}"

    if batch.handoff_output:
        state.last_final_output = batch.handoff_output
        state.finished = True
        return RuntimeOutcome(
            success=True,
            turns_executed=0,
            final_output=batch.handoff_output,
            state=state,
        )

    return None


def _run_subagent(sub_task: Any, parent_task: RuntimeTask, runtime_ref: Any) -> Any:
    from core.runtime._agent_runtime import AgentRuntime

    child_runtime = AgentRuntime(
        infer_fn=runtime_ref._infer_fn,
        config=RuntimeConfig(
            prompt_assembler=runtime_ref._prompt_assembler,
            output_parser=runtime_ref._output_parser,
            context_bus=runtime_ref._context_bus,
            memory_bridge=runtime_ref._memory_bridge,
            tool_registry=runtime_ref._tool_registry,
            tool_executor=runtime_ref._tool_executor,
            guardrail_engine=runtime_ref._guardrail_engine,
            turn_checkpoint_store=runtime_ref._turn_checkpoint_store,
            verification_suite=runtime_ref._verification_suite,
            subagent_manager=None,
            hook_event_bus=runtime_ref._hook_event_bus,
            auto_feedback_enabled=runtime_ref._auto_feedback_enabled,
            max_feedback_rounds=runtime_ref._max_feedback_rounds,
        ),
    )
    merged_metadata = dict(parent_task.metadata)
    merged_metadata.update(sub_task.metadata)
    merged_metadata.update(
        {
            "is_subagent": True,
            "parent_task_id": parent_task.task_id,
            "subagent_name": sub_task.name,
        }
    )
    child_task = RuntimeTask(
        user_input=sub_task.user_input,
        system_prompt=sub_task.system_prompt or parent_task.system_prompt,
        agent_name=parent_task.agent_name,
        provider=parent_task.provider,
        llm_config=dict(parent_task.llm_config),
        tool_definitions=list(parent_task.tool_definitions),
        memory_query=parent_task.memory_query,
        max_turns=sub_task.max_turns,
        metadata=merged_metadata,
    )
    child_state = RuntimeState()
    outcome = child_runtime.run_turn_loop(child_task, child_state)
    return SubagentResult(
        name=sub_task.name,
        mode=sub_task.mode,
        task_id=child_task.task_id,
        success=outcome.success,
        turns_executed=outcome.turns_executed,
        final_output=outcome.final_output,
        error=outcome.error,
        replay_events=list(child_state.conversation_history),
    )
