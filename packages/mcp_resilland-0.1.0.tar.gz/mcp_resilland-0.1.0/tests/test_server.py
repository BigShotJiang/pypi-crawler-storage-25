"""
Minimal smoke tests. Verifies:
  - package imports cleanly
  - FastMCP instance is constructed
  - all expected tools / resources / prompts are registered
  - httpx client module raises helpful error when API key missing
"""

from __future__ import annotations

import pytest


def test_package_imports() -> None:
    import mcp_resilland

    assert mcp_resilland.__version__ == "0.1.0"


def test_server_instance_builds() -> None:
    from mcp_resilland.server import mcp

    assert mcp is not None
    assert mcp.name == "resilland-intelligence"


async def test_tools_registered() -> None:
    from mcp_resilland.server import mcp

    tool_names = {t.name for t in await mcp.list_tools()}

    expected = {
        "get_balance",
        "list_models",
        "list_parcels",
        "get_parcel",
        "list_nurseries",
        "get_nursery",
        "analyze_area",
        "generate_feasibility_report",
        "translate_brief",
    }
    missing = expected - tool_names
    assert not missing, f"expected tools missing: {missing}"


async def test_resources_and_templates_registered() -> None:
    from mcp_resilland.server import mcp

    resources = {str(r.uri) for r in await mcp.list_resources()}
    templates = {t.uri_template for t in await mcp.list_resource_templates()}

    assert "resiland://info" in resources
    assert "resiland://nurseries" in resources

    assert "resiland://parcels/{parcel_id}" in templates
    assert "resiland://species/{species_id}" in templates
    assert "resiland://climate/{country}" in templates


async def test_prompts_registered() -> None:
    from mcp_resilland.server import mcp

    prompt_names = {p.name for p in await mcp.list_prompts()}
    assert "restoration_brief" in prompt_names
    assert "species_matchmaker" in prompt_names


def test_client_requires_api_key(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.delenv("RESILLAND_API_KEY", raising=False)

    from mcp_resilland import client

    with pytest.raises(RuntimeError, match="RESILLAND_API_KEY"):
        client.make_client()


def test_client_reads_base_url(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setenv("RESILLAND_API_KEY", "rsi_live_test")
    monkeypatch.setenv("RESILLAND_BASE_URL", "http://localhost:8000")

    from mcp_resilland import client

    c = client.make_client()
    try:
        assert str(c.base_url).rstrip("/") == "http://localhost:8000"
        assert c.headers["Authorization"] == "Bearer rsi_live_test"
    finally:
        # Not entering async context manager; cancel the underlying transport
        # synchronously so httpx doesn't complain at GC time.
        import httpx

        if isinstance(c, httpx.AsyncClient):
            try:
                import asyncio

                asyncio.new_event_loop().run_until_complete(c.aclose())
            except Exception:
                pass
