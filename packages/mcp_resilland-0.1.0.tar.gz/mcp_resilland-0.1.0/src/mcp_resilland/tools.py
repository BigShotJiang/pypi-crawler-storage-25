"""
MCP tools — functions Claude can call via the Model Context Protocol.

Every tool is a thin wrapper over an HTTP endpoint on the RESILAND
Intelligence backend. Heavy work (Opus 4.7, PostGIS, pgvector RAG) happens
server-side; here we only validate arguments and pass them through.
"""

from __future__ import annotations

from typing import Any

from fastmcp import FastMCP

from mcp_resilland import client


def register(mcp: FastMCP) -> None:
    """Attach every tool decorator to the shared mcp instance."""

    # ── Discovery ─────────────────────────────────────────────────────

    @mcp.tool
    async def get_balance() -> dict:
        """Return the current API key's quota state, totals, and scopes."""
        return await client.get("/v1/public/balance")

    @mcp.tool
    async def list_models() -> dict:
        """List available LLM + embedding models and supported locales/countries."""
        return await client.get("/v1/public/models")

    # ── Parcels ───────────────────────────────────────────────────────

    @mcp.tool
    async def list_parcels(
        country: str | None = None,
        viloyat: str | None = None,
        tuman: str | None = None,
        bbox: str | None = None,
        limit: int = 100,
    ) -> dict:
        """
        List cadastral forest parcels.

        Args:
            country: ISO-3166 alpha-3 (UZB, KAZ, KGZ, TJK, TKM)
            viloyat: Regional / provincial name (e.g. 'Samarqand viloyati')
            tuman:   District name (e.g. "Pastdarg'om")
            bbox:    'west,south,east,north' in EPSG:4326
            limit:   max rows (default 100, capped at 500)
        """
        return await client.get(
            "/v1/public/parcels",
            {
                "country": country,
                "viloyat": viloyat,
                "tuman": tuman,
                "bbox": bbox,
                "limit": limit,
            },
        )

    @mcp.tool
    async def get_parcel(parcel_id: int) -> dict:
        """
        Fetch full detail for a single parcel by integer id:
        cadastral attributes, geometry, centroid, nearest nurseries,
        and cached OSM infrastructure proximity (nearest road / settlement /
        water body).
        """
        return await client.get(f"/v1/public/parcels/{parcel_id}")

    # ── Nurseries ─────────────────────────────────────────────────────

    @mcp.tool
    async def list_nurseries(
        country: str | None = None,
        category: str | None = None,
    ) -> dict:
        """
        List forestry nurseries across the RESILAND region.

        Args:
            country:  ISO-3166 alpha-3
            category: RESILAND-9 | newly-established-18 | forestry-agency | existing
        """
        return await client.get(
            "/v1/public/nurseries",
            {"country": country, "category": category},
        )

    @mcp.tool
    async def get_nursery(nursery_id: str) -> dict:
        """Fetch full detail for a single nursery by UUID."""
        return await client.get(f"/v1/public/nurseries/{nursery_id}")

    # ── Intelligence ──────────────────────────────────────────────────

    @mcp.tool
    async def analyze_area(
        parcel_id: int | None = None,
        cadastral_number: str | None = None,
        nursery_id: str | None = None,
        geojson: dict | None = None,
        query: str | None = None,
        locale: str = "en",
        depth: str = "standard",
    ) -> dict:
        """
        Build a structured spatial context for this area. Returns a JSON payload
        containing:
          - subject (parcel / nursery / drawn polygon)
          - cadastral attributes
          - up to 5 nearest-neighbor parcels
          - up to 5 nearest nurseries with distance (km)
          - 12-month NDVI history (if cached)
          - country-level climate snapshot (ERA5 / CHIRPS / SPI / FWI)
          - OSM infrastructure proximity (road / settlement / water)
          - species fit scores from the curated Central Asia catalog
          - top-K semantic Phase 4 / handbook chunks (pgvector RAG)

        Exactly one of `parcel_id | cadastral_number | nursery_id | geojson`
        must be provided. `query` focuses the RAG retrieval (e.g. "drought
        tolerant halophytes"). `depth` is `shallow | standard | deep`.

        Locales: `en | tr | ru | uz`.
        """
        area: dict[str, Any] = {}
        if parcel_id is not None:
            area["parcel_id"] = parcel_id
        if cadastral_number:
            area["cadastral_number"] = cadastral_number
        if nursery_id:
            area["nursery_id"] = nursery_id
        if geojson:
            area["geojson"] = geojson
        if not area:
            raise ValueError(
                "Provide exactly one of parcel_id, cadastral_number, "
                "nursery_id, or geojson."
            )
        return await client.post(
            "/v1/public/analyze",
            {"area": area, "query": query, "locale": locale, "depth": depth},
        )

    @mcp.tool
    async def generate_feasibility_report(
        parcel_id: int | None = None,
        cadastral_number: str | None = None,
        nursery_id: str | None = None,
        geojson: dict | None = None,
        locale: str = "en",
    ) -> dict:
        """
        Generate a full Phase 4-style feasibility report with Opus 4.7.

        Returns markdown body, source citations (with pgvector similarity),
        token usage, and cost in USD. Typical output is 1,800-2,500 words
        across 10 standard sections (Executive Summary, Site Context,
        Ecological Assessment, Species Plan, Nursery Linkages, Risks,
        Monitoring Plan, Timeline, Budget indication, Sources).

        Exactly one area-reference parameter is required. `locale`:
        `en | tr | ru | uz`.
        """
        area: dict[str, Any] = {}
        if parcel_id is not None:
            area["parcel_id"] = parcel_id
        if cadastral_number:
            area["cadastral_number"] = cadastral_number
        if nursery_id:
            area["nursery_id"] = nursery_id
        if geojson:
            area["geojson"] = geojson
        if not area:
            raise ValueError(
                "Provide exactly one of parcel_id, cadastral_number, "
                "nursery_id, or geojson."
            )
        return await client.post(
            "/v1/public/report/feasibility",
            {"area": area, "locale": locale},
        )

    @mcp.tool
    async def translate_brief(
        text: str,
        target_lang: str,
        source_lang: str | None = None,
        preserve_markdown: bool = True,
    ) -> dict:
        """
        Translate forestry / policy text across the four supported languages
        (Sonnet 4.6, markdown-preserving).

        Args:
            text:             source text (up to 20,000 characters)
            target_lang:      'en' | 'tr' | 'ru' | 'uz'
            source_lang:      optional hint for the translator
            preserve_markdown: keep headings, lists, links intact
        """
        return await client.post(
            "/v1/public/translate",
            {
                "text": text,
                "target_lang": target_lang,
                "source_lang": source_lang,
                "preserve_markdown": preserve_markdown,
            },
        )
