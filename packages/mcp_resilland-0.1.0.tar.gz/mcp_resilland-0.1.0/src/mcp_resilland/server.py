"""
FastMCP server for RESILAND Intelligence.

Loaded capabilities
-------------------
  Tools      — discovery, parcels, nurseries, analysis, report, translate
  Resources  — parcel, nurseries collection, species, climate per country
  Prompts    — restoration_brief, species_matchmaker

Everything proxies `/v1/public/*` on the RESILAND backend. The backend handles
auth, quotas, RAG, Opus 4.7, and all heavy lifting; this server's job is to
expose those capabilities in MCP protocol terms.
"""

from __future__ import annotations

from fastmcp import FastMCP

from mcp_resilland import prompts, resources, tools

mcp = FastMCP(
    name="resilland-intelligence",
    instructions=(
        "RESILAND Intelligence — AI-powered spatial intelligence for the "
        "World Bank's $256M RESILAND CA+ landscape restoration program. "
        "Use these tools to analyze any cadastral forest parcel, drawn "
        "polygon, or existing nursery across Central Asia — Uzbekistan, "
        "Kazakhstan, Kyrgyzstan, Tajikistan, Turkmenistan — and produce "
        "Phase 4-style feasibility reports, NDVI history, species fit, "
        "infrastructure proximity (road / settlement / water) and "
        "pgvector-backed semantic search over policy documents.\n\n"
        "All heavy computation (Opus 4.7, PostGIS, RAG) runs on the RESILAND "
        "backend. This server proxies public API endpoints."
    ),
)

# Register tool / resource / prompt modules onto the shared mcp instance.
tools.register(mcp)
resources.register(mcp)
prompts.register(mcp)

__all__ = ["mcp"]
