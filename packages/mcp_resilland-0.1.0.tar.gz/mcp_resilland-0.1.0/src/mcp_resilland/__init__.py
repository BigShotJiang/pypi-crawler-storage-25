"""
mcp-resilland — Model Context Protocol server for RESILAND Intelligence.

Exposes AI-powered spatial intelligence for landscape restoration across
Central Asia (Uzbekistan · Kazakhstan · Kyrgyzstan · Tajikistan · Turkmenistan)
to Claude Desktop, Cursor, Continue, Windsurf, and any other MCP-compatible
client.

All capabilities proxy the public `/v1/public/*` API on the configured
RESILAND Intelligence backend, authenticating with a user-issued API key
(`rsi_live_*`).
"""

__version__ = "0.1.0"
__all__ = ["__version__"]
