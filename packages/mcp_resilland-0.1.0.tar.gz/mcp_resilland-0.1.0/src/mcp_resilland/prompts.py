"""
MCP prompts — pre-canned conversation starters the user can select from
their MCP client's prompt picker. Each prompt returns a list of messages
the client will seed into the chat.

Available prompts
-----------------
    restoration_brief      — produce a restoration recommendation for an area
    species_matchmaker     — pick tree species for given site conditions
"""

from __future__ import annotations

from fastmcp import FastMCP


def register(mcp: FastMCP) -> None:
    """Attach every prompt decorator to the shared mcp instance."""

    @mcp.prompt()
    def restoration_brief(
        area_reference: str,
        locale: str = "en",
    ) -> str:
        """
        Produce a structured restoration recommendation for a given area.

        Args:
            area_reference:
                Something the AI can hand to `analyze_area` — either a
                `parcel_id=123`, a `cadastral_number="10:41:..."`, a
                `nursery_id="<uuid>"`, or raw GeoJSON pasted inline.
            locale: en | tr | ru | uz (output language)
        """
        return (
            "You are RESILAND Intelligence's restoration advisor. Using the "
            "MCP tools below, produce a concise (under 600 words) "
            "restoration brief for the following area:\n\n"
            f"    area_reference = {area_reference}\n"
            f"    locale         = {locale}\n\n"
            "Steps:\n"
            "1. Call `analyze_area(...)` with the area reference to pull "
            "   the full spatial context (cadastral, NDVI, climate, OSM "
            "   infrastructure, species fit, policy RAG).\n"
            "2. From the returned context, write the brief in "
            f"   {locale!r} with these sections:\n"
            "     • Site Context (location, administrative hierarchy, area)\n"
            "     • Climate & NDVI Signal (last 12 months vs. baseline)\n"
            "     • Infrastructure Access (road / town / water km)\n"
            "     • Recommended Species (3-5 top fits with rationale)\n"
            "     • Nursery Linkages (2-3 nearest with distance)\n"
            "     • Top Risks (2-3 evidence-backed)\n"
            "     • Next Actions (3 concrete steps)\n"
            "3. Cite sources by document title where policy_rag chunks are "
            "   used. Quote numbers precisely.\n"
            "4. If any tool returns empty / error, say so explicitly — "
            "   do not fabricate."
        )

    @mcp.prompt()
    def species_matchmaker(
        country: str,
        annual_rainfall_mm: int | None = None,
        mean_temp_c: float | None = None,
        soil_ph: float | None = None,
        elevation_m: int | None = None,
        ecosystem_hint: str | None = None,
        locale: str = "en",
    ) -> str:
        """
        Recommend tree / shrub species for a given set of site conditions,
        grounded in the RESILAND curated species catalog.

        Args:
            country:             ISO-3166 alpha-3 (UZB / KAZ / KGZ / TJK / TKM)
            annual_rainfall_mm:  observed or planned precipitation
            mean_temp_c:         mean annual temperature °C
            soil_ph:             approximate soil pH (acidic ~5 → alkaline ~9)
            elevation_m:         site elevation in meters
            ecosystem_hint:      free text (e.g. "sandy desert", "riparian
                                 tugai", "mountain juniper belt")
            locale: en | tr | ru | uz
        """
        conditions: list[str] = [f"country = {country.upper()}"]
        if annual_rainfall_mm is not None:
            conditions.append(f"annual_rainfall_mm = {annual_rainfall_mm}")
        if mean_temp_c is not None:
            conditions.append(f"mean_temp_c = {mean_temp_c}")
        if soil_ph is not None:
            conditions.append(f"soil_ph = {soil_ph}")
        if elevation_m is not None:
            conditions.append(f"elevation_m = {elevation_m}")
        if ecosystem_hint:
            conditions.append(f"ecosystem_hint = {ecosystem_hint!r}")

        conditions_block = "\n    " + "\n    ".join(conditions)

        return (
            "You are RESILAND Intelligence's species-matchmaking assistant.\n\n"
            "Site conditions:"
            f"{conditions_block}\n\n"
            "Workflow:\n"
            "1. Call `analyze_area` with a drawn polygon centered in the "
            "   specified country (if no geometry is available, omit "
            "   geojson and set `depth='shallow'` — it will still return "
            "   species_fit candidates).\n"
            "2. Rank the returned species against the given site "
            "   conditions using:\n"
            "     • climate_profile.mean_annual_temp_C window vs. "
            "       `mean_temp_c`\n"
            "     • climate_profile.mean_annual_precip_mm window vs. "
            "       `annual_rainfall_mm`\n"
            "     • climate_profile.elevation_m window vs. `elevation_m`\n"
            "     • climate_profile.soil_ph window vs. `soil_ph`\n"
            "     • tolerances.drought and .salinity for aridity match\n"
            "     • ecosystems intersection with `ecosystem_hint`\n"
            "3. Present top 5 matches in "
            f"{locale!r} with a one-paragraph rationale each, plus the "
            "restoration.priority flag ('CRITICAL' / 'HIGH' / etc.) when "
            "present.\n"
            "4. Flag invasive / non-native species explicitly."
        )
