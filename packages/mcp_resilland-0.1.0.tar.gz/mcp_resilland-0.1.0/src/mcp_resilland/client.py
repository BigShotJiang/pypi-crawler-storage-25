"""
Thin async HTTP client for the RESILAND Intelligence public API.

Reads:
    RESILLAND_API_KEY   — required  (rsi_live_*)
    RESILLAND_BASE_URL  — optional  (default: https://api.resilland.com)

Endpoints are under `/v1/public/*` and authenticate via Bearer token.

Keeping this as its own module makes testing trivial (see tests/) and keeps
the MCP server file focused on tool / resource / prompt declarations.
"""

from __future__ import annotations

import os
from typing import Any

import httpx

from mcp_resilland import __version__

DEFAULT_BASE_URL = "https://api.resilland.com"


def _require_api_key() -> str:
    key = os.environ.get("RESILLAND_API_KEY", "").strip()
    if not key:
        raise RuntimeError(
            "RESILLAND_API_KEY environment variable is not set. "
            "Create a key at https://resilland.com/settings/api-keys"
        )
    return key


def _base_url() -> str:
    return os.environ.get("RESILLAND_BASE_URL", DEFAULT_BASE_URL).rstrip("/")


def make_client() -> httpx.AsyncClient:
    """Build an async client with RESILAND auth + UA headers pre-loaded."""
    return httpx.AsyncClient(
        base_url=_base_url(),
        headers={
            "Authorization": f"Bearer {_require_api_key()}",
            "User-Agent": f"mcp-resilland/{__version__}",
            "Accept": "application/json",
        },
        timeout=httpx.Timeout(connect=10.0, read=120.0, write=30.0, pool=5.0),
    )


async def get(path: str, params: dict[str, Any] | None = None) -> dict:
    async with make_client() as c:
        r = await c.get(path, params=_clean(params))
        r.raise_for_status()
        return r.json()


async def post(path: str, body: dict) -> dict:
    async with make_client() as c:
        r = await c.post(path, json=body)
        r.raise_for_status()
        return r.json()


def _clean(params: dict[str, Any] | None) -> dict[str, Any] | None:
    if not params:
        return None
    return {k: v for k, v in params.items() if v is not None}
