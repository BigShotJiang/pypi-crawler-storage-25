"""Entrypoint: `mcp-resilland` console script + `python -m mcp_resilland`."""

from mcp_resilland.server import mcp


def main() -> None:
    mcp.run()


if __name__ == "__main__":
    main()
