"""
MCP resources — read-only, URI-addressable views of RESILAND data.

Unlike tools (which the AI decides to call), resources are things the host
can surface in a sidebar, autocomplete, or "attach this to the chat" picker.
Each resource returns serialized JSON; MCP clients render / pass it along.

URI patterns
------------
    resiland://info                         — server version + runtime config
    resiland://parcels/{parcel_id}          — single parcel detail
    resiland://nurseries                    — all nurseries (list)
    resiland://species/{species_id}         — tree_species entry (curated)
    resiland://climate/{country}            — country-level climate snapshot
"""

from __future__ import annotations

import json
from typing import Any

from fastmcp import FastMCP

from mcp_resilland import __version__, client


def register(mcp: FastMCP) -> None:
    """Attach every resource decorator to the shared mcp instance."""

    @mcp.resource("resiland://info")
    async def info() -> str:
        """
        Server capabilities, version, and runtime config.
        Useful as a first call to confirm connectivity.
        """
        import os

        return json.dumps(
            {
                "name": "mcp-resilland",
                "version": __version__,
                "description": (
                    "MCP server for RESILAND Intelligence — spatial AI "
                    "for Central Asia landscape restoration"
                ),
                "api_base": os.environ.get("RESILLAND_BASE_URL", "https://api.resilland.com"),
                "api_key_set": bool(os.environ.get("RESILLAND_API_KEY")),
                "countries": ["UZB", "KAZ", "KGZ", "TJK", "TKM"],
                "locales": ["en", "tr", "ru", "uz"],
                "upstream_docs": "https://resilland.com/docs/api",
            },
            indent=2,
        )

    @mcp.resource("resiland://parcels/{parcel_id}")
    async def parcel_resource(parcel_id: str) -> str:
        """A single cadastral forest parcel (geometry + attributes + nearest OSM + nurseries)."""
        data = await client.get(f"/v1/public/parcels/{parcel_id}")
        return json.dumps(data, ensure_ascii=False, default=str)

    @mcp.resource("resiland://nurseries")
    async def nurseries_resource() -> str:
        """Full nurseries collection across the RESILAND region as GeoJSON-like."""
        data = await client.get("/v1/public/nurseries")
        return json.dumps(data, ensure_ascii=False, default=str)

    @mcp.resource("resiland://species/{species_id}")
    async def species_resource(species_id: str) -> str:
        """
        Curated tree / shrub species entry including climate profile,
        tolerances, performance, restoration use-cases, and per-country
        nursery availability (bolge_curated payload merged with base
        tree_species columns).
        """
        # Backend does not yet have a dedicated /v1/public/species endpoint
        # — use the `info` tool path on analyze-area which surfaces species_fit.
        # Graceful fallback: call /v1/public/species/{id} if available,
        # otherwise derive from list_parcels metadata.
        try:
            data = await client.get(f"/v1/public/species/{species_id}")
            return json.dumps(data, ensure_ascii=False, default=str)
        except Exception as exc:  # noqa: BLE001
            return json.dumps(
                {
                    "error": "species endpoint not implemented on this backend",
                    "detail": str(exc),
                    "workaround": (
                        "Call analyze_area(parcel_id=…) to get species_fit "
                        "results scoped to an area."
                    ),
                }
            )

    @mcp.resource("resiland://climate/{country}")
    async def climate_resource(country: str) -> str:
        """
        Country-level climate indicators sourced from Enis regional_data
        documents (ERA5 temperature, CHIRPS precipitation, GWIS FWI fire
        danger, SPI-3 drought, WRI water stress, Hansen tree-cover loss,
        MODIS dust, soil moisture).

        country: ISO-3166 alpha-3 (UZB / KAZ / KGZ / TJK / TKM)
        """
        # Climate is nested inside analyze_area for now — issue a lightweight
        # analyze call scoped at country level.
        try:
            data = await client.post(
                "/v1/public/analyze",
                {
                    "area": {"country": country.upper()},
                    "depth": "shallow",
                    "locale": "en",
                },
            )
            climate = data.get("context", {}).get("climate")
            return json.dumps(
                climate or {"country": country.upper(), "climate": None},
                ensure_ascii=False,
                default=str,
            )
        except Exception as exc:  # noqa: BLE001
            return json.dumps({"country": country.upper(), "error": str(exc)})
