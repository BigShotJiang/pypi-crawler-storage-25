"""DataFrame / pandas utilities."""
