"""luvmagitoolkits: modular Python toolkit."""

__version__ = "0.1.1"
