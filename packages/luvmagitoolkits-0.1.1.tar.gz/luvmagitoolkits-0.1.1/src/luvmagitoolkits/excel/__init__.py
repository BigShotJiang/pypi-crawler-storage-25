"""Excel utilities (openpyxl + pandas)."""
