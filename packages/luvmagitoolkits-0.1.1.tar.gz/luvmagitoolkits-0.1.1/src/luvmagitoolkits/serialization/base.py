import yaml
import json
import inspect
import logging
import types
from enum import Enum
from pathlib import Path
from typing import get_origin, get_args, Optional, Type, TypeVar, Any, Union
from dataclasses import dataclass, fields, asdict

logger = logging.getLogger(__name__)
_T = TypeVar("_T", bound="JsonMixin")

class _EnumEncoder(json.JSONEncoder):
    def default(self, obj):
        if isinstance(obj, Enum):
            return obj.value
        return super().default(obj)

def _resolve_type(field_type: Any) -> Any:
    """Resolve the actual type from Optional/Union."""
    origin = get_origin(field_type)
    if origin is Union or origin is types.UnionType:
        # Get all non-None types from the Union
        args = [arg for arg in get_args(field_type) if arg is not type(None)]
        # For simplicity in this mixin, we take the first valid type
        # (e.g. for Optional[MyModel], we take MyModel)
        if args:
            return args[0]
    return field_type

@dataclass
class JsonMixin:

    @classmethod
    def load_dict(cls: Type[_T], data: dict) -> _T:
        kwargs = {}
        for f in fields(cls):
            value = data.get(f.name)
            if value is None:
                kwargs[f.name] = None
                continue

            actual_type = _resolve_type(f.type)
            origin_type = get_origin(actual_type)

            if inspect.isclass(actual_type):
                if issubclass(actual_type, JsonMixin) and isinstance(value, dict):
                    kwargs[f.name] = actual_type.load_dict(value)
                elif issubclass(actual_type, Enum):
                    try:
                        kwargs[f.name] = actual_type(value)
                    except ValueError:
                        kwargs[f.name] = value # Or handle error appropriately
                else:
                    kwargs[f.name] = value
            elif origin_type is list and isinstance(value, list):
                args = get_args(actual_type)
                if args:
                    element_type = _resolve_type(args[0])
                    if inspect.isclass(element_type):
                        if issubclass(element_type, JsonMixin):
                            kwargs[f.name] = [element_type.load_dict(item) if isinstance(item, dict) else item for item in value]
                        elif issubclass(element_type, Enum):
                            kwargs[f.name] = [element_type(item) for item in value]
                        else:
                            kwargs[f.name] = value
                    else:
                        kwargs[f.name] = value
                else:
                    kwargs[f.name] = value
            else:
                kwargs[f.name] = value
                
        return cls(**kwargs)  # type: ignore[call-arg]

    @classmethod
    def load_file(cls: Type[_T], path: Path, encoding: str = "utf-8-sig") -> Optional[_T]:
        if not path.is_file():
            logger.error(f'{path} is not a file')
            return None
        try:
            with path.open(encoding=encoding) as f:
                if path.suffix.lower() in ['.json']:
                    return cls.load_dict(json.load(f))
                elif path.suffix.lower() in ['.yml', '.yaml']:
                    return cls.load_dict(yaml.safe_load(f))
                else:
                    logger.error(f'{path} is not a json/yaml file')
                    return None
        except Exception:  # noqa: BLE001
            logger.exception(f'failed to load {path}')
            return None

    def save_file(self, path: Path, encoding: str = 'utf-8-sig') -> None:
        path.parent.mkdir(parents=True, exist_ok=True)
        
        # asdict doesn't automatically use Enum values like json.dumps does with cls=_EnumEncoder
        # But yaml.safe_dump might struggle with Enums, so we serialize it to dict first if needed, 
        # or we rely on the encoder for JSON.
        
        if path.suffix.lower() in ['.json']:
            with path.open('w', encoding=encoding) as f:
                json.dump(asdict(self), f, ensure_ascii=False, indent=4, cls=_EnumEncoder)
        elif path.suffix.lower() in ['.yml', '.yaml']:
            # For YAML, we need to handle Enum serialization since PyYAML doesn't natively dump Enum values simply.
            # A quick hack is to roundtrip through JSON to resolve Enums and nested objects.
            dict_repr = json.loads(json.dumps(asdict(self), cls=_EnumEncoder))
            with path.open('w', encoding=encoding) as f:
                yaml.safe_dump(dict_repr, f, allow_unicode=True, sort_keys=False)
        else:
             logger.error(f'{path} is not a json/yaml file')

    def to_json_string(self) -> str:
        return json.dumps(asdict(self), ensure_ascii=False, indent=4, cls=_EnumEncoder)