"""General utilities (clipboard, YAML, TOML)."""
