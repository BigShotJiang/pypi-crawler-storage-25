"""Public API for the decotextual toolkit."""

from ._linear import Linear
from ._stop import (
    StopRequested,
    interruptible_sleep,
    is_stop_requested,
    raise_if_stopped,
)
from .decorators import get_registry, register_tool, tool_method


def run_tui() -> None:
    """Launch the Textual app only when the optional TUI dependency is installed."""
    try:
        from .deco_app import run_tui as _run_tui
    except ModuleNotFoundError as exc:
        missing_name = getattr(exc, "name", "")
        if missing_name in {"textual", "rich"}:
            raise ModuleNotFoundError(
                "run_tui() requires the optional TUI dependencies. "
                'Install them with: pip install "luvmagitoolkits[tui]"'
            ) from exc
        raise

    _run_tui()


__all__ = [
    "register_tool",
    "tool_method",
    "run_tui",
    "Linear",
    "get_registry",
    "StopRequested",
    "interruptible_sleep",
    "is_stop_requested",
    "raise_if_stopped",
]
