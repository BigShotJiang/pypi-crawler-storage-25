"""Cooperative cancellation support for tool methods.

Python threads cannot be safely force-killed, so the TUI's Stop button
signals a ``threading.Event`` instead. Tool methods opt in by calling
``raise_if_stopped()`` at interruption points, or by using
``interruptible_sleep()`` in place of ``time.sleep()``.
"""
from __future__ import annotations

import threading

_stop_event = threading.Event()


class StopRequested(Exception):
    """Raised when the user clicks Stop in the TUI."""


def is_stop_requested() -> bool:
    """Return ``True`` if the user has clicked Stop since the current run started."""
    return _stop_event.is_set()


def raise_if_stopped() -> None:
    """Raise :class:`StopRequested` if the user has clicked Stop.

    Sprinkle this inside long-running tool methods at safe interruption points.
    """
    if _stop_event.is_set():
        raise StopRequested()


def interruptible_sleep(seconds: float) -> None:
    """Sleep up to ``seconds`` seconds; raise :class:`StopRequested` on Stop.

    Drop-in replacement for ``time.sleep`` that returns immediately when
    the user clicks Stop instead of blocking for the full duration.
    """
    if _stop_event.wait(seconds):
        raise StopRequested()


# ---- internal, called by ToolkitApp -----------------------------------------


def _reset() -> None:
    _stop_event.clear()


def _signal_stop() -> None:
    _stop_event.set()
