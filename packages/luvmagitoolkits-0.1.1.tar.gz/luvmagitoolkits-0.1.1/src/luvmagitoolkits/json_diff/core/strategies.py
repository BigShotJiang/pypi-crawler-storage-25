from __future__ import annotations

import hashlib
import json
from typing import Any, Iterator

from .key_detector import infer_primary_key

MatchedPair = tuple[Any, Any, str, "int | None", "int | None"]


def resolve_strategy(
    old_arr: list[Any],
    new_arr: list[Any],
    configured_keys: list[str] | None,
    strategy: str,
) -> tuple[str, list[str] | None]:
    """Decide which matching strategy to use for a given array pair.

    Returns (strategy_name, resolved_keys). ``resolved_keys`` is only used
    when strategy_name is ``"key"``.
    """
    if strategy == "key":
        return "key", configured_keys
    if strategy == "hash":
        return "hash", None
    if strategy == "index":
        return "index", None

    if configured_keys is not None:
        return "key", configured_keys

    inferred = infer_primary_key(old_arr, new_arr)
    if inferred is not None:
        return "key", inferred

    return "hash", None


def match_by_key(
    old_arr: list[dict[str, Any]],
    new_arr: list[dict[str, Any]],
    keys: list[str],
) -> Iterator[MatchedPair]:
    """Match dict-elements by composite primary key.

    Yields (old_el, new_el, segment, old_index, new_index). ``segment`` is
    the path fragment like ``[endpoint=/a,method=GET]``. ``old_el`` is
    ``None`` for add, ``new_el`` is ``None`` for remove.
    """
    old_map: dict[str, tuple[int, dict[str, Any]]] = {}
    for i, el in enumerate(old_arr):
        ident = _make_identifier(el, keys)
        old_map[ident] = (i, el)

    seen: set[str] = set()
    for i, el in enumerate(new_arr):
        ident = _make_identifier(el, keys)
        seen.add(ident)
        segment = f"[{ident}]"
        if ident in old_map:
            old_i, old_el = old_map[ident]
            yield old_el, el, segment, old_i, i
        else:
            yield None, el, segment, None, i

    for ident, (old_i, old_el) in old_map.items():
        if ident in seen:
            continue
        yield old_el, None, f"[{ident}]", old_i, None


def match_by_hash(
    old_arr: list[Any], new_arr: list[Any]
) -> Iterator[MatchedPair]:
    """Set-like matching by stable content hash.

    Only emits ``add`` / ``remove`` pairs — never ``change`` — because
    hash-matched elements are by definition identical.
    """
    old_hashes: dict[str, tuple[int, Any]] = {}
    for i, el in enumerate(old_arr):
        old_hashes.setdefault(_stable_hash(el), (i, el))

    new_hashes: dict[str, tuple[int, Any]] = {}
    for i, el in enumerate(new_arr):
        new_hashes.setdefault(_stable_hash(el), (i, el))

    common = old_hashes.keys() & new_hashes.keys()
    for h, (i, el) in new_hashes.items():
        if h not in common:
            yield None, el, f"[{i}]", None, i
    for h, (i, el) in old_hashes.items():
        if h not in common:
            yield el, None, f"[{i}]", i, None


def match_by_index(
    old_arr: list[Any], new_arr: list[Any]
) -> Iterator[MatchedPair]:
    """Match by positional index. Differences in order produce spurious diffs."""
    for i in range(max(len(old_arr), len(new_arr))):
        old_el = old_arr[i] if i < len(old_arr) else None
        new_el = new_arr[i] if i < len(new_arr) else None
        segment = f"[{i}]"
        if i >= len(old_arr):
            yield None, new_el, segment, None, i
        elif i >= len(new_arr):
            yield old_el, None, segment, i, None
        else:
            yield old_el, new_el, segment, i, i


def _make_identifier(el: dict[str, Any], keys: list[str]) -> str:
    return ",".join(f"{k}={el.get(k)}" for k in keys)


def _stable_hash(obj: Any) -> str:
    payload = json.dumps(obj, sort_keys=True, ensure_ascii=False, default=str)
    return hashlib.sha256(payload.encode("utf-8")).hexdigest()
