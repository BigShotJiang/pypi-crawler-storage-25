from __future__ import annotations

import json
import re
from pathlib import Path
from typing import Any

from ..schema.config import ArrayStrategy, DifferConfig
from ..schema.result import DiffEntry, DiffOp, DiffResult
from . import strategies as _strat


class JsonDiffer:
    """Compare two JSON-serializable documents and report structural diffs.

    Array elements are matched in this priority order when ``array_strategy``
    is ``"auto"``:

    1. ``key_map`` configured for the array path
    2. Auto-inferred single primary-key field
    3. Content hash (set semantics, only add/remove)
    4. Positional index (last-resort, order-sensitive)
    """

    def __init__(
        self,
        key_map: dict[str, list[str]] | None = None,
        ignore_paths: list[str] | None = None,
        array_strategy: ArrayStrategy = "auto",
    ) -> None:
        self.config = DifferConfig(
            key_map=key_map or {},
            ignore_paths=ignore_paths or [],
            array_strategy=array_strategy,
        )

    def diff(self, old: Any, new: Any) -> DiffResult:
        result = DiffResult()
        self._walk(old, new, path="", pointer="", result=result)
        return result

    def diff_files(
        self,
        old_path: Path | str,
        new_path: Path | str,
        encoding: str = "utf-8-sig",
    ) -> DiffResult:
        old = json.loads(Path(old_path).read_text(encoding=encoding))
        new = json.loads(Path(new_path).read_text(encoding=encoding))
        return self.diff(old, new)

    # ------------------------------------------------------------------
    # walk
    # ------------------------------------------------------------------

    def _walk(
        self, old: Any, new: Any, path: str, pointer: str, result: DiffResult
    ) -> None:
        if self._is_ignored(path):
            return
        if isinstance(old, dict) and isinstance(new, dict):
            self._walk_dict(old, new, path, pointer, result)
        elif isinstance(old, list) and isinstance(new, list):
            self._walk_list(old, new, path, pointer, result)
        elif old != new:
            result.entries.append(
                DiffEntry(op=DiffOp.CHANGE, path=path, pointer=pointer, old=old, new=new)
            )

    def _walk_dict(
        self,
        old: dict[str, Any],
        new: dict[str, Any],
        path: str,
        pointer: str,
        result: DiffResult,
    ) -> None:
        for k, v in new.items():
            child_path = f"{path}.{k}" if path else k
            child_pointer = f"{pointer}/{_escape_pointer(k)}"
            if self._is_ignored(child_path):
                continue
            if k not in old:
                result.entries.append(
                    DiffEntry(op=DiffOp.ADD, path=child_path, pointer=child_pointer, new=v)
                )
            else:
                self._walk(old[k], v, child_path, child_pointer, result)

        for k, v in old.items():
            if k in new:
                continue
            child_path = f"{path}.{k}" if path else k
            child_pointer = f"{pointer}/{_escape_pointer(k)}"
            if self._is_ignored(child_path):
                continue
            result.entries.append(
                DiffEntry(op=DiffOp.REMOVE, path=child_path, pointer=child_pointer, old=v)
            )

    def _walk_list(
        self,
        old: list[Any],
        new: list[Any],
        path: str,
        pointer: str,
        result: DiffResult,
    ) -> None:
        configured_keys = self._lookup_key_map(path)
        strategy, resolved_keys = _strat.resolve_strategy(
            old, new, configured_keys, self.config.array_strategy
        )

        if strategy == "key":
            pairs = _strat.match_by_key(old, new, resolved_keys or [])
        elif strategy == "hash":
            pairs = _strat.match_by_hash(old, new)
        else:
            pairs = _strat.match_by_index(old, new)

        for old_el, new_el, segment, old_i, new_i in pairs:
            child_path = f"{path}{segment}"
            if old_el is None:
                child_pointer = f"{pointer}/{new_i}"
                result.entries.append(
                    DiffEntry(op=DiffOp.ADD, path=child_path, pointer=child_pointer, new=new_el)
                )
            elif new_el is None:
                child_pointer = f"{pointer}/{old_i}"
                result.entries.append(
                    DiffEntry(op=DiffOp.REMOVE, path=child_path, pointer=child_pointer, old=old_el)
                )
            else:
                child_pointer = f"{pointer}/{new_i}"
                self._walk(old_el, new_el, child_path, child_pointer, result)

    # ------------------------------------------------------------------
    # config helpers
    # ------------------------------------------------------------------

    def _lookup_key_map(self, path: str) -> list[str] | None:
        normalized = _strip_array_segments(path)
        if normalized in self.config.key_map:
            return self.config.key_map[normalized]
        for pattern, keys in self.config.key_map.items():
            if _match_dict_pattern(pattern, normalized):
                return keys
        return None

    def _is_ignored(self, path: str) -> bool:
        if not path:
            return False
        normalized = _strip_array_segments(path)
        for pattern in self.config.ignore_paths:
            if pattern == normalized or _match_dict_pattern(pattern, normalized):
                return True
        return False


def _escape_pointer(key: str) -> str:
    """Escape a dict key for RFC 6901 JSON Pointer."""
    return key.replace("~", "~0").replace("/", "~1")


_ARRAY_SEG = re.compile(r"\[[^\]]*\]")


def _strip_array_segments(path: str) -> str:
    return _ARRAY_SEG.sub("", path)


def _match_dict_pattern(pattern: str, path: str) -> bool:
    """Match a dot-separated path. ``*`` matches exactly one dict segment."""
    pat_segs = pattern.split(".")
    path_segs = path.split(".")
    if len(pat_segs) != len(path_segs):
        return False
    return all(p == "*" or p == s for p, s in zip(pat_segs, path_segs))
