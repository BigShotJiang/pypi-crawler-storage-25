from __future__ import annotations

from typing import Any

PREFERRED_KEYS: tuple[str, ...] = ("id", "uuid", "key", "name", "code", "slug")


def _is_primitive(v: Any) -> bool:
    return isinstance(v, (str, int, float, bool)) or v is None


def infer_primary_key(old_arr: list[Any], new_arr: list[Any]) -> list[str] | None:
    """Infer a single primary-key field shared by all elements of both arrays.

    Returns a list with one field name that uniquely identifies every element
    on both sides, or ``None`` if no such field exists.

    Composite keys are not auto-inferred to avoid false positives; configure
    ``key_map`` explicitly when a composite key is needed.
    """
    merged = old_arr + new_arr
    if not merged:
        return None
    if not all(isinstance(x, dict) for x in merged):
        return None

    common_keys: set[str] | None = None
    for el in merged:
        el_keys = {k for k, v in el.items() if _is_primitive(v)}
        common_keys = el_keys if common_keys is None else common_keys & el_keys
    if not common_keys:
        return None

    ordered = [k for k in PREFERRED_KEYS if k in common_keys] + sorted(
        k for k in common_keys if k not in PREFERRED_KEYS
    )

    for k in ordered:
        if _unique_on(old_arr, k) and _unique_on(new_arr, k):
            return [k]
    return None


def _unique_on(arr: list[dict[str, Any]], key: str) -> bool:
    values = [el[key] for el in arr]
    return len(set(values)) == len(values)
