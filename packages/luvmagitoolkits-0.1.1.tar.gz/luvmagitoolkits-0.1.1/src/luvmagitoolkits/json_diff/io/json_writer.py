from __future__ import annotations

import json
from pathlib import Path

from ..schema.result import DiffResult


def to_json(
    result: DiffResult,
    path: Path | str,
    encoding: str = "utf-8-sig",
    indent: int = 2,
) -> None:
    """Write a DiffResult to a JSON file."""
    payload = json.dumps(
        result.to_dict(), ensure_ascii=False, indent=indent, default=str
    )
    Path(path).write_text(payload, encoding=encoding)
