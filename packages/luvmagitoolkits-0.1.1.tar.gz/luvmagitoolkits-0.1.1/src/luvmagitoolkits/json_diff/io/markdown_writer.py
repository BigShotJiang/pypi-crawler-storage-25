from __future__ import annotations

import json
from pathlib import Path
from typing import Any

from ..schema.result import DiffOp, DiffResult


def to_markdown(
    result: DiffResult,
    path: Path | str,
    encoding: str = "utf-8-sig",
    title: str = "JSON Diff Report",
) -> None:
    """Write a DiffResult to a Markdown report file."""
    s = result.summary
    lines: list[str] = [
        f"# {title}",
        "",
        f"**Summary** — added: {s['added']}, removed: {s['removed']}, changed: {s['changed']}",
        "",
    ]

    sections = [
        ("Added", DiffOp.ADD, result.added),
        ("Removed", DiffOp.REMOVE, result.removed),
        ("Changed", DiffOp.CHANGE, result.changed),
    ]
    for title_, op, bucket in sections:
        if not bucket:
            continue
        lines.append(f"## {title_} ({len(bucket)})")
        lines.append("")
        if op is DiffOp.CHANGE:
            lines.append("| Path | Old | New |")
            lines.append("|---|---|---|")
            for e in bucket:
                lines.append(
                    f"| `{e.path}` | `{_fmt(e.old)}` | `{_fmt(e.new)}` |"
                )
        else:
            lines.append("| Path | Value |")
            lines.append("|---|---|")
            for e in bucket:
                value = e.new if op is DiffOp.ADD else e.old
                lines.append(f"| `{e.path}` | `{_fmt(value)}` |")
        lines.append("")

    Path(path).write_text("\n".join(lines), encoding=encoding)


def _fmt(value: Any) -> str:
    if isinstance(value, (dict, list)):
        return json.dumps(value, ensure_ascii=False, default=str)
    return str(value)
