from __future__ import annotations

from dataclasses import dataclass, field
from enum import Enum
from typing import Any


class DiffOp(str, Enum):
    ADD = "add"
    REMOVE = "remove"
    CHANGE = "change"


@dataclass
class DiffEntry:
    """A single diff entry.

    Attributes
    ----------
    op : DiffOp
        Kind of change: add / remove / change.
    path : str
        Human-readable path with key identifiers, e.g.
        ``apis[endpoint=/users,method=GET].params.limit``.
    pointer : str
        RFC 6901 JSON Pointer, e.g. ``/apis/0/params/limit``. Suitable
        for feeding standard JSON Patch libraries.
    old : Any
        Value on the old side. Present for ``remove`` and ``change``.
    new : Any
        Value on the new side. Present for ``add`` and ``change``.
    """

    op: DiffOp
    path: str
    pointer: str
    old: Any = None
    new: Any = None

    def to_dict(self) -> dict[str, Any]:
        d: dict[str, Any] = {
            "op": self.op.value,
            "path": self.path,
            "pointer": self.pointer,
        }
        if self.op in (DiffOp.REMOVE, DiffOp.CHANGE):
            d["old"] = self.old
        if self.op in (DiffOp.ADD, DiffOp.CHANGE):
            d["new"] = self.new
        return d


@dataclass
class DiffResult:
    """Collection of DiffEntry records produced by JsonDiffer."""

    entries: list[DiffEntry] = field(default_factory=list)

    @property
    def added(self) -> list[DiffEntry]:
        return [e for e in self.entries if e.op == DiffOp.ADD]

    @property
    def removed(self) -> list[DiffEntry]:
        return [e for e in self.entries if e.op == DiffOp.REMOVE]

    @property
    def changed(self) -> list[DiffEntry]:
        return [e for e in self.entries if e.op == DiffOp.CHANGE]

    @property
    def summary(self) -> dict[str, int]:
        return {
            "added": len(self.added),
            "removed": len(self.removed),
            "changed": len(self.changed),
        }

    def is_empty(self) -> bool:
        return not self.entries

    def to_dict(self) -> dict[str, Any]:
        return {
            "summary": self.summary,
            "entries": [e.to_dict() for e in self.entries],
        }
