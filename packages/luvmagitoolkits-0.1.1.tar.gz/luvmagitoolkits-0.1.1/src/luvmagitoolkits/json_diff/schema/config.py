from __future__ import annotations

from dataclasses import dataclass, field
from typing import Literal

ArrayStrategy = Literal["auto", "key", "hash", "index"]


@dataclass
class DifferConfig:
    """Configuration for JsonDiffer.

    Attributes
    ----------
    key_map : dict[str, list[str]]
        Map of array dict-path -> list of identifier fields used to match
        elements across old/new. Dict-paths use ``.`` separators and
        ignore intermediate array segments. A single ``*`` segment
        matches any dict key.

        Example: ``{"apis": ["endpoint", "method"], "modules.*.apis": ["name"]}``
    ignore_paths : list[str]
        Dict-paths to skip entirely. Same pattern grammar as key_map keys.
    array_strategy : {"auto", "key", "hash", "index"}
        Fallback order when ``auto``:
        key_map -> infer primary key -> content hash -> index.
    """

    key_map: dict[str, list[str]] = field(default_factory=dict)
    ignore_paths: list[str] = field(default_factory=list)
    array_strategy: ArrayStrategy = "auto"
