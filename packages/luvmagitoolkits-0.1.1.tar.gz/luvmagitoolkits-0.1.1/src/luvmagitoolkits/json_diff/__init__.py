"""JSON diff module.

Compare two JSON-serializable documents and produce a structured diff
suitable for reports and programmatic patching of API design artifacts.

Submodules
----------
schema : DiffEntry, DiffResult, DifferConfig dataclasses (SSOT)
core   : JsonDiffer main class + array matching strategies
io     : JSON / Markdown report writers
"""

from .core import JsonDiffer
from .io import to_json, to_markdown
from .schema import DiffEntry, DiffOp, DiffResult, DifferConfig

__all__ = [
    "JsonDiffer",
    "DiffEntry",
    "DiffOp",
    "DiffResult",
    "DifferConfig",
    "to_json",
    "to_markdown",
]
