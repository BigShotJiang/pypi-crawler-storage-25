class JsonDiffError(Exception):
    """Base exception for json_diff."""


class InvalidKeyMapError(JsonDiffError):
    """Raised when a configured key_map references fields missing from array elements."""
