"""Database utilities (PostgreSQL via psycopg2)."""
