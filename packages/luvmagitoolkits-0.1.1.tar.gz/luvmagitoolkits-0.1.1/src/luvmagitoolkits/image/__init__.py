"""Image processing utilities (Pillow)."""
