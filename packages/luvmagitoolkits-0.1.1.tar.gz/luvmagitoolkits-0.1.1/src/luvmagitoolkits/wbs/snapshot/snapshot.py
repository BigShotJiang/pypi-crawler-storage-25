"""Daily snapshot save / load logic."""

from __future__ import annotations

from datetime import date
from pathlib import Path

import pandas as pd


class Snapshot:
    """Manages dated CSV snapshots under a base directory.

    Directory layout::

        base_dir/
          wbs_frontend/
            2026-04-20.csv
          wbs_backend/
            2026-04-20.csv
    """

    def __init__(self, base_dir: Path) -> None:
        self.base_dir = Path(base_dir)

    def save(
        self,
        wbs_type: str,
        df: pd.DataFrame,
        snapshot_date: date | None = None,
        encoding: str = "utf-8-sig",
    ) -> Path:
        """Write *df* as a dated CSV snapshot.

        Args:
            wbs_type: Sub-directory name (e.g. ``"wbs_frontend"``).
            df: WBS DataFrame with Japanese column headers.
            snapshot_date: Date for the file name; defaults to today.
            encoding: File encoding; defaults to ``"utf-8-sig"``.

        Returns:
            Path of the written file.
        """
        if snapshot_date is None:
            snapshot_date = date.today()
        out_dir = self.base_dir / wbs_type
        out_dir.mkdir(parents=True, exist_ok=True)
        path = out_dir / f"{snapshot_date}.csv"
        df.to_csv(path, encoding=encoding, index=False)
        return path

    def load(self, wbs_type: str, encoding: str = "utf-8-sig") -> dict[date, pd.DataFrame]:
        """Load all dated CSVs for *wbs_type*.

        Args:
            wbs_type: Sub-directory name (e.g. ``"wbs_frontend"``).
            encoding: File encoding; defaults to ``"utf-8-sig"``.

        Returns:
            Dict mapping snapshot date → DataFrame (Japanese columns, dtype=str).
        """
        dir_ = self.base_dir / wbs_type
        if not dir_.exists():
            return {}
        result: dict[date, pd.DataFrame] = {}
        for f in sorted(dir_.glob("*.csv")):
            try:
                d = date.fromisoformat(f.stem)
            except ValueError:
                continue
            result[d] = pd.read_csv(f, encoding=encoding, dtype=str).fillna("")
        return result

    def latest(self, wbs_type: str, encoding: str = "utf-8-sig") -> pd.DataFrame | None:
        """Return the most recent snapshot DataFrame, or None if none exist."""
        snaps = self.load(wbs_type, encoding=encoding)
        if not snaps:
            return None
        return snaps[max(snaps)]
