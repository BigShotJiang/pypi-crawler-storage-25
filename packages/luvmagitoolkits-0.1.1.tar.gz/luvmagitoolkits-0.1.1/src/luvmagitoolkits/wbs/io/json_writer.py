from pathlib import Path

from ..core.base import WBSBase


def to_json(wbs: WBSBase, path: Path, encoding: str = "utf-8-sig") -> None:
    """Write a WBS instance to a JSON file."""
    wbs.to_json(path, encoding=encoding)
