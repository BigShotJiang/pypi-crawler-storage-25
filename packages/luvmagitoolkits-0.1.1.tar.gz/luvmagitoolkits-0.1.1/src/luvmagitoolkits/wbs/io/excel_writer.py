"""xlwings-based Excel writer for hidden dashboard sheets.

Requires: xlwings (not declared as a package dependency — install manually).
The target Excel file must already be open in Excel / OneDrive before calling.
"""

from __future__ import annotations

from pathlib import Path

import pandas as pd


def write_sheet(wb_path: Path, sheet_name: str, df: pd.DataFrame) -> None:
    """Overwrite *sheet_name* in the open Excel workbook with *df*.

    Args:
        wb_path: Full path to the Excel file (must be open in Excel).
        sheet_name: Target sheet name (e.g. ``"_burndown"``).
        df: DataFrame to write starting at cell A1.
    """
    try:
        import xlwings as xw  # type: ignore
    except ImportError as exc:
        raise ImportError("xlwings is required: pip install xlwings") from exc

    app = xw.apps.active
    if app is None:
        raise RuntimeError("No active Excel instance found. Open the workbook first.")

    wb = None
    for book in app.books:
        if Path(book.fullname).resolve() == wb_path.resolve():
            wb = book
            break

    if wb is None:
        raise FileNotFoundError(f"Workbook not open in Excel: {wb_path}")

    if sheet_name not in [s.name for s in wb.sheets]:
        wb.sheets.add(sheet_name)
    sheet = wb.sheets[sheet_name]
    sheet.clear()
    sheet["A1"].value = [df.columns.tolist()] + df.values.tolist()
