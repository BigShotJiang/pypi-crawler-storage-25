from pathlib import Path

from ..core.base import WBSBase


def to_csv(wbs: WBSBase, path: Path, encoding: str = "utf-8-sig") -> None:
    """Write a WBS instance to a CSV file."""
    wbs.to_csv(path, encoding=encoding)
