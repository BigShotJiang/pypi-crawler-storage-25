from pathlib import Path
from typing import Type, TypeVar

from ..core.base import WBSBase

T = TypeVar("T")


def from_csv(wbs_cls: Type[WBSBase[T]], path: Path, encoding: str = "utf-8-sig") -> WBSBase[T]:
    """Load a WBS instance from a CSV file."""
    return wbs_cls.from_csv(path, encoding=encoding)
