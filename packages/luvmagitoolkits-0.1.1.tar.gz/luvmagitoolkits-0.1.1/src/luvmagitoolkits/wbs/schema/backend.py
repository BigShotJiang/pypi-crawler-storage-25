from dataclasses import dataclass
from .frontend import FrontendWBSRow


@dataclass
class BackendWBSRow(FrontendWBSRow):
    pass
