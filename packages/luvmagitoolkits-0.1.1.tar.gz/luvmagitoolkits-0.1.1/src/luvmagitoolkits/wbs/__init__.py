"""WBS management module.

Submodules
----------
schema      : FrontendWBSRow, BackendWBSRow dataclasses (SSOT)
core        : WBSBase[T] generic container + column-mapping utilities
io          : CSV read / write helpers; xlwings Excel writer
snapshot    : Daily snapshot save / load (Snapshot class)
dashboard   : Calc functions (burndown, funnel, assignee, review_lag)
              + update_dashboard() for writing to Excel hidden sheets
"""

try:
    from .schema import FrontendWBSRow, BackendWBSRow
    from .core import WBSBase
    from .snapshot import Snapshot
    from .dashboard import update_dashboard
except ModuleNotFoundError as exc:
    missing_name = getattr(exc, "name", "")
    if missing_name in {"pandas", "xlwings"}:
        raise ModuleNotFoundError(
            "luvmagitoolkits.wbs requires optional dependencies. "
            'Install them with: pip install "luvmagitoolkits[wbs]"'
        ) from exc
    raise

__all__ = [
    "FrontendWBSRow",
    "BackendWBSRow",
    "WBSBase",
    "Snapshot",
    "update_dashboard",
]
