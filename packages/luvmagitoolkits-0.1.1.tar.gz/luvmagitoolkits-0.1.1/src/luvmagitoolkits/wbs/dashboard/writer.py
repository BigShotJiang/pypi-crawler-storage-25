"""Write calculated dashboard data to hidden Excel sheets via xlwings."""

from __future__ import annotations

from datetime import date
from pathlib import Path

import pandas as pd

from ..io.excel_writer import write_sheet
from .calc import calc_burndown, calc_funnel, calc_assignee, calc_review_lag

_SHEET_BURNDOWN  = "_burndown"
_SHEET_FUNNEL    = "_funnel"
_SHEET_ASSIGNEE  = "_assignee"
_SHEET_REVIEW_LAG = "_review_lag"


def update_dashboard(
    wb_path: Path,
    snapshots: dict[date, pd.DataFrame],
    latest_df: pd.DataFrame,
    deadline: date,
) -> None:
    """Recalculate all dashboard sheets and write them to the open workbook.

    Args:
        wb_path: Path to the Excel file (must be open in Excel).
        snapshots: {date: DataFrame} loaded from snapshot CSVs (Japanese columns).
        latest_df: Most recent WBS DataFrame (Japanese columns).
        deadline: Project deadline for the ideal burn-down line.
    """
    write_sheet(wb_path, _SHEET_BURNDOWN,   calc_burndown(snapshots, deadline))
    write_sheet(wb_path, _SHEET_FUNNEL,     calc_funnel(snapshots))
    write_sheet(wb_path, _SHEET_ASSIGNEE,   calc_assignee(latest_df))
    write_sheet(wb_path, _SHEET_REVIEW_LAG, calc_review_lag(latest_df))
