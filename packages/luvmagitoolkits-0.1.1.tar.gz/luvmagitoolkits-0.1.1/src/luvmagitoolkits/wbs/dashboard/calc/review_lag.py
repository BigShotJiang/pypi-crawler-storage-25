"""Review lag calculation (days from manufacturing end to review end)."""

from __future__ import annotations

import pandas as pd


def calc_review_lag(
    df: pd.DataFrame,
    actual_end_col: str = "実際終了日",
    review_end_col: str = "レビュー終了日",
    feature_col: str = "機能名称",
) -> pd.DataFrame:
    """Return per-row review lag in days.

    Rows where either date is empty are excluded.

    Returns:
        DataFrame with columns [feature, actual_end, review_end, lag_days].
    """
    work = df[[feature_col, actual_end_col, review_end_col]].copy()
    work = work[(work[actual_end_col] != "") & (work[review_end_col] != "")]
    work[actual_end_col] = pd.to_datetime(work[actual_end_col], errors="coerce")
    work[review_end_col] = pd.to_datetime(work[review_end_col], errors="coerce")
    work = work.dropna(subset=[actual_end_col, review_end_col])
    work["lag_days"] = (work[review_end_col] - work[actual_end_col]).dt.days
    return work.rename(columns={
        feature_col:    "feature",
        actual_end_col: "actual_end",
        review_end_col: "review_end",
    }).reset_index(drop=True)
