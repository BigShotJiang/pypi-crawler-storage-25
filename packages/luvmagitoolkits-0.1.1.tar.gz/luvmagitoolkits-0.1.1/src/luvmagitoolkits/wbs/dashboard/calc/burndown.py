"""Burn-down chart data calculation."""

from __future__ import annotations

from datetime import date

import pandas as pd


_DONE_STATUS = {"完了"}
_REVIEW_STATUS = {"レビュー中", "in review"}


def calc_burndown(
    snapshots: dict[date, pd.DataFrame],
    deadline: date,
    status_col: str = "状況",
    actual_end_col: str = "実際終了日",
) -> pd.DataFrame:
    """Return a DataFrame suitable for a burn-down chart.

    Args:
        snapshots: Mapping of snapshot date → WBS DataFrame (Japanese columns).
        deadline: Project deadline used to draw the ideal line.
        status_col: Column name for manufacturing status.
        actual_end_col: Column name for actual end date.

    Returns:
        DataFrame with columns [date, total, ideal, manufacturing_done, review_done].
    """
    if not snapshots:
        return pd.DataFrame(columns=["date", "total", "ideal", "manufacturing_done", "review_done"])

    sorted_dates = sorted(snapshots)
    first_date = sorted_dates[0]
    total = len(snapshots[first_date])
    total_days = max((deadline - first_date).days, 1)

    records = []
    for d in sorted_dates:
        df = snapshots[d]
        mfg_done = df[status_col].isin(_DONE_STATUS | _REVIEW_STATUS).sum()
        rev_done = df[status_col].isin(_DONE_STATUS).sum()
        elapsed = (d - first_date).days
        ideal = max(total - round(total * elapsed / total_days), 0)
        records.append({
            "date": d,
            "total": total,
            "ideal": ideal,
            "manufacturing_done": int(mfg_done),
            "review_done": int(rev_done),
        })

    return pd.DataFrame(records)
