"""Funnel time-series calculation (status counts per snapshot date)."""

from __future__ import annotations

from datetime import date

import pandas as pd


_STATUS_NOT_READY = {"未着手", "backlog"}
_STATUS_IN_PROGRESS = {"製造中", "in progress", "予定通り", "遅延"}
_STATUS_IN_REVIEW = {"レビュー中", "in review"}
_STATUS_DONE = {"完了"}


def calc_funnel(
    snapshots: dict[date, pd.DataFrame],
    status_col: str = "状況",
) -> pd.DataFrame:
    """Return status-count timeseries for funnel / stacked-area chart.

    Returns:
        DataFrame with columns [date, not_ready, in_progress, in_review, done].
    """
    records = []
    for d in sorted(snapshots):
        df = snapshots[d]
        s = df[status_col]
        records.append({
            "date": d,
            "not_ready":   int(s.isin(_STATUS_NOT_READY).sum()),
            "in_progress": int(s.isin(_STATUS_IN_PROGRESS).sum()),
            "in_review":   int(s.isin(_STATUS_IN_REVIEW).sum()),
            "done":        int(s.isin(_STATUS_DONE).sum()),
        })
    return pd.DataFrame(records)
