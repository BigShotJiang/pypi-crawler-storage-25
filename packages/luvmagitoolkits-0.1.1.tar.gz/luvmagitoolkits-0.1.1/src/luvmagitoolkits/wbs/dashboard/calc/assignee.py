"""Per-assignee progress calculation."""

from __future__ import annotations

import pandas as pd


_DONE_STATUS = {"完了"}


def calc_assignee(
    df: pd.DataFrame,
    assignee_col: str = "製造担当者",
    status_col: str = "状況",
) -> pd.DataFrame:
    """Return completed / remaining counts grouped by assignee.

    Returns:
        DataFrame with columns [assignee, completed, remaining, total].
    """
    grouped = df.groupby(assignee_col)
    records = []
    for name, group in grouped:
        done = int(group[status_col].isin(_DONE_STATUS).sum())
        total = len(group)
        records.append({
            "assignee":  name,
            "completed": done,
            "remaining": total - done,
            "total":     total,
        })
    return pd.DataFrame(records).sort_values("remaining", ascending=False)
