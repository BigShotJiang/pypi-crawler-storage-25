from __future__ import annotations

import json
from pathlib import Path
from typing import Generic, Type, TypeVar, Iterator

import pandas as pd

from .mapping import extract_column_mapping, extract_column_mapping_inv

T = TypeVar("T")


class WBSBase(Generic[T]):
    """Generic WBS container.

    Subclasses must set ``schema_cls`` to the target dataclass.
    """

    schema_cls: Type[T]

    def __init__(self, rows: list[T] | None = None) -> None:
        self.rows: list[T] = rows or []

    # ------------------------------------------------------------------
    # I/O
    # ------------------------------------------------------------------

    @classmethod
    def from_csv(cls, path: Path, encoding: str = "utf-8-sig") -> WBSBase[T]:
        df: pd.DataFrame = pd.read_csv(path, encoding=encoding, dtype=str, sep="\t")  # type: ignore[call-overload]
        df = df.fillna("")

        col_map_inv = extract_column_mapping_inv(cls.schema_cls)

        missing = set(col_map_inv) - set(df.columns)
        if missing:
            raise ValueError(f"Missing columns in CSV: {missing}")

        df = df.rename(columns=col_map_inv)
        rows = [cls.schema_cls(**record) for record in df.to_dict(orient="records")]
        return cls(rows=rows)

    def to_csv(self, path: Path, encoding: str = "utf-8-sig") -> None:
        col_map = extract_column_mapping(self.schema_cls)
        df = pd.DataFrame([vars(r) for r in self.rows])
        df = df.rename(columns=col_map)
        df = df[list(col_map.values())]
        df.to_csv(path, encoding=encoding, index=False)

    def to_dataframe(self) -> pd.DataFrame:
        col_map = extract_column_mapping(self.schema_cls)
        df = pd.DataFrame([vars(r) for r in self.rows])
        return df.rename(columns=col_map)

    def to_json(self, path: Path, encoding: str = "utf-8-sig") -> None:
        data = [vars(r) for r in self.rows]
        with open(path, "w", encoding=encoding) as f:
            json.dump(data, f, ensure_ascii=False, indent=2)

    @classmethod
    def from_json(cls, path: Path, encoding: str = "utf-8-sig") -> WBSBase[T]:
        with open(path, encoding=encoding) as f:
            data = json.load(f)
        rows = [cls.schema_cls(**record) for record in data]
        return cls(rows=rows)

    # ------------------------------------------------------------------
    # Collection helpers
    # ------------------------------------------------------------------

    def __len__(self) -> int:
        return len(self.rows)

    def __iter__(self) -> Iterator[T]:
        return iter(self.rows)

    def __getitem__(self, index: int) -> T:
        return self.rows[index]
