from typing import get_type_hints


def extract_column_mapping(dataclass_cls) -> dict[str, str]:
    """Return {english_attr: japanese_title} from Annotated metadata."""
    hints = get_type_hints(dataclass_cls, include_extras=True)
    return {
        attr: hint.__metadata__[0]
        for attr, hint in hints.items()
        if hasattr(hint, "__metadata__")
    }


def extract_column_mapping_inv(dataclass_cls) -> dict[str, str]:
    """Return {japanese_title: english_attr}."""
    return {v: k for k, v in extract_column_mapping(dataclass_cls).items()}
