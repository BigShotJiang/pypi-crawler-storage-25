from typing import Optional

from pydantic import BaseModel, ConfigDict, Field


class SelfHostedInstanceEntity(BaseModel):
    model_config = ConfigDict(
        use_enum_values=True,
        populate_by_name=True,
    )

    public_id: Optional[str] = Field(None, alias='ID')
    slug: Optional[str] = Field(None, alias='NAME')
    status: Optional[str] = Field(None, alias='STATUS')
    cpu_type: Optional[str] = Field(str, alias='CPU TYPE')
    cpu_cores: Optional[int] = Field(None, alias='CPU CORES')
    gpu_type: Optional[str] = Field(str, alias='GPU TYPE')
    ip_address: Optional[str] = Field(None, alias='IP ADDRESS')
    shm_free_space: Optional[str] = Field(None, alias='SHM AVAIL')
