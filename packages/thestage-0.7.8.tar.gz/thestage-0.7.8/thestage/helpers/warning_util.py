from typing import Optional

import typer

from thestage.color_scheme.color_scheme import ColorScheme
from thestage.services.clients.thestage_api.dtos.base_response import BaseResponseWarning
from rich import print


def print_warning(warning: BaseResponseWarning):
    colored_warning = f"[{warning.colorHex}]{warning.message}[/]"
    print(colored_warning)


def exit_with_message(code: int, message: str, color: Optional[ColorScheme] = None):
    if code == 1:
        message = f"Error: {message}"

    if color is None:
        typer.echo(f"{message}")
    else:
        print(f"[{color.value}]{message}[{color.value}]")

    raise typer.Exit(code=code)


def print_error_message(message: str, color: Optional[ColorScheme] = None):
    message = f"Error: {message}"

    if color is None:
        typer.echo(f"{message}")
    else:
        print(f"[{color.value}]{message}[{color.value}]")
