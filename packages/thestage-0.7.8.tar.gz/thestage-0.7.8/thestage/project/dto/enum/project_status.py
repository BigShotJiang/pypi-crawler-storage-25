from enum import Enum


class ProjectStatus(str, Enum):
    DELETED: str = 'DELETED'
    CREATED: str = 'CREATED'
    UNKNOWN: str = 'UNKNOWN'
    ALL: str = 'ALL'
