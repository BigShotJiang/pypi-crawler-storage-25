from typing import List, Optional

from pydantic import Field, ConfigDict, BaseModel

from thestage.services.clients.thestage_api.dtos.entity_filter_request import EntityFilterRequest


class ProjectListRequest(BaseModel):
    model_config = ConfigDict(use_enum_values=True)

    entityFilterRequest: EntityFilterRequest = Field(None, alias='entityFilterRequest')
    statuses: Optional[List[str]] = Field(None, alias='statuses')
    rentedInstancePublicId: Optional[str] = Field(None, alias='rentedInstancePublicId')
    rentedInstanceSlug: Optional[str] = Field(None, alias='rentedInstanceSlug')
    selfHostedInstancePublicId: Optional[str] = Field(None, alias='selfHostedInstancePublicId')
    selfHostedInstanceSlug: Optional[str] = Field(None, alias='selfHostedInstanceSlug')