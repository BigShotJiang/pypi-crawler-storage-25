from typing import List, Optional

from pydantic import Field, ConfigDict, BaseModel


class ModifyProjectInstanceAssignmentRequest(BaseModel):
    model_config = ConfigDict(use_enum_values=True)

    projectPublicId: Optional[str] = Field(None, alias='projectPublicId')
    projectSlug: Optional[str] = Field(None, alias='projectSlug')

    instanceRentedPublicIdsToAssign: Optional[List[str]] = Field(None, alias='instanceRentedPublicIdsToAssign')
    instanceRentedSlugsToAssign: Optional[List[str]] = Field(None, alias='instanceRentedSlugsToAssign')
    instanceRentedPublicIdsToDelete: Optional[List[str]] = Field(None, alias='instanceRentedPublicIdsToDelete')
    instanceRentedSlugsToDelete: Optional[List[str]] = Field(None, alias='instanceRentedSlugsToDelete')

    selfhostedInstancePublicIdsToAssign: Optional[List[str]] = Field(None, alias='selfhostedInstancePublicIdsToAssign')
    selfhostedInstanceSlugsToAssign: Optional[List[str]] = Field(None, alias='selfhostedInstanceSlugsToAssign')
    selfhostedInstancePublicIdsToDelete: Optional[List[str]] = Field(None, alias='selfhostedInstancePublicIdsToDelete')
    selfhostedInstanceSlugsToDelete: Optional[List[str]] = Field(None, alias='selfhostedInstanceSlugsToDelete')