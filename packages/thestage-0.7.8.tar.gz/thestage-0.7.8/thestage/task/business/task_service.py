from typing import Optional

import click
import typer
from git import Commit
from rich import print

from thestage.color_scheme.color_scheme import ColorScheme
from thestage.config.business.config_provider import ConfigProvider
from thestage.docker_container.communication.docker_container_api_client import DockerContainerApiClient
from thestage.docker_container.dto.container_response import DockerContainerDto
from thestage.git.communication.git_client import GitLocalClient
from thestage.global_dto.enums.yes_no_response import YesOrNoResponse
from thestage.helpers.error_handler import error_handler
from thestage.helpers.warning_util import exit_with_message
from thestage.i18n.translation import __
from thestage.project.business.project_service import ProjectService
from thestage.project.dto.project_config import ProjectConfig
from thestage.services.abstract_service import AbstractService
from thestage.services.clients.thestage_api.dtos.paginated_entity_list import PaginatedEntityList
from thestage.services.filesystem_service import FileSystemService
from thestage.task.business.mapper.task_mapper import TaskMapper
from thestage.task.communication.task_api_client import TaskApiClient
from thestage.task.dto.run_task_response import RunTaskResponse
from thestage.task.dto.task import Task
from thestage.task.dto.task_entity import TaskEntity


class TaskService(AbstractService):
    def __init__(
            self,
            docker_container_api_client: DockerContainerApiClient,
            task_api_client: TaskApiClient,
            config_provider: ConfigProvider,
            git_local_client: GitLocalClient,
            file_system_service: FileSystemService,
            project_service: ProjectService,
    ):
        self.__docker_container_api_client = docker_container_api_client
        self.__task_api_client = task_api_client
        self.__config_provider = config_provider
        self.__git_local_client = git_local_client
        self.__file_system_service = file_system_service
        self.__project_service = project_service


    @error_handler()
    def project_run_task(
            self,
            run_command: str,
            docker_container_slug: str,
            docker_container_public_id: str,
            task_title: Optional[str] = None,
            commit_hash: Optional[str] = None,
            files_to_add: Optional[str] = None,
            is_skip_auto_commit: Optional[bool] = False,
    ) -> Optional[Task]:
        is_output_prior_to_execution = False
        config = self.__config_provider.get_config()
        project_config: ProjectConfig = self.__project_service.get_fixed_project_config(do_check_default_container=True)
        if not project_config:
            exit_with_message(1, f"No project found at path: {config.runtime.working_directory}. Initialize or clone a project first. Or provide path to project using --working-directory option.")

        if not docker_container_public_id and not docker_container_slug and not project_config.default_container_public_id:
            exit_with_message(1, 'Docker container ID or name is required')

        is_using_default_container = False
        final_container_public_id = docker_container_public_id
        final_container_slug = docker_container_slug
        if not final_container_public_id and not final_container_slug:
            final_container_public_id = project_config.default_container_public_id
            is_using_default_container = True

        container: DockerContainerDto = self.__docker_container_api_client.get_container(
            container_slug=final_container_slug,
            container_public_id=final_container_public_id
        )
        if container is None or container.is_deleted_permanently:
            exit_msg = ''
            if final_container_slug:
                exit_msg = f"Could not find container with name '{final_container_slug}'"
            if final_container_public_id:
                exit_msg = f"Could not find container with ID '{final_container_public_id}'"
            if project_config.default_container_public_id == final_container_public_id:
                project_config.default_container_public_id = None
                project_config.prompt_for_default_container = True
                self.__config_provider.save_project_config(project_config=project_config)
                if exit_msg:
                    exit_msg = f"{exit_msg}. Default container settings were reset."
                else:
                    exit_msg = 'Default container settings were reset.'
            exit_with_message(1, exit_msg)

        if container.project.public_id != project_config.public_id:
            exit_with_message(1,
                              f"Provided container '{container.public_id}' is not related to project '{project_config.public_id}'")

        if (project_config.prompt_for_default_container is None or project_config.prompt_for_default_container) and (
                docker_container_slug or docker_container_public_id) and (
                project_config.default_container_public_id != container.public_id):

            container_display_name = docker_container_slug or docker_container_public_id

            set_default_container_answer: str = typer.prompt(
                text=f"Would you like to set '{container_display_name}' as a default container for this project installation?",
                show_choices=True,
                default=YesOrNoResponse.YES.value,
                type=click.Choice([r.value for r in YesOrNoResponse]),
                show_default=True,
            )
            is_output_prior_to_execution = True
            project_config.prompt_for_default_container = False
            if set_default_container_answer == YesOrNoResponse.YES.value:
                project_config.default_container_public_id = container.public_id

            self.__config_provider.save_project_config(project_config=project_config)

        has_wrong_args = files_to_add and commit_hash or is_skip_auto_commit and commit_hash or files_to_add and is_skip_auto_commit

        if has_wrong_args:
            exit_with_message(1, f"You can provide only one of the following arguments: --commit-hash, --files-add, --skip-autocommit")

        if not is_skip_auto_commit and not commit_hash:
            is_git_folder = self.__git_local_client.is_present_local_git(path=config.runtime.working_directory)
            if not is_git_folder:
                exit_with_message(1, "Working directory is not a git repository")

            is_commit_allowed: bool = True
            has_changes = self.__git_local_client.has_changes_with_untracked(
                path=config.runtime.working_directory,
            )

            if self.__git_local_client.is_head_detached(path=config.runtime.working_directory):
                is_commit_allowed = False
                print(f"[{ColorScheme.GIT_HEADLESS.value}]HEAD is detached[{ColorScheme.GIT_HEADLESS.value}]")

                is_headless_commits_present = self.__git_local_client.is_head_committed_in_headless_state(
                    path=config.runtime.working_directory)
                if is_headless_commits_present:
                    exit_with_message(1, "Current commit created in detached HEAD state. Cannot use it to run the task. Consider using 'project checkout' command to return to a valid reference.", ColorScheme.GIT_HEADLESS)

                if has_changes:
                    print(
                        f"[{ColorScheme.GIT_HEADLESS.value}]Local changes detected in detached head state. They will not impact the task execution.[{ColorScheme.GIT_HEADLESS.value}]")
                    response: YesOrNoResponse = typer.prompt(
                        text=__('Continue?'),
                        show_choices=True,
                        default=YesOrNoResponse.YES.value,
                        type=click.Choice([r.value for r in YesOrNoResponse]),
                        show_default=True,
                    )
                    if response == YesOrNoResponse.NO:
                        raise typer.Exit(0)
                    is_output_prior_to_execution = True

            if is_commit_allowed:
                if not self.__git_local_client.add_files_with_size_limit_or_warn(config.runtime.working_directory, files_to_add):
                    exit_with_message(1, "Task was not started", ColorScheme.WARNING)

                diff_stat = self.__git_local_client.git_diff_stat(repo_path=config.runtime.working_directory)

                if has_changes and diff_stat:
                    branch_name = self.__git_local_client.get_active_branch_name(config.runtime.working_directory)

                    typer.echo(__('Active branch [%branch_name%] has uncommitted changes: %diff_stat_bottomline%', {
                        'diff_stat_bottomline': diff_stat,
                        'branch_name': branch_name,
                    }))

                    response: str = typer.prompt(
                        text=__('Commit changes?'),
                        show_choices=True,
                        default=YesOrNoResponse.YES.value,
                        type=click.Choice([r.value for r in YesOrNoResponse]),
                        show_default=True,
                    )
                    if response == YesOrNoResponse.NO.value:
                        exit_with_message(0, "Cannot run task with uncommitted changes")

                    commit_name = typer.prompt(
                        text=__('Provide commit message'),
                        show_choices=False,
                        type=str,
                        show_default=False,
                    )

                    if commit_name:
                        commit_result = self.__git_local_client.commit_local_changes(
                            path=config.runtime.working_directory,
                            name=commit_name
                        )

                        if commit_result:
                            # in docs not Commit object, on real - str
                            if isinstance(commit_result, str):
                                typer.echo(commit_result)
                    else:
                        exit_with_message(0, 'Commit message cannot be empty')
                    is_output_prior_to_execution = True
                else:
                    pass
                    # possible to push new empty branch - only that there's a wrong place to do so

                self.__git_local_client.push_changes(
                    path=config.runtime.working_directory,
                    deploy_key_path=project_config.deploy_key_path
                )
                # typer.echo(__("Pushed changes to remote repository"))

        if not commit_hash:
            commit = self.__git_local_client.get_current_commit(path=config.runtime.working_directory)
            if not commit or not isinstance(commit, Commit):
                exit_with_message(1, "No current commit found in the local repository", ColorScheme.WARNING)
            commit_hash = commit.hexsha
        else:
            commit = self.__git_local_client.get_commit_by_hash(path=config.runtime.working_directory,
                                                                commit_hash=commit_hash)
            if not commit or not isinstance(commit, Commit):
                exit_with_message(1, f'commit \'{commit_hash}\' was not found in the local repository', ColorScheme.WARNING)

        if not task_title:
            task_title = commit.message.strip() if commit.message else f'Task_{commit_hash}'
            if not commit.message:
                typer.echo(f'Commit message is empty. Task title is set to "{task_title}"')
                is_output_prior_to_execution = True

        run_task_response: RunTaskResponse = self.__task_api_client.execute_project_task(
            project_public_id=project_config.public_id,
            docker_container_public_id=container.public_id,
            run_command=run_command,
            commit_hash=commit_hash,
            task_title=task_title,
        )
        if run_task_response:
            if run_task_response.message:
                print(f"[{ColorScheme.WARNING.value}]{run_task_response.message}[{ColorScheme.WARNING.value}]")
            if run_task_response.isSuccess and run_task_response.task:
                if is_output_prior_to_execution:
                    typer.echo("")
                typer.echo(f"Project name: '{project_config.slug}'")
                typer.echo(f"Container name: '{container.slug}'{' (default container)' if is_using_default_container else ''}")
                typer.echo(f"Task ID: '{run_task_response.task.public_id}'")
                typer.echo(f"Task name: '{run_task_response.task.title}'")
                typer.echo(f"")
                # typer.echo(f"Task '{run_task_response.task.title}' has been scheduled successfully. Task ID: {run_task_response.task.public_id}")
                if run_task_response.tasksInQueue:
                    typer.echo(f"There are tasks in queue ahead of this new task:")
                    for queued_task_item in run_task_response.tasksInQueue:
                        typer.echo(f"{queued_task_item.public_id} - {queued_task_item.frontend_status.status_translation}")
                return run_task_response.task
            else:
                exit_with_message(1, f'The task failed to start: {run_task_response.message}')
        else:
            exit_with_message(1, "The task failed to start")

    @error_handler()
    def cancel_task(self, task_public_id: str):
        cancel_result = self.__task_api_client.cancel_task(
            task_public_id=task_public_id,
        )

        if cancel_result.isSuccess:
            typer.echo(f'Task {task_public_id} has been canceled')
        else:
            typer.echo(f'Task {task_public_id} could not be canceled: {cancel_result.message}')

    def print_task_list(self, project_public_id: Optional[str], project_slug: Optional[str], row, page):
        if not project_slug and not project_public_id:
            project_config: ProjectConfig = self.__config_provider.read_project_config()
            if not project_config:
                exit_with_message(1, "Provide the project ID or name, or run this command from within an initialized project directory")
            project_public_id = project_config.public_id

        self.print(
            func_get_data=self.get_project_task_list,
            func_special_params={
                'project_public_id': project_public_id,
                'project_slug': project_slug,
            },
            mapper=TaskMapper(),
            headers=list(map(lambda x: x.alias, TaskEntity.model_fields.values())),
            row=row,
            page=page,
            max_col_width=[100, 100, 100, 100, 100, 100, 100, 100],
            show_index="never",
        )

    @error_handler()
    def get_project_task_list(
            self,
            project_public_id: Optional[str],
            project_slug: Optional[str],
            row: int = 5,
            page: int = 1,
    ) -> PaginatedEntityList[Task]:
        data: Optional[PaginatedEntityList[Task]] = self.__task_api_client.get_task_list_for_project(
            project_public_id=project_public_id,
            project_slug=project_slug,
            page=page,
            limit=row,
        )

        return data