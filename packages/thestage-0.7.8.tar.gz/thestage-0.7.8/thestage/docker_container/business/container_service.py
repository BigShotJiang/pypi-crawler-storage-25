import math
import re
from pathlib import Path
from typing import List, Tuple, Optional, Dict
from rich import print

import typer

from thestage.color_scheme.color_scheme import ColorScheme
from thestage.connect.communication.connect_api_client import ConnectApiClient
from thestage.docker_container.business.mapper.image_mapper import ImageMapper
from thestage.docker_container.communication.docker_container_api_client import DockerContainerApiClient
from thestage.docker_container.dto.container_entity import DockerContainerEntity
from thestage.docker_container.dto.container_action_request import DockerContainerActionRequest
from thestage.docker_container.dto.docker_container_create_request import DockerContainerCreateRequest, \
    DockerContainerMappings
from thestage.docker_container.dto.enum.container_pending_action import DockerContainerAction
from thestage.docker_container.dto.enum.container_status import DockerContainerStatus
from thestage.docker_container.dto.image_entity import DockerImageEntity
from thestage.global_dto.enums.shell_type import ShellType
from thestage.helpers.warning_util import exit_with_message
from thestage.project.dto.project_config import ProjectConfig
from thestage.services.clients.thestage_api.dtos.paginated_entity_list import PaginatedEntityList
from thestage.docker_container.business.mapper.container_mapper import ContainerMapper
from thestage.services.filesystem_service import FileSystemService
from thestage.connect.business.remote_server_service import RemoteServerService
from thestage.i18n.translation import __
from thestage.services.abstract_service import AbstractService
from thestage.docker_container.dto.container_response import DockerContainerDto, DockerImageDto
from thestage.helpers.error_handler import error_handler
from thestage.config.business.config_provider import ConfigProvider


class ContainerService(AbstractService):

    __docker_container_api_client: DockerContainerApiClient = None
    __config_provider: ConfigProvider = None
    __connect_api_client: ConnectApiClient = None

    def __init__(
            self,
            docker_container_api_client: DockerContainerApiClient,
            config_provider: ConfigProvider,
            remote_server_service: RemoteServerService,
            file_system_service: FileSystemService,
            connect_api_client: ConnectApiClient,

    ):
        self.__config_provider = config_provider
        self.__connect_api_client = connect_api_client
        self.__docker_container_api_client = docker_container_api_client
        self.__remote_server_service = remote_server_service
        self.__file_system_service = file_system_service


    @error_handler()
    def print_container_list(
            self,
            row: int,
            page: int,
            project_public_id: Optional[str],
            project_slug: Optional[str],
            statuses: List[str],
    ):
        container_status_map = self.__docker_container_api_client.get_container_business_status_map()

        if not statuses:
            statuses = ({key: container_status_map[key] for key in [
                DockerContainerStatus.RUNNING,
                DockerContainerStatus.STARTING,
            ]}).values()

        if "all" in statuses:
            statuses = container_status_map.values()

        for input_status_item in statuses:
            if input_status_item not in container_status_map.values():
                exit_with_message(1, __("'%invalid_status%' is not one of %valid_statuses%", {
                    'invalid_status': input_status_item,
                    'valid_statuses': str(list(container_status_map.values()))
                }))

        typer.echo(__(
            "Listing containers with the following statuses: %statuses%. To list all containers, use --status all",
            placeholders={
                'statuses': ', '.join([input_status_item for input_status_item in statuses])
            }))

        backend_statuses: List[str] = [key for key, value in container_status_map.items() if value in statuses]

        self.print(
            func_get_data=self.get_list,
            func_special_params={
                'statuses': backend_statuses,
                'project_slug': project_slug,
                'project_public_id': project_public_id,
            },
            mapper=ContainerMapper(),
            headers=list(map(lambda x: x.alias, DockerContainerEntity.model_fields.values())),
            row=row,
            page=page,
            max_col_width=[35, 20, 25],
            show_index="never",
        )


    @error_handler()
    def get_list(
            self,
            statuses: List[str],
            row: int = 5,
            page: int = 1,
            project_public_id: Optional[str] = None,
            project_slug: Optional[str] = None,
    ) -> PaginatedEntityList[DockerContainerDto]:

        list = self.__docker_container_api_client.get_container_list(
            statuses=statuses,
            page=page,
            limit=row,
            project_public_id=project_public_id,
            project_slug=project_slug
        )

        return list


    # TODO delete this proxy method
    @error_handler()
    def get_container(
            self,
            container_public_id: Optional[str] = None,
            container_slug: Optional[str] = None,
    ) -> Optional[DockerContainerDto]:
        return self.__docker_container_api_client.get_container(
            container_public_id=container_public_id,
            container_slug=container_slug,
        )

    def get_server_auth(
            self,
            container: DockerContainerDto,
            username_param: Optional[str],
            private_key_path_override: Optional[str],
    ) -> Tuple[str, str, Optional[str]]:
        username = None
        if container.instance_rented:
            username = container.instance_rented.host_username
            ip_address = container.instance_rented.ip_address
        elif container.selfhosted_instance:
            ip_address = container.selfhosted_instance.ip_address
        else:
            exit_with_message(1, "Neither rented nor self-hosted server instance found to connect to")

        if username_param:
            username = username_param

        if not username:
            username = 'root'
            typer.echo(__("No remote server username provided, using 'root' as username"))

        private_key_path = private_key_path_override
        if not private_key_path:
            private_key_path = self.__config_provider.get_valid_private_key_path_by_ip_address(ip_address)
            if private_key_path:
                typer.echo(f'Using configured private key for {ip_address}: {private_key_path}')
            else:
                typer.echo(f'Using SSH agent to connect to {ip_address} as {username}')
        else:
            self.__config_provider.update_remote_server_config_entry(ip_address, Path(private_key_path))
            typer.echo(f'Updated private key path for {ip_address}: {private_key_path}')

        return username, ip_address, private_key_path

    @error_handler()
    def connect_to_container(
            self,
            container_public_id: Optional[str],
            container_slug: Optional[str],
            username: Optional[str],
            input_ssh_key_path: Optional[str],
            do_remove_configured_key: Optional[bool] = False,
    ):
        container: Optional[DockerContainerDto] = self.get_container(
            container_public_id=container_public_id,
            container_slug=container_slug,
        )

        if not container:
            exit_with_message(1, f"Container was not found")

        self.check_if_container_running(
            container=container
        )

        if not container.system_name:
            exit_with_message(1, "Unable to connect to container: container system_name is missing")

        starting_directory: str = '/'
        workspace_mappings = {v for v in container.mappings.directory_mappings.values() if v.startswith('/workspace/') or v == '/workspace'}
        if len(workspace_mappings) > 0:
            starting_directory = '/workspace'

        inference_mappings = {v for v in container.mappings.directory_mappings.values() if v.startswith('/opt/') or v == '/opt'}
        if len(inference_mappings) > 0:
            starting_directory = '/opt/project'

        username, ip_address, private_key_path = self.get_server_auth(
            container=container,
            username_param=username,
            private_key_path_override=input_ssh_key_path
        )

        shell: Optional[ShellType] = self.__remote_server_service.get_shell_from_container(
            ip_address=ip_address,
            username=username,
            container_name=container.system_name,
            private_key_path=private_key_path
        )

        if not shell:
            exit_with_message(1, f"Failed to start shell (bash, sh) in container: ensure user '{username}' has Docker access and compatible shell is available")

        self.__remote_server_service.connect_to_container(
            ip_address=ip_address,
            username=username,
            docker_name=container.system_name,
            starting_directory=starting_directory,
            shell=shell,
            private_key_path=private_key_path
        )

    @error_handler()
    def check_if_container_stopped(
            self,
            container: DockerContainerDto,
    ) -> DockerContainerDto:
        if container.frontend_status.status_key not in [
            DockerContainerStatus.STOPPED.value,
        ]:
            exit_with_message(1, f'Container is not stopped (status: \'{container.frontend_status.status_translation}\')')

        return container

    @error_handler()
    def check_if_container_running(
            self,
            container: DockerContainerDto,
    ):
        if container.frontend_status.status_key not in [
            DockerContainerStatus.RUNNING.value,
            DockerContainerStatus.BUSY.value,
        ]:
            exit_with_message(1, f'Container is not running (status: \'{container.frontend_status.status_translation}\')')


    @staticmethod
    def _get_new_path_from_mapping(
            directory_mapping: Dict[str, str],
            destination_path: str,
    ) -> Tuple[Optional[str], Optional[str]]:

        instance_path: Optional[str] = None
        container_path: Optional[str] = None

        for instance_mapping, container_mapping in directory_mapping.items():
            if destination_path.startswith(f"{container_mapping}/") or destination_path == container_mapping:
                instance_path = destination_path.replace(container_mapping, instance_mapping)
                container_path = destination_path
                # dont break, check all mapping list

        if instance_path and container_path:
            return instance_path, container_path
        else:
            return None, None


    @error_handler()
    def put_file_to_container(
            self,
            source_path: str,
            destination: str,
            username_param: Optional[str],
    ):
        container_args = re.match(r"^([\w\W]+?):([\w\W]+)$", destination)
        if container_args is None:
            exit_with_message(1, 'Container name and source file path are required as the second argument\nExample: container_name:/path/to/file')
        container_identifier = container_args.groups()[0]
        destination_path = container_args.groups()[1].rstrip("/")

        if not container_identifier:
            exit_with_message(1, 'Container identifier (container_id_or_name) is required')

        resolved_options = self.__connect_api_client.resolve_user_input(entity_identifier=container_identifier)
        container_public_id = None
        valid_container_count = 0
        for container_item in resolved_options.dockerContainerMatchData:
            message = f"Found a container with matching {container_item.matchedField} in status: '{container_item.frontendStatus.status_translation}' (ID: {container_item.publicId})"
            line_color = ColorScheme.SUCCESS.value if container_item.canDownloadUploadOnContainer else 'default'
            print(f"[{line_color}]{message}[{line_color}]")
            if container_item.canDownloadUploadOnContainer:
                valid_container_count += 1
                container_public_id = container_item.publicId

        if valid_container_count != 1:
            exit_with_message(1, f"Failed to resolve the container by provided identifier, as total of {valid_container_count} containers are valid options")

        container: Optional[DockerContainerDto] = self.__docker_container_api_client.get_container(
            container_public_id=container_public_id,
        )

        if not container:
            exit_with_message(1, f"Container '{container_public_id}' was not found")

        if not self.__file_system_service.check_if_path_exist(file=source_path):
            exit_with_message(1, f"File not found at specified path: '{source_path}'")

        if not container.mappings or not container.mappings.directory_mappings:
            exit_with_message(1, "Mapping folders not found")

        instance_path, container_path = self._get_new_path_from_mapping(
            directory_mapping=container.mappings.directory_mappings,
            destination_path=destination_path,
        )

        if not instance_path and not container_path:
            exit_with_message(1, "Cannot find matching container volume mapping for specified file path")

        username, ip_address, private_key_path = self.get_server_auth(
            container=container,
            username_param=username_param,
            private_key_path_override=None
        )

        copy_only_folder_contents = source_path.endswith("/")

        self.__remote_server_service.upload_data_to_container(
            ip_address=ip_address,
            username=username,
            src_path=source_path,
            dest_path=destination_path,
            instance_path=instance_path,
            container_path=container_path,
            copy_only_folder_contents=copy_only_folder_contents,
            private_key_path=private_key_path,
        )

    @error_handler()
    def get_file_from_container(
            self,
            source: str,
            destination_path: str,
            username_param: Optional[str] = None,
    ):
        container_args = re.match(r"^([\w\W]+?):([\w\W]+)$", source)

        if container_args is None:
            exit_with_message(1, 'Container name and source directory path are required as the first argument\nExample: container_name:/path/to/file')
        container_identifier = container_args.groups()[0]
        source_path = container_args.groups()[1]

        if not container_identifier:
            exit_with_message(1, 'Container identifier (container_id_or_name) is required')

        resolved_options = self.__connect_api_client.resolve_user_input(entity_identifier=container_identifier)
        container_public_id = None
        valid_container_count = 0
        for container_item in resolved_options.dockerContainerMatchData:
            message = f"Found a container with matching {container_item.matchedField} in status: '{container_item.frontendStatus.status_translation}' (ID: {container_item.publicId})"
            line_color = ColorScheme.SUCCESS.value if container_item.canDownloadUploadOnContainer else 'default'
            print(f"[{line_color}]{message}[{line_color}]")
            if container_item.canDownloadUploadOnContainer:
                valid_container_count += 1
                container_public_id = container_item.publicId

        if valid_container_count != 1:
            exit_with_message(1, f"Failed to resolve the container by provided identifier, as total of {valid_container_count} containers are valid options")

        container: Optional[DockerContainerDto] = self.__docker_container_api_client.get_container(
            container_public_id=container_public_id,
        )

        if not container:
            exit_with_message(1, f"Container '{container_public_id}' was not found")

        if not container.mappings or not container.mappings.directory_mappings:
            exit_with_message(1, "Mapping folders not found")

        instance_path, container_path = self._get_new_path_from_mapping(
            directory_mapping=container.mappings.directory_mappings,
            destination_path=source_path,
        )

        if not instance_path and not container_path:
            exit_with_message(1, "Cannot find matching container volume mapping for specified file path")

        username, ip_address, private_key_path = self.get_server_auth(
            container=container,
            username_param=username_param,
            private_key_path_override=None,
        )

        copy_only_folder_contents=source_path.endswith("/")

        self.__remote_server_service.download_data_from_container(
            ip_address=ip_address,
            username=username,
            dest_path=destination_path,
            instance_path=instance_path,
            copy_only_folder_contents=copy_only_folder_contents,
            private_key_path=private_key_path,
        )


    @error_handler()
    def request_docker_container_action(
            self,
            container_public_id: Optional[str],
            container_slug: Optional[str],
            action: DockerContainerAction,
    ):

        request_params = DockerContainerActionRequest(
            dockerContainerPublicId=container_public_id,
            dockerContainerSlug=container_slug,
            action=action,
        )
        result = self.__docker_container_api_client.container_action(
            request_param=request_params,
        )

        if result.isSuccess:
            typer.echo(f'Docker container action scheduled: {action.value}')

    @error_handler()
    def create_docker_container(
            self,
            project_public_id: Optional[str],
            project_slug: Optional[str],
            container_slug: str,
            rented_instance_public_id: Optional[str],
            rented_instance_slug: Optional[str],
            self_hosted_instance_public_id: Optional[str],
            self_hosted_instance_slug: Optional[str],
            image_name: str,
            cpu_number: Optional[int],
            gpu_number: Optional[int],
            volume_mappings: Optional[Dict[str, str]],
            shm_size_bytes: Optional[float],
    ):
        if not project_public_id and not project_slug:
            project_config: ProjectConfig = self.__config_provider.read_project_config()
            if not project_config:
                exit_with_message(1, "Provide the project ID or name, or run this command from within an initialized project directory")
            project_public_id = project_config.public_id

        docker_images_paginated = self.get_image_list()
        if not docker_images_paginated or not docker_images_paginated.entities:
            exit_with_message(1, "No Docker images available")

        selected_image = None
        selection_pool = docker_images_paginated.entities

        if image_name is not None:
            matches = [img for img in selection_pool if img.image == image_name]

            if len(matches) == 1:
                selected_image = matches[0]
            elif len(matches) > 1:
                typer.echo(f"Multiple tags found for repository '{image_name}':")
                selection_pool = matches
            else:
                typer.echo(f"Image '{image_name}' was not found. Select from available images:")

        if selected_image is None:
            for idx, img in enumerate(selection_pool, start=1):
                typer.echo(f"{idx}) {img.image}:{img.tag}")

            choice_str = typer.prompt("Choose which image to use")

            try:
                choice_index = int(choice_str)
            except ValueError:
                exit_with_message(1, "Invalid input. Enter a number.")

            if not (1 <= choice_index <= len(selection_pool)):
                exit_with_message(1, "Choice out of range.")

            selected_image = selection_pool[choice_index - 1]

        request_params = DockerContainerCreateRequest(
            instance_rented_public_id=rented_instance_public_id,
            instance_rented_slug=rented_instance_slug,
            selfhosted_instance_public_id=self_hosted_instance_public_id,
            selfhosted_instance_slug=self_hosted_instance_slug,
            project_public_id=project_public_id,
            project_slug=project_slug,
            container_slug=container_slug,
            docker_image_id=selected_image.id,
            assigned_cpus=cpu_number,
            is_unlimited_cpus=cpu_number is None,
            assigned_gpus=gpu_number,
            is_unlimited_gpus=gpu_number is None,
            mappings=DockerContainerMappings(directory_mappings=volume_mappings),
            shm_size_bytes=shm_size_bytes if shm_size_bytes is not None else None,
        )

        result = self.__docker_container_api_client.create_container(
            request_params
        )
        if result.isSuccess:
            typer.echo(f'Docker container creation scheduled.')

    @error_handler()
    def print_docker_image_list(
            self,
            row: int,
            page: int,
    ):
        typer.echo("Listing available Docker images:")

        self.print(
            func_get_data=self.get_image_list,
            func_special_params={},
            mapper=ImageMapper(),
            headers=list(map(lambda x: x.alias, DockerImageEntity.model_fields.values())),
            row=row,
            page=page,
            max_col_width=[50, 20],
            show_index="never",
        )

    @error_handler()
    def get_image_list(
            self,
            row: int = 5,
            page: int = 1,
    ) -> PaginatedEntityList[DockerImageDto]:

        list = self.__docker_container_api_client.get_docker_image_list(
            page=page,
            limit=row,
        )

        return list


def bytes_to_human_readable_floored(bytes_: int, is_not_binary: bool) -> str:
    unit = 1000 if is_not_binary else 1024
    if bytes_ < unit:
        return f"{bytes_} B"
    exp = int(math.log(bytes_) / math.log(unit))
    pre_chars = "kMGTPE" if is_not_binary else "KMGTPE"
    pre = pre_chars[exp - 1] + ("" if is_not_binary else "i")
    value = bytes_ / math.pow(unit, exp)
    value = math.floor(value * 10.0) / 10.0  # round down to 1 decimal place
    return f"{value:.1f} {pre}B"
