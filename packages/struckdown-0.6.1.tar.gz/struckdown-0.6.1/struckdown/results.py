"""Result classes and run tracking for struckdown."""

import logging
from contextlib import contextmanager
from contextvars import ContextVar
from typing import Any, Callable, Dict, List, Optional

from box import Box
from pydantic import BaseModel, ConfigDict, Field, model_validator

logger = logging.getLogger(__name__)


# Progress callback for per-API-call updates
_progress_callback: ContextVar[Optional[Callable[[], None]]] = ContextVar(
    "_progress_callback", default=None
)


def get_progress_callback() -> Optional[Callable[[], None]]:
    """Get the current progress callback, if any."""
    return _progress_callback.get()


@contextmanager
def progress_tracking(on_api_call: Callable[[], None]):
    """Context manager for tracking individual API calls.

    Allows callers to receive a callback after each LLM completion,
    enabling real-time progress updates without changing the complete() signature.

    Usage:
        def on_call():
            print("API call completed!")

        with progress_tracking(on_api_call=on_call):
            result = complete(...)  # on_call() fires after each completion
    """
    token = _progress_callback.set(on_api_call)
    try:
        yield
    finally:
        _progress_callback.reset(token)


class SlotResult(BaseModel):
    name: Optional[str] = Field(
        default=None, description="The slot/variable name for this result"
    )
    prompt: str
    output: Any
    completion: Optional[Any] = Field(default=None, exclude=False)
    action: Optional[str] = Field(
        default=None,
        description="Action type (e.g., 'pick', 'bool', 'int', 'evidence', 'memory')",
    )
    options: Optional[List[Any]] = Field(
        default=None, description="Parsed template options (OptionValue namedtuples)"
    )
    params: Optional[Dict[str, Any]] = Field(
        default=None,
        description="Resolved action parameters (with variables interpolated)",
    )
    # Note: messages are now stored in completion._request_messages
    response_schema: Optional[Dict[str, Any]] = Field(
        default=None,
        description="Pydantic model schema (JSON Schema) for the expected response",
    )

    @property
    def thinking(self) -> Optional[str]:
        """The model's thinking/reasoning text for this slot, if available.

        Returns None when thinking was not enabled, the result was from cache
        without thinking data, or debug data has been stripped.
        """
        if not self.completion:
            return None
        if isinstance(self.completion, dict):
            return self.completion.get("_thinking")
        return getattr(self.completion, "_thinking", None)

    def get_schema_summary(self) -> str:
        """Extract key constraints from response schema.

        Returns a simplified string showing just the important constraints
        like type, enum values, min/max, required fields, etc.

        Returns:
            Formatted string with schema constraints, or message if no schema available
        """
        schema = self.response_schema

        if not schema or "properties" not in schema:
            return "No schema information available"

        # Get the response field schema (the actual constraint)
        response_schema = schema.get("properties", {}).get("response", {})

        if not response_schema:
            return "No response constraints"

        parts = []

        # Get title if available
        title = schema.get("title", "")
        if title:
            parts.append(f"Type: {title}")

        # Handle anyOf (optional types like Optional[bool])
        if "anyOf" in response_schema:
            types = []
            for option in response_schema["anyOf"]:
                if option.get("type") == "null":
                    continue  # Skip null, we'll indicate optionality differently

                # Check for enum
                if "enum" in option:
                    enum_values = ", ".join(f'"{v}"' for v in option["enum"])
                    types.append(f"enum: [{enum_values}]")
                elif "type" in option:
                    types.append(option["type"])

            if types:
                parts.append(f"Type: {' | '.join(types)}")
        elif "enum" in response_schema:
            # Direct enum
            enum_values = ", ".join(f'"{v}"' for v in response_schema["enum"])
            parts.append(f"Enum: [{enum_values}]")
        elif "type" in response_schema:
            parts.append(f"Type: {response_schema['type']}")

        # Get description
        if "description" in response_schema:
            desc = response_schema["description"]
            parts.append(f"Description: {desc}")

        # Get numeric constraints
        if "minimum" in response_schema:
            parts.append(f"Min: {response_schema['minimum']}")
        if "maximum" in response_schema:
            parts.append(f"Max: {response_schema['maximum']}")
        if "exclusiveMinimum" in response_schema:
            parts.append(f"Min (exclusive): {response_schema['exclusiveMinimum']}")
        if "exclusiveMaximum" in response_schema:
            parts.append(f"Max (exclusive): {response_schema['exclusiveMaximum']}")

        # Get string constraints
        if "minLength" in response_schema:
            parts.append(f"Min length: {response_schema['minLength']}")
        if "maxLength" in response_schema:
            parts.append(f"Max length: {response_schema['maxLength']}")
        if "pattern" in response_schema:
            parts.append(f"Pattern: {response_schema['pattern']}")

        # Check if required
        required_fields = schema.get("required", [])
        if "response" in required_fields:
            parts.append("Required: Yes")
        else:
            parts.append("Required: No (can return null)")

        return "\n".join(parts)

    @model_validator(mode="before")
    @classmethod
    def reconstruct_typed_output(cls, data: Any) -> Any:
        """Reconstruct registered Pydantic models from dict during deserialization.

        When SlotResult is loaded from JSON, action outputs (like FoundEvidenceSet)
        are plain dicts. This validator checks if the action has a registered return_type
        and reconstructs the Pydantic model, preserving computed fields and methods.

        Note: Returns a new dict to avoid mutating the input, which could cause issues
        when the same dict is used elsewhere (e.g., stored in a database JSONField).
        """
        # import here to avoid circular import
        from struckdown.actions import Actions

        if isinstance(data, dict) and "action" in data and "output" in data:
            action_name = data.get("action")
            output = data.get("output")

            # check if this action has a registered return type
            if action_name and isinstance(output, dict):
                return_type = Actions.get_return_type(action_name)
                if return_type is not None:
                    try:
                        # reconstruct the Pydantic model from the dict
                        # create new dict to avoid mutating the input
                        data = {**data, "output": return_type.model_validate(output)}
                    except Exception as e:
                        # if reconstruction fails, log warning but keep the dict
                        logger.warning(
                            f"Failed to reconstruct {return_type.__name__} for action '{action_name}': {e}"
                        )

        return data

    def __str__(self):
        """String representation returns the output's string representation"""
        return str(self.output)

    def __repr__(self):
        """Debug representation shows it's a SlotResult with the output"""
        return f"SlotResult(name={self.name!r}, output={self.output!r}, action={self.action!r})"

    def __eq__(self, other):
        """Equality compares the output value"""
        if isinstance(other, SlotResult):
            return self.output == other.output
        return self.output == other

    def __bool__(self):
        """Boolean evaluation based on output"""
        return bool(self.output)

    def __hash__(self):
        """Make hashable based on output (if output is hashable)"""
        try:
            return hash(self.output)
        except TypeError:
            return hash(id(self))


class StruckdownResult(BaseModel):
    type: str = Field(
        default="chatter", description="Discriminator field for union serialization"
    )
    results: Dict[str, SlotResult] = Field(default_factory=dict)
    interim_results: Dict[str, List[SlotResult]] = Field(
        default_factory=dict,
        description="Intermediate LLM calls and processing steps for multi-stage extractions (e.g., pattern expansion)",
    )

    def __str__(self):
        # abbreviate first prompt
        first_prompt = ""
        if self.results:
            first_seg = next(iter(self.results.values()))
            first_prompt = first_seg.prompt[:80] + (
                "..." if len(first_seg.prompt) > 80 else ""
            )

        # show outputs dict
        outputs_repr = {k: str(v.output) for k, v in self.results.items()}

        return f"<StruckdownResult: outputs={outputs_repr}, prompt='{first_prompt}'>"

    def __getitem__(self, key):
        return self.results[key].output

    def __getattr__(self, name):
        """Proxy attribute access to outputs for cleaner template syntax.

        Allows `result.themes` instead of `result["themes"]` or `result.outputs.themes`.
        Only called when normal attribute lookup fails, so existing attributes are safe.
        """
        # Avoid infinite recursion during initialization
        if name == "results":
            raise AttributeError(name)
        # Check if it's a slot name
        if name in self.results:
            return self.results[name].output
        raise AttributeError(f"'{type(self).__name__}' has no attribute '{name}'")

    def strip_debug_data(self) -> "StruckdownResult":
        """Return a copy with prompts and completions removed for compact storage."""
        stripped = {}
        for name, seg in self.results.items():
            stripped[name] = SlotResult(
                name=seg.name,
                prompt="",
                output=seg.output,
                completion=None,
                action=seg.action,
                options=seg.options,
            )
        return StruckdownResult(results=stripped, interim_results={})

    def __setitem__(self, key: str, value: SlotResult):
        """Set a result, enforcing SlotResult type and ensuring name is set."""
        if not isinstance(value, SlotResult):
            raise TypeError(
                f"StruckdownResult only accepts SlotResult values, got {type(value).__name__}"
            )
        if value.name is None:
            value.name = key
        self.results[key] = value

    def update(self, d: Dict[str, SlotResult]):
        """Update results with a dict of SlotResults, ensuring names are set."""
        for k, v in d.items():
            if v.name is None:
                v.name = k
            self.results[k] = v

    def keys(self):
        return self.results.keys()

    def __len__(self):
        return len(self.results)

    @property
    def response(self):
        # dict is insertion ordered python > 3.7
        if not self.results:
            return None
        last = self.results.get(next(reversed(self.results)), None)
        return last and last.output or None

    @property
    def outputs(self):
        return Box({k: v.output for k, v in self.results.items()})

    @property
    def thinking(self) -> Dict[str, str]:
        """Thinking text for all slots that produced thinking content."""
        return {
            name: seg.thinking
            for name, seg in self.results.items()
            if seg.thinking is not None
        }

    @property
    def total_cost(self) -> float:
        """Total USD cost from all segments (0.0 for cached/unavailable)"""
        total = 0.0
        for seg in self.results.values():
            if not seg.completion:
                continue
            hidden = seg.completion.get("_hidden_params", {})
            total += hidden.get("response_cost", 0.0) or 0.0
        return total

    @property
    def prompt_tokens(self) -> int:
        """Total input tokens across all segments"""
        total = 0
        for seg in self.results.values():
            if not seg.completion:
                continue
            usage = seg.completion.get("usage", {})
            total += usage.get("prompt_tokens", 0) or 0
        return total

    @property
    def completion_tokens(self) -> int:
        """Total output tokens across all segments"""
        total = 0
        for seg in self.results.values():
            if not seg.completion:
                continue
            usage = seg.completion.get("usage", {})
            total += usage.get("completion_tokens", 0) or 0
        return total

    @property
    def total_tokens(self) -> int:
        """Total tokens (prompt + completion)"""
        return self.prompt_tokens + self.completion_tokens

    @property
    def cached_prompt_tokens(self) -> int:
        """Prompt tokens served from provider cache (discounted)."""
        total = 0
        for seg in self.results.values():
            if not seg.completion:
                continue
            usage = seg.completion.get("usage", {})
            details = usage.get("prompt_tokens_details") or {}
            total += details.get("cached_tokens", 0) or 0
        return total

    @property
    def cache_creation_tokens(self) -> int:
        """Tokens used to create new cache entries."""
        total = 0
        for seg in self.results.values():
            if not seg.completion:
                continue
            usage = seg.completion.get("usage", {})
            details = usage.get("prompt_tokens_details") or {}
            total += details.get("cache_creation_tokens", 0) or 0
        return total

    @property
    def has_unknown_costs(self) -> bool:
        """True if ANY segment has unknown/missing cost data"""
        for seg in self.results.values():
            if not seg.completion:
                continue  # function executor, no cost
            hidden = seg.completion.get("_hidden_params")
            if not hidden:
                return True  # missing cost data
            if hidden.get("response_cost") is None:
                return True  # explicit None = unknown
        return False

    @property
    def all_costs_unknown(self) -> bool:
        """True if ALL segments with completions have unknown costs"""
        segments_with_hidden = [
            seg
            for seg in self.results.values()
            if seg.completion and seg.completion.get("_hidden_params")
        ]
        if not segments_with_hidden:
            return True  # no completions = unknown

        for seg in segments_with_hidden:
            cost = seg.completion.get("_hidden_params", {}).get("response_cost")
            if cost is not None:
                return False  # found at least one known cost
        return True

    @property
    def fresh_call_count(self) -> int:
        """Count of segments from fresh API calls (not cached)"""
        return sum(
            1
            for seg in self.results.values()
            if seg.completion and not seg.completion.get("_cached", False)
        )

    @property
    def cached_call_count(self) -> int:
        """Count of segments from cache"""
        return sum(
            1
            for seg in self.results.values()
            if seg.completion and seg.completion.get("_cached", False)
        )

    @property
    def fresh_cost(self) -> float:
        """Total USD cost from fresh API calls only (excludes cached)"""
        return sum(
            (seg.completion._hidden_params.get("response_cost", 0.0) or 0.0)
            for seg in self.results.values()
            if (
                seg.completion
                and hasattr(seg.completion, "_hidden_params")
                and not seg.completion.get("_cached", False)
            )
        )

    @property
    def cached_cost(self) -> float:
        """Total USD cost from cached calls (original cost when first made)"""
        return self.total_cost - self.fresh_cost

    model_config = ConfigDict(
        arbitrary_types_allowed=True,  # treat unknown sub-types as Any
    )


class CostSummary(BaseModel):
    """Aggregated cost summary from multiple StruckdownResult objects.

    Consolidates cost tracking logic for display in CLIs.
    """

    total_cost: float = 0.0
    fresh_cost: float = 0.0
    total_prompt_tokens: int = 0
    total_completion_tokens: int = 0
    cached_prompt_tokens: int = 0
    cache_creation_tokens: int = 0
    fresh_count: int = 0
    cached_count: int = 0
    has_unknown_costs: bool = False
    all_costs_unknown: bool = False

    @classmethod
    def from_results(cls, results: List["StruckdownResult"]) -> "CostSummary":
        """Aggregate cost data from multiple StruckdownResult objects.

        Args:
            results: List of StruckdownResult objects to aggregate

        Returns:
            CostSummary with aggregated data
        """
        total_cost = 0.0
        fresh_cost = 0.0
        total_prompt_tokens = 0
        total_completion_tokens = 0
        cached_prompt_tokens = 0
        cache_creation_tokens = 0
        fresh_count = 0
        cached_count = 0
        has_unknown_costs = False
        all_costs_unknown = True

        for result in results:
            if result is None:
                continue

            total_cost += result.total_cost
            fresh_cost += result.fresh_cost
            total_prompt_tokens += result.prompt_tokens
            total_completion_tokens += result.completion_tokens
            cached_prompt_tokens += result.cached_prompt_tokens
            cache_creation_tokens += result.cache_creation_tokens
            fresh_count += result.fresh_call_count
            cached_count += result.cached_call_count

            if result.has_unknown_costs:
                has_unknown_costs = True
            if not result.all_costs_unknown:
                all_costs_unknown = False

        return cls(
            total_cost=total_cost,
            fresh_cost=fresh_cost,
            total_prompt_tokens=total_prompt_tokens,
            total_completion_tokens=total_completion_tokens,
            cached_prompt_tokens=cached_prompt_tokens,
            cache_creation_tokens=cache_creation_tokens,
            fresh_count=fresh_count,
            cached_count=cached_count,
            has_unknown_costs=has_unknown_costs,
            all_costs_unknown=all_costs_unknown,
        )

    def format_summary(self, include_breakdown: bool = True) -> str:
        """Format cost summary for display.

        Args:
            include_breakdown: Include cache breakdown if available

        Returns:
            Formatted string ready for stderr output
        """
        lines = []

        # main line - handle unknown costs
        if self.all_costs_unknown:
            lines.append(
                f"Total cost: unknown "
                f"({self.total_prompt_tokens:,} in / {self.total_completion_tokens:,} out)"
            )
        elif self.has_unknown_costs:
            lines.append(
                f"Total cost: >=${self.total_cost:.4f} "
                f"({self.total_prompt_tokens:,} in / {self.total_completion_tokens:,} out, some costs unknown)"
            )
        else:
            lines.append(
                f"Total cost: ${self.total_cost:.4f} "
                f"({self.total_prompt_tokens:,} in / {self.total_completion_tokens:,} out)"
            )

            # cache breakdown (only if not unknown and has cached calls)
            if include_breakdown and self.cached_count > 0:
                lines.append(
                    f"  This run: ${self.fresh_cost:.4f} "
                    f"({self.fresh_count} fresh, {self.cached_count} cached)"
                )

        # provider prompt caching stats (if any)
        if include_breakdown and self.cached_prompt_tokens > 0:
            cache_pct = (
                self.cached_prompt_tokens / self.total_prompt_tokens * 100
                if self.total_prompt_tokens > 0
                else 0
            )
            lines.append(
                f"  Provider cache: {self.cached_prompt_tokens:,} tokens "
                f"({cache_pct:.0f}% of prompt)"
            )

        return "\n".join(lines)


class StruckdownEarlyTermination(Exception):
    """Raised when [[end]] or [[@break]] is encountered to stop template execution."""

    def __init__(self, message, partial_results=None):
        super().__init__(message)
        self.partial_results = (
            partial_results if partial_results is not None else StruckdownResult()
        )
