def action():
    print("Hello, Veloza!")

if __name__ == "__main__":
    action()