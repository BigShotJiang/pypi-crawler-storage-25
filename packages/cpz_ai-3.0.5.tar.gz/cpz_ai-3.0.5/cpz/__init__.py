from __future__ import annotations

from .clients.async_ import AsyncCPZClient
from .clients.sync import CPZClient
from .common.cpz_ai import CPZAIClient
from .execution.enums import OrderSide, OrderType, TimeInForce
from .execution.models import (
    Account,
    Order,
    OrderReplaceRequest,
    OrderSubmitRequest,
    Position,
    Quote,
)
from .execution.router import BROKER_ALPACA, BROKER_HFT, BROKER_POLYMARKET, wait_for_order_recording

# Data layer exports
from .data.models import (
    Bar,
    Trade,
    News,
    OptionQuote,
    OptionContract,
    EconomicSeries,
    Filing,
    SocialPost,
    TimeFrame,
)
from .data.client import DataClient

# Risk analytics exports
from .risk.engine import RiskAnalytics
RiskEngine = RiskAnalytics  # backward compat
from .risk.models import (
    RiskSnapshot,
    StrategyRisk,
    MonteCarloResult,
    StressScenario,
    RollingMetrics,
    DrawdownAnalysis,
    PositionSizeResult,
    SharpeInference,
    FactorExposure,
    TailRiskMetrics,
)

# Portfolio decomposition (new in 2.3.0)
from cpz.risk import (
    euler_decomposition,
    mctr,
    optimize_portfolio,
    what_if_analysis,
    risk_budget_check,
    EulerDecomposition,
    MCTRResult,
    OptimizationResult,
    WhatIfResult,
    RiskBudgetResult,
    cointegration_test,
    cointegration_rolling,
    CointegrationResult,
    RollingCointegrationResult,
    custom_scenario,
    cascade_effects,
    historical_scenario,
    scenario_comparison,
    ScenarioImpact,
    CascadeResult,
    ScenarioComparison,
    fragility_score,
    correlation_clustering,
    regime_from_returns,
    FragilityResult,
    CorrelationClusterResult,
    RegimeResult,
)

# Simons AI Assistant exports
from .simons import SimonsClient, AsyncSimonsClient
from .simons_models import (
    SimonsResponse,
    SimonsChunk,
    SimonsMemory,
    TokenUsage,
    CodeProposal,
)

# ── NEW in 3.0.0 ─────────────────────────────────────────────────────

# Typed domain model
from .model.types import Price, Quantity
from .model.types import Money as TypedMoney
from .model.events import (
    Event,
    BarEvent,
    QuoteEvent,
    TradeEvent,
    OrderEvent,
    FillEvent,
    PositionEvent,
    TimeEvent,
    SignalEvent,
)

# Event bus
from .events.bus import EventBus

# Strategy framework
from .strategy.config import StrategyConfig
from .strategy.base import Strategy
from .strategy.runner import StrategyRunner
from .strategy.backtest import BacktestResult

# Pre-trade risk guard
from .execution.risk_guard import RiskGuard, RiskGuardViolation

# Execution algorithms
from .execution.algos import TWAPAlgorithm, VWAPAlgorithm, IcebergAlgorithm

__all__ = [
    # Clients
    "CPZClient",
    "AsyncCPZClient",
    "CPZAIClient",
    "DataClient",
    # Simons AI Assistant
    "SimonsClient",
    "AsyncSimonsClient",
    "SimonsResponse",
    "SimonsChunk",
    "SimonsMemory",
    "TokenUsage",
    "CodeProposal",
    # Execution
    "OrderSide",
    "OrderType",
    "TimeInForce",
    "OrderSubmitRequest",
    "OrderReplaceRequest",
    "Order",
    "Account",
    "Position",
    "Quote",
    "BROKER_ALPACA",
    "BROKER_HFT",
    "BROKER_POLYMARKET",
    "wait_for_order_recording",
    # Risk Analytics
    "RiskAnalytics",
    "RiskEngine",  # backward compat
    "RiskSnapshot",
    "StrategyRisk",
    "MonteCarloResult",
    "StressScenario",
    "RollingMetrics",
    "DrawdownAnalysis",
    "PositionSizeResult",
    "SharpeInference",
    "FactorExposure",
    "TailRiskMetrics",
    # Data Models
    "Bar",
    "Trade",
    "News",
    "OptionQuote",
    "OptionContract",
    "EconomicSeries",
    "Filing",
    "SocialPost",
    "TimeFrame",
    # ── NEW in 3.0.0 ──
    # Typed Domain Model
    "Price",
    "Quantity",
    "TypedMoney",
    "Event",
    "BarEvent",
    "QuoteEvent",
    "TradeEvent",
    "OrderEvent",
    "FillEvent",
    "PositionEvent",
    "TimeEvent",
    "SignalEvent",
    # Event Bus
    "EventBus",
    # Strategy Framework
    "Strategy",
    "StrategyConfig",
    "StrategyRunner",
    "BacktestResult",
    # Pre-Trade Risk Guard
    "RiskGuard",
    "RiskGuardViolation",
    # Execution Algorithms
    "TWAPAlgorithm",
    "VWAPAlgorithm",
    "IcebergAlgorithm",
]

__version__ = "3.0.5"
