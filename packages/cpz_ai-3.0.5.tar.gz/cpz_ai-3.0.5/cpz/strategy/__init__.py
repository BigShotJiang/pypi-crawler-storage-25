"""Strategy framework — professional-grade backtest-live code parity.

Write your strategy once as a ``Strategy`` subclass. The same code runs
against the backtest engine or live broker with zero changes.

Example::

    from cpz import Strategy, StrategyConfig, StrategyRunner, CPZClient

    class MyConfig(StrategyConfig):
        fast: int = 10
        slow: int = 30

    class MyStrategy(Strategy):
        def on_start(self):
            self.subscribe_bars(self.config.instruments[0], "1D")

        def on_bar(self, bar):
            prices = self.cache.bars(bar.symbol)
            if len(prices) < self.config.slow:
                return
            fast_ma = sum(b.close for b in prices[-self.config.fast:]) / self.config.fast
            slow_ma = sum(b.close for b in prices[-self.config.slow:]) / self.config.slow
            if fast_ma > slow_ma and not self.portfolio.is_long(bar.symbol):
                self.buy(bar.symbol, qty=100)
            elif fast_ma < slow_ma and self.portfolio.is_long(bar.symbol):
                self.flatten(bar.symbol)

    client = CPZClient()
    runner = StrategyRunner(client)
    runner.add_strategy(MyStrategy(MyConfig(instruments=["AAPL"])))
    result = runner.backtest(start="2024-01-01", end="2024-12-31")
    print(result.summary())
"""

from __future__ import annotations

from .config import StrategyConfig
from .base import Strategy
from .runner import StrategyRunner
from .backtest import BacktestResult

__all__ = [
    "Strategy",
    "StrategyConfig",
    "StrategyRunner",
    "BacktestResult",
]
