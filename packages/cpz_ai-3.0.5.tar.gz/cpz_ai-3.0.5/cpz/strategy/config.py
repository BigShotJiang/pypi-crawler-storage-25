"""StrategyConfig — serializable, validated strategy configuration.

Subclass this to define your strategy's parameters. The same config works
for backtesting and live trading, and can be serialized for parameter sweeps,
version control, and remote execution.
"""

from __future__ import annotations

from typing import Any, Dict, List, Optional

from pydantic import BaseModel, Field


class StrategyConfig(BaseModel):
    """Base configuration for a Strategy.

    Subclass and add your own fields::

        class MyConfig(StrategyConfig):
            fast_period: int = 10
            slow_period: int = 30
            trade_size: float = 100

    The ``instruments`` list defines which symbols the strategy trades.
    ``strategy_id`` is auto-generated if not provided.
    """

    strategy_id: str = ""
    instruments: List[str] = Field(default_factory=list)
    broker: str = "alpaca"
    environment: str = "paper"
    parameters: Dict[str, Any] = Field(default_factory=dict)

    model_config = {"extra": "allow"}

    def to_dict(self) -> Dict[str, Any]:
        return self.model_dump()

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "StrategyConfig":
        return cls(**data)
