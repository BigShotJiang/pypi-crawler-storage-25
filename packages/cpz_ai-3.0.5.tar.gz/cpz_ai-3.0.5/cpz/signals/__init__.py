"""CPZ Signals — strategy-level position sizing and portfolio risk filters.

Usage inside ``generate_signal()``::

    from cpz.signals import vol_target, max_positions, regime_filter

    def generate_signal(data, state):
        if not regime_filter(data.get("^VIX"), threshold=30):
            return {}
        weights = {}
        for sym in SYMBOLS:
            weights[sym] = vol_target(data[sym], risk=0.02)
        return max_positions(weights, limit=3)
"""

from .sizing import (
    atr_size,
    equal_weight,
    inverse_vol_weights,
    kelly,
    risk_parity_weights,
    vol_target,
)
from .filters import (
    long_only,
    max_drawdown_filter,
    max_exposure,
    max_positions,
    max_weight,
    min_weight,
    normalize,
    regime_filter,
    sector_limit,
    trend_filter,
)

__all__ = [
    # Sizing
    "vol_target", "atr_size", "kelly", "equal_weight",
    "risk_parity_weights", "inverse_vol_weights",
    # Filters
    "max_positions", "max_weight", "max_exposure", "normalize",
    "long_only", "sector_limit", "min_weight",
    "regime_filter", "trend_filter", "max_drawdown_filter",
]
