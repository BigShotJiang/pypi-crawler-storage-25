"""Execution algorithms — intelligent order splitting and routing."""

from __future__ import annotations

from .base import ExecAlgorithm
from .twap import TWAPAlgorithm
from .vwap import VWAPAlgorithm
from .iceberg import IcebergAlgorithm

ALGO_REGISTRY = {
    "twap": TWAPAlgorithm,
    "vwap": VWAPAlgorithm,
    "iceberg": IcebergAlgorithm,
}

__all__ = [
    "ExecAlgorithm",
    "TWAPAlgorithm",
    "VWAPAlgorithm",
    "IcebergAlgorithm",
    "ALGO_REGISTRY",
]
