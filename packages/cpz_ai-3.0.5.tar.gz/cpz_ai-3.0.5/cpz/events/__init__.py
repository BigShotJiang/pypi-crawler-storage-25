"""Event bus — lightweight pub/sub system for real-time data and event routing."""

from __future__ import annotations

from .bus import EventBus

__all__ = ["EventBus"]
