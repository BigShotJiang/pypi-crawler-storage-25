"""CPZ Alpha — alpha research tools for signal quality assessment.

Implements the diagnostic toolkit from Grinold-Kahn's fundamental law:
``IR = IC x sqrt(Breadth) x TC``
"""

from .analysis import (
    ICResult,
    DecayResult,
    QuantileResult,
    TurnoverMetrics,
    information_coefficient,
    rolling_ic,
    signal_decay,
    quantile_returns,
    signal_turnover,
    breadth,
    transfer_coefficient,
)
from .combination import (
    FundLawResult,
    ic_weighted_blend,
    equal_weight_blend,
    zscore_blend,
    decay_adjusted_blend,
    fundamental_law_analysis,
)

__all__ = [
    # Analysis
    "information_coefficient", "rolling_ic", "signal_decay",
    "quantile_returns", "signal_turnover", "breadth", "transfer_coefficient",
    "ICResult", "DecayResult", "QuantileResult", "TurnoverMetrics",
    # Combination
    "ic_weighted_blend", "equal_weight_blend", "zscore_blend",
    "decay_adjusted_blend", "fundamental_law_analysis",
    "FundLawResult",
]
