"""CPZ Portfolio — institutional-grade portfolio construction.

Covers every stage of Paleologo's pipeline: covariance estimation,
factor models, optimisation (10 methods + alpha-risk-cost framework),
transaction costs (Almgren-Chriss), and performance attribution.
"""

from .covariance import (
    LedoitWolfResult,
    FactorCovResult,
    sample_cov,
    ledoit_wolf,
    oracle_approximating,
    ewma_cov,
    factor_model_cov,
    denoise_mp,
    gerber_cov,
)
from .factors import (
    StatFactorModel,
    FundFactorModel,
    FactorRiskDecomp,
    statistical_factor_model,
    fundamental_factors,
    factor_exposure,
    factor_risk_decomposition,
    rolling_factor_exposure,
)
from .optimization import (
    OptResult,
    BLResult,
    ARCResult,
    Constraints,
    mean_variance,
    min_variance,
    max_sharpe,
    risk_parity,
    equal_weight,
    black_litterman,
    hierarchical_risk_parity,
    mean_cvar,
    robust_mvo,
    max_diversification,
    min_tracking_error,
    turnover_penalized,
    alpha_risk_cost_optimize,
)
from .costs import (
    CostEstimate,
    TurnoverResult,
    CostModel,
    almgren_chriss,
    linear_impact,
    sqrt_impact,
    spread_cost,
    total_cost,
    turnover_analysis,
)
from .attribution import (
    BrinsonResult,
    FactorAttrResult,
    RiskAttrResult,
    AlphaBetaResult,
    brinson_fachler,
    factor_attribution,
    risk_attribution,
    alpha_beta_decomposition,
    rolling_attribution,
)

__all__ = [
    # Covariance
    "sample_cov", "ledoit_wolf", "oracle_approximating", "ewma_cov",
    "factor_model_cov", "denoise_mp", "gerber_cov",
    "LedoitWolfResult", "FactorCovResult",
    # Factors
    "statistical_factor_model", "fundamental_factors",
    "factor_exposure", "factor_risk_decomposition", "rolling_factor_exposure",
    "StatFactorModel", "FundFactorModel", "FactorRiskDecomp",
    # Optimization
    "mean_variance", "min_variance", "max_sharpe", "risk_parity", "equal_weight",
    "black_litterman", "hierarchical_risk_parity", "mean_cvar",
    "robust_mvo", "max_diversification", "min_tracking_error", "turnover_penalized",
    "alpha_risk_cost_optimize",
    "OptResult", "BLResult", "ARCResult", "Constraints",
    # Costs
    "almgren_chriss", "linear_impact", "sqrt_impact", "spread_cost",
    "total_cost", "turnover_analysis",
    "CostEstimate", "TurnoverResult", "CostModel",
    # Attribution
    "brinson_fachler", "factor_attribution", "risk_attribution",
    "alpha_beta_decomposition", "rolling_attribution",
    "BrinsonResult", "FactorAttrResult", "RiskAttrResult", "AlphaBetaResult",
]
