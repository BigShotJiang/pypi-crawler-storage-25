"""
Intercom Workspace Migration Dependency Graph
=============================================

Defines the ordered tiers for replicating an Intercom workspace.
Each tier must be fully completed before the next begins, because
later tiers reference IDs created in earlier ones.

Usage by the migration agent:
  from forge.migration.dependency_graph import MIGRATION_PLAN, MigrationResource

  for tier in MIGRATION_PLAN:
      for resource in tier.resources:
          if resource.migratable:
              # read from source workspace, create in target workspace
          else:
              # log the limitation and ask the operator what to do
"""

from dataclasses import dataclass, field


@dataclass
class MigrationResource:
    name: str
    description: str
    # Which forge server owns the read/write tools
    server: str  # "workspace" | "fin" | "both"
    # MCP tool names for reading source and writing target
    read_tools: list[str]
    write_tools: list[str]
    # Resources this one depends on (must exist in target before this is created)
    depends_on: list[str] = field(default_factory=list)
    # Can we create this via API in the target workspace?
    migratable: bool = True
    # Notes on limitations or special handling required
    notes: str = ""


@dataclass
class MigrationTier:
    tier: int
    name: str
    description: str
    resources: list[MigrationResource]


# ──────────────────────────────────────────────────────────────────────────────
# TIER 0 — System primitives: read-only, exist in every workspace by default.
# These are referenced by later tiers but cannot (or need not) be created.
# The migration agent must build an ID mapping between source and target.
# ──────────────────────────────────────────────────────────────────────────────
TIER_0 = MigrationTier(
    tier=0,
    name="System Primitives",
    description=(
        "Read-only entities that exist in every workspace. Cannot be created via API. "
        "The migration agent must map source IDs to target IDs by matching on "
        "email (admins), name (teams), or system identifiers."
    ),
    resources=[
        MigrationResource(
            name="admins",
            description="Workspace admins/agents. Cannot be created via API — must be invited manually.",
            server="workspace",
            read_tools=["list_admins", "get_admin"],
            write_tools=[],
            migratable=False,
            notes=(
                "Build a source_id → target_id map by matching admin email addresses. "
                "Used to populate author_id on articles, internal_articles, macros, and news items. "
                "Any content authored by an admin not present in the target workspace will need a fallback author."
            ),
        ),
        MigrationResource(
            name="teams",
            description="Inboxes/teams. Cannot be created via API — must be configured in the Intercom UI.",
            server="workspace",
            read_tools=["list_teams", "get_team"],
            write_tools=[],
            migratable=False,
            notes=(
                "Build a source_id → target_id map by matching team name. "
                "Teams are referenced by workflows, macros, and routing rules. "
                "Teams must be manually created in the target workspace before migration proceeds."
            ),
        ),
        MigrationResource(
            name="brands",
            description="Workspace brands. Read-only — tied to workspace plan/setup.",
            server="workspace",
            read_tools=["list_brands", "get_brand"],
            write_tools=[],
            migratable=False,
            notes="Map source brand IDs to target brand IDs by name for use in article/content creation.",
        ),
        MigrationResource(
            name="subscription_types",
            description="Email/SMS subscription types. System-defined, cannot be created.",
            server="workspace",
            read_tools=["list_subscription_types"],
            write_tools=[],
            migratable=False,
            notes="Read to understand what subscription types are in use; map by name.",
        ),
        MigrationResource(
            name="ticket_states",
            description="Ticket pipeline states. System-defined per ticket type.",
            server="workspace",
            read_tools=["list_ticket_states"],
            write_tools=[],
            migratable=False,
            notes="States are auto-created with each ticket type. Read-only reference.",
        ),
        MigrationResource(
            name="help_centers",
            description="Help center instances. System-defined per workspace.",
            server="workspace",
            read_tools=["list_help_centers", "get_help_center"],
            write_tools=[],
            migratable=False,
            notes=(
                "Each workspace has its own help center(s). Cannot be created via API. "
                "Map source help_center_id to target help_center_id by name before migrating collections/articles."
            ),
        ),
    ],
)

# ──────────────────────────────────────────────────────────────────────────────
# TIER 1 — Leaf nodes: no dependencies on other created resources.
# Create these first before anything else references them.
# ──────────────────────────────────────────────────────────────────────────────
TIER_1 = MigrationTier(
    tier=1,
    name="Leaf Nodes",
    description="Standalone entities with no dependencies. Create in any order within this tier.",
    resources=[
        MigrationResource(
            name="tags",
            description="Conversation and contact tags.",
            server="workspace",
            read_tools=["list_tags"],
            write_tools=["create_tag"],
            depends_on=[],
            notes=(
                "Tags are created by name via POST /tags. "
                "Build a source_id → target_id map after creation; "
                "used by workflows, macros, conversations, contacts, and tickets."
            ),
        ),
        MigrationResource(
            name="away_status_reasons",
            description="Custom reasons admins can set when going away.",
            server="workspace",
            read_tools=["list_away_status_reasons"],
            write_tools=[],
            migratable=False,
            notes="No create API available. Must be configured manually in target workspace settings.",
        ),
        MigrationResource(
            name="folders",
            description="Folders for organising internal articles.",
            server="workspace",
            read_tools=["list_internal_article_folders", "get_internal_article_folder"],
            write_tools=["create_internal_article_folder", "update_internal_article_folder", "delete_internal_article_folder"],
            depends_on=[],
            notes=(
                "Folders support nesting via parent_folder_id. "
                "Create parent folders first, then children. "
                "Build source_id → target_id map for use in internal_articles."
            ),
        ),
    ],
)

# ──────────────────────────────────────────────────────────────────────────────
# TIER 2 — Core configuration: depend only on Tier 0 ID maps.
# ──────────────────────────────────────────────────────────────────────────────
TIER_2 = MigrationTier(
    tier=2,
    name="Core Configuration",
    description="Core workspace configuration. Depends on admin/team ID maps from Tier 0.",
    resources=[
        MigrationResource(
            name="data_attributes",
            description="Custom data attributes for contacts, companies, and conversations.",
            server="workspace",
            read_tools=["list_data_attributes"],
            write_tools=["create_data_attribute", "update_data_attribute"],
            depends_on=[],
            notes=(
                "Filter by model: contact, company, conversation. "
                "Only non-archived, non-default attributes need migrating. "
                "Build source API name → target ID map; referenced by segments and workflows. "
                "NOTE: conversation CDAs require model='conversation' filter."
            ),
        ),
        MigrationResource(
            name="ticket_types",
            description="Ticket type definitions (Customer, Back-office, Tracker categories).",
            server="workspace",
            read_tools=["list_ticket_types", "get_ticket_type"],
            write_tools=["create_ticket_type", "update_ticket_type"],
            depends_on=[],
            notes=(
                "Create ticket types before their attributes. "
                "Build source_id → target_id map for use in ticket_type_attributes, "
                "workflows, and conversation-to-ticket conversion."
            ),
        ),
        MigrationResource(
            name="segments",
            description="Manual and auto-generated contact/company segments.",
            server="workspace",
            read_tools=["list_segments", "get_segment"],
            write_tools=[],
            migratable=False,
            notes=(
                "No create API available for segments. "
                "Dynamic segments (filter-based) must be recreated manually. "
                "Manual segments cannot be migrated. "
                "Map source_id → target_id by name for reference in workflows."
            ),
        ),
    ],
)

# ──────────────────────────────────────────────────────────────────────────────
# TIER 3 — Extended configuration: depend on Tier 2 resources.
# ──────────────────────────────────────────────────────────────────────────────
TIER_3 = MigrationTier(
    tier=3,
    name="Extended Configuration",
    description="Depends on ticket types (Tier 2) and help centers (Tier 0 map).",
    resources=[
        MigrationResource(
            name="ticket_type_attributes",
            description="Custom attributes on ticket types.",
            server="workspace",
            read_tools=["list_ticket_type_attributes"],
            write_tools=["create_ticket_type_attribute", "update_ticket_type_attribute"],
            depends_on=["ticket_types"],
            notes=(
                "Must be created after ticket types. "
                "list_ticket_types returns attributes inline — no separate list endpoint. "
                "Preserve list_items order for list-type attributes."
            ),
        ),
        MigrationResource(
            name="help_center_collections",
            description="Help center article collections (top-level and nested).",
            server="workspace",
            read_tools=["list_help_center_collections", "get_help_center_collection"],
            write_tools=["create_help_center_collection", "update_help_center_collection", "delete_help_center_collection"],
            depends_on=["help_centers"],
            notes=(
                "Create parent collections before children (parent_id references). "
                "Map source help_center_id to target help_center_id first. "
                "Build source_id → target_id map for use in articles."
            ),
        ),
        MigrationResource(
            name="ai_content_import_sources",
            description="External content sources for Fin AI (URLs synced for AI knowledge).",
            server="fin",
            read_tools=["list_content_import_sources", "get_content_import_source"],
            write_tools=["create_content_import_source", "update_content_import_source"],
            depends_on=[],
            notes="Sync behaviour options: api, automated, manual. Status: active or deactivated.",
        ),
    ],
)

# ──────────────────────────────────────────────────────────────────────────────
# TIER 4 — Content: depend on Tier 3 (collections, folders) and Tier 0 (admin map).
# ──────────────────────────────────────────────────────────────────────────────
TIER_4 = MigrationTier(
    tier=4,
    name="Content",
    description="Articles, internal articles, external pages. Depends on collections, folders, and admin ID map.",
    resources=[
        MigrationResource(
            name="articles",
            description="Public help center articles.",
            server="workspace",
            read_tools=["list_articles", "get_article", "search_articles"],
            write_tools=["create_article", "update_article"],
            depends_on=["help_center_collections", "admins"],
            notes=(
                "author_id is required — use mapped admin ID. "
                "parent_id references a collection — use mapped collection ID. "
                "parent_type is 'collection'. "
                "Migrate translated_content if the workspace uses multiple locales. "
                "Migrate as 'draft' first, then publish once verified."
            ),
        ),
        MigrationResource(
            name="internal_articles",
            description="Internal knowledge base articles (agent-facing).",
            server="workspace",
            read_tools=["list_internal_articles", "get_internal_article", "search_internal_articles"],
            write_tools=["create_internal_article", "update_internal_article"],
            depends_on=["folders", "admins"],
            notes=(
                "author_id and owner_id are required — use mapped admin IDs. "
                "folder_id references a folder — use mapped folder ID. "
            ),
        ),
        MigrationResource(
            name="ai_external_pages",
            description="Manually uploaded HTML pages for Fin AI knowledge.",
            server="fin",
            read_tools=["list_external_pages", "get_external_page"],
            write_tools=["create_external_page", "update_external_page"],
            depends_on=["ai_content_import_sources"],
            notes=(
                "source_id references a content_import_source — use mapped ID. "
                "locale is required (e.g. 'en'). "
                "html content must be provided in full."
            ),
        ),
        MigrationResource(
            name="news_items",
            description="News feed posts.",
            server="workspace",
            read_tools=["list_news_items", "get_news_item"],
            write_tools=["create_news_item", "update_news_item"],
            depends_on=["admins"],
            notes=(
                "sender_id references an admin — use mapped admin ID. "
                "newsfeed_assignments reference newsfeeds — system-defined, map by name. "
                "Migrate as 'draft' first."
            ),
        ),
    ],
)

# ──────────────────────────────────────────────────────────────────────────────
# TIER 5 — Operational tooling: data connectors and macros.
# Depend on most Tier 0–2 resources being in place.
# ──────────────────────────────────────────────────────────────────────────────
TIER_5 = MigrationTier(
    tier=5,
    name="Operational Tooling",
    description="Data connectors and macros. Depend on teams, tags, ticket types being in place.",
    resources=[
        MigrationResource(
            name="data_connectors",
            description="HTTP connectors used by workflows and Fin AI agents.",
            server="fin",
            read_tools=["list_data_connectors", "get_data_connector"],
            write_tools=["create_data_connector"],
            depends_on=["tags", "data_attributes"],
            notes=(
                "Migrate data_inputs, response_fields, and object_mappings in full. "
                "URL templates and headers carry over as-is. "
                "token_ids will be empty — authentication tokens must be re-linked manually after migration. "
                "State will be 'draft' until manually set to 'live'."
            ),
        ),
        MigrationResource(
            name="macros",
            description="Saved reply macros (agent quick-responses with actions).",
            server="workspace",
            read_tools=["list_macros", "get_macro"],
            write_tools=[],
            migratable=False,
            notes=(
                "No create API available for macros. Must be recreated manually. "
                "Export macro names/actions from source for manual reference. "
                "Macros reference teams and tags — ensure those exist first."
            ),
        ),
    ],
)

# ──────────────────────────────────────────────────────────────────────────────
# TIER 6 — Workflows: depend on everything above.
# ──────────────────────────────────────────────────────────────────────────────
TIER_6 = MigrationTier(
    tier=6,
    name="Workflows",
    description=(
        "Automation workflows. Depend on all prior tiers. "
        "CRITICAL LIMITATION: The Intercom API only supports exporting workflows, not creating them. "
        "Workflow migration is read-only — exports must be imported manually via the Intercom UI."
    ),
    resources=[
        MigrationResource(
            name="workflows",
            description="Intercom automation workflows (triggers, conditions, actions).",
            server="fin",
            read_tools=["export_workflow"],
            write_tools=[],
            migratable=False,
            notes=(
                "GET /export/workflows/{id} exports a workflow definition. "
                "There is NO POST /workflows endpoint in the API. "
                "Workflow migration path: export each workflow from source, then import manually in the target "
                "workspace UI, updating all referenced IDs (teams, tags, attributes, data connectors, ticket types) "
                "to their target equivalents using the ID maps built in Tiers 0–5. "
                "The migration agent should produce an annotated export with all ID substitutions applied "
                "so the operator can paste it into the UI import flow."
            ),
        ),
    ],
)

# ──────────────────────────────────────────────────────────────────────────────
# Full ordered plan
# ──────────────────────────────────────────────────────────────────────────────
MIGRATION_PLAN: list[MigrationTier] = [
    TIER_0,
    TIER_1,
    TIER_2,
    TIER_3,
    TIER_4,
    TIER_5,
    TIER_6,
]

# Flat lookup by resource name
RESOURCES: dict[str, MigrationResource] = {
    r.name: r
    for tier in MIGRATION_PLAN
    for r in tier.resources
}

# Resources that can be automatically migrated
MIGRATABLE = [r for r in RESOURCES.values() if r.migratable]

# Resources that require manual intervention
MANUAL_ONLY = [r for r in RESOURCES.values() if not r.migratable]


def print_plan() -> None:
    """Print a human-readable summary of the migration plan."""
    for tier in MIGRATION_PLAN:
        print(f"\n{'='*70}")
        print(f"Tier {tier.tier}: {tier.name}")
        print(f"  {tier.description}")
        for r in tier.resources:
            status = "AUTO" if r.migratable else "MANUAL"
            deps = f" (needs: {', '.join(r.depends_on)})" if r.depends_on else ""
            print(f"  [{status}] {r.name}{deps}")
            if r.notes:
                for line in r.notes.split(". "):
                    if line.strip():
                        print(f"         • {line.strip()}.")


if __name__ == "__main__":
    print_plan()
    print(f"\n\nTotal resources: {len(RESOURCES)}")
    print(f"Auto-migratable: {len(MIGRATABLE)}")
    print(f"Manual only:     {len(MANUAL_ONLY)} ({', '.join(r.name for r in MANUAL_ONLY)})")
