"""Per-user state directories for forge.

When forge runs from a source checkout, state has historically lived inside
the repo (workspace/, forge/ui_automation/.profiles/, etc.). That stops
working the moment forge is installed from PyPI: __file__ points inside
site-packages, which is read-only on managed systems and gets wiped on
package upgrade.

This module centralises the per-user state location so every subsystem
agrees on it. Default is ~/.forge/. Override with FORGE_STATE_DIR for
tests, ephemeral environments, or when running multiple isolated forge
installs side by side.

Layout:
    ~/.forge/
        workspaces/     — partner workspace configs (forge.json + snapshots)
        profiles/       — Playwright persistent browser profiles, one per workspace
        screenshots/    — Playwright debug screenshots
        cache/          — license validation cache, etc.
"""
from __future__ import annotations

import os
from pathlib import Path


def state_root() -> Path:
    """Root of the forge per-user state directory.

    Override with FORGE_STATE_DIR; otherwise defaults to ~/.forge/.
    Does NOT create the directory — callers that write should call
    ensure_dir() on the specific subdir they need.
    """
    override = os.environ.get("FORGE_STATE_DIR")
    if override:
        return Path(override).expanduser().resolve()
    return (Path.home() / ".forge").resolve()


def workspaces_dir() -> Path:
    """Default location for partner workspace configs.

    Note: workspace_config has its own override chain (FORGE_WORKSPACES_DIR
    env var, then a repo-local workspace/ if present) — this is the
    fallback when neither of those applies.
    """
    return state_root() / "workspaces"


def profiles_dir() -> Path:
    """Persistent Playwright browser profiles, one subdir per workspace."""
    return state_root() / "profiles"


def screenshots_dir() -> Path:
    """Playwright debug screenshots."""
    return state_root() / "screenshots"


def cache_dir() -> Path:
    """Generic cache (license validation responses, etc.)."""
    return state_root() / "cache"


def ensure_dir(path: Path) -> Path:
    """Create the directory (and parents) if missing; return it."""
    path.mkdir(parents=True, exist_ok=True)
    return path


def package_data_dir(name: str) -> Path:
    """Resolve a bundled data directory (playbooks, documentation, ...).

    In an installed wheel, hatch force-include puts these under forge/<name>/.
    In a source checkout, they live at <repo>/<name>/. This helper checks
    both locations so callers don't need to care which mode is in effect.
    Raises FileNotFoundError if neither resolves.
    """
    pkg_root = Path(__file__).resolve().parent
    installed = pkg_root / name
    if installed.is_dir():
        return installed
    repo_local = pkg_root.parent / name
    if repo_local.is_dir():
        return repo_local
    raise FileNotFoundError(
        f"Bundled data dir '{name}' not found. Looked in {installed} "
        f"and {repo_local}."
    )
