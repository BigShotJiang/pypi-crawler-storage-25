"""
Per-workspace configuration loader.

Each Intercom workspace has a folder containing a `forge.json` file. That file
describes the workspace and tells the MCP server which environment variable
holds its Intercom access token. The token itself is never stored in
`forge.json` — only the env var name is.

Two layouts are supported and may coexist:

    workspace/<Name>/forge.json                 (flat)
    workspace/<Industry>/<Name>/forge.json      (nested by industry)

When nested, the parent folder name becomes the workspace's "industry" tag.
Workspace folder names must be unique across the whole tree — the loader
raises if it sees the same name twice.

Example `workspace/gaming/Acme/forge.json`:

    {
      "name": "Acme",
      "intercom_token_env": "ACME_TOKEN",
      "admin_id": "12345",
      "default_brand_id": "67890",
      "notes": "Optional human-readable context."
    }
"""
from __future__ import annotations

import json
import os
from pathlib import Path
from typing import Any

from forge import paths


CONFIG_FILENAME = "forge.json"


def _workspaces_root() -> Path:
    """Resolve the workspaces directory.

    Resolution order:
      1. FORGE_WORKSPACES_DIR env var (explicit override).
      2. <repo>/workspace if running from a source checkout — preserves the
         existing local dev UX where partner workspace folders live next to
         the source. Detected by checking that the path actually exists,
         which it never will inside an installed wheel's site-packages.
      3. ~/.forge/workspaces (the standard post-install location).
    """
    override = os.environ.get("FORGE_WORKSPACES_DIR")
    if override:
        return Path(override).expanduser().resolve()
    repo_local = (Path(__file__).resolve().parent.parent / "workspace").resolve()
    if repo_local.is_dir():
        return repo_local
    return paths.workspaces_dir()


def _discover_workspace_paths() -> dict[str, Path]:
    """Return {name: path} for every folder containing a forge.json.

    Walks two levels:
      workspace/<Name>/forge.json                 → flat (no industry)
      workspace/<Industry>/<Name>/forge.json      → nested under an industry

    Raises ValueError if two workspaces share a folder name (regardless of
    industry), since `workspace` arguments to MCP tools are bare folder names.
    """
    root = _workspaces_root()
    if not root.is_dir():
        return {}

    found: dict[str, Path] = {}

    def _claim(path: Path) -> None:
        if path.name in found:
            existing = found[path.name]
            raise ValueError(
                f"Duplicate workspace folder name '{path.name}': "
                f"found at both {existing} and {path}. "
                f"Workspace names must be unique across the workspace/ tree."
            )
        found[path.name] = path

    for level1 in sorted(root.iterdir()):
        if not level1.is_dir():
            continue
        if (level1 / CONFIG_FILENAME).is_file():
            _claim(level1)
            continue
        # Treat level1 as an industry folder; look one level deeper.
        for level2 in sorted(level1.iterdir()):
            if level2.is_dir() and (level2 / CONFIG_FILENAME).is_file():
                _claim(level2)
    return found


def _industry_for(path: Path) -> str | None:
    """Return the industry folder name if the workspace is nested, else None."""
    rel = path.relative_to(_workspaces_root()).parts
    return rel[0] if len(rel) == 2 else None


def workspace_dir(workspace: str) -> Path:
    """Resolve the on-disk folder for a workspace by its bare name.

    Searches both flat and nested layouts. Raises FileNotFoundError if the
    name isn't found.
    """
    paths = _discover_workspace_paths()
    if workspace not in paths:
        available = ", ".join(sorted(paths)) or "(none found)"
        raise FileNotFoundError(
            f"Workspace '{workspace}' not found. Available: {available}"
        )
    return paths[workspace]


def _config_path(workspace: str) -> Path:
    return workspace_dir(workspace) / CONFIG_FILENAME


def _load_raw(workspace: str) -> dict[str, Any]:
    path = _config_path(workspace)
    try:
        data = json.loads(path.read_text())
    except json.JSONDecodeError as e:
        raise ValueError(f"Invalid JSON in {path}: {e}") from e
    if not isinstance(data, dict):
        raise ValueError(f"{path} must contain a JSON object")
    _reject_inline_secrets(path, data)
    return data


def _reject_inline_secrets(path: Path, data: dict[str, Any]) -> None:
    """Refuse to load configs that put a literal token in the file.

    Tokens must live in the shell environment (e.g. via ~/.secrets) and be
    referenced by name through `intercom_token_env`. This guard prevents
    accidental commits of credentials.
    """
    forbidden = {"intercom_token", "intercom_access_token", "access_token", "token"}
    leaked = forbidden.intersection(data.keys())
    if leaked:
        raise ValueError(
            f"{path} contains forbidden inline-secret field(s): {sorted(leaked)}. "
            f"Use 'intercom_token_env' to name an environment variable instead."
        )


def _discover_workspaces() -> list[str]:
    """Sorted list of workspace folder names."""
    return sorted(_discover_workspace_paths())


def list_industries() -> list[str]:
    """Sorted list of industry folder names found under workspace/."""
    paths = _discover_workspace_paths()
    industries = {ind for p in paths.values() if (ind := _industry_for(p))}
    return sorted(industries)


def load_workspace(workspace: str) -> dict[str, Any]:
    """Return the raw config dict for a workspace (no token resolution)."""
    return _load_raw(workspace)


def get_intercom_token(workspace: str) -> str:
    """Resolve the Intercom access token for a workspace via its env var."""
    config = _load_raw(workspace)
    env_name = config.get("intercom_token_env")
    if not env_name:
        raise ValueError(
            f"Workspace '{workspace}' config is missing 'intercom_token_env'. "
            f"Add the name of the environment variable that holds its token."
        )
    token = os.environ.get(env_name)
    if not token:
        raise ValueError(
            f"Environment variable '{env_name}' is not set. "
            f"Define it in ~/.secrets and ensure your shell sources that file."
        )
    return token


def list_workspaces() -> list[dict[str, Any]]:
    """Summarise all configured workspaces.

    Each entry includes the workspace's `industry` (parent folder name when
    nested under workspace/<industry>/, else None) and a `path` field showing
    the folder it was loaded from. Tokens are never returned; only whether the
    referenced env var is currently set.
    """
    out: list[dict[str, Any]] = []
    for name, path in sorted(_discover_workspace_paths().items()):
        try:
            cfg = _load_raw(name)
        except (ValueError, FileNotFoundError) as e:
            out.append({"name": name, "folder": name, "error": str(e)})
            continue
        env_name = cfg.get("intercom_token_env")
        entry = {k: v for k, v in cfg.items() if k != "intercom_token_env"}
        entry["name"] = entry.get("name", name)
        entry["folder"] = name
        entry["industry"] = _industry_for(path)
        entry["path"] = str(path.relative_to(_workspaces_root()))
        entry["intercom_token_env"] = env_name
        entry["intercom_token_present"] = bool(env_name and os.environ.get(env_name))
        out.append(entry)
    return out
