"""License key management CLI.

The forge MCP servers refuse to start without a valid license cache at
~/.forge/license.cache. These commands manage that cache:

    forge auth login --key forge_live_xxx     # activate this machine
    forge auth status                         # show key + subscription state
    forge auth logout                         # wipe the cache

The actual gating logic lives in forge.license — these commands are
thin wrappers around it.
"""
from __future__ import annotations

import time

import click

from forge import license as lic


@click.group("auth")
def auth_group():
    """Manage your forge license."""


@auth_group.command("login")
@click.option(
    "--key",
    "api_key",
    required=True,
    envvar="FORGE_LICENSE_KEY",
    help="License key issued from the forge dashboard, e.g. forge_live_xxx.",
)
def auth_login(api_key: str) -> None:
    """Activate this machine with your forge license key.

    Calls the backend to validate the key, then saves a signed cache
    file at ~/.forge/license.cache. The MCP servers read this file on
    startup; no key, no servers.
    """
    try:
        cached = lic.validate_with_backend(api_key)
    except lic.LicenseError as e:
        raise click.ClickException(str(e)) from e

    lic.save_cache(cached)

    r = cached.response
    click.echo(f"Logged in. Key {r.key_prefix}… is active.")
    click.echo(f"  Plan:           {r.subscription_plan}")
    click.echo(f"  Cache expires:  {time.ctime(r.expires_at)}")
    if r.notice:
        click.echo(f"  Notice:         {r.notice}")


@auth_group.command("status")
def auth_status() -> None:
    """Show the current license state.

    Doesn't hit the backend — only reads the local cache and verifies
    its signature. Use this to debug "why won't my server start" issues.
    """
    try:
        cached = lic.load_cache()
    except lic.LicenseError as e:
        raise click.ClickException(str(e)) from e

    if cached is None:
        click.echo("No license configured. Run: forge auth login --key forge_live_xxx")
        raise SystemExit(1)

    r = cached.response
    now = int(time.time())

    # Verify signature; surface the failure rather than silently passing.
    try:
        lic._verify_signature(cached.response, cached.signature_hex)
        sig_state = "valid"
    except lic.LicenseError as e:
        sig_state = f"INVALID ({e})"

    if not r.subscription_active:
        cache_state = "subscription INACTIVE"
    elif now < r.expires_at:
        cache_state = f"fresh ({r.expires_at - now}s until refresh)"
    elif now < r.expires_at + lic.GRACE_PERIOD_SECONDS:
        cache_state = (
            f"expired but in grace ({r.expires_at + lic.GRACE_PERIOD_SECONDS - now}s "
            f"of offline window left)"
        )
    else:
        cache_state = "EXPIRED past grace window"

    click.echo(f"Key:            {r.key_prefix}…")
    click.echo(f"Plan:           {r.subscription_plan}")
    click.echo(f"Active:         {r.subscription_active}")
    click.echo(f"Issued:         {time.ctime(r.issued_at)}")
    click.echo(f"Cache expires:  {time.ctime(r.expires_at)}")
    click.echo(f"Cache state:    {cache_state}")
    click.echo(f"Signature:      {sig_state}")
    click.echo(f"Machine ID:     {lic.machine_id_hash()}")
    click.echo(f"Seat count:     {r.seat_count}")
    if r.notice:
        click.echo(f"Notice:         {r.notice}")


@auth_group.command("logout")
@click.option("--yes", is_flag=True, help="Skip confirmation.")
def auth_logout(yes: bool) -> None:
    """Wipe the local license cache. The MCP servers will refuse to
    start until you `forge auth login` again."""
    if not yes:
        if not click.confirm("Wipe the local forge license cache?", default=False):
            click.echo("Cancelled.")
            return
    lic.wipe_cache()
    click.echo("License cache removed.")
