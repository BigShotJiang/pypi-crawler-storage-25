"""forge workspace ... — manage Intercom workspace configs.

Replaces the manual `mkdir ~/.forge/workspaces/<Name> && cat > forge.json`
dance. Each subcommand operates on the same on-disk layout the MCP
servers read at runtime:

    ~/.forge/workspaces/<Name>/forge.json                    flat
    ~/.forge/workspaces/<Industry>/<Name>/forge.json         nested

Tokens never live inside forge.json — only the env var name does. That
matches the existing security model (tokens in your shell env via
~/.secrets, never on disk in the project).
"""
from __future__ import annotations

import json
import os
import shutil
import sys
from pathlib import Path

import click

from forge import paths
from forge.workspace_config import (
    CONFIG_FILENAME,
    list_workspaces as wc_list_workspaces,
    load_workspace,
    workspace_dir,
)


# ── helpers ──────────────────────────────────────────────────────────


def _workspaces_root() -> Path:
    """Where new workspaces get written. Mirrors workspace_config's
    resolution chain: env override → repo workspace/ if dev → ~/.forge/."""
    override = os.environ.get("FORGE_WORKSPACES_DIR")
    if override:
        return Path(override).expanduser().resolve()
    repo_local = (Path(__file__).resolve().parents[2] / "workspace").resolve()
    if repo_local.is_dir():
        return repo_local
    return paths.workspaces_dir()


def _name_already_taken(name: str) -> Path | None:
    """Return the existing workspace dir if the bare name is taken
    (across both flat and nested layouts), else None."""
    for entry in wc_list_workspaces():
        if entry.get("folder") == name:
            return Path(entry.get("path", ""))
    return None


def _resolve_target_dir(name: str, industry: str | None) -> Path:
    root = _workspaces_root()
    if industry:
        return root / industry / name
    return root / name


def _write_config(target: Path, data: dict) -> None:
    """Atomic write — temp file, chmod 600, replace."""
    target.mkdir(parents=True, exist_ok=True)
    cfg = target / CONFIG_FILENAME
    tmp = cfg.with_suffix(".tmp")
    tmp.write_text(json.dumps(data, indent=2) + "\n")
    os.chmod(tmp, 0o600)
    tmp.replace(cfg)


def _build_payload(
    name: str,
    *,
    token_env: str,
    admin_id: str | None,
    default_brand_id: str | None,
    notes: str | None,
) -> dict:
    """Build the forge.json payload, dropping unset optional fields."""
    out: dict = {"name": name, "intercom_token_env": token_env}
    if admin_id:
        out["admin_id"] = admin_id
    if default_brand_id:
        out["default_brand_id"] = default_brand_id
    if notes:
        out["notes"] = notes
    return out


def _warn_if_env_missing(token_env: str) -> None:
    if not os.environ.get(token_env):
        click.echo(
            f"⚠  Note: env var '{token_env}' is not set in this shell. "
            f"Add it to ~/.secrets and source it from your shell rc, e.g.:\n"
            f"    echo 'export {token_env}=\"tok:...\"' >> ~/.secrets\n"
            f"    source ~/.secrets",
            err=True,
        )


# ── commands ─────────────────────────────────────────────────────────


@click.group("workspace")
def workspace_group():
    """Manage Intercom workspace configs."""


@workspace_group.command("add")
@click.argument("name")
@click.option(
    "--token-env",
    required=True,
    help="Name of the env var holding this workspace's Intercom token "
         "(e.g. CLIENT_ACME_TOKEN). The token itself never goes in forge.json.",
)
@click.option(
    "--industry",
    default=None,
    help="Optional industry tag (gaming, ecommerce, finance, ...). "
         "Creates the nested workspaces/<industry>/<name>/ layout.",
)
@click.option("--admin-id", default=None)
@click.option("--default-brand-id", default=None)
@click.option("--notes", default=None)
def workspace_add(
    name: str,
    token_env: str,
    industry: str | None,
    admin_id: str | None,
    default_brand_id: str | None,
    notes: str | None,
) -> None:
    """Add a new Intercom workspace.

    Creates ~/.forge/workspaces/<name>/forge.json (or nested under
    <industry>/ if --industry is given). Names must be globally unique
    across the whole tree — the MCP servers reference workspaces by
    bare folder name.
    """
    existing = _name_already_taken(name)
    if existing is not None:
        raise click.ClickException(
            f"Workspace '{name}' already exists at {existing}. "
            f"Use `forge workspace update {name} ...` to modify it, or "
            f"`forge workspace remove {name}` first."
        )

    target = _resolve_target_dir(name, industry)
    payload = _build_payload(
        name,
        token_env=token_env,
        admin_id=admin_id,
        default_brand_id=default_brand_id,
        notes=notes,
    )
    _write_config(target, payload)

    click.echo(f"Added workspace '{name}' at {target}")
    _warn_if_env_missing(token_env)


@workspace_group.command("list")
@click.option("--json", "as_json", is_flag=True, help="Emit JSON instead of a table.")
def workspace_list(as_json: bool) -> None:
    """List every configured workspace."""
    rows = wc_list_workspaces()
    if as_json:
        click.echo(json.dumps(rows, indent=2))
        return
    if not rows:
        click.echo("(no workspaces configured — try `forge workspace add ...`)")
        return
    name_w = max(len(r.get("folder", "")) for r in rows)
    name_w = max(name_w, 4)
    click.echo(f"{'NAME':<{name_w}}  INDUSTRY    TOKEN  PATH")
    for r in rows:
        token = "✓" if r.get("intercom_token_present") else "—"
        ind = r.get("industry") or ""
        click.echo(
            f"{r.get('folder', ''):<{name_w}}  "
            f"{ind:<10}  {token:<5}  {r.get('path', '')}"
        )


@workspace_group.command("show")
@click.argument("name")
def workspace_show(name: str) -> None:
    """Print one workspace's full config (without the token)."""
    try:
        cfg = load_workspace(name)
    except (FileNotFoundError, ValueError) as e:
        raise click.ClickException(str(e))
    cfg["_path"] = str(workspace_dir(name))
    env_name = cfg.get("intercom_token_env", "")
    cfg["_token_env_set"] = bool(env_name and os.environ.get(env_name))
    click.echo(json.dumps(cfg, indent=2))


@workspace_group.command("update")
@click.argument("name")
@click.option("--token-env")
@click.option("--admin-id")
@click.option("--default-brand-id")
@click.option("--notes")
def workspace_update(
    name: str,
    token_env: str | None,
    admin_id: str | None,
    default_brand_id: str | None,
    notes: str | None,
) -> None:
    """Update one or more fields on an existing workspace.

    Only fields you pass are changed; everything else is preserved. To
    clear a field, edit forge.json manually (rare).
    """
    try:
        cfg = load_workspace(name)
    except (FileNotFoundError, ValueError) as e:
        raise click.ClickException(str(e))

    changed = []
    if token_env:
        cfg["intercom_token_env"] = token_env
        changed.append("intercom_token_env")
    if admin_id:
        cfg["admin_id"] = admin_id
        changed.append("admin_id")
    if default_brand_id:
        cfg["default_brand_id"] = default_brand_id
        changed.append("default_brand_id")
    if notes:
        cfg["notes"] = notes
        changed.append("notes")

    if not changed:
        click.echo("Nothing to update — no flags passed.")
        return

    target = workspace_dir(name)
    _write_config(target, cfg)
    click.echo(f"Updated {', '.join(changed)} on '{name}'.")
    if "intercom_token_env" in changed:
        _warn_if_env_missing(cfg["intercom_token_env"])


@workspace_group.command("remove")
@click.argument("name")
@click.option("--yes", is_flag=True, help="Skip confirmation.")
def workspace_remove(name: str, yes: bool) -> None:
    """Delete a workspace's config directory.

    DESTRUCTIVE — also removes any snapshots / per-workspace state under
    that folder. The Intercom token in your shell env is untouched.
    """
    try:
        target = workspace_dir(name)
    except FileNotFoundError as e:
        raise click.ClickException(str(e))

    if not yes:
        click.echo(f"Will remove: {target}")
        if not click.confirm("Continue?", default=False):
            click.echo("Cancelled.")
            return

    shutil.rmtree(target)
    click.echo(f"Removed '{name}' ({target}).")


@workspace_group.command("test")
@click.argument("name")
def workspace_test(name: str) -> None:
    """Verify the workspace's token works by calling Intercom /me.

    Triggers the license gate as a side benefit — if you're not logged
    in, this fails with the same `forge auth login` guidance.
    """
    # Lazy import — IntercomClient construction triggers ensure_licensed(),
    # which is what we want, but only when this command runs.
    from forge.client.intercom import IntercomClient, IntercomError
    from forge.workspace_config import get_intercom_token

    try:
        token = get_intercom_token(name)
    except (FileNotFoundError, ValueError) as e:
        raise click.ClickException(str(e))

    try:
        client = IntercomClient(token)
        me = client.get("/me")
    except IntercomError as e:
        raise click.ClickException(f"Intercom rejected the token: HTTP {e.status_code} — {e.message}")

    app = me.get("app", {})
    click.echo(f"Token works for workspace '{name}':")
    click.echo(f"  Intercom app:    {app.get('name', '?')}")
    click.echo(f"  app id_code:     {app.get('id_code', '?')}")
    click.echo(f"  Authed admin:    {me.get('name', '?')} ({me.get('email', '?')})")
