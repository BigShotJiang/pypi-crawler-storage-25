"""Fin Voice — external telephony integration + read-only session lookups.

`register_fin_voice` is the Standalone API equivalent for voice: it hands an
inbound call from a NON-Intercom telephony provider (Five9, Zoom Phone, AWS
Connect) to Fin Voice. Intercom-native Phone calls register automatically.

The `get_fin_voice_*` tools are read-only session lookups, useful for AUDITING
Fin Voice usage patterns and configuration.
"""
from forge.mcp.shared import get_client, strip_nulls


def register_fin_voice(
    workspace: str,
    phone_number: str,
    call_id: str,
    source: str | None = None,
    data: dict | None = None,
) -> dict:
    """
    Register an inbound call from an EXTERNAL telephony provider so Fin Voice
    can take over the conversation.

    Use ONLY when integrating Fin Voice into a non-Intercom telephony stack —
    Intercom-native Phone calls are registered automatically and do not need
    this tool.

    phone_number: the caller's phone number.
    call_id: the unique identifier the telephony provider assigns to this call.
    source: telephony provider name — typically 'five9', 'zoom_phone', or
        'aws_connect'.
    data: optional additional metadata from the telephony provider.

    Returns the registered Fin Voice session.
    """
    client = get_client(workspace)
    payload = strip_nulls({
        "phone_number": phone_number,
        "call_id": call_id,
        "source": source,
        "data": data,
    })
    return client.post("/fin_voice/register", payload)


def get_fin_voice_conversation(workspace: str, conversation_id: str) -> dict:
    """
    Retrieve a Fin Voice session by Intercom conversation ID.

    Use this when you already have the Intercom conversation_id (e.g. from
    list_calls or the Inbox) and need the full Fin Voice session payload
    (transcript turns, collects, transfer events, etc.). Useful for AUDITING
    voice flow effectiveness.
    """
    client = get_client(workspace)
    return client.get(f"/fin_voice/conversation/{conversation_id}")


def get_fin_voice_by_external_id(workspace: str, external_id: str) -> dict:
    """
    Retrieve a Fin Voice session by the external telephony provider's call ID.

    Use this when you have the provider-side ID (the same `call_id` passed to
    register_fin_voice) and need to look up the corresponding Fin Voice session.
    """
    client = get_client(workspace)
    return client.get(f"/fin_voice/external_id/{external_id}")


def get_fin_voice_by_phone(workspace: str, phone_number: str) -> dict:
    """
    Retrieve a Fin Voice session by the caller's phone number.

    Use this when you only have the phone number (e.g. from a customer support
    enquiry referencing "the call from +1...") and need to find the matching
    Fin Voice session.
    """
    client = get_client(workspace)
    return client.get(f"/fin_voice/phone_number/{phone_number}")


def get_fin_voice_collect(workspace: str, collect_id: str) -> dict:
    """
    Retrieve a single Fin Voice "collect" — a structured data-collection step
    within a voice session (e.g. capturing a date of birth, order number, or
    yes/no confirmation from the caller).

    collect_id is returned as part of the session payload from
    get_fin_voice_conversation; this tool fetches the full collect with its
    captured value, retries, and validation outcomes.
    """
    client = get_client(workspace)
    return client.get(f"/fin_voice/collect/{collect_id}")
