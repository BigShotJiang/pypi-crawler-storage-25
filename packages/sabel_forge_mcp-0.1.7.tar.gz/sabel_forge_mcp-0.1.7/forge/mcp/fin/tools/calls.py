from forge.mcp.shared import get_client, paginate


def list_calls(workspace: str) -> list[dict]:
    """
    List all voice calls in the workspace.

    Useful for AUDITING Fin Voice usage patterns and configuration. NOT for
    migrating call records — Forge does not own conversation/call migration;
    that's Migr8Now's scope.

    For workspaces with high call volume this can return many results — use
    search_calls if you only need the calls tied to specific conversations.
    """
    client = get_client(workspace)
    return paginate(client, "/calls")


def search_calls(workspace: str, conversation_ids: list[str]) -> list[dict]:
    """Search for calls by their associated Intercom conversation IDs."""
    client = get_client(workspace)
    data = client.post("/calls/search", {"conversation_ids": conversation_ids})
    return data.get("data", [])


def get_call(workspace: str, call_id: str) -> dict:
    """Retrieve a single call by ID, including metadata and duration."""
    client = get_client(workspace)
    return client.get(f"/calls/{call_id}")


def get_call_transcript(workspace: str, call_id: str) -> dict:
    """
    Retrieve the transcript of a call as structured speaker turns with
    timestamps. Useful for AUDITING Fin Voice flow effectiveness on specific
    conversations.
    """
    client = get_client(workspace)
    return client.get(f"/calls/{call_id}/transcript")
