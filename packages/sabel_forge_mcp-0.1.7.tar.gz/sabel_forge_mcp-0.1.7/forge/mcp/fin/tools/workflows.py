from forge.mcp.shared import get_client


def export_workflow(workspace: str, workflow_id: str) -> dict:
    """
    Export a single workflow's full definition (triggers, conditions, actions,
    branches) as JSON.

    Useful for AUDITING — comparing a workspace's workflows to playbook
    standards or to other workspaces in the same industry.

    DISCOVERY: there is no list_workflows tool because Intercom's REST API
    doesn't expose workflows as a listable resource. To get workflow IDs to
    pass here, run snapshot_fin_resources first — it pulls every workflow via
    the intercom CLI's `fin download` and writes them under
    <workspace>/snapshot/fin/.

    LIMITATION: Intercom exposes no create/update workflow API. Workflows can
    only be read here; authoring/editing happens manually in the Intercom UI.
    """
    client = get_client(workspace)
    return client.get(f"/export/workflows/{workflow_id}")
