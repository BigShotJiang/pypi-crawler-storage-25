"""Fin SDK snapshot via the intercom CLI.

`intercom fin download` packages every Fin SDK resource — procedures, data
connectors, guidance, attributes, audiences, workflows, simulations — into
a single ZIP. The Intercom REST API does not expose these as listable
resources, so the CLI is the only way to pull them programmatically.

We scope the call to a specific workspace by passing the workspace's token
via the `INTERCOM_TOKEN` env var (the CLI's documented "skip login" path).
This avoids mutating the CLI's persisted auth state — important because
`intercom auth login --token <X>` only registers the workspace in the CLI's
list, it does NOT switch the active default. A subsequent `fin download`
would silently run against whichever workspace was previously active,
producing a ZIP from the wrong workspace.
"""
from __future__ import annotations

import os
import shutil
import subprocess
import zipfile
from pathlib import Path

from forge.workspace_config import get_intercom_token, workspace_dir


def _run_cli(
    cli: str,
    args: list[str],
    step: str,
    timeout: int,
    env: dict[str, str] | None = None,
) -> None:
    result = subprocess.run(
        [cli, *args],
        capture_output=True,
        text=True,
        timeout=timeout,
        env=env,
    )
    if result.returncode != 0:
        raise RuntimeError(
            f"`intercom {' '.join(args)}` failed during {step} "
            f"(exit {result.returncode}): "
            f"{result.stderr.strip() or result.stdout.strip()}"
        )


def snapshot_fin_resources(
    workspace: str,
    output_dir: str | None = None,
    extract: bool = True,
) -> dict:
    """Capture every Fin SDK resource for a workspace to disk.

    Useful for AUDITING — these resources (procedures, workflows, guidance,
    audiences, attributes, simulations, data connectors) are NOT listable via
    REST, so this is the only way to enumerate them programmatically. It is
    also the only way to discover workflow IDs to pass to export_workflow.

    Standard companion to snapshot_workspace: that one captures the
    REST-exposed config; this one captures the Fin SDK side. Together they
    cover the full configuration surface of a workspace for audit work.

    Mechanics: shells out to the intercom CLI's `fin download`. Scopes the
    call by passing the workspace token via INTERCOM_TOKEN, so the CLI's
    persisted auth state is not mutated and the download is guaranteed to
    come from the requested workspace.

    workspace:  workspace folder name under workspace/.
    output_dir: where to write the ZIP. Defaults to workspace/<Name>/snapshot/.
    extract:    if True (default), unzip into <output_dir>/fin/.

    Returns the ZIP path, optional extraction path, and the file manifest.
    """
    cli = shutil.which("intercom")
    if not cli:
        raise RuntimeError(
            "intercom CLI not found on PATH. Install @intercom/cli and retry."
        )

    token = get_intercom_token(workspace)

    if output_dir:
        out_root = Path(output_dir).expanduser().resolve()
    else:
        out_root = workspace_dir(workspace) / "snapshot"
    out_root.mkdir(parents=True, exist_ok=True)
    zip_path = out_root / "fin-resources.zip"

    _run_cli(
        cli,
        ["fin", "download", "--output", str(zip_path)],
        step="fin download",
        timeout=300,
        env={**os.environ, "INTERCOM_TOKEN": token},
    )

    extracted_to: str | None = None
    with zipfile.ZipFile(zip_path) as zf:
        files = zf.namelist()
        if extract:
            extract_dir = out_root / "fin"
            if extract_dir.exists():
                shutil.rmtree(extract_dir)
            extract_dir.mkdir(parents=True)
            zf.extractall(extract_dir)
            extracted_to = str(extract_dir)

    return {
        "workspace": workspace,
        "zip_path": str(zip_path),
        "extracted_to": extracted_to,
        "size_bytes": zip_path.stat().st_size,
        "file_count": len(files),
        "files": files,
    }
