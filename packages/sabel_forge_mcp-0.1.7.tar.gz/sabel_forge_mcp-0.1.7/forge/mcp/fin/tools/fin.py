"""Fin Standalone API integration tools.

These call the public Fin Standalone API (`/fin/start`, `/fin/reply`) — the
HTTP surface intended for embedding Fin into a NON-Intercom customer
channel (a 3rd-party messenger, custom mobile app, voice gateway, etc.).

They do NOT control Fin behaviour inside Intercom-native Inbox conversations
— Fin runs there automatically when enabled on the inbox. Do not call these
when a user asks "have Fin reply to ticket #N" inside Intercom.
"""
from forge.mcp.shared import get_client, strip_nulls


def fin_standalone_reply(
    workspace: str,
    conversation_id: str,
    message: dict,
    user: dict,
    attachments: list[dict] | None = None,
) -> dict:
    """
    Submit an end-user message to a Fin Standalone API session and receive Fin's reply.

    Use ONLY when integrating Fin into an EXTERNAL customer channel (3rd-party
    messenger, custom widget, mobile app). Do NOT use to make Fin reply inside
    an Intercom-native Inbox conversation — Fin handles that automatically when
    enabled on the inbox.

    conversation_id: the Standalone API session id returned by fin_standalone_start
        (NOT an Intercom Inbox conversation id).
    message: {body: str} — the end-user's message content.
    user: {id: str} or {email: str} — the end-user Fin is responding to.
    attachments: optional list of attachment objects.

    Returns Fin's response payload (message body, sources, handoff status).
    """
    client = get_client(workspace)
    payload = strip_nulls({
        "conversation_id": conversation_id,
        "message": message,
        "user": user,
        "attachments": attachments,
    })
    return client.post("/fin/reply", payload)


def fin_standalone_start(
    workspace: str,
    conversation_id: str,
    message: dict,
    user: dict,
    attachments: list[dict] | None = None,
    conversation_metadata: dict | None = None,
) -> dict:
    """
    Open a new Fin Standalone API session with an opening end-user message.

    Use ONLY when integrating Fin into an EXTERNAL customer channel; not for
    Intercom-native conversations. Pair with fin_standalone_reply for follow-up
    turns in the same session.

    conversation_id: a unique session id YOUR external channel assigns to this
        conversation (not an Intercom Inbox conversation id).
    message: {body: str} — the opening message from the end-user.
    user: {id: str} or {email: str} — identifies the end-user to Fin.
    attachments: optional list of attachment objects.
    conversation_metadata: optional contextual dict the channel passes to Fin
        (e.g. {page_url: "...", account_tier: "..."}).

    Returns Fin's first response and the established session metadata.
    """
    client = get_client(workspace)
    payload = strip_nulls({
        "conversation_id": conversation_id,
        "message": message,
        "user": user,
        "attachments": attachments,
        "conversation_metadata": conversation_metadata,
    })
    return client.post("/fin/start", payload)
