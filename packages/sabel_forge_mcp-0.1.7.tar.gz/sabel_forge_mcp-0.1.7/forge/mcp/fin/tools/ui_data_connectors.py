"""MCP wrapper for the data-connectors UI script.

Intercom's REST API for data connectors has POST (create) and DELETE,
but no PUT/PATCH. This wrapper drives the admin UI's edit page so a
connector can be updated in-place without losing its ID (which would
break workflow/Fin references).
"""
from __future__ import annotations

from forge.mcp.shared_ui import run_ui_script


_MODULE = "forge.ui_automation.data_connectors"


def update_data_connector_via_ui(
    workspace: str,
    payload_path: str,
    dry_run: bool = False,
) -> dict:
    """Update existing data connectors via the admin UI.

    Use this when the REST `update_data_connector` doesn't exist (it
    doesn't — REST is POST/DELETE only). For each connector listed in
    the payload, this tool opens the connector's edit page and applies
    the changes. The connector ID is preserved.

    SIDE EFFECT — opens a Chromium window. Cookies persist per-workspace.

    payload_path: YAML with top-level `updates:` list, each entry:
        - connector_id: "147006"
          description: "..."
          # plus any other supported fields per the script's schema
        Resolved against the workspace directory if relative.
    dry_run: parse + report what would change; no writes.
    """
    return run_ui_script(
        workspace,
        _MODULE,
        mode="--dry-run" if dry_run else "--update",
        payload_path=payload_path,
    )
