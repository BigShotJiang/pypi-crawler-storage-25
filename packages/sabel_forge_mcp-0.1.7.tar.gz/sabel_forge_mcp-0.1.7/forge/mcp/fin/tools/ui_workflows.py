"""MCP wrapper for the workflows UI script.

Intercom's REST API for workflows is read/export only — no create or
update. This wrapper drives the visual builder UI to create new
workflows from a YAML payload. The current scope is Tier 1.5: name +
trigger + save as draft. Step authoring inside the builder canvas is
not yet automated.
"""
from __future__ import annotations

from forge.mcp.shared_ui import run_ui_script


_MODULE = "forge.ui_automation.workflows"


def create_workflow_via_ui(
    workspace: str,
    payload_path: str,
    dry_run: bool = False,
) -> dict:
    """Create draft workflows via the admin UI's visual builder.

    SIDE EFFECT — opens a Chromium window. Cookies persist per-workspace.

    Scope: creates the workflow shell (name + trigger) and saves as
    draft. Adding steps to the canvas is not automated; finish each
    workflow manually in the UI after this runs.

    payload_path: YAML with top-level `workflows:` list. See the
        script's --help for fields. Resolved against the workspace
        directory if relative.
    dry_run: parse + diff against existing workflows; no writes.
    """
    return run_ui_script(
        workspace,
        _MODULE,
        mode="--dry-run" if dry_run else "--create",
        payload_path=payload_path,
    )
