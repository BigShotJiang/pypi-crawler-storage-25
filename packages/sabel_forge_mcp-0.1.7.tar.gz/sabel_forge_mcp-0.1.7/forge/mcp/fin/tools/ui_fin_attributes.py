"""MCP tools for the Fin attributes UI script.

Fin attributes (conversation-scoped enums Fin reasons over) are NOT
creatable via REST or the intercom CLI's Fin SDK — they live behind
the Fin Studio UI at /automation/fin-ai-agent/attributes. These
wrappers shell out to the Playwright script that drives that UI.
"""
from __future__ import annotations

from forge.mcp.shared_ui import run_ui_script


_MODULE = "forge.ui_automation.fin_attributes"


def create_fin_attributes_from_csv(
    workspace: str,
    csv_dir: str,
    dry_run: bool = False,
) -> dict:
    """Create Fin attributes by driving the Intercom Fin Studio UI.

    SIDE EFFECT — opens a visible Chromium window on the user's machine.
    First run requires the user to log in to Intercom interactively;
    cookies persist per-workspace under
    `forge/ui_automation/.profiles/<workspace>/`.

    USE THIS WHEN — the user wants to bulk-create Fin attributes from
    CSV files. There is no REST or CLI alternative; POST /data_attributes
    refuses model="conversation", and `intercom fin attributes` only
    supports `list`.

    csv_dir: directory containing `fin_attribute_<Name>.csv` files (one
        per attribute; rows of `value,description`). Plus an optional
        `_manifest.yaml` providing per-attribute metadata:
            attributes:
              <NameStem>:
                description: "Required attribute-level description (the
                              UI requires this; runs without it fail
                              with 'Attribute not saved')."
                name_override: "Optional display-name override"
        Absolute paths used as-is; relative paths resolve against the
        workspace directory (workspace/<Industry>/<Name>/).

    dry_run: if True, parse CSVs and print what would be created;
        no UI writes.

    Returns: subprocess result dict with `command`, `exit_code`,
    `stdout`, `stderr`. Stdout contains the per-attribute CREATE /
    SKIP / created / failed lines plus a SUMMARY block. Non-zero
    exit_code means the script crashed (not just per-attribute
    failures, which are reported in stdout).

    Timing: ~30-60s per attribute end-to-end on a populated workspace.
    A bulk run of ~25 attributes typically takes 15-25 minutes.
    """
    return run_ui_script(
        workspace,
        _MODULE,
        mode="--dry-run" if dry_run else "--create",
        csv_dir=csv_dir,
    )


def probe_fin_attributes_ui(
    workspace: str,
    probe_create_form: bool = False,
) -> dict:
    """Probe the Fin attributes UI to dump headings, buttons, inputs,
    and a screenshot. Read-only — no writes. Use this when the create
    flow is failing and selectors need verification (e.g. after an
    Intercom UI redesign).

    probe_create_form: if True, click "New" and probe the create form
        (General tab → Values tab → New value sub-form). If False, just
        probe the index page.
    """
    return run_ui_script(
        workspace,
        _MODULE,
        mode="--probe-create-form" if probe_create_form else "--probe",
    )
