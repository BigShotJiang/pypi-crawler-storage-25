from forge.mcp.shared import get_client, paginate, strip_nulls


def list_data_connectors(workspace: str) -> list[dict]:
    """
    List all Fin data connectors in the workspace (summary view).

    Useful for AUDITING — comparing the workspace's external integrations
    against playbook recommendations for the industry.

    Returns a SUMMARY for each connector (id, name, http_method, url, state).
    The full schema — data_inputs, headers, response_fields, object_mappings,
    token configuration — is NOT included. Call get_data_connector for each
    one whose details you need (e.g. before doing audit comparisons against
    a peer workspace's connector schema).
    """
    client = get_client(workspace)
    return paginate(client, "/data_connectors")


def get_data_connector(workspace: str, connector_id: str) -> dict:
    """
    Retrieve full detail of a data connector by ID.

    Includes data_inputs (typed inputs the connector accepts), headers,
    response_fields (extracted JSON paths from the upstream response),
    object_mappings (how response objects flow into Intercom's data model),
    and token configuration.
    """
    client = get_client(workspace)
    return client.get(f"/data_connectors/{connector_id}")


def create_data_connector(
    workspace: str,
    name: str,
    http_method: str = "get",
    url: str | None = None,
    description: str | None = None,
    body: str | None = None,
    direct_fin_usage: bool = False,
    audiences: list[str] | None = None,
    headers: list[dict] | None = None,
    data_inputs: list[dict] | None = None,
    customer_authentication: bool = False,
    bypass_authentication: bool = False,
    validate_missing_attributes: bool = False,
) -> dict:
    """
    Create a Fin data connector — an HTTP integration that workflows or Fin
    can call at conversation time to fetch external data.

    Used during IMPLEMENTATION when an industry playbook calls for an external
    data lookup (order status, account balance, KYC check, etc.).

    LIMITATION: there is no update endpoint for data connectors. To change a
    connector after creation, you must delete and recreate (which loses the
    ID and any workflow references). Use the Playwright UI script in
    forge/ui_automation/ if you need to edit a deployed connector
    in-place — that's the only path that preserves the ID.

    name: display name.
    http_method: 'get', 'post', 'put', 'delete', or 'patch'.
    url: external API URL. Supports {{template_variable}} syntax referring to
        data_inputs.
    description: human-readable purpose.
    body: request body template (supports {{template_variable}}).
    direct_fin_usage: if True, Fin can call this connector directly. If False,
        the connector is callable only from inside workflows.
    audiences: list of 'users', 'leads', 'visitors'.
    headers: list of {name, value} dicts. Values support {{template_variable}}.
    data_inputs: list of {name, type, description, required, default_value}.
        type must be 'string', 'integer', 'decimal', or 'boolean'.
    customer_authentication: require OTP authentication before execution.
    bypass_authentication: skip authentication entirely (public endpoint).
    validate_missing_attributes: validate required inputs have values before
        executing.
    """
    client = get_client(workspace)
    payload = strip_nulls({
        "name": name,
        "http_method": http_method,
        "url": url,
        "description": description,
        "body": body,
        "direct_fin_usage": direct_fin_usage,
        "audiences": audiences,
        "headers": headers,
        "data_inputs": data_inputs,
        "customer_authentication": customer_authentication,
        "bypass_authentication": bypass_authentication,
        "validate_missing_attributes": validate_missing_attributes,
    })
    return client.post("/data_connectors", payload)


def delete_data_connector(workspace: str, connector_id: str) -> dict:
    """
    PERMANENTLY delete a data connector by ID. Cannot be undone. Any workflows
    or Fin behaviours referencing this connector will break.
    """
    client = get_client(workspace)
    return client.delete(f"/data_connectors/{connector_id}")


def list_execution_results(workspace: str, connector_id: str, max_results: int = 50) -> list[dict]:
    """
    List recent execution results for a data connector — success/failure, HTTP
    status, timing, and source (workflow/fin/inbox).

    Useful for AUDITING connector reliability and usage patterns.

    max_results: maximum number of results to return (default 50).
    """
    client = get_client(workspace)
    return paginate(
        client,
        f"/data_connectors/{connector_id}/execution_results",
        max_results=max_results,
    )


def get_execution_result(workspace: str, connector_id: str, execution_id: str) -> dict:
    """
    Retrieve a single execution result including request/response bodies.
    Useful for debugging connector failures or auditing what data Fin sent
    upstream on a specific call.
    """
    client = get_client(workspace)
    return client.get(
        f"/data_connectors/{connector_id}/execution_results/{execution_id}"
    )
