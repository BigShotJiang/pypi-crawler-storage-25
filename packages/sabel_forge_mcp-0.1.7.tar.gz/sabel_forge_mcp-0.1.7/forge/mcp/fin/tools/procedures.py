"""Fin SDK procedures via the intercom CLI.

Procedures are YAML-defined Fin agent capabilities — they describe
multi-step conversations Fin can run (data collection, branching, data
connector calls, response composition). Intercom's REST API does NOT
expose procedures; the only programmatic path is the `intercom fin
procedures` CLI.

These tools shell out to that CLI with `INTERCOM_TOKEN` scoped per
workspace (same pattern as `snapshot_fin_resources`) so the CLI's
persisted auth state is never mutated.
"""
from __future__ import annotations

import json
import os
import shutil
import subprocess
from pathlib import Path

from forge.workspace_config import get_intercom_token, workspace_dir


def _resolve_cli() -> str:
    cli = shutil.which("intercom")
    if not cli:
        raise RuntimeError(
            "intercom CLI not found on PATH. Install @intercom/cli and retry."
        )
    return cli


def _run_capture(args: list[str], token: str, timeout: int = 60) -> str:
    """Run an `intercom` CLI subcommand with INTERCOM_TOKEN scoped, capture
    stdout, raise on non-zero exit. Returns stdout as a string."""
    cli = _resolve_cli()
    env = {**os.environ, "INTERCOM_TOKEN": token}
    result = subprocess.run(
        [cli, *args],
        capture_output=True,
        text=True,
        timeout=timeout,
        env=env,
    )
    if result.returncode != 0:
        raise RuntimeError(
            f"`intercom {' '.join(args)}` failed (exit {result.returncode}): "
            f"{result.stderr.strip() or result.stdout.strip()}"
        )
    return result.stdout


def list_procedures(workspace: str) -> list[dict]:
    """List every Fin procedure in the workspace.

    Useful for AUDITING — comparing the workspace's procedures against
    playbook recommendations for the industry, or finding procedures by
    name to fetch their full YAML for review.

    Returns a list of {id, name} dicts (CLI summary view). Use
    get_procedure(workspace, id) to fetch the full YAML for any procedure.

    LIMITATION: procedures are not exposed via REST. This shells out to
    `intercom fin procedures list --json` with INTERCOM_TOKEN scoped to
    the requested workspace.
    """
    token = get_intercom_token(workspace)
    out = _run_capture(["fin", "procedures", "list", "--json"], token)
    if not out.strip():
        return []
    return json.loads(out)


def get_procedure(workspace: str, procedure_id: str) -> dict:
    """Retrieve a single procedure's full YAML definition by ID.

    Useful for AUDITING (review what a procedure does), for COPYING a
    procedure between workspaces (get from source, upload_procedure to
    target), or as the source-of-truth before iterating on a procedure
    locally and re-uploading.

    procedure_id: the procedure's ID (use list_procedures to discover).

    Returns a dict with:
      - id: the procedure id
      - yaml: the full YAML definition as a single string (suitable to
        write to disk and feed into upload_procedure unchanged)

    Shells out to `intercom fin procedures get <id>`.
    """
    token = get_intercom_token(workspace)
    out = _run_capture(["fin", "procedures", "get", procedure_id], token)
    return {"id": procedure_id, "yaml": out}


def upload_procedure(workspace: str, file_path: str) -> dict:
    """Upload a procedure YAML file to the workspace, creating or updating
    a procedure (the file's metadata determines the target).

    Used during IMPLEMENTATION — once you've authored a procedure YAML
    (manually or via agent), this pushes it to the workspace. Pair with
    list_procedures + get_procedure to verify after upload.

    file_path: path to the YAML file. Absolute paths used as-is; relative
        paths are resolved against the workspace directory
        (workspace/<Name>/) so e.g. "procedures/my_proc.yaml" resolves to
        "workspace/<Name>/procedures/my_proc.yaml".

    Returns the parsed CLI output (id, status fields if any). Raises on
    non-zero exit.

    Shells out to `intercom fin procedures upload <file> --json`.
    """
    token = get_intercom_token(workspace)
    p = Path(file_path).expanduser()
    if not p.is_absolute():
        p = workspace_dir(workspace) / p
    p = p.resolve()
    if not p.exists():
        raise RuntimeError(f"Procedure file not found: {p}")
    out = _run_capture(["fin", "procedures", "upload", str(p), "--json"], token, timeout=120)
    parsed: dict = {"file": str(p)}
    if out.strip():
        try:
            data = json.loads(out)
            if isinstance(data, dict):
                parsed.update(data)
            else:
                parsed["raw"] = data
        except json.JSONDecodeError:
            parsed["raw_output"] = out.strip()
    return parsed
