from forge.mcp.shared import get_client, paginate, strip_nulls


# ── Content Import Sources ────────────────────────────────────────────────────

def list_content_import_sources(workspace: str) -> list[dict]:
    """
    List all AI content import sources — external URLs that Fin crawls for
    knowledge base content.

    Useful for AUDITING — comparing what external content the workspace pulls
    in against playbook recommendations for the industry.
    """
    client = get_client(workspace)
    return paginate(client, "/ai/content_import_sources")


def get_content_import_source(workspace: str, source_id: str) -> dict:
    """
    Retrieve a single content import source by ID, including its sync status,
    last crawl results, and configuration.
    """
    client = get_client(workspace)
    return client.get(f"/ai/content_import_sources/{source_id}")


def create_content_import_source(
    workspace: str,
    url: str,
    sync_behavior: str = "api",
    status: str = "active",
) -> dict:
    """
    Create an AI content import source (external URL for Fin to crawl).

    Used during IMPLEMENTATION when an industry playbook calls for ingesting
    a public knowledge base, support site, or product docs into Fin.

    url: the URL to crawl for content.
    sync_behavior: MUST be 'api' on creation — Intercom does not accept
        'automated' or 'manual' at create time. Sources can later be
        transitioned to 'automated' (Intercom-scheduled crawl) or 'manual' via
        update_content_import_source.
    status: 'active' or 'deactivated'.
    """
    client = get_client(workspace)
    payload = strip_nulls({
        "url": url,
        "sync_behavior": sync_behavior,
        "status": status,
    })
    return client.post("/ai/content_import_sources", payload)


def update_content_import_source(
    workspace: str,
    source_id: str,
    url: str,
    sync_behavior: str | None = None,
    status: str | None = None,
) -> dict:
    """
    Update an AI content import source.

    NOTE: `url` is required even when only changing sync_behavior or status —
    Intercom's PUT for this endpoint expects the URL on every call. Fetch the
    current source with get_content_import_source first to know the value.

    sync_behavior: 'api', 'automated' (Intercom-scheduled crawl), or 'manual'
        (crawl on demand only).
    status: 'active' or 'deactivated'.
    """
    client = get_client(workspace)
    payload = strip_nulls({
        "url": url,
        "sync_behavior": sync_behavior,
        "status": status,
    })
    return client.put(f"/ai/content_import_sources/{source_id}", payload)


def delete_content_import_source(workspace: str, source_id: str) -> dict:
    """
    PERMANENTLY delete an AI content import source by ID. Cannot be undone.
    All external pages associated with this source are also removed from Fin's
    knowledge base.
    """
    client = get_client(workspace)
    return client.delete(f"/ai/content_import_sources/{source_id}")


# ── External Pages ────────────────────────────────────────────────────────────

def list_external_pages(workspace: str) -> list[dict]:
    """
    List all AI external pages — manually uploaded HTML content for the Fin
    knowledge base (as opposed to crawled content from import sources).

    Useful for AUDITING — comparing what custom-authored content the workspace
    has fed to Fin against playbook recommendations.

    For workspaces with thousands of pages this can return a lot — prefer
    snapshot_workspace for bulk enumeration without inspecting bodies.
    """
    client = get_client(workspace)
    return paginate(client, "/ai/external_pages")


def get_external_page(workspace: str, page_id: str) -> dict:
    """
    Retrieve a single external page by ID, including its full HTML body and
    Fin availability flags.
    """
    client = get_client(workspace)
    return client.get(f"/ai/external_pages/{page_id}")


def create_external_page(
    workspace: str,
    title: str,
    html: str,
    source_id: int,
    external_id: str,
    locale: str = "en",
    url: str | None = None,
    ai_agent_availability: bool = True,
    ai_copilot_availability: bool = True,
) -> dict:
    """
    Create an external page for Fin's AI knowledge base.

    Used during IMPLEMENTATION to seed Fin with custom HTML content (FAQs,
    policy docs, product guides) that doesn't live behind a crawlable URL.
    Depends on: a content import source (use list_content_import_sources to
    find one or create_content_import_source to make one).

    title: page title.
    html: full HTML content of the page.
    source_id: ID of the content_import_source this page belongs to (use
        list_content_import_sources to discover).
    external_id: your own identifier for this page (must be unique within the
        source).
    locale: language code, e.g. 'en'.
    url: canonical URL of the original page (optional).
    ai_agent_availability: make available to Fin AI agent (default True).
    ai_copilot_availability: make available to AI Copilot (default True).
    """
    client = get_client(workspace)
    payload = strip_nulls({
        "title": title,
        "html": html,
        "source_id": source_id,
        "external_id": external_id,
        "locale": locale,
        "url": url,
        "ai_agent_availability": ai_agent_availability,
        "ai_copilot_availability": ai_copilot_availability,
    })
    return client.post("/ai/external_pages", payload)


def update_external_page(
    workspace: str,
    page_id: str,
    title: str,
    html: str,
    url: str,
    source_id: int,
    locale: str = "en",
    external_id: str | None = None,
    ai_agent_availability: bool | None = None,
    ai_copilot_availability: bool | None = None,
) -> dict:
    """
    Update an existing external page.

    IMPORTANT: this endpoint is a FULL-document PUT, not a partial PATCH —
    title, html, url, and source_id are REQUIRED on every call even if you
    only want to change one field. Sending a minimal payload will either
    return a 400 or silently blank out the omitted fields. Always
    get_external_page first, merge your changes into the returned object, and
    send the complete payload here.

    page_id: the page to update.
    ai_agent_availability / ai_copilot_availability: toggle Fin / Copilot
        access (omit to leave unchanged).
    """
    client = get_client(workspace)
    payload = strip_nulls({
        "title": title,
        "html": html,
        "url": url,
        "source_id": source_id,
        "locale": locale,
        "external_id": external_id,
        "ai_agent_availability": ai_agent_availability,
        "ai_copilot_availability": ai_copilot_availability,
    })
    return client.put(f"/ai/external_pages/{page_id}", payload)


def delete_external_page(workspace: str, page_id: str) -> dict:
    """
    PERMANENTLY delete an external page by ID. Cannot be undone. The page is
    immediately removed from Fin's knowledge base.
    """
    client = get_client(workspace)
    return client.delete(f"/ai/external_pages/{page_id}")
