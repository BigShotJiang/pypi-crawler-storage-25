from forge.mcp.shared import get_client, paginate, strip_nulls


def list_articles(workspace: str) -> list[dict]:
    """
    List all help center articles in the workspace.

    Useful for AUDITING — comparing the workspace's customer-facing knowledge
    base against playbook recommendations for the industry.

    For workspaces with thousands of articles this can return a lot — prefer
    snapshot_workspace if you only need to enumerate without inspecting bodies.
    """
    client = get_client(workspace)
    return paginate(client, "/articles")


def get_article(workspace: str, article_id: str) -> dict:
    """Retrieve a single article by ID, including full body content."""
    client = get_client(workspace)
    return client.get(f"/articles/{article_id}")


def search_articles(workspace: str, query: str) -> list[dict]:
    """
    Search articles by keyword.

    Returns a flat list of matching article objects (the underlying API also
    returns highlight metadata; this tool returns articles only).
    """
    client = get_client(workspace)
    data = client.get("/articles/search", params={"phrase": query})
    return data.get("articles", {}).get("articles", data.get("data", []))


def create_article(
    workspace: str,
    title: str,
    author_id: int,
    body: str | None = None,
    description: str | None = None,
    state: str = "draft",
    parent_id: int | None = None,
    parent_type: str | None = None,
    folder_id: int | None = None,
    translated_content: dict | None = None,
) -> dict:
    """
    Create a help center article.

    Used during IMPLEMENTATION to seed customer-facing knowledge base content.
    Depends on:
      - author_id: a real admin id (use list_admins to discover).
      - parent_id (optional): a help center collection id (use
        list_help_center_collections).

    title: article title.
    author_id: ID of the admin who authored this article (use list_admins).
    body: HTML body content.
    description: short summary shown in search results.
    state: 'draft' (default) or 'published'.
    parent_id: ID of the collection this article belongs to.
    parent_type: 'collection' (required when parent_id is set).
    folder_id: ID of a folder to organise the article within the help center.
    translated_content: dict of locale → {title, description, body, author_id, state}.
    """
    client = get_client(workspace)
    payload = strip_nulls({
        "title": title,
        "author_id": author_id,
        "body": body,
        "description": description,
        "state": state,
        "parent_id": parent_id,
        "parent_type": parent_type,
        "folder_id": folder_id,
        "translated_content": translated_content,
    })
    return client.post("/articles", payload)


def update_article(
    workspace: str,
    article_id: str,
    title: str | None = None,
    author_id: int | None = None,
    body: str | None = None,
    description: str | None = None,
    state: str | None = None,
    parent_id: str | None = None,
    parent_type: str | None = None,
    folder_id: int | None = None,
    translated_content: dict | None = None,
) -> dict:
    """
    Update an existing article. Sends a partial payload — omitted fields are
    unchanged.
    """
    client = get_client(workspace)
    payload = strip_nulls({
        "title": title,
        "author_id": author_id,
        "body": body,
        "description": description,
        "state": state,
        "parent_id": parent_id,
        "parent_type": parent_type,
        "folder_id": folder_id,
        "translated_content": translated_content,
    })
    return client.put(f"/articles/{article_id}", payload)


def delete_article(workspace: str, article_id: str) -> dict:
    """PERMANENTLY delete an article by ID. Cannot be undone."""
    client = get_client(workspace)
    return client.delete(f"/articles/{article_id}")
