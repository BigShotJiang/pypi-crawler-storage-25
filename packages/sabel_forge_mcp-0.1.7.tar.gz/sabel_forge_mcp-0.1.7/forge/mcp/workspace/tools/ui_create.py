"""MCP wrappers around the workspace-side Playwright UI scripts.

These resources have no REST POST endpoint (or only partial REST
support) and must be authored through the Intercom admin UI:

  - away_status_reasons      — REST is GET-only
  - brands                   — REST is read-only
  - macros                   — REST is read-only
  - newsfeeds                — REST is read-only
  - subscription_types       — REST is read-only
  - teams                    — REST is read-only
  - ticket_states            — REST is read-only (list_ticket_states only)
  - conversation_attributes  — POST /data_attributes refuses model="conversation"

Each wrapper shells out to the corresponding `forge.ui_automation.*`
module via `forge.mcp.shared_ui.run_ui_script`, which opens a Chromium
window on the user's machine. See shared_ui.py for caveats.

The companion read-only REST tools (list_*, get_*) live in their own
files and remain the right starting point for AUDIT work — only fall
back here when the user wants to CREATE.
"""
from __future__ import annotations

from forge.mcp.shared_ui import run_ui_script


# ── away_status_reasons ──────────────────────────────────────────────


def create_away_status_reasons_via_ui(
    workspace: str,
    payload_path: str,
    dry_run: bool = False,
) -> dict:
    """Create away-status reasons via the admin UI (Settings → Helpdesk →
    Assignments → "Customize away reasons").

    SIDE EFFECT — opens a Chromium window. Cookies persist per-workspace.

    payload_path: YAML with top-level `reasons:` list, each row having
        `name:` and optional `emoji:`. Resolved against the workspace
        directory if relative.
    dry_run: parse + diff against the existing list; no writes.
    """
    return run_ui_script(
        workspace,
        "forge.ui_automation.away_status_reasons",
        mode="--dry-run" if dry_run else "--create",
        payload_path=payload_path,
    )


# ── brands ───────────────────────────────────────────────────────────


def create_brands_via_ui(
    workspace: str,
    payload_path: str,
    dry_run: bool = False,
) -> dict:
    """Create brands via the admin UI (Settings → Brands).

    SIDE EFFECT — opens a Chromium window. Cookies persist per-workspace.

    payload_path: YAML with top-level `brands:` list. See the script's
        --help for the exact schema. Resolved against workspace dir if
        relative.
    dry_run: parse + diff against existing brands; no writes.
    """
    return run_ui_script(
        workspace,
        "forge.ui_automation.brands",
        mode="--dry-run" if dry_run else "--create",
        payload_path=payload_path,
    )


# ── macros ───────────────────────────────────────────────────────────


def create_macros_via_ui(
    workspace: str,
    payload_path: str,
    dry_run: bool = False,
) -> dict:
    """Create macros (saved replies) via the admin UI.

    SIDE EFFECT — opens a Chromium window. Cookies persist per-workspace.

    payload_path: YAML with top-level `macros:` list of {name, body, ...}.
        Resolved against the workspace directory if relative.
    dry_run: parse + diff against existing macros; no writes.
    """
    return run_ui_script(
        workspace,
        "forge.ui_automation.macros",
        mode="--dry-run" if dry_run else "--create",
        payload_path=payload_path,
    )


# ── newsfeeds ────────────────────────────────────────────────────────


def create_newsfeeds_via_ui(
    workspace: str,
    payload_path: str,
    dry_run: bool = False,
) -> dict:
    """Create newsfeeds via the admin UI.

    SIDE EFFECT — opens a Chromium window. Cookies persist per-workspace.

    payload_path: YAML with top-level `newsfeeds:` list. Resolved against
        the workspace directory if relative.
    dry_run: parse + diff against existing newsfeeds; no writes.
    """
    return run_ui_script(
        workspace,
        "forge.ui_automation.newsfeeds",
        mode="--dry-run" if dry_run else "--create",
        payload_path=payload_path,
    )


# ── subscription_types ───────────────────────────────────────────────


def create_subscription_types_via_ui(
    workspace: str,
    payload_path: str,
    dry_run: bool = False,
) -> dict:
    """Create subscription types via the admin UI.

    SIDE EFFECT — opens a Chromium window. Cookies persist per-workspace.

    payload_path: YAML with top-level `subscriptions:` list. Resolved
        against the workspace directory if relative.
    dry_run: parse + diff against existing subscription types; no writes.
    """
    return run_ui_script(
        workspace,
        "forge.ui_automation.subscription_types",
        mode="--dry-run" if dry_run else "--create",
        payload_path=payload_path,
    )


# ── teams ────────────────────────────────────────────────────────────


def create_teams_via_ui(
    workspace: str,
    payload_path: str,
    dry_run: bool = False,
) -> dict:
    """Create teams (team inboxes) via the admin UI.

    SIDE EFFECT — opens a Chromium window. Cookies persist per-workspace.

    payload_path: YAML with top-level `teams:` list. Resolved against the
        workspace directory if relative.
    dry_run: parse + diff against existing teams; no writes.
    """
    return run_ui_script(
        workspace,
        "forge.ui_automation.teams",
        mode="--dry-run" if dry_run else "--create",
        payload_path=payload_path,
    )


# ── ticket_states ────────────────────────────────────────────────────


def create_ticket_states_via_ui(
    workspace: str,
    payload_path: str,
    dry_run: bool = False,
) -> dict:
    """Create ticket states via the admin UI at Settings → Helpdesk →
    Tickets → Ticket states.

    REST is read-only (`list_ticket_states` only). Each state is bucketed
    into one of four Intercom-internal categories: `submitted`,
    `in_progress`, `waiting_on_customer`, `resolved`. Multiple states
    can share a category (e.g. two `submitted` states named "Triage" and
    "Awaiting review").

    The form does NOT currently include ticket-type assignment — that's
    a separate UI step after creation. If the workspace has multiple
    ticket types and a state should only apply to some, link them
    manually after this tool runs.

    SIDE EFFECT — opens a Chromium window. Cookies persist per-workspace.

    payload_path: YAML with top-level `states:` list, each row:
        - internal_label: "Triage"
          external_label: "Received"
          category: submitted   # required: submitted|in_progress|waiting_on_customer|resolved
        Resolved against the workspace directory if relative.
    dry_run: parse + diff against existing states; no writes.
    """
    return run_ui_script(
        workspace,
        "forge.ui_automation.ticket_states",
        mode="--dry-run" if dry_run else "--create",
        payload_path=payload_path,
    )


# ── conversation custom attributes ───────────────────────────────────


def create_conversation_attributes_via_ui(
    workspace: str,
    csv_dir: str,
    dry_run: bool = False,
) -> dict:
    """Create conversation custom attributes (model=conversation) via
    the admin UI at Settings → Data → Conversations/Tickets.

    REST POST refuses model="conversation" (verified empirically — see
    the Intercom API spec which still lists only contact/company), so
    this UI path is the only programmatic option.

    Distinct from `create_fin_attributes_from_csv` on forge-fin: that
    tool authors Fin-Studio reasoning attributes (with per-option
    descriptions Fin uses to pick a value); this one authors plain
    data-attribute fields. Per-option descriptions in source CSVs are
    intentionally dropped here — Intercom's plain conversation list
    attributes only store flat option strings.

    SIDE EFFECT — opens a Chromium window. Cookies persist per-workspace.

    csv_dir: directory containing `fin_attribute_<Name>.csv` files (one
        per attribute; rows of `value,description` — only `value` is
        used). Plus an optional `_manifest.yaml`:
            attributes:
              <NameStem>:
                description: "..."
                data_type: list   # default: 'list' if rows present, else 'string'
                name_override: "Optional display-name override"
        Resolved against workspace_dir if relative.
    dry_run: parse + diff against existing attributes; no writes.

    Timing: ~30s per attribute; option entry is one click + fill per row
    so it's slightly slower for large lists than the Fin-attributes CSV
    upload path.
    """
    return run_ui_script(
        workspace,
        "forge.ui_automation.conversation_attributes",
        mode="--dry-run" if dry_run else "--create",
        csv_dir=csv_dir,
    )
