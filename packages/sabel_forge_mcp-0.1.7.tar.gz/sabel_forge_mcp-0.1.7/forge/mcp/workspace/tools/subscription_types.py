from forge.mcp.shared import get_client


def list_subscription_types(workspace: str) -> list[dict]:
    """
    List all subscription types (email/SMS opt-in categories) in the
    workspace.

    Useful for AUDITING — confirming the workspace has the expected
    consent/opt-in categories for the industry (often regulated, e.g.
    marketing vs. transactional vs. account-related).

    LIMITATION: subscription types are read-only via API. Creation requires
    the Intercom UI.
    """
    client = get_client(workspace)
    data = client.get("/subscription_types")
    return data.get("data", [])
