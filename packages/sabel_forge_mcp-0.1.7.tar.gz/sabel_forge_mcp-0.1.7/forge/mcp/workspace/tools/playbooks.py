"""list_playbooks + get_playbook MCP tools.

Industry implementation playbooks — the best-practice baselines that
should drive workspace provisioning. Stored on the forge backend (not
in the wheel) so they're license-gated and updateable without
re-publishing forge-mcp.

The agent driving forge should call these BEFORE provisioning a new
workspace in a known vertical, so its plan is grounded in the playbook
rather than improvised.
"""
from __future__ import annotations

import httpx

from forge import license as lic


def _backend_url() -> str:
    import os
    return os.environ.get("FORGE_API_URL", lic.DEFAULT_BACKEND_URL).rstrip("/")


def _bearer_token() -> str:
    """Read the api_key from the local license cache. Surfaces a clean
    error if no cache exists rather than letting it 401 from the server."""
    cached = lic.load_cache()
    if cached is None:
        raise RuntimeError(
            "No forge license cache found. Run `forge auth login --key ...` first."
        )
    return cached.api_key


def list_playbooks() -> list[dict]:
    """List every industry playbook available to this license.

    Returns a list of {industry, summary, updated_at}. Use this to
    discover what playbooks exist; then `get_playbook(industry)` for
    the full markdown.
    """
    lic.ensure_licensed()
    resp = httpx.get(
        f"{_backend_url()}/v1/playbooks",
        headers={"Authorization": f"Bearer {_bearer_token()}"},
        timeout=15.0,
    )
    resp.raise_for_status()
    return resp.json()


def get_playbook(industry: str) -> dict:
    """Fetch the full markdown for one industry playbook.

    industry: short tag like "gambling", "ecommerce", "fintech". Match
        the `industry` field returned by list_playbooks.

    Returns {industry, summary, content_markdown, updated_at}. The
    agent should treat content_markdown as authoritative and ground its
    provisioning plan in it.

    Note: each fetch is uniquely watermarked per (partner, machine,
    fetch). Stripping or altering the watermark is a license violation.
    The audit log on the backend records every fetch.
    """
    lic.ensure_licensed()
    resp = httpx.get(
        f"{_backend_url()}/v1/playbooks/{industry}",
        headers={
            "Authorization": f"Bearer {_bearer_token()}",
            "X-Forge-Machine-Id": lic.machine_id_hash(),
        },
        timeout=15.0,
    )
    if resp.status_code == 404:
        raise RuntimeError(f"No playbook for industry '{industry}'.")
    resp.raise_for_status()
    return resp.json()
