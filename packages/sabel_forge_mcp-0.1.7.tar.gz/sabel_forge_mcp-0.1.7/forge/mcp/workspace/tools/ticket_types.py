from forge.mcp.shared import get_client, strip_nulls


def list_ticket_types(workspace: str) -> list[dict]:
    """
    List all ticket types in the workspace. Each ticket type includes its
    custom attributes inline.

    Useful for AUDITING — comparing the workspace's ticket schema against
    playbook recommendations for the industry.
    """
    client = get_client(workspace)
    data = client.get("/ticket_types")
    return data.get("ticket_types", data.get("data", []))


def get_ticket_type(workspace: str, ticket_type_id: str) -> dict:
    """Retrieve a single ticket type by ID, including all its custom attributes."""
    client = get_client(workspace)
    return client.get(f"/ticket_types/{ticket_type_id}")


def create_ticket_type(
    workspace: str,
    name: str,
    description: str | None = None,
    category: str = "Customer",
    icon: str | None = None,
    is_internal: bool = False,
) -> dict:
    """
    Create a new ticket type SHELL (no custom attributes yet).

    Used during IMPLEMENTATION. After creating the shell, add custom fields
    via create_ticket_type_attribute. Order matters: the ticket type appears
    in the inbox the moment it's created, so for client-facing types consider
    finishing attribute setup before agents start using it (or set
    is_internal=True until the schema is complete).

    name: display name of the ticket type.
    description: optional description.
    category: 'Customer', 'Back-office', or 'Tracker'.
    icon: emoji icon for the ticket type.
    is_internal: if True, this is an internal (back-office) ticket type that
        end-users can't see.
    """
    client = get_client(workspace)
    payload = strip_nulls({
        "name": name,
        "description": description,
        "category": category,
        "icon": icon,
        "is_internal": is_internal,
    })
    return client.post("/ticket_types", payload)


def update_ticket_type(
    workspace: str,
    ticket_type_id: str,
    name: str | None = None,
    description: str | None = None,
    category: str | None = None,
    icon: str | None = None,
    archived: bool | None = None,
    is_internal: bool | None = None,
) -> dict:
    """
    Update an existing ticket type. Sends a partial payload — omitted fields
    are unchanged.

    NOTE: there is NO delete endpoint for ticket types. Set archived=True to
    retire a type (it remains in workspace history and on existing tickets).
    """
    client = get_client(workspace)
    payload = strip_nulls({
        "name": name,
        "description": description,
        "category": category,
        "icon": icon,
        "archived": archived,
        "is_internal": is_internal,
    })
    return client.put(f"/ticket_types/{ticket_type_id}", payload)


def list_ticket_states(workspace: str) -> list[dict]:
    """
    List all ticket states (the system pipeline states a ticket can be in,
    e.g. "Submitted", "In progress", "Resolved").

    Useful for AUDITING workflow / SLA configuration. Building source→target
    state ID maps is essential when implementing routing rules that reference
    states.

    LIMITATION: ticket states are system-defined; they cannot be created or
    modified via API or UI.
    """
    client = get_client(workspace)
    data = client.get("/ticket_states")
    return data.get("ticket_states", data.get("data", []))


def create_ticket_type_attribute(
    workspace: str,
    ticket_type_id: str,
    name: str,
    description: str,
    data_type: str,
    required_to_create: bool = False,
    required_to_create_for_contacts: bool = False,
    visible_on_create: bool = True,
    visible_to_contacts: bool = False,
    multiline: bool = False,
    list_items: str | None = None,
    allow_multiple_values: bool = False,
) -> dict:
    """
    Add a custom attribute to a ticket type.

    Used during IMPLEMENTATION immediately after create_ticket_type, to
    populate the ticket type's schema. Depends on: an existing ticket type
    (use list_ticket_types or get the id from create_ticket_type's response).

    ticket_type_id: the ticket type this attribute belongs to.
    name: attribute name.
    description: attribute description.
    data_type: 'string', 'list', 'integer', 'decimal', 'boolean', 'datetime',
        or 'files'.
    required_to_create: whether agents must fill this in when creating a ticket.
    required_to_create_for_contacts: whether contacts must fill this in.
    visible_on_create: whether shown in the creation form.
    visible_to_contacts: whether contacts can see this attribute.
    multiline: for 'string' type, allow multiple lines.
    list_items: comma-separated values for 'list' type (e.g. 'Option A,Option B').
    allow_multiple_values: for 'list' type, allow selecting multiple values.
    """
    client = get_client(workspace)
    payload = strip_nulls({
        "name": name,
        "description": description,
        "data_type": data_type,
        "required_to_create": required_to_create,
        "required_to_create_for_contacts": required_to_create_for_contacts,
        "visible_on_create": visible_on_create,
        "visible_to_contacts": visible_to_contacts,
        "multiline": multiline,
        "list_items": list_items,
        "allow_multiple_values": allow_multiple_values,
    })
    return client.post(f"/ticket_types/{ticket_type_id}/attributes", payload)


def update_ticket_type_attribute(
    workspace: str,
    ticket_type_id: str,
    attribute_id: str,
    name: str | None = None,
    description: str | None = None,
    required_to_create: bool | None = None,
    required_to_create_for_contacts: bool | None = None,
    visible_on_create: bool | None = None,
    visible_to_contacts: bool | None = None,
    multiline: bool | None = None,
    list_items: str | None = None,
    allow_multiple_values: bool | None = None,
    archived: bool | None = None,
) -> dict:
    """
    Update an existing ticket type attribute. Sends a partial payload —
    omitted fields are unchanged.

    NOTE: there is NO delete endpoint. Set archived=True to retire an
    attribute (it remains in workspace history and on existing tickets).
    """
    client = get_client(workspace)
    payload = strip_nulls({
        "name": name,
        "description": description,
        "required_to_create": required_to_create,
        "required_to_create_for_contacts": required_to_create_for_contacts,
        "visible_on_create": visible_on_create,
        "visible_to_contacts": visible_to_contacts,
        "multiline": multiline,
        "list_items": list_items,
        "allow_multiple_values": allow_multiple_values,
        "archived": archived,
    })
    return client.put(f"/ticket_types/{ticket_type_id}/attributes/{attribute_id}", payload)
