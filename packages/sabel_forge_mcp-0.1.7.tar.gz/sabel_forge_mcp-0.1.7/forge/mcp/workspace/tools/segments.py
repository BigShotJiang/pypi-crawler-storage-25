from forge.mcp.shared import get_client


def list_segments(workspace: str, segment_type: str | None = None) -> list[dict]:
    """
    List all segments (saved contact filters) in the workspace.

    Useful for AUDITING — comparing the workspace's segments against playbook
    recommendations (which segments an industry typically uses for
    targeting/reporting).

    segment_type: optional filter — 'user' or 'lead'.

    LIMITATION: segments are read-only via API. Creation, filter editing, and
    deletion happen through the Intercom UI.
    """
    client = get_client(workspace)
    params = {}
    if segment_type:
        params["type"] = segment_type
    data = client.get("/segments", params=params or None)
    return data.get("segments", data.get("data", []))


def get_segment(workspace: str, segment_id: str) -> dict:
    """Retrieve a single segment by ID, including its filter rules."""
    client = get_client(workspace)
    return client.get(f"/segments/{segment_id}")
