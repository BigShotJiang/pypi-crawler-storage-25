from forge.mcp.shared import get_client, strip_nulls


def list_admins(workspace: str) -> list[dict]:
    """
    List all admins (teammates) in the workspace. Returns id, name, email,
    job_title, and away_mode_enabled for each.

    Useful for AUDITING — comparing the workspace's teammate roster against
    expectations, or building source→target ID maps for cross-workspace
    references in articles, macros, news items, etc.

    LIMITATION: admins are read-only via API except for set_admin_away.
    Inviting / removing admins must happen through the Intercom UI.
    """
    client = get_client(workspace)
    data = client.get("/admins")
    return data.get("admins", [])


def get_admin(workspace: str, admin_id: str) -> dict:
    """Retrieve a single admin by ID."""
    client = get_client(workspace)
    return client.get(f"/admins/{admin_id}")


def set_admin_away(
    workspace: str,
    admin_id: str,
    away_mode_enabled: bool,
    away_mode_reassign: bool = False,
    away_status_reason_id: int | None = None,
) -> dict:
    """
    Set an admin's away-mode status for the Inbox.

    This is the only mutating admin endpoint Intercom exposes via API; admin
    creation, role changes, and removals all happen through the Intercom UI.

    away_mode_enabled: True to mark the admin as away, False to mark active.
    away_mode_reassign: if True, conversations CURRENTLY ASSIGNED to this
        admin are routed to their team's reassignment inbox (configured per
        team in the Intercom UI). If False (default), they remain assigned to
        this admin while away.
    away_status_reason_id: optional ID of an entry from
        list_away_status_reasons to attach as the away reason (e.g. "On lunch",
        "In a meeting").
    """
    client = get_client(workspace)
    payload = strip_nulls({
        "away_mode_enabled": away_mode_enabled,
        "away_mode_reassign": away_mode_reassign,
        "away_status_reason_id": away_status_reason_id,
    })
    return client.put(f"/admins/{admin_id}/away", payload)
