from forge.mcp.shared import get_client


def list_away_status_reasons(workspace: str) -> list[dict]:
    """
    List all custom away status reasons (e.g. "Lunch", "In a meeting") that
    admins can attach to their away mode.

    Useful for AUDITING — comparing the workspace's away reasons against
    playbook recommendations for the industry. Pair with set_admin_away
    (which accepts a reason id) when implementing teammate workflows.

    LIMITATION: away status reasons are read-only via API. Creation requires
    the Intercom UI (Settings → Helpdesk → Assignments → "Customize away
    reasons") or the Playwright UI script in forge/ui_automation/.
    """
    client = get_client(workspace)
    data = client.get("/away_status_reasons")
    return data.get("away_status_reasons", data.get("data", []))
