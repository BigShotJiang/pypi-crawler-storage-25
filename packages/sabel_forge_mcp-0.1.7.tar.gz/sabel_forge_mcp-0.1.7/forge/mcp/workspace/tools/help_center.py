from forge.mcp.shared import get_client, paginate, strip_nulls


def list_help_centers(workspace: str) -> list[dict]:
    """
    List all help centers in the workspace.

    Useful for AUDITING — confirming the workspace has the expected help
    centers per industry / brand setup.
    """
    client = get_client(workspace)
    data = client.get("/help_center/help_centers")
    return data.get("data", [])


def get_help_center(workspace: str, help_center_id: str) -> dict:
    """Retrieve a single help center by ID."""
    client = get_client(workspace)
    return client.get(f"/help_center/help_centers/{help_center_id}")


def list_help_center_collections(
    workspace: str,
    help_center_id: str | None = None,
) -> list[dict]:
    """
    List help center collections (article categories / folders shown to
    customers in the help center).

    Useful for AUDITING — comparing the workspace's help center information
    architecture against playbook recommendations.

    help_center_id: optional filter to a specific help center.
    """
    client = get_client(workspace)
    params = {}
    if help_center_id:
        params["help_center_id"] = help_center_id
    return paginate(client, "/help_center/collections", params or None)


def get_help_center_collection(workspace: str, collection_id: str) -> dict:
    """Retrieve a single help center collection by ID."""
    client = get_client(workspace)
    return client.get(f"/help_center/collections/{collection_id}")


def create_help_center_collection(
    workspace: str,
    name: str,
    help_center_id: int,
    description: str | None = None,
    parent_id: str | None = None,
    translated_content: dict | None = None,
) -> dict:
    """
    Create a help center collection (article category visible to customers).

    Used during IMPLEMENTATION to seed the help center information
    architecture. Depends on:
      - help_center_id: an existing help center (use list_help_centers).
      - parent_id (optional): a parent collection id (use
        list_help_center_collections) when creating sub-sections.

    name: collection name.
    help_center_id: ID of the help center this collection belongs to.
    description: optional description.
    parent_id: ID of a parent collection to nest under (for sub-sections).
    translated_content: dict of locale → {name, description} translations.
    """
    client = get_client(workspace)
    payload = strip_nulls({
        "name": name,
        "help_center_id": help_center_id,
        "description": description,
        "parent_id": parent_id,
        "translated_content": translated_content,
    })
    return client.post("/help_center/collections", payload)


def update_help_center_collection(
    workspace: str,
    collection_id: str,
    name: str | None = None,
    description: str | None = None,
    parent_id: str | None = None,
    translated_content: dict | None = None,
) -> dict:
    """
    Update an existing help center collection. Sends a partial payload —
    omitted fields are unchanged.
    """
    client = get_client(workspace)
    payload = strip_nulls({
        "name": name,
        "description": description,
        "parent_id": parent_id,
        "translated_content": translated_content,
    })
    return client.put(f"/help_center/collections/{collection_id}", payload)


def delete_help_center_collection(workspace: str, collection_id: str) -> dict:
    """
    PERMANENTLY delete a help center collection by ID. Cannot be undone.
    Articles inside the collection are NOT deleted but lose their parent
    assignment.
    """
    client = get_client(workspace)
    return client.delete(f"/help_center/collections/{collection_id}")
