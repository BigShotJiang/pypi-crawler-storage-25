from forge.mcp.shared import get_client, paginate, strip_nulls


def list_news_items(workspace: str) -> list[dict]:
    """
    List ALL news items in the workspace, regardless of newsfeed assignment.

    Useful for AUDITING — comparing the workspace's customer-facing
    announcements against playbook recommendations for the industry. (Use
    list_newsfeed_items if you only want items currently shown on a specific
    newsfeed.)
    """
    client = get_client(workspace)
    return paginate(client, "/news/news_items")


def get_news_item(workspace: str, news_item_id: str) -> dict:
    """Retrieve a single news item by ID, including full body content."""
    client = get_client(workspace)
    return client.get(f"/news/news_items/{news_item_id}")


def create_news_item(
    workspace: str,
    title: str,
    sender_id: int,
    body: str | None = None,
    state: str = "draft",
    labels: list[str] | None = None,
    reactions: list[str] | None = None,
    deliver_silently: bool = False,
    newsfeed_assignments: list[dict] | None = None,
) -> dict:
    """
    Create a news item.

    Used during IMPLEMENTATION to seed customer announcements. Depends on:
      - sender_id: an admin id (use list_admins).
      - newsfeed_assignments (optional): newsfeed ids (use list_newsfeeds).

    title: headline of the news item.
    sender_id: ID of the admin sending this item.
    body: HTML body content.
    state: 'draft' (default) or 'live'.
    labels: list of label strings.
    reactions: list of emoji reaction strings to allow.
    deliver_silently: if True, do not send a notification.
    newsfeed_assignments: list of {newsfeed_id, published_at} dicts.
    """
    client = get_client(workspace)
    payload = strip_nulls({
        "title": title,
        "sender_id": sender_id,
        "body": body,
        "state": state,
        "deliver_silently": deliver_silently,
        "labels": labels,
        "reactions": reactions,
        "newsfeed_assignments": newsfeed_assignments,
    })
    return client.post("/news/news_items", payload)


def update_news_item(
    workspace: str,
    news_item_id: str,
    title: str | None = None,
    sender_id: int | None = None,
    body: str | None = None,
    state: str | None = None,
    labels: list[str] | None = None,
    reactions: list[str] | None = None,
    deliver_silently: bool | None = None,
    newsfeed_assignments: list[dict] | None = None,
) -> dict:
    """
    Update an existing news item. Sends a partial payload — omitted fields
    are unchanged.
    """
    client = get_client(workspace)
    payload = strip_nulls({
        "title": title,
        "sender_id": sender_id,
        "body": body,
        "state": state,
        "deliver_silently": deliver_silently,
        "labels": labels,
        "reactions": reactions,
        "newsfeed_assignments": newsfeed_assignments,
    })
    return client.put(f"/news/news_items/{news_item_id}", payload)


def delete_news_item(workspace: str, news_item_id: str) -> dict:
    """PERMANENTLY delete a news item by ID. Cannot be undone."""
    client = get_client(workspace)
    return client.delete(f"/news/news_items/{news_item_id}")


def list_newsfeeds(workspace: str) -> list[dict]:
    """
    List all newsfeeds in the workspace.

    Useful for AUDITING — confirming the workspace has the expected newsfeeds
    set up for the industry / channel mix.

    LIMITATION: newsfeeds are read-only via API. Creation requires the
    Intercom UI.
    """
    client = get_client(workspace)
    data = client.get("/news/newsfeeds")
    return data.get("data", [])


def get_newsfeed(workspace: str, newsfeed_id: str) -> dict:
    """Retrieve a single newsfeed by ID."""
    client = get_client(workspace)
    return client.get(f"/news/newsfeeds/{newsfeed_id}")


def list_newsfeed_items(workspace: str, newsfeed_id: str) -> list[dict]:
    """
    List the news items currently assigned to ONE specific newsfeed (its live
    contents). To list every news item workspace-wide regardless of newsfeed
    assignment, use list_news_items instead.
    """
    client = get_client(workspace)
    data = client.get(f"/news/newsfeeds/{newsfeed_id}/items")
    return data.get("data", [])
