from forge.mcp.shared import get_client


def list_brands(workspace: str) -> list[dict]:
    """
    List all brands in the workspace. Returns id, name, default flag, and
    associated configuration for each.

    Useful for AUDITING — confirming the workspace has the expected brands
    set up (per playbook recommendations or client engagement scope).

    LIMITATION: brands are read-only via API. Creating, renaming, or deleting
    brands must happen through the Intercom UI.
    """
    client = get_client(workspace)
    data = client.get("/brands")
    return data.get("data", [])


def get_brand(workspace: str, brand_id: str) -> dict:
    """Retrieve a single brand by ID, including its full configuration."""
    client = get_client(workspace)
    return client.get(f"/brands/{brand_id}")
