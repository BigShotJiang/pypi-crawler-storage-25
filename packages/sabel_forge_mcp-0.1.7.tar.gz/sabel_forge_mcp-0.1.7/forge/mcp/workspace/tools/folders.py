from forge.mcp.shared import get_client, paginate, strip_nulls


def list_internal_article_folders(workspace: str) -> list[dict]:
    """
    List all internal article folders in the workspace (the folders that
    organise agent-facing internal_articles, NOT help center collections).

    Useful for AUDITING — confirming the workspace's internal knowledge base
    is organised according to playbook standards.
    """
    client = get_client(workspace)
    return paginate(client, "/folders")


def get_internal_article_folder(workspace: str, folder_id: str) -> dict:
    """Retrieve a single internal article folder by ID."""
    client = get_client(workspace)
    return client.get(f"/folders/{folder_id}")


def create_internal_article_folder(
    workspace: str,
    name: str,
    description: str | None = None,
    emoji: str | None = None,
    parent_folder_id: int | None = None,
) -> dict:
    """
    Create an internal article folder.

    Used during IMPLEMENTATION — set up the folder hierarchy before creating
    internal articles inside them. Depends on:
      - parent_folder_id (optional): another internal article folder id (use
        list_internal_article_folders).

    name: folder name.
    description: optional description.
    emoji: optional emoji icon.
    parent_folder_id: ID of a parent folder to nest this under.
    """
    client = get_client(workspace)
    folder = strip_nulls({
        "name": name,
        "description": description,
        "emoji": emoji,
        "parent_folder_id": parent_folder_id,
    })
    return client.post("/folders", {"folder": folder})


def update_internal_article_folder(
    workspace: str,
    folder_id: str,
    name: str | None = None,
    description: str | None = None,
    emoji: str | None = None,
    parent_folder_id: int | None = None,
) -> dict:
    """
    Update an existing internal article folder. Sends a partial payload —
    omitted fields are unchanged.
    """
    client = get_client(workspace)
    folder = strip_nulls({
        "name": name,
        "description": description,
        "emoji": emoji,
        "parent_folder_id": parent_folder_id,
    })
    return client.put(f"/folders/{folder_id}", {"folder": folder})


def delete_internal_article_folder(workspace: str, folder_id: str) -> dict:
    """
    PERMANENTLY delete an internal article folder by ID. Cannot be undone.
    Articles inside the folder are NOT deleted but become unparented.
    """
    client = get_client(workspace)
    return client.delete(f"/folders/{folder_id}")
