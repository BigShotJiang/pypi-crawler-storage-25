from forge.mcp.shared import get_client, paginate


def list_macros(workspace: str) -> list[dict]:
    """
    List all macros (saved replies) in the workspace. Returns name, actions,
    and creation metadata for each.

    Useful for AUDITING — comparing the workspace's macro library against
    playbook recommendations for the industry (which canned replies typically
    exist for, say, gambling vs. ecommerce).

    LIMITATION: macros are read-only via API. Bulk creation requires either
    the Intercom UI or the Playwright UI script in
    forge/ui_automation/macros.py.
    """
    client = get_client(workspace)
    return paginate(client, "/macros")


def get_macro(workspace: str, macro_id: str) -> dict:
    """Retrieve a single macro by ID, including all its actions."""
    client = get_client(workspace)
    return client.get(f"/macros/{macro_id}")
