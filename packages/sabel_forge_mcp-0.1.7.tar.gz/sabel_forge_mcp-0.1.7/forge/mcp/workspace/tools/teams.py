from forge.mcp.shared import get_client


def list_teams(workspace: str) -> list[dict]:
    """
    List all teams (inboxes) in the workspace. Returns id, name, and admin_ids
    (membership) for each team.

    Useful for AUDITING — comparing the workspace's team structure against
    playbook recommendations (typical inbox layout for the industry) or
    building source→target ID maps for routing-rule implementation.

    LIMITATION: teams are read-only via API. Creation, renaming, membership
    changes, and routing configuration all happen through the Intercom UI.
    """
    client = get_client(workspace)
    data = client.get("/teams")
    return data.get("teams", [])


def get_team(workspace: str, team_id: str) -> dict:
    """Retrieve a single team by ID, including its admin members."""
    client = get_client(workspace)
    return client.get(f"/teams/{team_id}")


def get_team_metrics(workspace: str, team_id: str) -> dict:
    """
    Retrieve operational metrics for a team (open conversations, wait times,
    handle times).

    NOTE: this hits an undocumented endpoint and may return empty data on
    workspaces without the Reporting add-on. Treat the response as best-effort.
    """
    client = get_client(workspace)
    return client.get(f"/teams/{team_id}/metrics")
