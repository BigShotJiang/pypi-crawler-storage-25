from forge.mcp.shared import get_client, paginate, strip_nulls


def list_internal_articles(workspace: str) -> list[dict]:
    """
    List all internal (agent-facing) knowledge base articles.

    Useful for AUDITING — comparing the workspace's internal knowledge base
    against playbook recommendations (e.g. expected agent runbooks for an
    industry).

    For large knowledge bases this can return many results — prefer
    snapshot_workspace for bulk enumeration without inspecting bodies.
    """
    client = get_client(workspace)
    return paginate(client, "/internal_articles")


def get_internal_article(workspace: str, article_id: str) -> dict:
    """Retrieve a single internal article by ID, including full body content."""
    client = get_client(workspace)
    return client.get(f"/internal_articles/{article_id}")


def search_internal_articles(workspace: str, query: str) -> list[dict]:
    """
    Search internal articles by keyword.

    Returns a flat list of matching article objects (highlight metadata is not
    surfaced here; call the search endpoint directly if you need it).
    """
    client = get_client(workspace)
    data = client.get("/internal_articles/search", params={"phrase": query})
    return data.get("articles", {}).get("articles", data.get("data", []))


def create_internal_article(
    workspace: str,
    title: str,
    author_id: int,
    owner_id: int,
    body: str | None = None,
    folder_id: int | None = None,
) -> dict:
    """
    Create an internal (agent-facing) knowledge base article.

    Used during IMPLEMENTATION to seed agent runbooks. Depends on:
      - author_id and owner_id: admin ids (use list_admins to discover).
      - folder_id (optional): an internal article folder id (use
        list_internal_article_folders).

    title: article title.
    author_id: ID of the admin who wrote this article.
    owner_id: ID of the admin responsible for keeping it up to date.
    body: HTML body content.
    folder_id: ID of the folder to place this article in.
    """
    client = get_client(workspace)
    payload = strip_nulls({
        "title": title,
        "author_id": author_id,
        "owner_id": owner_id,
        "body": body,
        "folder_id": folder_id,
    })
    return client.post("/internal_articles", payload)


def update_internal_article(
    workspace: str,
    article_id: str,
    title: str | None = None,
    author_id: int | None = None,
    owner_id: int | None = None,
    body: str | None = None,
    folder_id: int | None = None,
) -> dict:
    """
    Update an existing internal article. Sends a partial payload — omitted
    fields are unchanged.
    """
    client = get_client(workspace)
    payload = strip_nulls({
        "title": title,
        "author_id": author_id,
        "owner_id": owner_id,
        "body": body,
        "folder_id": folder_id,
    })
    return client.put(f"/internal_articles/{article_id}", payload)


def delete_internal_article(workspace: str, article_id: str) -> dict:
    """PERMANENTLY delete an internal article by ID. Cannot be undone."""
    client = get_client(workspace)
    return client.delete(f"/internal_articles/{article_id}")
