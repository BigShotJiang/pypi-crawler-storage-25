from forge.mcp.shared import get_client, strip_nulls


def list_data_attributes(
    workspace: str,
    model: str | None = None,
    include_archived: bool = False,
) -> list[dict]:
    """
    List custom data attributes for contacts, companies, or conversations.

    Useful for AUDITING — comparing the workspace's custom attributes to
    playbook standards (which attributes an industry typically tracks) or to
    other workspaces in the same industry.

    model: filter by 'contact', 'company', or 'conversation'. Returns all models
        if omitted.
    include_archived: include archived attributes (default False).
    """
    client = get_client(workspace)
    params: dict = {"include_archived": str(include_archived).lower()}
    if model:
        params["model"] = model
    data = client.get("/data_attributes", params=params)
    return data.get("data", [])


def create_data_attribute(
    workspace: str,
    name: str,
    model: str,
    description: str | None = None,
    messenger_writable: bool | None = None,
) -> dict:
    """
    Create a custom data attribute.

    Used during IMPLEMENTATION — provisioning a workspace from scratch using
    playbooks/<industry>.md. No prerequisites. Note that conversation
    attributes cannot be created here; use create_ticket_type_attribute on a
    ticket type instead.

    name: the attribute name (must be unique within the model). Cannot be
        changed after creation.
    model: 'contact' or 'company'. Cannot be changed after creation.
    description: optional human-readable description.
    messenger_writable: whether the attribute can be set via the Messenger SDK.
    """
    client = get_client(workspace)
    payload = strip_nulls({
        "name": name,
        "model": model,
        "description": description,
        "messenger_writable": messenger_writable,
    })
    return client.post("/data_attributes", payload)


def update_data_attribute(
    workspace: str,
    attribute_id: str,
    archived: bool | None = None,
    description: str | None = None,
    messenger_writable: bool | None = None,
) -> dict:
    """
    Update a custom data attribute. Sends a partial payload — omitted fields
    are unchanged.

    LIMITATIONS:
      - `name` and `model` are IMMUTABLE once created. To rename, archive the
        old attribute (archived=True) and create a new one with the desired
        name via create_data_attribute.
      - There is NO delete endpoint. Setting archived=True is the only way to
        retire an attribute; it stays in workspace history.

    attribute_id: the ID of the attribute to update.
    archived: True to archive (soft-retire), False to unarchive.
    description: updated description.
    messenger_writable: updated Messenger SDK writability.
    """
    client = get_client(workspace)
    payload = strip_nulls({
        "archived": archived,
        "description": description,
        "messenger_writable": messenger_writable,
    })
    return client.put(f"/data_attributes/{attribute_id}", payload)
