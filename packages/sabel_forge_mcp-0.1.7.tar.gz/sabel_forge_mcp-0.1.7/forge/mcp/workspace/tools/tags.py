from forge.mcp.shared import get_client


def list_tags(workspace: str) -> list[dict]:
    """
    List all tags in the workspace. Returns id and name for each.

    Useful for AUDITING — comparing the workspace's tag taxonomy against
    playbook recommendations or against patterns observed in other workspaces
    in the same industry.
    """
    client = get_client(workspace)
    data = client.get("/tags")
    return data.get("data", [])


def create_tag(workspace: str, name: str) -> dict:
    """
    Create a new tag by name.

    Used during IMPLEMENTATION when provisioning a workspace's tag taxonomy
    from a playbook. No prerequisites.

    If a tag with this exact name already exists, Intercom returns it
    unchanged (no error, no duplicate). Use update_tag to RENAME an existing
    tag by its ID.
    """
    client = get_client(workspace)
    return client.post("/tags", {"name": name})


def update_tag(workspace: str, tag_id: str, name: str) -> dict:
    """
    Rename an existing tag by ID.

    Use this (not create_tag) when you specifically want to change the name of
    a tag whose ID you already know. To create a brand-new tag, use create_tag.
    """
    client = get_client(workspace)
    return client.post("/tags", {"id": tag_id, "name": name})


def delete_tag(workspace: str, tag_id: str) -> dict:
    """
    PERMANENTLY delete a tag by ID. Cannot be undone. The tag is removed from
    every contact, conversation, company, and segment it was applied to.
    """
    client = get_client(workspace)
    return client.delete(f"/tags/{tag_id}")
