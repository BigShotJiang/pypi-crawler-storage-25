"""Snapshot every listable Intercom resource for a workspace to JSON.

Fans out across all `list_*` endpoints exposed by `forge-workspace` and the
listable Fin endpoints from `forge-fin` (data connectors, content import
sources, external pages), and writes one `<resource>.json` per type plus
`_index.json` (counts, errors, scan metadata) and `_summary.json` (a slim
digest with bodies/HTML stripped) to `<workspace_dir>/config/`.

Resource-level failures are caught and recorded in `_index.json["errors"]`
so a partial snapshot is always written. Re-running overwrites prior files.

This covers the REST-exposed config surface only. Pair with
`snapshot_fin_resources` for the Fin SDK side (procedures, workflows, guidance,
audiences, simulations) — those aren't listable via REST.
"""
from __future__ import annotations

import json
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Callable

from forge.workspace_config import (
    get_intercom_token,
    list_workspaces,
    load_workspace,
    workspace_dir,
)
from forge.mcp.workspace.tools import (
    admins,
    articles,
    away_status_reasons,
    brands,
    data_attributes,
    folders,
    help_center,
    internal_articles,
    macros,
    news,
    segments,
    subscription_types,
    tags,
    teams,
    ticket_types,
)
from forge.mcp.fin.tools import ai_content, data_connectors


# (output filename without extension, callable(workspace) -> list[dict])
_LIST_TASKS: list[tuple[str, Callable[[str], list[dict]]]] = [
    ("admins", admins.list_admins),
    ("teams", teams.list_teams),
    ("brands", brands.list_brands),
    ("away_status_reasons", away_status_reasons.list_away_status_reasons),
    ("subscription_types", subscription_types.list_subscription_types),
    ("tags", tags.list_tags),
    ("segments", segments.list_segments),
    ("internal_article_folders", folders.list_internal_article_folders),
    ("data_attributes", data_attributes.list_data_attributes),
    ("ticket_types", ticket_types.list_ticket_types),
    ("ticket_states", ticket_types.list_ticket_states),
    ("help_centers", help_center.list_help_centers),
    ("collections", help_center.list_help_center_collections),
    ("articles", articles.list_articles),
    ("internal_articles", internal_articles.list_internal_articles),
    ("macros", macros.list_macros),
    ("news_items", news.list_news_items),
    ("newsfeeds", news.list_newsfeeds),
    ("data_connectors", data_connectors.list_data_connectors),
    ("content_import_sources", ai_content.list_content_import_sources),
    ("external_pages", ai_content.list_external_pages),
]

# Keys whose values are large bodies (HTML, markdown) and add no signal for
# cross-workspace pattern analysis. Dropped from `_summary.json`.
_SUMMARY_DROP_KEYS = frozenset({"body", "body_text", "html", "content"})

# Long string values are still useful as evidence; truncate rather than drop.
_SUMMARY_STR_LIMIT = 200


def _summarize(value: Any) -> Any:
    """Recursively trim a resource for the cross-workspace digest."""
    if isinstance(value, str):
        if len(value) > _SUMMARY_STR_LIMIT:
            head = value[:_SUMMARY_STR_LIMIT - 30].rstrip()
            return f"{head}…<truncated, {len(value)} chars total>"
        return value
    if isinstance(value, list):
        return [_summarize(v) for v in value]
    if isinstance(value, dict):
        return {
            k: _summarize(v)
            for k, v in value.items()
            if k not in _SUMMARY_DROP_KEYS
        }
    return value


def snapshot_workspace(
    workspace: str,
    output_dir: str | None = None,
) -> dict:
    """Capture a full point-in-time inventory of a workspace's REST-exposed
    configuration to disk.

    THIS IS THE STANDARD FIRST STEP FOR AUDITING a client workspace against
    playbook standards or comparing it to other workspaces in the same
    industry. Pair with snapshot_fin_resources to also capture procedures,
    workflows, guidance, audiences, and simulations (which aren't listable
    via REST).

    Fans out across every list_* endpoint (admins, teams, tags, articles,
    ticket types, data attributes, segments, help centers, news, data
    connectors, AI content sources, external pages — 20+ resource types).
    For each, writes the resulting array as `<output_dir>/<resource>.json`.
    Also writes:
      - `_index.json`  — scan timestamp, counts, errors, forge.json metadata
      - `_summary.json` — single-file digest of every resource with bodies
        stripped and long strings truncated, suitable for cross-workspace
        pattern analysis without blowing up context

    Resource-level failures don't abort the run — the error is recorded in
    `_index.json["errors"]` and the next resource is attempted. Re-running
    overwrites prior files.

    workspace:  workspace folder name (under workspace/<Name>/ or
                workspace/<Industry>/<Name>/).
    output_dir: where to write files. Defaults to <workspace_dir>/config/.

    Returns the index dict.
    """
    # Fail fast on missing/misconfigured token rather than recording the same
    # error against every single resource.
    get_intercom_token(workspace)
    workspace_config = load_workspace(workspace)
    ws_path = workspace_dir(workspace)

    if output_dir:
        out_root = Path(output_dir).expanduser().resolve()
    else:
        out_root = ws_path / "config"
    out_root.mkdir(parents=True, exist_ok=True)

    counts: dict[str, int] = {}
    errors: dict[str, str] = {}
    summary_resources: dict[str, list] = {}

    for name, func in _LIST_TASKS:
        try:
            result = func(workspace)
        except Exception as e:
            errors[name] = f"{type(e).__name__}: {e}"
            continue
        if not isinstance(result, list):
            errors[name] = (
                f"unexpected return type {type(result).__name__}; expected list"
            )
            continue
        (out_root / f"{name}.json").write_text(
            json.dumps(result, indent=2, ensure_ascii=False) + "\n"
        )
        counts[name] = len(result)
        summary_resources[name] = [_summarize(item) for item in result]

    scanned_at = datetime.now(timezone.utc).isoformat(timespec="seconds")
    industry = next(
        (w.get("industry") for w in list_workspaces() if w.get("folder") == workspace),
        None,
    )

    index = {
        "scanned_at": scanned_at,
        "workspace": workspace,
        "industry": industry,
        "output_dir": str(out_root),
        "forge_config": workspace_config,
        "counts": counts,
        "errors": errors,
        "files": {name: f"{name}.json" for name, _ in _LIST_TASKS if name in counts},
        "related": {
            "fin_sdk_resources": (
                "Use snapshot_fin_resources for procedures, workflows, "
                "guidance, audiences, attributes, and simulations — these "
                "are not listable via REST."
            ),
        },
    }
    (out_root / "_index.json").write_text(
        json.dumps(index, indent=2, ensure_ascii=False) + "\n"
    )

    summary = {
        "scanned_at": scanned_at,
        "workspace": workspace,
        "industry": industry,
        "counts": counts,
        "errors": errors,
        "resources": summary_resources,
    }
    (out_root / "_summary.json").write_text(
        json.dumps(summary, indent=2, ensure_ascii=False) + "\n"
    )

    return index


def snapshot_all_workspaces(industry: str | None = None) -> dict:
    """Snapshot every configured workspace, optionally filtered by industry.

    Use this to AUDIT an entire industry portfolio at once — e.g. snapshot
    every gambling workspace before comparing their tag taxonomies, ticket
    types, or macro libraries to find the patterns that should inform
    playbooks/<industry>.md.

    Calls `snapshot_workspace` for each workspace whose token env var is
    currently set. Workspaces with missing tokens are skipped (recorded as
    `skipped`) rather than failing the whole batch.

    industry: if set (e.g. 'gambling', 'ecommerce'), only snapshots
              workspaces under workspace/<industry>/. If omitted, snapshots
              every configured workspace regardless of layout.

    Returns {workspace_folder_name: report} where report contains either
    counts/errors/output_dir on success, `skipped` for missing tokens, or
    `failed` if `snapshot_workspace` itself raised.
    """
    workspaces = list_workspaces()
    if industry is not None:
        workspaces = [w for w in workspaces if w.get("industry") == industry]

    reports: dict[str, dict] = {}
    for w in workspaces:
        name = w["folder"]
        if not w.get("intercom_token_present"):
            reports[name] = {
                "industry": w.get("industry"),
                "skipped": f"env var '{w.get('intercom_token_env')}' not set",
            }
            continue
        try:
            result = snapshot_workspace(name)
        except Exception as e:
            reports[name] = {
                "industry": w.get("industry"),
                "failed": f"{type(e).__name__}: {e}",
            }
            continue
        reports[name] = {
            "industry": w.get("industry"),
            "counts": result["counts"],
            "errors": result["errors"],
            "output_dir": result["output_dir"],
        }
    return reports
