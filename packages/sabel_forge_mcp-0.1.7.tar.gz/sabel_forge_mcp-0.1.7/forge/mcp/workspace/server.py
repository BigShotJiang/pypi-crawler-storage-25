"""
forge-workspace MCP server
==========================
Exposes Intercom workspace configuration tools to an AI agent.

Multi-tenant: every tool requires a `workspace` argument that names a folder
under `workspace/<name>/` containing a `forge.json` config. The server reads
each workspace's Intercom access token from an environment variable named
in that config, so a single server process can serve any number of
workspaces without restart.

Run with:
  forge-workspace

Workspace tokens must be exported in the shell environment (e.g. via
`~/.secrets`). See CLAUDE.md for the setup flow.
"""

from mcp.server.fastmcp import FastMCP

from forge.mcp.workspaces_tool import list_workspaces
from forge.mcp.workspace.tools import (
    admins,
    articles,
    away_status_reasons,
    brands,
    data_attributes,
    folders,
    help_center,
    internal_articles,
    macros,
    news,
    playbooks,
    segments,
    snapshot,
    subscription_types,
    tags,
    teams,
    ticket_types,
    ui_create,
)

INSTRUCTIONS = """\
This server exposes Intercom workspace configuration tools across multiple
client workspaces. Tools fall into two product surfaces:

  - AUDITING (read-only): list_*, get_*, search_*, snapshot_workspace,
    snapshot_all_workspaces. Use these to compare a workspace's current state
    to playbook standards (fetch via list_playbooks + get_playbook) or to
    other workspaces in the same industry.

  - PLAYBOOKS: list_playbooks + get_playbook are the authoritative source
    for industry implementation standards (gambling, ecommerce, fintech, ...).
    BEFORE provisioning a new workspace in a known vertical, call
    get_playbook(industry) and ground your plan in it — don't improvise.

  - PROVISIONING PROTOCOL: when the user asks to set up / implement /
    configure a workspace (especially a new one), the FIRST thing to do
    — before any clarifying questions — is ask whether they have any
    project intake documents we should ingest. Examples to name explicitly:

      • Statement of work (SOW) or scope of work
      • Kickoff document, project brief, or onboarding pack
      • Discovery call notes / requirements summary
      • Existing Intercom workspace export from a prior tool
      • An RFP or proposal the partner submitted to win the engagement

    Reason: experienced partners almost always have one of these on hand,
    and they pre-answer 60-90% of the playbook clarifying questions. Asking
    those questions one-by-one without first ingesting the docs is a common
    workflow waste that experienced partners find frustrating.

    If the user provides documents, read them with the Read tool, extract
    answers to playbook questions, and surface ONLY the remaining unknowns
    + flag anything ambiguous between docs.

    If the user has no documents, proceed with playbook-driven Q&A as
    before — but ask in batches grouped by playbook section, not one
    question at a time.

  - IMPLEMENTATION (write): create_*, update_*, delete_*. Use these to
    provision a workspace from scratch following an industry playbook.
    Order matters — many resources depend on others (e.g. articles need a
    collection; ticket attributes need a ticket type).

Every tool except `list_workspaces` requires a `workspace` argument
identifying which workspace to act on. When the user requests an action
that needs Intercom access but does not specify a workspace, call
`list_workspaces` first and ask the user which one to use. Workspace names
match the folder names under `workspace/`. Never invent a workspace name —
only use names returned by `list_workspaces`.

If the user asks you to add, register, configure, or operate on a workspace
that does NOT appear in `list_workspaces`, the workspace must be created
through the `forge` CLI on their machine — there is no MCP tool for this.
Walk them through it explicitly. The full procedure is:

  1. Pick an env var name for their Intercom token, e.g. CLIENT_ACME_TOKEN.
     The convention is the workspace name in upper snake case + "_TOKEN".

  2. Add the token to ~/.secrets so it survives shell restarts:
        echo 'export CLIENT_ACME_TOKEN="dG9rOi..."' >> ~/.secrets
        source ~/.secrets
     The token comes from Intercom: Settings → Developers →
     Authentication → "New access token" (admin-scoped).

  3. Register the workspace with forge:
        forge workspace add Client_Acme --token-env CLIENT_ACME_TOKEN \
          [--industry gaming|ecommerce|fintech|...] \
          [--admin-id 12345] [--default-brand-id 67890] \
          [--notes "..."]
     The folder name (Client_Acme) is what they'll pass as the `workspace`
     argument to MCP tools, so pick a name that reads well.

  4. Verify the token works:
        forge workspace test Client_Acme
     This calls Intercom /me — if it returns the workspace name and admin,
     the token is valid and the license is active.

  5. RESTART Claude Code. The MCP server reads the workspaces directory
     once at startup; new workspaces aren't picked up until restart.

After step 5, `list_workspaces` will include the new workspace and you
can act on it. Until then, do NOT try to "fake" the workspace, edit
files for them, or call Intercom tools with the unregistered name —
those will all fail and confuse the user.

If they want to remove or rename a workspace later, point them at
`forge workspace remove <name>` or `forge workspace update <name> ...`
respectively. The full CLI reference is `forge workspace --help`.

Several Intercom resources are read-only via API (brands, teams, segments,
subscription types, away status reasons, macros, ticket states, admins
except set_admin_away). The list_* tools for those will work; for the ones
the user actually needs to CREATE there are companion `create_*_via_ui`
tools that drive the Intercom admin UI through Playwright:

  - create_away_status_reasons_via_ui
  - create_brands_via_ui
  - create_conversation_attributes_via_ui  (REST POST refuses model=conversation)
  - create_macros_via_ui
  - create_newsfeeds_via_ui
  - create_subscription_types_via_ui
  - create_teams_via_ui
  - create_ticket_states_via_ui

These open a Chromium window on the user's machine. First run requires
interactive login; cookies persist per-workspace. They take minutes per
resource — only reach for them when the user explicitly wants UI-driven
creation. The existing list_*/get_* REST tools remain the right choice
for AUDIT work.

Note on conversation attributes specifically: this tool creates plain
data attributes scoped to conversations (flat option strings). For
Fin-Studio reasoning attributes — same conversations namespace but with
per-option descriptions Fin uses to pick a value — use the separate
`create_fin_attributes_from_csv` tool on the forge-fin server.
"""

mcp = FastMCP("forge-workspace", instructions=INSTRUCTIONS)

# ── Workspace discovery ───────────────────────────────────────────────────────
mcp.tool()(list_workspaces)

# ── Admins (read-only except away-mode toggle) ───────────────────────────────
mcp.tool()(admins.list_admins)
mcp.tool()(admins.get_admin)
mcp.tool()(admins.set_admin_away)

# ── Brands (read-only) ────────────────────────────────────────────────────────
mcp.tool()(brands.list_brands)
mcp.tool()(brands.get_brand)

# ── Away Status Reasons (read-only) ──────────────────────────────────────────
mcp.tool()(away_status_reasons.list_away_status_reasons)

# ── Subscription Types (read-only) ───────────────────────────────────────────
mcp.tool()(subscription_types.list_subscription_types)

# ── Teams (read-only) ────────────────────────────────────────────────────────
mcp.tool()(teams.list_teams)
mcp.tool()(teams.get_team)
mcp.tool()(teams.get_team_metrics)

# ── Tags ─────────────────────────────────────────────────────────────────────
mcp.tool()(tags.list_tags)
mcp.tool()(tags.create_tag)
mcp.tool()(tags.update_tag)
mcp.tool()(tags.delete_tag)

# ── Segments (read-only) ─────────────────────────────────────────────────────
mcp.tool()(segments.list_segments)
mcp.tool()(segments.get_segment)

# ── Internal Article Folders ─────────────────────────────────────────────────
mcp.tool()(folders.list_internal_article_folders)
mcp.tool()(folders.get_internal_article_folder)
mcp.tool()(folders.create_internal_article_folder)
mcp.tool()(folders.update_internal_article_folder)
mcp.tool()(folders.delete_internal_article_folder)

# ── Data Attributes (no DELETE — archive via update) ─────────────────────────
mcp.tool()(data_attributes.list_data_attributes)
mcp.tool()(data_attributes.create_data_attribute)
mcp.tool()(data_attributes.update_data_attribute)

# ── Ticket Types & Attributes (no DELETE — archive via update) ───────────────
mcp.tool()(ticket_types.list_ticket_types)
mcp.tool()(ticket_types.get_ticket_type)
mcp.tool()(ticket_types.create_ticket_type)
mcp.tool()(ticket_types.update_ticket_type)
mcp.tool()(ticket_types.list_ticket_states)
mcp.tool()(ticket_types.create_ticket_type_attribute)
mcp.tool()(ticket_types.update_ticket_type_attribute)

# ── Help Center ───────────────────────────────────────────────────────────────
mcp.tool()(help_center.list_help_centers)
mcp.tool()(help_center.get_help_center)
mcp.tool()(help_center.list_help_center_collections)
mcp.tool()(help_center.get_help_center_collection)
mcp.tool()(help_center.create_help_center_collection)
mcp.tool()(help_center.update_help_center_collection)
mcp.tool()(help_center.delete_help_center_collection)

# ── Articles ──────────────────────────────────────────────────────────────────
mcp.tool()(articles.list_articles)
mcp.tool()(articles.get_article)
mcp.tool()(articles.search_articles)
mcp.tool()(articles.create_article)
mcp.tool()(articles.update_article)
mcp.tool()(articles.delete_article)

# ── Internal Articles ─────────────────────────────────────────────────────────
mcp.tool()(internal_articles.list_internal_articles)
mcp.tool()(internal_articles.get_internal_article)
mcp.tool()(internal_articles.search_internal_articles)
mcp.tool()(internal_articles.create_internal_article)
mcp.tool()(internal_articles.update_internal_article)
mcp.tool()(internal_articles.delete_internal_article)

# ── Macros (read-only) ────────────────────────────────────────────────────────
mcp.tool()(macros.list_macros)
mcp.tool()(macros.get_macro)

# ── News ──────────────────────────────────────────────────────────────────────
mcp.tool()(news.list_news_items)
mcp.tool()(news.get_news_item)
mcp.tool()(news.create_news_item)
mcp.tool()(news.update_news_item)
mcp.tool()(news.delete_news_item)
mcp.tool()(news.list_newsfeeds)
mcp.tool()(news.get_newsfeed)
mcp.tool()(news.list_newsfeed_items)

# ── Industry playbooks (license-gated, fetched from forge-api) ───────────────
mcp.tool()(playbooks.list_playbooks)
mcp.tool()(playbooks.get_playbook)

# ── Workspace snapshot (audit foundation) ────────────────────────────────────
mcp.tool()(snapshot.snapshot_workspace)
mcp.tool()(snapshot.snapshot_all_workspaces)

# ── UI-only creation (Playwright; opens a Chromium window) ───────────────────
mcp.tool()(ui_create.create_away_status_reasons_via_ui)
mcp.tool()(ui_create.create_brands_via_ui)
mcp.tool()(ui_create.create_conversation_attributes_via_ui)
mcp.tool()(ui_create.create_macros_via_ui)
mcp.tool()(ui_create.create_newsfeeds_via_ui)
mcp.tool()(ui_create.create_subscription_types_via_ui)
mcp.tool()(ui_create.create_teams_via_ui)
mcp.tool()(ui_create.create_ticket_states_via_ui)


def main():
    import sys
    from forge import license as lic

    try:
        lic.gate_startup()
    except lic.LicenseError as e:
        print(f"[forge-workspace] {e}", file=sys.stderr)
        sys.exit(1)

    mcp.run()


if __name__ == "__main__":
    main()
