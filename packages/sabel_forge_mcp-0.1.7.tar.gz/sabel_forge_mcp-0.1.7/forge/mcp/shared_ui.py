"""Shared helper for MCP tools that wrap Playwright UI-automation scripts.

The UI-automation scripts under `forge/ui_automation/` open a real
Chromium window on the user's machine and drive the Intercom admin UI
through it. They are the only path to create/update resources Intercom
does NOT expose via REST or the Fin SDK CLI.

Wrapping them as MCP tools means an agent can request the action by
name and the user — sitting at the same machine — sees a browser pop up
and the script clicks through. Cookies persist on disk per-workspace
so login is one-time per machine. First run will block while the user
authenticates interactively (up to 10 minutes, configured in
session.py).

Differences from REST-backed MCP tools:
  * Side effect — opens a visible Chromium window. The user must allow it.
  * Long-running — minutes per resource, not seconds. The default
    `timeout_s=3600` lets bulk runs (~50 items) complete; cap higher if
    you're driving more.
  * Stdout is the contract — the wrapper returns it verbatim plus an
    exit code. The script's own stdout is already structured (CREATE /
    SKIP / SUMMARY blocks) so the agent can read it directly.
"""
from __future__ import annotations

import os
import subprocess
import sys
from pathlib import Path

from forge.workspace_config import workspace_dir


def _resolve_workspace_path(workspace: str, raw: str) -> Path:
    """Absolute paths used as-is; relative paths resolve against the
    workspace directory (workspace/<Name>/ or workspace/<Industry>/<Name>/).
    Mirrors how `procedures.upload_procedure` resolves --file paths."""
    p = Path(raw).expanduser()
    if not p.is_absolute():
        p = workspace_dir(workspace) / p
    return p.resolve()


def run_ui_script(
    workspace: str,
    module: str,
    *,
    mode: str,
    payload_path: str | None = None,
    csv_dir: str | None = None,
    extra_args: list[str] | None = None,
    timeout_s: int = 3600,
) -> dict:
    """Run a Playwright UI-automation script as a subprocess.

    workspace:     forge workspace folder name (validates token presence
                   indirectly — every UI script calls resolve_app_id which
                   reads forge.json + the env var).
    module:        Python module path of the script, e.g. "forge.ui_automation.fin_attributes".
    mode:          One of "--probe", "--probe-create-form", "--dry-run",
                   "--create", "--update". Pass exactly as the script
                   accepts; this helper just forwards it.
    payload_path:  YAML file (most scripts), resolved against workspace_dir
                   if relative. Mutually exclusive with csv_dir.
    csv_dir:       Directory of CSVs (fin_attributes only), resolved
                   against workspace_dir if relative.
    extra_args:    Pass-through tail args (e.g. ["--connector-id", "147006"]).
    timeout_s:     Hard cap on the subprocess. Default 1h.

    Returns: {
        "command": list[str] of argv passed to subprocess,
        "exit_code": int,
        "stdout": str (full),
        "stderr": str (full),
    }
    Does NOT raise on non-zero exit — the caller (or the agent) decides
    what to do based on exit_code + stdout content. This matches the
    shell-style ergonomics agents expect.
    """
    args = [sys.executable, "-m", module, "--workspace", workspace, mode]
    if payload_path is not None:
        args += ["--payload", str(_resolve_workspace_path(workspace, payload_path))]
    if csv_dir is not None:
        resolved = _resolve_workspace_path(workspace, csv_dir)
        if not resolved.is_dir():
            raise RuntimeError(f"csv_dir not found or not a directory: {resolved}")
        args += ["--csv-dir", str(resolved)]
    if extra_args:
        args += list(extra_args)

    env = {**os.environ, "PYTHONUNBUFFERED": "1"}
    result = subprocess.run(
        args,
        capture_output=True,
        text=True,
        timeout=timeout_s,
        env=env,
    )
    return {
        "command": args,
        "exit_code": result.returncode,
        "stdout": result.stdout,
        "stderr": result.stderr,
    }
