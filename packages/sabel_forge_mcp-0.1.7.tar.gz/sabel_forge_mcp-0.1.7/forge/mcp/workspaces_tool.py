"""MCP tool for discovering configured workspaces.

Both `forge-workspace` and `forge-fin` register `list_workspaces` so an agent
can ask the user which workspace to operate on before calling any other tool.
"""
from forge.workspace_config import list_workspaces as _list_workspaces


def list_workspaces() -> list[dict]:
    """
    PREREQUISITE for every other Forge tool: those tools take a `workspace`
    argument that must match a folder name returned here.

    Returns one entry per configured workspace with non-secret metadata
    (folder name, industry tag if applicable, admin_id, default_brand_id,
    notes) plus 'intercom_token_present' indicating whether the workspace's
    token env var is currently set in the shell.

    Tokens themselves are NEVER returned by this tool.

    Call this first whenever the user asks for an action that needs Intercom
    access but hasn't named a workspace, and ask them to pick one before
    proceeding. Never invent a workspace name — only use names returned here.
    """
    return _list_workspaces()
