"""Shared utilities for forge MCP servers."""
from urllib.parse import parse_qs, urlparse

from forge.client.intercom import IntercomClient, IntercomError
from forge.workspace_config import get_intercom_token


def get_client(workspace: str) -> IntercomClient:
    """Build an IntercomClient for a specific workspace.

    The workspace name must match a folder under `workspace/<name>/` with a
    `forge.json` config. The token is resolved from the env var named in
    that config — it is never read from the file directly.
    """
    if not workspace:
        raise ValueError(
            "Every Intercom tool requires a 'workspace' argument. "
            "Call list_workspaces to see available options."
        )
    token = get_intercom_token(workspace)
    return IntercomClient(token)


def _next_starting_after(next_page) -> str | None:
    """Extract the `starting_after` cursor from a pages.next field.

    Intercom returns pages.next inconsistently: some endpoints (e.g. /tags)
    omit it when there are no more pages, some return a structured object
    `{"page": 2, "starting_after": "..."}`, and some (notably /articles and
    /help_center/collections) return the next URL as a plain string with the
    cursor in the query.
    """
    if not next_page:
        return None
    if isinstance(next_page, dict):
        return next_page.get("starting_after")
    if isinstance(next_page, str):
        cursors = parse_qs(urlparse(next_page).query).get("starting_after", [])
        return cursors[0] if cursors else None
    return None


def paginate(client: IntercomClient, path: str, params: dict | None = None, max_results: int = 500) -> list[dict]:
    """Fetch all pages from a cursor-paginated list endpoint."""
    results = []
    p = dict(params or {})
    p.setdefault("per_page", 50)

    while True:
        data = client.get(path, params=p)
        items = data.get("data", [])
        results.extend(items)
        if len(results) >= max_results:
            break
        cursor = _next_starting_after(data.get("pages", {}).get("next"))
        if not cursor:
            break
        p["starting_after"] = cursor

    return results[:max_results]


def strip_nulls(d: dict) -> dict:
    """Remove keys with None values from a dict (for cleaner API payloads)."""
    return {k: v for k, v in d.items() if v is not None}
