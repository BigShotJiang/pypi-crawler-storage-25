"""
Update Intercom Fin data connectors via the admin UI.

Intercom's REST API has no PUT/PATCH for data connectors — only POST
(create) and DELETE. This script fills the gap by driving the UI's
edit page so you can change a connector's fields in-place without
losing its ID (which would break workflow / Fin references).

Phase 1: update existing connector + activate/deactivate.
Phase 2 (future): run test execution and capture response.
Phase 3 (future): set response field mappings.

Usage:
    # Probe to find the edit-page URL pattern + selectors:
    uv run python -m forge.ui_automation.data_connectors \\
        --workspace Migr8now_Workspace --probe --connector-id 147006

YAML schema (will be finalized after probe):
    updates:
      - connector_id: "147006"
        description: "New description text"
        # Future fields: url, body, headers, data_inputs, auth_credential_name,
        # direct_fin_usage, audiences, state ('live'/'draft')
"""
from __future__ import annotations

import argparse
import asyncio
import time
from pathlib import Path

import yaml

from forge.ui_automation.session import (
    ensure_logged_in,
    intercom_session,
    resolve_app_id,
    screenshot,
)

# Data connectors are surfaced in the UI as "Custom Actions".
INDEX_PATH = "/settings/app-settings/custom-actions"
EDIT_PATH_CANDIDATES = [
    "/settings/app-settings/custom-actions/{id}",
    "/settings/app-settings/custom-actions/{id}/edit",
]


async def find_edit_page(page, workspace: str, connector_id: str) -> str:
    """Navigate to a connector's edit page. Tries direct deep-links first,
    falls back to opening the index and clicking the connector by id."""
    app_id = resolve_app_id(workspace)
    for pattern in EDIT_PATH_CANDIDATES:
        path = pattern.format(id=connector_id)
        url = f"https://app.intercom.com/a/apps/{app_id}{path}"
        print(f"[dc] trying {url}")
        await page.goto(url, wait_until="domcontentloaded")
        try:
            await page.wait_for_load_state("networkidle", timeout=6_000)
        except Exception:
            pass
        await page.wait_for_timeout(500)
        if connector_id in page.url and "custom-actions" in page.url:
            return path
    # Fallback: open the index, then click the row matching this id.
    index_url = f"https://app.intercom.com/a/apps/{app_id}{INDEX_PATH}"
    print(f"[dc] deep-links failed; opening index {index_url} and looking for connector")
    await page.goto(index_url, wait_until="domcontentloaded")
    try:
        await page.wait_for_load_state("networkidle", timeout=8_000)
    except Exception:
        pass
    await page.wait_for_timeout(800)
    return INDEX_PATH


async def probe_edit_page(page) -> dict:
    info: dict = {"url": page.url, "page_title": await page.title()}

    # Scroll the whole page so lazy-rendered content mounts.
    try:
        await page.evaluate("window.scrollTo(0, document.body.scrollHeight)")
        await page.wait_for_timeout(800)
        await page.evaluate("window.scrollTo(0, 0)")
        await page.wait_for_timeout(500)
    except Exception:
        pass

    try:
        headings = await page.locator("h1, h2, h3, h4, [role='heading']").all_inner_texts()
        info["headings"] = [h.strip() for h in headings if h.strip()][:50]
    except Exception as e:
        info["headings_error"] = str(e)

    # All form-like elements: inputs, textareas, contenteditable divs.
    try:
        inputs = page.locator("input, textarea, [contenteditable='true']")
        cnt = await inputs.count()
        info["input_count"] = cnt
        samples = []
        for i in range(min(cnt, 40)):
            el = inputs.nth(i)
            try:
                tag = await el.evaluate("el => el.tagName")
                value = None
                if tag in ("INPUT", "TEXTAREA"):
                    try:
                        value = (await el.input_value())[:80]
                    except Exception:
                        value = None
                else:
                    # contenteditable div: use innerText
                    try:
                        value = (await el.inner_text())[:80]
                    except Exception:
                        value = None
                samples.append({
                    "index": i,
                    "tag": tag,
                    "type": await el.get_attribute("type"),
                    "placeholder": await el.get_attribute("placeholder"),
                    "aria-label": await el.get_attribute("aria-label"),
                    "value": value,
                })
            except Exception as e:
                samples.append({"index": i, "error": str(e)})
        info["input_samples"] = samples
    except Exception as e:
        info["input_error"] = str(e)

    try:
        all_buttons = await page.get_by_role("button").all_inner_texts()
        info["visible_buttons"] = [b.strip() for b in all_buttons if b.strip()][:120]
    except Exception as e:
        info["visible_buttons_error"] = str(e)

    return info


async def run_probe(workspace: str, connector_id: str):
    async with intercom_session(workspace, headed=True) as ctx:
        page = await ensure_logged_in(ctx, workspace)
        await find_edit_page(page, workspace, connector_id)
        info = await probe_edit_page(page)
        shot = await screenshot(page, f"dc-edit-{workspace}-{connector_id}")

        print("\n=== DATA CONNECTOR EDIT-PAGE PROBE ===")
        print(f"URL:        {info['url']}")
        print(f"Page title: {info['page_title']}")
        print(f"Screenshot: {shot}")
        print("\nHeadings:")
        for h in info.get("headings", []):
            print(f"  - {h!r}")
        print(f"\nInput count: {info.get('input_count')}")
        for s in info.get("input_samples", []):
            print(f"  - {s}")
        print(f"\nButtons visible (first 80):")
        for b in info.get("visible_buttons", []):
            print(f"  - {b!r}")


# ────────────────────────────────────────────────────────────────────
# Phase 1: update existing connectors
# ────────────────────────────────────────────────────────────────────

NAME_INPUT = 'input[placeholder="Untitled"]'
DESC_TEXTAREA = 'textarea[placeholder="Enter"]'
# The HTTPS URL field is a contenteditable div, not a real <input>.
URL_CONTENTEDITABLE = '[contenteditable="true"]'
ALLOWED_HTTP_METHODS = {"get", "post", "put", "delete", "patch"}
ALLOWED_STATES = {"live", "draft"}
ALLOWED_INPUT_TYPES = {"string", "integer", "decimal", "boolean"}
# Map yaml type → format-dropdown label shown in the data-input modal
INPUT_TYPE_LABELS = {
    "string": "Text",
    "integer": "Integer",
    "decimal": "Decimal",
    "boolean": "Boolean",
}
SUPPORTED_FIELDS = {
    "name", "description", "url", "http_method",
    "state", "auth_credential", "headers", "data_inputs",
}


def load_payload(path: Path) -> list[dict]:
    data = yaml.safe_load(path.read_text())
    items = data.get("updates") if isinstance(data, dict) else None
    if not isinstance(items, list):
        raise SystemExit(f"YAML at {path} must have a top-level 'updates:' list")
    for i, u in enumerate(items):
        if not isinstance(u, dict) or "connector_id" not in u:
            raise SystemExit(f"updates[{i}] missing required 'connector_id'")
        unknown = set(u.keys()) - {"connector_id"} - SUPPORTED_FIELDS
        if unknown:
            raise SystemExit(
                f"updates[{i}] has unsupported fields: {unknown}. "
                f"Currently supported: {SUPPORTED_FIELDS}. "
                f"Other fields (state, headers, data_inputs, auth_credential) "
                f"coming in later phases."
            )
        if not (set(u.keys()) & SUPPORTED_FIELDS):
            raise SystemExit(
                f"updates[{i}] specifies no fields to update; provide at least "
                f"one of {SUPPORTED_FIELDS}"
            )
        if "http_method" in u:
            method = str(u["http_method"]).lower()
            if method not in ALLOWED_HTTP_METHODS:
                raise SystemExit(
                    f"updates[{i}].http_method must be one of {ALLOWED_HTTP_METHODS}"
                )
            u["http_method"] = method
        if "state" in u:
            state = str(u["state"]).lower()
            if state not in ALLOWED_STATES:
                raise SystemExit(
                    f"updates[{i}].state must be one of {ALLOWED_STATES}"
                )
            u["state"] = state
        if "headers" in u:
            if not isinstance(u["headers"], list):
                raise SystemExit(f"updates[{i}].headers must be a list of {{key, value}}")
            for h in u["headers"]:
                if not isinstance(h, dict) or "key" not in h or "value" not in h:
                    raise SystemExit(f"updates[{i}].headers entries must have 'key' and 'value'")
        if "data_inputs" in u:
            if not isinstance(u["data_inputs"], list):
                raise SystemExit(f"updates[{i}].data_inputs must be a list")
            for di in u["data_inputs"]:
                if not isinstance(di, dict) or "name" not in di:
                    raise SystemExit(f"updates[{i}].data_inputs entries must have 'name'")
                t = str(di.get("type", "string")).lower()
                if t not in ALLOWED_INPUT_TYPES:
                    raise SystemExit(
                        f"updates[{i}].data_inputs[*].type must be one of {ALLOWED_INPUT_TYPES}"
                    )
                di["type"] = t
    return items


async def _open_edit_page(page, workspace: str, connector_id: str):
    """Navigate to the edit page for a connector. Waits for the form to mount."""
    app_id = resolve_app_id(workspace)
    url = f"https://app.intercom.com/a/apps/{app_id}{INDEX_PATH}/{connector_id}"
    print(f"[dc] opening {url}")
    await page.goto(url, wait_until="domcontentloaded")
    try:
        await page.wait_for_load_state("networkidle", timeout=10_000)
    except Exception:
        pass
    # Title input being visible is the form-mounted signal.
    await page.locator(NAME_INPUT).wait_for(state="visible", timeout=15_000)
    await page.wait_for_timeout(500)


async def _commit_field(page, locator, value: str, label: str):
    """Fill a real input/textarea and verify via re-read."""
    await locator.wait_for(state="visible", timeout=10_000)
    for attempt in range(3):
        await locator.click(click_count=3)
        await page.wait_for_timeout(150)
        await locator.fill(value)
        await page.keyboard.press("Tab")
        await page.wait_for_timeout(500)
        actual = await locator.input_value()
        if actual == value:
            return
        print(f"  [dc] {label} commit attempt {attempt + 1} mismatch (got {actual!r})")
    raise RuntimeError(f"Could not set {label} to expected value after 3 attempts")


async def _commit_contenteditable(page, locator, value: str, label: str):
    """Fill a contenteditable div by selecting all + typing."""
    await locator.wait_for(state="visible", timeout=10_000)
    for attempt in range(3):
        await locator.click()
        await page.wait_for_timeout(100)
        # Select existing content + delete
        await page.keyboard.press("Meta+A")    # macOS selectAll
        await page.keyboard.press("Backspace")
        await page.wait_for_timeout(100)
        await page.keyboard.type(value)
        await page.keyboard.press("Tab")
        await page.wait_for_timeout(500)
        actual = (await locator.inner_text()).strip()
        if actual == value:
            return
        print(f"  [dc] {label} commit attempt {attempt + 1} mismatch (got {actual!r})")
    raise RuntimeError(f"Could not set {label} contenteditable to expected value after 3 attempts")


async def _set_auth_credential(page, credential_name: str):
    """Open the Authentication tokens dropdown and select a pre-configured
    credential by name. The credential must already exist in the workspace
    (added manually under Settings → Authentication).

    KNOWN BROKEN — PARKED. Intercom's auth credential dropdown is rendered
    inside a Web Component / shadow DOM that rejects every Playwright click
    strategy attempted (regular click, force=True, dispatch_event,
    page.mouse.click on bounding-box coords, search-input filter +
    ArrowDown/Enter). The popover opens visually but the option-click
    fails with "<html> intercepts pointer events" no matter the approach.
    Auth credential currently has to be set manually in the UI after a
    create/update."""
    section = page.get_by_text("Authentication tokens", exact=True).first
    await section.scroll_into_view_if_needed()
    await page.wait_for_timeout(300)

    # The dropdown trigger is a button just below the heading, currently
    # showing the active credential name (e.g. "Linelender"). Find it via
    # Playwright locator pattern: the section card contains a button whose
    # text doesn't match other known buttons. We use a positional approach:
    # find the button right after the "Authentication tokens" heading.
    # Strategy: enumerate visible buttons and pick the one closest to the
    # heading by Y position.
    heading_box = await section.bounding_box()
    if not heading_box:
        raise RuntimeError("Could not get bounding box for Authentication tokens heading")
    heading_y = heading_box["y"]

    # Find the dropdown trigger by looking for a button positioned below
    # the heading, within the section card.
    trigger = None
    skip_labels = {
        "Save", "Cancel", "Set live", "Set draft", "Fin preview",
        "Add key and value", "Data input", "Retest", "Mock response",
        "Test live connection", "Learn",
    }
    all_buttons = page.get_by_role("button")
    n = await all_buttons.count()
    best = None
    best_dist = 1e9
    for i in range(n):
        b = all_buttons.nth(i)
        try:
            text = (await b.inner_text()).strip()
            if text in skip_labels:
                continue
            box = await b.bounding_box()
            if not box:
                continue
            # Must be below heading and reasonably close (within 300px)
            dy = box["y"] - heading_y
            if dy < 0 or dy > 300:
                continue
            if dy < best_dist:
                best_dist = dy
                best = b
        except Exception:
            continue
    if best is None:
        raise RuntimeError("Could not find auth-credential dropdown trigger near heading")
    trigger = best
    # Use page.mouse.click with bounding-box center — lowest level, doesn't
    # do hit-testing or actionability checks. Works around Intercom's
    # shadow-DOM dropdown fighting higher-level click APIs.
    box = await trigger.bounding_box()
    if not box:
        raise RuntimeError("Could not get bounding box for auth dropdown trigger")
    await page.mouse.click(box["x"] + box["width"] / 2, box["y"] + box["height"] / 2)
    await page.wait_for_timeout(900)

    # Use exact match on the popover's Search placeholder so we don't pick
    # up the global "Search and navigate..." input.
    try:
        search = page.get_by_placeholder("Search", exact=True).first
        await search.wait_for(state="visible", timeout=5_000)
        await search.fill(credential_name)
        await page.wait_for_timeout(500)
        option = page.get_by_text(credential_name, exact=True).last
        await option.wait_for(state="visible", timeout=4_000)
        opt_box = await option.bounding_box()
        if not opt_box:
            raise RuntimeError("Could not get bounding box for option")
        await page.mouse.click(opt_box["x"] + opt_box["width"] / 2, opt_box["y"] + opt_box["height"] / 2)
        await page.wait_for_timeout(600)
    except Exception as e:
        raise RuntimeError(
            f"Could not select auth credential {credential_name!r}. "
            f"Confirm the credential exists under Settings → Authentication. ({e})"
        )


async def _add_headers(page, headers: list[dict]):
    """Additive: add headers from the payload that aren't already present
    (matched by key, case-insensitive). Each entry: {key: str, value: str}.

    Uses the "Add header" modal that opens when '+ Add key and value' is
    clicked — same modal pattern as data inputs. Existing-row delete is not
    yet implemented; v1 is additive only."""
    section = page.get_by_text("Headers", exact=True).first
    await section.scroll_into_view_if_needed()
    await page.wait_for_timeout(300)

    async def header_exists(key: str) -> bool:
        # Playwright's get_by_text auto-pierces shadow DOM. If the key text
        # appears anywhere within the visible page after the Headers section,
        # we treat it as already present. Case-insensitive HTTP header names
        # mean we check both as-is and capitalised forms.
        for variant in {key, key.lower(), key.title()}:
            loc = page.get_by_text(variant, exact=True)
            try:
                if await loc.count() > 0:
                    return True
            except Exception:
                continue
        return False

    for h in headers:
        if await header_exists(h["key"]):
            print(f"  [dc] header {h['key']!r} already present; skipping")
            continue

        add_btn = page.get_by_role("button", name="Add key and value").first
        await add_btn.scroll_into_view_if_needed()
        await add_btn.click()
        await page.wait_for_timeout(800)

        key_input = page.get_by_label("Key", exact=True).first
        value_input = page.get_by_label("Value", exact=True).first
        await key_input.wait_for(state="visible", timeout=5_000)
        await key_input.fill(h["key"])
        await value_input.fill(h["value"])
        await page.wait_for_timeout(400)

        modal_save = page.get_by_role("button", name="Save").last
        await modal_save.wait_for(state="visible", timeout=5_000)
        # Wait for Save to enable; if it stays disabled, treat as a
        # validation failure (e.g. duplicate) and cancel.
        enabled = False
        for _ in range(15):
            if await modal_save.is_enabled():
                enabled = True
                break
            await page.wait_for_timeout(200)
        if not enabled:
            print(f"  [dc] header {h['key']!r}: Save stayed disabled (validation rejected); cancelling")
            cancel = page.get_by_role("button", name="Cancel").last
            try:
                await cancel.click()
                await page.wait_for_timeout(400)
            except Exception:
                pass
            continue
        await modal_save.click()
        await page.wait_for_timeout(800)


async def _add_data_inputs(page, inputs: list[dict]):
    """Add each data input via the modal. Idempotent: skips inputs whose
    name already exists in the section."""
    for di in inputs:
        section = page.get_by_text("Data inputs", exact=True).first
        await section.scroll_into_view_if_needed()
        await page.wait_for_timeout(300)
        # Existence check via Playwright text locator (auto-pierces shadow DOM).
        # The data_input name might be truncated ("forge_test_..." style) in
        # the table cell; we check both exact and prefix-match by using
        # contains.
        name_present = False
        try:
            if await page.get_by_text(di["name"], exact=True).count() > 0:
                name_present = True
            else:
                # Truncated display: look for first 8 chars + ellipsis-like prefix
                prefix = di["name"][:8]
                if len(di["name"]) > 8 and await page.get_by_text(prefix, exact=False).count() > 0:
                    name_present = True
        except Exception:
            pass
        if name_present:
            print(f"  [dc] data input {di['name']!r} already present; skipping")
            continue

        # Click "+ Data input" to open the modal.
        add_btn = page.get_by_role("button", name="Data input").first
        await add_btn.scroll_into_view_if_needed()
        await add_btn.click()
        await page.wait_for_timeout(800)

        # Modal fields:
        #   Format dropdown (defaults to "Text" = string)
        #   Name input (placeholder "Enter")
        #   Description input (placeholder "Enter")
        #   Fallback value input (placeholder "Enter")
        # The 3 inputs all share placeholder "Enter" — fill by index in
        # the modal, taking the LAST 3 visible Enter-placeholder inputs.
        if di.get("type", "string") != "string":
            # Click format dropdown and pick label
            fmt_label = INPUT_TYPE_LABELS[di["type"]]
            fmt_btn = page.get_by_role("button", name="Text", exact=True).first
            await fmt_btn.click()
            await page.wait_for_timeout(400)
            opt = page.get_by_role("option", name=fmt_label, exact=True).first
            if not await opt.count():
                opt = page.get_by_text(fmt_label, exact=True).last
            await opt.wait_for(state="visible", timeout=4_000)
            await opt.click()
            await page.wait_for_timeout(300)

        # The modal's inputs are in shadow DOM (Intercom Web Components).
        # Use Playwright label locators — they pierce shadow roots.
        await page.get_by_label("Name", exact=True).first.fill(di["name"])
        await page.get_by_label("Description", exact=True).first.fill(di.get("description", ""))
        await page.get_by_label("Fallback value", exact=True).first.fill(di.get("fallback", ""))
        await page.wait_for_timeout(400)

        # Toggle Optional if requested
        if di.get("optional"):
            try:
                toggle = page.get_by_text("Fin can skip this parameter if not needed", exact=False).first
                # Click the switch near it
                await toggle.click()
                await page.wait_for_timeout(200)
            except Exception:
                pass

        modal_save = page.get_by_role("button", name="Save").last
        await modal_save.wait_for(state="visible", timeout=5_000)
        # If Save stays disabled (e.g. duplicate name validation), cancel.
        enabled = False
        for _ in range(15):
            if await modal_save.is_enabled():
                enabled = True
                break
            await page.wait_for_timeout(200)
        if not enabled:
            print(f"  [dc] data input {di['name']!r}: Save stayed disabled; cancelling")
            try:
                await page.get_by_role("button", name="Cancel").last.click()
                await page.wait_for_timeout(400)
            except Exception:
                pass
            continue
        await modal_save.click()
        await page.wait_for_timeout(800)


async def _set_state(page, target_state: str):
    """Click 'Set live' or 'Set draft' to toggle connector state.
    target_state is 'live' or 'draft'."""
    label = "Set live" if target_state == "live" else "Set draft"
    btn = page.get_by_role("button", name=label).first
    if not await btn.count():
        # Already in target state — no toggle button to click.
        print(f"  [dc] no '{label}' button visible; assuming already in {target_state} state")
        return
    await btn.scroll_into_view_if_needed()
    await btn.click()
    await page.wait_for_timeout(800)
    # If a confirmation modal appears, accept it.
    try:
        confirm = page.get_by_role("button", name="Set live").last
        if await confirm.count() and await confirm.is_visible():
            await confirm.click()
            await page.wait_for_timeout(800)
    except Exception:
        pass


async def _set_http_method(page, method: str):
    """Pick an HTTP method from the dropdown. method is lowercase."""
    label = method.upper()
    # The current method is shown as a button (e.g. "GET"). Click whichever
    # method button is currently visible to open the dropdown.
    current_btn = None
    for m in ALLOWED_HTTP_METHODS:
        b = page.get_by_role("button", name=m.upper(), exact=True).first
        try:
            if await b.count() and await b.is_visible():
                current_btn = b
                break
        except Exception:
            continue
    if current_btn is None:
        raise RuntimeError("Could not find current HTTP method dropdown trigger")
    await current_btn.click()
    await page.wait_for_timeout(500)
    # Pick the target method from the popover. Options likely show as
    # role=option or as text.
    target = page.get_by_role("option", name=label, exact=True).first
    if not await target.count():
        target = page.get_by_text(label, exact=True).last
    await target.wait_for(state="visible", timeout=5_000)
    await target.click()
    await page.wait_for_timeout(400)


async def _save_and_wait(page) -> bool:
    save_btn = page.get_by_role("button", name="Save").first
    await save_btn.wait_for(state="visible", timeout=10_000)
    # Save is disabled until there are unsaved changes — wait briefly for it
    # to enable.
    for _ in range(20):
        if await save_btn.is_enabled():
            break
        await page.wait_for_timeout(250)
    if not await save_btn.is_enabled():
        return False
    await save_btn.click()
    try:
        await page.wait_for_load_state("networkidle", timeout=10_000)
    except Exception:
        pass
    await page.wait_for_timeout(1500)
    return True


async def update_one_connector(page, workspace: str, item: dict) -> dict:
    cid = str(item["connector_id"])
    fields_changed = {k: item[k] for k in SUPPORTED_FIELDS if k in item}
    result = {"connector_id": cid, "fields_changed": list(fields_changed.keys()), "status": "unknown"}

    try:
        await _open_edit_page(page, workspace, cid)
    except Exception as e:
        shot = await screenshot(page, f"dc-open-fail-{cid}-{int(time.time())}")
        result["status"] = "error"
        result["error"] = f"open edit page failed: {e}"
        result["screenshot"] = str(shot)
        return result

    try:
        if "name" in fields_changed:
            await _commit_field(page, page.locator(NAME_INPUT), fields_changed["name"], "name")
        if "description" in fields_changed:
            await _commit_field(page, page.locator(DESC_TEXTAREA), fields_changed["description"], "description")
        if "url" in fields_changed:
            await _commit_contenteditable(
                page, page.locator(URL_CONTENTEDITABLE).first, fields_changed["url"], "url"
            )
        if "http_method" in fields_changed:
            await _set_http_method(page, fields_changed["http_method"])
        if "auth_credential" in fields_changed:
            raise RuntimeError(
                "auth_credential is known-broken — Intercom's shadow-DOM "
                "dropdown rejects all Playwright click strategies. Set the "
                "credential manually in the UI for now."
            )
        if "headers" in fields_changed:
            await _add_headers(page, fields_changed["headers"])
        if "data_inputs" in fields_changed:
            await _add_data_inputs(page, fields_changed["data_inputs"])
    except Exception as e:
        shot = await screenshot(page, f"dc-fill-fail-{cid}-{int(time.time())}")
        result["status"] = "error"
        result["error"] = f"field fill failed: {e}"
        result["screenshot"] = str(shot)
        return result

    # Save is only meaningful if there are changes other than state.
    non_state_changes = {k: v for k, v in fields_changed.items() if k != "state"}
    if non_state_changes:
        saved = await _save_and_wait(page)
        if not saved:
            # If Save never enabled, the most likely reason is everything
            # was idempotent (skipped) — not a real failure. Detect by
            # checking the Save button state vs. throwing.
            print(f"  [dc] Save button never enabled — assuming all changes were idempotent skips")

    # State toggle is applied after Save (it acts on persisted state).
    if "state" in fields_changed:
        try:
            await _set_state(page, fields_changed["state"])
        except Exception as e:
            shot = await screenshot(page, f"dc-state-fail-{cid}-{int(time.time())}")
            result["status"] = "error"
            result["error"] = f"state toggle failed: {e}"
            result["screenshot"] = str(shot)
            return result

    # Verify by re-reading after save.
    try:
        for fname, fval in fields_changed.items():
            if fname == "name":
                actual = await page.locator(NAME_INPUT).input_value()
            elif fname == "description":
                actual = await page.locator(DESC_TEXTAREA).input_value()
            elif fname == "url":
                actual = (await page.locator(URL_CONTENTEDITABLE).first.inner_text()).strip()
            elif fname == "http_method":
                # Find the visible method button (one of GET/POST/PUT/DELETE/PATCH).
                actual = None
                for m in ALLOWED_HTTP_METHODS:
                    b = page.get_by_role("button", name=m.upper(), exact=True).first
                    if await b.count() and await b.is_visible():
                        actual = m
                        break
            else:
                continue
            if actual != fval:
                shot = await screenshot(page, f"dc-verify-fail-{cid}-{int(time.time())}")
                result["status"] = "failed"
                result["error"] = f"{fname} did not persist (got {actual!r}, want {fval!r})"
                result["screenshot"] = str(shot)
                return result
    except Exception as e:
        result["status"] = "error"
        result["error"] = f"verify read failed: {e}"
        return result

    result["status"] = "updated"
    return result


async def run_dry_run(workspace: str, payload_path: Path):
    items = load_payload(payload_path)
    print(f"[dry-run] {len(items)} updates in payload")
    for u in items:
        fields = {k: u[k] for k in SUPPORTED_FIELDS if k in u}
        print(f"  [UPDATE] connector {u['connector_id']}  fields={list(fields.keys())}")


async def run_update(workspace: str, payload_path: Path):
    items = load_payload(payload_path)
    print(f"[update] {len(items)} connector updates in payload")
    summary = {"updated": 0, "failed": 0, "error": 0, "details": []}

    async with intercom_session(workspace, headed=True) as ctx:
        page = await ensure_logged_in(ctx, workspace)
        for i, u in enumerate(items, 1):
            print(f"\n[update] [{i}/{len(items)}] connector {u['connector_id']}")
            try:
                result = await update_one_connector(page, workspace, u)
            except Exception as e:
                shot = await screenshot(page, f"dc-uncaught-{int(time.time())}")
                result = {
                    "connector_id": str(u["connector_id"]),
                    "status": "error",
                    "error": f"uncaught: {e}",
                    "screenshot": str(shot),
                }
            print(f"           → {result['status']}")
            if result.get("error"):
                print(f"           error: {result['error']}")
            if result.get("screenshot"):
                print(f"           screenshot: {result['screenshot']}")
            summary[result["status"]] = summary.get(result["status"], 0) + 1
            summary["details"].append(result)

    print("\n=== SUMMARY ===")
    print(f"  updated: {summary['updated']}")
    print(f"  failed:  {summary['failed']}")
    print(f"  error:   {summary['error']}")


def main():
    ap = argparse.ArgumentParser(description="Manage Intercom data connectors via the admin UI.")
    ap.add_argument("--workspace", required=True, help="Workspace folder name under workspace/")
    mode = ap.add_mutually_exclusive_group(required=True)
    mode.add_argument("--probe", action="store_true", help="Probe a connector's edit page.")
    mode.add_argument("--dry-run", action="store_true", help="Parse payload and print which connectors would be updated.")
    mode.add_argument("--update", action="store_true", help="Apply updates from --payload (Phase 1: name, description).")
    ap.add_argument("--connector-id", help="Connector ID for --probe (use list_data_connectors to discover).")
    ap.add_argument("--payload", type=Path, help="YAML file with connector updates")
    args = ap.parse_args()

    if args.probe:
        if not args.connector_id:
            ap.error("--probe requires --connector-id")
        asyncio.run(run_probe(args.workspace, args.connector_id))
    elif args.dry_run:
        if not args.payload:
            ap.error("--dry-run requires --payload")
        asyncio.run(run_dry_run(args.workspace, args.payload))
    elif args.update:
        if not args.payload:
            ap.error("--update requires --payload")
        asyncio.run(run_update(args.workspace, args.payload))


if __name__ == "__main__":
    main()
