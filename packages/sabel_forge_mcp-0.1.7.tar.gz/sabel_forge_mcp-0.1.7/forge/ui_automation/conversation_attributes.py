"""
Create Intercom conversation custom attributes via the admin UI.

Conversation-scoped custom data attributes (model=conversation in REST
terms) cannot be POST'd through the public REST API — the endpoint
hard-rejects model="conversation" with "must be either contact or
company". The Intercom CLI doesn't expose them either. Playwright is
the only path.

Distinct from Fin attributes (forge/forge/ui_automation/fin_attributes.py):
that tool authors Fin-Studio reasoning attributes with per-option
descriptions Fin uses to pick a value. This tool authors plain
data-attribute fields scoped to conversations — name, description, type,
and (for list types) flat option strings.

Form lives at /settings/data/conversation-tickets.

Input format matches fin_attributes for re-usability of the same CSV
pool. Per-option descriptions in CSVs are ignored here — the REST
schema for these attributes only stores flat option values.

    <csv_dir>/fin_attribute_<Name>.csv
        value1,description1   <- description column ignored for plain
        value2,description2      conversation attrs
        ...

Optional `_manifest.yaml` provides attribute-level metadata:

    attributes:
      Sentiment:
        description: "..."
        data_type: list   # default: 'list' if CSV has rows, else 'string'
        name_override: "..."

Usage:
    # Probe the index page
    uv run python -m forge.ui_automation.conversation_attributes \\
        --workspace Migr8now_Workspace --probe

    # Probe the create form
    uv run python -m forge.ui_automation.conversation_attributes \\
        --workspace Migr8now_Workspace --probe-create-form

    # Dry run
    uv run python -m forge.ui_automation.conversation_attributes \\
        --workspace Migr8now_Workspace --dry-run \\
        --csv-dir /path/to/csvs

    # Create
    uv run python -m forge.ui_automation.conversation_attributes \\
        --workspace Migr8now_Workspace --create \\
        --csv-dir /path/to/csvs
"""
from __future__ import annotations

import argparse
import asyncio
import csv
import time
from dataclasses import dataclass, field
from pathlib import Path

import yaml

from forge.ui_automation.session import (
    ensure_logged_in,
    intercom_session,
    resolve_app_id,
    screenshot,
)

INDEX_PATH = "/settings/data/conversation-tickets"

# Selector candidates for the New / Create button on the index page —
# locked in once probe-create-form runs successfully.
NEW_BUTTON_LABELS = [
    "New attribute",
    "Create attribute",
    "Add attribute",
    "New",
    "Create",
    "Add",
]


# ────────────────────────────────────────────────────────────────────
# Payload model
# ────────────────────────────────────────────────────────────────────


@dataclass
class ConversationAttribute:
    name: str
    options: list[str] = field(default_factory=list)
    description: str = ""
    data_type: str = "string"  # "string" | "list" | "integer" | "float" | "boolean" | "date" | "datetime"
    source_file: str = ""


def _filename_to_attr_name(stem: str, *, keep_underscores: bool) -> str:
    prefix = "fin_attribute_"
    name = stem[len(prefix):] if stem.startswith(prefix) else stem
    return name if keep_underscores else name.replace("_", " ")


def load_csv_dir(csv_dir: Path, *, keep_underscores: bool = False) -> list[ConversationAttribute]:
    if not csv_dir.is_dir():
        raise SystemExit(f"--csv-dir {csv_dir} is not a directory")

    manifest_path = csv_dir / "_manifest.yaml"
    manifest: dict = {}
    if manifest_path.exists():
        loaded = yaml.safe_load(manifest_path.read_text()) or {}
        manifest = (loaded.get("attributes") or {}) if isinstance(loaded, dict) else {}

    attrs: list[ConversationAttribute] = []
    files = sorted(csv_dir.glob("fin_attribute_*.csv"))
    if not files:
        raise SystemExit(f"No fin_attribute_*.csv files found in {csv_dir}")

    for path in files:
        stem = path.stem
        suffix = stem[len("fin_attribute_"):] if stem.startswith("fin_attribute_") else stem
        meta = manifest.get(suffix, {}) if isinstance(manifest, dict) else {}

        name = meta.get("name_override") or _filename_to_attr_name(stem, keep_underscores=keep_underscores)
        description = (meta.get("description") or "").strip()

        opts: list[str] = []
        with path.open(newline="", encoding="utf-8") as fh:
            for row in csv.reader(fh):
                if not row:
                    continue
                value = (row[0] or "").strip()
                if value:
                    opts.append(value)

        # Default type: list if CSV has options and no override, else string.
        data_type = (meta.get("data_type") or ("list" if opts else "string")).strip()

        attrs.append(ConversationAttribute(
            name=name,
            options=opts,
            description=description,
            data_type=data_type,
            source_file=str(path),
        ))
    return attrs


# ────────────────────────────────────────────────────────────────────
# Probe modes
# ────────────────────────────────────────────────────────────────────


async def go_to_index(page, workspace: str):
    app_id = resolve_app_id(workspace)
    url = f"https://app.intercom.com/a/apps/{app_id}{INDEX_PATH}"
    print(f"[conv-attr] navigating to {url}")
    await page.goto(url, wait_until="domcontentloaded")
    try:
        await page.wait_for_load_state("networkidle", timeout=12_000)
    except Exception:
        pass
    await page.wait_for_timeout(800)


async def click_new_button(page) -> str:
    for label in NEW_BUTTON_LABELS:
        loc = page.get_by_role("button", name=label).first
        try:
            if await loc.count() and await loc.is_visible():
                print(f"[conv-attr] clicking {label!r}")
                await loc.click()
                await page.wait_for_timeout(1500)
                try:
                    await page.wait_for_load_state("networkidle", timeout=6_000)
                except Exception:
                    pass
                return label
        except Exception:
            continue
    raise RuntimeError(
        f"Could not find a New/Add/Create button on {page.url}. Tried: {NEW_BUTTON_LABELS}."
    )


async def probe_page(page) -> dict:
    info: dict = {"url": page.url, "page_title": await page.title()}
    try:
        all_buttons = await page.get_by_role("button").all_inner_texts()
        info["visible_buttons"] = [b.strip() for b in all_buttons if b.strip()][:80]
    except Exception as e:
        info["visible_buttons_error"] = str(e)
    try:
        headings = await page.locator("h1, h2, h3, h4, [role='heading']").all_inner_texts()
        info["headings"] = [h.strip() for h in headings if h.strip()][:40]
    except Exception as e:
        info["headings_error"] = str(e)
    try:
        inputs = page.locator("input, textarea, select")
        descriptors = []
        for i in range(min(await inputs.count(), 30)):
            el = inputs.nth(i)
            descriptors.append({
                "tag": await el.evaluate("el => el.tagName"),
                "type": await el.get_attribute("type"),
                "placeholder": await el.get_attribute("placeholder"),
                "aria-label": await el.get_attribute("aria-label"),
                "name": await el.get_attribute("name"),
            })
        info["inputs"] = descriptors
    except Exception as e:
        info["inputs_error"] = str(e)
    return info


async def run_probe(workspace: str):
    async with intercom_session(workspace, headed=True) as ctx:
        page = await ensure_logged_in(ctx, workspace)
        await go_to_index(page, workspace)
        info = await probe_page(page)
        shot = await screenshot(page, f"conv-attr-index-{workspace}")
        _print_probe("CONVERSATION ATTRIBUTES INDEX PROBE", info, shot)


async def run_probe_create_form(workspace: str):
    async with intercom_session(workspace, headed=True) as ctx:
        page = await ensure_logged_in(ctx, workspace)
        await go_to_index(page, workspace)
        label = await click_new_button(page)

        # 1. Default form (Format = Text)
        info = await probe_page(page)
        info["new_button_clicked"] = label
        shot = await screenshot(page, f"conv-attr-create-default-{workspace}")
        _print_probe("CREATE FORM — DEFAULT (Format: Text)", info, shot)

        # 2. Click the Format dropdown ("Text" button) to see type options
        format_btn = page.get_by_role("button", name="Text").first
        try:
            if await format_btn.count() and await format_btn.is_visible():
                print("\n[conv-attr] clicking Format dropdown")
                await format_btn.click()
                await page.wait_for_timeout(800)
                info_dd = await probe_page(page)
                shot_dd = await screenshot(page, f"conv-attr-format-dropdown-{workspace}")
                _print_probe("CREATE FORM — FORMAT DROPDOWN OPEN", info_dd, shot_dd)
        except Exception as e:
            print(f"[conv-attr] format dropdown probe failed: {e}")
            return

        # 3. Click "List" — try several role variants since the dropdown
        # may use option/menuitem/listitem or just generic divs.
        candidates = [
            ("option(name=List)", page.get_by_role("option", name="List").first),
            ("menuitem(name=List)", page.get_by_role("menuitem", name="List").first),
            ("listitem(name=List)", page.get_by_role("listitem", name="List").first),
            ("text=List exact (last)", page.get_by_text("List", exact=True).last),
        ]
        clicked = None
        for label, loc in candidates:
            try:
                if await loc.count() and await loc.is_visible():
                    print(f"\n[conv-attr] clicking via {label}")
                    await loc.click()
                    await page.wait_for_timeout(1200)
                    clicked = label
                    break
            except Exception:
                continue
        if not clicked:
            print("\n[conv-attr] could not locate List option in the Format dropdown")
            return
        info_l = await probe_page(page)
        info_l["format_chosen"] = "List"
        info_l["matcher_that_worked"] = clicked
        shot_l = await screenshot(page, f"conv-attr-format-list-{workspace}")
        _print_probe("CREATE FORM — FORMAT=List", info_l, shot_l)


def _print_probe(title: str, info: dict, shot: Path):
    print(f"\n=== {title} ===")
    print(f"URL:        {info['url']}")
    print(f"Screenshot: {shot}")
    print("\nHeadings:")
    for h in info.get("headings", []):
        print(f"  - {h!r}")
    print("\nVisible buttons (first 80):")
    for b in info.get("visible_buttons", []):
        print(f"  - {b!r}")
    if info.get("inputs"):
        print("\nInputs (tag, type, placeholder, aria-label, name):")
        for inp in info["inputs"]:
            print(f"  - {inp}")
    if info.get("new_button_clicked"):
        print(f"\nNew-button label that worked: {info['new_button_clicked']!r}")


# ────────────────────────────────────────────────────────────────────
# Existence + Create — TODO after probe
# ────────────────────────────────────────────────────────────────────


async def attr_exists(page, name: str) -> bool:
    """Match attribute name in any element except <th> column headers
    (mirrors the fin_attributes attr_exists strategy)."""
    try:
        elements = page.get_by_text(name, exact=True)
        count = await elements.count()
        for i in range(count):
            try:
                tag = await elements.nth(i).evaluate("el => el.tagName")
                if tag and tag.upper() != "TH":
                    return True
            except Exception:
                continue
        return False
    except Exception:
        return False


async def create_one_attribute(page, attr: ConversationAttribute, workspace: str) -> dict:
    """Create a single conversation attribute. Index must be loaded.

    Form structure (probed against Migr8now):
      - "Create attribute" button opens a slide-out panel.
      - General tab has: Format dropdown (button labelled "Text" by
        default), Name input (placeholder "e.g. Type"), Description
        textarea (placeholder "e.g. Type of conversation"), Limit
        visibility toggle, Required attribute toggle.
      - For Format = List: "Let Fin detect this attribute" callout
        appears at top, plus a "List options" section with inline
        option inputs (placeholder "e.g. Apples or 1-10"), an "Add"
        button and an "Upload" button (CSV upload via hidden file
        input). We use CSV upload — same pattern as fin_attributes —
        for parity and to avoid one-input-per-option DOM thrash.
      - Save commits and the panel closes.
    """
    result: dict = {"name": attr.name, "status": "unknown"}
    if await attr_exists(page, attr.name):
        return {**result, "status": "skipped"}

    # 1. Open the create panel.
    try:
        await click_new_button(page)
    except Exception as e:
        shot = await screenshot(page, f"conv-attr-new-fail-{int(time.time())}")
        return {**result, "status": "error", "error": f"new-button: {e}", "screenshot": str(shot)}

    # 2. If list type, switch Format to List BEFORE filling name —
    # changing format may rerender the form.
    if attr.data_type == "list":
        try:
            fmt = page.get_by_role("button", name="Text").first
            await fmt.wait_for(state="visible", timeout=8_000)
            await fmt.click()
            await page.wait_for_timeout(600)
            # Dropdown items aren't menuitem/option roles — match by
            # exact text within the open dropdown.
            list_opt = page.get_by_text("List", exact=True).last
            await list_opt.click()
            await page.wait_for_timeout(800)
        except Exception as e:
            shot = await screenshot(page, f"conv-attr-format-list-fail-{int(time.time())}")
            return {**result, "status": "error", "error": f"format=list: {e}", "screenshot": str(shot)}

    # 3. Fill Name (the only text input with placeholder "e.g. Type").
    try:
        name_input = page.locator('input[placeholder="e.g. Type"]').first
        await name_input.wait_for(state="visible", timeout=10_000)
        await name_input.fill(attr.name)
    except Exception as e:
        shot = await screenshot(page, f"conv-attr-name-fail-{int(time.time())}")
        return {**result, "status": "error", "error": f"name fill: {e}", "screenshot": str(shot)}

    # 4. Description (textarea with placeholder "e.g. Type of conversation").
    if attr.description:
        try:
            desc = page.locator('textarea[placeholder="e.g. Type of conversation"]').first
            await desc.fill(attr.description)
        except Exception:
            pass  # description is optional on this form

    # 5. For list type, fill inline option inputs (CSV upload is a click-
    # triggered native picker, not a hidden file input we can drive).
    if attr.data_type == "list" and attr.options:
        try:
            await _fill_options_inline(page, attr.options)
        except Exception as e:
            shot = await screenshot(page, f"conv-attr-options-fail-{int(time.time())}")
            return {**result, "status": "error", "error": f"options fill: {e}", "screenshot": str(shot)}

    # 6. Save.
    try:
        save_btn = page.get_by_role("button", name="Save").first
        await save_btn.wait_for(state="visible", timeout=8_000)
        if not await save_btn.is_enabled():
            shot = await screenshot(page, f"conv-attr-save-disabled-{int(time.time())}")
            return {**result, "status": "error",
                    "error": "Save disabled — required field missing",
                    "screenshot": str(shot)}
        await save_btn.click()
        await page.wait_for_timeout(1500)
    except Exception as e:
        shot = await screenshot(page, f"conv-attr-save-fail-{int(time.time())}")
        return {**result, "status": "error", "error": f"save: {e}", "screenshot": str(shot)}

    # 7. Verify on index.
    if not page.url.rstrip("/").endswith(INDEX_PATH):
        await go_to_index(page, workspace)
    if await attr_exists(page, attr.name):
        return {**result, "status": "created"}
    shot = await screenshot(page, f"conv-attr-verify-fail-{int(time.time())}")
    return {**result, "status": "failed",
            "error": "saved but did not appear on index",
            "screenshot": str(shot)}


async def _fill_options_inline(page, options: list[str]):
    """Fill list-attribute options into the inline rows.

    The form starts with 2 empty option inputs (placeholder
    "e.g. Apples or 1-10"). Clicking "Add" mounts another empty row.
    Strategy: fill all currently-visible empty rows, then click Add and
    repeat until every option has been entered.

    Per-option descriptions from the source CSV are intentionally
    dropped — Intercom's plain conversation list attributes only store
    flat option strings. (For Fin-reasoning attributes that DO use
    per-option descriptions, use forge.ui_automation.fin_attributes
    instead.)
    """
    placeholder = 'e.g. Apples or 1-10'
    selector = f'input[placeholder="{placeholder}"]'
    add_btn = page.get_by_role("button", name="Add").first

    remaining = list(options)
    while remaining:
        inputs = page.locator(selector)
        n = await inputs.count()
        # Find empty inputs (already-filled ones are kept).
        for i in range(n):
            inp = inputs.nth(i)
            try:
                if not await inp.is_visible():
                    continue
                value = await inp.input_value()
                if value:
                    continue
                if not remaining:
                    break
                next_value = remaining.pop(0)
                await inp.fill(next_value)
            except Exception:
                continue
        if not remaining:
            return
        # Need another row — click Add and re-scan.
        try:
            await add_btn.click()
            await page.wait_for_timeout(200)
        except Exception:
            # Fall back: if Add fails, give up rather than loop forever.
            raise RuntimeError(
                f"Add button failed; {len(remaining)} options not entered: {remaining[:3]}..."
            )


# ────────────────────────────────────────────────────────────────────
# Driver modes
# ────────────────────────────────────────────────────────────────────


async def run_dry_run(workspace: str, csv_dir: Path, keep_underscores: bool):
    attrs = load_csv_dir(csv_dir, keep_underscores=keep_underscores)
    print(f"\n[dry-run] {len(attrs)} attributes parsed from {csv_dir}")
    async with intercom_session(workspace, headed=True) as ctx:
        page = await ensure_logged_in(ctx, workspace)
        await go_to_index(page, workspace)
        for a in attrs:
            exists = await attr_exists(page, a.name)
            verb = "SKIP (exists)" if exists else "CREATE"
            print(f"  [{verb}] {a.name!r}  type={a.data_type}  options={len(a.options)}  source={Path(a.source_file).name}")
            if a.description:
                print(f"           description: {a.description[:80]!r}")


async def run_create(workspace: str, csv_dir: Path, keep_underscores: bool):
    attrs = load_csv_dir(csv_dir, keep_underscores=keep_underscores)
    print(f"[create] {len(attrs)} attributes parsed from {csv_dir}")
    summary = {"created": 0, "skipped": 0, "failed": 0, "error": 0, "details": []}
    async with intercom_session(workspace, headed=True) as ctx:
        page = await ensure_logged_in(ctx, workspace)
        await go_to_index(page, workspace)
        for i, a in enumerate(attrs, 1):
            print(f"\n[create] [{i}/{len(attrs)}] {a.name!r}  type={a.data_type}  ({len(a.options)} options)")
            try:
                result = await create_one_attribute(page, a, workspace)
            except Exception as e:
                shot = await screenshot(page, f"conv-attr-uncaught-{int(time.time())}")
                result = {"name": a.name, "status": "error",
                          "error": f"uncaught: {e}", "screenshot": str(shot)}
            print(f"           → {result['status']}")
            if result.get("error"):
                print(f"           error: {result['error']}")
            if result.get("screenshot"):
                print(f"           screenshot: {result['screenshot']}")
            summary[result["status"]] = summary.get(result["status"], 0) + 1
            summary["details"].append(result)
            await page.wait_for_timeout(800)
            if not page.url.rstrip("/").endswith(INDEX_PATH):
                await go_to_index(page, workspace)
    print("\n=== SUMMARY ===")
    print(f"  created: {summary['created']}")
    print(f"  skipped: {summary['skipped']}")
    print(f"  failed:  {summary['failed']}")
    print(f"  error:   {summary['error']}")
    if summary["failed"] or summary["error"]:
        print("\n  Problem details:")
        for d in summary["details"]:
            if d["status"] in ("failed", "error"):
                print(f"    - {d['name']}: {d.get('error', '')}")


def main():
    ap = argparse.ArgumentParser(description="Manage Intercom conversation custom attributes via the admin UI.")
    ap.add_argument("--workspace", required=True, help="Workspace folder name under workspace/")
    mode = ap.add_mutually_exclusive_group(required=True)
    mode.add_argument("--probe", action="store_true", help="Open the index page and dump structure.")
    mode.add_argument("--probe-create-form", action="store_true", help="Click New, dump the create form structure.")
    mode.add_argument("--dry-run", action="store_true", help="Parse CSV dir, list what would be created.")
    mode.add_argument("--create", action="store_true", help="Create attributes from CSV dir.")
    ap.add_argument("--csv-dir", type=Path, help="Directory of fin_attribute_*.csv files. Required for --dry-run/--create.")
    ap.add_argument("--keep-underscores", action="store_true", help="Keep underscores in derived names (default: replace with spaces).")
    args = ap.parse_args()

    if args.probe:
        asyncio.run(run_probe(args.workspace))
    elif args.probe_create_form:
        asyncio.run(run_probe_create_form(args.workspace))
    elif args.dry_run:
        if not args.csv_dir:
            ap.error("--dry-run requires --csv-dir")
        asyncio.run(run_dry_run(args.workspace, args.csv_dir, args.keep_underscores))
    elif args.create:
        if not args.csv_dir:
            ap.error("--create requires --csv-dir")
        asyncio.run(run_create(args.workspace, args.csv_dir, args.keep_underscores))


if __name__ == "__main__":
    main()
