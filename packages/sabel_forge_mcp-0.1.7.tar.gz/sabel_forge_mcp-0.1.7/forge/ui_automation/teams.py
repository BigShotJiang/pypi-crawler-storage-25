"""
Create Intercom teams (inboxes) via the admin UI.

Read-only via API (only GET /teams exists). Each team has a name and a list
of admin members; routing/limits are configured per-team.

Usage:
    uv run python -m forge.ui_automation.teams \\
        --workspace Migr8now_Workspace --probe

    uv run python -m forge.ui_automation.teams \\
        --workspace Migr8now_Workspace --probe-create-form

    uv run python -m forge.ui_automation.teams \\
        --workspace Migr8now_Workspace --dry-run \\
        --payload forge/ui_automation/teams_payloads/example.yaml

    uv run python -m forge.ui_automation.teams \\
        --workspace Migr8now_Workspace --create \\
        --payload forge/ui_automation/teams_payloads/example.yaml

YAML schema (preliminary — refine after probing):
    teams:
      - name: "Customer Support"
        members:
          - "admin@example.com"
          - "manager@example.com"
"""
from __future__ import annotations

import argparse
import asyncio
import time
from pathlib import Path

import yaml

from forge.ui_automation.session import (
    ensure_logged_in,
    intercom_session,
    resolve_app_id,
    screenshot,
)

DEFAULT_PATH = "/settings/helpdesk/teams"


async def go_to_page(page, workspace: str, path: str):
    app_id = resolve_app_id(workspace)
    if not path.startswith("/"):
        path = "/" + path
    url = f"https://app.intercom.com/a/apps/{app_id}{path}"
    print(f"[teams] navigating to {url}")
    await page.goto(url, wait_until="domcontentloaded")
    try:
        await page.wait_for_load_state("networkidle", timeout=12_000)
    except Exception:
        pass
    await page.wait_for_timeout(800)


async def probe_page(page) -> dict:
    info: dict = {"url": page.url, "page_title": await page.title()}

    new_candidates = [
        ('role=button[name="New team"]', page.get_by_role("button", name="New team")),
        ('role=button[name="Create team"]', page.get_by_role("button", name="Create team")),
        ('role=button[name="Add team"]', page.get_by_role("button", name="Add team")),
        ('role=button[name="New"]', page.get_by_role("button", name="New").first),
        ('text="New team"', page.get_by_text("New team", exact=True).first),
    ]
    info["new_button_matches"] = []
    for label, loc in new_candidates:
        try:
            cnt = await loc.count()
            if cnt:
                info["new_button_matches"].append({
                    "selector": label,
                    "count": cnt,
                    "visible": await loc.first.is_visible(),
                })
        except Exception as e:
            info["new_button_matches"].append({"selector": label, "error": str(e)})

    try:
        all_buttons = await page.get_by_role("button").all_inner_texts()
        info["visible_buttons"] = [b.strip() for b in all_buttons if b.strip()][:60]
    except Exception as e:
        info["visible_buttons_error"] = str(e)

    try:
        headings = await page.locator("h1, h2, h3, h4, [role='heading']").all_inner_texts()
        info["headings"] = [h.strip() for h in headings if h.strip()][:30]
    except Exception as e:
        info["headings_error"] = str(e)

    return info


async def run_probe(workspace: str, path: str | None):
    async with intercom_session(workspace, headed=True) as ctx:
        page = await ensure_logged_in(ctx, workspace)
        await go_to_page(page, workspace, path or DEFAULT_PATH)
        info = await probe_page(page)
        shot = await screenshot(page, f"teams-index-{workspace}")

        print("\n=== TEAMS PROBE ===")
        print(f"URL:        {info['url']}")
        print(f"Page title: {info['page_title']}")
        print(f"Screenshot: {shot}")
        print("\nHeadings:")
        for h in info.get("headings", []):
            print(f"  - {h!r}")
        print("\nNew button candidates:")
        for m in info.get("new_button_matches", []):
            print(f"  - {m}")
        print("\nVisible buttons (first 60):")
        for b in info.get("visible_buttons", []):
            print(f"  - {b!r}")


async def run_probe_create_form(workspace: str, path: str | None):
    """Click 'New team inbox' and capture whatever form/modal mounts."""
    async with intercom_session(workspace, headed=True) as ctx:
        page = await ensure_logged_in(ctx, workspace)
        await go_to_page(page, workspace, path or DEFAULT_PATH)
        await screenshot(page, f"teams-before-new-{workspace}")

        for label in ("New team inbox", "New team", "New"):
            btn = page.get_by_role("button", name=label).first
            try:
                if await btn.count() and await btn.is_visible():
                    print(f"[teams] clicking {label!r}")
                    await btn.click()
                    break
            except Exception:
                continue
        else:
            raise RuntimeError("Could not find a 'New team inbox' button on the page")

        try:
            await page.wait_for_load_state("networkidle", timeout=8_000)
        except Exception:
            pass
        await page.wait_for_timeout(1500)

        info: dict = {"url": page.url}

        try:
            headings = await page.locator("h1, h2, h3, h4, [role='heading']").all_inner_texts()
            info["headings"] = [h.strip() for h in headings if h.strip()][:30]
        except Exception as e:
            info["headings_error"] = str(e)

        try:
            inputs = page.locator("input, textarea")
            cnt = await inputs.count()
            info["input_count"] = cnt
            samples = []
            for i in range(min(cnt, 15)):
                el = inputs.nth(i)
                try:
                    samples.append({
                        "index": i,
                        "tag": await el.evaluate("el => el.tagName"),
                        "type": await el.get_attribute("type"),
                        "placeholder": await el.get_attribute("placeholder"),
                        "aria-label": await el.get_attribute("aria-label"),
                        "name": await el.get_attribute("name"),
                    })
                except Exception as e:
                    samples.append({"index": i, "error": str(e)})
            info["input_samples"] = samples
        except Exception as e:
            info["input_error"] = str(e)

        try:
            all_buttons = await page.get_by_role("button").all_inner_texts()
            info["visible_buttons"] = [b.strip() for b in all_buttons if b.strip()][:60]
        except Exception as e:
            info["visible_buttons_error"] = str(e)

        try:
            info["combobox_count"] = await page.get_by_role("combobox").count()
            info["radio_count"] = await page.get_by_role("radio").count()
            info["checkbox_count"] = await page.get_by_role("checkbox").count()
        except Exception as e:
            info["choice_error"] = str(e)

        shot = await screenshot(page, f"teams-create-form-{workspace}")

        print("\n=== TEAMS CREATE-FORM PROBE ===")
        print(f"URL:        {info['url']}")
        print(f"Screenshot: {shot}")
        print(f"\nHeadings:")
        for h in info.get("headings", []):
            print(f"  - {h!r}")
        print(f"\nInput count: {info.get('input_count')}")
        for s in info.get("input_samples", []):
            print(f"  - {s}")
        print(f"\ncomboboxes={info.get('combobox_count')}  radios={info.get('radio_count')}  checkboxes={info.get('checkbox_count')}")
        print(f"\nButtons visible (first 60):")
        for b in info.get("visible_buttons", []):
            print(f"  - {b!r}")


# ────────────────────────────────────────────────────────────────────
# Create flow
# ────────────────────────────────────────────────────────────────────

NAME_INPUT = 'input[placeholder="Untitled Team inbox"]'
MEMBERS_INPUT = 'input[placeholder="Select at least one teammate…"]'
ALLOWED_ASSIGNMENT = {"manual", "round_robin", "balanced"}
# Map yaml keys → button label text shown in the UI
ASSIGNMENT_LABELS = {
    "manual": "Manual",
    "round_robin": "Round robin",
    "balanced": "Balanced",
}


def load_payload(path: Path) -> list[dict]:
    data = yaml.safe_load(path.read_text())
    items = data.get("teams") if isinstance(data, dict) else None
    if not isinstance(items, list):
        raise SystemExit(f"YAML at {path} must have a top-level 'teams:' list")
    for i, t in enumerate(items):
        if not isinstance(t, dict) or "name" not in t:
            raise SystemExit(f"teams[{i}] missing required field 'name'")
        members = t.get("members") or []
        if not isinstance(members, list) or not members:
            raise SystemExit(f"teams[{i}] requires non-empty 'members' list")
        method = (t.get("assignment_method") or "manual").lower()
        if method not in ALLOWED_ASSIGNMENT:
            raise SystemExit(f"teams[{i}].assignment_method must be one of {ALLOWED_ASSIGNMENT}")
        t["assignment_method"] = method
    return items


async def team_exists(page, name: str) -> bool:
    """Check if a team with this exact name appears on the index page."""
    found = page.get_by_text(name, exact=True)
    try:
        return await found.count() > 0
    except Exception:
        return False


async def _add_member(page, member: str):
    """Type a member name/email into the typeahead and select the first match.

    Strategies attempted in order — first one that results in a chip wins:
      1. Press ArrowDown + Enter on the typeahead (the standard way to pick
         the first suggestion in most typeaheads).
      2. role=option with matching accessible name.
      3. role=option containing the member's text.
      4. Any clickable text containing the member's name.
    """
    box = page.locator(MEMBERS_INPUT)
    await box.click()
    await box.fill(member)
    await page.wait_for_timeout(900)

    async def via_keyboard():
        await box.press("ArrowDown")
        await page.wait_for_timeout(150)
        await box.press("Enter")

    async def via_locator(loc):
        await loc.wait_for(state="visible", timeout=2_000)
        await loc.click()

    attempts = [
        ("arrow+enter", lambda: via_keyboard()),
        ("role=option exact", lambda: via_locator(page.get_by_role("option", name=member).first)),
        ("role=option contains", lambda: via_locator(page.get_by_role("option").filter(has_text=member).first)),
        ("text contains", lambda: via_locator(page.get_by_text(member, exact=False).first)),
    ]

    last_err = None
    for label, make_action in attempts:
        try:
            await make_action()
            await page.wait_for_timeout(500)
            # Re-fetch input value: a successful selection clears the typeahead.
            current = await box.input_value()
            if current.strip() == "":
                return  # success — chip added, input cleared
        except Exception as e:
            last_err = e
            continue
        # If we got here without exception but the input still has text,
        # this strategy didn't actually select; move to next.

    raise RuntimeError(
        f"Member {member!r} not found / not selectable in typeahead. "
        f"Last error: {last_err}. Confirm the admin exists (use list_admins) "
        f"and check the screenshot to see the dropdown state."
    )


async def create_one_team(page, workspace: str, item: dict) -> dict:
    name = item["name"]
    result = {"name": name, "status": "unknown"}

    if await team_exists(page, name):
        result["status"] = "skipped"
        return result

    new_btn = page.get_by_role("button", name="New team inbox").first
    await new_btn.wait_for(state="visible", timeout=10_000)
    await new_btn.click()

    # Wait for the inline form to mount (name input appears).
    await page.locator(NAME_INPUT).wait_for(state="visible", timeout=10_000)

    # Fill name. Triple-click to select existing default + verify-and-retry.
    title = page.locator(NAME_INPUT)
    for attempt in range(3):
        await title.click(click_count=3)
        await page.wait_for_timeout(150)
        await title.fill(name)
        await page.keyboard.press("Tab")
        await page.wait_for_timeout(400)
        actual = await title.input_value()
        if actual == name:
            break
        print(f"  [teams] name commit attempt {attempt + 1} mismatch (got {actual!r}); retrying")
    else:
        shot = await screenshot(page, f"teams-name-fail-{int(time.time())}")
        result["status"] = "failed"
        result["error"] = "could not commit team name"
        result["screenshot"] = str(shot)
        return result

    # Add each member.
    for m in item["members"]:
        try:
            await _add_member(page, m)
        except Exception as e:
            shot = await screenshot(page, f"teams-member-fail-{int(time.time())}")
            result["status"] = "error"
            result["error"] = f"adding member {m!r} failed: {e}"
            result["screenshot"] = str(shot)
            return result

    # Assignment method (default 'manual' is auto-selected, only act if non-default).
    if item["assignment_method"] != "manual":
        label = ASSIGNMENT_LABELS[item["assignment_method"]]
        method_btn = page.get_by_text(label, exact=True).first
        try:
            await method_btn.scroll_into_view_if_needed()
            await method_btn.click()
            await page.wait_for_timeout(300)
        except Exception as e:
            shot = await screenshot(page, f"teams-assignment-fail-{int(time.time())}")
            result["status"] = "error"
            result["error"] = f"could not select assignment method {label!r}: {e}"
            result["screenshot"] = str(shot)
            return result

    # Submit.
    create_btn = page.get_by_role("button", name="Create Team inbox").first
    await create_btn.wait_for(state="visible", timeout=10_000)
    try:
        await create_btn.scroll_into_view_if_needed()
        await create_btn.click()
    except Exception as e:
        shot = await screenshot(page, f"teams-create-click-fail-{int(time.time())}")
        result["status"] = "error"
        result["error"] = f"create click failed: {e}"
        result["screenshot"] = str(shot)
        return result

    # Wait for the create to settle. The inline form should collapse and the
    # team should appear in the list.
    try:
        await page.wait_for_load_state("networkidle", timeout=10_000)
    except Exception:
        pass
    await page.wait_for_timeout(1500)

    if await team_exists(page, name):
        result["status"] = "created"
    else:
        shot = await screenshot(page, f"teams-verify-fail-{int(time.time())}")
        result["status"] = "failed"
        result["screenshot"] = str(shot)
        result["error"] = "saved but did not appear on index"
    return result


async def run_dry_run(workspace: str, payload_path: Path, path: str | None):
    items = load_payload(payload_path)
    async with intercom_session(workspace, headed=True) as ctx:
        page = await ensure_logged_in(ctx, workspace)
        await go_to_page(page, workspace, path or DEFAULT_PATH)
        print(f"\n[dry-run] {len(items)} teams in payload")
        for t in items:
            exists = await team_exists(page, t["name"])
            verb = "SKIP (already exists)" if exists else "CREATE"
            print(f"  [{verb}] {t['name']!r}  members={t['members']}  method={t['assignment_method']}")


async def run_create(workspace: str, payload_path: Path, path: str | None):
    items = load_payload(payload_path)
    print(f"[create] {len(items)} teams in payload")
    summary = {"created": 0, "skipped": 0, "failed": 0, "error": 0, "details": []}

    async with intercom_session(workspace, headed=True) as ctx:
        page = await ensure_logged_in(ctx, workspace)
        await go_to_page(page, workspace, path or DEFAULT_PATH)

        for i, t in enumerate(items, 1):
            print(f"\n[create] [{i}/{len(items)}] {t['name']!r}")
            try:
                result = await create_one_team(page, workspace, t)
            except Exception as e:
                shot = await screenshot(page, f"teams-uncaught-{int(time.time())}")
                result = {
                    "name": t["name"],
                    "status": "error",
                    "error": f"uncaught: {e}",
                    "screenshot": str(shot),
                }
            print(f"           → {result['status']}")
            if result.get("error"):
                print(f"           error: {result['error']}")
            if result.get("screenshot"):
                print(f"           screenshot: {result['screenshot']}")
            summary[result["status"]] = summary.get(result["status"], 0) + 1
            summary["details"].append(result)
            # Make sure we're back on the clean index for the next iteration.
            await go_to_page(page, workspace, path or DEFAULT_PATH)

    print("\n=== SUMMARY ===")
    print(f"  created: {summary['created']}")
    print(f"  skipped: {summary['skipped']}")
    print(f"  failed:  {summary['failed']}")
    print(f"  error:   {summary['error']}")
    if summary["failed"] or summary["error"]:
        print("\n  Problem details:")
        for d in summary["details"]:
            if d["status"] in ("failed", "error"):
                print(f"    - {d['name']}: {d.get('error', '')}")


def main():
    ap = argparse.ArgumentParser(description="Manage Intercom teams via the admin UI.")
    ap.add_argument("--workspace", required=True, help="Workspace folder name under workspace/")
    mode = ap.add_mutually_exclusive_group(required=True)
    mode.add_argument("--probe", action="store_true", help="Probe the teams page.")
    mode.add_argument("--probe-create-form", action="store_true", help="Click 'New team inbox' and probe the form.")
    mode.add_argument("--dry-run", action="store_true", help="Parse payload and print which teams would be created/skipped.")
    mode.add_argument("--create", action="store_true", help="Create teams from --payload.")
    ap.add_argument("--path", help="Path under /a/apps/<app_id>. Defaults to the known teams URL.")
    ap.add_argument("--payload", type=Path, help="YAML file with teams to create")
    args = ap.parse_args()

    if args.probe:
        asyncio.run(run_probe(args.workspace, args.path))
    elif args.probe_create_form:
        asyncio.run(run_probe_create_form(args.workspace, args.path))
    elif args.dry_run:
        if not args.payload:
            ap.error("--dry-run requires --payload")
        asyncio.run(run_dry_run(args.workspace, args.payload, args.path))
    elif args.create:
        if not args.payload:
            ap.error("--create requires --payload")
        asyncio.run(run_create(args.workspace, args.payload, args.path))


if __name__ == "__main__":
    main()
