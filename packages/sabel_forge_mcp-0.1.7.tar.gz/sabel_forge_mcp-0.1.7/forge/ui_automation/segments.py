"""
Create Intercom segments via the admin UI.

Read-only via API. Segments are saved filters over people (users / leads /
visitors) and companies, found at /contacts/segments.

PARKED — NOT IMPLEMENTED.

The segments UI is built around a deeply nested filter-rule builder:
field combobox → operator combobox → value (sometimes another combobox,
sometimes a free-text input or date picker). Each pick reveals the next
control, and the available operators / value editors are field-dependent.
This makes the create form one of the more fragile UI surfaces in
Intercom — and the YAML schema needed to express segment rules would be
substantial (per-rule field type, operator, value, plus AND/OR groupings).

Recommendation: segments rarely need bulk migration. The list/get API
tools (list_segments, get_segment) cover the audit use case. For
implementation, treat segments as a manual UI step and document the
expected playbook segments per industry in playbooks/<industry>.md.

If/when this is built, plan for:
  - YAML schema for nested filter groups (and/or trees)
  - Per-field-type value renderers (text, number, date, boolean, list)
  - Idempotency by segment name
  - Audience type selector (user / lead / visitor / company)
"""
