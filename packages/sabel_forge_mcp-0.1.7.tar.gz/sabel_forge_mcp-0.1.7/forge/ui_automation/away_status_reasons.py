"""
Create Intercom away status reasons via the admin UI.

Read-only via API (only GET /away_status_reasons exists). Each reason
is a name + emoji shown to admins when they go away from the inbox.

Usage:
    # Step 1: probe the page to find URL + selectors
    uv run python -m forge.ui_automation.away_status_reasons \\
        --workspace Migr8now_Workspace --probe

    # Step 2: probe the create modal
    uv run python -m forge.ui_automation.away_status_reasons \\
        --workspace Migr8now_Workspace --probe-create-form

    # Dry run / create
    uv run python -m forge.ui_automation.away_status_reasons \\
        --workspace Migr8now_Workspace --dry-run \\
        --payload forge/ui_automation/away_status_reasons_payloads/example.yaml

    uv run python -m forge.ui_automation.away_status_reasons \\
        --workspace Migr8now_Workspace --create \\
        --payload forge/ui_automation/away_status_reasons_payloads/example.yaml

YAML schema:
    reasons:
      - name: "Lunch"
        emoji: "🥪"        # optional; UI may default to a generic icon
      - name: "Deep work"
        emoji: "🧠"
"""
from __future__ import annotations

import argparse
import asyncio
import time
from pathlib import Path

import yaml

from forge.ui_automation.session import (
    ensure_logged_in,
    intercom_session,
    resolve_app_id,
    screenshot,
)

# Confirmed path: the away-reasons UI lives behind a "Customize away
# reasons" button on the Assignments settings page (not a dedicated
# settings sub-page).
ASSIGNMENTS_PATH = "/settings/helpdesk/assignments"
CUSTOMIZE_BUTTON_TEXT = "Customize away reasons"


async def go_to_assignments(page, workspace: str):
    """Navigate to the Assignments settings page."""
    app_id = resolve_app_id(workspace)
    url = f"https://app.intercom.com/a/apps/{app_id}{ASSIGNMENTS_PATH}"
    print(f"[away] navigating to {url}")
    await page.goto(url, wait_until="domcontentloaded")
    try:
        await page.wait_for_load_state("networkidle", timeout=12_000)
    except Exception:
        pass
    await page.wait_for_timeout(800)


async def open_customize_modal(page):
    """Click the 'Customize away reasons' button. The away-reasons UI
    is behind this — typically a modal or side drawer."""
    candidates = [
        page.get_by_role("button", name=CUSTOMIZE_BUTTON_TEXT),
        page.get_by_role("link", name=CUSTOMIZE_BUTTON_TEXT),
        page.get_by_text(CUSTOMIZE_BUTTON_TEXT, exact=True),
    ]
    for loc in candidates:
        try:
            l = loc.first
            if await l.count() and await l.is_visible():
                print(f"[away] clicking '{CUSTOMIZE_BUTTON_TEXT}'")
                await l.click()
                await page.wait_for_timeout(1500)
                try:
                    await page.wait_for_load_state("networkidle", timeout=6_000)
                except Exception:
                    pass
                return
        except Exception:
            continue
    raise RuntimeError(
        f"Could not find a clickable element labeled {CUSTOMIZE_BUTTON_TEXT!r}"
        f" on {page.url}"
    )


async def probe(page) -> dict:
    info: dict = {"url": page.url, "page_title": await page.title()}

    new_candidates = [
        ('role=button[name="Add status"]', page.get_by_role("button", name="Add status")),
        ('role=button[name="Add reason"]', page.get_by_role("button", name="Add reason")),
        ('role=button[name="New status"]', page.get_by_role("button", name="New status")),
        ('role=button[name="New reason"]', page.get_by_role("button", name="New reason")),
        ('role=button[name="Add"]', page.get_by_role("button", name="Add").first),
        ('role=button[name="New"]', page.get_by_role("button", name="New").first),
        ('text="Add status"', page.get_by_text("Add status", exact=True).first),
        ('text="Add reason"', page.get_by_text("Add reason", exact=True).first),
    ]
    info["new_button_matches"] = []
    for label, loc in new_candidates:
        try:
            cnt = await loc.count()
            if cnt:
                info["new_button_matches"].append({
                    "selector": label,
                    "count": cnt,
                    "visible": await loc.first.is_visible(),
                })
        except Exception as e:
            info["new_button_matches"].append({"selector": label, "error": str(e)})

    try:
        all_buttons = await page.get_by_role("button").all_inner_texts()
        info["visible_buttons"] = [b.strip() for b in all_buttons if b.strip()][:60]
    except Exception as e:
        info["visible_buttons_error"] = str(e)

    try:
        headings = await page.locator("h1, h2, h3, h4, [role='heading']").all_inner_texts()
        info["headings"] = [h.strip() for h in headings if h.strip()][:30]
    except Exception as e:
        info["headings_error"] = str(e)

    return info


async def run_probe(workspace: str, override_path: str | None = None):
    """Probe the away-status-reasons UI.

    Default flow:
      1. Navigate to /settings/helpdesk/assignments
      2. Click "Customize away reasons"
      3. Probe whatever modal/drawer mounts
    """
    async with intercom_session(workspace, headed=True) as ctx:
        page = await ensure_logged_in(ctx, workspace)

        if override_path:
            app_id = resolve_app_id(workspace)
            if not override_path.startswith("/"):
                override_path = "/" + override_path
            url = f"https://app.intercom.com/a/apps/{app_id}{override_path}"
            print(f"[away] navigating to override path: {url}")
            await page.goto(url, wait_until="domcontentloaded")
            try:
                await page.wait_for_load_state("networkidle", timeout=10_000)
            except Exception:
                pass
            await page.wait_for_timeout(800)
        else:
            await go_to_assignments(page, workspace)
            await screenshot(page, f"away-assignments-page-{workspace}")
            await open_customize_modal(page)

        info = await probe(page)
        shot = await screenshot(page, f"away-status-modal-{workspace}")

        print("\n=== AWAY STATUS REASONS PROBE ===")
        print(f"URL:        {info['url']}")
        print(f"Page title: {info['page_title']}")
        print(f"Screenshot: {shot}")
        print("\nHeadings:")
        for h in info.get("headings", []):
            print(f"  - {h!r}")
        print("\nNew/Add button candidates:")
        for m in info.get("new_button_matches", []):
            print(f"  - {m}")
        print("\nVisible buttons (first 60):")
        for b in info.get("visible_buttons", []):
            print(f"  - {b!r}")


async def run_probe_create_form(workspace: str):
    """Open the Away reasons drawer, click 'New reason', probe the form."""
    async with intercom_session(workspace, headed=True) as ctx:
        page = await ensure_logged_in(ctx, workspace)
        await go_to_assignments(page, workspace)
        await open_customize_modal(page)

        new_btn = page.get_by_role("button", name="New reason").first
        await new_btn.wait_for(state="visible", timeout=10_000)
        print("[away] clicking 'New reason'")
        await new_btn.click()
        await page.wait_for_timeout(1500)
        try:
            await page.wait_for_load_state("networkidle", timeout=5_000)
        except Exception:
            pass

        info: dict = {"url": page.url}

        # Inputs / textareas / contenteditables that just appeared
        try:
            textboxes = page.get_by_role("textbox")
            cnt = await textboxes.count()
            info["textbox_count"] = cnt
            samples = []
            for i in range(min(cnt, 10)):
                tb = textboxes.nth(i)
                try:
                    samples.append({
                        "index": i,
                        "tag": await tb.evaluate("el => el.tagName"),
                        "placeholder": await tb.get_attribute("placeholder"),
                        "aria-label": await tb.get_attribute("aria-label"),
                        "contenteditable": await tb.evaluate("el => el.isContentEditable"),
                    })
                except Exception as e:
                    samples.append({"index": i, "error": str(e)})
            info["textbox_samples"] = samples
        except Exception as e:
            info["textbox_error"] = str(e)

        # All text inputs by selector (catches things role=textbox doesn't)
        try:
            inputs = page.locator("input, textarea")
            placeholders = []
            for i in range(min(await inputs.count(), 15)):
                ph = await inputs.nth(i).get_attribute("placeholder")
                al = await inputs.nth(i).get_attribute("aria-label")
                tag = await inputs.nth(i).evaluate("el => el.tagName")
                if ph or al:
                    placeholders.append({"tag": tag, "placeholder": ph, "aria-label": al})
            info["input_placeholders"] = placeholders
        except Exception as e:
            info["input_placeholders_error"] = str(e)

        try:
            all_buttons = await page.get_by_role("button").all_inner_texts()
            info["visible_buttons"] = [b.strip() for b in all_buttons if b.strip()][:60]
        except Exception as e:
            info["visible_buttons_error"] = str(e)

        try:
            headings = await page.locator("h1, h2, h3, h4, [role='heading']").all_inner_texts()
            info["headings"] = [h.strip() for h in headings if h.strip()][:30]
        except Exception as e:
            info["headings_error"] = str(e)

        shot = await screenshot(page, f"away-status-create-form-{workspace}")

        print("\n=== AWAY STATUS CREATE-FORM PROBE ===")
        print(f"URL:        {info['url']}")
        print(f"Screenshot: {shot}")
        print(f"\nHeadings:")
        for h in info.get("headings", []):
            print(f"  - {h!r}")
        print(f"\nTextbox count: {info.get('textbox_count')}")
        for s in info.get("textbox_samples", []):
            print(f"  - {s}")
        print(f"\nInput/textarea placeholders:")
        for p in info.get("input_placeholders", []):
            print(f"  - {p}")
        print(f"\nButtons visible (first 60):")
        for b in info.get("visible_buttons", []):
            print(f"  - {b!r}")


# ────────────────────────────────────────────────────────────────────
# Create flow
# ────────────────────────────────────────────────────────────────────


def load_payload(path: Path) -> list[dict]:
    data = yaml.safe_load(path.read_text())
    items = data.get("reasons") if isinstance(data, dict) else None
    if not isinstance(items, list):
        raise SystemExit(f"YAML at {path} must have a top-level 'reasons:' list")
    for i, r in enumerate(items):
        if not isinstance(r, dict) or "name" not in r:
            raise SystemExit(f"reasons[{i}] missing required field 'name'")
    return items


async def reason_exists(page, name: str) -> bool:
    """Check if a reason with this exact name appears in the open drawer."""
    found = page.get_by_text(name, exact=True)
    try:
        return await found.count() > 0
    except Exception:
        return False


async def create_one_reason(page, name: str) -> dict:
    """Create a single away reason. Drawer must already be open."""
    result = {"name": name, "status": "unknown"}

    if await reason_exists(page, name):
        result["status"] = "skipped"
        return result

    # Click "New reason" — adds an inline row with empty input.
    new_btn = page.get_by_role("button", name="New reason").first
    await new_btn.wait_for(state="visible", timeout=10_000)
    await new_btn.click()

    # Wait for the Save / Cancel buttons to appear (row mounted).
    save_btn = page.get_by_role("button", name="Save").first
    cancel_btn = page.get_by_role("button", name="Cancel").first
    await save_btn.wait_for(state="visible", timeout=10_000)
    await page.wait_for_timeout(300)

    # The new input is the only role=textbox in the drawer (the search
    # input doesn't register as one). Take .last to be safe.
    name_input = page.get_by_role("textbox").last
    try:
        await name_input.click()
        await name_input.fill(name)
        # Verify the value committed.
        actual = await name_input.input_value()
        if actual != name:
            shot = await screenshot(page, f"away-name-mismatch-{int(time.time())}")
            result["status"] = "failed"
            result["error"] = f"name input did not accept value (got {actual!r})"
            result["screenshot"] = str(shot)
            try:
                await cancel_btn.click()
            except Exception:
                pass
            return result
    except Exception as e:
        shot = await screenshot(page, f"away-fill-fail-{int(time.time())}")
        result["status"] = "error"
        result["error"] = f"fill failed: {e}"
        result["screenshot"] = str(shot)
        try:
            await cancel_btn.click()
        except Exception:
            pass
        return result

    # Save — wait for it to be enabled (it's disabled until name has content).
    await page.wait_for_timeout(300)
    try:
        await save_btn.click()
    except Exception as e:
        shot = await screenshot(page, f"away-save-click-fail-{int(time.time())}")
        result["status"] = "error"
        result["error"] = f"save click failed: {e}"
        result["screenshot"] = str(shot)
        return result

    await page.wait_for_timeout(1500)

    # Verify by re-checking presence in the drawer.
    if await reason_exists(page, name):
        result["status"] = "created"
    else:
        shot = await screenshot(page, f"away-verify-fail-{int(time.time())}")
        result["status"] = "failed"
        result["screenshot"] = str(shot)
        result["error"] = "saved but did not appear in drawer"
    return result


async def run_dry_run(workspace: str, payload_path: Path):
    items = load_payload(payload_path)
    async with intercom_session(workspace, headed=True) as ctx:
        page = await ensure_logged_in(ctx, workspace)
        await go_to_assignments(page, workspace)
        await open_customize_modal(page)
        print(f"\n[dry-run] {len(items)} reasons in payload — checking each in the drawer")
        for r in items:
            exists = await reason_exists(page, r["name"])
            verb = "SKIP (already exists)" if exists else "CREATE"
            print(f"  [{verb}] {r['name']!r}")


async def run_create(workspace: str, payload_path: Path):
    items = load_payload(payload_path)
    print(f"[create] {len(items)} reasons in payload")
    summary = {"created": 0, "skipped": 0, "failed": 0, "error": 0, "details": []}

    async with intercom_session(workspace, headed=True) as ctx:
        page = await ensure_logged_in(ctx, workspace)
        await go_to_assignments(page, workspace)
        await open_customize_modal(page)

        for i, r in enumerate(items, 1):
            name = r["name"]
            print(f"\n[create] [{i}/{len(items)}] {name!r}")
            try:
                result = await create_one_reason(page, name)
            except Exception as e:
                shot = await screenshot(page, f"away-uncaught-{int(time.time())}")
                result = {"name": name, "status": "error", "error": f"uncaught: {e}", "screenshot": str(shot)}
            print(f"           → {result['status']}")
            if result.get("error"):
                print(f"           error: {result['error']}")
            if result.get("screenshot"):
                print(f"           screenshot: {result['screenshot']}")
            summary[result["status"]] = summary.get(result["status"], 0) + 1
            summary["details"].append(result)
            await page.wait_for_timeout(500)

    print("\n=== SUMMARY ===")
    print(f"  created: {summary['created']}")
    print(f"  skipped: {summary['skipped']}")
    print(f"  failed:  {summary['failed']}")
    print(f"  error:   {summary['error']}")
    if summary["failed"] or summary["error"]:
        print("\n  Problem details:")
        for d in summary["details"]:
            if d["status"] in ("failed", "error"):
                print(f"    - {d['name']}: {d.get('error', '')}")


def main():
    ap = argparse.ArgumentParser(description="Manage Intercom away status reasons via the admin UI.")
    ap.add_argument("--workspace", required=True, help="Workspace folder name under workspace/")
    mode = ap.add_mutually_exclusive_group(required=True)
    mode.add_argument("--probe", action="store_true", help="Probe the away-status-reasons page.")
    mode.add_argument("--probe-create-form", action="store_true", help="Open drawer, click 'New reason', probe the form.")
    mode.add_argument("--dry-run", action="store_true", help="Parse payload, print which reasons would be created/skipped. No writes.")
    mode.add_argument("--create", action="store_true", help="Create reasons from --payload.")
    ap.add_argument("--path", help="Override path. Skips the candidate-path search (legacy).")
    ap.add_argument("--payload", type=Path, help="YAML file with reasons to create")
    args = ap.parse_args()

    if args.probe:
        asyncio.run(run_probe(args.workspace, args.path))
    elif args.probe_create_form:
        asyncio.run(run_probe_create_form(args.workspace))
    elif args.dry_run:
        if not args.payload:
            ap.error("--dry-run requires --payload")
        asyncio.run(run_dry_run(args.workspace, args.payload))
    elif args.create:
        if not args.payload:
            ap.error("--create requires --payload")
        asyncio.run(run_create(args.workspace, args.payload))


if __name__ == "__main__":
    main()
