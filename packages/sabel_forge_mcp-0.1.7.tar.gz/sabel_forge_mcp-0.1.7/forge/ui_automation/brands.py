"""
Create Intercom brands via the admin UI.

Read-only via API. Brand creation may be plan-gated (Premium / Convert
plans typically required for multi-brand support).

KNOWN LIMITATION — PARKED:
This script is incomplete. The New brand drawer requires both a Help
Center selection AND a verified Default address before Save enables.
The Help Center dropdown picker has not been reliably scoped to the
side drawer popover — my best attempt clicked elements on the index
page (existing brand cards) instead, which switches the drawer into
"Edit brand" mode for the wrong brand and corrupts the run.

Preconditions for ever making this work:
  - At least one verified sender email address exists in the workspace
    (Settings → Channels → Email → Addresses).
  - At least one Help Center exists.
  - Picker logic must scope strictly to the .side-drawer__wrapper
    container (not viewport position), since brand cards on the index
    overlap the drawer's x range.

Probe modes work; create mode is unreliable. Recommend manual UI for
brand creation (typically 1-5 per workspace, rarely changed).
"""
from __future__ import annotations

import argparse
import asyncio
import time
from pathlib import Path

import yaml

from forge.ui_automation.session import (
    ensure_logged_in,
    intercom_session,
    resolve_app_id,
    screenshot,
)

DEFAULT_PATH = "/settings/workspace/brands"


async def go_to_page(page, workspace: str, path: str):
    app_id = resolve_app_id(workspace)
    if not path.startswith("/"):
        path = "/" + path
    url = f"https://app.intercom.com/a/apps/{app_id}{path}"
    print(f"[brands] navigating to {url}")
    await page.goto(url, wait_until="domcontentloaded")
    try:
        await page.wait_for_load_state("networkidle", timeout=12_000)
    except Exception:
        pass
    await page.wait_for_timeout(800)


async def probe_page(page) -> dict:
    info: dict = {"url": page.url, "page_title": await page.title()}

    new_candidates = [
        ('role=button[name="New brand"]', page.get_by_role("button", name="New brand")),
        ('role=button[name="Create brand"]', page.get_by_role("button", name="Create brand")),
        ('role=button[name="Add brand"]', page.get_by_role("button", name="Add brand")),
        ('role=button[name="New"]', page.get_by_role("button", name="New").first),
    ]
    info["new_button_matches"] = []
    for label, loc in new_candidates:
        try:
            cnt = await loc.count()
            if cnt:
                info["new_button_matches"].append({
                    "selector": label,
                    "count": cnt,
                    "visible": await loc.first.is_visible(),
                })
        except Exception as e:
            info["new_button_matches"].append({"selector": label, "error": str(e)})

    try:
        all_buttons = await page.get_by_role("button").all_inner_texts()
        info["visible_buttons"] = [b.strip() for b in all_buttons if b.strip()][:60]
    except Exception as e:
        info["visible_buttons_error"] = str(e)

    try:
        headings = await page.locator("h1, h2, h3, h4, [role='heading']").all_inner_texts()
        info["headings"] = [h.strip() for h in headings if h.strip()][:30]
    except Exception as e:
        info["headings_error"] = str(e)

    return info


async def run_probe(workspace: str, path: str | None):
    async with intercom_session(workspace, headed=True) as ctx:
        page = await ensure_logged_in(ctx, workspace)
        await go_to_page(page, workspace, path or DEFAULT_PATH)
        info = await probe_page(page)
        shot = await screenshot(page, f"brands-index-{workspace}")

        print("\n=== BRANDS PROBE ===")
        print(f"URL:        {info['url']}")
        print(f"Page title: {info['page_title']}")
        print(f"Screenshot: {shot}")
        print("\nHeadings:")
        for h in info.get("headings", []):
            print(f"  - {h!r}")
        print("\nNew button candidates:")
        for m in info.get("new_button_matches", []):
            print(f"  - {m}")
        print("\nVisible buttons (first 60):")
        for b in info.get("visible_buttons", []):
            print(f"  - {b!r}")


async def run_probe_create_form(workspace: str, path: str | None):
    async with intercom_session(workspace, headed=True) as ctx:
        page = await ensure_logged_in(ctx, workspace)
        await go_to_page(page, workspace, path or DEFAULT_PATH)
        await screenshot(page, f"brands-before-new-{workspace}")

        for label in ("New brand", "Create brand", "New"):
            btn = page.get_by_role("button", name=label).first
            try:
                if await btn.count() and await btn.is_visible():
                    print(f"[brands] clicking {label!r}")
                    await btn.click()
                    break
            except Exception:
                continue
        else:
            raise RuntimeError("Could not find a New brand button")

        try:
            await page.wait_for_load_state("networkidle", timeout=8_000)
        except Exception:
            pass
        await page.wait_for_timeout(1500)

        info: dict = {"url": page.url}
        try:
            headings = await page.locator("h1, h2, h3, h4, [role='heading']").all_inner_texts()
            info["headings"] = [h.strip() for h in headings if h.strip()][:30]
        except Exception as e:
            info["headings_error"] = str(e)
        try:
            inputs = page.locator("input, textarea")
            cnt = await inputs.count()
            info["input_count"] = cnt
            samples = []
            for i in range(min(cnt, 15)):
                el = inputs.nth(i)
                try:
                    samples.append({
                        "index": i,
                        "tag": await el.evaluate("el => el.tagName"),
                        "type": await el.get_attribute("type"),
                        "placeholder": await el.get_attribute("placeholder"),
                        "aria-label": await el.get_attribute("aria-label"),
                    })
                except Exception as e:
                    samples.append({"index": i, "error": str(e)})
            info["input_samples"] = samples
        except Exception as e:
            info["input_error"] = str(e)
        try:
            all_buttons = await page.get_by_role("button").all_inner_texts()
            info["visible_buttons"] = [b.strip() for b in all_buttons if b.strip()][:60]
        except Exception as e:
            info["visible_buttons_error"] = str(e)

        shot = await screenshot(page, f"brands-create-form-{workspace}")
        print("\n=== BRANDS CREATE-FORM PROBE ===")
        print(f"URL:        {info['url']}")
        print(f"Screenshot: {shot}")
        print(f"\nHeadings:")
        for h in info.get("headings", []):
            print(f"  - {h!r}")
        print(f"\nInput count: {info.get('input_count')}")
        for s in info.get("input_samples", []):
            print(f"  - {s}")
        print(f"\nButtons visible (first 60):")
        for b in info.get("visible_buttons", []):
            print(f"  - {b!r}")


# ────────────────────────────────────────────────────────────────────
# Create flow
# ────────────────────────────────────────────────────────────────────

NAME_INPUT = 'input[placeholder="Enter brand name"]'


def load_payload(path: Path) -> list[dict]:
    data = yaml.safe_load(path.read_text())
    items = data.get("brands") if isinstance(data, dict) else None
    if not isinstance(items, list):
        raise SystemExit(f"YAML at {path} must have a top-level 'brands:' list")
    for i, b in enumerate(items):
        if not isinstance(b, dict) or "name" not in b:
            raise SystemExit(f"brands[{i}] missing required 'name'")
    return items


async def brand_exists(page, name: str) -> bool:
    found = page.get_by_text(name, exact=True)
    try:
        return await found.count() > 0
    except Exception:
        return False


async def _open_dropdown(page, section_heading: str) -> dict:
    """Find the dropdown trigger near a section heading IN THE SIDE DRAWER
    (right half of the viewport) and click it open. Scoping by viewport
    position prevents matching same-named items in the page's left sidebar."""
    return await page.evaluate(
        """(heading) => {
            const minX = window.innerWidth * 0.4;  // drawer lives right of this
            // Find every element matching the heading, prefer ones in the
            // drawer (right half of viewport) and as small as possible.
            const matches = [...document.querySelectorAll('*')].filter(el => {
                if (!el.textContent || el.textContent.trim() !== heading) return false;
                const r = el.getBoundingClientRect();
                if (r.width === 0 || r.height === 0) return false;
                if (r.left < minX) return false;
                // Prefer leaf-ish elements: text node parent
                return el.children.length <= 2;
            });
            matches.sort((a, b) => (a.innerText.length - b.innerText.length));
            const target = matches[0];
            if (!target) return {ok: false, err: heading + ' heading not found in drawer (right half)'};

            // Walk up from the heading looking for a section card with a button.
            let node = target.parentElement;
            for (let depth = 0; depth < 8 && node; depth++) {
                const buttons = [...node.querySelectorAll('button')];
                const trigger = buttons.find(b => {
                    const t = (b.innerText || '').trim();
                    if (['Save','Cancel','Learn','Close','Select phone numbers',
                         'Add new email address','+ Add new email address'].includes(t)) return false;
                    // Trigger must be in the drawer too
                    const r = b.getBoundingClientRect();
                    return r.left >= minX;
                });
                if (trigger) {
                    trigger.scrollIntoView({block: 'center'});
                    trigger.click();
                    return {ok: true, depth, label: (trigger.innerText||'').trim().slice(0,60)};
                }
                node = node.parentElement;
            }
            return {ok: false, err: 'no dropdown trigger found near ' + heading};
        }""",
        section_heading,
    )


async def _pick_first_email_address(page):
    """Open Default address dropdown, pick the first email option."""
    opened = await _open_dropdown(page, "Default address")
    if not opened.get("ok"):
        raise RuntimeError(f"Could not open Default address dropdown: {opened.get('err')}")
    await page.wait_for_timeout(700)

    picked = await page.evaluate(
        """() => {
            // Find the smallest visible element whose text is an email-like value.
            const candidates = [...document.querySelectorAll('*')].filter(el => {
                const t = (el.innerText || '').trim();
                if (!t.includes('@') || t.length > 100) return false;
                const r = el.getBoundingClientRect();
                if (r.width === 0 || r.height === 0) return false;
                if (['INPUT','TEXTAREA','BUTTON'].includes(el.tagName)) return false;
                // Must look like an email (one @ surrounded by non-whitespace)
                if (!/\\S+@\\S+\\.\\S+/.test(t)) return false;
                return true;
            });
            candidates.sort((a, b) => (a.innerText.length - b.innerText.length));
            const opt = candidates[0];
            if (!opt) return {ok: false, err: 'no email option visible'};
            opt.scrollIntoView({block: 'center'});
            opt.click();
            return {ok: true, text: opt.innerText.trim().slice(0, 80)};
        }"""
    )
    if not picked.get("ok"):
        raise RuntimeError(
            "No verified sender email address available in this workspace. "
            "Add+verify one via Settings → Channels → Email → Addresses first."
        )
    await page.wait_for_timeout(500)


async def _pick_first_help_center(page):
    """Open Help Center dropdown and pick the first option in the popover."""
    opened = await _open_dropdown(page, "Help Center")
    if not opened.get("ok"):
        raise RuntimeError(f"Could not open Help Center dropdown: {opened.get('err')}")
    await page.wait_for_timeout(700)

    # Pick the first option from the popover. SCOPE to the right half of
    # the viewport (the drawer) AND to elements that look like dropdown
    # rows (cursor:pointer, short text, leaf-ish).
    picked = await page.evaluate(
        """() => {
            const minX = window.innerWidth * 0.4;
            const skip = new Set(['Help Center','Default address','Brand name',
                                  'Phone numbers','Save','Cancel','Learn','Close',
                                  'Select phone numbers','New brand',
                                  'Add new email address','+ Add new email address']);
            const candidates = [...document.querySelectorAll('*')].filter(el => {
                const t = (el.innerText || '').trim();
                if (!t || t.length > 80 || skip.has(t)) return false;
                const r = el.getBoundingClientRect();
                if (r.width === 0 || r.height === 0) return false;
                if (r.left < minX) return false;
                if (['INPUT','TEXTAREA','BUTTON','HEADER','HTML','BODY','SVG','PATH'].includes(el.tagName)) return false;
                const cs = window.getComputedStyle(el);
                if (cs.cursor !== 'pointer') return false;
                // Leaf-ish: no children, or children are empty/duplicate text
                if (el.children.length > 0) {
                    const allLeaf = [...el.children].every(c => {
                        const ct = (c.innerText || '').trim();
                        return ct === '' || ct === t;
                    });
                    if (!allLeaf) return false;
                }
                return true;
            });
            candidates.sort((a, b) => (a.innerText.length - b.innerText.length));
            const opt = candidates[0];
            if (!opt) return {ok: false, err: 'no help center option in drawer popover'};
            opt.scrollIntoView({block: 'center'});
            opt.click();
            return {ok: true, text: opt.innerText.trim().slice(0, 80)};
        }"""
    )
    if not picked.get("ok"):
        raise RuntimeError(
            "No Help Center option available to pick. The workspace needs at "
            "least one Help Center created first."
        )
    await page.wait_for_timeout(500)


async def create_one_brand(page, item: dict) -> dict:
    name = item["name"]
    result = {"name": name, "status": "unknown"}

    if await brand_exists(page, name):
        result["status"] = "skipped"
        return result

    new_btn = page.get_by_role("button", name="New brand").first
    await new_btn.wait_for(state="visible", timeout=10_000)
    await new_btn.click()

    name_input = page.locator(NAME_INPUT)
    await name_input.wait_for(state="visible", timeout=10_000)
    await name_input.fill(name)
    await page.wait_for_timeout(400)

    # Help Center and Default address are both required before Save enables.
    # Set Help Center first (so the address dropdown selection isn't lost
    # if filling a different field interferes).
    try:
        await _pick_first_help_center(page)
    except Exception as e:
        shot = await screenshot(page, f"brands-help-center-fail-{int(time.time())}")
        result["status"] = "error"
        result["error"] = f"could not set Help Center: {e}"
        result["screenshot"] = str(shot)
        return result

    try:
        await _pick_first_email_address(page)
    except Exception as e:
        shot = await screenshot(page, f"brands-default-addr-fail-{int(time.time())}")
        result["status"] = "error"
        result["error"] = f"could not set Default address: {e}"
        result["screenshot"] = str(shot)
        return result

    save_btn = page.get_by_role("button", name="Save").first
    await save_btn.wait_for(state="visible", timeout=10_000)
    try:
        await save_btn.click()
    except Exception as e:
        shot = await screenshot(page, f"brands-save-fail-{int(time.time())}")
        result["status"] = "error"
        result["error"] = f"save click failed: {e}"
        result["screenshot"] = str(shot)
        return result

    try:
        await page.wait_for_load_state("networkidle", timeout=8_000)
    except Exception:
        pass
    await page.wait_for_timeout(1500)

    if await brand_exists(page, name):
        result["status"] = "created"
    else:
        shot = await screenshot(page, f"brands-verify-fail-{int(time.time())}")
        result["status"] = "failed"
        result["screenshot"] = str(shot)
        result["error"] = "saved but did not appear on index"
    return result


async def run_dry_run(workspace: str, payload_path: Path, path: str | None):
    items = load_payload(payload_path)
    async with intercom_session(workspace, headed=True) as ctx:
        page = await ensure_logged_in(ctx, workspace)
        await go_to_page(page, workspace, path or DEFAULT_PATH)
        print(f"\n[dry-run] {len(items)} brands in payload")
        for b in items:
            exists = await brand_exists(page, b["name"])
            verb = "SKIP (already exists)" if exists else "CREATE"
            print(f"  [{verb}] {b['name']!r}")


async def run_create(workspace: str, payload_path: Path, path: str | None):
    items = load_payload(payload_path)
    print(f"[create] {len(items)} brands in payload")
    summary = {"created": 0, "skipped": 0, "failed": 0, "error": 0, "details": []}

    async with intercom_session(workspace, headed=True) as ctx:
        page = await ensure_logged_in(ctx, workspace)
        await go_to_page(page, workspace, path or DEFAULT_PATH)

        for i, b in enumerate(items, 1):
            print(f"\n[create] [{i}/{len(items)}] {b['name']!r}")
            try:
                result = await create_one_brand(page, b)
            except Exception as e:
                shot = await screenshot(page, f"brands-uncaught-{int(time.time())}")
                result = {"name": b["name"], "status": "error", "error": f"uncaught: {e}", "screenshot": str(shot)}
            print(f"           → {result['status']}")
            if result.get("error"):
                print(f"           error: {result['error']}")
            if result.get("screenshot"):
                print(f"           screenshot: {result['screenshot']}")
            summary[result["status"]] = summary.get(result["status"], 0) + 1
            summary["details"].append(result)
            await go_to_page(page, workspace, path or DEFAULT_PATH)

    print("\n=== SUMMARY ===")
    print(f"  created: {summary['created']}")
    print(f"  skipped: {summary['skipped']}")
    print(f"  failed:  {summary['failed']}")
    print(f"  error:   {summary['error']}")


def main():
    ap = argparse.ArgumentParser(description="Manage Intercom brands via the admin UI.")
    ap.add_argument("--workspace", required=True, help="Workspace folder name under workspace/")
    mode = ap.add_mutually_exclusive_group(required=True)
    mode.add_argument("--probe", action="store_true", help="Probe the brands page.")
    mode.add_argument("--probe-create-form", action="store_true", help="Click New brand and probe the form.")
    mode.add_argument("--dry-run", action="store_true", help="Parse payload and print which brands would be created/skipped.")
    mode.add_argument("--create", action="store_true", help="Create brands from --payload.")
    ap.add_argument("--path", help="Path under /a/apps/<app_id>. Defaults to known URL.")
    ap.add_argument("--payload", type=Path, help="YAML file with brands to create")
    args = ap.parse_args()

    if args.probe:
        asyncio.run(run_probe(args.workspace, args.path))
    elif args.probe_create_form:
        asyncio.run(run_probe_create_form(args.workspace, args.path))
    elif args.dry_run:
        if not args.payload:
            ap.error("--dry-run requires --payload")
        asyncio.run(run_dry_run(args.workspace, args.payload, args.path))
    elif args.create:
        if not args.payload:
            ap.error("--create requires --payload")
        asyncio.run(run_create(args.workspace, args.payload, args.path))


if __name__ == "__main__":
    main()
