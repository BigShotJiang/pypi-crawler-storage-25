"""
Create Intercom subscription types via the admin UI.

Read-only via API (only GET /subscription_types exists). Each subscription
type is a name + description + type (one-time / ongoing) + default opt-in
state, used to gate marketing/transactional/account messaging consent.

Usage:
    # Step 1: probe the page to find selectors. Pass --path with the URL
    # you see in your browser when you navigate to subscription types
    # settings (the path under /a/apps/<app_id>).
    uv run python -m forge.ui_automation.subscription_types \\
        --workspace Migr8now_Workspace --probe --path /settings/...

    # Step 2: probe the create modal/form
    uv run python -m forge.ui_automation.subscription_types \\
        --workspace Migr8now_Workspace --probe-create-form --path /settings/...

    # Dry run / create
    uv run python -m forge.ui_automation.subscription_types \\
        --workspace Migr8now_Workspace --dry-run \\
        --payload forge/ui_automation/subscription_types_payloads/example.yaml

    uv run python -m forge.ui_automation.subscription_types \\
        --workspace Migr8now_Workspace --create \\
        --payload forge/ui_automation/subscription_types_payloads/example.yaml

YAML schema (preliminary — refine after probing the create form):
    subscriptions:
      - name: "Product updates"
        description: "Monthly product news and feature releases"
        type: "ongoing"            # 'ongoing' or 'one-time'
        default_opt_in: false       # may be UI-only; refine after probe
"""
from __future__ import annotations

import argparse
import asyncio
import time
from pathlib import Path

import yaml

from forge.ui_automation.session import (
    ensure_logged_in,
    intercom_session,
    resolve_app_id,
    screenshot,
)

DEFAULT_PATH = "/settings/proactive-support/subscriptions"


async def go_to_page(page, workspace: str, path: str):
    app_id = resolve_app_id(workspace)
    if not path.startswith("/"):
        path = "/" + path
    url = f"https://app.intercom.com/a/apps/{app_id}{path}"
    print(f"[subs] navigating to {url}")
    await page.goto(url, wait_until="domcontentloaded")
    try:
        await page.wait_for_load_state("networkidle", timeout=12_000)
    except Exception:
        pass
    await page.wait_for_timeout(800)


async def probe_page(page) -> dict:
    info: dict = {"url": page.url, "page_title": await page.title()}

    # Likely button names for adding a new subscription type
    new_candidates = [
        ('role=button[name="New subscription type"]',
         page.get_by_role("button", name="New subscription type")),
        ('role=button[name="Create subscription type"]',
         page.get_by_role("button", name="Create subscription type")),
        ('role=button[name="Add subscription"]',
         page.get_by_role("button", name="Add subscription")),
        ('role=button[name="New"]', page.get_by_role("button", name="New").first),
        ('role=button[name="Create"]', page.get_by_role("button", name="Create").first),
        ('text="New subscription type"',
         page.get_by_text("New subscription type", exact=True).first),
    ]
    info["new_button_matches"] = []
    for label, loc in new_candidates:
        try:
            cnt = await loc.count()
            if cnt:
                info["new_button_matches"].append({
                    "selector": label,
                    "count": cnt,
                    "visible": await loc.first.is_visible(),
                })
        except Exception as e:
            info["new_button_matches"].append({"selector": label, "error": str(e)})

    try:
        all_buttons = await page.get_by_role("button").all_inner_texts()
        info["visible_buttons"] = [b.strip() for b in all_buttons if b.strip()][:60]
    except Exception as e:
        info["visible_buttons_error"] = str(e)

    try:
        headings = await page.locator("h1, h2, h3, h4, [role='heading']").all_inner_texts()
        info["headings"] = [h.strip() for h in headings if h.strip()][:30]
    except Exception as e:
        info["headings_error"] = str(e)

    return info


async def run_probe(workspace: str, path: str | None):
    if not path and not DEFAULT_PATH:
        raise SystemExit(
            "No --path provided and no DEFAULT_PATH set in the script. "
            "Open Intercom's subscription types page in your browser and "
            "pass the path under /a/apps/<id> as --path."
        )
    async with intercom_session(workspace, headed=True) as ctx:
        page = await ensure_logged_in(ctx, workspace)
        await go_to_page(page, workspace, path or DEFAULT_PATH)
        info = await probe_page(page)
        shot = await screenshot(page, f"subs-index-{workspace}")

        print("\n=== SUBSCRIPTION TYPES PROBE ===")
        print(f"URL:        {info['url']}")
        print(f"Page title: {info['page_title']}")
        print(f"Screenshot: {shot}")
        print("\nHeadings:")
        for h in info.get("headings", []):
            print(f"  - {h!r}")
        print("\nNew/Create button candidates:")
        for m in info.get("new_button_matches", []):
            print(f"  - {m}")
        print("\nVisible buttons (first 60):")
        for b in info.get("visible_buttons", []):
            print(f"  - {b!r}")


async def run_probe_create_form(workspace: str, path: str | None):
    """Click 'New Subscription', capture whatever the form/modal looks like."""
    async with intercom_session(workspace, headed=True) as ctx:
        page = await ensure_logged_in(ctx, workspace)
        await go_to_page(page, workspace, path or DEFAULT_PATH)
        await screenshot(page, f"subs-before-new-{workspace}")

        # Try common labels for the new button.
        for label in ("New Subscription", "New subscription", "New"):
            btn = page.get_by_role("button", name=label).first
            try:
                if await btn.count() and await btn.is_visible():
                    print(f"[subs] clicking {label!r}")
                    await btn.click()
                    break
            except Exception:
                continue
        else:
            raise RuntimeError("Could not find a 'New Subscription' button on the page")

        try:
            await page.wait_for_load_state("networkidle", timeout=8_000)
        except Exception:
            pass
        await page.wait_for_timeout(1500)

        info: dict = {"url": page.url}

        try:
            headings = await page.locator("h1, h2, h3, h4, [role='heading']").all_inner_texts()
            info["headings"] = [h.strip() for h in headings if h.strip()][:30]
        except Exception as e:
            info["headings_error"] = str(e)

        try:
            inputs = page.locator("input, textarea")
            cnt = await inputs.count()
            info["input_count"] = cnt
            samples = []
            for i in range(min(cnt, 15)):
                el = inputs.nth(i)
                try:
                    samples.append({
                        "index": i,
                        "tag": await el.evaluate("el => el.tagName"),
                        "type": await el.get_attribute("type"),
                        "placeholder": await el.get_attribute("placeholder"),
                        "aria-label": await el.get_attribute("aria-label"),
                        "name": await el.get_attribute("name"),
                    })
                except Exception as e:
                    samples.append({"index": i, "error": str(e)})
            info["input_samples"] = samples
        except Exception as e:
            info["input_error"] = str(e)

        try:
            all_buttons = await page.get_by_role("button").all_inner_texts()
            info["visible_buttons"] = [b.strip() for b in all_buttons if b.strip()][:60]
        except Exception as e:
            info["visible_buttons_error"] = str(e)

        # Look for radio / select-style inputs (consent type, message type)
        try:
            info["radio_count"] = await page.get_by_role("radio").count()
            info["combobox_count"] = await page.get_by_role("combobox").count()
        except Exception as e:
            info["choice_error"] = str(e)

        shot = await screenshot(page, f"subs-create-form-{workspace}")

        print("\n=== SUBSCRIPTION CREATE-FORM PROBE ===")
        print(f"URL:        {info['url']}")
        print(f"Screenshot: {shot}")
        print(f"\nHeadings:")
        for h in info.get("headings", []):
            print(f"  - {h!r}")
        print(f"\nInput count: {info.get('input_count')}")
        for s in info.get("input_samples", []):
            print(f"  - {s}")
        print(f"\nradios={info.get('radio_count')}  comboboxes={info.get('combobox_count')}")
        print(f"\nButtons visible (first 60):")
        for b in info.get("visible_buttons", []):
            print(f"  - {b!r}")


# ────────────────────────────────────────────────────────────────────
# Create flow
# ────────────────────────────────────────────────────────────────────

NAME_INPUT = 'input[placeholder="e.g. Newsletter"]'
DESC_INPUT = 'input[placeholder="e.g. Latest news, tips and updates"]'
ALLOWED_MESSAGE_TYPES = {"email", "sms"}
ALLOWED_CONSENT_TYPES = {"opt-in", "opt-out"}


def load_payload(path: Path) -> list[dict]:
    data = yaml.safe_load(path.read_text())
    items = data.get("subscriptions") if isinstance(data, dict) else None
    if not isinstance(items, list):
        raise SystemExit(f"YAML at {path} must have a top-level 'subscriptions:' list")
    for i, s in enumerate(items):
        if not isinstance(s, dict) or "name" not in s or "description" not in s:
            raise SystemExit(f"subscriptions[{i}] missing required 'name' and 'description'")
        mt = (s.get("message_type") or "email").lower()
        ct = (s.get("consent_type") or "opt-in").lower()
        if mt not in ALLOWED_MESSAGE_TYPES:
            raise SystemExit(f"subscriptions[{i}].message_type must be one of {ALLOWED_MESSAGE_TYPES}")
        if ct not in ALLOWED_CONSENT_TYPES:
            raise SystemExit(f"subscriptions[{i}].consent_type must be one of {ALLOWED_CONSENT_TYPES}")
        s["message_type"] = mt
        s["consent_type"] = ct
    return items


async def subscription_exists(page, name: str) -> bool:
    """Check if a subscription with this exact name appears on the index page."""
    found = page.get_by_text(name, exact=True)
    try:
        return await found.count() > 0
    except Exception:
        return False


async def create_one_subscription(page, workspace: str, item: dict) -> dict:
    """Create a single subscription. Page must already be on the index."""
    name = item["name"]
    result = {"name": name, "status": "unknown"}

    if await subscription_exists(page, name):
        result["status"] = "skipped"
        return result

    # Click "New Subscription" — navigates to /subscriptions/new.
    new_btn = page.get_by_role("button", name="New Subscription").first
    if not await new_btn.count():
        new_btn = page.get_by_role("button", name="New").first
    await new_btn.wait_for(state="visible", timeout=10_000)
    await new_btn.click()

    # Wait for form mount (name input appears).
    await page.locator(NAME_INPUT).wait_for(state="visible", timeout=10_000)

    # Fill name + description
    await page.locator(NAME_INPUT).fill(name)
    await page.locator(DESC_INPUT).fill(item["description"])
    await page.wait_for_timeout(300)

    # Toggle message type only if non-default (default is Email)
    if item["message_type"] == "sms":
        sms_btn = page.get_by_role("button", name="SMS").first
        await sms_btn.click()
        await page.wait_for_timeout(300)

    # Toggle consent type only if non-default (default is Opt-In)
    if item["consent_type"] == "opt-out":
        # The cards aren't role=button — they're divs with text.
        # Click on the "Opt-Out" heading text inside the card.
        opt_out = page.get_by_text("Opt-Out", exact=True).first
        await opt_out.wait_for(state="visible", timeout=5_000)
        await opt_out.click()
        await page.wait_for_timeout(300)

    # Save and Close
    save_btn = page.get_by_role("button", name="Save and Close").first
    await save_btn.wait_for(state="visible", timeout=10_000)
    try:
        await save_btn.click()
    except Exception as e:
        shot = await screenshot(page, f"subs-save-fail-{int(time.time())}")
        result["status"] = "error"
        result["error"] = f"save click failed: {e}"
        result["screenshot"] = str(shot)
        return result

    # Wait for navigation back to index list.
    try:
        await page.wait_for_url(
            lambda u: u.endswith("/subscriptions") or u.endswith("/subscriptions/"),
            timeout=15_000,
        )
    except Exception:
        # Fall back to networkidle settle.
        try:
            await page.wait_for_load_state("networkidle", timeout=8_000)
        except Exception:
            pass
    await page.wait_for_timeout(1500)

    if await subscription_exists(page, name):
        result["status"] = "created"
    else:
        shot = await screenshot(page, f"subs-verify-fail-{int(time.time())}")
        result["status"] = "failed"
        result["screenshot"] = str(shot)
        result["error"] = "saved but did not appear on index"
    return result


async def run_dry_run(workspace: str, payload_path: Path, path: str | None):
    items = load_payload(payload_path)
    async with intercom_session(workspace, headed=True) as ctx:
        page = await ensure_logged_in(ctx, workspace)
        await go_to_page(page, workspace, path or DEFAULT_PATH)
        print(f"\n[dry-run] {len(items)} subscriptions in payload — checking each on the index")
        for s in items:
            exists = await subscription_exists(page, s["name"])
            verb = "SKIP (already exists)" if exists else "CREATE"
            print(f"  [{verb}] {s['name']!r}  msg={s['message_type']}  consent={s['consent_type']}")


async def run_create(workspace: str, payload_path: Path, path: str | None):
    items = load_payload(payload_path)
    print(f"[create] {len(items)} subscriptions in payload")
    summary = {"created": 0, "skipped": 0, "failed": 0, "error": 0, "details": []}

    async with intercom_session(workspace, headed=True) as ctx:
        page = await ensure_logged_in(ctx, workspace)
        await go_to_page(page, workspace, path or DEFAULT_PATH)

        for i, s in enumerate(items, 1):
            print(f"\n[create] [{i}/{len(items)}] {s['name']!r}")
            try:
                result = await create_one_subscription(page, workspace, s)
            except Exception as e:
                shot = await screenshot(page, f"subs-uncaught-{int(time.time())}")
                result = {
                    "name": s["name"],
                    "status": "error",
                    "error": f"uncaught: {e}",
                    "screenshot": str(shot),
                }
            print(f"           → {result['status']}")
            if result.get("error"):
                print(f"           error: {result['error']}")
            if result.get("screenshot"):
                print(f"           screenshot: {result['screenshot']}")
            summary[result["status"]] = summary.get(result["status"], 0) + 1
            summary["details"].append(result)

            # Make sure we're back on the index for the next iteration.
            if not page.url.rstrip("/").endswith("subscriptions"):
                await go_to_page(page, workspace, path or DEFAULT_PATH)

    print("\n=== SUMMARY ===")
    print(f"  created: {summary['created']}")
    print(f"  skipped: {summary['skipped']}")
    print(f"  failed:  {summary['failed']}")
    print(f"  error:   {summary['error']}")
    if summary["failed"] or summary["error"]:
        print("\n  Problem details:")
        for d in summary["details"]:
            if d["status"] in ("failed", "error"):
                print(f"    - {d['name']}: {d.get('error', '')}")


def main():
    ap = argparse.ArgumentParser(description="Manage Intercom subscription types via the admin UI.")
    ap.add_argument("--workspace", required=True, help="Workspace folder name under workspace/")
    mode = ap.add_mutually_exclusive_group(required=True)
    mode.add_argument("--probe", action="store_true", help="Probe the subscription types page.")
    mode.add_argument("--probe-create-form", action="store_true", help="Click 'New Subscription' and probe the form.")
    mode.add_argument("--dry-run", action="store_true", help="Parse payload and print which subscriptions would be created/skipped.")
    mode.add_argument("--create", action="store_true", help="Create subscriptions from --payload.")
    ap.add_argument("--path", help="Path under /a/apps/<app_id>. Defaults to the known subscriptions URL.")
    ap.add_argument("--payload", type=Path, help="YAML file with subscriptions to create")
    args = ap.parse_args()

    if args.probe:
        asyncio.run(run_probe(args.workspace, args.path))
    elif args.probe_create_form:
        asyncio.run(run_probe_create_form(args.workspace, args.path))
    elif args.dry_run:
        if not args.payload:
            ap.error("--dry-run requires --payload")
        asyncio.run(run_dry_run(args.workspace, args.payload, args.path))
    elif args.create:
        if not args.payload:
            ap.error("--create requires --payload")
        asyncio.run(run_create(args.workspace, args.payload, args.path))


if __name__ == "__main__":
    main()
