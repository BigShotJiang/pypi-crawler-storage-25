"""
Shared Playwright session helpers for Intercom UI automation.

These scripts drive the Intercom admin UI through a logged-in Chromium
session backed by a persistent profile directory. The profile is created
on first run; the user logs in once interactively and subsequent runs
reuse the cookies on disk.

NOTE: this code lives outside the MCP server surface. It is invoked
manually for migration tasks where the Intercom REST API has no
equivalent endpoint. See conversation in CLAUDE.md scope.
"""
from __future__ import annotations

import os
import sys
from contextlib import asynccontextmanager
from pathlib import Path

from playwright.async_api import (
    BrowserContext,
    Page,
    Playwright,
    TimeoutError as PWTimeoutError,
    async_playwright,
)

from forge import paths
from forge.license import ensure_licensed
from forge.mcp.shared import get_client

PROFILE_ROOT = paths.profiles_dir()
SCREENSHOT_ROOT = paths.screenshots_dir()
DEFAULT_TIMEOUT_MS = 15_000


def resolve_app_id(workspace: str) -> str:
    """Look up the Intercom app_id for a workspace via the REST API.

    The token comes from forge.json's intercom_token_env, same as every
    MCP tool. Returned id_code is what appears in the URL after
    /a/apps/<id>/.
    """
    client = get_client(workspace)
    me = client.get("/me")
    app_id = me.get("app", {}).get("id_code")
    if not app_id:
        raise RuntimeError(f"No app.id_code in /me response for workspace {workspace}")
    return app_id


def workspace_url(workspace: str, path: str = "") -> str:
    """Build a fully-qualified app.intercom.com URL for a workspace path."""
    app_id = resolve_app_id(workspace)
    base = f"https://app.intercom.com/a/apps/{app_id}"
    if path and not path.startswith("/"):
        path = "/" + path
    return base + path


@asynccontextmanager
async def intercom_session(
    workspace: str,
    *,
    headed: bool = True,
    slow_mo_ms: int = 0,
):
    """
    Open a persistent-profile Chromium context for the given workspace.

    First run will land on app.intercom.com unauthenticated — the script
    pauses with page.pause() so the user can log in interactively (incl.
    MFA). Subsequent runs skip that step because the cookies are on disk.

    Each workspace gets its own profile directory so credentials don't
    cross-contaminate.
    """
    # Gate UI automation too — running scripts directly via
    # `python -m forge.ui_automation.X` bypasses the MCP server gate,
    # so we re-check here. Cheap after first call in a process.
    ensure_licensed()

    profile_dir = PROFILE_ROOT / workspace
    profile_dir.mkdir(parents=True, exist_ok=True)
    SCREENSHOT_ROOT.mkdir(parents=True, exist_ok=True)

    async with async_playwright() as p:
        ctx = await p.chromium.launch_persistent_context(
            user_data_dir=str(profile_dir),
            headless=not headed,
            slow_mo=slow_mo_ms,
            viewport={"width": 1440, "height": 900},
        )
        ctx.set_default_timeout(DEFAULT_TIMEOUT_MS)
        try:
            yield ctx
        finally:
            await ctx.close()


async def ensure_logged_in(
    ctx: BrowserContext,
    workspace: str,
    *,
    login_timeout_ms: int = 10 * 60 * 1000,
) -> Page:
    """Open a page on the workspace home and confirm the session is live.

    Bulletproofing notes:
      * Intercom serves a transient HTML on the workspace URL even when
        unauthenticated, then JS-redirects to /login or to Google OAuth.
        domcontentloaded fires on the transient page, so we additionally
        wait for networkidle to let the redirect chain settle.
      * Once redirected away (off /apps/<app_id>/), we wait_for_url for
        the auth'd URL pattern to come back. This covers Google OAuth,
        SSO, MFA, device verification — any flow that ends with the user
        landing back inside the workspace.

    login_timeout_ms: how long to wait for the post-login URL. Default
        10 minutes — generous for SSO + MFA + device prompts.
    """
    import re

    app_id = resolve_app_id(workspace)
    auth_pattern = re.compile(rf"https://app\.intercom\.com/a/apps/{re.escape(app_id)}/.*")

    page = ctx.pages[0] if ctx.pages else await ctx.new_page()
    target = f"https://app.intercom.com/a/apps/{app_id}/home"
    await page.goto(target, wait_until="domcontentloaded")

    # Let any client-side redirect chain settle. networkidle waits for
    # ~500ms of no network activity; capped so we don't hang on pages
    # like Google OAuth that never go idle.
    try:
        await page.wait_for_load_state("networkidle", timeout=10_000)
    except PWTimeoutError:
        pass

    if auth_pattern.match(page.url):
        return page  # already authenticated

    print(
        f"\n[session] Not signed in (current URL: {page.url}).\n"
        f"[session] The browser is open — please log in to Intercom"
        f" workspace '{workspace}' (app_id={app_id}).\n"
        f"[session] Waiting up to {login_timeout_ms // 1000}s for the URL"
        f" to land back on /apps/{app_id}/ ...\n"
        f"[session] (If the browser is showing a Google sign-in or MFA"
        f" prompt, complete it. The script will resume automatically.)"
    )
    try:
        await page.wait_for_url(auth_pattern, timeout=login_timeout_ms)
    except PWTimeoutError as e:
        raise RuntimeError(
            f"Timed out after {login_timeout_ms // 1000}s waiting for login."
            f" Current URL: {page.url}. Your partial session is saved on"
            f" disk; re-running should pick up where you left off."
        ) from e

    # One more settle so the Ember app finishes booting before the
    # caller starts looking for selectors.
    try:
        await page.wait_for_load_state("networkidle", timeout=15_000)
    except PWTimeoutError:
        pass

    print(f"[session] Logged in. Current URL: {page.url}")
    return page


async def screenshot(page: Page, name: str) -> Path:
    """Save a screenshot under .screenshots/ for debugging selectors."""
    SCREENSHOT_ROOT.mkdir(parents=True, exist_ok=True)
    path = SCREENSHOT_ROOT / f"{name}.png"
    await page.screenshot(path=str(path), full_page=True)
    return path


async def safe_click(page: Page, locator, *, timeout_ms: int = DEFAULT_TIMEOUT_MS):
    """Click a locator with a clear error message on timeout."""
    try:
        await locator.wait_for(state="visible", timeout=timeout_ms)
        await locator.click()
    except PWTimeoutError as e:
        await screenshot(page, f"click-timeout-{int(__import__('time').time())}")
        raise RuntimeError(
            f"Timed out waiting for element to be clickable: {locator}. "
            f"Screenshot saved to {SCREENSHOT_ROOT}"
        ) from e
