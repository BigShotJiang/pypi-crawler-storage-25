"""
Create Intercom newsfeeds via the admin UI.

Read-only via API (only GET /news/newsfeeds exists). A newsfeed is a
named container that bundles news items for display in the Messenger.
"""
from __future__ import annotations

import argparse
import asyncio
import time
from pathlib import Path

import yaml

from forge.ui_automation.session import (
    ensure_logged_in,
    intercom_session,
    resolve_app_id,
    screenshot,
)

DEFAULT_PATH = "/settings/proactive-support/newsfeeds"


async def go_to_page(page, workspace: str, path: str):
    app_id = resolve_app_id(workspace)
    if not path.startswith("/"):
        path = "/" + path
    url = f"https://app.intercom.com/a/apps/{app_id}{path}"
    print(f"[newsfeeds] navigating to {url}")
    await page.goto(url, wait_until="domcontentloaded")
    try:
        await page.wait_for_load_state("networkidle", timeout=12_000)
    except Exception:
        pass
    await page.wait_for_timeout(800)


async def probe_page(page) -> dict:
    info: dict = {"url": page.url, "page_title": await page.title()}

    new_candidates = [
        ('role=button[name="New newsfeed"]', page.get_by_role("button", name="New newsfeed")),
        ('role=button[name="New Newsfeed"]', page.get_by_role("button", name="New Newsfeed")),
        ('role=button[name="Create newsfeed"]', page.get_by_role("button", name="Create newsfeed")),
        ('role=button[name="New"]', page.get_by_role("button", name="New").first),
    ]
    info["new_button_matches"] = []
    for label, loc in new_candidates:
        try:
            cnt = await loc.count()
            if cnt:
                info["new_button_matches"].append({
                    "selector": label,
                    "count": cnt,
                    "visible": await loc.first.is_visible(),
                })
        except Exception as e:
            info["new_button_matches"].append({"selector": label, "error": str(e)})

    try:
        all_buttons = await page.get_by_role("button").all_inner_texts()
        info["visible_buttons"] = [b.strip() for b in all_buttons if b.strip()][:60]
    except Exception as e:
        info["visible_buttons_error"] = str(e)

    try:
        headings = await page.locator("h1, h2, h3, h4, [role='heading']").all_inner_texts()
        info["headings"] = [h.strip() for h in headings if h.strip()][:30]
    except Exception as e:
        info["headings_error"] = str(e)

    return info


async def run_probe(workspace: str, path: str | None):
    async with intercom_session(workspace, headed=True) as ctx:
        page = await ensure_logged_in(ctx, workspace)
        await go_to_page(page, workspace, path or DEFAULT_PATH)
        info = await probe_page(page)
        shot = await screenshot(page, f"newsfeeds-index-{workspace}")

        print("\n=== NEWSFEEDS PROBE ===")
        print(f"URL:        {info['url']}")
        print(f"Page title: {info['page_title']}")
        print(f"Screenshot: {shot}")
        print("\nHeadings:")
        for h in info.get("headings", []):
            print(f"  - {h!r}")
        print("\nNew button candidates:")
        for m in info.get("new_button_matches", []):
            print(f"  - {m}")
        print("\nVisible buttons (first 60):")
        for b in info.get("visible_buttons", []):
            print(f"  - {b!r}")


async def run_probe_create_form(workspace: str, path: str | None):
    async with intercom_session(workspace, headed=True) as ctx:
        page = await ensure_logged_in(ctx, workspace)
        await go_to_page(page, workspace, path or DEFAULT_PATH)
        await screenshot(page, f"newsfeeds-before-new-{workspace}")

        for label in ("Create Newsfeed", "Create newsfeed", "New newsfeed", "New"):
            btn = page.get_by_role("button", name=label).first
            try:
                if await btn.count() and await btn.is_visible():
                    print(f"[newsfeeds] clicking {label!r}")
                    await btn.click()
                    break
            except Exception:
                continue
        else:
            raise RuntimeError("Could not find a Create Newsfeed button")

        try:
            await page.wait_for_load_state("networkidle", timeout=8_000)
        except Exception:
            pass
        await page.wait_for_timeout(1500)

        info: dict = {"url": page.url}
        try:
            headings = await page.locator("h1, h2, h3, h4, [role='heading']").all_inner_texts()
            info["headings"] = [h.strip() for h in headings if h.strip()][:30]
        except Exception as e:
            info["headings_error"] = str(e)
        try:
            inputs = page.locator("input, textarea")
            cnt = await inputs.count()
            info["input_count"] = cnt
            samples = []
            for i in range(min(cnt, 15)):
                el = inputs.nth(i)
                try:
                    samples.append({
                        "index": i,
                        "tag": await el.evaluate("el => el.tagName"),
                        "type": await el.get_attribute("type"),
                        "placeholder": await el.get_attribute("placeholder"),
                        "aria-label": await el.get_attribute("aria-label"),
                    })
                except Exception as e:
                    samples.append({"index": i, "error": str(e)})
            info["input_samples"] = samples
        except Exception as e:
            info["input_error"] = str(e)
        try:
            all_buttons = await page.get_by_role("button").all_inner_texts()
            info["visible_buttons"] = [b.strip() for b in all_buttons if b.strip()][:60]
        except Exception as e:
            info["visible_buttons_error"] = str(e)

        shot = await screenshot(page, f"newsfeeds-create-form-{workspace}")
        print("\n=== NEWSFEEDS CREATE-FORM PROBE ===")
        print(f"URL:        {info['url']}")
        print(f"Screenshot: {shot}")
        print(f"\nHeadings:")
        for h in info.get("headings", []):
            print(f"  - {h!r}")
        print(f"\nInput count: {info.get('input_count')}")
        for s in info.get("input_samples", []):
            print(f"  - {s}")
        print(f"\nButtons visible (first 60):")
        for b in info.get("visible_buttons", []):
            print(f"  - {b!r}")


# ────────────────────────────────────────────────────────────────────
# Create flow
# ────────────────────────────────────────────────────────────────────

NAME_INPUT = 'input[placeholder="Enter a name"]'


def load_payload(path: Path) -> list[dict]:
    data = yaml.safe_load(path.read_text())
    items = data.get("newsfeeds") if isinstance(data, dict) else None
    if not isinstance(items, list):
        raise SystemExit(f"YAML at {path} must have a top-level 'newsfeeds:' list")
    for i, n in enumerate(items):
        if not isinstance(n, dict) or "name" not in n:
            raise SystemExit(f"newsfeeds[{i}] missing required 'name'")
    return items


async def newsfeed_exists(page, name: str) -> bool:
    found = page.get_by_text(name, exact=True)
    try:
        return await found.count() > 0
    except Exception:
        return False


async def create_one_newsfeed(page, item: dict) -> dict:
    name = item["name"]
    result = {"name": name, "status": "unknown"}

    if await newsfeed_exists(page, name):
        result["status"] = "skipped"
        return result

    new_btn = page.get_by_role("button", name="Create Newsfeed").first
    await new_btn.wait_for(state="visible", timeout=10_000)
    await new_btn.click()

    name_input = page.locator(NAME_INPUT)
    await name_input.wait_for(state="visible", timeout=10_000)
    await name_input.fill(name)
    await page.wait_for_timeout(400)

    save_btn = page.get_by_role("button", name="Save and close").first
    await save_btn.wait_for(state="visible", timeout=10_000)
    try:
        await save_btn.click()
    except Exception as e:
        shot = await screenshot(page, f"newsfeeds-save-fail-{int(time.time())}")
        result["status"] = "error"
        result["error"] = f"save click failed: {e}"
        result["screenshot"] = str(shot)
        return result

    try:
        await page.wait_for_load_state("networkidle", timeout=8_000)
    except Exception:
        pass
    await page.wait_for_timeout(1500)

    if await newsfeed_exists(page, name):
        result["status"] = "created"
    else:
        shot = await screenshot(page, f"newsfeeds-verify-fail-{int(time.time())}")
        result["status"] = "failed"
        result["screenshot"] = str(shot)
        result["error"] = "saved but did not appear on index"
    return result


async def run_dry_run(workspace: str, payload_path: Path, path: str | None):
    items = load_payload(payload_path)
    async with intercom_session(workspace, headed=True) as ctx:
        page = await ensure_logged_in(ctx, workspace)
        await go_to_page(page, workspace, path or DEFAULT_PATH)
        print(f"\n[dry-run] {len(items)} newsfeeds in payload")
        for n in items:
            exists = await newsfeed_exists(page, n["name"])
            verb = "SKIP (already exists)" if exists else "CREATE"
            print(f"  [{verb}] {n['name']!r}")


async def run_create(workspace: str, payload_path: Path, path: str | None):
    items = load_payload(payload_path)
    print(f"[create] {len(items)} newsfeeds in payload")
    summary = {"created": 0, "skipped": 0, "failed": 0, "error": 0, "details": []}

    async with intercom_session(workspace, headed=True) as ctx:
        page = await ensure_logged_in(ctx, workspace)
        await go_to_page(page, workspace, path or DEFAULT_PATH)

        for i, n in enumerate(items, 1):
            print(f"\n[create] [{i}/{len(items)}] {n['name']!r}")
            try:
                result = await create_one_newsfeed(page, n)
            except Exception as e:
                shot = await screenshot(page, f"newsfeeds-uncaught-{int(time.time())}")
                result = {"name": n["name"], "status": "error", "error": f"uncaught: {e}", "screenshot": str(shot)}
            print(f"           → {result['status']}")
            if result.get("error"):
                print(f"           error: {result['error']}")
            if result.get("screenshot"):
                print(f"           screenshot: {result['screenshot']}")
            summary[result["status"]] = summary.get(result["status"], 0) + 1
            summary["details"].append(result)
            await go_to_page(page, workspace, path or DEFAULT_PATH)

    print("\n=== SUMMARY ===")
    print(f"  created: {summary['created']}")
    print(f"  skipped: {summary['skipped']}")
    print(f"  failed:  {summary['failed']}")
    print(f"  error:   {summary['error']}")


def main():
    ap = argparse.ArgumentParser(description="Manage Intercom newsfeeds via the admin UI.")
    ap.add_argument("--workspace", required=True, help="Workspace folder name under workspace/")
    mode = ap.add_mutually_exclusive_group(required=True)
    mode.add_argument("--probe", action="store_true", help="Probe the newsfeeds page.")
    mode.add_argument("--probe-create-form", action="store_true", help="Click Create Newsfeed and probe the form.")
    mode.add_argument("--dry-run", action="store_true", help="Parse payload and print which newsfeeds would be created/skipped.")
    mode.add_argument("--create", action="store_true", help="Create newsfeeds from --payload.")
    ap.add_argument("--path", help="Path under /a/apps/<app_id>. Defaults to known URL.")
    ap.add_argument("--payload", type=Path, help="YAML file with newsfeeds to create")
    args = ap.parse_args()

    if args.probe:
        asyncio.run(run_probe(args.workspace, args.path))
    elif args.probe_create_form:
        asyncio.run(run_probe_create_form(args.workspace, args.path))
    elif args.dry_run:
        if not args.payload:
            ap.error("--dry-run requires --payload")
        asyncio.run(run_dry_run(args.workspace, args.payload, args.path))
    elif args.create:
        if not args.payload:
            ap.error("--create requires --payload")
        asyncio.run(run_create(args.workspace, args.payload, args.path))


if __name__ == "__main__":
    main()
