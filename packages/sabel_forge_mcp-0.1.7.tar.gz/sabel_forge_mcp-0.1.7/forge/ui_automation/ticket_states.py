"""
Create Intercom ticket states via the admin UI.

Ticket states are read-only via REST (`list_ticket_states` exists but
no create/update/delete). The admin UI exposes them at
/settings/helpdesk/tickets?tab=ticket-states.

A ticket state has:
  - category:        one of submitted | in_progress | waiting_on_customer | resolved
                     (Intercom-internal taxonomy; new categories cannot be invented)
  - internal_label:  what teammates see
  - external_label:  what customers see (can differ from internal)
  - applies_to_ticket_type_ids: which ticket types this state appears on

Multiple states can share a category (e.g. two "submitted" states named
"Triage" and "Awaiting review").

Usage:
    # Probe the index (list of existing states)
    uv run python -m forge.ui_automation.ticket_states \\
        --workspace Migr8now_Workspace --probe

    # Probe the create form
    uv run python -m forge.ui_automation.ticket_states \\
        --workspace Migr8now_Workspace --probe-create-form

    # Dry run / create
    uv run python -m forge.ui_automation.ticket_states \\
        --workspace Migr8now_Workspace --dry-run \\
        --payload forge/ui_automation/ticket_states_payloads/example.yaml

    uv run python -m forge.ui_automation.ticket_states \\
        --workspace Migr8now_Workspace --create \\
        --payload forge/ui_automation/ticket_states_payloads/example.yaml

YAML schema:
    states:
      - internal_label: "Triage"
        external_label: "Received"
        category: submitted          # required: submitted | in_progress | waiting_on_customer | resolved
        applies_to_ticket_types:     # optional; either names or IDs
          - "Customer support"
          - "Refund request"
"""
from __future__ import annotations

import argparse
import asyncio
import time
from pathlib import Path

import yaml

from forge.ui_automation.session import (
    ensure_logged_in,
    intercom_session,
    resolve_app_id,
    screenshot,
)

INDEX_PATH = "/settings/helpdesk/tickets?tab=ticket-states"

VALID_CATEGORIES = {"submitted", "in_progress", "waiting_on_customer", "resolved"}

NEW_BUTTON_LABELS = [
    "New state",
    "New ticket state",
    "Add state",
    "Add ticket state",
    "Create state",
    "Create ticket state",
    "New",
    "Add",
    "Create",
]


# ────────────────────────────────────────────────────────────────────
# Payload model
# ────────────────────────────────────────────────────────────────────


def load_payload(path: Path) -> list[dict]:
    data = yaml.safe_load(path.read_text())
    items = data.get("states") if isinstance(data, dict) else None
    if not isinstance(items, list):
        raise SystemExit(f"YAML at {path} must have a top-level 'states:' list")
    for i, s in enumerate(items):
        if not isinstance(s, dict):
            raise SystemExit(f"states[{i}] must be a dict")
        if not s.get("internal_label"):
            raise SystemExit(f"states[{i}] missing required field 'internal_label'")
        cat = s.get("category")
        if cat not in VALID_CATEGORIES:
            raise SystemExit(
                f"states[{i}] has invalid category {cat!r}. "
                f"Must be one of {sorted(VALID_CATEGORIES)}"
            )
    return items


# ────────────────────────────────────────────────────────────────────
# Page nav + probes
# ────────────────────────────────────────────────────────────────────


async def go_to_index(page, workspace: str):
    app_id = resolve_app_id(workspace)
    url = f"https://app.intercom.com/a/apps/{app_id}{INDEX_PATH}"
    print(f"[ticket-states] navigating to {url}")
    await page.goto(url, wait_until="domcontentloaded")
    try:
        await page.wait_for_load_state("networkidle", timeout=12_000)
    except Exception:
        pass
    await page.wait_for_timeout(800)


async def click_new_button(page) -> str:
    for label in NEW_BUTTON_LABELS:
        loc = page.get_by_role("button", name=label).first
        try:
            if await loc.count() and await loc.is_visible():
                print(f"[ticket-states] clicking {label!r}")
                await loc.click()
                await page.wait_for_timeout(1500)
                try:
                    await page.wait_for_load_state("networkidle", timeout=6_000)
                except Exception:
                    pass
                return label
        except Exception:
            continue
    raise RuntimeError(
        f"Could not find a New/Add/Create button on {page.url}. Tried: {NEW_BUTTON_LABELS}."
    )


async def probe_page(page) -> dict:
    info: dict = {"url": page.url, "page_title": await page.title()}
    try:
        all_buttons = await page.get_by_role("button").all_inner_texts()
        info["visible_buttons"] = [b.strip() for b in all_buttons if b.strip()][:80]
    except Exception as e:
        info["visible_buttons_error"] = str(e)
    try:
        headings = await page.locator("h1, h2, h3, h4, [role='heading']").all_inner_texts()
        info["headings"] = [h.strip() for h in headings if h.strip()][:40]
    except Exception as e:
        info["headings_error"] = str(e)
    try:
        inputs = page.locator("input, textarea, select")
        descriptors = []
        for i in range(min(await inputs.count(), 30)):
            el = inputs.nth(i)
            descriptors.append({
                "tag": await el.evaluate("el => el.tagName"),
                "type": await el.get_attribute("type"),
                "placeholder": await el.get_attribute("placeholder"),
                "aria-label": await el.get_attribute("aria-label"),
                "name": await el.get_attribute("name"),
            })
        info["inputs"] = descriptors
    except Exception as e:
        info["inputs_error"] = str(e)
    return info


def _print_probe(title: str, info: dict, shot: Path):
    print(f"\n=== {title} ===")
    print(f"URL:        {info['url']}")
    print(f"Screenshot: {shot}")
    print("\nHeadings:")
    for h in info.get("headings", []):
        print(f"  - {h!r}")
    print("\nVisible buttons (first 80):")
    for b in info.get("visible_buttons", []):
        print(f"  - {b!r}")
    if info.get("inputs"):
        print("\nInputs (tag, type, placeholder, aria-label, name):")
        for inp in info["inputs"]:
            print(f"  - {inp}")
    if info.get("new_button_clicked"):
        print(f"\nNew-button label that worked: {info['new_button_clicked']!r}")


async def run_probe(workspace: str):
    async with intercom_session(workspace, headed=True) as ctx:
        page = await ensure_logged_in(ctx, workspace)
        await go_to_index(page, workspace)
        info = await probe_page(page)
        shot = await screenshot(page, f"ticket-states-index-{workspace}")
        _print_probe("TICKET STATES INDEX PROBE", info, shot)


async def run_probe_create_form(workspace: str):
    async with intercom_session(workspace, headed=True) as ctx:
        page = await ensure_logged_in(ctx, workspace)
        await go_to_index(page, workspace)
        label = await click_new_button(page)

        # Step 1: dropdown should be open with category choices.
        info = await probe_page(page)
        info["new_button_clicked"] = label
        shot = await screenshot(page, f"ticket-states-category-dropdown-{workspace}")
        _print_probe("STEP 1 — CATEGORY DROPDOWN", info, shot)

        # Step 2: pick a category and probe the actual form. Try "Submitted"
        # first — it's the most generic. Use multiple matchers since the
        # dropdown items may be option/menuitem/button/text-only.
        chosen_via = None
        for matcher_label, loc in (
            ("option(name=Submitted)", page.get_by_role("option", name="Submitted").first),
            ("menuitem(name=Submitted)", page.get_by_role("menuitem", name="Submitted").first),
            ("button(name=Submitted)", page.get_by_role("button", name="Submitted").first),
            ("text=Submitted last", page.get_by_text("Submitted", exact=True).last),
        ):
            try:
                if await loc.count() and await loc.is_visible():
                    print(f"\n[ticket-states] clicking category via {matcher_label}")
                    await loc.click()
                    await page.wait_for_timeout(1200)
                    chosen_via = matcher_label
                    break
            except Exception:
                continue
        if not chosen_via:
            print("\n[ticket-states] could not locate Submitted in the category dropdown")
            return

        info_form = await probe_page(page)
        info_form["category_chosen"] = "Submitted"
        info_form["matcher_that_worked"] = chosen_via
        shot_form = await screenshot(page, f"ticket-states-create-form-{workspace}")
        _print_probe("STEP 2 — CREATE FORM (category=Submitted)", info_form, shot_form)


# ────────────────────────────────────────────────────────────────────
# Existence + Create — final selectors will be locked in after probes.
# ────────────────────────────────────────────────────────────────────


async def state_exists(page, internal_label: str) -> bool:
    """Match by internal_label; exclude column headers (TH)."""
    try:
        elements = page.get_by_text(internal_label, exact=True)
        count = await elements.count()
        for i in range(count):
            try:
                tag = await elements.nth(i).evaluate("el => el.tagName")
                if tag and tag.upper() != "TH":
                    return True
            except Exception:
                continue
        return False
    except Exception:
        return False


CATEGORY_TO_DROPDOWN_ITEM = {
    "submitted": "Submitted",
    "in_progress": "In progress",
    "waiting_on_customer": "Waiting on customer",
    "resolved": "Resolved",
}


async def create_one_state(page, state: dict, workspace: str) -> dict:
    """Create a single ticket state via the two-step UI flow:

      1. Click "Create ticket state" → category dropdown opens.
      2. Click the matching category → side panel opens with form
         "Create {Category} state".
      3. Fill "Label visible internally" + "Label visible to your customers".
      4. Save.

    The form does NOT include ticket-type assignment — that's a separate
    UI affordance after creation. If/when the user needs that wired up,
    extend this with a phase-2 step.
    """
    name = state["internal_label"]
    external = state.get("external_label") or name
    category = state["category"]
    category_label = CATEGORY_TO_DROPDOWN_ITEM[category]

    result: dict = {"internal_label": name, "category": category, "status": "unknown"}
    if await state_exists(page, name):
        return {**result, "status": "skipped"}

    # 1. Open the category dropdown.
    try:
        await click_new_button(page)
    except Exception as e:
        shot = await screenshot(page, f"ticket-states-new-fail-{int(time.time())}")
        return {**result, "status": "error", "error": f"new-button: {e}", "screenshot": str(shot)}

    # 2. Click the matching category. Probe found role=menuitem works.
    try:
        opt = page.get_by_role("menuitem", name=category_label).first
        await opt.wait_for(state="visible", timeout=8_000)
        await opt.click()
        await page.wait_for_timeout(1200)
    except Exception as e:
        shot = await screenshot(page, f"ticket-states-cat-fail-{int(time.time())}")
        return {**result, "status": "error",
                "error": f"category={category_label!r}: {e}", "screenshot": str(shot)}

    # 3. Fill internal + external labels. Form has no name/placeholder/
    # aria attrs on the inputs, so we use the visible label text via
    # get_by_label. Fall back to positional input lookup if that fails.
    try:
        internal = page.get_by_label("Label visible internally").first
        await internal.wait_for(state="visible", timeout=8_000)
        await internal.fill(name)
    except Exception:
        try:
            # Fallback: the form mounts two empty text inputs (besides
            # the global search bar at top).
            inputs = page.locator(
                'input[type="text"]:not([placeholder="Search and navigate..."])'
            )
            await inputs.nth(0).fill(name)
        except Exception as e:
            shot = await screenshot(page, f"ticket-states-internal-fail-{int(time.time())}")
            return {**result, "status": "error",
                    "error": f"internal label: {e}", "screenshot": str(shot)}

    try:
        ext = page.get_by_label("Label visible to your customers").first
        await ext.fill(external)
    except Exception:
        try:
            inputs = page.locator(
                'input[type="text"]:not([placeholder="Search and navigate..."])'
            )
            await inputs.nth(1).fill(external)
        except Exception as e:
            shot = await screenshot(page, f"ticket-states-external-fail-{int(time.time())}")
            return {**result, "status": "error",
                    "error": f"external label: {e}", "screenshot": str(shot)}

    # 4. Save.
    try:
        save_btn = page.get_by_role("button", name="Save").first
        await save_btn.wait_for(state="visible", timeout=8_000)
        if not await save_btn.is_enabled():
            shot = await screenshot(page, f"ticket-states-save-disabled-{int(time.time())}")
            return {**result, "status": "error",
                    "error": "Save disabled — required field missing",
                    "screenshot": str(shot)}
        await save_btn.click()
        await page.wait_for_timeout(1500)
    except Exception as e:
        shot = await screenshot(page, f"ticket-states-save-fail-{int(time.time())}")
        return {**result, "status": "error", "error": f"save: {e}", "screenshot": str(shot)}

    # 5. Verify by re-checking presence on index.
    if "ticket-states" not in page.url:
        await go_to_index(page, workspace)
    if await state_exists(page, name):
        return {**result, "status": "created"}
    shot = await screenshot(page, f"ticket-states-verify-fail-{int(time.time())}")
    return {**result, "status": "failed",
            "error": "saved but did not appear on index",
            "screenshot": str(shot)}


# ────────────────────────────────────────────────────────────────────
# Driver modes
# ────────────────────────────────────────────────────────────────────


async def run_dry_run(workspace: str, payload_path: Path):
    items = load_payload(payload_path)
    print(f"\n[dry-run] {len(items)} states in payload — checking each on the index page")
    async with intercom_session(workspace, headed=True) as ctx:
        page = await ensure_logged_in(ctx, workspace)
        await go_to_index(page, workspace)
        for s in items:
            label = s["internal_label"]
            exists = await state_exists(page, label)
            verb = "SKIP (exists)" if exists else "CREATE"
            print(f"  [{verb}] {label!r}  category={s['category']}  external={s.get('external_label', label)!r}")
            tt = s.get("applies_to_ticket_types") or []
            if tt:
                print(f"           applies_to_ticket_types: {tt}")


async def run_create(workspace: str, payload_path: Path):
    items = load_payload(payload_path)
    print(f"[create] {len(items)} states in payload")
    summary = {"created": 0, "skipped": 0, "failed": 0, "error": 0, "details": []}
    async with intercom_session(workspace, headed=True) as ctx:
        page = await ensure_logged_in(ctx, workspace)
        await go_to_index(page, workspace)
        for i, s in enumerate(items, 1):
            print(f"\n[create] [{i}/{len(items)}] {s['internal_label']!r}  ({s['category']})")
            try:
                result = await create_one_state(page, s, workspace)
            except Exception as e:
                shot = await screenshot(page, f"ticket-states-uncaught-{int(time.time())}")
                result = {"internal_label": s["internal_label"], "status": "error",
                          "error": f"uncaught: {e}", "screenshot": str(shot)}
            print(f"           → {result['status']}")
            if result.get("error"):
                print(f"           error: {result['error']}")
            if result.get("screenshot"):
                print(f"           screenshot: {result['screenshot']}")
            summary[result["status"]] = summary.get(result["status"], 0) + 1
            summary["details"].append(result)
            await page.wait_for_timeout(800)
            if "ticket-states" not in page.url:
                await go_to_index(page, workspace)
    print("\n=== SUMMARY ===")
    print(f"  created: {summary['created']}")
    print(f"  skipped: {summary['skipped']}")
    print(f"  failed:  {summary['failed']}")
    print(f"  error:   {summary['error']}")
    if summary["failed"] or summary["error"]:
        print("\n  Problem details:")
        for d in summary["details"]:
            if d["status"] in ("failed", "error"):
                print(f"    - {d['internal_label']}: {d.get('error', '')}")


def main():
    ap = argparse.ArgumentParser(description="Manage Intercom ticket states via the admin UI.")
    ap.add_argument("--workspace", required=True, help="Workspace folder name under workspace/")
    mode = ap.add_mutually_exclusive_group(required=True)
    mode.add_argument("--probe", action="store_true", help="Probe the ticket-states tab.")
    mode.add_argument("--probe-create-form", action="store_true", help="Click New, dump the create form structure.")
    mode.add_argument("--dry-run", action="store_true", help="Parse payload, list which states would be created/skipped.")
    mode.add_argument("--create", action="store_true", help="Create states from --payload.")
    ap.add_argument("--payload", type=Path, help="YAML file with states to create. Required for --dry-run/--create.")
    args = ap.parse_args()

    if args.probe:
        asyncio.run(run_probe(args.workspace))
    elif args.probe_create_form:
        asyncio.run(run_probe_create_form(args.workspace))
    elif args.dry_run:
        if not args.payload:
            ap.error("--dry-run requires --payload")
        asyncio.run(run_dry_run(args.workspace, args.payload))
    elif args.create:
        if not args.payload:
            ap.error("--create requires --payload")
        asyncio.run(run_create(args.workspace, args.payload))


if __name__ == "__main__":
    main()
