"""
Workflow builder probe (Playwright).

Workflows have NO write API and the Fin SDK CLI is read-only (list / get
/ export). This script is the discovery step — we open the workflow
builder, capture what selectors / node types / templates exist, and use
that to decide whether automation is feasible at any tier:
  Tier 1: create empty named workflow
  Tier 2: create simple linear workflow
  Tier 3: replay an exported workflow JSON

Usage:
    uv run python -m forge.ui_automation.workflows \\
        --workspace Migr8now_Workspace --probe

    # Probe the builder canvas after clicking 'New workflow':
    uv run python -m forge.ui_automation.workflows \\
        --workspace Migr8now_Workspace --probe-builder
"""
from __future__ import annotations

import argparse
import asyncio
import time
from pathlib import Path

import yaml

from forge.ui_automation.session import (
    ensure_logged_in,
    intercom_session,
    resolve_app_id,
    screenshot,
)

# Intercom has used a few paths for workflows over the years. The
# canonical one (as of 2026) is /automation/workflows-overview; the
# others are kept as fallbacks in case it moves again.
WORKFLOW_PATH_CANDIDATES = [
    "/automation/workflows-overview",
    "/automation/workflows",
    "/workflows",
    "/operator/workflows",
]


async def find_workflows_page(page, workspace: str) -> str:
    """Try each known workflows path and return the first one that loads
    a workspace page (URL stays inside /a/apps/<id>/...)."""
    app_id = resolve_app_id(workspace)
    for path in WORKFLOW_PATH_CANDIDATES:
        url = f"https://app.intercom.com/a/apps/{app_id}{path}"
        print(f"[workflows] trying {url}")
        await page.goto(url, wait_until="domcontentloaded")
        try:
            await page.wait_for_load_state("networkidle", timeout=8_000)
        except Exception:
            pass
        # If we ended up on a 404 / redirected to /home, this path is wrong.
        if f"/apps/{app_id}/" in page.url and "home" not in page.url.split("/")[-1]:
            print(f"[workflows] landed on {page.url}")
            return path
    raise RuntimeError(
        "Could not find workflows page — none of the candidate paths"
        f" worked: {WORKFLOW_PATH_CANDIDATES}. The product may have moved"
        " or this workspace may not have workflows enabled."
    )


async def probe_index(page) -> dict:
    info: dict = {"url": page.url, "page_title": await page.title()}

    # Candidate buttons to enter the builder
    new_candidates = [
        ('role=button[name="New workflow"]', page.get_by_role("button", name="New workflow")),
        ('role=button[name="Create workflow"]', page.get_by_role("button", name="Create workflow")),
        ('role=button[name="New"]', page.get_by_role("button", name="New").first),
        ('role=link[name="New workflow"]', page.get_by_role("link", name="New workflow")),
        ('text="New workflow"', page.get_by_text("New workflow", exact=True).first),
    ]
    info["new_button_matches"] = []
    for label, loc in new_candidates:
        try:
            cnt = await loc.count()
            if cnt:
                info["new_button_matches"].append({
                    "selector": label,
                    "count": cnt,
                    "visible": await loc.first.is_visible(),
                })
        except Exception as e:
            info["new_button_matches"].append({"selector": label, "error": str(e)})

    try:
        all_buttons = await page.get_by_role("button").all_inner_texts()
        info["visible_buttons"] = [b.strip() for b in all_buttons if b.strip()][:60]
    except Exception as e:
        info["visible_buttons_error"] = str(e)

    try:
        all_links = await page.get_by_role("link").all_inner_texts()
        info["visible_links"] = [l.strip() for l in all_links if l.strip()][:30]
    except Exception as e:
        info["visible_links_error"] = str(e)

    # Are existing workflows visible? Try a few list/row patterns.
    try:
        rows = page.locator('[role="row"], [role="listitem"], [data-test-id*="workflow"]')
        texts = await rows.all_inner_texts()
        info["row_samples"] = [t.split("\n")[0][:80] for t in texts[:20] if t.strip()]
    except Exception as e:
        info["row_samples_error"] = str(e)

    return info


async def probe_builder(page) -> dict:
    """After clicking 'New workflow' (or first template option), capture
    what the builder canvas looks like."""
    info: dict = {"url": page.url}
    # Headings / titles in the builder
    try:
        headings = await page.locator("h1, h2, h3, [role='heading']").all_inner_texts()
        info["headings"] = [h.strip() for h in headings if h.strip()][:30]
    except Exception as e:
        info["headings_error"] = str(e)

    # Any text suggesting templates (Tier 1 vs Tier 3 feasibility)
    try:
        page_text = await page.locator("body").inner_text()
        info["page_text_first_500"] = page_text[:500]
        info["mentions_template"] = "template" in page_text.lower()
        info["mentions_blank"] = "blank" in page_text.lower() or "from scratch" in page_text.lower()
    except Exception as e:
        info["page_text_error"] = str(e)

    # Buttons present in the builder
    try:
        all_buttons = await page.get_by_role("button").all_inner_texts()
        info["visible_buttons"] = [b.strip() for b in all_buttons if b.strip()][:80]
    except Exception as e:
        info["visible_buttons_error"] = str(e)

    # Look for canvas-ish elements
    try:
        info["svg_count"] = await page.locator("svg").count()
        info["canvas_count"] = await page.locator("canvas").count()
        info["draggable_count"] = await page.locator('[draggable="true"]').count()
    except Exception as e:
        info["canvas_error"] = str(e)

    return info


async def run_probe(workspace: str):
    async with intercom_session(workspace, headed=True) as ctx:
        page = await ensure_logged_in(ctx, workspace)
        await find_workflows_page(page, workspace)
        info = await probe_index(page)
        shot = await screenshot(page, f"workflows-index-{workspace}")

        print("\n=== WORKFLOWS INDEX PROBE ===")
        print(f"URL:        {info['url']}")
        print(f"Page title: {info['page_title']}")
        print(f"Screenshot: {shot}")
        print("\nNew-button selector candidates:")
        for m in info.get("new_button_matches", []):
            print(f"  - {m}")
        print("\nVisible buttons (first 60):")
        for b in info.get("visible_buttons", []):
            print(f"  - {b!r}")
        print("\nVisible links (first 30):")
        for l in info.get("visible_links", []):
            print(f"  - {l!r}")
        print("\nRow samples (first 20):")
        for r in info.get("row_samples", []):
            print(f"  - {r!r}")


async def run_probe_builder(workspace: str):
    async with intercom_session(workspace, headed=True) as ctx:
        page = await ensure_logged_in(ctx, workspace)
        await find_workflows_page(page, workspace)

        # Step 1: open the 'New workflow' dropdown.
        new_btn = page.get_by_role("button", name="New workflow").first
        if not (await new_btn.count() and await new_btn.is_visible()):
            print("[workflows] no 'New workflow' button found — aborting")
            return
        print("[workflows] clicking 'New workflow' (opens dropdown)")
        await new_btn.click()
        await page.wait_for_timeout(600)
        await screenshot(page, f"workflows-builder-dropdown-{workspace}")

        # Step 2: click 'Create from scratch' in the dropdown.
        scratch = page.get_by_role("button", name="Create from scratch").first
        if not await scratch.count():
            # Sometimes dropdown items are role=menuitem, not role=button.
            scratch = page.get_by_role("menuitem", name="Create from scratch").first
        if not await scratch.count():
            scratch = page.get_by_text("Create from scratch", exact=True).first
        try:
            await scratch.wait_for(state="visible", timeout=5_000)
            print("[workflows] clicking 'Create from scratch'")
            await scratch.click()
        except Exception as e:
            print(f"[workflows] couldn't click 'Create from scratch': {e}")
            print("[workflows] capturing whatever state we ended up in")

        # Let the builder mount. URL should change.
        try:
            await page.wait_for_load_state("networkidle", timeout=15_000)
        except Exception:
            pass
        await page.wait_for_timeout(2000)

        info = await probe_builder(page)
        shot = await screenshot(page, f"workflows-builder-{workspace}")

        print("\n=== WORKFLOWS BUILDER PROBE ===")
        print(f"URL:        {info['url']}")
        print(f"Screenshot: {shot}")
        print(f"\nHeadings on page:")
        for h in info.get("headings", []):
            print(f"  - {h!r}")
        print(f"\nMentions of 'template': {info.get('mentions_template')}")
        print(f"Mentions of 'blank' or 'from scratch': {info.get('mentions_blank')}")
        print(f"\nFirst 500 chars of page text:")
        print(f"  {info.get('page_text_first_500', '')!r}")
        print(f"\nCanvas elements: svg={info.get('svg_count')} canvas={info.get('canvas_count')} draggable={info.get('draggable_count')}")
        print("\nButtons visible in builder (first 80):")
        for b in info.get("visible_buttons", []):
            print(f"  - {b!r}")


async def run_probe_canvas(workspace: str, trigger_name: str):
    """Pick a trigger from the 'Create from scratch' modal and inspect
    the resulting builder canvas. Captures: URL, headings, all visible
    buttons, count of nodes / + buttons / SVG elements. No save."""
    async with intercom_session(workspace, headed=True) as ctx:
        page = await ensure_logged_in(ctx, workspace)
        await find_workflows_page(page, workspace)

        # Open the trigger picker
        await page.get_by_role("button", name="New workflow").first.click()
        await page.wait_for_timeout(500)
        scratch = page.get_by_text("Create from scratch", exact=True).first
        await scratch.wait_for(state="visible", timeout=5_000)
        await scratch.click()
        await page.wait_for_timeout(1500)
        await screenshot(page, f"workflows-trigger-picker-{workspace}")

        # Pick the requested trigger by exact text.
        print(f"[workflows] picking trigger: {trigger_name!r}")
        trigger = page.get_by_text(trigger_name, exact=True).first
        await trigger.wait_for(state="visible", timeout=8_000)
        await trigger.click()

        # Wait for the builder to actually finish loading. We try a few
        # signals in parallel — whichever appears first wins:
        #   * URL changes off /workflows-overview
        #   * A 'Save' or 'Publish' or 'Set live' button appears
        #   * A react-flow / canvas node appears
        print("[workflows] waiting for builder to mount (up to 30s)...")
        try:
            await page.wait_for_function(
                """() => {
                    if (!location.href.includes('workflows-overview')) return true;
                    const btns = [...document.querySelectorAll('button')]
                        .map(b => (b.innerText || '').trim().toLowerCase());
                    if (btns.some(t => ['save', 'publish', 'set live', 'set as live'].includes(t))) return true;
                    if (document.querySelector('.react-flow__node')) return true;
                    if (document.querySelector('[data-test-id*="workflow-editor"]')) return true;
                    return false;
                }""",
                timeout=30_000,
            )
            print(f"[workflows] builder mounted. URL now: {page.url}")
        except Exception as e:
            print(f"[workflows] timed out waiting for builder ({e}) — capturing whatever state we got")
        # Tiny additional settle for any deferred render.
        await page.wait_for_timeout(1500)

        info: dict = {"url": page.url}

        # Headings (workflow name field is often the H1)
        try:
            headings = await page.locator("h1, h2, h3, [role='heading']").all_inner_texts()
            info["headings"] = [h.strip() for h in headings if h.strip()][:30]
        except Exception as e:
            info["headings_error"] = str(e)

        # All buttons + their text — this is where Save / Add step / etc. live
        try:
            all_buttons = await page.get_by_role("button").all_inner_texts()
            info["visible_buttons"] = [b.strip() for b in all_buttons if b.strip()][:120]
        except Exception as e:
            info["visible_buttons_error"] = str(e)

        # Look for nodes (react-flow uses .react-flow__node, others use [data-id])
        try:
            for sel in [
                ".react-flow__node",
                "[data-id]",
                "[data-test-id*='node']",
                "[data-test-id*='step']",
                "[data-test-id*='block']",
            ]:
                cnt = await page.locator(sel).count()
                if cnt:
                    info.setdefault("node_selectors", []).append({"selector": sel, "count": cnt})
        except Exception as e:
            info["node_error"] = str(e)

        # Look for "+" / "Add" affordances
        try:
            add_buttons = page.get_by_role("button", name=lambda n: n and ("add" in n.lower() or n.strip() == "+"))
            info["add_button_count"] = await add_buttons.count()
            info["add_button_samples"] = (await add_buttons.all_inner_texts())[:10]
        except Exception as e:
            info["add_button_error"] = str(e)

        # Workflow name field — often a contenteditable or top input
        try:
            info["contenteditable_count"] = await page.locator('[contenteditable="true"]').count()
            inputs = page.locator("input[type='text'], input:not([type])")
            info["text_input_count"] = await inputs.count()
            info["text_input_placeholders"] = []
            for i in range(min(await inputs.count(), 10)):
                ph = await inputs.nth(i).get_attribute("placeholder")
                al = await inputs.nth(i).get_attribute("aria-label")
                info["text_input_placeholders"].append({"placeholder": ph, "aria-label": al})
        except Exception as e:
            info["input_error"] = str(e)

        info["svg_count"] = await page.locator("svg").count()
        info["canvas_count"] = await page.locator("canvas").count()

        shot = await screenshot(page, f"workflows-canvas-{workspace}")

        print("\n=== BUILDER CANVAS PROBE ===")
        print(f"URL:        {info['url']}")
        print(f"Screenshot: {shot}")
        print(f"\nHeadings:")
        for h in info.get("headings", []):
            print(f"  - {h!r}")
        print(f"\nNode-selector matches:")
        for n in info.get("node_selectors", []):
            print(f"  - {n}")
        print(f"\nAdd-button count: {info.get('add_button_count')}")
        for s in info.get("add_button_samples", []):
            print(f"  - {s!r}")
        print(f"\nText inputs ({info.get('text_input_count')}):")
        for ph in info.get("text_input_placeholders", []):
            print(f"  - {ph}")
        print(f"\ncontenteditable count: {info.get('contenteditable_count')}")
        print(f"svg / canvas: {info.get('svg_count')} / {info.get('canvas_count')}")
        print(f"\nButtons visible (first 120):")
        for b in info.get("visible_buttons", []):
            print(f"  - {b!r}")
        print(
            "\nNOTE: a draft workflow may now exist with name 'Untitled'"
            " or similar. You'll want to delete it manually after the probe."
        )


async def _open_blank_builder(page, workspace: str, trigger_name: str):
    """Shared helper: click through New workflow → Create from scratch
    → trigger, and wait for the builder to mount. Returns when the
    builder URL has changed off /workflows-overview."""
    await find_workflows_page(page, workspace)
    await page.get_by_role("button", name="New workflow").first.click()
    await page.wait_for_timeout(500)
    scratch = page.get_by_text("Create from scratch", exact=True).first
    await scratch.wait_for(state="visible", timeout=5_000)
    await scratch.click()
    await page.wait_for_timeout(1500)

    print(f"[workflows] picking trigger: {trigger_name!r}")
    trigger = page.get_by_text(trigger_name, exact=True).first
    await trigger.wait_for(state="visible", timeout=8_000)
    await trigger.click()

    print("[workflows] waiting for builder to mount (up to 30s)...")
    await page.wait_for_function(
        """() => {
            if (!location.href.includes('workflows-overview')) return true;
            const btns = [...document.querySelectorAll('button')]
                .map(b => (b.innerText || '').trim().toLowerCase());
            return btns.some(t => ['save', 'publish', 'set live'].includes(t));
        }""",
        timeout=30_000,
    )
    await page.wait_for_timeout(1500)
    print(f"[workflows] builder URL: {page.url}")


async def run_probe_add_step(workspace: str, trigger_name: str):
    """Open the builder, click 'Add step', and capture the action picker.

    The 'Add step' picker is the unified entry to every action / tool
    Intercom supports inside a workflow. Capturing its DOM tells us
    exactly which action types we can target for Tier 2 builds.
    """
    async with intercom_session(workspace, headed=True) as ctx:
        page = await ensure_logged_in(ctx, workspace)
        await _open_blank_builder(page, workspace, trigger_name)

        await screenshot(page, f"workflows-before-addstep-{workspace}")

        # The trigger config drawer mounts on the right with a blanket
        # that intercepts pointer events on the canvas. We need to
        # dismiss it before we can click 'Add step'.
        for label in ("Done", "Close"):
            btn = page.get_by_role("button", name=label).first
            try:
                if await btn.count() and await btn.is_visible():
                    print(f"[workflows] dismissing trigger drawer via '{label}'")
                    await btn.click()
                    await page.wait_for_timeout(800)
                    break
            except Exception:
                continue
        # Belt-and-braces: also press Escape in case the drawer ignores Done.
        await page.keyboard.press("Escape")
        await page.wait_for_timeout(400)

        # 'Add step' appears multiple times. Intercom auto-seeds a
        # Welcome message node which has its own 'Add step' for sub-
        # steps inside the message. The one we actually want is the
        # LAST 'Add step' on the canvas — the dashed "Or continue this
        # workflow here..." placeholder, which extends the workflow
        # with a real next action.
        all_add_steps = page.get_by_role("button", name="Add step")
        n = await all_add_steps.count()
        print(f"[workflows] {n} 'Add step' button(s) on canvas; clicking the last one")
        add_step = all_add_steps.last
        await add_step.wait_for(state="visible", timeout=10_000)
        # Scroll into view defensively — the dashed placeholder is to
        # the right of the canvas and may need panning.
        await add_step.scroll_into_view_if_needed()
        await add_step.click()

        # Picker mounts. Some pickers are sidebars, some are modals.
        # Wait briefly, then look for the new content.
        try:
            await page.wait_for_load_state("networkidle", timeout=8_000)
        except Exception:
            pass
        await page.wait_for_timeout(1500)

        # Expand the full catalog by clicking 'View more'.
        view_more = page.get_by_role("button", name="View more").first
        try:
            if await view_more.count() and await view_more.is_visible():
                print("[workflows] expanding full catalog via 'View more'")
                await view_more.click()
                await page.wait_for_timeout(800)
        except Exception as e:
            print(f"[workflows] couldn't click 'View more': {e}")

        info: dict = {"url": page.url}

        # Walk the picker popover DOM to find all clickable action items.
        # We locate the popover by anchoring on the 'Search' input that
        # only exists inside it, then walking up to the popover root and
        # back down to enumerate clickable children.
        try:
            items = await page.evaluate(
                """() => {
                    // Find the search input that anchors the popover.
                    const search = document.querySelector('input[placeholder="Search"]');
                    if (!search) return {error: 'no search input'};
                    // Walk up to find the popover root (some scrollable container).
                    let root = search;
                    for (let i = 0; i < 8; i++) {
                        if (root.scrollHeight > root.clientHeight && root.clientHeight > 200) break;
                        if (!root.parentElement) break;
                        root = root.parentElement;
                    }
                    // Enumerate descendants that look clickable: have a
                    // pointer cursor OR have a role=button OR are a li/a.
                    const out = [];
                    const walker = document.createTreeWalker(root, NodeFilter.SHOW_ELEMENT);
                    let node;
                    while (node = walker.nextNode()) {
                        const cs = window.getComputedStyle(node);
                        const isClickable = cs.cursor === 'pointer' ||
                                          node.getAttribute('role') === 'button' ||
                                          node.tagName === 'A' ||
                                          node.tagName === 'LI' ||
                                          node.onclick !== null;
                        if (!isClickable) continue;
                        const text = (node.innerText || '').trim();
                        if (!text || text.length > 80) continue;
                        // Skip nested duplicates: only include if this
                        // node has no clickable parent inside the root.
                        let parent = node.parentElement;
                        let nestedInClickable = false;
                        while (parent && parent !== root) {
                            const pcs = window.getComputedStyle(parent);
                            if (pcs.cursor === 'pointer' || parent.getAttribute('role') === 'button') {
                                nestedInClickable = true;
                                break;
                            }
                            parent = parent.parentElement;
                        }
                        if (nestedInClickable) continue;
                        out.push({tag: node.tagName, role: node.getAttribute('role'), text: text.split('\\n')[0].slice(0, 60)});
                    }
                    return {root_tag: root.tagName, root_size: {w: root.clientWidth, h: root.clientHeight}, items: out};
                }"""
            )
            info["picker_items"] = items
        except Exception as e:
            info["picker_walk_error"] = str(e)

        # Also capture all input placeholders (Search confirms picker is open).
        try:
            inputs = page.locator("input[type='text'], input:not([type])")
            placeholders = []
            for i in range(min(await inputs.count(), 10)):
                ph = await inputs.nth(i).get_attribute("placeholder")
                if ph:
                    placeholders.append(ph)
            info["input_placeholders"] = placeholders
        except Exception as e:
            info["input_error"] = str(e)

        shot = await screenshot(page, f"workflows-addstep-picker-{workspace}")

        print("\n=== ADD-STEP PICKER PROBE ===")
        print(f"URL:        {info['url']}")
        print(f"Screenshot: {shot}")
        print(f"\nInput placeholders on page:")
        for p in info.get("input_placeholders", []):
            print(f"  - {p!r}")
        picker = info.get("picker_items", {})
        if picker.get("error"):
            print(f"\nPicker walk error: {picker['error']}")
        else:
            print(f"\nPicker root: <{picker.get('root_tag')}> {picker.get('root_size')}")
            items = picker.get("items", [])
            print(f"Clickable items found in picker: {len(items)}")
            for it in items:
                print(f"  - <{it['tag']}> role={it['role']}  text={it['text']!r}")
        print(
            "\nNOTE: another draft workflow now exists. Delete via UI."
            " (You can also re-run with --probe-add-step many times — each"
            " creates a fresh untitled draft we never save.)"
        )


# ────────────────────────────────────────────────────────────────────
# Tier 1.5 — create draft workflow with trigger + name
#
# KNOWN LIMITATION: triggers that auto-place a Welcome node (notably
# "When customer opens a new conversation in the Messenger") have a
# race between the title-input fill and the auto-Welcome render. The
# title commit is sometimes lost and the workflow saves as "Untitled"
# despite the verify-and-retry logic in _set_workflow_name. Triggers
# that don't auto-place a node ("When customer sends their first
# message", etc.) work cleanly.
# ────────────────────────────────────────────────────────────────────

WORKFLOW_NAME_INPUT = 'input[placeholder="Untitled"]'


def load_workflow_payload(path: Path) -> list[dict]:
    data = yaml.safe_load(path.read_text())
    items = data.get("workflows") if isinstance(data, dict) else None
    if not isinstance(items, list):
        raise SystemExit(f"YAML at {path} must have a top-level 'workflows:' list")
    for i, w in enumerate(items):
        if not isinstance(w, dict) or "name" not in w or "trigger" not in w:
            raise SystemExit(f"workflows[{i}] missing required fields 'name' and 'trigger'")
    return items


async def _go_to_index(page, workspace: str):
    """Navigate to the workflows-overview index. Used for both
    idempotency checks and as the starting point for each create."""
    app_id = resolve_app_id(workspace)
    url = f"https://app.intercom.com/a/apps/{app_id}/automation/workflows-overview"
    await page.goto(url, wait_until="domcontentloaded")
    try:
        await page.wait_for_load_state("networkidle", timeout=15_000)
    except Exception:
        pass
    # The list is lazy-rendered; give it more time to populate so a
    # just-saved workflow shows up under its name.
    await page.wait_for_timeout(2000)


async def _workflow_exists(page, name: str) -> bool:
    """Return True iff a workflow with this exact name appears on the
    workflows-overview page. Caller must have navigated to /overview
    first (we don't, to keep this cheap inside the create loop)."""
    found = page.get_by_text(name, exact=True)
    try:
        return await found.count() > 0
    except Exception:
        return False


async def _enter_blank_builder_with_trigger(page, trigger_name: str):
    """From the workflows-overview page: click 'New workflow' →
    'Create from scratch' → pick trigger → wait for builder to mount."""
    await page.get_by_role("button", name="New workflow").first.click()
    await page.wait_for_timeout(500)
    scratch = page.get_by_text("Create from scratch", exact=True).first
    await scratch.wait_for(state="visible", timeout=5_000)
    await scratch.click()
    await page.wait_for_timeout(1500)

    trigger = page.get_by_text(trigger_name, exact=True).first
    await trigger.wait_for(state="visible", timeout=8_000)
    await trigger.click()

    # Builder is heavy — wait until either URL changes off /overview or a
    # Save / Set live button shows up.
    await page.wait_for_function(
        """() => {
            if (!location.href.includes('workflows-overview')) return true;
            const btns = [...document.querySelectorAll('button')]
                .map(b => (b.innerText || '').trim().toLowerCase());
            return btns.some(t => ['save', 'publish', 'set live'].includes(t));
        }""",
        timeout=30_000,
    )
    await page.wait_for_timeout(1500)


async def _dismiss_trigger_drawer(page):
    """The trigger config drawer mounts on the right with a blanket that
    intercepts clicks on the canvas. Close it before doing anything
    else in the builder."""
    for label in ("Done", "Close"):
        btn = page.get_by_role("button", name=label).first
        try:
            if await btn.count() and await btn.is_visible():
                await btn.click()
                await page.wait_for_timeout(600)
                return
        except Exception:
            continue
    # Fallback: Escape key.
    await page.keyboard.press("Escape")
    await page.wait_for_timeout(400)


async def _set_workflow_name(page, name: str):
    """Fill the workflow title input at the top of the builder.

    For triggers that auto-place a Welcome node (e.g. Messenger), the
    builder is busy mounting that node when we get here. We:
      1. Triple-click to select any default content
      2. Fill our name
      3. Blur via Tab
      4. Re-read the input value and verify it matches; if not, retry
    """
    title = page.locator(WORKFLOW_NAME_INPUT)
    await title.wait_for(state="visible", timeout=10_000)
    for attempt in range(3):
        try:
            await title.click(click_count=3)  # select all existing
            await page.wait_for_timeout(150)
            await title.fill(name)
            await page.keyboard.press("Tab")
            await page.wait_for_timeout(800)  # let any debounced save fire
        except Exception as e:
            print(f"[workflow] title fill attempt {attempt + 1} error: {e}")
            continue
        # Verify
        actual = await title.input_value()
        if actual == name:
            return
        print(f"[workflow] title verify mismatch (got {actual!r}, want {name!r}) — retrying")
        await page.wait_for_timeout(500)
    raise RuntimeError(f"Could not set workflow name to {name!r} after 3 attempts")


async def _save_workflow(page) -> bool:
    """Click Save and wait for the action to complete."""
    save_btn = page.get_by_role("button", name="Save").first
    await save_btn.wait_for(state="visible", timeout=10_000)
    try:
        await save_btn.click()
    except Exception as e:
        print(f"[workflow] Save click error: {e}")
        return False
    # Save can take a few seconds when the workflow has auto-placed nodes.
    # Wait for networkidle so any save POST + index update settles.
    try:
        await page.wait_for_load_state("networkidle", timeout=10_000)
    except Exception:
        pass
    await page.wait_for_timeout(2000)
    return True


async def create_one_workflow(page, workspace: str, name: str, trigger: str) -> dict:
    """Create one workflow end-to-end. Returns a result dict.

    Flow:
      1. Navigate to /workflows-overview
      2. Idempotency: skip if name already exists
      3. Click through to a blank builder with the chosen trigger
      4. Dismiss the trigger config drawer
      5. Set the workflow name
      6. Save as draft
      7. Verify by navigating back to /overview and checking the name appears
    """
    result = {"name": name, "trigger": trigger, "status": "unknown"}

    await _go_to_index(page, workspace)
    if await _workflow_exists(page, name):
        result["status"] = "skipped"
        return result

    try:
        await _enter_blank_builder_with_trigger(page, trigger)
    except Exception as e:
        shot = await screenshot(page, f"workflow-trigger-fail-{int(time.time())}")
        result["status"] = "error"
        result["error"] = f"trigger select failed: {e}"
        result["screenshot"] = str(shot)
        return result

    try:
        await _dismiss_trigger_drawer(page)
        await _set_workflow_name(page, name)
        ok = await _save_workflow(page)
        if not ok:
            shot = await screenshot(page, f"workflow-save-fail-{int(time.time())}")
            result["status"] = "failed"
            result["screenshot"] = str(shot)
            return result
    except Exception as e:
        shot = await screenshot(page, f"workflow-build-fail-{int(time.time())}")
        result["status"] = "error"
        result["error"] = f"build failed: {e}"
        result["screenshot"] = str(shot)
        return result

    # Verify by going back to the index. The workflow we just saved
    # should appear by name.
    await _go_to_index(page, workspace)
    if await _workflow_exists(page, name):
        result["status"] = "created"
    else:
        shot = await screenshot(page, f"workflow-verify-fail-{int(time.time())}")
        result["status"] = "failed"
        result["screenshot"] = str(shot)
        result["error"] = "saved but did not appear on index after navigation"
    return result


async def run_dry_run(workspace: str, payload_path: Path):
    items = load_workflow_payload(payload_path)
    async with intercom_session(workspace, headed=True) as ctx:
        page = await ensure_logged_in(ctx, workspace)
        await _go_to_index(page, workspace)
        print(f"\n[dry-run] {len(items)} workflows in payload — checking each by name on index")
        for w in items:
            exists = await _workflow_exists(page, w["name"])
            verb = "SKIP (already exists)" if exists else "CREATE"
            print(f"  [{verb}] {w['name']!r}  trigger={w['trigger']!r}")


async def run_create(workspace: str, payload_path: Path):
    items = load_workflow_payload(payload_path)
    print(f"[create] {len(items)} workflows in payload")
    summary = {"created": 0, "skipped": 0, "failed": 0, "error": 0, "details": []}

    async with intercom_session(workspace, headed=True) as ctx:
        page = await ensure_logged_in(ctx, workspace)

        for i, w in enumerate(items, 1):
            name = w["name"]
            trigger = w["trigger"]
            print(f"\n[create] [{i}/{len(items)}] {name!r}")
            print(f"           trigger: {trigger!r}")
            try:
                result = await create_one_workflow(page, workspace, name, trigger)
            except Exception as e:
                shot = await screenshot(page, f"workflow-uncaught-{int(time.time())}")
                result = {
                    "name": name,
                    "trigger": trigger,
                    "status": "error",
                    "error": f"uncaught: {e}",
                    "screenshot": str(shot),
                }
            print(f"           → {result['status']}")
            if result.get("error"):
                print(f"           error: {result['error']}")
            if result.get("screenshot"):
                print(f"           screenshot: {result['screenshot']}")
            summary[result["status"]] = summary.get(result["status"], 0) + 1
            summary["details"].append(result)

    print("\n=== SUMMARY ===")
    print(f"  created: {summary['created']}")
    print(f"  skipped: {summary['skipped']}")
    print(f"  failed:  {summary['failed']}")
    print(f"  error:   {summary['error']}")
    if summary["failed"] or summary["error"]:
        print("\n  Problem details:")
        for d in summary["details"]:
            if d["status"] in ("failed", "error"):
                print(f"    - {d['name']}: {d.get('error', '')}  {d.get('screenshot', '')}")


def main():
    ap = argparse.ArgumentParser(description="Probe Intercom workflow builder UI.")
    ap.add_argument("--workspace", required=True, help="Workspace folder name under workspace/")
    mode = ap.add_mutually_exclusive_group(required=True)
    mode.add_argument("--probe", action="store_true", help="Probe the workflows index page (list view).")
    mode.add_argument("--probe-builder", action="store_true", help="Click 'New workflow' → 'Create from scratch' and probe the trigger picker.")
    mode.add_argument("--probe-canvas", action="store_true", help="Pick a trigger and probe the resulting builder canvas. Requires --trigger.")
    mode.add_argument("--probe-add-step", action="store_true", help="Open builder, click 'Add step', and probe the action picker.")
    mode.add_argument("--dry-run", action="store_true", help="Parse payload and print which workflows would be created/skipped. Reads index but no writes.")
    mode.add_argument("--create", action="store_true", help="Create the workflows from --payload (Tier 1.5 — name + trigger + save as draft).")
    ap.add_argument("--trigger", help="Trigger name (exact text) for --probe-canvas / --probe-add-step.",
                    default="When customer opens a new conversation in the Messenger")
    ap.add_argument("--payload", type=Path, help="YAML file with workflows to create")
    args = ap.parse_args()

    if args.probe:
        asyncio.run(run_probe(args.workspace))
    elif args.probe_builder:
        asyncio.run(run_probe_builder(args.workspace))
    elif args.probe_canvas:
        asyncio.run(run_probe_canvas(args.workspace, args.trigger))
    elif args.probe_add_step:
        asyncio.run(run_probe_add_step(args.workspace, args.trigger))
    elif args.dry_run:
        if not args.payload:
            ap.error("--dry-run requires --payload")
        asyncio.run(run_dry_run(args.workspace, args.payload))
    elif args.create:
        if not args.payload:
            ap.error("--create requires --payload")
        asyncio.run(run_create(args.workspace, args.payload))


if __name__ == "__main__":
    main()
