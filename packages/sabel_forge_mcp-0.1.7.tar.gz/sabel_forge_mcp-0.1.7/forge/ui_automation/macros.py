"""
Create Intercom macros via the admin UI (Playwright).

Why this exists: Intercom's REST API is read-only for macros. The
intercom employee response on the community forum (Jan 2023)
confirms there are no plans for a write API. For migrations that
need to bulk-import macros from another helpdesk, the only path is
the UI.

Usage:
    # Smoke-test: open browser, log in, navigate to macros page, list
    # what's there, take a screenshot. No writes.
    uv run python -m forge.ui_automation.macros \\
        --workspace Migr8now_Workspace --probe

    # Dry run: parse the YAML, print what we WOULD create, don't click
    # any buttons.
    uv run python -m forge.ui_automation.macros \\
        --workspace Migr8now_Workspace \\
        --payload forge/ui_automation/macros_payloads/example.yaml \\
        --dry-run

    # For real:
    uv run python -m forge.ui_automation.macros \\
        --workspace Migr8now_Workspace \\
        --payload forge/ui_automation/macros_payloads/example.yaml

YAML schema:
    macros:
      - name: "Refund issued"
        body: "Hi {{first_name}}, your refund has been processed..."
        # Optional fields below — can be added once the basic flow works:
        # team_visibility: ["Support", "Billing"]   # team names, not IDs
        # channels: ["chat", "email"]
        # actions:
        #   - type: assign_team
        #     team: "Billing"
"""
from __future__ import annotations

import argparse
import asyncio
import sys
from pathlib import Path

import yaml

from forge.ui_automation.session import (
    ensure_logged_in,
    intercom_session,
    resolve_app_id,
    screenshot,
)

MACROS_PATH = "/settings/helpdesk/macros"


def load_payload(path: Path) -> list[dict]:
    data = yaml.safe_load(path.read_text())
    macros = data.get("macros") if isinstance(data, dict) else None
    if not isinstance(macros, list):
        raise SystemExit(f"YAML at {path} must have a top-level 'macros:' list")
    for i, m in enumerate(macros):
        if not isinstance(m, dict) or "name" not in m or "body" not in m:
            raise SystemExit(f"macros[{i}] missing required fields 'name' and 'body'")
    return macros


async def go_to_macros(page, workspace: str):
    app_id = resolve_app_id(workspace)
    url = f"https://app.intercom.com/a/apps/{app_id}{MACROS_PATH}"
    print(f"[macros] navigating to {url}")
    await page.goto(url, wait_until="domcontentloaded")
    # Macros list typically has lazy-loaded content; give it a moment.
    await page.wait_for_load_state("networkidle", timeout=20_000)


async def probe(page) -> dict:
    """Inspect the macros page DOM and report what selectors we can see.

    This is the diagnostic mode. We do NOT click anything. We collect
    data so the next iteration of the script can target real elements.
    """
    info: dict = {"url": page.url}

    # Try a few candidate selectors for "the macro list" and "the new
    # macro button". We log which ones matched so we can pick the most
    # stable.
    button_candidates = [
        ('role=button[name="New macro"]', page.get_by_role("button", name="New macro")),
        ('role=button[name="Create macro"]', page.get_by_role("button", name="Create macro")),
        ('role=button[name="New"]', page.get_by_role("button", name="New").first),
        ('text="New macro"', page.get_by_text("New macro", exact=True).first),
    ]
    info["new_button_matches"] = []
    for label, loc in button_candidates:
        try:
            count = await loc.count()
            if count:
                visible = await loc.first.is_visible()
                info["new_button_matches"].append(
                    {"selector": label, "count": count, "visible": visible}
                )
        except Exception as e:
            info["new_button_matches"].append({"selector": label, "error": str(e)})

    # Capture the page <title> and a list of all role=button names visible
    # right now — useful if none of our guesses matched.
    info["page_title"] = await page.title()
    try:
        all_buttons = await page.get_by_role("button").all_inner_texts()
        info["visible_buttons"] = [b for b in all_buttons if b.strip()][:50]
    except Exception as e:
        info["visible_buttons_error"] = str(e)

    # Existing macro names — try a couple of patterns. Intercom's macro
    # list is typically a table or a list of cards. We grab anything that
    # looks like a row label.
    try:
        rows = await page.locator('[role="row"], [role="listitem"]').all_inner_texts()
        info["row_samples"] = [r.split("\n")[0][:80] for r in rows[:20] if r.strip()]
    except Exception as e:
        info["row_samples_error"] = str(e)

    return info


SEARCH_INPUT = 'input[placeholder="Search macros..."]'
TITLE_FIELD = 'textarea[placeholder="Untitled macro"]'


async def macro_exists(page, name: str) -> bool:
    """Use the in-page search box to check whether a macro by this name exists.

    Cheaper and more reliable than scraping the list DOM (which uses
    custom non-role elements). Search is fuzzy on the Intercom side, so
    we additionally verify by exact text match on the result.
    """
    search = page.locator(SEARCH_INPUT)
    await search.fill(name)
    await page.wait_for_timeout(600)  # let the list re-render
    # If any element on the page (other than our search input) contains
    # the exact text, we treat the macro as existing.
    found = page.get_by_text(name, exact=True)
    try:
        count = await found.count()
    except Exception:
        count = 0
    # Clear the search before returning so the list goes back to normal.
    await search.fill("")
    await page.wait_for_timeout(300)
    return count > 0


async def click_new_macro(page):
    """Click the 'New macro' button. Multiple instances exist (header +
    inline empty-state); .first targets the header one which is always
    present."""
    btn = page.get_by_role("button", name="New macro").first
    await btn.wait_for(state="visible")
    await btn.click()
    # Wait for the title textarea to appear — that's our signal that the
    # form has mounted.
    await page.locator(TITLE_FIELD).wait_for(state="visible", timeout=10_000)


async def create_one_macro(page, name: str, body: str) -> dict:
    """Create a single macro via the UI. Returns a result dict.

    Steps:
      1. Click 'New macro' (form mounts on the right with empty fields)
      2. Fill title textarea
      3. Click into the contenteditable body and type the body
      4. Click Save
      5. Wait for the new macro to appear in the left list (confirms persisted)
    """
    result = {"name": name, "status": "unknown"}

    await click_new_macro(page)

    # Title
    title = page.locator(TITLE_FIELD)
    await title.fill(name)

    # Body — the only contenteditable on the page after the form mounts.
    # We focus and use page.keyboard.type so newlines in body become
    # actual newlines in the editor.
    body_editor = page.locator('[contenteditable="true"]')
    await body_editor.click()
    await page.keyboard.type(body)

    # Save
    save_btn = page.get_by_role("button", name="Save").first
    await save_btn.wait_for(state="visible")
    await save_btn.click()

    # Confirm: wait briefly for either an error toast OR the macro name
    # to land in the list. We use the search box again as a positive
    # confirmation signal since the list DOM is opaque.
    await page.wait_for_timeout(1500)
    if await macro_exists(page, name):
        result["status"] = "created"
    else:
        # Take a screenshot so a failure is debuggable.
        shot = await screenshot(page, f"macro-save-failed-{int(__import__('time').time())}")
        result["status"] = "failed"
        result["screenshot"] = str(shot)
    return result


async def run_probe(workspace: str):
    async with intercom_session(workspace, headed=True) as ctx:
        page = await ensure_logged_in(ctx, workspace)
        await go_to_macros(page, workspace)
        info = await probe(page)
        shot = await screenshot(page, f"macros-probe-{workspace}")

        print("\n=== PROBE RESULT ===")
        print(f"URL:         {info['url']}")
        print(f"Page title:  {info['page_title']}")
        print(f"Screenshot:  {shot}")
        print("\nNew-button selector candidates:")
        for m in info.get("new_button_matches", []):
            print(f"  - {m}")
        print("\nVisible buttons on the page (first 50):")
        for b in info.get("visible_buttons", []):
            print(f"  - {b!r}")
        print("\nRow samples (first 20 list rows):")
        for r in info.get("row_samples", []):
            print(f"  - {r!r}")


async def probe_create_form(page) -> dict:
    """Click 'New macro' and report what the create form looks like.

    Then press Escape / navigate away without saving so the partial macro
    is discarded. (Intercom shows a discard-changes prompt for unsaved
    edits; we accept it.)
    """
    info: dict = {}

    # Snapshot existing list state so we can compare after.
    info["list_pane_text_before"] = (await page.locator("body").inner_text())[:0]  # placeholder

    # Click the first visible "New macro" button.
    btn = page.get_by_role("button", name="New macro").first
    await btn.wait_for(state="visible")
    await btn.click()

    # Give the form a beat to mount.
    try:
        await page.wait_for_load_state("networkidle", timeout=5_000)
    except Exception:
        pass
    await page.wait_for_timeout(800)

    # Capture all textboxes and contenteditables visible right now.
    info["url_after_click"] = page.url

    # Textbox / input fields by role
    try:
        textboxes = page.get_by_role("textbox")
        count = await textboxes.count()
        info["textbox_count"] = count
        info["textbox_samples"] = []
        for i in range(min(count, 10)):
            tb = textboxes.nth(i)
            try:
                placeholder = await tb.get_attribute("placeholder")
                aria_label = await tb.get_attribute("aria-label")
                name_attr = await tb.get_attribute("name")
                tag = await tb.evaluate("el => el.tagName")
                is_ce = await tb.evaluate("el => el.isContentEditable")
                info["textbox_samples"].append({
                    "index": i,
                    "tag": tag,
                    "placeholder": placeholder,
                    "aria-label": aria_label,
                    "name": name_attr,
                    "contenteditable": is_ce,
                })
            except Exception as e:
                info["textbox_samples"].append({"index": i, "error": str(e)})
    except Exception as e:
        info["textbox_error"] = str(e)

    # Look for placeholders on common name/title fields
    title_candidates = []
    for selector in [
        'input[placeholder*="name" i]',
        'input[placeholder*="title" i]',
        'input[aria-label*="name" i]',
        '[contenteditable="true"][aria-label*="name" i]',
        '[contenteditable="true"][data-placeholder*="name" i]',
    ]:
        try:
            loc = page.locator(selector)
            cnt = await loc.count()
            if cnt:
                title_candidates.append({"selector": selector, "count": cnt})
        except Exception:
            pass
    info["title_candidates"] = title_candidates

    # Generic contenteditable count (body editor is one of these)
    try:
        ce = page.locator('[contenteditable="true"]')
        info["contenteditable_count"] = await ce.count()
    except Exception as e:
        info["contenteditable_error"] = str(e)

    # All visible buttons on the form right now
    try:
        all_buttons = await page.get_by_role("button").all_inner_texts()
        info["visible_buttons_after_new"] = [b.strip() for b in all_buttons if b.strip()][:60]
    except Exception as e:
        info["visible_buttons_error"] = str(e)

    return info


async def run_probe_create_form(workspace: str):
    async with intercom_session(workspace, headed=True) as ctx:
        page = await ensure_logged_in(ctx, workspace)
        await go_to_macros(page, workspace)

        # Take a "before" screenshot so we can confirm the form state.
        await screenshot(page, f"macros-create-before-{workspace}")
        info = await probe_create_form(page)
        await screenshot(page, f"macros-create-after-{workspace}")

        print("\n=== CREATE-FORM PROBE ===")
        print(f"URL after click: {info.get('url_after_click')}")
        print(f"Textbox count:   {info.get('textbox_count')}")
        print(f"Contenteditable: {info.get('contenteditable_count')}")
        print("\nTextbox samples:")
        for s in info.get("textbox_samples", []):
            print(f"  - {s}")
        print("\nTitle/name selector candidates:")
        for c in info.get("title_candidates", []):
            print(f"  - {c}")
        print("\nButtons visible after clicking New macro:")
        for b in info.get("visible_buttons_after_new", []):
            print(f"  - {b!r}")
        print(
            "\nNOTE: a partial (unsaved) macro may exist on the page now."
            " Browser will close; Intercom typically discards it. Verify"
            " in the UI on next run."
        )


async def run_dry_run(workspace: str, payload_path: Path):
    macros = load_payload(payload_path)
    async with intercom_session(workspace, headed=True) as ctx:
        page = await ensure_logged_in(ctx, workspace)
        await go_to_macros(page, workspace)
        print(f"\n[dry-run] {len(macros)} macros in payload — checking each via search")
        for m in macros:
            exists = await macro_exists(page, m["name"])
            verb = "SKIP (name already exists)" if exists else "CREATE"
            print(f"  [{verb}] {m['name']!r}  body={m['body'][:60]!r}...")


async def run_create(workspace: str, payload_path: Path):
    """Create each macro in the payload via the UI. Idempotent."""
    macros = load_payload(payload_path)
    print(f"[create] {len(macros)} macros in payload")
    summary = {"created": 0, "skipped": 0, "failed": 0, "details": []}

    async with intercom_session(workspace, headed=True) as ctx:
        page = await ensure_logged_in(ctx, workspace)
        await go_to_macros(page, workspace)

        for i, m in enumerate(macros, 1):
            name = m["name"]
            body = m["body"]
            print(f"[create] [{i}/{len(macros)}] {name!r}")
            if await macro_exists(page, name):
                print("           → already exists, skipping")
                summary["skipped"] += 1
                summary["details"].append({"name": name, "status": "skipped"})
                continue
            try:
                result = await create_one_macro(page, name, body)
            except Exception as e:
                shot = await screenshot(page, f"macro-create-error-{int(__import__('time').time())}")
                print(f"           → ERROR: {e}  (screenshot: {shot})")
                summary["failed"] += 1
                summary["details"].append({"name": name, "status": "error", "error": str(e), "screenshot": str(shot)})
                continue
            print(f"           → {result['status']}")
            if result["status"] == "created":
                summary["created"] += 1
            else:
                summary["failed"] += 1
            summary["details"].append(result)
            # Light pacing between operations.
            await page.wait_for_timeout(800)

    print("\n=== SUMMARY ===")
    print(f"  created: {summary['created']}")
    print(f"  skipped: {summary['skipped']}")
    print(f"  failed:  {summary['failed']}")
    if summary["failed"]:
        print("\n  Failed details:")
        for d in summary["details"]:
            if d.get("status") in ("failed", "error"):
                print(f"    - {d['name']}: {d.get('error', d.get('screenshot', ''))}")


def main():
    ap = argparse.ArgumentParser(description="Create Intercom macros via the admin UI.")
    ap.add_argument("--workspace", required=True, help="Workspace folder name under workspace/")
    mode = ap.add_mutually_exclusive_group(required=True)
    mode.add_argument("--probe", action="store_true", help="Open browser, navigate to macros page, dump selector candidates. No writes.")
    mode.add_argument("--probe-create-form", action="store_true", help="Click 'New macro' and dump form-field selectors. Discards the empty draft afterward.")
    mode.add_argument("--dry-run", action="store_true", help="Parse payload and print what would be created. Reads page but no writes.")
    mode.add_argument("--create", action="store_true", help="Actually create the macros. Requires --payload.")
    ap.add_argument("--payload", type=Path, help="YAML file with macros to create")
    args = ap.parse_args()

    if args.probe:
        asyncio.run(run_probe(args.workspace))
    elif args.probe_create_form:
        asyncio.run(run_probe_create_form(args.workspace))
    elif args.dry_run:
        if not args.payload:
            ap.error("--dry-run requires --payload")
        asyncio.run(run_dry_run(args.workspace, args.payload))
    elif args.create:
        if not args.payload:
            ap.error("--create requires --payload")
        asyncio.run(run_create(args.workspace, args.payload))


if __name__ == "__main__":
    main()
