import httpx
from typing import Any

from forge.license import ensure_licensed

INTERCOM_API_BASE = "https://api.intercom.io"
INTERCOM_VERSION = "Preview"


class IntercomError(Exception):
    def __init__(self, status_code: int, message: str):
        self.status_code = status_code
        self.message = message
        super().__init__(f"HTTP {status_code}: {message}")


class IntercomClient:
    def __init__(self, access_token: str):
        # Gate every Intercom client construction — even if a partner
        # bypasses the MCP server entrypoint by importing tools directly,
        # they still hit this. Cheap after the first call in a process.
        ensure_licensed()

        self._client = httpx.Client(
            base_url=INTERCOM_API_BASE,
            headers={
                "Authorization": f"Bearer {access_token}",
                "Accept": "application/json",
                "Content-Type": "application/json",
                "Intercom-Version": INTERCOM_VERSION,
            },
            timeout=30.0,
        )

    def _raise_for_status(self, response: httpx.Response) -> None:
        if response.is_error:
            try:
                body = response.json()
                errors = body.get("errors", [])
                message = errors[0].get("message", response.text) if errors else response.text
            except Exception:
                message = response.text
            raise IntercomError(response.status_code, message)

    def get(self, path: str, params: dict | None = None) -> Any:
        response = self._client.get(path, params=params)
        self._raise_for_status(response)
        return response.json()

    def post(self, path: str, body: dict) -> Any:
        response = self._client.post(path, json=body)
        self._raise_for_status(response)
        return response.json()

    def put(self, path: str, body: dict) -> Any:
        response = self._client.put(path, json=body)
        self._raise_for_status(response)
        return response.json()

    def delete(self, path: str) -> Any:
        response = self._client.delete(path)
        self._raise_for_status(response)
        return response.json()

    def close(self):
        self._client.close()

    def __enter__(self):
        return self

    def __exit__(self, *args):
        self.close()
