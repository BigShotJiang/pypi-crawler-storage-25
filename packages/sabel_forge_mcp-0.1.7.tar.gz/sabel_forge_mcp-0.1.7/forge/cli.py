"""forge top-level CLI.

Subcommand groups:
  - auth        License key management (login / status / logout).
  - install     One-shot setup helpers (Playwright browsers, etc.).
  - workspace   Manage Intercom workspace configs in ~/.forge/.

The root group takes no required options so subcommands that don't
need an Intercom token (auth, install) work without one in the env.

The bulk of forge's functionality is exposed via MCP servers
(forge-workspace, forge-fin) rather than the CLI — the CLI is for
partner-machine setup, not Intercom operations.
"""
from __future__ import annotations

import click

from forge.commands.auth import auth_group
from forge.commands.install import install_group
from forge.commands.workspace import workspace_group


@click.group()
def cli():
    """forge — Intercom implementations partner CLI."""


cli.add_command(auth_group)
cli.add_command(install_group)
cli.add_command(workspace_group)
