"""License validation and gating for forge MCP servers.

Forge is sold as a license-gated PyPI binary. Every MCP server start
calls `gate_startup()`, which loads a signed validation response from
the local cache, verifies its signature with an embedded public key, and
refreshes from the backend if the cache has expired. If the cache is
missing, expired beyond the grace period, or its signature doesn't
verify, the server refuses to start.

Trust model
-----------
The backend (forge-api on Fly) holds the Ed25519 private key. When a
partner runs `forge auth login --key forge_live_xxx`, the client POSTs
the key to /v1/license/validate. The backend looks up the partner +
their Stripe subscription, and returns a JSON response signed with the
private key. The signature covers a canonical (sort-keys, no spaces)
JSON encoding of the response payload so the client can verify it
later from the cache file.

The corresponding public key is embedded below. Anyone can read the
file — that's fine, public keys are public. What matters is that nobody
without the private key can forge a valid response.

Threat surfaces (acknowledged, not fully prevented)
---------------------------------------------------
Python wheels are bytecode-readable. A determined partner could
decompile and patch out the gate. We make this inconvenient (signed
responses, scattered checks, expiry-on-cache) but not impossible. For a
B2B audience this is the same trade-off JetBrains, Linear CLI, etc.
accept.

Configuration
-------------
- FORGE_API_URL                  override the backend (default https://api.forge.dev)
- FORGE_LICENSE_PUBLIC_KEY       override the embedded public key (hex)
- FORGE_LICENSE_DEV_BYPASS=1     skip enforcement entirely; emits a stderr warning.
                                 Intended ONLY for local development of the server itself
                                 — never set this on a partner machine.
"""
from __future__ import annotations

import json
import os
import socket
import sys
import time
import uuid
from dataclasses import asdict, dataclass
from pathlib import Path

import httpx
from cryptography.exceptions import InvalidSignature
from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PublicKey

from forge import paths

# Ed25519 public key, raw 32 bytes hex-encoded. The matching private key
# lives only on the forge-api backend (Fly secret) and signs every
# /v1/license/validate response. Replace this constant when rotating
# the keypair.
LICENSE_PUBLIC_KEY_HEX = (
    "fdcff5a06bb03da708ae12b6813f5a240c2349960c264f6d04046278a331d527"
)

DEFAULT_BACKEND_URL = "https://forge-mcp-api.fly.dev"
VALIDATE_PATH = "/v1/license/validate"
CACHE_FILENAME = "license.cache"

# Grace period: how long after expires_at the cache is still honoured
# when the backend can't be reached. Past this, gate_startup() refuses
# to start regardless of the cache contents.
GRACE_PERIOD_SECONDS = 12 * 60 * 60

VALIDATION_TIMEOUT_SECONDS = 10


class LicenseError(RuntimeError):
    """Raised when license validation fails for any reason — missing
    cache, bad signature, expired beyond grace period, subscription
    inactive, or backend rejected the key."""


@dataclass
class ValidationResponse:
    """The signed payload returned by the backend.

    issued_at:          unix epoch seconds the backend signed the response
    expires_at:         unix epoch seconds the cache should be refreshed
                        (typically issued_at + 24h)
    subscription_active: True iff the partner has a paid subscription right now
    subscription_plan:   free-form plan name (e.g. "monthly", "annual")
    key_prefix:          first 12 chars of the API key (for display)
    machine_id_hash:     what the backend recorded for this machine — lets
                        the client confirm the response was signed for THIS
                        machine, not someone else's
    seat_count:          number of distinct machines currently using this key
                        (informational; future pricing tiers)
    notice:              optional one-line message to surface in `forge auth status`
    """
    issued_at: int
    expires_at: int
    subscription_active: bool
    subscription_plan: str
    key_prefix: str
    machine_id_hash: str
    seat_count: int
    notice: str | None = None


@dataclass
class CachedLicense:
    """What we persist on disk.

    `response` + `signature_hex` are what the backend signed and we
    verify on every read. `api_key` is the partner's bearer token for
    re-validation — NOT part of the signed payload (the backend wouldn't
    echo a secret), stored locally at 600 perms so the MCP server can
    refresh the cache without forcing the partner to re-login.
    """
    response: ValidationResponse
    signature_hex: str
    api_key: str

    def to_disk_format(self) -> dict:
        return {
            "api_key": self.api_key,
            "response": asdict(self.response),
            "signature_hex": self.signature_hex,
        }


# ── Public key + signature verification ──────────────────────────────


def _public_key() -> Ed25519PublicKey:
    """Resolve the public key. Env override takes precedence — useful
    for staging/dev where you've rotated to a different backend."""
    raw_hex = os.environ.get("FORGE_LICENSE_PUBLIC_KEY", LICENSE_PUBLIC_KEY_HEX)
    return Ed25519PublicKey.from_public_bytes(bytes.fromhex(raw_hex))


def _canonical_payload(response: ValidationResponse) -> bytes:
    """Bytes the backend signed and the client verifies. MUST be
    deterministic — sort keys, no whitespace, UTF-8."""
    return json.dumps(asdict(response), sort_keys=True, separators=(",", ":")).encode("utf-8")


def _verify_signature(response: ValidationResponse, signature_hex: str) -> None:
    """Raise LicenseError if the signature doesn't verify."""
    try:
        _public_key().verify(bytes.fromhex(signature_hex), _canonical_payload(response))
    except (InvalidSignature, ValueError) as e:
        raise LicenseError(
            "License cache signature does not verify. The cache may have been "
            "tampered with, or your install was built against a different "
            "backend. Run `forge auth login --key ...` to refresh."
        ) from e


# ── Cache I/O ────────────────────────────────────────────────────────


def cache_path() -> Path:
    return paths.state_root() / CACHE_FILENAME


def load_cache() -> CachedLicense | None:
    """Read the cache file; return None if missing. Does NOT verify the
    signature — call gate_startup() or _verify_signature() for that."""
    p = cache_path()
    if not p.is_file():
        return None
    try:
        raw = json.loads(p.read_text())
        return CachedLicense(
            response=ValidationResponse(**raw["response"]),
            signature_hex=raw["signature_hex"],
            api_key=raw["api_key"],
        )
    except (json.JSONDecodeError, KeyError, TypeError) as e:
        raise LicenseError(
            f"License cache at {p} is malformed ({e}). "
            f"Run `forge auth logout` then `forge auth login --key ...`."
        ) from e


def save_cache(cached: CachedLicense) -> None:
    """Write atomically with 600 perms — the cache contains nothing
    truly secret (the API key isn't stored here, only its prefix), but
    on shared machines no need to broadcast subscription state."""
    paths.ensure_dir(paths.state_root())
    p = cache_path()
    tmp = p.with_suffix(".tmp")
    tmp.write_text(json.dumps(cached.to_disk_format(), indent=2))
    os.chmod(tmp, 0o600)
    tmp.replace(p)


def wipe_cache() -> None:
    """Remove the cache file. Used by `forge auth logout`."""
    p = cache_path()
    if p.exists():
        p.unlink()


# ── Backend round trip ───────────────────────────────────────────────


def _backend_url() -> str:
    return os.environ.get("FORGE_API_URL", DEFAULT_BACKEND_URL).rstrip("/")


def machine_id_hash() -> str:
    """Stable identifier for this machine. Combines hostname + a MAC-like
    id; SHA-256'd so we don't ship the raw values to the backend.

    Only used for backend-side anomaly detection ("one key seen on 50
    distinct machines this week is suspicious") and for tying signed
    responses to a specific machine. Not a hard fingerprint and not
    relied on for security.
    """
    import hashlib
    parts = [socket.gethostname(), str(uuid.getnode())]
    digest = hashlib.sha256("|".join(parts).encode("utf-8")).hexdigest()
    return digest[:32]


def validate_with_backend(api_key: str) -> CachedLicense:
    """Call the backend's /v1/license/validate. Returns a CachedLicense
    on success (signature already verified); raises LicenseError otherwise.

    Used both by `forge auth login` (first-time activation) and by
    gate_startup() when the local cache has expired.
    """
    url = _backend_url() + VALIDATE_PATH
    request_body = {
        "api_key": api_key,
        "machine_id_hash": machine_id_hash(),
        "client_version": _client_version(),
    }
    try:
        resp = httpx.post(url, json=request_body, timeout=VALIDATION_TIMEOUT_SECONDS)
    except httpx.HTTPError as e:
        raise LicenseError(
            f"Couldn't reach the forge license backend at {url}: {e}. "
            f"Check your internet connection and try again."
        ) from e

    if resp.status_code == 401 or resp.status_code == 403:
        raise LicenseError(
            "License key was rejected by the backend. Either the key is "
            "wrong, the subscription was cancelled, or payment failed. "
            "See https://forge.dev/billing for details."
        )
    if resp.status_code != 200:
        raise LicenseError(
            f"License backend returned HTTP {resp.status_code}: "
            f"{resp.text[:200]}"
        )

    try:
        envelope = resp.json()
        response = ValidationResponse(**envelope["response"])
        signature_hex = envelope["signature_hex"]
    except (json.JSONDecodeError, KeyError, TypeError) as e:
        raise LicenseError(
            f"License backend returned a malformed response: {e}"
        ) from e

    cached = CachedLicense(
        response=response, signature_hex=signature_hex, api_key=api_key
    )
    _verify_signature(cached.response, cached.signature_hex)
    if cached.response.machine_id_hash != machine_id_hash():
        raise LicenseError(
            "License backend signed a response for a different machine. "
            "This shouldn't happen on a normal client; if you're using a "
            "VPN or moved hardware, run `forge auth login` again."
        )
    return cached


# ── The actual gate ──────────────────────────────────────────────────


def _dev_bypass() -> bool:
    return os.environ.get("FORGE_LICENSE_DEV_BYPASS") == "1"


def _now() -> int:
    return int(time.time())


def gate_startup() -> CachedLicense | None:
    """Block server startup unless we have a verifiable, current license.

    Logic, in order:
      1. FORGE_LICENSE_DEV_BYPASS=1 → return None with a stderr warning.
      2. Load cache. If missing → LicenseError.
      3. Verify signature. If bad → LicenseError.
      4. If subscription_active=False on the cached response → LicenseError.
      5. If now < expires_at → cache is fresh; return it.
      6. Cache is expired. Try to refresh from backend (using the api_key
         stored in the cache).
         - If refresh succeeds and subscription is active → save + return.
         - If refresh fails (network) → check grace window:
            - If now < expires_at + GRACE_PERIOD_SECONDS → return stale cache.
            - Else → LicenseError.

    Returns the CachedLicense in use, or None when the dev-bypass is
    active. The caller decides whether to do anything with it.
    """
    if _dev_bypass():
        print(
            "[forge] WARNING: FORGE_LICENSE_DEV_BYPASS=1 — license check "
            "skipped. Never set this on a partner machine.",
            file=sys.stderr,
        )
        return None

    cached = load_cache()
    if cached is None:
        raise LicenseError(
            "No forge license found. Run:\n"
            "    forge auth login --key forge_live_xxx\n"
            "to activate this machine."
        )

    _verify_signature(cached.response, cached.signature_hex)

    if not cached.response.subscription_active:
        raise LicenseError(
            "This forge license is not currently active (subscription "
            "cancelled or payment failed). Visit https://forge.dev/billing."
        )

    now = _now()
    if now < cached.response.expires_at:
        return cached  # fresh cache, all good

    # Cache is expired. Try to refresh using the stored api_key.
    try:
        refreshed = validate_with_backend(cached.api_key)
        save_cache(refreshed)
        return refreshed
    except LicenseError:
        # Couldn't reach the backend. Honour grace window.
        if now < cached.response.expires_at + GRACE_PERIOD_SECONDS:
            print(
                f"[forge] WARNING: could not refresh license; running on "
                f"cached response from "
                f"{time.ctime(cached.response.issued_at)}.",
                file=sys.stderr,
            )
            return cached
        raise LicenseError(
            "License cache is past the 12h offline grace period and the "
            "backend is unreachable. Reconnect to the internet and retry."
        )


_PROCESS_VALIDATED: bool = False


def ensure_licensed() -> None:
    """Hot-path gate. Call this from anywhere we don't want users to be
    able to bypass — IntercomClient.__init__, intercom_session(), etc.

    Runs the full gate_startup() check on first call in this process,
    then caches an in-memory bool so subsequent calls are essentially
    free. The cache file on disk is the single source of truth; this
    is just a perf shim so we don't re-read + re-verify on every API
    call.

    Raises LicenseError if validation fails. Returns silently otherwise
    (including when FORGE_LICENSE_DEV_BYPASS=1 is set).

    Threat surface: a determined partner could patch _PROCESS_VALIDATED
    to True. That's expected — see the module docstring on why scattered
    checks beat one toggle.
    """
    global _PROCESS_VALIDATED
    if _PROCESS_VALIDATED:
        return
    gate_startup()  # raises on failure; returns CachedLicense | None on success
    _PROCESS_VALIDATED = True


def _client_version() -> str:
    """Best-effort package version, for telemetry. Avoids importing
    importlib.metadata on hot paths, but it's fine here since this only
    runs on validation."""
    try:
        from importlib.metadata import version
        return version("sabel-forge-mcp")
    except Exception:
        return "unknown"
