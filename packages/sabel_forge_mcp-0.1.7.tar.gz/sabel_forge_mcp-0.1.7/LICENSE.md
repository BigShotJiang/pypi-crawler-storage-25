# License — sabel-forge-mcp

Copyright © 2026 Sabel Customer Success Limited. All rights reserved.

This software ("Software") is licensed, not sold. Use of the Software
requires a current paid subscription with Sabel Customer Success
("Sabel"). The license granted is non-exclusive, non-transferable,
non-sublicensable, and revocable.

## You may

- Install and run the Software on machines you control as part of
  your business of implementing Intercom for your own clients.
- Activate the Software with a license key issued through your
  Sabel subscription.
- Use up to N distinct machines per active subscription, where N is
  determined by your subscription plan. Excess use is billable at the
  then-current overage rate.

## You may not

- Redistribute the Software or any artifact derived from it (binaries,
  modified source, repackaged versions, container images that include
  it) — publicly or privately, paid or free.
- Reverse engineer, disassemble, decompile, or otherwise attempt to
  derive the source of compiled portions of the Software, except to
  the extent this restriction is unenforceable under applicable law.
- Remove, modify, obscure, or strip license-validation code,
  watermarks (visible or invisible), audit identifiers, or any other
  enforcement mechanism. Doing so is a material breach of this license
  and terminates your rights immediately.
- Share, resell, or sublicense your license key. License keys are
  bound to a single Sabel subscription.
- Use the Software for the benefit of any organisation that does not
  have its own active Sabel subscription, except where you act as an
  authorised implementation partner of that organisation.

## License-gated content

Industry playbooks (gambling, ecommerce, fintech, ...) and other
content fetched from `forge-mcp-api.fly.dev` (or successor URLs) are
delivered only to licensees with active subscriptions. That content
remains the property of Sabel and is licensed for your use under the
same terms as the Software. Each fetch carries an invisible per-licensee
watermark; redistributed copies remain attributable to the original
licensee.

## Updates

Sabel may publish updates that change the Software, the validation
protocol, or the content surface. Continued use after an update
constitutes acceptance of the updated Software under this license.

## Termination

This license terminates automatically on (a) cancellation or non-payment
of your Sabel subscription, (b) breach of any term above, or (c) written
notice from Sabel for cause. On termination you must stop using the
Software and remove all installed copies.

## Warranty + liability

The Software is provided "as is" without warranty of any kind. To the
maximum extent permitted by law, Sabel disclaims all implied warranties
(including merchantability and fitness for a particular purpose) and is
not liable for indirect, incidental, special, or consequential damages
arising from the Software's use.

## Contact

License questions or compliance requests: engineering@sabelcustomersuccess.com
