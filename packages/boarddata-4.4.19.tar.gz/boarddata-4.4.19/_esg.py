"""ESG methods: IROs, transition plans, and benchmark."""

from __future__ import annotations

from typing import Any

from .types.core import FieldSourcePayload, PaginatedResponse
from .types.esg import (
    ESGBenchmarkExportItem,
    ESGBenchmarkStats,
    IROBatchItemPayload,
    IROBatchResultItem,
    IRODetail,
    TransitionFinancePayload,
    TransitionGovernancePayload,
    TransitionLeverPayload,
    TransitionPlanDetail,
    TransitionTargetPayload,
)


class ESGMixin:
    """ESG API methods: IROs, transition plans, and benchmark."""

    # ------------------------------------------------------------------
    # IROs
    # ------------------------------------------------------------------

    def list_iros(self, **params: Any) -> PaginatedResponse:
        """List IROs (Impact/Risk/Opportunity).

        Args:
            company: Filter by company UUID.
            esg_type: Filter by ESG pillar (``"E"``, ``"S"``, or ``"G"``).
            date_from: Filter by publication date >= (``"YYYY-MM-DD"``).
            date_to: Filter by publication date <= (``"YYYY-MM-DD"``).
            page: Page number.
            page_size: Results per page.

        Returns:
            Paginated list of IRODetail items.

        Raises:
            BoardDataError: On non-2xx API response.
        """
        return self._get("iros/", **params)  # type: ignore[attr-defined]

    def get_iro(self, uid: str) -> IRODetail:
        """Retrieve an IRO by UUID."""
        return self._get(f"iros/{uid}/")  # type: ignore[attr-defined]

    def create_iro(
        self,
        company: str,
        date_publication: str,
        name: str,
        esg_type: str,
        *,
        description: str | None = None,
        iro_types: list[int] | None = None,
        page_number: int | None = None,
        evidence_text: str | None = None,
        field_sources: list[FieldSourcePayload] | None = None,
    ) -> IRODetail:
        """Create an IRO.

        Args:
            company: Company UUID.
            date_publication: Publication date (``"YYYY-MM-DD"``).
            name: IRO name/title.
            esg_type: ESG pillar (``"E"``, ``"S"``, or ``"G"``).
            description: Detailed description.
            iro_types: List of IROType IDs to associate.
            page_number: Source document page number.
            evidence_text: Supporting evidence text.
            field_sources: List of field source entries for traceability.

        Returns:
            Created IRODetail.

        Raises:
            BoardDataError: On non-2xx API response.
        """
        payload = self._build_payload(  # type: ignore[attr-defined]
            company=company,
            date_publication=date_publication,
            name=name,
            esg_type=esg_type,
            description=description,
            iro_types=iro_types,
            page_number=page_number,
            evidence_text=evidence_text,
            field_sources=field_sources,
        )
        return self._post("iros/", payload)  # type: ignore[attr-defined]

    def update_iro(
        self,
        uid: str,
        *,
        company: str | None = None,
        date_publication: str | None = None,
        name: str | None = None,
        esg_type: str | None = None,
        description: str | None = None,
        iro_types: list[int] | None = None,
        page_number: int | None = None,
        evidence_text: str | None = None,
        field_sources: list[FieldSourcePayload] | None = None,
    ) -> IRODetail:
        """Partial update an IRO."""
        payload = self._build_payload(  # type: ignore[attr-defined]
            company=company,
            date_publication=date_publication,
            name=name,
            esg_type=esg_type,
            description=description,
            iro_types=iro_types,
            page_number=page_number,
            evidence_text=evidence_text,
            field_sources=field_sources,
        )
        return self._patch(f"iros/{uid}/", payload)  # type: ignore[attr-defined]

    def delete_iro(self, uid: str) -> None:
        """Delete an IRO."""
        self._delete(f"iros/{uid}/")  # type: ignore[attr-defined]

    def batch_create_iro(
        self,
        items: list[IROBatchItemPayload],
    ) -> list[IROBatchResultItem]:
        """Batch upsert IROs.

        Each item is matched by ``(company, date_publication, name)``.
        Existing records are updated; new ones are created.

        Args:
            items: List of IRO payloads to upsert.

        Returns:
            List of results with ``name``, ``iro_id``, and ``action``
            (``"created"`` or ``"updated"``).

        Raises:
            BoardDataError: On non-2xx API response.
        """
        return self._post("iros/batch/", items)  # type: ignore[attr-defined]

    # ------------------------------------------------------------------
    # Transition Plans
    # ------------------------------------------------------------------

    def list_transition_plans(self, **params: Any) -> PaginatedResponse:
        """List transition plans.

        Args:
            company: Filter by company UUID.
            date_from: Filter by publication date >= (``"YYYY-MM-DD"``).
            date_to: Filter by publication date <= (``"YYYY-MM-DD"``).
            page: Page number.
            page_size: Results per page.

        Returns:
            Paginated list of TransitionPlanDetail items.

        Raises:
            BoardDataError: On non-2xx API response.
        """
        return self._get("transition-plans/", **params)  # type: ignore[attr-defined]

    def get_transition_plan(self, uid: str) -> TransitionPlanDetail:
        """Retrieve a transition plan by UUID."""
        return self._get(f"transition-plans/{uid}/")  # type: ignore[attr-defined]

    def create_transition_plan(
        self,
        company: str,
        date_publication: str,
        *,
        explanation: str | None = None,
        ghg_baseline_year: int | None = None,
        ghg_baseline_value: str | None = None,
        ghg_baseline_unit: str | None = None,
        net_zero_target_year: int | None = None,
        paris_alignment_pathway: str | None = None,
        sbti_validated: bool | None = None,
        targets: list[TransitionTargetPayload] | None = None,
        levers: list[TransitionLeverPayload] | None = None,
        finances: list[TransitionFinancePayload] | None = None,
        governances: list[TransitionGovernancePayload] | None = None,
        field_sources: list[FieldSourcePayload] | None = None,
    ) -> TransitionPlanDetail:
        """Create a transition plan with optional nested children.

        Args:
            company: Company UUID.
            date_publication: Publication date (``"YYYY-MM-DD"``).
            explanation: Plan explanation text.
            ghg_baseline_year: GHG baseline year.
            ghg_baseline_value: GHG baseline value (decimal as string).
            ghg_baseline_unit: GHG baseline unit (e.g. ``"tCO2e"``).
            net_zero_target_year: Target year for net zero.
            paris_alignment_pathway: Paris alignment pathway reference.
            sbti_validated: Whether SBTi has validated the plan.
            targets: Nested GHG reduction targets.
            levers: Nested decarbonisation levers.
            finances: Nested financial commitments.
            governances: Nested governance mechanisms.
            field_sources: List of field source entries for traceability.

        Returns:
            Created TransitionPlanDetail with nested children.

        Raises:
            BoardDataError: On non-2xx API response.
        """
        payload = self._build_payload(  # type: ignore[attr-defined]
            company=company,
            date_publication=date_publication,
            explanation=explanation,
            ghg_baseline_year=ghg_baseline_year,
            ghg_baseline_value=ghg_baseline_value,
            ghg_baseline_unit=ghg_baseline_unit,
            net_zero_target_year=net_zero_target_year,
            paris_alignment_pathway=paris_alignment_pathway,
            sbti_validated=sbti_validated,
            targets=targets,
            levers=levers,
            finances=finances,
            governances=governances,
            field_sources=field_sources,
        )
        return self._post("transition-plans/", payload)  # type: ignore[attr-defined]

    def update_transition_plan(
        self,
        uid: str,
        *,
        company: str | None = None,
        date_publication: str | None = None,
        explanation: str | None = None,
        ghg_baseline_year: int | None = None,
        ghg_baseline_value: str | None = None,
        ghg_baseline_unit: str | None = None,
        net_zero_target_year: int | None = None,
        paris_alignment_pathway: str | None = None,
        sbti_validated: bool | None = None,
        targets: list[TransitionTargetPayload] | None = None,
        levers: list[TransitionLeverPayload] | None = None,
        finances: list[TransitionFinancePayload] | None = None,
        governances: list[TransitionGovernancePayload] | None = None,
        field_sources: list[FieldSourcePayload] | None = None,
    ) -> TransitionPlanDetail:
        """Partial update a transition plan.

        If nested children (targets, levers, finances, governances) are provided,
        they replace the existing children entirely (delete + recreate).
        """
        payload = self._build_payload(  # type: ignore[attr-defined]
            company=company,
            date_publication=date_publication,
            explanation=explanation,
            ghg_baseline_year=ghg_baseline_year,
            ghg_baseline_value=ghg_baseline_value,
            ghg_baseline_unit=ghg_baseline_unit,
            net_zero_target_year=net_zero_target_year,
            paris_alignment_pathway=paris_alignment_pathway,
            sbti_validated=sbti_validated,
            targets=targets,
            levers=levers,
            finances=finances,
            governances=governances,
            field_sources=field_sources,
        )
        return self._patch(f"transition-plans/{uid}/", payload)  # type: ignore[attr-defined]

    def delete_transition_plan(self, uid: str) -> None:
        """Delete a transition plan."""
        self._delete(f"transition-plans/{uid}/")  # type: ignore[attr-defined]

    # ------------------------------------------------------------------
    # Benchmark
    # ------------------------------------------------------------------

    def list_esg_benchmark(self, **params: Any) -> PaginatedResponse:
        """List companies with ESG benchmark data.

        Args:
            search: Search by company name or ISIN.
            indexes_include: List of index names to include.
            indexes_exclude: List of index names to exclude.
            sectors_include: List of sector names to include.
            sectors_exclude: List of sector names to exclude.
            headquarters_include: List of country codes to include.
            headquarters_exclude: List of country codes to exclude.
            page: Page number.
            page_size: Results per page (max 200).

        Returns:
            Paginated list of CompanyESGBenchmarkItem items.

        Raises:
            BoardDataError: On non-2xx API response.
        """
        return self._get("companies/benchmark/", **params)  # type: ignore[attr-defined]

    def export_esg_benchmark(
        self,
        *,
        search: str | None = None,
        indexes_include: list[str] | None = None,
        indexes_exclude: list[str] | None = None,
        sectors_include: list[str] | None = None,
        sectors_exclude: list[str] | None = None,
        headquarters_include: list[str] | None = None,
        headquarters_exclude: list[str] | None = None,
        date_from: str | None = None,
        date_to: str | None = None,
        iro_search: str | None = None,
        has_transition_plan: str | None = None,
        sbti_validated: str | None = None,
        has_net_zero: str | None = None,
        **kwargs: Any,
    ) -> list[ESGBenchmarkExportItem]:
        """Export ESG benchmark data as a flat list (up to the server's row cap).

        Accepts the same filters as ``list_esg_benchmark`` and
        ``get_esg_benchmark_stats``. Returns all matching company rows with
        nested IROs and transition plan without pagination.

        Args:
            search: Search by company name or ISIN.
            indexes_include: Index names to include.
            indexes_exclude: Index names to exclude.
            sectors_include: Sector names to include.
            sectors_exclude: Sector names to exclude.
            headquarters_include: ISO country codes to include.
            headquarters_exclude: ISO country codes to exclude.
            date_from: IRO publication date >= (``"YYYY-MM-DD"``).
            date_to: IRO publication date <= (``"YYYY-MM-DD"``).
            iro_search: IRO name substring (icontains).
            has_transition_plan: ``"yes"`` or ``"no"``.
            sbti_validated: ``"yes"`` or ``"no"``.
            has_net_zero: ``"yes"`` or ``"no"``.
            **kwargs: Additional filters forwarded as query params.

        Returns:
            List of ESGBenchmarkExportItem dicts.

        Raises:
            ExportTooLargeError: When the result set exceeds the server cap.
            BoardDataError: On any other non-2xx response.
        """
        return self._get_export(  # type: ignore[attr-defined]
            "companies/benchmark/export/",
            search=search,
            indexes_include=indexes_include,
            indexes_exclude=indexes_exclude,
            sectors_include=sectors_include,
            sectors_exclude=sectors_exclude,
            headquarters_include=headquarters_include,
            headquarters_exclude=headquarters_exclude,
            date_from=date_from,
            date_to=date_to,
            iro_search=iro_search,
            has_transition_plan=has_transition_plan,
            sbti_validated=sbti_validated,
            has_net_zero=has_net_zero,
            **kwargs,
        )

    def get_esg_benchmark_stats(self, **params: Any) -> ESGBenchmarkStats:
        """Get aggregate E/S/G IRO counts across filtered companies.

        Accepts the same filter params as ``list_esg_benchmark`` plus
        ``date_from``, ``date_to``, ``iro_search``, ``has_transition_plan``,
        ``sbti_validated``, ``has_net_zero``.

        Args:
            search: Company name/ISIN substring.
            indexes_include / indexes_exclude: Index names.
            sectors_include / sectors_exclude: Sector names.
            headquarters_include / headquarters_exclude: ISO country codes.
            date_from / date_to: IRO publication date range (YYYY-MM-DD).
            iro_search: IRO name substring (icontains).
            has_transition_plan: "yes" or "no".
            sbti_validated: "yes" or "no".
            has_net_zero: "yes" or "no".

        Returns:
            ``ESGBenchmarkStats`` TypedDict with keys ``count`` (company
            count), ``environment``, ``social``, ``governance``,
            ``total_iros``.

        Raises:
            BoardDataError: On non-2xx API response.
        """
        return self._get("companies/benchmark/stats/", **params)  # type: ignore[attr-defined,return-value]
