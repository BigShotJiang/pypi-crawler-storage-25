"""BoardData API exceptions."""

from __future__ import annotations

from typing import Any


class BoardDataError(Exception):
    """Raised when the API returns a non-2xx response."""

    def __init__(self, status_code: int, detail: Any) -> None:
        self.status_code = status_code
        self.detail = detail
        super().__init__(f"HTTP {status_code}: {detail}")


class ExportTooLargeError(BoardDataError):
    """Raised when an export exceeds the server's row cap (HTTP 413).

    Attributes:
        row_count: Number of rows the filtered queryset contains.
        cap: Server-side row cap that was exceeded.
    """

    def __init__(self, *, row_count: int, cap: int, message: str) -> None:
        self.row_count = row_count
        self.cap = cap
        super().__init__(413, message)
