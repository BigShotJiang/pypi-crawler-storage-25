"""Tests for all SDK export methods and ExportTooLargeError infrastructure."""
from __future__ import annotations

import json
from unittest.mock import MagicMock, patch

import pytest

from boarddata.errors import BoardDataError, ExportTooLargeError


# ---------------------------------------------------------------------------
# Shared helpers
# ---------------------------------------------------------------------------

def _make_response(status_code: int, body: object) -> MagicMock:
    """Build a minimal requests.Response-like mock."""
    resp = MagicMock()
    resp.status_code = status_code
    resp.ok = 200 <= status_code < 300
    resp.json.return_value = body
    resp.text = json.dumps(body) if isinstance(body, (dict, list)) else str(body)
    return resp


def _make_client_for(mixin_class):
    """Create a test client for a given mixin class."""
    from boarddata._base import Base

    class TestClient(mixin_class, Base):
        pass

    client = TestClient.__new__(TestClient)
    client._request = MagicMock()
    client._get_token = MagicMock(return_value="fake-token")
    client.base_url = "https://api.example.com"
    client.timeout = 30
    return client


# ---------------------------------------------------------------------------
# ExportTooLargeError
# ---------------------------------------------------------------------------

class TestExportTooLargeError:
    def test_is_board_data_error_subclass(self):
        err = ExportTooLargeError(row_count=1200, cap=100, message="Too many rows")
        assert isinstance(err, BoardDataError)

    def test_attributes(self):
        err = ExportTooLargeError(row_count=500, cap=100, message="Over cap")
        assert err.row_count == 500
        assert err.cap == 100
        assert err.status_code == 413

    def test_str_contains_message(self):
        err = ExportTooLargeError(row_count=5, cap=4, message="Export too large")
        assert "Export too large" in str(err)


# ---------------------------------------------------------------------------
# _get_export helper (unit-tested directly through Base)
# ---------------------------------------------------------------------------

class TestGetExportHelper:
    def _make_base_client(self):
        from boarddata._base import Base

        client = Base.__new__(Base)
        client._get_token = MagicMock(return_value="fake-token")
        client.base_url = "https://api.example.com"
        client.timeout = 30
        return client

    def test_returns_list_on_success(self):
        c = self._make_base_client()
        payload = [{"id": "row1"}, {"id": "row2"}]
        mock_resp = _make_response(200, payload)
        with patch("requests.request", return_value=mock_resp) as mock_req:
            result = c._get_export("director/export/")
        assert result == payload
        args, kwargs = mock_req.call_args
        assert args[0] == "GET"
        assert "director/export/" in args[1]

    def test_raises_export_too_large_on_413(self):
        c = self._make_base_client()
        body = {"row_count": 1500, "cap": 100, "message": "Too many rows"}
        mock_resp = _make_response(413, body)
        with patch("requests.request", return_value=mock_resp):
            with pytest.raises(ExportTooLargeError) as exc_info:
                c._get_export("director/export/")
        err = exc_info.value
        assert err.row_count == 1500
        assert err.cap == 100
        assert "Too many rows" in str(err)

    def test_raises_board_data_error_on_500(self):
        c = self._make_base_client()
        body = {"detail": "Server error"}
        mock_resp = _make_response(500, body)
        with patch("requests.request", return_value=mock_resp):
            with pytest.raises(BoardDataError) as exc_info:
                c._get_export("director/export/")
        assert exc_info.value.status_code == 500

    def test_drops_none_params(self):
        c = self._make_base_client()
        mock_resp = _make_response(200, [])
        with patch("requests.request", return_value=mock_resp) as mock_req:
            c._get_export("director/export/", company="uuid1", person=None)
        _, kwargs = mock_req.call_args
        assert kwargs["params"] == {"company": "uuid1"}

    def test_passes_no_params_when_all_none(self):
        c = self._make_base_client()
        mock_resp = _make_response(200, [])
        with patch("requests.request", return_value=mock_resp) as mock_req:
            c._get_export("director/export/", company=None)
        _, kwargs = mock_req.call_args
        assert kwargs["params"] is None


# ---------------------------------------------------------------------------
# Directors export
# ---------------------------------------------------------------------------

class TestExportDirectors:
    def _client(self):
        from boarddata._directors import DirectorMixin
        return _make_client_for(DirectorMixin)

    def test_success_returns_list(self):
        c = self._client()
        rows = [{"id": "m1", "title": "Director"}]
        with patch("requests.request", return_value=_make_response(200, rows)):
            result = c.export_directors(date_from="2024-01-01")
        assert result == rows

    def test_calls_correct_path(self):
        c = self._client()
        with patch("requests.request", return_value=_make_response(200, [])) as mock_req:
            c.export_directors()
        args, _ = mock_req.call_args
        assert "director/export/" in args[1]

    def test_passes_filters(self):
        c = self._client()
        with patch("requests.request", return_value=_make_response(200, [])) as mock_req:
            c.export_directors(company="comp-uuid", nature="REAL")
        _, kwargs = mock_req.call_args
        assert kwargs["params"]["company"] == "comp-uuid"
        assert kwargs["params"]["nature"] == "REAL"

    def test_too_large_raises_export_too_large_error(self):
        c = self._client()
        body = {"row_count": 2000, "cap": 500, "message": "Too many rows"}
        with patch("requests.request", return_value=_make_response(413, body)):
            with pytest.raises(ExportTooLargeError) as exc_info:
                c.export_directors()
        assert exc_info.value.row_count == 2000
        assert exc_info.value.cap == 500


# ---------------------------------------------------------------------------
# Comex export
# ---------------------------------------------------------------------------

class TestExportComex:
    def _client(self):
        from boarddata._comex import ComexMixin
        return _make_client_for(ComexMixin)

    def test_success_returns_list(self):
        c = self._client()
        rows = [{"id": "cm1", "compensations": []}]
        with patch("requests.request", return_value=_make_response(200, rows)):
            result = c.export_comex()
        assert result == rows

    def test_calls_correct_path(self):
        c = self._client()
        with patch("requests.request", return_value=_make_response(200, [])) as mock_req:
            c.export_comex(company="c1")
        args, _ = mock_req.call_args
        assert "comex/export/" in args[1]

    def test_passes_nature_filter(self):
        c = self._client()
        with patch("requests.request", return_value=_make_response(200, [])) as mock_req:
            c.export_comex(nature="POLITIC")
        _, kwargs = mock_req.call_args
        assert kwargs["params"]["nature"] == "POLITIC"

    def test_too_large_raises_export_too_large_error(self):
        c = self._client()
        body = {"row_count": 1200, "cap": 500, "message": "Too many rows"}
        with patch("requests.request", return_value=_make_response(413, body)):
            with pytest.raises(ExportTooLargeError) as exc_info:
                c.export_comex()
        assert exc_info.value.row_count == 1200


# ---------------------------------------------------------------------------
# Auditors export
# ---------------------------------------------------------------------------

class TestExportAuditors:
    def _client(self):
        from boarddata._auditors import AuditorMixin
        return _make_client_for(AuditorMixin)

    def test_success_returns_list(self):
        c = self._client()
        rows = [{"id": "a1", "fees": {}}]
        with patch("requests.request", return_value=_make_response(200, rows)):
            result = c.export_auditors()
        assert result == rows

    def test_calls_correct_path(self):
        c = self._client()
        with patch("requests.request", return_value=_make_response(200, [])) as mock_req:
            c.export_auditors(company="comp1")
        args, _ = mock_req.call_args
        assert "auditors/export/" in args[1]

    def test_passes_company_filter(self):
        c = self._client()
        with patch("requests.request", return_value=_make_response(200, [])) as mock_req:
            c.export_auditors(company="comp-uuid", auditor_type="statutory")
        _, kwargs = mock_req.call_args
        assert kwargs["params"]["company"] == "comp-uuid"
        assert kwargs["params"]["auditor_type"] == "statutory"

    def test_too_large_raises_export_too_large_error(self):
        c = self._client()
        body = {"row_count": 600, "cap": 100, "message": "Too many rows"}
        with patch("requests.request", return_value=_make_response(413, body)):
            with pytest.raises(ExportTooLargeError) as exc_info:
                c.export_auditors()
        assert exc_info.value.row_count == 600
        assert exc_info.value.cap == 100


# ---------------------------------------------------------------------------
# Assemblies export
# ---------------------------------------------------------------------------

class TestExportAssemblies:
    def _client(self):
        from boarddata._assemblies import AssemblyMixin
        return _make_client_for(AssemblyMixin)

    def test_success_returns_list(self):
        c = self._client()
        rows = [{"id": "asm1", "assembly_type": "OGM"}]
        with patch("requests.request", return_value=_make_response(200, rows)):
            result = c.export_assemblies()
        assert result == rows

    def test_calls_correct_path(self):
        c = self._client()
        with patch("requests.request", return_value=_make_response(200, [])) as mock_req:
            c.export_assemblies()
        args, _ = mock_req.call_args
        assert "assemblies/export/" in args[1]

    def test_passes_filters(self):
        c = self._client()
        with patch("requests.request", return_value=_make_response(200, [])) as mock_req:
            c.export_assemblies(assembly_type="OGM", fiscal_year=2024)
        _, kwargs = mock_req.call_args
        assert kwargs["params"]["assembly_type"] == "OGM"
        assert kwargs["params"]["fiscal_year"] == 2024

    def test_too_large_raises_export_too_large_error(self):
        c = self._client()
        body = {"row_count": 300, "cap": 100, "message": "Over cap"}
        with patch("requests.request", return_value=_make_response(413, body)):
            with pytest.raises(ExportTooLargeError) as exc_info:
                c.export_assemblies()
        assert exc_info.value.row_count == 300


# ---------------------------------------------------------------------------
# Resolutions export
# ---------------------------------------------------------------------------

class TestExportResolutions:
    def _client(self):
        from boarddata._assemblies import AssemblyMixin
        return _make_client_for(AssemblyMixin)

    def test_success_returns_list(self):
        c = self._client()
        rows = [{"id": "r1", "status": "approved"}]
        with patch("requests.request", return_value=_make_response(200, rows)):
            result = c.export_resolutions()
        assert result == rows

    def test_calls_correct_path(self):
        c = self._client()
        with patch("requests.request", return_value=_make_response(200, [])) as mock_req:
            c.export_resolutions(date_from="2024-01-01")
        args, _ = mock_req.call_args
        assert "resolutions/export/" in args[1]

    def test_passes_date_filters(self):
        c = self._client()
        with patch("requests.request", return_value=_make_response(200, [])) as mock_req:
            c.export_resolutions(date_from="2024-01-01", date_to="2024-12-31")
        _, kwargs = mock_req.call_args
        assert kwargs["params"]["date_from"] == "2024-01-01"
        assert kwargs["params"]["date_to"] == "2024-12-31"

    def test_passes_boolean_filters(self):
        c = self._client()
        with patch("requests.request", return_value=_make_response(200, [])) as mock_req:
            c.export_resolutions(rejected=True, is_dissenting=False)
        _, kwargs = mock_req.call_args
        assert kwargs["params"]["rejected"] is True
        assert kwargs["params"]["is_dissenting"] is False

    def test_too_large_raises_export_too_large_error(self):
        c = self._client()
        body = {"row_count": 5000, "cap": 100, "message": "Too many resolutions"}
        with patch("requests.request", return_value=_make_response(413, body)):
            with pytest.raises(ExportTooLargeError) as exc_info:
                c.export_resolutions()
        assert exc_info.value.row_count == 5000


# ---------------------------------------------------------------------------
# ESG benchmark export
# ---------------------------------------------------------------------------

class TestExportESGBenchmark:
    def _client(self):
        from boarddata._esg import ESGMixin
        return _make_client_for(ESGMixin)

    def test_success_returns_list(self):
        c = self._client()
        rows = [{"id": "co1", "iros": [], "transition_plan": None}]
        with patch("requests.request", return_value=_make_response(200, rows)):
            result = c.export_esg_benchmark()
        assert result == rows

    def test_calls_correct_path(self):
        c = self._client()
        with patch("requests.request", return_value=_make_response(200, [])) as mock_req:
            c.export_esg_benchmark(search="Total")
        args, _ = mock_req.call_args
        assert "companies/benchmark/export/" in args[1]

    def test_passes_search_filter(self):
        c = self._client()
        with patch("requests.request", return_value=_make_response(200, [])) as mock_req:
            c.export_esg_benchmark(search="Airbus", has_transition_plan="yes")
        _, kwargs = mock_req.call_args
        assert kwargs["params"]["search"] == "Airbus"
        assert kwargs["params"]["has_transition_plan"] == "yes"

    def test_passes_list_filters(self):
        c = self._client()
        with patch("requests.request", return_value=_make_response(200, [])) as mock_req:
            c.export_esg_benchmark(
                indexes_include=["CAC40", "SBF120"],
                sectors_exclude=["Finance"],
            )
        _, kwargs = mock_req.call_args
        assert kwargs["params"]["indexes_include"] == ["CAC40", "SBF120"]
        assert kwargs["params"]["sectors_exclude"] == ["Finance"]

    def test_too_large_raises_export_too_large_error(self):
        c = self._client()
        body = {"row_count": 800, "cap": 500, "message": "Too many companies"}
        with patch("requests.request", return_value=_make_response(413, body)):
            with pytest.raises(ExportTooLargeError) as exc_info:
                c.export_esg_benchmark()
        assert exc_info.value.row_count == 800


# ---------------------------------------------------------------------------
# Companies export
# ---------------------------------------------------------------------------

class TestExportCompanies:
    def _client(self):
        from boarddata._companies import CompanyMixin
        return _make_client_for(CompanyMixin)

    def test_success_returns_list(self):
        c = self._client()
        rows = [{"id": "co1", "name": "TotalEnergies", "isin": "FR0000120271"}]
        with patch("requests.request", return_value=_make_response(200, rows)):
            result = c.export_companies()
        assert result == rows

    def test_calls_correct_path(self):
        c = self._client()
        with patch("requests.request", return_value=_make_response(200, [])) as mock_req:
            c.export_companies(country="FR")
        args, _ = mock_req.call_args
        assert "companies/export/" in args[1]

    def test_passes_filters(self):
        c = self._client()
        with patch("requests.request", return_value=_make_response(200, [])) as mock_req:
            c.export_companies(country="FR", sector="Energy")
        _, kwargs = mock_req.call_args
        assert kwargs["params"]["country"] == "FR"
        assert kwargs["params"]["sector"] == "Energy"

    def test_too_large_raises_export_too_large_error(self):
        c = self._client()
        body = {"row_count": 200, "cap": 100, "message": "Too many companies"}
        with patch("requests.request", return_value=_make_response(413, body)):
            with pytest.raises(ExportTooLargeError) as exc_info:
                c.export_companies()
        assert exc_info.value.row_count == 200
        assert exc_info.value.cap == 100


# ---------------------------------------------------------------------------
# Persons export
# ---------------------------------------------------------------------------

class TestExportPersons:
    def _client(self):
        from boarddata._persons import PersonMixin
        return _make_client_for(PersonMixin)

    def test_success_returns_list(self):
        c = self._client()
        rows = [{"id": "p1", "first_name": "Marie", "last_name": "Dupont"}]
        with patch("requests.request", return_value=_make_response(200, rows)):
            result = c.export_persons()
        assert result == rows

    def test_calls_correct_path(self):
        c = self._client()
        with patch("requests.request", return_value=_make_response(200, [])) as mock_req:
            c.export_persons(gender="F")
        args, _ = mock_req.call_args
        assert "persons/export/" in args[1]

    def test_passes_filters(self):
        c = self._client()
        with patch("requests.request", return_value=_make_response(200, [])) as mock_req:
            c.export_persons(gender="F", nationality="FR")
        _, kwargs = mock_req.call_args
        assert kwargs["params"]["gender"] == "F"
        assert kwargs["params"]["nationality"] == "FR"

    def test_drops_none_filters(self):
        c = self._client()
        with patch("requests.request", return_value=_make_response(200, [])) as mock_req:
            c.export_persons(search=None, gender="M")
        _, kwargs = mock_req.call_args
        assert "search" not in kwargs["params"]
        assert kwargs["params"]["gender"] == "M"

    def test_too_large_raises_export_too_large_error(self):
        c = self._client()
        body = {"row_count": 1100, "cap": 500, "message": "Too many persons"}
        with patch("requests.request", return_value=_make_response(413, body)):
            with pytest.raises(ExportTooLargeError) as exc_info:
                c.export_persons()
        assert exc_info.value.row_count == 1100
        assert exc_info.value.cap == 500
