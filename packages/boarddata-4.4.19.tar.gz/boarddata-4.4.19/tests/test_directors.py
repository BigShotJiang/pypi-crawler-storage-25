"""Tests for DirectorMixin methods."""
from __future__ import annotations

from unittest.mock import MagicMock


def make_client():
    from boarddata._directors import DirectorMixin
    from boarddata._base import Base

    class TestClient(DirectorMixin, Base):
        pass

    client = TestClient.__new__(TestClient)
    client._request = MagicMock()
    client._get_token = MagicMock(return_value="fake-token")
    client.base_url = "https://api.example.com"
    client.timeout = 30
    return client


class TestListDirectors:
    def test_passes_common_filters(self):
        c = make_client()
        c._request.return_value = {"count": 0, "results": []}
        c.list_directors(company="uuid1", person="uuid2", page=1)
        _, kwargs = c._request.call_args
        assert kwargs["params"]["company"] == "uuid1"
        assert kwargs["params"]["person"] == "uuid2"

    def test_passes_advanced_filters(self):
        c = make_client()
        c._request.return_value = {"count": 0, "results": []}
        c.list_directors(indexes="CAC40", gender="F", independence="yes")
        _, kwargs = c._request.call_args
        assert kwargs["params"]["indexes"] == "CAC40"
        assert kwargs["params"]["gender"] == "F"

    def test_passes_expiring_year(self):
        c = make_client()
        c._request.return_value = {"count": 0, "results": []}
        c.list_directors(expiring_year=2026)
        _, kwargs = c._request.call_args
        assert kwargs["params"]["expiring_year"] == 2026


class TestCreateDirectorCompensation:
    def test_sends_token_fields(self):
        c = make_client()
        c._request.return_value = {"id": "comp1", "fiscal_year": 2024}
        c.create_director_compensation(
            "dir-uuid", 2024, "REAL", token_personal="15000.00", currency="EUR"
        )
        _, kwargs = c._request.call_args
        payload = kwargs["json"]
        assert payload["token_personal"] == "15000.00"
        assert payload["nature"] == "REAL"
        assert "fixed" not in payload  # comex field, not board


class TestUpsertDirector:
    def test_returns_upsert_result(self):
        c = make_client()
        c._request.side_effect = [
            {"count": 0, "results": []},
            {"id": "new-uuid", "title": "Director"},
        ]
        result = c.upsert_director("comp-uuid", "pers-uuid", title="Director")
        assert result["action"] == "created"
        assert result["id"] == "new-uuid"

    def test_sends_roles(self):
        c = make_client()
        c._request.side_effect = [
            {"count": 0, "results": []},
            {"id": "new-uuid"},
        ]
        c.upsert_director(
            "comp-uuid",
            "pers-uuid",
            title="Chairman",
            roles=["Independent", "Chairman"],
        )
        _, kwargs = c._request.call_args
        payload = kwargs["json"]
        assert payload["roles"] == ["Independent", "Chairman"]

    def test_omits_roles_when_not_set(self):
        c = make_client()
        c._request.side_effect = [
            {"count": 0, "results": []},
            {"id": "new-uuid"},
        ]
        c.upsert_director("comp-uuid", "pers-uuid", title="Director")
        _, kwargs = c._request.call_args
        payload = kwargs["json"]
        assert "roles" not in payload


class TestUpdateDirector:
    def test_sends_roles(self):
        c = make_client()
        c._request.return_value = {"id": "dir-uuid"}
        c.update_director(
            "dir-uuid",
            roles=["Independent"],
        )
        _, kwargs = c._request.call_args
        payload = kwargs["json"]
        assert payload["roles"] == ["Independent"]
        assert "is_chairman" not in payload
        assert "is_lead_independent" not in payload


class TestListDirectorsRoles:
    def test_passes_roles_as_comma_string(self):
        c = make_client()
        c._request.return_value = {"count": 0, "results": []}
        c.list_directors(roles=["Independent", "Chairman"])
        _, kwargs = c._request.call_args
        assert kwargs["params"]["roles"] == "Independent,Chairman"

    def test_passes_role_at(self):
        c = make_client()
        c._request.return_value = {"count": 0, "results": []}
        c.list_directors(role_at="2024-01-01")
        _, kwargs = c._request.call_args
        assert kwargs["params"]["role_at"] == "2024-01-01"
