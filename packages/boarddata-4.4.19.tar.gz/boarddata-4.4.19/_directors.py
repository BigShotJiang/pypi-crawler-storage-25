"""Board mandate (director) and board compensation methods."""

from __future__ import annotations

import logging
from typing import Any

from .types.core import FieldSourcePayload, PaginatedResponse, UpsertResult
from .types.directors import DirectorCompensationItem, DirectorDetail, DirectorExportItem

logger = logging.getLogger("boarddata")


class DirectorMixin:
    """Board mandate (director) and board compensation API methods.

    .. important:: Board compensations use **token/attendance** fields
       (``token_personal``, ``stock_personal``, ``attendance``, etc.),
       NOT the fixed/variable/stock_options fields used by comex compensations.
       See ``ComexMixin`` for executive compensation.
    """

    # ------------------------------------------------------------------
    # Board mandates
    # ------------------------------------------------------------------

    def list_directors(
        self,
        *,
        company: str | None = None,
        person: str | None = None,
        search: str | None = None,
        search_scope: str | None = None,
        date_from: str | None = None,
        date_to: str | None = None,
        as_of: str | None = None,
        expiring_year: int | None = None,
        nature: str | None = None,
        roles: list[str] | None = None,
        role_at: str | None = None,
        page: int | None = None,
        page_size: int | None = None,
        **kwargs: Any,
    ) -> PaginatedResponse:
        """List board mandates.

        Args:
            company: Filter by company UUID.
            person: Filter by person UUID.
            search: Search by person or company name.
            search_scope: Scope for search (``"person"``, ``"company"``).
            date_from: Filter mandates valid from this date (``"YYYY-MM-DD"``).
            date_to: Filter mandates valid to this date (``"YYYY-MM-DD"``).
            as_of: Show mandates active on this date (``"YYYY-MM-DD"``).
            expiring_year: Keep only mandates whose ``valid_to`` falls inside
                the given calendar year. Strictly excludes mandates with
                ``valid_to IS NULL`` (still active).
            nature: Filter by compensation nature (``"REAL"`` or ``"POLITIC"``).
            roles: Filter by role identifiers (e.g. ``["Independent", "Chairman"]``).
            role_at: Filter for mandates that held a role at this date (``"YYYY-MM-DD"``).
            page: Page number (1-indexed).
            page_size: Results per page.
            **kwargs: Advanced filters — ``indexes``, ``sectors``, ``headquarters``,
                ``governance_code``, ``floating``, ``turnover``, ``gender``,
                ``nationality``, ``age``, ``appointment_method``, ``committee_type``,
                ``fiscal_year``, ``validity_interval``, and all ``_exclude`` variants.

        Returns:
            PaginatedResponse with ``results`` list of DirectorListItem.

        Raises:
            BoardDataError: On non-2xx API response.
        """
        params: dict[str, Any] = {}
        if roles:
            params["roles"] = ",".join(roles)
        return self._get(  # type: ignore[attr-defined]
            "director/",
            company=company,
            person=person,
            search=search,
            search_scope=search_scope,
            date_from=date_from,
            date_to=date_to,
            as_of=as_of,
            expiring_year=expiring_year,
            nature=nature,
            role_at=role_at,
            page=page,
            page_size=page_size,
            **params,
            **kwargs,
        )

    def get_director(self, uid: str) -> DirectorDetail:
        """Retrieve a board mandate by UUID.

        Args:
            uid: Director mandate UUID.

        Returns:
            DirectorDetail with full mandate data.

        Raises:
            BoardDataError: On non-2xx API response.
        """
        return self._get(f"director/{uid}/")  # type: ignore[attr-defined]

    def create_director(
        self,
        company: str,
        person: str,
        *,
        title: str | None = None,
        valid_from: str | None = None,
        valid_to: str | None = None,
        roles: list[str] | None = None,
        appointment_method: str | None = None,
        entity_type: str | None = None,
        representative_name: str | None = None,
        cause_end: str | None = None,
        field_sources: list[FieldSourcePayload] | None = None,
    ) -> DirectorDetail:
        """Create a board mandate.

        Args:
            company: Company UUID.
            person: Person UUID.
            title: Mandate title/role.
            valid_from: Start date (``"YYYY-MM-DD"``).
            valid_to: End date (``"YYYY-MM-DD"``) or None if current.
            roles: List of role identifiers (e.g. ``["Independent", "Chairman"]``).
            appointment_method: How they were appointed.
            entity_type: Entity type (physical, legal).
            representative_name: Name of legal entity representative.
            cause_end: Reason the mandate ended.
            field_sources: Document provenance for fields.

        Returns:
            Created DirectorDetail.

        Raises:
            BoardDataError: On non-2xx API response.
        """
        payload = self._build_payload(  # type: ignore[attr-defined]
            company=company,
            person=person,
            title=title,
            valid_from=valid_from,
            valid_to=valid_to,
            roles=roles,
            appointment_method=appointment_method,
            entity_type=entity_type,
            representative_name=representative_name,
            cause_end=cause_end,
            field_sources=field_sources,
        )
        return self._post("director/", payload)  # type: ignore[attr-defined]

    def update_director(
        self,
        uid: str,
        *,
        title: str | None = None,
        valid_from: str | None = None,
        valid_to: str | None = None,
        roles: list[str] | None = None,
        appointment_method: str | None = None,
        entity_type: str | None = None,
        representative_name: str | None = None,
        cause_end: str | None = None,
        field_sources: list[FieldSourcePayload] | None = None,
    ) -> DirectorDetail:
        """Partial update a board mandate.

        Args:
            uid: Director mandate UUID.
            title: Mandate title/role.
            valid_from: Start date (``"YYYY-MM-DD"``).
            valid_to: End date (``"YYYY-MM-DD"``).
            roles: List of role identifiers (e.g. ``["Independent", "Chairman"]``).
            appointment_method: How they were appointed.
            entity_type: Entity type.
            representative_name: Name of legal entity representative.
            cause_end: Reason the mandate ended.
            field_sources: Document provenance for fields.

        Returns:
            Updated DirectorDetail.

        Raises:
            BoardDataError: On non-2xx API response.
        """
        payload = self._build_payload(  # type: ignore[attr-defined]
            title=title,
            valid_from=valid_from,
            valid_to=valid_to,
            roles=roles,
            appointment_method=appointment_method,
            entity_type=entity_type,
            representative_name=representative_name,
            cause_end=cause_end,
            field_sources=field_sources,
        )
        return self._patch(f"director/{uid}/", payload)  # type: ignore[attr-defined]

    def delete_director(self, uid: str) -> None:
        """Soft-delete a board mandate.

        Args:
            uid: Director mandate UUID.

        Raises:
            BoardDataError: On non-2xx API response.
        """
        self._delete(f"director/{uid}/")  # type: ignore[attr-defined]

    def export_directors(
        self,
        *,
        company: str | None = None,
        person: str | None = None,
        search: str | None = None,
        search_scope: str | None = None,
        date_from: str | None = None,
        date_to: str | None = None,
        as_of: str | None = None,
        expiring_year: int | None = None,
        nature: str | None = None,
        **kwargs: Any,
    ) -> list[DirectorExportItem]:
        """Export board mandates as a flat list (up to the server's row cap).

        Accepts the same filters as ``list_directors``. Returns all matching
        rows without pagination. The server applies French-locale number
        formatting to numeric fields.

        Args:
            company: Filter by company UUID.
            person: Filter by person UUID.
            search: Search by person or company name.
            search_scope: Scope for search (``"person"``, ``"company"``).
            date_from: Filter mandates valid from this date (``"YYYY-MM-DD"``).
            date_to: Filter mandates valid to this date (``"YYYY-MM-DD"``).
            as_of: Show mandates active on this date (``"YYYY-MM-DD"``).
            expiring_year: Keep only mandates expiring in the given year.
            nature: Filter by compensation nature (``"REAL"`` or ``"POLITIC"``).
            **kwargs: Advanced filters forwarded as query params.

        Returns:
            List of DirectorExportItem dicts.

        Raises:
            ExportTooLargeError: When the result set exceeds the server cap.
            BoardDataError: On any other non-2xx response.
        """
        return self._get_export(  # type: ignore[attr-defined]
            "director/export/",
            company=company,
            person=person,
            search=search,
            search_scope=search_scope,
            date_from=date_from,
            date_to=date_to,
            as_of=as_of,
            expiring_year=expiring_year,
            nature=nature,
            **kwargs,
        )

    def get_director_stats(self, **params: Any) -> Any:
        """Get board mandate statistics.

        Args:
            company: Filter by company UUID.
            fiscal_year: Filter by fiscal year.

        Returns:
            Dict with board mandate statistics (counts, averages, etc.).

        Raises:
            BoardDataError: On non-2xx API response.
        """
        return self._get("director/stats/", **params)  # type: ignore[attr-defined]

    # ------------------------------------------------------------------
    # Board compensations
    # ------------------------------------------------------------------

    def list_director_compensations(self, director_uid: str, **params: Any) -> PaginatedResponse:
        """List compensations for a board mandate.

        Args:
            director_uid: Director mandate UUID.
            fiscal_year: Filter by fiscal year.
            nature: Filter by compensation nature (``"REAL"`` or ``"POLITIC"``).
            page: Page number.
            page_size: Results per page.

        Returns:
            Paginated response with DirectorCompensationItem results.

        Raises:
            BoardDataError: On non-2xx API response.
        """
        return self._get(f"director/{director_uid}/compensations/", **params)  # type: ignore[attr-defined]

    def get_director_compensation(self, director_uid: str, pk: str) -> DirectorCompensationItem:
        """Retrieve a single director compensation.

        Args:
            director_uid: Director mandate UUID.
            pk: Compensation entry ID.

        Returns:
            DirectorCompensationItem with full compensation data.

        Raises:
            BoardDataError: On non-2xx API response.
        """
        return self._get(f"director/{director_uid}/compensations/{pk}/")  # type: ignore[attr-defined]

    def create_director_compensation(
        self,
        director_uid: str,
        fiscal_year: int,
        nature: str,
        *,
        assembly: str | None = None,
        token_personal: str | None = None,
        token_personal_paid: str | None = None,
        token_company: str | None = None,
        token_company_paid: str | None = None,
        token_others: str | None = None,
        token_others_paid: str | None = None,
        token_others_explain: str | None = None,
        stock_personal: str | None = None,
        stock_company: str | None = None,
        attendance: str | None = None,
        ratio_average: str | None = None,
        ratio_median: str | None = None,
        bsa: str | None = None,
        bsaar: str | None = None,
        bspce: str | None = None,
        collective: str | None = None,
        benefits_in_kind: str | None = None,
        currency: str | None = None,
        field_sources: list[FieldSourcePayload] | None = None,
    ) -> DirectorCompensationItem:
        """Create a compensation entry for a board mandate.

        .. important:: Board compensation uses **token/attendance** fields.
           Do NOT pass comex fields (``fixed``, ``variable``, ``stock_options``,
           ``performance_shares``). Use ``create_comex_compensation()`` for those.

        Args:
            director_uid: Director mandate UUID.
            fiscal_year: Fiscal year.
            nature: Compensation nature (``"REAL"`` or ``"POLITIC"``).
            assembly: Assembly UUID.
            token_personal: Personal attendance tokens (decimal).
            token_personal_paid: Personal attendance tokens paid (decimal).
            token_company: Company attendance tokens (decimal).
            token_company_paid: Company attendance tokens paid (decimal).
            token_others: Other attendance tokens (decimal).
            token_others_paid: Other attendance tokens paid (decimal).
            token_others_explain: Explanation for other tokens.
            stock_personal: Personal stock value (decimal).
            stock_company: Company stock value (decimal).
            attendance: Attendance rate (decimal).
            ratio_average: Average pay ratio (decimal).
            ratio_median: Median pay ratio (decimal).
            bsa: BSA value (decimal).
            bsaar: BSAAR value (decimal).
            bspce: BSPCE value (decimal).
            collective: Collective compensation (decimal).
            benefits_in_kind: Benefits in kind (decimal).
            currency: Currency code (e.g. ``"EUR"``).
            field_sources: Document provenance for fields.

        Returns:
            Created DirectorCompensationItem.

        Raises:
            BoardDataError: On non-2xx API response.
        """
        payload = self._build_payload(  # type: ignore[attr-defined]
            fiscal_year=fiscal_year,
            nature=nature,
            assembly=assembly,
            token_personal=token_personal,
            token_personal_paid=token_personal_paid,
            token_company=token_company,
            token_company_paid=token_company_paid,
            token_others=token_others,
            token_others_paid=token_others_paid,
            token_others_explain=token_others_explain,
            stock_personal=stock_personal,
            stock_company=stock_company,
            attendance=attendance,
            ratio_average=ratio_average,
            ratio_median=ratio_median,
            bsa=bsa,
            bsaar=bsaar,
            bspce=bspce,
            collective=collective,
            benefits_in_kind=benefits_in_kind,
            currency=currency,
            field_sources=field_sources,
        )
        return self._post(f"director/{director_uid}/compensations/", payload)  # type: ignore[attr-defined]

    def update_director_compensation(
        self,
        director_uid: str,
        pk: str,
        *,
        fiscal_year: int | None = None,
        nature: str | None = None,
        assembly: str | None = None,
        token_personal: str | None = None,
        token_personal_paid: str | None = None,
        token_company: str | None = None,
        token_company_paid: str | None = None,
        token_others: str | None = None,
        token_others_paid: str | None = None,
        token_others_explain: str | None = None,
        stock_personal: str | None = None,
        stock_company: str | None = None,
        attendance: str | None = None,
        ratio_average: str | None = None,
        ratio_median: str | None = None,
        bsa: str | None = None,
        bsaar: str | None = None,
        bspce: str | None = None,
        collective: str | None = None,
        benefits_in_kind: str | None = None,
        currency: str | None = None,
        field_sources: list[FieldSourcePayload] | None = None,
    ) -> DirectorCompensationItem:
        """Partial update a director compensation.

        Args:
            director_uid: Director mandate UUID.
            pk: Compensation entry ID.
            (All other args same as create_director_compensation, all optional.)

        Returns:
            Updated DirectorCompensationItem.

        Raises:
            BoardDataError: On non-2xx API response.
        """
        payload = self._build_payload(  # type: ignore[attr-defined]
            fiscal_year=fiscal_year,
            nature=nature,
            assembly=assembly,
            token_personal=token_personal,
            token_personal_paid=token_personal_paid,
            token_company=token_company,
            token_company_paid=token_company_paid,
            token_others=token_others,
            token_others_paid=token_others_paid,
            token_others_explain=token_others_explain,
            stock_personal=stock_personal,
            stock_company=stock_company,
            attendance=attendance,
            ratio_average=ratio_average,
            ratio_median=ratio_median,
            bsa=bsa,
            bsaar=bsaar,
            bspce=bspce,
            collective=collective,
            benefits_in_kind=benefits_in_kind,
            currency=currency,
            field_sources=field_sources,
        )
        return self._patch(f"director/{director_uid}/compensations/{pk}/", payload)  # type: ignore[attr-defined]

    def delete_director_compensation(self, director_uid: str, pk: str) -> None:
        """Delete a director compensation.

        Args:
            director_uid: Director mandate UUID.
            pk: Compensation entry ID.

        Raises:
            BoardDataError: On non-2xx API response.
        """
        self._delete(f"director/{director_uid}/compensations/{pk}/")  # type: ignore[attr-defined]

    # ------------------------------------------------------------------
    # Upsert
    # ------------------------------------------------------------------

    def upsert_director(
        self,
        company: str,
        person: str,
        *,
        title: str | None = None,
        valid_from: str | None = None,
        valid_to: str | None = None,
        roles: list[str] | None = None,
        appointment_method: str | None = None,
        entity_type: str | None = None,
        representative_name: str | None = None,
        cause_end: str | None = None,
        field_sources: list[FieldSourcePayload] | None = None,
    ) -> UpsertResult:
        """Find board mandate by company+person+validity, create or update.

        Args:
            company: Company UUID.
            person: Person UUID.
            title: Mandate title/role.
            valid_from: Start date (``"YYYY-MM-DD"``).
            valid_to: End date (``"YYYY-MM-DD"``).
            roles: List of role identifiers (e.g. ``["Independent", "Chairman"]``).
            appointment_method: How they were appointed.
            entity_type: Entity type.
            representative_name: Name of legal entity representative.
            cause_end: Reason the mandate ended.
            field_sources: Document provenance for fields.

        Returns:
            UpsertResult::

                {"action": "created", "id": "uuid", "data": {<DirectorDetail>}}

        Raises:
            BoardDataError: On non-2xx API response.
        """
        resp = self.list_directors(
            company=company,
            person=person,
            valid_from=valid_from,
            valid_to=valid_to,
        )
        results = resp.get("results", []) if isinstance(resp, dict) else resp
        existing = results[0] if results else None

        payload = self._build_payload(  # type: ignore[attr-defined]
            company=company,
            person=person,
            title=title,
            valid_from=valid_from,
            valid_to=valid_to,
            roles=roles,
            appointment_method=appointment_method,
            entity_type=entity_type,
            representative_name=representative_name,
            cause_end=cause_end,
            field_sources=field_sources,
        )

        if existing:
            director_uid = existing["id"]
            logger.info("Updating director mandate %s", director_uid)
            data = self._patch(f"director/{director_uid}/", payload)  # type: ignore[attr-defined]
            return UpsertResult(action="updated", id=director_uid, data=data)

        logger.info("Creating director mandate")
        data = self._post("director/", payload)  # type: ignore[attr-defined]
        return UpsertResult(action="created", id=data["id"], data=data)
