"""Assembly, Resolution, Presentation, and Question types."""

from __future__ import annotations

try:
    from typing import Any, NotRequired, TypedDict
except ImportError:
    from typing_extensions import Any, NotRequired, TypedDict

from .core import FieldSourcePayload


class _CompanySummary(TypedDict):
    id: str
    name: str


# -- Lookup tables --

class ResolutionTypeItem(TypedDict):
    id: int
    code: str
    name: str
    category: str
    majority_type: str


class PresentationCategoryItem(TypedDict):
    id: int
    name: str


class QuestionThemeItem(TypedDict):
    id: int
    name: str
    category: str


# -- Resolutions --

class ResolutionInline(TypedDict):
    id: str
    number: int
    number_or_letter: str
    resolution_type: ResolutionTypeItem
    description: str
    status: str
    approval_rate: str | None
    votes_for: int | None
    votes_against: int | None
    abstentions: int | None
    is_shareholder_proposal: bool
    is_dissenting: bool
    is_agreed: bool


class ResolutionListItem(TypedDict):
    id: str
    number: int
    number_or_letter: str
    resolution_type: ResolutionTypeItem
    description: str
    status: str
    approval_rate: str | None
    score_scenario_two: str | None
    votes_for: int | None
    votes_against: int | None
    abstentions: int | None
    is_shareholder_proposal: bool
    is_dissenting: bool
    is_agreed: bool
    company_name: str
    company_id: str | None
    company_sectors: str
    company_indexes: str
    assembly_date: str | None
    postponed_date: str | None


class ResolutionDetail(TypedDict):
    """Same as ResolutionListItem for now — retrieve uses same serializer."""
    id: str
    number: int
    number_or_letter: str
    resolution_type: ResolutionTypeItem
    description: str
    status: str
    approval_rate: str | None
    score_scenario_two: str | None
    votes_for: int | None
    votes_against: int | None
    abstentions: int | None
    is_shareholder_proposal: bool
    is_dissenting: bool
    is_agreed: bool
    company_name: str
    company_id: str | None
    company_sectors: str
    company_indexes: str
    assembly_date: str | None
    postponed_date: str | None


class CreateResolutionPayload(TypedDict):
    """Used with POST assemblies/{uid}/resolutions/ (batch upsert endpoint)."""
    number_or_letter: str
    resolution_type_id: int  # Uses ResolutionUpsertSerializer which expects _id suffix
    description: NotRequired[str]
    status: NotRequired[str]
    approval_rate: NotRequired[str | None]
    votes_for: NotRequired[int | None]
    votes_against: NotRequired[int | None]
    abstentions: NotRequired[int | None]
    is_shareholder_proposal: NotRequired[bool]
    is_dissenting: NotRequired[bool]
    is_agreed: NotRequired[bool]
    majority: NotRequired[str]
    source_page: NotRequired[int | None]
    text: NotRequired[str]
    entities: NotRequired[list[dict[str, Any]]]


class UpdateResolutionPayload(TypedDict, total=False):
    number_or_letter: str
    resolution_type: int
    description: str
    status: str
    approval_rate: str | None
    votes_for: int | None
    votes_against: int | None
    abstentions: int | None
    is_shareholder_proposal: bool
    is_dissenting: bool
    is_agreed: bool


class ResolutionTypeStats(TypedDict):
    resolution_type: str
    avg_approval_rate: str | None
    count: int


# -- Presentations --

class PresentationItem(TypedDict):
    id: str
    assembly: str
    speaker: str
    role: str
    topic: str
    category: PresentationCategoryItem
    key_points: list[str]
    start_time: str | None
    end_time: str | None
    duration: str | None
    position: int


class CreatePresentationPayload(TypedDict):
    speaker: str
    topic: str
    category: str
    role: NotRequired[str]
    key_points: NotRequired[list[str]]
    start_time: NotRequired[str | None]
    end_time: NotRequired[str | None]
    duration: NotRequired[str | None]


class UpdatePresentationPayload(TypedDict, total=False):
    speaker: str
    topic: str
    category: str
    role: str
    key_points: list[str]
    start_time: str | None
    end_time: str | None
    duration: str | None


# -- Questions --

class QuestionItem(TypedDict):
    id: str
    assembly: str
    questioner: str | None
    company: _CompanySummary | None
    question_type: str
    question_verbatim: str
    question_translation_en: str
    answer_verbatim: str
    answer_summary_en: str
    answer_author: str
    theme: QuestionThemeItem
    language: str
    start_time: str | None
    end_time: str | None
    position: int


class CreateQuestionPayload(TypedDict):
    question_type: str
    question_verbatim: str
    theme: str
    questioner: NotRequired[str | None]
    company_id: NotRequired[str | None]
    company_name: NotRequired[str]
    question_translation_en: NotRequired[str]
    answer_verbatim: NotRequired[str]
    answer_summary_en: NotRequired[str]
    answer_author: NotRequired[str]
    language: NotRequired[str]
    start_time: NotRequired[str | None]
    end_time: NotRequired[str | None]


class UpdateQuestionPayload(TypedDict, total=False):
    questioner: str | None
    company_id: str | None
    company_name: str
    question_type: str
    question_verbatim: str
    question_translation_en: str
    answer_verbatim: str
    answer_summary_en: str
    answer_author: str
    theme: str
    language: str
    start_time: str | None
    end_time: str | None


# -- Assembly documents (nested, read-only) --

class _AssemblyDocumentInline(TypedDict):
    id: str
    url: str
    title: str
    document_type: str
    category: str
    doc_type: str


# -- Assemblies --

class AssemblyListItem(TypedDict):
    id: str
    company: _CompanySummary
    assembly_date: str
    assembly_type: str
    fiscal_year: int
    postponed_date: str | None
    motivation: str
    quorum: str | None
    attendee_count: int | None
    present_count: int | None
    remote_count: int | None
    questions_count: int
    duration: str | None
    resolution_count: int
    format: str
    is_virtual: bool
    is_in_person: bool
    is_hybrid: bool
    closed_doors: bool
    rejected_count: int
    dissenting_count: int
    low_score_count: int
    company_sectors: str
    company_indexes: str


class AssemblyDetail(TypedDict):
    id: str
    company: _CompanySummary
    assembly_date: str
    assembly_type: str
    fiscal_year: int
    postponed_date: str | None
    date_not_certified: bool
    motivation: str
    agenda: str
    report: str
    report_purpose: str
    quorum: str | None
    attendee_count: int | None
    includes_abstention: bool
    present_count: int | None
    remote_count: int | None
    questions_count: int
    written_questions_count: int
    questions_duration: str | None
    duration: str | None
    resolution_count: int
    format: str
    is_virtual: bool
    is_in_person: bool
    is_hybrid: bool
    has_live_voting: bool
    has_replay: bool
    has_live_qa: bool
    has_video: bool
    has_audio: bool
    has_simultaneous_translation: bool
    closed_doors: bool
    balo_published: bool
    dividend_affected: bool
    rejected_count: int
    dissenting_count: int
    low_score_count: int
    report_html: str
    report_text: str
    agenda_html: str
    gift_description: str
    food_description: str
    time_allocation: dict[str, Any]
    resolutions: list[ResolutionInline]
    assembly_documents: list[_AssemblyDocumentInline]


class CreateAssemblyPayload(TypedDict):
    company: str
    assembly_date: str
    assembly_type: str
    fiscal_year: int
    postponed_date: NotRequired[str | None]
    date_not_certified: NotRequired[bool]
    motivation: NotRequired[str]
    agenda: NotRequired[str]
    report: NotRequired[str]
    report_purpose: NotRequired[str]
    quorum: NotRequired[str | None]
    attendee_count: NotRequired[int | None]
    includes_abstention: NotRequired[bool]
    present_count: NotRequired[int | None]
    remote_count: NotRequired[int | None]
    questions_count: NotRequired[int]
    written_questions_count: NotRequired[int]
    questions_duration: NotRequired[str | None]
    duration: NotRequired[str | None]
    resolution_count: NotRequired[int]
    format: NotRequired[str]
    is_virtual: NotRequired[bool]
    is_in_person: NotRequired[bool]
    is_hybrid: NotRequired[bool]
    has_live_voting: NotRequired[bool]
    has_replay: NotRequired[bool]
    has_live_qa: NotRequired[bool]
    has_video: NotRequired[bool]
    has_audio: NotRequired[bool]
    has_simultaneous_translation: NotRequired[bool]
    closed_doors: NotRequired[bool]
    balo_published: NotRequired[bool]
    dividend_affected: NotRequired[bool]
    field_sources: NotRequired[list[FieldSourcePayload]]


class UpdateAssemblyPayload(TypedDict, total=False):
    assembly_date: str
    assembly_type: str
    fiscal_year: int
    postponed_date: str | None
    date_not_certified: bool
    motivation: str
    agenda: str
    report: str
    report_purpose: str
    quorum: str | None
    attendee_count: int | None
    includes_abstention: bool
    present_count: int | None
    remote_count: int | None
    questions_count: int
    written_questions_count: int
    questions_duration: str | None
    duration: str | None
    resolution_count: int
    format: str
    is_virtual: bool
    is_in_person: bool
    is_hybrid: bool
    has_live_voting: bool
    has_replay: bool
    has_live_qa: bool
    has_video: bool
    has_audio: bool
    has_simultaneous_translation: bool
    closed_doors: bool
    balo_published: bool
    dividend_affected: bool


class AssemblyStats(TypedDict):
    """Dynamic shape based on query params."""
    pass


# -- Export --

class AssemblyExportItem(TypedDict, total=False):
    """Row shape returned by GET /api/assemblies/export/.

    Mirrors ``AssemblyListSerializer``.
    """

    id: str
    company: _CompanySummary
    assembly_date: str
    assembly_type: str
    fiscal_year: int
    postponed_date: str | None
    motivation: str
    quorum: str | None
    attendee_count: int | None
    present_count: int | None
    remote_count: int | None
    questions_count: int
    duration: str | None
    resolution_count: int
    format: str
    is_virtual: bool
    is_in_person: bool
    is_hybrid: bool
    closed_doors: bool
    rejected_count: int
    dissenting_count: int
    low_score_count: int
    company_sectors: str
    company_indexes: str


class ResolutionExportItem(TypedDict, total=False):
    """Row shape returned by GET /api/resolutions/export/.

    Mirrors ``ResolutionListSerializer``.
    """

    id: str
    number: int
    number_or_letter: str
    resolution_type: ResolutionTypeItem
    description: str
    status: str
    approval_rate: str | None
    score_scenario_two: str | None
    votes_for: int | None
    votes_against: int | None
    abstentions: int | None
    is_shareholder_proposal: bool
    is_dissenting: bool
    is_agreed: bool
    company_name: str
    company_id: str | None
    company_sectors: str
    company_indexes: str
    assembly_date: str | None
    postponed_date: str | None
