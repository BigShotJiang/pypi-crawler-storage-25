"""Auditor mandate and auditor company types."""

from __future__ import annotations

try:
    from typing import NotRequired, TypedDict
except ImportError:
    from typing_extensions import NotRequired, TypedDict

from .core import FieldSourceItem, FieldSourcePayload


class _AuditorCompanySummary(TypedDict):
    id: str
    name: str


class _CompanySummary(TypedDict):
    id: str
    name: str


# -- Auditor companies --

class AuditorCompanyItem(TypedDict):
    id: str
    name: str
    country: str


# -- Auditor compensations --

class AuditorCompensationItem(TypedDict):
    id: str
    fiscal_year: int
    assembly: str | None
    currency: str
    audit: str | None
    related: str | None
    advisory: str | None
    audit_total: str | None
    auditout_total: str | None
    ratio_advisory: str | None
    total_fees: str | None
    _sources: list[FieldSourceItem]


class CreateAuditorCompensationPayload(TypedDict):
    fiscal_year: int
    audit: NotRequired[str | None]
    related: NotRequired[str | None]
    advisory: NotRequired[str | None]
    assembly: NotRequired[str | None]
    currency: NotRequired[str]
    field_sources: NotRequired[list[FieldSourcePayload]]


class UpdateAuditorCompensationPayload(TypedDict, total=False):
    fiscal_year: int
    audit: str | None
    related: str | None
    advisory: str | None
    assembly: str | None
    currency: str
    field_sources: list[FieldSourcePayload]


# -- Auditor mandates --

class AuditorListItem(TypedDict):
    id: str
    auditor_company: _AuditorCompanySummary
    company: _CompanySummary
    auditor_type: str
    title: str
    valid_from: str | None
    valid_to: str | None


class AuditorDetail(TypedDict):
    id: str
    auditor_company: _AuditorCompanySummary
    company: _CompanySummary
    auditor_type: str
    title: str
    valid_from: str | None
    valid_to: str | None
    cause_end: str
    _sources: list[FieldSourceItem]


class AuditorCreateResponse(TypedDict):
    """Server-side upsert response from POST auditors/."""
    id: str
    action: str


class CreateAuditorPayload(TypedDict):
    auditor_company: str
    company: str
    auditor_type: str
    title: NotRequired[str]
    valid_from: NotRequired[str]
    valid_to: NotRequired[str | None]
    cause_end: NotRequired[str]
    field_sources: NotRequired[list[FieldSourcePayload]]


class UpdateAuditorPayload(TypedDict, total=False):
    title: str
    valid_from: str
    valid_to: str | None
    cause_end: str
    field_sources: list[FieldSourcePayload]


# -- Export --

class _AuditorFees(TypedDict, total=False):
    """Fee data for n-1, n-2, n-3 fiscal years relative to a reference year.

    Keys follow the pattern ``<field>_{n1|n2|n3}``.
    """

    comp_id_n1: str | None
    audit_n1: float | None
    related_n1: float | None
    advisory_n1: float | None
    ratio_advisory_n1: float | None
    auditout_total_n1: float | None
    comp_id_n2: str | None
    audit_n2: float | None
    related_n2: float | None
    advisory_n2: float | None
    ratio_advisory_n2: float | None
    comp_id_n3: str | None
    audit_n3: float | None
    related_n3: float | None
    advisory_n3: float | None
    ratio_advisory_n3: float | None


class _AuditorIndexMembership(TypedDict):
    name: str
    display_source_url: str
    membership_id: str


class AuditorExportItem(TypedDict, total=False):
    """Row shape returned by GET /api/auditors/export/.

    Mirrors ``AuditorBenchmarkSerializer`` — mandate + company annotations
    + nested ``fees`` dict with n-1/n-2/n-3 compensation data.
    """

    id: str
    auditor_company: _AuditorCompanySummary
    company: _CompanySummary
    auditor_type: str
    valid_from: str | None
    valid_to: str | None
    company_country: str
    company_sectors: str
    governance_code: str
    company_index: list[_AuditorIndexMembership]
    turnover_eur: str | None
    seniority_years: float | None
    fees: _AuditorFees
