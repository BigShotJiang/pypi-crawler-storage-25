"""Company, Sector, and TemporalAttribute types."""

from __future__ import annotations

try:
    from typing import Any, NotRequired, TypedDict
except ImportError:
    from typing_extensions import Any, NotRequired, TypedDict

from .core import AddressItem, AddressPayload, FieldSourcePayload


# -- Sectors --

class SectorItem(TypedDict):
    id: int
    name: str


# -- Temporal Attributes --

class TemporalAttributePayload(TypedDict):
    attribute_type: str
    valid_from: str
    value_decimal: NotRequired[str | None]
    value_text: NotRequired[str]
    field_sources: NotRequired[list[FieldSourcePayload]]


class TemporalAttributeItem(TypedDict):
    attribute_type: str
    valid_from: str
    value_decimal: str | None
    value_text: str


# -- Companies --

class CreateCompanyPayload(TypedDict):
    name: str
    isin: str
    country: NotRequired[str]
    ticker: NotRequired[str]
    logo: NotRequired[str]
    since: NotRequired[str]
    description: NotRequired[str]
    purpose: NotRequired[str]
    website: NotRequired[str]
    governance_code: NotRequired[str]
    sectors: NotRequired[list[int]]
    headquarter: NotRequired[AddressPayload | None]
    field_sources: NotRequired[list[FieldSourcePayload]]


class UpdateCompanyPayload(TypedDict, total=False):
    name: str
    country: str
    isin: str
    ticker: str
    logo: str
    since: str
    description: str
    purpose: str
    website: str
    governance_code: str
    sectors: list[int]
    headquarter: AddressPayload | None
    field_sources: list[FieldSourcePayload]


class CompanyResolveResult(TypedDict):
    id: str
    name: str
    isin: str
    ticker: str
    country: str
    logo: str


class CompanyListItem(TypedDict):
    id: str
    name: str
    country: str
    isin: str
    ticker: str
    logo: str
    since: str | None
    sectors: list[SectorItem]
    indexes: str
    headquarter: AddressItem | None


class _PersonSummary(TypedDict):
    id: str
    first_name: str
    last_name: str


class _MandateInline(TypedDict):
    id: str
    person: _PersonSummary | None
    auditor_company_name: str
    title: str
    valid_from: str | None
    valid_to: str | None
    is_independent: bool
    executive_role: str
    auditor_type: str


class _AssemblyInline(TypedDict):
    id: str
    assembly_date: str
    assembly_type: str
    fiscal_year: int
    quorum: str | None
    resolution_count: int


class CompanyDetail(TypedDict):
    id: str
    name: str
    country: str
    isin: str
    ticker: str
    logo: str
    since: str | None
    description: str
    purpose: str
    website: str
    governance_code: str
    sectors: list[SectorItem]
    headquarter: AddressItem | None
    board_mandates: list[_MandateInline]
    comex_mandates: list[_MandateInline]
    auditor_mandates: list[_MandateInline]
    assemblies: list[_AssemblyInline]


# -- Export --

class CompanyExportItem(TypedDict, total=False):
    """Row shape returned by GET /api/companies/export/.

    Mirrors ``CompanyListSerializer``.
    """

    id: str
    name: str
    country: str
    isin: str
    ticker: str
    logo: str
    since: str | None
    sectors: list[SectorItem]
    indexes: str
    headquarter: AddressItem | None
