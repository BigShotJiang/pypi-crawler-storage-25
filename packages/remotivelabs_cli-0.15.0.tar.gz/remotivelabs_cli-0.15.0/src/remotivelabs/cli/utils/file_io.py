from __future__ import annotations

import importlib
import os
import stat
import tempfile
from contextlib import contextmanager
from pathlib import Path
from typing import Iterator, NoReturn

_RESTRICTIVE_FILE_MODE = stat.S_IRUSR | stat.S_IWUSR  # 0o600
_RESTRICTIVE_DIR_MODE = stat.S_IRWXU  # 0o700


class FilePathError(Exception):
    pass


class FileAccessError(Exception):
    def __init__(self, message: str, *, original: str) -> None:
        super().__init__(f"{message}\nCause: {original}")


HINT_READ = "Often wrong ownership or permissions (e.g. file created while using sudo)."
HINT_MKDIR = "Often missing write access or wrong ownership on a parent folder."
HINT_WRITE = "Often wrong ownership, a read-only file, or permissions (e.g. after using sudo)."
HINT_SET_PERMISSIONS = HINT_READ


def _nearest_existing_path(path: Path) -> Path | None:
    p = path
    for _ in range(64):
        if p.exists():
            return p
        if p == p.parent:
            return None
        p = p.parent
    return None


def owner_mismatch_hint(path: Path) -> str | None:
    geteuid_fn = getattr(os, "geteuid", None)
    if os.name != "posix" or geteuid_fn is None:
        return None

    try:
        euid = geteuid_fn()
        anchor = _nearest_existing_path(path)
        if anchor is None:
            return None

        st = anchor.stat()
        if st.st_uid == euid:
            return None

        pwd = importlib.import_module("pwd")
        getpwuid = getattr(pwd, "getpwuid")
        try:
            owner = getpwuid(st.st_uid).pw_name
            you = getpwuid(euid).pw_name
        except KeyError:
            return f"Owner is uid {st.st_uid}; you are uid {euid}."

        kind = "directory" if anchor.is_dir() else "file"
        return f"{kind.capitalize()} owner is {owner}; you are {you}."

    except Exception:
        return None


def _raise_access_error(
    *,
    path: Path,
    action: str,
    original: OSError,
    hint_suffix: str | None = None,
) -> NoReturn:
    parts = [f"Could not {action}: {path}."]
    if hint_suffix:
        parts.append(hint_suffix)
        owner_hint = owner_mismatch_hint(path)
        if owner_hint:
            parts.append(owner_hint)
    raise FileAccessError(" ".join(parts), original=str(original))


def _is_within_directory(base: Path, target: Path) -> bool:
    try:
        target.resolve().relative_to(base.resolve())
        return True
    except ValueError:
        return False


@contextmanager
def _tmp_file(path: Path) -> Iterator[tuple[int, Path]]:
    """Yield (fd, tmp_path). Cleans up tmp_path on any failure."""
    fd, tmp_name = tempfile.mkstemp(
        prefix=f"{path.name}.",
        suffix=".tmp",
        dir=path.parent,
    )
    tmp_path = Path(tmp_name)
    try:
        yield fd, tmp_path
    finally:
        try:
            tmp_path.unlink(missing_ok=True)
        except OSError:
            pass


def _write_text_atomic(
    *,
    allowed_dir: Path,
    path: Path,
    data: str,
    restrictive: bool,
) -> Path:
    if not _is_within_directory(allowed_dir, path):
        raise FilePathError(f"File {path.resolve()} is not within allowed directory {allowed_dir.resolve()}")

    try:
        path.parent.mkdir(parents=True, exist_ok=True)
    except PermissionError as e:
        _raise_access_error(path=path.parent, action="create parent directory", original=e, hint_suffix=HINT_MKDIR)
    except OSError as e:
        _raise_access_error(path=path.parent, action="create parent directory", original=e)

    try:
        with _tmp_file(path) as (fd, tmp_path):
            if restrictive and os.name == "posix":
                fchmod = getattr(os, "fchmod", None)
                if fchmod is not None:
                    try:
                        fchmod(fd, _RESTRICTIVE_FILE_MODE)
                    except PermissionError as e:
                        _raise_access_error(path=path, action="set permissions", original=e, hint_suffix=HINT_SET_PERMISSIONS)
                    except OSError as e:
                        _raise_access_error(path=path, action="set permissions", original=e)

            with os.fdopen(fd, "w", encoding="utf-8") as f:
                f.write(data)

            os.replace(tmp_path, path)

    except PermissionError as e:
        _raise_access_error(path=path, action="write file", original=e, hint_suffix=HINT_WRITE)
    except OSError as e:
        _raise_access_error(path=path, action="write file", original=e)

    return path


# Public API


def mkdir_p(path: Path) -> None:
    """Create a directory and all its parent directories if they don't exist."""
    try:
        path.mkdir(parents=True, exist_ok=True)
    except PermissionError as e:
        _raise_access_error(path=path, action="create directory", original=e, hint_suffix=HINT_MKDIR)
    except OSError as e:
        _raise_access_error(path=path, action="create directory", original=e)


def read_text(path: Path) -> str:
    try:
        return path.read_text(encoding="utf-8")
    except FileNotFoundError:
        raise FileNotFoundError(f"File could not be found: {path}") from None
    except PermissionError as e:
        _raise_access_error(path=path, action="read file", original=e, hint_suffix=HINT_READ)
    except OSError as e:
        _raise_access_error(path=path, action="read file", original=e)


def write_text(*, allowed_dir: Path, path: Path, data: str) -> Path:
    return _write_text_atomic(
        allowed_dir=allowed_dir,
        path=path,
        data=data,
        restrictive=False,
    )


def write_text_restrictive(*, allowed_dir: Path, path: Path, data: str) -> Path:
    return _write_text_atomic(
        allowed_dir=allowed_dir,
        path=path,
        data=data,
        restrictive=True,
    )


def _check_file_stat(path: Path, st: os.stat_result, euid: int) -> None:
    if stat.S_ISLNK(st.st_mode):
        raise FileAccessError(f"Refusing to load {path}: file is a symlink.", original="symlink rejected")
    if not stat.S_ISREG(st.st_mode):
        raise FileAccessError(f"Refusing to load {path}: not a regular file.", original="non-regular file")
    actual_mode = stat.S_IMODE(st.st_mode)
    if actual_mode != _RESTRICTIVE_FILE_MODE:
        raise FileAccessError(
            f"Refusing to load {path}: permissions {oct(actual_mode)}, expected {oct(_RESTRICTIVE_FILE_MODE)}.",
            original="bad file mode",
        )
    if st.st_uid != euid:
        raise FileAccessError(
            f"Refusing to load {path}: file owner uid {st.st_uid}, current uid {euid}.",
            original="file owner mismatch",
        )


def _check_parent_dir_stat(path: Path, parent: Path, pst: os.stat_result, euid: int) -> None:
    parent_mode = stat.S_IMODE(pst.st_mode)
    if parent_mode != _RESTRICTIVE_DIR_MODE:
        raise FileAccessError(
            f"Refusing to load {path}: parent {parent} permissions {oct(parent_mode)}, expected {oct(_RESTRICTIVE_DIR_MODE)}.",
            original="bad parent mode",
        )
    if pst.st_uid != euid:
        raise FileAccessError(
            f"Refusing to load {path}: parent {parent} owner uid {pst.st_uid}, current uid {euid}.",
            original="parent owner mismatch",
        )


def validate_restrictive_file(*, allowed_dir: Path, path: Path) -> None:
    """Refuse to load *path* unless it is a regular 0600 file owned by user, in *allowed_dir*.

    No-op on non-POSIX platforms (Windows lacks the unix mode/uid model).
    """
    if not _is_within_directory(allowed_dir, path):
        raise FilePathError(f"File {path.resolve()} is not within allowed directory {allowed_dir.resolve()}")

    if os.name != "posix":
        # Windows lacks the unix mode/uid model, but we still verify the file
        # exists so we fail closed if the cert path is broken.
        if not path.exists():
            raise FileNotFoundError(f"File could not be found: {path}")
        return

    geteuid_fn = getattr(os, "geteuid", None)
    if geteuid_fn is None:
        return
    euid = geteuid_fn()

    try:
        st = os.lstat(path)
    except FileNotFoundError:
        raise FileNotFoundError(f"File could not be found: {path}") from None
    except OSError as e:
        _raise_access_error(path=path, action="stat file", original=e, hint_suffix=HINT_READ)

    _check_file_stat(path, st, euid)

    parent = path.parent
    try:
        # lstat (not stat): if parent itself is a symlink, we want the symlink's
        # owner/mode, not the target's — a symlink-swap into an attacker-owned
        # dir would otherwise pass the parent check.
        pst = os.lstat(parent)
    except OSError as e:
        _raise_access_error(path=parent, action="stat directory", original=e, hint_suffix=HINT_READ)

    _check_parent_dir_stat(path, parent, pst, euid)
