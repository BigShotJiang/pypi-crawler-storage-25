from __future__ import annotations

import contextlib
import hashlib
import hmac
import os
import platform
import plistlib
import shutil
import subprocess
import sys
import tarfile
import tempfile
from collections.abc import Callable, Iterator
from dataclasses import dataclass
from importlib.resources import files
from pathlib import Path
from typing import TYPE_CHECKING, BinaryIO, cast

import requests
import semver
import typer
from cryptography.exceptions import InvalidSignature
from cryptography.hazmat.primitives import serialization
from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PublicKey
from rich.progress import wrap_file

# fcntl is POSIX-only. Guarded at runtime; TYPE_CHECKING makes mypy on Windows
# also see the import so use-sites in the POSIX branch type-check on all OSes.
if TYPE_CHECKING or sys.platform != "win32":
    import fcntl

from remotivelabs.cli.utils.console import console, print_generic_error, print_hint

MIN_ELECTRON_APP_VERSION = "0.0.22"
# Release artifacts are uploaded to <RELEASE_BASE_URL>/remotive-studio-desktop-<ver>/<asset>
# by the `remotive-studio-desktop_release.yaml` workflow. The per-version subdir
# matches the GitHub release tag name (`remotive-studio-desktop-<ver>`).
RELEASE_BASE_URL = "https://releases.beamylabs.com/remotive-studio-desktop"

# State dir holds the install lock, the staging/backup dirs used during the
# atomic swap, and the download tempfile. The actual app bundles live in
# OS-conventional locations (see _installed_path).
INSTALL_DIR = Path.home() / ".local" / "share" / "remotive" / "app"
_LOCK_FILE = INSTALL_DIR / ".install.lock"

# Fixed install destinations — same path across versions; updates swap in place.
_MACOS_APP_BUNDLE = Path.home() / "Applications" / "RemotiveStudio.app"
_LINUX_APP_DIR = Path.home() / ".local" / "share" / "remotive-studio-desktop"
_LINUX_BIN_DIR = Path.home() / ".local" / "bin"
_LINUX_BIN_SYMLINK = _LINUX_BIN_DIR / "remotive-studio-desktop"
_LINUX_DESKTOP_DIR = Path.home() / ".local" / "share" / "applications"
_LINUX_DESKTOP_FILE = _LINUX_DESKTOP_DIR / "remotive-studio-desktop.desktop"
_LINUX_ICON_DIR = Path.home() / ".local" / "share" / "icons" / "hicolor" / "512x512" / "apps"
_LINUX_ICON_FILE = _LINUX_ICON_DIR / "remotive-studio-desktop.png"
_LINUX_VERSION_MARKER = ".installed-version"

# Per-artifact integrity sidecars published alongside each tarball:
#   <asset>.sha256      — "<hex-digest>  <asset>"
#   <asset>.sha256.sig  — raw 64-byte Ed25519 signature over the .sha256 file
_SHA256_EXT = ".sha256"
_SIG_EXT = ".sha256.sig"

# The RemotiveLabs release public key is bundled with the CLI package. The
# fingerprint (SHA-256 of the raw 32-byte Ed25519 public key, uppercase hex)
# is pinned in source so a swap of the .pem file alone cannot redirect trust.
# Rotating the signing key requires a CLI release that updates both the
# bundled key *and* this constant.
_RELEASE_KEY_RESOURCE = "release-public-key.pem"
_RELEASE_KEY_FINGERPRINT = "946AE04FEF967D7E3AF65193800092E52BFD4D1CC4B84CD3C3E72B2194EC22A1"


@dataclass(frozen=True)
class _PlatformInfo:
    os: str  # "linux" | "macos"
    arch: str  # "x86_64" | "arm64"
    ext: str  # "tar.gz" | "dmg"


def _is_wsl() -> bool:
    if os.environ.get("WSL_DISTRO_NAME"):
        return True
    try:
        return "microsoft" in Path("/proc/version").read_text().lower()
    except (FileNotFoundError, OSError):
        return False


def _unsupported(detail: str) -> typer.Exit:
    print_generic_error(f"RemotiveStudio Desktop is not supported on {detail}. Supported: Linux (x86_64, arm64), macOS (arm64), WSL2.")
    return typer.Exit(1)


def _detect_platform() -> _PlatformInfo:
    machine = platform.machine().lower()

    if sys.platform == "linux" or _is_wsl():
        if machine in ("x86_64", "amd64"):
            return _PlatformInfo(os="linux", arch="x86_64", ext="tar.gz")
        if machine in ("aarch64", "arm64"):
            return _PlatformInfo(os="linux", arch="arm64", ext="tar.gz")
        raise _unsupported(f"Linux {machine}")

    if sys.platform == "darwin":
        if machine == "arm64":
            return _PlatformInfo(os="macos", arch="arm64", ext="dmg")
        raise _unsupported(f"macOS {machine} (only Apple Silicon / arm64 is supported)")

    if sys.platform.startswith("win"):
        raise _unsupported("native Windows (please use WSL2)")

    raise _unsupported(sys.platform)


def _asset_name(info: _PlatformInfo, version: str) -> str:
    # Naming is OS-specific: Linux tarballs use the electron package name,
    # macOS DMGs use the product name.
    if info.os == "linux":
        return f"remotive-studio-desktop-{version}-{info.arch}.{info.ext}"
    return f"RemotiveStudio-{version}-{info.arch}.{info.ext}"


def _asset_url(info: _PlatformInfo, version: str) -> str:
    """Public URL for a release asset. The workflow lays artifacts out per-tag
    (``remotive-studio-desktop-<ver>/<asset>``); we mirror that path on the host."""
    return f"{RELEASE_BASE_URL}/remotive-studio-desktop-{version}/{_asset_name(info, version)}"


def _installed_path(info: _PlatformInfo) -> Path:
    """Top-level install entry — fixed path, version-independent.

    macOS: ~/Applications/RemotiveStudio.app (visible to Spotlight/Launchpad).
    Linux: ~/.local/share/remotive-studio-desktop (.desktop entry written separately).
    """
    if info.os == "linux":
        return _LINUX_APP_DIR
    return _MACOS_APP_BUNDLE


def _executable_path(info: _PlatformInfo) -> Path:
    """Executable that should be spawned to launch RemotiveStudio Desktop."""
    bundle = _installed_path(info)
    if info.os == "linux":
        return bundle / "RemotiveStudio"
    return bundle / "Contents" / "MacOS" / "RemotiveStudio"


def ensure_app_installed() -> Path:
    """Return the path to a ready-to-launch RemotiveStudio Desktop executable.

    Installs ``MIN_ELECTRON_APP_VERSION`` if no install is present, or if the
    installed version is older.
    """
    info = _detect_platform()

    with _install_lock():
        installed = _read_installed_version(info)
        if installed is None or _semver_lt(installed, MIN_ELECTRON_APP_VERSION):
            _download_and_install(info, MIN_ELECTRON_APP_VERSION)
            _post_install(info)
        elif info.os == "linux" and not _linux_desktop_integration_intact():
            # User deleted the .desktop entry, icon, or bin symlink — restore
            # without redownloading. Skipped on macOS: Launch Services
            # registration self-heals and re-running lsregister on every
            # invocation would be wasteful.
            _post_install(info)

    return _executable_path(info)


@contextlib.contextmanager
def _install_lock() -> Iterator[None]:
    """Serialize concurrent installers via an exclusive flock on the state dir.

    Two parallel ``remotive studio`` invocations could both decide they need to
    update; without a lock they would race on the atomic-swap rename. The
    second invocation blocks until the first finishes, then re-checks the
    installed version and (typically) finds nothing to do.
    """
    INSTALL_DIR.mkdir(parents=True, exist_ok=True)
    if sys.platform == "win32":
        # Unreachable in practice: _detect_platform() rejects native Windows
        # before we ever get here. Kept as a guard so mypy doesn't see the
        # POSIX-only fcntl calls below on Windows.
        yield
        return
    fd = os.open(_LOCK_FILE, os.O_CREAT | os.O_RDWR, 0o600)
    try:
        fcntl.flock(fd, fcntl.LOCK_EX)
        yield
    finally:
        with contextlib.suppress(OSError):
            fcntl.flock(fd, fcntl.LOCK_UN)
        os.close(fd)


def _read_installed_version(info: _PlatformInfo) -> str | None:
    """Read the currently-installed app version, or None if not installed.

    macOS: ``CFBundleShortVersionString`` from ``Contents/Info.plist``.
    Linux: contents of the ``.installed-version`` text file.
    Returns None on any read/parse failure — caller treats that as "needs install".
    """
    bundle = _installed_path(info)
    if not bundle.exists():
        return None

    try:
        if info.os == "macos":
            plist_path = bundle / "Contents" / "Info.plist"
            with open(plist_path, "rb") as fp:
                data = plistlib.load(fp)
            version = data.get("CFBundleShortVersionString")
            return str(version) if version else None

        marker = bundle / _LINUX_VERSION_MARKER
        return marker.read_text().strip() or None
    except (OSError, plistlib.InvalidFileException, ValueError):
        return None


def _semver_lt(a: str, b: str) -> bool:
    """Return True iff version *a* is strictly older than *b*.

    Falls back to string comparison if either side fails to parse — strict
    parsing would mean an install we can't read is treated as equal, which
    would let a stale install hide. We want the opposite: unparseable means
    "reinstall."
    """
    try:
        va = semver.Version.parse(a).finalize_version()
        vb = semver.Version.parse(b).finalize_version()
        return va < vb
    except (ValueError, TypeError):
        return True


def _download_and_install(info: _PlatformInfo, version: str) -> None:
    INSTALL_DIR.mkdir(parents=True, exist_ok=True)
    url = _asset_url(info, version)
    target = _installed_path(info)

    with tempfile.NamedTemporaryFile(dir=INSTALL_DIR, delete=False, suffix=".download") as fp:
        tmp_path = Path(fp.name)
    try:
        try:
            _download_with_progress(url, tmp_path, f"Downloading RemotiveStudio Desktop ({info.arch})")
        except requests.RequestException as e:
            print_generic_error(f"Failed to download {url}: {e}")
            raise typer.Exit(1) from e

        with console.status("Installing..."):
            if info.os == "linux":
                _verify_release(info, version, tmp_path)
                _atomic_install(target, lambda staging: _stage_tarball(tmp_path, staging))
            else:
                # macOS DMGs are not (yet) covered by the per-artifact Ed25519
                # signing pipeline that protects the Linux tarballs. The bundle
                # is ad-hoc signed by electron-builder; Gatekeeper is sidestepped
                # by the no-quarantine install path. See _stage_dmg for the full
                # rationale and what would change if we ever sign + notarize.
                _atomic_install(target, lambda staging: _stage_dmg(tmp_path, staging))
    finally:
        tmp_path.unlink(missing_ok=True)


def _atomic_install(target: Path, stage_into: Callable[[Path], None]) -> None:
    """Build the new install in a staging dir, then swap atomically.

    Order: stage → backup-rename existing target → rename(staging → target)
    → rmtree(backup). On failure between backup and rename, restore the
    backup. The window during which target is "missing" is two syscalls; if
    the user is running the old app it keeps working via inode reference.

    Staging and backup live in INSTALL_DIR — *not* as siblings of target —
    so on macOS Launch Services never sees a ``RemotiveStudio.app.staging``
    bundle to index. Both paths are on the same filesystem (the user's home
    volume), so rename(2) is atomic for the directory move into target.parent.
    """
    target.parent.mkdir(parents=True, exist_ok=True)
    INSTALL_DIR.mkdir(parents=True, exist_ok=True)

    staging = INSTALL_DIR / f".{target.name}.staging"
    backup = INSTALL_DIR / f".{target.name}.backup"
    if staging.exists():
        shutil.rmtree(staging, ignore_errors=True)
    if backup.exists():
        shutil.rmtree(backup, ignore_errors=True)

    try:
        stage_into(staging)
    except Exception:
        if staging.exists():
            shutil.rmtree(staging, ignore_errors=True)
        raise

    target_existed = target.exists()
    if target_existed:
        target.rename(backup)
    try:
        staging.rename(target)
    except Exception:
        if target_existed and backup.exists() and not target.exists():
            backup.rename(target)
        raise
    finally:
        if backup.exists():
            shutil.rmtree(backup, ignore_errors=True)


def _verify_release(info: _PlatformInfo, version: str, tarball_path: Path) -> None:
    """Fail-closed integrity check for a downloaded release asset.

    Downloads ``{asset}.sha256`` and ``{asset}.sha256.sig`` from the release
    host, verifies the Ed25519 signature was made by the pinned RemotiveLabs
    release key, asserts the sidecar names *this* asset (guards against
    replaying a signed hash from a different file), and compares the SHA-256
    of the downloaded tarball to the one in the sidecar. Any failure aborts.
    """
    asset = _asset_name(info, version)
    base = _asset_url(info, version)
    try:
        sha_bytes = _fetch_bytes(base + _SHA256_EXT)
        sig_bytes = _fetch_bytes(base + _SIG_EXT)
    except requests.RequestException as e:
        print_generic_error(f"Failed to download integrity files for {asset}: {e}. Refusing to install.")
        raise typer.Exit(1) from e

    key = _load_release_key()
    try:
        key.verify(sig_bytes, sha_bytes)
    except InvalidSignature:
        print_generic_error(f"Signature on {asset}.sha256 was not made by the pinned RemotiveLabs release key. Refusing to install.")
        raise typer.Exit(1) from None

    expected_digest = _parse_sha256_sidecar(sha_bytes, asset)
    if expected_digest is None:
        print_generic_error(f"{asset}.sha256 does not list {asset}. Refusing to install (signed hash does not belong to this artifact).")
        raise typer.Exit(1)

    actual_digest = _sha256_file(tarball_path)
    if not hmac.compare_digest(actual_digest, expected_digest):
        print_generic_error(
            f"SHA-256 mismatch for {asset}. Refusing to install. Please retry; contact support@remotivelabs.com if this persists."
        )
        raise typer.Exit(1)


def _fetch_bytes(url: str) -> bytes:
    resp = requests.get(url, timeout=30)
    resp.raise_for_status()
    return resp.content


def _load_release_key() -> Ed25519PublicKey:
    """Load the bundled release public key; assert pinned fingerprint."""
    pem_bytes = (files("remotivelabs.cli.studio") / _RELEASE_KEY_RESOURCE).read_bytes()
    key = serialization.load_pem_public_key(pem_bytes)
    if not isinstance(key, Ed25519PublicKey):
        # Non-Ed25519 bundled key means the CLI package was tampered with or
        # built with a stale format; refuse to proceed.
        print_generic_error(f"Bundled RemotiveLabs release key is not Ed25519 (got {type(key).__name__}). Refusing to install.")
        raise typer.Exit(1)
    raw = key.public_bytes(serialization.Encoding.Raw, serialization.PublicFormat.Raw)
    actual_fp = hashlib.sha256(raw).hexdigest().upper()
    if actual_fp != _RELEASE_KEY_FINGERPRINT:
        # The .pem shipped with this CLI build does not match the fingerprint
        # pinned in source. Either the CLI package was tampered with, or a key
        # rotation landed without updating the pin. Either way, don't install.
        print_generic_error(
            f"Bundled RemotiveLabs release key fingerprint ({actual_fp}) does not "
            f"match the value pinned in this CLI ({_RELEASE_KEY_FINGERPRINT}). "
            "Refusing to install."
        )
        raise typer.Exit(1)
    return key


def _parse_sha256_sidecar(data: bytes, expected_name: str) -> str | None:
    """Return the lowercase hex digest iff the sidecar names *expected_name*.

    Accepts the ``sha256sum``/GNU coreutils format: ``<hex>  <name>`` (two
    spaces) or ``<hex> *<name>`` (binary mode marker). Any other shape, or a
    name that doesn't match, returns None so the caller fails closed.
    """
    try:
        text = data.decode("utf-8")
    except UnicodeDecodeError:
        return None
    for raw_line in text.splitlines():
        line = raw_line.strip()
        if not line or line.startswith("#"):
            continue
        parts = line.split(maxsplit=1)
        if len(parts) != 2:
            continue
        digest, name = parts
        name = name.lstrip("*").strip()
        if name == expected_name and len(digest) == 64 and all(c in "0123456789abcdefABCDEF" for c in digest):
            return digest.lower()
    return None


def _sha256_file(path: Path) -> str:
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest()


def _download_with_progress(url: str, dest: Path, label: str) -> None:
    """Stream *url* to *dest* with a rich progress bar. Raises on non-200."""
    with requests.get(url, stream=True, timeout=60) as resp:
        resp.raise_for_status()
        content_length = int(resp.headers.get("Content-Length", 0))
        stream = cast(BinaryIO, resp.raw)
        with open(dest, "wb") as out_file, wrap_file(stream, content_length, description=label, transient=True) as progress_stream:
            shutil.copyfileobj(progress_stream, out_file)


def _stage_tarball(tar_path: Path, staging: Path) -> None:
    """Extract a gzipped tarball into *staging*.

    The archive may have a single top-level directory (common electron-builder
    layout) or be flat. After extraction *staging* contains the binary +
    resources directly (top-level dir is unwrapped), ready for atomic swap.
    Also writes the version marker file so future runs can detect the version.
    """
    work = staging.with_name(staging.name + ".extract")
    if work.exists():
        shutil.rmtree(work)
    work.mkdir(parents=True)
    try:
        with tarfile.open(tar_path, "r:gz") as tf:
            # PEP 706: filter="data" enforces safe paths and permissions.
            # Available on 3.12+ and security-backport patch releases of 3.10/3.11;
            # fall back on older patch versions (notably some Windows installs).
            if hasattr(tarfile, "data_filter"):
                tf.extractall(work, filter="data")
            else:
                tf.extractall(work)

        entries = list(work.iterdir())
        if len(entries) == 1 and entries[0].is_dir():
            extracted_root = entries[0]
        else:
            extracted_root = work

        if not (extracted_root / "RemotiveStudio").exists():
            raise RuntimeError("extracted tarball does not contain a RemotiveStudio binary")

        if extracted_root is work:
            work.rename(staging)
        else:
            extracted_root.rename(staging)
            shutil.rmtree(work, ignore_errors=True)

        (staging / _LINUX_VERSION_MARKER).write_text(MIN_ELECTRON_APP_VERSION)
    except Exception:
        shutil.rmtree(work, ignore_errors=True)
        raise


def _stage_dmg(dmg_path: Path, staging: Path) -> None:
    """Mount the DMG, copy the first .app bundle into *staging*, then detach.

    Why this works for an unsigned (not Developer-ID-signed, not notarized)
    .app on macOS — and why the install path matters:

    1. AMFI (the kernel) requires *some* code signature to execute on Apple
       Silicon. electron-builder injects an ad-hoc signature even when
       Developer ID signing is skipped, so the binary can run at all.
    2. Gatekeeper's "from unidentified developer" / "cannot be verified"
       dialog only fires for files carrying the ``com.apple.quarantine``
       extended attribute. That xattr is set by Safari, Chrome, Mail,
       Messages, AirDrop — i.e. any download path that opts into LaunchServices'
       quarantine API. It is *not* set by Python ``requests``, ``hdiutil
       attach``, or ``shutil.copytree``. So:

           requests.get(...)   → downloaded .dmg has no quarantine
           hdiutil attach      → mount inherits no quarantine
           shutil.copytree     → copied .app has no quarantine

       Result: no quarantine xattr on the installed bundle → Gatekeeper
       does not engage → the ad-hoc signature is accepted at exec time →
       the app launches without prompting.

    A user who downloads the same DMG via Safari and drags it to
    ``~/Applications`` would carry the quarantine xattr and hit Gatekeeper.
    The "unsigned but works" property here depends on the CLI being the
    install path. If we ever ship a browser-friendly download, we will need
    real Developer ID signing + notarization (or instructions to strip the
    xattr).
    """
    with tempfile.TemporaryDirectory() as mount_str:
        mount_dir = Path(mount_str)
        subprocess.run(
            ["hdiutil", "attach", str(dmg_path), "-mountpoint", str(mount_dir), "-nobrowse", "-quiet"],
            check=True,
        )
        try:
            app_bundles = [p for p in mount_dir.iterdir() if p.suffix == ".app"]
            if not app_bundles:
                raise RuntimeError(f"No .app bundle found inside {dmg_path.name}")
            # symlinks=True preserves the internal framework symlinks (e.g.
            # Electron Framework.framework/Versions/Current → A) that macOS
            # bundles rely on; without it copytree dereferences and breaks.
            shutil.copytree(app_bundles[0], staging, symlinks=True)
        finally:
            subprocess.run(["hdiutil", "detach", str(mount_dir), "-quiet"], check=False)


def _post_install(info: _PlatformInfo) -> None:
    """Best-effort OS integration after the swap.

    macOS: re-register with Launch Services so Spotlight/Launchpad pick up
    the new bundle (or the new version's Info.plist) immediately.
    Linux: write the desktop entry, copy the icon, refresh the symlink, and
    nudge the desktop/icon caches.
    """
    if info.os == "macos":
        _macos_register_launch_services()
    else:
        _linux_install_desktop_integration()


def _macos_register_launch_services() -> None:
    lsregister = "/System/Library/Frameworks/CoreServices.framework/Frameworks/LaunchServices.framework/Support/lsregister"
    if not Path(lsregister).exists():
        return
    with contextlib.suppress(OSError, subprocess.SubprocessError):
        subprocess.run([lsregister, "-f", str(_MACOS_APP_BUNDLE)], check=False, capture_output=True, timeout=15)


_DESKTOP_ENTRY_TEMPLATE = """\
[Desktop Entry]
Type=Application
Name=RemotiveStudio Desktop
GenericName=Recording Workspace
Comment=Visualize and analyze RemotiveLabs recordings
Exec={exec_path} %U
Icon=remotive-studio-desktop
Terminal=false
Categories=Development;Engineering;
StartupWMClass=RemotiveStudio
"""


def _linux_desktop_integration_intact() -> bool:
    """True iff the .desktop entry, icon, and bin symlink are all in place.

    The bin symlink check uses ``exists()``, so a user-owned file at that path
    counts as intact — consistent with ``_refresh_linux_bin_symlink`` which
    deliberately doesn't clobber user files.
    """
    return _LINUX_DESKTOP_FILE.exists() and _LINUX_ICON_FILE.exists() and _LINUX_BIN_SYMLINK.exists()


def _linux_install_desktop_integration() -> None:
    """Write `.desktop` entry, install the icon, refresh the launcher symlink.

    Idempotent: re-running with the same install in place is a no-op for the
    user (same content rewritten). The symlink is only replaced if it's missing
    or already points into our managed install dir — never clobber a user file.
    """
    exec_path = _LINUX_APP_DIR / "RemotiveStudio"

    _LINUX_ICON_DIR.mkdir(parents=True, exist_ok=True)
    icon_src = files("remotivelabs.cli.studio") / "assets" / "remotive-studio-desktop.png"
    _LINUX_ICON_FILE.write_bytes(icon_src.read_bytes())

    _LINUX_DESKTOP_DIR.mkdir(parents=True, exist_ok=True)
    desktop_content = _DESKTOP_ENTRY_TEMPLATE.format(exec_path=exec_path)
    _LINUX_DESKTOP_FILE.write_text(desktop_content)
    _LINUX_DESKTOP_FILE.chmod(0o644)

    _refresh_linux_bin_symlink(exec_path)
    _refresh_linux_caches()
    _hint_if_local_bin_not_on_path()


def _refresh_linux_bin_symlink(exec_path: Path) -> None:
    """Point ~/.local/bin/remotive-studio-desktop at the installed binary.

    Only created/replaced if the path is unset or already points into our
    managed install dir. A user-installed binary or symlink at this path is
    left alone so we never overwrite something the user owns.
    """
    _LINUX_BIN_DIR.mkdir(parents=True, exist_ok=True)
    if _LINUX_BIN_SYMLINK.is_symlink():
        try:
            current = os.readlink(_LINUX_BIN_SYMLINK)
        except OSError:
            # Can't read the target — don't guess. Leave the user's symlink alone.
            return
        # Replace only symlinks whose target is inside our managed dir.
        if not Path(current).is_absolute():
            current = str((_LINUX_BIN_SYMLINK.parent / current).resolve())
        try:
            if Path(current).resolve().is_relative_to(_LINUX_APP_DIR.resolve()):
                _LINUX_BIN_SYMLINK.unlink()
            else:
                return
        except (OSError, ValueError):
            return
    elif _LINUX_BIN_SYMLINK.exists():
        return
    with contextlib.suppress(OSError):
        _LINUX_BIN_SYMLINK.symlink_to(exec_path)


def _hint_if_local_bin_not_on_path() -> None:
    """Nudge the user to add ~/.local/bin to PATH if it isn't there.

    The symlink we just refreshed only makes ``remotive-studio-desktop``
    runnable from a terminal when ~/.local/bin is on PATH. Most distros set
    that up automatically, but minimal shells (and some non-login shells)
    don't, so check and hint instead of silently failing.
    """
    if not _LINUX_BIN_SYMLINK.exists():
        return
    target = _LINUX_BIN_DIR.resolve()
    for entry in os.environ.get("PATH", "").split(os.pathsep):
        if not entry:
            continue
        try:
            if Path(entry).resolve() == target:
                return
        except OSError:
            continue
    print_hint(
        f"Add {_LINUX_BIN_DIR} to your PATH to launch RemotiveStudio Desktop from a terminal "
        f'(e.g. `export PATH="{_LINUX_BIN_DIR}:$PATH"` in ~/.bashrc or ~/.zshrc).'
    )


def _refresh_linux_caches() -> None:
    """Best-effort `update-desktop-database` + `gtk-update-icon-cache`."""
    for cmd in (
        ["update-desktop-database", str(_LINUX_DESKTOP_DIR)],
        ["gtk-update-icon-cache", "-f", "-t", str(Path.home() / ".local" / "share" / "icons" / "hicolor")],
    ):
        with contextlib.suppress(OSError, subprocess.SubprocessError):
            subprocess.run(cmd, check=False, capture_output=True, timeout=15)
