from __future__ import annotations

import json
import logging
import mimetypes
import subprocess
from enum import Enum
from pathlib import Path
from typing import Generator

from fastapi import APIRouter, Header, HTTPException, Query, Request
from fastapi.responses import Response, StreamingResponse
from pydantic import BaseModel

from remotivelabs.cli.search import SearchAPI
from remotivelabs.cli.studio.api.path_utils import PathError, join_under, to_relative_path
from remotivelabs.cli.topology.cli.topology_cli import run_topology_async

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/api/studio/v1/files", tags=["files"])


def _get_search_index(request: Request) -> SearchAPI:
    return request.app.state.search_index  # type: ignore[no-any-return]


class FileType(str, Enum):
    FOLDER = "FILE_TYPE_FOLDER"
    INSTANCE = "FILE_TYPE_INSTANCE"
    PLATFORM = "FILE_TYPE_PLATFORM"
    RECORDING_SESSION = "FILE_TYPE_RECORDING_SESSION"
    RECORDING_MAPPING = "FILE_TYPE_RECORDING_MAPPING"
    RECORDING = "FILE_TYPE_RECORDING"
    VIDEO = "FILE_TYPE_VIDEO"
    AUDIO = "FILE_TYPE_AUDIO"
    IMAGE = "FILE_TYPE_IMAGE"
    TEXT = "FILE_TYPE_TEXT"
    UNKNOWN = "FILE_TYPE_UNKNOWN"
    SIGNAL_DATABASE = "FILE_TYPE_SIGNAL_DATABASE"
    DASHBOARD = "FILE_TYPE_DASHBOARD"


class ListFilesFile(BaseModel):
    path: str
    type: FileType
    size: int | None
    modified_time: int
    created_time: int


class ListFilesResponse(BaseModel):
    files: list[ListFilesFile]


def describe_path(root: Path, p: Path) -> ListFilesFile:
    path = "/" + str(p.relative_to(root))
    stat = p.stat()
    file_type = get_file_type(p)
    if file_type == FileType.FOLDER:
        return ListFilesFile(
            path=path,
            type=file_type,
            size=None,
            modified_time=int(stat.st_mtime),
            created_time=int(stat.st_ctime),
        )
    return ListFilesFile(
        path=path,
        type=file_type,
        size=stat.st_size,
        modified_time=int(stat.st_mtime),
        created_time=int(stat.st_ctime),
    )


@router.get("/platform")
async def platform_file(
    request: Request,
    # background_tasks: BackgroundTasks,
    path: str = Query(..., description="File path to show platform"),
) -> Response:
    return await run_cmd_and_get_yaml_async(["show", "platform"], request, path)


@router.get("/instance")
async def instance_file(
    request: Request,
    path: str = Query(..., description="File path to show instance"),
) -> Response:
    return await run_cmd_and_get_yaml_async(["show", "instance", "--full-platform"], request, path)


@router.get("/remotivedb")
async def convert_to_remotivedb(
    request: Request,
    path: str = Query(..., description="File path to convert to RemotiveDB"),
) -> Response:
    yaml_db = await run_cmd_and_get_yaml_async(["convert", "--file"], request, path)
    workspace = request.app.state.topology.workspace
    workspace_path = str(join_under(workspace, Path(path)).resolve())
    rel_path = to_relative_path(workspace, Path(path))
    raw = bytes(yaml_db.body).decode("utf-8")
    search_index = _get_search_index(request)
    search_index.index_yaml_data(rel_path, workspace_path, raw)
    return Response(content=bytes(yaml_db.body), media_type="application/yaml")


@router.get("/download")
def download_file(
    request: Request,
    path: str = Query(..., description="File path to download"),
    range: str | None = Header(None),
) -> StreamingResponse:
    file_path = join_under(request.app.state.topology.workspace, Path(path))
    if not file_path.exists():
        raise HTTPException(status_code=404, detail=PathError(message="File not found", path=str(file_path)).model_dump())
    if not file_path.is_file():
        raise HTTPException(status_code=400, detail=PathError(message="Not a file", path=str(file_path)).model_dump())

    file_size = file_path.stat().st_size
    content_type, _ = mimetypes.guess_type(str(file_path))
    if content_type is None:
        content_type = "application/octet-stream"

    start = 0
    end = file_size - 1

    if range:
        range_match = range.replace("bytes=", "").split("-")
        start = int(range_match[0]) if range_match[0] else 0
        end = int(range_match[1]) if range_match[1] else file_size - 1

    chunk_size = 1024 * 1024  # 1MB chunks

    def iter_file() -> Generator[bytes, None, None]:
        with open(file_path, "rb") as f:
            f.seek(start)
            remaining = end - start + 1
            while remaining > 0:
                read_size = min(chunk_size, remaining)
                data = f.read(read_size)
                if not data:
                    break
                remaining -= len(data)
                yield data

    headers = {
        "Content-Range": f"bytes {start}-{end}/{file_size}",
        "Accept-Ranges": "bytes",
        "Content-Length": str(end - start + 1),
        "Content-Disposition": f'inline; filename="{file_path.name}"',
    }

    status_code = 206 if range else 200
    return StreamingResponse(iter_file(), status_code=status_code, media_type=content_type, headers=headers)


@router.put("/upload")
async def upload_file(
    request: Request,
    path: str = Query(..., description="File path to upload to"),
) -> Response:
    """Upload a file to the workspace."""
    file_path = join_under(request.app.state.topology.workspace, Path(path))

    # Ensure parent directory exists
    file_path.parent.mkdir(parents=True, exist_ok=True)

    # Write the uploaded file content
    try:
        content = await request.body()
        with open(file_path, "wb") as f:
            f.write(content)

        return Response(
            status_code=201,
            content=json.dumps({"message": "File uploaded successfully", "path": str(Path(path))}),
            media_type="application/json",
        )
    except Exception as e:
        raise HTTPException(
            status_code=500,
            detail=PathError(message=f"Failed to upload file: {str(e)}", path=str(file_path)).model_dump(),
        )


@router.get("")
def list_files(
    request: Request,
    path: str = Query(..., description="Directory path to list files from"),
    include_hidden: bool = Query(False, description="Whether to include hidden files"),
) -> ListFilesResponse:
    try:
        root = join_under(request.app.state.topology.workspace, Path(path))
    except ValueError:
        raise HTTPException(status_code=400, detail=PathError(message="Invalid path", path=path).model_dump())

    if not root.exists():
        raise HTTPException(status_code=404, detail=PathError(message="Path not found", path=str(root)).model_dump())
    if not root.is_dir():
        raise HTTPException(status_code=400, detail=PathError(message="Path is not a directory", path=str(root)).model_dump())

    files = [describe_path(request.app.state.topology.workspace, p) for p in root.iterdir() if include_hidden or not p.name.startswith(".")]

    return ListFilesResponse(files=files)


VIDEO_FILE_EXTENSIONS = set([".mp4", ".mov", ".avi", ".webm"])

IMAGE_FILE_EXTENSIONS = set(
    [
        ".png",
        ".jpg",
        ".jpeg",
        ".gif",
        ".svg",
        ".webp",
    ]
)

COMMON_TEXT_FILE_NAMES = set(
    [
        "dockerfile",
        "license",
        ".gitignore",
    ]
)

TEXT_FILE_EXTENSIONS = set(
    [
        ".txt",
        ".md",
        ".ipynb",
        ".json",
        ".yaml",
        ".yml",
        ".xml",
        ".csv",
        ".log",
        ".py",
        ".js",
        ".ts",
        ".tsx",
        ".jsx",
        ".html",
        ".css",
        ".scss",
        ".sh",
        ".bash",
        ".zsh",
        ".conf",
        ".cfg",
        ".ini",
        ".toml",
        ".sql",
        ".graphql",
        ".proto",
        ".kt",
        ".java",
        ".go",
        ".rs",
        ".c",
        ".cpp",
        ".h",
        ".hpp",
        ".swift",
        ".rb",
        ".lua",
        ".lock",
        ".feature",
    ]
)


def get_file_type(path: Path) -> FileType:  # noqa: PLR0911 C901
    if path.is_dir():
        return FileType.FOLDER

    name = path.name
    if name.endswith(".instance.yaml"):
        return FileType.INSTANCE
    if name.endswith(".platform.yaml"):
        return FileType.PLATFORM
    if name.endswith(".recordingsession.yaml"):
        return FileType.RECORDING_SESSION
    if name.endswith(".mapping.yaml"):
        return FileType.RECORDING_MAPPING
    if name.endswith(".dbc") or name.endswith(".arxml") or name.endswith(".ldf") or name.endswith(".xml"):
        return FileType.SIGNAL_DATABASE
    if name.endswith(".log"):
        return FileType.RECORDING
    if name.endswith(".dashboard.json"):
        return FileType.DASHBOARD

    if path.suffix.lower() in IMAGE_FILE_EXTENSIONS:
        return FileType.IMAGE
    if path.suffix.lower() in VIDEO_FILE_EXTENSIONS:
        return FileType.VIDEO
    if path.suffix.lower() in TEXT_FILE_EXTENSIONS or path.name.lower() in COMMON_TEXT_FILE_NAMES:
        return FileType.TEXT

    return FileType.UNKNOWN


async def run_cmd_and_get_yaml_async(
    command: list[str],
    request: Request,
    path: str,
) -> Response:
    file_path = join_under(request.app.state.topology.workspace, Path(path))
    if not file_path.exists():
        raise HTTPException(status_code=404, detail=PathError(message="File not found", path=str(file_path)).model_dump())
    if not file_path.is_file():
        raise HTTPException(status_code=400, detail=PathError(message="Not a file", path=str(file_path)).model_dump())
    try:
        result = await run_topology_async(
            request.app.state.topology,
            command + [str(file_path)],
            lock=request.app.state.subprocess_lock,
        )
        # TODO: use file output instead of stdout
        return Response(content=result.stdout, media_type="application/yaml")
    except subprocess.TimeoutExpired:
        logger.warning("topology command timed out: %s on %s", command, file_path)
        raise HTTPException(status_code=504, detail="Topology command timed out")
    except subprocess.CalledProcessError as e:
        logger.warning("topology command failed: cmd=%s rc=%s path=%s", command, e.returncode, file_path, exc_info=True)
        if e.stderr:
            stderr_str = e.stderr.decode("utf-8", errors="replace") if isinstance(e.stderr, bytes) else e.stderr
            try:
                # Structured JSON from the topology CLI is the contract for surfacing
                # user-facing errors (bad input, validation failures) — safe to forward.
                error_detail = json.loads(stderr_str)
                raise HTTPException(status_code=400, detail=error_detail)
            except json.JSONDecodeError:
                # Unstructured stderr can contain absolute paths, stack traces, or
                # other internal details — log it server-side, return a generic message.
                raise HTTPException(status_code=500, detail="Topology command failed")
        raise HTTPException(status_code=500, detail="Topology command failed")
