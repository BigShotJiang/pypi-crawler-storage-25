"""FastAPI router for runtime inspection of the connected RemotiveBroker instance."""

from __future__ import annotations

import re
from pathlib import Path

import grpc
import requests
from fastapi import APIRouter, HTTPException, Request
from fastapi.responses import Response
from pydantic import BaseModel

from remotivelabs.broker.client import BrokerClient
from remotivelabs.broker.exceptions import BrokerConnectionError, BrokerError
from remotivelabs.cli.broker.typer import BrokerUrlOption
from remotivelabs.cli.studio.api.files import run_cmd_and_get_yaml_async

# OpenAPI examples: same default broker URL as CLI (`BrokerUrlOption`).
_OPENAPI_DOCS_BROKER_URL = BrokerUrlOption.default

# Broker-supplied topology instance IDs: safe segment for cache path (defense-in-depth).
_TOPOLOGY_INSTANCE_ID_RE = re.compile(r"^[A-Za-z0-9_-]{1,64}$")

# RemotiveTopology owns the `.remotive/cache` directory; the CLI only reads from it.
_CACHE_ROOT = ".remotive/cache"


def _find_instance_file(workspace: Path, instance_id: str) -> str | None:
    """Locate the cached `<instance_id>.instance.yaml` under the workspace.

    RemotiveTopology writes the file in either a nested
    (`.remotive/cache/<workspace-hash>/instances/...`) or flat
    (`.remotive/cache/instances/...`) layout; both are currently produced
    depending on the version. Nested wins when both exist.

    Returns the workspace-relative POSIX path, or None if neither layout exists.
    """
    workspace_resolved = workspace.resolve()
    cache_root = workspace / _CACHE_ROOT
    cache_root_resolved = cache_root.resolve()
    filename = f"{instance_id}.instance.yaml"

    def _contained_file(candidate: Path) -> Path | None:
        # Reject symlinks that escape the cache (e.g. an attacker-planted
        # `<hash>/instances/foo.instance.yaml` pointing at /etc/passwd).
        try:
            resolved = candidate.resolve(strict=True)
        except (FileNotFoundError, OSError):
            return None
        if not resolved.is_file() or not resolved.is_relative_to(cache_root_resolved):
            return None
        return resolved

    for candidate in sorted(cache_root.glob(f"*/instances/{filename}")):
        resolved = _contained_file(candidate)
        if resolved is not None:
            return resolved.relative_to(workspace_resolved).as_posix()

    resolved = _contained_file(cache_root / "instances" / filename)
    if resolved is not None:
        return resolved.relative_to(workspace_resolved).as_posix()

    return None


router = APIRouter(prefix="/api/studio/v1/runtime", tags=["runtime"])


# ---------------------------------------------------------------------------
# Shared OpenAPI error response schemas
# ---------------------------------------------------------------------------

_ERROR_404_INSTANCE_NOT_IN_WORKSPACE = {
    "description": "The broker's active topology instance is not present in this workspace.",
    "content": {"application/json": {"example": {"detail": "Current runtime service is not found in this workspace"}}},
}
_ERROR_501 = {
    "description": "Broker does not support topology instance IDs — broker version is too old or not started from a topology instance",
    "content": {
        "application/json": {
            "example": {
                "detail": "Broker returned no topologyInstanceId — broker version may be too old or not started using RemotiveTopology"
            }
        }
    },
}
_ERROR_502 = {
    "description": "Broker returned a gRPC error, or returned an invalid topology instance ID.",
    "content": {
        "application/json": {
            "examples": {
                "grpc_error": {
                    "summary": "gRPC error from broker",
                    "value": {"detail": "Broker gRPC error: <details from broker>"},
                },
                "invalid_instance_id": {
                    "summary": "Broker returned invalid topology instance ID",
                    "value": {"detail": "Broker returned invalid topologyInstanceId"},
                },
            }
        }
    },
}
_ERROR_503 = {
    "description": "Broker is unreachable.",
    "content": {"application/json": {"example": {"detail": f"Could not reach broker at {_OPENAPI_DOCS_BROKER_URL}: Connection refused"}}},
}


async def get_current_instance_id(broker_url: str) -> str:
    try:
        async with BrokerClient(url=broker_url) as client:
            raw_instance_id = await client.topology_instance_id()
    except BrokerConnectionError as e:
        raise HTTPException(status_code=503, detail=f"Could not reach broker at {broker_url}: {e.message}") from e
    except BrokerError as e:
        raise HTTPException(status_code=502, detail=f"Broker error: {e}") from e
    # Would be nice if GRPC errors was handled in broker lib so we could get proper exceptions not only for connect
    except grpc.RpcError as e:
        code_fn = getattr(e, "code", None)
        details_fn = getattr(e, "details", None)
        code = code_fn() if callable(code_fn) else None
        details = (details_fn() if callable(details_fn) else None) or str(e)
        if code == grpc.StatusCode.UNAVAILABLE:
            raise HTTPException(status_code=503, detail=f"Could not reach broker at {broker_url}: {details}") from e
        raise HTTPException(status_code=502, detail=f"Broker gRPC error: {details}") from e

    if not raw_instance_id:
        raise HTTPException(
            status_code=501,
            detail="Broker returned no topologyInstanceId — broker version may be too old or not started using RemotiveTopology",
        )
    if _TOPOLOGY_INSTANCE_ID_RE.fullmatch(raw_instance_id) is None:
        raise HTTPException(status_code=502, detail="Broker returned invalid topologyInstanceId")
    return raw_instance_id


# TODO: Perhaps check broker version once it's released to see if support exists
@router.get(
    "/instance",
    summary="Get the currently running topology instance",
    description=(
        "Resolves the active topology instance from the connected broker and returns its "
        "platform configuration as YAML. The broker is queried for its `topologyInstanceId`; "
        "the corresponding `.instance.yaml` file must exist in the current workspace."
    ),
    response_description="Platform configuration YAML for the active topology instance.",
    responses={
        404: _ERROR_404_INSTANCE_NOT_IN_WORKSPACE,
        501: _ERROR_501,
        502: _ERROR_502,
        503: _ERROR_503,
    },
)
async def current_instance(request: Request) -> Response:
    broker_url = str(request.app.state.broker_url)
    async with request.app.state.subprocess_lock:
        instance_id = await get_current_instance_id(broker_url)
    workspace: Path = request.app.state.topology.workspace
    instance_path = _find_instance_file(workspace, instance_id)
    if instance_path is None:
        raise HTTPException(status_code=404, detail="Current runtime service is not found in this workspace")
    return await run_cmd_and_get_yaml_async(["show", "instance", "--full-platform"], request, instance_path)


class RuntimeEnvironment(BaseModel):
    topology_broker_url: str
    instance_path: str | None
    instance_id: str | None
    grafana_enabled: bool


def _probe_grafana_enabled(broker_url: str, verify: str | bool) -> bool:
    """Probe the broker for a mounted Grafana instance at /grafana."""
    url = f"{broker_url.rstrip('/')}/grafana"
    try:
        response = requests.get(url, timeout=2, allow_redirects=False, verify=verify)
    except requests.RequestException:
        return False
    return response.status_code == 200


async def _try_get_instance_id(broker_url: str) -> str | None:
    """Best-effort fetch of a validated topologyInstanceId.

    Returns None if the broker is reachable but reports no/invalid id.
    Raises HTTPException 503 only if the broker cannot be reached.
    """
    try:
        async with BrokerClient(url=broker_url) as client:
            raw_instance_id = await client.topology_instance_id()
    except BrokerConnectionError as e:
        raise HTTPException(status_code=503, detail=f"Could not reach broker at {broker_url}: {e.message}") from e
    except grpc.RpcError as e:
        code_fn = getattr(e, "code", None)
        details_fn = getattr(e, "details", None)
        code = code_fn() if callable(code_fn) else None
        details = (details_fn() if callable(details_fn) else None) or str(e)
        if code == grpc.StatusCode.UNAVAILABLE:
            raise HTTPException(status_code=503, detail=f"Could not reach broker at {broker_url}: {details}") from e
        return None
    except BrokerError:
        return None

    if not raw_instance_id or _TOPOLOGY_INSTANCE_ID_RE.fullmatch(raw_instance_id) is None:
        return None
    return raw_instance_id


@router.get(
    "/environment",
    summary="Get topology runtime environment",
    description=("Get the topology runtime environment, like topology instance path, URLs for metrics, etc."),
    response_description="Topology runtime environment.",
    responses={503: _ERROR_503},
)
async def get_environment(request: Request) -> RuntimeEnvironment:
    broker_url = str(request.app.state.broker_url)
    async with request.app.state.subprocess_lock:
        instance_id = await _try_get_instance_id(broker_url)
    instance_path: str | None = None
    if instance_id is not None:
        workspace: Path = request.app.state.topology.workspace
        instance_path = _find_instance_file(workspace, instance_id)
    return RuntimeEnvironment(
        topology_broker_url=broker_url,
        instance_path=instance_path,
        instance_id=instance_id,
        grafana_enabled=_probe_grafana_enabled(broker_url, request.app.state.broker_verify),
    )
