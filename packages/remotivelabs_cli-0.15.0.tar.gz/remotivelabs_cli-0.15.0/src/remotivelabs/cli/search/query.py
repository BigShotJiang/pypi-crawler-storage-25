"""Signal search query parsers.

Two entry points produce the same ``Term``/``Group`` AST:

* ``Query.parse`` — shlex-tokenized ``field:value`` syntax with AND-only
  composition. Preserves the historic TUI/MCP behavior so a literal
  ``-Temp`` stays a literal, not a negation.
* ``Query.parse_lucene`` — luqum-backed Lucene syntax (negation, OR/AND,
  parens, regex, ranges). Opt-in for callers that want the full grammar.
"""

from __future__ import annotations

import contextlib
import io
import logging
import re
import shlex

# luqum's PLY-based parser prints LALR conflict warnings to stderr whenever
# it regenerates its cached parser tables (luqum issue #115) -- e.g. under
# Python 3.13, which strips common leading whitespace from docstrings and
# invalidates PLY's docstring-based cache signature on first import. The
# conflicts are benign and resolved deterministically; silence the import.
with contextlib.redirect_stderr(io.StringIO()):
    from luqum.thread import parse as _luqum_parse
from luqum.tree import (
    AndOperation,
    From,
    Item,
    Not,
    OrOperation,
    Phrase,
    Prohibit,
    Range,
    Regex,
    SearchField,
    To,
    UnknownOperation,
    Word,
)
from luqum.tree import (
    Group as LuqumGroup,
)

from remotivelabs.cli.search.columns import COLUMNS, Column
from remotivelabs.cli.search.types import Group, Operator, ParsedQuery, Term

logger = logging.getLogger(__name__)

_FIELD_DEFINITIONS: list[Column] = [c for c in COLUMNS if c.searchable]
FTS_COLUMNS: frozenset[str] = frozenset(c.name for c in _FIELD_DEFINITIONS if c.in_fts)
RAW_FILTER_FIELDS: frozenset[str] = frozenset(c.name for c in _FIELD_DEFINITIONS if not c.in_fts)
ALL_FILTER_FIELDS: frozenset[str] = FTS_COLUMNS | RAW_FILTER_FIELDS


def resolve_filter_field(name: str) -> str | None:
    return name if name in ALL_FILTER_FIELDS else None


def _tokenize(s: str) -> list[str]:
    lex = shlex.shlex(s, posix=True)
    lex.whitespace_split = True
    lex.commenters = ""
    lex.quotes = '"'
    try:
        return list(lex)
    except ValueError:
        return s.strip().split()


def _resolve_fields(prefix: str) -> frozenset[str]:
    cols = {c.strip() for c in prefix.split(",") if c.strip()}
    return frozenset(c for c in cols if c in ALL_FILTER_FIELDS)


def _parse_token(token: str) -> tuple[Term | Group, Term] | None:
    """Return ``(node, active_term)`` for one token, or None if empty.

    Multi-field prefixes fan out to an OR ``Group`` so each ``Term`` is
    classified independently downstream (FTS vs raw vs regex); the full
    multi-field set is preserved on ``active_term`` so suggest scopes
    across all columns.
    """
    sanitized = token.replace('"', "")
    if not sanitized:
        return None

    if ":" in sanitized:
        prefix, _, value = sanitized.partition(":")
        if value:
            fields = _resolve_fields(prefix)
            if len(fields) > 1:
                children = tuple(Term(value=value, fields=frozenset({f})) for f in sorted(fields))
                return Group(children=children, operator=Operator.OR), Term(value=value, fields=fields)
            if fields:
                term = Term(value=value, fields=fields)
                return term, term

    term = Term(value=sanitized, fields=frozenset())
    return term, term


class LuqumConverter:
    """Convert a luqum AST into our Term/Group tree."""

    def __init__(self) -> None:
        self.last_term: Term | None = None

    @staticmethod
    def _node_value(node: Word | Phrase | Regex) -> str:
        val: str = node.value
        if isinstance(node, Phrase):
            return val.strip('"')
        if isinstance(node, Regex):
            return val.strip("/")
        return val

    def _make_term(
        self,
        value: str,
        fields: frozenset[str] = frozenset(),
        *,
        negated: bool = False,
        is_regex: bool = False,
        is_phrase: bool = False,
    ) -> Term:
        term = Term(value=value, fields=fields, negated=negated, is_regex=is_regex, is_phrase=is_phrase)
        self.last_term = term
        return term

    def convert(self, node: Item) -> Term | Group | None:  # noqa: PLR0911
        if isinstance(node, (Word, Phrase)):
            return self._make_term(self._node_value(node), is_phrase=isinstance(node, Phrase))
        if isinstance(node, Regex):
            return self._make_term(self._node_value(node), is_regex=True)
        if isinstance(node, SearchField):
            return self._convert_search_field(node)
        if isinstance(node, (Prohibit, Not)):
            return self._convert_negation(node)
        if isinstance(node, (AndOperation, OrOperation, UnknownOperation)):
            return self._convert_operation(node)
        if isinstance(node, LuqumGroup):
            return self.convert(node.children[0])
        return self._make_term(str(node))

    def _convert_search_field(self, node: SearchField) -> Term | Group:  # noqa: PLR0911
        name = node.name
        if name not in ALL_FILTER_FIELDS:
            return self._make_term(str(node))

        child = node.children[0]
        fields = frozenset({name})

        if isinstance(child, (Word, Phrase)):
            val = self._node_value(child)
            is_phrase = isinstance(child, Phrase)
            return self._make_term(val, fields, is_phrase=is_phrase) if val else self._make_term(f"{name}:", frozenset())
        if isinstance(child, (From, To)):
            return self._convert_comparison(child, fields)
        if isinstance(child, Range):
            return self._convert_range(child, fields)
        if isinstance(child, Regex):
            return self._make_term(self._node_value(child), fields, is_regex=True)
        result = self.convert(child)
        if result is None:
            return self._make_term(str(node))
        if isinstance(result, Term) and not result.fields:
            return Term(value=result.value, fields=fields, negated=result.negated, is_regex=result.is_regex)
        return result

    def _convert_comparison(self, node: From | To, fields: frozenset[str]) -> Term:
        if isinstance(node, From):
            op = ">=" if node.include else ">"
        else:
            op = "<=" if node.include else "<"
        return self._make_term(f"{op}{self._node_value(node.children[0])}", fields)

    @staticmethod
    def _range_bound_value(bound: Word | Phrase | Prohibit | Not) -> str:
        if isinstance(bound, (Prohibit, Not)):
            return f"-{LuqumConverter._node_value(bound.children[0])}"
        return LuqumConverter._node_value(bound)

    def _convert_range(self, node: Range, fields: frozenset[str]) -> Term | Group:
        terms: list[Term] = []
        if node.low:
            val = self._range_bound_value(node.low)
            if val != "*":
                op = ">=" if node.include_low else ">"
                terms.append(self._make_term(f"{op}{val}", fields))
        if node.high:
            val = self._range_bound_value(node.high)
            if val != "*":
                op = "<=" if node.include_high else "<"
                terms.append(self._make_term(f"{op}{val}", fields))
        if len(terms) == 1:
            return terms[0]
        return Group(children=tuple(terms)) if terms else Group(children=())

    def _convert_negation(self, node: Prohibit | Not) -> Term | Group | None:
        result = self.convert(node.children[0])
        if result is None:
            return None
        if isinstance(result, Term):
            return Term(value=result.value, fields=result.fields, negated=True)
        negated = tuple(Term(value=c.value, fields=c.fields, negated=True) if isinstance(c, Term) else c for c in result.children)
        return Group(children=negated, operator=result.operator)

    def _convert_operation(self, node: AndOperation | OrOperation | UnknownOperation) -> Group:
        op = Operator.OR if isinstance(node, OrOperation) else Operator.AND
        children: list[Term | Group] = []
        for child in node.children:
            result = self.convert(child)
            if result is not None:
                children.append(result)
        if not children:
            return Group(children=())
        if len(children) == 1:
            c = children[0]
            return c if isinstance(c, Group) else Group(children=(c,))
        return Group(children=tuple(children), operator=op)

    def parse(self, s: str) -> Group:
        s = s.strip()
        if not s:
            return Group(children=())
        ast = _luqum_parse(s)
        result = self.convert(ast)
        if result is None:
            return Group(children=())
        return result if isinstance(result, Group) else Group(children=(result,))


def _as_substring_node(node: Term | Group) -> Term | Group:
    """Rewrite text terms to escaped regex for ``%term%`` substring semantics.

    Skip rules mirror the shape the SQL builder expects:

    * regex terms — already in the right form.
    * raw-only field-scoped terms (``cycle_time:>=8`` etc.) — go through the
      raw comparison path; turning them into regex would force a string match.
    * the ``active_term`` reference is left untouched by callers because
      ``suggest`` consumes ``active_term.value`` as a LIKE pattern, not a regex.
    """
    if isinstance(node, Group):
        return Group(
            children=tuple(_as_substring_node(c) for c in node.children),
            operator=node.operator,
        )
    if node.is_regex or (node.fields and not (node.fields - RAW_FILTER_FIELDS)):
        return node
    return Term(value=re.escape(node.value), fields=node.fields, negated=node.negated, is_regex=True)


class Query:
    """Parsed search query.

    Use ``Query.parse`` for the historic shlex ``field:value`` syntax
    (TUI / MCP / general purpose), or ``Query.parse_lucene`` for the
    full Lucene grammar (negation, OR/AND, parens, regex, ranges).
    """

    def __init__(self, parsed: ParsedQuery) -> None:
        self._parsed = parsed

    @staticmethod
    def parse(s: str, operator: Operator = Operator.AND, *, substring: bool = False) -> Query:
        children: list[Term | Group] = []
        last_active: Term | None = None
        for token in _tokenize(s):
            if token == "OR":
                continue
            result = _parse_token(token)
            if result is not None:
                node, active = result
                children.append(node)
                last_active = active
        root: Group = Group(children=tuple(children), operator=operator)
        if substring:
            rewritten = _as_substring_node(root)
            assert isinstance(rewritten, Group)
            root = rewritten
        return Query(ParsedQuery(root=root, active_term=last_active))

    @staticmethod
    def parse_lucene(s: str, *, substring: bool = False) -> Query:
        """Parse a full Lucene query (negation, OR/AND, parens, regex, ranges)."""
        converter = LuqumConverter()
        root = converter.parse(s)
        if substring:
            rewritten = _as_substring_node(root)
            assert isinstance(rewritten, Group)
            root = rewritten
        return Query(ParsedQuery(root=root, active_term=converter.last_term))

    @property
    def parsed(self) -> ParsedQuery:
        return self._parsed
