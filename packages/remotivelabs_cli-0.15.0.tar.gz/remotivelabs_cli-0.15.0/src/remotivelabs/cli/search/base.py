"""Abstract base class for the signal search API."""

from __future__ import annotations

from abc import ABC, abstractmethod
from typing import Any

from remotivelabs.cli.search.query import Query
from remotivelabs.cli.search.types import SearchOptions, StatusResult


class SearchAPI(ABC):
    @abstractmethod
    def connect(self) -> None: ...

    @abstractmethod
    def close(self) -> None: ...

    @abstractmethod
    def clear(self) -> None: ...

    @abstractmethod
    def index_signals(self, signals: list[dict[str, Any]]) -> int: ...

    @abstractmethod
    def index_yaml_data(self, file_path: str, workspace_path: str, raw: str) -> int: ...

    @abstractmethod
    def search(
        self,
        query: Query,
        limit: int = 50,
        opts: SearchOptions | None = None,
        exact: bool = False,
    ) -> list[dict[str, Any]]: ...

    @abstractmethod
    def search_slim(
        self,
        query: Query,
        opts: SearchOptions | None = None,
        exact: bool = False,
    ) -> list[str]:
        """Return matching signals as ``"namespace:name"`` or ``"channel:name"`` strings."""

    @abstractmethod
    def suggest(  # noqa: PLR0913 — match the underlying index API; collapsing into a config dataclass costs more than it saves
        self,
        query: Query,
        selected: list[Query] | None = None,
        limit: int = 20,
        opts: SearchOptions | None = None,
        substring: bool = False,
        exact_values_only: bool = False,
        offset: int = 0,
        field_priority: list[str] | None = None,
    ) -> tuple[list[dict[str, str]], int]:
        """Return suggestions for ``query``.

        ``field_priority`` opt-in: when given, results whose ``field``
        appears in the list come first in that order, followed by all
        other fields alphabetically; within each group, results are
        sorted by value.  ``None`` (default) keeps the historical
        alphabetical-by-value ordering used by studio.
        """
        ...

    @abstractmethod
    def status(
        self,
        source_filter: str | None = None,
        file_path_filter: str | None = None,
        filters: dict[str, str] | None = None,
        query: Query | None = None,
        exact: bool = False,
    ) -> StatusResult: ...
