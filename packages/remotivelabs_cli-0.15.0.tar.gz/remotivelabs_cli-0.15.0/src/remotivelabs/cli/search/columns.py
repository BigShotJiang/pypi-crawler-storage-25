"""Column definitions — single source of truth for the search schema."""

from __future__ import annotations

from dataclasses import dataclass
from enum import Enum


class ColumnType(Enum):
    TEXT = "TEXT"
    INT = "INTEGER"
    FLOAT = "REAL"
    BOOL = "BOOLEAN"


@dataclass(frozen=True)
class Column:
    """A search column definition."""

    name: str
    type: ColumnType = ColumnType.TEXT
    in_fts: bool = False  # Indexed in FTS5 for full-text search
    searchable: bool = False  # Exposed as a searchable/filterable field
    default: str | None = None  # Python default value for insertion
    camel_expand: bool = False  # Apply _camel_expand() in FTS trigger
    is_collection: bool = False  # Value is a multi-item collection (list or dict). Suggest yields per-item tokens, not the joined row.
    tokenize_suggest: bool = False  # Tokenize values for autocomplete suggestions
    dot_split: bool = False  # Split on dots for suggest tokens (e.g. PDU.DIM → PDU, DIM)

    @property
    def is_numeric(self) -> bool:
        return self.type in (ColumnType.INT, ColumnType.FLOAT, ColumnType.BOOL)

    @property
    def is_bool(self) -> bool:
        return self.type == ColumnType.BOOL

    @property
    def is_float(self) -> bool:
        return self.type == ColumnType.FLOAT


COLUMNS: list[Column] = [
    # Text fields (FTS-indexed)
    Column("signal_name", ColumnType.TEXT, in_fts=True, searchable=True, camel_expand=True, tokenize_suggest=True, dot_split=True),
    Column("frame_name", ColumnType.TEXT, in_fts=True, searchable=True, camel_expand=True, tokenize_suggest=True, dot_split=True),
    Column("frame_id", ColumnType.TEXT, in_fts=True, searchable=True),
    Column("namespace", ColumnType.TEXT, in_fts=True, searchable=True, camel_expand=True, tokenize_suggest=True),
    Column("channel", ColumnType.TEXT, in_fts=True, searchable=True, camel_expand=True, tokenize_suggest=True, dot_split=True),
    Column("description", ColumnType.TEXT, in_fts=True, searchable=True, default="", tokenize_suggest=True, dot_split=True),
    Column("unit", ColumnType.TEXT, in_fts=True, searchable=True, default=""),
    Column("senders", ColumnType.TEXT, in_fts=True, searchable=True, is_collection=True, camel_expand=True, tokenize_suggest=True),
    Column("receivers", ColumnType.TEXT, in_fts=True, searchable=True, is_collection=True, camel_expand=True, tokenize_suggest=True),
    Column(
        "named_values",
        ColumnType.TEXT,
        in_fts=True,
        searchable=True,
        is_collection=True,
        camel_expand=True,
        tokenize_suggest=True,
        dot_split=True,
    ),
    # Raw filterable fields (not FTS)
    Column("type", ColumnType.TEXT, searchable=True, default="signal"),
    Column("file_path", ColumnType.TEXT, searchable=True),
    Column("start_bit", ColumnType.INT, searchable=True),
    Column("size", ColumnType.INT, searchable=True),
    Column("factor", ColumnType.FLOAT, searchable=True),
    Column("offset", ColumnType.FLOAT, searchable=True),
    Column("min", ColumnType.FLOAT, searchable=True),
    Column("max", ColumnType.FLOAT, searchable=True),
    Column("is_signed", ColumnType.BOOL, searchable=True),
    Column("is_big_endian", ColumnType.BOOL, searchable=True),
    Column("is_ieee_floating_type", ColumnType.BOOL, searchable=True),
    Column("is_raw", ColumnType.BOOL, searchable=True),
    Column("payload_size", ColumnType.INT, searchable=True),
    Column("cycle_time", ColumnType.FLOAT, searchable=True),
    # Internal columns (not searchable)
    Column("named_values_json", ColumnType.TEXT),
    Column("start_value", ColumnType.FLOAT),
    Column("source", ColumnType.TEXT, default="grpc"),
    Column("channel_type", ColumnType.TEXT),
    Column("workspace_path", ColumnType.TEXT),
    Column("multiplex_json", ColumnType.TEXT),
    Column("opt_empty_payload", ColumnType.TEXT),
    Column("is_can_fd", ColumnType.BOOL),
    Column("is_extended", ColumnType.BOOL),
    Column("can_fd_flags", ColumnType.INT),
    Column("multiplex_selector", ColumnType.TEXT),
    Column("e2e_json", ColumnType.TEXT),
    Column("secoc_json", ColumnType.TEXT),
    Column("groups_json", ColumnType.TEXT),
    Column("channel_cluster", ColumnType.TEXT),
    Column("channel_physical_name", ColumnType.TEXT),
]
