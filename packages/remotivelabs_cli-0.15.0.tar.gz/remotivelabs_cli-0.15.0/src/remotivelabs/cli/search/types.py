"""Query model types used across the search package."""

from __future__ import annotations

from dataclasses import dataclass, field
from enum import Enum


class Operator(str, Enum):
    AND = "and"
    OR = "or"


@dataclass(frozen=True)
class Term:
    """What to search: content of a single search term."""

    value: str
    fields: frozenset[str]  # DB column names; empty frozenset = search all FTS columns
    negated: bool = False  # True when prefixed with '-' (exclude)
    is_regex: bool = False  # True for regex terms (e.g. /pattern/)
    is_phrase: bool = False  # True when the value was quoted ("exact phrase")


@dataclass(frozen=True)
class Group:
    """A group of children (Terms or nested Groups) joined by an operator."""

    children: tuple[Term | Group, ...]
    operator: Operator = Operator.AND


@dataclass(frozen=True)
class ParsedQuery:
    root: Group
    active_term: Term | None = None


@dataclass
class SearchOptions:
    source_filter: str | None = None
    file_path_filter: str | None = None
    filters: dict[str, str] = field(default_factory=dict)


@dataclass
class StatusResult:
    total: int
    last_indexed: str | None = None
