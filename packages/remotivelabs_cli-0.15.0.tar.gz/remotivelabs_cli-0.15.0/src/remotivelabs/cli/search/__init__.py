"""Signal search library — pure engine with no web-framework dependency."""

from .base import SearchAPI
from .query import Query
from .sqlite import SearchIndex, SQLiteSearch
from .types import Group, Operator, ParsedQuery, SearchOptions, StatusResult, Term

__all__ = [
    "Operator",
    "SearchOptions",
    "SearchAPI",
    "ParsedQuery",
    "Group",
    "Term",
    "Query",
    "SearchIndex",
    "SQLiteSearch",
    "StatusResult",
]
