"""SQLite FTS5 schema constants and SQL statements for the signal search index."""

from __future__ import annotations

from remotivelabs.cli.search.columns import COLUMNS, Column, ColumnType

# ── Derived constants ────────────────────────────────────────────────

_SQL_TYPE_MAP: dict[ColumnType, str] = {
    ColumnType.TEXT: "TEXT",
    ColumnType.INT: "INTEGER",
    ColumnType.FLOAT: "REAL",
    ColumnType.BOOL: "INTEGER",
}


def _sql_type(c: Column) -> str:
    return _SQL_TYPE_MAP[c.type]


def _col_name_sql(c: Column) -> str:
    return f'"{c.name}"'


def _col_def_sql(c: Column) -> str:
    name = _col_name_sql(c)
    default = f" DEFAULT '{c.default}'" if c.default is not None and c.default != "" else ""
    return f"    {name:<25s} {_sql_type(c)}{default}"


_FTS_COLUMNS_LIST: list[Column] = [c for c in COLUMNS if c.in_fts]
_CAMEL_EXPAND_NAMES: frozenset[str] = frozenset(c.name for c in COLUMNS if c.camel_expand)
_ALL_COLUMN_NAMES: list[str] = [c.name for c in COLUMNS]
_FTS_COLUMN_NAMES: list[str] = [c.name for c in _FTS_COLUMNS_LIST]

_TOKENIZED_SUGGEST_FIELDS = frozenset(c.name for c in COLUMNS if c.tokenize_suggest)
_DOT_SPLIT_FIELDS = frozenset(c.name for c in COLUMNS if c.dot_split)

# ── Generated SQL ────────────────────────────────────────────────────

_SCHEMA_RAW = (
    "CREATE TABLE IF NOT EXISTS signals_raw (\n"
    "    id                    INTEGER PRIMARY KEY,\n" + ",\n".join(_col_def_sql(c) for c in COLUMNS) + "\n)"
)

_SCHEMA_FTS = (
    "CREATE VIRTUAL TABLE IF NOT EXISTS signals_fts USING fts5(\n"
    "    " + ", ".join(_FTS_COLUMN_NAMES) + ",\n"
    "    content='signals_raw', content_rowid='id',\n"
    "    tokenize=\"unicode61 tokenchars '_-'\"\n"
    ")"
)


def _trigger_values(prefix: str) -> str:
    parts = []
    for c in _FTS_COLUMNS_LIST:
        if c.camel_expand:
            parts.append(f"_camel_expand({prefix}.{c.name})")
        else:
            parts.append(f"{prefix}.{c.name}")
    return ", ".join(parts)


_fts_col_list = ", ".join(_FTS_COLUMN_NAMES)

_TRIGGERS = [
    f"""\
CREATE TRIGGER IF NOT EXISTS signals_ai AFTER INSERT ON signals_raw BEGIN
    INSERT INTO signals_fts(rowid, {_fts_col_list})
    VALUES (new.id, {_trigger_values("new")});
END""",
    f"""\
CREATE TRIGGER IF NOT EXISTS signals_ad AFTER DELETE ON signals_raw BEGIN
    INSERT INTO signals_fts(signals_fts, rowid, {_fts_col_list})
    VALUES ('delete', old.id, {_trigger_values("old")});
END""",
]

_insert_cols = ", ".join(_col_name_sql(c) for c in COLUMNS)
_insert_placeholders = ", ".join("?" for _ in COLUMNS)
_INSERT_SQL = f"INSERT INTO signals_raw ({_insert_cols}) VALUES ({_insert_placeholders})"

_SCHEMA_TOKENS = """\
CREATE TABLE IF NOT EXISTS signals_tokens (
    signal_id INTEGER NOT NULL,
    field      TEXT    NOT NULL,
    token      TEXT    NOT NULL
)"""

_SCHEMA_TOKENS_INDEX = """\
CREATE INDEX IF NOT EXISTS idx_tokens_field_token
ON signals_tokens(field, token, signal_id)"""

_INSERT_TOKEN_SQL = "INSERT INTO signals_tokens (signal_id, field, token) VALUES (?, ?, ?)"
