"""SQLiteSearch — SQLite FTS5 implementation of SearchAPI."""

from __future__ import annotations

import functools
import json
import logging
import re
import sqlite3
import threading
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

import yaml

from remotivelabs.cli.search.base import SearchAPI
from remotivelabs.cli.search.columns import COLUMNS
from remotivelabs.cli.search.query import (
    FTS_COLUMNS,
    Query,
)
from remotivelabs.cli.search.sqlite.query_builder import (
    build_filter_clauses,
    build_filters,
    build_where,
    can_use_fts,
    get_file_path_from_query,
    to_fts_query,
)
from remotivelabs.cli.search.sqlite.schema import (
    _DOT_SPLIT_FIELDS,
    _INSERT_SQL,
    _INSERT_TOKEN_SQL,
    _SCHEMA_FTS,
    _SCHEMA_RAW,
    _SCHEMA_TOKENS,
    _SCHEMA_TOKENS_INDEX,
    _TOKENIZED_SUGGEST_FIELDS,
    _TRIGGERS,
)
from remotivelabs.cli.search.types import Group, ParsedQuery, SearchOptions, StatusResult, Term
from remotivelabs.cli.search.yaml_parser import parse_yaml_signals

_DOT_RE = re.compile(r"\.")

# Threshold above which inline ``IN (?, ?, …)`` placeholders would risk
# SQLite's bound-parameter limit; we materialise to a temp table instead.
_SCOPE_INLINE_LIMIT = 500

# What sqlite3 accepts as a bound parameter (no nested types — sqlite3 rejects them).
SqlParam = str | int | float | bytes | bool | None


@functools.lru_cache(maxsize=64)
def _compile_regexp(pattern: str) -> re.Pattern[str]:
    return re.compile(pattern, re.IGNORECASE)


def _sqlite_regexp(pattern: str, value: object) -> bool:
    """SQLite REGEXP function: returns True if value matches the pattern."""
    if value is None:
        return False
    try:
        return _compile_regexp(pattern).search(str(value)) is not None
    except re.error:
        return False


log = logging.getLogger(__name__)


def _escape_like(s: str) -> str:
    """Escape ``!``, ``%`` and ``_`` for use in a LIKE pattern with ESCAPE '!'."""
    return s.replace("!", "!!").replace("%", "!%").replace("_", "!_")


_CAMEL_SPLIT_RE = re.compile(
    r"(?<=[a-z])(?=[A-Z])"
    r"|(?<=[A-Z])(?=[A-Z][a-z])"
    r"|(?<=[a-zA-Z])(?=[0-9])"
    r"|(?<=[0-9])(?=[a-zA-Z])"
)


def _camel_case_split(word: str) -> list[str]:
    """Split a CamelCase identifier into component parts."""
    parts = _CAMEL_SPLIT_RE.split(word)
    return [p for p in parts if p]


def _camel_expand(value: str | None) -> str | None:
    """Expand a dot-separated identifier for FTS indexing.

    Each dot-segment that contains CamelCase is expanded so sub-words become
    separate FTS tokens, plus consecutive-pair joins so a prefix search can
    match across a single camel boundary — e.g. ``can0`` against ``BodyCAN0``
    (splits to ``[Body, CAN, 0]``, which would otherwise drop the ``CAN0``
    substring entirely from the prefix-searchable token set).

    Examples:
        ``ChargerDC.RearLeft.Delta`` → ``ChargerDC Charger DC RearLeft Rear Left Delta``
        ``BodyCAN0`` → ``BodyCAN0 Body CAN 0 BodyCAN CAN0``

    Registered as a SQLite function so the INSERT/DELETE triggers can call it.
    """
    if not value:
        return value
    parts: list[str] = []
    for segment in _DOT_RE.split(value):
        parts.append(segment)
        camel_parts = _camel_case_split(segment)
        if len(camel_parts) > 1:
            parts.extend(camel_parts)
            # Pair-joins only add information when there are 3+ parts; for
            # exactly 2 the only pair-join equals the original segment.
            if len(camel_parts) > 2:
                parts.extend(camel_parts[i] + camel_parts[i + 1] for i in range(len(camel_parts) - 1))
    return " ".join(parts)


def _value_to_words(field: str, value: object) -> list[str]:
    """Flatten a column value to the indexable word list for tokenization."""
    if isinstance(value, dict):
        return [str(v) for v in value.values() if v]
    if isinstance(value, list):
        return [str(v) for v in value if v]
    if isinstance(value, str):
        return value.replace(".", " ").split() if field in _DOT_SPLIT_FIELDS else value.split()
    return []


def _expand_word_tokens(field: str, word: str) -> list[str]:
    """Expand a single word into the tokens stored for prefix-suggest.

    Mirrors the FTS-side ``_camel_expand`` logic for dot-split fields: emits
    the full word, each camel segment, and consecutive-pair joins so a prefix
    search can match across one camel boundary (e.g. ``can0`` against
    ``BodyCAN0`` whose camel parts are ``[Body, CAN, 0]``).
    """
    tokens = [word]
    if field not in _DOT_SPLIT_FIELDS:
        return tokens
    parts = _camel_case_split(word)
    if len(parts) <= 1:
        return tokens
    tokens.extend(parts)
    if len(parts) > 2:
        tokens.extend(parts[i] + parts[i + 1] for i in range(len(parts) - 1))
    return tokens


def _build_token_rows_for_signal(signal_id: int, sig: dict[str, Any]) -> list[tuple[int, str, str]]:
    """Build (signal_id, field, token) tuples for one row (frame or signal)."""
    seen: set[tuple[str, str]] = set()
    rows: list[tuple[int, str, str]] = []
    for field in _TOKENIZED_SUGGEST_FIELDS:
        value = sig.get(field)
        if not value:
            continue
        for word in _value_to_words(field, value):
            for token in _expand_word_tokens(field, word):
                pair = (field, token)
                if pair not in seen:
                    seen.add(pair)
                    rows.append((signal_id, field, token))
    return rows


def _build_suggest_unions(  # noqa: PLR0913 — these knobs map 1:1 to the suggest decision tree below
    columns: list[str],
    escaped_prefix: str,
    raw_extra: tuple[str, list[SqlParam]],
    tok_extra: tuple[str, list[SqlParam]],
    *,
    exact_values_only: bool = False,
    substring: bool = False,
) -> tuple[list[str], list[SqlParam]]:
    """Build UNION SQL fragments and params for suggest queries.

    Three union shapes, picked per column:

    1. **Collection** (``is_collection=True``): always tokens-only — the joined
       raw value (e.g. ``"Off On Error"``) is useless as a single suggestion.
    2. **Field-scoped, tokenized, no explicit substring** (``exact_values_only
       and not substring`` and the column is tokenized): prefix-match
       ``signals_tokens`` and JOIN back to ``signals_raw`` to return DISTINCT
       column values. This way typing ``can`` surfaces ``BodyCAN0`` (token
       ``CAN`` matches the prefix → parent channel value) but typing ``rl``
       does NOT surface ``RearLightLIN`` (no token starts with ``rl``, so the
       cross-CamelCase-boundary substring noise disappears).
    3. **Default**: raw-column LIKE on ``signals_raw``, plus the historic
       per-token union when not field-scoped. Used when the caller explicitly
       asked for substring matching, when the column has no tokens, or when no
       field scope was supplied.

    The substring/prefix decision is per column rather than global: numeric
    columns always use prefix matching even when *substring* is True, because
    substring against stringified numbers produces nonsense (e.g. typing ``0``
    would match ``-1500.0``).

    Column names are interpolated into SQL (sqlite doesn't accept ``?``
    placeholders for identifiers), so we hard-gate against the allowlist at
    function entry. Any future caller passing through user input still can't
    reach the f-string.
    """
    unknown = [c for c in columns if c not in _COLUMN_BY_NAME]
    if unknown:
        msg = f"refusing to build suggest SQL for unknown column(s): {unknown!r}"
        raise ValueError(msg)
    raw_extra_sql, raw_extra_params = raw_extra
    tok_extra_sql, tok_extra_params = tok_extra
    prefix_pattern = f"{escaped_prefix}%"
    unions: list[str] = []
    params: list[SqlParam] = []
    for col in columns:
        is_collection = col in _COLLECTION_COLUMNS
        is_tokenized = col in _TOKENIZED_SUGGEST_FIELDS
        is_numeric = _COLUMN_BY_NAME[col].is_numeric
        use_substring = substring and not is_numeric
        substring_pattern = f"%{escaped_prefix}%" if use_substring else prefix_pattern

        if is_collection:
            if is_tokenized:
                unions.append(
                    f"SELECT DISTINCT ? AS field, token AS value FROM signals_tokens "
                    f"WHERE field = ? AND token LIKE ? ESCAPE '!'{tok_extra_sql}"
                )
                params.extend([col, col, substring_pattern] + tok_extra_params)
            continue

        # Token-prefix-with-JOIN path: only when field-scoped, no explicit
        # substring, and the column has tokens to match against.
        if exact_values_only and is_tokenized and not substring:
            unions.append(
                f'SELECT DISTINCT ? AS field, r."{col}" AS value '
                f"FROM signals_tokens t JOIN signals_raw r ON r.id = t.signal_id "
                f"WHERE t.field = ? AND t.token LIKE ? ESCAPE '!'{tok_extra_sql}"
            )
            params.extend([col, col, prefix_pattern] + tok_extra_params)
            continue

        unions.append(f'SELECT DISTINCT ? AS field, "{col}" AS value FROM signals_raw WHERE "{col}" LIKE ? ESCAPE \'!\'{raw_extra_sql}')
        params.extend([col, substring_pattern] + raw_extra_params)
        if is_tokenized and not exact_values_only:
            unions.append(
                f"SELECT DISTINCT ? AS field, token AS value FROM signals_tokens WHERE field = ? AND token LIKE ? ESCAPE '!'{tok_extra_sql}"
            )
            params.extend([col, col, substring_pattern] + tok_extra_params)
    return unions, params


def _build_suggest_order(field_priority: list[str] | None) -> tuple[str, list[SqlParam]]:
    """Build the ``ORDER BY`` clause for the suggest UNION query.

    Without ``field_priority`` the historical alphabetical-by-value
    ordering is preserved.  With it, results whose ``field`` appears
    in the priority list come first (in list order), followed by the
    rest sorted alphabetically by field, and finally by value within
    each group.

    Returns ``(sql, params)``.  Field names go into the SQL as bound
    parameters rather than being interpolated, even though the values
    in ``field_priority`` are caller-controlled — keeps the path
    inert against any future call site that forwards user input.
    """
    if not field_priority:
        return "ORDER BY value", []
    cases: list[str] = []
    params: list[SqlParam] = []
    for i, name in enumerate(field_priority):
        cases.append(f"WHEN ? THEN {i}")
        params.append(name)
    case_sql = "CASE field " + " ".join(cases) + f" ELSE {len(field_priority)} END"
    return f"ORDER BY {case_sql}, field, value", params


_INSERT_COLUMNS = tuple(c.name for c in COLUMNS)
_COLUMN_BY_NAME = {c.name: c for c in COLUMNS}


def _log_row_error(exc: Exception, sig: dict[str, Any], row: tuple[SqlParam, ...]) -> None:
    """Log which column value caused an insertion error."""
    bad_fields = [
        f"{col}={val!r}" for col, val in zip(_INSERT_COLUMNS, row) if val is not None and not isinstance(val, (str, float, bytes, bool))
    ]
    log.error(
        "Failed to insert signal %r (channel=%r, frame=%r): %s — suspect fields: %s",
        sig.get("signal_name"),
        sig.get("channel"),
        sig.get("frame_name"),
        exc,
        ", ".join(bad_fields) if bad_fields else "<none identified>",
    )


def _to_float(v: float | int | str | None) -> float | None:
    """Cast to float so sqlite3 never attempts INTEGER storage for REAL columns."""
    return float(v) if v is not None else None


def _to_bool_int(v: object) -> int | None:
    """Cast to 0/1 for SQLite INTEGER bool columns."""
    return None if v is None else (1 if v else 0)


_BOOL_COLUMNS = frozenset(c.name for c in COLUMNS if c.is_bool)
_FLOAT_COLUMNS = frozenset(c.name for c in COLUMNS if c.is_float)
_COLLECTION_COLUMNS = frozenset(c.name for c in COLUMNS if c.is_collection)


def _signal_to_row(sig: dict[str, Any]) -> tuple[SqlParam, ...]:
    """Convert a signal dict to a tuple matching COLUMNS order."""
    # Pre-compute named_values text and json
    named_values = sig.get("named_values")
    if isinstance(named_values, dict):
        nv_str = " ".join(str(v) for v in named_values.values())
    elif isinstance(named_values, list):
        nv_str = " ".join(str(v) for v in named_values)
    elif named_values:
        nv_str = str(named_values)
    else:
        nv_str = ""

    named_values_json = sig.get("named_values_json")
    if named_values_json is None and isinstance(named_values, dict) and named_values:
        named_values_json = json.dumps(named_values)

    overrides: dict[str, SqlParam] = {"named_values": nv_str, "named_values_json": named_values_json}

    values: list[SqlParam] = []
    for col in COLUMNS:
        name = col.name
        if name in overrides:
            values.append(overrides[name])
        elif name in _COLLECTION_COLUMNS:
            v = sig.get(name) or []
            values.append(" ".join(v) if isinstance(v, list) else str(v))
        elif name in _BOOL_COLUMNS:
            values.append(_to_bool_int(sig.get(name)))
        elif name in _FLOAT_COLUMNS:
            values.append(_to_float(sig.get(name)))
        else:
            values.append(sig.get(name, col.default))
    return tuple(values)


def _iter_terms(node: Term | Group) -> list[Term]:
    """Collect all Term leaves from a tree."""
    if isinstance(node, Term):
        return [node]
    result: list[Term] = []
    for child in node.children:
        result.extend(_iter_terms(child))
    return result


class SQLiteSearch(SearchAPI):
    def __init__(self, db_path: str = ":memory:"):
        self._db_path = db_path
        self._lock = threading.Lock()
        self._conn: sqlite3.Connection | None = None
        self._last_indexed: str | None = None

    def connect(self) -> None:
        self._conn = sqlite3.connect(self._db_path, check_same_thread=False)
        self._conn.row_factory = sqlite3.Row
        self._conn.create_function("_camel_expand", 1, _camel_expand)
        self._conn.create_function("regexp", 2, _sqlite_regexp)
        self._conn.execute("PRAGMA journal_mode=WAL")
        with self._conn:
            self._conn.execute(_SCHEMA_RAW)
            self._conn.execute(_SCHEMA_FTS)
            for trigger in _TRIGGERS:
                self._conn.execute(trigger)
            self._conn.execute(_SCHEMA_TOKENS)
            self._conn.execute(_SCHEMA_TOKENS_INDEX)

    def close(self) -> None:
        if self._conn:
            self._conn.close()
            self._conn = None

    def clear(self) -> None:
        assert self._conn is not None
        with self._lock, self._conn:
            self._conn.execute("DELETE FROM signals_raw")
            self._conn.execute("DELETE FROM signals_tokens")
        self._last_indexed = None

    def index_signals(self, signals: list[dict[str, Any]]) -> int:
        """Index a list of signal dicts, replacing all existing data."""
        assert self._conn is not None
        with self._lock, self._conn:
            self._conn.execute("DELETE FROM signals_raw")
            self._conn.execute("DELETE FROM signals_tokens")
            for sig in signals:
                cursor = self._conn.execute(_INSERT_SQL, _signal_to_row(sig))
                assert cursor.lastrowid is not None
                token_rows = _build_token_rows_for_signal(cursor.lastrowid, sig)
                if token_rows:
                    self._conn.executemany(_INSERT_TOKEN_SQL, token_rows)
        self._last_indexed = datetime.now(timezone.utc).isoformat()
        return len(signals)

    def index_yaml_data(self, file_path: str, workspace_path: str, raw: str) -> int:
        """Index signal data from a YAML string.

        Args:
            file_path: Workspace-relative path stored in the index (client-facing).
            workspace_path: Absolute filesystem path (server-internal).
            raw: Raw YAML text to parse.
        """
        data = yaml.safe_load(raw)
        signals = parse_yaml_signals(file_path, workspace_path, data)

        assert self._conn is not None
        with self._lock, self._conn:
            self._conn.execute("DELETE FROM signals_raw WHERE file_path = ?", (file_path,))
            self._conn.execute("DELETE FROM signals_tokens WHERE signal_id NOT IN (SELECT id FROM signals_raw)")
            indexed = 0
            for sig in signals:
                row = _signal_to_row(sig)
                try:
                    cursor = self._conn.execute(_INSERT_SQL, row)
                except Exception as exc:
                    _log_row_error(exc, sig, row)
                    raise
                assert cursor.lastrowid is not None
                token_rows = _build_token_rows_for_signal(cursor.lastrowid, sig)
                if token_rows:
                    self._conn.executemany(_INSERT_TOKEN_SQL, token_rows)
                indexed += 1

        log.info("Indexed %d entries from YAML file %s", indexed, workspace_path)
        return indexed

    def index_yaml_file(self, workspace_path: str, file_path: str) -> int:
        """Parse a remotive-signal-database YAML file and index its signals.

        Existing rows with the same ``file_path`` are replaced so calling this
        again with the same paths is idempotent. Signals from gRPC or other
        YAML files are left intact.

        Args:
            workspace_path: Absolute path used to read the file from disk.
            file_path: Workspace-relative path stored in the index and used for filtering.
        """
        resolved = str(Path(workspace_path).resolve())
        raw = Path(resolved).read_text(encoding="utf-8")
        return self.index_yaml_data(file_path, resolved, raw)

    def search(
        self,
        query: Query,
        limit: int = 50,
        opts: SearchOptions | None = None,
        exact: bool = False,
    ) -> list[dict[str, Any]]:
        opts = opts or SearchOptions()
        assert self._conn is not None

        # Fast path: pure FTS query — direct JOIN with BM25 ranking
        if can_use_fts(query.parsed):
            fts_query = to_fts_query(query.parsed, exact=exact)
            if fts_query:
                effective_fp = opts.file_path_filter or get_file_path_from_query(query.parsed)
                filter_parts, filter_params = build_filter_clauses(
                    build_filters(opts, file_path_override=effective_fp),
                    table_alias="r",
                )
                extra = (" AND " + " AND ".join(filter_parts)) if filter_parts else ""
                with self._lock:
                    cursor = self._conn.execute(
                        f"""SELECT r.*
                           FROM signals_fts f
                           JOIN signals_raw r ON r.id = f.rowid
                           WHERE signals_fts MATCH ?{extra}
                           ORDER BY bm25(signals_fts)
                           LIMIT ?""",
                        (fts_query, *filter_params, limit),
                    )
                    return [dict(row) for row in cursor.fetchall()]

        where, params = build_where(query, opts, exact=exact)
        if not where:
            return []
        with self._lock:
            cursor = self._conn.execute(
                f"SELECT * FROM signals_raw WHERE {where} ORDER BY id LIMIT ?",
                (*params, limit),
            )
            return [dict(row) for row in cursor.fetchall()]

    def search_slim(
        self,
        query: Query,
        opts: SearchOptions | None = None,
        exact: bool = False,
    ) -> list[str]:
        opts = opts or SearchOptions()
        where, params = build_where(query, opts, exact=exact)
        if not where:
            return []
        assert self._conn is not None
        with self._lock:
            cursor = self._conn.execute(
                f"""SELECT namespace, channel,
                    COALESCE(signal_name, frame_name) AS display_name FROM signals_raw
                    WHERE {where}""",
                params,
            )
            rows = [dict(row) for row in cursor.fetchall()]
        return [f"{r.get('namespace') or r.get('channel') or ''}:{r['display_name']}" for r in rows]

    def suggest(  # noqa: PLR0913 — match the abstract API; collapsing into a config dataclass costs more than it saves
        self,
        query: Query,
        selected: list[Query] | None = None,
        limit: int = 20,
        opts: SearchOptions | None = None,
        substring: bool = False,
        exact_values_only: bool = False,
        offset: int = 0,
        field_priority: list[str] | None = None,
    ) -> tuple[list[dict[str, str]], int]:
        """Return autocomplete suggestions for the term being typed.

        When ``selected`` is given, suggestions are scoped to signals that
        match all of those already-confirmed terms, and the selected values
        themselves are excluded from the returned suggestions.
        """
        opts = opts or SearchOptions()
        assert self._conn is not None
        active = query.parsed.active_term
        if active is None:
            return [], 0

        scope_ids: set[int] | None = None
        exclusions: set[tuple[str, str]] = set()

        if selected:
            # Merge all selected queries into one ParsedQuery for ID lookup.
            roots = [sq.parsed.root for sq in selected if sq.parsed.root.children]
            if roots:
                scope_query = Query(ParsedQuery(root=Group(children=tuple(roots))))
                scope_file_path = opts.file_path_filter or get_file_path_from_query(scope_query.parsed)
                scope_ids = self._search_ids(
                    scope_query,
                    opts=opts,
                    file_path_filter=scope_file_path,
                )
                if not scope_ids:
                    return [], 0

            # Build exclusion set: (display_field, value) pairs already selected.
            for sq in selected:
                for term in _iter_terms(sq.parsed.root):
                    display_fields = list(term.fields) if term.fields else list(FTS_COLUMNS)
                    for df in display_fields:
                        exclusions.add((df, term.value.lower()))

        suggest_file_path = opts.file_path_filter or get_file_path_from_query(query.parsed)
        cols = sorted(active.fields) if active.fields else sorted(FTS_COLUMNS)
        scope = (scope_ids, suggest_file_path)
        # Field-scoped suggest (e.g. `channel:can`) returns real column values
        # via the token-prefix-JOIN path inside ``_build_suggest_unions`` —
        # token ``CAN`` prefix-matches ``can``, and the JOIN surfaces the
        # parent ``channel`` value (``BodyCAN0``). That avoids the cross-
        # CamelCase-boundary noise that ``%can%`` against the raw column would
        # produce. Explicit ``substring=True`` from the API still uses
        # ``%prefix%`` against the raw column (caller asked for it).
        field_scoped = bool(active.fields)
        values_only = field_scoped or exact_values_only
        items, total = self._suggest_from_columns(
            (cols, active.value, limit),
            opts,
            scope,
            exact_values_only=values_only,
            substring=substring,
            offset=offset,
            field_priority=field_priority,
        )
        if exclusions:
            items = [s for s in items if (s["field"], s["suggestion"].lower()) not in exclusions]
            total = len(items)

        return items, total

    def _count_status_query(self, sql: str, params: list[SqlParam] | tuple[SqlParam, ...]) -> int:
        """Run a single-column COUNT query and return the total."""
        assert self._conn is not None
        with self._lock:
            cursor = self._conn.execute(sql, params)
            row = cursor.fetchone()
        return int(row["total"]) if row else 0

    def status(  # noqa: PLR0913
        self,
        source_filter: str | None = None,
        file_path_filter: str | None = None,
        filters: dict[str, str] | None = None,
        query: Query | None = None,
        exact: bool = False,
    ) -> StatusResult:
        """Count rows matching the same criteria as ``search_slim`` (no limit, no parent-frame fetch)."""
        assert self._conn is not None
        opts = SearchOptions(
            source_filter=source_filter,
            file_path_filter=file_path_filter,
            filters=dict(filters) if filters else {},
        )
        if query is None:
            query = Query(ParsedQuery(root=Group(children=())))
        where, params = build_where(query, opts, exact=exact)
        if not where:
            where, params = "1=1", []
        total = self._count_status_query(
            f"SELECT COUNT(*) AS total FROM signals_raw WHERE {where}",
            params,
        )
        return StatusResult(total=total, last_indexed=self._last_indexed)

    def fetch_frame_row(self, file_path: str, channel: str, frame_name: str) -> dict[str, Any] | None:
        """Fetch the frame row for (file_path, channel, frame_name). Returns None if not found."""
        assert self._conn is not None
        with self._lock:
            cursor = self._conn.execute(
                """SELECT * FROM signals_raw
                   WHERE type = 'frame' AND file_path = ? AND channel = ? AND frame_name = ?""",
                (file_path, channel, frame_name),
            )
            row = cursor.fetchone()
        return dict(row) if row else None

    def fetch_broker_frame_row(self, namespace: str, frame_name: str) -> dict[str, Any] | None:
        """Fetch the broker frame row for (namespace, frame_name). Returns None if not found."""
        assert self._conn is not None
        with self._lock:
            cursor = self._conn.execute(
                """SELECT * FROM signals_raw
                   WHERE type = 'frame' AND source = 'grpc' AND namespace = ? AND frame_name = ?""",
                (namespace, frame_name),
            )
            row = cursor.fetchone()
        return dict(row) if row else None

    def namespace_max_cycle_time_ms(self, source: str = "grpc") -> dict[str, float]:
        """Max declared cycle time per namespace, in ms."""
        assert self._conn is not None
        with self._lock:
            cursor = self._conn.execute(
                """SELECT namespace, MAX(cycle_time) AS max_cycle FROM signals_raw
                   WHERE source = ? AND type = 'frame' AND cycle_time IS NOT NULL AND cycle_time > 0
                   GROUP BY namespace""",
                (source,),
            )
            return {row["namespace"]: float(row["max_cycle"]) for row in cursor.fetchall()}

    def all_namespaces(self, source: str = "grpc") -> list[str]:
        """Every namespace present in the index (cyclic + static)."""
        assert self._conn is not None
        with self._lock:
            cursor = self._conn.execute(
                "SELECT DISTINCT namespace FROM signals_raw WHERE source = ? ORDER BY namespace",
                (source,),
            )
            return [row["namespace"] for row in cursor.fetchall()]

    # ------------------------------------------------------------------
    # Private helpers
    # ------------------------------------------------------------------

    def _build_token_scope_clause(
        self,
        scope_ids: set[int] | None,
        source_filter: str | None,
        file_path_filter: str | None,
    ) -> tuple[str, list[SqlParam]]:
        """Build a SQL clause to scope token suggestions, using a subquery for large sets.

        For ``scope_ids`` larger than ``_SCOPE_INLINE_LIMIT`` we materialise the IDs
        into a temporary table (``_token_scope_ids``) and intersect against it —
        the alternative inline ``IN (?, ?, …)`` would hit SQLite's variable limit.
        """
        clauses: list[str] = []
        params: list[SqlParam] = []
        if source_filter is not None:
            clauses.append("source = ?")
            params.append(source_filter)
        if file_path_filter is not None:
            clauses.append("file_path = ?")
            params.append(file_path_filter)
        if scope_ids is not None:
            if len(scope_ids) <= _SCOPE_INLINE_LIMIT:
                placeholders = ",".join("?" * len(scope_ids))
                clauses.append(f"id IN ({placeholders})")
                params.extend(scope_ids)
            else:
                self._stage_token_scope_ids(scope_ids)
                clauses.append("id IN (SELECT id FROM _token_scope_ids)")
        if not clauses:
            return "", []
        where = " AND ".join(clauses)
        subquery = f" AND signal_id IN (SELECT id FROM signals_raw WHERE {where})"
        return subquery, params

    def _stage_token_scope_ids(self, scope_ids: set[int]) -> None:
        """Populate the ``_token_scope_ids`` temp table for use as a join target.

        Caller must hold ``self._lock`` (or own the connection in tests). The
        table is created on demand and truncated on each call.
        """
        assert self._conn is not None
        self._conn.execute("CREATE TEMP TABLE IF NOT EXISTS _token_scope_ids (id INTEGER PRIMARY KEY)")
        self._conn.execute("DELETE FROM _token_scope_ids")
        self._conn.executemany("INSERT INTO _token_scope_ids (id) VALUES (?)", ((i,) for i in scope_ids))

    def _resolve_token_scope_ids(
        self,
        scope_ids: set[int] | None,
        source_filter: str | None,
        file_path_filter: str | None,
    ) -> set[int] | None:
        """Narrow scope_ids to only those matching source/file filter for tokenized columns."""
        assert self._conn is not None
        if source_filter is None and file_path_filter is None:
            return scope_ids
        source_id_clauses: list[str] = []
        source_id_params: list[SqlParam] = []
        if source_filter is not None:
            source_id_clauses.append("source = ?")
            source_id_params.append(source_filter)
        if file_path_filter is not None:
            source_id_clauses.append("file_path = ?")
            source_id_params.append(file_path_filter)
        where = " AND ".join(source_id_clauses)
        if scope_ids:
            placeholders = ",".join("?" * len(scope_ids))
            where += f" AND id IN ({placeholders})"
            source_id_params.extend(scope_ids)
        with self._lock:
            cur = self._conn.execute(f"SELECT id FROM signals_raw WHERE {where}", source_id_params)
            return {row[0] for row in cur.fetchall()} or {-1}

    def _query_ids(self, sql: str, params: tuple[SqlParam, ...] | list[SqlParam]) -> set[int]:
        """Execute a query and return the first column as a set of ints."""
        assert self._conn is not None
        with self._lock:
            cursor = self._conn.execute(sql, params)
            return {row[0] for row in cursor.fetchall()}

    def _search_ids(
        self,
        query: Query,
        *,
        opts: SearchOptions | None = None,
        file_path_filter: str | None = None,
    ) -> set[int]:
        """Return signal IDs matching *query* (used to scope suggest results)."""
        opts = opts or SearchOptions()
        assert self._conn is not None
        effective_fp = file_path_filter or get_file_path_from_query(query.parsed)
        where, params = build_where(query, opts)
        if not where:
            filters = build_filters(opts, file_path_override=effective_fp)
            filter_parts, filter_params = build_filter_clauses(filters)
            if filter_parts:
                return self._query_ids(
                    f"SELECT id FROM signals_raw WHERE {' AND '.join(filter_parts)}",
                    filter_params,
                )
            return set()
        return self._query_ids(f"SELECT id FROM signals_raw WHERE {where}", params)

    def _suggest_from_columns(  # noqa: PLR0913 — internal helper kept aligned with public ``suggest`` knobs
        self,
        query_params: tuple[list[str], str, int],
        opts: SearchOptions | None,
        scope: tuple[set[int] | None, str | None],
        *,
        exact_values_only: bool = False,
        substring: bool = False,
        offset: int = 0,
        field_priority: list[str] | None = None,
    ) -> tuple[list[dict[str, str]], int]:
        columns, prefix, limit = query_params
        opts = opts or SearchOptions()
        scope_ids, file_path_filter = scope
        assert self._conn is not None
        escaped_prefix = _escape_like(prefix)

        # Build scope (selected terms) and source/file clauses for signals_raw rows.
        filters = build_filters(opts, file_path_override=file_path_filter)
        filter_parts, filter_params = build_filter_clauses(filters)

        with self._lock:
            raw_extra_clauses: list[str] = []
            raw_extra_params: list[SqlParam] = []
            if scope_ids:
                if len(scope_ids) <= _SCOPE_INLINE_LIMIT:
                    placeholders = ",".join("?" * len(scope_ids))
                    raw_extra_clauses.append(f"id IN ({placeholders})")
                    raw_extra_params.extend(scope_ids)
                else:
                    # Inline ``IN (?, ?, …)`` repeated per FTS column would
                    # blow past SQLite's bound-parameter limit. Materialise
                    # the IDs into a temp table once and reference it from
                    # every union branch instead.
                    self._stage_token_scope_ids(scope_ids)
                    raw_extra_clauses.append("id IN (SELECT id FROM _token_scope_ids)")
            raw_extra_clauses.extend(filter_parts)
            raw_extra_params.extend(filter_params)
            raw_extra_sql = (" AND " + " AND ".join(raw_extra_clauses)) if raw_extra_clauses else ""

            # For tokenized columns we must join back to signals_raw to apply source/file
            # filters. ``_build_token_scope_clause`` reuses the same temp table when needed.
            tok_extra_sql, tok_extra_params = self._build_token_scope_clause(
                scope_ids,
                opts.source_filter,
                file_path_filter,
            )

            unions, params = _build_suggest_unions(
                columns,
                escaped_prefix,
                (raw_extra_sql, raw_extra_params),
                (tok_extra_sql, tok_extra_params),
                exact_values_only=exact_values_only,
                substring=substring,
            )

            union_sql = " UNION ".join(unions)
            order_sql, order_params = _build_suggest_order(field_priority)
            # Wrap the union in a subquery so a CASE-based ORDER BY can
            # see the ``field`` column.  SQLite rejects CASE
            # expressions in the ORDER BY of a compound (UNION) query
            # unless they reference columns in the leftmost SELECT
            # by name *and* the planner is happy — the subquery wrap
            # sidesteps that rule entirely.
            data_sql = f"SELECT * FROM ({union_sql}) {order_sql} LIMIT ? OFFSET ?"

            # Fetch one extra row to detect saturation; only run COUNT(*) when needed.
            cursor = self._conn.execute(data_sql, params + order_params + [limit + 1, offset])
            rows = cursor.fetchall()
            if len(rows) > limit:
                rows = rows[:limit]
                count_row = self._conn.execute(f"SELECT COUNT(*) FROM ({union_sql})", params).fetchone()
                total = count_row[0] if count_row else 0
            else:
                total = offset + len(rows)
            items = [
                {"field": row["field"], "suggestion": str(row["value"])} for row in rows if row["value"] is not None and row["value"] != ""
            ]

        return items, total


# Backward-compatible alias
SearchIndex = SQLiteSearch
