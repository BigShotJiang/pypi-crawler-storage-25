"""SQL builders: convert ParsedQuery to FTS5 and SQL fragments."""

from __future__ import annotations

import re
from typing import Any

from remotivelabs.cli.search.columns import COLUMNS
from remotivelabs.cli.search.query import (
    FTS_COLUMNS,
    RAW_FILTER_FIELDS,
    Query,
)
from remotivelabs.cli.search.types import Group, ParsedQuery, SearchOptions, Term

# Identifier allowlist; sqlite can't ``?``-bind column names.
_ALL_COLUMN_NAMES: frozenset[str] = frozenset(c.name for c in COLUMNS)

_COMPARISON_PREFIXES = (">=", "<=", ">", "<")


def _escape_fts_phrase(s: str) -> str:
    """Escape user input for safe use inside an FTS5 double-quoted phrase."""
    s = s.replace("\r\n", " ").replace("\n", " ").replace("\r", " ").replace("\t", " ")
    return s.replace('"', '""')


def _is_raw_only(term: Term) -> bool:
    if term.is_regex:
        return True
    return bool(term.fields) and not (term.fields - RAW_FILTER_FIELDS)


# A single match means the value contains an FTS5 separator char (``%``, ``/``,
# ``°``, …); those values can't round-trip through FTS5 (zero-token phrases
# match nothing, ``L/h`` splits to ``L``+``h``) so they need raw equality.
_FTS_SEPARATOR_RE = re.compile(r"[^A-Za-z0-9_.\- ]")


def _is_fts_field_scoped(term: Term) -> bool:
    return bool(term.fields) and not (term.fields - FTS_COLUMNS)


def _needs_raw_equality(term: Term) -> bool:
    if term.negated or term.is_regex or not _is_fts_field_scoped(term):
        return False
    return bool(_FTS_SEPARATOR_RE.search(term.value))


def _parse_comparison(value: str, negated: bool) -> tuple[str, str]:
    """Split ``>=8`` / ``<8`` / etc. into (op, bare_value); fall back to ``=`` / ``!=``."""
    for prefix in _COMPARISON_PREFIXES:
        if value.startswith(prefix):
            return prefix, value[len(prefix) :]
    return "!=" if negated else "=", value


def _term_to_fts(term: Term, exact: bool = False) -> str:
    """Convert a single Term to an FTS5 expression.

    Quoted phrases skip the trailing ``*`` — otherwise ``unit:"L/h"`` (tokens
    ``L`` ``h``) becomes a prefix query matching ``L hour`` etc.
    """
    safe_value = _escape_fts_phrase(term.value)
    suffix = "" if exact or term.is_phrase else "*"
    if not term.fields:
        return f'"{safe_value}"{suffix}'
    cols = sorted(term.fields)
    col_prefix = cols[0] if len(cols) == 1 else "{" + " ".join(cols) + "}"
    # Dot-split bare words use AND-joined sub-phrases to avoid FTS5
    # position mismatch on large indexes; quoted phrases stay verbatim.
    if not term.is_phrase:
        parts = safe_value.split(".")
        if len(parts) > 1:
            and_terms = " AND ".join(f'{col_prefix} : "{p}"{suffix}' for p in parts if p)
            return and_terms or f'{col_prefix} : "{safe_value}"{suffix}'
    return f'{col_prefix} : "{safe_value}"{suffix}'


def _regex_clause(term: Term, prefix: str) -> tuple[str, list[Any]]:
    cols = sorted(term.fields) if term.fields else sorted(FTS_COLUMNS)
    expr = " OR ".join(f"COALESCE({prefix}\"{c}\", '') REGEXP ?" for c in cols)
    if term.negated:
        return f"NOT ({expr})", [term.value] * len(cols)
    return f"({expr})", [term.value] * len(cols)


def _raw_comparison_clause(term: Term, prefix: str) -> tuple[str, list[Any]]:
    op, bare_value = _parse_comparison(term.value, term.negated)
    cols = sorted(term.fields & RAW_FILTER_FIELDS)
    clause = " OR ".join(f'{prefix}"{c}" {op} ?' for c in cols)
    return f"({clause})", [bare_value] * len(cols)


def _negated_fts_clause(term: Term, prefix: str) -> tuple[str, list[Any]]:
    """FTS5's ``NOT`` requires a positive seed; we use ``NOT REGEXP`` instead."""
    if _is_fts_field_scoped(term) and _FTS_SEPARATOR_RE.search(term.value):
        cols = sorted(term.fields)
        expr = " AND ".join(f'{prefix}"{c}" != ?' for c in cols)
        return f"({expr})", [term.value] * len(cols)
    cols = sorted(term.fields & FTS_COLUMNS) if term.fields else sorted(FTS_COLUMNS)
    escaped = re.escape(term.value)
    expr = " OR ".join(f"COALESCE({prefix}\"{c}\", '') REGEXP ?" for c in cols)
    return f"NOT ({expr})", [escaped] * len(cols)


def _term_to_clause(
    term: Term,
    table_alias: str = "",
    exact: bool = False,
    *,
    raw_only: bool = False,
) -> tuple[str, list[Any]] | None:
    prefix = f"{table_alias}." if table_alias else ""

    # ``signal_name:Eng*`` is shorthand for the same prefix match we apply to
    # bare words; strip the ``*`` so it doesn't get embedded into the phrase.
    if not term.is_phrase and not term.is_regex and term.value.endswith("*"):
        stripped = term.value.rstrip("*")
        if stripped:
            term = Term(
                value=stripped,
                fields=term.fields,
                negated=term.negated,
                is_regex=term.is_regex,
                is_phrase=term.is_phrase,
            )

    if term.is_regex:
        return _regex_clause(term, prefix)
    if _is_raw_only(term):
        return _raw_comparison_clause(term, prefix)
    if raw_only:
        return None
    if term.negated:
        return _negated_fts_clause(term, prefix)
    if _needs_raw_equality(term):
        cols = sorted(term.fields)
        expr = " OR ".join(f'{prefix}"{c}" = ?' for c in cols)
        return f"({expr})", [term.value] * len(cols)
    fts_expr = _term_to_fts(term, exact=exact)
    id_col = f"{prefix}id" if prefix else "id"
    return f"({id_col} IN (SELECT rowid FROM signals_fts WHERE signals_fts MATCH ?))", [fts_expr]


def _group_to_clauses(
    group: Group,
    table_alias: str = "",
    exact: bool = False,
    *,
    raw_only: bool = False,
) -> tuple[str, list[Any]]:
    parts: list[str] = []
    params: list[Any] = []
    for child in group.children:
        if isinstance(child, Term):
            result = _term_to_clause(child, table_alias, exact, raw_only=raw_only)
            if result is not None:
                clause, p = result
                parts.append(clause)
                params.extend(p)
        else:
            sub, p = _group_to_clauses(child, table_alias, exact, raw_only=raw_only)
            if sub:
                parts.append(f"({sub})")
                params.extend(p)
    if not parts:
        return "", []
    return f" {group.operator.value.upper()} ".join(parts), params


def _group_to_fts(group: Group, exact: bool) -> str:
    positive: list[str] = []
    negated: list[str] = []
    for child in group.children:
        if isinstance(child, Term):
            if _is_raw_only(child):
                continue
            fts = _term_to_fts(child, exact)
            if child.negated:
                negated.append(fts)
            else:
                positive.append(fts)
        else:
            sub = _group_to_fts(child, exact)
            if sub:
                positive.append(f"({sub})")
    if not positive and not negated:
        return ""
    # FTS5 ``NOT`` is a binary operator; wrap any operator-bearing sub-
    # expression in parens so the negation applies to the whole thing.
    op = f" {group.operator.value.upper()} "
    result = op.join(positive) if positive else ""
    for neg in negated:
        wrapped = f"({neg})" if any(o in neg for o in (" AND ", " OR ", " NOT ")) else neg
        result = f"{result} NOT {wrapped}" if result else ""
    return result


def _contains_raw(node: Term | Group) -> bool:
    if isinstance(node, Term):
        return _is_raw_only(node) or _needs_raw_equality(node)
    return any(_contains_raw(c) for c in node.children)


def _contains_positive_fts(node: Term | Group) -> bool:
    if isinstance(node, Term):
        return not _is_raw_only(node) and not node.negated
    return any(_contains_positive_fts(c) for c in node.children)


# ── public API ──────────────────────────────────────────────────────


def get_file_path_from_query(parsed: ParsedQuery) -> str | None:
    """Value of the first ``file_path:`` term, or None."""
    return _find_file_path(parsed.root)


def _find_file_path(node: Term | Group) -> str | None:
    if isinstance(node, Term):
        return node.value if "file_path" in node.fields and node.value else None
    for child in node.children:
        result = _find_file_path(child)
        if result is not None:
            return result
    return None


def to_fts_query(parsed: ParsedQuery, exact: bool = False) -> str:
    return _group_to_fts(parsed.root, exact)


def can_use_fts(parsed: ParsedQuery) -> bool:
    """True when the query has positive FTS terms and no raw-only branches."""
    return _contains_positive_fts(parsed.root) and not _contains_raw(parsed.root)


def has_raw_terms(parsed: ParsedQuery) -> bool:
    return _contains_raw(parsed.root)


def to_fts_subquery_where(
    parsed: ParsedQuery,
    table_alias: str = "",
    exact: bool = False,
) -> tuple[str, list[Any]]:
    return _group_to_clauses(parsed.root, table_alias, exact)


def build_filters(opts: SearchOptions, file_path_override: str | None = None) -> dict[str, str]:
    merged = dict(opts.filters)
    if opts.source_filter is not None:
        merged["source"] = opts.source_filter
    fp = file_path_override or opts.file_path_filter
    if fp is not None:
        merged["file_path"] = fp
    return merged


def build_filter_clauses(
    filters: dict[str, str],
    table_alias: str = "",
) -> tuple[list[str], list[Any]]:
    """Build per-filter ``"col" = ?`` clauses; gates against the column allowlist."""
    if not filters:
        return [], []
    unknown = [c for c in filters if c not in _ALL_COLUMN_NAMES]
    if unknown:
        msg = f"refusing to build filter SQL for unknown column(s): {unknown!r}"
        raise ValueError(msg)
    prefix = f"{table_alias}." if table_alias else ""
    clauses: list[str] = []
    params: list[Any] = []
    for col, value in filters.items():
        clauses.append(f'{prefix}"{col}" = ?')
        params.append(value)
    return clauses, params


def build_where(
    query: Query,
    opts: SearchOptions,
    exact: bool = False,
) -> tuple[str, list[Any]]:
    """WHERE body for ``signals_raw``. Returns ("", []) when there are no conditions.

    Substring mode is applied upstream (``Query.parse(..., substring=True)``)
    by rewriting text terms to regex before they reach this builder.
    """
    effective_fp = opts.file_path_filter or get_file_path_from_query(query.parsed)
    filters = build_filters(opts, file_path_override=effective_fp)

    query_sql, query_params = to_fts_subquery_where(query.parsed, exact=exact)
    filter_parts, filter_params = build_filter_clauses(filters)

    parts: list[str] = []
    params: list[Any] = []
    if query_sql:
        parts.append(query_sql)
        params.extend(query_params)
    parts.extend(filter_parts)
    params.extend(filter_params)

    if not parts:
        return "", []
    return " AND ".join(parts), params
