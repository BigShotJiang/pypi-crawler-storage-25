"""Search input + suggestion dropdown.

Two widgets that drive the typeahead-suggest pipeline:

- `SearchInput` debounces ``Input.Changed`` into ``SuggestRequested``
  / ``SearchRequested`` messages and exposes ``accept_*`` methods that
  splice an accepted suggestion into the input value.
- `SearchSuggestions` owns the dropdown's worker, race detection,
  and pagination.  It posts `FieldAccepted` / `ValueAccepted`
  when the user picks an item; the App routes those to ``SearchInput``.
"""

from __future__ import annotations

import re
from collections.abc import Callable
from dataclasses import dataclass
from typing import Any

from textual import events
from textual.binding import Binding
from textual.message import Message
from textual.timer import Timer
from textual.widgets import Input, OptionList
from textual.widgets.option_list import Option

from remotivelabs.cli.topology.tui.bindings import vertical_nav_bindings
from remotivelabs.cli.topology.tui.query_string import apply_field_suggestion, apply_value_suggestion


class SearchInput(Input):
    """Search input that joins multi-line pastes into spaces and debounces
    typeahead-suggest + tree-rebuild requests.

    Posts ``SuggestRequested`` ~80 ms after the last keystroke and
    ``SearchRequested`` ~150 ms after.  The App listens for both and decides
    whether the effective filter actually changed before doing real work.
    Owning the timers here (instead of on the App) keeps them on the widget's
    lifecycle: textual stops them and closes the pump before children become
    unreachable, so callbacks can't race a half-dismantled tree during
    teardown.
    """

    SUGGEST_DELAY = 0.08
    SEARCH_DELAY = 0.15

    def __init__(self, *args: Any, **kwargs: Any) -> None:
        super().__init__(*args, **kwargs)
        self.suggest_timer: Timer | None = None
        self.search_timer: Timer | None = None

    class SuggestRequested(Message):
        """Debounced ``Input.Changed`` — request a suggestion fetch."""

        def __init__(self, raw: str) -> None:
            self.raw = raw
            super().__init__()

    class SearchRequested(Message):
        """Debounced ``Input.Changed`` — request a tree rebuild."""

        def __init__(self, raw: str) -> None:
            self.raw = raw
            super().__init__()

    def _on_paste(self, event: events.Paste) -> None:
        # Mutate ``event.text`` in place — Textual's MRO dispatcher then calls
        # ``Input._on_paste`` with the cleaned text. Calling ``super()`` here
        # would paste twice, since the dispatcher also invokes the parent.
        if event.text:
            event.text = re.sub(r"[\r\n]+", " ", event.text)

    def _on_input_changed(self, event: Input.Changed) -> None:
        if event.input is not self:
            return
        raw = event.value
        if self.suggest_timer is not None:
            self.suggest_timer.stop()
        self.suggest_timer = self.set_timer(
            self.SUGGEST_DELAY,
            lambda: self.post_message(self.SuggestRequested(raw)),
        )
        if self.search_timer is not None:
            self.search_timer.stop()
        self.search_timer = self.set_timer(
            self.SEARCH_DELAY,
            lambda: self.post_message(self.SearchRequested(raw)),
        )

    def accept_field(self, name: str) -> None:
        self.value, self.cursor_position = apply_field_suggestion(self.value, self.cursor_position, name)
        self.focus()

    def accept_value(self, field: str, value: str) -> None:
        self.value, self.cursor_position = apply_value_suggestion(self.value, self.cursor_position, field=field, value_text=value)
        self.focus()

    def append_filter_term(self, term: str) -> None:
        current = self.value.rstrip()
        if term in current:
            return
        if not current:
            self.value = term
        elif current.endswith("("):
            self.value = current + term
        else:
            self.value = f"{current} {term}"

    def append_field(self, name: str) -> None:
        current = self.value.rstrip()
        if current.endswith(":"):
            parts = current.rsplit(maxsplit=1)
            if parts[-1].endswith(":"):
                current = parts[0].rstrip() if len(parts) > 1 else ""
        prefix = f"{current} " if current else ""
        new_value = f"{prefix}{name}:"
        if self.value != new_value:
            self.value = new_value
        self.cursor_position = len(self.value)
        self.focus()


# Suggestions dropdown pagination. Each ``cursor_down`` near the tail of
# the loaded list fetches the next ``SUGGEST_PAGE_SIZE`` items; ``End``/``G``
# instead fetches up to ``SUGGEST_MAX_TOTAL`` remaining items in one shot.
SUGGEST_PAGE_SIZE = 50
SUGGEST_MAX_TOTAL = 10_000


@dataclass(frozen=True)
class FieldSuggestion:
    """Field-name pick — accepting it appends ``name:`` to the input."""

    name: str


@dataclass(frozen=True)
class ValueSuggestion:
    """Value pick.  ``field`` is the source column the value came from in
    the index (e.g. ``"unit"`` for ``rpm``); empty when the active term
    already carries a field of its own."""

    value: str
    field: str


SuggestionItem = FieldSuggestion | ValueSuggestion


class SuggestionOption(Option):
    """Option that carries its source `SuggestionItem` so selection
    dispatch can branch on type instead of parsing back from a string id."""

    def __init__(self, prompt: str, item: SuggestionItem) -> None:
        super().__init__(prompt)
        self.item = item


@dataclass(frozen=True)
class SuggestResult:
    """Pre-rendered output of one suggest call.

    The App's "suggest source" produces this; the widget only displays it.
    Keeping rendering + parsing inside the source means
    `SearchSuggestions` stays index-agnostic.
    """

    items: list[SuggestionItem]
    value_count: int  # paginated count — used for offset bookkeeping
    total: int  # what the index says is the upper bound

    @property
    def has_more(self) -> bool:
        return self.value_count < self.total


SuggestFn = Callable[[str, int | None, int, int], SuggestResult | None]


class SearchSuggestions(OptionList):
    """Dropdown of typeahead suggestion"""

    DEFAULT_CSS = """
    SearchSuggestions {
        display: none;
        max-height: 10;
        border: tall $accent;
        background: $surface;
    }
    SearchSuggestions.visible {
        display: block;
    }
    """

    BINDINGS = [
        *vertical_nav_bindings("cursor_down", "cursor_up"),
        Binding("end", "load_all_and_end", show=False),
        Binding("G", "load_all_and_end", show=False),
    ]

    # When the highlight gets within this many rows of the loaded tail and
    # more pages exist, request another batch.
    _LOAD_MORE_THRESHOLD = 10

    class FieldAccepted(Message):
        """
        Posted when the user picks a field-name suggestion (e.g.
        ``unit`` from a list of filter fields).  Accepting it appends
        ``:`` to the input so the user can keep typing a value.
        """

        def __init__(self, name: str) -> None:
            super().__init__()
            self.name = name

    class ValueAccepted(Message):
        """Posted when the user picks a value suggestion.

        ``field`` is the source column the value came from in the index
        (e.g. ``"unit"`` for ``rpm``).  Empty when the user's active
        search term already carries a field of its own — splicing the
        value bare avoids producing ``unit:unit:rpm``.
        """

        def __init__(self, field: str, value: str) -> None:
            super().__init__()
            self.field = field
            self.value = value

    def __init__(self, *args: Any, suggestion_cb: SuggestFn, **kwargs: Any) -> None:
        super().__init__(*args, **kwargs)
        self._suggestion_cb = suggestion_cb
        # Filter the dropdown is currently chasing — set on every ``request``.
        # Workers compare their captured ``filter_str`` against this to detect
        # that a newer keystroke arrived and bail.
        self._current_filter: str = ""
        # Filter the displayed items correspond to (= ``_current_filter`` once
        # results land).  LoadMore / LoadAll consult this so they only fire
        # when what's on screen still matches what was last requested.
        self._loaded_filter: str | None = None
        # Cursor position snapshotted at request time so subsequent LoadMore /
        # LoadAll calls reuse the same parsing context — once a page is on
        # screen its origin context is frozen.
        self._cursor_pos: int | None = None
        self._offset: int = 0
        self._has_more: bool = False

    # -- public API ----------------------------------------------------------

    def request(self, filter_str: str, cursor_pos: int | None) -> None:
        """Kick off a fresh suggest fetch; cancels any in-flight worker.

        Empty input hides the dropdown without touching the source — there's
        nothing to suggest on. No-op when ``filter_str`` and ``cursor_pos``
        match the in-flight request, so debounce-driven re-fires (or a
        ``SearchInput.flush`` followed by the same timer-fired message)
        don't cancel their own worker via ``exclusive=True``.
        """
        if filter_str == self._current_filter and cursor_pos == self._cursor_pos:
            return
        self._current_filter = filter_str
        self._cursor_pos = cursor_pos
        if not filter_str.strip():
            self.hide()
            return
        self.run_worker(
            lambda: self._do_suggest(filter_str, cursor_pos),
            exclusive=True,
            group="suggest",
            thread=True,
        )

    def _do_suggest(self, filter_str: str, cursor_pos: int | None) -> None:
        result = self._suggestion_cb(filter_str, cursor_pos, SUGGEST_PAGE_SIZE, 0)
        if result is None:
            self.app.call_from_thread(self.hide)
            return
        if filter_str != self._current_filter:
            return
        self.app.call_from_thread(self._apply_initial, filter_str, result)

    def _do_fetch_more(
        self,
        filter_str: str,
        cursor_pos: int | None,
        page_limit: int,
        jump_to_end: bool,
        offset: int,
    ) -> None:
        result = self._suggestion_cb(filter_str, cursor_pos, page_limit, offset)
        if result is None:
            return  # leave dropdown alone on failure
        if filter_str != self._current_filter or filter_str != self._loaded_filter:
            return
        self.app.call_from_thread(self._apply_more, filter_str, result, jump_to_end)

    def _apply_initial(self, filter_str: str, result: SuggestResult) -> None:
        if filter_str != self._current_filter:
            return
        self._show_items(result.items)
        self._has_more = result.has_more
        self._offset = result.value_count
        self._loaded_filter = filter_str

    def _apply_more(self, filter_str: str, result: SuggestResult, jump_to_end: bool) -> None:
        if filter_str != self._current_filter or filter_str != self._loaded_filter:
            return
        self._append_items(result.items)
        self._has_more = (self._offset + result.value_count) < result.total
        self._offset += result.value_count
        if jump_to_end and self.option_count > 0:
            self.highlighted = self.option_count - 1

    def _kick_more(self, page_limit: int, *, jump_to_end: bool) -> None:
        filter_str = self._loaded_filter
        if not filter_str:
            return
        cursor_pos = self._cursor_pos
        offset = self._offset
        self.run_worker(
            lambda: self._do_fetch_more(filter_str, cursor_pos, page_limit, jump_to_end, offset),
            exclusive=True,
            group="suggest",
            thread=True,
        )

    def _show_items(self, items: list[SuggestionItem]) -> None:
        self.clear_options()
        if not items:
            self._has_more = False
            self.remove_class("visible")
            return
        for item in items:
            self._add_suggestion_option(item)
        self.add_class("visible")
        if self.option_count > 0:
            self.highlighted = 0

    def _append_items(self, items: list[SuggestionItem]) -> None:
        for item in items:
            self._add_suggestion_option(item)

    def _add_suggestion_option(self, item: SuggestionItem) -> None:
        if isinstance(item, FieldSuggestion):
            label = f"{item.name}:  [dim]filter field[/dim]"
        elif item.field:
            label = f"{item.value}  [dim]{item.field}[/dim]"
        else:
            label = item.value
        self.add_option(SuggestionOption(label, item))

    def hide(self) -> None:
        self.clear_options()
        self._has_more = False
        self.remove_class("visible")

    def on_option_list_option_selected(self, event: OptionList.OptionSelected) -> None:
        event.stop()
        if not isinstance(event.option, SuggestionOption):
            return
        item = event.option.item
        if isinstance(item, FieldSuggestion):
            self.post_message(self.FieldAccepted(name=item.name))
        else:
            self.post_message(self.ValueAccepted(field=item.field, value=item.value))
        self.hide()

    def on_option_list_option_highlighted(self, event: OptionList.OptionHighlighted) -> None:
        if not self._has_more:
            return
        if event.option_index <= 0:
            return
        if event.option_index >= self.option_count - self._LOAD_MORE_THRESHOLD:
            self._has_more = False
            self._kick_more(SUGGEST_PAGE_SIZE, jump_to_end=False)

    def watch_scroll_y(self, old: float, new: float) -> None:
        """Mouse-wheel scroll near the bottom triggers the next page.

        Highlight-driven pagination only fires when the keyboard moves the
        selection (``on_option_list_option_highlighted``), so a user
        scrolling with the wheel would otherwise hit the bottom of the
        loaded items and stop.  We watch ``scroll_y`` and trigger when
        within a viewport-height of the maximum.
        """
        super().watch_scroll_y(old, new)
        if not self._has_more:
            return
        if new >= self.max_scroll_y - self.size.height:
            self._has_more = False
            self._kick_more(SUGGEST_PAGE_SIZE, jump_to_end=False)

    def action_load_all_and_end(self) -> None:
        """``End`` / ``G`` — load every remaining page, then jump to the
        true last item. Falls through to ``cursor_end`` when nothing else
        is pending."""
        if self._has_more:
            self._has_more = False
            self._kick_more(SUGGEST_MAX_TOTAL, jump_to_end=True)
        else:
            self.action_last()
