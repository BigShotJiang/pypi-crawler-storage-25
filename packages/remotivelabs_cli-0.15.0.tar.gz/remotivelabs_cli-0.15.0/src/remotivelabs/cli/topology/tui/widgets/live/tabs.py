"""Tabbed container for live subscription / chart sessions.

Owns the tab strip and the per-tab streaming workers; subscribe and
chart actions open new tabs that the user can navigate with vim-style
keys.  Tab content widgets (``SubscriptionView`` / ``ChartView``) live
in sibling modules.
"""

from __future__ import annotations

from collections.abc import Callable, Coroutine
from typing import Any, TypeVar

from textual.app import ComposeResult
from textual.binding import Binding
from textual.containers import Vertical
from textual.message import Message
from textual.widget import Widget
from textual.widgets import ContentSwitcher, Tab, Tabs
from textual.worker import Worker

from remotivelabs.cli.topology.tui.bindings import horizontal_nav_bindings, jump_nav_bindings
from remotivelabs.cli.topology.tui.rows import FrameRow, SignalRow
from remotivelabs.cli.topology.tui.widgets.live.chart import ChartView, RevealTarget
from remotivelabs.cli.topology.tui.widgets.live.subscription import SubscriptionView

V = TypeVar("V", bound=Widget)


class LiveTabs(Vertical, can_focus=False):
    """Tabbed container for live subscription / chart sessions.

    Each subscribe action opens a new tab; previous tabs persist until
    closed.  Tab content is either a ``ChartView`` (single signal) or a
    ``SubscriptionView`` (one or more frames).  The widget tracks
    per-tab streaming workers and cancels them when the tab is closed.
    """

    DEFAULT_CSS = """
    LiveTabs {
        width: 1fr;
    }
    LiveTabs #live-tabs {
        width: 1fr;
        overflow-x: auto;
    }
    LiveTabs #live-content {
        height: 1fr;
        width: 1fr;
    }
    """

    BINDINGS = [
        Binding("+", "increase", "More history"),
        Binding("-", "decrease", "Less history"),
        Binding("e", "expand_all", "Expand all"),
        Binding("c", "collapse_all", "Collapse all"),
        Binding("ctrl+n", "toggle_named_values", "Named values"),
        Binding("ctrl+w", "close_active_tab", "Close tab"),
        # ``t`` jumps the cursor in the signal tree to the row under
        # the active tab's cursor (chart's signal, or the focused
        # subscription row). Posts `RevealRequested` so the App handles
        # the actual tree navigation.
        Binding("t", "reveal_in_tree", "Open in tree"),
        # Tab strip nav: ``h``/``←`` previous, ``l``/``→`` next; ``j``/``↓``
        # drops into the signal list.  ``g``/``Home`` and ``G``/``End`` also
        # drop into the signals — but anchored on the first / last row —
        # mirroring what those keys do everywhere else in the app.
        *horizontal_nav_bindings("prev_tab", "next_tab", prev_label="Prev tab", next_label="Next tab"),
        *jump_nav_bindings("focus_signals_first", "focus_signals_last", first_label="Top", last_label="Bottom"),
        Binding("j,down", "focus_signals", show=False),
        # ``PgDown`` from the tab strip drops into the first frame's
        # header — same landing as ``g``/``Home`` but matches users'
        # spatial expectation of "page down into the content below".
        Binding("pagedown", "focus_signals_first", show=False),
    ]

    class TabClosed(Message):
        """Posted after a tab is removed; the parent screen uses this to
        refresh status / park focus when the last tab goes away.  The
        streaming worker is cancelled internally — listeners do not need
        to do that themselves."""

        def __init__(self, tab_id: str) -> None:
            super().__init__()
            self.tab_id = tab_id

    class TabOpened(Message):
        """Posted after a new tab is mounted (chart or subscription).

        Not posted when an existing tab is focused via
        `open_or_focus_chart` / `open_or_focus_subscription` —
        focusing an existing tab is a no-op for status purposes.
        """

        def __init__(self, tab_id: str) -> None:
            super().__init__()
            self.tab_id = tab_id

    class RevealRequested(Message):
        """Posted when the user wants the active tab's cursor row
        opened in the signal tree (``t`` binding). The App handles
        the actual tree navigation + focus switch."""

        def __init__(self, target: RevealTarget) -> None:
            super().__init__()
            self.target = target

    def __init__(self, **kwargs: Any) -> None:
        super().__init__(**kwargs)
        self._counter = 0
        # Bidirectional map between a stable subscription identity and its tab.
        # Used to dedupe: opening the "same" subscribe action focuses the
        # existing tab instead of creating a duplicate.
        self._key_to_tab: dict[str, str] = {}
        self._tab_to_key: dict[str, str] = {}
        # Single source of truth for "what's open" — tab id to content widget,
        # in insertion order.
        self._tabs: dict[str, Widget] = {}
        # Streaming workers tied to each tab. The view owns them so tab
        # close / reset / unmount cancels the right worker without round-
        # tripping a message back through the App.
        self._tab_workers: dict[str, Worker[None]] = {}
        # Per-tab work coroutine factory — kept so ``restart_all_workers``
        # can re-run it after a reconnect without rebuilding the tab.
        self._tab_works: dict[str, Callable[[Widget], Coroutine[Any, Any, None]]] = {}
        # Original tab labels, indexed by tab id.  We prefix labels with
        # an indicator (e.g. ``[Δ]``) when on-change mode is on, then
        # restore from this map when it's off — derived from this dict
        # rather than re-derived from the underlying signals/frames so
        # toggling stays cheap and survives label changes upstream.
        self._tab_base_labels: dict[str, str] = {}

    def compose(self) -> ComposeResult:
        yield Tabs(id="live-tabs")
        yield ContentSwitcher(id="live-content")

    def _tabs_widget(self) -> Tabs:
        return self.query_one("#live-tabs", Tabs)

    def _switcher(self) -> ContentSwitcher:
        return self.query_one("#live-content", ContentSwitcher)

    @staticmethod
    def _content_id(tab_id: str) -> str:
        # ContentSwitcher.current matches a child id — keep it derivable from tab id.
        return f"{tab_id}-content"

    @property
    def tab_count(self) -> int:
        return len(self._tabs)

    @property
    def active_tab_id(self) -> str | None:
        active = self._tabs_widget().active
        return active or None

    def _new_tab_id(self) -> str:
        self._counter += 1
        return f"livetab-{self._counter}"

    @staticmethod
    def chart_key(namespace: str, signal_name: str) -> str:
        return f"chart:{namespace}:{signal_name}"

    @staticmethod
    def subscription_key(
        signals: dict[str, SignalRow],
        frames: dict[str, FrameRow] | None,
    ) -> str:
        sig_keys = tuple(sorted(signals.keys()))
        frame_keys = tuple(sorted((frames or {}).keys()))
        return f"sub:{sig_keys}:{frame_keys}"

    def find_tab_by_key(self, key: str) -> str | None:
        return self._key_to_tab.get(key)

    def focus_tab(self, tab_id: str) -> None:
        self._tabs_widget().active = tab_id

    def open_or_focus_chart(
        self,
        namespace: str,
        signal_name: str,
        *,
        work: Callable[[ChartView], Coroutine[Any, Any, None]],
    ) -> str:
        """Focus the existing chart tab for this signal, or open a new one.

        ``work`` is owned by the caller (it closes over the broker); this
        view starts and tracks the resulting ``Worker``.  Returns the tab id.
        Posts `TabOpened` only when a new tab is mounted.
        """
        existing = self.find_tab_by_key(self.chart_key(namespace, signal_name))
        if existing is not None:
            self.focus_tab(existing)
            return existing
        return self.add_chart_tab(namespace, signal_name, work=work)

    def open_or_focus_subscription(
        self,
        signals: dict[str, SignalRow],
        frames: dict[str, FrameRow] | None = None,
        *,
        work: Callable[[SubscriptionView], Coroutine[Any, Any, None]],
    ) -> str:
        """Focus the existing subscription tab for this set, or open a new one.

        See `open_or_focus_chart` for the ownership rule.
        """
        existing = self.find_tab_by_key(self.subscription_key(signals, frames))
        if existing is not None:
            self.focus_tab(existing)
            return existing
        return self.add_subscription_tab(signals, frames, work=work)

    def add_chart_tab(
        self,
        namespace: str,
        signal_name: str,
        *,
        work: Callable[[ChartView], Coroutine[Any, Any, None]],
    ) -> str:
        """Always-create primitive: mount a fresh chart tab and start
        ``work``.  Callers that want dedupe (the common case) should
        use `open_or_focus_chart` instead.
        """
        chart = ChartView()
        chart.start(namespace, signal_name)
        return self._add_tab(
            content=chart,
            label=signal_name,
            key=self.chart_key(namespace, signal_name),
            work=work,
        )

    def add_subscription_tab(
        self,
        signals: dict[str, SignalRow],
        frames: dict[str, FrameRow] | None = None,
        *,
        work: Callable[[SubscriptionView], Coroutine[Any, Any, None]],
    ) -> str:
        """Always-create primitive: mount a fresh subscription tab.
        Callers that want dedupe should use
        `open_or_focus_subscription`.
        """
        sub = SubscriptionView()
        sub.start(signals, frames)
        return self._add_tab(
            content=sub,
            label=self._subscription_label(signals, frames),
            key=self.subscription_key(signals, frames),
            work=work,
        )

    def _add_tab(
        self,
        *,
        content: V,
        label: str,
        key: str,
        work: Callable[[V], Coroutine[Any, Any, None]],
    ) -> str:
        """Mount ``content`` into a new tab and start its streaming worker.

        Shared core of `add_chart_tab` and
        `add_subscription_tab` — they only differ in widget type,
        label, and dedup key.  ``content.start()`` is the caller's
        responsibility because the start signature is widget-specific
        (one signal vs. many signals + frames).
        """
        tab_id = self._new_tab_id()
        content.id = self._content_id(tab_id)
        self._switcher().mount(content)
        self._tabs_widget().add_tab(Tab(self._truncate_label(label), id=tab_id))
        self._key_to_tab[key] = tab_id
        self._tab_to_key[tab_id] = key
        self._tabs[tab_id] = content
        self._tabs_widget().active = tab_id
        self.add_class("visible")
        self._tab_works[tab_id] = work  # type: ignore[assignment]
        self._tab_workers[tab_id] = self.run_worker(work(content))
        self.post_message(self.TabOpened(tab_id))
        return tab_id

    @staticmethod
    def _subscription_label(
        signals: dict[str, SignalRow],
        frames: dict[str, FrameRow] | None,
    ) -> str:
        frame_names: set[str] = set()
        for s in signals.values():
            frame_names.add(s.frame_name)
        if frames:
            for f in frames.values():
                frame_names.add(f.frame_name)
        names = sorted(frame_names)
        # Append a count of subscribed entries so users can disambiguate
        # near-duplicate tab names at a glance.
        count = len(signals) + len(frames or {})
        suffix = f" ({count})" if count else ""
        if len(names) == 1:
            return f"{names[0]}{suffix}"
        if len(names) > 1:
            return f"{names[0]} +{len(names) - 1}{suffix}"
        return f"(empty){suffix}"

    @staticmethod
    def _truncate_label(label: str, max_len: int = 24) -> str:
        """Trim ``label`` to fit a tab strip; ellipsises long names."""
        return label if len(label) <= max_len else label[: max_len - 1] + "…"

    def cancel_all_workers(self) -> None:
        """Synchronously cancel and forget every streaming worker.

        Useful when the caller needs an immediate stop (e.g. reindex) and
        will follow up with the async tab teardown via ``reset``.
        """
        for worker in self._tab_workers.values():
            worker.cancel()
        self._tab_workers.clear()

    def restart_worker(
        self,
        view: V,
        work: Callable[[V], Coroutine[Any, Any, None]],
    ) -> None:
        """Cancel ``view``'s current streaming worker and start a fresh one.

        Used when a tab needs its subscribe stream restarted with new
        parameters (e.g. ``SubscriptionView`` toggling on-change mode) —
        the new worker reads any updated state off the view at call time.
        Updates the stored work callable so a later ``restart_all_workers``
        rebuilds with the same parameters. No-op if the view isn't tabbed.
        """
        tab_id = next((tid for tid, v in self._tabs.items() if v is view), None)
        if tab_id is None:
            return
        old = self._tab_workers.pop(tab_id, None)
        if old is not None:
            old.cancel()
        self._tab_works[tab_id] = work  # type: ignore[assignment]
        self._tab_workers[tab_id] = self.run_worker(work(view))
        self._update_tab_indicator(tab_id, view)

    def restart_all_workers(self) -> None:
        """Re-run every tab's stored work callable; called on reconnect."""
        for tab_id, view in self._tabs.items():
            work = self._tab_works.get(tab_id)
            if work is None:
                continue
            old = self._tab_workers.pop(tab_id, None)
            if old is not None:
                old.cancel()
            self._tab_workers[tab_id] = self.run_worker(work(view))

    def _update_tab_indicator(self, tab_id: str, view: Widget) -> None:
        """Reflect a SubscriptionView's on-change mode in its tab label.

        The base (un-prefixed) label is captured in
        `_tab_base_labels` the first time so the prefix is
        reversible.  Brackets are escaped because Textual's
        ``Content`` treats unescaped ``[...]`` as markup tags and
        would strip the indicator entirely.
        """
        if not isinstance(view, SubscriptionView):
            return
        try:
            tab = self._tabs_widget().query_one(f"#{tab_id}", Tab)
        except Exception:
            return
        base = self._tab_base_labels.get(tab_id)
        if base is None:
            base = tab.label_text if hasattr(tab, "label_text") else str(tab.label)
            self._tab_base_labels[tab_id] = base
        prefix = r"\[Δ] " if view.on_change_mode is not False else ""
        tab.label = f"{prefix}{base}"  # type: ignore[assignment]  # ContentText accepts str

    async def reset(self) -> None:
        """Close all tabs and hide the view.

        Async because ``Tabs.remove_tab`` returns an ``AwaitComplete`` that
        must be awaited — discarding it leaves removal happening lazily on
        the next event-loop tick, which races against any synchronous
        re-add by the caller (e.g. reindex → immediate subscribe).
        """
        self.cancel_all_workers()
        for tab_id, view in list(self._tabs.items()):
            await self._tabs_widget().remove_tab(tab_id)
            view.remove()
        self._tabs.clear()
        self._counter = 0
        self._key_to_tab.clear()
        self._tab_to_key.clear()
        self._tab_works.clear()
        self._tab_base_labels.clear()
        self.remove_class("visible")

    async def close_active_tab(self) -> str | None:
        """Close the currently active tab. Returns the closed tab id, or None
        if there were no tabs."""
        return await self._close_tab(self.active_tab_id)

    async def _close_tab(self, tab_id: str | None) -> str | None:
        if tab_id is None or tab_id not in self._tabs:
            return None
        worker = self._tab_workers.pop(tab_id, None)
        if worker is not None:
            worker.cancel()
        view = self._tabs.pop(tab_id)
        await self._tabs_widget().remove_tab(tab_id)
        view.remove()
        key = self._tab_to_key.pop(tab_id, None)
        if key is not None:
            self._key_to_tab.pop(key, None)
        self._tab_works.pop(tab_id, None)
        self._tab_base_labels.pop(tab_id, None)
        if self.tab_count == 0:
            self.remove_class("visible")
        # Refocusing #signal-tree on empty isn't ours to do — it lives on the
        # parent screen. Let the app decide via the TabClosed message.
        self.post_message(self.TabClosed(tab_id))
        return tab_id

    def on_tabs_tab_activated(self, event: Tabs.TabActivated) -> None:
        if event.tab.id:
            self._switcher().current = self._content_id(event.tab.id)

    def on_unmount(self) -> None:
        # Textual cancels the widget's pump and timers on unmount but does
        # not touch workers, so we have to do it here — otherwise a
        # streaming worker can outlive the view and try to write to a
        # removed widget.
        self.cancel_all_workers()

    def _active_subscription_view(self) -> SubscriptionView | None:
        active = self.active_tab_id
        view = self._tabs.get(active) if active else None
        return view if isinstance(view, SubscriptionView) else None

    def _active_view(self) -> ChartView | SubscriptionView | None:
        active = self.active_tab_id
        view = self._tabs.get(active) if active else None
        return view if isinstance(view, (ChartView, SubscriptionView)) else None

    def action_reveal_in_tree(self) -> None:
        """Post `RevealRequested` for the active tab's cursor row.

        Silent no-op when there's no active view or the cursor isn't on
        a revealable row (e.g. focus on the tab strip rather than a
        FrameTable). The App's handler does the tree navigation.
        """
        view = self._active_view()
        if view is None:
            return
        target = view.tree_target()
        if target is not None:
            self.post_message(self.RevealRequested(target))

    def action_close_active_tab(self) -> None:
        # Wrapper so the binding system can call it (binding actions are sync).
        self.run_worker(self.close_active_tab(), exclusive=False)

    def action_increase(self) -> None:
        sub = self._active_subscription_view()
        if sub is not None:
            sub.adjust_history_depth(1)

    def action_decrease(self) -> None:
        sub = self._active_subscription_view()
        if sub is not None:
            sub.adjust_history_depth(-1)

    def action_expand_all(self) -> None:
        sub = self._active_subscription_view()
        if sub is not None:
            sub.action_expand_all()

    def action_collapse_all(self) -> None:
        sub = self._active_subscription_view()
        if sub is not None:
            sub.action_collapse_all()

    def action_toggle_named_values(self) -> None:
        # Proxy the active view's toggle so ``Ctrl+N`` also works when
        # focus sits on the tab strip, mirroring how ``e`` / ``c`` /
        # ``+`` / ``-`` reach into the active view.
        sub = self._active_subscription_view()
        if sub is not None:
            sub.action_toggle_named_values()

    def action_prev_tab(self) -> None:
        self._tabs_widget().action_previous_tab()

    def action_next_tab(self) -> None:
        self._tabs_widget().action_next_tab()

    def action_focus_signals_first(self) -> None:
        """``g`` / ``Home`` from the tab strip — drop into the active
        subscription view's signal list at the top.

        ``Widget.focus()`` defers the actual focus change via
        ``call_later``, and ``scroll_to_widget`` defers its scroll until
        the next refresh.  Running ``action_cursor_first`` synchronously
        races both — the first press would queue a scroll that lands too
        late.  ``call_after_refresh`` waits for focus + layout to settle
        before driving the cursor + scroll.
        """
        sub = self._active_subscription_view()
        if sub is not None and sub.has_rows:
            sub.focus()
            self.call_after_refresh(sub.action_cursor_first)

    def action_focus_signals_last(self) -> None:
        """``G`` / ``End`` from the tab strip — drop into the active
        subscription view's signal list at the bottom.  See
        `action_focus_signals_first` for why we ``call_after_refresh``.
        """
        sub = self._active_subscription_view()
        if sub is not None and sub.has_rows:
            sub.focus()
            self.call_after_refresh(sub.action_cursor_last)

    def action_focus_signals(self) -> None:
        """Move focus from the tab strip into the active subscription view.

        Focuses the panel itself (single focusable surface, like ``Tree``);
        ``SubscriptionView.on_focus`` parks the cursor on the first row.
        """
        sub = self._active_subscription_view()
        if sub is not None and sub.has_rows:
            sub.focus()

    def on_subscription_view_cursor_escape(self, event: SubscriptionView.CursorEscape) -> None:
        """``SubscriptionView`` posts this when ``k``/``↑`` is pressed at the
        topmost cursor position — bring focus back to the tab strip."""
        event.stop()
        self._tabs_widget().focus()
