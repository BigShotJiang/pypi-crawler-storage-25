"""Operations on the search-input string — both directions.

The TUI's search input is the string form of a `Query`. This module
holds the pure functions that translate between the two:

- **input → query** (parse side): clean up partial input, recover the
  active term mid-typing, and split the parsed query into the
  ``(active, selected)`` shape ``index.suggest`` expects.
- **suggestion pick → input** (splice side): quote a value safely and
  splice a chosen field/value back into the input string at the cursor.
"""

from __future__ import annotations

import re
from dataclasses import dataclass

from luqum.exceptions import ParseError

from remotivelabs.cli.search.query import ALL_FILTER_FIELDS, Query
from remotivelabs.cli.search.types import Group, ParsedQuery, Term

_INCOMPLETE_TAIL_RE = re.compile(r"(:|\bAND|\bOR|\bNOT|\bTO|\+|-|&&|\|\||<=?|>=?)$")
_QUOTED_LITERAL_RE = re.compile(r'"(?:\\.|[^"\\])*"')
# A ``/`` that could plausibly be a regex delimiter — preceded by ``:``,
# whitespace, ``(``, or the start of the string.
_REGEX_START_RE = re.compile(r"(?:^|[\s:(])/")


def _try_parse(filter_str: str) -> Query | None:
    """Parse ``filter_str`` as a Query, or ``None`` on ParseError.

    Uses the Lucene parser because the TUI search box exposes the full
    grammar (negation, ranges, regex, parens) — those features come from
    this module's recovery logic and would silently no-op against the
    shlex ``Query.parse`` path.
    """
    try:
        return Query.parse_lucene(filter_str)
    except ParseError:
        return None


def _unescaped_count(s: str, delim: str) -> int:
    """Count occurrences of ``delim`` not preceded by a backslash escape."""
    count = 0
    i = 0
    while i < len(s):
        if s[i] == "\\" and i + 1 < len(s):
            i += 2
            continue
        if s[i] == delim:
            count += 1
        i += 1
    return count


def _has_unbalanced_brackets(s: str) -> bool:
    """Bracket parity, ignoring content inside closed double quotes.

    Quoted literals are opaque to query syntax, so ``unit:"L/100km"``
    must not flag its contents as unbalanced.
    """
    bare = _QUOTED_LITERAL_RE.sub("", s)
    return (
        _unescaped_count(bare, "(") != _unescaped_count(bare, ")")
        or _unescaped_count(bare, "[") != _unescaped_count(bare, "]")
        or _unescaped_count(bare, "{") != _unescaped_count(bare, "}")
    )


def _has_half_open_regex(s: str) -> bool:
    """Odd number of ``/`` and at least one in a regex-plausible position
    (after ``:``, whitespace, ``(``, or start). Otherwise a literal ``/``
    inside a bare value (``unit:L/100km``) gets misread as half-open."""
    bare = _QUOTED_LITERAL_RE.sub("", s)
    return bool(_REGEX_START_RE.search(bare)) and _unescaped_count(bare, "/") % 2 != 0


def _has_open_quote(s: str) -> bool:
    """Odd number of unescaped ``"`` — counted on the original string so
    a lone opening quote still trips this even though
    `_QUOTED_LITERAL_RE` would strip closed pairs."""
    return _unescaped_count(s, '"') % 2 != 0


def _is_incomplete_query(s: str) -> bool:
    """True if ``s`` is mid-typing and clearly not yet a complete query."""
    s = s.strip()
    if not s:
        return False
    if _has_unbalanced_brackets(s) or _has_half_open_regex(s) or _has_open_quote(s):
        return True
    return bool(_INCOMPLETE_TAIL_RE.search(s))


def _strip_incomplete_tail(s: str) -> str:
    """Drop trailing whitespace-separated tokens until the remainder parses."""
    tokens = s.split()
    while tokens and _is_incomplete_query(" ".join(tokens)):
        tokens.pop()
    return " ".join(tokens)


def _resolve_effective_filter(s: str) -> str:
    """Pick the actual filter string to search on for possibly-incomplete input."""
    if not _is_incomplete_query(s):
        return s
    if _has_open_quote(s) and not _is_incomplete_query(s + '"'):
        return s + '"'
    return _strip_incomplete_tail(s)


_RANGE_FIELD_RE = re.compile(r"(\w+):$")
_RANGE_TO_RE = re.compile(r"\bTO\s+(.*)$")
_TRAILING_TOKEN_RE = re.compile(r"\S+$")
_TRAILING_FIELD_RE = re.compile(r"(\w+):\s*$")
# Boolean operator left dangling after we strip a trailing ``field:``.
# ``IGNORECASE`` only affects the AND/OR/NOT alternation; the symbol
# operators are case-insensitive by construction.
_TRAILING_OP_RE = re.compile(r"(?:\s+(?:AND|OR|NOT|&&|\|\|)|\s*[+\-])\s*$", re.IGNORECASE)


def _recover_range_active(filter_str: str) -> Term | None:
    """Active term for a mid-typing range like ``field:[X TO Y``."""
    last_open = max(filter_str.rfind("["), filter_str.rfind("{"))
    if last_open < 0:
        return None
    last_close = max(filter_str.rfind("]"), filter_str.rfind("}"))
    if last_close > last_open:
        return None
    m = _RANGE_FIELD_RE.search(filter_str[:last_open])
    if not m:
        return None
    field_name = m.group(1)
    if field_name not in ALL_FILTER_FIELDS:
        return None
    content = filter_str[last_open + 1 :]
    to_match = _RANGE_TO_RE.search(content)
    typed = (to_match.group(1) if to_match else content).strip()
    return Term(value=typed, fields=frozenset({field_name}))


def _recover_trailing_field(filter_str: str) -> tuple[Term, Group] | None:
    """If ``filter_str`` ends in ``field:``, synthesize the active Term
    for the empty value being typed and parse the prefix into a Group so
    its terms can still scope suggestions. Returns ``None`` when the
    trailing token isn't a known filter field or the prefix won't parse.
    """
    m = _TRAILING_FIELD_RE.search(filter_str)
    if not m or m.group(1) not in ALL_FILTER_FIELDS:
        return None
    active = Term(value="", fields=frozenset({m.group(1)}))
    # Strip a dangling boolean operator left over after removing ``field:``
    # so ``engine AND coolant_temp:`` parses as just ``engine``.
    prefix = _TRAILING_OP_RE.sub("", filter_str[: m.start()]).rstrip()
    if not prefix:
        return active, Group(children=(active,))
    prefix_query = _try_parse(prefix)
    if prefix_query is None:
        return None
    prefix_root = prefix_query.parsed.root
    return active, Group(children=(*prefix_root.children, active), operator=prefix_root.operator)


def _parse_for_suggest(filter_str: str) -> Query | None:
    """Try to parse a possibly-incomplete query for suggestion purposes."""
    parsed = _try_parse(filter_str)
    if parsed is not None:
        return parsed
    if _has_open_quote(filter_str):
        parsed = _try_parse(filter_str + '"')
        if parsed is not None:
            return parsed
    field_recovery = _recover_trailing_field(filter_str)
    if field_recovery is not None:
        active, root = field_recovery
        return Query(ParsedQuery(root=root, active_term=active))
    range_active = _recover_range_active(filter_str)
    if range_active is not None:
        return Query(ParsedQuery(root=Group(children=()), active_term=range_active))
    return None


def _remove_term_by_identity(group: Group, target: Term) -> Group:
    """Return ``group`` with the exact ``target`` Term object removed.

    Identity comparison (``is``) is correct here: ``LuqumConverter`` keeps
    a back-reference to the same Term it inserted into the tree as
    ``active_term``, so the term we want to drop is always the same object
    we walk past during traversal. Empty subgroups collapse out so the
    resulting tree stays minimal.
    """
    new_children: list[Term | Group] = []
    for child in group.children:
        if isinstance(child, Term):
            if child is target:
                continue
            new_children.append(child)
        else:
            sub = _remove_term_by_identity(child, target)
            if sub.children:
                new_children.append(sub)
    return Group(children=tuple(new_children), operator=group.operator)


def _split_for_suggest(filter_str: str) -> tuple[Query | None, tuple[Query, ...]]:
    """Split a typed filter into ``(active_only, selected)``."""
    parsed = _parse_for_suggest(filter_str)
    if parsed is None:
        return None, ()
    active = parsed.parsed.active_term
    if active is None:
        return parsed, ()
    rest_root = _remove_term_by_identity(parsed.parsed.root, active)
    active_only = Query(ParsedQuery(root=Group(children=(active,)), active_term=active))
    if not rest_root.children:
        return active_only, ()
    selected = Query(ParsedQuery(root=rest_root, active_term=None))
    return active_only, (selected,)


def _split_at_cursor(filter_str: str, cursor_pos: int | None) -> tuple[Query | None, tuple[Query, ...]]:
    """Cursor-aware split. When the cursor is in the middle of the input,
    parse only the prefix up to it so the active term reflects what the user
    is typing right now (rather than whatever happens to come last). The
    suffix is parsed separately and folded into ``selected`` so the backend
    still scopes suggestions to the full filter.
    """
    if cursor_pos is None or not 0 < cursor_pos < len(filter_str):
        return _split_for_suggest(filter_str)
    active_query, selected = _split_for_suggest(filter_str[:cursor_pos])
    suffix = _try_parse(filter_str[cursor_pos:])
    if suffix is None:
        return active_query, selected
    if suffix.parsed.root.children:
        selected = (*selected, suffix)
    return active_query, selected


@dataclass(frozen=True)
class Analysis:
    effective_filter: str
    active: Query | None
    selected: tuple[Query, ...]


def analyze(filter_str: str, cursor_pos: int | None = None) -> Analysis:
    """Parse + cursor split + effective-filter resolution in one call.

    - ``effective_filter`` — the string to actually search on (incomplete
      tails closed/stripped).
    - ``active`` — the active term being typed, isolated as its own query;
      ``None`` when the input doesn't recover.
    - ``selected`` — committed terms (everything except the active one).
    """
    active, selected = _split_at_cursor(filter_str, cursor_pos)
    return Analysis(
        effective_filter=_resolve_effective_filter(filter_str),
        active=active,
        selected=selected,
    )


# Bare-word values that luqum parses cleanly as a single token: alphanumerics,
# underscore, dot, and *internal* hyphens. A leading hyphen would be parsed as
# a negation marker, so we require the first char to be non-hyphen.
_SAFE_VALUE_RE = re.compile(r"^[A-Za-z0-9_.][A-Za-z0-9_.\-]*$")


def quote_value(value: str) -> str:
    """Wrap in double quotes if the value contains anything the query parser would split on."""
    if _SAFE_VALUE_RE.match(value):
        return value
    return '"' + value.replace('"', '\\"') + '"'


def _splice_at_active(value: str, active_value: str, replacement: str, *, raw_value: str | None = None) -> str:
    """Replace the rightmost occurrence of ``active_value`` in ``value``.

    Honours ``/.../`` (regex) and ``"..."`` literal boundaries — when the
    active span is wrapped in either, the surrounding delimiters are
    preserved. ``raw_value`` is the unquoted form used inside an existing
    quote pair; when ``None`` the function takes the field-pick path
    which has no quote handling.
    """
    idx = value.rfind(active_value)
    if idx < 0:
        return replacement
    end = idx + len(active_value)
    preceded_by_slash = idx > 0 and value[idx - 1] == "/"
    followed_by_slash = end < len(value) and value[end] == "/"
    if preceded_by_slash and followed_by_slash:
        return value[: idx - 1] + replacement + value[end + 1 :]
    if raw_value is not None:
        preceded_by_quote = idx > 0 and value[idx - 1] == '"'
        followed_by_quote = end < len(value) and value[end] == '"'
        if preceded_by_quote and followed_by_quote:
            return value[:idx] + raw_value + value[end:]
        if preceded_by_quote:
            return value[:idx] + raw_value + '"' + value[end:]
    return value[:idx] + replacement + value[end:]


def _splice_without_active(value: str, replacement: str) -> str:
    """Append ``replacement`` to ``value`` for the no-active-term case."""
    m = _TRAILING_TOKEN_RE.search(value)
    if m and ":" in m.group():
        return value[: m.start()] + replacement
    if value.strip():
        sep = "" if value.endswith(" ") else " "
        return value + sep + replacement
    return replacement


def _head_tail(value: str, cursor_pos: int) -> tuple[str, str]:
    """Cursor-aware prefix/suffix split — splices operate on the prefix only."""
    if 0 < cursor_pos < len(value):
        return value[:cursor_pos], value[cursor_pos:]
    return value, ""


def _recover_active_for_splice(head: str) -> Term | None:
    """Active-term lookup tuned for the splice path.

    Drops the misleading ``field:"`` recovery that luqum produces when
    the user has typed a bare opening quote — its ``value`` ends with
    ``field:`` and would derail the splice.
    """
    query = _parse_for_suggest(head)
    active = query.parsed.active_term if query else None
    if active and active.value.endswith(":") and not active.fields:
        return None
    return active


def _splice(head: str, active: Term | None, replacement: str, *, raw_value: str | None = None) -> str:
    """Place ``replacement`` into ``head`` per the active-term state.

    Three cases: an active term with non-empty value (replace the rightmost
    occurrence preserving any quote/regex delimiters), an active term with
    empty value (append directly so an empty ``field:`` trigger doesn't
    duplicate), or no active term (append with separator handling).
    """
    if active and active.value:
        return _splice_at_active(head, active.value, replacement, raw_value=raw_value)
    if active is not None:
        return head + replacement
    return _splice_without_active(head, replacement)


def apply_field_suggestion(value: str, cursor_pos: int, name: str) -> tuple[str, int]:
    """Splice a field-name pick at ``cursor_pos`` — appends ``:``."""
    head, tail = _head_tail(value, cursor_pos)
    head = _splice(head, _recover_active_for_splice(head), f"{name}:")
    return head + tail, len(head)


def apply_value_suggestion(value: str, cursor_pos: int, *, field: str, value_text: str) -> tuple[str, int]:
    """Splice a value pick at ``cursor_pos``.

    ``field`` is the source column the value came from (may be empty
    when the active term already carries a field of its own — the
    splicer keeps the existing prefix to avoid ``unit:unit:rpm``).
    Quoting is handled internally via ``quote_value``.
    """
    head, tail = _head_tail(value, cursor_pos)
    active = _recover_active_for_splice(head)
    active_has_field = bool(active and active.fields)
    if value_text and field and not active_has_field:
        replacement = f"{field}:{quote_value(value_text)}"
    else:
        replacement = quote_value(value_text) if value_text else ""
    head = _splice(head, active, replacement, raw_value=value_text)
    return head + tail, len(head)


__all__ = [
    "Analysis",
    "analyze",
    "apply_field_suggestion",
    "apply_value_suggestion",
    "quote_value",
]
