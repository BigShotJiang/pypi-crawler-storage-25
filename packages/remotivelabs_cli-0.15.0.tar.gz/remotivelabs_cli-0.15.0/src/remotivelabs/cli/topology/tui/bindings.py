from __future__ import annotations

from textual.binding import Binding


def vertical_nav_bindings(down_action: str, up_action: str, *, show: bool = False) -> list[Binding]:
    """``j``/``↓`` → ``down_action``, ``k``/``↑`` → ``up_action``."""
    return [
        Binding("j,down", down_action, "Down", show=show),
        Binding("k,up", up_action, "Up", show=show),
    ]


def arrow_nav_bindings(down_action: str, up_action: str, *, show: bool = False, priority: bool = False) -> list[Binding]:
    """``↑`` / ``↓`` only — used by screens whose focused widget is an
    ``Input`` where ``j`` / ``k`` would be typed text. ``priority=True``
    makes the arrows win over the focused Input's own bindings."""
    return [
        Binding("up", up_action, "Up", show=show, priority=priority),
        Binding("down", down_action, "Down", show=show, priority=priority),
    ]


def jump_nav_bindings(  # noqa: PLR0913 — keyword-only knobs are easier to read here than a config dataclass
    first_action: str,
    last_action: str,
    *,
    show: bool = False,
    priority_anchors: bool = True,
    first_label: str = "Top",
    last_label: str = "Bottom",
) -> list[Binding]:
    """``g``/``Home`` → ``first_action``, ``G``/``End`` → ``last_action``."""
    return [
        Binding("g", first_action, first_label, show=show),
        Binding("home", first_action, show=False, priority=priority_anchors),
        Binding("G", last_action, last_label, show=show),
        Binding("end", last_action, show=False, priority=priority_anchors),
    ]


def horizontal_nav_bindings(
    prev_action: str,
    next_action: str,
    *,
    show: bool = False,
    prev_label: str = "Prev",
    next_label: str = "Next",
) -> list[Binding]:
    """``h``/``←`` → ``prev_action``, ``l``/``→`` → ``next_action``."""
    return [
        Binding("h,left", prev_action, prev_label, show=show),
        Binding("l,right", next_action, next_label, show=show),
    ]
