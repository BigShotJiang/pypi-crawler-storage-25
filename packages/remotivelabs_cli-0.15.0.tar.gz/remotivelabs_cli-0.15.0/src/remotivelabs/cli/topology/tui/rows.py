"""Domain types for the TUI explorer — typed Row records returned by the search index."""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Literal


@dataclass
class Row:
    """Base row from the search index."""

    namespace: str
    frame_name: str
    type: Literal["frame", "signal"] = "frame"
    description: str | None = None
    unit: str | None = None
    senders: str | None = None
    receivers: str | None = None

    @staticmethod
    def from_dict(d: dict[str, Any]) -> Row:
        """Convert a search result dict to a typed Row."""
        if d.get("type") == "signal":
            return SignalRow(
                type="signal",
                namespace=d.get("namespace") or "",
                frame_name=d.get("frame_name") or "",
                signal_name=d.get("signal_name") or "",
                description=d.get("description"),
                unit=d.get("unit"),
                senders=d.get("senders"),
                receivers=d.get("receivers"),
                start_bit=d.get("start_bit"),
                size=d.get("size"),
                factor=d.get("factor"),
                offset=d.get("offset"),
                min=d.get("min"),
                max=d.get("max"),
                is_signed=d.get("is_signed"),
                is_big_endian=d.get("is_big_endian"),
                is_ieee_floating_type=d.get("is_ieee_floating_type"),
                is_raw=d.get("is_raw"),
                named_values_json=d.get("named_values_json"),
                start_value=d.get("start_value"),
            )
        return FrameRow(
            type="frame",
            namespace=d.get("namespace") or "",
            frame_name=d.get("frame_name") or "",
            description=d.get("description"),
            unit=d.get("unit"),
            senders=d.get("senders"),
            receivers=d.get("receivers"),
            payload_size=d.get("payload_size"),
            cycle_time=d.get("cycle_time"),
        )

    @property
    def key(self) -> str:
        """Unique key for this row, ``"namespace:name"``.

        Subclasses override to use the right name field; the base
        implementation falls back to the frame name so a bare ``Row``
        (rare; only the ``from_dict`` factory returns the typed
        subclasses) still has a sensible identity.
        """
        return f"{self.namespace}:{self.frame_name}"


@dataclass
class FrameRow(Row):
    """A frame row from the search index."""

    type: Literal["frame"] = "frame"
    payload_size: int | None = None
    cycle_time: float | None = None


@dataclass
class SignalRow(Row):
    """A signal row from the search index."""

    type: Literal["signal"] = "signal"
    signal_name: str = ""
    start_bit: int | None = None
    size: int | None = None
    factor: float | None = None
    offset: float | None = None
    min: float | None = None
    max: float | None = None
    is_signed: bool | None = None
    is_big_endian: bool | None = None
    is_ieee_floating_type: bool | None = None
    is_raw: bool | None = None
    named_values_json: str | None = None
    start_value: float | None = None

    @property
    def key(self) -> str:
        return f"{self.namespace}:{self.signal_name}"
