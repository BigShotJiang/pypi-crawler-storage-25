"""Detail panel for the currently-selected signal / frame row."""

from __future__ import annotations

import time
from collections.abc import Callable, Iterable
from typing import Any

from rich.markup import escape as rich_escape
from textual.message import Message
from textual.widgets import Static

from remotivelabs.cli.search.columns import COLUMNS
from remotivelabs.cli.topology.tui.broker.state import DISTRIBUTION_WINDOW_SECS, HISTORY_LEN, LivenessState, NamespaceSnapshot
from remotivelabs.cli.topology.tui.formatting import format_named_values, kv_line
from remotivelabs.cli.topology.tui.rows import FrameRow, Row, SignalRow

_SPARKLINE_BLOCKS = "▁▂▃▄▅▆▇█"
_SPARKLINE_PAD = "▁"

# Display labels for the bool fields rendered on SignalRow.  Bool columns absent
# from this map (e.g. ``is_can_fd``, ``is_extended``) belong to other row types
# and are skipped here.
SIGNAL_BOOL_LABELS: dict[str, str] = {
    "is_signed": "Signed",
    "is_big_endian": "Big endian",
    "is_ieee_floating_type": "IEEE float",
    "is_raw": "Raw signal",
}


def sparkline(values: Iterable[int], width: int | None = None) -> str:
    vs = list(values)
    if not vs:
        return _SPARKLINE_PAD * (width or 0)
    hi = max(vs)
    if hi == 0:
        body = _SPARKLINE_BLOCKS[0] * len(vs)
    else:
        n = len(_SPARKLINE_BLOCKS)
        body = "".join(_SPARKLINE_BLOCKS[min(n - 1, int(v / hi * (n - 1)))] for v in vs)
    if width is None or len(body) >= width:
        return body
    return _SPARKLINE_PAD * (width - len(body)) + body


def _relative_time(seen_at: float, now: float | None = None) -> str:
    """Human-friendly ``X ago`` for a monotonic timestamp."""
    current = time.monotonic() if now is None else now
    delta = max(0.0, current - seen_at)
    if delta < 1:
        return "just now"
    if delta < 60:
        return f"{int(delta)}s ago"
    if delta < 3600:
        return f"{int(delta / 60)}m ago"
    return f"{int(delta / 3600)}h ago"


def escape_action_param(value: str) -> str:
    """Escape a string for safe use inside a Rich [@click] action parameter."""
    return value.replace("\\", "\\\\").replace("'", "\\'")


def clickable(field: str, display: str, raw_value: str | None = None) -> str:
    """Wrap a value in a Textual action link for filter creation."""
    raw = raw_value if raw_value is not None else display
    safe = escape_action_param(raw)
    safe_display = rich_escape(display)
    return f"[@click=filter_clicked('{field}', '{safe}')][underline]{safe_display}[/underline][/]"


def format_signal_fields(row: SignalRow, _add: Callable[..., None]) -> None:
    _add("Frame", row.frame_name, click_field="frame_name")
    _add("Start bit", row.start_bit, click_field="start_bit")
    _add("Length (bits)", row.size, click_field="size")
    _add("Factor", row.factor, click_field="factor")
    _add("Offset", row.offset, click_field="offset")
    _add("Min", row.min, click_field="min")
    _add("Max", row.max, click_field="max")
    for col in COLUMNS:
        if not col.is_bool or col.name not in SIGNAL_BOOL_LABELS:
            continue
        value = getattr(row, col.name, None)
        if value is None:
            continue
        _add(
            SIGNAL_BOOL_LABELS[col.name],
            "Yes" if value else "No",
            click_field=col.name,
            raw_value="1" if value else "0",
        )


_STATE_COLOR: dict[LivenessState, str] = {
    LivenessState.UNKNOWN: "dim",
    LivenessState.LIVE: "green",
    LivenessState.QUIET: "yellow",
    LivenessState.STALE: "red",
}


def format_namespaces_summary(
    states: dict[str, LivenessState],
    snapshots: dict[str, NamespaceSnapshot | None] | None = None,
) -> str:
    """One-line-per-namespace overview rendered when the tree root is selected.

    Header carries the totals by state; each namespace row condenses
    status sigil, clickable name, ``last seen``, and peak onto a single
    line so large topologies (10+ namespaces) fit on screen without
    scrolling. The per-namespace sparkline is reserved for the
    drilled-in single-namespace view.
    """
    if not states:
        return "[bold]Namespaces[/bold]\n\n[dim italic]no namespaces yet[/dim italic]"
    counts: dict[LivenessState, int] = {state: 0 for state in LivenessState}
    for s in states.values():
        counts[s] = counts.get(s, 0) + 1
    # UNKNOWN is transient, so its chip only appears when at least one
    # namespace is still in that state.
    summary_chips = "   ".join(
        f"[bold {_STATE_COLOR[state]}]●[/] {counts[state]} [dim]{state.value}[/]"
        for state in (LivenessState.LIVE, LivenessState.QUIET, LivenessState.STALE, LivenessState.UNKNOWN)
        if state is not LivenessState.UNKNOWN or counts[state]
    )
    lines = [
        f"[bold]Namespaces[/bold]  [dim]({len(states)})[/dim]   {summary_chips}",
        "",
    ]
    name_width = max(len(ns) for ns in states) + 2
    for ns in sorted(states):
        lines.append(_format_namespace_row(ns, states[ns], (snapshots or {}).get(ns), name_width=name_width))
    return "\n".join(lines)


def _format_namespace_row(
    ns: str,
    state: LivenessState,
    snapshot: NamespaceSnapshot | None,
    *,
    name_width: int,
) -> str:
    """One row of `format_namespaces_summary`: sigil + clickable name +
    activity column.

    Padding is computed from the bare ``ns`` length because the
    clickable wrapper carries Rich markup that wouldn't count toward
    visual width if we went through ``f"{...:<width}"``.
    """
    color = _STATE_COLOR.get(state, "yellow")
    name_link = clickable("namespace", ns)
    name_pad = " " * max(0, name_width - len(ns))
    sigil = f"[bold {color}]●[/bold {color}]"
    activity = _format_activity_column(snapshot)
    return f"  {sigil} [cyan]{name_link}[/cyan]{name_pad}{activity}"


def _peak_fps(snapshot: NamespaceSnapshot) -> int:
    """Peak frames-per-second observed across the snapshot's history.

    ``history`` carries per-window frame counts; convert to a rate so
    the displayed number is intuitive ("frames per second") regardless
    of the broker's window size.
    """
    if not snapshot.history:
        return 0
    return round(max(snapshot.history) / DISTRIBUTION_WINDOW_SECS)


def _format_activity_column(snapshot: NamespaceSnapshot | None) -> str:
    """Render the right-hand activity column for a summary row.

    Missing snapshot (no emission yet) shows a placeholder rather than
    an empty space so the row still aligns with its peers.
    """
    if snapshot is None:
        return f"[dim]{'never':<10}[/dim]  [dim]peak {'—':>4}  [/dim]"
    last_seen = _relative_time(snapshot.last_seen_at) if snapshot.last_seen_at else "never"
    return f"[dim]{last_seen:<10}[/dim]  [dim]peak {_peak_fps(snapshot):>4}/s[/dim]"


def format_namespace_detail(
    ns: str,
    snapshot: NamespaceSnapshot | None,
    *,
    state: LivenessState = LivenessState.UNKNOWN,
) -> str:
    """Render the namespace detail view: name, live/quiet/stale
    status, an activity sparkline of the last N broker emission
    windows, and a relative ``X ago`` for the most recent traffic."""
    name_link = clickable("namespace", ns)
    lines: list[str] = [f"[bold]Namespace:[/bold] [cyan]{name_link}[/cyan]", ""]
    color = _STATE_COLOR.get(state, "yellow")
    lines.append(kv_line("Status", f"[bold {color}]●[/bold {color}] {state.value}"))

    if snapshot is None:
        # No emission yet — render the sparkline at full width so the
        # column doesn't grow once data starts flowing.
        lines.append(kv_line("Activity", f"{sparkline((), width=HISTORY_LEN)}  [dim](peak 0/s)[/dim]"))
        lines.append(kv_line("Last seen", "[bold red]never[/bold red]"))
        return "\n".join(lines)

    spark = sparkline(snapshot.history, width=HISTORY_LEN)
    lines.append(kv_line("Activity", f"{spark}  [dim](peak {_peak_fps(snapshot)}/s)[/dim]"))
    if snapshot.last_seen_at:
        lines.append(kv_line("Last seen", _relative_time(snapshot.last_seen_at)))
    else:
        # ``never`` means we've subscribed but no count-bearing
        # emission has landed — that's an anomaly worth flagging in
        # the same red as ``stale`` rather than dim-italic noise.
        lines.append(kv_line("Last seen", "[bold red]never[/bold red]"))
    return "\n".join(lines)


def format_detail(row: Row) -> str:
    """Format a signal or frame row as a Rich markup string with clickable fields."""
    kind = row.type.capitalize()
    name = row.signal_name if isinstance(row, SignalRow) else row.frame_name
    name_field = "signal_name" if isinstance(row, SignalRow) else "frame_name"
    name_link = clickable(name_field, name)
    lines: list[str] = [f"[bold]{kind}:[/bold] [cyan]{name_link}[/cyan]", ""]

    def _add(label: str, value: object, click_field: str | None = None, raw_value: str | None = None) -> None:
        if value is None or value in ("", []):
            return
        display = clickable(click_field, str(value), raw_value) if click_field else str(value)
        lines.append(kv_line(label, display))

    _add("Namespace", row.namespace, click_field="namespace")
    _add("Description", row.description, click_field="description")
    _add("Unit", row.unit, click_field="unit")

    if isinstance(row, SignalRow):
        format_signal_fields(row, _add)
        nv_json = row.named_values_json
    elif isinstance(row, FrameRow):
        _add("Payload size", row.payload_size, click_field="payload_size")
        _add("Cycle time", row.cycle_time, click_field="cycle_time")
        nv_json = None
    else:
        nv_json = None

    _add("Senders", row.senders, click_field="senders")
    _add("Receivers", row.receivers, click_field="receivers")
    format_named_values(nv_json, lines)

    return "\n".join(lines)


class DetailPanel(Static):
    """Displays signal/frame metadata with clickable filter fields.

    Owns its visibility: ``show(row)`` updates content AND toggles the
    parent container's ``visible`` class.  Callers don't reach into the
    container themselves.
    """

    class FilterInclude(Message):
        """Posted on click: immediately add an AND-include filter."""

        def __init__(self, field: str, value: str) -> None:
            super().__init__()
            self.field = field
            self.value = value

    def __init__(self, **kwargs: Any) -> None:
        super().__init__("", markup=True, **kwargs)
        self._row: Row | None = None
        self._namespace: str | None = None
        self._showing_summary: bool = False

    @property
    def current_row(self) -> Row | None:
        return self._row

    @property
    def current_namespace(self) -> str | None:
        return self._namespace

    def show(self, row: Row | None) -> None:
        self._row = row
        self._showing_summary = False
        self._namespace = None
        self.update("" if row is None else format_detail(row))
        self._set_visible(row is not None)

    def show_namespace_activity(
        self,
        ns: str,
        snapshot: NamespaceSnapshot | None,
        *,
        state: LivenessState,
    ) -> None:
        self._row = None
        self._namespace = ns
        self._showing_summary = False
        self.update(format_namespace_detail(ns, snapshot, state=state))
        self._set_visible(True)

    def show_namespaces_summary(
        self,
        states: dict[str, LivenessState],
        snapshots: dict[str, NamespaceSnapshot | None] | None = None,
    ) -> None:
        """Render the all-namespaces aggregate (tree-root highlight).

        When ``snapshots`` is provided, each namespace's detail block
        is stacked below the aggregate so the root view shows the same
        info as the per-namespace view."""
        self._row = None
        self._namespace = None
        self._showing_summary = True
        self.update(format_namespaces_summary(states, snapshots))
        self._set_visible(True)

    @property
    def showing_summary(self) -> bool:
        """``True`` when the panel is currently rendering the all-
        namespaces aggregate; the App's ticker uses this to refresh
        the panel after each state diff."""
        return getattr(self, "_showing_summary", False)

    def _set_visible(self, visible: bool) -> None:
        # The styled padding/border lives on the container, so visibility
        # toggling has to happen there too — the panel itself is just
        # content.
        parent = self.parent
        if parent is not None:
            parent.set_class(visible, "visible")

    def dismiss_if_stale(self, present_keys: set[str]) -> bool:
        """Hide the panel if its currently-displayed row is no longer
        present.  Returns whether a dismissal occurred."""
        if self._row is not None and self._row.key not in present_keys:
            self.show(None)
            return True
        return False

    def action_filter_clicked(self, field: str, value: str) -> None:
        self.post_message(self.FilterInclude(field, value))
