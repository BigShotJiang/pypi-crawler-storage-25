"""Helpers shared by the publish / restbus modal screens."""

from __future__ import annotations

import json
from collections.abc import Callable, Iterator
from typing import Any

from textual.widgets import Input, Static, Tree
from textual.widgets.tree import TreeNode

from remotivelabs.cli.topology.tui.formatting import format_named_values, kv_line
from remotivelabs.cli.topology.tui.rows import FrameRow, Row, SignalRow


def extract_signal_hints(
    row: SignalRow,
) -> tuple[tuple[float | None, float | None] | None, float | None, dict[str, Any] | None]:
    """Extract hint data from a signal row."""
    min_max = (row.min, row.max) if row.min is not None or row.max is not None else None
    start_value = row.start_value

    named_values: dict[str, Any] | None = None
    if row.named_values_json:
        try:
            nv = json.loads(row.named_values_json)
            if nv:
                named_values = nv
        except (json.JSONDecodeError, AttributeError):
            pass

    return min_max, start_value, named_values


def named_values_for(row: Row) -> dict[str, Any] | None:
    """Return the signal row's named-value map, or ``None`` for frames / rows without metadata.

    An empty dict (``{}``) means "this signal has metadata and declares no named
    values" — distinct from ``None`` which means "no metadata available." The
    value-token validator treats those differently.
    """
    if not isinstance(row, SignalRow) or not row.named_values_json:
        return None
    try:
        nv = json.loads(row.named_values_json)
    except (json.JSONDecodeError, ValueError):
        return None
    return nv if isinstance(nv, dict) else None


def format_signal_hints(row: SignalRow) -> str:
    """Format signal hint lines (min/max, start, named values) matching the detail-panel style."""
    min_max, start_value, _ = extract_signal_hints(row)
    lines: list[str] = []

    def _add(label: str, value: object) -> None:
        if value is not None and value not in ("", []):
            lines.append(kv_line(label, value))

    if min_max is not None:
        mn, mx = min_max
        _add("Min / Max", f"{mn} / {mx}")
    _add("Start value", start_value)
    format_named_values(row.named_values_json, lines)
    return "\n".join(lines)


# ---------------------------------------------------------------------------
# Row normalisation — dedupe + ensure each signal has a frame anchor
# ---------------------------------------------------------------------------


def ensure_frame_anchors(rows: list[Row]) -> list[Row]:
    """Normalise the modal's input row list"""
    seen_frames: set[tuple[str, str]] = set()
    seen_signals: set[tuple[str, str, str]] = set()
    deduped: list[Row] = []
    for r in rows:
        if isinstance(r, FrameRow):
            key = (r.namespace, r.frame_name)
            if key in seen_frames:
                continue
            seen_frames.add(key)
            deduped.append(r)
        elif isinstance(r, SignalRow):
            sig_key = (r.namespace, r.frame_name, r.signal_name)
            if sig_key in seen_signals:
                continue
            seen_signals.add(sig_key)
            deduped.append(r)
    for r in list(deduped):
        if isinstance(r, SignalRow):
            key = (r.namespace, r.frame_name)
            if key not in seen_frames:
                deduped.append(FrameRow(namespace=r.namespace, frame_name=r.frame_name))
                seen_frames.add(key)
    return deduped


def group_rows(rows: list[Row]) -> dict[str, dict[str, tuple[FrameRow, list[SignalRow]]]]:
    """Bucket rows into ``ns → frame_name → (frame_row, [signal_rows])``."""
    grouped: dict[str, dict[str, tuple[FrameRow, list[SignalRow]]]] = {}
    by_frame: dict[tuple[str, str], FrameRow] = {}
    sigs_by_frame: dict[tuple[str, str], list[SignalRow]] = {}
    for r in rows:
        key = (r.namespace, r.frame_name)
        if isinstance(r, FrameRow):
            by_frame[key] = r
        elif isinstance(r, SignalRow):
            sigs_by_frame.setdefault(key, []).append(r)
    for (ns, fname), frow in by_frame.items():
        sigs = sorted(sigs_by_frame.get((ns, fname), []), key=lambda s: s.signal_name)
        grouped.setdefault(ns, {})[fname] = (frow, sigs)
    return grouped


def iter_descendants(node: TreeNode[Row | None]) -> Iterator[TreeNode[Row | None]]:
    yield node
    for child in node.children:
        yield from iter_descendants(child)


def populate_dialog_tree(
    tree: Tree[Row | None],
    grouped: dict[str, dict[str, tuple[FrameRow, list[SignalRow]]]],
    frame_label: Callable[[FrameRow], str],
    signal_label: Callable[[SignalRow], str],
    tree_nodes: dict[str, TreeNode[Row | None]],
) -> None:
    """Build the namespace → frame → signal hierarchy on ``tree`` from
    ``grouped``. Both modals share this layout; the only difference is
    how each one renders frame / signal labels, so those go in as
    callables. Mutates ``tree_nodes`` so the caller can later look
    nodes up by row key (used for label refreshes and cursor moves).
    """
    for ns in sorted(grouped):
        ns_node = tree.root.add(f"[bold]{ns}[/bold]", data=None, expand=True)
        for fname in sorted(grouped[ns]):
            frame_row, sigs = grouped[ns][fname]
            f_node = ns_node.add(frame_label(frame_row), data=frame_row, expand=True)
            tree_nodes[frame_row.key] = f_node
            for sig in sigs:
                s_node = f_node.add_leaf(signal_label(sig), data=sig)
                tree_nodes[sig.key] = s_node


def refresh_row_label(
    row: Row,
    tree_nodes: dict[str, TreeNode[Row | None]],
    frame_label: Callable[[FrameRow], str],
    signal_label: Callable[[SignalRow], str],
) -> None:
    """Rerender the tree label for ``row``. No-op when the row's node
    isn't in ``tree_nodes`` (defensive — the modal manages the dict)."""
    node = tree_nodes.get(row.key)
    if node is None:
        return
    if isinstance(row, FrameRow):
        node.set_label(frame_label(row))
    elif isinstance(row, SignalRow):
        node.set_label(signal_label(row))


# ---------------------------------------------------------------------------
# Frame payload placeholder
# ---------------------------------------------------------------------------

# Visible cap on the hex template — keep the placeholder readable on
# wide-payload frames (e.g. 64-byte CAN-FD) by collapsing to ``...``
# past this width and putting the real expected size in a trailing
# annotation.
_FRAME_PLACEHOLDER_MAX_BYTES = 8


def frame_payload_placeholder(payload_size: int | None) -> str:
    """Hint string for the frame Input — sized to the frame's payload.

    For known sizes, the spaced and ``0x``-prefixed templates each
    show one ``XX`` per byte (capped at
    `_FRAME_PLACEHOLDER_MAX_BYTES`) so the user can copy-edit
    rather than count nibbles. The exact byte count is appended for
    the truncated case. For unknown sizes the generic example wins.
    """
    if payload_size is None or payload_size <= 0:
        return "DE AD BE EF  /  0xDEADBEEF  /  scalar list"
    visible = min(payload_size, _FRAME_PLACEHOLDER_MAX_BYTES)
    spaced = " ".join("XX" for _ in range(visible))
    contiguous = "X" * (2 * visible)
    ellipsis = "..." if payload_size > visible else ""
    return f"{spaced}{ellipsis}  /  0x{contiguous}{ellipsis}  /  scalar list  ({payload_size} bytes)"


# ---------------------------------------------------------------------------
# Live-input validation glue
# ---------------------------------------------------------------------------

#: Parser shape used by `validate_field`. Receives the trimmed
#: input value; raises ``ValueError`` to mark it invalid.
ValueParser = Callable[[str], Any]


def validate_field(widget: Input, parser: ValueParser, *, skip_when_hidden: bool = False) -> str | None:
    """Run ``parser`` on ``widget.value`` and toggle the ``invalid`` CSS class.

    Returns the parser's error message if parsing failed, otherwise
    ``None``. Empty input is intentionally not flagged — the user is
    presumed mid-edit; submit-time validation is the backstop for
    "this field was supposed to be filled in."
    """
    if skip_when_hidden and not widget.display:
        widget.remove_class("invalid")
        return None
    raw = widget.value.strip()
    if not raw:
        widget.remove_class("invalid")
        return None
    try:
        parser(raw)
    except ValueError as exc:
        widget.add_class("invalid")
        return str(exc)
    widget.remove_class("invalid")
    return None


def set_dialog_error(error_widget: Static, msg: str | None) -> None:
    """Render ``msg`` in the dialog's error slot, or clear it."""
    error_widget.update(f"[red]{msg}[/red]" if msg else "")


# ---------------------------------------------------------------------------
# Cross-row error stepping (Ctrl+E)
# ---------------------------------------------------------------------------


def find_next_error_key(
    rows_in_display_order: list[Row],
    errors: dict[str, str],
    current_key: str | None,
) -> str | None:
    """Find the next row key (in display order) with a validation error.

    Returns ``None`` when ``errors`` is empty. When ``current_key`` is
    itself an error, jumps to the next error after it (wrapping past
    the end). Otherwise returns the first error after ``current_key``,
    wrapping to the first error if none follows.

    Pure — caller does the cursor move. Shared between publish and
    restbus modals so the Ctrl+E semantics stay identical.
    """
    error_keys = [r.key for r in rows_in_display_order if r.key in errors]
    if not error_keys:
        return None
    if current_key in error_keys:
        i = error_keys.index(current_key)
        return error_keys[(i + 1) % len(error_keys)]
    cursor_idx = next((i for i, r in enumerate(rows_in_display_order) if r.key == current_key), -1)
    return next((r.key for r in rows_in_display_order[cursor_idx + 1 :] if r.key in errors), error_keys[0])


# ---------------------------------------------------------------------------
# Frame action cycling (restbus)
# ---------------------------------------------------------------------------

#: Order frames cycle through when the user presses Ctrl+A on a frame
#: row. ``start`` is the default.
FRAME_ACTIONS: tuple[str, ...] = ("start", "stop", "remove")

_ACTION_NEXT: dict[str, str] = {"start": "stop", "stop": "remove", "remove": "start"}

#: Sigil rendered next to the frame name in the modal tree.
ACTION_GLYPH: dict[str, str] = {"start": "▶", "stop": "⏸", "remove": "✗"}

#: Rich color applied to the action chip + glyph.
ACTION_COLOR: dict[str, str] = {"start": "green", "stop": "yellow", "remove": "red"}


def next_frame_action(action: str) -> str:
    """Return the action that follows ``action`` in the start→stop→remove cycle."""
    return _ACTION_NEXT[action]


# ---------------------------------------------------------------------------
# Shared modal layout / CSS
# ---------------------------------------------------------------------------


DIALOG_CSS = """
#dialog {
    width: 95%;
    max-width: 160;
    height: auto;
    max-height: 90%;
    padding: 1 2;
    background: $surface;
    border: thick $primary;
}
#dialog-body { height: auto; }
#dialog-tree { width: 3fr; height: auto; max-height: 24; margin-right: 1; }
#dialog-detail { width: 2fr; height: auto; max-height: 24; padding: 0 1; }
#edit-context { color: $accent; padding-top: 1; }
#edit-input { width: 100%; }
#edit-strip { height: auto; }
#edit-strip Input { width: 1fr; margin-right: 1; }
#edit-strip Input:last-child { margin-right: 0; }
Input.invalid { border: round $error; }
#dialog-error { color: $error; }
.modal-help { color: $text-muted; padding-top: 1; }
"""
