"""Publish modal — enter values for a set of pre-selected signals/frames."""

from __future__ import annotations

from collections.abc import Callable
from typing import Any

from rich.markup import escape as rich_escape
from textual import events
from textual.app import ComposeResult
from textual.binding import Binding
from textual.containers import Horizontal, Vertical
from textual.screen import ModalScreen
from textual.widgets import Input, Static, Tree
from textual.widgets.tree import TreeNode

from remotivelabs.broker.signal import SignalValue
from remotivelabs.cli.topology.tui.bindings import arrow_nav_bindings
from remotivelabs.cli.topology.tui.modals.dialog import (
    DIALOG_CSS,
    ensure_frame_anchors,
    find_next_error_key,
    frame_payload_placeholder,
    group_rows,
    iter_descendants,
    named_values_for,
    populate_dialog_tree,
    refresh_row_label,
    set_dialog_error,
    validate_field,
)
from remotivelabs.cli.topology.tui.modals.parse import SIGNAL_VALUE_PLACEHOLDER, parse_frame_publish, parse_signal_publish
from remotivelabs.cli.topology.tui.rows import FrameRow, Row, SignalRow
from remotivelabs.cli.topology.tui.widgets.detail import format_detail


class PublishValuesModal(ModalScreen[list[tuple[str, str, list[SignalValue]]] | None]):
    """Modal for entering values for a set of pre-selected signals/frames.

    The Tree is focused by default so all of Textual's native tree
    bindings (``↑↓ ←→ space``) work as you'd expect. The moment the
    user types a printable character, focus jumps to the Input below
    and the character is inserted. ``Enter`` advances to the next row
    (saving on the way); ``Ctrl+S`` submits; ``Esc`` returns to the
    Tree from the Input or cancels the modal from the Tree.
    """

    CSS = "PublishValuesModal { align: center middle; }" + DIALOG_CSS

    BINDINGS = [
        # Esc is context-sensitive: from Input → refocus Tree; from Tree → cancel.
        Binding("escape", "cancel", "Cancel", show=False, priority=True),
        # ↑↓ drive the Tree even when the Input has focus, so typing then
        # pressing ↓ saves and moves to the next node without any extra step.
        *arrow_nav_bindings("nav_down", "nav_up", priority=True),
        # Submit is Ctrl+S only — Enter is for next-row navigation.
        Binding("ctrl+s", "submit", "Publish"),
        # Step the cursor through rows that currently fail validation.
        # ``priority=True`` so ``Ctrl+E`` wins regardless of where focus
        # is — Inputs would otherwise swallow the chord.
        Binding("ctrl+e", "goto_next_error", "Next error", priority=True),
    ]

    def __init__(self, rows: list[Row]) -> None:
        super().__init__()
        self._rows = ensure_frame_anchors(rows)
        # row.key -> raw user input
        self._values: dict[str, str] = {}
        # row.key -> last validation error message; populated by live
        # validation and refreshed across all rows on the goto-next-error
        # action so users can step through every offender.
        self._errors: dict[str, str] = {}
        self._tree_nodes: dict[str, TreeNode[Row | None]] = {}
        self._current_row: Row | None = None

    def compose(self) -> ComposeResult:
        with Vertical(id="dialog"):
            yield Static(f"[bold]Publish[/bold] — {len(self._rows)} row(s)")
            with Horizontal(id="dialog-body"):
                yield Tree[Row | None]("Selection", id="dialog-tree")
                yield Static("", id="dialog-detail", markup=True)
            yield Static("[dim](navigate to a row)[/dim]", id="edit-context")
            yield Input(id="edit-input", select_on_focus=False)
            yield Static("", id="dialog-error")
            yield Static(
                "[dim]↑↓ navigate · Space expand/collapse · type to edit · "
                "Enter next row · Ctrl+E next error · Ctrl+S publish · Esc back/cancel[/dim]",
                classes="modal-help",
            )

    def on_mount(self) -> None:
        tree = self.query_one(Tree)
        tree.show_root = False
        tree.guide_depth = 3
        populate_dialog_tree(tree, group_rows(self._rows), self._frame_label, self._signal_label, self._tree_nodes)
        first_editable = next(
            (node for ns_node in tree.root.children for node in iter_descendants(ns_node) if node.data is not None),
            None,
        )
        if first_editable is not None:
            self.call_after_refresh(tree.move_cursor, first_editable)
        tree.focus()

    # ----- label rendering ---------------------------------------------

    def _frame_label(self, row: FrameRow) -> str:
        value = self._values.get(row.key, "").strip()
        suffix = f"  [bold]{rich_escape(value)}[/bold]" if value else "  [dim]…[/dim]"
        return f"[yellow]{rich_escape(row.frame_name)}[/yellow]{suffix}"

    def _signal_label(self, row: SignalRow) -> str:
        value = self._values.get(row.key, "").strip()
        suffix = f"  [bold]{rich_escape(value)}[/bold]" if value else "  [dim]…[/dim]"
        return f"[green]{rich_escape(row.signal_name)}[/green]{suffix}"

    def _refresh_label(self, row: Row) -> None:
        refresh_row_label(row, self._tree_nodes, self._frame_label, self._signal_label)

    # ----- editor sync --------------------------------------------------

    def _save_current(self) -> None:
        if self._current_row is None:
            return
        input_widget = self.query_one("#edit-input", Input)
        self._values[self._current_row.key] = input_widget.value
        self._refresh_label(self._current_row)

    def _switch_to(self, row: Row | None) -> None:
        self._current_row = row
        ctx_widget = self.query_one("#edit-context", Static)
        detail_widget = self.query_one("#dialog-detail", Static)
        input_widget = self.query_one("#edit-input", Input)
        if row is None:
            ctx_widget.update("[dim](navigate to a row)[/dim]")
            detail_widget.update("")
            input_widget.value = ""
            input_widget.placeholder = ""
            input_widget.disabled = True
            input_widget.remove_class("invalid")
            self.query_one("#dialog-error", Static).update("")
            return
        detail_widget.update(format_detail(row))
        ns = rich_escape(row.namespace)
        frame_name = rich_escape(row.frame_name)
        if isinstance(row, FrameRow):
            # When the search index didn't carry frame metadata (only signals
            # were returned for this frame, so a synthetic FrameRow was
            # built), surface that — submit-time size validation is silently
            # skipped and the hex-shape placeholder is generic.
            metadata_hint = "  [dim](frame metadata not in index — size won't be validated)[/dim]" if row.payload_size is None else ""
            ctx_widget.update(f"[bold]{ns}[/bold] · [yellow]{frame_name}[/yellow] · payload{metadata_hint}")
            input_widget.placeholder = frame_payload_placeholder(row.payload_size)
        else:
            assert isinstance(row, SignalRow)
            signal_name = rich_escape(row.signal_name)
            ctx_widget.update(f"[bold]{ns}[/bold] · [yellow]{frame_name}[/yellow] · [green]{signal_name}[/green]")
            input_widget.placeholder = SIGNAL_VALUE_PLACEHOLDER
        input_widget.disabled = False
        input_widget.value = self._values.get(row.key, "")
        input_widget.cursor_position = len(input_widget.value)
        self._validate_input()

    def on_tree_node_highlighted(self, event: Tree.NodeHighlighted[Row | None]) -> None:
        # Save what was being typed for the previous node, then load the
        # new node's value into the editor.
        self._save_current()
        self._switch_to(event.node.data)

    def on_input_changed(self, event: Input.Changed) -> None:
        # Live-update the tree label as the user types and re-validate.
        if self._current_row is None or event.input.id != "edit-input":
            return
        self._values[self._current_row.key] = event.value
        self._refresh_label(self._current_row)
        self._validate_input()

    def on_input_submitted(self, event: Input.Submitted) -> None:
        # Enter advances to the next row, keeping focus on the Input so
        # the user can keep typing.
        del event
        tree = self.query_one(Tree)
        tree.action_cursor_down()
        node = tree.cursor_node
        if node is not None and node.data is not None:
            self._switch_to(node.data)
            input_widget = self.query_one("#edit-input", Input)
            if not input_widget.disabled:
                input_widget.focus()

    # ----- live validation ---------------------------------------------

    def _row_parser(self, row: Row) -> Callable[[str], None]:
        """Build a parser closure for ``row``. Raises ``ValueError`` on
        invalid input so it slots into `validate_field` and the
        submit path uniformly."""
        named_values = named_values_for(row)

        def parse(raw: str) -> None:
            errors: list[str] = []

            def capture(msg: object, severity: str = "information", **_: Any) -> None:
                if severity == "error":
                    errors.append(str(msg))

            if isinstance(row, FrameRow):
                parse_frame_publish(capture, row.namespace, row.frame_name, raw, row.payload_size, named_values)
            elif isinstance(row, SignalRow):
                parse_signal_publish(capture, row.namespace, row.signal_name, raw, named_values)
            if errors:
                raise ValueError(errors[0])

        return parse

    def _validate_input(self) -> bool:
        if self._current_row is None:
            return True
        widget = self.query_one("#edit-input", Input)
        error_widget = self.query_one("#dialog-error", Static)
        err = validate_field(widget, self._row_parser(self._current_row))
        self._record_error(self._current_row.key, err)
        set_dialog_error(error_widget, err)
        return err is None

    def _record_error(self, key: str, err: str | None) -> None:
        """Update the cross-row error registry used by ``Ctrl+E``."""
        if err is None:
            self._errors.pop(key, None)
        else:
            self._errors[key] = err

    def _validate_all(self) -> None:
        """Re-parse every row's stored value into ``self._errors``.

        Live validation only runs against the focused row, so a typo
        on row 12 stays in the registry only as long as we last saw
        it. Before stepping to the next error we walk every row to
        rebuild a complete picture — cheap because the parsers are
        non-allocating for empty input and the row count tops out at
        a few thousand.
        """
        self._errors.clear()
        for row in self._rows:
            value = self._values.get(row.key, "").strip()
            if not value:
                continue
            try:
                self._row_parser(row)(value)
            except ValueError as exc:
                self._errors[row.key] = str(exc)

    def _rows_in_display_order(self) -> list[Row]:
        """Tree-display order — ns → frame → signals — derived from
        the actual mounted tree so it matches what the cursor sees."""
        tree = self.query_one(Tree)
        return [node.data for ns_node in tree.root.children for node in iter_descendants(ns_node) if node.data is not None]

    def action_goto_next_error(self) -> None:
        """Move the tree cursor to the next row with a validation
        error. Wraps to the first error from the top once past the
        last; ``no errors`` notification when nothing's wrong."""
        self._save_current()
        self._validate_all()
        if not self._errors:
            self.notify("No errors", severity="information")
            return
        current_key = self._current_row.key if self._current_row else None
        target_key = find_next_error_key(self._rows_in_display_order(), self._errors, current_key)
        if target_key is None:
            return
        target = self._tree_nodes.get(target_key)
        if target is not None:
            self.query_one(Tree).move_cursor(target)

    # ----- typing on the Tree forwards to the Input --------------------

    def on_key(self, event: events.Key) -> None:
        if self.focused is not self.query_one(Tree):
            return
        # Don't swallow keys the Tree needs (Space toggles the node, Tab
        # would move focus, etc). ``event.character`` for Space is " ",
        # which is printable, so the explicit exclusion is required.
        if event.key in ("space", "tab", "shift+tab"):
            return
        if event.character is None or not event.character.isprintable():
            return
        input_widget = self.query_one("#edit-input", Input)
        if input_widget.disabled:
            return
        input_widget.focus()
        input_widget.insert_text_at_cursor(event.character)
        event.prevent_default()
        event.stop()

    # ----- arrow nav ---------------------------------------------------

    def action_nav_up(self) -> None:
        self.query_one(Tree).action_cursor_up()

    def action_nav_down(self) -> None:
        self.query_one(Tree).action_cursor_down()

    # ----- submit / cancel ---------------------------------------------

    def _parse_row(self, row: Row, capture: Callable[..., None]) -> tuple[str, str, list[SignalValue]] | None:
        value = self._values.get(row.key, "").strip()
        if not value:
            return None
        named_values = named_values_for(row)
        if isinstance(row, FrameRow):
            return parse_frame_publish(capture, row.namespace, row.frame_name, value, row.payload_size, named_values)
        if isinstance(row, SignalRow):
            return parse_signal_publish(capture, row.namespace, row.signal_name, value, named_values)
        return None

    def action_submit(self) -> None:
        # Persist whatever's in the editor right now before reading state.
        self._save_current()
        results: list[tuple[str, str, list[SignalValue]]] = []
        first_error: str | None = None

        def capture(msg: object, severity: str = "information", **_: Any) -> None:
            nonlocal first_error
            if severity == "error" and first_error is None:
                first_error = str(msg)
            elif severity == "warning":
                # Warnings (e.g. hex size mismatch) still surface to the user.
                self.notify(str(msg), severity="warning")

        for row in self._rows:
            parsed = self._parse_row(row, capture)
            if parsed is not None:
                results.append(parsed)
        error_widget = self.query_one("#dialog-error", Static)
        if first_error is not None:
            set_dialog_error(error_widget, first_error)
            return
        if results:
            self.dismiss(results)
        else:
            set_dialog_error(error_widget, "Enter a value for at least one row")

    def action_cancel(self) -> None:
        # Esc from any focused Input returns focus to the Tree without
        # losing data; Esc on the Tree (or anywhere else) cancels.
        if isinstance(self.focused, Input):
            self._save_current()
            self.query_one(Tree).focus()
            return
        self.dismiss(None)
