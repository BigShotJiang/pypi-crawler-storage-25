"""Live signal-subscription panel."""

from __future__ import annotations

import collections
import json
from collections.abc import Callable, Mapping
from dataclasses import dataclass, field
from datetime import datetime
from typing import Any

from rich.style import Style
from rich.text import Text
from textual.binding import Binding
from textual.containers import VerticalScroll
from textual.coordinate import Coordinate
from textual.message import Message
from textual.timer import Timer
from textual.widgets import DataTable
from textual.widgets._data_table import RowKey

from remotivelabs.broker import OnChangeMode
from remotivelabs.broker.signal import SignalValue
from remotivelabs.cli.topology.tui.bindings import jump_nav_bindings, vertical_nav_bindings
from remotivelabs.cli.topology.tui.rows import FrameRow, SignalRow
from remotivelabs.cli.topology.tui.widgets.live.chart import RevealTarget

HISTORY_DEPTH = 20


def format_value(value: SignalValue, named_values: Mapping[str, str] | None = None) -> str:
    if named_values is not None and isinstance(value, (int, float)) and not isinstance(value, bool):
        key = str(int(value)) if isinstance(value, float) and value.is_integer() else str(value)
        if key in named_values:
            return named_values[key]
    if isinstance(value, bool):
        return "true" if value else "false"
    if isinstance(value, int):
        return str(value)
    if isinstance(value, float):
        return f"{value:.5g}"
    return f"{value!r}"


def decode_named_values(nv_json: str | None) -> dict[str, str] | None:
    if not nv_json:
        return None
    try:
        nv = json.loads(nv_json)
    except (json.JSONDecodeError, ValueError):
        return None
    if not isinstance(nv, dict) or not nv:
        return None
    return {str(k): str(v) for k, v in nv.items()}


def _signal_label(row: SignalRow) -> str:
    text = row.signal_name
    if row.start_bit is not None:
        text += f" (bit {row.start_bit})"
    return text


_PAYLOAD_BYTES_PER_LINE = 16

_TIMESTAMP_WIDTH = len("HH:MM:SS")


def _unit_column_width(signal_rows: list[SignalRow]) -> int:
    unit_widths = [len(r.unit or "") for r in signal_rows]
    return max(_TIMESTAMP_WIDTH, *unit_widths) if unit_widths else _TIMESTAMP_WIDTH


def payload_lines(payload: SignalValue) -> list[str]:
    """Wrap a frame payload to lines."""
    if isinstance(payload, bytes):
        if not payload:
            return [""]
        cells = [f"{b:02X}" for b in payload]
        return [" ".join(cells[i : i + _PAYLOAD_BYTES_PER_LINE]) for i in range(0, len(cells), _PAYLOAD_BYTES_PER_LINE)]
    return [f"{payload!r}"]


_TIME_GUTTER_WIDTH = _TIMESTAMP_WIDTH + 2


def with_time_gutter(time_str: str, lines: list[str]) -> list[str]:
    """Prefix the first line with ``time_str  `` and indent the rest."""
    if not lines:
        return [f"{time_str}  "]
    head = f"{time_str}  {lines[0]}"
    pad = " " * _TIME_GUTTER_WIDTH
    return [head, *(pad + line for line in lines[1:])]


_COL_NAME = "name"
_COL_VALUE = "value"
_COL_UNIT = "unit"

_FRAME_HEADER_ROW_KEY = "__frame_header__"


@dataclass
class FrameSlot:
    frame_row: FrameRow | None
    payload: SignalValue | None = None
    payload_ts: int | None = None
    history: collections.deque[tuple[int, SignalValue]] = field(default_factory=lambda: collections.deque(maxlen=HISTORY_DEPTH))
    expanded: bool = False


@dataclass
class SignalSlot:
    signal_row: SignalRow
    history: collections.deque[tuple[int, SignalValue]] = field(default_factory=lambda: collections.deque(maxlen=HISTORY_DEPTH))
    expanded: bool = False
    named_values: dict[str, str] | None = None


_MIN_FLUSH_INTERVAL_SECS = 0.05


class FrameTable(DataTable[Any], can_focus=True):
    skip_in_tab_chain: bool = True

    DEFAULT_CSS = """
    FrameTable {
        height: auto;
        margin-bottom: 1;
        overflow: hidden hidden;
        scrollbar-size: 0 0;
    }
    """

    BINDINGS = [
        *vertical_nav_bindings("vim_cursor_down", "vim_cursor_up"),
        *jump_nav_bindings("first_row", "last_row"),
        Binding("enter", "toggle_current", "Expand/collapse"),
        Binding("ctrl+c,y", "copy_cell", "Copy cell", priority=True),
    ]

    class EscapeUp(Message):
        """Posted when navigation should move focus to the previous table."""

    class EscapeDown(Message):
        """Posted when navigation should move focus to the next table."""

    def __init__(
        self,
        frame_key: str,
        frame_row: FrameRow | None,
        signal_rows: list[SignalRow],
        history_depth_getter: Callable[[], int],
        show_named_values_getter: Callable[[], bool],
        **kwargs: Any,
    ) -> None:
        super().__init__(
            cursor_type="cell",
            show_header=False,
            zebra_stripes=False,
            show_cursor=False,
            **kwargs,
        )
        self._frame_key = frame_key
        self._frame_slot = FrameSlot(frame_row=frame_row)
        ordered = sorted(signal_rows, key=lambda r: r.start_bit if r.start_bit is not None else -1)
        self._signal_slots: dict[str, SignalSlot] = {
            row.key: SignalSlot(
                signal_row=row,
                named_values=decode_named_values(row.named_values_json),
            )
            for row in ordered
        }
        self._signal_row_order: list[str] = list(self._signal_slots.keys())
        self._unit_column_width: int = _unit_column_width(ordered)
        self._history_depth_getter = history_depth_getter
        self._show_named_values_getter = show_named_values_getter
        self._refresh_timer: Timer | None = None
        self._layout_dirty: bool = False

    def on_mount(self) -> None:
        self.add_column("Name", key=_COL_NAME)
        self.add_column("Value", key=_COL_VALUE)
        self.add_column("Unit", key=_COL_UNIT, width=self._unit_column_width)
        self.add_row(
            self._render_frame_title(),
            "",
            "",
            key=_FRAME_HEADER_ROW_KEY,
            height=1,
        )
        for sig_key in self._signal_row_order:
            sig_row = self._signal_slots[sig_key].signal_row
            self.add_row(
                Text(_signal_label(sig_row), style="green"),
                Text("—", style="dim"),
                Text(sig_row.unit or "", style="dim"),
                key=sig_key,
                height=1,
            )

    @property
    def frame_key(self) -> str:
        return self._frame_key

    @property
    def has_signals(self) -> bool:
        return bool(self._signal_row_order)

    @property
    def frame_slot(self) -> FrameSlot:
        return self._frame_slot

    @property
    def signal_slots(self) -> dict[str, SignalSlot]:
        return self._signal_slots

    @property
    def signal_row_order(self) -> list[str]:
        return self._signal_row_order

    def on_frame_update(
        self,
        payload: SignalValue,
        timestamp: int,
        signals: dict[str, SignalValue],
        watched_keys: set[str],
    ) -> set[str]:
        """Capture state and arm a per-table repaint.

        Returns the set of signal keys whose history advanced.
        """
        slot = self._frame_slot
        slot.payload = payload
        slot.payload_ts = timestamp
        slot.history.append((timestamp, payload))
        ns = self._frame_key.split(":", 1)[0]
        updated: set[str] = set()
        for sig_name, sig_value in signals.items():
            sig_k = f"{ns}:{sig_name}"
            if sig_k not in watched_keys:
                continue
            sig_slot = self._signal_slots.get(sig_k)
            if sig_slot is not None:
                sig_slot.history.append((timestamp, sig_value))
            updated.add(sig_k)
        self._schedule_repaint()
        return updated

    def repaint_now(self) -> None:
        """Synchronous repaint of the header and every signal row."""
        self._layout_dirty = False
        self._render_header_cells()
        for sig_key in self._signal_row_order:
            self._render_signal_cell(sig_key)
        if self._layout_dirty:
            self.refresh(layout=True)
            self._layout_dirty = False

    def set_signal_expanded(self, sig_key: str, on: bool) -> None:
        slot = self._signal_slots.get(sig_key)
        if slot is None or slot.expanded == on:
            return
        slot.expanded = on
        depth = self._history_depth_getter()
        new_height = 1 + depth if on else 1
        try:
            self.rows[RowKey(sig_key)].height = new_height
        except KeyError:
            return
        self._render_signal_cell(sig_key)
        self.refresh(layout=True)
        self.check_idle()
        if on:
            row_index = self._row_index_for_signal(sig_key)
            if row_index is not None:
                self.call_after_refresh(self.call_after_refresh, self._scroll_row_into_parent_view, row_index)

    def _row_index_for_signal(self, sig_key: str) -> int | None:
        try:
            return self._signal_row_order.index(sig_key) + 1
        except ValueError:
            return None

    def _scroll_row_into_parent_view(self, row_index: int) -> None:
        parent = self.parent
        if not isinstance(parent, VerticalScroll):
            return
        ordered = self.ordered_rows
        if row_index < 0 or row_index >= len(ordered):
            return
        row_y_in_table = sum(r.height for r in ordered[:row_index])
        if self.show_header:
            row_y_in_table += self.header_height
        row_height = ordered[row_index].height
        table_screen = self.region
        parent_content = parent.scrollable_content_region
        if table_screen.height == 0 or parent_content.height == 0:
            return
        scroll_y = parent.scroll_offset.y
        row_top_in_parent = table_screen.y + row_y_in_table - parent_content.y + scroll_y
        row_bottom_in_parent = row_top_in_parent + row_height
        viewport_top = scroll_y
        viewport_bottom = scroll_y + parent_content.height
        if row_bottom_in_parent > viewport_bottom:
            parent.scroll_to(y=row_bottom_in_parent - parent_content.height, animate=False)
        elif row_top_in_parent < viewport_top:
            parent.scroll_to(y=row_top_in_parent, animate=False)

    def set_frame_expanded(self, on: bool) -> None:
        if self._frame_slot.expanded == on:
            return
        self._frame_slot.expanded = on
        self._render_header_cells()
        self.refresh(layout=True)

    def apply_history_depth(self) -> None:
        """Resize expanded rows to the panel-wide depth, then refresh."""
        depth = self._history_depth_getter()
        for sig_key, slot in self._signal_slots.items():
            if slot.expanded:
                try:
                    self.rows[RowKey(sig_key)].height = 1 + depth
                except KeyError:
                    continue
                self._render_signal_cell(sig_key)
        if self._frame_slot.expanded:
            self._render_header_cells()
        self.refresh(layout=True)

    def refresh_signal_values(self) -> None:
        """Re-render every signal cell."""
        for sig_key in self._signal_row_order:
            self._render_signal_cell(sig_key)
        self.refresh(layout=True)

    def cancel_timer(self) -> None:
        if self._refresh_timer is not None:
            self._refresh_timer.stop()
            self._refresh_timer = None

    def action_vim_cursor_down(self) -> None:
        if self.cursor_coordinate.row >= self.row_count - 1 or self.row_count == 0:
            self.post_message(self.EscapeDown())
            return
        self.cursor_coordinate = Coordinate(self.cursor_coordinate.row + 1, self.cursor_coordinate.column)

    def action_vim_cursor_up(self) -> None:
        if self.cursor_coordinate.row <= 0:
            self.post_message(self.EscapeUp())
            return
        self.cursor_coordinate = Coordinate(self.cursor_coordinate.row - 1, self.cursor_coordinate.column)

    def action_first_row(self) -> None:
        if self.row_count > 0:
            self.cursor_coordinate = Coordinate(0, self.cursor_coordinate.column)

    def action_last_row(self) -> None:
        if self.row_count > 0:
            self.cursor_coordinate = Coordinate(self.row_count - 1, self.cursor_coordinate.column)

    def action_toggle_current(self) -> None:
        if self.row_count == 0:
            return
        coord = self.cursor_coordinate
        if coord.row == 0:
            self.set_frame_expanded(not self._frame_slot.expanded)
            return
        sig_key = self._signal_key_at(coord.row)
        if sig_key is None:
            return
        slot = self._signal_slots.get(sig_key)
        if slot is None:
            return
        self.set_signal_expanded(sig_key, not slot.expanded)

    def action_copy_cell(self) -> None:
        coord = self.cursor_coordinate
        if coord.row < 0 or coord.row >= self.row_count:
            return
        try:
            value = self.get_cell_at(coord)
        except Exception:
            return
        text = value.plain if isinstance(value, Text) else str(value)
        if not text:
            return
        self.app.copy_to_clipboard(text)

    def on_focus(self) -> None:
        self.show_cursor = True

    def on_blur(self) -> None:
        self.show_cursor = False

    def _get_row_style(self, row_index: int, base_style: Style) -> Style:
        if row_index == 0:
            return base_style + Style(bgcolor="grey15")
        return super()._get_row_style(row_index, base_style)

    def _schedule_repaint(self) -> None:
        if self._refresh_timer is not None:
            return
        self._refresh_timer = self.set_timer(self._flush_period(), self._flush)

    def _flush_period(self) -> float:
        cycle_ms = self._frame_slot.frame_row.cycle_time if self._frame_slot.frame_row else None
        if not cycle_ms:
            return _MIN_FLUSH_INTERVAL_SECS
        return max(_MIN_FLUSH_INTERVAL_SECS, cycle_ms / 1000.0)

    def _flush(self) -> None:
        self._refresh_timer = None
        if not self.display:
            return
        self.repaint_now()

    def _render_frame_title(self) -> Text:
        ns, fname = self._frame_key.split(":", 1)
        text = Text()
        text.append(ns, style="bold")
        text.append("  ")
        text.append(fname, style="bold yellow")
        return text

    def _render_header_cells(self) -> None:
        slot = self._frame_slot
        if slot.payload is None or slot.payload_ts is None:
            return
        time_str = datetime.fromtimestamp(slot.payload_ts / 1_000_000).strftime("%H:%M:%S")
        latest_lines = payload_lines(slot.payload)
        if slot.expanded:
            depth = self._history_depth_getter()
            rendered: list[str] = list(with_time_gutter(time_str, latest_lines))
            for h_ts, h_payload in list(slot.history)[-2::-1][:depth]:
                h_time = datetime.fromtimestamp(h_ts / 1_000_000).strftime("%H:%M:%S")
                rendered.extend(with_time_gutter(h_time, payload_lines(h_payload)))
            value_text = Text("\n".join(rendered))
            new_height = len(rendered)
        else:
            value_text = Text("\n".join(latest_lines))
            new_height = len(latest_lines) or 1
        try:
            row = self.rows[RowKey(_FRAME_HEADER_ROW_KEY)]
        except KeyError:
            return
        if row.height != new_height:
            row.height = new_height
            self._layout_dirty = True
        self._safe_update_cell(_FRAME_HEADER_ROW_KEY, _COL_VALUE, value_text, update_width=True)
        self._safe_update_cell(_FRAME_HEADER_ROW_KEY, _COL_UNIT, Text(time_str, style="dim"))

    def _render_signal_cell(self, sig_key: str) -> None:
        slot = self._signal_slots.get(sig_key)
        if slot is None:
            return
        value_text = Text()
        if slot.history:
            sig_row = slot.signal_row
            latest_ts, latest = slot.history[-1]
            nv = slot.named_values if self._show_named_values_getter() else None
            formatted = format_value(latest, nv)
            out_of_range = (
                isinstance(latest, (int, float))
                and not isinstance(latest, bool)
                and sig_row.min is not None
                and sig_row.max is not None
                and (latest < sig_row.min or latest > sig_row.max)
            )
            latest_style = "bold red" if out_of_range else ""
            if slot.expanded:
                depth = self._history_depth_getter()
                latest_time = datetime.fromtimestamp(latest_ts / 1_000_000).strftime("%H:%M:%S")
                value_text.append(f"{latest_time}  ", style="dim")
                value_text.append(formatted, style=latest_style)
                for h_ts, h_val in list(slot.history)[-2::-1][:depth]:
                    h_time = datetime.fromtimestamp(h_ts / 1_000_000).strftime("%H:%M:%S")
                    value_text.append("\n")
                    value_text.append(f"{h_time}  {format_value(h_val, nv)}", style="dim")
            else:
                value_text.append(formatted, style=latest_style)
        self._safe_update_cell(sig_key, _COL_VALUE, value_text, update_width=True)

    def _safe_update_cell(self, row_key: str, col_key: str, value: Any, *, update_width: bool = False) -> None:
        try:
            self.update_cell(row_key, col_key, value, update_width=update_width)
        except Exception:
            return

    def _signal_key_at(self, row_index: int) -> str | None:
        if row_index <= 0:
            return None
        rows = self.ordered_rows
        if row_index >= len(rows):
            return None
        key = rows[row_index].key
        value = getattr(key, "value", None)
        unwrapped = value if value is not None else str(key)
        if unwrapped == _FRAME_HEADER_ROW_KEY:
            return None
        return unwrapped


class SubscriptionView(VerticalScroll, can_focus=False):
    """Live subscription panel — one `FrameTable` per frame."""

    skip_in_tab_chain: bool = True

    DEFAULT_CSS = """
    SubscriptionView {
        height: 1fr;
        width: 1fr;
    }
    """

    BINDINGS = [
        Binding("ctrl+t", "toggle_on_change", "Change-only"),
        Binding("ctrl+n", "toggle_named_values", "Named values"),
        Binding("pagedown", "next_frame", "Next frame", priority=True, show=False),
        Binding("pageup", "prev_frame", "Prev frame", priority=True, show=False),
        *jump_nav_bindings("cursor_first", "cursor_last", first_label="First frame", last_label="Last frame", priority_anchors=False),
    ]

    class Updated(Message):
        """Posted when subscription data arrives with new signal values."""

        def __init__(self, updated_keys: set[str]) -> None:
            super().__init__()
            self.updated_keys = updated_keys

    class CursorEscape(Message):
        """Posted when navigation should escape out to the tab strip."""

    class OnChangeToggled(Message):
        """Posted when the user toggles broker on-change delivery mode."""

        def __init__(self, view: SubscriptionView) -> None:
            super().__init__()
            self.view = view

    def __init__(self, **kwargs: Any) -> None:
        super().__init__(**kwargs)
        self._history_display_depth: int = 5
        self._tables: dict[str, FrameTable] = {}
        self._table_order: list[str] = []
        # ``start`` may be called pre-mount; stage data and build tables on_mount.
        self._pending_signals: dict[str, SignalRow] = {}
        self._pending_frames: dict[str, FrameRow] = {}
        self.on_change_mode: bool | OnChangeMode = False
        self._show_named_values: bool = False

    @property
    def subscribed_signals(self) -> dict[str, SignalRow]:
        out: dict[str, SignalRow] = {}
        for fkey in self._table_order:
            table = self._tables[fkey]
            for k, slot in table.signal_slots.items():
                out[k] = slot.signal_row
        if not out:
            # Pre-mount fallback: tables aren't built yet.
            return dict(self._pending_signals)
        return out

    @property
    def subscribed_frames(self) -> dict[str, FrameRow]:
        out: dict[str, FrameRow] = {}
        for fkey in self._table_order:
            row = self._tables[fkey].frame_slot.frame_row
            if row is not None:
                out[fkey] = row
        if not out:
            return dict(self._pending_frames)
        return out

    @property
    def has_rows(self) -> bool:
        # Each FrameTable contributes a frame-header row, so any mounted table counts;
        # gating on signals would make frames-without-signals unfocusable.
        return bool(self._table_order)

    @property
    def row_count(self) -> int:
        return sum(len(self._tables[fkey].signal_row_order) for fkey in self._table_order)

    def panel(self, frame_key: str) -> FrameTable | None:
        return self._tables.get(frame_key)

    @property
    def _signal_slots(self) -> dict[str, SignalSlot]:
        return {k: slot for fkey in self._table_order for k, slot in self._tables[fkey].signal_slots.items()}

    @property
    def _frame_slots(self) -> dict[str, FrameSlot]:
        return {fkey: self._tables[fkey].frame_slot for fkey in self._table_order}

    @property
    def _signal_row_order(self) -> list[str]:
        return [k for fkey in self._table_order for k in self._tables[fkey].signal_row_order]

    @property
    def _panels(self) -> dict[str, FrameTable]:
        # Compat alias — older tests reach for ``_panels``; the rename
        # to ``_tables`` reflects that the panel and the table merged.
        return self._tables

    def start(
        self,
        signals: dict[str, SignalRow],
        frames: dict[str, FrameRow] | None = None,
    ) -> None:
        """Replace the subscription set.

        Pre-mount, stages the requested data; post-mount, rebuilds
        tables immediately.  Splitting state-set from UI-mount lets a
        streaming worker read ``subscribed_signals`` /
        ``subscribed_frames`` before the widget is attached to the
        DOM.
        """
        self._pending_signals = dict(signals)
        self._pending_frames = dict(frames) if frames else {}
        if self.is_mounted:
            self._build_tables()

    def on_mount(self) -> None:
        if self._pending_signals or self._pending_frames:
            self._build_tables()

    def reset(self) -> None:
        """Clear all subscription state and hide."""
        for table in self._tables.values():
            table.cancel_timer()
        self._pending_signals.clear()
        self._pending_frames.clear()
        self._tear_down_tables()
        self.remove_class("visible")

    def on_frame_update(
        self,
        frame_key: str,
        payload: SignalValue,
        timestamp: int,
        signals: dict[str, SignalValue],
        watched_keys: set[str],
    ) -> None:
        """Route a transmission to the matching table."""
        table = self._tables.get(frame_key)
        if table is None:
            return
        updated = table.on_frame_update(payload, timestamp, signals, watched_keys)
        if updated:
            self.post_message(self.Updated(updated))

    def adjust_history_depth(self, delta: int) -> None:
        new_depth = self._history_display_depth + delta
        if new_depth > HISTORY_DEPTH:
            self.notify(f"Max history depth: {HISTORY_DEPTH}", severity="information")
            return
        self._history_display_depth = max(1, new_depth)
        for table in self._tables.values():
            table.apply_history_depth()

    def action_expand_all(self) -> None:
        active = self._active_table()
        for table in self._tables.values():
            for sig_key in table.signal_row_order:
                table.set_signal_expanded(sig_key, True)
            table.set_frame_expanded(True)
        # All tables grew, so the outer scroll's content rearranged
        # under the user's feet — bring the focused table back into
        # view so the cursor doesn't appear to "jump away".  Deferred
        # until layout has settled (the tables' new heights are
        # applied via ``refresh(layout=True)`` calls that haven't
        # flushed yet at this point).
        if active is not None:
            self.call_after_refresh(self.scroll_to_widget, active, animate=False)

    def action_collapse_all(self) -> None:
        active = self._active_table()
        for table in self._tables.values():
            for sig_key in table.signal_row_order:
                table.set_signal_expanded(sig_key, False)
            table.set_frame_expanded(False)
        if active is not None:
            self.call_after_refresh(self.scroll_to_widget, active, animate=False)

    def action_cursor_first(self) -> None:
        if self._table_order:
            self._focus_table(self._tables[self._table_order[0]], at_first=True)

    def action_cursor_last(self) -> None:
        if self._table_order:
            self._focus_table(self._tables[self._table_order[-1]], at_first=False)

    def action_next_frame(self) -> None:
        active = self._active_table_index()
        if active is None or active >= len(self._table_order) - 1:
            return
        self._focus_table(self._tables[self._table_order[active + 1]], at_first=True)

    def action_prev_frame(self) -> None:
        active = self._active_table_index()
        if active is None or active <= 0:
            return
        # Land on the previous frame's *header* (row 0), symmetric
        # with PgDown landing on the next frame's header.  Parking at
        # the previous table's last row was confusing — users press
        # PgUp expecting to jump *to* the new section's top, not into
        # its tail.
        self._focus_table(self._tables[self._table_order[active - 1]], at_first=True)

    def action_toggle_on_change(self) -> None:
        self.on_change_mode = OnChangeMode.MERGED if self.on_change_mode is False else False
        self.post_message(self.OnChangeToggled(self))

    def action_toggle_named_values(self) -> None:
        self._show_named_values = not self._show_named_values
        for table in self._tables.values():
            table.refresh_signal_values()

    def focus(self, scroll_visible: bool = True) -> "SubscriptionView":
        """Forward focus to the first table.

        Overrides ``Widget.focus`` so that callers like
        ``LiveTabs.action_focus_signals`` can still route here without
        knowing about the per-frame split.
        """
        if self._table_order:
            self._focus_table(self._tables[self._table_order[0]], at_first=True, scroll=scroll_visible)
            return self
        return super().focus(scroll_visible)

    # ----- compatibility helpers used by tests ---------------------------

    def _set_signal_expanded(self, sig_key: str, on: bool) -> None:
        for table in self._tables.values():
            if sig_key in table.signal_slots:
                table.set_signal_expanded(sig_key, on)
                return

    def _set_frame_expanded(self, frame_key: str, on: bool) -> None:
        table = self._tables.get(frame_key)
        if table is not None:
            table.set_frame_expanded(on)

    def _cursor_signal_key(self) -> str | None:
        """Return the signal key under the focused table's cursor, or
        ``None`` if no table is focused, the cursor is on the
        frame-header row, or no row is selected."""
        active = self._active_table()
        if active is None or active.row_count == 0:
            return None
        return active._signal_key_at(active.cursor_coordinate.row)

    def tree_target(self) -> RevealTarget | None:
        """Coordinates of the focused row in the signal tree.

        Frame-header row → ``RevealTarget(ns, frame_name)``; signal row
        → ``RevealTarget(ns, frame_name, signal_name)``. ``None`` when
        no table is focused (e.g. the tab strip has focus instead).
        """
        active = self._active_table()
        if active is None:
            return None
        ns, frame_name = active.frame_key.split(":", 1)
        sig_key = active._signal_key_at(active.cursor_coordinate.row)
        if sig_key is None:
            return RevealTarget(namespace=ns, frame_name=frame_name)
        # ``SignalRow.key`` is ``f"{namespace}:{signal_name}"``.
        _, signal_name = sig_key.split(":", 1)
        return RevealTarget(namespace=ns, frame_name=frame_name, signal_name=signal_name)

    @property
    def show_cursor(self) -> bool:
        active = self._active_table()
        return bool(active and active.show_cursor)

    @property
    def cursor_coordinate(self) -> Coordinate:
        active = self._active_table()
        return active.cursor_coordinate if active else Coordinate(0, 0)

    # ----- table lifecycle -----------------------------------------------

    def _build_tables(self) -> None:
        """Rebuild tables from staged ``_pending_*`` data."""
        self._tear_down_tables()
        groups: dict[str, list[SignalRow]] = {}
        for row in self._pending_signals.values():
            fkey = f"{row.namespace}:{row.frame_name}"
            groups.setdefault(fkey, []).append(row)
        all_keys = set(groups) | set(self._pending_frames)
        for fkey in sorted(all_keys):
            table = FrameTable(
                frame_key=fkey,
                frame_row=self._pending_frames.get(fkey),
                signal_rows=groups.get(fkey, []),
                history_depth_getter=lambda: self._history_display_depth,
                show_named_values_getter=lambda: self._show_named_values,
            )
            self._tables[fkey] = table
            self._table_order.append(fkey)
            self.mount(table)
        self.add_class("visible")

    def _tear_down_tables(self) -> None:
        for table in self._tables.values():
            table.cancel_timer()
            table.remove()
        self._tables.clear()
        self._table_order.clear()

    # ----- focus + cross-table cursor flow -------------------------------

    def _active_table(self) -> FrameTable | None:
        """The table currently focused, or ``None``."""
        for fkey in self._table_order:
            if self._tables[fkey].has_focus:
                return self._tables[fkey]
        return None

    def _active_table_index(self) -> int | None:
        for i, fkey in enumerate(self._table_order):
            if self._tables[fkey].has_focus:
                return i
        return None

    def _focus_table(self, table: FrameTable, *, at_first: bool, scroll: bool = True) -> None:
        """Focus a table and park its cursor at top or bottom."""
        if table.row_count == 0:
            table.focus(scroll_visible=scroll)
            return
        row = 0 if at_first else table.row_count - 1
        col = table.cursor_coordinate.column
        table.cursor_coordinate = Coordinate(row, col)
        table.focus(scroll_visible=scroll)

    def on_frame_table_escape_up(self, event: FrameTable.EscapeUp) -> None:
        """``k``/``↑`` at row 0 of a table — move to the previous
        table, or `CursorEscape` out to the tab strip."""
        event.stop()
        owner = self._active_table()
        if owner is None:
            return
        idx = self._table_order.index(owner.frame_key)
        if idx == 0:
            self.post_message(self.CursorEscape())
            return
        self._focus_table(self._tables[self._table_order[idx - 1]], at_first=False)

    def on_frame_table_escape_down(self, event: FrameTable.EscapeDown) -> None:
        """``j``/``↓`` at the last row of a table — move to the next
        table."""
        event.stop()
        owner = self._active_table()
        if owner is None:
            return
        idx = self._table_order.index(owner.frame_key)
        if idx >= len(self._table_order) - 1:
            return  # already on the last table
        self._focus_table(self._tables[self._table_order[idx + 1]], at_first=True)
