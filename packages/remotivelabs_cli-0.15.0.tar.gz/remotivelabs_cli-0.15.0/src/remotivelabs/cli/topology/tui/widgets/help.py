"""Help panel: scrollable markdown viewer + its left-edge resize handle.

Owns the search-syntax markdown content (generated from `COLUMNS` at
import so the field tables stay in sync with the index) and the
keybinding cheat-sheet.
"""

from __future__ import annotations

from collections.abc import Callable
from typing import Any

from textual.binding import Binding
from textual.containers import VerticalScroll
from textual.widget import Widget

from remotivelabs.cli.search.columns import COLUMNS, Column
from remotivelabs.cli.topology.tui.bindings import jump_nav_bindings, vertical_nav_bindings
from remotivelabs.cli.topology.tui.widgets.resize_handle import ResizeHandle

HIDDEN_COLUMNS = {"file_path", "type", "channel", "is_signed", "is_big_endian", "is_ieee_floating_type", "is_raw"}


def field_list(cols: list[Column], label: str) -> str:
    return "\n".join(f"- [{c.name}](field:{c.name}) *{label}*" for c in cols)


def build_search_help() -> str:
    """Generate search help markdown from field definitions."""
    fts = [c for c in COLUMNS if c.searchable and c.in_fts and c.name not in HIDDEN_COLUMNS]
    raw_text = [c for c in COLUMNS if c.searchable and not c.in_fts and not c.is_numeric and c.name not in HIDDEN_COLUMNS]
    raw_numeric = [c for c in COLUMNS if c.searchable and not c.in_fts and c.is_numeric and c.name not in HIDDEN_COLUMNS]

    other_section = (
        f"""\
## Other Fields
{field_list(raw_text, "text")}

Supports: `field:value`, `-field:exclude`

"""
        if raw_text
        else ""
    )

    return f"""\
# Search Syntax

Click a field name to insert it into the search input.

## Text Fields
{field_list(fts, "text")}

Supports: `field:value`, `"exact phrase"`, `field:prefix*`, `field:/regex/`, `-field:exclude`

- `field:value` - prefix-tokenized match (typeahead, e.g. `unit:rp` matches `rpm`)
- `field:"phrase"` - phrase match. For free-text fields (`description`) it
  matches rows whose value *contains* the phrase. For values with separator
  characters (`unit:"L/100km"`, `unit:"%"`) it falls back to exact match
  because FTS5's tokenizer drops or splits those values.

## Numeric Fields
{field_list(raw_numeric, "number")}

Supports: `field:>5`, `field:>=5`, `field:<10`, `field:<="-10"`, `field:[1 TO 10]`, `field:{{1 TO 10}}`

{other_section}## Operators

- `a b` - AND (implicit)
- `a AND b` / `a OR b` - explicit
- `-term` / `NOT term` - exclude
- `(a OR b) c` - grouping
- `/pattern/` - regex (see below)

## Regex

Wrap the pattern in slashes: `/pattern/`. Patterns are Python `re` syntax,
**case-insensitive**, and matched as a substring (use `^` / `$` to anchor).

- `.` - any char · `*` `+` `?` - quantifiers
- `[abc]` `[a-z]` `[^xyz]` - character classes
- `\\d` `\\w` `\\s` - digit / word / whitespace
- `^foo` / `bar$` - start / end anchors
- `(a|b)` - alternation
- `\\.` - escape literal dot (and other metas)
- `\\/` - escape a literal slash inside the pattern

Field-scoped: `signal_name:/^Eng.*RPM$/`. Combine with operators: `/temp/ -min:0`.

## Keyboard

### Global
- `F1` toggle help · `Ctrl+Q` quit · `Ctrl+B` sidebar · `Ctrl+R` re-index
- `/` focus search · `Esc` clear suggestions / focus tree · `Ctrl+L` clear filter

### Search input
- `Tab` / `↓` open suggestions · `Enter` accept

### Signal tree
- `j` / `k` (or `↑` / `↓`) move cursor · `g` / `G` (or `Home` / `End`) top / bottom
- `e` / `c` expand / collapse all
- `m` mark · `M` clear marks
- `s` subscribe (chart for a signal, multi-signal view for a frame or marks)
- `p` publish *selection* (marks if any, otherwise highlighted row) · `P` publish *visible tree* (everything currently shown)
- `r` restbus *selection* · `R` restbus *visible tree*
- `f` filter to cursor row (namespace / frame / signal — same as clicking the field in the detail panel)
- `Ctrl+C` copy name · `Ctrl+Y` copy detail

### Live tabs
- `h` / `l` (or `←` / `→`) prev / next tab · `Ctrl+W` close active tab
- `+` / `-` more / less history · `e` / `c` expand / collapse all
- `Ctrl+T` change-only · `Ctrl+N` named values
- `t` open the cursor row in the signal tree (chart's signal, or the focused subscription row)
- `PgUp` / `PgDn` prev / next frame · `Enter` expand row · `Ctrl+C` / `y` copy cell

### Publish / restbus modal
- `↑` / `↓` move row · `Tab` next field · `Enter` next row (saves) · `Ctrl+S` submit
- `Ctrl+E` jump to next validation error
- `Ctrl+A` (restbus) cycle frame action: start → stop → remove
- `Esc` from input → tree, from tree → cancel

## Examples

- `engine` - match anywhere across text fields
- `signal_name:RPM` - field-scoped prefix match
- `unit:L/100km` - bare value with separator → exact match
- `unit:"L/100km"` - same as above (quoting also forces exact)
- `unit:%` - separator-only value → exact match
- `"exact phrase"` - quoted phrase across all text fields
- `signal_name:Eng*` - prefix wildcard (equivalent to `signal_name:Eng`)
- `description:/temp.*coolant/` - regex
- `signal_name:/^Eng.*RPM$/` - anchored regex
- `min:>5 max:<=100` - numeric ranges
- `size:[8 TO 32]` - inclusive range
- `(rpm OR speed) -unit:rpm` - grouped + exclude
- `namespace:PowertrainCAN AND senders:ECU`
"""


SEARCH_HELP_MD = build_search_help()


class HelpScroll(VerticalScroll, can_focus=True):
    """Scrollable container for the help markdown.

    Focusable so users can scroll with vim-style keys (``j``/``k``,
    ``g``/``G``, ``Ctrl+D``/``Ctrl+U``, ``Space``, ``Esc`` to close).
    The Tab focus filter in `SignalsExplorer` skips it while the
    panel is hidden — Textual naturally drops widgets with
    ``display: none`` from the focus chain.
    """

    BINDINGS = [
        # Line + jump scrolling (vim + arrows + Home/End).
        *vertical_nav_bindings("scroll_down", "scroll_up"),
        *jump_nav_bindings("scroll_home", "scroll_end"),
        # Half-page (vim).
        Binding("ctrl+d", "scroll_half_page_down", "Half page down", show=False),
        Binding("ctrl+u", "scroll_half_page_up", "Half page up", show=False),
        # Full page (vim + page keys + space). Textual's ``page_*`` actions
        # are separate from the line-scroll ``scroll_*`` ones above.
        Binding("ctrl+f,pagedown,space", "page_down", "Page down"),
        Binding("ctrl+b,pageup", "page_up", "Page up"),
        # Close the help panel from inside it.
        Binding("escape", "app.toggle_search_help", "Close", show=False),
        Binding("q", "app.toggle_search_help", "Close", show=False),
    ]

    DEFAULT_CSS = """
    HelpScroll:focus {
        /* Subtle: tint the scrollbar via the inherited scrollbar-color-active
         * variable rather than re-tinting the whole content area. Keeps the
         * focus indicator from shifting layout or compositing the background.
         */
        scrollbar-color: $accent;
    }
    """

    def action_scroll_half_page_down(self) -> None:
        self.scroll_relative(y=max(1, self.size.height // 2), animate=False)

    def action_scroll_half_page_up(self) -> None:
        self.scroll_relative(y=-max(1, self.size.height // 2), animate=False)


class HelpResizeHandle(ResizeHandle):
    """Vertical handle on the left edge of the help panel — drag to resize.

    The panel is docked right, so dragging the handle right *shrinks* it
    (``invert_delta=True``).
    """

    DEFAULT_CSS = """
    HelpResizeHandle {
        width: 1;
        height: 1fr;
        background: $accent-darken-2;
    }
    HelpResizeHandle:hover {
        background: $accent;
    }
    """

    MIN_WIDTH = 30
    RIGHT_PADDING = 20

    def __init__(self, get_target: Callable[[], Widget], **kwargs: Any) -> None:
        super().__init__(
            get_target,
            min_width=self.MIN_WIDTH,
            right_padding=self.RIGHT_PADDING,
            invert_delta=True,
            **kwargs,
        )
