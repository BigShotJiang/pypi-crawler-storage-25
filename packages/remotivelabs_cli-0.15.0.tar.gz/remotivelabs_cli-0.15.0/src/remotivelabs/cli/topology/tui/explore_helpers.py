"""Pure helpers extracted from `SignalsExplorer`.

Holds the App-adjacent pure functions and small data types that don't
need to live on the App body — search-suggestion plumbing, subscribe
target resolution, the debounce coalescer, tree-data grouping, and the
parse-error formatter. No Textual screen state, no broker, no widgets;
testable in isolation.
"""

from __future__ import annotations

import re
from collections.abc import Callable
from dataclasses import dataclass, field
from typing import Protocol, runtime_checkable

from rich.markup import escape as rich_escape
from rich.text import Text
from textual.timer import Timer

from remotivelabs.cli.search.query import ALL_FILTER_FIELDS, Query
from remotivelabs.cli.search.types import Term
from remotivelabs.cli.topology.tui.marks import MarkRegistry
from remotivelabs.cli.topology.tui.rows import FrameRow, Row, SignalRow
from remotivelabs.cli.topology.tui.widgets import FieldSuggestion, SuggestionItem, ValueSuggestion

POSITION_RE = re.compile(r"at position (\d+)")


@runtime_checkable
class FocusSkippable(Protocol):
    """Widgets that opt out of the global Tab focus chain."""

    skip_in_tab_chain: bool


# Field types the user reaches for first when filtering signals.
# Drives both the field-name picker order in `field_name_suggestions`
# and the ``field_priority`` argument passed to ``SQLiteSearch.suggest``
# so the dropdown's value-suggest rows group by these fields too.
SUGGEST_FIELD_PRIORITY: tuple[str, ...] = ("namespace", "frame_name", "signal_name")


def _field_priority_sort_key(name: str) -> tuple[int, str]:
    """Sort key honouring `SUGGEST_FIELD_PRIORITY`.

    Priority fields sort by their index in the priority tuple;
    everything else sorts after them, alphabetically.
    """
    try:
        return (SUGGEST_FIELD_PRIORITY.index(name), "")
    except ValueError:
        return (len(SUGGEST_FIELD_PRIORITY), name)


def field_name_suggestions(active: Term) -> list[FieldSuggestion]:
    """Field-name prefix matches for the term being typed.

    Empty when the user has already typed ``field:`` (``active.fields``
    set) or the term has no value yet — there's nothing to prefix-match
    against.  Priority fields (``namespace`` / ``frame_name`` /
    ``signal_name``) come first; the rest are alphabetical so the
    dropdown stays stable across keystrokes.
    """
    if active.fields or not active.value:
        return []
    typed = active.value.lower()
    matching = [name for name in ALL_FILTER_FIELDS if name.startswith(typed)]
    matching.sort(key=_field_priority_sort_key)
    return [FieldSuggestion(name=name) for name in matching]


def drop_exact_value_matches(items: list[SuggestionItem], typed: str) -> list[SuggestionItem]:
    """Filter out `ValueSuggestion`s whose value equals the typed text.

    `FieldSuggestion`s pass through unchanged — accepting one rewrites
    the line (appends ``:``), so it carries information even when the
    suggestion text matches what's already typed.
    """
    return [it for it in items if not (isinstance(it, ValueSuggestion) and it.value.lower() == typed)]


def format_parse_error(filter_str: str, exc: Exception) -> Text:
    """Build a one-line status message highlighting the offending character."""
    msg = str(exc).removeprefix("Syntax error in input : ").removesuffix("!").strip()
    text = Text("  Invalid query: ")
    text.append(msg)
    m = POSITION_RE.search(str(exc))
    if not m:
        return text
    pos = int(m.group(1))
    text.append("  >  ")
    if pos >= len(filter_str):
        text.append(filter_str)
        text.append(" ", style="reverse")
        return text
    start = max(0, pos - 20)
    end = min(len(filter_str), pos + 20)
    if start > 0:
        text.append("…")
    text.append(filter_str[start:pos])
    text.append(filter_str[pos], style="reverse")
    text.append(filter_str[pos + 1 : end])
    if end < len(filter_str):
        text.append("…")
    return text


def empty_results_hint(query: Query, filter_str: str) -> str:
    """Build an actionable Rich-markup hint shown in the tree when a query
    returns zero rows. Picks suggestions based on the query's shape so the
    user has concrete next steps rather than a generic dead end.
    """
    suggestions: list[str] = []
    terms = [c for c in query.parsed.root.children if isinstance(c, Term)]
    only_term = terms[0] if len(terms) == 1 else None

    if only_term is not None and only_term.fields and not only_term.is_regex:
        # Single field-scoped term: suggest dropping the field scope to widen.
        if only_term.value:
            suggestions.append(f"Drop the field scope: search for `{only_term.value}` across all text fields")
            if not only_term.is_phrase and " " in only_term.value:
                suggestions.append(f'Quote the value to match it as a phrase: `"{only_term.value}"`')

    if any(t.is_regex for t in terms):
        suggestions.append("Regexes are case-insensitive substrings — anchor with `^` / `$` to narrow")

    if any(t.negated for t in terms):
        suggestions.append("Negated terms hide rows; remove a `-` to broaden the result")

    if not suggestions:
        suggestions.append("Try a shorter or unscoped term, or press F1 for syntax help")

    # ``filter_str`` came from user input — escape any ``[`` so Rich
    # doesn't treat it as markup, and collapse newlines so the head
    # stays one logical line (the tree splits the hint on ``\n`` and
    # parses each line independently — markup that spans lines blows
    # up there).
    safe_filter = rich_escape(" ".join(filter_str.split()))
    head = f"[dim italic]No matches for [/dim italic][italic]{safe_filter}[/italic][dim italic]:[/dim italic]"
    body = "\n".join(f"[dim italic]  · {s}[/dim italic]" for s in suggestions)
    return f"{head}\n{body}"


# ---------------------------------------------------------------------------
# Subscribe-action plumbing — pure data + helpers
# ---------------------------------------------------------------------------


@dataclass(frozen=True)
class ChartTarget:
    """Selection resolves to a single-signal chart subscription."""

    row: SignalRow


@dataclass(frozen=True)
class SubscriptionTarget:
    """Selection resolves to a multi-row frame-state subscription."""

    signals: dict[str, SignalRow]
    frames: dict[str, FrameRow]


def resolve_subscribe_target(
    marks: MarkRegistry,
    current_row: Row | None,
    signals_by_frame: dict[str, list[SignalRow]],
) -> ChartTarget | SubscriptionTarget | None:
    """What does the user's selection mean for ``action_subscribe``?

    Marks win — when set, subscribe to the marked rows. Else inspect
    the highlighted row: a frame opens a multi-signal subscription that
    *also* carries the `FrameRow` itself so downstream consumers
    (mock backend, ``SubscriptionView`` header) see the frame's
    ``payload_size`` and ``cycle_time``; a signal opens a chart;
    anything else returns ``None`` so the caller can prompt.
    """
    if not marks.is_empty:
        return SubscriptionTarget(signals=dict(marks.signals), frames=dict(marks.frames))
    if isinstance(current_row, FrameRow):
        frame_signals = {sig.key: sig for sig in signals_by_frame.get(current_row.key, [])}
        return SubscriptionTarget(signals=frame_signals, frames={current_row.key: current_row})
    if isinstance(current_row, SignalRow):
        return ChartTarget(row=current_row)
    return None


@dataclass(frozen=True)
class SubscriptionPlan:
    """Pre-computed routing tables for a frame-state subscription.

    Built once before any broker IO so the seed and stream loops don't
    re-derive groupings per frame. Pure data — no broker, no view.
    """

    by_ns_frame: dict[str, set[str]] = field(default_factory=dict)
    """Namespace → set of frame names the user is watching."""
    signals_by_frame: dict[tuple[str, str], list[str]] = field(default_factory=dict)
    """(namespace, frame_name) → owned signal names, so seed values
    route to the correct frame instead of being broadcast across the
    namespace."""
    watched_keys: set[str] = field(default_factory=set)
    """Signal keys (``ns:name``) the view actually displays."""

    @property
    def subscribe_args(self) -> list[tuple[str, list[str]]]:
        """Args for ``BrokerClient.subscribe_frames(*plan.subscribe_args, ...)``."""
        return [(ns, list(fnames)) for ns, fnames in self.by_ns_frame.items()]


def build_subscription_plan(
    signals: dict[str, SignalRow],
    frames: dict[str, FrameRow],
) -> SubscriptionPlan:
    """Group signals and frames by namespace for ``subscribe_frames``."""
    by_ns_frame: dict[str, set[str]] = {}
    signals_by_frame: dict[tuple[str, str], list[str]] = {}
    for sig in signals.values():
        by_ns_frame.setdefault(sig.namespace, set()).add(sig.frame_name)
        signals_by_frame.setdefault((sig.namespace, sig.frame_name), []).append(sig.signal_name)
    for frame in frames.values():
        by_ns_frame.setdefault(frame.namespace, set()).add(frame.frame_name)
    return SubscriptionPlan(
        by_ns_frame=by_ns_frame,
        signals_by_frame=signals_by_frame,
        watched_keys=set(signals.keys()),
    )


class DebouncedRowUpdate:
    """Coalesce rapid row-highlight events into one downstream call.

    The tree fires ``NodeHighlighted`` on every j/k keypress; without
    coalescing the App reformats ~20 lines of Rich markup per
    keystroke. `schedule` arms a one-shot timer and replaces any
    in-flight pending row, so only the most recently highlighted row
    commits when the user pauses.

    Owned by the App; ``set_timer`` is `textual.app.App.set_timer`
    and ``commit`` does the actual panel refresh.
    """

    def __init__(
        self,
        set_timer: Callable[[float, Callable[[], None]], Timer],
        commit: Callable[[Row | None], None],
        delay: float = 0.05,
    ) -> None:
        self._set_timer = set_timer
        self._commit = commit
        self._delay = delay
        self._timer: Timer | None = None
        self._pending: Row | None = None

    def schedule(self, row: Row | None) -> None:
        self._pending = row
        if self._timer is not None:
            self._timer.stop()
        self._timer = self._set_timer(self._delay, self._fire)

    def _fire(self) -> None:
        self._timer = None
        self._commit(self._pending)


def build_tree_data(rows: list[Row]) -> dict[str, dict[str, list[SignalRow]]]:
    """Group flat search rows into ``namespace → frame → [signal rows]``."""
    tree: dict[str, dict[str, list[SignalRow]]] = {}
    for row in rows:
        ns = row.namespace or "(unknown)"
        if ns not in tree:
            tree[ns] = {}
        if isinstance(row, FrameRow):
            if row.frame_name not in tree[ns]:
                tree[ns][row.frame_name] = []
        elif isinstance(row, SignalRow):
            frame_name = row.frame_name or "(no frame)"
            if frame_name not in tree[ns]:
                tree[ns][frame_name] = []
            tree[ns][frame_name].append(row)
    return tree


__all__ = [
    "POSITION_RE",
    "SUGGEST_FIELD_PRIORITY",
    "ChartTarget",
    "DebouncedRowUpdate",
    "FocusSkippable",
    "SubscriptionPlan",
    "SubscriptionTarget",
    "build_subscription_plan",
    "build_tree_data",
    "drop_exact_value_matches",
    "empty_results_hint",
    "field_name_suggestions",
    "format_parse_error",
    "resolve_subscribe_target",
]
