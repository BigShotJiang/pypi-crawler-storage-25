"""Shared text-formatting helpers used by both the detail panel and the publish modal."""

from __future__ import annotations

import json

from rich.markup import escape as rich_escape

LABEL_WIDTH = 18
"""Width of the left ``Label`` column in detail rows. Sets the visual
contract shared by `kv_line` and any module that lays out
key-value blocks alongside it (the detail panel, the publish/restbus
modals' signal-hint block)."""


def kv_line(label: str, value: object) -> str:
    """One ``Label  Value`` row with a dim, fixed-width label column.

    The label column is padded to `LABEL_WIDTH` so detail-panel
    rows and modal hint rows line up vertically when stacked or shown
    side by side. ``value`` is interpolated as-is and may carry Rich
    markup of its own.
    """
    return f"[dim]{label:<{LABEL_WIDTH}}[/dim] {value}"


def format_named_values(nv_json: str | None, lines: list[str]) -> None:
    """Append Rich-markup lines for the given named-values JSON, if any."""
    if not nv_json:
        return
    try:
        nv = json.loads(nv_json)
        if nv:
            lines.append("[dim]Named values:[/dim]")
            for k, v in nv.items():
                lines.append(f"  [yellow]{rich_escape(str(k))}[/yellow] = {rich_escape(str(v))}")
    except (json.JSONDecodeError, AttributeError):
        pass
