"""Single-signal time-series chart used as a tab content view."""

from __future__ import annotations

import collections
from dataclasses import dataclass
from datetime import datetime
from typing import Any

from textual.app import ComposeResult
from textual.containers import Vertical
from textual.timer import Timer
from textual_plotext import PlotextPlot


@dataclass(frozen=True)
class RevealTarget:
    """Coordinates of a row to highlight in the signal tree.

    ``frame_name`` is optional: charts only carry ``namespace`` +
    ``signal_name``, so the tree resolves the owning frame from its own
    `signals_by_frame` lookup. Subscription rows always pass both.
    """

    namespace: str
    frame_name: str | None = None
    signal_name: str | None = None


class ChartView(Vertical):
    """Single-signal chart renderer.  Internal tab content of
    `LiveTabs` — no lifecycle or focus management of its own."""

    _WINDOW_SECS = 30
    # Cap chart repaints at 20 Hz. Mirrors ``SubscriptionView``'s pattern —
    # streaming signals can deliver 50–100 Hz, but the ``plotext`` re-render
    # is heavy (clear + replot up to 10 000 points), so on every value would
    # otherwise starve keyboard handling.
    _REFRESH_INTERVAL_SECS = 0.05

    def __init__(self, **kwargs: Any) -> None:
        super().__init__(**kwargs)
        self._values: collections.deque[tuple[int, float]] = collections.deque(maxlen=10_000)
        self._signal_name: str = ""
        self._namespace: str = ""
        # Throttle state. ``_dirty`` is True when a value arrived since the
        # last flush; ``_refresh_timer`` is a one-shot armed only when there
        # is something to flush — no ticking work while idle.
        self._dirty: bool = False
        self._refresh_timer: Timer | None = None

    def compose(self) -> ComposeResult:
        yield PlotextPlot(id="signal-chart")

    def start(self, namespace: str, signal_name: str) -> None:
        """Prepare the chart for a new single-signal subscription.

        Title setup is deferred to ``on_mount`` if not yet mounted (the inner
        ``PlotextPlot`` is queried via ``query_one`` and can't be reached before
        compose runs).
        """
        self._values.clear()
        self._namespace = namespace
        self._signal_name = signal_name
        if self.is_mounted:
            self._init_chart()
        self.add_class("visible")

    def on_mount(self) -> None:
        if self._signal_name:
            self._init_chart()

    def _init_chart(self) -> None:
        chart = self.query_one(PlotextPlot)
        chart.plt.clear_data()
        chart.plt.clear_figure()
        chart.plt.title(f"{self._namespace}:{self._signal_name}")
        chart.plt.xlabel("Waiting for data...")
        chart.refresh()

    def on_signal_value(self, timestamp: int, value: float) -> None:
        """Record a new value and arm a throttled flush.

        State (the values deque) is updated synchronously so no samples are
        dropped; the chart repaint is deferred to ``_flush`` which runs at
        most once per ``_REFRESH_INTERVAL_SECS``.
        """
        self._values.append((timestamp, value))
        if not self.is_mounted:
            return
        self._dirty = True
        self._schedule_flush()

    def _schedule_flush(self) -> None:
        """Arm a one-shot refresh timer if none is in flight."""
        if self._refresh_timer is not None:
            return
        self._refresh_timer = self.set_timer(self._REFRESH_INTERVAL_SECS, self._flush)

    def _flush(self) -> None:
        """Repaint the chart if marked dirty since the last flush."""
        self._refresh_timer = None
        if not self._dirty:
            return
        self._dirty = False
        self._refresh_chart()

    def tree_target(self) -> RevealTarget | None:
        """Coordinates of the charted signal in the signal tree, or
        ``None`` if the chart hasn't been started yet. Charts don't
        carry the owning frame name; the tree resolves it via
        `signals_by_frame`."""
        if not self._signal_name:
            return None
        return RevealTarget(namespace=self._namespace, signal_name=self._signal_name)

    def reset(self) -> None:
        """Clear all state and hide."""
        self._cancel_timer()
        self._dirty = False
        self._values.clear()
        self._signal_name = ""
        self.remove_class("visible")

    def on_unmount(self) -> None:
        """Cancel the throttle timer on unmount.

        ``LiveTabs.close_active_tab`` removes the view without calling
        `reset`, so the timer would otherwise outlive the widget. Mirrors
        the explicit ``cancel_timer`` pattern in `FrameTable`.
        """
        self._cancel_timer()

    def _cancel_timer(self) -> None:
        if self._refresh_timer is not None:
            self._refresh_timer.stop()
            self._refresh_timer = None

    def _refresh_chart(self) -> None:
        chart = self.query_one(PlotextPlot)
        plt = chart.plt
        plt.clear_data()
        plt.clear_figure()
        all_data = list(self._values)
        if not all_data:
            return
        cutoff_us = all_data[-1][0] - self._WINDOW_SECS * 1_000_000
        data = [(ts, v) for ts, v in all_data if ts >= cutoff_us]
        times = [datetime.fromtimestamp(ts / 1_000_000).strftime("%H:%M:%S") for ts, _ in data]
        values = [v for _, v in data]
        # Title shows the latest value plus min/max observed across the
        # full window so users don't need to scan the chart to find spec
        # excursions. Computed over ``values`` (already trimmed to the
        # display window) so the stats reflect what's drawn, not the
        # unbounded history.
        latest = values[-1]
        title = f"{self._signal_name}  ·  latest: {latest:.5g}  ·  min: {min(values):.5g}  ·  max: {max(values):.5g}  ·  n={len(values)}"
        plt.date_form("H:M:S")
        plt.plot(times, values, marker="braille", label=self._signal_name)
        plt.title(title)
        plt.xlabel("time")
        chart.refresh()
