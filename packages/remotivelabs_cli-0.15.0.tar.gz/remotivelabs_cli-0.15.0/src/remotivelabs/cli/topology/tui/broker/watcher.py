"""Per-namespace ``FramesDistribution`` streaming and liveness state."""

from __future__ import annotations

import asyncio
import logging
from collections.abc import AsyncIterator, Awaitable, Callable, Iterable
from typing import cast

from remotivelabs.broker._generated import common_pb2, network_api_pb2
from remotivelabs.broker.client import BrokerClient
from remotivelabs.cli.topology.tui.broker.state import (
    DISTRIBUTION_WINDOW_SECS,
    LivenessState,
    NamespaceActivity,
    NamespaceSnapshot,
)
from remotivelabs.cli.topology.tui.broker.supervisor import is_transport_failure

logger = logging.getLogger(__name__)


def _subscribe_frames_distribution(broker: BrokerClient, ns: str) -> AsyncIterator[network_api_pb2.FramesDistribution]:
    """Open a ``FramesDistribution`` stream for ``ns``.

    ``BrokerClient`` doesn't expose this as a public method yet, so we
    reach for the underlying gRPC stub. Isolated to one helper so the
    protected-attribute access is contained — when the SDK adds a
    public surface we replace this body and the watcher is unchanged.
    """
    config = network_api_pb2.FramesDistributionConfig(namespace=common_pb2.NameSpace(name=ns))
    return cast(
        "AsyncIterator[network_api_pb2.FramesDistribution]",
        broker._network_service.SubscribeToFramesDistribution(config),  # noqa: SLF001
    )


class NamespaceActivityWatcher:
    # Live-detection window for namespaces without a declared cycle
    # time.
    _NON_CYCLIC_LIVE_WINDOW_SECS = 600.0

    # A healthy cyclic frame can be silent for at most one cycle plus
    # one broker window, but scheduling, network delays, and occasional
    # skipped emissions need headroom — we tolerate one fully missed
    # window before flipping to stale.
    _DISTRIBUTION_GRACE_WINDOWS = 2

    def __init__(
        self,
        *,
        get_broker: Callable[[], Awaitable[BrokerClient]],
        on_transport_failure: Callable[[], None],
        notify_error: Callable[[str], None] | None = None,
    ) -> None:
        self._get_broker = get_broker
        self._on_transport_failure = on_transport_failure
        # Non-transport stream failures (e.g. schema mismatch, server
        # error) silently drop the namespace to STALE without ``state``;
        # surface them to the user instead so a stuck namespace is
        # diagnosable. Optional so tests can omit the callback.
        self._notify_error = notify_error or (lambda _msg: None)
        self._activity = NamespaceActivity()
        self._cycle_ms: dict[str, float] = {}
        self._namespaces: list[str] = []
        self._tasks: list[asyncio.Task[None]] = []

    @property
    def activity(self) -> NamespaceActivity:
        """The underlying tracker. Exposed for tests that need to drive
        marks directly without round-tripping through a stream."""
        return self._activity

    @property
    def namespaces(self) -> list[str]:
        """Currently-watched namespaces, in stable sorted order."""
        return list(self._namespaces)

    @property
    def is_running(self) -> bool:
        return bool(self._tasks)

    def start(self, namespaces: Iterable[str], cycle_ms: dict[str, float]) -> None:
        """Spawn one watcher task per namespace."""
        if self._tasks:
            raise RuntimeError("NamespaceActivityWatcher already running — stop() before re-start")
        self._activity.clear()
        watched = sorted(namespaces)
        self._namespaces = watched
        self._cycle_ms = dict(cycle_ms)
        if not watched:
            logger.debug("NamespaceActivityWatcher.start called with empty namespace set")
            return
        for ns in watched:
            task = asyncio.create_task(self._watch(ns), name=f"ns-activity:{ns}")
            self._tasks.append(task)

    async def stop(self) -> None:
        """Cancel every watcher task and await unwinding."""
        if not self._tasks:
            return
        tasks = self._tasks
        self._tasks = []
        for task in tasks:
            task.cancel()
        await asyncio.gather(*tasks, return_exceptions=True)

    def snapshot(self, ns: str) -> NamespaceSnapshot | None:
        """Latest activity snapshot for ``ns`` (counts + sparkline data),
        or ``None`` if no traffic has been recorded yet."""
        return self._activity.snapshot(ns)

    def state(self, ns: str) -> LivenessState:
        """Liveness for a namespace. See `LivenessState`.

        UNKNOWN means no emission has arrived yet — distinct from STALE
        (we got emissions but none carried traffic).
        """
        if self._activity.snapshot(ns) is None:
            return LivenessState.UNKNOWN
        if self._activity.is_active(ns, window_secs=self._window_secs(ns)):
            return LivenessState.LIVE
        if not self._activity.has_traffic(ns):
            return LivenessState.STALE
        return LivenessState.STALE if ns in self._cycle_ms else LivenessState.QUIET

    def _window_secs(self, ns: str) -> float:
        """Per-namespace window for the "live" predicate.

        Cyclic namespaces wait one cycle plus two broker
        ``FramesDistribution`` windows (1 s) — that absorbs one fully
        missed emission and still flags a real stall reasonably
        quickly. Floored at three broker windows so fast cycles get
        the same headroom. Non-cyclic namespaces stay "live" for
        10 minutes after the last transmission.
        """
        cycle_ms = self._cycle_ms.get(ns)
        if cycle_ms is None:
            return self._NON_CYCLIC_LIVE_WINDOW_SECS
        slack = self._DISTRIBUTION_GRACE_WINDOWS * DISTRIBUTION_WINDOW_SECS
        return max(cycle_ms / 1000.0 + slack, (self._DISTRIBUTION_GRACE_WINDOWS + 1) * DISTRIBUTION_WINDOW_SECS)

    async def _watch(self, ns: str) -> None:
        """Stream ``FramesDistribution`` for one namespace and mark on hits."""
        broker = await self._get_broker()
        stream = _subscribe_frames_distribution(broker, ns)
        try:
            async for distribution in stream:
                # Always mark — empty windows feed the sparkline; the
                # tracker handles the ``count == 0`` case by leaving
                # ``last_seen_at`` (the staleness clock) untouched.
                total = sum(c.count for c in distribution.countsByFrameId)
                self._activity.mark(ns, count=total)
        except asyncio.CancelledError:
            raise
        except Exception as exc:
            if is_transport_failure(exc):
                self._on_transport_failure()
            else:
                # Surface to the user — silent exit would leave the
                # namespace stuck on STALE with no breadcrumb.
                logger.debug("Namespace activity stream %s ended", ns, exc_info=True)
                self._notify_error(f"Namespace activity stream {ns} ended: {exc}")


__all__ = ["NamespaceActivityWatcher"]
