"""Broker-side plumbing for the TUI explorer.

Two collaborators live here:

- `BrokerSupervisor` — owns the connection lifecycle (dial,
  reconnect, expose readiness, signal disconnect).
- `NamespaceActivityWatcher` — streams per-namespace
  ``FramesDistribution`` updates and derives a tri-state liveness label
  the App renders into the tree.

Both keep the App free of gRPC plumbing; the App only wires hooks and
forwards state into Textual widgets.
"""

from __future__ import annotations

from remotivelabs.cli.topology.tui.broker.state import (
    HISTORY_LEN,
    LivenessState,
    NamespaceActivity,
    NamespaceSnapshot,
)
from remotivelabs.cli.topology.tui.broker.supervisor import (
    BrokerCallbacks,
    BrokerSupervisor,
    ConnectionState,
    default_connect,
    is_transport_failure,
)
from remotivelabs.cli.topology.tui.broker.watcher import NamespaceActivityWatcher

__all__ = [
    "HISTORY_LEN",
    "BrokerCallbacks",
    "BrokerSupervisor",
    "ConnectionState",
    "LivenessState",
    "NamespaceActivity",
    "NamespaceActivityWatcher",
    "NamespaceSnapshot",
    "default_connect",
    "is_transport_failure",
]
