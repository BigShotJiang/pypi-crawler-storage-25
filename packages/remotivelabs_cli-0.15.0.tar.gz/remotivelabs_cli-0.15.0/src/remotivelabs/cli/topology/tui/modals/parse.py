"""Pure-function input parsing for the publish / restbus modals.

Signal value cells in both modals accept either a hex byte payload
(``0x12 34``) or a comma-separated scalar / named-value list with
numeric range expansion (``1, 2, 3``, ``1-5:2``, ``On, Off``);
`parse_signal_values` routes between the two. Frame-level
inputs differ — restbus has ``cycle_time``, publish has a hex frame
payload — handled by `parse_cycle_time` and
`parse_frame_payload`.
"""

from __future__ import annotations

import math
import re
from collections.abc import Callable, Mapping
from typing import Any

from remotivelabs.broker.signal import SignalValue

# Cap on values per range — keeps ``0-1000/0.0001`` (10M values) from
# spinning the broker into oblivion.
_MAX_RANGE_VALUES = 10000


def parse_scalar(raw: str) -> SignalValue:
    """Infer type of a single value string (int > float > bytes > str)."""
    try:
        return int(raw)
    except ValueError:
        pass
    try:
        return float(raw)
    except ValueError:
        pass
    try:
        return bytes.fromhex(raw)
    except ValueError:
        pass
    return raw


HEX_PAYLOAD_RE = re.compile(r"^(0x)?[0-9A-Fa-f\s]+$")

SIGNAL_VALUE_PLACEHOLDER = "v[,v,...] | hex bytes   v = number | name | start-stop[:step]"


def looks_like_hex_payload(raw: str) -> bool:
    """``True`` for ``0x``-prefixed or space-separated hex pairs.

    Bare hex like ``abcd`` falls through to `parse_scalar`'s
    bytes coercion via the scalar path; only the unambiguous shapes
    short-circuit here.
    """
    s = raw.strip()
    if not s:
        return False
    if s.lower().startswith("0x"):
        return True
    if " " in s and HEX_PAYLOAD_RE.match(s):
        return True
    return False


def looks_like_scalar_list(raw: str) -> bool:
    """``True`` when ``raw`` has a comma, decimal, or leading minus —
    used by the publish frame-row path to override the hex default."""
    s = raw.strip()
    if not s:
        return False
    if "," in s:
        return True
    if "." in s or s.startswith("-"):
        return True
    return False


def _parse_hex_bytes(raw: str) -> bytes:
    """Strict ``bytes.fromhex`` wrapper. Raises ``ValueError`` on
    invalid hex / odd length; callers add row context to the message."""
    hex_str = raw.strip().removeprefix("0x").removeprefix("0X")
    if not hex_str:
        raise ValueError("empty payload")
    # ``bytes.fromhex`` ignores ASCII whitespace between bytes, so the
    # parity check has to count hex digits only — otherwise a valid
    # ``00 00 00 00`` (7 spaces + 8 digits = 15 chars, odd) gets
    # rejected for being the wrong length.
    hex_only = "".join(hex_str.split())
    if len(hex_only) % 2 != 0:
        raise ValueError("odd number of hex characters")
    try:
        return bytes.fromhex(hex_str)
    except ValueError as exc:
        raise ValueError(f"invalid hex string '{raw.strip()}'") from exc


def parse_frame_payload(raw: str, ns: str, name: str, payload_size: int | None) -> tuple[bytes, str | None]:
    """Parse a frame's hex payload. Returns ``(payload, optional_warning)``;
    size mismatches surface as warnings so the caller can decide whether
    to drop the entry. Raises ``ValueError`` on invalid hex.
    """
    try:
        payload = _parse_hex_bytes(raw)
    except ValueError as exc:
        raise ValueError(f"{ns}:{name}: {exc}") from exc
    warning: str | None = None
    if payload_size is not None and len(payload) != payload_size:
        warning = f"{ns}:{name}: expected {payload_size} bytes, got {len(payload)}"
    return payload, warning


def parse_signal_values(
    raw: str,
    named_values: Mapping[str, Any] | None = None,
) -> list[SignalValue]:
    """Parse a signal-value input cell — hex bytes or scalar list.

    Hex (``0x12 34`` / ``DE AD BE EF``) returns ``[bytes]``; everything
    else is a comma-separated scalar list with named-value resolution
    and numeric range expansion (``1-5`` → ``[1..5]``,
    ``1-10:2`` / ``1-10/2`` → stepped, ``0, 1-3, 10`` mixes scalars
    and ranges, ``-1--5`` descends through negatives, ``0-2/0.5``
    floats). Empty / whitespace input yields ``[]``.
    """
    if looks_like_hex_payload(raw):
        return [_parse_hex_bytes(raw)]
    s = raw.strip()
    if not s:
        return []
    out: list[SignalValue] = []
    for raw_tok in s.split(","):
        tok = raw_tok.strip()
        if not tok:
            continue
        if _looks_like_numeric_range(tok):
            out.extend(_parse_range(tok))
        else:
            out.append(_parse_value(tok, named_values))
    return out


def _parse_value(tok: str, named_values: Mapping[str, Any] | None) -> SignalValue:
    """Validated wrapper around `parse_scalar`.

    The metadata's ``named_values`` map is keyed by the *numeric*
    underlying value with the symbolic name as the value (mirroring
    the format the search index emits, e.g. ``{"0": "Off", "1": "On"}``).
    Resolution order:

    1. If a ``named_values`` map is provided and ``tok`` matches one of
       its names, the token is a named-value reference — return it as a
       string before ``parse_scalar`` can coerce e.g. ``abcd`` to bytes.
    2. Otherwise run ``parse_scalar``. Numbers / bytes pass through.
    3. If ``parse_scalar`` falls back to a raw string, the token is
       neither a number nor a known name — reject it. Without metadata
       we have nothing to validate against, so any string is invalid.
    """
    names = list(named_values.values()) if named_values is not None else []
    if tok in names:
        return tok
    result = parse_scalar(tok)
    if isinstance(result, str):
        if not names:
            raise ValueError(f"unknown named value {tok!r} — signal has no named values")
        allowed = ", ".join(sorted(str(n) for n in names))
        raise ValueError(f"unknown named value {tok!r} — expected one of: {allowed}")
    return result


# ---------------------------------------------------------------------------
# Numeric range parsing
# ---------------------------------------------------------------------------


def _looks_like_numeric_range(tok: str) -> bool:
    """A token is a range if it starts numerically and contains a
    range separator (``-`` not as a leading sign / sci-notation
    exponent, or ``:`` / ``/`` for an explicit step)."""
    if not tok:
        return False
    first = tok[0]
    has_numeric_start = first.isdigit() or (first in "-." and len(tok) > 1 and (tok[1].isdigit() or tok[1] == "."))
    if not has_numeric_start:
        return False
    if ":" in tok or "/" in tok:
        return True
    # ``-`` is a separator only when it's not the leading sign and not
    # the exponent-sign of scientific notation.
    for i in range(1, len(tok)):
        if tok[i] == "-" and tok[i - 1] not in "eE":
            return True
    return False


def _split_range_dash(s: str) -> list[str]:
    """Split on ``-`` that isn't a leading sign or sci-notation exponent.

    A ``-`` immediately after a separator (``i == start``) is the
    leading sign of the next part — not another separator — so
    ``-1--5`` splits cleanly into ``['-1', '-5']``.
    """
    parts: list[str] = []
    start = 0
    i = 1
    while i < len(s):
        if s[i] == "-" and s[i - 1] not in "eE" and i != start:
            parts.append(s[start:i])
            start = i + 1
        i += 1
    parts.append(s[start:])
    return parts


def _parse_numeric(raw: str, ctx: str) -> int | float:
    raw = raw.strip()
    if not raw:
        raise ValueError(f"empty number in range {ctx!r}")
    try:
        return int(raw)
    except ValueError:
        pass
    try:
        return float(raw)
    except ValueError:
        pass
    raise ValueError(f"range component must be numeric, got {raw!r} in {ctx!r}")


def _parse_range(tok: str) -> list[int | float]:
    start, step, stop = _parse_range_bounds(tok)
    return _generate_range(start, step, stop, tok)


def _parse_range_bounds(tok: str) -> tuple[int | float, int | float, int | float]:
    # Optional step suffix: ``a-b:s`` or ``a-b/s``. Step always comes
    # after the range, so rsplit picks the step separator without
    # interfering with negative numbers earlier in the token.
    range_part = tok
    step_raw: str | None = None
    for sep in (":", "/"):
        if sep in range_part:
            range_part, step_raw = range_part.rsplit(sep, 1)
            break
    parts = _split_range_dash(range_part)
    if len(parts) != 2:
        raise ValueError(f"range must be 'start-stop' with optional ':step' or '/step', got {tok!r}")
    start = _parse_numeric(parts[0], tok)
    stop = _parse_numeric(parts[1], tok)
    if step_raw is None:
        step: int | float = 1 if stop >= start else -1
    else:
        step = _parse_numeric(step_raw, tok)
    if step == 0:
        raise ValueError(f"range step cannot be zero: {tok!r}")
    if (stop > start and step < 0) or (stop < start and step > 0):
        raise ValueError(f"range step {step} cannot reach {stop} from {start}: {tok!r}")
    return start, step, stop


def _generate_range(start: int | float, step: int | float, stop: int | float, tok: str) -> list[int | float]:
    is_float = any(isinstance(v, float) for v in (start, step, stop))
    eps = abs(step) * 1e-9 if is_float else 0
    values: list[int | float] = []
    n = 0
    while True:
        v = start + n * step
        if step > 0 and v > stop + eps:
            break
        if step < 0 and v < stop - eps:
            break
        values.append(float(v) if is_float else int(v))
        n += 1
        if n > _MAX_RANGE_VALUES:
            raise ValueError(f"range produces more than {_MAX_RANGE_VALUES} values: {tok!r}")
    return values


# ---------------------------------------------------------------------------
# Cycle time (restbus frames)
# ---------------------------------------------------------------------------


def parse_cycle_time(raw: str) -> float | None:
    """Parse an optional cycle-time override in milliseconds.

    Empty input means "use the broker default" (returns ``None``).
    Raises ``ValueError`` for non-numeric input or non-positive values
    so the caller can surface the reason inline.
    """
    s = raw.strip()
    if not s:
        return None
    value = float(s)
    if not math.isfinite(value):
        raise ValueError(f"cycle_time must be finite, got {value}")
    if value <= 0:
        raise ValueError(f"cycle_time must be positive, got {value}")
    return value


# ---------------------------------------------------------------------------
# Publish entry — typed dispatch: frame or signal
# ---------------------------------------------------------------------------


def parse_frame_publish(  # noqa: PLR0913 — positional ns/name/raw + payload knobs read clearer than a config dataclass
    notify: Callable[..., None],
    ns: str,
    name: str,
    raw: str,
    payload_size: int | None,
    named_values: Mapping[str, Any] | None = None,
) -> tuple[str, str, list[SignalValue]] | None:
    """Parse a publish entry for a frame row.

    Hex-shaped input goes through `parse_frame_payload` (size-checked,
    surfaces a warning on mismatch); scalar-list input falls through to
    `parse_signal_values` so a frame can also drive multi-iteration
    publishing. Errors are reported via ``notify`` and yield ``None``.
    """
    if looks_like_hex_payload(raw) or not looks_like_scalar_list(raw):
        try:
            payload, warning = parse_frame_payload(raw, ns, name, payload_size)
        except ValueError as exc:
            notify(f"Publish error: {exc}", severity="error")
            return None
        if warning:
            notify(warning, severity="warning")
        return (ns, name, [payload])
    try:
        values = parse_signal_values(raw, named_values)
    except ValueError as exc:
        notify(f"Publish error: {exc}", severity="error")
        return None
    return (ns, name, values)


def parse_signal_publish(
    notify: Callable[..., None],
    ns: str,
    name: str,
    raw: str,
    named_values: Mapping[str, Any] | None = None,
) -> tuple[str, str, list[SignalValue]] | None:
    """Parse a publish entry for a signal row.

    Always routes through `parse_signal_values` (hex bytes collapse
    to a single-payload list). Errors yield ``None`` via ``notify``.
    """
    try:
        values = parse_signal_values(raw, named_values)
    except ValueError as exc:
        notify(f"Publish error: {exc}", severity="error")
        return None
    return (ns, name, values)


__all__ = [
    "HEX_PAYLOAD_RE",
    "SIGNAL_VALUE_PLACEHOLDER",
    "looks_like_hex_payload",
    "looks_like_scalar_list",
    "parse_cycle_time",
    "parse_frame_payload",
    "parse_frame_publish",
    "parse_signal_publish",
    "parse_signal_values",
]
