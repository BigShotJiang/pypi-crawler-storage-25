"""Modal screens for the TUI explorer.

The publish and restbus modals share the same shape: a Textual ``Tree``
showing the namespace → frame → signal hierarchy of the user's
selection, a side detail panel, and a persistent ``Input`` strip below
that auto-tracks the currently-highlighted node. Typing forwards to
the input; ``Enter`` advances to the next row; ``Ctrl+S`` submits.

The two modals are split across ``publish.py`` and ``restbus.py``;
they share row-normalisation, named-value extraction, the dialog CSS,
and the live-validation glue via `.dialog`, and they share the
input parsers via `.parse`.
"""

from __future__ import annotations

from remotivelabs.cli.topology.tui.modals.dialog import extract_signal_hints, format_signal_hints
from remotivelabs.cli.topology.tui.modals.publish import PublishValuesModal
from remotivelabs.cli.topology.tui.modals.restbus import RestbusModal
from remotivelabs.cli.topology.tui.modals.restbus_plan import RestbusPlan

__all__ = [
    "PublishValuesModal",
    "RestbusModal",
    "RestbusPlan",
    "extract_signal_hints",
    "format_signal_hints",
]
