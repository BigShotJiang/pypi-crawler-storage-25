"""Interactive TUI explorer for topology frames and signals."""

from __future__ import annotations

import asyncio
import logging
import time
from collections.abc import AsyncGenerator, Awaitable
from contextlib import aclosing, suppress
from functools import wraps
from typing import Any, Callable, Protocol, TypeVar, cast

from luqum.exceptions import ParseError
from rich.text import Text
from textual import events
from textual.app import App, ComposeResult
from textual.binding import Binding
from textual.containers import Horizontal, ScrollableContainer, Vertical
from textual.timer import Timer
from textual.widgets import Footer, Header, Markdown, Static, Tree
from textual.widgets.tree import TreeNode

from remotivelabs.broker.client import BrokerClient
from remotivelabs.broker.frame import Frame
from remotivelabs.broker.signal import SignalValue, WriteSignal
from remotivelabs.cli.search.grpc import _fetch_grpc_signals
from remotivelabs.cli.search.query import Query
from remotivelabs.cli.search.sqlite.index import SQLiteSearch
from remotivelabs.cli.search.types import Group, ParsedQuery, SearchOptions
from remotivelabs.cli.topology.tui.broker import (
    BrokerCallbacks,
    BrokerSupervisor,
    ConnectionState,
    LivenessState,
    NamespaceActivityWatcher,
    default_connect,
    is_transport_failure,
)
from remotivelabs.cli.topology.tui.explore_helpers import (
    SUGGEST_FIELD_PRIORITY,
    ChartTarget,
    DebouncedRowUpdate,
    FocusSkippable,
    build_subscription_plan,
    build_tree_data,
    drop_exact_value_matches,
    empty_results_hint,
    field_name_suggestions,
    format_parse_error,
    resolve_subscribe_target,
)
from remotivelabs.cli.topology.tui.modals import PublishValuesModal, RestbusModal, RestbusPlan
from remotivelabs.cli.topology.tui.query_string import analyze, quote_value
from remotivelabs.cli.topology.tui.rows import FrameRow, Row, SignalRow
from remotivelabs.cli.topology.tui.widgets import (
    SEARCH_HELP_MD,
    ChartView,
    DetailPanel,
    HelpResizeHandle,
    HelpScroll,
    LiveTabs,
    SearchInput,
    SearchSuggestions,
    SidebarHandle,
    SignalTree,
    SubscriptionView,
    SuggestionItem,
    SuggestResult,
    ValueSuggestion,
)
from remotivelabs.cli.topology.tui.widgets.detail import format_namespace_detail, format_namespaces_summary

logger = logging.getLogger(__name__)

GRPC_SOURCE = "grpc"
ALL_ROWS_QUERY = Query(ParsedQuery(root=Group(children=()), active_term=None))


class _TreeEvent(Protocol):
    @property
    def control(self) -> Any: ...


E = TypeVar("E", bound=_TreeEvent)


def _signal_tree_event(method: Callable[["SignalsExplorer", E], None]) -> Callable[["SignalsExplorer", E], None]:
    """Drop ``Tree.Node*`` events that didn't come from the main signal_tree.

    Modals mount their own ``Tree`` and bubble ``Node*`` events up to the App;
    without this filter, navigating in a modal would refresh background tree state.
    """

    @wraps(method)
    def wrapper(self: "SignalsExplorer", event: E) -> None:
        if event.control is not self.signal_tree:
            return None
        return method(self, event)

    return wrapper


__all__ = [
    "SignalsExplorer",
]


class SignalsExplorer(App[None]):
    """Interactive TUI explorer for topology frames and signals."""

    COMMANDS = App.COMMANDS
    TITLE = "Topology Signal Explorer"
    CSS = """
    Screen {
        layout: vertical;
        layers: base overlay;
    }

    #search-input {
        dock: top;
        height: 3;
        margin: 0 0;
    }

    #main-area {
        layout: horizontal;
        height: 1fr;
    }

    #signal-tree {
        width: 40%;
        min-width: 20;
    }

    #signal-tree.collapsed {
        display: none;
    }

    #right-pane {
        width: 1fr;
        layout: vertical;
        background: $surface-darken-1;
        padding: 1;
    }

    #detail-container {
        padding: 1 2;
        height: 1fr;
        background: $surface;
        margin-bottom: 1;
        display: none;
    }

    #detail-container.visible {
        display: block;
    }

    #detail-container.with-live {
        height: auto;
        max-height: 50%;
    }

    #detail-panel {
        width: 100%;
    }

    #live-view {
        height: 1fr;
        display: none;
    }

    #live-view.visible {
        display: block;
    }

    #live-view:focus {
        border: tall $primary;
    }

    #chart-view {
        height: 1fr;
        display: none;
    }

    #chart-view.visible {
        display: block;
    }

    #signal-chart {
        height: 1fr;
        background: $surface;
    }

    #subscription-view {
        height: 1fr;
        display: none;
    }

    #subscription-view.visible {
        display: block;
    }

    .frame-window {
        height: auto;
        padding: 1 2;
        background: $surface;
        background-tint: $foreground 5%;
        margin-bottom: 1;
    }

    #status-bar {
        height: 1;
        padding: 0 1;
        color: $text;
        background: $primary-darken-2;
    }
    #status-bar.error {
        background: $error;
    }

    #search-help-panel {
        display: none;
        layer: overlay;
        dock: right;
        width: 50;
        min-width: 30;
        height: 1fr;
        border: tall $accent;
        background: $surface;
        layout: horizontal;
    }
    #search-help-panel.visible {
        display: block;
    }
    #search-help-panel Markdown {
        background: $surface;
    }
    #help-scroll {
        width: 1fr;
        height: 1fr;
        padding: 1 2;
    }
    """

    BINDINGS = [
        Binding("ctrl+q", "quit", "Quit", priority=True),
        Binding("/", "focus_search", "Search"),
        Binding("f1", "toggle_search_help", "Help"),
        Binding("ctrl+b", "toggle_sidebar", "Sidebar"),
        Binding("ctrl+l", "clear_search_input", "Clear filter"),
        Binding("ctrl+r", "reindex", "Re-index"),
        Binding("escape", "clear_search", "Dismiss / focus tree", show=False),
        Binding("tab", "skip_live_focus_next", show=False, priority=True),
        Binding("shift+tab", "skip_live_focus_previous", show=False, priority=True),
    ]
    search_input: SearchInput
    search_suggestions: SearchSuggestions
    signal_tree: SignalTree
    detail_panel: DetailPanel
    detail_container: ScrollableContainer
    live_view: LiveTabs
    status_bar: Static
    sidebar_handle: SidebarHandle
    search_help_panel: Horizontal
    help_scroll: HelpScroll

    def __init__(
        self,
        broker_url: str,
        api_key: str | None,
        index: SQLiteSearch,
        *,
        connect: Callable[[], Awaitable[BrokerClient]] | None = None,
    ) -> None:
        super().__init__()
        self._broker_url = broker_url
        self._api_key = api_key
        self._index = index
        self.sub_title = broker_url
        self._supervisor = BrokerSupervisor(
            connect=connect or default_connect(broker_url, api_key),
            callbacks=BrokerCallbacks(
                on_state_change=self._handle_connection_state,
                on_connected=self._handle_broker_connected,
                on_before_disconnect=self._handle_broker_disconnecting,
                notify_error=lambda msg: self.notify(msg, severity="error"),
            ),
        )
        self._current_node: TreeNode[Row] | None = None
        self._current_row: Row | None = None
        self._detail_update = DebouncedRowUpdate(
            set_timer=self.set_timer,
            commit=lambda row: self.detail_panel.show(row),
        )
        self._last_search_ms: float = 0.0
        self._activity_watcher = NamespaceActivityWatcher(
            get_broker=self._supervisor.get_broker,
            on_transport_failure=self._supervisor.signal_disconnect,
            notify_error=lambda msg: self.notify(msg, severity="error"),
        )
        self._activity_ticker: Timer | None = None
        self._last_state_snapshot: dict[str, LivenessState] = {}
        self._ns_cycle_ms: dict[str, float] = {}
        self._namespace_types: dict[str, str] = {}

    def compose(self) -> ComposeResult:
        self.search_input = SearchInput(
            placeholder="/ Search frames and signals...",
            id="search-input",
            select_on_focus=False,
        )
        self.search_suggestions = SearchSuggestions(
            suggestion_cb=self._build_suggestions,
            id="search-suggestions",
        )
        self.signal_tree = SignalTree("Namespaces", id="signal-tree")
        self.signal_tree.namespace_detail_provider = self._namespace_clipboard_text
        self.signal_tree.root_detail_provider = self._namespaces_summary_clipboard_text
        self.detail_panel = DetailPanel(id="detail-panel")
        self.detail_container = ScrollableContainer(self.detail_panel, id="detail-container", can_focus=False)
        self.live_view = LiveTabs(id="live-view")
        self.status_bar = Static("Indexing signals from broker...", id="status-bar")
        self.sidebar_handle = SidebarHandle(lambda: self.signal_tree, id="sidebar-handle")
        self.help_scroll = HelpScroll(Markdown(SEARCH_HELP_MD, open_links=False), id="help-scroll")
        self.search_help_panel = Horizontal(
            HelpResizeHandle(lambda: self.search_help_panel, id="help-resize-handle"),
            self.help_scroll,
            id="search-help-panel",
        )

        yield Header()
        yield self.search_input
        yield self.search_suggestions
        with Horizontal(id="main-area"):
            yield self.signal_tree
            yield self.sidebar_handle
            with Vertical(id="right-pane"):
                yield self.detail_container
                yield self.live_view
        yield self.status_bar
        yield self.search_help_panel
        yield Footer()

    def on_mount(self) -> None:
        self._supervisor.start()

    def _handle_connection_state(self, state: ConnectionState) -> None:
        if state is ConnectionState.CONNECTED:
            return
        if state is ConnectionState.CONNECTING:
            self._update_status_widget("Connecting to broker...")
        else:
            self._update_status_widget(f"Disconnected from {self._broker_url} — retrying...", error=True)

    def _handle_broker_connected(self, _client: BrokerClient) -> None:
        self._cancel_broker_workers()
        self.live_view.restart_all_workers()
        self.run_worker(self._do_index, exclusive=True, thread=True)

    def _cancel_broker_workers(self) -> None:
        self.workers.cancel_group(self, "publish")
        self.workers.cancel_group(self, "restbus")

    async def _handle_broker_disconnecting(self) -> None:
        await self._stop_namespace_activity_watchers()
        # Drop the diff cache so the first post-reconnect tick re-pushes
        # every namespace label even when the new state matches the cached one.
        self._last_state_snapshot.clear()
        with suppress(Exception):
            self.live_view.cancel_all_workers()
        self._sync_detail_layout()

    def _do_index(self) -> None:
        t0 = time.perf_counter()
        self._set_status("Indexing signals from broker...")
        try:
            signals, namespace_types = _fetch_grpc_signals(self._broker_url, self._api_key)
            count = self._index.index_signals(signals)
            self._namespace_types = namespace_types
            elapsed = time.perf_counter() - t0
            self._set_status(f"Indexed {count} entries from {self._broker_url} in {elapsed:.2f}s")
        except Exception as exc:
            self.call_from_thread(self.notify, f"Index error: {exc}", severity="error")
            return
        self._ns_cycle_ms = self._index.namespace_max_cycle_time_ms()
        self.call_from_thread(self._rebuild_tree, self.signal_tree.current_filter)

    def _set_status(self, message: str | Text, *, error: bool = False) -> None:
        self.call_from_thread(self._update_status_widget, message, error)

    def _update_status_widget(self, message: str | Text, error: bool = False) -> None:
        self.status_bar.update(message, layout=False)
        self.status_bar.set_class(error, "error")

    def _rebuild_tree(self, filter_str: str) -> None:
        self.run_worker(
            lambda: self._do_search(filter_str),
            exclusive=True,
            group="search",
            thread=True,
        )

    def _do_search(self, filter_str: str) -> None:
        opts = SearchOptions(source_filter=GRPC_SOURCE)
        if filter_str.strip():
            try:
                query = Query.parse_lucene(filter_str)
            except ParseError as exc:
                self._set_status(format_parse_error(filter_str, exc), error=True)
                return
        else:
            query = ALL_ROWS_QUERY

        try:
            t0 = time.perf_counter()
            raw_rows = self._index.search(query, limit=10000, opts=opts)
            search_ms = (time.perf_counter() - t0) * 1000.0
            rows = [Row.from_dict(r) for r in raw_rows]
            grouped = build_tree_data(rows)
        except Exception as exc:
            logger.exception("Search failed for query %r", filter_str)
            self._set_status(f"  Search failed: {exc}", error=True)
            return

        empty_hint = empty_results_hint(query, filter_str) if filter_str.strip() and not rows else None
        self.call_from_thread(self._start_apply, filter_str, rows, grouped, empty_hint, search_ms)

    def _start_apply(
        self,
        filter_str: str,
        rows: list[Row],
        grouped: dict[str, dict[str, list[SignalRow]]],
        empty_hint: str | None = None,
        search_ms: float = 0.0,
    ) -> None:
        self._last_search_ms = search_ms
        if self.detail_panel.dismiss_if_stale({r.key for r in rows}):
            self._current_node = None
            self._current_row = None
        self.run_worker(
            self._apply_tree(filter_str, rows, grouped, empty_hint),
            exclusive=True,
            group="apply",
        )

    async def _apply_tree(
        self,
        filter_str: str,
        rows: list[Row],
        grouped: dict[str, dict[str, list[SignalRow]]],
        empty_hint: str | None,
    ) -> None:
        await self.signal_tree.apply_search_results(filter_str, rows, grouped, empty_hint)
        self._refresh_status_label()
        if not self._activity_watcher.is_running:
            self._start_namespace_activity_watchers()

    def _refresh_status_label(self) -> None:
        ns_count, frame_count, sig_count = self.signal_tree.last_counts
        self._update_status_widget(self._format_status_label(ns_count, frame_count, sig_count))

    def _format_status_label(self, namespaces: int, frames: int, signals: int) -> str:
        parts = [f"{namespaces} namespace(s)", f"{frames} frame(s)", f"{signals} signal(s)"]
        if self._last_search_ms:
            parts.append(f"{self._last_search_ms:.0f} ms")
        return "  " + "  ·  ".join(parts)

    @_signal_tree_event
    def on_tree_node_expanded(self, event: Tree.NodeExpanded[Row]) -> None:
        if not isinstance(event.node.data, FrameRow):
            return
        self.signal_tree.populate_frame(event.node)
        children = event.node.children
        if not children:
            return
        last_child = children[-1]

        def _do_scroll() -> None:
            self.signal_tree.scroll_to_node(last_child, animate=False)

        self.signal_tree.call_after_refresh(self.signal_tree.call_after_refresh, _do_scroll)

    @_signal_tree_event
    def on_tree_node_highlighted(self, event: Tree.NodeHighlighted[Row]) -> None:
        self._current_node = event.node
        self._current_row = event.node.data
        if event.node is self.signal_tree.root:
            self._show_namespaces_summary()
        elif self._is_namespace_node(event.node):
            self._show_namespace_detail(self.signal_tree.ns_name(event.node))
        else:
            self._detail_update.schedule(event.node.data)

    @_signal_tree_event
    def on_tree_node_selected(self, event: Tree.NodeSelected[Row]) -> None:
        if event.node is self.signal_tree.root:
            self._show_namespaces_summary()
        elif self._is_namespace_node(event.node):
            self._show_namespace_detail(self.signal_tree.ns_name(event.node))
        else:
            self.detail_panel.show(event.node.data)

    def _is_namespace_node(self, node: TreeNode[Row]) -> bool:
        return node.data is None and node.parent is self.signal_tree.root

    def _show_namespaces_summary(self) -> None:
        visible = self._visible_namespaces()
        states = {ns: self._activity_watcher.state(ns) for ns in visible}
        snapshots = {ns: self._activity_watcher.snapshot(ns) for ns in visible}
        self.detail_panel.show_namespaces_summary(states, snapshots)

    def _visible_namespaces(self) -> list[str]:
        in_tree = {self.signal_tree.ns_name(child) for child in self.signal_tree.root.children}
        in_tree.discard("")
        return [ns for ns in self._activity_watcher.namespaces if ns in in_tree]

    def _show_namespace_detail(self, ns: str) -> None:
        if not ns:
            self.detail_panel.show(None)
            return
        snap = self._activity_watcher.snapshot(ns)
        self.detail_panel.show_namespace_activity(ns, snap, state=self._activity_watcher.state(ns))

    def _namespace_clipboard_text(self, ns: str) -> str:
        if not ns:
            return ""
        snap = self._activity_watcher.snapshot(ns)
        return Text.from_markup(format_namespace_detail(ns, snap, state=self._activity_watcher.state(ns))).plain

    def _namespaces_summary_clipboard_text(self) -> str:
        visible = self._visible_namespaces()
        states = {ns: self._activity_watcher.state(ns) for ns in visible}
        snapshots = {ns: self._activity_watcher.snapshot(ns) for ns in visible}
        return Text.from_markup(format_namespaces_summary(states, snapshots)).plain

    def on_detail_panel_filter_include(self, event: DetailPanel.FilterInclude) -> None:
        self.search_input.append_filter_term(f"{event.field}:{quote_value(event.value)}")

    def on_search_input_suggest_requested(self, event: SearchInput.SuggestRequested) -> None:
        self.search_suggestions.request(event.raw, self.search_input.cursor_position)

    def on_search_input_search_requested(self, event: SearchInput.SearchRequested) -> None:
        effective = analyze(event.raw).effective_filter
        if effective == self.signal_tree.current_filter:
            return
        self.signal_tree.current_filter = effective
        self._rebuild_tree(effective)

    def _build_suggestions(
        self,
        filter_str: str,
        cursor_pos: int | None,
        limit: int,
        offset: int,
    ) -> SuggestResult | None:
        analysis = analyze(filter_str, cursor_pos)
        active_query = analysis.active
        if active_query is None or active_query.parsed.active_term is None:
            return None
        active = active_query.parsed.active_term
        try:
            value_items, total = self._index.suggest(
                active_query,
                selected=list(analysis.selected),
                limit=limit,
                opts=SearchOptions(source_filter=GRPC_SOURCE),
                exact_values_only=True,
                offset=offset,
                field_priority=list(SUGGEST_FIELD_PRIORITY),
            )
        except Exception:
            logger.exception("Suggest failed for %r (limit=%d, offset=%d)", filter_str, limit, offset)
            return None
        typed = active.value.lower()
        field_items: list[SuggestionItem] = list(field_name_suggestions(active)) if offset == 0 else []
        value_suggestions: list[SuggestionItem] = [ValueSuggestion(value=v["suggestion"], field=v["field"]) for v in value_items]
        items = drop_exact_value_matches(field_items + value_suggestions, typed)
        return SuggestResult(items=items, value_count=len(value_items), total=total)

    def on_key(self, event: events.Key) -> None:
        focused = self.focused
        if focused is None or focused.id != "search-input":
            return
        if event.key not in ("tab", "down", "enter"):
            return
        suggestions = self.search_suggestions
        if not suggestions.has_class("visible") or suggestions.option_count == 0:
            return
        event.prevent_default()
        event.stop()
        if event.key == "enter":
            suggestions.action_select()
            return

        suggestions.focus()
        current = suggestions.highlighted if suggestions.highlighted is not None else -1
        suggestions.highlighted = min(current + 1, suggestions.option_count - 1)

    def on_search_suggestions_field_accepted(self, event: SearchSuggestions.FieldAccepted) -> None:
        self.search_input.accept_field(event.name)

    def on_search_suggestions_value_accepted(self, event: SearchSuggestions.ValueAccepted) -> None:
        self.search_input.accept_value(event.field, event.value)

    def action_reindex(self) -> None:
        self.live_view.cancel_all_workers()
        self.run_worker(self.live_view.reset(), group="live-reset", exclusive=False)
        self._sync_detail_layout()
        self._safe_refresh_bindings()
        self.signal_tree.marks.clear()
        self._current_node = None
        self._current_row = None
        self.detail_panel.show(None)
        self.run_worker(self._do_index, exclusive=True, thread=True)

    def action_focus_search(self) -> None:
        self.search_input.focus()

    def _step_focus(self, step: int) -> None:
        chain = [w for w in self.screen.focus_chain if not (isinstance(w, FocusSkippable) and w.skip_in_tab_chain)]
        if not chain:
            return
        current = self.focused
        if current in chain:
            idx = (chain.index(current) + step) % len(chain)
        else:
            idx = 0 if step >= 0 else len(chain) - 1
        chain[idx].focus()

    def action_skip_live_focus_next(self) -> None:
        self._step_focus(1)

    def action_skip_live_focus_previous(self) -> None:
        self._step_focus(-1)

    def action_clear_search_input(self) -> None:
        search = self.search_input
        if search.value:
            search.value = ""

    def action_toggle_search_help(self) -> None:
        panel = self.search_help_panel
        opening = "visible" not in panel.classes
        panel.toggle_class("visible")
        if opening:
            self.help_scroll.focus()
        else:
            self.search_input.focus()

    def on_markdown_link_clicked(self, event: Markdown.LinkClicked) -> None:
        if not event.href.startswith("field:"):
            return
        self.search_input.append_field(event.href.removeprefix("field:"))
        event.prevent_default()

    def action_clear_search(self) -> None:
        suggestions = self.search_suggestions
        if suggestions.has_class("visible"):
            suggestions.hide()
            self.search_input.focus()
            return
        self.signal_tree.focus()

    def action_toggle_sidebar(self) -> None:
        collapsed = self.sidebar_handle.toggle()
        if collapsed:
            self.detail_panel.show(None)
            if self.focused is self.signal_tree:
                self.screen.focus_next()
        else:
            self.signal_tree.focus()

    def on_sidebar_handle_clicked(self) -> None:
        self.action_toggle_sidebar()

    def on_signal_tree_nothing_to_mark(self, _event: SignalTree.NothingToMark) -> None:
        self.notify("Select a node to mark", severity="information")

    def _selection_for_action(self) -> list[Row] | None:
        if not self.signal_tree.marks.is_empty:
            return self.signal_tree.marks.all_rows()
        row = self._current_row
        if isinstance(row, FrameRow):
            sigs = self.signal_tree.signals_by_frame.get(row.key, [])
            return [row, *sigs]
        if isinstance(row, SignalRow):
            return [row]
        return None

    def action_publish(self) -> None:
        rows = self._selection_for_action()
        if rows is None:
            self.notify("Select a signal or frame node to publish", severity="information")
            return
        self.push_screen(
            PublishValuesModal(rows),
            callback=self._on_publish_result,
        )

    def action_publish_visible(self) -> None:
        rows = list(self.signal_tree.last_visible_rows)
        if not rows:
            self.notify("No rows in the current view to publish", severity="information")
            return
        self.push_screen(
            PublishValuesModal(rows),
            callback=self._on_publish_result,
        )

    def _on_publish_result(self, results: list[tuple[str, str, list[SignalValue]]] | None) -> None:
        if not results:
            return
        # Group + tracked so ``on_unmount`` can cancel an in-flight
        # publish before ``supervisor.stop()`` tears down the channel.
        self.run_worker(self._do_publish_batch(results), group="publish")

    async def _do_publish_batch(self, entries: list[tuple[str, str, list[SignalValue]]]) -> None:
        if not entries:
            return
        broker = await self._supervisor.get_broker()
        try:
            max_len = max(len(values) for _, _, values in entries)
            for i in range(max_len):
                by_ns: dict[str, list[WriteSignal]] = {}
                for ns, name, values in entries:
                    if i < len(values):
                        by_ns.setdefault(ns, []).append(WriteSignal(name=name, value=values[i]))
                await broker.publish(*by_ns.items())
        except Exception as exc:
            if is_transport_failure(exc):
                self._supervisor.signal_disconnect()
            self.notify(f"Publish error: {exc}", severity="error")

    def action_restbus(self) -> None:
        rows = self._selection_for_action()
        if rows is None:
            self.notify("Select a signal or frame node to restbus", severity="information")
            return
        self.push_screen(
            RestbusModal(rows),
            callback=self._on_restbus_result,
        )

    def action_restbus_visible(self) -> None:
        rows = list(self.signal_tree.last_visible_rows)
        if not rows:
            self.notify("No rows in the current view to restbus", severity="information")
            return
        self.push_screen(
            RestbusModal(rows),
            callback=self._on_restbus_result,
        )

    def _on_restbus_result(self, plan: RestbusPlan | None) -> None:
        if plan is None:
            return
        # Group + tracked so ``on_unmount`` can cancel an in-flight
        # restbus mutation before ``supervisor.stop()`` tears down.
        self.run_worker(self._do_restbus(plan), group="restbus")

    async def _do_restbus(self, plan: RestbusPlan) -> None:
        if plan.is_empty:
            return
        broker = await self._supervisor.get_broker()
        try:
            if plan.add_frames:
                await broker.restbus.add(*plan.add_frames.items(), start=True)
            if plan.stop_frames:
                await broker.restbus.add(*plan.stop_frames.items(), start=False)
            if plan.signals_by_ns:
                await broker.restbus.update_signals(*plan.signals_by_ns.items())
            if plan.remove_frames:
                await broker.restbus.remove(*plan.remove_frames.items())
        except Exception as exc:
            if is_transport_failure(exc):
                self._supervisor.signal_disconnect()
            self.notify(f"Restbus error: {exc}", severity="error")

    def action_subscribe(self) -> None:
        target = resolve_subscribe_target(
            self.signal_tree.marks,
            self._current_row,
            self.signal_tree.signals_by_frame,
        )
        if target is None:
            self.notify("Select a signal or frame node to subscribe", severity="information")
            return
        if isinstance(target, ChartTarget):
            row = target.row
            self.live_view.open_or_focus_chart(
                row.namespace,
                row.signal_name,
                work=lambda chart: self._do_chart(chart, row),
            )
        else:
            self.live_view.open_or_focus_subscription(
                target.signals,
                target.frames,
                work=self._do_subscribe,
            )

    async def _do_chart(self, view: ChartView, row: SignalRow) -> None:
        broker = await self._supervisor.get_broker()

        try:
            signals = await broker.read_signals((row.namespace, [row.signal_name]))
            for sig in signals:
                if isinstance(sig.value, (int, float)):
                    ts = int(time.time() * 1_000_000)
                    view.on_signal_value(ts, float(sig.value))
        except Exception as exc:
            logger.debug("Failed to seed chart with current value", exc_info=True)
            if is_transport_failure(exc):
                self._supervisor.signal_disconnect()
                return

        # ``subscribe_frames`` is typed as ``AsyncIterator`` but the SDK returns
        # an async generator (it has ``aclose``); cast so ``aclosing`` works.
        try:
            stream = cast(
                AsyncGenerator[Frame, None],
                await broker.subscribe_frames((row.namespace, [row.frame_name]), on_change=False),
            )
            async with aclosing(stream):
                async for frame in stream:
                    value = frame.signals.get(row.signal_name)
                    if isinstance(value, (int, float)):
                        view.on_signal_value(frame.timestamp, float(value))
        except asyncio.CancelledError:
            raise
        except Exception as exc:
            if is_transport_failure(exc):
                self._supervisor.signal_disconnect()
            else:
                logger.debug("Chart stream ended", exc_info=True)

    async def _do_subscribe(self, view: SubscriptionView) -> None:
        broker = await self._supervisor.get_broker()
        plan = build_subscription_plan(view.subscribed_signals, view.subscribed_frames)

        try:
            ts = int(time.time() * 1_000_000)
            for ns, fnames in plan.by_ns_frame.items():
                read_names: list[str] = list(fnames)
                for fname in fnames:
                    read_names.extend(plan.signals_by_frame.get((ns, fname), ()))
                results = await broker.read_signals((ns, read_names))
                result_map: dict[str, SignalValue] = {sig.name: sig.value for sig in results if sig.value is not None}
                for fname in fnames:
                    payload = result_map.get(fname, b"")
                    own_signals = plan.signals_by_frame.get((ns, fname), [])
                    sig_values: dict[str, SignalValue] = {name: result_map[name] for name in own_signals if name in result_map}
                    view.on_frame_update(
                        frame_key=f"{ns}:{fname}",
                        payload=payload,
                        timestamp=ts,
                        signals=sig_values,
                        watched_keys=plan.watched_keys,
                    )
        except Exception as exc:
            logger.debug("Failed to seed subscription with cached values", exc_info=True)
            if is_transport_failure(exc):
                self._supervisor.signal_disconnect()
                return

        try:
            stream = cast(
                AsyncGenerator[Frame, None],
                await broker.subscribe_frames(*plan.subscribe_args, on_change=view.on_change_mode),
            )
            async with aclosing(stream):
                async for frame in stream:
                    view.on_frame_update(
                        frame_key=f"{frame.namespace}:{frame.name}",
                        payload=frame.value,
                        timestamp=frame.timestamp,
                        signals=frame.signals,
                        watched_keys=plan.watched_keys,
                    )
        except asyncio.CancelledError:
            raise
        except Exception as exc:
            if is_transport_failure(exc):
                self._supervisor.signal_disconnect()
            else:
                logger.debug("Subscribe stream ended", exc_info=True)

    def _start_namespace_activity_watchers(self) -> None:
        if self._activity_watcher.is_running:
            return
        # Broker rejects FramesDistribution subscriptions on ``scripted`` namespaces.
        namespaces = sorted(ns for ns in self._index.all_namespaces() if self._namespace_types.get(ns) != "scripted")
        if not namespaces:
            return
        self._activity_watcher.start(namespaces, self._ns_cycle_ms)
        self._activity_ticker = self.set_interval(0.25, self._tick_namespace_activity)

    async def _stop_namespace_activity_watchers(self) -> None:
        if self._activity_ticker is not None:
            self._activity_ticker.stop()
            self._activity_ticker = None
        await self._activity_watcher.stop()

    def _tick_namespace_activity(self) -> None:
        current = {ns: self._activity_watcher.state(ns) for ns in self._activity_watcher.namespaces}
        for ns, state in current.items():
            if self._last_state_snapshot.get(ns) != state:
                self.signal_tree.set_namespace_state(ns, state)
        self._last_state_snapshot = current
        if self.detail_panel.showing_summary:
            self._show_namespaces_summary()
        else:
            shown_ns = self.detail_panel.current_namespace
            if shown_ns is not None:
                self._show_namespace_detail(shown_ns)

    def on_live_tabs_reveal_requested(self, event: LiveTabs.RevealRequested) -> None:
        target = event.target
        revealed = self.signal_tree.reveal(
            target.namespace,
            frame_name=target.frame_name,
            signal_name=target.signal_name,
        )
        if not revealed:
            self.notify("Not in current filter", severity="warning")
            return

    def on_live_tabs_tab_opened(self, _event: LiveTabs.TabOpened) -> None:
        self._sync_detail_layout()

    def on_live_tabs_tab_closed(self, _event: LiveTabs.TabClosed) -> None:
        if self.live_view.tab_count == 0:
            self.signal_tree.focus()
        self._sync_detail_layout()

    def _sync_detail_layout(self) -> None:
        self.detail_container.set_class(self.live_view.tab_count > 0, "with-live")

    def on_subscription_view_on_change_toggled(self, event: SubscriptionView.OnChangeToggled) -> None:
        """Restart the affected tab's subscribe worker with the new mode.

        ``_do_subscribe`` reads ``view.on_change_mode`` at call time, so
        bouncing the worker is enough — no closure capture needed.
        """
        self.live_view.restart_worker(event.view, self._do_subscribe)

    def _safe_refresh_bindings(self) -> None:
        """Refresh the footer's keybinding hints, swallowing errors."""
        try:
            self.refresh_bindings()
        except Exception:
            logger.debug("refresh_bindings skipped (no active screen)", exc_info=True)

    async def on_unmount(self) -> None:
        await self._stop_namespace_activity_watchers()
        # Cancel any in-flight publish / restbus workers *before* the
        # supervisor stops — otherwise the broker disconnects under
        # them and they raise into a partially-torn-down App.
        self._cancel_broker_workers()
        await self._supervisor.stop()


# ``command_palette`` imports ``SignalsExplorer`` at the top of its module
# for type annotations; importing ``SearchCommands`` here ahead of the class
# definition would deadlock the cycle, so the registration runs after the
# class is built.
from remotivelabs.cli.topology.tui.command_palette import SearchCommands  # noqa: E402

SignalsExplorer.COMMANDS = SignalsExplorer.COMMANDS | {SearchCommands}
