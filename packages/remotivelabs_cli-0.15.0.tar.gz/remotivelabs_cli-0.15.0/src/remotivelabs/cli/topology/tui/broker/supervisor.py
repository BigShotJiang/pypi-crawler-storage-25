"""Owns the broker connection lifecycle for the TUI explorer.

The supervisor is the single owner of ``BrokerClient`` construction and
disposal: it dials the broker on start, exposes a readiness gate so
callers can park on `get_broker`, and reconnects on transport-level
failures after a fixed delay.

Pulled out of ``explore_app.py`` so the App stays focused on UI wiring;
the supervisor is import-cheap, testable in isolation, and only knows
about gRPC + ``BrokerClient``.
"""

from __future__ import annotations

import asyncio
import logging
from collections.abc import Awaitable, Callable
from contextlib import suppress
from dataclasses import dataclass
from enum import Enum

import grpc

from remotivelabs.broker.auth import ApiKeyAuth, AuthMethod, NoAuth, TokenAuth
from remotivelabs.broker.client import BrokerClient
from remotivelabs.cli.settings import settings

logger = logging.getLogger(__name__)


class ConnectionState(str, Enum):
    """High-level state of the broker connection."""

    CONNECTING = "connecting"
    CONNECTED = "connected"
    DISCONNECTED = "disconnected"


# gRPC status codes that mean "the channel is gone, give up on this client
# and reconnect" — as opposed to per-call failures (e.g. NOT_FOUND on a
# missing frame) which the caller should surface but shouldn't bring down
# the whole connection.
_TRANSPORT_FAILURE_CODES: frozenset[grpc.StatusCode] = frozenset(
    {
        grpc.StatusCode.UNAVAILABLE,
        grpc.StatusCode.UNAUTHENTICATED,
        grpc.StatusCode.DEADLINE_EXCEEDED,
    }
)


def is_transport_failure(exc: BaseException) -> bool:
    """Decide whether ``exc`` indicates the broker channel is dead.

    Returning ``True`` means callers should signal disconnect via
    `BrokerSupervisor.signal_disconnect` and stop reusing the
    current ``BrokerClient``.
    """
    if isinstance(exc, grpc.aio.AioRpcError):
        return exc.code() in _TRANSPORT_FAILURE_CODES
    return isinstance(exc, ConnectionError)


async def _async_noop() -> None:
    return None


def _state_noop(_state: ConnectionState) -> None:
    pass


def _connected_noop(_client: BrokerClient) -> None:
    pass


def _error_noop(_msg: str) -> None:
    pass


@dataclass(slots=True)
class BrokerCallbacks:
    """Hooks the `BrokerSupervisor` invokes through the connect lifecycle.

    Each hook is optional — defaults are no-ops, so callers wire only
    the hooks they care about. Bundled into a dataclass so the
    supervisor's surface stays narrow and tests can pass a partial
    record without juggling keyword arguments.
    """

    on_state_change: Callable[[ConnectionState], None] = _state_noop
    on_connected: Callable[[BrokerClient], None] = _connected_noop
    on_before_disconnect: Callable[[], Awaitable[None]] = _async_noop
    notify_error: Callable[[str], None] = _error_noop


def _resolve_auth(url: str, api_key: str | None) -> AuthMethod:
    if api_key:
        return ApiKeyAuth(api_key)
    if url.startswith("https"):
        token = settings.get_active_token()
        return TokenAuth(token) if token else NoAuth()
    return NoAuth()


def default_connect(broker_url: str, api_key: str | None) -> Callable[[], Awaitable[BrokerClient]]:
    """Build the production connect closure for `BrokerSupervisor`.

    Captures ``broker_url`` + ``api_key`` so the supervisor stays
    free of authentication / URL plumbing and tests can swap in their
    own factory (typically returning an ``AsyncMock``) without
    touching this code path.
    """

    async def _connect() -> BrokerClient:
        auth = _resolve_auth(broker_url, api_key)
        return await BrokerClient(broker_url, auth=auth).connect()

    return _connect


class BrokerSupervisor:
    """Connect / reconnect loop with a fixed retry delay."""

    RECONNECT_DELAY_SECS = 5.0
    # Debounce window for ``_watch_channel_state``. gRPC's transparent
    # reconnect briefly drops the channel out of READY (IDLE → CONNECTING
    # → READY) during normal operation; we wait this long before
    # declaring a degraded channel actually dead so a transient blip
    # doesn't trip a full reconnect cycle.
    CHANNEL_DEGRADE_GRACE_SECS = 2.0

    def __init__(
        self,
        connect: Callable[[], Awaitable[BrokerClient]],
        callbacks: BrokerCallbacks | None = None,
    ) -> None:
        # ``connect`` is injected so the supervisor doesn't bake in a
        # specific way to dial the broker. Production passes a closure
        # over ``BrokerClient(url, auth=...).connect()``; tests pass a
        # closure that returns an ``AsyncMock``. Both go through the
        # same ``_run`` loop, so the test surface exercises the real
        # connect / reconnect path without any test-only seams.
        self._connect = connect
        self._callbacks = callbacks or BrokerCallbacks()
        self._ready_future: asyncio.Future[BrokerClient] | None = None
        self._died = asyncio.Event()
        self._task: asyncio.Task[None] | None = None
        self._channel_watch: asyncio.Task[None] | None = None
        self._state = ConnectionState.CONNECTING
        # Tracked separately so ``stop()`` can disconnect the live client
        # even when ``_ready_future`` has already rotated to a fresh one.
        self._current_client: BrokerClient | None = None

    @property
    def state(self) -> ConnectionState:
        return self._state

    def start(self) -> None:
        """Spawn the supervisor task. Idempotent — re-starting a running
        supervisor is a no-op rather than a second loop."""
        if self._task is not None and not self._task.done():
            return
        self._ready_future = self._fresh_future()
        self._task = asyncio.create_task(self._run(), name="broker-supervisor")

    async def stop(self) -> None:
        """Cancel the supervisor and dispose the current client."""
        if self._channel_watch is not None:
            self._channel_watch.cancel()
            with suppress(asyncio.CancelledError, Exception):
                await self._channel_watch
            self._channel_watch = None
        if self._task is not None:
            self._task.cancel()
            with suppress(asyncio.CancelledError, Exception):
                await self._task
            self._task = None
        client = self._current_client
        self._current_client = None
        if client is not None:
            with suppress(Exception):
                await client.disconnect()
        fut = self._ready_future
        if fut is not None and not fut.done():
            fut.cancel()
        self._ready_future = None

    async def get_broker(self) -> BrokerClient:
        """Block until the supervisor has a connected ``BrokerClient``.

        ``asyncio.shield`` keeps the future alive across cancellation
        of the calling task — handy when a worker is being torn down
        but the supervisor itself is still running.
        """
        if self._ready_future is None:
            raise RuntimeError("BrokerSupervisor.get_broker() called before start()")
        return await asyncio.shield(self._ready_future)

    def signal_disconnect(self) -> None:
        """Tell the supervisor the current channel is dead.

        Idempotent — multiple workers tripping the same transport error
        all set the same event; the supervisor only acts on the first
        wake-up of each connect cycle.
        """
        self._died.set()

    # ---- internals ------------------------------------------------------

    @staticmethod
    def _fresh_future() -> asyncio.Future[BrokerClient]:
        return asyncio.get_running_loop().create_future()

    def _set_state(self, state: ConnectionState) -> None:
        if self._state == state:
            return
        self._state = state
        self._callbacks.on_state_change(state)

    async def _run(self) -> None:
        while True:
            current = self._ready_future
            if current is None or current.done():
                current = self._fresh_future()
                self._ready_future = current

            self._died.clear()
            self._set_state(ConnectionState.CONNECTING)
            try:
                client = await self._connect()
            except asyncio.CancelledError:
                raise
            except Exception as exc:
                logger.debug("broker connect failed (will retry in %.1fs)", self.RECONNECT_DELAY_SECS, exc_info=True)
                self._set_state(ConnectionState.DISCONNECTED)
                self._callbacks.notify_error(f"Broker connect failed: {exc}")
                try:
                    await asyncio.sleep(self.RECONNECT_DELAY_SECS)
                except asyncio.CancelledError:
                    raise
                continue

            current.set_result(client)
            self._current_client = client
            self._set_state(ConnectionState.CONNECTED)
            try:
                self._callbacks.on_connected(client)
            except Exception:
                logger.debug("on_connected hook raised", exc_info=True)

            self._channel_watch = asyncio.create_task(
                self._watch_channel_state(client),
                name="broker-channel-watch",
            )

            await self._died.wait()

            self._set_state(ConnectionState.DISCONNECTED)
            self._ready_future = self._fresh_future()
            if self._channel_watch is not None:
                self._channel_watch.cancel()
                with suppress(asyncio.CancelledError, Exception):
                    await self._channel_watch
                self._channel_watch = None
            with suppress(Exception):
                await self._callbacks.on_before_disconnect()
            with suppress(Exception):
                await client.disconnect()
            self._current_client = None

    async def _watch_channel_state(self, client: BrokerClient) -> None:
        channel = client._channel  # noqa: SLF001
        while True:
            state = channel.get_state()
            if state == grpc.ChannelConnectivity.READY:
                try:
                    await channel.wait_for_state_change(state)
                except asyncio.CancelledError:
                    return
                except Exception:
                    logger.debug("channel wait_for_state_change failed; signalling disconnect", exc_info=True)
                    self.signal_disconnect()
                    return
                continue
            try:
                await asyncio.sleep(self.CHANNEL_DEGRADE_GRACE_SECS)
            except asyncio.CancelledError:
                return
            if channel.get_state() != grpc.ChannelConnectivity.READY:
                logger.debug("broker channel in %s after grace window; signalling disconnect", state)
                self._callbacks.notify_error("Broker channel disconnected — reconnecting...")
                self.signal_disconnect()
                return


__all__ = [
    "BrokerCallbacks",
    "BrokerSupervisor",
    "ConnectionState",
    "default_connect",
    "is_transport_failure",
]
