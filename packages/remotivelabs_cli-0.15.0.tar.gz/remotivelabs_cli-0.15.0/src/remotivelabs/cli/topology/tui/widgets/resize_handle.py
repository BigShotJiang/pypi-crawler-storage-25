"""Shared mouse-drag plumbing for handles that resize a target widget."""

from __future__ import annotations

from collections.abc import Callable
from typing import Any

from textual import events
from textual.widget import Widget
from textual.widgets import Static


class ResizeHandle(Static, can_focus=False):
    """Mouse-drag plumbing for handles that resize a target widget's width.

    Subclasses configure the target lookup and clamping via ``__init__`` and
    can opt into click-vs-drag detection (``click_threshold > 0``) to expose
    a "tap without moving" gesture distinct from a resize drag.

    Cumulative-delta protocol: every drag step applies
    ``new_width = anchor + sign * delta`` (where ``anchor`` is the target's
    width at mouse-down).  Cumulative — not incremental — keeps the handle
    locked under the mouse cursor even when the width clamps at the bounds.
    """

    def __init__(  # noqa: PLR0913 — keyword-only resize knobs read better than a config dataclass for two callers
        self,
        get_target: Callable[[], Widget],
        *,
        min_width: int,
        right_padding: int,
        invert_delta: bool = False,
        click_threshold: int = 0,
        content: str = "│",
        **kwargs: Any,
    ) -> None:
        super().__init__(content, **kwargs)
        self._get_target = get_target
        self._min_width = min_width
        self._right_padding = right_padding
        self._delta_sign = -1 if invert_delta else 1
        self._click_threshold = click_threshold
        self._anchor_x: int | None = None
        self._anchor_width: int | None = None
        self._dragged: bool = False

    def apply_resize(self, delta: int, *, is_start: bool = False) -> None:
        """Snapshot or apply a cumulative drag delta.

        ``is_start=True`` records the current target width as the anchor;
        subsequent calls with ``is_start=False`` set the target's width to
        ``anchor + sign * delta``, clamped to ``[min_width, screen_width -
        right_padding]``.  Subclass-overridable `_should_resize`
        skips the apply step entirely when the target isn't currently
        resizable (e.g. collapsed).
        """
        target = self._get_target()
        if is_start:
            self._anchor_width = target.size.width
            return
        if self._anchor_width is None or not self._should_resize():
            return
        new_width = self._anchor_width + self._delta_sign * delta
        new_width = max(self._min_width, new_width)
        new_width = min(new_width, max(self._min_width, self.app.size.width - self._right_padding))
        target.styles.width = new_width

    def on_mouse_down(self, event: events.MouseDown) -> None:
        self._anchor_x = event.screen_x
        self._dragged = False
        self.capture_mouse()
        self.apply_resize(0, is_start=True)

    def on_mouse_move(self, event: events.MouseMove) -> None:
        if self._anchor_x is None:
            return
        delta = event.screen_x - self._anchor_x
        if not self._dragged and self._click_threshold > 0 and abs(delta) < self._click_threshold:
            return
        self._dragged = True
        self.apply_resize(delta)

    def on_mouse_up(self, _event: events.MouseUp) -> None:
        if self._anchor_x is None:
            return
        self.release_mouse()
        was_dragged = self._dragged
        self._anchor_x = None
        self._anchor_width = None
        self._dragged = False
        if not was_dragged and self._click_threshold > 0:
            self._on_tap()

    def _should_resize(self) -> bool:
        """Override to skip the resize apply (e.g., when the target is hidden)."""
        return True

    def _on_tap(self) -> None:
        """Override to handle a tap without movement.  Default: no-op."""
