"""Public widget surface for the TUI explorer.

Split into sub-modules by feature; this module re-exports the public
classes so callers can keep importing ``from .widgets import X``.

Suggestion-pagination tuning constants and the internal
``SuggestFn`` type alias intentionally aren't re-exported — import
them from `widgets.search` directly if a caller needs them.
"""

from __future__ import annotations

from remotivelabs.cli.topology.tui.widgets.detail import DetailPanel
from remotivelabs.cli.topology.tui.widgets.help import SEARCH_HELP_MD, HelpResizeHandle, HelpScroll
from remotivelabs.cli.topology.tui.widgets.live import ChartView, LiveTabs, SubscriptionView
from remotivelabs.cli.topology.tui.widgets.resize_handle import ResizeHandle
from remotivelabs.cli.topology.tui.widgets.search import (
    FieldSuggestion,
    SearchInput,
    SearchSuggestions,
    SuggestionItem,
    SuggestResult,
    ValueSuggestion,
)
from remotivelabs.cli.topology.tui.widgets.tree import SidebarHandle, SignalTree

__all__ = [
    "SEARCH_HELP_MD",
    "ChartView",
    "DetailPanel",
    "FieldSuggestion",
    "HelpResizeHandle",
    "HelpScroll",
    "LiveTabs",
    "ResizeHandle",
    "SearchInput",
    "SearchSuggestions",
    "SidebarHandle",
    "SignalTree",
    "SubscriptionView",
    "SuggestionItem",
    "SuggestResult",
    "ValueSuggestion",
]
