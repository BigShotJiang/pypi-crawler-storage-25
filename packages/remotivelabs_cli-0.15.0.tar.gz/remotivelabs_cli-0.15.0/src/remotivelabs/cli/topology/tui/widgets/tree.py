"""Signal tree (namespace → frame → signal) and its sidebar collapse / resize handle."""

from __future__ import annotations

import asyncio
from collections.abc import Callable
from typing import Any

from rich.text import Text
from textual.binding import Binding
from textual.message import Message
from textual.widget import Widget
from textual.widgets import Tree
from textual.widgets.tree import TreeNode

from remotivelabs.cli.topology.tui.bindings import jump_nav_bindings, vertical_nav_bindings
from remotivelabs.cli.topology.tui.broker import LivenessState
from remotivelabs.cli.topology.tui.marks import MarkRegistry
from remotivelabs.cli.topology.tui.rows import FrameRow, Row, SignalRow
from remotivelabs.cli.topology.tui.widgets.detail import DetailPanel, format_detail
from remotivelabs.cli.topology.tui.widgets.resize_handle import ResizeHandle


class SignalTree(Tree[Row]):
    """Namespace → frame → signal tree, with mark-aware label rendering."""

    class NothingToMark(Message):
        """Posted when ``toggle_mark`` fires with no markable node under the cursor."""

    BINDINGS = [
        Binding("e", "expand_all", "Expand all"),
        Binding("c", "collapse_all", "Collapse all"),
        Binding("m", "toggle_mark", "mark/clear all", key_display="m/M"),
        Binding("M", "clear_marks", show=False),
        Binding("s", "app.subscribe", "Subscribe"),
        Binding("p", "app.publish", "Publish (all)", key_display="p/P"),
        Binding("P", "app.publish_visible", show=False),
        Binding("r", "app.restbus", "Restbus (all)", key_display="r/R"),
        Binding("R", "app.restbus_visible", show=False),
        Binding("f", "filter_by_cursor", "Filter to row"),
        *vertical_nav_bindings("cursor_down", "cursor_up"),
        *jump_nav_bindings("tree_top", "tree_bottom"),
        Binding("ctrl+c", "copy_node_name", "Copy name", priority=True, show=False),
        Binding("ctrl+y", "copy_node_detail", "Copy detail", priority=True),
    ]

    def action_tree_top(self) -> None:
        self.move_cursor_to_line(0)

    def action_tree_bottom(self) -> None:
        last = max(0, self.virtual_size.height - 1)
        self.move_cursor_to_line(last)

    def action_copy_node_name(self) -> None:
        """Copy the cursor node's bare name to the system clipboard."""
        node = self.cursor_node
        if node is None:
            return
        name = self._node_name(node)
        if not name:
            return
        self.app.copy_to_clipboard(name)

    def action_filter_by_cursor(self) -> None:
        """Narrow the search filter to the cursor row's identity field.

        Mirrors the click-filter on the detail panel — namespace
        groupers filter by ``namespace``, frames by ``frame_name``,
        signals by ``signal_name``. Posts the same `DetailPanel.FilterInclude`
        message the click action posts; the App's existing handler
        appends ``field:value`` to the search input.
        """
        node = self.cursor_node
        if node is None:
            return
        data = node.data
        if isinstance(data, SignalRow) and data.signal_name:
            self._post_filter("signal_name", data.signal_name)
        elif isinstance(data, FrameRow) and data.frame_name:
            self._post_filter("frame_name", data.frame_name)
        elif data is None:
            ns = SignalTree.ns_name(node)
            if ns:
                self._post_filter("namespace", ns)

    def _post_filter(self, field: str, value: str) -> None:
        """Post a `DetailPanel.FilterInclude` so the App's existing
        click-filter handler picks it up. One message type, one wire."""
        self.post_message(DetailPanel.FilterInclude(field, value))

    def action_copy_node_detail(self) -> None:
        """Copy the formatted detail text (the panel's content, with
        Rich markup stripped) for the cursor node.

        Namespace nodes have no row-level detail; for those, fall
        back to copying the namespace name."""
        node = self.cursor_node
        if node is None:
            return
        detail = self._node_detail(node)
        if not detail:
            return
        self.app.copy_to_clipboard(detail)

    @staticmethod
    def _node_name(node: TreeNode[Row]) -> str:
        """Bare name of a tree node — signal_name / frame_name /
        namespace string, depending on the node's data.

        Namespace nodes derive the name from a child row rather than
        the rendered label, so the activity sigil (``●``) and the
        ``(Nf, Ms)`` counts don't end up in the clipboard or as the
        lookup key for the namespace activity registry.
        """
        data = node.data
        if isinstance(data, SignalRow):
            return data.signal_name
        if isinstance(data, FrameRow):
            return data.frame_name
        # Namespace node — pull the bare name off a child row. Falls
        # back to the (possibly decorated) label only if the node has
        # no children to read from yet.
        ns = SignalTree.ns_name(node)
        if ns:
            return ns
        label = node.label
        return label.plain if isinstance(label, Text) else str(label)

    def _node_detail(self, node: TreeNode[Row]) -> str:
        """Plain-text detail for a tree node — the same content the
        detail panel shows for that node.

        Root: namespaces-summary aggregate (counts + stale list +
        per-namespace activity blocks). Namespace: that namespace's
        activity block. Frame / signal: row metadata.
        """
        data = node.data
        if isinstance(data, (SignalRow, FrameRow)):
            return Text.from_markup(format_detail(data)).plain
        if node is self.root:
            if self.root_detail_provider is not None:
                return self.root_detail_provider()
            return self._node_name(node)
        if data is None and self.namespace_detail_provider is not None:
            ns = self._node_name(node)
            return self.namespace_detail_provider(ns)
        return self._node_name(node)

    def __init__(self, label: str, **kwargs: Any) -> None:
        super().__init__(label, **kwargs)
        self.marks = MarkRegistry()
        self.namespace_detail_provider: Callable[[str], str] | None = None
        self.root_detail_provider: Callable[[], str] | None = None
        self.signals_by_frame: dict[str, list[SignalRow]] = {}
        self.expand_all_frames: bool = False
        self.manually_expanded_frames: set[str] = set()
        self.current_filter: str = ""
        self.last_counts: tuple[int, int, int] = (0, 0, 0)
        # Snapshot of the rows currently rendered in the tree — drives the
        # ``Publish all`` / ``Restbus all`` shortcuts that target the full
        # filtered view rather than the marks set.
        self.last_visible_rows: list[Row] = []
        self.empty_hint: str | None = None
        # Per-namespace liveness state. Pushed by the App's activity
        # ticker; consumed by ``ns_label`` to colour the leading sigil.
        # Defaults to ``QUIET`` for any namespace the ticker hasn't
        # reported on yet — see `LivenessState` for semantics.
        self._namespace_states: dict[str, LivenessState] = {}

    def signal_label(self, row: SignalRow) -> str:
        if self.marks.has_signal(row.key):
            return f"[bold green]* {row.signal_name}[/bold green]"
        return f"[green]{row.signal_name}[/green]"

    def frame_label(self, row: FrameRow, signal_count: int | None = None) -> str:
        count = f"  [dim]({signal_count})[/dim]" if signal_count else ""
        if self.marks.has_frame(row.key):
            return f"[bold yellow]* {row.frame_name}[/bold yellow]{count}"
        return f"[yellow]{row.frame_name}[/yellow]{count}"

    # Color of the leading liveness sigil per state. See
    # `LivenessState` for the per-state semantics.
    _STATE_COLOR: dict[LivenessState, str] = {
        LivenessState.UNKNOWN: "dim",
        LivenessState.LIVE: "green",
        LivenessState.QUIET: "yellow",
        LivenessState.STALE: "red",
    }

    def ns_label(
        self,
        ns: str,
        frame_count: int | None = None,
        signal_count: int | None = None,
        *,
        state: LivenessState = LivenessState.UNKNOWN,
    ) -> str:
        counts = ""
        if frame_count is not None and signal_count is not None:
            counts = f"  [dim]({frame_count}f, {signal_count}s)[/dim]"
        color = self._STATE_COLOR.get(state, "dim")
        indicator = f"[bold {color}]●[/bold {color}] "
        if self.marks.has_marks_in_namespace(ns):
            return f"{indicator}[bold green]* {ns}[/bold green]{counts}"
        return f"{indicator}[bold]{ns}[/bold]{counts}"

    @staticmethod
    def ns_name(node: TreeNode[Row]) -> str:
        """Best-effort namespace name for a node assumed to live under root.

        First child whose ``data`` is a ``FrameRow`` (or the frame's own
        signal child) is consulted — namespace is denormalised on every row
        so we just read it off whichever child loaded first.
        """
        for child in node.children:
            if isinstance(child.data, FrameRow):
                return child.data.namespace
            if child.data and isinstance(child.data, SignalRow):
                return child.data.namespace
        return ""

    def ns_counts(self, ns_node: TreeNode[Row]) -> tuple[int, int]:
        """Return ``(frame_count, signal_count)`` for a namespace node."""
        frame_count = 0
        signal_count = 0
        for child in ns_node.children:
            if isinstance(child.data, FrameRow):
                frame_count += 1
                signal_count += len(self.signals_by_frame.get(child.data.key, []))
        return frame_count, signal_count

    def frame_signal_count(self, node: TreeNode[Row]) -> int:
        data = node.data
        if isinstance(data, FrameRow):
            return len(self.signals_by_frame.get(data.key, []))
        return 0

    def update_ns_label(self, ns_node: TreeNode[Row]) -> None:
        """Refresh a namespace node's label from current counts + mark state."""
        ns = self.ns_name(ns_node)
        frame_count, signal_count = self.ns_counts(ns_node)
        ns_node.set_label(
            self.ns_label(
                ns,
                frame_count=frame_count,
                signal_count=signal_count,
                state=self._namespace_states.get(ns, LivenessState.UNKNOWN),
            )
        )

    def set_namespace_state(self, ns: str, state: LivenessState) -> None:
        """Set the liveness state of a namespace.

        See `LivenessState` for the meaning of each member.
        No-op when the requested state matches the cached one — keeps
        the App's diff-only ticker cheap.
        """
        if self._namespace_states.get(ns) == state:
            return
        self._namespace_states[ns] = state
        for child in self.root.children:
            if self.ns_name(child) == ns:
                self.update_ns_label(child)
                return

    def reveal(
        self,
        namespace: str,
        frame_name: str | None = None,
        signal_name: str | None = None,
    ) -> bool:
        """Move the tree cursor to the matching row, expanding its parents.

        Resolves missing ``frame_name`` from ``namespace`` + ``signal_name``
        via `signals_by_frame` so call sites that only know
        ``(namespace, signal_name)`` (e.g. charts) don't have to do the
        lookup themselves. Returns ``True`` on a successful reveal,
        ``False`` if the row isn't currently in the filtered tree.
        """
        if signal_name is not None and frame_name is None:
            frame_name = self._frame_name_for_signal(namespace, signal_name)
        ns_node = next((c for c in self.root.children if self.ns_name(c) == namespace), None)
        if ns_node is None:
            return False
        ns_node.expand()
        if frame_name is None:
            self._move_cursor_after_layout(ns_node)
            return True
        frame_node = next(
            (c for c in ns_node.children if isinstance(c.data, FrameRow) and c.data.frame_name == frame_name),
            None,
        )
        if frame_node is None:
            self._move_cursor_after_layout(ns_node)
            return False

        self.populate_frame(frame_node)
        frame_node.expand()

        if isinstance(frame_node.data, FrameRow):
            self.manually_expanded_frames.add(frame_node.data.key)
        if signal_name is None:
            self._move_cursor_after_layout(frame_node)
            return True
        signal_node = next(
            (c for c in frame_node.children if isinstance(c.data, SignalRow) and c.data.signal_name == signal_name),
            None,
        )
        if signal_node is None:
            self._move_cursor_after_layout(frame_node)
            return False
        self._move_cursor_after_layout(signal_node)
        return True

    def _move_cursor_after_layout(self, node: TreeNode[Row]) -> None:
        """Defer ``move_cursor`` until after Textual rebuilds its line layout.

        Textual assigns ``TreeNode._line`` only during ``Tree._build``, which
        runs as part of the refresh cycle. Calling ``move_cursor`` synchronously
        after ``expand()`` reads a stale ``_line == -1``, which Textual's
        ``validate_cursor_line`` clamps to ``0`` — the root row. Scheduling via
        ``call_after_refresh`` runs the cursor move after the next refresh has
        rebuilt the line list, so ``_line`` is correct by the time we move.
        """
        self.call_after_refresh(self._apply_cursor_move, node)

    def _apply_cursor_move(self, node: TreeNode[Row]) -> None:
        self.move_cursor(node)
        self.scroll_to_node(node)

    def _frame_name_for_signal(self, namespace: str, signal_name: str) -> str | None:
        """Reverse-lookup the frame name owning ``signal_name`` in
        ``namespace``. Returns ``None`` if the signal isn't in the
        currently-filtered tree."""
        for frame_key, sigs in self.signals_by_frame.items():
            ns_part, _, frame_part = frame_key.partition(":")
            if ns_part != namespace:
                continue
            if any(s.signal_name == signal_name for s in sigs):
                return frame_part
        return None

    def populate_frame(self, frame_node: TreeNode[Row]) -> None:
        """Add cached signal leaves to a frame node.  Idempotent.

        Frames mount collapsed by default — this fires from
        ``Tree.NodeExpanded`` to fill them on first open.
        """
        data = frame_node.data
        if not isinstance(data, FrameRow):
            return
        if any(isinstance(c.data, SignalRow) for c in frame_node.children):
            return
        for sig_row in self.signals_by_frame.get(data.key, []):
            frame_node.add_leaf(self.signal_label(sig_row), data=sig_row)

    def mark_frame(self, node: TreeNode[Row], marking: bool) -> None:
        """
        Mark or unmark a frame node and all its child signals.
        """
        data = node.data
        if not isinstance(data, FrameRow):
            return
        cached_signals = self.signals_by_frame.get(data.key, [])
        self.marks.set_frame(data, marking, cached_signals)
        node.set_label(self.frame_label(data, signal_count=len(cached_signals)))
        for child in node.children:
            if isinstance(child.data, SignalRow):
                child.set_label(self.signal_label(child.data))

    def mark_namespace(self, node: TreeNode[Row], marking: bool) -> None:
        """Mark or unmark every frame under a namespace node."""
        for child in node.children:
            if isinstance(child.data, FrameRow):
                self.mark_frame(child, marking)
        self.update_ns_label(node)

    def toggle_mark_at(self, node: TreeNode[Row]) -> bool:
        """
        Flip the mark on whatever ``node`` represents.
        """
        if isinstance(node.data, FrameRow):
            self.mark_frame(node, not self.marks.has_frame(node.data.key))
            if node.parent is not None:
                self.update_ns_label(node.parent)
            return True
        if isinstance(node.data, SignalRow):
            self.marks.toggle_signal(node.data)
            node.set_label(self.signal_label(node.data))
            if node.parent is not None and node.parent.parent is not None:
                self.update_ns_label(node.parent.parent)
            return True
        if node is self.root:
            any_unmarked = any(not self.marks.has_marks_in_namespace(self.ns_name(ns_node)) for ns_node in node.children)
            for ns_node in node.children:
                self.mark_namespace(ns_node, any_unmarked)
            return True
        if node.children:
            ns = self.ns_name(node)
            self.mark_namespace(node, not self.marks.has_marks_in_namespace(ns))
            return True
        return False

    def action_toggle_mark(self) -> None:
        """Toggle the mark on the cursor's node, or notify the App if nothing's selected."""
        node = self.cursor_node
        if node is None or not self.toggle_mark_at(node):
            self.post_message(self.NothingToMark())

    def action_clear_marks(self) -> None:
        self.clear_marks()

    def clear_marks(self) -> None:
        """Drop every mark and refresh the affected labels."""
        self.marks.clear()
        for ns_node in self.root.children:
            self.update_ns_label(ns_node)
            for frame_node in ns_node.children:
                if isinstance(frame_node.data, FrameRow):
                    frame_node.set_label(self.frame_label(frame_node.data, signal_count=self.frame_signal_count(frame_node)))
                for sig_node in frame_node.children:
                    if isinstance(sig_node.data, SignalRow):
                        sig_node.set_label(self.signal_label(sig_node.data))

    def snapshot_expansion(self) -> None:
        """Record currently-expanded frame keys before a tree rebuild."""
        for ns_node in self.root.children:
            for child in ns_node.children:
                if isinstance(child.data, FrameRow):
                    key = child.data.key
                    if child.is_expanded:
                        self.manually_expanded_frames.add(key)
                    else:
                        self.manually_expanded_frames.discard(key)

    def action_expand_all(self) -> None:
        """Expand every namespace and frame in the tree."""
        self.expand_all_frames = True
        for ns_node in self.root.children:
            ns_node.expand()
            for frame_node in ns_node.children:
                frame_node.expand()

    def action_collapse_all(self) -> None:
        """Collapse every namespace and clear remembered expansions."""
        self.expand_all_frames = False
        self.manually_expanded_frames.clear()
        for ns_node in self.root.children:
            for frame_node in ns_node.children:
                frame_node.collapse()
            ns_node.collapse()

    @staticmethod
    def _build_frame_lookup(rows: list[Row]) -> dict[tuple[str, str], FrameRow]:
        """``(namespace, frame_name) → FrameRow`` lookup in one pass over ``rows``.

        Replaces a per-frame O(n) scan over all rows.  With ~10k rows and
        hundreds of frames the difference is several million comparisons
        per rebuild.
        """
        lookup: dict[tuple[str, str], FrameRow] = {}
        for row in rows:
            if isinstance(row, FrameRow):
                lookup[(row.namespace, row.frame_name)] = row
        return lookup

    async def apply_search_results(
        self,
        filter_str: str,
        rows: list[Row],
        grouped: dict[str, dict[str, list[SignalRow]]],
        empty_hint: str | None = None,
    ) -> None:
        """Rebuild the tree from search results, yielding between namespaces.

        ``filter_str`` doubles as a staleness token: if ``current_filter``
        moves on to a newer search before this one finishes, we abort
        partway through rather than overwrite fresher results.  Caller is
        expected to set ``current_filter`` to ``filter_str`` before kicking
        this off.
        """
        if filter_str != self.current_filter:
            return
        self.empty_hint = empty_hint

        self.snapshot_expansion()
        self.clear()
        self.root.expand()
        self.signals_by_frame.clear()

        if not grouped and filter_str.strip():
            hint = empty_hint or "[dim italic]No matches - try a broader query, or press F1 for help[/dim italic]"
            for line in hint.split("\n"):
                self.root.add_leaf(line)

        frame_lookup = self._build_frame_lookup(rows)
        for ns in sorted(grouped):
            if filter_str != self.current_filter:
                return  # Abort: user typed more, newer search pending.
            frames = grouped[ns]
            ns_signal_count = sum(len(sigs) for sigs in frames.values())
            ns_node = self.root.add(
                self.ns_label(
                    ns,
                    frame_count=len(frames),
                    signal_count=ns_signal_count,
                    state=self._namespace_states.get(ns, LivenessState.UNKNOWN),
                ),
                expand=True,
            )
            for frame_name in sorted(frames):
                frame_row = frame_lookup.get((ns, frame_name)) or FrameRow(namespace=ns, frame_name=frame_name)
                sigs = sorted(frames[frame_name], key=lambda r: r.signal_name)
                self.signals_by_frame[frame_row.key] = sigs
                should_expand = self.expand_all_frames or frame_row.key in self.manually_expanded_frames
                frame_node: TreeNode[Row] = ns_node.add(
                    self.frame_label(frame_row, signal_count=len(sigs)),
                    data=frame_row,
                    expand=False,
                )
                if should_expand:
                    self.populate_frame(frame_node)
                    frame_node.expand()
            # Yield to keep typing responsive during fresh searches.
            await asyncio.sleep(0)

        total_signals = sum(len(sigs) for frames in grouped.values() for sigs in frames.values())
        total_frames = sum(len(frames) for frames in grouped.values())
        self.last_counts = (len(grouped), total_frames, total_signals)
        self.last_visible_rows = list(rows)


class SidebarHandle(ResizeHandle):
    """Thin strip between the sidebar and right pane.

    Click without movement → toggle collapse. Drag horizontally → resize
    the sidebar.
    """

    DEFAULT_CSS = """
    SidebarHandle {
        width: 1;
        height: 1fr;
        content-align: center middle;
        background: $surface;
    }
    SidebarHandle:hover {
        background: $accent;
    }
    """

    MIN_WIDTH = 20
    RIGHT_PADDING = 25
    DRAG_THRESHOLD = 1

    class Clicked(Message):
        """Posted when the handle is clicked without any drag movement.

        The App's ``action_toggle_sidebar`` listens for this so click and
        ``Ctrl+B`` go through the same toggle-plus-focus path.
        """

    def __init__(self, get_target: Callable[[], Widget], **kwargs: Any) -> None:
        super().__init__(
            get_target,
            min_width=self.MIN_WIDTH,
            right_padding=self.RIGHT_PADDING,
            click_threshold=self.DRAG_THRESHOLD,
            **kwargs,
        )

    def toggle(self) -> bool:
        """Flip the target's ``collapsed`` class and update the handle glyph.
        Returns the new collapsed state.
        """
        target = self._get_target()
        target.toggle_class("collapsed")
        collapsed = target.has_class("collapsed")
        # Collapsed: ▶ invites expansion. Open: │ marks the draggable divider.
        self.update("▶" if collapsed else "│")
        return collapsed

    def _should_resize(self) -> bool:
        return not self._get_target().has_class("collapsed")

    def _on_tap(self) -> None:
        # Forward click to the App so it owns the focus-management half of
        # the toggle (the same path ``Ctrl+B`` uses).
        self.post_message(self.Clicked())
