"""Pure-function plan-building for the restbus modal."""

from __future__ import annotations

from collections.abc import Mapping
from dataclasses import dataclass
from typing import NamedTuple

from remotivelabs.broker.restbus import RestbusFrameConfig, RestbusSignalConfig
from remotivelabs.cli.topology.tui.modals.dialog import named_values_for
from remotivelabs.cli.topology.tui.modals.parse import parse_cycle_time, parse_signal_values
from remotivelabs.cli.topology.tui.rows import FrameRow, SignalRow

CellMap = Mapping[tuple[str, str], str]
"""``(row.key, field) -> raw user input``; field is ``cycle`` / ``initial`` / ``loop``."""

ActionMap = Mapping[str, str]
"""``frame.key -> action`` (``start`` / ``stop`` / ``remove``)."""


@dataclass(frozen=True)
class RestbusPlan:
    """Result of `RestbusModal` — already grouped per namespace so the
    App can flush it at the broker without further bookkeeping.

    Frames are split by user-chosen action:

    - ``add_frames``: frames to add and **start** (auto-transmit).
    - ``stop_frames``: frames to add but **leave paused** (registered, not
      transmitting). Useful for staging frames you'll start later.
    - ``remove_frames``: frame names to deregister from the broker.

    ``signals_by_ns`` only applies to ``add_frames`` (started) — paused or
    removed frames don't get signal updates.
    """

    add_frames: dict[str, list[RestbusFrameConfig]]
    stop_frames: dict[str, list[RestbusFrameConfig]]
    remove_frames: dict[str, list[str]]
    signals_by_ns: dict[str, list[RestbusSignalConfig]]

    @property
    def is_empty(self) -> bool:
        return not (self.add_frames or self.stop_frames or self.remove_frames or self.signals_by_ns)


# Per-row submit contributions: typed shapes so `build_plan` dispatches
# by type, not by a tagged-record discriminator.


class FrameAdd(NamedTuple):
    namespace: str
    config: RestbusFrameConfig
    payload: RestbusSignalConfig | None


class FrameStop(NamedTuple):
    namespace: str
    config: RestbusFrameConfig


class FrameRemove(NamedTuple):
    namespace: str
    name: str


class SignalAdd(NamedTuple):
    namespace: str
    config: RestbusSignalConfig
    synth_frame: tuple[str, str]


RowContribution = FrameAdd | FrameStop | FrameRemove | SignalAdd


def frame_action(actions: ActionMap, row: FrameRow) -> str:
    """Action a frame is currently set to; defaults to ``"start"``."""
    return actions.get(row.key, "start")


def frame_cycle_error(row: FrameRow, cells: CellMap) -> str | None:
    """Return an error if the *effective* cycle isn't a positive value.

    Covers the case the parser misses: user left the field blank but
    the frame's own ``cycle_time`` default is 0 — submitting that
    would queue an instant-fire frame on the broker.
    """
    raw = cells.get((row.key, "cycle"), "")
    try:
        parsed = parse_cycle_time(raw)
    except ValueError as exc:
        return str(exc)
    if parsed is None and row.cycle_time is not None and row.cycle_time <= 0:
        return f"frame default is {row.cycle_time:g} ms — set a positive cycle"
    return None


def collect_frame(
    row: FrameRow,
    cells: CellMap,
    *,
    enforce_positive_default: bool,
) -> RestbusFrameConfig:
    """Build a `RestbusFrameConfig` from the frame's cycle cell.

    ``enforce_positive_default=True`` reflects the start path — empty
    input combined with a non-positive frame default is an error.
    """
    if enforce_positive_default:
        err = frame_cycle_error(row, cells)
        if err is not None:
            raise ValueError(f"{row.namespace}:{row.frame_name}: cycle: {err}")
    try:
        cycle = parse_cycle_time(cells.get((row.key, "cycle"), ""))
    except ValueError as exc:
        raise ValueError(f"{row.namespace}:{row.frame_name}: {exc}") from exc
    return RestbusFrameConfig(name=row.frame_name, cycle_time=cycle)


def collect_frame_payload(row: FrameRow, cells: CellMap) -> RestbusSignalConfig | None:
    """Build a same-named `RestbusSignalConfig` from the frame's
    ``initial`` / ``loop`` cells when set.

    The broker treats bytes values keyed by frame name as the frame's
    full payload — that's the mechanism that lets restbus drive a
    frame without per-signal configs. Returns ``None`` when neither
    field is set; raises ``ValueError`` on parse failure or empty
    loop with a set initial.
    """
    loop_raw = cells.get((row.key, "loop"), "")
    initial_raw = cells.get((row.key, "initial"), "")
    if not loop_raw.strip() and not initial_raw.strip():
        return None
    try:
        loop = parse_signal_values(loop_raw, None)
        initial = parse_signal_values(initial_raw, None)
    except ValueError as exc:
        raise ValueError(f"{row.namespace}:{row.frame_name}: {exc}") from exc
    if not loop:
        raise ValueError(f"{row.namespace}:{row.frame_name}: loop must contain at least one value")
    return RestbusSignalConfig(name=row.frame_name, loop=loop, initial=initial)


def collect_signal(row: SignalRow, cells: CellMap) -> RestbusSignalConfig | None:
    """Build a `RestbusSignalConfig` from a signal row's loop / initial
    cells. Returns ``None`` when loop is empty (signal is skipped)."""
    loop_raw = cells.get((row.key, "loop"), "")
    if not loop_raw.strip():
        return None
    nv = named_values_for(row)
    try:
        loop = parse_signal_values(loop_raw, nv)
        initial = parse_signal_values(cells.get((row.key, "initial"), ""), nv)
    except ValueError as exc:
        raise ValueError(f"{row.namespace}:{row.signal_name}: {exc}") from exc
    if not loop:
        raise ValueError(f"{row.namespace}:{row.signal_name}: loop must contain at least one value")
    return RestbusSignalConfig(name=row.signal_name, loop=loop, initial=initial)


def process_frame_row(
    row: FrameRow,
    cells: CellMap,
    actions: ActionMap,
) -> FrameAdd | FrameStop | FrameRemove:
    """Build a typed contribution for a frame row.

    Raises ``ValueError`` on parse failure.
    """
    action = frame_action(actions, row)
    if action == "remove":
        return FrameRemove(namespace=row.namespace, name=row.frame_name)
    config = collect_frame(row, cells, enforce_positive_default=action == "start")
    if action == "stop":
        return FrameStop(namespace=row.namespace, config=config)
    payload = collect_frame_payload(row, cells)
    return FrameAdd(namespace=row.namespace, config=config, payload=payload)


def process_signal_row(
    row: SignalRow,
    cells: CellMap,
    actions: ActionMap,
) -> SignalAdd | None:
    """Build a typed contribution for a signal row, or ``None`` when
    the parent frame isn't being started or the loop is empty."""
    parent_action = actions.get(f"{row.namespace}:{row.frame_name}", "start")
    if parent_action != "start":
        return None
    config = collect_signal(row, cells)
    if config is None:
        return None
    return SignalAdd(
        namespace=row.namespace,
        config=config,
        synth_frame=(row.namespace, row.frame_name),
    )


def build_plan(contributions: list[RowContribution]) -> RestbusPlan:
    """Aggregate per-row contributions into a `RestbusPlan`.

    The dispatch is purely structural — ``isinstance`` per shape — so
    each contribution flows to exactly one bucket. Synthesised frame
    anchors are added at the end for signals whose owning frame wasn't
    listed in either ``add_frames`` or ``stop_frames``.
    """
    add_frames: dict[str, list[RestbusFrameConfig]] = {}
    stop_frames: dict[str, list[RestbusFrameConfig]] = {}
    remove_frames: dict[str, list[str]] = {}
    signals_by_ns: dict[str, list[RestbusSignalConfig]] = {}
    synth_frames: set[tuple[str, str]] = set()
    for c in contributions:
        if isinstance(c, FrameAdd):
            add_frames.setdefault(c.namespace, []).append(c.config)
            if c.payload is not None:
                signals_by_ns.setdefault(c.namespace, []).append(c.payload)
        elif isinstance(c, FrameStop):
            stop_frames.setdefault(c.namespace, []).append(c.config)
        elif isinstance(c, FrameRemove):
            remove_frames.setdefault(c.namespace, []).append(c.name)
        elif isinstance(c, SignalAdd):
            signals_by_ns.setdefault(c.namespace, []).append(c.config)
            synth_frames.add(c.synth_frame)
    existing = {(ns, fc.name) for src in (add_frames, stop_frames) for ns, fcs in src.items() for fc in fcs}
    for ns, fname in synth_frames:
        if (ns, fname) not in existing:
            add_frames.setdefault(ns, []).append(RestbusFrameConfig(name=fname))
    return RestbusPlan(
        add_frames=add_frames,
        stop_frames=stop_frames,
        remove_frames=remove_frames,
        signals_by_ns=signals_by_ns,
    )


__all__ = [
    "ActionMap",
    "CellMap",
    "FrameAdd",
    "FrameRemove",
    "FrameStop",
    "RestbusPlan",
    "RowContribution",
    "SignalAdd",
    "build_plan",
    "collect_frame",
    "collect_frame_payload",
    "collect_signal",
    "frame_action",
    "frame_cycle_error",
    "process_frame_row",
    "process_signal_row",
]
