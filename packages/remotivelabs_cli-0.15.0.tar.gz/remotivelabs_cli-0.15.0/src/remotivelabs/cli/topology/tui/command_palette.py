"""Command-palette provider for the TUI explorer (Ctrl+P)."""

from __future__ import annotations

from collections.abc import Callable

from textual.command import DiscoveryHit, Hits, Provider

from remotivelabs.cli.topology.tui.explore_app import SignalsExplorer


class SearchCommands(Provider):
    """Command-palette provider exposing TUI actions by name (bound to Ctrl+P).

    Every entry corresponds to a keyboard binding documented in the
    search-help panel; the palette is the discovery path for users who
    don't know the shortcuts. Match against the command name AND the
    help text so e.g. typing "reload" finds "Re-index", or "search"
    finds the help toggle.
    """

    @property
    def _explorer(self) -> SignalsExplorer:
        app = self.screen.app
        assert isinstance(app, SignalsExplorer), f"SearchCommands attached to non-explorer app: {type(app).__name__}"
        return app

    def _entries(self) -> list[tuple[str, str, Callable[[], None]]]:
        return [
            ("Search Help", "Toggle search syntax reference panel (F1)", self._explorer.action_toggle_search_help),
            ("Re-index", "Re-read signals from the broker (Ctrl+R)", self._explorer.action_reindex),
            ("Focus search input", "Move keyboard focus to the search box (/)", self._explorer.action_focus_search),
            ("Clear search filter", "Clear the search input and show all signals", self._explorer.action_clear_search_input),
            ("Expand all frames", "Expand every frame node in the tree (e)", self._explorer.signal_tree.action_expand_all),
            ("Collapse all frames", "Collapse every frame node in the tree (c)", self._explorer.signal_tree.action_collapse_all),
            ("Clear marks", "Unmark every marked signal and frame (M)", self._explorer.signal_tree.clear_marks),
            ("Toggle sidebar", "Show or hide the left tree pane (Ctrl+B)", self._explorer.action_toggle_sidebar),
            ("Subscribe selected", "Open a live-view tab for the current selection (s)", self._explorer.action_subscribe),
            ("Publish to selected", "Open a publish modal for the current selection (p)", self._explorer.action_publish),
            ("Publish all visible", "Publish to every row in the current search view (P)", self._explorer.action_publish_visible),
            ("Restbus selected", "Open a restbus modal for the current selection (r)", self._explorer.action_restbus),
            ("Restbus all visible", "Restbus every row in the current search view (R)", self._explorer.action_restbus_visible),
        ]

    async def discover(self) -> Hits:
        for name, help_text, callback in self._entries():
            yield DiscoveryHit(name, callback, help=help_text)

    async def search(self, query: str) -> Hits:
        q = query.lower().strip()
        if not q:
            return
        for name, help_text, callback in self._entries():
            if q in name.lower() or q in help_text.lower():
                yield DiscoveryHit(name, callback, help=help_text)


__all__ = ["SearchCommands"]
