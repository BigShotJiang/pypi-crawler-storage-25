"""Per-namespace liveness tracker for the explore TUI."""

from __future__ import annotations

import time
from collections import deque
from dataclasses import dataclass, field
from enum import Enum

# Broker emits ``FramesDistribution`` every 500 ms; 40 entries =
# 20 seconds of recent activity.
HISTORY_LEN = 40

# Width of one broker ``FramesDistribution`` window. Each ``count`` in
# the stream is "frames seen in the last window" — divide by this to get
# frames-per-second when displaying.
DISTRIBUTION_WINDOW_SECS = 0.5


class LivenessState(str, Enum):
    """Liveness label for a namespace.

    Computed by `NamespaceActivityWatcher.state` from the activity
    tracker's recency vs. the namespace's cycle time. Drives the
    coloured sigil in the tree and the per-namespace block in the
    detail panel.

    - `UNKNOWN` (dim): we have a watcher but no broker emission has
      arrived yet. Initial state for every namespace until the first
      ``FramesDistribution`` window lands (~500 ms). Distinct from
      `STALE` so a fresh-connect doesn't paint the whole tree red
      before any data has had a chance to flow.
    - `LIVE` (green): traffic seen within the recency window. For
      cyclic namespaces the window is roughly one cycle plus a broker-
      side ``FramesDistribution`` flush + grace; for non-cyclic
      namespaces the window is 10 minutes.
    - `QUIET` (yellow): non-cyclic / event-driven namespace with
      traffic on record but nothing in the last 10 minutes. Silence is
      expected for these — just stale enough to mention.
    - `STALE` (red): cyclic namespace whose stream has gone silent
      past the window, *or* any namespace we've subscribed to and
      received empty windows from but no actual traffic. Both warrant
      the same anomaly flag.

    Inherits from ``str`` (rather than 3.11's ``StrEnum``) for Python
    3.10 compatibility — same comparison semantics, no version gating.
    """

    UNKNOWN = "unknown"
    LIVE = "live"
    QUIET = "quiet"
    STALE = "stale"


@dataclass(frozen=True)
class NamespaceSnapshot:
    last_seen_at: float
    # Latest count, regardless of whether it was zero.
    count: int = 0
    history: tuple[int, ...] = ()


@dataclass
class NamespaceActivity:
    _last_seen_at: dict[str, float] = field(default_factory=dict)
    _last_count: dict[str, int] = field(default_factory=dict)
    _histories: dict[str, deque[int]] = field(default_factory=dict)

    def mark(self, ns: str, *, count: int = 0, now: float | None = None) -> None:
        """Record a ``FramesDistribution`` emission for ``ns``."""
        ts = time.monotonic() if now is None else now
        self._histories.setdefault(ns, deque(maxlen=HISTORY_LEN)).append(count)
        self._last_count[ns] = count
        if count > 0:
            self._last_seen_at[ns] = ts

    def snapshot(self, ns: str) -> NamespaceSnapshot | None:
        if ns not in self._last_count:
            return None
        return NamespaceSnapshot(
            last_seen_at=self._last_seen_at.get(ns, 0.0),
            count=self._last_count[ns],
            history=tuple(self._histories.get(ns, ())),
        )

    def is_active(self, ns: str, *, now: float | None = None, window_secs: float = 1.0) -> bool:
        seen = self._last_seen_at.get(ns)
        if seen is None:
            return False
        current = time.monotonic() if now is None else now
        return current - seen < window_secs

    def has_traffic(self, ns: str) -> bool:
        """``True`` once a non-zero count has been recorded for ``ns``"""
        return ns in self._last_seen_at

    def active_set(self, *, now: float | None = None, window_secs: float = 1.0) -> frozenset[str]:
        current = time.monotonic() if now is None else now
        return frozenset(ns for ns, seen in self._last_seen_at.items() if current - seen < window_secs)

    def clear(self) -> None:
        """Drop all per-namespace history"""
        self._last_seen_at.clear()
        self._last_count.clear()
        self._histories.clear()
