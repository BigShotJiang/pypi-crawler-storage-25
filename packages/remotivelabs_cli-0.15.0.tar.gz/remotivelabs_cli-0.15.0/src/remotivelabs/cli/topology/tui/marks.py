"""Mark state for the TUI explorer — pure data, no rendering."""

from __future__ import annotations

from dataclasses import dataclass, field

from remotivelabs.cli.topology.tui.rows import FrameRow, Row, SignalRow


@dataclass
class MarkRegistry:
    """Tracks signals and frames the user has flagged for batch operations
    (subscribe, publish).  Pure data — does not touch the tree.  Callers
    that mutate marks are responsible for refreshing the affected tree
    labels themselves.
    """

    signals: dict[str, SignalRow] = field(default_factory=dict)
    frames: dict[str, FrameRow] = field(default_factory=dict)

    @property
    def total(self) -> int:
        return len(self.signals) + len(self.frames)

    @property
    def is_empty(self) -> bool:
        return not self.signals and not self.frames

    def all_rows(self) -> list[Row]:
        """Marked signals followed by marked frames (publish/subscribe order)."""
        return [*self.signals.values(), *self.frames.values()]

    def has_signal(self, key: str) -> bool:
        return key in self.signals

    def has_frame(self, key: str) -> bool:
        return key in self.frames

    def has_marks_in_namespace(self, ns: str) -> bool:
        prefix = f"{ns}:"
        return any(k.startswith(prefix) for k in self.frames) or any(k.startswith(prefix) for k in self.signals)

    def set_signal(self, row: SignalRow, marked: bool) -> None:
        if marked:
            self.signals[row.key] = row
        else:
            self.signals.pop(row.key, None)

    def toggle_signal(self, row: SignalRow) -> bool:
        """Flip the mark on ``row``.  Returns the new state."""
        marked = row.key not in self.signals
        self.set_signal(row, marked)
        return marked

    def set_frame(self, row: FrameRow, marked: bool, owned_signals: list[SignalRow]) -> None:
        """Mark or unmark a frame and propagate to its owned signals.

        ``owned_signals`` is passed in (not derived from ``row``) because the
        caller — the App — caches signal rows per frame in a structure the
        registry doesn't see.
        """
        if marked:
            self.frames[row.key] = row
        else:
            self.frames.pop(row.key, None)
        for sig in owned_signals:
            self.set_signal(sig, marked)

    def clear(self) -> None:
        self.signals.clear()
        self.frames.clear()
