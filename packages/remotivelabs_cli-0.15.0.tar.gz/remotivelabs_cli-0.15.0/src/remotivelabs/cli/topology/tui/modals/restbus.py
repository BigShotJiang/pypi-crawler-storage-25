"""Restbus modal — configure + start restbus on marked frames/signals."""

from __future__ import annotations

from collections.abc import Callable, Mapping
from typing import Any

from rich.markup import escape as rich_escape
from textual import events
from textual.app import ComposeResult
from textual.binding import Binding
from textual.containers import Horizontal, Vertical
from textual.screen import ModalScreen
from textual.widgets import Input, Static, Tree
from textual.widgets.tree import TreeNode

from remotivelabs.cli.topology.tui.bindings import arrow_nav_bindings
from remotivelabs.cli.topology.tui.modals.dialog import (
    ACTION_COLOR,
    ACTION_GLYPH,
    DIALOG_CSS,
    ensure_frame_anchors,
    find_next_error_key,
    group_rows,
    iter_descendants,
    named_values_for,
    next_frame_action,
    populate_dialog_tree,
    refresh_row_label,
    set_dialog_error,
    validate_field,
)
from remotivelabs.cli.topology.tui.modals.parse import SIGNAL_VALUE_PLACEHOLDER, parse_cycle_time, parse_signal_values
from remotivelabs.cli.topology.tui.modals.restbus_plan import (
    RestbusPlan,
    RowContribution,
    build_plan,
    frame_action,
    frame_cycle_error,
    process_frame_row,
    process_signal_row,
)
from remotivelabs.cli.topology.tui.rows import FrameRow, Row, SignalRow
from remotivelabs.cli.topology.tui.widgets.detail import format_detail


class RestbusModal(ModalScreen[RestbusPlan | None]):
    """Configure + start restbus on the marked frames/signals."""

    CSS = "RestbusModal { align: center middle; }" + DIALOG_CSS

    BINDINGS = [
        Binding("escape", "cancel", "Cancel", show=False, priority=True),
        *arrow_nav_bindings("nav_down", "nav_up", priority=True),
        Binding("ctrl+s", "submit", "Submit"),
        # priority=True so Inputs in the edit strip don't swallow Ctrl+A as a selection shortcut.
        Binding("ctrl+a", "cycle_action", "Cycle action", priority=True),
        Binding("ctrl+e", "goto_next_error", "Next error", priority=True),
    ]

    def __init__(self, rows: list[Row]) -> None:
        super().__init__()
        self._rows = ensure_frame_anchors(rows)
        self._cells: dict[tuple[str, str], str] = {}
        self._frame_actions: dict[str, str] = {}
        self._errors: dict[str, str] = {}
        self._tree_nodes: dict[str, TreeNode[Row | None]] = {}
        self._current_row: Row | None = None
        self._signals_by_frame: dict[str, list[SignalRow]] = {}
        self._frames_by_namespace: dict[str, list[FrameRow]] = {}
        for r in self._rows:
            if isinstance(r, FrameRow):
                self._frames_by_namespace.setdefault(r.namespace, []).append(r)
            elif isinstance(r, SignalRow):
                self._signals_by_frame.setdefault(f"{r.namespace}:{r.frame_name}", []).append(r)

    def compose(self) -> ComposeResult:
        with Vertical(id="dialog"):
            yield Static(f"[bold]Configure restbus[/bold] — {len(self._rows)} row(s)")
            with Horizontal(id="dialog-body"):
                yield Tree[Row | None]("Selection", id="dialog-tree")
                yield Static("", id="dialog-detail", markup=True)
            yield Static("[dim](navigate to a row)[/dim]", id="edit-context")
            with Horizontal(id="edit-strip"):
                yield Input(placeholder="cycle ms (optional)", id="edit-cycle", select_on_focus=False)
                yield Input(id="edit-initial", select_on_focus=False)
                yield Input(id="edit-loop", select_on_focus=False)
            yield Static("", id="dialog-error")
            yield Static(
                "[dim]↑↓ navigate · Space expand/collapse · type to edit · "
                "Tab next field · Enter next row · Ctrl+a cycle action · Ctrl+e next error · Ctrl+s submit · Esc back/cancel[/dim]",
                classes="modal-help",
            )

    def on_mount(self) -> None:
        tree = self.query_one(Tree)
        tree.show_root = False
        tree.guide_depth = 3
        populate_dialog_tree(tree, group_rows(self._rows), self._frame_label, self._signal_label, self._tree_nodes)
        first_editable = next(
            (node for ns_node in tree.root.children for node in iter_descendants(ns_node) if node.data is not None),
            None,
        )
        if first_editable is not None:
            self.call_after_refresh(tree.move_cursor, first_editable)
        tree.focus()

    def _frame_action(self, row: FrameRow) -> str:
        return frame_action(self._frame_actions, row)

    def _frame_label(self, row: FrameRow) -> str:
        action = self._frame_action(row)
        glyph = ACTION_GLYPH[action]
        color = ACTION_COLOR[action]
        prefix = f"[{color}]{glyph} {action}[/{color}]"
        frame_name = rich_escape(row.frame_name)
        if action != "start":
            return f"{prefix}  [yellow]{frame_name}[/yellow]"
        cycle = self._cells.get((row.key, "cycle"), "").strip()
        if cycle:
            cycle_part = f"[bold]cycle:[/bold] {rich_escape(cycle)} ms"
        elif row.cycle_time is not None and row.cycle_time <= 0:
            cycle_part = f"[red]cycle: {row.cycle_time:g} ms (set a positive value)[/red]"
        elif row.cycle_time is not None:
            cycle_part = f"[dim]cycle: {row.cycle_time:g} ms (default)[/dim]"
        else:
            cycle_part = "[dim]cycle: broker default[/dim]"
        parts = [f"[yellow]{frame_name}[/yellow]", cycle_part]
        loop = self._cells.get((row.key, "loop"), "").strip()
        initial = self._cells.get((row.key, "initial"), "").strip()
        if loop:
            parts.append(f"[bold]loop:[/bold] {rich_escape(loop)}")
        if initial:
            parts.append(f"[bold]init:[/bold] {rich_escape(initial)}")
        return f"{prefix}  " + "  ".join(parts)

    def _signal_label(self, row: SignalRow) -> str:
        parent_action = self._frame_actions.get(f"{row.namespace}:{row.frame_name}", "start")
        signal_name = rich_escape(row.signal_name)
        if parent_action != "start":
            return f"[dim]{signal_name}[/dim]  [dim]({parent_action})[/dim]"
        loop = self._cells.get((row.key, "loop"), "").strip()
        initial = self._cells.get((row.key, "initial"), "").strip()
        parts: list[str] = [f"[bold]loop:[/bold] {rich_escape(loop)}" if loop else "[dim]loop: …[/dim]"]
        if initial:
            parts.append(f"[bold]init:[/bold] {rich_escape(initial)}")
        return f"[green]{signal_name}[/green]  " + "  ".join(parts)

    def _refresh_label(self, row: Row) -> None:
        refresh_row_label(row, self._tree_nodes, self._frame_label, self._signal_label)

    def _inputs(self) -> tuple[Input, Input, Input]:
        return (
            self.query_one("#edit-cycle", Input),
            self.query_one("#edit-initial", Input),
            self.query_one("#edit-loop", Input),
        )

    def _save_current(self) -> None:
        if self._current_row is None:
            return
        cycle, initial, loop = self._inputs()
        if isinstance(self._current_row, FrameRow):
            self._cells[(self._current_row.key, "cycle")] = cycle.value
            self._cells[(self._current_row.key, "initial")] = initial.value
            self._cells[(self._current_row.key, "loop")] = loop.value
        elif isinstance(self._current_row, SignalRow):
            self._cells[(self._current_row.key, "initial")] = initial.value
            self._cells[(self._current_row.key, "loop")] = loop.value
        self._refresh_label(self._current_row)

    @staticmethod
    def _set_input(widget: Input, *, value: str, placeholder: str | None = None) -> None:
        widget.display = True
        if placeholder is not None:
            widget.placeholder = placeholder
        widget.value = value
        widget.cursor_position = len(value)

    def _hide_inputs(self) -> None:
        cycle, initial, loop = self._inputs()
        cycle.display = False
        initial.display = False
        loop.display = False

    def _switch_to(self, row: Row | None) -> None:
        self._current_row = row
        ctx_widget = self.query_one("#edit-context", Static)
        detail_widget = self.query_one("#dialog-detail", Static)
        if row is None:
            ctx_widget.update("[dim](navigate to a row)[/dim]")
            detail_widget.update("")
            self._hide_inputs()
            self._validate_inputs()
            return
        detail_widget.update(format_detail(row))
        if isinstance(row, FrameRow):
            self._switch_to_frame(row, ctx_widget)
        else:
            assert isinstance(row, SignalRow)
            self._switch_to_signal(row, ctx_widget)
        self._validate_inputs()

    def _switch_to_frame(self, row: FrameRow, ctx_widget: Static) -> None:
        action = self._frame_action(row)
        color = ACTION_COLOR[action]
        action_chip = f"[{color}]\\[{action}][/{color}]  [dim](press Ctrl+a to cycle)[/dim]"
        ns = rich_escape(row.namespace)
        frame_name = rich_escape(row.frame_name)
        if action != "start":
            hint = "frame removed — no config" if action == "remove" else "frame stopped — cycle won't be sent"
            ctx_widget.update(f"[bold]{ns}[/bold] · [yellow]{frame_name}[/yellow]  {action_chip}  [dim]({hint})[/dim]")
            self._hide_inputs()
            return
        metadata_hint = "  [dim](frame metadata not in index)[/dim]" if row.payload_size is None else ""
        ctx_widget.update(f"[bold]{ns}[/bold] · [yellow]{frame_name}[/yellow]  {action_chip}  · cycle ms · initial · loop{metadata_hint}")
        cycle, initial, loop = self._inputs()
        self._set_input(cycle, value=self._cells.get((row.key, "cycle"), ""))
        payload_hint = "hex bytes (e.g. 0xDEAD or DE AD BE EF)"
        self._set_input(initial, value=self._cells.get((row.key, "initial"), ""), placeholder=f"initial (optional)  {payload_hint}")
        self._set_input(loop, value=self._cells.get((row.key, "loop"), ""), placeholder=f"loop  {payload_hint}")

    def _switch_to_signal(self, row: SignalRow, ctx_widget: Static) -> None:
        parent_action = self._frame_actions.get(f"{row.namespace}:{row.frame_name}", "start")
        ns = rich_escape(row.namespace)
        frame_name = rich_escape(row.frame_name)
        signal_name = rich_escape(row.signal_name)
        if parent_action != "start":
            ctx_widget.update(
                f"[bold]{ns}[/bold] · [yellow]{frame_name}[/yellow] · [green]{signal_name}[/green]  "
                f"[dim](frame {parent_action} — signal values won't be sent)[/dim]"
            )
            self._hide_inputs()
            return
        ctx_widget.update(f"[bold]{ns}[/bold] · [yellow]{frame_name}[/yellow] · [green]{signal_name}[/green]  ·  initial · loop")
        cycle, initial, loop = self._inputs()
        cycle.display = False
        self._set_input(
            initial,
            value=self._cells.get((row.key, "initial"), ""),
            placeholder=f"initial (optional)  {SIGNAL_VALUE_PLACEHOLDER}",
        )
        self._set_input(
            loop,
            value=self._cells.get((row.key, "loop"), ""),
            placeholder=f"loop  {SIGNAL_VALUE_PLACEHOLDER}",
        )

    def on_tree_node_highlighted(self, event: Tree.NodeHighlighted[Row | None]) -> None:
        self._save_current()
        self._switch_to(event.node.data)

    def on_input_changed(self, event: Input.Changed) -> None:
        if self._current_row is None:
            return
        field = {"edit-cycle": "cycle", "edit-initial": "initial", "edit-loop": "loop"}.get(event.input.id or "")
        if field is None:
            return
        self._cells[(self._current_row.key, field)] = event.value
        self._refresh_label(self._current_row)
        self._validate_inputs()

    def _validate_inputs(self) -> bool:
        """Validate every visible input. Returns True if all are OK (or empty)."""
        nv = named_values_for(self._current_row) if self._current_row is not None else None
        cycle_w, initial_w, loop_w = self._inputs()

        def signal_parser(raw: str) -> None:
            parse_signal_values(raw, nv)

        fields: tuple[tuple[str, Input, Callable[[str], object]], ...] = (
            ("cycle", cycle_w, parse_cycle_time),
            ("initial", initial_w, signal_parser),
            ("loop", loop_w, signal_parser),
        )

        first_error: str | None = None
        for label, widget, parser in fields:
            err = validate_field(widget, parser, skip_when_hidden=True)
            if err is not None and first_error is None:
                first_error = f"{label}: {err}"

        # validate_field skips empty inputs as "user mid-edit," but here
        # the fallback default is invalid so the empty value is a final answer.
        if (
            isinstance(self._current_row, FrameRow)
            and self._frame_action(self._current_row) == "start"
            and cycle_w.display
            and not cycle_w.value.strip()
        ):
            err = frame_cycle_error(self._current_row, self._cells)
            if err is not None:
                cycle_w.add_class("invalid")
                if first_error is None:
                    first_error = f"cycle: {err}"

        set_dialog_error(self.query_one("#dialog-error", Static), first_error)
        if self._current_row is not None:
            if first_error is None:
                self._errors.pop(self._current_row.key, None)
            else:
                self._errors[self._current_row.key] = first_error
        return first_error is None

    def _value_fields_error(self, row_key: str, named_values: Mapping[str, Any] | None) -> str | None:
        for field in ("initial", "loop"):
            raw = self._cells.get((row_key, field), "")
            if not raw.strip():
                continue
            try:
                parse_signal_values(raw, named_values)
            except ValueError as exc:
                return f"{field}: {exc}"
        return None

    def _row_error(self, row: Row) -> str | None:
        if isinstance(row, FrameRow):
            if self._frame_action(row) != "start":
                return None
            cycle_err = frame_cycle_error(row, self._cells)
            if cycle_err is not None:
                return f"cycle: {cycle_err}"
            return self._value_fields_error(row.key, None)
        if isinstance(row, SignalRow):
            return self._value_fields_error(row.key, named_values_for(row))
        return None

    def _validate_all(self) -> None:
        self._errors.clear()
        for row in self._rows:
            err = self._row_error(row)
            if err is not None:
                self._errors[row.key] = err

    def _rows_in_display_order(self) -> list[Row]:
        tree = self.query_one(Tree)
        return [node.data for ns_node in tree.root.children for node in iter_descendants(ns_node) if node.data is not None]

    def action_goto_next_error(self) -> None:
        """Move the tree cursor to the next row with a validation error."""
        self._save_current()
        self._validate_all()
        if not self._errors:
            self.notify("No errors", severity="information")
            return
        current_key = self._current_row.key if self._current_row else None
        target_key = find_next_error_key(self._rows_in_display_order(), self._errors, current_key)
        if target_key is None:
            return
        target = self._tree_nodes.get(target_key)
        if target is not None:
            self.query_one(Tree).move_cursor(target)

    def on_input_submitted(self, event: Input.Submitted) -> None:
        del event
        tree = self.query_one(Tree)
        tree.action_cursor_down()
        node = tree.cursor_node
        if node is not None and node.data is not None:
            self._switch_to(node.data)
            primary = self._primary_input()
            if primary is not None and primary.display:
                primary.focus()

    def _primary_input(self) -> Input | None:
        if isinstance(self._current_row, FrameRow):
            return self.query_one("#edit-cycle", Input)
        if isinstance(self._current_row, SignalRow):
            return self.query_one("#edit-loop", Input)
        return None

    def on_key(self, event: events.Key) -> None:
        if self.focused is not self.query_one(Tree):
            return
        if event.key in ("space", "tab", "shift+tab"):
            return
        if event.character is None or not event.character.isprintable():
            return
        primary = self._primary_input()
        if primary is None or not primary.display:
            return
        primary.focus()
        primary.insert_text_at_cursor(event.character)
        event.prevent_default()
        event.stop()

    def _frame_for_current(self) -> FrameRow | None:
        row = self._current_row
        if isinstance(row, FrameRow):
            return row
        if isinstance(row, SignalRow):
            for candidate in self._frames_by_namespace.get(row.namespace, ()):
                if candidate.frame_name == row.frame_name:
                    return candidate
            return None
        return None

    def action_cycle_action(self) -> None:
        target = self._frame_for_current()
        if target is not None:
            self._cycle_frame_action(target)
            return
        ns = self._namespace_for_current()
        if ns is not None:
            self._cycle_namespace_action(ns)

    def _namespace_for_current(self) -> str | None:
        tree = self.query_one(Tree)
        node = tree.cursor_node
        if node is None or node.data is not None or node.parent is not tree.root:
            return None
        for child in node.children:
            if isinstance(child.data, FrameRow):
                return child.data.namespace
        return None

    def _cycle_namespace_action(self, ns: str) -> None:
        # Pick the next action from the first frame's current state so a
        # bulk-toggle leaves all frames in the same state, not staggered.
        frames = self._frames_by_namespace.get(ns, [])
        if not frames:
            return
        next_action = next_frame_action(self._frame_action(frames[0]))
        for frame in frames:
            self._frame_actions[frame.key] = next_action
            self._refresh_label(frame)
            for sig in self._signals_by_frame.get(frame.key, ()):
                self._refresh_label(sig)
            node = self._tree_nodes.get(frame.key)
            if node is not None and next_action != "start":
                node.collapse()

    def _cycle_frame_action(self, row: FrameRow) -> None:
        new = next_frame_action(self._frame_action(row))
        self._frame_actions[row.key] = new
        self._refresh_label(row)
        for sig in self._signals_by_frame.get(row.key, ()):
            self._refresh_label(sig)
        frame_node = self._tree_nodes.get(row.key)
        cur = self._current_row
        cursor_on_child = isinstance(cur, SignalRow) and cur.namespace == row.namespace and cur.frame_name == row.frame_name
        if frame_node is not None and new != "start":
            if cursor_on_child:
                # Move cursor up before collapsing so focus doesn't fall onto a now-hidden node.
                self.query_one(Tree).move_cursor(frame_node)
                cur = row
            frame_node.collapse()
        if cur is row:
            self._switch_to(row)
        elif cursor_on_child:
            self._switch_to(cur)

    def action_nav_up(self) -> None:
        self.query_one(Tree).action_cursor_up()

    def action_nav_down(self) -> None:
        self.query_one(Tree).action_cursor_down()

    def action_submit(self) -> None:
        self._save_current()
        error_widget = self.query_one("#dialog-error", Static)
        contributions: list[RowContribution] = []
        try:
            for row in self._rows:
                if isinstance(row, FrameRow):
                    contributions.append(process_frame_row(row, self._cells, self._frame_actions))
                elif isinstance(row, SignalRow):
                    signal = process_signal_row(row, self._cells, self._frame_actions)
                    if signal is not None:
                        contributions.append(signal)
        except ValueError as exc:
            set_dialog_error(error_widget, str(exc))
            return

        plan = build_plan(contributions)
        if plan.is_empty:
            set_dialog_error(error_widget, "Nothing to do — set a loop, a cycle, or pick stop / remove on a frame")
            return
        self.dismiss(plan)

    def action_cancel(self) -> None:
        if isinstance(self.focused, Input):
            self._save_current()
            self.query_one(Tree).focus()
            return
        self.dismiss(None)
