import asyncio
import os
import subprocess

import typer

from remotivelabs.cli.topology.cli.run_in_container import (
    run_subprocess_async,
    run_topology_cli_in_container_async,
)
from remotivelabs.cli.topology.context import TopologyContext


def _extract_marked_output(text: str | None) -> str | None:
    if not text:
        return text

    start_marker = "---BEGIN REMOTIVE STUDIO OUTPUT---"
    end_marker = "---END REMOTIVE STUDIO OUTPUT---"

    start_idx = text.find(start_marker)
    end_idx = text.find(end_marker)

    if start_idx == -1 or end_idx == -1:
        return text

    start_idx += len(start_marker)
    return text[start_idx:end_idx].strip()


def run_topology_cli(ctx: typer.Context, args: list[str]) -> None:
    try:
        asyncio.run(run_topology_async(ctx.obj["topology"], args, capture_output=False, timeout=None))
    except subprocess.CalledProcessError as e:
        raise typer.Exit(code=e.returncode)


async def run_topology_async(
    ctx: TopologyContext,
    args: list[str],
    capture_output: bool = True,
    lock: asyncio.Lock | None = None,
    timeout: float | None = 120.0,
) -> subprocess.CompletedProcess[str]:
    """Run the remotive-topology CLI from an event loop.

    Pass ``lock`` when the calling process also has gRPC channels open (the
    studio server) — it serialises fork+exec against in-flight RPCs to avoid
    the gRPC C-core fork-handler race. ``timeout`` caps how long the child may
    run before it is killed; callers map ``subprocess.TimeoutExpired`` to
    HTTP 504. Pass ``None`` for long-running CLI commands.
    """
    if ctx.cmd is None:
        result = await run_topology_cli_in_container_async(ctx, args, capture_output=capture_output, lock=lock, timeout=timeout)
        if capture_output:
            result.stdout = _extract_marked_output(result.stdout) or ""
            result.stderr = _extract_marked_output(result.stderr) or ""
        return result
    cmd = [ctx.cmd] + args
    if ctx.workspace is not None:
        os.putenv("REMOTIVE_TOPOLOGY_WORKSPACE", str(ctx.workspace))
    if ctx.is_studio:
        os.putenv("REMOTIVE_STUDIO", "true")
    os.putenv("REMOTIVE_TOPOLOGY_WORKING_DIRECTORY", str(ctx.working_directory))
    try:
        result = await run_subprocess_async(cmd, capture_output=capture_output, lock=lock, timeout=timeout)
    except subprocess.CalledProcessError as e:
        if capture_output:
            e.stderr = _extract_marked_output(e.stderr)
        raise

    if capture_output:
        result.stdout = _extract_marked_output(result.stdout) or ""

    return result
