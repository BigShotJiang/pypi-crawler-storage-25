"""
Delegate all arguments to the remotive-topology CLI inside Docker.
Example:
  remotive topology status --help
"""

import asyncio
import logging
import os
import shlex
import shutil
import subprocess
import sys
from datetime import datetime

import typer
from rich.progress import Progress, SpinnerColumn, TextColumn

from remotivelabs.cli.settings import settings
from remotivelabs.cli.topology.context import TopologyContext

logger = logging.getLogger(__name__)

# Hard cap on a single topology subprocess. Long enough for ``convert`` on
# large YAML, short enough that a wedged child cannot pin a server slot forever.
_DEFAULT_SUBPROCESS_TIMEOUT = 120.0
# ``docker pull`` over a slow link can legitimately take minutes.
_DEFAULT_PULL_TIMEOUT = 600.0


def check_container_engine_installed(engine: str) -> None:
    """Check if Docker is installed and accessible."""

    if shutil.which(engine) is None:
        if engine == "docker":
            typer.echo("❌ 'docker' is not installed or not in PATH.", err=True)
            typer.echo("👉 Please install Docker: https://docs.docker.com/get-docker/", err=True)
        elif engine == "podman":
            typer.echo("❌ 'podman' is not installed or not in PATH.", err=True)
            typer.echo("👉 Please install Podman: https://podman.io/getting-started/installation", err=True)
        raise typer.Exit(code=1)


def _build_pull_command(engine: str, image: str) -> list[str]:
    return [engine, "pull", "-q", image]


def _build_run_command(ctx: TopologyContext, image: str, args: list[str]) -> list[str]:
    container_engine = ctx.container_engine.value
    check_container_engine_installed(container_engine)

    workspace = str(ctx.workspace or ctx.working_directory)
    container_workspace = "/data" if sys.platform == "win32" else workspace

    # Pass the workspace path into the container via env var when explicitly set
    workspace_env = ["-e", f"REMOTIVE_TOPOLOGY_WORKSPACE={ctx.workspace}"] if ctx.workspace is not None else []
    workspace_dir_env = ["-e", f"REMOTIVE_TOPOLOGY_WORKING_DIRECTORY={str(ctx.working_directory)}"]

    cmd = [container_engine, "run", "--rm"]

    if container_engine == "podman":
        # Rootless podman maps container root → host user automatically, so we
        # skip -u / --userns. -it gives stdin + a TTY for interactive prompts.
        cmd += ["-it"]
    elif hasattr(os, "getuid") and hasattr(os, "getgid"):
        # Docker has no rootless user remapping, so map the host user explicitly
        # to keep ownership of files written to mounted volumes.
        cmd += ["-u", f"{os.getuid()}:{os.getgid()}"]  # type: ignore[unused-ignore, attr-defined]

    # On SELinux hosts, podman bind mounts are inaccessible to the container
    # unless relabeled. ":z" applies a shared label so the host can still read
    # the directory afterwards (":Z" would relabel it private).
    mount_suffix = ":z" if container_engine == "podman" else ""
    cmd += [
        "-v",
        f"{os.path.expanduser('~')}/.config/remotive/:/.config/remotive{mount_suffix}",
        "-v",
        f"{workspace}:{container_workspace}{mount_suffix}",
        "-w",
        container_workspace,
    ]
    for key, value in os.environ.items():
        if key.startswith("REMOTIVE_") and value:
            cmd += ["-e", f"{key}={value}"]
    for key in ("HTTP_PROXY", "HTTPS_PROXY", "http_proxy", "https_proxy"):
        proxy_value = os.environ.get(key)
        if proxy_value:
            cmd += ["-e", f"{key}={proxy_value}"]

    cmd += workspace_env
    cmd += workspace_dir_env
    cmd += ["-e", "REMOTIVE_CONFIG_DIR=/.config/remotive"]
    # Keep the topology binary's cache inside the bind-mounted workspace
    # so it persists to the host filesystem. By default the binary writes
    # to `$HOME/.cache/remotive`, but inside the container `$HOME` is
    # not mounted, so the cache would be discarded on container exit.
    # This is a transitional workaround until the topology binary is
    # bundled directly with the CLI (no container hop).
    cmd += ["-e", f"REMOTIVE_CACHE_DIR={container_workspace}/.remotive/cache"]
    if ctx.is_studio:
        cmd += ["-e", "REMOTIVE_STUDIO=true"]
    cmd += [image] + args
    return cmd


async def run_subprocess_async(
    cmd: list[str],
    capture_output: bool,
    lock: asyncio.Lock | None,
    timeout: float | None = _DEFAULT_SUBPROCESS_TIMEOUT,
) -> subprocess.CompletedProcess[str]:
    """Async equivalent of ``subprocess.run(..., check=True, capture_output=capture_output, text=capture_output)``.

    The fork+exec itself happens inside ``lock`` (when supplied) so a concurrent
    gRPC call cannot be mid-flight when the parent forks — that race is what
    trips gRPC C-core's fork handler and can deadlock the studio process.
    The lock is released as soon as ``create_subprocess_exec`` returns; reading
    the child's pipes via ``communicate`` runs without holding it.

    A wedged child is killed after ``timeout`` seconds and ``TimeoutExpired`` is
    raised. Pass ``None`` to disable (CLI/long-running callers only).
    """
    stdout = asyncio.subprocess.PIPE if capture_output else None
    stderr = asyncio.subprocess.PIPE if capture_output else None

    if lock is not None:
        async with lock:
            proc = await asyncio.create_subprocess_exec(*cmd, stdout=stdout, stderr=stderr)
    else:
        proc = await asyncio.create_subprocess_exec(*cmd, stdout=stdout, stderr=stderr)

    try:
        stdout_data, stderr_data = await asyncio.wait_for(proc.communicate(), timeout=timeout)
    except asyncio.TimeoutError as exc:
        proc.kill()
        await proc.wait()
        logger.warning("subprocess timed out after %ss: %r", timeout, cmd)
        raise subprocess.TimeoutExpired(cmd, timeout if timeout is not None else 0) from exc

    returncode = proc.returncode if proc.returncode is not None else 0

    if capture_output:
        out = stdout_data.decode("utf-8", errors="replace") if stdout_data else ""
        err = stderr_data.decode("utf-8", errors="replace") if stderr_data else ""
        result: subprocess.CompletedProcess[str] = subprocess.CompletedProcess(cmd, returncode, out, err)
    else:
        result = subprocess.CompletedProcess(cmd, returncode)

    if returncode != 0:
        logger.warning("subprocess failed: rc=%s cmd=%r", returncode, cmd)
        raise subprocess.CalledProcessError(returncode, cmd, output=result.stdout, stderr=result.stderr)

    return result


async def _run_with_delayed_spinner_async(
    cmd: list[str],
    message: str,
    lock: asyncio.Lock | None,
    delay_seconds: float = 2.0,
    timeout: float | None = _DEFAULT_PULL_TIMEOUT,
) -> None:
    """Run a command with a spinner that only appears after ``delay_seconds``.

    The fork+exec runs under ``lock`` (see ``run_subprocess_async``). The
    spinner timer is an ``asyncio.Task``.
    """
    if lock is not None:
        async with lock:
            proc = await asyncio.create_subprocess_exec(*cmd, stdout=asyncio.subprocess.DEVNULL, stderr=asyncio.subprocess.PIPE)
    else:
        proc = await asyncio.create_subprocess_exec(*cmd, stdout=asyncio.subprocess.DEVNULL, stderr=asyncio.subprocess.PIPE)

    spinner = Progress(SpinnerColumn(), TextColumn("[progress.description]{task.description}"), transient=True)
    spinner_shown = False

    async def show_spinner_after_delay() -> None:
        nonlocal spinner_shown
        await asyncio.sleep(delay_seconds)
        if proc.returncode is None:
            try:
                spinner.start()
                spinner_shown = True
                spinner.add_task(message, total=None)
            except Exception:
                pass  # Another live display is already active; skip spinner

    spinner_task = asyncio.create_task(show_spinner_after_delay())
    try:
        try:
            _, stderr_data = await asyncio.wait_for(proc.communicate(), timeout=timeout)
        except asyncio.TimeoutError as exc:
            proc.kill()
            await proc.wait()
            logger.warning("container pull timed out after %ss: %r", timeout, cmd)
            raise subprocess.TimeoutExpired(cmd, timeout if timeout is not None else 0) from exc
    finally:
        spinner_task.cancel()
        try:
            await spinner_task
        except asyncio.CancelledError:
            pass
        if spinner_shown:
            spinner.stop()

    if stderr_data:
        sys.stderr.buffer.write(stderr_data)

    if proc.returncode != 0:
        raise subprocess.CalledProcessError(proc.returncode or 0, cmd)


async def run_topology_cli_in_container_async(
    ctx: TopologyContext,
    args: list[str],
    capture_output: bool,
    lock: asyncio.Lock | None = None,
    timeout: float | None = _DEFAULT_SUBPROCESS_TIMEOUT,
) -> subprocess.CompletedProcess[str]:
    """Run the topology CLI inside a container.

    See ``run_subprocess_async`` for the role of ``lock``. Callers that share
    a process with active gRPC channels (the studio server) should pass one.

    The spinner only appears when the pull actually takes time (i.e. a real
    download). Since the pull check may take a few seconds this can be a bit
    annoying, only do it once every 30 minutes.
    """
    container_engine = ctx.container_engine.value
    check_container_engine_installed(container_engine)

    _default_image = "remotivelabs/remotive-topology:0.25"
    image = ctx.image or _default_image
    if ctx.container_registry:
        image = f"{ctx.container_registry.rstrip('/')}/{image}"

    pull_cmd = _build_pull_command(container_engine, image)
    run_cmd = _build_run_command(ctx, image, args)

    if os.environ.get("DBG") == "true":
        typer.echo(f"[DBG] {shlex.join(run_cmd)}", err=True)

    try:
        if settings.should_perform_topology_pull():
            await _run_with_delayed_spinner_async(pull_cmd, "Checking for updates...", lock)
            settings.set_last_topology_pull_time(datetime.now().isoformat())

        return await run_subprocess_async(run_cmd, capture_output=capture_output, lock=lock, timeout=timeout)
    except FileNotFoundError:
        typer.echo(f"❌ {container_engine} not found. Make sure {container_engine} is installed and in PATH.", err=True)
        raise typer.Exit(code=1)
