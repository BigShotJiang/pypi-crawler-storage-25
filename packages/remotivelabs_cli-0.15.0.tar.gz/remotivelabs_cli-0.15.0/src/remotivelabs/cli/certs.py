from __future__ import annotations

import os
from dataclasses import dataclass
from pathlib import Path
from urllib.parse import urlparse

import certifi
import trustme

from remotivelabs.cli.utils.file_io import mkdir_p, write_text_restrictive

_RESTRICTIVE_DIR_MODE = 0o700

CA_CERT_NAME = "ca.pem"
SERVER_CERT_NAME = "server.pem"
SERVER_KEY_NAME = "server-key.pem"
FULL_CHAIN_NAME = "full-chain.pem"
_TRUST_BUNDLE_NAME = "grpc-trust-bundle.pem"


@dataclass(frozen=True)
class CertPaths:
    ca_cert: Path
    server_cert: Path
    server_key: Path
    full_chain: Path


def ensure_certs(config_dir: Path) -> CertPaths:
    """Generate self-signed TLS certs for localhost if they don't already exist.

    Certs are written to *config_dir*/certs/ with restrictive (0o600) permissions.
    """
    certs_dir = config_dir / "certs"
    mkdir_p(certs_dir)
    if os.name == "posix":
        # Lock the dir to 0o700 even if mkdir_p ran with a permissive umask, so
        # validate_restrictive_file (called before TLS startup) won't reject it.
        os.chmod(certs_dir, _RESTRICTIVE_DIR_MODE)

    paths = CertPaths(
        ca_cert=certs_dir / CA_CERT_NAME,
        server_cert=certs_dir / SERVER_CERT_NAME,
        server_key=certs_dir / SERVER_KEY_NAME,
        full_chain=certs_dir / FULL_CHAIN_NAME,
    )

    if paths.ca_cert.exists() and paths.server_cert.exists() and paths.server_key.exists() and paths.full_chain.exists():
        return paths

    ca = trustme.CA()
    server_identity = ca.issue_cert("localhost", "127.0.0.1")

    ca_pem = ca.cert_pem.bytes().decode("ascii")
    server_key_pem = server_identity.private_key_pem.bytes().decode("ascii")
    server_cert_pem = "".join(blob.bytes().decode("ascii") for blob in server_identity.cert_chain_pems)

    write_text_restrictive(allowed_dir=certs_dir, path=paths.ca_cert, data=ca_pem)
    write_text_restrictive(allowed_dir=certs_dir, path=paths.server_key, data=server_key_pem)
    write_text_restrictive(allowed_dir=certs_dir, path=paths.server_cert, data=server_cert_pem)

    # full-chain.pem = server cert chain + CA cert (for Electron / nginx)
    write_text_restrictive(allowed_dir=certs_dir, path=paths.full_chain, data=server_cert_pem + ca_pem)

    return paths


def ca_bundle_for_url(url: str, ca_cert: Path) -> str | bool:
    """Return a CA bundle suitable for `requests`' ``verify=`` kwarg.

    For ``https://localhost`` brokers using our self-signed CA, return the
    local CA path. Otherwise return True so `requests` uses its default
    trust store (which still honors ``REQUESTS_CA_BUNDLE``).
    """
    parsed = urlparse(url)
    if parsed.scheme != "https" or parsed.hostname not in ("localhost", "127.0.0.1"):
        return True
    return str(ca_cert)


def ensure_grpc_trust_bundle(ca_cert: Path) -> None:
    """Write a combined trust bundle (system roots + local CA) and point gRPC
    at it via ``GRPC_DEFAULT_SSL_ROOTS_FILE_PATH``.

    Must run before any TLS gRPC channel is built — gRPC C-core caches the
    env var on first credential creation.
    """
    if "GRPC_DEFAULT_SSL_ROOTS_FILE_PATH" in os.environ:
        return  # respect operator override
    certs_dir = ca_cert.parent
    bundle_path = certs_dir / _TRUST_BUNDLE_NAME

    system_roots = Path(certifi.where()).read_text(encoding="utf-8")
    local_ca = ca_cert.read_text(encoding="utf-8")
    if not system_roots.endswith("\n"):
        system_roots += "\n"

    write_text_restrictive(allowed_dir=certs_dir, path=bundle_path, data=system_roots + local_ca)
    os.environ["GRPC_DEFAULT_SSL_ROOTS_FILE_PATH"] = str(bundle_path)
