from setuptools import setup; setup(name='pinterest-deploy', version='0.0.1')
