#!/usr/bin/env python3
"""
meshcode-launcher — cross-platform realtime wake daemon.

Subscribes to Supabase Realtime on meshcode.mc_messages INSERT events and, for
each new message, invokes the existing nudge_agent() in comms_v4.py to wake
the target agent. Zero LLM tokens are consumed by the daemon itself.

Usage:
    python3 -m meshcode.launcher run

Env vars (fallback: ~/.meshcode/env):
    SUPABASE_URL, SUPABASE_KEY
"""
from __future__ import annotations

import asyncio
import json
import os
import re
import signal
import sys
import time
import traceback
from datetime import datetime, timezone
from pathlib import Path

# ---------------------------------------------------------------------------
# Paths
# ---------------------------------------------------------------------------
STATE_DIR = Path.home() / ".meshcode"
STATE_DIR.mkdir(parents=True, exist_ok=True)
LOG_FILE = STATE_DIR / "launcher.log"
ERR_FILE = STATE_DIR / "launcher.err"
PID_FILE = STATE_DIR / "launcher.pid"
ENV_FILE = STATE_DIR / "env"

# In-memory state
_project_cache: dict[str, str] = {}        # project_id -> project name
_last_event_at: float | None = None
_start_time = time.time()

# ---------------------------------------------------------------------------
# Logging
# ---------------------------------------------------------------------------
def log(msg: str, *, err: bool = False) -> None:
    ts = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    line = f"[{ts}] {msg}\n"
    try:
        with open(LOG_FILE, "a") as f:
            f.write(line)
        if err:
            with open(ERR_FILE, "a") as f:
                f.write(line)
    except Exception:
        pass
    # Also echo to stderr so launchd/systemd/journalctl pick it up
    sys.stderr.write(line)
    sys.stderr.flush()


# ---------------------------------------------------------------------------
# Env loading
# ---------------------------------------------------------------------------
def load_env() -> tuple[str, str]:
    url = os.environ.get("SUPABASE_URL", "").strip()
    key = os.environ.get("SUPABASE_KEY", "").strip()
    if not (url and key) and ENV_FILE.exists():
        try:
            for raw in ENV_FILE.read_text().splitlines():
                line = raw.strip()
                if not line or line.startswith("#"):
                    continue
                if line.startswith("export "):
                    line = line[len("export "):]
                if "=" not in line:
                    continue
                k, _, v = line.partition("=")
                v = v.strip().strip('"').strip("'")
                if k.strip() == "SUPABASE_URL" and not url:
                    url = v
                elif k.strip() == "SUPABASE_KEY" and not key:
                    key = v
        except Exception as e:
            log(f"env-file read failed: {e}", err=True)
    if not (url and key):
        log("SUPABASE_URL/SUPABASE_KEY missing; cannot start", err=True)
        sys.exit(2)
    # Re-export so comms_v4 import at module load sees them
    os.environ["SUPABASE_URL"] = url
    os.environ["SUPABASE_KEY"] = key
    return url, key


# ---------------------------------------------------------------------------
# Heartbeat / pid file
# ---------------------------------------------------------------------------
def write_pidfile() -> None:
    payload = {
        "pid": os.getpid(),
        "started_at": _start_time,
        "last_event_at": _last_event_at,
        "uptime_seconds": int(time.time() - _start_time),
    }
    try:
        PID_FILE.write_text(json.dumps(payload, indent=2))
    except Exception as e:
        log(f"pid-file write failed: {e}", err=True)


async def heartbeat_loop() -> None:
    while True:
        write_pidfile()
        await asyncio.sleep(30)


# ---------------------------------------------------------------------------
# comms_v4 bridge — reuse nudge_agent
# ---------------------------------------------------------------------------
def _import_comms():
    """Import comms_v4 (lazy so env vars are already set)."""
    try:
        from meshcode import comms_v4 as C  # type: ignore
        return C
    except Exception as e:
        log(f"failed to import meshcode.comms_v4: {e}", err=True)
        # Fallback: load repo-root comms_v4.py directly
        try:
            repo_comms = Path(__file__).resolve().parent.parent / "comms_v4.py"
            if repo_comms.exists():
                import importlib.util
                spec = importlib.util.spec_from_file_location("comms_v4_root", repo_comms)
                mod = importlib.util.module_from_spec(spec)  # type: ignore
                spec.loader.exec_module(mod)                 # type: ignore
                return mod
        except Exception as e2:
            log(f"fallback comms_v4 load failed: {e2}", err=True)
    return None


def project_name_from_id(comms, project_id: str) -> str | None:
    if not project_id:
        return None
    if project_id in _project_cache:
        return _project_cache[project_id]
    try:
        rows = comms.sb_select("mc_projects", f"id=eq.{project_id}", limit=1)
        if rows:
            name = rows[0].get("name") or rows[0].get("project_name")
            if name:
                _project_cache[project_id] = name
                return name
    except Exception as e:
        log(f"project lookup failed for {project_id}: {e}", err=True)
    return None


def handle_message_row(comms, row: dict) -> None:
    global _last_event_at
    try:
        msg_type = (row.get("type") or "").lower()
        if row.get("read") is True:
            return
        if msg_type in ("ack", "warning"):
            return
        from_agent = row.get("from_agent") or ""
        to_agent = row.get("to_agent") or ""
        if not to_agent or from_agent == to_agent:
            return

        # Age filter — skip backfill older than 60s
        created = row.get("created_at") or row.get("inserted_at")
        if created:
            try:
                s = str(created).replace("Z", "+00:00")
                dt = datetime.fromisoformat(s)
                if dt.tzinfo is None:
                    dt = dt.replace(tzinfo=timezone.utc)
                age = (datetime.now(timezone.utc) - dt).total_seconds()
                if age > 60:
                    log(f"skip stale msg age={age:.0f}s from={from_agent} to={to_agent}")
                    return
            except Exception:
                pass

        project_id = row.get("project_id") or ""
        project = project_name_from_id(comms, project_id) or project_id
        if not project:
            log(f"no project for row id={row.get('id')}", err=True)
            return

        _last_event_at = time.time()
        write_pidfile()

        try:
            ok = comms.nudge_agent(project, to_agent, from_agent)
            if ok:
                log(f"EVENT {project} {from_agent} -> {to_agent} nudged (live terminal)")
            else:
                log(f"EVENT {project} {from_agent} -> {to_agent} queued (agent offline)")
        except Exception as e:
            log(f"  nudge_agent raised: {e}\n{traceback.format_exc()}", err=True)
    except Exception as e:
        log(f"handle_message_row error: {e}\n{traceback.format_exc()}", err=True)


# ---------------------------------------------------------------------------
# Realtime client — prefer `realtime` package, fallback to polling
# ---------------------------------------------------------------------------
async def run_realtime(url: str, key: str, comms) -> None:
    """Subscribe via the `realtime` package. Raises on failure for retry."""
    from realtime import AsyncRealtimeClient  # type: ignore

    # Build ws url from HTTPS supabase url
    ws_url = re.sub(r"^http", "ws", url).rstrip("/") + "/realtime/v1"
    client = AsyncRealtimeClient(ws_url, key, auto_reconnect=True)
    await client.connect()
    channel = client.channel("meshcode_launcher")

    def on_insert(payload, *_, **__):
        try:
            # realtime v2 delivers {"data": {"record": {...}}} or similar
            data = payload.get("data") if isinstance(payload, dict) else None
            record = None
            if isinstance(data, dict):
                record = data.get("record") or data.get("new")
            if record is None and isinstance(payload, dict):
                record = payload.get("record") or payload.get("new")
            if not record:
                return
            handle_message_row(comms, record)
        except Exception as e:
            log(f"on_insert error: {e}", err=True)

    channel.on_postgres_changes(
        event="INSERT",
        schema="meshcode",
        table="mc_messages",
        callback=on_insert,
    )
    await channel.subscribe()
    log("realtime: subscribed to meshcode.mc_messages INSERT")
    # Park forever — the client's own heartbeat keeps the socket alive
    while True:
        await asyncio.sleep(3600)


async def run_polling(comms) -> None:
    """Fallback: poll mc_messages every 3s for new INSERT rows."""
    log("polling: starting 3s fallback loop")
    # Baseline: only handle rows newer than startup
    since = datetime.now(timezone.utc).isoformat()
    while True:
        try:
            rows = comms.sb_select(
                "mc_messages",
                f"created_at=gt.{since}&order=created_at.asc",
                limit=50,
            ) or []
            for r in rows:
                handle_message_row(comms, r)
                c = r.get("created_at")
                if c:
                    since = c
        except Exception as e:
            log(f"polling error: {e}", err=True)
        await asyncio.sleep(3)


async def supervisor() -> None:
    url, key = load_env()
    comms = _import_comms()
    if comms is None:
        log("cannot continue without comms_v4", err=True)
        sys.exit(3)

    asyncio.create_task(heartbeat_loop())

    backoff = 1.0
    use_realtime = True
    try:
        import realtime  # noqa: F401
    except Exception as e:
        log(f"realtime package unavailable ({e}); using polling fallback", err=True)
        use_realtime = False

    while True:
        try:
            if use_realtime:
                await run_realtime(url, key, comms)
            else:
                await run_polling(comms)
        except asyncio.CancelledError:
            raise
        except Exception as e:
            log(f"main loop error: {e} — reconnect in {backoff:.0f}s", err=True)
            await asyncio.sleep(backoff)
            backoff = min(backoff * 2, 30.0)
            continue
        backoff = 1.0


# ---------------------------------------------------------------------------
# Signals + entry
# ---------------------------------------------------------------------------
def _install_signals(loop: asyncio.AbstractEventLoop) -> None:
    def _stop():
        log("shutdown signal received")
        for t in asyncio.all_tasks(loop):
            t.cancel()
    for s in (signal.SIGTERM, signal.SIGINT):
        try:
            loop.add_signal_handler(s, _stop)
        except NotImplementedError:
            # Windows: no add_signal_handler for SIGTERM
            pass


def cmd_run() -> int:
    log("meshcode-launcher v2 — mesh-only mode (never spawns claude)")
    log(f"launcher starting pid={os.getpid()}")
    write_pidfile()
    try:
        asyncio.run(_main())
    except KeyboardInterrupt:
        pass
    log("launcher exited")
    return 0


async def _main():
    loop = asyncio.get_running_loop()
    _install_signals(loop)
    try:
        await supervisor()
    except asyncio.CancelledError:
        return


def main(argv: list[str] | None = None) -> int:
    argv = list(argv if argv is not None else sys.argv[1:])
    cmd = argv[0] if argv else "run"
    if cmd in ("run", "start-foreground"):
        return cmd_run()
    if cmd in ("--help", "-h", "help"):
        print(__doc__)
        return 0
    print(f"unknown launcher command: {cmd}", file=sys.stderr)
    return 2


if __name__ == "__main__":
    sys.exit(main())
