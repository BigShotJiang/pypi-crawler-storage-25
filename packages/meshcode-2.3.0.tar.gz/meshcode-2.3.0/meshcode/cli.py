#!/usr/bin/env python3
"""MeshCode CLI entry point for pip install."""
import sys
import os


def main():
    """Entry point that delegates to comms_v4.py within the package."""
    # Find comms_v4.py — first in package dir, then in repo root
    pkg_dir = os.path.dirname(os.path.abspath(__file__))
    repo_root = os.path.dirname(pkg_dir)

    for candidate in [
        os.path.join(pkg_dir, "comms_v4.py"),
        os.path.join(repo_root, "comms_v4.py"),
    ]:
        if os.path.exists(candidate):
            sys.argv[0] = candidate
            # Set __name__ and __file__ for the script
            globs = {"__name__": "__main__", "__file__": candidate}
            with open(candidate) as f:
                exec(compile(f.read(), candidate, "exec"), globs)
            return

    print("[ERROR] comms_v4.py not found. Reinstall: pip install meshcode")
    sys.exit(1)


if __name__ == "__main__":
    main()
