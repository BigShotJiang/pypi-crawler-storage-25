"""Background self-update for the meshcode CLI.

Design goals:
  - ZERO added latency to `meshcode run`. The PyPI check + pip install
    runs in a fully detached background subprocess. The current launch
    is never blocked.
  - Opt-in (first-run prompt, like permission_mode). Default ON for
    interactive TTY users, default OFF for CI / non-TTY.
  - Cache the PyPI check for 1 hour so we don't hit the network on
    every launch.
  - Two-launch model: launch N detects + downloads in the background;
    launch N+1 reads the result file, prints "[meshcode] updated X → Y",
    and the new code is already on disk.
  - Safe in all the edge cases that bite Python CLI updaters:
      * editable installs (dev mode) → skip
      * pipx installs → use `pipx upgrade meshcode`
      * MCP server subprocess → skip (we're inside an agent runtime)
      * --no-update flag, MESHCODE_NO_UPDATE=1 env → skip
      * offline / network error → silent skip
      * concurrent runs → file lock so only one bg update at a time
"""
from __future__ import annotations

import json
import os
import subprocess
import sys
import time
from pathlib import Path
from typing import Optional, Tuple

PKG_NAME = "meshcode"
PYPI_URL = f"https://pypi.org/pypi/{PKG_NAME}/json"
CACHE_TTL_SEC = 3600  # 1 hour
NETWORK_TIMEOUT_SEC = 1.5

STATE_DIR = Path.home() / ".meshcode"
RESULT_PATH = STATE_DIR / ".update_result.json"
LOCK_PATH = STATE_DIR / ".update.lock"
LOG_PATH = STATE_DIR / "update.log"
LOCK_STALE_SEC = 600  # 10 min — if a lock is older, treat as crashed


# ============================================================
# Detection helpers — when NOT to auto-update
# ============================================================

def _current_version() -> str:
    try:
        from . import __version__
        return __version__
    except Exception:
        return "0.0.0"


def is_editable_install() -> bool:
    """True if meshcode is installed via `pip install -e .` (dev mode)."""
    try:
        import meshcode
        path = os.path.realpath(meshcode.__file__)
        return "site-packages" not in path and "dist-packages" not in path
    except Exception:
        return False


def is_inside_mcp_serve() -> bool:
    """True if we're running inside the MCP subprocess of an agent client."""
    if os.environ.get("MESHCODE_MCP_SERVE") == "1":
        return True
    argv0 = " ".join(sys.argv).lower()
    return "meshcode_mcp" in argv0 or "meshcode.meshcode_mcp" in argv0


def is_pipx_install() -> bool:
    """True if installed via pipx (we should use `pipx upgrade` instead)."""
    exe = os.path.realpath(sys.executable)
    return "/pipx/" in exe or "\\pipx\\" in exe


def update_disabled() -> bool:
    """User explicitly opted out for this run / globally."""
    if os.environ.get("MESHCODE_NO_UPDATE") == "1":
        return True
    if "--no-update" in sys.argv:
        return True
    return False


def _version_tuple(v: str) -> Tuple[int, ...]:
    parts = []
    for p in v.split("."):
        digits = "".join(c for c in p if c.isdigit())
        parts.append(int(digits) if digits else 0)
    return tuple(parts)


def _is_newer(remote: str, local: str) -> bool:
    try:
        return _version_tuple(remote) > _version_tuple(local)
    except Exception:
        return False


# ============================================================
# Cache + result file (consumed by next launch)
# ============================================================

def _read_prefs() -> dict:
    try:
        from .preferences import load_prefs
        return load_prefs()
    except Exception:
        return {}


def _write_prefs_kv(**kv) -> None:
    try:
        from .preferences import load_prefs, save_prefs
        prefs = load_prefs()
        prefs.update(kv)
        save_prefs(prefs)
    except Exception:
        pass


def _cache_fresh() -> bool:
    last = _read_prefs().get("last_update_check_at", 0)
    return (time.time() - last) < CACHE_TTL_SEC


def _mark_checked(latest: Optional[str]) -> None:
    _write_prefs_kv(
        last_update_check_at=int(time.time()),
        last_known_latest_version=latest or _current_version(),
    )


def consume_pending_result() -> None:
    """Read + delete .update_result.json, print outcome to stderr.

    Called at the START of each `meshcode run` to surface what the
    previous launch's background updater did.
    """
    if not RESULT_PATH.exists():
        return
    try:
        data = json.loads(RESULT_PATH.read_text())
        RESULT_PATH.unlink(missing_ok=True)
    except Exception:
        return
    cur = _current_version()
    new_v = data.get("version") or "?"
    if data.get("ok"):
        if _is_newer(new_v, cur):
            print(f"[meshcode] updated {cur} → {new_v}. Restart your editor to load the new version.", file=sys.stderr)
        else:
            # update ran but pip didn't actually upgrade (already at latest)
            pass
    else:
        err = data.get("error", "unknown error")
        print(f"[meshcode] WARN: last auto-update failed: {err}", file=sys.stderr)


# ============================================================
# Network — PyPI version probe
# ============================================================

def fetch_latest_version(timeout: float = NETWORK_TIMEOUT_SEC) -> Optional[str]:
    try:
        import urllib.request
        req = urllib.request.Request(PYPI_URL, headers={"User-Agent": f"meshcode/{_current_version()}"})
        with urllib.request.urlopen(req, timeout=timeout) as resp:
            data = json.loads(resp.read().decode("utf-8"))
        return data.get("info", {}).get("version")
    except Exception:
        return None


# ============================================================
# File lock — prevent concurrent bg updates
# ============================================================

def _acquire_lock() -> bool:
    try:
        if LOCK_PATH.exists():
            age = time.time() - LOCK_PATH.stat().st_mtime
            if age < LOCK_STALE_SEC:
                return False
            LOCK_PATH.unlink(missing_ok=True)
        LOCK_PATH.parent.mkdir(parents=True, exist_ok=True)
        LOCK_PATH.write_text(str(os.getpid()))
        return True
    except Exception:
        return False


# ============================================================
# Background update spawn
# ============================================================

_BG_RUNNER_PY = r'''
import json, os, subprocess, sys, time
from pathlib import Path

result = {"version": None, "ok": False, "error": None, "finished_at": None}
state_dir = Path.home() / ".meshcode"
result_path = state_dir / ".update_result.json"
lock_path = state_dir / ".update.lock"
log_path = state_dir / "update.log"
state_dir.mkdir(parents=True, exist_ok=True)

mode = sys.argv[1] if len(sys.argv) > 1 else "pip"
target_version = sys.argv[2] if len(sys.argv) > 2 else None

try:
    if mode == "pipx":
        cmd = ["pipx", "upgrade", "meshcode"]
    else:
        cmd = [sys.executable, "-m", "pip", "install", "-U", "--disable-pip-version-check", "--quiet", "meshcode"]
    with open(log_path, "ab") as logf:
        logf.write(f"\n=== {time.strftime('%Y-%m-%d %H:%M:%S')} bg update via {mode} ===\n".encode())
        logf.flush()
        proc = subprocess.run(cmd, stdout=logf, stderr=logf, timeout=180)
    if proc.returncode == 0:
        result["ok"] = True
        result["version"] = target_version
    else:
        result["error"] = f"pip exit {proc.returncode}"
except subprocess.TimeoutExpired:
    result["error"] = "pip install timed out after 180s"
except Exception as e:
    result["error"] = str(e)
finally:
    result["finished_at"] = int(time.time())
    try:
        result_path.write_text(json.dumps(result))
    except Exception:
        pass
    try:
        lock_path.unlink()
    except Exception:
        pass
'''


def _spawn_background_updater(target_version: str) -> bool:
    """Spawn a fully detached subprocess that runs the updater.

    The parent (current `meshcode run`) returns immediately. The child
    runs pip install in the background, writes the result to disk, and
    exits. Next `meshcode run` consumes the result.
    """
    if not _acquire_lock():
        return False

    mode = "pipx" if is_pipx_install() else "pip"

    # We pass the runner code via stdin so we don't need to ship a
    # second .py file. The child reads it from sys.stdin and execs it.
    runner = f"import sys; exec(sys.stdin.read())"
    args = [sys.executable, "-c", runner, mode, target_version]

    try:
        if sys.platform == "win32":
            DETACHED_PROCESS = 0x00000008
            CREATE_NEW_PROCESS_GROUP = 0x00000200
            CREATE_NO_WINDOW = 0x08000000
            flags = DETACHED_PROCESS | CREATE_NEW_PROCESS_GROUP | CREATE_NO_WINDOW
            proc = subprocess.Popen(
                args,
                stdin=subprocess.PIPE,
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
                creationflags=flags,
                close_fds=True,
            )
        else:
            proc = subprocess.Popen(
                args,
                stdin=subprocess.PIPE,
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
                start_new_session=True,
                close_fds=True,
            )
        if proc.stdin:
            proc.stdin.write(_BG_RUNNER_PY.encode("utf-8"))
            proc.stdin.close()
        return True
    except Exception:
        try:
            LOCK_PATH.unlink(missing_ok=True)
        except Exception:
            pass
        return False


# ============================================================
# Public entrypoint — called from meshcode run
# ============================================================

def check_and_maybe_update(verbose: bool = False) -> None:
    """Non-blocking. Call at the start of `meshcode run`.

    Order of checks (any failure → silent return, never raise):
      1. consume any pending result from previous launch
      2. opt-out gates: --no-update, MESHCODE_NO_UPDATE=1
      3. context gates: editable install, MCP subprocess
      4. user preference: resolve_auto_update() (may prompt first time)
      5. cache TTL: skip if checked < 1h ago
      6. PyPI fetch (1.5s timeout)
      7. version compare; if newer → spawn background updater
    """
    try:
        consume_pending_result()
    except Exception:
        pass

    if update_disabled():
        return
    if is_inside_mcp_serve():
        return
    if is_editable_install():
        return

    try:
        from .preferences import resolve_auto_update
        if not resolve_auto_update():
            return
    except Exception:
        return

    if _cache_fresh():
        return

    latest = fetch_latest_version()
    _mark_checked(latest)
    if not latest:
        return
    if not _is_newer(latest, _current_version()):
        return

    started = _spawn_background_updater(latest)
    if started and verbose:
        print(f"[meshcode] downloading {latest} in background...", file=sys.stderr)
