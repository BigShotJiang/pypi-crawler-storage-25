import html as _e
import json

from markdown_it import MarkdownIt
from stario.datastar import DatastarScript, at, data
from stario.html import (
    A,
    Body,
    Button,
    Div,
    Head,
    Html,
    Img,
    Input,
    Label,
    Meta,
    Pre,
    SafeString,
    Script,
    Span,
    Textarea,
    Title,
)

from stario import UrlFor

from grokbook.ansi import ansi_to_html
from grokbook.envs import EnvInfo
from grokbook.state import Cell, Notebook, Project

_md = MarkdownIt("gfm-like")

_SPINNER_SVG = SafeString(
    '<svg class="animate-spin h-4 w-4" viewBox="0 0 24 24">'
    '<circle class="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" stroke-width="4" fill="none"></circle>'
    '<path class="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4z"></path>'
    "</svg>"
)


# ── components ────────────────────────────────────────────────────────────────


def _settings_toggle(label: str, signal: str):
    """A labeled toggle switch for the settings dropdown."""
    return Div(
        data.on("click", f"{signal} = !{signal}"),
        {"class": "flex items-center justify-between cursor-pointer select-none group/st"},
        Span({"class": "text-xs text-zinc-300 group-hover/st:text-zinc-100"}, label),
        Div(
            {"class": "w-7 h-4 rounded-full relative transition-colors"},
            data.class_("bg-indigo-500", signal),
            data.class_("bg-zinc-600", f"!{signal}"),
            Div(
                {"class": "absolute top-0.5 w-3 h-3 rounded-full bg-white shadow transition-all"},
                data.class_("left-3.5", signal),
                data.class_("left-0.5", f"!{signal}"),
            ),
        ),
    )


def _path_suggestions_view(suggestions: list[str]):
    """Render the suggestions list (patched by /kernel/envs/complete)."""
    if not suggestions:
        return Div({"id": "path-suggestions"})
    return Div(
        {
            "id": "path-suggestions",
            "class": "max-h-40 overflow-y-auto border-t border-zinc-800 bg-zinc-950",
        },
        *[
            Button(
                data.on("click", f"$new_env_path = {json.dumps(s)}"),
                {
                    "class": (
                        "w-full text-left px-3 py-1 text-[11px] font-mono text-zinc-400 "
                        "hover:bg-zinc-800 hover:text-zinc-200 cursor-pointer truncate block"
                    ),
                    "title": s,
                },
                s,
            )
            for s in suggestions
        ],
    )


def _env_item(env: EnvInfo):
    """A single row in the kernel dropdown."""
    disabled = not env.has_ipykernel
    if disabled:
        # Clicking opens the install modal instead of switching
        click_expr = f"$install_env_path = {json.dumps(env.path)}; $install_env_name = {json.dumps(env.name)}; $show_kernels = false"
    else:
        # Set signal + POST to /kernel/env/set (notebook_id + env_path carried via signals)
        click_expr = (
            f"$kernel_env = {json.dumps(env.path)}; "
            f"$pending_env_path = {json.dumps(env.path)}; "
            f"$show_kernels = false; "
            f"@post('/kernel/env/set', {{filterSignals: {{include: '/^(notebook_id|pending_env_path)$/'}}}})"
        )
    tooltip = env.path + ("  (ipykernel not installed)" if disabled else "")
    return Button(
        data.on("click", click_expr),
        {
            "title": tooltip,
            "class": (
                "w-full flex items-center gap-2 px-3 py-1.5 text-left text-xs "
                "hover:bg-zinc-800 transition-colors cursor-pointer "
                + ("opacity-70" if disabled else "")
            ),
        },
        data.class_({
            "bg-indigo-600/20": f"$kernel_env === {json.dumps(env.path)}",
            "text-indigo-300": f"$kernel_env === {json.dumps(env.path)}",
        }),
        Span({"class": "font-mono text-zinc-500 w-4 shrink-0"}, env.label_glyph),
        Span({"class": "truncate flex-1"}, env.name),
        Span({"class": "font-mono text-zinc-500 text-[10px] shrink-0"}, f"py{env.version_str}"),
        Span({"class": "text-yellow-500 text-[10px] shrink-0"}, "⚠") if disabled else SafeString(""),
        Span(
            data.on(
                "click",
                f"event.stopPropagation(); $remove_env_path = {json.dumps(env.path)}; "
                f"@post('/kernel/envs/remove', {{filterSignals: {{include: '/^remove_env_path$/'}}}})",
            ),
            {
                "class": "text-zinc-600 hover:text-red-400 text-[11px] shrink-0 cursor-pointer ml-1",
                "title": "Remove custom env",
            },
            "✕",
        ) if env.source == "custom" else SafeString(""),
    )


def kernel_selector(envs: list[EnvInfo]):
    """Header dropdown for switching the notebook's Python kernel."""
    return Div(
        {"id": "kernel-selector", "class": "relative"},
        data.signals({
            "show_kernels": False,
            "pending_env_path": "",
            "new_env_path": "",
            "new_env_error": "",
            "remove_env_path": "",
        }),
        # outside-click on the selector wrapper closes the dropdown
        data.on("click", "$show_kernels = false", outside=True),
        Button(
            data.on("click", "$show_kernels = !$show_kernels"),
            data.attr("title", "$kernel_env || 'no kernel selected'"),
            {
                "class": (
                    "flex items-center gap-1.5 text-xs text-zinc-400 hover:text-zinc-200 "
                    "transition-colors cursor-pointer px-2 py-1 rounded border border-zinc-700 "
                    "hover:border-zinc-500 font-mono"
                ),
            },
            Span({"class": "text-zinc-500"}, "kernel:"),
            Span(data.text("$kernel_env.split('/').pop() || 'default'")),
            Span({"class": "text-zinc-600"}, "▾"),
        ),
        Div(
            data.show("$show_kernels"),
            {
                "class": (
                    "absolute left-0 top-full mt-1 bg-zinc-900 border border-zinc-700 "
                    "rounded-md py-1 min-w-[320px] max-h-[400px] overflow-y-auto z-50 shadow-xl"
                ),
                "style": "display:none",
            },
            *[_env_item(env) for env in envs],
            Div({"class": "border-t border-zinc-800 my-1"}),
            # Add custom path row
            Div(
                {"class": "px-3 py-1.5 flex items-center gap-1"},
                Input(
                    data.bind("new_env_path"),
                    data.on(
                        "input",
                        "@post('/kernel/envs/complete', {filterSignals: {include: '/^new_env_path$/'}})",
                        debounce="150ms",
                    ),
                    data.on(
                        "keydown",
                        "if(event.key==='Enter'){event.preventDefault();"
                        "@post('/kernel/envs/add', {filterSignals: {include: '/^new_env_path$/'}})}",
                    ),
                    {
                        "type": "text",
                        "placeholder": "/path/to/python",
                        "spellcheck": "false",
                        "autocomplete": "off",
                        "class": (
                            "flex-1 min-w-0 bg-zinc-800 border border-zinc-700 rounded px-2 py-1 "
                            "text-xs font-mono text-zinc-200 placeholder-zinc-600 "
                            "focus:border-indigo-500 outline-none"
                        ),
                    },
                ),
                Button(
                    data.on(
                        "click",
                        "@post('/kernel/envs/add', {filterSignals: {include: '/^new_env_path$/'}})",
                    ),
                    {
                        "class": "px-2 py-1 text-xs text-zinc-400 hover:text-zinc-200 "
                        "bg-zinc-800 hover:bg-zinc-700 rounded border border-zinc-700 cursor-pointer",
                        "title": "Add Python interpreter",
                    },
                    "+",
                ),
            ),
            # Suggestions list (populated by /kernel/envs/complete patches)
            Div({"id": "path-suggestions"}),
            Div(
                data.show("$new_env_error !== ''"),
                data.text("$new_env_error"),
                {
                    "class": "px-3 pb-1.5 text-[11px] text-red-400",
                    "style": "display:none",
                },
            ),
            Div({"class": "border-t border-zinc-800 my-1"}),
            Button(
                data.on("click", at.post("/kernel/envs/refresh") + "; $show_kernels = false"),
                {
                    "class": "w-full text-left px-3 py-1.5 text-xs text-zinc-500 "
                    "hover:text-zinc-200 hover:bg-zinc-800 cursor-pointer",
                },
                "↻ Refresh",
            ),
        ),
    )


def install_modal():
    """Modal shown when the user clicks an env without ipykernel installed.

    Driven by signals:
      $install_env_path — non-empty string opens the modal
      $install_env_name — display name
      $install_running  — installation in progress
      $install_done     — installation finished
    """
    return Div(
        {"id": "install-modal-wrap"},
        data.show("$install_env_path !== ''"),
        {
            "class": "fixed inset-0 bg-black/60 z-[60] flex items-center justify-center p-4",
            "style": "display:none",
        },
        data.on("click", "if(!$install_running){$install_env_path='';$install_env_name='';$install_done=false;}", outside=False),
        Div(
            data.on("click", "event.stopPropagation()"),
            {"class": "bg-zinc-900 border border-zinc-700 rounded-lg p-6 max-w-2xl w-full shadow-2xl"},
            Span({"class": "block text-sm font-semibold text-zinc-200 mb-1"}, "Install ipykernel"),
            Span(
                {"class": "block text-xs text-zinc-500 mb-3 font-mono"},
                data.text("$install_env_name"),
            ),
            Span(
                {"class": "block text-xs text-zinc-400 mb-3"},
                "This env doesn't have ",
                Span({"class": "font-mono text-zinc-300"}, "ipykernel"),
                " installed. Install it now? (runs ",
                Span({"class": "font-mono text-zinc-300"}, "uv pip install --python <env> ipykernel"),
                ")",
            ),
            Pre(
                {
                    "id": "install-log",
                    "class": "bg-black p-2 font-mono text-[11px] max-h-64 overflow-auto text-zinc-300 whitespace-pre-wrap mb-3 rounded",
                    "style": "display:none",
                },
                data.show("$install_running || $install_done"),
            ),
            Div(
                {"class": "flex gap-2 justify-end"},
                Button(
                    data.on("click", "$install_env_path='';$install_env_name='';$install_done=false;$install_ok=false"),
                    data.show("!$install_running"),
                    {"class": "px-3 py-1.5 text-xs text-zinc-400 hover:text-zinc-200 rounded border border-zinc-700 hover:border-zinc-500 cursor-pointer"},
                    "Close",
                ),
                Button(
                    data.on(
                        "click",
                        "$install_done=false;$install_ok=false;"
                        "@post('/kernel/env/install', {filterSignals: {include: '/^install_env_path$/'}})",
                    ),
                    data.show("!$install_running && !($install_done && $install_ok)"),
                    {"class": "px-3 py-1.5 text-xs text-white bg-indigo-600 hover:bg-indigo-500 rounded cursor-pointer"},
                    "Install",
                ),
                Button(
                    {"class": "px-3 py-1.5 text-xs text-zinc-400 rounded border border-zinc-700 cursor-not-allowed"},
                    data.show("$install_running"),
                    "Installing…",
                ),
            ),
        ),
    )


def header_bar(envs: list[EnvInfo] | None = None):
    return Div(
        {
            "class": "fixed top-0 left-0 right-0 h-12 bg-zinc-900 border-b border-zinc-800 "
            "flex items-center justify-between px-4 z-40"
        },
        Div(
            {"class": "flex items-center gap-3"},
            Span({"class": "text-sm font-semibold text-zinc-300"}, "grokbook"),
            Div(
                {"class": "flex items-center gap-1.5 ml-4"},
                Div(
                    data.show("$kernel_state === 'idle'"),
                    {"class": "w-2 h-2 rounded-full bg-green-400"},
                ),
                Div(
                    data.show("$kernel_state === 'busy'"),
                    {"class": "w-2 h-2 rounded-full bg-yellow-400 animate-pulse", "style": "display:none"},
                ),
                Div(
                    data.show("$kernel_state === 'dead'"),
                    {"class": "w-2 h-2 rounded-full bg-red-500", "style": "display:none"},
                ),
                Span(
                    {"class": "text-xs text-zinc-500"},
                    data.text("$kernel_state"),
                ),
            ),
            kernel_selector(envs or []),
        ),
        Div(
            {"class": "flex items-center gap-2"},
            Div(
                data.on("click", "$wide_mode = !$wide_mode"),
                {"class": "flex items-center gap-1.5 cursor-pointer select-none group/toggle"},
                Span({"class": "text-xs text-zinc-500 group-hover/toggle:text-zinc-300 transition-colors"}, "Wide"),
                Div(
                    {
                        "class": "w-7 h-4 rounded-full relative transition-colors",
                    },
                    data.class_("bg-indigo-500", "$wide_mode"),
                    data.class_("bg-zinc-700", "!$wide_mode"),
                    Div({
                        "class": "absolute top-0.5 w-3 h-3 rounded-full bg-white shadow transition-all",
                    },
                        data.class_("left-3.5", "$wide_mode"),
                        data.class_("left-0.5", "!$wide_mode"),
                    ),
                ),
            ),
            Button(
                data.on("click", "$show_vars = !$show_vars"),
                {
                    "class": "text-xs text-zinc-500 hover:text-zinc-200 transition-colors "
                    "cursor-pointer px-3 py-1 rounded border border-zinc-700 hover:border-zinc-500"
                },
                "Vars",
            ),
            Button(
                data.on("click", "$light_mode = !$light_mode"),
                {
                    "class": "text-xs text-zinc-500 hover:text-zinc-200 transition-colors "
                    "cursor-pointer px-3 py-1 rounded border border-zinc-700 hover:border-zinc-500"
                },
                "Theme",
            ),
            # ── Settings dropdown ──
            Div(
                {"class": "relative"},
                Button(
                    data.on("click", "$show_settings = !$show_settings"),
                    {
                        "class": "text-xs text-zinc-500 hover:text-zinc-200 transition-colors "
                        "cursor-pointer px-3 py-1 rounded border border-zinc-700 hover:border-zinc-500"
                    },
                    "⚙",
                ),
                Div(
                    data.show("$show_settings"),
                    {
                        "class": "absolute right-0 top-full mt-2 w-56 bg-zinc-800 border border-zinc-600 "
                        "rounded-lg shadow-xl z-50 p-3 space-y-3",
                        "style": "display:none",
                    },
                    Div(
                        {"class": "text-xs font-semibold text-zinc-400 uppercase tracking-wider mb-2"},
                        "Editor Settings",
                    ),
                    # Autocomplete toggle
                    _settings_toggle("Autocomplete", "$editor_autocomplete"),
                    # Line wrap toggle
                    _settings_toggle("Line Wrap", "$editor_linewrap"),
                    # Vim mode toggle
                    _settings_toggle("Vim Mode", "$editor_vim"),
                ),
                # Click-away overlay
                Div(
                    data.on("click", "$show_settings = false"),
                    data.show("$show_settings"),
                    {"class": "fixed inset-0 z-40", "style": "display:none"},
                ),
            ),
            Button(
                data.on("click", at.post("/cells/run-all", include=["notebook_id"])),
                data.indicator("executing"),
                {
                    "class": "text-xs text-zinc-500 hover:text-zinc-200 transition-colors "
                    "cursor-pointer px-3 py-1 rounded border border-zinc-700 hover:border-zinc-500"
                },
                "▶▶ Run All",
            ),
            Button(
                data.on("click", at.post("/cells/clear-all-outputs", include=["notebook_id"])),
                {
                    "class": "text-xs text-zinc-500 hover:text-zinc-200 transition-colors "
                    "cursor-pointer px-3 py-1 rounded border border-zinc-700 hover:border-zinc-500"
                },
                "Clear All",
            ),
            Button(
                data.on("click", at.post("/kernel/interrupt", include=["notebook_id"])),
                data.show("$executing"),
                {
                    "class": "text-xs text-red-400 hover:text-red-300 transition-colors "
                    "cursor-pointer px-3 py-1 rounded border border-red-700 hover:border-red-500",
                    "style": "display:none",
                },
                "■ Stop",
            ),
            Button(
                data.on(
                    "click",
                    at.post("/kernel/restart", include=["notebook_id"]),
                ),
                data.indicator("restarting"),
                data.attr("disabled", "$restarting"),
                {
                    "class": "text-xs text-zinc-500 hover:text-zinc-200 transition-colors "
                    "cursor-pointer px-3 py-1 rounded border border-zinc-700 hover:border-zinc-500 "
                    "disabled:opacity-60 disabled:cursor-wait flex items-center gap-1.5"
                },
                Span(data.show("$restarting"), {"style": "display:none"}, _SPINNER_SVG),
                Span(data.show("!$restarting"), "↺ "),
                "Restart Kernel",
            ),
        ),
    )


def _nb_item(nb: Notebook, active_id: int):
    """Normal sidebar notebook item with ⋯ menu button."""
    is_active = nb.id == active_id
    return Div(
        {"class": "relative group mb-1"},
        Button(
            data.on(
                "click",
                f"$notebook_id = {nb.id}; window.history.pushState(null,'','/nb/{nb.id}')",
            ),
            {
                "class": (
                    "block w-full text-left px-3 py-2 pr-8 rounded-md text-sm truncate "
                    "transition-colors cursor-pointer "
                    + (
                        "bg-indigo-600/20 text-indigo-300 border border-indigo-600/30"
                        if is_active
                        else "text-zinc-400 hover:bg-zinc-800 hover:text-zinc-200"
                    )
                ),
            },
            nb.name,
        ),
        Button(
            data.on("click", at.post(f"/nb/menu/{nb.id}")),
            {
                "class": "absolute right-1 top-1/2 -translate-y-1/2 px-1.5 py-0.5 rounded "
                "text-zinc-600 hover:text-zinc-300 hover:bg-zinc-700 opacity-0 "
                "group-hover:opacity-100 transition-opacity cursor-pointer text-xs",
            },
            "⋯",
        ),
    )


def _nb_item_menu(nb: Notebook, active_id: int):
    """Notebook item with dropdown menu open."""
    is_active = nb.id == active_id
    btn = (
        "block w-full text-left px-3 py-1.5 text-sm text-zinc-300 "
        "hover:bg-zinc-700 rounded cursor-pointer"
    )
    return Div(
        {"class": "relative mb-1"},
        Button(
            {
                "class": (
                    "block w-full text-left px-3 py-2 pr-8 rounded-md text-sm truncate "
                    + (
                        "bg-indigo-600/20 text-indigo-300 border border-indigo-600/30"
                        if is_active
                        else "bg-zinc-800 text-zinc-200"
                    )
                ),
            },
            nb.name,
        ),
        # Dropdown
        Div(
            {
                "class": "absolute left-0 top-full mt-1 w-full bg-zinc-800 border border-zinc-600 "
                "rounded-lg shadow-xl z-50 py-1"
            },
            Button(data.on("click", at.post(f"/nb/rename-mode/{nb.id}")), {"class": btn}, "Rename"),
            Button(data.on("click", at.post(f"/nb/duplicate/{nb.id}")), {"class": btn}, "Duplicate"),
            A(
                {"href": f"/nb/export/{nb.id}", "download": f"{nb.name}.ipynb", "class": btn},
                "Export .ipynb",
            ),
            Button(
                data.on("click", at.post(f"/nb/delete/{nb.id}")),
                {
                    "class": "block w-full text-left px-3 py-1.5 text-sm text-red-400 "
                    "hover:bg-zinc-700 rounded cursor-pointer"
                },
                "Delete",
            ),
        ),
        # Click-away overlay
        Div(
            data.on("click", at.post(f"/nb/menu-close")),
            {"class": "fixed inset-0 z-40", "style": "cursor: default"},
        ),
    )


def _nb_item_rename(nb: Notebook):
    """Notebook item in rename mode — input field."""
    sig = f"rename_{nb.id}"
    return Div(
        {"class": "mb-1"},
        data.signals({sig: nb.name}),
        Input(
            data.bind(sig),
            data.on(
                "keydown",
                f"if(evt.key==='Enter'){{{at.post(f'/nb/rename/{nb.id}', include=[sig])}}};"
                f"if(evt.key==='Escape'){{{at.post('/nb/menu-close')}}}",
            ),
            {
                "type": "text",
                "autofocus": True,
                "class": "w-full px-3 py-2 rounded-md text-sm bg-zinc-800 border border-indigo-500 "
                "text-zinc-200 outline-none",
            },
        ),
    )


def _project_header(project: Project, project_menu_id: int | None = None):
    """Clickable project header with collapse toggle and menu."""
    sig = f"$proj_{project.id}_open"
    return Div(
        {"class": "flex items-center justify-between group/proj mb-1 mt-3 first:mt-0"},
        Button(
            data.on("click", f"{sig} = !{sig}"),
            {"class": "flex items-center gap-1.5 text-xs font-semibold text-zinc-500 "
             "uppercase tracking-wider hover:text-zinc-300 transition-colors cursor-pointer truncate flex-1"},
            Span(
                {"class": "transition-transform text-[10px]"},
                data.class_("rotate-90", sig),
                "▶",
            ),
            Span({"class": "truncate"}, project.name),
        ),
        Button(
            data.on("click", at.post(f"/project/menu/{project.id}")),
            {"class": "px-1 py-0.5 rounded text-zinc-600 hover:text-zinc-300 hover:bg-zinc-700 "
             "opacity-0 group-hover/proj:opacity-100 transition-opacity cursor-pointer text-xs"},
            "⋯",
        ),
    )


def _project_menu(project: Project, active_id: int):
    """Dropdown menu for a project."""
    btn = (
        "block w-full text-left px-3 py-1.5 text-sm text-zinc-300 "
        "hover:bg-zinc-700 rounded cursor-pointer"
    )
    return Div(
        {"class": "relative mb-1 mt-3"},
        Div(
            {"class": "flex items-center gap-1.5 text-xs font-semibold text-zinc-400 "
             "uppercase tracking-wider px-1"},
            project.name,
        ),
        Div(
            {"class": "absolute left-0 top-full mt-1 w-full bg-zinc-800 border border-zinc-600 "
             "rounded-lg shadow-xl z-50 py-1"},
            Button(data.on("click", at.post(f"/project/rename-mode/{project.id}")), {"class": btn}, "Rename"),
            Button(
                data.on("click", at.post(f"/nb/new-in/{project.id}")),
                {"class": btn},
                "+ New Notebook",
            ),
            Button(
                data.on("click", at.post(f"/project/delete/{project.id}")),
                {"class": "block w-full text-left px-3 py-1.5 text-sm text-red-400 "
                 "hover:bg-zinc-700 rounded cursor-pointer"},
                "Delete",
            ),
        ),
        # Click-away overlay
        Div(
            data.on("click", at.post("/project/menu-close")),
            {"class": "fixed inset-0 z-40", "style": "cursor: default"},
        ),
    )


def _project_rename(project: Project):
    """Project in rename mode — input field."""
    sig = f"proj_rename_{project.id}"
    return Div(
        {"class": "mb-1 mt-3"},
        data.signals({sig: project.name}),
        Input(
            data.bind(sig),
            data.on(
                "keydown",
                f"if(evt.key==='Enter'){{{at.post(f'/project/rename/{project.id}', include=[sig])}}};"
                f"if(evt.key==='Escape'){{{at.post('/project/menu-close')}}}",
            ),
            {
                "type": "text",
                "autofocus": True,
                "class": "w-full px-3 py-1.5 rounded-md text-xs bg-zinc-800 border border-indigo-500 "
                "text-zinc-200 outline-none uppercase tracking-wider font-semibold",
            },
        ),
    )


def _project_section(
    project: Project,
    notebooks: list[Notebook],
    active_id: int,
    menu_id: int | None = None,
    renaming_id: int | None = None,
    project_menu_id: int | None = None,
    project_renaming_id: int | None = None,
):
    """A project header + its notebook list (collapsible)."""
    # Project header (or menu/rename mode)
    if project_renaming_id == project.id:
        header = _project_rename(project)
    elif project_menu_id == project.id:
        header = _project_menu(project, active_id)
    else:
        header = _project_header(project, project_menu_id)

    # Notebook items
    items = []
    for nb in notebooks:
        if renaming_id == nb.id:
            items.append(_nb_item_rename(nb))
        elif menu_id == nb.id:
            items.append(_nb_item_menu(nb, active_id))
        else:
            items.append(_nb_item(nb, active_id))

    sig = f"$proj_{project.id}_open"
    return Div(
        header,
        Div(
            data.show(sig),
            *items,
        ) if items else SafeString(""),
    )


def sidebar_view(
    active_id: int,
    projects: list[Project],
    notebooks_by_project: dict[int, list[Notebook]],
    menu_id: int | None = None,
    renaming_id: int | None = None,
    project_menu_id: int | None = None,
    project_renaming_id: int | None = None,
):
    sections = []
    for project in projects:
        nbs = notebooks_by_project.get(project.id, [])
        sections.append(
            _project_section(
                project, nbs, active_id,
                menu_id=menu_id,
                renaming_id=renaming_id,
                project_menu_id=project_menu_id,
                project_renaming_id=project_renaming_id,
            )
        )

    return Div(
        {
            "id": "sidebar",
            "class": "fixed left-0 top-12 w-56 h-[calc(100vh-3rem)] bg-zinc-900 "
            "border-r border-zinc-800 p-4 overflow-y-auto z-30",
        },
        Div(
            {"class": "text-xs font-semibold text-zinc-500 uppercase tracking-wider mb-3"},
            "Notebooks",
        ),
        *sections,
        Button(
            data.on("click", at.post("/project/new")),
            {
                "class": "block w-full text-left px-3 py-2 rounded-md text-sm mt-4 text-zinc-500 "
                "hover:text-indigo-400 hover:bg-zinc-800 transition-colors "
                "border border-dashed border-zinc-700 cursor-pointer",
            },
            "+ New Project",
        ),
        # Import .ipynb — file input hidden, label acts as button
        Label(
            {
                "for": "ipynb-upload",
                "class": "block w-full text-left px-3 py-2 rounded-md text-sm mt-1 text-zinc-500 "
                "hover:text-indigo-400 hover:bg-zinc-800 transition-colors "
                "border border-dashed border-zinc-700 cursor-pointer",
            },
            "↑ Import .ipynb",
        ),
        Input({
            "id": "ipynb-upload",
            "type": "file",
            "accept": ".ipynb",
            "class": "hidden",
            "data-on:change": (
                "const f=evt.target.files[0];"
                "if(!f)return;"
                "const r=new FileReader();"
                "r.onload=()=>{"
                "fetch('/nb/import',{method:'POST',"
                "headers:{'Content-Type':'application/json'},"
                "body:JSON.stringify({name:f.name,content:r.result})"
                "}).then(r=>r.json()).then(d=>{"
                "if(d.id)window.location.href='/nb/'+d.id;"
                "});"
                "evt.target.value='';"
                "};"
                "r.readAsText(f)"
            ),
        }),
    )


def execution_indicator():
    return Div(
        Div(
            data.show("$executing"),
            {"class": "fixed bottom-4 left-60 flex items-center gap-2 text-sm text-zinc-400", "style": "display:none"},
            _SPINNER_SVG,
            "executing…",
        ),
        Div(
            data.show("!$executing && $last_status === 'ok'"),
            {
                "class": "fixed bottom-4 left-60 flex items-center gap-2 text-sm text-green-400",
                "style": "display:none",
            },
            "✓ done",
        ),
        Div(
            data.show("!$executing && $last_status === 'error'"),
            {
                "class": "fixed bottom-4 left-60 flex items-center gap-2 text-sm text-red-400",
                "style": "display:none",
            },
            "✗ error",
        ),
    )


def _render_output_block(block: dict):
    """Render a single {mime, data} output block."""
    mime = block.get("mime", "text/plain")
    content = block.get("data", "")
    if mime in ("image/png", "image/jpeg"):
        return Img({"src": f"data:{mime};base64,{content}", "class": "max-w-full rounded my-2"})
    if mime == "image/svg+xml":
        return Div(
            {"class": "bg-white rounded p-2 my-2 inline-block"},
            SafeString(content),
        )
    if mime == "text/html":
        return Div({"class": "prose prose-invert prose-sm max-w-none my-2"}, SafeString(content))
    # text/plain fallback
    return Pre(
        {"class": "font-mono text-sm whitespace-pre-wrap break-words"},
        SafeString(ansi_to_html(content)),
    )


_COLLAPSE_THRESHOLD = 20  # lines before collapsing
_COLLAPSE_PREVIEW = 5     # lines shown when collapsed


def _collapsible_text(output: str, base_class: str, id_attr: dict):
    """Render large text output with collapse/expand toggle."""
    lines = output.split("\n")
    total = len(lines)
    if total <= _COLLAPSE_THRESHOLD:
        return Pre(
            id_attr,
            {"class": base_class + " font-mono text-sm whitespace-pre-wrap break-words"},
            SafeString(ansi_to_html(output)),
        )

    preview = "\n".join(lines[:_COLLAPSE_PREVIEW])
    sig = f"out_col_{id_attr.get('id', 'x').replace('output-', '')}"
    btn_class = (
        "mt-1 text-xs text-indigo-400 hover:text-indigo-300 cursor-pointer"
    )
    return Div(
        id_attr,
        data.signals({sig: True}),
        # Collapsed view
        Div(
            data.show(f"${sig}"),
            Pre(
                {"class": base_class + " font-mono text-sm whitespace-pre-wrap break-words"},
                SafeString(ansi_to_html(preview)),
            ),
            Button(
                data.on("click", f"${sig} = false"),
                {"class": btn_class},
                f"Show {total - _COLLAPSE_PREVIEW} more lines…",
            ),
        ),
        # Expanded view
        Div(
            data.show(f"!${sig}"),
            {"style": "display:none"},
            Pre(
                {"class": base_class + " font-mono text-sm whitespace-pre-wrap break-words"},
                SafeString(ansi_to_html(output)),
            ),
            Button(
                data.on("click", f"${sig} = true"),
                {"class": btn_class},
                "Collapse",
            ),
        ),
    )


def _render_output(output: str, is_error: bool, cell_id: int | None = None):
    """Render cell output — handles both plain text and rich JSON blocks."""
    id_attr = {"id": f"output-{cell_id}"} if cell_id else {}

    if not output:
        return Div(id_attr) if cell_id else SafeString("")

    base_class = (
        "mt-2 rounded-lg border p-4 overflow-x-auto "
        + ("border-red-900 bg-red-950 text-red-300" if is_error
           else "border-zinc-700 bg-zinc-900 text-emerald-300")
    )

    # Try parsing as rich output (JSON list of {mime, data} blocks)
    if not is_error:
        try:
            blocks = json.loads(output)
            if isinstance(blocks, list) and blocks and "mime" in blocks[0]:
                return Div(
                    id_attr,
                    {"class": base_class},
                    *[_render_output_block(b) for b in blocks],
                )
        except (json.JSONDecodeError, TypeError, KeyError):
            pass

    # Plain text — use collapsible for large outputs
    return _collapsible_text(output, base_class, id_attr)


def _cell_toolbar(cell: Cell):
    """Row of small action buttons that appear on hover."""
    btn = (
        "px-1.5 py-0.5 rounded text-zinc-600 hover:text-zinc-200 "
        "hover:bg-zinc-700 transition-colors cursor-pointer text-xs"
    )
    type_label = "MD" if cell.cell_type == "code" else "PY"
    type_title = "Convert to markdown" if cell.cell_type == "code" else "Convert to code"
    return Div(
        {"class": "opacity-0 group-hover:opacity-100 transition-opacity flex gap-1 mb-1 justify-end"},
        Button(
            data.on("click", at.post(f"/cells/convert/{cell.id}")),
            {"class": btn + " font-mono", "title": type_title},
            f"→ {type_label}",
        ),
        Button(data.on("click", at.post(f"/cells/move-up/{cell.id}")), {"class": btn, "title": "Move up"}, "▲"),
        Button(data.on("click", at.post(f"/cells/move-down/{cell.id}")), {"class": btn, "title": "Move down"}, "▼"),
        Button(data.on("click", at.post(f"/cells/duplicate/{cell.id}")), {"class": btn, "title": "Duplicate"}, "⊕"),
        Button(data.on("click", at.post(f"/cells/delete/{cell.id}")), {"class": btn + " hover:text-red-400", "title": "Delete"}, "✕"),
    )


def _fmt_time(secs: float) -> str:
    """Human-friendly execution time."""
    if secs < 60:
        return f"{secs:.2f}s"
    m, s = divmod(int(secs), 60)
    if m < 60:
        return f"{m}m {s:02d}s"
    h, m = divmod(m, 60)
    return f"{h}h {m:02d}m"


def _exec_label(prefix: str, count: int, time: float = 0.0):
    """Render In [N]: or Out[N]: label, positioned absolutely to the left."""
    n = str(count) if count > 0 else " "
    return Div(
        {"class": "absolute -left-16 top-2 text-xs font-mono text-zinc-500 select-none w-14 text-right"},
        Div(f"{prefix}[{n}]:"),
        Div({"class": "text-[10px] text-zinc-600"}, _fmt_time(time)) if time > 0 else SafeString(""),
    )


def _code_cell_view(cell: Cell):
    is_error = cell.status == "error"
    sig = f"cell_{cell.id}"
    return Div(
        {"class": "mb-6 group", "data-cell-container": str(cell.id)},
        _cell_toolbar(cell),
        data.signals({sig: cell.input}),
        Div(
            {"class": "relative"},
            _exec_label("In", cell.execution_count),
            Div(
                {"class": "relative"},
                # CM6 mount point — app.js creates the editor here
                Div(
                    {
                        "data-cell-id": str(cell.id),
                        "data-cell-type": "code",
                        "class": "w-full min-h-[5.5rem] rounded-lg border border-zinc-700 "
                        "overflow-hidden focus-within:border-indigo-500 transition-colors",
                    },
                ),
                # Hidden textarea keeps Datastar signal in sync for run button
                Textarea(
                    cell.input,
                    data.bind(sig),
                    {"data-cell-sync": str(cell.id), "class": "hidden"},
                ),
                # Initial content for CM6 — pad to 3 lines minimum for clean display
                Script(
                    {"type": "application/json", "data-cell-content": str(cell.id)},
                    SafeString(json.dumps(cell.input if cell.input.count("\n") >= 2 else cell.input + "\n" * (2 - cell.input.count("\n")))),
                ),
                Div(
                    {
                        "id": f"signature-{cell.id}",
                        "class": "hidden absolute z-50 max-w-xl max-h-56 overflow-y-auto "
                        "bg-zinc-900 border border-indigo-800 rounded-lg shadow-xl "
                        "px-3 py-2 font-mono text-xs text-zinc-300 whitespace-pre-wrap",
                    }
                ),
            ),
        ),
        # Hidden button — Shift+Enter clicks this to trigger Datastar indicator
        Button(
            data.on("click", at.post(f"/cells/execute/{cell.id}", include=[sig])),
            data.indicator("executing"),
            {"id": f"run-btn-{cell.id}", "class": "hidden"},
        ),
        # Status hint
        Div(
            {"class": "mt-1 flex items-center gap-2 text-xs"},
            SafeString(""),
            Span({"class": "text-green-400"}, "✓") if cell.status == "ok" else SafeString(""),
            Span({"class": "text-red-400"}, "✗") if cell.status == "error" else SafeString(""),
        ),
        Div(
            {"class": "relative"},
            _exec_label("Out", cell.execution_count, cell.execution_time) if cell.output and cell.output != "(no output)" else SafeString(""),
            _render_output(cell.output, is_error, cell.id) if cell.output and cell.output != "(no output)" else SafeString(""),
        ),
    )


def _markdown_cell_view(cell: Cell):
    sig = f"cell_{cell.id}"
    rendered = _md.render(cell.input) if cell.input else "<p class='text-zinc-600 italic'>empty markdown cell</p>"
    return Div(
        {"class": "mb-6 group", "data-cell-container": str(cell.id)},
        _cell_toolbar(cell),
        data.signals({sig: cell.input}),
        # Rendered markdown (click to edit)
        Div(
            {
                "id": f"md-display-{cell.id}",
                "class": "prose prose-invert prose-sm max-w-none p-4 rounded-lg "
                "border border-zinc-800 hover:border-zinc-600 transition-colors cursor-text "
                "overflow-x-auto",
            },
            data.on(
                "dblclick",
                f"document.getElementById('md-edit-{cell.id}').classList.remove('hidden');"
                f"document.getElementById('md-display-{cell.id}').classList.add('hidden');"
                f"var _ta=document.querySelector('#md-edit-{cell.id} textarea');"
                f"_ta.focus();_ta.style.height='auto';_ta.style.height=_ta.scrollHeight+'px'",
            ),
            SafeString(rendered),
        ),
        # Edit mode (hidden by default)
        Div(
            {
                "id": f"md-edit-{cell.id}",
                "class": "hidden",
            },
            Textarea(
                cell.input,
                data.bind(sig),
                {
                    "data-cell-id": str(cell.id),
                    "spellcheck": "false",
                    "class": (
                        "w-full min-h-[4.5rem] p-3 bg-zinc-900 border border-zinc-700 rounded-lg "
                        "text-zinc-200 font-mono text-sm leading-relaxed resize-none outline-none "
                        "focus:border-indigo-500 transition-colors overflow-hidden"
                    ),
                },
            ),
            SafeString(""),
        ),
        # Hidden button — Shift+Enter saves markdown and re-renders
        Button(
            data.on("click", at.post(f"/cells/save-md/{cell.id}", include=[sig])),
            {"id": f"run-btn-{cell.id}", "class": "hidden"},
        ),
    )


def cell_view(cell: Cell):
    if cell.cell_type == "markdown":
        return _markdown_cell_view(cell)
    return _code_cell_view(cell)


def notebook(cells: list[Cell], nb_id: int):
    """Full notebook div — SSE-patched on every change."""
    btn_class = (
        "px-4 py-1.5 border border-zinc-700 text-zinc-400 rounded-md "
        "text-sm hover:border-indigo-500 hover:text-indigo-400 transition-colors cursor-pointer"
    )
    return Div(
        {"id": "notebook", "class": "w-full transition-all duration-200"},
        data.class_("max-w-3xl", "!$wide_mode"),
        *[cell_view(c) for c in cells],
        Div(
            {"class": "mt-2 flex gap-2"},
            Button(
                data.on("click", at.post("/cells/new", include=["notebook_id"])),
                {"class": btn_class},
                "+ Code",
            ),
            Button(
                data.on("click", at.post("/cells/new-md", include=["notebook_id"])),
                {"class": btn_class},
                "+ Markdown",
            ),
        ),
    )


def variables_panel():
    """Right sidebar for kernel variables — fetched via polling when visible."""
    return Div(
        data.show("$show_vars"),
        {
            "id": "vars-panel",
            "class": "fixed right-0 top-12 w-72 h-[calc(100vh-3rem)] bg-zinc-900 "
            "border-l border-zinc-800 overflow-y-auto z-30",
            "style": "display:none",
        },
        Div(
            {"class": "p-4"},
            Div(
                {"class": "flex items-center justify-between mb-3"},
                Span({"class": "text-xs font-semibold text-zinc-500 uppercase tracking-wider"}, "Variables"),
                Button(
                    data.on("click", "$show_vars = false"),
                    {"class": "text-xs text-zinc-600 hover:text-zinc-300 cursor-pointer"},
                    "✕",
                ),
            ),
            Div({"id": "vars-content", "class": "text-xs font-mono text-zinc-400"}, "Loading..."),
        ),
    )


def page(
    nb: Notebook,
    projects: list[Project],
    notebooks_by_project: dict[int, list[Notebook]],
    cells: list[Cell],
    url_for: UrlFor,
    envs: list[EnvInfo] | None = None,
):
    """Full HTML shell — only used for the initial GET /nb/{id}."""
    return Html(
        Head(
            Meta({"charset": "utf-8"}),
            Meta({"name": "viewport", "content": "width=device-width, initial-scale=1"}),
            Title(f"{nb.name} — grokbook"),
            Script({"src": "https://cdn.tailwindcss.com?plugins=typography"}),
            DatastarScript(),
            SafeString(
                "<style>"
                ".light-mode { filter: invert(1) hue-rotate(180deg); }"
                ".light-mode img, .light-mode svg, .light-mode video, "
                ".light-mode [data-no-invert] { filter: invert(1) hue-rotate(180deg); }"
                "/* Pandas DataFrame tables */"
                ".dataframe { width: auto !important; border-collapse: collapse; font-size: 0.8125rem; font-family: ui-monospace, monospace; }"
                ".dataframe th, .dataframe td { padding: 0.25rem 0.625rem; border: none; border-bottom: 1px solid #27272a; text-align: right; white-space: nowrap; }"
                ".dataframe td:first-child, .dataframe th:first-child { text-align: left; }"
                ".dataframe thead th { color: #a1a1aa; font-weight: 500; border-bottom: 1px solid #3f3f46; padding-bottom: 0.375rem; }"
                ".dataframe tbody th { color: #52525b; font-weight: 400; }"
                ".dataframe tbody tr:hover { background: #18181b; }"
                "</style>"
            ),
            Script(SafeString(
                "(function(){var t=localStorage.getItem('nb-theme');"
                "var w=localStorage.getItem('nb-wide')==='true';"
                "var ac=localStorage.getItem('nb-autocomplete')!=='false';"
                "var lw=localStorage.getItem('nb-linewrap')==='true';"
                "var vm=localStorage.getItem('nb-vim')==='true';"
                "if(t==='light'){document.documentElement.classList.add('light-mode');}"
                "document.addEventListener('DOMContentLoaded',function(){"
                "var b=document.body;if(b){var s=JSON.parse(b.getAttribute('data-signals')||'{}');"
                "if(t==='light')s.light_mode=true;"
                "if(w)s.wide_mode=true;"
                "s.editor_autocomplete=ac;s.editor_linewrap=lw;s.editor_vim=vm;"
                "b.setAttribute('data-signals',JSON.stringify(s));}});})()"
            )),
        ),
        Body(
            {
                "class": "min-h-screen bg-zinc-950 text-zinc-200",
                "data-notebook-id": str(nb.id),
            },
            data.signals(
                {
                    "notebook_id": nb.id,
                    "executing": False,
                    "restarting": False,
                    "last_status": "",
                    "focus_cell": "",
                    "kernel_state": "idle",
                    "kernel_env": nb.kernel_env or "",
                    "pending_env_path": "",
                    "install_env_path": "",
                    "install_env_name": "",
                    "install_running": False,
                    "install_done": False,
                    "install_ok": False,
                    "show_vars": False,
                    "show_settings": False,
                    "wide_mode": False,
                    "light_mode": False,
                    "editor_autocomplete": True,
                    "editor_linewrap": False,
                    "editor_vim": False,
                    **{f"proj_{p.id}_open": True for p in projects},
                }
            ),
            # Reconnect SSE whenever $notebook_id changes so the server-side
            # stream's captured nb_id stays in sync with the client's view.
            data.effect("$notebook_id; @get('/events', {retryInterval: 2000, retryMaxCount: 0})"),
            Span(
                data.effect("document.body.dataset.notebookId=String($notebook_id)"),
                {"style": "display:none"},
            ),
            Span(
                data.effect(
                    "document.documentElement.classList.toggle('light-mode',$light_mode);"
                    "localStorage.setItem('nb-theme',$light_mode?'light':'dark')"
                ),
                {"style": "display:none"},
            ),
            Span(
                data.effect("localStorage.setItem('nb-wide',String($wide_mode))"),
                {"style": "display:none"},
            ),
            Span(
                data.effect(
                    "localStorage.setItem('nb-autocomplete',String($editor_autocomplete));"
                    "localStorage.setItem('nb-linewrap',String($editor_linewrap));"
                    "localStorage.setItem('nb-vim',String($editor_vim));"
                    "window._applyEditorSettings&&window._applyEditorSettings("
                    "$editor_autocomplete,$editor_linewrap,$editor_vim)"
                ),
                {"style": "display:none"},
            ),
            Span(
                data.effect(
                    "if($focus_cell){"
                    "var cm=window._cmEditors&&window._cmEditors.get($focus_cell);"
                    "if(cm){cm.focus();}else{"
                    "var el=document.querySelector('textarea[data-cell-id=\"'+$focus_cell+'\"]');"
                    "if(el){el.focus();}}$focus_cell='';}"
                ),
                {"style": "display:none"},
            ),
            header_bar(envs or []),
            Div(
                {"class": "flex pt-12"},
                sidebar_view(nb.id, projects, notebooks_by_project),
                Div(
                    {"class": "flex-1 flex justify-center py-10 px-4 pl-20 ml-56 min-w-0 overflow-x-hidden"},
                    notebook(cells, nb.id),
                ),
            ),
            execution_indicator(),
            variables_panel(),
            install_modal(),
            Script({"src": url_for("static", "js/codemirror.js")}),
            Script({"src": url_for("static", "js/app.js")}),
        ),
    )
