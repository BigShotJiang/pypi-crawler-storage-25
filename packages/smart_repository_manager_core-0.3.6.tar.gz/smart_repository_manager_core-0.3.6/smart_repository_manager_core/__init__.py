# Copyright (©) 2026, Alexander Suvorov. All rights reserved.
"""
Smart Repository Manager Core
"""

__version__ = "0.3.6"
__author__ = "Alexander Suvorov"