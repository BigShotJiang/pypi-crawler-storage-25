"""three.js-compatible geometry serialization for build123d parts.

Uses ``Part.tessellate()`` which calls the same OCC ``BRepMesh`` pipeline as
ocp_vscode, returning indexed geometry directly with no intermediate file I/O.
Normals are omitted from the payload; three.js computes them client-side via
``geometry.computeVertexNormals()``.
"""

from build123d import Part
import logging

_log = logging.getLogger("partomatic")


def part_to_mesh(
    part: Part, tolerance: float = 0.1, angular_tolerance: float = 0.5
) -> dict:
    """Tessellate a build123d Part into a three.js-compatible indexed mesh dict.

    Returns indexed geometry for a build123d Part compatible with three.js.

    Args:
        part: A build123d Part object.
        tolerance: Linear deflection for mesh quality (smaller = finer).
        angular_tolerance: Angular deflection in radians for curved surfaces.

    Returns:
        Dict with ``vertices`` (flat float list, 3 per vertex) and ``indices``
        (flat int list, 3 per triangle, 0-based).
    """

    vertices_raw, triangles = part.tessellate(tolerance, angular_tolerance)
    vertices = [coord for v in vertices_raw for coord in (v.X, v.Y, v.Z)]
    indices = [idx for tri in triangles for idx in tri]
    return {"vertices": vertices, "indices": indices}


def serialize_parts(display_parts: list[Part]) -> dict:
    """Serialize a list of placed build123d Parts to a three.js viewer payload.

    Each part is tessellated independently. Parts that fail tessellation are
    skipped with an error log so a single bad part does not abort the render.

    Args:
        display_parts: List of build123d Part objects to serialize.

    Returns:
        Dict with a ``parts`` key containing per-part indexed mesh data::

            {
                "parts": [
                    {"id": 0, "vertices": [...], "indices": [...]},
                    ...
                ]
            }
    """
    parts_data = []
    for i, part in enumerate(display_parts):
        try:
            mesh = part_to_mesh(part)
            parts_data.append({"id": i, **mesh})
        except Exception:
            _log.exception("Failed to serialize part %d for three.js viewer", i)
    return {"parts": parts_data}
