__package__ = "partomatic"

if __name__ == "__main__":
    import os, sys

    script_dir = os.path.dirname(os.path.abspath(__file__))
    src_root = os.path.dirname(script_dir)
    # Remove the script directory so 'partomatic' resolves to the package, not this file
    if script_dir in sys.path:
        sys.path.remove(script_dir)
    if src_root not in sys.path:
        sys.path.insert(0, src_root)

"""Part automation utilities: compile, preview, and export workflows."""

from dataclasses import field
from abc import ABC, abstractmethod
from copy import deepcopy
from functools import wraps
import inspect
import os
from pathlib import Path
from typing import Optional

from build123d import Location, export_step, export_stl
import ocp_vscode

import logging

from partomatic.viewer_geometry import serialize_parts

from partomatic.partomatic_config import PartomaticConfig
from partomatic.automatable_part import AutomatablePart
from partomatic.partomatic_preview import PartomaticPreviewMixin
from partomatic.observability import get_logger, log_event

_log = get_logger(__name__, app_mode="cli")


class Partomatic(PartomaticPreviewMixin, ABC):
    """Base class for automatable CAD parts.

    Subclasses provide `compile()` to populate `self.parts`, while this class
    supplies display, export, configuration-loading, and preview/configurator
    launch helpers.
    """

    config: PartomaticConfig
    parts: list[AutomatablePart] = field(default_factory=list)
    _viewer_geometry: Optional[dict] = None

    def __init_subclass__(cls, **kwargs):
        """Wrap subclass compile methods once to keep dirty-state tracking automatic."""
        super().__init_subclass__(**kwargs)

        compile_method = cls.__dict__.get("compile")
        if compile_method is None:
            return
        if getattr(compile_method, "_partomatic_wrapped", False):
            return

        @wraps(compile_method)
        def compile_with_tracking(self, *args, **kwargs):
            result = compile_method(self, *args, **kwargs)
            self._mark_compiled()
            return result

        compile_with_tracking._partomatic_wrapped = True
        cls.compile = compile_with_tracking

    @abstractmethod
    def compile(self):
        """Build the part geometry and populate `self.parts`."""

    def _display_parts(self) -> list:
        """Return deep-copied parts with display transforms applied."""
        return [deepcopy(part.part).move(part.display_location) for part in self.parts]

    def _validate_filename_component(self, value: str, field_name: str) -> str:
        """Reject path-like filename components before building export paths."""
        text = str(value)
        separators = {"/", "\\", os.sep}
        if os.altsep:
            separators.add(os.altsep)
        if any(separator and separator in text for separator in separators):
            raise ValueError(f"{field_name} must not contain path separators")
        return text

    def _ensure_path_within_root(self, export_root: Path, export_path: Path) -> Path:
        """Ensure export_path stays inside export_root after resolution."""
        resolved_root = export_root.resolve()
        resolved_path = export_path.resolve()
        try:
            resolved_path.relative_to(resolved_root)
        except ValueError as error:
            raise ValueError(
                "Export path escapes the configured export directory"
            ) from error
        return resolved_path

    def generate_viewer_geometry(self) -> dict:
        """Build and cache three.js viewer payload from current parts."""
        self._viewer_geometry = serialize_parts(self._display_parts())
        return self._viewer_geometry

    def display(
        self,
        viewer_host: Optional[str] = None,
        viewer_port: Optional[int] = None,
    ):
        """Show current parts in the OCP CAD viewer.

        If `viewer_port` is provided, the standalone endpoint is configured
        via `ocp_vscode.set_port(...)`. Otherwise display uses ocp_vscode's
        default integration behavior.

        Args:
            viewer_host: Hostname used with `viewer_port` for standalone viewer.
            viewer_port: Standalone viewer port to target.
        """
        if viewer_port is not None:
            ocp_vscode.set_port(viewer_port, host=viewer_host or "127.0.0.1")
        ocp_vscode.show_clear()
        display_parts = [
            deepcopy(part.part).move(part.display_location) for part in self.parts
        ]
        ocp_vscode.show(display_parts)

    def complete_stl_file_path(self, part: AutomatablePart) -> str:
        """Return the final STL file path for a part.

        Args:
            part: Part metadata used to derive export path components.

        Returns:
            Absolute or source-relative resolved STL path as a string.
        """
        return str(self._complete_export_file_path(part, ".stl"))

    def complete_step_file_path(self, part: AutomatablePart) -> str:
        """Return the final STEP file path for a part.

        Args:
            part: Part metadata used to derive export path components.

        Returns:
            Absolute or source-relative resolved STEP path as a string.
        """
        return str(self._complete_export_file_path(part, ".step"))

    def _complete_export_file_path(
        self,
        part: AutomatablePart,
        suffix: str,
        output_dir: Optional[str | Path] = None,
    ) -> Path:
        """Build the export path for a part and file suffix.

        Args:
            part: Part metadata containing base file name and default folder.
            suffix: File suffix such as `.stl` or `.step`.
            output_dir: Optional override directory for exports.

        Returns:
            Resolved filesystem path for the target export file.
        """
        export_root = (
            Path(output_dir) if output_dir is not None else Path(part.stl_folder)
        )
        if not export_root.is_absolute():
            export_root = self._source_dir / export_root
        file_prefix = self._validate_filename_component(
            self.config.file_prefix, "file_prefix"
        )
        file_suffix = self._validate_filename_component(
            self.config.file_suffix, "file_suffix"
        )
        export_path = (
            export_root / f"{file_prefix}{part.file_name_base}{file_suffix}"
        ).with_suffix(suffix)
        return self._ensure_path_within_root(export_root, export_path)

    def _export_parts(
        self,
        suffix: str,
        exporter,
        output_dir: Optional[str | Path] = None,
    ) -> list[Path]:
        """Export all compiled parts with a common suffix.

        Args:
            suffix: Output file suffix for each exported part.
            exporter: Callable that writes one part to one file path.
            output_dir: Optional override directory for exports.

        Returns:
            Paths written by the exporter, in part order.

        Raises:
            FileNotFoundError: If the export directory cannot be created/found.
        """
        if output_dir is None and self.config.stl_folder == "NONE":
            log_event(
                _log,
                logging.WARNING,
                "export.skipped",
                outcome="success",
                app_mode="cli",
                reason="stl_folder_none",
            )
            return []

        exported_paths = []
        log_event(
            _log,
            logging.INFO,
            "export.started",
            app_mode="cli",
            export_format=suffix.lstrip("."),
            part_count=len(self.parts),
        )
        for part in self.parts:
            export_path = self._complete_export_file_path(part, suffix, output_dir)
            if not export_path.parent.exists():
                export_path.parent.mkdir(
                    parents=True,
                    exist_ok=self.config.create_folders_if_missing,
                )
            if not export_path.parent.exists() or not export_path.parent.is_dir():
                error_str = f"Directory {export_path.parent} does not exist."
                _log.warning(error_str)
                log_event(
                    _log,
                    logging.ERROR,
                    "export.failed",
                    outcome="failure",
                    app_mode="cli",
                    export_format=suffix.lstrip("."),
                    error_type="io_error",
                    error_message=error_str,
                    export_path=str(export_path.parent),
                )
                raise FileNotFoundError(error_str)
            exporter(part.part, str(export_path))
            exported_paths.append(export_path)
        log_event(
            _log,
            logging.INFO,
            "export.succeeded",
            app_mode="cli",
            export_format=suffix.lstrip("."),
            exported_count=len(exported_paths),
        )
        return exported_paths

    def export_stls(self):
        """Generate STL exports in the configured output folder."""
        return self._export_parts(".stl", export_stl)

    def export_steps(self):
        """Generate STEP exports in the configured output folder."""
        return self._export_parts(".step", export_step)

    def export_stls_to_directory(self, output_dir: str | Path):
        """Generate STL exports into a specific directory."""
        return self._export_parts(".stl", export_stl, output_dir=output_dir)

    def export_steps_to_directory(self, output_dir: str | Path):
        """Generate STEP exports into a specific directory."""
        return self._export_parts(".step", export_step, output_dir=output_dir)

    def _config_snapshot(self) -> dict:
        """Return a deep-copied snapshot of current config values."""
        return deepcopy(self.config.as_dict())

    def _mark_compiled(self):
        """Store the current config snapshot as the compiled baseline."""
        self._compiled_config_snapshot = self._config_snapshot()

    @property
    def is_dirty(self) -> bool:
        """Whether config has changed since the last successful compile."""
        if self._compiled_config_snapshot is None:
            return True
        return self._config_snapshot() != self._compiled_config_snapshot

    def load_config(self, configuration: any, **kwargs):
        """Load configuration into this Partomatic instance.

        Args:
            configuration: Configuration source forwarded to
                `self.config.load_config(...)` (commonly a file path, YAML
                string, compatible config object, or `None`).
            **kwargs: Field overrides applied by the configuration loader.
        """

        log_event(
            _log,
            logging.DEBUG,
            "config.load.started",
            app_mode="cli",
            has_configuration=configuration is not None,
            override_count=len(kwargs),
        )
        try:
            self.config.load_config(configuration, **kwargs)
        except Exception as ex:
            log_event(
                _log,
                logging.ERROR,
                "config.load.failed",
                outcome="failure",
                app_mode="cli",
                error_type=ex.__class__.__name__,
                error_message=str(ex),
            )
            raise
        log_event(
            _log,
            logging.INFO,
            "config.load.succeeded",
            app_mode="cli",
            override_count=len(kwargs),
        )

    def __init__(self, configuration: any = None, **kwargs):
        """Initialize part state and load configuration.

        Args:
            configuration: Optional configuration source passed to `load_config`.
            **kwargs: Field overrides passed to `load_config`.
        """
        self.parts = []
        # Treat class-level config as a template and clone per instance to avoid
        # shared mutable state across Partomatic objects.
        template_config = getattr(self.__class__, "config", None)
        if not isinstance(template_config, PartomaticConfig):
            raise TypeError(
                f"{self.__class__.__name__}.config must be a PartomaticConfig instance"
            )
        self.config = deepcopy(template_config)
        self._source_dir = Path(inspect.getfile(self.__class__)).parent
        self._compiled_config_snapshot = None
        self._init_preview_state()
        self.load_config(configuration, **kwargs)

    def partomate(self, export_steps: bool = False):
        """Compile this part and export output files.

        Args:
            export_steps: When True, also export STEP files.

        Notes:
            Override `export_stls()` and/or `export_steps()` if a subclass wants
            custom export behavior or to disable a format.
        """
        log_event(
            _log,
            logging.INFO,
            "partomate.started",
            app_mode="cli",
            export_steps=export_steps,
        )
        try:
            self.compile()
            self.export_stls()
            if export_steps:
                self.export_steps()
        except Exception as ex:
            log_event(
                _log,
                logging.ERROR,
                "partomate.failed",
                outcome="failure",
                app_mode="cli",
                error_type=ex.__class__.__name__,
                error_message=str(ex),
            )
            _log.error(str(ex))
            raise
        log_event(
            _log,
            logging.INFO,
            "partomate.succeeded",
            app_mode="cli",
            export_steps=export_steps,
        )


if __name__ == "__main__":
    from build123d import BuildPart, Box, Sphere, Mode

    class DemoConfig(PartomaticConfig):
        stl_folder: str = "NONE"
        size: float = 20.0
        sphere_ratio: float = field(
            default=0.6,
            metadata={
                "kind": "float",
                "constraints": {"ge": 0.1, "le": 0.86},
                "step": 0.01,
            },
        )

    class DemoPart(Partomatic):
        config: DemoConfig = DemoConfig()

        def compile(self):
            self.parts.clear()
            with BuildPart() as cube:
                Box(
                    self.config.size,
                    self.config.size,
                    self.config.size,
                )
                Sphere(self.config.size * self.config.sphere_ratio, mode=Mode.SUBTRACT)
            with BuildPart() as ball:
                Box(
                    self.config.size,
                    self.config.size,
                    self.config.size,
                )
                Sphere(self.config.size * self.config.sphere_ratio, mode=Mode.INTERSECT)
            cube.part.label = "cube"
            ball.part.label = "ball"
            self.parts.append(
                AutomatablePart(
                    cube.part,
                    "demo-cube",
                    display_location=Location(
                        (self.config.size / 2 + self.config.size / 4, 0, 0)
                    ),
                    stl_folder=self.config.stl_folder,
                )
            )
            self.parts.append(
                AutomatablePart(
                    ball.part,
                    "demo-ball",
                    display_location=Location(
                        (-self.config.size / 2 - self.config.size / 4, 0, 0)
                    ),
                    stl_folder=self.config.stl_folder,
                ),
            )

    print("Starting Partomatic configurator demo.")
    demo = DemoPart()
    demo.config.enable_step_exports = True
    demo.launch_configurator(host="0.0.0.0", port=8585)
