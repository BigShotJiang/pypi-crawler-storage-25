"""Common logging utilities for Partomatic runtime observability.

This module intentionally uses only the standard logging package so users
without a telemetry stack still get useful diagnostics.
"""

from __future__ import annotations

from datetime import datetime, timezone
import json
import logging
import os
import sys
from typing import Any

_LOGGER_NAMESPACE = "partomatic"
_DEFAULT_LOG_LEVEL = "INFO"
_DEFAULT_LOG_FORMAT = "console"
_DEFAULT_APP_MODE = "cli"
_DEFAULT_DEPLOYMENT_ENV = "dev"
_RESERVED_RECORD_KEYS = set(logging.makeLogRecord({}).__dict__.keys())


class PartomaticJsonFormatter(logging.Formatter):
    """Render log records as compact JSON with stable event fields."""

    _STANDARD_ATTRS = {
        "args",
        "asctime",
        "created",
        "exc_info",
        "exc_text",
        "filename",
        "funcName",
        "levelname",
        "levelno",
        "lineno",
        "module",
        "msecs",
        "message",
        "msg",
        "name",
        "pathname",
        "process",
        "processName",
        "relativeCreated",
        "stack_info",
        "thread",
        "threadName",
    }

    def format(self, record: logging.LogRecord) -> str:
        payload: dict[str, Any] = {
            "timestamp": datetime.fromtimestamp(record.created, tz=timezone.utc)
            .isoformat()
            .replace("+00:00", "Z"),
            "severity": record.levelname,
            "message": record.getMessage(),
            "logger": record.name,
            "event.name": getattr(record, "event_name", "log"),
            "event.outcome": getattr(record, "event_outcome", "success"),
            "app.mode": getattr(record, "app_mode", _default_app_mode()),
            "deployment.environment": getattr(
                record,
                "deployment_environment",
                _default_deployment_environment(),
            ),
        }

        for key, value in record.__dict__.items():
            if key in self._STANDARD_ATTRS:
                continue
            if key.startswith("_"):
                continue
            if key in (
                "event_name",
                "event_outcome",
                "app_mode",
                "deployment_environment",
            ):
                continue
            payload[key] = value

        if record.exc_info:
            payload["error.type"] = record.exc_info[0].__name__
            payload["error.message"] = str(record.exc_info[1])

        return json.dumps(payload, separators=(",", ":"), default=str)


def _default_app_mode() -> str:
    return os.getenv("PARTOMATIC_APP_MODE", _DEFAULT_APP_MODE)


def _default_deployment_environment() -> str:
    return os.getenv("PARTOMATIC_DEPLOYMENT_ENV", _DEFAULT_DEPLOYMENT_ENV)


def _normalize_log_level(raw: str | None) -> int:
    text = (raw or _DEFAULT_LOG_LEVEL).strip().upper()
    return getattr(logging, text, logging.INFO)


def _normalize_log_format(raw: str | None, app_mode: str | None) -> str:
    if raw:
        text = raw.strip().lower()
        if text in ("console", "json"):
            return text
    mode = (app_mode or _default_app_mode()).strip().lower()
    if mode == "configurator":
        return "json"
    return _DEFAULT_LOG_FORMAT


def configure_logging(app_mode: str | None = None) -> logging.Logger:
    """Configure the partomatic logger once and return it."""
    logger = logging.getLogger(_LOGGER_NAMESPACE)
    if getattr(logger, "_partomatic_configured", False):
        return logger

    logger.handlers.clear()
    handler = logging.StreamHandler(sys.stdout)

    log_format = _normalize_log_format(os.getenv("PARTOMATIC_LOG_FORMAT"), app_mode)
    if log_format == "json":
        handler.setFormatter(PartomaticJsonFormatter())
    else:
        handler.setFormatter(
            logging.Formatter(
                "%(asctime)s %(levelname)s [%(name)s] %(message)s",
                "%Y-%m-%dT%H:%M:%S",
            )
        )

    logger.addHandler(handler)
    logger.setLevel(_normalize_log_level(os.getenv("PARTOMATIC_LOG_LEVEL")))
    logger.propagate = True
    logger._partomatic_configured = True
    return logger


def get_logger(name: str, app_mode: str | None = None) -> logging.Logger:
    """Return a namespaced Partomatic logger with shared configuration."""
    configure_logging(app_mode=app_mode)
    if name.startswith(_LOGGER_NAMESPACE):
        return logging.getLogger(name)
    return logging.getLogger(f"{_LOGGER_NAMESPACE}.{name}")


def log_event(
    logger: logging.Logger,
    level: int,
    event_name: str,
    outcome: str = "success",
    **fields: Any,
):
    """Emit a structured event via standard logging extras."""
    extra = {
        "event_name": event_name,
        "event_outcome": outcome,
        "app_mode": fields.pop("app_mode", _default_app_mode()),
        "deployment_environment": fields.pop(
            "deployment_environment",
            _default_deployment_environment(),
        ),
    }
    for key, value in fields.items():
        safe_key = key
        if safe_key in _RESERVED_RECORD_KEYS or safe_key in ("message", "asctime"):
            safe_key = f"field_{safe_key}"
        extra[safe_key] = value
    logger.log(level, event_name, extra=extra)
