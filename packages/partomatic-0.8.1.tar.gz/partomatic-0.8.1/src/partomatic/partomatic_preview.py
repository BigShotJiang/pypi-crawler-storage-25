"""Preview-state and launch helpers for Partomatic objects.

`compile()` remains the source of geometry generation (usually populating
`self.parts`).
"""

from enum import Enum
from threading import Thread


class PreviewState(Enum):
    """Preview lifecycle state for rendered geometry."""

    CLEAN = "clean"
    DIRTY = "dirty"
    RENDERING = "rendering"
    ERROR = "error"


class PartomaticPreviewMixin:
    """Preview state and launcher helpers for Partomatic classes."""

    def _init_preview_state(self):
        """Initialize preview state fields on the instance."""
        self._preview_state = PreviewState.DIRTY
        self._preview_error = None

    @property
    def preview_state(self) -> PreviewState:
        """Return computed preview state using dirty-tracking when available."""
        if self._preview_state in (PreviewState.RENDERING, PreviewState.ERROR):
            return self._preview_state
        if hasattr(self, "is_dirty"):
            return PreviewState.DIRTY if self.is_dirty else PreviewState.CLEAN
        return self._preview_state

    @property
    def preview_error(self) -> str | None:
        """Return the last preview error message, if any."""
        return self._preview_error

    def invalidate_preview(self):
        """Clear preview errors and mark stale state as dirty."""
        if self._preview_state == PreviewState.ERROR:
            self._preview_state = PreviewState.DIRTY
        self._preview_error = None

    def compile_for_preview(self):
        """Compile the model and update preview state transitions."""
        if hasattr(self, "is_dirty") and not self.is_dirty:
            self._preview_state = PreviewState.CLEAN
            self._preview_error = None
            return
        self._preview_state = PreviewState.RENDERING
        self._preview_error = None
        try:
            self.compile()
        except Exception as ex:
            self._preview_state = PreviewState.ERROR
            self._preview_error = str(ex)
            raise
        self._preview_state = PreviewState.CLEAN

    def launch_configurator(
        self,
        host: str = "localhost",
        port: int = 8505,
        port_retries: int = 10,
        background: bool = False,
    ):
        """Launch a combined configurator window: config form + 3D preview in one page.

        When any configuration field changes the preview is marked DIRTY and an overlay
        is shown on the viewer until the "Refresh" button is clicked.

        Args:
            host: NiceGUI server host.
            port: Starting port; incremented up to port_retries times if occupied.
            port_retries: Number of additional ports to try after start_port.
            background: When True run the UI server in a daemon thread.
        """
        try:
            import nicegui  # noqa: F401
        except ModuleNotFoundError as ex:
            raise ModuleNotFoundError(
                "Missing optional GUI dependencies. Install with: pip install partomatic[webui]"
            ) from ex

        from .configurator_app import run_configurator

        config_spec = self.config._editor_spec()

        kwargs = dict(
            preview_model=self,
            class_name=self.__class__.__name__,
            config_root_node=config_spec.get("root_node", "config"),
            config_fields_spec=config_spec.get("fields", {}),
            host=host,
            port=port,
            port_retries=port_retries,
        )

        if background:
            thread = Thread(
                target=run_configurator,
                kwargs=kwargs,
                daemon=True,
                name="partomatic-configurator",
            )
            thread.start()
            return thread

        return run_configurator(**kwargs)
