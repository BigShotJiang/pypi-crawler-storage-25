"""Combined single-window configurator for Partomatic: config editing + live 3D preview."""

__package__ = "partomatic"

if __name__ == "__main__":
    import os, sys

    script_dir = os.path.dirname(os.path.abspath(__file__))
    src_root = os.path.dirname(script_dir)
    # Avoid resolving 'partomatic' to this directory's modules during direct execution.
    if script_dir in sys.path:
        sys.path.remove(script_dir)
    if src_root not in sys.path:
        sys.path.insert(0, src_root)

import socket
import asyncio
import io
import inspect
import json
import logging
import os
from pathlib import Path
import tempfile
from threading import Lock, Thread
from typing import TYPE_CHECKING
import zipfile

from nicegui import ui
from pydantic import ValidationError
import yaml

from partomatic.config_editor_app import (
    _build_model,
    _collect_components,
    _component_value,
    _to_yaml_document,
)
from partomatic.partomatic_preview import PreviewState
from partomatic.observability import get_logger, log_event

if TYPE_CHECKING:
    from partomatic.partomatic import Partomatic


_log = get_logger(__name__, app_mode="configurator")

# ---------------------------------------------------------------------------
# Port utilities
# ---------------------------------------------------------------------------

MAX_PORT_RETRIES = 10
DEFAULT_MAX_YAML_UPLOAD_KB = 256
MAX_YAML_UPLOAD_KB_ENV = "PARTOMATIC_MAX_YAML_UPLOAD_KB"


def _yaml_upload_size_limit_kb() -> int:
    """Return max allowed YAML upload size in KB.

    The value is read from PARTOMATIC_MAX_YAML_UPLOAD_KB when present.
    Invalid or non-positive values fall back to the default (256 KB).
    """
    raw_kb = os.getenv(MAX_YAML_UPLOAD_KB_ENV)
    if raw_kb is None:
        return DEFAULT_MAX_YAML_UPLOAD_KB
    try:
        parsed = int(raw_kb)
    except (TypeError, ValueError):
        return DEFAULT_MAX_YAML_UPLOAD_KB
    if parsed <= 0:
        return DEFAULT_MAX_YAML_UPLOAD_KB
    return parsed


def _decode_uploaded_yaml(raw_data: bytes | str, max_bytes: int) -> str:
    """Validate uploaded YAML size and return decoded text."""
    if isinstance(raw_data, bytes):
        payload_size = len(raw_data)
        if payload_size > max_bytes:
            raise ValueError(f"Uploaded YAML exceeds maximum size of {max_bytes} bytes")
        return raw_data.decode("utf-8")

    if isinstance(raw_data, str):
        payload_size = len(raw_data.encode("utf-8"))
        if payload_size > max_bytes:
            raise ValueError(f"Uploaded YAML exceeds maximum size of {max_bytes} bytes")
        return raw_data

    raise ValueError("Uploaded file must be text YAML")


async def _extract_uploaded_text(upload_event, max_bytes: int | None = None) -> str:
    """Extract UTF-8 text content from a NiceGUI upload event.

    Args:
        upload_event: NiceGUI upload event object.

    Returns:
        Uploaded file content as text.

    Raises:
        ValueError: If no readable text content is present.
    """
    limit = max_bytes if max_bytes is not None else _yaml_upload_size_limit_kb() * 1024

    file_obj = getattr(upload_event, "file", None)
    if file_obj is not None:
        if hasattr(file_obj, "text"):
            maybe_text = file_obj.text("utf-8")
            if inspect.isawaitable(maybe_text):
                return _decode_uploaded_yaml(await maybe_text, limit)
            if isinstance(maybe_text, str):
                return _decode_uploaded_yaml(maybe_text, limit)

        if hasattr(file_obj, "read"):
            maybe_data = file_obj.read()
            raw_data = (
                await maybe_data if inspect.isawaitable(maybe_data) else maybe_data
            )
            if isinstance(raw_data, (bytes, str)):
                return _decode_uploaded_yaml(raw_data, limit)

    content = getattr(upload_event, "content", None)
    if content is None:
        raise ValueError("Uploaded file content is missing")

    if hasattr(content, "seek"):
        content.seek(0)

    if hasattr(content, "read"):
        raw_data = content.read()
    else:
        raw_data = content

    if isinstance(raw_data, (bytes, str)):
        return _decode_uploaded_yaml(raw_data, limit)
    raise ValueError("Uploaded file must be text YAML")


def _yaml_to_config_data(yaml_text: str, root_node: str) -> dict:
    """Parse YAML text and return configuration mapping for a root node."""
    parsed = yaml.safe_load(yaml_text)
    if parsed is None:
        raise ValueError("Uploaded YAML is empty")
    if not isinstance(parsed, dict):
        raise ValueError("Uploaded YAML must be a mapping")

    config_data = parsed.get(root_node, parsed)
    if not isinstance(config_data, dict):
        raise ValueError(f"YAML node '{root_node}' must be a mapping")
    return config_data


def _apply_values_to_component_tree(component_tree: dict, values: dict):
    """Apply mapping values recursively into a rendered component tree."""
    for key, value in values.items():
        if key not in component_tree:
            continue
        target = component_tree[key]
        if isinstance(target, dict) and isinstance(value, dict):
            _apply_values_to_component_tree(target, value)
            continue
        if hasattr(target, "value"):
            target.value = value


def _download_payload_from_paths(
    exported_paths: list[Path],
    zip_filename: str,
    single_media_type: str,
) -> tuple[bytes, str, str]:
    """Build download payload bytes for one file or a zipped multi-file export."""
    if not exported_paths:
        raise ValueError("No files were generated for download")
    if len(exported_paths) == 1:
        export_path = exported_paths[0]
        return export_path.read_bytes(), export_path.name, single_media_type

    buffer = io.BytesIO()
    with zipfile.ZipFile(buffer, "w", compression=zipfile.ZIP_DEFLATED) as archive:
        for export_path in exported_paths:
            archive.write(export_path, arcname=export_path.name)
    return buffer.getvalue(), zip_filename, "application/zip"


_THREEJS_VIEWER_HTML = (
    '<div id="partomatic-threejs-root" '
    'style="width:100%;height:calc(100vh - 56px);'
    'background:linear-gradient(180deg,#0f172a,#111827);"></div>'
)


_THREEJS_BOOTSTRAP_SCRIPT = """
<script type="module">
const THREE_MOD = 'https://esm.sh/three@0.166.1';
const ORBIT_CONTROLS_MOD = 'https://esm.sh/three@0.166.1/examples/jsm/controls/OrbitControls.js';

window.partomaticRender = async (payload, options = null) => {
  const root = document.getElementById('partomatic-threejs-root');
  if (!root) return;

    const previousCameraState = (() => {
        const previousCamera = root.__partomaticCamera;
        if (!previousCamera) {
            return null;
        }
        const previousControls = root.__partomaticControls;
        const target = previousControls && previousControls.target
            ? [previousControls.target.x, previousControls.target.y, previousControls.target.z]
            : [0, 0, 0];
        return {
            position: [previousCamera.position.x, previousCamera.position.y, previousCamera.position.z],
            target,
            near: previousCamera.near,
            far: previousCamera.far,
        };
    })();

  if (root.__partomaticResizeObserver) {
    root.__partomaticResizeObserver.disconnect();
    root.__partomaticResizeObserver = null;
  }
  if (root.__partomaticRenderer) {
    root.__partomaticRenderer.dispose();
    root.__partomaticRenderer = null;
  }
    if (root.__partomaticAnimationFrameId) {
        cancelAnimationFrame(root.__partomaticAnimationFrameId);
        root.__partomaticAnimationFrameId = null;
    }
    root.__partomaticControls = null;
    root.__partomaticFitToView = null;
    root.__partomaticResetView = null;
    root.__partomaticZoomBy = null;
  root.innerHTML = '';

  const THREE = await import(THREE_MOD);
    let OrbitControls = null;
    try {
        OrbitControls = (await import(ORBIT_CONTROLS_MOD)).OrbitControls;
    } catch (_error) {
        OrbitControls = null;
        console.warn('partomatic: OrbitControls unavailable, using static renderer');
    }

  const renderer = new THREE.WebGLRenderer({ antialias: true });
  renderer.setPixelRatio(window.devicePixelRatio || 1);
  renderer.setSize(root.clientWidth || 600, root.clientHeight || 400);
  renderer.outputColorSpace = THREE.SRGBColorSpace;
  root.appendChild(renderer.domElement);
  root.__partomaticRenderer = renderer;

  const scene = new THREE.Scene();
  scene.background = new THREE.Color(0x111827);

  const camera = new THREE.PerspectiveCamera(
    45,
    (root.clientWidth || 600) / (root.clientHeight || 400),
    0.1,
    10000,
  );
  camera.position.set(160, 120, 160);
    if (previousCameraState) {
        camera.position.set(...previousCameraState.position);
        if (Number.isFinite(previousCameraState.near) && previousCameraState.near > 0) {
            camera.near = previousCameraState.near;
        }
        if (Number.isFinite(previousCameraState.far) && previousCameraState.far > camera.near) {
            camera.far = previousCameraState.far;
        }
        camera.lookAt(...previousCameraState.target);
    }
    const defaultCameraPosition = new THREE.Vector3(160, 120, 160);
    const defaultCameraTarget = new THREE.Vector3(0, 0, 0);
    const resetCameraPosition = new THREE.Vector3().copy(defaultCameraPosition);
    const resetCameraTarget = new THREE.Vector3().copy(defaultCameraTarget);

    scene.add(new THREE.HemisphereLight(0xffffff, 0x334155, 1.08));
    const dir = new THREE.DirectionalLight(0xffffff, 0.96);
  dir.position.set(200, 260, 140);
  scene.add(dir);

    const viewerOptions = options || {};
    const transparentFaces = Boolean(viewerOptions.transparentFaces);
    const showEdges = Boolean(viewerOptions.showEdges);
    const showGrid = Boolean(viewerOptions.showGrid);

    const material = new THREE.MeshStandardMaterial({
    color: 0x38bdf8,
    metalness: 0.08,
    roughness: 0.42,
        transparent: transparentFaces,
        opacity: transparentFaces ? 0.39 : 1.0,
        polygonOffset: showEdges,
        polygonOffsetFactor: showEdges ? 1 : 0,
        polygonOffsetUnits: showEdges ? 1 : 0,
  });
    const edgeMaterial = new THREE.LineBasicMaterial({
        color: 0x000000,
        linewidth: 1.5,
    });

    const baseGridSize = 120;
    const baseAxesSize = 60;
    const grid = new THREE.GridHelper(baseGridSize, 24, 0x8297b5, 0x42556f);
    const gridMaterials = Array.isArray(grid.material)
        ? grid.material
        : [grid.material];
    for (const gridMaterial of gridMaterials) {
        gridMaterial.transparent = true;
        gridMaterial.opacity = 0.55;
        gridMaterial.linewidth = 1.5;
    }
    if (showGrid) {
      scene.add(grid);
    }

    const axes = new THREE.AxesHelper(baseAxesSize);
    scene.add(axes);

    const updateReferenceHelpers = (radius) => {
        const safeRadius = Math.max(radius || 0, 30);
        const gridSize = Math.max(safeRadius * 4, baseGridSize);
        const axesSize = Math.max(safeRadius * 0.9, 40);
        grid.scale.setScalar(gridSize / baseGridSize);
        axes.scale.setScalar(axesSize / baseAxesSize);
    };

  const group = new THREE.Group();
  scene.add(group);

    let controls = null;
    if (OrbitControls) {
        controls = new OrbitControls(camera, renderer.domElement);
        controls.enableDamping = true;
        controls.dampingFactor = 0.05;
        controls.enableZoom = true;
        controls.zoomSpeed = 1.0;
        controls.enablePan = true;
        controls.panSpeed = 0.5;
        if (previousCameraState) {
            controls.target.set(...previousCameraState.target);
            controls.update();
        }
        root.__partomaticControls = controls;
    }
    root.__partomaticCamera = camera;

  for (const p of ((payload && payload.parts) || [])) {
    const vertices = Array.isArray(p.vertices) ? p.vertices : [];
    const indices = Array.isArray(p.indices) ? p.indices : [];
    if (!vertices.length || !indices.length) continue;

    const geometry = new THREE.BufferGeometry();
    geometry.setAttribute('position', new THREE.Float32BufferAttribute(vertices, 3));
    geometry.setIndex(indices);
    geometry.computeVertexNormals();

        const mesh = new THREE.Mesh(geometry, material);
        mesh.renderOrder = 0;
        if (showEdges) {
            const edges = new THREE.LineSegments(
                new THREE.EdgesGeometry(geometry),
                edgeMaterial,
            );
            edges.renderOrder = 1;
            mesh.add(edges);
        }
    group.add(mesh);
  }

  if (group.children.length) {
    const bounds = new THREE.Box3().setFromObject(group);
    const size = bounds.getSize(new THREE.Vector3());
    const center = bounds.getCenter(new THREE.Vector3());
    group.position.sub(center);
    const radius = Math.max(size.x, size.y, size.z) * 0.65 || 60;
        updateReferenceHelpers(radius);
    camera.near = Math.max(radius / 1000, 0.01);
    camera.far = Math.max(radius * 100, 500);
        if (!previousCameraState) {
            camera.position.set(radius * 1.4, radius * 1.1, radius * 1.5);
            camera.lookAt(0, 0, 0);
            if (controls) {
                controls.target.set(0, 0, 0);
                controls.update();
            }
        } else if (controls) {
            controls.update();
        }
    } else {
        updateReferenceHelpers(60);
  }

    const renderOnce = () => {
        const w = root.clientWidth || 600;
        const h = root.clientHeight || 400;
        renderer.setSize(w, h);
        camera.aspect = w / h;
        camera.updateProjectionMatrix();
        renderer.render(scene, camera);
    };

    const saveResetView = () => {
        resetCameraPosition.copy(camera.position);
        if (controls) {
            resetCameraTarget.copy(controls.target);
            controls.saveState();
        } else {
            resetCameraTarget.copy(defaultCameraTarget);
        }
    };

    root.__partomaticFitToView = () => {
        if (!group.children.length) {
            camera.position.copy(defaultCameraPosition);
            camera.lookAt(defaultCameraTarget);
            if (controls) {
                controls.target.copy(defaultCameraTarget);
                controls.update();
            } else {
                renderOnce();
            }
            saveResetView();
            return;
        }

        const bounds = new THREE.Box3().setFromObject(group);
        const size = bounds.getSize(new THREE.Vector3());
        const radius = Math.max(size.x, size.y, size.z) * 0.65 || 60;
        camera.near = Math.max(radius / 1000, 0.01);
        camera.far = Math.max(radius * 100, 500);
        camera.position.set(radius * 1.4, radius * 1.1, radius * 1.5);
        camera.lookAt(0, 0, 0);
        if (controls) {
            controls.target.set(0, 0, 0);
            controls.update();
        } else {
            renderOnce();
        }
        saveResetView();
  };

    root.__partomaticResetView = () => {
        if (controls) {
            controls.reset();
            controls.update();
            return;
        }
        camera.position.copy(resetCameraPosition);
        camera.lookAt(resetCameraTarget);
        renderOnce();
    };

    root.__partomaticZoomBy = (factor) => {
        const scale = Number(factor);
        if (!Number.isFinite(scale) || scale <= 0) {
            return;
        }
        const target = controls ? controls.target.clone() : resetCameraTarget.clone();
        const offset = camera.position.clone().sub(target);
        const nextOffset = offset.multiplyScalar(scale);
        if (nextOffset.length() < 0.5 || nextOffset.length() > 200000) {
            return;
        }
        camera.position.copy(target.add(nextOffset));
        if (controls) {
            controls.update();
        } else {
            camera.lookAt(resetCameraTarget);
            renderOnce();
        }
    };

  const observer = new ResizeObserver(renderOnce);
  observer.observe(root);
  root.__partomaticResizeObserver = observer;

    saveResetView();

    if (controls) {
        const animate = () => {
            root.__partomaticAnimationFrameId = requestAnimationFrame(animate);
            controls.update();
            renderer.render(scene, camera);
        };
        animate();
    } else {
        renderOnce();
    }
};
</script>
"""


def _threejs_render_js(payload: dict | None, viewer_options: dict | None = None) -> str:
    """Return JavaScript to render payload in the browser viewer."""
    payload_json = json.dumps(payload or {"parts": []})
    options_json = json.dumps(viewer_options or {})
    return f"window.partomaticRender({payload_json}, {options_json});"


def _threejs_viewer_control_js(control: str) -> str:
    """Return JavaScript command for viewer camera controls."""
    mapping = {
        "fit": "document.getElementById('partomatic-threejs-root')?.__partomaticFitToView?.();",
        "reset": "document.getElementById('partomatic-threejs-root')?.__partomaticResetView?.();",
        "zoom_in": "document.getElementById('partomatic-threejs-root')?.__partomaticZoomBy?.(0.85);",
        "zoom_out": "document.getElementById('partomatic-threejs-root')?.__partomaticZoomBy?.(1.18);",
    }
    return mapping.get(control, "")


def find_available_port(
    host: str = "localhost",
    start_port: int = 8501,
    retries: int = MAX_PORT_RETRIES,
) -> int:
    """Find the first available TCP port in a range.

    Args:
        host: Hostname/interface to test.
        start_port: First port in the candidate range.
        retries: Additional consecutive ports to try.

    Returns:
        The first free port in `[start_port, start_port + retries]`.

    Raises:
        OSError: If no port in the range is available.
    """
    for offset in range(retries + 1):
        port = start_port + offset
        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as sock:
            sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
            try:
                sock.bind((host, port))
                return port
            except OSError:
                continue
    raise OSError(
        f"No free port found in range [{start_port}, {start_port + retries}] on {host}"
    )


# ---------------------------------------------------------------------------
# Combined configurator UI
# ---------------------------------------------------------------------------


def run_configurator(
    preview_model: "Partomatic",
    class_name: str = "Partomatic",
    config_root_node: str = "config",
    config_fields_spec: dict | None = None,
    host: str = "localhost",
    port: int = 8505,
    port_retries: int = MAX_PORT_RETRIES,
):
    """Launch the combined configurator window.

    Left panel: configuration form (reuses config_editor_app field renderers).
    Right panel: integrated three.js canvas.
    Re-render button: applies config to the Partomatic object and triggers a display.

    Args:
        preview_model: Partomatic instance to configure, compile, preview, and export.
        class_name: Partomatic class name shown in the UI.
        config_root_node: Root YAML node name for config import/export.
        config_fields_spec: Editable field specification mapping.
        host: Hostname/interface for the NiceGUI server.
        port: Preferred starting port for the NiceGUI server.
        port_retries: Additional ports to try if `port` is unavailable.

    Returns:
        None. This function starts the NiceGUI app server.
    """
    root_node = config_root_node
    fields_spec = config_fields_spec or {}
    max_yaml_upload_kb = _yaml_upload_size_limit_kb()
    log_event(
        _log,
        logging.INFO,
        "configurator.started",
        app_mode="configurator",
        host=host,
        port=port,
        max_yaml_upload_kb=max_yaml_upload_kb,
    )

    model = _build_model(f"{class_name}EditorModel", fields_spec)

    port = find_available_port(host=host, start_port=port, retries=port_retries)

    def build_ui():
        """Build the combined configurator and preview interface."""
        loading_overlay_visible = True
        active_job_name = None
        active_job_lock = Lock()
        viewer_options = {
            "transparentFaces": False,
            "showEdges": False,
            "showGrid": True,
        }

        ui.page_title("configurator")
        step_download_item = None

        # top bar
        with ui.row().classes("w-full items-center px-6 py-3 bg-slate-800"):
            ui.label("configurator").classes("text-white text-2xl font-semibold")

        form_state = {}

        # main two-column layout
        with ui.row().classes("w-full h-full gap-0"):

            # left column: config form
            with ui.column().classes(
                "w-1/3 p-4 gap-4 overflow-y-auto border-r border-slate-200"
            ):
                ui.label(f"{class_name} Configuration").classes("text-lg font-medium")

                with ui.card().classes("w-full"):
                    component_tree = _collect_components(fields_spec, form_state)

                validation_label = ui.label().classes(
                    "text-red-700 whitespace-pre-wrap text-sm"
                )

                def _current_validated():
                    """Return current form data and whether model validation succeeds.

                    Returns:
                        tuple[dict, bool]: Validated/model-shaped data and validation status.
                    """
                    values = _component_value(component_tree)
                    try:
                        validated = model.model_validate(values)
                        output_data = validated.model_dump(mode="python")
                        validation_label.set_text("")
                        return output_data, True
                    except ValidationError as ex:
                        validation_label.set_text(str(ex))
                        return values, False

                def _enable_step_exports_value(output_data: dict) -> bool:
                    """Determine whether STEP export actions should be visible.

                    Args:
                        output_data: Current validated config mapping.

                    Returns:
                        bool: True when STEP exports are enabled in the active config.
                    """
                    return bool(
                        output_data.get(
                            "enable_step_exports",
                            getattr(preview_model.config, "enable_step_exports", False),
                        )
                    )

                def _sync_export_visibility(output_data: dict):
                    """Synchronize STEP menu visibility with current config values.

                    Args:
                        output_data: Current validated config mapping.
                    """
                    if step_download_item is not None:
                        step_download_item.set_visibility(
                            _enable_step_exports_value(output_data)
                        )

                def _download_yaml():
                    """Validate and download the current configuration as YAML."""
                    output_data, ok = _current_validated()
                    if not ok:
                        return
                    yaml_text = _to_yaml_document(root_node, output_data)
                    filename = f"{root_node}.yaml"
                    media_type = "application/x-yaml"
                    log_event(
                        _log,
                        logging.INFO,
                        "config.downloaded",
                        app_mode="configurator",
                        filename=filename,
                        media_type=media_type,
                    )
                    ui.download(
                        yaml_text.encode("utf-8"),
                        filename=filename,
                        media_type=media_type,
                    )

                def _download_export(kind: str):
                    """Compile and download generated geometry files.

                    Args:
                        kind: Export file type, either "stl" or "step".
                    """
                    output_data, ok = _current_validated()
                    if not ok:
                        return
                    preview_model.config.update_from_mapping(output_data)
                    preview_model.invalidate_preview()
                    log_event(
                        _log,
                        logging.INFO,
                        "export.requested",
                        app_mode="configurator",
                        export_format=kind,
                    )

                    def _export_job():
                        if preview_model.is_dirty:
                            preview_model.compile()
                        _refresh_viewer_geometry()
                        with tempfile.TemporaryDirectory(
                            prefix=f"partomatic-{kind}-"
                        ) as export_dir:
                            if kind == "stl":
                                exported_paths = preview_model.export_stls_to_directory(
                                    export_dir
                                )
                                return _download_payload_from_paths(
                                    [Path(path) for path in exported_paths],
                                    f"{root_node}-stls.zip",
                                    "model/stl",
                                )

                            exported_paths = preview_model.export_steps_to_directory(
                                export_dir
                            )
                            return _download_payload_from_paths(
                                [Path(path) for path in exported_paths],
                                f"{root_node}-steps.zip",
                                "model/step",
                            )

                    def _handle_export_success(result):
                        payload, filename, media_type = result
                        log_event(
                            _log,
                            logging.INFO,
                            "export.succeeded",
                            app_mode="configurator",
                            export_format=kind,
                            filename=filename,
                            media_type=media_type,
                        )
                        _sync_threejs_viewer()
                        ui.download(
                            payload,
                            filename=filename,
                            media_type=media_type,
                        )
                        _sync_overlay_state()

                    def _handle_export_error(ex: Exception):
                        log_event(
                            _log,
                            logging.ERROR,
                            "export.failed",
                            outcome="failure",
                            app_mode="configurator",
                            export_format=kind,
                            error_type=ex.__class__.__name__,
                            error_message=str(ex),
                        )
                        validation_label.set_text(f"Export error: {ex}")
                        ui.notify(f"Export failed: {ex}", type="negative")
                        _sync_overlay_state()

                    _start_background_job(
                        "Export",
                        _export_job,
                        _handle_export_success,
                        _handle_export_error,
                    )

                async def _load_yaml_upload(upload_event):
                    """Load uploaded YAML into form controls and trigger a render.

                    Args:
                        upload_event: NiceGUI upload event containing YAML text.
                    """
                    try:
                        file_name = getattr(upload_event, "name", None)
                        if file_name is None:
                            file_name = getattr(
                                getattr(upload_event, "file", None),
                                "name",
                                "uploaded YAML",
                            )
                        log_event(
                            _log,
                            logging.INFO,
                            "upload_yaml.started",
                            app_mode="configurator",
                            file_name=file_name,
                        )
                        yaml_text = await _extract_uploaded_text(
                            upload_event,
                            max_bytes=max_yaml_upload_kb * 1024,
                        )
                        loaded_data = _yaml_to_config_data(yaml_text, root_node)
                        validated = model.model_validate(loaded_data)
                        output_data = validated.model_dump(mode="python")
                        _apply_values_to_component_tree(component_tree, output_data)
                        validation_label.set_text("")
                        on_field_change()
                        _trigger_render()
                        log_event(
                            _log,
                            logging.INFO,
                            "upload_yaml.succeeded",
                            app_mode="configurator",
                            file_name=file_name,
                            upload_size_bytes=len(yaml_text.encode("utf-8")),
                        )
                        ui.notify(
                            f"Loaded configuration from {file_name}", type="positive"
                        )
                    except Exception as ex:
                        outcome = (
                            "rejected"
                            if "exceeds maximum size" in str(ex).lower()
                            else "failure"
                        )
                        log_event(
                            _log,
                            logging.WARNING if outcome == "rejected" else logging.ERROR,
                            "upload_yaml.failed",
                            outcome=outcome,
                            app_mode="configurator",
                            error_type=ex.__class__.__name__,
                            error_message=str(ex),
                        )
                        validation_label.set_text(f"YAML load error: {ex}")
                        ui.notify(f"YAML load failed: {ex}", type="negative")
                    finally:
                        # Reset uploader state so selecting the same file again triggers upload.
                        yaml_upload.run_method("reset")

                def _pick_yaml_file():
                    """Open the hidden YAML file picker dialog."""
                    yaml_upload.run_method("reset")
                    yaml_upload.run_method("pickFiles")

                with ui.row().classes("gap-2 mt-2"):
                    refresh_button = ui.button(  # noqa: F841
                        "Refresh",
                        icon="refresh",
                        on_click=lambda: _trigger_render(),
                    ).props("unelevated color=primary")
                    yaml_upload = (
                        ui.upload(
                            label="Load YAML",
                            auto_upload=True,
                            on_upload=_load_yaml_upload,
                        )
                        .props("accept=.yaml,.yml")
                        .classes("hidden")
                    )
                    ui.button(
                        "Load YAML",
                        icon="upload_file",
                        on_click=_pick_yaml_file,
                    ).props("unelevated color=primary")
                    with ui.dropdown_button(
                        "Download STL",
                        icon="download",
                        split=True,
                        auto_close=True,
                        on_click=lambda: _download_export("stl"),
                    ).props("unelevated color=secondary"):
                        ui.menu_item("Configuration", on_click=_download_yaml)
                        ui.menu_item(
                            "STL Files", on_click=lambda: _download_export("stl")
                        )
                        step_download_item = ui.menu_item(
                            "STEP Files",
                            on_click=lambda: _download_export("step"),
                        )

            # right column: integrated three.js viewer
            with ui.column().classes("w-2/3 relative p-0"):
                viewer_html = ui.html(_THREEJS_VIEWER_HTML).style(
                    "width:100%;height:calc(100vh - 56px);"
                )
                ui.add_body_html(_THREEJS_BOOTSTRAP_SCRIPT)

                # Camera controls remain available even if pointer controls fail to load.
                with ui.row().classes("absolute top-3 right-3 z-30 gap-2"):
                    ui.button(
                        "Fit", on_click=lambda: _trigger_viewer_control("fit")
                    ).props("dense unelevated color=primary")
                    ui.button(
                        "Reset",
                        on_click=lambda: _trigger_viewer_control("reset"),
                    ).props("dense unelevated color=secondary")
                    ui.button(
                        "Zoom +",
                        on_click=lambda: _trigger_viewer_control("zoom_in"),
                    ).props("dense unelevated color=accent")
                    ui.button(
                        "Zoom -",
                        on_click=lambda: _trigger_viewer_control("zoom_out"),
                    ).props("dense unelevated color=accent")

                # Viewer style controls are kept separate from camera controls.
                with ui.row().classes("absolute top-3 left-3 z-30 gap-2"):
                    transparent_faces_button = ui.button(
                        "Transparency: Off",
                        on_click=lambda: _toggle_viewer_option(
                            "transparentFaces",
                            transparent_faces_button,
                            "Transparency",
                        ),
                    ).props("dense unelevated color=accent")
                    edges_button = ui.button(
                        "Edges: Off",
                        on_click=lambda: _toggle_viewer_option(
                            "showEdges",
                            edges_button,
                            "Edges",
                        ),
                    ).props("dense unelevated color=secondary")
                    grid_button = ui.button(
                        "Grid: On",
                        on_click=lambda: _toggle_viewer_option(
                            "showGrid",
                            grid_button,
                            "Grid",
                        ),
                    ).props("dense unelevated color=info")

                # Initial load overlay so startup does not appear as an empty white box.
                loading_overlay = (
                    ui.element("div")
                    .classes(
                        "absolute inset-0 flex items-center justify-center p-6 pointer-events-none"
                    )
                    .style("background: rgba(15, 23, 42, 0.18); z-index: 20;")
                )
                with loading_overlay:
                    ui.label("Loading...").classes(
                        "text-white text-base font-semibold text-center drop-shadow px-5 py-3 max-w-md rounded-xl"
                    ).style(
                        "background: rgba(15, 23, 42, 0.34);"
                        "border: 1px solid rgba(255, 255, 255, 0.34);"
                    )

                # Dirty state overlay (badge removed, overlay retained).
                dirty_overlay = (
                    ui.element("div")
                    .classes(
                        "absolute inset-0 flex items-center justify-center p-6 pointer-events-none"
                    )
                    .style("background: rgba(15, 23, 42, 0.18); z-index: 10;")
                )
                with dirty_overlay:
                    ui.label("Configuration changed - press Refresh to update").classes(
                        "text-white text-base font-semibold text-center drop-shadow px-5 py-3 max-w-md rounded-xl"
                    ).style(
                        "background: rgba(15, 23, 42, 0.34);"
                        "border: 1px solid rgba(255, 255, 255, 0.34);"
                    )

        def _sync_overlay_state():
            """Show or hide the dirty-state overlay based on preview status."""
            dirty_overlay.set_visibility(
                preview_model.preview_state == PreviewState.DIRTY
            )

        def _trigger_viewer_control(control: str):
            """Send a viewer camera control command to the browser."""
            run_javascript = getattr(ui, "run_javascript", None)
            if not callable(run_javascript):
                return
            command = _threejs_viewer_control_js(control)
            if command:
                run_javascript(command)

        def _sync_threejs_viewer():
            """Render the most recent serialized geometry payload in the viewer."""
            payload = getattr(preview_model, "_viewer_geometry", None) or {"parts": []}
            run_javascript = getattr(ui, "run_javascript", None)
            if callable(run_javascript):
                run_javascript(_threejs_render_js(payload, viewer_options))

        def _viewer_option_label(option_key: str, label_prefix: str) -> str:
            """Return a consistent label text for viewer style toggles."""
            state_text = "On" if viewer_options[option_key] else "Off"
            return f"{label_prefix}: {state_text}"

        def _toggle_viewer_option(option_key: str, button, label_prefix: str):
            """Toggle a viewer style option and re-render current geometry."""
            viewer_options[option_key] = not viewer_options[option_key]
            button.set_text(_viewer_option_label(option_key, label_prefix))
            _sync_threejs_viewer()

        def _refresh_viewer_geometry():
            """Update viewer payload, preferring three.js geometry generation."""
            generate = getattr(preview_model, "generate_viewer_geometry", None)
            if callable(generate):
                generate()
                return
            # Backward-compatible fallback for legacy/mocked objects.
            preview_model.display()

        def _sync_loading_overlay_state():
            """Show or hide the initial-load overlay."""
            loading_overlay.set_visibility(loading_overlay_visible)

        def _start_background_job(
            job_name: str,
            work,
            on_success,
            on_error,
            on_started=None,
        ) -> bool:
            """Run a long-running job off the UI callback path with re-entry protection."""
            nonlocal active_job_name
            try:
                ui_loop = asyncio.get_running_loop()
            except RuntimeError:
                ui_loop = None

            ui_client = None
            ui_context = getattr(ui, "context", None)
            if ui_context is not None:
                try:
                    ui_client = getattr(ui_context, "client", None)
                except RuntimeError:
                    ui_client = None

            with active_job_lock:
                if active_job_name is not None:
                    log_event(
                        _log,
                        logging.WARNING,
                        "job.rejected",
                        outcome="rejected",
                        app_mode="configurator",
                        job_name=job_name,
                        active_job_name=active_job_name,
                    )
                    ui.notify(f"{active_job_name} already in progress", type="warning")
                    return False
                active_job_name = job_name
                log_event(
                    _log,
                    logging.INFO,
                    "job.started",
                    app_mode="configurator",
                    job_name=job_name,
                )

            if callable(on_started):
                on_started()

            def _finish(result=None, error=None):
                nonlocal active_job_name
                with active_job_lock:
                    active_job_name = None
                if error is None:
                    log_event(
                        _log,
                        logging.INFO,
                        "job.succeeded",
                        app_mode="configurator",
                        job_name=job_name,
                    )
                    on_success(result)
                    return
                log_event(
                    _log,
                    logging.ERROR,
                    "job.failed",
                    outcome="failure",
                    app_mode="configurator",
                    job_name=job_name,
                    error_type=error.__class__.__name__,
                    error_message=str(error),
                )
                on_error(error)

            def _worker():
                result = None
                error = None
                try:
                    result = work()
                except (
                    Exception
                ) as ex:  # pragma: no cover - exercised via runtime tests
                    error = ex

                def _finish_with_client_context():
                    if ui_client is not None:
                        with ui_client:
                            _finish(result, error)
                    else:
                        _finish(result, error)

                # Always re-enter the UI thread from worker threads without
                # creating UI elements/timers from background tasks.
                if ui_loop is not None and ui_loop.is_running():
                    ui_loop.call_soon_threadsafe(_finish_with_client_context)
                else:
                    _finish_with_client_context()

            Thread(
                target=_worker,
                daemon=True,
                name=f"partomatic-configurator-{job_name.lower()}",
            ).start()
            return True

        def on_field_change(_event=None):
            """Apply form edits to config and update dependent UI state.

            Args:
                _event: Optional NiceGUI change event payload.
            """
            output_data, ok = _current_validated()
            _sync_export_visibility(output_data)
            if not ok:
                _sync_overlay_state()
                return
            preview_model.config.update_from_mapping(output_data)
            preview_model.invalidate_preview()
            _sync_overlay_state()

        for component in form_state.values():
            component.on_value_change(on_field_change)
            component.on("keydown.enter", lambda _event: _trigger_render())

        # seed YAML preview and show dirty state on first load
        on_field_change()

        def _trigger_render():
            """Compile and display the part using current validated form values."""
            nonlocal loading_overlay_visible
            output_data, ok = _current_validated()
            if not ok:
                return

            preview_model.config.update_from_mapping(output_data)
            preview_model.invalidate_preview()
            log_event(
                _log,
                logging.INFO,
                "render.requested",
                app_mode="configurator",
            )

            def _handle_render_started():
                nonlocal loading_overlay_visible
                loading_overlay_visible = True
                _sync_loading_overlay_state()

            def _render_job():
                preview_model.compile_for_preview()
                _refresh_viewer_geometry()

            def _handle_render_success(_result):
                nonlocal loading_overlay_visible
                log_event(
                    _log,
                    logging.INFO,
                    "render.succeeded",
                    app_mode="configurator",
                )
                _sync_threejs_viewer()
                loading_overlay_visible = False
                _sync_loading_overlay_state()
                _sync_overlay_state()

            def _handle_render_error(ex: Exception):
                nonlocal loading_overlay_visible
                log_event(
                    _log,
                    logging.ERROR,
                    "render.failed",
                    outcome="failure",
                    app_mode="configurator",
                    error_type=ex.__class__.__name__,
                    error_message=str(ex),
                )
                preview_model._preview_state = PreviewState.ERROR
                preview_model._preview_error = f"Render error: {ex}"
                validation_label.set_text(preview_model._preview_error)
                loading_overlay_visible = False
                _sync_loading_overlay_state()
                _sync_overlay_state()

            _start_background_job(
                "Render",
                _render_job,
                _handle_render_success,
                _handle_render_error,
                on_started=_handle_render_started,
            )

        # initial render on load
        _sync_loading_overlay_state()
        ui.timer(1.5, lambda: _trigger_render(), once=True)

    ui.run(
        host=host,
        port=port,
        reload=False,
        show=False,
        root=build_ui,
        title="partomatic configurator",
    )
