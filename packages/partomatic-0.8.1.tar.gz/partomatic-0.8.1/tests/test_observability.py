import json
import logging
import sys

from partomatic import observability


def _reset_partomatic_logger():
    logger = logging.getLogger("partomatic")
    logger.handlers.clear()
    if hasattr(logger, "_partomatic_configured"):
        delattr(logger, "_partomatic_configured")
    return logger


def test_json_formatter_emits_defaults_and_exception_fields(monkeypatch):
    monkeypatch.setenv("PARTOMATIC_APP_MODE", "cli-test")
    monkeypatch.setenv("PARTOMATIC_DEPLOYMENT_ENV", "stage")
    formatter = observability.PartomaticJsonFormatter()

    record = logging.LogRecord(
        "partomatic.sample",
        logging.INFO,
        __file__,
        10,
        "hello %s",
        ("world",),
        None,
    )
    payload = json.loads(formatter.format(record))
    assert payload["message"] == "hello world"
    assert payload["event.name"] == "log"
    assert payload["event.outcome"] == "success"
    assert payload["app.mode"] == "cli-test"
    assert payload["deployment.environment"] == "stage"

    try:
        raise ValueError("boom")
    except ValueError:
        exc_info = sys.exc_info()

    record_with_extra = logging.LogRecord(
        "partomatic.sample",
        logging.ERROR,
        __file__,
        20,
        "failed",
        (),
        exc_info,
    )
    record_with_extra.event_name = "job.failed"
    record_with_extra.event_outcome = "failure"
    record_with_extra.app_mode = "configurator"
    record_with_extra.deployment_environment = "prod"
    record_with_extra.custom_field = 42
    record_with_extra._internal_only = "skip"

    payload_with_extra = json.loads(formatter.format(record_with_extra))
    assert payload_with_extra["event.name"] == "job.failed"
    assert payload_with_extra["event.outcome"] == "failure"
    assert payload_with_extra["app.mode"] == "configurator"
    assert payload_with_extra["deployment.environment"] == "prod"
    assert payload_with_extra["custom_field"] == 42
    assert "_internal_only" not in payload_with_extra
    assert payload_with_extra["error.type"] == "ValueError"
    assert payload_with_extra["error.message"] == "boom"


def test_configure_get_logger_and_log_event(monkeypatch):
    _reset_partomatic_logger()
    monkeypatch.setenv("PARTOMATIC_LOG_FORMAT", "json")
    monkeypatch.setenv("PARTOMATIC_LOG_LEVEL", "debug")

    logger = observability.configure_logging(app_mode="cli")
    assert isinstance(
        logger.handlers[0].formatter, observability.PartomaticJsonFormatter
    )
    assert logger.level == logging.DEBUG

    same_logger = observability.configure_logging(app_mode="cli")
    assert same_logger is logger
    assert len(logger.handlers) == 1

    namespaced = observability.get_logger("worker")
    already_namespaced = observability.get_logger("partomatic.worker")
    assert namespaced.name == "partomatic.worker"
    assert already_namespaced.name == "partomatic.worker"

    captured = {}

    def _capture(level, message, extra):
        captured["level"] = level
        captured["message"] = message
        captured["extra"] = extra

    namespaced.log = _capture
    observability.log_event(
        namespaced,
        logging.WARNING,
        "export.failed",
        outcome="failure",
        app_mode="api",
        deployment_environment="prod",
        custom=1,
        message="reserved",
        asctime="reserved",
        name="reserved",
    )

    assert captured["level"] == logging.WARNING
    assert captured["message"] == "export.failed"
    assert captured["extra"]["event_name"] == "export.failed"
    assert captured["extra"]["event_outcome"] == "failure"
    assert captured["extra"]["app_mode"] == "api"
    assert captured["extra"]["deployment_environment"] == "prod"
    assert captured["extra"]["custom"] == 1
    assert captured["extra"]["field_message"] == "reserved"
    assert captured["extra"]["field_asctime"] == "reserved"
    assert captured["extra"]["field_name"] == "reserved"


def test_normalize_log_format_fallbacks(monkeypatch):
    monkeypatch.setenv("PARTOMATIC_APP_MODE", "configurator")

    assert observability._normalize_log_format(" json ", None) == "json"
    assert observability._normalize_log_format("unknown", "configurator") == "json"
    assert observability._normalize_log_format(None, "cli") == "console"
