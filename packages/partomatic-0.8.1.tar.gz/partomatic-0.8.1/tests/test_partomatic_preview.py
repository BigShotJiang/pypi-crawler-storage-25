import pytest

from partomatic import Partomatic, PartomaticConfig, PreviewState
from partomatic.partomatic_preview import PartomaticPreviewMixin


class PreviewConfig(PartomaticConfig):
    stl_folder: str = "NONE"
    should_fail: bool = False


class PreviewWidget(Partomatic):
    config: PreviewConfig = PreviewConfig()

    def compile(self):
        if self.config.should_fail:
            raise RuntimeError("compile failed")


class TestPartomaticPreview:

    def test_preview_state_without_is_dirty_returns_internal_state(self):
        class BarePreview(PartomaticPreviewMixin):
            pass

        widget = BarePreview()
        widget._init_preview_state()
        widget._preview_state = PreviewState.CLEAN

        assert widget.preview_state == PreviewState.CLEAN

    def test_initial_preview_state(self):
        widget = PreviewWidget()
        assert widget.preview_state == PreviewState.DIRTY
        assert widget.preview_error is None

    def test_invalidate_preview_marks_dirty_and_clears_error(self):
        widget = PreviewWidget()
        widget._preview_error = "prior error"

        widget.invalidate_preview()

        assert widget.preview_state == PreviewState.DIRTY
        assert widget.preview_error is None

    def test_compile_for_preview_success_transitions(self):
        widget = PreviewWidget()
        widget.invalidate_preview()

        widget.compile_for_preview()

        assert widget.preview_state == PreviewState.CLEAN
        assert widget.preview_error is None

    def test_compile_for_preview_short_circuits_when_not_dirty(self):
        widget = PreviewWidget()
        widget.compile_for_preview()
        compile_state = widget.preview_state

        widget.compile_for_preview()

        assert compile_state == PreviewState.CLEAN
        assert widget.preview_state == PreviewState.CLEAN
        assert widget.preview_error is None

    def test_compile_for_preview_failure_transitions(self):
        widget = PreviewWidget(should_fail=True)

        with pytest.raises(RuntimeError, match="compile failed"):
            widget.compile_for_preview()

        assert widget.preview_state == PreviewState.ERROR
        assert widget.preview_error == "compile failed"
