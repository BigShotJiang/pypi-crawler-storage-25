from types import SimpleNamespace

import partomatic.viewer_geometry as viewer_geometry


class _FakePart:
    def __init__(self, vertices, triangles):
        self._vertices = vertices
        self._triangles = triangles

    def tessellate(self, tolerance, angular_tolerance):
        _ = (tolerance, angular_tolerance)
        return self._vertices, self._triangles


def test_part_to_mesh_flattens_vertices_and_indices():
    vertices = [
        SimpleNamespace(X=1.0, Y=2.0, Z=3.0),
        SimpleNamespace(X=4.0, Y=5.0, Z=6.0),
        SimpleNamespace(X=7.0, Y=8.0, Z=9.0),
    ]
    triangles = [(0, 1, 2)]

    mesh = viewer_geometry.part_to_mesh(_FakePart(vertices, triangles))

    assert mesh["vertices"] == [1.0, 2.0, 3.0, 4.0, 5.0, 6.0, 7.0, 8.0, 9.0]
    assert mesh["indices"] == [0, 1, 2]


def test_serialize_parts_skips_failed_part_and_logs_exception(monkeypatch):
    calls = {"n": 0}

    def _part_to_mesh(_part):
        calls["n"] += 1
        if calls["n"] == 2:
            raise RuntimeError("boom")
        return {"vertices": [0.0, 0.0, 0.0], "indices": [0, 0, 0]}

    logs = []
    monkeypatch.setattr(viewer_geometry, "part_to_mesh", _part_to_mesh)
    monkeypatch.setattr(
        viewer_geometry._log,
        "exception",
        lambda msg, idx: logs.append((msg, idx)),
    )

    payload = viewer_geometry.serialize_parts([object(), object()])

    assert payload == {
        "parts": [{"id": 0, "vertices": [0.0, 0.0, 0.0], "indices": [0, 0, 0]}]
    }
    assert logs == [("Failed to serialize part %d for three.js viewer", 1)]
