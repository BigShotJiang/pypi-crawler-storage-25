from dataclasses import dataclass, field
from enum import Enum, auto
from _pytest.logging import caplog
import pytest
from unittest.mock import patch
from pathlib import Path

from partomatic import AutomatablePart, PartomaticConfig, Partomatic
from build123d import BuildPart, Box, Part, Sphere, Align, Mode, Location

import logging
from sys import stdout


class FakeEnum(Enum):
    ONE = auto()
    TWO = auto()
    THREE = auto()


class SubConfig(PartomaticConfig):
    sub_field: str = "sub_default"
    sub_enum: FakeEnum = FakeEnum.ONE


class ContainerConfig(PartomaticConfig):
    container_field: str = "container_default"
    sub: SubConfig = field(default_factory=SubConfig)


class WidgetConfig(PartomaticConfig):
    stl_folder: str = field(default="C:\\Users\\xopher\\Downloads")
    radius: float = field(default=10)
    length: float = field(default=17)


class Widget(Partomatic):

    config: WidgetConfig = WidgetConfig()

    def complete_wheel(self) -> Part:
        with BuildPart() as holebox:
            Box(
                self.config.length,
                self.config.length,
                self.config.length,
                align=(Align.CENTER, Align.CENTER, Align.CENTER),
            )
            Sphere(
                self.config.radius,
                align=(Align.CENTER, Align.CENTER, Align.CENTER),
                mode=Mode.SUBTRACT,
            )
        return holebox.part

    def compile(self):
        self.parts.clear()

        self.parts.append(
            AutomatablePart(
                self.complete_wheel(),
                "test",
                display_location=Location((9, 0, 9)),
                stl_folder=str(Path(self.config.stl_folder) / "stls"),
            )
        )


class TestPartomatic:

    def test_init_subclass_no_compile_override_keeps_parent_compile(self):
        class BaseWidget(Partomatic):
            config = WidgetConfig()

            def compile(self):
                self.parts.clear()

        original_compile = BaseWidget.compile

        class ChildWidget(BaseWidget):
            pass

        assert ChildWidget.compile is original_compile

    def test_init_subclass_skips_rewrapping_already_wrapped_compile(self):
        def compile_already_wrapped(self):
            self.parts.clear()

        compile_already_wrapped._partomatic_wrapped = True

        class PreWrappedWidget(Partomatic):
            config = WidgetConfig()
            compile = compile_already_wrapped

        assert PreWrappedWidget.__dict__["compile"] is compile_already_wrapped

    def test_instances_get_isolated_config_objects(self):
        first = Widget()
        second = Widget()

        assert first.config is not second.config
        first.config.radius = 123
        assert second.config.radius == 10

    def test_complete_file_path_helpers_and_compile_wrapper_stability(self):
        foo = Widget()
        wrapped_compile_func = foo.compile.__func__
        foo.compile()

        stl_path = foo.complete_stl_file_path(foo.parts[0])
        step_path = foo.complete_step_file_path(foo.parts[0])

        assert stl_path.endswith(".stl")
        assert step_path.endswith(".step")
        assert foo.compile.__func__ is wrapped_compile_func

    def test_export_path_rejects_path_like_filename_components(self):
        foo = Widget()
        foo.compile()
        foo.config.file_prefix = "../escape/"

        with pytest.raises(
            ValueError, match="file_prefix must not contain path separators"
        ):
            foo.complete_stl_file_path(foo.parts[0])

    def test_export_path_rejects_windows_style_path_separator_in_prefix(self):
        foo = Widget()
        foo.compile()
        foo.config.file_prefix = "..\\escape\\"

        with pytest.raises(
            ValueError, match="file_prefix must not contain path separators"
        ):
            foo.complete_stl_file_path(foo.parts[0])

    def test_validate_filename_component_rejects_altsep_when_configured(self):
        foo = Widget()
        with patch("partomatic.partomatic.os.altsep", "|"):
            with pytest.raises(ValueError, match="must not contain path separators"):
                foo._validate_filename_component("bad|prefix", "file_prefix")

    def test_export_path_rejects_path_like_file_suffix(self):
        foo = Widget()
        foo.compile()
        foo.config.file_suffix = "/nested/output"

        with pytest.raises(
            ValueError, match="file_suffix must not contain path separators"
        ):
            foo.complete_step_file_path(foo.parts[0])

    def test_dirty_state_tracks_config_against_last_compile(self):
        foo = Widget()

        assert foo.is_dirty is True

        foo.compile()
        assert foo.is_dirty is False

        foo.config.update_from_mapping({"radius": 12})
        assert foo.is_dirty is True

        foo.config.update_from_mapping({"radius": 10})
        assert foo.is_dirty is False

    def test_ensure_path_within_root_rejects_escape_attempt(self, tmp_path):
        foo = Widget()
        export_root = tmp_path / "safe"
        export_root.mkdir()
        escaped_path = tmp_path / "outside" / "part.stl"

        with pytest.raises(
            ValueError, match="Export path escapes the configured export directory"
        ):
            foo._ensure_path_within_root(export_root, escaped_path)

    def test_partomatic_class(self, caplog):
        wc = WidgetConfig()
        assert wc.stl_folder == "C:\\Users\\xopher\\Downloads"
        assert wc.enable_step_exports is False
        foo = Widget(wc)
        assert foo.config.radius == 10
        assert foo.config.length == 17
        with (
            patch("pathlib.Path.mkdir"),
            patch("pathlib.Path.exists"),
            patch("pathlib.Path.is_dir"),
            patch("partomatic.partomatic.export_stl") as export_stl,
            patch("partomatic.partomatic.export_step") as export_step,
        ):
            foo.display()
            foo.partomate()
        export_stl.assert_called_once()
        export_step.assert_not_called()

        with (
            patch("pathlib.Path.mkdir"),
            patch("pathlib.Path.exists"),
            patch("pathlib.Path.is_dir"),
            patch("partomatic.partomatic.export_stl") as export_stl,
            patch("partomatic.partomatic.export_step") as export_step,
        ):
            foo.partomate(export_steps=True)
        export_stl.assert_called_once()
        export_step.assert_called_once()
        foo.config.stl_folder = "NONE"
        foo.export_stls()
        foo.export_steps()
        assert len(caplog.records) > 0

    def test_export_to_directory_helpers_return_generated_paths(self):
        foo = Widget(stl_folder="relative-output")
        foo.compile()

        with (
            patch("pathlib.Path.mkdir"),
            patch("pathlib.Path.exists", return_value=True),
            patch("pathlib.Path.is_dir", return_value=True),
            patch("partomatic.partomatic.export_stl") as export_stl,
            patch("partomatic.partomatic.export_step") as export_step,
        ):
            stl_paths = foo.export_stls_to_directory("bundle")
            step_paths = foo.export_steps_to_directory("bundle")

        assert stl_paths[0].name.endswith(".stl")
        assert step_paths[0].name.endswith(".step")
        export_stl.assert_called_once()
        export_step.assert_called_once()

    def test_bad_stl_output_folder(self, caplog):
        logging.getLogger("partomatic").addHandler(logging.StreamHandler())
        foo = Widget(stl_folder="/bad/path")
        assert foo.config.stl_folder == "/bad/path"
        with (
            patch("pathlib.Path.mkdir"),
            patch("pathlib.Path.exists", return_value=False),
            patch("pathlib.Path.is_dir"),
            patch("build123d.export_stl"),
            patch("build123d.export_step"),
        ):
            foo.display()
            with pytest.raises(FileNotFoundError):
                foo.partomate()
        assert "does not exist" in caplog.records[-1].message
        assert "Directory" in caplog.records[-1].message

    def test_display_targets_configured_viewer_endpoint(self):
        foo = Widget()
        foo.compile()

        with (
            patch("partomatic.partomatic.ocp_vscode.set_port") as set_port,
            patch("partomatic.partomatic.ocp_vscode.show_clear") as show_clear,
            patch("partomatic.partomatic.ocp_vscode.show") as show,
        ):
            foo.display(viewer_host="127.0.0.1", viewer_port=4040)

        set_port.assert_called_once_with(4040, host="127.0.0.1")
        show_clear.assert_called_once()
        show.assert_called_once()

    def test_display_maintains_consistent_bounding_boxes(self):
        """Verify display payload remains stable across repeated render calls."""

        foo = Widget()
        foo.compile()

        foo.display()
        first_payload = foo._viewer_geometry

        foo.display()
        second_payload = foo._viewer_geometry

        assert first_payload == second_payload

    def test_generate_viewer_geometry_populates_cache(self):
        foo = Widget()
        foo.compile()

        sentinel = {
            "parts": [{"id": 0, "vertices": [1.0, 2.0, 3.0], "indices": [0, 0, 0]}]
        }
        with patch("partomatic.partomatic.serialize_parts", return_value=sentinel):
            payload = foo.generate_viewer_geometry()

        assert payload == sentinel
        assert foo._viewer_geometry == sentinel

    def test_main_block(self):
        from unittest.mock import patch
        import runpy
        from pathlib import Path
        import os
        import sys

        script = str(Path(__file__).parents[1] / "src/partomatic/partomatic.py")
        src_root = str(Path(script).resolve().parents[1])
        script_dir = str(Path(script).resolve().parent)
        # Remove src_root so the insert branch fires; keep script_dir so the remove branch fires
        pruned_sys_path = [p for p in sys.path if os.path.abspath(p) != src_root] + [
            script_dir
        ]

        def fake_launch(self, **kwargs):
            self.compile()

        with patch(
            "partomatic.partomatic_preview.PartomaticPreviewMixin.launch_configurator",
            fake_launch,
        ), patch.object(sys, "path", pruned_sys_path):
            runpy.run_path(script, run_name="__main__")
            assert sys.path[0] == src_root

    def test_main_block_when_path_already_prepared(self):
        from unittest.mock import patch
        import runpy
        from pathlib import Path
        import os
        import sys

        script = str(Path(__file__).parents[1] / "src/partomatic/partomatic.py")
        src_root = str(Path(script).resolve().parents[1])
        script_dir = str(Path(script).resolve().parent)
        preconfigured = [src_root] + [
            p for p in sys.path if os.path.abspath(p) not in (src_root, script_dir)
        ]

        def fake_launch(self, **kwargs):
            self.compile()

        with patch(
            "partomatic.partomatic_preview.PartomaticPreviewMixin.launch_configurator",
            fake_launch,
        ), patch.object(sys, "path", preconfigured):
            runpy.run_path(script, run_name="__main__")
            assert sys.path[0] == src_root
            assert script_dir not in sys.path

    def test_invalid_class_level_config_raises_type_error(self):
        """Verify TypeError is raised when class-level config is not a PartomaticConfig."""

        # Case 1: config is a dict (invalid type)
        class BadWidget1(Partomatic):
            config = {"radius": 10}  # type: ignore

            def compile(self):
                pass

        with pytest.raises(
            TypeError,
            match="BadWidget1.config must be a PartomaticConfig instance",
        ):
            BadWidget1()

        # Case 2: config is None
        class BadWidget2(Partomatic):
            config = None  # type: ignore

            def compile(self):
                pass

        with pytest.raises(
            TypeError,
            match="BadWidget2.config must be a PartomaticConfig instance",
        ):
            BadWidget2()

        # Case 3: config is a string
        class BadWidget3(Partomatic):
            config = "not_a_config"  # type: ignore

            def compile(self):
                pass

        with pytest.raises(
            TypeError,
            match="BadWidget3.config must be a PartomaticConfig instance",
        ):
            BadWidget3()

    def test_load_config_failure_branch_re_raises_exception(self):
        class ExplodingConfig(WidgetConfig):
            def load_config(self, _configuration, **_kwargs):
                raise RuntimeError("boom")

        class ExplodingWidget(Partomatic):
            config = ExplodingConfig()

            def compile(self):
                pass

        with pytest.raises(RuntimeError, match="boom"):
            ExplodingWidget()
