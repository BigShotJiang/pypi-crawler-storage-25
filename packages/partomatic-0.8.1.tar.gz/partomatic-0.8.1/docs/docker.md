# Docker Deployment

Partomatic can be run in containers with a single configurator service. The current deployment model uses NiceGUI for config editing and an integrated three.js viewer rendered in the same web app.

## What This Folder Contains

- [Dockerfile](../docker/Dockerfile) builds a Python 3.13 image with Partomatic, NiceGUI, and build123d dependencies.
- [docker-compose.yml](../docker/docker-compose.yml) defines the demo service, port mapping, and optional Traefik labels.
- [sample.env](../docker/sample.env) shows runtime environment variables used by the demo.
- [app/server.py](../docker/app/server.py) is a working example entrypoint that launches a demo part.

## Quick Start

1. Copy the `docker` folder into a location where you want to build and run the container.
2. Rename [sample.env](../docker/sample.env) to `.env` and adjust values for your environment.
3. Put your own Python files in [app/](../docker/app/) or replace demo code in [server.py](../docker/app/server.py) with your own Partomatic subclass.
4. Build and start with Docker Compose.

```bash
docker compose up --build
```

The configurator will be exposed on the configured Partomatic port.

## How The Demo Works

The example server in [app/server.py](../docker/app/server.py) does three things:

1. Creates a small demo `Partomatic` subclass.
2. Sets `enable_step_exports` so the STEP export option is available in the UI.
3. Launches the configurator.

## Replacing The Demo With Your Own Part

The quickest path is to copy your project code into [docker/app/](../docker/app/) and update [server.py](../docker/app/server.py) to import and launch your own model.

At a minimum, your server entrypoint should:

- define a `PartomaticConfig` subclass with your parameters
- define a `Partomatic` subclass with a `compile()` method
- instantiate your part
- call `launch_configurator(...)`

## Environment Variables

The docker container reads runtime settings from [.env](../docker/sample.env).:

- `PUBLIC_HOST` for public hostname used by reverse proxy labels.
- `BIND_HOST` and `BIND_PORT` for NiceGUI bind address/port inside the container.
- `PARTOMATIC_TLS_RESOLVER` for Traefik certificate resolver name when TLS is enabled.
- `PARTOMATIC_MAX_YAML_UPLOAD_KB` for maximum uploaded YAML size accepted by the configurator.
- `PARTOMATIC_LOG_LEVEL` for log verbosity (`DEBUG`, `INFO`, `WARNING`, `ERROR`, `CRITICAL`).
- `PARTOMATIC_LOG_FORMAT` for output format (`console` or `json`).
- `PARTOMATIC_APP_MODE` for the `app.mode` field in structured logs.
- `PARTOMATIC_DEPLOYMENT_ENV` for the `deployment.environment` field in structured logs.

Notes on logging behavior:
- If `PARTOMATIC_LOG_LEVEL` is invalid or unset, Partomatic defaults to `INFO`.
- If `PARTOMATIC_LOG_FORMAT` is invalid or unset, Partomatic defaults based on app mode:
	- `configurator` mode defaults to `json`
	- other modes default to `console`

Inside a container, the configurator should usually bind to `0.0.0.0` so Docker can route traffic into it.

## Reverse Proxy / Traefik

The Compose file includes Traefik labels and an optional external network block for deployments where Traefik terminates TLS and forwards traffic to the Partomatic container.

When running behind Traefik:

- keep internal service ports on the container side unchanged
- configure public hostnames in labels and environment variables
- ensure the router service port points at the configurator app port

## Compose Notes

The example Compose file uses a named service and network so it can be launched as a standalone demo. Update service/image names and hostnames to match your deployment.

The provided port mapping is:

- `8505` for the Partomatic configurator

If you change ports in `.env`, keep Compose mappings and application launch arguments in sync.

## Suggested Workflow

For a new project, this setup is usually enough:

1. Copy the Docker folder into your project.
2. Update demo server to import your own Partomatic model.
3. Adjust `.env` for hostnames, ports, and proxy settings.
4. Build the image and confirm the configurator starts.
5. Re-enable and customize Traefik labels only after direct container run is working.

## Troubleshooting

If the container starts but the preview area remains blank, check browser devtools for JavaScript errors and verify your model compiles in the server logs.

If the app is deployed behind HTTPS and static assets fail to load, verify proxy headers and TLS routing in Traefik configuration.
