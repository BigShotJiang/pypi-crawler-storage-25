# WebUI Telemetry

Telemetry is emitted by the Partomatic configurator WebUI that can be routed to your observability platform.

## Scope

The configurator emits structured events through the standard Python logging system. In `json` log format, each log line is a JSON object that can be shipped to common observability platforms.

This telemetry currently covers:

- configurator startup
- render lifecycle (requested/succeeded/failed)
- export lifecycle for STL/STEP (requested/succeeded/failed)
- YAML upload lifecycle (started/succeeded/failed)
- YAML/STEP/STL downloads
- background job lifecycle and rejection

## Structured Log Fields

When `PARTOMATIC_LOG_FORMAT=json`, each event includes common fields:

- `timestamp`: UTC timestamp in ISO-8601 format
- `severity`: Python log level (`INFO`, `WARNING`, `ERROR`, etc.)
- `message`: raw message text (typically same as `event.name`)
- `logger`: logger namespace (for example `partomatic.configurator`)
- `event.name`: event identifier
- `event.outcome`: outcome label (`success` by default)
- `app.mode`: app mode (`configurator` for WebUI flows)
- `deployment.environment`: environment label (`dev`, `staging`, `prod`, etc.)

Additional event-specific fields are attached per event (for example `export_format`, `filename`, or `error_type`).

## WebUI Event Catalog

### Startup

- `configurator.started`
  - fields: `host`, `port`, `max_yaml_upload_kb`

### Rendering

- `render.requested`
- `render.succeeded`
- `render.failed`
  - fields: `error_type`, `error_message` (on failure)

### Exports (STL/STEP)

- `export.requested`
  - fields: `export_format` (`stl` or `step`)
- `export.succeeded`
  - fields: `export_format`, `filename`, `media_type`
- `export.failed`
  - fields: `export_format`, `error_type`, `error_message`

### Config Download

- `config.downloaded`
  - fields: `filename`, `media_type`

### YAML Upload

- `upload_yaml.started`
  - fields: `file_name`
- `upload_yaml.succeeded`
  - fields: `file_name`, `upload_size_bytes`
- `upload_yaml.failed`
  - fields: `error_type`, `error_message`
  - outcome: `rejected` when upload exceeds configured size limit, otherwise `failure`

### Background Jobs

- `job.started`
  - fields: `job_name`
- `job.succeeded`
  - fields: `job_name`
- `job.failed`
  - fields: `job_name`, `error_type`, `error_message`
- `job.rejected`
  - fields: `job_name`, `active_job_name`
  - outcome: `rejected`

## Environment Variables

These variables control WebUI telemetry behavior:

- `PARTOMATIC_LOG_LEVEL`
  - valid values include: `DEBUG`, `INFO`, `WARNING`, `ERROR`, `CRITICAL`
  - default: `INFO`
- `PARTOMATIC_LOG_FORMAT`
  - values: `console`, `json`
  - default behavior when unset/invalid:
    - `configurator` mode defaults to `json`
    - other modes default to `console`
- `PARTOMATIC_APP_MODE`
  - propagated as `app.mode`
  - typical value for WebUI: `configurator`
- `PARTOMATIC_DEPLOYMENT_ENV`
  - propagated as `deployment.environment`

## Example JSON Event

```json
{
  "timestamp": "2026-05-22T18:04:19.623Z",
  "severity": "INFO",
  "message": "export.succeeded",
  "logger": "partomatic.configurator",
  "event.name": "export.succeeded",
  "event.outcome": "success",
  "app.mode": "configurator",
  "deployment.environment": "prod",
  "export_format": "stl",
  "filename": "wheel-stls.zip",
  "media_type": "model/stl"
}
```

## Shipping to Observability Platforms

Recommended pattern:

1. Keep Partomatic emitting structured JSON logs.
2. Use an OpenTelemetry Collector (or equivalent log shipper) to ingest container stdout or file logs.
3. Parse JSON and map keys (`event.name`, `event.outcome`, `app.mode`, `deployment.environment`) to your backend schema.
4. Forward to your telemetry backend.

This approach preserves rich event semantics from the WebUI.