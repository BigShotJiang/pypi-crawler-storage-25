# Partomatic

Partomatic is an [abstract base class](https://docs.python.org/3/library/abc.html) for creating automatable CAD components. There are 3 primary uses for Partomatic:
  - collecting user modifiable values into a centralized configuration for parametric modeling.
  - simplifying part generation for complex projects with multiple parts and configurations.
  - providing a web UI for configuring and downloading customized parts.

Partomatic automatically handles `__init__` and `load_config`. Overriding these methods is not recommended.

## Quick Start

A minimal Partomatic subclass requires only a `config` class variable typed to your `PartomaticConfig` descendant, and a `compile` method:

```python
from build123d import BuildPart, Box
from partomatic import AutomatablePart, Partomatic, PartomaticConfig

class WidgetConfig(PartomaticConfig):
    stl_folder: str = "./stls"
    size: float = 20.0

class Widget(Partomatic):
    config: WidgetConfig = WidgetConfig()

    def compile(self):
        self.parts.clear()
        with BuildPart() as body:
            Box(self.config.size, self.config.size, self.config.size)
        self.parts.append(
            AutomatablePart(
                body.part,
                "widget",
                stl_folder=self.config.stl_folder,
            )
        )

widget = Widget()
widget.partomate()  # compiles and exports STLs to ./stls/
```

## Defined Partomatic Variables

Partomatic defines two variables that your descendant classes will inherit:

```python
config: PartomaticConfig
parts: list[AutomatablePart] = field(default_factory=list)
```

`config` holds the parameters from a `PartomaticConfig` object. You must declare `config` as a class variable in each subclass, typed to your own `PartomaticConfig` descendant:

```python
class Widget(Partomatic):
    config: WidgetConfig = WidgetConfig()
```

`parts` is a list of `AutomatablePart` objects that `display`, `export_stls`, and `export_steps` operate on. Your `compile` method is responsible for populating it.

### Dirty tracking

Partomatic tracks whether `config` has changed since the last successful `compile` via the `is_dirty` property. This is used internally by `launch_configurator` to avoid redundant recompiles, and is available for your own workflows:

```python
widget.is_dirty  # True if config changed since last compile
```

## Built-in Methods

### `load_config`

```python
foo.load_config(configuration=None, **kwargs)
```

Loads configuration into this instance. `configuration` may be a file path, a YAML string, an existing compatible config object, or `None` to use defaults. Keyword arguments override individual fields.

See the [PartomaticConfig](partomatic_config.md) documentation for full details on configuration loading.

### Abstract `compile` method

`compile` is the one method you **must** implement in every subclass. It is responsible for generating the 3D geometry and should always clear `self.parts` before repopulating it:

```python
def compile(self):
    self.parts.clear()
    self.parts.append(
        AutomatablePart(
            self.complete_wheel(),
            "complete-wheel",
            stl_folder=self.config.stl_folder,
        )
    )
```

After a successful `compile`, `is_dirty` will return `False` until `config` changes again.

### `display`

```python
foo.display(viewer_host=None, viewer_port=None)
```

Renders each part in `self.parts` into the OCP CAD viewer (`ocp_vscode`) at its configured `display_location`. `display` does **not** call `compile` — call `compile` first if the geometry may be stale.

| Parameter | Type | Default | Description |
|-----------|------|---------|-------------|
| `viewer_host` | `str` | `None` | Compatibility argument retained for existing call sites. |
| `viewer_port` | `int` | `None` | Compatibility argument retained for existing call sites. |

```python
foo.display(viewer_host="127.0.0.1", viewer_port=3939)
```

The `viewer_*` values are optional and are primarily used when targeting an OCP standalone endpoint.

For the integrated configurator viewer, geometry updates are driven by `generate_viewer_geometry()`.

### `partomate`

```python
foo.partomate(export_steps=False)
```

Convenience method that calls `compile` then `export_stls`. Pass `export_steps=True` to also write STEP files.

| Parameter | Type | Default | Description |
|-----------|------|---------|-------------|
| `export_steps` | `bool` | `False` | When `True`, also exports STEP files after STLs. |

```python
foo.partomate(export_steps=True)
```

### `export_stls`

```python
paths = foo.export_stls()
```

Exports all parts in `self.parts` as STL files. The file path for each part is composed from:

- `self.config.stl_folder` (or the part's own `stl_folder`)
- `self.config.file_prefix`
- `AutomatablePart.file_name_base`
- `self.config.file_suffix`

> **Relative paths** for `stl_folder` are resolved relative to the directory containing your subclass file, not the current working directory.

> **Disabling exports:** set `stl_folder = "NONE"` in your config to skip all file writes (useful for testing or display-only workflows).

> **`file_prefix` and `file_suffix`:** these can be set in a configuration file to make alternate versions of components easy to identify.

If `create_folders_if_missing` is `False` and the target directory does not exist, export raises `FileNotFoundError`. If `True` (default), missing directories are created automatically.

**Returns:** `list[Path]` — the paths of all files written.

### `export_steps`

```python
paths = foo.export_steps()
```

Identical to `export_stls`, but writes STEP files. Follows the same path resolution rules and returns `list[Path]`.

### `export_stls_to_directory` / `export_steps_to_directory`

```python
paths = foo.export_stls_to_directory(output_dir)
paths = foo.export_steps_to_directory(output_dir)
```

Export directly to an explicit directory without modifying your config. Useful for one-off or CI exports.

| Parameter | Type | Description |
|-----------|------|-------------|
| `output_dir` | `str \| Path` | Target directory for all exported files. |

```python
foo.export_stls_to_directory("/tmp/stls")
foo.export_steps_to_directory("/tmp/steps")
```

**Returns:** `list[Path]` — the paths of all files written.

### `launch_configurator`

```python
foo.launch_configurator(
    host="localhost",
    port=8505,
    port_retries=10,
    background=False,
)
```

Opens a combined NiceGUI web app with a live config editor and integrated three.js preview side by side. **Requires the `webui` extra:**

```bash
pip install partomatic[webui]
```

| Parameter | Type | Default | Description |
|-----------|------|---------|-------------|
| `host` | `str` | `"localhost"` | NiceGUI server host. |
| `port` | `int` | `8505` | Starting port. Incremented automatically if occupied. |
| `port_retries` | `int` | `10` | How many additional ports to try before failing. |
| `background` | `bool` | `False` | When `True`, runs the UI server in a daemon thread and returns immediately. |

Key capabilities:

- Live validation of config fields
- YAML load and YAML download
- STL download
- STEP download when `enable_step_exports` is `True`

```python
foo.launch_configurator(
    host="localhost",
    port=8505,
)
```

## Partomatic Logging

Partomatic logs to the `"partomatic"` namespace. Attach a handler to capture output:

```python
import logging
from sys import stdout

logger = logging.getLogger("partomatic")
logger.setLevel(logging.DEBUG)
logger.addHandler(logging.StreamHandler(stdout))

foo = Widget()
foo.config.stl_folder = "NONE"  # disable file writes
foo.partomate()
```
