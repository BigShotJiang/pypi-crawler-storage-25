import os

from build123d import BuildPart, Box, Sphere, Mode, Location
from dataclasses import field
from partomatic import Partomatic, PartomaticConfig, AutomatablePart


class DemoConfig(PartomaticConfig):
    stl_folder: str = "NONE"
    size: float = 20.0
    sphere_ratio: float = field(
        default=0.6,
        metadata={
            "kind": "float",
            "constraints": {"ge": 0.1, "le": 0.86},
            "step": 0.01,
        },
    )


class DemoPart(Partomatic):
    config: DemoConfig = DemoConfig()

    def compile(self):
        self.parts.clear()
        with BuildPart() as cube:
            Box(
                self.config.size,
                self.config.size,
                self.config.size,
            )
            Sphere(self.config.size * self.config.sphere_ratio, mode=Mode.SUBTRACT)
        with BuildPart() as ball:
            Box(
                self.config.size,
                self.config.size,
                self.config.size,
            )
            Sphere(self.config.size * self.config.sphere_ratio, mode=Mode.INTERSECT)
        cube.part.label = "cube"
        ball.part.label = "ball"
        self.parts.append(
            AutomatablePart(
                cube.part,
                "demo-cube",
                display_location=Location(
                    (self.config.size / 2 + self.config.size / 4, 0, 0)
                ),
                stl_folder=self.config.stl_folder,
            )
        )
        self.parts.append(
            AutomatablePart(
                ball.part,
                "demo-ball",
                display_location=Location(
                    (-self.config.size / 2 - self.config.size / 4, 0, 0)
                ),
                stl_folder=self.config.stl_folder,
            ),
        )


print("Starting Partomatic configurator demo.")
demo = DemoPart()
demo.config.enable_step_exports = True

config_host = os.getenv("BIND_HOST", "0.0.0.0")
config_port = int(os.getenv("BIND_PORT", "8505"))

demo.launch_configurator(
    host=config_host,
    port=config_port,
)
