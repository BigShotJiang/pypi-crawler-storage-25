"""
Workflow validation rules.
"""
