"""
Workflow context abstractions.
"""
