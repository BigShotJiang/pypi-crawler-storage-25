"""
Workflow execution configuration.
"""
