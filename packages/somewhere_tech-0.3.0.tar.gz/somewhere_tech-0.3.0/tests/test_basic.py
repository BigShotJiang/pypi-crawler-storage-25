"""Smoke test — creates a project, runs a migration, queries, deploys,
then deletes the project. Skipped unless SMT_KEY is set.

    SMT_KEY=smt_... python -m pytest tests/test_basic.py -s

Or just:

    SMT_KEY=smt_... python tests/test_basic.py
"""
from __future__ import annotations

import os
import random
import string
import sys

# Run cold without `pip install -e .` by putting the repo root on sys.path.
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "..")))

from somewhere import Somewhere, SomewhereError  # noqa: E402


def run() -> None:
    key = os.environ.get("SMT_KEY")
    if not key:
        print("SMT_KEY not set — skipping live API test.")
        return

    sw = Somewhere(key=key)
    suffix = "".join(random.choices(string.ascii_lowercase + string.digits, k=6))

    print("→ creating test project")
    project = sw.projects.create(
        name=f"SDK Smoke {suffix}", subdomain=f"sdk-smoke-py-{suffix}"
    )
    print(f"  created {project['id']} {project.get('subdomain')}")

    try:
        print("→ running migration")
        sw.db.migrate(
            """CREATE TABLE IF NOT EXISTS notes (
                 id INTEGER PRIMARY KEY,
                 body TEXT NOT NULL,
                 created_at TEXT DEFAULT (datetime('now'))
               );""",
            project["id"],
        )

        print("→ inserting row")
        sw.db.query(
            "INSERT INTO notes (body) VALUES (?)",
            ["hello from the python sdk smoke test"],
            project["id"],
        )

        print("→ reading rows")
        result = sw.db.query(
            "SELECT id, body FROM notes ORDER BY id DESC LIMIT 5", [], project["id"]
        )
        print(f"  rows: {result['rows']}")

        print("→ deploying a static file")
        deploy_result = sw.deploy(
            files={"index.html": "<h1>hello from the python sdk smoke test</h1>"},
            project_id=project["id"],
        )
        print(f"  deployed to {deploy_result.get('url')}")

        print("✅ smoke test passed")
    except SomewhereError as err:
        print(f"❌ API error [{err.code}] {err.message} (HTTP {err.status_code})")
        sys.exit(1)
    finally:
        print("→ cleaning up: deleting project")
        try:
            sw.projects.delete(project["id"])
            print("  deleted")
        except Exception as err:  # pragma: no cover
            print(f"  cleanup failed (ignore if already deleted): {err}")


if __name__ == "__main__":
    run()
