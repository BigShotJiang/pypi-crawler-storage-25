"""Email client for the somewhere.tech platform.

Provides a simple send() method for transactional email.
"""
from __future__ import annotations

from typing import Any, Dict, List, Optional, Union

import httpx

from .query_builder import Result


class EmailsClient:
    """Email sending interface. Access via sw.emails.

    Usage:
        result = sw.emails.send(
            to='user@test.com',
            subject='Hi',
            html='<h1>Hello</h1>',
        )
    """

    def __init__(
        self,
        project_id: str,
        http_client: httpx.Client,
        base_url: str,
        auth_header: str,
        extra_headers: Dict[str, str],
    ) -> None:
        self._project_id = project_id
        self._http = http_client
        self._base_url = base_url
        self._auth_header = auth_header
        self._extra_headers = extra_headers

    def send(
        self,
        *,
        to: Union[str, List[str]],
        subject: str,
        html: Optional[str] = None,
        text: Optional[str] = None,
        from_address: Optional[str] = None,
        reply_to: Optional[str] = None,
    ) -> Result:
        """Send a transactional email.

        Args:
            to: Recipient email address or list of addresses.
            subject: Email subject line.
            html: HTML body content.
            text: Plain text body content (fallback if html not provided).
            from_address: Sender address override.
            reply_to: Reply-to address.
        """
        payload: Dict[str, Any] = {
            "project_id": self._project_id,
            "to": to,
            "subject": subject,
        }
        if html is not None:
            payload["html"] = html
        if text is not None:
            payload["text"] = text
        if from_address is not None:
            payload["from"] = from_address
        if reply_to is not None:
            payload["reply_to"] = reply_to

        url = f"{self._base_url}/email/send"
        headers = {
            "Authorization": self._auth_header,
            "Accept": "application/json",
            "Content-Type": "application/json",
            **self._extra_headers,
        }
        try:
            response = self._http.post(url, json=payload, headers=headers)
            return self._parse(response)
        except httpx.HTTPError as exc:
            return Result(error={"code": "NETWORK_ERROR", "message": str(exc)})

    @staticmethod
    def _parse(response: httpx.Response) -> Result:
        try:
            body = response.json()
        except ValueError:
            return Result(error={
                "code": "INVALID_RESPONSE",
                "message": f"Non-JSON response (status {response.status_code})",
            })

        if isinstance(body, dict) and body.get("ok") is True:
            data = body.get("data")
            if isinstance(data, list):
                return Result(data=data, count=len(data))
            if isinstance(data, dict):
                return Result(data=[data], count=1)
            return Result(data=[data] if data is not None else [], count=1 if data else 0)

        error_code = body.get("error", "UNKNOWN_ERROR") if isinstance(body, dict) else "UNKNOWN_ERROR"
        error_message = body.get("message", "Unknown error") if isinstance(body, dict) else str(body)
        return Result(error={"code": error_code, "message": error_message})
