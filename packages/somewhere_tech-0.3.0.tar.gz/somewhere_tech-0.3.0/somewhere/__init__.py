"""Official Python SDK for the somewhere.tech platform API.

Supabase-compatible interface with query builder, auth, storage, email,
and OpenAI-compatible chat completions.

Usage:
    from somewhere import Somewhere

    sw = Somewhere(key='smt_...', project_id='my-project')

    # Database (Supabase-style query builder)
    result = sw.from_('users').select('*').eq('role', 'admin').execute()

    # Auth
    result = sw.auth.sign_up(email='u@test.com', password='pass123')

    # Storage
    result = sw.storage.from_('avatars').upload('photo.png', file_bytes)

    # Email
    result = sw.emails.send(to='user@test.com', subject='Hi', html='<h1>Hello</h1>')

    # AI (OpenAI-compatible)
    completion = sw.chat.completions.create(model='claude-sonnet-4-6', messages=[...])
"""
from __future__ import annotations

from typing import Dict, Optional

import httpx

from .auth import AuthClient
from .chat import ChatClient
from .client import (
    BillingClient,
    CronClient,
    DeployClient,
    DomainsClient,
    EnvClient,
    FeedbackClient,
    HttpClient,
    JobsClient,
    LogsClient,
    PreviewClient,
    ProjectsClient,
    QueueClient,
    UsageClient,
)
from .emails import EmailsClient
from .errors import SomewhereError
from .query_builder import QueryBuilder, Result
from .storage import StorageClient

__all__ = ["Somewhere", "SomewhereError", "Result"]
__version__ = "0.2.0"


class Somewhere:
    """Entry point for the somewhere.tech SDK.

    Provides a Supabase-compatible interface with query builder, auth,
    storage, email, and OpenAI-compatible chat completions.

    Args:
        key: Developer API key (smt_...). Mutually exclusive with token.
        token: App-user JWT. Mutually exclusive with key.
        project_id: Default project ID for all operations.
        base_url: API base URL (defaults to https://api.somewhere.tech/v1).
        http_client: Custom httpx.Client instance (optional).
        headers: Extra headers to send with every request (optional).
        timeout: Request timeout in seconds (default 60).

    Example:
        sw = Somewhere(key='smt_...', project_id='booking-app')
        result = sw.from_('users').select('*').eq('role', 'admin').execute()
        print(result.data)
    """

    def __init__(
        self,
        *,
        key: Optional[str] = None,
        token: Optional[str] = None,
        project_id: Optional[str] = None,
        base_url: str = "https://api.somewhere.tech/v1",
        http_client: Optional[httpx.Client] = None,
        headers: Optional[Dict[str, str]] = None,
        timeout: float = 60.0,
    ) -> None:
        self._http = HttpClient(
            key=key,
            token=token,
            project_id=project_id,
            base_url=base_url,
            http_client=http_client,
            headers=headers,
            timeout=timeout,
        )

        # Supabase-compatible clients
        self.auth = AuthClient(
            project_id=self._http.project_id,
            http_client=self._http.client,
            base_url=self._http.base_url,
            auth_header=self._http.auth_header,
            extra_headers=self._http.extra_headers,
        )
        self.storage = StorageClient(
            project_id=self._http.project_id,
            http_client=self._http.client,
            base_url=self._http.base_url,
            auth_header=self._http.auth_header,
            extra_headers=self._http.extra_headers,
        )
        self.emails = EmailsClient(
            project_id=self._http.project_id,
            http_client=self._http.client,
            base_url=self._http.base_url,
            auth_header=self._http.auth_header,
            extra_headers=self._http.extra_headers,
        )
        self.chat = ChatClient(
            project_id=self._http.project_id,
            http_client=self._http.client,
            base_url=self._http.base_url,
            auth_header=self._http.auth_header,
            extra_headers=self._http.extra_headers,
        )

        # Simple resource clients
        self.env = EnvClient(self._http)
        self.jobs = JobsClient(self._http)
        self.cron = CronClient(self._http)
        self.domains = DomainsClient(self._http)
        self.projects = ProjectsClient(self._http)
        self.deploy = DeployClient(self._http)
        self.logs = LogsClient(self._http)
        self.queue = QueueClient(self._http)
        self.billing = BillingClient(self._http)
        self.usage = UsageClient(self._http)
        self.feedback = FeedbackClient(self._http)
        self.preview = PreviewClient(self._http)

    def from_(self, table: str) -> QueryBuilder:
        """Start a Supabase-style query builder for the given table.

        Uses `from_` because `from` is a reserved word in Python.

        Args:
            table: The database table name.

        Returns:
            A QueryBuilder that supports .select(), .insert(), .update(),
            .delete(), .upsert(), plus filter chains (.eq(), .gt(), etc.)
            ending with .execute().

        Example:
            result = sw.from_('users').select('*').eq('role', 'admin').execute()
            result = sw.from_('users').insert({'name': 'A'}).execute()
        """
        return QueryBuilder(
            table=table,
            project_id=self._http.project_id,
            http_client=self._http.client,
            base_url=self._http.base_url,
            auth_header=self._http.auth_header,
            extra_headers=self._http.extra_headers,
        )
