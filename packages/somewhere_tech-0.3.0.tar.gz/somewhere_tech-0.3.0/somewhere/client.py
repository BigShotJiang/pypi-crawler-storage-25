"""Internal HTTP client and simple resource classes for the somewhere.tech SDK.

This module contains:
- HttpClient: low-level httpx wrapper used by all SDK modules
- Result: re-exported from query_builder for convenience
- Simple resource clients (EnvClient, JobsClient, CronClient, DomainsClient,
  ProjectsClient, DeployClient, LogsClient, FsClient, etc.) that return Result
  objects for endpoints that don't need the query builder pattern.
"""
from __future__ import annotations

from typing import Any, Dict, List, Optional, Union
from urllib.parse import quote

import httpx

from .query_builder import Result

DEFAULT_BASE_URL = "https://api.somewhere.tech/v1"


class HttpClient:
    """Internal HTTP client. Not part of the public API -- use Somewhere."""

    def __init__(
        self,
        *,
        key: Optional[str] = None,
        token: Optional[str] = None,
        project_id: Optional[str] = None,
        base_url: str = DEFAULT_BASE_URL,
        http_client: Optional[httpx.Client] = None,
        headers: Optional[Dict[str, str]] = None,
        timeout: float = 60.0,
    ) -> None:
        if not key and not token:
            raise ValueError("Somewhere: pass either `key` (smt_...) or `token` (JWT).")
        if key and token:
            raise ValueError("Somewhere: pass `key` OR `token`, not both.")

        self.base_url = base_url.rstrip("/")
        self.project_id = project_id or ""
        self.auth_header = f"Bearer {key or token}"
        self.extra_headers = headers or {}
        self.client = http_client or httpx.Client(timeout=timeout)

    def request(
        self,
        method: str,
        path: str,
        *,
        json_body: Optional[Any] = None,
        params: Optional[Dict[str, Any]] = None,
    ) -> Result:
        """Make an HTTP request and return a Result."""
        url = f"{self.base_url}{path}"
        headers = {
            "Authorization": self.auth_header,
            "Accept": "application/json",
            "Content-Type": "application/json",
            **self.extra_headers,
        }
        # Strip None values from json and params
        if isinstance(json_body, dict):
            json_body = {k: v for k, v in json_body.items() if v is not None}
        if params:
            params = {k: v for k, v in params.items() if v is not None}

        try:
            response = self.client.request(
                method,
                url,
                json=json_body,
                params=params or None,
                headers=headers,
            )
            return _parse_response(response)
        except httpx.HTTPError as exc:
            return Result(error={"code": "NETWORK_ERROR", "message": str(exc)})


def _parse_response(response: httpx.Response) -> Result:
    """Parse an API response into a Result."""
    try:
        body = response.json()
    except ValueError:
        return Result(error={
            "code": "INVALID_RESPONSE",
            "message": f"Non-JSON response (status {response.status_code})",
        })

    if isinstance(body, dict) and body.get("ok") is True:
        data = body.get("data")
        if isinstance(data, list):
            return Result(data=data, count=len(data))
        if isinstance(data, dict):
            return Result(data=[data], count=1)
        return Result(data=[data] if data is not None else [], count=1 if data else 0)

    error_code = body.get("error", "UNKNOWN_ERROR") if isinstance(body, dict) else "UNKNOWN_ERROR"
    error_message = body.get("message", "Unknown error") if isinstance(body, dict) else str(body)
    return Result(error={"code": error_code, "message": error_message})


# ---------------------------------------------------------------------------
# Simple resource clients for endpoints that don't use query builder
# ---------------------------------------------------------------------------


class EnvClient:
    """Environment variable management. Access via sw.env."""

    def __init__(self, http: HttpClient) -> None:
        self._http = http

    def set(self, key: str, value: str, *, project_id: Optional[str] = None) -> Result:
        """Set an environment variable."""
        pid = project_id or self._http.project_id
        return self._http.request("POST", "/env", json_body={
            "project_id": pid,
            "key": key,
            "value": value,
        })

    def get(self, key: str, *, project_id: Optional[str] = None) -> Result:
        """Get a specific environment variable."""
        pid = project_id or self._http.project_id
        return self._http.request("GET", f"/env/{quote(pid)}/{quote(key)}")

    def list(self, *, project_id: Optional[str] = None) -> Result:
        """List all environment variables."""
        pid = project_id or self._http.project_id
        return self._http.request("GET", "/env", params={"project_id": pid})

    def delete(self, key: str, *, project_id: Optional[str] = None) -> Result:
        """Delete an environment variable."""
        pid = project_id or self._http.project_id
        return self._http.request("DELETE", f"/env/{quote(pid)}/{quote(key)}")


class JobsClient:
    """Background job management. Access via sw.jobs."""

    def __init__(self, http: HttpClient) -> None:
        self._http = http

    def create(
        self,
        *,
        handler: str,
        payload: Optional[Any] = None,
        webhook_url: Optional[str] = None,
        timeout_seconds: Optional[int] = None,
        priority: Optional[str] = None,
        project_id: Optional[str] = None,
    ) -> Result:
        """Create a background job."""
        pid = project_id or self._http.project_id
        return self._http.request("POST", "/jobs", json_body={
            "project_id": pid,
            "handler": handler,
            "payload": payload,
            "webhook_url": webhook_url,
            "timeout_seconds": timeout_seconds,
            "priority": priority,
        })

    def status(self, job_id: str) -> Result:
        """Get the status of a job."""
        return self._http.request("GET", f"/jobs/{quote(job_id)}")

    def list(
        self,
        *,
        status: Optional[str] = None,
        limit: Optional[int] = None,
        project_id: Optional[str] = None,
    ) -> Result:
        """List jobs."""
        pid = project_id or self._http.project_id
        return self._http.request("GET", "/jobs", params={
            "project_id": pid,
            "status": status,
            "limit": limit,
        })

    def cancel(self, job_id: str) -> Result:
        """Cancel a running job."""
        return self._http.request("POST", f"/jobs/{quote(job_id)}/cancel")

    def progress(
        self,
        job_id: str,
        *,
        progress: Optional[float] = None,
        message: Optional[str] = None,
    ) -> Result:
        """Report job progress."""
        return self._http.request("POST", f"/jobs/{quote(job_id)}/progress", json_body={
            "progress": progress,
            "message": message,
        })


class CronClient:
    """Cron job management. Access via sw.cron."""

    def __init__(self, http: HttpClient) -> None:
        self._http = http

    def create(
        self,
        *,
        schedule: str,
        handler: str,
        payload: Optional[Any] = None,
        name: Optional[str] = None,
        enabled: Optional[bool] = None,
        project_id: Optional[str] = None,
    ) -> Result:
        """Create a cron job."""
        pid = project_id or self._http.project_id
        return self._http.request("POST", "/cron", json_body={
            "project_id": pid,
            "schedule": schedule,
            "handler": handler,
            "payload": payload,
            "name": name,
            "enabled": enabled,
        })

    def list(self, *, project_id: Optional[str] = None) -> Result:
        """List cron jobs."""
        pid = project_id or self._http.project_id
        return self._http.request("GET", "/cron", params={"project_id": pid})

    def update(
        self,
        cron_id: str,
        *,
        schedule: Optional[str] = None,
        handler: Optional[str] = None,
        payload: Optional[Any] = None,
        enabled: Optional[bool] = None,
        name: Optional[str] = None,
    ) -> Result:
        """Update a cron job."""
        return self._http.request("PATCH", f"/cron/{quote(cron_id)}", json_body={
            "schedule": schedule,
            "handler": handler,
            "payload": payload,
            "enabled": enabled,
            "name": name,
        })

    def delete(self, cron_id: str) -> Result:
        """Delete a cron job."""
        return self._http.request("DELETE", f"/cron/{quote(cron_id)}")


class DomainsClient:
    """Custom domain management. Access via sw.domains."""

    def __init__(self, http: HttpClient) -> None:
        self._http = http

    def add(self, domain: str, *, project_id: Optional[str] = None) -> Result:
        """Add a custom domain to a project."""
        pid = project_id or self._http.project_id
        return self._http.request("POST", "/domains/add", json_body={
            "project_id": pid,
            "domain": domain,
        })

    def verify(self, domain: str) -> Result:
        """Verify DNS for a custom domain."""
        return self._http.request("GET", "/domains/verify", params={"domain": domain})

    def list(self, *, project_id: Optional[str] = None) -> Result:
        """List custom domains."""
        pid = project_id or self._http.project_id
        return self._http.request("GET", "/domains", params={"project_id": pid})

    def delete(self, domain: str) -> Result:
        """Remove a custom domain."""
        return self._http.request("DELETE", f"/domains/{quote(domain)}")


class ProjectsClient:
    """Project management. Access via sw.projects."""

    def __init__(self, http: HttpClient) -> None:
        self._http = http

    def create(
        self,
        name: str,
        *,
        description: Optional[str] = None,
        subdomain: Optional[str] = None,
    ) -> Result:
        """Create a new project."""
        return self._http.request("POST", "/projects", json_body={
            "name": name,
            "description": description,
            "subdomain": subdomain,
        })

    def list(self) -> Result:
        """List all projects."""
        return self._http.request("GET", "/projects")

    def get(self, project_id: str) -> Result:
        """Get a specific project."""
        return self._http.request("GET", f"/projects/{quote(project_id)}")

    def delete(self, project_id: str) -> Result:
        """Delete a project."""
        return self._http.request("DELETE", f"/projects/{quote(project_id)}")

    def rename(
        self,
        project_id: str,
        *,
        name: Optional[str] = None,
        subdomain: Optional[str] = None,
        description: Optional[str] = None,
    ) -> Result:
        """Rename or update a project."""
        return self._http.request("PATCH", f"/projects/{quote(project_id)}", json_body={
            "name": name,
            "subdomain": subdomain,
            "description": description,
        })

    def archive(self, project_id: str) -> Result:
        """Archive a project."""
        return self._http.request("POST", f"/projects/{quote(project_id)}/archive")

    def unarchive(self, project_id: str) -> Result:
        """Unarchive a project."""
        return self._http.request("POST", f"/projects/{quote(project_id)}/unarchive")

    def deploys(self, project_id: str) -> Result:
        """List deploys for a project."""
        return self._http.request("GET", f"/projects/{quote(project_id)}/deploys")


class DeployClient:
    """Deployment operations. Access via sw.deploy."""

    def __init__(self, http: HttpClient) -> None:
        self._http = http

    def __call__(
        self,
        files: Dict[str, Any],
        *,
        functions: Optional[Dict[str, Any]] = None,
        project_id: Optional[str] = None,
    ) -> Result:
        """Deploy files to a project."""
        pid = project_id or self._http.project_id
        return self._http.request("POST", "/deploy", json_body={
            "project_id": pid,
            "files": files,
            "functions": functions,
        })

    def status(self, *, project_id: Optional[str] = None) -> Result:
        """Get deployment status."""
        pid = project_id or self._http.project_id
        return self._http.request("GET", "/deploy/status", params={"project_id": pid})


class LogsClient:
    """Log management. Access via sw.logs."""

    def __init__(self, http: HttpClient) -> None:
        self._http = http

    def write(
        self,
        *,
        level: str,
        message: str,
        data: Optional[Dict[str, Any]] = None,
        project_id: Optional[str] = None,
    ) -> Result:
        """Write a log entry."""
        pid = project_id or self._http.project_id
        return self._http.request("POST", "/logs", json_body={
            "project_id": pid,
            "level": level,
            "message": message,
            "data": data,
        })

    def read(
        self,
        *,
        level: Optional[str] = None,
        source: Optional[str] = None,
        search: Optional[str] = None,
        after: Optional[str] = None,
        before: Optional[str] = None,
        limit: Optional[int] = None,
        project_id: Optional[str] = None,
    ) -> Result:
        """Read log entries."""
        pid = project_id or self._http.project_id
        return self._http.request("GET", "/logs", params={
            "project_id": pid,
            "level": level,
            "source": source,
            "search": search,
            "after": after,
            "before": before,
            "limit": limit,
        })


class QueueClient:
    """Message queue operations. Access via sw.queue."""

    def __init__(self, http: HttpClient) -> None:
        self._http = http

    def push(
        self,
        *,
        handler: str,
        payload: Optional[Any] = None,
        delay_seconds: Optional[int] = None,
        project_id: Optional[str] = None,
    ) -> Result:
        """Push a message to the queue."""
        pid = project_id or self._http.project_id
        return self._http.request("POST", "/queue", json_body={
            "project_id": pid,
            "handler": handler,
            "payload": payload,
            "delay_seconds": delay_seconds,
        })


class BillingClient:
    """Billing operations. Access via sw.billing."""

    def __init__(self, http: HttpClient) -> None:
        self._http = http

    def status(self) -> Result:
        """Get billing status."""
        return self._http.request("GET", "/billing/status")

    def checkout(self, plan: str = "builder") -> Result:
        """Start a checkout session."""
        return self._http.request("POST", "/billing/checkout", json_body={"plan": plan})

    def portal(self) -> Result:
        """Get billing portal URL."""
        return self._http.request("POST", "/billing/portal")


class UsageClient:
    """Usage reporting. Access via sw.usage."""

    def __init__(self, http: HttpClient) -> None:
        self._http = http

    def get(self, *, project_id: Optional[str] = None) -> Result:
        """Get usage for a project."""
        pid = project_id or self._http.project_id
        return self._http.request("GET", "/usage", params={
            "project_id": pid,
            "period": "30d",
        })

    def summary(self) -> Result:
        """Get usage summary across all projects."""
        return self._http.request("GET", "/usage/summary")


class FeedbackClient:
    """Feedback operations. Access via sw.feedback."""

    def __init__(self, http: HttpClient) -> None:
        self._http = http

    def submit(
        self,
        *,
        message: str,
        screenshot_url: Optional[str] = None,
        page_url: Optional[str] = None,
        project_id: Optional[str] = None,
    ) -> Result:
        """Submit feedback."""
        pid = project_id or self._http.project_id
        return self._http.request(
            "POST",
            f"/projects/{quote(pid)}/feedback",
            json_body={
                "message": message,
                "page_url": page_url,
                "screenshot_url": screenshot_url,
            },
        )

    def list(self, *, project_id: Optional[str] = None) -> Result:
        """List feedback for a project."""
        pid = project_id or self._http.project_id
        return self._http.request("GET", f"/projects/{quote(pid)}/feedback")


class PreviewClient:
    """Preview sharing operations. Access via sw.preview."""

    def __init__(self, http: HttpClient) -> None:
        self._http = http

    def invite(self, email: str, *, project_id: Optional[str] = None) -> Result:
        """Invite someone to preview."""
        pid = project_id or self._http.project_id
        return self._http.request("POST", "/preview/invite", json_body={
            "project_id": pid,
            "email": email,
        })

    def revoke(self, email: str, *, project_id: Optional[str] = None) -> Result:
        """Revoke preview access."""
        pid = project_id or self._http.project_id
        return self._http.request("POST", "/preview/revoke", json_body={
            "project_id": pid,
            "email": email,
        })

    def viewers(self, *, project_id: Optional[str] = None) -> Result:
        """List preview viewers."""
        pid = project_id or self._http.project_id
        return self._http.request("GET", "/preview/viewers", params={"project_id": pid})
