"""Typed error class for the somewhere.tech SDK."""
from __future__ import annotations

from typing import Any, Optional


class SomewhereError(Exception):
    """Raised for non-recoverable errors (network failures, chat API errors).

    For most SDK methods, errors are returned in Result.error instead of
    being raised. SomewhereError is only raised by chat.completions.create
    (to match the OpenAI SDK convention) and for truly unrecoverable issues
    like missing credentials.

    Attributes:
        code:          Platform error code, e.g. "D1_TABLE_NOT_FOUND".
        message:       Human-readable description.
        status_code:   HTTP status code (400, 402, 429, 500, ...).
        retry:         Whether the client should retry.
        retry_after_ms: Milliseconds to wait before retrying, if known.
        body:          The full parsed response body, for inspection.
    """

    def __init__(
        self,
        code: str,
        message: str,
        status_code: int = 0,
        retry: bool = False,
        retry_after_ms: Optional[int] = None,
        body: Any = None,
    ) -> None:
        super().__init__(message)
        self.code = code
        self.message = message
        self.status_code = status_code
        self.retry = retry
        self.retry_after_ms = retry_after_ms
        self.body = body

    def __repr__(self) -> str:
        return (
            f"SomewhereError(code={self.code!r}, status={self.status_code}, "
            f"message={self.message!r})"
        )
