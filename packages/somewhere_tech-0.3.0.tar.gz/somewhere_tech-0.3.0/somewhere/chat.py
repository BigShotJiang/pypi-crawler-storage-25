"""OpenAI-compatible chat completions client for the somewhere.tech AI API.

This module deliberately raises SomewhereError on failure (instead of returning
Result) to match the OpenAI SDK convention where chat.completions.create raises
on error.
"""
from __future__ import annotations

from typing import Any, Dict, List, Optional

import httpx

from .errors import SomewhereError


class ChatMessage:
    """A single message in a chat completion response."""

    def __init__(self, role: str, content: str) -> None:
        self.role = role
        self.content = content

    def __repr__(self) -> str:
        preview = self.content[:80] + "..." if len(self.content) > 80 else self.content
        return f"ChatMessage(role={self.role!r}, content={preview!r})"


class ChatChoice:
    """A single choice in a chat completion response."""

    def __init__(
        self,
        index: int,
        message: ChatMessage,
        finish_reason: Optional[str] = None,
    ) -> None:
        self.index = index
        self.message = message
        self.finish_reason = finish_reason

    def __repr__(self) -> str:
        return f"ChatChoice(index={self.index}, finish_reason={self.finish_reason!r})"


class ChatUsage:
    """Token usage for a chat completion."""

    def __init__(
        self,
        prompt_tokens: int = 0,
        completion_tokens: int = 0,
        total_tokens: int = 0,
    ) -> None:
        self.prompt_tokens = prompt_tokens
        self.completion_tokens = completion_tokens
        self.total_tokens = total_tokens

    def __repr__(self) -> str:
        return f"ChatUsage(prompt={self.prompt_tokens}, completion={self.completion_tokens}, total={self.total_tokens})"


class ChatCompletion:
    """OpenAI-compatible chat completion response object.

    Usage:
        completion = sw.chat.completions.create(
            model='claude-sonnet-4-6',
            messages=[{'role': 'user', 'content': 'Hello'}],
        )
        print(completion.choices[0].message.content)
    """

    def __init__(
        self,
        id: str,
        model: str,
        choices: List[ChatChoice],
        usage: Optional[ChatUsage] = None,
        created: Optional[int] = None,
    ) -> None:
        self.id = id
        self.object = "chat.completion"
        self.model = model
        self.choices = choices
        self.usage = usage
        self.created = created

    def __repr__(self) -> str:
        return f"ChatCompletion(id={self.id!r}, model={self.model!r}, choices={len(self.choices)})"


class ChatCompletionsClient:
    """OpenAI-compatible completions interface.

    Accessed via sw.chat.completions.create(...).
    Raises SomewhereError on failure (matches OpenAI SDK behavior).
    """

    def __init__(
        self,
        project_id: str,
        http_client: httpx.Client,
        base_url: str,
        auth_header: str,
        extra_headers: Dict[str, str],
    ) -> None:
        self._project_id = project_id
        self._http = http_client
        self._base_url = base_url
        self._auth_header = auth_header
        self._extra_headers = extra_headers

    def create(
        self,
        *,
        model: str,
        messages: List[Dict[str, str]],
        system: Optional[str] = None,
        max_tokens: Optional[int] = None,
        temperature: Optional[float] = None,
        top_p: Optional[float] = None,
        stop: Optional[List[str]] = None,
        provider: Optional[str] = None,
    ) -> ChatCompletion:
        """Create a chat completion.

        This method raises SomewhereError on failure (matching OpenAI SDK behavior).

        Args:
            model: Model identifier (e.g. 'claude-sonnet-4-6', 'gpt-4o').
            messages: List of message dicts with 'role' and 'content' keys.
            system: Optional system prompt.
            max_tokens: Maximum tokens to generate.
            temperature: Sampling temperature (0-2).
            top_p: Nucleus sampling parameter.
            stop: Stop sequences.
            provider: Override the AI provider.

        Returns:
            ChatCompletion with choices[0].message.content containing the response.

        Raises:
            SomewhereError: On API errors (matches OpenAI SDK convention).
        """
        payload: Dict[str, Any] = {
            "project_id": self._project_id,
            "model": model,
            "messages": messages,
        }
        if system is not None:
            payload["system"] = system
        if max_tokens is not None:
            payload["max_tokens"] = max_tokens
        if temperature is not None:
            payload["temperature"] = temperature
        if top_p is not None:
            payload["top_p"] = top_p
        if stop is not None:
            payload["stop"] = stop
        if provider is not None:
            payload["provider"] = provider

        url = f"{self._base_url}/ai/complete"
        headers = {
            "Authorization": self._auth_header,
            "Accept": "application/json",
            "Content-Type": "application/json",
            **self._extra_headers,
        }

        try:
            response = self._http.post(url, json=payload, headers=headers)
        except httpx.HTTPError as exc:
            raise SomewhereError(
                code="NETWORK_ERROR",
                message=str(exc),
                status_code=0,
            )

        try:
            body = response.json()
        except ValueError:
            raise SomewhereError(
                code="INVALID_RESPONSE",
                message=f"Non-JSON response (status {response.status_code})",
                status_code=response.status_code,
            )

        # Error response
        if isinstance(body, dict) and body.get("ok") is False:
            raise SomewhereError(
                code=body.get("error", "UNKNOWN_ERROR"),
                message=body.get("message", "Unknown error"),
                status_code=response.status_code,
                retry=bool(body.get("retry", False)),
                retry_after_ms=body.get("retry_after_ms"),
                body=body,
            )

        if not isinstance(body, dict) or body.get("ok") is not True:
            raise SomewhereError(
                code="INVALID_RESPONSE",
                message=f"Unexpected response shape (status {response.status_code})",
                status_code=response.status_code,
                body=body,
            )

        data = body.get("data", {})
        return self._to_completion(data, model)

    @staticmethod
    def _to_completion(data: Any, requested_model: str) -> ChatCompletion:
        """Convert API response data into an OpenAI-compatible ChatCompletion."""
        if not isinstance(data, dict):
            data = {}

        # The API may return data in different shapes. Handle both
        # OpenAI-compatible and platform-native formats.

        # If the response already has 'choices', use them directly
        if "choices" in data:
            choices = []
            for i, choice_data in enumerate(data["choices"]):
                msg = choice_data.get("message", {})
                choices.append(ChatChoice(
                    index=choice_data.get("index", i),
                    message=ChatMessage(
                        role=msg.get("role", "assistant"),
                        content=msg.get("content", ""),
                    ),
                    finish_reason=choice_data.get("finish_reason"),
                ))
            usage_data = data.get("usage", {})
            usage = ChatUsage(
                prompt_tokens=usage_data.get("prompt_tokens", 0),
                completion_tokens=usage_data.get("completion_tokens", 0),
                total_tokens=usage_data.get("total_tokens", 0),
            ) if usage_data else None

            return ChatCompletion(
                id=data.get("id", ""),
                model=data.get("model", requested_model),
                choices=choices,
                usage=usage,
                created=data.get("created"),
            )

        # Platform-native format: data might have 'content' or 'text' directly
        content = data.get("content") or data.get("text") or data.get("response") or ""
        model_used = data.get("model", requested_model)

        usage_data = data.get("usage", {})
        # Platform returns input_tokens/output_tokens, OpenAI uses prompt/completion
        prompt = usage_data.get("prompt_tokens") or usage_data.get("input_tokens") or 0
        completion = usage_data.get("completion_tokens") or usage_data.get("output_tokens") or 0
        usage = ChatUsage(
            prompt_tokens=prompt,
            completion_tokens=completion,
            total_tokens=usage_data.get("total_tokens") or (prompt + completion),
        ) if usage_data else None

        return ChatCompletion(
            id=data.get("id", ""),
            model=model_used,
            choices=[
                ChatChoice(
                    index=0,
                    message=ChatMessage(role="assistant", content=str(content)),
                    finish_reason=data.get("finish_reason", "stop"),
                ),
            ],
            usage=usage,
            created=data.get("created"),
        )


class ChatClient:
    """Top-level chat client. Access via sw.chat.

    Provides sw.chat.completions.create(...) for OpenAI-compatible chat.
    """

    def __init__(
        self,
        project_id: str,
        http_client: httpx.Client,
        base_url: str,
        auth_header: str,
        extra_headers: Dict[str, str],
    ) -> None:
        self.completions = ChatCompletionsClient(
            project_id=project_id,
            http_client=http_client,
            base_url=base_url,
            auth_header=auth_header,
            extra_headers=extra_headers,
        )
