"""Auth client for the somewhere.tech platform -- Supabase-compatible interface.

Provides sign_up, sign_in_with_password, get_user, sign_out, and other
auth operations. All methods return Result objects (never raise).
"""
from __future__ import annotations

from typing import Any, Dict, List, Optional

import httpx

from .query_builder import Result


class AuthClient:
    """Supabase-compatible auth interface.

    Usage:
        result = sw.auth.sign_up(email='u@test.com', password='pass123')
        result = sw.auth.sign_in_with_password(email='u@test.com', password='pass123')
        result = sw.auth.get_user()
        result = sw.auth.sign_out()
    """

    def __init__(
        self,
        project_id: str,
        http_client: httpx.Client,
        base_url: str,
        auth_header: str,
        extra_headers: Dict[str, str],
    ) -> None:
        self._project_id = project_id
        self._http = http_client
        self._base_url = base_url
        self._auth_header = auth_header
        self._extra_headers = extra_headers
        self._session_token: Optional[str] = None

    def sign_up(
        self,
        *,
        email: str,
        password: str,
        metadata: Optional[Dict[str, Any]] = None,
    ) -> Result:
        """Create a new user account."""
        return self._post("/auth/signup", {
            "project_id": self._project_id,
            "email": email,
            "password": password,
            "metadata": metadata,
        })

    def sign_in_with_password(
        self,
        *,
        email: str,
        password: str,
    ) -> Result:
        """Sign in with email and password. Stores session token internally."""
        result = self._post("/auth/login", {
            "project_id": self._project_id,
            "email": email,
            "password": password,
        })
        if result.data and isinstance(result.data, list) and len(result.data) > 0:
            session = result.data[0]
            if isinstance(session, dict):
                self._session_token = session.get("token") or session.get("session_token")
        return result

    def get_user(self) -> Result:
        """Get the currently authenticated user."""
        return self._get("/auth/me")

    def sign_out(self) -> Result:
        """Sign out the current user."""
        payload: Dict[str, Any] = {"project_id": self._project_id}
        if self._session_token:
            payload["session_token"] = self._session_token
        result = self._post("/auth/logout", payload)
        if not result.error:
            self._session_token = None
        return result

    def forgot_password(self, *, email: str) -> Result:
        """Send a password reset email."""
        return self._post("/auth/forgot", {
            "project_id": self._project_id,
            "email": email,
        })

    def reset_password(self, *, token: str, new_password: str) -> Result:
        """Reset password using a reset token."""
        return self._post("/auth/reset", {
            "project_id": self._project_id,
            "token": token,
            "new_password": new_password,
        })

    def verify_email(self, *, code: str) -> Result:
        """Verify email with a verification code."""
        return self._post("/auth/verify-email", {"code": code})

    def request_verification(self) -> Result:
        """Request a new email verification code."""
        return self._post("/auth/request-email-verification", {})

    def update_user(
        self,
        *,
        display_name: Optional[str] = None,
        metadata: Optional[Dict[str, Any]] = None,
    ) -> Result:
        """Update the current user's profile."""
        payload: Dict[str, Any] = {}
        if display_name is not None:
            payload["display_name"] = display_name
        if metadata is not None:
            payload["metadata"] = metadata
        return self._request("PATCH", "/auth/users/me", json_body=payload)

    def delete_user(self) -> Result:
        """Delete the current user's account."""
        return self._request("DELETE", "/auth/users/me")

    def list_users(
        self,
        *,
        search: Optional[str] = None,
        limit: Optional[int] = None,
        cursor: Optional[str] = None,
        ids: Optional[List[str]] = None,
    ) -> Result:
        """List users (admin operation)."""
        params: Dict[str, Any] = {"project_id": self._project_id}
        if search is not None:
            params["search"] = search
        if limit is not None:
            params["limit"] = limit
        if cursor is not None:
            params["cursor"] = cursor
        if ids is not None:
            params["ids"] = ",".join(ids)
        return self._get("/auth/users", params=params)

    # --- Internal helpers ---

    def _headers(self) -> Dict[str, str]:
        return {
            "Authorization": self._auth_header,
            "Accept": "application/json",
            "Content-Type": "application/json",
            **self._extra_headers,
        }

    def _post(self, path: str, payload: Dict[str, Any]) -> Result:
        return self._request("POST", path, json_body=payload)

    def _get(self, path: str, params: Optional[Dict[str, Any]] = None) -> Result:
        return self._request("GET", path, params=params)

    def _request(
        self,
        method: str,
        path: str,
        json_body: Optional[Dict[str, Any]] = None,
        params: Optional[Dict[str, Any]] = None,
    ) -> Result:
        url = f"{self._base_url}{path}"
        try:
            if json_body is not None:
                # Strip None values
                json_body = {k: v for k, v in json_body.items() if v is not None}
            if params is not None:
                params = {k: v for k, v in params.items() if v is not None}

            response = self._http.request(
                method,
                url,
                json=json_body,
                params=params,
                headers=self._headers(),
            )
            return self._parse(response)
        except httpx.HTTPError as exc:
            return Result(error={"code": "NETWORK_ERROR", "message": str(exc)})

    @staticmethod
    def _parse(response: httpx.Response) -> Result:
        try:
            body = response.json()
        except ValueError:
            return Result(error={
                "code": "INVALID_RESPONSE",
                "message": f"Non-JSON response (status {response.status_code})",
            })

        if isinstance(body, dict) and body.get("ok") is True:
            data = body.get("data")
            if isinstance(data, list):
                return Result(data=data, count=len(data))
            if isinstance(data, dict):
                return Result(data=[data], count=1)
            return Result(data=[data] if data is not None else [], count=1 if data else 0)

        error_code = body.get("error", "UNKNOWN_ERROR") if isinstance(body, dict) else "UNKNOWN_ERROR"
        error_message = body.get("message", "Unknown error") if isinstance(body, dict) else str(body)
        return Result(error={"code": error_code, "message": error_message})
