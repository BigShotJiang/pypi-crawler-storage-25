"""Supabase-style query builder for the somewhere.tech database API.

Builds structured JSON queries and sends them to POST /v1/db/query.
Never sends raw SQL — all operations are expressed as structured filters,
inserts, updates, and deletes.

The platform endpoint accepts:
    { table, select?, filters?, order?, limit?, offset? }       — SELECT
    { table, insert: row_or_rows }                              — INSERT
    { table, update: {col: val}, filters? }                     — UPDATE
    { table, delete: true, filters? }                           — DELETE
    { table, upsert: row, onConflict: "col" }                  — UPSERT
"""
from __future__ import annotations

from typing import Any, Dict, List, Optional, Union

import httpx


class Result:
    """Return type for all query builder executions.

    Attributes:
        data:  List of row dicts on success, single dict if .single(), None on error.
        error: None on success, dict with 'code' and 'message' on failure.
        count: Row count if available, None otherwise.
    """

    def __init__(
        self,
        data: Any = None,
        error: Optional[Dict[str, Any]] = None,
        count: Optional[int] = None,
    ) -> None:
        self.data = data
        self.error = error
        self.count = count

    def __repr__(self) -> str:
        if self.error:
            return f"Result(error={self.error!r})"
        if isinstance(self.data, list):
            return f"Result(data=[...{len(self.data)} rows])"
        return f"Result(data={self.data!r})"


class QueryBuilder:
    """Chainable query builder. Created via ``Somewhere.from_('table')``.

    Usage::

        result = sw.from_('users').select('*').eq('role', 'admin').execute()
        result = sw.from_('users').insert({'name': 'Alice'}).execute()
        result = sw.from_('users').update({'role': 'admin'}).eq('id', 1).execute()
        result = sw.from_('users').delete().eq('id', 1).execute()
    """

    def __init__(
        self,
        table: str,
        project_id: str,
        http_client: httpx.Client,
        base_url: str,
        auth_header: str,
        extra_headers: Dict[str, str],
    ) -> None:
        self._table = table
        self._project_id = project_id
        self._http = http_client
        self._base_url = base_url
        self._auth_header = auth_header
        self._extra_headers = extra_headers

        self._action: str = "select"
        self._select_columns: str = "*"
        self._filters: List[Dict[str, Any]] = []
        self._order_clause: Optional[Dict[str, Any]] = None
        self._limit_value: Optional[int] = None
        self._offset_value: Optional[int] = None
        self._insert_rows: Optional[Union[Dict[str, Any], List[Dict[str, Any]]]] = None
        self._update_values: Optional[Dict[str, Any]] = None
        self._upsert_row: Optional[Dict[str, Any]] = None
        self._on_conflict: Optional[str] = None
        self._resolve: str = "many"  # 'many' | 'single' | 'maybeSingle'

    # ── Operation starters ──────────────────────────────────────────

    def select(self, columns: str = "*") -> QueryBuilder:
        self._action = "select"
        self._select_columns = columns
        return self

    def insert(self, data: Union[Dict[str, Any], List[Dict[str, Any]]]) -> QueryBuilder:
        self._action = "insert"
        self._insert_rows = data
        return self

    def update(self, data: Dict[str, Any]) -> QueryBuilder:
        self._action = "update"
        self._update_values = data
        return self

    def delete(self) -> QueryBuilder:
        self._action = "delete"
        return self

    def upsert(
        self,
        data: Union[Dict[str, Any], List[Dict[str, Any]]],
        *,
        on_conflict: Optional[str] = None,
    ) -> QueryBuilder:
        self._action = "upsert"
        self._upsert_row = data
        self._on_conflict = on_conflict or "id"
        return self

    # ── Filters ─────────────────────────────────────────────────────

    def eq(self, column: str, value: Any) -> QueryBuilder:
        self._filters.append({"column": column, "op": "eq", "value": value})
        return self

    def neq(self, column: str, value: Any) -> QueryBuilder:
        self._filters.append({"column": column, "op": "neq", "value": value})
        return self

    def gt(self, column: str, value: Any) -> QueryBuilder:
        self._filters.append({"column": column, "op": "gt", "value": value})
        return self

    def gte(self, column: str, value: Any) -> QueryBuilder:
        self._filters.append({"column": column, "op": "gte", "value": value})
        return self

    def lt(self, column: str, value: Any) -> QueryBuilder:
        self._filters.append({"column": column, "op": "lt", "value": value})
        return self

    def lte(self, column: str, value: Any) -> QueryBuilder:
        self._filters.append({"column": column, "op": "lte", "value": value})
        return self

    def like(self, column: str, pattern: str) -> QueryBuilder:
        self._filters.append({"column": column, "op": "like", "value": pattern})
        return self

    def ilike(self, column: str, pattern: str) -> QueryBuilder:
        self._filters.append({"column": column, "op": "ilike", "value": pattern})
        return self

    def in_(self, column: str, values: List[Any]) -> QueryBuilder:
        self._filters.append({"column": column, "op": "in", "value": values})
        return self

    def is_(self, column: str, value: Any) -> QueryBuilder:
        self._filters.append({"column": column, "op": "is", "value": value})
        return self

    def match(self, criteria: Dict[str, Any]) -> QueryBuilder:
        for k, v in criteria.items():
            self.eq(k, v)
        return self

    # ── Modifiers ───────────────────────────────────────────────────

    def order(
        self,
        column: str,
        *,
        ascending: Optional[bool] = None,
        desc: bool = False,
    ) -> QueryBuilder:
        """Order results. Pass ascending=False or desc=True for descending."""
        asc = True
        if ascending is not None:
            asc = ascending
        elif desc:
            asc = False
        self._order_clause = {"column": column, "ascending": asc}
        return self

    def limit(self, count: int) -> QueryBuilder:
        self._limit_value = count
        return self

    def offset(self, count: int) -> QueryBuilder:
        self._offset_value = count
        return self

    def range(self, start: int, end: int) -> QueryBuilder:
        self._offset_value = start
        self._limit_value = end - start + 1
        return self

    def single(self) -> QueryBuilder:
        """Expect exactly one row. Returns a dict instead of a list.
        Errors with PGRST116 if 0 or >1 rows."""
        self._resolve = "single"
        return self

    def maybe_single(self) -> QueryBuilder:
        """Expect 0 or 1 row. Returns dict or None."""
        self._resolve = "maybeSingle"
        return self

    # ── Execution ───────────────────────────────────────────────────

    def execute(self) -> Result:
        """Execute the query against the platform API."""
        payload = self._build_payload()
        try:
            response = self._http.post(
                f"{self._base_url}/db/query",
                json=payload,
                headers={
                    "Authorization": self._auth_header,
                    "Accept": "application/json",
                    "Content-Type": "application/json",
                    **self._extra_headers,
                },
            )
            return self._parse_response(response)
        except httpx.HTTPError as exc:
            return Result(error={"code": "NETWORK_ERROR", "message": str(exc)})

    def _build_payload(self) -> Dict[str, Any]:
        """Build the structured JSON the platform expects."""
        body: Dict[str, Any] = {
            "project_id": self._project_id,
            "table": self._table,
        }

        if self._action == "select":
            body["select"] = self._select_columns
        elif self._action == "insert":
            body["insert"] = self._insert_rows
        elif self._action == "update":
            body["update"] = self._update_values
        elif self._action == "delete":
            body["delete"] = True
        elif self._action == "upsert":
            body["upsert"] = self._upsert_row
            body["onConflict"] = self._on_conflict or "id"

        if self._filters:
            body["filters"] = self._filters

        if self._order_clause:
            body["order"] = self._order_clause

        if self._limit_value is not None:
            body["limit"] = self._limit_value

        if self._offset_value is not None:
            body["offset"] = self._offset_value

        return body

    def _parse_response(self, response: httpx.Response) -> Result:
        """Parse the API response into a Result."""
        try:
            body = response.json()
        except ValueError:
            return Result(error={
                "code": "INVALID_RESPONSE",
                "message": f"Non-JSON response (status {response.status_code})",
            })

        if not isinstance(body, dict) or body.get("ok") is not True:
            code = body.get("error", "UNKNOWN_ERROR") if isinstance(body, dict) else "UNKNOWN_ERROR"
            msg = body.get("message", "Unknown error") if isinstance(body, dict) else str(body)
            return Result(error={"code": code, "message": msg})

        # The API wraps in {ok: true, data: {data: [...rows], count, error}}
        outer = body.get("data", {})
        if not isinstance(outer, dict):
            # Fallback: data is the rows directly
            rows = outer if isinstance(outer, list) else []
            return self._shape_rows(rows)

        # Structured response: outer has {data: rows[], count, error}
        rows = outer.get("data", [])
        if not isinstance(rows, list):
            rows = [rows] if rows is not None else []

        return self._shape_rows(rows)

    def _shape_rows(self, rows: List[Dict[str, Any]]) -> Result:
        """Apply single/maybeSingle resolution."""
        if self._resolve == "single":
            if len(rows) == 0:
                return Result(error={
                    "code": "PGRST116",
                    "message": "Single-row query returned 0 rows.",
                })
            if len(rows) > 1:
                return Result(error={
                    "code": "PGRST116",
                    "message": f"Single-row query returned {len(rows)} rows.",
                })
            return Result(data=rows[0], count=1)

        if self._resolve == "maybeSingle":
            if len(rows) == 0:
                return Result(data=None, count=0)
            return Result(data=rows[0], count=1)

        return Result(data=rows, count=len(rows))
