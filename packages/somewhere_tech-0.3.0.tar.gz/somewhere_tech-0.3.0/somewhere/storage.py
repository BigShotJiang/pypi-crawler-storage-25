"""Storage client for the somewhere.tech platform -- Supabase-compatible interface.

Provides a bucket-based API: sw.storage.from_('bucket').upload/download/list/remove.
"""
from __future__ import annotations

from typing import Any, Dict, List, Optional, Union
from urllib.parse import quote

import httpx

from .query_builder import Result


class StorageFileApi:
    """Operations on a specific storage bucket.

    Created via StorageClient.from_('bucket_name'). Not instantiated directly.

    Usage:
        result = sw.storage.from_('avatars').upload('photo.png', data, content_type='image/png')
        result = sw.storage.from_('avatars').download('photo.png')
        result = sw.storage.from_('avatars').list('folder/')
        result = sw.storage.from_('avatars').remove(['photo.png'])
    """

    def __init__(
        self,
        bucket: str,
        project_id: str,
        http_client: httpx.Client,
        base_url: str,
        auth_header: str,
        extra_headers: Dict[str, str],
    ) -> None:
        self._bucket = bucket
        self._project_id = project_id
        self._http = http_client
        self._base_url = base_url
        self._auth_header = auth_header
        self._extra_headers = extra_headers

    def upload(
        self,
        path: str,
        data: Union[bytes, bytearray],
        *,
        content_type: str = "application/octet-stream",
    ) -> Result:
        """Upload a file to the bucket.

        Args:
            path: File path within the bucket (e.g. 'photo.png' or 'folder/photo.png').
            data: Raw file bytes.
            content_type: MIME type of the file.
        """
        encoded_path = self._encode_path(path)
        url = f"{self._base_url}/fs/{quote(self._project_id)}/{quote(self._bucket)}/{encoded_path}"
        headers = {
            "Authorization": self._auth_header,
            "Content-Type": content_type,
            "Accept": "application/json",
            **self._extra_headers,
        }
        try:
            response = self._http.put(url, content=bytes(data), headers=headers)
            return self._parse(response)
        except httpx.HTTPError as exc:
            return Result(error={"code": "NETWORK_ERROR", "message": str(exc)})

    def download(self, path: str) -> Result:
        """Download a file from the bucket.

        Returns Result with data containing a single dict:
            {'content': bytes, 'content_type': str}
        """
        encoded_path = self._encode_path(path)
        url = f"{self._base_url}/fs/{quote(self._project_id)}/{quote(self._bucket)}/{encoded_path}"
        headers = {
            "Authorization": self._auth_header,
            **self._extra_headers,
        }
        try:
            response = self._http.get(url, headers=headers)
            if response.status_code >= 400:
                return self._parse_error(response)
            ct = response.headers.get("content-type", "application/octet-stream")
            return Result(
                data=[{"content": response.content, "content_type": ct}],
                count=1,
            )
        except httpx.HTTPError as exc:
            return Result(error={"code": "NETWORK_ERROR", "message": str(exc)})

    def list(self, prefix: str = "", *, cursor: Optional[str] = None) -> Result:
        """List files in the bucket, optionally filtered by prefix.

        Routes to GET /v1/fs/{pid}/{bucket}/{prefix} which returns a
        directory listing when the path is a directory.
        """
        dir_path = f"{self._bucket}/{prefix}" if prefix else self._bucket
        encoded = self._encode_path(dir_path)
        url = f"{self._base_url}/fs/{quote(self._project_id)}/{encoded}"
        headers = {
            "Authorization": self._auth_header,
            "Accept": "application/json",
            **self._extra_headers,
        }
        try:
            response = self._http.get(url, headers=headers)
            body = response.json()
            data = body.get("data", body) if isinstance(body, dict) else body
            if isinstance(data, dict) and data.get("ok") is True:
                data = data.get("data", data)
            if isinstance(data, dict) and data.get("type") == "directory":
                entries = [
                    {"name": e.get("name"), "size": e.get("size_bytes", 0),
                     "content_type": e.get("content_type"),
                     "updated_at": e.get("updated_at")}
                    for e in data.get("entries", [])
                ]
                return Result(data=entries, count=len(entries))
            return Result(data=[], count=0)
        except (httpx.HTTPError, ValueError) as exc:
            return Result(error={"code": "NETWORK_ERROR", "message": str(exc)})

    def remove(self, paths: List[str]) -> Result:
        """Remove one or more files from the bucket.

        Args:
            paths: List of file paths within the bucket to delete.
        """
        results: List[Dict[str, Any]] = []
        last_error: Optional[Dict[str, Any]] = None

        for path in paths:
            encoded_path = self._encode_path(path)
            url = f"{self._base_url}/fs/{quote(self._project_id)}/{quote(self._bucket)}/{encoded_path}"
            headers = {
                "Authorization": self._auth_header,
                "Accept": "application/json",
                **self._extra_headers,
            }
            try:
                response = self._http.delete(url, headers=headers)
                parsed = self._parse(response)
                if parsed.error:
                    last_error = parsed.error
                else:
                    results.append({"path": path, "deleted": True})
            except httpx.HTTPError as exc:
                last_error = {"code": "NETWORK_ERROR", "message": str(exc)}

        if last_error and not results:
            return Result(error=last_error)
        return Result(data=results, count=len(results))

    def get_public_url(self, path: str) -> str:
        """Get the public URL for a file (does not verify existence)."""
        encoded_path = self._encode_path(path)
        return f"{self._base_url}/fs/{quote(self._project_id)}/{quote(self._bucket)}/{encoded_path}"

    @staticmethod
    def _encode_path(path: str) -> str:
        """URL-encode each segment of a path."""
        return "/".join(quote(segment, safe="") for segment in path.split("/"))

    @staticmethod
    def _parse(response: httpx.Response) -> Result:
        try:
            body = response.json()
        except ValueError:
            return Result(error={
                "code": "INVALID_RESPONSE",
                "message": f"Non-JSON response (status {response.status_code})",
            })

        if isinstance(body, dict) and body.get("ok") is True:
            data = body.get("data")
            if isinstance(data, list):
                return Result(data=data, count=len(data))
            if isinstance(data, dict):
                return Result(data=[data], count=1)
            return Result(data=[data] if data is not None else [], count=1 if data else 0)

        error_code = body.get("error", "UNKNOWN_ERROR") if isinstance(body, dict) else "UNKNOWN_ERROR"
        error_message = body.get("message", "Unknown error") if isinstance(body, dict) else str(body)
        return Result(error={"code": error_code, "message": error_message})

    @staticmethod
    def _parse_error(response: httpx.Response) -> Result:
        try:
            body = response.json()
            error_code = body.get("error", "UNKNOWN_ERROR") if isinstance(body, dict) else "UNKNOWN_ERROR"
            error_message = body.get("message", "Unknown error") if isinstance(body, dict) else str(body)
        except ValueError:
            error_code = "HTTP_ERROR"
            error_message = f"HTTP {response.status_code}"
        return Result(error={"code": error_code, "message": error_message})


class StorageClient:
    """Top-level storage client. Access via sw.storage.

    Usage:
        bucket = sw.storage.from_('avatars')
        result = bucket.upload('photo.png', file_bytes)
    """

    def __init__(
        self,
        project_id: str,
        http_client: httpx.Client,
        base_url: str,
        auth_header: str,
        extra_headers: Dict[str, str],
    ) -> None:
        self._project_id = project_id
        self._http = http_client
        self._base_url = base_url
        self._auth_header = auth_header
        self._extra_headers = extra_headers

    def from_(self, bucket: str) -> StorageFileApi:
        """Get a StorageFileApi for the given bucket name."""
        return StorageFileApi(
            bucket=bucket,
            project_id=self._project_id,
            http_client=self._http,
            base_url=self._base_url,
            auth_header=self._auth_header,
            extra_headers=self._extra_headers,
        )
