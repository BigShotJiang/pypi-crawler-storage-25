# Simple — video downloader server

The local Python server that backs the **Simple** Firefox extension.

## Install

```
pip install -U --pre simple-video-downloader-server
```

That pulls in `yt-dlp`, `curl-cffi` and `mutagen` automatically. You'll also need:

- **FFmpeg** — daily builds at https://github.com/yt-dlp/FFmpeg-Builds/releases/latest
- **MKVToolNix** — https://mkvtoolnix.download/downloads.html

## Run

```
simple-server
```

The server listens on `localhost:16868`. Install the [Simple Firefox extension](https://addons.mozilla.org/en-GB/firefox/) and it'll find the server automatically.

Files download to `~/Downloads/Simple downloads` by default. Override with the `SIMPLE_DOWNLOAD_FOLDER` environment variable, or change it from the extension's Settings tab.

## Auto-start

### Linux (systemd)

```
mkdir -p ~/.config/systemd/user
cat > ~/.config/systemd/user/simple-server.service <<'UNIT'
[Unit]
Description=Simple video downloader server
After=network-online.target
Wants=network-online.target

[Service]
Type=simple
ExecStart=%h/.local/bin/simple-server
Restart=on-failure
RestartSec=5

[Install]
WantedBy=default.target
UNIT
systemctl --user daemon-reload
systemctl --user enable --now simple-server.service
```

### macOS / Windows

See https://github.com/no-faff/Simple-video-downloader for current instructions.

## Update

```
pip install -U --pre simple-video-downloader-server
```

The extension will warn you when there's an update worth pulling.
