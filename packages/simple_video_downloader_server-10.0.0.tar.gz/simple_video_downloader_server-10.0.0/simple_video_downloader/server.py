# -*- coding: utf-8 -*-

# Section 1: Initial setup, imports and logging configuration

print("⚡ Starting 🚀Simple server ...")

# Essential libraries for core functionality
import yt_dlp            # YouTube-DL fork for video downloading with extended features
import curl_cffi          # Browser fingerprint impersonation for avoiding CAPTCHAs and bot detection
import subprocess        # For executing external commands (mkvmerge, etc.)
import re                # Regular expressions for pattern matching
import sys               # System-specific parameters and functions
from http.server import BaseHTTPRequestHandler, HTTPServer  # Basic HTTP server implementation
import urllib.parse      # Tools for URL parsing and manipulation
import time              # Time-related functions for timing and delays
import logging           # Logging infrastructure
import json              # JSON parsing and generation
import os                # Operating system interfaces
import unicodedata       # Unicode character database for normalisation
import difflib           # Sequence comparison tools
import shutil            # High-level file operations
import tempfile          # Temporary file creation
import socket            # Low-level networking interface
import datetime          # Date and time manipulation
import traceback         # Stack trace handling for error reporting
from pathlib import Path  # Object-oriented filesystem paths
from mutagen.id3 import ID3, USLT  # MP3 tag manipulation for embedding lyrics
import random            # For randomised delays
import platform          # For detecting OS to customise user agent
import threading         # For async download processing
import uuid              # For unique download IDs
import copy              # For deep copying state dicts

# Configure logging with timestamp format
logging.basicConfig(level=logging.INFO, format="%(message)s %(asctime)s")

class CustomLogFilter(logging.Filter):
    """
    Custom filter to suppress verbose and repetitive log messages.

    This filter checks log messages against a list of regular expression patterns
    and filters out any that match, keeping the console output clean and focused
    on important status updates.
    """
    def filter(self, record):
        # Comprehensive list of patterns to ignore in logs
        ignored_patterns = [
            r"Downloading video thumbnail",
            r"Video Thumbnail",
            r"Fetching SponsorBlock segments",
            r"No matching segments were found in the SponsorBlock database",
            r"Extracting cookies from",
            r"Extracted \d+ cookies",
            r"Writing video subtitles",
            r"Converting subtitles",
            r"Converting thumbnail",
            r"Deleting original file",
            r"Merging formats",
            r"Embedding subtitles",
            r"Adding metadata",
            r"\[SponsorBlock\]",
            r"Finished downloading playlist",
            r"\[youtube\]",
            r"\[info\]",
            r"\[SubtitlesConvertor\]",
            r"\[VideoRemuxer\]",
            r"\[EmbedSubtitle\]",
            r"\[EmbedThumbnail\]",
            r"cookies",
            r"^$",
            r"\[download\] \d+\.\d+KiB at",
            r"\[youtube\] Extracting URL",
            r"\[youtube\] .*: Downloading",
            r"SponsorBlock] Found \d+ segments",
            r"\[youtube:tab\] Incomplete data received",
        ]

        # Check if the log message matches any of the patterns to be ignored
        log_message = record.getMessage()
        return not any(re.search(pattern, log_message) for pattern in ignored_patterns)

# Setup logging with custom filter
logger = logging.getLogger()
logger.setLevel(logging.INFO)
logger.addFilter(CustomLogFilter())

# Error Handling Strategy:
# 1. Server-level errors (handle_connection_error function) - handles errors in the server's main loop
# 2. Handler-level errors (BatchRequestHandler.handle_error method) - handles errors during HTTP request processing
# This dual-layer approach ensures ConnectionAbortedError is gracefully handled regardless of where it occurs
def handle_connection_error(request, client_address):
    """
    Custom error handler for server-level connection errors.

    This function provides a clean error message when a connection is aborted at the server level,
    preventing verbose stack traces from appearing in the console output.

    Args:
        request: The client request object
        client_address: A tuple containing the client's address information
    """
    error_type, error_value, _ = sys.exc_info()
    if isinstance(error_value, ConnectionAbortedError):
        print("\n❌ Connection lost")
        print("─────────────────")
        print("😎 Ready")
    else:
        # Let the original handler process other types of errors
        traceback.print_exc()

# History is the only thing we persist to disk; user settings live in the
# extension and are pushed to us per-request (or via /set-folder once on load).
# Stored under the user's data dir so the pip-installed `simple-server` doesn't
# litter the current working directory. XDG on Linux, ~/Library on macOS, and
# %LOCALAPPDATA% on Windows; ~/.simple-video-downloader/ as a sensible fallback.
def _user_data_dir():
    system = platform.system()
    if system == "Windows":
        base = os.environ.get("LOCALAPPDATA") or str(Path.home() / "AppData" / "Local")
    elif system == "Darwin":
        base = str(Path.home() / "Library" / "Application Support")
    else:
        base = os.environ.get("XDG_DATA_HOME") or str(Path.home() / ".local" / "share")
    p = Path(base) / "simple-video-downloader"
    p.mkdir(parents=True, exist_ok=True)
    return p

HISTORY_FILE = str(_user_data_dir() / "history.json")
HISTORY_MAX_ENTRIES = 500

# Section 2: Port management and settings

# Check if port is available
def is_port_available(port):
    """
    Check if a specific network port is available for use.

    Attempts to bind to the specified port to determine if it's free.

    Args:
        port (int): The port number to check

    Returns:
        bool: True if the port is available, False otherwise
    """
    try:
        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
            # SO_REUSEADDR so a recent shutdown's TIME_WAIT doesn't make the
            # port appear busy. Without this, restarting the service can shove
            # us up to 16874+, which the extension's scan range doesn't cover.
            s.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
            s.bind(("", port))
            return True
    except OSError:
        return False

# Find an available port
def find_available_port(start_port=16868, max_attempts=10):
    """
    Find an available port starting from a specified port number.

    Tries incrementing port numbers until finding an available one,
    falling back to a random high port if necessary.

    Args:
        start_port (int): The initial port to check (default: 16868)
        max_attempts (int): Maximum number of consecutive ports to try (default: 10)

    Returns:
        int: An available port number
    """
    port = start_port
    attempts = 0

    while attempts < max_attempts:
        if is_port_available(port):
            return port
        port += 1
        attempts += 1

    # If we've tried too many ports, fall back to a random high port
    return find_random_high_port()

def find_random_high_port():
    """
    Find a random available high-numbered port.

    Uses the system's port allocation mechanism to find a free port
    in the ephemeral port range.

    Returns:
        int: An available port number in the high range
    """
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
        s.bind(("", 0))
        return s.getsockname()[1]

# Load settings
# --- Server defaults ------------------------------------------------------
# Settings used to live in Simple_settings.json. The extension now stores user
# prefs client-side (browser.storage) and pushes them per-request, so the
# server only needs sensible in-memory defaults. The download folder is the
# one piece of state that has to be known server-side at download time; the
# extension calls /set-folder on load to push its stored value.
DEFAULT_PORT = 16868
DEFAULT_RESOLUTION = "1080"
DEFAULT_USE_MP4 = False
DEFAULT_USE_COOKIES = True
DEFAULT_FILENAME_TEMPLATE = "%(title)s-%(extractor)s-%(id)s"

# Folder default: env var lets advanced users override at startup (e.g. in a
# systemd unit), otherwise ~/Downloads/Simple downloads.
_env_folder = os.environ.get("SIMPLE_DOWNLOAD_FOLDER", "").strip()
if _env_folder and os.path.isabs(_env_folder):
    DEFAULT_DOWNLOAD_FOLDER = Path(_env_folder).resolve()
else:
    DEFAULT_DOWNLOAD_FOLDER = (Path.home() / "Downloads" / "Simple downloads").resolve()

# In-memory mirror of "current settings" used by code paths that expect a dict.
# Nothing here is persisted to disk; the extension is the source of truth.
settings = {
    "folder": str(DEFAULT_DOWNLOAD_FOLDER),
    "port": DEFAULT_PORT,
    "resolution": DEFAULT_RESOLUTION,
    "use_mp4": DEFAULT_USE_MP4,
    "use_cookies": DEFAULT_USE_COOKIES,
    "filename_template": DEFAULT_FILENAME_TEMPLATE,
}

def save_settings(settings_arg, print_message=True):
    """No-op — kept so legacy call sites still work. Settings live in memory only."""
    return

MAX_RESOLUTION = DEFAULT_RESOLUTION
USE_MP4 = DEFAULT_USE_MP4
USE_BROWSER_COOKIES = DEFAULT_USE_COOKIES
FILENAME_TEMPLATE = settings.get("filename_template", "%(title)s-%(id)s")

# Ensure the folder exists
DEFAULT_DOWNLOAD_FOLDER.mkdir(parents=True, exist_ok=True)

# Get a realistic user agent based on the operating system
def get_system_user_agent():
    """
    Returns a realistic user agent string based on the user's operating system.

    This helps make requests appear more like normal browser traffic.

    Returns:
        str: A user agent string appropriate for the system
    """
    system = platform.system()
    if system == "Windows":
        return "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:135.0) Gecko/20100101 Firefox/135.0"
    elif system == "Darwin":  # macOS
        return "Mozilla/5.0 (Macintosh; Intel Mac OS X 10.15; rv:135.0) Gecko/20100101 Firefox/135.0"
    else:  # Linux and others
        return "Mozilla/5.0 (X11; Linux x86_64; rv:135.0) Gecko/20100101 Firefox/135.0"

# System user agent to be used in requests
SYSTEM_USER_AGENT = get_system_user_agent()

# Section 2.5: Async download state and queue management

download_queue = []  # list of queued download dicts
download_lock = threading.Lock()
settings_lock = threading.Lock()  # protects global settings variables
cancel_event = threading.Event()  # signalled to cancel the active download
worker_thread = None  # reference to the background worker thread

download_state = {
    "active": False,
    "id": None,
    "url": "",
    "title": "",
    "progress": 0.0,
    "phase": "idle",  # idle/resolving/downloading_video/downloading_audio/processing/complete/error
    "speed": "",
    "eta": "",
    "error_message": "",
    "file_name": "",
    "file_size": 0,
}

def reset_download_state():
    """Reset the global download state to idle defaults."""
    download_state["active"] = False
    download_state["id"] = None
    download_state["url"] = ""
    download_state["title"] = ""
    download_state["progress"] = 0.0
    download_state["phase"] = "idle"
    download_state["speed"] = ""
    download_state["eta"] = ""
    download_state["error_message"] = ""
    download_state["file_name"] = ""
    download_state["file_size"] = 0

def get_download_state_snapshot():
    """Return a thread-safe copy of the current download state."""
    with download_lock:
        return copy.deepcopy(download_state)

# Download history management
def load_history():
    """
    Load download history from the history file.

    Returns:
        list: List of history entry dicts
    """
    if os.path.exists(HISTORY_FILE):
        try:
            with open(HISTORY_FILE, "r") as f:
                data = json.load(f)
                if isinstance(data, list):
                    return data
        except (json.JSONDecodeError, IOError):
            pass
    return []

def save_history(history):
    """
    Save download history to the history file.
    Caps at HISTORY_MAX_ENTRIES.

    Args:
        history (list): List of history entry dicts
    """
    # Keep only the most recent entries
    history = history[-HISTORY_MAX_ENTRIES:]
    try:
        with open(HISTORY_FILE, "w") as f:
            json.dump(history, f, indent=2)
    except Exception as e:
        logging.error(f"❌ Error saving history: {e}")

def add_history_entry(entry):
    """
    Add a single entry to download history.

    Args:
        entry (dict): History entry with id, url, filename, fileSize, completedAt, audioOnly, format, resolution
    """
    history = load_history()
    history.append(entry)
    save_history(history)

# Install dependency commands per platform
INSTALL_COMMANDS = {
    "windows": {
        "python": ["winget", "install", "Python.Python.3.12"],
        "ffmpeg": ["winget", "install", "Gyan.FFmpeg"],
        "mkvtoolnix": ["winget", "install", "MoritzBunkus.MKVToolNix"],
        "ytdlp": ["py", "-m", "pip", "install", "-U", "--pre", "yt-dlp[default,curl-cffi]"],
    },
    "darwin": {
        "python": ["brew", "install", "python"],
        "ffmpeg": ["brew", "install", "ffmpeg"],
        "mkvtoolnix": ["brew", "install", "mkvtoolnix"],
        "ytdlp": ["python3", "-m", "pip", "install", "-U", "--pre", "yt-dlp[default,curl-cffi]"],
    },
    "linux": {
        "ffmpeg": None,  # resolved at runtime by get_linux_install_cmd()
        "mkvtoolnix": None,
        "ytdlp": ["python3", "-m", "pip", "install", "-U", "--pre", "yt-dlp[default,curl-cffi]"],
    }
}

def get_linux_package_manager():
    """Detect the system package manager."""
    if shutil.which("dnf"):
        return "dnf"
    elif shutil.which("apt"):
        return "apt"
    elif shutil.which("pacman"):
        return "pacman"
    elif shutil.which("zypper"):
        return "zypper"
    return None

def get_linux_install_cmd(package):
    """Build an install command for the detected Linux package manager."""
    pm = get_linux_package_manager()
    if pm == "dnf":
        return ["sudo", "dnf", "install", "-y", package]
    elif pm == "apt":
        return ["sudo", "apt", "install", "-y", package]
    elif pm == "pacman":
        return ["sudo", "pacman", "-S", "--noconfirm", package]
    elif pm == "zypper":
        return ["sudo", "zypper", "install", "-y", package]
    return None

_pypi_cache = {}  # {package: (latest_version, fetched_at)}

def _parse_version_tuple(v):
    """Parse a yt-dlp-style version string into a comparable tuple of ints."""
    if not v:
        return ()
    v = re.sub(r"\.dev\d*$", "", v)  # Strip .dev suffix; nightlies sort same as stable.
    parts = []
    for p in v.split("."):
        try:
            parts.append(int(p))
        except ValueError:
            parts.append(0)
    return tuple(parts)

def get_pypi_latest(package, cache_seconds=3600, timeout=3):
    """Look up the latest version of a package on PyPI (incl. pre-releases). Cached."""
    import urllib.request
    cached = _pypi_cache.get(package)
    if cached and (time.time() - cached[1]) < cache_seconds:
        return cached[0]
    try:
        url = f"https://pypi.org/pypi/{package}/json"
        req = urllib.request.Request(url, headers={"User-Agent": "simple-video-downloader"})
        with urllib.request.urlopen(req, timeout=timeout) as resp:
            data = json.loads(resp.read())
        versions = list(data.get("releases", {}).keys())
        if not versions:
            return None
        latest = max(versions, key=_parse_version_tuple)
        _pypi_cache[package] = (latest, time.time())
        return latest
    except Exception as e:
        logging.debug(f"PyPI lookup failed for {package}: {e}")
        return None

def get_install_command_info(dep_name):
    """
    Return the install command string and whether it must be run manually.

    Manual = the server cannot run it non-interactively (e.g. Linux sudo needs
    a password prompt that the HTTP server has no way to satisfy). The client
    should display the command for the user to run themselves rather than
    offering a button that will silently fail.

    Returns:
        tuple: (command_string or None, manual: bool)
    """
    plat_key = get_platform_key()
    cmd = INSTALL_COMMANDS.get(plat_key, {}).get(dep_name)
    if cmd is None and plat_key == "linux":
        cmd = get_linux_install_cmd(dep_name)
    if cmd is None:
        return (None, False)
    manual = bool(cmd) and cmd[0] == "sudo"
    return (" ".join(cmd), manual)

def get_platform_key():
    """
    Get the platform key for INSTALL_COMMANDS.

    Returns:
        str: 'windows', 'darwin', or 'linux'
    """
    system = platform.system().lower()
    if system == "windows":
        return "windows"
    elif system == "darwin":
        return "darwin"
    else:
        return "linux"

# Section 3: URL and file processing utilities

def clean_video_url(url):
    """
    Remove playlist parameters from YouTube video URLs.

    For YouTube videos that are part of a playlist, this extracts just
    the video ID and creates a clean URL without playlist parameters,
    ensuring only the specific video is downloaded.

    Args:
        url (str): The YouTube URL, potentially with playlist parameters

    Returns:
        str: A clean URL with only the video ID
    """
    if "youtube.com/watch" in url and "&list=" in url:
        # Extract the video ID
        video_id_match = re.search(r'v=([^&]+)', url)
        if video_id_match:
            video_id = video_id_match.group(1)
            # Return clean URL with just the video ID
            return f"https://www.youtube.com/watch?v={video_id}"
    return url

# Temporary directory management functions
def get_temp_processing_dir():
    """
    Create and return a persistent temporary directory for processing downloads.

    Creates a platform-specific temporary directory for intermediate files
    during download processing. On Windows, uses LocalAppData, and on other
    platforms, uses the home directory's cache folder.

    Returns:
        Path: Path object pointing to the temporary processing directory
    """
    if sys.platform == "win32":
        base_dir = Path(os.getenv('LOCALAPPDATA')) / "SimpleDownloader" / "temp"
    else:
        base_dir = Path.home() / ".cache" / "SimpleDownloader" / "temp"

    base_dir.mkdir(parents=True, exist_ok=True)
    return base_dir

def cleanup_temp_dir(temp_dir):
    """
    Remove all files in the temporary directory.

    Cleans up the temporary processing directory by removing all files
    and recreating the empty directory.

    Args:
        temp_dir (Path): The temporary directory to clean
    """
    try:
        shutil.rmtree(temp_dir)
        temp_dir.mkdir(parents=True, exist_ok=True)
        logging.debug("✨ Cleaned up temporary files")
    except Exception as e:
        logging.error(f"❌ Error cleaning temporary directory: {e}")

# Folder management functions
def load_folder():
    """
    Return the current download folder path.

    Returns:
        Path: Path object pointing to the current download folder
    """
    return DEFAULT_DOWNLOAD_FOLDER

# Folder is in-memory only now; this helper updates the globals after the
# /set-folder endpoint receives a new path.
def _apply_new_folder(folder_path):
    global DEFAULT_DOWNLOAD_FOLDER
    DEFAULT_DOWNLOAD_FOLDER = Path(folder_path)
    settings["folder"] = str(folder_path)
    print(f"📂 Download folder set to: {folder_path}")

# Set max resolution
def set_resolution(resolution):
    """
    Set the maximum video resolution.

    Updates the settings with the new resolution limit.

    Args:
        resolution (str): Resolution setting - "480", "720", "1080", or "best"
    """
    valid_resolutions = ["480", "720", "1080", "best"]
    if resolution not in valid_resolutions:
        resolution = "1080"  # Default fallback

    with settings_lock:
        try:
            settings["resolution"] = resolution
            save_settings(settings, print_message=False)
            res_label = "Best available" if resolution == "best" else f"{resolution}p"
            print(f"📽️ Max resolution set to: {res_label}\n")

            global MAX_RESOLUTION
            MAX_RESOLUTION = resolution
        except Exception as e:
            print(f"❌ ERROR: Could not save resolution setting: {e}")

# Set use cookies
def set_use_cookies(use_cookies):
    """
    Set whether to use browser cookies for authentication.

    Args:
        use_cookies (bool): Whether to use browser cookies
    """
    with settings_lock:
        try:
            settings["use_cookies"] = bool(use_cookies)
            save_settings(settings, print_message=False)
            print(f"🍪 Use browser cookies set to: {'✅ Yes' if use_cookies else '❌ No'}\n")

            global USE_BROWSER_COOKIES
            USE_BROWSER_COOKIES = bool(use_cookies)
        except Exception as e:
            print(f"❌ ERROR: Could not save cookies setting: {e}")

def check_dependency(dependency_name):
    """
    Check if a dependency is installed and get its version.

    Uses subprocess to run version check commands for various
    dependencies and parses the output to determine installation
    status and version information.

    Args:
        dependency_name (str): Name of the dependency to check
            (python, ffmpeg, mkvtoolnix, ytdlp)

    Returns:
        dict: Dictionary with 'installed' status and 'version' if available
    """
    # Python is always installed if this server is running
    if dependency_name == "python":
        version = f"{sys.version_info.major}.{sys.version_info.minor}.{sys.version_info.micro}"
        return {"installed": True, "version": version, "install_command": None, "manual_install": False}

    commands = {
        "ffmpeg": ["ffmpeg", "-version"],
        "mkvtoolnix": ["mkvpropedit", "--version"],
        "ytdlp": ["yt-dlp", "--version"]
    }

    version_patterns = {
        "ffmpeg": r"ffmpeg version ([^ ]+)",
        "mkvtoolnix": r"mkvpropedit v(\d+\.\d+)",
        "ytdlp": r"(\d{4}\.\d{2}\.\d{2}(?:\.\d+)?)"
    }

    install_cmd, manual = get_install_command_info(dependency_name)

    if dependency_name not in commands:
        return {"installed": False, "version": None, "error": "Unknown dependency",
                "install_command": install_cmd, "manual_install": manual}

    try:
        cmd = commands[dependency_name]
        result = subprocess.run(
            cmd,
            text=True,
            capture_output=True,
            timeout=10
        )

        if result.returncode != 0:
            return {"installed": False, "version": None, "error": "Dependency not found",
                    "install_command": install_cmd, "manual_install": manual}

        # Extract version using regex if available
        version_str = None
        if dependency_name in version_patterns:
            output = result.stdout or result.stderr  # Some programs output version to stderr
            match = re.search(version_patterns[dependency_name], output)
            if match:
                version_str = match.group(1)

        if version_str is None:
            version_str = "Unknown"

        # For yt-dlp, also report whether a newer version is on PyPI.
        update_available = None
        latest_version = None
        if dependency_name == "ytdlp" and version_str != "Unknown":
            latest_version = get_pypi_latest("yt-dlp")
            if latest_version:
                update_available = _parse_version_tuple(version_str) < _parse_version_tuple(latest_version)

        return {"installed": True, "version": version_str,
                "install_command": install_cmd, "manual_install": manual,
                "latest_version": latest_version, "update_available": update_available}

    except (subprocess.SubprocessError, FileNotFoundError):
        return {"installed": False, "version": None, "error": "Dependency not found",
                "install_command": install_cmd, "manual_install": manual}
    except Exception as e:
        return {"installed": False, "version": None, "error": str(e),
                "install_command": install_cmd, "manual_install": manual}

# Toggle use MP4 instead of MKV
def set_use_mp4(use_mp4):
    """
    Set whether to use MP4 instead of MKV for video downloads.

    Updates the settings to toggle the video container format.

    Args:
        use_mp4 (bool): Whether to use MP4 instead of MKV
    """
    with settings_lock:
        try:
            settings["use_mp4"] = bool(use_mp4)
            save_settings(settings, print_message=False)
            print(f"📼 Use MP4 instead of MKV set to: {'✅ Yes' if use_mp4 else '❌ No'}\n")

            global USE_MP4
            USE_MP4 = bool(use_mp4)
        except Exception as e:
            print(f"❌ ERROR: Could not save video format setting: {e}")

def set_filename_template(template):
    """
    Set the filename template for downloads.

    The template uses yt-dlp output template fields (without extension).
    Must contain at least %(title)s or %(id)s.

    Args:
        template (str): The filename template string
    """
    if "%(title)s" not in template and "%(id)s" not in template:
        print(f"❌ Invalid template: must contain %(title)s or %(id)s")
        return False
    with settings_lock:
        try:
            settings["filename_template"] = template
            save_settings(settings, print_message=False)
            print(f"📝 Filename template set to: {template}\n")

            global FILENAME_TEMPLATE
            FILENAME_TEMPLATE = template
            return True
        except Exception as e:
            print(f"❌ ERROR: Could not save filename template: {e}")
            return False

# Filename and subtitle handling functions
def normalise_filename(name):
    """
    Remove problematic characters and normalise special symbols in filenames.

    Applies Unicode normalisation to convert special characters to their
    canonical form and converts to lowercase for case-insensitive comparisons.

    Args:
        name (str): The filename to normalise

    Returns:
        str: Normalised filename
    """
    return unicodedata.normalize('NFKC', name).lower()

# Section 4: Subtitle and lyrics processing

def convert_srt_timestamp(srt_time):
    """
    Convert SRT timestamp (00:00:00,000) to LRC format [mm:ss.xx].

    Transforms subtitle timestamps from SRT format to LRC format for
    lyrics embedding in MP3 files.

    Args:
        srt_time (str): Timestamp in SRT format (HH:MM:SS,mmm)

    Returns:
        str: Timestamp in LRC format [mm:ss.xx] or None if parsing fails
    """
    pattern = r'(\d{2}):(\d{2}):(\d{2}),(\d{3})'
    match = re.match(pattern, srt_time)
    if not match:
        return None

    h, m, s, ms = map(int, match.groups())
    total_minutes = h * 60 + m
    return f"[{total_minutes:02d}:{s:02d}.{ms//10:02d}]"

def fix_TED_lyrics_before_embedding_in_mp3(srt_file):
    """
    Fix formatting of first subtitle block in TED audio transcripts.

    TED subtitles often have a malformed first subtitle block that needs
    special handling. This function also adds a 3585ms offset to all
    timestamps to adjust for audio delay.

    Args:
        srt_file (str): Path to the SRT subtitle file

    Returns:
        bool: True if successful, False otherwise
    """
    try:
        with open(srt_file, 'r', encoding='utf-8') as f:
            content = f.read()

        # Pattern focusing on the dual timestamp structure
        pattern = r'1\n00:00:00,000 --> 00:00:00,001\n\s*\n(\d{2}:\d{2}:\d{2})\.(\d{3}) -- (\d{2}:\d{2}:\d{2})\.(\d{3})\n(.*?)\n(?=\d+\n\d{2}:\d{2}:\d{2},)'

        # Replace with correctly formatted subtitle block
        replacement = r'1\n\1,\2 --> \3,\4\n\5\n'

        # Fix the malformed first subtitle
        content = re.sub(pattern, replacement, content, count=1, flags=re.DOTALL)

        # Add 3585ms to all timestamps
        def add_offset(match):
            start, end = match.groups()
            start_parts = start.split(',')
            end_parts = end.split(',')

            # Add offset to start time
            h, m, s = map(int, start_parts[0].split(':'))
            ms = int(start_parts[1]) + 3585
            s += ms // 1000
            ms = ms % 1000
            m += s // 60
            s = s % 60
            h += m // 60
            m = m % 60
            new_start = f"{h:02d}:{m:02d}:{s:02d},{ms:03d}"

            # Add offset to end time
            h, m, s = map(int, end_parts[0].split(':'))
            ms = int(end_parts[1]) + 3585
            s += ms // 1000
            ms = ms % 1000
            m += s // 60
            s = s % 60
            h += m // 60
            m = m % 60
            new_end = f"{h:02d}:{m:02d}:{s:02d},{ms:03d}"

            return f"{new_start} --> {new_end}"

        # Apply the offset to all timestamps
        content = re.sub(r'(\d{2}:\d{2}:\d{2},\d{3}) --> (\d{2}:\d{2}:\d{2},\d{3})', add_offset, content)

        with open(srt_file, 'w', encoding='utf-8') as f:
            f.write(content)

        return True
    except Exception as e:
        logging.error(f"❌ Error fixing TED subtitle format: {e}")
        return False

def fix_TED_lyrics_and_embed_in_mkv(mkv_file, srt_file):
    """
    Fix formatting of first subtitle block and embed in MKV file.

    Similar to fix_TED_lyrics_before_embedding_in_mp3, but embeds the
    fixed subtitles into an MKV video file using mkvmerge external tool.

    Args:
        mkv_file (str): Path to the MKV video file
        srt_file (str): Path to the SRT subtitle file

    Returns:
        bool: True if successful, False otherwise
    """
    try:
        # First modify the SRT file
        with open(srt_file, 'r', encoding='utf-8') as f:
            content = f.read()

        # Pattern focusing on the dual timestamp structure
        pattern = r'1\n00:00:00,000 --> 00:00:00,001\n\s*\n(\d{2}:\d{2}:\d{2})\.(\d{3}) -- (\d{2}:\d{2}:\d{2})\.(\d{3})\n(.*?)\n(?=\d+\n\d{2}:\d{2}:\d{2},)'

        # Replace with correctly formatted subtitle block
        replacement = r'1\n\1,\2 --> \3,\4\n\5\n'

        # Fix the malformed first subtitle
        content = re.sub(pattern, replacement, content, count=1, flags=re.DOTALL)

        # Add 3585ms to all timestamps
        def add_offset(match):
            start, end = match.groups()
            start_parts = start.split(',')
            end_parts = end.split(',')

            # Add offset to start time
            h, m, s = map(int, start_parts[0].split(':'))
            ms = int(start_parts[1]) + 3585
            s += ms // 1000
            ms = ms % 1000
            m += s // 60
            s = s % 60
            h += m // 60
            m = m % 60
            new_start = f"{h:02d}:{m:02d}:{s:02d},{ms:03d}"

            # Add offset to end time
            h, m, s = map(int, end_parts[0].split(':'))
            ms = int(end_parts[1]) + 3585
            s += ms // 1000
            ms = ms % 1000
            m += s // 60
            s = s % 60
            h += m // 60
            m = m % 60
            new_end = f"{h:02d}:{m:02d}:{s:02d},{ms:03d}"

            return f"{new_start} --> {new_end}"

        # Apply the offset to all timestamps
        content = re.sub(r'(\d{2}:\d{2}:\d{2},\d{3}) --> (\d{2}:\d{2}:\d{2},\d{3})', add_offset, content)

        with open(srt_file, 'w', encoding='utf-8') as f:
            f.write(content)

        # Use mkvmerge to embed the modified subtitles
        temp_output = mkv_file + ".temp.mkv"
        merge_command = [
            "mkvmerge",
            "-o", temp_output,
            mkv_file,
            "--language", "0:eng",
            "--track-name", "0:English",
            srt_file
        ]

        result = subprocess.run(
            merge_command,
            text=True,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE
        )

        if result.returncode != 0:
            logging.error(f"❌ Error embedding TED subtitles: {result.stderr}")
            if os.path.exists(temp_output):
                os.remove(temp_output)
            return False

        # Replace original file with the new one
        os.replace(temp_output, mkv_file)
        return True

    except Exception as e:
        logging.error(f"❌ Error processing TED subtitles: {e}")
        temp_cleanup = mkv_file + ".temp.mkv"
        if os.path.exists(temp_cleanup):
            os.remove(temp_cleanup)
        return False

def embed_lyrics_in_mp3(mp3_file, srt_file):
    """
    Convert SRT to LRC format and embed in MP3 using ID3v2.3.

    Reads subtitles from an SRT file, converts them to LRC format,
    and embeds them as synchronised lyrics in an MP3 file.

    Args:
        mp3_file (str): Path to the MP3 file
        srt_file (str): Path to the SRT subtitle file

    Returns:
        bool: True if successful, False otherwise
    """
    try:
        if not os.path.exists(mp3_file) or not mp3_file.lower().endswith('.mp3'):
            logging.error("❌ Invalid MP3 file for lyrics embedding")
            return False

        # Read and convert SRT content
        with open(srt_file, 'r', encoding='utf-8') as f:
            content = f.read()
            content = re.sub(r'\\h+', ' ', content)
            blocks = re.split(r'\n\n+', content.strip())
            lrc_lines = []
            last_end_time = None

            for block in blocks:
                lines = block.split('\n')
                if len(lines) < 3:
                    continue

                timestamp_line = lines[1]
                text_lines = lines[2:]

                start_time, end_time = timestamp_line.split(' --> ')
                lrc_timestamp = convert_srt_timestamp(start_time)
                last_end_time = end_time

                if lrc_timestamp:
                    text = ' '.join(text_lines)
                    lrc_lines.append(f"{lrc_timestamp} {text}")

            # Add final empty timestamp
            if last_end_time:
                final_timestamp = convert_srt_timestamp(last_end_time)
                if final_timestamp:
                    lrc_lines.append(f"{final_timestamp}")

        if not lrc_lines:
            return False

        # Embed lyrics in MP3
        try:
            audio = ID3(mp3_file)
        except Exception:
            audio = ID3()

        audio.version = (2, 3, 0)
        audio.delall("f")
        audio.add(USLT(encoding=3, lang='eng', text='\n'.join(lrc_lines)))
        audio.save(mp3_file, v2_version=3)
        logging.debug("✅ Embedded synchronised lyrics in MP3")
        return True

    except Exception as e:
        logging.error(f"❌ Error embedding lyrics: {e}")
        return False

# Section 5: File matching and platform detection

def find_closest_filename(expected_name, directory, desired_extension=None):
    """
    Find a file in the directory that closely matches the expected name.

    Handles case differences, special characters, and fuzzy matching
    to find an existing file that matches the expected filename.
    Optionally filters by file extension.

    Args:
        expected_name (str): The expected filename to match
        directory (str): Directory to search in
        desired_extension (str, optional): File extension to filter by

    Returns:
        str: Path to the matching file, or None if no match found
    """
    expected_normalised = normalise_filename(expected_name)
    all_files = os.listdir(directory)
    normalised_files = {normalise_filename(f): f for f in all_files}

    if desired_extension:
        desired_extension = desired_extension.lower()
        video_extensions = {'.mkv', '.mp4', '.webm'}

        for real_name in normalised_files.values():
            base_name = os.path.splitext(real_name)[0]
            ext = os.path.splitext(real_name)[1].lower()
            if (normalise_filename(base_name) == os.path.splitext(expected_normalised)[0] and
                ext == desired_extension):
                return os.path.join(directory, real_name)

        for real_name in normalised_files.values():
            base_name = os.path.splitext(real_name)[0]
            ext = os.path.splitext(real_name)[1].lower()
            if normalise_filename(base_name) == os.path.splitext(expected_normalised)[0]:
                if (desired_extension == '.mp3' and ext in video_extensions) or \
                   (desired_extension in video_extensions and ext == '.mp3'):
                    return None

        return None

    if expected_normalised in normalised_files:
        return os.path.join(directory, normalised_files[expected_normalised])

    closest_match = difflib.get_close_matches(expected_normalised, normalised_files.keys(), n=1, cutoff=0.8)
    if closest_match:
        return os.path.join(directory, normalised_files[closest_match[0]])
    return None

# Platform detection and chapter handling
def is_supported_video_platform(url):
    """
    Check if the URL is from a supported video platform that might have chapters.

    Detects if the URL belongs to YouTube, TED, Vimeo, or Dailymotion
    using regular expression pattern matching.

    Args:
        url (str): URL to check

    Returns:
        tuple: (is_supported, platform_name)
            - is_supported (bool): True if the platform is supported
            - platform_name (str): Name of the detected platform
    """
    youtube_patterns = [
        r'(?:https?://)?(?:www\.)?youtube\.com/watch\?v=[\w-]+',
        r'(?:https?://)?(?:www\.)?youtube\.com/v/[\w-]+',
        r'(?:https?://)?youtu\.be/[\w-]+',
        r'(?:https?://)?(?:www\.)?youtube\.com/embed/[\w-]+',
        r'(?:https?://)?(?:www\.)?youtube\.com/shorts/[\w-]+'
    ]

    ted_patterns = [
        r'(?:https?://)?(?:www\.)?ted\.com/talks/[\w-]+',
        r'(?:https?://)?(?:www\.)?ted\.com/talks/lang/\w+/[\w-]+'
    ]

    vimeo_patterns = [
        r'(?:https?://)?(?:www\.)?vimeo\.com/\d+',
        r'(?:https?://)?player\.vimeo\.com/video/\d+'
    ]

    dailymotion_patterns = [
        r'(?:https?://)?(?:www\.)?dailymotion\.com/video/[\w]+',
        r'(?:https?://)?dai\.ly/[\w]+'
    ]

    combined_youtube = '|'.join(youtube_patterns)
    if re.match(combined_youtube, url):
        return True, "youtube"

    combined_ted = '|'.join(ted_patterns)
    if re.match(combined_ted, url):
        return True, "ted"

    combined_vimeo = '|'.join(vimeo_patterns)
    if re.match(combined_vimeo, url):
        return True, "vimeo"

    combined_dailymotion = '|'.join(dailymotion_patterns)
    if re.match(combined_dailymotion, url):
        return True, "dailymotion"

    return False, "unknown"

# Section 6: Chapter extraction functions

def extract_chapter_titles(url, chapters_xml):
    """
    Extracts chapters based on the video platform.

    Delegates to platform-specific extraction functions based on
    the detected video platform.

    Args:
        url (str): URL of the video
        chapters_xml (str): Path to save the extracted chapters XML

    Returns:
        bool: True if chapters were extracted successfully, False otherwise
    """
    is_supported, platform = is_supported_video_platform(url)

    if not is_supported:
        logging.debug(f"⚠️ No chapter extraction available for this URL type")
        return False

    if platform == "youtube":
        return extract_youtube_chapters(url, chapters_xml)
    elif platform == "ted":
        return extract_ted_chapters(url, chapters_xml)
    elif platform in ["vimeo", "dailymotion"]:
        logging.debug(f"⚠️ Chapter extraction for {platform} not yet implemented")
        return False
    else:
        logging.debug(f"⚠️ Unrecognised platform for chapter extraction")
        return False

def extract_youtube_chapters(url, chapters_xml):
    """
    Extracts both YouTube chapters and SponsorBlock chapters using yt-dlp.

    Gets chapter information from both the video's own chapter markers
    and the SponsorBlock community database, combining them into
    a single chapters XML file.

    Args:
        url (str): YouTube URL
        chapters_xml (str): Path to save the extracted chapters XML

    Returns:
        bool: True if chapters were extracted successfully, False otherwise
    """
    try:
        # Build the command with user agent and cookies
        cmd = ["yt-dlp", "--cookies-from-browser", "firefox", "--dump-json", "--sponsorblock-mark", "--user-agent", SYSTEM_USER_AGENT, url]

        result = subprocess.run(
            cmd,
            text=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE
        )
        regular_chapters = []
        if result.stdout.strip():
            try:
                video_data = json.loads(result.stdout)
                if "chapters" in video_data:
                    regular_chapters = video_data["chapters"]
                    if regular_chapters:
                        logging.debug("✅ Chapters found")
                    else:
                        logging.debug("❌ No chapters available")
            except Exception as e:
                logging.debug("❌ No chapters available")
        else:
            logging.debug("❌ No chapters available")

        logging.debug("🔍 Getting SponsorBlock segments ...")
        sponsor_chapters = []
        if result.stdout.strip():
            try:
                video_data = json.loads(result.stdout)
                if "sponsorblock_chapters" in video_data and video_data["sponsorblock_chapters"]:
                    for segment in video_data["sponsorblock_chapters"]:
                        sponsor_chapters.append({
                            "start_time": segment["start_time"],
                            "end_time": segment["end_time"],
                            "title": f"[SponsorBlock] {segment['category']}"
                        })
                    logging.debug("✅ SponsorBlock segments found")
                else:
                    logging.debug("⚠️ No SponsorBlock segments available")
            except Exception as e:
                logging.debug("⚠️ No SponsorBlock segments available")
        else:
            logging.debug("⚠️ No SponsorBlock segments available")

        all_chapters = []

        for chapter in regular_chapters:
            all_chapters.append({
                "start_time": chapter["start_time"],
                "end_time": chapter["end_time"],
                "title": chapter["title"]
            })

        all_chapters.extend(sponsor_chapters)
        all_chapters.sort(key=lambda x: x["start_time"])

        if all_chapters:
            with open(chapters_xml, "w", encoding="utf-8") as f:
                for i, chapter in enumerate(all_chapters, 1):
                    start_ms = int(chapter["start_time"] * 1000)
                    hours = start_ms // 3600000
                    minutes = (start_ms % 3600000) // 60000
                    seconds = (start_ms % 60000) // 1000
                    milliseconds = start_ms % 1000

                    timestamp = f"{hours:02d}:{minutes:02d}:{seconds:02d}.{milliseconds:03d}"
                    f.write(f"CHAPTER{i:02d}={timestamp}\n")
                    f.write(f"CHAPTER{i:02d}NAME={chapter['title']}\n")

            logging.debug(f"✅ Created chapters.xml with {len(all_chapters)} chapters")
            return True
        else:
            return False

    except subprocess.CalledProcessError as e:
        logging.error(f"❌ Failed to extract chapter information: {e}")
        return False

def extract_ted_chapters(url, chapters_xml):
    """
    Extracts chapters from TED talks using yt-dlp's json output.

    Parses the video description to extract timestamp-based chapters
    that are common in TED talks.

    Args:
        url (str): TED talk URL
        chapters_xml (str): Path to save the extracted chapters XML

    Returns:
        bool: True if chapters were extracted successfully, False otherwise
    """
    try:
        # Build the command with user agent and optional cookies
        cmd = ["yt-dlp", "--cookies-from-browser", "firefox", "--dump-json", "--user-agent", SYSTEM_USER_AGENT, url]

        result = subprocess.run(
            cmd,
            text=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE
        )

        if not result.stdout.strip():
            logging.debug("❌ No TED data available")
            return False

        try:
            video_data = json.loads(result.stdout)
            description = video_data.get("description", "")

            timestamp_pattern = r'(?:^|\n)(?P<time>\d{1,2}:(?:\d{1,2})(?::\d{1,2})?) (?P<title>.*?)(?=\n\d{1,2}:|$)'
            timestamps = re.finditer(timestamp_pattern, description)

            chapters = []
            for match in timestamps:
                time_str = match.group('time')
                title = match.group('title').strip()

                parts = time_str.split(':')
                if len(parts) == 2:  # MM:SS format
                    minutes, seconds = map(int, parts)
                    start_time = minutes * 60 + seconds
                elif len(parts) == 3:  # HH:MM:SS format
                    hours, minutes, seconds = map(int, parts)
                    start_time = hours * 3600 + minutes * 60 + seconds
                else:
                    continue

                chapters.append({
                    "start_time": start_time,
                    "end_time": start_time + 1,
                    "title": title
                })

            chapters.sort(key=lambda x: x["start_time"])

            for i in range(len(chapters) - 1):
                chapters[i]["end_time"] = chapters[i + 1]["start_time"]

            if "duration" in video_data and chapters:
                chapters[-1]["end_time"] = video_data["duration"]

            if chapters:
                with open(chapters_xml, "w", encoding="utf-8") as f:
                    for i, chapter in enumerate(chapters, 1):
                        start_ms = int(chapter["start_time"] * 1000)
                        hours = start_ms // 3600000
                        minutes = (start_ms % 3600000) // 60000
                        seconds = (start_ms % 60000) // 1000
                        milliseconds = start_ms % 1000

                        timestamp = f"{hours:02d}:{minutes:02d}:{seconds:02d}.{milliseconds:03d}"
                        f.write(f"CHAPTER{i:02d}={timestamp}\n")
                        f.write(f"CHAPTER{i:02d}NAME={chapter['title']}\n")

                logging.debug(f"✅ Created chapters.xml with {len(chapters)} TED chapters")
                return True
            else:
                logging.debug("⚠️ No chapters found in TED talk description")
                return False

        except json.JSONDecodeError:
            logging.debug("❌ Failed to parse TED video data")
            return False

    except subprocess.CalledProcessError as e:
        logging.error(f"❌ Failed to extract TED chapter information: {e}")
        return False

def apply_chapters_to_mkv(mkv_file, chapters_xml):
    """
    Applies the updated chapters.xml to the MKV file.

    Uses mkvpropedit external tool to embed chapter information into
    the MKV file.

    Args:
        mkv_file (str): Path to the MKV file
        chapters_xml (str): Path to the chapters XML file

    Returns:
        bool: True if successful, False otherwise
    """
    try:
        result = subprocess.run(
            ["mkvpropedit", mkv_file, "--chapters", chapters_xml],
            text=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE
        )

        if result.returncode != 0:
            logging.error(f"❌ mkvpropedit error: {result.stderr.strip()}")
            return False

        return True

    except subprocess.CalledProcessError as e:
        logging.error(f"❌ Failed to apply chapters: {e}")
        return False

# Section 7: Video processing main functions

def process_single_video(handler, url, audio_only, temp_processing_dir, item_num=1, total_items=1, resolution="1080", use_mp4=False, use_cookies=True, progress_callback=None):
    """
    Process a single video download completely - from download to final file move.

    This is the core function that handles the entire process of downloading
    a video from a supported platform, processing it according to parameters
    and saving it to the destination folder. Includes special handling for
    various platforms and formats.

    Args:
        handler: The HTTP request handler instance (can be None for async downloads)
        url (str): URL of the video to download
        audio_only (bool): Whether to extract audio only (MP3)
        temp_processing_dir (Path): Temporary directory for processing
        item_num (int): Current item number in a playlist
        total_items (int): Total number of items in a playlist
        resolution (str): Max resolution - "480", "720", "1080", or "best"
        use_mp4 (bool): Whether to use MP4 instead of MKV
        use_cookies (bool): Whether to use browser cookies for auth
        progress_callback (callable, optional): Function called with progress updates.
            Signature: progress_callback(phase, progress, speed, eta, title, error_message)

    Returns:
        tuple: (processed_file, file_size_bytes)
            - processed_file (str): Name of the processed file
            - file_size_bytes (int): Size of the processed file in bytes
    """

    # Use the configured filename template
    output_template = f"{FILENAME_TEMPLATE}.%(ext)s"

    # Apply randomized delay to mimic human behavior and reduce detection
    if item_num > 1:
        delay = random.uniform(1.0, 3.0)
        time.sleep(delay)

    # Get expected filename for this video
    url = clean_video_url(url)

    # Notify resolving phase
    if progress_callback:
        progress_callback("resolving", 0.0, "", "", "", "")

    # Build the filename command with user agent
    filename_command = [
        "yt-dlp",
        "--print", "filename",
        "--user-agent", SYSTEM_USER_AGENT,
        "--downloader-args", "default:{'external_client':'firefox135'}",
        "-o", output_template,
        "-P", str(DEFAULT_DOWNLOAD_FOLDER),
        url
    ]

    # Add cookies if enabled
    if use_cookies:
        filename_command.insert(1, "--cookies-from-browser")
        filename_command.insert(2, "firefox")

    try:
        filename_result = subprocess.run(
            filename_command,
            text=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE,
            check=False
        )

        if not filename_result.stdout.strip():
            logging.error("❌ No video found")
            print(f"───────────────────────────────────────────")
            print(f"😎 Ready")
            if progress_callback:
                progress_callback("error", 0.0, "", "", "", "No video found")
            return None, 0

        output_filename = filename_result.stdout.strip()
        base_name = os.path.splitext(os.path.basename(output_filename))[0]

        print(f"🗃️ Downloading (filename may be temporarily sanitised):\n➡️ {base_name}")

        # Notify callback with resolved title
        if progress_callback:
            progress_callback("resolving", 0.0, "", "", base_name, "")

        # Prepare final filename
        final_extension = ".mp3" if audio_only else ".mp4" if use_mp4 else ".mkv"
        final_filepath = Path(output_filename).with_suffix(final_extension)
        final_destination = DEFAULT_DOWNLOAD_FOLDER / final_filepath.name

        # Check for existing file
        existing_file = find_closest_filename(final_filepath.name, DEFAULT_DOWNLOAD_FOLDER, final_extension)
        if existing_file:
            logging.info(f"✅ Skipping download, file already exists: {Path(existing_file).name}")
            if progress_callback:
                progress_callback("complete", 100.0, "", "", base_name, "")
            return Path(existing_file).name, Path(existing_file).stat().st_size

        # Set the yt-dlp output template
        yt_dlp_output_template = output_template

        # Check if it's a TED video
        is_ted_video = is_supported_video_platform(url)[1] == "ted"

        # Build base command parameters with user agent
        yt_dlp_command = [
            "yt-dlp",
            "--user-agent", SYSTEM_USER_AGENT,
            "--no-mtime",
            "--no-playlist",
            "--downloader-args", "default:{'external_client':'firefox135'}",
            "-o", yt_dlp_output_template,
            "-P", str(temp_processing_dir),
            "--convert-thumbnails", "png",
            "--embed-thumbnail",
            "--add-metadata",
            "--sub-lang", "en.*",
            "--convert-subs", "srt",
            "--newline",
            url
        ]

        # Add cookies if enabled
        if use_cookies:
            yt_dlp_command.insert(1, "--cookies-from-browser")
            yt_dlp_command.insert(2, "firefox")

        # Build format string based on resolution setting
        def get_format_string(res, is_ted=False):
            if res == "best":
                # No height limit, prioritize HDR
                return "(bestvideo[hdr=1])/(bestvideo[bit_depth=10])+(bestaudio)/bv*+ba/b"
            else:
                # Height-limited format with HDR preference
                return f"(bestvideo[hdr=1][height<={res}])/(bestvideo[bit_depth=10][height<={res}])/(bestvideo[height<={res}])+(bestaudio)/b[height<={res}]"

        # Add format-specific parameters based on conditions
        if not audio_only:
            if not is_ted_video:
                # Regular video download with embedded subs
                format_str = get_format_string(resolution)
                yt_dlp_command += [
                    "-f", format_str,
                    "-S", "lang,vcodec:av01,vcodec:vp09,res,br",
                    "--merge-output-format", "mp4" if use_mp4 else "mkv",
                    "--remux-video", "mp4" if use_mp4 else "mkv",
                    "--embed-subs",
                    "--sub-format", "srt/best",
                    "--sponsorblock-mark", "all,-music_offtopic,-poi_highlight"
                ]
            else:
                # TED video - download subs separately
                format_str = get_format_string(resolution, is_ted=True) if resolution != "best" else "bv*+ba/b"
                yt_dlp_command += [
                    "-f", format_str,
                    "-S", "lang,vcodec:av01,vcodec:vp09,res,br",
                    "--merge-output-format", "mp4" if use_mp4 else "mkv",
                    "--remux-video", "mp4" if use_mp4 else "mkv",
                    "--write-sub",
                    "--sub-format", "srt/best",
                    "--sponsorblock-mark", "all,-music_offtopic,-poi_highlight"
                ]
        else:
            # Audio-only downloads always get separate subtitle handling
            yt_dlp_command += [
                "-f", "bestaudio/best",
                "-S", "lang",
                "--extract-audio",
                "--audio-format", "mp3",
                "--audio-quality", "0",
                "--write-sub"
            ]

        # Clean URL to remove playlist parameters
        yt_dlp_command[-1] = clean_video_url(yt_dlp_command[-1])

        # Start download with progress tracking
        current_video_url = url
        thumbnail_embedded = False
        file_info = f" (File {item_num}/{total_items})" if total_items > 1 else ""

        # Clear flags for download type detection
        is_downloading_audio = False
        is_downloading_video = False
        is_downloading_metadata = False

        # State tracking
        download_count = 0
        download_sequence = []
        has_downloaded_mp4 = False

        # Check for cancellation before starting subprocess
        if cancel_event.is_set():
            if progress_callback:
                progress_callback("error", 0.0, "", "", base_name, "Download cancelled")
            return None, 0

        process = subprocess.Popen(
            yt_dlp_command,
            text=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE
        )

        while True:
            # Check for cancellation
            if cancel_event.is_set():
                process.terminate()
                try:
                    process.wait(timeout=5)
                except subprocess.TimeoutExpired:
                    process.kill()
                if progress_callback:
                    progress_callback("error", 0.0, "", "", base_name, "Download cancelled")
                return None, 0

            output = process.stdout.readline()
            if output == "" and process.poll() is not None:
                break

            if output:
                # Detect what's currently downloading
                if "[download]" in output and "Destination:" in output:
                    # Reset flags
                    is_downloading_audio = False
                    is_downloading_video = False
                    is_downloading_metadata = False
                    download_count += 1

                    # For TED videos, use a simple index-based approach
                    # First = metadata, Second = video, Third = audio
                    if is_ted_video and not audio_only:
                        if ".vtt" in output.lower() or ".srt" in output.lower() or ".json" in output.lower() or ".jpg" in output.lower() or ".png" in output.lower():
                            is_downloading_metadata = True
                            download_sequence.append("metadata")
                        elif download_count == 2:
                            is_downloading_video = True
                            has_downloaded_mp4 = True
                            download_sequence.append("video")
                        elif download_count == 3:
                            is_downloading_audio = True
                            download_sequence.append("audio")
                        else:
                            # Default to metadata for any additional files
                            is_downloading_metadata = True
                            download_sequence.append("metadata")
                    else:
                        # For all other video sites
                        if any(ext in output.lower() for ext in [".srt", ".vtt", ".jpg", ".png", ".json", ".ytdl"]):
                            is_downloading_metadata = True
                        elif audio_only:
                            is_downloading_audio = True
                        elif any(ext in output.lower() for ext in [".m4a", ".mp3", ".aac", ".opus", ".weba", ".ogg", ".wav", ".flac", ".ac3", ".mka"]):
                            is_downloading_audio = True
                        elif ".f" in output and any(format_id in output for format_id in ["140", "249", "250", "251", "139", "171", "258"]):
                            is_downloading_audio = True
                        elif any(indicator in output.lower() for indicator in ["audio only", "audio_only", "audio stream", "audio track", "audio-only"]):
                            is_downloading_audio = True
                        elif any(pattern in output.lower() for pattern in ["audio-high", "-audio-", "dash_audio", "audio_track", "audio-track", "audio_mp4", "audio-mp4", "mp4-audio", "audio_segment", "audio=", "audio_only=true"]):
                            is_downloading_audio = True
                        else:
                            is_downloading_video = True

                # Handle progress updates
                progress_match = re.search(r'\[download\]\s+(\d+\.\d+)% of', output)
                if progress_match:
                    progress = progress_match.group(1)
                    sys.stdout.write('\r' + ' ' * 70 + '\r')  # Clear line

                    if is_downloading_metadata:
                        msg = f"📄 Downloading metadata: {progress}%"
                    elif is_downloading_video:
                        msg = f"📽️ Downloading video: {progress}%"
                    elif is_downloading_audio:
                        msg = f"🎧 Downloading audio: {progress}%"
                    else:
                        msg = f"📥 Downloading: {progress}%"

                    if file_info:
                        msg += file_info
                    sys.stdout.write(msg)
                    sys.stdout.flush()

                    # Call progress callback for async tracking
                    if progress_callback:
                        # Determine phase
                        if is_downloading_video:
                            phase = "downloading_video"
                        elif is_downloading_audio:
                            phase = "downloading_audio"
                        else:
                            phase = "downloading_video"  # default

                        # Parse speed and ETA from yt-dlp output
                        speed_str = ""
                        eta_str = ""
                        speed_match = re.search(r'at\s+([\d.]+\w+/s)', output)
                        if speed_match:
                            speed_str = speed_match.group(1)
                        eta_match = re.search(r'ETA\s+(\S+)', output)
                        if eta_match:
                            eta_str = eta_match.group(1)

                        progress_callback(phase, float(progress), speed_str, eta_str, base_name, "")

                # Also check for merging/processing lines
                if progress_callback:
                    if "[Merger]" in output or "[Merger] Merging" in output:
                        progress_callback("processing", 99.0, "", "", base_name, "")
                    elif "[ExtractAudio]" in output:
                        progress_callback("processing", 99.0, "", "", base_name, "")
                    elif "[EmbedSubtitle]" in output or "[EmbedThumbnail]" in output:
                        progress_callback("processing", 99.0, "", "", base_name, "")

        # Replace final progress line with "Done" message
        if download_count > 0:
            sys.stdout.write('\r' + ' ' * 70 + '\r')  # Clear line
            now = datetime.datetime.now()
            timestamp = now.strftime("%Y-%m-%d %H:%M:%S") + f",{now.microsecond // 1000:03d}"
            file_info = f" (File {item_num}/{total_items})" if total_items > 1 else ""
            done_msg = f"💯 Done{file_info} 💥 {timestamp}"
            sys.stdout.write(done_msg + '\n')
            sys.stdout.flush()

        # Process downloaded file
        processed_file = None
        file_size_bytes = 0

        # Wait for file
        retries = 0
        max_retries = 10
        while retries < max_retries:
            download_files = list(temp_processing_dir.glob(f"*.{'mp3' if audio_only else 'mp4' if use_mp4 else 'mkv'}"))
            if download_files:
                break
            time.sleep(0.5)
            retries += 1

        if not download_files:
            logging.error(f"❌ No downloaded file found for: {final_filepath.name}")
            if progress_callback:
                progress_callback("error", 0.0, "", "", base_name, "No downloaded file found")
            return None, 0

        file_path = download_files[0]

        # Handle audio processing
        if audio_only:
            # Process TED audio or regular audio
            srt_files = list(temp_processing_dir.glob("*.srt"))
            matching_srt = None
            for srt in srt_files:
                if any(part in file_path.stem for part in srt.stem.split('.')):
                    matching_srt = srt
                    break

            if matching_srt:
                if is_ted_video:
                    if fix_TED_lyrics_before_embedding_in_mp3(str(matching_srt)):
                        if embed_lyrics_in_mp3(str(file_path), str(matching_srt)):
                            logging.info("🎧 Embedded TED transcript in MP3")
                        else:
                            logging.warning("⚠️ Failed to embed TED transcript")
                else:
                    if embed_lyrics_in_mp3(str(file_path), str(matching_srt)):
                        logging.info("🎧 Embedded synchronised lyrics/transcript in MP3")
                    else:
                        logging.warning("⚠️ No lyrics/transcript available")
                try:
                    os.remove(matching_srt)
                    logging.debug(f"🧹 Deleted temporary subtitle file: {matching_srt.name}")
                except Exception as e:
                    logging.error(f"❌ Error deleting subtitle file: {e}")

        # Handle video processing
        if not audio_only:
            if is_ted_video:
                # Process TED video subtitles
                srt_files = list(temp_processing_dir.glob("*.srt"))
                matching_srt = None
                for srt in srt_files:
                    if any(part in file_path.stem for part in srt.stem.split('.')):
                        matching_srt = srt
                        break

                if matching_srt:
                    if fix_TED_lyrics_and_embed_in_mkv(str(file_path), str(matching_srt)):
                        logging.info("🗨️ Embedded TED subtitles in MKV")
                    else:
                        logging.warning("⚠️ Failed to embed TED subtitles")
                    try:
                        os.remove(matching_srt)
                    except Exception as e:
                        logging.error(f"❌ Error deleting subtitle file: {e}")
            else:
                # Handle chapters for supported platforms (skip for MP4)
                if not use_mp4:
                    is_supported, platform = is_supported_video_platform(current_video_url)
                    if is_supported:
                        logging.debug(f"📥 Getting chapters from {platform} ...")
                        chapters_xml = Path(temp_processing_dir) / f"{file_path.stem}_chapters.xml"

                        if extract_chapter_titles(current_video_url, str(chapters_xml)):
                            logging.debug("📌 Applying chapters to MKV ...")
                            apply_chapters_to_mkv(str(file_path), str(chapters_xml))
                            if os.path.exists(chapters_xml):
                                logging.debug(f"🧹 Cleaning up chapters file: {chapters_xml}")
                                os.remove(chapters_xml)

        # Move and finalise file
        final_destination = DEFAULT_DOWNLOAD_FOLDER / file_path.name
        shutil.move(str(file_path), str(final_destination))

        if final_destination.exists():
            file_size_bytes = final_destination.stat().st_size
            processed_file = final_destination.name

            # Only show individual file line for playlists
            if total_items > 1:
                file_size_mb = file_size_bytes / (1024 * 1024)
                formatted_size = f"{file_size_mb:.2f} MB" if file_size_mb >= 1 else f"{file_size_bytes / 1024:.2f} KB"
                emoji = "💿" if final_destination.suffix == '.mp3' else "📺"
                print(f"{emoji} {final_destination.name} ({formatted_size})")

            # Always print the separator
            print("─────────────────")

            # Notify callback of completion
            if progress_callback:
                progress_callback("complete", 100.0, "", "", base_name, "")

        # Cleanup
        leftover_files = list(temp_processing_dir.glob("*.*"))
        for leftover in leftover_files:
            try:
                os.remove(leftover)
            except Exception:
                pass

        return processed_file, file_size_bytes

    except subprocess.CalledProcessError as e:
        if "getaddrinfo failed" in str(e) or "network is unreachable" in str(e) or "socket error" in str(e):
            logging.error("❌ Network connection error - Please check your internet connection")
        else:
            logging.error(f"❌ Error processing URL: {url}. Details: {e}")
        if progress_callback:
            progress_callback("error", 0.0, "", "", "", str(e))
        return None, 0
    except Exception as e:
        logging.error(f"❌ Unexpected error processing {url}: {str(e)}")
        if progress_callback:
            progress_callback("error", 0.0, "", "", "", str(e))
        return None, 0

# Section 7.5: Async download worker

def download_worker():
    """
    Background thread worker that processes download queue items one at a time.

    Pops items from the global download_queue, processes them using
    process_single_video(), updates download_state throughout, and
    adds completed entries to download history. Continues until the
    queue is empty, then exits.
    """
    global download_queue

    while True:
        # Get next item from queue
        item = None
        with download_lock:
            # Find next pending item
            for q_item in download_queue:
                if q_item["status"] == "pending":
                    q_item["status"] = "active"
                    item = q_item
                    break

        if item is None:
            # No more items to process
            with download_lock:
                reset_download_state()
            break

        # Check for cancellation
        if cancel_event.is_set():
            with download_lock:
                item["status"] = "cancelled"
                reset_download_state()
            # Cancel remaining items
            with download_lock:
                for q_item in download_queue:
                    if q_item["status"] == "pending":
                        q_item["status"] = "cancelled"
            break

        # Update download state
        with download_lock:
            download_state["active"] = True
            download_state["id"] = item["id"]
            download_state["url"] = item["url"]
            download_state["title"] = ""
            download_state["progress"] = 0.0
            download_state["phase"] = "resolving"
            download_state["speed"] = ""
            download_state["eta"] = ""
            download_state["error_message"] = ""
            download_state["file_name"] = ""
            download_state["file_size"] = 0

        # Define progress callback that updates global state
        def progress_callback(phase, progress, speed, eta, title, error_message):
            with download_lock:
                download_state["phase"] = phase
                download_state["progress"] = progress
                download_state["speed"] = speed
                download_state["eta"] = eta
                if title:
                    download_state["title"] = title
                    item["title"] = title
                if error_message:
                    download_state["error_message"] = error_message

        # Process the download
        temp_processing_dir = get_temp_processing_dir()
        cleanup_temp_dir(temp_processing_dir)

        logging.info("🚀 Download started 🪐")
        print(f"🌍 URL: {item['url']}")
        res_label = "Best available" if item["resolution"] == "best" else f"{item['resolution']}p"
        print(f"🎧 Audio only?: {'✅ Yes' if item['audio_only'] else '❌ No'}\n📽️ Max resolution: {res_label}\n📼 Format: {'MP4' if item['use_mp4'] else 'MKV'}\n🍪 Browser cookies: {'✅ Yes' if item['use_cookies'] else '❌ No'}")
        print(f"🔎 Getting filename/playlist info ...")

        start_time = time.time()

        try:
            processed_file, file_size = process_single_video(
                None,  # no HTTP handler needed for async
                item["url"],
                item["audio_only"],
                temp_processing_dir,
                1, 1,
                item["resolution"],
                item["use_mp4"],
                item["use_cookies"],
                progress_callback=progress_callback
            )

            elapsed_time = time.time() - start_time
            formatted_time = time.strftime("%H:%M:%S", time.gmtime(elapsed_time))

            with download_lock:
                if processed_file:
                    item["status"] = "complete"
                    item["file_name"] = processed_file
                    item["file_size"] = file_size
                    item["progress"] = 100.0

                    download_state["phase"] = "complete"
                    download_state["progress"] = 100.0
                    download_state["file_name"] = processed_file
                    download_state["file_size"] = file_size

                    # Determine format
                    if processed_file.endswith(".mp3"):
                        fmt = "mp3"
                    elif processed_file.endswith(".mp4"):
                        fmt = "mp4"
                    else:
                        fmt = "mkv"

                    # Add to history
                    history_entry = {
                        "id": item["id"],
                        "url": item["url"],
                        "filename": processed_file,
                        "fileSize": file_size,
                        "completedAt": datetime.datetime.now().isoformat(timespec="seconds"),
                        "audioOnly": item["audio_only"],
                        "format": fmt,
                        "resolution": item["resolution"]
                    }
                    add_history_entry(history_entry)

                    file_size_formatted = format_size(file_size)
                    emoji = "💿" if processed_file.endswith('.mp3') else "📺"
                    print(f"💥 Download summary")
                    print(f"{emoji} {processed_file} ({file_size_formatted})")
                    print(f"📂 Saved in folder: {DEFAULT_DOWNLOAD_FOLDER}")
                    print(f"\n😎 Ready\n")
                else:
                    item["status"] = "error"
                    item["error_message"] = download_state.get("error_message", "Download failed")
                    download_state["phase"] = "error"
                    if not download_state["error_message"]:
                        download_state["error_message"] = "Download failed"
                    print(f"❌ Download failed for: {item['url']}")
                    print(f"\n😎 Ready\n")

        except Exception as e:
            with download_lock:
                item["status"] = "error"
                item["error_message"] = str(e)
                download_state["phase"] = "error"
                download_state["error_message"] = str(e)
            logging.error(f"❌ Worker error: {e}")
            print(f"\n😎 Ready\n")

        cleanup_temp_dir(temp_processing_dir)

    # Prune old completed/error/cancelled items — keep at most 50
    with download_lock:
        finished = [q for q in download_queue if q["status"] in ("complete", "error", "cancelled")]
        if len(finished) > 50:
            ids_to_remove = {q["id"] for q in finished[:-50]}
            download_queue[:] = [q for q in download_queue if q["id"] not in ids_to_remove]

    # Worker is done — clear the cancel event for next run
    cancel_event.clear()


def start_worker_if_needed():
    """
    Start the download worker thread if it's not already running.
    Protected by download_lock to prevent duplicate worker threads.
    """
    global worker_thread
    with download_lock:
        if worker_thread is None or not worker_thread.is_alive():
            cancel_event.clear()
            worker_thread = threading.Thread(target=download_worker, daemon=True)
            worker_thread.start()


# Section 8: HTTP server implementation

class BatchRequestHandler(BaseHTTPRequestHandler):
    """
    Custom HTTP request handler for the download server.

    Handles HTTP requests for video downloads, folder settings
    and server information. Implements custom error handling
    for connection aborted errors.
    """
    def log_message(self, format, *args):
        """
        Override to suppress default server log messages.

        Args:
            format: Format string
            *args: Format arguments
        """
        pass

    def _set_headers(self, status_code=200, content_type="application/json"):
        """
        Set common HTTP response headers.

        Args:
            status_code (int): HTTP status code (default: 200)
            content_type (str): Content-Type header value (default: "application/json")
        """
        self.send_response(status_code)
        self.send_header("Content-Type", content_type)
        origin = self.headers.get("Origin", "")
        if origin.startswith("moz-extension://") or origin.startswith("http://localhost") or origin.startswith("http://127.0.0.1"):
            self.send_header("Access-Control-Allow-Origin", origin)
        else:
            self.send_header("Access-Control-Allow-Origin", "null")
        self.send_header("Access-Control-Allow-Methods", "GET, POST, OPTIONS")
        self.send_header("Access-Control-Allow-Headers", "Content-Type")
        self.send_header("Access-Control-Max-Age", "3600")
        self.end_headers()

    def do_OPTIONS(self):
        """Handle OPTIONS requests for CORS preflight."""
        self._set_headers(200)

    def handle_error(self, request, client_address):
        """
        Override to suppress ConnectionAbortedError tracebacks during request processing.

        This catches connection errors that occur while sending responses to clients,
        which is different from the server-level handle_connection_error function.

        Args:
            request: The client request object
            client_address: A tuple containing the client's address information
        """
        error_type, error_value, _ = sys.exc_info()
        if isinstance(error_value, ConnectionAbortedError):
            print("\n❌ Connection lost")
            print("─────────────────")
            print("😎 Ready")
        else:
            super().handle_error(request, client_address)

    def do_GET(self):
        """
        Handle GET requests.

        Processes favicon requests, folder information requests,
        server information requests, download progress, queue status,
        history, and legacy download requests.
        """
        if self.path == "/favicon.ico":
            self._set_headers(204)
            return

        if self.path == "/folder":
            self._set_headers(200, "application/json")
            folder_response = {
                "folder": str(DEFAULT_DOWNLOAD_FOLDER)
            }
            try:
                self.wfile.write(json.dumps(folder_response).encode())
            except ConnectionAbortedError:
                logging.debug("Connection aborted before response was fully sent.")
            return

        elif self.path == "/server-info":
            self._set_headers(200, "application/json")
            server_path = str(Path(__file__).parent.resolve())
            if not server_path:
                server_path = str(Path.home() / "Downloads" / "Simple downloads")

            with settings_lock:
                server_info = {
                    "server_path": server_path,
                    "server_file": str(Path(__file__).resolve()),
                    "platform": get_platform_key(),
                    "port": settings["port"],
                    "resolution": settings.get("resolution", "1080"),
                    "use_mp4": settings.get("use_mp4", False),
                    "use_cookies": settings.get("use_cookies", True),
                    "filename_template": settings.get("filename_template", "%(title)s-%(id)s"),
                    "package_manager": get_linux_package_manager() if get_platform_key() == "linux" else None,
                }
            try:
                self.wfile.write(json.dumps(server_info).encode())
            except ConnectionAbortedError:
                logging.debug("Connection aborted before response was fully sent.")
                return
            return

        elif self.path.startswith("/check-dependency"):
            query = urllib.parse.urlparse(self.path).query
            params = urllib.parse.parse_qs(query)

            if "name" in params:
                dependency_name = params["name"][0]
                dependency_info = check_dependency(dependency_name)

                self._set_headers(200, "application/json")
                try:
                    self.wfile.write(json.dumps(dependency_info).encode())
                except ConnectionAbortedError:
                    logging.debug("Connection aborted before response was fully sent.")
                return
            else:
                self._set_headers(400)
                self.wfile.write(b"Missing dependency name parameter")
                return

        elif self.path == "/download-progress":
            # Return current download state
            state = get_download_state_snapshot()
            self._set_headers(200, "application/json")
            try:
                self.wfile.write(json.dumps(state).encode())
            except ConnectionAbortedError:
                logging.debug("Connection aborted before response was fully sent.")
            return

        elif self.path == "/queue":
            # Return full queue status
            with download_lock:
                items = []
                active_id = download_state["id"] if download_state["active"] else None
                for q_item in download_queue:
                    items.append({
                        "id": q_item["id"],
                        "url": q_item["url"],
                        "status": q_item["status"],
                        "progress": q_item.get("progress", 0.0),
                        "title": q_item.get("title", ""),
                        "file_name": q_item.get("file_name", ""),
                        "file_size": q_item.get("file_size", 0),
                    })
                # Update the active item's progress from download_state
                if active_id:
                    for it in items:
                        if it["id"] == active_id:
                            it["progress"] = download_state["progress"]
                            it["title"] = download_state["title"]
                            it["file_name"] = download_state["file_name"]
                            it["file_size"] = download_state["file_size"]
                            break

            response = {
                "items": items,
                "active_id": active_id
            }
            self._set_headers(200, "application/json")
            try:
                self.wfile.write(json.dumps(response).encode())
            except ConnectionAbortedError:
                logging.debug("Connection aborted before response was fully sent.")
            return

        elif self.path.startswith("/history"):
            # Parse query params for limit and offset
            query = urllib.parse.urlparse(self.path).query
            params = urllib.parse.parse_qs(query)
            try:
                limit = int(params.get("limit", ["50"])[0])
            except (ValueError, IndexError):
                limit = 50
            try:
                offset = int(params.get("offset", ["0"])[0])
            except (ValueError, IndexError):
                offset = 0

            history = load_history()
            total = len(history)
            # Return in reverse chronological order (newest first)
            history_reversed = list(reversed(history))
            page = history_reversed[offset:offset + limit]

            response = {
                "items": page,
                "total": total
            }
            self._set_headers(200, "application/json")
            try:
                self.wfile.write(json.dumps(response).encode())
            except ConnectionAbortedError:
                logging.debug("Connection aborted before response was fully sent.")
            return

        # Legacy GET download endpoint: /?url=...
        query = urllib.parse.urlparse(self.path).query
        params = urllib.parse.parse_qs(query)

        if "url" in params:
            url = params["url"][0]
            audio_only = params.get("audioOnly", [False])[0] == "true"
            resolution = params.get("resolution", ["1080"])[0]  # "480", "720", "1080", "best"
            use_mp4 = params.get("useMP4", [False])[0] == "true"
            use_cookies = params.get("useCookies", ["true"])[0] == "true"

            if not url:
                self._set_headers(400)
                self.wfile.write(b"Invalid URL provided")
                logging.error("Invalid URL received.")
                return

            logging.info("🚀 Download started 🪐")
            print(f"🌍 URL: {url}")
            res_label = "Best available" if resolution == "best" else f"{resolution}p"
            print(f"🎧 Audio only?: {'✅ Yes' if audio_only else '❌ No'}\n📽️ Max resolution: {res_label}\n📼 Format: {'MP4' if use_mp4 else 'MKV'}\n🍪 Browser cookies: {'✅ Yes' if use_cookies else '❌ No'}")


            print(f"🔎 Getting filename/playlist info ...")

            temp_processing_dir = get_temp_processing_dir()
            cleanup_temp_dir(temp_processing_dir)
            start_time = time.time()

            is_playlist_page = url.startswith("https://www.youtube.com/playlist?")

            try:
                processed_files = []
                total_size_bytes = 0

                if is_playlist_page:
                    # Build command with user agent
                    playlist_command = [
                        "yt-dlp",
                        "--user-agent", SYSTEM_USER_AGENT,
                        "--downloader-args", "default:{'external_client':'firefox135'}",
                        "--flat-playlist",
                        "--print", "%(id)s",
                        url
                    ]
                    if use_cookies:
                        playlist_command.insert(1, "--cookies-from-browser")
                        playlist_command.insert(2, "firefox")

                    playlist_result = subprocess.run(
                        playlist_command,
                        text=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE
                    )
                    video_ids = [id for id in playlist_result.stdout.strip().split('\n') if id]
                    num_files = len(video_ids)

                    # Get playlist name once (with stderr capture to suppress warnings)
                    playlist_name_cmd = [
                        "yt-dlp",
                        "--user-agent", SYSTEM_USER_AGENT,
                        "--downloader-args", "default:{'external_client':'firefox135'}",
                        "--flat-playlist",
                        "--print", "%(playlist_title)s",
                        url
                    ]
                    if use_cookies:
                        playlist_name_cmd.insert(1, "--cookies-from-browser")
                        playlist_name_cmd.insert(2, "firefox")

                    playlist_name_result = subprocess.run(
                        playlist_name_cmd,
                        text=True,
                        stdout=subprocess.PIPE,
                        stderr=subprocess.PIPE  # Capture stderr to prevent warnings
                    )
                    # Process playlist name from first valid line
                    playlist_name = "Unnamed Playlist"
                    if playlist_name_result.stdout.strip():
                        # Take first non-empty line
                        playlist_name = playlist_name_result.stdout.strip().split('\n')[0].strip()

                    print(f"📦 Playlist name: {playlist_name} ({num_files} videos)")
                    print("🗃️ Files to be downloaded (filenames may be temporarily sanitised):")

                    # Get all filenames upfront
                    for idx, video_id in enumerate(video_ids, 1):
                        video_url = f"https://www.youtube.com/watch?v={video_id}"
                        # Build command with user agent
                        filename_command = [
                            "yt-dlp",
                            "--user-agent", SYSTEM_USER_AGENT,
                            "--downloader-args", "default:{'external_client':'firefox135'}",
                            "--print", "filename",
                            "-o", "%(title)s.%(ext)s",
                            video_url
                        ]
                        if use_cookies:
                            filename_command.insert(1, "--cookies-from-browser")
                            filename_command.insert(2, "firefox")

                        filename_result = subprocess.run(
                            filename_command,
                            text=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE,
                            check=False
                        )
                        if filename_result.stdout.strip():
                            # Remove extension and print filename
                            base_filename = os.path.splitext(filename_result.stdout.strip())[0]
                            print(f"{idx}. {base_filename}")

                    print("─────────────────")

                    # Continue with processing each video, but add delay between them
                    for idx, video_id in enumerate(video_ids, 1):
                        video_url = f"https://www.youtube.com/watch?v={video_id}"
                        processed_file, file_size = process_single_video(
                            self, video_url, audio_only, temp_processing_dir, idx, num_files, resolution, use_mp4, use_cookies
                        )

                        if processed_file:
                            processed_files.append({
                                'name': processed_file,
                                'size': format_size(file_size),
                                'size_bytes': file_size
                            })
                            total_size_bytes += file_size

                    if len(processed_files) > 0:
                        logging.info("✅ Downloads complete 💃🕺")
                else:
                    processed_file, file_size = process_single_video(
                        self, url, audio_only, temp_processing_dir, 1, 1, resolution, use_mp4, use_cookies
                    )

                    if processed_file:
                        processed_files.append({
                            'name': processed_file,
                            'size': format_size(file_size),
                            'size_bytes': file_size
                        })
                        total_size_bytes += file_size

                cleanup_temp_dir(temp_processing_dir)

                elapsed_time = time.time() - start_time
                formatted_time = time.strftime("%H:%M:%S", time.gmtime(elapsed_time))

                if len(processed_files) > 0:
                    print("💥 Download summary")

                    for file_info in processed_files:
                        emoji = "💿" if file_info['name'].endswith('.mp3') else "📺"
                        print(f"{emoji} {file_info['name']} ({file_info['size']})")

                    total_formatted = format_size(total_size_bytes)
                    print(f"📊 Total size: {total_formatted}")
                    print(f"📂 Saved in folder: {DEFAULT_DOWNLOAD_FOLDER}")
                    print("\n😎 Ready\n")

                    self._set_headers(200)
                    response_message = f"Download completed in {formatted_time}\n"
                    self.wfile.write(response_message.encode())
                else:
                    self._set_headers(404)
                    self.wfile.write(b"No files were downloaded")

            except subprocess.CalledProcessError as e:
                self._set_headers(500)
                if "getaddrinfo failed" in str(e) or "network is unreachable" in str(e) or "socket error" in str(e):
                    self.wfile.write(b"Network connection error")
                    logging.error("❌ Network connection error - Please check your internet connection")
                else:
                    self.wfile.write(b"An error occurred while processing the URL")
                    logging.error(f"Error processing URL: {url}. Details: {e}")
            except ConnectionAbortedError:
                logging.info("📡 Connection interrupted - possibly due to network issues")
            except Exception as e:
                self._set_headers(500)
                self.wfile.write(b"An unexpected error occurred")
                logging.error(f"❌ Unexpected error: {str(e)}")

        else:
            self._set_headers(400)
            self.wfile.write(b"No URL provided in the request")
            logging.error("No URL provided in the request.")

    def do_POST(self):
        """
        Handle POST requests.

        Processes folder setting requests, async download requests,
        batch downloads, cancellation, dependency installation,
        and folder opening.
        """
        content_length = int(self.headers.get("Content-Length", 0))
        post_data = self.rfile.read(content_length) if content_length > 0 else b"{}"

        if self.path == "/download":
            # Async download: queue a single URL and return immediately
            try:
                data = json.loads(post_data)
                url = data.get("url", "").strip()
                if not url:
                    self._set_headers(400)
                    self.wfile.write(json.dumps({"error": "No URL provided"}).encode())
                    return

                audio_only = bool(data.get("audioOnly", False))
                resolution = data.get("resolution", MAX_RESOLUTION)
                use_mp4 = bool(data.get("useMP4", USE_MP4))
                use_cookies = bool(data.get("useCookies", USE_BROWSER_COOKIES))

                download_id = str(uuid.uuid4())
                queue_item = {
                    "id": download_id,
                    "url": url,
                    "audio_only": audio_only,
                    "resolution": resolution,
                    "use_mp4": use_mp4,
                    "use_cookies": use_cookies,
                    "status": "pending",
                    "progress": 0.0,
                    "title": "",
                    "file_name": "",
                    "file_size": 0,
                    "error_message": "",
                }

                with download_lock:
                    download_queue.append(queue_item)

                # Start worker thread if not running
                start_worker_if_needed()

                self._set_headers(200, "application/json")
                self.wfile.write(json.dumps({"id": download_id, "status": "queued"}).encode())

            except Exception as e:
                logging.error(f"❌ Error queuing download: {e}")
                self._set_headers(500)
                self.wfile.write(json.dumps({"error": str(e)}).encode())
            return

        elif self.path == "/download-batch":
            # Queue multiple URLs at once
            try:
                data = json.loads(post_data)
                urls = data.get("urls", [])
                if not urls or not isinstance(urls, list):
                    self._set_headers(400)
                    self.wfile.write(json.dumps({"error": "No URLs provided"}).encode())
                    return

                audio_only = bool(data.get("audioOnly", False))
                resolution = data.get("resolution", MAX_RESOLUTION)
                use_mp4 = bool(data.get("useMP4", USE_MP4))
                use_cookies = bool(data.get("useCookies", USE_BROWSER_COOKIES))

                ids = []
                with download_lock:
                    for url in urls:
                        url = url.strip()
                        if not url:
                            continue
                        download_id = str(uuid.uuid4())
                        queue_item = {
                            "id": download_id,
                            "url": url,
                            "audio_only": audio_only,
                            "resolution": resolution,
                            "use_mp4": use_mp4,
                            "use_cookies": use_cookies,
                            "status": "pending",
                            "progress": 0.0,
                            "title": "",
                            "file_name": "",
                            "file_size": 0,
                            "error_message": "",
                        }
                        download_queue.append(queue_item)
                        ids.append(download_id)

                # Start worker thread if not running
                start_worker_if_needed()

                self._set_headers(200, "application/json")
                self.wfile.write(json.dumps({
                    "ids": ids,
                    "status": "queued",
                    "count": len(ids)
                }).encode())

            except Exception as e:
                logging.error(f"❌ Error queuing batch download: {e}")
                self._set_headers(500)
                self.wfile.write(json.dumps({"error": str(e)}).encode())
            return

        elif self.path == "/cancel-download":
            # Cancel current or remove pending download by ID
            try:
                data = json.loads(post_data)
                cancel_id = data.get("id", "")

                cancelled = False
                with download_lock:
                    # Check if it's the active download
                    if download_state["active"] and download_state["id"] == cancel_id:
                        cancel_event.set()
                        cancelled = True
                    else:
                        # Look for it in the queue as pending
                        for q_item in download_queue:
                            if q_item["id"] == cancel_id and q_item["status"] == "pending":
                                q_item["status"] = "cancelled"
                                cancelled = True
                                break

                self._set_headers(200, "application/json")
                self.wfile.write(json.dumps({"cancelled": cancelled}).encode())

            except Exception as e:
                logging.error(f"❌ Error cancelling download: {e}")
                self._set_headers(500)
                self.wfile.write(json.dumps({"error": str(e)}).encode())
            return

        elif self.path == "/install-dependency":
            # Auto-install a dependency
            try:
                data = json.loads(post_data)
                dep_name = data.get("name", "").strip().lower()

                plat_key = get_platform_key()
                plat_commands = INSTALL_COMMANDS.get(plat_key, {})

                if dep_name not in plat_commands:
                    self._set_headers(400)
                    self.wfile.write(json.dumps({
                        "success": False,
                        "output": f"Unsupported dependency '{dep_name}' for platform '{plat_key}'"
                    }).encode())
                    return

                cmd = plat_commands[dep_name]

                # Linux packages (except ytdlp) are resolved at runtime
                if cmd is None and plat_key == "linux":
                    cmd = get_linux_install_cmd(dep_name)
                if cmd is None:
                    self._set_headers(400)
                    self.wfile.write(json.dumps({
                        "success": False,
                        "output": f"No supported package manager found for installing '{dep_name}'"
                    }).encode())
                    return

                # Refuse sudo installs: the server has no way to supply a password.
                if cmd[0] == "sudo":
                    self._set_headers(200, "application/json")
                    self.wfile.write(json.dumps({
                        "success": False,
                        "manual": True,
                        "command": " ".join(cmd),
                        "output": f"Run this command in a terminal: {' '.join(cmd)}"
                    }).encode())
                    return

                print(f"📦 Installing {dep_name}: {' '.join(cmd)}")

                try:
                    result = subprocess.run(
                        cmd,
                        text=True,
                        capture_output=True,
                        timeout=300  # 5 minute timeout for installs
                    )
                    success = result.returncode == 0
                    output = result.stdout + "\n" + result.stderr
                    output = output.strip()

                    if success:
                        print(f"✅ Successfully installed {dep_name}")
                    else:
                        print(f"❌ Failed to install {dep_name}")

                    self._set_headers(200, "application/json")
                    self.wfile.write(json.dumps({
                        "success": success,
                        "output": output
                    }).encode())

                except subprocess.TimeoutExpired:
                    self._set_headers(200, "application/json")
                    self.wfile.write(json.dumps({
                        "success": False,
                        "output": "Installation timed out after 5 minutes"
                    }).encode())
                except FileNotFoundError as fnf:
                    self._set_headers(200, "application/json")
                    self.wfile.write(json.dumps({
                        "success": False,
                        "output": f"Command not found: {fnf}"
                    }).encode())

            except Exception as e:
                logging.error(f"❌ Error installing dependency: {e}")
                self._set_headers(500)
                self.wfile.write(json.dumps({"error": str(e)}).encode())
            return

        elif self.path == "/open-folder":
            # Open download folder in system file manager
            try:
                folder_path = str(DEFAULT_DOWNLOAD_FOLDER)
                system = platform.system()

                if system == "Windows":
                    os.startfile(folder_path)
                elif system == "Darwin":
                    subprocess.Popen(["open", folder_path])
                else:
                    subprocess.Popen(["xdg-open", folder_path])

                self._set_headers(200, "application/json")
                self.wfile.write(json.dumps({"opened": True}).encode())

            except Exception as e:
                logging.error(f"❌ Error opening folder: {e}")
                self._set_headers(500)
                self.wfile.write(json.dumps({"error": str(e)}).encode())
            return

        elif self.path.startswith("/open-file"):
            # Open a downloaded file in its default application.
            # Confined to the configured download folder for safety.
            try:
                query = urllib.parse.urlparse(self.path).query
                params = urllib.parse.parse_qs(query)
                filename = params.get("name", [""])[0]
                target = (DEFAULT_DOWNLOAD_FOLDER / filename).resolve()
                if not str(target).startswith(str(DEFAULT_DOWNLOAD_FOLDER.resolve())):
                    self._set_headers(400)
                    self.wfile.write(json.dumps({"error": "Path outside download folder"}).encode())
                    return
                if not target.exists():
                    self._set_headers(404)
                    self.wfile.write(json.dumps({"error": "File not found"}).encode())
                    return
                system = platform.system()
                if system == "Windows":
                    os.startfile(str(target))
                elif system == "Darwin":
                    subprocess.Popen(["open", str(target)])
                else:
                    subprocess.Popen(["xdg-open", str(target)])
                self._set_headers(200, "application/json")
                self.wfile.write(json.dumps({"opened": True}).encode())

            except Exception as e:
                logging.error(f"❌ Error opening file: {e}")
                self._set_headers(500)
                self.wfile.write(json.dumps({"opened": False, "error": str(e)}).encode())
            return

        elif self.path == "/clear-history":
            try:
                save_history([])
                self._set_headers(200, "application/json")
                self.wfile.write(json.dumps({"cleared": True}).encode())
            except Exception as e:
                logging.error(f"❌ Error clearing history: {e}")
                self._set_headers(500)
                self.wfile.write(json.dumps({"error": str(e)}).encode())
            return

        elif self.path.startswith("/reveal-file"):
            # Open the download folder with the given file selected/highlighted.
            # If the file is missing, fall back to just opening the folder.
            try:
                query = urllib.parse.urlparse(self.path).query
                params = urllib.parse.parse_qs(query)
                filename = params.get("name", [""])[0]
                target = (DEFAULT_DOWNLOAD_FOLDER / filename).resolve() if filename else None
                folder_root = DEFAULT_DOWNLOAD_FOLDER.resolve()
                if target and not str(target).startswith(str(folder_root)):
                    self._set_headers(400)
                    self.wfile.write(json.dumps({"error": "Path outside download folder"}).encode())
                    return

                system = platform.system()
                exists = bool(target and target.exists())

                if not exists:
                    # File gone — open the folder itself.
                    if system == "Windows":
                        os.startfile(str(folder_root))
                    elif system == "Darwin":
                        subprocess.Popen(["open", str(folder_root)])
                    else:
                        subprocess.Popen(["xdg-open", str(folder_root)])
                else:
                    if system == "Windows":
                        # explorer /select,<path> opens the folder with the file selected.
                        subprocess.Popen(["explorer", f"/select,{target}"])
                    elif system == "Darwin":
                        subprocess.Popen(["open", "-R", str(target)])
                    else:
                        # Try the freedesktop D-Bus FileManager1 interface (Nautilus, Dolphin,
                        # Nemo, Files, etc. all implement this). Fall back to xdg-open if not.
                        revealed = False
                        try:
                            file_uri = "file://" + urllib.parse.quote(str(target))
                            r = subprocess.run([
                                "dbus-send",
                                "--print-reply",
                                "--dest=org.freedesktop.FileManager1",
                                "/org/freedesktop/FileManager1",
                                "org.freedesktop.FileManager1.ShowItems",
                                f"array:string:{file_uri}",
                                "string:",
                            ], timeout=3, capture_output=True)
                            revealed = (r.returncode == 0)
                        except Exception:
                            revealed = False
                        if not revealed:
                            subprocess.Popen(["xdg-open", str(target.parent)])

                self._set_headers(200, "application/json")
                self.wfile.write(json.dumps({"revealed": exists}).encode())

            except Exception as e:
                logging.error(f"❌ Error revealing file: {e}")
                self._set_headers(500)
                self.wfile.write(json.dumps({"error": str(e)}).encode())
            return

        elif self.path == "/set-folder":
            try:
                data = json.loads(post_data)
                new_folder = data.get("folder", "").strip()
                # Validate: Ensure it's an absolute path
                if not new_folder or not os.path.isabs(new_folder):
                    self._set_headers(400)
                    self.wfile.write(json.dumps({"message": "❌ Invalid folder path. Please enter a full absolute path."}).encode())
                    logging.error(f"Invalid folder path: {new_folder}")
                    return
                new_folder_path = Path(new_folder)
                # Instead of rejecting, create the folder if it doesn't exist
                new_folder_path.mkdir(parents=True, exist_ok=True)
                # Ensure the folder is writeable
                if not os.access(new_folder_path, os.W_OK):
                    self._set_headers(400)
                    self.wfile.write(json.dumps({"message": "❌ Folder exists but is not writable. Check permissions or disk space."}).encode())
                    logging.error(f"Folder exists but is not writable: {new_folder}")
                    return
                # Folder is in-memory only; the extension persists it client-side.
                _apply_new_folder(Path(new_folder).resolve())
                self._set_headers(200)
                self.wfile.write(json.dumps({"message": "✅ Download folder updated."}).encode())
                logging.info(f"Download folder updated to: {DEFAULT_DOWNLOAD_FOLDER}")
            except Exception as e:
                logging.error(f"Error updating folder: {e}")
                self._set_headers(500)
                self.wfile.write(json.dumps({"message": "❌ Server error while updating folder."}).encode())

        elif self.path == "/set-resolution":
            try:
                data = json.loads(post_data)
                resolution = data.get("resolution", "1080")

                # Update the resolution setting
                set_resolution(resolution)

                res_label = "Best available" if resolution == "best" else f"{resolution}p"
                self._set_headers(200)
                self.wfile.write(json.dumps({"message": f"✅ Max resolution set to: {res_label}"}).encode())

            except Exception as e:
                logging.error(f"Error updating resolution settings: {e}")
                self._set_headers(500)
                self.wfile.write(json.dumps({"message": "❌ Server error while updating resolution."}).encode())

        elif self.path == "/set-limit-to-1080p":
            # Backwards compatibility - convert to new resolution format
            try:
                data = json.loads(post_data)
                limit_enabled = data.get("limitTo1080p", True)

                # Convert boolean to resolution string
                resolution = "1080" if limit_enabled else "best"
                set_resolution(resolution)

                self._set_headers(200)
                self.wfile.write(json.dumps({"message": f"✅ Resolution set to: {resolution}"}).encode())

            except Exception as e:
                logging.error(f"Error updating resolution settings: {e}")
                self._set_headers(500)
                self.wfile.write(json.dumps({"message": "❌ Server error while updating resolution."}).encode())

        elif self.path == "/set-use-mp4":
            try:
                data = json.loads(post_data)
                use_mp4 = data.get("useMP4", False)

                # Update the MP4 format setting
                set_use_mp4(use_mp4)

                self._set_headers(200)
                self.wfile.write(json.dumps({"message": f"✅ MP4 format set to: {'enabled' if use_mp4 else 'disabled'}"}).encode())

            except Exception as e:
                logging.error(f"Error updating MP4 format settings: {e}")
                self._set_headers(500)
                self.wfile.write(json.dumps({"message": "❌ Server error while updating MP4 format setting."}).encode())

        elif self.path == "/set-use-cookies":
            try:
                data = json.loads(post_data)
                use_cookies = data.get("useCookies", True)

                # Update the cookies setting
                set_use_cookies(use_cookies)

                self._set_headers(200)
                self.wfile.write(json.dumps({"message": f"✅ Browser cookies: {'enabled' if use_cookies else 'disabled'}"}).encode())

            except Exception as e:
                logging.error(f"Error updating cookies settings: {e}")
                self._set_headers(500)
                self.wfile.write(json.dumps({"message": "❌ Server error while updating cookies setting."}).encode())

        elif self.path == "/set-filename-template":
            try:
                data = json.loads(post_data)
                template = data.get("template", "%(title)s-%(id)s")

                if set_filename_template(template):
                    self._set_headers(200)
                    self.wfile.write(json.dumps({"message": f"✅ Filename template set to: {template}"}).encode())
                else:
                    self._set_headers(400)
                    self.wfile.write(json.dumps({"message": "❌ Invalid template. Must contain %(title)s or %(id)s."}).encode())

            except Exception as e:
                logging.error(f"Error updating filename template: {e}")
                self._set_headers(500)
                self.wfile.write(json.dumps({"message": "❌ Server error while updating filename template."}).encode())

        else:
            self._set_headers(404)
            self.wfile.write(json.dumps({"error": "Unknown endpoint"}).encode())

def format_size(size_bytes):
    """
    Format bytes as human-readable size.

    Converts raw byte count to a human-readable format in MB or KB.

    Args:
        size_bytes (int): Size in bytes

    Returns:
        str: Formatted size string with units
    """
    size_mb = size_bytes / (1024 * 1024)
    return f"{size_mb:.2f} MB" if size_mb >= 1 else f"{size_bytes / 1024:.2f} KB"

# Check for existing Simple server instances
def check_existing_server(start_port=16868, end_port=16872):
    """Check if a Simple server is already running on any known port."""
    import http.client
    for p in range(start_port, end_port + 1):
        try:
            conn = http.client.HTTPConnection("localhost", p, timeout=1)
            conn.request("GET", "/server-info")
            resp = conn.getresponse()
            if resp.status == 200:
                conn.close()
                return p
        except Exception:
            pass
    return None

def kill_server_on_port(port):
    """Find and kill the process listening on a given port."""
    try:
        if sys.platform == "win32":
            result = subprocess.run(
                ["netstat", "-ano"], capture_output=True, text=True, timeout=5
            )
            for line in result.stdout.splitlines():
                if f":{port}" in line and "LISTENING" in line:
                    pid = line.strip().split()[-1]
                    subprocess.run(["taskkill", "/PID", pid, "/F"],
                                   capture_output=True, timeout=5)
                    print(f"   Stopped old server (PID {pid})")
                    return True
        else:
            result = subprocess.run(
                ["lsof", "-ti", f":{port}"], capture_output=True, text=True, timeout=5
            )
            for pid in result.stdout.strip().splitlines():
                subprocess.run(["kill", pid.strip()], timeout=5)
                print(f"   Stopped old server (PID {pid.strip()})")
                return True
    except Exception:
        pass
    return False

def main():
    """Entry point used by the pip-installed `simple-server` command."""
    existing_port = check_existing_server()
    if existing_port:
        if "--replace" in sys.argv:
            print(f"⚠️  Replacing existing server on port {existing_port}...")
            kill_server_on_port(existing_port)
            time.sleep(0.5)
        else:
            print(f"⚠️  Simple server is already running on port {existing_port}")
            print(f"   Run with --replace to stop it and start fresh:")
            print(f"   simple-server --replace\n")
            sys.exit(1)

    # Always start fresh from DEFAULT_PORT — no longer cached, since persisting
    # it led to the server "drifting" up the port range across restarts and
    # ending up outside the extension's scan window.
    port = find_available_port(DEFAULT_PORT)
    if port != DEFAULT_PORT:
        print(f"⚠ Default port {DEFAULT_PORT} not available, using port {port}")
    else:
        logging.debug(f"✅ Using port {port}")

    server_address = ("", port)
    HTTPServer.allow_reuse_address = True  # tolerate TIME_WAIT across restarts
    httpd = HTTPServer(server_address, BatchRequestHandler)

    print(f"✅ Server running on port {port}")
    print(f"📂 Download folder is: {DEFAULT_DOWNLOAD_FOLDER}")
    print("\n😎 Ready\n")

    httpd.handle_error = handle_connection_error

    try:
        httpd.serve_forever()
    except KeyboardInterrupt:
        print("\n🚀 Downloads cancelled\n")
        print("✨ Run `simple-server` again to keep downloading.\n")
        sys.exit(0)

if __name__ == "__main__":
    main()
