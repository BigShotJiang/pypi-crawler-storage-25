"""Simple — local video downloader server.

The HTTP server that backs the Simple Firefox extension. The console-script
entry point ``simple-server`` resolves to ``main`` here.
"""

from .server import main

__all__ = ["main"]
__version__ = "10.0.0"
