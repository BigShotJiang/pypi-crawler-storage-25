from __future__ import annotations

import tempfile
import unittest
from pathlib import Path

from prompt_toolkit.completion import CompleteEvent
from prompt_toolkit.document import Document

from comate_cli.terminal_agent.mention_completer import LocalFileMentionCompleter


class TestLocalFileMentionCompleter(unittest.TestCase):
    def setUp(self) -> None:
        self._tmpdir = tempfile.TemporaryDirectory()
        self.root = Path(self._tmpdir.name)
        (self.root / "main.py").write_text("print('ok')", encoding="utf-8")
        (self.root / "README.md").write_text("# readme", encoding="utf-8")
        (self.root / "src").mkdir(parents=True, exist_ok=True)
        (self.root / "src" / "main_helper.py").write_text("x = 1", encoding="utf-8")
        self.completer = LocalFileMentionCompleter(self.root, refresh_interval=0.0, limit=200)

    def tearDown(self) -> None:
        self._tmpdir.cleanup()

    def _populate_many_src_directories(self) -> None:
        names = [
            "assistant",
            "bootstrap",
            "bridge",
            "buddy",
            "cli",
            "commands",
            "components",
            "constants",
            "context",
            "coordinator",
            "entrypoints",
            "history",
            "hooks",
            "ink",
            "keybindings",
            "memdir",
            "migrations",
            "moreright",
            "native-ts",
            "outputStyles",
            "plugins",
            "query",
            "remote",
            "schemas",
            "screens",
            "server",
            "services",
            "skills",
            "state",
            "tasks",
            "tools",
            "types",
            "upstreamproxy",
            "utils",
            "vim",
            "voice",
        ]
        for name in names:
            (self.root / "src" / name).mkdir(parents=True, exist_ok=True)

    def test_guard_ignores_email_trigger(self) -> None:
        context = self.completer.extract_context("contact me: foo@example.com")
        self.assertIsNone(context)

    def test_suggest_prefers_basename_prefix_match(self) -> None:
        result = self.completer.suggest("@main", max_items=8)
        self.assertIsNotNone(result)
        assert result is not None
        _, candidates = result
        self.assertTrue(candidates)
        self.assertEqual(candidates[0], "main.py")
        self.assertIn("src/main_helper.py", candidates)

    def test_suggest_returns_none_for_completed_file(self) -> None:
        result = self.completer.suggest("open @main.py")
        self.assertIsNone(result)

    def test_apply_completion_replaces_fragment_and_appends_space(self) -> None:
        original = "open @ma"
        suggest_result = self.completer.suggest(original, max_items=8)
        self.assertIsNotNone(suggest_result)
        assert suggest_result is not None
        context, _ = suggest_result
        new_text, new_cursor = self.completer.apply_completion(
            full_text=original,
            cursor_position=len(original),
            context=context,
            completion="main.py",
            append_space=True,
        )
        self.assertEqual(new_text, "open @main.py ")
        self.assertEqual(new_cursor, len("open @main.py "))

    def test_prompt_toolkit_completion_appends_space_for_files(self) -> None:
        doc = Document(text="open @ma", cursor_position=len("open @ma"))
        event = CompleteEvent(completion_requested=True)
        completions = list(self.completer.get_completions(doc, event))
        self.assertTrue(completions)
        texts = [completion.text for completion in completions]
        self.assertIn("main.py ", texts)

    def test_directory_prefix_completion_is_not_lost_after_large_tree_scan(self) -> None:
        for index in range(1200):
            nested = self.root / "bulk" / f"dir{index}"
            nested.mkdir(parents=True, exist_ok=True)
            (nested / f"file{index}.txt").write_text("x", encoding="utf-8")

        target_dir = self.root / "target" / "sub"
        target_dir.mkdir(parents=True, exist_ok=True)
        (target_dir / "wanted.py").write_text("pass", encoding="utf-8")

        result = self.completer.suggest("@target/", max_items=8)

        self.assertIsNotNone(result)
        assert result is not None
        _, candidates = result
        self.assertIn("target/sub/", candidates)

    def test_existing_directory_prefix_continues_to_suggest_children(self) -> None:
        for index in range(1200):
            nested = self.root / "bulk" / f"dir{index}"
            nested.mkdir(parents=True, exist_ok=True)
            (nested / f"file{index}.txt").write_text("x", encoding="utf-8")

        target_dir = self.root / "target" / "sub"
        target_dir.mkdir(parents=True, exist_ok=True)
        (target_dir / "wanted.py").write_text("pass", encoding="utf-8")

        result = self.completer.suggest("@target/s", max_items=8)

        self.assertIsNotNone(result)
        assert result is not None
        _, candidates = result
        self.assertIn("target/sub/", candidates)

    def test_directory_completion_does_not_truncate_late_entries(self) -> None:
        self._populate_many_src_directories()

        doc = Document(text="@src/", cursor_position=len("@src/"))
        event = CompleteEvent(completion_requested=True)

        completions = list(self.completer.get_completions(doc, event))

        self.assertTrue(completions)
        display_texts = [completion.display_text for completion in completions]
        self.assertIn("src/tools/", display_texts)


if __name__ == "__main__":
    unittest.main(verbosity=2)
