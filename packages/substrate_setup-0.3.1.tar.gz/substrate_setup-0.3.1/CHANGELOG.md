# Changelog

## 0.3.1 — 2026-05-24

- Persist `SUBSTRATE_API_KEY` automatically during `configure`:
  on Windows, writes `HKCU\Environment\SUBSTRATE_API_KEY` via `winreg`
  + `WM_SETTINGCHANGE` broadcast — visible to GUI agents (Codex Desktop)
  on next launch without the user editing rc files or restarting their
  session. On macOS / Linux, appends a marker-fenced `export` block (or
  fish-syntax `set -gx` for fish users) to the user's shell rc. Re-runs
  collapse stale blocks idempotently — the rc never grows on repeated
  configures.
- Codex adapter now prints a one-line Windows Defender exclusion command
  to eliminate SmartScreen prompts on per-action helper binary spawns.
  Informational only — substrate-setup never elevates itself.
- Adapters surface env-persistence failures with a clear `WARNING:`
  prefix + manual fallback hint so users notice when the convenience
  step fails but the config file itself was written successfully.
- Codex adapter drops the stale "/v1/responses NOT YET STARTED" warning
  — Phase 2 shipped on 2026-05-24.
- No config schema changes from 0.3.0. Upgrade cleanly via
  `uv tool install --force substrate-setup` (or pipx).
