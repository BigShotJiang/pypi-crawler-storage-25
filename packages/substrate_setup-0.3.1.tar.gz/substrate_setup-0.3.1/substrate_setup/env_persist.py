"""Persist SUBSTRATE_API_KEY so GUI agents (Codex Desktop, etc.)
see it on next launch without the user manually editing rc files.

Windows: writes HKCU\\Environment\\SUBSTRATE_API_KEY via winreg, then
broadcasts WM_SETTINGCHANGE so Explorer + new processes refresh their
env block immediately (matches what ``setx`` does). User does not need
to log out.

Mac/Linux: appends an ``export SUBSTRATE_API_KEY="..."`` line wrapped
in marker comments to the user's shell rc (zsh > bash > fish detected
in that order). Re-running replaces the existing marker block in
place — no duplicate lines, no clobbering of surrounding content.
The user must ``source`` the rc or open a new terminal for the value
to take effect in CLI agents; GUI agents are unaffected on POSIX
because they don't read shell rc files anyway.

Returns a PersistResult so the caller can print an accurate message
to the user (PERSISTED vs SKIPPED vs ERROR).
"""
from __future__ import annotations

import os
import re
import sys
from dataclasses import dataclass
from enum import Enum
from pathlib import Path

_ENV_VAR = "SUBSTRATE_API_KEY"
_MARKER_OPEN = "# >>> substrate-setup managed >>>"
_MARKER_CLOSE = "# <<< substrate-setup managed <<<"
_MARKER_BLOCK_RE = re.compile(
    rf"{re.escape(_MARKER_OPEN)}.*?{re.escape(_MARKER_CLOSE)}\n?",
    re.DOTALL,
)


class PersistStatus(str, Enum):
    PERSISTED = "persisted"
    SKIPPED = "skipped"
    ERROR = "error"


@dataclass(frozen=True)
class PersistResult:
    status: PersistStatus
    message: str
    path: Path | None  # rc file path (POSIX) or None (Windows registry)


def persist_substrate_api_key(api_key: str) -> PersistResult:
    """Persist SUBSTRATE_API_KEY so future processes inherit it."""
    if sys.platform == "win32":
        return _persist_windows(api_key)
    return _persist_posix(api_key)


def format_persist_message_for_user(result: PersistResult) -> str:
    """Format a PersistResult for end-user display.

    PERSISTED: plain message.
    SKIPPED: prefixed with 'NOTE:' so it stands out from success lines.
    ERROR: prefixed with 'WARNING:' + a one-line manual fallback hint
    so the user knows the config file was written but they need to set
    the env var themselves.
    """
    if result.status is PersistStatus.PERSISTED:
        return f"API key: {result.message}"
    if result.status is PersistStatus.SKIPPED:
        return f"API key NOTE: {result.message}"
    # ERROR
    return (
        f"API key WARNING: {result.message}\n"
        "    The agent config file was written successfully, but the\n"
        "    API key was not persisted. Set SUBSTRATE_API_KEY in your\n"
        "    shell environment manually before launching the agent."
    )


# ── Windows ───────────────────────────────────────────────────────────────

def _persist_windows(api_key: str) -> PersistResult:
    try:
        import winreg  # type: ignore[import-not-found, unused-ignore]
    except ImportError:  # pragma: no cover - only on broken builds
        return PersistResult(
            status=PersistStatus.ERROR,
            message="winreg not available on this Python build.",
            path=None,
        )

    try:
        with winreg.OpenKey(
            winreg.HKEY_CURRENT_USER,
            "Environment",
            0,
            winreg.KEY_SET_VALUE,
        ) as h:
            winreg.SetValueEx(h, _ENV_VAR, 0, winreg.REG_EXPAND_SZ, api_key)
    except OSError as exc:
        return PersistResult(
            status=PersistStatus.ERROR,
            message=f"Failed to write HKCU\\Environment\\{_ENV_VAR}: {exc}",
            path=None,
        )

    _broadcast_setting_change_windows()

    return PersistResult(
        status=PersistStatus.PERSISTED,
        message=(
            f"Persisted {_ENV_VAR} to HKCU\\Environment. "
            "New shells and GUI apps will see it on next launch."
        ),
        path=None,
    )


def _broadcast_setting_change_windows() -> None:
    """SendMessageTimeoutW(HWND_BROADCAST, WM_SETTINGCHANGE, ...) so
    already-running shells refresh their env block. Failures are
    non-fatal — the registry write already succeeded; broadcast just
    speeds up propagation to currently-open windows.
    """
    try:
        import ctypes
        from ctypes import wintypes  # type: ignore[import-not-found, unused-ignore]
    except ImportError:  # pragma: no cover
        return
    HWND_BROADCAST = 0xFFFF
    WM_SETTINGCHANGE = 0x001A
    SMTO_ABORTIFHUNG = 0x0002
    user32 = ctypes.WinDLL("user32", use_last_error=True)
    result = wintypes.DWORD()
    try:
        user32.SendMessageTimeoutW(
            HWND_BROADCAST,
            WM_SETTINGCHANGE,
            0,
            "Environment",
            SMTO_ABORTIFHUNG,
            5000,
            ctypes.byref(result),
        )
    except OSError:
        pass  # broadcast is best-effort


# ── POSIX ─────────────────────────────────────────────────────────────────

def _persist_posix(api_key: str) -> PersistResult:
    rc = _detect_rc_path()
    if rc is None:
        return PersistResult(
            status=PersistStatus.SKIPPED,
            message=(
                "No shell rc file detected (~/.zshrc, ~/.bashrc, "
                "~/.config/fish/config.fish). Set SUBSTRATE_API_KEY "
                "manually in your shell."
            ),
            path=None,
        )

    # Fish uses `set -gx VAR value` instead of bash's `export VAR=value`.
    # Emitting bash syntax into a fish config throws a parser error on
    # every shell start, so pick the right form by the rc file's name.
    if rc.suffix == ".fish":
        export_line = f'set -gx {_ENV_VAR} "{api_key}"'
    else:
        export_line = f'export {_ENV_VAR}="{api_key}"'
    block = f"{_MARKER_OPEN}\n{export_line}\n{_MARKER_CLOSE}\n"

    # Ensure parent dir exists — fish users on a fresh install won't
    # have ~/.config/fish/ yet.
    rc.parent.mkdir(parents=True, exist_ok=True)
    existing = rc.read_text(encoding="utf-8") if rc.exists() else ""

    # Strip ALL existing marker blocks (defensive: a buggy earlier run
    # or hand-editing could leave duplicates) and append exactly one new
    # block. Invariant: exactly one marker block after any call.
    stripped = _MARKER_BLOCK_RE.sub("", existing)
    if stripped and not stripped.endswith("\n"):
        stripped += "\n"
    new_body = stripped + block

    rc.write_text(new_body, encoding="utf-8")

    return PersistResult(
        status=PersistStatus.PERSISTED,
        message=(
            f"Wrote {_ENV_VAR} into {rc}. "
            "`source` it or open a new terminal to pick up the value."
        ),
        path=rc,
    )


def _detect_rc_path() -> Path | None:
    """Return the user's shell rc to write into.

    Order: $ZDOTDIR/.zshrc → ~/.zshrc → ~/.bashrc → ~/.config/fish/config.fish.
    Skips files we have no write access to.

    Pure path-returner — does NOT create directories. The caller
    (``_persist_posix``) is responsible for ensuring the parent dir
    exists before writing.
    """
    candidates: list[Path] = []
    zdotdir = os.environ.get("ZDOTDIR")
    if zdotdir:
        candidates.append(Path(zdotdir) / ".zshrc")
    home = Path.home()
    candidates.extend([
        home / ".zshrc",
        home / ".bashrc",
        home / ".config" / "fish" / "config.fish",
    ])
    for path in candidates:
        if path.exists() and os.access(path, os.W_OK):
            return path
    shell = os.environ.get("SHELL", "")
    if shell.endswith("zsh"):
        return home / ".zshrc"
    if shell.endswith("fish"):
        return home / ".config" / "fish" / "config.fish"
    return home / ".bashrc"
