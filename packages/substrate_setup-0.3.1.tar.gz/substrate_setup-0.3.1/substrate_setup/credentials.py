"""Credential resolution: env > config file > interactive prompt."""
from __future__ import annotations

import os
import re
import sys
from collections.abc import Callable
from getpass import getpass
from pathlib import Path

try:
    import tomllib
except ImportError:  # pragma: no cover - Python <3.11 fallback
    import tomli as tomllib  # type: ignore[no-redef]

KEY_REGEX = re.compile(r"^sk-substrate-[A-Za-z0-9_-]{20,}$")
ENV_VAR = "SUBSTRATE_API_KEY"


def _default_config_path() -> Path:
    if sys.platform == "win32":
        appdata = os.environ.get("APPDATA") or None
        base = Path(appdata) if appdata else Path.home() / "AppData" / "Roaming"
        return base / "substrate-setup" / "credentials.toml"
    xdg = os.environ.get("XDG_CONFIG_HOME")
    base = Path(xdg) if xdg else Path.home() / ".config"
    return base / "substrate-setup" / "credentials.toml"


class CredentialResolutionError(Exception):
    """No API key found in env, config file, or prompt."""


class InvalidKeyFormatError(Exception):
    """The resolved value is not the shape of a Substrate API key."""


def _prompt(question: str) -> str:
    return getpass(question)


def resolve_api_key(
    *,
    config_path: Path | None = None,
    prompt_fn: Callable[[str], str] = _prompt,
) -> str:
    """Resolve a Substrate API key. Validate format. Return it.

    Resolution order: env var → config file → interactive prompt.
    Raises:
      InvalidKeyFormatError: a candidate was found but its shape is wrong.
      CredentialResolutionError: no candidate found at any layer.
    """
    config_path = config_path if config_path is not None else _default_config_path()

    candidate: str | None = os.environ.get(ENV_VAR)
    if not candidate and config_path.exists():
        try:
            payload = tomllib.loads(config_path.read_text(encoding="utf-8"))
        except tomllib.TOMLDecodeError as exc:
            raise CredentialResolutionError(
                f"{config_path} is not valid TOML: {exc}"
            ) from exc
        candidate = payload.get("api_key")
        if candidate is not None and not isinstance(candidate, str):
            raise CredentialResolutionError(
                f"{config_path}: 'api_key' must be a string, "
                f"got {type(candidate).__name__}."
            )
    if not candidate:
        candidate = prompt_fn("Substrate API key (sk-substrate-...): ").strip()
    if not candidate:
        raise CredentialResolutionError(
            "No API key found. Set SUBSTRATE_API_KEY, write "
            f"{config_path}, or paste when prompted."
        )
    if not KEY_REGEX.match(candidate):
        raise InvalidKeyFormatError(
            "That doesn't look like a Substrate API key -- expected "
            "sk-substrate-... followed by at least 20 characters."
        )
    return candidate
