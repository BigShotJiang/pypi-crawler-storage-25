"""Aider integration (0.3.0 — conf.yml + model-metadata sidecar).

Files:
  ~/.aider.conf.yml             — openai-api-base, openai-api-key, model
  ~/.aider.model.metadata.json  — per-model LiteLLM hints (re-added in 0.3.0)

Why metadata.json is back (0.3.0)
---------------------------------
0.2.0 dropped the file because Aider routes everything through one
OpenAI-compatible endpoint and the per-model metadata duplicated info
the gateway already knows. The 0.3.0 multi-agent catalog reverses this:
the file is now used to advertise every chat-capable Substrate model
to Aider so ``--model openai/<id>`` works for any catalog entry without
each user having to memorise the prefix discipline. Keys use the
``openai/<gateway_id>`` form aider's OpenAI-compatible provider
requires. Image-gen catalog entries (``output_modality != "text"``) are
filtered out — Aider only routes chat completions.

Why no `~/.env` (was written by 0.1)
------------------------------------
Aider's docs say the inline ``openai-api-key`` in ``~/.aider.conf.yml``
is the supported way to authenticate against OpenAI-compatible
gateways. Writing a shared ``~/.env`` was an over-reach that risked
clobbering other tools' OPENAI_API_KEY. 0.2.0 dropped the env write.
``remove()`` still strips a substrate-shaped ``OPENAI_API_KEY=`` line
from ``~/.env`` if planted by 0.1 (best-effort legacy cleanup).

Marker discipline
-----------------
Two markers, one per file:

  conf.yml: top-level ``_substrate_setup_managed_keys`` list naming the
    three keys we own (``openai-api-base``, ``openai-api-key``, ``model``).
    Configure/remove refuse to touch the file if absent + user-set values.

  metadata.json: top-level sentinel ``_substrate_setup_managed: true``.
    Configure refuses to overwrite an unmarked file; remove deletes the
    file only if the marker is present. An unmarked file is treated as
    user-owned and left alone.
"""
from __future__ import annotations

import io
import json
import os
import sys
from pathlib import Path
from typing import Any

from ruamel.yaml import YAML

from substrate_setup.agents.base import (
    Agent,
    AgentResult,
    ConfigureContext,
    ResultStatus,
)
from substrate_setup.backup import backup_once
from substrate_setup.env_persist import format_persist_message_for_user, persist_substrate_api_key

MANAGED_KEYS_MARKER = "_substrate_setup_managed_keys"
MANAGED_KEYS: list[str] = ["openai-api-base", "openai-api-key", "model"]

# 0.3.0: ~/.aider.model.metadata.json is now substrate-managed (sidecar
# to ~/.aider.conf.yml). The top-level sentinel below differentiates a
# substrate-written file from a user-authored one.
META_MARKER_KEY = "_substrate_setup_managed"


def _conf_path() -> Path:
    return Path.home() / ".aider.conf.yml"


def _meta_path() -> Path:
    """Path to the Aider model-metadata JSON file (peer of .aider.conf.yml)."""
    return Path.home() / ".aider.model.metadata.json"


def _legacy_env_path() -> Path:
    return Path.home() / ".env"


def _meta_has_marker(meta: dict[str, Any]) -> bool:
    return meta.get(META_MARKER_KEY) is True


def _is_chat_capable(entry: Any) -> bool:
    """True if the catalog entry is a chat model (not image-gen).

    Catalog entries without an explicit ``output_modality`` default to
    ``text`` (chat).
    """
    return getattr(entry, "output_modality", "text") == "text"


def _build_metadata_payload(catalog: list[Any]) -> dict[str, Any]:
    """Build the JSON payload aider reads.

    Keys use the ``openai/<gateway_id>`` form because aider's
    OpenAI-compatible provider always prefixes with ``openai/``. The
    sentinel ``_substrate_setup_managed: true`` carries marker
    discipline so remove() knows the file is ours.
    """
    out: dict[str, Any] = {META_MARKER_KEY: True}
    for entry in catalog:
        if not _is_chat_capable(entry):
            continue
        out[f"openai/{entry.id}"] = {
            "litellm_provider": "openai",
            "mode": "chat",
        }
    return out


def _yaml() -> YAML:
    y = YAML()
    y.preserve_quotes = True
    y.indent(mapping=2, sequence=4, offset=2)
    return y


def _load_yaml(path: Path) -> dict[str, Any]:
    if not path.exists():
        return {}
    result: dict[str, Any] | None = _yaml().load(path.read_text(encoding="utf-8"))
    return result or {}


def _dump_yaml(path: Path, data: dict[str, Any]) -> None:
    buf = io.StringIO()
    _yaml().dump(data, buf)
    path.write_text(buf.getvalue(), encoding="utf-8")
    _restrict_file_mode(path)


def _restrict_file_mode(path: Path) -> None:
    """0600 on POSIX so the inline ``openai-api-key`` isn't world-readable.

    No-op on Windows (file mode bits aren't POSIX-ish there; ACLs already
    default to per-user under %USERPROFILE%).
    """
    if sys.platform == "win32":
        return
    try:
        os.chmod(path, 0o600)
    except OSError:
        pass


def _has_substrate_marker(payload: dict[str, Any]) -> bool:
    marker = payload.get(MANAGED_KEYS_MARKER)
    if not isinstance(marker, list):
        return False
    return set(MANAGED_KEYS).issubset(set(marker))


def _user_has_meaningful_keys(payload: dict[str, Any]) -> bool:
    for k in MANAGED_KEYS:
        v = payload.get(k)
        if isinstance(v, str) and v.strip():
            return True
    return False


def _existing_matches_substrate_shape(
    payload: dict[str, Any], ctx: ConfigureContext
) -> bool:
    """True if existing top-level values look substrate-shaped already.

    Specifically:
      - openai-api-base matches ctx.base_url
      - openai-api-key starts with "sk-substrate-" (the user may have
        rotated keys since, so we don't require an exact match)

    Lets us silently take ownership of configs that were either manually
    configured to match our schema or written by an earlier substrate-setup
    version that didn't drop the marker. Without this auto-claim, every
    user upgrading from 0.1 (or who manually fixed their config) sees a
    refusal ERROR on first 0.2.x run.
    """
    if payload.get("openai-api-base") != ctx.base_url:
        return False
    api_key = payload.get("openai-api-key")
    if not isinstance(api_key, str) or not api_key.startswith("sk-substrate-"):
        return False
    return True


def _pick_default_model(catalog: list[Any]) -> str:
    if not catalog:
        raise ValueError("Cannot pick default model from empty catalog")
    return str(catalog[0].id)


class AiderAgent(Agent):
    name = "aider"
    pretty_name = "Aider"

    def detect(self) -> Path | None:
        conf = _conf_path()
        return conf if conf.exists() else None

    def configure(self, ctx: ConfigureContext) -> AgentResult:
        conf = _conf_path()
        backups: list[Path] = []
        payload = _load_yaml(conf)

        if not _has_substrate_marker(payload) and _user_has_meaningful_keys(payload):
            if _existing_matches_substrate_shape(payload, ctx):
                # Shape already matches us -- silently take ownership.
                # Fall through to the normal write below, which adds the
                # marker and refreshes our 3 keys.
                pass
            else:
                return AgentResult(
                    ResultStatus.ERROR,
                    "Aider ~/.aider.conf.yml has user-owned openai-api-base / "
                    "openai-api-key / model keys but no substrate-setup marker; "
                    "refused to overwrite. To take over, remove those keys (or "
                    "the whole file) and re-run substrate-setup.",
                )

        if conf.exists():
            backup = backup_once(conf)
            if backup is not None:
                backups.append(backup)

        payload["openai-api-base"] = ctx.base_url
        payload["openai-api-key"] = ctx.api_key
        payload["model"] = _pick_default_model(ctx.catalog)
        payload[MANAGED_KEYS_MARKER] = list(MANAGED_KEYS)

        if not ctx.dry_run:
            _dump_yaml(conf, payload)

        # Write the model-metadata sidecar file. If a user-owned file
        # already exists (no marker), refuse to clobber it — same
        # refusal pattern as the conf.yml block above.
        meta_path = _meta_path()
        if meta_path.exists():
            try:
                existing_meta = json.loads(meta_path.read_text(encoding="utf-8"))
            except json.JSONDecodeError:
                existing_meta = {}
            if not isinstance(existing_meta, dict):
                existing_meta = {}
            if not _meta_has_marker(existing_meta):
                return AgentResult(
                    ResultStatus.ERROR,
                    f"Aider {meta_path} exists but is not substrate-managed; "
                    "refused to overwrite. Delete the file or add "
                    f"`{META_MARKER_KEY}: true` at the top to take over.",
                    tuple(backups),
                )
            backup = backup_once(meta_path)
            if backup is not None:
                backups.append(backup)
        new_meta = _build_metadata_payload(ctx.catalog)
        if not ctx.dry_run:
            meta_path.write_text(
                json.dumps(new_meta, indent=2) + "\n", encoding="utf-8"
            )
            _restrict_file_mode(meta_path)

        persist_result = persist_substrate_api_key(ctx.api_key)
        print(format_persist_message_for_user(persist_result))

        return AgentResult(
            ResultStatus.SUCCESS,
            f"Wrote openai-api-base + openai-api-key + model into {conf}.",
            tuple(backups),
        )

    def verify(self, ctx: ConfigureContext) -> AgentResult:
        conf = _conf_path()
        if not conf.exists():
            return AgentResult(ResultStatus.ERROR, "Aider conf.yml does not exist")
        payload = _load_yaml(conf)
        if not _has_substrate_marker(payload):
            return AgentResult(
                ResultStatus.ERROR,
                "Aider ~/.aider.conf.yml is not managed by substrate-setup "
                "(marker missing)",
            )

        problems: list[str] = []
        if payload.get("openai-api-base") != ctx.base_url:
            problems.append(
                f"openai-api-base: expected {ctx.base_url!r}, "
                f"got {payload.get('openai-api-base')!r}"
            )
        expected_model = _pick_default_model(ctx.catalog)
        if payload.get("model") != expected_model:
            problems.append(
                f"model: expected {expected_model!r}, got {payload.get('model')!r}"
            )
        api_key = payload.get("openai-api-key")
        if not isinstance(api_key, str) or len(api_key) < 20:
            problems.append("openai-api-key: missing or implausibly short")

        if problems:
            return AgentResult(ResultStatus.ERROR, "; ".join(problems))
        return AgentResult(ResultStatus.SUCCESS, "in sync")

    def remove(self, ctx: ConfigureContext) -> AgentResult:
        conf = _conf_path()
        if not conf.exists():
            # Still try to clean up legacy artifacts even if conf.yml is gone.
            cleaned_legacy = self._clean_legacy(ctx)
            if cleaned_legacy:
                return AgentResult(
                    ResultStatus.SUCCESS,
                    "Removed legacy Aider artifacts (~/.aider.model.metadata.json / ~/.env)",
                    (),
                )
            return AgentResult(ResultStatus.SKIPPED, "Aider not configured")

        payload = _load_yaml(conf)
        if not _has_substrate_marker(payload):
            return AgentResult(
                ResultStatus.SKIPPED,
                "Aider ~/.aider.conf.yml is not managed by substrate-setup; "
                "refusing to delete keys we don't own",
            )

        backups: list[Path] = []
        backup = backup_once(conf)
        if backup is not None:
            backups.append(backup)

        for k in MANAGED_KEYS:
            payload.pop(k, None)
        payload.pop(MANAGED_KEYS_MARKER, None)

        if not ctx.dry_run:
            _dump_yaml(conf, payload)

        # Drop the model-metadata sidecar if it's ours.
        meta_path = _meta_path()
        if meta_path.exists():
            try:
                existing_meta = json.loads(meta_path.read_text(encoding="utf-8"))
            except json.JSONDecodeError:
                existing_meta = {}
            if isinstance(existing_meta, dict) and _meta_has_marker(existing_meta):
                if not ctx.dry_run:
                    meta_path.unlink()
            # If no marker (user-owned), leave it alone.

        # Also clean up legacy artifacts written by 0.1 (best-effort).
        self._clean_legacy(ctx, backups=backups)

        return AgentResult(
            ResultStatus.SUCCESS,
            f"Removed substrate-managed keys from {conf}",
            tuple(backups),
        )

    @staticmethod
    def _clean_legacy(
        ctx: ConfigureContext, *, backups: list[Path] | None = None
    ) -> bool:
        """Strip substrate entries from ~/.env (0.1 legacy).

        ~/.aider.model.metadata.json is no longer treated as legacy in
        0.3.0 — it's a substrate-managed sidecar with its own marker
        discipline handled directly in configure()/remove(). This
        helper now covers only the ~/.env case.
        """
        if backups is None:
            backups = []
        did_something = False

        # ~/.env: strip the OPENAI_API_KEY line if its value starts with "sk-substrate-".
        legacy_env = _legacy_env_path()
        if legacy_env.exists():
            lines = legacy_env.read_text(encoding="utf-8").splitlines()
            kept: list[str] = []
            stripped = False
            for line in lines:
                if line.startswith("OPENAI_API_KEY="):
                    value = line.split("=", 1)[1]
                    if value.startswith("sk-substrate-"):
                        stripped = True
                        continue
                kept.append(line)
            if stripped:
                backup = backup_once(legacy_env)
                if backup is not None:
                    backups.append(backup)
                if not ctx.dry_run:
                    legacy_env.write_text(
                        "\n".join(kept) + ("\n" if kept else ""), encoding="utf-8"
                    )
                did_something = True

        return did_something
