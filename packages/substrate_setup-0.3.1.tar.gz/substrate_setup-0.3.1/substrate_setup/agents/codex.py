"""Codex CLI integration.

Codex reads its config from ``~/.codex/config.toml``. We write:

  - top-level ``model = "<default>"``
  - top-level ``model_provider = "substrate"``
  - ``[model_providers.substrate]`` block with name, base_url,
    env_key = "SUBSTRATE_API_KEY", and wire_api = "responses"
    (the ``"chat"`` variant was removed from codex-rs).

Codex's /model slash-command picker is hardcoded to OpenAI's lineup
(gpt-5.5, gpt-5.4-mini, ...) and not externally extensible. To use
other Substrate models the user passes ``codex --model openai/gpt-5.5``
(or any chat-capable catalog id).

Marker discipline:
  TOML libraries drop in-block comments on round-trip; only the
  file-leading comment survives because we re-prepend it on write.
  The marker is the literal comment ``# substrate-setup-managed: ...``
  at line 1 of the file. verify() and remove() parse the raw text to
  check the marker, not the parsed TOML.

Auth:
  The block writes ``env_key = "SUBSTRATE_API_KEY"`` so Codex reads
  the key from that env var. configure() calls persist_substrate_api_key()
  to write the value into HKCU\\Environment (Windows) or the user's shell
  rc (POSIX) so GUI launches and new terminals pick it up automatically.

Gateway dependency:
  Codex talks ``wire_api = "responses"`` (OpenAI Responses API),
  which lives at /v1/responses on the Substrate gateway. That endpoint
  shipped in gateway protocol adapters Phase 2 (2026-05-24) and is live.
"""
from __future__ import annotations

import os
import re
import shutil
import sys
from pathlib import Path
from typing import Any

import tomli_w

try:
    import tomllib
except ImportError:  # pragma: no cover — Python <3.11 fallback
    import tomli as tomllib  # type: ignore[no-redef]

from substrate_setup.agents.base import (
    Agent,
    AgentResult,
    ConfigureContext,
    ResultStatus,
)
from substrate_setup.backup import backup_once
from substrate_setup.env_persist import format_persist_message_for_user, persist_substrate_api_key

PROVIDER_KEY = "substrate"
ENV_KEY_NAME = "SUBSTRATE_API_KEY"
WIRE_API = "responses"

MARKER_PREFIX = "# substrate-setup-managed:"
MARKER_TOKENS = "model, model_provider, model_providers.substrate"
MARKER_COMMENT = f"{MARKER_PREFIX} {MARKER_TOKENS}"
MARKER_COMMENT_PATTERN = re.compile(
    rf"^{re.escape(MARKER_PREFIX)}\s+{re.escape(MARKER_TOKENS)}\s*$"
)


def _codex_dir() -> Path:
    return Path.home() / ".codex"


def _config_path() -> Path:
    return _codex_dir() / "config.toml"


def _load_toml(path: Path) -> tuple[dict[str, Any] | None, AgentResult | None]:
    if not path.exists():
        return {}, None
    try:
        data = tomllib.loads(path.read_text(encoding="utf-8"))
    except tomllib.TOMLDecodeError as exc:
        return None, AgentResult(
            ResultStatus.ERROR,
            f"Codex {path} is not valid TOML: {exc}. Fix the file and "
            "re-run.",
        )
    return data, None


def _has_marker_comment(text: str) -> bool:
    if not text:
        return False
    first = text.splitlines()[0]
    return MARKER_COMMENT_PATTERN.match(first) is not None


def _existing_substrate_block_matches(
    data: dict[str, Any], ctx: ConfigureContext
) -> bool:
    """Auto-claim heuristic for an existing [model_providers.substrate] block."""
    if data.get("model_provider") != PROVIDER_KEY:
        return False
    providers = data.get("model_providers")
    if not isinstance(providers, dict):
        return False
    block = providers.get(PROVIDER_KEY)
    if not isinstance(block, dict):
        return False
    if block.get("base_url") != ctx.base_url:
        return False
    if block.get("env_key") != ENV_KEY_NAME:
        return False
    if block.get("wire_api") != WIRE_API:
        return False
    return True


def _chat_capable(catalog: list[Any]) -> list[Any]:
    return [e for e in catalog if e.output_modality == "text"]


def _restrict_file_mode(path: Path) -> None:
    if sys.platform == "win32":
        return
    try:
        os.chmod(path, 0o600)
    except OSError:
        pass


class CodexAgent(Agent):
    name = "codex"
    pretty_name = "Codex"

    def detect(self) -> Path | None:
        cfg = _config_path()
        if cfg.exists():
            return cfg
        if _codex_dir().exists():
            return _codex_dir()
        binary = shutil.which("codex")
        if binary:
            return Path(binary)
        return None

    def configure(self, ctx: ConfigureContext) -> AgentResult:
        codex_dir = _codex_dir()
        codex_dir.mkdir(parents=True, exist_ok=True)

        cfg_path = _config_path()
        backups: list[Path] = []
        notes: list[str] = []

        data, err = _load_toml(cfg_path)
        if err is not None:
            return err
        assert data is not None

        existing_text = (
            cfg_path.read_text(encoding="utf-8") if cfg_path.exists() else ""
        )
        if not _has_marker_comment(existing_text):
            providers = data.get("model_providers")
            existing_substrate = (
                providers.get(PROVIDER_KEY)
                if isinstance(providers, dict)
                else None
            )
            if isinstance(existing_substrate, dict):
                if _existing_substrate_block_matches(data, ctx):
                    notes.append(
                        "Codex config.toml had a substrate-shaped block but "
                        "no marker; auto-claiming ownership."
                    )
                else:
                    return AgentResult(
                        ResultStatus.ERROR,
                        "Codex config.toml has a [model_providers.substrate] "
                        "block but no substrate-setup marker; refused to "
                        "overwrite. To take over, delete that block (or its "
                        "base_url/wire_api keys) and re-run substrate-setup.",
                        tuple(backups),
                    )

        if cfg_path.exists():
            backup = backup_once(cfg_path)
            if backup is not None:
                backups.append(backup)

        chat_models = _chat_capable(ctx.catalog)
        if not chat_models:
            return AgentResult(
                ResultStatus.ERROR,
                "Cannot configure Codex with an empty chat-model catalog.",
                tuple(backups),
            )
        default_model = chat_models[0].id

        data["model"] = default_model
        data["model_provider"] = PROVIDER_KEY
        providers = data.get("model_providers")
        if not isinstance(providers, dict):
            providers = {}
        providers[PROVIDER_KEY] = {
            "name": "Substrate Solutions",
            "base_url": ctx.base_url,
            "env_key": ENV_KEY_NAME,
            "wire_api": WIRE_API,
        }
        data["model_providers"] = providers

        if not ctx.dry_run:
            body = tomli_w.dumps(data)
            cfg_path.write_text(f"{MARKER_COMMENT}\n{body}", encoding="utf-8")
            _restrict_file_mode(cfg_path)

        persist_result = persist_substrate_api_key(ctx.api_key)
        bullets = "\n".join(f"     - {m.id}" for m in chat_models)
        print(
            "Codex configured to use the Substrate gateway.\n"
            "\n"
            f"  Default model: {default_model}\n"
            "  The /model picker stays gpt-5.5/5.4-mini/... (built-in).\n"
            "  To use any other Substrate model, pass --model on the CLI:\n"
            "\n"
            "      codex --model openai/gpt-5.5 \"...\"\n"
            "\n"
            "  Available chat-capable Substrate models:\n"
            f"{bullets}\n"
            "\n"
            f"  NOTE: Codex reaches Substrate via /v1/responses. That endpoint\n"
            f"  is live on the Substrate gateway (Phase 2, shipped 2026-05-24).\n"
            "\n"
            f"  {format_persist_message_for_user(persist_result)}"
        )

        if sys.platform == "win32":
            print(
                "\n"
                "  NOTE: Windows Defender SmartScreen may prompt every time you\n"
                "  interact with Codex Desktop. One-time fix — open an\n"
                "  Administrator PowerShell window and run:\n"
                "\n"
                '      Add-MpPreference -ExclusionPath "$env:LOCALAPPDATA\\OpenAI\\Codex"\n'
                "\n"
                "  This excludes the Codex install directory from real-time\n"
                "  scanning. Reverse with: Remove-MpPreference -ExclusionPath ..."
            )

        msg = (
            f"Wrote [model_providers.{PROVIDER_KEY}] + model + "
            f"model_provider into {cfg_path}."
        )
        if notes:
            msg += "\n" + "\n".join(notes)
        return AgentResult(ResultStatus.SUCCESS, msg, tuple(backups))

    def verify(self, ctx: ConfigureContext) -> AgentResult:
        cfg_path = _config_path()
        if not cfg_path.exists():
            return AgentResult(
                ResultStatus.ERROR, "Codex config.toml does not exist"
            )
        text = cfg_path.read_text(encoding="utf-8")
        if not _has_marker_comment(text):
            return AgentResult(
                ResultStatus.ERROR,
                "Codex config.toml is not managed by substrate-setup "
                "(marker comment missing on line 1)",
            )

        data, err = _load_toml(cfg_path)
        if err is not None:
            return err
        assert data is not None

        chat_models = _chat_capable(ctx.catalog)
        expected_default = chat_models[0].id if chat_models else None

        problems: list[str] = []
        if data.get("model") != expected_default:
            problems.append(
                f"model: expected {expected_default!r}, got {data.get('model')!r}"
            )
        if data.get("model_provider") != PROVIDER_KEY:
            problems.append(
                f"model_provider: expected {PROVIDER_KEY!r}, got "
                f"{data.get('model_provider')!r}"
            )
        providers = data.get("model_providers") or {}
        block = providers.get(PROVIDER_KEY) or {}
        if block.get("base_url") != ctx.base_url:
            problems.append(
                f"model_providers.{PROVIDER_KEY}.base_url: expected "
                f"{ctx.base_url!r}, got {block.get('base_url')!r}"
            )
        if block.get("wire_api") != WIRE_API:
            problems.append(
                f"model_providers.{PROVIDER_KEY}.wire_api: expected "
                f"{WIRE_API!r}, got {block.get('wire_api')!r}"
            )

        if problems:
            return AgentResult(ResultStatus.ERROR, "; ".join(problems))
        return AgentResult(ResultStatus.SUCCESS, "in sync")

    def remove(self, ctx: ConfigureContext) -> AgentResult:
        cfg_path = _config_path()
        if not cfg_path.exists():
            return AgentResult(
                ResultStatus.SKIPPED, "Codex not configured"
            )
        text = cfg_path.read_text(encoding="utf-8")
        if not _has_marker_comment(text):
            return AgentResult(
                ResultStatus.SKIPPED,
                "Codex config.toml is not managed by substrate-setup; "
                "refusing to delete blocks we don't own",
            )

        data, err = _load_toml(cfg_path)
        if err is not None:
            return err
        assert data is not None

        backups: list[Path] = []
        backup = backup_once(cfg_path)
        if backup is not None:
            backups.append(backup)

        if data.get("model_provider") == PROVIDER_KEY:
            data.pop("model_provider", None)
            data.pop("model", None)
        providers = data.get("model_providers")
        if isinstance(providers, dict):
            providers.pop(PROVIDER_KEY, None)
            if providers:
                data["model_providers"] = providers
            else:
                data.pop("model_providers", None)

        if not ctx.dry_run:
            if data:
                body = tomli_w.dumps(data)
                cfg_path.write_text(body, encoding="utf-8")
            else:
                cfg_path.write_text("", encoding="utf-8")
            _restrict_file_mode(cfg_path)

        return AgentResult(
            ResultStatus.SUCCESS,
            f"Removed substrate-managed entries from {cfg_path}",
            tuple(backups),
        )
