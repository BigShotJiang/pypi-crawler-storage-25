"""Continue (VS Code / JetBrains extension) integration.

0.2.0 writes only ``~/.continue/config.yaml``. The legacy
``~/.continue/config.json`` is migrated: if it exists but config.yaml
doesn't, we read the JSON, copy the user's ``models`` array over, back
up the JSON to ``config.json.substrate-bak-<ts>``, and write fresh YAML.

Fresh config.yaml carries the required top-level fields the Continue
upstream config schema needs:

  name: substrate-setup
  version: 0.0.1
  schema: v1
  models: [...]

Each substrate-managed model entry:

  - name: "<model_id>"
    provider: openai
    apiBase: "<base_url>"
    apiKey: "<api_key>"
    model: "<model_id>"
    roles: [chat, edit, apply, summarize]
    _substrate_managed: true

The ``_substrate_managed: true`` marker is per-entry (Continue's
``models`` is a list of dicts, so each dict can carry its own marker
without colliding with user state).
"""
from __future__ import annotations

import io
import json
import os
import sys
import time
from pathlib import Path
from typing import Any

from ruamel.yaml import YAML

from substrate_setup.agents.base import (
    Agent,
    AgentResult,
    ConfigureContext,
    ResultStatus,
)
from substrate_setup.backup import backup_once
from substrate_setup.env_persist import format_persist_message_for_user, persist_substrate_api_key
from substrate_setup.catalog import CatalogEntry
from substrate_setup.markers import MARKER_KEY, MARKER_VALUE, is_substrate_managed

CONFIG_NAME = "substrate-setup"
CONFIG_VERSION = "0.0.1"
CONFIG_SCHEMA = "v1"
DEFAULT_ROLES = ["chat", "edit", "apply", "summarize"]


def _dir() -> Path:
    return Path.home() / ".continue"


def _yaml_path() -> Path:
    return _dir() / "config.yaml"


def _json_path() -> Path:
    return _dir() / "config.json"


def _yaml() -> YAML:
    y = YAML()
    y.preserve_quotes = True
    y.indent(mapping=2, sequence=4, offset=2)
    return y


def _load_yaml(path: Path) -> dict[str, Any]:
    if not path.exists():
        return {}
    result: dict[str, Any] | None = _yaml().load(path.read_text(encoding="utf-8"))
    return result or {}


def _dump_yaml(path: Path, data: dict[str, Any]) -> None:
    buf = io.StringIO()
    _yaml().dump(data, buf)
    path.write_text(buf.getvalue(), encoding="utf-8")
    _restrict_file_mode(path)


def _restrict_file_mode(path: Path) -> None:
    """0600 on POSIX so per-model inline ``apiKey`` values aren't world-readable.

    No-op on Windows (file mode bits aren't POSIX-ish there; ACLs already
    default to per-user under %USERPROFILE%).
    """
    if sys.platform == "win32":
        return
    try:
        os.chmod(path, 0o600)
    except OSError:
        pass


def _load_json(path: Path) -> dict[str, Any]:
    if not path.exists():
        return {}
    result: dict[str, Any] = json.loads(path.read_text(encoding="utf-8"))
    return result


def _model_entry(ctx: ConfigureContext, catalog_id: str) -> dict[str, Any]:
    return {
        "name": catalog_id,
        "provider": "openai",   # OpenAI-compatible gateway
        "model": catalog_id,
        "apiBase": ctx.base_url,
        "apiKey": ctx.api_key,
        "roles": list(DEFAULT_ROLES),
        MARKER_KEY: MARKER_VALUE,
    }


def _merge_models(
    existing: list[dict[str, Any]],
    catalog: list[CatalogEntry],
    ctx: ConfigureContext,
) -> list[dict[str, Any]]:
    """Marker-respecting merge.

    - Preserve user-authored entries (no marker).
    - Replace substrate-managed entries to match the current catalog (live path).
    - On fallback path, keep existing substrate-managed entries even if absent
      from the (potentially stale) catalog.
    """
    user_entries = [e for e in existing if not is_substrate_managed(e)]
    existing_substrate_ids = {
        e.get("model") for e in existing if is_substrate_managed(e)
    }
    catalog_ids = {entry.id for entry in catalog}

    chat_catalog = [
        entry for entry in catalog
        if getattr(entry, "output_modality", "text") == "text"
    ]
    fresh_entries = [_model_entry(ctx, entry.id) for entry in chat_catalog]

    if ctx.catalog_source == "fallback":
        kept_ids = existing_substrate_ids - catalog_ids
        for old in existing:
            if is_substrate_managed(old) and old.get("model") in kept_ids:
                fresh_entries.append(old)

    return user_entries + fresh_entries


def _ensure_required_top_level(payload: dict[str, Any]) -> dict[str, Any]:
    """Make sure name/version/schema are set; populate from defaults if missing."""
    payload.setdefault("name", CONFIG_NAME)
    payload.setdefault("version", CONFIG_VERSION)
    payload.setdefault("schema", CONFIG_SCHEMA)
    return payload


def _migrate_legacy_json(json_path: Path, yaml_path: Path) -> list[Path]:
    """Migrate config.json → config.yaml. Returns the list of backup paths created.

    Strategy:
      - Read JSON.
      - Copy its ``models`` array (and any other top-level keys) onto a fresh
        YAML payload with the required ``name``/``version``/``schema`` fields.
      - Write YAML.
      - Backup JSON to ``config.json.substrate-bak-<ts>``.
    """
    backups: list[Path] = []
    legacy = _load_json(json_path)

    # Carry over the user's data wholesale. We'll fill in required fields below.
    yaml_payload: dict[str, Any] = dict(legacy)
    _ensure_required_top_level(yaml_payload)
    yaml_payload.setdefault("models", [])
    # Leave a breadcrumb so future readers know what happened.
    yaml_payload["_substrate_migration_note"] = (
        "migrated from config.json by substrate-setup"
    )

    # Back up the legacy file. Use a stable suffix so detect/cleanup logic can
    # find it if needed.
    ts = int(time.time())
    backup_path = json_path.parent / f"{json_path.name}.substrate-bak-{ts}"
    backup_path.write_text(json_path.read_text(encoding="utf-8"), encoding="utf-8")
    backups.append(backup_path)

    yaml_path.parent.mkdir(parents=True, exist_ok=True)
    _dump_yaml(yaml_path, yaml_payload)

    return backups


class ContinueAgent(Agent):
    name = "continue"
    pretty_name = "Continue"

    def detect(self) -> Path | None:
        if _yaml_path().exists():
            return _yaml_path()
        if _json_path().exists():
            # Continue is installed (legacy JSON); the configure() call will
            # migrate it to YAML.
            return _yaml_path()
        return None

    def configure(self, ctx: ConfigureContext) -> AgentResult:
        _dir().mkdir(parents=True, exist_ok=True)
        backups: list[Path] = []
        notes: list[str] = []

        # ── migration: only-JSON → write YAML and back up JSON ───────
        if _json_path().exists() and not _yaml_path().exists():
            migration_backups = _migrate_legacy_json(_json_path(), _yaml_path())
            backups.extend(migration_backups)
            notes.append(
                "Migrated legacy ~/.continue/config.json to config.yaml "
                f"(backup: {migration_backups[0].name})."
            )

        yaml_path = _yaml_path()
        if yaml_path.exists():
            backup = backup_once(yaml_path)
            if backup is not None:
                backups.append(backup)

        payload = _load_yaml(yaml_path)
        payload = _ensure_required_top_level(payload)

        existing_models = payload.get("models") or []
        merged = _merge_models(existing_models, ctx.catalog, ctx)
        payload["models"] = merged

        if not ctx.dry_run:
            _dump_yaml(yaml_path, payload)

        persist_result = persist_substrate_api_key(ctx.api_key)
        print(format_persist_message_for_user(persist_result))

        msg = f"{len(ctx.catalog)} models written, API base + key set in {yaml_path}."
        if notes:
            msg = "\n".join(notes) + "\n" + msg
        return AgentResult(ResultStatus.SUCCESS, msg, tuple(backups))

    def verify(self, ctx: ConfigureContext) -> AgentResult:
        if not _yaml_path().exists():
            return AgentResult(ResultStatus.ERROR, "Continue config.yaml not present")
        payload = _load_yaml(_yaml_path())
        substrate_ids = {
            m.get("model") for m in (payload.get("models") or [])
            if is_substrate_managed(m)
        }
        catalog_ids = {e.id for e in ctx.catalog}
        missing = catalog_ids - substrate_ids
        stale = substrate_ids - catalog_ids
        if missing or stale:
            parts = []
            if missing:
                parts.append(f"missing: {sorted(missing)}")
            if stale:
                parts.append(f"stale: {sorted(stale)}")
            return AgentResult(ResultStatus.ERROR, "; ".join(parts))
        return AgentResult(ResultStatus.SUCCESS, "in sync")

    def remove(self, ctx: ConfigureContext) -> AgentResult:
        if not _yaml_path().exists():
            return AgentResult(ResultStatus.SKIPPED, "Continue not installed")
        backup = backup_once(_yaml_path())
        payload = _load_yaml(_yaml_path())
        payload["models"] = [
            m for m in (payload.get("models") or []) if not is_substrate_managed(m)
        ]
        if not ctx.dry_run:
            _dump_yaml(_yaml_path(), payload)
        return AgentResult(
            ResultStatus.SUCCESS,
            "Removed substrate model entries from Continue",
            (backup,) if backup else (),
        )
