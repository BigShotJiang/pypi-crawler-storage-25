"""Hermes Agent CLI integration.

Hermes is NousResearch/hermes-agent. Its config file is a single YAML
that has an inline `model:` block — provider routing lives in that
block, NOT in a `custom_providers:` list. The `custom_providers:`
section (when present) only carries per-provider overrides; Hermes does
not consume it for routing.

Schema (verified against upstream `cli-config.yaml.example` and Frank's
live ``%LOCALAPPDATA%/hermes/config.yaml``):

    model:
      default:  "<model-id>"                     # which model to use
      provider: "custom"                         # tells Hermes to use base_url + api_key below
      api_key:  "sk-substrate-..."               # inline credential
      base_url: "https://substrate-solutions-api.fly.dev/v1"
      # user-owned keys (context_length, max_tokens, reasoning_effort, …) survive

Why no `.env` write (0.2.0):
  Earlier versions also wrote ``~/.hermes/.env`` with SUBSTRATE_API_KEY.
  Frank verified inline ``model.api_key`` works on the live deployment,
  so we now only write the YAML. A user who already had a working .env
  setup is unaffected — Hermes prefers env vars over the inline key.

Config location:
  Windows: ``%LOCALAPPDATA%\\hermes\\config.yaml``
           (i.e. ``C:\\Users\\<user>\\AppData\\Local\\hermes\\config.yaml``)
  Unix:    ``~/.hermes/config.yaml``

Marker discipline:
  Because we share the inline ``model:`` block with the user (we don't
  own a separate namespace), the standard ``_substrate_managed: True``
  marker inside ``model:`` would be awkward. Instead, we write a single
  top-level key:

      _substrate_setup_managed_keys:
        - "model.default"
        - "model.provider"
        - "model.api_key"
        - "model.base_url"

  This is the authoritative list of keys substrate-setup owns. If the
  marker is missing from the file, the adapter refuses to overwrite a
  user-owned ``model:`` block (it can't tell what's safe to clobber).
"""
from __future__ import annotations

import io
import os
import shutil
import sys
from pathlib import Path
from typing import Any

from ruamel.yaml import YAML
from ruamel.yaml.error import YAMLError

from substrate_setup.agents.base import (
    Agent,
    AgentResult,
    ConfigureContext,
    ResultStatus,
)
from substrate_setup.backup import backup_once
from substrate_setup.env_persist import format_persist_message_for_user, persist_substrate_api_key

# Top-level marker key listing the model.* keys substrate-setup owns.
MANAGED_KEYS_MARKER = "_substrate_setup_managed_keys"

# Authoritative list of dotted keys substrate-setup owns inside the YAML.
# Must match the values written by configure() and stripped by remove().
MANAGED_KEYS: list[str] = [
    "model.default",
    "model.provider",
    "model.api_key",
    "model.base_url",
    "model_catalog.providers.substrate.url",
]


def _windows_config_path() -> Path | None:
    """Return %LOCALAPPDATA%\\hermes\\config.yaml on Windows, else None."""
    local_appdata = os.environ.get("LOCALAPPDATA")
    if local_appdata:
        return Path(local_appdata) / "hermes" / "config.yaml"
    return None


def _unix_config_path() -> Path:
    return Path.home() / ".hermes" / "config.yaml"


def _candidate_config_paths() -> list[Path]:
    """Resolution order: prefer the platform-native install, fall back to ~/.hermes."""
    paths: list[Path] = []
    if sys.platform == "win32":
        win = _windows_config_path()
        if win is not None:
            paths.append(win)
    paths.append(_unix_config_path())
    return paths


def _resolved_config_path() -> Path:
    """Pick the first existing config; if none exist, choose where to *write*.

    Write-target rule: on Windows, prefer %LOCALAPPDATA%\\hermes\\config.yaml
    (matches what installing hermes does). On Unix, ~/.hermes/config.yaml.
    """
    for path in _candidate_config_paths():
        if path.exists():
            return path
    # No existing file — pick the platform-preferred write target.
    return _candidate_config_paths()[0]


# Files that, when sitting next to each other, identify a Hermes source
# checkout. Both must be present — either alone is not specific enough.
# `hermes_bootstrap.py` is the package entry shim that lives only in the
# upstream repo; `cli-config.yaml.example` is the canonical config template
# tracked under hermes-agent/.
_HERMES_SOURCE_SIGNATURE: tuple[str, ...] = (
    "cli-config.yaml.example",
    "hermes_bootstrap.py",
)


def _is_hermes_source_checkout(directory: Path) -> bool:
    return all((directory / fname).is_file() for fname in _HERMES_SOURCE_SIGNATURE)


def _find_hermes_source_from(start: Path) -> Path | None:
    """Walk up from ``start`` looking for a Hermes source checkout.

    Lets the user run ``substrate-setup configure`` from any subdirectory
    of their cloned ``hermes-agent`` repo (e.g., ``~/Desktop/Hermes/agent``).
    """
    if _is_hermes_source_checkout(start):
        return start
    for parent in start.parents:
        if _is_hermes_source_checkout(parent):
            return parent
    return None


def _yaml() -> YAML:
    y = YAML()
    y.preserve_quotes = True
    y.indent(mapping=2, sequence=4, offset=2)
    return y


def _load_yaml(path: Path) -> dict[str, Any]:
    """Raises YAMLError on malformed input; callers handle via _load_or_error."""
    if not path.exists():
        return {}
    text = path.read_text(encoding="utf-8")
    result: dict[str, Any] | None = _yaml().load(text)
    return result or {}


def _load_or_error(path: Path) -> tuple[dict[str, Any] | None, AgentResult | None]:
    """Load YAML, returning an AgentResult.ERROR on parse failure so the CLI
    surfaces a one-liner instead of a stacktrace. Frank's own dogfood
    config (and many user-edited Hermes configs) can drift into invalid
    YAML; we must not crash the whole run on Hermes alone.
    """
    try:
        return _load_yaml(path), None
    except YAMLError as exc:
        # Keep the message single-line and actionable.
        first_line = str(exc).splitlines()[0] if str(exc) else type(exc).__name__
        return None, AgentResult(
            ResultStatus.ERROR,
            f"Hermes config at {path} is not valid YAML: {first_line}. "
            "Fix the file and re-run, or pass `--agents-only` to skip hermes.",
        )


def _dump_yaml(path: Path, data: dict[str, Any]) -> None:
    buf = io.StringIO()
    _yaml().dump(data, buf)
    path.write_text(buf.getvalue(), encoding="utf-8")
    _restrict_file_mode(path)


def _restrict_file_mode(path: Path) -> None:
    """Set 0600 on POSIX so an inline API key isn't world-readable.

    No-op on Windows (chmod doesn't model POSIX bits there; ACLs already
    default to per-user under %USERPROFILE%).
    """
    if sys.platform == "win32":
        return
    try:
        os.chmod(path, 0o600)
    except OSError:
        # Read-only filesystem, exotic mount — not worth failing configure over.
        pass


def _pick_default_model_id(catalog: list[Any]) -> str:
    """Pick the catalog entry to write into model.default.

    All entries in our catalog are chat-capable today. Pick the first.
    """
    if not catalog:
        raise ValueError("Cannot pick default model from empty catalog")
    return str(catalog[0].id)


def _catalog_url_for(gateway_base_url: str) -> str:
    """Derive the Hermes catalog URL from the gateway base URL.

    Example: ``https://substrate-solutions-api.fly.dev/v1`` →
    ``https://substrate-solutions-api.fly.dev/v1/agent-catalogs/hermes.json``.
    Strips any trailing slash on the base URL for canonical formatting.
    """
    return f"{gateway_base_url.rstrip('/')}/agent-catalogs/hermes.json"


# The four model.* keys written since 0.1; any config we ever wrote has these.
# Used as the minimum presence check so that configs written by older versions
# (which don't yet carry the model_catalog.* key) are still claimed as ours.
_CORE_MODEL_KEYS: frozenset[str] = frozenset(
    [
        "model.default",
        "model.provider",
        "model.api_key",
        "model.base_url",
    ]
)


def _has_substrate_marker(payload: dict[str, Any]) -> bool:
    marker = payload.get(MANAGED_KEYS_MARKER)
    if not isinstance(marker, list):
        return False
    # Accept configs written by any version: a valid marker contains at least
    # the four original model.* keys (the 5th key was added in 0.3.0).
    return _CORE_MODEL_KEYS.issubset(set(marker))


def _user_has_meaningful_model_block(payload: dict[str, Any]) -> bool:
    """True if model: has any of our 4 keys set to a non-empty value."""
    model = payload.get("model") or {}
    if not isinstance(model, dict):
        return False
    for short_key in ("default", "provider", "api_key", "base_url"):
        v = model.get(short_key)
        if isinstance(v, str) and v.strip():
            return True
    return False


def _existing_matches_substrate_shape(
    model: dict[str, Any], ctx: ConfigureContext
) -> bool:
    """True if existing model.* values look substrate-shaped already.

    Specifically:
      - provider == "custom"
      - base_url matches ctx.base_url
      - api_key starts with "sk-substrate-" (we don't require exact match --
        the user may have rotated keys since)

    This lets us silently take ownership of configs that were either
    manually configured to match our schema or written by an earlier
    substrate-setup version that didn't drop the marker. Without this
    auto-claim, every user upgrading from 0.1 (or who manually fixed
    their config) sees a refusal ERROR on first 0.2.x run.
    """
    if model.get("provider") != "custom":
        return False
    if model.get("base_url") != ctx.base_url:
        return False
    api_key = model.get("api_key")
    if not isinstance(api_key, str) or not api_key.startswith("sk-substrate-"):
        return False
    return True


class HermesAgent(Agent):
    name = "hermes"
    pretty_name = "Hermes"

    def detect(self) -> Path | None:
        """Return a Path identifying *something* that proves Hermes is on the
        machine, or None.

        Resolution order, widest-to-narrowest:
          1. Existing runtime config (``~/.hermes/config.yaml`` or its
             Windows %LOCALAPPDATA% variant). Strongest signal — Hermes has
             actually been run at least once.
          2. ``hermes`` binary on PATH (pipx / brew / setup-hermes.sh
             install — agent is usable but never run, so no runtime config
             yet). Returns the resolved binary path.
          3. Current working directory (or any ancestor) is a Hermes source
             checkout — the user is sitting inside a cloned ``hermes-agent``
             repo. Returns the checkout root.

        For 2 and 3, ``configure()`` will create the runtime config at the
        platform-preferred write target; Hermes reads that on first run.
        """
        for path in _candidate_config_paths():
            if path.exists():
                return path
        binary = shutil.which("hermes")
        if binary:
            return Path(binary)
        return _find_hermes_source_from(Path.cwd())

    def configure(self, ctx: ConfigureContext) -> AgentResult:
        cfg_path = _resolved_config_path()
        cfg_path.parent.mkdir(parents=True, exist_ok=True)
        backups: list[Path] = []
        notes: list[str] = []

        payload, err = _load_or_error(cfg_path)
        if err is not None:
            return err
        assert payload is not None

        # Marker absent: decide between auto-claim (shape already looks like
        # ours — safe to take ownership) and refusal (truly user-owned).
        if not _has_substrate_marker(payload):
            existing_model = payload.get("model") or {}
            if not isinstance(existing_model, dict):
                existing_model = {}
            if _user_has_meaningful_model_block(payload):
                if _existing_matches_substrate_shape(existing_model, ctx):
                    notes.append(
                        "Hermes config.yaml had substrate-shaped keys but no "
                        "marker; auto-claiming ownership."
                    )
                    # fall through to normal write (which adds the marker)
                else:
                    return AgentResult(
                        ResultStatus.ERROR,
                        "Hermes config.yaml has a user-owned `model:` block "
                        "but no substrate-setup marker; refused to overwrite. "
                        "To take over, delete the existing `model:` block "
                        "(or its provider/api_key/base_url keys) and re-run "
                        "substrate-setup.",
                        tuple(backups),
                    )

        if cfg_path.exists():
            backup = backup_once(cfg_path)
            if backup is not None:
                backups.append(backup)

        # Mutate ONLY our 4 keys under model:; preserve everything else.
        model: dict[str, Any] = payload.get("model") or {}
        if not isinstance(model, dict):
            # Defensive: someone wrote a scalar/list at `model:` — overwrite
            # with a fresh dict only if no marker present we'd have caught above.
            model = {}
        model["default"] = _pick_default_model_id(ctx.catalog)
        model["provider"] = "custom"
        model["api_key"] = ctx.api_key
        model["base_url"] = ctx.base_url
        payload["model"] = model

        # Point Hermes' catalog logic at Substrate's manifest endpoint.
        # Hermes resolves model_catalog.providers.<name>.url at runtime
        # (TTL-cached for 24h by default) and surfaces the listed models
        # in its /model picker.
        catalog_url = _catalog_url_for(ctx.base_url)
        model_catalog = payload.get("model_catalog") or {}
        if not isinstance(model_catalog, dict):
            model_catalog = {}
        providers = model_catalog.get("providers") or {}
        if not isinstance(providers, dict):
            providers = {}
        substrate_entry = providers.get("substrate") or {}
        if not isinstance(substrate_entry, dict):
            substrate_entry = {}
        substrate_entry["url"] = catalog_url
        providers["substrate"] = substrate_entry
        model_catalog["providers"] = providers
        payload["model_catalog"] = model_catalog

        # Write/refresh the marker.
        payload[MANAGED_KEYS_MARKER] = list(MANAGED_KEYS)

        if not ctx.dry_run:
            _dump_yaml(cfg_path, payload)

        persist_result = persist_substrate_api_key(ctx.api_key)
        print(format_persist_message_for_user(persist_result))

        msg = (
            f"Wrote model.{{default,provider,api_key,base_url}} into "
            f"{cfg_path}."
        )
        if notes:
            msg += "\n" + "\n".join(notes)
        return AgentResult(ResultStatus.SUCCESS, msg, tuple(backups))

    def verify(self, ctx: ConfigureContext) -> AgentResult:
        # detect() now also returns truthy for binary-on-PATH / source-checkout
        # cases where the runtime config has not been generated yet. verify
        # cares specifically about that config file, so resolve it directly.
        cfg_path = _resolved_config_path()
        if not cfg_path.exists():
            return AgentResult(
                ResultStatus.ERROR, "Hermes config.yaml does not exist"
            )
        payload, err = _load_or_error(cfg_path)
        if err is not None:
            return err
        assert payload is not None
        if not _has_substrate_marker(payload):
            return AgentResult(
                ResultStatus.ERROR,
                "Hermes config.yaml is not managed by substrate-setup "
                "(marker `_substrate_setup_managed_keys` missing)",
            )
        model = payload.get("model") or {}
        if not isinstance(model, dict):
            return AgentResult(
                ResultStatus.ERROR, "Hermes `model:` block is malformed"
            )

        problems: list[str] = []
        expected_default = _pick_default_model_id(ctx.catalog)
        if model.get("default") != expected_default:
            problems.append(
                f"model.default: expected {expected_default!r}, "
                f"got {model.get('default')!r}"
            )
        if model.get("provider") != "custom":
            problems.append(
                f"model.provider: expected 'custom', got {model.get('provider')!r}"
            )
        if model.get("base_url") != ctx.base_url:
            problems.append(
                f"model.base_url: expected {ctx.base_url!r}, "
                f"got {model.get('base_url')!r}"
            )
        # api_key is sensitive — compare length only (user may have rotated).
        api_key = model.get("api_key")
        if not isinstance(api_key, str) or len(api_key) < 20:
            problems.append("model.api_key: missing or implausibly short")

        if problems:
            return AgentResult(ResultStatus.ERROR, "; ".join(problems))
        return AgentResult(ResultStatus.SUCCESS, "in sync")

    def remove(self, ctx: ConfigureContext) -> AgentResult:
        # Same reasoning as verify(): detect() may now return a binary or
        # source-checkout path; remove only operates on the runtime config.
        cfg_path = _resolved_config_path()
        if not cfg_path.exists():
            return AgentResult(ResultStatus.SKIPPED, "Hermes not configured")
        payload, err = _load_or_error(cfg_path)
        if err is not None:
            return err
        assert payload is not None
        if not _has_substrate_marker(payload):
            return AgentResult(
                ResultStatus.SKIPPED,
                "Hermes config.yaml is not managed by substrate-setup; "
                "refusing to delete keys we don't own",
            )

        backups: list[Path] = []
        backup = backup_once(cfg_path)
        if backup is not None:
            backups.append(backup)

        # Delete only the 4 model.* keys we own; preserve other model keys.
        model = payload.get("model") or {}
        if isinstance(model, dict):
            for short_key in ("default", "provider", "api_key", "base_url"):
                model.pop(short_key, None)
            if model:
                payload["model"] = model
            else:
                payload.pop("model", None)

        # Strip our entry from model_catalog.providers; preserve any user
        # entries the user may have added under the same parent.
        model_catalog = payload.get("model_catalog") or {}
        if isinstance(model_catalog, dict):
            providers = model_catalog.get("providers") or {}
            if isinstance(providers, dict):
                providers.pop("substrate", None)
                if providers:
                    model_catalog["providers"] = providers
                else:
                    model_catalog.pop("providers", None)
            if model_catalog:
                payload["model_catalog"] = model_catalog
            else:
                payload.pop("model_catalog", None)

        payload.pop(MANAGED_KEYS_MARKER, None)

        if not ctx.dry_run:
            _dump_yaml(cfg_path, payload)

        return AgentResult(
            ResultStatus.SUCCESS,
            f"Removed substrate-managed keys from {cfg_path}",
            tuple(backups),
        )
