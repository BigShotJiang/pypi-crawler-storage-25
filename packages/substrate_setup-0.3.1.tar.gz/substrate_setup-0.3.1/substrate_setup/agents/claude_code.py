"""Claude Code (Anthropic) integration.

Claude Code reads its config from ``~/.claude/settings.json``. We
merge three env keys into the ``env:`` block:

  - ANTHROPIC_BASE_URL — Substrate gateway, WITHOUT /v1 suffix
    (Claude Code appends /v1/messages itself)
  - ANTHROPIC_AUTH_TOKEN — Substrate API key
  - ANTHROPIC_MODEL — default model for chat sessions

Claude Code's /model slash-command picker is hardcoded
(opus/sonnet/haiku) and not externally extensible. To use other
Substrate models the user passes ``claude --model openai/gpt-5.5``
(or any chat-capable catalog id) on the command line. configure()
prints a walkthrough listing the available model ids.

Marker discipline:
  Because we share settings.json with other Claude Code config
  (skill registry, hooks, theme, etc.), we use a dedicated top-level
  list ``_substrate_setup_managed_env_keys`` enumerating which env
  keys we own. The settings.json itself never gets deleted — even
  when remove() runs.

Gateway dependency:
  Claude Code reaches Substrate via /v1/messages. The route was
  merged in gateway protocol adapters Phase 1 (PR #57) and is
  mounted behind the ``GATEWAY_PROTOCOL_ADAPTERS_ENABLED`` Fly
  secret. Until that flag is flipped, requests return 404 — the
  walkthrough below tells the user this so they're not surprised.
"""
from __future__ import annotations

import json
import os
import shutil
import sys
from pathlib import Path
from typing import Any

from substrate_setup.agents.base import (
    Agent,
    AgentResult,
    ConfigureContext,
    ResultStatus,
)
from substrate_setup.backup import backup_once
from substrate_setup.env_persist import format_persist_message_for_user, persist_substrate_api_key

MANAGED_ENV_KEYS_MARKER = "_substrate_setup_managed_env_keys"
MANAGED_ENV_KEYS: list[str] = [
    "ANTHROPIC_BASE_URL",
    "ANTHROPIC_AUTH_TOKEN",
    "ANTHROPIC_MODEL",
]


def _claude_dir() -> Path:
    return Path.home() / ".claude"


def _settings_path() -> Path:
    return _claude_dir() / "settings.json"


def _strip_v1_suffix(base_url: str) -> str:
    """Claude Code appends /v1/messages itself.

    The Substrate gateway base is `https://...fly.dev/v1`; Hermes/Aider/
    Continue.dev want the `/v1` in their base URL (they hit
    `/v1/chat/completions`); Claude Code does NOT. Strip a trailing `/v1`
    (and any trailing slash) if present.
    """
    trimmed = base_url.rstrip("/")
    if trimmed.endswith("/v1"):
        return trimmed[: -len("/v1")]
    return trimmed


def _load_settings(path: Path) -> tuple[dict[str, Any] | None, AgentResult | None]:
    if not path.exists():
        return {}, None
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
    except json.JSONDecodeError as exc:
        return None, AgentResult(
            ResultStatus.ERROR,
            f"Claude Code {path} is not valid JSON: {exc.msg} at "
            f"line {exc.lineno}. Fix the file and re-run.",
        )
    if not isinstance(data, dict):
        return None, AgentResult(
            ResultStatus.ERROR,
            f"Claude Code {path} root is not an object; refused to merge.",
        )
    return data, None


def _has_managed_marker(payload: dict[str, Any]) -> bool:
    marker = payload.get(MANAGED_ENV_KEYS_MARKER)
    if not isinstance(marker, list):
        return False
    return set(MANAGED_ENV_KEYS).issubset(set(marker))


def _user_owns_anthropic_env(env_block: dict[str, Any]) -> bool:
    for key in MANAGED_ENV_KEYS:
        v = env_block.get(key)
        if isinstance(v, str) and v.strip():
            return True
    return False


def _existing_matches_substrate_shape(
    env_block: dict[str, Any], ctx: ConfigureContext
) -> bool:
    """Auto-claim heuristic for an existing config."""
    expected_base = _strip_v1_suffix(ctx.base_url)
    if env_block.get("ANTHROPIC_BASE_URL") != expected_base:
        return False
    token = env_block.get("ANTHROPIC_AUTH_TOKEN")
    if not isinstance(token, str) or not token.startswith("sk-substrate-"):
        return False
    return True


def _chat_capable(catalog: list[Any]) -> list[Any]:
    return [e for e in catalog if e.output_modality == "text"]


def _restrict_file_mode(path: Path) -> None:
    if sys.platform == "win32":
        return
    try:
        os.chmod(path, 0o600)
    except OSError:
        pass


class ClaudeCodeAgent(Agent):
    name = "claude-code"
    pretty_name = "Claude Code"

    def detect(self) -> Path | None:
        """Three layered signals:
          1. settings.json present (strongest)
          2. ~/.claude/ directory present (Claude Code ran at least once)
          3. `claude` binary on PATH (pipx install, never run)
        """
        settings = _settings_path()
        if settings.exists():
            return settings
        claude_dir = _claude_dir()
        if claude_dir.exists():
            return claude_dir
        binary = shutil.which("claude")
        if binary:
            return Path(binary)
        return None

    def configure(self, ctx: ConfigureContext) -> AgentResult:
        claude_dir = _claude_dir()
        claude_dir.mkdir(parents=True, exist_ok=True)

        settings_path = _settings_path()
        backups: list[Path] = []
        notes: list[str] = []

        payload, err = _load_settings(settings_path)
        if err is not None:
            return err
        assert payload is not None

        env_block = payload.get("env") or {}
        if not isinstance(env_block, dict):
            env_block = {}

        if not _has_managed_marker(payload):
            if _user_owns_anthropic_env(env_block):
                if _existing_matches_substrate_shape(env_block, ctx):
                    notes.append(
                        "Claude Code settings.json had substrate-shaped env "
                        "keys but no marker; auto-claiming ownership."
                    )
                else:
                    return AgentResult(
                        ResultStatus.ERROR,
                        "Claude Code settings.json has user-owned ANTHROPIC_* "
                        "env keys but no substrate-setup marker; refused to "
                        "overwrite. To take over, delete those keys from "
                        "settings.json and re-run substrate-setup.",
                        tuple(backups),
                    )

        if settings_path.exists():
            backup = backup_once(settings_path)
            if backup is not None:
                backups.append(backup)

        chat_models = _chat_capable(ctx.catalog)
        if not chat_models:
            return AgentResult(
                ResultStatus.ERROR,
                "Cannot configure Claude Code with an empty chat-model "
                "catalog.",
                tuple(backups),
            )
        default_model = chat_models[0].id

        env_block["ANTHROPIC_BASE_URL"] = _strip_v1_suffix(ctx.base_url)
        env_block["ANTHROPIC_AUTH_TOKEN"] = ctx.api_key
        env_block["ANTHROPIC_MODEL"] = default_model
        payload["env"] = env_block

        payload[MANAGED_ENV_KEYS_MARKER] = list(MANAGED_ENV_KEYS)

        if not ctx.dry_run:
            settings_path.write_text(
                json.dumps(payload, indent=2) + "\n", encoding="utf-8"
            )
            _restrict_file_mode(settings_path)

        persist_result = persist_substrate_api_key(ctx.api_key)
        bullets = "\n".join(f"     - {m.id}" for m in chat_models)
        print(
            "Claude Code configured to use the Substrate gateway.\n"
            "\n"
            f"  Default model: {default_model}\n"
            "  The /model slash command stays opus/sonnet/haiku (built-in).\n"
            "  To use any other Substrate model, pass --model on the CLI:\n"
            "\n"
            "      claude --model openai/gpt-5.5 \"...\"\n"
            "\n"
            "  Available chat-capable Substrate models:\n"
            f"{bullets}\n"
            "\n"
            "  NOTE: Claude Code reaches Substrate via /v1/messages. The route\n"
            "  was added in gateway protocol adapters Phase 1 (PR #57) and is\n"
            "  mounted behind a Fly feature flag — until that flag is flipped\n"
            "  on, requests return 404.\n"
            "\n"
            f"  {format_persist_message_for_user(persist_result)}"
        )

        msg = f"Wrote {','.join(MANAGED_ENV_KEYS)} into {settings_path}."
        if notes:
            msg += "\n" + "\n".join(notes)
        return AgentResult(ResultStatus.SUCCESS, msg, tuple(backups))

    def verify(self, ctx: ConfigureContext) -> AgentResult:
        settings_path = _settings_path()
        if not settings_path.exists():
            return AgentResult(
                ResultStatus.ERROR,
                "Claude Code settings.json does not exist",
            )
        payload, err = _load_settings(settings_path)
        if err is not None:
            return err
        assert payload is not None

        if not _has_managed_marker(payload):
            return AgentResult(
                ResultStatus.ERROR,
                "Claude Code settings.json is not managed by substrate-setup "
                f"(marker `{MANAGED_ENV_KEYS_MARKER}` missing or incomplete)",
            )

        env_block = payload.get("env") or {}
        if not isinstance(env_block, dict):
            return AgentResult(
                ResultStatus.ERROR,
                "Claude Code env block is malformed",
            )

        problems: list[str] = []
        expected_base = _strip_v1_suffix(ctx.base_url)
        if env_block.get("ANTHROPIC_BASE_URL") != expected_base:
            problems.append(
                f"ANTHROPIC_BASE_URL: expected {expected_base!r}, "
                f"got {env_block.get('ANTHROPIC_BASE_URL')!r}"
            )
        token = env_block.get("ANTHROPIC_AUTH_TOKEN")
        if not isinstance(token, str) or len(token) < 20:
            problems.append(
                "ANTHROPIC_AUTH_TOKEN: missing or implausibly short"
            )
        chat_models = _chat_capable(ctx.catalog)
        expected_default = chat_models[0].id if chat_models else None
        if env_block.get("ANTHROPIC_MODEL") != expected_default:
            problems.append(
                f"ANTHROPIC_MODEL: expected {expected_default!r}, "
                f"got {env_block.get('ANTHROPIC_MODEL')!r}"
            )

        if problems:
            return AgentResult(ResultStatus.ERROR, "; ".join(problems))
        return AgentResult(ResultStatus.SUCCESS, "in sync")

    def remove(self, ctx: ConfigureContext) -> AgentResult:
        settings_path = _settings_path()
        if not settings_path.exists():
            return AgentResult(
                ResultStatus.SKIPPED, "Claude Code not configured"
            )
        payload, err = _load_settings(settings_path)
        if err is not None:
            return err
        assert payload is not None

        if not _has_managed_marker(payload):
            return AgentResult(
                ResultStatus.SKIPPED,
                "Claude Code settings.json is not managed by substrate-setup; "
                "refusing to delete keys we don't own",
            )

        backups: list[Path] = []
        backup = backup_once(settings_path)
        if backup is not None:
            backups.append(backup)

        env_block = payload.get("env") or {}
        if isinstance(env_block, dict):
            for key in MANAGED_ENV_KEYS:
                env_block.pop(key, None)
            if env_block:
                payload["env"] = env_block
            else:
                payload.pop("env", None)

        payload.pop(MANAGED_ENV_KEYS_MARKER, None)

        if not ctx.dry_run:
            settings_path.write_text(
                json.dumps(payload, indent=2) + "\n", encoding="utf-8"
            )
            _restrict_file_mode(settings_path)

        return AgentResult(
            ResultStatus.SUCCESS,
            f"Removed substrate-managed env keys from {settings_path}",
            tuple(backups),
        )
