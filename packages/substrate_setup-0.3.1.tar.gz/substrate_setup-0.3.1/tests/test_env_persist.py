"""Unit tests for env_persist."""
from __future__ import annotations

import sys
from pathlib import Path

import pytest
from substrate_setup.env_persist import (
    PersistResult,
    PersistStatus,
    format_persist_message_for_user,
    persist_substrate_api_key,
)

# ── Windows path ──────────────────────────────────────────────────────────

@pytest.mark.skipif(sys.platform != "win32", reason="Windows-only path")
def test_windows_persists_to_hkcu_environment(monkeypatch: pytest.MonkeyPatch) -> None:
    """Writes HKCU\\Environment\\SUBSTRATE_API_KEY and broadcasts WM_SETTINGCHANGE."""
    import winreg  # type: ignore[import-not-found]

    test_key = "sk-substrate-TESTKEYA-" + "0" * 40
    try:
        result = persist_substrate_api_key(test_key)
        assert result.status == PersistStatus.PERSISTED
        with winreg.OpenKey(winreg.HKEY_CURRENT_USER, "Environment") as h:
            value, _ = winreg.QueryValueEx(h, "SUBSTRATE_API_KEY")
        assert value == test_key
    finally:
        try:
            with winreg.OpenKey(
                winreg.HKEY_CURRENT_USER, "Environment", 0, winreg.KEY_SET_VALUE
            ) as h:
                winreg.DeleteValue(h, "SUBSTRATE_API_KEY")
        except OSError:
            pass


# ── Mac/Linux path ────────────────────────────────────────────────────────

@pytest.mark.skipif(sys.platform == "win32", reason="POSIX shell-rc path")
def test_posix_appends_export_when_rc_does_not_have_marker(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    rc = tmp_path / ".zshrc"
    rc.write_text("# preexisting user content\nalias ll='ls -al'\n", encoding="utf-8")
    monkeypatch.setattr("substrate_setup.env_persist._detect_rc_path", lambda: rc)

    result = persist_substrate_api_key("sk-substrate-AAAAAAAA-" + "0" * 40)

    assert result.status == PersistStatus.PERSISTED
    body = rc.read_text(encoding="utf-8")
    assert "# preexisting user content" in body
    assert "# >>> substrate-setup managed >>>" in body
    assert 'export SUBSTRATE_API_KEY="sk-substrate-AAAAAAAA-' in body
    assert "# <<< substrate-setup managed <<<" in body


@pytest.mark.skipif(sys.platform == "win32", reason="POSIX shell-rc path")
def test_posix_replaces_existing_marker_block(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    rc = tmp_path / ".zshrc"
    rc.write_text(
        "# preexisting\n"
        "# >>> substrate-setup managed >>>\n"
        'export SUBSTRATE_API_KEY="sk-substrate-OLDKEYAA-' + "0" * 40 + '"\n'
        "# <<< substrate-setup managed <<<\n"
        "# after block\n",
        encoding="utf-8",
    )
    monkeypatch.setattr("substrate_setup.env_persist._detect_rc_path", lambda: rc)

    new_key = "sk-substrate-NEWKEYAA-" + "0" * 40
    result = persist_substrate_api_key(new_key)

    assert result.status == PersistStatus.PERSISTED
    body = rc.read_text(encoding="utf-8")
    assert body.count("# >>> substrate-setup managed >>>") == 1
    assert new_key in body
    assert "OLDKEYAA" not in body
    assert "# preexisting" in body and "# after block" in body


@pytest.mark.skipif(sys.platform == "win32", reason="POSIX shell-rc path")
def test_posix_collapses_two_stale_marker_blocks_into_one(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    """Two stale marker blocks (from a buggy earlier run) must collapse
    to exactly one after persist runs."""
    rc = tmp_path / ".zshrc"
    rc.write_text(
        "# preexisting\n"
        "# >>> substrate-setup managed >>>\n"
        'export SUBSTRATE_API_KEY="sk-substrate-STALEAAA-' + "0" * 40 + '"\n'
        "# <<< substrate-setup managed <<<\n"
        "# middle content\n"
        "# >>> substrate-setup managed >>>\n"
        'export SUBSTRATE_API_KEY="sk-substrate-STALEBBB-' + "0" * 40 + '"\n'
        "# <<< substrate-setup managed <<<\n"
        "# tail\n",
        encoding="utf-8",
    )
    monkeypatch.setattr("substrate_setup.env_persist._detect_rc_path", lambda: rc)

    new_key = "sk-substrate-NEWKEYAA-" + "0" * 40
    result = persist_substrate_api_key(new_key)

    assert result.status == PersistStatus.PERSISTED
    body = rc.read_text(encoding="utf-8")
    assert body.count("# >>> substrate-setup managed >>>") == 1
    assert body.count("# <<< substrate-setup managed <<<") == 1
    assert new_key in body
    assert "STALEAAA" not in body and "STALEBBB" not in body
    assert "# preexisting" in body
    assert "# middle content" in body
    assert "# tail" in body


@pytest.mark.skipif(sys.platform == "win32", reason="POSIX shell-rc path")
def test_posix_writes_fish_syntax_for_fish_config(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    """Fish config files get `set -gx`, not `export`."""
    fish_dir = tmp_path / ".config" / "fish"
    fish_dir.mkdir(parents=True)
    rc = fish_dir / "config.fish"
    rc.write_text("# user content\n", encoding="utf-8")
    monkeypatch.setattr("substrate_setup.env_persist._detect_rc_path", lambda: rc)

    result = persist_substrate_api_key("sk-substrate-FISHAAAA-" + "0" * 40)

    assert result.status == PersistStatus.PERSISTED
    body = rc.read_text(encoding="utf-8")
    assert "set -gx SUBSTRATE_API_KEY" in body
    assert 'export SUBSTRATE_API_KEY="' not in body


@pytest.mark.skipif(sys.platform == "win32", reason="POSIX shell-rc path")
def test_posix_returns_skipped_when_no_rc_found(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    monkeypatch.setattr("substrate_setup.env_persist._detect_rc_path", lambda: None)
    result = persist_substrate_api_key("sk-substrate-XXXXXXXX-" + "0" * 40)
    assert result.status == PersistStatus.SKIPPED
    assert "no shell rc" in result.message.lower()


# ── Cross-platform contract ───────────────────────────────────────────────

def test_persistresult_is_dataclass_with_status_and_message() -> None:
    r = PersistResult(status=PersistStatus.PERSISTED, message="ok", path=None)
    assert r.status is PersistStatus.PERSISTED
    assert r.message == "ok"
    assert r.path is None


# ── format_persist_message_for_user ──────────────────────────────────────

def test_format_persist_message_for_user_persisted() -> None:
    r = PersistResult(status=PersistStatus.PERSISTED, message="ok msg", path=None)
    out = format_persist_message_for_user(r)
    assert out == "API key: ok msg"
    assert "WARNING" not in out and "NOTE" not in out


def test_format_persist_message_for_user_skipped() -> None:
    r = PersistResult(status=PersistStatus.SKIPPED, message="no rc", path=None)
    out = format_persist_message_for_user(r)
    assert out.startswith("API key NOTE:")
    assert "no rc" in out


def test_format_persist_message_for_user_error() -> None:
    r = PersistResult(status=PersistStatus.ERROR, message="winreg blew up", path=None)
    out = format_persist_message_for_user(r)
    assert out.startswith("API key WARNING:")
    assert "winreg blew up" in out
    assert "manually" in out.lower()
    assert "config file was written successfully" in out.lower()
