"""pytest fixtures shared across substrate_setup tests."""
from __future__ import annotations

import pytest

VALID_KEY = "sk-substrate-abcdefghijklmnopqrstuv"


@pytest.fixture
def stub_env(tmp_path, monkeypatch):
    monkeypatch.setenv("HOME", str(tmp_path))
    monkeypatch.setenv("USERPROFILE", str(tmp_path))
    monkeypatch.setenv("SUBSTRATE_API_KEY", VALID_KEY)
    monkeypatch.setenv("XDG_CONFIG_HOME", str(tmp_path / ".config"))
    # Hermes 0.2.0 prefers %LOCALAPPDATA%\hermes on Windows; force it into
    # the tmpdir so tests don't see the developer's real Hermes config.
    monkeypatch.setenv("LOCALAPPDATA", str(tmp_path / "AppData" / "Local"))
    monkeypatch.setenv("APPDATA", str(tmp_path / "AppData" / "Roaming"))
    return tmp_path
