"""End-to-end: run configure / verify / remove against a tmpdir with stubbed agents.

The test stubs only what's needed:
  - HOME points at a tmpdir
  - .config/Cursor/ dir exists so Cursor's print-only handler fires
  - The other three agents have minimal pre-existing user-owned entries to
    confirm preservation
  - /v1/models is mocked via pytest-httpx

Asserts:
  - configure writes the three file-writing agents and prints Cursor's walkthrough
  - Re-running configure produces zero file diff
  - verify reports SUCCESS for the three
  - remove strips the three back to original user content
"""
from __future__ import annotations

from ruamel.yaml import YAML
from substrate_setup.cli import EXIT_OK, main

VALID_KEY = "sk-substrate-abcdefghijklmnopqrstuv"
CATALOG_PAYLOAD = {
    "object": "list",
    "data": [
        {"id": "anthropic/claude-sonnet-4-6", "object": "model", "owned_by": "anthropic",
         "display_name": "Claude Sonnet 4.6", "description": "x"},
        {"id": "openai/gpt-5.5", "object": "model", "owned_by": "openai",
         "display_name": "GPT-5.5", "description": "x"},
    ],
}


def _yaml() -> YAML:
    y = YAML()
    y.preserve_quotes = True
    return y


def test_full_lifecycle(tmp_path, monkeypatch, httpx_mock, capsys):
    monkeypatch.setenv("HOME", str(tmp_path))
    monkeypatch.setenv("USERPROFILE", str(tmp_path))
    monkeypatch.setenv("XDG_CONFIG_HOME", str(tmp_path / ".config"))
    monkeypatch.setenv("APPDATA", str(tmp_path / "AppData/Roaming"))
    monkeypatch.setenv("LOCALAPPDATA", str(tmp_path / "AppData/Local"))
    monkeypatch.setenv("SUBSTRATE_API_KEY", VALID_KEY)

    # Pre-create Cursor dir (so its handler fires).
    (tmp_path / ".config" / "Cursor").mkdir(parents=True)

    # Pre-create a user-owned aider entry.
    (tmp_path / ".aider.conf.yml").write_text("dark-mode: true\n", encoding="utf-8")

    # Pre-create a user-owned hermes entry (detect() requires the file to exist).
    (tmp_path / ".hermes").mkdir()
    (tmp_path / ".hermes" / "config.yaml").write_text("{}\n", encoding="utf-8")

    # Pre-create a user-owned continue entry.
    (tmp_path / ".continue").mkdir()
    (tmp_path / ".continue" / "config.yaml").write_text(
        "schema: v1\nmodels:\n  - name: User Ollama\n    provider: ollama\n    model: qwen\n",
        encoding="utf-8",
    )

    httpx_mock.add_response(
        url="https://gw.example/v1/models",
        json=CATALOG_PAYLOAD,
        is_reusable=True,
    )

    # 1. Configure.
    code = main(["configure", "--base-url", "https://gw.example"])
    assert code == EXIT_OK
    out = capsys.readouterr().out
    assert "Cursor detected" in out

    # Aider preserved.
    aider_conf = _yaml().load((tmp_path / ".aider.conf.yml").read_text(encoding="utf-8"))
    assert aider_conf["dark-mode"] is True
    assert aider_conf["openai-api-base"] == "https://gw.example"

    # Continue preserved.
    cont = _yaml().load((tmp_path / ".continue" / "config.yaml").read_text(encoding="utf-8"))
    names = {m["name"] for m in cont["models"]}
    assert "User Ollama" in names

    # 2. Idempotent re-run.
    snap_aider = (tmp_path / ".aider.conf.yml").read_text(encoding="utf-8")
    snap_continue = (tmp_path / ".continue" / "config.yaml").read_text(encoding="utf-8")
    snap_hermes = (tmp_path / ".hermes" / "config.yaml").read_text(encoding="utf-8")
    # 0.3.0: substrate-managed metadata.json sidecar.
    aider_meta = tmp_path / ".aider.model.metadata.json"
    assert aider_meta.exists()
    snap_meta = aider_meta.read_text(encoding="utf-8")

    capsys.readouterr()
    code = main(["configure", "--base-url", "https://gw.example"])
    assert code == EXIT_OK
    assert (tmp_path / ".aider.conf.yml").read_text(encoding="utf-8") == snap_aider
    assert (tmp_path / ".continue" / "config.yaml").read_text(encoding="utf-8") == snap_continue
    assert (tmp_path / ".hermes" / "config.yaml").read_text(encoding="utf-8") == snap_hermes
    assert aider_meta.read_text(encoding="utf-8") == snap_meta

    # 3. Verify reports clean for the three file-writing agents.
    capsys.readouterr()
    code = main(["verify", "--base-url", "https://gw.example"])
    assert code == EXIT_OK

    # 4. Remove cleans up.
    code = main(["remove", "--base-url", "https://gw.example"])
    assert code == EXIT_OK
    # User entries should still be there.
    cont_after = _yaml().load((tmp_path / ".continue" / "config.yaml").read_text(encoding="utf-8"))
    names_after = {m["name"] for m in cont_after.get("models") or []}
    assert names_after == {"User Ollama"}
    # The substrate-managed metadata sidecar is removed too.
    assert not aider_meta.exists()


def test_e2e_configure_all_six_agents_via_agents_only(
    stub_env, httpx_mock, capsys,
):
    """Configure every supported agent in one run via --agents-only.
    Asserts: CLI exits OK; each file-writing adapter creates its expected
    artifact; Cursor's walkthrough is printed.
    """
    httpx_mock.add_response(
        url="https://gw.example/v1/models",
        json={"object": "list", "data": [
            {"id": "anthropic/claude-sonnet-4-6", "object": "model",
             "owned_by": "anthropic", "display_name": "Claude Sonnet 4.6",
             "description": "Balanced quality and speed"},
            {"id": "openai/gpt-5.5", "object": "model", "owned_by": "openai",
             "display_name": "GPT-5.5", "description": "..."},
        ]},
    )
    code = main([
        "configure", "--base-url", "https://gw.example",
        "--agents-only", "hermes,cursor,aider,continue,claude-code,codex",
    ])
    out = capsys.readouterr().out
    assert code == EXIT_OK, out

    # Each file-writing adapter created its artifact.
    assert (stub_env / ".hermes" / "config.yaml").exists()
    assert (stub_env / ".aider.conf.yml").exists()
    assert (stub_env / ".aider.model.metadata.json").exists()
    assert (stub_env / ".continue" / "config.yaml").exists()
    assert (stub_env / ".claude" / "settings.json").exists()
    assert (stub_env / ".codex" / "config.toml").exists()

    # Cursor's walkthrough fired.
    assert "Cursor" in out
