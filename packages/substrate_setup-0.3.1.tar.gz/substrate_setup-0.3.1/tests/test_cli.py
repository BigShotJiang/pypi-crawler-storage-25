"""Tests for the CLI orchestrator."""
from __future__ import annotations

import pytest
from substrate_setup.cli import EXIT_AUTH, EXIT_BAD_FLAGS, EXIT_OK, EXIT_PARTIAL, main


def test_version_subcommand(capsys):
    code = main(["version"])
    assert code == EXIT_OK
    out = capsys.readouterr().out
    assert "substrate-setup" in out


def test_help_subcommand_exits_zero(capsys):
    with pytest.raises(SystemExit) as exc:
        main(["--help"])
    assert exc.value.code == 0


def test_no_subcommand_runs_configure(stub_env, httpx_mock, capsys):
    httpx_mock.add_response(
        url="https://gw.example/v1/models",
        json={"object": "list", "data": [
            {"id": "openai/gpt-5.5", "object": "model", "owned_by": "openai",
             "display_name": "GPT-5.5", "description": "x"},
        ]},
    )
    code = main(["--base-url", "https://gw.example"])
    out = capsys.readouterr().out
    assert "Configuring" in out
    assert code == EXIT_OK


def test_configure_exits_partial_on_agent_error(stub_env, httpx_mock, capsys, monkeypatch):
    # Plant corrupt YAML in ~/.aider.conf.yml; ruamel.yaml will raise on load,
    # the orchestrator catches it and converts to ResultStatus.ERROR → EXIT_PARTIAL.
    (stub_env / ".aider.conf.yml").write_text(
        "this is: {{ not valid yaml: !!!\n  : indented oddly\n",
        encoding="utf-8",
    )
    httpx_mock.add_response(
        url="https://gw.example/v1/models",
        json={"object": "list", "data": [
            {"id": "openai/gpt-5.5", "object": "model", "owned_by": "openai",
             "display_name": "GPT-5.5", "description": "x"},
        ]},
    )
    code = main(["configure", "--base-url", "https://gw.example"])
    out = capsys.readouterr().out
    assert "ERROR" in out
    assert code == EXIT_PARTIAL


def test_configure_exits_auth_on_401(stub_env, httpx_mock, capsys):
    httpx_mock.add_response(
        url="https://gw.example/v1/models",
        status_code=401,
        json={"error": "invalid_key"},
    )
    code = main(["configure", "--base-url", "https://gw.example"])
    err = capsys.readouterr().err
    assert "rejected by" in err
    assert code == EXIT_AUTH


def test_bad_flag_exits_bad_flags(stub_env, capsys):
    with pytest.raises(SystemExit) as exc:
        main(["--this-flag-does-not-exist"])
    assert exc.value.code in (EXIT_BAD_FLAGS, 2)  # argparse default is 2


def test_agents_only_overrides_detect_on_configure(stub_env, httpx_mock, capsys):
    """Regression: --agents-only is a user assertion that the named agents are
    installed; configure must trust it and write fresh config rather than
    silently skipping because no runtime config exists yet.

    Use case: user cloned Hermes' source to ~/Desktop/Hermes but hasn't run it,
    so ~/.hermes/config.yaml doesn't exist yet. Without this override they'd
    have to run hermes once first to generate the file substrate-setup is
    looking for — a confusing dance.
    """
    httpx_mock.add_response(
        url="https://gw.example/v1/models",
        json={"object": "list", "data": [
            {"id": "openai/gpt-5.5", "object": "model", "owned_by": "openai",
             "display_name": "GPT-5.5", "description": "x"},
        ]},
    )
    # Sanity: no Hermes config exists in stub_env yet.
    assert not (stub_env / ".hermes" / "config.yaml").exists()

    code = main(
        ["configure", "--base-url", "https://gw.example", "--agents-only", "hermes"]
    )
    out = capsys.readouterr().out
    assert code == EXIT_OK, out
    # Hermes must have been configured, NOT skipped.
    assert "Configuring Hermes" in out
    assert "0 of 0 detected" not in out
    # And the config file is now on disk.
    assert (stub_env / ".hermes" / "config.yaml").exists()


def test_agents_only_filters(stub_env, httpx_mock, capsys, monkeypatch):
    httpx_mock.add_response(
        url="https://gw.example/v1/models",
        json={"object": "list", "data": [
            {"id": "openai/gpt-5.5", "object": "model", "owned_by": "openai",
             "display_name": "GPT-5.5", "description": "x"},
        ]},
    )
    code = main(["configure", "--base-url", "https://gw.example", "--agents-only", "aider"])
    out = capsys.readouterr().out
    assert "Aider" in out
    assert "Hermes" not in out
    assert "Continue" not in out
    assert "Cursor" not in out
    assert code == EXIT_OK


def test_main_reconfigures_stdout_utf8_errors_replace(monkeypatch):
    """main() must call ``reconfigure(encoding='utf-8', errors='replace')`` on
    stdout/stderr at entry — without this, printing any non-ASCII glyph
    (e.g. a model id or upstream error message) crashes on Windows GBK
    consoles with UnicodeEncodeError. Affects every China beta user.
    """
    import sys as _sys

    captured: list[tuple[str, dict[str, object]]] = []

    class _FakeStream:
        def reconfigure(self, **kwargs: object) -> None:
            captured.append(("reconfigure", kwargs))

        def write(self, _data: str) -> int:
            return 0

        def flush(self) -> None:
            pass

    fake_out = _FakeStream()
    fake_err = _FakeStream()
    monkeypatch.setattr(_sys, "stdout", fake_out)
    monkeypatch.setattr(_sys, "stderr", fake_err)

    # ``version`` is the cheapest path — it doesn't touch HTTP or files.
    main(["version"])

    # Both streams must have been reconfigured with utf-8 + errors=replace.
    kwargs_seen = [c[1] for c in captured if c[0] == "reconfigure"]
    assert len(kwargs_seen) == 2, f"expected 2 reconfigure calls, got {captured}"
    for kw in kwargs_seen:
        assert kw == {"encoding": "utf-8", "errors": "replace"}, kw


def test_status_glyphs_are_ascii_only(stub_env, httpx_mock, capsys):
    """The detected/not-installed status line must not print any non-ASCII
    char (the old ``✓``/``·`` glyphs and ``…`` ellipsis crashed GBK consoles).
    """
    httpx_mock.add_response(
        url="https://gw.example/v1/models",
        json={"object": "list", "data": [
            {"id": "openai/gpt-5.5", "object": "model", "owned_by": "openai",
             "display_name": "GPT-5.5", "description": "x"},
        ]},
    )
    code = main(["configure", "--base-url", "https://gw.example"])
    assert code == EXIT_OK
    out = capsys.readouterr().out
    # The whole orchestrator output must be ASCII-clean now.
    non_ascii = [ch for ch in out if ord(ch) > 127]
    assert not non_ascii, (
        f"non-ASCII chars leaked into CLI output: "
        f"{sorted(set(non_ascii))!r}"
    )


@pytest.mark.parametrize(
    "agent_name,pretty,expected_artifact",
    [
        ("aider", "Aider", ".aider.conf.yml"),
        ("continue", "Continue", ".continue/config.yaml"),
        ("cursor", "Cursor", None),
        ("claude-code", "Claude Code", ".claude/settings.json"),
        ("codex", "Codex", ".codex/config.toml"),
    ],
)
def test_agents_only_override_covers_all_file_agents(
    agent_name, pretty, expected_artifact, stub_env, httpx_mock, capsys
):
    """--agents-only <name> must write the expected artifact for every
    file-writing adapter and not crash for non-file-writing adapters."""
    httpx_mock.add_response(
        url="https://gw.example/v1/models",
        json={"object": "list", "data": [
            {"id": "openai/gpt-5.5", "object": "model", "owned_by": "openai",
             "display_name": "GPT-5.5", "description": "x"},
        ]},
    )
    code = main(
        ["configure", "--base-url", "https://gw.example", "--agents-only", agent_name]
    )
    out = capsys.readouterr().out
    assert code == EXIT_OK, out
    assert pretty in out
    if expected_artifact is not None:
        assert (stub_env / expected_artifact).exists(), (
            f"Expected {expected_artifact!r} to exist after --agents-only {agent_name!r}"
        )


def test_dry_run_does_not_write(stub_env, httpx_mock, capsys):
    httpx_mock.add_response(
        url="https://gw.example/v1/models",
        json={"object": "list", "data": [
            {"id": "openai/gpt-5.5", "object": "model", "owned_by": "openai",
             "display_name": "GPT-5.5", "description": "x"},
        ]},
    )
    code = main(["configure", "--base-url", "https://gw.example", "--dry-run"])
    # No files should exist under HOME yet.
    assert not (stub_env / ".aider.conf.yml").exists()
    assert not (stub_env / ".hermes").exists()
    assert not (stub_env / ".continue").exists()
    assert code == EXIT_OK
