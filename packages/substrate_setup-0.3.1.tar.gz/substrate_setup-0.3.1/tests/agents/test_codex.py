"""Tests for the Codex (codex) agent handler.

Codex stores config in ``~/.codex/config.toml``. We write a
[model_providers.substrate] block and point top-level model +
model_provider at it. The Codex picker is hardcoded to OpenAI's
lineup; the walkthrough surfaces Substrate model ids for --model
overrides. Marker is a top-of-file comment line.
"""
from __future__ import annotations

import sys

import pytest

try:
    import tomllib
except ImportError:  # pragma: no cover
    import tomli as tomllib  # type: ignore[no-redef]

from substrate_setup.agents.base import ConfigureContext, ResultStatus
from substrate_setup.agents.codex import (
    MARKER_COMMENT_PATTERN,
    CodexAgent,
)
from substrate_setup.catalog import CatalogEntry

VALID_KEY = "sk-substrate-abcdefghijklmnopqrstuv"
SAMPLE_CATALOG = [
    CatalogEntry(
        id="anthropic/claude-sonnet-4-6", provider="anthropic",
        display_name="Claude Sonnet 4.6", description="...",
    ),
    CatalogEntry(
        id="openai/gpt-5.5", provider="openai",
        display_name="GPT-5.5", description="...",
    ),
]


def _ctx(*, dry_run: bool = False) -> ConfigureContext:
    return ConfigureContext(
        base_url="https://gw.example/v1",
        api_key=VALID_KEY,
        catalog=SAMPLE_CATALOG,
        catalog_source="live",
        dry_run=dry_run,
    )


@pytest.fixture
def home_dir(tmp_path, monkeypatch):
    monkeypatch.setattr(sys, "platform", "linux")
    monkeypatch.setenv("HOME", str(tmp_path))
    monkeypatch.setenv("USERPROFILE", str(tmp_path))
    # Insulate from any developer's PATH-installed `codex` binary.
    monkeypatch.setenv("PATH", "")
    return tmp_path


# ─── detect ─────────────────────────────────────────────────────────────────


def test_detect_returns_none_when_codex_not_installed(home_dir):
    assert CodexAgent().detect() is None


def test_detect_returns_config_path_when_present(home_dir):
    (home_dir / ".codex").mkdir()
    (home_dir / ".codex" / "config.toml").write_text("", encoding="utf-8")
    assert CodexAgent().detect() == home_dir / ".codex" / "config.toml"


def test_detect_finds_binary_on_path(home_dir, monkeypatch, tmp_path):
    fake_bin = tmp_path / "bin"
    fake_bin.mkdir()
    fake = fake_bin / "codex"
    fake.write_text("#!/bin/sh\nexit 0\n", encoding="utf-8")
    fake.chmod(0o755)
    monkeypatch.setenv("PATH", str(fake_bin))
    detected = CodexAgent().detect()
    assert detected is not None


# ─── configure ──────────────────────────────────────────────────────────────


def test_configure_writes_model_providers_substrate_block(home_dir):
    result = CodexAgent().configure(_ctx())
    assert result.status == ResultStatus.SUCCESS

    cfg = home_dir / ".codex" / "config.toml"
    assert cfg.exists()
    data = tomllib.loads(cfg.read_text(encoding="utf-8"))

    block = data["model_providers"]["substrate"]
    assert block["name"] == "Substrate Solutions"
    assert block["base_url"] == "https://gw.example/v1"
    assert block["env_key"] == "SUBSTRATE_API_KEY"
    assert block["wire_api"] == "responses"


def test_configure_writes_top_level_model_and_model_provider(home_dir):
    CodexAgent().configure(_ctx())
    data = tomllib.loads(
        (home_dir / ".codex" / "config.toml").read_text(encoding="utf-8")
    )
    assert data["model"] == "anthropic/claude-sonnet-4-6"
    assert data["model_provider"] == "substrate"


def test_configure_writes_marker_comment_line(home_dir):
    CodexAgent().configure(_ctx())
    text = (home_dir / ".codex" / "config.toml").read_text(encoding="utf-8")
    first_line = text.splitlines()[0]
    assert first_line.startswith("# substrate-setup-managed:")
    assert MARKER_COMMENT_PATTERN.match(first_line) is not None


def test_configure_preserves_other_model_providers_blocks(home_dir):
    codex_dir = home_dir / ".codex"
    codex_dir.mkdir()
    (codex_dir / "config.toml").write_text(
        '[model_providers.local]\n'
        'name = "Local"\n'
        'base_url = "http://127.0.0.1:1234/v1"\n'
        'wire_api = "responses"\n',
        encoding="utf-8",
    )
    CodexAgent().configure(_ctx())

    data = tomllib.loads((codex_dir / "config.toml").read_text(encoding="utf-8"))
    assert "local" in data["model_providers"]
    assert data["model_providers"]["local"]["base_url"] == "http://127.0.0.1:1234/v1"
    assert "substrate" in data["model_providers"]


def test_configure_refuses_when_user_owned_substrate_block(home_dir):
    codex_dir = home_dir / ".codex"
    codex_dir.mkdir()
    (codex_dir / "config.toml").write_text(
        '[model_providers.substrate]\n'
        'name = "User Substrate"\n'
        'base_url = "https://different.example"\n'
        'wire_api = "chat"\n',
        encoding="utf-8",
    )
    result = CodexAgent().configure(_ctx())
    assert result.status == ResultStatus.ERROR


def test_configure_auto_claims_when_existing_substrate_block_matches(home_dir):
    codex_dir = home_dir / ".codex"
    codex_dir.mkdir()
    (codex_dir / "config.toml").write_text(
        'model = "openai/gpt-5.4-mini"\n'
        'model_provider = "substrate"\n'
        '\n'
        '[model_providers.substrate]\n'
        'name = "Substrate Solutions"\n'
        'base_url = "https://gw.example/v1"\n'
        'env_key = "SUBSTRATE_API_KEY"\n'
        'wire_api = "responses"\n',
        encoding="utf-8",
    )
    result = CodexAgent().configure(_ctx())
    assert result.status == ResultStatus.SUCCESS

    text = (codex_dir / "config.toml").read_text(encoding="utf-8")
    assert MARKER_COMMENT_PATTERN.match(text.splitlines()[0]) is not None


def test_configure_returns_clean_error_on_malformed_toml(home_dir):
    codex_dir = home_dir / ".codex"
    codex_dir.mkdir()
    (codex_dir / "config.toml").write_text(
        "this is = [not valid toml = oops\n",
        encoding="utf-8",
    )
    result = CodexAgent().configure(_ctx())
    assert result.status == ResultStatus.ERROR
    assert "valid TOML" in result.message


def test_configure_chmods_0600_on_posix(home_dir, monkeypatch):
    monkeypatch.setattr(sys, "platform", "linux")
    CodexAgent().configure(_ctx())
    mode = (home_dir / ".codex" / "config.toml").stat().st_mode & 0o777
    assert mode == 0o600


def test_configure_walkthrough_lists_models_with_codex_model_flag(
    home_dir, capsys
):
    CodexAgent().configure(_ctx())
    out = capsys.readouterr().out
    assert "anthropic/claude-sonnet-4-6" in out
    assert "openai/gpt-5.5" in out
    assert "codex --model" in out
    # Reminds the user to export SUBSTRATE_API_KEY.
    assert "SUBSTRATE_API_KEY" in out


def test_configure_walkthrough_acknowledges_responses_endpoint(home_dir, capsys):
    """Codex talks /v1/responses (gateway Phase 2, shipped 2026-05-24).
    The walkthrough must mention /v1/responses; the stale "NOT YET STARTED"
    warning must NOT appear; and the "live" message must be present.
    """
    CodexAgent().configure(_ctx())
    out = capsys.readouterr().out
    assert "/v1/responses" in out
    assert "NOT YET STARTED" not in out
    assert "live" in out.lower() and "substrate" in out.lower()


def test_codex_configure_calls_env_persist(monkeypatch, home_dir):
    """Configure must persist the API key, not just print 'set it yourself'."""
    from substrate_setup import env_persist

    captured: list[str] = []

    def fake_persist(api_key: str) -> env_persist.PersistResult:
        captured.append(api_key)
        return env_persist.PersistResult(
            status=env_persist.PersistStatus.PERSISTED,
            message="test ok",
            path=None,
        )

    monkeypatch.setattr(
        "substrate_setup.agents.codex.persist_substrate_api_key", fake_persist
    )

    ctx = _ctx()
    CodexAgent().configure(ctx)

    assert captured == [VALID_KEY]


def test_codex_configure_prints_defender_note_on_windows(
    monkeypatch, tmp_path, capsys
):
    """Configure on Windows surfaces the one-line Defender exclusion command."""
    monkeypatch.setattr("substrate_setup.agents.codex.sys.platform", "win32")
    monkeypatch.setenv("HOME", str(tmp_path))
    monkeypatch.setenv("USERPROFILE", str(tmp_path))
    monkeypatch.setenv("PATH", "")

    from substrate_setup import env_persist

    monkeypatch.setattr(
        "substrate_setup.agents.codex.persist_substrate_api_key",
        lambda key: env_persist.PersistResult(
            status=env_persist.PersistStatus.PERSISTED,
            message="patched in test",
            path=None,
        ),
    )

    CodexAgent().configure(_ctx())

    out = capsys.readouterr().out
    assert "Windows Defender SmartScreen" in out
    assert "Add-MpPreference -ExclusionPath" in out
    assert (
        r"$env:LOCALAPPDATA\OpenAI\Codex" in out
        or "$env:LOCALAPPDATA\\OpenAI\\Codex" in out
    )


def test_codex_configure_skips_defender_note_on_non_windows(
    monkeypatch, tmp_path, capsys
):
    """The Defender note is Windows-only — Mac/Linux users don't see it."""
    monkeypatch.setattr("substrate_setup.agents.codex.sys.platform", "darwin")
    monkeypatch.setenv("HOME", str(tmp_path))
    monkeypatch.setenv("USERPROFILE", str(tmp_path))
    monkeypatch.setenv("PATH", "")

    from substrate_setup import env_persist

    monkeypatch.setattr(
        "substrate_setup.agents.codex.persist_substrate_api_key",
        lambda key: env_persist.PersistResult(
            status=env_persist.PersistStatus.PERSISTED,
            message="patched in test",
            path=None,
        ),
    )

    CodexAgent().configure(_ctx())

    out = capsys.readouterr().out
    assert "Defender" not in out
    assert "Add-MpPreference" not in out


# ─── verify ─────────────────────────────────────────────────────────────────


def test_verify_reports_clean_when_in_sync(home_dir):
    CodexAgent().configure(_ctx())
    result = CodexAgent().verify(_ctx())
    assert result.status == ResultStatus.SUCCESS


def test_verify_reports_drift_when_base_url_changed(home_dir):
    CodexAgent().configure(_ctx())
    cfg = home_dir / ".codex" / "config.toml"
    text = cfg.read_text(encoding="utf-8")
    text = text.replace("https://gw.example/v1", "https://drift.example/v1")
    cfg.write_text(text, encoding="utf-8")

    result = CodexAgent().verify(_ctx())
    assert result.status == ResultStatus.ERROR


# ─── remove ────────────────────────────────────────────────────────────────


def test_remove_drops_substrate_block_and_top_level_refs(home_dir):
    CodexAgent().configure(_ctx())
    result = CodexAgent().remove(_ctx())
    assert result.status == ResultStatus.SUCCESS

    text = (home_dir / ".codex" / "config.toml").read_text(encoding="utf-8")
    assert "substrate-setup-managed" not in text
    data = tomllib.loads(text) if text.strip() else {}
    assert "substrate" not in data.get("model_providers", {})
    assert data.get("model_provider") != "substrate"


def test_remove_preserves_other_providers(home_dir):
    codex_dir = home_dir / ".codex"
    codex_dir.mkdir()
    (codex_dir / "config.toml").write_text(
        '[model_providers.local]\n'
        'name = "Local"\n'
        'base_url = "http://127.0.0.1:1234/v1"\n'
        'wire_api = "responses"\n',
        encoding="utf-8",
    )
    CodexAgent().configure(_ctx())
    CodexAgent().remove(_ctx())

    text = (codex_dir / "config.toml").read_text(encoding="utf-8")
    data = tomllib.loads(text)
    assert "local" in data.get("model_providers", {})


def test_remove_skips_when_marker_absent(home_dir):
    """remove() must not touch user-owned config.toml without a marker."""
    codex_dir = home_dir / ".codex"
    codex_dir.mkdir()
    user_toml = (
        '[model_providers.local]\n'
        'name = "Local"\n'
    )
    (codex_dir / "config.toml").write_text(user_toml, encoding="utf-8")

    result = CodexAgent().remove(_ctx())
    assert result.status == ResultStatus.SKIPPED
    assert (codex_dir / "config.toml").read_text(encoding="utf-8") == user_toml
