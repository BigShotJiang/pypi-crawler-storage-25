"""Tests for the Continue agent handler (0.2.0 — YAML-only, migrates legacy JSON)."""
from __future__ import annotations

import json
import sys

import pytest
from ruamel.yaml import YAML
from substrate_setup.agents.base import ConfigureContext, ResultStatus
from substrate_setup.agents.continue_dev import ContinueAgent
from substrate_setup.catalog import CatalogEntry

VALID_KEY = "sk-substrate-abcdefghijklmnopqrstuv"
SAMPLE_CATALOG = [
    CatalogEntry("anthropic/claude-sonnet-4-6", "anthropic", "Claude Sonnet 4.6", "x"),
    CatalogEntry("openai/gpt-5.5", "openai", "GPT-5.5", "x"),
]


def _ctx(*, source: str = "live") -> ConfigureContext:
    return ConfigureContext(
        base_url="https://gw.example/v1",
        api_key=VALID_KEY,
        catalog=SAMPLE_CATALOG,
        catalog_source=source,
        dry_run=False,
    )


@pytest.fixture
def home_dir(tmp_path, monkeypatch):
    monkeypatch.setattr(sys, "platform", "linux")
    monkeypatch.setenv("HOME", str(tmp_path))
    monkeypatch.setenv("USERPROFILE", str(tmp_path))
    return tmp_path


def _yaml() -> YAML:
    y = YAML()
    y.preserve_quotes = True
    return y


# ─── detect ─────────────────────────────────────────────────────────────────


def test_detect_returns_yaml_when_present(home_dir):
    (home_dir / ".continue").mkdir()
    (home_dir / ".continue" / "config.yaml").write_text("models: []\n", encoding="utf-8")
    assert ContinueAgent().detect() == home_dir / ".continue" / "config.yaml"


def test_detect_returns_yaml_path_when_only_json_present(home_dir):
    """Even if only legacy JSON exists, detect() returns the would-be YAML path
    so the orchestrator knows Continue is installed and triggers migration."""
    (home_dir / ".continue").mkdir()
    (home_dir / ".continue" / "config.json").write_text('{"models": []}', encoding="utf-8")
    detected = ContinueAgent().detect()
    # Either path is acceptable, but the configure() flow MUST end up writing YAML.
    assert detected is not None
    assert detected.parent == home_dir / ".continue"


def test_detect_returns_none_when_neither_present(home_dir):
    assert ContinueAgent().detect() is None


# ─── configure ──────────────────────────────────────────────────────────────


def test_writes_required_top_level_fields_on_fresh_config(home_dir):
    """A fresh config.yaml must have name, version, schema, and models."""
    result = ContinueAgent().configure(_ctx())
    assert result.status == ResultStatus.SUCCESS

    cfg = home_dir / ".continue" / "config.yaml"
    assert cfg.exists()

    payload = _yaml().load(cfg.read_text(encoding="utf-8"))
    assert payload["name"] == "substrate-setup"
    assert payload["version"] == "0.0.1"
    assert payload["schema"] == "v1"
    assert isinstance(payload["models"], list)

    # Models populated.
    ids = {m["model"] for m in payload["models"]}
    assert ids == {"anthropic/claude-sonnet-4-6", "openai/gpt-5.5"}
    for m in payload["models"]:
        assert m["provider"] == "openai"
        assert m["apiBase"] == "https://gw.example/v1"
        assert m["apiKey"] == VALID_KEY
        assert m["_substrate_managed"] is True
        # Required: name + model + roles
        assert "name" in m
        assert "model" in m
        assert set(m["roles"]) == {"chat", "edit", "apply", "summarize"}


def test_writes_only_yaml_never_json(home_dir):
    ContinueAgent().configure(_ctx())
    assert (home_dir / ".continue" / "config.yaml").exists()
    # No new JSON file created when starting from nothing.
    assert not (home_dir / ".continue" / "config.json").exists()


def test_migrates_legacy_json(home_dir, capsys):
    """If only config.json exists, migrate it to config.yaml; back up JSON."""
    (home_dir / ".continue").mkdir()
    legacy_json = home_dir / ".continue" / "config.json"
    legacy_json.write_text(
        json.dumps({
            "models": [
                {"name": "My Local Ollama", "provider": "ollama", "model": "qwen"}
            ]
        }),
        encoding="utf-8",
    )

    ContinueAgent().configure(_ctx())

    yaml_path = home_dir / ".continue" / "config.yaml"
    assert yaml_path.exists()
    payload = _yaml().load(yaml_path.read_text(encoding="utf-8"))

    # YAML carries the migrated user entry AND the substrate entries.
    names = {m["name"] for m in payload["models"]}
    assert "My Local Ollama" in names
    ids = {m.get("model") for m in payload["models"]}
    assert "anthropic/claude-sonnet-4-6" in ids
    assert "openai/gpt-5.5" in ids

    # A backup of config.json exists.
    backups = list((home_dir / ".continue").glob("config.json.substrate-bak-*"))
    assert backups, "expected a substrate-bak-* backup of the legacy JSON"

    # Required top-level fields populated.
    assert payload["schema"] == "v1"
    assert payload["name"]
    assert payload["version"]


def test_yaml_preferred_when_both_present(home_dir):
    """If both config.yaml and config.json exist, mutate YAML only; JSON untouched."""
    (home_dir / ".continue").mkdir()
    (home_dir / ".continue" / "config.yaml").write_text(
        "schema: v1\nname: existing\nversion: 0.0.1\nmodels: []\n", encoding="utf-8"
    )
    json_path = home_dir / ".continue" / "config.json"
    json_path.write_text('{"models": [{"a": 1}]}', encoding="utf-8")
    json_original = json_path.read_text(encoding="utf-8")

    ContinueAgent().configure(_ctx())

    yaml_data = _yaml().load((home_dir / ".continue" / "config.yaml").read_text(encoding="utf-8"))
    assert len(yaml_data["models"]) == 2
    # JSON untouched.
    assert json_path.read_text(encoding="utf-8") == json_original


def test_configure_preserves_user_models_without_marker(home_dir):
    (home_dir / ".continue").mkdir()
    (home_dir / ".continue" / "config.yaml").write_text(
        "schema: v1\nname: existing\nversion: 0.0.1\n"
        "models:\n  - name: My Local Ollama\n    provider: ollama\n"
        "    model: qwen2.5-coder:32b\n",
        encoding="utf-8",
    )
    ContinueAgent().configure(_ctx())
    payload = _yaml().load((home_dir / ".continue" / "config.yaml").read_text(encoding="utf-8"))
    names = {m["name"] for m in payload["models"]}
    assert "My Local Ollama" in names
    assert payload["schema"] == "v1"


def test_configure_is_idempotent(home_dir):
    ContinueAgent().configure(_ctx())
    a = (home_dir / ".continue" / "config.yaml").read_text(encoding="utf-8")
    ContinueAgent().configure(_ctx())
    b = (home_dir / ".continue" / "config.yaml").read_text(encoding="utf-8")
    assert a == b


def test_configure_fallback_path_does_not_drop_existing_substrate_entries(home_dir):
    ContinueAgent().configure(_ctx())
    fallback_ctx = ConfigureContext(
        base_url="https://gw.example/v1",
        api_key=VALID_KEY,
        catalog=SAMPLE_CATALOG[:1],   # drop gpt-5.5
        catalog_source="fallback",
        dry_run=False,
    )
    ContinueAgent().configure(fallback_ctx)
    payload = _yaml().load((home_dir / ".continue" / "config.yaml").read_text(encoding="utf-8"))
    ids = {m["model"] for m in payload["models"]}
    assert "openai/gpt-5.5" in ids


# ─── remove ─────────────────────────────────────────────────────────────────


def test_remove_strips_substrate_models_only(home_dir):
    (home_dir / ".continue").mkdir()
    (home_dir / ".continue" / "config.yaml").write_text(
        "schema: v1\nname: existing\nversion: 0.0.1\n"
        "models:\n  - name: My Local Ollama\n    provider: ollama\n    model: qwen2.5-coder:32b\n",
        encoding="utf-8",
    )
    ContinueAgent().configure(_ctx())
    ContinueAgent().remove(_ctx())
    payload = _yaml().load((home_dir / ".continue" / "config.yaml").read_text(encoding="utf-8"))
    names = {m["name"] for m in payload.get("models", [])}
    assert names == {"My Local Ollama"}


# ─── verify ─────────────────────────────────────────────────────────────────


def test_verify_reports_stale(home_dir):
    ContinueAgent().configure(_ctx())
    larger = ConfigureContext(
        base_url="https://gw.example/v1",
        api_key=VALID_KEY,
        catalog=[
            *SAMPLE_CATALOG,
            CatalogEntry("moonshot/kimi-k2.6", "moonshot", "Kimi K2.6", ""),
        ],
        catalog_source="live",
        dry_run=False,
    )
    result = ContinueAgent().verify(larger)
    assert result.status == ResultStatus.ERROR
    assert "moonshot/kimi-k2.6" in result.message


def test_continue_configure_calls_env_persist(monkeypatch, home_dir):
    """Configure must persist the API key, not just print 'set it yourself'."""
    from substrate_setup import env_persist

    captured: list[str] = []

    def fake_persist(api_key: str) -> env_persist.PersistResult:
        captured.append(api_key)
        return env_persist.PersistResult(
            status=env_persist.PersistStatus.PERSISTED,
            message="test ok",
            path=None,
        )

    monkeypatch.setattr(
        "substrate_setup.agents.continue_dev.persist_substrate_api_key", fake_persist
    )

    ctx = _ctx()
    ContinueAgent().configure(ctx)

    assert captured == [VALID_KEY]


def test_excludes_image_gen_models(home_dir):
    chat = CatalogEntry(
        id="openai/gpt-5.5", provider="openai",
        display_name="GPT-5.5", description="...",
    )
    image = CatalogEntry(
        id="openai/gpt-image-2", provider="openai",
        display_name="gpt-image-2", description="...",
        output_modality="image",
    )
    ctx = ConfigureContext(
        base_url="https://gw.example/v1",
        api_key=VALID_KEY,
        catalog=[chat, image],
        catalog_source="live",
        dry_run=False,
    )
    ContinueAgent().configure(ctx)

    payload = _yaml().load(
        (home_dir / ".continue" / "config.yaml").read_text(encoding="utf-8")
    )
    model_ids = [m["model"] for m in (payload.get("models") or [])]
    assert "openai/gpt-5.5" in model_ids
    assert "openai/gpt-image-2" not in model_ids
