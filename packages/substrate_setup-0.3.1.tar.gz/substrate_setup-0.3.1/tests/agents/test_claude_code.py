"""Tests for the Claude Code (claude-code) agent handler.

Claude Code stores config in ``~/.claude/settings.json``. We merge three
env keys into the ``env:`` block without disturbing other user-set keys.
Marker is a top-level list ``_substrate_setup_managed_env_keys``.
"""
from __future__ import annotations

import json
import sys

import pytest
from substrate_setup.agents.base import ConfigureContext, ResultStatus
from substrate_setup.agents.claude_code import (
    MANAGED_ENV_KEYS,
    ClaudeCodeAgent,
)
from substrate_setup.catalog import CatalogEntry

VALID_KEY = "sk-substrate-abcdefghijklmnopqrstuv"
SAMPLE_CATALOG = [
    CatalogEntry(
        id="anthropic/claude-sonnet-4-6", provider="anthropic",
        display_name="Claude Sonnet 4.6", description="...",
    ),
    CatalogEntry(
        id="openai/gpt-5.5", provider="openai",
        display_name="GPT-5.5", description="...",
    ),
]


def _ctx(*, dry_run: bool = False) -> ConfigureContext:
    return ConfigureContext(
        base_url="https://gw.example/v1",
        api_key=VALID_KEY,
        catalog=SAMPLE_CATALOG,
        catalog_source="live",
        dry_run=dry_run,
    )


@pytest.fixture
def home_dir(tmp_path, monkeypatch):
    monkeypatch.setattr(sys, "platform", "linux")
    monkeypatch.setenv("HOME", str(tmp_path))
    monkeypatch.setenv("USERPROFILE", str(tmp_path))
    # Insulate from any developer's PATH-installed `claude` binary so
    # detect() tests don't leak the local environment.
    monkeypatch.setenv("PATH", "")
    return tmp_path


# ─── detect ─────────────────────────────────────────────────────────────────


def test_detect_returns_none_when_claude_code_not_installed(home_dir):
    assert ClaudeCodeAgent().detect() is None


def test_detect_returns_settings_path_when_present(home_dir):
    (home_dir / ".claude").mkdir()
    (home_dir / ".claude" / "settings.json").write_text("{}", encoding="utf-8")
    assert ClaudeCodeAgent().detect() == home_dir / ".claude" / "settings.json"


def test_detect_returns_dir_when_only_directory_present(home_dir):
    (home_dir / ".claude").mkdir()
    detected = ClaudeCodeAgent().detect()
    assert detected is not None
    assert detected.name in {"settings.json", ".claude"}


def test_detect_finds_binary_on_path(home_dir, monkeypatch, tmp_path):
    fake_bin = tmp_path / "bin"
    fake_bin.mkdir()
    fake = fake_bin / "claude"
    fake.write_text("#!/bin/sh\nexit 0\n", encoding="utf-8")
    fake.chmod(0o755)
    monkeypatch.setenv("PATH", str(fake_bin))
    detected = ClaudeCodeAgent().detect()
    assert detected is not None


# ─── configure ──────────────────────────────────────────────────────────────


def test_configure_writes_three_env_keys(home_dir):
    result = ClaudeCodeAgent().configure(_ctx())
    assert result.status == ResultStatus.SUCCESS

    settings_path = home_dir / ".claude" / "settings.json"
    assert settings_path.exists()
    data = json.loads(settings_path.read_text(encoding="utf-8"))

    env = data["env"]
    # Base URL must NOT include /v1 — Claude Code appends /v1/messages itself.
    assert env["ANTHROPIC_BASE_URL"] == "https://gw.example"
    assert env["ANTHROPIC_AUTH_TOKEN"] == VALID_KEY
    assert env["ANTHROPIC_MODEL"] == "anthropic/claude-sonnet-4-6"

    assert data["_substrate_setup_managed_env_keys"] == list(MANAGED_ENV_KEYS)


def test_configure_creates_settings_json_when_missing(home_dir):
    assert not (home_dir / ".claude").exists()
    result = ClaudeCodeAgent().configure(_ctx())
    assert result.status == ResultStatus.SUCCESS
    assert (home_dir / ".claude" / "settings.json").exists()


def test_configure_preserves_user_env_keys(home_dir):
    claude_dir = home_dir / ".claude"
    claude_dir.mkdir()
    (claude_dir / "settings.json").write_text(json.dumps({
        "env": {"MAX_THINKING_TOKENS": "100000"}
    }) + "\n", encoding="utf-8")

    ClaudeCodeAgent().configure(_ctx())

    data = json.loads((claude_dir / "settings.json").read_text(encoding="utf-8"))
    env = data["env"]
    assert env["MAX_THINKING_TOKENS"] == "100000"
    assert env["ANTHROPIC_MODEL"] == "anthropic/claude-sonnet-4-6"


def test_configure_refuses_user_owned_settings(home_dir):
    claude_dir = home_dir / ".claude"
    claude_dir.mkdir()
    (claude_dir / "settings.json").write_text(json.dumps({
        "env": {
            "ANTHROPIC_BASE_URL": "https://different.example",
            "ANTHROPIC_AUTH_TOKEN": "sk-ant-USER",
            "ANTHROPIC_MODEL": "custom-model",
        }
    }) + "\n", encoding="utf-8")

    result = ClaudeCodeAgent().configure(_ctx())
    assert result.status == ResultStatus.ERROR
    # Settings.json content is unchanged.
    data = json.loads((claude_dir / "settings.json").read_text(encoding="utf-8"))
    assert data["env"]["ANTHROPIC_AUTH_TOKEN"] == "sk-ant-USER"  # noqa: S105


def test_configure_auto_claims_when_existing_matches_substrate_shape(home_dir):
    claude_dir = home_dir / ".claude"
    claude_dir.mkdir()
    (claude_dir / "settings.json").write_text(json.dumps({
        "env": {
            "ANTHROPIC_BASE_URL": "https://gw.example",
            "ANTHROPIC_AUTH_TOKEN": "sk-substrate-old-rotated-key-12345",
            "ANTHROPIC_MODEL": "anthropic/claude-sonnet-4-6",
        }
    }) + "\n", encoding="utf-8")

    result = ClaudeCodeAgent().configure(_ctx())
    assert result.status == ResultStatus.SUCCESS

    data = json.loads((claude_dir / "settings.json").read_text(encoding="utf-8"))
    assert data["_substrate_setup_managed_env_keys"] == list(MANAGED_ENV_KEYS)


def test_configure_handles_malformed_json(home_dir):
    claude_dir = home_dir / ".claude"
    claude_dir.mkdir()
    (claude_dir / "settings.json").write_text("{ not valid json", encoding="utf-8")
    result = ClaudeCodeAgent().configure(_ctx())
    assert result.status == ResultStatus.ERROR
    assert "valid JSON" in result.message


def test_configure_chmods_0600_on_posix(home_dir, monkeypatch):
    monkeypatch.setattr(sys, "platform", "linux")
    ClaudeCodeAgent().configure(_ctx())
    mode = (home_dir / ".claude" / "settings.json").stat().st_mode & 0o777
    assert mode == 0o600


def test_configure_base_url_strips_v1_suffix(home_dir):
    """Claude Code appends /v1/messages itself."""
    ctx = ConfigureContext(
        base_url="https://gw.example/v1",
        api_key=VALID_KEY,
        catalog=SAMPLE_CATALOG,
        catalog_source="live",
        dry_run=False,
    )
    ClaudeCodeAgent().configure(ctx)
    data = json.loads(
        (home_dir / ".claude" / "settings.json").read_text(encoding="utf-8")
    )
    assert data["env"]["ANTHROPIC_BASE_URL"] == "https://gw.example"


def test_configure_writes_walkthrough_with_model_examples(home_dir, capsys):
    ClaudeCodeAgent().configure(_ctx())
    out = capsys.readouterr().out
    assert "anthropic/claude-sonnet-4-6" in out
    assert "openai/gpt-5.5" in out
    assert "--model" in out


def test_configure_walkthrough_acknowledges_messages_endpoint_flag_gated(
    home_dir, capsys,
):
    """Phase 1 (/v1/messages) merged but is mounted behind a Fly feature
    flag that may not be flipped yet. The walkthrough must tell the user
    so they're not surprised by 404 responses.
    """
    ClaudeCodeAgent().configure(_ctx())
    out = capsys.readouterr().out
    assert "/v1/messages" in out
    assert "404" in out or "feature flag" in out.lower() or "not yet" in out.lower()


# ─── verify ─────────────────────────────────────────────────────────────────


def test_verify_reports_clean_when_in_sync(home_dir):
    ClaudeCodeAgent().configure(_ctx())
    result = ClaudeCodeAgent().verify(_ctx())
    assert result.status == ResultStatus.SUCCESS


def test_verify_reports_drift_on_base_url_change(home_dir):
    ClaudeCodeAgent().configure(_ctx())
    settings_path = home_dir / ".claude" / "settings.json"
    data = json.loads(settings_path.read_text(encoding="utf-8"))
    data["env"]["ANTHROPIC_BASE_URL"] = "https://drift.example"
    settings_path.write_text(json.dumps(data) + "\n", encoding="utf-8")

    result = ClaudeCodeAgent().verify(_ctx())
    assert result.status == ResultStatus.ERROR
    assert "ANTHROPIC_BASE_URL" in result.message


# ─── remove ────────────────────────────────────────────────────────────────


def test_remove_strips_only_managed_env_keys(home_dir):
    claude_dir = home_dir / ".claude"
    claude_dir.mkdir()
    (claude_dir / "settings.json").write_text(json.dumps({
        "env": {"MAX_THINKING_TOKENS": "100000"}
    }) + "\n", encoding="utf-8")

    ClaudeCodeAgent().configure(_ctx())
    result = ClaudeCodeAgent().remove(_ctx())
    assert result.status == ResultStatus.SUCCESS

    data = json.loads((claude_dir / "settings.json").read_text(encoding="utf-8"))
    env = data.get("env", {})
    assert "ANTHROPIC_BASE_URL" not in env
    assert "ANTHROPIC_AUTH_TOKEN" not in env
    assert "ANTHROPIC_MODEL" not in env
    assert env["MAX_THINKING_TOKENS"] == "100000"
    assert "_substrate_setup_managed_env_keys" not in data


def test_remove_skips_when_not_configured(home_dir):
    result = ClaudeCodeAgent().remove(_ctx())
    assert result.status == ResultStatus.SKIPPED


def test_claude_code_configure_calls_env_persist(monkeypatch, home_dir):
    """Configure must persist the API key, not just print 'set it yourself'."""
    from substrate_setup import env_persist

    captured: list[str] = []

    def fake_persist(api_key: str) -> env_persist.PersistResult:
        captured.append(api_key)
        return env_persist.PersistResult(
            status=env_persist.PersistStatus.PERSISTED,
            message="test ok",
            path=None,
        )

    monkeypatch.setattr(
        "substrate_setup.agents.claude_code.persist_substrate_api_key", fake_persist
    )

    ctx = _ctx()
    ClaudeCodeAgent().configure(ctx)

    assert captured == [VALID_KEY]
