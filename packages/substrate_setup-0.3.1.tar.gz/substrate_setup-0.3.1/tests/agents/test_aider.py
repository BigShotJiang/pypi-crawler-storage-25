"""Tests for the Aider agent handler (0.2.0 — single conf.yml, no metadata file)."""
from __future__ import annotations

import json
import sys

import pytest
from ruamel.yaml import YAML
from substrate_setup.agents.aider import AiderAgent
from substrate_setup.agents.base import ConfigureContext, ResultStatus
from substrate_setup.catalog import CatalogEntry

VALID_KEY = "sk-substrate-abcdefghijklmnopqrstuv"
SAMPLE_CATALOG = [
    CatalogEntry("anthropic/claude-sonnet-4-6", "anthropic", "Claude Sonnet 4.6", "x"),
    CatalogEntry("openai/gpt-5.5", "openai", "GPT-5.5", "x"),
]


def _ctx(*, source: str = "live") -> ConfigureContext:
    return ConfigureContext(
        base_url="https://gw.example/v1",
        api_key=VALID_KEY,
        catalog=SAMPLE_CATALOG,
        catalog_source=source,
        dry_run=False,
    )


@pytest.fixture
def home_dir(tmp_path, monkeypatch):
    monkeypatch.setattr(sys, "platform", "linux")
    monkeypatch.setenv("HOME", str(tmp_path))
    monkeypatch.setenv("USERPROFILE", str(tmp_path))
    return tmp_path


def _yaml() -> YAML:
    y = YAML()
    y.preserve_quotes = True
    return y


# ─── detect ─────────────────────────────────────────────────────────────────


def test_detect_returns_aider_conf_path_when_present(home_dir):
    (home_dir / ".aider.conf.yml").write_text("dark-mode: true\n", encoding="utf-8")
    assert AiderAgent().detect() == home_dir / ".aider.conf.yml"


def test_detect_returns_none_when_aider_not_installed(home_dir):
    assert AiderAgent().detect() is None


# ─── configure ──────────────────────────────────────────────────────────────


def test_writes_only_conf_yml(home_dir):
    """0.3.0: writes ~/.aider.conf.yml plus the substrate-managed
    ~/.aider.model.metadata.json sidecar. ~/.env is no longer written.
    """
    result = AiderAgent().configure(_ctx())
    assert result.status == ResultStatus.SUCCESS

    conf = home_dir / ".aider.conf.yml"
    assert conf.exists()
    # 0.3.0: metadata.json is now substrate-managed (with marker).
    assert (home_dir / ".aider.model.metadata.json").exists()
    # ~/.env is still not written (0.2.0 dropped it; legacy cleanup only).
    assert not (home_dir / ".env").exists()

    conf_data = _yaml().load(conf.read_text(encoding="utf-8"))
    assert conf_data["openai-api-base"] == "https://gw.example/v1"
    assert conf_data["openai-api-key"] == VALID_KEY
    # default model = first catalog entry
    assert conf_data["model"] == "anthropic/claude-sonnet-4-6"

    # Top-level marker listing the keys we own.
    assert conf_data["_substrate_setup_managed_keys"] == [
        "openai-api-base",
        "openai-api-key",
        "model",
    ]


def test_configure_preserves_user_aider_conf_keys(home_dir):
    (home_dir / ".aider.conf.yml").write_text(
        "dark-mode: true\nauto-commits: false\nweak-model: openai/gpt-4o-mini\n",
        encoding="utf-8",
    )
    AiderAgent().configure(_ctx())
    conf_data = _yaml().load((home_dir / ".aider.conf.yml").read_text(encoding="utf-8"))
    assert conf_data["dark-mode"] is True
    assert conf_data["auto-commits"] is False
    assert conf_data["weak-model"] == "openai/gpt-4o-mini"
    assert conf_data["openai-api-base"] == "https://gw.example/v1"


def test_auto_claim_when_shape_matches_unmarked(home_dir):
    """If openai-api-base == ctx.base_url and openai-api-key starts with
    sk-substrate- but the marker is absent, configure() should SUCCEED,
    write the marker, and keep/refresh the keys. This is the
    upgrade-from-0.1 / manually-fixed case; refusing here is friction
    with no safety benefit.
    """
    (home_dir / ".aider.conf.yml").write_text(
        "openai-api-base: https://gw.example/v1\n"
        "openai-api-key: sk-substrate-prior-key-shaped-like-substrate\n"
        "model: anthropic/claude-sonnet-4-6\n",
        encoding="utf-8",
    )
    result = AiderAgent().configure(_ctx())
    assert result.status == ResultStatus.SUCCESS

    conf_data = _yaml().load(
        (home_dir / ".aider.conf.yml").read_text(encoding="utf-8")
    )
    # Marker now present.
    assert conf_data["_substrate_setup_managed_keys"] == [
        "openai-api-base",
        "openai-api-key",
        "model",
    ]
    # Keys refreshed to ctx values.
    assert conf_data["openai-api-base"] == "https://gw.example/v1"
    assert conf_data["openai-api-key"] == VALID_KEY
    assert conf_data["model"] == "anthropic/claude-sonnet-4-6"


def test_still_refuses_truly_user_owned(home_dir):
    """Marker absent + shape does NOT look substrate (api.openai.com
    base_url, non-sk-substrate key) -> still ERROR + no write.
    """
    conf = home_dir / ".aider.conf.yml"
    conf.write_text(
        "openai-api-base: https://api.openai.com/v1\n"
        "openai-api-key: sk-real-openai-key-not-substrate-shaped\n"
        "model: openai/gpt-4o\n",
        encoding="utf-8",
    )
    before = conf.read_bytes()

    result = AiderAgent().configure(_ctx())
    assert result.status == ResultStatus.ERROR
    assert (
        "user-owned" in result.message.lower()
        or "refused" in result.message.lower()
    )
    # File untouched.
    assert conf.read_bytes() == before


def test_refuses_to_overwrite_user_keys_without_marker(home_dir):
    """If marker absent AND any of our 3 keys are user-set, refuse."""
    (home_dir / ".aider.conf.yml").write_text(
        "openai-api-base: https://api.openai.com/v1\n"
        "openai-api-key: sk-openai-user-owned-xxxxxxxxxxxxxx\n"
        "model: openai/gpt-4o\n",
        encoding="utf-8",
    )
    result = AiderAgent().configure(_ctx())
    conf_data = _yaml().load((home_dir / ".aider.conf.yml").read_text(encoding="utf-8"))
    # User values must survive.
    assert conf_data["openai-api-base"] == "https://api.openai.com/v1"
    assert conf_data["openai-api-key"] == "sk-openai-user-owned-xxxxxxxxxxxxxx"
    assert conf_data["model"] == "openai/gpt-4o"
    assert "user-owned" in result.message.lower() or "refused" in result.message.lower()


def test_configure_is_idempotent(home_dir):
    AiderAgent().configure(_ctx())
    a = (home_dir / ".aider.conf.yml").read_text(encoding="utf-8")
    AiderAgent().configure(_ctx())
    assert (home_dir / ".aider.conf.yml").read_text(encoding="utf-8") == a


# ─── verify ─────────────────────────────────────────────────────────────────


def test_verify_reports_clean_after_configure(home_dir):
    AiderAgent().configure(_ctx())
    result = AiderAgent().verify(_ctx())
    assert result.status == ResultStatus.SUCCESS


def test_verify_reports_error_when_conf_missing(home_dir):
    result = AiderAgent().verify(_ctx())
    assert result.status == ResultStatus.ERROR


def test_verify_reports_error_when_marker_absent(home_dir):
    (home_dir / ".aider.conf.yml").write_text(
        "openai-api-base: https://gw.example/v1\n"
        "openai-api-key: sk-substrate-abcdefghijklmnopqrstuv\n"
        "model: anthropic/claude-sonnet-4-6\n",
        encoding="utf-8",
    )
    result = AiderAgent().verify(_ctx())
    assert result.status == ResultStatus.ERROR
    assert "not managed" in result.message or "marker" in result.message


def test_verify_reports_drift_when_base_url_changed(home_dir):
    AiderAgent().configure(_ctx())
    drifted = ConfigureContext(
        base_url="https://different.example/v1",
        api_key=VALID_KEY,
        catalog=SAMPLE_CATALOG,
        catalog_source="live",
        dry_run=False,
    )
    result = AiderAgent().verify(drifted)
    assert result.status == ResultStatus.ERROR
    assert "openai-api-base" in result.message


# ─── remove ─────────────────────────────────────────────────────────────────


def test_remove_strips_only_managed_keys(home_dir):
    """remove() deletes only the 3 managed keys + marker; user keys survive."""
    AiderAgent().configure(_ctx())
    # Add a user-owned key to the file post-configure.
    conf = home_dir / ".aider.conf.yml"
    text = conf.read_text(encoding="utf-8")
    conf.write_text(text + "dark-mode: true\n", encoding="utf-8")

    result = AiderAgent().remove(_ctx())
    assert result.status == ResultStatus.SUCCESS

    conf_data = _yaml().load(conf.read_text(encoding="utf-8"))
    assert "openai-api-base" not in conf_data
    assert "openai-api-key" not in conf_data
    assert "model" not in conf_data
    assert "_substrate_setup_managed_keys" not in conf_data
    # User key preserved.
    assert conf_data["dark-mode"] is True


def test_remove_strips_legacy_env(home_dir):
    """v0.1 wrote ~/.env. The 0.3.0 remove still strips substrate-shaped
    OPENAI_API_KEY lines from it (best-effort).

    Note: in 0.3.0, ~/.aider.model.metadata.json is a substrate-managed
    sidecar with its own marker discipline (see
    test_remove_deletes_metadata_when_marker_present and
    test_configure_refuses_when_user_metadata_lacks_marker). A
    pre-0.3.0-shaped metadata file without our new top-level marker is
    treated as user-owned and left alone.
    """
    AiderAgent().configure(_ctx())
    # Replace the substrate-written metadata.json with a 0.1-shape file
    # (no top-level marker) to assert it's preserved.
    legacy_meta = home_dir / ".aider.model.metadata.json"
    legacy_meta.write_text(
        json.dumps({"openai/anthropic/claude-sonnet-4-6": {"_substrate_managed": True}}),
        encoding="utf-8",
    )
    legacy_env = home_dir / ".env"
    legacy_env.write_text(f"OPENAI_API_KEY={VALID_KEY}\n", encoding="utf-8")

    result = AiderAgent().remove(_ctx())
    assert result.status == ResultStatus.SUCCESS

    # Unmarked metadata file is preserved (treated as user-owned).
    assert legacy_meta.exists()
    # Legacy .env: the substrate-shaped OPENAI_API_KEY value is stripped.
    if legacy_env.exists():
        env_text = legacy_env.read_text(encoding="utf-8")
        assert f"OPENAI_API_KEY={VALID_KEY}" not in env_text


def test_remove_skips_when_marker_absent(home_dir):
    """If marker missing, remove() must not delete user-owned keys."""
    (home_dir / ".aider.conf.yml").write_text(
        "openai-api-base: https://api.openai.com/v1\n"
        "openai-api-key: sk-openai-user-owned-xxxxxxxxxxxxxx\n"
        "model: openai/gpt-4o\n",
        encoding="utf-8",
    )
    result = AiderAgent().remove(_ctx())
    conf_data = _yaml().load((home_dir / ".aider.conf.yml").read_text(encoding="utf-8"))
    assert conf_data["openai-api-key"] == "sk-openai-user-owned-xxxxxxxxxxxxxx"
    assert result.status in (ResultStatus.SKIPPED, ResultStatus.ERROR)


def test_remove_skips_when_not_installed(home_dir):
    result = AiderAgent().remove(_ctx())
    assert result.status == ResultStatus.SKIPPED


# ─── metadata.json (0.3.0) ──────────────────────────────────────────────────


def test_writes_metadata_json_with_marker(home_dir):
    """The new ~/.aider.model.metadata.json file gets a top-level sentinel
    key plus one entry per chat-capable Substrate model. Keys use the
    `openai/<gateway_id>` form aider requires for OpenAI-compatible
    providers.
    """
    AiderAgent().configure(_ctx())

    meta_path = home_dir / ".aider.model.metadata.json"
    assert meta_path.exists()
    meta = json.loads(meta_path.read_text(encoding="utf-8"))

    assert meta.get("_substrate_setup_managed") is True
    # SAMPLE_CATALOG has 2 chat models (claude-sonnet-4-6, gpt-5.5).
    assert "openai/anthropic/claude-sonnet-4-6" in meta
    assert "openai/openai/gpt-5.5" in meta
    # Per-entry shape: litellm_provider=openai, mode=chat at minimum.
    entry = meta["openai/anthropic/claude-sonnet-4-6"]
    assert entry["litellm_provider"] == "openai"
    assert entry["mode"] == "chat"


def test_remove_deletes_metadata_when_marker_present(home_dir):
    AiderAgent().configure(_ctx())
    meta_path = home_dir / ".aider.model.metadata.json"
    assert meta_path.exists()

    result = AiderAgent().remove(_ctx())
    assert result.status == ResultStatus.SUCCESS
    assert not meta_path.exists()


def test_configure_refuses_when_user_metadata_lacks_marker(home_dir):
    """User-authored metadata files (no marker) must NOT be clobbered."""
    meta_path = home_dir / ".aider.model.metadata.json"
    user_meta = {"openai/some-other-model": {"litellm_provider": "openai", "mode": "chat"}}
    meta_path.write_text(json.dumps(user_meta), encoding="utf-8")

    result = AiderAgent().configure(_ctx())
    assert result.status == ResultStatus.ERROR
    # File untouched.
    assert json.loads(meta_path.read_text(encoding="utf-8")) == user_meta


def test_aider_configure_calls_env_persist(monkeypatch, home_dir):
    """Configure must persist the API key, not just print 'set it yourself'."""
    from substrate_setup import env_persist

    captured: list[str] = []

    def fake_persist(api_key: str) -> env_persist.PersistResult:
        captured.append(api_key)
        return env_persist.PersistResult(
            status=env_persist.PersistStatus.PERSISTED,
            message="test ok",
            path=None,
        )

    monkeypatch.setattr(
        "substrate_setup.agents.aider.persist_substrate_api_key", fake_persist
    )

    ctx = _ctx()
    AiderAgent().configure(ctx)

    assert captured == [VALID_KEY]


def test_metadata_excludes_image_gen_models(home_dir):
    """Image-gen entries (output_modality != 'text') must not appear in the
    metadata file — Aider routes chat completions only.
    """
    chat = CatalogEntry(
        id="openai/gpt-5.5", provider="openai",
        display_name="GPT-5.5", description="...",
    )
    image = CatalogEntry(
        id="openai/gpt-image-2", provider="openai",
        display_name="gpt-image-2", description="...",
        output_modality="image",
    )
    ctx = ConfigureContext(
        base_url="https://gw.example/v1",
        api_key=VALID_KEY,
        catalog=[chat, image],
        catalog_source="live",
        dry_run=False,
    )
    AiderAgent().configure(ctx)

    meta = json.loads(
        (home_dir / ".aider.model.metadata.json").read_text(encoding="utf-8")
    )
    assert "openai/openai/gpt-5.5" in meta
    assert "openai/openai/gpt-image-2" not in meta
