"""Tests for the Cursor handler (print-only — Cursor cannot be configured by writing files)."""
from __future__ import annotations

from substrate_setup.agents.base import ConfigureContext, ResultStatus
from substrate_setup.agents.cursor import CursorAgent
from substrate_setup.catalog import CatalogEntry
from substrate_setup.env_persist import PersistResult, PersistStatus

VALID_KEY = "sk-substrate-abcdefghijklmnopqrstuv"
SAMPLE_CATALOG = [
    CatalogEntry("anthropic/claude-sonnet-4-6", "anthropic", "Claude Sonnet 4.6", "x"),
    CatalogEntry("openai/gpt-5.5", "openai", "GPT-5.5", "x"),
]


def _ctx() -> ConfigureContext:
    return ConfigureContext(
        base_url="https://gw.example/v1",
        api_key=VALID_KEY,
        catalog=SAMPLE_CATALOG,
        catalog_source="live",
        dry_run=False,
    )


def test_detect_returns_none_when_no_cursor_dir(tmp_path, monkeypatch):
    monkeypatch.setenv("HOME", str(tmp_path))
    monkeypatch.setenv("USERPROFILE", str(tmp_path))
    monkeypatch.setenv("XDG_CONFIG_HOME", str(tmp_path / ".config"))
    monkeypatch.setenv("APPDATA", str(tmp_path / "AppData/Roaming"))
    assert CursorAgent().detect() is None


def test_detect_returns_user_data_dir_when_present(tmp_path, monkeypatch):
    monkeypatch.setenv("HOME", str(tmp_path))
    monkeypatch.setenv("USERPROFILE", str(tmp_path))
    monkeypatch.setenv("XDG_CONFIG_HOME", str(tmp_path / ".config"))
    monkeypatch.setenv("APPDATA", str(tmp_path / "AppData/Roaming"))
    cursor_dir = tmp_path / ".config" / "Cursor"
    cursor_dir.mkdir(parents=True)
    detected = CursorAgent().detect()
    assert detected == cursor_dir


def test_configure_prints_walkthrough_and_does_not_write(tmp_path, monkeypatch, capsys):
    monkeypatch.setenv("HOME", str(tmp_path))
    monkeypatch.setenv("USERPROFILE", str(tmp_path))
    monkeypatch.setenv("XDG_CONFIG_HOME", str(tmp_path / ".config"))
    monkeypatch.setenv("APPDATA", str(tmp_path / "AppData/Roaming"))
    (tmp_path / ".config" / "Cursor").mkdir(parents=True)

    monkeypatch.setattr(
        "substrate_setup.agents.cursor.persist_substrate_api_key",
        lambda key: PersistResult(
            status=PersistStatus.PERSISTED,
            message="patched in test",
            path=None,
        ),
    )

    result = CursorAgent().configure(_ctx())
    assert result.status == ResultStatus.PRINT_ONLY

    out = capsys.readouterr().out
    assert "Cursor detected" in out
    assert "https://gw.example/v1" in out
    assert VALID_KEY in out
    assert "anthropic/claude-sonnet-4-6" in out
    assert "openai/gpt-5.5" in out
    assert "WARNING" in out
    assert "Override OpenAI Base URL" in out
    # Verify no file was written under the Cursor dir.
    files = list((tmp_path / ".config" / "Cursor").rglob("*"))
    assert files == []


def test_verify_prints_cannot_verify_line(tmp_path, monkeypatch, capsys):
    monkeypatch.setenv("HOME", str(tmp_path))
    monkeypatch.setenv("USERPROFILE", str(tmp_path))
    monkeypatch.setenv("XDG_CONFIG_HOME", str(tmp_path / ".config"))
    monkeypatch.setenv("APPDATA", str(tmp_path / "AppData/Roaming"))
    (tmp_path / ".config" / "Cursor").mkdir(parents=True)
    result = CursorAgent().verify(_ctx())
    assert result.status == ResultStatus.PRINT_ONLY
    assert "cannot verify automatically" in capsys.readouterr().out


def test_remove_prints_inverse_walkthrough(tmp_path, monkeypatch, capsys):
    monkeypatch.setenv("HOME", str(tmp_path))
    monkeypatch.setenv("USERPROFILE", str(tmp_path))
    monkeypatch.setenv("XDG_CONFIG_HOME", str(tmp_path / ".config"))
    monkeypatch.setenv("APPDATA", str(tmp_path / "AppData/Roaming"))
    (tmp_path / ".config" / "Cursor").mkdir(parents=True)
    result = CursorAgent().remove(_ctx())
    assert result.status == ResultStatus.PRINT_ONLY
    out = capsys.readouterr().out
    assert "Toggle \"Override OpenAI Base URL\" OFF" in out


def test_cursor_configure_calls_env_persist(monkeypatch, tmp_path):
    """Configure must persist the API key, not just print 'set it yourself'."""
    from substrate_setup import env_persist

    monkeypatch.setenv("HOME", str(tmp_path))
    monkeypatch.setenv("USERPROFILE", str(tmp_path))
    (tmp_path / ".config" / "Cursor").mkdir(parents=True)

    captured: list[str] = []

    def fake_persist(api_key: str) -> env_persist.PersistResult:
        captured.append(api_key)
        return env_persist.PersistResult(
            status=env_persist.PersistStatus.PERSISTED,
            message="test ok",
            path=None,
        )

    monkeypatch.setattr(
        "substrate_setup.agents.cursor.persist_substrate_api_key", fake_persist
    )

    ctx = _ctx()
    CursorAgent().configure(ctx)

    assert captured == [VALID_KEY]


def test_walkthrough_excludes_image_gen_models(capsys):
    chat = CatalogEntry(
        id="openai/gpt-5.5", provider="openai",
        display_name="GPT-5.5", description="...",
    )
    image = CatalogEntry(
        id="openai/gpt-image-2", provider="openai",
        display_name="gpt-image-2", description="...",
        output_modality="image",
    )
    ctx = ConfigureContext(
        base_url="https://gw.example/v1",
        api_key=VALID_KEY,
        catalog=[chat, image],
        catalog_source="live",
        dry_run=False,
    )
    CursorAgent().configure(ctx)

    out = capsys.readouterr().out
    assert "openai/gpt-5.5" in out
    assert "openai/gpt-image-2" not in out
