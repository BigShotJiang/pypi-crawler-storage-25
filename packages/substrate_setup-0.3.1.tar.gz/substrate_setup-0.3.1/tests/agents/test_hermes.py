"""Tests for the Hermes agent handler (0.2.0 — inline `model:` schema)."""
from __future__ import annotations

import sys

import pytest
from ruamel.yaml import YAML
from substrate_setup.agents.base import ConfigureContext, ResultStatus
from substrate_setup.agents.hermes import HermesAgent
from substrate_setup.catalog import CatalogEntry

VALID_KEY = "sk-substrate-abcdefghijklmnopqrstuv"
SAMPLE_CATALOG = [
    CatalogEntry(
        id="anthropic/claude-sonnet-4-6",
        provider="anthropic",
        display_name="Claude Sonnet 4.6",
        description="Balanced quality and speed",
    ),
    CatalogEntry(
        id="openai/gpt-5.5",
        provider="openai",
        display_name="GPT-5.5",
        description="OpenAI flagship",
    ),
]


def _yaml() -> YAML:
    y = YAML()
    y.preserve_quotes = True
    return y


def _ctx(*, dry_run: bool = False) -> ConfigureContext:
    return ConfigureContext(
        base_url="https://gw.example/v1",
        api_key=VALID_KEY,
        catalog=SAMPLE_CATALOG,
        catalog_source="live",
        dry_run=dry_run,
    )


@pytest.fixture
def home_dir(tmp_path, monkeypatch):
    """Standard test layout.

    Forces sys.platform != "win32" so the adapter's "Unix" path
    (``~/.hermes/config.yaml``) is used for the body of tests; the
    Windows path resolution gets its own dedicated tests.
    """
    monkeypatch.setattr(sys, "platform", "linux")
    monkeypatch.setenv("HOME", str(tmp_path))
    monkeypatch.setenv("USERPROFILE", str(tmp_path))  # Path.home() on Windows
    monkeypatch.delenv("LOCALAPPDATA", raising=False)
    return tmp_path


# ─── detect ─────────────────────────────────────────────────────────────────


def test_detect_returns_none_when_hermes_not_installed(home_dir):
    assert HermesAgent().detect() is None


def test_detect_returns_unix_path_when_present(home_dir):
    hermes_dir = home_dir / ".hermes"
    hermes_dir.mkdir()
    (hermes_dir / "config.yaml").write_text("model: {}\n", encoding="utf-8")
    assert HermesAgent().detect() == hermes_dir / "config.yaml"


def test_detect_prefers_localappdata_on_windows(tmp_path, monkeypatch):
    """On Windows, %LOCALAPPDATA%\\hermes\\config.yaml takes precedence over ~/.hermes."""
    monkeypatch.setattr(sys, "platform", "win32")
    monkeypatch.setenv("USERPROFILE", str(tmp_path))
    monkeypatch.setenv("HOME", str(tmp_path))
    local_appdata = tmp_path / "AppData" / "Local"
    monkeypatch.setenv("LOCALAPPDATA", str(local_appdata))

    win_dir = local_appdata / "hermes"
    win_dir.mkdir(parents=True)
    (win_dir / "config.yaml").write_text("model: {}\n", encoding="utf-8")
    # Also create the legacy ~/.hermes/config.yaml to prove preference.
    legacy_dir = tmp_path / ".hermes"
    legacy_dir.mkdir()
    (legacy_dir / "config.yaml").write_text("model: {}\n", encoding="utf-8")

    detected = HermesAgent().detect()
    assert detected == win_dir / "config.yaml"


def test_detect_falls_back_to_home_when_localappdata_missing_on_windows(
    tmp_path, monkeypatch
):
    monkeypatch.setattr(sys, "platform", "win32")
    monkeypatch.setenv("USERPROFILE", str(tmp_path))
    monkeypatch.setenv("HOME", str(tmp_path))
    monkeypatch.setenv("LOCALAPPDATA", str(tmp_path / "no-local-appdata"))
    legacy_dir = tmp_path / ".hermes"
    legacy_dir.mkdir()
    (legacy_dir / "config.yaml").write_text("model: {}\n", encoding="utf-8")
    detected = HermesAgent().detect()
    assert detected == legacy_dir / "config.yaml"


def test_detect_finds_hermes_binary_on_path(home_dir, monkeypatch, tmp_path):
    """Default-flow fix: a pipx-installed Hermes that's never been run
    creates the binary on PATH but not ~/.hermes/config.yaml. detect()
    must still return truthy so the default `substrate-setup configure`
    pre-seeds the runtime config.
    """
    fake_bin_dir = tmp_path / "bin"
    fake_bin_dir.mkdir()
    fake_hermes = fake_bin_dir / "hermes"
    fake_hermes.write_text("#!/bin/sh\nexit 0\n", encoding="utf-8")
    fake_hermes.chmod(0o755)
    monkeypatch.setenv("PATH", str(fake_bin_dir))
    # No ~/.hermes/config.yaml — pure binary signal.
    assert not (home_dir / ".hermes" / "config.yaml").exists()
    detected = HermesAgent().detect()
    assert detected == fake_hermes


def test_detect_finds_source_checkout_in_cwd(
    home_dir, monkeypatch, tmp_path
):
    """Default-flow fix: when the user clones the Hermes repo and runs
    `substrate-setup configure` from inside that checkout, detect() must
    recognize the source-layout signature (cli-config.yaml.example +
    hermes_bootstrap.py side-by-side) even though the runtime config
    hasn't been created yet. This is the user-reported flow against
    ~/Desktop/Hermes.
    """
    src = tmp_path / "Hermes"
    src.mkdir()
    (src / "cli-config.yaml.example").write_text("model: {}\n", encoding="utf-8")
    (src / "hermes_bootstrap.py").write_text("# stub\n", encoding="utf-8")
    monkeypatch.chdir(src)
    assert HermesAgent().detect() == src


def test_detect_finds_source_checkout_in_parent(
    home_dir, monkeypatch, tmp_path
):
    """Source-checkout detection must walk up so running from a subdir
    of the cloned repo still works (e.g., ~/Desktop/Hermes/agent)."""
    src = tmp_path / "Hermes"
    sub = src / "agent"
    sub.mkdir(parents=True)
    (src / "cli-config.yaml.example").write_text("model: {}\n", encoding="utf-8")
    (src / "hermes_bootstrap.py").write_text("# stub\n", encoding="utf-8")
    monkeypatch.chdir(sub)
    assert HermesAgent().detect() == src


def test_detect_ignores_partial_source_signature(
    home_dir, monkeypatch, tmp_path
):
    """One signature file alone must not be enough — both files together
    are required to claim a directory is a Hermes source checkout. Avoids
    false positives in unrelated projects that happen to have a
    cli-config.yaml.example."""
    dir_with_one = tmp_path / "not-hermes"
    dir_with_one.mkdir()
    (dir_with_one / "cli-config.yaml.example").write_text("model: {}\n")
    monkeypatch.chdir(dir_with_one)
    assert HermesAgent().detect() is None


# ─── configure ──────────────────────────────────────────────────────────────


def test_writes_inline_model_block(home_dir):
    """Configure must mutate the inline `model:` block, not `custom_providers:`."""
    result = HermesAgent().configure(_ctx())
    assert result.status == ResultStatus.SUCCESS

    cfg = home_dir / ".hermes" / "config.yaml"
    assert cfg.exists()

    payload = _yaml().load(cfg.read_text(encoding="utf-8"))

    # No custom_providers list written.
    assert "custom_providers" not in payload

    # Inline model: block populated.
    model = payload["model"]
    assert model["provider"] == "custom"
    assert model["base_url"] == "https://gw.example/v1"
    assert model["api_key"] == VALID_KEY
    # default = first catalog entry id (chat-capable)
    assert model["default"] == "anthropic/claude-sonnet-4-6"

    # Top-level marker present, listing the keys we own.
    assert payload["_substrate_setup_managed_keys"] == [
        "model.default",
        "model.provider",
        "model.api_key",
        "model.base_url",
        "model_catalog.providers.substrate.url",
    ]


def test_preserves_user_model_keys(home_dir):
    """User-set keys under model: (context_length, max_tokens, …) must survive."""
    hermes_dir = home_dir / ".hermes"
    hermes_dir.mkdir()
    (hermes_dir / "config.yaml").write_text(
        """\
model:
  default: "gpt-5.4-nano"
  provider: "custom"
  api_key: "sk-substrate-old-but-shaped-like-substratexx"
  base_url: "https://old.example/v1"
  context_length: 200000
  max_tokens: 8192
  reasoning_effort: "medium"
tools:
  enable_web_search: false
_substrate_setup_managed_keys:
  - "model.default"
  - "model.provider"
  - "model.api_key"
  - "model.base_url"
""",
        encoding="utf-8",
    )

    HermesAgent().configure(_ctx())

    payload = _yaml().load((hermes_dir / "config.yaml").read_text(encoding="utf-8"))
    model = payload["model"]
    # Substrate-managed keys updated.
    assert model["api_key"] == VALID_KEY
    assert model["base_url"] == "https://gw.example/v1"
    assert model["provider"] == "custom"
    # User keys preserved.
    assert model["context_length"] == 200000
    assert model["max_tokens"] == 8192
    assert model["reasoning_effort"] == "medium"
    # Other top-level keys preserved.
    assert payload["tools"]["enable_web_search"] is False


def test_auto_claim_when_shape_matches_unmarked(home_dir):
    """If model.* already looks substrate-shaped (provider=custom,
    base_url == ctx.base_url, api_key startswith sk-substrate-) but the
    marker is absent, configure() should SUCCEED, write the marker, and
    keep/refresh the keys. This is the upgrade-from-0.1 / manually-fixed
    case Frank hit; the prior refusal was UX friction with no safety
    benefit (we'd be overwriting our own shape with our own shape).
    """
    hermes_dir = home_dir / ".hermes"
    hermes_dir.mkdir()
    # Substrate-shaped values, BUT no _substrate_setup_managed_keys marker.
    (hermes_dir / "config.yaml").write_text(
        """\
model:
  default: "anthropic/claude-sonnet-4-6"
  provider: "custom"
  api_key: "sk-substrate-prior-key-shaped-like-substrate"
  base_url: "https://gw.example/v1"
""",
        encoding="utf-8",
    )
    result = HermesAgent().configure(_ctx())
    assert result.status == ResultStatus.SUCCESS

    payload = _yaml().load(
        (hermes_dir / "config.yaml").read_text(encoding="utf-8")
    )
    # Marker now present (upgraded to 0.3.0 list on reconfigure).
    assert payload["_substrate_setup_managed_keys"] == [
        "model.default",
        "model.provider",
        "model.api_key",
        "model.base_url",
        "model_catalog.providers.substrate.url",
    ]
    # Keys present (api_key refreshed to ctx.api_key).
    model = payload["model"]
    assert model["provider"] == "custom"
    assert model["base_url"] == "https://gw.example/v1"
    assert model["api_key"] == VALID_KEY
    assert model["default"] == "anthropic/claude-sonnet-4-6"


def test_still_refuses_truly_user_owned(home_dir):
    """Marker absent + shape does NOT look substrate (openai provider,
    api.openai.com base_url, non-sk-substrate key) -> still ERROR + no
    write. Belt-and-suspenders for the auto-claim split.
    """
    hermes_dir = home_dir / ".hermes"
    hermes_dir.mkdir()
    cfg = hermes_dir / "config.yaml"
    cfg.write_text(
        """\
model:
  default: "gpt-4o"
  provider: "openai"
  api_key: "sk-real-openai-key-not-substrate-shaped"
  base_url: "https://api.openai.com/v1"
""",
        encoding="utf-8",
    )
    before = cfg.read_bytes()

    result = HermesAgent().configure(_ctx())
    assert result.status == ResultStatus.ERROR
    assert "user-owned" in result.message.lower() or "refused" in result.message.lower()
    # File untouched.
    assert cfg.read_bytes() == before


def test_refuses_to_overwrite_user_model_without_marker(home_dir):
    """If marker absent AND model.provider is user-set non-substrate value, refuse."""
    hermes_dir = home_dir / ".hermes"
    hermes_dir.mkdir()
    (hermes_dir / "config.yaml").write_text(
        """\
model:
  default: "gpt-4o"
  provider: "openai"
  api_key: "sk-openai-user-owned-key"
  base_url: "https://api.openai.com/v1"
""",
        encoding="utf-8",
    )
    result = HermesAgent().configure(_ctx())
    # The substrate keys must NOT have been overwritten.
    payload = _yaml().load((hermes_dir / "config.yaml").read_text(encoding="utf-8"))
    assert payload["model"]["provider"] == "openai"
    assert payload["model"]["api_key"] == "sk-openai-user-owned-key"
    assert payload["model"]["base_url"] == "https://api.openai.com/v1"
    # The result message must flag this.
    assert "user-owned" in result.message.lower() or "refused" in result.message.lower()


def test_creates_config_when_missing(home_dir):
    """Configure creates ~/.hermes/config.yaml from nothing."""
    result = HermesAgent().configure(_ctx())
    assert result.status == ResultStatus.SUCCESS

    cfg = home_dir / ".hermes" / "config.yaml"
    assert cfg.exists()
    payload = _yaml().load(cfg.read_text(encoding="utf-8"))
    assert payload["model"]["api_key"] == VALID_KEY


def test_no_env_file_written(home_dir):
    """0.2.0 drops the .env credential write entirely (api_key is inline)."""
    HermesAgent().configure(_ctx())
    env_path = home_dir / ".hermes" / ".env"
    assert not env_path.exists()


def test_configure_is_idempotent(home_dir):
    HermesAgent().configure(_ctx())
    snapshot_after_first = (
        home_dir / ".hermes" / "config.yaml"
    ).read_text(encoding="utf-8")
    HermesAgent().configure(_ctx())
    snapshot_after_second = (
        home_dir / ".hermes" / "config.yaml"
    ).read_text(encoding="utf-8")
    assert snapshot_after_first == snapshot_after_second


# ─── verify ─────────────────────────────────────────────────────────────────


def test_verify_reports_clean_after_configure(home_dir):
    HermesAgent().configure(_ctx())
    result = HermesAgent().verify(_ctx())
    assert result.status == ResultStatus.SUCCESS


def test_verify_reports_error_when_config_missing(home_dir):
    result = HermesAgent().verify(_ctx())
    assert result.status == ResultStatus.ERROR


def test_verify_reports_error_when_marker_absent(home_dir):
    hermes_dir = home_dir / ".hermes"
    hermes_dir.mkdir()
    (hermes_dir / "config.yaml").write_text(
        """\
model:
  default: "anthropic/claude-sonnet-4-6"
  provider: "custom"
  api_key: "sk-substrate-old-but-shaped-like-substratexx"
  base_url: "https://gw.example/v1"
""",
        encoding="utf-8",
    )
    result = HermesAgent().verify(_ctx())
    assert result.status == ResultStatus.ERROR
    assert "not managed" in result.message or "marker" in result.message


def test_verify_reports_drift_when_base_url_changed(home_dir):
    HermesAgent().configure(_ctx())
    drifted = ConfigureContext(
        base_url="https://different.example/v1",
        api_key=VALID_KEY,
        catalog=SAMPLE_CATALOG,
        catalog_source="live",
        dry_run=False,
    )
    result = HermesAgent().verify(drifted)
    assert result.status == ResultStatus.ERROR
    assert "base_url" in result.message


# ─── remove ─────────────────────────────────────────────────────────────────


def test_remove_strips_only_managed_keys(home_dir):
    """remove() must delete only the 4 managed model.* keys + the marker;
    other model keys (user-owned) must survive."""
    hermes_dir = home_dir / ".hermes"
    hermes_dir.mkdir()
    (hermes_dir / "config.yaml").write_text(
        """\
model:
  default: "anthropic/claude-sonnet-4-6"
  provider: "custom"
  api_key: "sk-substrate-old-but-shaped-like-substratexx"
  base_url: "https://gw.example/v1"
  context_length: 200000
  max_tokens: 8192
tools:
  enable_web_search: false
_substrate_setup_managed_keys:
  - "model.default"
  - "model.provider"
  - "model.api_key"
  - "model.base_url"
""",
        encoding="utf-8",
    )
    result = HermesAgent().remove(_ctx())
    assert result.status == ResultStatus.SUCCESS

    payload = _yaml().load((hermes_dir / "config.yaml").read_text(encoding="utf-8"))
    # The 4 managed model.* keys gone.
    assert "default" not in payload["model"]
    assert "provider" not in payload["model"]
    assert "api_key" not in payload["model"]
    assert "base_url" not in payload["model"]
    # User-owned model.* keys preserved.
    assert payload["model"]["context_length"] == 200000
    assert payload["model"]["max_tokens"] == 8192
    # Marker gone.
    assert "_substrate_setup_managed_keys" not in payload
    # Other top-level user keys preserved.
    assert payload["tools"]["enable_web_search"] is False


def test_remove_skips_when_not_installed(home_dir):
    result = HermesAgent().remove(_ctx())
    assert result.status == ResultStatus.SKIPPED


def test_remove_refuses_when_marker_absent(home_dir):
    """If the marker is missing, remove() must NOT delete keys it can't claim."""
    hermes_dir = home_dir / ".hermes"
    hermes_dir.mkdir()
    (hermes_dir / "config.yaml").write_text(
        """\
model:
  default: "gpt-4o"
  provider: "openai"
  api_key: "sk-openai-user-owned-key"
  base_url: "https://api.openai.com/v1"
""",
        encoding="utf-8",
    )
    result = HermesAgent().remove(_ctx())
    # The user keys must NOT have been removed.
    payload = _yaml().load((hermes_dir / "config.yaml").read_text(encoding="utf-8"))
    assert payload["model"]["provider"] == "openai"
    assert payload["model"]["api_key"] == "sk-openai-user-owned-key"
    # Result should communicate this clearly.
    assert result.status in (ResultStatus.SKIPPED, ResultStatus.ERROR)


def test_malformed_yaml_returns_clean_error_not_stacktrace(home_dir):
    """Frank's own Hermes config.yaml has a malformed quoted-string from
    an earlier round-trip mangling a kaomoji. Configure/verify/remove must
    surface a one-liner instead of a ruamel.yaml stacktrace, and must NOT
    write to the broken file.
    """
    hermes_dir = home_dir / ".hermes"
    hermes_dir.mkdir()
    bad = hermes_dir / "config.yaml"
    # Unterminated double-quote scalar — same shape as the real-world breakage.
    bad.write_text(
        'model:\n  default: "anthropic/claude\n  provider: custom\n',
        encoding="utf-8",
    )
    bad_before = bad.read_bytes()

    cfg = HermesAgent().configure(_ctx())
    assert cfg.status == ResultStatus.ERROR
    assert "not valid YAML" in cfg.message
    # File untouched.
    assert bad.read_bytes() == bad_before

    ver = HermesAgent().verify(_ctx())
    assert ver.status == ResultStatus.ERROR
    assert "not valid YAML" in ver.message

    rem = HermesAgent().remove(_ctx())
    assert rem.status == ResultStatus.ERROR
    assert "not valid YAML" in rem.message
    assert bad.read_bytes() == bad_before


def test_configure_chmods_0600_on_posix(home_dir, monkeypatch):
    """Inline api_key shouldn't be world-readable. Verify os.chmod is called
    with 0o600 on POSIX; checking the resulting mode bits directly is
    unreliable on Windows test runners (Windows reports 0o666 for any
    regular file regardless of os.chmod arguments).
    """
    import os as _os

    monkeypatch.setattr(sys, "platform", "linux")
    calls: list[tuple[str, int]] = []
    real_chmod = _os.chmod

    def recorder(path, mode, *args, **kwargs):
        calls.append((str(path), mode))
        try:
            return real_chmod(path, mode, *args, **kwargs)
        except OSError:
            pass

    monkeypatch.setattr(_os, "chmod", recorder)
    HermesAgent().configure(_ctx())
    cfg = home_dir / ".hermes" / "config.yaml"
    matching = [c for c in calls if c[0] == str(cfg) and c[1] == 0o600]
    assert matching, f"expected os.chmod({cfg}, 0o600); calls were {calls}"


def test_configure_skips_chmod_on_windows(home_dir, monkeypatch):
    """On Windows the chmod helper short-circuits — POSIX mode bits don't apply."""
    import os as _os

    monkeypatch.setattr(sys, "platform", "win32")
    calls: list[tuple[str, int]] = []
    real_chmod = _os.chmod

    def recorder(path, mode, *args, **kwargs):
        calls.append((str(path), mode))
        return real_chmod(path, mode, *args, **kwargs)

    monkeypatch.setattr(_os, "chmod", recorder)
    HermesAgent().configure(_ctx())
    cfg_path_unix = home_dir / ".hermes" / "config.yaml"
    matching = [c for c in calls if c[0] == str(cfg_path_unix)]
    assert not matching, f"expected no chmod on win32; got {matching}"


def test_writes_model_catalog_substrate_url(home_dir):
    result = HermesAgent().configure(_ctx())
    assert result.status == ResultStatus.SUCCESS

    cfg = home_dir / ".hermes" / "config.yaml"
    payload = _yaml().load(cfg.read_text(encoding="utf-8"))

    # The new catalog-URL key under model_catalog.providers.substrate.
    mc = payload.get("model_catalog") or {}
    providers = mc.get("providers") or {}
    substrate = providers.get("substrate") or {}
    assert substrate.get("url") == "https://gw.example/v1/agent-catalogs/hermes.json"


def test_marker_includes_catalog_url_key(home_dir):
    HermesAgent().configure(_ctx())
    cfg = home_dir / ".hermes" / "config.yaml"
    payload = _yaml().load(cfg.read_text(encoding="utf-8"))
    assert payload["_substrate_setup_managed_keys"] == [
        "model.default",
        "model.provider",
        "model.api_key",
        "model.base_url",
        "model_catalog.providers.substrate.url",
    ]


def test_hermes_configure_calls_env_persist(monkeypatch, home_dir):
    """Configure must persist the API key, not just print 'set it yourself'."""
    from substrate_setup import env_persist

    captured: list[str] = []

    def fake_persist(api_key: str) -> env_persist.PersistResult:
        captured.append(api_key)
        return env_persist.PersistResult(
            status=env_persist.PersistStatus.PERSISTED,
            message="test ok",
            path=None,
        )

    monkeypatch.setattr(
        "substrate_setup.agents.hermes.persist_substrate_api_key", fake_persist
    )

    ctx = _ctx()
    HermesAgent().configure(ctx)

    assert captured == [VALID_KEY]


def test_remove_strips_catalog_url(home_dir):
    HermesAgent().configure(_ctx())
    result = HermesAgent().remove(_ctx())
    assert result.status == ResultStatus.SUCCESS

    cfg = home_dir / ".hermes" / "config.yaml"
    payload = _yaml().load(cfg.read_text(encoding="utf-8"))

    # The model_catalog block may still exist (if user had other keys under
    # it), but the substrate URL specifically must be gone.
    mc = payload.get("model_catalog") or {}
    providers = mc.get("providers") or {}
    assert "substrate" not in providers
