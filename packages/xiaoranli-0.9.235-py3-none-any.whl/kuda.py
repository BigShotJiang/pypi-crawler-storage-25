from __future__ import annotations

import argparse
import json
import os
from collections import Counter
from dataclasses import dataclass
from datetime import datetime, timedelta, timezone
from typing import Any, Callable, Dict, List, Optional, Set, Tuple
from urllib.parse import quote, urlparse

DEFAULT_APIM_CLUSTER_URL = "https://cogsvc.kusto.windows.net"
DEFAULT_APIM_DATABASE = "Platform"
DEFAULT_SINGULARITY_CLUSTER_URL = "https://aiscprodkusto.westus2.kusto.windows.net"
DEFAULT_SINGULARITY_DATABASE = "logs"

DEFAULT_WORKSPACE = "Vienna"
DEFAULT_TABLE = "AMLManagedComputeLogs"
DEFAULT_APIM_TABLE = "TraceCallResult"
DEFAULT_FRONTDOOR_TABLE = "AzureMLFrontdoorAccessLog"
DEFAULT_REQUESTS_TABLE = "requests"
DEFAULT_TRACES_TABLE = "traces"
DEFAULT_SINGULARITY_TRACES_FUNCTION = "ContainerTraces_allEnvironments()"

KUSTO_SCOPE = "https://kusto.kusto.windows.net/.default"
KUSTO_WEB_UI_BASE_URL = "https://dataexplorer.azure.com"
KUSTO_CLUSTER_HOST_SUFFIX = ".kusto.windows.net"

DEFAULT_INVESTIGATION_LOOKBACK = "2h"
DEFAULT_REQUEST_TRACE_LOOKBACK = "7d"
DEFAULT_RESOLVE_LOOKBACK = "24h"
REQUEST_TRACE_WINDOW_MINUTES = 30
CLIENT_CONNECTION_FAILURE = "ClientConnectionFailure"

# Local MaaS monitoring docs map these regions to the closest Vienna clusters.
VIENNA_REGION_CLUSTER_URLS = {
    "canadacentral": "https://viennacac.canadacentral.kusto.windows.net",
    "eastus": "https://viennause.kusto.windows.net",
    "eastus2": "https://viennause2.eastus2.kusto.windows.net",
    "francecentral": "https://viennafc.francecentral.kusto.windows.net",
    "germanywestcentral": "https://viennadewc.germanywestcentral.kusto.windows.net",
    "northcentralus": "https://viennausnc.northcentralus.kusto.windows.net",
    "southcentralus": "https://viennaussc.kusto.windows.net",
    "swedencentral": "https://viennasec.swedencentral.kusto.windows.net",
    "uksouth": "https://viennauks.uksouth.kusto.windows.net",
    "westus": "https://viennausw.westus.kusto.windows.net",
    "westus2": "https://viennausw.westus.kusto.windows.net",
    "westus3": "https://viennausw3.westus.kusto.windows.net",
}

LOG_SIGNAL_RULES = (
    (
        "model_load_failure",
        (
            "model load failed",
            "failed to load model",
            "exception while loading model",
            "error while loading model",
            "missing weights",
        ),
    ),
    (
        "oom",
        (
            "out of memory",
            "cuda out of memory",
            "oom",
        ),
    ),
    (
        "health_probe_failure",
        (
            "health probe failed",
            "readiness probe failed",
            "liveness probe failed",
        ),
    ),
    (
        "timeout",
        (
            "timed out",
            "timeout",
        ),
    ),
    (
        "client_disconnect",
        (
            "client connection failure",
            "clientconnectionfailure",
            "user cancelled request",
            "client disconnected",
            "broken pipe",
        ),
    ),
    (
        "crash",
        (
            "segmentation fault",
            "crashloop",
            "terminated unexpectedly",
            "fatal error",
        ),
    ),
    (
        "generic_error",
        (
            "traceback",
            "exception",
            "error",
            "failed",
        ),
    ),
)


@dataclass(frozen=True)
class KustoConnectionConfig:
    cluster_url: str
    database: str


@dataclass(frozen=True)
class QueryExecutionResult:
    rows: List[Dict[str, Any]]

    @property
    def row_count(self) -> int:
        return len(self.rows)


@dataclass(frozen=True)
class QueryFilters:
    endpoint: str
    deployment: str
    lookback: str = "2h"
    container: Optional[str] = None


@dataclass(frozen=True)
class ResolveFilters:
    endpoint: Optional[str] = None
    deployment: Optional[str] = None
    lookback: str = "24h"


@dataclass(frozen=True)
class RequestTraceFilters:
    apim_request_id: str
    lookback: str = "7d"


@dataclass(frozen=True)
class QueryTimeRange:
    start: str
    end: str


@dataclass(frozen=True)
class InvestigationRequest:
    endpoint: Optional[str] = None
    deployment: Optional[str] = None
    lookback: str = DEFAULT_INVESTIGATION_LOOKBACK
    resolve_lookback: str = DEFAULT_RESOLVE_LOOKBACK
    limit: Optional[int] = None


@dataclass(frozen=True)
class RequestTraceRequest:
    apim_request_id: str
    lookback: str = DEFAULT_REQUEST_TRACE_LOOKBACK


@dataclass(frozen=True)
class ResolvedTarget:
    endpoint: str
    deployment: str
    containers: List[str]
    latest_timestamp: Optional[str]
    candidate_count: int


@dataclass(frozen=True)
class InvestigationAnalysis:
    summary: str
    suspected_root_cause: Optional[str]
    affected_containers: List[str]
    error_row_count: int
    signal_counts: Dict[str, int]
    evidence_lines: List[str]


@dataclass(frozen=True)
class InvestigationResult:
    target: ResolvedTarget
    analysis: InvestigationAnalysis
    resolve_query: str
    query: str
    rows: List[Dict[str, Any]]

    @property
    def row_count(self) -> int:
        return len(self.rows)


@dataclass(frozen=True)
class RequestTraceTarget:
    apim_request_id: str
    x_request_id: Optional[str]
    nexus_request_id: Optional[str]
    model_name: Optional[str]
    apim_region: Optional[str]
    nexus_region: Optional[str]
    backend_endpoint: Optional[str]
    backend_region: Optional[str]
    endpoint: Optional[str]
    deployment: Optional[str]


@dataclass(frozen=True)
class RequestTraceAnalysis:
    summary: str
    root_cause_layer: Optional[str]
    suspected_root_cause: Optional[str]
    evidence_lines: List[str]
    container_signal_counts: Dict[str, int]
    trace_signal_counts: Dict[str, int]
    structured_summary: Dict[str, str]


@dataclass(frozen=True)
class RequestTraceResult:
    target: RequestTraceTarget
    analysis: RequestTraceAnalysis
    anchor_timestamp: str
    window_start: str
    window_end: str
    apim_query: str
    nexus_query: str
    traces_query: Optional[str]
    frontdoor_query: Optional[str]
    container_query: Optional[str]
    apim_rows: List[Dict[str, Any]]
    nexus_rows: List[Dict[str, Any]]
    trace_rows: List[Dict[str, Any]]
    frontdoor_rows: List[Dict[str, Any]]
    container_rows: List[Dict[str, Any]]

    @property
    def layer_row_counts(self) -> Dict[str, int]:
        return {
            "apim": len(self.apim_rows),
            "nexus": len(self.nexus_rows),
            "traces": len(self.trace_rows),
            "frontdoor": len(self.frontdoor_rows),
            "container": len(self.container_rows),
        }


@dataclass(frozen=True)
class TraceEvidenceAnalysis:
    suspected_root_cause: Optional[str]
    signal_counts: Dict[str, int]
    evidence_lines: List[str]


def load_connection_config(
    cluster_url: Optional[str] = None,
    database: Optional[str] = None,
) -> KustoConnectionConfig:
    resolved_cluster_url = cluster_url or os.getenv("XIAORANLI_KUDA_CLUSTER_URL")
    resolved_database = database or os.getenv("XIAORANLI_KUDA_DATABASE")

    missing = [
        env_name
        for env_name, value in (
            ("XIAORANLI_KUDA_CLUSTER_URL", resolved_cluster_url),
            ("XIAORANLI_KUDA_DATABASE", resolved_database),
        )
        if not value
    ]
    if missing:
        missing_text = ", ".join(missing)
        raise ValueError("Missing required Kusto connection setting(s): {0}".format(missing_text))

    return KustoConnectionConfig(
        cluster_url=resolved_cluster_url,
        database=resolved_database,
    )


def load_apim_connection_config(
    cluster_url: Optional[str] = None,
    database: Optional[str] = None,
) -> KustoConnectionConfig:
    resolved_cluster_url = cluster_url or os.getenv("XIAORANLI_KUDA_APIM_CLUSTER_URL") or DEFAULT_APIM_CLUSTER_URL
    resolved_database = database or os.getenv("XIAORANLI_KUDA_APIM_DATABASE") or DEFAULT_APIM_DATABASE
    return KustoConnectionConfig(
        cluster_url=resolved_cluster_url,
        database=resolved_database,
    )


def load_singularity_connection_config(
    cluster_url: Optional[str] = None,
    database: Optional[str] = None,
) -> KustoConnectionConfig:
    resolved_cluster_url = (
        cluster_url or os.getenv("XIAORANLI_KUDA_SINGULARITY_CLUSTER_URL") or DEFAULT_SINGULARITY_CLUSTER_URL
    )
    resolved_database = database or os.getenv("XIAORANLI_KUDA_SINGULARITY_DATABASE") or DEFAULT_SINGULARITY_DATABASE
    return KustoConnectionConfig(
        cluster_url=resolved_cluster_url,
        database=resolved_database,
    )


def build_kusto_web_link(config: KustoConnectionConfig) -> str:
    parsed_cluster_url = urlparse(config.cluster_url)
    cluster_host = parsed_cluster_url.netloc or parsed_cluster_url.path
    normalized_cluster = cluster_host.rstrip("/")
    if normalized_cluster.endswith(KUSTO_CLUSTER_HOST_SUFFIX):
        normalized_cluster = normalized_cluster[: -len(KUSTO_CLUSTER_HOST_SUFFIX)]
    encoded_database = quote(config.database, safe="")
    return (
        "{0}/clusters/{1}/databases/{2}".format(
            KUSTO_WEB_UI_BASE_URL,
            quote(normalized_cluster, safe=""),
            encoded_database,
        )
    )


def check_authentication() -> str:
    credential = _build_credential()
    try:
        credential.get_token(KUSTO_SCOPE)
    except Exception as exc:  # pragma: no cover - requires Azure runtime
        raise RuntimeError(_format_auth_error(exc))
    return "Azure authentication is ready"


def execute_query(config: KustoConnectionConfig, query: str) -> QueryExecutionResult:
    credential = _build_credential()

    try:
        from azure.kusto.data import KustoClient, KustoConnectionStringBuilder

        kcsb = KustoConnectionStringBuilder.with_azure_token_credential(
            config.cluster_url,
            credential,
        )
        client = KustoClient(kcsb)
        response = client.execute(config.database, query)
        primary_result = response.primary_results[0]
        rows = primary_result.to_dict().get("data", [])
        return QueryExecutionResult(rows=rows)
    except Exception as exc:  # pragma: no cover - requires Azure runtime
        raise RuntimeError("Kusto query failed: {0}".format(exc))


def _build_credential():
    from azure.identity import (
        AzureCliCredential,
        ChainedTokenCredential,
        DefaultAzureCredential,
    )

    return ChainedTokenCredential(
        AzureCliCredential(),
        DefaultAzureCredential(),
    )


def _format_auth_error(exc: Exception) -> str:
    message = str(exc)
    if "az login" in message or "Azure CLI" in message:
        return "Azure authentication failed. Run 'az login' and retry."
    return "Azure authentication failed. Run 'az login' and retry. Original error: {0}".format(message)


def build_logs_query(filters: QueryFilters) -> str:
    lines = _base_query_lines(filters)
    if filters.container:
        lines.append("| where Container == {0}".format(_kql_string(filters.container)))
    lines.extend(
        [
            "| project PreciseTimeStamp, Container, onlineEndpointName, deploymentName, log",
            "| order by PreciseTimeStamp desc",
        ]
    )
    return "\n".join(lines)


def build_list_containers_query(filters: QueryFilters) -> str:
    return "\n".join(
        [
            *_base_query_lines(filters),
            "| distinct Container",
            "| order by Container asc",
        ]
    )


def build_resolve_targets_query(filters: ResolveFilters) -> str:
    if not filters.endpoint and not filters.deployment:
        raise ValueError("resolve query requires endpoint or deployment")

    lines = [
        _union_all_logs(DEFAULT_TABLE),
        _lookback_line("PreciseTimeStamp", filters.lookback),
    ]
    if filters.endpoint:
        lines.append("| where onlineEndpointName == {0}".format(_kql_string(filters.endpoint)))
    if filters.deployment:
        lines.append("| where deploymentName == {0}".format(_kql_string(filters.deployment)))
    lines.extend(
        [
            "| summarize latestTimestamp=max(PreciseTimeStamp) by onlineEndpointName, deploymentName, Container",
            "| order by latestTimestamp desc, onlineEndpointName asc, deploymentName asc, Container asc",
        ]
    )
    return "\n".join(lines)


def build_application_snapshots_query(*, endpoint: str, deployment: str, lookback: str = "2h") -> str:
    return "\n".join(
        [
            "ApplicationSnapshots_allEnvironments",
            _lookback_line("PreciseTimeStamp", lookback),
            "| where OnlineEndpoint == {0}".format(_kql_string(endpoint)),
            "| where Deployment == {0}".format(_kql_string(deployment)),
            "| project PreciseTimeStamp, Tenant, InstanceId, OnlineEndpoint, Deployment, Ready, Status",
            "| order by PreciseTimeStamp desc",
        ]
    )


def build_pod_snapshots_query(*, endpoint: str, deployment: str, lookback: str = "2h") -> str:
    return "\n".join(
        [
            "PodSnapshots_allEnvironments",
            _lookback_line("PreciseTimeStamp", lookback),
            "| where OnlineEndpoint == {0}".format(_kql_string(endpoint)),
            "| where Deployment == {0}".format(_kql_string(deployment)),
            "| project PreciseTimeStamp, Tenant, InstanceId, PodName, ContainerName, Ready, Phase, AllContainerRestarts, MainContainerRestarts, ReadyAt, PodStatus",
            "| order by PreciseTimeStamp desc",
        ]
    )


def build_kubernetes_events_query(*, endpoint: str, deployment: str, lookback: str = "2h") -> str:
    return "\n".join(
        [
            "KubernetesEvents_allEnvironments",
            _lookback_line("PreciseTimeStamp", lookback),
            "| where OnlineEndpoint == {0}".format(_kql_string(endpoint)),
            "| where Deployment == {0}".format(_kql_string(deployment)),
            "| project PreciseTimeStamp, Tenant, InstanceId, PodName, EventType, Reason, Message",
            "| order by PreciseTimeStamp desc",
        ]
    )


def build_apim_request_query(filters: RequestTraceFilters) -> str:
    return "\n".join(
        [
            DEFAULT_APIM_TABLE,
            _lookback_line("TIMESTAMP", filters.lookback),
            '| where ApiId has "maas" or ApiId has "anthropic" or ApiId contains "openai-api" or ApiId contains "azure-ai-providers"',
            "| where RequestId == {0}".format(_kql_string(filters.apim_request_id)),
            '| extend model_name = iff(ApiId contains "azure-ai-providers", tostring(parse_json(ExtraData)["provider-backend-object"]["name"]), iff(ApiId has "anthropic", "anthropic", tostring(parse_json(ExtraData)["openai-model-name"])))',
            '| extend apimErrorReason = tostring(parse_json(ApimError)["Reason"])',
            "| project TIMESTAMP, RequestId, ResponseCode, Location, ApiId, DeploymentId, BackendUrl, model_name, apimErrorReason, ApimError, ExtraData",
            "| order by TIMESTAMP desc",
        ]
    )


def build_nexus_request_query(
    filters: RequestTraceFilters,
    *,
    time_range: Optional[QueryTimeRange] = None,
) -> str:
    return "\n".join(
        [
            _union_all_logs(DEFAULT_REQUESTS_TABLE),
            _time_filter_line("timestamp", lookback=filters.lookback, time_range=time_range),
            "| where Container == 'nexus'",
            '| extend apimRequestId = tostring(customDimensions["apim-request-id"])',
            "| where apimRequestId == {0}".format(_kql_string(filters.apim_request_id)),
            '| extend xRequestId = tostring(customDimensions["X-Request-ID"])',
            '| extend model_name = tostring(customDimensions["model_name"])',
            '| extend status_code = toint(customDimensions["status_code"])',
            '| extend error_code = tostring(customDimensions["error_code"])',
            '| extend endpoint = tostring(customDimensions["endpoint"])',
            '| extend azureRegion = tostring(customDimensions["AzureRegion"])',
            '| extend model_error_message = tostring(customDimensions["model_error_message"])',
            '| extend is_streaming = tostring(customDimensions["is_streaming"])',
            "| project timestamp, id, resultCode, apimRequestId, xRequestId, model_name, status_code, error_code, endpoint, azureRegion, model_error_message, is_streaming, customDimensions",
            "| order by timestamp desc",
        ]
    )


def build_nexus_traces_query(
    nexus_operation_id: str,
    *,
    lookback: Optional[str] = None,
    time_range: Optional[QueryTimeRange] = None,
) -> str:
    return "\n".join(
        [
            _union_all_logs(DEFAULT_TRACES_TABLE),
            _time_filter_line("timestamp", lookback=lookback, time_range=time_range),
            "| where operation_ParentId == {0}".format(_kql_string(nexus_operation_id)),
            '| extend stackTrace = tostring(customDimensions["ExceptionStackTrace"])',
            "| project timestamp, message, severityLevel, stackTrace, customDimensions",
            "| order by timestamp asc",
        ]
    )


def build_frontdoor_request_query(
    x_request_id: str,
    *,
    lookback: Optional[str] = None,
    time_range: Optional[QueryTimeRange] = None,
) -> str:
    return "\n".join(
        [
            DEFAULT_FRONTDOOR_TABLE,
            _time_filter_line("PreciseTimeStamp", lookback=lookback, time_range=time_range),
            "| where xRequestId == {0}".format(_kql_string(x_request_id)),
            "| project PreciseTimeStamp, xRequestId, xMsClientRequestId, endpointName, deploymentName, trafficGroupName, method, path, responseCode, responseCodeDetails, responseCodeReason, modelResponseCode, modelResponseCodeReason, durationTotal, durationResponse, durationModel, durationUpstream, userAgent",
            "| order by PreciseTimeStamp asc",
        ]
    )


def build_container_request_query(
    x_request_id: str,
    *,
    lookback: Optional[str] = None,
    time_range: Optional[QueryTimeRange] = None,
    region: Optional[str] = None,
    endpoint: Optional[str] = None,
    deployment: Optional[str] = None,
) -> str:
    lines = [
        DEFAULT_SINGULARITY_TRACES_FUNCTION,
        _time_filter_line("PreciseTimeStamp", lookback=lookback, time_range=time_range),
        "| extend parsedMessage = parse_json(message)",
        '| extend onlineEndpointName = coalesce(tostring(parsedMessage["EndpointName"]), tostring(parsedMessage["endpointName"]))',
        '| extend deploymentName = coalesce(tostring(parsedMessage["Name"]), tostring(parsedMessage["DeploymentName"]), tostring(parsedMessage["deploymentName"]))',
        '| extend Container = coalesce(tostring(PodName), tostring(ContainerImageName), "singularity")',
        "| extend containerImageName = tostring(ContainerImageName)",
        "| extend log = tostring(message)",
    ]
    if region:
        lines.append("| where Region == {0}".format(_kql_string(region)))
    if endpoint:
        lines.append("| where onlineEndpointName == {0}".format(_kql_string(endpoint)))
    if deployment:
        lines.append("| where deploymentName == {0}".format(_kql_string(deployment)))
    lines.extend(
        [
            "| where log contains {0} or AISC_ResourceId contains {0} or * contains {0}".format(
                _kql_string(x_request_id)
            ),
            "| project PreciseTimeStamp, Region, onlineEndpointName, deploymentName, Container, containerImageName, PodName, AISC_ResourceId, log",
            "| order by PreciseTimeStamp asc",
        ]
    )
    return "\n".join(lines)


def _base_query_lines(filters: QueryFilters) -> List[str]:
    return [
        _union_all_logs(DEFAULT_TABLE),
        _lookback_line("PreciseTimeStamp", filters.lookback),
        "| where onlineEndpointName == {0}".format(_kql_string(filters.endpoint)),
        "| where deploymentName == {0}".format(_kql_string(filters.deployment)),
    ]


def _lookback_line(column_name: str, lookback: str) -> str:
    return "| where {0} between (ago({1}) .. now())".format(column_name, lookback)


def _time_filter_line(
    column_name: str,
    *,
    lookback: Optional[str] = None,
    time_range: Optional[QueryTimeRange] = None,
) -> str:
    if time_range is not None:
        return "| where {0} between ({1} .. {2})".format(
            column_name,
            _kql_datetime(time_range.start),
            _kql_datetime(time_range.end),
        )
    if not lookback:
        raise ValueError("query requires lookback or time_range")
    return _lookback_line(column_name, lookback)


def _union_all_logs(table_name: str) -> str:
    return "UnionOfAllLogs({0}, {1})".format(_kql_string(DEFAULT_WORKSPACE), _kql_string(table_name))


def _kql_datetime(value: str) -> str:
    return "todatetime({0})".format(_kql_string(value))


def _kql_string(value: str) -> str:
    return "'" + value.replace("'", "''") + "'"


def investigate(
    config: KustoConnectionConfig,
    request: InvestigationRequest,
) -> InvestigationResult:
    resolved_target, resolve_query = resolve_target(config, request)
    query = build_logs_query(
        QueryFilters(
            endpoint=resolved_target.endpoint,
            deployment=resolved_target.deployment,
            lookback=request.lookback,
        )
    )
    if request.limit:
        query = "{0}\n| take {1}".format(query, request.limit)

    result = execute_query(config, query)
    analysis = analyze_logs(
        result.rows,
        lookback=request.lookback,
        container_count=len(resolved_target.containers),
    )
    return InvestigationResult(
        target=resolved_target,
        analysis=analysis,
        resolve_query=resolve_query,
        query=query,
        rows=result.rows,
    )


def trace_request(
    config: KustoConnectionConfig,
    request: RequestTraceRequest,
) -> RequestTraceResult:
    apim_config = load_apim_connection_config()
    filters = RequestTraceFilters(
        apim_request_id=request.apim_request_id,
        lookback=request.lookback,
    )

    apim_query = build_apim_request_query(filters)
    apim_rows = execute_query(apim_config, apim_query).rows
    if not apim_rows:
        raise RuntimeError(
            "No APIM request found for {0} in the last {1}".format(
                request.apim_request_id,
                request.lookback,
            )
        )

    apim_row = _select_latest_row(apim_rows, "TIMESTAMP")
    if apim_row is None:
        raise RuntimeError(
            "APIM query for {0} returned no usable rows".format(request.apim_request_id)
        )

    anchor_timestamp = _normalize_timestamp_text(str(apim_row["TIMESTAMP"]))
    time_range = _build_request_trace_time_range(anchor_timestamp)

    nexus_query = build_nexus_request_query(filters, time_range=time_range)
    nexus_rows = execute_query(config, nexus_query).rows
    nexus_row = _select_latest_row(nexus_rows, "timestamp")

    traces_query = None
    trace_rows = []
    frontdoor_query = None
    frontdoor_rows = []
    container_query = None
    container_rows = []

    backend_endpoint = _first_nonempty(
        _clean_text(nexus_row.get("endpoint")) if nexus_row else None,
        _clean_text(apim_row.get("BackendUrl")) if apim_row else None,
    )
    backend_region = _first_nonempty(
        _extract_backend_region(backend_endpoint),
        _clean_text(nexus_row.get("azureRegion")) if nexus_row else None,
        _clean_text(apim_row.get("Location")) if apim_row else None,
    )
    frontdoor_config = _resolve_vienna_region_config(config.database, backend_region) or config
    singularity_config = load_singularity_connection_config()
    backend_endpoint_name = _extract_endpoint_name(backend_endpoint)
    deployment_hint = _clean_text(apim_row.get("DeploymentId")) if apim_row else None

    nexus_request_id = _clean_text(nexus_row.get("id")) if nexus_row else None
    if nexus_request_id:
        traces_query = build_nexus_traces_query(nexus_request_id, time_range=time_range)
        trace_rows = execute_query(config, traces_query).rows

    x_request_id = _clean_text(nexus_row.get("xRequestId")) if nexus_row else None
    if x_request_id:
        frontdoor_query = build_frontdoor_request_query(x_request_id, time_range=time_range)
        frontdoor_rows = execute_query(frontdoor_config, frontdoor_query).rows

        container_query = build_container_request_query(
            x_request_id,
            time_range=time_range,
            region=backend_region,
            endpoint=backend_endpoint_name,
            deployment=deployment_hint,
        )
        container_rows = execute_query(singularity_config, container_query).rows

    frontdoor_row = _select_latest_row(frontdoor_rows, "PreciseTimeStamp")
    container_row = _select_latest_row(container_rows, "PreciseTimeStamp")
    target = RequestTraceTarget(
        apim_request_id=request.apim_request_id,
        x_request_id=x_request_id,
        nexus_request_id=nexus_request_id,
        model_name=_first_nonempty(
            _clean_text(nexus_row.get("model_name")) if nexus_row else None,
            _clean_text(apim_row.get("model_name")) if apim_row else None,
        ),
        apim_region=_clean_text(apim_row.get("Location")) if apim_row else None,
        nexus_region=_clean_text(nexus_row.get("azureRegion")) if nexus_row else None,
        backend_endpoint=backend_endpoint,
        backend_region=backend_region,
        endpoint=_first_nonempty(
            _clean_text(frontdoor_row.get("endpointName")) if frontdoor_row else None,
            _clean_text(container_row.get("onlineEndpointName")) if container_row else None,
            backend_endpoint_name,
        ),
        deployment=_first_nonempty(
            _clean_text(frontdoor_row.get("deploymentName")) if frontdoor_row else None,
            _clean_text(container_row.get("deploymentName")) if container_row else None,
            deployment_hint,
        ),
    )
    analysis = analyze_request_trace(
        target=target,
        apim_row=apim_row,
        nexus_row=nexus_row,
        traces_rows=trace_rows,
        frontdoor_row=frontdoor_row,
        frontdoor_rows=frontdoor_rows,
        container_rows=container_rows,
        anchor_window_minutes=REQUEST_TRACE_WINDOW_MINUTES,
    )
    return RequestTraceResult(
        target=target,
        analysis=analysis,
        anchor_timestamp=anchor_timestamp,
        window_start=time_range.start,
        window_end=time_range.end,
        apim_query=apim_query,
        nexus_query=nexus_query,
        traces_query=traces_query,
        frontdoor_query=frontdoor_query,
        container_query=container_query,
        apim_rows=apim_rows,
        nexus_rows=nexus_rows,
        trace_rows=trace_rows,
        frontdoor_rows=frontdoor_rows,
        container_rows=container_rows,
    )


def resolve_target(
    config: KustoConnectionConfig,
    request: InvestigationRequest,
) -> Tuple[ResolvedTarget, str]:
    if not request.endpoint and not request.deployment:
        raise ValueError("investigate requires --endpoint or --deployment")

    resolve_query = build_resolve_targets_query(
        ResolveFilters(
            endpoint=request.endpoint,
            deployment=request.deployment,
            lookback=request.resolve_lookback,
        )
    )
    result = execute_query(config, resolve_query)

    candidates: Dict[Tuple[str, str], Dict[str, Any]] = {}
    for row in result.rows:
        endpoint = str(row.get("onlineEndpointName") or "")
        deployment = str(row.get("deploymentName") or "")
        if not endpoint or not deployment:
            continue

        key = (endpoint, deployment)
        candidate = candidates.setdefault(
            key,
            {
                "endpoint": endpoint,
                "deployment": deployment,
                "containers": set(),
                "latest_timestamp": None,
            },
        )

        container = row.get("Container")
        if container:
            candidate["containers"].add(str(container))

        latest_timestamp = row.get("latestTimestamp")
        if latest_timestamp is not None:
            latest_text = str(latest_timestamp)
            current_latest = candidate["latest_timestamp"]
            if current_latest is None or latest_text > current_latest:
                candidate["latest_timestamp"] = latest_text

    if not candidates:
        identifier = request.deployment or request.endpoint
        raise RuntimeError("No active target found for {0}".format(identifier))

    ordered_candidates = sorted(
        candidates.values(),
        key=lambda candidate: (
            candidate["latest_timestamp"] or "",
            candidate["endpoint"],
            candidate["deployment"],
        ),
        reverse=True,
    )
    selected = ordered_candidates[0]
    return (
        ResolvedTarget(
            endpoint=selected["endpoint"],
            deployment=selected["deployment"],
            containers=sorted(selected["containers"]),
            latest_timestamp=selected["latest_timestamp"],
            candidate_count=len(ordered_candidates),
        ),
        resolve_query,
    )


def analyze_logs(
    rows: List[Dict[str, Any]],
    *,
    lookback: str = DEFAULT_INVESTIGATION_LOOKBACK,
    container_count: Optional[int] = None,
) -> InvestigationAnalysis:
    signal_counts: Counter[str] = Counter()
    container_counts: Counter[str] = Counter()
    evidence_lines: List[str] = []

    for row in rows:
        category = _classify_log_line(str(row.get("log", "")))
        if not category:
            continue

        signal_counts[category] += 1
        container = str(row.get("Container") or "unknown")
        container_counts[container] += 1
        if len(evidence_lines) < 5:
            evidence_lines.append(str(row.get("log", "")))

    suspected_root_cause = signal_counts.most_common(1)[0][0] if signal_counts else None
    affected_containers = [container for container, _count in container_counts.most_common()]
    suspicious_count = sum(signal_counts.values())
    inspected_container_count = container_count if container_count is not None else len(affected_containers)

    if suspicious_count:
        summary = (
            "Found {0} suspicious log row(s) across {1} container(s) in the last {2}. "
            "Dominant signal: {3}."
        ).format(
            suspicious_count,
            len(affected_containers),
            lookback,
            suspected_root_cause,
        )
    else:
        summary = "No suspicious log rows found in the last {0} across {1} container(s).".format(
            lookback,
            inspected_container_count,
        )

    return InvestigationAnalysis(
        summary=summary,
        suspected_root_cause=suspected_root_cause,
        affected_containers=affected_containers,
        error_row_count=suspicious_count,
        signal_counts=dict(signal_counts),
        evidence_lines=evidence_lines,
    )


def analyze_request_trace(
    *,
    target: RequestTraceTarget,
    apim_row: Optional[Dict[str, Any]],
    nexus_row: Optional[Dict[str, Any]],
    traces_rows: List[Dict[str, Any]],
    frontdoor_row: Optional[Dict[str, Any]],
    frontdoor_rows: List[Dict[str, Any]],
    container_rows: List[Dict[str, Any]],
    anchor_window_minutes: int,
) -> RequestTraceAnalysis:
    anchor_window_text = _format_anchor_window_text(anchor_window_minutes)
    container_analysis = analyze_logs(
        container_rows,
        lookback=anchor_window_text,
        container_count=len({str(row.get("Container") or "unknown") for row in container_rows}) or None,
    )
    trace_analysis = _analyze_trace_rows(traces_rows)
    flow_text = _build_flow_text(
        apim_found=apim_row is not None,
        nexus_found=nexus_row is not None,
        frontdoor_found=bool(frontdoor_rows),
        container_found=bool(container_rows),
    )

    apim_reason = _clean_text(apim_row.get("apimErrorReason")) if apim_row else None
    apim_response_code = _clean_text(apim_row.get("ResponseCode")) if apim_row else None
    nexus_error_code = _clean_text(nexus_row.get("error_code")) if nexus_row else None
    nexus_result_code = _clean_text(nexus_row.get("resultCode")) if nexus_row else None
    nexus_model_error_message = _clean_text(nexus_row.get("model_error_message")) if nexus_row else None
    frontdoor_response_code = _clean_text(frontdoor_row.get("responseCode")) if frontdoor_row else None
    frontdoor_reason = _extract_frontdoor_reason(frontdoor_row)
    frontdoor_classification = _classify_frontdoor_failure(frontdoor_row)

    root_cause_layer = None
    suspected_root_cause = None
    evidence_lines: List[str] = []

    if _is_client_connection_failure(apim_reason, nexus_error_code, traces_rows):
        root_cause_layer = "apim" if apim_reason == CLIENT_CONNECTION_FAILURE else "nexus"
        suspected_root_cause = "client_connection_failure"
        summary = (
            "Correlated layers: {0}. The request ended with a client connection failure "
            "before a complete backend response was observed."
        ).format(flow_text)
        evidence_lines.extend(
            _prefixed_lines(
                "apim",
                [_format_apim_evidence(apim_row)] if apim_row else [],
            )
        )
        evidence_lines.extend(_prefixed_lines("nexus", trace_analysis.evidence_lines))
    elif container_analysis.suspected_root_cause:
        root_cause_layer = "container"
        suspected_root_cause = container_analysis.suspected_root_cause
        summary = (
            "Correlated layers: {0}. Root cause is most likely in the container layer "
            "for {1}: {2}."
        ).format(
            flow_text,
            _format_target_text(target),
            suspected_root_cause,
        )
        evidence_lines.extend(
            _prefixed_lines(
                "container",
                [_truncate_text(line) for line in container_analysis.evidence_lines],
            )
        )
    elif trace_analysis.suspected_root_cause:
        root_cause_layer = "nexus"
        suspected_root_cause = trace_analysis.suspected_root_cause
        summary = "Correlated layers: {0}. Nexus traces point to {1}.".format(
            flow_text,
            suspected_root_cause,
        )
        evidence_lines.extend(_prefixed_lines("nexus-trace", trace_analysis.evidence_lines))
    elif frontdoor_classification is not None:
        root_cause_layer = "frontdoor"
        suspected_root_cause = frontdoor_classification["suspected_root_cause"]
        summary = frontdoor_classification["summary"].format(
            flow_text=flow_text,
            target=_format_target_text(target),
            response_code=frontdoor_response_code or "unknown",
        )
        if frontdoor_row:
            evidence_lines.extend(_prefixed_lines("frontdoor", [_format_frontdoor_evidence(frontdoor_row)]))
        if nexus_row:
            evidence_lines.extend(_prefixed_lines("nexus", [_format_nexus_evidence(nexus_row)]))
    elif nexus_error_code or nexus_model_error_message or _is_non_success_code(nexus_result_code):
        root_cause_layer = "nexus"
        suspected_root_cause = nexus_error_code or nexus_model_error_message or _http_reason(nexus_result_code)
        summary = "Correlated layers: {0}. Nexus returned {1} with error {2}.".format(
            flow_text,
            nexus_result_code or "unknown",
            suspected_root_cause,
        )
        if nexus_row:
            evidence_lines.extend(_prefixed_lines("nexus", [_format_nexus_evidence(nexus_row)]))
    elif frontdoor_reason or _is_non_success_code(frontdoor_response_code):
        root_cause_layer = "frontdoor"
        suspected_root_cause = frontdoor_reason or _http_reason(frontdoor_response_code)
        summary = "Correlated layers: {0}. FrontDoor returned {1} with reason {2}.".format(
            flow_text,
            frontdoor_response_code or "unknown",
            suspected_root_cause,
        )
        if frontdoor_row:
            evidence_lines.extend(_prefixed_lines("frontdoor", [_format_frontdoor_evidence(frontdoor_row)]))
    elif apim_reason or _is_non_success_code(apim_response_code):
        root_cause_layer = "apim"
        suspected_root_cause = apim_reason or _http_reason(apim_response_code)
        if nexus_row:
            summary = (
                "Correlated layers: {0}. No stronger downstream failure was found; "
                "APIM reported {1}."
            ).format(flow_text, suspected_root_cause)
        else:
            summary = (
                "Correlated layers: {0}. The request did not reach Nexus within the "
                "anchored {1} window; APIM reported {2}."
            ).format(flow_text, anchor_window_text, suspected_root_cause)
        if apim_row:
            evidence_lines.extend(_prefixed_lines("apim", [_format_apim_evidence(apim_row)]))
    else:
        summary = (
            "Correlated layers: {0}. The request was found, but the anchored "
            "{1} correlation window did not expose a clear root cause."
        ).format(flow_text, anchor_window_text)

    if apim_row:
        evidence_lines.extend(_prefixed_lines("apim", [_format_apim_evidence(apim_row)]))
    if nexus_row:
        evidence_lines.extend(_prefixed_lines("nexus", [_format_nexus_evidence(nexus_row)]))
    if frontdoor_row:
        evidence_lines.extend(_prefixed_lines("frontdoor", [_format_frontdoor_evidence(frontdoor_row)]))

    return RequestTraceAnalysis(
        summary=summary,
        root_cause_layer=root_cause_layer,
        suspected_root_cause=suspected_root_cause,
        evidence_lines=_dedupe_preserving_order(evidence_lines)[:8],
        container_signal_counts=container_analysis.signal_counts,
        trace_signal_counts=trace_analysis.signal_counts,
        structured_summary=_build_structured_trace_summary(
            target=target,
            root_cause_layer=root_cause_layer,
            suspected_root_cause=suspected_root_cause,
            flow_text=flow_text,
            frontdoor_row=frontdoor_row,
        ),
    )


def _analyze_trace_rows(rows: List[Dict[str, Any]]) -> TraceEvidenceAnalysis:
    signal_counts: Counter[str] = Counter()
    evidence_lines: List[str] = []

    for row in rows:
        message = _clean_text(row.get("message")) or ""
        stack_trace = _clean_text(row.get("stackTrace")) or ""
        combined = " ".join(part for part in (message, stack_trace) if part)
        if not combined:
            continue

        category = _classify_log_line(combined)
        if category:
            signal_counts[category] += 1

        severity = _as_int(row.get("severityLevel")) or 0
        if category or severity >= 2 or stack_trace:
            if len(evidence_lines) < 5:
                evidence_lines.append(_truncate_text("severity={0} {1}".format(severity, combined)))

    suspected_root_cause = signal_counts.most_common(1)[0][0] if signal_counts else None
    if suspected_root_cause is None and evidence_lines:
        suspected_root_cause = "trace_error"

    return TraceEvidenceAnalysis(
        suspected_root_cause=suspected_root_cause,
        signal_counts=dict(signal_counts),
        evidence_lines=evidence_lines,
    )


def _build_structured_trace_summary(
    *,
    target: RequestTraceTarget,
    root_cause_layer: Optional[str],
    suspected_root_cause: Optional[str],
    flow_text: str,
    frontdoor_row: Optional[Dict[str, Any]],
) -> Dict[str, str]:
    symptom = _build_trace_symptom(frontdoor_row)
    deepest_confirmed_layer = root_cause_layer or "unknown"
    likely_root_cause = suspected_root_cause or "undetermined"
    target_text = _format_target_text(target)

    if suspected_root_cause in {"deployment_unhealthy_or_not_ready", "instant_rejection_before_backend"}:
        not_yet_proven = (
            "Pod health is implicated, but the exact pod-level cause is not yet proven. "
            "Check deployment readiness, restarts, and Kubernetes events next."
        )
        next_query_focus = "Pivot to pod health: ApplicationSnapshots, PodSnapshots, and KubernetesEvents."
    elif suspected_root_cause == "backend_returned_error":
        not_yet_proven = (
            "The request reached the backend, but the exact model/container failure is not yet proven."
        )
        next_query_focus = "Pivot deeper into backend traces and container logs for the correlated target."
    else:
        not_yet_proven = "The current trace has not yet proven the exact failing subsystem beyond the correlated layers."
        next_query_focus = "Continue with the strongest downstream query and verify the next layer manually."

    return {
        "symptom": symptom,
        "correlated_path": flow_text,
        "deepest_confirmed_layer": deepest_confirmed_layer,
        "likely_root_cause": likely_root_cause,
        "what_is_not_yet_proven": not_yet_proven,
        "next_query_focus": "{0} Target: {1}".format(next_query_focus, target_text),
    }


def _build_trace_symptom(frontdoor_row: Optional[Dict[str, Any]]) -> str:
    if not frontdoor_row:
        return "Trace correlated without a FrontDoor symptom row"

    response_code = _clean_text(frontdoor_row.get("responseCode")) or "unknown"
    reason = _extract_frontdoor_reason(frontdoor_row)
    if reason:
        return "HTTP {0} / {1}".format(response_code, reason)
    return "HTTP {0}".format(response_code)


def _build_flow_text(
    *,
    apim_found: bool,
    nexus_found: bool,
    frontdoor_found: bool,
    container_found: bool,
) -> str:
    layers = [
        layer_name
        for layer_name, found in (
            ("APIM", apim_found),
            ("Nexus", nexus_found),
            ("FrontDoor", frontdoor_found),
            ("Container", container_found),
        )
        if found
    ]
    if not layers:
        return "none"
    return " -> ".join(layers)


def _format_target_text(target: RequestTraceTarget) -> str:
    endpoint = target.endpoint or target.backend_endpoint or "unknown-target"
    if target.deployment:
        return "{0}/{1}".format(endpoint, target.deployment)
    return endpoint


def _format_apim_evidence(row: Dict[str, Any]) -> str:
    response_code = _clean_text(row.get("ResponseCode")) or "unknown"
    reason = _clean_text(row.get("apimErrorReason")) or "no_apim_reason"
    api_id = _clean_text(row.get("ApiId")) or "unknown-api"
    location = _clean_text(row.get("Location")) or "unknown-location"
    return "RequestId={0} response={1} reason={2} api={3} location={4}".format(
        row.get("RequestId"),
        response_code,
        reason,
        api_id,
        location,
    )


def _format_nexus_evidence(row: Dict[str, Any]) -> str:
    result_code = _clean_text(row.get("resultCode")) or "unknown"
    status_code = _clean_text(row.get("status_code")) or "unknown"
    error_code = _clean_text(row.get("error_code")) or "no_error_code"
    x_request_id = _clean_text(row.get("xRequestId")) or "missing-x-request-id"
    model_name = _clean_text(row.get("model_name")) or "unknown-model"
    return (
        "xRequestId={0} resultCode={1} status_code={2} "
        "error_code={3} model_name={4}"
    ).format(
        x_request_id,
        result_code,
        status_code,
        error_code,
        model_name,
    )


def _format_frontdoor_evidence(row: Dict[str, Any]) -> str:
    response_code = _clean_text(row.get("responseCode")) or "unknown"
    reason = _extract_frontdoor_reason(row) or "no_frontdoor_reason"
    endpoint = _clean_text(row.get("endpointName")) or "unknown-endpoint"
    deployment = _clean_text(row.get("deploymentName")) or "unknown-deployment"
    duration_total = _clean_text(row.get("durationTotal")) or "unknown"
    duration_upstream = _clean_text(row.get("durationUpstream")) or "unknown"
    return (
        "endpoint={0} deployment={1} response={2} reason={3} "
        "durationTotalMs={4} durationUpstreamMs={5}"
    ).format(
        endpoint,
        deployment,
        response_code,
        reason,
        duration_total,
        duration_upstream,
    )


def _classify_frontdoor_failure(row: Optional[Dict[str, Any]]) -> Optional[Dict[str, str]]:
    if not row:
        return None

    reason = (_extract_frontdoor_reason(row) or "").lower()
    response_code = _clean_text(row.get("responseCode")) or "unknown"
    duration_total = _as_int(row.get("durationTotal"))
    duration_upstream = _as_int(row.get("durationUpstream"))

    if reason == "no_healthy_upstream":
        return {
            "suspected_root_cause": "deployment_unhealthy_or_not_ready",
            "summary": (
                "Correlated layers: {flow_text}. FrontDoor returned {response_code} for {target} "
                "with no_healthy_upstream, so the request likely did not reach the backend. "
                "This usually points to pod readiness, endpoint registration, or routing health."
            ),
        }

    if reason == "via_upstream":
        return {
            "suspected_root_cause": "backend_returned_error",
            "summary": (
                "Correlated layers: {flow_text}. FrontDoor returned {response_code} for {target} "
                "with via_upstream, so the request reached the backend but no deeper backend signal was captured."
            ),
        }

    if (duration_total == 0 or duration_upstream == 0) and _is_non_success_code(response_code):
        return {
            "suspected_root_cause": "instant_rejection_before_backend",
            "summary": (
                "Correlated layers: {flow_text}. FrontDoor returned {response_code} for {target} "
                "with an instant rejection profile before meaningful upstream work was observed."
            ),
        }

    return None


def _build_pod_health_queries(endpoint: Optional[str], deployment: Optional[str], lookback: str) -> Optional[Dict[str, str]]:
    if not endpoint or not deployment:
        return None

    return {
        "applicationSnapshotsQuery": build_application_snapshots_query(
            endpoint=endpoint,
            deployment=deployment,
            lookback=lookback,
        ),
        "podSnapshotsQuery": build_pod_snapshots_query(
            endpoint=endpoint,
            deployment=deployment,
            lookback=lookback,
        ),
        "kubernetesEventsQuery": build_kubernetes_events_query(
            endpoint=endpoint,
            deployment=deployment,
            lookback=lookback,
        ),
    }


def _extract_frontdoor_reason(row: Optional[Dict[str, Any]]) -> Optional[str]:
    if not row:
        return None
    return _first_nonempty(
        _clean_text(row.get("modelResponseCodeReason")),
        _clean_text(row.get("responseCodeDetails")),
        _clean_text(row.get("responseCodeReason")),
    )


def _is_client_connection_failure(
    apim_reason: Optional[str],
    nexus_error_code: Optional[str],
    traces_rows: List[Dict[str, Any]],
) -> bool:
    if apim_reason == CLIENT_CONNECTION_FAILURE or nexus_error_code == CLIENT_CONNECTION_FAILURE:
        return True

    for row in traces_rows:
        text = " ".join(
            filter(
                None,
                (
                    _clean_text(row.get("message")),
                    _clean_text(row.get("stackTrace")),
                ),
            )
        ).lower()
        if "user cancelled request" in text or "client disconnected" in text:
            return True

    return False


def _build_request_trace_time_range(anchor_timestamp: str) -> QueryTimeRange:
    anchor = _parse_timestamp(anchor_timestamp)
    window_start = _format_timestamp(anchor - timedelta(minutes=REQUEST_TRACE_WINDOW_MINUTES))
    window_end = _format_timestamp(anchor + timedelta(minutes=REQUEST_TRACE_WINDOW_MINUTES))
    return QueryTimeRange(start=window_start, end=window_end)


def _resolve_vienna_region_config(
    database: str,
    region: Optional[str],
) -> Optional[KustoConnectionConfig]:
    if not region:
        return None

    cluster_url = VIENNA_REGION_CLUSTER_URLS.get(region.lower())
    if not cluster_url:
        return None

    return KustoConnectionConfig(
        cluster_url=cluster_url,
        database=database,
    )


def _extract_backend_region(backend_endpoint: Optional[str]) -> Optional[str]:
    host = _extract_backend_host(backend_endpoint)
    if not host:
        return None

    parts = host.split(".")
    if len(parts) < 6:
        return None

    if parts[-4:] != ["inference", "ml", "azure", "com"]:
        return None
    return parts[-5]


def _extract_endpoint_name(backend_endpoint: Optional[str]) -> Optional[str]:
    host = _extract_backend_host(backend_endpoint)
    if not host:
        return None

    return host.split(".", 1)[0]


def _extract_backend_host(backend_endpoint: Optional[str]) -> Optional[str]:
    endpoint = _clean_text(backend_endpoint)
    if not endpoint:
        return None

    parsed = urlparse(endpoint if "://" in endpoint else "https://{0}".format(endpoint))
    host = (parsed.hostname or parsed.netloc or parsed.path).strip().strip("/")
    return host or None


def _normalize_timestamp_text(value: str) -> str:
    return _format_timestamp(_parse_timestamp(value))


def _parse_timestamp(value: str) -> datetime:
    normalized = value.strip()
    if normalized.endswith("Z"):
        normalized = "{0}+00:00".format(normalized[:-1])

    parsed = datetime.fromisoformat(normalized)
    if parsed.tzinfo is None:
        parsed = parsed.replace(tzinfo=timezone.utc)
    return parsed.astimezone(timezone.utc)


def _format_timestamp(value: datetime) -> str:
    return value.astimezone(timezone.utc).isoformat().replace("+00:00", "Z")


def _format_anchor_window_text(minutes: int) -> str:
    return "+/-{0}m".format(minutes)


def _select_latest_row(
    rows: List[Dict[str, Any]],
    timestamp_field: str,
) -> Optional[Dict[str, Any]]:
    if not rows:
        return None
    return max(rows, key=lambda row: str(row.get(timestamp_field) or ""))


def _prefixed_lines(prefix: str, lines: List[str]) -> List[str]:
    return ["{0}: {1}".format(prefix, line) for line in lines if line]


def _dedupe_preserving_order(lines: List[str]) -> List[str]:
    seen: Set[str] = set()
    ordered_lines: List[str] = []
    for line in lines:
        if line in seen:
            continue
        seen.add(line)
        ordered_lines.append(line)
    return ordered_lines


def _truncate_text(text: str, limit: int = 240) -> str:
    if len(text) <= limit:
        return text
    return "{0}...".format(text[: limit - 3])


def _http_reason(response_code: Optional[str]) -> Optional[str]:
    if response_code is None:
        return None
    return "http_{0}".format(response_code)


def _is_non_success_code(value: Any) -> bool:
    code = _as_int(value)
    if code is not None:
        return code < 200 or code >= 300

    text = _clean_text(value)
    if text is None:
        return False
    return not text.startswith("2")


def _as_int(value: Any) -> Optional[int]:
    if value is None:
        return None

    text = _clean_text(value)
    if text is None:
        return None

    try:
        return int(text)
    except ValueError:
        try:
            return int(float(text))
        except ValueError:
            return None


def _first_nonempty(*values: Optional[str]) -> Optional[str]:
    for value in values:
        if value:
            return value
    return None


def _clean_text(value: Any) -> Optional[str]:
    if value is None:
        return None
    text = str(value).strip()
    return text or None


def _classify_log_line(log_line: str) -> Optional[str]:
    normalized = log_line.lower()
    for category, patterns in LOG_SIGNAL_RULES:
        if any(pattern in normalized for pattern in patterns):
            return category
    return None


def main() -> int:
    parser = _build_parser()
    args = parser.parse_args()

    try:
        payload = args.handler(args)
    except Exception as exc:
        _print_json({"success": False, "error": str(exc)})
        return 1

    _print_json(dict({"success": True}, **payload))
    return 0


def _build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="xiaoranli-kuda",
        description="Focused MaaS Kusto helper for container logs and APIM request tracing",
    )
    subparsers = parser.add_subparsers(dest="command", required=True)

    auth_parser = subparsers.add_parser("auth-check", help="Verify Azure auth via az login")
    auth_parser.set_defaults(handler=_handle_auth_check)

    list_parser = subparsers.add_parser(
        "list-containers",
        help="List all containers for an endpoint deployment pair",
    )
    _add_query_arguments(list_parser)
    list_parser.set_defaults(handler=lambda args: _handle_query_command(args, build_list_containers_query))

    logs_parser = subparsers.add_parser(
        "logs",
        help="Fetch AMLManagedComputeLogs rows for an endpoint deployment pair",
    )
    _add_query_arguments(logs_parser, include_container=True, include_limit=True)
    logs_parser.set_defaults(handler=lambda args: _handle_query_command(args, build_logs_query))

    investigate_parser = subparsers.add_parser(
        "investigate",
        help="Trace an APIM request ID or investigate endpoint/deployment log issues",
    )
    _add_investigate_arguments(investigate_parser)
    investigate_parser.set_defaults(handler=_handle_investigate_command)

    return parser


def _add_query_arguments(
    parser: argparse.ArgumentParser,
    *,
    include_container: bool = False,
    include_limit: bool = False,
) -> None:
    parser.add_argument("--endpoint", required=True, help="onlineEndpointName filter")
    parser.add_argument("--deployment", required=True, help="deploymentName filter")
    parser.add_argument("--lookback", default="2h", help="ago() window, default: 2h")
    parser.add_argument("--cluster-url", help="Override XIAORANLI_KUDA_CLUSTER_URL")
    parser.add_argument("--database", help="Override XIAORANLI_KUDA_DATABASE")
    parser.add_argument(
        "--print-query",
        action="store_true",
        help="Print the generated KQL without executing it",
    )
    if include_container:
        parser.add_argument("--container", help="Container filter, e.g. inference-server")
    if include_limit:
        parser.add_argument("--limit", type=int, help="Append '| take N' after sorting")


def _add_investigate_arguments(parser: argparse.ArgumentParser) -> None:
    parser.add_argument("--apim-request-id", help="APIM RequestId for cross-layer request tracing")
    parser.add_argument("--endpoint", help="onlineEndpointName filter")
    parser.add_argument("--deployment", help="deploymentName filter")
    parser.add_argument(
        "--lookback",
        help="Logs ago() window. Defaults to 2h for endpoint/deployment mode and 7d for APIM mode",
    )
    parser.add_argument(
        "--resolve-lookback",
        default="24h",
        help="Resolve ago() window used to map endpoint/deployment, default: 24h",
    )
    parser.add_argument("--limit", type=int, help="Append '| take N' after sorting")
    parser.add_argument("--cluster-url", help="Override XIAORANLI_KUDA_CLUSTER_URL")
    parser.add_argument("--database", help="Override XIAORANLI_KUDA_DATABASE")


def _handle_auth_check(_args: argparse.Namespace) -> Dict[str, Any]:
    return {"message": check_authentication()}


def _handle_query_command(
    args: argparse.Namespace,
    builder: Callable[[QueryFilters], str],
) -> Dict[str, Any]:
    filters = QueryFilters(
        endpoint=args.endpoint,
        deployment=args.deployment,
        lookback=args.lookback,
        container=getattr(args, "container", None),
    )
    query = builder(filters)
    limit = getattr(args, "limit", None)
    if limit:
        query = "{0}\n| take {1}".format(query, limit)

    if args.print_query:
        return {"query": query}

    config = load_connection_config(
        cluster_url=args.cluster_url,
        database=args.database,
    )
    result = execute_query(config, query)
    return {
        "kustoLink": build_kusto_web_link(config),
        "query": query,
        "rows": result.rows,
        "rowCount": result.row_count,
    }


def _handle_investigate_command(args: argparse.Namespace) -> Dict[str, Any]:
    if args.apim_request_id and (args.endpoint or args.deployment):
        raise ValueError("investigate accepts either --apim-request-id or --endpoint/--deployment filters")
    if not args.apim_request_id and not args.endpoint and not args.deployment:
        raise ValueError("investigate requires --apim-request-id or --endpoint/--deployment")

    config = load_connection_config(
        cluster_url=args.cluster_url,
        database=args.database,
    )
    if args.apim_request_id:
        lookback = args.lookback or DEFAULT_REQUEST_TRACE_LOOKBACK
        apim_config = load_apim_connection_config()
        result = trace_request(
            config=config,
            request=RequestTraceRequest(
                apim_request_id=args.apim_request_id,
                lookback=lookback,
            ),
        )
        pod_health_queries = _build_pod_health_queries(
            result.target.endpoint,
            result.target.deployment,
            DEFAULT_INVESTIGATION_LOOKBACK,
        )
        return {
            "kustoLink": build_kusto_web_link(config),
            "apimKustoLink": build_kusto_web_link(apim_config),
            "traceTarget": {
                "apimRequestId": result.target.apim_request_id,
                "xRequestId": result.target.x_request_id,
                "nexusRequestId": result.target.nexus_request_id,
                "modelName": result.target.model_name,
                "apimRegion": result.target.apim_region,
                "nexusRegion": result.target.nexus_region,
                "backendEndpoint": result.target.backend_endpoint,
                "backendRegion": result.target.backend_region,
                "endpoint": result.target.endpoint,
                "deployment": result.target.deployment,
            },
            "searchWindow": {
                "anchorTimestamp": result.anchor_timestamp,
                "start": result.window_start,
                "end": result.window_end,
            },
            "analysis": {
                "summary": result.analysis.summary,
                "rootCauseLayer": result.analysis.root_cause_layer,
                "suspectedRootCause": result.analysis.suspected_root_cause,
                "evidenceLines": result.analysis.evidence_lines,
                "containerSignalCounts": result.analysis.container_signal_counts,
                "traceSignalCounts": result.analysis.trace_signal_counts,
                "structuredSummary": result.analysis.structured_summary,
            },
            "podHealthQueries": pod_health_queries,
            "layerRowCounts": result.layer_row_counts,
            "apimQuery": result.apim_query,
            "nexusQuery": result.nexus_query,
            "tracesQuery": result.traces_query,
            "frontdoorQuery": result.frontdoor_query,
            "containerQuery": result.container_query,
            "apimRows": result.apim_rows,
            "nexusRows": result.nexus_rows,
            "traceRows": result.trace_rows,
            "frontdoorRows": result.frontdoor_rows,
            "containerRows": result.container_rows,
        }

    result = investigate(
        config=config,
        request=InvestigationRequest(
            endpoint=args.endpoint,
            deployment=args.deployment,
            lookback=args.lookback or DEFAULT_INVESTIGATION_LOOKBACK,
            resolve_lookback=args.resolve_lookback,
            limit=args.limit,
        ),
    )
    return {
        "kustoLink": build_kusto_web_link(config),
        "resolveQuery": result.resolve_query,
        "query": result.query,
        "resolvedTarget": {
            "endpoint": result.target.endpoint,
            "deployment": result.target.deployment,
            "containers": result.target.containers,
            "latestTimestamp": result.target.latest_timestamp,
            "candidateCount": result.target.candidate_count,
        },
        "analysis": {
            "summary": result.analysis.summary,
            "suspectedRootCause": result.analysis.suspected_root_cause,
            "affectedContainers": result.analysis.affected_containers,
            "errorRowCount": result.analysis.error_row_count,
            "signalCounts": result.analysis.signal_counts,
            "evidenceLines": result.analysis.evidence_lines,
        },
        "rows": result.rows,
        "rowCount": result.row_count,
    }


def _print_json(payload: Dict[str, Any]) -> None:
    print(json.dumps(payload, indent=2, default=str))


if __name__ == "__main__":  # pragma: no cover
    raise SystemExit(main())
