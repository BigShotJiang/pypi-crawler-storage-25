# dc_sdk/session.py

import uuid

_sessions = {}

def create_session(connector):
    session_id = str(uuid.uuid4())
    _sessions[session_id] = connector
    return session_id

def get_session(session_id):
    return _sessions.get(session_id)

def delete_session(session_id):
    if session_id in _sessions:
        connector = _sessions.pop(session_id)
        if hasattr(connector, "close"):
            connector.close()