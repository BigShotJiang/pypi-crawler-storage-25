import os
import importlib
from typing import Type
from dc_sdk.types import ConnectorProtocol


def load_connector() -> Type[ConnectorProtocol]:
    import sys, os
    cwd = os.getcwd()
    if cwd not in sys.path:
        sys.path.insert(0, cwd)
    
    connector_module = os.getenv("CONNECTOR_MODULE", "src.connector")

    print(f"[DC SDK] Loading connector module: {connector_module}")

    try:
        module = importlib.import_module(connector_module)
    except ModuleNotFoundError as e:
        raise Exception(f"Could not import module '{connector_module}'") from e

    if not hasattr(module, "Connector"):
        raise Exception(f"Module '{connector_module}' must define a Connector class")

    ConnectorClass = module.Connector

    # validate class methods (not instance now)
    required_methods = [
        "authenticate",
        "get_objects",
        "get_fields",
        "get_data",
        "load_data",
    ]

    for method in required_methods:
        if not hasattr(ConnectorClass, method) or not callable(getattr(ConnectorClass, method)):
            raise Exception(f"Connector class missing required method: {method}")

    return ConnectorClass