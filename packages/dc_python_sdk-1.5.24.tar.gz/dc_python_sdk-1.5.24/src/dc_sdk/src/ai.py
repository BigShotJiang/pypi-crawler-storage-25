import subprocess
import time
import requests
from openai import OpenAI
import os
import boto3
import re
import json
from base64 import b64decode

BASE_URL = "http://localhost:6000"
API_BASE_URL = "http://localhost:5002"

client = None

_ssm_cache = {}

CONNECTOR_CONTEXT = {
    "name": "test",
    "auth_type": "api_key",
    "base_url": "account_url that gets provided from the self.credentials"
}

METHOD_CONTEXT = {
    "authenticate": "Authenticate using self.credentials. Return True when authentication is successful, otherwise raise a meaningful error.",
    "get_objects": "Return a list of object dictionaries with keys: object_id, object_name, object_label, and optional object_group/visible.",
    "get_fields": "Return a list of field dictionaries for an object_id with keys: field_id, field_name, field_label, and optional metadata like data_type/size.",
    "get_data": "Return paginated data in shape {'next_page': <token_or_none>, 'data': [row_dict, ...]}. Respect object_id, field_ids, n_rows, filters, next_page.",
    "load_data": "Load mapped destination rows into object_id using mapping m and update_method. Return True on success or raise a specific load/write error.",
    "close": "Close open sessions/connections safely. Should not fail when resources were never initialized.",
    "FOLLOWUP": "Refine output quality based on user follow-up feedback after a method succeeds.",
}

REQUIRED_METHODS = [
    "authenticate",
    "get_objects",
    "get_fields",
    "get_data",
    "load_data",
    "close",
]

FOLLOWUP_CONTEXT = {
    "expected_object_ids": os.getenv("AI_EXPECTED_OBJECT_IDS", ""),
    "expected_object_labels": os.getenv("AI_EXPECTED_OBJECT_LABELS", ""),
    "expected_field_ids": os.getenv("AI_EXPECTED_FIELD_IDS", ""),
    "min_objects": int(os.getenv("AI_MIN_OBJECTS", "1")),
    "min_fields": int(os.getenv("AI_MIN_FIELDS", "1")),
    "min_rows": int(os.getenv("AI_MIN_ROWS", "0")),
    "interactive": os.getenv("AI_INTERACTIVE_FOLLOWUP", "1") == "1",
}

METHOD_SHAPE_REFERENCE = """
Reference behavior patterns (from production connectors like PostgreSQL):
- authenticate(self) -> bool
  - validates credentials and initializes client/connection state.
- get_objects(self) -> list[dict]
  - each object has: object_id, object_name, object_label, optional object_group.
  - if we need to hardcode the objects, we should not do it here. Instead return an empty list with a comment that says objects pulled from API.
- get_fields(self, object_id, options=dict()) -> list[dict]
  - each field has: field_id, field_name, field_label, optional data_type/size.
- get_data(self, object_id, field_ids, n_rows=None, filters=None, next_page=None, options=dict()) -> dict
  - returns {"next_page": token_or_none, "data": [row_dict, ...]}.
- load_data(self, data, object_id, m, update_method, batch_number: int, total_batches: int) -> bool
  - maps/transforms rows and writes data to destination object.
- close(self) -> None
  - gracefully closes resources (session/connection/tunnel/etc).
"""

EXAMPLE_PATTERN = """
```python
def authenticate(self):
        if self.credentials.get("authentication_type_name", "OAuth 2.0") == "OAuth 2.0":
            return self._authenticate_oauth2()
        if self.credentials.get("authentication_type_name", "OAuth 2.0") == "Username and Password":
            raise errors.NotImplementedError("Username and Password authentication is not supported")
        else:
            raise Exception(f"Authentication type {self.credentials.get('authentication_type_name')} is not supported")
    
    def _authenticate_oauth2(self):
        if "code" in self.credentials:
            redirect_uri = self.credentials.get("redirect_uri", None) or self.credentials.get("redirectUrl", None)
            data = {
                "grant_type": "authorization_code",
                "code": self.credentials["code"],
                "client_id": self.credentials["client_id"],
                "client_secret": self.credentials["client_secret"],
                "redirect_uri": redirect_uri,
            }
        else:
            data = {
                'client_id': self.credentials["client_id"],
                'client_secret': self.credentials["client_secret"],
                'grant_type': "refresh_token",
                'refresh_token': self.credentials['token']
            }
        headers = {
            'content-type': self.content_type
        }
        use_production_url = self.credentials['environment'] == 'login' or self.credentials['environment'] == 'production'
        url = self.prod_url if not 'environment' in self.credentials or use_production_url else self.dev_url
        # Retrieve access token for creating a new session with salesforce.
        response = requests.post(url, data=data, headers=headers)
        json_response = response.json()
        if response.ok:
            print("Successfully authenticated")
            self.credentials.pop("code", None)
            if "refresh_token" in json_response:
                self.credentials["token"] = json_response['refresh_token']
            self.credentials["instance_url"] = json_response['instance_url']
            self.instance_url = json_response["instance_url"]
            self.access_token = json_response['access_token']
            try:
                class TimeoutAdapter(HTTPAdapter):
                    def send(self, *args, **kwargs):
                        kwargs['timeout'] = 120
                        return super().send(*args, **kwargs)
                retries = Retry(total=self.retries, backoff_factor=1, status_forcelist=[429, 500, 502, 503, 504])
                sfSession = requests.Session()
                sfSession.mount("https://", TimeoutAdapter(max_retries=retries))
                sfSession.mount("http://", TimeoutAdapter(max_retries=retries))
                self.client = Salesforce(instance_url=self.instance_url, session_id=self.access_token, session=sfSession)
            except Exception as e:
                print(f"Error authenticating: {str(e)}")
                raise errors.AuthenticationError()
        else:
            print("Failed to authenticate")
            error_code = json_response.get('error', 'unknown_error')
            error_description = json_response.get('error_description', 'No error description provided')
            print(error_code)
            print(error_description)
            if error_code in ["invalid_client_id", "invalid_client_credentials"]:
                raise KeyError(
                    f"Please provide the Salesforce Client ID / Client Secret. Error Code: {error_code}. {error_description}"
                )

            if "invalid_grant" in error_code and "inactive organization" in error_description.lower():
                raise errors.AuthenticationError("Inactive organization, please reconnect the connector")
            # AuthenticationError only takes a single message parameter
            error_message = (
                f"{error_description.capitalize()} - Error Code: {error_code}. "
                "For more information, visit: https://help.salesforce.com/s/articleView?id=sf.remoteaccess_oauth_flow_errors.htm&type=5"
            )
            raise Exception(error_message)
        return response.ok
```
"""

# -----------------------------
# SERVER CONTROL
# -----------------------------
def start_server():
    # Reuse an existing server if one is already healthy.
    try:
        health = requests.get(f"{BASE_URL}/health", timeout=2)
        if health.ok:
            return None
    except Exception:
        pass

    proc = subprocess.Popen(
        ["dc-sdk", "http"],
        stdout=subprocess.DEVNULL,
        stderr=subprocess.DEVNULL
    )

    for _ in range(20):
        try:
            requests.get(f"{BASE_URL}/health")
            return proc
        except:
            time.sleep(0.5)

    proc.terminate()
    raise Exception("Server failed to start")


def stop_server(proc):
    if proc is None:
        return
    proc.terminate()
    proc.wait()


# -----------------------------
# INVOKE HELPER
# -----------------------------
def invoke(method, session_id=None, credentials=None, params=None):
    payload = {
        "method": method,
        "session_id": session_id,
        "credentials": credentials if not session_id else None,
        "params": params or {}
    }

    try:
        res = requests.post(f"{BASE_URL}/invoke", json=payload)

        # 🔥 DEBUG: print raw response
        print("\n[RAW RESPONSE]")
        print("Status:", res.status_code)
        print("Text:", res.text)

        try:
            return res.json()
        except Exception:
            return {
                "success": False,
                "error": res.text,
                "status_code": res.status_code,
                "stage": method
            }

    except Exception as e:
        return {
            "success": False,
            "error": str(e),
            "stage": method
        }


# -----------------------------
# TEST CONNECTOR
# -----------------------------
def run_test(credentials):
    session_id = None
    manual_feedback = []

    def attach_manual_feedback(err):
        if not manual_feedback:
            return err
        if isinstance(err, dict):
            err = dict(err)
            err["user_followup"] = "\n".join(manual_feedback)
        return err

    def is_hard_failure(response):
        if not isinstance(response, dict):
            return True
        if response.get("internal_error"):
            return True
        # Only fail when results is None AND we have an error payload.
        if response.get("results") is None:
            return (
                response.get("error") is not None
                or response.get("error_class") is not None
                or response.get("success") is False
            )
        return False

    def prompt_continue(method, response):
        """
        Blocks progression until you provide feedback/confirmation.

        Accepted inputs:
        - `continue` (or `c`) => proceed
        - `fix: <feedback>` => trigger AI patch + fail test so `fix_connector` runs
        - any other non-empty text => treated as notes and progression continues
        """
        if not FOLLOWUP_CONTEXT.get("interactive"):
            return None

        def summarize(res):
            if not isinstance(res, dict):
                return "no details"
            results = res.get("results")
            if method == "get_objects" and isinstance(results, list):
                count = len(results)
                sample = []
                for o in results[:5]:
                    if isinstance(o, dict):
                        sample.append(o.get("object_id") or o.get("id") or o.get("object_label") or o.get("label") or o.get("object_name") or o.get("name"))
                sample_str = ", ".join([str(x) for x in sample if x]) or "no sample"
                return f"{count} objects; sample: {sample_str}"
            if method == "get_fields" and isinstance(results, list):
                return f"{len(results)} fields"
            if method == "get_data" and isinstance(results, dict):
                rows = results.get("data")
                return f"{len(rows) if isinstance(rows, list) else 'unknown'} rows"
            if method == "authenticate":
                return "authenticated"
            return "results returned"

        while True:
            try:
                print(f"\n[FOLLOW-UP] {method} returned results. {summarize(response)}")
                user_in = input(
                    "Type 'continue' (or 'c') to proceed, 'fix: <feedback>' to patch, "
                    "or provide non-empty notes to record: "
                ).strip()
            except EOFError:
                user_in = ""
            except Exception:
                user_in = ""

            if not user_in:
                print("No input provided. Please type one of: 'continue' | 'fix: ...' | notes text.")
                continue

            normalized = user_in.lower()
            if normalized in ("continue", "c"):
                return None

            if normalized.startswith("fix:"):
                # Trigger AI patch.
                manual_feedback.append(f"{method}: {user_in}")
                return {
                    "error_class": "ManualFollowupFeedback",
                    "message": f"User requested AI patch after {method}: {user_in}",
                    "error": f"Manual follow-up for {method}",
                    "internal_error": False,
                    "followup_feedback": True,
                }

            # Treat any other non-empty text as notes.
            manual_feedback.append(f"{method}: {user_in}")
            return None

    # 1) authenticate
    auth_res = invoke("authenticate", session_id, credentials, {})
    print(f"\n--- authenticate ---")
    print(auth_res)
    if is_hard_failure(auth_res):
        return False, "authenticate", attach_manual_feedback(auth_res)

    # Optional pause for your follow-up.
    requested_fix = prompt_continue("authenticate", auth_res)
    if requested_fix:
        return False, "FOLLOWUP", attach_manual_feedback(requested_fix)

    session_id = auth_res.get("session_id")

    # 2) get_objects
    objects_res = invoke("get_objects", session_id, credentials, {})
    print(f"\n--- get_objects ---")
    print(objects_res)
    if is_hard_failure(objects_res):
        return False, "get_objects", attach_manual_feedback(objects_res)

    requested_fix = prompt_continue("get_objects", objects_res)
    if requested_fix:
        return False, "FOLLOWUP", attach_manual_feedback(requested_fix)

    results = objects_res.get("results")
    object_id = extract_first_object_id(results) if isinstance(results, list) else None

    # If we can't proceed, keep asking the user (or request an AI fix).
    while not object_id:
        if not FOLLOWUP_CONTEXT.get("interactive"):
            break
        try:
            user_in = input(
                "No object_id derived from get_objects results. Enter object_id to use for get_fields/get_data, "
                "or type 'fix: <feedback>' to request AI patch (or empty to stop): "
            ).strip()
        except EOFError:
            user_in = ""
        if not user_in:
            # Results are non-null and no connector error happened, but we still need an object_id.
            # Keep waiting rather than exiting as "success".
            print("Waiting for object_id (or type 'fix: ...').")
            continue
        if user_in.lower() == "stop":
            return True, None, None
        if user_in.lower().startswith("fix:"):
            return False, "FOLLOWUP", attach_manual_feedback(build_feedback_error("get_objects", user_in, results))
        object_id = user_in

    # 3) get_fields
    fields_res = invoke("get_fields", session_id, credentials, {"object_id": object_id, "options": {}})
    print(f"\n--- get_fields ---")
    print(fields_res)
    if is_hard_failure(fields_res):
        return False, "get_fields", attach_manual_feedback(fields_res)

    requested_fix = prompt_continue("get_fields", fields_res)
    if requested_fix:
        return False, "FOLLOWUP", attach_manual_feedback(requested_fix)

    field_ids = extract_field_ids(fields_res.get("results"))
    while not field_ids:
        if not FOLLOWUP_CONTEXT.get("interactive"):
            break
        try:
            user_in = input(
                "No field_ids derived from get_fields results. Enter field_ids comma-separated "
                "(or type 'fix: <feedback>' to request AI patch, or empty to stop): "
            ).strip()
        except EOFError:
            user_in = ""
        if not user_in:
            print("Waiting for field_ids (or type 'fix: ...').")
            continue
        if user_in.lower() == "stop":
            return True, None, None
        if user_in.lower().startswith("fix:"):
            return False, "FOLLOWUP", attach_manual_feedback(build_feedback_error("get_fields", user_in, fields_res.get("results")))
        field_ids = [x.strip() for x in user_in.split(",") if x.strip()]

    # 4) get_data
    data_params = {
        "object_id": object_id,
        "field_ids": field_ids[:10],
        "n_rows": 5,
        "filters": None,
        "next_page": None,
        "options": {},
    }
    data_res = invoke("get_data", session_id, credentials, data_params)
    print(f"\n--- get_data ---")
    print(data_res)
    if is_hard_failure(data_res):
        return False, "get_data", attach_manual_feedback(data_res)

    requested_fix = prompt_continue("get_data", data_res)
    if requested_fix:
        return False, "FOLLOWUP", attach_manual_feedback(requested_fix)

    return True, None, None

def is_step_successful(method, response):
    if not isinstance(response, dict):
        return False

    if response.get("internal_error"):
        return False

    # Some SDK responses rely primarily on "results".
    results = response.get("results")
    if method == "authenticate":
        return results is True
    if method in ("get_objects", "get_fields"):
        return isinstance(results, list)
    if method == "get_data":
        return isinstance(results, dict) and "data" in results
    if method == "load_data":
        return results is True

    # Fallback: respect explicit success, otherwise non-None results.
    if response.get("success") is True:
        return True
    return results is not None

def extract_first_object_id(objects_result):
    if not isinstance(objects_result, list):
        return None
    for obj in objects_result:
        if isinstance(obj, dict):
            if obj.get("object_id"):
                return obj["object_id"]
            if obj.get("id"):
                return obj["id"]
    return None

def extract_field_ids(fields_result):
    if not isinstance(fields_result, list):
        return []
    field_ids = []
    for field in fields_result:
        if isinstance(field, dict):
            if field.get("field_id"):
                field_ids.append(field["field_id"])
            elif field.get("id"):
                field_ids.append(field["id"])
    return field_ids

def parse_csv_set(value):
    if not value:
        return set()
    return {item.strip() for item in value.split(",") if item.strip()}

def apply_followup_feedback(method, response):
    """
    Applies quality checks after a method technically succeeds.
    This lets AI continue refining behavior based on expected objects/fields/data.
    """
    results = response.get("results") if isinstance(response, dict) else None

    if method == "get_objects" and isinstance(results, list):
        min_objects = FOLLOWUP_CONTEXT.get("min_objects", 1)
        if len(results) < min_objects:
            return build_feedback_error(
                method,
                f"Expected at least {min_objects} objects but got {len(results)}.",
                results
            )

        expected_ids = parse_csv_set(FOLLOWUP_CONTEXT.get("expected_object_ids"))
        expected_labels = parse_csv_set(FOLLOWUP_CONTEXT.get("expected_object_labels"))
        if expected_ids or expected_labels:
            object_ids = {str(o.get("object_id")) for o in results if isinstance(o, dict) and o.get("object_id")}
            object_labels = {str(o.get("object_label")) for o in results if isinstance(o, dict) and o.get("object_label")}

            missing_ids = sorted(expected_ids - object_ids)
            missing_labels = sorted(expected_labels - object_labels)
            if missing_ids or missing_labels:
                missing_parts = []
                if missing_ids:
                    missing_parts.append(f"missing object_ids: {missing_ids}")
                if missing_labels:
                    missing_parts.append(f"missing object_labels: {missing_labels}")
                return build_feedback_error(method, "; ".join(missing_parts), results)

    if method == "get_fields" and isinstance(results, list):
        min_fields = FOLLOWUP_CONTEXT.get("min_fields", 1)
        if len(results) < min_fields:
            return build_feedback_error(
                method,
                f"Expected at least {min_fields} fields but got {len(results)}.",
                results
            )

        expected_fields = parse_csv_set(FOLLOWUP_CONTEXT.get("expected_field_ids"))
        if expected_fields:
            returned_fields = {str(f.get("field_id")) for f in results if isinstance(f, dict) and f.get("field_id")}
            missing_fields = sorted(expected_fields - returned_fields)
            if missing_fields:
                return build_feedback_error(method, f"Missing expected field_ids: {missing_fields}", results)

    if method == "get_data" and isinstance(results, dict):
        rows = results.get("data")
        min_rows = FOLLOWUP_CONTEXT.get("min_rows", 0)
        if isinstance(rows, list) and len(rows) < min_rows:
            return build_feedback_error(
                method,
                f"Expected at least {min_rows} rows but got {len(rows)}.",
                results
            )

    return None

def build_feedback_error(stage, message, results):
    return {
        "error_class": "FollowupValidationError",
        "message": f"{stage} succeeded but follow-up validation failed: {message}",
        "error": f"Follow-up expectation mismatch. results={results}",
        "internal_error": False,
        "followup_feedback": True,
    }

def collect_manual_followup_feedback(method, response):
    if not FOLLOWUP_CONTEXT.get("interactive"):
        return None

    try:
        print(f"\n[FOLLOW-UP] {method} succeeded.")
        user_feedback = input(
            f"Optional feedback for {method} (e.g. expected objects/fields/rows). Press Enter to continue: "
        ).strip()
    except EOFError:
        return None
    except Exception:
        return None

    if not user_feedback:
        return None

    return {
        "error_class": "ManualFollowupFeedback",
        "message": f"User follow-up feedback after {method}: {user_feedback}",
        "error": f"Manual follow-up for {method}",
        "internal_error": False,
        "followup_feedback": True,
    }

def start_server_api():
    res = requests.get(f"{API_BASE_URL}/")
    if res.status_code != 200:
        # start server docker compose command
        res.raise_for_status()


def get_boto_session():
    return boto3.Session(profile_name="sso_dev")  # ← your profile name


def ensure_aws_authentication():
    print("[AWS] Checking authentication...")

    try:
        session = get_boto_session()
        session.client("sts").get_caller_identity()
        print("[AWS] Already authenticated")
        return

    except Exception:
        print("[AWS] Not authenticated. Running aws sso login...")

    subprocess.run(
        ["aws", "sso", "login", "--profile", "sso_dev"],
        check=True
    )

    # retry with session
    try:
        session = get_boto_session()
        session.client("sts").get_caller_identity()
        print("[AWS] Authentication successful")
    except Exception:
        raise Exception("AWS authentication failed after login")

def get_ssm_parameter(parameter_name):
    if parameter_name in _ssm_cache:
        return _ssm_cache[parameter_name]

    ssm = boto3.client("ssm")

    res = ssm.get_parameter(
        Name=parameter_name,
        WithDecryption=True
    )

    value = res["Parameter"]["Value"]
    _ssm_cache[parameter_name] = value

    return value


def decrypt_customer_data_object(encrypted_data, customer_metadata_uuid, kms_key_id=None):
    if not encrypted_data:
        raise Exception("Missing encrypted credential payload")
    if not customer_metadata_uuid:
        raise Exception("Missing customer metadata UUID for KMS decryption context")

    kms = boto3.client("kms")
    decrypt_kwargs = {
        "CiphertextBlob": b64decode(encrypted_data.encode("utf-8")),
        "EncryptionContext": {"CustomerId": customer_metadata_uuid},
    }
    if kms_key_id:
        decrypt_kwargs["KeyId"] = kms_key_id

    response = kms.decrypt(**decrypt_kwargs)
    plaintext = response.get("Plaintext")
    if not plaintext:
        raise Exception("KMS decryption returned empty plaintext")
    return json.loads(plaintext.decode("utf-8"))


def _auth_type_key(credentials):
    if not isinstance(credentials, dict):
        return None
    for key in (
        "authentication_type_id",
        "AuthenticationTypeID",
        "authenticationTypeId",
        "authentication_type_name",
        "AuthenticationTypeName",
        "authentication_type_nm",
        "authenticationTypeName",
    ):
        value = credentials.get(key)
        if value is not None:
            return str(value)
    return None


def get_test_credentials_from_api():
    api_key_auth = get_ssm_parameter("/dataconnector/development/api/API_KEY_AUTH")
    kms_key_id = get_ssm_parameter("/dataconnector/development/api/AWS_KEY_ID")
    if not api_key_auth:
        raise Exception("Missing API_KEY_AUTH from SSM")
    if not kms_key_id:
        raise Exception("Missing AWS_KEY_ID from SSM")

    connector_id = os.getenv("AI_CONNECTOR_ID")
    if not connector_id:
        raise Exception("Missing AI_CONNECTOR_ID env var for /credential/encrypted endpoint")
    organization_id = os.getenv("AI_ORGANIZATION_ID", "2")
    endpoint = os.getenv(
        "AI_TEST_CREDENTIALS_ENDPOINT",
        f"/api/connector/{connector_id}/credential/encrypted",
    )
    url = f"{API_BASE_URL.rstrip('/')}{endpoint}?organizationId={organization_id}"

    response = requests.get(
        url,
        headers={
            "Accept": "application/json",
            "x-data-connector-access-token": api_key_auth,
        },
        timeout=30,
    )
    if not response.ok:
        raise Exception(
            f"Failed retrieving test credentials from API. Status={response.status_code}, body={response.text}"
        )

    payload = response.json()
    data = payload.get("data", {}) if isinstance(payload, dict) else {}
    encrypted_credentials = data.get("encryptedCredentials") if isinstance(data, dict) else None
    customer_metadata_uuid = data.get("organizationMetadataUUID") if isinstance(data, dict) else None

    if not customer_metadata_uuid:
        raise Exception("Missing organizationMetadataUUID in encrypted credential response")
    if not isinstance(encrypted_credentials, list) or not encrypted_credentials:
        raise Exception("No test credentials found from /credential/encrypted")

    decrypted_credentials = []
    for encrypted in encrypted_credentials:
        decrypted = decrypt_customer_data_object(encrypted, customer_metadata_uuid, kms_key_id)
        if isinstance(decrypted, dict):
            decrypted_credentials.append(decrypted)

    if not decrypted_credentials:
        raise Exception("No decryptable test credentials found from /credential/encrypted")

    # Keep one credential per distinct authentication type id/name when available.
    seen = set()
    distinct_credentials = []
    for credential in decrypted_credentials:
        key = _auth_type_key(credential)
        if key:
            if key in seen:
                continue
            seen.add(key)
        distinct_credentials.append(credential)

    if not distinct_credentials:
        raise Exception("No distinct test credentials available after dedupe")

    return distinct_credentials

def read_connector():
    with open("./src/connector.py", "r") as f:
        return f.read()


def write_connector(code):
    with open("./src/connector.py", "w") as f:
        f.write(code)

def summarize_error(error):
    if not isinstance(error, dict):
        return "", None

    parts = [
        str(error.get("message") or ""),
        str(error.get("error_class") or ""),
        str(error.get("error") or ""),
    ]
    raw = "\n".join([p for p in parts if p]).strip()

    missing_method = None
    match = re.search(r"missing required method:\s*([a-zA-Z_][a-zA-Z0-9_]*)", raw, re.IGNORECASE)
    if match:
        missing_method = match.group(1)

    return raw, missing_method

def extract_python_code(ai_response: str):
    if not ai_response:
        return ""

    text = ai_response.strip()
    fenced = re.search(r"```python\s*(.*?)```", text, flags=re.DOTALL | re.IGNORECASE)
    if fenced:
        return fenced.group(1).strip()

    generic_fenced = re.search(r"```\s*(.*?)```", text, flags=re.DOTALL)
    if generic_fenced:
        return generic_fenced.group(1).strip()

    return text


def fix_connector(stage, error):
    code = read_connector()
    error_text, missing_method = summarize_error(error)
    effective_stage = missing_method if missing_method else stage
    expected_behavior = METHOD_CONTEXT.get(effective_stage) or (
        "Fix the connector so all required methods exist and the current failing stage succeeds."
    )

    prompt = f"""
You are fixing a dc-python-sdk connector.

Connector:
- Name: {CONNECTOR_CONTEXT["name"]}
- Auth Type: {CONNECTOR_CONTEXT["auth_type"]}
- Base URL: {CONNECTOR_CONTEXT["base_url"]}

The connector failed at: {stage}
Resolved failing focus: {effective_stage}

Expected behavior:
{expected_behavior}

Error:
- error_class: {error.get("error_class")}
- message: {error.get("message")}
- raw_error: {error_text}
- followup_feedback: {error.get("followup_feedback")}

Example pattern:
{EXAMPLE_PATTERN}

Rules:
- Use requests, or other common libraries.
- Use self.credentials
- Follow the example pattern
- Return only valid Python code
- If the issue is unrecoverable, do not return code. Return exactly one line in this format: AI_STOP: <REASON>
- Allowed reasons: CREDENTIALS BROKEN, STUCK IN LOOP, MODULE NOT INSTALLED
- fix methods in the file if needed using the default code methods reference.
- Ensure all required connector methods exist ({", ".join(REQUIRED_METHODS)}).
- Use the method signatures exactly as shown in the default reference.
- Match expected return shapes for get_objects/get_fields/get_data/load_data.
- If followup_feedback is true, prioritize fixing data quality/completeness over transport/auth concerns.

Method shape reference:
{METHOD_SHAPE_REFERENCE}

Code:
{code}

default code methods reference:

class Connector:
    def __init__(self, credentials):
        self.credentials = credentials

    def authenticate(self):
        raise NotImplementedError("Connect method not implemented. Please implement authenticate() in your connector class.")

    def get_objects(self):
        raise NotImplementedError("Get objects method not implemented. Please implement get_objects() in your connector class.")

    def get_fields(self, object_id, options=dict()):
        raise NotImplementedError("Get fields method not implemented. Please implement get_fields() in your connector class.")

    def get_data(self, object_id, field_ids, n_rows=None, filters=None, next_page=None, options=dict()):
        raise NotImplementedError("Read method not implemented. Please implement get_data() in your connector class.")

    def load_data(self, data, object_id, m, update_method, batch_number: int, total_batches: int):
        raise NotImplementedError("Write method not implemented. Please implement load_data() in your connector class.")

    def close(self):
        raise NotImplementedError("Close method not implemented. Please implement close() in your connector class.")
"""

    response = client.chat.completions.create(
        model="gpt-5.4",
        messages=[
            {"role": "system", "content": "You fix ETL connectors."},
            {"role": "user", "content": prompt}
        ]
    )

    new_code = response.choices[0].message.content

    print("\n[AI PATCH]")
    print(new_code)
    check_ai_breakers(new_code)
    cleaned_code = extract_python_code(new_code)
    if not cleaned_code:
        raise Exception("AI_STOP: EMPTY_PATCH")

    write_connector(cleaned_code)


def check_ai_breakers(ai_response: str):
    if not ai_response:
        return

    triggers = [
        "CREDENTIALS BROKEN",
        "STUCK IN LOOP",
        "MODULE NOT INSTALLED"
    ]

    lines = [line.strip() for line in ai_response.splitlines() if line.strip()]
    control_lines = [line for line in lines if line.upper().startswith("AI_STOP:")]

    if control_lines:
        reason = control_lines[0].split(":", 1)[1].strip().upper()
        for trigger in triggers:
            if reason == trigger:
                print(f"\n🚨 BREAK CONDITION HIT: {trigger}")
                raise Exception(f"AI_STOP: {trigger}")
        print(f"\n🚨 BREAK CONDITION HIT: {reason}")
        raise Exception(f"AI_STOP: {reason}")

    for trigger in triggers:
        if ai_response.strip().upper() == trigger:
            print(f"\n🚨 BREAK CONDITION HIT: {trigger}")
            raise Exception(f"AI_STOP: {trigger}")

# -----------------------------
# MAIN AI LOOP
# -----------------------------
def start_ai():
    global client

    ensure_aws_authentication()
    start_server_api()

    oa_key = get_ssm_parameter("/dataconnector/development/api/OPENAI_API_KEY")
    if not oa_key:
        raise Exception("Missing OpenAI API key from SSM")
    client = OpenAI(api_key=oa_key)

    credentials_list = get_test_credentials_from_api()
    print(f"Loaded {len(credentials_list)} distinct test credential set(s).")

    for attempt in range(5):
        print(f"\n==============================")
        print(f"Attempt {attempt + 1}")
        print(f"==============================")

        proc = start_server()

        try:
            success = False
            failed_stage = None
            error = None
            for idx, credentials in enumerate(credentials_list, start=1):
                print(f"\n--- Testing credential set {idx}/{len(credentials_list)} ---")
                success, failed_stage, error = run_test(credentials)
                if success:
                    break

        finally:
            stop_server(proc)

        if success:
            print("\n✅ CONNECTOR WORKS")
            return

        print(f"\n❌ Failed at: {failed_stage}")
        fix_connector(failed_stage, error)

        time.sleep(1)