import sys
from importlib.metadata import version
import os

def get_arg(name, default=None):
    if name in sys.argv:
        idx = sys.argv.index(name)
        if idx + 1 < len(sys.argv):
            return sys.argv[idx + 1]
    return default

def main():
    if len(sys.argv) < 2:
        print("Usage: dc-sdk [http|ai|ai-http]")
        sys.exit(1)

    command = sys.argv[1]

    print("version: ", version("dc-python-sdk"))

    print(f"[DC SDK] Command: {command}")

    if command == "http":
        from dc_sdk.src.server import start_server
        start_server()

    elif command == "ai":
        from dc_sdk.src.ai import start_ai
        start_ai()

    elif command == "ai-http":
        from dc_sdk.src.ai_http import start_ai_http
        start_ai_http()
    
    else:
        print(f"Unknown command: {command}")
        sys.exit(1)