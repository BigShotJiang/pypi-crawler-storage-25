"""Tool registry — wires ops modules into the JSON-RPC server.

Each ops module exposes plain Python functions; this module describes their
JSON Schema and registers them with an :class:`MCPServer`. Adding a new tool
means appending one entry here.
"""

from __future__ import annotations

from typing import TYPE_CHECKING

from pbirb_mcp.ops import (
    actions,
    body,
    chart,
    clone,
    dataset,
    datasource,
    embedded_images,
    header_footer,
    images,
    page,
    parameters,
    positioning,
    reader,
    snapshot,
    styling,
    tablix,
    tablix_cells,
    tablix_columns,
    tablix_static,
    tablix_subtotals,
    templates,
    validate,
    visibility,
)
from pbirb_mcp.ops import dry_run as _dry_run
from pbirb_mcp.ops import escape as _escape
from pbirb_mcp.ops import expressions as _expressions
from pbirb_mcp.ops import layout as _layout
from pbirb_mcp.ops import lint as _lint

if TYPE_CHECKING:
    from pbirb_mcp.server import MCPServer


_PATH_ONLY_SCHEMA: dict = {
    "type": "object",
    "properties": {
        "path": {
            "type": "string",
            "description": "Absolute path to the .rdl file to read.",
        }
    },
    "required": ["path"],
    "additionalProperties": False,
}


def register_all_tools(server: MCPServer) -> None:
    server.register_tool(
        name="describe_report",
        description=(
            "Top-level inventory of an RDL: data sources, datasets, parameters, "
            "tablixes, and page setup. Always the first call when planning edits."
        ),
        input_schema=_PATH_ONLY_SCHEMA,
        handler=reader.describe_report,
    )
    server.register_tool(
        name="get_datasets",
        description=(
            "Full DAX command text, fields, query parameters, and dataset-level "
            "filters for every DataSet in the report."
        ),
        input_schema=_PATH_ONLY_SCHEMA,
        handler=reader.get_datasets,
    )
    server.register_tool(
        name="get_parameters",
        description="Report parameter declarations: name, data type, prompt, flags.",
        input_schema=_PATH_ONLY_SCHEMA,
        handler=reader.get_parameters,
    )
    server.register_tool(
        name="get_tablixes",
        description=(
            "Tablix layout with stable IDs: columns, row/column groups, sort "
            "expressions, filters, visibility. Required input for any tablix edit."
        ),
        input_schema=_PATH_ONLY_SCHEMA,
        handler=reader.get_tablixes,
    )

    server.register_tool(
        name="update_dataset_query",
        description=(
            "Replace the DAX command text of a named dataset. The full DAX "
            "expression is accepted verbatim; empty bodies are rejected. "
            "Optional alias_strategy='preserve_field_names' positionally "
            "rewrites <DataField> cells to the new DAX columns while "
            "keeping existing <Field Name> identifiers — so "
            "Fields!X.Value references in expressions keep resolving."
        ),
        input_schema={
            "type": "object",
            "properties": {
                "path": {"type": "string"},
                "dataset_name": {"type": "string"},
                "dax_body": {
                    "type": "string",
                    "description": "Full DAX (e.g. EVALUATE TOPN(10, 'Sales')).",
                },
                "alias_strategy": {
                    "type": ["string", "null"],
                    "enum": [None, "preserve_field_names"],
                    "description": (
                        "When 'preserve_field_names', positionally remap "
                        "<DataField> cells to the new DAX column list."
                    ),
                },
            },
            "required": ["path", "dataset_name", "dax_body"],
            "additionalProperties": False,
        },
        handler=dataset.update_dataset_query,
    )
    server.register_tool(
        name="add_query_parameter",
        description=(
            "Add a <QueryParameter> binding to a dataset's query. Use to "
            "wire report parameters into DAX (e.g. "
            "=Parameters!DateFrom.Value).\n"
            "\n"
            "PBIDATASET parameter naming rule: in DAX/<CommandText>, "
            "write @MyParam (with @). In <QueryParameter Name=...>, "
            "write MyParam (no @). SQL/MDX use @ in both places. This "
            "tool detects the dataset's provider and AUTO-STRIPS a "
            "leading @ from `name` for PBIDATASET datasets, returning "
            "{normalised: true, warning: ...}. Pass force_at_prefix=true "
            "to override (rare; needed for some RSCustomDaxFilter "
            "patterns)."
        ),
        input_schema={
            "type": "object",
            "properties": {
                "path": {"type": "string"},
                "dataset_name": {"type": "string"},
                "name": {"type": "string"},
                "value_expression": {"type": "string"},
                "force_at_prefix": {"type": "boolean", "default": False},
            },
            "required": ["path", "dataset_name", "name", "value_expression"],
            "additionalProperties": False,
        },
        handler=dataset.add_query_parameter,
    )
    server.register_tool(
        name="update_query_parameter",
        description=(
            "Change the value expression of an existing query parameter. "
            "Same PBIDATASET @-prefix normalisation as add_query_parameter "
            "applies on lookup; legacy Name='@X' parameters that already "
            "exist on disk are addressable via either @X or X."
        ),
        input_schema={
            "type": "object",
            "properties": {
                "path": {"type": "string"},
                "dataset_name": {"type": "string"},
                "name": {"type": "string"},
                "value_expression": {"type": "string"},
                "force_at_prefix": {"type": "boolean", "default": False},
            },
            "required": ["path", "dataset_name", "name", "value_expression"],
            "additionalProperties": False,
        },
        handler=dataset.update_query_parameter,
    )
    server.register_tool(
        name="set_datasource_connection",
        description=(
            "Repoint a DataSource at a Power BI XMLA endpoint. workspace_url "
            "accepts a bare workspace name or a full powerbi:// URL; "
            "DataProvider is set to SQL (the AS provider id in RDL)."
        ),
        input_schema={
            "type": "object",
            "properties": {
                "path": {"type": "string"},
                "name": {
                    "type": "string",
                    "description": "RDL DataSource Name attribute.",
                },
                "workspace_url": {
                    "type": "string",
                    "description": "Workspace name or full powerbi:// XMLA URL.",
                },
                "dataset_name": {
                    "type": "string",
                    "description": "PBI semantic model (Initial Catalog).",
                },
                "integrated_security": {
                    "type": "boolean",
                    "description": "Default true. False omits the element.",
                },
            },
            "required": ["path", "name", "workspace_url", "dataset_name"],
            "additionalProperties": False,
        },
        handler=datasource.set_datasource_connection,
    )
    server.register_tool(
        name="list_data_sources",
        description=(
            "Return a rich list of every <DataSource> in the report — "
            "name, data_provider, connect_string, integrated_security, "
            "shared_reference, security_type, data_source_id. "
            "describe_report.data_sources returns names only; this tool "
            "is the authoring-friendly read."
        ),
        input_schema=_PATH_ONLY_SCHEMA,
        handler=datasource.list_data_sources,
    )
    server.register_tool(
        name="get_data_source",
        description=(
            "Single-DataSource read-back (parity with get_textbox / "
            "get_image / get_rectangle / get_chart). Returns the same "
            "shape as one entry of list_data_sources."
        ),
        input_schema={
            "type": "object",
            "properties": {
                "path": {"type": "string"},
                "name": {"type": "string"},
            },
            "required": ["path", "name"],
            "additionalProperties": False,
        },
        handler=datasource.get_data_source,
    )
    server.register_tool(
        name="add_data_source",
        description=(
            "Create a new <DataSource> for a Power BI XMLA endpoint. "
            "workspace_url accepts a bare workspace name or a full "
            "powerbi:// URL. Generates a fresh rd:DataSourceID GUID. "
            "Refuses if a DataSource of the same name already exists."
        ),
        input_schema={
            "type": "object",
            "properties": {
                "path": {"type": "string"},
                "name": {"type": "string"},
                "workspace_url": {"type": "string"},
                "dataset_name": {"type": "string"},
                "integrated_security": {"type": "boolean", "default": True},
            },
            "required": ["path", "name", "workspace_url", "dataset_name"],
            "additionalProperties": False,
        },
        handler=datasource.add_data_source,
    )
    server.register_tool(
        name="remove_data_source",
        description=(
            "Remove a named <DataSource>. Refuses by default if any "
            "DataSet/Query/DataSourceName or DataSource/"
            "DataSourceReference still references it; the error lists "
            "the offending locators. Pass force=True to remove anyway."
        ),
        input_schema={
            "type": "object",
            "properties": {
                "path": {"type": "string"},
                "name": {"type": "string"},
                "force": {"type": "boolean", "default": False},
            },
            "required": ["path", "name"],
            "additionalProperties": False,
        },
        handler=datasource.remove_data_source,
    )
    server.register_tool(
        name="rename_data_source",
        description=(
            "Rename a <DataSource> and rewrite every reference: "
            "DataSet/Query/DataSourceName entries AND any "
            "DataSource/DataSourceReference shared-source links. "
            "Atomic: stages all matches before committing. Errors if "
            "new_name already exists or equals old_name."
        ),
        input_schema={
            "type": "object",
            "properties": {
                "path": {"type": "string"},
                "old_name": {"type": "string"},
                "new_name": {"type": "string"},
            },
            "required": ["path", "old_name", "new_name"],
            "additionalProperties": False,
        },
        handler=datasource.rename_data_source,
    )
    server.register_tool(
        name="list_dataset_filters",
        description=(
            "List dataset-level filters in document order. Returns "
            "[{expression, operator, values}]; index in the list is the "
            "stable handle for remove_dataset_filter. DataSet filters "
            "apply to every consumer of the dataset (every Tablix / "
            "Chart bound to it); use list_tablix_filters for per-tablix "
            "filtering."
        ),
        input_schema={
            "type": "object",
            "properties": {
                "path": {"type": "string"},
                "dataset_name": {"type": "string"},
            },
            "required": ["path", "dataset_name"],
            "additionalProperties": False,
        },
        handler=dataset.list_dataset_filters,
    )
    server.register_tool(
        name="add_dataset_filter",
        description=(
            "Append a <Filter> to the named dataset's <Filters> block. "
            "operator ∈ Equal / NotEqual / GreaterThan / LessThan / "
            "GreaterThanOrEqual / LessThanOrEqual / Like / In / Between "
            "/ TopN / BottomN / TopPercent / BottomPercent. values must "
            "be non-empty (single-value filters use a one-element list). "
            "Returns the new filter's index for later removal. Optional "
            "field_format wraps the expression as Format(<body>, fmt) "
            "to coerce typed fields for string-parameter comparison. "
            "Response includes warnings for field/parameter type "
            "mismatches detected via best-effort cross-check."
        ),
        input_schema={
            "type": "object",
            "properties": {
                "path": {"type": "string"},
                "dataset_name": {"type": "string"},
                "expression": {
                    "type": "string",
                    "description": "FilterExpression — usually a Fields! reference.",
                },
                "operator": {"type": "string"},
                "values": {
                    "type": "array",
                    "items": {"type": "string"},
                    "minItems": 1,
                },
                "field_format": {
                    "type": "string",
                    "description": (
                        "Optional format string (e.g. 'MMM, yyyy') wrapping "
                        "the expression as Format(<body>, '<fmt>')."
                    ),
                },
            },
            "required": [
                "path",
                "dataset_name",
                "expression",
                "operator",
                "values",
            ],
            "additionalProperties": False,
        },
        handler=dataset.add_dataset_filter,
    )
    server.register_tool(
        name="remove_dataset_filter",
        description=(
            "Remove a dataset-level filter by its 0-based document-order "
            "index. Cleans up the empty <Filters> block when removing the "
            "last entry."
        ),
        input_schema={
            "type": "object",
            "properties": {
                "path": {"type": "string"},
                "dataset_name": {"type": "string"},
                "filter_index": {"type": "integer", "minimum": 0},
            },
            "required": ["path", "dataset_name", "filter_index"],
            "additionalProperties": False,
        },
        handler=dataset.remove_dataset_filter,
    )
    server.register_tool(
        name="get_dataset",
        description=(
            "Single-DataSet read-back (parity with get_textbox / "
            "get_image / get_rectangle / get_chart / get_data_source). "
            "Returns dataset name, data_source, command_text, fields "
            "(with both data_field and value), query_parameters, "
            "filters, and designer_state_present."
        ),
        input_schema={
            "type": "object",
            "properties": {
                "path": {"type": "string"},
                "name": {"type": "string"},
            },
            "required": ["path", "name"],
            "additionalProperties": False,
        },
        handler=dataset.get_dataset,
    )
    server.register_tool(
        name="add_calculated_field",
        description=(
            "Append a calculated <Field> to the named dataset. "
            "Calculated fields carry an expression (<Value>) instead of "
            "a column reference (<DataField>); use them for derived "
            "fields like Total = Amount * Quantity that aren't in the "
            "source query but should be available via Fields!Name.Value. "
            "Refuses if a field of the same name already exists."
        ),
        input_schema={
            "type": "object",
            "properties": {
                "path": {"type": "string"},
                "dataset_name": {"type": "string"},
                "field_name": {"type": "string"},
                "expression": {
                    "type": "string",
                    "description": "RDL expression, e.g. '=Fields!Amount.Value * Fields!Quantity.Value'.",
                },
            },
            "required": ["path", "dataset_name", "field_name", "expression"],
            "additionalProperties": False,
        },
        handler=dataset.add_calculated_field,
    )
    server.register_tool(
        name="remove_calculated_field",
        description=(
            "Remove a calculated <Field> by name. Refuses if the field "
            "is data-bound (carries <DataField> instead of <Value>) — "
            "those reflect the source query's columns. Drop a data-bound "
            "field via remove_dataset_field, or rewrite the dataset "
            "query via update_dataset_query."
        ),
        input_schema={
            "type": "object",
            "properties": {
                "path": {"type": "string"},
                "dataset_name": {"type": "string"},
                "field_name": {"type": "string"},
            },
            "required": ["path", "dataset_name", "field_name"],
            "additionalProperties": False,
        },
        handler=dataset.remove_calculated_field,
    )
    server.register_tool(
        name="remove_dataset_field",
        description=(
            "Remove a data-bound <Field> by name (one with <DataField>). "
            "Symmetric counterpart to remove_calculated_field. Refuses "
            "on calculated fields (use remove_calculated_field instead) "
            "and on still-referenced fields (any expression containing "
            "Fields!<name>.Value / .IsMissing / .Count). Pass "
            "force=True to delete anyway. Closes the cookbook flow: "
            "refresh_dataset_fields lists orphans, "
            "remove_dataset_field drops them. Returns "
            "{dataset, removed, kind: 'DataBoundField'}."
        ),
        input_schema={
            "type": "object",
            "properties": {
                "path": {"type": "string"},
                "dataset_name": {"type": "string"},
                "field_name": {"type": "string"},
                "force": {
                    "type": "boolean",
                    "description": (
                        "Default false: refuse if the field is still "
                        "referenced anywhere. true: delete anyway "
                        "(prefer fixing the references first)."
                    ),
                },
            },
            "required": ["path", "dataset_name", "field_name"],
            "additionalProperties": False,
        },
        handler=dataset.remove_dataset_field,
    )
    server.register_tool(
        name="add_dataset_field",
        description=(
            "Append a data-bound <Field> to a dataset's <Fields> block. "
            "Writes <DataField>data_field</DataField> (and optional "
            "<rd:TypeName>type_name</rd:TypeName>). Distinct from "
            "add_calculated_field which writes <Value> for derived "
            "fields. Use after rewriting the DAX to declare a new "
            "column that came back from the query but isn't yet in "
            "<Fields>. Refuses on duplicate field name."
        ),
        input_schema={
            "type": "object",
            "properties": {
                "path": {"type": "string"},
                "dataset_name": {"type": "string"},
                "field_name": {"type": "string"},
                "data_field": {
                    "type": "string",
                    "description": (
                        "Source column reference, e.g. 'Sales[ProductID]' "
                        "or '[Region]' (the form depends on DAX shape)."
                    ),
                },
                "type_name": {
                    "type": ["string", "null"],
                    "description": (
                        ".NET type, e.g. 'System.String', "
                        "'System.DateTime', 'System.Decimal'. Optional."
                    ),
                },
            },
            "required": ["path", "dataset_name", "field_name", "data_field"],
            "additionalProperties": False,
        },
        handler=dataset.add_dataset_field,
    )
    server.register_tool(
        name="refresh_dataset_fields",
        description=(
            "Sync a dataset's <Fields> block against the shape detected "
            "in its DAX <CommandText>. Eliminates the manual 'open "
            "Report Builder → right-click → Refresh Fields' step after "
            "a query rewrite. Recognises SELECTCOLUMNS aliases and "
            "Table[Col] tokens (SUMMARIZECOLUMNS / ad-hoc). Adds missing "
            "fields; lists orphans without auto-removing (caller decides "
            "what to drop). Returns {added, orphans, unchanged, "
            "warnings}. Cheap regex-based detection — bare EVALUATE "
            "'Table' returns a warning."
        ),
        input_schema={
            "type": "object",
            "properties": {
                "path": {"type": "string"},
                "dataset_name": {"type": "string"},
            },
            "required": ["path", "dataset_name"],
            "additionalProperties": False,
        },
        handler=dataset.refresh_dataset_fields,
    )
    server.register_tool(
        name="set_image_sizing",
        description=(
            "Set <Image>/<Sizing> on a named Image. sizing ∈ AutoSize / "
            "Fit / FitProportional / Clip. AutoSize renders at native "
            "size (box grows to fit); Fit stretches to fill (ignores "
            "aspect ratio); FitProportional preserves aspect ratio; "
            "Clip renders at native size, clipped to the box. "
            "Idempotent: same value → {changed: false}, no save."
        ),
        input_schema={
            "type": "object",
            "properties": {
                "path": {"type": "string"},
                "image_name": {"type": "string"},
                "sizing": {
                    "type": "string",
                    "enum": ["AutoSize", "Fit", "FitProportional", "Clip"],
                },
            },
            "required": ["path", "image_name", "sizing"],
            "additionalProperties": False,
        },
        handler=images.set_image_sizing,
    )
    server.register_tool(
        name="set_image_source",
        description=(
            "Repoint an existing <Image> at a different embedded image "
            "entry without delete-and-readd. Sets Source=Embedded and "
            "rewrites <Value> to embedded_name. Refuses with a clear "
            "error if embedded_name isn't in <EmbeddedImages> — leaving "
            "a dangling reference would render as a broken image. Add "
            "the image first via add_embedded_image. Idempotent: same "
            "(Source, Value) pair → {changed: false}, no save. Returns "
            "{name, kind, changed: bool}."
        ),
        input_schema={
            "type": "object",
            "properties": {
                "path": {"type": "string"},
                "image_name": {"type": "string"},
                "embedded_name": {"type": "string"},
            },
            "required": ["path", "image_name", "embedded_name"],
            "additionalProperties": False,
        },
        handler=images.set_image_source,
    )
    server.register_tool(
        name="set_column_width",
        description=(
            "Set <Width> on a tablix's body column. column accepts a "
            "0-based integer index OR a textbox name living in any cell "
            "of that column (mirrors how set_cell_span / add_subtotal_row "
            "address columns). width is an RDL size ('1.5in', '4cm', "
            "'80pt'). Idempotent: same width → {changed: false}, no save."
        ),
        input_schema={
            "type": "object",
            "properties": {
                "path": {"type": "string"},
                "tablix_name": {"type": "string"},
                "column": {
                    "oneOf": [
                        {"type": "integer", "minimum": 0},
                        {"type": "string"},
                    ],
                    "description": "0-based column index or textbox name in any column cell.",
                },
                "width": {"type": "string"},
            },
            "required": ["path", "tablix_name", "column", "width"],
            "additionalProperties": False,
        },
        handler=tablix_columns.set_column_width,
    )
    server.register_tool(
        name="set_tablix_size",
        description=(
            "Resize a tablix by writing <Height> and / or <Width> directly. "
            "Each arg independently optional. Use after adding header / "
            "footer rows that change the body's natural height — v0.2's "
            "positioning tools only cover top/left, not size. Both values "
            "are RDL size strings. Returns {tablix, kind, changed: "
            "list[str]} — empty list when inputs match existing."
        ),
        input_schema={
            "type": "object",
            "properties": {
                "path": {"type": "string"},
                "name": {"type": "string"},
                "height": {"type": "string"},
                "width": {"type": "string"},
            },
            "required": ["path", "name"],
            "additionalProperties": False,
        },
        handler=tablix.set_tablix_size,
    )
    server.register_tool(
        name="reorder_parameters",
        description=(
            "Reorder <ReportParameter> children to match the supplied "
            "names list. names MUST be a permutation of every existing "
            "parameter — no missing, no duplicates, no unknown names. "
            "When a <ReportParametersLayout> exists, its CellDefinition "
            "entries are reordered in lockstep so the parameter pane "
            "shows fields in the new declaration order. RowIndex / "
            "ColumnIndex are not recomputed (RB's layout grid is "
            "independent of declaration order). Returns {order, kind, "
            "changed: bool}; same order → no save."
        ),
        input_schema={
            "type": "object",
            "properties": {
                "path": {"type": "string"},
                "names": {
                    "type": "array",
                    "items": {"type": "string"},
                    "minItems": 1,
                },
            },
            "required": ["path", "names"],
            "additionalProperties": False,
        },
        handler=parameters.reorder_parameters,
    )
    server.register_tool(
        name="set_parameter_layout",
        description=(
            "Author <ReportParametersLayout>/<GridLayoutDefinition> "
            "explicitly. Writes <NumberOfRows> + <NumberOfColumns>; "
            "rewrites <CellDefinitions> so each name in parameter_order "
            "lands at (row=index // columns, col=index % columns). "
            "Strict permutation check (every existing parameter exactly "
            "once). rows*columns must be ≥ parameter count. Auto-creates "
            "the layout block when absent. Idempotent: same grid + order "
            "→ no save. Complements reorder_parameters (declaration "
            "order) and sync_parameter_layout (gap-filling). Returns "
            "{rows, columns, order, kind, changed}."
        ),
        input_schema={
            "type": "object",
            "properties": {
                "path": {"type": "string"},
                "rows": {"type": "integer", "minimum": 1},
                "columns": {"type": "integer", "minimum": 1},
                "parameter_order": {
                    "type": "array",
                    "items": {"type": "string"},
                    "minItems": 1,
                },
            },
            "required": ["path", "rows", "columns", "parameter_order"],
            "additionalProperties": False,
        },
        handler=parameters.set_parameter_layout,
    )
    server.register_tool(
        name="duplicate_report",
        description=(
            "Clone an .rdl to a new path. When regenerate_ids=true "
            "(default), every <rd:DataSourceID> and any <rd:ReportID> "
            "is rewritten to a fresh uuid4() so Power BI Report Builder "
            "doesn't refuse to load the duplicate due to identity "
            "collision. Atomic-write convention from RDLDocument.save_as. "
            "Refuses if dst_path already exists. Returns {src, dst, "
            "regenerated_ids: list[str]}."
        ),
        input_schema={
            "type": "object",
            "properties": {
                "src_path": {"type": "string"},
                "dst_path": {"type": "string"},
                "regenerate_ids": {"type": "boolean", "default": True},
            },
            "required": ["src_path", "dst_path"],
            "additionalProperties": False,
        },
        handler=clone.duplicate_report,
    )
    server.register_tool(
        name="get_embedded_image_data",
        description=(
            "Read an embedded image's base64 <ImageData> for porting "
            "it to another report without re-reading from disk. Returns "
            "{name, mime_type, base64, byte_size}. base64 is the raw "
            "text of the ImageData element; byte_size is the decoded "
            "size for sanity-checking. Refuses with ElementNotFoundError "
            "if the named entry isn't in <EmbeddedImages>."
        ),
        input_schema={
            "type": "object",
            "properties": {
                "path": {"type": "string"},
                "name": {"type": "string"},
            },
            "required": ["path", "name"],
            "additionalProperties": False,
        },
        handler=embedded_images.get_embedded_image_data,
    )

    # ---- validation (Phase 7) -------------------------------------------

    server.register_tool(
        name="validate_report",
        description=(
            "Run schema/structural validation against an .rdl. Returns "
            "{valid, errors, xsd_used}. Structural checks always run "
            "(root element + required top-level sections). The Microsoft "
            "RDL 2016/01 XSD is bundled by default since v0.3.1 — when "
            "it's loaded, xsd_used is True and the schema-conformance "
            "bug class Power BI Report Builder rejects on load gets "
            "caught here. If the bundled XSD is missing (source-build "
            "without package-data) a {severity:warning, "
            "rule:'xsd-not-bundled'} issue surfaces instead of silent "
            "skip. Each issue is {severity, rule, location, message, "
            "suggestion?}; valid is True iff no severity='error' issue."
        ),
        input_schema=_PATH_ONLY_SCHEMA,
        handler=validate.validate_report,
    )

    server.register_tool(
        name="verify_report",
        description=(
            "One-shot static check: union of validate_report and "
            "lint_report. Returns {valid, issues, xsd_used} where "
            "valid is True iff no issue has severity='error'. "
            "Warnings (including 'xsd-not-bundled' when the schema "
            "file is missing) don't invalidate the report. Use this as "
            "the single 'is the report OK?' tool, or set "
            "PBIRB_MCP_AUTO_VERIFY=1 to have it run after every "
            "mutating call."
        ),
        input_schema=_PATH_ONLY_SCHEMA,
        handler=validate.verify_report,
    )

    server.register_tool(
        name="lint_report",
        description=(
            "Run static-analysis lint rules against an .rdl. Sixteen "
            "rules cover the v0.2/v0.3 sweep bug classes (multi-value-eq, "
            "missing-field-reference, dangling-embedded-image, "
            "pbidataset-at-prefix, parameter-layout-out-of-sync, "
            "double-encoded-entities, stale-designer-state, "
            "tablix-span-misplaced, dataset-fields-out-of-sync, etc.). "
            "Returns {issues, rules_run} with each issue {severity, "
            "rule, location, message, suggestion?}. Optional `rules` "
            "selects a subset by name."
        ),
        input_schema={
            "type": "object",
            "properties": {
                "path": {"type": "string"},
                "rules": {
                    "type": "array",
                    "items": {"type": "string"},
                    "description": "Optional subset of rule names; default runs all 16.",
                },
            },
            "required": ["path"],
            "additionalProperties": False,
        },
        handler=_lint.lint_report,
    )

    server.register_tool(
        name="dry_run_edit",
        description=(
            "Apply a list of {tool, args} ops to a tempfile clone of "
            "the report; return the unified diff and a verify "
            "(validate + lint) report. The original file is NEVER "
            "modified. The harness auto-injects `path` into each op's "
            "args, so callers don't supply it. On op failure, dispatch "
            "stops; partial diff + verify are still returned. Use this "
            "to preview risky multi-step edits before committing."
        ),
        input_schema={
            "type": "object",
            "properties": {
                "path": {"type": "string"},
                "ops": {
                    "type": "array",
                    "items": {
                        "type": "object",
                        "properties": {
                            "tool": {"type": "string"},
                            "args": {"type": "object"},
                        },
                        "required": ["tool"],
                        "additionalProperties": False,
                    },
                    "description": "Sequence of tool calls to dispatch against the tempfile.",
                },
            },
            "required": ["path", "ops"],
            "additionalProperties": False,
        },
        handler=_dry_run.dry_run_edit,
    )

    server.register_tool(
        name="get_expression_reference",
        description=(
            "Return a static cheat-sheet of common RDL expression "
            "patterns: globals, parameters, fields, aggregates, "
            "conditionals, strings, dates. Each entry is {name, syntax, "
            "example, description}. Call this when authoring a textbox "
            "value or filter expression instead of guessing — and note "
            "the explicit encoding hint for the `&` concat operator."
        ),
        input_schema={
            "type": "object",
            "properties": {},
            "additionalProperties": False,
        },
        handler=_expressions.get_expression_reference,
    )

    server.register_tool(
        name="count_where",
        description=(
            "Emit =Sum(IIf(<condition>, 1, 0)) — the SSRS conditional-count "
            "idiom. condition is an RDL expression body (no leading '='). "
            "Returns a complete top-level expression suitable for "
            "set_textbox_value or any RDL <Value> sink."
        ),
        input_schema={
            "type": "object",
            "properties": {
                "condition": {
                    "type": "string",
                    "description": (
                        "RDL expression body, e.g. 'Fields!Status.Value = \"Active\"'."
                    ),
                },
            },
            "required": ["condition"],
            "additionalProperties": False,
        },
        handler=_expressions.count_where,
    )

    server.register_tool(
        name="sum_where",
        description=(
            "Emit =Sum(IIf(<condition>, <field_expression>, 0)) — the SSRS "
            "conditional-sum idiom. Both args are expression bodies "
            "(no leading '=')."
        ),
        input_schema={
            "type": "object",
            "properties": {
                "field_expression": {
                    "type": "string",
                    "description": ("Value to sum, e.g. 'Fields!Amount.Value'."),
                },
                "condition": {
                    "type": "string",
                    "description": (
                        "RDL expression body, e.g. 'Fields!Status.Value = \"Active\"'."
                    ),
                },
            },
            "required": ["field_expression", "condition"],
            "additionalProperties": False,
        },
        handler=_expressions.sum_where,
    )

    server.register_tool(
        name="iif_format",
        description=(
            "Emit =IIf(<condition>, <true_value>, <false_value>). All three "
            "args are expression bodies (no leading '='); string literals "
            "must already be quoted, e.g. true_value='\"Yes\"'."
        ),
        input_schema={
            "type": "object",
            "properties": {
                "condition": {"type": "string"},
                "true_value": {"type": "string"},
                "false_value": {"type": "string"},
            },
            "required": ["condition", "true_value", "false_value"],
            "additionalProperties": False,
        },
        handler=_expressions.iif_format,
    )

    # ---- pagination (Phase 10) ------------------------------------------

    server.register_tool(
        name="set_group_page_break",
        description=(
            "Set <BreakLocation> on a tablix group's page-break rule. "
            "location ∈ {None, Start, End, StartAndEnd, Between}. "
            "Passing 'None' removes the <PageBreak> element (the "
            "canonical 'no break' shape). Idempotent. Returns "
            "{tablix, group, kind: 'Group', location, changed}."
        ),
        input_schema={
            "type": "object",
            "properties": {
                "path": {"type": "string"},
                "tablix_name": {"type": "string"},
                "group_name": {"type": "string"},
                "location": {
                    "type": "string",
                    "enum": list(_layout._VALID_BREAK_LOCATIONS),
                },
            },
            "required": ["path", "tablix_name", "group_name", "location"],
            "additionalProperties": False,
        },
        handler=_layout.set_group_page_break,
    )

    server.register_tool(
        name="set_repeat_on_new_page",
        description=(
            "Set <TablixMember>/<RepeatOnNewPage> on the member that "
            "wraps the named group. Most common use: repeat a group "
            "header row at the top of every page the group spans. "
            "Setting repeat=False removes the element (False is "
            "default). Returns {tablix, group, kind: 'TablixMember', "
            "repeat, changed}."
        ),
        input_schema={
            "type": "object",
            "properties": {
                "path": {"type": "string"},
                "tablix_name": {"type": "string"},
                "group_name": {"type": "string"},
                "repeat": {"type": "boolean"},
            },
            "required": ["path", "tablix_name", "group_name", "repeat"],
            "additionalProperties": False,
        },
        handler=_layout.set_repeat_on_new_page,
    )

    server.register_tool(
        name="set_keep_together",
        description=(
            "Set <KeepTogether> on a named Tablix / Rectangle / Chart / "
            "Textbox / Map / Gauge. Tells the renderer 'don't split "
            "this across pages if you can help it'. Best-effort — "
            "items larger than a page are still split. keep=False "
            "removes the element. Refuses for Image / Line / Subreport "
            "and other kinds where the RDL XSD doesn't allow it."
        ),
        input_schema={
            "type": "object",
            "properties": {
                "path": {"type": "string"},
                "name": {"type": "string"},
                "keep": {"type": "boolean"},
            },
            "required": ["path", "name", "keep"],
            "additionalProperties": False,
        },
        handler=_layout.set_keep_together,
    )

    server.register_tool(
        name="set_keep_with_group",
        description=(
            "Set <TablixMember>/<KeepWithGroup> on the member that "
            "wraps the named group. value ∈ {None, Before, After}. "
            "Typical use: a column-header row's member with 'After' "
            "to glue it to the data rows that follow. value='None' "
            "removes the element."
        ),
        input_schema={
            "type": "object",
            "properties": {
                "path": {"type": "string"},
                "tablix_name": {"type": "string"},
                "group_name": {"type": "string"},
                "value": {
                    "type": "string",
                    "enum": list(_layout._VALID_KEEP_WITH_GROUP),
                },
            },
            "required": ["path", "tablix_name", "group_name", "value"],
            "additionalProperties": False,
        },
        handler=_layout.set_keep_with_group,
    )

    # ---- layout containers (Phase 11) -----------------------------------

    server.register_tool(
        name="add_rectangle",
        description=(
            "Add a <Rectangle> to <Body>/<ReportItems>. With no "
            "contained_items the rectangle is empty (a visual frame). "
            "With contained_items=[name1, name2, ...], each named "
            "body item is MOVED into the rectangle's <ReportItems> "
            "and its <Top>/<Left> recalculated so the on-screen "
            "position is preserved. Refuses on duplicate name or "
            "if any contained_item isn't in <Body>/<ReportItems>. "
            "Returns {name, kind: 'Rectangle', moved}."
        ),
        input_schema={
            "type": "object",
            "properties": {
                "path": {"type": "string"},
                "name": {"type": "string"},
                "top": {"type": "string"},
                "left": {"type": "string"},
                "width": {"type": "string"},
                "height": {"type": "string"},
                "contained_items": {
                    "type": "array",
                    "items": {"type": "string"},
                    "description": (
                        "Names of existing body items to move into the "
                        "rectangle. Empty list / omitted → empty rectangle."
                    ),
                },
            },
            "required": ["path", "name", "top", "left", "width", "height"],
            "additionalProperties": False,
        },
        handler=_layout.add_rectangle,
    )

    server.register_tool(
        name="add_list",
        description=(
            "Add a List (single-cell repeating Tablix) bound to a "
            "dataset. RDL has no distinct <List> element — Report "
            "Builder's List is a Tablix with one column, one detail "
            "row, and a Rectangle inside the cell. Items placed in "
            "the rectangle repeat once per dataset row. The inner "
            "rectangle is named '<name>_Rect' for subsequent lookup. "
            "Returns {name, kind: 'Tablix', dataset, rectangle}."
        ),
        input_schema={
            "type": "object",
            "properties": {
                "path": {"type": "string"},
                "name": {"type": "string"},
                "dataset_name": {"type": "string"},
                "top": {"type": "string"},
                "left": {"type": "string"},
                "width": {"type": "string"},
                "height": {"type": "string"},
            },
            "required": ["path", "name", "dataset_name", "top", "left", "width", "height"],
            "additionalProperties": False,
        },
        handler=_layout.add_list,
    )

    server.register_tool(
        name="add_line",
        description=(
            "Add a <Line> to <Body>/<ReportItems>. RDL Line semantics: "
            "top/left is the start point; width/height is the offset "
            "(vector) to the end point — horizontal line uses "
            "height='0in', vertical uses width='0in'. Optional color, "
            "line_thickness ('1pt' default), line_style "
            "(Solid/Dashed/Dotted/Double/etc.). Returns {name, kind: 'Line'}."
        ),
        input_schema={
            "type": "object",
            "properties": {
                "path": {"type": "string"},
                "name": {"type": "string"},
                "top": {"type": "string"},
                "left": {"type": "string"},
                "width": {"type": "string"},
                "height": {"type": "string"},
                "color": {"type": "string"},
                "line_thickness": {"type": "string"},
                "line_style": {
                    "type": "string",
                    "enum": list(_layout._VALID_LINE_STYLES),
                },
            },
            "required": ["path", "name", "top", "left", "width", "height"],
            "additionalProperties": False,
        },
        handler=_layout.add_line,
    )

    # ---- xpath escape hatch (Phase 12 commit 45) ------------------------

    server.register_tool(
        name="raw_xml_view",
        description=(
            "Read-only XPath query against the report. Returns matched "
            "elements as serialised XML strings. XPath context is "
            "<Report> (the root); 'r:' is bound to the RDL namespace, "
            "'rd:' to the rd namespace. Examples: "
            "\"r:DataSources/r:DataSource[@Name='X']\" / "
            "\".//r:Textbox[@Name='X']/r:Style\". Returns [] when "
            "nothing matches; raises on malformed xpath."
        ),
        input_schema={
            "type": "object",
            "properties": {
                "path": {"type": "string"},
                "xpath": {"type": "string"},
            },
            "required": ["path", "xpath"],
            "additionalProperties": False,
        },
        handler=_escape.raw_xml_view,
    )

    server.register_tool(
        name="raw_xml_replace",
        description=(
            "Replace the single element matched by xpath with new "
            "content. content is parsed with RDL as the default "
            "namespace and 'rd:' bound, so bare names like "
            "<Textbox><Value>x</Value></Textbox> work without explicit "
            "xmlns. Refuses on zero matches, multiple matches, or if "
            "the xpath targets the <Report> root. Saves atomically. "
            "Returns {xpath, kind, changed}."
        ),
        input_schema={
            "type": "object",
            "properties": {
                "path": {"type": "string"},
                "xpath": {"type": "string"},
                "content": {
                    "type": "string",
                    "description": (
                        "XML for the replacement element. Exactly one top-level element."
                    ),
                },
            },
            "required": ["path", "xpath", "content"],
            "additionalProperties": False,
        },
        handler=_escape.raw_xml_replace,
    )

    # ---- actions / tooltip / document-map (Phase 5) ---------------------

    _DRILLTHROUGH_PARAM_ITEM = {
        "type": "object",
        "properties": {
            "name": {"type": "string"},
            "value": {"type": "string"},
        },
        "required": ["name", "value"],
        "additionalProperties": False,
    }

    server.register_tool(
        name="set_textbox_action",
        description=(
            "Set <Textbox>/<Action> to a Hyperlink (URL), Drillthrough "
            "(another report + optional parameters), or BookmarkLink "
            "(jump within document). target_expression accepts literal "
            "text or =expression. drillthrough_parameters is a list of "
            "{name, value} dicts wired into <Drillthrough>/<Parameters>. "
            "Idempotent: same action_type + target + parameters → "
            "{changed: false}, no save."
        ),
        input_schema={
            "type": "object",
            "properties": {
                "path": {"type": "string"},
                "textbox_name": {"type": "string"},
                "action_type": {
                    "type": "string",
                    "enum": ["Hyperlink", "Drillthrough", "BookmarkLink"],
                },
                "target_expression": {"type": "string"},
                "drillthrough_parameters": {
                    "type": "array",
                    "items": _DRILLTHROUGH_PARAM_ITEM,
                },
            },
            "required": [
                "path",
                "textbox_name",
                "action_type",
                "target_expression",
            ],
            "additionalProperties": False,
        },
        handler=actions.set_textbox_action,
    )
    server.register_tool(
        name="set_image_action",
        description=(
            "Same shape as set_textbox_action but operates on a named "
            "<Image>. action_type ∈ Hyperlink / Drillthrough / "
            "BookmarkLink. Returns {image, kind, action_type, changed}."
        ),
        input_schema={
            "type": "object",
            "properties": {
                "path": {"type": "string"},
                "image_name": {"type": "string"},
                "action_type": {
                    "type": "string",
                    "enum": ["Hyperlink", "Drillthrough", "BookmarkLink"],
                },
                "target_expression": {"type": "string"},
                "drillthrough_parameters": {
                    "type": "array",
                    "items": _DRILLTHROUGH_PARAM_ITEM,
                },
            },
            "required": [
                "path",
                "image_name",
                "action_type",
                "target_expression",
            ],
            "additionalProperties": False,
        },
        handler=actions.set_image_action,
    )
    server.register_tool(
        name="set_textbox_tooltip",
        description=(
            "Set <Textbox>/<ToolTip>. Literal text or =expression. Pass "
            "'' to clear. Idempotent. Returns {textbox, kind, changed: "
            "bool}."
        ),
        input_schema={
            "type": "object",
            "properties": {
                "path": {"type": "string"},
                "textbox_name": {"type": "string"},
                "text_or_expression": {"type": "string"},
            },
            "required": ["path", "textbox_name", "text_or_expression"],
            "additionalProperties": False,
        },
        handler=actions.set_textbox_tooltip,
    )
    server.register_tool(
        name="set_document_map_label",
        description=(
            "Set <DocumentMapLabel> on any named ReportItem (Textbox / "
            "Image / Rectangle / Chart / Tablix / etc.). Surfaces in "
            "the rendered report's navigable document-map / "
            "table-of-contents pane. Pass '' to clear. Idempotent. "
            "Returns {element, kind, changed: bool}."
        ),
        input_schema={
            "type": "object",
            "properties": {
                "path": {"type": "string"},
                "element_name": {"type": "string"},
                "label_or_expression": {"type": "string"},
            },
            "required": ["path", "element_name", "label_or_expression"],
            "additionalProperties": False,
        },
        handler=actions.set_document_map_label,
    )
    server.register_tool(
        name="set_chart_series_action",
        description=(
            "Set <ChartSeries>/<Action> to a Hyperlink (URL), Drillthrough "
            "(another report + optional parameters), or BookmarkLink. "
            "Same kwarg surface as set_textbox_action / set_image_action; "
            "the chart series is addressed by (chart_name, series_name). "
            "Schema-aware insertion respects ChartSeries child order. "
            "Idempotent on structural equality of the inner block."
        ),
        input_schema={
            "type": "object",
            "properties": {
                "path": {"type": "string"},
                "chart_name": {"type": "string"},
                "series_name": {"type": "string"},
                "action_type": {
                    "type": "string",
                    "enum": ["Hyperlink", "Drillthrough", "BookmarkLink"],
                },
                "target_expression": {"type": "string"},
                "drillthrough_parameters": {
                    "type": "array",
                    "items": _DRILLTHROUGH_PARAM_ITEM,
                },
            },
            "required": [
                "path",
                "chart_name",
                "series_name",
                "action_type",
                "target_expression",
            ],
            "additionalProperties": False,
        },
        handler=actions.set_chart_series_action,
    )

    server.register_tool(
        name="remove_query_parameter",
        description=(
            "Remove a query parameter from a dataset. Cleans up the empty "
            "<QueryParameters/> block when removing the last one."
        ),
        input_schema={
            "type": "object",
            "properties": {
                "path": {"type": "string"},
                "dataset_name": {"type": "string"},
                "name": {"type": "string"},
            },
            "required": ["path", "dataset_name", "name"],
            "additionalProperties": False,
        },
        handler=dataset.remove_query_parameter,
    )

    server.register_tool(
        name="list_tablix_filters",
        description=(
            "List all filters on a named tablix in document order. Returns "
            "expression, operator, and values per filter; index in the list "
            "is the stable handle for remove_tablix_filter."
        ),
        input_schema={
            "type": "object",
            "properties": {
                "path": {"type": "string"},
                "tablix_name": {"type": "string"},
            },
            "required": ["path", "tablix_name"],
            "additionalProperties": False,
        },
        handler=tablix.list_tablix_filters,
    )
    server.register_tool(
        name="add_tablix_filter",
        description=(
            "Append a <Filter> to a tablix. Operator must be one of the RDL "
            "2016 enumeration (Equal, NotEqual, GreaterThan, In, Between, ...). "
            "Returns the new filter's index for follow-up calls. Optional "
            "field_format wraps the expression as Format(<body>, fmt) to "
            "coerce typed fields for string-parameter comparison. The "
            "response includes warnings for cross-checked field/parameter "
            "type mismatches."
        ),
        input_schema={
            "type": "object",
            "properties": {
                "path": {"type": "string"},
                "tablix_name": {"type": "string"},
                "expression": {"type": "string"},
                "operator": {"type": "string"},
                "values": {
                    "type": "array",
                    "items": {"type": "string"},
                    "minItems": 1,
                },
                "field_format": {
                    "type": "string",
                    "description": (
                        "Optional format string (e.g. 'MMM, yyyy') wrapping "
                        "the expression as Format(<body>, '<fmt>')."
                    ),
                },
            },
            "required": ["path", "tablix_name", "expression", "operator", "values"],
            "additionalProperties": False,
        },
        handler=tablix.add_tablix_filter,
    )
    server.register_tool(
        name="add_row_group",
        description=(
            "Add a row group that wraps the entire current top-level row "
            "hierarchy. Inserts a matching group-header row at body row 0 "
            "with the group expression in the first cell. parent_group "
            "(nesting under an existing group) is reserved for a future "
            "commit and currently raises NotImplementedError."
        ),
        input_schema={
            "type": "object",
            "properties": {
                "path": {"type": "string"},
                "tablix_name": {"type": "string"},
                "group_name": {"type": "string"},
                "group_expression": {
                    "type": "string",
                    "description": "RDL expression, e.g. =Fields!Region.Value",
                },
                "parent_group": {"type": ["string", "null"]},
            },
            "required": ["path", "tablix_name", "group_name", "group_expression"],
            "additionalProperties": False,
        },
        handler=tablix.add_row_group,
    )
    server.register_tool(
        name="remove_row_group",
        description=(
            "Inverse of add_row_group: unwraps a group's children back to "
            "its parent hierarchy and removes the matching header row at "
            "body row 0. Refuses to remove the conventional Details group."
        ),
        input_schema={
            "type": "object",
            "properties": {
                "path": {"type": "string"},
                "tablix_name": {"type": "string"},
                "group_name": {"type": "string"},
            },
            "required": ["path", "tablix_name", "group_name"],
            "additionalProperties": False,
        },
        handler=tablix.remove_row_group,
    )
    server.register_tool(
        name="set_group_sort",
        description=(
            "Replace a group's <SortExpressions> with a fresh list. Each "
            "entry is an RDL expression, e.g. =Fields!Region.Value."
        ),
        input_schema={
            "type": "object",
            "properties": {
                "path": {"type": "string"},
                "tablix_name": {"type": "string"},
                "group_name": {"type": "string"},
                "sort_expressions": {
                    "type": "array",
                    "items": {"type": "string"},
                },
            },
            "required": [
                "path",
                "tablix_name",
                "group_name",
                "sort_expressions",
            ],
            "additionalProperties": False,
        },
        handler=tablix.set_group_sort,
    )
    server.register_tool(
        name="set_group_visibility",
        description=(
            "Set <Visibility> on a group's TablixMember. Accepts a Hidden "
            "expression and an optional ToggleItem (a textbox name that "
            "toggles the group expand/collapse)."
        ),
        input_schema={
            "type": "object",
            "properties": {
                "path": {"type": "string"},
                "tablix_name": {"type": "string"},
                "group_name": {"type": "string"},
                "visibility_expression": {"type": "string"},
                "toggle_textbox": {"type": ["string", "null"]},
            },
            "required": [
                "path",
                "tablix_name",
                "group_name",
                "visibility_expression",
            ],
            "additionalProperties": False,
        },
        handler=tablix.set_group_visibility,
    )

    # ---- column-axis groups (v0.2) ----------------------------------------
    server.register_tool(
        name="add_column_group",
        description=(
            "Add a column group that wraps the current top-level column "
            "hierarchy. Inserts a matching column at body column 0 (default "
            "1in width) and a header cell at column 0 of every existing row "
            "with the group expression in the topmost cell. Mirrors "
            "add_row_group on the column axis. parent_group nesting is "
            "reserved for a future commit and currently raises "
            "NotImplementedError."
        ),
        input_schema={
            "type": "object",
            "properties": {
                "path": {"type": "string"},
                "tablix_name": {"type": "string"},
                "group_name": {"type": "string"},
                "group_expression": {
                    "type": "string",
                    "description": "RDL expression, e.g. =Fields!Region.Value",
                },
                "parent_group": {"type": ["string", "null"]},
            },
            "required": ["path", "tablix_name", "group_name", "group_expression"],
            "additionalProperties": False,
        },
        handler=tablix_columns.add_column_group,
    )
    server.register_tool(
        name="remove_column_group",
        description=(
            "Inverse of add_column_group: unwraps a column-axis group's "
            "children back to the top of the column hierarchy and removes "
            "the matching body column at position 0 (along with each row's "
            "first cell). Errors if group_name only exists on the row axis."
        ),
        input_schema={
            "type": "object",
            "properties": {
                "path": {"type": "string"},
                "tablix_name": {"type": "string"},
                "group_name": {"type": "string"},
            },
            "required": ["path", "tablix_name", "group_name"],
            "additionalProperties": False,
        },
        handler=tablix_columns.remove_column_group,
    )
    server.register_tool(
        name="set_column_group_sort",
        description=(
            "Replace a column-axis group's <SortExpressions> with a fresh "
            "list. Mirrors set_group_sort but refuses up front if "
            "group_name is on the row axis (use set_group_sort instead)."
        ),
        input_schema={
            "type": "object",
            "properties": {
                "path": {"type": "string"},
                "tablix_name": {"type": "string"},
                "group_name": {"type": "string"},
                "sort_expressions": {
                    "type": "array",
                    "items": {"type": "string"},
                },
            },
            "required": ["path", "tablix_name", "group_name", "sort_expressions"],
            "additionalProperties": False,
        },
        handler=tablix_columns.set_column_group_sort,
    )
    server.register_tool(
        name="set_column_group_visibility",
        description=(
            "Set <Visibility> on a column-axis group's TablixMember. Accepts "
            "a Hidden expression and an optional ToggleItem (textbox name "
            "that toggles expand/collapse). Mirrors set_group_visibility "
            "but refuses up front if group_name is on the row axis."
        ),
        input_schema={
            "type": "object",
            "properties": {
                "path": {"type": "string"},
                "tablix_name": {"type": "string"},
                "group_name": {"type": "string"},
                "visibility_expression": {"type": "string"},
                "toggle_textbox": {"type": ["string", "null"]},
            },
            "required": [
                "path",
                "tablix_name",
                "group_name",
                "visibility_expression",
            ],
            "additionalProperties": False,
        },
        handler=tablix_columns.set_column_group_visibility,
    )
    server.register_tool(
        name="add_tablix_column",
        description=(
            "Append (or insert) a column into a tablix. column_name is the "
            "textbox name placed in the data row's new cell — must be unique "
            "report-wide. expression goes inside that textbox's TextRun "
            "(typically =Fields!X.Value). For a tablix with >= 2 rows the "
            "first row gets header_text (default = column_name) as a literal, "
            "middle rows get blank cells, and the last row gets expression. "
            "position is 0-indexed; default appends at end. width defaults to "
            "1in. Inserts a matching top-level TablixMember in the column "
            "hierarchy at the same index."
        ),
        input_schema={
            "type": "object",
            "properties": {
                "path": {"type": "string"},
                "tablix_name": {"type": "string"},
                "column_name": {"type": "string"},
                "expression": {"type": "string"},
                "position": {"type": ["integer", "null"], "minimum": 0},
                "width": {"type": ["string", "null"]},
                "header_text": {"type": ["string", "null"]},
            },
            "required": ["path", "tablix_name", "column_name", "expression"],
            "additionalProperties": False,
        },
        handler=tablix_columns.add_tablix_column,
    )
    server.register_tool(
        name="remove_tablix_column",
        description=(
            "Remove the tablix column whose data-row cell holds a textbox "
            "named column_name. Drops the matching TablixColumn, removes the "
            "top-level TablixMember at that column index (only if it's a "
            "leaf, never a column group wrapper), and removes the cell at "
            "that index from every TablixRow. Errors if no row contains a "
            "textbox with the given name."
        ),
        input_schema={
            "type": "object",
            "properties": {
                "path": {"type": "string"},
                "tablix_name": {"type": "string"},
                "column_name": {"type": "string"},
            },
            "required": ["path", "tablix_name", "column_name"],
            "additionalProperties": False,
        },
        handler=tablix_columns.remove_tablix_column,
    )
    server.register_tool(
        name="add_subtotal_row",
        description=(
            "Append a subtotal row to a row-axis group. aggregates is a list "
            "of {column, expression} entries; column matches against the "
            "Details row's textbox names (the same names add_tablix_column "
            "uses as column_name — NOT field names). expression is the "
            "aggregate (e.g. =Sum(Fields!X.Value)). Columns not listed get "
            "blank cells. position='footer' (default) appends; 'header' "
            "inserts at body row 1 (right after the group-header row). "
            "Group must have been added via add_row_group."
        ),
        input_schema={
            "type": "object",
            "properties": {
                "path": {"type": "string"},
                "tablix_name": {"type": "string"},
                "group_name": {"type": "string"},
                "aggregates": {
                    "type": "array",
                    "items": {
                        "type": "object",
                        "properties": {
                            "column": {"type": "string"},
                            "expression": {"type": "string"},
                        },
                        "required": ["column", "expression"],
                        "additionalProperties": False,
                    },
                },
                "position": {
                    "type": "string",
                    "enum": ["header", "footer"],
                    "default": "footer",
                },
            },
            "required": ["path", "tablix_name", "group_name", "aggregates"],
            "additionalProperties": False,
        },
        handler=tablix_subtotals.add_subtotal_row,
    )
    server.register_tool(
        name="set_cell_span",
        description=(
            "Set <RowSpan> and/or <ColSpan> on a tablix cell. The cell is "
            "addressed by (row_index, column_name) where column_name is the "
            "textbox name inside the cell. At least one of row_span / "
            "col_span must be supplied; both must be >= 1. Pass 1 to "
            "explicitly reset a span. Replaces existing values if present."
        ),
        input_schema={
            "type": "object",
            "properties": {
                "path": {"type": "string"},
                "tablix_name": {"type": "string"},
                "row_index": {"type": "integer", "minimum": 0},
                "column_name": {"type": "string"},
                "row_span": {"type": ["integer", "null"], "minimum": 1},
                "col_span": {"type": ["integer", "null"], "minimum": 1},
            },
            "required": ["path", "tablix_name", "row_index", "column_name"],
            "additionalProperties": False,
        },
        handler=tablix_cells.set_cell_span,
    )
    server.register_tool(
        name="add_static_row",
        description=(
            "Add a static (no-group) row to a tablix. Each cell holds "
            "literal text. cells is a list of strings, one per body column "
            "(left to right); shorter list = blank trailing cells, longer "
            "list errors. Cell textboxes are named row_name (col 0) and "
            "row_name_<col_index> (others) — unique report-wide so row_name "
            "must not clash with any existing textbox. position is "
            "0-indexed; default appends. height defaults to 0.25in."
        ),
        input_schema={
            "type": "object",
            "properties": {
                "path": {"type": "string"},
                "tablix_name": {"type": "string"},
                "row_name": {"type": "string"},
                "cells": {
                    "type": ["array", "null"],
                    "items": {"type": "string"},
                },
                "position": {"type": ["integer", "null"], "minimum": 0},
                "height": {"type": ["string", "null"]},
            },
            "required": ["path", "tablix_name", "row_name"],
            "additionalProperties": False,
        },
        handler=tablix_static.add_static_row,
    )
    server.register_tool(
        name="add_static_column",
        description=(
            "Add a static (no-group) column to a tablix. Each cell holds "
            "literal text. cells is a list of strings, one per body row "
            "(top to bottom); shorter list = blank trailing cells, longer "
            "list errors. Cell textboxes are named column_name (row 0) and "
            "column_name_<row_index> (others). position is 0-indexed; "
            "default appends. width defaults to 1in."
        ),
        input_schema={
            "type": "object",
            "properties": {
                "path": {"type": "string"},
                "tablix_name": {"type": "string"},
                "column_name": {"type": "string"},
                "cells": {
                    "type": ["array", "null"],
                    "items": {"type": "string"},
                },
                "position": {"type": ["integer", "null"], "minimum": 0},
                "width": {"type": ["string", "null"]},
            },
            "required": ["path", "tablix_name", "column_name"],
            "additionalProperties": False,
        },
        handler=tablix_static.add_static_column,
    )

    # ---- positioning (v0.2 commits 6-8) -----------------------------------
    server.register_tool(
        name="set_body_item_position",
        description=(
            "Move an existing named ReportItem inside <Body> to (top, left). "
            "Preserves all other properties (size, style, group structure). "
            "top and left are passed through verbatim — RDL accepts any size "
            "unit (2cm, 0.75in, 108pt). Errors if no body item by that name."
        ),
        input_schema={
            "type": "object",
            "properties": {
                "path": {"type": "string"},
                "name": {"type": "string"},
                "top": {"type": "string"},
                "left": {"type": "string"},
            },
            "required": ["path", "name", "top", "left"],
            "additionalProperties": False,
        },
        handler=positioning.set_body_item_position,
    )
    server.register_tool(
        name="set_header_item_position",
        description=(
            "Move an existing named ReportItem inside <PageHeader> to "
            "(top, left). Errors if there is no <PageHeader> (call "
            "set_page_header first) or no item by that name."
        ),
        input_schema={
            "type": "object",
            "properties": {
                "path": {"type": "string"},
                "name": {"type": "string"},
                "top": {"type": "string"},
                "left": {"type": "string"},
            },
            "required": ["path", "name", "top", "left"],
            "additionalProperties": False,
        },
        handler=positioning.set_header_item_position,
    )
    server.register_tool(
        name="set_footer_item_position",
        description=(
            "Move an existing named ReportItem inside <PageFooter> to "
            "(top, left). Errors if there is no <PageFooter> (call "
            "set_page_footer first) or no item by that name."
        ),
        input_schema={
            "type": "object",
            "properties": {
                "path": {"type": "string"},
                "name": {"type": "string"},
                "top": {"type": "string"},
                "left": {"type": "string"},
            },
            "required": ["path", "name", "top", "left"],
            "additionalProperties": False,
        },
        handler=positioning.set_footer_item_position,
    )
    server.register_tool(
        name="set_body_item_size",
        description=(
            "Resize an existing named ReportItem inside <Body>. At least "
            "one of width / height must be supplied; missing fields are "
            "left untouched. Same RDL size-string convention as the "
            "position tools."
        ),
        input_schema={
            "type": "object",
            "properties": {
                "path": {"type": "string"},
                "name": {"type": "string"},
                "width": {"type": ["string", "null"]},
                "height": {"type": ["string", "null"]},
            },
            "required": ["path", "name"],
            "additionalProperties": False,
        },
        handler=positioning.set_body_item_size,
    )
    server.register_tool(
        name="set_header_item_size",
        description=(
            "Resize a named item inside <PageHeader>. Mirrors "
            "set_body_item_size — at least one of width / height; "
            "missing fields untouched; idempotent ({changed: false} "
            "when nothing differs). Closes the v0.2 parity gap where "
            "only the body variant existed."
        ),
        input_schema={
            "type": "object",
            "properties": {
                "path": {"type": "string"},
                "name": {"type": "string"},
                "width": {"type": ["string", "null"]},
                "height": {"type": ["string", "null"]},
            },
            "required": ["path", "name"],
            "additionalProperties": False,
        },
        handler=positioning.set_header_item_size,
    )
    server.register_tool(
        name="set_footer_item_size",
        description=(
            "Resize a named item inside <PageFooter>. Same shape as set_header_item_size."
        ),
        input_schema={
            "type": "object",
            "properties": {
                "path": {"type": "string"},
                "name": {"type": "string"},
                "width": {"type": ["string", "null"]},
                "height": {"type": ["string", "null"]},
            },
            "required": ["path", "name"],
            "additionalProperties": False,
        },
        handler=positioning.set_footer_item_size,
    )

    # ---- reader extensions (v0.2) -----------------------------------------
    server.register_tool(
        name="list_body_items",
        description=(
            "List every named ReportItem at the top level of <Body>. "
            "Returns name, type (Tablix / Textbox / Image / Rectangle / "
            "Subreport / Chart / etc.), top, left, width, height. Use "
            "before set_body_item_position / set_body_item_size when you "
            "don't already know what's in the body."
        ),
        input_schema=_PATH_ONLY_SCHEMA,
        handler=reader.list_body_items,
    )
    server.register_tool(
        name="list_header_items",
        description="Same shape as list_body_items but for <PageHeader>.",
        input_schema=_PATH_ONLY_SCHEMA,
        handler=reader.list_header_items,
    )
    server.register_tool(
        name="list_footer_items",
        description="Same shape as list_body_items but for <PageFooter>.",
        input_schema=_PATH_ONLY_SCHEMA,
        handler=reader.list_footer_items,
    )
    server.register_tool(
        name="get_textbox",
        description=(
            "Return effective state of a named Textbox: position, size, "
            "Visibility, CanGrow, CanShrink, plus a nested style dict that "
            "mirrors set_textbox_style's routing — "
            "{box: {BackgroundColor, VerticalAlign, padding, ...}, "
            "border: {Style, Color, Width}, paragraph: {TextAlign}, "
            "run: {FontFamily, FontSize, FontWeight, Color, Format, ...}}. "
            "Empty branches are dropped. runs[] entries each carry their own "
            "per-run style. Searches the entire report; tablix-cell textboxes "
            "have None for top/left/width/height. Top-level positioned items "
            "with a missing <Top> or <Left> coerce to '0in' (RDL default)."
        ),
        input_schema={
            "type": "object",
            "properties": {
                "path": {"type": "string"},
                "name": {"type": "string"},
            },
            "required": ["path", "name"],
            "additionalProperties": False,
        },
        handler=reader.get_textbox,
    )
    server.register_tool(
        name="get_image",
        description=(
            "Return effective state of a named Image: position, size, "
            "Source (External / Embedded / Database), Value, Sizing "
            "(AutoSize / Fit / FitProportional / Clip), MIMEType, Style, "
            "Visibility."
        ),
        input_schema={
            "type": "object",
            "properties": {
                "path": {"type": "string"},
                "name": {"type": "string"},
            },
            "required": ["path", "name"],
            "additionalProperties": False,
        },
        handler=reader.get_image,
    )
    server.register_tool(
        name="get_rectangle",
        description=(
            "Return effective state of a named Rectangle: position, size, "
            "names of contained ReportItems, Style, Visibility."
        ),
        input_schema={
            "type": "object",
            "properties": {
                "path": {"type": "string"},
                "name": {"type": "string"},
            },
            "required": ["path", "name"],
            "additionalProperties": False,
        },
        handler=reader.get_rectangle,
    )
    server.register_tool(
        name="get_chart",
        description=(
            "Return effective state of a named Chart: position, size, "
            "dataset, palette, series list (name/type/subtype/value "
            "expression/color), category groups (name/expression/label), "
            "axes (category and value), legend, title, Style, Visibility. "
            "Symmetric with get_textbox / get_image / get_rectangle."
        ),
        input_schema={
            "type": "object",
            "properties": {
                "path": {"type": "string"},
                "name": {"type": "string"},
            },
            "required": ["path", "name"],
            "additionalProperties": False,
        },
        handler=reader.get_chart,
    )

    # ---- snapshot (v0.2 commit 14) ----------------------------------------
    server.register_tool(
        name="backup_report",
        description=(
            "Copy the report to <path>.bak.<UTC-timestamp>. Original is "
            "untouched. Cheap explicit checkpoint to call before a "
            "destructive batch (remove_*, rename_parameter, etc.). Returns "
            "the backup path. Set PBIRB_MCP_AUTO_BACKUP=1 to opt into "
            "automatic backups before destructive ops (off by default)."
        ),
        input_schema=_PATH_ONLY_SCHEMA,
        handler=snapshot.backup_report,
    )

    # ---- parameter CRUD (v0.2 commits 15-19) ------------------------------
    server.register_tool(
        name="set_parameter_prompt",
        description=(
            "Write the <Prompt> text on a ReportParameter. Empty string "
            "clears the <Prompt> element entirely; pass a single space ' ' "
            "for blank-but-present."
        ),
        input_schema={
            "type": "object",
            "properties": {
                "path": {"type": "string"},
                "name": {"type": "string"},
                "prompt": {"type": "string"},
            },
            "required": ["path", "name", "prompt"],
            "additionalProperties": False,
        },
        handler=parameters.set_parameter_prompt,
    )
    server.register_tool(
        name="set_parameter_type",
        description=(
            "Set <DataType> on a ReportParameter. type ∈ {Boolean, "
            "DateTime, Integer, Float, String}. Rejects with ValueError "
            "if any existing literal default value would be incompatible "
            "with the new type — fix defaults first via "
            "set_parameter_default_values, then retry."
        ),
        input_schema={
            "type": "object",
            "properties": {
                "path": {"type": "string"},
                "name": {"type": "string"},
                "type": {
                    "type": "string",
                    "enum": ["Boolean", "DateTime", "Integer", "Float", "String"],
                },
            },
            "required": ["path", "name", "type"],
            "additionalProperties": False,
        },
        handler=parameters.set_parameter_type,
    )
    server.register_tool(
        name="add_parameter",
        description=(
            "Create a new ReportParameter with a minimal valid declaration. "
            "Appends to <ReportParameters> (creating it if absent). Pair "
            "with set_parameter_available_values / "
            "set_parameter_default_values afterwards for value lists. "
            "Booleans are only emitted when an explicit value is supplied."
        ),
        input_schema={
            "type": "object",
            "properties": {
                "path": {"type": "string"},
                "name": {"type": "string"},
                "type": {
                    "type": "string",
                    "enum": ["Boolean", "DateTime", "Integer", "Float", "String"],
                },
                "prompt": {"type": ["string", "null"]},
                "allow_null": {"type": ["boolean", "null"]},
                "allow_blank": {"type": ["boolean", "null"]},
                "multi_value": {"type": ["boolean", "null"]},
                "hidden": {"type": ["boolean", "null"]},
            },
            "required": ["path", "name", "type"],
            "additionalProperties": False,
        },
        handler=parameters.add_parameter,
    )
    server.register_tool(
        name="remove_parameter",
        description=(
            "Remove a ReportParameter by name. Refuses (lists offending "
            "locators) if the parameter is still referenced anywhere in "
            "the report by Parameters!<name>.Value or .Label. Pass "
            "force=True to remove anyway."
        ),
        input_schema={
            "type": "object",
            "properties": {
                "path": {"type": "string"},
                "name": {"type": "string"},
                "force": {"type": "boolean", "default": False},
            },
            "required": ["path", "name"],
            "additionalProperties": False,
        },
        handler=parameters.remove_parameter,
    )
    server.register_tool(
        name="rename_parameter",
        description=(
            "Rename a ReportParameter and rewrite every textual occurrence "
            "of Parameters!<old_name>.Value / .Label across the entire "
            "report. Case-sensitive. Atomic: collects all matches first, "
            "then commits. Errors if new_name already exists or equals "
            "old_name."
        ),
        input_schema={
            "type": "object",
            "properties": {
                "path": {"type": "string"},
                "old_name": {"type": "string"},
                "new_name": {"type": "string"},
            },
            "required": ["path", "old_name", "new_name"],
            "additionalProperties": False,
        },
        handler=parameters.rename_parameter,
    )
    server.register_tool(
        name="sync_parameter_layout",
        description=(
            "Bring <ReportParametersLayout>/<GridLayoutDefinition>/"
            "<CellDefinitions> into sync with <ReportParameters>. Drops "
            "cells whose ParameterName no longer exists; appends cells "
            "for parameters that have no entry, placed at the next free "
            "(row, col) slot. add_parameter / remove_parameter / "
            "rename_parameter call this internally; the standalone tool "
            "is for repairing legacy reports authored before v0.3.0 "
            "where the layout drifted. No-op when the report has no "
            "<ReportParametersLayout>. Returns {added, removed}."
        ),
        input_schema=_PATH_ONLY_SCHEMA,
        handler=parameters.sync_parameter_layout,
    )

    server.register_tool(
        name="set_detail_row_visibility",
        description=(
            "Set <Visibility> on the tablix's Details group, optionally with "
            "a ToggleItem textbox name. Use to hide detail rows by expression "
            "without restructuring the row hierarchy."
        ),
        input_schema={
            "type": "object",
            "properties": {
                "path": {"type": "string"},
                "tablix_name": {"type": "string"},
                "expression": {"type": "string"},
                "toggle_textbox": {"type": ["string", "null"]},
            },
            "required": ["path", "tablix_name", "expression"],
            "additionalProperties": False,
        },
        handler=tablix.set_detail_row_visibility,
    )
    server.register_tool(
        name="set_row_height",
        description=(
            "Set the Height of the Nth body row (0-indexed) in a tablix. "
            "Accepts any RDL size string ('0.25in', '1cm', '12pt')."
        ),
        input_schema={
            "type": "object",
            "properties": {
                "path": {"type": "string"},
                "tablix_name": {"type": "string"},
                "row_index": {"type": "integer", "minimum": 0},
                "height": {"type": "string"},
            },
            "required": ["path", "tablix_name", "row_index", "height"],
            "additionalProperties": False,
        },
        handler=tablix.set_row_height,
    )

    server.register_tool(
        name="remove_tablix_filter",
        description=(
            "Remove a filter by index. Filters are anonymous in RDL, so use "
            "list_tablix_filters first to find the right index. Removing the "
            "last filter also drops the empty <Filters/> block."
        ),
        input_schema={
            "type": "object",
            "properties": {
                "path": {"type": "string"},
                "tablix_name": {"type": "string"},
                "filter_index": {"type": "integer", "minimum": 0},
            },
            "required": ["path", "tablix_name", "filter_index"],
            "additionalProperties": False,
        },
        handler=tablix.remove_tablix_filter,
    )

    server.register_tool(
        name="set_page_setup",
        description=(
            "Update <Page> dimensions, margins, and column count on the "
            "first ReportSection. All fields are optional — only what's "
            "passed gets written. columns=1 strips the <Columns/> element."
        ),
        input_schema={
            "type": "object",
            "properties": {
                "path": {"type": "string"},
                "page_height": {"type": ["string", "null"]},
                "page_width": {"type": ["string", "null"]},
                "margin_top": {"type": ["string", "null"]},
                "margin_bottom": {"type": ["string", "null"]},
                "margin_left": {"type": ["string", "null"]},
                "margin_right": {"type": ["string", "null"]},
                "columns": {"type": ["integer", "null"], "minimum": 1},
            },
            "required": ["path"],
            "additionalProperties": False,
        },
        handler=page.set_page_setup,
    )
    server.register_tool(
        name="set_page_orientation",
        description=(
            "Set page orientation by swapping PageHeight and PageWidth when "
            "the current orientation doesn't match the requested one. "
            "Idempotent. Accepts 'Portrait' or 'Landscape'."
        ),
        input_schema={
            "type": "object",
            "properties": {
                "path": {"type": "string"},
                "orientation": {
                    "type": "string",
                    "enum": ["Portrait", "Landscape"],
                },
            },
            "required": ["path", "orientation"],
            "additionalProperties": False,
        },
        handler=page.set_page_orientation,
    )

    _SECTION_FLAGS_SCHEMA = {
        "type": "object",
        "properties": {
            "path": {"type": "string"},
            "height": {"type": ["string", "null"]},
            "print_on_first_page": {"type": ["boolean", "null"]},
            "print_on_last_page": {"type": ["boolean", "null"]},
        },
        "required": ["path"],
        "additionalProperties": False,
    }
    _TEXTBOX_SCHEMA = {
        "type": "object",
        "properties": {
            "path": {"type": "string"},
            "name": {"type": "string"},
            "text": {
                "type": "string",
                "description": "Static text or RDL expression (=...).",
            },
            "top": {"type": "string"},
            "left": {"type": "string"},
            "width": {"type": "string"},
            "height": {"type": "string"},
        },
        "required": ["path", "name", "text", "top", "left", "width", "height"],
        "additionalProperties": False,
    }
    _IMAGE_SCHEMA = {
        "type": "object",
        "properties": {
            "path": {"type": "string"},
            "name": {"type": "string"},
            "image_source": {
                "type": "string",
                "enum": ["External", "Embedded", "Database"],
            },
            "value": {
                "type": "string",
                "description": (
                    "URL for External, embedded-image name for Embedded, "
                    "or =Fields!X.Value for Database."
                ),
            },
            "top": {"type": "string"},
            "left": {"type": "string"},
            "width": {"type": "string"},
            "height": {"type": "string"},
        },
        "required": [
            "path",
            "name",
            "image_source",
            "value",
            "top",
            "left",
            "width",
            "height",
        ],
        "additionalProperties": False,
    }
    _NAMED_REMOVE_SCHEMA = {
        "type": "object",
        "properties": {
            "path": {"type": "string"},
            "name": {"type": "string"},
        },
        "required": ["path", "name"],
        "additionalProperties": False,
    }

    server.register_tool(
        name="set_page_header",
        description=(
            "Create or update <PageHeader>: height plus PrintOnFirstPage / "
            "PrintOnLastPage flags. All fields optional — only what's "
            "passed gets written."
        ),
        input_schema=_SECTION_FLAGS_SCHEMA,
        handler=header_footer.set_page_header,
    )
    server.register_tool(
        name="set_page_footer",
        description="Same as set_page_header, for <PageFooter>.",
        input_schema=_SECTION_FLAGS_SCHEMA,
        handler=header_footer.set_page_footer,
    )
    server.register_tool(
        name="add_header_textbox",
        description=(
            "Add a Textbox to <PageHeader>/<ReportItems>. text accepts "
            "static strings or RDL expressions (=Parameters!DateFrom.Value). "
            "Pass raw text — encoding is handled; don't pre-encode XML "
            "entities (use `&` not `&amp;`, including for the VB.NET "
            "string-concat operator in expressions)."
        ),
        input_schema=_TEXTBOX_SCHEMA,
        handler=header_footer.add_header_textbox,
    )
    server.register_tool(
        name="add_footer_textbox",
        description="Same as add_header_textbox, for <PageFooter>.",
        input_schema=_TEXTBOX_SCHEMA,
        handler=header_footer.add_footer_textbox,
    )
    server.register_tool(
        name="add_header_image",
        description=(
            "Add an Image to <PageHeader>/<ReportItems>. image_source is "
            "External (URL in value), Embedded (EmbeddedImage Name in value), "
            "or Database (=Fields!Photo.Value-style expression)."
        ),
        input_schema=_IMAGE_SCHEMA,
        handler=header_footer.add_header_image,
    )
    server.register_tool(
        name="add_footer_image",
        description="Same as add_header_image, for <PageFooter>.",
        input_schema=_IMAGE_SCHEMA,
        handler=header_footer.add_footer_image,
    )
    server.register_tool(
        name="remove_header_item",
        description=(
            "Remove a named Textbox or Image from <PageHeader>/<ReportItems>. "
            "Empties the ReportItems block when the last item leaves."
        ),
        input_schema=_NAMED_REMOVE_SCHEMA,
        handler=header_footer.remove_header_item,
    )
    server.register_tool(
        name="remove_footer_item",
        description="Same as remove_header_item, for <PageFooter>.",
        input_schema=_NAMED_REMOVE_SCHEMA,
        handler=header_footer.remove_footer_item,
    )

    server.register_tool(
        name="set_textbox_style",
        description=(
            "Set styling on a named Textbox. Properties route to the right "
            "nested Style node automatically: background_color, "
            "border_*, vertical_align, padding_*, writing_mode go on "
            "Textbox/Style; text_align on Paragraph/Style; font_*, color, "
            "format on TextRun/Style; can_grow / can_shrink go DIRECTLY "
            "on Textbox (not inside Style). All fields optional — only "
            "what's passed gets written. Cell-level styling: every tablix "
            "cell is a Textbox with a unique name, so use this tool with "
            "the cell's textbox name (e.g. 'HeaderAmount')."
        ),
        input_schema={
            "type": "object",
            "properties": {
                "path": {"type": "string"},
                "textbox_name": {"type": "string"},
                "font_family": {"type": ["string", "null"]},
                "font_size": {
                    "type": ["string", "null"],
                    "description": "RDL size, e.g. '11pt'.",
                },
                "font_weight": {
                    "type": ["string", "null"],
                    "description": "Normal | Bold | Lighter | ... or numeric.",
                },
                "color": {
                    "type": ["string", "null"],
                    "description": "Text color — '#RRGGBB' or named.",
                },
                "background_color": {"type": ["string", "null"]},
                "border_style": {
                    "type": ["string", "null"],
                    "description": "None | Solid | Dotted | Dashed | Double.",
                },
                "border_color": {"type": ["string", "null"]},
                "border_width": {"type": ["string", "null"]},
                "text_align": {
                    "type": ["string", "null"],
                    "description": "Left | Center | Right | Justify | General.",
                },
                "vertical_align": {
                    "type": ["string", "null"],
                    "description": "Top | Middle | Bottom.",
                },
                "format": {
                    "type": ["string", "null"],
                    "description": "Number/date format (e.g. '#,0.00', 'C2', 'd').",
                },
                "padding_top": {
                    "type": ["string", "null"],
                    "description": "RDL size (e.g. '2pt', '0.05in').",
                },
                "padding_bottom": {"type": ["string", "null"]},
                "padding_left": {"type": ["string", "null"]},
                "padding_right": {"type": ["string", "null"]},
                "writing_mode": {
                    "type": ["string", "null"],
                    "description": (
                        "Horizontal | Vertical | Rotate270 — text "
                        "orientation. Useful for narrow column headers."
                    ),
                },
                "can_grow": {
                    "type": ["boolean", "null"],
                    "description": (
                        "Allow textbox to grow vertically when content "
                        "exceeds the height. Direct Textbox child, not Style."
                    ),
                },
                "can_shrink": {
                    "type": ["boolean", "null"],
                    "description": (
                        "Allow textbox to shrink when content is shorter "
                        "than the height. Direct Textbox child, not Style."
                    ),
                },
            },
            "required": ["path", "textbox_name"],
            "additionalProperties": False,
        },
        handler=styling.set_textbox_style,
    )
    server.register_tool(
        name="set_textbox_runs",
        description=(
            "Replace a textbox's content with multiple <TextRun> children "
            "for mixed styling within one display — e.g. '**Asset(s):** "
            "value' with a bold prefix + regular value in a single "
            "textbox. Each run is a dict with required 'text' and optional "
            "font_family / font_size / font_weight / font_style / color / "
            "format / text_decoration. Replaces the entire <Paragraphs> "
            "subtree (single-paragraph in v0.3; multi-paragraph deferred). "
            "Round-trip contract: get_textbox.runs[] returns the same "
            "shape this tool writes. Idempotent — identical input is a "
            "no-op short-circuit. Returns {textbox, kind, runs, changed}. "
            "Pass raw text in each run's `text` — encoding is handled; "
            "don't pre-encode XML entities (use `&` not `&amp;`, "
            "including for the VB.NET string-concat operator)."
        ),
        input_schema={
            "type": "object",
            "properties": {
                "path": {"type": "string"},
                "textbox_name": {"type": "string"},
                "runs": {
                    "type": "array",
                    "minItems": 1,
                    "items": {
                        "type": "object",
                        "properties": {
                            "text": {"type": "string"},
                            "font_family": {"type": "string"},
                            "font_size": {"type": "string"},
                            "font_weight": {"type": "string"},
                            "font_style": {"type": "string"},
                            "color": {"type": "string"},
                            "format": {"type": "string"},
                            "text_decoration": {"type": "string"},
                        },
                        "required": ["text"],
                        "additionalProperties": False,
                    },
                },
            },
            "required": ["path", "textbox_name", "runs"],
            "additionalProperties": False,
        },
        handler=styling.set_textbox_runs,
    )
    server.register_tool(
        name="set_textbox_value",
        description=(
            "Replace the text content of a single-run textbox. value can "
            "be raw text or an =expression. Use this for the everyday "
            "'change the textbox content' case (swap a literal label, "
            "update a stale parameter reference, replace a broken "
            "aggregate). Refuses with a redirect to set_textbox_runs when "
            "the textbox has multiple text runs (multi-run content needs "
            "the rich-text editor). Idempotent: identical value → "
            "{changed: false} no-op. Returns {textbox, kind, changed}. "
            "Pass raw text — encoding is handled; don't pre-encode XML "
            "entities (use `&` not `&amp;`, including for the VB.NET "
            "string-concat operator in expressions)."
        ),
        input_schema={
            "type": "object",
            "properties": {
                "path": {"type": "string"},
                "textbox_name": {"type": "string"},
                "value": {"type": "string"},
            },
            "required": ["path", "textbox_name", "value"],
            "additionalProperties": False,
        },
        handler=styling.set_textbox_value,
    )
    server.register_tool(
        name="set_textbox_style_bulk",
        description=(
            "Apply the same style kwargs to every named textbox in one "
            "call. Same kwarg surface as set_textbox_style. Missing names "
            "land in skipped rather than raising. Returns {textboxes, "
            "skipped, changed} where changed is the union of sub-paths "
            "affected across all textboxes. Pair with find_textboxes_by_"
            "style to discover names by current style."
        ),
        input_schema={
            "type": "object",
            "properties": {
                "path": {"type": "string"},
                "textbox_names": {
                    "type": "array",
                    "items": {"type": "string"},
                },
                "font_family": {"type": ["string", "null"]},
                "font_size": {"type": ["string", "null"]},
                "font_weight": {"type": ["string", "null"]},
                "color": {"type": ["string", "null"]},
                "background_color": {"type": ["string", "null"]},
                "border_style": {"type": ["string", "null"]},
                "border_color": {"type": ["string", "null"]},
                "border_width": {"type": ["string", "null"]},
                "text_align": {"type": ["string", "null"]},
                "vertical_align": {"type": ["string", "null"]},
                "format": {"type": ["string", "null"]},
                "padding_top": {"type": ["string", "null"]},
                "padding_bottom": {"type": ["string", "null"]},
                "padding_left": {"type": ["string", "null"]},
                "padding_right": {"type": ["string", "null"]},
                "writing_mode": {"type": ["string", "null"]},
                "can_grow": {"type": ["boolean", "null"]},
                "can_shrink": {"type": ["boolean", "null"]},
            },
            "required": ["path", "textbox_names"],
            "additionalProperties": False,
        },
        handler=styling.set_textbox_style_bulk,
    )
    server.register_tool(
        name="find_textboxes_by_style",
        description=(
            "Search for textboxes matching one or more style filters. "
            "Filters AND together (every supplied filter must match). "
            "Returns [{name, location, matched_fields}] where location "
            "is best-effort 'body' / 'header' / 'footer' / "
            "'tablix:<name>' / 'rectangle:<name>'. Returns [] when no "
            "filters supplied. Pair with set_textbox_style_bulk for "
            "discovery+apply patterns (e.g. 'recolor every red textbox')."
        ),
        input_schema={
            "type": "object",
            "properties": {
                "path": {"type": "string"},
                "background_color": {"type": "string"},
                "vertical_align": {"type": "string"},
                "writing_mode": {"type": "string"},
                "padding_top": {"type": "string"},
                "padding_bottom": {"type": "string"},
                "padding_left": {"type": "string"},
                "padding_right": {"type": "string"},
                "border_style": {"type": "string"},
                "border_color": {"type": "string"},
                "border_width": {"type": "string"},
                "text_align": {"type": "string"},
                "font_family": {"type": "string"},
                "font_size": {"type": "string"},
                "font_weight": {"type": "string"},
                "font_style": {"type": "string"},
                "color": {"type": "string"},
                "format": {"type": "string"},
                "text_decoration": {"type": "string"},
            },
            "required": ["path"],
            "additionalProperties": False,
        },
        handler=reader.find_textboxes_by_style,
    )
    server.register_tool(
        name="find_textbox_by_value",
        description=(
            "Find every Textbox whose <Value> text matches a Python "
            "regex pattern. Searches Body / PageHeader / PageFooter. "
            "A textbox with multiple matching runs surfaces once per "
            "match. Returns [{textbox, value, region}]. Useful for "
            "finding stale =Parameters!Old.Value references after "
            "rename_parameter, or any cross-cutting expression edit."
        ),
        input_schema={
            "type": "object",
            "properties": {
                "path": {"type": "string"},
                "pattern": {
                    "type": "string",
                    "description": "Python regex (re.search); not RDL/SQL glob.",
                },
            },
            "required": ["path", "pattern"],
            "additionalProperties": False,
        },
        handler=reader.find_textbox_by_value,
    )
    server.register_tool(
        name="style_tablix_row",
        description=(
            "Apply the same style kwargs to every cell in a tablix row "
            "in ONE call. Replaces the 12-individual-set_textbox_style-"
            "calls-per-row pattern. row accepts: integer (0-based body "
            "row index), 'header' (first leaf with KeepWithGroup=After "
            "— the column header row), 'details' (the Details leaf "
            "row), '<group>_header' (header row of a named row group), "
            "'<group>_footer' (footer row when present, e.g. after "
            "add_subtotal_row). Same style kwargs as set_textbox_style "
            "(font_*, color, background_color, border_*, padding_*, "
            "writing_mode, can_grow, can_shrink, etc.). Delegates "
            "writes to set_textbox_style_bulk. Returns {tablix, row, "
            "row_index, kind, cells, changed, skipped}."
        ),
        input_schema={
            "type": "object",
            "properties": {
                "path": {"type": "string"},
                "tablix_name": {"type": "string"},
                "row": {
                    "oneOf": [
                        {"type": "integer", "minimum": 0},
                        {"type": "string"},
                    ],
                    "description": (
                        "Integer index, or one of: 'header', 'details', "
                        "'<group>_header', '<group>_footer'."
                    ),
                },
                "font_family": {"type": ["string", "null"]},
                "font_size": {"type": ["string", "null"]},
                "font_weight": {"type": ["string", "null"]},
                "color": {"type": ["string", "null"]},
                "background_color": {"type": ["string", "null"]},
                "border_style": {"type": ["string", "null"]},
                "border_color": {"type": ["string", "null"]},
                "border_width": {"type": ["string", "null"]},
                "text_align": {"type": ["string", "null"]},
                "vertical_align": {"type": ["string", "null"]},
                "format": {"type": ["string", "null"]},
                "padding_top": {"type": ["string", "null"]},
                "padding_bottom": {"type": ["string", "null"]},
                "padding_left": {"type": ["string", "null"]},
                "padding_right": {"type": ["string", "null"]},
                "writing_mode": {"type": ["string", "null"]},
                "can_grow": {"type": ["boolean", "null"]},
                "can_shrink": {"type": ["boolean", "null"]},
            },
            "required": ["path", "tablix_name", "row"],
            "additionalProperties": False,
        },
        handler=styling.style_tablix_row,
    )

    _BODY_TEXTBOX_SCHEMA = {
        "type": "object",
        "properties": {
            "path": {"type": "string"},
            "name": {"type": "string"},
            "text": {
                "type": "string",
                "description": "Static text or RDL expression (=...).",
            },
            "top": {"type": "string"},
            "left": {"type": "string"},
            "width": {"type": "string"},
            "height": {"type": "string"},
        },
        "required": ["path", "name", "text", "top", "left", "width", "height"],
        "additionalProperties": False,
    }
    _BODY_IMAGE_SCHEMA = {
        "type": "object",
        "properties": {
            "path": {"type": "string"},
            "name": {"type": "string"},
            "image_source": {
                "type": "string",
                "enum": ["External", "Embedded", "Database"],
            },
            "value": {"type": "string"},
            "top": {"type": "string"},
            "left": {"type": "string"},
            "width": {"type": "string"},
            "height": {"type": "string"},
        },
        "required": [
            "path",
            "name",
            "image_source",
            "value",
            "top",
            "left",
            "width",
            "height",
        ],
        "additionalProperties": False,
    }
    server.register_tool(
        name="add_body_textbox",
        description=(
            "Add a Textbox to <Body>/<ReportItems>. text accepts static "
            "strings or RDL expressions (e.g. =Globals!ReportName). "
            "Coexists with the existing tablix; rejects names already in use. "
            "Pass raw text — encoding is handled; don't pre-encode XML "
            "entities (use `&` not `&amp;`, including for the VB.NET "
            "string-concat operator in expressions)."
        ),
        input_schema=_BODY_TEXTBOX_SCHEMA,
        handler=body.add_body_textbox,
    )
    server.register_tool(
        name="add_body_image",
        description=(
            "Add an Image to <Body>/<ReportItems>. image_source: "
            "External (URL), Embedded (EmbeddedImage Name), Database "
            "(=Fields!Photo.Value)."
        ),
        input_schema=_BODY_IMAGE_SCHEMA,
        handler=body.add_body_image,
    )
    server.register_tool(
        name="remove_body_item",
        description=(
            "Remove a named item (Textbox, Image, or Tablix) from "
            "<Body>/<ReportItems>. Destructive but explicit — raises if "
            "the name doesn't match anything."
        ),
        input_schema={
            "type": "object",
            "properties": {
                "path": {"type": "string"},
                "name": {"type": "string"},
            },
            "required": ["path", "name"],
            "additionalProperties": False,
        },
        handler=body.remove_body_item,
    )

    server.register_tool(
        name="insert_tablix_from_template",
        description=(
            "Build and append a basic Tablix to <Body>/<ReportItems>. One "
            "column per name in `columns`; header row gets the column "
            "name as a static label, detail row binds to "
            "=Fields!<column>.Value. dataset_name must already exist. "
            "`width` is the tablix outer width — each column defaults to "
            "1in regardless, so for a 3-column tablix the columns sum to "
            "3in even if you pass width=10cm. Resize columns afterwards "
            "via direct edits or future column-width tools."
        ),
        input_schema={
            "type": "object",
            "properties": {
                "path": {"type": "string"},
                "name": {"type": "string"},
                "dataset_name": {"type": "string"},
                "columns": {
                    "type": "array",
                    "items": {"type": "string"},
                    "minItems": 1,
                },
                "top": {"type": "string"},
                "left": {"type": "string"},
                "width": {"type": "string"},
                "height": {"type": "string"},
            },
            "required": [
                "path",
                "name",
                "dataset_name",
                "columns",
                "top",
                "left",
                "width",
                "height",
            ],
            "additionalProperties": False,
        },
        handler=templates.insert_tablix_from_template,
    )
    server.register_tool(
        name="insert_chart_from_template",
        description=(
            "Build and append a basic Column chart to <Body>/<ReportItems>. "
            "Single category axis grouped by category_field; single Y series "
            "Sum(Fields!<value_field>.Value). dataset_name must already exist. "
            "Change <Type> post-insert (e.g. to Bar / Line / Pie) by "
            "editing the chart directly."
        ),
        input_schema={
            "type": "object",
            "properties": {
                "path": {"type": "string"},
                "name": {"type": "string"},
                "dataset_name": {"type": "string"},
                "category_field": {"type": "string"},
                "value_field": {"type": "string"},
                "top": {"type": "string"},
                "left": {"type": "string"},
                "width": {"type": "string"},
                "height": {"type": "string"},
            },
            "required": [
                "path",
                "name",
                "dataset_name",
                "category_field",
                "value_field",
                "top",
                "left",
                "width",
                "height",
            ],
            "additionalProperties": False,
        },
        handler=chart.insert_chart_from_template,
    )
    server.register_tool(
        name="add_chart_series",
        description=(
            "Append a new <ChartSeries> to a named chart. value_field is "
            "the dataset field whose Sum becomes the Y expression "
            "(=Sum(Fields!<value_field>.Value)). series_type defaults to "
            "Column; combine series of different types in one chart for "
            "combo charts (e.g. Bar + Line). series_subtype defaults to "
            "Plain. Refuses if series_name already exists."
        ),
        input_schema={
            "type": "object",
            "properties": {
                "path": {"type": "string"},
                "chart_name": {"type": "string"},
                "series_name": {"type": "string"},
                "value_field": {"type": "string"},
                "series_type": {
                    "type": "string",
                    "description": (
                        "Column / Bar / Line / Area / Pie / Doughnut / "
                        "Range / Scatter / Bubble / Stock / Polar / Radar "
                        "/ Funnel / Pyramid"
                    ),
                },
                "series_subtype": {
                    "type": "string",
                    "description": (
                        "Plain / Stacked / PercentStacked / Smooth / "
                        "Exploded / SmoothLine / 100 / Line / Spline"
                    ),
                },
            },
            "required": ["path", "chart_name", "series_name", "value_field"],
            "additionalProperties": False,
        },
        handler=chart.add_chart_series,
    )
    server.register_tool(
        name="remove_chart_series",
        description=(
            "Remove a named <ChartSeries> from a chart. Refuses to remove "
            "the last remaining series (use remove_body_item to drop the "
            "whole chart instead). Returns {chart, removed, remaining}."
        ),
        input_schema={
            "type": "object",
            "properties": {
                "path": {"type": "string"},
                "chart_name": {"type": "string"},
                "series_name": {"type": "string"},
            },
            "required": ["path", "chart_name", "series_name"],
            "additionalProperties": False,
        },
        handler=chart.remove_chart_series,
    )
    server.register_tool(
        name="set_chart_series_type",
        description=(
            "Update <Type> and <Subtype> on a named ChartSeries. Combo "
            "charts work by setting different types per series in the "
            "same chart (e.g. one Bar series and one Line series). "
            "Returns {chart, series, kind, changed: list[str]} — empty "
            "when inputs match existing values (no-op short-circuit)."
        ),
        input_schema={
            "type": "object",
            "properties": {
                "path": {"type": "string"},
                "chart_name": {"type": "string"},
                "series_name": {"type": "string"},
                "series_type": {"type": "string"},
                "series_subtype": {"type": "string", "default": "Plain"},
            },
            "required": ["path", "chart_name", "series_name", "series_type"],
            "additionalProperties": False,
        },
        handler=chart.set_chart_series_type,
    )
    server.register_tool(
        name="set_chart_axis",
        description=(
            "Configure a chart axis: title (Caption), format (numeric/"
            "date format string in <Style>/<Format>), min/max range, "
            "log_scale, interval, visible. axis ∈ {Category, Value}; "
            "axis_name defaults to 'Primary' (the only axis the template "
            "emits — pass a real name for secondary axes). "
            "All field args are optional; pass '' to clear an element. "
            "Returns {chart, axis, axis_name, kind, changed: list[str]} "
            "with the affected sub-element names."
        ),
        input_schema={
            "type": "object",
            "properties": {
                "path": {"type": "string"},
                "chart_name": {"type": "string"},
                "axis": {
                    "type": "string",
                    "description": "Category or Value",
                    "enum": ["Category", "Value"],
                },
                "axis_name": {"type": "string", "default": "Primary"},
                "title": {"type": "string"},
                "format": {
                    "type": "string",
                    "description": "Numeric/date format, e.g. '#,0.00' or 'MMM yyyy'.",
                },
                "min": {"type": "string"},
                "max": {"type": "string"},
                "log_scale": {"type": "boolean"},
                "interval": {"type": "string"},
                "visible": {"type": "boolean"},
            },
            "required": ["path", "chart_name", "axis"],
            "additionalProperties": False,
        },
        handler=chart.set_chart_axis,
    )
    server.register_tool(
        name="set_chart_legend",
        description=(
            "Configure a chart legend: position (TopLeft / TopCenter / "
            "TopRight / LeftTop / LeftCenter / LeftBottom / RightTop / "
            "RightCenter / RightBottom / BottomLeft / BottomCenter / "
            "BottomRight) and visible (writes <Hidden>true|false</Hidden>). "
            "legend_name defaults to 'Default' (the only one the template "
            "emits). Returns {chart, legend, kind, changed: list[str]}; "
            "no-op short-circuit when nothing supplied."
        ),
        input_schema={
            "type": "object",
            "properties": {
                "path": {"type": "string"},
                "chart_name": {"type": "string"},
                "legend_name": {"type": "string", "default": "Default"},
                "position": {"type": "string"},
                "visible": {"type": "boolean"},
            },
            "required": ["path", "chart_name"],
            "additionalProperties": False,
        },
        handler=chart.set_chart_legend,
    )
    server.register_tool(
        name="set_chart_data_labels",
        description=(
            "Configure <ChartDataLabel> on one or all series in a chart. "
            "When series_name is None, the change applies to every "
            "series; otherwise only the named series. visible writes "
            "<Visible>true|false</Visible>; format writes <Style>/<Format>. "
            "Pass format='' to clear the format. Returns {chart, series, "
            "kind, changed}; series lists affected series names."
        ),
        input_schema={
            "type": "object",
            "properties": {
                "path": {"type": "string"},
                "chart_name": {"type": "string"},
                "series_name": {"type": "string"},
                "visible": {"type": "boolean"},
                "format": {"type": "string"},
            },
            "required": ["path", "chart_name"],
            "additionalProperties": False,
        },
        handler=chart.set_chart_data_labels,
    )
    server.register_tool(
        name="set_chart_palette",
        description=(
            "Set <Palette> on a chart. palette ∈ Default / EarthTones / "
            "Excel / GrayScale / Light / Pastel / SemiTransparent / "
            "Berry / Chocolate / Fire / SeaGreen / BrightPastel. Pass "
            "'' to clear (RB falls back to its built-in default palette). "
            "Returns {chart, kind, changed: bool}."
        ),
        input_schema={
            "type": "object",
            "properties": {
                "path": {"type": "string"},
                "chart_name": {"type": "string"},
                "palette": {"type": "string"},
            },
            "required": ["path", "chart_name", "palette"],
            "additionalProperties": False,
        },
        handler=chart.set_chart_palette,
    )
    server.register_tool(
        name="set_series_color",
        description=(
            "Write <Color> into a named series's <Style> block, "
            "overriding the chart palette for just that series. color "
            "accepts a named color ('Red'), a hex string ('#FF0000'), "
            "or an =expression. Pass '' to clear (series falls back to "
            "the palette). Returns {chart, series, kind, changed: bool}."
        ),
        input_schema={
            "type": "object",
            "properties": {
                "path": {"type": "string"},
                "chart_name": {"type": "string"},
                "series_name": {"type": "string"},
                "color": {"type": "string"},
            },
            "required": ["path", "chart_name", "series_name", "color"],
            "additionalProperties": False,
        },
        handler=chart.set_series_color,
    )
    server.register_tool(
        name="set_chart_title",
        description=(
            "Update <ChartTitle>/<Caption>. text can be literal text or "
            "an =expression. title_name defaults to 'Default' (the only "
            "title the template emits). Returns {chart, title, kind, "
            "changed: bool}."
        ),
        input_schema={
            "type": "object",
            "properties": {
                "path": {"type": "string"},
                "chart_name": {"type": "string"},
                "text": {"type": "string"},
                "title_name": {"type": "string", "default": "Default"},
            },
            "required": ["path", "chart_name", "text"],
            "additionalProperties": False,
        },
        handler=chart.set_chart_title,
    )

    _STATIC_VALUE_ITEM = {
        "oneOf": [
            {"type": "string"},
            {
                "type": "object",
                "properties": {
                    "value": {"type": "string"},
                    "label": {"type": "string"},
                },
                "required": ["value"],
                "additionalProperties": False,
            },
        ]
    }
    server.register_tool(
        name="set_parameter_available_values",
        description=(
            "Set or clear <ValidValues> on a report parameter. "
            "source='static' with a non-empty static_values writes a list "
            "of <ParameterValue> entries (each entry can be a string or "
            "{value, label} dict). source='static' with static_values=[] "
            "or omitted CLEARS the <ValidValues> element entirely (mirrors "
            "set_parameter_prompt('') and returns cleared=true). "
            "source='query' writes a <DataSetReference> to a lookup "
            "dataset. Replaces any existing <ValidValues> block."
        ),
        input_schema={
            "type": "object",
            "properties": {
                "path": {"type": "string"},
                "name": {"type": "string"},
                "source": {"type": "string", "enum": ["static", "query"]},
                "static_values": {
                    "type": ["array", "null"],
                    "items": _STATIC_VALUE_ITEM,
                },
                "query_dataset": {"type": ["string", "null"]},
                "query_value_field": {"type": ["string", "null"]},
                "query_label_field": {"type": ["string", "null"]},
            },
            "required": ["path", "name", "source"],
            "additionalProperties": False,
        },
        handler=parameters.set_parameter_available_values,
    )
    server.register_tool(
        name="set_parameter_default_values",
        description=(
            "Set or clear <DefaultValue> on a report parameter. "
            "source='static' with a non-empty static_values writes a "
            "<Values> list of expressions. source='static' with "
            "static_values=[] or omitted CLEARS the <DefaultValue> element "
            "entirely (mirrors set_parameter_prompt('') and returns "
            "cleared=true). source='query' writes a <DataSetReference> "
            "with ValueField only (no LabelField — defaults are values, "
            "not display strings). Replaces any existing block."
        ),
        input_schema={
            "type": "object",
            "properties": {
                "path": {"type": "string"},
                "name": {"type": "string"},
                "source": {"type": "string", "enum": ["static", "query"]},
                "static_values": {
                    "type": ["array", "null"],
                    "items": {"type": "string"},
                },
                "query_dataset": {"type": ["string", "null"]},
                "query_value_field": {"type": ["string", "null"]},
            },
            "required": ["path", "name", "source"],
            "additionalProperties": False,
        },
        handler=parameters.set_parameter_default_values,
    )

    server.register_tool(
        name="update_parameter_advanced",
        description=(
            "Toggle the four boolean flags on a report parameter: "
            "multi_value, hidden, allow_null (writes <Nullable>), "
            "allow_blank. Each is independently optional. With no flags "
            "passed it's a no-op. Cascading parameters are NOT a flag — "
            "use set_parameter_available_values(source='query') + "
            "add_query_parameter on the lookup dataset to wire a "
            "dependency on another parameter."
        ),
        input_schema={
            "type": "object",
            "properties": {
                "path": {"type": "string"},
                "name": {"type": "string"},
                "multi_value": {"type": ["boolean", "null"]},
                "hidden": {"type": ["boolean", "null"]},
                "allow_null": {"type": ["boolean", "null"]},
                "allow_blank": {"type": ["boolean", "null"]},
            },
            "required": ["path", "name"],
            "additionalProperties": False,
        },
        handler=parameters.update_parameter_advanced,
    )

    server.register_tool(
        name="add_embedded_image",
        description=(
            "Read a real image file off disk, base64-encode it, and store "
            "it under <EmbeddedImages>. Reference it later with "
            "image_source='Embedded' + value=<name>. Supported MIME types: "
            "image/bmp, image/gif, image/jpeg, image/png, image/x-png. "
            "The file's magic bytes are sniffed and must match mime_type — "
            "claiming PNG bytes as image/jpeg is rejected here rather than "
            "letting Report Builder fail at preview time."
        ),
        input_schema={
            "type": "object",
            "properties": {
                "path": {"type": "string"},
                "name": {"type": "string"},
                "mime_type": {
                    "type": "string",
                    "enum": [
                        "image/bmp",
                        "image/gif",
                        "image/jpeg",
                        "image/png",
                        "image/x-png",
                    ],
                },
                "image_path": {
                    "type": "string",
                    "description": "Filesystem path to the source image.",
                },
            },
            "required": ["path", "name", "mime_type", "image_path"],
            "additionalProperties": False,
        },
        handler=embedded_images.add_embedded_image,
    )
    server.register_tool(
        name="list_embedded_images",
        description=(
            "List embedded images in the report by name and MIME type. "
            "Returns an empty list when <EmbeddedImages> is absent."
        ),
        input_schema={
            "type": "object",
            "properties": {"path": {"type": "string"}},
            "required": ["path"],
            "additionalProperties": False,
        },
        handler=embedded_images.list_embedded_images,
    )
    server.register_tool(
        name="remove_embedded_image",
        description=(
            "Remove a named embedded image. Refuses (lists offending Image "
            'elements) when any <Image Source="Embedded"><Value>=name> '
            "still references it; pass force=True to remove anyway and "
            "accept the dangling references. Drops the empty "
            "<EmbeddedImages/> block when removing the last entry."
        ),
        input_schema={
            "type": "object",
            "properties": {
                "path": {"type": "string"},
                "name": {"type": "string"},
                "force": {"type": "boolean", "default": False},
            },
            "required": ["path", "name"],
            "additionalProperties": False,
        },
        handler=embedded_images.remove_embedded_image,
    )

    server.register_tool(
        name="set_alternating_row_color",
        description=(
            "Zebra-stripe a tablix's detail row by writing "
            "BackgroundColor=IIf(RowNumber(Nothing) Mod 2, color_a, color_b) "
            "on every detail cell's Textbox. Walks the row hierarchy to "
            "find the Details leaf — works after add_row_group nests the "
            "structure deeper. Replaces any existing BackgroundColor."
        ),
        input_schema={
            "type": "object",
            "properties": {
                "path": {"type": "string"},
                "tablix_name": {"type": "string"},
                "color_a": {
                    "type": "string",
                    "description": "Odd-row color, e.g. '#F2F2F2'.",
                },
                "color_b": {
                    "type": "string",
                    "description": "Even-row color, e.g. '#FFFFFF'.",
                },
            },
            "required": ["path", "tablix_name", "color_a", "color_b"],
            "additionalProperties": False,
        },
        handler=styling.set_alternating_row_color,
    )
    server.register_tool(
        name="set_conditional_row_color",
        description=(
            "Color every cell of a tablix's detail row based on the value "
            "of one of its fields. Builds a Switch(...) expression mapping "
            "field values to colors and writes it as BackgroundColor on "
            "every detail cell. value_expression is the field reference "
            "(e.g. 'Fields!Status.Value' — a leading '=' is accepted). "
            "color_map is an ordered dict of value->color (e.g. "
            '{"Red":"#FF0000","Yellow":"#FFFF00"}); first match '
            "wins. Unmatched values fall back to default_color "
            "(default 'Transparent'). When case_sensitive is False "
            "(default), wraps the field reference in UCase() and uppercases "
            "the keys for case-insensitive matching. Walks the row "
            "hierarchy to find the Details leaf — works after add_row_group "
            "nests the structure. Replaces any existing BackgroundColor."
        ),
        input_schema={
            "type": "object",
            "properties": {
                "path": {"type": "string"},
                "tablix_name": {"type": "string"},
                "value_expression": {
                    "type": "string",
                    "description": (
                        "Field reference to switch on, e.g. "
                        "'Fields!Status.Value'. Leading '=' optional."
                    ),
                },
                "color_map": {
                    "type": "object",
                    "description": (
                        "Ordered map of expected values to color strings. "
                        "First match in declaration order wins."
                    ),
                    "additionalProperties": {"type": "string"},
                    "minProperties": 1,
                },
                "default_color": {
                    "type": "string",
                    "default": "Transparent",
                },
                "case_sensitive": {
                    "type": "boolean",
                    "default": False,
                },
            },
            "required": ["path", "tablix_name", "value_expression", "color_map"],
            "additionalProperties": False,
        },
        handler=styling.set_conditional_row_color,
    )

    server.register_tool(
        name="set_element_visibility",
        description=(
            "Set <Visibility> on any named ReportItem (Tablix, Textbox, "
            "Image, Rectangle, Subreport, Chart). For group-level "
            "visibility use set_group_visibility; for detail-row use "
            "set_detail_row_visibility. toggle_textbox optionally points "
            "at a textbox name that toggles expand/collapse."
        ),
        input_schema={
            "type": "object",
            "properties": {
                "path": {"type": "string"},
                "element_name": {"type": "string"},
                "hidden_expression": {"type": "string"},
                "toggle_textbox": {"type": ["string", "null"]},
            },
            "required": ["path", "element_name", "hidden_expression"],
            "additionalProperties": False,
        },
        handler=visibility.set_element_visibility,
    )


__all__ = ["register_all_tools"]
