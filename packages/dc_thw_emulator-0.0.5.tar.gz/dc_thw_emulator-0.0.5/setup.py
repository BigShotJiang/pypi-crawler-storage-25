from pathlib import Path

from setuptools import find_packages, setup

# Read the README.md for the long description
this_directory = Path(__file__).parent
long_description = (this_directory / "README.md").read_text(encoding="utf-8")

setup(
    name="dc-thw-emulator", #pip install dc-thw-emulator --upgrade
    version="0.0.5",
    packages=find_packages(),
    author="Dai Chao Online",
    description="Emulator Manager for THW Emulator instances",
    long_description=long_description,
    long_description_content_type="text/markdown",
    python_requires=">=3.8",
    install_requires=[
        # List any dependencies your package needs here, e.g.
        # "pywin32",
        # "psutil",
    ],
    classifiers=[
        "Programming Language :: Python :: 3",
        "Operating System :: Microsoft :: Windows",
        "License :: OSI Approved :: MIT License",
        "Intended Audience :: Developers",
    ],
)
