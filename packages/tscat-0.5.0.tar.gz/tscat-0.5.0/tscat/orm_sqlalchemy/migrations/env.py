import os.path
from logging.config import fileConfig
from logging import getLogger
from datetime import datetime
from shutil import copyfile
from typing import Optional

from sqlalchemy import engine_from_config
from sqlalchemy import pool

from alembic import context

# this is the Alembic Config object, which provides
# access to the values within the .ini file in use.
config = context.config

# Interpret the config file for Python logging.
# This line sets up loggers basically.
if config.config_file_name is not None:
    fileConfig(config.config_file_name)

# add your model's MetaData object here
# for 'autogenerate' support
from tscat.orm_sqlalchemy.orm import Base

target_metadata = Base.metadata


# other values from the config, defined by the needs of env.py,
# can be acquired:
# my_important_option = config.get_main_option("my_important_option")
# ... etc.

def _backup_database(db_url: Optional[str] = None):
    if db_url is not None:
        path = db_url.replace('sqlite://', '')
        if os.path.exists(path) and os.path.isfile(path):
            now = datetime.now().strftime('%Y%m%dT%H%M%S')
            backup_path = path.replace('.sqlite', f'-{now}.sqlite.backup')
            getLogger('alembic').info(f'Backing up database to {backup_path}')
            copyfile(path, backup_path)


def run_migrations_offline() -> None:  # pragma: no cover
    """Run migrations in 'offline' mode.

    This configures the context with just a URL
    and not an Engine, though an Engine is acceptable
    here as well.  By skipping the Engine creation
    we don't even need a DBAPI to be available.

    Calls to context.execute() here emit the given string to the
    script output.

    """
    url = config.get_main_option("sqlalchemy.url")
    context.configure(
        url=url,
        target_metadata=target_metadata,
        literal_binds=True,
        dialect_opts={"paramstyle": "named"},
    )
    if context.get_head_revision() != context.get_context().get_current_revision():
        _backup_database(url)
    with context.begin_transaction():
        context.run_migrations()


def run_migrations_online() -> None:
    """Run migrations in 'online' mode.

    In this scenario we need to create an Engine
    and associate a connection with the context.

    """
    connectable = engine_from_config(
        config.get_section(config.config_ini_section, {}),
        prefix="sqlalchemy.",
        poolclass=pool.NullPool,
    )

    with connectable.connect() as connection:
        context.configure(
            connection=connection, target_metadata=target_metadata
        )
        if context.get_head_revision() != context.get_context().get_current_revision():
            _backup_database(config.get_main_option("sqlalchemy.url"))
        with context.begin_transaction():
            context.run_migrations()


if context.is_offline_mode():
    run_migrations_offline()  # pragma: no cover
else:
    run_migrations_online()
