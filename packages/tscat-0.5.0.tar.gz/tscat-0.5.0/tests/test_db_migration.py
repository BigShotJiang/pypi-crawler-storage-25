import unittest
import tscat.orm_sqlalchemy
import os
from glob import glob
import tscat
import datetime as dt
from tscat.filtering import All, Any, Comparison, Match, Has, In, Field, Attribute


class DBMigration(unittest.TestCase):

    def setUp(self) -> None:
        if tscat.base._backend:
            tscat.base._backend.close()
        test_db_file = os.path.join(os.path.dirname(os.path.realpath(__file__)), 'migration-db-test.sqlite')
        tscat.base._backend = tscat.orm_sqlalchemy.Backend(testing=test_db_file)

    def test_existing_event_now_has_rating_field(self):
        existing, = tscat.get_events()
        self.assertEqual(existing.rating, None)
        self.assertGreater(len(glob(f'{tscat.base.backend()._tmp_dir}/*.sqlite.backup')), 0)

    def test_creating_event_with_rating(self):
        tscat.create_event(dt.datetime.now(), dt.datetime.now() + dt.timedelta(days=1), "Patrick", rating=3)

        _, e = tscat.get_events()
        self.assertEqual(e.author, "Patrick")
        self.assertEqual(e.rating, 3)

        self.assertEqual(len(tscat.get_events()), 2)

    def test_existing_event_tags_survived_migration(self):
        existing, = tscat.get_events()
        self.assertListEqual(existing.tags, ['tag1', 'tag2'])
        self.assertListEqual(existing.products, ['prod1', 'mars'])

    def test_existing_catalogue_tags_survived_migration(self):
        cats = tscat.get_catalogues()
        self.assertEqual(len(cats), 1)
        self.assertListEqual(cats[0].tags, ['tag1', '#tag2', '', "'as"])

    def test_existing_catalogue_pickled_predicate_migrated_to_json(self):
        cats = tscat.get_catalogues()
        self.assertEqual(len(cats), 1)
        expected = All(
            Comparison('==', Field('author'), 'Patrick'),
            Any(
                Match(Attribute('description'), r'^test.*'),
                Has(Attribute('priority')),
            ),
            In('mars', Field('products')),
            Comparison('>=', Attribute('score'), 5),
        )
        self.assertEqual(repr(cats[0].predicate), repr(expected))
