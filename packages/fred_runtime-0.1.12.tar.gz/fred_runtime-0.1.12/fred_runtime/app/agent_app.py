# Copyright Thales 2026
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
"""
Reusable FastAPI app factory for Fred agent pods.

Why this module exists:
- every agent pod (rags-v2, future pods) needs identical execution plumbing:
  RuntimeConfig wiring, BoundRuntimeContext construction, ReActRuntime lifecycle,
  and `POST /agents/execute` / `POST /agents/execute/stream` endpoints
- duplicating that across pods causes divergence bugs and maintenance overhead

How to use it:
- call `create_agent_app(registry, config)` in your pod's `main.py`
- the returned FastAPI app already exposes:
    POST {config.app.base_url}/agents/execute                           — terminal RuntimeEvent JSON
    POST {config.app.base_url}/agents/execute/stream                    — stream RuntimeEvent JSON over SSE
    GET  {config.app.base_url}/agents                                   — list registered agent IDs
    GET  {config.app.base_url}/agents/sessions/{session_id}/messages    — conversation history from checkpointer
- pass `extra_routers` to mount additional domain-specific routers under `config.app.base_url`

Example:
    from fred_runtime.app import create_agent_app, load_agent_pod_config
    from myapp.agents.registry import REGISTRY

    config = load_agent_pod_config()
    app = create_agent_app(registry=REGISTRY, config=config)
"""

from __future__ import annotations

import json
import logging
from collections.abc import AsyncIterator, Mapping
from contextlib import asynccontextmanager
from dataclasses import dataclass
from typing import Any
from uuid import uuid4

import httpx
from fastapi import APIRouter, Depends, FastAPI, HTTPException, Request, status
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse, StreamingResponse
from fred_core.logs.log_setup import log_setup
from fred_core.logs.memory_log_store import RamLogStore
from fred_core.security.oidc import get_keycloak_client_id, get_keycloak_url
from fred_sdk.contracts.context import (
    BoundRuntimeContext,
    PortableContext,
    PortableEnvironment,
    RuntimeContext,
)
from fred_sdk.contracts.models import (
    AgentTuning,
    ExecutionCategory,
    GraphAgentDefinition,
    MCPServerConfiguration,
    ReActAgentDefinition,
)
from fred_sdk.contracts.react_contract import ReActInput, ReActMessage, ReActMessageRole
from fred_sdk.contracts.runtime import ExecutionConfig, RuntimeServices
from fred_sdk.graph.graph_runtime import GraphRuntime
from fred_sdk.react.react_runtime import ReActRuntime
from fred_sdk.support.authored_toolsets import (
    AuthoredToolRuntimePorts,
    build_authored_tool_handlers,
)
from pydantic import BaseModel, Field, model_validator

from fred_runtime.common.kf_markdown_media_client import KfMarkdownMediaClient

from ..common.structures import AgentSettingsLike
from ..integrations.v2_runtime.adapters import (
    CompositeToolInvoker,
    FredArtifactPublisher,
    FredKnowledgeSearchToolInvoker,
    FredMcpToolProvider,
    FredResourceReader,
    build_default_tracer,
)
from ..runtime_context import (
    RuntimeConfig,
    get_runtime_context,
    set_runtime_context,
)
from ..runtime_context import RuntimeContext as FredRuntimeContext
from ..runtime_support import refresh_user_access_token_from_keycloak
from .config import AgentPodConfig
from .observability_factory import bootstrap_observability

logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Chat model factory builder
# ---------------------------------------------------------------------------


def _build_chat_model_factory(config: AgentPodConfig) -> Any:
    """
    Build a ChatModelFactoryPort for the configured model backend.

    Resolution:
    - the resolved mandatory `models_catalog.yaml` path is attached during
      `load_agent_pod_config()`
    - this function loads it and builds a `RoutedChatModelFactory` backed by
      `ModelRoutingResolver`
    - rules in the catalog are evaluated per-request against the real
      `BoundRuntimeContext` (agent_id, team_id, user_id)

    Why this returns a ChatModelFactoryPort (not a zero-arg callable):
    - `RoutedChatModelFactory.build(definition, binding)` receives the full
      runtime context per invocation, enabling per-request rule evaluation.
    """
    from ..model_routing import (
        ModelRoutingResolver,
        RoutedChatModelFactory,
        load_model_catalog,
    )

    catalog_path = config.get_models_catalog_path()
    if not catalog_path:
        raise RuntimeError(
            "AgentPodConfig is missing the resolved models catalog path. "
            "Use load_agent_pod_config() for pod startup."
        )

    catalog = load_model_catalog(catalog_path)
    policy = catalog.to_policy()
    logger.info(
        "[fred-runtime] model routing from catalog=%s profiles=%d rules=%d",
        catalog_path,
        len(policy.profiles),
        len(policy.rules),
    )
    return RoutedChatModelFactory(resolver=ModelRoutingResolver(policy))


@dataclass(slots=True)
class _PodAgentSettings:
    """
    Minimal settings object expected by fred-runtime adapter ports.

    Why this exists:
    - the reusable pod app executes raw `ReActAgentDefinition` objects, not the
      richer settings model assembled inside agentic-backend
    - runtime adapters still need a small identity/tuning object so authored
      tools, Fred built-ins, and MCP defaults behave the same way in pods

    How to use it:
    - build one from the current agent definition for each request
    - pass it to the fred-runtime adapter constructors

    Example:
    - `settings = _build_agent_settings(definition)`
    """

    id: str
    name: str
    team_id: str | None
    tuning: AgentTuning | None


class _MediaClientAgentAdapter:
    """
    Small bridge exposing token refresh to the markdown media client.

    Why this exists:
    - authored tools may call `ctx.fetch_media(...)`
    - `KfMarkdownMediaClient` expects an agent-like object with runtime context,
      settings, and a token-refresh hook

    How to use it:
    - instantiate only from `_build_media_fetcher(...)`

    Example:
    - `adapter = _MediaClientAgentAdapter(binding=binding, settings=settings)`
    """

    def __init__(
        self, *, binding: BoundRuntimeContext, settings: _PodAgentSettings
    ) -> None:
        self.runtime_context = binding.runtime_context
        self.agent_settings: AgentSettingsLike = settings

    def refresh_user_access_token(self) -> str:
        """
        Refresh the user access token for media downloads.

        Why this exists:
        - media fetch retries need the same Keycloak refresh path as other
          runtime adapters

        How to use it:
        - called by `KfMarkdownMediaClient` when the current token is expired

        Example:
        - `token = adapter.refresh_user_access_token()`
        """

        refresh_token = self.runtime_context.refresh_token
        if not refresh_token:
            raise RuntimeError(
                "Cannot refresh user access token: refresh_token missing from runtime context."
            )

        keycloak_url = get_keycloak_url()
        client_id = get_keycloak_client_id()
        if not keycloak_url:
            raise RuntimeError(
                "User security realm_url is not configured for Keycloak."
            )
        if not client_id:
            raise RuntimeError(
                "User security client_id is not configured for Keycloak."
            )

        payload = refresh_user_access_token_from_keycloak(
            keycloak_url=keycloak_url,
            client_id=client_id,
            refresh_token=refresh_token,
        )
        new_access_token = payload.get("access_token")
        new_refresh_token = payload.get("refresh_token") or refresh_token
        if not isinstance(new_access_token, str) or not new_access_token:
            raise RuntimeError(
                "Keycloak refresh response did not include a valid access_token."
            )

        self.runtime_context.access_token = new_access_token
        self.runtime_context.refresh_token = new_refresh_token
        return new_access_token


def _definition_to_agent_tuning(
    definition: ReActAgentDefinition | GraphAgentDefinition,
) -> AgentTuning:
    """
    Project one ReAct definition into the public runtime tuning shape.

    Why this exists:
    - pod metadata endpoints and managed-instance execution both need the same
      "default tuning" view of a registered template without importing
      agentic-backend catalog helpers

    How to use it:
    - call for template metadata responses or when building adapter settings

    Example:
    - `tuning = _definition_to_agent_tuning(definition)`
    """

    return AgentTuning(
        role=definition.role,
        description=definition.description,
        tags=list(definition.tags),
        fields=list(definition.fields),
        mcp_servers=list(definition.default_mcp_servers),
    )


def _build_agent_settings(
    definition: ReActAgentDefinition | GraphAgentDefinition,
    *,
    team_id: str | None = None,
) -> _PodAgentSettings:
    """
    Derive the minimal runtime settings object for one pod-hosted agent.

    Why this exists:
    - fred-runtime adapter ports operate on a small settings contract rather
      than raw definitions
    - pod execution should still honor default MCP servers and agent identity
      the same way the backend bootstrap does

    How to use it:
    - call once per request before constructing runtime adapter ports

    Example:
    - `settings = _build_agent_settings(definition)`
    """

    return _PodAgentSettings(
        id=definition.agent_id,
        name=definition.agent_id,
        team_id=team_id,
        tuning=_definition_to_agent_tuning(definition),
    )


def _build_media_fetcher(*, binding: BoundRuntimeContext, settings: _PodAgentSettings):
    """
    Build the media-fetcher port exposed to Python-authored tool handlers.

    Why this exists:
    - authored tools can fetch packaged markdown media through `ctx.fetch_media`
    - the SDK expects a small async callable, not a concrete fred-runtime client

    How to use it:
    - pass the current binding and agent settings while assembling authored-tool
      runtime ports

    Example:
    - `media_fetcher = _build_media_fetcher(binding=binding, settings=settings)`
    """

    adapter = _MediaClientAgentAdapter(binding=binding, settings=settings)
    client: KfMarkdownMediaClient | None = None

    async def _fetch_media(document_uid: str, file_name: str) -> bytes:
        """
        Fetch one packaged media asset lazily through Knowledge Flow.

        Why this exists:
        - media support should be available to authored tools without incurring
          client setup cost when no tool uses it

        How to use it:
        - invoked by the authored-tool runtime when a tool calls
          `ctx.fetch_media(...)`

        Example:
        - `payload = await media_fetcher("doc-123", "image.png")`
        """

        nonlocal client
        if client is None:
            client = KfMarkdownMediaClient(agent=adapter)
        return await client.fetch_media(document_uid, file_name)

    return _fetch_media


def _build_runtime_services(
    definition: ReActAgentDefinition | GraphAgentDefinition,
    binding: BoundRuntimeContext,
    *,
    team_id: str | None = None,
) -> RuntimeServices:
    """
    Assemble the full `RuntimeServices` bundle for one pod request.

    Why this exists:
    - authored local tools, Fred built-ins, MCP tools, resource reads, and
      artifact publication now all share one runtime contract in `fred-sdk`
    - the reusable pod app must mirror the same binding-aware service assembly
      already used by agentic-backend, or declared tools fail at runtime

    How to use it:
    - call from `_stream(...)` after the request binding is constructed
    - create a fresh service bundle per request so binding-scoped adapters stay
      aligned with the current session/user/token context

    Example:
    - `services = _build_runtime_services(definition, binding)`
    """

    runtime_config = get_runtime_context().config
    settings = _build_agent_settings(definition, team_id=team_id)
    base_tool_invoker = FredKnowledgeSearchToolInvoker(
        binding=binding,
        settings=settings,
    )
    tool_provider = FredMcpToolProvider(
        binding=binding,
        settings=settings,
    )
    artifact_publisher = FredArtifactPublisher(
        binding=binding,
        settings=settings,
    )
    resource_reader = FredResourceReader(
        binding=binding,
        settings=settings,
    )
    handlers = (
        build_authored_tool_handlers(
            definition=definition,  # type: ignore[arg-type]
            toolset_key=getattr(definition, "toolset_key", None),
            binding=binding,
            settings=settings,
            ports=AuthoredToolRuntimePorts(
                chat_model_factory=runtime_config.chat_model_factory,
                artifact_publisher=artifact_publisher,
                resource_reader=resource_reader,
                fallback_tool_invoker=base_tool_invoker,
                media_fetcher=_build_media_fetcher(binding=binding, settings=settings),
            ),
        )
        if isinstance(definition, ReActAgentDefinition)
        else {}
    )
    tool_invoker = (
        CompositeToolInvoker(
            handlers=handlers,
            fallback=base_tool_invoker,
        )
        if handlers
        else base_tool_invoker
    )
    return RuntimeServices(
        tracer=build_default_tracer(),
        chat_model_factory=runtime_config.chat_model_factory,
        tool_invoker=tool_invoker,
        tool_provider=tool_provider,
        artifact_publisher=artifact_publisher,
        resource_reader=resource_reader,
        checkpointer=runtime_config.checkpointer,
    )


def _normalize_base_url(base_url: str) -> str:
    """
    Normalize the configured FastAPI base URL for router and docs mounting.

    Why this exists:
    - pod apps should honor `config.app.base_url` consistently
    - normalization avoids accidental double slashes from empty or trailing-slash
      values

    How to use it:
    - call once inside `create_agent_app(...)`

    Example:
    - `_normalize_base_url("/rags/v1/") == "/rags/v1"`
    """

    cleaned = base_url.strip()
    if not cleaned or cleaned == "/":
        return ""
    return f"/{cleaned.strip('/')}"


# ---------------------------------------------------------------------------
# Execution helpers
# ---------------------------------------------------------------------------


class _AgentExecuteRequest(BaseModel):
    """
    Input payload for the agent execution endpoints.

    Normal turn:
    ```json
    {"agent_id": "sentinel.react.v2", "message": "hello", "context": {"session_id": "..."}}
    ```

    HITL resume (message may be empty — graph resumes from the checkpointed interrupt):
    ```json
    {"agent_id": "sentinel.react.v2", "message": "", "context": {"session_id": "..."},
     "resume_payload": {"approved": true, "exchange_id": "..."}}
    ```
    """

    agent_id: str | None = Field(default=None, min_length=1)
    agent_instance_id: str | None = Field(default=None, min_length=1)
    message: str = Field(default="")
    context: dict[str, Any] | None = None
    resume_payload: Any | None = Field(
        default=None,
        description=(
            "HITL resume data returned by the caller after an AwaitingHumanRuntimeEvent. "
            "When set, the graph is resumed from its checkpointed interrupt state using "
            "LangGraph Command(resume=...) — the message field is ignored."
        ),
    )

    @model_validator(mode="after")
    def _require_message_or_resume(self) -> "_AgentExecuteRequest":
        """
        Validate the execution target and turn shape for one request.

        Why this exists:
        - the pod now supports both direct template execution (`agent_id`) and
          managed instance execution (`agent_instance_id`), but exactly one
          target must be provided

        How to use it:
        - validation runs automatically when FastAPI parses the request body

        Example:
        - `{"agent_instance_id": "uuid", "message": "hello"}`
        """

        if bool(self.agent_id) == bool(self.agent_instance_id):
            raise ValueError("Provide exactly one of agent_id or agent_instance_id")
        if self.resume_payload is None and not self.message.strip():
            raise ValueError("message is required when resume_payload is not set")
        return self


class _AgentTemplateSummary(BaseModel):
    template_agent_id: str
    title: str
    description: str
    kind: ExecutionCategory
    default_tuning: AgentTuning
    available_mcp_servers: list[MCPServerConfiguration] = Field(default_factory=list)


class _ResolvedAgentInstance(BaseModel):
    agent_instance_id: str
    template_agent_id: str
    owner_scope: str
    owner_user_id: str | None = None
    owner_team_id: str | None = None
    enabled: bool = True
    tuning: AgentTuning


@dataclass(slots=True)
class _ResolvedExecutionTarget:
    definition: ReActAgentDefinition | GraphAgentDefinition
    effective_agent_id: str
    team_id: str | None = None


def _apply_runtime_tuning(
    definition: ReActAgentDefinition | GraphAgentDefinition, tuning: AgentTuning
) -> ReActAgentDefinition | GraphAgentDefinition:
    """
    Overlay persisted business tuning onto one registered ReAct template.

    Why this exists:
    - control-plane stores the full effective tuning for a managed agent
      instance, and the pod must execute that tuning without depending on the
      old agentic-backend definition factory

    How to use it:
    - call after resolving an `agent_instance_id` from control-plane

    Example:
    - `definition = _apply_runtime_tuning(template_definition, resolution.tuning)`
    """

    return definition.model_copy(
        update={
            "role": tuning.role,
            "description": tuning.description,
            "tags": tuple(tuning.tags),
            "fields": tuple(field.model_copy(deep=True) for field in tuning.fields),
            "default_mcp_servers": tuple(
                server.model_copy(deep=True) for server in tuning.mcp_servers
            ),
        }
    )


def _available_mcp_servers_for_definition(
    definition: ReActAgentDefinition | GraphAgentDefinition,
) -> list[MCPServerConfiguration]:
    """
    Resolve the concrete MCP catalog entries referenced by one agent template.

    Why this exists:
    - the frontend create/edit flow needs user-facing MCP names and
      descriptions, not just logical server ids, when showing the tunable tool
      surface of a registered template

    How to use it:
    - call while building `/agents/templates` responses

    Example:
    - `servers = _available_mcp_servers_for_definition(definition)`
    """

    mcp_configuration = get_runtime_context().config.mcp_configuration
    if mcp_configuration is None:
        return []
    resolved: list[MCPServerConfiguration] = []
    for server_ref in definition.default_mcp_servers:
        server = mcp_configuration.get_server(server_ref.id)
        if server is not None:
            resolved.append(server)
    return resolved


async def _resolve_agent_instance(
    *,
    request: _AgentExecuteRequest,
    registry: Mapping[str, ReActAgentDefinition | GraphAgentDefinition],
    access_token: str | None,
    control_plane_url: str | None,
) -> _ResolvedExecutionTarget:
    """
    Resolve a direct or managed execution target into a concrete definition.

    Why this exists:
    - `/agents/execute*` now supports both raw template execution and managed
      agent instances stored in control-plane, while the lower runtime path
      still wants one concrete `ReActAgentDefinition`

    How to use it:
    - call from execute routes before invoking the runtime

    Example:
    - `target = await _resolve_agent_instance(...)`
    """

    if request.agent_id is not None:
        definition = registry.get(request.agent_id)
        if definition is None:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail=f"Unknown agent_id: {request.agent_id!r}. "
                f"Known agents: {list(registry.keys())}",
            )
        return _ResolvedExecutionTarget(
            definition=definition,
            effective_agent_id=definition.agent_id,
        )

    if control_plane_url is None:
        raise HTTPException(
            status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
            detail=(
                "Managed agent instances require platform.control_plane_url in the pod configuration."
            ),
        )

    url = (
        f"{control_plane_url.rstrip('/')}/agent-instances/"
        f"{request.agent_instance_id}/runtime"
    )
    headers = {"Authorization": f"Bearer {access_token}"} if access_token else None
    async with httpx.AsyncClient(timeout=10.0) as client:
        response = await client.get(url, headers=headers)
    if response.status_code == status.HTTP_404_NOT_FOUND:
        raise HTTPException(
            status_code=404, detail=response.text or "Unknown agent instance."
        )
    if response.status_code == status.HTTP_403_FORBIDDEN:
        raise HTTPException(status_code=403, detail=response.text or "Forbidden.")
    if response.status_code >= 400:
        raise HTTPException(
            status_code=status.HTTP_502_BAD_GATEWAY,
            detail=(
                f"Failed to resolve agent instance '{request.agent_instance_id}' through control-plane: "
                f"{response.text or response.reason_phrase}"
            ),
        )

    resolution = _ResolvedAgentInstance.model_validate(response.json())
    definition = registry.get(resolution.template_agent_id)
    if definition is None:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=(
                f"Resolved template_agent_id '{resolution.template_agent_id}' is not registered in this pod."
            ),
        )
    return _ResolvedExecutionTarget(
        definition=_apply_runtime_tuning(definition, resolution.tuning),
        effective_agent_id=resolution.agent_instance_id,
        team_id=resolution.owner_team_id,
    )


def _sse(payload: str) -> str:
    return f"data: {payload}\n\n"


async def _stream(
    definition: ReActAgentDefinition | GraphAgentDefinition,
    request: _AgentExecuteRequest,
    access_token: str | None = None,
    *,
    team_id: str | None = None,
) -> AsyncIterator[str]:
    """
    Execute one agent turn and yield SSE-framed RuntimeEvent JSON.

    Why this helper exists:
    - keeps the streaming FastAPI endpoint thin
    - shares the same runtime-event production path as `/agents/execute`
    """

    async for payload in _iterate_runtime_event_payloads(
        definition,
        request,
        access_token=access_token,
        team_id=team_id,
    ):
        yield _sse(json.dumps(payload, ensure_ascii=False))


async def _iterate_runtime_event_payloads(
    definition: ReActAgentDefinition | GraphAgentDefinition,
    request: _AgentExecuteRequest,
    access_token: str | None = None,
    *,
    team_id: str | None = None,
) -> AsyncIterator[dict[str, Any]]:
    """
    Execute one agent turn and yield runtime-event payloads as JSON-ready dicts.

    Why this helper exists:
    - both `/agents/execute` and `/agents/execute/stream` should share the same
      runtime wiring and event production path
    - keeping the generator payload-oriented lets the HTTP layer choose whether
      it renders SSE or returns a terminal JSON response

    access_token:
    - the user's JWT forwarded from agentic-backend via the Authorization header
    - stored in RuntimeContext so KF tool adapters can use it for outbound calls
      (same path as local agents in agentic-backend)
    - None in local dev when security is disabled
    """

    request_id = str(uuid4())
    ctx = request.context or {}
    correlation_id = ctx.get("correlation_id", request_id)
    resolved_team_id = team_id or ctx.get("team_id")

    portable_context = PortableContext(
        request_id=request_id,
        correlation_id=correlation_id,
        actor=ctx.get("user_id", "anonymous"),
        tenant=ctx.get("tenant", "default"),
        environment=PortableEnvironment.DEV,
        agent_id=definition.agent_id,
        agent_name=definition.agent_id,
        session_id=ctx.get("session_id"),
        user_id=ctx.get("user_id"),
        team_id=resolved_team_id,
    )

    runtime_context = RuntimeContext(
        session_id=ctx.get("session_id"),
        user_id=ctx.get("user_id"),
        language=ctx.get("language"),
        access_token=access_token,
    )

    binding = BoundRuntimeContext(
        runtime_context=runtime_context,
        portable_context=portable_context,
    )

    services = _build_runtime_services(definition, binding, team_id=resolved_team_id)
    if isinstance(definition, GraphAgentDefinition):
        runtime: ReActRuntime | GraphRuntime = GraphRuntime(
            definition=definition,
            services=services,
        )
    else:
        runtime = ReActRuntime(
            definition=definition,
            services=services,
        )
    runtime.bind(binding)

    # thread_id = session_id enables LangGraph checkpointing: the agent
    # resumes its graph state from the SQL checkpointer on every turn.
    # When session_id is absent (e.g. one-shot calls) thread_id=None and
    # LangGraph runs stateless — no checkpoint written or read.
    execution_config = ExecutionConfig(
        thread_id=ctx.get("session_id"),
        resume_payload=request.resume_payload,
    )

    try:
        await runtime.activate()
        executor = await runtime.get_executor()
        if isinstance(definition, GraphAgentDefinition):
            # Graph agents receive their typed input schema; the agent's
            # build_turn_state() maps it to graph state before the first node runs.
            # The standard contract is a single "message" field in the input schema.
            # On a HITL resume the runtime ignores input entirely (state is loaded
            # from the checkpoint), so bypass validation with model_construct.
            input_cls = definition.input_model()
            if request.resume_payload is not None:
                graph_input = input_cls.model_construct(message="")
            else:
                graph_input = input_cls.model_validate(
                    {"message": request.message or ""}
                )
            executor_input: ReActInput | object = graph_input
        else:
            # On HITL resume, messages are ignored by the codec — the graph
            # resumes from its checkpointed interrupt via Command(resume=...).
            # On a normal turn, the user message is the only input.
            executor_input = ReActInput(
                messages=(
                    ()
                    if request.resume_payload is not None
                    else (
                        ReActMessage(
                            role=ReActMessageRole.USER, content=request.message
                        ),
                    )
                ),
            )
        async for event in executor.stream(executor_input, execution_config):
            payload = event.model_dump(mode="json")
            if not isinstance(payload, dict):
                raise RuntimeError(
                    "RuntimeEvent payload must serialize to a JSON object."
                )
            yield payload
    except Exception as exc:
        logger.exception(
            "[fred-runtime] agent execution error agent_id=%s", definition.agent_id
        )
        yield {"error": str(exc)}
    finally:
        await runtime.dispose()


def _terminal_execute_payload(payloads: list[dict[str, Any]]) -> dict[str, Any]:
    """
    Select the terminal JSON payload returned by `/agents/execute`.

    Why this helper exists:
    - non-streaming callers want one deterministic response object
    - different runtimes may emit several intermediate events before the
      terminal outcome, so the endpoint should consistently return the final
      event when present and otherwise fall back to the last emitted payload

    How to use it:
    - pass the collected event payloads from `_iterate_runtime_event_payloads`

    Example:
    - `payload = _terminal_execute_payload(payloads)`
    """

    if not payloads:
        return {"error": "Agent execution produced no runtime events."}
    for payload in reversed(payloads):
        if payload.get("kind") == "final":
            return payload
    return payloads[-1]


# ---------------------------------------------------------------------------
# Message serializer (checkpointer → HTTP response)
# ---------------------------------------------------------------------------


def _serialize_lc_message(msg: Any) -> dict[str, Any]:
    """
    Project one LangChain BaseMessage from the checkpoint into a plain dict.

    Why this helper exists:
    - the checkpointer stores typed LangChain objects; the HTTP layer must return
      plain JSON that the UI and any client can consume without the LangChain SDK
    - keeping serialization here isolates the LangChain dependency from the route

    Shape returned per role:
    - user:      {"role": "user", "content": str}
    - assistant: {"role": "assistant", "content": str,
                  "tool_calls": [...] | None, "metadata": {...} | None}
    - tool:      {"role": "tool", "content": str,
                  "tool_call_id": str, "tool_name": str | None}
    """
    from langchain_core.messages import AIMessage, HumanMessage, ToolMessage

    content = msg.content if isinstance(msg.content, str) else str(msg.content)

    if isinstance(msg, HumanMessage):
        return {"role": "user", "content": content}

    if isinstance(msg, AIMessage):
        result: dict[str, Any] = {"role": "assistant", "content": content}
        if msg.tool_calls:
            result["tool_calls"] = [
                {"id": tc["id"], "name": tc["name"], "args": tc["args"]}
                for tc in msg.tool_calls
            ]
        if msg.response_metadata:
            result["metadata"] = msg.response_metadata
        return result

    if isinstance(msg, ToolMessage):
        return {
            "role": "tool",
            "content": content,
            "tool_call_id": msg.tool_call_id,
            "tool_name": msg.name,
        }

    # Fallback for any future message type (e.g. SystemMessage stored in state).
    return {"role": getattr(msg, "type", "unknown"), "content": content}


# ---------------------------------------------------------------------------
# Router builder
# ---------------------------------------------------------------------------


def _build_agent_router(
    registry: Mapping[str, ReActAgentDefinition | GraphAgentDefinition],
    security_enabled: bool,
) -> APIRouter:
    """
    Build the FastAPI router for agent execution.

    Why this is a function rather than a module-level router:
    - the registry is provided at app-creation time, not import time
    - each call produces an isolated router instance bound to that registry
    - security_enabled controls whether get_current_user is applied as a dependency
    """
    from fred_core.security.oidc import get_current_user

    router = APIRouter(prefix="/agents", tags=["Agents"])

    # Build the dependency list once — empty when security is off so that
    # local-dev pods start without any Keycloak configuration.
    _auth_deps = [Depends(get_current_user)] if security_enabled else []

    def _resolve_definition(
        agent_id: str,
    ) -> ReActAgentDefinition | GraphAgentDefinition:
        """
        Resolve one registered agent definition or raise a 404 HTTP error.

        Why this helper exists:
        - both execute routes should share the same lookup and error wording

        How to use it:
        - call from the route handlers after request validation

        Example:
        - `definition = _resolve_definition(request.agent_id)`
        """

        definition = registry.get(agent_id)
        if definition is None:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail=f"Unknown agent_id: {agent_id!r}. "
                f"Known agents: {list(registry.keys())}",
            )
        return definition

    @router.get("")
    async def list_agents() -> list[str]:
        """Return the agent IDs registered in this pod."""
        return list(registry.keys())

    @router.get("/templates")
    async def list_agent_templates() -> list[_AgentTemplateSummary]:
        """
        Return the executable agent templates registered in this pod.

        Why this endpoint exists:
        - control-plane business admin flows need a read-only catalog of
          executable templates without exposing runtime CRUD or class-path
          authoring

        How to use it:
        - call from control-plane to aggregate template metadata across pods

        Example:
        - `GET /fred/agents/v2/agents/templates`
        """

        return [
            _AgentTemplateSummary(
                template_agent_id=definition.agent_id,
                title=definition.role,
                description=definition.description,
                kind=definition.execution_category,
                default_tuning=_definition_to_agent_tuning(definition),
                available_mcp_servers=_available_mcp_servers_for_definition(definition),
            )
            for definition in registry.values()
        ]

    @router.get("/sessions/{session_id}/messages", dependencies=_auth_deps)
    async def get_session_messages(session_id: str) -> list[dict[str, Any]]:
        """
        Return the conversation history for a session as a flat message list.

        GET <configured base_url>/agents/sessions/{session_id}/messages
        Authorization: Bearer <user JWT> (same auth as execute endpoints)
        Response: JSON array of message objects keyed by role/content/metadata.

        Why the checkpointer is the source of truth:
        - LangGraph accumulates the full message list in the `messages` channel of
          the graph state, persisted by the SQL checkpointer on every turn.
        - No separate history write is needed — the checkpoint IS the history.
        - Returns [] when the session has no checkpoint (new or stateless session).
        """
        checkpointer = get_runtime_context().config.checkpointer
        if checkpointer is None:
            raise HTTPException(
                status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
                detail="No checkpointer configured — session history is unavailable.",
            )
        lc_config = {"configurable": {"thread_id": session_id, "checkpoint_ns": ""}}
        checkpoint_tuple = await checkpointer.aget_tuple(lc_config)  # type: ignore[arg-type]
        if checkpoint_tuple is None:
            return []
        messages = checkpoint_tuple.checkpoint.get("channel_values", {}).get(
            "messages", []
        )
        return [_serialize_lc_message(m) for m in messages]

    @router.post("/execute", dependencies=_auth_deps)
    async def execute(
        request: _AgentExecuteRequest, http_request: Request
    ) -> JSONResponse:
        """
        Execute one agent turn and return the terminal RuntimeEvent as JSON.

        POST <configured base_url>/agents/execute
        Authorization: Bearer <user JWT forwarded from agentic-backend>
        Body: {"agent_id": "...", "message": "...", "context": {...}}
        Response: application/json containing the terminal runtime payload

        The Bearer token is the user's Keycloak JWT forwarded by agentic-backend.
        It is stored in RuntimeContext.access_token so KF tool adapters can use it
        for outbound calls — the same pattern as local agents in agentic-backend.
        """

        auth = http_request.headers.get("Authorization", "")
        access_token = auth.removeprefix("Bearer ").strip() or None
        target = await _resolve_agent_instance(
            request=request,
            registry=registry,
            access_token=access_token,
            control_plane_url=get_runtime_context().config.control_plane_url,
        )
        payloads = [
            payload
            async for payload in _iterate_runtime_event_payloads(
                target.definition,
                request,
                access_token=access_token,
                team_id=target.team_id,
            )
        ]
        return JSONResponse(_terminal_execute_payload(payloads))

    @router.post("/execute/stream", dependencies=_auth_deps)
    async def execute_stream(
        request: _AgentExecuteRequest, http_request: Request
    ) -> StreamingResponse:
        """
        Stream RuntimeEvent JSON over SSE for a single agent invocation.

        POST <configured base_url>/agents/execute/stream
        Authorization: Bearer <user JWT forwarded from agentic-backend>
        Body: {"agent_id": "...", "message": "...", "context": {...}}
        Response: text/event-stream, each `data:` line is a RuntimeEvent JSON

        The Bearer token is the user's Keycloak JWT forwarded by agentic-backend.
        It is stored in RuntimeContext.access_token so KF tool adapters can use it
        for outbound calls — the same pattern as local agents in agentic-backend.
        """
        auth = http_request.headers.get("Authorization", "")
        access_token = auth.removeprefix("Bearer ").strip() or None
        target = await _resolve_agent_instance(
            request=request,
            registry=registry,
            access_token=access_token,
            control_plane_url=get_runtime_context().config.control_plane_url,
        )
        return StreamingResponse(
            _stream(
                target.definition,
                request,
                access_token=access_token,
                team_id=target.team_id,
            ),
            media_type="text/event-stream",
        )

    return router


# ---------------------------------------------------------------------------
# Public factory
# ---------------------------------------------------------------------------


def create_agent_app(
    registry: Mapping[str, ReActAgentDefinition | GraphAgentDefinition],
    config: AgentPodConfig,
    extra_routers: list[APIRouter] | None = None,
) -> FastAPI:
    """
    Create a ready-to-serve FastAPI app for a Fred agent pod.

    Why this exists:
    - every agent pod needs the same execution endpoints, RuntimeConfig wiring,
      lifespan hook, and security middleware — this factory provides all of it
      so pods contain zero infrastructure code

    How to use it:
    - call from your pod's `main.py` after loading your config
    - security is taken from `config.security` — no separate parameter needed

    Example:
    ```python
    from fred_runtime.app import create_agent_app, load_agent_pod_config
    from myapp.agents.registry import REGISTRY

    config = load_agent_pod_config()
    app = create_agent_app(registry=REGISTRY, config=config)
    ```

    Parameters:
    - registry: maps agent_id → ReActAgentDefinition; built at startup, read-only
    - config: AgentPodConfig loaded from `config/configuration.yaml`
    - extra_routers: additional APIRouter instances mounted under `config.app.base_url`

    Security (from config.security):
    - when `config.security.user.enabled` is True:
        - initializes Keycloak JWT validation (initialize_user_security)
        - adds Depends(get_current_user) to POST /agents/execute and
          POST /agents/execute/stream
    - `config.security.authorized_origins` controls CORS (when non-empty)
    - routes, docs, and OpenAPI are mounted under `config.app.base_url`
    """

    security = config.security
    base_url = _normalize_base_url(config.app.base_url)
    user_security = security.user if security is not None else None
    security_enabled: bool = (
        user_security.enabled if user_security is not None else False
    )
    authorized_origins: list[str] = (
        [str(o).rstrip("/") for o in security.authorized_origins]
        if security is not None and security.authorized_origins
        else []
    )

    @asynccontextmanager
    async def lifespan(app: FastAPI):
        # --- Observability bootstrap ---
        # Must happen first so every subsequent logger call uses the correct
        # formatter, handlers (Rich + StoreEmitHandler), and noisy-lib filters —
        # the same stack that agentic-backend uses via the same log_setup call.
        log_setup(
            service_name=config.app.name,
            log_level=config.app.log_level,
            store=RamLogStore(),
        )
        # Bootstrap the global tracer and metrics provider from pod config.
        # The backend (logging, null, langfuse, …) is declared in configuration.yaml.
        # Credentials stay in .env.
        bootstrap_observability(config.observability)

        # Initialize Keycloak inbound validation before any request is handled.
        if security_enabled and user_security is not None:
            from fred_core.security.oidc import initialize_user_security

            initialize_user_security(user_security)

        chat_factory = _build_chat_model_factory(config)

        # SQL checkpointer — always initialized from config.storage.postgres.
        # Uses SQLite (via aiosqlite) when no Postgres host is set (local dev).
        # Uses asyncpg Postgres in production.
        # Provides durable LangGraph session state keyed by session_id.
        sql_engine = None
        checkpointer = None
        try:
            from fred_core.sql.base_sql import create_async_engine_from_config

            from ..runtime_support.sql_checkpointer import FredSqlCheckpointer

            sql_engine = create_async_engine_from_config(config.storage.postgres)
            checkpointer = FredSqlCheckpointer(sql_engine)
            logger.info(
                "[fred-runtime] SQL checkpointer ready (dialect=%s)",
                sql_engine.dialect.name,
            )
        except Exception:
            logger.exception(
                "[fred-runtime] Failed to initialize SQL checkpointer — running stateless"
            )

        # MCP catalog — resolved during config bootstrap from `mcp_catalog.yaml`
        # and attached internally to the typed pod config.
        mcp_configuration = config.get_mcp_configuration()

        runtime_config = RuntimeConfig(
            knowledge_flow_url=config.ai.knowledge_flow_url,
            timeouts=config.ai.timeout,
            chat_model_factory=chat_factory,
            checkpointer=checkpointer,
            mcp_configuration=mcp_configuration,
            control_plane_url=config.platform.control_plane_url,
        )
        set_runtime_context(FredRuntimeContext(runtime_config))
        logger.info(
            "[fred-runtime] agent pod started — base_url=%s kf=%s security=%s checkpointer=%s agents=%s",
            base_url or "/",
            config.ai.knowledge_flow_url,
            "enabled" if security_enabled else "disabled",
            "sql" if checkpointer is not None else "none",
            list(registry.keys()),
        )
        yield

        # Graceful shutdown — dispose the SQL engine connection pool.
        if sql_engine is not None:
            await sql_engine.dispose()
            logger.info("[fred-runtime] SQL engine disposed")

    app = FastAPI(
        title=config.app.name,
        version="0.1.0",
        docs_url=f"{base_url}/docs" if base_url else "/docs",
        redoc_url=f"{base_url}/redoc" if base_url else "/redoc",
        openapi_url=f"{base_url}/openapi.json" if base_url else "/openapi.json",
        lifespan=lifespan,
    )

    # CORS — only added when security is provided so local-dev pods stay simple.
    if authorized_origins:
        app.add_middleware(
            CORSMiddleware,
            allow_origins=authorized_origins,
            allow_methods=["GET", "POST"],
            allow_headers=["Content-Type", "Authorization"],
        )
        logger.debug("[fred-runtime] CORS allow_origins=%s", authorized_origins)

    api_router = APIRouter(prefix=base_url)
    api_router.include_router(
        _build_agent_router(registry, security_enabled=security_enabled)
    )

    for extra in extra_routers or []:
        api_router.include_router(extra)

    app.include_router(api_router)
    return app
