"""Shared Link release version."""
from __future__ import annotations

LINK_VERSION = "1.1.0"
