# Changes

## v1.2.0

Release date: 2026-05-19

### Breaking changes

* `Connection.ping()` change the default to not reconnect and deprecate `reconnect` argument.
  Create a new connection if you want to reconnect. (#1241)

* Error classes in Cursor class are removed. (#1240)

* `connect()` arguments `db` and `passwd` now emit DeprecationWarning.
  Use `database` and `password` instead. (#1240)

* Reorganize TLS connection behavior.

  * PyMySQL uses TLS by default when server supports it.
    Use `ssl_disabled=True` to prohibit SSL. (#1213)

  * When `ssl_verify_cert=True`, `ssl_verify_identity=True`, an `ssl.SSLContext` is passed,
    or when any other SSL option is configured, the connection **requires** SSL and raises
    `OperationalError` (CR_SSL_CONNECTION_ERROR) if the server doesn't support it. (#1234)

### Other changes

* Support MySQL 8 row/column alias syntax in `executemany` INSERT regex. (#1235)
* Expose SQLSTATE on MySQL protocol exceptions without changing exception formatting. (#1236)
* Reject non-finite `decimal.Decimal` query parameters (`NaN`, `sNaN`, `±Infinity`). (#1237)
* `Connection.set_charset(charset)` now emits `DeprecationWarning`.


## v1.1.3

Release date: 2026-05-01

### Security

* Fix `Cursor.callproc()` didn't escape procedure name. (#1206)
  There was a possibility of SQL injection when calling a procedure with a string received from an untrusted source as the procedure name.

  NOTICE: This change may cause backward compatibility issues. If you specified a procedure name like `"dbname.funcname"`, the previous version called `CALL dbname.funcname`, but from this version, it will call ``CALL `dbname.funcname` `` so you cannot specify procedure name with database name anymore.

## v1.1.2

Release date: 2025-08-24

* Prevent UnboundLocalError in very rare situation. https://github.com/PyMySQL/PyMySQL/pull/1174
* Close underlying `SocketIO` soon when Connection is closed for PyPy. https://github.com/PyMySQL/PyMySQL/issues/1183
* Fix importing PyMySQL fail on CPython 3.13 when `getpass.getuser()` raises OSEError. https://github.com/PyMySQL/PyMySQL/pull/1190
* Make charset name "utf8" case insensitive. https://github.com/PyMySQL/PyMySQL/pull/1195
* `Connection.kill()` uses `KILL` query instead of `COM_KILL`command to support MySQL 8.4. https://github.com/PyMySQL/PyMySQL/pull/1197
* Fix SSL error on CPython 3.13 caused by strict TLS default setting. https://github.com/PyMySQL/PyMySQL/pull/1198
* Fix auth switch request handling. https://github.com/PyMySQL/PyMySQL/pull/1200


## v1.1.1

Release date: 2024-05-21

> [!WARNING]
> This release fixes a vulnerability (CVE-2024-36039).
> All users are recommended to update to this version.
>
> If you can not update soon, check the input value from
> untrusted source has an expected type. Only dict input
> from untrusted source can be an attack vector.

* Prohibit dict parameter for `Cursor.execute()`. It didn't produce valid SQL
  and might cause SQL injection. (CVE-2024-36039)
* Added ssl_key_password param. #1145

## v1.1.0

Release date: 2023-06-26

* Fixed SSCursor raising OperationalError for query timeouts on wrong statement (#1032)
* Exposed `Cursor.warning_count` to check for warnings without additional query (#1056)
* Make Cursor iterator (#995)
* Support '_' in key name in my.cnf (#1114)
* `Cursor.fetchall()` returns empty list instead of tuple (#1115). Note that `Cursor.fetchmany()` still return empty tuple after reading all rows for compatibility with Django.
* Deprecate Error classes in Cursor class (#1117)
* Add `Connection.set_character_set(charset, collation=None)`. This method is compatible with mysqlclient. (#1119)
* Deprecate `Connection.set_charset(charset)` (#1119)
* New connection always send "SET NAMES charset [COLLATE collation]" query. (#1119)
  Since collation table is vary on MySQL server versions, collation in handshake is fragile.
* Support `charset="utf8mb3"` option (#1127)


## v1.0.3

Release date: 2023-03-28

* Dropped support of end of life MySQL version 5.6
* Dropped support of end of life MariaDB versions below 10.3
* Dropped support of end of life Python version 3.6
* Removed `_last_executed` because of duplication with `_executed` by @rajat315315 in https://github.com/PyMySQL/PyMySQL/pull/948
* Fix generating authentication response with long strings by @netch80 in https://github.com/PyMySQL/PyMySQL/pull/988
* update pymysql.constants.CR by @Nothing4You in https://github.com/PyMySQL/PyMySQL/pull/1029
* Document that the ssl connection parameter can be an SSLContext by @cakemanny in https://github.com/PyMySQL/PyMySQL/pull/1045
* Raise ProgrammingError on -np.inf in addition to np.inf by @cdcadman in https://github.com/PyMySQL/PyMySQL/pull/1067
* Use Python 3.11 release instead of -dev in tests by @Nothing4You in https://github.com/PyMySQL/PyMySQL/pull/1076


## v1.0.2

Release date: 2021-01-09

* Fix `user`, `password`, `host`, `database` are still positional arguments.
  All arguments of `connect()` are now keyword-only. (#941)


## v1.0.1

Release date: 2021-01-08

* Stop emitting DeprecationWarning for use of ``db`` and ``passwd``.
  Note that they are still deprecated. (#939)
* Add ``python_requires=">=3.6"`` to setup.py. (#936)


## v1.0.0

Release date: 2021-01-07

Backward incompatible changes:

* Python 2.7 and 3.5 are not supported.
* ``connect()`` uses keyword-only arguments. User must use keyword argument.
* ``connect()`` kwargs ``db`` and ``passwd`` are now deprecated; Use ``database`` and ``password`` instead.
* old_password authentication method (used by MySQL older than 4.1) is not supported.
* MySQL 5.5 and MariaDB 5.5 are not officially supported, although it may still works.
* Removed ``escape_dict``, ``escape_sequence``, and ``escape_string`` from ``pymysql``
  module. They are still in ``pymysql.converters``.

Other changes:

* Connection supports context manager API. ``__exit__`` closes the connection. (#886)
* Add MySQL Connector/Python compatible TLS options (#903)
* Major code cleanup; PyMySQL now uses black and flake8.


## v0.10.1

Release date: 2020-09-10

* Fix missing import of ProgrammingError. (#878)
* Fix auth switch request handling. (#890)


## v0.10.0

Release date: 2020-07-18

This version is the last version supporting Python 2.7.

* MariaDB ed25519 auth is supported.
* Python 3.4 support is dropped.
* Context manager interface is removed from `Connection`. It will be added
  with different meaning.
* MySQL warnings are not shown by default because many user report issue to
  PyMySQL issue tracker when they see warning. You need to call "SHOW WARNINGS"
  explicitly when you want to see warnings.
* Formatting of float object is changed from "3.14" to "3.14e0".
* Use cp1252 codec for latin1 charset.
* Fix decimal literal.
* TRUNCATED_WRONG_VALUE_FOR_FIELD, and ILLEGAL_VALUE_FOR_TYPE are now
  DataError instead of InternalError.


## 0.9.3

Release date: 2018-12-18

* cryptography dependency is optional now.
* Fix old_password (used before MySQL 4.1) support.
* Deprecate old_password.
* Stop sending ``sys.argv[0]`` for connection attribute "program_name".
* Close connection when unknown error is happened.
* Deprecate context manager API of Connection object.

## 0.9.2

Release date: 2018-07-04

* Disabled unintentinally enabled debug log
* Removed unintentionally installed tests


## 0.9.1

Release date: 2018-07-03

* Fixed caching_sha2_password and sha256_password raise TypeError on PY2
  (#700, #702)


## 0.9.0

Release date: 2018-06-27

* Change default charset from latin1 to utf8mb4.  (because MySQL 8 changed) (#692)
* Support sha256_password and caching_sha2_password auth method (#682)
* Add cryptography dependency, because it's needed for new auth methods.
* Remove deprecated `no_delay` option (#694)
* Support connection attributes (#679)
* Map LOCK_DEADLOCK to OperationalError (#693)

## 0.8.1

Release date: 2018-05-07

* Reduce `cursor.callproc()` roundtrip time. (#636)

* Fixed `cursor.query()` is hunged after multi statement failed. (#647)

* WRONG_DB_NAME and WRONG_COLUMN_NAME is ProgrammingError for now. (#629)

* Many test suite improvements, especially adding MySQL 8.0 and using Docker.
  Thanks to Daniel Black.

* Dropped support for old Python and MySQL which is not tested long time.


## 0.8

Release date: 2017-12-20

* **BACKWARD INCOMPATIBLE** ``binary_prefix`` option is added and off
  by default because of compatibility with mysqlclient.
  When you need PyMySQL 0.7 behavior, you have to pass ``binary_prefix=True``.
  (#549)

* **BACKWARD INCOMPATIBLE** ``MULTI_STATEMENTS`` client flag is no longer
  set by default, while it was on PyMySQL 0.7.  You need to pass
  ``client_flag=CLIENT.MULTI_STATEMENTS`` when you connect to explicitly
  enable multi-statement mode. (#590)

* Fixed AuthSwitch packet handling.

* Raise OperationalError for MariaDB's constraint error. (#607)

* executemany() accepts query without space between ``VALUES`` and ``(``.  (#597)

* Support config file containing option without value. (#588)

* Fixed Connection.ping() returned unintended value.


## 0.7.11

Release date: 2017-04-06

* Fixed Connection.close() failed when failed to send COM_CLOSE packet.
* Cursor.executemany() accepts query ends with semicolon.
* ssl parameters can be read from my.cnf.


## 0.7.10

Release date: 2017-02-14

* **SECURITY FIX**: Raise RuntimeError when received LOAD_LOCAL packet while
  ``loacal_infile=False``.  (Thanks to Bryan Helmig)

* Raise SERVER_LOST error for MariaDB's shutdown packet (#540)

* Change default connect_timeout to 10.

* Add bind_address option (#529)


## 0.7.9

Release date: 2016-09-03

* Fix PyMySQL stop reading rows when first column is empty string (#513)
  Reverts DEPRECATE_EOF introduced in 0.7.7.

## 0.7.8

Release date: 2016-09-01

* Revert error message change in 0.7.7.
  (SQLAlchemy parses error message, #507)

## 0.7.7

Release date: 2016-08-30

* Add new unicode collation (#498)
* Fix conv option is not used for encoding objects.
* Experimental support for DEPRECATE_EOF protocol.

## 0.7.6

Release date: 2016-07-29

* Fix SELECT JSON type cause UnicodeError
* Avoid float conversion while parsing microseconds
* Warning has number
* SSCursor supports warnings

## 0.7.5

Release date: 2016-06-28

* Fix exception raised while importing when getpwuid() fails (#472)
* SSCursor supports LOAD DATA LOCAL INFILE (#473)
* Fix encoding error happen for JSON type (#477)
* Fix test fail on Python 2.7 and MySQL 5.7 (#478)

## 0.7.4

Release date: 2016-05-26

* Fix AttributeError may happen while Connection.__del__ (#463)
* Fix SyntaxError in test_cursor. (#464)
* frozenset support for query value. (#461)
* Start using readthedocs.io

## 0.7.3

Release date: 2016-05-19

* Add read_timeout and write_timeout option.
* Support serialization customization by `conv` option.
* Unknown type is converted by `str()`, for MySQLdb compatibility.
* Support '%%' in `Cursor.executemany()`
* Support REPLACE statement in `Cursor.executemany()`
* Fix handling incomplete row caused by 'SHOW SLAVE HOSTS'.
* Fix decode error when use_unicode=False on PY3
* Fix port option in my.cnf file is ignored.


## 0.7.2

Release date: 2016-02-24

* Fix misuse of `max_allowed_packet` parameter. (#426, #407 and #397)
* Add %(name)s plceholder support to `Cursor.executemany()`. (#427, thanks to
  @WorldException)

## 0.7.1

Release date: 2016-01-14

* Fix auth fail with MySQL 5.1
* Fix escaping unicode fails on Python 2

## 0.7

Release date: 2016-01-10

* Faster binary escaping
* Add `"_binary" prefix` to string literal for binary types.
  binary types are: `bytearray` on Python 2, `bytes` and `bytearray` on Python 3.
  This is because recent MySQL show warnings when string literal is invalid for
  connection encoding.
* `pymysql.Binary()` returns `bytearray` on Python 2.  This is required to distinguish
  binary and string.
* Auth plugin support.
* no_delay option is ignored.  It will be removed in PyMySQL 0.8.


## 0.6.7

Release date: 2015-09-30

* Allow self signed certificate
* Add max_allowed_packet option
* Fix error when bytes in executemany
* Support geometry type
* Add coveralls badge to README
* Fix some bugs relating to warnings
* Add Cursor.mogrify() method
* no_delay option is deprecated and True by default
* Fix options from my.cnf overrides options from arguments
* Allow socket like object.  (It's not feature for end users)
* Strip quotes while reading options from my.cnf file
* Fix encoding issue in executemany()

## 0.6.6

* Add context manager to cursor
* Fix can't encode blob that is not utf-8 on PY3. (regression of 0.6.4,
  Thanks to @wiggzz)

## 0.6.5
Skipped

## 0.6.4
* Support "LOAD LOCAL INFILE".  Thanks @wraziens
* Show MySQL warnings after execute query.
* Fix MySQLError may be wrapped with OperationalError while connectiong. (#274)
* SSCursor no longer attempts to expire un-collected rows within __del__,
  delaying termination of an interrupted program; cleanup of uncollected
  rows is left to the Connection on next execute, which emits a
  warning at that time. (#287)
* Support datetime and time with microsecond. (#303)
* Use surrogateescape to format bytes on Python 3.
* OperationalError raised from connect() have information about original
  exception. (#304)
* `init_command` now support multi statement.
* `Connection.escape()` method now accepts second argument compatible to
  MySQL-Python.

## 0.6.3
* Fixed multiple result sets with SSCursor.
* Fixed connection timeout.
* Fixed literal set syntax to work on Py2.6.
* Allow for mysql negative values with 0 hour timedelta.
* Added Connection.begin().

## 0.6.2
* Fixed old password on Python 3.
* Added support for bulk insert in Cursor.executemany().
* Added support for microseconds in datetimes and dates before 1900.
* Several other bug fixes.

## 0.6.1
* Added cursor._last_executed for MySQLdb compatibility
* Cursor.fetchall() and .fetchmany now return list, not tuple
* Allow "length of auth-plugin-data" = 0
* Cursor.connection references connection object without weakref

## 0.6
* Improved Py3k support
* Improved PyPy support
* Added IPv6 support
* Added Thing2Literal for Django/MySQLdb compatibility
* Removed errorhandler
* Fixed GC errors
* Improved test suite
* Many bug fixes
* Many performance improvements

## 0.4
* Miscellaneous bug fixes
* Implementation of SSL support
* Implementation of kill()
* Cleaned up charset functionality
* Fixed BIT type handling
* Connections raise exceptions after they are close()'d
* Full Py3k and unicode support

## 0.3
* Implemented most of the extended DBAPI 2.0 spec including callproc()
* Fixed error handling to include the message from the server and support
  multiple protocol versions.
* Implemented ping()
* Implemented unicode support (probably needs better testing)
* Removed DeprecationWarnings
* Ran against the MySQLdb unit tests to check for bugs
* Added support for client_flag, charset, sql_mode, read_default_file,
  use_unicode, cursorclass, init_command, and connect_timeout.
* Refactoring for some more compatibility with MySQLdb including a fake
  pymysql.version_info attribute.
* Now runs with no warnings with the -3 command-line switch
* Added test cases for all outstanding tickets and closed most of them.
* Basic Jython support added.
* Fixed empty result sets bug.
* Integrated new unit tests and refactored the example into one.
* Fixed bug with decimal conversion.
* Fixed string encoding bug. Now unicode and binary data work!
* Added very basic docstrings.

## 0.2
* Changed connection parameter name 'password' to 'passwd'
  to make it more plugin replaceable for the other mysql clients.
* Changed pack()/unpack() calls so it runs on 64 bit OSes too.
* Added support for unix_socket.
* Added support for no password.
* Renamed decorders to decoders.
* Better handling of non-existing decoder.
