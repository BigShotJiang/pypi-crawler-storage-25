# Registry-Runtime Integration Guide

This guide explains how to connect the PyGubernator control plane (API/UI) with the Python agent runtime, enabling a turnkey workflow where agents registered in the API can be instantiated and executed with automatic observability.

## Overview

The integration consists of three main components:

1. **Registry** (API/UI): Register agents, versions, and create runs
2. **Factory**: Build agent instances from stored `AgentVersion` records
3. **Runners**: Execute agents with automatic `run_id` threading and database persistence

## Prerequisites

Install the required extras:

```bash
pip install "pygubernator[api,workflow]"
```

The `api` extra includes SQLAlchemy, Alembic, and the PostgreSQL driver (`psycopg2-binary`).

## Workflow

### 1. Register Agent and Version

First, register your agent in the control plane:

```python
from pygubernator.client import ControlPlaneClient

async with ControlPlaneClient("http://localhost:8010", token="your-token") as client:
    # Create agent
    agent = await client.create_agent(
        name="my-llm-agent",
        owner="team-data",
        status="active"
    )
    agent_id = agent["id"]

    # Create version with model, prompt, tools, config
    version = await client.create_agent_version(
        agent_id=agent_id,
        version="1.0.0",
        model="gpt-4o-mini",
        prompt="You are a helpful assistant.",
        tools={
            "search": {
                "module": "my_tools",
                "function": "search_tool"
            }
        },
        config={
            "max_iterations": 5
        }
    )
    version_id = version["id"]

    # Activate the version
    await client.activate_version(agent_id, version_id)
```

Or use the HTTP API directly:

```bash
TOKEN=$(curl -s -X POST http://localhost:8010/api/v1/auth/login \
  -H "Content-Type: application/json" \
  -d '{"username":"admin","password":"changeme"}' | python -c 'import json,sys; print(json.load(sys.stdin)["access_token"])')

curl -X POST http://localhost:8010/api/v1/agents \
  -H "Authorization: Bearer $TOKEN" \
  -H "Content-Type: application/json" \
  -d '{"name": "my-llm-agent", "owner": "team-data"}'
```

Fetch agent + versions in one call:

```bash
curl http://localhost:8010/api/v1/agents/$AGENT_ID/dashboard \
  -H "Authorization: Bearer $TOKEN"
```

### 2. Create a Run

Create a run record (queued status):

```python
run = await client.create_run(
    agent_id=agent_id,
    agent_version_id=version_id,
    correlation_id="correlation-123",
    trigger="manual",
    metadata_json={"source": "integration-test"}
)
run_id = run["id"]
```

When you already have ``agent_id`` in context, prefer ``ControlPlaneClient.enqueue_run`` so the JSON body omits it:

```python
run = await client.enqueue_run(
    agent_id=agent_id,
    agent_version_id=version_id,
    trigger="manual",
)
```

### 3. Build Agent from Version

Use the factory to create an agent instance from the stored version:

```python
from pygubernator.spec import create_llm_agent_from_version
from pygubernator.llm._provider import LiteLLMProvider
from pygubernator.db.session import SessionLocal
from pygubernator.db.models import AgentVersion

# Load version from database
db = SessionLocal()
try:
    version = db.get(AgentVersion, version_id)
finally:
    db.close()

# Create agent from version
agent = create_llm_agent_from_version(
    version=version,
    llm_provider_factory=lambda m: LiteLLMProvider(model=m or "gpt-4o-mini"),
    run_id=run_id
)
```

### 4. Execute with Database Integration

Use the convenience helpers that automatically manage run lifecycle:

```python
from pygubernator.runners import run_batch_with_db
from pygubernator.transport import InMemoryTransport
from pygubernator.db.session import SessionLocal

transport = InMemoryTransport()
await transport.publish("input", Message(payload={"content": "Hello"}))

result = await run_batch_with_db(
    agent=agent,
    transport=transport,
    topic="input",
    db_session_factory=SessionLocal,
    agent_id=agent_id,
    agent_version_id=version_id,
    max_messages=10,
    correlation_id="correlation-123"
)
```

The `run_batch_with_db` helper:
- Creates a Run record (if not already created)
- Sets `run_id` on the agent
- Attaches `DatabaseEventHandler` to persist events
- Updates run status (queued → running → succeeded/failed)
- Handles errors and updates run status

## Two Patterns

### Pattern 1: Shared Database (In-Process)

When your worker shares database access with the API:

```python
from pygubernator.db.session import SessionLocal
from pygubernator.runners import run_stream_with_db

# Use run_stream_with_db or run_batch_with_db
result = await run_stream_with_db(
    agent=agent,
    transport=transport,
    topic="input",
    db_session_factory=SessionLocal,
    agent_id=agent_id,
    agent_version_id=version_id
)
```

**Benefits:**
- Automatic run lifecycle management
- Events automatically persisted to database
- UI shows runs and events in real-time

### Pattern 2: HTTP-Only (Separate Worker)

When your worker only has HTTP access:

```python
from pygubernator.client import ControlPlaneClient
from pygubernator.runners import run_stream

# Create run via HTTP
async with ControlPlaneClient(api_url, token=token) as client:
    run = await client.create_run(agent_id=agent_id)
    run_id = run["id"]

# Execute with run_id
result = await run_stream(
    agent=agent,
    transport=transport,
    topic="input",
    run_id=run_id
)

# Post events via HTTP (optional, if you want observability)
await client.post_event(
    run_id=run_id,
    event_type="run.completed",
    level="info",
    message="Run completed successfully"
)
```

**Benefits:**
- No database dependency in worker
- Works across network boundaries
- Can scale workers independently

## Tool Loading

The factory supports loading tools from `AgentVersion.tools` dict. Tools can be specified as references:

```python
tools = {
    "search": {
        "module": "my_package.tools",
        "function": "search_function"
    },
    "validate": {
        "module": "my_package.tools",
        "function": "validate_data"
    }
}
```

The factory will:
1. Import the module
2. Get the function
3. Register it in the `ToolRegistry`

Tools must implement the `Tool` protocol (have `name`, `description`, `parameters_schema`, and `execute` method).

## Run ID Threading

When `run_id` is set on an agent (via constructor or `set_run_id()`), all events emitted by the agent automatically include the `run_id`. This enables:

- Automatic correlation of events to runs
- `DatabaseEventHandler` to persist events
- UI to show complete traces

The `run_id` flows through:
1. Agent constructor or `set_run_id()`
2. `_emit()` automatically includes it
3. All `AgentEvent` instances have `run_id`
4. `DatabaseEventHandler` persists events with `run_id`

## Configuration

### Agent Version Config

The `AgentVersion.config` dict can contain:

- `max_iterations`: Maximum think-act-observe iterations for LLM agents
- Other config values are passed through (extensible)

### Environment Variables

Set `PYGUBERNATOR_DATABASE_URL` for database connection:

```bash
export PYGUBERNATOR_DATABASE_URL="sqlite:///./pygubernator.db"
# or
export PYGUBERNATOR_DATABASE_URL="postgresql://user:pass@localhost/pygubernator"
```

See also **[Run lifecycle](run-lifecycle.md)** for HTTP vs DB patterns and `run_id` threading.

## Examples

See the repository **`examples/`** directory for complete examples:
- `observable_pipeline.py` - Pipeline with event bus
- `llm_data_pipeline.py` - LLM agent with tools

## Troubleshooting

### Events not appearing in database

- Ensure `run_id` is set on the agent
- Verify `DatabaseEventHandler` is attached to the event bus
- Check that `event.run_id` is not None (DatabaseEventHandler skips events without run_id)

### Tool loading fails

- Verify tool module path is correct
- Ensure tool function exists and implements `Tool` protocol
- Check import errors in logs

### Run status not updating

- Ensure `run_stream_with_db` or `run_batch_with_db` is used
- Check database connection
- Verify run record exists before execution
