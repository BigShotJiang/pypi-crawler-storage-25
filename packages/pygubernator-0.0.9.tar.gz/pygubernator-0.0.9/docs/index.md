# PyGubernator documentation

**PyGubernator** is a general-purpose Python **agent** framework with [**pystator**](https://pypi.org/project/pystator/) integration: lifecycle state machines, LLM agents with tools, workflows, Kafka or in-memory transport, and batch/stream runners. An optional **control plane** (FastAPI + SQLAlchemy + UI) manages agents, runs, and observability.

## Where to start

| If you want to… | Read |
|-----------------|------|
| Install and choose extras | [Installation](getting-started/installation.md) |
| Run agents and transports quickly | [Quick start](getting-started/quickstart.md) |
| Wire the API registry to Python runners | [Registry ↔ runtime integration](guides/integration.md) |
| Understand runs, `run_id`, and persistence | [Run lifecycle](guides/run-lifecycle.md) |
| API / UI observability contracts | [Observability guides](guides/observability-api-contract.md) |
| Error types and codes | [Errors (API reference)](api/errors.md) |

## Default local ports

Defined in `pygubernator.config.ports` (overridable via `PYGUBERNATOR_*` / `pygubernator.cfg`):

| Service | Port |
|---------|------|
| Control-plane API (`pygubernator api`) | **8010** |
| UI dev / serve (`pygubernator ui dev` / `serve`) | **3010** |
| This documentation site (`pygubernator docs serve`) | **5010** |

## Build the docs locally

From a checkout with dev (or `[docs]`) dependencies:

```bash
pip install -e ".[dev]"
pygubernator docs serve
# or: mkdocs serve -a 127.0.0.1:5010
```

Static output: `pygubernator docs build` → `site/`.

## Repository links

- [README](https://github.com/optophi/pygubernator#readme) — install, features, development
- [Contributing](https://github.com/optophi/pygubernator/blob/main/CONTRIBUTING.md) — tests, Ruff, PRs
