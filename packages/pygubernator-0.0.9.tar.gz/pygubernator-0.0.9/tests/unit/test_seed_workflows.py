from __future__ import annotations

from pathlib import Path

import pytest
import yaml

from pygubernator.db.base import Base, get_engine
from pygubernator.db.cli import _seed_workflows
from pygubernator.workflow.config._loader import WorkflowLoader


def _seed_dir() -> Path:
    return (
        Path(__file__).resolve().parents[2] / "src" / "pygubernator" / "data" / "seed"
    )


def test_all_seed_yaml_files_validate() -> None:
    seed_path = _seed_dir()
    if not seed_path.exists():
        pytest.skip("seed directory not found")

    loader = WorkflowLoader()
    files = sorted(seed_path.glob("*.yaml")) + sorted(seed_path.glob("*.yml"))
    assert files, "no workflow seed files found"

    for p in files:
        data = yaml.safe_load(p.read_text(encoding="utf-8"))
        assert data is not None, f"{p.name} empty"
        items = data if isinstance(data, list) else [data]
        for idx, item in enumerate(items):
            assert isinstance(item, dict), f"{p.name}[{idx}] not a mapping"
            loader.load_dict(item)


def test_db_seed_skips_existing_versions(tmp_path: Path) -> None:
    # Prepare an empty DB with tables.
    db_url = f"sqlite:///{tmp_path / 'seed.db'}"
    engine = get_engine(db_url)
    # Ensure models are imported so metadata is complete.
    import pygubernator.db.models  # noqa: F401

    Base.metadata.create_all(engine)

    seed_path = _seed_dir()
    assert seed_path.exists()

    # First run: create.
    rc1 = _seed_workflows(seed_path, db_url)
    assert rc1 == 0

    # Second run: should skip (not overwrite) and still succeed.
    rc2 = _seed_workflows(seed_path, db_url)
    assert rc2 == 0
