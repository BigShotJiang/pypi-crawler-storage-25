"""Tests for library testing API routes."""

from __future__ import annotations

import time

import pytest
from fastapi.testclient import TestClient

from pygubernator.api.main import create_app
from tests.unit.conftest import reset_test_db


def _headers() -> dict[str, str]:
    # Tests run with auth disabled (see tests/unit/conftest.py env fixture),
    # but keep headers for consistency with other route tests.
    return {
        "X-API-Token": "dev-token",
        "X-Actor": "test",
        "X-Role": "admin",
    }


@pytest.fixture(autouse=True)
def _reset_db() -> None:
    reset_test_db()


@pytest.fixture
def client() -> TestClient:
    return TestClient(create_app())


def test_create_and_list_jobs(client: TestClient) -> None:
    create = client.post(
        "/api/v1/library-testing/jobs",
        headers=_headers(),
        json={"name": "job-a", "spec_json": {"repo_path": "/tmp/does-not-exist"}},
    )
    assert create.status_code == 200
    job = create.json()
    assert job["name"] == "job-a"
    assert job["current_state"] == "queued"

    lst = client.get("/api/v1/library-testing/jobs", headers=_headers())
    assert lst.status_code == 200
    body = lst.json()
    assert body["meta"]["total"] == 1
    assert body["items"][0]["id"] == job["id"]


def test_submit_event_idempotent(client: TestClient) -> None:
    job = client.post(
        "/api/v1/library-testing/jobs",
        headers=_headers(),
        json={"name": "job-a", "spec_json": {}},
    ).json()
    job_id = job["id"]

    e1 = client.post(
        f"/api/v1/library-testing/jobs/{job_id}/events",
        headers=_headers(),
        json={"trigger": "enqueue", "idempotency_key": "k1"},
    )
    assert e1.status_code == 200
    ev1 = e1.json()["event"]

    e2 = client.post(
        f"/api/v1/library-testing/jobs/{job_id}/events",
        headers=_headers(),
        json={"trigger": "enqueue", "idempotency_key": "k1"},
    )
    assert e2.status_code == 200
    ev2 = e2.json()["event"]
    assert ev1["id"] == ev2["id"]


def test_workflow_replay_and_diff_smoke(
    client: TestClient, monkeypatch: pytest.MonkeyPatch
) -> None:
    # Avoid running subprocess/venv in unit tests: inject recorded output by forcing
    # the library_test node to read __recorded_outputs__ (replay path).
    job = client.post(
        "/api/v1/library-testing/jobs",
        headers=_headers(),
        json={
            "name": "job-a",
            "spec_json": {
                "repo_path": "/tmp/x",
                "requirements": [],
                "pytest_args": ["-q"],
            },
        },
    ).json()

    # Start run (will fail because repo_path doesn't exist); we just need a run row.
    started = client.post(
        f"/api/v1/library-testing/jobs/{job['id']}/run",
        headers=_headers(),
        json={},
    )
    assert started.status_code == 200
    run_id = started.json()["workflow_run_id"]

    # Wait for completion
    status = "running"
    for _ in range(80):
        time.sleep(0.05)
        poll = client.get(f"/api/v1/workflows/runs/{run_id}", headers=_headers())
        if poll.status_code != 200:
            continue
        status = poll.json()["run"]["status"]
        if status in ("completed", "failed", "cancelled", "awaiting_approval"):
            break
    assert status in ("completed", "failed", "cancelled", "awaiting_approval")

    # Replay (recorded). Even if no recorded outputs exist, endpoint should succeed
    # and create a new run (it will likely fail fast due to missing recorded data).
    replay = client.post(
        f"/api/v1/workflows/runs/{run_id}/replay",
        headers=_headers(),
        json={},
    )
    assert replay.status_code == 200
    new_run_id = replay.json()["new_run_id"]

    diff = client.get(
        "/api/v1/replay/workflow-runs/diff",
        headers=_headers(),
        params={"left_run_id": run_id, "right_run_id": new_run_id},
    )
    assert diff.status_code == 200
    assert diff.json()["left_run_id"] == run_id
