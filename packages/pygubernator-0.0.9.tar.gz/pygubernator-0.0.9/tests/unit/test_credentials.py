"""Tests for credential encryption, masking, and API routes."""

from __future__ import annotations

import os
from unittest.mock import MagicMock, patch

import pytest

from pygubernator.config.integrations import (
    KNOWN_PROVIDERS,
    decrypt_value,
    encrypt_value,
    mask_value,
)

# ---------------------------------------------------------------------------
# Encryption / decryption
# ---------------------------------------------------------------------------


class TestEncryptDecrypt:
    """Tests for encrypt_value and decrypt_value round-trip."""

    def test_round_trip(self) -> None:
        secret = "test-jwt-secret-1234"
        plaintext = "xoxb-slack-token-abcdef"
        encrypted = encrypt_value(plaintext, secret)
        assert encrypted != plaintext
        assert decrypt_value(encrypted, secret) == plaintext

    def test_different_secrets_fail(self) -> None:
        plaintext = "my-secret-value"
        enc = encrypt_value(plaintext, "secret-a")
        with pytest.raises(Exception):
            decrypt_value(enc, "secret-b")

    def test_empty_value(self) -> None:
        secret = "secret"
        enc = encrypt_value("", secret)
        assert decrypt_value(enc, secret) == ""

    def test_unicode_value(self) -> None:
        secret = "secret"
        plaintext = "password-with-emoji-\U0001f511"
        enc = encrypt_value(plaintext, secret)
        assert decrypt_value(enc, secret) == plaintext


# ---------------------------------------------------------------------------
# Masking
# ---------------------------------------------------------------------------


class TestMaskValue:
    """Tests for mask_value."""

    def test_long_value(self) -> None:
        assert mask_value("abcdefghijklmnop") == "abcd****mnop"

    def test_short_value(self) -> None:
        assert mask_value("short") == "****"

    def test_boundary_value(self) -> None:
        # Exactly 10 chars — should be masked fully
        assert mask_value("1234567890") == "****"

    def test_eleven_chars(self) -> None:
        assert mask_value("12345678901") == "1234****8901"


# ---------------------------------------------------------------------------
# Known providers
# ---------------------------------------------------------------------------


class TestKnownProviders:
    """Tests for the provider registry."""

    def test_all_have_env_var(self) -> None:
        for name, info in KNOWN_PROVIDERS.items():
            assert "env_var" in info, f"{name} missing env_var"
            assert "type" in info, f"{name} missing type"

    def test_expected_providers_present(self) -> None:
        expected = {
            "google_sheets",
            "google_docs",
            "slack",
            "notion",
            "sql",
            "http",
            "obsidian",
            "python",
            "catalyst",
            "stator",
            "db_sqlite",
            "db_postgres",
            "db_mongodb_uri",
            "db_mongodb_database",
            "db_redis",
        }
        assert expected == set(KNOWN_PROVIDERS.keys())


# ---------------------------------------------------------------------------
# inject_credentials
# ---------------------------------------------------------------------------


class TestInjectCredentials:
    """Tests for the credential injection function."""

    @patch("pygubernator.config.integrations.get_auth_jwt_secret")
    def test_sets_env_vars(self, mock_secret: MagicMock) -> None:
        from pygubernator.config.integrations import (
            inject_credentials,
        )

        mock_secret.return_value = "test-secret"
        encrypted = encrypt_value("my-token", "test-secret")

        mock_row = MagicMock()
        mock_row.env_var = "_TEST_INJECT_CRED"
        mock_row.encrypted_value = encrypted
        mock_row.name = "test"

        mock_session = MagicMock()
        mock_session.query.return_value.filter.return_value.all.return_value = [
            mock_row
        ]

        try:
            inject_credentials(mock_session)
            assert os.environ.get("_TEST_INJECT_CRED") == "my-token"
        finally:
            os.environ.pop("_TEST_INJECT_CRED", None)

    @patch("pygubernator.config.integrations.get_auth_jwt_secret")
    def test_skips_when_no_secret(
        self,
        mock_secret: MagicMock,
    ) -> None:
        from pygubernator.config.integrations import (
            inject_credentials,
        )

        mock_secret.return_value = ""
        mock_session = MagicMock()
        inject_credentials(mock_session)
        mock_session.query.assert_not_called()

    @patch("pygubernator.config.integrations.get_auth_jwt_secret")
    def test_continues_on_decrypt_error(
        self,
        mock_secret: MagicMock,
    ) -> None:
        from pygubernator.config.integrations import (
            inject_credentials,
        )

        mock_secret.return_value = "test-secret"

        bad_row = MagicMock()
        bad_row.env_var = "_TEST_BAD_CRED"
        bad_row.encrypted_value = "invalid-ciphertext"
        bad_row.name = "bad"

        good_row = MagicMock()
        good_row.env_var = "_TEST_GOOD_CRED"
        good_row.encrypted_value = encrypt_value("ok", "test-secret")
        good_row.name = "good"

        mock_session = MagicMock()
        mock_session.query.return_value.filter.return_value.all.return_value = [
            bad_row,
            good_row,
        ]

        try:
            inject_credentials(mock_session)
            assert "_TEST_BAD_CRED" not in os.environ
            assert os.environ.get("_TEST_GOOD_CRED") == "ok"
        finally:
            os.environ.pop("_TEST_BAD_CRED", None)
            os.environ.pop("_TEST_GOOD_CRED", None)


# ---------------------------------------------------------------------------
# API routes
# ---------------------------------------------------------------------------


class TestCredentialsApiRoutes:
    """Tests for credential API route definitions."""

    def test_router_has_expected_paths(self) -> None:
        """Verify the router defines the expected endpoints."""
        from pygubernator.api.routes_credentials import router

        paths = [r.path for r in router.routes]
        prefix = "/api/v1/admin/credentials"
        assert prefix in paths  # list + create
        assert f"{prefix}/{{credential_id}}" in paths
        assert f"{prefix}/providers" in paths

    def test_provider_endpoint_returns_known(self) -> None:
        """The list_providers function returns KNOWN_PROVIDERS."""
        from pygubernator.api.routes_credentials import (
            list_providers,
        )

        # Call the function directly (bypass FastAPI deps)
        result = list_providers(_admin={})  # type: ignore[arg-type]
        assert "providers" in result
        assert "slack" in result["providers"]
        assert "notion" in result["providers"]

    def test_to_response_masks_value(self) -> None:
        """_to_response masks the credential value."""
        from pygubernator.api.routes_credentials import (
            _to_response,
        )

        secret = "test-secret"
        enc = encrypt_value("long-secret-token-value", secret)
        row = MagicMock()
        row.id = "abc-123"
        row.provider = "slack"
        row.name = "My Slack"
        row.env_var = "PYGUBERNATOR_SLACK_BOT_TOKEN"
        row.encrypted_value = enc
        row.enabled = True
        row.created_at = "2026-01-01T00:00:00Z"
        row.updated_at = "2026-01-01T00:00:00Z"

        resp = _to_response(row, secret)
        assert resp.value_preview != "long-secret-token-value"
        assert "****" in resp.value_preview
