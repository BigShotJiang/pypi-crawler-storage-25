from __future__ import annotations

import sqlite3
from pathlib import Path

import pytest

from pygubernator.tools import db_factory, db_tools


@pytest.mark.asyncio
async def test_sqlite_tools_execute_and_query(tmp_path: Path) -> None:
    db_path = tmp_path / "test.db"

    tools = db_tools.create_sqlite_tools(str(db_path))
    by_name = {t.name: t for t in tools}

    # Create + insert.
    res = await by_name["db_sqlite_execute"].execute(
        {"sql": "CREATE TABLE items(id INTEGER PRIMARY KEY, n INTEGER)"}
    )
    assert res.success is True

    res = await by_name["db_sqlite_execute"].execute(
        {"sql": "INSERT INTO items(n) VALUES (:n)", "params_json": {"n": 40}}
    )
    assert res.success is True

    # Query.
    res = await by_name["db_sqlite_query"].execute(
        {"sql": "SELECT n FROM items LIMIT 1"}
    )
    assert res.success is True
    assert res.output["rows"][0]["n"] == 40

    # List tables.
    res = await by_name["db_sqlite_list_tables"].execute({})
    assert res.success is True
    assert "items" in res.output["tables"]


def test_db_factory_sqlite_from_env(
    tmp_path: Path,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    db_path = tmp_path / "env.db"
    # touch file to make the intent explicit
    sqlite3.connect(db_path).close()

    monkeypatch.setenv("PYGUBERNATOR_SQLITE_PATH", str(db_path))
    tools = db_factory.create_tools_from_env("sqlite")
    names = {t.name for t in tools}
    assert "db_sqlite_query" in names
    assert "db_sqlite_execute" in names


def test_db_factory_missing_env_errors(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.delenv("PYGUBERNATOR_SQLITE_PATH", raising=False)
    with pytest.raises(ValueError):
        db_factory.create_tools_from_env("sqlite")
