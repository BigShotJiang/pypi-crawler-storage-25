"""Factory helpers to build database tool sets from env.

This is intended to scale: new backends should be added by:
  - implementing create_<backend>_tools(...) in tools/db_tools.py
  - adding a small env-reading wrapper here
  - optionally adding a workflow preset (workflow/tool_presets.py)
"""

from __future__ import annotations

import os
from typing import Any, Literal

from pygubernator.config._helpers import _cfg
from pygubernator.tools import db_tools

Backend = Literal["sqlite", "postgres", "mongodb", "redis"]


def _resolve_value(
    explicit: str | None,
    *,
    env_var: str,
) -> str:
    """Resolve a backend setting using standard precedence.

    Precedence (highest → lowest):
      1) explicit value passed in factory_args (workflow artifact)
      2) environment variable (includes DB-injected IntegrationCredential values)
      3) pygubernator.cfg [integrations]
    """
    if explicit is not None and str(explicit).strip():
        return str(explicit).strip()
    env_val = os.environ.get(env_var, "")
    if env_val.strip():
        return env_val.strip()
    cfg_val = _cfg("integrations", env_var) or ""
    return cfg_val.strip()


def create_tools_from_env(
    backend: Backend,
    *,
    # Explicit values (preferred when set; override env/cfg)
    sqlite_path: str | None = None,
    postgres_dsn: str | None = None,
    mongodb_uri: str | None = None,
    mongodb_database: str | None = None,
    redis_url: str | None = None,
    # Env var indirection (lets workflows refer to custom env names)
    sqlite_path_env: str = "PYGUBERNATOR_SQLITE_PATH",
    postgres_dsn_env: str = "PYGUBERNATOR_POSTGRES_DSN",
    mongodb_uri_env: str = "PYGUBERNATOR_MONGODB_URI",
    mongodb_db_env: str = "PYGUBERNATOR_MONGODB_DATABASE",
    redis_url_env: str = "PYGUBERNATOR_REDIS_URL",
) -> list[Any]:
    """Create database tools for a chosen backend using env/cfg or explicit args.

    Args:
        backend: One of sqlite/postgres/mongodb/redis.
        sqlite_path: Explicit sqlite db path (overrides env/cfg).
        postgres_dsn: Explicit Postgres DSN (overrides env/cfg).
        mongodb_uri: Explicit MongoDB URI (overrides env/cfg).
        mongodb_database: Explicit MongoDB DB name (overrides env/cfg).
        redis_url: Explicit Redis URL (overrides env/cfg).
        sqlite_path_env: Env var containing sqlite db path.
        postgres_dsn_env: Env var containing postgres DSN.
        mongodb_uri_env: Env var containing mongodb connection URI.
        mongodb_db_env: Env var containing mongodb database name.
        redis_url_env: Env var containing redis URL.
    """
    backend = str(backend).strip().lower()

    if backend == "sqlite":
        path = _resolve_value(sqlite_path, env_var=sqlite_path_env)
        if not path:
            raise ValueError(f"Missing SQLite path. Set {sqlite_path_env}.")
        return db_tools.create_sqlite_tools(path)

    if backend == "postgres":
        dsn = _resolve_value(postgres_dsn, env_var=postgres_dsn_env)
        if not dsn:
            raise ValueError(f"Missing Postgres DSN. Set {postgres_dsn_env}.")
        return db_tools.create_postgres_tools(dsn)

    if backend == "mongodb":
        uri = _resolve_value(mongodb_uri, env_var=mongodb_uri_env)
        db = _resolve_value(mongodb_database, env_var=mongodb_db_env)
        if not uri:
            raise ValueError(f"Missing MongoDB URI. Set {mongodb_uri_env}.")
        if not db:
            raise ValueError(f"Missing MongoDB database. Set {mongodb_db_env}.")
        return db_tools.create_mongodb_tools(uri=uri, database=db)

    if backend == "redis":
        url = _resolve_value(redis_url, env_var=redis_url_env)
        if not url:
            raise ValueError(f"Missing Redis URL. Set {redis_url_env}.")
        return db_tools.create_redis_tools(url)

    raise ValueError(f"Unknown backend: {backend}")
