"""Google Sheets tools for creating and modifying spreadsheets."""

from __future__ import annotations

import logging
import os
from typing import Any

from pygubernator.tools._decorator import tool

logger = logging.getLogger(__name__)

try:
    from google.oauth2.service_account import (
        Credentials,  # type: ignore[import-untyped]
    )
    from googleapiclient.discovery import build  # type: ignore[import-untyped]

    _HAS_GSHEETS = True
except ImportError:
    _HAS_GSHEETS = False

_SCOPES = ["https://www.googleapis.com/auth/spreadsheets"]

_DEFAULT_HTTP_TIMEOUT_S = float(os.getenv("PYGUBERNATOR_GSHEETS_HTTP_TIMEOUT", "30"))
_DEFAULT_TOOL_TIMEOUT_S = float(os.getenv("PYGUBERNATOR_GSHEETS_TOOL_TIMEOUT", "60"))


def _check_deps() -> None:
    """Raise if Google API dependencies are missing."""
    if not _HAS_GSHEETS:
        msg = (
            "Google Sheets dependencies not available. "
            "Install with: pip install google-api-python-client "
            "google-auth"
        )
        raise ImportError(msg)


class _SheetsClient:
    """Thin wrapper around the Google Sheets API v4.

    Args:
        credentials_path: Path to service account JSON key file.
    """

    def __init__(self, credentials_path: str) -> None:
        _check_deps()
        # Ensure the underlying HTTP transport has a finite timeout so calls
        # don't hang indefinitely and can be bounded by workflow/node timeouts.
        creds = Credentials.from_service_account_file(credentials_path, scopes=_SCOPES)
        http = None
        try:
            import httplib2  # type: ignore[import-untyped]

            base_http = httplib2.Http(timeout=_DEFAULT_HTTP_TIMEOUT_S)
            # googleapiclient requires that you pass either `credentials=` OR
            # an already-authorized `http=` transport, not both.
            http = creds.authorize(base_http)
        except Exception:
            http = None
        # If we fail to build an authorized transport, fall back to passing
        # credentials directly. This prevents googleapiclient from attempting
        # Application Default Credentials (ADC).
        if http is not None:
            service = build(
                "sheets",
                "v4",
                http=http,
                cache_discovery=False,
            )
        else:
            service = build(
                "sheets",
                "v4",
                credentials=creds,
                cache_discovery=False,
            )
        self._sheets = service.spreadsheets()

    # ------------------------------------------------------------------
    # Spreadsheet operations
    # ------------------------------------------------------------------

    def create_spreadsheet(self, title: str) -> dict[str, Any]:
        """Create a new spreadsheet.

        Args:
            title: Spreadsheet title.

        Returns:
            Dict with ``spreadsheet_id`` and ``url``.
        """
        body: dict[str, Any] = {"properties": {"title": title}}
        result = self._sheets.create(body=body).execute()
        return {
            "spreadsheet_id": result["spreadsheetId"],
            "url": result["spreadsheetUrl"],
        }

    # ------------------------------------------------------------------
    # Read
    # ------------------------------------------------------------------

    def read_range(self, spreadsheet_id: str, range_: str) -> list[list[Any]]:
        """Read a cell range.

        Args:
            spreadsheet_id: Spreadsheet ID.
            range_: A1 notation range (e.g. ``Sheet1!A1:C10``).

        Returns:
            2-D list of cell values.
        """
        result = (
            self._sheets.values()
            .get(spreadsheetId=spreadsheet_id, range=range_)
            .execute()
        )
        return result.get("values", [])

    # ------------------------------------------------------------------
    # Write / Update
    # ------------------------------------------------------------------

    def write_range(
        self,
        spreadsheet_id: str,
        range_: str,
        values: list[list[Any]],
    ) -> dict[str, Any]:
        """Write values to a range (overwrite existing data).

        Args:
            spreadsheet_id: Spreadsheet ID.
            range_: A1 notation range.
            values: 2-D list of values to write.

        Returns:
            Dict with ``updated_cells`` count.
        """
        body = {"values": values}
        result = (
            self._sheets.values()
            .update(
                spreadsheetId=spreadsheet_id,
                range=range_,
                valueInputOption="USER_ENTERED",
                body=body,
            )
            .execute()
        )
        return {"updated_cells": result.get("updatedCells", 0)}

    # ------------------------------------------------------------------
    # Append
    # ------------------------------------------------------------------

    def append_rows(
        self,
        spreadsheet_id: str,
        range_: str,
        values: list[list[Any]],
    ) -> dict[str, Any]:
        """Append rows after the last row with data.

        Args:
            spreadsheet_id: Spreadsheet ID.
            range_: A1 notation range (table to append to).
            values: 2-D list of rows to append.

        Returns:
            Dict with ``updated_cells`` count.
        """
        body = {"values": values}
        result = (
            self._sheets.values()
            .append(
                spreadsheetId=spreadsheet_id,
                range=range_,
                valueInputOption="USER_ENTERED",
                insertDataOption="INSERT_ROWS",
                body=body,
            )
            .execute()
        )
        updates = result.get("updates", {})
        return {"updated_cells": updates.get("updatedCells", 0)}

    # ------------------------------------------------------------------
    # Sheet (tab) management
    # ------------------------------------------------------------------

    def create_sheet(self, spreadsheet_id: str, title: str) -> dict[str, Any]:
        """Add a new sheet (tab) to a spreadsheet.

        Args:
            spreadsheet_id: Spreadsheet ID.
            title: Name for the new sheet.

        Returns:
            Dict with ``sheet_id`` and ``title``.
        """
        request = {"addSheet": {"properties": {"title": title}}}
        result = self._batch_update(spreadsheet_id, [request])
        reply = result["replies"][0]["addSheet"]
        props = reply["properties"]
        return {"sheet_id": props["sheetId"], "title": props["title"]}

    def delete_sheet(self, spreadsheet_id: str, sheet_id: int) -> dict[str, Any]:
        """Delete a sheet (tab) by its numeric ID.

        Args:
            spreadsheet_id: Spreadsheet ID.
            sheet_id: Numeric sheet ID (not name).

        Returns:
            Dict confirming deletion.
        """
        request = {"deleteSheet": {"sheetId": sheet_id}}
        self._batch_update(spreadsheet_id, [request])
        return {"deleted_sheet_id": sheet_id}

    def rename_sheet(
        self,
        spreadsheet_id: str,
        sheet_id: int,
        new_title: str,
    ) -> dict[str, Any]:
        """Rename a sheet (tab).

        Args:
            spreadsheet_id: Spreadsheet ID.
            sheet_id: Numeric sheet ID.
            new_title: New name for the sheet.

        Returns:
            Dict with ``sheet_id`` and ``new_title``.
        """
        request = {
            "updateSheetProperties": {
                "properties": {
                    "sheetId": sheet_id,
                    "title": new_title,
                },
                "fields": "title",
            }
        }
        self._batch_update(spreadsheet_id, [request])
        return {"sheet_id": sheet_id, "new_title": new_title}

    # ------------------------------------------------------------------
    # Formatting
    # ------------------------------------------------------------------

    def format_cells(
        self,
        spreadsheet_id: str,
        sheet_id: int,
        start_row: int,
        end_row: int,
        start_col: int,
        end_col: int,
        bold: bool | None = None,
        fg_color: dict[str, float] | None = None,
        bg_color: dict[str, float] | None = None,
        border_style: str | None = None,
    ) -> dict[str, Any]:
        """Apply formatting to a cell range.

        Args:
            spreadsheet_id: Spreadsheet ID.
            sheet_id: Numeric sheet ID.
            start_row: Start row index (0-based, inclusive).
            end_row: End row index (0-based, exclusive).
            start_col: Start column index (0-based, inclusive).
            end_col: End column index (0-based, exclusive).
            bold: Whether to bold the text.
            fg_color: Text colour as ``{"red": 0-1, "green": 0-1, "blue": 0-1}``.
            bg_color: Background colour (same format).
            border_style: Border style — ``"SOLID"``, ``"DASHED"``, etc.

        Returns:
            Dict confirming the format operation.
        """
        grid_range = {
            "sheetId": sheet_id,
            "startRowIndex": start_row,
            "endRowIndex": end_row,
            "startColumnIndex": start_col,
            "endColumnIndex": end_col,
        }

        cell_format: dict[str, Any] = {}
        fields: list[str] = []

        if bold is not None:
            cell_format["textFormat"] = {"bold": bold}
            fields.append("userEnteredFormat.textFormat.bold")

        if fg_color is not None:
            cell_format.setdefault("textFormat", {})["foregroundColorStyle"] = {
                "rgbColor": fg_color
            }
            fields.append("userEnteredFormat.textFormat.foregroundColorStyle")

        if bg_color is not None:
            cell_format["backgroundColorStyle"] = {"rgbColor": bg_color}
            fields.append("userEnteredFormat.backgroundColorStyle")

        requests: list[dict[str, Any]] = []

        if fields:
            requests.append(
                {
                    "repeatCell": {
                        "range": grid_range,
                        "cell": {"userEnteredFormat": cell_format},
                        "fields": ",".join(fields),
                    }
                }
            )

        if border_style:
            border = {
                "style": border_style,
                "colorStyle": {
                    "rgbColor": fg_color or {"red": 0, "green": 0, "blue": 0}
                },
            }
            requests.append(
                {
                    "updateBorders": {
                        "range": grid_range,
                        "top": border,
                        "bottom": border,
                        "left": border,
                        "right": border,
                    }
                }
            )

        if not requests:
            return {"formatted": False, "reason": "no format options specified"}

        self._batch_update(spreadsheet_id, requests)
        return {"formatted": True}

    # ------------------------------------------------------------------
    # Internal
    # ------------------------------------------------------------------

    def _batch_update(
        self,
        spreadsheet_id: str,
        requests: list[dict[str, Any]],
    ) -> dict[str, Any]:
        """Execute a batchUpdate request.

        Args:
            spreadsheet_id: Spreadsheet ID.
            requests: List of request dicts.

        Returns:
            Raw API response.
        """
        body = {"requests": requests}
        return self._sheets.batchUpdate(
            spreadsheetId=spreadsheet_id, body=body
        ).execute()


def create_sheets_client(credentials_path: str) -> _SheetsClient:
    """Build a Google Sheets API client for workflow nodes and scripting.

    Args:
        credentials_path: Path to the service account JSON key file.

    Returns:
        A :class:`_SheetsClient` instance.
    """
    return _SheetsClient(credentials_path)


# ======================================================================
# Public factory
# ======================================================================


def create_gsheets_tools(credentials_path: str) -> list[Any]:
    """Create Google Sheets tools backed by a service account.

    Args:
        credentials_path: Path to the service account JSON key file.

    Returns:
        List of tool objects ready for registration.
    """
    client = _SheetsClient(credentials_path)

    # ------------------------------------------------------------------
    # Tool definitions
    # ------------------------------------------------------------------

    @tool(
        name="gsheets_create_spreadsheet",
        description="Create a new Google Sheets spreadsheet.",
    )
    async def gsheets_create_spreadsheet(
        title: str,
        *,
        timeout_s: float | None = None,
    ) -> dict[str, Any]:
        """Create a new Google Sheets spreadsheet.

        Args:
            title: Title for the new spreadsheet.

        Returns:
            Dict with spreadsheet_id and url.
        """
        import asyncio

        t = _DEFAULT_TOOL_TIMEOUT_S if timeout_s is None else float(timeout_s)
        return await asyncio.wait_for(
            asyncio.to_thread(client.create_spreadsheet, title),
            timeout=t,
        )

    @tool(
        name="gsheets_read_range",
        description=(
            "Read a range of cells from a Google Sheets spreadsheet. "
            "Returns a 2-D list of cell values."
        ),
    )
    async def gsheets_read_range(
        spreadsheet_id: str,
        range: str,
        *,
        timeout_s: float | None = None,
    ) -> dict[str, Any]:
        """Read cells from a spreadsheet.

        Args:
            spreadsheet_id: The spreadsheet ID from the URL.
            range: A1 notation range (e.g. Sheet1!A1:C10).

        Returns:
            Dict with the values as a 2-D list.
        """
        import asyncio

        t = _DEFAULT_TOOL_TIMEOUT_S if timeout_s is None else float(timeout_s)
        values = await asyncio.wait_for(
            asyncio.to_thread(client.read_range, spreadsheet_id, range),
            timeout=t,
        )
        return {"values": values, "row_count": len(values)}

    @tool(
        name="gsheets_write_range",
        description=("Write values to a range of cells, overwriting existing data."),
    )
    async def gsheets_write_range(
        spreadsheet_id: str,
        range: str,
        values: list[list[Any]],
        *,
        timeout_s: float | None = None,
    ) -> dict[str, Any]:
        """Write values to a spreadsheet range.

        Args:
            spreadsheet_id: The spreadsheet ID.
            range: A1 notation range to write to.
            values: 2-D list of values (rows of columns).

        Returns:
            Dict with updated_cells count.
        """
        import asyncio

        t = _DEFAULT_TOOL_TIMEOUT_S if timeout_s is None else float(timeout_s)
        return await asyncio.wait_for(
            asyncio.to_thread(client.write_range, spreadsheet_id, range, values),
            timeout=t,
        )

    @tool(
        name="gsheets_append_rows",
        description=("Append rows after the last row with data in a sheet."),
    )
    async def gsheets_append_rows(
        spreadsheet_id: str,
        range: str,
        values: list[list[Any]],
        *,
        timeout_s: float | None = None,
    ) -> dict[str, Any]:
        """Append rows to a spreadsheet.

        Args:
            spreadsheet_id: The spreadsheet ID.
            range: A1 notation range identifying the table.
            values: 2-D list of rows to append.

        Returns:
            Dict with updated_cells count.
        """
        import asyncio

        t = _DEFAULT_TOOL_TIMEOUT_S if timeout_s is None else float(timeout_s)
        return await asyncio.wait_for(
            asyncio.to_thread(client.append_rows, spreadsheet_id, range, values),
            timeout=t,
        )

    @tool(
        name="gsheets_create_sheet",
        description="Add a new sheet (tab) to a spreadsheet.",
    )
    async def gsheets_create_sheet(
        spreadsheet_id: str,
        title: str,
        *,
        timeout_s: float | None = None,
    ) -> dict[str, Any]:
        """Create a new sheet tab.

        Args:
            spreadsheet_id: The spreadsheet ID.
            title: Name for the new sheet tab.

        Returns:
            Dict with sheet_id and title.
        """
        import asyncio

        t = _DEFAULT_TOOL_TIMEOUT_S if timeout_s is None else float(timeout_s)
        return await asyncio.wait_for(
            asyncio.to_thread(client.create_sheet, spreadsheet_id, title),
            timeout=t,
        )

    @tool(
        name="gsheets_delete_sheet",
        description="Delete a sheet (tab) from a spreadsheet by numeric ID.",
    )
    async def gsheets_delete_sheet(
        spreadsheet_id: str,
        sheet_id: int,
        *,
        timeout_s: float | None = None,
    ) -> dict[str, Any]:
        """Delete a sheet tab.

        Args:
            spreadsheet_id: The spreadsheet ID.
            sheet_id: Numeric sheet ID (not the tab name).

        Returns:
            Dict confirming deletion.
        """
        import asyncio

        t = _DEFAULT_TOOL_TIMEOUT_S if timeout_s is None else float(timeout_s)
        return await asyncio.wait_for(
            asyncio.to_thread(client.delete_sheet, spreadsheet_id, sheet_id),
            timeout=t,
        )

    @tool(
        name="gsheets_rename_sheet",
        description="Rename a sheet (tab) in a spreadsheet.",
    )
    async def gsheets_rename_sheet(
        spreadsheet_id: str,
        sheet_id: int,
        new_title: str,
        *,
        timeout_s: float | None = None,
    ) -> dict[str, Any]:
        """Rename a sheet tab.

        Args:
            spreadsheet_id: The spreadsheet ID.
            sheet_id: Numeric sheet ID.
            new_title: New name for the sheet.

        Returns:
            Dict with sheet_id and new_title.
        """
        import asyncio

        t = _DEFAULT_TOOL_TIMEOUT_S if timeout_s is None else float(timeout_s)
        return await asyncio.wait_for(
            asyncio.to_thread(client.rename_sheet, spreadsheet_id, sheet_id, new_title),
            timeout=t,
        )

    @tool(
        name="gsheets_format_cells",
        description=(
            "Apply formatting (bold, colours, borders) to a cell range. "
            "Uses 0-based row/col indices."
        ),
    )
    async def gsheets_format_cells(
        spreadsheet_id: str,
        sheet_id: int,
        start_row: int,
        end_row: int,
        start_col: int,
        end_col: int,
        bold: bool | None = None,
        fg_color: dict[str, float] | None = None,
        bg_color: dict[str, float] | None = None,
        border_style: str | None = None,
        *,
        timeout_s: float | None = None,
    ) -> dict[str, Any]:
        """Format a range of cells.

        Args:
            spreadsheet_id: The spreadsheet ID.
            sheet_id: Numeric sheet ID.
            start_row: Start row (0-based, inclusive).
            end_row: End row (0-based, exclusive).
            start_col: Start column (0-based, inclusive).
            end_col: End column (0-based, exclusive).
            bold: Set text to bold.
            fg_color: Text colour as {red, green, blue} floats 0-1.
            bg_color: Background colour as {red, green, blue} floats 0-1.
            border_style: Border style (SOLID, DASHED, DOTTED, etc).

        Returns:
            Dict confirming the format operation.
        """
        import asyncio

        t = _DEFAULT_TOOL_TIMEOUT_S if timeout_s is None else float(timeout_s)
        return await asyncio.wait_for(
            asyncio.to_thread(
                client.format_cells,
                spreadsheet_id=spreadsheet_id,
                sheet_id=sheet_id,
                start_row=start_row,
                end_row=end_row,
                start_col=start_col,
                end_col=end_col,
                bold=bold,
                fg_color=fg_color,
                bg_color=bg_color,
                border_style=border_style,
            ),
            timeout=t,
        )

    return [
        gsheets_create_spreadsheet,
        gsheets_read_range,
        gsheets_write_range,
        gsheets_append_rows,
        gsheets_create_sheet,
        gsheets_delete_sheet,
        gsheets_rename_sheet,
        gsheets_format_cells,
    ]
