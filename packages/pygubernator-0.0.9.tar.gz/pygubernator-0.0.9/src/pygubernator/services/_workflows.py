"""Workflow execution service — business logic extracted from routes."""

from __future__ import annotations

import asyncio
import logging
import os
import time
from collections.abc import Callable
from datetime import UTC, datetime
from typing import Any

from pygubernator._events import AgentEvent, AgentEventType, EventBus
from pygubernator._sse import broadcaster
from pygubernator.workflow._metadata import get_builtin_node_type_descriptions
from pygubernator.workflow._registry import NodeTypeRegistry
from pygubernator.workflow._types import WorkflowResult

logger = logging.getLogger(__name__)

_WORKFLOW_TIMEOUT = float(os.getenv("PYGUBERNATOR_WORKFLOW_TIMEOUT", "600"))
_NODE_TIMEOUT = float(os.getenv("PYGUBERNATOR_NODE_TIMEOUT", "300"))


async def _run_with_timeout(
    engine: Any,
    input_json: dict[str, Any],
    timeout: float,
    variables: dict[str, Any] | None = None,
) -> WorkflowResult:
    """Execute engine.run() with an overall timeout guard."""
    return await asyncio.wait_for(
        engine.run(input_json, variables=variables),
        timeout=timeout,
    )


def build_node_registry() -> NodeTypeRegistry:
    """Build a NodeTypeRegistry with all built-in node factories.

    Returns:
        Configured NodeTypeRegistry instance with all standard node types.
    """
    from pygubernator.workflow.nodes._approval import ApprovalNodeFactory
    from pygubernator.workflow.nodes._code import CodeNodeFactory
    from pygubernator.workflow.nodes._condition import ConditionNodeFactory
    from pygubernator.workflow.nodes._input import InputNodeFactory
    from pygubernator.workflow.nodes._library_test import LibraryTestNodeFactory
    from pygubernator.workflow.nodes._loop import LoopNodeFactory
    from pygubernator.workflow.nodes._map import MapNodeFactory
    from pygubernator.workflow.nodes._memory import MemoryNodeFactory
    from pygubernator.workflow.nodes._output import OutputNodeFactory
    from pygubernator.workflow.nodes._python_exec import PythonExecNodeFactory
    from pygubernator.workflow.nodes._router import RouterNodeFactory
    from pygubernator.workflow.nodes._template import TemplateNodeFactory

    registry = NodeTypeRegistry()
    descriptions = {
        desc.type_name: desc for desc in get_builtin_node_type_descriptions()
    }
    for name, factory_cls in [
        ("input", InputNodeFactory),
        ("output", OutputNodeFactory),
        ("template", TemplateNodeFactory),
        ("condition", ConditionNodeFactory),
        ("code", CodeNodeFactory),
        ("python_exec", PythonExecNodeFactory),
        ("router", RouterNodeFactory),
        ("loop", LoopNodeFactory),
        ("map", MapNodeFactory),
        ("memory", MemoryNodeFactory),
        ("approval", ApprovalNodeFactory),
        ("library_test", LibraryTestNodeFactory),
    ]:
        registry.register(name, factory_cls(), description=descriptions.get(name))

    try:
        from pygubernator.workflow.nodes._http import HttpNodeFactory

        registry.register(
            "http",
            HttpNodeFactory(),
            description=descriptions.get("http"),
        )
    except ImportError:
        pass

    try:
        from pygubernator.workflow.nodes._gsheets import GSheetsNodeFactory

        registry.register(
            "gsheets",
            GSheetsNodeFactory(),
            description=descriptions.get("gsheets"),
        )
    except ImportError:
        pass

    try:
        from pygubernator.workflow.nodes._llm import LLMNodeFactory

        registry.register(
            "llm",
            LLMNodeFactory(llm_provider=None),
            description=descriptions.get("llm"),
        )
    except ImportError:
        pass

    try:
        from pygubernator.workflow.nodes._agent import AgentNodeFactory

        registry.register(
            "agent",
            AgentNodeFactory(),
            description=descriptions.get("agent"),
        )
    except ImportError:
        pass

    try:
        from pygubernator.workflow.nodes._tool import ToolNodeFactory

        registry.register(
            "tool",
            ToolNodeFactory(),
            description=descriptions.get("tool"),
        )
    except ImportError:
        pass

    try:
        from pygubernator.workflow.nodes._subworkflow import (
            SubWorkflowNodeFactory,
        )

        registry.register(
            "subworkflow",
            SubWorkflowNodeFactory(),
            description=descriptions.get("subworkflow"),
        )
    except ImportError:
        pass

    for description in descriptions.values():
        if registry.describe(description.type_name) is None:
            registry.register_description(description)

    return registry


def execute_workflow(
    spec_json: dict[str, Any],
    input_json: dict[str, Any],
    store: Any,
    run_id: str,
    *,
    session_id: str | None = None,
    cancellation_check: Callable[[], bool] | None = None,
) -> dict[str, Any]:
    """Build and execute a workflow spec, persisting step results.

    Args:
        spec_json: Workflow spec as a JSON dict.
        input_json: Input data for the workflow.
        store: :class:`~pygubernator.agent_store.SQLAlchemyAgentStore` for persistence.
        run_id: Workflow run ID for step association.
        session_id: Optional session ID for multi-turn memory persistence.
        cancellation_check: If set, called before each DAG level; return True to stop.

    Returns:
        Result dict with success, output, errors, duration_ms, and optional cancelled.
    """
    from pygubernator.workflow._engine import WorkflowEngine
    from pygubernator.workflow._types import NodeResult
    from pygubernator.workflow.config._loader import WorkflowLoader

    logger.info(
        "[SVC] execute_workflow called: run_id=%s, nodes=%d, input_keys=%s",
        run_id[:12] if run_id else "?",
        len(spec_json.get("nodes", {})),
        list(input_json.keys()),
    )

    loader = WorkflowLoader()
    try:
        spec = loader.load_dict(spec_json)
    except Exception as exc:
        logger.error("[SVC] Spec load failed: %s", exc, exc_info=True)
        return {
            "success": False,
            "output": {},
            "errors": [f"Invalid spec: {exc}"],
            "duration_ms": 0,
        }

    logger.info(
        "[SVC] Spec loaded: %d nodes, node_timeout=%ss, workflow_timeout=%ss",
        len(spec.nodes),
        _NODE_TIMEOUT,
        _WORKFLOW_TIMEOUT,
    )
    for nid, ns in spec.nodes.items():
        logger.info(
            "[SVC]   node %s: type=%s config_keys=%s",
            nid,
            ns.node_type,
            list(ns.config.keys())[:6],
        )

    # Guardrail: the overall workflow timeout should never be shorter than the
    # longest node timeout, otherwise long-running nodes can perform side effects
    # (e.g. tool calls) and then still be cut off by the workflow-level timeout.
    #
    # We treat missing/invalid per-node overrides as the global node timeout.
    max_node_timeout_s = float(_NODE_TIMEOUT)
    for _nid, _ns in spec.nodes.items():
        try:
            raw = _ns.config.get("node_timeout")
            if raw is None:
                raw = _ns.config.get("timeout_seconds")
            if raw is None or raw == "":
                continue
            max_node_timeout_s = max(max_node_timeout_s, float(raw))
        except Exception:
            continue

    effective_workflow_timeout_s = max(
        float(_WORKFLOW_TIMEOUT), max_node_timeout_s + 30.0
    )
    if effective_workflow_timeout_s != float(_WORKFLOW_TIMEOUT):
        logger.info(
            "[SVC] Adjusted workflow timeout to %ss (max node timeout=%ss)",
            effective_workflow_timeout_s,
            max_node_timeout_s,
        )

    # Always persist a bootstrap trace row and commit so GET .../trace is never
    # empty while the run is in progress (execute API returns before the worker
    # finishes; without an early commit, step rows are invisible to other sessions).
    _run_started_at = datetime.now(UTC)
    _marker = store.create_workflow_step_run(
        workflow_run_id=run_id,
        node_id="__run__",
        node_type="workflow_run",
        status="completed",
        input_json={},
    )
    store.update_workflow_step_run(
        _marker,
        output_json={
            "event": "run_started",
            "message": "Workflow execution started",
            "workflow": spec.name,
        },
        started_at=_run_started_at,
        completed_at=_run_started_at,
        duration_ms=0,
    )
    store.commit()

    registry = build_node_registry()

    # Inject stored credentials as env vars for tool factories
    try:
        from pygubernator.config.integrations import inject_credentials

        inject_credentials(store.session)
    except Exception as exc:
        logger.warning("Credential injection failed: %s", exc)

    def persist_step(node_id: str, result: NodeResult) -> None:
        """Persist a single step execution result."""
        node_spec = spec.nodes.get(node_id)
        node_type = node_spec.node_type if node_spec else "unknown"
        step = store.create_workflow_step_run(
            workflow_run_id=run_id,
            node_id=node_id,
            node_type=node_type,
            status=result.status.value,
            input_json={},
        )
        store.update_workflow_step_run(
            step,
            output_json=result.output,
            output_handle=result.output_handle,
            error_message=result.error,
        )

        # Record deterministic outputs for replay (Phase 1: node-scoped).
        try:
            if node_type == "library_test" and result.status.value != "failed":
                payload = result.output.get("result")
                if isinstance(payload, dict):
                    from pygubernator.db import repositories as _repos

                    _repos.upsert_recorded_output(
                        store.session,
                        workspace_id=getattr(store, "workspace_id", "default"),
                        workflow_run_id=run_id,
                        node_id=node_id,
                        payload_json=payload,
                    )
        except Exception as exc:
            logger.debug("recorded output store failed: %s", exc)

        # Commit each step so (a) the trace is visible while the run is in progress
        # and (b) we release the SQLite write transaction before nodes open other
        # connections to the same file (e.g. agent memory with db_path=pygubernator.db).
        commit_fn = getattr(store, "commit", None)
        if callable(commit_fn):
            try:
                commit_fn()
            except Exception as exc:
                logger.warning(
                    "[SVC] commit after step %s failed: %s",
                    node_id,
                    exc,
                )

    def _check_cancelled() -> bool:
        sess = getattr(store, "session", None)
        if sess is not None:
            sess.expire_all()
        run_row = store.get_workflow_run(run_id)
        if run_row is None:
            return False
        status = getattr(run_row, "status", None)
        return status == "cancelled"

    should_cancel = (
        cancellation_check if cancellation_check is not None else _check_cancelled
    )

    # Set up event bus for SSE broadcasting
    event_bus = EventBus()
    event_bus.add_handler(_BroadcastHandler(run_id))

    engine = WorkflowEngine(
        spec=spec,
        registry=registry,
        persist_callback=persist_step,
        event_bus=event_bus,
        node_timeout=_NODE_TIMEOUT,
        should_cancel=should_cancel,
    )

    variables: dict[str, Any] = {}
    if session_id:
        variables["__session_id__"] = session_id

    start = time.monotonic()
    try:
        wf_result = asyncio.run(
            _run_with_timeout(
                engine, input_json, effective_workflow_timeout_s, variables
            )
        )
    except TimeoutError:
        elapsed = int((time.monotonic() - start) * 1000)
        logger.error(
            "Workflow execution timed out after %ss",
            effective_workflow_timeout_s,
        )
        broadcaster.publish(
            run_id,
            {"type": "workflow_completed", "success": False, "duration_ms": elapsed},
        )
        broadcaster.close(run_id)
        return {
            "success": False,
            "output": {},
            "errors": [
                f"Workflow execution timed out after {effective_workflow_timeout_s}s"
            ],
            "duration_ms": elapsed,
        }
    except Exception as exc:
        elapsed = int((time.monotonic() - start) * 1000)
        parts = [f"{type(exc).__name__}: {exc}"]
        cause = exc.__cause__
        while cause:
            parts.append(f"  caused by {type(cause).__name__}: {cause}")
            cause = cause.__cause__
        error_msg = "\n".join(parts)
        logger.error("Workflow execution failed: %s", error_msg, exc_info=True)
        broadcaster.publish(
            run_id,
            {"type": "workflow_completed", "success": False, "duration_ms": elapsed},
        )
        broadcaster.close(run_id)
        return {
            "success": False,
            "output": {},
            "errors": [error_msg],
            "duration_ms": elapsed,
        }

    elapsed = int((time.monotonic() - start) * 1000)

    if wf_result.awaiting_approval:
        return _handle_approval_pause(
            wf_result,
            store,
            run_id,
            elapsed,
        )

    payload: dict[str, Any] = {
        "type": "workflow_completed",
        "success": wf_result.success,
        "duration_ms": elapsed,
    }
    if wf_result.cancelled:
        payload["cancelled"] = True
    broadcaster.publish(run_id, payload)
    broadcaster.close(run_id)
    return {
        "success": wf_result.success,
        "output": wf_result.output,
        "errors": wf_result.errors,
        "duration_ms": elapsed,
        "cancelled": wf_result.cancelled,
    }


def _handle_approval_pause(
    wf_result: WorkflowResult,
    store: Any,
    run_id: str,
    elapsed: int,
) -> dict[str, Any]:
    """Persist an approval record and pause the workflow run.

    Args:
        wf_result: The workflow result with approval data.
        store: Agent store for DB persistence.
        run_id: Current workflow run ID.
        elapsed: Elapsed time in milliseconds.

    Returns:
        Result dict with awaiting_approval flag.
    """
    from pygubernator.db.models import WorkflowApproval

    output = wf_result.output
    checkpoint = output.get("__checkpoint__", {})
    node_id = output.get("approval_node_id", "")
    prompt = output.get("approval_prompt", "")
    timeout = output.get("timeout_seconds", 86400)

    approval = WorkflowApproval(
        workflow_run_id=run_id,
        node_id=node_id,
        prompt=prompt,
        status="pending",
        checkpoint_json=checkpoint,
        timeout_seconds=timeout,
    )
    sess = getattr(store, "session", None)
    if sess is not None:
        sess.add(approval)

    run_row = store.get_workflow_run(run_id)
    if run_row is not None:
        store.update_workflow_run(
            run_row,
            status="awaiting_approval",
        )
    store.commit()

    broadcaster.publish(
        run_id,
        {
            "type": "workflow_awaiting_approval",
            "node_id": node_id,
            "prompt": prompt,
            "duration_ms": elapsed,
        },
    )
    return {
        "success": False,
        "output": {
            "approval_node_id": node_id,
            "approval_prompt": prompt,
        },
        "errors": [],
        "duration_ms": elapsed,
        "awaiting_approval": True,
        "approval_id": approval.id,
    }


def resume_workflow(
    approval_id: str,
    response_data: dict[str, Any],
    store: Any,
    actor: str,
) -> dict[str, Any]:
    """Resume a paused workflow after human approval.

    Args:
        approval_id: The approval record ID.
        response_data: Human response (approved, comment, etc.).
        store: Agent store for DB persistence.
        actor: Username of the responder.

    Returns:
        Result dict from the resumed workflow execution.
    """
    from pygubernator.db.models import WorkflowApproval
    from pygubernator.workflow._engine import WorkflowEngine
    from pygubernator.workflow.config._loader import WorkflowLoader

    sess = getattr(store, "session", None)
    if sess is None:
        return _error_result("No DB session available")

    approval = sess.get(WorkflowApproval, approval_id)
    if approval is None:
        return _error_result("Approval not found")
    if approval.status != "pending":
        return _error_result(f"Approval already resolved: {approval.status}")

    decision = response_data.get("decision", "approved")
    approval.status = decision
    approval.response_json = response_data
    approval.responded_by = actor
    approval.responded_at = datetime.now(UTC)

    run_id = approval.workflow_run_id
    run_row = store.get_workflow_run(run_id)
    if run_row is None:
        return _error_result("Workflow run not found")

    if decision == "rejected":
        store.update_workflow_run(
            run_row,
            status="failed",
            error_message="Approval rejected",
            completed_at=datetime.now(UTC),
        )
        store.commit()
        return {
            "success": False,
            "output": {},
            "errors": ["Approval rejected"],
            "duration_ms": 0,
        }

    store.update_workflow_run(run_row, status="running")
    store.commit()

    checkpoint = dict(approval.checkpoint_json or {})
    node_id = approval.node_id

    # Rebuild workflow spec from the version
    wf_version_id = run_row.workflow_version_id
    if not wf_version_id:
        return _error_result("No workflow version on run")

    versions = store.list_workflow_versions(run_row.workflow_id)
    version = next(
        (v for v in versions if v.id == wf_version_id),
        None,
    )
    if version is None:
        return _error_result("Workflow version not found")

    loader = WorkflowLoader()
    try:
        spec = loader.load_dict(version.spec_json)
    except Exception as exc:
        return _error_result(f"Invalid spec: {exc}")

    registry = build_node_registry()
    engine = WorkflowEngine(
        spec=spec,
        registry=registry,
        node_timeout=_NODE_TIMEOUT,
    )

    start = time.monotonic()
    try:
        wf_result = asyncio.run(
            asyncio.wait_for(
                engine.run_from_checkpoint(
                    checkpoint,
                    node_id,
                    response_data,
                ),
                timeout=_WORKFLOW_TIMEOUT,
            )
        )
    except Exception as exc:
        elapsed = int((time.monotonic() - start) * 1000)
        logger.error(
            "Resume workflow failed: %s",
            exc,
            exc_info=True,
        )
        store.update_workflow_run(
            run_row,
            status="failed",
            error_message=str(exc),
            completed_at=datetime.now(UTC),
            duration_ms=elapsed,
        )
        store.commit()
        return {
            "success": False,
            "output": {},
            "errors": [str(exc)],
            "duration_ms": elapsed,
        }

    elapsed = int((time.monotonic() - start) * 1000)

    if wf_result.awaiting_approval:
        return _handle_approval_pause(
            wf_result,
            store,
            run_id,
            elapsed,
        )

    final_status = "completed" if wf_result.success else "failed"
    store.update_workflow_run(
        run_row,
        status=final_status,
        output_json=wf_result.output,
        completed_at=datetime.now(UTC),
        duration_ms=elapsed,
        error_message=("; ".join(wf_result.errors) if wf_result.errors else None),
    )
    store.commit()
    return {
        "success": wf_result.success,
        "output": wf_result.output,
        "errors": wf_result.errors,
        "duration_ms": elapsed,
    }


def _error_result(msg: str) -> dict[str, Any]:
    """Build a failure result dict with a single error message."""
    return {
        "success": False,
        "output": {},
        "errors": [msg],
        "duration_ms": 0,
    }


class _BroadcastHandler:
    """EventHandler that publishes workflow events to SSEBroadcaster."""

    _EVENT_MAP = {
        AgentEventType.WORKFLOW_STARTED: "workflow_started",
        AgentEventType.WORKFLOW_COMPLETED: "workflow_completed",
        AgentEventType.WORKFLOW_NODE_STARTED: "node_started",
        AgentEventType.WORKFLOW_NODE_COMPLETED: "node_completed",
        AgentEventType.WORKFLOW_NODE_FAILED: "node_failed",
    }

    def __init__(self, run_id: str) -> None:
        self._run_id = run_id

    async def handle(self, event: AgentEvent) -> None:
        """Forward relevant workflow events to the SSE broadcaster."""
        sse_type = self._EVENT_MAP.get(event.event_type)
        if sse_type is None:
            return  # Ignore non-workflow events

        payload: dict[str, Any] = {
            "type": sse_type,
            "timestamp": event.timestamp,
            **event.data,
        }
        broadcaster.publish(self._run_id, payload)
