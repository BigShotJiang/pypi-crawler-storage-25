"""Service layer for LibraryTestJob lifecycle management."""

from __future__ import annotations

import uuid
from dataclasses import dataclass
from typing import Any

from sqlalchemy.exc import IntegrityError
from sqlalchemy.orm import Session

from pygubernator.db import repositories as repos
from pygubernator.db.models import LibraryTestJob, LibraryTestJobEvent
from pygubernator.services.library_testing.machine import (
    library_test_job_machine_config,
)


@dataclass(frozen=True)
class TransitionInfo:
    trigger: str
    source: list[str]
    dest: str


def _transitions() -> list[TransitionInfo]:
    cfg = library_test_job_machine_config()
    out: list[TransitionInfo] = []
    for t in cfg.get("transitions", []):
        src = t.get("source")
        sources = [src] if isinstance(src, str) else list(src or [])
        out.append(
            TransitionInfo(
                trigger=str(t["trigger"]), source=sources, dest=str(t["dest"])
            )
        )
    return out


def next_valid_triggers(current_state: str) -> list[str]:
    """Compute next valid triggers from the static machine config."""
    seen: set[str] = set()
    ordered: list[str] = []
    for t in _transitions():
        if current_state in t.source and t.trigger not in seen:
            seen.add(t.trigger)
            ordered.append(t.trigger)
    return ordered


def apply_trigger(current_state: str, trigger: str) -> tuple[bool, str, str | None]:
    """Apply a trigger to a state using the static transition table.

    Returns:
        (success, new_state, error_message)
    """
    for t in _transitions():
        if t.trigger == trigger and current_state in t.source:
            return True, t.dest, None
    return (
        False,
        current_state,
        f"Trigger {trigger!r} not allowed from state {current_state!r}",
    )


def create_job(
    db: Session,
    *,
    workspace_id: str,
    name: str,
    spec_json: dict[str, Any],
    created_by: str,
) -> LibraryTestJob:
    rec = repos.create_library_test_job(
        db,
        workspace_id=workspace_id,
        name=name,
        spec_json=spec_json,
        created_by=created_by,
        machine_name="library_test_job",
        machine_version="1.0.0",
        current_state="queued",
    )
    return rec


def submit_event(
    db: Session,
    *,
    workspace_id: str,
    job_id: str,
    trigger: str,
    actor: str,
    idempotency_key: str | None = None,
    payload_json: dict[str, Any] | None = None,
    workflow_run_id: str | None = None,
) -> tuple[LibraryTestJob, LibraryTestJobEvent]:
    """Submit an event to a job with idempotency.

    Idempotency is enforced via a unique index on
    (workspace_id, job_id, idempotency_key).
    """
    job = repos.get_library_test_job(db, job_id, workspace_id=workspace_id)
    if job is None:
        raise ValueError("job not found")

    idem = idempotency_key or f"auto-{uuid.uuid4().hex}"
    from_state = job.current_state
    ok, to_state, err = apply_trigger(from_state, trigger)

    ev = repos.create_library_test_job_event(
        db,
        workspace_id=workspace_id,
        job_id=job.id,
        trigger=trigger,
        actor=actor,
        idempotency_key=idem,
        payload_json=payload_json,
        workflow_run_id=workflow_run_id,
        from_state=from_state,
        to_state=to_state if ok else from_state,
        success=ok,
        error_message=err,
    )

    # Update the entity state only if the transition is valid.
    if ok:
        job.current_state = to_state
        job.last_workflow_run_id = workflow_run_id or job.last_workflow_run_id
        job.last_error_message = None
    else:
        job.last_error_message = err

    # If the idempotency constraint trips, fetch and return the existing event.
    try:
        db.flush()
    except IntegrityError as err:
        db.rollback()
        # Reload job (rollback invalidates local state changes).
        job = repos.get_library_test_job(db, job_id, workspace_id=workspace_id)
        if job is None:
            raise ValueError("job not found") from err
        items, _ = repos.list_library_test_job_events(
            db, job_id, workspace_id=workspace_id, page=1, page_size=1_000
        )
        for existing in items:
            if existing.idempotency_key == idem:
                return job, existing
        raise

    return job, ev


def get_job_transitions(job: LibraryTestJob) -> dict[str, Any]:
    valid = next_valid_triggers(job.current_state)
    return {
        "current_state": job.current_state,
        "next_triggers": valid,
        "blocked": [],
    }


def sync_job_from_workflow_run(
    db: Session,
    *,
    workspace_id: str,
    job_id: str,
    workflow_run_id: str,
    workflow_status: str,
    actor: str = "system",
) -> None:
    """Synchronize LibraryTestJob lifecycle based on workflow run lifecycle.

    This provides the ops usability guarantee: job state progresses without manual
    event submission.
    """
    # Start-of-run: push job into tests_running via intermediate states
    if workflow_status == "running":
        for trig in ("enqueue", "prepare_env_ok", "install_ok"):
            submit_event(
                db,
                workspace_id=workspace_id,
                job_id=job_id,
                trigger=trig,
                actor=actor,
                idempotency_key=f"wf:{workflow_run_id}:{trig}",
                payload_json={"workflow_run_id": workflow_run_id},
                workflow_run_id=workflow_run_id,
            )
        return

    # Completion: succeeded/failed/cancelled
    if workflow_status == "completed":
        for trig in ("tests_ok", "summary_ok", "publish_ok"):
            submit_event(
                db,
                workspace_id=workspace_id,
                job_id=job_id,
                trigger=trig,
                actor=actor,
                idempotency_key=f"wf:{workflow_run_id}:{trig}",
                payload_json={"workflow_run_id": workflow_run_id},
                workflow_run_id=workflow_run_id,
            )
        return

    if workflow_status in {"failed", "cancelled"}:
        if workflow_status == "cancelled":
            submit_event(
                db,
                workspace_id=workspace_id,
                job_id=job_id,
                trigger="cancel",
                actor=actor,
                idempotency_key=f"wf:{workflow_run_id}:cancel",
                payload_json={"workflow_run_id": workflow_run_id},
                workflow_run_id=workflow_run_id,
            )
            return
        # failed
        for trig in ("tests_failed", "summary_ok", "publish_failed"):
            submit_event(
                db,
                workspace_id=workspace_id,
                job_id=job_id,
                trigger=trig,
                actor=actor,
                idempotency_key=f"wf:{workflow_run_id}:{trig}",
                payload_json={"workflow_run_id": workflow_run_id},
                workflow_run_id=workflow_run_id,
            )
        return


__all__ = [
    "create_job",
    "get_job_transitions",
    "submit_event",
    "sync_job_from_workflow_run",
]
