"""Workflow run diff and audit bundle routes."""

from __future__ import annotations

from fastapi import APIRouter, HTTPException, Query

from pygubernator.api.deps import AgentStore, CurrentActor
from pygubernator.services.replay.diff import diff_step_outputs
from pygubernator.services.replay.export import chain_hash

router = APIRouter(prefix="/api/v1/replay", tags=["replay"])


@router.get("/workflow-runs/diff")
def diff_workflow_runs(
    store: AgentStore,
    _: CurrentActor,
    left_run_id: str = Query(...),
    right_run_id: str = Query(...),
) -> dict:
    left = store.get_workflow_run(left_run_id)
    right = store.get_workflow_run(right_run_id)
    if not left or not right:
        raise HTTPException(
            status_code=404, detail="One or both workflow runs not found"
        )

    left_steps = [s.__dict__ for s in store.list_step_runs(left_run_id)]
    right_steps = [s.__dict__ for s in store.list_step_runs(right_run_id)]

    # Normalize to safe dicts
    def _norm(rows):
        out = []
        for r in rows:
            out.append(
                {
                    "node_id": r.get("node_id"),
                    "node_type": r.get("node_type"),
                    "status": r.get("status"),
                    "output_json": r.get("output_json") or {},
                    "error_message": r.get("error_message"),
                }
            )
        return out

    result = diff_step_outputs(
        left_steps=_norm(left_steps), right_steps=_norm(right_steps)
    )
    first = result.get("first_divergence")
    summary = None
    if isinstance(first, dict):
        kind = first.get("kind")
        node_id = first.get("node_id")
        node_type = first.get("node_type")
        if kind == "missing":
            summary = f"Node {node_id} missing on one side"
        elif kind == "status_changed":
            summary = (
                f"{node_type or 'node'} {node_id} status changed: "
                f"{first.get('left_status')} → {first.get('right_status')}"
            )
        elif kind == "output_changed":
            summary = f"{node_type or 'node'} {node_id} output changed"
    return {
        "left_run_id": left_run_id,
        "right_run_id": right_run_id,
        "summary": summary,
        **result,
    }


@router.get("/workflow-runs/{run_id}/audit-bundle")
def export_workflow_run_audit_bundle(
    run_id: str, store: AgentStore, _: CurrentActor
) -> dict:
    run = store.get_workflow_run(run_id)
    if not run:
        raise HTTPException(status_code=404, detail="Workflow run not found")

    steps = store.list_step_runs(run_id)
    timeline = [
        {
            "node_id": s.node_id,
            "node_type": s.node_type,
            "status": s.status,
            "output_handle": s.output_handle,
            "input_json": s.input_json,
            "output_json": s.output_json,
            "error_message": s.error_message,
            "started_at": s.started_at.isoformat() if s.started_at else None,
            "completed_at": s.completed_at.isoformat() if s.completed_at else None,
            "duration_ms": s.duration_ms,
        }
        for s in steps
    ]

    chained = chain_hash(timeline, seed=run_id)
    return {
        "run": {
            "id": run.id,
            "workflow_id": run.workflow_id,
            "workflow_version_id": run.workflow_version_id,
            "status": run.status,
            "created_by": run.created_by,
            "started_at": run.started_at.isoformat() if run.started_at else None,
            "completed_at": run.completed_at.isoformat() if run.completed_at else None,
            "duration_ms": run.duration_ms,
            "error_message": run.error_message,
            "input_json": run.input_json,
            "output_json": run.output_json,
            "variables_json": run.variables_json,
        },
        "timeline": chained,
        "redactions": [],
        "artifacts": [],
    }
