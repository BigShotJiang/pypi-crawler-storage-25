"""FastAPI dependencies for auth and db."""

from __future__ import annotations

import hmac
import time
from typing import Annotated, Any

from fastapi import Depends, HTTPException, status
from fastapi.security import HTTPAuthorizationCredentials, HTTPBearer
from sqlalchemy.orm import Session

from pygubernator.agent_store.sqlalchemy import SQLAlchemyAgentStore
from pygubernator.config import (
    get_auth_admin_group_claims,
    get_auth_admin_role_claims,
    get_auth_jwt_secret,
    get_auth_service_introspect_path,
    get_auth_service_url,
    get_auth_users,
    is_auth_disabled,
)
from pygubernator.db.session import get_db

security = HTTPBearer(auto_error=False)
ACCESS_TOKEN_EXPIRE_SECONDS = 3600


def _constant_time_compare(a: str, b: str) -> bool:
    return hmac.compare_digest(a.encode("utf-8"), b.encode("utf-8"))


def verify_credentials(username: str, password: str) -> dict[str, str] | None:
    for user in get_auth_users():
        if _constant_time_compare(
            username, user["username"]
        ) and _constant_time_compare(password, user["password"]):
            return {"username": user["username"], "role": user.get("role", "User")}
    return None


def _import_jwt():
    try:
        import jwt as _jwt

        return _jwt
    except ImportError:
        raise ImportError(
            "PyJWT is required for JWT auth. "
            "Install with: pip install pygubernator[api] or pip install PyJWT"
        ) from None


def create_access_token(
    username: str,
    role: str = "User",
    expires_delta_seconds: int = ACCESS_TOKEN_EXPIRE_SECONDS,
) -> str:
    jwt = _import_jwt()
    secret = get_auth_jwt_secret()
    if not secret:
        raise ValueError(
            "JWT secret not configured "
            "(set PYGUBERNATOR_AUTH_JWT_SECRET in env or pygubernator.cfg [auth])"
        )
    payload = {
        "sub": username,
        "role": role,
        "exp": int(time.time()) + expires_delta_seconds,
        "iat": int(time.time()),
    }
    return jwt.encode(payload, secret, algorithm="HS256")


def verify_jwt(token: str) -> dict[str, Any] | None:
    try:
        jwt = _import_jwt()
    except ImportError:
        return None
    secret = get_auth_jwt_secret()
    if not secret:
        return None
    try:
        payload = jwt.decode(token, secret, algorithms=["HS256"])
        return payload
    except jwt.PyJWTError:
        return None


def _as_str_set(value: Any) -> set[str]:
    if isinstance(value, str):
        return {value.lower()}
    if isinstance(value, list):
        return {str(v).lower() for v in value}
    return set()


def _payload_roles(payload: dict[str, Any]) -> set[str]:
    roles = payload.get("roles") or payload.get("role")
    return _as_str_set(roles) if roles else set()


def _payload_groups(payload: dict[str, Any]) -> set[str]:
    groups = payload.get("groups") or payload.get("group")
    return _as_str_set(groups) if groups else set()


def _resolve_role_from_claims(payload: dict[str, Any]) -> str:
    roles = _payload_roles(payload)
    if roles & get_auth_admin_role_claims():
        return "Admin"
    groups = _payload_groups(payload)
    if groups & get_auth_admin_group_claims():
        return "Admin"
    return "User"


async def introspect_token(token: str) -> dict[str, Any] | None:
    base = get_auth_service_url()
    path = get_auth_service_introspect_path()
    if not base or not path:
        return None
    url = f"{base.rstrip('/')}{path}"
    try:
        import httpx

        async with httpx.AsyncClient() as client:
            response = await client.post(
                url,
                data={"token": token},
                headers={"Content-Type": "application/x-www-form-urlencoded"},
                timeout=5.0,
            )
            if response.status_code != 200:
                return None
            data = response.json()
            if not data.get("active", False):
                return None
            return data
    except Exception:
        return None


async def get_current_actor(
    credentials: Annotated[
        HTTPAuthorizationCredentials | None, Depends(security)
    ] = None,
) -> dict[str, str | bool]:
    if is_auth_disabled():
        return {"actor": "anonymous", "role": "Admin", "auth_disabled": True}

    token = credentials.credentials if credentials and credentials.credentials else None
    if not token:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Not authenticated",
            headers={"WWW-Authenticate": "Bearer"},
        )

    payload = verify_jwt(token)
    if payload is None and (
        get_auth_service_url() and get_auth_service_introspect_path()
    ):
        payload = await introspect_token(token)

    if payload is None:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Invalid or expired token",
            headers={"WWW-Authenticate": "Bearer"},
        )

    username = payload.get("sub") or payload.get("username")
    if not username:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Invalid token payload",
            headers={"WWW-Authenticate": "Bearer"},
        )

    role = payload.get("role") or _resolve_role_from_claims(payload)
    return {"actor": str(username), "role": str(role), "auth_disabled": False}


def require_admin(actor: CurrentActor) -> dict[str, str | bool]:
    if actor.get("auth_disabled"):
        return actor
    admin_claims = get_auth_admin_role_claims()
    if str(actor.get("role", "")).lower() not in {c.lower() for c in admin_claims} | {
        "owner"
    }:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Admin role required",
        )
    return actor


DbSession = Annotated[Session, Depends(get_db)]


def get_agent_store(db: DbSession, workspace_id: WorkspaceId) -> SQLAlchemyAgentStore:
    """Request-scoped persistence client for control-plane routes."""
    return SQLAlchemyAgentStore(session=db, workspace_id=workspace_id)


AgentStore = Annotated[SQLAlchemyAgentStore, Depends(get_agent_store)]
CurrentActor = Annotated[dict[str, str | bool], Depends(get_current_actor)]
AdminActor = Annotated[dict[str, str | bool], Depends(require_admin)]


def get_workspace_id(actor: CurrentActor) -> str:
    """Extract workspace_id from actor claims.

    Falls back to ``"default"`` when the JWT does not carry a
    workspace claim.

    Args:
        actor: Decoded actor dict from the auth dependency.

    Returns:
        The workspace identifier string.
    """
    return str(actor.get("workspace_id", "default"))


WorkspaceId = Annotated[str, Depends(get_workspace_id)]
