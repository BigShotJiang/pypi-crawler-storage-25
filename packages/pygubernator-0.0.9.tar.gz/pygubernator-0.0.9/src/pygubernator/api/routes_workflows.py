"""Workflow management and execution routes."""

from __future__ import annotations

import asyncio
import json
import logging
from datetime import UTC, datetime
from typing import cast

from fastapi import APIRouter, HTTPException, Query, Request
from sqlalchemy.orm import Session
from starlette.responses import StreamingResponse

from pygubernator.agent_store.sqlalchemy import SQLAlchemyAgentStore
from pygubernator.api.deps import AgentStore, CurrentActor
from pygubernator.api.models import (
    PageMeta,
    WorkflowCreateRequest,
    WorkflowExecuteRequest,
    WorkflowNodeFieldOut,
    WorkflowNodePortOut,
    WorkflowNodeTypeOut,
    WorkflowOut,
    WorkflowRunOut,
    WorkflowStepRunOut,
    WorkflowToolPresetOut,
    WorkflowUpdateRequest,
    WorkflowVersionCreateRequest,
    WorkflowVersionOut,
)
from pygubernator.db import repositories as repos
from pygubernator.services._workflows import execute_workflow

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/api/v1/workflows", tags=["workflows"])


@router.get("/node-types")
def list_workflow_node_types_route(_: CurrentActor) -> dict:
    """List workflow node metadata for editor-driven palettes and inspectors."""
    from pygubernator.services._workflows import build_node_registry

    registry = build_node_registry()
    items = [
        WorkflowNodeTypeOut(
            type_name=desc.type_name,
            display_name=desc.display_name,
            category=desc.category,
            description=desc.description,
            color=desc.color,
            icon=desc.icon,
            inputs=[
                WorkflowNodePortOut(
                    name=port.name,
                    direction=port.direction,
                    kind=port.kind,
                    label=port.label,
                    multiple=port.multiple,
                )
                for port in desc.inputs
            ],
            outputs=[
                WorkflowNodePortOut(
                    name=port.name,
                    direction=port.direction,
                    kind=port.kind,
                    label=port.label,
                    multiple=port.multiple,
                )
                for port in desc.outputs
            ],
            fields=[
                WorkflowNodeFieldOut(
                    name=field.name,
                    field_type=field.field_type,
                    label=field.label,
                    required=field.required,
                    default=field.default,
                    help_text=field.help_text,
                    options=list(field.options),
                    placeholder=field.placeholder,
                    visible_if=field.visible_if,
                )
                for field in desc.fields
            ],
            tags=list(desc.tags),
            supports_streaming=desc.supports_streaming,
            supports_checkpointing=desc.supports_checkpointing,
            supports_subgraph=desc.supports_subgraph,
            runtime_kind=desc.runtime_kind,
        )
        for desc in registry.list_descriptions()
    ]
    return {"items": [item.model_dump() for item in items]}


@router.get("/tool-presets")
def list_workflow_tool_presets_route(_: CurrentActor) -> dict:
    """List built-in tool integration presets for the Tool node inspector."""
    from pygubernator.workflow.tool_presets import TOOL_INTEGRATION_PRESETS

    items = [
        WorkflowToolPresetOut(
            id=p.id,
            label=p.label,
            name=p.name,
            factory_module=p.factory_module,
            factory_function=p.factory_function,
            env_hint=p.env_hint,
        ).model_dump()
        for p in TOOL_INTEGRATION_PRESETS
    ]
    return {"items": items}


@router.post("", response_model=WorkflowOut)
def create_workflow_route(
    payload: WorkflowCreateRequest,
    store: AgentStore,
    actor: CurrentActor,
) -> WorkflowOut:
    """Create a new workflow."""
    wf = store.create_workflow(
        name=payload.name,
        description=payload.description,
        owner=payload.owner,
    )
    store.create_audit(
        actor=actor["actor"],
        action="workflow.create",
        resource_type="workflow",
        resource_id=wf.id,
        details=payload.model_dump(),
    )
    store.commit()
    store.refresh(wf)
    return WorkflowOut.model_validate(wf)


@router.get("")
def list_workflows_route(
    store: AgentStore,
    _: CurrentActor,
    page: int = Query(1, ge=1),
    page_size: int = Query(25, ge=1, le=100),
    status: str | None = None,
    q: str | None = None,
) -> dict:
    """List workflows with pagination."""
    items, total = store.list_workflows(page=page, page_size=page_size, status=status)
    if q:
        ql = q.lower()
        items = [i for i in items if ql in i.name.lower() or ql in i.owner.lower()]
    return {
        "items": [WorkflowOut.model_validate(w).model_dump() for w in items],
        "meta": PageMeta(total=total, page=page, page_size=page_size).model_dump(),
    }


@router.get("/{workflow_id}", response_model=WorkflowOut)
def get_workflow_route(
    workflow_id: str, store: AgentStore, _: CurrentActor
) -> WorkflowOut:
    """Get workflow detail."""
    wf = store.get_workflow(workflow_id)
    if not wf:
        raise HTTPException(status_code=404, detail="Workflow not found")
    return WorkflowOut.model_validate(wf)


@router.patch("/{workflow_id}", response_model=WorkflowOut)
def update_workflow_route(
    workflow_id: str,
    payload: WorkflowUpdateRequest,
    store: AgentStore,
    actor: CurrentActor,
) -> WorkflowOut:
    """Update workflow metadata."""
    wf = store.get_workflow(workflow_id)
    if not wf:
        raise HTTPException(status_code=404, detail="Workflow not found")
    updates = payload.model_dump(exclude_none=True)
    store.update_workflow(wf, **updates)
    store.create_audit(
        actor=actor["actor"],
        action="workflow.update",
        resource_type="workflow",
        resource_id=workflow_id,
        details=updates,
    )
    store.commit()
    store.refresh(wf)
    return WorkflowOut.model_validate(wf)


@router.delete("/{workflow_id}", response_model=WorkflowOut)
def delete_workflow_route(
    workflow_id: str,
    store: AgentStore,
    actor: CurrentActor,
) -> WorkflowOut:
    """Soft-delete a workflow by setting status to 'deleted'."""
    wf = store.get_workflow(workflow_id)
    if not wf:
        raise HTTPException(status_code=404, detail="Workflow not found")
    store.update_workflow(wf, status="deleted")
    store.create_audit(
        actor=actor["actor"],
        action="workflow.delete",
        resource_type="workflow",
        resource_id=workflow_id,
        details={"status": "deleted"},
    )
    store.commit()
    store.refresh(wf)
    return WorkflowOut.model_validate(wf)


@router.post("/{workflow_id}/versions", response_model=WorkflowVersionOut)
def create_version_route(
    workflow_id: str,
    payload: WorkflowVersionCreateRequest,
    store: AgentStore,
    actor: CurrentActor,
    request: Request,
) -> WorkflowVersionOut:
    """Create a workflow version, or replace its spec if this version already exists."""
    if not store.get_workflow(workflow_id):
        raise HTTPException(status_code=404, detail="Workflow not found")
    wv = store.create_workflow_version(
        workflow_id=workflow_id,
        version=payload.version,
        spec_json=payload.spec_json,
        created_by=actor["actor"],
    )

    # Optimistic-concurrency check
    if (
        payload.expected_revision is not None
        and wv.revision != payload.expected_revision
    ):
        raise HTTPException(
            status_code=409,
            detail=(
                f"Revision conflict: expected"
                f" {payload.expected_revision},"
                f" current {wv.revision}"
            ),
        )

    # Bump revision on every save
    wv.revision = (wv.revision or 0) + 1

    store.create_audit(
        actor=actor["actor"],
        action="workflow.version.create",
        resource_type="workflow_version",
        resource_id=wv.id,
        details={"version": payload.version},
    )
    store.commit()
    store.refresh(wv)

    # Publish config-change event for real-time collaboration
    _publish_change(request, wv, actor["actor"])

    return WorkflowVersionOut.model_validate(wv)


def _publish_change(
    request: Request,
    wv: object,
    actor_name: str,
) -> None:
    """Publish a workflow-saved ChangeEvent if the bus exists."""
    from pygubernator.events import ChangeBus, ChangeEvent

    bus: ChangeBus | None = getattr(request.app.state, "change_bus", None)
    if bus is None:
        return
    bus.publish(
        ChangeEvent(
            topic="workflow",
            action="saved",
            resource_id=getattr(wv, "workflow_id", ""),
            revision=getattr(wv, "revision", 0),
            actor=actor_name,
            metadata={
                "version_id": getattr(wv, "id", ""),
                "version": getattr(wv, "version", ""),
            },
        )
    )


@router.get("/{workflow_id}/versions")
def list_versions_route(workflow_id: str, store: AgentStore, _: CurrentActor) -> dict:
    """List all versions for a workflow."""
    versions = store.list_workflow_versions(workflow_id)
    return {
        "items": [WorkflowVersionOut.model_validate(v).model_dump() for v in versions],
    }


@router.post(
    "/{workflow_id}/versions/{version_id}/activate",
    response_model=WorkflowOut,
)
def activate_version_route(
    workflow_id: str,
    version_id: str,
    store: AgentStore,
    actor: CurrentActor,
) -> WorkflowOut:
    """Activate a specific workflow version."""
    wf = store.get_workflow(workflow_id)
    if not wf:
        raise HTTPException(status_code=404, detail="Workflow not found")
    versions = store.list_workflow_versions(workflow_id)
    if not any(v.id == version_id for v in versions):
        raise HTTPException(status_code=404, detail="Version not found")
    store.activate_workflow_version(wf, version_id)
    store.create_audit(
        actor=actor["actor"],
        action="workflow.version.activate",
        resource_type="workflow",
        resource_id=workflow_id,
        details={"version_id": version_id},
    )
    store.commit()
    store.refresh(wf)
    return WorkflowOut.model_validate(wf)


def _run_workflow_background(
    spec_json: dict,
    input_json: dict,
    run_id: str,
    session_id: str | None = None,
) -> None:
    """Execute a workflow in a background thread with its own DB session."""
    from pygubernator.db.session import get_db

    db = cast(Session, next(get_db()))
    store = SQLAlchemyAgentStore(session=db)
    try:
        result = execute_workflow(
            spec_json,
            input_json,
            store,
            run_id,
            session_id=session_id,
        )

        run = store.get_workflow_run(run_id)
        if not run:
            logger.error("[BG] Run %s vanished from DB", run_id[:12])
            return

        if result.get("cancelled"):
            store.update_workflow_run(
                run,
                status="cancelled",
                error_message="Cancelled by user",
                completed_at=datetime.now(UTC),
                duration_ms=result.get("duration_ms"),
            )
        elif result["success"]:
            store.update_workflow_run(
                run,
                status="completed",
                output_json=result.get("output", {}),
                completed_at=datetime.now(UTC),
                duration_ms=result.get("duration_ms"),
            )
        else:
            store.update_workflow_run(
                run,
                status="failed",
                error_message="; ".join(result.get("errors", [])),
                completed_at=datetime.now(UTC),
                duration_ms=result.get("duration_ms"),
            )
        store.commit()

        # LibraryTestJob auto-sync: if workflow input includes job_id, update lifecycle.
        try:
            job_id = (input_json or {}).get("job_id")
            if isinstance(job_id, str) and job_id:
                from pygubernator.services.library_testing.service import (
                    sync_job_from_workflow_run,
                )

                sync_job_from_workflow_run(
                    store.session,
                    workspace_id=getattr(store, "workspace_id", "default"),
                    job_id=job_id,
                    workflow_run_id=run_id,
                    workflow_status=str(getattr(run, "status", "")),
                    actor="system",
                )
                store.commit()
        except Exception:
            logger.debug("LibraryTestJob sync failed", exc_info=True)
        logger.info(
            "[BG] Run %s finished: success=%s duration=%sms",
            run_id[:12],
            result.get("success"),
            result.get("duration_ms"),
        )
    except Exception as exc:
        logger.error("[BG] Run %s crashed: %s", run_id[:12], exc, exc_info=True)
        try:
            run = store.get_workflow_run(run_id)
            if run:
                store.update_workflow_run(
                    run,
                    status="failed",
                    error_message=f"Internal error: {type(exc).__name__}: {exc}",
                    completed_at=datetime.now(UTC),
                )
                store.commit()
        except Exception:
            logger.error("[BG] Failed to update run %s status", run_id[:12])
    finally:
        db.close()


@router.post("/{workflow_id}/execute")
def execute_workflow_route(
    workflow_id: str,
    payload: WorkflowExecuteRequest,
    store: AgentStore,
    actor: CurrentActor,
) -> dict:
    """Start workflow execution and return immediately with run ID.

    The workflow runs in a background thread. Poll GET /runs/{run_id}
    to track progress.
    """
    import threading

    logger.info(
        "[EXEC] Start execute workflow_id=%s actor=%s input_keys=%s",
        workflow_id,
        actor.get("actor"),
        list(payload.input_json.keys()),
    )
    wf = store.get_workflow(workflow_id)
    if not wf:
        raise HTTPException(status_code=404, detail="Workflow not found")

    versions = store.list_workflow_versions(workflow_id)
    if payload.version_id:
        version = next((v for v in versions if v.id == payload.version_id), None)
    else:
        version = next((v for v in versions if v.active), None)
        if not version and versions:
            version = versions[0]

    if not version:
        raise HTTPException(status_code=400, detail="No workflow version available")

    run = store.create_workflow_run(
        workflow_id=workflow_id,
        workflow_version_id=version.id,
        status="running",
        input_json=payload.input_json,
        created_by=actor["actor"],
        session_id=payload.session_id,
    )
    run.started_at = datetime.now(UTC)
    store.commit()
    store.refresh(run)

    run_data = WorkflowRunOut.model_validate(run).model_dump()
    logger.info("[EXEC] Created run %s, launching background execution", run.id[:12])

    # Launch execution in background thread with its own DB session
    thread = threading.Thread(
        target=_run_workflow_background,
        args=(version.spec_json, payload.input_json, run.id, payload.session_id),
        daemon=True,
        name=f"wf-run-{run.id[:8]}",
    )
    thread.start()

    # Return immediately — UI polls GET /runs/{run_id} for status
    return {
        "run": run_data,
        "result": {
            "success": True,
            "output": {},
            "errors": [],
            "duration_ms": 0,
        },
    }


@router.get("/runs/list")
def list_runs_route(
    store: AgentStore,
    _: CurrentActor,
    page: int = Query(1, ge=1),
    page_size: int = Query(25, ge=1, le=100),
    workflow_id: str | None = None,
    status: str | None = None,
    search: str | None = None,
    created_after: datetime | None = None,
    created_before: datetime | None = None,
) -> dict:
    """List workflow runs."""
    items, total = store.list_workflow_runs(
        page=page,
        page_size=page_size,
        workflow_id=workflow_id,
        status=status,
        search=search,
        created_after=created_after,
        created_before=created_before,
    )
    # Enrich with workflow names for display
    wf_ids = {r.workflow_id for r in items}
    wf_names: dict[str, str] = {}
    for wid in wf_ids:
        wf = store.get_workflow(wid)
        if wf:
            wf_names[wid] = wf.name

    enriched = []
    for r in items:
        data = WorkflowRunOut.model_validate(r).model_dump()
        data["workflow_name"] = wf_names.get(r.workflow_id, "")
        enriched.append(data)

    return {
        "items": enriched,
        "meta": PageMeta(total=total, page=page, page_size=page_size).model_dump(),
    }


@router.get("/{workflow_id}/sessions")
def list_sessions_route(
    workflow_id: str,
    store: AgentStore,
    _: CurrentActor,
) -> dict:
    """List distinct sessions for a workflow with latest run info."""
    wf = store.get_workflow(workflow_id)
    if not wf:
        raise HTTPException(status_code=404, detail="Workflow not found")
    sessions = store.list_workflow_sessions(workflow_id)
    return {"items": sessions}


@router.delete("/{workflow_id}/sessions/{session_id}")
def delete_session_route(
    workflow_id: str,
    session_id: str,
    store: AgentStore,
    _: CurrentActor,
) -> dict:
    """Clear in-memory cache for a session."""
    from pygubernator.workflow.nodes._memory import clear_session_stores

    clear_session_stores(session_id)
    return {"detail": f"Session {session_id} cache cleared"}


@router.post("/runs/{run_id}/cancel")
def cancel_workflow_run_route(
    run_id: str,
    store: AgentStore,
    actor: CurrentActor,
) -> dict:
    """Request cancellation of a running workflow (cooperative, between DAG levels)."""
    run = store.get_workflow_run(run_id)
    if not run:
        raise HTTPException(status_code=404, detail="Workflow run not found")
    if run.status != "running":
        raise HTTPException(
            status_code=409,
            detail=f"Run cannot be cancelled (status={run.status})",
        )
    store.update_workflow_run(run, status="cancelled")
    store.create_audit(
        actor=actor["actor"],
        action="workflow.run.cancel",
        resource_type="workflow_run",
        resource_id=run_id,
        details={},
    )
    store.commit()
    store.refresh(run)
    return {
        "run": WorkflowRunOut.model_validate(run).model_dump(),
        "message": "Cancellation requested; run stops after the current DAG level.",
    }


@router.delete("/runs/{run_id}", status_code=204)
def delete_workflow_run_route(
    run_id: str,
    store: AgentStore,
    actor: CurrentActor,
) -> None:
    """Permanently delete a workflow run and its step records."""
    run = store.get_workflow_run(run_id)
    if not run:
        raise HTTPException(status_code=404, detail="Workflow run not found")
    if run.status == "running":
        raise HTTPException(
            status_code=409,
            detail=(
                "Run cannot be deleted while running; "
                "cancel it first or wait until it finishes."
            ),
        )
    if not store.delete_workflow_run(run_id):
        raise HTTPException(status_code=404, detail="Workflow run not found")
    store.create_audit(
        actor=actor["actor"],
        action="workflow.run.delete",
        resource_type="workflow_run",
        resource_id=run_id,
        details={},
    )
    store.commit()


@router.get("/runs/{run_id}")
def get_run_detail_route(run_id: str, store: AgentStore, _: CurrentActor) -> dict:
    """Get workflow run detail with step timeline."""
    run = store.get_workflow_run(run_id)
    if not run:
        raise HTTPException(status_code=404, detail="Workflow run not found")
    steps = store.list_step_runs(run_id)
    return {
        "run": WorkflowRunOut.model_validate(run).model_dump(),
        "steps": [WorkflowStepRunOut.model_validate(s).model_dump() for s in steps],
    }


@router.get("/runs/{run_id}/trace")
def get_run_trace_route(run_id: str, store: AgentStore, _: CurrentActor) -> dict:
    """Get full step-by-step trace with timing for a workflow run."""
    run = store.get_workflow_run(run_id)
    if not run:
        raise HTTPException(status_code=404, detail="Workflow run not found")
    steps = store.list_step_runs(run_id)
    trace = []
    for step in steps:
        trace.append(
            {
                "node_id": step.node_id,
                "node_type": step.node_type,
                "status": step.status,
                "input": step.input_json,
                "output": step.output_json,
                "error": step.error_message,
                "output_handle": step.output_handle,
                "started_at": (
                    step.started_at.isoformat() if step.started_at else None
                ),
                "completed_at": (
                    step.completed_at.isoformat() if step.completed_at else None
                ),
                "duration_ms": step.duration_ms,
            }
        )
    return {
        "run_id": run_id,
        "workflow_id": run.workflow_id,
        "status": run.status,
        "trace": trace,
    }


@router.post("/runs/{run_id}/replay")
def replay_workflow_run_route(
    run_id: str, store: AgentStore, actor: CurrentActor
) -> dict:
    """Create a deterministic recorded replay of a workflow run.

    Phase 1: supports recorded replay for nodes that write RecordedOutput rows.
    """
    source = store.get_workflow_run(run_id)
    if not source:
        raise HTTPException(status_code=404, detail="Workflow run not found")
    if not source.workflow_version_id:
        raise HTTPException(status_code=400, detail="Run has no workflow_version_id")

    # Load recorded outputs from DB and inject into replay input.
    recorded_rows = repos.list_recorded_outputs(
        store.session,
        workspace_id=store.workspace_id,
        workflow_run_id=run_id,
    )
    recorded_map = {r.node_id: r.payload_json for r in recorded_rows}

    # Fail-fast: if the source run contains library_test nodes, it must have
    # recorded outputs for them.
    steps = store.list_step_runs(run_id)
    required_nodes = [s.node_id for s in steps if s.node_type == "library_test"]
    missing = [nid for nid in required_nodes if nid not in recorded_map]
    if missing:
        raise HTTPException(
            status_code=409,
            detail=(
                "Recorded replay unavailable: missing recorded outputs for "
                f"node(s): {missing}. Re-run the workflow to record outputs first."
            ),
        )

    replay = store.create_workflow_run(
        workflow_id=source.workflow_id,
        workflow_version_id=source.workflow_version_id,
        status="running",
        input_json={
            **(source.input_json or {}),
            "__replay_of__": run_id,
            "__replay_mode__": "recorded",
            "__recorded_outputs__": recorded_map,
        },
        created_by=str(actor.get("actor", "system")),
        session_id=source.session_id,
    )
    replay.started_at = datetime.now(UTC)
    store.create_audit(
        actor=str(actor["actor"]),
        action="workflow.run.replay",
        resource_type="workflow_run",
        resource_id=replay.id,
        details={"source_run_id": run_id, "mode": "recorded"},
    )
    store.commit()
    store.refresh(replay)

    # Find spec_json for the version and run in background (reuse helper).
    versions = store.list_workflow_versions(source.workflow_id)
    version = next((v for v in versions if v.id == source.workflow_version_id), None)
    if version is None:
        raise HTTPException(status_code=404, detail="Workflow version not found")

    import threading

    thread = threading.Thread(
        target=_run_workflow_background,
        args=(version.spec_json, replay.input_json, replay.id, replay.session_id),
        daemon=True,
        name=f"wf-replay-{replay.id[:8]}",
    )
    thread.start()

    return {"ok": True, "new_run_id": replay.id}


@router.get("/runs/{run_id}/stream")
async def stream_run(
    run_id: str,
    token: str = Query(..., description="Bearer token for SSE auth"),
) -> StreamingResponse:
    """SSE stream of workflow execution events.

    Connect after POST /execute returns a run_id. Events are pushed
    in real-time as each node starts/completes. The stream ends with
    a ``done`` event.

    Auth is via query param because EventSource cannot send headers.
    """
    from pygubernator._sse import broadcaster
    from pygubernator.api.deps import verify_jwt

    payload = verify_jwt(token)
    if not payload:
        raise HTTPException(status_code=401, detail="Invalid or expired token")

    async def event_generator():
        queue = broadcaster.subscribe(run_id)
        try:
            while True:
                try:
                    event = await asyncio.wait_for(queue.get(), timeout=600)
                except TimeoutError:
                    yield f"data: {json.dumps({'type': 'timeout'})}\n\n"
                    break
                yield f"data: {json.dumps(event)}\n\n"
                if event.get("type") == "done":
                    break
        finally:
            broadcaster.unsubscribe(run_id, queue)

    return StreamingResponse(
        event_generator(),
        media_type="text/event-stream",
        headers={
            "Cache-Control": "no-cache",
            "Connection": "keep-alive",
            "X-Accel-Buffering": "no",
        },
    )


@router.post("/runs/{run_id}/approve")
def approve_workflow_run(
    run_id: str,
    payload: dict,
    actor: CurrentActor,
    store: AgentStore,
) -> dict:
    """Approve a pending workflow approval, resuming execution."""
    from pygubernator.db.models import WorkflowApproval
    from pygubernator.services._workflows import resume_workflow

    run = store.get_workflow_run(run_id)
    if not run:
        raise HTTPException(
            status_code=404,
            detail="Workflow run not found",
        )
    if run.status != "awaiting_approval":
        raise HTTPException(
            status_code=409,
            detail=(f"Run is not awaiting approval (status={run.status})"),
        )

    sess = store.session
    approval = (
        sess.query(WorkflowApproval)
        .filter_by(workflow_run_id=run_id, status="pending")
        .first()
    )
    if not approval:
        raise HTTPException(
            status_code=404,
            detail="No pending approval for this run",
        )

    result = resume_workflow(
        approval_id=approval.id,
        response_data=payload,
        store=store,
        actor=str(actor.get("actor", "anonymous")),
    )
    store.create_audit(
        actor=str(actor["actor"]),
        action="workflow.run.approve",
        resource_type="workflow_run",
        resource_id=run_id,
        details={"decision": payload.get("decision", "approved")},
    )
    store.commit()
    return {"run_id": run_id, "result": result}


@router.get("/runs/{run_id}/approvals")
def list_workflow_approvals(
    run_id: str,
    _actor: CurrentActor,
    store: AgentStore,
) -> dict:
    """List approval requests for a workflow run."""
    from pygubernator.db.models import WorkflowApproval

    run = store.get_workflow_run(run_id)
    if not run:
        raise HTTPException(
            status_code=404,
            detail="Workflow run not found",
        )

    sess = store.session
    approvals = (
        sess.query(WorkflowApproval)
        .filter_by(workflow_run_id=run_id)
        .order_by(WorkflowApproval.created_at)
        .all()
    )
    items = [
        {
            "id": a.id,
            "node_id": a.node_id,
            "prompt": a.prompt,
            "status": a.status,
            "responded_by": a.responded_by,
            "timeout_seconds": a.timeout_seconds,
            "created_at": (a.created_at.isoformat() if a.created_at else None),
            "responded_at": (a.responded_at.isoformat() if a.responded_at else None),
        }
        for a in approvals
    ]
    return {"items": items}


@router.get("/{workflow_id}/export")
def export_workflow_route(
    workflow_id: str,
    _actor: CurrentActor,
    store: AgentStore,
) -> dict:
    """Export a workflow's active version as a JSON spec."""
    wf = store.get_workflow(workflow_id)
    if not wf:
        raise HTTPException(
            status_code=404,
            detail="Workflow not found",
        )
    versions = store.list_workflow_versions(workflow_id)
    active = next((v for v in versions if v.active), None)
    if not active and versions:
        active = versions[0]
    if not active:
        raise HTTPException(
            status_code=404,
            detail="No version available to export",
        )
    return {
        "workflow": {
            "name": wf.name,
            "description": wf.description,
            "owner": wf.owner,
            "spec": active.spec_json,
            "version": active.version,
        },
    }


@router.post("/import")
def import_workflow_route(
    payload: dict,
    actor: CurrentActor,
    store: AgentStore,
) -> dict:
    """Import a workflow from a JSON spec.

    Expects ``{"name": ..., "spec": {...}, ...}`` in the body.
    Creates the workflow and an initial version.
    """
    name = payload.get("name", "imported-workflow")
    description = payload.get("description", "")
    owner = payload.get("owner", str(actor.get("actor", "")))
    spec_json = payload.get("spec", {})
    version_label = payload.get("version", "1.0.0")

    wf = store.create_workflow(
        name=name,
        description=description,
        owner=owner,
    )
    store.commit()
    store.refresh(wf)

    store.create_workflow_version(
        workflow_id=wf.id,
        version=version_label,
        spec_json=spec_json,
        active=True,
        created_by=str(actor.get("actor", "system")),
    )
    store.create_audit(
        actor=str(actor["actor"]),
        action="workflow.import",
        resource_type="workflow",
        resource_id=wf.id,
        details={"name": name},
    )
    store.commit()
    store.refresh(wf)
    return {
        "workflow": WorkflowOut.model_validate(wf).model_dump(),
    }
