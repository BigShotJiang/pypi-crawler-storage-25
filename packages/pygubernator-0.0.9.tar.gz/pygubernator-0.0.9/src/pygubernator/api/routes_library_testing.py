"""Library testing (LibraryTestJob) routes."""

from __future__ import annotations

from datetime import datetime

from fastapi import APIRouter, HTTPException, Query

from pygubernator.api.deps import AgentStore, CurrentActor
from pygubernator.api.models import (
    LibraryTestJobCreateRequest,
    LibraryTestJobEventOut,
    LibraryTestJobEventSubmitRequest,
    LibraryTestJobOut,
    PageMeta,
)
from pygubernator.db import repositories as repos
from pygubernator.services.library_testing import (
    create_job,
    get_job_transitions,
    submit_event,
)
from pygubernator.services.library_testing.bootstrap import ensure_library_test_workflow
from pygubernator.services.library_testing.service import sync_job_from_workflow_run

router = APIRouter(prefix="/api/v1/library-testing", tags=["library-testing"])


@router.post("/jobs", response_model=LibraryTestJobOut)
def create_job_route(
    payload: LibraryTestJobCreateRequest,
    store: AgentStore,
    actor: CurrentActor,
) -> LibraryTestJobOut:
    rec = create_job(
        store.session,
        workspace_id=store.workspace_id,
        name=payload.name,
        spec_json=payload.spec_json,
        created_by=str(actor.get("actor", "system")),
    )
    store.create_audit(
        actor=str(actor["actor"]),
        action="library_test_job.create",
        resource_type="library_test_job",
        resource_id=rec.id,
        details=payload.model_dump(),
    )
    store.commit()
    store.refresh(rec)
    return LibraryTestJobOut.model_validate(rec)


@router.get("/jobs")
def list_jobs_route(
    store: AgentStore,
    _: CurrentActor,
    page: int = Query(1, ge=1),
    page_size: int = Query(25, ge=1, le=100),
    state: str | None = None,
    created_from: datetime | None = None,
    created_to: datetime | None = None,
) -> dict:
    items, total = repos.list_library_test_jobs(
        store.session,
        workspace_id=store.workspace_id,
        page=page,
        page_size=page_size,
        state=state,
        created_from=created_from,
        created_to=created_to,
    )
    return {
        "items": [LibraryTestJobOut.model_validate(i).model_dump() for i in items],
        "meta": PageMeta(total=total, page=page, page_size=page_size).model_dump(),
        "facets": {"states": sorted({i.current_state for i in items})},
    }


@router.get("/jobs/{job_id}", response_model=LibraryTestJobOut)
def get_job_route(job_id: str, store: AgentStore, _: CurrentActor) -> LibraryTestJobOut:
    rec = repos.get_library_test_job(
        store.session, job_id, workspace_id=store.workspace_id
    )
    if not rec:
        raise HTTPException(status_code=404, detail="Job not found")
    return LibraryTestJobOut.model_validate(rec)


@router.get("/jobs/{job_id}/transitions")
def get_job_transitions_route(job_id: str, store: AgentStore, _: CurrentActor) -> dict:
    rec = repos.get_library_test_job(
        store.session, job_id, workspace_id=store.workspace_id
    )
    if not rec:
        raise HTTPException(status_code=404, detail="Job not found")
    return get_job_transitions(rec)


@router.post("/jobs/{job_id}/events")
def submit_event_route(
    job_id: str,
    payload: LibraryTestJobEventSubmitRequest,
    store: AgentStore,
    actor: CurrentActor,
) -> dict:
    try:
        job, ev = submit_event(
            store.session,
            workspace_id=store.workspace_id,
            job_id=job_id,
            trigger=payload.trigger,
            actor=str(actor.get("actor", "system")),
            idempotency_key=payload.idempotency_key,
            payload_json=payload.payload_json,
            workflow_run_id=payload.workflow_run_id,
        )
    except ValueError:
        raise HTTPException(status_code=404, detail="Job not found") from None

    store.create_audit(
        actor=str(actor["actor"]),
        action="library_test_job.event",
        resource_type="library_test_job",
        resource_id=job_id,
        details=payload.model_dump(),
    )
    store.commit()
    store.refresh(job)
    store.refresh(ev)
    return {
        "job": LibraryTestJobOut.model_validate(job).model_dump(),
        "event": LibraryTestJobEventOut.model_validate(ev).model_dump(),
    }


@router.get("/jobs/{job_id}/events")
def list_events_route(
    job_id: str,
    store: AgentStore,
    _: CurrentActor,
    page: int = Query(1, ge=1),
    page_size: int = Query(200, ge=1, le=500),
) -> dict:
    job = repos.get_library_test_job(
        store.session, job_id, workspace_id=store.workspace_id
    )
    if not job:
        raise HTTPException(status_code=404, detail="Job not found")
    items, total = repos.list_library_test_job_events(
        store.session,
        job_id,
        workspace_id=store.workspace_id,
        page=page,
        page_size=page_size,
    )
    return {
        "items": [LibraryTestJobEventOut.model_validate(i).model_dump() for i in items],
        "meta": PageMeta(total=total, page=page, page_size=page_size).model_dump(),
    }


@router.post("/jobs/{job_id}/run")
def run_job_route(job_id: str, store: AgentStore, actor: CurrentActor) -> dict:
    """Execute the LibraryTestWorkflow for a job (Phase 1: local runner)."""
    job = repos.get_library_test_job(
        store.session, job_id, workspace_id=store.workspace_id
    )
    if not job:
        raise HTTPException(status_code=404, detail="Job not found")

    wf, version = ensure_library_test_workflow(
        store,
        workspace_id=store.workspace_id,
        actor=str(actor.get("actor", "system")),
    )

    # Create a workflow run pointing at the template workflow/version.
    run = store.create_workflow_run(
        workflow_id=wf.id,
        workflow_version_id=version.id,
        status="running",
        input_json={
            "job_id": job.id,
            **(job.spec_json or {}),
        },
        created_by=str(actor.get("actor", "system")),
        session_id=None,
    )
    from datetime import UTC, datetime

    run.started_at = datetime.now(UTC)
    store.create_audit(
        actor=str(actor["actor"]),
        action="library_test_job.run",
        resource_type="library_test_job",
        resource_id=job.id,
        details={"workflow_id": wf.id, "workflow_version_id": version.id},
    )
    store.commit()
    store.refresh(run)

    # Best-effort pointer for UI convenience.
    job.last_workflow_run_id = run.id
    store.commit()

    # Auto-progress the job lifecycle for ops usability.
    sync_job_from_workflow_run(
        store.session,
        workspace_id=store.workspace_id,
        job_id=job.id,
        workflow_run_id=run.id,
        workflow_status="running",
        actor=str(actor.get("actor", "system")),
    )
    store.commit()

    # Execute in background thread using the same approach as workflows route.
    import threading

    from pygubernator.api.routes_workflows import _run_workflow_background

    thread = threading.Thread(
        target=_run_workflow_background,
        args=(version.spec_json, run.input_json, run.id, None),
        daemon=True,
        name=f"libtest-{run.id[:8]}",
    )
    thread.start()

    return {"ok": True, "workflow_run_id": run.id}
