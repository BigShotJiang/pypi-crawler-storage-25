"""Metadata descriptions for workflow node types."""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Literal

FieldType = Literal[
    "string",
    "number",
    "boolean",
    "json",
    "expression",
    "select",
    "code",
    "model_ref",
    "tool_ref",
]


@dataclass(frozen=True, slots=True)
class PortSpec:
    """UI and wiring metadata for a node port."""

    name: str
    direction: Literal["input", "output"]
    kind: Literal["control", "data", "tool", "agent", "memory", "model"] = "data"
    label: str | None = None
    multiple: bool = False


@dataclass(frozen=True, slots=True)
class FieldSpec:
    """Metadata for a node configuration field."""

    name: str
    field_type: FieldType
    label: str
    required: bool = False
    default: Any = None
    help_text: str = ""
    options: tuple[str, ...] = ()
    placeholder: str | None = None
    visible_if: dict[str, Any] = field(default_factory=dict)


@dataclass(frozen=True, slots=True)
class NodeTypeDescription:
    """Single-source-of-truth metadata for runtime and editor node types."""

    type_name: str
    display_name: str
    category: str
    description: str
    color: str | None = None
    icon: str | None = None
    inputs: tuple[PortSpec, ...] = ()
    outputs: tuple[PortSpec, ...] = ()
    fields: tuple[FieldSpec, ...] = ()
    tags: tuple[str, ...] = ()
    supports_streaming: bool = False
    supports_checkpointing: bool = False
    supports_subgraph: bool = False
    runtime_kind: Literal["node", "config_only"] = "node"


def _field(
    name: str,
    field_type: FieldType,
    label: str,
    *,
    required: bool = False,
    default: Any = None,
    help_text: str = "",
    options: tuple[str, ...] = (),
    placeholder: str | None = None,
) -> FieldSpec:
    return FieldSpec(
        name=name,
        field_type=field_type,
        label=label,
        required=required,
        default=default,
        help_text=help_text,
        options=options,
        placeholder=placeholder,
    )


GSHEETS_OPERATIONS: tuple[str, ...] = (
    "create_spreadsheet",
    "read_range",
    "write_range",
    "append_rows",
    "create_sheet",
    "delete_sheet",
    "rename_sheet",
    "format_cells",
)


def get_builtin_node_type_descriptions() -> tuple[NodeTypeDescription, ...]:
    """Return built-in node metadata for the workflow editor and API."""
    return (
        NodeTypeDescription(
            type_name="input",
            display_name="Input",
            category="io",
            description="Workflow entry point",
            color="#60a5fa",
            outputs=(PortSpec("output", "output", "data"),),
        ),
        NodeTypeDescription(
            type_name="output",
            display_name="Output",
            category="io",
            description="Workflow exit point",
            color="#4ade80",
            inputs=(PortSpec("input", "input", "data"),),
        ),
        NodeTypeDescription(
            type_name="template",
            display_name="Template",
            category="processing",
            description="String templating",
            color="#c084fc",
            inputs=(PortSpec("input", "input", "data"),),
            outputs=(PortSpec("output", "output", "data"),),
            fields=(_field("template", "string", "Template", required=True),),
        ),
        NodeTypeDescription(
            type_name="code",
            display_name="Code",
            category="processing",
            description="Python expression",
            color="#fb923c",
            inputs=(PortSpec("input", "input", "data"),),
            outputs=(PortSpec("output", "output", "data"),),
            fields=(_field("code", "code", "Code", required=True),),
        ),
        NodeTypeDescription(
            type_name="python_exec",
            display_name="Python Exec",
            category="processing",
            description="Python code with package imports",
            color="#3776ab",
            inputs=(PortSpec("input", "input", "data"),),
            outputs=(PortSpec("output", "output", "data"),),
            fields=(
                _field("code", "code", "Code", required=True),
                _field(
                    "allowed_imports",
                    "json",
                    "Allowed imports",
                    help_text=('Module allowlist as JSON array, e.g. ["pycatalyst"]'),
                    placeholder='["pycatalyst", "pystator"]',
                ),
                _field(
                    "timeout",
                    "number",
                    "Timeout (seconds)",
                    default=30,
                    help_text="Maximum execution time in seconds",
                ),
            ),
        ),
        NodeTypeDescription(
            type_name="library_test",
            display_name="Library Test",
            category="ops",
            description="Run an isolated library/module test job (venv + pytest)",
            color="#22c55e",
            inputs=(PortSpec("input", "input", "data"),),
            outputs=(PortSpec("output", "output", "data"),),
            fields=(
                _field(
                    "timeout_seconds",
                    "number",
                    "Timeout (seconds)",
                    default=1800,
                    help_text="Max runtime for the test job",
                ),
            ),
            tags=("library_testing", "ops"),
        ),
        NodeTypeDescription(
            type_name="http",
            display_name="HTTP",
            category="processing",
            description="HTTP request",
            color="#f87171",
            inputs=(PortSpec("input", "input", "data"),),
            outputs=(PortSpec("output", "output", "data"),),
            fields=(
                _field("method", "select", "Method", default="GET"),
                _field("url", "string", "URL", required=True),
            ),
        ),
        NodeTypeDescription(
            type_name="gsheets",
            display_name="Google Sheets",
            category="processing",
            description=(
                "Google Sheets API (service account JSON path from env). "
                "Connect the green top handle to an Agent's Tool port so the "
                "model can call Sheets tools; use the right handle for data flow."
            ),
            color="#0f9d58",
            inputs=(PortSpec("input", "input", "data"),),
            outputs=(PortSpec("output", "output", "data"),),
            fields=(
                _field(
                    "operation",
                    "select",
                    "Operation",
                    required=True,
                    options=GSHEETS_OPERATIONS,
                    help_text="Parameters may use templates or upstream input_data.",
                ),
                _field(
                    "credentials_env_var",
                    "string",
                    "Credentials env var",
                    help_text=(
                        "Env var for service account JSON path "
                        "(default: PYGUBERNATOR_GSHEETS_CREDENTIALS_PATH)."
                    ),
                    placeholder="PYGUBERNATOR_GSHEETS_CREDENTIALS_PATH",
                ),
            ),
        ),
        NodeTypeDescription(
            type_name="condition",
            display_name="Condition",
            category="logic",
            description="Boolean branching",
            color="#facc15",
            inputs=(PortSpec("input", "input", "data"),),
            outputs=(
                PortSpec("true", "output", "control", label="True"),
                PortSpec("false", "output", "control", label="False"),
            ),
            fields=(_field("condition", "expression", "Condition", required=True),),
        ),
        NodeTypeDescription(
            type_name="router",
            display_name="Router",
            category="logic",
            description="Multi-way routing",
            color="#f472b6",
            inputs=(PortSpec("input", "input", "data"),),
            outputs=(PortSpec("routes", "output", "control", multiple=True),),
        ),
        NodeTypeDescription(
            type_name="loop",
            display_name="Loop",
            category="logic",
            description="Iterate over items",
            color="#22d3ee",
            inputs=(PortSpec("input", "input", "data"),),
            outputs=(
                PortSpec("each", "output", "control", label="Each"),
                PortSpec("done", "output", "control", label="Done"),
            ),
        ),
        NodeTypeDescription(
            type_name="map",
            display_name="Map",
            category="logic",
            description="Parallel map",
            color="#2dd4bf",
            inputs=(PortSpec("input", "input", "data"),),
            outputs=(PortSpec("output", "output", "data"),),
        ),
        NodeTypeDescription(
            type_name="llm",
            display_name="LLM",
            category="ai",
            description="LLM call",
            color="#818cf8",
            inputs=(
                PortSpec("input", "input", "data"),
                PortSpec("model", "input", "model", label="Model"),
            ),
            outputs=(PortSpec("output", "output", "data"),),
            supports_streaming=True,
        ),
        NodeTypeDescription(
            type_name="agent",
            display_name="Agent",
            category="ai",
            description="Python package agent",
            color="#e879f9",
            inputs=(
                PortSpec("input", "input", "data"),
                PortSpec("tools", "input", "tool", multiple=True),
                PortSpec("memory", "input", "memory", multiple=True),
            ),
            outputs=(PortSpec("output", "output", "agent"),),
            supports_streaming=True,
            supports_checkpointing=True,
        ),
        NodeTypeDescription(
            type_name="memory",
            display_name="Memory",
            category="memory",
            description="Agent memory store",
            color="#f59e0b",
            inputs=(PortSpec("input", "input", "memory"),),
            outputs=(PortSpec("output", "output", "memory"),),
        ),
        NodeTypeDescription(
            type_name="tool",
            display_name="Tool (Custom)",
            category="tools",
            description="Custom tool (advanced)",
            color="#34d399",
            inputs=(PortSpec("input", "input", "tool"),),
            outputs=(PortSpec("output", "output", "tool"),),
        ),
        NodeTypeDescription(
            type_name="tool_gsheets",
            display_name="Google Sheets",
            category="tools",
            description="Read, write, and manage spreadsheets",
            color="#0f9d58",
            inputs=(PortSpec("input", "input", "tool"),),
            outputs=(PortSpec("output", "output", "tool"),),
            runtime_kind="config_only",
        ),
        NodeTypeDescription(
            type_name="tool_gdocs",
            display_name="Google Docs",
            category="tools",
            description="Create and edit Google Docs",
            color="#4285f4",
            inputs=(PortSpec("input", "input", "tool"),),
            outputs=(PortSpec("output", "output", "tool"),),
            runtime_kind="config_only",
        ),
        NodeTypeDescription(
            type_name="tool_slack",
            display_name="Slack",
            category="tools",
            description="Send messages and manage Slack channels",
            color="#4a154b",
            inputs=(PortSpec("input", "input", "tool"),),
            outputs=(PortSpec("output", "output", "tool"),),
            runtime_kind="config_only",
        ),
        NodeTypeDescription(
            type_name="tool_notion",
            display_name="Notion",
            category="tools",
            description="Read and write Notion pages and databases",
            color="#191919",
            inputs=(PortSpec("input", "input", "tool"),),
            outputs=(PortSpec("output", "output", "tool"),),
            runtime_kind="config_only",
        ),
        NodeTypeDescription(
            type_name="tool_sql",
            display_name="SQL Database",
            category="tools",
            description="Query and manage SQL databases",
            color="#336791",
            inputs=(PortSpec("input", "input", "tool"),),
            outputs=(PortSpec("output", "output", "tool"),),
            runtime_kind="config_only",
        ),
        NodeTypeDescription(
            type_name="tool_http",
            display_name="HTTP / REST",
            category="tools",
            description="Make HTTP requests to any API",
            color="#f87171",
            inputs=(PortSpec("input", "input", "tool"),),
            outputs=(PortSpec("output", "output", "tool"),),
            runtime_kind="config_only",
        ),
        NodeTypeDescription(
            type_name="tool_python",
            display_name="Python",
            category="tools",
            description="Execute Python code and expressions",
            color="#3776ab",
            inputs=(PortSpec("input", "input", "tool"),),
            outputs=(PortSpec("output", "output", "tool"),),
            runtime_kind="config_only",
        ),
        NodeTypeDescription(
            type_name="tool_obsidian",
            display_name="Obsidian",
            category="tools",
            description="Read and search Obsidian vault notes",
            color="#7c3aed",
            inputs=(PortSpec("input", "input", "tool"),),
            outputs=(PortSpec("output", "output", "tool"),),
            runtime_kind="config_only",
        ),
        NodeTypeDescription(
            type_name="tool_catalyst",
            display_name="Mock Data",
            category="tools",
            description="Generate mock data with pycatalyst",
            color="#f59e0b",
            inputs=(PortSpec("input", "input", "tool"),),
            outputs=(PortSpec("output", "output", "tool"),),
            runtime_kind="config_only",
        ),
        NodeTypeDescription(
            type_name="tool_stator",
            display_name="State Machine",
            category="tools",
            description="Manage state machines with pystator",
            color="#8b5cf6",
            inputs=(PortSpec("input", "input", "tool"),),
            outputs=(PortSpec("output", "output", "tool"),),
            runtime_kind="config_only",
        ),
        NodeTypeDescription(
            type_name="chat_model_openai",
            display_name="OpenAI",
            category="chat_models",
            description="ChatGPT models",
            color="#10a37f",
            outputs=(PortSpec("model", "output", "model"),),
            runtime_kind="config_only",
        ),
        NodeTypeDescription(
            type_name="chat_model_anthropic",
            display_name="Anthropic",
            category="chat_models",
            description="Claude models",
            color="#d97706",
            outputs=(PortSpec("model", "output", "model"),),
            runtime_kind="config_only",
        ),
        NodeTypeDescription(
            type_name="chat_model_gemini",
            display_name="Gemini",
            category="chat_models",
            description="Google Gemini models",
            color="#4285f4",
            outputs=(PortSpec("model", "output", "model"),),
            runtime_kind="config_only",
        ),
        NodeTypeDescription(
            type_name="chat_model_ollama",
            display_name="Ollama",
            category="chat_models",
            description="Local and self-hosted models",
            color="#808080",
            outputs=(PortSpec("model", "output", "model"),),
            runtime_kind="config_only",
        ),
        NodeTypeDescription(
            type_name="chat_model_deepseek",
            display_name="Deepseek",
            category="chat_models",
            description="Deepseek models",
            color="#1a73e8",
            outputs=(PortSpec("model", "output", "model"),),
            runtime_kind="config_only",
        ),
        NodeTypeDescription(
            type_name="chat_model_glm",
            display_name="GLM",
            category="chat_models",
            description="GLM and ChatGLM models",
            color="#ff6b35",
            outputs=(PortSpec("model", "output", "model"),),
            runtime_kind="config_only",
        ),
        NodeTypeDescription(
            type_name="chat_model_openai_compat",
            display_name="OpenAI-Compat",
            category="chat_models",
            description="Any OpenAI-compatible API",
            color="#6b7280",
            outputs=(PortSpec("model", "output", "model"),),
            runtime_kind="config_only",
        ),
    )
