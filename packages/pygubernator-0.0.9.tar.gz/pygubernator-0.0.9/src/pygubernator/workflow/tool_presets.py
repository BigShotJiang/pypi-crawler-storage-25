"""Built-in Agent tool integration presets (factory module + function).

Single source of truth for the workflow editor and GET /workflows/tool-presets.
"""

from __future__ import annotations

from dataclasses import dataclass


@dataclass(frozen=True, slots=True)
class ToolIntegrationPreset:
    """Metadata for one env-based tool factory bundle."""

    id: str
    label: str
    name: str
    factory_module: str
    factory_function: str
    env_hint: str


TOOL_INTEGRATION_PRESETS: tuple[ToolIntegrationPreset, ...] = (
    ToolIntegrationPreset(
        id="google_sheets",
        label="Google Sheets",
        name="google_sheets",
        factory_module="pygubernator.tools.gsheets_factory",
        factory_function="create_tools_from_env",
        env_hint="PYGUBERNATOR_GSHEETS_CREDENTIALS_PATH",
    ),
    ToolIntegrationPreset(
        id="google_docs",
        label="Google Docs",
        name="google_docs",
        factory_module="pygubernator.tools.gdocs_factory",
        factory_function="create_tools_from_env",
        env_hint="PYGUBERNATOR_GDOCS_CREDENTIALS_PATH",
    ),
    ToolIntegrationPreset(
        id="slack",
        label="Slack",
        name="slack",
        factory_module="pygubernator.tools.slack_factory",
        factory_function="create_tools_from_env",
        env_hint="PYGUBERNATOR_SLACK_BOT_TOKEN",
    ),
    ToolIntegrationPreset(
        id="notion",
        label="Notion",
        name="notion",
        factory_module="pygubernator.tools.notion_factory",
        factory_function="create_tools_from_env",
        env_hint="PYGUBERNATOR_NOTION_API_KEY",
    ),
    ToolIntegrationPreset(
        id="sql",
        label="SQL Database",
        name="sql",
        factory_module="pygubernator.tools.sql_factory",
        factory_function="create_tools_from_env",
        env_hint="PYGUBERNATOR_SQL_CONNECTION_STRING",
    ),
    ToolIntegrationPreset(
        id="database",
        label="Database (SQLite/Postgres/Mongo/Redis)",
        name="database",
        factory_module="pygubernator.tools.db_factory",
        factory_function="create_tools_from_env",
        env_hint=(
            "PYGUBERNATOR_SQLITE_PATH | PYGUBERNATOR_POSTGRES_DSN | "
            "PYGUBERNATOR_MONGODB_URI + PYGUBERNATOR_MONGODB_DATABASE | "
            "PYGUBERNATOR_REDIS_URL"
        ),
    ),
    ToolIntegrationPreset(
        id="http",
        label="HTTP / REST",
        name="http",
        factory_module="pygubernator.tools.http_factory",
        factory_function="create_tools_from_env",
        env_hint="PYGUBERNATOR_HTTP_BASE_URL (optional)",
    ),
    ToolIntegrationPreset(
        id="python",
        label="Python Execution",
        name="python",
        factory_module="pygubernator.tools.python_factory",
        factory_function="create_tools_from_env",
        env_hint="PYGUBERNATOR_PYTHON_ALLOWED_IMPORTS (optional)",
    ),
    ToolIntegrationPreset(
        id="obsidian",
        label="Obsidian Vault",
        name="obsidian",
        factory_module="pygubernator.tools.obsidian_factory",
        factory_function="create_tools_from_env",
        env_hint="PYGUBERNATOR_OBSIDIAN_VAULT_PATH",
    ),
    ToolIntegrationPreset(
        id="catalyst",
        label="Mock Data (pycatalyst)",
        name="catalyst",
        factory_module="pygubernator.tools.catalyst_factory",
        factory_function="create_tools_from_env",
        env_hint="PYGUBERNATOR_CATALYST_SCHEMAS_PATH (optional)",
    ),
    ToolIntegrationPreset(
        id="stator",
        label="State Machine (pystator)",
        name="stator",
        factory_module="pygubernator.tools.stator_factory",
        factory_function="create_tools_from_env",
        env_hint="PYGUBERNATOR_STATOR_MACHINES_PATH (optional)",
    ),
)
