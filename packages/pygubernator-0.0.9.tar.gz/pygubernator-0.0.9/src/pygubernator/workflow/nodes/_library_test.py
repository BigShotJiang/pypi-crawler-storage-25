"""Workflow node for running library/module tests (Phase 1 local runner)."""

from __future__ import annotations

import logging
from typing import Any

from pygubernator.services.library_testing.runner import run_library_test
from pygubernator.workflow._types import NodeContext, NodeResult
from pygubernator.workflow.nodes._base import AbstractNode

logger = logging.getLogger(__name__)


class LibraryTestNode(AbstractNode):
    node_type = "library_test"

    async def execute(self, context: NodeContext) -> NodeResult:
        # Deterministic recorded replay: the route injects recorded outputs
        # into the workflow input under __recorded_outputs__.
        recorded = context.input_data.get("__recorded_outputs__")
        if isinstance(recorded, dict):
            payload = recorded.get(self._node_id)
            if isinstance(payload, dict):
                return self._success({"result": payload})

        repo_path = str(context.input_data.get("repo_path", "")).strip()
        if not repo_path:
            return self._failure("Missing required input: repo_path")

        requirements = context.input_data.get("requirements")
        pytest_args = context.input_data.get("pytest_args")
        timeout_seconds = int(self._config.get("timeout_seconds", 1800))
        python = context.input_data.get("python")

        try:
            result = run_library_test(
                repo_path=repo_path,
                requirements=requirements,
                pytest_args=pytest_args,
                timeout_seconds=timeout_seconds,
                python=str(python) if python else None,
            )
        except Exception as exc:
            logger.error("Library test failed: %s", exc, exc_info=True)
            return self._failure(f"{type(exc).__name__}: {exc}")

        return self._success({"result": result})


class LibraryTestNodeFactory:
    def create(self, node_id: str, config: dict[str, Any]) -> LibraryTestNode:
        return LibraryTestNode(node_id=node_id, config=config)


__all__ = ["LibraryTestNodeFactory"]
