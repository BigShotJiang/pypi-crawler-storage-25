"""Background scheduler engine for cron-based workflow triggers."""

from __future__ import annotations

import logging
import threading
from collections.abc import Callable
from datetime import UTC, datetime

from sqlalchemy.orm import Session

logger = logging.getLogger(__name__)

try:
    from croniter import croniter
except ImportError:  # pragma: no cover
    croniter = None  # type: ignore[assignment,misc]


def _parse_5field(expr: str) -> list[str] | None:
    parts = [p for p in expr.strip().split() if p]
    return parts if len(parts) == 5 else None


def _is_simple_field_ok(field: str, *, min_v: int, max_v: int) -> bool:
    if field == "*":
        return True
    if field.startswith("*/"):
        try:
            n = int(field[2:])
            return 1 <= n <= max_v
        except Exception:
            return False
    # Support MON-FRI style tokens for day-of-week only (validated separately).
    try:
        v = int(field)
        return min_v <= v <= max_v
    except Exception:
        return False


_DOW_NAMES = {"SUN": 0, "MON": 1, "TUE": 2, "WED": 3, "THU": 4, "FRI": 5, "SAT": 6}


def _is_dow_ok(field: str) -> bool:
    if field == "*":
        return True
    if field.isdigit():
        return _is_simple_field_ok(field, min_v=0, max_v=7)
    up = field.upper()
    if "-" in up:
        a, b = up.split("-", 1)
        return a in _DOW_NAMES and b in _DOW_NAMES
    return up in _DOW_NAMES


def _utcnow() -> datetime:
    """Return the current UTC datetime."""
    return datetime.now(UTC)


def compute_next_run(
    cron_expr: str,
    base_time: datetime | None = None,
) -> datetime:
    """Compute the next run time for a cron expression.

    Args:
        cron_expr: Standard cron expression string.
        base_time: Reference time; defaults to now (UTC).

    Returns:
        Next occurrence as a timezone-aware UTC datetime.

    Raises:
        RuntimeError: If croniter is not installed.
        ValueError: If the cron expression is invalid.
    """
    base = base_time or _utcnow()
    if croniter is not None:
        cron = croniter(cron_expr, base)
        return cron.get_next(datetime).replace(tzinfo=UTC)

    # Fallback: support a minimal subset used in tests and common ops use.
    parts = _parse_5field(cron_expr)
    if parts is None:
        raise ValueError("Invalid cron expression")
    minute, hour, dom, month, dow = parts

    # Every minute: * * * * *
    if minute == hour == dom == month == dow == "*":
        from datetime import timedelta

        cur = base.replace(second=0, microsecond=0)
        return (cur + timedelta(minutes=1)).replace(tzinfo=UTC)

    # Support */n minute step with other fields as '*'
    if minute.startswith("*/") and hour == dom == month == dow == "*":
        from datetime import timedelta

        step = int(minute[2:])
        cur = base.replace(second=0, microsecond=0)
        # Move forward at least 1 minute, then advance until divisible.
        nxt = cur + timedelta(minutes=1)
        for _ in range(60):
            if nxt.minute % step == 0:
                return nxt.replace(tzinfo=UTC)
            nxt = nxt + timedelta(minutes=1)
        return nxt.replace(tzinfo=UTC)

    # Support daily midnight: 0 0 * * *
    if minute == "0" and hour == "0" and dom == month == dow == "*":
        cur = base.replace(second=0, microsecond=0)
        nxt = cur.replace(hour=0, minute=0)
        if nxt <= base:
            from datetime import timedelta

            nxt = nxt + timedelta(days=1)
        return nxt.replace(tzinfo=UTC)

    raise RuntimeError(
        "croniter is required for advanced scheduling. "
        "Install with: pip install croniter>=2.0.0"
    )


def validate_cron(cron_expr: str) -> bool:
    """Check whether a cron expression is syntactically valid.

    Args:
        cron_expr: Cron expression to validate.

    Returns:
        True if valid, False otherwise.
    """
    if croniter is not None:
        return croniter.is_valid(cron_expr)
    parts = _parse_5field(cron_expr)
    if parts is None:
        return False
    minute, hour, dom, month, dow = parts
    return (
        _is_simple_field_ok(minute, min_v=0, max_v=59)
        and _is_simple_field_ok(hour, min_v=0, max_v=23)
        and _is_simple_field_ok(dom, min_v=1, max_v=31)
        and _is_simple_field_ok(month, min_v=1, max_v=12)
        and _is_dow_ok(dow)
    )


class Scheduler:
    """Background scheduler that evaluates cron jobs.

    Runs in a daemon thread, polling the DB every
    ``poll_interval`` seconds for due jobs. Uses croniter
    to compute next-run times.
    """

    def __init__(
        self,
        db_session_factory: Callable[[], Session],
        poll_interval: float = 30.0,
    ) -> None:
        self._db_session_factory = db_session_factory
        self._poll_interval = poll_interval
        self._stop_event = threading.Event()
        self._thread: threading.Thread | None = None

    # -- public API --------------------------------------------------

    def start(self) -> None:
        """Start the scheduler daemon thread."""
        self._stop_event.clear()
        self._thread = threading.Thread(
            target=self._loop,
            name="pygubernator-scheduler",
            daemon=True,
        )
        self._thread.start()
        logger.info(
            "Scheduler started (poll every %ss)",
            self._poll_interval,
        )

    def stop(self) -> None:
        """Signal the scheduler to stop."""
        self._stop_event.set()
        if self._thread is not None:
            self._thread.join(timeout=self._poll_interval + 5)
            self._thread = None
        logger.info("Scheduler stopped")

    @property
    def running(self) -> bool:
        """Whether the scheduler thread is alive."""
        return self._thread is not None and self._thread.is_alive()

    # -- internal ----------------------------------------------------

    def _loop(self) -> None:
        """Main polling loop (runs in daemon thread)."""
        logger.info("Scheduler loop entered")
        while not self._stop_event.is_set():
            try:
                self._poll_once()
            except Exception:
                logger.error("Scheduler poll error", exc_info=True)
            self._stop_event.wait(self._poll_interval)

    def _poll_once(self) -> None:
        """Execute a single poll cycle."""
        session: Session = self._db_session_factory()
        try:
            self._evaluate_jobs(session)
        finally:
            session.close()

    def _evaluate_jobs(self, session: Session) -> None:
        """Check which jobs are due and trigger them.

        Args:
            session: Active SQLAlchemy session.
        """
        from pygubernator.db.models import ScheduledJob

        now = _utcnow()
        jobs = (
            session.query(ScheduledJob)
            .filter(
                ScheduledJob.enabled.is_(True),
                ScheduledJob.next_run_at.isnot(None),
                ScheduledJob.next_run_at <= now,
            )
            .all()
        )
        for job in jobs:
            try:
                self._trigger_workflow(job, session)
            except Exception:
                logger.error(
                    "Failed to trigger job %s",
                    job.id,
                    exc_info=True,
                )
                job.last_status = "error"
            job.last_run_at = now
            job.next_run_at = compute_next_run(job.cron_expression, now)
        if jobs:
            session.commit()
            logger.info("Triggered %d scheduled job(s)", len(jobs))

    def _trigger_workflow(
        self,
        job: object,
        session: Session,
    ) -> None:
        """Execute a workflow for a due scheduled job.

        Args:
            job: ScheduledJob row with workflow_id and input_json.
            session: Active SQLAlchemy session.
        """
        from pygubernator.agent_store.sqlalchemy import (
            SQLAlchemyAgentStore,
        )
        from pygubernator.db.models import ScheduledJob

        assert isinstance(job, ScheduledJob)

        store = SQLAlchemyAgentStore(session=session)
        workflow = store.get_workflow(job.workflow_id)
        if workflow is None:
            logger.warning(
                "Workflow %s not found for job %s",
                job.workflow_id,
                job.id,
            )
            job.last_status = "error"
            return

        versions = store.list_workflow_versions(job.workflow_id)
        active = next((v for v in versions if v.active), None)
        if active is None:
            logger.warning(
                "No active version for workflow %s",
                job.workflow_id,
            )
            job.last_status = "error"
            return

        run = store.create_workflow_run(
            workflow_id=job.workflow_id,
            workflow_version_id=active.id,
            input_json=dict(job.input_json or {}),
            created_by="scheduler",
        )
        session.commit()
        run_id = run.id

        logger.info(
            "Scheduler triggering workflow %s run %s",
            job.workflow_id,
            run_id[:12],
        )

        _execute_in_thread(
            active.spec_json,
            dict(job.input_json or {}),
            run_id,
            self._db_session_factory,
        )
        job.last_status = "triggered"


def _execute_in_thread(
    spec_json: dict,
    input_json: dict,
    run_id: str,
    session_factory: Callable,
) -> None:
    """Fire-and-forget workflow execution in a thread.

    Args:
        spec_json: Workflow spec as JSON dict.
        input_json: Workflow input data.
        run_id: The workflow run ID.
        session_factory: Callable that returns a new session.
    """
    t = threading.Thread(
        target=_run_workflow,
        args=(spec_json, input_json, run_id, session_factory),
        daemon=True,
        name=f"sched-wf-{run_id[:8]}",
    )
    t.start()


def _run_workflow(
    spec_json: dict,
    input_json: dict,
    run_id: str,
    session_factory: Callable,
) -> None:
    """Execute a workflow with its own DB session."""
    from pygubernator.agent_store.sqlalchemy import (
        SQLAlchemyAgentStore,
    )
    from pygubernator.services._workflows import (
        execute_workflow,
    )

    session = session_factory()
    store = SQLAlchemyAgentStore(session=session)
    try:
        result = execute_workflow(spec_json, input_json, store, run_id)
        run = store.get_workflow_run(run_id)
        if run is None:
            return
        if result["success"]:
            store.update_workflow_run(
                run,
                status="completed",
                output_json=result.get("output", {}),
                completed_at=datetime.now(UTC),
                duration_ms=result.get("duration_ms"),
            )
        else:
            store.update_workflow_run(
                run,
                status="failed",
                error_message="; ".join(result.get("errors", [])),
                completed_at=datetime.now(UTC),
                duration_ms=result.get("duration_ms"),
            )
        store.commit()
    except Exception:
        logger.error(
            "Scheduled run %s crashed",
            run_id[:12],
            exc_info=True,
        )
    finally:
        session.close()
