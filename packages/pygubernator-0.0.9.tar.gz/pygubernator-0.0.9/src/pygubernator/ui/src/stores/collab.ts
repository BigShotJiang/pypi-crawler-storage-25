'use client'

import { create } from 'zustand'
import { devtools } from 'zustand/middleware'
import type { Collaborator, RoomInfo } from '@/lib/collab/types'

/** Connection lifecycle status for the collaboration socket. */
export type ConnectionStatus = 'disconnected' | 'connecting' | 'connected'

export interface CollabState {
  /** Whether a collaboration session is active. */
  isActive: boolean
  /** The current room info (null if not in a session). */
  roomInfo: RoomInfo | null
  /** List of other collaborators in the room. */
  collaborators: Collaborator[]
  /** Whether the share dialog is open. */
  shareDialogOpen: boolean
  /** Connection status. */
  connectionStatus: ConnectionStatus
}

interface CollabActions {
  setActive: (active: boolean) => void
  setRoomInfo: (info: RoomInfo | null) => void
  setCollaborators: (collaborators: Collaborator[]) => void
  setShareDialogOpen: (open: boolean) => void
  setConnectionStatus: (status: ConnectionStatus) => void
  reset: () => void
}

const initialState: CollabState = {
  isActive: false,
  roomInfo: null,
  collaborators: [],
  shareDialogOpen: false,
  connectionStatus: 'disconnected',
}

export const useCollabStore = create<CollabState & CollabActions>()(
  devtools(
    (set) => ({
      ...initialState,
      setActive: (active) => set({ isActive: active }),
      setRoomInfo: (info) => set({ roomInfo: info }),
      setCollaborators: (collaborators) => set({ collaborators }),
      setShareDialogOpen: (open) => set({ shareDialogOpen: open }),
      setConnectionStatus: (status) => set({ connectionStatus: status }),
      reset: () => set(initialState),
    }),
    { name: 'collab' },
  ),
)

// Granular selectors
export const selectIsActive = (s: CollabState & CollabActions) => s.isActive
export const selectRoomInfo = (s: CollabState & CollabActions) => s.roomInfo
export const selectCollaborators = (s: CollabState & CollabActions) =>
  s.collaborators
export const selectShareDialogOpen = (s: CollabState & CollabActions) =>
  s.shareDialogOpen
export const selectConnectionStatus = (s: CollabState & CollabActions) =>
  s.connectionStatus
export const selectSetActive = (s: CollabState & CollabActions) => s.setActive
export const selectSetRoomInfo = (s: CollabState & CollabActions) =>
  s.setRoomInfo
export const selectSetCollaborators = (s: CollabState & CollabActions) =>
  s.setCollaborators
export const selectSetShareDialogOpen = (s: CollabState & CollabActions) =>
  s.setShareDialogOpen
export const selectSetConnectionStatus = (s: CollabState & CollabActions) =>
  s.setConnectionStatus
export const selectReset = (s: CollabState & CollabActions) => s.reset
