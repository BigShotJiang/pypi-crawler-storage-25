/**
 * Version-based conflict resolution (Excalidraw algorithm).
 */

import type { VersionedField } from "./types";

/**
 * Merge remote fields into local state.
 *
 * - Currently-editing field: always keep local
 * - Higher version wins
 * - Equal version: lower versionNonce wins
 * - Unknown remote fields are added
 */
export function reconcile(
  local: Map<string, VersionedField>,
  remote: VersionedField[],
  editingFieldId?: string,
): Map<string, VersionedField> {
  const result = new Map(local);

  for (const remoteField of remote) {
    const localField = local.get(remoteField.id);

    if (!localField) {
      result.set(remoteField.id, remoteField);
      continue;
    }

    if (remoteField.id === editingFieldId) {
      continue;
    }

    if (shouldAcceptRemote(localField, remoteField)) {
      result.set(remoteField.id, remoteField);
    }
  }

  return result;
}

/** Determine whether a remote field should overwrite the local version. */
function shouldAcceptRemote(
  local: VersionedField,
  remote: VersionedField,
): boolean {
  if (remote.version > local.version) return true;
  if (remote.version === local.version) {
    return remote.versionNonce < local.versionNonce;
  }
  return false;
}
