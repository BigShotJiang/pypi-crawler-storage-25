/**
 * Room link generation and parsing.
 */

const ROOM_LINK_REGEX = /^#room=([a-zA-Z0-9_-]+),([a-zA-Z0-9_-]+)$/;

/** Generate a cryptographically random 20-character hex room ID. */
export function generateRoomId(): string {
  const bytes = new Uint8Array(10);
  crypto.getRandomValues(bytes);
  return Array.from(bytes)
    .map((b) => b.toString(16).padStart(2, "0"))
    .join("");
}

/** Parse a URL hash fragment into room ID and encryption key. */
export function parseRoomLink(
  hash: string,
): { roomId: string; roomKey: string } | null {
  const match = hash.match(ROOM_LINK_REGEX);
  if (!match) return null;
  return { roomId: match[1], roomKey: match[2] };
}

/** Build a URL hash fragment from a room ID and encryption key. */
export function buildRoomLink(roomId: string, roomKey: string): string {
  return `#room=${roomId},${roomKey}`;
}

/** Extract room info from the current browser URL hash, if present. */
export function getRoomFromUrl(): {
  roomId: string;
  roomKey: string;
} | null {
  if (typeof window === "undefined") return null;
  return parseRoomLink(window.location.hash);
}
