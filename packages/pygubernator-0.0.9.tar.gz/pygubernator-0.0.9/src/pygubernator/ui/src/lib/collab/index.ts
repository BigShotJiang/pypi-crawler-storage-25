/**
 * Real-time collaboration client library (Excalidraw-style relay).
 *
 * The Socket.IO client must use the **FastAPI base URL** (see `getCollabServerUrl()` in
 * `@/lib/settings`), not the Next.js dev server. Same model as **pystator** / **pycharter**.
 * Backend: `pip install 'pygubernator[collab]'` so `/collab` is mounted on the API.
 */

export { CollabSocket } from "./socket";
export type { CollabCallbacks } from "./socket";
export { colorForSocketId, PresenceManager } from "./presence";
export { reconcile } from "./reconcile";
export {
  buildRoomLink,
  generateRoomId,
  getRoomFromUrl,
  parseRoomLink,
} from "./room";
export {
  decryptData,
  encryptData,
  generateEncryptionKey,
} from "./encryption";
export type {
  Collaborator,
  CollabMessage,
  RoomInfo,
  VersionedField,
  WSSubtype,
} from "./types";
