/**
 * Helpers for workflow collaboration: spec signatures and safe merges.
 * Layout persistence for the editor lives in `spec_json` (node.position);
 * the REST `/api/v1/layouts` routes are optional and not wired from the UI today.
 */

import type { SpecJson } from '@/lib/types/workflow'

/** Node IDs + edge endpoints — unchanged when only coordinates move. */
export function workflowStructureKey(spec: SpecJson): string {
  const nodes = spec.nodes ?? {}
  const ids = Object.keys(nodes).sort().join('\0')
  const edges = (spec.edges ?? [])
    .map((e) => `${e.source}>${e.target}`)
    .sort()
    .join('\0')
  return `${ids}|${edges}`
}

/** Serialized positions for all nodes (collab throttle bucket). */
export function workflowPositionsKey(spec: SpecJson): string {
  const nodes = spec.nodes ?? {}
  return Object.keys(nodes)
    .sort()
    .map((id) => {
      const p = nodes[id]?.position
      return `${id}:${p?.x ?? ''},${p?.y ?? ''}`
    })
    .join(';')
}

export function isValidRemoteWorkflowSpec(spec: unknown): spec is SpecJson {
  if (spec == null || typeof spec !== 'object') return false
  const o = spec as Record<string, unknown>
  if (!('nodes' in o)) return false
  const n = o.nodes
  if (n == null || typeof n !== 'object' || Array.isArray(n)) return false
  if ('edges' in o && o.edges != null && !Array.isArray(o.edges)) return false
  return true
}

export function mergeLayoutPositionsIntoSpec(
  spec: SpecJson,
  positions: Record<string, { x: number; y: number }>,
): SpecJson {
  const nodes = { ...(spec.nodes ?? {}) }
  for (const [id, pos] of Object.entries(positions)) {
    const n = nodes[id]
    if (n) {
      nodes[id] = { ...n, position: { x: pos.x, y: pos.y } }
    }
  }
  return { ...spec, nodes }
}
