/**
 * End-to-end encryption for collaboration messages.
 * Uses AES-GCM (128-bit) via the Web Crypto API.
 * The server never sees unencrypted data.
 */

const ALGO = "AES-GCM";
const KEY_BITS = 128;
const IV_LENGTH = 12;

/** Generate a new AES-GCM encryption key and return it as a base64url string. */
export async function generateEncryptionKey(): Promise<string> {
  const key = await crypto.subtle.generateKey(
    { name: ALGO, length: KEY_BITS },
    true,
    ["encrypt", "decrypt"],
  );
  const jwk = await crypto.subtle.exportKey("jwk", key);
  return jwk.k!;
}

/** Import a base64url key string into a CryptoKey for encrypt/decrypt. */
async function importKey(keyBase64: string): Promise<CryptoKey> {
  return crypto.subtle.importKey(
    "jwk",
    { kty: "oct", k: keyBase64, alg: "A128GCM", ext: true },
    { name: ALGO, length: KEY_BITS },
    false,
    ["encrypt", "decrypt"],
  );
}

/** Encrypt a plaintext string, returning the ciphertext and IV. */
export async function encryptData(
  data: string,
  keyBase64: string,
): Promise<{ encrypted: ArrayBuffer; iv: Uint8Array }> {
  const key = await importKey(keyBase64);
  const iv = crypto.getRandomValues(new Uint8Array(IV_LENGTH));
  const encoded = new TextEncoder().encode(data);
  const encrypted = await crypto.subtle.encrypt(
    { name: ALGO, iv: iv as BufferSource },
    key,
    encoded,
  );
  return { encrypted, iv };
}

/** Decrypt ciphertext back to a plaintext string using the IV and key. */
export async function decryptData(
  encrypted: ArrayBuffer,
  iv: Uint8Array,
  keyBase64: string,
): Promise<string> {
  const key = await importKey(keyBase64);
  const decrypted = await crypto.subtle.decrypt(
    { name: ALGO, iv: iv as BufferSource },
    key,
    encrypted,
  );
  return new TextDecoder().decode(decrypted);
}
