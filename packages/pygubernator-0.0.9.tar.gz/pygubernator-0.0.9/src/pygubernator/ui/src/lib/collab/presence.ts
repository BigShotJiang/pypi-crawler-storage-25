/**
 * Collaborator presence tracking.
 */

import type { Collaborator } from "./types";

/** Deterministic color palette for collaborator avatars. */
const COLORS = [
  "#FF6B6B",
  "#4ECDC4",
  "#45B7D1",
  "#96CEB4",
  "#FFEAA7",
  "#DDA0DD",
  "#98D8C8",
  "#F7DC6F",
  "#BB8FCE",
  "#85C1E9",
  "#F8C471",
  "#82E0AA",
];

/** Deterministic color assignment from a socket ID string. */
export function colorForSocketId(socketId: string): string {
  let hash = 0;
  for (let i = 0; i < socketId.length; i++) {
    hash = (hash << 5) - hash + socketId.charCodeAt(i);
    hash |= 0;
  }
  return COLORS[Math.abs(hash) % COLORS.length];
}

/** Tracks active collaborators in a room and notifies on changes. */
export class PresenceManager {
  private collaborators = new Map<string, Collaborator>();
  private onChange?: (collaborators: Collaborator[]) => void;

  /** Register a callback invoked whenever the collaborator list changes. */
  setOnChange(cb: (collaborators: Collaborator[]) => void): void {
    this.onChange = cb;
  }

  /** Update a collaborator's state, creating a new entry if needed. */
  update(socketId: string, updates: Partial<Collaborator>): void {
    const existing = this.collaborators.get(socketId) ?? {
      socketId,
      username: "Anonymous",
      color: colorForSocketId(socketId),
      userState: "active" as const,
    };
    this.collaborators.set(socketId, { ...existing, ...updates });
    this.onChange?.(this.getAll());
  }

  /** Remove a collaborator by socket ID. */
  remove(socketId: string): void {
    this.collaborators.delete(socketId);
    this.onChange?.(this.getAll());
  }

  /** Sync the collaborator set with the server's member list. */
  setMembers(socketIds: string[], mySocketId: string): void {
    for (const [id] of this.collaborators) {
      if (!socketIds.includes(id) || id === mySocketId) {
        this.collaborators.delete(id);
      }
    }
    this.onChange?.(this.getAll());
  }

  /** Return all tracked collaborators as an array. */
  getAll(): Collaborator[] {
    return Array.from(this.collaborators.values());
  }

  /** Remove all collaborators and notify listeners. */
  clear(): void {
    this.collaborators.clear();
    this.onChange?.(this.getAll());
  }
}
