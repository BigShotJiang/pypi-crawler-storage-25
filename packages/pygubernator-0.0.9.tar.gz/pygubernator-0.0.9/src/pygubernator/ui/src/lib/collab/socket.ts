/**
 * Socket.IO connection manager for collaboration.
 */

import { io, type Socket } from "socket.io-client";

import { decryptData, encryptData, generateEncryptionKey } from "./encryption";
import { PresenceManager } from "./presence";
import { generateRoomId } from "./room";
import type { CollabMessage, RoomInfo } from "./types";

/** Callbacks for collaboration events. */
export interface CollabCallbacks {
  onMessage: (message: CollabMessage) => void;
  onCollaboratorsChange: (socketIds: string[]) => void;
  onFirstInRoom: () => void;
  onNewUser?: (socketId: string) => void;
  /** Fired when Socket.IO has connected (after handshake). Use for UI "live" state. */
  onReady?: () => void;
}

/**
 * Manages a Socket.IO connection for real-time collaboration.
 *
 * Handles room creation/joining, encrypted message broadcast,
 * and presence tracking via Socket.IO events.
 */
export class CollabSocket {
  private socket: Socket | null = null;
  private roomInfo: RoomInfo | null = null;
  readonly presence = new PresenceManager();

  /**
   * Start a new collaboration session.
   * Generates a room ID and encryption key, then connects.
   */
  async startSession(
    serverUrl: string,
    callbacks: CollabCallbacks,
    socketPath = "/collab/socket.io",
  ): Promise<RoomInfo> {
    const roomId = generateRoomId();
    const roomKey = await generateEncryptionKey();
    this.roomInfo = { roomId, roomKey };
    this._connect(serverUrl, roomId, callbacks, socketPath);
    return this.roomInfo;
  }

  /** Join an existing session with known room info. */
  joinSession(
    serverUrl: string,
    roomInfo: RoomInfo,
    callbacks: CollabCallbacks,
    socketPath = "/collab/socket.io",
  ): void {
    this.roomInfo = roomInfo;
    this._connect(serverUrl, roomInfo.roomId, callbacks, socketPath);
  }

  /** Send an encrypted message to all other room members. */
  async broadcast(
    message: CollabMessage,
    volatile = false,
  ): Promise<void> {
    if (!this.socket || !this.roomInfo) return;
    const json = JSON.stringify(message);
    const { encrypted, iv } = await encryptData(
      json,
      this.roomInfo.roomKey,
    );
    const event = volatile
      ? "server-volatile-broadcast"
      : "server-broadcast";
    this.socket.emit(event, this.roomInfo.roomId, encrypted, iv);
  }

  /** Disconnect from the session and clear all state. */
  disconnect(): void {
    this.socket?.disconnect();
    this.socket = null;
    this.roomInfo = null;
    this.presence.clear();
  }

  /** Whether the socket is currently connected. */
  get connected(): boolean {
    return this.socket?.connected ?? false;
  }

  /** The local socket ID, if connected. */
  get socketId(): string | undefined {
    return this.socket?.id;
  }

  /** Open a Socket.IO connection and wire up event handlers. */
  private _connect(
    serverUrl: string,
    roomId: string,
    callbacks: CollabCallbacks,
    socketPath: string,
  ): void {
    this.socket = io(serverUrl, {
      path: socketPath,
      transports: ["websocket", "polling"],
      timeout: 45_000,
      reconnection: true,
      reconnectionAttempts: 10,
      reconnectionDelay: 1_000,
      reconnectionDelayMax: 10_000,
    });

    this.socket.on("connect", () => {
      callbacks.onReady?.();
    });

    this.socket.on("connect_error", (err) => {
      console.error(
        "[collab] socket connect_error",
        err.message,
        `(url=${serverUrl} path=${socketPath})`,
      );
    });

    this.socket.on("init-room", () => {
      this.socket!.emit("join-room", roomId);
    });

    this.socket.on("first-in-room", () => {
      callbacks.onFirstInRoom();
    });

    this.socket.on("new-user", (data: { socketId: string }) => {
      callbacks.onNewUser?.(data.socketId);
    });

    this.socket.on(
      "room-user-change",
      (members: string[]) => {
        callbacks.onCollaboratorsChange(members);
        this.presence.setMembers(members, this.socket!.id!);
      },
    );

    this.socket.on(
      "client-broadcast",
      async (encrypted: ArrayBuffer, iv: Uint8Array) => {
        if (!this.roomInfo) return;
        try {
          const json = await decryptData(
            encrypted,
            iv,
            this.roomInfo.roomKey,
          );
          const message: CollabMessage = JSON.parse(json);
          callbacks.onMessage(message);
        } catch (err: unknown) {
          console.error("[collab] decryption/parse failed:", err);
        }
      },
    );
  }
}
