/**
 * Type definitions for the collaboration module.
 */

export interface Collaborator {
  socketId: string;
  username: string;
  color: string;
  cursor?: { x: number; y: number };
  selectedIds?: string[];
  userState: "active" | "idle" | "away";
}

export interface VersionedField {
  id: string;
  version: number;
  versionNonce: number;
  value: unknown;
}

export type WSSubtype =
  | "CONFIG_INIT"
  | "CONFIG_UPDATE"
  | "CURSOR_LOCATION"
  | "IDLE_STATUS"
  | "USER_SELECTION"
  | "NOTE_STATE_UPSERT"
  | "NOTE_STATE_DELETE"
  | "NOTE_TRANSITION_UPSERT"
  | "NOTE_TRANSITION_DELETE";

export interface CollabMessage {
  type: WSSubtype;
  payload: unknown;
}

export interface RoomInfo {
  roomId: string;
  roomKey: string;
}
