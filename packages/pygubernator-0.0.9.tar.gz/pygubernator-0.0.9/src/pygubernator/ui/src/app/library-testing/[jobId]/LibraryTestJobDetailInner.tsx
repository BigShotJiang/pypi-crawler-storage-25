"use client";

import { useEffect, useMemo, useRef, useState } from "react";
import Link from "next/link";
import { useParams } from "next/navigation";

import { apiGet, apiPost, apiUrl } from "@/lib/api";

type Job = {
  id: string;
  name: string;
  current_state: string;
  created_by: string;
  created_at: string;
  last_workflow_run_id?: string | null;
  last_error_message?: string | null;
  spec_json?: Record<string, unknown>;
};

type JobEvent = {
  id: string;
  trigger: string;
  actor: string;
  created_at: string;
  from_state: string;
  to_state: string;
  success: number;
  error_message?: string | null;
  workflow_run_id?: string | null;
};

type WorkflowStep = {
  id: string;
  node_id: string;
  node_type: string;
  status: string;
  output_json: any;
  error_message?: string | null;
  started_at?: string | null;
  completed_at?: string | null;
  duration_ms?: number | null;
};

export default function LibraryTestJobDetailInner() {
  const params = useParams<{ jobId: string }>();
  const jobId = params.jobId;

  const [job, setJob] = useState<Job | null>(null);
  const [events, setEvents] = useState<JobEvent[]>([]);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const [replayRunId, setReplayRunId] = useState<string | null>(null);
  const [diff, setDiff] = useState<any | null>(null);
  const [steps, setSteps] = useState<WorkflowStep[]>([]);
  const [expandedNodeId, setExpandedNodeId] = useState<string | null>(null);

  const stepElsRef = useRef<Record<string, HTMLDivElement | null>>({});

  async function refresh() {
    const j = await apiGet<Job>(`/api/v1/library-testing/jobs/${jobId}`);
    const e = await apiGet<{ items: JobEvent[] }>(`/api/v1/library-testing/jobs/${jobId}/events`);
    setJob(j);
    setEvents(e.items);
    if (j.last_workflow_run_id) {
      const r = await apiGet<{ run: any; steps: WorkflowStep[] }>(
        `/api/v1/workflows/runs/${j.last_workflow_run_id}`
      );
      setSteps(r.steps ?? []);
    } else {
      setSteps([]);
    }
  }

  useEffect(() => {
    void refresh().catch((e) => setError(e instanceof Error ? e.message : "Failed to load job"));
  }, [jobId]);

  const lastRunId = job?.last_workflow_run_id ?? null;

  const firstFailedStep = useMemo(() => {
    return (
      steps
        .filter((s) => s.node_id !== "__run__")
        .find((s) => String(s.status).toLowerCase() === "failed") ?? null
    );
  }, [steps]);

  const failureReport = useMemo(() => {
    if (!firstFailedStep) return null;
    const parts: string[] = [];
    parts.push(`LibraryTestJob failure report`);
    parts.push(`job_id: ${jobId}`);
    if (job?.name) parts.push(`job_name: ${job.name}`);
    if (lastRunId) parts.push(`workflow_run_id: ${lastRunId}`);
    parts.push(`failed_node_id: ${firstFailedStep.node_id}`);
    parts.push(`failed_node_type: ${firstFailedStep.node_type}`);
    if (firstFailedStep.error_message) parts.push(`error: ${firstFailedStep.error_message}`);
    return parts.join("\n");
  }, [firstFailedStep, job?.name, jobId, lastRunId]);

  const specSummary = useMemo(() => {
    if (!job?.spec_json) return null;
    const rp = job.spec_json["repo_path"];
    const req = job.spec_json["requirements"];
    return { repo_path: rp, requirements: req };
  }, [job?.spec_json]);

  async function runJob() {
    setBusy(true);
    setError(null);
    try {
      await apiPost<object, { ok: boolean; workflow_run_id: string }>(
        `/api/v1/library-testing/jobs/${jobId}/run`,
        {}
      );
      await refresh();
    } catch (e) {
      setError(e instanceof Error ? e.message : "Failed to start run");
    } finally {
      setBusy(false);
    }
  }

  async function replayRecorded() {
    if (!lastRunId) return;
    setBusy(true);
    setError(null);
    setDiff(null);
    try {
      const res = await apiPost<object, { ok: boolean; new_run_id: string }>(
        `/api/v1/workflows/runs/${lastRunId}/replay`,
        {}
      );
      setReplayRunId(res.new_run_id);
    } catch (e) {
      setError(e instanceof Error ? e.message : "Replay failed");
    } finally {
      setBusy(false);
    }
  }

  async function loadDiff() {
    if (!lastRunId || !replayRunId) return;
    setBusy(true);
    setError(null);
    try {
      const d = await apiGet<any>("/api/v1/replay/workflow-runs/diff", {
        left_run_id: lastRunId,
        right_run_id: replayRunId
      });
      setDiff(d);
    } catch (e) {
      setError(e instanceof Error ? e.message : "Diff failed");
    } finally {
      setBusy(false);
    }
  }

  function jumpToNode(nodeId: string) {
    const el = stepElsRef.current[nodeId];
    if (el) {
      el.scrollIntoView({ behavior: "smooth", block: "start" });
    }
  }

  async function copyFailureReport() {
    if (!failureReport) return;
    try {
      await navigator.clipboard.writeText(failureReport);
    } catch (e) {
      setError("Copy failed (clipboard permission denied?)");
    }
  }

  // Auto-expand failing step output when it appears.
  useEffect(() => {
    if (firstFailedStep && expandedNodeId == null) {
      setExpandedNodeId(firstFailedStep.node_id);
    }
  }, [firstFailedStep, expandedNodeId]);

  return (
    <div className="max-w-5xl mx-auto p-6">
      <div className="flex items-baseline justify-between mb-6">
        <div>
          <div className="text-sm text-muted-foreground">
            <Link className="underline" href="/library-testing/">
              Library testing
            </Link>{" "}
            / {jobId.slice(0, 8)}
          </div>
          <h1 className="text-2xl font-bold mt-1">{job?.name || "Job"}</h1>
          <div className="text-sm text-muted-foreground mt-1">
            state: <span className="font-mono">{job?.current_state}</span>
            {job?.last_error_message ? (
              <span className="text-destructive"> • {job.last_error_message}</span>
            ) : null}
          </div>
        </div>
        <div className="flex gap-2">
          <button
            className="px-3 py-2 rounded-md border border-border text-sm hover:bg-muted"
            onClick={() => void refresh()}
            disabled={busy}
          >
            Refresh
          </button>
          <button
            className="px-3 py-2 rounded-md bg-primary text-primary-foreground text-sm disabled:opacity-50"
            onClick={() => void runJob()}
            disabled={busy}
          >
            Run
          </button>
        </div>
      </div>

      {error && (
        <div className="mb-4 p-3 rounded-md border border-destructive/30 bg-destructive/10 text-sm">
          {error}
        </div>
      )}

      {firstFailedStep && (
        <div className="mb-6 p-4 rounded-lg border border-destructive/30 bg-destructive/10">
          <div className="flex items-start justify-between gap-3">
            <div className="min-w-0">
              <div className="font-medium">Failure detected</div>
              <div className="text-sm text-muted-foreground mt-1">
                <span className="font-mono">{firstFailedStep.node_id}</span>{" "}
                <span className="text-muted-foreground">({firstFailedStep.node_type})</span>
                {firstFailedStep.error_message ? (
                  <span className="text-destructive"> • {firstFailedStep.error_message}</span>
                ) : null}
              </div>
            </div>
            <div className="flex gap-2 flex-shrink-0">
              <button
                className="px-3 py-2 rounded-md border border-border text-sm hover:bg-muted"
                onClick={() => {
                  setExpandedNodeId(firstFailedStep.node_id);
                  jumpToNode(firstFailedStep.node_id);
                }}
              >
                Jump to failing step
              </button>
              <button
                className="px-3 py-2 rounded-md border border-border text-sm hover:bg-muted"
                onClick={() => void copyFailureReport()}
              >
                Copy failure report
              </button>
            </div>
          </div>
        </div>
      )}

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div className="rounded-lg border border-border p-4">
          <div className="font-medium mb-3">Summary</div>
          <div className="text-sm">
            <div>
              <span className="text-muted-foreground">job_id:</span>{" "}
              <span className="font-mono">{jobId}</span>
            </div>
            {specSummary && (
              <>
                <div className="mt-2">
                  <span className="text-muted-foreground">repo_path:</span>{" "}
                  <span className="font-mono">{String(specSummary.repo_path ?? "")}</span>
                </div>
                <div className="mt-2">
                  <span className="text-muted-foreground">requirements:</span>{" "}
                  <span className="font-mono">
                    {Array.isArray(specSummary.requirements)
                      ? (specSummary.requirements as any[]).join(", ")
                      : String(specSummary.requirements ?? "")}
                  </span>
                </div>
              </>
            )}
            <div className="mt-2">
              <span className="text-muted-foreground">last_run:</span>{" "}
              {lastRunId ? (
                <Link className="underline font-mono" href={`/runs/?id=${encodeURIComponent(lastRunId)}`}>
                  {lastRunId}
                </Link>
              ) : (
                <span className="text-muted-foreground">none</span>
              )}
            </div>
          </div>
        </div>

        <div className="rounded-lg border border-border p-4">
          <div className="font-medium mb-3">Replay & audit</div>
          <div className="flex flex-col gap-2">
            <button
              className="px-3 py-2 rounded-md border border-border text-sm hover:bg-muted disabled:opacity-50"
              onClick={() => void replayRecorded()}
              disabled={busy || !lastRunId}
            >
              Replay (recorded)
            </button>

            {replayRunId && (
              <div className="text-sm">
                replay_run:{" "}
                <Link className="underline font-mono" href={`/runs/?id=${encodeURIComponent(replayRunId)}`}>
                  {replayRunId}
                </Link>
              </div>
            )}

            <button
              className="px-3 py-2 rounded-md border border-border text-sm hover:bg-muted disabled:opacity-50"
              onClick={() => void loadDiff()}
              disabled={busy || !lastRunId || !replayRunId}
            >
              Diff last run vs replay
            </button>

            {lastRunId && (
              <a
                className="px-3 py-2 rounded-md border border-border text-sm hover:bg-muted inline-block"
                href={apiUrl(`/api/v1/replay/workflow-runs/${lastRunId}/audit-bundle`)}
                target="_blank"
                rel="noreferrer"
              >
                Download audit bundle (last run)
              </a>
            )}
          </div>

          {diff && (
            <div className="mt-4 text-sm">
              <div className="font-medium">Diff</div>
              <div className="text-muted-foreground">
                same: <span className="font-mono">{String(diff.same)}</span>
              </div>
              {diff.summary ? (
                <div className="text-muted-foreground mt-1">
                  summary: <span className="font-mono">{String(diff.summary)}</span>
                </div>
              ) : null}
              {diff.first_divergence && (
                <pre className="mt-2 p-2 rounded-md bg-muted overflow-auto text-xs">
                  {JSON.stringify(diff.first_divergence, null, 2)}
                </pre>
              )}
            </div>
          )}
        </div>
      </div>

      <div className="rounded-lg border border-border p-4 mt-6">
        <div className="font-medium mb-3">Job timeline</div>
        {events.length === 0 ? (
          <div className="text-sm text-muted-foreground">No events yet.</div>
        ) : (
          <div className="space-y-2">
            {events.map((e) => (
              <div key={e.id} className="text-sm flex items-baseline justify-between gap-3">
                <div className="min-w-0">
                  <span className="font-mono">{e.trigger}</span>{" "}
                  <span className="text-muted-foreground">
                    {e.from_state} → {e.to_state}
                  </span>
                  {e.error_message ? (
                    <span className="text-destructive"> • {e.error_message}</span>
                  ) : null}
                  {e.workflow_run_id ? (
                    <span className="text-muted-foreground">
                      {" "}
                      • run{" "}
                      <Link
                        className="underline font-mono"
                        href={`/runs/?id=${encodeURIComponent(e.workflow_run_id)}`}
                      >
                        {e.workflow_run_id.slice(0, 8)}
                      </Link>
                    </span>
                  ) : null}
                </div>
                <div className="text-xs text-muted-foreground whitespace-nowrap">
                  {new Date(e.created_at).toLocaleString()}
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      <div className="rounded-lg border border-border p-4 mt-6">
        <div className="font-medium mb-3">Workflow step timeline</div>
        {!lastRunId ? (
          <div className="text-sm text-muted-foreground">No workflow run yet.</div>
        ) : steps.length === 0 ? (
          <div className="text-sm text-muted-foreground">No steps recorded.</div>
        ) : (
          <div className="space-y-2">
            {steps
              .filter((s) => s.node_id !== "__run__")
              .map((s) => (
                <div
                  key={s.id}
                  ref={(el) => {
                    stepElsRef.current[s.node_id] = el;
                  }}
                  className="text-sm rounded-md border border-border p-3"
                >
                  <div className="flex items-baseline justify-between gap-3">
                    <div className="min-w-0">
                      <div className="font-mono">
                        {s.node_id}{" "}
                        <span className="text-muted-foreground">
                          ({s.node_type})
                        </span>
                      </div>
                      <div className="text-xs text-muted-foreground mt-1">
                        status: <span className="font-mono">{s.status}</span>
                        {typeof s.duration_ms === "number"
                          ? ` • ${s.duration_ms}ms`
                          : ""}
                        {s.error_message ? (
                          <span className="text-destructive">
                            {" "}
                            • {s.error_message}
                          </span>
                        ) : null}
                      </div>
                    </div>
                    <div className="text-xs text-muted-foreground whitespace-nowrap">
                      {s.completed_at
                        ? new Date(s.completed_at).toLocaleString()
                        : s.started_at
                          ? new Date(s.started_at).toLocaleString()
                          : ""}
                    </div>
                  </div>
                  {s.output_json ? (
                    <details
                      className="mt-2"
                      open={expandedNodeId === s.node_id}
                      onToggle={(e) => {
                        const open = (e.target as HTMLDetailsElement).open;
                        setExpandedNodeId(open ? s.node_id : null);
                      }}
                    >
                      <summary className="text-xs text-muted-foreground cursor-pointer">
                        Output
                      </summary>
                      <pre className="mt-2 p-2 rounded-md bg-muted overflow-auto text-xs">
                        {JSON.stringify(s.output_json, null, 2)}
                      </pre>
                    </details>
                  ) : null}
                </div>
              ))}
          </div>
        )}
      </div>
    </div>
  );
}
