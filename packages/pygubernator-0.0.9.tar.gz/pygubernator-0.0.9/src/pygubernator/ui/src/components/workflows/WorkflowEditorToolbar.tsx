"use client";

import { useCallback, useEffect, useRef, useState } from "react";
import Link from "next/link";
import {
  Check,
  ChevronDown,
  Download,
  Ellipsis,
  Loader2,
  PanelBottom,
  Play,
  Redo2,
  RefreshCw,
  Save,
  Undo2,
  Upload,
} from "lucide-react";

import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { ShareButton } from "@/components/collab";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { ROUTES, WORKFLOW_EDITOR_LAST_ID_KEY } from "@/lib/constants";
import { cn } from "@/lib/utils";
import type { SpecJson, VersionRow } from "@/lib/types/workflow";
import {
  useWorkflowEditorStore,
  selectSpec,
  selectSetSpec,
  selectIsDirty,
  selectBottomPanelOpen,
  selectToggleBottomPanel,
} from "@/stores/workflow-editor";

interface WorkflowEditorToolbarProps {
  workflowName: string;
  workflowId: string;
  saveVersion: string;
  onSaveVersionChange: (version: string) => void;
  currentVersion?: string;
  versions?: VersionRow[];
  versionsLoading?: boolean;
  onSelectVersion?: (versionId: string) => void;
  onSave: () => void;
  onExecute: () => void;
  onReload: () => void;
  onUndo: () => void;
  onRedo: () => void;
  canUndo: boolean;
  canRedo: boolean;
  busy: boolean;
  loading: boolean;
  lastRunId?: string | null;
  runStatus?: string | null;
  /** Seconds since this run started being tracked (execute returned until finish). */
  runElapsedSec?: number;
  /** SSE stream connected for this run (otherwise UI falls back to polling). */
  sseConnected?: boolean;
  isDraft?: boolean;
  saveName?: string;
  onSaveNameChange?: (name: string) => void;
}

const STATUS_COLORS: Record<string, string> = {
  completed: "bg-green-500",
  success: "bg-green-500",
  failed: "bg-red-500",
  running: "bg-yellow-500 animate-pulse",
  pending: "bg-gray-400",
  cancelled: "bg-amber-500",
};

function VersionSelector({
  currentVersion,
  versions,
  versionsLoading,
  onSelectVersion,
}: {
  currentVersion?: string;
  versions: VersionRow[];
  versionsLoading: boolean;
  onSelectVersion?: (versionId: string) => void;
}) {
  const hasMultipleVersions = versions.length > 1;
  const activeVersion = currentVersion ?? versions.find((v) => v.active)?.version ?? null;
  const triggerText = activeVersion ? `v${activeVersion}` : "Version";

  return (
    <DropdownMenu>
      <DropdownMenuTrigger asChild>
        <Button
          variant="ghost"
          size="sm"
          disabled={versionsLoading}
          className="h-7 gap-1 px-2 text-xs font-medium text-muted-foreground hover:text-foreground"
          aria-label="Workflow version"
        >
          {versionsLoading ? (
            <Loader2 className="h-3 w-3 animate-spin" />
          ) : (
            <>
              {triggerText}
              {(hasMultipleVersions || versions.length === 0) && (
                <ChevronDown className="h-3 w-3 opacity-60" />
              )}
            </>
          )}
        </Button>
      </DropdownMenuTrigger>
      <DropdownMenuContent align="start" className="w-48">
        <DropdownMenuLabel className="text-xs">
          Versions
          {versionsLoading ? " (loading...)" : ` (${versions.length})`}
        </DropdownMenuLabel>
        <DropdownMenuSeparator />
        {versionsLoading ? (
          <DropdownMenuItem disabled>
            <Loader2 className="mr-2 h-3.5 w-3.5 animate-spin" />
            Loading...
          </DropdownMenuItem>
        ) : versions.length === 0 ? (
          <DropdownMenuItem disabled className="text-muted-foreground">
            No versions found
          </DropdownMenuItem>
        ) : (
          versions.map((v) => {
            const isActive = v.version === activeVersion;
            return (
              <DropdownMenuItem
                key={v.id}
                onClick={() => onSelectVersion?.(v.id)}
                className="justify-between"
              >
                <span className={isActive ? "font-medium" : ""}>
                  v{v.version}
                </span>
                {isActive && (
                  <Check className="h-3.5 w-3.5 text-primary" />
                )}
              </DropdownMenuItem>
            );
          })
        )}
      </DropdownMenuContent>
    </DropdownMenu>
  );
}

export default function WorkflowEditorToolbar({
  workflowName,
  workflowId,
  saveVersion,
  onSaveVersionChange,
  currentVersion,
  versions = [],
  versionsLoading = false,
  onSelectVersion,
  onSave,
  onExecute,
  onReload,
  onUndo,
  onRedo,
  canUndo,
  canRedo,
  busy,
  loading,
  lastRunId,
  runStatus,
  runElapsedSec = 0,
  sseConnected = false,
  isDraft,
  saveName,
  onSaveNameChange,
}: WorkflowEditorToolbarProps) {
  const toolbarRef = useRef<HTMLDivElement>(null);
  const uncollapsedWidthRef = useRef<number>(0);
  const isCollapsedRef = useRef(false);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [isCollapsed, setIsCollapsed] = useState(false);

  const spec = useWorkflowEditorStore(selectSpec);
  const setSpec = useWorkflowEditorStore(selectSetSpec);
  const isDirty = useWorkflowEditorStore(selectIsDirty);
  const bottomPanelOpen = useWorkflowEditorStore(selectBottomPanelOpen);
  const toggleBottomPanel = useWorkflowEditorStore(selectToggleBottomPanel);

  // Collapse when the expanded toolbar exceeds ~85% of the content area width.
  useEffect(() => {
    const toolbar = toolbarRef.current;
    const parent = toolbar?.parentElement;
    if (!toolbar || !parent) return;

    const wouldOverlap = (toolbarW: number, parentW: number) =>
      toolbarW > parentW * 0.85;

    const check = () => {
      const parentWidth = parent.clientWidth;
      if (!isCollapsedRef.current) {
        uncollapsedWidthRef.current = toolbar.offsetWidth;
        if (wouldOverlap(uncollapsedWidthRef.current, parentWidth)) {
          isCollapsedRef.current = true;
          setIsCollapsed(true);
        }
      } else if (!wouldOverlap(uncollapsedWidthRef.current, parentWidth)) {
        isCollapsedRef.current = false;
        setIsCollapsed(false);
        requestAnimationFrame(() => {
          const freshWidth = toolbar.offsetWidth;
          uncollapsedWidthRef.current = freshWidth;
          if (wouldOverlap(freshWidth, parent.clientWidth)) {
            isCollapsedRef.current = true;
            setIsCollapsed(true);
          }
        });
      }
    };

    const observer = new ResizeObserver(check);
    observer.observe(parent);
    return () => observer.disconnect();
  }, []);

  // Cmd+S / Ctrl+S keyboard shortcut
  useEffect(() => {
    const handler = (e: KeyboardEvent) => {
      if ((e.metaKey || e.ctrlKey) && e.key === "s") {
        e.preventDefault();
        onSave();
      }
    };
    window.addEventListener("keydown", handler);
    return () => window.removeEventListener("keydown", handler);
  }, [onSave]);

  const handleExport = useCallback(() => {
    const json = JSON.stringify(spec, null, 2);
    const name = (spec.meta?.name || workflowName || "workflow")
      .replace(/[^a-zA-Z0-9_-]/g, "_");
    const blob = new Blob([json], { type: "application/json" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `${name}.json`;
    a.click();
    URL.revokeObjectURL(url);
  }, [spec, workflowName]);

  const handleImport = useCallback(() => {
    fileInputRef.current?.click();
  }, []);

  const onFileSelected = useCallback(
    (e: React.ChangeEvent<HTMLInputElement>) => {
      const file = e.target.files?.[0];
      if (!file) return;
      const reader = new FileReader();
      reader.onload = () => {
        try {
          const parsed = JSON.parse(reader.result as string) as SpecJson;
          if (!parsed || typeof parsed !== "object") throw new Error("Invalid");
          setSpec(parsed, { replaceHistory: true });
        } catch {
          // Invalid JSON — ignore silently
        }
      };
      reader.readAsText(file);
      e.target.value = "";
    },
    [setSpec],
  );

  return (
    <div
      ref={toolbarRef}
      className="absolute top-3 right-3 z-10 flex flex-row items-center gap-2 rounded-lg border border-border bg-background/95 px-3 py-2 shadow-md backdrop-blur-sm"
    >
      <input
        ref={fileInputRef}
        type="file"
        accept=".json"
        className="hidden"
        onChange={onFileSelected}
      />

      {/* Workflow name + run status */}
      {isDraft && onSaveNameChange ? (
        <Input
          className="w-40 h-8 text-sm font-medium"
          placeholder="Workflow name..."
          value={saveName ?? ""}
          onChange={(e) => onSaveNameChange(e.target.value)}
        />
      ) : (
        <span className="text-sm font-medium truncate max-w-[160px]">
          {workflowName}
        </span>
      )}
      {lastRunId && runStatus ? (
        <div
          className="flex items-center gap-1.5 shrink-0 max-w-[min(100vw-12rem,280px)] rounded-md border border-border/70 bg-muted/60 px-2 py-0.5"
          title={`Run ${lastRunId}`}
          role="status"
          aria-live="polite"
        >
          {(() => {
            const terminal = ["failed", "completed", "success", "cancelled"];
            const spin = !terminal.includes(runStatus);
            return spin ? (
              <Loader2
                className="h-3.5 w-3.5 shrink-0 animate-spin text-primary"
                aria-hidden
              />
            ) : null;
          })()}
          <span className="font-mono text-[10px] text-muted-foreground truncate">
            {lastRunId.slice(0, 8)}…
          </span>
          <span className="tabular-nums text-[10px] text-muted-foreground">
            {runElapsedSec}s
          </span>
          <div
            className={cn(
              "w-2 h-2 shrink-0 rounded-full",
              STATUS_COLORS[runStatus] ?? "bg-gray-400",
            )}
          />
          <span className="hidden min-[420px]:inline text-[10px] text-muted-foreground capitalize">
            {runStatus === "running"
              ? "Running"
              : runStatus === "failed"
                ? "Failed"
                : runStatus === "cancelled"
                  ? "Cancelled"
                  : runStatus === "completed" || runStatus === "success"
                    ? "Done"
                    : runStatus}
          </span>
          <span
            className={cn(
              "text-[10px] font-medium",
              sseConnected ? "text-emerald-600" : "text-muted-foreground",
            )}
            title={
              sseConnected
                ? "Live run updates (SSE)"
                : "Polling run status every 2s"
            }
          >
            {sseConnected ? "Live" : "Poll"}
          </span>
        </div>
      ) : null}

      <div className="h-5 border-l border-border" />

      {/* Primary actions (full-width toolbar) */}
      {!isCollapsed && (
        <>
          {/* Reload — only for saved workflows */}
          {!isDraft && (
            <Button
              variant="ghost"
              size="sm"
              onClick={onReload}
              disabled={loading || busy}
              className="h-7 px-2 text-xs text-muted-foreground hover:text-foreground"
            >
              <RefreshCw className="mr-1.5 h-3.5 w-3.5" />
              Reload
            </Button>
          )}

          {/* Version selector (pycharter-style) for saved workflows */}
          {!isDraft && (
            <VersionSelector
              currentVersion={currentVersion}
              versions={versions}
              versionsLoading={versionsLoading}
              onSelectVersion={onSelectVersion}
            />
          )}

          {/* Version input for drafts */}
          {isDraft && (
            <Input
              className="w-24 h-8"
              placeholder="Version"
              value={saveVersion}
              onChange={(e) => onSaveVersionChange(e.target.value)}
            />
          )}

          {/* Execute */}
          <Button variant="secondary" size="sm" onClick={onExecute} disabled={busy}>
            <Play className="h-4 w-4 mr-1" /> Execute
          </Button>
        </>
      )}

      {/* Consistent menu (always visible, even when not collapsed) */}
      <DropdownMenu>
        <DropdownMenuTrigger asChild>
          <Button
            variant="ghost"
            size="sm"
            className="shrink-0 p-2"
            aria-label="More options"
          >
            <Ellipsis className="h-4 w-4" />
          </Button>
        </DropdownMenuTrigger>
        <DropdownMenuContent align="end" className="w-48">
          <DropdownMenuLabel>Edit</DropdownMenuLabel>
          {!isDraft && (
            <DropdownMenuItem onClick={onReload} disabled={loading || busy}>
              <RefreshCw className="mr-2 h-4 w-4" />
              Reload
            </DropdownMenuItem>
          )}
          {!isDraft && <DropdownMenuSeparator />}
          {!isDraft &&
            versions.map((v) => {
              const isActive = v.version === currentVersion;
              return (
                <DropdownMenuItem
                  key={v.id}
                  onClick={() => onSelectVersion?.(v.id)}
                  className="justify-between"
                >
                  <span className={isActive ? "font-medium" : ""}>
                    v{v.version}
                  </span>
                  {isActive && <Check className="h-3.5 w-3.5 text-primary" />}
                </DropdownMenuItem>
              );
            })}
          {!isDraft && <DropdownMenuSeparator />}
          <DropdownMenuItem onClick={onExecute} disabled={busy}>
            <Play className="mr-2 h-4 w-4" />
            Execute
          </DropdownMenuItem>
          <DropdownMenuSeparator />
          <DropdownMenuLabel>File</DropdownMenuLabel>
          <DropdownMenuItem onClick={handleExport}>
            <Download className="mr-2 h-4 w-4" />
            Export JSON
          </DropdownMenuItem>
          <DropdownMenuItem onClick={handleImport}>
            <Upload className="mr-2 h-4 w-4" />
            Import JSON
          </DropdownMenuItem>
          <DropdownMenuSeparator />
          <DropdownMenuItem asChild>
            <Link
              href={
                workflowId
                  ? `${ROUTES.WORKFLOWS}?id=${workflowId}`
                  : ROUTES.WORKFLOWS
              }
            >
              {workflowId ? "Open details" : "Open workflows page"}
            </Link>
          </DropdownMenuItem>
          <DropdownMenuItem asChild>
            <Link
              href={`${ROUTES.WORKFLOW_EDITOR}?new=1`}
              onClick={() => {
                if (typeof window !== "undefined") {
                  sessionStorage.removeItem(WORKFLOW_EDITOR_LAST_ID_KEY);
                }
              }}
            >
              New blank canvas
            </Link>
          </DropdownMenuItem>
        </DropdownMenuContent>
      </DropdownMenu>

      {/* Undo / Redo */}
      <Button
        variant="ghost"
        size="sm"
        onClick={onUndo}
        disabled={!canUndo}
        className="shrink-0 p-2"
        title="Undo (Cmd+Z)"
        aria-label="Undo"
      >
        <Undo2 className="h-4 w-4" />
      </Button>
      <Button
        variant="ghost"
        size="sm"
        onClick={onRedo}
        disabled={!canRedo}
        className="shrink-0 p-2"
        title="Redo (Cmd+Shift+Z)"
        aria-label="Redo"
      >
        <Redo2 className="h-4 w-4" />
      </Button>

      {/* Bottom panel toggle */}
      <Button
        variant={bottomPanelOpen ? "secondary" : "ghost"}
        size="sm"
        onClick={toggleBottomPanel}
        className="shrink-0 p-2"
        title={`${bottomPanelOpen ? "Hide" : "Show"} bottom panel`}
        aria-label={`${bottomPanelOpen ? "Hide" : "Show"} bottom panel`}
        aria-pressed={bottomPanelOpen}
      >
        <PanelBottom className="h-4 w-4" />
      </Button>

      {/* Share / Collaboration */}
      <div className="h-5 border-l border-border" />
      <ShareButton />

      {/* Export — always visible */}
      <Button
        variant="outline"
        size="sm"
        onClick={handleExport}
        className="shrink-0 p-2"
        title="Export JSON"
        aria-label="Export JSON"
      >
        <Download className="h-4 w-4" />
      </Button>

      {/* Save — split button with dirty indicator */}
      <div className="relative inline-flex items-center">
        <div className="flex">
          <Button
            variant="outline"
            size="sm"
            onClick={onSave}
            disabled={busy || !saveVersion.trim()}
            className="shrink-0 gap-1.5 rounded-r-none border-r-0 px-2 text-xs"
            title="Save (Cmd+S)"
            aria-label="Save"
          >
            <Save className="h-3.5 w-3.5" />
            {!isCollapsed && "Save"}
          </Button>
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button
                variant="outline"
                size="sm"
                className="shrink-0 rounded-l-none px-1"
                aria-label="More save options"
              >
                <ChevronDown className="h-3.5 w-3.5" />
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end" className="w-48">
              <DropdownMenuItem onClick={handleImport}>
                <Upload className="mr-2 h-4 w-4" />
                Import JSON...
              </DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>
        </div>
        {isDirty && (
          <span
            className="absolute -top-0.5 -right-0.5 w-2 h-2 rounded-full bg-amber-500"
            title="Unsaved changes"
          />
        )}
      </div>

    </div>
  );
}
