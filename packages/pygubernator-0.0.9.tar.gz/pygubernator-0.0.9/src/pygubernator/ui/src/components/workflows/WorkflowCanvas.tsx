"use client";

import { useCallback, useEffect, useMemo, useRef, useState, DragEvent } from "react";
import {
  ReactFlow,
  Background,
  Controls,
  addEdge,
  useNodesState,
  useEdgesState,
  useReactFlow,
  ReactFlowProvider,
  SelectionMode,
  type Node,
  type Edge,
  type Connection,
  type OnNodesChange,
  type OnEdgesChange,
  type OnSelectionChangeFunc,
  type NodeTypes,
  type EdgeTypes,
  type ReactFlowInstance,
  MarkerType,
  BackgroundVariant,
} from "@xyflow/react";
import "@xyflow/react/dist/style.css";
import { useWorkflowNodeTypes } from "@/hooks/useWorkflowNodeTypes";
import { summarizeValidationIssues, validateNodeSpec } from "@/lib/workflow-validation";
import type { SpecNode, SpecEdge, StepItem, WorkflowNodeTypeItem } from "@/lib/types/workflow";
import { WorkflowContextMenu } from "@/components/workflows/WorkflowContextMenu";
import { WorkflowEdge } from "@/components/workflows/WorkflowEdge";
import { SubNodeEdge } from "@/components/workflows/SubNodeEdge";
import { WorkflowNode, TYPE_COLORS, DEFAULT_COLOR } from "@/components/workflows/WorkflowNode";
import { useWorkflowEditorStore } from "@/stores/workflow-editor";
import { workflowPositionsKey } from "@/lib/workflow-collab-sync";

const POSITION_EPS = 0.5;

/* ---------- Props ---------- */

interface WorkflowCanvasProps {
  nodes: Record<string, SpecNode>;
  edges: SpecEdge[];
  selectedNodeIds: string[];
  onSelectNodeIds: (ids: string[]) => void;
  onNodesChange: (
    nodes: Record<string, SpecNode>,
    options?: { skipUndo?: boolean },
  ) => void;
  onEdgesChange: (
    edges: SpecEdge[],
    options?: { skipUndo?: boolean },
  ) => void;
  onRemoveNode: (nodeId: string) => void;
  onAddNode: (type: string) => string;
  onOpenInspector?: (nodeId: string) => void;
  /** Called when the user clicks empty canvas (pane), e.g. to dismiss the inspector. */
  onCloseInspector?: () => void;
  runOverlay?: Record<string, StepItem> | null;
  fitViewTrigger?: number;
}

const nodeTypes: NodeTypes = { workflowNode: WorkflowNode };
const edgeTypes: EdgeTypes = { workflow: WorkflowEdge, subNodeEdge: SubNodeEdge };

const _SUB_NODE_EXACT = new Set(["memory", "tool"]);
const _SUB_NODE_PREFIXES = ["chat_model_", "tool_"];

function isSubNodeType(type: string): boolean {
  if (_SUB_NODE_EXACT.has(type)) return true;
  return _SUB_NODE_PREFIXES.some((p) => type.startsWith(p));
}

const ADD_NODE_TYPES = [
  "input", "output", "template", "condition", "code",
  "router", "loop", "map", "http", "gsheets", "llm", "agent",
  "chat_model_openai", "chat_model_anthropic", "chat_model_gemini", "chat_model_ollama",
  "chat_model_deepseek", "chat_model_glm", "chat_model_openai_compat",
  "memory", "tool",
] as const;

/* ---------- Conversion helpers ---------- */

function specToFlow(
  specNodes: Record<string, SpecNode>,
  specEdges: SpecEdge[],
  overlay?: Record<string, StepItem> | null,
  metadataByType: Record<string, WorkflowNodeTypeItem> = {},
): { flowNodes: Node[]; flowEdges: Edge[] } {
  const flowNodes: Node[] = Object.entries(specNodes).map(([id, node], idx) => {
    const step = overlay?.[id];
    const issues = validateNodeSpec(
      node,
      metadataByType[node.type],
    );
    const summary = summarizeValidationIssues(issues);
    return {
      id,
      type: "workflowNode",
      position: node.position ?? { x: 250, y: idx * 120 + 50 },
      data: {
        label: id,
        nodeType: node.type,
        runStatus: step?.status,
        runDuration: step?.duration_ms,
        validationIssues: issues,
        validationSeverity: summary.highestSeverity ?? undefined,
        validationCount: issues.length,
      },
    };
  });
  const flowEdges: Edge[] = specEdges.map((e, idx) => {
    const isSubEdge = e.target_handle?.startsWith("sub:");
    return {
      id: `e-${idx}-${e.source}-${e.target}`,
      source: e.source,
      target: e.target,
      sourceHandle: e.source_handle ?? undefined,
      targetHandle: e.target_handle ?? undefined,
      type: isSubEdge ? "subNodeEdge" : (e.condition || e.source_handle) ? "workflow" : undefined,
      data: { condition: e.condition, sourceHandle: e.source_handle },
      markerEnd: { type: MarkerType.ArrowClosed, width: 16, height: 16 },
      style: { strokeWidth: 2 },
      animated: false,
    };
  });
  return { flowNodes, flowEdges };
}

function flowToSpecNodes(
  flowNodes: Node[],
  originalSpec: Record<string, SpecNode>,
): Record<string, SpecNode> {
  const result: Record<string, SpecNode> = {};
  for (const fn of flowNodes) {
    const orig = originalSpec[fn.id];
    result[fn.id] = {
      type: orig?.type ?? (fn.data as { nodeType: string }).nodeType,
      config: orig?.config ?? {},
      position: { x: Math.round(fn.position.x), y: Math.round(fn.position.y) },
    };
  }
  return result;
}

function flowToSpecEdges(flowEdges: Edge[]): SpecEdge[] {
  return flowEdges.map((e) => ({
    source: e.source,
    target: e.target,
    ...(e.sourceHandle ? { source_handle: e.sourceHandle } : {}),
    ...(e.targetHandle ? { target_handle: e.targetHandle } : {}),
  }));
}

/* ---------- Inner canvas (needs ReactFlow provider) ---------- */

function WorkflowCanvasInner({
  nodes: specNodes,
  edges: specEdges,
  selectedNodeIds,
  onSelectNodeIds,
  onNodesChange: onSpecNodesChange,
  onEdgesChange: onSpecEdgesChange,
  onRemoveNode,
  onAddNode,
  onOpenInspector,
  onCloseInspector,
  runOverlay,
  fitViewTrigger,
}: WorkflowCanvasProps) {
  const reactFlow = useReactFlow();
  const flowViewport = useWorkflowEditorStore((s) => s.flowViewport);
  const setFlowViewport = useWorkflowEditorStore((s) => s.setFlowViewport);
  const isDraggingRef = useRef(false);
  const { nodeTypes: nodeTypeMetadata } = useWorkflowNodeTypes();
  const metadataByType = useMemo(
    () =>
      Object.fromEntries(
        nodeTypeMetadata.map((item) => [item.type_name, item]),
      ),
    [nodeTypeMetadata],
  );

  const initial = useMemo(
    () => specToFlow(specNodes, specEdges, runOverlay, metadataByType),
    // eslint-disable-next-line react-hooks/exhaustive-deps
    [JSON.stringify(specNodes), JSON.stringify(specEdges), JSON.stringify(runOverlay), JSON.stringify(nodeTypeMetadata)],
  );

  const [flowNodes, setFlowNodes, handleNodesChange] = useNodesState(initial.flowNodes);
  const [flowEdges, setFlowEdges, handleEdgesChange] = useEdgesState(initial.flowEdges);

  // Keep ReactFlow in sync when nodes/edges are added or removed from spec.
  // Derive stable keys from node IDs and edge connections so this only fires
  // on structural changes (add/remove), NOT on position updates (drag).
  const specNodeIdKey = useMemo(
    () => Object.keys(specNodes).sort().join("\0"),
    [specNodes],
  );
  const specEdgeKey = useMemo(
    () => specEdges.map((e) => `${e.source}>${e.target}`).sort().join("\0"),
    [specEdges],
  );

  useEffect(() => {
    setFlowNodes(initial.flowNodes);
    setFlowEdges(initial.flowEdges);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [specNodeIdKey, specEdgeKey]);

  // Apply node positions from spec when peers (or server) update coordinates without
  // changing graph structure. Structural sync above intentionally skips position-only
  // updates so React Flow is not reset; this effect merges remote layout into RF state.
  const specPositionsKey = useMemo(
    () => workflowPositionsKey({ nodes: specNodes, edges: [] }),
    [specNodes],
  );

  useEffect(() => {
    if (isDraggingRef.current) return;
    setFlowNodes((nds) => {
      let changed = false;
      const next = nds.map((n) => {
        const p = specNodes[n.id]?.position;
        if (p == null) return n;
        if (
          Math.abs(n.position.x - p.x) < POSITION_EPS
          && Math.abs(n.position.y - p.y) < POSITION_EPS
        ) {
          return n;
        }
        changed = true;
        return { ...n, position: { x: p.x, y: p.y } };
      });
      return changed ? next : nds;
    });
  }, [specPositionsKey, specNodes, setFlowNodes]);

  // Keep per-node run status badges in sync with runOverlay. Structural sync above
  // does not run when only the overlay changes, so without this, stale icons remain
  // after a new execute clears the overlay (and during live run updates).
  useEffect(() => {
    setFlowNodes((nds) =>
      nds.map((n) => {
        const step = runOverlay?.[n.id];
        const nodeSpec = specNodes[n.id];
        const issues = nodeSpec
          ? validateNodeSpec(
              nodeSpec,
              metadataByType[nodeSpec.type],
            )
          : [];
        const summary = summarizeValidationIssues(issues);
        return {
          ...n,
          data: {
            ...n.data,
            runStatus: step?.status,
            runDuration: step?.duration_ms ?? undefined,
            validationIssues: issues,
            validationSeverity: summary.highestSeverity ?? undefined,
            validationCount: issues.length,
          },
        };
      }),
    );
  }, [runOverlay, setFlowNodes, specNodes, metadataByType]);

  const [contextMenu, setContextMenu] = useState<{
    x: number; y: number; nodeId?: string;
  } | null>(null);

  useEffect(() => {
    if (!fitViewTrigger || fitViewTrigger <= 0) return;
    void reactFlow.fitView({ padding: 0.2, duration: 300 });
    const t = window.setTimeout(() => {
      const v = reactFlow.getViewport();
      setFlowViewport({ x: v.x, y: v.y, zoom: v.zoom });
    }, 350);
    return () => window.clearTimeout(t);
  }, [fitViewTrigger, reactFlow, setFlowViewport]);

  const onFlowInit = useCallback(
    (instance: ReactFlowInstance) => {
      const stored = useWorkflowEditorStore.getState().flowViewport;
      if (stored) {
        instance.setViewport(stored);
        return;
      }
      instance.fitView({ padding: 0.2, duration: 0 });
      const v = instance.getViewport();
      setFlowViewport({ x: v.x, y: v.y, zoom: v.zoom });
    },
    [setFlowViewport],
  );

  const onMoveEnd = useCallback(
    (_: MouseEvent | TouchEvent | null, viewport: { x: number; y: number; zoom: number }) => {
      setFlowViewport({ x: viewport.x, y: viewport.y, zoom: viewport.zoom });
    },
    [setFlowViewport],
  );

  const onNodesChangeWrapped: OnNodesChange = useCallback(
    (changes) => {
      handleNodesChange(changes);

      const dragStart = changes.some(
        (c) => c.type === "position" && c.dragging === true,
      );
      const dragEnd = changes.some(
        (c) => c.type === "position" && c.dragging === false,
      );
      if (dragStart) isDraggingRef.current = true;

      const removed = changes.filter((c) => c.type === "remove");
      if (removed.length > 0) {
        queueMicrotask(() => {
          for (const r of removed) {
            if (r.type === "remove") onRemoveNode(r.id);
          }
        });
      }

      const hasPositionChange = changes.some(
        (c) => c.type === "position" && c.position,
      );
      if (hasPositionChange) {
        const skipUndo = !dragEnd && isDraggingRef.current;
        setFlowNodes((current) => {
          queueMicrotask(() =>
            onSpecNodesChange(flowToSpecNodes(current, specNodes), { skipUndo }),
          );
          return current;
        });
      }
      if (dragEnd) isDraggingRef.current = false;
    },
    [handleNodesChange, setFlowNodes, onSpecNodesChange, onRemoveNode, specNodes],
  );

  const onEdgesChangeWrapped: OnEdgesChange = useCallback(
    (changes) => {
      handleEdgesChange(changes);
      const hasRemoval = changes.some((c) => c.type === "remove");
      if (hasRemoval) {
        setFlowEdges((current) => {
          queueMicrotask(() => onSpecEdgesChange(flowToSpecEdges(current)));
          return current;
        });
      }
    },
    [handleEdgesChange, setFlowEdges, onSpecEdgesChange],
  );

  const isValidConnection = useCallback(
    (connection: Connection | Edge) => {
      const sourceNode = flowNodes.find((n) => n.id === connection.source);
      const targetNode = flowNodes.find((n) => n.id === connection.target);
      if (!sourceNode || !targetNode) return false;

      const sourceType = (sourceNode.data as { nodeType: string }).nodeType;
      const targetType = (targetNode.data as { nodeType: string }).nodeType;
      const targetHandle = connection.targetHandle;

      // Google Sheets node: top handle → Agent/LLM Tool port registers gsheets_factory tools.
      if (
        sourceType === "gsheets" &&
        targetHandle === "sub:tool" &&
        targetType === "agent"
      ) {
        return true;
      }

      // Sub-nodes can only connect to sub:* handles
      if (isSubNodeType(sourceType)) {
        if (!targetHandle?.startsWith("sub:")) return false;
        // Source type must match the sub-port suffix (chat_model_* → sub:chat_model)
        const expectedType = targetHandle.slice(4);
        const matches = sourceType === expectedType || sourceType.startsWith(`${expectedType}_`);
        if (!matches) return false;
        // At most 1 chat_model and 1 memory per LLM node (tools allow multiple)
        if (sourceType !== "tool" && !sourceType.startsWith("tool_")) {
          const existing = flowEdges.find(
            (e) => e.target === connection.target && e.targetHandle === targetHandle,
          );
          if (existing) return false;
        }
        return true;
      }

      // Non-sub-nodes cannot connect to sub:* handles
      if (targetHandle?.startsWith("sub:")) return false;

      return true;
    },
    [flowNodes, flowEdges],
  );

  const onConnect = useCallback(
    (connection: Connection) => {
      const isSubEdge = connection.targetHandle?.startsWith("sub:");
      setFlowEdges((eds) => {
        const next = addEdge(
          {
            ...connection,
            type: isSubEdge ? "subNodeEdge" : undefined,
            markerEnd: { type: MarkerType.ArrowClosed, width: 16, height: 16 },
            style: { strokeWidth: 2 },
          },
          eds,
        );
        queueMicrotask(() => onSpecEdgesChange(flowToSpecEdges(next)));
        return next;
      });
    },
    [setFlowEdges, onSpecEdgesChange],
  );

  const onNodeClick = useCallback(
    (_: React.MouseEvent, node: Node) => onSelectNodeIds([node.id]),
    [onSelectNodeIds],
  );

  const onNodeDoubleClick = useCallback(
    (_: React.MouseEvent, node: Node) => {
      onSelectNodeIds([node.id]);
      onOpenInspector?.(node.id);
    },
    [onOpenInspector, onSelectNodeIds],
  );

  const onPaneClick = useCallback(() => {
    onSelectNodeIds([]);
    setContextMenu(null);
    onCloseInspector?.();
  }, [onSelectNodeIds, onCloseInspector]);

  const onSelectionChange: OnSelectionChangeFunc = useCallback(
    ({ nodes: selected }) => {
      if (selected.length > 0) onSelectNodeIds(selected.map((n) => n.id));
    },
    [onSelectNodeIds],
  );

  const onDragOver = useCallback((event: DragEvent) => {
    event.preventDefault();
    event.dataTransfer.dropEffect = "move";
  }, []);

  const onDrop = useCallback(
    (event: DragEvent) => {
      event.preventDefault();
      const type = event.dataTransfer.getData("application/pygubernator-node-type");
      if (!type) return;

      const position = reactFlow.screenToFlowPosition({
        x: event.clientX,
        y: event.clientY,
      });

      const id = `${type}_${Date.now().toString(36)}`;
      const newNode: Node = {
        id,
        type: "workflowNode",
        position,
        data: { label: id, nodeType: type },
      };

      setFlowNodes((nds) => [...nds, newNode]);
      queueMicrotask(() => {
        onSpecNodesChange(
          {
            ...Object.fromEntries(
              Object.entries(specNodes).map(([nid, n]) => [
                nid,
                { type: n.type, config: n.config ?? {}, position: n.position },
              ]),
            ),
            [id]: { type, config: {}, position },
          },
        );
        onSelectNodeIds([id]);
      });
    },
    [setFlowNodes, onSpecNodesChange, onSelectNodeIds, specNodes, reactFlow],
  );

  const onNodeContextMenu = useCallback(
    (event: React.MouseEvent, node: Node) => {
      event.preventDefault();
      setContextMenu({ x: event.clientX, y: event.clientY, nodeId: node.id });
    },
    [],
  );

  const onPaneContextMenu = useCallback((event: React.MouseEvent | MouseEvent) => {
    event.preventDefault();
    setContextMenu({ x: event.clientX, y: event.clientY });
  }, []);

  const contextMenuItems = useMemo(() => {
    if (!contextMenu) return [];
    const store = useWorkflowEditorStore.getState();

    if (contextMenu.nodeId) {
      return [
        { label: "Delete", onClick: () => onRemoveNode(contextMenu.nodeId!), destructive: true },
        {
          label: "Duplicate",
          onClick: () => {
            onSelectNodeIds([contextMenu.nodeId!]);
            setTimeout(() => {
              const s = useWorkflowEditorStore.getState();
              s.copySelection();
              s.pasteClipboard();
            }, 0);
          },
        },
        {
          label: "Copy",
          onClick: () => {
            onSelectNodeIds([contextMenu.nodeId!]);
            setTimeout(() => useWorkflowEditorStore.getState().copySelection(), 0);
          },
        },
      ];
    }

    return [
      { label: "Paste", onClick: () => store.pasteClipboard(), disabled: !store.clipboard },
      { label: "Select All", onClick: () => store.selectAll() },
      { label: "---", onClick: () => {}, disabled: true },
      ...ADD_NODE_TYPES.map((t) => ({
        label: `Add ${t.charAt(0).toUpperCase() + t.slice(1)}`,
        onClick: () => onAddNode(t),
      })),
    ];
  }, [contextMenu, onRemoveNode, onSelectNodeIds, onAddNode]);

  return (
    <div className="h-full w-full bg-slate-50 dark:bg-slate-900/50 overflow-hidden">
      <ReactFlow
        nodes={flowNodes}
        edges={flowEdges}
        onNodesChange={onNodesChangeWrapped}
        onEdgesChange={onEdgesChangeWrapped}
        onConnect={onConnect}
        isValidConnection={isValidConnection}
        onNodeClick={onNodeClick}
        onNodeDoubleClick={onNodeDoubleClick}
        onPaneClick={onPaneClick}
        onSelectionChange={onSelectionChange}
        onDragOver={onDragOver}
        onDrop={onDrop}
        onNodeContextMenu={onNodeContextMenu}
        onPaneContextMenu={onPaneContextMenu}
        onInit={onFlowInit}
        onMoveEnd={onMoveEnd}
        defaultViewport={flowViewport ?? { x: 0, y: 0, zoom: 1 }}
        nodeTypes={nodeTypes}
        edgeTypes={edgeTypes}
        selectionMode={SelectionMode.Partial}
        multiSelectionKeyCode="Shift"
        deleteKeyCode={["Backspace", "Delete"]}
        proOptions={{ hideAttribution: true }}
        defaultEdgeOptions={{
          markerEnd: { type: MarkerType.ArrowClosed, width: 16, height: 16 },
          style: { strokeWidth: 2 },
        }}
      >
        <Background variant={BackgroundVariant.Dots} gap={20} size={1} className="!bg-transparent" />
        <Controls className="!bg-white dark:!bg-slate-800 !border-slate-200 dark:!border-slate-700 !rounded-lg !shadow-md" />
      </ReactFlow>
      {contextMenu && (
        <WorkflowContextMenu
          x={contextMenu.x}
          y={contextMenu.y}
          items={contextMenuItems}
          onClose={() => setContextMenu(null)}
        />
      )}
    </div>
  );
}

/* ---------- Wrapper with provider ---------- */

export default function WorkflowCanvas(props: WorkflowCanvasProps) {
  return (
    <ReactFlowProvider>
      <WorkflowCanvasInner {...props} />
    </ReactFlowProvider>
  );
}
