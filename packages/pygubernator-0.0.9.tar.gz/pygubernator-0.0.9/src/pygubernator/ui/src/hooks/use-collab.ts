'use client'

/**
 * Workflow collaboration hook — aligned with pystator/pycharter:
 * Socket.IO targets the API origin from `getCollabServerUrl()` (never Next rewrites).
 *
 * Broadcast rules: structural spec changes (nodes/edges topology) flush immediately;
 * position-only updates are throttled (~80ms) to limit traffic during drags. Incoming
 * payloads must include a valid `nodes` object (or layout-only merge with `_layoutPositions`).
 */

import { useCallback, useEffect, useRef } from 'react'
import { CollabSocket, getRoomFromUrl, buildRoomLink } from '@/lib/collab'
import type { CollabMessage, Collaborator, RoomInfo } from '@/lib/collab/types'
import { getCollabServerUrl } from '@/lib/settings'
import { useCollabStore } from '@/stores/collab'
import { useWorkflowEditorStore } from '@/stores/workflow-editor'
import { useToastStore } from '@/stores/toast'
import type { SpecJson } from '@/lib/types/workflow'
import {
  isValidRemoteWorkflowSpec,
  mergeLayoutPositionsIntoSpec,
  workflowPositionsKey,
  workflowStructureKey,
} from '@/lib/workflow-collab-sync'

const POSITION_BROADCAST_MS = 80

/** Throttle position-only spec updates to reduce socket traffic during drags. */
let collabPositionThrottleTimer: ReturnType<typeof setTimeout> | null = null
let pendingCollabSpec: SpecJson | null = null

function clearCollabPositionThrottle() {
  if (collabPositionThrottleTimer != null) {
    clearTimeout(collabPositionThrottleTimer)
    collabPositionThrottleTimer = null
  }
  pendingCollabSpec = null
}

function schedulePositionOnlyCollabBroadcast(spec: SpecJson) {
  pendingCollabSpec = spec
  if (collabPositionThrottleTimer != null) return
  collabPositionThrottleTimer = setTimeout(() => {
    collabPositionThrottleTimer = null
    const toSend = pendingCollabSpec
    pendingCollabSpec = null
    if (toSend && globalSocket?.connected) {
      void globalSocket.broadcast({ type: 'CONFIG_UPDATE', payload: toSend })
    }
  }, POSITION_BROADCAST_MS)
}

function normalizeRemoteSpec(spec: SpecJson): SpecJson {
  return {
    ...spec,
    meta: spec.meta ?? {},
    nodes: spec.nodes ?? {},
    edges: spec.edges ?? [],
  }
}

/** Singleton collab socket shared across hook instances. */
let globalSocket: CollabSocket | null = null

/**
 * Flag set when a remote update is being applied.
 * Prevents the local-change subscriber from re-broadcasting.
 */
let _applyingRemote = false

/**
 * Module-level handler for layout position updates from collaborators.
 * Set from the editor page so incoming position changes update the diagram.
 */
let _layoutPositionHandler: ((positions: Record<string, { x: number; y: number }>) => void) | null = null

export function setCollabLayoutHandler(handler: ((positions: Record<string, { x: number; y: number }>) => void) | null) {
  _layoutPositionHandler = handler
}

/** Broadcast a message to peers without needing the hook. */
export function collabBroadcast(msg: CollabMessage) {
  if (globalSocket?.connected) {
    void globalSocket.broadcast(msg)
  }
}

/**
 * Connects the CollabSocket to the workflow editor and collab stores.
 *
 * Provides actions to start, join, and disconnect from a collaboration
 * session, plus auto-broadcast of local changes to peers.
 */
export function useCollab() {
  const setActive = useCollabStore((s) => s.setActive)
  const setRoomInfo = useCollabStore((s) => s.setRoomInfo)
  const setCollaborators = useCollabStore((s) => s.setCollaborators)
  const setConnectionStatus = useCollabStore((s) => s.setConnectionStatus)
  const reset = useCollabStore((s) => s.reset)

  const toastSuccess = useToastStore((s) => s.success)
  const toastError = useToastStore((s) => s.error)

  /** Ref to track whether we've set up the store subscription. */
  const subscribedRef = useRef(false)

  /** FastAPI origin for Socket.IO (not the Next.js dev server). */
  const getServerUrl = useCallback(() => getCollabServerUrl(), [])

  /** Build a snapshot of the current workflow spec for broadcasting. */
  const getSpecSnapshot = useCallback((): SpecJson => {
    return useWorkflowEditorStore.getState().spec
  }, [])

  /** Handle an incoming decrypted collaboration message. */
  const handleMessage = useCallback(
    (message: CollabMessage) => {
      if (message.type === 'CONFIG_INIT' || message.type === 'CONFIG_UPDATE') {
        const raw = message.payload as (SpecJson & {
          _layoutPositions?: Record<string, { x: number; y: number }>
        }) | null
        if (raw == null || typeof raw !== 'object') return

        const layoutPositions = raw._layoutPositions
        const { _layoutPositions: _, ...stripped } = raw
        let remoteSpec = stripped as SpecJson

        if (layoutPositions && _layoutPositionHandler) {
          _layoutPositionHandler(layoutPositions)
        }

        if (isValidRemoteWorkflowSpec(remoteSpec)) {
          if (layoutPositions) {
            remoteSpec = mergeLayoutPositionsIntoSpec(remoteSpec, layoutPositions)
          }
        } else if (
          layoutPositions
          && typeof layoutPositions === 'object'
          && Object.keys(layoutPositions).length > 0
        ) {
          const cur = useWorkflowEditorStore.getState().spec
          remoteSpec = mergeLayoutPositionsIntoSpec(cur, layoutPositions)
        } else {
          return
        }

        const normalized = normalizeRemoteSpec(remoteSpec)
        _applyingRemote = true
        useWorkflowEditorStore.getState().setSpec(normalized, {
          replaceHistory: true,
        })
        requestAnimationFrame(() => {
          _applyingRemote = false
        })
      }

      if (message.type === 'CURSOR_LOCATION' || message.type === 'IDLE_STATUS') {
        const payload = message.payload as Partial<Collaborator> & {
          socketId?: string
        }
        if (globalSocket?.presence && payload.socketId) {
          globalSocket.presence.update(payload.socketId, payload)
          setCollaborators(globalSocket.presence.getAll())
        }
      }
    },
    [setCollaborators],
  )

  /** Sync the collaborator list from the presence manager. */
  const syncCollaborators = useCallback(() => {
    if (globalSocket?.presence) {
      setCollaborators(globalSocket.presence.getAll())
    }
  }, [setCollaborators])

  /** Start a new collaboration session and update the URL hash. */
  const startSession = useCallback(async () => {
    if (globalSocket) return

    const serverUrl = getServerUrl()
    const socket = new CollabSocket()
    globalSocket = socket

    setConnectionStatus('connecting')

    try {
      const roomInfo = await socket.startSession(serverUrl, {
        onMessage: handleMessage,
        onCollaboratorsChange: () => syncCollaborators(),
        onFirstInRoom: () => {
          const spec = getSpecSnapshot()
          void socket.broadcast({ type: 'CONFIG_INIT', payload: spec })
        },
        onNewUser: () => {
          const spec = getSpecSnapshot()
          void socket.broadcast({ type: 'CONFIG_INIT', payload: spec })
        },
        onReady: () => {
          setConnectionStatus('connected')
          toastSuccess('Collaboration session started')
        },
      })

      window.location.hash = buildRoomLink(roomInfo.roomId, roomInfo.roomKey)

      setRoomInfo(roomInfo)
      setActive(true)
    } catch {
      setConnectionStatus('disconnected')
      toastError('Failed to start collaboration session')
    }
  }, [
    getServerUrl,
    handleMessage,
    syncCollaborators,
    getSpecSnapshot,
    setRoomInfo,
    setActive,
    setConnectionStatus,
    toastSuccess,
    toastError,
  ])

  /** Join an existing session using room info (typically parsed from URL). */
  const joinSession = useCallback(
    (roomInfo: RoomInfo) => {
      if (globalSocket) return

      const serverUrl = getServerUrl()
      const socket = new CollabSocket()
      globalSocket = socket

      setConnectionStatus('connecting')

      try {
        socket.joinSession(serverUrl, roomInfo, {
          onMessage: handleMessage,
          onCollaboratorsChange: () => syncCollaborators(),
          onFirstInRoom: () => {
            const spec = getSpecSnapshot()
            void socket.broadcast({ type: 'CONFIG_INIT', payload: spec })
          },
          onNewUser: () => {
            const spec = getSpecSnapshot()
            void socket.broadcast({ type: 'CONFIG_INIT', payload: spec })
          },
          onReady: () => {
            setConnectionStatus('connected')
          },
        })

        setRoomInfo(roomInfo)
        setActive(true)
      } catch {
        globalSocket = null
        setConnectionStatus('disconnected')
        toastError('Failed to join collaboration session')
      }
    },
    [
      getServerUrl,
      handleMessage,
      syncCollaborators,
      getSpecSnapshot,
      setRoomInfo,
      setActive,
      setConnectionStatus,
      toastError,
    ],
  )

  /** Disconnect from the current session and clean up URL hash. */
  const disconnect = useCallback(() => {
    clearCollabPositionThrottle()
    globalSocket?.disconnect()
    globalSocket = null

    if (typeof window !== 'undefined') {
      history.replaceState(
        null,
        '',
        window.location.pathname + window.location.search,
      )
    }

    reset()
    toastSuccess('Left collaboration session')
  }, [reset, toastSuccess])

  // Subscribe to store changes and broadcast to peers.
  useEffect(() => {
    if (subscribedRef.current) return
    subscribedRef.current = true

    const unsub = useWorkflowEditorStore.subscribe((state, prevState) => {
      if (!globalSocket?.connected) return
      if (_applyingRemote) return
      if (state.spec === prevState.spec) return

      const spec = state.spec
      const prevSpec = prevState.spec
      const structChanged =
        workflowStructureKey(spec) !== workflowStructureKey(prevSpec)
      const posChanged =
        workflowPositionsKey(spec) !== workflowPositionsKey(prevSpec)

      if (structChanged) {
        clearCollabPositionThrottle()
        void globalSocket.broadcast({ type: 'CONFIG_UPDATE', payload: spec })
        return
      }

      if (posChanged) {
        schedulePositionOnlyCollabBroadcast(spec)
        return
      }

      clearCollabPositionThrottle()
      void globalSocket.broadcast({ type: 'CONFIG_UPDATE', payload: spec })
    })

    return () => {
      unsub()
      subscribedRef.current = false
    }
  }, [])

  // Auto-join if the URL already contains a room link on first mount.
  useEffect(() => {
    const roomInfo = getRoomFromUrl()
    if (roomInfo && !globalSocket) {
      joinSession(roomInfo)
    }
    // Only run on mount.
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [])

  return {
    startSession,
    joinSession,
    disconnect,
    socket: globalSocket,
  }
}
