"""Repository helpers for control-plane entities."""

from __future__ import annotations

from pygubernator.db._agents import (
    activate_agent_version,
    create_agent,
    create_agent_version,
    get_agent,
    get_agent_version,
    list_agent_versions,
    list_agents,
    update_agent,
)
from pygubernator.db._audit import create_audit, list_audit_logs
from pygubernator.db._incidents import get_incident, list_incidents
from pygubernator.db._library_test import (
    create_library_test_job,
    create_library_test_job_event,
    get_library_test_job,
    list_library_test_job_events,
    list_library_test_jobs,
)
from pygubernator.db._pagination import paginate
from pygubernator.db._policies import list_policies
from pygubernator.db._recorded_outputs import (
    list_recorded_outputs,
    upsert_recorded_output,
)
from pygubernator.db._runs import (
    create_run,
    create_run_event,
    create_tool_call,
    get_run,
    get_run_status_facets,
    list_run_events,
    list_runs_filtered,
    list_tool_calls,
    update_run,
)
from pygubernator.db._workflows import (
    activate_workflow_version,
    create_workflow,
    create_workflow_run,
    create_workflow_step_run,
    create_workflow_version,
    delete_workflow_run,
    get_workflow,
    get_workflow_run,
    list_step_runs,
    list_workflow_runs,
    list_workflow_sessions,
    list_workflow_versions,
    list_workflows,
    update_workflow,
    update_workflow_run,
    update_workflow_step_run,
)

__all__ = [
    # agents
    "activate_agent_version",
    "create_agent",
    "create_agent_version",
    "get_agent",
    "get_agent_version",
    "list_agent_versions",
    "list_agents",
    "update_agent",
    # library testing
    "create_library_test_job",
    "create_library_test_job_event",
    "get_library_test_job",
    "list_library_test_job_events",
    "list_library_test_jobs",
    # audit
    "create_audit",
    "list_audit_logs",
    # incidents
    "get_incident",
    "list_incidents",
    # pagination
    "paginate",
    # policies
    "list_policies",
    # runs
    "create_run",
    "create_run_event",
    "create_tool_call",
    "get_run",
    "get_run_status_facets",
    "list_run_events",
    "list_runs_filtered",
    "list_tool_calls",
    "update_run",
    # recorded outputs (replay)
    "list_recorded_outputs",
    "upsert_recorded_output",
    # workflows
    "activate_workflow_version",
    "create_workflow",
    "create_workflow_run",
    "create_workflow_step_run",
    "create_workflow_version",
    "delete_workflow_run",
    "get_workflow",
    "get_workflow_run",
    "list_step_runs",
    "list_workflow_runs",
    "list_workflow_sessions",
    "list_workflow_versions",
    "list_workflows",
    "update_workflow",
    "update_workflow_run",
    "update_workflow_step_run",
    # library testing
    "create_library_test_job",
    "create_library_test_job_event",
    "get_library_test_job",
    "list_library_test_job_events",
    "list_library_test_jobs",
]
