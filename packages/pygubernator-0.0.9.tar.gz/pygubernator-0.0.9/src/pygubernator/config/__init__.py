"""Configuration loading and validation."""

from __future__ import annotations

from pygubernator.config._control_plane import ControlPlaneSettings, get_api_url
from pygubernator.config._settings import AgentSettings
from pygubernator.config.auth import (
    get_auth_admin_group_claims,
    get_auth_admin_role_claims,
    get_auth_jwt_secret,
    get_auth_service_introspect_path,
    get_auth_service_url,
    get_auth_users,
    is_auth_disabled,
)
from pygubernator.config.database import get_database_url, set_database_url
from pygubernator.config.paths import find_config_file
from pygubernator.config.ports import API_PORT, DOCS_PORT, UI_PORT
from pygubernator.config.ui import get_ui_app_name, get_ui_theme

__all__ = [
    "AgentSettings",
    "ControlPlaneSettings",
    "API_PORT",
    "DOCS_PORT",
    "UI_PORT",
    "get_api_url",
    "get_database_url",
    "set_database_url",
    "find_config_file",
    "get_ui_theme",
    "get_ui_app_name",
    "get_auth_users",
    "get_auth_jwt_secret",
    "get_auth_admin_role_claims",
    "get_auth_admin_group_claims",
    "get_auth_service_url",
    "get_auth_service_introspect_path",
    "is_auth_disabled",
]
