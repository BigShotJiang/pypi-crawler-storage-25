"""Integration credential encryption and injection."""

from __future__ import annotations

import base64
import hashlib
import logging
import os
from typing import Any

from pygubernator.config.auth import get_auth_jwt_secret

logger = logging.getLogger(__name__)

try:
    from cryptography.fernet import Fernet

    _HAS_CRYPTO = True
except ImportError:
    _HAS_CRYPTO = False

KNOWN_PROVIDERS: dict[str, dict[str, str]] = {
    "google_sheets": {
        "env_var": "PYGUBERNATOR_GSHEETS_CREDENTIALS_PATH",
        "type": "file_path",
    },
    "google_docs": {
        "env_var": "PYGUBERNATOR_GDOCS_CREDENTIALS_PATH",
        "type": "file_path",
    },
    "slack": {
        "env_var": "PYGUBERNATOR_SLACK_BOT_TOKEN",
        "type": "token",
    },
    "notion": {
        "env_var": "PYGUBERNATOR_NOTION_API_KEY",
        "type": "token",
    },
    "sql": {
        "env_var": "PYGUBERNATOR_SQL_CONNECTION_STRING",
        "type": "connection_string",
    },
    "http": {
        "env_var": "PYGUBERNATOR_HTTP_BASE_URL",
        "type": "url",
    },
    "obsidian": {
        "env_var": "PYGUBERNATOR_OBSIDIAN_VAULT_PATH",
        "type": "file_path",
    },
    "python": {
        "env_var": "PYGUBERNATOR_PYTHON_ALLOWED_IMPORTS",
        "type": "text",
    },
    "catalyst": {
        "env_var": "PYGUBERNATOR_CATALYST_SCHEMAS_PATH",
        "type": "file_path",
    },
    "stator": {
        "env_var": "PYGUBERNATOR_STATOR_MACHINES_PATH",
        "type": "file_path",
    },
    # ------------------------------------------------------------------
    # Database tool bundles (used by pygubernator.tools.db_factory)
    # ------------------------------------------------------------------
    "db_sqlite": {
        "env_var": "PYGUBERNATOR_SQLITE_PATH",
        "type": "file_path",
    },
    "db_postgres": {
        "env_var": "PYGUBERNATOR_POSTGRES_DSN",
        "type": "connection_string",
    },
    "db_mongodb_uri": {
        "env_var": "PYGUBERNATOR_MONGODB_URI",
        "type": "connection_string",
    },
    "db_mongodb_database": {
        "env_var": "PYGUBERNATOR_MONGODB_DATABASE",
        "type": "text",
    },
    "db_redis": {
        "env_var": "PYGUBERNATOR_REDIS_URL",
        "type": "connection_string",
    },
}


def _derive_key(secret: str) -> bytes:
    """Derive a 32-byte Fernet key from a secret using SHA-256.

    Args:
        secret: The secret string to derive a key from.

    Returns:
        A url-safe base64-encoded 32-byte key suitable for Fernet.
    """
    digest = hashlib.sha256(secret.encode("utf-8")).digest()
    return base64.urlsafe_b64encode(digest)


def encrypt_value(plaintext: str, secret: str) -> str:
    """Encrypt a plaintext value and return a base64 string.

    Uses Fernet encryption when the ``cryptography`` package is
    available; falls back to simple base64 encoding otherwise.

    Args:
        plaintext: The value to encrypt.
        secret: The secret used to derive the encryption key.

    Returns:
        Encrypted (or base64-encoded) string.
    """
    if _HAS_CRYPTO:
        key = _derive_key(secret)
        return Fernet(key).encrypt(plaintext.encode("utf-8")).decode("utf-8")
    logger.warning("cryptography not installed; using base64 fallback (NOT secure)")
    return base64.b64encode(plaintext.encode("utf-8")).decode("utf-8")


def decrypt_value(ciphertext: str, secret: str) -> str:
    """Decrypt a ciphertext value back to plaintext.

    Uses Fernet decryption when the ``cryptography`` package is
    available; falls back to simple base64 decoding otherwise.

    Args:
        ciphertext: The encrypted (or base64-encoded) string.
        secret: The secret used to derive the decryption key.

    Returns:
        Decrypted plaintext string.
    """
    if _HAS_CRYPTO:
        key = _derive_key(secret)
        return Fernet(key).decrypt(ciphertext.encode("utf-8")).decode("utf-8")
    logger.warning("cryptography not installed; using base64 fallback (NOT secure)")
    return base64.b64decode(ciphertext.encode("utf-8")).decode("utf-8")


def mask_value(plaintext: str) -> str:
    """Mask a plaintext value for safe display.

    Returns the first 4 and last 4 characters with ``****`` in
    between.  If the value is 10 characters or shorter, returns
    ``****`` to avoid leaking the full value.

    Args:
        plaintext: The value to mask.

    Returns:
        Masked string safe for logging or API responses.
    """
    if len(plaintext) <= 10:
        return "****"
    return f"{plaintext[:4]}****{plaintext[-4:]}"


def inject_credentials(session: Any) -> None:
    """Load enabled credentials from the DB and set as env vars.

    Queries all enabled ``IntegrationCredential`` rows, decrypts
    their values, and sets them as environment variables so that
    downstream tool factories can discover them.

    Args:
        session: A SQLAlchemy session instance.
    """
    from pygubernator.db.models import IntegrationCredential

    secret = get_auth_jwt_secret()
    if not secret:
        logger.warning("JWT secret not configured; skipping credential injection")
        return

    rows = (
        session.query(IntegrationCredential)
        .filter(IntegrationCredential.enabled.is_(True))
        .all()
    )
    count = 0
    for row in rows:
        try:
            decrypted = decrypt_value(row.encrypted_value, secret)
            os.environ[row.env_var] = decrypted
            count += 1
        except Exception:
            logger.error("Failed to decrypt credential %s", row.name)
    logger.info("Injected %d integration credential(s)", count)
