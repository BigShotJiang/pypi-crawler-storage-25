"""Internal helpers for SQLiteStorageBackend."""

