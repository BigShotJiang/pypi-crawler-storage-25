import io
import zipfile
from datetime import datetime
from pathlib import Path
from typing import Literal, Optional, Union, cast
from urllib.parse import urljoin

import httpx

from ..clients.graphql_client import PolymarketGraphQLClient
from ..types.common import EthAddress, TimeseriesPoint
from ..types.data_types import (
    AccountingSnapshotCSVs,
    Activity,
    ActivityType,
    BuilderLeaderboardUser,
    ClosedPosition,
    EventLiveVolume,
    GQLPosition,
    HolderResponse,
    LeaderboardUser,
    MarketValue,
    Position,
    Trade,
    UserMetric,
    UserRank,
    ValueResponse,
)


class PolymarketDataClient:
    def __init__(
        self,
        base_url: str = "https://data-api.polymarket.com",
        proxy: Optional[str] = None,
    ):
        self.base_url = base_url
        self.client = httpx.Client(http2=True, timeout=30.0, proxy=proxy)
        self.gql_positions_client = PolymarketGraphQLClient(
            endpoint_name="positions_subgraph"
        )

    def _build_url(self, endpoint: str) -> str:
        return urljoin(self.base_url, endpoint)

    def get_ok(self) -> str:
        response = self.client.get(self.base_url)
        response.raise_for_status()
        return cast("str", response.json()["data"])

    def get_all_positions_gql(
        self,
        user: EthAddress,
        size_threshold: float = 0.0,
    ) -> list[GQLPosition]:
        query = f"""query {{
                  userBalances(where: {{
                  user: "{user.lower()}",
                  balance_gt: "{int(size_threshold * 10**6)}"
                  }}) {{
                    user
                    asset {{
                      id
                      condition {{
                        id
                      }}
                      complement
                      outcomeIndex
                    }}
                    balance
                  }}
                }}
                """

        response = self.gql_positions_client.query(query)
        return [GQLPosition(**pos) for pos in response["userBalances"]]

    def get_positions(
        self,
        user: EthAddress,
        condition_id: Optional[
            Union[str, list[str]]
        ] = None,  # mutually exclusive with event_id
        event_id: Optional[
            Union[str, int, list[str], list[int]]
        ] = None,  # mutually exclusive with condition_id
        size_threshold: float = 1.0,
        redeemable: bool = False,
        mergeable: bool = False,
        title: Optional[str] = None,
        limit: int = 100,
        offset: int = 0,
        sort_by: Literal[
            "TOKENS",
            "CURRENT",
            "INITIAL",
            "CASHPNL",
            "PERCENTPNL",
            "TITLE",
            "RESOLVING",
            "PRICE",
            "AVGPRICE",
        ] = "TOKENS",
        sort_direction: Literal["ASC", "DESC"] = "DESC",
    ) -> list[Position]:
        params: dict[str, str | list[str] | int | float] = {
            "user": user,
            "sizeThreshold": size_threshold,
            "limit": min(limit, 500),
            "offset": offset,
        }
        if isinstance(condition_id, str):
            params["market"] = condition_id
        if isinstance(condition_id, list):
            params["market"] = ",".join(condition_id)
        if isinstance(event_id, str):
            params["eventId"] = event_id
        if isinstance(event_id, int):
            params["eventId"] = str(event_id)
        if isinstance(event_id, list):
            params["eventId"] = [str(i) for i in event_id]
        if redeemable is not None:
            params["redeemable"] = redeemable
        if mergeable is not None:
            params["mergeable"] = mergeable
        if title:
            params["title"] = title
        if sort_by:
            params["sortBy"] = sort_by
        if sort_direction:
            params["sortDirection"] = sort_direction

        response = self.client.get(self._build_url("/positions"), params=params)
        response.raise_for_status()
        return [Position(**pos) for pos in response.json()]

    def get_all_positions(
        self,
        user: EthAddress,
    ) -> list[Position]:
        params: dict[str, str | int] = {"user": user, "sizeThreshold": 0}

        response = self.client.get(self._build_url("/positions"), params=params)
        response.raise_for_status()
        return [Position(**pos) for pos in response.json()]

    def get_trades(
        self,
        limit: int = 100,
        offset: int = 0,
        taker_only: bool = True,
        filter_type: Optional[Literal["CASH", "TOKENS"]] = None,
        filter_amount: Optional[
            float
        ] = None,  # must be provided together with filter_type
        condition_id: Optional[str | list[str]] = None,
        event_id: Optional[str | int | list[str] | list[int]] = None,
        user: Optional[str] = None,
        side: Optional[Literal["BUY", "SELL"]] = None,
    ) -> list[Trade]:
        params: dict[str, int | bool | float | str | list[str]] = {
            "limit": min(limit, 500),
            "offset": offset,
            "takerOnly": taker_only,
        }
        if filter_type:
            params["filterType"] = filter_type
        if filter_amount:
            params["filterAmount"] = filter_amount
        if isinstance(condition_id, str):
            params["market"] = condition_id
        if isinstance(condition_id, list):
            params["market"] = ",".join(condition_id)
        if isinstance(event_id, str):
            params["eventId"] = event_id
        if isinstance(event_id, int):
            params["eventId"] = str(event_id)
        if isinstance(event_id, list):
            params["eventId"] = [str(i) for i in event_id]
        if user:
            params["user"] = user
        if side:
            params["side"] = side

        response = self.client.get(self._build_url("/trades"), params=params)
        response.raise_for_status()
        return [Trade(**trade) for trade in response.json()]

    def get_activity(
        self,
        user: EthAddress,
        limit: int = 100,
        offset: int = 0,
        condition_id: Optional[Union[str, list[str]]] = None,
        event_id: Optional[Union[str, int, list[str], list[int]]] = None,
        type: Optional[Union[ActivityType, list[ActivityType]]] = None,
        start: Optional[datetime] = None,
        end: Optional[datetime] = None,
        side: Optional[Literal["BUY", "SELL"]] = None,
        sort_by: Literal["TIMESTAMP", "TOKENS", "CASH"] = "TIMESTAMP",
        sort_direction: Literal["ASC", "DESC"] = "DESC",
    ) -> list[Activity]:
        params: dict[str, str | list[str] | int] = {
            "user": user,
            "limit": min(limit, 500),
            "offset": offset,
        }
        if isinstance(condition_id, str):
            params["market"] = condition_id
        if isinstance(condition_id, list):
            params["market"] = ",".join(condition_id)
        if isinstance(event_id, str):
            params["eventId"] = event_id
        if isinstance(event_id, int):
            params["eventId"] = str(event_id)
        if isinstance(event_id, list):
            params["eventId"] = [str(i) for i in event_id]
        if isinstance(type, str):
            params["type"] = type
        if isinstance(type, list):
            params["type"] = ",".join(type)
        if start:
            params["start"] = int(start.timestamp())
        if end:
            params["end"] = int(end.timestamp())
        if side:
            params["side"] = side
        if sort_by:
            params["sortBy"] = sort_by
        if sort_direction:
            params["sortDirection"] = sort_direction

        response = self.client.get(self._build_url("/activity"), params=params)
        response.raise_for_status()
        return [Activity(**activity) for activity in response.json()]

    def get_holders(
        self,
        condition_id: str,
        limit: int = 500,
        min_balance: int = 1,
    ) -> list[HolderResponse]:
        """Takes in a condition_id and returns top holders for each corresponding token_id."""
        params: dict[str, int | str] = {
            "market": condition_id,
            "limit": limit,
            "min_balance": min_balance,
        }
        response = self.client.get(self._build_url("/holders"), params=params)
        response.raise_for_status()
        return [HolderResponse(**holder_data) for holder_data in response.json()]

    def get_value(
        self,
        user: EthAddress,
        condition_ids: Optional[Union[str, list[str]]] = None,
    ) -> ValueResponse:
        """
        Get the current value of a user's position in a set of markets.

        Takes in condition_id as:
            - None      --> total value of positions
            - str       --> value of position
            - list[str] --> sum of the values of positions.
        """
        params: dict[str, str] = {"user": user}
        if isinstance(condition_ids, str):
            params["market"] = condition_ids
        if isinstance(condition_ids, list):
            params["market"] = ",".join(condition_ids)

        response = self.client.get(self._build_url("/value"), params=params)
        response.raise_for_status()
        return ValueResponse(**response.json()[0])

    def get_closed_positions(
        self,
        user: EthAddress,
        condition_id: Optional[
            Union[str, list[str]]
        ] = None,  # mutually exclusive with event_id
        title: Optional[str] = None,
        event_id: Optional[
            Union[int, list[int]]
        ] = None,  # mutually exclusive with condition_id
        limit: int = 50,
        offset: int = 0,
        sort_by: Literal["REALIZEDPNL", "TITLE", "PRICE", "AVGPRICE", "TIMESTAMP"] = (
            "TIMESTAMP"
        ),
        sort_direction: Literal["ASC", "DESC"] = "DESC",
    ) -> list[ClosedPosition]:
        """
        Get closed positions for a user.

        Args:
            user: 用户钱包地址（必填）。
            condition_id: 市场 conditionId（对应 query 参数 market），支持单个或多个。
                与 event_id 互斥。
            title: 按市场标题过滤。
            event_id: 事件 ID（支持单个或多个），返回该事件下所有 market 的已平仓仓位。
                与 condition_id 互斥。
            limit: 返回条数上限（默认 10，通常可设为 100 做批量拉取）。
            offset: 分页起始偏移（接口范围 0~100000）。
            sort_by: 排序字段，默认 REALIZEDPNL。
            sort_direction: 排序方向，ASC 或 DESC。
        """
        if condition_id is not None and event_id is not None:
            raise ValueError("condition_id and event_id are mutually exclusive")

        params: dict[str, str | list[str] | int] = {
            "user": user,
            "limit": min(limit, 100),
            "offset": offset,
        }
        if isinstance(condition_id, str):
            params["market"] = condition_id
        if isinstance(condition_id, list):
            params["market"] = ",".join(condition_id)
        if title:
            params["title"] = title
        if isinstance(event_id, int):
            params["eventId"] = str(event_id)
        if isinstance(event_id, list):
            params["eventId"] = [str(i) for i in event_id]
        if sort_by:
            params["sortBy"] = sort_by
        if sort_direction:
            params["sortDirection"] = sort_direction

        response = self.client.get(self._build_url("/closed-positions"), params=params)
        response.raise_for_status()
        return [ClosedPosition(**pos) for pos in response.json()]

    def get_total_markets_traded(
        self,
        user: EthAddress,
    ) -> int:
        """Get the total number of markets a user has traded in."""
        params = {"user": user}

        response = self.client.get(self._build_url("/traded"), params=params)
        response.raise_for_status()
        return cast("int", response.json()["traded"])

    def get_open_interest(
        self,
        condition_ids: Optional[Union[str, list[str]]] = None,
    ) -> list[MarketValue]:
        """Get open interest."""
        params = {}

        if isinstance(condition_ids, str):
            params["market"] = condition_ids
        if isinstance(condition_ids, list):
            params["market"] = ",".join(condition_ids)

        response = self.client.get(self._build_url("/oi"), params=params)
        response.raise_for_status()
        return [MarketValue(**oi) for oi in response.json()]

    def get_live_volume(
        self,
        event_id: str | int,
    ) -> EventLiveVolume:
        """Get live volume for a given event."""
        params = {"id": str(event_id)}

        response = self.client.get(self._build_url("/live-volume"), params=params)
        response.raise_for_status()
        return EventLiveVolume(**response.json()[0])

    def get_accounting_snapshot_zip(
        self, user: EthAddress, save_to: Optional[str | Path] = None
    ) -> bytes:
        """Download the accounting snapshot ZIP (CSV bundle) as bytes."""
        params = {"user": user}

        response = self.client.get(
            self._build_url("/v1/accounting/snapshot"), params=params
        )
        response.raise_for_status()
        data = response.content

        if save_to is not None:
            Path(save_to).write_bytes(data)

        return data

    def get_accounting_snapshot_csvs(self, user: EthAddress) -> AccountingSnapshotCSVs:
        """Get the accounting snapshot as a list of dicts (one per row)."""
        raw = self.get_accounting_snapshot_zip(user)
        with zipfile.ZipFile(io.BytesIO(raw)) as zf:
            positions_csv = zf.read("positions.csv").decode()
            equity_csv = zf.read("equity.csv").decode()
        return AccountingSnapshotCSVs(
            positions_csv=positions_csv, equity_csv=equity_csv
        )

    def get_leaderboard_rankings(
        self,
        address: Optional[EthAddress] = None,
        username: Optional[str] = None,
        category: Literal[
            "OVERALL",
            "POLITICS",
            "SPORTS",
            "CRYPTO",
            "CULTURE",
            "MENTIONS",
            "WEATHER",
            "ECONOMICS",
            "TECH",
            "FINANCE",
        ] = "OVERALL",
        time_period: Literal["DAY", "WEEK", "MONTH", "ALL"] = "DAY",
        order_by: Literal["PNL", "VOL"] = "PNL",
        limit: int = 25,  # 1 <= x <= 50
        offset: int = 0,  # 0 <= x <= 1000
    ) -> list[LeaderboardUser]:
        """Get the leaderboard rankings with optional filters and pagination."""
        params: dict[str, str | int] = {
            "category": category,
            "timePeriod": time_period,
            "orderBy": order_by,
            "limit": limit,
            "offset": offset,
        }
        if address:
            params["user"] = address
        if username:
            params["username"] = username

        response = self.client.get(self._build_url("/v1/leaderboard"), params=params)
        response.raise_for_status()
        return [LeaderboardUser(**user) for user in response.json()]

    def get_builder_leaderboard_aggregated(
        self, time_period: Literal["DAY", "WEEK", "MONTH", "ALL"] = "DAY"
    ) -> list[BuilderLeaderboardUser]:
        """Get the aggregated builder volume leaderboard rankings for a given time period."""
        params = {"timePeriod": time_period}
        response = self.client.get(
            self._build_url("/v1/builders/leaderboard"), params=params
        )
        response.raise_for_status()
        return [BuilderLeaderboardUser(**user) for user in response.json()]

    def get_builder_leaderboard_timeseries(
        self, granularity: Literal["DAY", "WEEK", "MONTH", "ALL"] = "DAY"
    ) -> list[BuilderLeaderboardUser]:
        """Get the builder volume leaderboard timeseries with a given granularity."""
        params = {"timePeriod": granularity}
        response = self.client.get(
            self._build_url("/v1/builders/volume"), params=params
        )
        response.raise_for_status()
        return cast("list[BuilderLeaderboardUser]", response.json())

    # website endpoints

    def get_pnl(
        self,
        user: EthAddress,
        period: Literal["all", "1m", "1w", "1d"] = "all",
        frequency: Literal["1h", "3h", "12h", "1d"] = "1h",
    ) -> list[TimeseriesPoint]:
        """Get a user's PnL timeseries in the last day, week, month or all with a given frequency."""
        params = {
            "user_address": user,
            "interval": period,
            "fidelity": frequency,
        }

        response = self.client.get(
            "https://user-pnl-api.polymarket.com/user-pnl", params=params
        )
        response.raise_for_status()
        return [TimeseriesPoint(**point) for point in response.json()]

    def get_user_metric(
        self,
        user: EthAddress,
        metric: Literal["profit", "volume"] = "profit",
        window: Literal["1d", "7d", "30d", "all"] = "all",
    ) -> UserMetric:
        """Get a user's overall profit or volume in the last day, week, month or all."""
        params: dict[str, int | str] = {
            "address": user,
            "window": window,
            "limit": 1,
        }
        response = self.client.get(
            "https://lb-api.polymarket.com/" + metric, params=params
        )
        response.raise_for_status()
        return UserMetric(**response.json()[0])

    def get_leaderboard_user_rank(
        self,
        user: EthAddress,
        metric: Literal["profit", "volume"] = "profit",
        window: Literal["1d", "7d", "30d", "all"] = "all",
    ) -> UserRank:
        """Get a user's rank on the leaderboard by profit or volume."""
        params = {
            "address": user,
            "window": window,
            "rankType": "pnl" if metric == "profit" else "vol",
        }
        response = self.client.get("https://lb-api.polymarket.com/rank", params=params)
        response.raise_for_status()
        return UserRank(**response.json()[0])

    def get_leaderboard_top_users(
        self,
        metric: Literal["profit", "volume"] = "profit",
        window: Literal["1d", "7d", "30d", "all"] = "all",
        limit: int = 100,
    ) -> list[UserMetric]:
        """Get the leaderboard of the top at most 100 users by profit or volume."""
        params = {
            "window": window,
            "limit": limit,
        }
        response = self.client.get(
            "https://lb-api.polymarket.com/" + metric, params=params
        )
        response.raise_for_status()
        return [UserMetric(**user) for user in response.json()]

    def __enter__(self) -> object:
        return self

    def __exit__(self, exc_type: object, exc_val: object, exc_tb: object) -> None:
        self.client.close()
