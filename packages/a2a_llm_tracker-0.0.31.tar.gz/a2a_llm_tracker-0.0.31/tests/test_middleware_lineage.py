from __future__ import annotations

from a2a_llm_tracker.middleware import (
    get_call_id,
    get_parent_call_id,
    get_sequence_number,
    set_call_id,
    set_parent_call_id,
    set_sequence_number,
)


def test_call_lineage_context_setters_and_getters():
    set_call_id("call-1")
    set_parent_call_id("parent-1")
    set_sequence_number("7")

    assert get_call_id() == "call-1"
    assert get_parent_call_id() == "parent-1"
    assert get_sequence_number() == "7"
