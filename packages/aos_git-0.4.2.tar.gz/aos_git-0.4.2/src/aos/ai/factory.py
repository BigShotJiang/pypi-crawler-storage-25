from aos.config.settings import Config
from aos.ai.adapter import AIAdapter
from aos.ai.databricks import DatabricksAdapter
from aos.ai.anthropic_adapter import AnthropicAdapter


def build_adapter(config: Config) -> AIAdapter:
    """설정에 따라 적절한 AI 어댑터를 반환한다."""
    if config.ai.provider == "databricks":
        if not config.databricks or not config.databricks.host:
            raise ValueError("Databricks 설정이 없습니다. 'aos setup'을 실행하세요.")
        return DatabricksAdapter(
            host=config.databricks.host,
            token=config.databricks.token,
            model=config.ai.model,
        )
    elif config.ai.provider == "anthropic":
        if not config.anthropic or not config.anthropic.api_key:
            raise ValueError("Anthropic API 키가 없습니다. 'aos setup'을 실행하세요.")
        return AnthropicAdapter(
            api_key=config.anthropic.api_key,
            model=config.ai.model,
        )
    else:
        raise ValueError(f"알 수 없는 AI 제공자: {config.ai.provider}")
