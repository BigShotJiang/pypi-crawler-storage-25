from typing import Optional
from openai import OpenAI
from aos.ai.adapter import AIAdapter, SYSTEM_PROMPT, USER_TEMPLATE
from aos.conflict.parser import ConflictBlock


class DatabricksAdapter(AIAdapter):
    def __init__(
        self,
        host: str,
        token: str,
        model: str = "databricks-claude-sonnet-4-6",
        _client: Optional[object] = None,
    ):
        self.model = model
        self._client = _client or OpenAI(
            api_key=token,
            base_url=f"{host.rstrip('/')}/serving-endpoints",
        )

    def resolve_conflict(
        self,
        block: ConflictBlock,
        ours_ts: str,
        theirs_ts: str,
    ) -> str:
        prompt = USER_TEMPLATE.format(
            file_path=block.file_path,
            base=block.base or "(없음)",
            ours=block.ours,
            theirs=block.theirs,
            ours_ts=ours_ts or "알 수 없음",
            theirs_ts=theirs_ts or "알 수 없음",
            context_before=block.context_before,
            context_after=block.context_after,
        )
        response = self._client.chat.completions.create(
            model=self.model,
            messages=[
                {"role": "system", "content": SYSTEM_PROMPT},
                {"role": "user", "content": prompt},
            ],
        )
        return response.choices[0].message.content
