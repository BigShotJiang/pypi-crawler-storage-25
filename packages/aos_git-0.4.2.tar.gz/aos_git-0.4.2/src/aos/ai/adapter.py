from abc import ABC, abstractmethod
from aos.conflict.parser import ConflictBlock

SYSTEM_PROMPT = """당신은 git merge conflict 해결 전문가입니다.
두 개발자가 같은 코드를 수정했을 때, 양쪽의 변경 의도를 모두 보존하여 논리적으로 통합된 코드를 반환합니다.
- 한쪽 변경사항을 일방적으로 버리지 마세요.
- 충돌 마커(<<<<<<, =======, >>>>>>>) 없이 최종 코드만 반환하세요.
- 코드 블록 마크다운(```) 없이 순수 코드만 반환하세요."""

USER_TEMPLATE = """다음 충돌을 해결해주세요.

파일: {file_path}
BASE (공통 조상):
{base}

OURS (커밋 시각: {ours_ts}):
{ours}

THEIRS (커밋 시각: {theirs_ts}):
{theirs}

주변 코드:
{context_before}
[충돌 위치]
{context_after}

두 변경사항을 모두 살려 통합된 코드를 반환하세요."""


class AIAdapter(ABC):
    @abstractmethod
    def resolve_conflict(
        self,
        block: ConflictBlock,
        ours_ts: str,
        theirs_ts: str,
    ) -> str:
        """통합된 코드 문자열을 반환한다."""
