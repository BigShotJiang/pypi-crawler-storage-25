from typing import Optional
import anthropic
from aos.ai.adapter import AIAdapter, SYSTEM_PROMPT, USER_TEMPLATE
from aos.conflict.parser import ConflictBlock


class AnthropicAdapter(AIAdapter):
    def __init__(
        self,
        api_key: str,
        model: str = "claude-sonnet-4-6",
        _client: Optional[object] = None,
    ):
        self.model = model
        self._client = _client or anthropic.Anthropic(api_key=api_key)

    def resolve_conflict(
        self,
        block: ConflictBlock,
        ours_ts: str,
        theirs_ts: str,
    ) -> str:
        prompt = USER_TEMPLATE.format(
            file_path=block.file_path,
            base=block.base or "(없음)",
            ours=block.ours,
            theirs=block.theirs,
            ours_ts=ours_ts or "알 수 없음",
            theirs_ts=theirs_ts or "알 수 없음",
            context_before=block.context_before,
            context_after=block.context_after,
        )
        response = self._client.messages.create(
            model=self.model,
            max_tokens=4096,
            system=SYSTEM_PROMPT,
            messages=[{"role": "user", "content": prompt}],
        )
        return response.content[0].text
