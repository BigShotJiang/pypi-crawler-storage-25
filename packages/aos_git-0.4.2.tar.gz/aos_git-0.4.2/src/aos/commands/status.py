import subprocess
import click
from rich.console import Console
from rich.table import Table

console = Console()


@click.command("status")
def status_cmd():
    """현재 git 상태를 친화적으로 표시한다."""
    result = subprocess.run(
        ["git", "status", "--porcelain=v1", "-b"],
        capture_output=True, text=True,
    )
    if result.returncode != 0:
        console.print("[red]git 저장소가 아니거나 오류가 발생했습니다.[/red]")
        raise click.Abort()

    lines = result.stdout.splitlines()
    branch_line = lines[0] if lines else ""
    file_lines = lines[1:]

    branch = branch_line.replace("## ", "").split("...")[0]
    console.print(f"\n[bold]현재 브랜치:[/bold] [cyan]{branch}[/cyan]\n")

    if not file_lines:
        console.print("[green]변경사항 없음. 깨끗한 상태입니다.[/green]")
        return

    table = Table(show_header=True, header_style="bold")
    table.add_column("상태", width=12)
    table.add_column("파일")

    STATUS_MAP = {
        "M": ("수정됨", "yellow"),
        "A": ("추가됨", "green"),
        "D": ("삭제됨", "red"),
        "R": ("이름변경", "blue"),
        "?": ("미추적", "dim"),
        "U": ("충돌", "bold red"),
    }

    for line in file_lines:
        if len(line) < 3:
            continue
        xy = line[:2].strip() or line[0]
        filepath = line[3:]
        code = xy[0] if xy else "?"
        label, color = STATUS_MAP.get(code, (code, "white"))
        table.add_row(f"[{color}]{label}[/{color}]", filepath)

    console.print(table)
