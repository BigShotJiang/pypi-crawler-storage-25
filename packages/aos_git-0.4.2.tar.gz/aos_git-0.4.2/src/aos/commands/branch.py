import subprocess
import click
from rich.console import Console
from rich.table import Table

console = Console()


@click.command("branch")
@click.option("-a", "--all", "show_all", is_flag=True, default=False, help="원격 브랜치 포함 전체 표시")
@click.option("-d", "--delete", "delete", default="", help="브랜치 삭제")
def branch_cmd(show_all: bool, delete: str):
    """브랜치 목록을 표시하거나 삭제한다."""
    if delete:
        result = subprocess.run(
            ["git", "branch", "-d", delete],
            capture_output=True, text=True,
        )
        if result.returncode == 0:
            console.print(f"[green][aos] '{delete}' 브랜치 삭제 완료.[/green]")
        else:
            console.print(f"[red][aos] 삭제 실패: {result.stderr}[/red]")
            raise click.Abort()
        return

    if show_all:
        subprocess.run(["git", "fetch", "--prune", "origin"], capture_output=True)

    cmd = ["git", "branch", "-vv"] + (["-a"] if show_all else [])
    result = subprocess.run(cmd, capture_output=True, text=True)
    lines = result.stdout.splitlines()

    table = Table(show_header=True, header_style="bold")
    table.add_column("", width=2)       # 현재 브랜치 표시
    table.add_column("브랜치")
    table.add_column("마지막 커밋", style="dim")

    for line in lines:
        is_current = line.startswith("*")
        parts = line[2:].split()
        if not parts:
            continue
        name = parts[0]
        # remotes/origin/HEAD 같은 포인터 스킵
        if "->" in line:
            continue
        commit_msg = " ".join(parts[2:]) if len(parts) > 2 else ""
        marker = "[bold green]*[/bold green]" if is_current else " "
        style = "bold green" if is_current else ""
        table.add_row(marker, f"[{style}]{name}[/{style}]" if style else name, commit_msg)

    console.print(table)
