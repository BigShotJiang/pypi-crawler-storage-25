import subprocess
from pathlib import Path
import click
from rich.console import Console
from aos.config.settings import load_config
from aos.ai.factory import build_adapter
from aos.conflict.resolver import resolve_all_conflicts

console = Console()


@click.command("pull")
@click.option("--remote", default="origin", help="원격 저장소 이름")
@click.option("--branch", default="", help="브랜치 이름 (기본: 현재 브랜치)")
def pull_cmd(remote: str, branch: str):
    """원격에서 변경사항을 가져오고, 충돌 시 AI가 해결을 제안한다."""
    cmd = ["git", "pull", remote]
    if branch:
        cmd.append(branch)

    console.print(f"[cyan][aos] {' '.join(cmd)} 실행 중...[/cyan]")
    result = subprocess.run(cmd, capture_output=True, text=True)
    console.print(result.stdout)

    if result.returncode == 0:
        console.print("[green][aos] 완료.[/green]")
        return

    # 충돌 여부 확인
    if "CONFLICT" in result.stdout or "conflict" in result.stderr.lower():
        console.print("[yellow][aos] 충돌이 감지되었습니다. AI 해결을 시도합니다...[/yellow]")
        try:
            cfg = load_config()
            adapter = build_adapter(cfg)
        except ValueError as e:
            console.print(f"[red][aos] {e}[/red]")
            raise click.Abort()

        repo_root = Path.cwd()
        resolve_all_conflicts(repo_root, adapter, cfg.behavior)
    else:
        console.print(f"[red][aos] 오류: {result.stderr}[/red]")
        raise click.Abort()
