import subprocess
import click
from rich.console import Console

console = Console()


@click.command("commit")
@click.option("-m", "--message", default="", help="커밋 메시지")
def commit_cmd(message: str):
    """모든 변경사항을 스테이징하고 커밋한다."""
    subprocess.run(["git", "add", "-A"], check=True)
    console.print("[cyan][aos] 모든 변경사항을 스테이징했습니다.[/cyan]")

    if not message:
        message = click.prompt("커밋 메시지를 입력하세요")

    result = subprocess.run(["git", "commit", "-m", message])
    if result.returncode == 0:
        console.print("[green][aos] 커밋 완료.[/green]")
    else:
        console.print("[red][aos] 커밋 실패.[/red]")
        raise click.Abort()
