import subprocess
from pathlib import Path
import click
from rich.console import Console
from aos.config.settings import load_config
from aos.ai.factory import build_adapter
from aos.conflict.resolver import resolve_all_conflicts

console = Console()


def _is_remote_branch(branch: str) -> bool:
    """origin/feature/xxx 또는 슬래시 포함 브랜치명을 remote로 판단한다."""
    return "/" in branch


def _fetch_remote(remote: str) -> bool:
    """원격 저장소에서 최신 정보를 가져온다. 성공 시 True."""
    console.print(f"[cyan][aos] git fetch {remote} 실행 중...[/cyan]")
    result = subprocess.run(["git", "fetch", remote], capture_output=True, text=True)
    if result.returncode != 0:
        console.print(f"[red][aos] fetch 실패: {result.stderr}[/red]")
        return False
    return True


@click.command("merge")
@click.argument("branch")
@click.option("--no-fetch", is_flag=True, default=False, help="fetch 없이 바로 병합")
def merge_cmd(branch: str, no_fetch: bool):
    """브랜치를 병합하고, 충돌 시 AI가 해결을 제안한다. remote 브랜치는 자동 fetch."""
    # remote 브랜치이거나 origin/ 없이 입력된 경우 fetch 먼저 실행
    if not no_fetch:
        remote = branch.split("/")[0] if _is_remote_branch(branch) else "origin"
        _fetch_remote(remote)

    # origin/feature/xxx 형태로 입력됐으면 그대로, 아니면 origin/ 붙여서 시도
    merge_target = branch
    console.print(f"[cyan][aos] git merge {merge_target} 실행 중...[/cyan]")
    result = subprocess.run(["git", "merge", merge_target], capture_output=True, text=True)
    console.print(result.stdout)

    if result.returncode == 0:
        console.print("[green][aos] 병합 완료.[/green]")
        return

    if "CONFLICT" in result.stdout or "conflict" in result.stderr.lower():
        console.print("[yellow][aos] 충돌이 감지되었습니다. AI 해결을 시도합니다...[/yellow]")
        try:
            cfg = load_config()
            adapter = build_adapter(cfg)
        except ValueError as e:
            console.print(f"[red][aos] {e}[/red]")
            raise click.Abort()

        repo_root = Path.cwd()
        all_resolved = resolve_all_conflicts(repo_root, adapter, cfg.behavior)
        if all_resolved:
            _auto_commit(branch)
        else:
            console.print("[yellow][aos] 일부 충돌이 해결되지 않았습니다. 수동으로 확인 후 커밋하세요.[/yellow]")
    else:
        console.print(f"[red][aos] 오류: {result.stderr}[/red]")
        raise click.Abort()


def _auto_commit(branch: str) -> None:
    """충돌 해결 후 자동으로 스테이징하고 커밋한다."""
    subprocess.run(["git", "add", "-A"], capture_output=True)
    commit_msg = f"merge: {branch}"
    result = subprocess.run(
        ["git", "commit", "-m", commit_msg],
        capture_output=True, text=True,
    )
    if result.returncode == 0:
        console.print(f"[green][aos] 커밋 완료: '{commit_msg}'[/green]")
    else:
        console.print(f"[red][aos] 커밋 실패: {result.stderr}[/red]")
