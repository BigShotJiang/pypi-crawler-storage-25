import subprocess
import click
from rich.console import Console

console = Console()


@click.command("checkout")
@click.argument("branch")
@click.option("-b", "--new", "create", is_flag=True, default=False, help="브랜치를 새로 만들고 전환")
@click.option("--push", "auto_push", is_flag=True, default=False, help="생성 후 원격에 바로 push")
def checkout_cmd(branch: str, create: bool, auto_push: bool):
    """브랜치를 전환하거나 새로 만든다."""
    if create:
        result = subprocess.run(
            ["git", "checkout", "-b", branch],
            capture_output=True, text=True,
        )
        if result.returncode != 0:
            console.print(f"[red][aos] 브랜치 생성 실패: {result.stderr}[/red]")
            raise click.Abort()
        console.print(f"[green][aos] 브랜치 '{branch}' 생성 및 전환 완료.[/green]")

        if auto_push:
            push_result = subprocess.run(
                ["git", "push", "-u", "origin", branch],
                capture_output=True, text=True,
            )
            if push_result.returncode == 0:
                console.print(f"[green][aos] 원격에 '{branch}' 브랜치 등록 완료.[/green]")
            else:
                console.print(f"[yellow][aos] 원격 push 실패 (나중에 'aos push'로 시도): {push_result.stderr}[/yellow]")
    else:
        # 로컬에 없으면 원격에서 자동으로 가져와서 전환
        result = subprocess.run(
            ["git", "checkout", branch],
            capture_output=True, text=True,
        )
        if result.returncode != 0:
            # 원격에만 있는 브랜치일 수 있으므로 fetch 후 재시도
            console.print(f"[cyan][aos] 원격에서 '{branch}' 브랜치를 가져오는 중...[/cyan]")
            subprocess.run(["git", "fetch", "origin"], capture_output=True)
            retry = subprocess.run(
                ["git", "checkout", "-b", branch, f"origin/{branch}"],
                capture_output=True, text=True,
            )
            if retry.returncode != 0:
                console.print(f"[red][aos] 브랜치 전환 실패: {result.stderr}[/red]")
                raise click.Abort()
        console.print(f"[green][aos] '{branch}' 브랜치로 전환 완료.[/green]")
