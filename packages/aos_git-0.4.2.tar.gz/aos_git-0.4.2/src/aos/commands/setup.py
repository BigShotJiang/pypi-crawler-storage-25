import subprocess
from pathlib import Path
import click
from rich.console import Console
from aos.config.settings import (
    load_config, save_config, AIConfig,
    DatabricksConfig, AnthropicConfig, BehaviorConfig, NotifyConfig,
)

console = Console()

GITLAB_CI_TEMPLATE = """\
stages:
  - notify

notify-branch-update:
  stage: notify
  only:
    - {branch}
  script:
    - python3 scripts/notify_main_update.py
"""

NOTIFY_CONFIG_TEMPLATE = """\
# aos-git 알림 설정
# aos setup --notify 로 자동 생성됨

[notify]
branch = "{branch}"
recipients = {recipients}
"""


def _generate_ci_files(branch: str, recipients: list[str], repo_root: Path) -> None:
    """GitLab CI 설정 파일과 수신자 config를 생성한다."""
    ci_path = repo_root / ".gitlab-ci.yml"
    ci_path.write_text(GITLAB_CI_TEMPLATE.format(branch=branch))
    console.print(f"[green][aos] .gitlab-ci.yml 생성됨 (브랜치: {branch})[/green]")

    scripts_dir = repo_root / "scripts"
    scripts_dir.mkdir(exist_ok=True)
    recipients_toml = "[" + ", ".join(f'"{r}"' for r in recipients) + "]"
    config_path = scripts_dir / "notify_config.toml"
    config_path.write_text(NOTIFY_CONFIG_TEMPLATE.format(branch=branch, recipients=recipients_toml))
    console.print(f"[green][aos] scripts/notify_config.toml 생성됨[/green]")


def _setup_notify(cfg) -> None:
    """알림 설정만 단독으로 진행한다."""
    current = cfg.notify
    console.print("[bold cyan][aos] GitLab 알림 설정[/bold cyan]")

    if current.branch or current.recipients:
        console.print(f"  현재 브랜치  : [yellow]{current.branch or '(없음)'}[/yellow]")
        console.print(f"  현재 수신자  : [yellow]{', '.join(current.recipients) or '(없음)'}[/yellow]")
        console.print()

    branch = click.prompt("알림을 받을 브랜치 이름", default=current.branch or "main")
    recipients_raw = click.prompt(
        "수신자 이메일 (콤마로 구분, 예: a@lge.com,b@lge.com)",
        default=", ".join(current.recipients) if current.recipients else "",
    )
    recipients = [r.strip() for r in recipients_raw.split(",") if r.strip()]

    cfg.notify = NotifyConfig(branch=branch, recipients=recipients)
    save_config(cfg)

    repo_root = _find_repo_root()
    if repo_root:
        _generate_ci_files(branch, recipients, repo_root)
        console.print(
            "\n[yellow][aos] 변경사항을 커밋하고 push 해야 GitLab에 반영됩니다.[/yellow]"
        )
        console.print("       git add .gitlab-ci.yml scripts/notify_config.toml")
        console.print("       git commit -m 'chore: update notify config'")
    else:
        console.print("[yellow][aos] git 저장소를 찾을 수 없어 CI 파일을 생성하지 못했습니다.[/yellow]")

    console.print("\n[green][aos] 알림 설정 완료![/green]")


@click.command("setup")
@click.option("--notify", "notify_only", is_flag=True, default=False, help="알림 설정만 변경한다")
def setup_cmd(notify_only: bool):
    """AI 제공자를 설정하고 git을 구성한다.

    알림 설정만 변경하려면: aos setup --notify
    """
    cfg = load_config()

    if notify_only:
        _setup_notify(cfg)
        return

    # ── 전체 설정 ──────────────────────────────────────────
    console.print("[bold cyan][aos] 설정을 시작합니다.[/bold cyan]")

    provider = click.prompt(
        "AI 제공자를 선택하세요",
        type=click.Choice(["databricks", "anthropic"]),
        default=cfg.ai.provider,
    )
    cfg.ai = AIConfig(provider=provider)

    if provider == "databricks":
        host = click.prompt("Databricks Host", default=cfg.databricks.host if cfg.databricks else "")
        token = click.prompt("Databricks Token", hide_input=True, default=cfg.databricks.token if cfg.databricks else None)
        model = click.prompt("모델 엔드포인트", default=cfg.ai.model or "databricks-claude-sonnet-4-6")
        cfg.databricks = DatabricksConfig(host=host, token=token)
        cfg.ai.model = model
    else:
        api_key = click.prompt("Anthropic API Key", hide_input=True, default=cfg.anthropic.api_key if cfg.anthropic else None)
        model = click.prompt("모델", default=cfg.ai.model or "claude-sonnet-4-6")
        cfg.anthropic = AnthropicConfig(api_key=api_key)
        cfg.ai.model = model

    lang = click.prompt("안내 메시지 언어", type=click.Choice(["ko", "en"]), default=cfg.behavior.language)
    cfg.behavior = BehaviorConfig(language=lang)

    # 알림 설정
    console.print("\n[bold cyan][aos] GitLab 알림 설정[/bold cyan]")
    console.print("  (병합 담당자가 특정 브랜치에 push 하면 팀원에게 이메일 알림을 보냅니다)")

    notify_enabled = click.confirm("GitLab 이메일 알림을 설정하시겠습니까?", default=True)

    if notify_enabled:
        _setup_notify(cfg)
    else:
        cfg.notify = NotifyConfig()
        save_config(cfg)

    # diff3 스타일 자동 설정
    subprocess.run(["git", "config", "--global", "merge.conflictstyle", "diff3"], check=False)

    console.print("\n[green][aos] 설정 완료! ~/.aos/config.toml 에 저장됨.[/green]")
    console.print("[green]       git merge.conflictstyle=diff3 적용됨.[/green]")


def _find_repo_root() -> Path | None:
    result = subprocess.run(
        ["git", "rev-parse", "--show-toplevel"],
        capture_output=True, text=True,
    )
    if result.returncode == 0:
        return Path(result.stdout.strip())
    return None
