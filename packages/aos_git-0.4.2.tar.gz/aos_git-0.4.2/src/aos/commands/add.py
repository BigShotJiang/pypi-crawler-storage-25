import subprocess
import click
from rich.console import Console

console = Console()


@click.command("add")
@click.argument("files", nargs=-1)
def add_cmd(files: tuple):
    """변경사항을 스테이징한다. 파일 미지정 시 전체 스테이징."""
    cmd = ["git", "add"] + (list(files) if files else ["-A"])
    result = subprocess.run(cmd, capture_output=True, text=True)
    if result.returncode == 0:
        target = " ".join(files) if files else "전체"
        console.print(f"[green][aos] 스테이징 완료: {target}[/green]")
    else:
        console.print(f"[red][aos] 오류: {result.stderr}[/red]")
        raise click.Abort()
