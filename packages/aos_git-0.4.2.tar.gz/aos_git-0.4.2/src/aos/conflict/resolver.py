import click
from pathlib import Path
from rich.console import Console

from aos.conflict.detector import find_conflict_files
from aos.conflict.parser import parse_conflicts, get_merge_timestamps
from aos.conflict.preview import show_conflict_preview, ask_apply
from aos.conflict.applier import apply_resolution
from aos.ai.adapter import AIAdapter

console = Console()


def resolve_all_conflicts(repo_root: Path, adapter: AIAdapter, behavior) -> bool:
    """
    repo_root 내 모든 충돌을 처리한다.
    같은 파일 내 여러 충돌은 결정을 먼저 모두 수집한 뒤 역순으로 적용한다.
    (앞 블록을 먼저 적용하면 뒤 블록의 줄 번호가 어긋나는 버그 방지)
    반환값: 모든 충돌이 적용되면 True, 하나라도 건너뛰면 False.
    """
    conflict_files = find_conflict_files(repo_root)
    if not conflict_files:
        console.print("[green][aos] 충돌이 없습니다.[/green]")
        return True

    ours_ts, theirs_ts = get_merge_timestamps(repo_root)
    all_applied = True
    total_blocks = sum(len(parse_conflicts(f)) for f in conflict_files)
    index = 0

    for file_path in conflict_files:
        blocks = parse_conflicts(file_path, context_lines=behavior.context_lines)
        # 1단계: 모든 블록에 대해 AI 해결 + 사용자 결정 수집
        decisions: list[tuple] = []  # (block, resolved, choice)
        for block in blocks:
            index += 1
            try:
                resolved = adapter.resolve_conflict(block, ours_ts=ours_ts, theirs_ts=theirs_ts)
            except Exception as e:
                console.print(f"[red][aos] AI 호출 실패: {e}[/red]")
                console.print("[yellow]수동 해결: git mergetool[/yellow]")
                decisions.append((block, "", "n"))
                all_applied = False
                continue

            show_conflict_preview(block, resolved, index, total_blocks)
            choice = "y" if behavior.auto_apply else ask_apply(behavior.language)
            decisions.append((block, resolved, choice))

        # 2단계: 역순으로 적용 (줄 번호 보존)
        for block, resolved, choice in reversed(decisions):
            if choice == "y":
                apply_resolution(file_path, block.line_start, resolved)
                console.print(f"[green]  적용됨 (라인 {block.line_start})[/green]")
            elif choice == "e":
                click.edit(filename=str(file_path))
                all_applied = False
            else:
                console.print(f"[yellow]  건너뜀 (라인 {block.line_start}) — 충돌 마커 유지됨[/yellow]")
                all_applied = False

    if not all_applied:
        console.print("[yellow][aos] 일부 충돌이 남아 있습니다. 'git merge --abort' 또는 수동 해결하세요.[/yellow]")

    return all_applied
