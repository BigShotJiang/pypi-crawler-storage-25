from pathlib import Path

CONFLICT_MARKER = "<<<<<<< "
SKIP_DIRS = {".git", "__pycache__", "node_modules", ".venv", "venv"}


def find_conflict_files(repo_root: Path) -> list[Path]:
    """repo_root 아래에서 충돌 마커가 있는 파일 목록을 반환한다."""
    conflict_files = []
    for path in repo_root.rglob("*"):
        if path.is_file() and not any(p.name in SKIP_DIRS for p in path.parents):
            try:
                text = path.read_text(encoding="utf-8", errors="ignore")
                if CONFLICT_MARKER in text:
                    conflict_files.append(path)
            except (PermissionError, OSError):
                pass
    return conflict_files
