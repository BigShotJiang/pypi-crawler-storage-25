from dataclasses import dataclass
from pathlib import Path
import subprocess


@dataclass
class ConflictBlock:
    file_path: Path
    line_start: int    # 1-based, <<<<<<< 줄 번호
    ours: str
    base: str          # diff3 스타일 있을 때만 채워짐
    theirs: str
    context_before: str
    context_after: str


def parse_conflicts(file_path: Path, context_lines: int = 20) -> list[ConflictBlock]:
    """파일 내 모든 충돌 블록을 파싱하여 반환한다."""
    text = file_path.read_text(encoding="utf-8")
    lines = text.splitlines(keepends=True)
    blocks = []
    i = 0
    while i < len(lines):
        if lines[i].startswith("<<<<<<<"):
            block_start = i
            ours_lines, base_lines, theirs_lines = [], [], []
            section = "ours"
            i += 1
            while i < len(lines):
                line = lines[i]
                if line.startswith("|||||||"):
                    section = "base"
                    i += 1
                    continue
                elif line.startswith("======="):
                    section = "theirs"
                    i += 1
                    continue
                elif line.startswith(">>>>>>>"):
                    i += 1
                    break
                if section == "ours":
                    ours_lines.append(line)
                elif section == "base":
                    base_lines.append(line)
                else:
                    theirs_lines.append(line)
                i += 1
            ctx_start = max(0, block_start - context_lines)
            ctx_end = min(len(lines), i + context_lines)
            blocks.append(ConflictBlock(
                file_path=file_path,
                line_start=block_start + 1,
                ours="".join(ours_lines),
                base="".join(base_lines),
                theirs="".join(theirs_lines),
                context_before="".join(lines[ctx_start:block_start]),
                context_after="".join(lines[i:ctx_end]),
            ))
        else:
            i += 1
    return blocks


def get_merge_timestamps(repo_root: Path) -> tuple[str, str]:
    """HEAD(OURS)와 MERGE_HEAD(THEIRS)의 커밋 타임스탬프를 반환한다."""
    def _ts(ref: str) -> str:
        try:
            r = subprocess.run(
                ["git", "log", "-1", "--format=%ci", ref],
                capture_output=True, text=True, cwd=repo_root, timeout=5,
            )
            return r.stdout.strip()
        except Exception:
            return ""
    return _ts("HEAD"), _ts("MERGE_HEAD")
