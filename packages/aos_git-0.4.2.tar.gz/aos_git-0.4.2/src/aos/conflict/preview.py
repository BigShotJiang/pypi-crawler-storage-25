from rich.console import Console
from rich.panel import Panel
from rich.text import Text
from rich.columns import Columns
from aos.conflict.parser import ConflictBlock

console = Console()


def show_conflict_preview(
    block: ConflictBlock,
    resolved: str,
    index: int,
    total: int,
) -> None:
    """충돌 블록과 AI 해결안을 터미널에 나란히 출력한다."""
    console.rule(f"[bold yellow]충돌 {index}/{total}[/] — {block.file_path} (라인 {block.line_start})")

    ours_text = Text(f"[OURS]\n{block.ours}", style="red")
    theirs_text = Text(f"[THEIRS]\n{block.theirs}", style="blue")
    resolved_text = Text(f"[AI 통합 결과]\n{resolved}", style="green")

    console.print(Columns([
        Panel(ours_text, title="내 변경사항", border_style="red"),
        Panel(theirs_text, title="상대방 변경사항", border_style="blue"),
        Panel(resolved_text, title="AI 제안", border_style="green"),
    ]))


def ask_apply(language: str = "ko") -> str:
    """사용자에게 적용 여부를 묻고 'y', 'n', 'e' 중 하나를 반환한다."""
    msg = "적용할까요?" if language == "ko" else "Apply this resolution?"
    choice = console.input(f"[bold]{msg}[/] \\[Y/n/e(직접편집)] ").strip().lower()
    if choice in ("", "y"):
        return "y"
    elif choice == "e":
        return "e"
    return "n"
