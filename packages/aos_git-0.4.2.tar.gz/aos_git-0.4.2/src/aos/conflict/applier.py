from pathlib import Path


def apply_resolution(file_path: Path, line_start: int, resolved: str) -> None:
    """파일에서 line_start 위치의 충돌 블록을 resolved로 교체한다."""
    text = file_path.read_text(encoding="utf-8")
    lines = text.splitlines(keepends=True)
    # line_start는 1-based; <<<<<<< 줄 찾기
    i = line_start - 1
    if i >= len(lines) or not lines[i].startswith("<<<<<<<"):
        return
    # 블록 끝(>>>>>>>) 찾기
    j = i + 1
    while j < len(lines):
        if lines[j].startswith(">>>>>>>"):
            j += 1
            break
        j += 1
    new_lines = lines[:i] + [resolved] + lines[j:]
    file_path.write_text("".join(new_lines), encoding="utf-8")
