from dataclasses import dataclass, field
from pathlib import Path
from typing import Optional
import toml

CONFIG_PATH = Path.home() / ".aos" / "config.toml"


@dataclass
class AIConfig:
    provider: str = "databricks"
    model: str = "databricks-claude-sonnet-4-6"


@dataclass
class DatabricksConfig:
    host: str = ""
    token: str = ""


@dataclass
class AnthropicConfig:
    api_key: str = ""


@dataclass
class BehaviorConfig:
    auto_apply: bool = False
    context_lines: int = 20
    language: str = "ko"


@dataclass
class NotifyConfig:
    branch: str = "main"
    recipients: list = field(default_factory=list)  # ["a@lge.com", "b@lge.com"]


@dataclass
class Config:
    ai: AIConfig = field(default_factory=AIConfig)
    databricks: Optional[DatabricksConfig] = field(default_factory=DatabricksConfig)
    anthropic: Optional[AnthropicConfig] = field(default_factory=AnthropicConfig)
    behavior: BehaviorConfig = field(default_factory=BehaviorConfig)
    notify: NotifyConfig = field(default_factory=NotifyConfig)


def load_config() -> Config:
    if not CONFIG_PATH.exists():
        return Config()
    data = toml.load(CONFIG_PATH)
    notify_data = data.get("notify", {})
    return Config(
        ai=AIConfig(**data.get("ai", {})),
        databricks=DatabricksConfig(**data.get("databricks", {})),
        anthropic=AnthropicConfig(**data.get("anthropic", {})),
        behavior=BehaviorConfig(**data.get("behavior", {})),
        notify=NotifyConfig(
            branch=notify_data.get("branch", "main"),
            recipients=notify_data.get("recipients", []),
        ),
    )


def save_config(config: Config) -> None:
    CONFIG_PATH.parent.mkdir(parents=True, exist_ok=True)
    data = {
        "ai": {"provider": config.ai.provider, "model": config.ai.model},
        "databricks": {
            "host": config.databricks.host if config.databricks else "",
            "token": config.databricks.token if config.databricks else "",
        },
        "anthropic": {
            "api_key": config.anthropic.api_key if config.anthropic else "",
        },
        "behavior": {
            "auto_apply": config.behavior.auto_apply,
            "context_lines": config.behavior.context_lines,
            "language": config.behavior.language,
        },
        "notify": {
            "branch": config.notify.branch,
            "recipients": config.notify.recipients,
        },
    }
    with open(CONFIG_PATH, "w") as f:
        toml.dump(data, f)
