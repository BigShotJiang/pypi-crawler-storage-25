from unittest.mock import MagicMock
from aos.ai.databricks import DatabricksAdapter
from aos.ai.anthropic_adapter import AnthropicAdapter
from aos.conflict.parser import ConflictBlock
from pathlib import Path


def _make_block(ours: str, base: str, theirs: str) -> ConflictBlock:
    return ConflictBlock(
        file_path=Path("app.py"),
        line_start=1,
        ours=ours,
        base=base,
        theirs=theirs,
        context_before="",
        context_after="",
    )


def test_databricks_adapter_returns_resolved_string():
    block = _make_block("def f():\n    return 1\n", "", "def f(x):\n    return x\n")
    mock_client = MagicMock()
    mock_client.chat.completions.create.return_value = MagicMock(
        choices=[MagicMock(message=MagicMock(content="def f(x=None):\n    return x\n"))]
    )
    adapter = DatabricksAdapter(
        host="https://fake.databricks.net",
        token="fake-token",
        model="databricks-claude-sonnet-4-6",
        _client=mock_client,
    )
    result = adapter.resolve_conflict(block, ours_ts="2026-04-20", theirs_ts="2026-04-21")
    assert "def f(" in result
    mock_client.chat.completions.create.assert_called_once()


def test_anthropic_adapter_returns_resolved_string():
    block = _make_block("x = 1\n", "", "x = 2\n")
    mock_client = MagicMock()
    mock_client.messages.create.return_value = MagicMock(
        content=[MagicMock(text="x = 1  # merged\n")]
    )
    adapter = AnthropicAdapter(
        api_key="fake-key",
        model="claude-sonnet-4-6",
        _client=mock_client,
    )
    result = adapter.resolve_conflict(block, ours_ts="2026-04-20", theirs_ts="2026-04-21")
    assert "x = " in result
    mock_client.messages.create.assert_called_once()
