from pathlib import Path
from aos.conflict.applier import apply_resolution


def test_apply_resolution_replaces_conflict_block(tmp_path):
    f = tmp_path / "app.py"
    f.write_text(
        "# header\n"
        "<<<<<<< HEAD\n"
        "x = 1\n"
        "=======\n"
        "x = 2\n"
        ">>>>>>> other\n"
        "# footer\n"
    )
    apply_resolution(f, line_start=2, resolved="x = 1  # merged\n")
    result = f.read_text()
    assert "<<<<<<" not in result
    assert "=======" not in result
    assert ">>>>>>" not in result
    assert "x = 1  # merged" in result
    assert "# header" in result
    assert "# footer" in result


def test_apply_resolution_with_diff3_block(tmp_path):
    f = tmp_path / "app.py"
    f.write_text(
        "<<<<<<< HEAD\n"
        "a = 1\n"
        "||||||| base\n"
        "a = 0\n"
        "=======\n"
        "a = 2\n"
        ">>>>>>> other\n"
    )
    apply_resolution(f, line_start=1, resolved="a = 1 + 2\n")
    result = f.read_text()
    assert "a = 1 + 2" in result
    assert "<<<<<<" not in result
