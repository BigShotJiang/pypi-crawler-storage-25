from pathlib import Path
from aos.conflict.parser import parse_conflicts, ConflictBlock


def test_parse_single_conflict_diff3(tmp_path):
    f = tmp_path / "app.py"
    f.write_text(
        "# header\n"
        "<<<<<<< HEAD\n"
        "def login():\n"
        "    pass\n"
        "||||||| base\n"
        "def login():\n"
        "    return None\n"
        "=======\n"
        "def login(user_id):\n"
        "    pass\n"
        ">>>>>>> feature/auth\n"
        "# footer\n"
    )
    blocks = parse_conflicts(f, context_lines=1)
    assert len(blocks) == 1
    b = blocks[0]
    assert "def login():\n    pass\n" in b.ours
    assert "def login():\n    return None\n" in b.base
    assert "def login(user_id):\n    pass\n" in b.theirs
    assert b.line_start == 2


def test_parse_conflict_without_base(tmp_path):
    """diff3 없는 경우 base가 빈 문자열이어야 한다."""
    f = tmp_path / "app.py"
    f.write_text(
        "<<<<<<< HEAD\n"
        "x = 1\n"
        "=======\n"
        "x = 2\n"
        ">>>>>>> other\n"
    )
    blocks = parse_conflicts(f)
    assert len(blocks) == 1
    assert blocks[0].base == ""
    assert blocks[0].ours == "x = 1\n"
    assert blocks[0].theirs == "x = 2\n"


def test_parse_multiple_conflicts(tmp_path):
    f = tmp_path / "app.py"
    f.write_text(
        "<<<<<<< HEAD\na = 1\n=======\na = 2\n>>>>>>> other\n"
        "middle\n"
        "<<<<<<< HEAD\nb = 1\n=======\nb = 2\n>>>>>>> other\n"
    )
    blocks = parse_conflicts(f)
    assert len(blocks) == 2
