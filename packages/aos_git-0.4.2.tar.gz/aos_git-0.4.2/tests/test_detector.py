from pathlib import Path
from aos.conflict.detector import find_conflict_files


def test_find_conflict_files_detects_marker(tmp_path):
    conflict_file = tmp_path / "main.py"
    conflict_file.write_text(
        "def foo():\n"
        "<<<<<<< HEAD\n"
        "    return 1\n"
        "=======\n"
        "    return 2\n"
        ">>>>>>> feature\n"
    )
    clean_file = tmp_path / "clean.py"
    clean_file.write_text("def bar():\n    return 3\n")

    result = find_conflict_files(tmp_path)
    assert conflict_file in result
    assert clean_file not in result


def test_find_conflict_files_empty_dir(tmp_path):
    assert find_conflict_files(tmp_path) == []
