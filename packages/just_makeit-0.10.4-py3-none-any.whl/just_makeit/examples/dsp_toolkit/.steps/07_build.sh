make && make test
