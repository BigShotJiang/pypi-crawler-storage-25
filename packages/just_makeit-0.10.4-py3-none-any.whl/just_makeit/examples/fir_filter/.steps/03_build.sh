make
make test
