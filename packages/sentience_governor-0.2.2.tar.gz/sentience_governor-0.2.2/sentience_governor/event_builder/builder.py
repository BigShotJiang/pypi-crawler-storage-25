"""EventBuilder — the ONLY module that may compute advisory_flags,
policy_violations, and simulated_consequence.

Policy evaluation order (deterministic, fixed):
  REGISTRATION → INTENT → SCOPE → CONTEXT → MEMORY

First violation in this order determines simulated_consequence.

Lock usage
----------
EventBuilder uses the per-session sequencing lock owned by SessionManager.
It does NOT own or manage the lock's lifecycle.
"""

from __future__ import annotations

import json
import logging
import sys
import uuid
from datetime import datetime, timezone
from typing import Any, Dict, List, Optional, Tuple

from pydantic import ValidationError

from sentience_governor.cache.cache import (
    SENSITIVITY_TIERS,
    InProcessCache,
    _NO_PRIOR,
    max_sensitivity_tier,
)
from sentience_governor.schema.events import (
    AdvisoryFlag,
    AgentRegisteredPayload,
    ClassificationSource,
    ContextSnapshotPayload,
    DeploymentMode,
    ErrorType,
    EventType,
    GovernanceErrorPayload,
    GovernanceEvent,
    IntentConfidence,
    IntentDeclaredPayload,
    IntentSource,
    InterceptStage,
    MemoryWriteAttemptPayload,
    OperationType,
    PolicyViolation,
    PrimitiveType,
    ScopeAssertedPayload,
    Severity,
)
from sentience_governor.session_manager.manager import SessionManager

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Policy: simulated_consequence strings (verbatim from spec / golden trace)
# ---------------------------------------------------------------------------
_CONSEQUENCE: Dict[str, str] = {
    PolicyViolation.POL_001: (
        "This WRITE operation would have been blocked. "
        "The agent must declare intent before executing mutating operations."
    ),
    PolicyViolation.POL_002: (
        "This session would have been blocked at the central server. "
        "Unregistered agents cannot access tools."
    ),
    PolicyViolation.POL_003: (
        "Downstream tool calls requiring classified context would have been "
        "restricted until classification was provided."
    ),
    PolicyViolation.POL_004: (
        "This write would have been blocked. "
        "Memory writes require both classification and a retention policy."
    ),
    PolicyViolation.POL_005: (
        "This context escalation would have triggered a boundary check. "
        "The session would have been paused pending authorization review."
    ),
}

# Primitive evaluation order used to pick first consequence
_PRIMITIVE_ORDER = [
    PrimitiveType.REGISTRATION,
    PrimitiveType.INTENT,
    PrimitiveType.SCOPE,
    PrimitiveType.CONTEXT,
    PrimitiveType.MEMORY,
]

# Mapping from PolicyViolation → its primitive (for ordering)
_VIOLATION_PRIMITIVE: Dict[str, PrimitiveType] = {
    PolicyViolation.POL_002: PrimitiveType.REGISTRATION,
    PolicyViolation.POL_001: PrimitiveType.SCOPE,   # fires at SCOPE or INTENT (SCOPE wins order)
    PolicyViolation.POL_003: PrimitiveType.CONTEXT,
    PolicyViolation.POL_004: PrimitiveType.MEMORY,
    PolicyViolation.POL_005: PrimitiveType.CONTEXT,
}


def _first_consequence(violations: List[str]) -> Optional[str]:
    """Return simulated_consequence for the first violation in evaluation order."""
    if not violations:
        return None
    ordered = sorted(
        violations,
        key=lambda v: _PRIMITIVE_ORDER.index(
            _VIOLATION_PRIMITIVE.get(v, PrimitiveType.SYSTEM)
        ),
    )
    return _CONSEQUENCE.get(ordered[0])


def _now_utc() -> str:
    return datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%S.") + \
           f"{datetime.now(timezone.utc).microsecond // 1000:03d}Z"


class EventBuilder:
    """Constructs and validates all governance events.

    Parameters
    ----------
    session_manager : SessionManager
        Provides per-session sequencing lock and sequence number management.
    cache : InProcessCache
        Provides intent baseline and context sensitivity tier lookups.
    agent_id : str
        Agent identifier used for all events in this builder instance.
    session_id : str
        Session identifier.
    deployment_mode : DeploymentMode
        Topology declared at session start.
    """

    def __init__(
        self,
        session_manager: SessionManager,
        cache: InProcessCache,
        agent_id: str,
        session_id: str,
        deployment_mode: DeploymentMode = DeploymentMode.vendor_managed,
    ) -> None:
        self._sm = session_manager
        self._cache = cache
        self._agent_id = agent_id
        self._session_id = session_id
        self._deployment_mode = deployment_mode

    # ------------------------------------------------------------------
    # Public factory methods (one per event type)
    # ------------------------------------------------------------------

    def build_agent_registered(
        self,
        agent_version: Optional[str],
        vendor_id: Optional[str],
        declared_capabilities: List[str],
        owner_claim: Optional[str],
        policy_context: Optional[str] = None,
        timestamp_utc: Optional[str] = None,
        event_id: Optional[str] = None,
    ) -> Optional[GovernanceEvent]:
        payload = AgentRegisteredPayload(
            agent_id=self._agent_id,
            agent_version=agent_version,
            vendor_id=vendor_id,
            deployment_mode=self._deployment_mode,
            declared_capabilities=declared_capabilities,
            owner_claim=owner_claim,
            policy_context=policy_context,
        )
        flags, violations = self._eval_registration(payload)
        return self._finalise(
            event_id=event_id,
            event_type=EventType.AGENT_REGISTERED,
            primitive=PrimitiveType.REGISTRATION,
            payload=payload,
            flags=flags,
            violations=violations,
            timestamp_utc=timestamp_utc,
        )

    def build_intent_declared(
        self,
        stated_objective: Optional[str],
        intent_source: IntentSource,
        intent_confidence: IntentConfidence,
        authorization_claim: Optional[str],
        session_scope_hint: List[str],
        timestamp_utc: Optional[str] = None,
        event_id: Optional[str] = None,
    ) -> Optional[GovernanceEvent]:
        payload = IntentDeclaredPayload(
            stated_objective=stated_objective,
            intent_source=intent_source,
            intent_confidence=intent_confidence,
            authorization_claim=authorization_claim,
            session_scope_hint=session_scope_hint,
        )
        flags, violations = self._eval_intent(payload)
        # Update cache — intent baseline set from first INTENT_DECLARED
        self._cache.set_intent_baseline(
            self._session_id,
            stated_objective=stated_objective,
            scope_hint=session_scope_hint,
        )
        return self._finalise(
            event_id=event_id,
            event_type=EventType.INTENT_DECLARED,
            primitive=PrimitiveType.INTENT,
            payload=payload,
            flags=flags,
            violations=violations,
            timestamp_utc=timestamp_utc,
        )

    def build_scope_asserted(
        self,
        tool_id: str,
        asserted_permissions: List[str],
        target_system: str,
        operation_type: OperationType,
        authorization_claim: Optional[str] = None,
        timestamp_utc: Optional[str] = None,
        event_id: Optional[str] = None,
    ) -> Optional[GovernanceEvent]:
        payload = ScopeAssertedPayload(
            tool_id=tool_id,
            asserted_permissions=asserted_permissions,
            target_system=target_system,
            operation_type=operation_type,
        )
        flags, violations = self._eval_scope(payload, authorization_claim)
        return self._finalise(
            event_id=event_id,
            event_type=EventType.SCOPE_ASSERTED,
            primitive=PrimitiveType.SCOPE,
            payload=payload,
            flags=flags,
            violations=violations,
            timestamp_utc=timestamp_utc,
        )

    def build_context_snapshot(
        self,
        data_classifications: List[str],
        classification_source: ClassificationSource,
        provenance: List[str],
        retention_flags: List[str],
        context_size_tokens: int,
        authorization_claim: Optional[str] = None,
        timestamp_utc: Optional[str] = None,
        event_id: Optional[str] = None,
    ) -> Optional[GovernanceEvent]:
        payload = ContextSnapshotPayload(
            data_classifications=data_classifications,
            classification_source=classification_source,
            provenance=provenance,
            retention_flags=retention_flags,
            context_size_tokens=context_size_tokens,
        )
        # Update cache; get prior value (_NO_PRIOR sentinel on first snapshot)
        prior_value = self._cache.update_context_tier(
            self._session_id, data_classifications
        )
        flags, violations = self._eval_context(payload, prior_value, authorization_claim)
        return self._finalise(
            event_id=event_id,
            event_type=EventType.CONTEXT_SNAPSHOT,
            primitive=PrimitiveType.CONTEXT,
            payload=payload,
            flags=flags,
            violations=violations,
            timestamp_utc=timestamp_utc,
        )

    def build_memory_write_attempt(
        self,
        write_type,
        detection_mechanism,
        target_store: str,
        write_classification: str,
        write_size_tokens: int,
        retention_requested: Optional[str],
        timestamp_utc: Optional[str] = None,
        event_id: Optional[str] = None,
    ) -> Optional[GovernanceEvent]:
        payload = MemoryWriteAttemptPayload(
            write_type=write_type,
            detection_mechanism=detection_mechanism,
            target_store=target_store,
            write_classification=write_classification,
            write_size_tokens=write_size_tokens,
            retention_requested=retention_requested,
        )
        flags, violations = self._eval_memory(payload)
        return self._finalise(
            event_id=event_id,
            event_type=EventType.MEMORY_WRITE_ATTEMPT,
            primitive=PrimitiveType.MEMORY,
            payload=payload,
            flags=flags,
            violations=violations,
            timestamp_utc=timestamp_utc,
        )

    def build_governance_error(
        self,
        error_type: ErrorType,
        severity: Severity,
        failure_reason: str,
        intercept_stage: Optional[InterceptStage] = None,
        timestamp_utc: Optional[str] = None,
        event_id: Optional[str] = None,
    ) -> Optional[GovernanceEvent]:
        payload = GovernanceErrorPayload(
            error_type=error_type,
            severity=severity,
            intercept_stage=intercept_stage,
            failure_reason=failure_reason,
            agent_continued=True,
        )
        return self._finalise(
            event_id=event_id,
            event_type=EventType.GOVERNANCE_ERROR,
            primitive=PrimitiveType.SYSTEM,
            payload=payload,
            flags=[],
            violations=[],
            timestamp_utc=timestamp_utc,
        )

    # ------------------------------------------------------------------
    # Policy evaluation (private — ONLY place flags/violations are set)
    # ------------------------------------------------------------------

    def _eval_registration(
        self, payload: AgentRegisteredPayload
    ) -> Tuple[List[str], List[str]]:
        flags: List[str] = []
        violations: List[str] = []
        # AGENT_UNREGISTERED: no registration signal (agent_version null, vendor_id null,
        # declared_capabilities empty, owner_claim null)
        if (
            payload.agent_version is None
            and payload.vendor_id is None
            and not payload.declared_capabilities
            and payload.owner_claim is None
        ):
            flags.append(AdvisoryFlag.AGENT_UNREGISTERED)
            violations.append(PolicyViolation.POL_002)
        return flags, violations

    def _eval_intent(
        self, payload: IntentDeclaredPayload
    ) -> Tuple[List[str], List[str]]:
        flags: List[str] = []
        violations: List[str] = []
        if payload.intent_source == IntentSource.none:
            flags.append(AdvisoryFlag.INTENT_MISSING)
            # POL-001 fires on subsequent mutating operations, not here
        return flags, violations

    def _eval_scope(
        self,
        payload: ScopeAssertedPayload,
        authorization_claim: Optional[str],
    ) -> Tuple[List[str], List[str]]:
        flags: List[str] = []
        violations: List[str] = []

        intent_entry = self._cache.get_intent_baseline(self._session_id)

        is_mutating = payload.operation_type in (
            OperationType.WRITE,
            OperationType.DELETE,
            OperationType.EXECUTE,
        )

        # SCOPE_OPERATION_UNEXPECTED: mutating op with null intent baseline
        if is_mutating:
            if intent_entry is None or intent_entry.intent_stated_objective is None:
                flags.append(AdvisoryFlag.SCOPE_OPERATION_UNEXPECTED)
                violations.append(PolicyViolation.POL_001)

        # SCOPE_INTENT_MISMATCH: target_system not in scope hint
        if intent_entry is not None:
            scope_hint = [s.lower() for s in intent_entry.intent_scope_hint]
            target_lower = payload.target_system.lower()
            # Check if target system matches any hint (prefix or exact)
            match = any(
                target_lower == h or target_lower.startswith(h.split(".")[0])
                for h in scope_hint
            )
            if not match:
                flags.append(AdvisoryFlag.SCOPE_INTENT_MISMATCH)
                if PolicyViolation.POL_001 not in violations:
                    violations.append(PolicyViolation.POL_001)
        else:
            # No intent baseline yet → mismatch (baseline is null/empty)
            flags.append(AdvisoryFlag.SCOPE_INTENT_MISMATCH)
            if PolicyViolation.POL_001 not in violations:
                violations.append(PolicyViolation.POL_001)

        return flags, violations

    def _eval_context(
        self,
        payload: ContextSnapshotPayload,
        prior_value: object,
        authorization_claim: Optional[str],
    ) -> Tuple[List[str], List[str]]:
        flags: List[str] = []
        violations: List[str] = []

        # CONTEXT_UNCLASSIFIED
        if payload.classification_source == ClassificationSource.unclassified:
            flags.append(AdvisoryFlag.CONTEXT_UNCLASSIFIED)
            violations.append(PolicyViolation.POL_003)

        # SENSITIVITY_ESCALATION: cannot fire on first snapshot (_NO_PRIOR sentinel)
        if prior_value is not _NO_PRIOR:
            # prior_value is the prior tier string (or None for unclassified/below-public)
            prior_tier: Optional[str] = prior_value  # type: ignore[assignment]
            current_max = max_sensitivity_tier(payload.data_classifications)
            # None (empty/unclassified) is treated as below "public" → index -1
            prior_idx = SENSITIVITY_TIERS.index(prior_tier) if prior_tier in SENSITIVITY_TIERS else -1
            current_idx = (
                SENSITIVITY_TIERS.index(current_max) if current_max in SENSITIVITY_TIERS else -1
            )
            if current_idx > prior_idx:
                flags.append(AdvisoryFlag.SENSITIVITY_ESCALATION)
                if authorization_claim is None:
                    violations.append(PolicyViolation.POL_005)

        return flags, violations

    def _eval_memory(
        self, payload: MemoryWriteAttemptPayload
    ) -> Tuple[List[str], List[str]]:
        flags: List[str] = []
        violations: List[str] = []

        # MEMORY_WRITE_CANDIDATE: write matched a known persistence target
        if payload.write_type.value == "write_to_persistence_target":
            flags.append(AdvisoryFlag.MEMORY_WRITE_CANDIDATE)

        # MEMORY_WRITE_UNCLASSIFIED
        if payload.write_classification == "unclassified":
            flags.append(AdvisoryFlag.MEMORY_WRITE_UNCLASSIFIED)

        # POL-004: unclassified OR retention_requested is null
        if payload.write_classification == "unclassified" or payload.retention_requested is None:
            violations.append(PolicyViolation.POL_004)

        return flags, violations

    # ------------------------------------------------------------------
    # Core finalisation — sequence assignment + schema validation
    # ------------------------------------------------------------------

    def _finalise(
        self,
        event_id: Optional[str],
        event_type: EventType,
        primitive: PrimitiveType,
        payload: Any,
        flags: List[str],
        violations: List[str],
        timestamp_utc: Optional[str],
    ) -> Optional[GovernanceEvent]:
        """Assign sequence, validate schema, return GovernanceEvent or None.

        On schema validation failure, emits GOVERNANCE_ERROR to stdout and
        returns None (caller must not pass None to SinkWriter).
        """
        eid = event_id or str(uuid.uuid4())
        ts = timestamp_utc or _now_utc()
        consequence = _first_consequence(violations)

        with self._sm.acquire_sequence(self._session_id) as seq_ctx:
            seq = seq_ctx.next_sequence()
            prev = seq_ctx.last_event_id

            try:
                event = GovernanceEvent(
                    event_id=eid,
                    event_type=event_type,
                    session_id=self._session_id,
                    event_sequence_number=seq,
                    previous_event_id=prev,
                    agent_id=self._agent_id,
                    deployment_mode=self._deployment_mode,
                    timestamp_utc=ts,
                    primitive=primitive,
                    payload=payload,
                    advisory_flags=flags,
                    policy_violations=violations,
                    simulated_consequence=consequence,
                    pass_through=True,
                )
            except (ValidationError, Exception) as exc:
                # Emit GOVERNANCE_ERROR to stdout; do not write failed event
                self._emit_schema_violation(str(exc), primitive)
                return None

            seq_ctx.set_last_event_id(eid)

        # Touch session inactivity timer
        self._sm.touch(self._session_id)
        return event

    def _emit_schema_violation(self, reason: str, stage: PrimitiveType) -> None:
        stage_map = {
            PrimitiveType.REGISTRATION: InterceptStage.REGISTRATION,
            PrimitiveType.INTENT: InterceptStage.INTENT,
            PrimitiveType.SCOPE: InterceptStage.SCOPE,
            PrimitiveType.CONTEXT: InterceptStage.CONTEXT,
            PrimitiveType.MEMORY: InterceptStage.MEMORY,
        }
        error_payload = GovernanceErrorPayload(
            error_type=ErrorType.SCHEMA_VIOLATION,
            severity=Severity.warning,
            intercept_stage=stage_map.get(stage),
            failure_reason=reason,
            agent_continued=True,
        )
        err_event = {
            "event_id": str(uuid.uuid4()),
            "event_type": EventType.GOVERNANCE_ERROR,
            "session_id": self._session_id,
            "agent_id": self._agent_id,
            "primitive": PrimitiveType.SYSTEM,
            "payload": error_payload.model_dump(),
            "advisory_flags": [],
            "policy_violations": [],
            "simulated_consequence": None,
            "pass_through": True,
        }
        print(json.dumps(err_event), file=sys.stderr)
