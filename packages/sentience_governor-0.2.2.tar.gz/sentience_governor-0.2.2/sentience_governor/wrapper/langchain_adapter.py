"""LangChain Path B — SentienceCallbackHandler and SentienceMiddleware.

Mapping
-------
on_chain_start  → AGENT_REGISTERED
on_tool_start   → SCOPE_ASSERTED + CONTEXT_SNAPSHOT
on_tool_end     → CONTEXT_SNAPSHOT (update)
awrap_tool_call → observe only, never blocks

Intent capture
--------------
* From agent inputs or system prompts → INTENT_DECLARED as early as possible.
* Falls back to intent_source=none if no signal.

v0 constraint: observe only.  SentienceMiddleware never blocks.
"""

from __future__ import annotations

import logging
import uuid
from typing import Any, Dict, List, Optional, Union

from sentience_governor.cache.cache import InProcessCache
from sentience_governor.event_builder.builder import EventBuilder
from sentience_governor.schema.events import (
    ClassificationSource,
    DeploymentMode,
    IntentConfidence,
    IntentSource,
    OperationType,
)
from sentience_governor.session_manager.manager import SessionManager
from sentience_governor.sink.writer import SinkWriter

logger = logging.getLogger(__name__)


class SentienceCallbackHandler:
    """Maps LangChain callback events to governance control points.

    Attach as a callback handler to a LangChain agent or chain.
    This class does not inherit from BaseCallbackHandler to avoid a hard
    dependency on langchain-core at import time; it implements the same
    interface via duck typing.

    If langchain-core is available, you may subclass BaseCallbackHandler:

        from langchain_core.callbacks import BaseCallbackHandler
        class MySentienceHandler(SentienceCallbackHandler, BaseCallbackHandler): ...
    """

    def __init__(
        self,
        agent_id: str,
        session_manager: SessionManager,
        cache: InProcessCache,
        sink_writer: SinkWriter,
        deployment_mode: DeploymentMode = DeploymentMode.vendor_managed,
        agent_version: Optional[str] = None,
        vendor_id: Optional[str] = None,
        declared_capabilities: Optional[List[str]] = None,
        owner_claim: Optional[str] = None,
    ) -> None:
        self._agent_id = agent_id
        self._sm = session_manager
        self._cache = cache
        self._sink = sink_writer
        self._deployment_mode = deployment_mode
        self._agent_version = agent_version
        self._vendor_id = vendor_id
        self._declared_capabilities = declared_capabilities or []
        self._owner_claim = owner_claim
        self._session_id: Optional[str] = None
        self._intent_emitted: bool = False
        self._builder: Optional[EventBuilder] = None

    # ------------------------------------------------------------------
    # LangChain callback surface
    # ------------------------------------------------------------------

    def on_chain_start(
        self,
        serialized: Dict[str, Any],
        inputs: Dict[str, Any],
        **kwargs: Any,
    ) -> None:
        """Map to AGENT_REGISTERED; capture intent from inputs."""
        self._session_id = str(uuid.uuid4())
        self._sm.session_start(
            session_id=self._session_id, agent_id=self._agent_id
        )
        self._cache.init_session(self._session_id)
        self._builder = EventBuilder(
            session_manager=self._sm,
            cache=self._cache,
            agent_id=self._agent_id,
            session_id=self._session_id,
            deployment_mode=self._deployment_mode,
        )

        # Emit AGENT_REGISTERED
        event = self._builder.build_agent_registered(
            agent_version=self._agent_version,
            vendor_id=self._vendor_id,
            declared_capabilities=self._declared_capabilities,
            owner_claim=self._owner_claim,
        )
        if event:
            self._sink.write(event, self._session_id)

        # Attempt to capture intent from inputs
        stated_objective = self._extract_intent(inputs)
        self._emit_intent(stated_objective)

    def on_chain_end(self, outputs: Dict[str, Any], **kwargs: Any) -> None:
        if not self._intent_emitted and self._builder:
            self._emit_intent(None)
        if self._session_id:
            self._sink.session_closed(self._session_id, self._agent_id)
            self._sm.session_end(self._session_id)
            self._cache.clear_session(self._session_id)

    def on_tool_start(
        self,
        serialized: Dict[str, Any],
        input_str: str,
        **kwargs: Any,
    ) -> None:
        """Emit INTENT_DECLARED (if not yet), SCOPE_ASSERTED, CONTEXT_SNAPSHOT."""
        if not self._intent_emitted and self._builder:
            self._emit_intent(None)

        if not self._builder:
            return

        tool_name = serialized.get("name", "unknown_tool")
        operation_type = self._infer_operation_type(tool_name, input_str)

        # SCOPE_ASSERTED
        scope_event = self._builder.build_scope_asserted(
            tool_id=tool_name,
            asserted_permissions=[operation_type.value.lower()],
            target_system=self._extract_target_system(tool_name),
            operation_type=operation_type,
        )
        if scope_event:
            self._sink.write(scope_event, self._session_id)

        # CONTEXT_SNAPSHOT — at tool call with incoming data
        ctx_event = self._builder.build_context_snapshot(
            data_classifications=[],
            classification_source=ClassificationSource.unclassified,
            provenance=[tool_name],
            retention_flags=[],
            context_size_tokens=len(input_str.split()) * 2,
        )
        if ctx_event:
            self._sink.write(ctx_event, self._session_id)

    def on_tool_end(self, output: str, **kwargs: Any) -> None:
        """Update CONTEXT_SNAPSHOT with tool output (classification unknown)."""
        if not self._builder:
            return
        ctx_event = self._builder.build_context_snapshot(
            data_classifications=[],
            classification_source=ClassificationSource.unclassified,
            provenance=["tool_output"],
            retention_flags=[],
            context_size_tokens=len(str(output).split()) * 2,
        )
        if ctx_event:
            self._sink.write(ctx_event, self._session_id)

    # ------------------------------------------------------------------
    # Internal helpers
    # ------------------------------------------------------------------

    def _emit_intent(
        self,
        stated_objective: Optional[str],
        source: IntentSource = IntentSource.inferred,
    ) -> None:
        """Emit the INTENT_DECLARED event for this session.

        Parameters
        ----------
        stated_objective
            The objective string. If ``None``, the emitted event carries
            ``intent_source=none`` regardless of the ``source`` argument.
        source
            Where the objective came from. Defaults to
            ``IntentSource.inferred`` because the only call site that
            supplies a non-None ``stated_objective`` is ``on_chain_start``,
            which extracts the string from the chain's invocation inputs
            at runtime. Callers that want to declare an integrator-supplied
            objective must pass ``source=IntentSource.explicit`` explicitly.

        Confidence semantics
        --------------------
        Confidence reflects epistemic trust in the *content* of the
        objective, not the reliability of the *extraction mechanism*.

        * ``source=IntentSource.explicit`` -> ``IntentConfidence.explicit``
          (integrator declared the objective at wrapper construction time;
          high-trust content, high-trust mechanism)
        * ``source=IntentSource.inferred`` -> ``IntentConfidence.inferred_low``
          (extraction mechanism is reliable, but the meaning of the
          extracted string is opaque — it could be a user request, a
          machine-generated payload, or anything in between)
        * No objective supplied -> ``IntentConfidence.unknown``
        """
        if self._intent_emitted or not self._builder:
            return
        if stated_objective:
            confidence = (
                IntentConfidence.explicit
                if source is IntentSource.explicit
                else IntentConfidence.inferred_low
            )
        else:
            source = IntentSource.none
            confidence = IntentConfidence.unknown

        event = self._builder.build_intent_declared(
            stated_objective=stated_objective,
            intent_source=source,
            intent_confidence=confidence,
            authorization_claim=self._owner_claim,
            session_scope_hint=self._declared_capabilities,
        )
        if event:
            self._sink.write(event, self._session_id)
        self._intent_emitted = True

    @staticmethod
    def _extract_intent(inputs: Dict[str, Any]) -> Optional[str]:
        for key in ("input", "question", "objective", "task", "prompt"):
            if key in inputs and isinstance(inputs[key], str):
                return inputs[key]
        return None

    @staticmethod
    def _infer_operation_type(tool_name: str, input_str: str) -> OperationType:
        name_lower = tool_name.lower()
        if any(k in name_lower for k in ("write", "update", "create", "insert", "put")):
            return OperationType.WRITE
        if any(k in name_lower for k in ("delete", "remove", "drop")):
            return OperationType.DELETE
        if any(k in name_lower for k in ("exec", "run", "execute")):
            return OperationType.EXECUTE
        return OperationType.READ

    @staticmethod
    def _extract_target_system(tool_name: str) -> str:
        parts = tool_name.split(".")
        return parts[0] if len(parts) > 1 else tool_name


class SentienceMiddleware:
    """Wraps tool calls via awrap_tool_call — observe only, never blocks.

    Usage (conceptual):
        middleware = SentienceMiddleware(handler)
        agent = create_react_agent(..., middleware=[middleware])
    """

    def __init__(self, handler: SentienceCallbackHandler) -> None:
        self._handler = handler

    async def awrap_tool_call(
        self,
        tool_name: str,
        tool_input: Any,
        next_call: Any,
    ) -> Any:
        """Intercept tool call; emit governance events; never block."""
        serialized = {"name": tool_name}
        input_str = str(tool_input)
        self._handler.on_tool_start(serialized, input_str)
        try:
            result = await next_call(tool_input)
            self._handler.on_tool_end(str(result))
            return result
        except Exception:
            # Fail-open: governance failure must never block agent
            raise
