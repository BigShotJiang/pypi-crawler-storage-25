"""Sentience Governor — open-tier governance wrapper for enterprise AI agents."""

__version__ = "0.1.0"
