"""Pure aggregation over newline-delimited governance log files.

Purity contract
---------------
This module computes counts from its inputs and returns a result. It MUST
NOT make any persistence-policy decisions:

* It does not open, read, or write any state file.
* It does not decide whether a given window has been uploaded before.
* It does not rewrite the offsets it is handed — on detected truncation
  it raises ``LogTruncatedError`` and lets the caller decide whether to
  reset the offset to zero or abort.

The only filesystem interaction is **reading** the log files it is given,
starting at the offsets it is given. Everything else — which logs, which
window, what to do with the result — is the caller's responsibility.

Idempotence semantics (enforced in tests)
-----------------------------------------
1. **Event dedup is keyed on ``event_id``.** Two events with the same
   ``event_id`` seen within a single ``aggregate()`` call (whether in
   the same file or across multiple files) count exactly once. The
   first occurrence wins; subsequent occurrences are silently dropped.
2. **Window bounds are inclusive at both ends.** Events whose
   ``timestamp_utc`` compares lexicographically equal to ``window_start``
   or ``window_end`` are included in the aggregation.
3. **Across-call dedup is the caller's job** via per-log byte offsets.
   Given the same inputs and offsets, ``aggregate()`` is deterministic:
   calling it twice returns the same result.
4. **Events outside the window still advance the offset** — they are
   counted in ``events_before_window`` / ``events_after_window`` but
   do not contribute to ``counts_by_rule``. The offset advances past
   them so a subsequent run with the returned offset will not re-see
   them.
5. **Malformed JSON lines are skipped** (logged to stderr, offset still
   advances past them). Missing required fields (``event_id``,
   ``timestamp_utc``) also cause the event to be skipped.

Isolation
---------
No imports from ``sentience_governor``. Only stdlib.
"""

from __future__ import annotations

import json
import sys
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Dict, Iterable, Mapping, Sequence, Set


# ---------------------------------------------------------------------------
# Errors
# ---------------------------------------------------------------------------

class LogTruncatedError(Exception):
    """Raised when a starting offset is beyond the current size of a log.

    This typically means the log has been rotated or manually truncated.
    The aggregator will not silently restart from zero — restarting is a
    persistence-policy decision the caller must take deliberately.
    """

    def __init__(self, path: Path, file_size: int, starting_offset: int) -> None:
        super().__init__(
            f"Log file {path} has been truncated: "
            f"size={file_size} < starting_offset={starting_offset}"
        )
        self.path = path
        self.file_size = file_size
        self.starting_offset = starting_offset


# ---------------------------------------------------------------------------
# Result
# ---------------------------------------------------------------------------

@dataclass(frozen=True)
class AggregationResult:
    """Everything the caller needs after an aggregation pass.

    Fields
    ------
    counts_by_rule
        Map of policy rule ID → count of events inside the window whose
        ``policy_violations`` list contained that rule ID. Only rule IDs
        that actually fired appear in the map.
    advisory_counts
        Map of advisory flag name → count. Separately tracked so the
        aggregator is useful for internal analytics without bloating the
        sync wire payload. The caller decides whether to ship any of
        this over the wire.
    events_seen
        Total events read from disk (within the offset-to-EOF slice).
    events_in_window
        Subset of events_seen whose timestamp falls inside the window.
    events_before_window
        Events whose timestamp < window_start.
    events_after_window
        Events whose timestamp > window_end.
    duplicate_event_ids
        Count of events dropped because their ``event_id`` had already
        been seen earlier in this same call.
    malformed_lines
        Count of lines that failed to parse as JSON or were missing
        required fields.
    new_offsets
        Map of ``str(path)`` → final byte offset after reading. The
        caller is responsible for persisting these (or not) in whatever
        state store it manages.
    unique_event_ids
        The set of event_ids observed. Exposed for test introspection;
        not meant to ship anywhere.
    """

    counts_by_rule: Dict[str, int]
    advisory_counts: Dict[str, int]
    events_seen: int
    events_in_window: int
    events_before_window: int
    events_after_window: int
    duplicate_event_ids: int
    malformed_lines: int
    new_offsets: Dict[str, int]
    unique_event_ids: Set[str] = field(default_factory=set)


# ---------------------------------------------------------------------------
# Entry point
# ---------------------------------------------------------------------------

def aggregate(
    log_sources: Sequence[Path],
    starting_offsets: Mapping[str, int],
    window_start: str,
    window_end: str,
    *,
    stderr: Any = None,
) -> AggregationResult:
    """Aggregate governance events across ``log_sources`` into a result.

    Parameters
    ----------
    log_sources
        Log file paths to process. Order matters for cross-file event
        dedup: the first occurrence of an ``event_id`` wins.
    starting_offsets
        Map of ``str(path)`` → byte offset. Missing entries default to 0.
        The keys must match ``str(path)`` for the paths in ``log_sources``;
        otherwise they are ignored.
    window_start, window_end
        Inclusive ISO-8601 window bounds. Must be strings; lexicographic
        string comparison is used (correct for UTC ISO-8601 timestamps
        with uniform precision).
    stderr
        File-like object for skip warnings. Defaults to sys.stderr.
        Exposed so tests can capture skip messages without muting output
        globally.

    Returns
    -------
    AggregationResult
        Fully populated, immutable.

    Raises
    ------
    LogTruncatedError
        If any log file's starting_offset exceeds its current size.
    """
    if not isinstance(window_start, str) or not isinstance(window_end, str):
        raise TypeError("window_start and window_end must be ISO-8601 strings")
    if window_start > window_end:
        raise ValueError(
            f"window_start must be <= window_end: got {window_start!r} > {window_end!r}"
        )

    if stderr is None:
        stderr = sys.stderr

    counts_by_rule: Dict[str, int] = {}
    advisory_counts: Dict[str, int] = {}
    new_offsets: Dict[str, int] = {}
    unique_event_ids: Set[str] = set()

    events_seen = 0
    events_in_window = 0
    events_before_window = 0
    events_after_window = 0
    duplicate_event_ids = 0
    malformed_lines = 0

    for raw_path in log_sources:
        path = Path(raw_path)
        key = str(path)

        if not path.exists():
            # Log source configured but the file hasn't been created yet.
            # Not an error — the agent may not have run yet. Record the
            # starting offset unchanged so state.py isn't disturbed.
            new_offsets[key] = int(starting_offsets.get(key, 0))
            continue

        try:
            file_size = path.stat().st_size
        except OSError as exc:
            print(
                f"sentience-sync: cannot stat {path}: {exc}",
                file=stderr,
            )
            new_offsets[key] = int(starting_offsets.get(key, 0))
            continue

        start = int(starting_offsets.get(key, 0))
        if start > file_size:
            raise LogTruncatedError(path, file_size, start)

        final_offset = start
        try:
            with path.open("rb") as fh:
                fh.seek(start)
                while True:
                    line = fh.readline()
                    if not line:
                        break
                    # Record the offset AFTER the successfully-read line
                    # so a crash mid-file doesn't lose already-counted
                    # events.
                    final_offset = fh.tell()

                    event, is_malformed = _parse_line(line)
                    if is_malformed:
                        malformed_lines += 1
                        continue
                    if event is None:
                        continue

                    event_id = event.get("event_id")
                    timestamp = event.get("timestamp_utc")

                    if not isinstance(event_id, str) or not event_id:
                        malformed_lines += 1
                        continue
                    if not isinstance(timestamp, str) or not timestamp:
                        malformed_lines += 1
                        continue

                    events_seen += 1

                    if event_id in unique_event_ids:
                        duplicate_event_ids += 1
                        continue
                    unique_event_ids.add(event_id)

                    if timestamp < window_start:
                        events_before_window += 1
                        continue
                    if timestamp > window_end:
                        events_after_window += 1
                        continue

                    events_in_window += 1
                    _tally(event, counts_by_rule, advisory_counts)
        except OSError as exc:
            print(
                f"sentience-sync: read error on {path} at offset {final_offset}: {exc}",
                file=stderr,
            )

        new_offsets[key] = final_offset

    return AggregationResult(
        counts_by_rule=counts_by_rule,
        advisory_counts=advisory_counts,
        events_seen=events_seen,
        events_in_window=events_in_window,
        events_before_window=events_before_window,
        events_after_window=events_after_window,
        duplicate_event_ids=duplicate_event_ids,
        malformed_lines=malformed_lines,
        new_offsets=new_offsets,
        unique_event_ids=unique_event_ids,
    )


# ---------------------------------------------------------------------------
# Internals
# ---------------------------------------------------------------------------

def _parse_line(line: bytes) -> tuple[dict[str, Any] | None, bool]:
    """Decode and JSON-parse one NDJSON line.

    Returns
    -------
    (event, is_malformed)
        * ``(event, False)`` on success
        * ``(None, False)`` if the line is blank (whitespace-only)
        * ``(None, True)`` on decode error or JSON parse error or if
          the top-level value isn't an object
    """
    try:
        text = line.decode("utf-8").strip()
    except UnicodeDecodeError:
        return None, True

    if not text:
        return None, False

    try:
        parsed = json.loads(text)
    except json.JSONDecodeError:
        return None, True

    if not isinstance(parsed, dict):
        return None, True

    return parsed, False


def _tally(
    event: Mapping[str, Any],
    counts_by_rule: Dict[str, int],
    advisory_counts: Dict[str, int],
) -> None:
    """Fold an in-window event's violations and advisory flags into counters."""
    violations = event.get("policy_violations") or []
    if isinstance(violations, list):
        for rule in violations:
            if isinstance(rule, str) and rule:
                counts_by_rule[rule] = counts_by_rule.get(rule, 0) + 1

    flags = event.get("advisory_flags") or []
    if isinstance(flags, list):
        for flag in flags:
            if isinstance(flag, str) and flag:
                advisory_counts[flag] = advisory_counts.get(flag, 0) + 1
