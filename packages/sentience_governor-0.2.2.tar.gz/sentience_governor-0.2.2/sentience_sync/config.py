"""Sync configuration — JSON file + environment variables + CLI overrides.

Precedence (highest wins)
-------------------------
    CLI overrides > environment variables > config file > built-in defaults

Config file
-----------
Format: JSON object. Unknown keys raise ConfigError to catch typos loudly.

    {
        "endpoint": "https://sync.getsentience.ai/v1",
        "state_path": "~/.sentience/sync-state.json",
        "log_sources": ["/var/log/sentience/agent.jsonl"],
        "deployment_label": "prod",
        "timeout_seconds": 30,
        "protocol_version": "1.0",
        "report_geo": false
    }

Environment variables
---------------------
    SENTIENCE_SYNC_ENDPOINT         → endpoint
    SENTIENCE_SYNC_STATE_PATH       → state_path
    SENTIENCE_SYNC_LOG_SOURCES      → log_sources (pathsep-separated)
    SENTIENCE_SYNC_DEPLOYMENT_LABEL → deployment_label
    SENTIENCE_SYNC_TIMEOUT_SECONDS  → timeout_seconds
    SENTIENCE_SYNC_REPORT_GEO       → report_geo

Config file path discovery
--------------------------
* If the caller passes an explicit ``config_path`` and the file does not
  exist, ``ConfigError`` is raised. No silent fallback — this prevents the
  "my config isn't being read" class of bug.
* If no explicit path is passed, the default ``~/.sentience/sync-config.json``
  is used if present and silently skipped if absent.

Isolation
---------
This module MUST NOT import from sentience_governor. It uses only stdlib.
"""

from __future__ import annotations

import json
import os
from dataclasses import dataclass, field, fields
from pathlib import Path
from typing import Any, Mapping, Optional


# ---------------------------------------------------------------------------
# Defaults
# ---------------------------------------------------------------------------

DEFAULT_ENDPOINT = "https://sync.getsentience.ai/v1"
DEFAULT_STATE_PATH = "~/.sentience/sync-state.json"
DEFAULT_CONFIG_PATH = "~/.sentience/sync-config.json"
DEFAULT_TIMEOUT_SECONDS = 30.0
# Why 30s: the sync server runs on AWS Lambda. Each /v1/* endpoint is
# its own function with independent cold-start state. Field evidence
# from v0.2.1 (see docs/debug/sync-endpoint-cold-starts.md) showed that
# a deeply-cold Lambda on a slower client network can take 20-35s to
# respond. The previous 15s default was sufficient for typical /v1/register
# cold starts but failed for /v1/sync cold starts on slower paths.
# 30s comfortably covers most cold-start scenarios while still being
# short enough to fail fast if the network is genuinely down.
# Operators on slow links can raise it further via the
# SENTIENCE_SYNC_TIMEOUT_SECONDS env var or `timeout_seconds` config key.
DEFAULT_PROTOCOL_VERSION = "1.0"


# ---------------------------------------------------------------------------
# Errors
# ---------------------------------------------------------------------------

class ConfigError(Exception):
    """Raised when the config file, env vars, or CLI overrides are invalid."""


# ---------------------------------------------------------------------------
# Path / type helpers (pure, testable)
# ---------------------------------------------------------------------------

def _expand(p: str | Path) -> Path:
    """Expand ``~`` without resolving symlinks or requiring the path to exist."""
    return Path(os.path.expanduser(str(p)))


def _parse_bool(value: Any, context: str) -> bool:
    if isinstance(value, bool):
        return value
    if isinstance(value, str):
        s = value.strip().lower()
        if s in ("1", "true", "yes", "on"):
            return True
        if s in ("0", "false", "no", "off"):
            return False
        raise ConfigError(
            f"{context}: expected boolean (true/false/1/0/yes/no), got {value!r}"
        )
    raise ConfigError(
        f"{context}: expected boolean, got {type(value).__name__}"
    )


def _parse_float(value: Any, context: str) -> float:
    if isinstance(value, bool):
        # bool is an int subclass in Python; reject explicitly.
        raise ConfigError(f"{context}: expected numeric, got bool")
    if isinstance(value, (int, float)):
        return float(value)
    if isinstance(value, str):
        try:
            return float(value)
        except ValueError as exc:
            raise ConfigError(
                f"{context}: expected numeric, got {value!r}"
            ) from exc
    raise ConfigError(
        f"{context}: expected numeric, got {type(value).__name__}"
    )


def _parse_path_list(value: Any, context: str) -> tuple[Path, ...]:
    if isinstance(value, str):
        parts = [p for p in value.split(os.pathsep) if p]
    elif isinstance(value, (list, tuple)):
        parts = []
        for p in value:
            if not isinstance(p, (str, Path)):
                raise ConfigError(
                    f"{context}: list entries must be strings, "
                    f"got {type(p).__name__}"
                )
            s = str(p)
            if s:
                parts.append(s)
    else:
        raise ConfigError(
            f"{context}: expected list or pathsep-separated string, "
            f"got {type(value).__name__}"
        )
    return tuple(_expand(p) for p in parts)


# ---------------------------------------------------------------------------
# Config dataclass
# ---------------------------------------------------------------------------

@dataclass(frozen=True)
class SyncConfig:
    """Resolved Sync configuration after the precedence chain is applied.

    All fields are fully coerced to their final types.  Path fields have had
    ``~`` expanded but are NOT resolved to absolute real paths, so the dataclass
    can describe locations that do not yet exist (e.g. the state file on first
    run).
    """

    endpoint: str = DEFAULT_ENDPOINT
    state_path: Path = field(
        default_factory=lambda: _expand(DEFAULT_STATE_PATH)
    )
    log_sources: tuple[Path, ...] = ()
    deployment_label: Optional[str] = None
    timeout_seconds: float = DEFAULT_TIMEOUT_SECONDS
    protocol_version: str = DEFAULT_PROTOCOL_VERSION
    report_geo: bool = False


# ---------------------------------------------------------------------------
# Env var mapping
# ---------------------------------------------------------------------------

ENV_VAR_MAP: dict[str, str] = {
    "endpoint": "SENTIENCE_SYNC_ENDPOINT",
    "state_path": "SENTIENCE_SYNC_STATE_PATH",
    "log_sources": "SENTIENCE_SYNC_LOG_SOURCES",
    "deployment_label": "SENTIENCE_SYNC_DEPLOYMENT_LABEL",
    "timeout_seconds": "SENTIENCE_SYNC_TIMEOUT_SECONDS",
    "report_geo": "SENTIENCE_SYNC_REPORT_GEO",
}


# ---------------------------------------------------------------------------
# Internals
# ---------------------------------------------------------------------------

def _resolve_config_path(
    config_path: Optional[Path | str],
    default_path: Path,
) -> Optional[Path]:
    """Return the path to read, or None if no config file should be read.

    Raises ConfigError if an explicit path was given but does not exist.
    """
    if config_path is not None:
        resolved = _expand(config_path)
        if not resolved.exists():
            raise ConfigError(f"Config file not found: {resolved}")
        return resolved

    return default_path if default_path.exists() else None


def _load_file(path: Path) -> dict[str, Any]:
    try:
        raw = path.read_text(encoding="utf-8")
    except OSError as exc:
        raise ConfigError(f"Cannot read config file {path}: {exc}") from exc

    try:
        parsed = json.loads(raw)
    except json.JSONDecodeError as exc:
        raise ConfigError(f"Malformed JSON in {path}: {exc}") from exc

    if not isinstance(parsed, dict):
        raise ConfigError(
            f"Config file {path} must contain a JSON object at the top level"
        )

    known = {f.name for f in fields(SyncConfig)}
    unknown = set(parsed.keys()) - known
    if unknown:
        raise ConfigError(
            f"Unknown config key(s) in {path}: {sorted(unknown)}. "
            f"Known keys: {sorted(known)}"
        )
    return parsed


def _load_env(env: Mapping[str, str]) -> dict[str, Any]:
    out: dict[str, Any] = {}
    for field_name, env_name in ENV_VAR_MAP.items():
        if env_name in env:
            out[field_name] = env[env_name]
    return out


def _coerce(data: dict[str, Any]) -> dict[str, Any]:
    """Coerce a merged raw dict into the final types SyncConfig expects."""
    out: dict[str, Any] = {}

    if "endpoint" in data:
        value = data["endpoint"]
        if not isinstance(value, str) or not value:
            raise ConfigError(
                f"endpoint: expected non-empty string, got {value!r}"
            )
        out["endpoint"] = value

    if "state_path" in data:
        value = data["state_path"]
        if not isinstance(value, (str, Path)):
            raise ConfigError(
                f"state_path: expected string, got {type(value).__name__}"
            )
        out["state_path"] = _expand(value)

    if "log_sources" in data:
        out["log_sources"] = _parse_path_list(data["log_sources"], "log_sources")

    if "deployment_label" in data:
        value = data["deployment_label"]
        if value is None:
            out["deployment_label"] = None
        elif isinstance(value, str):
            out["deployment_label"] = value or None
        else:
            raise ConfigError(
                f"deployment_label: expected string or null, "
                f"got {type(value).__name__}"
            )

    if "timeout_seconds" in data:
        timeout = _parse_float(data["timeout_seconds"], "timeout_seconds")
        if timeout <= 0:
            raise ConfigError(
                f"timeout_seconds: must be > 0, got {timeout}"
            )
        out["timeout_seconds"] = timeout

    if "protocol_version" in data:
        value = data["protocol_version"]
        if not isinstance(value, str) or not value:
            raise ConfigError(
                f"protocol_version: expected non-empty string, got {value!r}"
            )
        out["protocol_version"] = value

    if "report_geo" in data:
        out["report_geo"] = _parse_bool(data["report_geo"], "report_geo")

    return out


# ---------------------------------------------------------------------------
# Public loader
# ---------------------------------------------------------------------------

def load_config(
    config_path: Optional[Path | str] = None,
    *,
    env: Optional[Mapping[str, str]] = None,
    cli_overrides: Optional[Mapping[str, Any]] = None,
    default_config_path: Optional[Path] = None,
) -> SyncConfig:
    """Resolve a SyncConfig by applying the full precedence chain.

    Parameters
    ----------
    config_path
        Optional path to a JSON config file. If provided and missing,
        ConfigError is raised. If omitted, ``default_config_path`` (or
        the built-in default) is used when present.
    env
        Environment mapping. Defaults to ``os.environ``. Exposed for tests.
    cli_overrides
        Dict of ``field_name -> value`` from CLI parsing. ``None`` values
        are treated as "not set" and skipped, so a CLI parser can pass
        every argparse field unconditionally without accidentally clearing
        config-file values.
    default_config_path
        Override the default config file location. Exposed for tests.

    Raises
    ------
    ConfigError
        Any invalid input — missing explicit file, malformed JSON,
        unknown keys, bad types, out-of-range values.
    """
    if env is None:
        env = os.environ

    if default_config_path is None:
        default_config_path = _expand(DEFAULT_CONFIG_PATH)

    # Layered merge (later layers override earlier ones).
    raw: dict[str, Any] = {}

    file_path = _resolve_config_path(config_path, default_config_path)
    if file_path is not None:
        raw.update(_load_file(file_path))

    raw.update(_load_env(env))

    if cli_overrides:
        for key, value in cli_overrides.items():
            if value is None:
                continue
            if key not in {f.name for f in fields(SyncConfig)}:
                raise ConfigError(f"Unknown CLI override key: {key!r}")
            raw[key] = value

    coerced = _coerce(raw)
    return SyncConfig(**coerced)
