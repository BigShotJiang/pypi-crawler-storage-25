"""sentience-sync command-line entry point.

Thinness contract
-----------------
Every subcommand function in this module does four things and nothing
else:

1. Parse arguments (argparse has already done the heavy lifting).
2. Call exactly one orchestration function.
3. Format the result and write it to stdout.
4. Catch expected exceptions and map them to exit codes.

Subcommands MUST NOT re-implement state rules, aggregation, or HTTP
transport. If a behaviour needs to change, it changes in
``sentience_sync.orchestration`` (or deeper) — not here.

Exit codes (stable, tested in ``tests/sync/test_cli.py``)
---------------------------------------------------------
    0 — success
    1 — config error (missing/malformed config file, invalid overrides,
        init refused because target exists without --force, unknown
        subcommand, argument validation failure)
    2 — network error (timeout, DNS, connection refused)
    3 — not registered (run / update-check called without prior
        registration)
    4 — server rejected payload (HTTP non-2xx, malformed response)
    5 — local state error (corrupt state file, unwritable state file,
        log truncation detected)

Output discipline
-----------------
* Error messages: stderr.
* Success output: stdout.
* --json: stdout only, ``json.dumps(..., sort_keys=True, indent=2)``
  so the machine surface is stable across runs (no dict-order surprises,
  no wall-clock drift beyond the fields the user explicitly asked for).
* status --json is pure JSON: no human prose, no transient formatting.
"""

from __future__ import annotations

import argparse
import json
import sys
from dataclasses import asdict
from pathlib import Path
from typing import Any, Dict, List, Optional, Sequence, TextIO, Tuple

from sentience_sync import orchestration
from sentience_sync.aggregator import LogTruncatedError
from sentience_sync.config import (
    DEFAULT_CONFIG_PATH,
    DEFAULT_ENDPOINT,
    DEFAULT_PROTOCOL_VERSION,
    DEFAULT_STATE_PATH,
    DEFAULT_TIMEOUT_SECONDS,
    ConfigError,
    SyncConfig,
    load_config,
)
from sentience_sync.orchestration import (
    AggregateResult,
    AlreadyRegisteredError,
    NotRegisteredError,
    RegisterResult,
    RunResult,
    UpdateCheckResult,
    check_updates,
    compute_aggregate,
    register_installation,
    run_sync,
)
from sentience_sync.state import StateError
from sentience_sync.transport import NetworkError, ServerError, TransportError


# ---------------------------------------------------------------------------
# Exit codes (named so tests can reference them symbolically)
# ---------------------------------------------------------------------------

EXIT_OK = 0
EXIT_CONFIG_ERROR = 1
EXIT_NETWORK_ERROR = 2
EXIT_NOT_REGISTERED = 3
EXIT_SERVER_ERROR = 4
EXIT_LOCAL_STATE_ERROR = 5


# ---------------------------------------------------------------------------
# Default config template written by `init`
# ---------------------------------------------------------------------------

def _default_config_template() -> Dict[str, Any]:
    """The JSON config init writes when no file exists yet."""
    return {
        "endpoint": DEFAULT_ENDPOINT,
        "state_path": DEFAULT_STATE_PATH,
        "log_sources": [],
        "deployment_label": None,
        "timeout_seconds": DEFAULT_TIMEOUT_SECONDS,
        "protocol_version": DEFAULT_PROTOCOL_VERSION,
        "report_geo": False,
    }


# ---------------------------------------------------------------------------
# Window flag parsing
# ---------------------------------------------------------------------------

def _parse_window(value: str) -> Tuple[str, str]:
    if not isinstance(value, str) or ".." not in value:
        raise argparse.ArgumentTypeError(
            f"--window must be 'start..end', got {value!r}"
        )
    parts = value.split("..", 1)
    if len(parts) != 2 or not parts[0].strip() or not parts[1].strip():
        raise argparse.ArgumentTypeError(
            f"--window must be 'start..end', got {value!r}"
        )
    return parts[0].strip(), parts[1].strip()


# ---------------------------------------------------------------------------
# Argparse builder
# ---------------------------------------------------------------------------

def _build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="sentience-sync",
        description=(
            "Sentience Sync — on-demand cloud bridge for the open-tier "
            "Governor runtime. Reads governance logs, aggregates "
            "per-rule counts, and on explicit invocation uploads "
            "aggregates (not events) to Sentience Cloud."
        ),
    )

    parser.add_argument(
        "--config",
        metavar="PATH",
        help="Path to sync-config.json. Default: ~/.sentience/sync-config.json.",
    )
    parser.add_argument(
        "--endpoint",
        metavar="URL",
        help="Override the configured sync endpoint URL.",
    )
    parser.add_argument(
        "--state-path",
        metavar="PATH",
        help="Override the state file path. Primarily for tests and the "
             "acceptance-live Makefile target; regular operators should "
             "use the default ~/.sentience/sync-state.json.",
    )
    parser.add_argument(
        "-v", "--verbose", action="store_true", help="Verbose diagnostic output."
    )
    parser.add_argument(
        "-q", "--quiet", action="store_true", help="Suppress non-error output."
    )

    sub = parser.add_subparsers(dest="subcommand", metavar="SUBCOMMAND")

    # init
    p_init = sub.add_parser(
        "init",
        help="Write a default sync-config.json if none exists.",
        description=(
            "Create a default config file at ~/.sentience/sync-config.json "
            "(or at the path given via --config). Refuses to overwrite an "
            "existing file unless --force is passed."
        ),
    )
    p_init.add_argument(
        "--force",
        action="store_true",
        help="Overwrite an existing config file.",
    )

    # register
    p_register = sub.add_parser(
        "register",
        help="Register this installation with Sentience Cloud.",
        description=(
            "Register this installation with Sentience Cloud. Contact "
            "information (--email and --name) is required because "
            "registering opts this installation into operator "
            "communications from Sentience Cloud."
        ),
    )
    p_register.add_argument(
        "--email",
        required=True,
        metavar="ADDR",
        help="Operator email address (required). Used for update notices "
             "and support.",
    )
    p_register.add_argument(
        "--name",
        required=True,
        metavar="NAME",
        help="Operator name (required).",
    )
    p_register.add_argument(
        "--organization",
        metavar="NAME",
        help="Optional: organization name.",
    )
    p_register.add_argument(
        "--role",
        metavar="ROLE",
        help="Optional: operator role (e.g. 'platform', 'security').",
    )
    p_register.add_argument(
        "--force",
        action="store_true",
        help="Re-register even if an installation_secret already exists. "
             "Your installation_id will be preserved; only the secret is "
             "refreshed.",
    )

    # run
    p_run = sub.add_parser(
        "run",
        help="Aggregate new events and upload to Sentience Cloud.",
    )
    p_run.add_argument(
        "--dry-run",
        action="store_true",
        help="Compute the aggregate and print the payload that would be "
             "sent, without touching the network or advancing state.",
    )
    p_run.add_argument(
        "--window",
        type=_parse_window,
        metavar="START..END",
        help="Override the time window (ISO-8601 pair, inclusive bounds).",
    )
    p_run.add_argument(
        "--json",
        action="store_true",
        help="Print the run result as JSON to stdout.",
    )

    # status
    p_status = sub.add_parser(
        "status",
        help="Print local installation state (never touches the network).",
    )
    p_status.add_argument(
        "--json",
        action="store_true",
        help="Print a stable machine-readable JSON snapshot to stdout.",
    )

    # aggregate
    p_aggregate = sub.add_parser(
        "aggregate",
        help="Compute counts across configured logs locally. "
             "No network. No state writes. Deterministic output.",
    )
    p_aggregate.add_argument(
        "--window",
        type=_parse_window,
        metavar="START..END",
        help="ISO-8601 window pair. Default: 1970..9999 (all time).",
    )
    p_aggregate.add_argument(
        "--json",
        action="store_true",
        help="Print results as JSON to stdout.",
    )

    # update-check
    sub.add_parser(
        "update-check",
        help="Query Sentience Cloud for recommended runtime / bundle updates.",
    )

    return parser


# ---------------------------------------------------------------------------
# main()
# ---------------------------------------------------------------------------

def main(
    argv: Optional[Sequence[str]] = None,
    *,
    stdout: Optional[TextIO] = None,
    stderr: Optional[TextIO] = None,
) -> int:
    """Entry point. Returns an exit code; never calls ``sys.exit``.

    Parameters
    ----------
    argv
        Argument list, defaults to ``sys.argv[1:]``.
    stdout, stderr
        Writable streams, defaults to ``sys.stdout`` / ``sys.stderr``.
        Exposed so tests can run ``main`` in-process with captured I/O.
    """
    if stdout is None:
        stdout = sys.stdout
    if stderr is None:
        stderr = sys.stderr

    parser = _build_parser()
    # argparse writes usage + error messages to the parser's configured
    # _print_message target, which defaults to sys.stderr. For in-process
    # test runs (and library consumers), redirect those messages to the
    # caller-supplied stderr so the test can assert on them. This is the
    # only way to capture argparse's usage errors without subprocess
    # fixtures or monkey-patching sys.stderr globally.
    original_stderr = sys.stderr
    try:
        sys.stderr = stderr
        try:
            args = parser.parse_args(argv)
        finally:
            sys.stderr = original_stderr
    except SystemExit as exc:
        # argparse uses SystemExit for --help and argument errors.
        return int(exc.code) if isinstance(exc.code, int) else EXIT_CONFIG_ERROR

    subcommand = args.subcommand or "run"

    # If the user invoked ``sentience-sync`` with no subcommand we fall
    # through to ``run``, but argparse never parsed the ``run`` subparser
    # so its flags are missing from the namespace. Fill in run's defaults
    # so the subcommand function can rely on them.
    if args.subcommand is None:
        for attr, default in (("dry_run", False), ("window", None), ("json", False)):
            if not hasattr(args, attr):
                setattr(args, attr, default)

    # ``init`` is the only command that runs without loading config
    # (it writes a fresh config file; there may be no config to load).
    if subcommand == "init":
        return _cmd_init(args, stdout=stdout, stderr=stderr)

    # Every other command needs a resolved config.
    cli_overrides: Dict[str, Any] = {}
    if args.endpoint:
        cli_overrides["endpoint"] = args.endpoint
    if getattr(args, "state_path", None):
        cli_overrides["state_path"] = args.state_path

    try:
        config = load_config(
            config_path=args.config,
            cli_overrides=cli_overrides,
        )
    except ConfigError as exc:
        print(f"sentience-sync: config error: {exc}", file=stderr)
        return EXIT_CONFIG_ERROR

    dispatch = {
        "register": _cmd_register,
        "run": _cmd_run,
        "status": _cmd_status,
        "aggregate": _cmd_aggregate,
        "update-check": _cmd_update_check,
    }
    handler = dispatch.get(subcommand)
    if handler is None:
        parser.print_help(stderr)
        return EXIT_CONFIG_ERROR

    return handler(args, config, stdout=stdout, stderr=stderr)


# ---------------------------------------------------------------------------
# init
# ---------------------------------------------------------------------------

def _cmd_init(
    args: argparse.Namespace,
    *,
    stdout: TextIO,
    stderr: TextIO,
) -> int:
    path = Path(
        args.config if args.config else DEFAULT_CONFIG_PATH
    ).expanduser()

    if path.exists() and not args.force:
        print(
            f"sentience-sync: config already exists at {path}",
            file=stderr,
        )
        print("  use --force to overwrite", file=stderr)
        return EXIT_CONFIG_ERROR

    try:
        path.parent.mkdir(parents=True, exist_ok=True)
        template = _default_config_template()
        path.write_text(
            json.dumps(template, sort_keys=True, indent=2) + "\n",
            encoding="utf-8",
        )
    except OSError as exc:
        print(
            f"sentience-sync: cannot write config to {path}: {exc}",
            file=stderr,
        )
        return EXIT_LOCAL_STATE_ERROR

    print(f"Wrote default config to {path}", file=stdout)
    print(
        "Next: edit the config to set log_sources and endpoint, "
        "then run `sentience-sync register`.",
        file=stdout,
    )
    return EXIT_OK


# ---------------------------------------------------------------------------
# register
# ---------------------------------------------------------------------------

def _cmd_register(
    args: argparse.Namespace,
    config: SyncConfig,
    *,
    stdout: TextIO,
    stderr: TextIO,
) -> int:
    # CLI-side custom validation (plan §4.4 / guardrail §11.8):
    # argparse handles presence; this handles blank/whitespace-only.
    # Both checks happen BEFORE any HTTP call.
    email_blank_error = _validate_nonblank(args.email, "--email")
    if email_blank_error is not None:
        print(email_blank_error, file=stderr)
        return EXIT_CONFIG_ERROR
    name_blank_error = _validate_nonblank(args.name, "--name")
    if name_blank_error is not None:
        print(name_blank_error, file=stderr)
        return EXIT_CONFIG_ERROR

    try:
        result = register_installation(
            config,
            contact_email=args.email,
            contact_name=args.name,
            organization=args.organization,
            operator_role=args.role,
            force=args.force,
        )
    except AlreadyRegisteredError as exc:
        print(str(exc), file=stdout)
        return EXIT_OK
    except NetworkError as exc:
        print(f"sentience-sync: network error: {exc}", file=stderr)
        return EXIT_NETWORK_ERROR
    except ServerError as exc:
        print(f"sentience-sync: server rejected request: {exc}", file=stderr)
        if exc.body:
            print(f"  body: {exc.body}", file=stderr)
        return EXIT_SERVER_ERROR
    except StateError as exc:
        print(f"sentience-sync: state error: {exc}", file=stderr)
        return EXIT_LOCAL_STATE_ERROR

    print(f"Registered installation {result.installation_id}", file=stdout)
    print(f"  contact: {result.contact_name} <{result.contact_email}>", file=stdout)
    print(f"  registered_at: {result.registered_at}", file=stdout)
    print(
        "  installation_secret stored locally in the state file "
        "(owner-only permissions on POSIX)",
        file=stdout,
    )
    return EXIT_OK


def _validate_nonblank(value: Optional[str], flag_name: str) -> Optional[str]:
    """Return an error string if ``value`` is blank/whitespace-only, else None.

    Argparse's ``required=True`` enforces presence; this function enforces
    non-emptiness after strip. Split this way per plan §4.4 so each layer
    owns exactly one concern.
    """
    if value is None or not value.strip():
        return f"sentience-sync: {flag_name} value must not be blank"
    return None


# ---------------------------------------------------------------------------
# run
# ---------------------------------------------------------------------------

def _cmd_run(
    args: argparse.Namespace,
    config: SyncConfig,
    *,
    stdout: TextIO,
    stderr: TextIO,
) -> int:
    try:
        result = run_sync(
            config,
            dry_run=args.dry_run,
            window=args.window,
        )
    except NotRegisteredError as exc:
        # Plan §3.7 / guardrail §11.8: exception message is either the
        # "Not registered" (never registered) or "Registration incomplete
        # or outdated" (has ID, no secret) form. Surface verbatim.
        print(f"sentience-sync: {exc}", file=stderr)
        return EXIT_NOT_REGISTERED
    except LogTruncatedError as exc:
        print(f"sentience-sync: log truncation detected: {exc}", file=stderr)
        print(
            "  a log file was rotated or truncated below the last "
            "recorded offset. No state was advanced. To re-process from "
            "the beginning, manually reset the offset in the state file.",
            file=stderr,
        )
        return EXIT_LOCAL_STATE_ERROR
    except NetworkError as exc:
        print(f"sentience-sync: network error: {exc}", file=stderr)
        return EXIT_NETWORK_ERROR
    except ServerError as exc:
        # 401 gets the targeted "your secret may be out of sync" message
        # (plan §4.4 / guardrail §11.8). Other server errors get the
        # generic surface.
        if exc.status_code == 401:
            print(
                "sentience-sync: Authorization failed. Your "
                "installation_secret may be out of sync.",
                file=stderr,
            )
            print(
                "Run 'sentience-sync register --email ... --name ...' "
                "again (your installation ID will be preserved).",
                file=stderr,
            )
            return EXIT_SERVER_ERROR
        print(f"sentience-sync: server rejected upload: {exc}", file=stderr)
        if exc.body:
            print(f"  body: {exc.body}", file=stderr)
        return EXIT_SERVER_ERROR
    except StateError as exc:
        print(f"sentience-sync: state error: {exc}", file=stderr)
        return EXIT_LOCAL_STATE_ERROR

    if args.json:
        _print_run_json(result, stdout)
    else:
        _print_run_human(result, stdout)
    return EXIT_OK


def _print_run_human(result: RunResult, stdout: TextIO) -> None:
    # Plan §3.6 / guardrail §11.3: duplicate branch is a successful
    # no-op. Branch on the flag, not on the server's response text.
    if result.dry_run:
        print("DRY RUN — no network call, no state advancement.", file=stdout)
        print("", file=stdout)
    elif result.duplicate:
        print(
            f"Already uploaded for this window (sync_run_id={result.sync_run_id})",
            file=stdout,
        )
        print(
            f"  window: {result.window_start} .. {result.window_end}",
            file=stdout,
        )
    else:
        print(
            f"Synced window {result.window_start} .. {result.window_end} "
            f"(sync_run_id={result.sync_run_id})",
            file=stdout,
        )

    agg = result.aggregation
    print(f"  events scanned:       {agg.events_seen}", file=stdout)
    print(f"  events in window:     {agg.events_in_window}", file=stdout)
    print(f"  events before window: {agg.events_before_window}", file=stdout)
    print(f"  events after window:  {agg.events_after_window}", file=stdout)
    print(f"  duplicate event_ids:  {agg.duplicate_event_ids}", file=stdout)
    print(f"  malformed lines:      {agg.malformed_lines}", file=stdout)

    if agg.counts_by_rule:
        print("", file=stdout)
        print("  counts_by_rule:", file=stdout)
        for rule in sorted(agg.counts_by_rule):
            print(f"    {rule}: {agg.counts_by_rule[rule]}", file=stdout)

    if result.dry_run:
        print("", file=stdout)
        print("  payload that would be sent:", file=stdout)
        rendered = json.dumps(result.payload, sort_keys=True, indent=2)
        for line in rendered.splitlines():
            print(f"    {line}", file=stdout)
    elif not result.duplicate:
        print(
            f"  state advanced: {len(result.aggregation.new_offsets)} log source(s)",
            file=stdout,
        )


def _print_run_json(result: RunResult, stdout: TextIO) -> None:
    agg = result.aggregation
    payload = {
        "dry_run": result.dry_run,
        "state_advanced": result.state_advanced,
        "duplicate": result.duplicate,
        "sync_run_id": result.sync_run_id,
        "window_start": result.window_start,
        "window_end": result.window_end,
        "aggregation": {
            "counts_by_rule": dict(sorted(agg.counts_by_rule.items())),
            "advisory_counts": dict(sorted(agg.advisory_counts.items())),
            "events_seen": agg.events_seen,
            "events_in_window": agg.events_in_window,
            "events_before_window": agg.events_before_window,
            "events_after_window": agg.events_after_window,
            "duplicate_event_ids": agg.duplicate_event_ids,
            "malformed_lines": agg.malformed_lines,
        },
        "upload_payload": result.payload if result.dry_run else None,
    }
    print(json.dumps(payload, sort_keys=True, indent=2), file=stdout)


# ---------------------------------------------------------------------------
# status
# ---------------------------------------------------------------------------

def _cmd_status(
    args: argparse.Namespace,
    config: SyncConfig,
    *,
    stdout: TextIO,
    stderr: TextIO,
) -> int:
    from sentience_sync.state import load_state

    try:
        state = load_state(config.state_path)
    except StateError as exc:
        print(f"sentience-sync: state error: {exc}", file=stderr)
        return EXIT_LOCAL_STATE_ERROR

    if args.json:
        _print_status_json(config, state, stdout)
    else:
        _print_status_human(config, state, stdout)
    return EXIT_OK


def _print_status_json(
    config: SyncConfig,
    state: Any,
    stdout: TextIO,
) -> None:
    """Write a stable machine-readable snapshot.

    Key contract
    ------------
    * Always the same keys regardless of registration state (nulls fill
      absent values). Stable for automation to consume.
    * All dicts are sorted by key via ``sort_keys=True``.
    * No human prose.
    * No transient formatting.
    """
    last_window: Optional[Dict[str, Any]] = None
    if state.uploaded_windows:
        latest = max(state.uploaded_windows, key=lambda w: w.window_end)
        last_window = {
            "window_start": latest.window_start,
            "window_end": latest.window_end,
            "uploaded_at": latest.uploaded_at,
            "counts_by_rule": dict(sorted(latest.counts_by_rule.items())),
        }

    payload: Dict[str, Any] = {
        "installation_id": state.installation_id,
        "registered": state.is_registered(),
        "has_installation_secret": state.has_installation_secret(),
        "contact_email": state.contact_email,
        "contact_name": state.contact_name,
        "registered_at": state.registered_at,
        "endpoint": config.endpoint,
        "state_path": str(config.state_path),
        "log_sources": [str(p) for p in config.log_sources],
        "log_offsets": {
            key: state.log_offsets[key].last_processed_offset
            for key in sorted(state.log_offsets)
        },
        "uploaded_windows_count": len(state.uploaded_windows),
        "last_uploaded_window": last_window,
        "deployment_label": config.deployment_label,
        "report_geo": config.report_geo,
        "protocol_version": config.protocol_version,
    }
    # DELIBERATE: installation_secret is NEVER in status output, even
    # in --json mode. Grep-testable: `sgn_live_` must not appear.
    print(json.dumps(payload, sort_keys=True, indent=2), file=stdout)


def _print_status_human(
    config: SyncConfig,
    state: Any,
    stdout: TextIO,
) -> None:
    if state.is_registered():
        print(f"Installation: {state.installation_id}", file=stdout)
        if state.contact_name and state.contact_email:
            print(
                f"Contact: {state.contact_name} <{state.contact_email}>",
                file=stdout,
            )
        if state.has_installation_secret():
            print("Secret: stored locally (owner-only perms)", file=stdout)
        else:
            print(
                "Secret: MISSING — run 'sentience-sync register "
                "--email ... --name ...' again",
                file=stdout,
            )
        print(f"Registered at: {state.registered_at}", file=stdout)
    else:
        print("Installation: not registered", file=stdout)
        print(
            "  run `sentience-sync register --email ... --name ...` "
            "to register with Sentience Cloud",
            file=stdout,
        )

    print(f"Endpoint: {config.endpoint}", file=stdout)
    print(f"State path: {config.state_path}", file=stdout)
    print(f"Report geo: {str(config.report_geo).lower()}", file=stdout)
    if config.deployment_label:
        print(f"Deployment label: {config.deployment_label}", file=stdout)

    print(f"Log sources ({len(config.log_sources)}):", file=stdout)
    for path in config.log_sources:
        key = str(path)
        entry = state.log_offsets.get(key)
        offset = entry.last_processed_offset if entry else 0
        print(f"  {path} → offset {offset}", file=stdout)

    print(f"Uploaded windows: {len(state.uploaded_windows)}", file=stdout)
    if state.uploaded_windows:
        latest = max(state.uploaded_windows, key=lambda w: w.window_end)
        print(
            f"  last: {latest.window_start} .. {latest.window_end} "
            f"(uploaded {latest.uploaded_at})",
            file=stdout,
        )


# ---------------------------------------------------------------------------
# aggregate (local dry, no network, no state writes, deterministic output)
# ---------------------------------------------------------------------------

def _cmd_aggregate(
    args: argparse.Namespace,
    config: SyncConfig,
    *,
    stdout: TextIO,
    stderr: TextIO,
) -> int:
    try:
        result = compute_aggregate(config, window=args.window)
    except LogTruncatedError as exc:
        print(f"sentience-sync: log truncation detected: {exc}", file=stderr)
        return EXIT_LOCAL_STATE_ERROR

    if args.json:
        _print_aggregate_json(result, stdout)
    else:
        _print_aggregate_human(result, stdout)
    return EXIT_OK


def _print_aggregate_human(result: AggregateResult, stdout: TextIO) -> None:
    agg = result.aggregation
    print(
        f"Aggregation window: {result.window_start} .. {result.window_end}",
        file=stdout,
    )
    print(f"Events scanned:          {agg.events_seen}", file=stdout)
    print(f"Events in window:        {agg.events_in_window}", file=stdout)
    print(f"Events before window:    {agg.events_before_window}", file=stdout)
    print(f"Events after window:     {agg.events_after_window}", file=stdout)
    print(f"Duplicate event_ids:     {agg.duplicate_event_ids}", file=stdout)
    print(f"Malformed lines:         {agg.malformed_lines}", file=stdout)

    print("", file=stdout)
    print("Policy violation counts:", file=stdout)
    if agg.counts_by_rule:
        for rule in sorted(agg.counts_by_rule):
            print(f"  {rule}: {agg.counts_by_rule[rule]}", file=stdout)
    else:
        print("  (none)", file=stdout)

    print("", file=stdout)
    print("Advisory flag counts:", file=stdout)
    if agg.advisory_counts:
        for flag in sorted(agg.advisory_counts):
            print(f"  {flag}: {agg.advisory_counts[flag]}", file=stdout)
    else:
        print("  (none)", file=stdout)


def _print_aggregate_json(result: AggregateResult, stdout: TextIO) -> None:
    agg = result.aggregation
    payload = {
        "window_start": result.window_start,
        "window_end": result.window_end,
        "counts_by_rule": dict(sorted(agg.counts_by_rule.items())),
        "advisory_counts": dict(sorted(agg.advisory_counts.items())),
        "events_seen": agg.events_seen,
        "events_in_window": agg.events_in_window,
        "events_before_window": agg.events_before_window,
        "events_after_window": agg.events_after_window,
        "duplicate_event_ids": agg.duplicate_event_ids,
        "malformed_lines": agg.malformed_lines,
    }
    print(json.dumps(payload, sort_keys=True, indent=2), file=stdout)


# ---------------------------------------------------------------------------
# update-check
# ---------------------------------------------------------------------------

def _cmd_update_check(
    args: argparse.Namespace,
    config: SyncConfig,
    *,
    stdout: TextIO,
    stderr: TextIO,
) -> int:
    try:
        result = check_updates(config)
    except NotRegisteredError as exc:
        print(f"sentience-sync: {exc}", file=stderr)
        return EXIT_NOT_REGISTERED
    except NetworkError as exc:
        print(f"sentience-sync: network error: {exc}", file=stderr)
        return EXIT_NETWORK_ERROR
    except ServerError as exc:
        print(f"sentience-sync: server rejected request: {exc}", file=stderr)
        if exc.body:
            print(f"  body: {exc.body}", file=stderr)
        return EXIT_SERVER_ERROR
    except StateError as exc:
        print(f"sentience-sync: state error: {exc}", file=stderr)
        return EXIT_LOCAL_STATE_ERROR

    response = result.response
    if not response.update_available:
        print("No updates available.", file=stdout)
        return EXIT_OK

    severity = response.severity or "info"
    print(f"[{severity}] {response.message or ''}".rstrip(), file=stdout)
    if response.min_runtime_version:
        print(
            f"  applies to runtime_version >= {response.min_runtime_version}",
            file=stdout,
        )
    if response.max_runtime_version:
        print(
            f"  applies to runtime_version <  {response.max_runtime_version}",
            file=stdout,
        )
    if response.link_url:
        print(f"  more: {response.link_url}", file=stdout)
    return EXIT_OK


# ---------------------------------------------------------------------------
# Script entry point
# ---------------------------------------------------------------------------

if __name__ == "__main__":  # pragma: no cover
    sys.exit(main())
