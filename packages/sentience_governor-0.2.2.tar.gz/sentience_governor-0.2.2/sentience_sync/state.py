"""Sync state file — installation_id, secret, contact, offsets, windows.

Purpose
-------
The state file is the boundary between one Sync run and the next. It is the
**only** place persistence-policy decisions live. The aggregator has no
knowledge of state; the CLI orchestration reads state, hands offsets to the
aggregator, and writes state back on success.

Schema (JSON on disk) — current version is **2**
------------------------------------------------
    {
        "version": 2,
        "installation_id": "inst_<uuid4>" | null,
        "installation_secret": "sgn_live_<32-byte-urlsafe>" | null,
        "contact_email": "ops@example.com" | null,
        "contact_name": "Ops Team" | null,
        "registered_at": "2026-04-14T22:00:00Z" | null,
        "log_offsets": {
            "/var/log/sentience/agent.jsonl": {
                "last_processed_offset": 4096,
                "last_processed_event_id": "evt_..." | null,
                "last_processed_at": "2026-04-14T22:00:00Z" | null
            }
        },
        "uploaded_windows": [
            {
                "window_start": "2026-04-14T00:00:00Z",
                "window_end":   "2026-04-14T23:59:59Z",
                "uploaded_at":  "2026-04-14T23:59:59Z",
                "counts_by_rule": {"POL-001": 0, ...}
            }
        ]
    }

Schema v1 backward compatibility
--------------------------------
v1 state files (no ``installation_secret``, ``contact_email``, or
``contact_name``) are tolerated on load: the three new fields default to
``None`` and the file is re-written as v2 on the next successful
``save_state``. This supports the upgrade path for any operator who
registered against the pre-0.2.0 placeholder URL — their existing
``installation_id`` is preserved verbatim so the server's recovery flow
(NULL ``installation_secret_hash``) refreshes the secret cleanly on the
next register call.

Files with ``version`` absent, numeric 0, 3+, or any non-int raise
``StateError`` — we don't silently accept a state file from a future
CLI we haven't written yet.

Idempotence rules (explicit)
----------------------------
* **Exact-match window dedup only.** Two uploaded windows are considered
  duplicates iff their ``(window_start, window_end)`` tuples are equal
  byte-for-byte.
* **Per-log byte offsets.** Cross-run event dedup is achieved by byte
  offsets.
* **Truncation detection is NOT state.py's job.** state.py stores offsets
  as opaque integers.

Atomic writes + permission hardening
------------------------------------
``save_state`` writes to a ``.tmp`` sibling, fsyncs, then uses
``os.replace`` to swap it into place. ``os.replace`` is atomic on POSIX
and on modern Windows filesystems. On POSIX, the temp file is created
with owner-only mode (``0o600``) from the first byte so the plaintext
``installation_secret`` never passes through a world-readable state. A
best-effort ``os.chmod(path, 0o600)`` after the replace restores perms
if the replace operation reset them. Chmod failures (Windows, some
container filesystems) log a warning to stderr and do NOT raise — the
state was saved correctly; only the extra hardening didn't stick.

This is best-effort local hardening, not perfect protection. See
``docs/plans/cli-v0.2.0-contract-update.md`` §3.1 for the full threat
model.
"""

from __future__ import annotations

import json
import os
import sys
from dataclasses import asdict, dataclass, field
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, List, Mapping, Optional


STATE_SCHEMA_VERSION = 2
STATE_SCHEMA_SUPPORTED_VERSIONS = (1, 2)
_SECRET_FILE_MODE = 0o600


# ---------------------------------------------------------------------------
# Errors
# ---------------------------------------------------------------------------

class StateError(Exception):
    """Raised when the state file is unreadable, corrupt, or has an
    incompatible schema version."""


# ---------------------------------------------------------------------------
# Substructures
# ---------------------------------------------------------------------------

@dataclass
class LogOffset:
    """Where we left off in a single log file on the previous run."""

    last_processed_offset: int = 0
    last_processed_event_id: Optional[str] = None
    last_processed_at: Optional[str] = None


@dataclass
class UploadedWindow:
    """Record of a successful upload. Kept for idempotence and operator audit."""

    window_start: str
    window_end: str
    uploaded_at: str
    counts_by_rule: Dict[str, int] = field(default_factory=dict)


# ---------------------------------------------------------------------------
# SyncState
# ---------------------------------------------------------------------------

@dataclass
class SyncState:
    installation_id: Optional[str] = None
    installation_secret: Optional[str] = None
    contact_email: Optional[str] = None
    contact_name: Optional[str] = None
    registered_at: Optional[str] = None
    log_offsets: Dict[str, LogOffset] = field(default_factory=dict)
    uploaded_windows: List[UploadedWindow] = field(default_factory=list)

    # ------------------------------------------------------------------
    # Registration
    # ------------------------------------------------------------------

    def is_registered(self) -> bool:
        return self.installation_id is not None

    def has_installation_secret(self) -> bool:
        """True iff a non-empty, non-whitespace secret is stored.

        Used by orchestration to distinguish "never registered" from
        "registered but missing/corrupted secret" when composing the
        operator-facing error message (see §3.7 of the plan).
        """
        secret = self.installation_secret
        return bool(secret and secret.strip())

    def register(
        self,
        installation_id: str,
        *,
        installation_secret: Optional[str] = None,
        contact_email: Optional[str] = None,
        contact_name: Optional[str] = None,
    ) -> None:
        """Record a registration result. Caller is responsible for invoking
        ``save_state`` afterwards.

        The ``installation_secret`` is the sgn_live_... bearer token
        returned by the server. The CLI captures it exactly once at
        register time and presents it on every subsequent /v1/sync call.
        """
        self.installation_id = installation_id
        if installation_secret is not None:
            self.installation_secret = installation_secret
        if contact_email is not None:
            self.contact_email = contact_email
        if contact_name is not None:
            self.contact_name = contact_name
        self.registered_at = _utcnow_iso()

    # ------------------------------------------------------------------
    # Log offsets
    # ------------------------------------------------------------------

    def offset_for(self, path: os.PathLike[str] | str) -> int:
        """Return the last processed offset for ``path``, or 0 if untracked."""
        key = _normalise_path_key(path)
        entry = self.log_offsets.get(key)
        return entry.last_processed_offset if entry is not None else 0

    def get_starting_offsets(
        self, log_sources: Mapping[str, Any] | List[Path] | tuple[Path, ...]
    ) -> Dict[str, int]:
        """Return a ``{str(path): offset}`` map suitable for passing to
        the aggregator. Missing entries default to 0."""
        out: Dict[str, int] = {}
        iterable: Any
        if isinstance(log_sources, Mapping):
            iterable = log_sources.keys()
        else:
            iterable = log_sources
        for path in iterable:
            key = _normalise_path_key(path)
            entry = self.log_offsets.get(key)
            out[key] = entry.last_processed_offset if entry is not None else 0
        return out

    def update_offsets(self, new_offsets: Mapping[str, int]) -> None:
        """Advance stored offsets. Only keys explicitly present are updated;
        other tracked logs are left untouched (important when the operator
        runs Sync against a subset of their configured log sources)."""
        now = _utcnow_iso()
        for raw_key, offset in new_offsets.items():
            key = _normalise_path_key(raw_key)
            existing = self.log_offsets.get(key)
            if existing is None:
                self.log_offsets[key] = LogOffset(
                    last_processed_offset=offset,
                    last_processed_at=now,
                )
            else:
                existing.last_processed_offset = offset
                existing.last_processed_at = now

    # ------------------------------------------------------------------
    # Uploaded windows (idempotence)
    # ------------------------------------------------------------------

    def has_uploaded_window(self, window_start: str, window_end: str) -> bool:
        """True iff a window with exactly matching bounds has been uploaded.

        Overlapping windows are NOT considered duplicates — operators may
        deliberately re-aggregate over shifted windows.
        """
        for window in self.uploaded_windows:
            if (
                window.window_start == window_start
                and window.window_end == window_end
            ):
                return True
        return False

    def record_upload(
        self,
        window_start: str,
        window_end: str,
        counts_by_rule: Mapping[str, int],
    ) -> UploadedWindow:
        """Append a successful upload record. Caller persists via save_state."""
        record = UploadedWindow(
            window_start=window_start,
            window_end=window_end,
            uploaded_at=_utcnow_iso(),
            counts_by_rule=dict(counts_by_rule),
        )
        self.uploaded_windows.append(record)
        return record


# ---------------------------------------------------------------------------
# Serialisation helpers
# ---------------------------------------------------------------------------

def _normalise_path_key(path: os.PathLike[str] | str) -> str:
    """Canonicalise a path into the string form used as a state file key.

    Keys are always the string form of the expanded path. ``~`` is
    expanded so that ``~/logs/a.jsonl`` and ``/home/alice/logs/a.jsonl``
    resolve to the same key.
    """
    return str(Path(os.path.expanduser(str(path))))


def _utcnow_iso() -> str:
    """Return the current UTC time as an ISO-8601 string with trailing Z."""
    return datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%S.%fZ")


def _state_to_dict(state: SyncState) -> Dict[str, Any]:
    return {
        "version": STATE_SCHEMA_VERSION,
        "installation_id": state.installation_id,
        "installation_secret": state.installation_secret,
        "contact_email": state.contact_email,
        "contact_name": state.contact_name,
        "registered_at": state.registered_at,
        "log_offsets": {
            key: asdict(value) for key, value in state.log_offsets.items()
        },
        "uploaded_windows": [asdict(w) for w in state.uploaded_windows],
    }


def _dict_to_state(data: Mapping[str, Any]) -> SyncState:
    version = data.get("version")
    if version not in STATE_SCHEMA_SUPPORTED_VERSIONS:
        raise StateError(
            f"Unsupported state schema version: supported "
            f"{list(STATE_SCHEMA_SUPPORTED_VERSIONS)}, got {version!r}"
        )

    log_offsets_raw = data.get("log_offsets") or {}
    if not isinstance(log_offsets_raw, dict):
        raise StateError("log_offsets must be an object")

    log_offsets: Dict[str, LogOffset] = {}
    for key, value in log_offsets_raw.items():
        if not isinstance(value, dict):
            raise StateError(f"log_offsets[{key}] must be an object")
        try:
            log_offsets[str(key)] = LogOffset(
                last_processed_offset=int(value.get("last_processed_offset", 0)),
                last_processed_event_id=value.get("last_processed_event_id"),
                last_processed_at=value.get("last_processed_at"),
            )
        except (TypeError, ValueError) as exc:
            raise StateError(
                f"log_offsets[{key}] has invalid types: {exc}"
            ) from exc

    uploaded_raw = data.get("uploaded_windows") or []
    if not isinstance(uploaded_raw, list):
        raise StateError("uploaded_windows must be an array")

    uploaded: List[UploadedWindow] = []
    for idx, entry in enumerate(uploaded_raw):
        if not isinstance(entry, dict):
            raise StateError(f"uploaded_windows[{idx}] must be an object")
        try:
            uploaded.append(
                UploadedWindow(
                    window_start=str(entry["window_start"]),
                    window_end=str(entry["window_end"]),
                    uploaded_at=str(entry["uploaded_at"]),
                    counts_by_rule=dict(entry.get("counts_by_rule") or {}),
                )
            )
        except KeyError as exc:
            raise StateError(
                f"uploaded_windows[{idx}] missing required key: {exc}"
            ) from exc

    return SyncState(
        installation_id=_optional_str(data.get("installation_id")),
        installation_secret=_optional_str(data.get("installation_secret")),
        contact_email=_optional_str(data.get("contact_email")),
        contact_name=_optional_str(data.get("contact_name")),
        registered_at=_optional_str(data.get("registered_at")),
        log_offsets=log_offsets,
        uploaded_windows=uploaded,
    )


def _optional_str(value: Any) -> Optional[str]:
    """Coerce a JSON-loaded value to Optional[str].

    Tolerates ``None`` and strings; rejects other types with a
    ``StateError``. This centralises the nullable-string parsing so
    every optional field behaves the same way on v1-and-earlier files
    that may have missing keys (``dict.get`` returns None) vs explicit
    nulls.
    """
    if value is None:
        return None
    if isinstance(value, str):
        return value
    raise StateError(
        f"state field expected string or null, got {type(value).__name__}"
    )


# ---------------------------------------------------------------------------
# Public load / save
# ---------------------------------------------------------------------------

def load_state(path: Path) -> SyncState:
    """Load a SyncState from disk, returning a fresh empty state if absent.

    Raises
    ------
    StateError
        If the file exists but cannot be parsed or has an unexpected schema.
    """
    if not path.exists():
        return SyncState()

    try:
        raw = path.read_text(encoding="utf-8")
    except OSError as exc:
        raise StateError(f"Cannot read state file {path}: {exc}") from exc

    try:
        data = json.loads(raw)
    except json.JSONDecodeError as exc:
        raise StateError(f"Malformed JSON in state file {path}: {exc}") from exc

    if not isinstance(data, dict):
        raise StateError(f"State file {path} must contain a JSON object")

    return _dict_to_state(data)


def save_state(path: Path, state: SyncState) -> None:
    """Atomically persist a SyncState to disk with best-effort 0600 perms.

    The flow:

    1. Serialize state to JSON.
    2. Create a ``.tmp`` sibling with owner-only perms (``0o600``) from
       the first byte — on POSIX this closes the window where the
       plaintext ``installation_secret`` could be readable by other
       users. On Windows, the mode bit is honored inconsistently
       across Python versions; we continue anyway and rely on the
       post-replace chmod as our hardening there.
    3. fsync the temp file so the rename commits content, not a sparse
       stub.
    4. ``os.replace`` the temp over the target — atomic on POSIX and
       modern Windows filesystems.
    5. Best-effort ``os.chmod(path, 0o600)`` after replace. On platforms
       where ``os.replace`` may reset perms, this restores them. Failures
       log a warning to stderr and do NOT raise — the state was saved
       correctly; only the extra hardening didn't stick.

    The caller never sees a partial state file. If any step raises,
    the temp file is cleaned up and the on-disk state is unchanged.
    """
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp_path = path.with_name(path.name + ".tmp")

    try:
        serialised = json.dumps(_state_to_dict(state), indent=2) + "\n"
        _write_owner_only_text(tmp_path, serialised)
        # fsync the temp file so the rename really commits the contents.
        with tmp_path.open("rb") as fh:
            os.fsync(fh.fileno())
        os.replace(tmp_path, path)
    except Exception:
        # Best-effort cleanup of the temp file so we don't leave crumbs.
        try:
            if tmp_path.exists():
                tmp_path.unlink()
        except OSError:
            pass
        raise

    # Belt-and-suspenders: restore 0600 perms if os.replace reset them.
    # On Windows this is typically a no-op or silently ignored; on POSIX
    # it enforces the owner-only invariant.
    try:
        os.chmod(path, _SECRET_FILE_MODE)
    except OSError as exc:
        # Warn and continue — state save itself succeeded.
        print(
            f"sentience-sync: warning: could not chmod state file {path} "
            f"to owner-only ({exc}). State was saved correctly; the "
            f"installation_secret is recoverable but not locked down at "
            f"the filesystem level on this platform.",
            file=sys.stderr,
        )


def _write_owner_only_text(path: Path, text: str) -> None:
    """Write text to ``path`` creating it with owner-only (0600) perms.

    On POSIX, uses ``os.open`` with O_CREAT|O_WRONLY|O_TRUNC and explicit
    mode 0o600 so the file is never briefly world-readable between
    create and the first write. On Windows, the mode argument to
    ``os.open`` is ignored for most permission bits; we fall back to a
    plain ``write_text`` and rely on the post-replace chmod in
    ``save_state`` for hardening.
    """
    data = text.encode("utf-8")
    flags = os.O_WRONLY | os.O_CREAT | os.O_TRUNC
    try:
        fd = os.open(str(path), flags, _SECRET_FILE_MODE)
    except OSError:
        # Fallback — unusual filesystems. Use the Path API and let the
        # post-replace chmod do the hardening.
        path.write_text(text, encoding="utf-8")
        return
    try:
        with os.fdopen(fd, "wb") as fh:
            fh.write(data)
    except Exception:
        # fd is closed by fdopen's context manager on exception; nothing
        # else to do beyond re-raising so the caller's cleanup runs.
        raise
