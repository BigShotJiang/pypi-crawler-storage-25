"""HTTP transport — registration, sync, update-check.

Scope
-----
This module is the only place in ``sentience_sync`` that speaks HTTP. It
has three responsibilities:

1. Build wire-format payloads from primitive arguments (pure functions,
   exported at module level for direct testing).
2. Send those payloads to the Sentience Cloud endpoint.
3. Parse and validate the responses into typed dataclasses.

It does NOT:

- Read or write any state file.
- Read log files or compute aggregates.
- Import or load configuration; callers unpack whatever config object
  they hold into the primitive arguments this module takes.
- Make persistence-policy decisions of any kind.

This keeps transport testable with nothing more than a mocked
``_urlopen`` — no filesystem setup, no state, no config objects.

Error taxonomy → exit codes
---------------------------
* ``NetworkError``  → CLI exit code 2 (timeout, DNS, connection refused,
                      any URL/socket-level failure before a response).
* ``ServerError``   → CLI exit code 4 (server returned non-2xx, response
                      was not valid JSON, response was not an object,
                      required response fields were missing or wrong
                      type). The ``ServerError.status_code`` attribute
                      preserves the HTTP status so callers can branch
                      on 401 vs 500 without re-parsing the message.

Endpoint contract
-----------------
The wire contract tracked here matches ``server/src/models.py`` at
``sync.getsentience.ai/v1``. Payload shapes and response shapes are
enforced against that contract in ``tests/sync/test_transport.py``
(see the ``protocol_version`` asymmetry tests and the ``language_binding``
/ ``deployment_label`` leak-prevention tests).

Isolation
---------
Only stdlib imports. No ``sentience_sync.*`` imports at all — transport
must stay uncoupled from state / aggregator / config so the purity
guardrail test in ``tests/sync/test_isolation.py`` remains green.
"""

from __future__ import annotations

import json
import socket
import sys
import urllib.error
import urllib.parse
import urllib.request
from dataclasses import dataclass
from typing import Any, Dict, Mapping, Optional


# ---------------------------------------------------------------------------
# Path constants
# ---------------------------------------------------------------------------

REGISTER_PATH = "/register"
SYNC_PATH = "/sync"
UPDATE_CHECK_PATH = "/update-check"


# ---------------------------------------------------------------------------
# Error taxonomy
# ---------------------------------------------------------------------------

class TransportError(Exception):
    """Base class for all transport-layer failures."""


class NetworkError(TransportError):
    """Network-level failure before or during the request.

    Raised on socket timeout, connection refused, DNS resolution failure,
    or any other ``URLError`` / socket-level exception. The CLI maps this
    to exit code 2.
    """


class ServerError(TransportError):
    """Server rejected the payload or returned an unparseable response.

    Raised on:
    - any HTTP status outside 2xx
    - response body that is not valid JSON
    - response body that is valid JSON but not an object
    - response missing required fields or with wrong types

    Carries ``status_code`` (``None`` for non-HTTP cases) and ``body``
    (decoded response body as a string, possibly empty). The CLI maps
    this to exit code 4.
    """

    def __init__(
        self,
        message: str,
        *,
        status_code: Optional[int] = None,
        body: Optional[str] = None,
    ) -> None:
        super().__init__(message)
        self.status_code = status_code
        self.body = body


# ---------------------------------------------------------------------------
# Response dataclasses — shape matches server/src/models.py exactly
# ---------------------------------------------------------------------------

@dataclass(frozen=True)
class RegistrationResponse:
    """Response from POST /v1/register.

    Matches ``server/src/models.py::RegisterResponse``. ``installation_secret``
    is returned exactly once — the CLI captures it, writes it to local
    state, and presents it as a Bearer token on every subsequent
    ``/v1/sync`` call.
    """

    status: str
    installation_id: str
    installation_secret: str
    server_time_utc: str


@dataclass(frozen=True)
class SyncResponse:
    """Response from POST /v1/sync.

    Matches ``server/src/models.py::SyncResponse``. ``duplicate`` is the
    canonical signal that the server already had a sync_run with the
    same ``(installation_id, window_start, window_end)`` tuple — both
    the first submission and the replay return 200 OK; the client
    branches on this flag, not on the message string.
    """

    status: str
    received_at: str
    sync_run_id: int
    duplicate: bool = False


@dataclass(frozen=True)
class UpdateCheckResponse:
    """Response from GET /v1/update-check.

    Matches ``server/src/models.py::UpdateCheckResponse``. When
    ``update_available`` is False, every other field is typically None —
    the CLI treats that as "nothing to report" and prints nothing.
    """

    update_available: bool
    severity: Optional[str] = None
    message: Optional[str] = None
    link_url: Optional[str] = None
    min_runtime_version: Optional[str] = None
    max_runtime_version: Optional[str] = None


# ---------------------------------------------------------------------------
# Payload builders (pure, exported for direct testing)
# ---------------------------------------------------------------------------

def build_registration_payload(
    *,
    installation_id: str,
    runtime_version: str,
    contact_email: str,
    contact_name: str,
    protocol_version: str = "1.0",
    organization: Optional[str] = None,
    operator_role: Optional[str] = None,
    timezone: Optional[str] = None,
    report_geo: bool = False,
    geo_country: Optional[str] = None,
    user_agent: Optional[str] = None,
) -> Dict[str, Any]:
    """Build the POST /v1/register payload.

    Matches ``server/src/models.py::RegisterRequest`` exactly. Required
    fields (per the server's Pydantic validation):

    - ``installation_id``
    - ``runtime_version``
    - ``contact_email``
    - ``contact_name``
    - ``protocol_version`` (defaults to ``"1.0"``; server accepts only
      that value today)

    Optional fields are **omitted entirely** from the payload when not
    provided — not sent as ``null``. This keeps the payload small and
    makes server-side "did the client send this?" checks unambiguous.

    Asymmetry invariant
    -------------------
    Register is the ONLY endpoint where ``protocol_version`` is part of
    the payload. Sync and update-check omit it. See §3.4 of
    ``docs/plans/cli-v0.2.0-contract-update.md``.
    """
    payload: Dict[str, Any] = {
        "protocol_version": protocol_version,
        "installation_id": installation_id,
        "runtime_version": runtime_version,
        "contact_email": contact_email,
        "contact_name": contact_name,
    }
    if organization:
        payload["organization"] = organization
    if operator_role:
        payload["operator_role"] = operator_role
    if report_geo:
        payload["report_geo"] = True
        if timezone:
            payload["timezone"] = timezone
        if geo_country:
            payload["geo_country"] = geo_country
    if user_agent:
        payload["user_agent"] = user_agent
    return payload


def build_sync_payload(
    *,
    installation_id: str,
    runtime_version: str,
    window_start: str,
    window_end: str,
    counts_by_rule: Mapping[str, int],
) -> Dict[str, Any]:
    """Build the POST /v1/sync payload.

    Matches ``server/src/models.py::SyncRequest``. Does NOT include
    ``protocol_version`` — the server's ``SyncRequest`` model has no
    such field, and including it here would be a silent contract drift.

    Authentication is handled at the HTTP header level
    (``Authorization: Bearer sgn_live_...``), not in the body. The
    ``installation_secret`` is carried through ``SyncTransport.sync()``
    and never appears in the payload dict.
    """
    return {
        "installation_id": installation_id,
        "runtime_version": runtime_version,
        "window_start": window_start,
        "window_end": window_end,
        "counts_by_rule": dict(counts_by_rule),
    }


def build_update_check_params(
    *,
    installation_id: str,
    runtime_version: str,
) -> Dict[str, str]:
    """Build the GET /v1/update-check query string parameters.

    Update-check is a GET with query-string params, not a POST with a
    body. This helper returns a plain dict; the SyncTransport URL-encodes
    it when assembling the request.
    """
    return {
        "installation_id": installation_id,
        "runtime_version": runtime_version,
    }


# ---------------------------------------------------------------------------
# Response parsers (pure, exported for direct testing)
# ---------------------------------------------------------------------------

def parse_registration_response(data: Mapping[str, Any]) -> RegistrationResponse:
    _require_object(data, "registration response")
    status = _required_string(data, "status", "registration response")
    installation_id = _required_string(
        data, "installation_id", "registration response"
    )
    installation_secret = _required_string(
        data, "installation_secret", "registration response"
    )
    server_time_utc = _required_string(
        data, "server_time_utc", "registration response"
    )
    return RegistrationResponse(
        status=status,
        installation_id=installation_id,
        installation_secret=installation_secret,
        server_time_utc=server_time_utc,
    )


def parse_sync_response(data: Mapping[str, Any]) -> SyncResponse:
    _require_object(data, "sync response")
    status = _required_string(data, "status", "sync response")
    received_at = _required_string(data, "received_at", "sync response")
    sync_run_id_raw = data.get("sync_run_id")
    if not isinstance(sync_run_id_raw, int) or isinstance(sync_run_id_raw, bool):
        raise ServerError("`sync_run_id` must be an integer")
    duplicate_raw = data.get("duplicate", False)
    if not isinstance(duplicate_raw, bool):
        raise ServerError("`duplicate` must be a boolean when present")
    return SyncResponse(
        status=status,
        received_at=received_at,
        sync_run_id=sync_run_id_raw,
        duplicate=duplicate_raw,
    )


def parse_update_check_response(data: Mapping[str, Any]) -> UpdateCheckResponse:
    _require_object(data, "update-check response")
    update_available_raw = data.get("update_available")
    if not isinstance(update_available_raw, bool):
        raise ServerError("`update_available` must be a boolean")
    return UpdateCheckResponse(
        update_available=update_available_raw,
        severity=_optional_string(
            data.get("severity"), "severity"
        ),
        message=_optional_string(data.get("message"), "message"),
        link_url=_optional_string(data.get("link_url"), "link_url"),
        min_runtime_version=_optional_string(
            data.get("min_runtime_version"), "min_runtime_version"
        ),
        max_runtime_version=_optional_string(
            data.get("max_runtime_version"), "max_runtime_version"
        ),
    )


# ---------------------------------------------------------------------------
# Parser helpers
# ---------------------------------------------------------------------------

def _require_object(data: Any, context: str) -> None:
    if not isinstance(data, dict):
        raise ServerError(f"{context} must be a JSON object")


def _required_string(
    data: Mapping[str, Any], key: str, context: str
) -> str:
    if key not in data:
        raise ServerError(f"{context} missing required field `{key}`")
    value = data[key]
    if not isinstance(value, str):
        raise ServerError(f"{context} field `{key}` must be a string")
    return value


def _optional_string(value: Any, context: str) -> Optional[str]:
    if value is None:
        return None
    if not isinstance(value, str):
        raise ServerError(f"`{context}` must be a string when present")
    return value


# ---------------------------------------------------------------------------
# Testable indirection point
# ---------------------------------------------------------------------------

def _urlopen(request: urllib.request.Request, timeout: float) -> Any:
    """Thin wrapper so tests can monkey-patch ``sentience_sync.transport._urlopen``
    without reaching into ``urllib.request`` globally.
    """
    return urllib.request.urlopen(request, timeout=timeout)


# ---------------------------------------------------------------------------
# SyncTransport
# ---------------------------------------------------------------------------

class SyncTransport:
    """HTTP client for the Sentience Sync cloud endpoints.

    Takes primitive configuration arguments (endpoint, timeout, protocol
    version, runtime version) rather than any package-level configuration
    object. The caller is responsible for unpacking whatever higher-level
    configuration it holds into these parameters.

    Parameters
    ----------
    endpoint
        Base URL including the API major version (e.g.
        ``"https://sync.getsentience.ai/v1"``). Trailing slash is
        normalised away.
    timeout_seconds
        Per-request timeout. Must be > 0.
    protocol_version
        Wire-protocol minor version the client speaks (e.g. ``"1.0"``).
        Included in the register payload only; sync and update-check
        do not carry it.
    runtime_version
        The ``sentience_governor`` runtime version string. Included in
        every payload and in the ``User-Agent`` header.
    """

    def __init__(
        self,
        *,
        endpoint: str,
        timeout_seconds: float,
        protocol_version: str,
        runtime_version: str,
    ) -> None:
        if not isinstance(endpoint, str) or not endpoint:
            raise ValueError("endpoint must be a non-empty string")
        if not isinstance(timeout_seconds, (int, float)) or timeout_seconds <= 0:
            raise ValueError("timeout_seconds must be > 0")
        if not isinstance(protocol_version, str) or not protocol_version:
            raise ValueError("protocol_version must be a non-empty string")
        if not isinstance(runtime_version, str) or not runtime_version:
            raise ValueError("runtime_version must be a non-empty string")

        self._endpoint = endpoint.rstrip("/")
        self._timeout = float(timeout_seconds)
        self._protocol_version = protocol_version
        self._runtime_version = runtime_version

    # ------------------------------------------------------------------
    # Public methods
    # ------------------------------------------------------------------

    def register(
        self,
        *,
        installation_id: str,
        contact_email: str,
        contact_name: str,
        organization: Optional[str] = None,
        operator_role: Optional[str] = None,
        timezone: Optional[str] = None,
        report_geo: bool = False,
        geo_country: Optional[str] = None,
        user_agent: Optional[str] = None,
        stderr: Any = None,
    ) -> RegistrationResponse:
        payload = build_registration_payload(
            installation_id=installation_id,
            runtime_version=self._runtime_version,
            contact_email=contact_email,
            contact_name=contact_name,
            protocol_version=self._protocol_version,
            organization=organization,
            operator_role=operator_role,
            timezone=timezone,
            report_geo=report_geo,
            geo_country=geo_country,
            user_agent=user_agent,
        )
        data = self._post_json(REGISTER_PATH, payload, stderr=stderr)
        return parse_registration_response(data)

    def sync(
        self,
        *,
        installation_id: str,
        installation_secret: str,
        window_start: str,
        window_end: str,
        counts_by_rule: Mapping[str, int],
        stderr: Any = None,
    ) -> SyncResponse:
        # Guardrail §11.2: fail-fast pre-network. Never open a socket
        # for an invalid secret — produces a clean ValueError the
        # orchestration layer translates into an incomplete-state message.
        if not installation_secret or not installation_secret.strip():
            raise ValueError("installation_secret missing")

        payload = build_sync_payload(
            installation_id=installation_id,
            runtime_version=self._runtime_version,
            window_start=window_start,
            window_end=window_end,
            counts_by_rule=counts_by_rule,
        )
        data = self._post_json(
            SYNC_PATH,
            payload,
            stderr=stderr,
            bearer_token=installation_secret,
        )
        return parse_sync_response(data)

    def update_check(
        self,
        *,
        installation_id: str,
        stderr: Any = None,
    ) -> UpdateCheckResponse:
        params = build_update_check_params(
            installation_id=installation_id,
            runtime_version=self._runtime_version,
        )
        data = self._get_json(UPDATE_CHECK_PATH, params, stderr=stderr)
        return parse_update_check_response(data)

    # ------------------------------------------------------------------
    # Internals
    # ------------------------------------------------------------------

    def _post_json(
        self,
        path: str,
        payload: Dict[str, Any],
        *,
        stderr: Any = None,
        bearer_token: Optional[str] = None,
    ) -> Dict[str, Any]:
        """POST a JSON payload to ``endpoint + path`` and parse the response.

        If ``bearer_token`` is provided, adds an
        ``Authorization: Bearer <token>`` header.
        """
        if stderr is None:
            stderr = sys.stderr

        url = self._endpoint + path
        body = json.dumps(payload).encode("utf-8")
        headers = {
            "Content-Type": "application/json",
            "Accept": "application/json",
            "User-Agent": f"sentience-sync/{self._runtime_version}",
        }
        if bearer_token is not None:
            headers["Authorization"] = f"Bearer {bearer_token}"
        request = urllib.request.Request(
            url,
            data=body,
            headers=headers,
            method="POST",
        )
        return self._execute(request, url, stderr)

    def _get_json(
        self,
        path: str,
        params: Mapping[str, str],
        *,
        stderr: Any = None,
    ) -> Dict[str, Any]:
        """GET ``endpoint + path + ?<params>`` and parse the response.

        No auth — update-check is the only caller today and is a public
        endpoint (the server applies no bearer check). If a future GET
        endpoint needs auth, widen this signature then.
        """
        if stderr is None:
            stderr = sys.stderr

        query = urllib.parse.urlencode(params)
        url = f"{self._endpoint}{path}?{query}" if query else self._endpoint + path
        request = urllib.request.Request(
            url,
            headers={
                "Accept": "application/json",
                "User-Agent": f"sentience-sync/{self._runtime_version}",
            },
            method="GET",
        )
        return self._execute(request, url, stderr)

    def _execute(
        self,
        request: urllib.request.Request,
        url: str,
        stderr: Any,
    ) -> Dict[str, Any]:
        """Shared HTTP-execute path for _post_json and _get_json.

        Handles network errors, HTTP status, JSON parsing, and the
        protocol-version advisory check. Returns the decoded response
        dict on success.

        Raises
        ------
        NetworkError
            Network / socket failure before the response is fully received.
        ServerError
            HTTP non-2xx status, or malformed response body.
        """
        try:
            response = _urlopen(request, timeout=self._timeout)
        except urllib.error.HTTPError as exc:
            raw_body = b""
            try:
                raw_body = exc.read() or b""
            except Exception:
                pass
            raise ServerError(
                f"Server returned HTTP {exc.code} for {url}",
                status_code=exc.code,
                body=raw_body.decode("utf-8", errors="replace"),
            ) from exc
        except urllib.error.URLError as exc:
            reason = getattr(exc, "reason", exc)
            raise NetworkError(
                f"Network error contacting {url}: {reason}"
            ) from exc
        except socket.timeout as exc:
            raise NetworkError(f"Timeout contacting {url}") from exc
        except TimeoutError as exc:
            raise NetworkError(f"Timeout contacting {url}") from exc

        with response as resp:
            status = getattr(resp, "status", None)
            if status is None:
                status = resp.getcode() if hasattr(resp, "getcode") else 0
            try:
                raw = resp.read() or b""
            except OSError as exc:
                raise NetworkError(
                    f"Read error on response from {url}: {exc}"
                ) from exc

        if not (200 <= int(status) < 300):
            raise ServerError(
                f"Server returned HTTP {status} for {url}",
                status_code=int(status),
                body=raw.decode("utf-8", errors="replace"),
            )

        if not raw:
            raise ServerError(
                f"Empty response body from {url}",
                status_code=int(status),
                body="",
            )

        try:
            parsed = json.loads(raw.decode("utf-8"))
        except (UnicodeDecodeError, json.JSONDecodeError) as exc:
            raise ServerError(
                f"Response from {url} is not valid JSON: {exc}",
                status_code=int(status),
                body=raw.decode("utf-8", errors="replace"),
            ) from exc

        if not isinstance(parsed, dict):
            raise ServerError(
                f"Response from {url} must be a JSON object",
                status_code=int(status),
                body=raw.decode("utf-8", errors="replace"),
            )

        return parsed
