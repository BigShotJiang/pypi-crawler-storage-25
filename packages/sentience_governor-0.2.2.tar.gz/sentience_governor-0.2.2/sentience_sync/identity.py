"""Installation identity — installation_id generation, timezone detection.

Scope
-----
This module is pure value generation. It never writes to disk. All
persistence is the responsibility of ``sentience_sync.state`` (Phase 2),
so identity.py can be unit-tested in-memory with no filesystem setup.

Helpers exposed
---------------
* ``generate_installation_id()`` — fresh ``inst_<uuid4>`` identifier.
* ``is_valid_installation_id(value)`` — syntactic validator.
* ``detect_timezone(...)`` — best-effort IANA timezone name.
* ``language_binding()`` — ``python-X.Y`` string for the running interpreter.
* ``build_user_agent(cli_version)`` — ``sentience-sync/<cli_version> python-X.Y <os>``
  string for the optional ``user_agent`` field in registration payloads.
"""

from __future__ import annotations

import os
import platform
import sys
import time
import uuid
from pathlib import Path
from typing import Mapping, Optional


INSTALLATION_ID_PREFIX = "inst_"
_TIMEZONE_FALLBACK = "UTC"
_LOCALTIME_PATH = Path("/etc/localtime")
_ZONEINFO_MARKER = "zoneinfo/"


# ---------------------------------------------------------------------------
# Installation ID
# ---------------------------------------------------------------------------

def generate_installation_id() -> str:
    """Generate a fresh installation_id.

    Format: ``inst_<uuid4>``. The prefix makes the identifier unambiguous
    in logs and support contexts — an ``inst_`` string is always an
    installation identifier, never a session, agent, or user identifier.
    """
    return f"{INSTALLATION_ID_PREFIX}{uuid.uuid4()}"


def is_valid_installation_id(value: object) -> bool:
    """Return True if ``value`` is a syntactically valid installation_id.

    Accepts only UUIDv4 identifiers with the ``inst_`` prefix. This is a
    pure syntactic check; it does not imply the identifier is known to
    Sentience Cloud.
    """
    if not isinstance(value, str):
        return False
    if not value.startswith(INSTALLATION_ID_PREFIX):
        return False
    tail = value[len(INSTALLATION_ID_PREFIX):]
    try:
        parsed = uuid.UUID(tail)
    except (ValueError, AttributeError):
        return False
    return parsed.version == 4


# ---------------------------------------------------------------------------
# Timezone detection
# ---------------------------------------------------------------------------

def _tz_from_localtime(localtime_path: Path) -> Optional[str]:
    """Extract the IANA zone name from ``/etc/localtime`` if it is a symlink.

    On macOS and most Linux distributions ``/etc/localtime`` is a symlink
    into a zoneinfo tree, e.g. ``/usr/share/zoneinfo/America/Los_Angeles``.
    """
    try:
        if not localtime_path.is_symlink():
            return None
        target = os.readlink(localtime_path)
    except (OSError, ValueError):
        return None

    if _ZONEINFO_MARKER not in target:
        return None
    tail = target.split(_ZONEINFO_MARKER, 1)[1]
    return tail or None


def _tz_from_env(tz_value: Optional[str]) -> Optional[str]:
    """Return a non-empty, non-``:prefixed`` TZ env value, or None."""
    if tz_value is None:
        return None
    stripped = tz_value.strip()
    if not stripped:
        return None
    # POSIX ``TZ=:Region/City`` form — accept by stripping the colon.
    if stripped.startswith(":"):
        stripped = stripped[1:].strip()
        if not stripped:
            return None
    return stripped


def _tz_from_tzname() -> Optional[str]:
    """Last-resort fallback: ``time.tzname[0]`` (typically a non-IANA abbr)."""
    try:
        names = time.tzname
    except Exception:
        return None
    if not names:
        return None
    first = names[0]
    return first if first else None


def detect_timezone(
    *,
    localtime_path: Optional[Path] = None,
    env: Optional[Mapping[str, str]] = None,
) -> str:
    """Return the system's IANA timezone name, falling back to ``UTC``.

    Resolution order:

    1. ``/etc/localtime`` symlink target (canonical on macOS + Linux).
    2. ``TZ`` environment variable if set to a plausible zone name.
    3. ``time.tzname[0]`` (non-IANA abbreviation; still a usable signal).
    4. Literal ``"UTC"``.

    The function never raises. Passing ``localtime_path`` and ``env``
    keeps the implementation fully testable — tests can construct a
    throwaway symlink or env mapping and observe resolution without
    touching the host system.
    """
    if localtime_path is None:
        localtime_path = _LOCALTIME_PATH
    if env is None:
        env = os.environ

    result = _tz_from_localtime(localtime_path)
    if result:
        return result

    result = _tz_from_env(env.get("TZ"))
    if result:
        return result

    result = _tz_from_tzname()
    if result:
        return result

    return _TIMEZONE_FALLBACK


# ---------------------------------------------------------------------------
# Language binding
# ---------------------------------------------------------------------------

def language_binding() -> str:
    """Return the language binding string, e.g. ``python-3.11``."""
    return f"python-{sys.version_info.major}.{sys.version_info.minor}"


# ---------------------------------------------------------------------------
# User-Agent string
# ---------------------------------------------------------------------------

def build_user_agent(cli_version: str) -> str:
    """Return a ``user_agent`` string for the register payload.

    Format: ``sentience-sync/<cli_version> python-X.Y <os>``

    The ``<os>`` component is ``platform.system().lower()`` (typically
    ``"linux"``, ``"darwin"``, or ``"windows"``). If detection fails for
    any reason, the OS component is omitted and the returned string is
    ``sentience-sync/<cli_version> python-X.Y``.

    Tests against this string must use a stable-prefix check:

        assert ua.startswith("sentience-sync/")

    Full-string snapshots are forbidden per guardrail §11.5 because the
    OS component drifts across CI hosts, container images, and Python
    patch bumps.
    """
    base = f"sentience-sync/{cli_version} {language_binding()}"
    try:
        osname = platform.system().strip().lower()
    except Exception:  # pragma: no cover — platform.system is stdlib
        osname = ""
    if osname:
        return f"{base} {osname}"
    return base
