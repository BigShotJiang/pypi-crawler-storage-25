"""Sentience Sync — on-demand cloud bridge for open-tier Governor installations.

Sync is a standalone component that ships alongside sentience_governor in the
same PyPI distribution but lives as a sibling package with a one-way import
boundary: the Governance Runtime (sentience_governor) MUST NOT import from
sentience_sync, and sentience_sync does not touch the runtime execution path.

Responsibilities
----------------
* Read already-emitted newline-delimited JSON governance logs from disk.
* Aggregate per-window counts for POL-001 through POL-005 across sessions.
* On explicit operator invocation (never automatic), upload aggregates —
  never raw events — to Sentience Cloud.
* Surface curated runtime and content-bundle update recommendations from
  Sentience Cloud; never auto-apply them.

Normative constraints (Tech Spec Appendix)
------------------------------------------
* MUST NOT be linked into or invoked from the Governance Wrapper, Session
  Manager, EventBuilder, or Sink Writer.
* MUST NOT alter runtime configuration, policy behaviour, or event schema.
* MUST NOT send raw events, payloads, or content — only aggregates and
  coarse installation metadata.
* MUST NOT introduce any dependency that makes the runtime unavailable if
  Sync is absent or misconfigured.

The runtime MUST continue to operate with zero knowledge of whether Sync is
installed, configured, or running.
"""

__version__ = "0.1.0"
