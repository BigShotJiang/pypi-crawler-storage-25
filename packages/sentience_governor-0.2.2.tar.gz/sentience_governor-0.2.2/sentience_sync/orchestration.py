"""Composition layer — the only place that combines state, aggregator, and transport.

This module exists so that ``sentience_sync.cli`` can stay thin. CLI
subcommands parse arguments, call exactly one function here, format the
result, and map exceptions to exit codes. They do NOT re-implement any
of the composition logic below.

Critical invariant (enforced in tests)
--------------------------------------
``run_sync`` MUST NOT advance durable state unless the upload succeeded.

The implementation makes this structural rather than conventional:
``save_state`` is called on exactly one line of ``run_sync``, and that
line is unreachable unless ``transport.sync(...)`` has already returned
without raising. Any exception at any earlier step (config, state load,
aggregation, network, server validation) leaves the state file
byte-identical to its pre-run contents.

The dry-run path is similarly structural: it returns before the
``transport.sync`` call, so it cannot possibly touch the network; and
it never reaches ``save_state`` either.

Dependencies
------------
This module imports from state, aggregator, transport, identity, and
config. It is the ONE place that's allowed to couple them.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Mapping, Optional, Tuple

from sentience_sync.aggregator import (
    AggregationResult,
    LogTruncatedError,
    aggregate,
)
from sentience_sync.config import SyncConfig
from sentience_sync.identity import (
    build_user_agent,
    detect_timezone,
    generate_installation_id,
    is_valid_installation_id,
)
from sentience_sync.state import (
    StateError,
    SyncState,
    load_state,
    save_state,
)
from sentience_sync.transport import (
    NetworkError,
    RegistrationResponse,
    ServerError,
    SyncResponse,
    SyncTransport,
    UpdateCheckResponse,
)


# ---------------------------------------------------------------------------
# Constants
# ---------------------------------------------------------------------------

# Default window bounds for the aggregate command — chosen so the output
# is deterministic even when no --window is provided. These are wide
# enough to include every plausible real governance event.
AGGREGATE_DEFAULT_WINDOW_START = "1970-01-01T00:00:00.000Z"
AGGREGATE_DEFAULT_WINDOW_END = "9999-12-31T23:59:59.999Z"


# ---------------------------------------------------------------------------
# Errors (CLI maps these to exit codes)
# ---------------------------------------------------------------------------

class OrchestrationError(Exception):
    """Base class for composition-level failures."""


class NotRegisteredError(OrchestrationError):
    """Raised when a command requires registration but none exists.

    CLI exit code 3.
    """


class AlreadyRegisteredError(OrchestrationError):
    """Raised when register is called on an already-registered installation
    without ``force=True``."""


# ---------------------------------------------------------------------------
# Result shapes (returned to CLI for formatting)
# ---------------------------------------------------------------------------

@dataclass(frozen=True)
class RegisterResult:
    installation_id: str
    registered_at: str
    newly_registered: bool
    installation_secret: str
    contact_email: str
    contact_name: str
    response: Optional[RegistrationResponse]


@dataclass(frozen=True)
class RunResult:
    """Return value of ``run_sync``.

    ``duplicate`` is True iff the server responded with ``duplicate=true``
    (i.e., a run with the same ``(installation_id, window_start,
    window_end)`` tuple already existed). Both duplicate and
    first-submission are 200 OK; the CLI branches on this flag only —
    per guardrail §11.3, it does NOT infer duplicate from response
    message strings.

    ``sync_run_id`` is populated from the server's response. For
    duplicate replays it is the id of the pre-existing row.
    """

    dry_run: bool
    window_start: str
    window_end: str
    aggregation: AggregationResult
    upload_response: Optional[SyncResponse]
    state_advanced: bool
    duplicate: bool
    sync_run_id: Optional[int]
    # The payload that was (or would be) sent, exposed for --dry-run
    # rendering without re-building it in the CLI layer.
    payload: dict


@dataclass(frozen=True)
class AggregateResult:
    window_start: str
    window_end: str
    aggregation: AggregationResult


@dataclass(frozen=True)
class UpdateCheckResult:
    response: UpdateCheckResponse


# ---------------------------------------------------------------------------
# Runtime-version discovery
# ---------------------------------------------------------------------------

def _get_runtime_version() -> str:
    """Return the installed sentience-governor version via package metadata.

    Uses ``importlib.metadata`` rather than importing the governor module
    so we never trigger runtime code-path loading from inside Sync.
    """
    try:
        from importlib.metadata import version, PackageNotFoundError
    except ImportError:  # pragma: no cover
        return "unknown"
    try:
        return version("sentience-governor")
    except PackageNotFoundError:
        return "unknown"


def _utcnow_iso() -> str:
    """Return current UTC as an ISO-8601 string with millisecond precision."""
    now = datetime.now(timezone.utc)
    return now.strftime("%Y-%m-%dT%H:%M:%S.") + f"{now.microsecond // 1000:03d}Z"


# ---------------------------------------------------------------------------
# Transport factory (single place where SyncTransport is constructed)
# ---------------------------------------------------------------------------

def _make_transport(config: SyncConfig) -> SyncTransport:
    return SyncTransport(
        endpoint=config.endpoint,
        timeout_seconds=config.timeout_seconds,
        protocol_version=config.protocol_version,
        runtime_version=_get_runtime_version(),
    )


# ---------------------------------------------------------------------------
# register
# ---------------------------------------------------------------------------

def register_installation(
    config: SyncConfig,
    *,
    contact_email: str,
    contact_name: str,
    organization: Optional[str] = None,
    operator_role: Optional[str] = None,
    force: bool = False,
    now_iso: Optional[str] = None,
    transport: Optional[SyncTransport] = None,
) -> RegisterResult:
    """Register this installation with Sentience Cloud.

    Required arguments
    ------------------
    ``contact_email`` and ``contact_name`` are non-optional. The server
    requires both (per ``server/src/models.py::RegisterRequest``) and
    the CLI enforces non-blank values before this function is called.
    Blank / whitespace-only values here raise ``ValueError`` — defence
    in depth against a CLI bug.

    Reuse-existing-id invariant (plan §3.1b / guardrail §11.1)
    ----------------------------------------------------------
    If local state contains a VALID ``installation_id``, it is reused
    verbatim in the outgoing payload. A new ID is generated ONLY when
    state is absent OR the stored ID fails ``is_valid_installation_id``
    (covers corrupted / hand-edited / partially-written state). The
    ``--force`` flag does NOT trigger ID regeneration under any
    circumstance.

    This rule is load-bearing for server-side recovery: a v1 user with
    NULL ``installation_secret_hash`` is recognized by the server when
    the CLI sends their existing ``installation_id``; the server takes
    the recovery branch and issues a fresh secret. Generating a new ID
    would create a duplicate row and orphan the original.

    State mutation rule
    -------------------
    The installation_id, secret, and contact fields are written to the
    state file ONLY after the registration POST returns successfully.
    Any failure path (network error, server rejection) leaves the state
    file unchanged.
    """
    # Defensive validation — CLI should have caught this already.
    if not contact_email or not contact_email.strip():
        raise ValueError("contact_email must not be blank")
    if not contact_name or not contact_name.strip():
        raise ValueError("contact_name must not be blank")

    state = load_state(config.state_path)

    if (
        state.is_registered()
        and state.has_installation_secret()
        and not force
    ):
        raise AlreadyRegisteredError(
            f"Already registered as {state.installation_id}. "
            "Use --force to re-register (your installation_id will be "
            "preserved; only the installation_secret is refreshed)."
        )

    # Reuse-existing-id invariant (guardrail §11.1).
    # Exactly ONE branch may generate a new ID. Presence of any other
    # branch in this function is a bug.
    existing_id = state.installation_id
    if existing_id and is_valid_installation_id(existing_id):
        installation_id = existing_id
    else:
        installation_id = generate_installation_id()

    tz = detect_timezone() if config.report_geo else None
    user_agent = build_user_agent(_get_runtime_version())

    if transport is None:
        transport = _make_transport(config)

    # Network call — if this raises, we never touch the state file.
    response = transport.register(
        installation_id=installation_id,
        contact_email=contact_email.strip(),
        contact_name=contact_name.strip(),
        organization=organization.strip() if organization else None,
        operator_role=operator_role.strip() if operator_role else None,
        timezone=tz,
        report_geo=config.report_geo,
        user_agent=user_agent,
    )

    # SUCCESS PATH ONLY — mutate and persist.
    state.register(
        installation_id,
        installation_secret=response.installation_secret,
        contact_email=contact_email.strip(),
        contact_name=contact_name.strip(),
    )
    save_state(config.state_path, state)

    return RegisterResult(
        installation_id=installation_id,
        registered_at=state.registered_at or _utcnow_iso(),
        newly_registered=(existing_id != installation_id) or not existing_id,
        installation_secret=response.installation_secret,
        contact_email=contact_email.strip(),
        contact_name=contact_name.strip(),
        response=response,
    )


# ---------------------------------------------------------------------------
# run
# ---------------------------------------------------------------------------

def _derive_window(state: SyncState, now_iso: str) -> Tuple[str, str]:
    """Pick the default window for a fresh ``run_sync`` call.

    Windows tile (do not overlap): the next window starts where the last
    one ended. On first sync, the start is the registration timestamp.
    """
    if state.uploaded_windows:
        last = max(state.uploaded_windows, key=lambda w: w.window_end)
        return last.window_end, now_iso
    if state.registered_at is not None:
        return state.registered_at, now_iso
    # Not reachable in normal flow because run_sync requires registration.
    return AGGREGATE_DEFAULT_WINDOW_START, now_iso


def run_sync(
    config: SyncConfig,
    *,
    dry_run: bool = False,
    window: Optional[Tuple[str, str]] = None,
    now_iso: Optional[str] = None,
    transport: Optional[SyncTransport] = None,
) -> RunResult:
    """Load state, aggregate, upload, and persist — in that order.

    State mutation rule (ENFORCED HERE)
    -----------------------------------
    The ONLY call to ``save_state`` in this function is on a single line,
    AFTER ``transport.sync(...)`` has returned without raising. Any
    exception raised by config/state/aggregate/transport propagates out
    of this function without ever reaching that line. The state file on
    disk is byte-identical to its pre-call contents in every failure path.

    Dry-run rule
    ------------
    Dry-run returns BEFORE the ``transport.sync`` call, so it is
    structurally impossible for dry-run to hit the network. It also never
    reaches ``save_state``.
    """
    now = now_iso or _utcnow_iso()

    # Step 1: read-only state load
    state = load_state(config.state_path)

    # Two-branch NotRegisteredError (plan §3.7 / guardrail §11.8).
    # Distinct messages per sub-case so the operator knows whether to
    # run register "first" (never registered) vs "again" (incomplete
    # state — their installation_id is preserved on the server).
    if not state.is_registered():
        raise NotRegisteredError(
            "Not registered. Run 'sentience-sync register --email ... "
            "--name ...' first."
        )
    if not state.has_installation_secret():
        raise NotRegisteredError(
            "Registration incomplete or outdated. Run "
            "'sentience-sync register --email ... --name ...' again."
        )

    # Step 2: resolve window bounds
    if window is not None:
        window_start, window_end = window
    else:
        window_start, window_end = _derive_window(state, now)

    # Step 3: pure aggregation (no state mutation)
    starting_offsets = state.get_starting_offsets(list(config.log_sources))
    result = aggregate(
        log_sources=list(config.log_sources),
        starting_offsets=starting_offsets,
        window_start=window_start,
        window_end=window_end,
    )

    # Step 4: build the payload we'd send. Done here (not in transport)
    # so the dry-run path can return it to the CLI for rendering without
    # the CLI reaching into transport internals.
    from sentience_sync.transport import build_sync_payload
    payload = build_sync_payload(
        installation_id=state.installation_id or "",
        runtime_version=_get_runtime_version(),
        window_start=window_start,
        window_end=window_end,
        counts_by_rule=result.counts_by_rule,
    )

    if dry_run:
        # Dry-run returns BEFORE any network call. No state advancement.
        return RunResult(
            dry_run=True,
            window_start=window_start,
            window_end=window_end,
            aggregation=result,
            upload_response=None,
            state_advanced=False,
            duplicate=False,
            sync_run_id=None,
            payload=payload,
        )

    # Step 5: upload. If this raises (NetworkError, ServerError), the
    # function exits immediately and the state file is untouched. The
    # ValueError path on empty/whitespace secret is caught here and
    # re-raised as NotRegisteredError so the CLI shows the right
    # operator-facing message instead of a traceback.
    if transport is None:
        transport = _make_transport(config)
    try:
        response = transport.sync(
            installation_id=state.installation_id or "",
            installation_secret=state.installation_secret or "",
            window_start=window_start,
            window_end=window_end,
            counts_by_rule=result.counts_by_rule,
        )
    except ValueError as exc:
        # transport.sync fail-fast on missing/empty secret. Bridge to
        # the incomplete-state NotRegisteredError so CLI exit code and
        # message are consistent.
        raise NotRegisteredError(
            "Registration incomplete or outdated. Run "
            "'sentience-sync register --email ... --name ...' again."
        ) from exc

    # Step 6: SUCCESS PATH — mutate state and persist. This is the only
    # save_state call in this module on the run path. It is structurally
    # unreachable unless the upload call above succeeded.
    #
    # NOTE: duplicate=True also reaches this branch — the server's
    # idempotent replay is a successful no-op from the protocol's
    # perspective, and advancing local state (offsets, window record)
    # is still correct because the window was uploaded, just at an
    # earlier time.
    state.update_offsets(result.new_offsets)
    state.record_upload(window_start, window_end, result.counts_by_rule)
    save_state(config.state_path, state)

    return RunResult(
        dry_run=False,
        window_start=window_start,
        window_end=window_end,
        aggregation=result,
        upload_response=response,
        state_advanced=True,
        duplicate=response.duplicate,
        sync_run_id=response.sync_run_id,
        payload=payload,
    )


# ---------------------------------------------------------------------------
# update-check
# ---------------------------------------------------------------------------

def check_updates(
    config: SyncConfig,
    *,
    transport: Optional[SyncTransport] = None,
) -> UpdateCheckResult:
    """Query Sentience Cloud for curated update recommendations.

    Requires registration (the server keys recommendations off
    ``installation_id``). Never advances state. No bearer-token auth —
    update-check is a public GET endpoint on the server.
    """
    state = load_state(config.state_path)
    if not state.is_registered():
        raise NotRegisteredError(
            "Not registered. Run 'sentience-sync register --email ... "
            "--name ...' first."
        )

    if transport is None:
        transport = _make_transport(config)
    response = transport.update_check(
        installation_id=state.installation_id or "",
    )
    return UpdateCheckResult(response=response)


# ---------------------------------------------------------------------------
# aggregate (pure-local)
# ---------------------------------------------------------------------------

def compute_aggregate(
    config: SyncConfig,
    *,
    window: Optional[Tuple[str, str]] = None,
) -> AggregateResult:
    """Compute counts for a window across the configured log sources.

    Purity rules
    ------------
    * No network call.
    * No state file read or write.
    * No wall-clock time — default window is a fixed constant so output
      is byte-deterministic across runs on the same inputs.
    * Starts from offset 0 for every log source (this is an auditing
      tool, not a sync tool; it answers "what's in my logs?", not
      "what's new since last sync?").
    """
    window_start, window_end = (
        window
        if window is not None
        else (AGGREGATE_DEFAULT_WINDOW_START, AGGREGATE_DEFAULT_WINDOW_END)
    )

    result = aggregate(
        log_sources=list(config.log_sources),
        starting_offsets={},  # always from zero for determinism
        window_start=window_start,
        window_end=window_end,
    )

    return AggregateResult(
        window_start=window_start,
        window_end=window_end,
        aggregation=result,
    )
