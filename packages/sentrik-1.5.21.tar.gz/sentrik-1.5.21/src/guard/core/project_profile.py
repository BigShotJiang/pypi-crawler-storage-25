"""Project profile builder — analyzes codebase to extract design constraints.

Scans the full source tree (respecting scan_exclude) to detect frameworks,
architectural patterns, coding conventions, compliance signals, and ADRs.
Used by the MCP ``get_design_constraints`` tool and the dashboard profile tab.
"""

from __future__ import annotations

import json
import logging
import re
from collections import Counter, defaultdict
from pathlib import Path
from typing import Any

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Language → extensions
# ---------------------------------------------------------------------------

_LANG_EXTENSIONS: dict[str, list[str]] = {
    "Python":     [".py"],
    "TypeScript": [".ts", ".tsx"],
    "JavaScript": [".js", ".jsx", ".mjs"],
    "Go":         [".go"],
    "Rust":       [".rs"],
    "Java":       [".java"],
    "Kotlin":     [".kt"],
    "C#":         [".cs"],
    "C++":        [".cpp", ".cxx", ".cc", ".hpp"],
    "C":          [".c", ".h"],
    "Ruby":       [".rb"],
    "PHP":        [".php"],
    "Swift":      [".swift"],
    "Dart":       [".dart"],
}

_EXT_TO_LANG: dict[str, str] = {
    ext: lang for lang, exts in _LANG_EXTENSIONS.items() for ext in exts
}

# Directories always excluded from scanning
_ALWAYS_SKIP: set[str] = {
    "node_modules", "__pycache__", ".venv", "venv", "env",
    ".git", ".svn", ".hg",
    "out", "dist", "build", "target",
    ".mypy_cache", ".pytest_cache", ".ruff_cache",
    "bin", "obj", ".idea", ".vs",
}

# ---------------------------------------------------------------------------
# Framework detection
# ---------------------------------------------------------------------------

_PYTHON_FRAMEWORKS: dict[str, list[str]] = {
    "FastAPI":        ["fastapi"],
    "Django":         ["django"],
    "Flask":          ["flask"],
    "SQLAlchemy":     ["sqlalchemy"],
    "Pydantic":       ["pydantic"],
    "Celery":         ["celery"],
    "Pytest":         ["pytest"],
    "NumPy":          ["numpy"],
    "Pandas":         ["pandas"],
    "PyTorch":        ["torch"],
    "TensorFlow":     ["tensorflow"],
    "Scikit-learn":   ["scikit-learn", "sklearn"],
    "Requests":       ["requests"],
    "httpx":          ["httpx"],
    "Typer":          ["typer"],
    "Click":          ["click"],
    "Rich":           ["rich"],
    "aiohttp":        ["aiohttp"],
    "Alembic":        ["alembic"],
    "Motor":          ["motor"],
    "Redis":          ["redis"],
    "Kafka":          ["confluent-kafka", "kafka-python"],
    "RabbitMQ":       ["pika"],
    "Boto3 (AWS)":    ["boto3"],
    "Azure SDK":      ["azure-core", "azure-identity"],
    "Google Cloud":   ["google-cloud"],
    "MCP":            ["mcp"],
    "LangChain":      ["langchain"],
    "OpenAI SDK":     ["openai"],
    "Anthropic SDK":  ["anthropic"],
    "uvicorn":        ["uvicorn"],
    "gunicorn":       ["gunicorn"],
}

_JS_FRAMEWORKS: dict[str, list[str]] = {
    "React":       ["react"],
    "Next.js":     ["next"],
    "Vue":         ["vue"],
    "Angular":     ["@angular/core"],
    "Svelte":      ["svelte"],
    "Express":     ["express"],
    "Fastify":     ["fastify"],
    "NestJS":      ["@nestjs/core"],
    "Prisma":      ["@prisma/client"],
    "TypeORM":     ["typeorm"],
    "Mongoose":    ["mongoose"],
    "Drizzle ORM": ["drizzle-orm"],
    "Jest":        ["jest"],
    "Vitest":      ["vitest"],
    "Playwright":  ["@playwright/test"],
    "Tailwind CSS":["tailwindcss"],
    "Redux":       ["redux", "@reduxjs/toolkit"],
    "Zustand":     ["zustand"],
    "tRPC":        ["@trpc/server"],
    "Zod":         ["zod"],
    "Supabase":    ["@supabase/supabase-js"],
    "Socket.IO":   ["socket.io"],
    "GraphQL":     ["graphql", "apollo-server"],
    "OpenAI SDK":  ["openai"],
    "Anthropic SDK": ["@anthropic-ai/sdk"],
    "Vite":        ["vite"],
}

_GO_FRAMEWORKS: dict[str, str] = {
    "Gin":    "github.com/gin-gonic/gin",
    "Echo":   "github.com/labstack/echo",
    "GORM":   "gorm.io/gorm",
    "Cobra":  "github.com/spf13/cobra",
    "Fiber":  "github.com/gofiber/fiber",
    "Chi":    "github.com/go-chi/chi",
    "Go-kit": "github.com/go-kit/kit",
}

# ---------------------------------------------------------------------------
# Architectural pattern detection
# (name, directory_keywords, file_suffix_keywords, description)
# ---------------------------------------------------------------------------

_ARCH_PATTERNS: list[tuple[str, list[str], list[str], str]] = [
    (
        "Layered Architecture",
        ["core", "domain", "infrastructure", "presentation", "application", "usecases", "usecase"],
        [],
        "Codebase is organized into distinct layers — core/domain logic separated from infrastructure and presentation",
    ),
    (
        "Provider / Plugin Pattern",
        ["providers", "provider", "plugins", "plugin", "backends", "backend"],
        ["_provider", "provider_", ".provider.", "Provider"],
        "Extensible system with interchangeable providers or plugins — improves testability and modularity",
    ),
    (
        "Adapter / Ports & Adapters",
        ["adapters", "adapter", "ports", "port", "inbound", "outbound"],
        ["_adapter", "Adapter", "_port", "Port"],
        "Application core isolated from external systems via adapters — enables swapping implementations without touching business logic",
    ),
    (
        "Repository Pattern",
        ["repositories", "repository", "repos", "repo"],
        ["_repository", "_repo", "Repository"],
        "Data access abstracted behind repository interfaces — improves testability and decouples storage technology",
    ),
    (
        "Service Layer",
        ["services", "service"],
        ["_service", ".service.", "Service"],
        "Business logic encapsulated in dedicated service classes, separate from controllers and data access",
    ),
    (
        "Factory Pattern",
        ["factories", "factory"],
        ["_factory", "factory_", ".factory.", "Factory"],
        "Object creation centralized in factory functions or classes — used for provider selection and dependency wiring",
    ),
    (
        "MVC / Router Pattern",
        ["controllers", "controller", "routes", "router", "routers", "views"],
        ["_controller", ".controller.", "Controller", "_router", ".router.", "Router", "_routes", "routes_"],
        "Request routing and controller separation — standard MVC or API router structure",
    ),
    (
        "Middleware",
        ["middleware", "middlewares", "interceptors", "interceptor", "filters", "guards"],
        ["_middleware", ".middleware.", "Middleware", "_interceptor", "_guard", ".guard.", "Guard"],
        "Cross-cutting concerns (auth, logging, rate limiting) handled in middleware layers",
    ),
    (
        "Schema / Data Model Layer",
        ["schemas", "schema", "models", "model", "entities", "entity", "dto", "dtos", "types"],
        ["_schema", ".schema.", "Schema", "_model", ".model.", "Model", "_entity", "Entity", "_dto", "Dto"],
        "Structured data modeling with validation schemas or ORM models — important for input validation and type safety",
    ),
    (
        "Event-Driven Architecture",
        ["events", "handlers", "listeners", "subscribers", "emitters", "publishers", "consumers"],
        ["_event", "Event_", "_handler", ".handler.", "Handler", "_listener", "Listener", "_subscriber", "Consumer"],
        "Components communicate through events rather than direct calls — improves decoupling and auditability",
    ),
    (
        "Command / Query Separation (CQRS)",
        ["commands", "command", "queries", "query"],
        ["_command", "Command_", "_query", "Query_"],
        "Read and write operations separated — improves clarity, scalability, and audit trail",
    ),
    (
        "Pipeline / Chain of Responsibility",
        ["pipeline", "pipelines", "steps", "stages", "processors", "processor"],
        ["_pipeline", "Pipeline", "_step", "_stage", "_processor", "Processor"],
        "Processing steps chained sequentially — common in scan engines, ETL, and CI/CD systems",
    ),
    (
        "Rule Engine",
        ["rules", "rule", "engine", "checkers", "checker", "validators", "validator", "policies", "policy"],
        ["_rule", "_rules", "rules_", "_engine", "Engine", "_checker", "_validator", "_policy", "Policy"],
        "Declarative rules evaluated against data — common in compliance, governance, and policy enforcement systems",
    ),
    (
        "Plugin / Standards Pack System",
        ["packs", "pack", "plugins", "extensions", "extension", "modules", "addons", "addon"],
        ["_pack", "pack_", "_plugin", "Plugin", "_extension", "Extension"],
        "Modular, loadable rule packs or feature extensions — enables per-project compliance customization",
    ),
    (
        "API Gateway / Facade",
        ["gateway", "gateways", "facade", "proxy", "proxies"],
        ["_gateway", "Gateway", "_facade", "Facade"],
        "Single entry point routing to downstream services — important for API security boundaries",
    ),
    (
        "Observer / Pub-Sub",
        ["pubsub", "pub_sub", "broker", "brokers", "dispatcher", "bus", "eventbus"],
        ["_broker", "Broker", "_dispatcher", "Dispatcher", "_bus", "Bus"],
        "Publishers and subscribers decoupled through a message broker",
    ),
    (
        "State Machine",
        ["states", "state", "transitions", "transition", "statemachine", "fsm"],
        ["_state", "State_", "_fsm", "_transition"],
        "Explicit state management — useful for workflow, device, or process lifecycle modeling",
    ),
]

# ---------------------------------------------------------------------------
# Compliance / regulatory signals
# (label, directory/module keywords, description)
# ---------------------------------------------------------------------------

_COMPLIANCE_SIGNALS: list[tuple[str, list[str], str]] = [
    (
        "Audit Logging",
        ["audit", "audit_log", "audit_trail", "auditlog", "activity_log"],
        "Audit trail module detected — required by SOC 2, HIPAA, IEC 62304, and most regulatory frameworks",
    ),
    (
        "Authentication & Authorization",
        ["auth", "authentication", "authorization", "oauth", "jwt", "session", "permissions", "rbac", "acl", "iam"],
        "Auth module detected — verify OWASP authentication controls, session management, and least-privilege access",
    ),
    (
        "Input Validation",
        ["validation", "validators", "sanitize", "sanitizers", "sanitization"],
        "Input validation layer detected — reduces injection, XSS, and data integrity risk",
    ),
    (
        "Secrets & Configuration Management",
        ["secrets", "vault", "keystore", "credentials", "env"],
        "Secrets/config module detected — verify no hardcoded credentials (Sentrik `secrets` scan covers this)",
    ),
    (
        "Centralized Error Handling",
        ["errors", "error", "exceptions", "exception", "fault", "faults"],
        "Error handling module detected — centralized error handling improves traceability and failure auditability",
    ),
    (
        "Cryptography",
        ["crypto", "cryptography", "encryption", "signing", "hash", "hmac", "cipher"],
        "Cryptographic module detected — verify algorithm compliance (FIPS 140-2, NIST approved algorithms)",
    ),
    (
        "Evidence & Traceability",
        ["evidence", "traceability", "trace", "attestation", "compliance", "lineage"],
        "Evidence or compliance traceability module detected — supports SOC 2 audit evidence and IEC 62304 traceability",
    ),
    (
        "Data Privacy / PII",
        ["privacy", "pii", "gdpr", "anonymize", "anonymization", "redact", "consent"],
        "Data privacy module detected — verify GDPR/CCPA controls for data subject rights and consent management",
    ),
    (
        "Rate Limiting / Throttling",
        ["rate_limit", "throttle", "ratelimit", "limiter", "quota"],
        "Rate limiting detected — important for API security, availability, and abuse prevention",
    ),
    (
        "Dependency / Supply Chain",
        ["sbom", "supply_chain", "dependencies", "lockfile", "provenance"],
        "Supply chain or SBOM module detected — use `sentrik sbom` and `sentrik vulns` to track CVEs",
    ),
]

# ---------------------------------------------------------------------------
# Framework → recommended Sentrik packs
# ---------------------------------------------------------------------------

_FRAMEWORK_PACK_RECS: dict[str, list[str]] = {
    "FastAPI":       ["owasp-top-10", "python-security"],
    "Django":        ["owasp-top-10", "python-security"],
    "Flask":         ["owasp-top-10", "python-security"],
    "Express":       ["owasp-top-10"],
    "NestJS":        ["owasp-top-10"],
    "Next.js":       ["owasp-top-10"],
    "React":         ["owasp-top-10"],
    "Angular":       ["owasp-top-10"],
    "Vue":           ["owasp-top-10"],
    "SQLAlchemy":    ["owasp-top-10"],
    "Prisma":        ["owasp-top-10"],
    "TypeORM":       ["owasp-top-10"],
    "Mongoose":      ["owasp-top-10"],
    "Drizzle ORM":   ["owasp-top-10"],
    "PyTorch":       ["nist-ai-rmf", "eu-ai-act"],
    "TensorFlow":    ["nist-ai-rmf", "eu-ai-act"],
    "Scikit-learn":  ["nist-ai-rmf"],
    "LangChain":     ["nist-ai-rmf", "eu-ai-act"],
    "OpenAI SDK":    ["nist-ai-rmf", "eu-ai-act"],
    "Anthropic SDK": ["nist-ai-rmf", "eu-ai-act"],
    "Boto3 (AWS)":   ["supply-chain-security"],
    "Azure SDK":     ["supply-chain-security"],
    "Google Cloud":  ["supply-chain-security"],
    "Kafka":         ["supply-chain-security"],
    "RabbitMQ":      ["supply-chain-security"],
}

_LANG_PACK_RECS: dict[str, list[str]] = {
    "Python": ["python-security"],
    "C++":    ["misra-c"],
    "C":      ["misra-c"],
    "Go":     ["go-security"],
    "PHP":    ["php-security"],
    "Kotlin": ["kotlin-security"],
}

# Keyword → pack suggestions based on project name/description
_KEYWORD_PACK_RECS: list[tuple[list[str], str, str]] = [
    # Medical / health — checked first so calibration/device are caught before aviation
    (["medical", "hipaa", "ehr", "hl7", "fhir", "clinical", "patient",
      "surgical", "therapy", "diagnosis", "radiology", "imaging"],        "hipaa",        "Medical/health keywords"),
    (["medical device", "fda", "iec62304", "iec 62304", "510k", "pma",
      "predicate device", "device calibration", "robot calibration",
      "surgical robot", "medical robot", "implant", "prosthetic",
      "sterilization", "biomedical", "in vitro", "in vivo"],              "fda-iec-62304","Medical device keywords"),
    (["health software", "iec 81001", "iec81001"],                        "iec-81001-5-1","Health software keywords"),
    (["pci", "payment", "cardholder", "stripe", "braintree", "acquirer"], "pci-dss",      "Payment processing keywords"),
    (["gdpr", "personal data", "pii", "data subject", "right to erasure"],"gdpr",         "GDPR/PII keywords"),
    (["cmmc", "cui", "defense contractor", "dod ", "itar", "nist 800"],   "cmmc",         "Defense/government keywords"),
    (["iso27001", "iso 27001", "information security management", "isms"],"iso-27001",    "ISO 27001 keywords"),
    # Automotive — only fire on explicit automotive terms, not generic "functional safety"
    (["automotive", "iso26262", "iso 26262", "asil", "misra", "autosar",
      "vehicle", "ecu ", "powertrain", "adas"],                           "iso-26262",    "Automotive safety keywords"),
    # Aviation — require explicit aviation terms; "calibration" alone does not qualify
    (["aviation", "do-178", "do178", "dal level", "airborne system",
      "aerospace", "avionics", "flight software"],                        "do-178c",      "Aviation/avionics keywords"),
    (["artificial intelligence", "machine learning", "neural network",
      "deep learning", "llm", "foundation model"],                        "nist-ai-rmf",  "AI/ML components"),
]

# ---------------------------------------------------------------------------
# Import extraction regexes by file extension
# ---------------------------------------------------------------------------

_IMPORT_RES: dict[str, list[re.Pattern[str]]] = {
    ".py":  [re.compile(r"^(?:from|import)\s+([\w.]+)", re.MULTILINE)],
    ".ts":  [re.compile(r"""(?:import|from)\s+['"]([^'"]+)['"]"""), re.compile(r"""require\(['"]([^'"]+)['"]\)""")],
    ".tsx": [re.compile(r"""(?:import|from)\s+['"]([^'"]+)['"]""")],
    ".js":  [re.compile(r"""(?:import|from)\s+['"]([^'"]+)['"]"""), re.compile(r"""require\(['"]([^'"]+)['"]\)""")],
    ".jsx": [re.compile(r"""(?:import|from)\s+['"]([^'"]+)['"]""")],
    ".mjs": [re.compile(r"""(?:import|from)\s+['"]([^'"]+)['"]""")],
    ".go":  [re.compile(r'"([a-zA-Z][^"]+)"')],
    ".java":[re.compile(r"^import\s+([\w.]+);", re.MULTILINE)],
    ".kt":  [re.compile(r"^import\s+([\w.]+)", re.MULTILINE)],
    ".cs":  [re.compile(r"^using\s+([\w.]+);", re.MULTILINE)],
    ".rs":  [re.compile(r"^use\s+([\w:]+)", re.MULTILINE)],
    ".rb":  [re.compile(r"""^require(?:_relative)?\s+['"]([^'"]+)['"]""", re.MULTILINE)],
    ".php": [re.compile(r"""(?:require|include)(?:_once)?\s+['"]([^'"]+)['"]""", re.MULTILINE)],
}

# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------


def build_project_profile(repo_root: str, scan_exclude: list[str] | None = None) -> dict[str, Any]:
    """Analyze the codebase and return a project profile.

    Scans the full source tree (excluding ``scan_exclude`` patterns and
    standard noise dirs) to detect languages, frameworks, architectural
    patterns, compliance signals, conventions, and module structure.
    """
    root = Path(repo_root)
    exclude_patterns: list[str] = scan_exclude or []

    print("  Collecting source files...")
    files = _collect_source_files(root, exclude_patterns)
    all_dirs = _collect_all_dirs(root, exclude_patterns)

    print(f"  Scanning imports across {len(files)} source files...")
    import_counter, internal_importers = _scan_imports(files, root)

    print("  Detecting languages and frameworks...")
    languages = _detect_languages(files)
    frameworks = _detect_frameworks(root, import_counter, exclude_patterns=exclude_patterns)

    print("  Detecting architectural patterns...")
    architecture = _detect_architecture(root, files, all_dirs, import_counter, internal_importers)
    compliance_signals = _detect_compliance_signals(all_dirs)

    print("  Analyzing conventions...")
    conventions = _detect_conventions(files)

    print("  Building module map...")
    module_map = _build_module_map(root, files, exclude_patterns)
    adrs = _find_adrs(root)
    identity = _extract_identity(root)

    print("  Computing pack recommendations...")
    recommended_packs = _recommend_packs(frameworks, languages, identity, files=files)

    print("  Building top-dependency summary...")
    top_imports = [
        {"module": mod, "importers": count}
        for mod, count in import_counter.most_common(15)
        if count >= 2
    ]

    return {
        "name":               identity.get("name", ""),
        "description":        identity.get("description", ""),
        "version":            identity.get("version", ""),
        "languages":          languages,
        "frameworks":         frameworks,
        "architecture":       architecture,
        "compliance_signals": compliance_signals,
        "adrs":               adrs,
        "conventions":        conventions,
        "module_map":         module_map,
        "top_imports":        top_imports,
        "recommended_packs":  recommended_packs,
        "tech_stack":         languages + [f["name"] for f in frameworks],
        "file_count":         len(files),
    }


# ---------------------------------------------------------------------------
# File collection
# ---------------------------------------------------------------------------


def _should_skip_dir(d: Path, exclude_patterns: list[str], root: Path) -> bool:
    if d.name in _ALWAYS_SKIP:
        return True
    rel = str(d.relative_to(root))
    return any(pat.rstrip("/") in rel for pat in exclude_patterns)


def _collect_source_files(root: Path, exclude_patterns: list[str]) -> list[Path]:
    """Walk the full tree and return all source code files."""
    files: list[Path] = []
    source_exts = set(_EXT_TO_LANG.keys())

    def _walk(path: Path) -> None:
        try:
            for child in sorted(path.iterdir()):
                if child.is_dir():
                    if not _should_skip_dir(child, exclude_patterns, root):
                        _walk(child)
                elif child.is_file() and child.suffix.lower() in source_exts:
                    files.append(child)
        except PermissionError:
            pass

    _walk(root)
    return files


def _collect_all_dirs(root: Path, exclude_patterns: list[str]) -> set[str]:
    """Return a set of all (lowercase) directory names found anywhere in the tree."""
    dirs: set[str] = set()

    def _walk(path: Path) -> None:
        try:
            for child in path.iterdir():
                if child.is_dir():
                    if not _should_skip_dir(child, exclude_patterns, root):
                        dirs.add(child.name.lower())
                        _walk(child)
        except PermissionError:
            pass

    _walk(root)
    return dirs


# ---------------------------------------------------------------------------
# Import scanning
# ---------------------------------------------------------------------------


def _scan_imports(
    files: list[Path],
    root: Path,
) -> tuple[Counter[str], dict[str, set[str]]]:
    """Extract import statements from all source files.

    Returns:
        import_counter  — Counter of internal module paths by number of files importing them
        internal_importers — map from internal module → set of files that import it
    """
    all_imports: Counter[str] = Counter()
    internal_importers: dict[str, set[str]] = defaultdict(set)

    # Derive the package root name(s) for "internal" import detection
    # A module is internal if it starts with a top-level source directory name
    top_src_dirs = {
        d.name for d in root.iterdir()
        if d.is_dir() and d.name not in _ALWAYS_SKIP and not d.name.startswith(".")
    }
    src_dir = root / "src"
    if src_dir.is_dir():
        for d in src_dir.iterdir():
            if d.is_dir() and not d.name.startswith("."):
                top_src_dirs.add(d.name)

    for fpath in files:
        ext = fpath.suffix.lower()
        patterns = _IMPORT_RES.get(ext)
        if not patterns:
            continue
        try:
            text = fpath.read_text(encoding="utf-8", errors="replace")
        except OSError:
            continue

        for pat in patterns:
            for m in pat.finditer(text):
                mod = m.group(1).strip()
                if not mod:
                    continue
                # Normalize: take the top-level component for counting
                top = mod.split(".")[0].split("/")[0].lstrip(".")
                if not top:
                    continue
                all_imports[top] += 1
                # Track which are internal (imported from our own source tree)
                if top in top_src_dirs:
                    # For Python: record full module path
                    full = mod.split(".")[0] if ext == ".py" else top
                    internal_importers[full].add(str(fpath.relative_to(root)))

    # For internal module counting, use the full module paths of internal imports
    internal_counter: Counter[str] = Counter()
    for mod, importers in internal_importers.items():
        internal_counter[mod] = len(importers)

    return internal_counter, internal_importers


# ---------------------------------------------------------------------------
# Language detection
# ---------------------------------------------------------------------------


def _detect_languages(files: list[Path]) -> list[str]:
    counts: Counter[str] = Counter()
    for f in files:
        lang = _EXT_TO_LANG.get(f.suffix.lower())
        if lang:
            counts[lang] += 1
    return [lang for lang, _ in counts.most_common()]


# ---------------------------------------------------------------------------
# Framework detection
# ---------------------------------------------------------------------------


def _detect_frameworks(
    root: Path,
    import_counter: Counter[str],
    exclude_patterns: list[str] | None = None,
) -> list[dict[str, str]]:
    _excl = exclude_patterns or []
    frameworks: list[dict[str, str]] = []
    seen: set[str] = set()

    def _add(name: str, source: str) -> None:
        if name not in seen:
            frameworks.append({"name": name, "source": source})
            seen.add(name)

    def _is_excluded(p: Path) -> bool:
        """Return True if any part of the path matches an always-skip or exclude pattern."""
        parts = p.parts
        if any(part in _ALWAYS_SKIP for part in parts):
            return True
        rel = str(p.relative_to(root))
        return any(pat.rstrip("/") in rel for pat in _excl)

    # Python manifests
    for req_file in ("requirements.txt", "pyproject.toml", "setup.cfg", "Pipfile", "setup.py"):
        path = root / req_file
        if path.is_file():
            try:
                content = path.read_text(encoding="utf-8", errors="replace").lower()
                for name, patterns in _PYTHON_FRAMEWORKS.items():
                    if any(p in content for p in patterns):
                        _add(name, req_file)
            except OSError:
                pass

    # package.json (root and common subdirectories — respecting excludes)
    for pkg_path in root.rglob("package.json"):
        if _is_excluded(pkg_path):
            continue
        try:
            pkg = json.loads(pkg_path.read_text(encoding="utf-8"))
            all_deps = {**pkg.get("dependencies", {}), **pkg.get("devDependencies", {})}
            rel = str(pkg_path.relative_to(root))
            for name, patterns in _JS_FRAMEWORKS.items():
                if any(p in all_deps for p in patterns):
                    _add(name, rel)
        except (json.JSONDecodeError, OSError, ValueError):
            pass

    # go.mod
    go_mod = root / "go.mod"
    if go_mod.is_file():
        try:
            content = go_mod.read_text(encoding="utf-8", errors="replace")
            for name, pattern in _GO_FRAMEWORKS.items():
                if pattern in content:
                    _add(name, "go.mod")
        except OSError:
            pass

    return frameworks


# ---------------------------------------------------------------------------
# Architecture detection
# ---------------------------------------------------------------------------


def _detect_architecture(
    root: Path,
    files: list[Path],
    all_dirs: set[str],
    import_counter: Counter[str],
    internal_importers: dict[str, set[str]],
) -> list[dict[str, Any]]:
    """Detect architectural patterns from directory names, file names, and import graph."""

    # Build file stem set for naming pattern matching (all languages)
    file_stems = [f.stem for f in files]
    file_names = [f.name for f in files]

    # Highly-imported internal modules (centrality signals)
    central_modules = {mod for mod, count in import_counter.items() if count >= 3}

    patterns: list[dict[str, Any]] = []
    seen: set[str] = set()

    for pattern_name, dir_keywords, file_keywords, description in _ARCH_PATTERNS:
        if pattern_name in seen:
            continue

        evidence: list[str] = []

        # 1. Directory signal
        matched_dirs = [kw for kw in dir_keywords if kw in all_dirs]
        if matched_dirs:
            evidence.append(f"directory: {', '.join(matched_dirs)}")

        # 2. File naming signal (works for all languages — matches stems and full names)
        file_hits: list[str] = []
        for kw in file_keywords:
            matches = [
                nm for nm in file_names
                if kw.lower() in nm.lower()
            ]
            if matches:
                file_hits.append(f"{kw} ({len(matches)} file{'s' if len(matches) != 1 else ''})")
        if file_hits:
            evidence.append(f"files: {', '.join(file_hits[:3])}")

        # 3. Import centrality signal — if a module matching a dir/file keyword is heavily imported
        for kw in dir_keywords + file_keywords:
            kw_clean = kw.strip("_.")
            for mod in central_modules:
                if kw_clean.lower() in mod.lower():
                    count = import_counter[mod]
                    evidence.append(f"import hub: {mod} ({count} importers)")
                    break

        if evidence:
            seen.add(pattern_name)
            patterns.append({
                "pattern":     pattern_name,
                "evidence":    "; ".join(evidence),
                "description": description,
            })

    return patterns


# ---------------------------------------------------------------------------
# Compliance signals
# ---------------------------------------------------------------------------


def _detect_compliance_signals(all_dirs: set[str]) -> list[dict[str, str]]:
    """Detect compliance-relevant structural signals from directory names."""
    signals: list[dict[str, str]] = []
    for label, keywords, description in _COMPLIANCE_SIGNALS:
        matched = [kw for kw in keywords if kw in all_dirs]
        if matched:
            signals.append({
                "signal":      label,
                "evidence":    f"directory: {', '.join(matched)}",
                "description": description,
            })
    return signals


# ---------------------------------------------------------------------------
# Convention detection
# ---------------------------------------------------------------------------


def _detect_conventions(files: list[Path]) -> dict[str, Any]:
    """Analyze actual source code to infer coding conventions."""
    conventions: dict[str, Any] = {}

    # Detect convention/config files
    roots_checked: set[Path] = {f.parent for f in files}
    all_parents: set[Path] = set()
    for p in roots_checked:
        all_parents.add(p)
        all_parents.add(p.parent)  # also check parent
    convention_files = []
    for parent in all_parents:
        for name in (".editorconfig", ".prettierrc", ".prettierrc.js", ".eslintrc",
                     ".eslintrc.js", ".eslintrc.json", "CONVENTIONS.md", "CONTRIBUTING.md",
                     "styleguide.md", ".flake8", "pyproject.toml", ".ruff.toml"):
            if (parent / name).is_file():
                convention_files.append(name)
    if convention_files:
        conventions["convention_files"] = sorted(set(convention_files))

    # Python-specific analysis
    py_files = [f for f in files if f.suffix == ".py"][:60]
    if py_files:
        type_hint_count = 0
        docstring_count = 0
        async_count = 0
        dataclass_count = 0
        pydantic_count = 0
        camel_fn_count = 0
        snake_fn_count = 0
        total_fns = 0

        fn_re = re.compile(r"^\s*(?:async\s+)?def\s+(\w+)\s*\(([^)]*)\)\s*(?:->\s*\S+)?", re.MULTILINE)
        async_re = re.compile(r"^\s*async\s+def\s+", re.MULTILINE)
        doc_re = re.compile(r'^\s*"""', re.MULTILINE)
        camel_re = re.compile(r"^[a-z]+[A-Z]")

        for f in py_files:
            try:
                text = f.read_text(encoding="utf-8", errors="replace")
            except OSError:
                continue

            if '"""' in text or "'''" in text:
                docstring_count += 1
            if "->" in text:
                type_hint_count += 1
            if "async def " in text:
                async_count += 1
            if "@dataclass" in text:
                dataclass_count += 1
            if "BaseModel" in text or "pydantic" in text.lower():
                pydantic_count += 1

            for m in fn_re.finditer(text):
                fn_name = m.group(1)
                if fn_name.startswith("_") or fn_name in ("__init__", "__str__", "__repr__"):
                    continue
                total_fns += 1
                if camel_re.match(fn_name):
                    camel_fn_count += 1
                else:
                    snake_fn_count += 1

        n = len(py_files)
        if total_fns > 0:
            if camel_fn_count / total_fns > 0.3:
                conventions["naming_style"] = "camelCase (mixed)"
            else:
                conventions["naming_style"] = "snake_case"

        if type_hint_count > n // 2:
            conventions["type_hints"] = f"widely used ({type_hint_count}/{n} files)"
        elif type_hint_count > 0:
            conventions["type_hints"] = f"partial ({type_hint_count}/{n} files)"

        if docstring_count > n // 2:
            conventions["docstrings"] = f"widely used ({docstring_count}/{n} files)"

        if async_count > n // 3:
            conventions["async_style"] = f"async-heavy ({async_count}/{n} Python files)"

        if pydantic_count > 0:
            conventions["data_modeling"] = f"Pydantic ({pydantic_count} files)"
        elif dataclass_count > 0:
            conventions["data_modeling"] = f"dataclasses ({dataclass_count} files)"

    # TypeScript/JavaScript analysis
    ts_files = [f for f in files if f.suffix in (".ts", ".tsx")][:30]
    if ts_files:
        interface_count = 0
        type_count = 0
        for f in ts_files:
            try:
                text = f.read_text(encoding="utf-8", errors="replace")
                if re.search(r"\binterface\s+\w+", text):
                    interface_count += 1
                if re.search(r"\btype\s+\w+\s*=", text):
                    type_count += 1
            except OSError:
                continue
        if interface_count + type_count > len(ts_files) // 2:
            conventions["ts_typing"] = f"typed ({interface_count} interfaces, {type_count} type aliases)"

    # Test naming pattern
    test_files = [f for f in files if "test" in f.name.lower() or "spec" in f.name.lower()]
    if test_files:
        prefix_style = sum(1 for f in test_files if f.name.startswith("test_"))
        suffix_style = sum(1 for f in test_files if f.name.endswith(("_test.py", "_test.ts", ".test.ts", ".spec.ts")))
        if prefix_style > suffix_style:
            conventions["test_naming"] = f"test_* prefix ({prefix_style} files)"
        elif suffix_style > 0:
            conventions["test_naming"] = f"*_test / *.spec suffix ({suffix_style} files)"
        conventions["test_file_count"] = len(test_files)

    return conventions


# ---------------------------------------------------------------------------
# ADR detection
# ---------------------------------------------------------------------------


def _find_adrs(root: Path) -> list[dict[str, str]]:
    adrs: list[dict[str, str]] = []
    for adr_dir in ("docs/adr", "docs/decisions", "adr", "decisions", "docs/architecture"):
        path = root / adr_dir
        if path.is_dir():
            for f in sorted(path.iterdir()):
                if f.suffix.lower() == ".md":
                    try:
                        title = f.read_text(encoding="utf-8", errors="replace").split("\n")[0].lstrip("# ").strip()
                    except OSError:
                        title = f.stem
                    adrs.append({"file": str(f.relative_to(root)), "title": title})
    for pattern in ("ADR-*.md", "adr-*.md"):
        for f in root.glob(pattern):
            adrs.append({"file": f.name, "title": f.stem})
    return adrs


# ---------------------------------------------------------------------------
# Module map
# ---------------------------------------------------------------------------


_KNOWN_DIR_PURPOSES: dict[str, str] = {
    "src":         "Source code root",
    "lib":         "Library code",
    "app":         "Application entry",
    "api":         "API endpoints",
    "tests":       "Test suite",
    "test":        "Test suite",
    "spec":        "Test specifications",
    "docs":        "Documentation",
    "scripts":     "Build / utility scripts",
    "config":      "Configuration files",
    "migrations":  "Database migrations",
    "static":      "Static assets",
    "public":      "Public assets",
    "templates":   "HTML templates",
    "frontend":    "Frontend application",
    "backend":     "Backend application",
    "cli":         "Command-line interface",
    "core":        "Core business logic",
    "services":    "Service layer",
    "models":      "Data models",
    "providers":   "Provider implementations",
    "adapters":    "Adapter implementations",
    "handlers":    "Request / event handlers",
    "middleware":  "Middleware components",
    "utils":       "Utility functions",
    "helpers":     "Helper functions",
    "common":      "Shared / common code",
    "shared":      "Shared modules",
    "types":       "Type definitions",
    "schemas":     "Data schemas",
    "routes":      "Route definitions",
    "controllers": "Controller layer",
    "repositories":"Data access repositories",
    "packs":       "Standards packs",
    "rules":       "Rule definitions",
    "reporters":   "Output formatters",
    "infra":       "Infrastructure code",
    "deploy":      "Deployment configuration",
    "docker":      "Docker configuration",
    "k8s":         "Kubernetes manifests",
    "ci":          "CI/CD configuration",
    "tools":       "Developer tooling",
    "examples":    "Example code",
    "demos":       "Demo applications",
}


def _build_module_map(root: Path, files: list[Path], exclude_patterns: list[str]) -> list[dict[str, Any]]:
    module_map: list[dict[str, Any]] = []
    file_set = set(files)

    for d in sorted(root.iterdir()):
        if not d.is_dir():
            continue
        if d.name.startswith(".") or d.name in _ALWAYS_SKIP:
            continue
        if _should_skip_dir(d, exclude_patterns, root):
            continue
        purpose = _KNOWN_DIR_PURPOSES.get(d.name.lower(), "")
        # Count only source files (not all files) for meaningful signal
        src_count = sum(1 for f in files if str(f).startswith(str(d)))
        all_count = sum(1 for _ in d.rglob("*") if _.is_file())
        if all_count > 0:
            module_map.append({
                "directory":    d.name,
                "purpose":      purpose,
                "files":        all_count,
                "source_files": src_count,
            })

    return module_map


# ---------------------------------------------------------------------------
# Project identity extraction
# ---------------------------------------------------------------------------


def _extract_identity(root: Path) -> dict[str, str]:
    identity: dict[str, str] = {"name": "", "description": "", "version": ""}

    # pyproject.toml
    pyproject = root / "pyproject.toml"
    if pyproject.is_file():
        try:
            text = pyproject.read_text(encoding="utf-8", errors="replace")
            for field in ("name", "version", "description"):
                m = re.search(rf'^{field}\s*=\s*["\']([^"\']+)["\']', text, re.MULTILINE)
                if m and not identity[field]:
                    identity[field] = m.group(1).strip()
        except OSError:
            pass

    # package.json (root)
    pkg_json = root / "package.json"
    if pkg_json.is_file():
        try:
            pkg = json.loads(pkg_json.read_text(encoding="utf-8"))
            for field in ("name", "version", "description"):
                if not identity[field] and pkg.get(field):
                    identity[field] = str(pkg[field])
        except (json.JSONDecodeError, OSError):
            pass

    # README.md — grab the first non-heading paragraph
    for readme_name in ("README.md", "readme.md", "README.rst"):
        readme = root / readme_name
        if readme.is_file():
            try:
                lines = readme.read_text(encoding="utf-8", errors="replace").splitlines()
                for line in lines:
                    line = line.strip()
                    if line and not line.startswith("#") and not line.startswith("!") and not identity["description"]:
                        identity["description"] = line[:200]
                        break
            except OSError:
                pass
            break

    return identity


# ---------------------------------------------------------------------------
# Pack recommendations
# ---------------------------------------------------------------------------


def _recommend_packs(
    frameworks: list[dict[str, str]],
    languages: list[str],
    identity: dict[str, str],
    files: list[Path] | None = None,
) -> list[dict[str, str]]:
    """Return deterministic Sentrik pack recommendations based on detected stack.

    Scans manifest identity fields AND a sample of source file content so that
    domain context buried in code (e.g. "robot calibration" in a medical device
    project) is found even when it doesn't appear in pyproject.toml or README.
    """
    recs: dict[str, str] = {}  # pack_id → reason

    framework_names = {f["name"] for f in frameworks}

    for fw in framework_names:
        for pack in _FRAMEWORK_PACK_RECS.get(fw, []):
            recs.setdefault(pack, f"{fw} detected")

    for lang in languages:
        for pack in _LANG_PACK_RECS.get(lang, []):
            recs.setdefault(pack, f"{lang} codebase")

    # Build a corpus for keyword matching: manifest identity + sample of source content.
    # We read up to 50 source files (first 4 KB each) so we catch domain terms that
    # only appear in actual code rather than the project description.
    corpus_parts = [
        identity.get("name", ""),
        identity.get("description", ""),
    ]
    if files:
        sampled = files[:50]
        for fpath in sampled:
            try:
                corpus_parts.append(fpath.read_text(encoding="utf-8", errors="replace")[:4096])
            except OSError:
                pass

    corpus = " ".join(corpus_parts).lower()

    for keywords, pack, reason in _KEYWORD_PACK_RECS:
        if any(kw in corpus for kw in keywords):
            recs.setdefault(pack, reason)

    return [{"pack": pack, "reason": reason} for pack, reason in sorted(recs.items())]


# ---------------------------------------------------------------------------
# Design constraints (MCP tool support)
# ---------------------------------------------------------------------------


def get_design_constraints(
    profile: dict[str, Any],
    file_path: str | None = None,
    intent: str | None = None,
) -> dict[str, Any]:
    """Return design constraints for a specific file or intent (used by MCP tool)."""
    frameworks = {f["name"] for f in profile.get("frameworks", [])}
    arch_patterns = [p["pattern"] for p in profile.get("architecture", [])]

    constraints: dict[str, Any] = {
        "tech_stack":          profile.get("tech_stack", []),
        "established_patterns": list(arch_patterns),
        "architectural_rules": profile.get("architecture", []),
        "adrs":                profile.get("adrs", []),
        "conventions":         profile.get("conventions", {}),
        "tech_stack_warnings": [],
    }

    # File-path-specific guidance
    if file_path:
        parts = Path(file_path).parts
        if any(p in ("api", "routes", "endpoints", "views") for p in parts):
            if "FastAPI" in frameworks:
                constraints["established_patterns"].append(
                    "Use FastAPI APIRouter, Depends() for DI, and Pydantic models for request/response."
                )
            elif "Express" in frameworks:
                constraints["established_patterns"].append(
                    "Use Express Router, middleware pattern, and async error handling."
                )
            elif "Django" in frameworks:
                constraints["established_patterns"].append(
                    "Use class-based views or DRF serializers for API endpoints."
                )
        if any(p in ("db", "database", "repositories", "models") for p in parts):
            if "SQLAlchemy" in frameworks:
                constraints["established_patterns"].append(
                    "Use the existing SQLAlchemy session pattern and declarative models."
                )
            elif "Prisma" in frameworks:
                constraints["established_patterns"].append(
                    "Use the Prisma client for all database operations."
                )

    # Intent-based guidance
    if intent:
        intent_lower = intent.lower()
        if "auth" in intent_lower:
            constraints["established_patterns"].append(
                "Check existing auth patterns before implementing authentication. Do not introduce a second auth system."
            )
        if "database" in intent_lower or "migration" in intent_lower:
            constraints["established_patterns"].append(
                "Use the project's established ORM/database library. Do not introduce a new one."
            )

    if frameworks:
        constraints["tech_stack_warnings"].append(
            f"Project uses: {', '.join(sorted(frameworks))}. Do not introduce conflicting frameworks."
        )

    return constraints


# ---------------------------------------------------------------------------
# Profile-context — three-layer persistent understanding
# ---------------------------------------------------------------------------


def _read_scan_insights(output_dir: str = "out") -> dict[str, Any]:
    """Extract actionable insights from the most recent findings.json.

    Returns a dict with:
    - severity_counts: {critical, high, medium, low, info} tallies
    - top_rules: [(rule_id, count), ...] up to 10 most-fired rules
    - risk_modules: [path, ...] top directories with most findings
    - frameworks_flagged: [standard, ...] distinct compliance standards hit
    - total: total finding count
    """
    path = Path(output_dir) / "findings.json"
    if not path.is_file():
        return {}
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
    except (json.JSONDecodeError, OSError):
        return {}

    findings = data if isinstance(data, list) else data.get("findings", [])
    if not findings:
        return {}

    severity_counts: Counter[str] = Counter()
    rule_counts: Counter[str] = Counter()
    module_counts: Counter[str] = Counter()
    standards: set[str] = set()

    for f in findings:
        sev = (f.get("severity") or "info").lower()
        severity_counts[sev] += 1

        rule_id = f.get("rule_id", "")
        if rule_id:
            rule_counts[rule_id] += 1

        # Top-level path component as module proxy
        evidence = f.get("evidence") or {}
        file_path = evidence.get("file", "") if isinstance(evidence, dict) else ""
        if not file_path:
            file_path = f.get("file", "")
        if file_path:
            parts = Path(file_path).parts
            if parts:
                module_counts[parts[0]] += 1

        std = f.get("standard", "")
        if std:
            standards.add(std)

    return {
        "total": len(findings),
        "severity_counts": dict(severity_counts),
        "top_rules": rule_counts.most_common(10),
        "risk_modules": [mod for mod, _ in module_counts.most_common(5)],
        "frameworks_flagged": sorted(standards),
    }


def _read_profile_context(root: str = ".") -> str:
    """Read the existing .sentrik/profile-context.md if present."""
    path = Path(root) / ".sentrik" / "profile-context.md"
    if not path.is_file():
        return ""
    try:
        return path.read_text(encoding="utf-8", errors="replace")
    except OSError:
        return ""


def save_profile_context(content: str, root: str = ".") -> Path:
    """Write the LLM-generated profile-context.md to .sentrik/."""
    sentrik_dir = Path(root) / ".sentrik"
    sentrik_dir.mkdir(parents=True, exist_ok=True)
    path = sentrik_dir / "profile-context.md"
    path.write_text(content, encoding="utf-8")
    return path


# ---------------------------------------------------------------------------
# Persistence
# ---------------------------------------------------------------------------


def save_profile(profile: dict[str, Any], output_dir: str = "out") -> Path:
    out = Path(output_dir)
    out.mkdir(parents=True, exist_ok=True)
    path = out / "project-profile.json"
    path.write_text(json.dumps(profile, indent=2), encoding="utf-8")
    return path


def load_profile(output_dir: str = "out") -> dict[str, Any] | None:
    path = Path(output_dir) / "project-profile.json"
    if path.is_file():
        try:
            return json.loads(path.read_text(encoding="utf-8"))
        except (json.JSONDecodeError, OSError):
            return None
    return None
