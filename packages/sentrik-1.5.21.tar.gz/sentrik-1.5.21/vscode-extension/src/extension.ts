import * as vscode from "vscode";
import * as cp from "child_process";
import * as path from "path";
import * as fs from "fs";
import * as http from "http";

// ---------------------------------------------------------------------------
// CLI version gating
// ---------------------------------------------------------------------------

/** Minimum CLI version this extension requires. Bump when new CLI features are used. */
const SENTRIK_MIN_CLI_VERSION = "1.5.5";

// ---------------------------------------------------------------------------
// Severity mapping
// ---------------------------------------------------------------------------

const SEVERITY_MAP: Record<string, vscode.DiagnosticSeverity> = {
  critical: vscode.DiagnosticSeverity.Error,
  high: vscode.DiagnosticSeverity.Error,
  medium: vscode.DiagnosticSeverity.Warning,
  low: vscode.DiagnosticSeverity.Information,
  info: vscode.DiagnosticSeverity.Hint,
};

const SEVERITY_ICON: Record<string, string> = {
  critical: "error",
  high: "error",
  medium: "warning",
  low: "info",
  info: "debug-hint",
};

const SEVERITY_ORDER: Record<string, number> = {
  critical: 0,
  high: 1,
  medium: 2,
  low: 3,
  info: 4,
};

// ---------------------------------------------------------------------------
// Finding interface (matches CLI JSON output)
// ---------------------------------------------------------------------------

interface Finding {
  finding_id: string;
  rule_id: string;
  severity: string;
  message: string;
  evidence: {
    file: string;
    lines: number[];
    snippet: string;
  };
  suggestion?: string;
  confidence: number;
  deterministic: boolean;
  remediation_guidance?: string;
  standard?: string;
  clause?: string;
}

// ---------------------------------------------------------------------------
// Global state
// ---------------------------------------------------------------------------

let diagnosticCollection: vscode.DiagnosticCollection;
let outputChannel: vscode.OutputChannel;
let statusBarItem: vscode.StatusBarItem;
let scoreStatusBarItem: vscode.StatusBarItem;
let isScanning = false;
let scanDebounceTimer: ReturnType<typeof setTimeout> | undefined;
let lastFindings: Finding[] = [];
let findingsTreeProvider: FindingsTreeProvider;
let packsTreeProvider: PacksTreeProvider;

// Copilot LM proxy state
let lmProxyServer: http.Server | undefined;
let lmProxyPort: number | undefined;
let proxyModel: vscode.LanguageModelChat | undefined; // cached, reused for all proxy requests
let dashboardTerminal: vscode.Terminal | undefined;
let dashboardPanel: vscode.WebviewPanel | undefined;

// Extension context — needed for secret storage
let extensionContext: vscode.ExtensionContext | undefined;

// ---------------------------------------------------------------------------
// Findings Tree View (sidebar)
// ---------------------------------------------------------------------------

class FindingTreeItem extends vscode.TreeItem {
  constructor(
    public readonly finding: Finding,
    public readonly root: string
  ) {
    super(finding.message, vscode.TreeItemCollapsibleState.None);
    this.description = `${finding.rule_id} — ${path.basename(finding.evidence.file)}:${finding.evidence.lines[0] || 0}`;
    this.tooltip = new vscode.MarkdownString(
      `**${finding.rule_id}** (${finding.severity})\n\n` +
      `${finding.message}\n\n` +
      `File: \`${finding.evidence.file}:${finding.evidence.lines[0] || 0}\`\n\n` +
      (finding.suggestion || finding.remediation_guidance
        ? `**Fix:** ${finding.suggestion || finding.remediation_guidance}`
        : "")
    );
    this.iconPath = new vscode.ThemeIcon(
      SEVERITY_ICON[finding.severity] || "info"
    );
    this.contextValue = "finding";

    // Click to navigate to the finding
    const absPath = path.isAbsolute(finding.evidence.file)
      ? finding.evidence.file
      : path.join(root, finding.evidence.file);
    const line = finding.evidence.lines[0] ? finding.evidence.lines[0] - 1 : 0;
    this.command = {
      command: "vscode.open",
      title: "Go to finding",
      arguments: [
        vscode.Uri.file(absPath),
        { selection: new vscode.Range(line, 0, line, 0) },
      ],
    };
  }
}

class SeverityGroupItem extends vscode.TreeItem {
  constructor(
    public readonly severity: string,
    public readonly findings: Finding[],
    public readonly root: string
  ) {
    super(
      `${severity.toUpperCase()} (${findings.length})`,
      vscode.TreeItemCollapsibleState.Expanded
    );
    this.iconPath = new vscode.ThemeIcon(
      SEVERITY_ICON[severity] || "info"
    );
    this.contextValue = "severityGroup";
  }
}

class FindingsTreeProvider
  implements vscode.TreeDataProvider<vscode.TreeItem>
{
  private _onDidChangeTreeData = new vscode.EventEmitter<void>();
  readonly onDidChangeTreeData = this._onDidChangeTreeData.event;
  private findings: Finding[] = [];
  private root = "";

  refresh(findings: Finding[], root: string): void {
    this.findings = findings;
    this.root = root;
    this._onDidChangeTreeData.fire();
  }

  getTreeItem(element: vscode.TreeItem): vscode.TreeItem {
    return element;
  }

  getChildren(element?: vscode.TreeItem): vscode.TreeItem[] {
    if (!element) {
      // Root: group by severity
      const groups = new Map<string, Finding[]>();
      for (const f of this.findings) {
        if (!groups.has(f.severity)) {
          groups.set(f.severity, []);
        }
        groups.get(f.severity)!.push(f);
      }
      // Sort by severity order
      const sorted = [...groups.entries()].sort(
        (a, b) => (SEVERITY_ORDER[a[0]] ?? 9) - (SEVERITY_ORDER[b[0]] ?? 9)
      );
      if (sorted.length === 0) {
        const noFindings = new vscode.TreeItem("No findings");
        noFindings.iconPath = new vscode.ThemeIcon("check");
        return [noFindings];
      }
      return sorted.map(
        ([sev, findings]) => new SeverityGroupItem(sev, findings, this.root)
      );
    }
    if (element instanceof SeverityGroupItem) {
      return element.findings.map(
        (f) => new FindingTreeItem(f, element.root)
      );
    }
    return [];
  }
}

// ---------------------------------------------------------------------------
// Standards Packs Tree View (sidebar)
// ---------------------------------------------------------------------------

interface PackInfo {
  id: string;
  name: string;
  rules: number;
  tier: string;
  enabled: boolean;
  custom: boolean;
}

class PackTreeItem extends vscode.TreeItem {
  constructor(
    public readonly pack: PackInfo
  ) {
    super(pack.name, vscode.TreeItemCollapsibleState.None);
    this.description = `${pack.rules} rules — ${pack.tier}`;
    this.tooltip = new vscode.MarkdownString(
      `**${pack.id}**\n\n` +
      `Rules: ${pack.rules}\n\n` +
      `Tier: ${pack.tier}\n\n` +
      `Status: ${pack.enabled ? "Enabled" : "Disabled"}` +
      (pack.custom ? "\n\n*Custom pack*" : "")
    );
    this.iconPath = new vscode.ThemeIcon(
      pack.enabled ? "check" : "circle-slash",
      pack.enabled
        ? new vscode.ThemeColor("testing.iconPassed")
        : undefined
    );
    this.contextValue = pack.enabled ? "packEnabled" : "packDisabled";
    this.command = {
      command: pack.enabled ? "sentrik.removePack" : "sentrik.addPack",
      title: pack.enabled ? "Disable pack" : "Enable pack",
      arguments: [pack.id],
    };
  }
}

class PackGroupItem extends vscode.TreeItem {
  constructor(
    public readonly label_text: string,
    public readonly packs: PackInfo[]
  ) {
    super(label_text, vscode.TreeItemCollapsibleState.Expanded);
    this.iconPath = new vscode.ThemeIcon("package");
    this.contextValue = "packGroup";
  }
}

class PacksTreeProvider implements vscode.TreeDataProvider<vscode.TreeItem> {
  private _onDidChangeTreeData = new vscode.EventEmitter<void>();
  readonly onDidChangeTreeData = this._onDidChangeTreeData.event;
  private packs: PackInfo[] = [];
  private customLimit = 5;

  refresh(packs: PackInfo[], customLimit?: number): void {
    this.packs = packs;
    if (customLimit !== undefined) {
      this.customLimit = customLimit;
    }
    this._onDidChangeTreeData.fire();
  }

  getTreeItem(element: vscode.TreeItem): vscode.TreeItem {
    return element;
  }

  getChildren(element?: vscode.TreeItem): vscode.TreeItem[] {
    if (!element) {
      if (this.packs.length === 0) {
        const loading = new vscode.TreeItem("Loading packs...");
        loading.iconPath = new vscode.ThemeIcon("sync~spin");
        return [loading];
      }
      const enabled = this.packs.filter(p => p.enabled);
      const available = this.packs.filter(p => !p.enabled);
      const custom = this.packs.filter(p => p.custom);
      const groups: vscode.TreeItem[] = [];
      if (enabled.length > 0) {
        groups.push(new PackGroupItem(`Enabled (${enabled.length})`, enabled));
      }
      if (available.length > 0) {
        groups.push(new PackGroupItem(`Available (${available.length})`, available));
      }
      if (custom.length > 0) {
        groups.push(new PackGroupItem(`Custom (${custom.length}/${this.customLimit})`, custom));
      }
      if (groups.length === 0) {
        const noPacks = new vscode.TreeItem("No packs found");
        noPacks.iconPath = new vscode.ThemeIcon("info");
        return [noPacks];
      }
      return groups;
    }
    if (element instanceof PackGroupItem) {
      return element.packs.map(p => new PackTreeItem(p));
    }
    return [];
  }
}

// ---------------------------------------------------------------------------
// Code Action Provider (quick fixes)
// ---------------------------------------------------------------------------

class SentrikCodeActionProvider implements vscode.CodeActionProvider {
  provideCodeActions(
    document: vscode.TextDocument,
    range: vscode.Range
  ): vscode.CodeAction[] {
    const actions: vscode.CodeAction[] = [];
    const diagnostics = diagnosticCollection.get(document.uri);
    if (!diagnostics) return actions;

    for (const diag of diagnostics) {
      if (!diag.range.intersection(range)) continue;

      const ruleId = diag.code?.toString() || "";

      // Suppress finding (add inline comment)
      const suppressAction = new vscode.CodeAction(
        `Suppress ${ruleId} (sentrik-ignore)`,
        vscode.CodeActionKind.QuickFix
      );
      suppressAction.edit = new vscode.WorkspaceEdit();
      const line = diag.range.start.line;
      const lineText = document.lineAt(line).text;
      const indent = lineText.match(/^\s*/)?.[0] || "";

      // Detect comment style from file extension
      const ext = path.extname(document.fileName).toLowerCase();
      let commentPrefix = "#";
      if ([".js", ".ts", ".jsx", ".tsx", ".java", ".c", ".cpp", ".go", ".rs", ".swift", ".kt", ".scala", ".dart", ".cs"].includes(ext)) {
        commentPrefix = "//";
      } else if ([".php"].includes(ext)) {
        commentPrefix = "//";
      }

      suppressAction.edit.insert(
        document.uri,
        new vscode.Position(line, 0),
        `${indent}${commentPrefix} sentrik-ignore: ${ruleId}\n`
      );
      suppressAction.diagnostics = [diag];
      suppressAction.isPreferred = false;
      actions.push(suppressAction);

      // View docs
      const docsAction = new vscode.CodeAction(
        `View docs for ${ruleId}`,
        vscode.CodeActionKind.QuickFix
      );
      docsAction.command = {
        command: "vscode.open",
        title: "View docs",
        arguments: [vscode.Uri.parse(`https://docs.sentrik.dev/rules/${ruleId}`)],
      };
      docsAction.diagnostics = [diag];
      actions.push(docsAction);

      // Apply suggestion if available
      const finding = lastFindings.find(
        (f) => f.rule_id === ruleId && f.evidence.lines[0] === line + 1
      );
      if (finding?.suggestion) {
        const explainAction = new vscode.CodeAction(
          `How to fix: ${finding.suggestion.slice(0, 60)}${finding.suggestion.length > 60 ? "..." : ""}`,
          vscode.CodeActionKind.QuickFix
        );
        explainAction.command = {
          command: "sentrik.showFix",
          title: "Show fix",
          arguments: [finding],
        };
        explainAction.diagnostics = [diag];
        explainAction.isPreferred = true;
        actions.push(explainAction);
      }

      // Explain with Copilot (if Copilot is available)
      if (finding && typeof vscode.lm !== "undefined") {
        const copilotAction = new vscode.CodeAction(
          `✨ Explain ${ruleId} with Copilot`,
          vscode.CodeActionKind.QuickFix
        );
        copilotAction.command = {
          command: "sentrik.explainWithCopilot",
          title: "Explain with Copilot",
          arguments: [finding],
        };
        copilotAction.diagnostics = [diag];
        actions.push(copilotAction);
      }
    }

    return actions;
  }
}

// ---------------------------------------------------------------------------
// Copilot LM proxy
//
// A minimal OpenAI-compatible HTTP server running inside the extension host.
// The Sentrik CLI's `GUARD_LLM_BASE_URL` is pointed at this proxy so every
// AI feature in the CLI and dashboard (confidence scoring, threat model,
// design review, drift analysis) runs through the user's Copilot subscription
// — no separate API key needed.
// ---------------------------------------------------------------------------

/** Pick the best available Copilot chat model. Returns undefined if Copilot is not available. */
async function getCopilotModel(): Promise<vscode.LanguageModelChat | undefined> {
  try {
    // Prefer gpt-4o; fall back to any copilot model
    for (const family of ["gpt-4o", "gpt-4", "claude-sonnet", "claude"]) {
      const models = await vscode.lm.selectChatModels({ vendor: "copilot", family });
      if (models.length > 0) return models[0];
    }
    const any = await vscode.lm.selectChatModels({ vendor: "copilot" });
    return any[0];
  } catch {
    return undefined;
  }
}

/** Stream a Copilot response to a string. */
async function streamToString(
  model: vscode.LanguageModelChat,
  messages: vscode.LanguageModelChatMessage[],
  token: vscode.CancellationToken
): Promise<string> {
  const response = await model.sendRequest(messages, {}, token);
  let result = "";
  for await (const chunk of response.text) {
    result += chunk;
  }
  return result;
}

/**
 * Start a local HTTP server that accepts OpenAI-compatible `/v1/chat/completions`
 * requests and routes them through the VS Code Language Model API (Copilot).
 * Assigns a random port in the 47100–47999 range.
 */
async function startLmProxy(): Promise<void> {
  const config = vscode.workspace.getConfiguration("sentrik");
  if (!config.get<boolean>("enableCopilotAI", true)) return;

  // Check Copilot is available
  const model = await getCopilotModel();
  if (!model) {
    outputChannel.appendLine("Copilot LM proxy: no Copilot model available — proxy not started");
    return;
  }

  const port = 47200; // fixed port so config.yaml URL stays stable

  lmProxyServer = http.createServer((req, res) => {
    if (req.method !== "POST" || !req.url?.includes("chat/completions")) {
      res.writeHead(404);
      res.end(JSON.stringify({ error: "Not found" }));
      return;
    }

    let body = "";
    req.on("data", (chunk) => { body += chunk.toString(); });
    req.on("end", async () => {
      try {
        const payload = JSON.parse(body);
        const rawMessages: Array<{ role: string; content: string }> = payload.messages || [];

        // Map OpenAI roles to VS Code LM API message types.
        // LanguageModelChatMessage.System() was added in VS Code 1.94; fall back
        // to User() on older versions so the system prompt still gets through.
        const systemFn: ((c: string) => vscode.LanguageModelChatMessage) =
          (vscode.LanguageModelChatMessage as any).System?.bind(vscode.LanguageModelChatMessage)
          ?? vscode.LanguageModelChatMessage.User.bind(vscode.LanguageModelChatMessage);

        const lmMessages = rawMessages.map((m) => {
          if (m.role === "assistant") return vscode.LanguageModelChatMessage.Assistant(m.content);
          if (m.role === "system")    return systemFn(m.content);
          return vscode.LanguageModelChatMessage.User(m.content);
        });

        // Use the cached model; refresh if it has gone stale
        if (!proxyModel) {
          proxyModel = await getCopilotModel();
        }
        if (!proxyModel) {
          res.writeHead(503);
          res.end(JSON.stringify({ error: "Copilot model unavailable" }));
          return;
        }

        const cts = new vscode.CancellationTokenSource();
        let text: string;
        try {
          text = await streamToString(proxyModel, lmMessages, cts.token);
        } catch (modelErr: any) {
          // If the model is no longer valid, clear cache so next request retries
          proxyModel = undefined;
          cts.dispose();
          throw modelErr;
        }
        cts.dispose();

        const responseBody = JSON.stringify({
          id: `sentrik-proxy-${Date.now()}`,
          object: "chat.completion",
          model: proxyModel.name,
          choices: [{
            index: 0,
            message: { role: "assistant", content: text },
            finish_reason: "stop",
          }],
          usage: { prompt_tokens: 0, completion_tokens: 0, total_tokens: 0 },
        });

        res.writeHead(200, {
          "Content-Type": "application/json",
          "Content-Length": Buffer.byteLength(responseBody),
        });
        res.end(responseBody);
        outputChannel.appendLine(`Copilot proxy: served request (${text.length} chars)`);
      } catch (err: any) {
        outputChannel.appendLine(`Copilot proxy error: ${err.message}`);
        res.writeHead(500);
        res.end(JSON.stringify({ error: err.message }));
      }
    });
  });

  await new Promise<void>((resolve, reject) => {
    lmProxyServer!.listen(port, "127.0.0.1", async () => {
      lmProxyPort = port;
      outputChannel.appendLine(`Copilot LM proxy started on http://127.0.0.1:${port} (model: ${model.name})`);

      // Warm-up: send a trivial request so VS Code shows the Copilot permission
      // dialog NOW (while the user is in VS Code) rather than silently canceling
      // the first real request later from a background HTTP call.
      try {
        const cts = new vscode.CancellationTokenSource();
        await streamToString(
          model,
          [vscode.LanguageModelChatMessage.User("reply with the single word: ready")],
          cts.token
        );
        cts.dispose();
        proxyModel = model; // permission granted — cache for all proxy requests
        outputChannel.appendLine("Copilot LM proxy: permission granted, proxy ready");
        _writeCopilotLlmConfig(port);
      } catch (err: any) {
        outputChannel.appendLine(`Copilot LM proxy: warm-up failed (${err.message}) — Copilot permission not granted`);
        vscode.window.showWarningMessage(
          "SENTRIK: Copilot AI not available. Open the Copilot Chat panel and try again, or use 'SENTRIK: Configure AI Provider' to set a different provider.",
          "Configure AI"
        ).then(choice => { if (choice === "Configure AI") vscode.commands.executeCommand("sentrik.configureAI"); });
        // Don't write config — proxy is running but won't work until permission is granted
      }

      resolve();
    });
    lmProxyServer!.on("error", (err) => {
      outputChannel.appendLine(`Copilot LM proxy failed to start: ${err.message}`);
      lmProxyServer = undefined;
      reject(err);
    });
  });
}

function stopLmProxy(): void {
  if (lmProxyServer) {
    lmProxyServer.close();
    lmProxyServer = undefined;
    lmProxyPort = undefined;
    proxyModel = undefined;
    outputChannel?.appendLine("Copilot LM proxy stopped");
    _clearCopilotLlmConfig();
  }
}

// ---------------------------------------------------------------------------
// @sentrik chat participant
// ---------------------------------------------------------------------------

async function handleSentrikChat(
  request: vscode.ChatRequest,
  _context: vscode.ChatContext,
  stream: vscode.ChatResponseStream,
  token: vscode.CancellationToken
): Promise<void> {
  const model = await getCopilotModel();
  if (!model) {
    stream.markdown("GitHub Copilot is not available. Please ensure you have an active Copilot subscription.");
    return;
  }

  const root = getWorkspaceRoot() || "(no workspace)";
  const prompt = request.prompt.trim();
  const command = request.command; // "findings" | "fix" | "score" | undefined

  // Build context from current scan state
  const criticalCount = lastFindings.filter(f => f.severity === "critical").length;
  const highCount = lastFindings.filter(f => f.severity === "high").length;
  const findingsSummary = lastFindings.length === 0
    ? "No findings from the last scan."
    : `Last scan: ${lastFindings.length} total findings — ${criticalCount} critical, ${highCount} high.\n` +
      lastFindings.slice(0, 20).map(f =>
        `[${f.severity.toUpperCase()}] ${f.rule_id}: ${f.message} (${f.evidence.file}:${f.evidence.lines[0] || 0})`
      ).join("\n") +
      (lastFindings.length > 20 ? `\n...and ${lastFindings.length - 20} more.` : "");

  const systemPrompt = `You are a security and compliance assistant embedded in the Sentrik VS Code extension.
Sentrik is a governance runtime that scans code for security, compliance, and quality issues.
Workspace root: ${root}

Current scan state:
${findingsSummary}

Answer questions about findings, explain security/compliance issues, and provide actionable remediation guidance.
Be concise and practical. Reference specific rule IDs and file locations when relevant.`;

  let userMessage = prompt;
  if (command === "findings" || (!prompt && !command)) {
    userMessage = `Summarize the current findings. Highlight the most critical issues and what the developer should fix first.`;
  } else if (command === "score") {
    userMessage = `Explain the current compliance and quality posture based on the findings. What areas need the most improvement?`;
  } else if (command === "fix") {
    userMessage = prompt
      ? `Provide a detailed fix for: ${prompt}`
      : `List the top 3 most impactful fixes the developer can make right now.`;
  }

  try {
    const messages = [
      vscode.LanguageModelChatMessage.User(systemPrompt + "\n\nUser question: " + userMessage),
    ];

    stream.markdown(`*Sentrik has ${lastFindings.length} finding(s) in scope.*\n\n`);

    const response = await model.sendRequest(messages, {}, token);
    for await (const chunk of response.text) {
      stream.markdown(chunk);
    }

    // Offer follow-up actions
    stream.button({
      command: "sentrik.scan",
      title: "$(search) Re-scan",
    });
    stream.button({
      command: "sentrik.openDashboard",
      title: "$(browser) Open Dashboard",
    });
  } catch (err: any) {
    if (err?.name === "Cancelled") return;
    stream.markdown(`\n\n*Error: ${err.message}*`);
    outputChannel.appendLine(`@sentrik chat error: ${err.message}`);
  }
}

// ---------------------------------------------------------------------------
// Explain finding with Copilot (code action + command)
// ---------------------------------------------------------------------------

async function explainFindingWithCopilot(finding: Finding): Promise<void> {
  const model = await getCopilotModel();
  if (!model) {
    vscode.window.showWarningMessage("SENTRIK: GitHub Copilot is not available.");
    return;
  }

  const panel = vscode.window.createWebviewPanel(
    "sentrikCopilot",
    `Copilot: ${finding.rule_id}`,
    vscode.ViewColumn.Beside,
    { enableScripts: false }
  );

  const severity = finding.severity.toUpperCase();
  const file = `${finding.evidence.file}:${finding.evidence.lines[0] || 0}`;
  const snippet = finding.evidence.snippet || "";

  // Show loading state immediately
  panel.webview.html = buildExplainHtml(finding, severity, file, snippet, "*(Asking Copilot…)*");

  const prompt = `A security/compliance scanner found the following issue in code:

Rule: ${finding.rule_id}
Severity: ${severity}
Message: ${finding.message}
File: ${file}
${snippet ? `Code snippet:\n\`\`\`\n${snippet}\n\`\`\`` : ""}
${finding.remediation_guidance ? `Suggested fix: ${finding.remediation_guidance}` : ""}

Please explain:
1. Why this is a problem (what can go wrong)
2. A concrete fix with example code
3. Any edge cases or related issues to watch for

Be practical and concise.`;

  try {
    const cts = new vscode.CancellationTokenSource();
    const messages = [vscode.LanguageModelChatMessage.User(prompt)];
    const response = await model.sendRequest(messages, {}, cts.token);

    let explanation = "";
    for await (const chunk of response.text) {
      explanation += chunk;
      // Update panel progressively
      panel.webview.html = buildExplainHtml(finding, severity, file, snippet, explanation);
    }
    cts.dispose();
  } catch (err: any) {
    panel.webview.html = buildExplainHtml(finding, severity, file, snippet, `*Error: ${err.message}*`);
    outputChannel.appendLine(`Copilot explain error: ${err.message}`);
  }
}

function buildExplainHtml(
  finding: Finding,
  severity: string,
  file: string,
  snippet: string,
  explanation: string
): string {
  return `<!DOCTYPE html>
<html>
<head><style>
  body { font-family: var(--vscode-font-family); padding: 16px; color: var(--vscode-foreground); background: var(--vscode-editor-background); max-width: 800px; }
  h2 { margin-top: 0; display: flex; align-items: center; gap: 8px; }
  .badge { display: inline-block; padding: 2px 8px; border-radius: 4px; font-size: 12px; font-weight: bold; }
  .critical, .high { background: #ef4444; color: white; }
  .medium { background: #f59e0b; color: white; }
  .low { background: #3b82f6; color: white; }
  .info { background: #6b7280; color: white; }
  code { background: var(--vscode-textCodeBlock-background); padding: 2px 4px; border-radius: 3px; font-family: var(--vscode-editor-font-family); }
  pre { background: var(--vscode-textCodeBlock-background); padding: 12px; border-radius: 6px; overflow-x: auto; white-space: pre-wrap; }
  .meta { color: var(--vscode-descriptionForeground); font-size: 13px; margin-bottom: 16px; }
  .section { margin: 16px 0; }
  .copilot-label { font-size: 12px; color: var(--vscode-descriptionForeground); margin-bottom: 4px; display: flex; align-items: center; gap: 4px; }
  hr { border: none; border-top: 1px solid var(--vscode-widget-border); margin: 16px 0; }
  p { line-height: 1.6; }
  ul, ol { line-height: 1.8; }
</style></head>
<body>
  <h2>${escapeHtml(finding.rule_id)} <span class="badge ${finding.severity}">${severity}</span></h2>
  <div class="meta">${escapeHtml(file)}</div>
  <p>${escapeHtml(finding.message)}</p>
  ${snippet ? `<pre>${escapeHtml(snippet)}</pre>` : ""}
  <hr>
  <div class="copilot-label">✨ Copilot explanation</div>
  <div class="section">${markdownToHtml(explanation)}</div>
</body>
</html>`;
}

/** Minimal markdown → HTML for the Copilot explanation panel. */
function markdownToHtml(md: string): string {
  return md
    .replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;")
    .replace(/```[\w]*\n?([\s\S]*?)```/g, "<pre>$1</pre>")
    .replace(/`([^`]+)`/g, "<code>$1</code>")
    .replace(/\*\*(.+?)\*\*/g, "<strong>$1</strong>")
    .replace(/\*(.+?)\*/g, "<em>$1</em>")
    .replace(/^### (.+)$/gm, "<h3>$1</h3>")
    .replace(/^## (.+)$/gm, "<h2>$1</h2>")
    .replace(/^# (.+)$/gm, "<h1>$1</h1>")
    .replace(/^\d+\. (.+)$/gm, "<li>$1</li>")
    .replace(/^[-*] (.+)$/gm, "<li>$1</li>")
    .replace(/\n\n/g, "</p><p>")
    .replace(/^(?!<[hpulo])/gm, "")
    .replace(/^<p><\/p>$/gm, "");
}

// ---------------------------------------------------------------------------
// AI provider configuration wizard
// ---------------------------------------------------------------------------

const PROVIDER_OPTIONS = [
  {
    label: "$(sparkle) GitHub Copilot",
    description: "Use your existing Copilot subscription — no API key needed",
    detail: "Recommended. Requires the GitHub Copilot extension.",
    value: "copilot",
  },
  {
    label: "$(robot) Anthropic (Claude)",
    description: "claude-sonnet-4-6, claude-haiku-4-5, etc.",
    detail: "Requires an Anthropic API key.",
    value: "anthropic",
  },
  {
    label: "$(globe) OpenAI",
    description: "gpt-4o, gpt-4o-mini, or any OpenAI-compatible endpoint",
    detail: "Requires an OpenAI API key.",
    value: "openai",
  },
  {
    label: "$(server) Ollama (local)",
    description: "Run models locally — no API key, no data leaves your machine",
    detail: "Requires Ollama running at http://localhost:11434 (or custom URL).",
    value: "ollama",
  },
  {
    label: "$(settings) Custom OpenAI-compatible endpoint",
    description: "Azure OpenAI, LM Studio, vLLM, etc.",
    detail: "Any endpoint that speaks the OpenAI chat completions format.",
    value: "openai_custom",
  },
  {
    label: "$(close) Disable AI features",
    description: "Turn off LLM-powered features",
    detail: "Confidence scoring, threat model, and design review will be disabled.",
    value: "none",
  },
] as const;

const DEFAULT_MODELS: Record<string, string> = {
  anthropic: "claude-sonnet-4-6",
  openai: "gpt-4o",
  openai_custom: "gpt-4o",
  ollama: "llama3",
};

const DEFAULT_BASE_URLS: Record<string, string> = {
  ollama: "http://localhost:11434",
};

async function configureAiProvider(): Promise<void> {
  if (!extensionContext) return;

  // Step 1: pick provider
  const picked = await vscode.window.showQuickPick(PROVIDER_OPTIONS as any, {
    title: "SENTRIK: Configure AI Provider (1/3)",
    placeHolder: "Which AI provider should Sentrik use?",
    matchOnDescription: true,
    matchOnDetail: true,
  }) as typeof PROVIDER_OPTIONS[number] | undefined;

  if (!picked) return;

  const config = vscode.workspace.getConfiguration("sentrik");

  // Copilot: just enable the toggle and return
  if (picked.value === "copilot") {
    await config.update("enableCopilotAI", true, vscode.ConfigurationTarget.Global);
    await config.update("llmProvider", "", vscode.ConfigurationTarget.Global);
    if (!lmProxyPort) {
      startLmProxy().catch(() => {});
    }
    outputChannel.appendLine("AI provider: GitHub Copilot (routed via VS Code proxy — no config.yaml entry needed)");
    vscode.window.showInformationMessage("SENTRIK AI: GitHub Copilot enabled. Scans from VS Code will use Copilot automatically.");
    return;
  }

  // Disable: clear everything
  if (picked.value === "none") {
    await config.update("enableCopilotAI", false, vscode.ConfigurationTarget.Global);
    await config.update("llmProvider", "", vscode.ConfigurationTarget.Global);
    await config.update("llmModel", "", vscode.ConfigurationTarget.Global);
    await config.update("llmBaseUrl", "", vscode.ConfigurationTarget.Global);
    await _writeLlmConfig({ provider: "", model: "", baseUrl: "" });
    vscode.window.showInformationMessage("SENTRIK AI: AI features disabled.");
    return;
  }

  // Step 2: model
  const defaultModel = DEFAULT_MODELS[picked.value] || "";
  const model = await vscode.window.showInputBox({
    title: "SENTRIK: Configure AI Provider (2/3)",
    prompt: "Model name",
    value: defaultModel,
    placeHolder: defaultModel,
    ignoreFocusOut: true,
  });
  if (model === undefined) return; // cancelled

  // Step 3a: base URL (for ollama / custom)
  let baseUrl = "";
  if (picked.value === "ollama" || picked.value === "openai_custom") {
    const defaultUrl = DEFAULT_BASE_URLS[picked.value] || "";
    const inputUrl = await vscode.window.showInputBox({
      title: "SENTRIK: Configure AI Provider (3/3)",
      prompt: "API base URL",
      value: defaultUrl,
      placeHolder: defaultUrl || "https://your-endpoint.com",
      ignoreFocusOut: true,
    });
    if (inputUrl === undefined) return;
    baseUrl = inputUrl;
  }

  // Step 3b: API key (for anthropic / openai / openai_custom)
  const needsKey = picked.value === "anthropic" || picked.value === "openai" || picked.value === "openai_custom";
  if (needsKey) {
    const existingKey = await extensionContext.secrets.get(`sentrik.llmApiKey.${picked.value}`);
    const keyInput = await vscode.window.showInputBox({
      title: "SENTRIK: Configure AI Provider (3/3)",
      prompt: `${picked.label.replace(/^\$\([^)]+\)\s*/, "")} API key`,
      value: existingKey || "",
      password: true,
      placeHolder: existingKey ? "(unchanged — press Enter to keep)" : "sk-...",
      ignoreFocusOut: true,
    });
    if (keyInput === undefined) return;
    if (keyInput) {
      await extensionContext.secrets.store(`sentrik.llmApiKey.${picked.value}`, keyInput);
    }
  }

  // Persist non-secret settings to VS Code settings
  const providerValue = picked.value === "openai_custom" ? "openai" : picked.value;
  await config.update("enableCopilotAI", false, vscode.ConfigurationTarget.Global);
  await config.update("llmProvider", providerValue, vscode.ConfigurationTarget.Global);
  await config.update("llmModel", model, vscode.ConfigurationTarget.Global);
  await config.update("llmBaseUrl", baseUrl, vscode.ConfigurationTarget.Global);

  // Also write to .sentrik/config.yaml so CLI runs pick up the provider
  // (API key is never written — stays in VS Code secret storage)
  await _writeLlmConfig({ provider: providerValue, model, baseUrl });

  const providerName = picked.label.replace(/^\$\([^)]+\)\s*/, "");
  vscode.window.showInformationMessage(
    `SENTRIK AI: ${providerName} configured${model ? ` (${model})` : ""}. AI features are now active.`
  );
  outputChannel.appendLine(`AI provider set: ${providerValue} / model=${model} / baseUrl=${baseUrl || "(default)"}`);
}

/** Write LLM provider settings into .sentrik/config.yaml (never writes API keys). */
async function _writeLlmConfig(opts: { provider: string; model?: string; baseUrl?: string }): Promise<void> {
  const root = getWorkspaceRoot();
  if (!root) return;

  const configPath = path.join(root, ".sentrik", "config.yaml");
  if (!fs.existsSync(configPath)) return; // don't create config from scratch here

  try {
    let text = fs.readFileSync(configPath, "utf8");

    const setOrRemove = (key: string, value: string | undefined): void => {
      const lineRe = new RegExp(`^(\\s*)${key}:.*$`, "m");
      if (value) {
        const line = `${key}: ${value}`;
        if (lineRe.test(text)) {
          text = text.replace(lineRe, `$1${line}`);
        } else {
          text = text.trimEnd() + `\n${line}\n`;
        }
      } else {
        // Remove the key entirely
        text = text.replace(new RegExp(`^\\s*${key}:.*\\n?`, "m"), "");
      }
    };

    setOrRemove("llm_enabled", opts.provider ? "true" : undefined);
    setOrRemove("llm_provider", opts.provider || undefined);
    setOrRemove("llm_model", opts.model || undefined);
    setOrRemove("llm_base_url", opts.baseUrl || undefined);

    fs.writeFileSync(configPath, text, "utf8");
    outputChannel.appendLine(`Updated .sentrik/config.yaml with LLM settings`);
  } catch (err: any) {
    outputChannel.appendLine(`Warning: could not update .sentrik/config.yaml: ${err.message}`);
  }
}

/** Write Copilot proxy URL into .sentrik/config.yaml so the dashboard server picks it up. */
function _writeCopilotLlmConfig(port: number): void {
  const root = getWorkspaceRoot();
  if (!root) return;
  const configPath = path.join(root, ".sentrik", "config.yaml");
  if (!fs.existsSync(configPath)) return;
  try {
    let text = fs.readFileSync(configPath, "utf8");
    const setOrRemove = (key: string, value: string | undefined): void => {
      const lineRe = new RegExp(`^(\\s*)${key}:.*$`, "m");
      if (value) {
        if (lineRe.test(text)) {
          text = text.replace(lineRe, `$1${key}: ${value}`);
        } else {
          text = text.trimEnd() + `\n${key}: ${value}\n`;
        }
      } else {
        text = text.replace(new RegExp(`^\\s*${key}:.*\\n?`, "m"), "");
      }
    };
    setOrRemove("llm_enabled", "true");
    setOrRemove("llm_provider", "openai");
    setOrRemove("llm_model", "gpt-4o");
    setOrRemove("llm_base_url", `http://127.0.0.1:${port}`);
    setOrRemove("confidence_scoring_enabled", "true");
    fs.writeFileSync(configPath, text, "utf8");
    outputChannel.appendLine(`Copilot proxy: wrote LLM config to .sentrik/config.yaml (port ${port})`);
  } catch (err: any) {
    outputChannel.appendLine(`Copilot proxy: could not write config.yaml: ${err.message}`);
  }
}

/** Remove Copilot proxy entries from .sentrik/config.yaml on shutdown. */
function _clearCopilotLlmConfig(): void {
  const root = getWorkspaceRoot();
  if (!root) return;
  const configPath = path.join(root, ".sentrik", "config.yaml");
  if (!fs.existsSync(configPath)) return;
  try {
    let text = fs.readFileSync(configPath, "utf8");
    for (const key of ["llm_enabled", "llm_provider", "llm_model", "llm_base_url", "confidence_scoring_enabled"]) {
      text = text.replace(new RegExp(`^\\s*${key}:.*\\n?`, "m"), "");
    }
    fs.writeFileSync(configPath, text, "utf8");
    outputChannel?.appendLine("Copilot proxy: cleared LLM config from .sentrik/config.yaml");
  } catch {
    // ignore on shutdown
  }
}

// ---------------------------------------------------------------------------
// Activation
// ---------------------------------------------------------------------------

export function activate(context: vscode.ExtensionContext): void {
  extensionContext = context;
  diagnosticCollection = vscode.languages.createDiagnosticCollection("sentrik");
  outputChannel = vscode.window.createOutputChannel("SENTRIK");

  // Status bar — scan status
  statusBarItem = vscode.window.createStatusBarItem(
    vscode.StatusBarAlignment.Left,
    100
  );
  statusBarItem.command = "sentrik.scan";
  setStatusIdle();
  statusBarItem.show();

  // Status bar — compliance score
  scoreStatusBarItem = vscode.window.createStatusBarItem(
    vscode.StatusBarAlignment.Left,
    99
  );
  scoreStatusBarItem.command = "sentrik.qualityScore";

  // Findings tree view (sidebar)
  findingsTreeProvider = new FindingsTreeProvider();
  const treeView = vscode.window.createTreeView("sentrik.findingsView", {
    treeDataProvider: findingsTreeProvider,
    showCollapseAll: true,
  });

  // Packs tree view (sidebar)
  packsTreeProvider = new PacksTreeProvider();
  const packsTreeView = vscode.window.createTreeView("sentrik.packsView", {
    treeDataProvider: packsTreeProvider,
    showCollapseAll: true,
  });

  // Code actions (quick fixes)
  const codeActionProvider = vscode.languages.registerCodeActionsProvider(
    { scheme: "file" },
    new SentrikCodeActionProvider(),
    { providedCodeActionKinds: [vscode.CodeActionKind.QuickFix] }
  );

  // Start Copilot LM proxy (non-blocking — fails gracefully if Copilot unavailable)
  startLmProxy().catch(() => {});

  // Register @sentrik chat participant (vscode.chat available in VS Code 1.90+)
  if (typeof (vscode as any).chat !== "undefined") {
    const participant = (vscode as any).chat.createChatParticipant("sentrik", handleSentrikChat);
    participant.iconPath = new vscode.ThemeIcon("shield");
    context.subscriptions.push(participant);
  }

  // Register commands
  context.subscriptions.push(
    vscode.commands.registerCommand("sentrik.scan", () => runScan()),
    vscode.commands.registerCommand("sentrik.gate", () => runGate()),
    vscode.commands.registerCommand("sentrik.qualityScore", () => runQualityScore()),
    vscode.commands.registerCommand("sentrik.clearDiagnostics", () => {
      diagnosticCollection.clear();
      lastFindings = [];
      findingsTreeProvider.refresh([], "");
      setStatusIdle();
      scoreStatusBarItem.hide();
    }),
    vscode.commands.registerCommand("sentrik.configureAI", () => configureAiProvider()),
    vscode.commands.registerCommand("sentrik.copilotStatus", async () => {
      const model = await getCopilotModel();
      if (model) {
        const proxyInfo = lmProxyPort
          ? `\nProxy: http://127.0.0.1:${lmProxyPort} (CLI AI features routing through Copilot)`
          : "\nProxy: not running";
        vscode.window.showInformationMessage(`SENTRIK Copilot AI: active (${model.name})${proxyInfo}`);
      } else {
        vscode.window.showWarningMessage("SENTRIK Copilot AI: GitHub Copilot not available. Install the GitHub Copilot extension and sign in.");
      }
    }),
    vscode.commands.registerCommand("sentrik.explainWithCopilot", (finding: Finding) => {
      explainFindingWithCopilot(finding);
    }),
    vscode.commands.registerCommand("sentrik.showFix", (finding: Finding) => {
      const fix = finding.suggestion || finding.remediation_guidance || "No fix available.";
      const panel = vscode.window.createWebviewPanel(
        "sentrikFix",
        `Fix: ${finding.rule_id}`,
        vscode.ViewColumn.Beside,
        {}
      );
      panel.webview.html = `<!DOCTYPE html>
<html>
<head><style>
  body { font-family: var(--vscode-font-family); padding: 16px; color: var(--vscode-foreground); background: var(--vscode-editor-background); }
  h2 { margin-top: 0; }
  .badge { display: inline-block; padding: 2px 8px; border-radius: 4px; font-size: 12px; font-weight: bold; }
  .critical, .high { background: #ef4444; color: white; }
  .medium { background: #f59e0b; color: white; }
  .low { background: #3b82f6; color: white; }
  .info { background: #6b7280; color: white; }
  code { background: var(--vscode-textCodeBlock-background); padding: 2px 4px; border-radius: 3px; }
  pre { background: var(--vscode-textCodeBlock-background); padding: 12px; border-radius: 6px; overflow-x: auto; }
  .section { margin: 16px 0; }
</style></head>
<body>
  <h2>${finding.rule_id} <span class="badge ${finding.severity}">${finding.severity.toUpperCase()}</span></h2>
  <p>${finding.message}</p>
  <div class="section">
    <strong>File:</strong> <code>${finding.evidence.file}:${finding.evidence.lines[0] || 0}</code>
  </div>
  ${finding.evidence.snippet ? `<div class="section"><strong>Code:</strong><pre>${escapeHtml(finding.evidence.snippet)}</pre></div>` : ""}
  <div class="section">
    <strong>How to fix:</strong>
    <p>${escapeHtml(fix)}</p>
  </div>
  ${finding.standard ? `<div class="section"><strong>Standard:</strong> ${finding.standard}${finding.clause ? ` §${finding.clause}` : ""}</div>` : ""}
</body>
</html>`;
    }),
    vscode.commands.registerCommand("sentrik.openDashboard", () => openDashboard()),
    vscode.commands.registerCommand("sentrik.managePacks", () => refreshPacks()),
    vscode.commands.registerCommand("sentrik.addPack", (packId?: string) => addPack(packId)),
    vscode.commands.registerCommand("sentrik.removePack", (packId?: string) => removePack(packId)),
    vscode.commands.registerCommand("sentrik.createCustomPack", () => createCustomPack()),
    vscode.commands.registerCommand("sentrik.scanFile", (uri?: vscode.Uri) => {
      const target = uri?.fsPath || vscode.window.activeTextEditor?.document.uri.fsPath;
      if (target) runScanTarget(target);
    }),
    vscode.commands.registerCommand("sentrik.scanFolder", (uri?: vscode.Uri) => {
      if (uri?.fsPath) runScanTarget(uri.fsPath);
    }),
    // Legacy command aliases
    vscode.commands.registerCommand("ai-sdlc-guard.scan", () => runScan()),
    vscode.commands.registerCommand("ai-sdlc-guard.gate", () => runGate()),
    vscode.commands.registerCommand("ai-sdlc-guard.clearDiagnostics", () =>
      diagnosticCollection.clear()
    ),
    diagnosticCollection,
    outputChannel,
    statusBarItem,
    scoreStatusBarItem,
    treeView,
    packsTreeView,
    codeActionProvider
  );

  // Auto-init + initial scan + version check on activation
  const root = getWorkspaceRoot();
  if (root) {
    checkCliVersion(root);
    autoInitAndScan(root);
    refreshPacks();
  }

  // Scan on save — only the saved file, not the full workspace
  context.subscriptions.push(
    vscode.workspace.onDidSaveTextDocument((doc) => {
      const config = vscode.workspace.getConfiguration("sentrik");
      const autoScan = config.get<boolean>("autoScan") ??
        vscode.workspace.getConfiguration("ai-sdlc-guard").get<boolean>("scanOnSave") ??
        true;
      if (autoScan) {
        debouncedScanFile(doc.uri.fsPath);
      }
    })
  );

  outputChannel.appendLine("SENTRIK extension activated");
}

export function deactivate(): void {
  stopLmProxy();
  dashboardTerminal?.dispose();
  dashboardPanel?.dispose();
  diagnosticCollection?.dispose();
  outputChannel?.dispose();
  statusBarItem?.dispose();
  scoreStatusBarItem?.dispose();
}

// ---------------------------------------------------------------------------
// HTML escape helper
// ---------------------------------------------------------------------------

function escapeHtml(text: string): string {
  return text
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;");
}

// ---------------------------------------------------------------------------
// Binary discovery
// ---------------------------------------------------------------------------

function discoverBinary(): string {
  const config = vscode.workspace.getConfiguration("sentrik");
  const configPath = config.get<string>("binaryPath");
  if (configPath) return configPath;

  const legacyPath = vscode.workspace
    .getConfiguration("ai-sdlc-guard")
    .get<string>("guardPath");
  if (legacyPath && legacyPath !== "guard") return legacyPath;

  // Auto-detect pip-installed binary on Windows
  if (process.platform === "win32") {
    const home = process.env.USERPROFILE || process.env.HOME || "";
    const pipPaths = [
      path.join(home, "AppData", "Local", "Programs", "Python", "Python313", "Scripts", "sentrik.exe"),
      path.join(home, "AppData", "Local", "Programs", "Python", "Python312", "Scripts", "sentrik.exe"),
      path.join(home, "AppData", "Local", "Programs", "Python", "Python311", "Scripts", "sentrik.exe"),
      path.join(home, "AppData", "Local", "Programs", "Python", "Python310", "Scripts", "sentrik.exe"),
      path.join(home, "AppData", "Roaming", "Python", "Python313", "Scripts", "sentrik.exe"),
      path.join(home, "AppData", "Roaming", "Python", "Python312", "Scripts", "sentrik.exe"),
      path.join(home, "AppData", "Roaming", "Python", "Python311", "Scripts", "sentrik.exe"),
      path.join(home, "AppData", "Local", "Microsoft", "WindowsApps", "sentrik.exe"),
    ];
    for (const p of pipPaths) {
      if (fs.existsSync(p)) {
        outputChannel.appendLine(`Auto-detected binary: ${p}`);
        return p;
      }
    }

    // Fall back to `where sentrik` to find the binary on PATH
    try {
      const result = cp.spawnSync("where", ["sentrik"], { encoding: "utf8" });
      if (result.status === 0 && result.stdout) {
        const found = result.stdout.trim().split(/\r?\n/)[0];
        if (found && fs.existsSync(found)) {
          outputChannel.appendLine(`Auto-detected binary via where: ${found}`);
          return found;
        }
      }
    } catch {
      // ignore
    }
  } else {
    // macOS/Linux: try `which sentrik`
    try {
      const result = cp.spawnSync("which", ["sentrik"], { encoding: "utf8" });
      if (result.status === 0 && result.stdout) {
        const found = result.stdout.trim();
        if (found && fs.existsSync(found)) {
          outputChannel.appendLine(`Auto-detected binary via which: ${found}`);
          return found;
        }
      }
    } catch {
      // ignore
    }
  }

  return "sentrik";
}

// ---------------------------------------------------------------------------
// Status bar helpers
// ---------------------------------------------------------------------------

function setStatusIdle(cliVersion?: string): void {
  statusBarItem.text = "$(shield) SENTRIK";
  statusBarItem.tooltip = cliVersion
    ? `SENTRIK v${cliVersion} — click to scan`
    : "SENTRIK — click to scan";
  statusBarItem.backgroundColor = undefined;
}

// ---------------------------------------------------------------------------
// CLI version check
// ---------------------------------------------------------------------------

/** Parse a semver string like "1.5.5" or "sentrik, version 1.5.5" into [major, minor, patch]. */
function parseSemver(raw: string): [number, number, number] | null {
  const m = raw.match(/(\d+)\.(\d+)\.(\d+)/);
  if (!m) return null;
  return [parseInt(m[1], 10), parseInt(m[2], 10), parseInt(m[3], 10)];
}

/** Return true if actual >= required. */
function semverAtLeast(actual: [number, number, number], required: [number, number, number]): boolean {
  for (let i = 0; i < 3; i++) {
    if (actual[i] > required[i]) return true;
    if (actual[i] < required[i]) return false;
  }
  return true; // equal
}

async function checkCliVersion(root: string): Promise<void> {
  const binary = discoverBinary();
  try {
    const { stdout } = await execPromise(`${binary} --version`, { cwd: root, timeout: 10000 });
    const versionStr = stdout.trim();
    const actual = parseSemver(versionStr);

    if (!actual) {
      outputChannel.appendLine(`SENTRIK: could not parse CLI version from: ${versionStr}`);
      return;
    }

    const [maj, min, pat] = actual;
    const detectedVersion = `${maj}.${min}.${pat}`;
    outputChannel.appendLine(`SENTRIK CLI version: ${detectedVersion} (min required: ${SENTRIK_MIN_CLI_VERSION})`);

    // Update status bar tooltip to always show installed version
    setStatusIdle(detectedVersion);

    const required = parseSemver(SENTRIK_MIN_CLI_VERSION)!;
    if (!semverAtLeast(actual, required)) {
      const message = `SENTRIK CLI v${detectedVersion} is outdated. v${SENTRIK_MIN_CLI_VERSION}+ is recommended. (using: ${binary})`;
      outputChannel.appendLine(`WARNING: ${message}`);

      const choice = await vscode.window.showWarningMessage(
        message,
        "Upgrade now",
        "Dismiss"
      );
      if (choice === "Upgrade now") {
        const terminal = vscode.window.createTerminal("SENTRIK Upgrade");
        // Upgrade via the pip that lives alongside the binary the extension is
        // actually using — avoids "already satisfied" from the wrong Python env.
        const binaryDir = path.dirname(binary);
        const pipExe = process.platform === "win32"
          ? path.join(binaryDir, "pip.exe")
          : path.join(binaryDir, "pip");
        const pipExists = require("fs").existsSync(pipExe);
        const pipCmd = pipExists ? `"${pipExe}"` : "pip";
        terminal.sendText(`${pipCmd} install --force-reinstall "sentrik[treesitter]"`);
        terminal.show();
        outputChannel.appendLine(`Running upgrade via: ${pipCmd}`);
      }
    }
  } catch (err: any) {
    outputChannel.appendLine(`SENTRIK: CLI version check failed — ${err.message}`);
    // Don't block the user if version check fails (binary may not be installed yet)
  }
}

function setStatusScanning(): void {
  statusBarItem.text = "$(sync~spin) SENTRIK: scanning...";
  statusBarItem.tooltip = "SENTRIK scan in progress";
}

function setStatusFindings(count: number): void {
  if (count === 0) {
    statusBarItem.text = "$(check) SENTRIK: clean";
    statusBarItem.tooltip = "No findings";
    statusBarItem.backgroundColor = undefined;
  } else {
    statusBarItem.text = `$(shield) SENTRIK: ${count} issue${count === 1 ? "" : "s"}`;
    statusBarItem.tooltip = `${count} finding${count === 1 ? "" : "s"} — click to re-scan`;
    statusBarItem.backgroundColor = new vscode.ThemeColor(
      "statusBarItem.warningBackground"
    );
  }
}

function setStatusError(): void {
  statusBarItem.text = "$(warning) SENTRIK: error";
  statusBarItem.tooltip = "Scan failed — check SENTRIK output";
  statusBarItem.backgroundColor = new vscode.ThemeColor(
    "statusBarItem.errorBackground"
  );
}

// ---------------------------------------------------------------------------
// Auto-init and first scan
// ---------------------------------------------------------------------------

async function autoInitAndScan(root: string): Promise<void> {
  const config = vscode.workspace.getConfiguration("sentrik");
  const autoInit = config.get<boolean>("autoInit") ?? true;

  const hasSentrikConfig = fs.existsSync(path.join(root, ".sentrik", "config.yaml"));
  const hasGuardConfig = fs.existsSync(path.join(root, ".guard.yaml"));

  if (!hasSentrikConfig && !hasGuardConfig && autoInit) {
    const binary = discoverBinary();
    outputChannel.appendLine(`Auto-initializing: ${binary} init --no-interactive`);

    try {
      await execPromise(`${binary} init --no-interactive`, { cwd: root, timeout: 30000 });
      vscode.window.showInformationMessage("SENTRIK initialized. Docs: https://docs.sentrik.dev");
      outputChannel.appendLine("Auto-init complete");
    } catch (err: any) {
      outputChannel.appendLine(`Auto-init failed: ${err.message}`);
    }
  }

  const autoScan = config.get<boolean>("autoScan") ??
    vscode.workspace.getConfiguration("ai-sdlc-guard").get<boolean>("scanOnSave") ??
    true;
  if (autoScan) {
    runScan();
  }
}

// ---------------------------------------------------------------------------
// Helpers
// ---------------------------------------------------------------------------

function getWorkspaceRoot(): string | undefined {
  const folders = vscode.workspace.workspaceFolders;
  return folders?.[0]?.uri.fsPath;
}

function getSeverityFilter(): Set<string> {
  const config = vscode.workspace.getConfiguration("sentrik");
  const filter = config.get<string[]>("severityFilter") ??
    vscode.workspace.getConfiguration("ai-sdlc-guard").get<string[]>("severityFilter") ??
    ["critical", "high", "medium"];
  return new Set(filter);
}

function execPromise(
  cmd: string,
  opts: cp.ExecOptions
): Promise<{ stdout: string; stderr: string }> {
  return new Promise((resolve, reject) => {
    cp.exec(cmd, opts, (error, stdout, stderr) => {
      if (error) {
        reject(Object.assign(error, { stdout, stderr }));
      } else {
        resolve({ stdout: stdout?.toString() ?? "", stderr: stderr?.toString() ?? "" });
      }
    });
  });
}

// ---------------------------------------------------------------------------
// Debounced scan
// ---------------------------------------------------------------------------

function debouncedScan(): void {
  if (scanDebounceTimer) {
    clearTimeout(scanDebounceTimer);
  }
  scanDebounceTimer = setTimeout(() => runScan(), 500);
}

function debouncedScanFile(filePath: string): void {
  if (scanDebounceTimer) {
    clearTimeout(scanDebounceTimer);
  }
  scanDebounceTimer = setTimeout(() => runScanTarget(filePath), 500);
}

// ---------------------------------------------------------------------------
// Scan
// ---------------------------------------------------------------------------

async function runScan(): Promise<void> {
  if (isScanning) return;

  const root = getWorkspaceRoot();
  if (!root) return;

  isScanning = true;
  const binary = discoverBinary();
  setStatusScanning();
  outputChannel.appendLine(`Running: ${binary} scan`);

  const scanEnv = await buildScanEnv();
  cp.exec(
    `${binary} scan`,
    { cwd: root, timeout: 120000, env: { ...process.env, ...scanEnv } },
    (error, stdout, stderr) => {
      isScanning = false;

      if (stderr) outputChannel.appendLine(`stderr: ${stderr}`);
      if (stdout) outputChannel.appendLine(stdout);

      const findings = parseFindings(root);
      if (findings !== null) {
        lastFindings = findings;
        applyDiagnostics(root, findings);
        setStatusFindings(findings.length);
        findingsTreeProvider.refresh(findings, root);
        outputChannel.appendLine(`Scan complete: ${findings.length} findings`);
        // Auto-fetch quality score after scan
        fetchQualityScore(root);
      } else if (error) {
        setStatusError();
        outputChannel.appendLine(`Scan failed: ${error.message}`);
      } else {
        lastFindings = [];
        findingsTreeProvider.refresh([], root);
        setStatusFindings(0);
      }
    }
  );
}

// ---------------------------------------------------------------------------
// Scan file / folder
// ---------------------------------------------------------------------------

async function runScanTarget(targetPath: string): Promise<void> {
  if (isScanning) return;

  const root = getWorkspaceRoot();
  if (!root) return;

  isScanning = true;
  const binary = discoverBinary();
  const relativePath = path.relative(root, targetPath).replace(/\\/g, "/");
  const isDir = fs.existsSync(targetPath) && fs.statSync(targetPath).isDirectory();
  const label = isDir ? `folder "${relativePath}"` : `file "${relativePath}"`;

  setStatusScanning();
  outputChannel.appendLine(`Running: ${binary} scan --files "${relativePath}"`);

  const scanEnv = await buildScanEnv();
  cp.exec(
    `${binary} scan --files "${relativePath}"`,
    { cwd: root, timeout: 120000, env: { ...process.env, ...scanEnv } },
    (error, stdout, stderr) => {
      isScanning = false;

      if (stderr) outputChannel.appendLine(`stderr: ${stderr}`);
      if (stdout) outputChannel.appendLine(stdout);

      const findings = parseFindings(root);
      if (findings !== null) {
        lastFindings = findings;
        applyDiagnostics(root, findings);
        setStatusFindings(findings.length);
        findingsTreeProvider.refresh(findings, root);
        outputChannel.appendLine(`Scan of ${label} complete: ${findings.length} findings`);
        vscode.window.showInformationMessage(`SENTRIK: ${findings.length} finding(s) in ${label}`);
      } else if (error) {
        setStatusError();
        outputChannel.appendLine(`Scan failed: ${error.message}`);
      } else {
        lastFindings = [];
        findingsTreeProvider.refresh([], root);
        setStatusFindings(0);
        vscode.window.showInformationMessage(`SENTRIK: No findings in ${label}`);
      }
    }
  );
}

// ---------------------------------------------------------------------------
// Gate
// ---------------------------------------------------------------------------

function runGate(): void {
  const root = getWorkspaceRoot();
  if (!root) {
    vscode.window.showWarningMessage("SENTRIK: No workspace folder open");
    return;
  }

  const binary = discoverBinary();
  setStatusScanning();
  outputChannel.appendLine(`Running: ${binary} gate`);

  cp.exec(
    `${binary} gate`,
    { cwd: root, timeout: 120000 },
    (error, stdout, stderr) => {
      if (stderr) outputChannel.appendLine(`stderr: ${stderr}`);
      if (stdout) outputChannel.appendLine(stdout);

      const findings = parseFindings(root);
      if (findings) {
        lastFindings = findings;
        applyDiagnostics(root, findings);
        setStatusFindings(findings.length);
        findingsTreeProvider.refresh(findings, root);
      }

      if (error && error.code === 1) {
        vscode.window.showErrorMessage("SENTRIK: Gate FAILED — fix critical/high findings.");
      } else if (!error) {
        vscode.window.showInformationMessage("SENTRIK: Gate PASSED");
      } else {
        setStatusError();
        vscode.window.showWarningMessage(`SENTRIK: Gate error — ${error.message}`);
      }
    }
  );
}

// ---------------------------------------------------------------------------
// Quality Score
// ---------------------------------------------------------------------------

function fetchQualityScore(root: string): void {
  const binary = discoverBinary();

  cp.exec(
    `${binary} quality-score --json`,
    { cwd: root, timeout: 30000 },
    (error: cp.ExecException | null, stdout: string) => {
      if (error || !stdout) {
        scoreStatusBarItem.hide();
        return;
      }
      try {
        const data = JSON.parse(stdout);
        const score = data.overall_score ?? data.score ?? null;
        if (score !== null) {
          const num = Math.round(score);
          let icon = "$(pulse)";
          let color: string | undefined;
          if (num >= 80) {
            icon = "$(check)";
          } else if (num >= 50) {
            icon = "$(warning)";
            color = "statusBarItem.warningBackground";
          } else {
            icon = "$(error)";
            color = "statusBarItem.errorBackground";
          }
          scoreStatusBarItem.text = `${icon} Score: ${num}/100`;
          scoreStatusBarItem.tooltip = `Sentrik Quality Score: ${num}/100\nClick for details`;
          scoreStatusBarItem.backgroundColor = color
            ? new vscode.ThemeColor(color)
            : undefined;
          scoreStatusBarItem.show();
        }
      } catch {
        scoreStatusBarItem.hide();
      }
    }
  );
}

function runQualityScore(): void {
  const root = getWorkspaceRoot();
  if (!root) return;

  const binary = discoverBinary();
  outputChannel.appendLine(`Running: ${binary} quality-score --verbose --json`);

  cp.exec(
    `${binary} quality-score --verbose --json`,
    { cwd: root, timeout: 30000 },
    (error: cp.ExecException | null, stdout: string) => {
      if (error || !stdout) {
        vscode.window.showWarningMessage("SENTRIK: Could not fetch quality score.");
        return;
      }
      try {
        const data = JSON.parse(stdout);
        const score = Math.round(data.overall_score ?? data.score ?? 0);
        const dims = data.dimensions || {};

        let detail = `**Overall Score: ${score}/100**\n\n`;
        for (const [name, info] of Object.entries(dims) as [string, any][]) {
          const dimScore = Math.round(info.score ?? info.value ?? 0);
          detail += `- **${name}:** ${dimScore}/100\n`;
        }

        const panel = vscode.window.createWebviewPanel(
          "sentrikScore",
          `Sentrik Quality Score: ${score}/100`,
          vscode.ViewColumn.Beside,
          {}
        );
        panel.webview.html = `<!DOCTYPE html>
<html>
<head><style>
  body { font-family: var(--vscode-font-family); padding: 20px; color: var(--vscode-foreground); background: var(--vscode-editor-background); }
  h1 { margin-top: 0; }
  .score { font-size: 48px; font-weight: bold; margin: 16px 0; }
  .good { color: #22c55e; }
  .okay { color: #f59e0b; }
  .bad { color: #ef4444; }
  .dim { display: flex; justify-content: space-between; padding: 8px 0; border-bottom: 1px solid var(--vscode-widget-border); }
  .dim-name { font-weight: 600; }
  .bar-bg { width: 200px; height: 8px; background: var(--vscode-widget-border); border-radius: 4px; overflow: hidden; }
  .bar-fg { height: 100%; border-radius: 4px; }
</style></head>
<body>
  <h1>Sentrik Quality Score</h1>
  <div class="score ${score >= 80 ? "good" : score >= 50 ? "okay" : "bad"}">${score}/100</div>
  <h2>Dimensions</h2>
  ${Object.entries(dims).map(([name, info]: [string, any]) => {
          const ds = Math.round(info.score ?? info.value ?? 0);
          const barColor = ds >= 80 ? "#22c55e" : ds >= 50 ? "#f59e0b" : "#ef4444";
          return `<div class="dim">
      <span class="dim-name">${name}</span>
      <span>${ds}/100</span>
      <div class="bar-bg"><div class="bar-fg" style="width:${ds}%;background:${barColor}"></div></div>
    </div>`;
        }).join("")}
</body>
</html>`;
      } catch {
        vscode.window.showWarningMessage("SENTRIK: Failed to parse quality score.");
      }
    }
  );
}

// ---------------------------------------------------------------------------
// Parse findings from output file
// ---------------------------------------------------------------------------

function parseFindings(root: string): Finding[] | null {
  const findingsPath = path.join(root, "out", "findings.json");
  if (!fs.existsSync(findingsPath)) return null;

  try {
    const raw = fs.readFileSync(findingsPath, "utf-8");
    return JSON.parse(raw) as Finding[];
  } catch (e) {
    outputChannel.appendLine(`Failed to parse findings: ${e}`);
    return null;
  }
}

// ---------------------------------------------------------------------------
// C++ analysis environment
// ---------------------------------------------------------------------------

async function buildScanEnv(): Promise<Record<string, string>> {
  const env: Record<string, string> = {};
  const config = vscode.workspace.getConfiguration("sentrik");

  if (config.get<boolean>("enableCppAnalysis")) {
    env.GUARD_CPP_ANALYSIS_ENABLED = "true";
  }

  // Priority 1: Copilot proxy (if running and enabled)
  if (lmProxyPort && config.get<boolean>("enableCopilotAI", true)) {
    env.GUARD_LLM_PROVIDER = "openai";
    env.GUARD_LLM_BASE_URL = `http://127.0.0.1:${lmProxyPort}`;
    env.GUARD_LLM_MODEL = "gpt-4o";
    env.GUARD_CONFIDENCE_SCORING_ENABLED = "true";
    return env;
  }

  // Priority 2: manually configured provider
  const provider = config.get<string>("llmProvider", "");
  if (provider && provider !== "copilot") {
    env.GUARD_LLM_PROVIDER = provider;
    env.GUARD_CONFIDENCE_SCORING_ENABLED = "true";

    const model = config.get<string>("llmModel", "");
    if (model) env.GUARD_LLM_MODEL = model;

    const baseUrl = config.get<string>("llmBaseUrl", "");
    if (baseUrl) env.GUARD_LLM_BASE_URL = baseUrl;

    // Retrieve API key from secret storage
    if (extensionContext) {
      const apiKey = await extensionContext.secrets.get(`sentrik.llmApiKey.${provider}`);
      if (apiKey) {
        if (provider === "anthropic") env.ANTHROPIC_API_KEY = apiKey;
        else if (provider === "openai") env.OPENAI_API_KEY = apiKey;
        // ollama/custom: no key needed
      }
    }
  }

  return env;
}

// ---------------------------------------------------------------------------
// Standards Packs management
// ---------------------------------------------------------------------------

function refreshPacks(): void {
  const root = getWorkspaceRoot();
  if (!root) return;

  const binary = discoverBinary();
  outputChannel.appendLine(`Running: ${binary} list-packs --json`);

  // Fetch license tier to determine custom pack limit
  const tierLimits: Record<string, number> = { FREE: 5, TRIAL: 25, TEAM: 25, ORG: 100, ENTERPRISE: 9999 };
  let customLimit = FREE_CUSTOM_PACK_LIMIT;

  cp.exec(
    `${binary} license --json`,
    { cwd: root, timeout: 10000 },
    (licErr, licOut) => {
      if (!licErr && licOut) {
        try {
          const lic = JSON.parse(licOut);
          const tier = (lic.tier || "FREE").toUpperCase();
          customLimit = tierLimits[tier] || FREE_CUSTOM_PACK_LIMIT;
        } catch { /* use default */ }
      }

      cp.exec(
        `${binary} list-packs --json`,
        { cwd: root, timeout: 30000 },
        (error, stdout, stderr) => {
          outputChannel.appendLine(`list-packs --json: exit=${error?.code ?? 0}, stdout=${(stdout || "").length} bytes`);
          if (stderr) outputChannel.appendLine(`list-packs stderr: ${stderr}`);

          if (error || !stdout || !stdout.trim().startsWith("[")) {
            // Fallback: try without --json and parse text output
            outputChannel.appendLine("Falling back to text output...");
            cp.exec(
              `${binary} list-packs`,
              { cwd: root, timeout: 30000 },
              (_err, textOut) => {
                outputChannel.appendLine(`list-packs text: ${(textOut || "").split("\n").length} lines`);
                const packs = parsePacksText(textOut || "", root);
                outputChannel.appendLine(`Parsed ${packs.length} packs from text output`);
                packsTreeProvider.refresh(packs, customLimit);
              }
            );
            return;
          }
          try {
            const data = JSON.parse(stdout);
            const packs: PackInfo[] = (Array.isArray(data) ? data : data.packs || []).map((p: any) => ({
              id: p.id || p.pack_id || "",
              name: p.name || p.id || p.pack_id || "",
              rules: p.rules || p.rule_count || 0,
              tier: p.tier || "free",
              enabled: p.enabled ?? false,
              custom: p.custom ?? false,
            }));
            // Also scan for custom packs in .sentrik/rules/
            const customPacks = discoverCustomPacks(root);
            outputChannel.appendLine(`Loaded ${packs.length} built-in + ${customPacks.length} custom packs`);
            packsTreeProvider.refresh([...packs, ...customPacks], customLimit);
          } catch (e) {
            outputChannel.appendLine(`Failed to parse packs JSON: ${e}`);
            const customPacks = discoverCustomPacks(root);
            packsTreeProvider.refresh(customPacks, customLimit);
          }
        }
      );
    }
  );
}

function parsePacksText(text: string, root: string): PackInfo[] {
  // Parse text output from `sentrik list-packs` (table format)
  // Format: "fda-iec-62304             builtin    ENABLED    Team     31       FDA IEC 62304"
  const packs: PackInfo[] = [];
  const lines = text.split("\n");
  for (const line of lines) {
    // Skip header, separator, and summary lines
    if (line.startsWith("PACK ID") || line.startsWith("---") || line.startsWith("Total:") || line.startsWith("Add a pack") || line.trim() === "" || line.startsWith("  Docs:")) {
      continue;
    }
    const match = line.match(/^([\w-]+)\s+(builtin|custom)\s+(ENABLED|available)\s+(Free|Team|Org\w*)\s+(\d+)\s+(.+)/i);
    if (match) {
      packs.push({
        id: match[1],
        name: match[6].trim(),
        rules: parseInt(match[5], 10),
        tier: match[4].toLowerCase(),
        enabled: match[3].toUpperCase() === "ENABLED",
        custom: match[2] === "custom",
      });
    }
  }
  const customPacks = discoverCustomPacks(root);
  return [...packs, ...customPacks];
}

function discoverCustomPacks(root: string): PackInfo[] {
  const customPacks: PackInfo[] = [];
  const config = vscode.workspace.getConfiguration("sentrik");
  const customPath = config.get<string>("customPacksPath") || path.join(root, ".sentrik", "rules");

  if (!fs.existsSync(customPath)) return customPacks;

  try {
    const files = fs.readdirSync(customPath).filter(f => f.endsWith(".yaml") || f.endsWith(".yml"));
    for (const file of files) {
      const filePath = path.join(customPath, file);
      try {
        const content = fs.readFileSync(filePath, "utf-8");
        const nameMatch = content.match(/^#\s*pack:\s*(.+)/m) || content.match(/^name:\s*(.+)/m);
        const ruleCount = (content.match(/- id:/g) || content.match(/rule_id:/g) || []).length;
        customPacks.push({
          id: path.basename(file, path.extname(file)),
          name: nameMatch ? nameMatch[1].trim() : path.basename(file, path.extname(file)),
          rules: ruleCount || 0,
          tier: "custom",
          enabled: true,
          custom: true,
        });
      } catch {
        // Skip unreadable files
      }
    }
  } catch {
    // Directory not readable
  }
  return customPacks;
}

async function addPack(packId?: string): Promise<void> {
  const root = getWorkspaceRoot();
  if (!root) return;

  if (!packId) {
    packId = await vscode.window.showInputBox({
      prompt: "Enter the standards pack ID to enable (e.g., owasp-top-10, hipaa, misra-c)",
      placeHolder: "pack-id",
    });
  }
  if (!packId) return;

  const binary = discoverBinary();
  outputChannel.appendLine(`Running: ${binary} add-pack ${packId}`);

  try {
    await execPromise(`${binary} add-pack ${packId}`, { cwd: root, timeout: 30000 });
    vscode.window.showInformationMessage(`SENTRIK: Pack "${packId}" enabled`);
    refreshPacks();
    // Re-scan with new pack
    debouncedScan();
  } catch (err: any) {
    const msg = err.stderr || err.message || "Unknown error";
    vscode.window.showErrorMessage(`SENTRIK: Failed to enable pack "${packId}" — ${msg}`);
    outputChannel.appendLine(`add-pack failed: ${msg}`);
  }
}

async function removePack(packId?: string): Promise<void> {
  const root = getWorkspaceRoot();
  if (!root) return;

  if (!packId) {
    packId = await vscode.window.showInputBox({
      prompt: "Enter the standards pack ID to disable",
      placeHolder: "pack-id",
    });
  }
  if (!packId) return;

  const binary = discoverBinary();
  outputChannel.appendLine(`Running: ${binary} remove-pack ${packId}`);

  try {
    await execPromise(`${binary} remove-pack ${packId}`, { cwd: root, timeout: 30000 });
    vscode.window.showInformationMessage(`SENTRIK: Pack "${packId}" disabled`);
    refreshPacks();
  } catch (err: any) {
    const msg = err.stderr || err.message || "Unknown error";
    vscode.window.showErrorMessage(`SENTRIK: Failed to disable pack "${packId}" — ${msg}`);
  }
}

const FREE_CUSTOM_PACK_LIMIT = 5;

async function createCustomPack(): Promise<void> {
  const root = getWorkspaceRoot();
  if (!root) return;

  // Check custom pack count against free tier limit
  const config = vscode.workspace.getConfiguration("sentrik");
  const customPath = config.get<string>("customPacksPath") || path.join(root, ".sentrik", "rules");
  if (fs.existsSync(customPath)) {
    try {
      const existing = fs.readdirSync(customPath).filter(f => {
        const fullPath = path.join(customPath, f);
        return fs.statSync(fullPath).isDirectory() && fs.existsSync(path.join(fullPath, "pack.yaml"));
      });
      if (existing.length >= FREE_CUSTOM_PACK_LIMIT) {
        // Check via CLI if they have a higher-tier license
        const binary = discoverBinary();
        try {
          const { stdout } = await execPromise(`${binary} license --json`, { cwd: root, timeout: 10000 });
          const license = JSON.parse(stdout);
          const tier = (license.tier || "FREE").toUpperCase();
          const limits: Record<string, number> = { FREE: 5, TRIAL: 25, TEAM: 25, ORG: 100, ENTERPRISE: 9999 };
          const max = limits[tier] || FREE_CUSTOM_PACK_LIMIT;
          if (existing.length >= max) {
            vscode.window.showWarningMessage(
              `SENTRIK: Custom pack limit reached (${existing.length}/${max} on ${tier} tier). Visit sentrik.dev to upgrade.`
            );
            return;
          }
        } catch {
          // Can't verify license — enforce free limit
          vscode.window.showWarningMessage(
            `SENTRIK: Custom pack limit reached (${existing.length}/${FREE_CUSTOM_PACK_LIMIT} on Free tier). Visit sentrik.dev to upgrade.`
          );
          return;
        }
      }
    } catch {
      // Directory read failed — proceed and let CLI enforce
    }
  }

  const packName = await vscode.window.showInputBox({
    prompt: "Name for your custom pack (e.g., my-team-rules)",
    placeHolder: "my-custom-pack",
    validateInput: (v) => /^[a-z0-9][a-z0-9-]*$/.test(v) ? null : "Use lowercase letters, numbers, and hyphens",
  });
  if (!packName) return;

  const packConfig = vscode.workspace.getConfiguration("sentrik");
  const packDir = packConfig.get<string>("customPacksPath") || path.join(root, ".sentrik", "rules");

  // Ensure directory exists
  if (!fs.existsSync(packDir)) {
    fs.mkdirSync(packDir, { recursive: true });
  }

  const filePath = path.join(packDir, `${packName}.yaml`);
  if (fs.existsSync(filePath)) {
    vscode.window.showWarningMessage(`Pack file already exists: ${packName}.yaml`);
    const doc = await vscode.workspace.openTextDocument(filePath);
    await vscode.window.showTextDocument(doc);
    return;
  }

  const template = `# pack: ${packName}
# Custom standards pack for Sentrik
# Docs: https://docs.sentrik.dev/custom-rules/

rules:
  - id: ${packName}-001
    name: "Example rule"
    description: "Describe what this rule checks"
    severity: medium          # critical | high | medium | low | info
    type: regex               # regex | required_pattern | file_policy | ast | documentation_obligation
    standard: "Internal"
    clause: "1.1"
    languages:
      - python
      - javascript
      - typescript
      - cpp
      - c
    pattern: "TODO|FIXME|HACK"
    suggestion: "Resolve TODO comments before merging"

  # --- More rule examples ---
  #
  # Required pattern (fail if missing):
  # - id: ${packName}-002
  #   name: "Copyright header required"
  #   type: required_pattern
  #   severity: low
  #   pattern: "Copyright \\\\(c\\\\)"
  #   file_patterns: ["*.cpp", "*.c", "*.h", "*.hpp"]
  #   suggestion: "Add a copyright header to the file"
  #
  # C/C++ specific rule:
  # - id: ${packName}-003
  #   name: "No malloc in C++ code"
  #   type: regex
  #   severity: high
  #   languages: [cpp]
  #   pattern: "\\\\bmalloc\\\\s*\\\\("
  #   suggestion: "Use new/std::make_unique instead of malloc in C++ code"
  #
  # File policy:
  # - id: ${packName}-004
  #   name: "File length limit"
  #   type: file_policy
  #   severity: medium
  #   check: max_lines
  #   params:
  #     max_lines: 500
  #   suggestion: "Split large files into smaller modules"
`;

  fs.writeFileSync(filePath, template, "utf-8");
  const doc = await vscode.workspace.openTextDocument(filePath);
  await vscode.window.showTextDocument(doc);
  vscode.window.showInformationMessage(`SENTRIK: Custom pack "${packName}" created. Edit the rules and save to apply.`);
  refreshPacks();
}

// ---------------------------------------------------------------------------
// Open Dashboard
// ---------------------------------------------------------------------------

function openDashboard(): void {
  const root = getWorkspaceRoot();
  if (!root) {
    vscode.window.showWarningMessage("SENTRIK: No workspace folder open");
    return;
  }

  const binary = discoverBinary();
  const port = 8000;

  // If panel already exists, just bring it to front
  if (dashboardPanel) {
    dashboardPanel.reveal(vscode.ViewColumn.One);
    return;
  }

  // Check if dashboard server is already running
  /* http imported at top */
  const checkReq = http.get(`http://localhost:${port}/api/metrics`, (res) => {
    if (res.statusCode === 200) {
      // Already running — just open panel
      _openDashboardWindow(port);
    } else {
      _startAndOpenDashboard(binary, root, port);
    }
  });
  checkReq.on("error", () => {
    _startAndOpenDashboard(binary, root, port);
  });
  checkReq.setTimeout(2000, () => {
    checkReq.destroy();
    _startAndOpenDashboard(binary, root, port);
  });
}

async function _startAndOpenDashboard(binary: string, root: string, port: number): Promise<void> {
  outputChannel.appendLine(`Starting dashboard: ${binary} dashboard --no-open --port ${port}`);

  // Use VS Code's Terminal API rather than cp.spawn().
  // The extension host process has a restricted PATH that doesn't include the
  // user's Python Scripts directory, so cp.spawn("sentrik", ...) always produces
  // ENOENT. A terminal inherits the user's full login shell environment — PATH,
  // venvs, conda, etc. — so "sentrik" resolves correctly regardless of where it
  // was installed. hideFromUser keeps it invisible while still running.
  dashboardTerminal?.dispose();
  // On Windows, force cmd.exe so we avoid PowerShell's quoting rules
  // (PowerShell requires `& "path"` to invoke a quoted executable; cmd.exe does not).
  const shellPath = process.platform === "win32" ? "cmd.exe" : undefined;

  // Pass LLM env vars (including Copilot proxy URL) so the dashboard server
  // and any commands it spawns can use the configured AI provider.
  const llmEnv = await buildScanEnv();

  dashboardTerminal = vscode.window.createTerminal({
    name: "SENTRIK Dashboard",
    cwd: root,
    hideFromUser: true,
    shellPath,
    env: llmEnv,
  });

  // Quote the binary path in case it contains spaces
  const quotedBinary = binary.includes(" ") ? `"${binary}"` : binary;
  dashboardTerminal.sendText(`${quotedBinary} dashboard --no-open --port ${port}`);

  // Show progress notification while waiting for the server to start
  vscode.window.withProgress(
    {
      location: vscode.ProgressLocation.Notification,
      title: "SENTRIK: Starting dashboard...",
      cancellable: true,
    },
    (progress, token) => new Promise<void>((resolve) => {
      let attempts = 0;
      const maxAttempts = 60;

      token.onCancellationRequested(() => {
        clearInterval(check);
        dashboardTerminal?.dispose();
        dashboardTerminal = undefined;
        resolve();
      });

      const check = setInterval(() => {
        attempts++;
        progress.report({ message: `(${attempts}s)` });

        const req = http.get(`http://localhost:${port}/api/metrics`, (res) => {
          if (res.statusCode === 200) {
            clearInterval(check);
            _openDashboardWindow(port);
            outputChannel.appendLine("Dashboard started successfully");
            resolve();
          }
          res.resume();
        });
        req.on("error", () => {
          if (attempts >= maxAttempts) {
            clearInterval(check);
            // Show the terminal so the user can see what went wrong
            dashboardTerminal?.show();
            vscode.window.showErrorMessage(
              "SENTRIK: Dashboard failed to start. Check the terminal for errors.",
              "Show Terminal"
            ).then(choice => {
              if (choice === "Show Terminal") {
                dashboardTerminal?.show();
              }
            });
            outputChannel.appendLine("Dashboard failed to start after 60 attempts");
            resolve();
          }
        });
        req.setTimeout(1500, () => req.destroy());
      }, 1000);
    })
  );
}

function _openDashboardWindow(port: number): void {
  const dashboardUrl = `http://localhost:${port}/dashboard?mode=extension`;
  outputChannel.appendLine(`Opening dashboard: ${dashboardUrl}`);

  // Reuse existing panel if it's still open
  if (dashboardPanel) {
    dashboardPanel.reveal(vscode.ViewColumn.One);
    dashboardPanel.webview.html = _dashboardHtml(dashboardUrl);
    return;
  }

  dashboardPanel = vscode.window.createWebviewPanel(
    "sentrikDashboard",
    "Sentrik",
    vscode.ViewColumn.One,
    {
      enableScripts: true,
      retainContextWhenHidden: true,
    }
  );

  dashboardPanel.webview.html = _dashboardHtml(dashboardUrl);

  dashboardPanel.onDidDispose(() => {
    dashboardPanel = undefined;
  });
}

function _dashboardHtml(url: string): string {
  return `<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta http-equiv="Content-Security-Policy" content="default-src * 'unsafe-inline' 'unsafe-eval'; frame-src *;">
  <style>
    html, body { margin: 0; padding: 0; width: 100%; height: 100vh; overflow: hidden; background: #1a1a2e; }
    iframe { width: 100%; height: 100%; border: none; display: block; }
  </style>
</head>
<body>
  <iframe src="${url}" sandbox="allow-scripts allow-same-origin allow-forms allow-popups allow-modals"></iframe>
</body>
</html>`;
}

// ---------------------------------------------------------------------------
// Apply diagnostics
// ---------------------------------------------------------------------------

function applyDiagnostics(root: string, findings: Finding[]): void {
  diagnosticCollection.clear();
  const severityFilter = getSeverityFilter();

  const byFile = new Map<string, Finding[]>();
  for (const f of findings) {
    if (!severityFilter.has(f.severity)) continue;
    const filePath = f.evidence.file;
    if (!byFile.has(filePath)) {
      byFile.set(filePath, []);
    }
    byFile.get(filePath)!.push(f);
  }

  for (const [filePath, fileFindings] of byFile) {
    const absPath = path.isAbsolute(filePath)
      ? filePath
      : path.join(root, filePath);
    const uri = vscode.Uri.file(absPath);
    const diagnostics: vscode.Diagnostic[] = [];

    for (const f of fileFindings) {
      const line = f.evidence.lines[0] ? f.evidence.lines[0] - 1 : 0;
      const range = new vscode.Range(line, 0, line, 200);
      const severity =
        SEVERITY_MAP[f.severity] ?? vscode.DiagnosticSeverity.Warning;

      const diagnostic = new vscode.Diagnostic(range, f.message, severity);
      diagnostic.source = "sentrik";
      diagnostic.code = f.rule_id;

      if (f.suggestion || f.remediation_guidance) {
        const hint = f.suggestion || f.remediation_guidance || "";
        diagnostic.message += `\n\nFix: ${hint}`;
      }

      diagnostics.push(diagnostic);
    }

    diagnosticCollection.set(uri, diagnostics);
  }
}
