#!/usr/bin/env bash
# SPDX-FileCopyrightText: (C) 2022 user4223 and (other) contributors to ticket-decoder <https://github.com/user4223/ticket-decoder>
# SPDX-License-Identifier: GPL-3.0-or-later

set -o errexit

readonly WORKSPACE_ROOT="$(readlink -f $(dirname "$0"))"/..

# curl --output ${WORKSPACE_ROOT}/cert/UIC_PublicKeys.xml \
#     --show-error --fail 'https://railpublickey.uic.org/download.php'

readonly DESTINATION_FILE="${WORKSPACE_ROOT}/cert/UIC_PublicKeys.xml"

if [ -f ${DESTINATION_FILE} ]; then
    readonly DATE=$(date +%F)
    cp ${DESTINATION_FILE} "${WORKSPACE_ROOT}/cert/UIC_PublicKeys_before_${DATE}.xml"
fi

wget -nv -O ${DESTINATION_FILE} 'https://railpublickey.uic.org/download.php'
