// SPDX-FileCopyrightText: (C) 2022 user4223 and (other) contributors to ticket-decoder <https://github.com/user4223/ticket-decoder>
// SPDX-License-Identifier: GPL-3.0-or-later

#pragma once

#include "lib/decoder/api/include/Decoder.h"

#include "lib/infrastructure/include/ContextFwd.h"
#include "lib/infrastructure/include/DebugController.h"

#include <opencv2/core.hpp>

#include <memory>

namespace decoder::detail
{
  class ZxingDecoder : public api::Decoder
  {
    infrastructure::DebugController &debugController;
    struct Internal;
    std::shared_ptr<Internal> internal;

  public:
    ZxingDecoder(infrastructure::Context &context, api::DecoderOptions defaultOptions);

    virtual api::Result decode(detector::api::Descriptor const &descriptor) override;

    virtual api::Result decode(unsigned int id, cv::Rect const &box, cv::Mat const &image) override;
  };
}
