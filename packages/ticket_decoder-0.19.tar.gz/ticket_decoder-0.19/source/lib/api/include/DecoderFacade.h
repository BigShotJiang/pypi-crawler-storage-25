// SPDX-FileCopyrightText: (C) 2022 user4223 and (other) contributors to ticket-decoder <https://github.com/user4223/ticket-decoder>
// SPDX-License-Identifier: GPL-3.0-or-later

#pragma once

#include <lib/infrastructure/include/ParameterSupplier.h>
#include <lib/infrastructure/include/ParameterCollector.h>
#include <lib/infrastructure/include/ContextFwd.h>

#include <lib/input/api/include/InputElement.h>
#include <lib/input/api/include/LoadResult.h>

#include <lib/detector/api/include/DetectorType.h>
#include <lib/detector/api/include/Result.h>
#include <lib/decoder/api/include/Result.h>

#include <memory>
#include <string>
#include <filesystem>
#include <vector>
#include <functional>
#include <iterator>

namespace utility
{
    class DebugController;
}

namespace dip
{
    class PreProcessor;
}

namespace api
{
    class DecoderFacade;

    class DecoderFacadeBuilder
    {
        infrastructure::Context &context;
        struct Options;
        std::shared_ptr<Options> options; // unfortunately, forward declaration works with shared_ptr only, but not with unique_ptr

        /* Use DecoderFacade::create for creation instead of this ctor!
         */
        DecoderFacadeBuilder(infrastructure::Context &context);

    public:
        friend DecoderFacade;
        DecoderFacadeBuilder(DecoderFacadeBuilder const &) = delete;
        DecoderFacadeBuilder(DecoderFacadeBuilder &&) = delete;
        DecoderFacadeBuilder &operator=(DecoderFacadeBuilder const &) = delete;
        DecoderFacadeBuilder &operator=(DecoderFacadeBuilder &&) = delete;

        DecoderFacadeBuilder &withPreProcessorResultVisitor(std::function<void(input::api::InputElement const &)> visitor);

        DecoderFacadeBuilder &withDetectorResultVisitor(std::function<void(detector::api::Result const &)> visitor);

        DecoderFacadeBuilder &withDecoderResultVisitor(std::function<void(decoder::api::Result const &)> visitor);

        DecoderFacadeBuilder &withInterpreterResultVisitor(std::function<void(std::string const &)> visitor);

        DecoderFacadeBuilder &withAsynchronousLoad(bool loadAsynchronously);

        DecoderFacadeBuilder &withFailOnDecoderError(bool failOnDecoderError);

        DecoderFacadeBuilder &withFailOnInterpreterError(bool failOnInterpreterError);

        DecoderFacadeBuilder &withDpiOnLoad(int dpi);

        DecoderFacadeBuilder &withDetector(detector::api::DetectorType type);

        DecoderFacadeBuilder &withUicPublicKeyXmlFile(std::filesystem::path uicPublicKeyXmlFile);

        DecoderFacadeBuilder &withVdvCertificateLdifFile(std::filesystem::path vdvCertificateLdifFile);

        DecoderFacadeBuilder &withPureBarcode(bool pureBarcode);

        DecoderFacadeBuilder &withLocalBinarizer(bool localBinarizer);

        DecoderFacadeBuilder &withImageRotation(int rotationDegree);

        DecoderFacadeBuilder &withImageScale(unsigned int scalePercent);

        DecoderFacadeBuilder &withImageSplit(std::string split);

        DecoderFacadeBuilder &withImageFlipping(unsigned int flippingMode);

        DecoderFacadeBuilder &withJsonIndent(int indent);

        DecoderFacadeBuilder &withClassifierFile(std::filesystem::path classifierFile);

        DecoderFacade build();
    };

    class DecoderFacade : public infrastructure::ParameterSupplier, public infrastructure::ParameterCollector
    {
        struct Internal;
        std::shared_ptr<Internal> internal;
        DecoderFacadeBuilder::Options const &options;

        template <typename T>
        void decodeImage(input::api::InputElement image, std::function<void(T &&, std::string)> transformer);

        template <typename T>
        void decodeImageFiles(std::filesystem::path path, std::function<void(T &&, std::string)> transformer);

        std::string interpretRawBytes(std::vector<std::uint8_t> bytes, std::string origin);

        /* Use DecoderFacade::create for creation instead of this ctor!
         */
        DecoderFacade(infrastructure::Context &context, std::shared_ptr<DecoderFacadeBuilder::Options> options);

    public:
        friend DecoderFacadeBuilder;
        DecoderFacade(DecoderFacade const &) = delete;
        DecoderFacade(DecoderFacade &&) = delete;
        DecoderFacade &operator=(DecoderFacade const &) = delete;
        DecoderFacade &operator=(DecoderFacade &&) = delete;

        static DecoderFacadeBuilder create(infrastructure::Context &context);

        dip::PreProcessor &getPreProcessor();

        /* Load all supported elements synchronously/asynchronously from given file/directory
         */
        input::api::LoadResult loadSupportedFiles(std::filesystem::path path);

        /* Aztec code detector handling
         */
        std::vector<detector::api::DetectorType> getSupportetDetectorTypes() const;

        std::string setDetectorType(detector::api::DetectorType type);

        detector::api::DetectorType getDetectorType() const;

        /* Raw uic918 input from file, byte-array or base64-string to json
         */
        std::string decodeRawFileToJson(std::filesystem::path filePath);

        std::string decodeRawBytesToJson(std::vector<std::uint8_t> rawData, std::string origin = "");

        std::string decodeRawBase64ToJson(std::string base64RawData, std::string origin = "");

        /* Barcodes from image or PDF input file/directory to json, raw byte-array or raw base64-string
         */
        std::vector<std::pair<std::string, std::string>> decodeImageFilesToJson(std::filesystem::path path);

        std::vector<std::pair<std::string, std::vector<std::uint8_t>>> decodeImageFilesToRawBytes(std::filesystem::path path);

        std::vector<std::pair<std::string, std::string>> decodeImageFilesToRawBase64(std::filesystem::path path);

        /* Pre-loaded image data as input-element to json
         */
        std::vector<std::string> decodeImageToJson(input::api::InputElement image);

        ParameterTypeList supplyParameters() const;
    };
}
