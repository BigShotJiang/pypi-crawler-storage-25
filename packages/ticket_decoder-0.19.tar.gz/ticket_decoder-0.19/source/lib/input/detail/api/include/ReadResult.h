// SPDX-FileCopyrightText: (C) 2022 user4223 and (other) contributors to ticket-decoder <https://github.com/user4223/ticket-decoder>
// SPDX-License-Identifier: GPL-3.0-or-later

#pragma once

#include <opencv2/core.hpp>

#include <vector>

namespace input::detail
{
  class ReadResult
  {
    std::vector<cv::Mat> images;

    void ensureNoMultipart() const;

  public:
    ReadResult(cv::Mat &&image);
    ReadResult(std::vector<cv::Mat> &&images);

    ReadResult(ReadResult const &) = delete;
    ReadResult(ReadResult &&) = default;
    ReadResult &operator=(ReadResult const &) = delete;
    ReadResult &operator=(ReadResult &&) = default;

    /* Returns true when the read file contained more than one image and
       multiple images has been loaded, this could be the case e.g. for multi-page PDF files.
     */
    bool isMultiPart() const;

    /* Returns just the image in case of isMultiPart() == false
       and throws std::runtime_error in case of isMultiPart() == true
     */
    cv::Mat getImage();

    /* Returns/moves out the image, similar to getImage() but after
       this call the image not hold by this class anymore. So do not call
       it twice.
    */
    cv::Mat consumeImage();

    /* Returns a list of images loaded from file. In most cases a
       list of size 1, but e.g. in case of multi-page PDF files, each
       page results in one separated image.
     */
    std::vector<cv::Mat> getImages();

    std::vector<cv::Mat> consumeImages();
  };
}
