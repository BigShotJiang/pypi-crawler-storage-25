from opentelemetry import trace
from opentelemetry.trace import Status, StatusCode
from puvinoise.env_keys import get_agent_id
from puvinoise.context import AgentContext
from puvinoise.trace_context import TraceContext
import os
import uuid
from importlib.metadata import version as _pkg_version

_tracer = trace.get_tracer("agent.runtime")


def record_context(context_type: str, content: str, source_span_id: str = None):
    """
    Attach context metadata to the current active span.
    Used for RAG/memory/tool/MCP context graph generation.
    """
    span = trace.get_current_span()
    if not span or not span.is_recording():
        return
    try:
        span.set_attribute("context.type", str(context_type))
        span.set_attribute("context.content", str(content)[:2000])
        if source_span_id:
            span.set_attribute("context.source_span_id", str(source_span_id))
    except Exception:
        # Never allow telemetry helpers to break agent execution
        pass


def start_trace(session_id: str) -> TraceContext:
    """
    Create explicit trace context owned by the SDK.

    Args:
        session_id: Session/conversation identifier for this trace.

    Returns:
        TraceContext containing SDK-generated trace_id and provided session_id.
    """
    return TraceContext(trace_id=f"trace-{uuid.uuid4().hex}", session_id=str(session_id))


def validate_bi_contract(ctx):
    required = ["scenario", "intent", "goal", "success"]
    metadata = getattr(ctx, "metadata", {}) or {}
    missing = [k for k in required if not metadata.get(k)]

    if missing:
        print("BI_SDK_CONTRACT_FAIL", missing)


def _parse_version(v: str):
    out = []
    for part in str(v or "").split("."):
        digits = "".join(ch for ch in part if ch.isdigit())
        out.append(int(digits) if digits else 0)
    return tuple(out)


def _installed_puvinoise_distribution_version():
    """Installed wheel/sdist version; PyPI name is puvinoise-sdk."""
    for dist in ("puvinoise-sdk", "puvinoise"):
        try:
            return _pkg_version(dist)
        except Exception:
            continue
    return None


def _sdk_version_warning_if_mismatch():
    required = (os.getenv("PUVINOISE_SDK_VERSION") or "").strip()
    if not required:
        return None
    current = _installed_puvinoise_distribution_version()
    if not current:
        print("PUVINOISE_SDK_VERSION_WARN", {"required": required, "current": "unknown"})
        return None
    if _parse_version(current) < _parse_version(required):
        print("PUVINOISE_SDK_VERSION_WARN", {"required": required, "current": current})
    return current


def run_with_trace(
    fn,
    ctx=None,
    session_id=None,
    agent_name=None,
    goal=None,
    task_type=None,
    *args,
    **kwargs,
):
    """
    Wraps a function execution with OpenTelemetry tracing and agent context.
    Optional goal, task_type, intent, session_id, turn_index, message_id are set for decision telemetry.
    If outcome is provided (success|failure|timeout|cancelled|partial), it is set on the root span after the run.

    Args:
        fn: The function to execute
        agent_name: Name of the agent (defaults to env PUVINOISE_AGENT_NAME)
        goal: Optional goal string (decision telemetry)
        task_type: Optional task type (decision telemetry)
        intent: Optional intent classification (decision telemetry)
        session_id: Optional session/conversation ID (decision telemetry envelope)
        turn_index: Optional 1-based turn number in session (decision telemetry envelope)
        message_id: Optional request/message ID (decision telemetry envelope)
        outcome: Optional explicit trace outcome: success|failure|timeout|cancelled|partial
        outcome_reason: Optional short reason for outcome
        *args, **kwargs: Arguments to pass to the function
    """
    # Backward-compatible optional params from kwargs.
    sdk_version_current = _sdk_version_warning_if_mismatch()
    intent = kwargs.get("intent")
    turn_index = kwargs.get("turn_index")
    message_id = kwargs.get("message_id")
    outcome = kwargs.get("outcome")
    outcome_reason = kwargs.get("outcome_reason")
    if goal is None:
        goal = kwargs.get("goal")
    if task_type is None:
        task_type = kwargs.get("task_type")

    # Backward-compatible trace context handling:
    # - If explicit ctx is provided, prefer its session_id.
    # - If ctx is missing, fallback to SDK-generated context.
    if ctx is None:
        if session_id is None:
            session_id = "default-session"
        ctx = start_trace(session_id=session_id)
    elif session_id is None:
        session_id = getattr(ctx, "session_id", None)

    # Ensure metadata envelope exists on trace context (backward safe).
    if not hasattr(ctx, "metadata") or ctx.metadata is None:
        ctx.metadata = {}
    elif not isinstance(ctx.metadata, dict):
        try:
            ctx.metadata = dict(ctx.metadata)
        except Exception:
            ctx.metadata = {}

    env_agent_name = os.getenv("PUVINOISE_AGENT_NAME", "").strip()
    name = (agent_name or env_agent_name or "default-agent").strip()

    # Keep agent identity on ctx so metadata inference can use it.
    if not getattr(ctx, "agent_name", None):
        ctx.agent_name = name
    if not getattr(ctx, "agent_id", None):
        # agent_id must be the canonical agt_xxx from PUVINOISE_AGENT_ID — NEVER fall back to name.
        ctx.agent_id = get_agent_id() or ""

    # Scenario (existing enrichment behavior): kwargs -> agent_name -> agent_id -> unknown
    if not ctx.metadata.get("scenario"):
        scenario_value = (
            kwargs.get("scenario")
            or getattr(ctx, "agent_name", None)
            or getattr(ctx, "agent_id", None)
            or "unknown"
        )
        ctx.metadata["scenario"] = str(scenario_value)

    # Intent enrichment: kwargs["intent"] -> fn.__name__ -> unknown_intent
    if not ctx.metadata.get("intent"):
        fn_name = getattr(fn, "__name__", None)
        intent_value = kwargs.get("intent") or intent or fn_name or "unknown_intent"
        ctx.metadata["intent"] = str(intent_value)

    # Goal enrichment: kwargs["goal"] -> default_goal
    if not ctx.metadata.get("goal"):
        goal_value = kwargs.get("goal") or goal or "default_goal"
        ctx.metadata["goal"] = str(goal_value)

    # Optimistic success so exported spans include metadata.success before fn() returns (helps BI ingestion).
    if ctx.metadata.get("success") is None:
        ctx.metadata["success"] = True

    agent_ctx = AgentContext(
        name,
        goal=goal,
        task_type=task_type,
        intent=intent,
        session_id=session_id,
        turn_index=turn_index,
        message_id=message_id,
    )
    agent_ctx.activate()

    # Emit env-derived params as span attributes so collector/backend can filter and display
    tenant_id = (
        os.getenv("PUVINOISE_TENANTID")
        or ""
    ).strip()
    if tenant_id.lower() == "your-tenant-id":
        tenant_id = ""
    llm_provider = (os.getenv("CUST_LLM_PROVIDER") or "").strip()

    # STRICT: agent.id MUST be on every span.
    # The normalizer returns null (DROPS the trace) for any span missing agent.id.
    # Validate here — before the span is opened — so the error is raised at call time
    # rather than silently producing a trace that will be discarded at ingest.
    _span_agent_id = (os.getenv("PUVINOISE_AGENT_ID") or "").strip()
    if not _span_agent_id:
        raise RuntimeError(
            "PUVINOISE_AGENT_ID is not set. "
            "Call puvinoise.bootstrap() or puvinoise.init(agent_id='agt_xxx') before running traces. "
            "The normalizer DROPS every trace whose agent.run span is missing the agent.id tag."
        )

    with _tracer.start_as_current_span("agent.run") as span:
        try:
            from puvinoise.decision_telemetry import record_agent_state_transition
            record_agent_state_transition("idle", "running", "sdk_run_with_trace")
        except Exception:
            pass
        span.set_attribute("agent.run_id", agent_ctx.run_id)
        span.set_attribute("agent.name", agent_ctx.agent_name)
        span.set_attribute("trace.id", str(getattr(ctx, "trace_id", ""))[:200])
        span.set_attribute("tenant.id", tenant_id)
        # _span_agent_id validated non-empty above — always set unconditionally.
        span.set_attribute("agent.id", _span_agent_id)
        if getattr(agent_ctx, "_session_id", None):
            span.set_attribute("session.id", str(agent_ctx._session_id)[:200])
        if llm_provider:
            span.set_attribute("puvinoise.llm_provider", llm_provider)
            span.set_attribute("llm.provider", llm_provider)
        if sdk_version_current:
            span.set_attribute("puvinoise.sdk.version", str(sdk_version_current))
            span.set_attribute("PUVINOISE_SDK_VERSION", str(sdk_version_current))
        if getattr(agent_ctx, "_goal", None):
            span.set_attribute("agent.goal", str(agent_ctx._goal)[:500])
        if getattr(agent_ctx, "_task_type", None):
            span.set_attribute("agent.task_type", str(agent_ctx._task_type)[:200])
            span.set_attribute("agent.task", str(agent_ctx._task_type)[:200])
        if getattr(agent_ctx, "_intent", None):
            span.set_attribute("agent.intent", str(agent_ctx._intent)[:200])

        # --- PROPAGATE METADATA TO SPAN ---
        if ctx.metadata:
            scenario_meta = ctx.metadata.get("scenario")
            intent_meta = ctx.metadata.get("intent")
            goal_meta = ctx.metadata.get("goal")
            success_meta = ctx.metadata.get("success")

            if scenario_meta:
                span.set_attribute("metadata.scenario", str(scenario_meta))
                span.set_attribute("scenario", str(scenario_meta))

            if intent_meta:
                span.set_attribute("metadata.intent", str(intent_meta))

            if goal_meta:
                span.set_attribute("metadata.goal", str(goal_meta))

            if success_meta is not None:
                span.set_attribute("metadata.success", str(success_meta))

            # Also emit direct keys for safety.
            span.set_attribute("agent.intent", str(ctx.metadata.get("intent", "")))
            span.set_attribute("agent.goal", str(ctx.metadata.get("goal", "")))
        # --- END PROPAGATION ---
        if turn_index is not None:
            span.set_attribute("decision.turn_index", int(turn_index))
        if message_id is not None:
            span.set_attribute("decision.message_id", str(message_id)[:200])

        deploy_env = (os.getenv("PUVINOISE_DEPLOY_ENV") or "").strip()
        if deploy_env:
            span.set_attribute("deployment.environment", deploy_env)
        else:
            print("[PUVINoise] WARNING: missing PUVINOISE_DEPLOY_ENV; deployment.environment not emitted.")

        deploy_version = (os.getenv("PUVINOISE_DEPLOY_VERSION") or "").strip()
        if deploy_version:
            span.set_attribute("deployment.version", deploy_version[:50])
        else:
            print("[PUVINoise] WARNING: missing PUVINOISE_DEPLOY_VERSION; deployment.version not emitted.")

        deploy_region = (os.getenv("PUVINOISE_REGION") or "").strip()
        if deploy_region:
            span.set_attribute("puvinoise.region", deploy_region[:128])
        else:
            print("[PUVINoise] WARNING: missing PUVINOISE_REGION; puvinoise.region not emitted.")

        _deploy_label = (os.getenv("PUVINOISE_DEPLOY_LABEL") or "current").strip()[:64]
        span.set_attribute("deployment.label", _deploy_label)

        error_occurred = False
        try:
            # Execute the function (pop decision-telemetry keys so they are not passed to fn)
            kwargs_for_fn = {
                k: v
                for k, v in kwargs.items()
                if k
                not in (
                    "goal",
                    "task_type",
                    "intent",
                    "turn_index",
                    "message_id",
                    "outcome",
                    "outcome_reason",
                    "ctx",
                )
            }
            result = fn(*args, **kwargs_for_fn)
            ctx.metadata["success"] = True
            if span.is_recording():
                span.set_attribute("metadata.success", str(ctx.metadata["success"]))
            # Set OK before return so Jaeger and PUViNoise both see success (status + tag)
            if span.is_recording():
                span.set_status(Status(StatusCode.OK))
                span.set_attribute("otel.status_code", "OK")
            return result

        except Exception as e:
            error_occurred = True
            ctx.metadata["success"] = False
            if span.is_recording():
                span.set_attribute("metadata.success", str(ctx.metadata["success"]))
            span.set_status(Status(StatusCode.ERROR, str(e)))
            span.set_attribute("otel.status_code", "ERROR")
            span.record_exception(e)
            try:
                from puvinoise.decision_telemetry import record_task_completed, set_trace_outcome
                set_trace_outcome("failure", reason=str(e)[:200])
                record_task_completed(False)
            except Exception:
                pass
            raise

        finally:
            validate_bi_contract(ctx)
            # Ensure OK is set if we didn't raise (e.g. edge cases)
            if not error_occurred and span.is_recording():
                span.set_status(Status(StatusCode.OK))
                span.set_attribute("otel.status_code", "OK")
                try:
                    from puvinoise.decision_telemetry import record_task_completed, set_trace_outcome
                    set_trace_outcome("success")
                    record_task_completed(True)
                except Exception:
                    pass
            if outcome is not None and span.is_recording():
                span.set_attribute("decision.trace_outcome", str(outcome)[:50])
                if outcome_reason is not None:
                    span.set_attribute("decision.trace_outcome_reason", str(outcome_reason)[:200])