"""
agent_state.py — Two-layer identity state management for PUVINoise.

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
FINAL DATA CONTRACT  (v1.0)
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

.puvinoise/env.json  — environment-level, written by puvinoise-bind --env-only
──────────────────────────────────────────────────────────────────
REQUIRED  version      str  "1.0"
REQUIRED  env_id       str  "env_xxxxxxxxxxxxxxxx"
REQUIRED  base_url     str  "https://app.puvilabs.com"
REQUIRED  created_at   str  ISO-8601 UTC ("2026-04-22T10:00:00Z")
MUST NOT  api_key       — credentials belong ONLY in agent_<id>.json
MUST NOT  agent_id      — runtime identity belongs ONLY in agent_<id>.json
MUST NOT  tenant_id     — tenant attribution belongs ONLY in agent_<id>.json
MUST NOT  runtime_*     — no runtime state here

.puvinoise/agent_<id>.json  — agent-level, written on first SDK run / auto-register
──────────────────────────────────────────────────────────────────
REQUIRED  version        str  "1.0"
REQUIRED  agent_id       str  "agt_xxxxxxxxxxxxxxxx"
REQUIRED  env_id         str  — must match env.json:env_id
REQUIRED  base_url       str  — must match env.json:base_url
REQUIRED  api_key        str  — MANDATORY; SDK will not init without this
REQUIRED  tenant_id      str  — scopes telemetry to the correct tenant
REQUIRED  agent_name     str  — canonical name used for registration
REQUIRED  status         str  "active"
REQUIRED  registered_at  str  ISO-8601 UTC
REQUIRED  sdk_version    str  e.g. "0.3.4"
OPTIONAL  last_used_at   str  ISO-8601 UTC  (updated each run)

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
IDENTITY RESOLUTION  (STRICT — no env-var fallback)
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

    load_identity(workdir):
        1. agent state  → .puvinoise/agent_<id>.json   (authoritative — wins if present)
        2. env state    → .puvinoise/env.json           (bootstrap-only fallback)
        3. RuntimeError → explicit, actionable message

    Resolution is FILES-ONLY.  No env-var fallback at any layer.
    If PUVINOISE_* env vars are present → warn and ignore.

VALIDATION  (enforced by validate_agent_state / validate_env_state)
──────────────────────────────────────────────────────────────────
• env.json            required fields present; api_key / agent_id absent.
• agent_<id>.json     required fields present; api_key non-empty.
• Cross-file check    agent_<id>.env_id  == env.json:env_id
                      agent_<id>.base_url == env.json:base_url

Legacy files (.puvinoise_env.json, .puvinoise_bind_state.json) are NOT read.
No silent failures — every write is validated with _verify_exists().

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
PUBLIC API
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

STATE_FORMAT_VERSION
ENV_STATE_REQUIRED_FIELDS
AGENT_STATE_REQUIRED_FIELDS
AGENT_STATE_FORBIDDEN_IN_ENV

get_agent_state_dir(base)                       → Path
get_env_state_path(base)                        → Path
get_agent_state_path(base, agent_id)            → Path

save_env_state(env_id, base_url, workdir, *,
               created_at)                      → Path   (raises RuntimeError on failure)
load_env_state(workdir)                         → (dict, Path | None)
validate_env_state(workdir)                     → None   (raises ValueError on contract violation)

save_agent_state(agent_id, env_id, base_url, workdir, *,
                 api_key, tenant_id, agent_name, status,
                 registered_at, sdk_version,
                 last_used_at)                  → Path   (raises RuntimeError on failure)
load_agent_state(workdir, agent_id=None)        → (dict, Path | None)
validate_agent_state(workdir)                   → None   (raises ValueError on contract violation)

load_identity(workdir)                          → dict   (raises RuntimeError if not init'd)
find_all_agent_states(base)                     → [Path]
invalidate_agent_state(workdir)                 → bool   (deletes agent_<id>.json, True on success)
"""

from __future__ import annotations

import json
import logging
import os
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

logger = logging.getLogger("puvinoise.agent_state")

# ─── Constants ────────────────────────────────────────────────────────────────

STATE_FORMAT_VERSION = "1.0"

# Sub-directory created inside the agent working directory.
AGENT_STATE_SUBDIR = ".puvinoise"

# Environment-level state file name (bootstrap output).
ENV_STATE_FILENAME = "env.json"

# Glob pattern for per-agent state files.
AGENT_STATE_GLOB = "agent_*.json"

# ─── Contract schemas ─────────────────────────────────────────────────────────

# Fields that MUST be present in a valid env.json.
# Deploy metadata keys (environment/version/region) are intentionally optional and
# may be null when unavailable at bootstrap time.
ENV_STATE_REQUIRED_FIELDS: tuple = ("env_id", "base_url", "created_at")

# Fields that MUST NOT appear in env.json.
# api_key, agent_id → credentials / runtime identity belong ONLY in agent_<id>.json
# tenant_id → ownership attribution belongs ONLY in agent_<id>.json
AGENT_STATE_FORBIDDEN_IN_ENV: tuple = ("api_key", "agent_id", "tenant_id")

# Fields that MUST be present in a valid agent_<id>.json.
AGENT_STATE_REQUIRED_FIELDS: tuple = (
    "version",
    "agent_id",
    "env_id",
    "base_url",
    "api_key",
    "tenant_id",
    "agent_name",
    "status",
    "registered_at",
    "sdk_version",
)


# ─── Path helpers ─────────────────────────────────────────────────────────────


def get_agent_state_dir(base: Path) -> Path:
    """Return the .puvinoise/ directory under *base*."""
    return base / AGENT_STATE_SUBDIR


def get_env_state_path(base: Path) -> Path:
    """Return the canonical environment state file path (.puvinoise/env.json)."""
    return get_agent_state_dir(base) / ENV_STATE_FILENAME


def get_agent_state_path(base: Path, agent_id: str) -> Path:
    """Return the canonical per-agent state file path for *agent_id*."""
    safe_id = (agent_id or "unknown").strip().replace("/", "_").replace("\\", "_")
    return get_agent_state_dir(base) / f"agent_{safe_id}.json"


# ─── Write ────────────────────────────────────────────────────────────────────


def save_env_state(
    env_id: str,
    base_url: str,
    workdir: Path,
    *,
    environment: Optional[str] = None,
    deploy_version: Optional[str] = None,
    region: Optional[str] = None,
    created_at: Optional[str] = None,
) -> Path:
    """
    Write ``.puvinoise/env.json`` with environment identity.

    Written by ``puvinoise-bind --env-only``.
    Required fields: env_id, base_url, created_at.
    Deploy metadata keys are always included and may be null:
    environment, version, region.
    MUST NOT include: api_key, agent_id, tenant_id.

    Credentials and tenant attribution belong EXCLUSIVELY in agent_<id>.json.
    Raises ``RuntimeError`` on any failure — callers MUST NOT swallow this.
    Post-write validation confirms the file exists before returning.
    """
    path = get_env_state_path(workdir)
    _make_state_dir(path.parent)

    _now = datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")
    env_value = (environment or "").strip() or None
    version_value = (deploy_version or "").strip() or None
    region_value = (region or "").strip() or None
    content: Dict[str, Any] = {
        "env_id": env_id,
        "environment": env_value,
        "version": version_value,
        "region": region_value,
        "base_url": base_url.rstrip("/"),
        "created_at": (created_at or _now).strip(),
    }
    _write_json(path, content)
    _verify_exists(path)
    _set_permissions(path)
    abs_path = path.resolve()
    print(f"[puvinoise] wrote file: {abs_path}")
    return abs_path


def save_agent_state(
    agent_id: str,
    env_id: str,
    base_url: str,
    workdir: Path,
    *,
    api_key: Optional[str] = None,
    tenant_id: Optional[str] = None,
    agent_name: Optional[str] = None,
    status: str = "active",
    registered_at: Optional[str] = None,
    sdk_version: Optional[str] = None,
    last_used_at: Optional[str] = None,
) -> Path:
    """
    Write ``.puvinoise/agent_<agent_id>.json`` with full agent identity.

    This file is the AUTHORITATIVE single source of truth for all SDK identity
    resolution.  After this file exists, the SDK NEVER reads env vars for
    credentials or identity — it reads from here exclusively.

    Required fields (contract v1.0):
        version, agent_id, env_id, base_url, api_key, tenant_id,
        agent_name, status, registered_at, sdk_version.

    Optional fields:
        last_used_at  — updated by the SDK on each successful run.

    ``api_key`` MUST be provided — registration without a stored api_key is
    invalid; the SDK will refuse to init on subsequent runs.
    ``tenant_id`` scopes telemetry to the correct tenant in multi-tenant deployments.
    ``agent_name`` is the canonical registration name (normalized slug).
    ``sdk_version`` is detected automatically if not supplied.

    Raises ``RuntimeError`` on any failure — do NOT wrap in a bare except.
    Post-write validation confirms the file exists before returning.
    """
    aid = (agent_id or "unknown").strip()
    path = get_agent_state_path(workdir, aid)
    _make_state_dir(path.parent)

    _now = datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")

    # Detect sdk_version if not supplied.
    if not sdk_version:
        try:
            from importlib.metadata import version as _imv
            sdk_version = str(_imv("puvinoise-sdk"))
        except Exception:
            try:
                import puvinoise as _pv
                sdk_version = str(getattr(_pv, "__version__", "unknown"))
            except Exception:
                sdk_version = "unknown"

    _key = (api_key or "").strip()
    _tid = (tenant_id or "").strip()
    _name = (agent_name or "").strip()

    # HARD FAIL: both api_key and tenant_id are MANDATORY for a valid agent state file.
    # Writing an incomplete file would silently break SDK init on subsequent runs and
    # disable behaviour pipeline attribution.  Callers MUST supply both or the contract fails.
    if not _key:
        raise RuntimeError(
            f"Cannot write agent state for {aid}: api_key is empty.\n"
            "  api_key is MANDATORY — the SDK will not initialise on subsequent runs without it.\n"
            "  Ensure POST /api/agent-register returns agent.apiKey and it is passed here.\n"
            "  Fix: delete .puvinoise/ and re-run 'puvinoise run' after checking your API key."
        )
    if not _tid:
        raise RuntimeError(
            f"Cannot write agent state for {aid}: tenant_id is empty.\n"
            "  tenant_id is MANDATORY — the behaviour pipeline cannot attribute events without it.\n"
            "  Ensure POST /api/agent-register returns agent.tenantId and it is passed here.\n"
            "  Fix: delete .puvinoise/ and re-run 'puvinoise run' after verifying the backend response."
        )

    content: Dict[str, Any] = {
        "version": STATE_FORMAT_VERSION,
        "agent_id": aid,
        "env_id": env_id,
        "base_url": base_url.rstrip("/"),
        "api_key": _key,
        "tenant_id": _tid,
        "status": (status or "active").strip(),
        "registered_at": (registered_at or _now).strip(),
        "sdk_version": (sdk_version or "unknown").strip(),
    }
    if _name:
        content["agent_name"] = _name
    _lused = (last_used_at or "").strip()
    if _lused:
        content["last_used_at"] = _lused
    _write_json(path, content)
    _verify_exists(path)
    _set_permissions(path)
    abs_path = path.resolve()
    print(f"[puvinoise] wrote file: {abs_path}")
    return abs_path


# ─── Read ─────────────────────────────────────────────────────────────────────


def load_env_state(workdir: Path) -> Tuple[Dict[str, Any], Optional[Path]]:
    """
    Load environment state from ``.puvinoise/env.json`` in *workdir*.

    Returns ``(state_dict, path)`` on success, ``({}, None)`` when absent.
    Does NOT walk parent directories — env.json belongs to the agent workdir.
    Does NOT read legacy files.
    """
    path = get_env_state_path(workdir)
    if path.is_file():
        data = _read_json(path)
        if data:
            logger.debug("agent_state: loaded env state from %s", path)
            return data, path
    return {}, None


def _enforce_single_agent_state(state_dir: Path) -> None:
    """
    Enforce the single-agent-per-directory constraint (Contract v1.0, §7).

    Only ONE ``agent_*.json`` file is permitted inside a ``.puvinoise/`` directory.
    Multiple files indicate either a corrupted state or an attempt to run two
    different agents from the same working directory, both of which are unsupported.

    Raises ``RuntimeError`` with an actionable message if the constraint is violated.
    No-op when zero or one file is found.
    """
    if not state_dir.is_dir():
        return
    files = sorted(state_dir.glob(AGENT_STATE_GLOB))
    if len(files) > 1:
        names = ", ".join(f.name for f in files)
        raise RuntimeError(
            f"Identity conflict: multiple agent state files found in {state_dir}:\n"
            f"  {names}\n"
            "Only ONE agent_<id>.json is permitted per working directory.\n"
            "Resolution options:\n"
            "  • Keep only the file for the agent you want to run, delete the others.\n"
            "  • Or reset entirely: rm -rf .puvinoise && puvinoise-bind --env-only"
        )


def load_agent_state(
    workdir: Path,
    agent_id: Optional[str] = None,
) -> Tuple[Dict[str, Any], Optional[Path]]:
    """
    Load agent state from ``.puvinoise/agent_<id>.json`` in *workdir*.

    If *agent_id* is given, looks for the exact file first.
    Otherwise enforces the single-agent constraint and returns the sole file.

    Returns ``(state_dict, path)`` on success, ``({}, None)`` when absent.
    Raises ``RuntimeError`` if multiple agent state files are found.
    Does NOT read legacy files (.puvinoise_env.json etc).
    """
    state_dir = get_agent_state_dir(workdir)
    if not state_dir.is_dir():
        return {}, None

    if agent_id:
        exact = get_agent_state_path(workdir, agent_id)
        if exact.is_file():
            data = _read_json(exact)
            if data:
                logger.debug("agent_state: loaded agent state from %s", exact)
                return data, exact

    # Enforce single-agent constraint before loading.
    _enforce_single_agent_state(state_dir)

    for p in sorted(state_dir.glob(AGENT_STATE_GLOB)):
        data = _read_json(p)
        if data:
            logger.debug("agent_state: loaded agent state from %s", p)
            return data, p

    return {}, None


def load_identity(workdir: Path) -> Dict[str, Any]:
    """
    Deterministic identity resolution.  Agent state overrides env state.

    Resolution order:
      1. ``.puvinoise/agent_*.json``  — agent state (present after first run)
      2. ``.puvinoise/env.json``      — env state (present after bootstrap)
      3. ``RuntimeError``             — neither found; user must run bootstrap

    Rules:
      • No fallback to global environment variables
      • No silent defaults
      • Raises with an explicit, actionable message when identity is missing
    """
    agent_data, agent_path = load_agent_state(workdir)
    if agent_data:
        logger.debug("agent_state: identity resolved from agent state %s", agent_path)
        return agent_data

    env_data, env_path = load_env_state(workdir)
    if env_data:
        logger.debug("agent_state: identity resolved from env state %s", env_path)
        return env_data

    state_dir = get_agent_state_dir(workdir)
    raise RuntimeError(
        "PUVINoise not initialized.\n"
        f"  Expected: {state_dir / ENV_STATE_FILENAME}\n"
        "  Run `puvinoise-bind --env-only` in your agent directory to bootstrap the environment.\n"
        "  After bootstrap, run `puvinoise run <command>` to start the agent."
    )


# ─── Discovery ────────────────────────────────────────────────────────────────


def find_all_agent_states(base: Path) -> List[Path]:
    """Return all ``.puvinoise/agent_*.json`` files directly under *base*."""
    state_dir = get_agent_state_dir(base)
    if not state_dir.is_dir():
        return []
    return sorted(state_dir.glob(AGENT_STATE_GLOB))


def invalidate_agent_state(workdir: Path) -> bool:
    """
    Delete ``agent_<id>.json`` from *workdir* and log an actionable message.

    Called when the platform returns HTTP 401 — the stored api_key is invalid
    and the agent must re-register to obtain a fresh one.

    Returns ``True`` if a file was found and deleted; ``False`` if nothing was found.
    Never raises — deletion failures are logged but do not crash the caller.
    """
    state_dir = get_agent_state_dir(workdir)
    files = sorted(state_dir.glob(AGENT_STATE_GLOB)) if state_dir.is_dir() else []
    if not files:
        logger.warning(
            "agent_state: invalidate requested but no agent_<id>.json found in %s", state_dir
        )
        return False

    deleted = False
    for f in files:
        try:
            f.unlink()
            logger.error(
                "agent_state: INVALIDATED %s — credentials rejected by platform (HTTP 401)", f
            )
            import sys as _sys
            _sys.stderr.write(
                f"[puvinoise] CREDENTIALS INVALID — {f.name} has been deleted.\n"
                "  Agent credentials were rejected by the platform (HTTP 401).\n"
                "  Re-registration is required before the next run.\n"
                "  Fix: run 'puvinoise run --agent-name <name> python <file>' to re-register.\n"
            )
            _sys.stderr.flush()
            deleted = True
        except OSError as exc:
            logger.error("agent_state: failed to delete %s during invalidation: %s", f, exc)

    return deleted


# ─── Contract validation ──────────────────────────────────────────────────────


def validate_env_state(workdir: Path) -> None:
    """
    Validate ``.puvinoise/env.json`` against the data contract.

    Rules enforced:
      • All ENV_STATE_REQUIRED_FIELDS must be present and non-empty.
      • No field in AGENT_STATE_FORBIDDEN_IN_ENV may be present
        (api_key / agent_id must never appear in env.json).

    Raises ``ValueError`` with an actionable message on any violation.
    Returns ``None`` silently on success.
    """
    data, path = load_env_state(workdir)
    if not data:
        state_dir = get_agent_state_dir(workdir)
        raise ValueError(
            f"env.json not found at {state_dir / ENV_STATE_FILENAME}.\n"
            "Run 'puvinoise-bind --env-only' to bootstrap."
        )

    errors: List[str] = []

    for field in ENV_STATE_REQUIRED_FIELDS:
        val = data.get(field)
        if not val or not str(val).strip():
            errors.append(f"  • Required field '{field}' is missing or empty.")

    for field in AGENT_STATE_FORBIDDEN_IN_ENV:
        if field in data:
            errors.append(
                f"  • Forbidden field '{field}' found in env.json — "
                "credentials must only appear in agent_<id>.json."
            )

    if errors:
        raise ValueError(
            f"env.json contract violation ({path}):\n" + "\n".join(errors) + "\n"
            "Fix: delete .puvinoise/ and re-run 'puvinoise-bind --env-only'."
        )

    logger.debug("agent_state: env.json contract valid (%s)", path)


def validate_agent_state(workdir: Path) -> None:
    """
    Validate ``.puvinoise/agent_<id>.json`` against the data contract,
    including a cross-file consistency check against ``env.json``.

    Rules enforced:
      1. All AGENT_STATE_REQUIRED_FIELDS must be present and non-empty.
         In particular, ``api_key`` MUST be non-empty — the SDK will not
         init without it.
      2. ``env_id`` must match ``env.json:env_id`` (cross-file check).
      3. ``base_url`` must match ``env.json:base_url`` (cross-file check).

    If env.json is absent, cross-file checks are skipped (bootstrap-only mode).

    Raises ``ValueError`` with an actionable message on any violation.
    Returns ``None`` silently on success.
    """
    # Enforce single-agent constraint first (raises RuntimeError if violated).
    _enforce_single_agent_state(get_agent_state_dir(workdir))

    agent_data, agent_path = load_agent_state(workdir)
    if not agent_data:
        raise ValueError(
            f"No agent_<id>.json found in {get_agent_state_dir(workdir)}.\n"
            "Run 'puvinoise run --agent-name <name> python <file>' to auto-register."
        )

    errors: List[str] = []

    for field in AGENT_STATE_REQUIRED_FIELDS:
        val = agent_data.get(field)
        if not val or not str(val).strip():
            errors.append(f"  • Required field '{field}' is missing or empty.")

    # Cross-file consistency: compare against env.json if it exists.
    env_data, env_path = load_env_state(workdir)
    if env_data:
        persisted_env_id = str(agent_data.get("env_id") or "").strip()
        canonical_env_id = str(env_data.get("env_id") or "").strip()
        if persisted_env_id and canonical_env_id and persisted_env_id != canonical_env_id:
            errors.append(
                f"  • env_id mismatch: agent_<id>.json has '{persisted_env_id}' "
                f"but env.json has '{canonical_env_id}'.\n"
                "    Reset: rm -rf .puvinoise && puvinoise-bind --env-only"
            )

        persisted_base = str(agent_data.get("base_url") or "").strip().rstrip("/")
        canonical_base = str(env_data.get("base_url") or "").strip().rstrip("/")
        if persisted_base and canonical_base and persisted_base != canonical_base:
            errors.append(
                f"  • base_url mismatch: agent_<id>.json has '{persisted_base}' "
                f"but env.json has '{canonical_base}'.\n"
                "    Reset: rm -rf .puvinoise && puvinoise-bind --env-only"
            )

    if errors:
        raise ValueError(
            f"agent_<id>.json contract violation ({agent_path}):\n"
            + "\n".join(errors)
        )

    logger.debug("agent_state: agent_<id>.json contract valid (%s)", agent_path)


# ─── Internal helpers ─────────────────────────────────────────────────────────


def _make_state_dir(d: Path) -> None:
    """Create directory *d* and all parents.  Raises ``RuntimeError`` on failure."""
    try:
        d.mkdir(parents=True, exist_ok=True)
    except OSError as exc:
        raise RuntimeError(
            f"Cannot create state directory {d}: {exc}\n"
            "Check directory permissions and try again."
        ) from exc
    # Hard verification — a filesystem that silently swallowed the mkdir would
    # produce a confusing "file written but not found" error further down.
    if not d.is_dir():
        raise RuntimeError(
            f"Failed to create state directory {d}.\n"
            "mkdir returned without error but the directory does not exist.\n"
            "Check file system permissions and available inodes."
        )


def _write_json(path: Path, content: Dict[str, Any]) -> None:
    """Write *content* as JSON to *path*.  Raises ``RuntimeError`` on failure.

    If *path* already exists as read-only (0o444), it is temporarily made
    writable for the duration of the write, then locked back to read-only by
    the ``_set_permissions`` call that follows every ``_write_json`` call.
    """
    try:
        if path.exists():
            # Temporarily unlock so we can overwrite the read-only file.
            try:
                os.chmod(path, 0o600)
            except Exception:  # noqa: BLE001
                pass
        path.write_text(json.dumps(content, indent=2), encoding="utf-8")
    except OSError as exc:
        raise RuntimeError(f"Cannot write state file {path}: {exc}") from exc


def _verify_exists(path: Path) -> None:
    """Raise ``RuntimeError`` if *path* does not exist after a write."""
    if not path.is_file():
        raise RuntimeError(
            f"File write appeared to succeed but {path} does not exist.\n"
            "Check available disk space and file system permissions."
        )


def _set_permissions(path: Path) -> None:
    """Set 0o444 (read-only for all) on *path* (best-effort; failure is not fatal).

    The agent state file must never be hand-edited — making it read-only prevents
    accidental corruption and reinforces that identity is managed exclusively by the SDK.
    """
    try:
        os.chmod(path, 0o444)
    except Exception:  # noqa: BLE001
        pass


def _read_json(path: Path) -> Dict[str, Any]:
    """Return parsed JSON dict from *path*, or ``{}`` on any read/parse error."""
    try:
        raw = path.read_text(encoding="utf-8")
        data = json.loads(raw)
        if isinstance(data, dict):
            return data
    except Exception:  # noqa: BLE001
        pass
    return {}
