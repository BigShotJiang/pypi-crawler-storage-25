"""
Deterministic environment binding for PUVINoise (bindcar).

* Validates registration token with the platform (read-only inspect).
* Writes active state to ``<cwd>/.env.puvinoise`` only.
* Saves named snapshots under ``.puvinoise/environments/<slug>.json``.

``puvinoise run`` reads only the active ``.env.puvinoise`` in the current working directory.
"""

from __future__ import annotations

import json
import os
import re
import sys
import urllib.error
import urllib.request
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, Optional, Tuple


ACTIVE_ENV_FILENAME = ".env.puvinoise"
ENVIRONMENTS_SUBDIR = "environments"


def _active_env_path(workdir: Path) -> Path:
    return workdir / ACTIVE_ENV_FILENAME


def _environments_dir(workdir: Path) -> Path:
    return workdir / ".puvinoise" / ENVIRONMENTS_SUBDIR


def _env_slug(name: str) -> str:
    s = (name or "").strip().lower().replace(" ", "_")
    s = re.sub(r"[^a-z0-9._-]+", "_", s)
    s = re.sub(r"_+", "_", s).strip("_")
    return s or "environment"


def _parse_dotenv_file(path: Path) -> Dict[str, str]:
    """KEY=VAL lines; supports optional `export ` prefix and quoted values."""
    out: Dict[str, str] = {}
    if not path.is_file():
        return out
    try:
        text = path.read_text(encoding="utf-8-sig")
    except OSError:
        return out
    for raw in text.splitlines():
        line = raw.strip()
        if not line or line.startswith("#"):
            continue
        if line.lower().startswith("export "):
            line = line[7:].strip()
        if "=" not in line:
            continue
        k, _, rest = line.partition("=")
        k = k.strip()
        if not k:
            continue
        val = rest.strip()
        if len(val) >= 2 and val[0] == val[-1] and val[0] in ("\"", "'"):
            val = val[1:-1]
        out[k] = val
    return out


def _write_dotenv_file(path: Path, env_map: Dict[str, str]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    lines = [f"{k}={v}" for k, v in sorted(env_map.items(), key=lambda kv: kv[0])]
    path.write_text("\n".join(lines) + "\n", encoding="utf-8")


def _post_inspect(base_url: str, registration_token: str, timeout: float = 45.0) -> Dict[str, Any]:
    url = f"{base_url.rstrip('/')}/api/bindcar/inspect"
    body = json.dumps({"registration_token": registration_token}).encode("utf-8")
    req = urllib.request.Request(
        url,
        data=body,
        headers={"Content-Type": "application/json"},
        method="POST",
    )
    try:
        with urllib.request.urlopen(req, timeout=timeout) as resp:
            raw = resp.read().decode("utf-8")
            return json.loads(raw) if raw else {}
    except urllib.error.HTTPError as e:
        try:
            detail = e.read().decode("utf-8")
            data = json.loads(detail) if detail else {}
        except Exception:
            data = {}
        err = (data.get("error") if isinstance(data, dict) else None) or str(e)
        raise RuntimeError(str(err)) from e


def _read_current_binding(workdir: Path) -> Tuple[Dict[str, str], Optional[str], Optional[str]]:
    """
    Returns (map, env_id, env_display_name) from active file.
    Prefer ``PUVINOISE_ENV_NAME``; fall back to legacy keys for older files.
    """
    p = _active_env_path(workdir)
    if not p.is_file():
        return {}, None, None
    try:
        m = _parse_dotenv_file(p)
    except Exception:
        return {}, None, None
    if not m:
        return {}, None, None
    eid = (m.get("PUVINOISE_ENV_ID") or m.get("PUVINOISE_ENVIRONMENT_ID") or "").strip() or None
    name = (
        (m.get("PUVINOISE_ENV_NAME") or "").strip()
        or (m.get("PUVINOISE_ENVIRONMENT_NAME") or "").strip()
        or (m.get("PUVINOISE_DEPLOY_ENV") or "").strip()
        or None
    )
    return m, eid, name


def _confirm_switch(current_label: str, new_name: str) -> bool:
    if not sys.stdin.isatty():
        return False
    try:
        r = input(
            f"This folder is currently bound to {current_label}.\n"
            f"You are attempting to switch to {new_name}.\n"
            "Overwrite active binding? [y/N]: "
        ).strip().lower()
    except EOFError:
        return False
    return r in ("y", "yes")


def cmd_bindcar(args) -> int:
    token = (getattr(args, "token", None) or "").strip()
    if not token:
        print("puvinoise bindcar: --token is required", file=sys.stderr)
        return 2

    base_url = (getattr(args, "base_url", None) or os.getenv("PUVINOISE_BASE_URL", "") or "").strip()
    if not base_url:
        print(
            "puvinoise bindcar: set PUVINOISE_BASE_URL or pass --base-url <url>",
            file=sys.stderr,
        )
        return 2

    workdir = Path.cwd().resolve()
    active_path = _active_env_path(workdir)

    try:
        payload = _post_inspect(base_url, token)
    except RuntimeError as e:
        print(f"puvinoise bindcar: token validation failed: {e}", file=sys.stderr)
        return 1

    if not payload.get("ok"):
        print("puvinoise bindcar: unexpected response from server", file=sys.stderr)
        return 1

    new_env_id = str(payload.get("env_id") or "").strip()
    new_env_name = str(payload.get("env_name") or "").strip()
    tenant_id = str(payload.get("tenant_id") or "").strip()
    resolved_base = str(payload.get("base_url") or base_url).strip().rstrip("/")

    if not new_env_id or not new_env_name or not tenant_id:
        print("puvinoise bindcar: server response missing env_id, env_name, or tenant_id", file=sys.stderr)
        return 1

    file_map, cur_id, cur_name = _read_current_binding(workdir)
    cur_label = cur_name or cur_id or "(unknown)"

    if cur_id and cur_id == new_env_id:
        print(f"✔ Already bound to environment: {new_env_name}")
        print(
            "[puvinoise-bindcar] Next: `puvinoise onboard` or `puvinoise run --agent-name <name> ...`",
            file=sys.stderr,
        )
        return 0

    if cur_id and cur_id != new_env_id:
        print(
            f"⚠ This folder is currently bound to {cur_label}\n"
            f"You are attempting to switch to {new_env_name}",
            file=sys.stderr,
        )
        force = bool(getattr(args, "force", False))
        if not force and not _confirm_switch(cur_label, new_env_name):
            if not sys.stdin.isatty():
                print(
                    "puvinoise bindcar: non-interactive session — re-run with --force to switch binding.",
                    file=sys.stderr,
                )
            return 3

    if active_path.is_file() and not file_map.get("PUVINOISE_ENV_ID"):
        print(
            "⚠ Environment config file exists but PUVINOISE_ENV_ID is missing or unreadable.",
            file=sys.stderr,
        )
        if not bool(getattr(args, "force", False)):
            print(
                "puvinoise bindcar: fix the file or re-run with --force to replace it.",
                file=sys.stderr,
            )
            return 3

    # Strict local contract: no registration token persisted — token is used only for this request.
    out_map: Dict[str, str] = {
        "PUVINOISE_BASE_URL": resolved_base,
        "PUVINOISE_ENV_ID": new_env_id,
        "PUVINOISE_ENV_NAME": new_env_name,
        "PUVINOISE_TENANT_ID": tenant_id,
    }
    _write_dotenv_file(active_path, out_map)

    slug = _env_slug(new_env_name)
    env_dir = _environments_dir(workdir)
    env_dir.mkdir(parents=True, exist_ok=True)
    saved_path = env_dir / f"{slug}.json"
    snap = {
        "version": "1.0",
        "env_id": new_env_id,
        "env_name": new_env_name,
        "slug": slug,
        "tenant_id": tenant_id,
        "base_url": resolved_base,
        "bound_at": datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ"),
    }
    saved_path.write_text(json.dumps(snap, indent=2) + "\n", encoding="utf-8")

    print(f"✔ Active environment: {new_env_name}")
    print(f"[puvinoise-bindcar] wrote {active_path}", file=sys.stderr)
    print(f"[puvinoise-bindcar] saved snapshot → {saved_path}", file=sys.stderr)
    print(
        "[puvinoise-bindcar] Next: register this folder — "
        "`puvinoise onboard` (prompts for agent name) or "
        "`puvinoise run --agent-name <name> ...`",
        file=sys.stderr,
    )
    return 0


def _find_saved_env(workdir: Path, name: str) -> Optional[Path]:
    want = (name or "").strip().lower()
    if not want:
        return None
    d = _environments_dir(workdir)
    if not d.is_dir():
        return None
    for p in sorted(d.glob("*.json")):
        try:
            data = json.loads(p.read_text(encoding="utf-8"))
        except Exception:
            continue
        if not isinstance(data, dict):
            continue
        if str(data.get("slug", "")).strip().lower() == want:
            return p
        if str(data.get("env_name", "")).strip().lower() == want:
            return p
    return None


def cmd_switch(args) -> int:
    name = (getattr(args, "env_name", None) or "").strip()
    if not name:
        print("puvinoise switch: environment name is required", file=sys.stderr)
        return 2

    workdir = Path.cwd().resolve()
    p = _find_saved_env(workdir, name)
    if not p or not p.is_file():
        print(
            f"puvinoise switch: no saved environment '{name}' under .puvinoise/environments/",
            file=sys.stderr,
        )
        return 1

    try:
        data = json.loads(p.read_text(encoding="utf-8"))
    except Exception as e:
        print(f"puvinoise switch: corrupted snapshot: {e}", file=sys.stderr)
        return 1

    if not isinstance(data, dict):
        print("puvinoise switch: invalid snapshot", file=sys.stderr)
        return 1

    eid = str(data.get("env_id") or "").strip()
    ename = str(data.get("env_name") or "").strip()
    tid = str(data.get("tenant_id") or "").strip()
    base = str(data.get("base_url") or "").strip().rstrip("/")
    if not eid or not ename or not tid or not base:
        print("puvinoise switch: snapshot missing env_id, env_name, tenant_id, or base_url", file=sys.stderr)
        return 1

    out_map: Dict[str, str] = {
        "PUVINOISE_BASE_URL": base,
        "PUVINOISE_ENV_ID": eid,
        "PUVINOISE_ENV_NAME": ename,
        "PUVINOISE_TENANT_ID": tid,
    }

    _write_dotenv_file(_active_env_path(workdir), out_map)
    print(f"✔ Active environment: {ename}")
    print(f"[puvinoise-switch] updated {_active_env_path(workdir)}", file=sys.stderr)
    return 0


def register_bindcar_subparser(sub) -> None:
    p = sub.add_parser(
        "bindcar",
        help="Bind this folder to a platform environment (writes .env.puvinoise)",
        description=(
            "Validate a registration token with the server and persist the active environment "
            "to .env.puvinoise plus a named snapshot under .puvinoise/environments/."
        ),
    )
    p.add_argument("--token", required=True, help="Registration token (prt_...) from the PUVINoise UI")
    p.add_argument(
        "--base-url",
        dest="base_url",
        default=None,
        help="Platform base URL (overrides PUVINOISE_BASE_URL)",
    )
    p.add_argument(
        "--force",
        action="store_true",
        help="Non-interactive: allow switching away from an existing binding",
    )
    p.set_defaults(func=cmd_bindcar)


def register_switch_subparser(sub) -> None:
    p = sub.add_parser(
        "switch",
        help="Activate a previously saved environment snapshot (no server call)",
        description="Copy a saved environment from .puvinoise/environments/ into .env.puvinoise.",
    )
    p.add_argument("env_name", help="Saved environment name or slug")
    p.set_defaults(func=cmd_switch)
