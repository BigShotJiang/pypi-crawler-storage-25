"""
HTTP helpers for tenant-scoped CLI commands (create, attach, list).

Uses JWT from PUVINOISE_BEARER_TOKEN or --bearer. These endpoints mirror the
product UI; they are separate from agent runtime auth (API keys).
"""

from __future__ import annotations

import json
import os
import urllib.error
import urllib.request
from pathlib import Path
from urllib.parse import quote
from typing import Any, Dict, List, Optional, Tuple

from puvinoise.bindcar import _active_env_path, _parse_dotenv_file


class TenantApiError(RuntimeError):
    """HTTP error from tenant API with parsed JSON body when available."""

    def __init__(self, message: str, *, status: int, payload: Any = None):
        super().__init__(message)
        self.status = status
        self.payload = payload if isinstance(payload, dict) else None


def load_binding(workdir: Path) -> Tuple[str, str, str, str]:
    """
    Read ./.env.puvinoise for base URL, env id, env display name, tenant id.

    Raises ValueError with an actionable message if binding is missing or incomplete.
    """
    p = _active_env_path(workdir.resolve())
    if not p.is_file():
        raise ValueError(
            "No environment binding for this folder.\n"
            "  Run: puvinoise bindcar --token <prt_...>\n"
            "  (set PUVINOISE_BASE_URL or use bindcar --base-url if needed)"
        )
    m = _parse_dotenv_file(p)
    base = (m.get("PUVINOISE_BASE_URL") or "").strip().rstrip("/")
    eid = (m.get("PUVINOISE_ENV_ID") or m.get("PUVINOISE_ENVIRONMENT_ID") or "").strip()
    ename = (
        (m.get("PUVINOISE_ENV_NAME") or "").strip()
        or (m.get("PUVINOISE_ENVIRONMENT_NAME") or "").strip()
        or ""
    )
    tid = (m.get("PUVINOISE_TENANT_ID") or "").strip()
    if not base or not eid:
        raise ValueError(
            f"{p} is missing PUVINOISE_BASE_URL or PUVINOISE_ENV_ID.\n"
            "  Re-run: puvinoise bindcar --token <prt_...>"
        )
    return base, eid, ename, tid


def resolve_bearer(explicit: Optional[str] = None) -> str:
    """Bearer JWT from argument or PUVINOISE_BEARER_TOKEN."""
    t = (explicit or os.environ.get("PUVINOISE_BEARER_TOKEN", "") or "").strip()
    if not t:
        raise ValueError(
            "Tenant JWT is required for this command.\n"
            "  Export PUVINOISE_BEARER_TOKEN from your browser session (same token as the UI),\n"
            "  or pass --bearer <jwt>."
        )
    return t


def _request_json(
    method: str,
    url: str,
    *,
    bearer: Optional[str] = None,
    body: Optional[Dict[str, Any]] = None,
    timeout: float = 60.0,
) -> Tuple[int, Any]:
    data = json.dumps(body).encode("utf-8") if body is not None else None
    req = urllib.request.Request(url, data=data, method=method)
    req.add_header("Content-Type", "application/json")
    if bearer:
        req.add_header("Authorization", f"Bearer {bearer}")
    try:
        with urllib.request.urlopen(req, timeout=timeout) as resp:
            raw = resp.read().decode("utf-8")
            status = int(getattr(resp, "status", 200) or 200)
            if not raw:
                return status, {}
            return status, json.loads(raw)
    except urllib.error.HTTPError as e:
        try:
            detail = e.read().decode("utf-8")
            payload = json.loads(detail) if detail else {}
        except Exception:
            payload = {"error": str(e)}
        err = (payload.get("error") if isinstance(payload, dict) else None) or str(e)
        raise TenantApiError(
            f"HTTP {e.code}: {err}",
            status=int(e.code),
            payload=payload if isinstance(payload, dict) else None,
        ) from e


def api_list_agents(
    base_url: str,
    bearer: str,
    *,
    tag_filters: Optional[List[Tuple[str, str]]] = None,
    search: Optional[str] = None,
) -> List[Dict[str, Any]]:
    qs: List[str] = []
    if search and str(search).strip():
        qs.append(f"search={quote(str(search).strip())}")
    if tag_filters:
        for k, v in tag_filters:
            k0, v0 = str(k).strip(), str(v).strip()
            if k0 and v0:
                qs.append(f"tag={quote(f'{k0}={v0}')}")
    suffix = ("?" + "&".join(qs)) if qs else ""
    status, data = _request_json("GET", f"{base_url}/api/agents{suffix}", bearer=bearer)
    if status >= 400:
        raise RuntimeError(f"List agents failed: {data}")
    agents = data.get("agents") if isinstance(data, dict) else None
    if not isinstance(agents, list):
        return []
    return agents


def api_get_agent(base_url: str, bearer: str, agent_id: str) -> Dict[str, Any]:
    aid = quote(agent_id.strip(), safe="")
    status, data = _request_json("GET", f"{base_url}/api/agents/{aid}", bearer=bearer)
    if status >= 400 or not isinstance(data, dict):
        raise RuntimeError(f"Get agent failed: {data}")
    agent = data.get("agent")
    if not isinstance(agent, dict):
        raise RuntimeError("Get agent: missing agent object")
    return agent


def api_create_agent(
    base_url: str,
    bearer: str,
    name: str,
    *,
    tags: Optional[Dict[str, str]] = None,
) -> Dict[str, Any]:
    body: Dict[str, Any] = {"name": name.strip()}
    if tags:
        body["tags"] = tags
    try:
        status, data = _request_json(
            "POST",
            f"{base_url}/api/agents",
            bearer=bearer,
            body=body,
        )
    except TenantApiError:
        raise
    if status >= 400 or not isinstance(data, dict):
        raise RuntimeError(f"Create agent failed: {data}")
    agent = data.get("agent")
    if not isinstance(agent, dict) or not agent.get("agent_id"):
        raise RuntimeError("Create agent: invalid response")
    return agent


def api_patch_agent(
    base_url: str,
    bearer: str,
    agent_key: str,
    *,
    environment_id: Optional[str] = None,
) -> Dict[str, Any]:
    body: Dict[str, Any] = {}
    if environment_id is not None:
        body["environmentId"] = environment_id
    key = quote(agent_key.strip(), safe="")
    status, data = _request_json(
        "PATCH",
        f"{base_url}/api/agents/{key}",
        bearer=bearer,
        body=body,
    )
    if status >= 400 or not isinstance(data, dict):
        raise RuntimeError(f"Update agent failed: {data}")
    agent = data.get("agent")
    if not isinstance(agent, dict):
        raise RuntimeError("Update agent: invalid response")
    return agent


def api_auto_register(base_url: str, env_id: str, agent_name: str) -> Dict[str, Any]:
    """Open registration (bootstrapped env gate on server). No JWT."""
    status, data = _request_json(
        "POST",
        f"{base_url.rstrip('/')}/api/auto-register",
        bearer=None,
        body={"env_id": env_id.strip(), "agent_name": agent_name.strip()},
    )
    if status >= 400 or not isinstance(data, dict):
        raise RuntimeError(f"Auto-register failed: {data}")
    if not data.get("api_key") or not data.get("agent_id"):
        raise RuntimeError("Auto-register: incomplete response (api_key / agent_id)")
    return data
