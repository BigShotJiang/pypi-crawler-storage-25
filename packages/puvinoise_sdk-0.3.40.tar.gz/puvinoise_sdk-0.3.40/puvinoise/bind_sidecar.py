#!/usr/bin/env python3 -u
"""
PUVINoise bind sidecar (standalone).

Purpose:
- Handle bind probe, token registration, runtime metadata report, and heartbeat loop.
- After registration: pull bootstrap config (.env, wrapper, SDK install) from the platform.
- Validate wrapper application with syntax check before enabling.

After the bind probe, POST /api/register returns 409 until an admin approves the bind in
Register Agent → Step 3. This script polls until approval (use --loop for an unbounded wait on the agent host).

Required env:
- PUVINOISE_BASE_URL
- PUVINOISE_AGENT_NAME
- PUVINOISE_DEPLOY_ENV — optional for POST /api/register when using PUVINOISE_REGISTRATION_TOKEN; the control
  plane uses the environment name baked into the token (client value is ignored if it differs).
  Still used for probes/heartbeat labels; defaults to "Development". Alias: PUVINOISE_ENVIRONMENT_NAME.
- PUVINOISE_DEPLOY_VERSION (recommended)

Registration token (first bind only):
- PUVINOISE_REGISTRATION_TOKEN — required until the agent has registered once.

After a successful bind, state is stored in:

- ``--env-only`` mode (environment bootstrap only):
    ``.puvinoise/env.json``                  — env_id + base_url

- Full registration mode (agent bound):
    ``.puvinoise/agent_<agent_id>.json``     — env_id + base_url + agent_id
    ``.puvinoise_bind_state.json``           — full credentials (legacy; workdir authoritative)
    ``<tempdir>/puvi_bind_state.json``       — temp mirror for process restarts

Load order prefers the workdir file so fixing identity in the agent folder (or syncing with ``.env``)
cannot be overridden by a stale global temp cache.

If both caches are missing (e.g. ``/tmp`` cleared) but ``.env`` in the agent directory already contains
``PUVINOISE_BASE_URL``, ``PUVINOISE_AGENT_ID``, and ``PUVINOISE_API_KEY``
matching this run, the sidecar recovers without a registration token.
"""

from __future__ import annotations

import argparse
import json
import os
import re
import shutil
import socket
import ssl
import subprocess
import sys
import tempfile
import time
import urllib.error
import urllib.request
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple
from puvinoise.wrapper_builder import (
    INSTRUMENTATION_MARKER,
    build_python_wrapper_with_rollback,
)
from puvinoise.env_files import (
    canonical_env_path,
    legacy_env_path,
    resolve_read_env_path,
    BRANDED_NAME as PUVI_ENV_BRANDED_NAME,
)

SIDECAR_VERSION = "2"
STATE_FILE = Path(tempfile.gettempdir()) / "puvi_bind_state.json"
# Persists in the agent cwd (unlike /tmp); survives OS reboot and tmp cleanup.
PERSISTENT_STATE_BASENAME = ".puvinoise_bind_state.json"
SIDEAR_SDK_VERSION = f"bind-sidecar-standalone-{SIDECAR_VERSION}"
SIDEAR_WRAPPER_VERSION = f"proxy-stub-{SIDECAR_VERSION}"
MIN_SDK_VERSION = (0, 2, 16)


def _now_iso() -> str:
    return datetime.now(timezone.utc).isoformat()


def _required_env(name: str) -> str:
    value = os.getenv(name, "").strip()
    if not value:
        raise RuntimeError(f"Missing required env var: {name}")
    return value


SSL_ERROR_PATTERNS = (
    "CERTIFICATE_VERIFY_FAILED",
    "SSL:",
    "unable to get local issuer certificate",
    "SSL_CERT_FILE",
    "certificate verify failed",
)


def _is_ssl_cert_error(exc: object) -> bool:
    """Return True when text indicates an SSL certificate verification failure."""
    msg = str(exc or "").lower()
    return any(pattern.lower() in msg for pattern in SSL_ERROR_PATTERNS)


def _ssl_certificate_guidance() -> str:
    message = (
        "[PUVINoise] SSL certificate issue detected.\n\n"
        "This is a common macOS Python environment issue.\n\n"
        "Run the following command to fix it:\n\n"
        "export SSL_CERT_FILE=$(python3 -m certifi)\n\n"
        "Then re-run your agent."
    )
    try:
        import certifi  # type: ignore  # noqa: F401
    except Exception:
        message += "\n\nIf certifi is not installed, run:\n\npip install certifi"
    return message


def _get_certifi_path() -> Optional[str]:
    """Return the certifi CA bundle path, installing certifi if absent."""
    try:
        import certifi  # type: ignore
        return certifi.where()
    except ImportError:
        pass

    print("[PUVINoise] certifi is not installed")
    print("[PUVINoise] Installing certifi bundle with pip")
    try:
        subprocess.check_call(
            [sys.executable, "-m", "pip", "install", "-q", "--upgrade", "certifi"],
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
        )
        import certifi  # type: ignore  # noqa: PLC0415
        return certifi.where()
    except Exception as exc:
        print(f"[PUVINoise] certifi install failed: {exc}")
        return None


def _make_ssl_context(cert_path: str) -> ssl.SSLContext:
    ctx = ssl.create_default_context()
    ctx.load_verify_locations(cafile=cert_path)
    return ctx


def _patch_env_file_ssl(cert_path: str, workdir: Optional[Path] = None) -> None:
    """Append SSL_CERT_FILE and REQUESTS_CA_BUNDLE to .env.puvinoise if not already present."""
    env_file = canonical_env_path(workdir or Path.cwd())
    try:
        existing = env_file.read_text(encoding="utf-8") if env_file.exists() else ""
        lines_to_add = []
        for key, val in [("SSL_CERT_FILE", cert_path), ("REQUESTS_CA_BUNDLE", cert_path)]:
            if f"{key}=" not in existing:
                lines_to_add.append(f"{key}={val}")
        if lines_to_add:
            print(f"[PUVINoise] Writing SSL certificate bundle settings to {env_file}")
            with env_file.open("a", encoding="utf-8") as f:
                f.write("\n# SSL certificate bundle — added by PUVINoise certifi-based SSL fix\n")
                f.write("\n".join(lines_to_add) + "\n")
        else:
            print(f"[PUVINoise] SSL certificate bundle settings already present in {env_file}")
    except Exception as patch_err:
        print(f"[PUVINoise] Could not persist SSL certificate bundle settings to {env_file}: {patch_err}")


def _apply_ssl_self_heal(workdir: Optional[Path] = None) -> Optional[ssl.SSLContext]:
    """
    Detect macOS/Python SSL cert issue and self-heal using certifi only.

    This does not disable SSL verification. It sets Python/requests CA bundle
    environment variables to certifi's CA bundle and retries with an SSLContext
    loaded from the same bundle.
    """
    print("[PUVINoise] Applying certifi-based fix")
    cert_path = _get_certifi_path()
    if not cert_path:
        print("[PUVINoise] SSL certifi-based fix failed")
        return None

    print(f"[PUVINoise] Using certifi bundle: {cert_path}")
    os.environ["SSL_CERT_FILE"] = cert_path
    os.environ["REQUESTS_CA_BUNDLE"] = cert_path
    print("[PUVINoise] Set SSL_CERT_FILE and REQUESTS_CA_BUNDLE for this process")
    _patch_env_file_ssl(cert_path, workdir)
    ctx = _make_ssl_context(cert_path)
    print("[PUVINoise] SSL configured successfully")
    return ctx


def _urlopen_with_ssl_heal(req: urllib.request.Request, timeout: int, workdir: Optional[Path] = None):
    """
    Try urlopen; on SSL cert error apply transparent certifi-based self-heal and retry once.
    """
    try:
        return urllib.request.urlopen(req, timeout=timeout)
    except urllib.error.URLError as exc:
        if not _is_ssl_cert_error(exc):
            raise
        print("[PUVINoise] SSL issue detected")
        ctx = _apply_ssl_self_heal(workdir)
        if ctx is None:
            raise RuntimeError(_ssl_certificate_guidance()) from exc
        return urllib.request.urlopen(req, context=ctx, timeout=timeout)


def _post_json(url: str, payload: Dict[str, Any], bearer: Optional[str] = None, timeout: int = 15, workdir: Optional[Path] = None) -> Dict[str, Any]:
    req = urllib.request.Request(url, data=json.dumps(payload).encode("utf-8"), method="POST")
    req.add_header("Content-Type", "application/json")
    if bearer:
        req.add_header("Authorization", f"Bearer {bearer}")
    try:
        with _urlopen_with_ssl_heal(req, timeout, workdir) as resp:
            raw = resp.read().decode("utf-8", errors="replace")
            return json.loads(raw) if raw.strip() else {}
    except urllib.error.HTTPError as e:
        body = e.read().decode("utf-8", errors="replace")
        raise RuntimeError(f"HTTP {e.code} {url}: {body or e.reason}") from e
    except urllib.error.URLError as e:
        raise RuntimeError(f"Network error {url}: {e.reason}") from e


def _read_json_file(path: Path) -> Dict[str, Any]:
    if not path.exists():
        return {}
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except Exception:
        return {}


def _load_state(workdir: Optional[Path] = None) -> Dict[str, Any]:
    """
    Load registration state: prefer persistent file in workdir, then temp cache.

    Previously temp won first, which left a stale ``puvi_bind_state.json`` in ``/tmp`` overriding
    an updated ``.puvinoise_bind_state.json`` or ``.env`` after re-registration — causing 401 and
    agent id mismatch until the user manually deleted the temp file.
    """
    wd = workdir if workdir is not None else Path.cwd()
    persistent = _read_json_file(wd / PERSISTENT_STATE_BASENAME)
    if persistent:
        return persistent
    data = _read_json_file(STATE_FILE)
    if data:
        return data
    return {}


def _save_state(state: Dict[str, Any], workdir: Optional[Path] = None) -> None:
    STATE_FILE.write_text(json.dumps(state, indent=2), encoding="utf-8")
    wd = workdir if workdir is not None else Path.cwd()
    try:
        (wd / PERSISTENT_STATE_BASENAME).write_text(json.dumps(state, indent=2), encoding="utf-8")
    except Exception:
        pass


def _clear_state(workdir: Optional[Path] = None) -> None:
    try:
        if STATE_FILE.exists():
            STATE_FILE.unlink()
    except Exception:
        pass
    wd = workdir if workdir is not None else Path.cwd()
    try:
        p = wd / PERSISTENT_STATE_BASENAME
        if p.exists():
            p.unlink()
    except Exception:
        pass


def _merged_env_for_recovery(workdir: Path) -> Dict[str, str]:
    """Dotenv file plus process environment (process overrides file)."""
    # Prefer branded .env.puvinoise; fall back to legacy .env.
    env_path = resolve_read_env_path(workdir) or canonical_env_path(workdir)
    file_map = _parse_env_file_map(env_path)
    merged = dict(file_map)
    for k, v in os.environ.items():
        if v is not None and str(v).strip():
            merged[k] = str(v).strip()
    return merged


def _normalize_platform_url(url: str) -> str:
    return (url or "").strip().rstrip("/")


def _try_recover_state_from_dotenv(
    platform_url: str,
    agent_name: str,
    deploy_env: str,
    deploy_version: str,
    workdir: Path,
) -> Optional[Dict[str, Any]]:
    """
    When temp cache is gone, rebuild registration state from .env / environment if the agent was
    already bound (PUVINOISE_AGENT_ID + access key present for this platform and agent name).
    """
    merged = _merged_env_for_recovery(workdir)
    exp = _normalize_platform_url(platform_url)
    plat = _normalize_platform_url(merged.get("PUVINOISE_BASE_URL", ""))
    if not plat or plat != exp:
        return None

    name_in_env = (merged.get("PUVINOISE_AGENT_NAME") or "").strip()
    if name_in_env and name_in_env != agent_name:
        return None

    aid = (merged.get("PUVINOISE_AGENT_ID") or "").strip()
    key = (merged.get("PUVINOISE_API_KEY") or "").strip()
    if not aid or not key:
        return None

    token = (merged.get("PUVINOISE_REGISTRATION_TOKEN") or os.getenv("PUVINOISE_REGISTRATION_TOKEN") or "").strip()

    return {
        "agent_id": aid,
        "agent_access_key": key,
        "platform_url": exp,
        "registration_token": token,
        "agent_name": agent_name,
        "deploy_env": deploy_env,
        "deploy_version": deploy_version,
        "registered_at": _now_iso(),
        "recovered_from": "dotenv_or_env",
    }


def emit_probe(platform_url: str, registration_token: str, agent_name: str, deploy_env: str, deploy_version: str) -> None:
    try:
        _post_json(
            f"{platform_url.rstrip('/')}/api/register/probe",
            {
                "registration_token": registration_token,
                "agent_name": agent_name,
                "metadata": {"deploy_env": deploy_env, "deploy_version": deploy_version},
            },
            timeout=10,
        )
    except Exception as exc:
        msg = str(exc)
        # Token may already be USED by a prior /api/register call; probe is advisory.
        if (
            "Registration token is not active" in msg
            or "token is not active" in msg
            or "Registration token expired" in msg
            or "token expired" in msg
        ):
            print("[puvi-bind-sidecar] probe skipped: token already consumed or expired")
            return
        raise


def _is_bind_pending_approval_error(err: Exception) -> bool:
    msg = str(err)
    return "409" in msg and ("BIND_NOT_APPROVED" in msg or "PENDING_APPROVAL" in msg)


def _register_once(
    platform_url: str,
    registration_token: str,
    agent_name: str,
    deploy_env: str,
    deploy_version: str,
    workdir: Optional[Path] = None,
) -> Dict[str, Any]:
    _wd = (workdir or Path.cwd()).resolve()
    env_id = os.getenv("PUVINOISE_ENV_ID", "").strip()
    resp = _post_json(
        f"{platform_url.rstrip('/')}/api/register",
        {
            "registration_token": registration_token,
            "agent_name": agent_name,
            **({"env_id": env_id} if env_id else {}),
            "metadata": {"deploy_env": deploy_env, "deploy_version": deploy_version},
        },
        timeout=20,
    )
    next_state = {
        "agent_id": str(resp.get("agent_id", "")).strip(),
        "agent_access_key": str(resp.get("agent_access_key", "")).strip(),
        "platform_url": platform_url.rstrip("/"),
        "registration_token": registration_token,
        "agent_name": agent_name,
        "deploy_env": deploy_env,
        "registered_at": _now_iso(),
    }
    if not next_state["agent_id"] or not next_state["agent_access_key"]:
        raise RuntimeError("Registration succeeded but missing agent_id or agent_access_key")
    _save_state(next_state, _wd)
    return next_state


def ensure_registered(
    platform_url: str,
    registration_token: str,
    agent_name: str,
    deploy_env: str,
    deploy_version: str,
    *,
    approval_max_wait_s: Optional[float] = 240.0,
    approval_poll_interval_s: float = 5.0,
    workdir: Optional[Path] = None,
) -> Dict[str, Any]:
    """
    Complete POST /api/register. If the bind intent exists but is not approved yet, the API returns 409
    (BIND_NOT_APPROVED). Poll until approved or until approval_max_wait_s elapses.

    approval_max_wait_s:
      - None  → wait indefinitely (use with --loop on the agent host).
      - float → seconds, then raise with instructions to approve in UI and retry (default 240).
    """
    _wd = (workdir or Path.cwd()).resolve()
    state = _load_state(_wd)
    same_context = (
        str(state.get("platform_url", "")).strip() == platform_url.rstrip("/")
        and str(state.get("registration_token", "")).strip() == registration_token
        and str(state.get("agent_name", "")).strip() == agent_name
        and str(state.get("deploy_env", "")).strip() == deploy_env
    )
    if same_context and state.get("agent_access_key") and state.get("agent_id"):
        return state

    start = time.time()
    attempt = 0
    while True:
        attempt += 1
        try:
            return _register_once(
                platform_url,
                registration_token,
                agent_name,
                deploy_env,
                deploy_version,
                workdir=_wd,
            )
        except RuntimeError as e:
            if not _is_bind_pending_approval_error(e):
                raise
            elapsed = time.time() - start
            if approval_max_wait_s is not None and elapsed >= approval_max_wait_s:
                raise RuntimeError(
                    "Binding is still waiting for administrator approval in PUVINoise "
                    "(Register Agent → Step 3 Registration → Approve binding). "
                    "After you approve, run this command again, or use --loop to wait automatically."
                ) from e
            if attempt == 1 or attempt % 6 == 0:
                print(
                    "[puvi-bind-sidecar] Bind intent recorded; waiting for approval in PUVINoise UI… "
                    f"(poll #{attempt}, {int(elapsed)}s elapsed)"
                )
            time.sleep(max(2.0, approval_poll_interval_s))


def report_runtime_metadata(
    platform_url: str,
    access_key: str,
    agent_id: str,
    agent_name: str,
    deploy_env: str,
    deploy_version: str,
    installed_sdk_version: str = "",
    readiness_ok: Optional[bool] = None,
    readiness_issues: Optional[List[str]] = None,
    trace_probe_status: str = "",
    trace_probe_details: Optional[List[str]] = None,
) -> None:
    """Report agent registration metadata to the platform.
    installed_sdk_version: the real puvinoise-sdk version from PyPI (e.g. "0.2.16"),
    as returned by ensure_sdk_installed(). Falls back to SIDEAR_SDK_VERSION only if
    the real version is not yet known.
    """
    sdk_ver = installed_sdk_version.strip() if installed_sdk_version.strip() else SIDEAR_SDK_VERSION
    env_id = os.getenv("PUVINOISE_ENV_ID", "").strip()
    _post_json(
        f"{platform_url.rstrip('/')}/api/agent-register",
        {
            "agentId": agent_id,
            "agentName": agent_name,
            "framework": "customer-runtime",
            "llmProvider": "unknown",
            "model": "n/a",
            "tools": [],
            "environment": deploy_env,
            **({"env_id": env_id} if env_id else {}),
            **({"environmentId": env_id} if env_id else {}),
            "version": deploy_version,
            "runtime_metadata": {
                "agent_name": agent_name,
                "sdk_language": "python",
                "sdk_version": sdk_ver,
                "wrapper_version": SIDEAR_WRAPPER_VERSION,
                "deploy_env": deploy_env,
                "deploy_version": deploy_version,
                "runtime": "bind-sidecar-standalone",
                "env_id": env_id,
                "host": socket.gethostname(),
                "instance_id": f"bind-{int(time.time())}",
                "bootstrap_readiness_status": (
                    "PASS" if readiness_ok is True else "FAIL" if readiness_ok is False else ""
                ),
                "bootstrap_readiness_issues": readiness_issues or [],
                "bootstrap_readiness_checked_at": _now_iso() if readiness_ok is not None else "",
                "trace_probe_status": str(trace_probe_status or "").strip(),
                "trace_probe_details": trace_probe_details or [],
            },
        },
        bearer=access_key,
        timeout=45,
    )


def _request_environment_approval(
    platform_url: str,
    access_key: str,
    env_id: str,
) -> None:
    """
    Environment-first lifecycle: transition environment from CREATED → PENDING.

    Called early in the sidecar bootstrap flow (after registration) so that the admin
    approval queue is populated automatically, matching the flowchart step
    "Sidecar → Register Environment → PUVINoise: Mark env PENDING_APPROVAL".

    Idempotent: the server returns 200 with alreadyAdvanced=true if already PENDING+.
    Non-fatal: if the call fails the sidecar continues; approval can be triggered
    manually via POST /environments/:id/request-approval in the UI.
    """
    if not env_id:
        return
    try:
        _post_json(
            f"{platform_url.rstrip('/')}/api/environments/{env_id}/request-approval-sdk",
            {"agentInitiated": True},
            timeout=15,
            bearer=access_key,
        )
        print(f"[puvi-bind-sidecar] ✓ environment {env_id} submitted for approval (PENDING)")
    except Exception as exc:
        print(
            f"[puvi-bind-sidecar] request-approval-sdk non-fatal (admin can approve manually): {exc}"
        )


def _notify_bootstrap_complete(
    platform_url: str,
    access_key: str,
    agent_id: str,
    deploy_env: str,
    sdk_ver: str,
    ready_issues: Optional[List[str]] = None,
) -> bool:
    """
    Environment-first lifecycle: notify the platform that bootstrap is complete so that
    env.bootstrapStatus transitions to BOOTSTRAPPED and agents may register.

    Reads PUVINOISE_ENV_ID (the environment's MongoDB _id) and PUVINOISE_BOOTSTRAP_TOKEN
    (the single-use token issued when the admin approved the environment) from env.

    Gap 5 fix: if env vars are missing, adds a warning to ready_issues so the
    readiness report surfaces the gap instead of silently skipping.

    Returns True on success (including idempotent already-bootstrapped), False on failure.
    """
    env_id = os.getenv("PUVINOISE_ENV_ID", "").strip()
    bootstrap_token = os.getenv("PUVINOISE_BOOTSTRAP_TOKEN", "").strip()

    if not env_id or not bootstrap_token:
        msg = (
            "PUVINOISE_ENV_ID or PUVINOISE_BOOTSTRAP_TOKEN not set — "
            "environment will remain in APPROVED state and agents cannot register. "
            "Set both vars and re-run sidecar, or call POST /environments/:id/reissue-bootstrap-token "
            "if the token has expired."
        )
        print(f"[puvi-bind-sidecar] WARNING: {msg}")
        if ready_issues is not None:
            ready_issues.append(msg)
        return False

    try:
        _post_json(
            f"{platform_url.rstrip('/')}/api/environments/{env_id}/bootstrap-complete",
            {
                "bootstrapToken": bootstrap_token,
                "sdkVersion": sdk_ver or "",
                "hostName": os.getenv("HOSTNAME", ""),
                "agentId": agent_id,
                "deployEnv": deploy_env,
            },
            timeout=20,
            bearer=access_key,
        )
        print(f"[puvi-bind-sidecar] ✓ environment {env_id} bootstrapped — agents may now register")
        return True
    except Exception as exc:
        # Non-fatal for full bind flows (token may have been consumed on a prior run).
        # In --env-only mode the caller checks the return value and surfaces the error clearly.
        print(f"[puvi-bind-sidecar] bootstrap-complete notification non-fatal: {exc}")
        return False


def _report_bootstrap_complete(
    server_url: str,
    agent_id: str,
    access_key: str,
    env_written: bool,
    wrapper_written: bool,
    run_py_instrumented: bool,
    sdk_version: str,
    readiness_gate_passed: bool,
) -> None:
    """POST bootstrap file-level confirmation to PUVINoise server.

    This closes the gap where the server only knows the sidecar is alive via heartbeat
    but has no visibility into whether .env, puvinoise-wrapper.sh, and run.py
    instrumentation were actually written.  Called once after the readiness gate check,
    before the heartbeat loop begins.

    Non-fatal: a failure here must never prevent the sidecar from starting.
    """
    import urllib.request as _ureq
    import json as _json

    url = f"{server_url.rstrip('/')}/api/agent/bootstrap-complete"
    payload = {
        "agent_id": agent_id,
        "envWritten": env_written,
        "wrapperWritten": wrapper_written,
        "runPyInstrumented": run_py_instrumented,
        "sdkVersion": sdk_version or "",
        "readinessGatePassed": readiness_gate_passed,
    }
    headers = {
        "Content-Type": "application/json",
        "X-Api-Key": access_key,          # same header as heartbeat (authenticateApiKeyFromHeaderOrBearer)
    }
    try:
        data = _json.dumps(payload).encode("utf-8")
        req = _ureq.Request(url, data=data, headers=headers, method="POST")
        with _ureq.urlopen(req, timeout=10) as resp:
            body = _json.loads(resp.read().decode("utf-8"))
            confirmed = body.get("bootstrapFilesConfirmed", False)
            status = "confirmed" if confirmed else "INCOMPLETE"
            print(f"[puvi-bind-sidecar] bootstrap-complete reported: {status}")
    except Exception as exc:
        # Non-fatal — log and continue.  A temporary network hiccup must never
        # prevent the sidecar from starting.
        print(f"[puvi-bind-sidecar] bootstrap-complete report failed (non-fatal): {exc}")


def send_heartbeat(platform_url: str, access_key: str, agent_id: str, deploy_env: str, installed_sdk_version: str = "") -> None:
    sdk_ver = installed_sdk_version.strip() if installed_sdk_version.strip() else SIDEAR_SDK_VERSION
    _post_json(
        f"{platform_url.rstrip('/')}/api/agent-heartbeat",
        {
            "agentId": agent_id,
            "status": "running",
            "timestamp": _now_iso(),
            "environment": deploy_env,
            "ready": True,
            "pending_update": False,
            "sdk_version": sdk_ver,
            "wrapper_version": SIDEAR_WRAPPER_VERSION,
            "runtime": {
                "runtimeId": f"bind-{agent_id}",
                "hostName": socket.gethostname(),
                "runtimeType": "bind-sidecar-standalone",
            },
        },
        bearer=access_key,
        timeout=20,
    )


def _get_json(url: str, bearer: Optional[str] = None, timeout: int = 15, workdir: Optional[Path] = None) -> Dict[str, Any]:
    req = urllib.request.Request(url, method="GET")
    req.add_header("Accept", "application/json")
    if bearer:
        req.add_header("Authorization", f"Bearer {bearer}")
        req.add_header("X-Api-Key", bearer)
    try:
        with _urlopen_with_ssl_heal(req, timeout, workdir) as resp:
            raw = resp.read().decode("utf-8", errors="replace")
            return json.loads(raw) if raw.strip() else {}
    except urllib.error.HTTPError as e:
        body = e.read().decode("utf-8", errors="replace")
        raise RuntimeError(f"HTTP {e.code} {url}: {body or e.reason}") from e
    except urllib.error.URLError as e:
        raise RuntimeError(f"Network error {url}: {e.reason}") from e


# ─────────────────────────────────────────────────────────────────────────────
# GAP 1: Bootstrap config pull — .env, wrapper, SDK install command
# ─────────────────────────────────────────────────────────────────────────────

def pull_bootstrap_config(
    platform_url: str,
    access_key: str,
    agent_id: str,
    agent_name: str,
    workdir: Path,
) -> Dict[str, Any]:
    """
    Fetch the full bootstrap config from GET /api/agent/config/:agentId
    and write .env + wrapper script to the agent working directory.
    Returns the parsed config body.
    """
    url = f"{platform_url.rstrip('/')}/api/agent/config/{agent_id}"
    print(f"[puvi-bind-sidecar] pulling bootstrap config from {url}")
    try:
        cfg = _get_json(url, bearer=access_key, timeout=20)
    except Exception as exc:
        # Retry with agent name if agent_id lookup failed
        try:
            url2 = f"{platform_url.rstrip('/')}/api/agent/config/{agent_name}"
            cfg = _get_json(url2, bearer=access_key, timeout=20)
        except Exception:
            print(f"[puvi-bind-sidecar] bootstrap config pull failed: {exc}")
            return {}

    # Write env file.
    #
    # Canonical filename is `.env.puvinoise`. If a legacy `.env` already exists
    # in the workdir (older deploy), we mirror the new content to it too so
    # any wrapper or tool still doing `load_dotenv()` / `find_dotenv()` keeps
    # working unchanged. New installs only see `.env.puvinoise`.
    env_content = str(cfg.get("envFile") or cfg.get("envTemplate") or "").strip()
    if env_content:
        env_path = canonical_env_path(workdir)
        legacy_path = legacy_env_path(workdir)
        # Preserve customer OPENAI_API_KEY if already set (branded preferred, legacy fallback)
        existing_openai_key = ""
        for _source in (env_path, legacy_path):
            if not _source.exists():
                continue
            for line in _source.read_text(encoding="utf-8").splitlines():
                if line.startswith("OPENAI_API_KEY=") and line.split("=", 1)[1].strip():
                    existing_openai_key = line.split("=", 1)[1].strip()
                    break
            if existing_openai_key:
                break
        # Backup existing env files (branded and legacy if present)
        if env_path.exists():
            shutil.copy2(str(env_path), str(workdir / f"{PUVI_ENV_BRANDED_NAME}.bak"))
        if legacy_path.exists():
            shutil.copy2(str(legacy_path), str(workdir / ".env.bak"))
        # Write canonical branded file
        env_path.write_text(env_content + "\n", encoding="utf-8")
        # Restore customer API key if the new env has it empty
        if existing_openai_key:
            text = env_path.read_text(encoding="utf-8")
            if "OPENAI_API_KEY=\n" in text or text.endswith("OPENAI_API_KEY="):
                text = text.replace("OPENAI_API_KEY=", f"OPENAI_API_KEY={existing_openai_key}", 1)
                env_path.write_text(text, encoding="utf-8")
        # Mirror to legacy `.env` only when it already exists — don't silently
        # create a second file on fresh installs (that would defeat the purpose
        # of the rename).
        if legacy_path.exists():
            try:
                shutil.copy2(str(env_path), str(legacy_path))
                print(f"[puvi-bind-sidecar] legacy .env mirrored for backward compat → {legacy_path}")
            except Exception as _mirror_err:
                print(f"[puvi-bind-sidecar] warning: could not mirror to legacy .env: {_mirror_err}")
        print(f"[puvi-bind-sidecar] env written ({len(env_content)} bytes) → {env_path}")
    else:
        print("[puvi-bind-sidecar] warning: no envFile in bootstrap config response")

    # Write wrapper script
    wrapper_content = str(cfg.get("wrapperScript") or "").strip()
    if wrapper_content:
        wrapper_path = workdir / "puvinoise-wrapper.sh"
        wrapper_path.write_text(wrapper_content + "\n", encoding="utf-8")
        wrapper_path.chmod(0o755)
        print(f"[puvi-bind-sidecar] wrapper script written → {wrapper_path}")

    # Write restart script
    restart_content = str(cfg.get("restartScript") or "").strip()
    if restart_content:
        restart_path = workdir / "puvinoise-agent-restart.sh"
        restart_path.write_text(restart_content + "\n", encoding="utf-8")
        restart_path.chmod(0o755)

    return cfg


# ─────────────────────────────────────────────────────────────────────────────
# GAP 2: SDK version ↔ wrapper compatibility check
# ─────────────────────────────────────────────────────────────────────────────

def _parse_semver(v: str) -> Tuple[int, ...]:
    parts: List[int] = []
    for p in str(v or "").split("."):
        digits = "".join(ch for ch in p if ch.isdigit())
        parts.append(int(digits) if digits else 0)
    return tuple(parts) if parts else (0,)


def check_sdk_version_compatibility(min_required: Tuple[int, ...] = MIN_SDK_VERSION) -> Tuple[bool, str]:
    """
    Check if installed puvinoise SDK meets the minimum version required by this sidecar.
    Returns (compatible: bool, installed_version: str).
    """
    try:
        result = subprocess.run(
            [sys.executable, "-c", "from importlib.metadata import version; print(version('puvinoise'))"],
            capture_output=True, text=True, timeout=10,
        )
        installed = result.stdout.strip()
        if not installed and result.returncode != 0:
            # Try alternate package name
            result2 = subprocess.run(
                [sys.executable, "-c", "from importlib.metadata import version; print(version('puvinoise-sdk'))"],
                capture_output=True, text=True, timeout=10,
            )
            installed = result2.stdout.strip()
        if not installed:
            return False, "not installed"
        parsed = _parse_semver(installed)
        if parsed >= min_required:
            return True, installed
        min_str = ".".join(str(x) for x in min_required)
        print(f"[puvi-bind-sidecar] SDK version {installed} < required {min_str}")
        return False, installed
    except Exception as exc:
        print(f"[puvi-bind-sidecar] SDK version check error: {exc}")
        return False, "check failed"


# ─────────────────────────────────────────────────────────────────────────────
# GAP 3: SDK installation
# ─────────────────────────────────────────────────────────────────────────────

def ensure_sdk_installed(sdk_install_command: str = "") -> Tuple[bool, str]:
    """
    Install or upgrade the PUVINoise SDK if not present or below minimum version.
    Returns (success: bool, version: str).
    """
    compatible, version = check_sdk_version_compatibility()
    if compatible:
        print(f"[puvi-bind-sidecar] SDK {version} is compatible (>= {'.'.join(str(x) for x in MIN_SDK_VERSION)})")
        return True, version

    cmd = sdk_install_command.strip() if sdk_install_command else ""
    if not cmd:
        # Try local wheel first (common in dev/on-prem)
        workdir = Path.cwd()
        local_wheels = sorted(workdir.glob("puvinoise_sdk-*.whl")) + sorted(
            Path(__file__).resolve().parent.glob("puvinoise_sdk-*.whl")
        )
        if local_wheels:
            cmd = f"{sys.executable} -m pip install -U '{local_wheels[-1]}'"
        else:
            # Try downloading the wheel from the platform
            platform_url = os.environ.get("PUVINOISE_BASE_URL", "").rstrip("/")
            if platform_url:
                wheel_url = f"{platform_url}/api/registration/sdk-wheel"
                try:
                    print(f"[puvi-bind-sidecar] downloading SDK wheel from {wheel_url}")
                    req = urllib.request.Request(wheel_url)
                    with urllib.request.urlopen(req, timeout=30) as resp:
                        # Extract original filename from Content-Disposition or URL
                        cd = resp.headers.get("Content-Disposition", "")
                        fname = ""
                        if "filename=" in cd:
                            fname = cd.split("filename=")[-1].strip().strip('"').strip("'")
                        if not fname or not fname.endswith(".whl"):
                            fname = "puvinoise_sdk-0.0.0-py3-none-any.whl"
                        wheel_path = workdir / fname
                        wheel_path.write_bytes(resp.read())
                    cmd = f"{sys.executable} -m pip install -U '{wheel_path}'"
                    print(f"[puvi-bind-sidecar] SDK wheel downloaded → {wheel_path}")
                except Exception as dl_exc:
                    print(f"[puvi-bind-sidecar] SDK wheel download failed: {dl_exc}")
                    cmd = f"{sys.executable} -m pip install -U puvinoise-sdk"
            else:
                cmd = f"{sys.executable} -m pip install -U puvinoise-sdk"

    print(f"[puvi-bind-sidecar] installing/upgrading SDK: {cmd}")
    try:
        result = subprocess.run(
            cmd, shell=True, capture_output=True, text=True, timeout=120,
        )
        if result.returncode != 0:
            print(f"[puvi-bind-sidecar] SDK install failed (exit {result.returncode}): {result.stderr[:500]}")
            return False, version
        # Re-check version after install
        compatible_after, version_after = check_sdk_version_compatibility()
        if compatible_after:
            print(f"[puvi-bind-sidecar] SDK installed successfully: {version_after}")
            return True, version_after
        print(f"[puvi-bind-sidecar] SDK installed but version {version_after} still below minimum")
        return False, version_after
    except subprocess.TimeoutExpired:
        print("[puvi-bind-sidecar] SDK install timed out (120s)")
        return False, version
    except Exception as exc:
        print(f"[puvi-bind-sidecar] SDK install error: {exc}")
        return False, version


# ─────────────────────────────────────────────────────────────────────────────
# GAP 5: Inject PUVINoise SDK instrumentation into run.py
# ─────────────────────────────────────────────────────────────────────────────

INSTRUMENTATION_PREAMBLE = '''\
# ── PUVINoise SDK instrumentation (auto-injected by sidecar) ──────────────
import os as _puvi_os
from pathlib import Path as _PuviPath
try:
    from dotenv import load_dotenv as _puvi_load_dotenv
    _puvi_load_dotenv(_PuviPath(__file__).resolve().parent / ".env", override=True)
except ImportError:
    pass
try:
    import puvinoise
    puvinoise.bootstrap()
except Exception:
    pass
# ── End PUVINoise SDK instrumentation ─────────────────────────────────────
'''

INSTRUMENTATION_MARKER = "PUVINoise SDK instrumentation (auto-injected by sidecar)"


def find_instrumentation_insert_index(lines: list[str]) -> int:
    """
    Line index where instrumentation may be inserted. Python requires `from __future__`
    before any other imports; injecting after shebang only breaks files that use a
    module docstring then __future__ (common pattern).
    """
    i = 0
    n = len(lines)
    if i < n and lines[i].startswith("#!"):
        i += 1
    while i < n and lines[i].strip() == "":
        i += 1
    if i < n and lines[i].strip().startswith("#") and "coding" in lines[i]:
        i += 1
        while i < n and lines[i].strip() == "":
            i += 1
    # Optional module docstring
    if i < n:
        raw = lines[i].lstrip()
        if raw.startswith('"""') or raw.startswith("'''"):
            q = '"""' if raw.startswith('"""') else "'''"
            body = raw[3:]
            if body.rstrip().endswith(q) and body.count(q) >= 1:
                i += 1
            else:
                i += 1
                while i < n:
                    if q in lines[i]:
                        i += 1
                        break
                    i += 1
            while i < n and lines[i].strip() == "":
                i += 1
    # All from __future__ ... statements (may span lines with \\ or parentheses)
    while i < n:
        st = lines[i].strip()
        if st == "":
            i += 1
            continue
        if st.startswith("#"):
            i += 1
            continue
        if not st.startswith("from __future__"):
            break
        start = i
        i += 1
        while i < n and lines[i - 1].rstrip().endswith("\\"):
            i += 1
        paren = 0
        for k in range(start, i):
            paren += lines[k].count("(") - lines[k].count(")")
        while paren > 0 and i < n:
            paren += lines[i].count("(") - lines[i].count(")")
            i += 1
    return i


def inject_instrumentation(agent_file: Path) -> Tuple[bool, str]:
    ok, msg = build_python_wrapper_with_rollback(agent_file)
    if ok and msg == "already instrumented":
        print(f"[puvi-bind-sidecar] run.py already instrumented — skipping injection")
    elif ok:
        print(f"[puvi-bind-sidecar] instrumentation injected into {agent_file.name}")
    else:
        print(f"[puvi-bind-sidecar] instrumentation builder failed: {msg}")
    return ok, msg


# ─────────────────────────────────────────────────────────────────────────────
# GAP 4: Wrapper syntax validation
# ─────────────────────────────────────────────────────────────────────────────

def validate_agent_syntax(agent_file: Path) -> Tuple[bool, str]:
    """
    Run py_compile on the agent file to verify it has no syntax errors.
    Returns (valid: bool, error_message: str).
    """
    if not agent_file.exists():
        return False, f"file not found: {agent_file}"
    try:
        result = subprocess.run(
            [sys.executable, "-m", "py_compile", str(agent_file)],
            capture_output=True, text=True, timeout=15,
        )
        if result.returncode == 0:
            print(f"[puvi-bind-sidecar] syntax check PASS: {agent_file.name}")
            return True, ""
        err = (result.stderr or result.stdout or "unknown compile error").strip()
        print(f"[puvi-bind-sidecar] syntax check FAIL: {agent_file.name}: {err[:300]}")
        return False, err[:500]
    except Exception as exc:
        msg = f"syntax check error: {exc}"
        print(f"[puvi-bind-sidecar] {msg}")
        return False, msg


def validate_agent_imports(agent_file: Path) -> Tuple[bool, str]:
    """
    Dry-run import to catch missing modules (e.g. puvinoise not installed).
    Does NOT execute the agent — only verifies imports resolve.
    """
    if not agent_file.exists():
        return False, f"file not found: {agent_file}"
    try:
        check_code = (
            "import sys, importlib.util; "
            f"spec = importlib.util.spec_from_file_location('_check', '{agent_file}'); "
            "loader = importlib.util.LazyLoader(spec.loader); "
            "spec.loader = loader; "
            "mod = importlib.util.module_from_spec(spec); "
            "print('imports_ok')"
        )
        result = subprocess.run(
            [sys.executable, "-c", check_code],
            capture_output=True, text=True, timeout=15,
            env={**os.environ, "PUVINOISE_BOOTSTRAP_DRY_RUN": "1"},
        )
        if "imports_ok" in (result.stdout or ""):
            print(f"[puvi-bind-sidecar] import check PASS: {agent_file.name}")
            return True, ""
        err = (result.stderr or result.stdout or "import check failed").strip()
        print(f"[puvi-bind-sidecar] import check WARNING: {agent_file.name}: {err[:300]}")
        return False, err[:500]
    except Exception as exc:
        return False, str(exc)


def _parse_env_file_map(env_file: Path) -> Dict[str, str]:
    out: Dict[str, str] = {}
    if not env_file.exists():
        return out
    try:
        for raw in env_file.read_text(encoding="utf-8").splitlines():
            line = raw.strip()
            if not line or line.startswith("#") or "=" not in line:
                continue
            k, v = line.split("=", 1)
            out[k.strip()] = v.strip()
    except Exception:
        return out
    return out


def _write_env_file_map(env_file: Path, env_map: Dict[str, str]) -> None:
    lines = [f"{k}={v}" for k, v in sorted(env_map.items(), key=lambda kv: kv[0])]
    env_file.write_text("\n".join(lines) + "\n", encoding="utf-8")


def auto_repair_bootstrap_env(workdir: Path, platform_url: str, agent_id: str, agent_name: str) -> List[str]:
    # Repair operates on whichever env file is currently in use; prefer branded.
    env_file = resolve_read_env_path(workdir) or canonical_env_path(workdir)
    env_map = _parse_env_file_map(env_file)
    repairs: List[str] = []

    expected_platform = platform_url.rstrip("/")
    if (env_map.get("PUVINOISE_BASE_URL", "") or "").strip() != expected_platform:
        env_map["PUVINOISE_BASE_URL"] = expected_platform
        repairs.append("set PUVINOISE_BASE_URL")
    if ":4318" in (env_map.get("PUVINOISE_BASE_URL", "") or "").strip():
        env_map["PUVINOISE_BASE_URL"] = expected_platform
        repairs.append("fixed malformed PUVINOISE_BASE_URL (removed collector port :4318)")

    if not (env_map.get("PUVINOISE_AGENT_ID", "") or "").strip():
        env_map["PUVINOISE_AGENT_ID"] = agent_id
        repairs.append("set PUVINOISE_AGENT_ID")
    if not (env_map.get("PUVINOISE_AGENT_NAME", "") or "").strip():
        env_map["PUVINOISE_AGENT_NAME"] = agent_name
        repairs.append("set PUVINOISE_AGENT_NAME")

    env_map.setdefault("PUVINOISE_WRAPPER_FILE", "./puvinoise-wrapper.sh")
    env_map.setdefault("PUVINOISE_AGENT_PID_FILE", ".puvinoise_agent.pid")
    if "PUVINOISE_WRAPPER_FILE" not in _parse_env_file_map(env_file):
        repairs.append("set PUVINOISE_WRAPPER_FILE")
    if "PUVINOISE_AGENT_PID_FILE" not in _parse_env_file_map(env_file):
        repairs.append("set PUVINOISE_AGENT_PID_FILE")

    if repairs:
        _write_env_file_map(env_file, env_map)
    return repairs


def evaluate_bootstrap_readiness(
    workdir: Path,
    *,
    sdk_ok: bool,
    sdk_ver: str,
    agent_id: str,
) -> Tuple[bool, List[str]]:
    """
    Strict pre-run readiness gate:
    validates env + wrapper + instrumentation + metadata hints before customer run.
    """
    issues: List[str] = []
    env_file = resolve_read_env_path(workdir) or canonical_env_path(workdir)
    wrapper_file = workdir / "puvinoise-wrapper.sh"
    run_file = workdir / "run.py"

    if not env_file.exists():
        issues.append("missing .env file")
        env_map = {}
    else:
        env_map = _parse_env_file_map(env_file)

    # Required env contract
    required_env = [
        "PUVINOISE_BASE_URL",
        "PUVINOISE_AGENT_NAME",
    ]
    for key in required_env:
        if not (env_map.get(key, "") or "").strip():
            issues.append(f"missing env key: {key}")

    if not (env_map.get("PUVINOISE_API_KEY", "") or "").strip():
        issues.append("missing env key: PUVINOISE_API_KEY")

    platform_url = (env_map.get("PUVINOISE_BASE_URL", "") or "").strip().lower()
    if platform_url and ":4318" in platform_url:
        issues.append("invalid PUVINOISE_BASE_URL uses collector port :4318 (use platform HTTP origin)")

    # Agent identity consistency
    env_agent_id = (env_map.get("PUVINOISE_AGENT_ID", "") or "").strip()
    if agent_id.strip() and env_agent_id and agent_id.strip() != env_agent_id:
        issues.append(f"agent id mismatch: registered={agent_id.strip()} env={env_agent_id}")

    # Wrapper checks
    if not wrapper_file.exists():
        issues.append("missing wrapper file: puvinoise-wrapper.sh")
    else:
        try:
            wrapper_text = wrapper_file.read_text(encoding="utf-8")
            has_run_py = (
                "exec python3 run.py" in wrapper_text
                or "exec python3 -u run.py" in wrapper_text
                or "exec python run.py" in wrapper_text
                or "exec python -u run.py" in wrapper_text
            )
            if not has_run_py:
                issues.append("wrapper missing final exec python(3) run.py")
            if "PUVINOISE_CONTROL_RUNTIME_EXEC" not in wrapper_text:
                issues.append("wrapper missing control runtime export")
        except Exception as exc:
            issues.append(f"cannot read wrapper file: {exc}")

    # Agent entry checks
    if not run_file.exists():
        issues.append("missing run.py")
    else:
        syntax_ok, syntax_err = validate_agent_syntax(run_file)
        if not syntax_ok:
            issues.append(f"run.py syntax invalid: {syntax_err[:160]}")
        if sdk_ok:
            content = run_file.read_text(encoding="utf-8")
            if INSTRUMENTATION_MARKER not in content:
                issues.append("run.py missing PUVINoise instrumentation marker")
            # SDK signature compatibility check (known pitfall)
            if re.search(r"with\s+puvinoise\.run_with_trace\s*\(", content):
                issues.append("run.py uses context-manager run_with_trace; SDK expects fn wrapper style")
            if "intent=" not in content or "goal=" not in content:
                issues.append("run.py trace calls missing intent/goal metadata hints")

    if not sdk_ok:
        issues.append(f"sdk not ready: {sdk_ver}")

    return (len(issues) == 0), issues


def run_trace_emission_probe(workdir: Path, sdk_ok: bool) -> Dict[str, Any]:
    run_file = workdir / "run.py"
    result: Dict[str, Any] = {
        "status": "FAIL",
        "details": [],
        "checkedAt": _now_iso(),
        "instrumentationPath": "none",
    }
    details: List[str] = []
    if not sdk_ok:
        details.append("sdk_not_ready")
        result["details"] = details
        return result
    if not run_file.exists():
        details.append("run.py_missing")
        result["details"] = details
        return result
    try:
        content = run_file.read_text(encoding="utf-8")
    except Exception as exc:
        details.append(f"run_read_error:{exc}")
        result["details"] = details
        return result

    if INSTRUMENTATION_MARKER in content:
        result["instrumentationPath"] = "sidecar_injected"
    elif "puvinoise.bootstrap(" in content:
        result["instrumentationPath"] = "customer_bootstrap"

    if "run_with_trace(" in content:
        details.append("run_with_trace_present")
    if "intent=" in content:
        details.append("intent_present")
    if "goal=" in content:
        details.append("goal_present")
    if "success=" in content:
        details.append("success_present")

    has_min = "run_with_trace_present" in details and "intent_present" in details and "goal_present" in details
    result["status"] = "PASS" if has_min else "WARNING"
    result["details"] = details
    return result


def write_bootstrap_readiness_report(
    workdir: Path,
    ok: bool,
    issues: List[str],
    trace_probe: Optional[Dict[str, Any]] = None,
) -> None:
    report = {
        "ready": bool(ok),
        "checkedAt": _now_iso(),
        "issues": issues,
        "traceProbe": trace_probe or {},
    }
    try:
        (workdir / ".puvinoise_bootstrap_readiness.json").write_text(
            json.dumps(report, indent=2),
            encoding="utf-8",
        )
    except Exception:
        pass


def _access_key_prefix_masked(key: str) -> str:
    k = (key or "").strip()
    if not k:
        return "(empty)"
    return k[:8] + ("…" if len(k) > 8 else "")


def _maybe_reregister_on_401(
    err: Exception,
    platform_url: str,
    registration_token: str,
    agent_name: str,
    deploy_env: str,
    deploy_version: str,
    *,
    approval_max_wait_s: Optional[float],
    workdir: Optional[Path] = None,
) -> Optional[Dict[str, Any]]:
    msg = str(err)
    if "401" not in msg and "Invalid or expired agent access key" not in msg:
        return None
    if not str(registration_token or "").strip():
        print("[puvi-bind-sidecar] access key rejected and no registration token available for re-registration")
        return None
    _wd = (workdir or Path.cwd()).resolve()
    print("[puvi-bind-sidecar] access key rejected; clearing stale state and re-registering")
    _clear_state(_wd)
    try:
        return ensure_registered(
            platform_url,
            registration_token,
            agent_name,
            deploy_env,
            deploy_version,
            approval_max_wait_s=approval_max_wait_s,
            workdir=_wd,
        )
    except Exception as rereg_exc:
        rereg_msg = str(rereg_exc)
        if "already been used" in rereg_msg or "400" in rereg_msg:
            print("[puvi-bind-sidecar] re-registration failed (token already used). Heartbeats will continue with current key.")
            print("[puvi-bind-sidecar] If this persists, generate a new token and restart the sidecar.")
            return None
        raise


def _write_sdk_handoff_state(
    workdir: Path,
    *,
    base_url: str,
    agent_id: str,
    env_id: str,
) -> None:
    """
    Phase E — SDK handoff state file.

    Write a per-agent state file that the SDK and `puvinoise run` read on startup.
    Each agent gets its own file under .puvinoise/agent_<agent_id>.json so that
    multiple agents sharing the same working directory never overwrite each other.

    Canonical contract (only these keys; no credentials or trace URLs):
      env_id, base_url, agent_id

    Raises ``RuntimeError`` on any failure — a missing state file causes silent SDK
    failures downstream, so this must never be swallowed as non-fatal.
    """
    from puvinoise.agent_state import save_agent_state  # local import to avoid cycles

    # No bare except — let RuntimeError propagate so the caller (main) can surface it.
    # save_agent_state returns the resolved absolute path and prints "[puvinoise] wrote file: ..."
    path = save_agent_state(agent_id=agent_id, env_id=env_id, base_url=base_url, workdir=workdir)
    # Hard filesystem confirmation before declaring success.
    if not path.is_file():
        raise RuntimeError(
            f"Agent state file does not exist after write: {path}\n"
            "Check filesystem permissions and disk space."
        )
    print(f"[puvi-bind-sidecar] ✓ Agent config written to:\n  {path}")


def _phase_e_env_only_enabled() -> bool:
    """
    Phase E env-only mode.

    When set, the sidecar refuses to touch the agent's source tree:
      - no run.py injection
      - no wrapper builder invocation
      - no instrumentation marker writes
    Only environment bootstrap + credential handoff are performed.

    Enable via either:
        PUVINOISE_SIDECAR_ENV_ONLY=1
        PUVINOISE_RUNTIME_DRIVEN=1
    """
    for k in ("PUVINOISE_SIDECAR_ENV_ONLY", "PUVINOISE_RUNTIME_DRIVEN"):
        v = os.environ.get(k, "").strip().lower()
        if v in ("1", "true", "yes"):
            return True
    return False


def main() -> None:
    parser = argparse.ArgumentParser(description="PUVINoise bind sidecar (standalone)")
    parser.add_argument("--loop", action="store_true", help="keep sending heartbeat")
    parser.add_argument("--interval", type=int, default=10, help="heartbeat interval seconds")
    parser.add_argument(
        "--heartbeat-log",
        action="store_true",
        help="print a line after each successful POST /api/agent-heartbeat (default: silent on success)",
    )
    parser.add_argument(
        "--allow-noncompliant",
        action="store_true",
        help="do not block startup when bootstrap readiness checks fail",
    )
    parser.add_argument(
        "--env-only",
        action="store_true",
        help="Phase E: only perform environment bootstrap and credential handoff. "
             "No run.py injection, no wrapper-builder invocation. Agent registration "
             "happens when you run the process with `puvinoise run` (SDK loads via sitecustomize) "
             "POSTing to /api/agent-register.",
    )
    args = parser.parse_args()
    # Env var equivalents so operators can switch modes without touching the CLI.
    env_only_mode = bool(args.env_only) or _phase_e_env_only_enabled()

    platform_url = _required_env("PUVINOISE_BASE_URL")
    registration_token = os.getenv("PUVINOISE_REGISTRATION_TOKEN", "").strip()
    # In env-only / bootstrap-only mode the agent hasn't been registered yet, so
    # PUVINOISE_AGENT_NAME is optional.  When it is absent the sidecar performs
    # environment bootstrap only; agent registration happens later when the SDK
    # calls puvinoise.init() (or the operator re-runs the sidecar with the name set).
    if env_only_mode:
        agent_name = os.getenv("PUVINOISE_AGENT_NAME", "").strip()
    else:
        agent_name = _required_env("PUVINOISE_AGENT_NAME")
    # Must match RegistrationToken.environment (Settings → Environment name), not a generic label.
    # Default "Development" breaks bind if the token was minted for another env name.
    deploy_env = (
        os.getenv("PUVINOISE_DEPLOY_ENV", "").strip()
        or os.getenv("PUVINOISE_ENVIRONMENT_NAME", "").strip()
    )
    deploy_version = os.getenv("PUVINOISE_DEPLOY_VERSION", "").strip()

    # Resolve workdir to an absolute canonical path — eliminates symlinks and
    # relative-path ambiguity so all downstream writes land in the same directory
    # regardless of how the interpreter was invoked.
    workdir = Path.cwd().resolve()
    print(f"[puvi-bind-sidecar] project root: {workdir}")

    # Print the installed SDK version so stale-install problems are immediately visible.
    try:
        import importlib.metadata as _imeta
        _sdk_ver_installed = _imeta.version("puvinoise")
    except Exception:
        try:
            import importlib.metadata as _imeta  # noqa: F811
            _sdk_ver_installed = _imeta.version("puvinoise-sdk")
        except Exception:
            _sdk_ver_installed = "not installed / unknown"
    print(f"[puvi-bind-sidecar] sdk version: {_sdk_ver_installed}")

    # ── Bootstrap-only short-circuit ─────────────────────────────────────────────────────────
    # New flow: environment bootstrap runs BEFORE agent registration.
    # --env-only ALWAYS means "environment bootstrap only" — agent registration is intentionally
    # deferred to 'puvinoise run' (SDK init). The previous guard (not agent_name) was a heuristic
    # that broke when PUVINOISE_AGENT_NAME was already set in the shell or .env: the code would
    # fall through to the registration path and demand PUVINOISE_REGISTRATION_TOKEN even though
    # the caller only wanted to bootstrap the environment.
    # PUVINOISE_BOOTSTRAP_TOKEN is used as the Bearer so no agent key is required.
    #
    # bootstrap_only = True when env_only AND no PUVINOISE_REGISTRATION_TOKEN:
    #   → env-level bootstrap only: notify platform, write .puvinoise/env.json, exit.
    #     Content includes env_id/environment/version/region/base_url.
    #     Fails loudly if the file cannot be written.
    #
    # bootstrap_only = False when env_only AND PUVINOISE_REGISTRATION_TOKEN is set:
    #   → agent-level registration without source injection: run full registration flow so
    #     pull_bootstrap_config(), _write_sdk_handoff_state(), etc. all execute and
    #     .env.puvinoise / puvinoise-wrapper.sh / .puvinoise/agent_<id>.json are written.
    #     run.py injection is still skipped by the env_only_mode checks below.
    # ── Env-only mode: warn if stale registration vars are still present ─────────
    # These vars are no longer needed; their presence suggests an old workflow.
    # We warn loudly so developers know to clean them up.
    if env_only_mode:
        _stale_vars = []
        if os.getenv("PUVINOISE_AGENT_NAME", "").strip():
            _stale_vars.append("PUVINOISE_AGENT_NAME")
        if os.getenv("PUVINOISE_REGISTRATION_TOKEN", "").strip():
            _stale_vars.append("PUVINOISE_REGISTRATION_TOKEN")
        if _stale_vars:
            import sys as _sys_warn
            _sys_warn.stderr.write(
                f"[puvi-bind-sidecar] WARNING: --env-only detected but the following "
                f"env vars are set and will be ignored: {', '.join(_stale_vars)}\n"
                "  These variables are no longer required. Agent registration now happens\n"
                "  automatically on the first 'puvinoise run' — no token or name needed here.\n"
                "  You may unset them: "
                + " ".join(f"unset {v}" for v in _stale_vars) + "\n"
            )
            del _sys_warn

    bootstrap_only = env_only_mode and not registration_token
    if bootstrap_only:
        print(
            "[puvi-bind-sidecar] bootstrap-only mode (--env-only, no registration token) — "
            "performing environment-level bootstrap only. "
            "Agent registration happens on first 'puvinoise run' (SDK init)."
        )
        _bootstrap_token = os.getenv("PUVINOISE_BOOTSTRAP_TOKEN", "").strip()
        _sidecar_env_id = os.getenv("PUVINOISE_ENV_ID", "").strip()

        # Step 1: CREATED → PENDING (request-approval-sdk)
        #
        # This call is only meaningful when the environment has NOT yet been approved.
        # In the standard onboarding flow the operator clicks "Generate Bootstrap Token"
        # in the UI *before* running the sidecar — that action already moves the env to
        # APPROVED and issues the bootstrap token, so PUVINOISE_BOOTSTRAP_TOKEN is set.
        # Calling request-approval-sdk on an already-APPROVED env is a no-op at best and
        # causes a 401 at worst (bootstrap token is not accepted as a Bearer on that endpoint).
        #
        # Decision tree:
        #   bootstrap_token set   → env is already APPROVED  → skip (nothing to do)
        #   registration_token set → env may be CREATED      → request approval via reg token Bearer
        #   neither set           → skip with informational message
        if _sidecar_env_id:
            if _bootstrap_token:
                # Env already approved by the admin — bootstrap token proves it.
                # request-approval-sdk (CREATED → PENDING) is not needed; skip to avoid
                # a spurious 401 on an already-APPROVED environment.
                pass
            elif registration_token:
                # No bootstrap token yet: env may still be CREATED.
                # Request approval using the registration token so the admin sees it in the UI.
                _request_environment_approval(platform_url, registration_token, _sidecar_env_id)
            else:
                print(
                    "[puvi-bind-sidecar] skipping request-approval-sdk: "
                    "PUVINOISE_REGISTRATION_TOKEN and PUVINOISE_BOOTSTRAP_TOKEN are both unset. "
                    "Approve the environment in the PUVINoise UI (Settings → Environments) "
                    "and set PUVINOISE_BOOTSTRAP_TOKEN, then re-run."
                )

        # Step 2: APPROVED → BOOTSTRAPPED — bootstrap token must be set (issued after admin approval).
        # If not yet issued, this is a no-op; re-run the sidecar after admin approves.
        _bootstrap_ok = False
        if _bootstrap_token:
            _bootstrap_ok = _notify_bootstrap_complete(
                platform_url,
                access_key=_bootstrap_token,
                agent_id="",
                deploy_env=deploy_env,
                sdk_ver="",
                ready_issues=[],
            )
        else:
            print(
                "[puvi-bind-sidecar] PUVINOISE_BOOTSTRAP_TOKEN not set — "
                "environment approval pending. Re-run after admin approves the environment."
            )

        if _bootstrap_ok:
            # Write .puvinoise/env.json — the ONLY local file created in env-only mode.
            # This file is the authoritative local state the SDK reads on startup.
            # A missing file means the bootstrap silently failed; we treat that as fatal.
            from puvinoise.agent_state import save_env_state as _save_env_state
            try:
                # save_env_state returns the resolved absolute path and prints it internally.
                _env_state_path = _save_env_state(
                    env_id=_sidecar_env_id,
                    base_url=platform_url,
                    workdir=workdir,
                    environment=deploy_env,
                    deploy_version=deploy_version,
                    region=os.getenv("PUVINOISE_REGION", "").strip(),
                )
            except RuntimeError as _state_exc:
                print(
                    f"[puvi-bind-sidecar] ✗ FATAL: could not write environment state: {_state_exc}\n"
                    "Bootstrap reported success but the local config file was not created. "
                    "Fix the error above and re-run puvinoise-bind."
                )
                sys.exit(1)

            # Hard filesystem confirmation — the success message is ONLY printed
            # after we verify the file actually exists at the resolved absolute path.
            if not _env_state_path.is_file():
                print(
                    f"[puvi-bind-sidecar] ✗ FATAL: file does not exist after write: {_env_state_path}\n"
                    "This is a filesystem-level failure. Check permissions and disk space."
                )
                sys.exit(1)

            print(
                f"[puvi-bind-sidecar] ✓ Environment config written to:\n"
                f"  {_env_state_path}"
            )
            print(
                "[puvi-bind-sidecar] ✓ bootstrap-only mode complete. "
                "Set PUVINOISE_AGENT_NAME (and PUVINOISE_REGISTRATION_TOKEN if first bind) "
                "then run 'puvinoise run' to register and start the agent."
            )
        else:
            print(
                "[puvi-bind-sidecar] ✗ bootstrap-only mode: environment bootstrap did NOT complete. "
                "Check the errors above. Common causes:\n"
                "  • PUVINOISE_BOOTSTRAP_TOKEN is expired or invalid — "
                "generate a fresh token in the PUVINoise UI (Settings → Environments → Approve/Reissue).\n"
                "  • The server is unreachable at PUVINOISE_BASE_URL.\n"
                "  • Admin has not yet approved the environment — approve it in the UI first."
            )
            sys.exit(1)
        return

    # Register Agent UI (GET /api/registration-bind-intent-status) needs bindIntentAt on the token.
    # Cached registration skips the branch below that used to call emit_probe — so restarts never
    # notified the UI. Always probe when a token is present (idempotent on the server).
    if registration_token:
        try:
            emit_probe(platform_url, registration_token, agent_name, deploy_env, deploy_version)
        except Exception as exc:
            print(f"[puvi-bind-sidecar] bind intent probe non-fatal: {exc}")

    # Until an admin approves the bind in the UI, /api/register returns 409. --loop waits forever; one-shot waits ~4 min.
    reg_approval_max: Optional[float] = None if args.loop else 240.0

    cached = _load_state(workdir)
    cached_token = str(cached.get("registration_token", "")).strip()
    # If caller provides a token, honor token rotation / fresh bind intent and avoid stale cache reuse.
    token_mismatch = bool(registration_token) and cached_token and cached_token != registration_token
    cached_matches = (
        str(cached.get("platform_url", "")).strip() == platform_url.rstrip("/")
        and str(cached.get("agent_name", "")).strip() == agent_name
        and str(cached.get("deploy_env", "")).strip() == deploy_env
        and str(cached.get("agent_id", "")).strip()
        and str(cached.get("agent_access_key", "")).strip()
        and not token_mismatch
    )
    if cached_matches:
        state = cached
        print("[puvi-bind-sidecar] using cached registration state (token not required for restart)")
    else:
        if token_mismatch:
            print("[puvi-bind-sidecar] registration token changed; ignoring cached registration state")
        recovered = _try_recover_state_from_dotenv(
            platform_url, agent_name, deploy_env, deploy_version, workdir
        )
        if recovered:
            state = recovered
            _save_state(state, workdir)
            print(
                "[puvi-bind-sidecar] recovered registration from .env / environment "
                f"({PERSISTENT_STATE_BASENAME} + temp cache repopulated; token not required)"
            )
        elif not registration_token:
            raise RuntimeError(
                "Missing PUVINOISE_REGISTRATION_TOKEN and no cached or recoverable registration state found. "
                "Ensure .env in this directory contains PUVINOISE_BASE_URL, PUVINOISE_AGENT_ID, and "
                "PUVINOISE_API_KEY after a successful bind, or generate a new registration token from "
                "the product (Settings → Agents → Agent setup / runtime bind flow)."
            )
        else:
            state = ensure_registered(
                platform_url,
                registration_token,
                agent_name,
                deploy_env,
                deploy_version,
                approval_max_wait_s=reg_approval_max,
                workdir=workdir,
            )
    aid = str(state["agent_id"])
    key = str(state["agent_access_key"])
    if not key.strip():
        print("[puvi-bind-sidecar] missing access key after load; re-registering")
        _clear_state(workdir)
        state = ensure_registered(
            platform_url,
            registration_token,
            agent_name,
            deploy_env,
            deploy_version,
            approval_max_wait_s=reg_approval_max,
            workdir=workdir,
        )
        aid = str(state["agent_id"])
        key = str(state["agent_access_key"])

    print(f"[puvi-bind-sidecar] access key prefix={_access_key_prefix_masked(key)}")

    # ── Post-registration bootstrap: pull config, install SDK, validate ──
    print(f"[puvi-bind-sidecar] agent workdir: {workdir}")

    agent_entry = workdir / "run.py"
    if not agent_entry.exists():
        print(f"[puvi-bind-sidecar] ⚠ WARNING: run.py not found in {workdir}")
        print(f"[puvi-bind-sidecar] The sidecar writes .env, installs SDK, and validates the wrapper")
        print(f"[puvi-bind-sidecar] relative to the current working directory.")
        print(f"[puvi-bind-sidecar] Make sure you run the sidecar FROM your agent directory that")
        print(f"[puvi-bind-sidecar] contains run.py (your agent entry file).")
        _py_exe = "python" if sys.platform == "win32" else "python3"
        print(f"[puvi-bind-sidecar] Example: cd /path/to/{agent_name} && {_py_exe} -u puvi_bind_sidecar.py --loop")
        print(f"[puvi-bind-sidecar] Continuing with bootstrap anyway — .env and SDK will be written here.")

    # ── Bootstrap file tracking — collected for POST /api/agent/bootstrap-complete ─
    # Initialise to False; each stage sets its flag when the corresponding file is
    # confirmed on disk.  All four are required for bootstrapFilesConfirmed = true.
    env_written: bool = False
    wrapper_written: bool = False
    run_py_instrumented: bool = False
    # readiness_gate_passed is assigned below from ready_ok

    # GAP 1: Pull bootstrap config (.env, wrapper, restart scripts)
    sdk_install_cmd = ""
    try:
        cfg = pull_bootstrap_config(platform_url, key, aid, agent_name, workdir)
        sdk_install_cmd = str(cfg.get("sdkInstallLatestCommand") or "").strip()
    except Exception as exc:
        print(f"[puvi-bind-sidecar] bootstrap config pull non-fatal: {exc}")

    # Update bootstrap tracking flags from what pull_bootstrap_config() wrote.
    # Check file existence immediately after the call so we capture the current
    # state of the working directory, whether the files were written just now or
    # on a previous run (idempotent restarts).
    # Branded or legacy env file counts as "written" so upgraded workdirs
    # don't regress to MISSING on the first restart after the rename.
    env_written     = resolve_read_env_path(workdir) is not None
    wrapper_written = (workdir / "puvinoise-wrapper.sh").exists()

    # GAP 3: Install/upgrade PUVINoise SDK
    sdk_ok, sdk_ver = ensure_sdk_installed(sdk_install_cmd)
    if sdk_ok:
        print(f"[puvi-bind-sidecar] SDK ready: {sdk_ver}")
    else:
        print(f"[puvi-bind-sidecar] WARNING: SDK not available or below minimum ({sdk_ver})")
        print(f"[puvi-bind-sidecar] The agent may fail to emit telemetry. Install manually:")
        print(f"[puvi-bind-sidecar]   {sdk_install_cmd or 'python -m pip install -U puvinoise-sdk'}")

    # Phase E: write the SDK handoff state file as soon as we have identity
    # + env_id. This is the file the SDK's agent_autoregister module reads.
    sidecar_env_id_phaseE = os.getenv("PUVINOISE_ENV_ID", "").strip()
    if sidecar_env_id_phaseE:
        try:
            _write_sdk_handoff_state(
                workdir,
                base_url=platform_url,
                agent_id=aid,
                env_id=sidecar_env_id_phaseE,
            )
        except RuntimeError as _hw_exc:
            print(
                f"[puvi-bind-sidecar] ✗ FATAL: agent state file write failed: {_hw_exc}\n"
                "The agent cannot start without a valid .puvinoise/agent_<id>.json file. "
                "Check directory permissions and disk space, then re-run puvinoise-bind."
            )
            sys.exit(1)

    # Phase E env-only mode: skip ALL file-based instrumentation.
    # In this mode the SDK itself (via puvinoise.init()) is responsible for
    # registering the agent and emitting telemetry. The sidecar's only remaining
    # job is environment bootstrap + credential handoff, completed above.
    if env_only_mode:
        print(
            "[puvi-bind-sidecar] env-only mode: skipping run.py injection, "
            "wrapper builder, and syntax validation. SDK will auto-register on init()."
        )
        agent_file = workdir / "run.py"  # referenced below for legacy compat only
    else:
        # ── Legacy file-based instrumentation (deprecated in Phase E) ───────
        # This path remains for backward compatibility with the TestAgent/
        # demo agents that still ship a run.py. New deployments should pass
        # --env-only or set PUVINOISE_SIDECAR_ENV_ONLY=1 and let the SDK
        # handle registration + telemetry from inside the agent process.
        agent_file = workdir / "run.py"
        if agent_file.exists() and sdk_ok:
            inj_ok, inj_msg = inject_instrumentation(agent_file)
            if inj_ok:
                run_py_instrumented = True
                print(f"[puvi-bind-sidecar] instrumentation: {inj_msg}")
            else:
                print(f"[puvi-bind-sidecar] instrumentation injection failed: {inj_msg}")

    # GAP 4: Validate agent file syntax if run.py exists (skipped in env-only mode)
    if not env_only_mode and agent_file.exists():
        syntax_ok, syntax_err = validate_agent_syntax(agent_file)
        if not syntax_ok:
            print(f"[puvi-bind-sidecar] CRITICAL: run.py has syntax errors — agent will not start!")
            print(f"[puvi-bind-sidecar] Error: {syntax_err}")
            broken_backup = workdir / "run.py.broken"
            shutil.copy2(str(agent_file), str(broken_backup))
            print(f"[puvi-bind-sidecar] Broken file backed up to {broken_backup}")
            # Restore from backup
            original_file = workdir / "run_original.py"
            if original_file.exists():
                shutil.copy2(str(original_file), str(agent_file))
                print(f"[puvi-bind-sidecar] Restored run.py from run_original.py")
        else:
            if sdk_ok:
                import_ok, import_err = validate_agent_imports(agent_file)
                if not import_ok:
                    print(f"[puvi-bind-sidecar] WARNING: run.py import check failed: {import_err[:200]}")
                    print(f"[puvi-bind-sidecar] The wrapper may be incompatible with SDK {sdk_ver}")

    # Auto-repair common bootstrap defects before readiness gate
    repairs = auto_repair_bootstrap_env(workdir, platform_url, aid, agent_name)
    if repairs:
        print("[puvi-bind-sidecar] auto-repair applied:")
        for item in repairs:
            print(f"[puvi-bind-sidecar]   - {item}")

    # Bootstrap readiness gate (after pull + install + injection, before runtime handoff)
    # In env-only mode we intentionally skip run.py/wrapper checks.
    if env_only_mode:
        ready_ok, ready_issues = True, []
    else:
        ready_ok, ready_issues = evaluate_bootstrap_readiness(
            workdir,
            sdk_ok=sdk_ok,
            sdk_ver=sdk_ver,
            agent_id=aid,
        )
    trace_probe = run_trace_emission_probe(workdir, sdk_ok=sdk_ok)
    print(f"[puvi-bind-sidecar] trace probe {trace_probe.get('status', 'UNKNOWN')}")
    write_bootstrap_readiness_report(workdir, ready_ok, ready_issues, trace_probe=trace_probe)
    if ready_ok:
        print("[puvi-bind-sidecar] readiness gate PASS")
    else:
        print("[puvi-bind-sidecar] readiness gate FAIL")
        for issue in ready_issues:
            print(f"[puvi-bind-sidecar]   - {issue}")
        if not args.allow_noncompliant:
            raise RuntimeError(
                "Bootstrap readiness checks failed. "
                "Fix issues above and re-run sidecar (or use --allow-noncompliant to continue)."
            )

    # Report runtime metadata — pass the real installed SDK version so the platform
    # stores the actual puvinoise-sdk PyPI version, not the sidecar placeholder.
    try:
        report_runtime_metadata(platform_url, key, aid, agent_name, deploy_env, deploy_version,
                                installed_sdk_version=sdk_ver if sdk_ok else "",
                                readiness_ok=ready_ok,
                                readiness_issues=ready_issues,
                                trace_probe_status=str(trace_probe.get("status", "")),
                                trace_probe_details=[str(x) for x in (trace_probe.get("details") or [])])
    except Exception as exc:
        print(f"[puvi-bind-sidecar] metadata report non-fatal: {exc}")

    # ── Environment-first lifecycle step 1: CREATED → PENDING ──────────────────────────────
    # Notify the platform that the sidecar has started and is awaiting admin approval.
    # This matches the flowchart: "Sidecar → Register Environment → Mark env PENDING_APPROVAL".
    # The server endpoint is idempotent — if already PENDING+ it returns 200 with no harm.
    sidecar_env_id = os.getenv("PUVINOISE_ENV_ID", "").strip()
    if sidecar_env_id:
        _request_environment_approval(platform_url, key, sidecar_env_id)

    # ── Environment-first lifecycle step 2: APPROVED → BOOTSTRAPPED ─────────────────────────
    # Notify the platform that bootstrap is complete so that agents may register.
    # PUVINOISE_ENV_ID and PUVINOISE_BOOTSTRAP_TOKEN must be set in .env or environment.
    # Gap 5 fix: pass ready_issues so missing vars are surfaced in the readiness report.
    _notify_bootstrap_complete(platform_url, key, aid, deploy_env, sdk_ver if sdk_ok else "", ready_issues=ready_issues)

    # ── Agent bootstrap file confirmation ────────────────────────────────────────────────────
    # POST the per-file status to the server so it can gate ACC command dispatch.
    # Appears between "readiness gate PASS" and "ready agent_id=..." in the log.
    # In env-only mode run.py instrumentation is intentionally skipped; the gate
    # still passes because env_written + wrapper_written + readiness_gate_passed
    # are the three signals the server cares about for ACC.
    _report_bootstrap_complete(
        server_url=platform_url,
        agent_id=aid,
        access_key=key,
        env_written=env_written,
        wrapper_written=wrapper_written,
        run_py_instrumented=run_py_instrumented if not env_only_mode else True,
        sdk_version=sdk_ver if sdk_ok else "",
        readiness_gate_passed=ready_ok,
    )

    # First heartbeat
    try:
        send_heartbeat(platform_url, key, aid, deploy_env, installed_sdk_version=sdk_ver if sdk_ok else "")
    except Exception as exc:
        refreshed = _maybe_reregister_on_401(
            exc, platform_url, registration_token, agent_name, deploy_env, deploy_version,
            approval_max_wait_s=reg_approval_max,
            workdir=workdir,
        )
        if refreshed:
            aid = str(refreshed.get("agent_id", aid))
            key = str(refreshed.get("agent_access_key", key))
            print(f"[puvi-bind-sidecar] access key prefix={_access_key_prefix_masked(key)}")
            try:
                send_heartbeat(platform_url, key, aid, deploy_env, installed_sdk_version=sdk_ver if sdk_ok else "")
            except Exception as hb2:
                print(f"[puvi-bind-sidecar] first heartbeat still failing: {hb2}")
        elif "401" in str(exc) or "Invalid or expired" in str(exc):
            print(f"[puvi-bind-sidecar] first heartbeat 401 but re-registration skipped (token may be reused). Continuing with loop.")
        else:
            print(f"[puvi-bind-sidecar] first heartbeat error (non-fatal): {exc}")

    print(f"[puvi-bind-sidecar] ready agent_id={aid}")
    print(f"[puvi-bind-sidecar] bootstrap summary:")
    _env_resolved = resolve_read_env_path(workdir)
    _env_display = _env_resolved.name if _env_resolved else f"{PUVI_ENV_BRANDED_NAME} (missing)"
    print(f"  env:     {'OK' if _env_resolved else 'MISSING'}  [{_env_display}]")
    print(f"  SDK:     {sdk_ver} ({'OK' if sdk_ok else 'NEEDS INSTALL'})")
    print(f"  run.py:  {'exists' if (workdir / 'run.py').exists() else 'MISSING'}")
    print(f"  wrapper: {'exists' if (workdir / 'puvinoise-wrapper.sh').exists() else 'MISSING'}")

    if not args.loop:
        return
    # All heartbeat loop messages go to stderr — sidecar runs alongside the agent
    # process and must not pollute the agent's stdout with system-level chatter.
    sys.stderr.write(f"[puvi-bind-sidecar] heartbeat loop interval={args.interval}s\n")
    sys.stderr.flush()
    if not args.heartbeat_log:
        sys.stderr.write("[puvi-bind-sidecar] (heartbeats are quiet on success; use --heartbeat-log to print each tick)\n")
        sys.stderr.flush()
    while True:
        if not str(key).strip():
            sys.stderr.write("[puvi-bind-sidecar] missing access key in heartbeat loop; re-registering\n")
            sys.stderr.flush()
            _clear_state(workdir)
            state = ensure_registered(
                platform_url,
                registration_token,
                agent_name,
                deploy_env,
                deploy_version,
                approval_max_wait_s=reg_approval_max,
                workdir=workdir,
            )
            aid = str(state["agent_id"])
            key = str(state["agent_access_key"])
        try:
            send_heartbeat(platform_url, key, aid, deploy_env, installed_sdk_version=sdk_ver if sdk_ok else "")
            if args.heartbeat_log:
                sys.stderr.write("[puvi-bind-sidecar] heartbeat ok\n")
                sys.stderr.flush()
        except Exception as exc:
            refreshed = _maybe_reregister_on_401(
                exc,
                platform_url,
                registration_token,
                agent_name,
                deploy_env,
                deploy_version,
                approval_max_wait_s=reg_approval_max,
                workdir=workdir,
            )
            if refreshed:
                aid = str(refreshed.get("agent_id", aid))
                key = str(refreshed.get("agent_access_key", key))
                try:
                    report_runtime_metadata(platform_url, key, aid, agent_name, deploy_env, deploy_version,
                                            installed_sdk_version=sdk_ver if sdk_ok else "",
                                            readiness_ok=ready_ok,
                                            readiness_issues=ready_issues,
                                            trace_probe_status=str(trace_probe.get("status", "")),
                                            trace_probe_details=[str(x) for x in (trace_probe.get("details") or [])])
                except Exception as meta_exc:
                    sys.stderr.write(f"[puvi-bind-sidecar] metadata report non-fatal after re-register: {meta_exc}\n")
                    sys.stderr.flush()
                try:
                    send_heartbeat(platform_url, key, aid, deploy_env, installed_sdk_version=sdk_ver if sdk_ok else "")
                except Exception as hb_exc:
                    sys.stderr.write(f"[puvi-bind-sidecar] heartbeat error after re-register: {hb_exc}\n")
                    sys.stderr.flush()
            else:
                sys.stderr.write(f"[puvi-bind-sidecar] heartbeat error: {exc}\n")
                sys.stderr.flush()
        time.sleep(max(3, args.interval))


if __name__ == "__main__":
    main()
