"""Quick smoke test — run with: python test_live.py"""
import asyncio
from tompo_mcp.auth import TokenProvider
from tompo_mcp.core.fabric_client import FabricClient


async def test():
    tp = TokenProvider()
    client = FabricClient(tp)

    print("Fetching workspaces...")
    ws = await client.list_workspaces()
    print(f"Found {len(ws)} workspaces:")
    for w in ws[:10]:
        print(f"  - {w.get('name')} ({w.get('id')})")
    if len(ws) > 10:
        print(f"  ... and {len(ws) - 10} more")


asyncio.run(test())
