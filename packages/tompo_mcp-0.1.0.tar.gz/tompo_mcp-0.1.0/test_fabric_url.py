"""Test getDefinition with correct Fabric REST API URL."""
import asyncio
import httpx
from tompo_mcp.auth import TokenProvider

async def test():
    tp = TokenProvider()
    fabric_token = tp.get_fabric_token()
    
    ws = "7899d04f-b333-4e85-848d-49d45569d179"
    ds = "80c0f966-729e-46ba-bc26-676902fdecff"
    
    url = f"https://api.fabric.microsoft.com/v1/workspaces/{ws}/semanticModels/{ds}/getDefinition"
    headers = {"Authorization": f"Bearer {fabric_token}", "Content-Type": "application/json"}
    
    async with httpx.AsyncClient(timeout=300) as client:
        r = await client.post(url, headers=headers)
        print(f"Fabric API: {r.status_code}")
        loc = r.headers.get("Location", "")
        retry = int(r.headers.get("Retry-After", "3"))
        print(f"Location: {loc}")
        print(f"Retry-After: {retry}")
        
        if r.status_code == 202 and loc:
            await asyncio.sleep(retry)
            poll = await client.get(loc, headers=headers)
            print(f"Poll: {poll.status_code}")
            if poll.status_code == 200:
                body = poll.json()
                print(f"Response keys: {list(body.keys())}")
                defn = body.get("definition", {})
                print(f"Definition keys: {list(defn.keys()) if defn else 'None'}")
                parts = defn.get("parts", [])
                fmt = defn.get("format")
                print(f"Format: {fmt}")
                print(f"Parts count: {len(parts)}")
                for p in parts[:5]:
                    print(f"  - {p.get('path')}")
                # Check for result location header
                res_loc = poll.headers.get("Location", "")
                print(f"Result Location: {res_loc}")
                if not parts and not fmt and res_loc:
                    import json
                    # Follow result location
                    res_resp = await client.get(res_loc, headers=headers)
                    print(f"Result resp: {res_resp.status_code}")
                    if res_resp.status_code == 200:
                        res_body = res_resp.json()
                        rdefn = res_body.get("definition", {})
                        rparts = rdefn.get("parts", [])
                        print(f"Result Format: {rdefn.get('format')}")
                        print(f"Result Parts: {len(rparts)}")
                        for p in rparts[:5]:
                            print(f"  - {p.get('path')}")
            elif poll.status_code == 202:
                print("Still running, waiting more...")
                await asyncio.sleep(retry)
                poll2 = await client.get(loc, headers=headers)
                print(f"Poll2: {poll2.status_code}")
                if poll2.status_code == 200:
                    body = poll2.json()
                    defn = body.get("definition", {})
                    parts = defn.get("parts", [])
                    print(f"Format: {defn.get('format')}, Parts: {len(parts)}")
        elif r.status_code == 200:
            body = r.json()
            defn = body.get("definition", {})
            parts = defn.get("parts", [])
            print(f"Direct response - Format: {defn.get('format')}, Parts: {len(parts)}")
        else:
            print(f"Body: {r.text[:500]}")

asyncio.run(test())
