from decimal import Decimal

from foodeo_core.commands.services.price_and_discount import PriceAndDiscountService
from foodeo_core.shared.entities.pricing import (
    PricingContext,
    PricingResult,
    PricingViolation,
    PricingViolationCode,
    PromotionSnapshot,
)
from foodeo_core.shared.enums import DiscountEnum, RequestEnum
from foodeo_core.shared.helpers import normalize

VERIFACTU_FISCAL_INTEGRATION = "sign_es_verifactu"


class RequestPricingService:
    @classmethod
    def calculate(
            cls,
            request_or_command,
            context: PricingContext,
            promotion: PromotionSnapshot | None = None,
    ) -> PricingResult:
        original_price, request_price = PriceAndDiscountService.get_price_and_discount(request_or_command)

        request_price = normalize(request_price)
        original_price = normalize(original_price)
        manual_discount = normalize(original_price - request_price)

        promotion_discount = Decimal("0")
        if promotion and promotion.enabled:
            promotion_discount = cls._calculate_promotion_discount(request_price, promotion)
            request_price = normalize(max(Decimal("0"), request_price - promotion_discount))

        request_price_before_service = request_price
        service_charge = Decimal("0")
        violations: list[PricingViolation] = []

        if cls._requires_service_charge(context):
            service_charge = normalize(context.service_charge)
            request_price = normalize(request_price + service_charge)
            if context.minimal_amount is not None and request_price < context.minimal_amount:
                violations.append(
                    PricingViolation(
                        code=PricingViolationCode.MINIMAL_AMOUNT_NOT_REACHED,
                        message=f"The order price must be greater than or equal to {context.minimal_amount}",
                    )
                )

        if cls._exceeds_max_amount(context, request_price):
            violations.append(
                PricingViolation(
                    code=PricingViolationCode.MAX_AMOUNT_EXCEEDED,
                    message=f"The command amount cannot exceed {context.max_amount}",
                )
            )

        return PricingResult(
            original_price=original_price,
            request_price=request_price,
            request_price_before_service=request_price_before_service,
            manual_discount=manual_discount,
            promotion_discount=promotion_discount,
            service_charge=service_charge,
            violations=violations,
        )

    @classmethod
    def _calculate_promotion_discount(cls, request_price: Decimal, promotion: PromotionSnapshot) -> Decimal:
        if promotion.discount_type == DiscountEnum.percentage:
            return normalize(request_price * promotion.price / Decimal("100"))
        return normalize(min(request_price, promotion.price))

    @classmethod
    def _requires_service_charge(cls, context: PricingContext) -> bool:
        return context.request_type == RequestEnum.domicile

    @classmethod
    def _exceeds_max_amount(cls, context: PricingContext, request_price: Decimal) -> bool:
        return (
                context.fiscal_integration == VERIFACTU_FISCAL_INTEGRATION
                and context.max_amount is not None
                and request_price > context.max_amount
        )
