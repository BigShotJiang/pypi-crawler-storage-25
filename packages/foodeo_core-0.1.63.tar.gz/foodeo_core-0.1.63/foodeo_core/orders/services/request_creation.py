from foodeo_core.shared.entities.request_creation import RequestCreationContext, RequestCreationResult
from foodeo_core.shared.enums import FromClientEnum, RequestEnum, StatusEnum


class RequestCreationPolicy:
    @classmethod
    def resolve(cls, request_model, context: RequestCreationContext) -> RequestCreationResult:
        match request_model.type:
            case RequestEnum.local:
                return cls._resolve_local(request_model, context)
            case RequestEnum.barra | RequestEnum.kiosko:
                return cls._resolve_barra_like(request_model, context)
            case RequestEnum.pickup:
                return cls._resolve_pickup(request_model, context)
            case RequestEnum.domicile:
                return cls._resolve_domicile(request_model, context)

        raise ValueError(f"Unsupported request type: {request_model.type}")

    @classmethod
    def _resolve_local(cls, request_model, context: RequestCreationContext) -> RequestCreationResult:
        employee = None
        if request_model.from_client in [FromClientEnum.web, FromClientEnum.apk]:
            if context.select_employee_before_order:
                employee = request_model.worker if request_model.worker is not None else request_model.user_id
            else:
                employee = request_model.user_id

        client = None
        if request_model.from_client == FromClientEnum.web_sales or (
                request_model.from_client == FromClientEnum.apk and context.user_is_client
        ):
            client = request_model.user_id

        status = StatusEnum.requested
        return RequestCreationResult(status=status, employee=employee, client=client)

    @classmethod
    def _resolve_barra_like(cls, request_model, context: RequestCreationContext) -> RequestCreationResult:
        employee = request_model.user_id
        if context.select_employee_before_order:
            employee = request_model.worker if request_model.worker is not None else request_model.user_id

        status = StatusEnum.closed if context.close_barra_order_auto else StatusEnum.requested
        return RequestCreationResult(
            status=status,
            employee=employee,
            client=request_model.client,
        )

    @classmethod
    def _resolve_pickup(cls, request_model, context: RequestCreationContext) -> RequestCreationResult:
        employee = None
        if request_model.from_client == FromClientEnum.web:
            if context.select_employee_before_order:
                employee = request_model.worker
            else:
                employee = request_model.user_id

        if request_model.from_client == FromClientEnum.web_sales:
            client = request_model.user_id
        elif not context.request_without_client_pickup or request_model.client:
            client = request_model.client
        else:
            client = context.default_client_id

        status = StatusEnum.requested
        if request_model.from_client == FromClientEnum.web_sales and not context.auto_accept_pickup:
            status = StatusEnum.draft

        return RequestCreationResult(status=status, employee=employee, client=client)

    @classmethod
    def _resolve_domicile(cls, request_model, context: RequestCreationContext) -> RequestCreationResult:
        employee = None
        if request_model.from_client == FromClientEnum.web:
            if context.select_employee_before_order:
                employee = request_model.worker
            else:
                employee = request_model.user_id

        if request_model.from_client == FromClientEnum.web_sales:
            client = request_model.user_id
            address = request_model.address
        elif not context.request_without_client_domicile or (request_model.client and request_model.address):
            client = request_model.client
            address = request_model.address
        else:
            client = context.default_client_id
            address = context.default_address_id

        status = StatusEnum.requested
        if request_model.from_client == FromClientEnum.web_sales and not context.auto_accept_domicile:
            status = StatusEnum.draft

        return RequestCreationResult(
            status=status,
            employee=employee,
            client=client,
            address=address,
            dealer=request_model.dealer if request_model.dealer else None,
            domicile_price=context.domicile_service_price,
        )
