from decimal import Decimal

from pydantic import BaseModel


class CashlogyContentExtras(BaseModel):
    tpv: str
    local_id: int
    command_id: int
    user_id: int
    user_token: str
    web_client: str


class CashlogyContentData(BaseModel):
    raw_message: str
    execution_message: str
    auto_charged_amount: int = 0
    refunded_amount: int = 0
    manual_charged_amount: int = 0
    changes_added: int = 0
    card_charged_amount: Decimal = 0


class CashlogyResponseEntity(BaseModel):
    operation: int
    data: CashlogyContentData
    extras: CashlogyContentExtras
