from uuid import UUID

from pydantic import BaseModel

from foodeo_core.payments.entities.fiskaly.sign_es.fiskaly_item import InvoiceItemData


class CorrectingInvoiceData(BaseModel):
    type: str
    number: str
    series: str
    text: str
    full_amount: str
    issued_at: str
    items: list[InvoiceItemData]


class ContentCorrectingInvoiceData(BaseModel):
    type: str
    id: UUID
    method: str
    invoice: CorrectingInvoiceData


class MetadataCorrectingInvoiceData(BaseModel):
    local_key: str
    local_tax_number: str
    command_id: str
    payment_id: str
    economic_subscription_id: str
    modified_invoice_id: str


class CorrectingInvoiceEntity(BaseModel):
    content: ContentCorrectingInvoiceData
    metadata: MetadataCorrectingInvoiceData
