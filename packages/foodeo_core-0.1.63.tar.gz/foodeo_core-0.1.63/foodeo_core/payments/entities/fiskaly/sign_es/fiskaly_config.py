from uuid import UUID

from pydantic import BaseModel


class FiskalyEsConfigData(BaseModel):
    secret_key: str
    api_key: str
    fiskaly_client_id: UUID
