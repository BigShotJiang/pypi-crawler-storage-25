from datetime import datetime
from decimal import Decimal
from typing import Optional
from uuid import UUID

from pydantic import BaseModel


class FiskalyEsCommandEntity(BaseModel):
    id: int
    serial: str
    all_discounted: bool
    discount_type: Optional[str] = None
    original_price: Decimal
    discount: Optional[Decimal] = None
    type: str


class FiskalyEsPaymentEntity(BaseModel):
    id: int
    serial: str
    importe: Decimal
    fiskaly_invoice_id: Optional[UUID] = None
    fiskaly_remedy_invoice_id: Optional[UUID] = None
    fiskaly_invoice_status: Optional[str] = None
    fiskaly_remedy: bool = False
    created_at: datetime
    command_payment: FiskalyEsCommandEntity


class FiskalyEsEconomicSubscriptionEntity(BaseModel):
    id: int
    fiskaly_modified_invoice_id: Optional[UUID] = None
    fiskaly_correcting_invoice_id: Optional[UUID] = None
    fiskaly_correcting_invoice_status: Optional[str] = None
    serial: str
    amount: Decimal
    created_at: datetime
    economic_subscription_payment: FiskalyEsPaymentEntity


class FiskalyEsPromotionEntity(BaseModel):
    discount_type: str
    price: Decimal


class FiskalyEsLocalEntity(BaseModel):
    id: int
    name: str
    key: UUID
    database: str
