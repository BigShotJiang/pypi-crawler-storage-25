from pydantic import BaseModel


class FiskalyEsAuthenticationContentData(BaseModel):
    api_key: str
    api_secret: str


class FiskalyEsAuthenticationData(BaseModel):
    content: FiskalyEsAuthenticationContentData


class FiskalyInvoiceHeaders(BaseModel):
    Authorization: str
