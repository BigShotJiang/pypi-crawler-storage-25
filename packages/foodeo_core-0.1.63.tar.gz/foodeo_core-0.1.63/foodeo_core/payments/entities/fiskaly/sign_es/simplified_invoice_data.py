from pydantic import BaseModel

from foodeo_core.payments.entities.fiskaly.sign_es.fiskaly_item import InvoiceItemData


class ContentSimplifiedInvoiceData(BaseModel):
    type: str
    number: str
    series: str
    text: str
    full_amount: str
    issued_at: str
    items: list[InvoiceItemData]


class MetadataSimplifiedInvoiceData(BaseModel):
    local_key: str
    local_tax_number: str
    command_id: str
    payment_id: str


class SimplifiedInvoiceEntity(BaseModel):
    content: ContentSimplifiedInvoiceData
    metadata: MetadataSimplifiedInvoiceData
