from decimal import Decimal
from typing import Optional

from pydantic import BaseModel


class FiskalyCommandItem(BaseModel):
    product_name: str
    qty: int
    total_price: Decimal
    discount_type: Optional[str]
    discount: Optional[Decimal]


class ItemCategoryData(BaseModel):
    type: str
    rate: str


class ItemSystemData(BaseModel):
    type: str
    category: ItemCategoryData


class InvoiceItemData(BaseModel):
    text: str
    quantity: str
    unit_amount: str
    full_amount: str
    discount: Optional[str]
    vat_type: str
    system: ItemSystemData
