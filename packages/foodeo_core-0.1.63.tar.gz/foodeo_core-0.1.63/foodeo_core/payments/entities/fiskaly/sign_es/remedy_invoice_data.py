from uuid import UUID

from pydantic import BaseModel

from foodeo_core.payments.entities.fiskaly.sign_es.simplified_invoice_data import ContentSimplifiedInvoiceData


class ContentRemedyInvoiceData(BaseModel):
    type: str
    id: UUID
    invoice: ContentSimplifiedInvoiceData


class MetadataRemedyInvoiceData(BaseModel):
    local_key: str
    local_tax_number: str
    command_id: str
    payment_id: str


class RemedyInvoiceEntity(BaseModel):
    content: ContentRemedyInvoiceData
    metadata: MetadataRemedyInvoiceData
