from pydantic import BaseModel


class FiskalyItAuthenticationContentData(BaseModel):
    type: str
    key: str
    secret: str


class FiskalyItAuthenticationData(BaseModel):
    content: FiskalyItAuthenticationContentData


class FiskalyInvoiceHeaders(BaseModel):
    Authorization: str
