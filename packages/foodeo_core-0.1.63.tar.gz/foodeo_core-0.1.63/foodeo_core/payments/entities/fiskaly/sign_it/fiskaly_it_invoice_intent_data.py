from pydantic import BaseModel


class FiskalyItInvoiceIntentMetadataData(BaseModel):
    local_key: str
    local_tax_number: str
    local_vat_number: str


class FiskalyItInvoiceIntentOperationData(BaseModel):
    type: str


class FiskalyItInvoiceIntentSystemData(BaseModel):
    id: str


class FiskalyItInvoiceIntentContentData(BaseModel):
    type: str
    system: FiskalyItInvoiceIntentSystemData
    operation: FiskalyItInvoiceIntentOperationData


class FiskalyItInvoiceIntentData(BaseModel):
    content: FiskalyItInvoiceIntentContentData
    metadata: FiskalyItInvoiceIntentMetadataData
