from pydantic import BaseModel


class FiskalyItInvoiceCancellationMetadataData(BaseModel):
    payment_id: str
    command_id: str
    local_key: str
    local_tax_number: str
    local_vat_number: str


class FiskalyItInvoiceCancellationRecordData(BaseModel):
    id: str


class FiskalyItInvoiceCancellationOperationData(BaseModel):
    type: str
    record: FiskalyItInvoiceCancellationRecordData


class FiskalyItInvoiceCancellationContentData(BaseModel):
    type: str
    record: FiskalyItInvoiceCancellationRecordData
    operation: FiskalyItInvoiceCancellationOperationData


class FiskalyItInvoiceCancellationData(BaseModel):
    content: FiskalyItInvoiceCancellationContentData
    metadata: FiskalyItInvoiceCancellationMetadataData
