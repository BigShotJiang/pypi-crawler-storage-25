from uuid import UUID

from pydantic import BaseModel


class FiskalyItConfigData(BaseModel):
    secret_key: str
    api_key: str
    fiskaly_system_id: UUID
