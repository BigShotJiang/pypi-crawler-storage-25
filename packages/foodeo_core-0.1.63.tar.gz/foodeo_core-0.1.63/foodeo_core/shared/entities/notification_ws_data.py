from pydantic import BaseModel


class NotificationErrorWsData(BaseModel):
    type: str = "error"
    message: str


class NotificationSuccessWsData(BaseModel):
    type: str = "success"
    message: str


class NotificationInfoWsData(BaseModel):
    type: str = "info"
    message: str
