from decimal import Decimal

from pydantic import BaseModel, ConfigDict, Field


class RequestCreationContext(BaseModel):
    model_config = ConfigDict(use_enum_values=True)

    select_employee_before_order: bool = False
    close_barra_order_auto: bool = False
    auto_accept_domicile: bool = False
    auto_accept_pickup: bool = False
    request_without_client_domicile: bool = False
    request_without_client_pickup: bool = False
    default_client_id: int | None = None
    default_address_id: int | None = None
    user_is_client: bool = False
    domicile_service_price: Decimal = Field(default=Decimal("0"), ge=0)


class RequestCreationResult(BaseModel):
    model_config = ConfigDict(use_enum_values=True)

    status: str
    employee: int | None = None
    client: int | None = None
    address: int | None = None
    dealer: int | None = None
    domicile_price: Decimal = Field(default=Decimal("0"), ge=0)
