from decimal import Decimal
from enum import StrEnum

from pydantic import BaseModel, ConfigDict, Field


class PricingViolationCode(StrEnum):
    MINIMAL_AMOUNT_NOT_REACHED = "minimal_amount_not_reached"
    MAX_AMOUNT_EXCEEDED = "max_amount_exceeded"


class PricingViolation(BaseModel):
    code: PricingViolationCode
    message: str


class PromotionSnapshot(BaseModel):
    model_config = ConfigDict(use_enum_values=True)

    discount_type: str
    price: Decimal = Field(ge=0)
    enabled: bool = True


class PricingContext(BaseModel):
    model_config = ConfigDict(use_enum_values=True)

    request_type: str
    fiscal_integration: str | None = None
    max_amount: Decimal | None = None
    service_charge: Decimal = Decimal("0")
    minimal_amount: Decimal | None = None


class PricingResult(BaseModel):
    original_price: Decimal = Field(ge=0)
    request_price: Decimal = Field(ge=0)
    request_price_before_service: Decimal = Field(ge=0)
    manual_discount: Decimal = Field(ge=0, default=Decimal("0"))
    promotion_discount: Decimal = Field(ge=0, default=Decimal("0"))
    service_charge: Decimal = Field(ge=0, default=Decimal("0"))
    violations: list[PricingViolation] = Field(default_factory=list)

    @property
    def is_valid(self) -> bool:
        return not self.violations
