import unittest
from decimal import Decimal

from foodeo_core.orders.services import RequestPricingService, VERIFACTU_FISCAL_INTEGRATION
from foodeo_core.shared.entities import (
    DomicileRequest,
    LocalRequest,
    PricingContext,
    ProductInCommand,
    ProductInRequest,
    PromotionSnapshot,
)
from foodeo_core.shared.entities.commands import LocalCommand
from foodeo_core.shared.enums import DiscountEnum, FromClientEnum, RequestEnum


class TestRequestPricingService(unittest.TestCase):
    def test_calculate_local_request_with_manual_discount_and_fixed_promotion(self) -> None:
        request_model = LocalRequest(
            type=RequestEnum.local,
            from_client=FromClientEnum.web,
            qr="A-01",
            products=[
                ProductInRequest(
                    id=1,
                    name="Burger",
                    qty=2,
                    price=Decimal("10.00"),
                    is_discounted=True,
                )
            ],
            discount={"type": DiscountEnum.percentage, "value": Decimal("10.00")},
            all_discounted=True,
        )
        context = PricingContext(request_type=RequestEnum.local)
        promotion = PromotionSnapshot(discount_type=DiscountEnum.numeric, price=Decimal("3.00"))

        result = RequestPricingService.calculate(request_model, context, promotion)

        self.assertEqual(result.original_price, Decimal("20.00"))
        self.assertEqual(result.manual_discount, Decimal("2.00"))
        self.assertEqual(result.promotion_discount, Decimal("3.00"))
        self.assertEqual(result.request_price_before_service, Decimal("15.00"))
        self.assertEqual(result.request_price, Decimal("15.00"))
        self.assertTrue(result.is_valid)

    def test_calculate_domicile_request_adds_service_charge_and_flags_minimal_amount(self) -> None:
        request_model = DomicileRequest(
            type=RequestEnum.domicile,
            from_client=FromClientEnum.web,
            shift_time="13:00",
            products=[
                ProductInRequest(
                    id=1,
                    name="Burger",
                    qty=1,
                    price=Decimal("10.00"),
                    is_discounted=False,
                )
            ],
        )
        context = PricingContext(
            request_type=RequestEnum.domicile,
            service_charge=Decimal("2.50"),
            minimal_amount=Decimal("20.00"),
        )

        result = RequestPricingService.calculate(request_model, context)

        self.assertEqual(result.original_price, Decimal("10.00"))
        self.assertEqual(result.request_price_before_service, Decimal("10.00"))
        self.assertEqual(result.service_charge, Decimal("2.50"))
        self.assertEqual(result.request_price, Decimal("12.50"))
        self.assertEqual(len(result.violations), 1)
        self.assertEqual(result.violations[0].code.value, "minimal_amount_not_reached")

    def test_calculate_local_command_with_percentage_promotion(self) -> None:
        command_model = LocalCommand(
            type="local",
            table=1,
            qr="A-01",
            products=[
                ProductInCommand(
                    id=1,
                    name="Burger",
                    qty=2,
                    price=Decimal("10.00"),
                    is_discounted=False,
                )
            ],
        )
        context = PricingContext(request_type=RequestEnum.local)
        promotion = PromotionSnapshot(discount_type=DiscountEnum.percentage, price=Decimal("10.00"))

        result = RequestPricingService.calculate(command_model, context, promotion)

        self.assertEqual(result.original_price, Decimal("20.00"))
        self.assertEqual(result.promotion_discount, Decimal("2.00"))
        self.assertEqual(result.request_price, Decimal("18.00"))
        self.assertTrue(result.is_valid)

    def test_calculate_flags_verifactu_limit(self) -> None:
        request_model = LocalRequest(
            type=RequestEnum.local,
            from_client=FromClientEnum.web,
            qr="A-01",
            products=[
                ProductInRequest(
                    id=1,
                    name="Expensive",
                    qty=1,
                    price=Decimal("3500.00"),
                    is_discounted=False,
                )
            ],
        )
        context = PricingContext(
            request_type=RequestEnum.local,
            fiscal_integration=VERIFACTU_FISCAL_INTEGRATION,
            max_amount=Decimal("3000.00"),
        )

        result = RequestPricingService.calculate(request_model, context)

        self.assertEqual(len(result.violations), 1)
        self.assertEqual(result.violations[0].code.value, "max_amount_exceeded")
