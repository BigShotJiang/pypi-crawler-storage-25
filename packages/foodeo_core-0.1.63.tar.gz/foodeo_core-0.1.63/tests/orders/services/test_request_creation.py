import unittest
from decimal import Decimal

from foodeo_core.orders.services import RequestCreationPolicy
from foodeo_core.shared.entities import (
    DomicileRequest,
    LocalRequest,
    PickupRequest,
    RequestCreationContext,
)
from foodeo_core.shared.entities.requests import BarraRequestCloseWithConfig, CloseWith, BarraRequest
from foodeo_core.shared.entities.requests_items import ProductInRequest
from foodeo_core.shared.enums import FromClientEnum, RequestEnum, StatusEnum


def product() -> ProductInRequest:
    return ProductInRequest(id=1, name="Burger", qty=1, price=Decimal("10.00"), is_discounted=False)


class TestRequestCreationPolicy(unittest.TestCase):
    def test_local_from_apk_client_assigns_user_as_client(self):
        request = LocalRequest(
            type=RequestEnum.local,
            from_client=FromClientEnum.apk,
            qr="A-01",
            products=[product()],
            user_id=10,
        )
        context = RequestCreationContext(user_is_client=True, select_employee_before_order=False)

        result = RequestCreationPolicy.resolve(request, context)

        self.assertEqual(result.status, StatusEnum.requested)
        self.assertEqual(result.employee, 10)
        self.assertEqual(result.client, 10)

    def test_barra_uses_user_as_employee_when_worker_missing(self):
        request = BarraRequest(
            type=RequestEnum.barra,
            from_client=FromClientEnum.web,
            products=[product()],
            user_id=7,
            config=BarraRequestCloseWithConfig(close_with=CloseWith(payment_method=1)),
        )
        context = RequestCreationContext(select_employee_before_order=True)

        result = RequestCreationPolicy.resolve(request, context)

        self.assertEqual(result.status, StatusEnum.requested)
        self.assertEqual(result.employee, 7)

    def test_pickup_web_sales_uses_user_and_draft_when_not_auto_accepted(self):
        request = PickupRequest(
            type=RequestEnum.pickup,
            from_client=FromClientEnum.web_sales,
            products=[product()],
            user_id=22,
            shift_time="13:00",
        )
        context = RequestCreationContext(auto_accept_pickup=False)

        result = RequestCreationPolicy.resolve(request, context)

        self.assertEqual(result.status, StatusEnum.draft)
        self.assertEqual(result.client, 22)
        self.assertIsNone(result.employee)

    def test_pickup_uses_default_client_when_client_is_optional(self):
        request = PickupRequest(
            type=RequestEnum.pickup,
            from_client=FromClientEnum.web,
            products=[product()],
            user_id=22,
            shift_time="13:00",
        )
        context = RequestCreationContext(
            request_without_client_pickup=True,
            default_client_id=99,
            select_employee_before_order=False,
        )

        result = RequestCreationPolicy.resolve(request, context)

        self.assertEqual(result.client, 99)
        self.assertEqual(result.employee, 22)

    def test_domicile_uses_default_client_and_address(self):
        request = DomicileRequest(
            type=RequestEnum.domicile,
            from_client=FromClientEnum.web,
            products=[product()],
            user_id=15,
            shift_time="13:00",
        )
        context = RequestCreationContext(
            request_without_client_domicile=True,
            default_client_id=80,
            default_address_id=81,
            domicile_service_price=Decimal("2.50"),
            select_employee_before_order=False,
        )

        result = RequestCreationPolicy.resolve(request, context)

        self.assertEqual(result.status, StatusEnum.requested)
        self.assertEqual(result.employee, 15)
        self.assertEqual(result.client, 80)
        self.assertEqual(result.address, 81)
        self.assertEqual(result.domicile_price, Decimal("2.50"))
