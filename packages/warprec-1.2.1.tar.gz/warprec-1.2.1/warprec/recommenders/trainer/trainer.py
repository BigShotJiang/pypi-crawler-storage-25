# pylint: disable = wrong-import-position
import os

# Set Ray environment variable to enable new features
os.environ["RAY_TRAIN_V2_ENABLED"] = "1"
import uuid
import math
from typing import List, Tuple, Optional, Dict, Union, Any
from pathlib import Path

import torch
import numpy as np
import ray
from ray import tune
from ray.tune import Tuner, TuneConfig
from ray.tune.experiment import Trial
from ray.tune.integration.ray_train import TuneReportCallback
from ray.train.torch import TorchTrainer
from ray.train import ScalingConfig

from warprec.recommenders.base_recommender import Recommender, IterativeRecommender
from warprec.data import Dataset
from warprec.recommenders.trainer.objectives import objective_function
from warprec.utils.config import (
    RecomModel,
    DashboardConfig,
    ComplexMetricConfig,
)
from warprec.utils.helpers import validation_metric
from warprec.utils.callback import WarpRecCallback
from warprec.utils.logger import logger
from warprec.utils.registry import (
    model_registry,
    search_algorithm_registry,
    scheduler_registry,
    search_space_registry,
)

# Optional imports handling
try:
    from ray.air.integrations.wandb import WandbLoggerCallback
    from ray.air.integrations.mlflow import MLflowLoggerCallback
    from codecarbon import EmissionsTracker

    DASHBOARD_AVAILABLE = True
except ImportError:
    DASHBOARD_AVAILABLE = False


class Trainer:
    """Trainer class for training and hyperparameter optimization using Ray Tune.
    Delegates configuration details to TrainConfiguration object.

    Args:
        custom_callback (WarpRecCallback): Custom callback for training/eval.
        custom_modules (Optional[Union[str, List[str]]]): List of custom models to load.
        dashboard_config (Optional[DashboardConfig]): Configuration for logging dashboards
            (WandB, MLFlow, CodeCarbon). Defaults to None.
    """

    def __init__(
        self,
        custom_callback: WarpRecCallback = WarpRecCallback(),
        custom_modules: Optional[Union[str, List[str]]] = None,
        dashboard_config: Optional[DashboardConfig] = None,
    ):
        self._custom_modules = custom_modules or []
        self._callbacks = self._setup_callbacks(custom_callback, dashboard_config)

    def train_single_fold(
        self,
        model_name: str,
        params: RecomModel,
        dataset: Dataset,
        metrics: List[str],
        topk: List[int],
        validation_score: str,
        storage_path: str,
        device: str = "cpu",
        evaluation_strategy: str = "full",
        num_negatives: int = 99,
        complex_metrics: List[ComplexMetricConfig] = None,
        ray_verbose: int = 1,
    ) -> Tuple[Optional[Recommender], dict, int]:
        """Main method of the Trainer class.

        This method will execute the training of the model and evaluation,
        according to information passed through configuration.

        Args:
            model_name (str): The name of the model to optimize.
            params (RecomModel): The parameters of the model.
            dataset (Dataset): The dataset to use during training.
            metrics (List[str]): List of metrics to compute on each report.
            topk (List[int]): List of cutoffs for metrics.
            validation_score (str): The metric to monitor during training.
            storage_path (str): Path to store Ray results.
            device (str): The device that will be used for tensor operations.
            evaluation_strategy (str): Evaluation strategy, either "full" or "sampled".
            num_negatives (int): Number of negative samples to use in "sampled" strategy.
            complex_metrics (List[ComplexMetricConfig]): List of complex metrics
                to compute.
            ray_verbose (int): The Ray level of verbosity.

        Returns:
            Tuple[Optional[Recommender], dict, int]:
                - Recommender: The model trained.
                - dict: Summary report of the training.
                - int: The best training iteration.
        """

        mode = params.optimization.properties.mode

        tuner = self._setup_tuner(
            model_name=model_name,
            params=params,
            dataset=dataset,
            metrics=metrics,
            topk=topk,
            validation_score=validation_score,
            storage_path=storage_path,
            device=device,
            evaluation_strategy=evaluation_strategy,
            num_negatives=num_negatives,
            complex_metrics=complex_metrics,
            ray_verbose=ray_verbose,
        )

        results = tuner.fit()

        # Check if any trial succeeded
        if results.errors and len(results) == len(results.errors):
            logger.negative(f"All trials failed for {model_name}.")
            return None, {}, 0

        # Retrieve best result using Ray API
        best_result = results.get_best_result(metric=validation_score, mode=mode)

        if not best_result:
            logger.negative(f"Could not determine best result for {model_name}.")
            return None, {}, 0

        best_params = best_result.config
        best_params = {k: v for k, v in best_params.items() if not k.startswith("_")}
        best_row = self._get_best_result_row(
            best_result.metrics_dataframe, validation_score, mode
        )
        best_score = best_row.get(validation_score).item()
        best_iter = best_row.get("training_iteration").item()
        best_checkpoint_path = best_row.get("checkpoint_path")

        logger.msg(
            f"Best params: {best_params} | Score ({validation_score}): {best_score} "
            f"| Iteration: {best_iter}"
        )
        logger.positive(f"HPO for {model_name} ended successfully.")

        # Load Best Model
        best_model = self._load_best_model(
            model_name,
            best_checkpoint_path,
            best_params,
            dataset,
        )

        report = self._create_report(results, best_model)
        return best_model, report, best_iter

    def train_multiple_fold(
        self,
        model_name: str,
        params: RecomModel,
        datasets: List[Dataset],
        metrics: List[str],
        topk: List[int],
        validation_score: str,
        storage_path: str,
        device: str = "cpu",
        evaluation_strategy: str = "full",
        num_negatives: int = 99,
        complex_metrics: List[ComplexMetricConfig] = None,
        desired_training_it: str = "median",
        ray_verbose: int = 1,
    ) -> Tuple[Optional[Dict], Dict]:
        """Main method of the Trainer class for cross-validation.

        Args:
            model_name (str): The name of the model to optimize.
            params (RecomModel): The parameters of the model.
            datasets (List[Dataset]): The list of datasets to use during training.
            metrics (List[str]): List of metrics to compute on each report.
            topk (List[int]): List of cutoffs for metrics.
            validation_score (str): The metric to monitor during training.
            storage_path (str): Path to store Ray results.
            device (str): The device that will be used for tensor operations.
            evaluation_strategy (str): Evaluation strategy, either "full" or "sampled".
            num_negatives (int): Number of negative samples to use in "sampled" strategy.
            complex_metrics (List[ComplexMetricConfig]): List of complex metrics
                to compute.
            desired_training_it (str): The type of statistic to use to
                select the number of training iterations to use
                when training on the full dataset. Either "min", "max",
                "mean" or "median". Default is "median".
            ray_verbose (int): The Ray level of verbosity.

        Returns:
            Tuple[Optional[Dict], Dict]:
                - Dict: The best hyperparameters found.
                - Dict: Summary report of the training.
        """

        mode = params.optimization.properties.mode

        tuner = self._setup_tuner(
            model_name=model_name,
            params=params,
            dataset=datasets,
            metrics=metrics,
            topk=topk,
            validation_score=validation_score,
            storage_path=storage_path,
            device=device,
            evaluation_strategy=evaluation_strategy,
            num_negatives=num_negatives,
            complex_metrics=complex_metrics,
            ray_verbose=ray_verbose,
        )

        results = tuner.fit()
        result_df = results.get_dataframe(
            filter_metric=validation_score, filter_mode=mode
        )

        if result_df.empty or (
            mode == "max" and result_df[validation_score].max() == -torch.inf
        ):
            logger.negative(f"All trials failed for {model_name}.")
            return None, {}

        # Aggregate results logic
        best_hyperparameters, best_stats = self._aggregate_cv_results(
            result_df, validation_score, mode, desired_training_it
        )

        logger.msg(
            f"Best params: {best_hyperparameters} | Avg Score: {best_stats['mean']} "
            f"| Std: {best_stats['std']} | Iterations: {best_hyperparameters['iterations']}"
        )
        logger.positive(f"CV HPO for {model_name} ended successfully.")

        report = self._create_report(results)
        return best_hyperparameters, report

    def _setup_tuner(
        self,
        model_name: str,
        params: RecomModel,
        dataset: Union[Dataset, List[Dataset]],
        metrics: List[str],
        topk: List[int],
        validation_score: str,
        storage_path: str,
        device: str,
        evaluation_strategy: str,
        num_negatives: int,
        complex_metrics: List[ComplexMetricConfig],
        ray_verbose: int,
    ) -> Tuner:
        """Prepares the Ray Tuner instance.

        Args:
            model_name (str): The name of the model to optimize.
            params (RecomModel): The parameters of the model.
            dataset (Union[Dataset, List[Dataset]]): The dataset(s) to use during
                training.
            metrics (List[str]): List of metrics to compute on each report.
            topk (List[int]): List of cutoffs for metrics.
            validation_score (str): The metric to monitor during training.
            storage_path (str): Path to store Ray results.
            device (str): The device that will be used for tensor operations.
            evaluation_strategy (str): Evaluation strategy, either "full" or "sampled".
            num_negatives (int): Number of negative samples to use in "sampled" strategy.
            complex_metrics (List[ComplexMetricConfig]): List of complex metrics to compute.
            ray_verbose (int): The Ray level of verbosity.

        Returns:
            Tuner: The configured Ray Tuner instance.
        """

        opt_config = params.optimization
        mode = opt_config.properties.mode

        # Determine resources
        scaling_config_dict = self._get_scaling_config(
            opt_config.cpu_per_trial,
            opt_config.gpu_per_trial,
            opt_config.custom_resources_per_trial,
            opt_config.label_selector,
            device,
        )

        # Prepare data bundle
        validation_metric_name, validation_top_k = validation_metric(validation_score)
        data_bundle = {
            "model_name": model_name,
            "dataset_folds": ray.put(dataset),
            "metrics": metrics,
            "topk": topk,
            "validation_top_k": validation_top_k,
            "validation_metric_name": validation_metric_name,
            "mode": opt_config.properties.mode,
            "device": device,
            "eval_every_n": opt_config.eval_every_n,
            "strategy": evaluation_strategy,
            "num_negatives": num_negatives,
            "complex_metrics": complex_metrics,
            "lr_scheduler": opt_config.lr_scheduler,
            "optimizer": opt_config.optimizer,
            "seed": opt_config.properties.seed,
            "block_size": opt_config.block_size,
            "chunk_size": opt_config.chunk_size,
            "custom_modules": self._custom_modules,
            "early_stopping_config": params.early_stopping,
        }

        num_folds = len(dataset) if isinstance(dataset, list) else 0
        param_space = self._parse_params(params, num_folds)

        # Driver function that will be launched by Ray Tune and will
        # initialize Ray Train
        def train_driver_fn(config: dict, data_bundle: dict, scaling_config_dict: dict):
            scaling_config = ScalingConfig(**scaling_config_dict)

            train_loop_config = {**data_bundle, "params": config}

            trainer = TorchTrainer(
                train_loop_per_worker=objective_function,
                train_loop_config=train_loop_config,
                scaling_config=scaling_config,
                run_config=ray.train.RunConfig(
                    callbacks=[TuneReportCallback()],  # type: ignore[list-item]
                    storage_path=storage_path,
                    checkpoint_config=ray.train.CheckpointConfig(
                        num_to_keep=opt_config.checkpoint_to_keep,
                        checkpoint_score_attribute=validation_score,
                        checkpoint_score_order=mode,
                    ),
                ),
            )

            trainer.fit()

        # Search Algorithm & Scheduler
        search_alg = search_algorithm_registry.get(
            opt_config.strategy, **opt_config.properties.model_dump()
        )
        scheduler = scheduler_registry.get(
            opt_config.scheduler, **opt_config.properties.model_dump()
        )

        # Configs
        run_config = ray.tune.RunConfig(
            callbacks=self._callbacks,
            verbose=ray_verbose,
            storage_path=storage_path,
            checkpoint_config=ray.tune.CheckpointConfig(
                num_to_keep=opt_config.checkpoint_to_keep,
                checkpoint_score_attribute=validation_score,
                checkpoint_score_order=mode,
            ),
        )

        # Deadlock fix
        resources = ray.available_resources()
        available_cpus = resources.get("CPU", 1)
        available_gpus = resources.get("GPU", 0)

        if scaling_config_dict["use_gpu"] and opt_config.gpu_per_trial > 0:
            max_concurrent = max(1, int(available_gpus // opt_config.gpu_per_trial))
        else:
            max_concurrent = max(1, int(available_cpus // opt_config.cpu_per_trial))

        # Tuner will execute the driver function
        tune_config = TuneConfig(
            metric=validation_score,
            mode=mode,
            search_alg=search_alg,  # type: ignore[arg-type]
            scheduler=scheduler,  # type: ignore[arg-type]
            num_samples=opt_config.num_samples,
            trial_name_creator=self._trial_name_creator(model_name),
            trial_dirname_creator=self._trial_dirname_creator(model_name),
            max_concurrent_trials=max_concurrent,
        )
        trainable = tune.with_resources(
            tune.with_parameters(
                train_driver_fn,
                data_bundle=data_bundle,
                scaling_config_dict=scaling_config_dict,
            ),
            resources={"CPU": 0.05},
        )

        return Tuner(
            trainable,
            param_space=param_space,
            tune_config=tune_config,
            run_config=run_config,
        )

    def _get_scaling_config(
        self,
        cpu_per_trial: int,
        gpu_per_trial: float,
        custom_resources_per_trial: Optional[Dict[str, float | int]] = None,
        label_selector: Optional[Dict[str, str]] = None,
        device: str = "cpu",
    ) -> Dict[str, Any]:
        """Calculates resource allocation per trial.

        Args:
            cpu_per_trial (int): The number of cpu per trial.
            gpu_per_trial (float): The number of gpu per trial.
            custom_resources_per_trial (Optional[Dict[str, float | int]]): Custom resources to assign to each trial.
            label_selector (Optional[Dict[str, str]]): Custom labels used during trial assignment.
            device (str): The device of the experiment.

        Returns:
            Dict[str, Any]: Resources dictionary for Ray Tune.
        """
        # Determine if we are using GPUs
        use_gpu = device == "cuda" or gpu_per_trial > 0

        # In Ray Train, `num_workers` represents the number of distributed processes.
        # For GPU training, we typically spawn 1 worker per GPU to enable DDP.
        if use_gpu:
            num_workers = max(1, int(gpu_per_trial))
        else:
            # For CPU training, we default to 1 worker per trial
            num_workers = 1

        # Calculate resources per individual worker
        resources_per_worker = {
            "CPU": cpu_per_trial / num_workers,
        }
        if use_gpu:
            resources_per_worker["GPU"] = gpu_per_trial / num_workers

        # Add custom resources if provided
        if custom_resources_per_trial is not None:
            for res, amount in custom_resources_per_trial.items():
                resources_per_worker[res] = amount / num_workers

        scaling_dict = {
            "num_workers": num_workers,
            "use_gpu": use_gpu,
            "resources_per_worker": resources_per_worker,
        }

        # Add label selector if provided
        if label_selector is not None:
            scaling_dict["label_selector"] = label_selector

        return scaling_dict

    def _load_best_model(self, model_name, checkpoint_path, best_params, dataset):
        """Loads the model state from the best checkpoint."""
        model_class = model_registry.get_class(model_name)

        if issubclass(model_class, IterativeRecommender):
            model = model_class.from_checkpoint(
                torch.load(
                    Path(checkpoint_path) / "checkpoint.ckpt",
                    weights_only=False,
                    map_location="cpu",
                ),
                interactions=dataset.train_set,
                **dataset.get_stash(),
            )
        else:
            model = model_class(
                params=best_params,
                interactions=dataset.train_set,
                info=dataset.info(),
                **dataset.get_stash(),
            )

        return model

    def _get_best_result_row(self, df, metric, mode):
        """Extract the best iteration row from the result DataFrame."""
        if mode == "max":
            best_idx = df[metric].idxmax()
        else:
            best_idx = df[metric].idxmin()
        return df.loc[best_idx]

    def _aggregate_cv_results(self, df, metric, mode, desired_it_stat):
        """Aggregates Cross-Validation results to find best hyperparameters."""
        hyperparam_cols = [
            c for c in df.columns if c.startswith("config/") and c != "config/fold"
        ]

        # Fix list hashing for groupby
        for col in hyperparam_cols:
            if df[col].dtype == "object":
                df[col] = df[col].apply(
                    lambda x: tuple(x) if isinstance(x, list) else x
                )

        agg_df = (
            df.groupby(hyperparam_cols)
            .agg(
                mean_score=(metric, "mean"),
                std_score=(metric, "std"),
                desired_training_iterations=("training_iteration", desired_it_stat),
            )
            .reset_index()
        )

        best_row = agg_df.sort_values(by="mean_score", ascending=(mode == "min")).iloc[
            0
        ]

        # Reconstruct clean params dict
        best_params = {"iterations": math.ceil(best_row["desired_training_iterations"])}
        for col in hyperparam_cols:
            key = col.replace("config/", "")
            val = best_row[col]
            # Type restoration logic
            if isinstance(val, (np.integer, int)):
                best_params[key] = int(val)
            elif isinstance(val, (np.floating, float)):
                best_params[key] = int(val) if val.is_integer() else float(val)
            elif isinstance(val, (np.bool_, bool)):
                best_params[key] = bool(val)
            else:
                best_params[key] = val

        stats = {"mean": best_row["mean_score"], "std": best_row["std_score"]}
        return best_params, stats

    def _parse_params(self, params: RecomModel, num_folds: int = 0) -> dict:
        """Parses model parameters into Ray Tune search space."""
        tune_params = {}
        # Exclude metadata fields
        exclude = {"meta", "optimization", "early_stopping"}
        clean_params = {
            k: v for k, v in params.model_dump().items() if k not in exclude
        }

        for k, v in clean_params.items():
            if isinstance(v, list) and len(v) > 0:
                space_type = v[0]
                args = v[1:]
                tune_params[k] = search_space_registry.get(space_type)(*args)
            else:
                tune_params[k] = v  # Static parameter

        if num_folds > 0:
            tune_params["fold"] = tune.grid_search(list(range(num_folds)))

        return tune_params

    def _trial_name_creator(self, model_name: str):
        def _creator(trial: Trial):
            return f"{model_name}_{str(uuid.uuid4())[:8]}"

        return _creator

    def _trial_dirname_creator(self, model_name: str):
        def _creator(trial: Trial):
            return f"{model_name}_trial_{trial.trial_id}"

        return _creator

    def _setup_callbacks(
        self,
        custom_callback: WarpRecCallback,
        dashboard: Optional[DashboardConfig] = None,
    ) -> List[tune.Callback | WarpRecCallback]:
        callbacks: List[tune.Callback | WarpRecCallback] = [custom_callback]

        # If dashboard config is not provided, return only the custom callback
        if dashboard is None:
            return callbacks

        if not DASHBOARD_AVAILABLE:
            if any(
                [
                    dashboard.wandb.enabled,
                    dashboard.codecarbon.enabled,
                    dashboard.mlflow.enabled,
                ]
            ):
                logger.attention(
                    "WarpRec dashboard extra has not been installed. "
                    "Dashboards will not be available during training."
                )
            return callbacks

        if dashboard.wandb.enabled:
            callbacks.append(
                WandbLoggerCallback(
                    project=dashboard.wandb.project,
                    group=dashboard.wandb.group,
                    api_key_file=dashboard.wandb.api_key_file,
                    api_key=dashboard.wandb.api_key,
                    excludes=dashboard.wandb.excludes,
                    log_config=dashboard.wandb.log_config,
                    upload_checkpoints=dashboard.wandb.upload_checkpoints,
                    entity=dashboard.wandb.team,
                )
            )
        if dashboard.codecarbon.enabled:
            callbacks.append(
                CodeCarbonCallback(
                    save_to_api=dashboard.codecarbon.save_to_api,
                    save_to_file=dashboard.codecarbon.save_to_file,
                    output_dir=dashboard.codecarbon.output_dir,
                    tracking_mode=dashboard.codecarbon.tracking_mode,
                )
            )
        if dashboard.mlflow.enabled:
            callbacks.append(
                MLflowLoggerCallback(
                    tracking_uri=dashboard.mlflow.tracking_uri,
                    registry_uri=dashboard.mlflow.registry_uri,
                    experiment_name=dashboard.mlflow.experiment_name,
                    tags=dashboard.mlflow.tags,
                    tracking_token=dashboard.mlflow.tracking_token,
                    save_artifact=dashboard.mlflow.save_artifacts,
                )
            )
        return callbacks

    def _create_report(
        self, results: tune.ResultGrid, model: Optional[Recommender] = None
    ) -> dict:
        report = {}

        # Memory stats from dataframe
        df = results.get_dataframe()
        mem_cols = ["ram_peak_mb", "vram_peak_mb"]
        for col in mem_cols:
            if col in df.columns:
                prefix = "RAM" if "ram" in col and "vram" not in col else "VRAM"
                report[f"{prefix} Mean Usage (MB)"] = df[col].mean()
                report[f"{prefix} Max Usage (MB)"] = df[col].max()

        # Time stats
        successful_trials = [r for r in results if not r.error]  # type: ignore[attr-defined]
        if successful_trials:
            times = [r.metrics.get("time_total_s", 0) for r in successful_trials]
            report["Average Trial Time (s)"] = sum(times) / len(times)

        # Model stats
        report["Total Params (Best Model)"] = np.nan
        report["Trainable Params (Best Model)"] = np.nan

        if model:
            report["Total Params (Best Model)"] = sum(
                p.numel() for p in model.parameters()
            )
            report["Trainable Params (Best Model)"] = sum(
                p.numel() for p in model.parameters() if p.requires_grad
            )

        return report


class CodeCarbonCallback(tune.Callback):
    """Custom CodeCarbon callback for Ray Tune."""

    def __init__(
        self,
        save_to_api=False,
        save_to_file=False,
        output_dir="./",
        tracking_mode="machine",
    ):
        self.save_to_api = save_to_api
        self.save_to_file = save_to_file
        self.output_dir = output_dir
        self.tracking_mode = tracking_mode
        self.trackers: Dict[str, EmissionsTracker] = {}
        os.makedirs(self.output_dir, exist_ok=True)

    def on_trial_start(self, iteration, trials, trial, **info):
        tracker = EmissionsTracker(
            save_to_api=self.save_to_api,
            save_to_file=self.save_to_file,
            output_dir=self.output_dir,
            tracking_mode=self.tracking_mode,
            log_level="error",  # Reduce noise
        )
        tracker.start()
        self.trackers[trial.trial_id] = tracker

    def on_trial_complete(self, iteration, trials, trial, **info):
        self._stop_tracker(trial.trial_id)

    def on_trial_fail(self, iteration, trials, trial, **info):
        self._stop_tracker(trial.trial_id)

    def _stop_tracker(self, trial_id):
        tracker = self.trackers.pop(trial_id, None)
        if tracker:
            tracker.stop()
