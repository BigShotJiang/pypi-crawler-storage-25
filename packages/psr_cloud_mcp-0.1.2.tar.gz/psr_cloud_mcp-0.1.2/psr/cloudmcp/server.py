#!/usr/bin/env python3
"""MCP server for PSR Cloud — wraps pycloud (psr-cloud) for AI automation."""

from __future__ import annotations

import os
from typing import Optional

from mcp.server.fastmcp import FastMCP

mcp = FastMCP(
    "PSR Cloud",
    instructions=(
        "Tools for managing PSR Cloud HPC model runs. "
        "Authentication is read automatically from the PSR_CLOUD_EMAIL and "
        "PSR_CLOUD_ACCESS_TOKEN environment variables — no login step needed. "
        "Typical workflow for submitting a run: "
        "get_programs() → get_program_versions(program) → get_execution_types(program, version) "
        "→ run_case(). Use get_memory_per_process_ratios() to see valid ratio strings. "
        "After submission, poll get_case_status(case_id) until finished, then download_results()."
    ),
)

_client = None


def _get_client():
    global _client
    if _client is None:
        email = os.environ.get("PSR_CLOUD_EMAIL")
        token = os.environ.get("PSR_CLOUD_ACCESS_TOKEN")
        if not email or not token:
            raise RuntimeError(
                "PSR_CLOUD_EMAIL and PSR_CLOUD_ACCESS_TOKEN environment variables must be set. "
                "Get your Personal Access Token at sso.psr-inc.com/profile, then add both "
                "variables to your MCP server config (mcpServers > psr-cloud > env in "
                "settings.json for Claude Code, or claude_desktop_config.json for Claude Desktop)."
            )
        from psr.cloud import Client

        _client = Client(python_client=True, quiet=True, application_version="PSRCloudMCP")
    return _client


# ---------------------------------------------------------------------------
# Case discovery & status
# ---------------------------------------------------------------------------


@mcp.tool()
def list_cases(days: int = 7) -> list[dict]:
    """List cases submitted in the last N days (default 7), sorted newest first."""
    return [c.to_dict() for c in _get_client().get_all_cases_since(days)]


@mcp.tool()
def get_cases(case_ids: list[int]) -> list[dict]:
    """Get details for one or more cases by their repository IDs."""
    return [c.to_dict() for c in _get_client().get_cases(case_ids)]


@mcp.tool()
def get_case_status(case_id: int) -> dict:
    """
    Get the current execution status of a case.

    Possible status values: QUEUE, PENDING, WAITING_MACHINE, RUNNING, SUCCESS,
    ERROR, CANCELLED, ABORTED, UPLOADED, and others.
    """
    status, message = _get_client().get_status(case_id, quiet=True)
    return {"case_id": case_id, "status": status.name, "message": message}


@mcp.tool()
def get_case_log(case_id: int) -> str:
    """Retrieve the execution log text for a case."""
    return _get_client().get_log(case_id, quiet=True) or ""


@mcp.tool()
def list_download_files(case_id: int) -> list[dict]:
    """
    List result files available for download for a case.

    Returns a list of dicts with keys: name, filesize, filedate.
    Use the names in download_results(files=[...]) to fetch specific files.
    """
    return _get_client().list_download_files(case_id)


# ---------------------------------------------------------------------------
# Submit & cancel
# ---------------------------------------------------------------------------


@mcp.tool()
def run_case(
    name: str,
    data_path: str,
    program: str,
    program_version: str,
    execution_type: str,
    number_of_processes: int,
    memory_per_process_ratio: str = "4:1",
    price_optimized: bool = False,
    repository_duration: str = "Normal (1 month)",
    parent_case_id: Optional[int] = None,
    budget: Optional[str] = None,
) -> dict:
    """
    Submit a new model case to PSR Cloud HPC.

    Before calling this, use:
      - get_programs() to see available programs
      - get_program_versions(program) to see valid versions
      - get_execution_types(program, version) to see valid execution types
      - get_memory_per_process_ratios() to see valid ratio strings

    Args:
        name: Human-readable label for this run.
        data_path: Absolute local path to the folder containing input data files.
        program: Program identifier, e.g. "SDDP", "OPTGEN", "GRAF".
        program_version: Version name, e.g. "18.0" (from get_program_versions).
        execution_type: Execution type name (from get_execution_types).
        number_of_processes: Number of parallel processes (check get_number_of_processes).
        memory_per_process_ratio: Memory-to-core ratio, e.g. "4:1" or "8:1".
        price_optimized: Use spot/price-optimized instances (lower cost, may be preempted).
        repository_duration: How long to retain results, e.g. "Normal (1 month)",
                             "Short (1 week)", "Extended (6 months)", "Long (2 years)".
        parent_case_id: Repository ID of a parent case (for chained/dependent runs).
        budget: Budget tag name to charge this run against (from get_budgets if needed).

    Returns:
        dict with case_id (int), name, and status "submitted".
    """
    from psr.cloud import Case

    case = Case(
        name=name,
        data_path=data_path,
        program=program,
        program_version=program_version,
        execution_type=execution_type,
        price_optimized=price_optimized,
        number_of_processes=number_of_processes,
        memory_per_process_ratio=memory_per_process_ratio,
        repository_duration=repository_duration,
        parent_case_id=parent_case_id,
        budget=budget,
    )
    case_id = _get_client().run_case(case)
    return {"case_id": case_id, "name": name, "status": "submitted"}


@mcp.tool()
def cancel_case(case_id: int) -> dict:
    """
    Request cancellation of a running or queued case.

    Returns immediately; the case may take a moment to reach CANCELLED status.
    """
    success = _get_client().cancel_case(case_id)
    return {"case_id": case_id, "cancelled": success}


@mcp.tool()
def download_results(
    case_id: int,
    output_path: str,
    extensions: Optional[list[str]] = None,
    files: Optional[list[str]] = None,
) -> dict:
    """
    Download result files for a completed case to a local directory.

    Args:
        case_id: Case repository ID.
        output_path: Local directory where files will be saved (created if needed).
        extensions: File extensions to include, e.g. ["csv", "log", "bin"].
                    Defaults to ["csv", "log", "hdr", "bin", "out", "ok"] when
                    neither extensions nor files is specified.
        files: Specific filenames to download (overrides extensions filter).
               Use list_download_files(case_id) to see what is available.

    Returns:
        dict with case_id, output_path, and status "downloaded".
    """
    _get_client().download_results(
        case_id, output_path, files=files, extensions=extensions
    )
    return {"case_id": case_id, "output_path": output_path, "status": "downloaded"}


# ---------------------------------------------------------------------------
# Program / version discovery
# ---------------------------------------------------------------------------


@mcp.tool()
def get_programs() -> list[str]:
    """List all programs available on PSR Cloud, e.g. SDDP, OPTGEN, GRAF."""
    return _get_client().get_programs()


@mcp.tool()
def get_program_versions(program: str) -> dict:
    """
    List available versions for a program.

    Returns a dict mapping version_id (int) to version_name (str).
    Pass the version_name string to run_case(program_version=...).
    """
    return _get_client().get_program_versions(program)


@mcp.tool()
def get_execution_types(program: str, version: str) -> dict:
    """
    List execution types for a given program and version.

    Returns a dict mapping type_id (int) to type_name (str).
    Pass the type_name string to run_case(execution_type=...).
    """
    return _get_client().get_execution_types(program, version)


@mcp.tool()
def get_memory_per_process_ratios() -> list[str]:
    """
    List valid memory-per-process ratio strings for the current cluster.

    Example return: ["4:1", "8:1"]. Pass one of these to run_case(memory_per_process_ratio=...).
    """
    return _get_client().get_memory_per_process_ratios()


# ---------------------------------------------------------------------------
# Entry point
# ---------------------------------------------------------------------------


def main():
    mcp.run()


if __name__ == "__main__":
    main()
