# PSR Cloud MCP Server

MCP server that exposes PSR Cloud HPC operations as AI tools, built on top of
[pycloud](https://pypi.org/project/psr-cloud/) (`psr-cloud` on PyPI).

## Prerequisites

1. **Python 3.10+**
2. A **Personal Access Token** from PSR Cloud:
   - Go to `sso.psr-inc.com/profile`
   - Log in with your corporate PSR Google account
   - Generate a token under *PSR Cloud — Personal Access Tokens*
   - Save the token value (shown only once)

## Installation

### Option A — from the Git repository

```bash
pip install git+https://github.com/your-org/psr-cloud-mcp.git
```

This installs the `psr-cloud-mcp` CLI and pulls `psr-cloud` from PyPI automatically.

### Option B — from a local clone (development)

```bash
git clone https://github.com/your-org/psr-cloud-mcp.git
cd psr-cloud-mcp
pip install -e .
```

### Option C — from PyPI (once published)

```bash
pip install psr-cloud-mcp
```

## Authentication

Set two environment variables before starting the server:

```bash
export PSR_CLOUD_EMAIL=yourname@psr-inc.com
export PSR_CLOUD_ACCESS_TOKEN=<your-token>
```

On Windows:

```powershell
$env:PSR_CLOUD_EMAIL = "yourname@psr-inc.com"
$env:PSR_CLOUD_ACCESS_TOKEN = "<your-token>"
```

## Running the server

```bash
# directly
python -m psr.cloudmcp

# or via the installed script
psr-cloud-mcp

# or via the MCP CLI
mcp run psr/cloudmcp/server.py
```

## Configuring Claude Code

Add to `~/.claude/settings.json` (or `settings.local.json` for local-only):

```json
{
  "mcpServers": {
    "psr-cloud": {
      "command": "psr-cloud-mcp",
      "env": {
        "PSR_CLOUD_EMAIL": "yourname@psr-inc.com",
        "PSR_CLOUD_ACCESS_TOKEN": "<your-token>"
      }
    }
  }
}
```

If you prefer not to store the token in the config file, omit the `env` block and
set the variables in your shell profile instead.

## Configuring Claude Desktop

Open the Claude Desktop config file:

- **Windows:** `%APPDATA%\Claude\claude_desktop_config.json`
- **macOS:** `~/Library/Application Support/Claude/claude_desktop_config.json`

Add the `psr-cloud` entry under `mcpServers`:

```json
{
  "mcpServers": {
    "psr-cloud": {
      "command": "psr-cloud-mcp",
      "env": {
        "PSR_CLOUD_EMAIL": "yourname@psr-inc.com",
        "PSR_CLOUD_ACCESS_TOKEN": "<your-token>"
      }
    }
  }
}
```

If `psr-cloud-mcp` is not on the system PATH (common on Windows), use the full
path to the executable:

```json
{
  "mcpServers": {
    "psr-cloud": {
      "command": "C:\\Users\\<user>\\AppData\\Local\\Programs\\Python\\Python3xx\\Scripts\\psr-cloud-mcp.exe",
      "env": {
        "PSR_CLOUD_EMAIL": "yourname@psr-inc.com",
        "PSR_CLOUD_ACCESS_TOKEN": "<your-token>"
      }
    }
  }
}
```

To find the exact executable path, run:

```powershell
where.exe psr-cloud-mcp
```

After saving the file, restart Claude Desktop. The PSR Cloud tools will appear
in the tools panel (hammer icon).

## Available tools

| Tool | Description |
|---|---|
| `list_cases` | List cases from the last N days |
| `get_cases` | Get details for specific case IDs |
| `get_case_status` | Poll execution status of a case |
| `get_case_log` | Retrieve execution log text |
| `list_download_files` | List result files available for a case |
| `run_case` | Submit a new model run |
| `cancel_case` | Cancel a running or queued case |
| `download_results` | Download result files to a local path |
| `get_programs` | List available programs (SDDP, OPTGEN, …) |
| `get_program_versions` | List versions for a program |
| `get_execution_types` | List execution types for a program + version |
| `get_memory_per_process_ratios` | List valid memory ratio strings |

## Typical AI workflow

```
get_programs()
  → get_program_versions("SDDP")
  → get_execution_types("SDDP", "18.0")
  → run_case(name="my-run", data_path="/path/to/data", program="SDDP", ...)
  → get_case_status(case_id)   # poll until SUCCESS
  → list_download_files(case_id)
  → download_results(case_id, output_path="/path/to/results")
```
