from __future__ import annotations

from typing import Callable


def router_admin_headers(api_key: str) -> dict[str, str]:
    return {"Authorization": f"Bearer {api_key}", "Content-Type": "application/json"}


async def router_unload_hook(
    model: str,
    *,
    router_admin_base: str,
    api_key: str,
    http_post: Callable[..., object],
) -> None:
    _ = model
    try:
        await http_post(
            f"{router_admin_base}/admin/unload",
            headers=router_admin_headers(api_key),
            json={},
            timeout=10,
        )
    except Exception:
        return


async def router_load_hook(
    model: str,
    *,
    router_admin_base: str,
    api_key: str,
    http_post: Callable[..., object],
) -> None:
    try:
        await http_post(
            f"{router_admin_base}/admin/load",
            headers=router_admin_headers(api_key),
            json={"model": model},
            timeout=30,
        )
    except Exception:
        return
