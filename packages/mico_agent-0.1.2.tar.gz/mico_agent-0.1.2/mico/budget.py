from __future__ import annotations

from typing import Any, Callable


def compute_thinking_budget(
    history: list[dict[str, str]],
    ctx: Any,
    step: int,
    consecutive_reads: int,
    *,
    thinking_budget: int,
    thinking_enabled: bool,
    adaptive_budget: bool,
    min_thinking_budget: int,
    clamp_budget: Callable[[int], int],
    recent_user_message: Callable[[list[dict[str, str]]], str],
    current_dispatch_mode: Callable[[Any], str],
) -> int:
    base = clamp_budget(thinking_budget)
    if not thinking_enabled or not adaptive_budget:
        return base

    last_user = recent_user_message(history)
    last_len = len(last_user)
    budget = base

    mode = current_dispatch_mode(ctx)
    if mode == "plan":
        budget = max(budget, base * 2)
    elif mode == "review":
        budget = max(budget, int(base * 1.5))

    if step == 1:
        budget = max(budget, int(base * 1.5))

    if "Tool error for" in last_user or "Model backend error" in last_user:
        budget = max(budget, base * 2)
    elif "You are repeating the same step" in last_user or "Too many consecutive inspection steps" in last_user:
        budget = max(min_thinking_budget, base // 2)
    elif last_user.startswith("Tool result for "):
        if "exit_code=0" in last_user and last_len < 1200 and consecutive_reads == 0:
            budget = max(min_thinking_budget, int(base * 0.75))
        elif last_len > 4000:
            budget = max(budget, int(base * 1.25))
    elif last_len < 400:
        budget = max(min_thinking_budget, int(base * 0.75))
    elif last_len > 2500:
        budget = max(budget, int(base * 1.25))

    return clamp_budget(budget)
