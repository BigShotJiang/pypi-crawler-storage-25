"""mico slash command registry and dispatcher."""
from __future__ import annotations

import os
import sys
import inspect
from dataclasses import dataclass
from pathlib import Path
from typing import Any


@dataclass
class RuntimeState:
    """Mutable runtime state for REPL session — mutated by slash commands."""
    profile: Any  # model_recommender.Profile
    mode: str = "auto"  # auto | code | plan | review
    network_access: bool = True
    thinking: bool = False
    cwd: str = ""
    session_id: str = "interactive"
    quit_requested: bool = False
    multiline: bool = False
    effort: str = "medium"  # low | medium | high
    dryrun: bool = False
    # Live telemetry (updated by repl.py / cli.py streaming layer)
    history_chars_used: int = 0
    last_tokens_per_sec: float = 0.0
    live_tokens_per_sec: float = 0.0   # updated every chunk during streaming
    last_turn_seconds: float = 0.0
    live_stage: str = ""
    live_detail: str = ""
    turn_started_at: float = 0.0
    request_sent_at: float = 0.0
    first_token_at: float = 0.0
    last_progress_at: float = 0.0
    # Server lifecycle — reset to False after model switch so lazy load re-runs
    server_started: bool = False


@dataclass
class SlashCommand:
    """Registrable slash command."""
    name: str  # without leading slash
    description: str
    handler: Any
    args_hint: str = ""  # e.g. "<path>", "on|off"
    aliases: tuple[str, ...] = ()


REGISTRY: dict[str, SlashCommand] = {}


def register(cmd: SlashCommand) -> None:
    """Register a slash command."""
    REGISTRY[cmd.name] = cmd
    for alias in cmd.aliases:
        REGISTRY[alias] = cmd


def names() -> list[str]:
    """Return canonical command names (without aliases)."""
    return sorted({cmd.name for cmd in REGISTRY.values()})


def top_level_completions() -> list[SlashCommand]:
    """Return canonical slash commands for dropdown/autosuggest."""
    return [REGISTRY[name] for name in names()]


async def dispatch(line: str, state: RuntimeState) -> bool:
    """Dispatch a slash command line. Returns True if handled, False otherwise."""
    line = line.strip()
    if not line.startswith("/"):
        return False

    # Parse /command [args...]
    parts = line[1:].split(None, 1)
    if not parts:
        return False

    cmd_name = parts[0].lower()
    args = parts[1].split() if len(parts) > 1 else []

    cmd = REGISTRY.get(cmd_name)
    if not cmd:
        sys.stdout.write(f"✗ Bilinmeyen komut: /{cmd_name}. Liste için /help kullan.\n")
        return True

    try:
        if inspect.iscoroutinefunction(cmd.handler):
            await cmd.handler(args, state)
        else:
            cmd.handler(args, state)
    except Exception as exc:
        sys.stdout.write(f"✗ Command error: {exc}\n")
    return True


# ---------------------------------------------------------------------------
# Built-in command handlers
# ---------------------------------------------------------------------------

def _cmd_help(_args: list[str], _state: RuntimeState) -> None:
    """Show available core slash commands."""
    lines = [
        "Kullanılabilir slash komutları",
        "  /help                    bu yardımı göster",
        "  /mode <auto|code|plan|review>",
        "                           bir sonraki görev için çalışma modunu seç",
        "  /model                   aktif modeli göster veya picker aç",
        "  /thinking <on|off>       düşünme modunu aç/kapat",
        "  /cd <yol>                çalışma dizinini değiştir",
        "  /history                 oturum mesajlarını listele",
        "  /save                    oturumu kaydet",
        "  /compact                 geçmişi zorla özetle",
        "  /clear                   ekranı temizle",
        "  /reload                  profili diskten yeniden yükle",
        "  /exit                    mico'dan çık",
        "",
        "Kısayollar",
        "  Enter: gönder  |  Esc+Enter: yeni satır  |  Ctrl+D: çıkış",
        "  PgUp/PgDn: scroll  |  Ctrl+O: thinking'i genişlet/daralt",
    ]
    sys.stdout.write("\n" + "\n".join(lines) + "\n\n")


def _cmd_clear(args: list[str], state: RuntimeState) -> None:
    """Clear visible terminal output."""
    # Clear screen
    sys.stdout.write("\033[2J\033[H")
    sys.stdout.flush()
    sys.stdout.write("Ekran temizlendi.\n")


async def _cmd_compact(_args: list[str], state: RuntimeState) -> None:
    """Force history compaction now."""
    try:
        from . import cli as mico_cli
        session_id = state.session_id
        session_file = mico_cli.SESSIONS_DIR / f"{session_id}.json"
        if not session_file.exists():
            sys.stdout.write("Oturum dosyası bulunamadı.\n")
            return
        history = mico_cli.load_session_history(session_file)
        before_len = len(history)
        before_chars = sum(len(str(m.get("content", ""))) for m in history)
        history = await mico_cli.maybe_compact_history(history, session_id, force=True)
        after_len = len(history)
        after_chars = sum(len(str(m.get("content", ""))) for m in history)
        sys.stdout.write(
            f"Geçmiş özetlendi: {before_len} → {after_len} mesaj"
            f" ({before_chars // 1000}k → {after_chars // 1000}k karakter).\n"
        )
    except Exception as exc:
        sys.stdout.write(f"✗ Compact hatası: {exc}\n")


def _cmd_mode(args: list[str], state: RuntimeState) -> None:
    """Change mode or runner for next turn: /mode <auto|code|plan|review> or /mode runner <local|docker>"""
    if not args:
        sys.stdout.write(f"Geçerli mod: {state.mode}\n")
        return
    
    if args[0].lower() == "runner" and len(args) > 1:
        new_runner = args[1].lower()
        if new_runner in {"local", "docker"}:
            os.environ["MICO_RUNNER_TYPE"] = new_runner
            # Reset runner in existing contexts if needed, 
            # but usually it's picked up in run_tool
            sys.stdout.write(f"Runner ayarlandı: {new_runner}\n")
            return
        else:
            sys.stdout.write(f"✗ Geçersiz runner: {new_runner}. Seç: local, docker\n")
            return

    new_mode = args[0].lower()
    if new_mode not in {"auto", "code", "plan", "review"}:
        sys.stdout.write(f"✗ Geçersiz mod: {new_mode}. Seç: auto, code, plan, review\n")
        return
    state.mode = new_mode
    sys.stdout.write(f"Mod ayarlandı: {state.mode}\n")


def _cmd_model(args: list[str], state: RuntimeState) -> None:
    """`/model` → current model info or picker from local discoveries."""
    from . import model_recommender as mr
    from . import picker

    sub = args[0].lower() if args else ""
    if sub in {"show", "status"}:
        sys.stdout.write(
            f"Model   : {state.profile.model_name or '(yok)'}\n"
            f"Backend : {state.profile.backend or '(yok)'}\n"
            f"Path    : {state.profile.model_path or '(yok)'}\n"
        )
        return

    # /model, /model list, /model ls, /model select → hepsi picker açar
    discovered = mr.discover_models()
    mr.save_models(discovered)

    if not discovered:
        sys.stdout.write("Algılanan model yok.\n")
        return

    default_idx = next(
        (i for i, m in enumerate(discovered) if m.path == state.profile.model_path),
        0,
    )
    labels = [
        f"{m.name[:52]:52}  {m.params_b}B  {m.quant_bits}b  {m.size_gb}GB  {m.backend}"
        for m in discovered
    ]

    def _render_extra(i: int) -> str:
        return discovered[i].path

    sys.stdout.write("\n")
    idx = picker.pick(
        labels,
        title="Model seç (↑↓ gezin, Enter seç, Esc iptal):",
        default_index=default_idx,
        render_extra=_render_extra,
    )
    if idx is None:
        sys.stdout.write("İptal.\n")
        return

    chosen = discovered[idx]
    _switch_model_inplace(state, {
        "path": chosen.path,
        "name": chosen.name,
        "backend": chosen.backend,
        "size_gb": chosen.size_gb,
        "params_b": chosen.params_b,
        "quant_bits": chosen.quant_bits,
    })


def _switch_model_inplace(state: RuntimeState, entry: dict) -> None:
    try:
        from . import server as server_mod
        from . import cli as mico_cli
        from . import model_recommender as mr
        from . import hardware as hw_mod
        from .model_ops import discover_draft_models, is_compatible_draft_model

        hw = hw_mod.load_hardware() or hw_mod.detect_hardware()
        me = mr.ModelEntry(
            path=entry.get("path", ""),
            name=entry.get("name", ""),
            backend=entry.get("backend", "mlx"),
            size_gb=float(entry.get("size_gb") or 0),
            params_b=float(entry.get("params_b") or 0),
            quant_bits=int(entry.get("quant_bits") or 0),
        )
        previous_draft = getattr(state.profile, "draft_model_path", "") or ""
        new_profile = mr.recommend_profile(hw, me)

        resolved_draft = ""
        if new_profile.backend == "mlx" and new_profile.model_path:
            main_path = Path(new_profile.model_path)
            if (
                previous_draft
                and Path(previous_draft).exists()
                and previous_draft != new_profile.model_path
                and is_compatible_draft_model(main_path, Path(previous_draft))
            ):
                resolved_draft = previous_draft
            else:
                draft_candidates = discover_draft_models(new_profile.model_path, new_profile.backend)
                if draft_candidates:
                    resolved_draft = str(draft_candidates[0])
        new_profile.draft_model_path = resolved_draft
        state.profile = new_profile

        mr.save_profile(state.profile)
        mico_cli.MODEL = state.profile.model_path
        mico_cli.MODEL_PROVIDER = state.profile.backend
        mico_cli.MAX_TOKENS = state.profile.max_tokens
        mico_cli.CONTEXT_WINDOW_TOKENS = state.profile.context_window
        mico_cli.THINKING_BUDGET = state.profile.thinking_budget
        mico_cli.TEMPERATURE = state.profile.temperature
        mico_cli.DRAFT_MODEL = state.profile.draft_model_path or ""
        os.environ["MODEL_NAME"] = state.profile.model_path
        os.environ["MODEL_PROVIDER"] = state.profile.backend
        os.environ["DRAFT_MODEL_NAME"] = mico_cli.DRAFT_MODEL

        # VLM backends don't support request-level thinking params — force off
        try:
            from mico.server import _is_vlm_model
            if _is_vlm_model(state.profile.model_path):
                mico_cli.THINKING = False
                state.thinking = False
                sys.stdout.write("[!] VLM modeli — thinking modu devre dışı.\n")
            else:
                mico_cli.THINKING = state.profile.thinking
                state.thinking = state.profile.thinking
        except Exception:
            mico_cli.THINKING = state.profile.thinking

        sys.stdout.write("\nServer durduruluyor (sonraki mesajda yeni modelle başlar)...\n")
        server_mod.stop()
        state.server_started = False
        sys.stdout.write(
            f"✓ Aktif: {state.profile.model_name}\n"
            f"✓ Draft: {state.profile.draft_model_path or 'none'}\n"
        )
    except Exception as exc:
        sys.stdout.write(f"✗ Model değiştirme hatası: {exc}\n")



def _cmd_thinking(args: list[str], state: RuntimeState) -> None:
    if not args:
        status = "açık" if state.thinking else "kapalı"
        sys.stdout.write(f"Düşünme modu: {status}\n")
        return
    flag = args[0].lower()
    want_on = (flag == "on")
    if want_on:
        try:
            from mico.model_client import supports_extended_generation_controls
            from mico.server import _is_vlm_model
            import mico.cli as _cli
            if not supports_extended_generation_controls():
                sys.stdout.write(
                    "[!] Bu backend thinking modunu desteklemiyor "
                    "(sadece yerel MLX ve uyumlu sunucular destekler).\n"
                )
                return
            if _is_vlm_model(str(getattr(_cli, "MODEL", "") or "")):
                sys.stdout.write(
                    "[!] VLM modellerde thinking request parametresi desteklenmiyor.\n"
                )
                return
        except Exception:
            pass
    state.thinking = want_on
    sys.stdout.write(f"Düşünme modu: {'açık' if state.thinking else 'kapalı'}\n")


def _cmd_cd(args: list[str], state: RuntimeState) -> None:
    if not args:
        sys.stdout.write(f"Geçerli dizin: {os.getcwd()}\n")
        return
    path = " ".join(args)
    try:
        os.chdir(path)
        state.cwd = os.getcwd()
        sys.stdout.write(f"Değiştirildi: {state.cwd}\n")
    except Exception as exc:
        sys.stdout.write(f"✗ Hata: {exc}\n")


def _cmd_history(_args: list[str], state: RuntimeState) -> None:
    try:
        from . import cli as mico_cli
        sf = mico_cli.SESSIONS_DIR / f"{state.session_id}.json"
        if not sf.exists():
            return
        history = mico_cli.load_session_history(sf)
        for i, msg in enumerate(history or [], 1):
            sys.stdout.write(f"  {i:3d}. [{msg.get('role','?'):9s}] {str(msg.get('content',''))[:60]}\n")
    except Exception as exc:
        sys.stdout.write(f"✗ History hatası: {exc}\n")


def _cmd_save(_args: list[str], state: RuntimeState) -> None:
    try:
        from . import cli as mico_cli
        sf = mico_cli.SESSIONS_DIR / f"{state.session_id}.json"
        history = mico_cli.load_session_history(sf)
        mico_cli.save_session(state.session_id, history)
        sys.stdout.write("Oturum kayıtlı.\n")
    except Exception as exc:
        sys.stdout.write(f"✗ Save hatası: {exc}\n")


def _cmd_reload(_args: list[str], state: RuntimeState) -> None:
    try:
        from . import model_recommender as mr
        new_profile = mr.load_profile()
        if new_profile:
            state.profile = new_profile
            sys.stdout.write("✓ Profil diskten yeniden yüklendi.\n")
    except Exception as exc:
        sys.stdout.write(f"✗ Reload hatası: {exc}\n")


def _cmd_exit(args: list[str], state: RuntimeState) -> None:
    state.quit_requested = True
    sys.stdout.write("Çıkılıyor...\n")


def _register_builtins() -> None:
    """Register all built-in slash commands."""
    register(SlashCommand("help", "yardımı göster", _cmd_help))
    register(SlashCommand("clear", "ekranı temizle", _cmd_clear))
    register(SlashCommand("compact", "geçmişi özetle", _cmd_compact))
    register(SlashCommand("mode", "modu değiştir", _cmd_mode, args_hint="<auto|code|plan|review>"))
    register(SlashCommand("model", "aktif modeli göster veya seç", _cmd_model, aliases=("models",)))
    register(SlashCommand("thinking", "düşünme modunu aç/kapat", _cmd_thinking, args_hint="<on|off>"))
    register(SlashCommand("cd", "çalışma dizinini değiştir", _cmd_cd, args_hint="<yol>"))
    register(SlashCommand("history", "oturum mesajlarını listele", _cmd_history))
    register(SlashCommand("save", "oturumu kaydet", _cmd_save))
    register(SlashCommand("reload", "profili diskten yeniden yükle", _cmd_reload))
    register(SlashCommand("exit", "temiz çıkış", _cmd_exit))


_register_builtins()
