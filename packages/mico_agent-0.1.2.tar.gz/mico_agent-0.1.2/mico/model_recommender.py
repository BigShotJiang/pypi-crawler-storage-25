"""Model + profil önerisi.

İki sorumluluk:
1. Yerel modelleri keşfet (`~/Desktop/models/`, HF cache, LM Studio, kullanıcı path).
2. Donanım × seçilen model → uygun profil hesapla; uygun model yoksa generic
   bir "şu büyüklük + şu kuantizasyon iyi olur" tavsiyesi üret.
"""
from __future__ import annotations

import json
import os
import re
from dataclasses import asdict, dataclass, field
from pathlib import Path

from .hardware import HardwareInfo

CONFIG_DIR = Path(os.environ.get("MICO_HOME", str(Path.home() / ".mico")))
MODELS_PATH = CONFIG_DIR / "models.json"
PROFILE_PATH = CONFIG_DIR / "profile.json"


# ---------------------------------------------------------------------------
# Model discovery
# ---------------------------------------------------------------------------

DEFAULT_SCAN_DIRS = [
    Path.home() / "Desktop",
    Path.home() / "Desktop" / "models",
    Path.home() / "Desktop" / "models" / "mlx",
    Path.home() / ".cache" / "huggingface" / "hub",
    Path.home() / ".lmstudio" / "models",
    Path.home() / "models",
]
HF_HOME = os.environ.get("HF_HOME")
if HF_HOME:
    DEFAULT_SCAN_DIRS.append(Path(HF_HOME) / "hub")

# Paths to skip when doing full-system scan (to avoid slow/irrelevant dirs)
_SYSTEM_SCAN_SKIP = {
    ".Trash", ".git", "node_modules", "__pycache__", ".venv", "venv",
    ".npm", ".yarn", "Library/Caches", "Library/Application Support",
    "Library/Containers", ".docker", ".gradle", "Android", "Xcode",
    "DerivedData", ".local/share/Trash",
}


@dataclass
class ModelEntry:
    path: str
    name: str
    backend: str = "mlx"          # mlx | gguf | safetensors | unknown
    size_gb: float = 0.0
    params_b: float = 0.0          # estimated billions of params
    quant_bits: int = 0            # 0 = unknown, else 2/3/4/5/6/8/16
    notes: str = ""


_PARAM_PATTERN = re.compile(r"(?:^|[-_/.\s])(\d+(?:\.\d+)?)\s*[bB](?![a-zA-Z])")
_QUANT_PATTERN = re.compile(
    r"(?:^|[-_/.])(?:q|int|fp|mxfp)?(\d+)\s*[-_]?bit", re.I
)
_QUANT_SHORT = re.compile(r"(?:^|[-_/.])(q\d|fp\d|int\d|mxfp\d)(?:[-_/.]|$)", re.I)


def _estimate_params(name: str) -> float:
    m = _PARAM_PATTERN.search(name)
    if not m:
        return 0.0
    try:
        return float(m.group(1))
    except ValueError:
        return 0.0


def _estimate_quant(name: str) -> int:
    name_l = name.lower()
    m = _QUANT_PATTERN.search(name_l)
    if m:
        try:
            return int(m.group(1))
        except ValueError:
            pass
    m2 = _QUANT_SHORT.search(name_l)
    if m2:
        token = m2.group(1)
        digits = re.search(r"\d+", token)
        if digits:
            try:
                return int(digits.group())
            except ValueError:
                pass
    if "8bit" in name_l or "mxfp8" in name_l:
        return 8
    if "4bit" in name_l:
        return 4
    if "bf16" in name_l or "fp16" in name_l:
        return 16
    return 0


def _detect_backend(path: Path) -> str:
    """Backend tespiti.

    Sıra:
      1. .gguf dosya/dizini → gguf
      2. Klasör adında "mtplx" var → mtplx
      3. config.json'da mtplx anahtarı var → mtplx
      4. config.json'da `quantization` veya mxfp/mlx işareti → mlx
      5. Path/isim "mlx" içeriyor → mlx (zayıf imza, son çare)
      6. .safetensors + config.json → safetensors (HF-tarz, llama.cpp/transformers)
    """
    if not path.is_dir():
        if path.suffix == ".gguf":
            return "gguf"
        return "unknown"
    children = {c.name.lower() for c in path.iterdir() if c.is_file()}
    if any(c.endswith(".gguf") for c in children):
        return "gguf"

    # MTPLX: klasör adında "mtplx" geçiyorsa kesin tanı
    name_lower = path.name.lower()
    if "mtplx" in name_lower:
        return "mtplx"

    has_safetensors = any(c.endswith(".safetensors") for c in children)
    has_config = "config.json" in children
    if not (has_safetensors and has_config):
        return "unknown"

    try:
        cfg_text = (path / "config.json").read_text(encoding="utf-8", errors="replace")
        cfg = json.loads(cfg_text)

        # MTPLX: config.json'da mtplx işareti
        if "mtplx_version" in cfg or "mtplx_profile" in cfg or "mtplx" in str(cfg.get("model_type", "")).lower():
            return "mtplx"

        # MLX'in net imzası: config.json içinde "quantization" dict'i ve genelde
        # "mode": "mxfp..." veya {"group_size": ..., "bits": ...} bulunur.
        q = cfg.get("quantization")
        if isinstance(q, dict) and {"group_size", "bits"} <= q.keys():
            return "mlx"
        if isinstance(q, dict) and isinstance(q.get("mode"), str) and q["mode"].startswith(("mxfp", "fp")):
            return "mlx"
    except (OSError, json.JSONDecodeError):
        pass

    # Zayıf imza: path adı "mlx" geçiyorsa MLX kabul et (mlx-community/* veya mlx adlı klasörler)
    parent_lower = path.parent.name.lower() if path.parent else ""
    if "mlx" in name_lower or "mlx" in parent_lower or "mxfp" in name_lower:
        return "mlx"

    return "safetensors"


def _dir_size_gb(path: Path) -> float:
    total = 0
    try:
        for p in path.rglob("*"):
            if p.is_file():
                try:
                    total += p.stat().st_size
                except OSError:
                    pass
    except OSError:
        return 0.0
    return round(total / (1024**3), 2)


def _add_model_entry(child: Path, found: list[ModelEntry], seen: set[str]) -> None:
    """Try to add child as a model entry into found list."""
    try:
        rp = str(child.resolve())
    except OSError:
        rp = str(child)
    if rp in seen:
        return
    seen.add(rp)
    if child.is_dir():
        backend = _detect_backend(child)
        if backend == "unknown":
            if child.name.startswith("models--"):
                snap = child / "snapshots"
                if snap.exists():
                    for s in sorted(snap.iterdir()):
                        if s.is_dir():
                            bk = _detect_backend(s)
                            if bk != "unknown":
                                try:
                                    srp = str(s.resolve())
                                except OSError:
                                    srp = str(s)
                                if srp in seen:
                                    break
                                seen.add(srp)
                                name = child.name.replace("models--", "").replace("--", "/")
                                entry = ModelEntry(
                                    path=str(s),
                                    name=name,
                                    backend=bk,
                                    size_gb=_dir_size_gb(s),
                                    params_b=_estimate_params(name),
                                    quant_bits=_estimate_quant(name),
                                )
                                found.append(entry)
                                break
            return
        entry = ModelEntry(
            path=str(child),
            name=child.name,
            backend=backend,
            size_gb=_dir_size_gb(child),
            params_b=_estimate_params(child.name),
            quant_bits=_estimate_quant(child.name),
        )
        found.append(entry)
    elif child.suffix == ".gguf":
        try:
            size = round(child.stat().st_size / (1024**3), 2)
        except OSError:
            size = 0.0
        entry = ModelEntry(
            path=str(child),
            name=child.stem,
            backend="gguf",
            size_gb=size,
            params_b=_estimate_params(child.stem),
            quant_bits=_estimate_quant(child.stem),
        )
        found.append(entry)


def _scan_dir_shallow(root: Path, found: list[ModelEntry], seen: set[str]) -> None:
    """Scan one directory (non-recursive) for model subdirs/files."""
    if not root.exists():
        return
    try:
        children = [c for c in root.iterdir() if not c.name.startswith(".")]
    except OSError:
        return
    for child in children:
        _add_model_entry(child, found, seen)


def discover_all_system_models(timeout_s: float = 8.0) -> list[ModelEntry]:
    """Full-system scan for LLM models anywhere on the filesystem.

    Uses `find` to locate config.json files within reasonable depth limits,
    then checks each parent directory for model signatures. Runs with a
    timeout so it doesn't block startup.
    """
    import subprocess
    import threading
    found: list[ModelEntry] = []
    seen: set[str] = set()

    # Pre-scan known fast paths first
    for d in DEFAULT_SCAN_DIRS:
        _scan_dir_shallow(d, found, seen)

    # System-wide: find config.json files up to depth 8 under home dir
    results: list[str] = []
    done = threading.Event()

    def _find_worker() -> None:
        try:
            proc = subprocess.run(
                [
                    "find", str(Path.home()), "-maxdepth", "8",
                    "-name", "config.json",
                    "-not", "-path", "*/.*/*",
                    "-not", "-path", "*/node_modules/*",
                    "-not", "-path", "*/__pycache__/*",
                    "-not", "-path", "*/Library/Caches/*",
                    "-not", "-path", "*/Library/Application Support/*",
                ],
                capture_output=True, text=True, timeout=timeout_s,
            )
            results.extend(proc.stdout.splitlines())
        except Exception:
            pass
        finally:
            done.set()

    t = threading.Thread(target=_find_worker, daemon=True)
    t.start()
    done.wait(timeout=timeout_s + 1)

    for cfg_path_str in results:
        cfg_path = Path(cfg_path_str)
        model_dir = cfg_path.parent
        _add_model_entry(model_dir, found, seen)

    found.sort(key=lambda e: (-(e.params_b or 0), e.name))
    return found


def discover_models(extra_dirs: list[Path] | None = None, system_scan: bool = False) -> list[ModelEntry]:
    seen: set[str] = set()
    found: list[ModelEntry] = []
    if system_scan:
        return discover_all_system_models()
    dirs = list(DEFAULT_SCAN_DIRS) + list(extra_dirs or [])
    for root in dirs:
        _scan_dir_shallow(root, found, seen)

    # Also scan parent of any extra_dirs entries (for direct model paths)
    for extra in extra_dirs or []:
        ep = Path(extra)
        if ep.exists() and ep.is_dir():
            _add_model_entry(ep, found, seen)

    found.sort(key=lambda e: (-(e.params_b or 0), e.name))
    return found




# ---------------------------------------------------------------------------
# Profile recommendation
# ---------------------------------------------------------------------------

@dataclass
class Profile:
    name: str = "balanced"
    backend: str = "mlx"
    model_path: str = ""
    model_name: str = ""
    context_window: int = 8192
    max_tokens: int = 2048
    prefill_step_size: int = 2048
    # kv_bits / quantized_kv_start / max_kv_size: kept for JSON compat but
    # mlx_lm server does NOT support these flags — they only work with
    # mlx_lm generate CLI. Ignored at server start time.
    kv_bits: int = 0
    quantized_kv_start: int = 0
    max_kv_size: int = 0
    prompt_cache_size: int = 8
    prompt_cache_bytes: str = "1GB"
    thinking: bool = False
    thinking_budget: int = 0
    # Sampling: temperature=0.0 → deterministic (best for coding/agentic tasks)
    # min_p=0.05 → cuts off low-prob tokens, prevents repetition loops
    # repetition_penalty=1.1 → mild penalty to prevent exact token repetition
    temperature: float = 0.0
    min_p: float = 0.05
    repetition_penalty: float = 1.1
    repetition_context_size: int = 64
    draft_model_path: str = ""   # speculative decoding — smaller companion model
    num_draft_tokens: int = 0    # 0 = disabled; 4-8 typical
    notes: list[str] = field(default_factory=list)


def _model_runtime_footprint_gb(params_b: float, quant_bits: int) -> float:
    """Tahmini bellek ayak izi (model ağırlıkları + KV + activations).

    Yaklaşım: weights ~ params * (bits/8) GB, KV ve overhead için x1.4 katsayı.
    """
    if params_b <= 0:
        return 0.0
    bits = quant_bits if quant_bits > 0 else 16
    weight_gb = params_b * (bits / 8.0)
    return round(weight_gb * 1.4, 2)


def _apply_family_sampling(p: "Profile", model_name: str) -> None:
    """Model adından aile tespiti yaparak resmi önerilen coding sampling ayarlarını uygular.

    Her giriş kaynağı:
      Qwen3 / Qwen3.5 / Qwen3.6  — Qwen3 HF model kartı (Alibaba, 2025)
        coding modu: temperature=0.6, top_p=0.95, top_k=20, min_p kapalı
        /no_think modu (deterministic): temperature=0.0
        Burada coding agentic flow kullandığımız için thinking=True → 0.6 / top_p=0.95 / top_k=20
        thinking=False → 0.0 (deterministik, instruction-following için)
      Qwen2.5 / QwQ            — Qwen2.5 HF model kartı (Alibaba, 2024)
        coding: temperature=0.7, top_p=0.8, min_p=0.0 (top_k baskın)
      DeepSeek-R1 / DeepSeek-V3 — DeepSeek teknik raporu / system card (2025)
        R1 (reasoning): temperature=0.6, top_p=0.95 — model kartı önerisi
        V3 (non-reasoning): temperature=0.0 — deterministik kod üretimi için
      Llama 3.x                 — Meta Llama 3 model kartı
        temperature=0.6, top_p=0.9 (Meta önerisi: "for creative tasks"; coding için 0.0-0.6 arası)
        Coding için deterministik: temperature=0.0
      Gemma 3 / Gemma 4         — Google Gemma 3 teknik raporu (2025)
        resmi önerilen: temperature=1.0, top_k=64, top_p=0.95
        (Google, Gemma'nın bu ayarlarda en kararlı olduğunu ölçtü)
      Mistral / Devstral        — Mistral AI dokümantasyonu
        coding: temperature=0.0 (deterministik); Devstral için de aynı
      Phi-3 / Phi-4             — Microsoft Phi-3 teknik raporu
        temperature=0.0, top_p=1.0 (deterministik; reasoning trace yokken)
      SmolLM3                   — HuggingFace SmolLM3 model kartı (2025)
        temperature=0.6, top_p=0.95 (Qwen3 stili /think modu)
      Gemma 2                   — Google Gemma 2 model kartı
        temperature=1.0, top_k=64, top_p=0.95 (Gemma 3 ile aynı politika)
      IBM Granite 4             — IBM Granite 3.x/4 model kartı
        temperature=0.0 (deterministik; Granite agentic coding için bu değeri önerir)
      Varsayılan (bilinmeyen aile)
        temperature=0.0 — coding/agentic görevlerde güvenli deterministik taban
        min_p=0.05 — mlx_lm'nin degenerate token loop koruması
        repetition_penalty=1.1 — takılma önleyici hafif ceza
    """
    n = (model_name or "").lower()

    # Qwen3 / Qwen3.5 / Qwen3.6 — düşünce modunda 0.6/top_p=0.95/top_k=20
    # Düşünce kapalıysa (instruction-only) 0.0 deterministik.
    if "qwen3" in n:
        # thinking aktif olduğunda model kartındaki "with thinking" reçetesi
        p.temperature = 0.6
        p.min_p = 0.0        # Qwen3 kartı top_k=20 + top_p=0.95 kullanır, min_p yok
        p.repetition_penalty = 1.0
        p.repetition_context_size = 0
        p.notes.append(
            "Sampling: Qwen3 resmi önerisi (thinking=on) — temp=0.6, top_p=0.95, top_k=20"
        )
        return

    # Qwen2.5 / QwQ
    if "qwen2.5" in n or "qwq" in n:
        p.temperature = 0.7
        p.min_p = 0.0
        p.repetition_penalty = 1.0
        p.repetition_context_size = 0
        p.notes.append(
            "Sampling: Qwen2.5 resmi önerisi — temp=0.7, top_p=0.8"
        )
        return

    # DeepSeek-R1 (reasoning) — model kartı temp=0.6 öneriyor
    if "deepseek" in n and ("r1" in n or "r2" in n):
        p.temperature = 0.6
        p.min_p = 0.0
        p.repetition_penalty = 1.0
        p.repetition_context_size = 0
        p.notes.append(
            "Sampling: DeepSeek-R1 resmi önerisi — temp=0.6, top_p=0.95"
        )
        return

    # DeepSeek-V3 / genel DeepSeek (non-reasoning)
    if "deepseek" in n:
        p.temperature = 0.0
        p.min_p = 0.0
        p.repetition_penalty = 1.0
        p.repetition_context_size = 0
        p.notes.append(
            "Sampling: DeepSeek-V3 coding önerisi — temp=0.0 (deterministik)"
        )
        return

    # Gemma 3 / Gemma 4 — Google resmi: temp=1.0, top_k=64, top_p=0.95
    if "gemma" in n:
        p.temperature = 1.0
        p.min_p = 0.0
        p.repetition_penalty = 1.0
        p.repetition_context_size = 0
        p.notes.append(
            "Sampling: Gemma resmi önerisi — temp=1.0, top_k=64, top_p=0.95"
        )
        return

    # Llama 3.x — Meta önerisi coding için deterministik
    if "llama" in n:
        p.temperature = 0.0
        p.min_p = 0.0
        p.repetition_penalty = 1.0
        p.repetition_context_size = 0
        p.notes.append(
            "Sampling: Llama 3 coding önerisi — temp=0.0 (deterministik)"
        )
        return

    # Mistral / Devstral
    if "mistral" in n or "devstral" in n or "magistral" in n:
        p.temperature = 0.0
        p.min_p = 0.0
        p.repetition_penalty = 1.0
        p.repetition_context_size = 0
        p.notes.append(
            "Sampling: Mistral coding önerisi — temp=0.0 (deterministik)"
        )
        return

    # Phi-3 / Phi-4
    if "phi" in n:
        p.temperature = 0.0
        p.min_p = 0.0
        p.repetition_penalty = 1.0
        p.repetition_context_size = 0
        p.notes.append(
            "Sampling: Phi resmi önerisi — temp=0.0 (deterministik)"
        )
        return

    # SmolLM3
    if "smollm" in n:
        p.temperature = 0.6
        p.min_p = 0.0
        p.repetition_penalty = 1.0
        p.repetition_context_size = 0
        p.notes.append(
            "Sampling: SmolLM3 resmi önerisi — temp=0.6, top_p=0.95"
        )
        return

    # IBM Granite 4
    if "granite" in n:
        p.temperature = 0.0
        p.min_p = 0.0
        p.repetition_penalty = 1.0
        p.repetition_context_size = 0
        p.notes.append(
            "Sampling: Granite coding önerisi — temp=0.0 (deterministik)"
        )
        return

    # Bilinmeyen aile — güvenli coding taban değerleri
    p.temperature = 0.0
    p.min_p = 0.05
    p.repetition_penalty = 1.1
    p.repetition_context_size = 64


def _read_model_config(model_path: str) -> dict:
    """Read config.json from model directory. Returns {} on failure."""
    import json as _json
    from pathlib import Path as _Path
    try:
        return _json.loads((_Path(model_path) / "config.json").read_text(encoding="utf-8"))
    except Exception:
        return {}


def _read_model_context_limit(model_path: str) -> int:
    """Read max_position_embeddings from model config.json. Returns 0 if not found."""
    cfg = _read_model_config(model_path)
    for key in ("max_position_embeddings", "max_seq_len", "max_sequence_length", "n_positions"):
        val = cfg.get(key)
        if isinstance(val, int) and val > 0:
            return val
    return 0


def _read_model_quant_bits(model_path: str) -> int:
    """Read actual quantization bits from config.json. Returns 0 if not found.

    Checks (in order):
      1. cfg["quantization"]["bits"]  — MLX standard
      2. cfg["quantization"]["q_group_size"] heuristic (not reliable, skip)
      3. cfg["torch_dtype"] / cfg["model_type"] heuristic for fp16/bf16 → 16
    """
    cfg = _read_model_config(model_path)
    q = cfg.get("quantization")
    if isinstance(q, dict):
        bits = q.get("bits")
        if isinstance(bits, int) and bits > 0:
            return bits
    # torch_dtype present → full precision safetensors (HF native)
    dtype = cfg.get("torch_dtype", "")
    if dtype in ("float16", "bfloat16"):
        return 16
    if dtype == "float32":
        return 32
    return 0


def _kv_cache_gb_per_token(cfg: dict) -> float:
    """Estimate KV cache memory in GB per token (float16, no quantization).

    Formula: 2 (K+V) × num_layers × num_kv_heads × head_dim × 2 bytes / 1e9
    Falls back to a conservative estimate if fields missing.
    """
    num_layers = cfg.get("num_hidden_layers") or cfg.get("n_layer") or 32
    # GQA: num_key_value_heads may differ from num_attention_heads
    num_kv_heads = (
        cfg.get("num_key_value_heads")
        or cfg.get("num_attention_heads")
        or cfg.get("n_head")
        or 8
    )
    hidden_size = cfg.get("hidden_size") or cfg.get("n_embd") or 4096
    num_heads = cfg.get("num_attention_heads") or cfg.get("n_head") or num_kv_heads
    head_dim = cfg.get("head_dim") or (hidden_size // max(num_heads, 1))
    # 2 (K+V) × layers × kv_heads × head_dim × 2 bytes (float16)
    bytes_per_token = 2 * num_layers * num_kv_heads * head_dim * 2
    return bytes_per_token / 1e9


def _optimize_kv_and_context(
    model_path: str,
    free_gb: float,
    model_ctx_limit: int,
    conservative_ctx: int,
) -> tuple[int, int, int, str]:
    """Choose optimal kv_bits, context_window, prompt_cache_bytes given free RAM.

    Returns (kv_bits, context_window, prompt_cache_mb, note).
    """
    cfg = _read_model_config(model_path)
    gb_per_token_f16 = _kv_cache_gb_per_token(cfg)

    # free_gb is already net of model footprint and OS reserve (caller's responsibility).
    kv_budget_gb = max(0.2, free_gb)

    # Try kv_bits options from best quality to most compressed
    for kv_bits, scale in ((0, 1.0), (8, 0.5), (4, 0.25)):
        gb_per_token = gb_per_token_f16 * scale
        if gb_per_token <= 0:
            continue
        # Max context that fits in kv_budget (leave 30% for prompt cache)
        max_ctx_from_ram = int((kv_budget_gb * 0.70) / gb_per_token)
        # Round down to nearest power-of-2-ish checkpoint
        for ctx in (131072, 65536, 32768, 16384, 8192, 4096):
            if ctx <= max_ctx_from_ram and ctx <= model_ctx_limit and ctx >= conservative_ctx // 2:
                # Remaining budget after context → prompt cache
                ctx_cost_gb = ctx * gb_per_token
                remaining_gb = kv_budget_gb - ctx_cost_gb
                cache_mb = max(256, min(4096, int(remaining_gb * 1024 * 0.8)))
                kv_label = "f16" if kv_bits == 0 else f"{kv_bits}bit"
                note = (
                    f"KV optimize: kv={kv_label}, ctx={ctx}, "
                    f"KV={ctx_cost_gb:.2f}GB, cache≈{cache_mb}MB "
                    f"(free={free_gb:.1f}GB, {gb_per_token_f16*1e6:.0f}B/Mtok f16)"
                )
                return kv_bits, ctx, cache_mb, note
    # Fallback: most compressed, smallest context
    return 4, conservative_ctx, 256, f"KV fallback: bellek çok dar (free={free_gb:.1f}GB)"


def recommend_profile(hw: HardwareInfo, model: ModelEntry) -> Profile:
    """Donanım × model → ayar seti."""
    mem = hw.memory_gb
    params = model.params_b
    # Priority: config.json (real) > name heuristic > backend default
    cfg_bits = _read_model_quant_bits(model.path)
    bits = cfg_bits or model.quant_bits or (8 if model.backend == "gguf" else 4)
    footprint = _model_runtime_footprint_gb(params, bits)
    pressure = footprint / max(mem, 1.0) if mem else 1.0
    model_ctx_limit = _read_model_context_limit(model.path)

    p = Profile(
        backend=model.backend or "mlx",
        model_path=model.path,
        model_name=model.name,
    )
    bits_source = "config.json" if cfg_bits else ("isim tahmini" if model.quant_bits else "backend tahmini")
    p.notes.append(
        f"Tahmini ayak izi: {footprint} GB / {mem} GB ({pressure*100:.0f}% bellek baskısı)"
        f" — {bits}bit ({bits_source})"
    )

    # Context window + prompt cache bytes — memory pressure'a göre
    # 24 GB ve altı Apple Silicon hedefinde daha muhafazakar davran.
    constrained_24g = mem <= 24
    large_model_on_24g = constrained_24g and params >= 20
    if mem >= 64 and pressure < 0.45:
        p.context_window = 32768
        p.max_tokens = 4096
        p.prompt_cache_bytes = "4GB"
        p.name = "deep"
    elif mem >= 24 and pressure < 0.6 and not large_model_on_24g:
        p.context_window = 16384
        p.max_tokens = 2048
        p.prompt_cache_bytes = "2GB"
        p.name = "balanced"
    elif mem >= 16 and pressure < 0.75 and not large_model_on_24g:
        p.context_window = 8192
        p.max_tokens = 2048
        p.prompt_cache_bytes = "1GB"
        p.name = "fast"
    else:
        p.context_window = 4096
        p.max_tokens = 1024
        p.prompt_cache_bytes = "512MB"
        p.name = "tight"
        p.notes.append("DİKKAT: bellek dar — bağlam ve çıktı boyutu sınırlı.")

    if constrained_24g and p.name == "balanced" and pressure >= 0.5:
        p.context_window = min(p.context_window, 8192)
        p.max_tokens = min(p.max_tokens, 1536)
        p.prompt_cache_bytes = "1GB"
        p.name = "fast"
        p.notes.append("24 GB sınıfında baskı yükseldiği için balanced -> fast düşürüldü.")

    # Prompt cache slots — agentic multi-turn için 8 ideal, dar bellekte 4
    if constrained_24g and (pressure >= 0.6 or params >= 14):
        p.prompt_cache_size = 4
    else:
        p.prompt_cache_size = 8 if mem >= 16 else 4

    # prefill_step_size: küçük/orta makinelerde agresif prefill ilk tool loop'u şişiriyor.
    if pressure >= 0.8 or large_model_on_24g:
        p.prefill_step_size = 512
    elif pressure >= 0.6 or params >= 14:
        p.prefill_step_size = 1024
    else:
        p.prefill_step_size = 1536 if constrained_24g else 2048

    # Cap context_window to what the model actually supports (from config.json).
    # Also cap max_tokens to context_window (can't generate more than context allows).
    if model_ctx_limit > 0:
        # Use the lesser of: what hardware can afford vs. what the model supports.
        # But never exceed model's real limit.
        p.context_window = min(p.context_window, model_ctx_limit)
        # If model supports much more than our conservative hardware estimate,
        # be slightly more generous (up to 2x the conservative estimate, still within model limit).
        hardware_generous = p.context_window * 2
        if model_ctx_limit >= hardware_generous:
            p.context_window = min(hardware_generous, model_ctx_limit)
    p.max_tokens = min(p.max_tokens, p.context_window // 2)

    # KV cache + prompt cache RAM optimization.
    # free_gb = RAM left after model weights and a small OS reserve.
    free_gb = max(0.5, mem - footprint - 1.0)
    opt_kv_bits, opt_ctx, opt_cache_mb, opt_note = _optimize_kv_and_context(
        model.path, free_gb, model_ctx_limit or p.context_window, p.context_window
    )
    p.kv_bits = opt_kv_bits
    p.context_window = opt_ctx
    p.max_tokens = min(p.max_tokens, p.context_window // 2)
    p.prompt_cache_bytes = f"{opt_cache_mb}MB"
    p.notes.append(opt_note)

    # Sampling parameters — her model ailesinin resmi önerilen coding ayarları.
    _apply_family_sampling(p, model.name)

    # Thinking — enable for models known to support extended reasoning.
    _name_lower = (model.name or "").lower()
    _thinking_models = ("qwen3", "qwen3.6", "qwen2.5", "qwq", "deepseek-r", "deepseek_r", "r1", "r2")
    if any(k in _name_lower for k in _thinking_models) and pressure < 0.85:
        p.thinking = True
        if mem >= 32 and pressure < 0.6:
            p.thinking_budget = max(512, min(4096, p.context_window // 10))
        else:
            p.thinking_budget = 2048
        p.max_tokens = max(p.max_tokens, p.thinking_budget + 1024)
    elif any(k in _name_lower for k in _thinking_models):
        p.thinking = False
        p.notes.append("Thinking kapatıldı: bu donanım/model kombinasyonunda önce stabilite ve bellek öncelikli.")

    # Thinking=False olan Qwen3/DeepSeek-R1 modelleri için sampling düzelt:
    # Resmi öneri — thinking kapalıysa temperature=0.0 (deterministik instruction modu).
    if not p.thinking and "qwen3" in _name_lower:
        p.temperature = 0.0
        p.notes.append("Sampling güncellendi: thinking=off → Qwen3 deterministik moda geçildi (temp=0.0)")
    if not p.thinking and "deepseek" in _name_lower and any(k in _name_lower for k in ("r1", "r2")):
        p.temperature = 0.0
        p.notes.append("Sampling güncellendi: thinking=off → DeepSeek-R1 deterministik moda geçildi (temp=0.0)")

    # MTPLX modelleri için özel ayarlar
    if model.backend == "mtplx":
        p.thinking = True
        p.thinking_budget = max(512, min(4096, p.context_window // 10))
        p.max_tokens = max(p.max_tokens, p.thinking_budget + 1024)
        p.notes.append("MTPLX native MTP backend — mlx_lm/mlx_vlm yerine mtplx server kullanılır.")

    # Backend uyarıları
    if hw.gpu_type == "apple-integrated":
        if model.backend not in {"mlx", "mtplx"}:
            p.notes.append("Apple Silicon'da en hızlı backend MLX — bu model GGUF, llama.cpp Metal kullanılacak.")
    elif hw.gpu_type == "nvidia":
        if model.backend in {"mlx", "mtplx"}:
            p.notes.append("MLX/MTPLX Apple Silicon'a özgü — bu modeli kullanmak için Apple Silicon gerekli.")

    return p


# ---------------------------------------------------------------------------
# When no suitable model exists
# ---------------------------------------------------------------------------

def generic_recommendation(hw: HardwareInfo) -> str:
    """Yerel model yoksa: donanıma göre 'ne tür model indirsem' tavsiyesi.
    Spesifik HF link vermez — kullanıcı kendi karar versin.
    """
    mem = hw.memory_gb
    is_apple = hw.gpu_type == "apple-integrated"
    backend_hint = "MLX (mlx-community/* HuggingFace)" if is_apple else (
        "GGUF (TheBloke/* veya mlc-llm)" if hw.gpu_type in {"nvidia", "amd", "intel"} else "GGUF (CPU)"
    )

    if mem >= 64:
        target = "27B 4-bit veya 14B 8-bit (ideal: 70B 4-bit)"
    elif mem >= 36:
        target = "14B 4-bit veya 8B 8-bit (üstü zorlanır)"
    elif mem >= 24:
        target = "8B 4-bit veya 14B 3-bit"
    elif mem >= 16:
        target = "8B 4-bit (öneri) veya 4B 8-bit"
    elif mem >= 8:
        target = "4B 4-bit veya 1.5B 8-bit"
    else:
        target = "1.5B 4-bit (sınırda)"

    return (
        f"Yerel model bulunamadı.\n"
        f"  Donanım: {hw.chip or hw.os} / {mem:.0f} GB\n"
        f"  Önerilen büyüklük: {target}\n"
        f"  Backend: {backend_hint}\n"
        f"\n"
        f"Modeli indirip ana dizinine koy (örn. ~/Desktop/models/), sonra `mico setup` "
        f"komutunu yeniden çalıştır."
    )


# ---------------------------------------------------------------------------
# Persistence
# ---------------------------------------------------------------------------

def save_models(entries: list[ModelEntry], default_path: str | None = None,
                path: Path = MODELS_PATH) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    payload = {
        "default": default_path,
        "discovered": [asdict(e) for e in entries],
    }
    path.write_text(json.dumps(payload, indent=2, ensure_ascii=False), encoding="utf-8")


def load_models(path: Path = MODELS_PATH) -> dict | None:
    if not path.exists():
        return None
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError):
        return None


PROFILES_DIR = CONFIG_DIR / "profiles"


def _model_slug(model_path: str) -> str:
    """Convert a model path to a safe filename slug."""
    name = Path(model_path).name or Path(model_path).parent.name
    slug = re.sub(r"[^\w\-.]", "_", name).strip("_")
    return slug or "unknown"


def model_profile_path(model_path: str) -> Path:
    """Return path for per-model profile: ~/.mico/profiles/<slug>.json"""
    return PROFILES_DIR / f"{_model_slug(model_path)}.json"


def save_profile(profile: Profile, path: Path = PROFILE_PATH) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(
        json.dumps(asdict(profile), indent=2, ensure_ascii=False), encoding="utf-8"
    )


def save_model_profile(profile: Profile) -> Path:
    """Save profile to both the default location and the per-model location."""
    save_profile(profile)
    mp = model_profile_path(profile.model_path or "")
    save_profile(profile, mp)
    return mp


def load_profile(path: Path = PROFILE_PATH) -> Profile | None:
    if not path.exists():
        return None
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
        known = {f.name for f in Profile.__dataclass_fields__.values()}  # type: ignore[attr-defined]
        data = {k: v for k, v in data.items() if k in known}
        return Profile(**data)
    except (OSError, json.JSONDecodeError, TypeError):
        return None


def load_model_profile(model_path: str) -> Profile | None:
    """Load per-model profile if it exists for this model on this machine."""
    return load_profile(model_profile_path(model_path))
