from __future__ import annotations

import re
from typing import Callable


def strip_thinking(text: str) -> str:
    # Standard XML-style thinking tags
    cleaned = re.sub(r"<think>.*?</think>", "", text, flags=re.DOTALL)
    cleaned = re.sub(r"<thinking>.*?</thinking>", "", cleaned, flags=re.DOTALL)
    cleaned = re.sub(r"<\|im_(start|end)\|>", "", cleaned)
    cleaned = re.sub(r"(?m)^\s*```(?:json)?\s*$", "", cleaned)
    # Tag-less thinking preamble: header on its own line, followed by indented/bulleted
    # content, terminated by a blank line.  Only strip when a blank line clearly
    # separates the preamble from the actual answer so we don't eat real content.
    cleaned = re.sub(
        r"(?m)^(?:ThinkingProcess|Thinking Process|My Thinking|Internal Monologue|Chain[- ]of[- ]Thought)"
        r"[:\s][^\n]*(?:\n(?![ \t]*\n).+)*\n[ \t]*\n",
        "\n",
        cleaned,
    )
    return cleaned.strip()


def history_safe_text(text: str, *, strip_thinking: Callable[[str], str], truncator: Callable[[str, int], str], limit: int) -> str:
    _ = strip_thinking
    return truncator(text, limit)


def assistant_safe_text(
    text: str,
    *,
    strip_thinking: Callable[[str], str],
    truncator: Callable[[str, int], str],
    raw_assistant_soft_limit: int,
) -> str:
    return truncator(strip_thinking(text), raw_assistant_soft_limit)
