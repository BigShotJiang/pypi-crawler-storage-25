"""TaskState management and related functions."""

from __future__ import annotations

import json
import re
import time
from dataclasses import dataclass, field
from pathlib import Path
from typing import TYPE_CHECKING, Any, Optional

from mico.redact import redact_json_safe
from mico.session_ops import (
    task_state_path,
    dedupe_keep_order as _dedupe_keep_order,
)

if TYPE_CHECKING:
    from mico.audit import AuditLogger
    from mico.runners import BaseRunner


@dataclass
class ToolContext:
    cwd: Path
    approval: str
    force: bool
    mode: str = "auto"
    narrate: bool = True
    dry_run: bool = False
    profile: str = "balanced"
    network_access: bool = True
    tool_install: bool = False
    unattended: bool = False
    permission_mode: str = "balanced"
    allowed_external_paths: list[Path] = field(default_factory=list)
    force_model_mismatch: bool = False
    audit_logger: AuditLogger | None = None
    runner: Optional[BaseRunner] = None


@dataclass
class TaskState:
    session_id: str
    goal: str
    mode: str
    task_kind: str
    user_goal: str
    current_mode: str
    active_model_profile: str
    cwd: str
    constraints: list[str]
    success_criteria: list[str]
    subtasks: list[dict[str, Any]]
    current_plan: list[str]
    selected_files: list[str]
    files_touched: list[str]
    artifacts: list[dict[str, Any]]
    decisions: list[str]
    findings: list[str]
    open_questions: list[str]
    next_step: str
    last_tool: str
    last_error: str
    test_command: str
    test_result: str
    pending_tasks: list[str]
    verifier_notes: list[str]
    status: str
    updated_at: int
    current_phase: str
    phases: list[dict[str, Any]]
    checkpoints: list[dict[str, Any]]
    pending_tool: dict[str, Any]
    test_attempts: int = 0
    last_test_summary: str = ""
    # Circuit-breaker counters — escape doom-loops where the model repeatedly
    # tries to finalize with the same excuse (e.g. "my output got truncated").
    rejected_final_attempts: int = 0
    last_rejected_final_excerpt: str = ""
    consecutive_tool_errors: int = 0
    auto_promoted: bool = False


@dataclass
class EvalCase:
    name: str
    kind: str
    task: str
    expected: dict[str, Any]
    options: dict[str, Any]


def dedupe_keep_order(items: list[str]) -> list[str]:
    """Remove duplicates while preserving order."""
    return _dedupe_keep_order(items)


def default_success_criteria(task: str, ctx: ToolContext) -> list[str]:
    from mico.task_classify import (
        resolve_mode_for_task,
        task_is_captive_portal_workflow,
    )

    mode = resolve_mode_for_task(task, ctx)
    criteria = [
        "Use tool results or local files as evidence before concluding.",
        "Avoid repeating the same inspection without new information.",
    ]
    if mode == "code":
        criteria.extend(
            [
                "Make the minimal correct code or config change needed for the task.",
                "Verify the change with a targeted command, test, or direct file inspection.",
            ]
        )
    elif mode == "review":
        criteria.extend(
            [
                "List concrete findings before any summary.",
                "Reference evidence from specific files or outputs.",
            ]
        )
    elif mode == "plan":
        criteria.extend(
            [
                "Produce an actionable plan with dependencies and success checks.",
            ]
        )
    elif mode == "audit":
        criteria.extend(
            [
                "Ground each finding in a concrete observable signal.",
                "Include a verification or remediation path for each material issue.",
            ]
        )
        if task_is_captive_portal_workflow(task):
            criteria.extend(
                [
                    "For captive portal work, complete exactly one redirect check, one form extraction, one rejection timing measurement, and one script artifact.",
                    "Do not repeat the same portal GET with curl variants after the login page is captured.",
                    "Do not attempt brute force or unauthorized bypass; report bypass only when supported by observed evidence.",
                ]
            )
    else:
        criteria.append("Return a concrete result, not a placeholder summary.")
    return criteria


def extract_ordered_task_steps(task: str) -> list[str]:
    from mico.task_classify import extract_task_body

    body = extract_task_body(task)
    steps: list[str] = []
    for raw in body.splitlines():
        line = raw.strip()
        if not line:
            continue
        match = re.match(r"^(?:[-*]|\d+[.)])\s+(.+)$", line)
        if match:
            steps.append(match.group(1).strip())
    return [step for step in dedupe_keep_order(steps) if len(step) >= 8]


def task_has_explicit_steps(task: str) -> bool:
    return len(extract_ordered_task_steps(task)) >= 2


def infer_constraints(task: str, ctx: ToolContext) -> list[str]:
    from mico.task_classify import task_is_security_sensitive

    constraints = [
        f"cwd={ctx.cwd}",
        "os=macOS",
        f"tool_install={'on' if ctx.tool_install else 'off'}",
    ]
    if task_is_security_sensitive(task):
        constraints.append("security_mode=on")
    if ctx.dry_run:
        constraints.append("dry_run=on")
    return constraints


def default_phase_plan(task: str, ctx: ToolContext) -> list[dict[str, Any]]:
    from mico.task_classify import (
        resolve_mode_for_task,
        task_is_captive_portal_workflow,
    )

    mode = resolve_mode_for_task(task, ctx)
    explicit_steps = extract_ordered_task_steps(task)
    if mode == "code":
        return [
            {"name": "inspect", "status": "active", "goal": "Find the minimal relevant code or config context."},
            {"name": "change", "status": "pending", "goal": "Apply the smallest correct change."},
            {"name": "verify", "status": "pending", "goal": "Prove the change works with targeted evidence."},
            {"name": "finalize", "status": "pending", "goal": "Return a concise result grounded in evidence."},
        ]
    if mode == "review":
        return [
            {"name": "inspect", "status": "active", "goal": "Read the changed surface and relevant context."},
            {"name": "findings", "status": "pending", "goal": "Identify concrete bugs, regressions, and missing tests."},
            {"name": "finalize", "status": "pending", "goal": "Return findings first, then a brief summary."},
        ]
    if mode == "audit":
        if task_is_captive_portal_workflow(task):
            return [
                {"name": "redirect", "status": "active", "goal": "Confirm the portal redirect target once."},
                {"name": "form", "status": "pending", "goal": "Extract login endpoint and fields from existing portal evidence."},
                {"name": "measure", "status": "pending", "goal": "Perform one random credential attempt and measure rejection timing."},
                {"name": "script", "status": "pending", "goal": "Write a local interval script parameterized by username/password."},
                {"name": "finalize", "status": "pending", "goal": "Summarize evidence, timing, script path, and remaining blockers."},
            ]
        if len(explicit_steps) >= 2:
            phases = [
                {"name": f"step_{idx}", "status": "active" if idx == 1 else "pending", "goal": step}
                for idx, step in enumerate(explicit_steps[:8], start=1)
            ]
            phases.append({"name": "finalize", "status": "pending", "goal": "Summarize each requested step with evidence, output, or blocker."})
            return phases
        return [
            {"name": "scope", "status": "active", "goal": "Choose one narrow, safe first check tied to the user's target."},
            {"name": "probe", "status": "pending", "goal": "Collect one concrete signal or blocker from the target."},
            {"name": "assess", "status": "pending", "goal": "Decide whether evidence supports a finding, blocker, or next step."},
            {"name": "finalize", "status": "pending", "goal": "Return grounded findings or a precise blocker statement."},
        ]
    if len(explicit_steps) >= 2 and mode not in {"review", "code"}:
        phases = [
            {"name": f"step_{idx}", "status": "active" if idx == 1 else "pending", "goal": step}
            for idx, step in enumerate(explicit_steps[:8], start=1)
        ]
        phases.append({"name": "finalize", "status": "pending", "goal": "Return the result for each requested step."})
        return phases
    if mode == "plan":
        return [
            {"name": "inspect", "status": "active", "goal": "Read only the context needed for planning."},
            {"name": "plan", "status": "pending", "goal": "Produce the execution plan with dependencies and checks."},
            {"name": "finalize", "status": "pending", "goal": "Return the plan clearly."},
        ]
    return [
        {"name": "inspect", "status": "active", "goal": "Reduce uncertainty with one high-signal step."},
        {"name": "answer", "status": "pending", "goal": "Return the result grounded in the latest evidence."},
    ]


def current_phase_entry(state: TaskState) -> dict[str, Any]:
    for phase in state.phases:
        if str(phase.get("name", "")) == state.current_phase:
            return phase
    if state.phases:
        state.current_phase = str(state.phases[0].get("name", "inspect"))
        return state.phases[0]
    fallback = {"name": "inspect", "status": "active", "goal": "Inspect the most relevant local context."}
    state.phases = [fallback]
    state.current_phase = "inspect"
    return fallback


def advance_phase(state: TaskState, note: str = "") -> None:
    if not state.phases:
        return
    names = [str(phase.get("name", "")) for phase in state.phases]
    try:
        idx = names.index(state.current_phase)
    except ValueError:
        idx = 0
    state.phases[idx]["status"] = "done"
    phase_id = str(state.phases[idx].get("name", ""))
    for subtask in state.subtasks:
        if str(subtask.get("id", "")) == phase_id:
            subtask["status"] = "done"
    if note:
        state.checkpoints.append(
            {
                "phase": state.current_phase,
                "note": note.strip(),
                "created_at": int(time.time()),
            }
        )
    if idx + 1 < len(state.phases):
        state.current_phase = names[idx + 1]
        state.phases[idx + 1]["status"] = "active"
        for subtask in state.subtasks:
            if str(subtask.get("id", "")) == state.current_phase and str(subtask.get("status", "")) != "done":
                subtask["status"] = "active"
        state.next_step = str(state.phases[idx + 1].get("goal", state.next_step))
    else:
        state.current_phase = names[-1]


def phase_checkpoint_summary(state: TaskState) -> str:
    from mico.cli import truncate

    lines = ["phases:"]
    for phase in state.phases:
        status = str(phase.get("status", "pending"))
        name = str(phase.get("name", "phase"))
        goal = str(phase.get("goal", "")).strip()
        marker = "*" if name == state.current_phase else "-"
        lines.append(f"{marker} {name}: {status} | {goal}")
    if state.checkpoints:
        lines.append("recent_checkpoints:")
        for item in state.checkpoints[-3:]:
            lines.append(f"- {item.get('phase')}: {truncate(str(item.get('note', '')), 120)}")
    return "\n".join(lines)


def explicit_step_phase_active(state: TaskState) -> bool:
    return bool(re.fullmatch(r"step_\d+", state.current_phase or ""))


def create_task_state(session_id: str, task: str, ctx: ToolContext) -> TaskState:
    from mico.task_classify import (
        extract_task_body,
        classify_task,
        resolve_mode_for_task,
    )

    now = int(time.time())
    phases = default_phase_plan(task, ctx)
    explicit_steps = extract_ordered_task_steps(task)
    resolved_mode = resolve_mode_for_task(task, ctx)

    # Get ACTIVE_PROFILE from cli module
    try:
        from mico.cli import ACTIVE_PROFILE
    except ImportError:
        ACTIVE_PROFILE = None

    return TaskState(
        session_id=session_id,
        goal=extract_task_body(task).strip(),
        mode=resolved_mode,
        task_kind=classify_task(task),
        user_goal=extract_task_body(task).strip(),
        current_mode=resolved_mode,
        active_model_profile=ACTIVE_PROFILE.name if ACTIVE_PROFILE else "default",
        cwd=str(ctx.cwd),
        constraints=infer_constraints(task, ctx),
        success_criteria=default_success_criteria(task, ctx),
        subtasks=[
            {"id": f"step_{idx}", "title": step, "status": "active" if idx == 1 else "pending"}
            for idx, step in enumerate(explicit_steps[:8], start=1)
        ],
        current_plan=[str(item.get("goal", "")) for item in phases if str(item.get("goal", "")).strip()],
        selected_files=[],
        files_touched=[],
        artifacts=[],
        decisions=[],
        findings=[],
        open_questions=[],
        next_step="Inspect the most relevant local context before concluding.",
        last_tool="",
        last_error="",
        test_command="",
        test_result="",
        pending_tasks=[],
        verifier_notes=[],
        status="active",
        updated_at=now,
        current_phase=str(phases[0]["name"]) if phases else "inspect",
        phases=phases,
        checkpoints=[],
        pending_tool={},
    )


def task_state_to_dict(state: TaskState) -> dict[str, Any]:
    return {
        "session_id": state.session_id,
        "goal": state.goal,
        "mode": state.mode,
        "task_kind": state.task_kind,
        "user_goal": state.user_goal,
        "current_mode": state.current_mode,
        "active_model_profile": state.active_model_profile,
        "cwd": state.cwd,
        "constraints": dedupe_keep_order(state.constraints),
        "success_criteria": dedupe_keep_order(state.success_criteria),
        "subtasks": state.subtasks[-12:],
        "current_plan": dedupe_keep_order(state.current_plan)[-12:],
        "selected_files": dedupe_keep_order(state.selected_files)[-24:],
        "files_touched": dedupe_keep_order(state.files_touched)[-40:],
        "artifacts": state.artifacts[-40:],
        "decisions": dedupe_keep_order(state.decisions)[-20:],
        "findings": dedupe_keep_order(state.findings)[-20:],
        "open_questions": dedupe_keep_order(state.open_questions)[-20:],
        "next_step": state.next_step.strip(),
        "last_tool": state.last_tool.strip(),
        "last_error": state.last_error.strip(),
        "test_command": state.test_command.strip(),
        "test_result": state.test_result.strip(),
        "pending_tasks": dedupe_keep_order(state.pending_tasks)[-20:],
        "verifier_notes": dedupe_keep_order(state.verifier_notes)[-20:],
        "status": state.status,
        "updated_at": state.updated_at,
        "current_phase": state.current_phase,
        "phases": state.phases[-12:],
        "checkpoints": state.checkpoints[-20:],
        "pending_tool": state.pending_tool,
        "test_attempts": state.test_attempts,
        "last_test_summary": state.last_test_summary,
        "consecutive_tool_errors": state.consecutive_tool_errors,
        "auto_promoted": state.auto_promoted,
    }


def load_task_state(session_id: str, task: str, ctx: ToolContext) -> TaskState:
    from mico.task_classify import (
        extract_task_body,
        classify_task,
        resolve_mode_for_task,
    )

    path = task_state_path(session_id)
    if path.exists():
        data = json.loads(path.read_text())

        # Get ACTIVE_PROFILE from cli module
        try:
            from mico.cli import ACTIVE_PROFILE
        except ImportError:
            ACTIVE_PROFILE = None

        return TaskState(
            session_id=session_id,
            goal=str(data.get("goal", extract_task_body(task).strip())),
            mode=str(data.get("mode", resolve_mode_for_task(task, ctx))),
            task_kind=str(data.get("task_kind", classify_task(task))),
            user_goal=str(data.get("user_goal", extract_task_body(task).strip())),
            current_mode=str(data.get("current_mode", resolve_mode_for_task(task, ctx))),
            active_model_profile=str(data.get("active_model_profile", ACTIVE_PROFILE.name if ACTIVE_PROFILE else "default")),
            cwd=str(data.get("cwd", ctx.cwd)),
            constraints=[str(x) for x in data.get("constraints", [])],
            success_criteria=[str(x) for x in data.get("success_criteria", [])],
            subtasks=list(data.get("subtasks", [])),
            current_plan=[str(x) for x in data.get("current_plan", [])],
            selected_files=[str(x) for x in data.get("selected_files", [])],
            files_touched=[str(x) for x in data.get("files_touched", [])],
            artifacts=list(data.get("artifacts", [])),
            decisions=[str(x) for x in data.get("decisions", [])],
            findings=[str(x) for x in data.get("findings", [])],
            open_questions=[str(x) for x in data.get("open_questions", [])],
            next_step=str(data.get("next_step", "Continue from the latest verified evidence.")),
            last_tool=str(data.get("last_tool", "")),
            last_error=str(data.get("last_error", "")),
            test_command=str(data.get("test_command", "")),
            test_result=str(data.get("test_result", "")),
            pending_tasks=[str(x) for x in data.get("pending_tasks", [])],
            verifier_notes=[str(x) for x in data.get("verifier_notes", [])],
            status=str(data.get("status", "active")),
            updated_at=int(data.get("updated_at", int(time.time()))),
            current_phase=str(data.get("current_phase", "inspect")),
            phases=list(data.get("phases", default_phase_plan(task, ctx))),
            checkpoints=list(data.get("checkpoints", [])),
            pending_tool=dict(data.get("pending_tool", {})),
            test_attempts=int(data.get("test_attempts", 0)),
            last_test_summary=str(data.get("last_test_summary", "")),
            consecutive_tool_errors=int(data.get("consecutive_tool_errors", 0)),
            auto_promoted=bool(data.get("auto_promoted", False)),
        )
    return create_task_state(session_id, task, ctx)


def save_task_state(state: TaskState) -> None:
    state.updated_at = int(time.time())
    task_state_path(state.session_id).write_text(
        json.dumps(redact_json_safe(task_state_to_dict(state)), ensure_ascii=False, indent=2)
    )


def track_tool_side_effects(state: TaskState, action: dict[str, Any]) -> None:
    if action.get("type") != "tool":
        return
    label = str(action.get("tool", ""))
    state.last_tool = label
    if label in {"read_file", "write_file", "replace_in_file", "parse_json_file"}:
        path = str(action.get("path", "")).strip()
        if path:
            state.files_touched.append(path)
            state.selected_files.append(path)
    elif label == "bash":
        command = str(action.get("command", "")).strip()
        for match in re.findall(r"(?:^|[\s'\"`])([A-Za-z0-9_./-]+\.(?:py|ts|tsx|js|jsx|json|md|go|rs|toml|yaml|yml|sh))", command):
            state.files_touched.append(match)
            state.selected_files.append(match)
    state.selected_files = dedupe_keep_order(state.selected_files)


def update_state_after_tool(
    state: TaskState,
    action: dict[str, Any],
    result: str,
    artifact: dict[str, Any] | None,
    *,
    error: bool,
) -> None:
    from mico.state_mutations import (
        update_state_after_tool as _update_state_after_tool,
    )
    from mico.cli import (
        truncate,
        summarize_tool_payload,
        task_goal_tag,
    )

    _update_state_after_tool(
        state,
        action,
        result,
        artifact,
        error=error,
        track_tool_side_effects=track_tool_side_effects,
        summarize_tool_payload=summarize_tool_payload,
        task_goal_tag=task_goal_tag,
        truncator=truncate,
        dedupe_keep_order=dedupe_keep_order,
    )


MAX_STATE_ARTIFACT_SNIPPETS = 5  # Based on cli.py usage


def build_task_state_prompt(state: TaskState) -> str:
    from mico.cli import truncate

    recent_artifacts = state.artifacts[-MAX_STATE_ARTIFACT_SNIPPETS:]
    lines = [
        "[TASK STATE]",
        f"goal: {state.goal}",
        f"mode: {state.mode}",
        f"task_kind: {state.task_kind}",
        f"active_model_profile: {state.active_model_profile}",
        f"status: {state.status}",
    ]
    if state.current_plan:
        lines.append("current_plan:")
        lines.extend(f"- {item}" for item in state.current_plan[-8:])
    if state.selected_files:
        lines.append("selected_files:")
        lines.extend(f"- {item}" for item in state.selected_files[-12:])
    if state.constraints:
        lines.append("constraints:")
        lines.extend(f"- {item}" for item in dedupe_keep_order(state.constraints)[:8])
    if state.success_criteria:
        lines.append("success_criteria:")
        lines.extend(f"- {item}" for item in dedupe_keep_order(state.success_criteria)[:8])
    if state.subtasks:
        lines.append("ordered_subtasks:")
        for item in state.subtasks[:8]:
            lines.append(f"- {item.get('id')}: {item.get('status')} | {item.get('title')}")
        lines.append("subtask_rule: Work on the active subtask only. Once evidence or a blocker exists for it, move to the next subtask instead of collecting similar evidence again.")
    if state.files_touched:
        lines.append("files_touched:")
        lines.extend(f"- {item}" for item in state.files_touched[-12:])
    if state.findings:
        lines.append("findings:")
        lines.extend(f"- {item}" for item in dedupe_keep_order(state.findings)[-8:])
    if state.decisions:
        lines.append("decisions:")
        lines.extend(f"- {item}" for item in dedupe_keep_order(state.decisions)[-6:])
    lines.append(phase_checkpoint_summary(state))
    if state.open_questions:
        lines.append("open_questions:")
        lines.extend(f"- {item}" for item in dedupe_keep_order(state.open_questions)[-6:])
    if recent_artifacts:
        lines.append("recent_artifacts:")
        for item in recent_artifacts:
            lines.append(f"- artifact://{item['id']} {item['label']}")
            lines.append(f"  {truncate(str(item.get('snippet', '')), 180)}")
    if state.last_error:
        lines.append(f"last_error: {truncate(state.last_error, 240)}")
    if state.test_command:
        lines.append(f"test_command: {state.test_command}")
    if state.test_result:
        lines.append(f"test_result: {truncate(state.test_result, 240)}")
    if state.pending_tasks:
        lines.append("pending_tasks:")
        lines.extend(f"- {item}" for item in state.pending_tasks[-8:])
    if state.pending_tool:
        summary = state.pending_tool.get("summary", "")
        lines.append(f"pending_tool: {summary} (henüz tamamlanmadı — önce bunu bitir)")
    lines.append(f"next_step: {state.next_step}")
    return "\n".join(lines)


def retrieval_terms(task: str, history: list[dict[str, str]]) -> set[str]:
    from mico.retrieval import retrieval_terms as _retrieval_terms
    from mico.task_classify import extract_task_body

    return _retrieval_terms(task, history, extract_task_body)


def synthesize_state_final(state: TaskState, ctx: ToolContext) -> str:
    from mico.task_classify import state_dispatch_mode
    from mico.cli import truncate

    findings = dedupe_keep_order(state.findings)
    questions = dedupe_keep_order(state.open_questions)
    phase = current_phase_entry(state)
    lines: list[str] = []
    if state_dispatch_mode(state) == "audit":
        lines.append("Current evidence summary:")
        if findings:
            for item in findings[-3:]:
                lines.append(f"- {truncate(item, 220)}")
        else:
            lines.append("- No durable findings recorded.")
        if questions:
            lines.append("Open blockers:")
            for item in questions[-2:]:
                lines.append(f"- {truncate(item, 220)}")
        lines.append(f"Phase: {phase.get('name', '')}")
        lines.append("Returning now to avoid repeating the same blocked strategy.")
        return "\n".join(lines)
    if findings:
        return "\n".join(findings[-3:])
    return f"Stopped at phase `{phase.get('name', '')}` to avoid repeating a blocked strategy."


def update_phase_after_tool(state: TaskState, action: dict[str, Any], result: str, *, error: bool) -> None:
    from mico.phase_transitions import (
        update_phase_after_tool as _update_phase_after_tool,
    )
    from mico.cli import (
        phase_requires_goal_alignment,
        result_supports_phase_goal,
        task_is_captive_portal_workflow,
    )

    _update_phase_after_tool(
        state,
        action,
        result,
        error=error,
        current_phase_entry=current_phase_entry,
        phase_requires_goal_alignment=phase_requires_goal_alignment,
        result_supports_phase_goal=result_supports_phase_goal,
        explicit_step_phase_active=explicit_step_phase_active,
        advance_phase=advance_phase,
        task_is_captive_portal_workflow=task_is_captive_portal_workflow,
        now_ts=lambda: int(time.time()),
    )


def mark_pending_tool(state: TaskState, action: dict[str, Any]) -> None:
    from mico.phase_transitions import (
        mark_pending_tool as _mark_pending_tool,
    )
    from mico.cli import summarize_action

    _mark_pending_tool(
        state,
        action,
        summarize_action=summarize_action,
        now_ts=lambda: int(time.time()),
    )


def clear_pending_tool(state: TaskState, note: str = "") -> None:
    from mico.phase_transitions import (
        clear_pending_tool as _clear_pending_tool,
    )

    _clear_pending_tool(state, note=note, now_ts=lambda: int(time.time()))
