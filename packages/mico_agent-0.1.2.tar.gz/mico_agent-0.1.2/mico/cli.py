#!/usr/bin/env python3
import argparse
import asyncio
import atexit
import errno
import math
import difflib
import json
import os
import readline
import re
import shutil
import socket
import subprocess
import sys
import time
import uuid
import shlex
import threading
import zipfile
import queue
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any
from urllib.parse import urlparse

import requests

from mico.redact import redact_json_safe, redact_text
from mico.patch import (
    PatchError,
    apply_patch as _apply_patch_pipeline,
    recovery_prompt as _patch_recovery_prompt,
    validate_patch as _validate_patch_pipeline,
)
from mico.testloop import (
    FixLoopState,
    TestResult,
    TestRunner,
    detect_test_runners,
    run_tests as _run_tests_impl,
    should_continue_fix_loop,
)
from mico.profiles_runtime import (
    ModelSlot,
    ProfileConfig,
    ROLE_FALLBACKS,
    RoleConfig,
    list_profiles as list_model_profiles,
    load_profile as load_model_profile,
    resolve_logical_model,
    resolve_role_model,
)
from mico.preflight import (
    run_preflight,
    check_model_sanity,
    format_preflight,
    classify_task_size,
    format_task_size,
)
from mico.limits import (
    PROFILE_LIMITS,
)
from mico.audit import AuditLogger
from mico.output import (
    format_elapsed_compact as _format_elapsed_compact,
    usage_footer_text as _usage_footer_text,
    format_final_summary as _format_final_summary,
    parse_git_status_paths as _parse_git_status_paths,
)
from mico.recovery import (
    build_recovery_prompt as _build_recovery_prompt,
    recovery_kind_for_exception as _recovery_kind_for_exception,
)
from mico.command_policy import (
    is_local_network_host as _is_local_network_host,
    command_targets_only_local_network as _command_targets_only_local_network,
    lint_bash_command as _lint_bash_command,
    dangerous_command as _dangerous_command,
    catastrophic_command_reason as _catastrophic_command_reason,
    classify_command as _classify_command,
    command_uses_external_network as _command_uses_external_network,
    full_root_scan_reason as _full_root_scan_reason,
    disallowed_command_reason as _policy_disallowed_command_reason,
)
from mico.context import (
    startup_note_paths as _startup_note_paths,
    load_startup_notes as _load_startup_notes,
    is_inline_code_heavy_final as _is_inline_code_heavy_final,
    runtime_context_text as _runtime_context_text,
    compact_runtime_context_text as _compact_runtime_context_text,
)
from mico.retrieval import (
    retrieval_terms as _retrieval_terms,
    select_relevant_artifacts as _select_relevant_artifacts,
    build_retrieval_prompt as _build_retrieval_prompt,
)
from mico.metrics import (
    new_turn_state as _new_turn_state,
    add_usage as _add_usage,
)
from mico.model_text import (
    flatten_model_content as _flatten_model_content,
    extract_choice_text as _extract_choice_text,
    extract_choice_reasoning as _extract_choice_reasoning,
)
from mico.ui_status import (
    build_prompt_status_markup as _build_prompt_status_markup,
    build_footer_status_markup as _build_footer_status_markup,
    build_inline_status_markup as _build_inline_status_markup,
)
from mico.state_reports import (
    task_state_report as _task_state_report,
    artifact_report as _artifact_report,
)
from mico.state_mutations import (
    update_state_after_tool as _update_state_after_tool,
)
from mico.phase_transitions import (
    update_phase_after_tool as _update_phase_after_tool,
    mark_pending_tool as _mark_pending_tool,
    clear_pending_tool as _clear_pending_tool,
)
from mico.action_validation import (
    validate_action as _validate_action,
)
from mico.session_store import (
    save_session as _save_session,
    save_patch as _save_patch,
    load_session_history as _load_session_history,
)
from mico.tool_narration import (
    summarize_action as _summarize_action,
    tool_family as _tool_family,
    narrate_tool_intent as _narrate_tool_intent,
    narrate_tool_result as _narrate_tool_result,
    tool_output_preview as _tool_output_preview,
)
from mico.diff_render import (
    render_live_diff as _render_live_diff,
)
from mico.budget import (
    compute_thinking_budget as _compute_thinking_budget,
)
from mico.compact import (
    maybe_compact_history as _maybe_compact_history,
    fallback_history_summary as _fallback_history_summary,
    summarize_history as _summarize_history,
)
from mico.repair import (
    repair_action_response as _repair_action_response,
)
from mico.action_parse import (
    normalize_action_schema as _normalize_action_schema,
    extract_json as _extract_json_action,
)
from mico.history_utils import (
    recent_user_message as _recent_user_message,
    history_total_chars as _history_total_chars,
    count_primary_user_turns as _count_primary_user_turns,
)
from mico.compact_meter import (
    compact_trigger_chars as _compact_trigger_chars,
    update_compact_meter as _update_compact_meter,
)
from mico import git_checkpoint as _git_cp
from mico.shell_utils import (
    shell_join as _shell_join,
    install_command_env as _install_command_env,
)
from mico.git_repo import (
    git_repo_root as _git_repo_root,
)
from mico.paths import (
    safe_path as _safe_path,
)
from mico.skill_io import (
    find_skill_by_name as _find_skill_by_name,
    skill_archive_members as _skill_archive_members,
    read_skill_member as _read_skill_member,
)
from mico.model_client import (
    strip_thinking,
    normalize_action_schema,
    router_unload_hook,
    router_load_hook,
    extract_json,
    coerce_local_info_action,
    validate_orchestra_handoff,
    normalize_compact_summary,
    normalize_messages_for_model,
    speculative_draft_active,
    draft_mode_name,
    count_primary_user_turns,
    clamp_budget,
    stream_model_text,
    call_model,
    summarize_history,
    repair_action_response,
    fallback_history_summary,
)
from mico.server import (
    is_port_open,
    read_server_pid,
    process_exists,
    is_mico_server_process,
    listening_pids,
    expected_mlx_server_running,
    clear_server_pid_file,
    mico_session_env,
    set_active_model_response,
    close_active_model_response,
    stop_managed_server,
    write_mico_heartbeat,
    start_mico_heartbeat,
    clear_mico_heartbeat,
    shutdown_on_exit,
    release_server_now,
    ensure_server,
    read_server_log_tail,
    warmup_model,
    start as _server_start,
)
from mico.skill_loader import (
    load_env_file,
    parse_skill_frontmatter,
    load_skill_from_file,
    skill_search_paths,
    discover_skills,
    skill_keywords,
    skill_aliases,
    task_mentions_skill,
    select_skills_for_task,
    render_skill_notes,
)
from mico.task_classify import (
    extract_task_body,
    classify_task,
    task_prefers_minimal_context,
    task_prefers_brief_answer,
    task_is_code_focused,
    task_is_security_sensitive,
    task_needs_memory_guard,
    task_is_captive_portal_workflow,
    resolve_mode_for_task,
    current_dispatch_mode,
    state_dispatch_mode,
    task_uses_orchestra,
    task_requests_code_inspection,
    task_goal_tag,
    preferred_local_info_action,
    action_goal_tag,
    task_needs_planning,
    planning_hint_message,
)
from mico.prompt_builder import (
    build_system_prompt,
    review_task_prompt,
    audit_task_prompt,
    compact_audit_task_prompt,
    code_task_prompt,
    mode_wrapped_task,
    COMPACT_SYSTEM_PROMPT,
    LIGHTWEIGHT_SYSTEM_PROMPT,
    COMPACT_CODE_ADDENDUM,
    SYSTEM_PROMPT_PATH,
)
from mico.router_hooks import (
    router_admin_headers as _router_admin_headers_impl,
    router_unload_hook as _router_unload_hook_impl,
    router_load_hook as _router_load_hook_impl,
)
from mico.model_discovery import (
    model_name_tokens as _model_name_tokens,
    is_draft_model_name as _is_draft_model_name,
    draft_model_rank as _draft_model_rank,
)
from mico.model_ops import (
    discover_ollama_models,
    infer_model_provider,
    discover_mlx_model_dirs,
    mlx_model_is_complete,
    model_name_tokens,
    normalized_model_family,
    pick_auto_promote_model,
    auto_promote_model_if_needed,
    model_label,
    estimate_tokens_from_text,
    estimate_prompt_tokens,
    normalize_usage_payload,
    brief_model_error,
    record_turn_usage,
    usage_footer_text,
    reset_turn_metrics,
    note_turn_model,
    set_turn_stop_reason,
    record_orchestra_trace,
    is_low_signal_final,
    is_draft_model_name,
    read_model_type,
    is_compatible_draft_model,
    supported_model_types,
    discover_draft_models,
    flatten_model_content,
    extract_choice_text,
    extract_choice_reasoning,
    get_turn_started_at,
    get_turn_models,
    get_turn_trace,
)
from mico.text_utils import (
    strip_thinking as _strip_thinking,
    history_safe_text as _history_safe_text,
    assistant_safe_text as _assistant_safe_text,
)
from mico.auto_fix import (
    run_auto_test_fix_loop as _run_auto_test_fix_loop,
)
from mico.session_ops import (
    save_session,
    load_session_history,
    save_patch,
    session_artifacts_dir,
    task_state_path,
    record_artifact,
    artifact_snippet,
    select_relevant_artifacts,
    build_retrieval_prompt,
    task_state_report,
    artifact_report,
    list_recent_sessions,
    latest_session,
    latest_patch,
    session_preview,
    dedupe_keep_order as _session_dedupe_keep_order,
)
from mico.tool_runner import (
    inspection_signature,
    is_inspection_tool,
    normalize_artifact_snippet,
    should_force_finalize_on_stale_audit,
    audit_task_requires_followthrough,
    bash_read_target,
    redundant_artifact_read_reason,
    artifact_reread_guidance,
    normalize_url_key,
    urls_from_bash_command,
    http_action_method,
    http_action_is_fetch,
    action_urls,
    artifact_url_keys,
    redundant_http_probe_reason,
    redundant_http_probe_guidance,
    extract_result_body,
    phase_goal_keywords,
    result_supports_phase_goal,
    phase_requires_goal_alignment,
    result_answers_goal,
    is_duplicate_goal_attempt,
    maybe_confirm,
    disallowed_command_reason,
    lint_bash_command,
    distill_text_output,
    summarize_tool_payload,
    compact_old_inspection_tool_results,
)
from mico.task_state import (
    TaskState,
    ToolContext,
    EvalCase,
    dedupe_keep_order,
    default_success_criteria,
    extract_ordered_task_steps,
    task_has_explicit_steps,
    infer_constraints,
    default_phase_plan,
    current_phase_entry,
    advance_phase,
    phase_checkpoint_summary,
    explicit_step_phase_active,
    create_task_state,
    task_state_to_dict,
    load_task_state,
    save_task_state,
    track_tool_side_effects,
    update_state_after_tool,
    build_task_state_prompt,
    retrieval_terms,
    synthesize_state_final,
    update_phase_after_tool,
    mark_pending_tool,
    clear_pending_tool,
)
from mico.runners import LocalRunner, DockerRunner, BaseRunner
from rich import box
from rich.align import Align
from rich.columns import Columns
from rich.console import Console
from rich.markdown import Markdown
from rich.panel import Panel
from rich.prompt import Prompt
from rich.rule import Rule
from rich.table import Table
from rich.text import Text

try:
    from prompt_toolkit.application import Application
    from prompt_toolkit.completion import Completer, Completion
    from prompt_toolkit.document import Document
    from prompt_toolkit.formatted_text import HTML
    from prompt_toolkit.key_binding import KeyBindings
    from prompt_toolkit.layout import Dimension, HSplit, Layout, VSplit
    from prompt_toolkit.layout.containers import Float, FloatContainer, Window
    from prompt_toolkit.layout.controls import FormattedTextControl
    from prompt_toolkit.lexers import Lexer
    from prompt_toolkit.history import InMemoryHistory
    from prompt_toolkit.styles import Style
    from prompt_toolkit.layout.menus import CompletionsMenu
    from prompt_toolkit.widgets import Frame, Label, TextArea

    PROMPT_TOOLKIT_AVAILABLE = True
except Exception:
    PROMPT_TOOLKIT_AVAILABLE = False


ROOT = Path(__file__).resolve().parent.parent
CONFIG_PATH = ROOT / "config.env"
GLOBAL_STARTUP_NOTES_PATH = ROOT / "profiles" / "mico-startup.md"
SESSIONS_DIR = ROOT / "sessions"
PATCHES_DIR = ROOT / "patches"
TASK_STATES_DIR = ROOT / "task_states"
ARTIFACTS_DIR = ROOT / "artifacts"
EVALS_DIR = ROOT / "evals"
LOGS_DIR = ROOT / "logs"
SERVER_LOG = LOGS_DIR / "mico-server.log"
SERVER_PID_PATH = LOGS_DIR / "mico-server.pid"
SESSION_SERVER_PID_PATH = LOGS_DIR / "qwen36-server.pid"
SESSION_MANAGER = ROOT / "bin" / "qwen36-session"
SERVER_HOST = "127.0.0.1"
MAX_TOOL_OUTPUT_CHARS = 12000
MAX_READ_CHARS = 32000
DEFAULT_ITERATIONS = 512
EFFORT_MAX_ITERATIONS = DEFAULT_ITERATIONS  # overridden by apply_effort_level()
MAX_CONSECUTIVE_READS = 4
MAX_SAME_TOOL_REPEATS = 2
COMPACT_TRIGGER_MESSAGES = 30
COMPACT_KEEP_TAIL = 24
MODEL_RETRY_DELAYS = [0.5, 1.0, 2.0, 4.0]
HISTORY_ITEM_SOFT_LIMIT = 3500
RAW_ASSISTANT_SOFT_LIMIT = 4000
HISTORY_COMPACT_CHAR_TRIGGER = 20000
DISTILLED_TOOL_OUTPUT_CHARS = 4000
READ_CACHE_LIMIT = 32
DOCTOR_RECENT_SESSIONS = 10
REQUEST_CHAR_SOFT_LIMIT = 12000
REQUEST_CHAR_HARD_LIMIT = 18000
MAX_STATE_ARTIFACT_SNIPPETS = 4
VERIFIER_INTERVAL = 3
MAX_RETRIEVED_ARTIFACTS = 3
AUDIT_HEAVY_TASK_CHARS = 220
ACTIVE_MODEL_RESPONSE_LOCK = threading.Lock()
ACTIVE_MODEL_RESPONSE: requests.Response | None = None

PROFILE_PRESETS = {
    "lite": {"thinking_budget": 128, "adaptive_budget": False, "context_window": 2560},
    "fast": {"thinking_budget": 192, "adaptive_budget": False, "context_window": 8192},
    "balanced": {"thinking_budget": 512, "adaptive_budget": True, "context_window": 8192},
    "deep": {"thinking_budget": 768, "adaptive_budget": True, "context_window": 8192},
}

# FIX 3: Planning hint helpers for build-style tasks
_BUILD_VERBS_TR = (
    "yap", "oluştur", "olustur", "kur", "yaz", "yarat", "geliştir", "gelistir",
    "ekle", "build", "create", "make", "implement", "set up", "scaffold",
    "automate", "otomatize", "scripti", "betik", "tool yaz", "uygulama",
)


SLASH_COMMANDS = [
    "/help",
    "/paste",
    "/exit",
    "/new",
    "/skills",
    "/sessions",
    "/status",
    "/orchestra on",
    "/orchestra off",
    "/orchestra status",
    "/mode auto",
    "/mode code",
    "/mode audit",
    "/mode review",
    "/mode plan",
    "/mode fast",
    "/mode normal",
    "/mode deep",
    "/mode docs",
    "/mode ship-safe",
    "/approval ask",
    "/approval auto",
    "/approval never",
    "/unattended on",
    "/unattended off",
    "/permission strict",
    "/permission balanced",
    "/permission yolo",
    "/network on",
    "/network off",
    "/tool-install on",
    "/tool-install off",
    "/auto-accept on",
    "/auto-accept off",
    "/thinking on",
    "/thinking off",
    "/budget 256",
    "/context-window 3072",
    "/budget 512",
    "/budget 768",
    "/budget 1024",
    "/context-window 4096",
    "/context-window 8192",
    "/context-window 16384",
    "/adaptive-budget on",
    "/adaptive-budget off",
    "/profile lite",
    "/profile fast",
    "/profile balanced",
    "/profile deep",
    "/model-profile fast",
    "/model-profile normal",
    "/model-profile deep",
    "/model-profile review",
    "/model-profile docs",
    "/model-profile default",
    "/dry-run on",
    "/dry-run off",
    "/doctor",
    "/state",
    "/artifacts",
    "/narrate on",
    "/narrate off",
    "/resume",
    "/resume last",
    "/checkpoint",
    "/checkpoints",
    "/rollback",
    "/rollback last",
    "/restore",
    "/diff",
    "/test",
    "/gitstatus",
    "/allow-path",
    "/allowed-paths",
    "/review",
    "/commit",
    "/context",
    "/stop",
    "/plan",
    "/edit",
    "/model",
]

console = Console()
SERVER_STARTED_BY_QCODEX = False
SERVER_STOP_ON_EXIT = False
SERVER_SESSION_ACQUIRED = False
MICO_HEARTBEAT_PATH = LOGS_DIR / "mico-heartbeat.json"
MICO_HEARTBEAT_STOP = threading.Event()
MICO_HEARTBEAT_THREAD: threading.Thread | None = None
CONTEXT_WINDOW_TOKENS = 8192
AUTO_COMPACT_RATIO = 0.75
UI_COMPACT_PERCENT_REMAINING = 100
MONOLOGUE_LINE_START = True

COLOR_MODEL = "cyan"
COLOR_PLAN = "bright_black"
COLOR_TOOL = "yellow"
COLOR_EDIT = "magenta"
COLOR_RESULT = "green"
COLOR_ERROR = "red"
COLOR_NARRATE = "blue"
LAST_STATUS_TEXT = ""
CANCEL_REQUESTED = threading.Event()
UI_STATUS_TEXT = "idle"
UI_STATUS_LOGGING = True
UI_APP: Application | None = None
UI_SPINNER_INDEX = 0
USE_PLAIN_STDOUT = False  # Set True by run_single_turn() to bypass prompt_toolkit UI
STREAM_EXPECT_ACTION_JSON = True  # When False, model output is treated as direct text (no JSON action wrapping)
_ACTIVE_SPINNER: "Any" = None  # Set by entry.py so render_log_line can pause/resume it
UI_SPINNER_FRAMES = ["⠋", "⠙", "⠹", "⠸", "⠼", "⠴", "⠦", "⠧", "⠇", "⠏"]
UI_STATUS_STARTED_AT: float | None = None
LIVE_COMPLETION_TOKENS = 0
LIVE_COMPLETION_STARTED_AT: float | None = None
UI_MOUSE_SUPPORT = os.getenv("MICO_TUI_MOUSE", "").strip().lower() in {"1", "true", "yes", "on"}
UI_FULLSCREEN = os.getenv("MICO_TUI_FULLSCREEN", "1").strip().lower() in {"1", "true", "yes", "on"}
UI_MIN_REDRAW_INTERVAL = 0.12
UI_REFRESH_INTERVAL = 0.12
RUNTIME_STATE: Any = None
MONOLOGUE_BUFFER = ""
MONOLOGUE_OPEN = False
THINKING_FULL_BUFFER = ""   # accumulates all thinking text for the current turn
THINKING_COLLAPSED = False  # per-turn state; default is assigned from config in ensure_monologue_open()
READ_CACHE: dict[str, tuple[float, str]] = {}
DIR_CACHE: dict[str, tuple[float, list[str]]] = {}
MODEL_RETRY_COUNT = 0
# CURRENT_TURN_* are now in model_ops module (imported via get_turn_*_at accessors)
LAST_FINAL_PAYLOAD: dict[str, Any] | None = None
STOP_REQUESTED = False
_JSON_STREAM_FILTER: Any = None  # Will be initialized in run_single_turn
_PHASE_CHANGE_CALLBACK: Any = None  # Called by JsonStreamFilter to notify spinner of phase changes


class ModelStreamCancelled(RuntimeError):
    pass


@dataclass(frozen=True)
class ModelOption:
    key: str
    label: str
    provider: str
    model: str
    params_label: str = ""
    size_label: str = ""


@dataclass(frozen=True)
class SkillSpec:
    name: str
    description: str
    source: Path
    content: str
    aliases: tuple[str, ...] = ()


@dataclass(frozen=True)
class HackingToolSpec:
    key: str
    title: str
    description: str
    category: str
    source: Path
    run_commands: tuple[str, ...]
    install_commands: tuple[str, ...]
    project_url: str


MLX_MODEL_ROOTS = (
    Path.home() / "Desktop",
    Path.home() / "Desktop" / "models",
    Path.home() / "Desktop" / "models" / "mlx",
    Path.home() / ".cache" / "huggingface" / "hub",
    Path.home() / ".lmstudio" / "models",
    Path.home() / "models",
    ROOT / "models",
)
MODEL_NAME_STOPWORDS = {
    "mlx",
    "community",
    "thecluster",
    "culturerevolt",
    "z",
    "lab",
    "claude",
    "highiq",
    "ultra",
    "uncensored",
    "heretic",
    "healed",
    "bf16",
    "fp16",
    "fp8",
    "mxfp8",
    "bit",
    "4bit",
    "8bit",
}
DRAFT_MODEL_MARKERS = ("dflash", "assistant", "draft")




# Note: model_label, reset_turn_metrics, note_turn_model, set_turn_stop_reason,
# record_orchestra_trace, is_low_signal_final, estimate_tokens_from_text,
# estimate_prompt_tokens, normalize_usage_payload, flatten_model_content,
# extract_choice_text, extract_choice_reasoning, brief_model_error,
# record_turn_usage, usage_footer_text are now defined in mico.model_ops
# and imported above.



def format_elapsed_compact(seconds: float | int) -> str:
    return _format_elapsed_compact(seconds)


def format_final_summary(payload: dict[str, Any]) -> str:
    return _format_final_summary(payload)



def auto_enrich_final_payload(payload: dict[str, Any], cwd: Path) -> dict[str, Any]:
    """Best-effort fill-in of changed/added/deleted_files from git status."""
    out = dict(payload)
    has_files = any(out.get(k) for k in ("changed_files", "added_files", "deleted_files"))
    if not has_files:
        try:
            status_text = git_status_short(cwd)
            ch, ad, de = _parse_git_status_paths(status_text)
            if ch:
                out["changed_files"] = ch
            if ad:
                out["added_files"] = ad
            if de:
                out["deleted_files"] = de
        except Exception:
            pass
    return out


def build_final_summary_panel(payload: dict[str, Any]) -> Panel:
    md_text = format_final_summary(payload)
    turn_started = get_turn_started_at()
    elapsed = 0 if turn_started is None else max(0, time.time() - turn_started)
    turn_models = get_turn_models()
    llm_flow = " -> ".join(turn_models) if turn_models else model_label(MODEL)
    footer = f"\n\n_{format_elapsed_compact(elapsed)} | llms: {llm_flow}_"
    body = Markdown(md_text + footer)
    return Panel(
        body,
        title="[bold white]mico[/bold white]",
        border_style=COLOR_RESULT,
        box=box.ROUNDED,
        padding=(1, 2),
    )


def render_final_panel(message: str) -> Panel:
    """Pick the structured panel when LAST_FINAL_PAYLOAD is populated, else the
    plain message panel. Consumes LAST_FINAL_PAYLOAD (single-shot)."""
    global LAST_FINAL_PAYLOAD
    payload = LAST_FINAL_PAYLOAD
    LAST_FINAL_PAYLOAD = None
    if isinstance(payload, dict) and payload:
        try:
            return build_final_summary_panel(payload)
        except Exception:
            pass
    return build_final_response_panel(message)


def build_final_response_panel(message: str) -> Panel:
    clean = (message or "Done.").replace("\r\n", "\n").replace("\r", "")
    body = Text(clean.rstrip(), style="white")
    turn_started = get_turn_started_at()
    elapsed = 0 if turn_started is None else max(0, time.time() - turn_started)
    turn_models = get_turn_models()
    llm_flow = " -> ".join(turn_models) if turn_models else model_label(MODEL)
    footer = f"{format_elapsed_compact(elapsed)} | llms: {llm_flow}"
    usage_footer = usage_footer_text(ACTIVE_PROFILE.name if ACTIVE_PROFILE else "default")
    body.append("\n\n")
    body.append(footer, style="dim italic bold")
    body.append("\n")
    body.append(usage_footer, style="dim")
    return Panel(
        body,
        title="[bold white]mico[/bold white]",
        border_style=COLOR_RESULT,
        box=box.ROUNDED,
        padding=(1, 2),
    )


# Model discovery functions are now in mico.model_ops:
# discover_ollama_models, infer_model_provider, discover_mlx_model_dirs,
# mlx_model_is_complete, model_name_tokens, normalized_model_family,
# pick_auto_promote_model, auto_promote_model_if_needed


def discover_model_options() -> list[ModelOption]:
    options: list[ModelOption] = []
    seen: set[tuple[str, str]] = set()

    def format_bytes(num: int | float | None) -> str:
        if not num:
            return ""
        value = float(num)
        units = ["B", "KB", "MB", "GB", "TB"]
        idx = 0
        while value >= 1024 and idx < len(units) - 1:
            value /= 1024.0
            idx += 1
        return f"{value:.1f}{units[idx]}" if idx else f"{int(value)}B"

    def format_params(num: int | float | None) -> str:
        if not num:
            return ""
        value = float(num)
        if value >= 1_000_000_000:
            return f"{value / 1_000_000_000:.1f}B"
        if value >= 1_000_000:
            return f"{value / 1_000_000:.1f}M"
        if value >= 1_000:
            return f"{value / 1_000:.1f}K"
        return str(int(value))

    def read_model_metadata(model: str, provider: str) -> tuple[str, str]:
        if provider != "mlx":
            return ("", "")
        model_dir = Path(model)
        if not model_dir.exists() or not model_dir.is_dir():
            return ("", "")
        params_label = ""
        size_label = ""
        index_path = model_dir / "model.safetensors.index.json"
        if index_path.exists():
            try:
                data = json.loads(index_path.read_text())
                metadata = data.get("metadata", {}) if isinstance(data, dict) else {}
                params_label = format_params(metadata.get("total_parameters"))
                size_label = format_bytes(metadata.get("total_size"))
            except Exception:
                pass
        if not params_label:
            config_path = model_dir / "config.json"
            if config_path.exists():
                try:
                    data = json.loads(config_path.read_text())
                    text_cfg = data.get("text_config", {}) if isinstance(data, dict) else {}
                    hidden = int(text_cfg.get("hidden_size") or 0)
                    layers = int(text_cfg.get("num_hidden_layers") or 0)
                    vocab = int(text_cfg.get("vocab_size") or 0)
                    estimate = 12 * hidden * hidden * layers + vocab * hidden if hidden and layers else 0
                    params_label = format_params(estimate)
                except Exception:
                    pass
        return (params_label, size_label)

    def add_option(key: str, model: str, provider: str, label: str | None = None) -> None:
        normalized = (provider, model)
        if normalized in seen:
            return
        seen.add(normalized)
        params_label, size_label = read_model_metadata(model, provider)
        options.append(
            ModelOption(
                key=key,
                label=label or model_label(model),
                provider=provider,
                model=model,
                params_label=params_label,
                size_label=size_label,
            )
        )

    add_option("default", MODEL, infer_model_provider(MODEL), f"Current config - {model_label(MODEL)}")

    for mlx_index, entry in enumerate(discover_mlx_model_dirs(), start=1):
        if is_draft_model_name(entry.name):
            continue
        if not mlx_model_is_complete(entry):
            continue
        # HF cache: entry is snapshots/<hash>/, pretty name from grandparent
        grandparent = entry.parent.parent
        if grandparent.name.startswith("models--"):
            display_name = grandparent.name.replace("models--", "").replace("--", "/")
        else:
            display_name = entry.name
        add_option(f"mlx-{mlx_index}", str(entry), "mlx", f"MLX - {display_name}")

    for idx, ollama_model in enumerate(discover_ollama_models(), start=1):
        add_option(f"ollama-{idx}", ollama_model, "ollama", f"Ollama - {ollama_model}")

    # LM Studio — always shown; host configured via LMSTUDIO_HOST or asked at selection time
    add_option("lmstudio", "lmstudio:__connect__", "lmstudio", "LM Studio (OpenAI-compatible API)")

    return options


def apply_model_profile(name: str | None) -> ProfileConfig | None:
    """Load a built-in model profile and resolve logical model fragments.

    Returns the resolved ProfileConfig, or None if `name` is falsy.
    Sets the global ACTIVE_PROFILE.
    """
    global ACTIVE_PROFILE
    if not name:
        ACTIVE_PROFILE = None
        return None
    profile = load_model_profile(name)
    discovered = discover_mlx_model_dirs()
    for role_name, cfg in profile.roles.items():
        fallbacks = ROLE_FALLBACKS.get(profile.name, ())
        resolved = resolve_logical_model(cfg.model, discovered, fallbacks)
        cfg.resolved_path = resolved
    ACTIVE_PROFILE = profile
    # Sync role base_url to the running MLX server's dynamic port.
    try:
        from mico.server import active_port as _active_port
        _port = _active_port()
        if _port:
            _new_base = f"http://{SERVER_HOST}:{_port}/v1"
            for _cfg in profile.roles.values():
                if "127.0.0.1" in _cfg.base_url or "localhost" in _cfg.base_url:
                    _cfg.base_url = _new_base
    except Exception:
        pass
    return profile


def resolve_orchestra_role_configs(primary_role: str = "worker") -> tuple[RoleConfig | None, RoleConfig | None]:
    """Resolve analyzer/final role configs for orchestra from the active profile.

    Priority:
    - final defaults to worker for coding loops, reviewer for review, architect for plan-only
    - analyzer prefers architect, then reviewer, then final
    - if no active profile exists, fall back to env/config orchestra models
    """
    if ACTIVE_PROFILE is not None:
        final_cfg = resolve_role_model(primary_role, ACTIVE_PROFILE)
        if final_cfg is None:
            if primary_role != "worker":
                final_cfg = resolve_role_model("worker", ACTIVE_PROFILE)
            if final_cfg is None:
                final_cfg = resolve_role_model(ACTIVE_PROFILE.default_role, ACTIVE_PROFILE)
        analyzer_cfg = (
            resolve_role_model("architect", ACTIVE_PROFILE)
            or resolve_role_model("reviewer", ACTIVE_PROFILE)
            or final_cfg
        )
        return analyzer_cfg, final_cfg

    analyzer_cfg = RoleConfig(
        model=ORCHESTRA_ANALYZER_MODEL or MODEL,
        base_url=API_BASE,
        context=8192,
        temperature=0.1,
        max_tokens=384,
        resolved_path=ORCHESTRA_ANALYZER_MODEL or MODEL,
    )
    final_cfg = RoleConfig(
        model=ORCHESTRA_FINAL_MODEL or MODEL,
        base_url=API_BASE,
        context=8192,
        temperature=TEMPERATURE,
        max_tokens=MAX_TOKENS,
        resolved_path=ORCHESTRA_FINAL_MODEL or MODEL,
    )
    return analyzer_cfg, final_cfg


def select_startup_model(explicit_model: str | None, explicit_draft_model: str | None = None) -> None:
    global MODEL, MODEL_PROVIDER, DRAFT_MODEL, API_BASE, API_KEY, THINKING, THINKING_BUDGET
    chosen_model = explicit_model.strip() if explicit_model else ""
    chosen_provider = infer_model_provider(chosen_model) if chosen_model else ""

    if not chosen_model:
        # No interactive prompt at startup — use config.env default.
        # Switch models inside the TUI with /model list / /model <N>.
        options = discover_model_options()
        if options:
            selected = options[0]
            chosen_model = selected.model
            chosen_provider = selected.provider

    # If no model resolved yet, fall back to saved profile
    if not chosen_model:
        from mico.model_recommender import load_profile as _load_global_profile
        saved = _load_global_profile()
        if saved and saved.model_path:
            chosen_model = saved.model_path
            chosen_provider = infer_model_provider(chosen_model)
            THINKING = saved.thinking
            THINKING_BUDGET = saved.thinking_budget or THINKING_BUDGET

    MODEL = chosen_model
    MODEL_PROVIDER = chosen_provider or MODEL_PROVIDER
    chosen_draft = explicit_draft_model.strip() if explicit_draft_model else ""
    DRAFT_MODEL = chosen_draft
    os.environ["MODEL_NAME"] = MODEL
    os.environ["MODEL_PROVIDER"] = MODEL_PROVIDER
    os.environ["DRAFT_MODEL_NAME"] = DRAFT_MODEL
    if MODEL_PROVIDER == "lmstudio":
        # LM Studio için API_BASE_URL / PORT gibi MLX config'leri görmezden gel.
        # Sadece LMSTUDIO_HOST kullan — çakışma olmaz.
        _lms_host = os.environ.get("LMSTUDIO_HOST", CONFIG.get("LMSTUDIO_HOST", "http://localhost:1234")).rstrip("/")
        API_BASE = f"{_lms_host}/v1"
        API_KEY = "lm-studio"
    else:
        API_BASE = os.environ.get(
            "API_BASE_URL",
            f"http://127.0.0.1:{PORT}/v1" if MODEL_PROVIDER == "mlx" else "http://127.0.0.1:11434/v1",
        ).rstrip("/")
        API_KEY = os.environ.get("API_KEY_VALUE", "mlx-local" if MODEL_PROVIDER == "mlx" else "ollama")


# pick_auto_promote_model and auto_promote_model_if_needed are now in mico.model_ops


def clear_startup_terminal() -> None:
    if not sys.stdin.isatty() or not sys.stdout.isatty():
        return
    try:
        console.clear()
    except Exception:
        sys.stdout.write("\033[2J\033[H")
        sys.stdout.flush()


CONFIG = load_env_file(CONFIG_PATH)
MODEL_PROVIDER = os.environ.get("MODEL_PROVIDER", CONFIG.get("MODEL_PROVIDER", "mlx"))
MODEL = os.environ.get("MODEL_NAME", CONFIG.get("MODEL", ""))
DRAFT_MODEL = os.environ.get("DRAFT_MODEL_NAME", CONFIG.get("DRAFT_MODEL", ""))
ORCHESTRA_ENABLED = os.environ.get("MICO_ORCHESTRA_ENABLED", CONFIG.get("MICO_ORCHESTRA_ENABLED", "0")) == "1"
ORCHESTRA_ANALYZER_MODEL = os.environ.get(
    "MICO_ORCHESTRA_ANALYZER_MODEL",
    CONFIG.get("MICO_ORCHESTRA_ANALYZER_MODEL", str(Path.home() / "Desktop" / "models" / "qwen-3.5")),
)
ORCHESTRA_FINAL_MODEL = os.environ.get("MICO_ORCHESTRA_FINAL_MODEL", CONFIG.get("MICO_ORCHESTRA_FINAL_MODEL", MODEL))
# temperature=0.0 → greedy decoding, deterministic, best for coding agents
TEMPERATURE = float(CONFIG.get("TEMPERATURE", "0.0"))
# min_p=0.05: filter tokens whose prob < 5% of top token (prevents degenerate outputs)
SAMPLING_MIN_P = float(CONFIG.get("SAMPLING_MIN_P", "0.05"))
# repetition_penalty=1.1: mild penalty to prevent stuck/looping outputs
SAMPLING_REPETITION_PENALTY = float(CONFIG.get("SAMPLING_REPETITION_PENALTY", "1.1"))
SAMPLING_REPETITION_CONTEXT = int(CONFIG.get("SAMPLING_REPETITION_CONTEXT", "64"))
MAX_TOKENS = int(CONFIG.get("MAX_TOKENS", "2048"))
PREFILL_STEP_SIZE = int(CONFIG.get("PREFILL_STEP_SIZE", "512"))
_SERVER_PORT_FILE = Path(os.environ.get("MICO_HOME", str(Path.home() / ".mico"))) / "server.port"
try:
    _port_text = _SERVER_PORT_FILE.read_text().strip()
    PORT = int(_port_text) if _port_text.isdigit() else int(CONFIG.get("PORT", "8080"))
except OSError:
    PORT = int(CONFIG.get("PORT", "8080"))
THINKING = CONFIG.get("THINKING", "1") == "1"
THINKING_BUDGET = int(CONFIG.get("THINKING_BUDGET", "2048"))
ADAPTIVE_BUDGET = CONFIG.get("ADAPTIVE_BUDGET", "1") == "1"
MIN_THINKING_BUDGET = int(CONFIG.get("MIN_THINKING_BUDGET", "256"))
MAX_THINKING_BUDGET = int(CONFIG.get("MAX_THINKING_BUDGET", "4096"))
RUNTIME_DRYRUN = False  # Set by entry.py from runtime state
CONTEXT_WINDOW_TOKENS = int(os.environ.get("MICO_CONTEXT_WINDOW", CONFIG.get("CONTEXT_WINDOW", "8192")))
AUTO_COMPACT_RATIO = float(CONFIG.get("AUTO_COMPACT_RATIO", "0.75"))
COMPACT_TRIGGER_MESSAGES = int(CONFIG.get("COMPACT_TRIGGER_MESSAGES", str(COMPACT_TRIGGER_MESSAGES)))
HISTORY_COMPACT_CHAR_TRIGGER = int(CONFIG.get("HISTORY_COMPACT_CHAR_TRIGGER", str(HISTORY_COMPACT_CHAR_TRIGGER)))
DEFAULT_NETWORK_ACCESS = True
OFFLINE = False
PENTEST_MODE = CONFIG.get("PENTEST_MODE", "1") == "1"
DEFAULT_TOOL_INSTALL = CONFIG.get("MICO_TOOL_INSTALL", "0") == "1"
DEFAULT_PROFILE = CONFIG.get("MICO_DEFAULT_PROFILE", "balanced")
DEFAULT_MODEL_PROFILE = CONFIG.get("MICO_DEFAULT_MODEL_PROFILE", "normal").strip().lower()
DEFAULT_COLLAPSE_THINKING = os.environ.get(
    "MICO_TUI_COLLAPSE_THINKING",
    CONFIG.get("MICO_TUI_COLLAPSE_THINKING", "1"),
).strip().lower() in {"1", "true", "yes", "on"}
ACTIVE_PROFILE: ProfileConfig | None = None
ACTIVE_ROLE: str = "worker"
SERVER_PREFILL_STEP_SIZE = int(CONFIG.get("SERVER_PREFILL_STEP_SIZE", str(PREFILL_STEP_SIZE)))
SERVER_KV_BITS = CONFIG.get("SERVER_KV_BITS", "0")
SERVER_KV_QUANT_SCHEME = CONFIG.get("SERVER_KV_QUANT_SCHEME", "uniform")
SERVER_KV_GROUP_SIZE = CONFIG.get("SERVER_KV_GROUP_SIZE", "64")
SERVER_MAX_KV_SIZE = CONFIG.get("SERVER_MAX_KV_SIZE", "0")
SERVER_QUANTIZED_KV_START = CONFIG.get("SERVER_QUANTIZED_KV_START", "0")
SERVER_PROMPT_CACHE_SIZE = CONFIG.get("SERVER_PROMPT_CACHE_SIZE", "2")
SERVER_PROMPT_CACHE_BYTES = CONFIG.get("SERVER_PROMPT_CACHE_BYTES", "1GB")
PYTHON = str(ROOT / ".venv" / "bin" / "python")
SESSION_MANAGED_EXTERNALLY = os.environ.get("QWEN36_SESSION_MANAGED", "") == "1"
if MODEL_PROVIDER == "lmstudio":
    _lms_host = os.environ.get("LMSTUDIO_HOST", CONFIG.get("LMSTUDIO_HOST", "http://localhost:1234")).rstrip("/")
    API_BASE = f"{_lms_host}/v1"
    API_KEY = "lm-studio"
else:
    API_BASE = os.environ.get(
        "API_BASE_URL",
        f"http://127.0.0.1:{PORT}/v1" if MODEL_PROVIDER == "mlx" else "http://127.0.0.1:11434/v1",
    ).rstrip("/")
    API_KEY = os.environ.get("API_KEY_VALUE", "mlx-local" if MODEL_PROVIDER == "mlx" else "ollama")
_api_base_parsed = urlparse(API_BASE)
_mlx_router_admin_default = (
    f"{_api_base_parsed.scheme}://{_api_base_parsed.netloc}"
    if _api_base_parsed.scheme in {"http", "https"} and _api_base_parsed.netloc
    else "http://127.0.0.1:8090"
)
MLX_ROUTER_ADMIN_BASE = os.environ.get("MICO_MLX_ROUTER_ADMIN_URL", _mlx_router_admin_default).rstrip("/")


ModelSlot.set_unload_hook(router_unload_hook)
ModelSlot.set_load_hook(router_load_hook)


def is_local_network_host(host: str) -> bool:
    return _is_local_network_host(host)


def command_targets_only_local_network(command: str) -> bool:
    return _command_targets_only_local_network(command)


def semantic_code_observation(summary: str) -> str:
    lines = [line.strip() for line in summary.splitlines() if line.strip()]
    hints: list[str] = []
    joined = "\n".join(lines)
    if "def " in joined:
        hints.append("function boundaries")
    if "return " in joined:
        hints.append("return paths")
    if "if " in joined or "elif " in joined:
        hints.append("branching logic")
    if "history" in joined:
        hints.append("history/session handling")
    if "render_" in joined or "log_line" in joined:
        hints.append("logging or UI updates")
    if not hints:
        hints.append("code excerpt")
    return "Observed " + ", ".join(hints[:3]) + "."


def tool_result_history_text(label: str, result: str, task: str) -> str:
    goal = task_goal_tag(task)
    # For read_file: pass full content (up to MAX_READ_CHARS) so model sees whole file.
    if label == "read_file":
        summary = truncate(result.strip(), MAX_READ_CHARS)
    else:
        summary = summarize_tool_payload(label, result, goal)
    message = f"Tool result for {label}:\n{summary}"
    lowered_task = task.lower()
    if result_answers_goal(goal, label, result):
        message += "\nThis directly answers the task. Return final now unless the user explicitly requested more detail."
        return message
    if label == "bash" and task_requests_code_inspection(task) and len(summary.splitlines()) >= 3:
        message += (
            "\n"
            + semantic_code_observation(summary)
            + " Synthesize from this excerpt instead of reading many tiny sequential sed slices."
        )
        return message
    if label in {"read_file", "list_files", "coding_tool", "grep_code", "parse_json_file", "http_request",
                 "find_in_files", "json_query", "env_info"}:
        if any(token in lowered_task for token in ["incele", "anlat", "özet", "ozet", "review", "risk", "neden", "what", "why", "show"]):
            message += "\nIf this already answers the task, return final next."
    return message


def doctor_report(history: list[dict[str, str]] | None, session_id: str, ctx: "ToolContext") -> str:
    sessions = list_recent_sessions()[:DOCTOR_RECENT_SESSIONS]
    current_history = history or []
    state_path = task_state_path(session_id)
    state_artifacts = 0
    state_status = "missing"
    if state_path.exists():
        try:
            state_data = json.loads(state_path.read_text())
            state_artifacts = len(state_data.get("artifacts", []))
            state_status = str(state_data.get("status", "active"))
        except Exception:
            state_status = "invalid"
    invalid_actions = sum(
        1 for item in current_history if item.get("role") == "user" and "Invalid model action" in str(item.get("content", ""))
    )
    tool_results = sum(
        1 for item in current_history if item.get("role") == "user" and str(item.get("content", "")).startswith("Tool result for ")
    )
    tool_errors = sum(
        1 for item in current_history if item.get("role") == "user" and str(item.get("content", "")).startswith("Tool error for ")
    )
    compact_markers = sum(
        1 for item in current_history if item.get("role") == "system" and str(item.get("content", "")).startswith("[COMPACTED SUMMARY]")
    )
    avg_len = 0
    tool_messages = [
        str(item.get("content", "")) for item in current_history if str(item.get("content", "")).startswith(("Tool result for ", "Tool error for "))
    ]
    if tool_messages:
        avg_len = int(sum(len(item) for item in tool_messages) / len(tool_messages))
    lines = [
        "Session Doctor",
        f"session: {session_id[:8]}",
        f"profile: {ctx.profile}",
        f"dry_run: {'on' if ctx.dry_run else 'off'}",
        f"thinking_budget: {THINKING_BUDGET}",
        f"context_window: {CONTEXT_WINDOW_TOKENS}",
        f"adaptive_budget: {'on' if ADAPTIVE_BUDGET else 'off'}",
        f"history_items: {len(current_history)}",
        f"tool_results: {tool_results}",
        f"tool_errors: {tool_errors}",
        f"invalid_actions: {invalid_actions}",
        f"compact_markers: {compact_markers}",
        f"avg_tool_message_chars: {avg_len}",
        f"model_retries_this_process: {MODEL_RETRY_COUNT}",
        f"read_cache_entries: {len(READ_CACHE)}",
        f"recent_sessions: {len(sessions)}",
        f"task_state: {state_status}",
        f"artifacts_recorded: {state_artifacts}",
    ]

    # Add model sanity check info
    if ACTIVE_PROFILE:
        try:
            primary_role = ACTIVE_PROFILE.default_role or "worker"
            role_cfg = resolve_role_model(primary_role, ACTIVE_PROFILE)
            if role_cfg:
                sanity = check_model_sanity(ACTIVE_PROFILE.name, primary_role, role_cfg.base_url, role_cfg.model)
                lines.append(f"model_sanity: {'ok' if sanity.ok else 'MISMATCH'}")
                lines.append(f"expected_model: {sanity.expected_model_hint}")
                lines.append(f"connected_model: {sanity.connected_model}")
        except Exception:
            pass

    # Add audit info if available
    audit_logger = getattr(ctx, "audit_logger", None)
    if audit_logger and audit_logger.current():
        entry = audit_logger.current()
        lines.append(f"audit_run_id: {entry.run_id[:16]}")
        lines.append(f"audit_files_changed: {len(entry.changed_files)}")

    return "\n".join(lines)


def truncate(text: str, limit: int) -> str:
    if len(text) <= limit:
        return text
    return text[:limit] + f"\n...[truncated {len(text) - limit} chars]"


def style_badge(label: str, value: str, color: str) -> Text:
    text = Text()
    text.append(f"{label} ", style="bold white")
    text.append(value, style=f"bold {color}")
    return text


def render_log_line(label: str, body: str = "", color: str = "cyan") -> None:
    # Bypass prompt_toolkit UI if using plain stdout — route to mico.ui for color.
    if USE_PLAIN_STDOUT:
        _sp = _ACTIVE_SPINNER
        try:
            if _sp is not None:
                _sp.pause()
            from mico import ui as _mico_ui
            _mico_ui.render_log(label, body)
        except Exception:
            if body:
                sys.stdout.write(f"[{label}] {body}\n")
            else:
                sys.stdout.write(f"[{label}]\n")
            sys.stdout.flush()
        finally:
            if _sp is not None:
                _sp.resume()
        return

    bullet = Text("⏺ ", style=f"bold {color}")
    if label.startswith("step "):
        bullet.append(label, style="bold white")
        console.print(bullet)
        return
    if label in {"list_files", "read_file", "find_in_files", "grep_code", "parse_json_file",
                  "json_query", "env_info"}:
        bullet.append("Explored", style="bold white")
    elif label in {"bash", "coding_tool", "macos_admin_task", "python_run", "run_tests"}:
        bullet.append("Ran", style="bold white")
    elif label in {"git_tool"}:
        bullet.append("Git", style="bold white")
    elif label in {"write_file", "replace_in_file", "create_dir", "move_file", "delete_file"}:
        bullet.append("Edited", style="bold white")
    elif label == "edit":
        bullet.append("Edited", style="bold white")
    elif label == "model":
        title = "Thinking"
        if body == "parsing action":
            title = "Parsing action"
        elif body == "streaming response":
            title = "Streaming response"
        elif body.startswith("backend error"):
            title = "Model backend error"
        bullet.append(title, style="bold white")
        if body and title.lower() != body.lower():
            detail = Text("\n  └ ", style="dim")
            detail.append(body, style="white")
            bullet.append_text(detail)
        console.print(bullet)
        return
    elif label == "tool":
        bullet.append("Running tool", style="bold white")
    elif label == "monologue":
        bullet.append("Monologue", style="bold white")
        if body:
            detail = Text("\n  └ ", style="dim")
            detail.append(body, style="white")
            bullet.append_text(detail)
        console.print(bullet)
        return
    elif label == "orchestra":
        bullet.append("Orchestra", style="bold italic white")
        if body:
            detail = Text("\n  ↳ ", style="dim italic")
            detail.append(body, style="bold italic bright_black")
            bullet.append_text(detail)
        console.print(bullet)
        return
    elif label == "agent":
        bullet.append("Agent", style="bold white")
    elif label == "triage":
        bullet.append("Evaluating", style="bold yellow")
        if body:
            detail = Text("\n  └ ", style="dim")
            detail.append(body, style="yellow")
            bullet.append_text(detail)
        console.print(bullet)
        return
    elif label == "narrate":
        bullet.append(body or "Working", style="white")
        console.print(bullet)
        return
    else:
        title = body if label in {"ui", "status", "plan", "model", "agent", "memory", "paste"} and body else label
        bullet.append(title, style="white")
        console.print(bullet)
        return

    if body:
        detail = Text("\n  └ ", style="dim")
        detail.append(body, style="white")
        bullet.append_text(detail)
    console.print(bullet)


def render_output_block(title: str, body: str, color: str = "bright_black") -> None:
    text = (body or "").rstrip()
    if not text:
        return
    header = Text("• ", style=f"bold {color}")
    header.append(title, style="bold white")
    console.print(header)
    for line in text.splitlines():
        console.print(Text("  " + line, style="white"))


def summarize_edit(path: Path, before: str, after: str) -> str:
    added = 0
    removed = 0
    for line in difflib.unified_diff(before.splitlines(), after.splitlines(), lineterm=""):
        if line.startswith("+++") or line.startswith("---") or line.startswith("@@"):
            continue
        if line.startswith("+"):
            added += 1
        elif line.startswith("-"):
            removed += 1
    return f"{path.name} (+{added} -{removed})"


def summarize_tool_action(action: dict[str, Any]) -> tuple[str, str]:
    tool = str(action.get("tool", "tool"))
    if tool == "bash":
        command = str(action.get("command", "")).strip()
        return ("Ran", command or "shell command")
    if tool == "coding_tool":
        name = str(action.get("name", "")).strip()
        if name == "search_code":
            pattern = str(action.get("pattern", "")).strip()
            path = str(action.get("path", ".")).strip()
            return ("Explored", f"{pattern} in {path}")
        if name == "list_code_files":
            path = str(action.get("path", ".")).strip()
            pattern = str(action.get("pattern", "")).strip()
            suffix = f" ({pattern})" if pattern else ""
            return ("Explored", f"{path}{suffix}")
        return ("Ran", name or "coding tool")
    if tool == "skill_tool":
        skill = str(action.get("skill", "")).strip()
        op = str(action.get("action", "")).strip()
        name = str(action.get("name", "")).strip()
        detail = " ".join(part for part in [skill, op, name] if part).strip()
        return ("Ran", detail or "skill tool")
    if tool == "http_request":
        method = str(action.get("method", "GET")).strip().upper()
        url = str(action.get("url", "")).strip()
        return ("Ran", f"{method} {url}".strip())
    if tool == "grep_code":
        pattern = str(action.get("pattern", "")).strip()
        path = str(action.get("path", ".")).strip()
        return ("Explored", f"{pattern} in {path}".strip())
    if tool == "parse_json_file":
        return ("Explored", str(action.get("path", "")))
    if tool == "read_file":
        return ("Explored", str(action.get("path", "")))
    if tool == "list_files":
        return ("Explored", str(action.get("path", ".")))
    if tool == "write_file":
        return ("Edited", str(action.get("path", "")))
    if tool == "replace_in_file":
        return ("Edited", str(action.get("path", "")))
    if tool == "find_in_files":
        return ("Explored", f"{action.get('pattern', '')} @ {action.get('path', '.')}")
    if tool == "git_tool":
        return ("Ran", f"git {action.get('op', '')}")
    if tool == "create_dir":
        return ("Edited", str(action.get("path", "")))
    if tool == "move_file":
        return ("Edited", f"{action.get('src', '')} → {action.get('dst', '')}")
    if tool == "delete_file":
        return ("Edited", str(action.get("path", "")))
    if tool == "python_run":
        code = str(action.get("code", ""))
        return ("Ran", code[:60] + ("..." if len(code) > 60 else ""))
    if tool == "env_info":
        return ("Explored", "env bilgisi")
    if tool == "json_query":
        return ("Explored", f"{action.get('path', '')} → {action.get('query', '.')}")
    return ("Ran", tool)


def update_status(text: str) -> None:
    global LAST_STATUS_TEXT, UI_STATUS_TEXT, UI_STATUS_STARTED_AT
    text = text.strip()
    if not text or text == LAST_STATUS_TEXT:
        return
    if text == "idle":
        UI_STATUS_STARTED_AT = None
    elif LAST_STATUS_TEXT == "idle" or UI_STATUS_STARTED_AT is None:
        UI_STATUS_STARTED_AT = time.time()
    LAST_STATUS_TEXT = text
    UI_STATUS_TEXT = text
    runtime_status_from_label(text)
    if UI_STATUS_LOGGING:
        render_log_line("status", text, COLOR_PLAN)
    if UI_APP is not None:
        try:
            UI_APP.invalidate()
        except Exception:
            pass


def reset_live_completion_metrics() -> None:
    global LIVE_COMPLETION_TOKENS, LIVE_COMPLETION_STARTED_AT
    LIVE_COMPLETION_TOKENS = 0
    LIVE_COMPLETION_STARTED_AT = None


def note_live_output_text(text: str) -> None:
    global LIVE_COMPLETION_TOKENS, LIVE_COMPLETION_STARTED_AT
    if not text:
        return
    if LIVE_COMPLETION_STARTED_AT is None:
        LIVE_COMPLETION_STARTED_AT = time.monotonic()
    LIVE_COMPLETION_TOKENS += max(0, estimate_tokens_from_text(text))
    # Update live tok/s in runtime state so spinner shows it in real time
    state = RUNTIME_STATE
    if state is not None and LIVE_COMPLETION_STARTED_AT is not None and LIVE_COMPLETION_TOKENS > 0:
        elapsed = time.monotonic() - LIVE_COMPLETION_STARTED_AT
        if elapsed > 0.2:
            state.live_tokens_per_sec = LIVE_COMPLETION_TOKENS / elapsed


def runtime_status_reset() -> None:
    state = RUNTIME_STATE
    if state is None:
        return
    state.live_stage = ""
    state.live_detail = ""
    state.turn_started_at = 0.0
    state.request_sent_at = 0.0
    state.first_token_at = 0.0
    state.last_progress_at = 0.0


def runtime_status_set(stage: str, detail: str = "") -> None:
    state = RUNTIME_STATE
    if state is None:
        return
    state.live_stage = str(stage or "").strip()
    state.live_detail = str(detail or "").strip()
    state.last_progress_at = time.monotonic()


def runtime_status_turn_started() -> None:
    state = RUNTIME_STATE
    if state is None:
        return
    now = time.monotonic()
    state.turn_started_at = now
    state.request_sent_at = 0.0
    state.first_token_at = 0.0
    state.last_progress_at = now
    runtime_status_set("server ready")


def runtime_status_request_sent(detail: str = "chat") -> None:
    state = RUNTIME_STATE
    now = time.monotonic()
    if state is not None:
        if not state.turn_started_at:
            state.turn_started_at = now
        state.request_sent_at = now
    runtime_status_set("request sent", detail)
    if UI_STATUS_LOGGING:
        render_log_line("status", f"request sent: {detail}", COLOR_PLAN)


def runtime_status_first_token() -> None:
    state = RUNTIME_STATE
    now = time.monotonic()
    if state is not None and not state.first_token_at:
        state.first_token_at = now
    runtime_status_set("first token")
    if UI_STATUS_LOGGING:
        render_log_line("status", "first token", COLOR_PLAN)


def runtime_status_from_label(text: str) -> None:
    lowered = text.strip().lower()
    if not lowered:
        return
    if lowered == "idle":
        runtime_status_set("idle")
        return
    if lowered == "parsing action":
        runtime_status_set("tool selected")
        return
    if lowered.startswith("running "):
        runtime_status_set("tool running", text.strip()[8:])
        return
    if lowered.startswith("orchestrating "):
        runtime_status_set("request sent", text.strip())
        return
    if lowered in {"thinking", "calisiyor", "working", "değerlendiriliyor..."}:
        runtime_status_set(text.strip())


class OutputSink:
    def __init__(self, app: Application | None = None, max_chars: int | None = None) -> None:
        self.app = app
        self.max_chars = max_chars
        self._lock = threading.Lock()
        self._text = ""

    def write(self, data: str) -> int:
        if not data:
            return 0
        with self._lock:
            self._text += data
            if self.max_chars is not None and len(self._text) > self.max_chars:
                self._text = self._text[-self.max_chars :]
        if self.app is not None:
            try:
                self.app.invalidate()
            except Exception:
                pass
        return len(data)

    def flush(self) -> None:
        return

    def text(self) -> str:
        with self._lock:
            return self._text


class TranscriptLexer(Lexer):
    def lex_document(self, document):
        def get_line(lineno: int):
            line = document.lines[lineno]
            # Claude Code tarzı kullanıcı prompt ayırıcı
            if line.startswith("╭─ ") or line.startswith("╰─"):
                return [("class:transcript.separator", line)]
            if line.startswith("│ "):
                return [("class:transcript.user", line)]
            if line.startswith("> "):
                return [("class:transcript.user-prefix", "> "), ("class:transcript.user", line[2:])]
            if line.startswith("• step "):
                return [("class:transcript.step", line)]
            if line.startswith("⏺ Thinking") or line.startswith("• Thinking"):
                return [("class:transcript.thinking", line)]
            if line.startswith("⏺ Monologue") or line.startswith("• Monologue"):
                return [("class:transcript.thinking", line)]
            if line.startswith("⏺ Streaming response") or line.startswith("• Streaming response"):
                return [("class:transcript.streaming", line)]
            if line.startswith("⏺ Parsing action") or line.startswith("• Parsing action"):
                return [("class:transcript.parsing", line)]
            if line.startswith("⏺ Explored") or line.startswith("• Explored"):
                return [("class:transcript.explored", line)]
            if line.startswith("⏺ Ran") or line.startswith("• Ran"):
                return [("class:transcript.ran", line)]
            if line.startswith("⏺ Edited") or line.startswith("• Edited"):
                return [("class:transcript.edited", line)]
            if line.startswith("⏺ Agent") or line.startswith("• Agent"):
                return [("class:transcript.agent", line)]
            if line.startswith("⏺ Orchestra") or line.startswith("• Orchestra"):
                return [("class:transcript.orchestra", line)]
            if line.startswith("⏺ ") or line.startswith("• "):
                return [("class:transcript.bullet", line)]
            if line.startswith("  @@"):
                return [("class:transcript.hunk", line)]
            if line.startswith("    "):
                return [("class:transcript.monologue", line)]
            if line.startswith("  ↳"):
                return [("class:transcript.orchestra-detail", line)]
            if line.startswith("  +"):
                return [("class:transcript.add", line)]
            if line.startswith("  -"):
                return [("class:transcript.del", line)]
            if line.startswith("  └"):
                return [("class:transcript.detail", line)]
            return [("class:transcript.text", line)]

        return get_line


class SlashCommandCompleter(Completer):
    def __init__(self, commands: list[str]) -> None:
        self.commands = sorted(commands)

    def get_completions(self, document, complete_event):
        before = document.current_line_before_cursor.lstrip()
        if not before.startswith("/"):
            return
        needle = before.lower()
        for command in self.commands:
            if command.lower().startswith(needle):
                yield Completion(command, start_position=-len(before), display=command)


_STREAMING_ACTIVE: bool = False  # True while a model response is streaming


def stream_stdout(text: str, *, style: str | None = None) -> None:
    global _STREAMING_ACTIVE
    if not text:
        return
    if USE_PLAIN_STDOUT or UI_APP is None:
        _sp = _ACTIVE_SPINNER
        # First chunk: pause spinner once to clear the spinner line.
        # Subsequent chunks: spinner already paused, write directly.
        if _sp is not None and not _STREAMING_ACTIVE:
            _sp.pause()  # clears \r\033[K, acquires write lock
            runtime_status_first_token()
        _STREAMING_ACTIVE = True
        try:
            from . import ui as mico_ui
            filtered_text = text
            if _JSON_STREAM_FILTER is not None and STREAM_EXPECT_ACTION_JSON:
                filtered_text = _JSON_STREAM_FILTER.feed(text)
            if filtered_text:
                note_live_output_text(filtered_text)
                mico_ui.stream_text(filtered_text)
        except (ImportError, Exception):
            sys.stdout.write(text)
            sys.stdout.flush()
        # Do NOT resume here — spinner stays paused for the entire stream.
        # resume() is called once in run_single_turn after stream completes.
    else:
        target = getattr(console, "file", sys.stdout)
        try:
            target.write(text)
            target.flush()
        except Exception:
            sys.stdout.write(text)
            sys.stdout.flush()


def stream_wordwise(text: str, *, style: str | None = None) -> None:
    if not text:
        return
    for token in re.findall(r"\s+|\S+", text):
        stream_stdout(token, style=style)


def monologue_line_allowed(text: str) -> bool:
    normalized = text.strip().lower()
    if not normalized:
        return False
    if normalized in {"<think>", "</think>"}:
        return False
    if normalized.startswith('{"type"') or normalized.startswith("{\"type\""):
        return False
    blocked_fragments = [
        "let me generate final",
        "let's generate final",
        "lets generate final",
        "i will return a final",
        "i'll return a final",
        "i will formulate the final response",
        "i should now provide",
        "now i can provide a final",
        "i will summarize this",
        "i will report this blocker",
        "i'll ask for the password",
        "i should report this blocker",
    ]
    if any(fragment in normalized for fragment in blocked_fragments):
        return False
    return True


def flush_monologue_buffer(force: bool = False) -> None:
    global MONOLOGUE_BUFFER, MONOLOGUE_LINE_START, MONOLOGUE_OPEN
    # In TUI collapsed mode nothing is written to output — text is in THINKING_FULL_BUFFER
    if not USE_PLAIN_STDOUT and THINKING_COLLAPSED:
        if force:
            MONOLOGUE_BUFFER = ""
            MONOLOGUE_OPEN = False
        return
    sentence_pattern = re.compile(r"(.+?[.!?](?:['\")\]]+)?)(\s+|$)", re.DOTALL)
    while True:
        match = sentence_pattern.match(MONOLOGUE_BUFFER)
        if match is None:
            break
        sentence = match.group(1).strip()
        MONOLOGUE_BUFFER = MONOLOGUE_BUFFER[match.end() :]
        if monologue_line_allowed(sentence):
            stream_stdout("    " + sentence + "\n")
            MONOLOGUE_LINE_START = True
    if force and MONOLOGUE_BUFFER:
        remaining = MONOLOGUE_BUFFER.strip()
        if monologue_line_allowed(remaining):
            stream_stdout("    " + remaining + "\n")
            MONOLOGUE_LINE_START = True
        MONOLOGUE_BUFFER = ""
    if force:
        MONOLOGUE_OPEN = False


def ensure_monologue_open() -> None:
    global MONOLOGUE_OPEN, MONOLOGUE_BUFFER, THINKING_COLLAPSED, THINKING_FULL_BUFFER
    if MONOLOGUE_OPEN:
        return
    MONOLOGUE_BUFFER = ""
    MONOLOGUE_OPEN = True
    THINKING_FULL_BUFFER = ""
    THINKING_COLLAPSED = DEFAULT_COLLAPSE_THINKING and not USE_PLAIN_STDOUT
    try:
        from . import ui as mico_ui
        mico_ui.reset_thinking_line_state()
    except Exception:
        pass
    if THINKING_COLLAPSED:
        stream_stdout("\033[2;3m▸ thinking… (ctrl+O to expand)\033[0m\n")


def looks_like_action_json_fragment(text: str) -> bool:
    normalized = text.lstrip()
    if not normalized:
        return False
    compact = re.sub(r"\s+", "", normalized[:600]).lower()
    if not compact.startswith("{"):
        return False
    if compact.startswith('{"type":"tool"') or compact.startswith('{"type":"final"'):
        return True
    return '"tool":' in compact and ('"type":' in compact or '"path":' in compact or '"pattern":' in compact)


def clean_reasoning_for_display(text: str) -> str:
    if not text:
        return ""
    compact_source = re.sub(r"\s+", "", text[:800]).lower()
    if compact_source.startswith("{") and (
        compact_source.startswith('{"type":"tool"')
        or compact_source.startswith('{"type":"final"')
        or ('"tool":' in compact_source and ('"path":' in compact_source or '"pattern":' in compact_source))
    ):
        return ""
    cleaned = text.replace("<think>", "").replace("</think>", "")
    cleaned = cleaned.replace("<|im_start|>", " ").replace("<|im_end|>", " ")
    cleaned = re.sub(r"artifact://\S+", " ", cleaned, flags=re.IGNORECASE)
    cleaned = re.sub(r"/Users/[^\s]+", " ", cleaned)
    cleaned = re.sub(r"(?i)\b(?:assistant|user|system)\s*\{", " ", cleaned)
    cleaned = re.sub(r'(?i)"type"\s*:\s*"tool"', " ", cleaned)
    cleaned = re.sub(r'(?i)"tool"\s*:\s*"[a-z_]+"', " ", cleaned)
    cleaned = re.sub(r'(?i)"command"\s*:\s*"[^"]*"', " ", cleaned)
    cleaned = re.sub(r"(?i)tool result for [a-z_]+:?", " ", cleaned)
    cleaned = re.sub(r"(?i)tool error for [a-z_]+:?", " ", cleaned)
    cleaned = re.sub(r"(?i)artifact\s*:\s*", " ", cleaned)
    cleaned = re.sub(r"(?i)observed code excerpt.*", " ", cleaned)
    cleaned = re.sub(r"(?i)synthesize from this excerpt.*", " ", cleaned)
    cleaned = re.sub(r"(?i)timeout\s*:\s*\d+", " ", cleaned)
    cleaned = re.sub(r"\{\s*,?", " ", cleaned)
    cleaned = re.sub(r"\}\s*", " ", cleaned)
    cleaned = re.sub(r"[ \t]+", " ", cleaned)
    # Smooth out tokenization artifacts common in reasoning streams:
    # stray spaces before punctuation, around brackets, and in contractions.
    cleaned = re.sub(r"\s+([,.;:!?%)\]\}])", r"\1", cleaned)
    cleaned = re.sub(r"([(\[\{])\s+", r"\1", cleaned)
    cleaned = re.sub(r"(?<=\S)\s*/\s*(?=\S)", "/", cleaned)
    cleaned = re.sub(r"(?<=\w)\s*([._-])\s*(?=\w)", r"\1", cleaned)
    cleaned = re.sub(r"(\w)\s+'\s+(\w)", r"\1'\2", cleaned)
    cleaned = re.sub(r"(\w)\s+'\b", r"\1'", cleaned)
    cleaned = re.sub(r"\b(n)\s+'\s*t\b", r"\1't", cleaned, flags=re.IGNORECASE)
    cleaned = re.sub(r"\b([A-Za-z])\s+'\s*([smvdreSMVDRE]|ll|LL)\b", r"\1'\2", cleaned)
    cleaned = re.sub(r"\n{3,}", "\n\n", cleaned).strip()
    if not cleaned:
        return ""
    return cleaned


def expand_thinking() -> None:
    """Ctrl+O handler — dump the buffered thinking text to output."""
    global THINKING_COLLAPSED
    if THINKING_COLLAPSED and THINKING_FULL_BUFFER:
        THINKING_COLLAPSED = False
        try:
            from . import ui as mico_ui
            mico_ui.render_thinking(THINKING_FULL_BUFFER)
        except (ImportError, Exception):
            DIM_IT = "\033[2;3m"
            RST = "\033[0m"
            for line in THINKING_FULL_BUFFER.splitlines():
                stream_stdout(f"  {DIM_IT}{line}{RST}\n")
        if UI_APP is not None:
            try:
                UI_APP.invalidate()
            except Exception:
                pass


def stream_monologue_text(text: str) -> None:
    global MONOLOGUE_BUFFER, THINKING_FULL_BUFFER, _STREAMING_ACTIVE
    if not text:
        return

    # Strip MLX stop tokens
    chunk = text
    for tok in ("<|im_end|>", "<|im_start|>", "<|endoftext|>", "<think>", "</think>"):
        chunk = chunk.replace(tok, "")
    if not chunk.strip():
        return

    # Always accumulate into full buffer for Ctrl+O expand
    THINKING_FULL_BUFFER += chunk

    # Plain stdout mode: stream directly via render_thinking (no collapse)
    if USE_PLAIN_STDOUT:
        sanitized = clean_reasoning_for_display(chunk)
        if not sanitized:
            return
        try:
            from . import ui as mico_ui
            _sp = _ACTIVE_SPINNER
            if _sp is not None and not _STREAMING_ACTIVE:
                _sp.pause()
                runtime_status_first_token()
            _STREAMING_ACTIVE = True
            note_live_output_text(sanitized)
            mico_ui.render_thinking(sanitized)
        except (ImportError, Exception):
            pass
        return

    # TUI mode: collapsed — don't write thinking text to output yet
    if THINKING_COLLAPSED:
        return

    # Expanded TUI mode: render chunks live instead of sentence-buffering.
    # Some providers emit tiny fragments such as "." or short newline-delimited
    # spans; buffering those until sentence completion hides the stream.
    sanitized = clean_reasoning_for_display(chunk)
    if not sanitized:
        return
    try:
        from . import ui as mico_ui
        _sp = _ACTIVE_SPINNER
        if _sp is not None and not _STREAMING_ACTIVE:
            _sp.pause()
            runtime_status_first_token()
        _STREAMING_ACTIVE = True
        note_live_output_text(sanitized)
        mico_ui.render_thinking(sanitized)
    except (ImportError, Exception):
        stream_stdout(sanitized)


def tag_suffix_carry(text: str, tags: tuple[str, ...]) -> str:
    max_len = max(len(tag) for tag in tags) - 1
    limit = min(len(text), max_len)
    for size in range(limit, 0, -1):
        suffix = text[-size:]
        if any(tag.startswith(suffix) for tag in tags):
            return suffix
    return ""


def history_safe_text(text: str) -> str:
    return _history_safe_text(
        text,
        strip_thinking=strip_thinking,
        truncator=truncate,
        limit=HISTORY_ITEM_SOFT_LIMIT,
    )


def assistant_safe_text(text: str) -> str:
    return _assistant_safe_text(
        text,
        strip_thinking=strip_thinking,
        truncator=truncate,
        raw_assistant_soft_limit=RAW_ASSISTANT_SOFT_LIMIT,
    )


def history_total_chars(history: list[dict[str, str]]) -> int:
    return _history_total_chars(history)


def compact_trigger_chars() -> int:
    return _compact_trigger_chars(
        context_window_tokens=CONTEXT_WINDOW_TOKENS,
        auto_compact_ratio=AUTO_COMPACT_RATIO,
        history_compact_char_trigger=HISTORY_COMPACT_CHAR_TRIGGER,
    )


def update_compact_meter(history: list[dict[str, str]]) -> int:
    global UI_COMPACT_PERCENT_REMAINING
    UI_COMPACT_PERCENT_REMAINING = _update_compact_meter(
        history,
        compact_trigger_chars=compact_trigger_chars,
        history_total_chars=history_total_chars,
    )
    return UI_COMPACT_PERCENT_REMAINING


atexit.register(shutdown_on_exit)


def safe_path(path: str, cwd: Path) -> Path:
    return _safe_path(path, cwd)


def _mico_source_dir() -> str:
    """Return the mico package source directory (the directory containing cli.py)."""
    return str(Path(__file__).resolve().parent)


SENSITIVE_PATH_PATTERNS: tuple[str, ...] = (
    "~/.ssh", "~/.aws", "~/.gnupg", "~/.config", "~/.gitconfig",
    "~/.netrc", "~/.docker/config.json", "~/.kube",
    "~/Library/Keychains", "~/Library/Application Support/Google/Chrome",
    "~/Library/Application Support/Firefox", "~/Library/Cookies",
    "/etc", "/private/etc", "/System", "/Library", "/var/db",
    "/var/root", "/Volumes",
)

# Core mico source files the model must never overwrite (prevents self-damage during analysis tasks).
_MICO_CORE_FILES: frozenset[str] = frozenset({
    "cli.py", "tool_dispatch.py", "tool_runner.py", "model_text.py",
    "prompt_builder.py", "task_envelope.py", "task_classify.py",
    "model_recommender.py", "action_parse.py", "action_schemas.py",
    "command_policy.py", "repair.py", "server.py", "model_client.py",
    "session_ops.py", "compact.py", "history_utils.py",
})


def _resolved_sensitive_paths() -> set[Path]:
    resolved: set[Path] = set()
    for raw in SENSITIVE_PATH_PATTERNS:
        try:
            resolved.add(Path(raw).expanduser().resolve(strict=False))
        except (OSError, RuntimeError):
            continue
    return resolved


_SENSITIVE_PATHS_CACHE: set[Path] | None = None


def _sensitive_paths() -> set[Path]:
    global _SENSITIVE_PATHS_CACHE
    if _SENSITIVE_PATHS_CACHE is None:
        _SENSITIVE_PATHS_CACHE = _resolved_sensitive_paths()
    return _SENSITIVE_PATHS_CACHE


def is_sensitive_path(p: Path) -> bool:
    try:
        resolved = Path(p).expanduser().resolve(strict=False)
    except (OSError, RuntimeError):
        return True
    sensitive = _sensitive_paths()
    if resolved in sensitive:
        return True
    for ancestor in resolved.parents:
        if ancestor in sensitive:
            return True
    return False


def _is_within(child: Path, parent: Path) -> bool:
    try:
        child_r = child.expanduser().resolve(strict=False)
        parent_r = parent.expanduser().resolve(strict=False)
    except (OSError, RuntimeError):
        return False
    if child_r == parent_r:
        return True
    return parent_r in child_r.parents


def enforce_path_policy(p: Path, ctx: "ToolContext", *, write: bool) -> None:
    resolved = Path(p).expanduser().resolve(strict=False)
    if is_sensitive_path(resolved):
        raise PermissionError(
            f"Path inside protected location: {resolved}. Always denied."
        )
    if write and resolved.name in _MICO_CORE_FILES:
        mico_src = Path(_mico_source_dir()).resolve()
        if resolved.parent.resolve() == mico_src:
            raise PermissionError(
                f"Writing to mico core source file '{resolved.name}' is not allowed. "
                f"Use final to report findings instead."
            )
    cwd_resolved = Path(ctx.cwd).expanduser().resolve(strict=False)
    if _is_within(resolved, cwd_resolved):
        return
    allowed = getattr(ctx, "allowed_external_paths", []) or []
    for allowed_path in allowed:
        if _is_within(resolved, Path(allowed_path)):
            return
    action = "write" if write else "read"
    raise PermissionError(
        f"Path outside project root denied for {action}: {resolved}. "
        f"Project root: {cwd_resolved}. "
        f"Write files inside the project root ({cwd_resolved}) instead."
    )


def safe_path_for_tool(path: str, ctx: "ToolContext", *, write: bool) -> Path:
    target = safe_path(path, ctx.cwd)
    enforce_path_policy(target, ctx, write=write)
    return target


def dangerous_command(command: str) -> bool:
    return _dangerous_command(command)


def catastrophic_command_reason(command: str) -> str | None:
    return _catastrophic_command_reason(command)


def classify_command(command: str) -> tuple[str, str]:
    """Returns (tier, reason). Tier: 'allow' | 'ask' | 'deny'. Catastrophic check is separate."""
    return _classify_command(command)




def runtime_context_text(ctx: ToolContext, *, effective_mode: str | None = None) -> str:
    mode_display = effective_mode or str(getattr(ctx, "mode", "auto") or "auto")
    return _runtime_context_text(
        cwd=str(ctx.cwd),
        model_provider=MODEL_PROVIDER,
        model=MODEL,
        offline=OFFLINE,
        network_access=ctx.network_access,
        tool_install=ctx.tool_install,
        pentest_mode=PENTEST_MODE,
        mode_display=mode_display,
        profile=ctx.profile,
        dry_run=ctx.dry_run,
        unattended=ctx.unattended,
    )


def compact_runtime_context_text(ctx: ToolContext) -> str:
    return _compact_runtime_context_text(
        cwd=str(ctx.cwd),
        mode=ctx.mode,
        profile=ctx.profile,
        network_access=ctx.network_access,
        tool_install=ctx.tool_install,
    )


def apply_runtime_profile(name: str) -> str:
    global THINKING_BUDGET, ADAPTIVE_BUDGET, CONTEXT_WINDOW_TOKENS
    profile = PROFILE_PRESETS.get(name, PROFILE_PRESETS["balanced"])
    THINKING_BUDGET = int(profile["thinking_budget"])
    ADAPTIVE_BUDGET = bool(profile["adaptive_budget"])
    CONTEXT_WINDOW_TOKENS = int(profile["context_window"])
    return name if name in PROFILE_PRESETS else "balanced"


def trim_cache(cache: dict[str, Any], limit: int) -> None:
    while len(cache) > limit:
        first_key = next(iter(cache))
        cache.pop(first_key, None)


def cached_read_text(path: Path) -> str:
    stat = path.stat()
    key = str(path.resolve())
    cached = READ_CACHE.get(key)
    if cached and cached[0] == stat.st_mtime:
        return cached[1]
    text = path.read_text()
    READ_CACHE[key] = (stat.st_mtime, text)
    trim_cache(READ_CACHE, READ_CACHE_LIMIT)
    return text


_LIST_HIDDEN_NAMES = frozenset({".agent-runs", ".mico", "__pycache__", ".git", ".DS_Store"})
_LIST_HIDDEN_SUFFIXES = (".pyc", ".pyo")
_LIST_ARTIFACT_RE = re.compile(r"^\d{4}-\d{2}-\d{2}T\d{2}-\d{2}-\d{2}")  # timestamp filenames


def cached_list_entries(path: Path) -> list[str]:
    stat = path.stat()
    key = str(path.resolve())
    cached = DIR_CACHE.get(key)
    if cached and cached[0] == stat.st_mtime:
        return list(cached[1])
    entries = sorted(path.iterdir(), key=lambda p: (p.is_file(), p.name.lower()))
    rendered = []
    for entry in entries[:400]:
        name = entry.name
        if name in _LIST_HIDDEN_NAMES:
            continue
        if name.startswith("."):
            continue
        if name.endswith(_LIST_HIDDEN_SUFFIXES):
            continue
        if _LIST_ARTIFACT_RE.match(name):
            continue
        rendered.append(name + ("/" if entry.is_dir() else ""))
    DIR_CACHE[key] = (stat.st_mtime, rendered)
    trim_cache(DIR_CACHE, READ_CACHE_LIMIT)
    return list(rendered)


def startup_note_paths(ctx: ToolContext) -> list[Path]:
    return _startup_note_paths(
        ctx.cwd,
        GLOBAL_STARTUP_NOTES_PATH,
        os.environ.get("MICO_EXTRA_NOTES_FILE", ""),
    )


def load_startup_notes(ctx: ToolContext, task: str = "") -> str:
    return _load_startup_notes(
        cwd=ctx.cwd,
        global_startup_notes_path=GLOBAL_STARTUP_NOTES_PATH,
        extra_notes_file=os.environ.get("MICO_EXTRA_NOTES_FILE", ""),
        should_skip_minimal=bool(task and (task_prefers_minimal_context(task) or not task_is_security_sensitive(task))),
        should_skip_memory_guard=bool(task and task_needs_memory_guard(task, ctx)),
        truncator=truncate,
    )


def is_inline_code_heavy_final(message: str) -> bool:
    return _is_inline_code_heavy_final(message)



def git_diff_patch(cwd: Path, limit: int = 8000) -> str:
    root = git_repo_root(cwd)
    if root is None:
        return "not a git repo"
    try:
        proc = run_subprocess(["git", "diff", "--unified=3", "--", "."], cwd=root, timeout=25)
    except Exception as exc:
        return f"git diff failed: {exc}"
    if proc.returncode != 0:
        return f"git diff failed: {proc.stderr.strip() or proc.stdout.strip()}"
    text = proc.stdout.strip() or "no changes"
    return truncate(text, limit)


def detect_primary_test_runner(cwd: Path) -> TestRunner | None:
    detected = detect_test_runners(cwd)
    if not detected:
        return None
    return detected[0]


def max_fix_loops_for_context(ctx: ToolContext) -> int:
    if ACTIVE_PROFILE is not None:
        if ACTIVE_PROFILE.name == "fast":
            return 2
        if ACTIVE_PROFILE.name in {"normal", "deep"}:
            return 3
    if ctx.profile == "lite":
        return 1
    if ctx.profile == "fast":
        return 2
    return 3


def collect_failure_file_context(cwd: Path, result: TestResult, limit: int = 3) -> str:
    blocks: list[str] = []
    for failure in result.failing_tests[:limit]:
        file_path = str(failure.get("file") or "").strip()
        if not file_path:
            continue
        try:
            target = safe_path(file_path, cwd)
            if not target.is_absolute():
                target = (cwd / file_path).resolve()
            if not target.exists() or not target.is_file():
                continue
            text = target.read_text(encoding="utf-8", errors="replace")
        except OSError:
            continue
        lines = text.splitlines()
        line_no = int(failure.get("line") or 1)
        start = max(0, line_no - 6)
        end = min(len(lines), line_no + 6)
        excerpt = "\n".join(f"{idx + 1}: {lines[idx]}" for idx in range(start, end))
        blocks.append(f"# {file_path}\n{excerpt}")
    return "\n\n".join(blocks)


def build_recovery_prompt(kind: str, *, task: str, state: TaskState, details: str = "", excerpts: str = "", diff_text: str = "") -> str:
    return _build_recovery_prompt(
        kind,
        task_body=extract_task_body(task),
        mode=state.mode,
        task_kind=state.task_kind,
        details=details,
        excerpts=excerpts,
        diff_text=diff_text,
        truncator=truncate,
    )


async def request_role_action(task: str, ctx: ToolContext, role: str, prompt_text: str) -> tuple[dict[str, Any], str]:
    messages = [
        {"role": "system", "content": build_system_prompt(task, ctx, role=role)},
        {"role": "user", "content": prompt_text},
    ]
    raw = await call_model(
        messages,
        thinking_budget=MIN_THINKING_BUDGET,
        stream=False,
        use_orchestra=False,
        role=role,
    )
    action = extract_json(raw)
    valid, reason = validate_action(action)
    if not valid:
        raise ValueError(reason)
    return action, raw


async def request_recovery_action(
    task: str,
    ctx: ToolContext,
    state: TaskState,
    kind: str,
    *,
    details: str = "",
    excerpts: str = "",
    diff_text: str = "",
    role: str = "worker",
) -> tuple[dict[str, Any], str]:
    prompt_text = build_recovery_prompt(
        kind,
        task=task,
        state=state,
        details=details,
        excerpts=excerpts,
        diff_text=diff_text,
    )
    return await request_role_action(task, ctx, role, prompt_text)


def recovery_kind_for_exception(exc: Exception) -> str:
    return _recovery_kind_for_exception(exc)


def recovery_guidance_for_exception(task: str, state: TaskState, exc: Exception) -> str:
    return build_recovery_prompt(
        recovery_kind_for_exception(exc),
        task=task,
        state=state,
        details=str(exc),
    )


def request_architect_handoff(task: str, ctx: ToolContext, state: TaskState) -> dict[str, Any] | None:
    from mico.orchestra import request_architect_handoff as _request_architect_handoff
    return _request_architect_handoff(
        task,
        ctx,
        state,
        active_profile=ACTIVE_PROFILE,
        resolve_role_model=resolve_role_model,
        extract_task_body=extract_task_body,
        build_task_state_prompt=build_task_state_prompt,
        build_system_prompt=build_system_prompt,
        call_model=call_model,
        min_thinking_budget=MIN_THINKING_BUDGET,
        extract_json=extract_json,
        truncate=truncate,
        render_log_line=render_log_line,
        color_plan=COLOR_PLAN,
    )


def request_reviewer_note(task: str, ctx: ToolContext, state: TaskState, test_summary: str = "") -> str:
    from mico.orchestra import request_reviewer_note as _request_reviewer_note
    return _request_reviewer_note(
        task,
        ctx,
        state,
        test_summary=test_summary,
        active_profile=ACTIVE_PROFILE,
        resolve_role_model=resolve_role_model,
        extract_task_body=extract_task_body,
        git_diff_patch=git_diff_patch,
        truncate=truncate,
        request_role_action=request_role_action,
        render_log_line=render_log_line,
        color_plan=COLOR_PLAN,
    )


async def run_auto_test_fix_loop(
    task: str,
    ctx: ToolContext,
    session_id: str,
    state: TaskState,
    history: list[dict[str, str]],
    *,
    max_attempts: int,
) -> tuple[bool, str]:
    return await _run_auto_test_fix_loop(
        task,
        ctx,
        session_id,
        state,
        history,
        max_attempts=max_attempts,
        detect_primary_test_runner=detect_primary_test_runner,
        run_tests_impl=_run_tests_impl,
        save_task_state=save_task_state,
        should_continue_fix_loop=should_continue_fix_loop,
        git_diff_patch=git_diff_patch,
        collect_failure_file_context=collect_failure_file_context,
        request_recovery_action=request_recovery_action,
        apply_patch_pipeline=_apply_patch_pipeline,
        patch_error_type=PatchError,
        truncator=truncate,
        history_safe_text=history_safe_text,
        git_diff_summary=git_diff_summary,
        maybe_compact_history=maybe_compact_history,
        save_session=save_session,
        cancel_requested=lambda: CANCEL_REQUESTED.is_set(),
        stop_requested=lambda: STOP_REQUESTED,
        fix_loop_state_factory=FixLoopState,
    )


def read_clipboard_text() -> str:
    try:
        proc = subprocess.run(
            ["/usr/bin/pbpaste"],
            capture_output=True,
            text=True,
            timeout=10,
        )
    except Exception as exc:
        raise RuntimeError(f"Clipboard read failed: {exc}") from exc
    if proc.returncode != 0:
        raise RuntimeError(proc.stderr.strip() or "Clipboard read failed.")
    return proc.stdout


def run_subprocess(
    args: list[str],
    *,
    cwd: Path | None = None,
    timeout: float = 30.0,
) -> subprocess.CompletedProcess[str]:
    return subprocess.run(
        args,
        cwd=str(cwd) if cwd else None,
        capture_output=True,
        text=True,
        timeout=timeout,
    )


def shell_join(parts: list[str]) -> str:
    return _shell_join(parts)


# ---------------------------------------------------------------------------
# Git checkpoint helpers (refs/mico-checkpoints/* namespace)
# ---------------------------------------------------------------------------

MICO_CHECKPOINT_REF_NS = "refs/mico-checkpoints/"


def git_repo_root(cwd: Path) -> Path | None:
    return _git_repo_root(cwd, run_subprocess=run_subprocess)


def _slugify_checkpoint_label(label: str) -> str:
    return _git_cp.slugify_checkpoint_label(label)


def create_git_checkpoint(cwd: Path, label: str = "") -> tuple[str | None, str]:
    """Create a checkpoint ref under refs/mico-checkpoints/.

    Returns (ref_name_or_None, message_or_sha). On success returns (ref, sha).
    On failure returns (None, error_message).
    """
    return _git_cp.create_git_checkpoint(
        cwd,
        label=label,
        git_repo_root=git_repo_root,
        run_subprocess=run_subprocess,
    )


def list_git_checkpoints(cwd: Path) -> list[dict]:
    return _git_cp.list_git_checkpoints(
        cwd,
        checkpoint_ref_ns=MICO_CHECKPOINT_REF_NS,
        git_repo_root=git_repo_root,
        run_subprocess=run_subprocess,
    )


def _normalize_checkpoint_ref(ref: str) -> str:
    return _git_cp.normalize_checkpoint_ref(ref, MICO_CHECKPOINT_REF_NS)


def rollback_to_checkpoint(cwd: Path, ref: str, paths: list[str] | None = None) -> str:
    return _git_cp.rollback_to_checkpoint(
        cwd,
        ref,
        paths=paths,
        checkpoint_ref_ns=MICO_CHECKPOINT_REF_NS,
        git_repo_root=git_repo_root,
        run_subprocess=run_subprocess,
        create_checkpoint=lambda root, name: create_git_checkpoint(root, name),
    )


def git_diff_summary(cwd: Path) -> str:
    return _git_cp.git_diff_summary(
        cwd,
        git_repo_root=git_repo_root,
        run_subprocess=run_subprocess,
        truncator=truncate,
    )


def git_status_short(cwd: Path) -> str:
    return _git_cp.git_status_short(
        cwd,
        git_repo_root=git_repo_root,
        run_subprocess=run_subprocess,
    )


def install_command_env() -> dict[str, str]:
    return _install_command_env()


def find_skill_by_name(name: str, ctx: ToolContext) -> SkillSpec | None:
    return _find_skill_by_name(name, discover_skills=discover_skills, ctx=ctx)


def skill_archive_members(skill: SkillSpec) -> list[str]:
    return _skill_archive_members(skill)


def read_skill_member(skill: SkillSpec, member: str) -> str:
    return _read_skill_member(skill, member)


def hackingtool_repo_root() -> Path:
    raise NotImplementedError("hackingtool support removed")


def hackingtool_disallowed_categories() -> set[str]:
    raise NotImplementedError("hackingtool support removed")


def normalize_tool_key(value: str) -> str:
    raise NotImplementedError("hackingtool support removed")


def parse_hackingtool_specs() -> list[HackingToolSpec]:
    raise NotImplementedError('parse_hackingtool_specs support removed (security module)')


def find_hackingtool_spec(name: str) -> HackingToolSpec | None:
    raise NotImplementedError('find_hackingtool_spec support removed (security module)')


def infer_hackingtool_command(spec: HackingToolSpec, args: list[str]) -> tuple[list[str], Path | None] | None:
    raise NotImplementedError('infer_hackingtool_command support removed (security module)')


def skill_tool(action: dict[str, Any], ctx: ToolContext) -> str:
    skill_name = str(action.get("skill", "")).strip()
    op = str(action.get("action", "")).strip().lower()
    if not op:
        raise ValueError("skill_tool missing action")
    if op == "list_skills":
        skills = discover_skills(ctx)
        return "\n".join(f"{skill.name} | {skill.source} | {skill.description}" for skill in skills) or "(no skills)"
    if not skill_name:
        raise ValueError("skill_tool missing skill")
    skill = find_skill_by_name(skill_name, ctx)
    if not skill:
        raise ValueError(f"skill not found: {skill_name}")
    if op == "read_reference":
        path = str(action.get("path", "")).strip()
        return truncate(read_skill_member(skill, path).strip() or "(no output)", MAX_TOOL_OUTPUT_CHARS)
    if op == "run_script":
        path = str(action.get("path", "")).strip()
        args = [str(item) for item in action.get("args", [])]
        if skill.source.suffix == ".skill":
            raise ValueError("run_script requires an unpacked skill directory")
        target = (skill.source / path).resolve()
        if not target.is_file() or skill.source.resolve() not in target.parents:
            raise ValueError(f"script not found: {path}")
        proc = run_subprocess([str(target), *args], cwd=skill.source, timeout=int(action.get("timeout", 120000)) / 1000.0)
        output = ((proc.stdout or "") + ("\n" + proc.stderr if proc.stderr else "")).strip() or "(no output)"
        return f"exit_code={proc.returncode}\n{truncate(output, MAX_TOOL_OUTPUT_CHARS)}"
    if op == "list_tools":
        return "\n".join(skill_archive_members(skill)) or "(no bundled tools)"
    # hackingtool-skill support moved to mico-security package
    if skill.name == "hackingtool-skill":
        raise NotImplementedError("hackingtool support moved to mico-security package. Install with: pip install mico-security")
    raise ValueError(f"Unsupported action for skill {skill.name}: {op}")


def list_network_interfaces() -> str:
    hardware = run_subprocess(
        ["/usr/sbin/networksetup", "-listallhardwareports"],
        timeout=15,
    )
    ifconfig = run_subprocess(
        ["/sbin/ifconfig"],
        timeout=15,
    )
    return (
        "networksetup:\n"
        + truncate((hardware.stdout or hardware.stderr).strip() or "(no output)", 12000)
        + "\n\nifconfig:\n"
        + truncate((ifconfig.stdout or ifconfig.stderr).strip() or "(no output)", 12000)
    )


def run_admin_shell(command: str, *, timeout: float = 120.0) -> str:
    apple_script = (
        'do shell script '
        + json.dumps(command)
        + ' with administrator privileges'
    )
    proc = run_subprocess(
        ["/usr/bin/osascript", "-e", apple_script],
        timeout=timeout,
    )
    output = (proc.stdout or proc.stderr).strip() or "(no output)"
    if proc.returncode != 0:
        raise RuntimeError(output)
    return output


def validate_mac_address(value: str) -> str:
    normalized = value.strip().lower().replace("-", ":")
    if not re.fullmatch(r"[0-9a-f]{2}(:[0-9a-f]{2}){5}", normalized):
        raise ValueError("Invalid MAC address format. Use aa:bb:cc:dd:ee:ff")
    return normalized


def macos_admin_task(action: dict[str, Any]) -> str:
    name = str(action.get("name", "")).strip().lower()
    if not name:
        raise ValueError("macos_admin_task missing name")

    if name == "list_network_interfaces":
        return list_network_interfaces()

    if name == "change_mac":
        interface = str(action.get("interface", "")).strip()
        mac = validate_mac_address(str(action.get("mac", "")))
        cycle = bool(action.get("cycle_interface", True))
        commands = [f"/sbin/ifconfig {shlex.quote(interface)} ether {shlex.quote(mac)}"]
        if cycle:
            commands = [
                f"/sbin/ifconfig {shlex.quote(interface)} down",
                *commands,
                f"/sbin/ifconfig {shlex.quote(interface)} up",
            ]
        output = run_admin_shell(" && ".join(commands), timeout=180.0)
        verify = run_subprocess(
            ["/sbin/ifconfig", interface],
            timeout=15,
        )
        verify_output = (verify.stdout or verify.stderr).strip() or "(no output)"
        return f"{output}\n\nverify:\n{truncate(verify_output, 4000)}"

    if name == "set_wifi_power":
        interface = str(action.get("interface", "")).strip()
        state = str(action.get("state", "")).strip().lower()
        if state not in {"on", "off"}:
            raise ValueError("set_wifi_power state must be on or off")
        output = run_admin_shell(
            f"/usr/sbin/networksetup -setairportpower {shlex.quote(interface)} {shlex.quote(state)}",
            timeout=120.0,
        )
        return output

    if name == "renew_dhcp":
        interface = str(action.get("interface", "")).strip()
        output = run_admin_shell(
            f"/usr/sbin/ipconfig set {shlex.quote(interface)} DHCP",
            timeout=120.0,
        )
        return output

    if name == "flush_dns":
        output = run_admin_shell(
            "/usr/bin/dscacheutil -flushcache && /usr/bin/killall -HUP mDNSResponder",
            timeout=120.0,
        )
        return output

    raise ValueError(f"Unsupported macos_admin_task: {name}")


def ensure_binary(name: str) -> str:
    path = shutil.which(name)
    if not path:
        raise RuntimeError(f"Required binary not found in PATH: {name}")
    return path


async def run_security_command(binary: str, args: list[str], ctx: ToolContext, *, timeout: float = 120.0) -> str:
    if ctx.runner is None:
        ctx.runner = get_default_runner()
    
    res = await ctx.runner.run_command([binary, *args], cwd=ctx.cwd, timeout=timeout)
    output = res.combined.strip() or "(no output)"
    return f"exit_code={res.exit_code}\n{truncate(output, MAX_TOOL_OUTPUT_CHARS)}"


# security_tool moved to mico-security package
def security_tool(action: dict[str, Any]) -> str:
    raise NotImplementedError("security_tool support moved to mico-security package. Install with: pip install mico-security")


# security_preset moved to mico-security package
def security_preset(action: dict[str, Any]) -> str:
    raise NotImplementedError("security_preset support moved to mico-security package. Install with: pip install mico-security")


async def coding_tool(action: dict[str, Any], ctx: ToolContext) -> str:
    name = str(action.get("name", "")).strip().lower()
    timeout = int(action.get("timeout", 120000)) / 1000.0
    if not name:
        raise ValueError("coding_tool missing name")

    if name == "search_code":
        pattern = str(action.get("pattern", "")).strip()
        path = str(action.get("path", ".")).strip()
        extra = [str(item) for item in action.get("options", [])]
        if not pattern:
            raise ValueError("search_code pattern is required")
        target = safe_path(path, ctx.cwd)
        return await run_security_command(
            ensure_binary("rg"),
            ["-n", "--hidden", *extra, pattern, str(target)],
            ctx,
            timeout=timeout,
        )

    if name == "find_files":
        path = str(action.get("path", ".")).strip()
        pattern = str(action.get("pattern", "")).strip()
        target = safe_path(path, ctx.cwd)
        proc = run_subprocess([ensure_binary("rg"), "--files", str(target)], timeout=timeout)
        text = (proc.stdout or proc.stderr).strip() or "(no output)"
        if proc.returncode != 0:
            return f"exit_code={proc.returncode}\n{truncate(text, MAX_TOOL_OUTPUT_CHARS)}"
        if not pattern:
            return truncate(text, MAX_TOOL_OUTPUT_CHARS)
        lines = text.splitlines()
        filtered = [line for line in lines if pattern in line]
        return "\n".join(filtered) if filtered else "(no matches)"

    if name == "git_status":
        return await run_security_command("/usr/bin/env", ["git", "status", "--short"], ctx, timeout=timeout)
    if name == "git_diff":
        path = str(action.get("path", "")).strip()
        ref = str(action.get("ref", "")).strip()
        args = ["git", "diff"]
        if ref:
            args.append(ref)
        if path:
            args.extend(["--", str(safe_path(path, ctx.cwd))])
        return await run_security_command("/usr/bin/env", args, ctx, timeout=timeout)

    if name == "git_log":
        count = str(action.get("count", "10")).strip()
        return await run_security_command(
            "/usr/bin/env",
            ["git", "log", f"-n{count}", "--oneline", "--decorate"],
            ctx,
            timeout=timeout,
        )

    if name == "python_check":
        path = str(action.get("path", "")).strip()
        if not path:
            raise ValueError("python_check path is required")
        target = safe_path(path, ctx.cwd)
        return await run_security_command(sys.executable, ["-m", "py_compile", str(target)], ctx, timeout=timeout)

    if name == "parse_json_file":
        path = str(action.get("path", "")).strip()
        if not path:
            raise ValueError("parse_json_file path is required")
        target = safe_path(path, ctx.cwd)
        data = json.loads(cached_read_text(target))
        pretty = json.dumps(data, ensure_ascii=False, indent=2)
        return truncate(pretty, MAX_TOOL_OUTPUT_CHARS)

    raise ValueError(f"Unsupported coding_tool: {name}")


def prompt_box_input(session_id: str, ctx: ToolContext) -> str | None:
    if not PROMPT_TOOLKIT_AVAILABLE:
        try:
            return Prompt.ask("[bold cyan]>[/bold cyan]").strip()
        except EOFError:
            return None

    info_lines = build_prompt_status_html(session_id, ctx)
    style = Style.from_dict(
        {
            "frame.border": "#5f87af",
            "frame.label": "bold #ffffff",
            "textarea": "#ffffff bg:#111111",
        }
    )
    editor = TextArea(
        text="",
        scrollbar=True,
        wrap_lines=False,
        multiline=True,
        history=InMemoryHistory(),
        style="class:textarea",
    )
    buffer = editor.buffer
    buffer.set_document(Document("", 0))
    bindings = KeyBindings()

    @bindings.add("enter")
    def _submit(event) -> None:
        event.app.exit(result=buffer.text)

    @bindings.add("escape", "enter")
    def _newline(event) -> None:
        buffer.insert_text("\n")

    @bindings.add("escape")
    def _cancel_line(event) -> None:
        buffer.text = ""
        event.app.exit(result="__cancel__")

    @bindings.add("tab")
    def _indent(event) -> None:
        buffer.insert_text("    ")

    @bindings.add("c-d")
    def _exit(event) -> None:
        if buffer.text.strip():
            event.app.exit(result=buffer.text)
        else:
            event.app.exit(result=None)

    @bindings.add("c-c")
    def _cancel(event) -> None:
        release_server_now()
        event.app.exit(result=None)

    app = Application(
        layout=Layout(
            HSplit(
                [
                    Frame(editor, title="Prompt"),
                    Label(text=info_lines),
                ]
            )
        ),
        key_bindings=bindings,
        mouse_support=UI_MOUSE_SUPPORT,
        full_screen=False,
        style=style,
    )
    return app.run()


def build_prompt_status_html(session_id: str, ctx: ToolContext) -> HTML:
    mode = ctx.mode
    profile = ctx.profile
    model_profile = ACTIVE_PROFILE.name if ACTIVE_PROFILE else "default"
    return HTML(
        _build_prompt_status_markup(
            mode=mode,
            approval=ctx.approval,
            thinking_enabled=THINKING,
            runtime_profile=profile,
            model_profile=model_profile,
            dry_run=bool(ctx.dry_run),
            session_short=session_id[:8],
            model=model_label(MODEL),
            cwd=str(ctx.cwd),
            thinking_budget=f"{THINKING_BUDGET}{' auto' if ADAPTIVE_BUDGET else ''}",
            context_window_tokens=CONTEXT_WINDOW_TOKENS,
            compact_remaining_percent=UI_COMPACT_PERCENT_REMAINING,
            narrate=bool(ctx.narrate),
        )
    )


def current_terminal_width(default: int = 120) -> int:
    if UI_APP is not None:
        try:
            return max(60, UI_APP.output.get_size().columns)
        except Exception:
            pass
    try:
        return max(60, shutil.get_terminal_size((default, 24)).columns)
    except Exception:
        return default


def build_footer_status_html(session_id: str, ctx: ToolContext) -> HTML:
    model_profile = ACTIVE_PROFILE.name if ACTIVE_PROFILE else "default"
    turn_trace = get_turn_trace()
    usage = dict(turn_trace.get("usage") or {})
    if not usage and LIVE_COMPLETION_STARTED_AT is not None and LIVE_COMPLETION_TOKENS > 0:
        usage = {
            "completion_tokens": LIVE_COMPLETION_TOKENS,
            "llm_seconds": max(0.001, time.monotonic() - LIVE_COMPLETION_STARTED_AT),
        }
    return HTML(
        _build_footer_status_markup(
            model=MODEL or "?",
            mode=ctx.mode or "auto",
            runtime_profile=ctx.profile or "balanced",
            model_profile=model_profile,
            context_window_tokens=CONTEXT_WINDOW_TOKENS,
            thinking_enabled=THINKING,
            thinking_budget=THINKING_BUDGET,
            adaptive_budget=ADAPTIVE_BUDGET,
            permission_mode=getattr(ctx, "approval", None) or "balanced",
            dry_run=bool(ctx.dry_run),
            usage=usage,
        )
    )


def build_inline_status_html() -> HTML:
    spinner = UI_SPINNER_FRAMES[UI_SPINNER_INDEX % len(UI_SPINNER_FRAMES)] if UI_STATUS_TEXT != "idle" else "·"
    elapsed = None
    if UI_STATUS_STARTED_AT is not None and UI_STATUS_TEXT != "idle":
        elapsed = time.time() - UI_STATUS_STARTED_AT
    turn_trace = get_turn_trace()
    return HTML(
        _build_inline_status_markup(
            spinner_frame=spinner,
            status_text=UI_STATUS_TEXT,
            elapsed_seconds=elapsed,
            compact_remaining_percent=UI_COMPACT_PERCENT_REMAINING,
            usage=(turn_trace.get("usage") or {}),
        )
    )


def apply_effort_level(level: str) -> str:
    """Apply effort level: low=fast/no-thinking, medium=default, high=deep.

    low:    thinking OFF, tool loop capped at 12 steps — hız öncelikli
    medium: thinking ON, profile budget, tool loop capped at 24 steps
    high:   thinking ON, budget>=2048, tool loop uncapped (DEFAULT_ITERATIONS)
    """
    global THINKING, THINKING_BUDGET, EFFORT_MAX_ITERATIONS
    value = str(level or "").strip().lower()
    if value not in {"low", "medium", "high"}:
        raise ValueError("effort must be one of: low, medium, high")
    profile_budget = 0
    try:
        profile_budget = int(getattr(ACTIVE_PROFILE, "thinking_budget", 0) or 0)
    except Exception:
        profile_budget = 0
    if value == "low":
        THINKING = False
        THINKING_BUDGET = 0
        EFFORT_MAX_ITERATIONS = 12
        return "Effort: low — thinking kapalı, hızlı mod (max 12 adım)."
    elif value == "medium":
        THINKING = True
        THINKING_BUDGET = max(512, profile_budget)
        EFFORT_MAX_ITERATIONS = 24
        return f"Effort: medium — thinking açık, budget={THINKING_BUDGET}, max 24 adım."
    else:  # high
        THINKING = True
        THINKING_BUDGET = max(2048, profile_budget)
        EFFORT_MAX_ITERATIONS = DEFAULT_ITERATIONS
        return f"Effort: high — thinking açık, budget={THINKING_BUDGET}, derinlemesine analiz."


def command_uses_external_network(command: str) -> bool:
    return _command_uses_external_network(command)


def full_root_scan_reason() -> str:
    return _full_root_scan_reason()



def get_default_runner() -> BaseRunner:
    runner_type = os.environ.get("MICO_RUNNER_TYPE", "local").lower()
    if runner_type == "docker":
        return DockerRunner()
    return LocalRunner()


async def run_tool(action: dict[str, Any], ctx: ToolContext) -> str:
    if ctx.runner is None:
        ctx.runner = get_default_runner()
    tool = action.get("tool")

    # Skills first
    from mico.skill_api import get_skill_registry
    registry = get_skill_registry()
    for skill in registry.list_skills():
        tools = skill.get_tools()
        if tool in tools:
            try:
                update_status(f"running {skill.name}.{tool}")
                return await tools[tool](action, ctx)
            except Exception as e:
                return f"SKILL_ERROR ({skill.name}): {e}"

    if ctx.dry_run:
        return f"dry_run=1\naction={json.dumps(action, ensure_ascii=False, sort_keys=True)}"

    from mico.tool_dispatch import dispatch as _tool_dispatch
    return await _tool_dispatch(action, ctx)


def assistant_messages(system_prompt: str, history: list[dict[str, str]], state_prompt: str = "") -> list[dict[str, str]]:
    extra_system: list[str] = []
    filtered_history: list[dict[str, str]] = []
    for message in history:
        if message.get("role") == "system":
            extra_system.append(str(message.get("content", "")).strip())
        else:
            filtered_history.append(message)

    # Keep the stable system_prompt as its own message so the prompt cache
    # can reuse the prefix across turns. Per-turn dynamic content (state_prompt,
    # injected extra_system entries) is emitted as a user-role [CONTEXT] block
    # placed just before the most recent user turn — this keeps both the
    # system message AND the historical prefix byte-stable across turns,
    # maximizing prompt cache hits in mlx_lm.server.
    dynamic_parts: list[str] = []
    if state_prompt.strip():
        dynamic_parts.append(state_prompt.strip())
    for part in extra_system:
        if part:
            dynamic_parts.append(part)

    messages: list[dict[str, str]] = [{"role": "system", "content": system_prompt}]
    if dynamic_parts:
        # Find index of the last user message in filtered_history; insert
        # the [CONTEXT] block immediately before it.
        last_user_idx = -1
        for idx in range(len(filtered_history) - 1, -1, -1):
            if filtered_history[idx].get("role") == "user":
                last_user_idx = idx
                break
        context_msg = {
            "role": "user",
            "content": "[CONTEXT]\n" + "\n\n".join(dynamic_parts),
        }
        if last_user_idx >= 0:
            messages.extend(filtered_history[:last_user_idx])
            messages.append(context_msg)
            messages.extend(filtered_history[last_user_idx:])
        else:
            messages.extend(filtered_history)
            messages.append(context_msg)
    else:
        messages.extend(filtered_history)
    return normalize_messages_for_model(messages)


def messages_char_count(messages: list[dict[str, str]]) -> int:
    return sum(len(str(message.get("content", ""))) for message in messages)


def compute_request_limits(
    messages: list[dict[str, str]],
    thinking_budget: int,
    max_tokens: int,
    use_orchestra: bool,
) -> tuple[int, int, bool, str]:
    chars = messages_char_count(messages)
    effective_budget = clamp_budget(thinking_budget)
    effective_tokens = max(256, int(max_tokens))
    effective_orchestra = use_orchestra
    reason = ""

    if chars >= REQUEST_CHAR_SOFT_LIMIT:
        effective_budget = clamp_budget(min(effective_budget, max(MIN_THINKING_BUDGET, int(effective_budget * 0.75))))
        effective_tokens = min(effective_tokens, 768)
        effective_orchestra = False
        reason = f"soft governor active ({chars} chars)"

    if chars >= REQUEST_CHAR_HARD_LIMIT:
        effective_budget = clamp_budget(min(effective_budget, max(MIN_THINKING_BUDGET, 384)))
        effective_tokens = min(effective_tokens, 512)
        effective_orchestra = False
        reason = f"hard governor active ({chars} chars)"

    return effective_budget, effective_tokens, effective_orchestra, reason


def apply_task_memory_guard(task: str, ctx: ToolContext, history: list[dict[str, str]]) -> None:
    global THINKING_BUDGET
    if not task_needs_memory_guard(task, ctx):
        return
    if THINKING_BUDGET > 256:
        THINKING_BUDGET = 256
    update_compact_meter(history)




def default_eval_dataset_path() -> Path:
    from mico.eval_suite import default_eval_dataset_path as _f
    return _f(EVALS_DIR)


def load_eval_cases(path: Path) -> list[EvalCase]:
    from mico.eval_suite import load_eval_cases as _f
    return _f(path, EvalCase)


def run_eval_case(case: EvalCase) -> tuple[bool, str]:
    from mico.eval_suite import eval_session_id as _eval_session_id, append_artifacts as _append_eval_artifacts, activate_phase as _activate_eval_phase
    from mico.eval_case_handlers import (
        handle_prompt_mode_case as _handle_prompt_mode_case,
        handle_action_validation_case as _handle_action_validation_case,
        handle_local_shortcut_case as _handle_local_shortcut_case,
        handle_artifact_retrieval_case as _handle_artifact_retrieval_case,
        handle_phase_plan_case as _handle_phase_plan_case,
        handle_phase_transition_case as _handle_phase_transition_case,
        handle_stale_audit_guard_case as _handle_stale_audit_guard_case,
        handle_redundant_artifact_read_case as _handle_redundant_artifact_read_case,
        handle_redundant_http_probe_case as _handle_redundant_http_probe_case,
        handle_verifier_gate_case as _handle_verifier_gate_case,
    )
    from mico.eval_dispatch import run_eval_case_with_dispatch as _run_eval_case_with_dispatch
    ctx = ToolContext(cwd=ROOT, approval="never", force=False, mode=str(case.options.get("mode", "auto")), dry_run=True)
    def new_eval_session_id():
        return _eval_session_id(lambda: uuid.uuid4().hex)
    handlers: dict[str, Any] = {
        "prompt_mode": lambda c: _handle_prompt_mode_case(
            c,
            ctx=ctx,
            resolve_mode_for_task=resolve_mode_for_task,
            build_system_prompt=build_system_prompt,
        ),
        "action_validation": lambda c: _handle_action_validation_case(c, validate_action=validate_action),
        "local_shortcut": lambda c: _handle_local_shortcut_case(
            c,
            ctx=ctx,
            new_eval_session_id=new_eval_session_id,
            tool_loop=tool_loop,
            truncator=truncate,
        ),
        "artifact_retrieval": lambda c: _handle_artifact_retrieval_case(
            c,
            ctx=ctx,
            new_eval_session_id=new_eval_session_id,
            create_task_state=create_task_state,
            append_artifacts=_append_eval_artifacts,
            select_relevant_artifacts=lambda state, task, history: select_relevant_artifacts(state, task, history),
        ),
        "phase_plan": lambda c: _handle_phase_plan_case(
            c,
            ctx=ctx,
            new_eval_session_id=new_eval_session_id,
            create_task_state=create_task_state,
        ),
        "phase_transition": lambda c: _handle_phase_transition_case(
            c,
            ctx=ctx,
            new_eval_session_id=new_eval_session_id,
            create_task_state=create_task_state,
            activate_phase=_activate_eval_phase,
            update_phase_after_tool=update_phase_after_tool,
        ),
        "stale_audit_guard": lambda c: _handle_stale_audit_guard_case(
            c,
            ctx=ctx,
            new_eval_session_id=new_eval_session_id,
            create_task_state=create_task_state,
            append_artifacts=_append_eval_artifacts,
            should_force_finalize_on_stale_audit=should_force_finalize_on_stale_audit,
        ),
        "redundant_artifact_read": lambda c: _handle_redundant_artifact_read_case(
            c,
            ctx=ctx,
            new_eval_session_id=new_eval_session_id,
            create_task_state=create_task_state,
            append_artifacts=_append_eval_artifacts,
            redundant_artifact_read_reason=redundant_artifact_read_reason,
            artifact_reread_guidance=artifact_reread_guidance,
        ),
        "redundant_http_probe": lambda c: _handle_redundant_http_probe_case(
            c,
            ctx=ctx,
            new_eval_session_id=new_eval_session_id,
            create_task_state=create_task_state,
            append_artifacts=_append_eval_artifacts,
            redundant_http_probe_reason=redundant_http_probe_reason,
            redundant_http_probe_guidance=redundant_http_probe_guidance,
        ),
        "verifier_gate": lambda c: _handle_verifier_gate_case(
            c,
            ctx=ctx,
            new_eval_session_id=new_eval_session_id,
            create_task_state=create_task_state,
            current_phase_entry=current_phase_entry,
        ),
    }
    return _run_eval_case_with_dispatch(case, handlers=handlers)


def run_eval_suite(path: Path) -> str:
    from mico.eval_suite import run_eval_suite as _run_eval_suite
    return _run_eval_suite(path, loader=load_eval_cases, run_case=run_eval_case)


def validate_action(action: dict[str, Any]) -> tuple[bool, str]:
    return _validate_action(action)


def verifier_prompt(state: TaskState, history: list[dict[str, str]], step: int) -> list[dict[str, str]]:
    from mico.verifier import verifier_prompt as _verifier_prompt
    return _verifier_prompt(
        state,
        history,
        step,
        build_task_state_prompt=build_task_state_prompt,
    )


async def run_verifier(state: TaskState, history: list[dict[str, str]], step: int) -> dict[str, Any] | None:
    from mico.verifier import run_verifier as _run_verifier
    return await _run_verifier(
        state,
        history,
        step,
        prompt_builder=verifier_prompt,
        call_model=call_model,
        extract_json=extract_json,
        thinking_budget=MIN_THINKING_BUDGET,
        current_phase_entry=current_phase_entry,
    )


def summarize_action(action: dict[str, Any]) -> str:
    return _summarize_action(action)


def tool_family(action: dict[str, Any]) -> str:
    return _tool_family(action)


def narrate_tool_intent(action: dict[str, Any], ctx: ToolContext) -> str:
    return _narrate_tool_intent(action, mode=ctx.mode, truncator=truncate)


def narrate_tool_result(label: str, result: str, is_error: bool) -> str:
    return _narrate_tool_result(label, result, is_error, truncator=truncate)


def tool_output_preview(label: str, result: str, *, is_error: bool = False) -> str:
    return _tool_output_preview(label, result, is_error=is_error, truncator=truncate)


def render_live_diff(path: Path, before: str, after: str) -> None:
    _render_live_diff(
        path,
        before,
        after,
        render_log_line=render_log_line,
        summarize_edit=summarize_edit,
        color_edit=COLOR_EDIT,
        stream_stdout=lambda text: stream_stdout(text),
        stream_stdout_style=lambda text, style: stream_stdout(text, style=style),
    )


def recent_user_message(history: list[dict[str, str]]) -> str:
    return _recent_user_message(history)


def compute_thinking_budget(
    history: list[dict[str, str]],
    ctx: ToolContext,
    step: int,
    consecutive_reads: int,
) -> int:
    return _compute_thinking_budget(
        history,
        ctx,
        step,
        consecutive_reads,
        thinking_budget=THINKING_BUDGET,
        thinking_enabled=THINKING,
        adaptive_budget=ADAPTIVE_BUDGET,
        min_thinking_budget=MIN_THINKING_BUDGET,
        clamp_budget=clamp_budget,
        recent_user_message=recent_user_message,
        current_dispatch_mode=current_dispatch_mode,
    )


async def maybe_compact_history(history: list[dict[str, str]], session_id: str, *, force: bool = False) -> list[dict[str, str]]:
    return await _maybe_compact_history(
        history,
        session_id,
        count_primary_user_turns=count_primary_user_turns,
        update_compact_meter=update_compact_meter,
        compact_trigger_chars=compact_trigger_chars,
        history_total_chars=history_total_chars,
        compact_trigger_messages=COMPACT_TRIGGER_MESSAGES,
        compact_keep_tail=COMPACT_KEEP_TAIL,
        ui_status_text=UI_STATUS_TEXT,
        set_status=update_status,
        render_log_line=render_log_line,
        color_plan=COLOR_PLAN,
        summarize_history=summarize_history,
        fallback_history_summary=fallback_history_summary,
        brief_model_error=brief_model_error,
        save_session=save_session,
        force=force,
    )


async def run_single_turn(task: str, *, session_id: str = "default", phase_change_callback: Any = None) -> None:
    """Bridge for mico/repl.py — runs one user turn with plain stdout output.

    Sets USE_PLAIN_STDOUT to bypass prompt_toolkit TUI and streams output to stdout.
    Caller (mico/repl.py) provides input. Output streams to stdout.

    Args:
        task: User prompt / task string
        session_id: Session identifier for history persistence
        phase_change_callback: Optional callable to notify of stream phase changes
    """
    global USE_PLAIN_STDOUT, _JSON_STREAM_FILTER, _PHASE_CHANGE_CALLBACK, _STREAMING_ACTIVE
    USE_PLAIN_STDOUT = True
    _STREAMING_ACTIVE = False  # reset at turn start
    _PHASE_CHANGE_CALLBACK = phase_change_callback
    # Her yeni turn'de önceki task state'i temizle — resume için /resume kullanılır
    task_state_path(session_id).unlink(missing_ok=True)
    # Initialize JSON stream filter for this turn
    try:
        from . import ui as mico_ui
        _JSON_STREAM_FILTER = mico_ui.JsonStreamFilter(on_phase_change=phase_change_callback, on_monologue_text=stream_monologue_text)
    except (ImportError, Exception):
        _JSON_STREAM_FILTER = None
    try:
        # Create a minimal ToolContext with sensible defaults
        import tempfile as _tempfile
        _tmp_paths = [Path(_tempfile.gettempdir()).resolve(strict=False), Path("/tmp")]
        ctx = ToolContext(
            cwd=Path.cwd(),
            approval="auto",
            force=False,
            mode="auto",
            narrate=False,  # No narration in REPL mode
            dry_run=RUNTIME_DRYRUN,
            profile=DEFAULT_PROFILE if DEFAULT_PROFILE in PROFILE_PRESETS else "balanced",
            network_access=DEFAULT_NETWORK_ACCESS,
            tool_install=DEFAULT_TOOL_INSTALL,
            unattended=False,
            permission_mode="balanced",
            force_model_mismatch=False,
            allowed_external_paths=_tmp_paths,
        )

        # Initialize audit logger
        try:
            from mico.audit import AuditLogger
            _audit_root = git_repo_root(ctx.cwd) or ctx.cwd
            ctx.audit_logger = AuditLogger(project_root=_audit_root)  # type: ignore[attr-defined]
            ctx.audit_logger.start(  # type: ignore[attr-defined]
                mode=ctx.mode or "auto",
                profile=ACTIVE_PROFILE.name if ACTIVE_PROFILE else "default",
            )
        except Exception:
            pass  # Audit logger is best-effort

        # Load or initialize history
        session_file = SESSIONS_DIR / f"{session_id}.json"
        history: list[dict[str, str]] | None = None
        if session_file.exists():
            try:
                history = load_session_history(session_file)
            except Exception:
                history = None  # Fallback to None (tool_loop will initialize)

        runtime_status_reset()
        runtime_status_turn_started()

        # Fast path for non-agentic tasks — skip tool_loop entirely
        task_kind = classify_task(task)
        if task_kind in ("trivial_chat", "brief_general"):
            # Fast-path: disable JSON filter and streaming so thinking is stripped from result.
            global STREAM_EXPECT_ACTION_JSON
            STREAM_EXPECT_ACTION_JSON = False
            _JSON_STREAM_FILTER = None
            try:
                if task_kind == "trivial_chat":
                    sys_content = (
                        "Sen mico adında yerel bir kodlama asistanısın. "
                        "Kullanıcı hangi dilde yazıyorsa MUTLAKA o dilde cevap ver. "
                        "Türkçe mesaja Türkçe, İngilizce mesaja İngilizce cevap ver. "
                        "Kısa ve samimi cevap ver. Araç kullanma."
                    )
                    fallback = "Merhaba!"
                else:
                    sys_content = (
                        "Sen mico adında yerel bir kodlama asistanısın. "
                        "Kullanıcı hangi dilde yazıyorsa o dilde cevap ver. "
                        "Soruyu doğrudan ve özlü şekilde yanıtla. "
                        "Araç kullanma, dosya sistemi tarama."
                    )
                    fallback = ""

                messages = [
                    {"role": "system", "content": sys_content},
                    {"role": "user", "content": task},
                ]
                if history:
                    # Only inject clean user/assistant pairs — skip tool output and empty messages.
                    def _is_clean_fast(msg: dict) -> bool:
                        c = msg.get("content", "")
                        if not isinstance(c, str) or not c.strip():
                            return False
                        if c.startswith("exit_code=") or c.startswith("lint_warnings:"):
                            return False
                        if c.startswith("Runtime context:") or c.startswith("[ARCHITECT"):
                            return False
                        # Skip raw assistant JSON actions — only keep extracted final messages
                        if msg.get("role") == "assistant" and c.strip().startswith("{"):
                            import json as _json
                            try:
                                obj = _json.loads(c)
                                if obj.get("type") == "tool":
                                    return False
                            except Exception:
                                pass
                        return True
                    clean_history = [m for m in history if _is_clean_fast(m)]
                    recent = clean_history[-6:] if len(clean_history) > 6 else clean_history
                    messages = [messages[0]] + recent + [messages[1]]

                # For fast paths, cap total wait at ~30s: one attempt, no deep server restart loop.
                # If the server is restarting, wait up to 25s for it to become ready, then give up.
                _fast_result = None
                _server_wait_deadline = time.time() + 25
                while time.time() < _server_wait_deadline:
                    if MODEL_PROVIDER != "mlx" or expected_mlx_server_running():
                        break
                    await asyncio.sleep(1)
                try:
                    # stream=False: tam sonucu al, sonra strip_thinking ile thinking temizle.
                    # stream=True modunda tag'siz thinking (ThinkingProcess: ...) ekrana sızıyor.
                    reset_live_completion_metrics()
                    _fast_result = await call_model(messages, thinking_budget=None, stream=False, use_orchestra=False)
                except Exception:
                    _fast_result = None
                result = (_fast_result or "").strip()
                for _stop in ("<|im_end|>", "<|im_start|>", "<|endoftext|>"):
                    result = result.replace(_stop, "").strip()
                from .text_utils import strip_thinking as _strip_thinking
                result = _strip_thinking(result).strip()

                if not result:
                    result = fallback or ""

                # stream=False: result stream edilmedi, else branch'te stream_text ile basılır.
                _sp = _ACTIVE_SPINNER
                if _STREAMING_ACTIVE:
                    # streaming sırasında spinner pause'da kaldı — sadece newline + resume
                    try:
                        from . import ui as mico_ui
                        mico_ui.stream_text("\n")
                    except Exception:
                        sys.stdout.write("\n")
                        sys.stdout.flush()
                    if _sp is not None:
                        _sp.resume()
                else:
                    # Streaming hiç başlamadıysa (boş response) spinner'ı durdur
                    if _sp is not None:
                        _sp.pause()
                    if result:
                        try:
                            from . import ui as mico_ui
                            mico_ui.stream_text(result + "\n")
                        except Exception:
                            sys.stdout.write(result + "\n")
                            sys.stdout.flush()
                    if _sp is not None:
                        _sp.resume()

                if history is None:
                    history = []
                history.append({"role": "user", "content": task})
                history.append({"role": "assistant", "content": result})
                save_session(session_id, history)
                if RUNTIME_STATE is not None:
                    try:
                        RUNTIME_STATE.history_chars_used = history_total_chars(history)
                    except Exception:
                        pass
                return
            except Exception:
                pass  # Fall through to tool_loop on unexpected error

        # --- Görev triyajı (kural tabanlı, LLM çağrısı yok) ---
        if task_kind not in ("trivial_chat", "local_info", "brief_general"):
            try:
                from .triage import triage_task, format_reject_message
                triage = await triage_task(task, task_kind=task_kind)
                if triage.verdict == "reject":
                    msg = format_reject_message(triage.reason)
                    stream_stdout(msg + "\n")
                    if history is not None:
                        history.append({"role": "user", "content": task})
                        history.append({"role": "assistant", "content": msg})
                        save_session(session_id, history)
                    return
            except Exception:
                pass  # Triage hatası → normal akış

        # Run the tool loop for this turn
        result, updated_history = await tool_loop(task, ctx, session_id, history)

        # Update ctx meter with final history size after tool loop
        if RUNTIME_STATE is not None and updated_history is not None:
            try:
                RUNTIME_STATE.history_chars_used = history_total_chars(updated_history)
            except Exception:
                pass

        # Reset stream filter state; recover any leftover buffered text
        _filter_showed_message = False
        if _JSON_STREAM_FILTER is not None:
            _leftover = _JSON_STREAM_FILTER.finalize()
            _filter_showed_message = getattr(_JSON_STREAM_FILTER, "message_shown", False)
            if _leftover and not result:
                result = _leftover
            # Fallback: model produced plain prose without JSON envelope (e.g. Gemma-4)
            if not result and not _filter_showed_message:
                _prose = _JSON_STREAM_FILTER.get_prose_fallback()
                if _prose:
                    result = _prose
        # Print final result (skip if filter already streamed it live — avoids double output)
        _sp = _ACTIVE_SPINNER
        # If streaming never started (e.g. empty fast-path result), pause now to clear line.
        if _sp is not None and not _STREAMING_ACTIVE:
            _sp.pause()
        _STREAMING_ACTIVE = False
        try:
            from . import ui as mico_ui
            if not _filter_showed_message:
                if result:
                    mico_ui.stream_text(result + "\n")
                else:
                    mico_ui.stream_text("\n")
            else:
                # Filter already printed the message live; just add trailing newline
                mico_ui.stream_text("\n")
        except Exception:
            sys.stdout.write((result + "\n") if result else "\n")
            sys.stdout.flush()
        finally:
            if _sp is not None:
                _sp.resume()

        # Ensure audit logger is finished
        try:
            if hasattr(ctx, 'audit_logger') and ctx.audit_logger:
                ctx.audit_logger.finish(status="ok")  # type: ignore[attr-defined]
        except Exception:
            pass
    finally:
        USE_PLAIN_STDOUT = False
        _JSON_STREAM_FILTER = None
        _STREAMING_ACTIVE = False


async def tool_loop(
    task: str,
    ctx: ToolContext,
    session_id: str,
    history: list[dict[str, str]] | None = None,
) -> tuple[str, list[dict[str, str]]]:
    try:
        global STOP_REQUESTED
        reset_turn_metrics()
        original_task = task
        requested_mode = ctx.mode
        effective_mode = resolve_mode_for_task(task, ctx)
        if effective_mode != ctx.mode:
            ctx = ToolContext(
                cwd=ctx.cwd,
                approval=ctx.approval,
                force=ctx.force,
                mode=effective_mode,
                narrate=ctx.narrate,
                dry_run=ctx.dry_run,
                profile=ctx.profile,
                network_access=ctx.network_access,
                tool_install=ctx.tool_install,
                allowed_external_paths=list(ctx.allowed_external_paths),
            )
            render_log_line("plan", f"auto mode: {requested_mode} -> {effective_mode}", COLOR_PLAN)
        system_prompt = build_system_prompt(task, ctx)
        task_kind = classify_task(task)
        goal_tag = task_goal_tag(task)
        use_orchestra = task_uses_orchestra(task, ctx)
        state = load_task_state(session_id, task, ctx)
        if state.goal.strip() != extract_task_body(task).strip() and history is None:
            state.goal = extract_task_body(task).strip()
        state.mode = ctx.mode
        state.task_kind = task_kind
        state.current_mode = effective_mode
        state.user_goal = extract_task_body(task).strip()
        state.active_model_profile = ACTIVE_PROFILE.name if ACTIVE_PROFILE else "default"
        answered_goals: set[str] = set()
        record_orchestra_trace(task_kind=task_kind, goal_tag=goal_tag, mode=ctx.mode, requested_mode=requested_mode, enabled=use_orchestra)
        skill_notes = render_skill_notes(task, ctx)
        if history is None:
            effective_mode = resolve_mode_for_task(task, ctx)
            runtime_note = (
                compact_runtime_context_text(ctx)
                if task_needs_memory_guard(task, ctx)
                else runtime_context_text(ctx, effective_mode=effective_mode)
            )
            history = [{"role": "user", "content": runtime_note}]
            startup_notes = load_startup_notes(ctx, task)
            if startup_notes:
                history.append({"role": "user", "content": startup_notes})
            if skill_notes:
                history.append({"role": "user", "content": skill_notes})
            from .task_envelope import build_task_envelope
            _envelope = build_task_envelope(
                task,
                task_kind,
                goal_tag,
                cwd=str(ctx.cwd) if hasattr(ctx, "cwd") else None,
            )
            history.append({"role": "user", "content": _envelope})
            if task_needs_planning(task):
                history.append(planning_hint_message())
            task_cls = classify_task(task)
            cwd_path = Path(ctx.cwd) if hasattr(ctx, 'cwd') else Path.cwd()
            if str(cwd_path) in {str(Path.home()), "/"} and task_cls not in {"trivial_chat", "local_info"} and task_needs_planning(task):
                history.append({
                    "role": "user",
                    "content": (
                        "Çalışma dizini ev klasörü ($HOME). Kod yazmadan önce kullanıcıya sor: "
                        "'Hangi dizinde çalışayım? örn: ~/projects/<isim>'. "
                        "Final dön ve cevap bekle. Hiçbir dosya yazma."
                    ),
                })
        else:
            if skill_notes:
                history.append({"role": "user", "content": skill_notes})
            history.append({"role": "user", "content": task})
        apply_task_memory_guard(task, ctx, history)
        if use_orchestra:
            architect = await request_architect_handoff(task, ctx, state,
                active_profile=ACTIVE_PROFILE,
                resolve_role_model=resolve_role_model,
                extract_task_body=extract_task_body,
                build_task_state_prompt=build_task_state_prompt,
                build_system_prompt=build_system_prompt,
                call_model=call_model,
                min_thinking_budget=MIN_THINKING_BUDGET,
                extract_json=extract_json,
                truncate=truncate,
                render_log_line=render_log_line,
                color_plan=COLOR_PLAN
            )
            if architect:
                if architect.get("summary"):
                    state.decisions.append(f"architect: {architect['summary']}")
                if architect.get("plan"):
                    state.current_plan = architect["plan"]
                if architect.get("files"):
                    state.selected_files = dedupe_keep_order(state.selected_files + architect["files"])
                if architect.get("risks"):
                    state.open_questions.extend(architect["risks"])
                if architect.get("pending_tasks"):
                    state.pending_tasks = dedupe_keep_order(state.pending_tasks + architect["pending_tasks"])
                history.append(
                    {
                        "role": "system",
                        "content": (
                            "[ARCHITECT HANDOFF]\n"
                            + json.dumps(architect, ensure_ascii=False)
                            + "\nUse this as planning metadata only. Do not echo it."
                        ),
                    }
                )
        # preflight before first real edit
        if not getattr(ctx, '_preflight_done', False):
            ctx._preflight_done = True  # type: ignore[attr-defined]
            try:
                from mico.preflight import run_preflight
                _pf = run_preflight(ctx, task=task, cwd=ctx.cwd if hasattr(ctx, 'cwd') else Path.cwd())
                if not _pf.ready and _pf.warnings:
                    for _w in _pf.warnings:
                        console.print(f"[yellow]preflight:[/yellow] {_w}")
            except Exception:
                pass  # preflight is best-effort, never block the loop
        save_task_state(state)
        history = await maybe_compact_history(history, session_id)
        save_session(session_id, history)
        action_history: list[str] = []
        tool_feedback_history: list[str] = []
        inspection_history: list[str] = []
        consecutive_reads = 0
        invalid_action_streak = 0
        blocked_tool_family = ""
        blocked_tool_violations = 0  # how many times model ignored the block

        _max_steps = EFFORT_MAX_ITERATIONS
        for step in range(1, _max_steps + 1):
            # Step limiti yaklaşınca modele uyar
            remaining = _max_steps - step + 1
            if remaining <= 5 and remaining > 0:
                # Uyarıyı bir kez ver (tam 5 kaldığında)
                if remaining == 5:
                    history.append({
                        "role": "user",
                        "content": "SİSTEM: Yalnızca 5 adım kaldı. Hemen sonuca git ve final action döndür."
                    })
                    history = await maybe_compact_history(history, session_id)
                    save_session(session_id, history)

            # Force compact if history is large — prevents OOM on local models (27B+)
            _hard_compact_limit = HISTORY_COMPACT_CHAR_TRIGGER * 2
            if history_total_chars(history) > _hard_compact_limit:
                history = await maybe_compact_history(history, session_id, force=True)

            # Update ctx% meter so the toolbar reflects live usage during long tool chains
            if RUNTIME_STATE is not None:
                try:
                    RUNTIME_STATE.history_chars_used = history_total_chars(history)
                except Exception:
                    pass

            if CANCEL_REQUESTED.is_set() or STOP_REQUESTED:
                return ("Cancelled.", history)
            current_phase_entry(state)
            if not USE_PLAIN_STDOUT:
                render_log_line(f"step {step:03d}", color=COLOR_MODEL)
            if task_kind == "local_info" and step == 1 and goal_tag:
                action = preferred_local_info_action(goal_tag)
                raw_to_store = json.dumps(action, ensure_ascii=False)
                record_orchestra_trace(local_info_shortcut=True)
                if not USE_PLAIN_STDOUT:
                    render_log_line("model", "local info shortcut", COLOR_PLAN)
                history.append({"role": "assistant", "content": assistant_safe_text(raw_to_store)})
                history = await maybe_compact_history(history, session_id)
                save_session(session_id, history)
                if goal_tag:
                    state.decisions.append(f"Used local info shortcut for goal `{goal_tag}`.")
                    state.next_step = "Run the shortcut tool once, then return a direct final answer."
            else:
                effective_budget = compute_thinking_budget(history, ctx, step, consecutive_reads)
                if THINKING:
                    if not USE_PLAIN_STDOUT:
                        render_log_line("model", f"thinking  budget={effective_budget}", COLOR_PLAN)
                    update_status("thinking")
                else:
                    update_status("calisiyor")
                if not USE_PLAIN_STDOUT:
                    render_log_line("model", "streaming response", COLOR_PLAN)
                try:
                    retrieval_prompt = build_retrieval_prompt(task, history, state)
                    context_block = build_task_state_prompt(state) + "\n\n" + retrieval_prompt
                    
                    raw = await call_model(
                        assistant_messages(
                            system_prompt,
                            history,
                            context_block,
                        ),
                        thinking_budget=effective_budget,
                        stream=True,
                        use_orchestra=use_orchestra,
                    )
                except ModelStreamCancelled:
                    return ("Cancelled.", history)
                except Exception as exc:
                    brief_exc = brief_model_error(exc)
                    recovery_message = (
                        "Model backend error. Session saved at the last good step.\n"
                        "Resume this session and say `continue` to keep going.\n\n"
                        f"{brief_exc}\n\n"
                        + build_recovery_prompt("model_timeout", task=task, state=state, details=brief_exc)
                    )
                    history.append({"role": "user", "content": history_safe_text(recovery_message)})
                    history = await maybe_compact_history(history, session_id)
                    save_session(session_id, history)
                    return (recovery_message, history)

                # Boş cevap kontrolü — boşsa empty final, retry'a girme
                if not raw or not raw.strip():
                    action = {"type": "final", "message": ""}
                    raw_to_store = json.dumps(action, ensure_ascii=False)
                else:
                    try:
                        update_status("parsing action")
                        if not USE_PLAIN_STDOUT:
                            render_log_line("model", "parsing action", COLOR_PLAN)
                        action = extract_json(raw)
                        action = coerce_local_info_action(action, goal_tag)
                        runtime_status_set("tool selected", str(action.get("tool") or action.get("type") or "action"))
                        valid_action, action_error = validate_action(action)
                        if not valid_action:
                            raise ValueError(action_error)
                        raw_to_store = json.dumps(action, ensure_ascii=False)
                    except Exception as exc:
                        invalid_action_streak += 1
                        record_orchestra_trace(invalid_action_streak=invalid_action_streak)
                        try:
                            action, repaired_raw = await repair_action_response(raw, history, task_state_summary=build_task_state_prompt(state))
                            action = coerce_local_info_action(action, goal_tag)
                            valid_action, action_error = validate_action(action)
                            if not valid_action:
                                raise ValueError(action_error)
                            raw_to_store = json.dumps(action, ensure_ascii=False)
                            record_orchestra_trace(repair_used=True)
                            # Internal repair — don't surface to user
                        except Exception as repair_exc:
                            parser_error = brief_model_error(exc) if isinstance(exc, Exception) else truncate(str(exc), 280)
                            repair_error = brief_model_error(repair_exc)
                            msg = (
                                "Invalid model action. Return exactly one JSON action object. "
                                "Do not include prose or markdown."
                            )
                            if invalid_action_streak >= 2:
                                msg += " Strategy reset: choose one different tool or return final."
                            msg += f"\nParser error: {parser_error}"
                            msg += f"\nRepair error: {repair_error}"
                            msg += "\n\n" + build_recovery_prompt("malformed_json", task=task, state=state, details=parser_error)
                            history.append({"role": "user", "content": history_safe_text(msg)})
                            history = await maybe_compact_history(history, session_id)
                            save_session(session_id, history)
                            continue

                invalid_action_streak = 0
                record_orchestra_trace(invalid_action_streak=0)
                history.append({"role": "assistant", "content": assistant_safe_text(raw_to_store)})
                history = await maybe_compact_history(history, session_id)
                save_session(session_id, history)

            if action.get("type") == "final":
                message = action.get("message", "").strip()
                phase = current_phase_entry(state)

                # Empty/broken final recovery: if message is empty or whitespace-only, request retry
                if not message:
                    history.append(
                        {
                            "role": "user",
                            "content": (
                                "Final response was empty or missing a message. "
                                "Provide a concrete answer with the result from tool output above. "
                                'Return JSON: {"type":"final","message":"<your answer here>"}'
                            ),
                        }
                    )
                    history = await maybe_compact_history(history, session_id)
                    save_session(session_id, history)
                    continue

                if str(phase.get("name", "")) not in {"finalize", "final", "answer"} and not task_prefers_brief_answer(original_task):
                    # Accept early if step_N phase or verify/check phase already produced file output and message is clean.
                    _files_written = [p for p in state.files_touched if p]
                    _verify_phase = str(phase.get("name", "")).lower() in {"verify", "check", "validate", "test", "run"}
                    _step_file_done = (
                        (explicit_step_phase_active(state) or (_verify_phase and bool(_files_written)))
                        and bool(_files_written)
                        and not is_inline_code_heavy_final(message)
                    )
                    if not _step_file_done:
                        if resolve_mode_for_task(original_task, ctx) == "code" and is_inline_code_heavy_final(message):
                            history.append(
                                {
                                    "role": "user",
                                    "content": (
                                        "Code mode guard: uzun kodu chat'e yazma. "
                                        "Do NOT paste code in final. Use write_file veya replace_in_file ile dosyaya uygula, "
                                        "ardindan sadece kisa ozet + dosya yolu dondur."
                                    ),
                                }
                            )
                            history = await maybe_compact_history(history, session_id)
                            save_session(session_id, history)
                            continue
                        # Circuit breaker for final-rejection doom loops.
                        excerpt = re.sub(r"\s+", " ", message)[:160].lower()
                        similar = bool(
                            state.last_rejected_final_excerpt
                            and (
                                excerpt == state.last_rejected_final_excerpt
                                or excerpt.startswith(state.last_rejected_final_excerpt[:80])
                                or state.last_rejected_final_excerpt.startswith(excerpt[:80])
                            )
                        )
                        looks_truncated = any(
                            marker in message.lower()
                            for marker in ("truncat", "cut off", "cut-off", "kesild", "yarıda kal")
                        )
                        state.rejected_final_attempts += 1
                        state.last_rejected_final_excerpt = excerpt
                        # Fire on: (3 similar/truncated) OR (5 any — model varied messages but still looping)
                        hard_limit = state.rejected_final_attempts >= 5
                        soft_limit = state.rejected_final_attempts >= 3 and (similar or looks_truncated)
                        if hard_limit or soft_limit:
                            promote_note = auto_promote_model_if_needed(state, "doom_loop_bailout_risk")
                            if promote_note:
                                history.append(
                                    {
                                        "role": "user",
                                        "content": (
                                            f"{promote_note}\n"
                                            "Retry now with write_file/replace_in_file flow; do not return final yet."
                                        ),
                                    }
                                )
                                state.rejected_final_attempts = 0
                                state.last_rejected_final_excerpt = ""
                                save_task_state(state)
                                history = await maybe_compact_history(history, session_id)
                                save_session(session_id, history)
                                continue
                            # Bail out cleanly instead of burning more cycles.
                            bail_msg = (
                                f"Doom-loop detected: {state.rejected_final_attempts} rejected final attempts. "
                                "The agent could not satisfy phase discipline for "
                                f"`{phase.get('name')}`. "
                                "Stopping. Tip: if the script is already written to a file, just return "
                                "final with the file path and a one-line summary — do not re-read or re-run."
                            )
                            render_log_line("agent", bail_msg, COLOR_PLAN)
                            state.status = "bailed"
                            state.next_step = "Re-run with /model-profile deep, or simplify the task."
                            save_task_state(state)
                            set_turn_stop_reason("doom_loop_bailout")
                            history.append({"role": "user", "content": bail_msg})
                            save_session(session_id, history)
                            return f"[{state.status}] {bail_msg}", history
                        phase_goal_hint = str(phase.get("goal", phase.get("title", phase.get("name", ""))))
                        coaching = (
                            f"Phase discipline: current phase `{phase.get('name')}` is still active. "
                            "Do not finalize yet. Complete the phase goal or produce verification first."
                        )
                        if explicit_step_phase_active(state):
                            # Explicit step mode: guide the model toward what counts as done.
                            files_written = [p for p in state.files_touched if p]
                            if files_written:
                                coaching += (
                                    f"\n\nA file was already written ({files_written[-1]}). "
                                    "If the step goal is met by that file, return final with just "
                                    "the file path and a one-line summary of what it does. "
                                    "Do NOT re-read, re-run, or add more explanation."
                                )
                            else:
                                coaching += (
                                    f"\n\nStep goal: {phase_goal_hint}\n"
                                    "Use write_file to create or update the target file, then "
                                    "return final with the file path and a one-line summary."
                                )
                        elif looks_truncated:
                            coaching += (
                                "\n\nYour previous attempt looks truncated. Do NOT paste the script "
                                "in the chat. Use the write_file tool to put the code in an actual "
                                "file under the working directory, then return final with just a "
                                "short summary and the file path."
                            )
                        history.append({"role": "user", "content": coaching})
                        history = await maybe_compact_history(history, session_id)
                        save_session(session_id, history)
                        continue
                # Reaching the success branch resets the circuit-breaker counter.
                state.rejected_final_attempts = 0
                state.last_rejected_final_excerpt = ""
                if is_low_signal_final(message) and not task_prefers_brief_answer(original_task):
                    history.append(
                        {
                            "role": "user",
                            "content": (
                                "Final answer was empty or placeholder-like. "
                                "Return a concrete answer with the actual result, summary, or findings. "
                                "Do not return '...', 'TBD', or similar filler."
                            ),
                        }
                    )
                    history = await maybe_compact_history(history, session_id)
                    save_session(session_id, history)
                    continue
                state.status = "completed"
                phase["status"] = "done"
                state.decisions.append("Returned a final answer based on the latest verified context.")
                state.next_step = "No further action required."
                save_task_state(state)
                set_turn_stop_reason("model_returned_final")
                if not USE_PLAIN_STDOUT:
                    render_log_line("agent", "final", COLOR_RESULT)
                # Capture optional structured fields from the final action.
                global LAST_FINAL_PAYLOAD
                structured_keys = ("summary", "changed_files", "added_files", "deleted_files",
                                   "tests", "review", "next_steps", "commit_suggestion")
                payload: dict[str, Any] = {}
                for key in structured_keys:
                    if key in action and action.get(key) not in (None, "", [], {}):
                        payload[key] = action.get(key)
                if not payload.get("summary"):
                    payload["summary"] = message
                # Auto-derive changed files from git when the model didn't provide them.
                try:
                    payload = auto_enrich_final_payload(payload, ctx.cwd)
                except Exception:
                    pass
                # Only treat as structured if there's more than just a summary.
                reviewer_note = ""
                if use_orchestra:
                    reviewer_note = await request_reviewer_note(task, ctx, state,
                        test_summary=state.test_result,
                        active_profile=ACTIVE_PROFILE,
                        resolve_role_model=resolve_role_model,
                        extract_task_body=extract_task_body,
                        git_diff_patch=git_diff_patch,
                        truncate=truncate,
                        request_role_action=request_role_action,
                        render_log_line=render_log_line,
                        color_plan=COLOR_PLAN
                    )
                    if reviewer_note:
                        payload["review"] = reviewer_note
                        state.decisions.append(f"reviewer: {truncate(reviewer_note, 220)}")
                if any(k in payload for k in structured_keys if k != "summary"):
                    LAST_FINAL_PAYLOAD = payload
                else:
                    LAST_FINAL_PAYLOAD = None
                if reviewer_note and message:
                    message = f"{message}\n\nReview:\n- {reviewer_note}"
                history = await maybe_compact_history(history, session_id)
                save_session(session_id, history)
                return (message or "Done.", history)

            if action.get("type") == "patch":
                diff = action.get("diff", "").strip()
                if not diff:
                    history.append({"role": "user", "content": "Patch action missing diff."})
                    history = await maybe_compact_history(history, session_id)
                    save_session(session_id, history)
                    continue
                # Always persist for audit trail.
                patch_path = save_patch(session_id, diff)
                render_log_line("agent", f"patch saved {patch_path.name}", COLOR_RESULT)
                # Strict permission mode: require confirmation before touching files.
                effective_perm = "yolo" if getattr(ctx, "unattended", False) else getattr(ctx, "permission_mode", "balanced")
                if effective_perm == "strict" and not getattr(ctx, "unattended", False):
                    try:
                        preview_plan = _validate_patch_pipeline(diff, ctx.cwd)
                    except PatchError as preview_err:
                        prompt_msg = _patch_recovery_prompt(preview_err)
                        render_log_line("agent", f"patch pre-validate failed: {type(preview_err).__name__}", COLOR_ERROR)
                        history.append({
                            "role": "user",
                            "content": f"patch_failed: {type(preview_err).__name__}\n{prompt_msg}",
                        })
                        history = await maybe_compact_history(history, session_id)
                        save_session(session_id, history)
                        continue
                    if not Prompt.ask(
                        f"Apply patch? {preview_plan.summary()} (y/N)",
                        default="n",
                    ).lower().startswith("y"):
                        history.append({
                            "role": "user",
                            "content": "Patch declined by user. Stop or revise the change.",
                        })
                        history = await maybe_compact_history(history, session_id)
                        save_session(session_id, history)
                        continue
                # Apply (unattended/balanced/yolo all auto-apply when pre-validate passes).
                try:
                    plan = _apply_patch_pipeline(diff, ctx.cwd)
                except PatchError as patch_err:
                    err_name = type(patch_err).__name__
                    excerpts: dict[str, str] = {}
                    target_path = getattr(patch_err, "path", None)
                    if target_path:
                        try:
                            full = ctx.cwd / target_path
                            if full.exists() and full.is_file():
                                text = full.read_text(errors="replace")
                                lines_ = text.splitlines()[:80]
                                excerpts[target_path] = "\n".join(lines_)
                        except OSError:
                            pass
                    prompt_msg = _patch_recovery_prompt(patch_err, file_excerpts=excerpts or None)
                    render_log_line("agent", f"patch failed: {err_name}", COLOR_ERROR)
                    history.append({
                        "role": "user",
                        "content": f"patch_failed: {err_name}\n{prompt_msg}",
                    })
                    history = await maybe_compact_history(history, session_id)
                    save_session(session_id, history)
                    continue
                # Success: report applied files + git diff summary.
                try:
                    summary = git_diff_summary(ctx.cwd)
                except Exception:
                    summary = ""
                changed_paths = [change.path for change in plan.files]
                state.selected_files = dedupe_keep_order(state.selected_files + changed_paths)
                state.files_touched = dedupe_keep_order(state.files_touched + changed_paths)
                render_log_line("agent", f"patch applied: {plan.summary()}", COLOR_RESULT)
                ok_tests, test_summary = await run_auto_test_fix_loop(
                    task,
                    ctx,
                    session_id,
                    state,
                    history,
                    max_attempts=max_fix_loops_for_context(ctx),
                )
                reviewer_note = request_reviewer_note(task, ctx, state, test_summary) if use_orchestra else ""
                if reviewer_note:
                    state.decisions.append(f"reviewer: {truncate(reviewer_note, 220)}")
                save_task_state(state)
                history.append({
                    "role": "user",
                    "content": (
                        f"patch_applied: {plan.summary()}\n"
                        f"saved={patch_path}\n"
                        + (f"git_status:\n{summary}\n" if summary else "")
                        + (f"test_result:\n{test_summary}\n" if test_summary else "")
                        + (f"review_result:\n{reviewer_note}\n" if reviewer_note else "")
                        + ("Return final unless more work is required." if ok_tests else "Tests still fail; fix the failing path or return a blocker summary.")
                    ),
                })
                history = await maybe_compact_history(history, session_id)
                save_session(session_id, history)
                continue

            if action.get("type") != "tool":
                history.append({"role": "user", "content": "Invalid action type. Use tool or final."})
                history = await maybe_compact_history(history, session_id)
                save_session(session_id, history)
                continue

            current_family = tool_family(action)
            if should_force_finalize_on_stale_audit(state, action):
                message = synthesize_state_final(state, ctx)
                phase = current_phase_entry(state)
                state.status = "completed"
                phase["status"] = "done"
                state.decisions.append("Stopped after stale audit evidence repeated in finalize phase.")
                state.next_step = "No further action required."
                save_task_state(state)
                set_turn_stop_reason("stale_audit_finalize_forced_final")
                history.append({"role": "assistant", "content": assistant_safe_text(json.dumps({"type": "final", "message": message}, ensure_ascii=False))})
                history = await maybe_compact_history(history, session_id)
                save_session(session_id, history)
                return (message, history)
            if blocked_tool_family and current_family == blocked_tool_family:
                phase = current_phase_entry(state)
                if (
                    state_dispatch_mode(state) == "audit"
                    and str(phase.get("name", "")) in {"assess", "finalize"}
                    and not audit_task_requires_followthrough(state.goal)
                ):
                    message = synthesize_state_final(state, ctx)
                    state.status = "completed"
                    phase["status"] = "done"
                    state.decisions.append("Stopped after repeated blocked tool family and returned evidence summary.")
                    state.next_step = "No further action required."
                    save_task_state(state)
                    set_turn_stop_reason("blocked_tool_family_forced_final")
                    history.append({"role": "assistant", "content": assistant_safe_text(json.dumps({"type": "final", "message": message}, ensure_ascii=False))})
                    history = await maybe_compact_history(history, session_id)
                    save_session(session_id, history)
                    return (message, history)
                if state_dispatch_mode(state) == "audit" and str(phase.get("name", "")) in {"assess", "finalize"}:
                    history.append(
                        {
                            "role": "user",
                            "content": (
                                "You already have the core evidence for this target. "
                                "Do not reread the same page again. Move to the next requested deliverable "
                                "or explain the blocker explicitly."
                            ),
                        }
                    )
                    blocked_tool_family = ""
                    record_orchestra_trace(blocked_tool_family=blocked_tool_family, guard="audit_followthrough_continue")
                    history = await maybe_compact_history(history, session_id)
                    save_session(session_id, history)
                    continue
                blocked_tool_violations += 1
                if blocked_tool_violations >= 3:
                    # Model repeatedly ignored the block — force final
                    message = (
                        "Görev tamamlanamadı: aynı araç ailesi tekrar tekrar denendi "
                        "ve sonuç alınamadı. Lütfen farklı bir yaklaşım veya ek bilgi ile tekrar deneyin."
                    )
                    state.status = "completed"
                    set_turn_stop_reason("blocked_tool_family_forced_final")
                    history.append({"role": "assistant", "content": assistant_safe_text(json.dumps({"type": "final", "message": message}, ensure_ascii=False))})
                    history = await maybe_compact_history(history, session_id)
                    save_session(session_id, history)
                    return (message, history)
                history.append(
                    {
                        "role": "user",
                        "content": (
                            "Strategy reset is active. Do not repeat the same tool family again. "
                            "Use read_file, grep_code, or return final."
                        ),
                    }
                )
                record_orchestra_trace(blocked_tool_family=blocked_tool_family)
                history = await maybe_compact_history(history, session_id)
                save_session(session_id, history)
                continue

            if is_duplicate_goal_attempt(action, answered_goals):
                history.append(
                    {
                        "role": "user",
                        "content": (
                            "You already collected the key fact needed for this task. "
                            "Do not run another tool for the same goal. Return final now."
                        ),
                    }
                )
                record_orchestra_trace(guard="duplicate_goal_attempt_blocked")
                set_turn_stop_reason("duplicate_goal_attempt_blocked")
                history = await maybe_compact_history(history, session_id)
                save_session(session_id, history)
                continue

            artifact_reread_reason = redundant_artifact_read_reason(state, action)
            if artifact_reread_reason:
                history.append(
                    {
                        "role": "user",
                        "content": f"{artifact_reread_reason} {artifact_reread_guidance(state)}",
                    }
                )
                state.decisions.append(artifact_reread_reason)
                state.next_step = "Continue from existing artifact evidence without rereading it."
                save_task_state(state)
                record_orchestra_trace(guard="redundant_artifact_read_blocked")
                history = await maybe_compact_history(history, session_id)
                save_session(session_id, history)
                continue

            http_probe_reason = redundant_http_probe_reason(state, action)
            if http_probe_reason:
                history.append(
                    {
                        "role": "user",
                        "content": f"{http_probe_reason} {redundant_http_probe_guidance(state)}",
                    }
                )
                state.decisions.append(http_probe_reason)
                state.next_step = "Use existing portal evidence, then move to timing measurement or script generation."
                save_task_state(state)
                record_orchestra_trace(guard="redundant_http_probe_blocked")
                history = await maybe_compact_history(history, session_id)
                save_session(session_id, history)
                continue

            action_key = summarize_action(action)
            inspect_key = inspection_signature(action)
            action_history.append(action_key)
            if len(action_history) >= MAX_SAME_TOOL_REPEATS + 1 and all(
                item == action_key for item in action_history[-(MAX_SAME_TOOL_REPEATS + 1):]
            ):
                history.append(
                    {
                        "role": "user",
                        "content": (
                            "You are repeating the same step. Replan. "
                            "Either use a different tool or return final."
                        ),
                    }
                )
                blocked_tool_family = current_family
                record_orchestra_trace(blocked_tool_family=blocked_tool_family)
                history = await maybe_compact_history(history, session_id)
                save_session(session_id, history)
                continue
            if inspect_key:
                inspection_history.append(inspect_key)
                # Be more aggressive with read repetitions
                trigger_count = 3
                if inspect_key.startswith("read:"):
                    trigger_count = 2
                
                if len(inspection_history) >= trigger_count and all(item == inspect_key for item in inspection_history[-trigger_count:]):
                    history.append(
                        {
                            "role": "user",
                            "content": (
                                f"You already inspected {inspect_key} multiple times ({trigger_count}x). "
                                "Stop rereading the same target. Either move to a different file, "
                                "apply an edit, or return a final conclusion."
                            ),
                        }
                    )
                    blocked_tool_family = current_family
                    record_orchestra_trace(blocked_tool_family=blocked_tool_family, guard="repeated_inspection_target")
                    history = await maybe_compact_history(history, session_id)
                    save_session(session_id, history)
                    continue

            label = action.get("tool", "tool")
            turn_trace = get_turn_trace()
            usage_bucket = turn_trace.setdefault(
                "usage",
                {"prompt_tokens": 0, "completion_tokens": 0, "total_tokens": 0, "llm_seconds": 0.0, "calls": 0, "tool_calls": 0, "estimated": False},
            )
            usage_bucket["tool_calls"] = int(usage_bucket.get("tool_calls") or 0) + 1
            summary_title, summary_detail = summarize_tool_action(action)
            # In plain stdout mode, render_tool_call (below) handles display — skip this
            if not USE_PLAIN_STDOUT:
                render_log_line(
                    "read_file" if summary_title == "Explored" else "bash" if summary_title == "Ran" else "edit",
                    summary_detail,
                    COLOR_TOOL,
                )
            if ctx.narrate:
                render_log_line("narrate", narrate_tool_intent(action, ctx), COLOR_NARRATE)
            if label in {"read_file", "list_files"}:
                consecutive_reads += 1
            else:
                consecutive_reads = 0
            if label in {"read_file", "grep_code"}:
                blocked_tool_family = ""
            if consecutive_reads > MAX_CONSECUTIVE_READS:
                history.append(
                    {
                        "role": "user",
                        "content": (
                            "Too many consecutive inspection steps. "
                            "Return a conclusion, edit files, or run one targeted command."
                        ),
                    }
                )
                blocked_tool_family = current_family
                record_orchestra_trace(blocked_tool_family=blocked_tool_family)
                history = await maybe_compact_history(history, session_id)
                save_session(session_id, history)
                continue
            result = ""
            artifact: dict[str, Any] | None = None
            mark_pending_tool(state, action)
            save_task_state(state)
            save_session(session_id, history)
            try:
                if CANCEL_REQUESTED.is_set():
                    return ("Cancelled.", history)
                update_status(f"running {label}")
                if label == "write_file":
                    target = safe_path(action["path"], ctx.cwd)
                    before = target.read_text() if target.exists() else ""
                    after = action.get("content", "")
                    render_live_diff(target, before, after)
                elif label == "replace_in_file":
                    target = safe_path(action["path"], ctx.cwd)
                    before = target.read_text()
                    old = action["old"]
                    new = action["new"]
                    if old in before:
                        after = before.replace(old, new, 1)
                        render_live_diff(target, before, after)

                # Render tool call in plain stdout mode
                if USE_PLAIN_STDOUT:
                    _sp = _ACTIVE_SPINNER
                    try:
                        if _sp is not None:
                            _sp.pause()
                        from . import ui as mico_ui
                        mico_ui.render_activity(summary_title, summary_detail)
                    except Exception:
                        pass
                    finally:
                        if _sp is not None:
                            _sp.resume()

                result = await run_tool(action, ctx)
                artifact = record_artifact(
                    session_id,
                    label,
                    result,
                    metadata={"tool": label, "action": summarize_action(action), "error": False},
                )
                # Treat non-zero exit_code from bash as a soft error so the
                # consecutive_tool_errors counter fires coaching hints.
                _bash_failed = (
                    label == "bash"
                    and isinstance(result, str)
                    and result.startswith("exit_code=")
                    and not result.startswith("exit_code=0")
                )
                update_state_after_tool(state, action, result, artifact, error=_bash_failed)
                update_phase_after_tool(state, action, result, error=_bash_failed)
                clear_pending_tool(state, f"tool completed: {summarize_action(action)}")
                if _bash_failed:
                    state.consecutive_tool_errors += 1
                else:
                    state.consecutive_tool_errors = 0

                # Render tool output in plain stdout mode
                if USE_PLAIN_STDOUT:
                    _sp = _ACTIVE_SPINNER
                    try:
                        if _sp is not None:
                            _sp.pause()
                        from . import ui as mico_ui
                        mico_ui.render_tool_output(result, max_lines=15)
                    except Exception:
                        pass
                    finally:
                        if _sp is not None:
                            _sp.resume()

                tool_result = (
                    tool_result_history_text(label, result, original_task)
                    + f"\nArtifact: artifact://{artifact['id']} {artifact['path']}"
                )
                # Add coaching hints for consecutive bash failures
                if _bash_failed and state.consecutive_tool_errors == 2:
                    tool_result += (
                        "\n\n[COACHING] Aynı yaklaşımla 2 komut başarısız oldu. "
                        "Şimdi farklı bir strateji dene: ya farklı bir araç, ya farklı argümanlar, "
                        "ya da kullanıcıdan eksik bilgi iste (final ile)."
                    )
                if label in {"write_file", "replace_in_file"}:
                    ok_tests, test_summary = await run_auto_test_fix_loop(
                        task,
                        ctx,
                        session_id,
                        state,
                        history,
                        max_attempts=max_fix_loops_for_context(ctx),
                    )
                    if test_summary:
                        tool_result += f"\nTest result:\n{truncate(test_summary, 1800)}"
                    if not ok_tests:
                        tool_result += "\nTests still failing; apply a targeted fix on the reported failure path."
                tool_feedback_signature = f"{label}:ok:{truncate(summarize_tool_payload(label, result, goal_tag), 200)}"
                # In plain stdout mode, render_tool_output (above) already displayed result — skip duplicate
                if not USE_PLAIN_STDOUT:
                    preview = tool_output_preview(label, result)
                    if preview:
                        render_output_block("Output", preview)
                if ctx.narrate:
                    render_log_line("narrate", narrate_tool_result(label, result, False), COLOR_NARRATE)
            except Exception as exc:
                error_text = str(exc)

                # Render error in plain stdout mode
                if USE_PLAIN_STDOUT:
                    _sp = _ACTIVE_SPINNER
                    try:
                        if _sp is not None:
                            _sp.pause()
                        from . import ui as mico_ui
                        mico_ui.render_log("error", str(exc)[:200])
                    except Exception:
                        pass
                    finally:
                        if _sp is not None:
                            _sp.resume()

                artifact = record_artifact(
                    session_id,
                    f"{label}-error",
                    error_text,
                    metadata={"tool": label, "action": summarize_action(action), "error": True},
                )
                update_state_after_tool(state, action, error_text, artifact, error=True)
                update_phase_after_tool(state, action, error_text, error=True)
                clear_pending_tool(state, f"tool failed: {summarize_action(action)}")
                state.consecutive_tool_errors += 1
                tool_result = (
                    f"Tool error for {label}:\n{exc}\n"
                    "Replan with a platform-appropriate and task-relevant next step.\n"
                    + recovery_guidance_for_exception(task, state, exc)
                    + "\n"
                    f"Artifact: artifact://{artifact['id']} {artifact['path']}"
                )
                # FIX 4: Add coaching hint when 2 tools fail in a row
                if state.consecutive_tool_errors == 2:
                    tool_result += (
                        "\n\n[COACHING] Aynı yaklaşımla 2 tool başarısız oldu. "
                        "Şimdi farklı bir strateji dene: ya farklı bir tool, ya farklı argümanlar, "
                        "ya da kullanıcıdan eksik bilgi iste (final ile)."
                    )
                if state.consecutive_tool_errors >= 3:
                    promote_note = auto_promote_model_if_needed(state, "repeated_tool_errors")
                    if promote_note:
                        tool_result += f"\n{promote_note}"
                    state.consecutive_tool_errors = 0
                tool_feedback_signature = f"{label}:error:{type(exc).__name__}:{truncate(str(exc), 160)}"
                if not USE_PLAIN_STDOUT:
                    render_output_block("Error", truncate(str(exc), 2500), "red")
                else:
                    # In REPL mode, show error inline as a log line
                    _sp = _ACTIVE_SPINNER
                    try:
                        if _sp is not None:
                            _sp.pause()
                        from . import ui as _mico_ui
                        _mico_ui.render_error(truncate(str(exc), 200))
                    except Exception:
                        pass
                    finally:
                        if _sp is not None:
                            _sp.resume()
                if ctx.narrate:
                    render_log_line("narrate", narrate_tool_result(label, str(exc), True), COLOR_ERROR)

            tool_feedback_history.append(tool_feedback_signature)
            if len(tool_feedback_history) >= 2 and tool_feedback_history[-1] == tool_feedback_history[-2]:
                tool_result += (
                    "\nStrategy reset required: do not repeat the same failing step. "
                    "Use a different tool, change the target/arguments, or return final."
                )
                if ":error:" in tool_feedback_history[-1]:
                    tool_result += (
                        "\n"
                        + build_recovery_prompt(
                            "repeated_bad_fix",
                            task=task,
                            state=state,
                            details=tool_feedback_history[-1],
                        )
                    )
                blocked_tool_family = current_family
                record_orchestra_trace(blocked_tool_family=blocked_tool_family)
            if result and result_answers_goal(goal_tag, label, result):
                answered_goals.add(goal_tag)
                state.decisions.append(f"{label} produced evidence that directly answers goal `{goal_tag}`.")
                state.next_step = "Return a final answer unless the user explicitly requested more depth."
                record_orchestra_trace(answered_goal=goal_tag)
                set_turn_stop_reason(f"goal_answered:{goal_tag}")
                if task_prefers_brief_answer(original_task):
                    message = summarize_tool_payload(label, result, goal_tag)
                    state.status = "completed"
                    current_phase_entry(state)["status"] = "done"
                    state.decisions.append("Returned a direct final answer from local verified output.")
                    state.next_step = "No further action required."
                    save_task_state(state)
                    history.append({"role": "user", "content": history_safe_text(tool_result)})
                    compact_old_inspection_tool_results(history)
                    history = await maybe_compact_history(history, session_id)
                    save_session(session_id, history)
                    return (message, history)
                save_task_state(state)
                history.append({"role": "user", "content": history_safe_text(tool_result)})
                compact_old_inspection_tool_results(history)
                history = await maybe_compact_history(history, session_id)
                save_session(session_id, history)
                continue
            if step % VERIFIER_INTERVAL == 0 or (tool_feedback_history and ":error:" in tool_feedback_history[-1]):
                verifier = await run_verifier(state, history + [{"role": "user", "content": history_safe_text(tool_result)}], step)
                if verifier is not None:
                    state.verifier_notes.append(f"{verifier['status']}: {truncate(verifier.get('reason', ''), 220)}")
                    if verifier.get("next_focus"):
                        state.next_step = verifier["next_focus"]
                    if verifier["status"] == "loop_risk":
                        blocked_tool_family = current_family
                    if verifier["status"] == "done" and verifier.get("done"):
                        state.decisions.append("Verifier marked the task as ready for final response.")
                        tool_result += "\nVerifier: the task appears complete; return final unless the user explicitly asked for more."
                    elif verifier["status"] == "blocked":
                        tool_result += "\nVerifier: progress is blocked; choose a materially different next step or explain the blocker."
                    elif verifier["status"] == "loop_risk":
                        tool_result += "\nVerifier: loop risk detected; do not repeat the same strategy without new evidence."
            save_task_state(state)
            # Aynı tool result zaten history'nin sonundaysa tekrar ekleme
            _safe_result = history_safe_text(tool_result)
            if not history or history[-1].get("content") != _safe_result:
                history.append({"role": "user", "content": _safe_result})
            compact_old_inspection_tool_results(history)
            history = await maybe_compact_history(history, session_id)
            save_session(session_id, history)

            # Auto-promote inspect phase to next if direct-final goal detected
            phase = current_phase_entry(state)
            if phase.get("name") == "inspect" and (
                "direct final" in (state.next_step or "").lower()
                or "shortcut" in (state.next_step or "").lower()
            ):
                advance_phase(state, note="auto-promote after tool result for direct-final goal")
                save_task_state(state)

        return ("Stopped after maximum iterations.", history)
    finally:
        update_status("idle")


def interactive_chat(
    initial_prompt: str | None,
    ctx: ToolContext,
    session_id: str | None = None,
    history: list[dict[str, str]] | None = None,
) -> int:
    global console, UI_APP, UI_STATUS_LOGGING, UI_SPINNER_INDEX
    configure_readline()
    session_id = session_id or str(uuid.uuid4())
    # start audit logger
    try:
        from mico.audit import AuditLogger
        _audit_root = git_repo_root(ctx.cwd) or ctx.cwd
        ctx.audit_logger = AuditLogger(project_root=_audit_root)  # type: ignore[attr-defined]
        ctx.audit_logger.start(  # type: ignore[attr-defined]
            mode=ctx.mode or "auto",
            profile=ACTIVE_PROFILE.name if ACTIVE_PROFILE else "default",
        )
    except Exception:
        pass
    if MODEL_PROVIDER == "mlx" and not expected_mlx_server_running():
        try:
            from mico.model_recommender import Profile as _Profile
            _boot_profile = _Profile(
                name="boot",
                model_path=MODEL,
                draft_model_path=DRAFT_MODEL,
                num_draft_tokens=getattr(ACTIVE_PROFILE, "num_draft_tokens", 0) if ACTIVE_PROFILE else 0,
                context_window=getattr(ACTIVE_PROFILE, "context_window", 8192) if ACTIVE_PROFILE else 8192,
                max_tokens=getattr(ACTIVE_PROFILE, "max_tokens", 2048) if ACTIVE_PROFILE else 2048,
                prompt_cache_size=getattr(ACTIVE_PROFILE, "prompt_cache_size", 8) if ACTIVE_PROFILE else 8,
                prompt_cache_bytes=getattr(ACTIVE_PROFILE, "prompt_cache_bytes", "1GB") if ACTIVE_PROFILE else "1GB",
            )
            new_port = _server_start(_boot_profile, host=SERVER_HOST, backend="mlx")
            if new_port != PORT:
                import mico.cli as _self
                _self.PORT = new_port
                _self.API_BASE = f"http://{SERVER_HOST}:{new_port}/v1"
        except Exception as _e:
            render_log_line("server", f"MLX server başlatılamadı: {_e}", COLOR_ERROR)

    update_compact_meter(history or [])
    if not PROMPT_TOOLKIT_AVAILABLE:
        if initial_prompt is None and not history:
            render_welcome_panel()
        while True:
            if initial_prompt is not None:
                prompt = initial_prompt
                initial_prompt = None
            else:
                prompt = prompt_box_input(session_id, ctx)
                if prompt is None:
                    return 0
                if prompt == "__cancel__":
                    continue
                prompt = prompt.strip()
            if not prompt:
                continue
            if prompt.startswith("/"):
                keep_going, message, new_session_id, new_history = handle_chat_command(
                    prompt, session_id, history, ctx
                )
                if message and message.startswith("[PASTE_CLIPBOARD "):
                    pasted_text = message.split("\n", 1)[1] if "\n" in message else ""
                    line_count = pasted_text.count("\n") + 1 if pasted_text else 0
                    render_log_line("paste", f"captured {line_count} lines from clipboard", COLOR_EDIT)
                    render_log_line("ui", "working", COLOR_PLAN)
                    result, history = asyncio.run(tool_loop(mode_wrapped_task(pasted_text, ctx), ctx, session_id, history))
                    console.print(render_final_panel(result))
                    continue
                if message:
                    console.print(message)
                if new_session_id is not None:
                    session_id = new_session_id
                    history = new_history
                if not keep_going:
                    try:
                        if hasattr(ctx, 'audit_logger') and ctx.audit_logger:
                            ctx.audit_logger.finish(status="ok")
                    except Exception:
                        pass
                    return 0
                continue
            line_count = prompt.count("\n") + 1
            if line_count > 1:
                render_log_line("paste", f"captured {line_count} lines from prompt box", COLOR_EDIT)
            render_log_line("ui", "working", COLOR_PLAN)
            result, history = asyncio.run(tool_loop(mode_wrapped_task(prompt, ctx), ctx, session_id, history))
            console.print(render_final_panel(result))
        try:
            if hasattr(ctx, 'audit_logger') and ctx.audit_logger:
                ctx.audit_logger.finish(status="ok")
        except Exception:
            pass
        return 0

    original_console = console
    sink = OutputSink()
    ui_console = Console(file=sink, force_terminal=False, color_system=None, stderr=False)
    console = ui_console
    CANCEL_REQUESTED.clear()
    UI_STATUS_LOGGING = False
    # Clear terminal before TUI starts so the screen is clean
    try:
        sys.stdout.write("\033[2J\033[H")
        sys.stdout.flush()
    except Exception:
        pass
    if initial_prompt is None and not history:
        render_welcome_panel()

    async def ui_main() -> int:
        nonlocal session_id, history, initial_prompt

        history_state = InMemoryHistory()
        slash_completer = SlashCommandCompleter(SLASH_COMMANDS)
        output_area = TextArea(
            text="",
            scrollbar=True,
            wrap_lines=True,
            multiline=True,
            read_only=True,
            focusable=True,
            height=Dimension(min=5, weight=1),
            style="class:textarea",
            lexer=TranscriptLexer(),
        )
        output_area.buffer.enable_history_search = lambda: False
        input_area = TextArea(
            text="",
            wrap_lines=True,
            multiline=True,
            height=Dimension(min=3, max=8),
            history=history_state,
            style="class:textarea",
            completer=slash_completer,
            complete_while_typing=True,
            scrollbar=False,
        )
        input_area.buffer.enable_history_search = lambda: True
        busy = False
        follow_output = True
        app: Application | None = None

        def append_output(text: str) -> None:
            if not text:
                return
            sink.write(text)

        async def refresh_output() -> None:
            nonlocal follow_output
            last_text = ""
            while app is not None and app.is_running:
                text = sink.text()
                if text != last_text:
                    if output_area.buffer.selection_state is not None:
                        await asyncio.sleep(UI_REFRESH_INTERVAL)
                        continue
                    previous_cursor = output_area.buffer.cursor_position
                    previous_scroll = output_area.window.vertical_scroll if output_area.window is not None else 0
                    if follow_output:
                        # Follow tail: cursor at end → window auto-scrolls to bottom.
                        cursor_position = len(text)
                    else:
                        # User has scrolled up — anchor cursor to the logical line at the
                        # top of the visible viewport. We use render_info.first_visible_line()
                        # which gives the correct LOGICAL line regardless of wrap_lines=True
                        # (using previous_scroll directly would be a visual-vs-logical mismatch).
                        anchor_logical_line = 0
                        if (
                            output_area.window is not None
                            and output_area.window.render_info is not None
                        ):
                            try:
                                anchor_logical_line = output_area.window.render_info.first_visible_line()
                            except Exception:
                                anchor_logical_line = 0
                        anchor_doc = Document(text)
                        anchor_logical_line = min(anchor_logical_line, max(0, anchor_doc.line_count - 1))
                        try:
                            cursor_position = anchor_doc.translate_row_col_to_index(anchor_logical_line, 0)
                        except Exception:
                            cursor_position = min(previous_cursor, len(text))
                    output_area.buffer.set_document(
                        Document(text, cursor_position=cursor_position),
                        bypass_readonly=True,
                    )
                    if output_area.window is not None:
                        if follow_output and output_area.window.render_info:
                            output_area.window.vertical_scroll = max(
                                0,
                                output_area.window.render_info.content_height
                                - output_area.window.render_info.window_height
                                + 1,
                            )
                        else:
                            output_area.window.vertical_scroll = previous_scroll
                    last_text = text
                await asyncio.sleep(UI_REFRESH_INTERVAL)

        def scroll_output(lines: int) -> None:
            nonlocal follow_output
            if output_area.window is None:
                return
            new_scroll = max(0, output_area.window.vertical_scroll + lines)
            output_area.window.vertical_scroll = new_scroll
            # Re-engage tail-follow if the user has scrolled all the way back to
            # the bottom — matches the Claude Code feel ("scroll to the latest
            # message and you're live again").
            ri = output_area.window.render_info
            if ri is not None:
                # Use render_info's at_bottom check — reliable regardless of wrap_lines.
                follow_output = ri.full_height_visible or ri.last_visible_line() >= ri.content_height - 1
            else:
                follow_output = False

        def scroll_output_to_end() -> None:
            nonlocal follow_output
            follow_output = True
            if output_area.window is not None and output_area.window.render_info:
                output_area.window.vertical_scroll = max(
                    0,
                    output_area.window.render_info.content_height - output_area.window.render_info.window_height + 1,
                )

        async def refresh_spinner() -> None:
            global UI_SPINNER_INDEX
            while app is not None and app.is_running:
                if UI_STATUS_TEXT != "idle":
                    UI_SPINNER_INDEX = (UI_SPINNER_INDEX + 1) % len(UI_SPINNER_FRAMES)
                    if output_area.buffer.selection_state is None and input_area.buffer.selection_state is None:
                        app.invalidate()
                await asyncio.sleep(0.16)

        async def process_prompt(prompt: str) -> None:
            nonlocal session_id, history, busy
            try:
                reset_live_completion_metrics()
                # Claude Code tarzı kullanıcı turn gösterimi
                preview = prompt if len(prompt) <= 72 else prompt[:69] + "…"
                append_output(f"\n> {preview}\n\n")
                if prompt.startswith("/"):
                    keep_going, message, new_session_id, new_history = handle_chat_command(
                        prompt, session_id, history, ctx
                    )
                    if message and message.startswith("[PASTE_CLIPBOARD "):
                        pasted_text = message.split("\n", 1)[1] if "\n" in message else ""
                        line_count = pasted_text.count("\n") + 1 if pasted_text else 0
                        render_log_line("paste", f"captured {line_count} lines from clipboard", COLOR_EDIT)
                        render_log_line("ui", "working", COLOR_PLAN)
                        result, history = await tool_loop(
                            mode_wrapped_task(pasted_text, ctx),
                            ctx,
                            session_id,
                            history,
                        )
                        append_output(result.rstrip() + "\n")
                    elif message:
                        append_output(str(message).rstrip() + "\n")
                    if new_session_id is not None:
                        session_id = new_session_id
                        history = new_history
                    if not keep_going and app is not None:
                        app.exit(result=0)
                    return

                line_count = prompt.count("\n") + 1
                if line_count > 1:
                    render_log_line("paste", f"captured {line_count} lines from prompt box", COLOR_EDIT)
                render_log_line("ui", "working", COLOR_PLAN)
                result, history = await tool_loop(
                    mode_wrapped_task(prompt, ctx),
                    ctx,
                    session_id,
                    history,
                )
                append_output(result.rstrip() + "\n")
            finally:
                busy = False
                input_area.buffer.read_only = False
                CANCEL_REQUESTED.clear()
                update_status("idle")
                if app is not None:
                    app.invalidate()

        bindings = KeyBindings()

        @bindings.add("enter")
        def _submit(event) -> None:
            nonlocal busy
            if busy:
                return
            text = input_area.text.strip()
            if not text:
                return
            input_area.buffer.history.append_string(text)
            busy = True
            input_area.buffer.set_document(Document(text, len(text)), bypass_readonly=True)
            input_area.buffer.read_only = True
            update_status("working")
            event.app.invalidate()
            event.app.create_background_task(process_prompt(text))

        @bindings.add("escape", "enter")
        def _newline(event) -> None:
            input_area.buffer.insert_text("\n")

        @bindings.add("escape")
        def _cancel(event) -> None:
            if busy:
                CANCEL_REQUESTED.set()
                close_active_model_response()
                update_status("stopping")
                if app is not None:
                    app.invalidate()
            else:
                input_area.buffer.set_document(Document("", 0), bypass_readonly=True)

        @bindings.add("tab")
        def _indent(event) -> None:
            if event.app.current_buffer.complete_state:
                event.current_buffer.complete_next()
                return
            input_area.buffer.insert_text("    ")

        @bindings.add("pageup")
        def _pageup(event) -> None:
            scroll_output(-10)
            event.app.invalidate()

        @bindings.add("pagedown")
        def _pagedown(event) -> None:
            scroll_output(10)
            event.app.invalidate()

        @bindings.add("up")
        def _up(event) -> None:
            if event.app.layout.current_control == output_area.control:
                scroll_output(-1)
                event.app.invalidate()
                return
            buf = event.current_buffer
            # On the first line of input → go to previous history entry
            if buf.document.cursor_position_row == 0:
                buf.history_backward(count=event.arg)
            else:
                buf.auto_up(count=event.arg)

        @bindings.add("down")
        def _down(event) -> None:
            if event.app.layout.current_control == output_area.control:
                scroll_output(1)
                event.app.invalidate()
                return
            buf = event.current_buffer
            # On the last line of input → go to next history entry
            if buf.document.cursor_position_row == buf.document.line_count - 1:
                buf.history_forward(count=event.arg)
            else:
                buf.auto_down(count=event.arg)

        @bindings.add("home")
        def _home(event) -> None:
            scroll_output(-10_000)
            event.app.invalidate()

        @bindings.add("end")
        def _end(event) -> None:
            scroll_output_to_end()
            event.app.invalidate()

        @bindings.add("escape", "up")
        def _scroll_up_fast(event) -> None:
            scroll_output(-5)
            event.app.layout.focus(output_area)
            event.app.invalidate()

        @bindings.add("escape", "down")
        def _scroll_down_fast(event) -> None:
            scroll_output(5)
            event.app.layout.focus(output_area)
            event.app.invalidate()

        @bindings.add("f7")
        def _jump_bottom(event) -> None:
            scroll_output_to_end()
            event.app.layout.focus(output_area)
            event.app.invalidate()

        @bindings.add("f6")
        def _toggle_focus(event) -> None:
            if event.app.layout.current_control == input_area.buffer.control:
                event.app.layout.focus(output_area)
            else:
                event.app.layout.focus(input_area)

        @bindings.add("c-o")
        def _expand_thinking(event) -> None:
            expand_thinking()
            event.app.invalidate()

        @bindings.add("c-d")
        def _exit(event) -> None:
            if busy:
                CANCEL_REQUESTED.set()
                close_active_model_response()
                update_status("stopping")
                release_server_now()
                event.app.exit(result=0)
                return
            release_server_now()
            event.app.exit(result=0)

        @bindings.add("c-c")
        def _interrupt(event) -> None:
            CANCEL_REQUESTED.set()
            close_active_model_response()
            release_server_now()
            event.app.exit(result=0)

        @bindings.add("c-l")
        def _clear_output(event) -> None:
            output_area.buffer.set_document(Document("", 0), bypass_readonly=True)
            event.app.invalidate()

        style = Style.from_dict(
            {
                # temel
                "": "#e6edf3 bg:#0a0c10",
                "textarea": "#e6edf3 bg:#0a0c10",
                "prompt-prefix": "bold #79c0ff",
                "separator": "#21262d",
                "inline-status": "#8b949e bg:#0a0c10",
                "footer": "#6e7681 bg:#161b22",
                "header": "bold #e6edf3 bg:#161b22",
                # tamamlama menüsü
                "completion-menu": "bg:#161b22 #e6edf3",
                "completion-menu.completion.current": "bg:#388bfd #ffffff",
                "completion-menu.completion": "bg:#161b22 #e6edf3",
                "completion-menu.meta.completion.current": "bg:#388bfd #e6edf3",
                "completion-menu.meta.completion": "bg:#0d1117 #6e7681",
                "scrollbar.background": "bg:#161b22",
                "scrollbar.button": "bg:#30363d",
                # transcript satırları
                "transcript.user": "bold #e6edf3",
                "transcript.user-prefix": "bold #388bfd",
                "transcript.prompt": "bold #e6edf3",
                "transcript.step": "#8b949e",
                "transcript.thinking": "italic #6e7681",
                "transcript.monologue": "italic #6e7681",
                "transcript.streaming": "#e6edf3",
                "transcript.parsing": "#d2a8ff",
                "transcript.explored": "#79c0ff",
                "transcript.ran": "#ffa657",
                "transcript.edited": "#ff7b72",
                "transcript.agent": "#3fb950",
                "transcript.orchestra": "italic #8b949e",
                "transcript.orchestra-detail": "italic #6e7681",
                "transcript.bullet": "#8b949e",
                "transcript.detail": "#6e7681",
                "transcript.hunk": "#6e7681",
                "transcript.add": "#3fb950",
                "transcript.del": "#f85149",
                "transcript.text": "#e6edf3",
                "transcript.separator": "#21262d",
                "transcript.code": "#e6edf3 bg:#161b22",
            }
        )
        def _header_text():
            model_short = (MODEL or "?").split("/")[-1][:32]
            mode_str = ctx.mode or "auto"
            profile_str = ACTIVE_PROFILE.name if ACTIVE_PROFILE else "default"
            sess_str = session_id[:8] if session_id else "new"
            return HTML(
                f"<b fg='#388bfd'>mico</b>"
                f"  <style fg='#30363d'>│</style>"
                f"  <style fg='#8b949e'>{model_short}</style>"
                f"  <style fg='#30363d'>│</style>"
                f"  <style fg='#8b949e'>mode:{mode_str}</style>"
                f"  <style fg='#30363d'>│</style>"
                f"  <style fg='#8b949e'>profile:{profile_str}</style>"
                f"  <style fg='#30363d'>│</style>"
                f"  <style fg='#6e7681'>session:{sess_str}</style>"
            )

        header_window = Window(
            content=FormattedTextControl(text=_header_text),
            height=Dimension.exact(1),
            dont_extend_height=True,
            style="class:header",
        )
        header_separator = Window(height=1, char="─", style="class:separator")
        separator = Window(height=1, char="─", style="class:separator")
        inline_status_window = Window(
            content=FormattedTextControl(text=build_inline_status_html),
            height=Dimension.exact(1),
            dont_extend_height=True,
            style="class:inline-status",
        )
        prompt_prefix = Window(
            content=FormattedTextControl(text=[("class:prompt-prefix", "❯ ")]),
            width=Dimension.exact(2),
            dont_extend_width=True,
        )
        composer = Frame(
            VSplit(
                [
                    prompt_prefix,
                    input_area,
                ],
            ),
            title="Prompt",
            style="class:textarea",
        )
        status_window = Window(
            content=FormattedTextControl(text=lambda: build_footer_status_html(session_id, ctx)),
            height=Dimension.exact(1),
            dont_extend_height=True,
            style="class:footer",
        )
        root_container = FloatContainer(
            content=HSplit(
                [
                    header_window,
                    header_separator,
                    output_area,
                    separator,
                    inline_status_window,
                    composer,
                    status_window,
                ]
            ),
            floats=[
                Float(
                    xcursor=True,
                    ycursor=True,
                    transparent=True,
                    content=CompletionsMenu(max_height=8, scroll_offset=1),
                )
            ],
        )
        app = Application(
            layout=Layout(
                root_container,
                focused_element=input_area,
            ),
            key_bindings=bindings,
            mouse_support=UI_MOUSE_SUPPORT,
            full_screen=UI_FULLSCREEN,
            style=style,
            min_redraw_interval=UI_MIN_REDRAW_INTERVAL,
            refresh_interval=UI_REFRESH_INTERVAL,
        )
        sink.app = app
        if initial_prompt is not None:
            initial = initial_prompt
            initial_prompt = None
            app.pre_run_callables.append(
                lambda: app.create_background_task(process_prompt(initial))
            )
        app.pre_run_callables.append(lambda: app.create_background_task(refresh_output()))
        app.pre_run_callables.append(lambda: app.create_background_task(refresh_spinner()))
        return await app.run_async()

    try:
        return asyncio.run(ui_main())
    finally:
        try:
            if hasattr(ctx, 'audit_logger') and ctx.audit_logger:
                ctx.audit_logger.finish(status="ok")
        except Exception:
            pass
        UI_APP = None
        UI_STATUS_LOGGING = True
        console = original_console


def render_path_choices_text(paths: list[Path], title: str) -> str:
    lines = [title]
    for idx, path in enumerate(paths, start=1):
        if path.suffix == ".json":
            updated, msg_count, preview = session_preview(path)
            lines.append(f"{idx}. {path.name} | {updated} | {msg_count} msgs | {preview}")
        else:
            updated = time.strftime("%Y-%m-%d %H:%M:%S", time.localtime(path.stat().st_mtime))
            lines.append(f"{idx}. {path.name} | {updated}")
    return "\n".join(lines)


def choose_from_paths(paths: list[Path], title: str) -> Path | None:
    if not paths:
        return None
    table = Table(
        title=title,
        box=box.SIMPLE_HEAVY,
        header_style="bold cyan",
        border_style="bright_black",
        expand=True,
        pad_edge=False,
    )
    table.add_column("#", style="cyan", no_wrap=True, width=4)
    table.add_column("Name", style="green", ratio=2)
    table.add_column("Updated", style="magenta", ratio=1)
    if paths and paths[0].suffix == ".json":
        table.add_column("Msgs", style="yellow", no_wrap=True, width=6)
        table.add_column("Preview", style="white", ratio=3)
    for idx, path in enumerate(paths, start=1):
        if path.suffix == ".json":
            updated, msg_count, preview = session_preview(path)
            table.add_row(str(idx), path.name, updated, msg_count, preview)
        else:
            updated = time.strftime("%Y-%m-%d %H:%M:%S", time.localtime(path.stat().st_mtime))
            table.add_row(str(idx), path.name, updated)
    console.print(Panel(table, border_style="bright_black", box=box.ROUNDED, padding=(0, 1)))
    choice = Prompt.ask("[bold cyan]select[/bold cyan]", default="1").strip()
    if not choice.isdigit():
        return None
    index = int(choice) - 1
    if index < 0 or index >= len(paths):
        return None
    return paths[index]


def configure_readline() -> None:
    def completer(text: str, state: int) -> str | None:
        buffer = readline.get_line_buffer()
        options = [cmd for cmd in SLASH_COMMANDS if cmd.startswith(buffer or text)]
        return options[state] if state < len(options) else None

    readline.parse_and_bind("tab: complete")
    try:
        readline.parse_and_bind("set enable-bracketed-paste on")
    except Exception:
        pass
    readline.set_completer(completer)


def print_status_bar(session_id: str, ctx: ToolContext) -> None:
    budget_label = f"{THINKING_BUDGET} auto" if ADAPTIVE_BUDGET else str(THINKING_BUDGET)
    left = Columns(
        [
            style_badge("mode", ctx.mode, "cyan"),
            style_badge("approval", ctx.approval, "yellow"),
            style_badge("thinking", "on" if THINKING else "off", "green"),
            style_badge("budget", budget_label, "magenta"),
            style_badge("context", str(CONTEXT_WINDOW_TOKENS), "cyan"),
            style_badge("compact", f"{UI_COMPACT_PERCENT_REMAINING}%", "blue"),
            style_badge("narrate", "on" if ctx.narrate else "off", "blue"),
            style_badge("profile", ctx.profile, "yellow"),
            style_badge("dry-run", "on" if ctx.dry_run else "off", "red"),
            style_badge("unattended", "on" if ctx.unattended else "off", "red" if ctx.unattended else "green"),
            style_badge("permission", getattr(ctx, "permission_mode", "balanced"), "yellow"),
            style_badge("orchestra", "on" if ORCHESTRA_ENABLED else "off", "green" if ORCHESTRA_ENABLED else "red"),
            style_badge("model-profile", ACTIVE_PROFILE.name if ACTIVE_PROFILE else "default", "magenta"),
        ],
        expand=False,
        equal=False,
        padding=(0, 2),
    )
    right = Text()
    right.append("session ", style="bold white")
    right.append(session_id[:8], style="dim")
    right.append("  model ", style="bold white")
    right.append(model_label(MODEL), style="dim")
    if DRAFT_MODEL:
        right.append("  draft ", style="bold white")
        right.append(model_label(DRAFT_MODEL), style="dim")
    if ORCHESTRA_ENABLED:
        analyzer_cfg, final_cfg = resolve_orchestra_role_configs("worker")
        right.append("  orch ", style="bold white")
        right.append(
            (
                f"{model_label((analyzer_cfg.resolved_path if analyzer_cfg else None) or (analyzer_cfg.model if analyzer_cfg else ORCHESTRA_ANALYZER_MODEL))} -> "
                f"{model_label((final_cfg.resolved_path if final_cfg else None) or (final_cfg.model if final_cfg else ORCHESTRA_FINAL_MODEL))}"
            ),
            style="dim",
        )
    right.append("  cwd ", style="bold white")
    right.append(str(ctx.cwd), style="dim")
    header = Table.grid(expand=True)
    header.add_column(ratio=2)
    header.add_column(justify="right", ratio=3)
    header.add_row(left, right)
    console.print(
        Panel(
            header,
            title="[bold white]mico[/bold white]",
            border_style=COLOR_PLAN,
            box=box.ROUNDED,
            padding=(0, 1),
        )
    )


def runtime_settings_report(session_id: str, ctx: ToolContext) -> str:
    return "\n".join(
        [
            "Runtime Settings",
            f"session: {session_id[:8]}",
            f"cwd: {ctx.cwd}",
            f"mode: {ctx.mode}",
            f"profile: {ctx.profile}",
            f"model_profile: {ACTIVE_PROFILE.name if ACTIVE_PROFILE else 'default'}",
            f"permission: {ctx.permission_mode}",
            f"approval: {ctx.approval}",
            f"thinking: {'on' if THINKING else 'off'}",
            f"thinking_budget: {THINKING_BUDGET}",
            f"adaptive_budget: {'on' if ADAPTIVE_BUDGET else 'off'}",
            f"min_thinking_budget: {MIN_THINKING_BUDGET}",
            f"max_thinking_budget: {MAX_THINKING_BUDGET}",
            f"context_window: {CONTEXT_WINDOW_TOKENS}",
            f"max_tokens: {MAX_TOKENS}",
            f"compact_remaining: {UI_COMPACT_PERCENT_REMAINING}%",
            f"narrate: {'on' if ctx.narrate else 'off'}",
            f"dry_run: {'on' if ctx.dry_run else 'off'}",
            f"tool_install: {'on' if ctx.tool_install else 'off'}",
            f"orchestra: {'on' if ORCHESTRA_ENABLED else 'off'}",
            f"model_provider: {MODEL_PROVIDER}",
            f"model: {model_label(MODEL)}",
            f"draft_model: {model_label(DRAFT_MODEL) if DRAFT_MODEL else '-'}",
            f"api_base: {API_BASE}",
            f"server_port: {PORT}",
            f"server_prefill_step_size: {SERVER_PREFILL_STEP_SIZE}",
            f"server_kv_bits: {SERVER_KV_BITS}",
            f"server_max_kv_size: {SERVER_MAX_KV_SIZE}",
            f"server_quantized_kv_start: {SERVER_QUANTIZED_KV_START}",
            f"server_prompt_cache_size: {SERVER_PROMPT_CACHE_SIZE}",
            f"server_prompt_cache_bytes: {SERVER_PROMPT_CACHE_BYTES}",
            f"default_tool_install: {'on' if DEFAULT_TOOL_INSTALL else 'off'}",
            f"default_profile: {DEFAULT_PROFILE}",
            f"default_model_profile: {DEFAULT_MODEL_PROFILE or 'default'}",
        ]
    )


def render_welcome_panel() -> None:
    recent_count = len(list_recent_sessions())
    model_short = (MODEL or "?").split("/")[-1][:40]

    quick = Table.grid(padding=(0, 2))
    quick.add_column(style="bold #79c0ff", no_wrap=True)
    quick.add_column(style="#6e7681")
    quick.add_row("/model list", "model değiştir")
    quick.add_row("/mode fast|normal|deep", "mod seç")
    quick.add_row("/dry-run on", "dosya değiştirmeden analiz")
    quick.add_row("/preflight", "başlamadan kontrol")
    quick.add_row("/checkpoint", "anlık snapshot")
    quick.add_row("/rollback", "son checkpoint'e dön")
    quick.add_row("/help", "tüm komutlar")

    logo = Text()
    logo.append(" ██████   ██████  ██████  ███████ ██   ██\n", style="bold #388bfd")
    logo.append("██    ██ ██      ██    ██ ██       ██ ██ \n", style="bold #388bfd")
    logo.append("██    ██ ██      ██    ██ █████     ███  \n", style="bold #388bfd")
    logo.append("██ ▄▄ ██ ██      ██    ██ ██       ██ ██ \n", style="bold #388bfd")
    logo.append(" ██████   ██████  ██████  ███████ ██   ██\n", style="bold #388bfd")
    logo.append(" ▀▀\n", style="bold #388bfd")
    logo.append("local coding agent\n\n", style="#8b949e")
    logo.append("model    ", style="#6e7681")
    logo.append(f"{model_short}\n", style="#e6edf3")
    logo.append("network  ", style="#6e7681")
    logo.append("on\n", style="#3fb950")
    logo.append("sessions ", style="#6e7681")
    logo.append(f"{recent_count}\n\n", style="#e6edf3")
    logo.append("Enter:gönder  Esc+Enter:yeni satır  Ctrl-D:çıkış", style="#6e7681")

    console.print(
        Panel(
            Columns(
                [Align.left(logo), Align.left(quick)],
                expand=True,
                equal=False,
                padding=(0, 4),
            ),
            border_style="#21262d",
            box=box.ROUNDED,
            padding=(1, 2),
        )
    )


def handle_chat_command(
    command: str,
    session_id: str,
    history: list[dict[str, str]] | None,
    ctx: ToolContext,
) -> tuple[bool, str | None, str | None, list[dict[str, str]] | None]:
    global THINKING_BUDGET, THINKING, ADAPTIVE_BUDGET, CONTEXT_WINDOW_TOKENS
    parts = command.strip().split()
    head = parts[0].lower()

    if head in {"/exit", "exit", "quit"}:
        return (False, None, None, history)
    if head == "/help":
        console.print(
            Panel(
                "/new                  yeni oturum baslat\n"
                "/skills               yuklu skill'leri listele\n"
                "/doctor               oturum ve runtime sagligini ozetle\n"
                "/sessions             son oturumlari listele\n"
                "/paste                clipboard icerigini goreve donustur\n"
                "/mode auto|code|audit|review|plan|fast|normal|deep|docs|ship-safe   dispatch modu veya hazir calisma modu sec\n"
                "/approval ask|auto|never       komut onay davranisini ayarla\n"
                "/unattended on|off    gece modu: tum onaylari atla, sadece katastrofik komutlar bloklanir\n"
                "/permission strict|balanced|yolo   3-tier komut izni (allow/ask/deny) ayari\n"
                "/tool-install on|off  arac kurulumunu ac veya kapa\n"
                "/auto-accept on|off   hizli onay kisayolu\n"
                "/thinking on|off|low|medium|high   dusunmeyi ac/kapat veya effort seviyesi ata\n"
                "/effort low|medium|high   runtime dusunme derinligini ayarla\n"
                "/budget <n>           thinking budget degerini ayarla\n"
                "/context-window <tokens>   baglam boyutunu ayarla\n"
                "/adaptive-budget on|off    dinamik budget ayarini ac veya kapa\n"
                "/profile lite|fast|balanced|deep   thinking/context icin runtime profili sec\n"
                "/model-profile fast|normal|deep|review|docs|default   worker/architect/reviewer model profilini sec\n"
                "/dry-run on|off       araclari gercekten calistirmadan planla\n"
                "/narrate on|off       arac ilerleme satirlarini ac veya kapa\n"
                "/status               anlik durum cubugunu yazdir\n"
                "/state                aktif oturumun task state ozetini yazdir\n"
                "/artifacts            aktif oturum artifact ozetini yazdir\n"
                "/orchestra on|off|status   coklu-model orchestra durumunu yonet\n"
                "/checkpoint [label]   git tabanli geri alinabilir nokta olustur\n"
                "/checkpoints          son checkpoint'leri listele\n"
                "/rollback [ref]       son veya secilen checkpoint'e geri don\n"
                "/restore <file>       sadece bir dosyayi son checkpoint'ten geri al\n"
                "/diff                 calisma kopyasinda degisen seyleri ozetle\n"
                "/gitstatus            git status --short --branch ozetini yazdir\n"
                "/allow-path <path>    proje koku disindaki bir dizini dosya araclari icin whitelist'e ekle\n"
                "/allowed-paths        whitelist'teki dis yollari listele\n"
                "/test [runner]        otomatik test runner'i calistir (auto/pytest/npm/cargo/go/make)\n"
                "/review               review modu + git diff ozeti\n"
                "/commit <mesaj>       git add -A && git commit -m <mesaj>\n"
                "/context              context window ve compact durum bilgisini goster\n"
                "/stop                 mevcut agent loop'unu durdurmak icin bayrak set et\n"
                "/plan [gorev]         plan modu (modifikasyon yok)\n"
                "/edit <dosya>         code modu + dosyayi context'e hazirla\n"
                "/model                aktif model ve profil bilgisini goster\n"
                "/resume               oturum secip devam et\n"
                "/resume last          son oturumu ac\n"
                "/resume <session-id>  belirli oturumu ac\n"
                "/exit                 mico'ten cik\n"
                "\n"
                "Varsayilan davranis:\n"
                "- tool-first calisir; gerekli ise once typed tool kullanir\n"
                "- uygun oldugunda bash yerine read_file/list_files/grep_code/macos_admin_task/skill_tool tercih edilir\n"
                "- yuklu skill'leri gormek icin /skills kullan\n"
                "- TUI'de dispatch != runtime != model-profile; /status veya /model ile net gorebilirsin\n"
                "\n"
                "Kisayollar:\n"
                "Enter gonder | Esc+Enter yeni satir | Ctrl+D cikis\n"
                "PgUp/PgDn scroll | F7 bottom | Esc+Up/Down hizli scroll | terminal text secimi acik",
                title="commands",
                border_style=COLOR_NARRATE,
            )
        )
        return (True, "", None, history)
    if head == "/paste":
        text = read_clipboard_text().rstrip("\n")
        if not text.strip():
            return (True, "Clipboard is empty.", None, history)
        line_count = text.count("\n") + 1
        return (True, f"[PASTE_CLIPBOARD {line_count} lines]\n{text}", None, history)
    if head == "/new":
        new_session_id = str(uuid.uuid4())
        new_history = None
        return (True, f"Started new session {new_session_id[:8]}.", new_session_id, new_history)
    if head == "/skills":
        skills = discover_skills(ctx)
        if not skills:
            return (True, "No skills found.", None, history)
        lines = ["Available Skills"]
        for idx, skill in enumerate(skills, start=1):
            desc = truncate(skill.description or "(no description)", 120).replace("\n", " ")
            lines.append(f"{idx}. {skill.name} | {skill.source} | {desc}")
        return (True, "\n".join(lines), None, history)
    if head == "/sessions":
        sessions = list_recent_sessions()[:10]
        if not sessions:
            return (True, "No sessions found.", None, history)
        if not UI_STATUS_LOGGING:
            return (
                True,
                render_path_choices_text(sessions, "Recent Sessions") + "\nUse /resume <number> to open one.",
                None,
                history,
            )
        choose_from_paths(sessions, "Recent Sessions")
        return (True, "", None, history)
    if head == "/status":
        print_status_bar(session_id, ctx)
        return (True, runtime_settings_report(session_id, ctx), None, history)
    if head == "/orchestra":
        global ORCHESTRA_ENABLED
        if len(parts) == 1 or parts[1].lower() == "status":
            state = "on" if ORCHESTRA_ENABLED else "off"
            analyzer_cfg, final_cfg = resolve_orchestra_role_configs("worker")
            analyzer_label = (analyzer_cfg.resolved_path if analyzer_cfg else None) or (analyzer_cfg.model if analyzer_cfg else ORCHESTRA_ANALYZER_MODEL)
            final_label = (final_cfg.resolved_path if final_cfg else None) or (final_cfg.model if final_cfg else ORCHESTRA_FINAL_MODEL)
            return (
                True,
                (
                    f"Orchestra {state}. analyzer={analyzer_label} final={final_label}. "
                    "(persist etmek icin config.env icine MICO_ORCHESTRA_ENABLED=1 yazabilirsin)"
                ),
                None,
                history,
            )
        value = parts[1].lower()
        if value in {"on", "off"}:
            ORCHESTRA_ENABLED = value == "on"
            return (True, f"Orchestra {'enabled' if ORCHESTRA_ENABLED else 'disabled'}.", None, history)
    if head == "/doctor":
        return (True, doctor_report(history, session_id, ctx), None, history)
    if head == "/state":
        return (True, task_state_report(session_id), None, history)
    if head == "/artifacts":
        return (True, artifact_report(session_id), None, history)
    if head == "/mode" and len(parts) > 1:
        mode = parts[1].lower()
        if mode in {"fast", "normal", "deep", "docs"}:
            runtime_map = {"fast": "fast", "normal": "balanced", "deep": "deep", "docs": "balanced"}
            ctx.profile = apply_runtime_profile(runtime_map[mode])
            ctx.mode = "plan" if mode == "docs" else ("review" if mode == "review" else "auto")
            apply_model_profile(mode)
            current_model_profile = ACTIVE_PROFILE.name if ACTIVE_PROFILE else "default"
            return (
                True,
                (
                    f"Mode set to {mode}. dispatch={ctx.mode} "
                    f"runtime={ctx.profile} model-profile={current_model_profile}"
                ),
                None,
                history,
            )
        if mode == "ship-safe":
            ctx.mode = "auto"
            ctx.permission_mode = "strict"
            ctx.tool_install = False
            ctx.unattended = False
            return (
                True,
                (
                    "Ship-safe mode enabled. dispatch=auto, "
                    "network/tool-install off, strict permission policy active."
                ),
                None,
                history,
            )
        if mode in {"auto", "exec", "code", "audit", "review", "plan"}:
            ctx.mode = "auto" if mode == "exec" else mode
            if mode == "review":
                try:
                    apply_model_profile("review")
                except ValueError:
                    pass
            current_model_profile = ACTIVE_PROFILE.name if ACTIVE_PROFILE else "default"
            return (True, f"Dispatch mode set to {ctx.mode}. model-profile={current_model_profile}", None, history)
    if head == "/approval" and len(parts) > 1:
        mode = parts[1].lower()
        if mode in {"ask", "auto", "never"}:
            ctx.approval = mode
            return (True, f"Approval set to {mode}.", None, history)
    if head == "/checkpoint":
        if git_repo_root(ctx.cwd) is None:
            return (
                True,
                "Bu klasor git deposu degil. /commit ile init etmedikce checkpoint olusturulamaz.",
                None,
                history,
            )
        label = " ".join(parts[1:]).strip()
        ref, info = create_git_checkpoint(ctx.cwd, label)
        if ref is None:
            return (True, f"Checkpoint olusturulamadi: {info}", None, history)
        return (True, f"Checkpoint olusturuldu: {ref} ({info[:12]})", None, history)
    if head == "/checkpoints":
        if git_repo_root(ctx.cwd) is None:
            return (
                True,
                "Bu klasor git deposu degil. /commit ile init etmedikce checkpoint olusturulamaz.",
                None,
                history,
            )
        items = list_git_checkpoints(ctx.cwd)
        if not items:
            return (True, "Henuz checkpoint yok. /checkpoint ile olustur.", None, history)
        lines = ["# son checkpoint'ler"]
        for idx, item in enumerate(items[:10], start=1):
            lines.append(f"{idx}. {item['ref']}  {item['sha'][:8]}  {item['date']}")
        return (True, "\n".join(lines), None, history)
    if head == "/rollback":
        if git_repo_root(ctx.cwd) is None:
            return (
                True,
                "Bu klasor git deposu degil. /commit ile init etmedikce checkpoint olusturulamaz.",
                None,
                history,
            )
        rest = parts[1:]
        target_paths: list[str] | None = None
        if "--" in rest:
            sep_idx = rest.index("--")
            ref_args = rest[:sep_idx]
            target_paths = rest[sep_idx + 1 :] or None
        else:
            ref_args = rest
        if not ref_args or (len(ref_args) == 1 and ref_args[0].lower() == "last"):
            items = list_git_checkpoints(ctx.cwd)
            if not items:
                return (True, "Geri donulecek checkpoint yok.", None, history)
            ref = items[0]["ref"]
        else:
            ref = ref_args[0]
        msg = rollback_to_checkpoint(ctx.cwd, ref, target_paths)
        return (True, msg, None, history)
    if head == "/restore":
        if len(parts) < 2:
            return (True, "Kullanim: /restore <dosya>", None, history)
        if git_repo_root(ctx.cwd) is None:
            return (
                True,
                "Bu klasor git deposu degil. /commit ile init etmedikce checkpoint olusturulamaz.",
                None,
                history,
            )
        items = list_git_checkpoints(ctx.cwd)
        if not items:
            return (True, "Geri donulecek checkpoint yok.", None, history)
        file_path = parts[1]
        msg = rollback_to_checkpoint(ctx.cwd, items[0]["ref"], [file_path])
        return (True, msg, None, history)
    if head == "/test":
        runner_arg = parts[1].lower() if len(parts) > 1 else "auto"
        detected = detect_test_runners(ctx.cwd)
        if runner_arg == "auto":
            if not detected:
                return (True, "No test runner detected in cwd.", None, history)
            runner = detected[0]
        else:
            runner = next((r for r in detected if r.name == runner_arg), None)
            if runner is None:
                forced = {
                    "pytest": ["pytest", "-x", "--tb=short", "-q"],
                    "npm": ["npm", "test", "--silent"],
                    "cargo": ["cargo", "test", "--quiet"],
                    "go": ["go", "test", "./..."],
                    "make": ["make", "test"],
                }.get(runner_arg)
                if not forced:
                    return (True, f"Unknown runner: {runner_arg}", None, history)
                runner = TestRunner(name=runner_arg, command=forced, config_file="(forced)", priority=99)
        result = _run_tests_impl(runner, ctx.cwd, timeout=180)
        return (True, result.summary, None, history)
    if head == "/diff":
        return (True, git_diff_summary(ctx.cwd), None, history)
    if head == "/gitstatus":
        return (True, git_status_short(ctx.cwd), None, history)
    if head == "/allow-path":
        if len(parts) < 2:
            return (True, "Usage: /allow-path <path>", None, history)
        raw = " ".join(parts[1:]).strip()
        try:
            candidate = Path(raw).expanduser().resolve(strict=False)
        except (OSError, RuntimeError) as exc:
            return (True, f"Invalid path: {exc}", None, history)
        if is_sensitive_path(candidate):
            return (
                True,
                f"Refused: {candidate} is inside a protected location and can never be whitelisted.",
                None,
                history,
            )
        if candidate not in ctx.allowed_external_paths:
            ctx.allowed_external_paths.append(candidate)
        return (True, f"Allowed external path: {candidate}", None, history)
    if head == "/allowed-paths":
        if not ctx.allowed_external_paths:
            return (True, "No external paths whitelisted.", None, history)
        listing = "\n".join(f"- {p}" for p in ctx.allowed_external_paths)
        return (True, f"Whitelisted external paths:\n{listing}", None, history)
    if head == "/tool-install" and len(parts) > 1:
        value = parts[1].lower()
        if value in {"on", "off"}:
            ctx.tool_install = value == "on"
            if not ctx.tool_install:
                return (True, "Tool installation disabled.", None, history)
            return (True, "Tool installation enabled.", None, history)
    if head == "/permission" and len(parts) > 1:
        value = parts[1].lower()
        if value in {"strict", "balanced", "yolo"}:
            ctx.permission_mode = value
            return (True, f"Permission mode set to {value}.", None, history)
        return (True, "Usage: /permission strict|balanced|yolo", None, history)
    if head == "/unattended" and len(parts) > 1:
        value = parts[1].lower()
        if value == "on":
            ctx.unattended = True
            ctx.approval = "never"
            ctx.force = True
            ctx.tool_install = True
            return (
                True,
                "Unattended mode ON: no prompts, network+tool-install enabled. "
                "Catastrophic commands (sudo, rm -rf /, mkfs, shutdown, curl|sh) stay blocked.",
                None,
                history,
            )
        if value == "off":
            ctx.unattended = False
            ctx.force = False
            ctx.approval = "ask"
            return (True, "Unattended mode OFF. Approval reset to ask.", None, history)
    if head == "/auto-accept" and len(parts) > 1:
        value = parts[1].lower()
        if value == "on":
            ctx.approval = "never"
            return (True, "Auto-accept enabled.", None, history)
        if value == "off":
            ctx.approval = "ask"
            return (True, "Auto-accept disabled.", None, history)
    if head == "/thinking" and len(parts) > 1:
        value = parts[1].lower()
        if value in {"on", "off"}:
            THINKING = value == "on"
            return (True, f"Thinking {'enabled' if THINKING else 'disabled'}.", None, history)
        if value in {"low", "medium", "high"}:
            return (True, apply_effort_level(value), None, history)
        return (True, "Usage: /thinking on|off|low|medium|high", None, history)
    if head == "/effort":
        if len(parts) < 2:
            return (True, "Usage: /effort low|medium|high", None, history)
        value = parts[1].lower()
        if value in {"low", "medium", "high"}:
            return (True, apply_effort_level(value), None, history)
        return (True, "Usage: /effort low|medium|high", None, history)
    if head == "/budget" and len(parts) > 1 and parts[1].isdigit():
        THINKING_BUDGET = int(parts[1])
        return (True, f"Thinking budget set to {THINKING_BUDGET}.", None, history)
    if head in {"/context-window", "/context"} and len(parts) > 1 and parts[1].isdigit():
        CONTEXT_WINDOW_TOKENS = max(1024, int(parts[1]))
        remaining = update_compact_meter(history or [])
        return (
            True,
            f"Context window set to {CONTEXT_WINDOW_TOKENS}. Auto compact remaining {remaining}%.",
            None,
            history,
        )
    if head == "/adaptive-budget" and len(parts) > 1:
        value = parts[1].lower()
        if value in {"on", "off"}:
            ADAPTIVE_BUDGET = value == "on"
            return (
                True,
                f"Adaptive budget {'enabled' if ADAPTIVE_BUDGET else 'disabled'}.",
                None,
                history,
            )
    if head == "/model-profile":
        if len(parts) < 2:
            current = ACTIVE_PROFILE.name if ACTIVE_PROFILE else "default"
            return (
                True,
                f"Model profile: {current}. Available: {', '.join(list_model_profiles())} | default",
                None,
                history,
            )
        target = parts[1].lower()
        if target in {"default", "none", "off"}:
            apply_model_profile(None)
            return (True, "Model profile cleared (default single-model behavior).", None, history)
        try:
            profile_obj = apply_model_profile(target)
        except ValueError as exc:
            return (True, f"Model profile error: {exc}", None, history)
        roles_summary = ", ".join(
            f"{r}={cfg.resolved_path or cfg.model}" for r, cfg in (profile_obj.roles.items() if profile_obj else [])
        )
        return (True, f"Model profile set to {target}. Roles: {roles_summary}", None, history)
    if head == "/profile":
        choices = sorted(PROFILE_PRESETS)
        if len(parts) <= 1:
            return (
                True,
                (
                    f"/profile sets the *runtime* profile (thinking budget + ctx window). "
                    f"Current: {ctx.profile}. Choices: {', '.join(choices)}. "
                    f"For role/model bindings (fast/normal/deep/review/docs) use /model-profile."
                ),
                None,
                history,
            )
        profile = parts[1].lower()
        if profile in PROFILE_PRESETS:
            ctx.profile = apply_runtime_profile(profile)
            remaining = update_compact_meter(history or [])
            return (
                True,
                f"Runtime profile set to {ctx.profile}. Budget {THINKING_BUDGET}, context {CONTEXT_WINDOW_TOKENS}, compact remaining {remaining}%.",
                None,
                history,
            )
        return (
            True,
            f"Unknown runtime profile '{profile}'. Choices: {', '.join(choices)}. "
            f"(Did you mean /model-profile? That switches model role bindings.)",
            None,
            history,
        )
    if head == "/dry-run" and len(parts) > 1:
        value = parts[1].lower()
        if value in {"on", "off"}:
            ctx.dry_run = value == "on"
            return (True, f"Dry-run {'enabled' if ctx.dry_run else 'disabled'}.", None, history)
    if head == "/preflight":
        args_str = " ".join(parts[1:]) if len(parts) > 1 else ""
        task_hint = args_str.strip() if args_str else ""
        result = run_preflight(ctx, task=task_hint, cwd=Path.cwd())
        return (True, format_preflight(result), None, history)
    if head == "/limits":
        profile_name = (ACTIVE_PROFILE.name if ACTIVE_PROFILE else "fast")
        limits = PROFILE_LIMITS.get(profile_name, PROFILE_LIMITS["normal"])
        lines = [f"Limits for {profile_name} mode:"]
        for k, v in limits.items():
            lines.append(f"  {k}: {v}")
        return (True, "\n".join(lines), None, history)
    if head == "/model-check":
        result = run_preflight(ctx, cwd=Path.cwd())
        return (True, format_preflight(result), None, history)
    if head == "/task-size":
        task_text = " ".join(parts[1:]).strip() if len(parts) > 1 else ""
        if not task_text:
            task_text = history[-1].get("content", "") if history else ""
        if not task_text:
            return (True, "Usage: /task-size <task description>", None, history)
        result = classify_task_size(task_text)
        return (True, format_task_size(result), None, history)
    if head == "/audit":
        audit = getattr(ctx, "audit_logger", None)
        if audit and audit.current():
            from mico.audit import format_audit_summary
            return (True, format_audit_summary(audit.current()), None, history)
        return (True, "No audit entry for current session.", None, history)
    if head == "/mode" and len(parts) > 1:
        profile_name = parts[1].lower()
        valid = {"fast", "normal", "deep", "review", "docs"}
        if profile_name not in valid:
            return (True, f"Usage: /mode <{'|'.join(sorted(valid))}>", None, history)
        try:
            apply_model_profile(profile_name)
            return (True, f"Mode set to: {profile_name}", None, history)
        except ValueError as exc:
            return (True, f"Error setting mode: {exc}", None, history)
    if head == "/narrate" and len(parts) > 1:
        value = parts[1].lower()
        if value in {"on", "off"}:
            ctx.narrate = value == "on"
            return (True, f"Narration {'enabled' if ctx.narrate else 'disabled'}.", None, history)
    if head == "/resume":
        target: Path | None = None
        if len(parts) > 1 and parts[1].lower() == "last":
            target = latest_session()
        elif len(parts) > 1:
            if parts[1].isdigit():
                sessions = list_recent_sessions()[:10]
                index = int(parts[1]) - 1
                if 0 <= index < len(sessions):
                    target = sessions[index]
                else:
                    return (True, "Session number not found.", None, history)
            else:
                candidate = SESSIONS_DIR / parts[1]
                target = candidate if candidate.exists() else SESSIONS_DIR / f"{parts[1]}.json"
        else:
            sessions = list_recent_sessions()[:10]
            if not sessions:
                return (True, "No sessions found.", None, history)
            if not UI_STATUS_LOGGING:
                return (
                    True,
                    render_path_choices_text(sessions, "Recent Sessions") + "\nUse /resume <number> to open one.",
                    None,
                    history,
                )
            target = choose_from_paths(sessions, "Recent Sessions")
        if not target or not target.exists():
            return (True, "Session not found.", None, history)
        loaded_history = load_session_history(target)
        return (True, f"Resumed {target.name}.", target.stem, loaded_history)
    if head == "/review":
        ctx.mode = "review"
        try:
            apply_model_profile("review")
        except ValueError:
            pass
        diff_text = git_diff_summary(ctx.cwd)
        model_profile = ACTIVE_PROFILE.name if ACTIVE_PROFILE else "default"
        body = (
            f"Review mode aktif. dispatch=review model-profile={model_profile}\n\n"
            "Calisma kopyasi diff'i:\n\n"
            + (diff_text or "(no changes)")
        )
        return (True, body, None, history)
    if head == "/commit":
        message = " ".join(parts[1:]).strip()
        if not message:
            return (True, "Kullanim: /commit <mesaj>", None, history)
        if "\n" in message:
            return (True, "Tek satir mesaj kullan; multiline desteklenmiyor.", None, history)
        if git_repo_root(ctx.cwd) is None:
            return (True, "Bu klasor git deposu degil.", None, history)
        effective_perm = "yolo" if getattr(ctx, "unattended", False) else getattr(ctx, "permission_mode", "balanced")
        if effective_perm == "strict" and not getattr(ctx, "unattended", False):
            if not Prompt.ask(f"Commit yapilacak: '{message}' (y/N)", default="n").lower().startswith("y"):
                return (True, "Commit iptal edildi.", None, history)
        try:
            run_subprocess(["git", "add", "-A"], cwd=ctx.cwd, timeout=30)
            proc = run_subprocess(["git", "commit", "-m", message], cwd=ctx.cwd, timeout=30)
        except Exception as exc:
            return (True, f"git commit failed: {exc}", None, history)
        out = (proc.stdout or "").strip()
        err = (proc.stderr or "").strip()
        body = "\n".join(filter(None, [out, err])) or "Commit tamamlandi."
        return (True, body, None, history)
    if head == "/context" and len(parts) == 1:
        remaining = update_compact_meter(history or [])
        body = (
            f"Mode: {ctx.mode}\n"
            f"Profile: {ctx.profile}\n"
            f"Model-profile: {ACTIVE_PROFILE.name if ACTIVE_PROFILE else 'default'}\n"
            f"Context window: {CONTEXT_WINDOW_TOKENS} tokens\n"
            f"Auto-compact ratio: {AUTO_COMPACT_RATIO}\n"
            f"Compact remaining: {remaining}%\n"
            f"Mesaj sayisi: {len(history or [])}"
        )
        return (True, body, None, history)
    if head == "/stop":
        global STOP_REQUESTED
        STOP_REQUESTED = True
        CANCEL_REQUESTED.set()
        return (
            True,
            "Stop bayragi set edildi; mevcut tool cagrisi bittikten sonra durur.",
            None,
            history,
        )
    if head == "/plan":
        ctx.mode = "plan"
        rest = " ".join(parts[1:]).strip()
        if rest:
            return (True, f"Plan modu aktif. Gorev: {rest}", None, history)
        return (True, "Plan modu aktif. Modifikasyon yok; sadece plan uretilir.", None, history)
    if head == "/edit":
        if len(parts) < 2:
            return (True, "Kullanim: /edit <dosya>", None, history)
        target_path = " ".join(parts[1:]).strip()
        ctx.mode = "code"
        try:
            full = Path(target_path).expanduser()
            if not full.is_absolute():
                full = (ctx.cwd / target_path).resolve()
            if not full.exists():
                return (True, f"Dosya bulunamadi: {full}", None, history)
            content = full.read_text(errors="replace")
            head_lines = "\n".join(content.splitlines()[:60])
            body = (
                f"Code modu aktif. {full} hazirlandi.\n"
                f"Ilk 60 satir:\n----\n{head_lines}\n----"
            )
            return (True, body, None, history)
        except Exception as exc:
            return (True, f"/edit hatasi: {exc}", None, history)
    if head == "/model":
        sub = parts[1].lower() if len(parts) > 1 else ""

        # /model list — show available models
        if sub == "list":
            options = discover_model_options()
            if not options:
                return (True, "No models found. Check API endpoint.", None, history)
            lines = ["Available models:"]
            for i, opt in enumerate(options, 1):
                marker = " *" if opt.model == MODEL else ""
                lines.append(f"  {i}. {opt.label} ({opt.params_label or opt.model}){marker}")
            lines.append("\nUse /model <number> to switch.")
            return (True, "\n".join(lines), None, history)

        # /model <number> — switch to model by index
        if sub.isdigit():
            options = discover_model_options()
            idx = int(sub) - 1
            if 0 <= idx < len(options):
                selected = options[idx]
                if selected.provider == "lmstudio":
                    import mico.cli as _self
                    current_host = CONFIG.get("LMSTUDIO_HOST", os.environ.get("LMSTUDIO_HOST", "http://localhost:1234"))
                    sys.stdout.write(f"LM Studio host [{current_host}]: ")
                    sys.stdout.flush()
                    try:
                        entered = input().strip()
                    except (EOFError, KeyboardInterrupt):
                        entered = ""
                    lms_host = entered or current_host
                    lms_host = lms_host.rstrip("/")
                    if not lms_host.startswith("http"):
                        lms_host = f"http://{lms_host}"
                    _self.API_BASE = f"{lms_host}/v1"
                    _self.API_KEY = "lm-studio"
                    _self.MODEL = "lmstudio:__connect__"
                    _self.MODEL_PROVIDER = "lmstudio"
                    os.environ["LMSTUDIO_HOST"] = lms_host
                    os.environ["MODEL_PROVIDER"] = "lmstudio"
                    os.environ["MODEL_NAME"] = "lmstudio:__connect__"
                    return (True, f"LM Studio bağlandı: {lms_host}/v1", None, history)
                select_startup_model(selected.model, None)
                return (True, f"Model switched to: {selected.label}\nDraft: {DRAFT_MODEL or 'none'}", None, history)
            return (True, "Invalid model number. Use /model list to see options.", None, history)

        # /model select — interactive picker (only in TTY)
        if sub == "select":
            if sys.stdin.isatty():
                select_startup_model(None, None)
                return (True, f"Active model: {MODEL}\nDraft: {DRAFT_MODEL or 'none'}", None, history)
            return (True, "Interactive selection requires a TTY. Use /model <number> instead.", None, history)

        # /model (no args) — show current info
        if not sub:
            profile_name = ACTIVE_PROFILE.name if ACTIVE_PROFILE else "default"
            body = (
                f"Active model:  {MODEL}\n"
                f"Draft model:   {DRAFT_MODEL or 'none'}\n"
                f"Mode:          {ctx.mode}\n"
                f"Profile:       {ctx.profile}\n"
                f"Model-profile: {profile_name}\n"
                f"Orchestra:     {'on' if ORCHESTRA_ENABLED else 'off'}\n"
                f"\nCommands:\n"
                f"  /model list       — show available models\n"
                f"  /model <N>        — switch to model N\n"
                f"  /model select     — interactive picker"
            )
            return (True, body, None, history)

        return (True, "Unknown /model subcommand. Try /model list or /model select.", None, history)
    return (True, "Unknown command. Use /help.", None, history)



def apply_patch_file(patch_path: Path, cwd: Path) -> str:
    proc = subprocess.run(
        ["/usr/bin/env", "git", "apply", "--verbose", str(patch_path)],
        cwd=str(cwd),
        capture_output=True,
        text=True,
    )
    output = (proc.stdout + ("\n" + proc.stderr if proc.stderr else "")).strip()
    if proc.returncode != 0:
        raise RuntimeError(output or f"git apply failed with code {proc.returncode}")
    return output or f"Applied {patch_path}"


def main() -> int:
    global SERVER_STOP_ON_EXIT
    argv = sys.argv[1:]
    subcommands = {"auto", "exec", "code", "chat", "serve", "review", "audit", "apply", "resume", "doctor", "state", "artifacts", "eval"}
    initial_prompt = None
    if argv and not argv[0].startswith("-") and argv[0] not in subcommands:
        initial_prompt = argv[0]
        argv = argv[1:]

    parser = argparse.ArgumentParser(description="mico local CLI")
    parser.add_argument("--cd", default=".", help="Working directory")
    parser.add_argument("--model", default=None, help="Model path or name override")
    parser.add_argument("--draft-model", default=None, help="Draft model path override for speculative decoding")
    parser.add_argument(
        "--approval",
        choices=["ask", "auto", "never"],
        default="ask",
        help="When to ask before running commands",
    )
    parser.add_argument(
        "--dangerously-bypass-approvals-and-sandbox",
        action="store_true",
        help="Run all generated commands without confirmation heuristics",
    )
    parser.add_argument(
        "--unattended",
        action="store_true",
        help=(
            "Overnight/no-prompt mode: skips every confirmation, enables network and "
            "tool installs. Catastrophic commands (sudo, rm -rf /, mkfs, shutdown, "
            "curl|sh, etc.) remain hard-blocked."
        ),
    )
    parser.add_argument(
        "--permission-mode",
        choices=["strict", "balanced", "yolo"],
        default="balanced",
        help="Allowlist tier policy: strict (allow only), balanced (ask for side-effects), yolo (skip prompts; deny still blocks)",
    )
    parser.add_argument(
        "--allow-tool-install",
        action="store_true",
        help="Allow package installation and remote tool setup commands",
    )
    parser.add_argument(
        "--narrate",
        choices=["on", "off"],
        default="on",
        help="Show human-readable progress narration for each tool step",
    )
    parser.add_argument(
        "--dry-run",
        action="store_true",
        help="Plan and format tool actions without executing them",
    )
    parser.add_argument(
        "--profile",
        choices=sorted(PROFILE_PRESETS),
        default=DEFAULT_PROFILE if DEFAULT_PROFILE in PROFILE_PRESETS else "balanced",
        help="Runtime profile for thinking budget and context sizing",
    )
    parser.add_argument(
        "--model-profile",
        choices=list_model_profiles(),
        default=DEFAULT_MODEL_PROFILE if DEFAULT_MODEL_PROFILE in list_model_profiles() else None,
        help="Role-based model profile (fast|normal|deep|review|docs)",
    )
    parser.add_argument(
        "--force-model-mismatch",
        action="store_true",
        help="Skip model sanity check warning for mismatches",
    )
    sub = parser.add_subparsers(dest="command")
    auto_parser = sub.add_parser("auto", help="Run with automatic task-based mode selection", aliases=["exec"])
    auto_parser.add_argument("task", help="Task to execute")
    code_parser = sub.add_parser("code", help="Run in focused coding mode")
    code_parser.add_argument("task", help="Coding task")
    chat_parser = sub.add_parser("chat", help="Run interactive chat")
    chat_parser.add_argument("task", nargs="?", help="Optional initial task")
    sub.add_parser("serve", help="Start or ensure backend server")
    review_parser = sub.add_parser("review", help="Run in findings-first review mode")
    review_parser.add_argument("task", help="Review task")
    audit_parser = sub.add_parser("audit", help="Run in security audit mode")
    audit_parser.add_argument("task", help="Audit task")
    apply_parser = sub.add_parser("apply", help="Apply a patch file with git apply")
    apply_parser.add_argument("patch", nargs="?", help="Patch file path")
    resume_parser = sub.add_parser("resume", help="List or continue recent sessions")
    resume_parser.add_argument("session", nargs="?", help="Session file or id to continue")
    resume_parser.add_argument("--last", action="store_true", help="Show only the most recent session file")
    sub.add_parser("doctor", help="Show session and runtime health diagnostics")
    state_parser = sub.add_parser("state", help="Show task state for a session")
    state_parser.add_argument("session", nargs="?", help="Session id or path")
    state_parser.add_argument("--last", action="store_true", help="Use the most recent session")
    artifacts_parser = sub.add_parser("artifacts", help="Show artifacts for a session")
    artifacts_parser.add_argument("session", nargs="?", help="Session id or path")
    artifacts_parser.add_argument("--last", action="store_true", help="Use the most recent session")
    artifacts_parser.add_argument("--limit", type=int, default=10, help="How many artifacts to show")
    eval_parser = sub.add_parser("eval", help="Run local mico regression evals")
    eval_parser.add_argument("dataset", nargs="?", help="Path to eval dataset JSON")

    args = parser.parse_args(argv)
    select_startup_model(args.model, args.draft_model)
    clear_startup_terminal()
    selected_profile = apply_runtime_profile(args.profile)
    if getattr(args, "model_profile", None):
        try:
            apply_model_profile(args.model_profile)
        except ValueError as exc:
            console.print(f"[red]model profile error:[/red] {exc}")
    SERVER_STOP_ON_EXIT = args.command != "serve"

    default_mode = args.command or "chat"
    if default_mode == "chat":
        default_mode = "auto"
    elif default_mode == "exec":
        default_mode = "auto"

    unattended = bool(args.unattended)
    approval = "never" if unattended else args.approval
    force_flag = bool(args.dangerously_bypass_approvals_and_sandbox or unattended)
    network_on = True
    tool_install_on = bool(args.allow_tool_install or unattended or DEFAULT_TOOL_INSTALL)

    ctx = ToolContext(
        cwd=safe_path(args.cd, Path.cwd()),
        approval=approval,
        force=force_flag,
        mode=default_mode,
        narrate=args.narrate == "on",
        dry_run=args.dry_run,
        profile=selected_profile,
        network_access=network_on,
        tool_install=tool_install_on,
        unattended=unattended,
        permission_mode=args.permission_mode,
        force_model_mismatch=getattr(args, "force_model_mismatch", False),
        audit_logger=None,
    )

    try:
        if args.command == "serve":
            ensure_server()
            warmup_model()
            console.print(f"Server ready at http://{SERVER_HOST}:{PORT} with model loaded")
            return 0

        if args.command == "resume":
            if args.session:
                path = Path(args.session)
                if not path.is_absolute():
                    candidate = SESSIONS_DIR / args.session
                    path = candidate if candidate.exists() else SESSIONS_DIR / f"{args.session}.json"
                if not path.exists():
                    console.print("Session not found.")
                    return 1
                history = load_session_history(path)
                session_id = path.stem
                console.print(f"Resuming {path.name}")
                return interactive_chat(None, ctx, session_id=session_id, history=history)
            if args.last:
                session = latest_session()
                if not session:
                    console.print("No sessions found.")
                    return 0
                history = load_session_history(session)
                console.print(f"Resuming {session.name}")
                return interactive_chat(None, ctx, session_id=session.stem, history=history)
            sessions = list_recent_sessions()[:10]
            if not sessions:
                console.print("No sessions found.")
                return 0
            chosen = choose_from_paths(sessions, "Recent Sessions")
            if not chosen:
                return 0
            history = load_session_history(chosen)
            console.print(f"Resuming {chosen.name}")
            return interactive_chat(None, ctx, session_id=chosen.stem, history=history)

        if args.command == "doctor":
            console.print(doctor_report(None, str(uuid.uuid4()), ctx))
            return 0

        if args.command in {"state", "artifacts"}:
            session_ref = getattr(args, "session", None)
            target_path: Path | None = None
            if session_ref:
                candidate = Path(session_ref)
                if candidate.exists():
                    target_path = candidate
                else:
                    repo_candidate = SESSIONS_DIR / session_ref
                    target_path = repo_candidate if repo_candidate.exists() else SESSIONS_DIR / f"{session_ref}.json"
            elif getattr(args, "last", False):
                target_path = latest_session()
            else:
                target_path = latest_session()
            if not target_path or not target_path.exists():
                console.print("Session not found.")
                return 1
            if args.command == "state":
                console.print(task_state_report(target_path.stem))
            else:
                console.print(artifact_report(target_path.stem, limit=max(1, int(getattr(args, "limit", 10)))))
            return 0

        if args.command == "eval":
            dataset = safe_path(args.dataset, ctx.cwd) if args.dataset else default_eval_dataset_path()
            if not dataset.exists():
                console.print(f"Eval dataset not found: {dataset}")
                return 1
            console.print(run_eval_suite(dataset))
            return 0

        if args.command == "apply":
            if args.patch:
                patch = safe_path(args.patch, ctx.cwd)
            else:
                patches = sorted(PATCHES_DIR.glob("*.patch"), key=lambda p: p.stat().st_mtime, reverse=True)[:10]
                if not patches:
                    console.print("No patch found.")
                    return 1
                patch = choose_from_paths(patches, "Recent Patches")
            if not patch or not patch.exists():
                console.print("No patch found.")
                return 1
            console.print(Rule("apply"))
            console.print(apply_patch_file(patch, ctx.cwd))
            return 0

        if args.command in {"auto", "exec"}:
            session_id = str(uuid.uuid4())
            render_log_line("ui", "working", COLOR_PLAN)
            result, _history = asyncio.run(tool_loop(mode_wrapped_task(args.task, ctx), ctx, session_id))
            console.print(render_final_panel(result))
            return 0

        if args.command == "code":
            session_id = str(uuid.uuid4())
            code_ctx = ToolContext(
                cwd=ctx.cwd,
                approval=ctx.approval,
                force=ctx.force,
                mode="code",
                narrate=ctx.narrate,
                dry_run=ctx.dry_run,
                profile=ctx.profile,
                network_access=ctx.network_access,
                tool_install=ctx.tool_install,
            )
            render_log_line("ui", "coding", COLOR_PLAN)
            result, _history = asyncio.run(tool_loop(mode_wrapped_task(args.task, code_ctx), code_ctx, session_id))
            console.print(render_final_panel(result))
            return 0

        if args.command == "review":
            session_id = str(uuid.uuid4())
            review_ctx = ToolContext(
                cwd=ctx.cwd,
                approval=ctx.approval,
                force=ctx.force,
                mode="review",
                narrate=ctx.narrate,
                dry_run=ctx.dry_run,
                profile=ctx.profile,
                network_access=ctx.network_access,
                tool_install=ctx.tool_install,
            )
            render_log_line("ui", "reviewing", COLOR_PLAN)
            result, _history = asyncio.run(tool_loop(mode_wrapped_task(args.task, review_ctx), review_ctx, session_id))
            console.print(render_final_panel(result))
            return 0

        if args.command == "audit":
            session_id = str(uuid.uuid4())
            audit_ctx = ToolContext(
                cwd=ctx.cwd,
                approval=ctx.approval,
                force=ctx.force,
                mode="audit",
                narrate=ctx.narrate,
                dry_run=ctx.dry_run,
                profile=ctx.profile,
                network_access=ctx.network_access,
                tool_install=ctx.tool_install,
            )
            render_log_line("ui", "auditing", COLOR_PLAN)
            result, _history = asyncio.run(tool_loop(mode_wrapped_task(args.task, audit_ctx), audit_ctx, session_id))
            console.print(render_final_panel(result))
            return 0

        # Show startup hint in interactive mode
        if sys.stdin.isatty() and args.command in {"auto", "chat", None}:
            console.print(
                "[dim]Network: on  |  Tool install: on  |  Mode: auto  |  /model to switch model  |  /help for commands[/dim]"
            )

        if args.command == "chat":
            return interactive_chat(args.task, ctx)

        if initial_prompt:
            return interactive_chat(initial_prompt, ctx)
        return interactive_chat(None, ctx)
    finally:
        if SERVER_STOP_ON_EXIT:
            clear_mico_heartbeat()
            stop_managed_server()


if __name__ == "__main__":
    raise SystemExit(main())
