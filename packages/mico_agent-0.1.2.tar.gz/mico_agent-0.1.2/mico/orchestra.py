from __future__ import annotations

import json
from typing import Any, Callable


async def request_architect_handoff(
    task: str,
    ctx: Any,
    state: Any,
    *,
    active_profile: Any,
    resolve_role_model: Callable[[str, Any], Any],
    extract_task_body: Callable[[str], str],
    build_task_state_prompt: Callable[[Any], str],
    build_system_prompt: Callable[[str, Any], str],
    call_model: Callable[..., Any],
    min_thinking_budget: int,
    extract_json: Callable[[str], dict[str, Any]],
    truncate: Callable[[str, int], str],
    render_log_line: Callable[[str, str, str], None],
    color_plan: str,
) -> dict[str, Any] | None:
    if active_profile is None or resolve_role_model("architect", active_profile) is None:
        return None
    prompt_text = (
        "Analyze the task and return exactly one JSON object with keys: summary, plan, files, risks, pending_tasks. "
        "plan/files/risks/pending_tasks must be arrays of short strings. "
        "Do not write code, patches, or commands.\n\n"
        f"Task:\n{extract_task_body(task)}\n\n"
        f"Task state:\n{build_task_state_prompt(state)}"
    )
    try:
        raw = await call_model(
            [
                {"role": "system", "content": build_system_prompt(task, ctx, role="architect")},
                {"role": "user", "content": prompt_text},
            ],
            thinking_budget=min_thinking_budget,
            stream=False,
            use_orchestra=False,
            role="architect",
        )
        data = extract_json(raw)
    except Exception as exc:
        render_log_line("orchestra", f"architect skipped: {truncate(str(exc), 180)}", color_plan)
        return None
    if data.get("type") == "final":
        try:
            parsed = json.loads(data.get("message", "{}"))
            if isinstance(parsed, dict):
                data = parsed
        except Exception:
            return None
    if not isinstance(data, dict):
        return None
    summary = str(data.get("summary", "")).strip()
    plan = [str(x).strip() for x in data.get("plan", []) if str(x).strip()]
    files = [str(x).strip() for x in data.get("files", []) if str(x).strip()]
    risks = [str(x).strip() for x in data.get("risks", []) if str(x).strip()]
    pending = [str(x).strip() for x in data.get("pending_tasks", []) if str(x).strip()]
    if not summary and not plan and not files:
        return None
    return {
        "summary": summary,
        "plan": plan,
        "files": files,
        "risks": risks,
        "pending_tasks": pending,
    }


async def request_reviewer_note(
    task: str,
    ctx: Any,
    state: Any,
    *,
    test_summary: str,
    active_profile: Any,
    resolve_role_model: Callable[[str, Any], Any],
    extract_task_body: Callable[[str], str],
    git_diff_patch: Callable[[Any, int], str],
    truncate: Callable[[str, int], str],
    request_role_action: Callable[[str, Any, str, str], Any],
    render_log_line: Callable[[str, str, str], None],
    color_plan: str,
) -> str:
    if active_profile is None or resolve_role_model("reviewer", active_profile) is None:
        return ""
    prompt_text = (
        "Review the change using only the task summary, git diff, and test result. "
        "Return exactly one JSON object: {\"type\":\"final\",\"message\":\"...\"}. "
        "Keep it short and actionable.\n\n"
        f"Task:\n{extract_task_body(task)}\n\n"
        f"Diff:\n{git_diff_patch(ctx.cwd, 4000)}\n\n"
        f"Tests:\n{truncate(test_summary or state.test_result or 'not run', 1500)}"
    )
    try:
        action, _raw = await request_role_action(task, ctx, "reviewer", prompt_text)
    except Exception as exc:
        render_log_line("orchestra", f"reviewer skipped: {truncate(str(exc), 180)}", color_plan)
        return ""
    if action.get("type") != "final":
        return ""
    return str(action.get("message", "")).strip()
