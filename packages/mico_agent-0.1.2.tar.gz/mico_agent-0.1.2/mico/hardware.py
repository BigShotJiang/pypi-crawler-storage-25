"""Donanım tespiti — macOS (Apple Silicon + Intel) ve Linux için.

İlk açılışta `~/.mico/hardware.json`'a yazılır, sonraki açılışlarda yeniden
tespit yapılmaz.
"""
from __future__ import annotations

import json
import os
import platform
import re
import shutil
import subprocess
from dataclasses import asdict, dataclass, field
from pathlib import Path
from typing import Any

CONFIG_DIR = Path(os.environ.get("MICO_HOME", str(Path.home() / ".mico")))
HARDWARE_PATH = CONFIG_DIR / "hardware.json"


@dataclass
class HardwareInfo:
    os: str                         # "darwin-arm64", "darwin-x86_64", "linux-x86_64", ...
    os_version: str = ""
    chip: str = ""                  # "Apple M3 Pro", "Intel Core i7-...", "AMD Ryzen 9 ..."
    cores_performance: int = 0
    cores_efficiency: int = 0
    cores_total: int = 0
    memory_gb: float = 0.0          # unified memory on Apple Silicon, system RAM elsewhere
    gpu_type: str = ""              # "apple-integrated", "nvidia", "amd", "intel", "none"
    gpu_name: str = ""
    gpu_memory_gb: float = 0.0      # 0 on UMA (shared with system)
    neural_engine: bool = False
    backends: list[str] = field(default_factory=list)  # e.g. ["mlx", "metal"]
    raw: dict[str, Any] = field(default_factory=dict)  # raw probe data, debug only

    def summary(self) -> str:
        lines = [
            f"OS         : {self.os} {self.os_version}".rstrip(),
            f"Chip       : {self.chip or 'unknown'}",
            f"Cores      : {self.cores_total} (P:{self.cores_performance} E:{self.cores_efficiency})",
            f"Memory     : {self.memory_gb:.1f} GB" + (" (unified)" if self.gpu_type == "apple-integrated" else ""),
            f"GPU        : {self.gpu_name or self.gpu_type or 'none'}"
            + (f" ({self.gpu_memory_gb:.1f} GB)" if self.gpu_memory_gb else ""),
        ]
        if self.neural_engine:
            lines.append("Neural Eng : yes")
        if self.backends:
            lines.append(f"Backends   : {', '.join(self.backends)}")
        return "\n".join(lines)


def _run(cmd: list[str], timeout: int = 6) -> str:
    try:
        out = subprocess.run(cmd, capture_output=True, text=True, timeout=timeout)
        return out.stdout
    except (FileNotFoundError, subprocess.TimeoutExpired, OSError):
        return ""


def _detect_macos() -> HardwareInfo:
    info = HardwareInfo(os=f"darwin-{platform.machine()}")
    info.os_version = platform.mac_ver()[0]

    raw_hw = _run(["system_profiler", "SPHardwareDataType", "-json"])
    try:
        data = json.loads(raw_hw).get("SPHardwareDataType", [{}])[0]
    except Exception:
        data = {}

    info.raw["SPHardwareDataType"] = data
    info.chip = data.get("chip_type") or data.get("cpu_type") or ""
    info.cores_total = int(re.search(r"\d+", data.get("number_processors", "0") or "0").group() or 0) if data.get("number_processors") else 0

    cores_str = data.get("number_processors", "")
    pe = re.search(r"\((\d+)\s*performance.*?(\d+)\s*efficiency", cores_str or "", re.I)
    if pe:
        info.cores_performance = int(pe.group(1))
        info.cores_efficiency = int(pe.group(2))

    mem_raw = _run(["sysctl", "-n", "hw.memsize"]).strip()
    if mem_raw.isdigit():
        info.memory_gb = round(int(mem_raw) / (1024**3), 1)

    is_apple_silicon = platform.machine() == "arm64"
    if is_apple_silicon:
        info.gpu_type = "apple-integrated"
        info.gpu_name = info.chip
        info.gpu_memory_gb = 0.0  # unified
        info.neural_engine = True
        info.backends = ["mlx", "metal"]
    else:
        # Intel Mac — try to read GPU
        raw_disp = _run(["system_profiler", "SPDisplaysDataType", "-json"])
        try:
            disp = json.loads(raw_disp).get("SPDisplaysDataType", [])
            if disp:
                d = disp[0]
                info.gpu_name = d.get("sppci_model", "")
                info.gpu_type = "intel" if "intel" in info.gpu_name.lower() else (
                    "amd" if any(x in info.gpu_name.lower() for x in ("amd", "radeon")) else "unknown"
                )
                vram = d.get("spdisplays_vram_shared", "") or d.get("spdisplays_vram", "")
                m = re.search(r"(\d+)\s*(GB|MB)", vram, re.I)
                if m:
                    val = int(m.group(1))
                    info.gpu_memory_gb = val if m.group(2).upper() == "GB" else round(val / 1024, 2)
        except Exception:
            pass
        info.backends = ["metal"]

    return info


def _detect_linux() -> HardwareInfo:
    info = HardwareInfo(os=f"linux-{platform.machine()}")
    info.os_version = platform.release()

    try:
        cpuinfo = Path("/proc/cpuinfo").read_text()
        m = re.search(r"^model name\s*:\s*(.+)$", cpuinfo, re.M)
        info.chip = (m.group(1).strip() if m else "")
        info.cores_total = len(re.findall(r"^processor\s*:", cpuinfo, re.M))
    except OSError:
        pass

    try:
        meminfo = Path("/proc/meminfo").read_text()
        m = re.search(r"^MemTotal:\s+(\d+)\s*kB", meminfo, re.M)
        if m:
            info.memory_gb = round(int(m.group(1)) / (1024**2), 1)
    except OSError:
        pass

    if shutil.which("nvidia-smi"):
        smi = _run(["nvidia-smi", "--query-gpu=name,memory.total", "--format=csv,noheader,nounits"])
        line = smi.strip().splitlines()[0] if smi.strip() else ""
        if line:
            parts = [p.strip() for p in line.split(",")]
            info.gpu_name = parts[0]
            info.gpu_type = "nvidia"
            try:
                info.gpu_memory_gb = round(float(parts[1]) / 1024, 1)
            except (ValueError, IndexError):
                pass
            info.backends = ["cuda"]
    else:
        # Best-effort: lspci for AMD/Intel
        lspci = _run(["lspci"])
        for line in lspci.splitlines():
            if "VGA" in line or "3D controller" in line:
                low = line.lower()
                if "amd" in low or "radeon" in low:
                    info.gpu_type = "amd"
                elif "intel" in low:
                    info.gpu_type = "intel"
                else:
                    info.gpu_type = "unknown"
                info.gpu_name = line.split(":", 2)[-1].strip()
                break
        info.backends = ["cpu"]

    return info


def detect_hardware() -> HardwareInfo:
    """Probe the current machine. Cheap (~50ms). No caching here — use load/save."""
    sysname = platform.system().lower()
    if sysname == "darwin":
        return _detect_macos()
    if sysname == "linux":
        return _detect_linux()
    info = HardwareInfo(os=f"{sysname}-{platform.machine()}")
    info.os_version = platform.release()
    return info


def save_hardware(info: HardwareInfo, path: Path = HARDWARE_PATH) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    payload = asdict(info)
    payload.pop("raw", None)  # raw can be large + may leak system specifics
    path.write_text(json.dumps(payload, indent=2, ensure_ascii=False), encoding="utf-8")


def load_hardware(path: Path = HARDWARE_PATH) -> HardwareInfo | None:
    if not path.exists():
        return None
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
        return HardwareInfo(**data)
    except (OSError, json.JSONDecodeError, TypeError):
        return None


def get_or_detect(path: Path = HARDWARE_PATH) -> HardwareInfo:
    cached = load_hardware(path)
    if cached is not None:
        return cached
    info = detect_hardware()
    save_hardware(info, path)
    return info


if __name__ == "__main__":
    info = detect_hardware()
    print(info.summary())
