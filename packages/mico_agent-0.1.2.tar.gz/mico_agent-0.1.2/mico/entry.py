"""mico CLI entry point.

Akış:
  1. Bağımlılık kontrolü (gerekirse onay + kurulum)
  2. Setup wizard (yoksa)
  3. Komuta göre dispatch:
       mico                    → REPL
       mico ask "prompt"       → tek seferlik
       mico setup [--force]    → wizard tekrar
       mico models             → algılanan modeller
       mico --doctor           → tanı çıktısı
       mico --version          → sürüm
"""
from __future__ import annotations

import argparse
import os
import sys
from pathlib import Path

from . import __version__


def _try_reexec_venv_early() -> None:
    """main() başlamadan önce: eğer ~/.mico/.venv varsa ve şu an orada değilsek, oraya geç.

    Bu sayede deps kontrolü (mlx importlanabilir mi?) venv python'u üzerinden yapılır.
    Binary python (ör. python3.14) ile venv python (ör. python3.13) farklıysa
    her açılışta mlx "eksik" görünme sorunu ortadan kalkar.
    """
    if os.environ.get("_MICO_REEXECED") == "1":
        return
    config_dir = Path(os.environ.get("MICO_HOME", str(Path.home() / ".mico")))
    venv_python = config_dir / ".venv" / "bin" / "python"
    if not venv_python.exists():
        return
    # Zaten bu venv'den mi çalışıyoruz?
    try:
        current_exe = Path(sys.executable).resolve()
        venv_exe = venv_python.resolve()
        if current_exe == venv_exe:
            return  # zaten doğru python
    except Exception:
        return
    # mico bu venv'de importlanabilir mi? (tek subprocess, combine check)
    try:
        import subprocess
        check = subprocess.run(
            [str(venv_python), "-c", "import mico"],
            capture_output=True, timeout=4,
        )
        if check.returncode != 0:
            return  # venv'de mico yok, geçiş yapma
    except Exception:
        return
    os.environ["_MICO_REEXECED"] = "1"
    os.execv(str(venv_python), [str(venv_python), "-m", "mico.entry"] + sys.argv[1:])


def _build_parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(prog="mico", description="local coding agent")
    p.add_argument("--version", action="version", version=f"mico {__version__}")
    p.add_argument("--doctor", action="store_true", help="Tanı raporu yazdır ve çık")
    sub = p.add_subparsers(dest="cmd")

    sub.add_parser("setup", help="Sihirbazı yeniden çalıştır").add_argument(
        "--force", action="store_true"
    )
    ask_p = sub.add_parser("ask", help="Tek seferlik prompt")
    ask_p.add_argument("prompt", nargs="+")

    models_p = sub.add_parser("models", help="Algılanan modelleri listele / indir")
    models_p.add_argument("--download", metavar="HF_REPO", help="HuggingFace repo'su indir (örn: mlx-community/Qwen3-8B-4bit)")
    models_p.add_argument("--dest", metavar="DIR", help="İndirme hedefi (varsayılan: ~/Desktop/models/)")
    models_p.add_argument("--scan", action="store_true", help="Sistem geneli tarama yap")
    sub.add_parser("server-stop", help="Çalışan model sunucusunu durdur")
    repl_p = sub.add_parser("repl", help="Interaktif REPL (default)")
    repl_p.add_argument("--non-interactive", action="store_true",
                        help="Etkileşim yok (CI / script kullanımı)")

    return p


def cmd_doctor() -> int:
    from . import hardware, model_recommender, setup_wizard
    from . import dependency_consent as dc

    sys.stdout.write(f"mico {__version__}\n")

    # Python environment details
    py_exe = Path(sys.executable).resolve()
    py_version = sys.version.split()[0]
    mico_venv_bin = dc.MICO_VENV_PYTHON.parent  # ~/.mico/.venv/bin/
    pointer = dc.read_python_pointer()
    try:
        py_exe.relative_to(mico_venv_bin.resolve())
        py_origin = "mico adanmış venv"
    except ValueError:
        if pointer and py_exe == pointer.resolve():
            py_origin = f"donor venv (işaret: {pointer})"
        else:
            py_origin = "sistem Python"
    sys.stdout.write(f"Python      : {py_version} @ {py_exe}  [{py_origin}]\n")
    sys.stdout.write(f"Adanmış venv: {dc.MICO_VENV_PYTHON.parent.parent}  "
                     f"({'var' if dc.MICO_VENV_PYTHON.parent.parent.exists() else 'yok'})\n")

    hw = hardware.load_hardware() or hardware.detect_hardware()
    sys.stdout.write("\n--- Donanım ---\n")
    sys.stdout.write(hw.summary() + "\n")

    sys.stdout.write("\n--- Profil ---\n")
    prof = model_recommender.load_profile()
    if prof:
        sys.stdout.write(f"name        : {prof.name}\n")
        sys.stdout.write(f"model       : {prof.model_name}\n")
        sys.stdout.write(f"path        : {prof.model_path}\n")
        sys.stdout.write(f"context     : {prof.context_window}\n")
        sys.stdout.write(f"kv_bits     : {prof.kv_bits or 'full'}\n")
    else:
        sys.stdout.write("(profil yok — `mico setup` çalıştır)\n")

    sys.stdout.write(f"\nKonfig dizini: {setup_wizard.CONFIG_DIR}\n")
    sys.stdout.write(f"Setup tamam : {setup_wizard.is_setup_complete()}\n")
    return 0


def cmd_models(download: str | None = None, dest: str | None = None, scan: bool = False) -> int:
    from . import model_recommender as mr

    if download:
        return _cmd_download(download, dest)

    if scan:
        sys.stdout.write("Sistem geneli taranıyor (maks 8 saniye)...\n")
        entries = mr.discover_all_system_models()
    else:
        entries = mr.discover_models()

    if not entries:
        sys.stdout.write("Model bulunamadı. `mico models --scan` ile tüm sistemi tara.\n")
        return 1

    sys.stdout.write(f"{len(entries)} model:\n")
    for e in entries:
        params = f"{e.params_b}B" if e.params_b else "?B"
        quant = f"{e.quant_bits}-bit" if e.quant_bits else "?"
        sys.stdout.write(
            f"  {e.name:50} {params:6}  {quant:6}  {e.backend:12}  {e.size_gb}GB\n"
            f"    {e.path}\n"
        )
    return 0


def _cmd_download(repo: str, dest: str | None) -> int:
    """Download a HuggingFace model repo to local disk."""
    from pathlib import Path
    import subprocess

    # Parse HF URL or repo id
    repo_id = repo
    if "huggingface.co/" in repo:
        # https://huggingface.co/org/model → org/model
        parts = repo.split("huggingface.co/")[-1].strip("/").split("/")
        repo_id = "/".join(parts[:2])

    dest_dir = Path(dest).expanduser() if dest else Path.home() / "Desktop" / "models"
    dest_dir.mkdir(parents=True, exist_ok=True)

    model_name = repo_id.split("/")[-1]
    target = dest_dir / model_name
    sys.stdout.write(f"İndiriliyor: {repo_id}\n")
    sys.stdout.write(f"Hedef: {target}\n\n")

    # Try huggingface-cli first (fast, handles auth)
    hf_cli = Path(os.environ.get("MICO_HOME", str(Path.home() / ".mico"))) / ".venv" / "bin" / "huggingface-cli"
    if not hf_cli.exists():
        import shutil
        hf_cli_path = shutil.which("huggingface-cli")
        hf_cli = Path(hf_cli_path) if hf_cli_path else None

    if hf_cli and hf_cli.exists():
        cmd = [
            str(hf_cli), "download",
            repo_id,
            "--local-dir", str(target),
            "--local-dir-use-symlinks", "False",
        ]
        sys.stdout.write(f"Komut: {' '.join(cmd)}\n\n")
        try:
            result = subprocess.run(cmd)
            if result.returncode == 0:
                weight_files = list(target.glob("*.safetensors")) + list(target.glob("*.bin"))
                if not weight_files:
                    sys.stdout.write(
                        f"\nUYARI: İndirme tamamlandı fakat {target} içinde ağırlık dosyası bulunamadı.\n"
                        "Modelin yalnızca config/tokenizer dosyaları var olabilir.\n"
                    )
                    return 1
                sys.stdout.write(f"\nİndirildi: {target}\n")
                sys.stdout.write(f"Ağırlık dosyaları: {len(weight_files)} adet\n")
                sys.stdout.write("Listeyi yenilemek için: mico models\n")
                return 0
            sys.stdout.write(f"hf-cli hata kodu: {result.returncode}\n")
        except FileNotFoundError:
            pass

    # Fallback: git clone (requires git-lfs for binary weights)
    import shutil as _shutil
    git_lfs = _shutil.which("git-lfs")
    if not git_lfs:
        sys.stdout.write(
            "\nHATA: huggingface-cli bulunamadı ve git-lfs yüklü değil.\n"
            "Model dosyaları (*.safetensors) git-lfs olmadan indirilemez — sadece pointer dosyaları iner.\n\n"
            "Çözüm (birini seç):\n"
            "  pip install huggingface_hub && huggingface-cli download "
            f"{repo_id} --local-dir {target}\n"
            "  brew install git-lfs && git lfs install  (ardından tekrar dene)\n"
        )
        return 1

    sys.stdout.write("huggingface-cli bulunamadı, git clone (git-lfs) deneniyor...\n")
    hf_url = f"https://huggingface.co/{repo_id}"
    try:
        result = subprocess.run(
            ["git", "clone", "--depth=1", hf_url, str(target)],
        )
        if result.returncode == 0:
            # Verify model weights actually downloaded (not just LFS pointers)
            weight_files = list(target.glob("*.safetensors")) + list(target.glob("*.bin"))
            if not weight_files:
                sys.stdout.write(
                    f"\nUYARI: {target} klasörüne indirildi fakat ağırlık dosyası "
                    "(*.safetensors / *.bin) bulunamadı.\n"
                    "git-lfs pointer'ları indirilmiş olabilir. Kontrol: git lfs ls-files\n"
                    "Doğrudan indirme için:\n"
                    f"  pip install huggingface_hub\n"
                    f"  huggingface-cli download {repo_id} --local-dir {target}\n"
                )
                return 1
            sizes = [f.stat().st_size for f in weight_files]
            tiny = [f for f, s in zip(weight_files, sizes) if s < 1024]
            if tiny:
                sys.stdout.write(
                    "\nUYARI: Bazı ağırlık dosyaları çok küçük (LFS pointer olabilir):\n"
                    + "\n".join(f"  {f.name} ({f.stat().st_size} byte)" for f in tiny) + "\n"
                    "git lfs pull ile gerçek dosyaları çek.\n"
                )
                return 1
            sys.stdout.write(f"\nİndirildi: {target}\n")
            sys.stdout.write(f"Ağırlık dosyaları: {len(weight_files)} adet\n")
            sys.stdout.write("Listeyi yenilemek için: mico models\n")
            return 0
    except Exception as e:
        sys.stdout.write(f"git clone hatası: {e}\n")

    sys.stdout.write(
        "\nManuel indirme:\n"
        f"  pip install huggingface_hub\n"
        f"  huggingface-cli download {repo_id} --local-dir {target}\n"
    )
    return 1


def cmd_server_stop() -> int:
    from . import server
    server.stop()
    sys.stdout.write("Server durduruldu.\n")
    return 0


def cmd_setup(force: bool) -> int:
    from .setup_wizard import run_wizard
    run_wizard(force=force)
    return 0


def _external_profile_from_env():
    """Build a minimal profile for an already-running OpenAI-compatible server.

    Set MICO_EXTERNAL_API_BASE and MICO_EXTERNAL_MODEL to point mico at any
    OpenAI-compatible endpoint (e.g. a manually started mlx_lm server).
    """
    api_base = os.environ.get("MICO_EXTERNAL_API_BASE", "").strip().rstrip("/")
    model = os.environ.get("MICO_EXTERNAL_MODEL", "").strip()
    if not api_base or not model:
        return None

    from .model_recommender import Profile

    def _int_env(name: str, default: int) -> int:
        raw = os.environ.get(name, "").strip()
        try:
            return int(raw) if raw else default
        except ValueError:
            return default

    def _float_env(name: str, default: float) -> float:
        raw = os.environ.get(name, "").strip()
        try:
            return float(raw) if raw else default
        except ValueError:
            return default

    thinking_raw = os.environ.get("MICO_EXTERNAL_THINKING", "false").strip().lower()
    return Profile(
        name=os.environ.get("MICO_EXTERNAL_PROFILE", "external"),
        backend=os.environ.get("MICO_EXTERNAL_PROVIDER", "openai"),
        model_path=model,
        model_name=model,
        context_window=_int_env("MICO_EXTERNAL_CONTEXT_WINDOW", 8192),
        max_tokens=_int_env("MICO_EXTERNAL_MAX_TOKENS", 4096),
        thinking=thinking_raw in {"1", "true", "yes", "on", "e", "evet"},
        thinking_budget=_int_env("MICO_EXTERNAL_THINKING_BUDGET", 0),
        temperature=_float_env("MICO_EXTERNAL_TEMPERATURE", 0.0),
    )


def cmd_ask(prompt: str) -> int:
    """Single-shot ask: start server, run one turn, exit."""
    from .setup_wizard import run_wizard
    import os
    import asyncio
    from . import cli as mico_cli
    from . import server as server_mod

    profile = run_wizard()

    from .model_recommender import _apply_family_sampling
    _apply_family_sampling(profile, profile.model_name or profile.model_path)

    pl = (profile.model_path or "").lower()
    if profile.backend != "mlx" and ("/mlx/" in pl or "mlx" in pl.rsplit("/", 1)[-1] or "mxfp" in pl):
        profile.backend = "mlx"

    os.environ["QWEN36_SESSION_MANAGED"] = "1"
    os.environ["MICO_NETWORK_ACCESS"] = "1"

    mico_cli.MODEL = profile.model_path
    mico_cli.MAX_TOKENS = profile.max_tokens
    mico_cli.CONTEXT_WINDOW_TOKENS = profile.context_window
    mico_cli.THINKING = profile.thinking
    mico_cli.THINKING_BUDGET = profile.thinking_budget
    mico_cli.TEMPERATURE = profile.temperature
    mico_cli.SESSION_MANAGED_EXTERNALLY = True
    mico_cli.USE_PLAIN_STDOUT = True

    async def _run() -> None:
        if profile.backend == "mlx":
            loop = asyncio.get_event_loop()
            chosen_port = await loop.run_in_executor(None, server_mod.start, profile)
            mico_cli.API_BASE = f"http://127.0.0.1:{chosen_port}/v1"
            mico_cli.PORT = chosen_port
        await mico_cli.run_single_turn(prompt, session_id="ask")

    asyncio.run(_run())
    return 0


def cmd_repl(non_interactive: bool = False) -> int:
    from .setup_wizard import run_wizard
    from . import slash
    external_api_base = os.environ.get("MICO_EXTERNAL_API_BASE", "").strip().rstrip("/")
    external_profile = _external_profile_from_env()
    profile = external_profile or run_wizard()

    # Diskten yüklenen profilde family sampling ayarlarını güncelle.
    # run_wizard() eski profile.json'u döndürebilir; o dosya yeni
    # _apply_family_sampling mantığından önce kaydedilmiş olabilir.
    if not external_profile:
        from .model_recommender import _apply_family_sampling
        _apply_family_sampling(profile, profile.model_name or profile.model_path)

    # Path-based MLX rescue: older wizard runs (before the config.json
    # quantization detection fix) saved backend="safetensors" for genuine MLX
    # models. If the path itself looks like an MLX checkpoint, override.
    pl = (profile.model_path or "").lower()
    if profile.backend != "mlx" and ("/mlx/" in pl or "mlx" in pl.rsplit("/", 1)[-1] or "mxfp" in pl):
        sys.stdout.write("\n[mico] Profil 'safetensors' olarak işaretli ama model yolu MLX gibi görünüyor; backend MLX'e ayarlandı.\n")
        sys.stdout.write("       Daha temiz bir profil için: `mico setup --force`\n")
        profile.backend = "mlx"

    external_server = external_profile is not None

    # Ensure backend-specific deps based on model type. External servers
    # (MICO_EXTERNAL_API_BASE) already handle the runner, so skip dep checks.
    if not external_server:
        from .dependency_consent import ensure_runtime_deps
        from .server import _is_vlm_model, _is_mtplx_model
        if profile.backend == "mtplx" or _is_mtplx_model(profile.model_path):
            backends = ["mtplx"]
        elif profile.backend == "mlx":
            if _is_vlm_model(profile.model_path):
                backends = ["mlx_vlm"]
            else:
                backends = ["mlx"]
        else:
            backends = []
        ensure_runtime_deps(include_backends=backends, non_interactive=non_interactive)

    # Server is started by us (mico.server), not by cli.py's bin/qwen36-session
    # legacy shell script. Mark it managed externally so cli.py won't try to
    # acquire/release the session.
    os.environ["QWEN36_SESSION_MANAGED"] = "1"

    # Enable network access by default in interactive mode
    os.environ["MICO_NETWORK_ACCESS"] = "1"

    # Apply profile to env (some cli.py paths read os.environ directly).
    os.environ.setdefault("MODEL", profile.model_path)
    os.environ.setdefault("MICO_CONTEXT_WINDOW", str(profile.context_window))

    # LAZY MODEL LOADING: Don't start server yet, defer until first user message

    from .repl import run_repl, StreamWriter
    from . import cli as mico_cli
    from . import spinner as spinner_mod
    from . import server as server_mod

    # Override cli.py module-level constants from the chosen profile. cli.py
    # reads these at import time from CONFIG (config.env file); since we don't
    # use that file in the public release, push values directly.
    mico_cli.MODEL = profile.model_path
    if external_server:
        mico_cli.MODEL_PROVIDER = "openai"
        mico_cli.API_BASE = external_api_base
        mico_cli.API_KEY = os.environ.get("MICO_EXTERNAL_API_KEY", "local")
        os.environ["API_BASE_URL"] = external_api_base
        os.environ["API_KEY_VALUE"] = mico_cli.API_KEY
        os.environ["MODEL_PROVIDER"] = mico_cli.MODEL_PROVIDER
        os.environ["MODEL_NAME"] = profile.model_path
    mico_cli.MAX_TOKENS = profile.max_tokens
    mico_cli.CONTEXT_WINDOW_TOKENS = profile.context_window
    mico_cli.THINKING = profile.thinking
    mico_cli.THINKING_BUDGET = profile.thinking_budget
    mico_cli.TEMPERATURE = profile.temperature
    mico_cli.DEFAULT_NETWORK_ACCESS = True
    mico_cli.OFFLINE = False
    mico_cli.SESSION_MANAGED_EXTERNALLY = True
    mico_cli.DRAFT_MODEL = profile.draft_model_path or ""
    os.environ["DRAFT_MODEL_NAME"] = profile.draft_model_path or ""

    # Compact thresholds: trigger at 70% of context window (in chars, ~4 chars/token).
    # Keep the last 20% worth of messages as uncompacted tail.
    _ctx_chars = profile.context_window * 4
    mico_cli.HISTORY_COMPACT_CHAR_TRIGGER = int(_ctx_chars * 0.70)
    mico_cli.AUTO_COMPACT_RATIO = 0.70

    # Prompt cache: sync from profile so server and cli agree.
    mico_cli.SERVER_PROMPT_CACHE_SIZE = str(profile.prompt_cache_size)
    mico_cli.SERVER_PROMPT_CACHE_BYTES = profile.prompt_cache_bytes

    session_id = "interactive"

    # Her açılış temiz başlar — önceki oturum previous.json'a taşınır, /resume ile geri alınır
    _session_file = mico_cli.SESSIONS_DIR / f"{session_id}.json"
    _prev_file = mico_cli.SESSIONS_DIR / "interactive.previous.json"
    if _session_file.exists():
        try:
            _session_file.rename(_prev_file)
        except Exception:
            _session_file.unlink(missing_ok=True)

    # Create mutable runtime state for slash commands
    runtime_state = slash.RuntimeState(
        profile=profile,
        mode="auto",
        network_access=getattr(mico_cli, "NETWORK_ACCESS", True),  # Default ON in interactive mode
        thinking=profile.thinking,
        cwd=os.getcwd(),
        session_id=session_id,
    )
    runtime_state.server_started = external_server

    # Discover skills
    from .skill_loader import discover_skills
    discover_skills(runtime_state)

    # Expose runtime_state to cli.py so streaming layer can push tok/s telemetry.
    mico_cli.RUNTIME_STATE = runtime_state

    async def handle_message(line: str, out: StreamWriter, spinner: spinner_mod.Spinner) -> None:
        # Make spinner available to render_log_line so it can pause before printing
        mico_cli._ACTIVE_SPINNER = spinner

        # Sync runtime state back to cli.py module-level constants before each turn
        mico_cli.THINKING = runtime_state.thinking
        mico_cli.NETWORK_ACCESS = runtime_state.network_access
        mico_cli.DEFAULT_NETWORK_ACCESS = runtime_state.network_access

        # Sync effort → thinking + iteration limit.
        if runtime_state.effort == "low":
            mico_cli.THINKING = False
            mico_cli.THINKING_BUDGET = 0
            mico_cli.EFFORT_MAX_ITERATIONS = 12
        elif runtime_state.effort == "medium":
            mico_cli.THINKING = True
            mico_cli.THINKING_BUDGET = max(512, runtime_state.profile.thinking_budget)
            mico_cli.EFFORT_MAX_ITERATIONS = 24
        else:  # high
            mico_cli.THINKING = True
            mico_cli.THINKING_BUDGET = max(2048, runtime_state.profile.thinking_budget)
            mico_cli.EFFORT_MAX_ITERATIONS = mico_cli.DEFAULT_ITERATIONS

        # Sync dry-run mode
        mico_cli.RUNTIME_DRYRUN = runtime_state.dryrun

        def on_phase_change(phase_name: str) -> None:
            """Callback from JsonStreamFilter to update spinner message."""
            if phase_name == "yanıt geliyor":
                spinner.update("yanıt geliyor...")
            elif phase_name == "yazıyor":
                spinner.update("yazıyor...")

        # LAZY LOAD: Start server on first message, or after model switch
        if not runtime_state.server_started:
            if runtime_state.profile.backend == "mlx":
                spinner.pause()
                try:
                    import asyncio as _asyncio
                    loop = _asyncio.get_event_loop()
                    chosen_port = await loop.run_in_executor(
                        None, server_mod.start, runtime_state.profile
                    )
                    mico_cli.API_BASE = f"http://127.0.0.1:{chosen_port}/v1"
                    mico_cli.PORT = chosen_port
                    mico_cli.MODEL = runtime_state.profile.model_path
                    # Sync role base_url to actual server port
                    if mico_cli.ACTIVE_PROFILE is not None:
                        _new_base = f"http://127.0.0.1:{chosen_port}/v1"
                        for _cfg in mico_cli.ACTIVE_PROFILE.roles.values():
                            if "127.0.0.1" in _cfg.base_url or "localhost" in _cfg.base_url:
                                _cfg.base_url = _new_base
                    try:
                        from . import server_watcher
                        server_watcher.start(host="127.0.0.1", port=chosen_port)
                    except Exception:
                        pass
                except Exception as exc:
                    spinner.resume()
                    out.writeln(f"✗ Model yüklenemedi: {exc}")
                    raise
                finally:
                    spinner.resume()
            runtime_state.server_started = True

        spinner.start("düşünüyor...")
        try:
            await mico_cli.run_single_turn(line, session_id=session_id, phase_change_callback=on_phase_change)
        finally:
            spinner.stop()

    return run_repl(profile, handle_message=handle_message, runtime_state=runtime_state)


def main(argv: list[str] | None = None) -> int:
    _try_reexec_venv_early()
    args = _build_parser().parse_args(argv)

    if args.doctor:
        return cmd_doctor()

    cmd = args.cmd or "repl"
    if cmd == "setup":
        return cmd_setup(force=getattr(args, "force", False))
    if cmd == "models":
        return cmd_models(
            download=getattr(args, "download", None),
            dest=getattr(args, "dest", None),
            scan=getattr(args, "scan", False),
        )
    if cmd == "server-stop":
        return cmd_server_stop()
    if cmd == "ask":
        return cmd_ask(" ".join(args.prompt))
    if cmd == "repl":
        return cmd_repl(non_interactive=getattr(args, 'non_interactive', False))
    return 1


if __name__ == "__main__":
    sys.exit(main())
