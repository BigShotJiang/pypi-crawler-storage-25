from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Optional, Union


@dataclass
class BaseAction:
    type: str


@dataclass
class FinalAction(BaseAction):
    type: str = "final"
    message: str = ""


@dataclass
class PatchAction(BaseAction):
    type: str = "patch"
    file_path: str = ""
    patch: str = ""


@dataclass
class ToolAction(BaseAction):
    type: str = "tool"
    tool: str = ""


@dataclass
class BashAction(ToolAction):
    tool: str = "bash"
    command: str = ""
    timeout: Optional[int] = 120000


@dataclass
class ReadFileAction(ToolAction):
    tool: str = "read_file"
    path: str = ""


@dataclass
class ListFilesAction(ToolAction):
    tool: str = "list_files"
    path: str = "."


@dataclass
class WriteFileAction(ToolAction):
    tool: str = "write_file"
    path: str = ""
    content: str = ""


@dataclass
class ReplaceInFileAction(ToolAction):
    tool: str = "replace_in_file"
    path: str = ""
    pattern: str = ""
    replacement: str = ""


@dataclass
class MacosAdminTaskAction(ToolAction):
    tool: str = "macos_admin_task"
    name: str = ""
    args: dict[str, Any] = field(default_factory=dict)


@dataclass
class GrepCodeAction(ToolAction):
    tool: str = "grep_code"
    pattern: str = ""
    path: str = "."
    include: Optional[str] = None


@dataclass
class HttpRequestAction(ToolAction):
    tool: str = "http_request"
    url: str = ""
    method: str = "GET"
    headers: dict[str, str] = field(default_factory=dict)
    body: Optional[str] = None
    timeout: int = 120000


@dataclass
class GitToolAction(ToolAction):
    tool: str = "git_tool"
    op: str = ""
    args: list[str] = field(default_factory=list)


@dataclass
class FindInFilesAction(ToolAction):
    tool: str = "find_in_files"
    pattern: str = ""
    path: str = "."


@dataclass
class CreateDirAction(ToolAction):
    tool: str = "create_dir"
    path: str = ""


@dataclass
class MoveFileAction(ToolAction):
    tool: str = "move_file"
    src: str = ""
    dst: str = ""


@dataclass
class DeleteFileAction(ToolAction):
    tool: str = "delete_file"
    path: str = ""


@dataclass
class PythonRunAction(ToolAction):
    tool: str = "python_run"
    code: str = ""


@dataclass
class RagSearchAction(ToolAction):
    tool: str = "rag_search"
    query: str = ""
    n_results: Optional[int] = 5


@dataclass
class WebFetchAction(ToolAction):
    tool: str = "web_fetch"
    url: str = ""


@dataclass
class EnvInfoAction(ToolAction):
    tool: str = "env_info"
    keys: Optional[list[str]] = None


@dataclass
class JsonQueryAction(ToolAction):
    tool: str = "json_query"
    path: str = ""
    query: str = ""


@dataclass
class FinishAction(ToolAction):
    tool: str = "finish"
    message: str = ""


ActionUnion = Union[
    FinalAction,
    PatchAction,
    BashAction,
    ReadFileAction,
    ListFilesAction,
    WriteFileAction,
    ReplaceInFileAction,
    MacosAdminTaskAction,
    GrepCodeAction,
    HttpRequestAction,
    GitToolAction,
    FindInFilesAction,
    CreateDirAction,
    MoveFileAction,
    DeleteFileAction,
    PythonRunAction,
    RagSearchAction,
    WebFetchAction,
    EnvInfoAction,
    JsonQueryAction,
    FinishAction,
]

_TOOL_CLASSES: dict[str, type] = {
    "bash": BashAction,
    "read_file": ReadFileAction,
    "list_files": ListFilesAction,
    "write_file": WriteFileAction,
    "replace_in_file": ReplaceInFileAction,
    "macos_admin_task": MacosAdminTaskAction,
    "grep_code": GrepCodeAction,
    "http_request": HttpRequestAction,
    "git_tool": GitToolAction,
    "find_in_files": FindInFilesAction,
    "create_dir": CreateDirAction,
    "move_file": MoveFileAction,
    "delete_file": DeleteFileAction,
    "python_run": PythonRunAction,
    "rag_search": RagSearchAction,
    "web_fetch": WebFetchAction,
    "env_info": EnvInfoAction,
    "json_query": JsonQueryAction,
    "finish": FinishAction,
}


# Fields that must be non-empty in the incoming data (tool → set of required keys)
_REQUIRED_FIELDS: dict[str, set[str]] = {
    "read_file": {"path"},
    "write_file": {"path", "content"},
    "replace_in_file": {"path", "old", "new"},
    "bash": {"command"},
    "grep_code": {"pattern"},
    "find_in_files": {"pattern"},
    "git_tool": {"op"},
    "python_run": {"code"},
    "http_request": {"url"},
    "json_query": {"path"},
    "parse_json_file": {"path"},
    "create_dir": {"path"},
    "move_file": {"src", "dst"},
    "delete_file": {"path"},
    "rag_search": {"query"},
    "web_fetch": {"url"},
}


def validate_action(data: dict[str, Any]) -> ActionUnion:
    import dataclasses

    action_type = data.get("type")
    if action_type == "final":
        return FinalAction(type="final", message=str(data.get("message", "")))
    if action_type == "patch":
        return PatchAction(
            type="patch",
            file_path=str(data.get("file_path", "")),
            patch=str(data.get("patch", "")),
        )
    if action_type == "tool":
        tool = data.get("tool")
        cls = _TOOL_CLASSES.get(str(tool or ""))
        if cls is None:
            raise ValueError(f"Unknown tool: {tool}")
        # Check required fields are present and non-empty
        required = _REQUIRED_FIELDS.get(str(tool), set())
        for key in required:
            if not data.get(key):
                raise ValueError(f"tool '{tool}' requires '{key}'")
        valid_fields = {f.name for f in dataclasses.fields(cls)}
        filtered = {k: v for k, v in data.items() if k in valid_fields}
        return cls(**filtered)
    raise ValueError(f"Unknown action type: {action_type}")
