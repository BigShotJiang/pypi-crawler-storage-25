"""Preflight checks and model sanity validation for mico."""
from __future__ import annotations

import re
import subprocess
from dataclasses import dataclass, field
from pathlib import Path
from typing import Optional

import requests


@dataclass
class ModelSanityResult:
    """Result of model sanity check."""
    profile: str
    role: str
    expected_model_hint: str
    connected_model: str
    endpoint: str
    ok: bool
    warning: str = ""


@dataclass
class PreflightResult:
    """Result of preflight checks."""
    project_root: Optional[Path]
    git_ok: bool
    dirty: bool
    checkpoint_ref: str = ""
    mode: str = ""
    profile: str = ""
    model_info: str = ""
    context_limit: int = 8192
    task_size: str = ""
    permission_policy: str = ""
    ready: bool = True
    warnings: list[str] = field(default_factory=list)


@dataclass
class TaskSizeResult:
    """Result of task size classification."""
    size: str  # "small" | "medium" | "large"
    recommended_profile: str
    reason: str
    estimated_files: str
    risk: str  # "low" | "medium" | "high"
    should_auto_continue: bool
    suggest_dry_run: bool


# Model hint mapping for sanity checks
EXPECTED_MODEL_HINTS = {
    ("fast", "worker"): "qwen3.5 9b",
    ("normal", "worker"): "qwen3.5 9b",
    ("normal", "reviewer"): "glm 18b",
    ("deep", "architect"): "qwen3.6 27b",
    ("deep", "worker"): "qwen3.5 9b",
    ("deep", "reviewer"): "glm 18b",
    ("review", "reviewer"): "glm 18b",
    ("docs", "worker"): "gemma",
    ("docs", "docs"): "gemma",
}


def check_model_sanity(
    profile_name: str,
    role: str,
    api_base: str,
    model_name: str,
) -> ModelSanityResult:
    """Check if connected model matches expected hint for profile+role.

    Args:
        profile_name: Profile name (fast, normal, deep, review, docs)
        role: Role (worker, architect, reviewer, docs)
        api_base: API base URL
        model_name: Model name from config

    Returns:
        ModelSanityResult with ok=True if model matches expected hint.
    """
    expected_hint = EXPECTED_MODEL_HINTS.get((profile_name, role), "")
    _base = api_base.rstrip("/")
    endpoint = f"{_base}/models" if _base.endswith("/v1") else f"{_base}/v1/models"

    # Try to fetch connected model from API
    connected_model = "unknown"
    try:
        resp = requests.get(endpoint, timeout=3)
        if resp.status_code == 200:
            data = resp.json()
            # Handle both direct model name and list of models
            if isinstance(data, dict) and "data" in data:
                models = data.get("data", [])
                if models and isinstance(models[0], dict):
                    connected_model = models[0].get("id", model_name)
            elif isinstance(data, dict) and "model" in data:
                connected_model = data["model"]
            else:
                connected_model = model_name
    except (requests.RequestException, requests.Timeout, ValueError):
        # Endpoint unreachable or invalid response
        connected_model = "unknown"

    # Check if connected model contains expected hint (case-insensitive substring)
    ok = False
    if connected_model != "unknown":
        ok = expected_hint.lower() in connected_model.lower()

    warning = ""
    if not ok and connected_model != "unknown":
        warning = (
            f"Model mismatch: {profile_name} mode expects '{expected_hint}' "
            f"but found '{connected_model}'"
        )

    return ModelSanityResult(
        profile=profile_name,
        role=role,
        expected_model_hint=expected_hint,
        connected_model=connected_model,
        endpoint=endpoint,
        ok=ok,
        warning=warning,
    )


def classify_task_size(task: str) -> TaskSizeResult:
    """Classify task size based on keywords and content analysis.

    Uses rule-based classification (no LLM calls).
    Priority: check LARGE first, then MEDIUM, then SMALL.

    Args:
        task: Task description text

    Returns:
        TaskSizeResult with size, recommended profile, and metadata.
    """
    if not task:
        return TaskSizeResult(
            size="small",
            recommended_profile="fast",
            reason="Empty task",
            estimated_files="1",
            risk="low",
            should_auto_continue=True,
            suggest_dry_run=False,
        )

    task_lower = task.lower()
    word_count = len(task.split())

    # Extract file mentions (loose heuristic)
    file_pattern = r'\b\w+\.(py|js|ts|tsx|jsx|json|md|txt|yaml|yml|toml|sh|rs)\b'
    file_matches = re.findall(file_pattern, task, re.IGNORECASE)
    file_count = len(set(file_matches))

    # --- CHECK LARGE ---
    large_signals = [
        "refactor" in task_lower and any(w in task_lower for w in ["tüm", "hepsini", "komple", "full", "entire"]),
        "migrate" in task_lower,
        "rewrite" in task_lower,
        "new app" in task_lower or "yeni uygulama" in task_lower,
        "architecture" in task_lower or "mimari" in task_lower,
        "everything" in task_lower or "herşeyi" in task_lower,
        word_count > 50 and file_count > 1,
    ]

    if any(large_signals):
        return TaskSizeResult(
            size="large",
            recommended_profile="deep",
            reason="Complex refactor, migration, or multi-file architecture change",
            estimated_files="8+",
            risk="high",
            should_auto_continue=False,
            suggest_dry_run=True,
        )

    # --- CHECK MEDIUM ---
    medium_signals = [
        2 <= file_count <= 5,
        "test" in task_lower and "implement" in task_lower,
        "feature" in task_lower or "özellik" in task_lower,
        "refactor" in task_lower and not any(w in task_lower for w in ["tüm", "hepsini", "komple", "full"]),
        20 <= word_count <= 50 and file_count >= 1,
    ]

    if any(medium_signals):
        return TaskSizeResult(
            size="medium",
            recommended_profile="normal",
            reason="Feature or moderate refactor involving 2-5 files",
            estimated_files="2-5",
            risk="medium",
            should_auto_continue=True,
            suggest_dry_run=False,
        )

    # --- CHECK SMALL (default) ---
    small_signals = [
        file_count <= 1,
        "fix" in task_lower or "düzelt" in task_lower,
        "readme" in task_lower,
        "typo" in task_lower or "comment" in task_lower,
        "rename" in task_lower and "refactor" not in task_lower,
        word_count < 20,
    ]

    if any(small_signals):
        return TaskSizeResult(
            size="small",
            recommended_profile="fast",
            reason="Single file fix or small change",
            estimated_files="1",
            risk="low",
            should_auto_continue=True,
            suggest_dry_run=False,
        )

    # Default to medium if nothing matches
    return TaskSizeResult(
        size="medium",
        recommended_profile="normal",
        reason="Default classification (unmatched keywords)",
        estimated_files="2-3",
        risk="medium",
        should_auto_continue=True,
        suggest_dry_run=False,
    )


def run_preflight(ctx, task: str = "", cwd: Optional[Path] = None) -> PreflightResult:
    """Run comprehensive preflight checks.

    Args:
        ctx: ToolContext with mode, profile, etc.
        task: Task description for size classification
        cwd: Working directory (defaults to Path.cwd())

    Returns:
        PreflightResult with all checks.
    """
    if cwd is None:
        cwd = Path.cwd()

    warnings = []
    project_root = None
    git_ok = False
    dirty = False
    checkpoint_ref = ""

    # 1. Find project root
    try:
        result = subprocess.run(
            ["git", "rev-parse", "--git-dir"],
            cwd=str(cwd),
            capture_output=True,
            text=True,
            timeout=5,
        )
        if result.returncode == 0:
            git_dir = Path(result.stdout.strip())
            if git_dir.is_absolute():
                project_root = git_dir.parent
            else:
                project_root = cwd / git_dir
                project_root = project_root.resolve()
            git_ok = True
    except Exception as e:
        warnings.append(f"Git check failed: {e}")

    if not project_root:
        project_root = cwd

    # 2. Check dirty state
    if git_ok:
        try:
            result = subprocess.run(
                ["git", "status", "--short"],
                cwd=str(project_root),
                capture_output=True,
                text=True,
                timeout=5,
            )
            if result.returncode == 0:
                dirty = bool(result.stdout.strip())
        except Exception:
            pass

    # 3. Get current checkpoint
    if git_ok:
        try:
            result = subprocess.run(
                ["git", "rev-parse", "--short", "HEAD"],
                cwd=str(project_root),
                capture_output=True,
                text=True,
                timeout=5,
            )
            if result.returncode == 0:
                checkpoint_ref = result.stdout.strip()
        except Exception:
            pass

    # 4. Extract mode and profile
    mode = getattr(ctx, "mode", "auto") or "auto"
    profile_name = getattr(ctx, "mode", "fast") or "fast"
    if hasattr(ctx, "profile"):
        profile_name = ctx.profile

    # 5. Model sanity check (if profile available)
    model_info = "unknown"
    if profile_name != "auto":
        try:
            # Import here to avoid circular imports
            from mico.profiles_runtime import BUILTIN_PROFILES, resolve_role_model

            if profile_name in BUILTIN_PROFILES:
                profile_cfg = BUILTIN_PROFILES[profile_name]
                primary_role = profile_cfg.default_role or "worker"
                role_cfg = resolve_role_model(primary_role, profile_cfg)

                if role_cfg is not None:
                    sanity = check_model_sanity(
                        profile_name,
                        primary_role,
                        role_cfg.base_url,
                        role_cfg.model,
                    )
                    model_info = f"{sanity.expected_model_hint} ({sanity.connected_model})"
                    if not sanity.ok and sanity.connected_model != "unknown":
                        warnings.append(f"Model mismatch: expected {sanity.expected_model_hint}, got {sanity.connected_model}")
        except Exception as e:
            warnings.append(f"Model check failed: {e}")

    # 6. Context limit (from profile if available)
    context_limit = 8192
    try:
        from mico.profiles_runtime import BUILTIN_PROFILES
        if profile_name in BUILTIN_PROFILES:
            profile_cfg = BUILTIN_PROFILES[profile_name]
            for role_cfg in profile_cfg.roles.values():
                context_limit = role_cfg.context
                break
    except Exception:
        pass

    # 7. Classify task size
    task_size = "medium"
    if task:
        size_result = classify_task_size(task)
        task_size = size_result.size

    # 8. Permission policy
    permission_policy = getattr(ctx, "permission_mode", "balanced") or "balanced"

    ready = len(warnings) == 0

    return PreflightResult(
        project_root=project_root,
        git_ok=git_ok,
        dirty=dirty,
        checkpoint_ref=checkpoint_ref,
        mode=mode,
        profile=profile_name,
        model_info=model_info,
        context_limit=context_limit,
        task_size=task_size,
        permission_policy=permission_policy,
        ready=ready,
        warnings=warnings,
    )


def format_preflight(result: PreflightResult) -> str:
    """Format preflight result as human-readable string.

    Args:
        result: PreflightResult from run_preflight

    Returns:
        Formatted string suitable for console output.
    """
    lines = ["Preflight:"]

    if result.project_root:
        lines.append(f"  project root: {result.project_root}")
    else:
        lines.append("  project root: not found")

    lines.append(f"  git: {'ok' if result.git_ok else 'not found'}")
    lines.append(f"  dirty: {'yes' if result.dirty else 'no'}")

    if result.checkpoint_ref:
        lines.append(f"  checkpoint: {result.checkpoint_ref}")

    lines.append(f"  mode: {result.mode}")
    lines.append(f"  profile: {result.profile}")
    lines.append(f"  model: {result.model_info}")
    lines.append(f"  context: {result.context_limit}")

    if result.task_size:
        lines.append(f"  task size: {result.task_size}")

    lines.append(f"  permission policy: {result.permission_policy}")

    ready_str = "yes" if result.ready else "NO"
    lines.append(f"  ready: {ready_str}")

    if result.warnings:
        lines.append("")
        lines.append("Warnings:")
        for w in result.warnings:
            lines.append(f"  - {w}")

    return "\n".join(lines)


def format_task_size(result: TaskSizeResult) -> str:
    """Format task size result as human-readable string.

    Args:
        result: TaskSizeResult from classify_task_size

    Returns:
        Formatted string suitable for console output.
    """
    lines = [
        f"Task size: {result.size}",
        f"Recommended mode: {result.recommended_profile}",
        f"Reason: {result.reason}",
        f"Estimated touched files: {result.estimated_files}",
        f"Risk: {result.risk}",
        f"Auto-continue: {'yes' if result.should_auto_continue else 'no'}",
        f"Suggest dry-run: {'yes' if result.suggest_dry_run else 'no'}",
    ]
    return "\n".join(lines)
