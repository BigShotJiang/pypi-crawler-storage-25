from __future__ import annotations

import re
import time
from pathlib import Path
from typing import Any, Callable


def slugify_checkpoint_label(label: str) -> str:
    slug = re.sub(r"[^a-zA-Z0-9._-]+", "-", (label or "").strip()).strip("-")
    return slug[:40] if slug else "checkpoint"


def normalize_checkpoint_ref(ref: str, checkpoint_ref_ns: str) -> str:
    ref = (ref or "").strip()
    if not ref:
        return ref
    if ref.startswith("refs/"):
        return ref
    if ref.startswith("mico-checkpoints/"):
        return f"refs/{ref}"
    return f"{checkpoint_ref_ns}{ref}"


def create_git_checkpoint(
    cwd: Path,
    *,
    label: str,
    git_repo_root: Callable[[Path], Path | None],
    run_subprocess: Callable[..., Any],
) -> tuple[str | None, str]:
    root = git_repo_root(cwd)
    if root is None:
        return (None, "not a git repo")
    try:
        stash = run_subprocess(["git", "stash", "create"], cwd=root, timeout=30)
    except Exception as exc:
        return (None, f"git stash create failed: {exc}")
    sha = stash.stdout.strip()
    if not sha:
        try:
            head = run_subprocess(["git", "rev-parse", "HEAD"], cwd=root, timeout=10)
        except Exception as exc:
            return (None, f"git rev-parse HEAD failed: {exc}")
        if head.returncode != 0:
            return (None, f"git rev-parse HEAD failed: {head.stderr.strip()}")
        sha = head.stdout.strip()
    if not sha:
        return (None, "could not determine checkpoint sha")
    ts = time.strftime("%Y%m%d-%H%M%S")
    slug = slugify_checkpoint_label(label)
    ref_short = f"mico-checkpoints/{ts}-{slug}"
    ref_full = f"refs/{ref_short}"
    try:
        upd = run_subprocess(["git", "update-ref", ref_full, sha], cwd=root, timeout=10)
    except Exception as exc:
        return (None, f"git update-ref failed: {exc}")
    if upd.returncode != 0:
        return (None, f"git update-ref failed: {upd.stderr.strip()}")
    return (ref_short, sha)


def list_git_checkpoints(
    cwd: Path,
    *,
    checkpoint_ref_ns: str,
    git_repo_root: Callable[[Path], Path | None],
    run_subprocess: Callable[..., Any],
) -> list[dict]:
    root = git_repo_root(cwd)
    if root is None:
        return []
    try:
        proc = run_subprocess(
            [
                "git",
                "for-each-ref",
                checkpoint_ref_ns,
                "--format=%(refname:short)|%(objectname)|%(committerdate:iso8601)",
                "--sort=-committerdate",
            ],
            cwd=root,
            timeout=15,
        )
    except Exception:
        return []
    if proc.returncode != 0:
        return []
    items: list[dict] = []
    for line in proc.stdout.splitlines():
        parts = line.split("|", 2)
        if len(parts) < 2:
            continue
        ref = parts[0].strip()
        sha = parts[1].strip()
        date = parts[2].strip() if len(parts) > 2 else ""
        if not ref or not sha:
            continue
        items.append({"ref": ref, "sha": sha, "date": date})
        if len(items) >= 20:
            break
    return items


def rollback_to_checkpoint(
    cwd: Path,
    ref: str,
    *,
    paths: list[str] | None,
    checkpoint_ref_ns: str,
    git_repo_root: Callable[[Path], Path | None],
    run_subprocess: Callable[..., Any],
    create_checkpoint: Callable[[Path, str], tuple[str | None, str]],
) -> str:
    root = git_repo_root(cwd)
    if root is None:
        return "not a git repo"
    full_ref = normalize_checkpoint_ref(ref, checkpoint_ref_ns)
    try:
        verify = run_subprocess(["git", "rev-parse", "--verify", full_ref], cwd=root, timeout=10)
    except Exception as exc:
        return f"failed to verify ref {full_ref}: {exc}"
    if verify.returncode != 0:
        return f"ref not found: {full_ref}"
    messages: list[str] = []
    try:
        status = run_subprocess(["git", "status", "--porcelain"], cwd=root, timeout=15)
    except Exception as exc:
        return f"git status failed: {exc}"
    if status.returncode == 0 and status.stdout.strip():
        pre_ref, pre_sha = create_checkpoint(root, "auto-pre-rollback")
        if pre_ref:
            messages.append(f"dirty worktree saved as auto-pre-rollback checkpoint {pre_ref} ({pre_sha[:8]})")
        else:
            messages.append(f"warning: could not auto-checkpoint dirty worktree: {pre_sha}")
    target_paths = paths if paths else ["."]
    cmd = ["git", "checkout", full_ref, "--", *target_paths]
    try:
        co = run_subprocess(cmd, cwd=root, timeout=60)
    except Exception as exc:
        return "\n".join(messages + [f"git checkout failed: {exc}"])
    if co.returncode != 0:
        return "\n".join(messages + [f"git checkout failed: {co.stderr.strip() or co.stdout.strip()}"])
    if paths:
        messages.append(f"restored {len(paths)} path(s) from {full_ref}")
    else:
        messages.append(f"restored worktree from {full_ref} (HEAD unchanged)")
    messages.append("note: branch/HEAD has not changed; only files were rewritten")
    return "\n".join(messages)


def git_diff_summary(
    cwd: Path,
    *,
    git_repo_root: Callable[[Path], Path | None],
    run_subprocess: Callable[..., Any],
    truncator: Callable[[str, int], str],
) -> str:
    root = git_repo_root(cwd)
    if root is None:
        return "not a git repo"
    parts: list[str] = []
    try:
        diff = run_subprocess(["git", "diff", "--stat", "HEAD"], cwd=root, timeout=20)
        if diff.stdout.strip():
            parts.append("# diff --stat HEAD")
            parts.append(diff.stdout.rstrip())
    except Exception as exc:
        parts.append(f"git diff failed: {exc}")
    try:
        st = run_subprocess(["git", "status", "--short"], cwd=root, timeout=15)
        if st.stdout.strip():
            parts.append("# status --short")
            parts.append(st.stdout.rstrip())
    except Exception as exc:
        parts.append(f"git status failed: {exc}")
    if not parts:
        return "no changes"
    return truncator("\n".join(parts), 4000)


def git_status_short(
    cwd: Path,
    *,
    git_repo_root: Callable[[Path], Path | None],
    run_subprocess: Callable[..., Any],
) -> str:
    root = git_repo_root(cwd)
    if root is None:
        return "not a git repo"
    try:
        proc = run_subprocess(["git", "status", "--short", "--branch"], cwd=root, timeout=15)
    except Exception as exc:
        return f"git status failed: {exc}"
    if proc.returncode != 0:
        return f"git status failed: {proc.stderr.strip()}"
    out = proc.stdout.rstrip()
    return out or "clean"
