from __future__ import annotations


def recent_user_message(history: list[dict[str, str]]) -> str:
    for message in reversed(history):
        if message.get("role") == "user":
            return str(message.get("content", ""))
    return ""


def history_total_chars(history: list[dict[str, str]]) -> int:
    total = 0
    for message in history:
        total += len(str(message.get("content", "")))
    return total


def count_primary_user_turns(history: list[dict[str, str]]) -> int:
    count = 0
    for message in history:
        if message.get("role") != "user":
            continue
        content = str(message.get("content", ""))
        if content.startswith("Runtime context:"):
            continue
        if content.startswith("Tool result for ") or content.startswith("Tool error for "):
            continue
        if content.startswith("Model backend error."):
            continue
        count += 1
    return count
