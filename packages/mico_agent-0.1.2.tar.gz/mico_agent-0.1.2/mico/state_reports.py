from __future__ import annotations

import json
from pathlib import Path
from typing import Callable


def task_state_report(
    session_id: str,
    *,
    task_state_file: Path,
    truncator: Callable[[str, int], str],
) -> str:
    if not task_state_file.exists():
        return f"No task state for session {session_id[:8]}."
    data = json.loads(task_state_file.read_text())
    artifacts = data.get("artifacts", [])
    files_touched = data.get("files_touched", [])
    lines = [
        "Task State",
        f"session: {session_id[:8]}",
        f"goal: {data.get('goal', '')}",
        f"mode: {data.get('mode', '')}",
        f"task_kind: {data.get('task_kind', '')}",
        f"active_model_profile: {data.get('active_model_profile', '')}",
        f"status: {data.get('status', '')}",
        f"current_phase: {data.get('current_phase', '')}",
        f"next_step: {data.get('next_step', '')}",
        f"files_touched: {len(files_touched)}",
        f"artifacts: {len(artifacts)}",
    ]
    pending_tool = data.get("pending_tool", {}) or {}
    if pending_tool:
        lines.append(f"pending_tool: {pending_tool.get('tool', '')} | {pending_tool.get('summary', '')}")
    if data.get("test_command"):
        lines.append(f"test_command: {data.get('test_command')}")
    if data.get("test_result"):
        lines.append(f"test_result: {truncator(str(data.get('test_result', '')), 180)}")
    for phase in data.get("phases", [])[:6]:
        lines.append(f"phase: {phase.get('name')} | {phase.get('status')}")
    for item in data.get("verifier_notes", [])[-3:]:
        lines.append(f"verifier: {item}")
    for item in artifacts[-3:]:
        lines.append(f"artifact: {item.get('id')} {item.get('label')}")
    return "\n".join(lines)


def artifact_report(
    session_id: str,
    *,
    artifacts_dir: Path,
    artifact_snippet: Callable[[str, int], str],
    limit: int = 10,
) -> str:
    entries = sorted(artifacts_dir.glob("*.txt"), key=lambda p: p.stat().st_mtime, reverse=True)
    if not entries:
        return f"No artifacts for session {session_id[:8]}."
    lines = ["Artifacts", f"session: {session_id[:8]}"]
    for artifact in entries[:limit]:
        snippet = artifact_snippet(artifact.read_text(), 180).replace("\n", " ")
        lines.append(f"{artifact.name} | {snippet}")
    return "\n".join(lines)
