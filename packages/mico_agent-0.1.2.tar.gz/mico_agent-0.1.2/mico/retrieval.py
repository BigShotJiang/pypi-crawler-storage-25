from __future__ import annotations

import re
from typing import Any


def retrieval_terms(task: str, history: list[dict[str, str]], extract_task_body: Any) -> set[str]:
    raw = extract_task_body(task) + "\n" + "\n".join(str(item.get("content", "")) for item in history[-4:])
    tokens = re.findall(r"[A-Za-z0-9_.:/-]{3,}", raw.lower())
    stop = {
        "the", "and", "for", "with", "that", "this", "from", "into", "your", "task",
        "tool", "result", "file", "code", "read", "show", "incele", "gorev", "veya",
        "icin", "bunu", "then", "return",
    }
    return {token for token in tokens if token not in stop}


def select_relevant_artifacts(
    artifacts: list[dict[str, Any]],
    task: str,
    history: list[dict[str, str]],
    *,
    limit: int,
    extract_task_body: Any,
) -> list[dict[str, Any]]:
    terms = retrieval_terms(task, history, extract_task_body)
    scored: list[tuple[int, int, dict[str, Any]]] = []
    for idx, artifact in enumerate(artifacts):
        haystack = " ".join(
            [
                str(artifact.get("label", "")).lower(),
                str(artifact.get("snippet", "")).lower(),
                str(artifact.get("path", "")).lower(),
            ]
        )
        score = sum(3 if term in str(artifact.get("path", "")).lower() else 1 for term in terms if term in haystack)
        if score <= 0:
            continue
        scored.append((score, idx, artifact))
    if not scored:
        return artifacts[-limit:]
    scored.sort(key=lambda item: (item[0], item[1]), reverse=True)
    return [artifact for _, _, artifact in scored[:limit]]


def build_retrieval_prompt(
    artifacts: list[dict[str, Any]],
    task: str,
    history: list[dict[str, str]],
    *,
    limit: int,
    extract_task_body: Any,
    truncator: Any,
) -> str:
    selected = select_relevant_artifacts(
        artifacts,
        task,
        history,
        limit=limit,
        extract_task_body=extract_task_body,
    )
    if not selected:
        return ""
    lines = ["[RETRIEVED EVIDENCE]", "Use these artifacts when they are directly relevant. Prefer them over re-reading the same target."]
    for artifact in selected:
        lines.append(f"- artifact://{artifact['id']} {artifact['label']}")
        lines.append(f"  path: {artifact['path']}")
        snippet = truncator(str(artifact.get("snippet", "")), 220).replace("\n", " ")
        if snippet:
            lines.append(f"  snippet: {snippet}")
    return "\n".join(lines)


