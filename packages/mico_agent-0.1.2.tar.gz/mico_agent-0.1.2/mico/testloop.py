"""Test runner detection, execution, parsing, and fix-loop helpers for mico.

Pure module: no imports from mico.py to avoid circular deps.
"""
from __future__ import annotations

import re
import subprocess
import time
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any


MAX_RAW_TAIL_CHARS = 4000
DEFAULT_TIMEOUT_S = 180
MAX_TIMEOUT_S = 600


@dataclass
class TestRunner:
    __test__ = False
    name: str
    command: list[str]
    config_file: str
    priority: int


@dataclass
class TestResult:
    runner_name: str
    command: list[str]
    exit_code: int
    duration_s: float
    summary: str
    failing_tests: list[dict[str, Any]] = field(default_factory=list)
    raw_tail: str = ""


@dataclass
class FixLoopState:
    attempts: int = 0
    max_attempts: int = 3
    last_summary: str | None = None


def should_continue_fix_loop(state: FixLoopState) -> bool:
    return state.attempts < state.max_attempts


# ---------- Detection ----------

def _pyproject_has_pytest(path: Path) -> bool:
    try:
        text = path.read_text(encoding="utf-8", errors="replace")
    except OSError:
        return False
    return "[tool.pytest" in text or "pytest" in text


def _setup_cfg_has_pytest(path: Path) -> bool:
    try:
        text = path.read_text(encoding="utf-8", errors="replace")
    except OSError:
        return False
    return "[tool:pytest]" in text


def _package_json_has_test(path: Path) -> bool:
    try:
        import json
        data = json.loads(path.read_text(encoding="utf-8", errors="replace"))
    except Exception:
        return False
    scripts = data.get("scripts") or {}
    return isinstance(scripts, dict) and bool(scripts.get("test"))


def _makefile_has_test(path: Path) -> bool:
    try:
        text = path.read_text(encoding="utf-8", errors="replace")
    except OSError:
        return False
    return bool(re.search(r"^test\s*:", text, flags=re.MULTILINE))


def detect_test_runners(cwd: Path) -> list[TestRunner]:
    runners: list[TestRunner] = []
    cwd = Path(cwd)

    py = cwd / "pyproject.toml"
    pi = cwd / "pytest.ini"
    sc = cwd / "setup.cfg"
    if pi.exists() or (py.exists() and _pyproject_has_pytest(py)) or (sc.exists() and _setup_cfg_has_pytest(sc)):
        config = "pytest.ini" if pi.exists() else ("pyproject.toml" if py.exists() else "setup.cfg")
        runners.append(TestRunner(
            name="pytest",
            command=["pytest", "-x", "--tb=short", "-q"],
            config_file=config,
            priority=10,
        ))

    pkg = cwd / "package.json"
    if pkg.exists() and _package_json_has_test(pkg):
        runners.append(TestRunner(
            name="npm",
            command=["npm", "test", "--silent"],
            config_file="package.json",
            priority=20,
        ))

    cargo = cwd / "Cargo.toml"
    if cargo.exists():
        runners.append(TestRunner(
            name="cargo",
            command=["cargo", "test", "--quiet"],
            config_file="Cargo.toml",
            priority=30,
        ))

    gomod = cwd / "go.mod"
    if gomod.exists():
        runners.append(TestRunner(
            name="go",
            command=["go", "test", "./..."],
            config_file="go.mod",
            priority=40,
        ))

    mk = cwd / "Makefile"
    if mk.exists() and _makefile_has_test(mk):
        runners.append(TestRunner(
            name="make",
            command=["make", "test"],
            config_file="Makefile",
            priority=50,
        ))

    runners.sort(key=lambda r: r.priority)
    return runners


# ---------- Parsing ----------

_PYTEST_FAILED_RE = re.compile(r"^FAILED\s+([^\s:]+)::([\w\[\]\-\.]+)(?:\s*-\s*(.*))?$", re.MULTILINE)
_PYTEST_LINE_RE = re.compile(r"([^\s:]+\.py):(\d+):")


def parse_pytest_failures(text: str) -> list[dict[str, Any]]:
    fails: list[dict[str, Any]] = []
    for m in _PYTEST_FAILED_RE.finditer(text):
        file_path = m.group(1)
        test_name = m.group(2)
        message = (m.group(3) or "").strip()
        line = None
        # Look near the failure block for line number
        idx = m.start()
        block = text[max(0, idx - 1500):idx]
        line_match = None
        for lm in _PYTEST_LINE_RE.finditer(block):
            if lm.group(1).endswith(file_path) or file_path.endswith(lm.group(1)):
                line_match = lm
        if line_match:
            try:
                line = int(line_match.group(2))
            except ValueError:
                line = None
        if not message:
            # Try assertion line
            am = re.search(r"AssertionError[:\s]+(.+)", block)
            if am:
                message = am.group(1).strip()
        fails.append({
            "name": f"{file_path}::{test_name}",
            "file": file_path,
            "line": line,
            "message": message or "(no message)",
        })
    return fails


def parse_npm_test_failures(text: str) -> list[dict[str, Any]]:
    fails: list[dict[str, Any]] = []
    seen: set[str] = set()
    for line in text.splitlines():
        m = re.match(r"\s*(?:✗|FAIL|×)\s+(.+)", line)
        if m:
            name = m.group(1).strip()
            if name and name not in seen:
                seen.add(name)
                fails.append({"name": name, "file": None, "line": None, "message": ""})
    # Attach expect() context if found
    expect_blocks = re.findall(r"expect\([^)]*\)[^\n]*", text)
    if fails and expect_blocks:
        fails[0]["message"] = expect_blocks[0][:300]
    return fails


def parse_cargo_test_failures(text: str) -> list[dict[str, Any]]:
    fails: list[dict[str, Any]] = []
    for m in re.finditer(r"^test\s+([\w:]+)\s+\.\.\.\s+FAILED$", text, flags=re.MULTILINE):
        name = m.group(1)
        msg = ""
        pm = re.search(r"panicked at[^\n]*", text[m.start():])
        if pm:
            msg = pm.group(0).strip()
        fails.append({"name": name, "file": None, "line": None, "message": msg})
    return fails


def parse_go_test_failures(text: str) -> list[dict[str, Any]]:
    fails: list[dict[str, Any]] = []
    for m in re.finditer(r"^---\s+FAIL:\s+(\S+)", text, flags=re.MULTILINE):
        name = m.group(1)
        block = text[m.start():m.start() + 2000]
        line_match = re.search(r"(\S+_test\.go):(\d+):\s*(.*)", block)
        file_path = line_match.group(1) if line_match else None
        line_no = int(line_match.group(2)) if line_match else None
        message = line_match.group(3).strip() if line_match else ""
        fails.append({"name": name, "file": file_path, "line": line_no, "message": message})
    return fails


def parse_make_test_failures(text: str) -> list[dict[str, Any]]:
    fails: list[dict[str, Any]] = []
    for line in text.splitlines():
        if re.search(r"\b[Ee]rror\b", line):
            fails.append({"name": "make", "file": None, "line": None, "message": line.strip()[:300]})
            if len(fails) >= 10:
                break
    return fails


_PARSERS = {
    "pytest": parse_pytest_failures,
    "npm": parse_npm_test_failures,
    "cargo": parse_cargo_test_failures,
    "go": parse_go_test_failures,
    "make": parse_make_test_failures,
}


# ---------- Execution ----------

def run_tests(runner: TestRunner, cwd: Path, *, timeout: int = DEFAULT_TIMEOUT_S) -> TestResult:
    timeout = max(1, min(int(timeout), MAX_TIMEOUT_S))
    start = time.monotonic()
    exit_code = 1
    combined = ""
    try:
        proc = subprocess.run(
            runner.command,
            cwd=str(cwd),
            capture_output=True,
            text=True,
            timeout=timeout,
        )
        exit_code = proc.returncode
        combined = (proc.stdout or "") + ("\n" if proc.stdout and proc.stderr else "") + (proc.stderr or "")
    except subprocess.TimeoutExpired as exc:
        combined = f"TIMEOUT after {timeout}s\n" + (exc.stdout or "") + "\n" + (exc.stderr or "")
        exit_code = 124
    except FileNotFoundError as exc:
        combined = f"runner not found: {exc}"
        exit_code = 127
    duration = time.monotonic() - start
    parser = _PARSERS.get(runner.name, parse_make_test_failures)
    failures = parser(combined) if exit_code != 0 else []
    raw_tail = combined[-MAX_RAW_TAIL_CHARS:]
    result = TestResult(
        runner_name=runner.name,
        command=list(runner.command),
        exit_code=exit_code,
        duration_s=round(duration, 3),
        summary="",
        failing_tests=failures,
        raw_tail=raw_tail,
    )
    result.summary = summarize_test_result(result)
    return result


# ---------- Summarization ----------

def summarize_test_result(r: TestResult, *, max_failures: int = 5) -> str:
    lines: list[str] = []
    lines.append(f"runner: {r.runner_name}")
    lines.append(f"command: {' '.join(r.command)}")
    lines.append(f"exit_code: {r.exit_code}")
    lines.append(f"duration: {r.duration_s}s")
    total = len(r.failing_tests)
    if total:
        shown = min(total, max_failures)
        lines.append(f"failures ({total} total, showing {shown}):")
        for f in r.failing_tests[:max_failures]:
            name = f.get("name", "?")
            line_no = f.get("line")
            message = (f.get("message") or "").strip().splitlines()[0] if f.get("message") else ""
            line_part = f"line {line_no}" if line_no else "line ?"
            lines.append(f"- {name} | {line_part} | {message}")
    elif r.exit_code == 0:
        lines.append("failures (0 total): all tests passed")
    else:
        lines.append("failures (0 parsed) — non-zero exit but no parseable failures")
    tail_chars = min(800, len(r.raw_tail))
    lines.append(f"(raw tail truncated to {tail_chars} chars)")
    if r.raw_tail:
        lines.append(r.raw_tail[-tail_chars:])
    return "\n".join(lines)
