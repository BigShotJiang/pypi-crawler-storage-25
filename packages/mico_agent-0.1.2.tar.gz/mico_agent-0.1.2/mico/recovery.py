from __future__ import annotations

from typing import Any


def build_recovery_prompt(
    kind: str,
    *,
    task_body: str,
    mode: str,
    task_kind: str,
    details: str = "",
    excerpts: str = "",
    diff_text: str = "",
    truncator: Any = None,
) -> str:
    def _t(value: str, limit: int) -> str:
        if truncator is None:
            return value[:limit]
        return truncator(value, limit)

    prefix = [
        f"Goal: {task_body}",
        f"Mode: {mode}",
        f"Task kind: {task_kind}",
        "Return exactly one JSON action object.",
    ]
    if kind == "invalid_patch":
        prefix.append("The previous patch was invalid. Produce a smaller corrected patch; do not rewrite whole files.")
    elif kind == "context_mismatch":
        prefix.append("The patch context did not match the file. Re-read the excerpt mentally and emit a corrected minimal patch.")
    elif kind == "file_not_found":
        prefix.append("The referenced file does not exist. Use only the listed existing files.")
    elif kind == "test_failed":
        prefix.append("Tests failed after the latest change. Fix only the failing code path and return a minimal patch.")
    elif kind == "command_failed":
        prefix.append("The last command failed. Choose a different targeted step or return a final blocker summary.")
    elif kind == "hallucinated_file":
        prefix.append("The model referenced a non-existent file. Use only existing files from the provided context.")
    elif kind == "missing_command_output":
        prefix.append(
            "The expected output file does not exist — this means the command that was supposed to create it "
            "failed or was never installed. Do NOT try to read this file again. "
            "Use a different tool or approach, or return a final answer explaining the limitation."
        )
    elif kind == "file_outside_project_root":
        prefix.append("The previous action targeted a path outside allowed workspace roots. Stay inside project paths.")
    elif kind == "context_overflow":
        prefix.append("Context overflow occurred. Narrow the scope to the listed files and return one minimal action.")
    elif kind == "model_timeout":
        prefix.append("The previous model attempt timed out. Return one simpler next action.")
    elif kind == "malformed_json":
        prefix.append("The previous response was malformed. Return one valid JSON action object only.")
    elif kind == "empty_response":
        prefix.append("The previous response was empty. Return one valid JSON action object only.")
    elif kind == "repeated_bad_fix":
        prefix.append("Repeated bad fixes were detected. Either return a different minimal patch or a final blocker summary.")
    elif kind == "permission_denied":
        prefix.append("The previous action was blocked by permission policy. Pick a safe alternative tool or return a blocker.")
    if details:
        prefix.append(f"Details:\n{_t(details, 2400)}")
    if diff_text:
        prefix.append(f"Current diff:\n{_t(diff_text, 3000)}")
    if excerpts:
        prefix.append(f"Relevant excerpts:\n{_t(excerpts, 3000)}")
    return "\n\n".join(prefix)


def recovery_kind_for_exception(exc: Exception) -> str:
    message = str(exc).lower()
    if isinstance(exc, FileNotFoundError):
        path = str(exc)
        # Temp files that were expected as output from a command that failed
        if "/tmp/" in path or path.startswith("/var/folders"):
            return "missing_command_output"
        return "hallucinated_file"
    if isinstance(exc, PermissionError):
        return "file_outside_project_root"
    if "outside project root" in message or "protected location" in message:
        return "file_outside_project_root"
    if "permission" in message or "disabled" in message or "strict mode" in message:
        return "permission_denied"
    if "timeout" in message:
        return "model_timeout"
    if "empty" in message:
        return "empty_response"
    if "json" in message:
        return "malformed_json"
    return "command_failed"

