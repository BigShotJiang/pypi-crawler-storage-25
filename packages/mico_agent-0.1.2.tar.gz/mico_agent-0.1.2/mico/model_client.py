"""
Model API client functions extracted from cli.py.

This module provides high-level functions for model API calls, streaming,
and message normalization. It lazily imports globals from cli.py to avoid
circular dependencies.
"""
from __future__ import annotations

import json
import re
import time
import asyncio
from typing import Any

import httpx

from mico.text_utils import strip_thinking as _strip_thinking
from mico.action_parse import normalize_action_schema as _normalize_action_schema
from mico.router_hooks import (
    router_admin_headers as _router_admin_headers_impl,
    router_unload_hook as _router_unload_hook_impl,
    router_load_hook as _router_load_hook_impl,
)
from mico.model_ops import (
    model_label,
    estimate_tokens_from_text,
    estimate_prompt_tokens,
    normalize_usage_payload,
    record_turn_usage,
    note_turn_model,
    record_orchestra_trace,
    extract_choice_text as _ect,
    extract_choice_reasoning as _ecr,
)
from mico.draft_mode import (
    speculative_draft_active as _speculative_draft_active,
    draft_mode_name as _draft_mode_name,
)
from mico.history_utils import (
    count_primary_user_turns as _count_primary_user_turns,
)
from mico.compact import (
    fallback_history_summary as _fallback_history_summary,
    summarize_history as _summarize_history,
)
from mico.repair import (
    repair_action_response as _repair_action_response,
)
from mico.profiles_runtime import ModelSlot, RoleConfig, resolve_role_model


# Exception for streaming cancellation
class ModelStreamCancelled(Exception):
    """Raised when model stream is cancelled by user."""
    pass


# ============================================================================
# Group 1: Action/Message Normalization Functions
# ============================================================================

def strip_thinking(text: str) -> str:
    """Strip thinking tags from text."""
    return _strip_thinking(text)


def normalize_action_schema(action: dict[str, Any]) -> dict[str, Any]:
    """Normalize action schema from model response."""
    return _normalize_action_schema(action)


def _router_admin_headers() -> dict[str, str]:
    """Get router admin headers using current API_KEY."""
    from mico import cli as _cli
    return _router_admin_headers_impl(_cli.API_KEY)


async def router_unload_hook(_model: str) -> None:
    """Router hook: unload model."""
    from mico import cli as _cli
    if _cli.MODEL_PROVIDER == "mlx" and not _cli.os.environ.get("MICO_MLX_ROUTER_ADMIN_URL"):
        return
    async with httpx.AsyncClient() as client:
        await _router_unload_hook_impl(
            _model,
            router_admin_base=_cli.MLX_ROUTER_ADMIN_BASE,
            api_key=_cli.API_KEY,
            http_post=client.post,
        )


async def router_load_hook(model: str, _cfg: RoleConfig) -> None:
    """Router hook: load model."""
    from mico import cli as _cli
    _ = _cfg
    if _cli.MODEL_PROVIDER == "mlx" and not _cli.os.environ.get("MICO_MLX_ROUTER_ADMIN_URL"):
        return
    async with httpx.AsyncClient() as client:
        await _router_load_hook_impl(
            model,
            router_admin_base=_cli.MLX_ROUTER_ADMIN_BASE,
            api_key=_cli.API_KEY,
            http_post=client.post,
        )


# Register hooks with ModelSlot (Note: ModelSlot might need async update too)
ModelSlot.set_unload_hook(router_unload_hook)
ModelSlot.set_load_hook(router_load_hook)


def extract_json(text: str) -> dict[str, Any]:
    """Extract JSON action from model response, handling thinking tags."""
    from mico.action_parse import extract_json as _extract_json_action
    return _extract_json_action(text, strip_thinking=strip_thinking)


def coerce_local_info_action(action: dict[str, Any], goal: str | None) -> dict[str, Any]:
    """Coerce action to preferred local info action if needed."""
    from mico.task_classify import preferred_local_info_action

    preferred = preferred_local_info_action(goal)
    if not preferred:
        return action
    if action.get("type") == "final":
        return action
    if action.get("type") != "tool":
        return preferred
    if goal == "local_ip":
        if action.get("tool") == "macos_admin_task" and action.get("name") == "list_network_interfaces":
            return action
        if action.get("tool") == "bash":
            command = str(action.get("command", "")).strip().lower()
            if any(token in command for token in ("ifconfig", "ipconfig getifaddr", "networksetup", "scutil --nwi")):
                return action
        return preferred
    return action


def validate_orchestra_handoff(data: dict[str, Any] | None) -> tuple[bool, str]:
    """Validate orchestra handoff data structure."""
    if not isinstance(data, dict):
        return (False, "handoff is not a JSON object")
    required: dict[str, type[Any]] = {
        "intent": str,
        "task_kind": str,
        "next_action": str,
        "tool_choice": str,
        "stop_if_answered": bool,
        "concise_answer_ok": bool,
    }
    for key, expected_type in required.items():
        value = data.get(key)
        if not isinstance(value, expected_type):
            return (False, f"{key} must be {expected_type.__name__}")
        if expected_type is str and not str(value).strip():
            return (False, f"{key} must be non-empty")
    return (True, "")


def normalize_compact_summary(text: str) -> str:
    """Normalize and clean a compact history summary."""
    cleaned = strip_thinking(text).replace("```", "").replace("\r", "").strip()
    lines: list[str] = []
    banned_prefixes = (
        "here's a thinking process",
        "thinking process",
        "**analyze the request",
        "analyze the request",
        "**analyze the input data",
        "analyze the input data",
        "analyze user input",
        "goal:",
    )
    for raw_line in cleaned.splitlines():
        line = re.sub(r"\s+", " ", raw_line).strip()
        if not line:
            continue
        lower = line.lower()
        if lower.startswith(banned_prefixes):
            continue
        if lower in {"recent actions:", "* recent actions:*", "input:", "format:", "content:", "context:"}:
            continue
        line = re.sub(r"^\d+\.\s*", "", line)
        line = re.sub(r"^-+\s*", "", line)
        line = re.sub(r"^\*+\s*", "", line)
        lines.append(truncate(line, 240).replace("\n", " "))
        if len(lines) >= 12:
            break
    if not lines:
        return "Goal: continue from the preserved tail messages.\nState: prior context was compacted."
    return "\n".join(lines)


def normalize_messages_for_model(messages: list[dict[str, str]]) -> list[dict[str, str]]:
    """Normalize messages for model API call."""
    system_parts: list[str] = []
    normalized: list[dict[str, str]] = []
    for message in messages:
        role = str(message.get("role", "user")).strip() or "user"
        content = str(message.get("content", "")).strip()
        if not content:
            continue
        if role == "system":
            system_parts.append(content)
            continue
        if role not in {"user", "assistant"}:
            role = "user"
        normalized.append({"role": role, "content": content})
    if system_parts:
        normalized.insert(0, {"role": "system", "content": "\n\n".join(system_parts)})
    if not normalized:
        normalized.append({"role": "user", "content": "Return exactly one valid JSON object."})
    return normalized


# ============================================================================
# Group 2: Model Call Functions
# ============================================================================

def speculative_draft_active() -> bool:
    """Check if speculative draft mode is active."""
    from mico import cli as _cli
    return _speculative_draft_active(_cli.MODEL_PROVIDER, _cli.DRAFT_MODEL)


def draft_mode_name() -> str:
    """Get draft mode name."""
    from mico import cli as _cli
    return _draft_mode_name(_cli.DRAFT_MODEL)


def count_primary_user_turns(history: list[dict[str, str]]) -> int:
    """Count primary user turns in history."""
    return _count_primary_user_turns(history)


def clamp_budget(value: int) -> int:
    """Clamp thinking budget to configured min/max. 0 = thinking disabled (pass-through)."""
    if value <= 0:
        return 0
    from mico import cli as _cli
    return max(_cli.MIN_THINKING_BUDGET, min(_cli.MAX_THINKING_BUDGET, value))


def supports_extended_generation_controls() -> bool:
    """Return True when the active backend accepts Mico's extended generation knobs.

    Local MLX-based servers (mlx_lm, rapid-mlx, mtplx, mlx_vlm) understand
    MLX-native fields such as `enable_thinking`, `thinking_budget`, `min_p`,
    and repetition controls. Treat any local OpenAI-compatible endpoint as
    capable so profile settings survive the transport layer.
    """
    from mico import cli as _cli

    provider = str(getattr(_cli, "MODEL_PROVIDER", "") or "").strip().lower()
    if provider == "mlx":
        return True

    api_base = str(getattr(_cli, "API_BASE", "") or "").strip().lower()
    if provider in {"openai", "lmstudio"}:
        if _cli.os.environ.get("MICO_EXTERNAL_API_BASE"):
            return True
        if "localhost" in api_base or "127.0.0.1" in api_base:
            return True
    return False


def stream_model_text(
    text: str,
    *,
    in_think: bool = False,
    carry: str = "",
    public_output_started: bool = False,
    suppress_think: bool = False,
) -> tuple[bool, str, bool, bool]:
    """Stream model text chunks, handling thinking tags."""
    from mico import cli as _cli

    def stream_monologue_text(t: str) -> None:
        """Stream monologue text through UI."""
        if hasattr(_cli, 'stream_monologue_text'):
            _cli.stream_monologue_text(t)

    def stream_stdout(t: str) -> None:
        """Stream stdout."""
        if hasattr(_cli, 'stream_stdout'):
            _cli.stream_stdout(t)

    def ensure_monologue_open() -> None:
        """Ensure monologue buffer is open."""
        if hasattr(_cli, 'ensure_monologue_open'):
            _cli.ensure_monologue_open()

    def flush_monologue_buffer(force: bool = False) -> None:
        """Flush monologue buffer."""
        if hasattr(_cli, 'flush_monologue_buffer'):
            _cli.flush_monologue_buffer(force=force)

    def tag_suffix_carry(s: str, tags: tuple[str, ...]) -> str:
        """Get carry suffix for incomplete tags."""
        if hasattr(_cli, 'tag_suffix_carry'):
            return _cli.tag_suffix_carry(s, tags)
        return ""

    def looks_like_action_json_fragment(s: str) -> bool:
        """Check if string looks like JSON fragment."""
        if hasattr(_cli, 'looks_like_action_json_fragment'):
            return _cli.looks_like_action_json_fragment(s)
        return False

    expect_action_json = getattr(_cli, "STREAM_EXPECT_ACTION_JSON", True)

    # In REPL/plain mode, stream thinking chunks through stream_monologue_text
    if _cli.USE_PLAIN_STDOUT:
        combined = carry + text
        open_tag = "<think>"
        close_tag = "</think>"
        pos = 0
        new_carry = ""
        while pos < len(combined):
            if in_think:
                tag_index = combined.find(close_tag, pos)
                if tag_index == -1:
                    chunk = combined[pos:]
                    new_carry = tag_suffix_carry(chunk, (close_tag,))
                    emit = chunk[:len(chunk) - len(new_carry)] if new_carry else chunk
                    if emit and not suppress_think and expect_action_json:
                        stream_monologue_text(emit)
                    return True, new_carry, public_output_started, suppress_think
                chunk = combined[pos:tag_index]
                if chunk and not suppress_think and expect_action_json:
                    stream_monologue_text(chunk)
                in_think = False
                suppress_think = False
                pos = tag_index + len(close_tag)
                continue
            tag_index = combined.find(open_tag, pos)
            if tag_index == -1:
                # Outside think tag — decide: public JSON output or internal monologue?
                chunk = combined[pos:]
                carry_out = tag_suffix_carry(chunk, (open_tag,))
                emit = chunk[:len(chunk) - len(carry_out)] if carry_out else chunk
                if emit:
                    # Tool-loop stream expects JSON actions; fast-path stream is plain text.
                    if expect_action_json and not public_output_started:
                        brace_index = emit.find("{")
                        if brace_index == -1:
                            stream_monologue_text(emit)
                        else:
                            prefix = emit[:brace_index]
                            suffix = emit[brace_index:]
                            if prefix:
                                stream_monologue_text(prefix)
                            if suffix:
                                stream_stdout(suffix)
                                public_output_started = True
                    else:
                        stream_stdout(emit)
                        public_output_started = True
                return False, carry_out, public_output_started, suppress_think
            # Text before <think> — same logic: pre-JSON prose → monologue
            chunk = combined[pos:tag_index]
            if chunk:
                if expect_action_json and not public_output_started:
                    brace_index = chunk.find("{")
                    if brace_index == -1:
                        stream_monologue_text(chunk)
                    else:
                        prefix = chunk[:brace_index]
                        suffix = chunk[brace_index:]
                        if prefix:
                            stream_monologue_text(prefix)
                        if suffix:
                            stream_stdout(suffix)
                            public_output_started = True
                else:
                    stream_stdout(chunk)
                    public_output_started = True
            pos = tag_index + len(open_tag)
            in_think = True
            suppress_think = not expect_action_json
        return in_think, new_carry, public_output_started, suppress_think

    combined = carry + text
    open_tag = "<think>"
    close_tag = "</think>"
    pos = 0
    while pos < len(combined):
        if in_think:
            tag_index = combined.find(close_tag, pos)
            if tag_index == -1:
                chunk = combined[pos:]
                carry_out = tag_suffix_carry(chunk, (close_tag,))
                emit = chunk[: len(chunk) - len(carry_out)] if carry_out else chunk
                if emit and not suppress_think:
                    ensure_monologue_open()
                    stream_monologue_text(emit)
                return True, carry_out, public_output_started, suppress_think
            chunk = combined[pos:tag_index]
            if chunk and not suppress_think:
                ensure_monologue_open()
                stream_monologue_text(chunk)
            if not suppress_think:
                flush_monologue_buffer(force=True)
                if not _cli.MONOLOGUE_LINE_START:
                    stream_stdout("\n")
                    _cli.MONOLOGUE_LINE_START = True
            in_think = False
            suppress_think = False
            pos = tag_index + len(close_tag)
            continue

        tag_index = combined.find(open_tag, pos)
        if tag_index == -1:
            chunk = combined[pos:]
            carry_out = tag_suffix_carry(chunk, (open_tag,))
            emit = chunk[: len(chunk) - len(carry_out)] if carry_out else chunk
            if emit:
                if not public_output_started and not looks_like_action_json_fragment(emit):
                    ensure_monologue_open()
                    stream_monologue_text(emit)
                elif emit.strip():
                    flush_monologue_buffer(force=True)
                    if not _cli.MONOLOGUE_LINE_START:
                        stream_stdout("\n")
                        _cli.MONOLOGUE_LINE_START = True
                    public_output_started = True
            return False, carry_out, public_output_started, suppress_think

        chunk = combined[pos:tag_index]
        if chunk:
            if not public_output_started and not looks_like_action_json_fragment(chunk):
                ensure_monologue_open()
                stream_monologue_text(chunk)
            elif chunk.strip():
                flush_monologue_buffer(force=True)
                if not _cli.MONOLOGUE_LINE_START:
                    stream_stdout("\n")
                    _cli.MONOLOGUE_LINE_START = True
                public_output_started = True
        suppress_think = public_output_started
        if not suppress_think:
            ensure_monologue_open()
        _cli.MONOLOGUE_LINE_START = True
        in_think = True
        pos = tag_index + len(open_tag)

    return in_think, "", public_output_started, suppress_think


async def call_model(
    messages: list[dict[str, str]],
    thinking_budget: int | None = None,
    *,
    stream: bool = False,
    use_orchestra: bool = True,
    role: str = "worker",
) -> str:
    """Public entrypoint for model API call. Resolves role-based slot config then delegates."""
    from mico import cli as _cli

    role_cfg_outer: RoleConfig | None = None
    if _cli.ACTIVE_PROFILE is not None:
        role_cfg_outer = resolve_role_model(role, _cli.ACTIVE_PROFILE)
        if role_cfg_outer is None and _cli.ACTIVE_PROFILE.default_role != role:
            role_cfg_outer = resolve_role_model(_cli.ACTIVE_PROFILE.default_role, _cli.ACTIVE_PROFILE)

    slot_for_acquire = role_cfg_outer or RoleConfig(
        model=_cli.MODEL,
        base_url=_cli.API_BASE,
        context=_cli.CONTEXT_WINDOW_TOKENS,
        temperature=_cli.TEMPERATURE,
        max_tokens=_cli.MAX_TOKENS,
        resolved_path=_cli.MODEL,
    )
    # ModelSlot.acquire is currently synchronous. We might need an async lock here.
    async with ModelSlot.acquire(role, slot_for_acquire):
        return await _call_model_impl(
            messages,
            thinking_budget,
            stream=stream,
            use_orchestra=use_orchestra,
            role=role,
            role_cfg=role_cfg_outer,
        )


async def _call_model_impl(
    messages: list[dict[str, str]],
    thinking_budget: int | None = None,
    *,
    stream: bool = False,
    use_orchestra: bool = True,
    role: str = "worker",
    role_cfg: RoleConfig | None = None,
) -> str:
    """Implementation of model API call with streaming, retries, and orchestra support."""
    from mico import cli as _cli

    def compute_request_limits(msgs, budget, max_toks, use_orch):
        if hasattr(_cli, 'compute_request_limits'):
            return _cli.compute_request_limits(msgs, budget, max_toks, use_orch)
        return budget, max_toks, use_orch, None

    def resolve_orchestra_role_configs(r):
        if hasattr(_cli, 'resolve_orchestra_role_configs'):
            return _cli.resolve_orchestra_role_configs(r)
        return None, None

    def expected_mlx_server_running():
        if hasattr(_cli, 'expected_mlx_server_running'):
            return _cli.expected_mlx_server_running()
        return True

    def ensure_server():
        if hasattr(_cli, 'ensure_server'):
            _cli.ensure_server()

    def set_active_model_response(resp):
        if hasattr(_cli, 'set_active_model_response'):
            _cli.set_active_model_response(resp)

    def close_active_model_response():
        if hasattr(_cli, 'close_active_model_response'):
            _cli.close_active_model_response()

    def render_log_line(tag, msg, color):
        if hasattr(_cli, 'render_log_line'):
            _cli.render_log_line(tag, msg, color)

    def update_status(msg):
        if hasattr(_cli, 'update_status'):
            _cli.update_status(msg)

    def runtime_status_set(stage, detail=""):
        if hasattr(_cli, 'runtime_status_set'):
            _cli.runtime_status_set(stage, detail)

    def runtime_status_request_sent(detail="chat"):
        if hasattr(_cli, 'runtime_status_request_sent'):
            _cli.runtime_status_request_sent(detail)

    def runtime_status_first_token():
        if hasattr(_cli, 'runtime_status_first_token'):
            _cli.runtime_status_first_token()

    def ensure_monologue_open():
        if hasattr(_cli, 'ensure_monologue_open'):
            _cli.ensure_monologue_open()

    def stream_monologue_text(text):
        if hasattr(_cli, 'stream_monologue_text'):
            _cli.stream_monologue_text(text)

    def read_server_log_tail():
        if hasattr(_cli, 'read_server_log_tail'):
            return _cli.read_server_log_tail()
        return ""

    COLOR_PLAN = getattr(_cli, 'COLOR_PLAN', 'cyan')
    COLOR_NARRATE = getattr(_cli, 'COLOR_NARRATE', 'white')

    requested_budget = _cli.THINKING_BUDGET if thinking_budget is None else clamp_budget(thinking_budget)
    normalized_messages = normalize_messages_for_model(messages)
    effective_budget, effective_max_tokens, effective_orchestra, governor_reason = compute_request_limits(
        normalized_messages,
        requested_budget,
        _cli.MAX_TOKENS,
        use_orchestra,
    )
    if governor_reason:
        if not _cli.USE_PLAIN_STDOUT:
            render_log_line(
                "memory",
                f"{governor_reason}; budget={effective_budget} max_tokens={effective_max_tokens} orchestra={'off' if not effective_orchestra else 'on'}",
                COLOR_PLAN,
            )

    _raw_model = _cli.MODEL
    model_for_request = _raw_model
    effective_messages = normalized_messages
    analyzer_cfg, final_cfg = resolve_orchestra_role_configs(role)
    orchestra_active = bool(
        effective_orchestra and _cli.ORCHESTRA_ENABLED and _cli.MODEL_PROVIDER == "mlx" and analyzer_cfg and final_cfg
    )
    
    if orchestra_active:
        analyzer_model = analyzer_cfg.resolved_path or analyzer_cfg.model
        final_model = final_cfg.resolved_path or final_cfg.model
        model_for_request = final_model
        record_orchestra_trace(
            enabled=True,
            analyzer_model=model_label(analyzer_model),
            final_model=model_label(final_model),
        )
        note_turn_model(analyzer_model)
        note_turn_model(final_model)
        update_status("orchestrating analyzer")
        try:
            analyzer_payload = {
                "model": analyzer_model,
                "messages": [
                    {
                        "role": "system",
                        "content": (
                            "You are an orchestration analyzer for a coding agent. "
                            "Return exactly one JSON object with keys: "
                            "intent, task_kind, next_action, tool_choice, stop_if_answered, concise_answer_ok. "
                            "Prefer concise directives. stop_if_answered must be true when one successful tool result is enough."
                        ),
                    },
                    {
                        "role": "user",
                        "content": json.dumps(normalized_messages[-8:], ensure_ascii=False),
                    },
                ],
                "stream": False,
                "temperature": analyzer_cfg.temperature,
                "max_tokens": min(384, analyzer_cfg.max_tokens or 384),
            }
            if supports_extended_generation_controls():
                from mico.server import _is_vlm_model as _avlm
                if not _avlm(str(getattr(_cli, "MODEL", "") or "")):
                    analyzer_payload["enable_thinking"] = False
                    analyzer_payload["thinking_budget"] = _cli.MIN_THINKING_BUDGET
            async with httpx.AsyncClient(timeout=180) as client:
                runtime_status_request_sent("analyzer")
                analyzer_resp = await client.post(
                    f"{analyzer_cfg.base_url.rstrip('/')}/chat/completions",
                    json=analyzer_payload,
                    headers={"Authorization": f"Bearer {_cli.API_KEY}"},
                )
                analyzer_resp.raise_for_status()
                analyzer_response = analyzer_resp.json()
            
            analyzer_choices = analyzer_response.get("choices") or []
            if not analyzer_choices:
                raise RuntimeError("Analyzer response contained no choices.")
            analyzer_text = _ect(analyzer_choices[0])
            if not analyzer_text:
                raise RuntimeError("Analyzer response contained no text content.")
            record_orchestra_trace(analyzer_raw_preview=truncate(strip_thinking(analyzer_text), 220))
            analyzer_data: dict[str, Any] | None = None
            try:
                analyzer_data = extract_json(analyzer_text)
            except Exception:
                analyzer_data = None
            valid_handoff, invalid_reason = validate_orchestra_handoff(analyzer_data)
            record_orchestra_trace(
                analyzer_valid=valid_handoff,
                analyzer_invalid_reason=invalid_reason or None,
            )
            if valid_handoff and analyzer_data is not None:
                analyzer_summary = analyzer_data
                record_orchestra_trace(analyzer=analyzer_summary, handoff_injected=True)
                analyzer_preview = truncate(json.dumps(analyzer_summary, ensure_ascii=False), 220)
                analyzer_notes = (
                    "BEGIN_ORCHESTRA_HANDOFF\n"
                    + json.dumps(analyzer_summary, ensure_ascii=False)
                    + "\nEND_ORCHESTRA_HANDOFF\n\n"
                    + "The orchestra handoff above is advisory metadata only. "
                    + "Do not echo it, continue it as prose, or quote it. "
                    + "Your output must still be exactly one JSON action object."
                )
                effective_messages = list(normalized_messages)
                if effective_messages and effective_messages[0].get("role") == "system":
                    effective_messages[0] = {
                        "role": "system",
                        "content": str(effective_messages[0].get("content", "")).rstrip() + "\n\n" + analyzer_notes,
                    }
                else:
                    effective_messages.insert(0, {"role": "system", "content": analyzer_notes})
                render_log_line(
                    "orchestra",
                    (
                        f"{model_label(analyzer_model)} -> {model_label(final_model)}"
                        f"\n    handoff: {analyzer_preview}"
                    ),
                    COLOR_NARRATE,
                )
            else:
                record_orchestra_trace(
                    analyzer=({"intent": truncate(str(analyzer_text), 400)} if analyzer_text else None),
                    handoff_injected=False,
                )
                effective_messages = normalized_messages
                render_log_line("orchestra", f"invalid handoff skipped: {invalid_reason or 'parse failed'}", COLOR_PLAN)
        except Exception as exc:
            record_orchestra_trace(
                analyzer_error=truncate(str(exc), 180),
                analyzer_valid=False,
                handoff_injected=False,
            )
            render_log_line("orchestra", f"analyzer skipped: {truncate(str(exc), 180)}", COLOR_PLAN)
            effective_messages = normalized_messages

        update_status("orchestrating final")
    else:
        note_turn_model(model_for_request)

    effective_temperature = _cli.TEMPERATURE
    if speculative_draft_active() and draft_mode_name() == "assistant":
        effective_temperature = 0.0

    # Role-based profile override
    role_api_base = _cli.API_BASE
    if orchestra_active and final_cfg is not None:
        role_api_base = final_cfg.base_url.rstrip("/")
        effective_temperature = final_cfg.temperature
        if final_cfg.max_tokens:
            effective_max_tokens = min(effective_max_tokens, final_cfg.max_tokens) if effective_max_tokens else final_cfg.max_tokens
    elif role_cfg is not None:
        if role_cfg.resolved_path:
            model_for_request = role_cfg.resolved_path
        role_api_base = role_cfg.base_url.rstrip("/")
        effective_temperature = role_cfg.temperature
        if role_cfg.max_tokens:
            effective_max_tokens = min(effective_max_tokens, role_cfg.max_tokens) if effective_max_tokens else role_cfg.max_tokens

    payload = {
        "model": model_for_request,
        "messages": effective_messages,
        "stream": stream,
        "temperature": effective_temperature,
        "max_tokens": effective_max_tokens,
    }
    if stream:
        payload["stream_options"] = {"include_usage": True}
    if supports_extended_generation_controls():
        from mico.server import _is_vlm_model as _is_vlm
        _is_vlm_backend = _is_vlm(str(getattr(_cli, "MODEL", "") or ""))
        enable_thinking = _cli.THINKING and effective_budget > 0
        if not _is_vlm_backend:
            # mlx_vlm server does not accept request-level thinking params — skip them
            payload["enable_thinking"] = enable_thinking
            if enable_thinking:
                payload["thinking_budget"] = effective_budget
        if _cli.SAMPLING_MIN_P > 0:
            payload["min_p"] = _cli.SAMPLING_MIN_P
        if _cli.SAMPLING_REPETITION_PENALTY != 1.0:
            payload["repetition_penalty"] = _cli.SAMPLING_REPETITION_PENALTY
            payload["repetition_context_size"] = _cli.SAMPLING_REPETITION_CONTEXT

    last_error: Exception | None = None
    for attempt in range(len(_cli.MODEL_RETRY_DELAYS) + 1):
        try:
            request_started_at = time.time()
            if _cli.MODEL_PROVIDER == "mlx" and not expected_mlx_server_running():
                ensure_server()
            
            profile_name = str(getattr(_cli.ACTIVE_PROFILE, "name", "") or "").strip().lower()
            if profile_name == "tight":
                request_timeout = 45
            elif profile_name == "fast":
                request_timeout = 75
            elif profile_name == "balanced":
                request_timeout = 120
            else:
                request_timeout = 180

            async with httpx.AsyncClient(timeout=request_timeout) as client:
                if stream:
                    runtime_status_request_sent("chat")
                    async with client.stream(
                        "POST",
                        f"{role_api_base}/chat/completions",
                        json=payload,
                        headers={"Authorization": f"Bearer {_cli.API_KEY}"},
                    ) as response:
                        response.raise_for_status()
                        set_active_model_response(response)
                        chunks: list[str] = []
                        usage_stats: tuple[int, int, int] | None = None
                        in_think = False
                        carry = ""
                        public_output_started = False
                        suppress_think = False

                        async for raw_line in response.aiter_lines():
                            if _cli.CANCEL_REQUESTED.is_set():
                                # We can't easily close httpx response from here without affecting the loop
                                raise ModelStreamCancelled("Cancelled.")
                            if not raw_line:
                                continue
                            line = raw_line.strip()
                            if not line.startswith("data:"):
                                continue
                            data_line = line[5:].strip()
                            if data_line == "[DONE]":
                                break
                            try:
                                payload_line = json.loads(data_line)
                            except json.JSONDecodeError:
                                continue
                            usage_stats = normalize_usage_payload(payload_line.get("usage")) or usage_stats
                            choice = (payload_line.get("choices") or [{}])[0]
                            reasoning_chunk = _ecr(choice)
                            if reasoning_chunk:
                                ensure_monologue_open()
                                stream_monologue_text(reasoning_chunk)
                            chunk = _ect(choice)
                            if not chunk:
                                continue
                            runtime_status_first_token()
                            for _s in ("<|im_end|>", "<|im_start|>", "<|endoftext|>"):
                                chunk = chunk.replace(_s, "")
                            if not chunk:
                                continue
                            chunks.append(chunk)
                            in_think, carry, public_output_started, suppress_think = stream_model_text(
                                chunk,
                                in_think=in_think,
                                carry=carry,
                                public_output_started=public_output_started,
                                suppress_think=suppress_think,
                            )
                        
                        full_text = "".join(chunks)
                        if usage_stats is None:
                            prompt_estimate = estimate_prompt_tokens(effective_messages)
                            completion_estimate = estimate_tokens_from_text(full_text)
                            usage_stats = (prompt_estimate, completion_estimate, prompt_estimate + completion_estimate)
                            estimated = True
                        else:
                            estimated = False
                        record_turn_usage(
                            prompt_tokens=usage_stats[0],
                            completion_tokens=usage_stats[1],
                            total_tokens=usage_stats[2],
                            llm_seconds=time.time() - request_started_at,
                            estimated=estimated,
                        )
                        return full_text
                else:
                    runtime_status_request_sent("chat")
                    response = await client.post(
                        f"{role_api_base}/chat/completions",
                        json=payload,
                        headers={"Authorization": f"Bearer {_cli.API_KEY}"},
                    )
                    response.raise_for_status()
                    data = response.json()
                    usage_stats = normalize_usage_payload(data.get("usage"))
                    choices = data.get("choices") or []
                    if not choices:
                        raise RuntimeError("Model response contained no choices.")
                    content = _ect(choices[0])
                    if content is None:
                        raise RuntimeError("Model response contained no text content.")
                    runtime_status_first_token()
                    if usage_stats is None:
                        prompt_estimate = estimate_prompt_tokens(effective_messages)
                        completion_estimate = estimate_tokens_from_text(content)
                        usage_stats = (prompt_estimate, completion_estimate, prompt_estimate + completion_estimate)
                        estimated = True
                    else:
                        estimated = False
                    record_turn_usage(
                        prompt_tokens=usage_stats[0],
                        completion_tokens=usage_stats[1],
                        total_tokens=usage_stats[2],
                        llm_seconds=time.time() - request_started_at,
                        estimated=estimated,
                    )
                    return content
        except ModelStreamCancelled:
            raise
        except Exception as exc:
            if _cli.CANCEL_REQUESTED.is_set():
                raise ModelStreamCancelled("Cancelled.") from exc
            last_error = exc
            _cli.MODEL_RETRY_COUNT += 1
            if attempt >= len(_cli.MODEL_RETRY_DELAYS):
                break
            delay = _cli.MODEL_RETRY_DELAYS[attempt]
            err_text = str(exc).lower()
            is_connection_dead = any(t in err_text for t in ("connection refused", "connection error", "newconnectionerror", "max retries exceeded"))
            
            if is_connection_dead and _cli.MODEL_PROVIDER == "mlx":
                render_log_line("server", "model sunucusu düştü, yeniden başlatılıyor...", COLOR_PLAN)
                # ... restart logic (might need to be async) ...
            else:
                msg = f"sunucu yanıt vermedi, yeniden deniyor ({attempt + 1}/{len(_cli.MODEL_RETRY_DELAYS) + 1})..."
                update_status(msg)
            await asyncio.sleep(delay)
        finally:
            set_active_model_response(None)

    detail = read_server_log_tail()
    raise RuntimeError(f"Model backend failed after retries.\nLast error: {last_error}\nRecent server log:\n{detail}")


async def summarize_history(history: list[dict[str, str]]) -> str:
    """Summarize history for context preservation."""
    return await _summarize_history(
        history,
        call_model=call_model,
        normalize_compact_summary=normalize_compact_summary,
    )


async def repair_action_response(
    raw: str,
    history: list[dict[str, str]],
    task_state_summary: str = "",
) -> tuple[dict[str, Any], str]:
    """Repair invalid action response from model."""
    from mico.task_classify import task_prefers_brief_answer
    from mico.history_utils import recent_user_message

    import mico.cli as _cli_mod
    _call_model = getattr(_cli_mod, "call_model", call_model)
    return await _repair_action_response(
        raw,
        history,
        strip_thinking=strip_thinking,
        truncate=truncate,
        recent_user_message=recent_user_message,
        task_prefers_brief_answer=task_prefers_brief_answer,
        call_model=_call_model,
        min_thinking_budget=_get_min_thinking_budget(),
        extract_json=extract_json,
        task_state_summary=task_state_summary,
    )


def fallback_history_summary(history: list[dict[str, str]]) -> str:
    """Generate fallback summary if normal summarization fails."""
    return _fallback_history_summary(history, truncator=truncate)


def _get_min_thinking_budget() -> int:
    """Get MIN_THINKING_BUDGET from cli module."""
    from mico import cli as _cli
    return _cli.MIN_THINKING_BUDGET


def truncate(text: str, limit: int) -> str:
    """Get truncate function from cli module."""
    from mico import cli as _cli
    if hasattr(_cli, 'truncate'):
        return _cli.truncate(text, limit)
    if len(text) <= limit:
        return text
    return text[:limit] + f"\n...[truncated {len(text) - limit} chars]"
