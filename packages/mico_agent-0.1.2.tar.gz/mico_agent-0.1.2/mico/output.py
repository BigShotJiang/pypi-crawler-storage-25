from __future__ import annotations

from typing import Any


def format_elapsed_compact(seconds: float | int) -> str:
    total_seconds = max(0, int(seconds))
    hours, remainder = divmod(total_seconds, 3600)
    minutes, secs = divmod(remainder, 60)
    if hours:
        return f"{hours}h {minutes:02d}m {secs:02d}s"
    return f"{minutes}m {secs:02d}s"


def usage_footer_text(
    *,
    prompt_tokens: int,
    completion_tokens: int,
    total_tokens: int,
    llm_seconds: float,
    estimated: bool,
    llm_calls: int,
    tool_calls: int,
    active_profile: str,
) -> str:
    if completion_tokens > 0 and llm_seconds > 0:
        rate_text = f"{(completion_tokens / llm_seconds):.1f} tok/s"
    else:
        rate_text = "tok/s n/a"
    suffix = " approx" if estimated else ""
    return (
        f"calls llm/tool: {llm_calls}/{tool_calls} | "
        f"tokens in/out/total: {prompt_tokens}/{completion_tokens}/{total_tokens}{suffix} | "
        f"{rate_text} | model-profile: {active_profile}"
    )


def format_final_summary(payload: dict[str, Any]) -> str:
    if not isinstance(payload, dict):
        payload = {}

    sections: list[str] = []

    summary = str(payload.get("summary") or "").strip()
    sections.append("## Summary\n" + (summary if summary else "(no summary)"))

    changed = list(payload.get("changed_files") or [])
    added = list(payload.get("added_files") or [])
    deleted = list(payload.get("deleted_files") or [])
    if changed or added or deleted:
        lines = ["## Changed files"]
        for path in changed:
            lines.append(f"- {path}")
        for path in added:
            lines.append(f"- {path} (added)")
        for path in deleted:
            lines.append(f"- {path} (deleted)")
        sections.append("\n".join(lines))

    tests = payload.get("tests")
    if isinstance(tests, dict):
        lines = ["## Tests"]
        cmd = str(tests.get("command") or "").strip()
        if cmd:
            lines.append(f"command: {cmd}")
        if "exit_code" in tests and tests.get("exit_code") is not None:
            lines.append(f"exit_code: {tests.get('exit_code')}")
        tsum = str(tests.get("summary") or "").strip()
        if tsum:
            lines.append(tsum)
        errors = tests.get("errors")
        if errors:
            lines.append("errors:")
            lines.append(str(errors).rstrip())
        if len(lines) > 1:
            sections.append("\n".join(lines))

    review = payload.get("review")
    if isinstance(review, dict):
        risks = list(review.get("risks") or [])
        missing = list(review.get("missing") or [])
        if risks or missing:
            lines = ["## Review"]
            for item in risks:
                lines.append(f"- risk: {item}")
            for item in missing:
                lines.append(f"- missing: {item}")
            sections.append("\n".join(lines))

    next_steps = list(payload.get("next_steps") or [])
    if next_steps:
        lines = ["## Next steps"]
        for idx, step in enumerate(next_steps, start=1):
            lines.append(f"{idx}. {step}")
        sections.append("\n".join(lines))

    commit_suggestion = payload.get("commit_suggestion")
    if commit_suggestion and str(commit_suggestion).strip():
        sections.append("## Commit\n" + str(commit_suggestion).strip())

    return "\n\n".join(sections)


def parse_git_status_paths(status_text: str) -> tuple[list[str], list[str], list[str]]:
    changed: list[str] = []
    added: list[str] = []
    deleted: list[str] = []
    if not status_text or status_text.strip() in {"clean", "not a git repo"}:
        return changed, added, deleted
    for line in status_text.splitlines():
        if not line or len(line) < 3:
            continue
        if line.startswith("##"):
            continue
        code = line[:2]
        path = line[3:].strip()
        if not path:
            continue
        if " -> " in path:
            path = path.split(" -> ", 1)[1].strip()
        if "D" in code:
            deleted.append(path)
        elif "A" in code or code.strip() == "??":
            added.append(path)
        else:
            changed.append(path)
    return changed, added, deleted

