"""Task classification and analysis module.

Extracted from cli.py to provide task classification, mode resolution, and
goal-directed action dispatch for different task types.
"""

from __future__ import annotations

import re
from typing import Any

# Constants
AUDIT_HEAVY_TASK_CHARS = 220

_BUILD_VERBS_TR = (
    "yap", "oluştur", "olustur", "kur", "yaz", "yarat", "geliştir", "gelistir",
    "ekle", "build", "create", "make", "implement", "set up", "scaffold",
    "automate", "otomatize", "scripti", "betik", "tool yaz", "uygulama",
)


def extract_task_body(task: str) -> str:
    marker = "Task:\n"
    if marker in task:
        return task.rsplit(marker, 1)[-1].strip()
    return task.strip()


def classify_task(task: str) -> str:
    body = extract_task_body(task).strip()
    lowered = body.lower()
    if not body:
        return "empty"

    # --- Trivial greetings ---
    # Only treat as trivial if it's JUST a greeting — no task words after it
    _greeting_words = {"merhaba", "selam", "hello", "hi", "hey", "yo", "sup"}
    _task_words = {"bul", "yap", "çalıştır", "calistir", "göster", "goster", "listele",
                   "sil", "yaz", "oluştur", "olustur", "kontrol", "ara", "tara", "tara",
                   "find", "run", "show", "list", "create", "check", "scan", "search",
                   "kullan", "use", "nmap", "git", "curl", "install", "başlat", "baslat"}
    if len(body) <= 40 and lowered.strip() in _greeting_words or lowered in {"selam", "merhaba", "hello", "hi", "sadece merhaba de"}:
        return "trivial_chat"
    if len(body) <= 80:
        words = lowered.split()
        first_word = words[0] if words else ""
        if first_word in _greeting_words and not any(w in _task_words for w in words[1:]):
            return "trivial_chat"

    # --- Read-only git queries (fast path before agentic_verbs check) ---
    _git_readonly_patterns = (
        "git durumu", "git status", "git log", "git diff", "git branch",
        "git ne durumda", "son commit", "mevcut branch", "hangi branch",
    )
    if len(body) <= 120 and any(p in lowered for p in _git_readonly_patterns):
        return "local_info"

    # --- "Run this file" shortcut (fast path before agentic_verbs check) ---
    # e.g. "/tmp/foo.py calistir", "hello.py dosyasini calistir", "run foo.py"
    _RUN_FILE_RE1 = re.search(
        r'(?:^|[\s/])\S+\.(?:py|sh|js|ts|rb)'
        r'.*?(?:calistir|çalıştır|dosyasini calistir|dosyasını çalıştır|run|execute)',
        lowered,
    )
    _RUN_FILE_RE2 = re.search(
        r'(?:run|execute|calistir|çalıştır).*?(?:^|[\s/])\S+\.(?:py|sh|js|ts|rb)',
        lowered,
    )
    if len(body) <= 200 and (_RUN_FILE_RE1 or _RUN_FILE_RE2):
        return "local_info"

    # --- Local system info (single tool call, no file editing) ---
    local_info_patterns = [
        "ip adres", "ip ne", "what is my ip", "my ip",
        "hostname", "host name", "pwd",
        "working directory", "current directory",
        "hangi klasor", "hangi klasörde",
        "whoami", "kullanici ad",
        "saat kac", "saat kaç", "tarih ne",
        "ağdaki cihaz", "agdaki cihaz", "network device", "list device",
        "arp -a", "yerel ağ", "yerel ag", "local network",
    ]
    if len(body) <= 120 and any(pattern in lowered for pattern in local_info_patterns):
        return "local_info"

    # --- Agentic intent: requires tools/filesystem ---
    agentic_verbs = {
        # Turkish
        "oluştur", "yaz", "yarat", "ekle", "sil", "düzelt", "değiştir", "güncelle",
        "çalıştır", "kur", "yükle", "taşı", "kopyala", "bul", "ara", "listele",
        "git", "commit", "push", "pull", "merge", "rebase",
        "refactor", "optimize", "debug", "test", "çalıştır",
        "implement", "build", "deploy", "run",
        # English
        "create", "write", "make", "add", "delete", "remove", "edit", "update", "change",
        "run", "execute", "install", "move", "copy", "find", "search", "list",
        "fix", "debug", "refactor", "implement", "build", "deploy",
        "check", "show", "read", "open", "oku", "göster",
    }
    words = set(lowered.replace(",", " ").replace(".", " ").split())
    if words & agentic_verbs:
        return "project_work"
    # File path patterns signal agentic intent: explicit extensions or absolute paths
    _KNOWN_EXTS = r'(?:py|js|ts|go|rs|c|cpp|h|java|rb|sh|md|json|yaml|yml|toml|txt|html|css)'
    if re.search(rf'\b\w+\.{_KNOWN_EXTS}\b', lowered) or re.search(r'(?:^|[\s])/\w+/', lowered):
        return "project_work"

    # --- Capability/meta questions stay brief even if they mention code words ---
    _meta_question_starters = {
        "yeterli", "yeterince", "var mi", "var mı", "mevcut mu", "destekliyor mu",
        "yapabilir mi", "yapabilir misin", "ne kadar", "nasil", "nasıl",
        "ne zaman", "neden", "niye", "kaç tane", "kaç", "hangi",
        "can you", "do you", "does it", "is there", "are there", "how many",
        "what is", "what are", "which", "why", "when",
    }
    _is_meta_question = (
        len(body) <= 150
        and (
            any(lowered.startswith(s) for s in _meta_question_starters)
            or any(s in lowered for s in _meta_question_starters)
            or "?" in body
        )
        and any(s in lowered for s in _meta_question_starters)
    )
    if _is_meta_question:
        return "brief_general"

    # --- Explicit project/code references (whole-word match) ---
    repo_terms = {
        "repo", "proje", "project", "readme",
        "bug", "review", "audit", "plan",
        "kod", "code", "file",
        "orchestra", "session", "fonksiyon", "function", "class", "module",
    }
    if words & repo_terms:
        return "project_work"

    # --- Commands that need tool execution → project_work even if short ---
    _exec_verbs = {"nmap", "curl", "ping", "ssh", "brew", "pip", "npm", "docker",
                   "kullan", "çalıştır", "calistir", "tara", "bul", "listele",
                   "run", "scan", "find", "execute", "install", "başlat", "baslat"}
    if words & _exec_verbs:
        return "project_work"

    # --- Sorular internet/güncel veri gerektiriyorsa tool_loop'a yönlendir ---
    _web_signals = {
        "link", "url", "sitesinden", "site", "websitesi", "web sitesi",
        "güncel", "guncel", "son", "latest", "current", "live",
        "en çok", "en cok", "most", "top", "popular", "trending",
        "indirilen", "downloaded", "indir",
        "fiyat", "price", "haber", "news",
        "huggingface", "github", "twitter", "reddit",
        "bağlantı", "baglanti",
    }
    if words & _web_signals:
        return "project_work"

    # --- Short general questions (math, knowledge, small talk) → no tools needed ---
    if len(body) <= 120 and body.count("\n") == 0:
        return "brief_general"
    return "general"


def task_prefers_minimal_context(task: str) -> bool:
    return classify_task(task) in {"trivial_chat", "local_info", "brief_general"}


def task_prefers_brief_answer(task: str) -> bool:
    return classify_task(task) in {"trivial_chat", "local_info", "brief_general"}


def task_is_code_focused(task: str) -> bool:
    lowered = extract_task_body(task).lower()
    keywords = (
        "bug",
        "fix",
        "duzelt",
        "düzelt",
        "refactor",
        "implement",
        "ekle",
        "add test",
        "test ekle",
        "write code",
        "kod yaz",
        "patch",
        "diff",
        "rename",
        "cleanup",
        "lint",
        "compile",
        "failing test",
        "pytest",
        "unit test",
        "readme",
        "function",
        "class",
        ".py",
        ".ts",
        ".tsx",
        ".js",
        ".jsx",
        ".go",
        ".rs",
    )
    return any(keyword in lowered for keyword in keywords)


def task_is_security_sensitive(task: str) -> bool:
    lowered = extract_task_body(task).lower()
    keywords = (
        "pentest",
        "audit",
        "nmap",
        "ffuf",
        "gobuster",
        "sqlmap",
        "hydra",
        "vulnerability",
        "zafiyet",
        "security",
        "exploit",
        "recon",
        "tls",
        "httpx",
        "subfinder",
        "amass",
        "gitleaks",
        "trufflehog",
    )
    return any(keyword in lowered for keyword in keywords)


def task_needs_memory_guard(task: str, ctx: Any | None = None) -> bool:
    body = extract_task_body(task)
    lowered = body.lower()
    effective_mode = resolve_mode_for_task(task, ctx) if ctx is not None else "auto"
    if effective_mode == "audit" and len(body) >= AUDIT_HEAVY_TASK_CHARS:
        return True
    heavy_markers = (
        "captive portal",
        "portal",
        "bypass",
        "script yaz",
        "username",
        "password",
        "interval",
        "192.168.",
        "10.",
        "172.16.",
    )
    return task_is_security_sensitive(task) and any(marker in lowered for marker in heavy_markers)


def task_is_captive_portal_workflow(task: str) -> bool:
    body = extract_task_body(task).lower()
    required = ("captive portal" in body or "portal" in body) and ("192.168." in body or "hotspot" in body)
    followthrough = any(marker in body for marker in ("red ver", "kaç sn", "kac sn", "interval", "script", "username", "password"))
    return required and followthrough


def resolve_mode_for_task(task: str, ctx: Any) -> str:
    explicit_mode = str(getattr(ctx, "mode", "auto") or "auto")
    if explicit_mode == "exec":
        explicit_mode = "auto"
    if explicit_mode != "auto":
        return explicit_mode
    body = extract_task_body(task).lower()
    if task_prefers_brief_answer(task):
        return "auto"
    if any(token in body for token in ("review", "code review", "findings first", "request changes", "bug bul")):
        return "review"
    if any(token in body for token in ("plan", "roadmap", "adim adim plan", "step-by-step plan", "uygulama plani")):
        return "plan"
    # Captive portal script writing → code mode, not audit
    if task_is_captive_portal_workflow(task):
        return "code"
    if task_is_security_sensitive(task):
        return "audit"
    if task_is_code_focused(task):
        return "code"
    return "auto"


def current_dispatch_mode(ctx: Any, task: str = "") -> str:
    explicit = str(getattr(ctx, "mode", "auto") or "auto")
    if explicit in {"fast", "normal", "deep", "docs", "ship-safe"}:
        explicit = "auto"
    if explicit == "exec":
        explicit = "auto"
    if explicit != "auto":
        return explicit
    return resolve_mode_for_task(task, ctx) if task else "auto"


def state_dispatch_mode(state: Any) -> str:
    return str(getattr(state, "current_mode", "") or getattr(state, "mode", "") or "auto")


def task_uses_orchestra(task: str, ctx: Any = None) -> bool:
    effective_mode = resolve_mode_for_task(task, ctx) if ctx is not None else "exec"
    if classify_task(task) in {"trivial_chat", "local_info"}:
        return False
    if effective_mode == "code":
        return False
    if ctx is None:
        return True
    if effective_mode in {"plan", "review"}:
        return True
    if ctx.profile == "deep":
        return True
    return "orchestra" in extract_task_body(task).lower()


def task_requests_code_inspection(task: str) -> bool:
    body = extract_task_body(task).lower()
    patterns = (
        "incele",
        "inspect",
        "summarize",
        "özet",
        "ozet",
        "anlat",
        "read through",
        "tool_loop",
        "function",
    )
    return any(pattern in body for pattern in patterns)


def task_goal_tag(task: str) -> str | None:
    if classify_task(task) != "local_info":
        return None
    body = extract_task_body(task)
    lowered = body.lower()
    if any(token in lowered for token in ["ip adres", "what is my ip", "my ip", "ip ne"]):
        return "local_ip"
    if "hostname" in lowered or "host name" in lowered:
        return "hostname"
    if "pwd" in lowered or "working directory" in lowered or "current directory" in lowered:
        return "cwd"
    if "whoami" in lowered or "kullanici ad" in lowered:
        return "whoami"
    if "saat kaç" in lowered or "saat kac" in lowered or lowered == "date" or "tarih ne" in lowered:
        return "time"
    if any(p in lowered for p in ("ağdaki cihaz", "agdaki cihaz", "network device", "list device", "yerel ağ", "yerel ag", "local network")):
        return "network_devices"
    # Read-only git queries
    if any(p in lowered for p in ("git durumu", "git status", "git ne durumda")):
        return "git_status"
    if any(p in lowered for p in ("git log", "son commit", "last commit")):
        return "git_log"
    if any(p in lowered for p in ("git branch", "mevcut branch", "hangi branch", "current branch")):
        return "git_branch"
    if any(p in lowered for p in ("git diff",)):
        return "git_diff"
    # Run file shortcut — extract the file path
    _rf1 = re.search(
        r'((?:/\S+|[\w.-]+)\.(?:py|sh|js|ts|rb))'
        r'.*?(?:calistir|çalıştır|run|execute)',
        lowered,
    )
    _rf2 = re.search(
        r'(?:calistir|çalıştır|run|execute).*?((?:/\S+|[\w.-]+)\.(?:py|sh|js|ts|rb))',
        lowered,
    )
    _rf_match = _rf1 or _rf2
    if _rf_match:
        # Recover original-case path from body
        path_lower = _rf_match.group(1)
        idx = lowered.find(path_lower)
        path_orig = body[idx : idx + len(path_lower)] if idx >= 0 else path_lower
        return f"run_file:{path_orig}"
    return None


def preferred_local_info_action(goal: str | None) -> dict[str, Any] | None:
    if goal == "local_ip":
        return {"type": "tool", "tool": "bash", "command": "ipconfig getifaddr en0 2>/dev/null || ifconfig | grep 'inet ' | grep -v '127.0.0.1' | awk '{print $2}'", "timeout": 10000}
    if goal == "hostname":
        return {"type": "tool", "tool": "bash", "command": "hostname", "timeout": 120000}
    if goal == "cwd":
        return {"type": "tool", "tool": "bash", "command": "pwd", "timeout": 120000}
    if goal == "git_status":
        return {"type": "tool", "tool": "git_tool", "op": "status"}
    if goal == "git_log":
        return {"type": "tool", "tool": "git_tool", "op": "log"}
    if goal == "git_branch":
        return {"type": "tool", "tool": "git_tool", "op": "branch"}
    if goal == "git_diff":
        return {"type": "tool", "tool": "git_tool", "op": "diff"}
    if goal == "whoami":
        return {"type": "tool", "tool": "bash", "command": "whoami", "timeout": 120000}
    if goal == "network_devices":
        return {"type": "tool", "tool": "bash", "command": "/usr/sbin/arp -a", "timeout": 15000}
    if goal == "time":
        return {"type": "tool", "tool": "bash", "command": "date", "timeout": 120000}
    if goal and goal.startswith("run_file:"):
        path = goal[len("run_file:"):]
        ext = path.rsplit(".", 1)[-1].lower() if "." in path else ""
        if ext == "py":
            cmd = f"python3 {path}"
        elif ext == "sh":
            cmd = f"bash {path}"
        elif ext in ("js", "ts"):
            cmd = f"node {path}"
        elif ext == "rb":
            cmd = f"ruby {path}"
        else:
            cmd = path
        return {"type": "tool", "tool": "bash", "command": cmd, "timeout": 30000}
    return None


def action_goal_tag(action: dict[str, Any]) -> str | None:
    if action.get("type") != "tool":
        return None
    label = str(action.get("tool", ""))
    if label == "bash":
        command = str(action.get("command", "")).lower()
        if "ipconfig getifaddr" in command or "ifconfig" in command:
            return "local_ip"
        if "hostname" in command:
            return "hostname"
        if re.search(r"\bpwd\b", command):
            return "cwd"
        if re.search(r"\bwhoami\b", command):
            return "whoami"
        if re.search(r"\bdate\b", command):
            return "time"
        _rf = re.search(r'\b(python3?|bash|node|ruby)\s+(\S+\.(?:py|sh|js|ts|rb))\b', command)
        if _rf:
            return f"run_file:{_rf.group(2)}"
        return None
    if label == "macos_admin_task":
        name = str(action.get("name", "")).lower()
        if name == "list_network_interfaces":
            return "local_ip"
    if label == "git_tool":
        op = str(action.get("op", "")).lower()
        if op == "status":
            return "git_status"
        if op == "log":
            return "git_log"
        if op == "branch":
            return "git_branch"
        if op == "diff":
            return "git_diff"
    return None


def task_needs_planning(task: str) -> bool:
    """Check if a task needs structured planning (multi-step build-style tasks)."""
    t = (task or "").lower()
    if len(t) < 25:
        return False
    if any(v in t for v in _BUILD_VERBS_TR):
        return True
    # Multi-clause sentence: comma + time-related keywords
    if t.count(",") >= 1 and any(w in t for w in ("sonra", "ardından", "dakikada", "saniyede")):
        return True
    return False


def planning_hint_message() -> dict:
    """Return a coaching message for planning-aware tasks."""
    return {
        "role": "user",
        "content": (
            "Plan kuralı: Bu görev birden fazla adım gerektiriyor.\n"
            "Birinci adımı çalıştırmadan önce kafanda 3-5 maddelik bir plan oluştur.\n"
            "İlk action'da type='tool' ile (genellikle write_file veya read_file) "
            "ilk somut adımı çalıştır. Final'a ancak tüm adımlar bittikten sonra dön. "
            "Kodu chat'e yapıştırma — write_file kullan."
        ),
    }
