"""Change limits and task size classification for mico."""
from __future__ import annotations

from dataclasses import dataclass


@dataclass
class LimitCheckResult:
    """Result of limit checking."""
    profile: str
    files_changed: int
    new_files: int
    lines_changed: int
    max_files_changed: int
    max_new_files: int
    max_lines_changed: int
    exceeded: bool
    exceeded_fields: list[str]


# Profile-specific limits for change scope
PROFILE_LIMITS = {
    "fast": {
        "max_files_changed": 3,
        "max_new_files": 3,
        "max_lines_changed": 300,
        "max_fix_loops": 2,
    },
    "normal": {
        "max_files_changed": 6,
        "max_new_files": 5,
        "max_lines_changed": 700,
        "max_fix_loops": 3,
    },
    "deep": {
        "max_files_changed": 12,
        "max_new_files": 8,
        "max_lines_changed": 1500,
        "max_fix_loops": 3,
    },
    "review": {
        "max_files_changed": 0,
        "max_new_files": 0,
        "max_lines_changed": 0,
        "max_fix_loops": 0,
    },
    "docs": {
        "max_files_changed": 4,
        "max_new_files": 2,
        "max_lines_changed": 400,
        "max_fix_loops": 2,
    },
}


def check_limits(
    profile_name: str,
    files_changed: int,
    new_files: int,
    lines_changed: int,
) -> LimitCheckResult:
    """Check if changes exceed profile limits.

    Args:
        profile_name: Profile name (fast, normal, deep, review, docs)
        files_changed: Number of files modified
        new_files: Number of new files created
        lines_changed: Total lines added/removed

    Returns:
        LimitCheckResult with exceeded flag and exceeded fields list.
    """
    limits = PROFILE_LIMITS.get(profile_name, PROFILE_LIMITS["normal"])

    max_files = limits["max_files_changed"]
    max_new = limits["max_new_files"]
    max_lines = limits["max_lines_changed"]

    exceeded_fields = []
    if files_changed > max_files:
        exceeded_fields.append("files_changed")
    if new_files > max_new:
        exceeded_fields.append("new_files")
    if lines_changed > max_lines:
        exceeded_fields.append("lines_changed")

    exceeded = len(exceeded_fields) > 0

    return LimitCheckResult(
        profile=profile_name,
        files_changed=files_changed,
        new_files=new_files,
        lines_changed=lines_changed,
        max_files_changed=max_files,
        max_new_files=max_new,
        max_lines_changed=max_lines,
        exceeded=exceeded,
        exceeded_fields=exceeded_fields,
    )


def format_limit_exceeded(result: LimitCheckResult) -> str:
    """Format limit exceeded message with remediation options.

    Args:
        result: LimitCheckResult from check_limits

    Returns:
        Formatted message with remediation steps.
    """
    lines = [
        f"Limit exceeded ({result.profile} mode):",
        "",
    ]

    if "files_changed" in result.exceeded_fields:
        lines.append(f"  files changed: {result.files_changed} / limit {result.max_files_changed}")

    if "new_files" in result.exceeded_fields:
        lines.append(f"  new files: {result.new_files} / limit {result.max_new_files}")

    if "lines_changed" in result.exceeded_fields:
        lines.append(f"  lines changed: {result.lines_changed} / limit {result.max_lines_changed}")

    lines.extend([
        "",
        "Options:",
        "  [y] Continue with approval",
        "  [m] Switch to normal/deep mode",
        "  [r] Rollback changes",
        "  [q] Quit",
    ])

    return "\n".join(lines)
