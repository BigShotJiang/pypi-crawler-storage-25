"""mico spinner — animated status line using \\r (carriage return).

Writes to stdout (not stderr) so that when patch_stdout is active in prompt_toolkit,
output appears above the spinner naturally.

Non-fullscreen, doesn't interfere with normal scrollback.
Respects TTY: skips animation for piped/CI output.
"""
from __future__ import annotations

import atexit
import sys
import threading
import time
from typing import Any, Optional


# Braille spinner frames
_FRAMES = ["⠋", "⠙", "⠹", "⠸", "⠼", "⠴", "⠦", "⠧", "⠇", "⠏"]


def _fmt_elapsed(seconds: float) -> str:
    """Format elapsed seconds as h:mm:ss or m:ss."""
    s = int(seconds)
    h, rem = divmod(s, 3600)
    m, sec = divmod(rem, 60)
    if h:
        return f"{h}:{m:02d}:{sec:02d}"
    return f"{m}:{sec:02d}"


def _fmt_stage(state: Any) -> str:
    """Build compact runtime stage text from RuntimeState telemetry."""
    if state is None:
        return ""
    now = time.monotonic()
    turn_started_at = float(getattr(state, "turn_started_at", 0.0) or 0.0)
    request_sent_at = float(getattr(state, "request_sent_at", 0.0) or 0.0)
    first_token_at = float(getattr(state, "first_token_at", 0.0) or 0.0)
    live_stage = str(getattr(state, "live_stage", "") or "").strip()
    live_detail = str(getattr(state, "live_detail", "") or "").strip()

    if turn_started_at and not request_sent_at:
        wait = int(max(0.0, now - turn_started_at))
        if wait >= 8:
            return f"stuck: no chat request {wait}s"
    if request_sent_at and not first_token_at:
        wait = int(max(0.0, now - request_sent_at))
        if wait >= 8:
            return f"stuck: no first token {wait}s"

    if live_stage and live_detail:
        return f"{live_stage}: {live_detail}"
    if live_stage:
        return live_stage
    return ""


class Spinner:
    """Animated spinner with elapsed timer on a sticky status line.

    The status line stays at the current cursor row using \\r overwrite.
    When output is written (pause/resume), the line is cleared first so
    output lands above; after output the spinner resumes on a fresh line.

    Usage:
        spinner = Spinner()
        spinner.start("thinking...")
        spinner.update("working on task...")
        spinner.stop()
    """

    def __init__(self, stream: Optional[object] = None, state: Any = None) -> None:
        import os as _os
        # Write directly to /dev/tty so patch_stdout doesn't intercept statusbar.
        # Fall back to stdout if /dev/tty is unavailable (CI, pipes).
        _tty_stream = None
        if stream is None:
            try:
                _tty_stream = open("/dev/tty", "w")  # noqa: SIM115
            except OSError:
                pass
        self.stream = stream or _tty_stream or sys.stdout
        self._tty_stream = _tty_stream  # keep ref so we can close on stop
        self.state = state  # RuntimeState — read for tok/s in status line
        _isatty = getattr(self.stream, "isatty", lambda: False)()
        _term = _os.environ.get("TERM", "")
        _has_term = bool(_term and _term != "dumb")
        self._enabled = _isatty or _has_term
        self._thread: Optional[threading.Thread] = None
        self._stop_event = threading.Event()
        self._message = ""
        self._message_lock = threading.Lock()
        self._write_lock = threading.RLock()  # serialises stdout writes; allows nested pause/resume
        self._frame_idx = 0
        self._paused = False
        self._start_time: Optional[float] = None

        atexit.register(self.stop)

    def start(self, message: str = "") -> None:
        """Start spinner with an initial message."""
        if not self._enabled:
            return
        with self._message_lock:
            self._message = message
        self._start_time = time.monotonic()
        if self._thread is None or not self._thread.is_alive():
            self._stop_event.clear()
            self._thread = threading.Thread(target=self._run, daemon=True)
            self._thread.start()

    def update(self, message: str) -> None:
        """Update spinner message while running. Starts if not already running."""
        if not self._enabled:
            return
        with self._message_lock:
            self._message = message
        if self._start_time is None:
            self._start_time = time.monotonic()
        if self._thread is None or not self._thread.is_alive():
            self._stop_event.clear()
            self._thread = threading.Thread(target=self._run, daemon=True)
            self._thread.start()

    def pause(self) -> None:
        """Pause spinner and acquire write lock so caller can safely write output.

        Caller MUST call resume() or write_unlock() when done writing.
        """
        if not self._enabled:
            return
        self._paused = True
        self._write_lock.acquire()
        try:
            self._clear_statusbar()
        except Exception:
            pass

    def resume(self) -> None:
        """Release write lock and resume spinner animation."""
        if not self._enabled:
            return
        self._paused = False
        try:
            self._write_lock.release()
        except RuntimeError:
            pass  # not acquired — safe to ignore

    def stop(self) -> None:
        """Stop spinner and clear the line."""
        if not self._enabled or self._thread is None:
            return
        self._paused = True
        self._stop_event.set()
        if self._thread.is_alive():
            self._thread.join(timeout=0.5)
        self._start_time = None
        # Release lock if pause() was called without resume()
        try:
            self._write_lock.release()
        except RuntimeError:
            pass
        try:
            self._clear_statusbar()
        except Exception:
            pass
        if self._tty_stream is not None:
            try:
                self._tty_stream.close()
            except Exception:
                pass
            self._tty_stream = None

    def _build_line(self, frame: str, msg: str) -> str:
        """Build the full spinner status line."""
        elapsed = ""
        if self._start_time is not None:
            elapsed = "  " + _fmt_elapsed(time.monotonic() - self._start_time)

        # tok/s — prefer live (streaming) rate, fall back to last completed turn
        toks_part = ""
        if self.state is not None:
            toks = getattr(self.state, "live_tokens_per_sec", 0.0) or 0.0
            if toks <= 0:
                toks = getattr(self.state, "last_tokens_per_sec", 0.0) or 0.0
            if toks > 0:
                toks_part = f"  │  {toks:.1f} tok/s"

        stage_part = ""
        stage = _fmt_stage(self.state)
        if stage:
            stage_part = f"  │  {stage}"

        return f"{frame} {msg}{elapsed}{toks_part}{stage_part}"

    def _write_statusbar(self, line: str) -> None:
        """Write line to the bottom of the terminal, then restore cursor position.

        Sequence:
          ESC[s          save cursor
          ESC[{r};1H     move to last row, col 1
          \r ESC[K       clear line
          ESC[2m ... ESC[0m   dim text
          ESC[u          restore cursor
        """
        try:
            import shutil as _shutil
            cols, rows = _shutil.get_terminal_size(fallback=(80, 24))
        except Exception:
            cols, rows = 80, 24
        if len(line) > cols - 1:
            line = line[:cols - 2] + "…"
        seq = f"\033[s\033[{rows};1H\r\033[K\033[2m{line}\033[0m\033[u"
        self.stream.write(seq)
        self.stream.flush()

    def _clear_statusbar(self) -> None:
        """Clear the bottom status line."""
        try:
            import shutil as _shutil
            _, rows = _shutil.get_terminal_size(fallback=(80, 24))
        except Exception:
            rows = 24
        seq = f"\033[s\033[{rows};1H\r\033[K\033[u"
        self.stream.write(seq)
        self.stream.flush()

    def _run(self) -> None:
        """Background thread: animate spinner."""
        frame_idx = 0
        while not self._stop_event.is_set():
            if not self._paused:
                with self._message_lock:
                    msg = self._message
                frame = _FRAMES[frame_idx % len(_FRAMES)]
                line = self._build_line(frame, msg)
                acquired = self._write_lock.acquire(blocking=False)
                if acquired:
                    try:
                        self._write_statusbar(line)
                    except Exception:
                        pass
                    finally:
                        self._write_lock.release()
                frame_idx += 1
            time.sleep(0.1)  # 10 fps
