"""Görev triyajı — LLM çağrısı olmadan, kural tabanlı.

Sadece fiziksel dünya eylemlerini (reject) yakalar.
Normal ve longrun görevler doğrudan tool_loop'a yönlenir.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any


@dataclass
class TriageResult:
    verdict: str                          # "ok" | "reject"
    reason: str = ""
    plan_steps: list[str] = field(default_factory=list)
    max_turns: int = 60
    confidence: str = "high"


# Fiziksel dünya — mico'nun araçlarıyla imkânsız olan şeyler
_PHYSICAL_WORLD_PATTERNS = (
    "arabayı sürdür", "roket fırlat", "ışığı aç", "kapıyı aç", "kapıyı kapat",
    "arabayı çalıştır", "drive the car", "launch the rocket", "turn on the light",
    "open the door", "close the door",
)


async def triage_task(
    task: str,
    *,
    call_model: Any = None,
    history: list[dict] | None = None,
    task_kind: str = "",
) -> TriageResult:
    """Kural tabanlı triyaj — LLM çağrısı yok."""
    lowered = task.strip().lower()
    for pattern in _PHYSICAL_WORLD_PATTERNS:
        if pattern in lowered:
            return TriageResult(
                verdict="reject",
                reason="Bu, dijital bir araçla gerçekleştirilemeyen fiziksel bir eylem.",
            )
    return TriageResult(verdict="ok", reason="")


def format_reject_message(reason: str) -> str:
    return f"Bunu yapamam: {reason}" if reason else "Bu görevi gerçekleştiremem."
