"""Auto-load and manage skill documents from ~/.mico/skills/ directory and discover custom skills."""
from __future__ import annotations

import os
import re
import zipfile
from pathlib import Path
from typing import TYPE_CHECKING, Any

if TYPE_CHECKING:
    from mico.cli import SkillSpec, ToolContext


def skills_dir() -> Path:
    """Return the skills directory path."""
    return Path(os.environ.get("MICO_HOME", str(Path.home() / ".mico"))) / "skills"


def load_skills() -> str:
    """Return concatenated skill texts, or empty string if no skills.

    Each .md file in ~/.mico/skills/ is loaded and formatted as a skill section.
    """
    d = skills_dir()
    if not d.is_dir():
        return ""
    parts = []
    for f in sorted(d.glob("*.md")):
        try:
            content = f.read_text(encoding="utf-8").strip()
            if content:
                parts.append(f"## {f.stem}\n{content}")
        except OSError:
            continue
    return "\n\n".join(parts)


def load_env_file(path: Path) -> dict[str, str]:
    """Parse a .env or config file into a dictionary."""
    env: dict[str, str] = {}
    if not path.exists():
        return env
    for raw in path.read_text().splitlines():
        line = raw.strip()
        if not line or line.startswith("#") or "=" not in line:
            continue
        key, value = line.split("=", 1)
        value = value.strip().strip('"').strip("'")
        env[key.strip()] = value
    return env


def parse_skill_frontmatter(text: str) -> tuple[dict[str, Any], str]:
    """Parse YAML-style frontmatter from skill markdown.

    Expects format:
    ---
    name: skill name
    description: brief description
    aliases: [alias1, alias2]
    ---
    Body content here...

    Returns (metadata_dict, body_text).
    """
    stripped = text.strip()
    if not stripped.startswith("---"):
        return ({}, text.strip())
    lines = text.splitlines()
    if not lines or lines[0].strip() != "---":
        return ({}, text.strip())
    meta: dict[str, Any] = {}
    body_start = 0
    current_list_key: str | None = None
    for idx in range(1, len(lines)):
        line = lines[idx]
        if line.strip() == "---":
            body_start = idx + 1
            break
        stripped_line = line.strip()
        if current_list_key and stripped_line.startswith("- "):
            meta.setdefault(current_list_key, []).append(stripped_line[2:].strip().strip('"').strip("'"))
            continue
        if stripped_line and not line.startswith((" ", "\t")):
            current_list_key = None
        if ":" not in line:
            continue
        key, value = line.split(":", 1)
        normalized_key = key.strip().lower()
        cleaned_value = value.strip()
        if not cleaned_value:
            meta[normalized_key] = []
            current_list_key = normalized_key
            continue
        if cleaned_value.startswith("[") and cleaned_value.endswith("]"):
            items = [
                item.strip().strip('"').strip("'")
                for item in cleaned_value[1:-1].split(",")
                if item.strip()
            ]
            meta[normalized_key] = items
            continue
        meta[normalized_key] = cleaned_value.strip('"').strip("'")
    body = "\n".join(lines[body_start:]).strip() if body_start else text.strip()
    return (meta, body)


def load_skill_from_file(path: Path) -> SkillSpec | None:
    """Load a skill from file, directory, or .skill archive.

    Supports:
    - Single markdown file (e.g., skill.md)
    - Directory with SKILL.md inside
    - .skill zipfile with SKILL.md inside archive
    """
    try:
        if path.suffix == ".skill":
            with zipfile.ZipFile(path) as archive:
                with archive.open("SKILL.md") as handle:
                    raw = handle.read().decode("utf-8", errors="replace")
        elif path.is_dir():
            raw = (path / "SKILL.md").read_text()
        else:
            raw = path.read_text()
    except Exception:
        return None
    meta, body = parse_skill_frontmatter(raw)
    name = meta.get("name") or path.stem
    description = meta.get("description") or ""
    aliases_raw = meta.get("aliases", [])
    if isinstance(aliases_raw, str):
        aliases = (aliases_raw,)
    elif isinstance(aliases_raw, list):
        aliases = tuple(str(item).strip() for item in aliases_raw if str(item).strip())
    else:
        aliases = ()

    # Import SkillSpec at runtime to avoid circular imports
    from mico.cli import SkillSpec
    return SkillSpec(name=name, description=description, source=path, content=body, aliases=aliases)


def skill_search_paths(ctx: ToolContext) -> list[Path]:
    """Return ordered list of paths to search for skills."""
    from mico.cli import ROOT

    cwd = Path(ctx.cwd)
    paths: list[Path] = [
        ROOT / "skills",
        cwd / "skills",
        cwd,
        Path.home() / ".agent" / "skills",
        Path.home() / ".agent" / "skills" / "skills",
        Path.home() / ".codex" / "skills",
        Path.home(),
    ]
    extra = os.environ.get("MICO_SKILL_PATHS", "").strip()
    if extra:
        for item in extra.split(os.pathsep):
            item = item.strip()
            if item:
                paths.append(Path(item))
    return paths


def discover_skills(ctx: ToolContext) -> list[SkillSpec]:
    """Discover all available skills from search paths."""
    skills: list[SkillSpec] = []
    seen: set[Path] = set()
    for base in skill_search_paths(ctx):
        if not base.exists():
            continue
        candidates: list[Path] = []
        if base.is_dir():
            try:
                for child in base.iterdir():
                    if child.suffix == ".skill":
                        candidates.append(child)
                    elif child.is_dir() and (child / "SKILL.md").exists():
                        candidates.append(child)
                    elif child.suffix == ".py" and child.name != "__init__.py":
                        # Potential active skill
                        load_active_skill(child)
            except OSError:
                continue
        elif base.suffix == ".skill":
            candidates.append(base)
        for candidate in candidates:
            resolved = candidate.resolve()
            if resolved in seen:
                continue
            seen.add(resolved)
            skill = load_skill_from_file(candidate)
            if skill:
                skills.append(skill)
    return skills


def load_active_skill(path: Path):
    """Dynamically load an active skill from a Python file."""
    try:
        import importlib.util
        spec = importlib.util.spec_from_file_location(path.stem, path)
        if spec and spec.loader:
            module = importlib.util.module_from_spec(spec)
            spec.loader.exec_module(module)
            # Active skills should register themselves with mico.skill_api.get_skill_registry()
    except Exception:
        pass


def skill_keywords(text: str) -> set[str]:
    """Extract relevant keywords from text, filtering stopwords."""
    stopwords = {
        "the",
        "and",
        "for",
        "with",
        "from",
        "that",
        "this",
        "then",
        "into",
        "your",
        "when",
        "what",
        "where",
        "have",
        "list",
        "show",
        "make",
        "using",
        "used",
        "user",
        "task",
        "help",
        "need",
        "want",
        "code",
        "repo",
        "file",
        "skill",
        "skills",
        "agent",
        "tools",
    }
    return {
        token
        for token in re.findall(r"[a-zA-Z0-9_./:-]+", text.lower())
        if len(token) >= 3 and token not in stopwords and not token.isdigit()
    }


def skill_aliases(skill: SkillSpec) -> set[str]:
    """Generate searchable aliases for a skill."""
    aliases = {
        skill.name.lower().strip(),
        re.sub(r"[-_/]+", " ", skill.name.lower()).strip(),
        re.sub(r"[^a-z0-9]+", "", skill.name.lower()).strip(),
    }
    aliases.update(alias.lower().strip() for alias in skill.aliases if alias.strip())
    tokens = [token for token in re.split(r"[^a-zA-Z0-9]+", skill.name.lower()) if len(token) >= 4]
    aliases.update(tokens)
    aliases.discard("")
    return aliases


def task_mentions_skill(task: str, skill: SkillSpec) -> bool:
    """Strict explicit-mention check. Only the slug name or @/$ prefix counts.

    Common 2-word aliases (e.g. "code review") used to auto-inject the entire
    skill body, blowing up the prompt for unrelated tasks. Now only an explicit
    `@skill-name`, `$skill-name`, or the slug appearing as a token triggers
    full-content activation. Fuzzy keyword matches still produce hint lines.
    """
    task_lower = task.lower()
    slug = skill.name.strip().lower()
    if not slug:
        return False
    if f"@{slug}" in task_lower or f"${slug}" in task_lower:
        return True
    # require the full slug as a whole token (hyphens preserved)
    if re.search(rf"(?<![A-Za-z0-9_-]){re.escape(slug)}(?![A-Za-z0-9_-])", task_lower):
        return True
    return False


def select_skills_for_task(task: str, ctx: ToolContext) -> list[SkillSpec]:
    """Select and rank skills relevant to a task.

    Explicit mentions (@skill-name, $skill-name, or exact slug match) take priority.
    Fuzzy keyword matches are included up to 3 skills with score >= 16.
    """
    task_terms = skill_keywords(task)
    if not task_terms:
        return []
    ranked: list[tuple[int, int, SkillSpec]] = []
    import mico.cli as _cli_mod
    _discover = getattr(_cli_mod, "discover_skills", discover_skills)
    for skill in _discover(ctx):
        explicit = task_mentions_skill(task, skill)
        name_terms = skill_keywords(skill.name)
        description_terms = skill_keywords(skill.description)
        content_terms = skill_keywords(skill.content[:2000])
        name_overlap = len(task_terms & name_terms)
        description_overlap = len(task_terms & description_terms)
        content_overlap = len(task_terms & content_terms)
        score = (name_overlap * 8) + (description_overlap * 4) + content_overlap
        if explicit:
            score += 100
        if any(term in name_terms | description_terms for term in {"security", "deploy", "figma", "threat", "model"}):
            score += 2
        if score <= 0:
            continue
        ranked.append((0 if explicit else 1, -score, skill))
    ranked.sort(key=lambda item: (item[0], item[1], item[2].name.lower()))
    if not ranked:
        return []
    selected: list[SkillSpec] = []
    fuzzy_added = 0
    for explicit_rank, neg_score, skill in ranked:
        score = -neg_score
        if explicit_rank == 0:
            # Explicit slug mention → include with full content, up to 1
            selected.append(skill)
            if len(selected) >= 1:
                break
        else:
            # Fuzzy match → at most 3 hint lines (no full content), modest score floor.
            # Hints are cheap (~30 tok each); the real budget win is that fuzzy never
            # injects body content anymore.
            if fuzzy_added < 3 and score >= 16:
                selected.append(skill)
                fuzzy_added += 1
    return selected


def render_skill_notes(task: str, ctx: ToolContext) -> str:
    """Render skill notes for a task.

    Activated skills are logged, explicit mentions include full content,
    and fuzzy matches show hint lines only.
    """
    from mico.cli import (
        task_prefers_minimal_context,
        task_needs_memory_guard,
        render_log_line,
        COLOR_NARRATE,
    )

    if task_prefers_minimal_context(task):
        return ""
    selected = select_skills_for_task(task, ctx)
    if not selected:
        return ""

    explicit_skills = [s for s in selected if task_mentions_skill(task, s)]
    fuzzy_skills = [s for s in selected if not task_mentions_skill(task, s)]

    names = ", ".join(s.name for s in selected)
    render_log_line("memory", f"activated skills: {names}", COLOR_NARRATE)

    parts = []

    # Explicit slug mention: inject full content (capped to keep prompt small).
    for skill in explicit_skills:
        body = skill.content.strip()
        # 9B-class models drown in long skill bodies; cap at ~1.5k chars (~400 tok).
        if len(body) > 1500:
            body = body[:1500].rstrip() + "\n…(truncated; use skill_tool for more)"
        if task_needs_memory_guard(task, ctx):
            parts.append(f"Skill {skill.name}: {skill.description}")
        else:
            parts.append(
                f"Activated skill: {skill.name}\n"
                f"Description: {skill.description}\n\n"
                f"{body}"
            )

    # Fuzzy: name + one-line description hint only. Model can call skill_tool
    # to pull full content on demand. No usage-example block — that costs ~150
    # tokens for nothing on a 9B model.
    if fuzzy_skills:
        hints = ["Available skills (call skill_tool to load):"]
        for skill in fuzzy_skills:
            desc = (skill.description or "").splitlines()[0][:120]
            hints.append(f"- {skill.name}: {desc}")
        parts.append("\n".join(hints))

    return "\n\n".join(parts)
