"""Session and artifact management operations."""

from __future__ import annotations

import json
import os
import re
import time
from pathlib import Path
from typing import TYPE_CHECKING, Any

if TYPE_CHECKING:
    from mico.cli import TaskState

def _mico_base() -> Path:
    return Path(os.environ.get("MICO_HOME", str(Path.home() / ".mico")))


def _sessions_dir() -> Path:
    return _mico_base() / "sessions"


def _patches_dir() -> Path:
    return _mico_base() / "patches"


def _task_states_dir() -> Path:
    return _mico_base() / "task_states"


def _artifacts_dir() -> Path:
    return _mico_base() / "artifacts"


# Keep module-level aliases for callers that access these as attributes.
# They resolve at import time; use the _*_dir() helpers inside this module.
SESSIONS_DIR = _sessions_dir()
PATCHES_DIR = _patches_dir()
TASK_STATES_DIR = _task_states_dir()
ARTIFACTS_DIR = _artifacts_dir()


def session_artifacts_dir(session_id: str) -> Path:
    """Get or create the artifacts directory for a session."""
    path = _artifacts_dir() / session_id
    path.mkdir(parents=True, exist_ok=True)
    return path


def task_state_path(session_id: str) -> Path:
    """Get path to task state JSON file."""
    d = _task_states_dir()
    d.mkdir(parents=True, exist_ok=True)
    return d / f"{session_id}.json"


def dedupe_keep_order(items: list[str]) -> list[str]:
    """Remove duplicates while preserving order."""
    seen: set[str] = set()
    out: list[str] = []
    for item in items:
        cleaned = item.strip()
        if not cleaned or cleaned in seen:
            continue
        seen.add(cleaned)
        out.append(cleaned)
    return out


def artifact_snippet(text: str, limit: int = 1200) -> str:
    """Create a snippet from artifact text."""
    from mico.cli import distill_text_output, truncate
    return truncate(distill_text_output(text, limit=limit), limit)


def record_artifact(
    session_id: str,
    label: str,
    content: str,
    metadata: dict[str, Any] | None = None,
) -> dict[str, Any]:
    """Record an artifact for a session."""
    from mico.redact import redact_text

    artifact_dir = session_artifacts_dir(session_id)
    existing = sorted(artifact_dir.glob("*.txt"))
    artifact_id = f"{len(existing) + 1:04d}"
    safe_label = re.sub(r"[^a-zA-Z0-9_.-]+", "-", label.strip().lower()).strip("-") or "artifact"
    path = artifact_dir / f"{artifact_id}-{safe_label}.txt"
    path.write_text(redact_text(content))

    result = {
        "id": artifact_id,
        "label": label,
        "path": str(path),
        "snippet": artifact_snippet(content),
        "created_at": int(time.time()),
    }
    if metadata:
        result["metadata"] = metadata
    return result


def select_relevant_artifacts(
    state: TaskState,
    task: str,
    history: list[dict[str, str]],
    limit: int = 20,  # MAX_RETRIEVED_ARTIFACTS
) -> list[dict[str, Any]]:
    """Select relevant artifacts for retrieval."""
    from mico.retrieval import select_relevant_artifacts as _select_relevant_artifacts
    from mico.cli import extract_task_body

    return _select_relevant_artifacts(
        state.artifacts,
        task,
        history,
        limit=limit,
        extract_task_body=extract_task_body,
    )


def build_retrieval_prompt(
    task: str,
    history: list[dict[str, str]],
    state: TaskState,
) -> str:
    """Build a retrieval prompt for context."""
    from mico.retrieval import build_retrieval_prompt as _build_retrieval_prompt
    from mico.cli import extract_task_body, truncate

    return _build_retrieval_prompt(
        state.artifacts,
        task,
        history,
        limit=20,  # MAX_RETRIEVED_ARTIFACTS
        extract_task_body=extract_task_body,
        truncator=truncate,
    )


def task_state_report(session_id: str) -> str:
    """Get a report of the task state."""
    from mico.state_reports import task_state_report as _task_state_report
    from mico.cli import truncate

    return _task_state_report(
        session_id,
        task_state_file=task_state_path(session_id),
        truncator=truncate,
    )


def artifact_report(session_id: str, limit: int = 10) -> str:
    """Get a report of artifacts for a session."""
    from mico.state_reports import artifact_report as _artifact_report

    return _artifact_report(
        session_id,
        artifacts_dir=session_artifacts_dir(session_id),
        artifact_snippet=artifact_snippet,
        limit=limit,
    )


def save_session(session_id: str, history: list[dict[str, str]]) -> None:
    """Save session history to disk."""
    from mico.session_store import save_session as _save_session
    from mico.cli import update_compact_meter
    from mico.model_ops import CURRENT_TURN_TRACE
    from mico.redact import redact_json_safe

    _save_session(
        session_id,
        history,
        sessions_dir=_sessions_dir(),
        update_compact_meter=update_compact_meter,
        current_turn_trace=CURRENT_TURN_TRACE,
        task_state_path=task_state_path,
        artifacts_dir_for_session=session_artifacts_dir,
        redact_json_safe=redact_json_safe,
    )


def save_patch(session_id: str, diff: str) -> Path:
    """Save a patch (diff) to disk."""
    from mico.session_store import save_patch as _save_patch
    from mico.redact import redact_text

    return _save_patch(session_id, diff, patches_dir=_patches_dir(), redact_text=redact_text)


def load_session_history(path: Path) -> list[dict[str, str]]:
    """Load session history from disk."""
    from mico.session_store import load_session_history as _load_session_history

    return _load_session_history(path)


def list_recent_sessions() -> list[Path]:
    """List recent sessions, sorted by modification time (newest first)."""
    d = _sessions_dir()
    if not d.exists():
        return []
    return sorted(d.glob("*.json"), key=lambda p: p.stat().st_mtime, reverse=True)


def latest_session() -> Path | None:
    """Get the most recent session."""
    sessions = list_recent_sessions()
    return sessions[0] if sessions else None


def latest_patch() -> Path | None:
    """Get the most recent patch."""
    d = _patches_dir()
    if not d.exists():
        return None
    patches = sorted(d.glob("*.patch"), key=lambda p: p.stat().st_mtime, reverse=True)
    return patches[0] if patches else None


def session_preview(path: Path) -> tuple[str, str, str]:
    """Get (updated_time, message_count, preview) for a session."""
    from mico.cli import truncate

    history = load_session_history(path)
    last_user = ""
    for item in reversed(history):
        if item.get("role") == "user":
            last_user = str(item.get("content", "")).strip()
            if last_user:
                break

    updated = time.strftime("%Y-%m-%d %H:%M:%S", time.localtime(path.stat().st_mtime))
    preview = truncate(last_user or "(no user message)", 90).replace("\n", " ")
    state_path = task_state_path(path.stem)
    if state_path.exists():
        try:
            state = json.loads(state_path.read_text())
            suffix = " ".join(
                part
                for part in [str(state.get("status", "")).strip(), str(state.get("current_phase", "")).strip()]
                if part
            )
            pending = state.get("pending_tool", {}) or {}
            if pending:
                suffix = (suffix + " pending-tool").strip()
            if suffix:
                preview = truncate(f"{preview} [{suffix}]", 90)
        except Exception:
            pass
    return (updated, str(len(history)), preview)
