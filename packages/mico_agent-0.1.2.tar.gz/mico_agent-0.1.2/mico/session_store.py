from __future__ import annotations

import json
import time
from pathlib import Path
from typing import Any, Callable


def save_session(
    session_id: str,
    history: list[dict[str, str]],
    *,
    sessions_dir: Path,
    update_compact_meter: Callable[[list[dict[str, str]]], None],
    current_turn_trace: dict[str, Any],
    task_state_path: Callable[[str], Path],
    artifacts_dir_for_session: Callable[[str], Path],
    redact_json_safe: Callable[[dict[str, Any]], dict[str, Any]],
) -> None:
    sessions_dir.mkdir(parents=True, exist_ok=True)
    path = sessions_dir / f"{session_id}.json"
    update_compact_meter(history)
    payload = {
        "session_id": session_id,
        "history": history,
        "updated_at": int(time.time()),
        "trace": current_turn_trace,
        "task_state_path": str(task_state_path(session_id)),
        "artifacts_dir": str(artifacts_dir_for_session(session_id)),
    }
    path.write_text(json.dumps(redact_json_safe(payload), ensure_ascii=False, indent=2))


def save_patch(
    session_id: str,
    diff: str,
    *,
    patches_dir: Path,
    redact_text: Callable[[str], str],
) -> Path:
    patches_dir.mkdir(parents=True, exist_ok=True)
    path = patches_dir / f"{session_id}.patch"
    path.write_text(redact_text(diff))
    return path


def load_session_history(path: Path) -> list[dict[str, str]]:
    data = json.loads(path.read_text())
    if isinstance(data, list):
        return data
    if isinstance(data, dict) and isinstance(data.get("history"), list):
        return data["history"]
    raise ValueError(f"Unsupported session format: {path}")
