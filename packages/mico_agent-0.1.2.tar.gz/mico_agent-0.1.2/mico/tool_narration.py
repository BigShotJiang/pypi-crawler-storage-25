from __future__ import annotations

import re
from typing import Any, Callable


def summarize_action(action: dict[str, Any]) -> str:
    if action.get("type") != "tool":
        return str(action.get("type", "unknown"))
    label = action.get("tool", "tool")
    detail = action.get("command") or action.get("path") or ""
    return f"{label}:{detail}"


def tool_family(action: dict[str, Any]) -> str:
    if action.get("type") != "tool":
        return str(action.get("type", "unknown"))
    tool = str(action.get("tool", "tool"))
    if tool != "bash":
        return tool
    command = str(action.get("command", "")).strip().lower()
    if command.startswith("sed -n"):
        return "bash_sed_read"
    if command.startswith("grep -n"):
        return "bash_grep_read"
    return "bash_other"


def narrate_tool_intent(action: dict[str, Any], *, mode: str, truncator: Callable[[str, int], str]) -> str:
    tool = action.get("tool", "tool")
    if tool == "list_files":
        target = str(action.get("path", "."))
        return f"Klasör taranıyor: {target}"
    if tool == "read_file":
        target = str(action.get("path", ""))
        return f"Dosya okunuyor: {target}"
    if tool == "write_file":
        target = str(action.get("path", ""))
        return f"Dosya yazılıyor: {target}"
    if tool == "replace_in_file":
        target = str(action.get("path", ""))
        return f"Dosya düzenleniyor: {target}"
    if tool == "bash":
        command = str(action.get("command", "")).strip()
        first_line = command.splitlines()[0] if command else command
        return f"Komut çalıştırılıyor: {truncator(first_line, 120)}"
    if tool == "coding_tool":
        name = str(action.get("name", ""))
        return f"Kod aracı: {name}"
    if tool == "macos_admin_task":
        name = str(action.get("name", ""))
        return f"macOS görevi: {name}"
    if tool == "skill_tool":
        skill = str(action.get("skill", "")).strip()
        op = str(action.get("action", "")).strip()
        name = str(action.get("name", "")).strip()
        query = str(action.get("query", "")).strip()
        path = str(action.get("path", "")).strip()
        detail = " ".join(part for part in [skill, op, name or query or path] if part).strip()
        return f"Skill: {detail or 'skill_tool'}"
    if tool == "http_request":
        method = str(action.get("method", "GET")).strip().upper()
        url = str(action.get("url", "")).strip()
        return f"HTTP isteği: {method} {url}".strip()
    if tool == "grep_code":
        pattern = str(action.get("pattern", "")).strip()
        path = str(action.get("path", "")).strip()
        suffix = f" ({path})" if path else ""
        return f"Aranıyor: {pattern}{suffix}"
    if tool == "parse_json_file":
        target = str(action.get("path", ""))
        return f"JSON okunuyor: {target}"
    if tool == "find_in_files":
        pattern = str(action.get("pattern", "")).strip()
        return f"Dosyalarda aranıyor: {pattern}"
    return f"Araç: {tool}"


def narrate_tool_result(label: str, result: str, is_error: bool, *, truncator: Callable[[str, int], str]) -> str:
    if is_error:
        snippet = truncator(result.strip().replace("\n", " "), 140)
        return f"{label} hatası: {snippet}"
    if "(no output)" in result:
        return f"{label} tamamlandı (çıktı yok)"
    if label == "bash":
        match = re.search(r"exit_code=(\d+)", result)
        if match:
            code = match.group(1)
            return f"Tamamlandı (exit {code})" if code != "0" else "Tamamlandı"
    line_count = result.count("\n") + 1 if result.strip() else 0
    return f"{label} tamamlandı ({line_count} satır)"


def tool_output_preview(
    label: str,
    result: str,
    *,
    is_error: bool = False,
    truncator: Callable[[str, int], str],
) -> str:
    text = (result or "").strip()
    if not text or text == "(no output)":
        return ""
    if text.startswith("exit_code="):
        lines = text.splitlines()[:18]
        return truncator("\n".join(lines), 2500)
    if label in {"http_request", "macos_admin_task", "skill_tool", "coding_tool"}:
        lines = text.splitlines()[:18]
        return truncator("\n".join(lines), 2500)
    if is_error:
        return truncator(text, 2500)
    return ""
