"""Role-based model profile system and ModelSlot mutex for mico.

Goal on M4-24GB: prevent two large models being held in RAM simultaneously.
The previously-loaded model is "released" before a new one is acquired; the
RLock around acquire ensures concurrent calls serialize.

YAML/TOML profile loading is intentionally a stub for now -- only built-in
profiles are returned. The `load_profile` signature is preserved so an
on-disk loader can be added later without touching call sites.
"""
from __future__ import annotations

import copy
import os
import time
from dataclasses import dataclass, field
from pathlib import Path
import asyncio
from contextlib import asynccontextmanager
from typing import AsyncIterator, Iterable, Literal, Optional

try:
    import tomllib
except ModuleNotFoundError:  # pragma: no cover
    tomllib = None

ModelRole = Literal["worker", "architect", "reviewer", "docs"]
VALID_ROLES: tuple[str, ...] = ("worker", "architect", "reviewer", "docs")


@dataclass
class RoleConfig:
    model: str  # logical name fragment, e.g. "qwen3.5", resolved via discover
    base_url: str = "http://127.0.0.1:8080/v1"
    context: int = 8192
    temperature: float = 0.15
    max_tokens: int = 2048
    timeout: int = 1800
    retries: int = 2

    # Resolved absolute model path (set by resolver). None until resolved.
    resolved_path: Optional[str] = None


@dataclass
class ProfileConfig:
    name: str
    default_role: ModelRole = "worker"
    roles: dict[str, RoleConfig] = field(default_factory=dict)


# ---------------------------------------------------------------------------
# Built-in profiles. Logical model fragments only; resolved later via
# `discover_mlx_model_dirs` substring matching.
# ---------------------------------------------------------------------------

def _r(model: str, **kwargs) -> RoleConfig:
    return RoleConfig(model=model, **kwargs)


BUILTIN_PROFILES: dict[str, ProfileConfig] = {
    "fast": ProfileConfig(
        name="fast",
        default_role="worker",
        roles={
            "worker": _r("qwen3.5", context=8192, temperature=0.15, max_tokens=2048),
        },
    ),
    "normal": ProfileConfig(
        name="normal",
        default_role="worker",
        roles={
            "worker": _r("qwen3.5", context=8192, temperature=0.15, max_tokens=2048),
            "reviewer": _r("qwopus", context=8192, temperature=0.1, max_tokens=2048),
        },
    ),
    "deep": ProfileConfig(
        name="deep",
        default_role="worker",
        roles={
            "architect": _r("qwen3.6", context=8192, temperature=0.2, max_tokens=3072),
            "worker": _r("qwen3.5", context=8192, temperature=0.15, max_tokens=2048),
            "reviewer": _r("qwopus", context=8192, temperature=0.1, max_tokens=2048),
        },
    ),
    "review": ProfileConfig(
        name="review",
        default_role="reviewer",
        roles={
            # primary reviewer; qwen3.6 is allowed as fallback when resolving.
            "reviewer": _r("qwopus", context=8192, temperature=0.1, max_tokens=2048),
        },
    ),
    "docs": ProfileConfig(
        name="docs",
        default_role="docs",
        roles={
            "docs": _r("gemma", context=8192, temperature=0.3, max_tokens=3072),
        },
    ),
}


# Per-role fallbacks when the primary substring does not match any local model.
ROLE_FALLBACKS: dict[str, tuple[str, ...]] = {
    "review": ("qwen3.6",),
}


def _candidate_profile_paths() -> list[Path]:
    explicit = os.environ.get("MICO_PROFILE_PATH", "").strip()
    paths: list[Path] = []
    if explicit:
        paths.append(Path(explicit).expanduser())
    paths.append(Path.cwd() / "mico.profiles.toml")
    paths.append(Path.home() / ".mico" / "profiles.toml")
    deduped: list[Path] = []
    seen: set[str] = set()
    for path in paths:
        key = str(path)
        if key in seen:
            continue
        seen.add(key)
        deduped.append(path)
    return deduped


def _deepcopy_profile(profile: ProfileConfig) -> ProfileConfig:
    return copy.deepcopy(profile)


def _profile_from_mapping(name: str, data: dict) -> ProfileConfig:
    roles: dict[str, RoleConfig] = {}
    default_role = str(data.get("default_role", "worker")).strip() or "worker"
    raw_roles = data.get("roles", {})
    if not isinstance(raw_roles, dict):
        raise ValueError(f"profile {name!r} roles must be a table/object")
    for role_name, raw_cfg in raw_roles.items():
        if not isinstance(raw_cfg, dict):
            raise ValueError(f"profile {name!r} role {role_name!r} must be a table/object")
        roles[str(role_name)] = RoleConfig(
            model=str(raw_cfg.get("model", "")).strip(),
            base_url=str(raw_cfg.get("base_url", "http://127.0.0.1:8080/v1")).strip() or "http://127.0.0.1:8080/v1",
            context=int(raw_cfg.get("context", 8192) or 8192),
            temperature=float(raw_cfg.get("temperature", 0.15) or 0.15),
            max_tokens=int(raw_cfg.get("max_tokens", 2048) or 2048),
            timeout=int(raw_cfg.get("timeout", 1800) or 1800),
            retries=int(raw_cfg.get("retries", 2) or 2),
            resolved_path=str(raw_cfg.get("resolved_path", "")).strip() or None,
        )
    return ProfileConfig(name=name, default_role=default_role, roles=roles)


def _merge_profile(base: ProfileConfig, override: ProfileConfig) -> ProfileConfig:
    merged = _deepcopy_profile(base)
    if override.default_role:
        merged.default_role = override.default_role
    for role_name, cfg in override.roles.items():
        merged.roles[role_name] = copy.deepcopy(cfg)
    return merged


def _load_profiles_from_disk() -> dict[str, ProfileConfig]:
    if tomllib is None:
        return {}
    for path in _candidate_profile_paths():
        if not path.exists():
            continue
        data = tomllib.loads(path.read_text(encoding="utf-8"))
        raw_profiles = data.get("profiles", {})
        if not isinstance(raw_profiles, dict):
            raise ValueError(f"invalid profiles file: {path}")
        parsed: dict[str, ProfileConfig] = {}
        for name, raw in raw_profiles.items():
            if not isinstance(raw, dict):
                raise ValueError(f"profile {name!r} must be a table/object")
            if "roles" in raw:
                parsed[str(name)] = _profile_from_mapping(str(name), raw)
                continue
            default_role = str(raw.get("default_role", "worker")).strip() or "worker"
            role_entries = {k: v for k, v in raw.items() if isinstance(v, dict)}
            parsed[str(name)] = _profile_from_mapping(
                str(name),
                {"default_role": default_role, "roles": role_entries},
            )
        return parsed
    return {}


def load_profile(name: str) -> ProfileConfig:
    """Return a built-in or disk-overridden profile by name.

    Resolution order:
    1. `MICO_PROFILE_PATH` if set
    2. `./mico.profiles.toml`
    3. `~/.mico/profiles.toml`
    """
    key = (name or "").strip().lower()
    disk_profiles = _load_profiles_from_disk()
    if key in disk_profiles and key not in BUILTIN_PROFILES:
        return disk_profiles[key]
    if key in BUILTIN_PROFILES:
        base = _deepcopy_profile(BUILTIN_PROFILES[key])
        override = disk_profiles.get(key)
        if override is not None:
            return _merge_profile(base, override)
        return base
    if key in disk_profiles:
        return disk_profiles[key]
    raise ValueError(f"unknown model profile: {name!r}")


def list_profiles() -> list[str]:
    names = set(BUILTIN_PROFILES.keys())
    try:
        names.update(_load_profiles_from_disk().keys())
    except Exception:
        pass
    return sorted(names)


def resolve_role_model(role: ModelRole, profile: ProfileConfig) -> Optional[RoleConfig]:
    """Return the RoleConfig for `role` in `profile`, or None if absent."""
    if profile is None:
        return None
    return profile.roles.get(role)


def resolve_logical_model(
    fragment: str,
    discovered: Iterable[Path] | None = None,
    fallbacks: tuple[str, ...] = (),
) -> Optional[str]:
    """Match a logical model fragment (e.g. "qwen3.5") against discovered MLX dirs.

    Returns the absolute path string of the first directory whose name contains
    the fragment (case-insensitive). Falls back through `fallbacks` fragments.
    """
    candidates = list(discovered or [])
    for needle in (fragment, *fallbacks):
        if not needle:
            continue
        needle_lower = needle.lower()
        for entry in candidates:
            if needle_lower in entry.name.lower():
                return str(entry)
    return None


# ---------------------------------------------------------------------------
# ModelSlot mutex: only one model "loaded" at a time.
# ---------------------------------------------------------------------------

class _ModelSlot:
    """Process-wide mutex around the currently-loaded MLX model."""

    def __init__(self) -> None:
        self._lock = asyncio.Lock()
        self.current_model: Optional[str] = None
        self.current_role: Optional[str] = None
        self.loaded_at: float = 0.0
        self._unload_hook = None
        self._load_hook = None

    def set_unload_hook(self, fn) -> None:
        self._unload_hook = fn

    def set_load_hook(self, fn) -> None:
        self._load_hook = fn

    @asynccontextmanager
    async def acquire(self, role: ModelRole, role_config: RoleConfig) -> AsyncIterator["_ModelSlot"]:
        target = role_config.resolved_path or role_config.model
        async with self._lock:
            if self.current_model and self.current_model != target:
                if self._unload_hook is not None:
                    try:
                        await self._unload_hook(self.current_model)
                    except Exception:
                        pass
                self.current_model = None
                self.current_role = None
            if self.current_model != target:
                if self._load_hook is not None:
                    try:
                        await self._load_hook(target, role_config)
                    except Exception:
                        pass
                self.current_model = target
                self.current_role = role
                self.loaded_at = time.time()
            else:
                self.current_role = role
            yield self

    async def status(self) -> dict:
        async with self._lock:
            return {
                "model": self.current_model,
                "role": self.current_role,
                "loaded_at": self.loaded_at,
            }


ModelSlot = _ModelSlot()


__all__ = [
    "ModelRole",
    "VALID_ROLES",
    "RoleConfig",
    "ProfileConfig",
    "BUILTIN_PROFILES",
    "ROLE_FALLBACKS",
    "load_profile",
    "list_profiles",
    "resolve_role_model",
    "resolve_logical_model",
    "ModelSlot",
]
