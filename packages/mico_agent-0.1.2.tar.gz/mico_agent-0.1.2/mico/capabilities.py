from __future__ import annotations

from dataclasses import dataclass
from enum import Enum, auto


class ModelFormat(Enum):
    JSON = auto()          # Standard JSON object
    MARKDOWN_JSON = auto() # JSON inside markdown blocks
    XML = auto()           # XML tags (e.g. <tool>...</tool>)
    NATIVE_TOOL = auto()   # Native LLM tool calling API


@dataclass
class ModelCapabilities:
    format: ModelFormat
    supports_thinking: bool = False
    supports_vision: bool = False
    context_limit: int = 32000


def get_model_capabilities(model_name: str, provider: str) -> ModelCapabilities:
    """Determine model capabilities based on name and provider."""
    name = model_name.lower()
    
    # Default capabilities
    caps = ModelCapabilities(format=ModelFormat.MARKDOWN_JSON)
    
    if provider == "openai":
        caps.format = ModelFormat.NATIVE_TOOL
        if "gpt-4" in name:
            caps.context_limit = 128000
    elif provider == "mlx":
        # MLX usually follows the base model. 
        # For simplicity, assume Markdown JSON for most local models unless specified.
        if "command-r" in name:
            caps.format = ModelFormat.XML
    elif provider == "ollama":
        caps.format = ModelFormat.JSON
        
    return caps
