from __future__ import annotations

import json
from typing import Callable, Any


async def maybe_compact_history(
    history: list[dict[str, str]],
    session_id: str,
    *,
    count_primary_user_turns: Callable[[list[dict[str, str]]], int],
    update_compact_meter: Callable[[list[dict[str, str]]], int],
    compact_trigger_chars: Callable[[], int],
    history_total_chars: Callable[[list[dict[str, str]]], int],
    compact_trigger_messages: int,
    compact_keep_tail: int,
    ui_status_text: str,
    set_status: Callable[[str], None],
    render_log_line: Callable[[str, str, str], None],
    color_plan: str,
    summarize_history: Any,
    fallback_history_summary: Callable[[list[dict[str, str]]], str],
    brief_model_error: Callable[[Exception], str],
    save_session: Callable[[str, list[dict[str, str]]], None],
    force: bool = False,
) -> list[dict[str, str]]:
    if count_primary_user_turns(history) < 1:
        return history
    remaining_before = update_compact_meter(history)
    if not force:
        trigger = compact_trigger_chars()
        if len(history) < compact_trigger_messages and history_total_chars(history) < trigger:
            return history

    compact_index = None
    for idx, item in enumerate(history):
        if item.get("role") == "system" and str(item.get("content", "")).startswith("[COMPACTED SUMMARY]"):
            compact_index = idx
            break

    # Cap tail to at most 40% of history so compaction always makes a meaningful dent.
    effective_keep = min(compact_keep_tail, max(4, len(history) * 2 // 5))
    tail = history[-effective_keep:]
    prefix = history[:-effective_keep]
    if compact_index is not None and compact_index < len(prefix):
        prefix = [m for i, m in enumerate(prefix) if i != compact_index]

    previous_status = ui_status_text
    set_status("compacting")
    render_log_line("memory", f"auto compacting... {remaining_before}% left", color_plan)
    try:
        summary = await summarize_history(prefix)
    except Exception as exc:
        summary = (
            fallback_history_summary(prefix)
            + "\n\nCompaction model error:\n"
            + brief_model_error(exc)
        )
    finally:
        set_status(previous_status or "idle")
    compacted = [
        {"role": "system", "content": "[COMPACTED SUMMARY]\n" + summary},
        *tail,
    ]
    remaining_after = update_compact_meter(compacted)
    save_session(session_id, compacted)
    render_log_line("memory", f"auto compacted ({remaining_after}% left)", color_plan)
    return compacted


def fallback_history_summary(
    history: list[dict[str, str]],
    *,
    truncator: Callable[[str, int], str],
) -> str:
    lines = [
        "Yedek compact ozeti.",
        "Asagidaki korunmus son mesajlardan devam et.",
    ]
    for item in history[-10:]:
        role = item.get("role", "unknown")
        content = str(item.get("content", "")).strip()
        if not content:
            continue
        lines.append(f"{role}: {truncator(content, 500)}")
    return "\n".join(lines)


async def summarize_history(
    history: list[dict[str, str]],
    *,
    call_model: Any,
    normalize_compact_summary: Callable[[str], str],
) -> str:
    summary_prompt = [
        {
            "role": "system",
            "content": (
                "Summarize the conversation state for a coding agent. "
                "Tum ciktiyi Turkce ver. "
                "Return plain text only. No reasoning, no chain-of-thought, no headings about your process. "
                "Use at most 24 short lines. Keep durable context only: goal, constraints, files touched, "
                "findings, decisions, unfinished work, user preferences, blockers, and important tool results. "
                "Prefer factual bullets over abstractions."
            ),
        },
        {
            "role": "user",
            "content": json.dumps(history, ensure_ascii=False)[-20000:],
        },
    ]
    return normalize_compact_summary(await call_model(summary_prompt, use_orchestra=False))
