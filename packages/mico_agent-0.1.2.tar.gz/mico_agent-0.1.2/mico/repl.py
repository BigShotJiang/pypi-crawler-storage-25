"""mico interaktif REPL — Claude Code stili akış.

Tasarım kararları:
  - Hiçbir full-screen TUI yok. Çıktı doğrudan stdout'a stream edilir,
    terminalin kendi scrollback'i çalışır (yukarı kaydır → eski geçmiş).
  - Input prompt_toolkit `PromptSession` kullanır (sadece input satırı için):
    history, multiline, completion var ama terminal alt-screen'i ele geçirilmez.
  - Status bilgisi animated spinner satırı olarak yazılır, bir sonraki çıktıdan
    önce temizlenir.
  - Ctrl+D = clean shutdown: model server'a TERM, kısa wait, gerekirse KILL.
  - Ctrl+C = aktif yanıtı iptal et, prompt'a dön.
  - Slash commands (/help, /mode, etc) intercepted before handle_message.
  - Bottom toolbar shows live state: model, mode, ctx, network, thinking.
"""
from __future__ import annotations

import atexit
import os
import signal
import sys
from pathlib import Path
from typing import Callable, Optional

from . import server as server_mod
from . import ui as ui_mod
from . import slash
from . import spinner as spinner_mod
from . import files_complete
from .model_recommender import Profile


# ---------------------------------------------------------------------------
# Spinner instance (shared across REPL session)
# ---------------------------------------------------------------------------

_spinner: Optional[spinner_mod.Spinner] = None


# ---------------------------------------------------------------------------
# Streaming print — pauses spinner during output
# ---------------------------------------------------------------------------

class StreamWriter:
    def __init__(self, spinner: spinner_mod.Spinner):
        self.spinner = spinner

    def write(self, text: str) -> None:
        if not text:
            return
        self.spinner.pause()
        sys.stdout.write(text)
        sys.stdout.flush()
        self.spinner.resume()

    def writeln(self, text: str = "") -> None:
        self.write(text + "\n")


def _slash_suggestion_text(text: str) -> str | None:
    """Return ghost-text suffix for a partially typed slash command."""
    if not text.startswith("/") or "\n" in text:
        return None
    raw = text[1:]
    if " " in raw:
        return None
    needle = raw.lower()
    for cmd in slash.top_level_completions():
        if cmd.name.startswith(needle):
            suffix = cmd.name[len(needle):]
            if suffix:
                return suffix
            if cmd.args_hint:
                return f" {cmd.args_hint}"
            return None
    return None


# ---------------------------------------------------------------------------
# Shutdown — Ctrl+D / SIGTERM / atexit safety net
# ---------------------------------------------------------------------------

_shutdown_called = False


def _shutdown(*_):
    global _shutdown_called
    if _shutdown_called:
        return
    _shutdown_called = True
    try:
        sys.stdout.write("\nModel sunucusu kapatılıyor...\n")
        sys.stdout.flush()
    except Exception:
        pass
    try:
        server_mod.stop(grace_seconds=3.0)
    except Exception as exc:
        sys.stderr.write(f"server stop error: {exc}\n")


def install_shutdown_hooks() -> None:
    atexit.register(_shutdown)
    # SIGTERM (kill) and SIGHUP (terminal closed) → clean shutdown
    for sig in (signal.SIGTERM, signal.SIGHUP):
        try:
            signal.signal(sig, _shutdown)
        except (ValueError, OSError):
            pass
    # SIGINT is handled at the prompt loop level so it cancels the current
    # response instead of exiting.


# ---------------------------------------------------------------------------
# Input prompt — uses prompt_toolkit minimally (no layout)
# ---------------------------------------------------------------------------

def _build_input_session(state: slash.RuntimeState):
    try:
        from prompt_toolkit import PromptSession
        from prompt_toolkit.history import FileHistory
        from prompt_toolkit.auto_suggest import AutoSuggestFromHistory
        from prompt_toolkit.auto_suggest import Suggestion
        from prompt_toolkit.completion import merge_completers
    except ImportError:
        return None

    hist_path = Path(os.environ.get("MICO_HOME", str(Path.home() / ".mico"))) / "history"
    hist_path.parent.mkdir(parents=True, exist_ok=True)

    # Build combined completer: slash commands + @-file completion
    slash_completer = _build_slash_completer()
    file_completer = files_complete.AtFileCompleter(get_cwd=os.getcwd)
    combined = merge_completers([slash_completer, file_completer])

    history_suggest = AutoSuggestFromHistory()

    class SlashAwareAutoSuggest:
        def get_suggestion(self, buffer, document):
            text = document.text_before_cursor
            if text.startswith("/") and "\n" not in text and document.cursor_position == len(document.text):
                suggestion = _slash_suggestion_text(text)
                if suggestion:
                    return Suggestion(suggestion)
            return history_suggest.get_suggestion(buffer, document)

        async def get_suggestion_async(self, buff, document):
            return self.get_suggestion(buff, document)

    # Bottom toolbar showing live state
    def get_toolbar_text():
        return ui_mod.bottom_toolbar_fragments(state)

    return PromptSession(
        history=FileHistory(str(hist_path)),
        auto_suggest=SlashAwareAutoSuggest(),
        completer=combined,
        complete_while_typing=True,
        style=ui_mod.prompt_toolkit_style(),
        bottom_toolbar=get_toolbar_text,
        refresh_interval=0.5,  # update toolbar tok/s + ctx % every 500ms
        # NO layout, NO full_screen — just a styled input line.
        enable_history_search=True,
        multiline=False,
    )


def _build_slash_completer():
    """Build a prompt_toolkit Completer for slash commands."""
    try:
        from prompt_toolkit.completion import Completer, Completion
        from prompt_toolkit.document import Document
    except ImportError:
        return None

    class SlashCommandCompleter(Completer):
        def get_completions(self, document: Document, _complete_event):
            text = document.text_before_cursor.lstrip()
            if not text.startswith("/"):
                return
            needle = text[1:].lower()  # After the /
            for cmd in slash.top_level_completions():
                cmd_name = cmd.name
                if cmd_name.startswith(needle):
                    hint = f" {cmd.args_hint}" if cmd.args_hint else ""
                    yield Completion(
                        text=cmd_name[len(needle):],
                        start_position=-len(needle),
                        display=f"/{cmd_name}{hint}",
                        display_meta=cmd.description,
                    )

    return SlashCommandCompleter()


def read_input(session, state: Optional[slash.RuntimeState] = None) -> str | None:
    """Return user input, or None on EOF (Ctrl+D)."""
    # TTY yoksa (pipe, test, CI) prompt_toolkit'i atla — plain stdin
    if session is None or not sys.stdin.isatty():
        try:
            if sys.stdin.isatty():
                sys.stdout.write("\033[1;32m❯\033[0m ")
                sys.stdout.flush()
            return input()
        except EOFError:
            return None
        except KeyboardInterrupt:
            sys.stdout.write("\n")
            return ""
    try:
        multiline = state.multiline if state else False
        text = session.prompt(ui_mod.prompt_fragments(), multiline=multiline)
        # Erase the prompt line so render_user_bubble replaces it cleanly.
        # Move up one line, clear it, then return to column 0.
        if text and text.strip() and sys.stdout.isatty():
            sys.stdout.write("\033[1A\033[2K")
            sys.stdout.flush()
        return text
    except EOFError:
        return None
    except KeyboardInterrupt:
        sys.stdout.write("\n")
        return ""


# ---------------------------------------------------------------------------
# REPL entry
# ---------------------------------------------------------------------------

def run_repl(profile: Profile,
             *,
             handle_message: Callable[[str, StreamWriter, spinner_mod.Spinner], None],
             runtime_state: Optional[slash.RuntimeState] = None) -> int:
    """Generic REPL. `handle_message(text, out, spinner)` runs one user turn.

    Args:
        profile: Model profile with model_name, context_window, etc.
        handle_message: Callback for user input (besides slash commands)
        runtime_state: RuntimeState for slash commands to mutate

    Returns:
        Shell exit code.
    """
    install_shutdown_hooks()

    # Check working directory — guard against running in home or root
    cwd = Path.cwd()
    if cwd == Path.home() or str(cwd) == "/":
        from rich.panel import Panel
        msg = (
            "⚠ Çalışma dizini ev klasörü ($HOME) veya root (/). "
            "mico kod yazmak için bir proje dizininde çalışmalı. "
            "/cd <yol> ile değiştir veya çıkıp proje dizininde tekrar başlat."
        )
        ui_mod.console.print(Panel(msg, style="mico.warn", padding=(1, 2)))
        sys.stdout.write("\n")
        sys.stdout.flush()

    ui_mod.render_welcome(
        model_name=profile.model_name or "(no model)",
        profile_name=profile.name,
        context_window=profile.context_window,
        workdir=os.getcwd(),
    )

    # Initialize state if not provided
    if runtime_state is None:
        runtime_state = slash.RuntimeState(profile=profile, cwd=os.getcwd())
    runtime_state.profile = profile
    runtime_state.cwd = os.getcwd()

    # Check for existing session and show hint if found
    pass  # Session cleared at startup; /resume to restore previous session

    # Hint about lazy loading
    try:
        ui_mod.console.print(
            "\n[mico.hint]İlk mesajla model yüklenecek.[/]",
            highlight=False,
        )
    except Exception:
        pass  # Silently skip if console unavailable

    # Create spinner (will skip animation if not a TTY)
    global _spinner
    _spinner = spinner_mod.Spinner(state=runtime_state)
    out = StreamWriter(_spinner)
    session = _build_input_session(runtime_state)

    import asyncio
    import time as _time

    # Try importing patch_stdout once; fall back gracefully if unavailable.
    try:
        from prompt_toolkit.patch_stdout import patch_stdout as _patch_stdout
        _has_patch_stdout = True
    except ImportError:
        _has_patch_stdout = False

    while True:
        # Read input — patch_stdout keeps the bottom toolbar visible while typing.
        if _has_patch_stdout:
            with _patch_stdout(raw=True):
                line = read_input(session, state=runtime_state)
        else:
            line = read_input(session, state=runtime_state)

        if line is None:           # Ctrl+D
            sys.stdout.write("\n")
            break
        line = line.strip()
        if not line:
            continue

        # Check if it's a slash command
        if line.startswith("/"):
            cmd_token = line.split()[0][1:]  # word after leading /
            if cmd_token in slash.REGISTRY:
                if asyncio.run(slash.dispatch(line, runtime_state)):
                    if runtime_state.quit_requested:
                        break
                    continue

        # Kullanıcı mesajını köşeli blok içinde göster ve LLM header'ını sıfırla
        ui_mod.render_user_bubble(line)
        ui_mod.reset_assistant_header()

        # Run LLM turn — patch_stdout keeps spinner and toolbar visible during generation.
        _turn_start = _time.monotonic()
        try:
            if _has_patch_stdout:
                with _patch_stdout(raw=True):
                    asyncio.run(handle_message(line, out, _spinner))
            else:
                asyncio.run(handle_message(line, out, _spinner))
        except KeyboardInterrupt:
            _spinner.pause()
            sys.stdout.write("\n[iptal edildi]\n")
            sys.stdout.flush()
            _spinner.resume()
        except Exception as exc:
            _spinner.pause()
            sys.stderr.write(f"\nHata: {exc}\n")
            _spinner.resume()
        _turn_elapsed = _time.monotonic() - _turn_start

        # Persist final tok/s for render_turn_stamp, then reset live counter.
        if runtime_state.live_tokens_per_sec > 0:
            runtime_state.last_tokens_per_sec = runtime_state.live_tokens_per_sec
        runtime_state.live_tokens_per_sec = 0.0

        # Update ctx usage and print a compact turn stamp (elapsed, tok/s, ctx%).
        try:
            from . import cli as mico_cli
            import json as _json
            session_file = mico_cli.SESSIONS_DIR / f"{runtime_state.session_id}.json"
            if session_file.exists():
                try:
                    raw = _json.loads(session_file.read_text(encoding="utf-8"))
                    hist = raw if isinstance(raw, list) else raw.get("history", raw.get("messages", []))
                    runtime_state.history_chars_used = sum(
                        len(str(m.get("content", ""))) for m in (hist or [])
                    )
                except Exception:
                    pass
            runtime_state.cwd = os.getcwd()
            ui_mod.render_turn_stamp(_turn_elapsed, runtime_state)
        except Exception:
            pass

    # Stop spinner and _shutdown will run via atexit
    if _spinner:
        _spinner.stop()
    return 0
