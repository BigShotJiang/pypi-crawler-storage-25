from __future__ import annotations

from typing import Any


def flatten_model_content(value: Any) -> str:
    if value is None:
        return ""
    if isinstance(value, str):
        return value
    if isinstance(value, list):
        parts: list[str] = []
        for item in value:
            if isinstance(item, str):
                parts.append(item)
                continue
            if not isinstance(item, dict):
                continue
            item_type = str(item.get("type", ""))
            if item_type in {"text", "output_text", "input_text"}:
                parts.append(str(item.get("text", "")))
                continue
            if "content" in item:
                parts.append(flatten_model_content(item.get("content")))
                continue
            if "text" in item:
                parts.append(str(item.get("text", "")))
        return "".join(parts)
    if isinstance(value, dict):
        for key in ("content", "text", "output_text", "reasoning_content"):
            if key in value:
                return flatten_model_content(value.get(key))
    return str(value)


def extract_choice_text(choice: dict[str, Any] | None) -> str:
    if not isinstance(choice, dict):
        return ""
    message = choice.get("message")
    if isinstance(message, dict):
        text = flatten_model_content(message.get("content"))
        if text:
            return text
        text = flatten_model_content(message.get("reasoning_content"))
        if text:
            return text
        text = flatten_model_content(message.get("reasoning"))
        if text:
            return text
    delta = choice.get("delta")
    if isinstance(delta, dict):
        # Only extract content here — reasoning is handled by extract_choice_reasoning
        text = flatten_model_content(delta.get("content"))
        if text:
            return text
    for key in ("text", "content"):
        text = flatten_model_content(choice.get(key))
        if text:
            return text
    return ""


def extract_choice_reasoning(choice: dict[str, Any] | None) -> str:
    if not isinstance(choice, dict):
        return ""
    message = choice.get("message")
    if isinstance(message, dict):
        text = flatten_model_content(message.get("reasoning_content"))
        if text:
            return text
    delta = choice.get("delta")
    if isinstance(delta, dict):
        for key in ("reasoning_content", "reasoning", "thinking"):
            text = flatten_model_content(delta.get(key))
            if text:
                return text
    for key in ("reasoning_content", "thinking", "reasoning"):
        text = flatten_model_content(choice.get(key))
        if text:
            return text
    return ""

