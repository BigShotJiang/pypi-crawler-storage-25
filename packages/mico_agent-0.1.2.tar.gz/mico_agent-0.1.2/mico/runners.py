from __future__ import annotations

import abc
import asyncio
import os
from pathlib import Path
from typing import Optional


class RunnerResult:
    def __init__(self, stdout: str, stderr: str, exit_code: int, timed_out: bool = False):
        self.stdout = stdout
        self.stderr = stderr
        self.exit_code = exit_code
        self.timed_out = timed_out

    @property
    def combined(self) -> str:
        if not self.stdout and not self.stderr:
            return ""
        if self.stdout and not self.stderr:
            return self.stdout
        if not self.stdout and self.stderr:
            return self.stderr
        return f"{self.stdout}\n\n[stderr]\n{self.stderr}"


class BaseRunner(abc.ABC):
    @abc.abstractmethod
    async def run_command(
        self, 
        args: list[str], 
        cwd: Path, 
        timeout: float = 120.0,
        env: Optional[dict[str, str]] = None
    ) -> RunnerResult:
        pass

    @abc.abstractmethod
    async def run_python(
        self, 
        code: str, 
        cwd: Path, 
        timeout: float = 120.0
    ) -> RunnerResult:
        pass


class LocalRunner(BaseRunner):
    async def run_command(
        self, 
        args: list[str], 
        cwd: Path, 
        timeout: float = 120.0,
        env: Optional[dict[str, str]] = None
    ) -> RunnerResult:
        try:
            proc = await asyncio.create_subprocess_exec(
                *args,
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.PIPE,
                cwd=str(cwd),
                env={**os.environ, **(env or {})}
            )
            try:
                stdout, stderr = await asyncio.wait_for(proc.communicate(), timeout=timeout)
                return RunnerResult(
                    stdout.decode(errors="replace").strip(),
                    stderr.decode(errors="replace").strip(),
                    proc.returncode or 0
                )
            except asyncio.TimeoutError:
                try:
                    proc.kill()
                except ProcessLookupError:
                    pass
                return RunnerResult("", "Command timed out", 124, timed_out=True)
        except Exception as e:
            return RunnerResult("", str(e), 1)

    async def run_python(
        self, 
        code: str, 
        cwd: Path, 
        timeout: float = 120.0
    ) -> RunnerResult:
        # Use python3 to run the code
        import tempfile
        with tempfile.NamedTemporaryFile("w", suffix=".py", delete=False) as f:
            f.write(code)
            tmp_path = Path(f.name)
        
        try:
            res = await self.run_command(["python3", str(tmp_path)], cwd=cwd, timeout=timeout)
            return res
        finally:
            if tmp_path.exists():
                tmp_path.unlink()


class DockerRunner(BaseRunner):
    def __init__(self, image: str = "python:3.11-slim"):
        self.image = image

    async def run_command(
        self, 
        args: list[str], 
        cwd: Path, 
        timeout: float = 120.0,
        env: Optional[dict[str, str]] = None
    ) -> RunnerResult:
        # Shell out to docker run
        # Mount cwd to /workspace
        cmd_str = " ".join([f"'{a}'" if " " in a else a for a in args])
        docker_args = [
            "docker", "run", "--rm",
            "-v", f"{cwd.resolve()}:/workspace",
            "-w", "/workspace",
            self.image,
            "sh", "-c", cmd_str
        ]
        
        # Reuse LocalRunner's subprocess logic to call docker CLI
        local = LocalRunner()
        return await local.run_command(docker_args, cwd=cwd, timeout=timeout + 10, env=env)

    async def run_python(
        self, 
        code: str, 
        cwd: Path, 
        timeout: float = 120.0
    ) -> RunnerResult:
        # Run python code inside the container
        # We can pass code via stdin or a temp file in the mounted volume
        import tempfile
        with tempfile.NamedTemporaryFile("w", dir=str(cwd), suffix=".mico_tmp.py", delete=False) as f:
            f.write(code)
            tmp_name = Path(f.name).name
        
        try:
            return await self.run_command(["python3", tmp_name], cwd=cwd, timeout=timeout)
        finally:
            tmp_file = cwd / tmp_name
            if tmp_file.exists():
                tmp_file.unlink()
