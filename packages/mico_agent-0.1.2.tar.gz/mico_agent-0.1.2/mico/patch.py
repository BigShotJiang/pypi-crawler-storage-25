"""Robust patch validation and application pipeline for mico.

Small local models often emit malformed unified diffs. This module:
  * pre-parses the diff before touching disk,
  * runs `git apply --check` to detect context mismatches early,
  * applies with `git apply --3way`,
  * raises typed exceptions so the agent loop can issue targeted recovery
    prompts instead of bare error strings.
"""

from __future__ import annotations

import os
import subprocess
import tempfile
from dataclasses import dataclass, field
from pathlib import Path
from typing import Optional


# ---------------------------------------------------------------------------
# Exceptions
# ---------------------------------------------------------------------------


class PatchError(Exception):
    """Base class for all patch pipeline errors."""

    def __init__(self, message: str, *, detail: str = "", path: Optional[str] = None) -> None:
        super().__init__(message)
        self.message = message
        self.detail = detail
        self.path = path


class InvalidPatchError(PatchError):
    """The diff could not be parsed as a unified diff."""


class ContextMismatchError(PatchError):
    """git apply rejected one or more hunks because surrounding context did not match."""


class FileNotFoundInPatchError(PatchError):
    """A patch referenced a file that does not exist on disk (and is not marked create)."""


class DuplicateHunkError(PatchError):
    """Two hunks in the same patch overlap in the same file."""


class PartialApplyError(PatchError):
    """git apply applied some hunks but rejected others."""


class RewriteTooLargeError(PatchError):
    """Patch rewrites a disproportionate fraction of the file (likely a hallucinated rewrite)."""


# ---------------------------------------------------------------------------
# Plan dataclasses
# ---------------------------------------------------------------------------


@dataclass
class PatchFileChange:
    path: str
    kind: str  # "modify" | "create" | "delete" | "rename" | "binary"
    added_lines: int = 0
    removed_lines: int = 0
    existing_lines: int = 0  # filled by validate_patch when file exists
    old_path: str = ""  # only set for kind="rename"

    def churn_ratio(self) -> float:
        denom = max(self.existing_lines, 1)
        return (self.added_lines + self.removed_lines) / denom


@dataclass
class PatchPlan:
    files: list[PatchFileChange] = field(default_factory=list)

    def is_too_large(self, threshold: float = 0.6) -> bool:
        for change in self.files:
            if change.kind != "modify":
                continue
            # Tiny files (e.g. fixtures, configs) should not trip the heuristic;
            # rewriting a 3-line file completely is normal.
            if change.existing_lines > 0 and change.existing_lines < 20:
                continue
            if change.existing_lines <= 0:
                if change.added_lines + change.removed_lines >= 400:
                    return True
                continue
            if change.churn_ratio() > threshold:
                return True
        return False

    def summary(self) -> str:
        parts = []
        for change in self.files:
            if change.kind == "rename":
                parts.append(f"rename {change.old_path} → {change.path}")
            elif change.kind == "binary":
                parts.append(f"binary {change.path}")
            else:
                parts.append(
                    f"{change.kind} {change.path} (+{change.added_lines}/-{change.removed_lines})"
                )
        return "; ".join(parts) if parts else "no file changes"


# ---------------------------------------------------------------------------
# Parsing
# ---------------------------------------------------------------------------


def _strip_diff_prefix(path: str) -> str:
    if path.startswith(("a/", "b/")):
        return path[2:]
    return path


def parse_unified_diff(diff: str) -> PatchPlan:
    """Parse a unified diff into a PatchPlan.

    Pure function: does not read the filesystem. Only counts +/- lines per
    file and infers create/delete/modify from the headers.
    """
    if not diff or not diff.strip():
        raise InvalidPatchError("Empty diff")

    plan = PatchPlan()
    lines = diff.splitlines()
    i = 0
    n = len(lines)
    current: Optional[PatchFileChange] = None
    last_diff_git_new_path: str = ""  # path from most-recent "diff --git" line
    seen_hunks_by_file: dict[str, list[tuple[int, int]]] = {}
    saw_any_header = False

    def _commit_current() -> None:
        if current is not None:
            plan.files.append(current)

    while i < n:
        line = lines[i]
        if line.startswith("diff --git"):
            _commit_current()
            current = None
            saw_any_header = True
            # extract new-side path: "diff --git a/<old> b/<new>"
            parts = line.split(" b/", 1)
            last_diff_git_new_path = parts[1].strip() if len(parts) == 2 else ""
            i += 1
            continue
        # rename headers (appear between "diff --git" and "---"/"+++")
        if line.startswith("rename from "):
            old_name = line[len("rename from "):].strip()
            i += 1
            new_name = ""
            if i < n and lines[i].startswith("rename to "):
                new_name = lines[i][len("rename to "):].strip()
                i += 1
            _commit_current()
            current = PatchFileChange(path=new_name or old_name, kind="rename", old_path=old_name)
            seen_hunks_by_file.setdefault(current.path, [])
            saw_any_header = True
            continue
        # binary patch block — consume until next diff header
        if line.startswith("GIT binary patch"):
            saw_any_header = True
            binary_path = (current.path if current is not None else None) or last_diff_git_new_path
            _commit_current()
            current = PatchFileChange(path=binary_path, kind="binary")
            i += 1
            while i < n and not lines[i].startswith("diff --git"):
                i += 1
            _commit_current()
            current = None
            continue
        if line.startswith("--- "):
            saw_any_header = True
            old = line[4:].strip()
            new_line = lines[i + 1] if i + 1 < n else ""
            if not new_line.startswith("+++ "):
                raise InvalidPatchError(
                    "Malformed file header: '---' not followed by '+++'",
                    detail=line,
                )
            new = new_line[4:].strip()
            kind = "modify"
            path: str
            if old == "/dev/null":
                kind = "create"
                path = _strip_diff_prefix(new)
            elif new == "/dev/null":
                kind = "delete"
                path = _strip_diff_prefix(old)
            else:
                path = _strip_diff_prefix(new)
            _commit_current()
            current = PatchFileChange(path=path, kind=kind)
            seen_hunks_by_file.setdefault(path, [])
            i += 2
            continue
        if line.startswith("@@"):
            if current is None:
                raise InvalidPatchError("Hunk header @@ before file header", detail=line)
            # @@ -a,b +c,d @@
            try:
                meta = line.split("@@")[1].strip()
                old_part = meta.split(" ")[0]
                old_start = int(old_part.split(",")[0].lstrip("-").split(",")[0] or "0")
                old_count = int(old_part.split(",")[1]) if "," in old_part else 1
            except (ValueError, IndexError) as exc:
                raise InvalidPatchError(
                    "Malformed hunk header", detail=line
                ) from exc
            # detect overlap
            for prev_start, prev_count in seen_hunks_by_file[current.path]:
                if not (
                    old_start + old_count <= prev_start
                    or prev_start + prev_count <= old_start
                ):
                    raise DuplicateHunkError(
                        f"Overlapping hunks in {current.path}",
                        detail=f"prev=-{prev_start},{prev_count} new=-{old_start},{old_count}",
                        path=current.path,
                    )
            seen_hunks_by_file[current.path].append((old_start, old_count))
            i += 1
            # consume hunk body
            while i < n:
                body = lines[i]
                if body.startswith("@@") or body.startswith("diff --git") or body.startswith("--- "):
                    break
                if body.startswith("+") and not body.startswith("+++"):
                    current.added_lines += 1
                elif body.startswith("-") and not body.startswith("---"):
                    current.removed_lines += 1
                # context (' ') and '\\ No newline at end of file' ignored
                i += 1
            continue
        i += 1

    _commit_current()

    if not saw_any_header or not plan.files:
        raise InvalidPatchError(
            "No file headers found. Expected '--- a/<path>' / '+++ b/<path>'."
        )

    return plan


# ---------------------------------------------------------------------------
# Validation
# ---------------------------------------------------------------------------


def validate_patch(diff: str, cwd: Path) -> PatchPlan:
    """Parse + check that referenced files exist and fill existing_lines."""
    plan = parse_unified_diff(diff)
    cwd = Path(cwd)
    for change in plan.files:
        target = cwd / change.path
        if change.kind == "create":
            if target.exists():
                # The model wants to create a file that already exists; treat
                # as a soft modify so apply has a chance via 3-way merge.
                change.kind = "modify"
                try:
                    with target.open("rb") as fh:
                        change.existing_lines = sum(1 for _ in fh)
                except OSError:
                    change.existing_lines = 0
            continue
        if change.kind == "delete":
            if not target.exists():
                raise FileNotFoundInPatchError(
                    f"Cannot delete missing file: {change.path}",
                    path=change.path,
                )
            continue
        if change.kind == "rename":
            old_target = cwd / change.old_path if change.old_path else target
            if not old_target.exists():
                raise FileNotFoundInPatchError(
                    f"Cannot rename missing file: {change.old_path}",
                    path=change.old_path,
                )
            continue
        if change.kind == "binary":
            # binary patches pass through to git apply without line-count analysis
            continue
        # modify
        if not target.exists():
            raise FileNotFoundInPatchError(
                f"File referenced by patch does not exist: {change.path}",
                path=change.path,
            )
        try:
            with target.open("rb") as fh:
                change.existing_lines = sum(1 for _ in fh)
        except OSError:
            change.existing_lines = 0
    return plan


# ---------------------------------------------------------------------------
# Apply
# ---------------------------------------------------------------------------


def _run_git_apply(args: list[str], cwd: Path, timeout: float = 60.0) -> subprocess.CompletedProcess:
    return subprocess.run(
        ["git", "apply", *args],
        cwd=str(cwd),
        capture_output=True,
        text=True,
        timeout=timeout,
    )


def _classify_apply_error(stderr: str, path_hint: Optional[str] = None) -> PatchError:
    text = stderr or ""
    low = text.lower()
    if "does not exist" in low or "no such file" in low:
        return FileNotFoundInPatchError(
            "git apply could not locate target file",
            detail=text.strip(),
            path=path_hint,
        )
    if "patch does not apply" in low or "while searching for" in low or "patch failed" in low:
        return ContextMismatchError(
            "Patch context did not match the file on disk",
            detail=text.strip(),
            path=path_hint,
        )
    if "corrupt patch" in low or "unrecognized input" in low or "fatal" in low and "patch" in low:
        return InvalidPatchError(
            "git refused to parse the diff",
            detail=text.strip(),
            path=path_hint,
        )
    return PatchError(
        "git apply failed",
        detail=text.strip() or "unknown error",
        path=path_hint,
    )


def apply_patch(diff: str, cwd: Path, *, three_way: bool = True) -> PatchPlan:
    """Validate then apply the unified diff using `git apply --3way`."""
    cwd = Path(cwd)
    plan = validate_patch(diff, cwd)

    if plan.is_too_large():
        raise RewriteTooLargeError(
            "Patch rewrites more than 60% of at least one file",
            detail=plan.summary(),
        )

    # write the diff to a temp file (git apply prefers a real file)
    fd, tmp_name = tempfile.mkstemp(prefix="mico_", suffix=".patch", text=True)
    try:
        with os.fdopen(fd, "w") as fh:
            if not diff.endswith("\n"):
                fh.write(diff + "\n")
            else:
                fh.write(diff)

        check = _run_git_apply(["--check", tmp_name], cwd)
        if check.returncode != 0:
            raise _classify_apply_error(check.stderr or check.stdout)

        args = ["--3way", tmp_name] if three_way else [tmp_name]
        applied = _run_git_apply(args, cwd)
        if applied.returncode != 0:
            stderr = applied.stderr or applied.stdout or ""
            low = stderr.lower()
            # 3-way may produce per-hunk rejects -> partial apply
            if "applied patch" in low and ("with conflicts" in low or "rejected" in low):
                raise PartialApplyError(
                    "Patch partially applied with conflicts",
                    detail=stderr.strip(),
                )
            raise _classify_apply_error(stderr)
    finally:
        try:
            os.unlink(tmp_name)
        except OSError:
            pass

    return plan


# ---------------------------------------------------------------------------
# Recovery prompts
# ---------------------------------------------------------------------------


def _file_excerpt_block(file_excerpts: Optional[dict[str, str]]) -> str:
    if not file_excerpts:
        return ""
    parts = []
    for path, excerpt in file_excerpts.items():
        snippet = excerpt.strip()
        if len(snippet) > 1200:
            snippet = snippet[:1200] + "\n..."
        parts.append(f"--- {path} (current contents)\n{snippet}")
    return "\n\n" + "\n\n".join(parts)


def recovery_prompt(
    error: PatchError,
    *,
    file_excerpts: Optional[dict[str, str]] = None,
) -> str:
    path = error.path or "(unknown file)"
    detail = (error.detail or "").strip()
    detail_line = f" Underlying error: {detail}" if detail else ""

    if isinstance(error, InvalidPatchError):
        body = (
            "Your patch could not be parsed as a unified diff. "
            "Re-emit a single fenced unified diff. Use exact `--- a/<path>` and "
            "`+++ b/<path>` headers, then `@@ -<start>,<n> +<start>,<n> @@` hunk "
            "markers. Do not include prose, code fences, or blank lines before the "
            "first `---`."
        )
    elif isinstance(error, ContextMismatchError):
        body = (
            f"Your hunk did not apply to {path}. The surrounding context lines "
            "do not match the current file. Re-read the file with read_file, "
            "copy the exact current lines (no rewording), and emit a fresh patch "
            "whose context lines match byte-for-byte."
        )
    elif isinstance(error, FileNotFoundInPatchError):
        body = (
            f"The patch refers to {path}, but that file does not exist. "
            "Either pick an existing file (use list_files first), or emit a "
            "create-file patch with `--- /dev/null` and `+++ b/<path>`."
        )
    elif isinstance(error, DuplicateHunkError):
        body = (
            f"Two hunks in your patch overlap inside {path}. Merge them into a "
            "single contiguous hunk that covers the affected range exactly once."
        )
    elif isinstance(error, PartialApplyError):
        body = (
            "git applied some hunks but rejected others. Inspect the current "
            "file state, then emit a smaller patch covering only the still-needed "
            "changes. Do not re-send hunks that already applied."
        )
    elif isinstance(error, RewriteTooLargeError):
        body = (
            f"Your patch rewrites more than 60% of {path}. That usually means a "
            "hallucinated full rewrite. Break the change into smaller, focused "
            "hunks targeting only the lines that actually need to change."
        )
    else:
        body = (
            "Your patch failed to apply. Re-read the target file, then emit a "
            "fresh minimal unified diff."
        )

    return body + detail_line + _file_excerpt_block(file_excerpts)
