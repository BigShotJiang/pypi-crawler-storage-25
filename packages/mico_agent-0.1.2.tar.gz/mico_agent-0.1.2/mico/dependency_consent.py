"""İlk çalıştırmada eksik bağımlılıkları listele, onay al, kur.

`pip install mico` core dep'leri zaten kurar. Bu modül opsiyonel ekstralar
(MLX backend, prompt-toolkit gibi) için ek onay flow'u sağlar.

Akış:
  - import attempt → eksik olanlar tespit edilir
  - kullanıcıya liste + indirme boyutu (bilinmiyorsa "?")
  - onay yoksa: clean exit (1), mesaj.
"""
from __future__ import annotations

import importlib.util
import os
import subprocess
import sys
from pathlib import Path

CONFIG_DIR = Path(os.environ.get("MICO_HOME", str(Path.home() / ".mico")))
DEPS_FLAG = CONFIG_DIR / "deps-installed"
MICO_VENV = CONFIG_DIR / ".venv"
MICO_VENV_PYTHON = MICO_VENV / "bin" / "python"
PYTHON_POINTER = CONFIG_DIR / "python"   # bin/mico bunu okur


def _probe_python(py: Path, modules: list[str], timeout: float = 6.0) -> bool:
    """Bir Python yorumlayıcısının verilen modülleri import edebildiğini doğrula."""
    if not py.exists():
        return False
    code = "import " + ",".join(m for m in modules if m)
    try:
        result = subprocess.run(
            [str(py), "-c", code],
            capture_output=True, timeout=timeout,
        )
        return result.returncode == 0
    except (subprocess.TimeoutExpired, OSError):
        return False


def find_donor_python(needed_modules: list[str]) -> Path | None:
    """Ev dizininde mevcut venv'leri tara, gereken modülleri olan birini döndür.

    Kullanıcının başka bir projede zaten mlx/mlx_lm yüklü venv'i varsa
    yeniden indirmek yerine onu kullanmasını öner.
    """
    candidates: list[Path] = []
    seen: set[str] = set()

    def _add(py: Path) -> None:
        try:
            rp = str(py.resolve())
        except OSError:
            return
        if rp in seen:
            return
        seen.add(rp)
        candidates.append(py)

    # Şu an aktif venv
    if os.environ.get("VIRTUAL_ENV"):
        _add(Path(os.environ["VIRTUAL_ENV"]) / "bin" / "python")

    # Sistem / Homebrew Python yorumlayıcıları — pip install --user veya brew ile kurulmuş olabilir
    for sys_py in (
        Path("/usr/bin/python3"),
        Path("/usr/local/bin/python3"),
        Path("/opt/homebrew/bin/python3"),
        Path(sys.executable),  # mevcut çalışan yorumlayıcı
    ):
        _add(sys_py)

    # HOME / Desktop / Projects / code / dev — bir seviye derin tara
    parents = [
        Path.home(),
        Path.home() / "Desktop",
        Path.home() / "Projects",
        Path.home() / "code",
        Path.home() / "dev",
        Path.home() / "src",
    ]
    venv_names = (".venv", "venv", "env")
    for parent in parents:
        if not parent.is_dir():
            continue
        try:
            children = list(parent.iterdir())
        except OSError:
            continue
        # parent altında doğrudan venv (ör. ~/.venv)
        for vn in venv_names:
            _add(parent / vn / "bin" / "python")
        # parent/proje/.venv/bin/python
        for child in children:
            if not child.is_dir() or child.name.startswith("."):
                continue
            for vn in venv_names:
                _add(child / vn / "bin" / "python")

    # mico'nun kendi venv'ini hariç tut
    candidates = [c for c in candidates if c != MICO_VENV_PYTHON]

    for py in candidates:
        if _probe_python(py, needed_modules):
            return py
    return None


def write_python_pointer(python: Path) -> None:
    PYTHON_POINTER.parent.mkdir(parents=True, exist_ok=True)
    PYTHON_POINTER.write_text(str(python.resolve()) + "\n", encoding="utf-8")


def read_python_pointer() -> Path | None:
    if not PYTHON_POINTER.exists():
        return None
    try:
        line = PYTHON_POINTER.read_text(encoding="utf-8").strip()
    except OSError:
        return None
    if not line:
        return None
    p = Path(line)
    return p if p.exists() else None

# (import_name, pip_spec, description, approx_size_mb, optional)
RUNTIME_REQUIREMENTS = [
    ("requests", "requests>=2.31", "HTTP client (model server)", 1, False),
    ("prompt_toolkit", "prompt_toolkit>=3.0.43", "Interactive shell", 1, False),
    ("rich", "rich>=13.7", "Renkli terminal çıktısı", 2, False),
]

OPTIONAL_BACKENDS = {
    "mlx": [
        ("mlx", "mlx>=0.20", "Apple Silicon LLM backend", 80, True),
        ("mlx_lm", "mlx-lm>=0.21", "MLX language model server", 5, True),
    ],
    "mlx_vlm": [
        ("mlx", "mlx>=0.20", "Apple Silicon LLM backend", 80, True),
        ("mlx_vlm", "mlx-vlm>=0.5", "MLX vision/multimodal model server (Gemma4, LLaVA, vb.)", 30, True),
    ],
    "mtplx": [
        ("mtplx", "mtplx", "MTPLX native multi-token prediction server", 1, True),
    ],
}


def _import_ok(import_name: str) -> bool:
    return importlib.util.find_spec(import_name) is not None


def missing_requirements(reqs: list[tuple]) -> list[tuple]:
    return [r for r in reqs if not _import_ok(r[0])]


def prompt_install(missing: list[tuple], non_interactive: bool = False) -> bool:
    if not missing:
        return True
    sys.stdout.write("\nEksik bağımlılıklar:\n")
    total_mb = 0
    for import_name, pip_spec, desc, size_mb, _opt in missing:
        sys.stdout.write(f"  · {pip_spec:35} — {desc} (~{size_mb} MB)\n")
        total_mb += size_mb
    sys.stdout.write(f"  Toplam tahmini indirme: ~{total_mb} MB\n")

    if non_interactive:
        return False

    sys.stdout.write("\nKurmama izin veriyor musun? [Y/n]: ")
    sys.stdout.flush()
    try:
        ans = input().strip().lower()
    except (EOFError, KeyboardInterrupt):
        sys.stdout.write("\n")
        return False
    return not ans or ans.startswith("y") or ans in {"e", "evet"}


def _running_in_venv() -> bool:
    return sys.prefix != getattr(sys, "base_prefix", sys.prefix)


def _ensure_mico_venv() -> Path:
    """`~/.mico/.venv` yoksa oluştur. Path → python interpreter."""
    if MICO_VENV_PYTHON.exists():
        return MICO_VENV_PYTHON
    sys.stdout.write(f"\nmico için adanmış venv oluşturuluyor: {MICO_VENV}\n")
    sys.stdout.flush()
    try:
        subprocess.run(
            [sys.executable, "-m", "venv", "--upgrade-deps", str(MICO_VENV)],
            check=True,
        )
    except (subprocess.CalledProcessError, FileNotFoundError) as exc:
        # `--upgrade-deps` Python 3.9+; fallback'e gerek yok ama venv modülü yoksa hata
        sys.stdout.write(
            f"venv oluşturulamadı: {exc}\n"
            "Sistem Python'unda `python3 -m venv` modülü yok.\n"
            "Çözüm: `brew install python` veya distroya uygun python3-venv paketi.\n"
        )
        sys.exit(1)
    if not MICO_VENV_PYTHON.exists():
        sys.stdout.write("venv oluştu ama bin/python bulunamadı.\n")
        sys.exit(1)
    return MICO_VENV_PYTHON


def _re_exec_in_venv() -> None:
    """Eğer venv'de değilsek ve ~/.mico/.venv varsa oradan başlat."""
    # Sonsuz döngü önlemi — her zaman ilk kontrol
    if os.environ.get("_MICO_REEXECED") == "1":
        return
    if _running_in_venv():
        return
    if not MICO_VENV_PYTHON.exists():
        return
    # Venv python'u mico'yu import edebiliyorsa geçiş yap
    if not _probe_python(MICO_VENV_PYTHON, ["mico"]):
        sys.stdout.write(
            f"\n[mico] Uyarı: {MICO_VENV_PYTHON} mico'yu import edemiyor.\n"
            "       Venv'i sıfırlamak için: rm -rf ~/.mico/.venv && mico\n"
        )
        return
    os.environ["_MICO_REEXECED"] = "1"
    args = [str(MICO_VENV_PYTHON), "-m", "mico.entry", *sys.argv[1:]]
    os.execv(str(MICO_VENV_PYTHON), args)


def _pip_for(python: Path) -> list[str]:
    return [str(python), "-m", "pip", "install", "--upgrade", "--quiet"]


def _ask_yes(question: str, default: bool = True) -> bool:
    hint = "[Y/n]" if default else "[y/N]"
    sys.stdout.write(f"{question} {hint}: ")
    sys.stdout.flush()
    try:
        ans = input().strip().lower()
    except (EOFError, KeyboardInterrupt):
        sys.stdout.write("\n")
        return default
    if not ans:
        return default
    return ans.startswith("y") or ans in {"e", "evet"}


def _try_reuse_donor(missing: list[tuple]) -> Path | None:
    """Eksik modülleri zaten içeren bir venv var mı? Varsa kullanıcıya sor."""
    if MICO_VENV_PYTHON.exists():
        return None  # zaten kendi venv'imiz var, donora gerek yok
    needed = [r[0] for r in missing]
    sys.stdout.write("\nMevcut Python ortamları taranıyor (mlx_lm gibi paketler için)...\n")
    donor = find_donor_python(needed)
    if not donor:
        return None
    sys.stdout.write(f"\nBulundu: {donor}\n")
    sys.stdout.write("  → bu yorumlayıcıda gerekli modüller zaten yüklü.\n")
    if not _ask_yes("Yeni indirme yerine bu Python'u kullanayım mı?"):
        return None
    write_python_pointer(donor)
    return donor


def install(missing: list[tuple]) -> bool:
    if not missing:
        return True

    # Önce: başka bir venv'de tüm gerekenler var mı? Varsa onu kullan.
    donor = _try_reuse_donor(missing)
    if donor is not None:
        sys.stdout.write(f"\nmico bundan sonra şu Python'u kullanacak: {donor}\n")
        sys.stdout.write("Sonraki açılışlarda bu seçim hatırlanacak (~/.mico/python).\n\n")
        # Re-exec via the donor — bin/mico, sonraki çağrılarda pointer'ı okuyacak
        if str(Path(sys.executable).resolve()) != str(donor.resolve()):
            args = [str(donor), "-m", "mico.entry", *sys.argv[1:]]
            os.environ["_MICO_REEXECED"] = "1"
            os.execv(str(donor), args)
        return True

    # Donor yok → adanmış venv'e kur (PEP 668 sistem Python'unu engellediği için)
    if _running_in_venv():
        target_python = Path(sys.executable)
    else:
        target_python = _ensure_mico_venv()
    cmd = _pip_for(target_python) + [r[1] for r in missing]
    sys.stdout.write(f"\nÇalıştırılıyor: {' '.join(cmd)}\n\n")
    try:
        result = subprocess.run(cmd)
    except FileNotFoundError:
        sys.stdout.write("pip bulunamadı.\n")
        return False
    if result.returncode != 0:
        return False
    # Venv'e dep kurulduysa: mico'nun orada importlanabilir olduğunu garanti et, sonra reexec
    if target_python == MICO_VENV_PYTHON:
        _install_mico_into_venv(target_python)
        write_python_pointer(target_python)
        if not _running_in_venv():
            sys.stdout.write(f"\nmico kendi venv'inden yeniden başlatılıyor: {target_python}\n\n")
            _re_exec_in_venv()
    return True


def _install_mico_into_venv(venv_python: Path) -> None:
    """mico paketini venv'e editable olarak kur (ModuleNotFoundError önlemek için)."""
    # Kaynak kök: bu dosyanın bulunduğu paketin üst dizini
    pkg_root = Path(__file__).parent.parent.resolve()
    if not (pkg_root / "pyproject.toml").exists():
        return  # Kurulu bir wheel'den çalışıyoruz; tekrar kurma
    try:
        result = subprocess.run(
            [str(venv_python), "-m", "pip", "install", "--quiet", "-e", str(pkg_root)],
            capture_output=True,
            timeout=120,
        )
        if result.returncode != 0:
            sys.stdout.write(
                f"mico venv kurulumu başarısız:\n{result.stderr.decode(errors='replace')}\n"
            )
    except Exception as exc:
        sys.stdout.write(f"mico venv kurulumu atlandı: {exc}\n")


def _load_deps_flag() -> set[str]:
    """Return set of backend names recorded as installed in DEPS_FLAG."""
    try:
        import json as _json
        raw = DEPS_FLAG.read_text(encoding="utf-8").strip()
        data = _json.loads(raw) if raw.startswith("{") else {}
        backends = data.get("backends", [])
        return set(backends) if isinstance(backends, list) else set()
    except Exception:
        return set()


def _save_deps_flag(backends: list[str]) -> None:
    import json as _json
    DEPS_FLAG.parent.mkdir(parents=True, exist_ok=True)
    DEPS_FLAG.write_text(
        _json.dumps({"backends": sorted(set(backends))}, ensure_ascii=False),
        encoding="utf-8",
    )


def ensure_runtime_deps(*, include_backends: list[str] | None = None,
                       non_interactive: bool = False) -> None:
    """mico başlamadan önce çağırılır. Eksikse onay alır, kurar, yoksa exit(1)."""
    needed_backends = list(include_backends or [])

    # Fast path: DEPS_FLAG gerekli backend'lerin tümünü zaten kayıt etmişse
    # ve temel paketler (requests, prompt_toolkit, rich) bu Python'da erişilebilirse
    # import taramasını tamamen atla.
    if DEPS_FLAG.exists():
        recorded = _load_deps_flag()
        if all(b in recorded for b in needed_backends):
            # Sadece core paketleri kontrol et (bunlar her zaman gerekmeli)
            core_ok = all(_import_ok(r[0]) for r in RUNTIME_REQUIREMENTS)
            if core_ok:
                return

    reqs = list(RUNTIME_REQUIREMENTS)
    for backend in needed_backends:
        reqs += OPTIONAL_BACKENDS.get(backend, [])

    missing = missing_requirements(reqs)
    if not missing:
        _save_deps_flag(needed_backends)
        return

    # Eksik paketler var — önce sistemde/başka venv'de kurulu mu diye bak.
    # Bu makinede mlx_lm veya mtplx zaten kuruluysa kullanıcıya sormadan geçiş yap.
    needed_modules = [r[0] for r in missing]
    silent_donor = find_donor_python(needed_modules)
    if silent_donor is not None:
        sys.stdout.write(
            f"\n[mico] Gerekli paketler bulundu: {silent_donor}\n"
            f"       Yeniden indirme atlanıyor.\n\n"
        )
        write_python_pointer(silent_donor)
        _save_deps_flag(needed_backends)
        if str(Path(sys.executable).resolve()) != str(silent_donor.resolve()):
            os.environ["_MICO_REEXECED"] = "1"
            os.execv(str(silent_donor), [str(silent_donor), "-m", "mico.entry", *sys.argv[1:]])
        return

    approved = prompt_install(missing, non_interactive=non_interactive)
    if not approved:
        sys.stdout.write("Kurulum iptal edildi. mico bu bağımlılıklar olmadan çalışamaz.\n")
        sys.exit(1)

    ok = install(missing)
    if not ok:
        sys.stdout.write("Kurulum başarısız. Lütfen manuel deneyin:\n")
        sys.stdout.write("  pip install " + " ".join(r[1] for r in missing) + "\n")
        sys.exit(1)

    _save_deps_flag(needed_backends)
    sys.stdout.write("\nBağımlılıklar yüklendi.\n")
