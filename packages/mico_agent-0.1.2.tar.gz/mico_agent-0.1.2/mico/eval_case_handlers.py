from __future__ import annotations

from typing import Any, Callable


def handle_prompt_mode_case(
    case: Any,
    *,
    ctx: Any,
    resolve_mode_for_task: Callable[[str, Any], str],
    build_system_prompt: Callable[[str, Any], str],
) -> tuple[bool, str]:
    actual_mode = resolve_mode_for_task(case.task, ctx)
    actual_prompt = build_system_prompt(case.task, ctx)
    expected_mode = str(case.expected.get("mode", "")).strip()
    expected_contains = [str(x) for x in case.expected.get("prompt_contains", [])]
    ok = actual_mode == expected_mode and all(token in actual_prompt for token in expected_contains)
    detail = f"mode={actual_mode} expected={expected_mode}"
    return (ok, detail)


def handle_action_validation_case(
    case: Any,
    *,
    validate_action: Callable[[dict[str, Any]], tuple[bool, str]],
) -> tuple[bool, str]:
    action = dict(case.options.get("action", {}))
    valid, reason = validate_action(action)
    expected_valid = bool(case.expected.get("valid", False))
    ok = valid == expected_valid
    detail = "valid" if valid else f"invalid: {reason}"
    return (ok, detail)


def handle_local_shortcut_case(
    case: Any,
    *,
    ctx: Any,
    new_eval_session_id: Callable[[], str],
    tool_loop: Callable[[str, Any, str], tuple[str, list[dict[str, str]]]],
    truncator: Callable[[str, int], str],
) -> tuple[bool, str]:
    session_id = new_eval_session_id()
    result, _history = tool_loop(case.task, ctx, session_id)
    expected_contains = [str(x) for x in case.expected.get("result_contains", [])]
    ok = all(token in result for token in expected_contains)
    detail = truncator(result.replace("\n", " "), 220)
    return (ok, detail)


def handle_artifact_retrieval_case(
    case: Any,
    *,
    ctx: Any,
    new_eval_session_id: Callable[[], str],
    create_task_state: Callable[[str, str, Any], Any],
    append_artifacts: Callable[[Any, list[dict[str, Any]] | None], None],
    select_relevant_artifacts: Callable[[Any, str, list[dict[str, str]]], list[dict[str, Any]]],
) -> tuple[bool, str]:
    session_id = new_eval_session_id()
    state = create_task_state(session_id, case.task, ctx)
    append_artifacts(state, case.options.get("artifacts", []))
    selected = select_relevant_artifacts(state, case.task, [{"role": "user", "content": case.task}])
    labels = [str(item.get("label", "")) for item in selected]
    expected_label = str(case.expected.get("top_label", ""))
    ok = bool(labels) and labels[0] == expected_label
    detail = ", ".join(labels)
    return (ok, detail)


def handle_phase_plan_case(
    case: Any,
    *,
    ctx: Any,
    new_eval_session_id: Callable[[], str],
    create_task_state: Callable[[str, str, Any], Any],
) -> tuple[bool, str]:
    state = create_task_state(new_eval_session_id(), case.task, ctx)
    phase_names = [str(item.get("name", "")) for item in state.phases]
    expected_names = [str(x) for x in case.expected.get("phase_names", [])]
    ok = phase_names == expected_names and state.current_phase == str(case.expected.get("current_phase", ""))
    detail = f"{phase_names} current={state.current_phase}"
    return (ok, detail)


def handle_phase_transition_case(
    case: Any,
    *,
    ctx: Any,
    new_eval_session_id: Callable[[], str],
    create_task_state: Callable[[str, str, Any], Any],
    activate_phase: Callable[[Any, str], None],
    update_phase_after_tool: Callable[..., None],
) -> tuple[bool, str]:
    state = create_task_state(new_eval_session_id(), case.task, ctx)
    initial_phase = str(case.options.get("initial_phase", "")).strip()
    if initial_phase:
        activate_phase(state, initial_phase)
    action = dict(case.options.get("action", {}))
    result = str(case.options.get("result", ""))
    update_phase_after_tool(state, action, result, error=False)
    expected_phase = str(case.expected.get("current_phase", ""))
    ok = state.current_phase == expected_phase
    detail = f"current={state.current_phase} phases={[p.get('status') for p in state.phases]}"
    return (ok, detail)


def handle_stale_audit_guard_case(
    case: Any,
    *,
    ctx: Any,
    new_eval_session_id: Callable[[], str],
    create_task_state: Callable[[str, str, Any], Any],
    append_artifacts: Callable[[Any, list[dict[str, Any]] | None], None],
    should_force_finalize_on_stale_audit: Callable[[Any, dict[str, Any]], bool],
) -> tuple[bool, str]:
    state = create_task_state(new_eval_session_id(), case.task, ctx)
    state.mode = "audit"
    state.current_phase = "finalize"
    for phase in state.phases:
        name = str(phase.get("name", ""))
        if name == "finalize":
            phase["status"] = "active"
        elif name in {"scope", "probe", "assess"}:
            phase["status"] = "done"
    append_artifacts(state, case.options.get("artifacts", []))
    action = dict(case.options.get("action", {}))
    actual = should_force_finalize_on_stale_audit(state, action)
    expected = bool(case.expected.get("should_force", False))
    ok = actual == expected
    detail = f"force={actual} artifacts={len(state.artifacts)} tool={action.get('tool', '')}"
    return (ok, detail)


def handle_redundant_artifact_read_case(
    case: Any,
    *,
    ctx: Any,
    new_eval_session_id: Callable[[], str],
    create_task_state: Callable[[str, str, Any], Any],
    append_artifacts: Callable[[Any, list[dict[str, Any]] | None], None],
    redundant_artifact_read_reason: Callable[[Any, dict[str, Any]], str | None],
    artifact_reread_guidance: Callable[[Any], str],
) -> tuple[bool, str]:
    state = create_task_state(new_eval_session_id(), case.task, ctx)
    state.mode = str(case.options.get("mode", state.mode))
    append_artifacts(state, case.options.get("artifacts", []))
    action = dict(case.options.get("action", {}))
    reason = redundant_artifact_read_reason(state, action)
    guidance = artifact_reread_guidance(state) if reason else ""
    expected_blocked = bool(case.expected.get("blocked", False))
    expected_guidance = [str(x) for x in case.expected.get("guidance_contains", [])]
    ok = bool(reason) == expected_blocked and all(token in guidance for token in expected_guidance)
    detail = f"blocked={bool(reason)} reason={reason}"
    return (ok, detail)


def handle_redundant_http_probe_case(
    case: Any,
    *,
    ctx: Any,
    new_eval_session_id: Callable[[], str],
    create_task_state: Callable[[str, str, Any], Any],
    append_artifacts: Callable[[Any, list[dict[str, Any]] | None], None],
    redundant_http_probe_reason: Callable[[Any, dict[str, Any]], str | None],
    redundant_http_probe_guidance: Callable[[Any], str],
) -> tuple[bool, str]:
    state = create_task_state(new_eval_session_id(), case.task, ctx)
    state.mode = str(case.options.get("mode", state.mode))
    append_artifacts(state, case.options.get("artifacts", []))
    action = dict(case.options.get("action", {}))
    reason = redundant_http_probe_reason(state, action)
    guidance = redundant_http_probe_guidance(state) if reason else ""
    expected_blocked = bool(case.expected.get("blocked", False))
    expected_guidance = [str(x) for x in case.expected.get("guidance_contains", [])]
    ok = bool(reason) == expected_blocked and all(token in guidance for token in expected_guidance)
    detail = f"blocked={bool(reason)} reason={reason}"
    return (ok, detail)


def handle_verifier_gate_case(
    case: Any,
    *,
    ctx: Any,
    new_eval_session_id: Callable[[], str],
    create_task_state: Callable[[str, str, Any], Any],
    current_phase_entry: Callable[[Any], dict[str, Any]],
) -> tuple[bool, str]:
    state = create_task_state(new_eval_session_id(), case.task, ctx)
    state.current_phase = str(case.options.get("current_phase", state.current_phase))
    raw = {
        "status": "done",
        "should_continue": False,
        "done": True,
        "next_focus": "return final",
        "reason": "synthetic verifier output",
    }
    phase = current_phase_entry(state)
    phase_name = str(phase.get("name", ""))
    if raw["status"] == "done" and phase_name not in {"finalize", "final", "answer"}:
        gated = {
            "status": "continue",
            "should_continue": True,
            "done": False,
            "next_focus": str(phase.get("goal", "")),
            "reason": f"Current phase `{phase_name}` is still active.",
        }
    else:
        gated = raw
    expected_status = str(case.expected.get("status", ""))
    ok = gated["status"] == expected_status
    detail = f"status={gated['status']} phase={phase_name}"
    return (ok, detail)
