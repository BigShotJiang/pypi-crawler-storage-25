"""mico @-file completion for prompt_toolkit.

When user types @filename, completes against files in cwd (2 levels deep).
Ignores common ignored directories: .git, __pycache__, .venv, node_modules, .github, .env, dist, build.
"""
from __future__ import annotations

from pathlib import Path
from typing import Callable, Iterator

from prompt_toolkit.completion import Completer, Completion
from prompt_toolkit.document import Document


_IGNORE_DIRS = {".git", "__pycache__", ".venv", "node_modules", ".github", ".env", "dist", "build", ".pytest_cache", "*.egg-info"}


def _walk_files(base_dir: str, prefix: str = "", max_depth: int = 2, current_depth: int = 0) -> list[str]:
    """Recursively walk files up to max_depth, returning paths matching prefix.

    Args:
        base_dir: Root directory to start walking
        prefix: String prefix to match (relative to base_dir)
        max_depth: Maximum recursion depth (2 levels = files + one subdir)
        current_depth: Current recursion depth

    Returns:
        List of matching relative paths (up to 20)
    """
    results = []
    try:
        base_path = Path(base_dir)
        if not base_path.exists() or not base_path.is_dir():
            return results

        # List entries at this level
        try:
            entries = list(base_path.iterdir())
        except (PermissionError, OSError):
            return results

        for entry in entries:
            # Skip ignored directories
            if entry.is_dir() and entry.name in _IGNORE_DIRS:
                continue

            # Build relative path
            rel_path = entry.relative_to(base_path).as_posix()

            # Check if matches prefix
            if rel_path.startswith(prefix):
                results.append(rel_path)

            # Recurse if we have depth left and this is a directory
            if current_depth < max_depth - 1 and entry.is_dir():
                # For subdirs, only recurse if prefix starts with or is a parent of this dir
                if prefix.startswith(entry.name + "/") or prefix.startswith(entry.name):
                    sub_prefix = prefix[len(entry.name) + 1:] if prefix.startswith(entry.name + "/") else ""
                    sub_results = _walk_files(
                        str(entry),
                        prefix=sub_prefix,
                        max_depth=max_depth,
                        current_depth=current_depth + 1,
                    )
                    for sub in sub_results:
                        full_sub = (entry.name + "/" + sub).lstrip("/")
                        if full_sub.startswith(prefix):
                            results.append(full_sub)
    except Exception:
        pass

    return results[:20]  # Limit to top 20


class AtFileCompleter(Completer):
    """Completer for @filename in prompt_toolkit input.

    Matches files starting with @ in the text and provides completions.
    """

    def __init__(self, get_cwd: Callable[[], str]) -> None:
        """Initialize with a callable that returns current working directory.

        Args:
            get_cwd: Callable returning current working directory path
        """
        self.get_cwd = get_cwd

    def get_completions(self, document: Document, _complete_event: object) -> Iterator[Completion]:
        """Generate completions for @-prefixed paths.

        Args:
            document: prompt_toolkit Document
            _complete_event: Unused

        Yields:
            Completion objects for matching files
        """
        text = document.text_before_cursor

        # Find the last @ in the text
        if "@" not in text:
            return

        last_at_pos = text.rfind("@")
        prefix = text[last_at_pos + 1:]

        # Only complete if @ is preceded by whitespace or is at start of input
        if last_at_pos > 0 and text[last_at_pos - 1] not in (" ", "\t", "\n", "(", "[", "{"):
            return

        # Get the working directory
        try:
            cwd = self.get_cwd()
        except Exception:
            return

        # Walk and find matching files
        matches = _walk_files(cwd, prefix=prefix, max_depth=2)

        for match in matches:
            # Completion shows the matched part after @
            # Start position is -len(prefix) to replace what user typed after @
            yield Completion(
                text=match[len(prefix):] if match.startswith(prefix) else match,
                start_position=-len(prefix),
                display=match,
            )
