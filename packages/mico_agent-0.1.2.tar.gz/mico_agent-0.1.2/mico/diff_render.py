from __future__ import annotations

import difflib
from pathlib import Path
from typing import Callable


def render_live_diff(
    path: Path,
    before: str,
    after: str,
    *,
    render_log_line: Callable[[str, str, str], None],
    summarize_edit: Callable[[Path, str, str], str],
    color_edit: str,
    stream_stdout: Callable[[str], None],
    stream_stdout_style: Callable[[str, str], None],
) -> None:
    if before == after:
        return
    render_log_line("edit", summarize_edit(path, before, after), color_edit)
    diff_lines = difflib.unified_diff(
        before.splitlines(),
        after.splitlines(),
        lineterm="",
    )
    for line in diff_lines:
        if line.startswith("@@"):
            stream_stdout_style("  " + line + "\n", "dim")
        elif line.startswith("---") or line.startswith("+++"):
            continue
        elif line.startswith("-"):
            stream_stdout_style("  " + line + "\n", "red")
        elif line.startswith("+"):
            stream_stdout_style("  " + line + "\n", "green")
        elif line:
            stream_stdout("  " + line + "\n")
