"""System prompt and task prompt builder for mico."""

from __future__ import annotations

import os
from pathlib import Path
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from mico.cli import ToolContext

# Constants
ROOT = Path(__file__).resolve().parent.parent
SYSTEM_PROMPT_PATH = ROOT / "profiles" / "mico-system.txt"

COMPACT_SYSTEM_PROMPT = """
You are mico, a local coding agent.
Goal: finish the task end-to-end with minimal steps.
Output: exactly one JSON object per turn — no prose, no markdown.

{"type":"tool","tool":"bash","command":"pwd","timeout":30000}
{"type":"tool","tool":"read_file","path":"file.py"}
{"type":"tool","tool":"read_file","path":"file.py","offset":100,"limit":80}
{"type":"tool","tool":"write_file","path":"out.py","content":"..."}
{"type":"tool","tool":"replace_in_file","path":"f.py","old":"x","new":"y"}
{"type":"tool","tool":"list_files","path":"."}
{"type":"tool","tool":"grep_code","pattern":"TODO","path":"."}
{"type":"tool","tool":"git_tool","op":"status"}
{"type":"tool","tool":"run_tests","runner":"auto"}
{"type":"tool","tool":"http_request","url":"http://...","method":"GET"}
{"type":"tool","tool":"python_run","code":"print(1+1)","timeout":10000}
{"type":"final","message":"Turkce kisa ozet"}

Rules:
- Read before editing. Use replace_in_file for targeted edits, write_file for full rewrites.
- After writing a file, do NOT re-read it — go to next step or final.
- Never paste code blocks in final.message — write to file, then final with path.
- final.message must be a SHORT human summary — never copy raw tool output into it.
- If a tool fails, try a different approach; do not retry same args twice.
- Be platform-aware: use commands appropriate for the OS shown in Runtime context.
- Final message always in Turkish.
- For large files: use grep_code first to find line numbers, then read_file with offset+limit to read only relevant sections.
- Analysis tasks: grep → targeted read → conclude. Never read the whole file if grep can locate the target.
- If a file says "implementations are in X.py" or "see X.py", immediately read that file next — do not conclude without it.
- When a file doesn't contain what you need, use grep_code or list_files to find the right file before concluding.
- grep_code patterns must be simple strings or basic regex (e.g. "def retry", "except", "retry"). Avoid complex multi-step regex patterns that may fail silently.
- To find a specific function: grep_code pattern="def function_name" to get line number, then read_file with offset=<line-1> limit=80.
- If a file read is truncated: use grep_code on the same file to search for specific keywords instead of re-reading the whole file.
""".strip()

LIGHTWEIGHT_SYSTEM_PROMPT = """Sen mico adında yerel bir kodlama asistanısın.
Her turda yalnızca tek bir JSON objesi döndür — başka hiçbir şey yazma.

{"type":"tool","tool":"bash","command":"...","timeout":30000}
{"type":"tool","tool":"read_file","path":"..."}
{"type":"tool","tool":"write_file","path":"...","content":"..."}
{"type":"tool","tool":"replace_in_file","path":"...","old":"...","new":"..."}
{"type":"tool","tool":"list_files","path":"."}
{"type":"tool","tool":"grep_code","pattern":"...","path":"."}
{"type":"tool","tool":"git_tool","op":"status"}
{"type":"tool","tool":"run_tests","runner":"auto"}
{"type":"final","message":"Türkçe kısa özet — tool çıktısını tekrarlama"}

- Düzenlemeden önce oku. Dosya yazdıktan sonra tekrar okuma.
- final.message kısa insan özeti olmalı — ham tool çıktısını kopyalama.
- Kullanıcı Türkçe yazdıysa Türkçe, İngilizce yazdıysa İngilizce cevap ver.
""".strip()

COMPACT_CODE_ADDENDUM = """
Coding mode:
- Work like a focused code editor-agent, not a generic chat model.
- Prefer this loop: inspect relevant files -> decide -> patch -> verify -> final.
- Keep file scope tight. Avoid scanning the whole repo unless necessary.
- Prefer concrete edits and diffs over long explanations.
- Stop exploring once you have enough context to change the right files.
""".strip()


def _role_language_note() -> str:
    return (
        "\n\nDil kilidi:\n"
        "- Tum gorunur ciktilari Turkce ver.\n"
        "- final.message her zaman Turkce olsun.\n"
        "- Compact sonrasi devam, blocker metni ve kisa ozetler de Turkce olsun."
    )


def _compact_architect_addendum() -> str:
    return (
        "Architect mode:\n"
        "- Gorevi tek cumleyle netlestir.\n"
        "- En fazla 5 maddelik kisa plan cikar.\n"
        "- Yalnizca bakilacak dosyalari, riskleri ve dogrulama yolunu soyle.\n"
        "- Kod yazma, patch uretme, terminal komutu calistirma onerisi verme.\n"
        "- Tahmin etme; eksik bilgi varsa hangi dosyanin okunmasi gerektigini soyle."
    )


def _compact_reviewer_addendum() -> str:
    return (
        "Review mode:\n"
        "- Sadece diff, test sonucu ve kisa gorev ozeti uzerinden degerlendir.\n"
        "- Once bug, regresyon, guvenlik riski, gereksiz degisiklik ve eksik test ara.\n"
        "- Stil tartismasi yapma; bulgulari kisa ve uygulanabilir ver.\n"
        "- Dosya duzenleme veya yeni plan uretme."
    )


def _compact_docs_addendum() -> str:
    return (
        "Docs mode:\n"
        "- README, kullanim aciklamasi, yorum ve ozet yaz.\n"
        "- Teknik olarak dogru, kisa ve taranabilir ol.\n"
        "- Kod degisikligi onermeden once mevcut davranisi netlestir.\n"
        "- Gereksiz teori ve uzun girisler yazma."
    )


def _runtime_context_note() -> str:
    import datetime as _dt
    import platform as _platform

    today = _dt.date.today().isoformat()
    model_str = os.environ.get("MODEL_NAME", "unknown")
    model_slug = (model_str or "unknown").split("/")[-1]
    _sys_name = _platform.system()
    _os_label = f"macOS {_platform.mac_ver()[0]}" if _sys_name == "Darwin" else f"{_sys_name} {_platform.release()}"
    return (
        f"\n\nRuntime context (factual — do not contradict or speculate beyond this):\n"
        f"- Today's date: {today}\n"
        f"- Active model: {model_slug}\n"
        f"- OS: {_os_label}\n"
        f"- You are mico, a local AI coding agent running on the user's hardware. You are NOT Claude, GPT, or any other cloud model.\n"
        f"- Your identity is strictly 'mico'. Do NOT hallucinate identities or training cutoff dates.\n"
        f"- If you do not have information (like web links or real-time data), explicitly say 'I don't know' or 'I don't have web access'.\n"
        f"- Never claim to be an Anthropic model or follow Anthropic's deployment schedules."
    )


def _task_has_explicit_steps(task: str) -> bool:
    """Check if task has 2+ explicit numbered/bulleted steps."""
    from mico.task_classify import extract_task_body
    import re as _re

    body = extract_task_body(task)
    steps: list[str] = []
    for raw in body.splitlines():
        line = raw.strip()
        if not line:
            continue
        match = _re.match(r"^(?:[-*]|\d+[.)])\s+(.+)$", line)
        if match:
            steps.append(match.group(1).strip())
    # Use dedup if available
    try:
        from mico.cli import dedupe_keep_order
        steps = [step for step in dedupe_keep_order(steps) if len(step) >= 8]
    except (ImportError, NameError):
        # Fallback dedup
        seen = set()
        deduped = []
        for step in steps:
            if step not in seen and len(step) >= 8:
                seen.add(step)
                deduped.append(step)
        steps = deduped
    return len(steps) >= 2


def _network_note(ctx: "ToolContext") -> str:
    return (
        "\n\nNetwork access: ENABLED. "
        "When the user asks for current/live data (prices, rankings, links, docs, etc.), "
        "use http_request to fetch it before answering. "
        "Do NOT answer from training data when fresh data is available via http_request. "
        "If the request fails (e.g. no internet), say so explicitly — do not invent data. "
        "Preferred search: https://lite.duckduckgo.com/lite/?q=<query> or direct URL if known."
    )


def build_system_prompt(task: str, ctx: "ToolContext", role: str = "worker") -> str:
    """Build system prompt based on task, context, and role.

    Args:
        task: The user's task/goal
        ctx: ToolContext object (for profile and other state)
        role: Role identifier ('worker', 'architect', 'reviewer', 'docs')

    Returns:
        A complete system prompt string
    """
    # Import here to avoid circular imports
    from mico.task_classify import (
        classify_task,
        task_is_security_sensitive,
        task_needs_memory_guard,
        resolve_mode_for_task,
    )
    from mico.cli import MODEL

    language_note = _role_language_note() + _runtime_context_note() + _network_note(ctx)

    # Lightweight mode for smaller models and constrained profiles.
    try:
        import re as _re
        _m = _re.search(r"(\d+(?:\.\d+)?)\s*[bB](?![a-zA-Z])", MODEL or "")
        _params_b = float(_m.group(1)) if _m else 99.0
        profile_name = str(getattr(ctx, "profile", "") or "").strip().lower()
        explicit_mode = str(getattr(ctx, "mode", "auto") or "auto").strip().lower()
        effective_mode_hint = resolve_mode_for_task(task, ctx)
        lightweight_ok = not task_is_security_sensitive(task) and explicit_mode not in {"audit", "plan", "review"} and effective_mode_hint not in {"audit", "plan", "review"}
        if lightweight_ok and (_params_b <= 14.0 or profile_name in {"fast", "tight"}):
            return LIGHTWEIGHT_SYSTEM_PROMPT + language_note
    except Exception:
        pass

    # Load user skills if available
    try:
        from .skill_loader import load_skills
        skills = load_skills()
        skills_section = f"\n\nUser skills (apply when relevant):\n{skills}" if skills else ""
    except Exception:
        skills_section = ""

    task_kind = classify_task(task)
    effective_mode = resolve_mode_for_task(task, ctx)
    role = (role or "worker").strip().lower()

    if task_needs_memory_guard(task, ctx):
        if role == "architect":
            return COMPACT_SYSTEM_PROMPT + "\n\n" + _compact_architect_addendum() + language_note + skills_section
        if role == "reviewer":
            return COMPACT_SYSTEM_PROMPT + "\n\n" + _compact_reviewer_addendum() + language_note + skills_section
        if role == "docs":
            return COMPACT_SYSTEM_PROMPT + "\n\n" + _compact_docs_addendum() + language_note + skills_section
        if effective_mode == "audit":
            return (
                COMPACT_SYSTEM_PROMPT
                + "\n\n"
                + "Heavy audit mode:\n"
                + "- Keep context minimal.\n"
                + "- Start with one targeted inspection step only.\n"
                + "- Prefer concrete local observations over broad planning.\n"
                + "- If the task is blocked by missing network access or missing user-supplied credentials, say so briefly.\n"
                + language_note + skills_section
            )
        return COMPACT_SYSTEM_PROMPT + language_note + skills_section

    use_full_prompt = ctx.profile == "deep" or effective_mode in {"audit", "plan"}
    if task_kind in {"trivial_chat", "local_info", "brief_general"}:
        use_full_prompt = False

    if role == "architect":
        return COMPACT_SYSTEM_PROMPT + "\n\n" + _compact_architect_addendum() + language_note + skills_section
    if role == "reviewer":
        return COMPACT_SYSTEM_PROMPT + "\n\n" + _compact_reviewer_addendum() + language_note + skills_section
    if role == "docs":
        return COMPACT_SYSTEM_PROMPT + "\n\n" + _compact_docs_addendum() + language_note + skills_section

    if not use_full_prompt and not task_is_security_sensitive(task):
        if effective_mode == "code":
            return COMPACT_SYSTEM_PROMPT + "\n\n" + COMPACT_CODE_ADDENDUM + language_note + skills_section
        if effective_mode == "review":
            return COMPACT_SYSTEM_PROMPT + "\n\nReview mode:\n- Prioritize bugs, regressions, and missing tests.\n- Findings first, summary second.\n- Do not modify files unless the user explicitly asks for changes." + language_note + skills_section
        if effective_mode == "plan":
            return COMPACT_SYSTEM_PROMPT + "\n\nPlan mode:\n- Produce an executable plan tied to concrete code or config areas.\n- Prefer dependencies, risks, and verification steps over prose." + language_note + skills_section
        return COMPACT_SYSTEM_PROMPT + language_note + skills_section

    if not use_full_prompt and task_is_security_sensitive(task):
        return COMPACT_SYSTEM_PROMPT + language_note + skills_section

    prompt = SYSTEM_PROMPT_PATH.read_text().strip()
    prompt = prompt.replace(
        "- Assume there is no internet. Do not try to download packages, clone repos, fetch docs, call remote APIs, or contact arbitrary external hosts unless the user explicitly asks for a network target and that target is central to the task.\n",
        "",
    ).replace(
        "- Prefer offline methods: local code review, local config inspection, local binaries, local packet captures, local logs, local test harnesses, localhost services, and user-provided samples.\n",
        "",
    )
    # Replace static macOS identity line with runtime OS
    import platform as _plat
    _sys_name = _plat.system()
    if _sys_name == "Darwin":
        _arch = _plat.machine()
        _os_str = f"macOS ({_plat.mac_ver()[0]}, {_arch})"
    else:
        _os_str = f"{_sys_name} ({_plat.release()}, {_plat.machine()})"
    prompt = prompt.replace(
        "You are mico, a local coding agent running in a terminal on macOS (Darwin, arm64).",
        f"You are mico, a local coding agent running in a terminal on {_os_str}.",
    )
    if _sys_name != "Darwin":
        prompt = prompt.replace(
            "- For macOS system administration tasks, prefer macos_admin_task over raw bash when it fits.",
            "- Use platform-appropriate administration commands (systemctl, ip, etc. on Linux).",
        ).replace(
            "- Be platform-aware. This machine is macOS, not Linux. Do not use Linux-specific commands like ip addr, ip route, apt, systemctl, or /proc unless the user explicitly asks for them.",
            "- Be platform-aware. This machine is Linux. Prefer Linux-native commands (ip, systemctl, /proc) over macOS-only ones.",
        )
    if task_is_security_sensitive(task):
        return prompt + language_note + skills_section
    return prompt + "\n\nPrefer coding and file work over generic reconnaissance when the task is not security-focused." + language_note + skills_section


def review_task_prompt(task: str) -> str:
    """Build prompt for review mode."""
    return (
        "Review mode. Findings first. Prioritize bugs, security risks, regressions, and missing tests. "
        "Do not modify files. Keep summary brief after findings.\n\n"
        f"Task:\n{task}"
    )


def audit_task_prompt(task: str) -> str:
    """Build prompt for audit mode."""

    return (
        "Audit mode. Act as a practical security auditing assistant for authorized lab work. "
        "Follow this workflow: Reconnaissance -> Vulnerability Scanning -> Proof of Concept -> Remediation. "
        "Prefer concrete commands, version collection, misconfiguration checks, evidence, and remediation steps. "
        "Choose tools deliberately: nmap for service discovery, ffuf or gobuster for web enumeration, curl for HTTP verification, "
        "openssl for TLS inspection, tshark or tcpdump for packet analysis. Use sqlmap only after a grounded SQLi hypothesis exists, "
        "and treat hydra as a narrow credential-audit tool only when the target and scope are explicit. "
        "Avoid generic theory. When useful, format findings as: "
        "Tespit Edilen Servis/Durum, Guvenlik Riski Hipotezi, Dogrulama Komutu (PoC), Analiz, Iyilestirme.\n\n"
        f"Task:\n{task}"
    )


def compact_audit_task_prompt(task: str) -> str:
    """Build prompt for compact audit mode (memory guard)."""
    from mico.task_classify import (
        extract_task_body,
        task_is_captive_portal_workflow,
    )

    if task_is_captive_portal_workflow(task):
        return (
            "Audit mode: captive portal workflow for authorized local testing. "
            "Follow this sequence exactly and do not loop:\n"
            "1. Redirect: make one GET to http://192.168.11.1 and record redirect/login URL.\n"
            "2. Form: use the captured artifact or one local grep/read to extract form action, method, and username/password field names. "
            "Do not curl the same login page again just to grep it.\n"
            "3. Bypass assessment: only report a bypass if the evidence shows one. Do not brute force, fuzz, or exploit.\n"
            "4. Timing: if no bypass evidence exists, perform at most one random credential POST and measure elapsed reject time.\n"
            "5. Script: write a local script that accepts username/password variables and repeats login attempts at the measured interval. "
            "Keep it rate-limited and parameterized; no credential guessing loop.\n"
            "6. Finalize with evidence, reject timing, script path, and blockers.\n\n"
            f"Task:\n{extract_task_body(task)}"
        )
    if _task_has_explicit_steps(task):
        return (
            "Audit mode. The user gave an ordered checklist. Treat each bullet as a subtask contract. "
            "Work on the active subtask only, use one high-signal tool result or blocker per subtask, then move forward. "
            "Do not repeat the same target with command variants once you already have equivalent evidence. "
            "If a subtask cannot be completed, record the blocker and continue to the next requested subtask when possible. "
            "Finalize only after every ordered subtask has evidence, output, or a blocker.\n\n"
            f"Task:\n{extract_task_body(task)}"
        )
    return (
        "Audit mode. Keep the first step narrow and evidence-driven. "
        "Do not expand into a long plan. Use one targeted inspection step, then reassess. "
        "If a required action is blocked by disabled network access or missing credentials, say so briefly.\n\n"
        f"Task:\n{extract_task_body(task)}"
    )


def code_task_prompt(task: str) -> str:
    """Build prompt for code mode."""
    return (
        "Code mode. Behave like a focused coding agent. "
        "Prefer a tight loop: inspect only relevant files, decide, make targeted edits, verify, then return final. "
        "Keep file scope narrow. Avoid generic repo exploration. "
        "When a concrete edit is needed, prefer patch-like progress over discussion. "
        "If enough context exists, stop reading and modify the right files.\n\n"
        f"Task:\n{task}"
    )


def mode_wrapped_task(task: str, ctx: "ToolContext") -> str:
    """Wrap task prompt with appropriate mode-specific instructions."""
    from mico.task_classify import (
        extract_task_body,
        task_prefers_brief_answer,
        task_needs_memory_guard,
        resolve_mode_for_task,
    )

    effective_mode = resolve_mode_for_task(task, ctx)
    if task_prefers_brief_answer(task):
        return (
            "Answer directly and briefly. Use at most one targeted tool call if needed. "
            "Do not turn this into a security audit, code review, or long report.\n\n"
            f"Task:\n{extract_task_body(task)}"
        )
    if effective_mode == "review":
        return review_task_prompt(task)
    if effective_mode == "audit":
        if task_needs_memory_guard(task, ctx):
            return compact_audit_task_prompt(task)
        return audit_task_prompt(task)
    if effective_mode == "plan":
        return (
            "Plan mode. Do not modify files. Inspect only as needed and produce a concrete execution plan. "
            "If enough context already exists, return final with numbered steps.\n\n"
            f"Task:\n{task}"
        )
    if effective_mode == "code":
        return (
            code_task_prompt(task)
            + "\n\nExecution discipline:\n"
            + "Work phase-first: inspect -> change -> verify -> finalize.\n"
            + "Do not finalize before verify unless the task is purely explanatory.\n"
        )
    return (
        "Default mode. Be tool-first and economical. "
        "For any non-trivial task, prefer one high-signal inspection tool before giving a final answer. "
        "Prefer typed tools over bash when they fit.\n"
        "Work phase-first: inspect before answer.\n\n"
        f"Task:\n{task}"
    )
