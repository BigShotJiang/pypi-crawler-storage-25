from __future__ import annotations

from typing import Any


def format_hms(seconds: float | int) -> str:
    total = max(0, int(seconds))
    h, rem = divmod(total, 3600)
    m, s = divmod(rem, 60)
    return f"{h:02d}:{m:02d}:{s:02d}"


def current_tok_per_sec(usage: dict[str, Any] | None) -> tuple[float, int]:
    usage = usage or {}
    completion = int(usage.get("completion_tokens") or 0)
    seconds = float(usage.get("llm_seconds") or 0.0)
    if completion <= 0 or seconds <= 0:
        return 0.0, completion
    return completion / seconds, completion


def context_bar_html(percent_remaining: int, width: int = 10) -> str:
    remaining = max(0, min(100, int(percent_remaining)))
    used_pct = 100 - remaining
    filled = max(0, min(width, round(width * used_pct / 100)))
    empty = width - filled
    if used_pct >= 85:
        bar_color = "#f85149"
    elif used_pct >= 60:
        bar_color = "#d29922"
    else:
        bar_color = "#388bfd"
    bar = (
        f"<style fg='{bar_color}'>{'█' * filled}</style>"
        f"<style fg='#30363d'>{'░' * empty}</style>"
    )
    return f"{bar} <style fg='#6e7681'>{used_pct}%</style>"


def build_prompt_status_markup(
    *,
    mode: str,
    approval: str,
    thinking_enabled: bool,
    runtime_profile: str,
    model_profile: str,
    dry_run: bool,
    session_short: str,
    model: str,
    cwd: str,
    thinking_budget: str,
    context_window_tokens: int,
    compact_remaining_percent: int,
    narrate: bool,
) -> str:
    return (
        "<b fg='#ffffff'>mode </b><b fg='#00ffff'>{mode}</b>"
        "   <b fg='#ffffff'>approval </b><b fg='#ffff00'>{approval}</b>"
        "   <b fg='#ffffff'>thinking </b><b fg='#00ff00'>{thinking}</b>\n"
        "<b fg='#ffffff'>runtime </b><b fg='#ffaf00'>{profile}</b>"
        "   <b fg='#ffffff'>models </b><b fg='#ff00ff'>{model_profile}</b>"
        "   <b fg='#ffffff'>dry-run </b><b fg='#ff5f5f'>{dry_run}</b>\n"
        "<b fg='#ffffff'>session </b><style fg='#808080'>{session}</style>"
        "   <b fg='#ffffff'>model </b><style fg='#808080'>{model}</style>\n"
        "<b fg='#ffffff'>cwd </b><style fg='#808080'>{cwd}</style>\n"
        "<b fg='#ffffff'>budget </b><b fg='#ff00ff'>{budget}</b>"
        "   <b fg='#ffffff'>context </b><b fg='#00ffff'>{context}</b>"
        "   <b fg='#ffffff'>compact </b><b fg='#5f87ff'>{compact}</b>\n"
        "   <b fg='#ffffff'>narrate </b><b fg='#5f87ff'>{narrate}</b>\n"
        "<style fg='#808080'>enter send · esc+enter newline · pgup/pgdn scroll · f7 bottom · ctrl+o thinking · ctrl+d exit</style>"
    ).format(
        mode=mode,
        approval=approval,
        thinking="on" if thinking_enabled else "off",
        profile=runtime_profile,
        model_profile=model_profile,
        dry_run="on" if dry_run else "off",
        session=session_short,
        model=model,
        cwd=cwd,
        budget=thinking_budget,
        context=context_window_tokens,
        compact=f"{compact_remaining_percent}%",
        narrate="on" if narrate else "off",
    )


def build_footer_status_markup(
    *,
    model: str,
    mode: str,
    runtime_profile: str,
    model_profile: str,
    context_window_tokens: int,
    thinking_enabled: bool,
    thinking_budget: int,
    adaptive_budget: bool,
    permission_mode: str,
    dry_run: bool,
    usage: dict[str, Any] | None,
) -> str:
    model_short = (model or "?").split("/")[-1][:28]
    sep = "  <style fg='#30363d'>│</style>  "
    ctx_window = f"ctx:{context_window_tokens}"
    if thinking_enabled:
        budget = f"think:{thinking_budget}{'+' if adaptive_budget else ''}"
    else:
        budget = "think:off"
    footer = (
        f"<b fg='#388bfd'>{model_short}</b>"
        f"{sep}<style fg='#8b949e'>{mode or 'auto'}</style>"
        f"{sep}<style fg='#a371f7'>runtime:{runtime_profile or 'balanced'}</style>"
        f"{sep}<style fg='#a371f7'>models:{model_profile}</style>"
        f"{sep}<style fg='#3fb950'>{ctx_window}</style>"
        f"{sep}<style fg='#d29922'>{budget}</style>"
        f"{sep}<style fg='#f0883e'>perm:{(permission_mode or 'balanced').lower()}</style>"
    )
    if dry_run:
        footer += f"{sep}<style fg='#f85149'>dry-run</style>"
    footer += f"{sep}<style fg='#6e7681'>Esc:cancel  Ctrl-D:exit  F6:focus  PgUp/Dn:scroll</style>"
    rate, completion = current_tok_per_sec(usage)
    if rate > 0:
        if rate >= 25:
            rate_color = "#3fb950"
        elif rate >= 8:
            rate_color = "#d29922"
        else:
            rate_color = "#f85149"
        footer += (
            f"{sep}<style fg='{rate_color}'>{rate:.1f} tok/s</style>"
            f"<style fg='#6e7681'> ({completion} tok)</style>"
        )
    return footer


def build_inline_status_markup(
    *,
    spinner_frame: str,
    status_text: str,
    elapsed_seconds: float | None,
    compact_remaining_percent: int,
    usage: dict[str, Any] | None,
) -> str:
    display_status = {
        "idle": "Idle",
        "working": "Working",
        "streaming": "Streaming",
        "stopping": "Stopping",
        "cancelled": "Cancelled",
    }.get(status_text, status_text.capitalize() if status_text else "Working")
    if status_text == "idle":
        spinner_style = "fg='#30363d'"
        text_style = "fg='#6e7681'"
    elif status_text in {"working", "streaming"}:
        spinner_style = "fg='#388bfd'"
        text_style = "fg='#8b949e'"
    elif status_text in {"stopping", "cancelled"}:
        spinner_style = "fg='#f85149'"
        text_style = "fg='#f85149'"
    else:
        spinner_style = "fg='#3fb950'"
        text_style = "fg='#8b949e'"
    elapsed = ""
    if elapsed_seconds is not None and status_text != "idle":
        elapsed = f"  <style fg='#6e7681'>{format_hms(elapsed_seconds)}</style>"
    interrupt_hint = ""
    if status_text != "idle":
        interrupt_hint = "  <style fg='#6e7681'>• esc to interrupt</style>"
    ctx_bar = context_bar_html(compact_remaining_percent)
    rate, completion = current_tok_per_sec(usage)
    if rate > 0:
        if rate >= 25:
            rate_color = "#3fb950"
        elif rate >= 8:
            rate_color = "#d29922"
        else:
            rate_color = "#f85149"
        rate_html = (
            f"  <style fg='#30363d'>│</style>"
            f"  <style fg='{rate_color}'>{rate:.1f} tok/s</style>"
            f"  <style fg='#6e7681'>({completion} tok)</style>"
        )
    else:
        rate_html = ""
    return (
        f"<style {spinner_style}>{spinner_frame}</style>"
        f"  <style {text_style}>{display_status}</style>"
        f"{elapsed}"
        f"{interrupt_hint}"
        f"  <style fg='#30363d'>│</style>  {ctx_bar}"
        f"{rate_html}"
    )
