"""Tool handler dispatch — her tool kendi async fonksiyonu, merkezi dict ile yönlendirme.

cli.py:run_tool buraya yönlenir: _HANDLERS[tool](action, ctx)
"""
from __future__ import annotations

import asyncio
import json
import os
import re
import shutil
import sys
from collections.abc import Awaitable, Callable
from pathlib import Path
from typing import Any, TYPE_CHECKING

import httpx

if TYPE_CHECKING:
    from mico.task_state import ToolContext


# ---------------------------------------------------------------------------
# Helpers — cli.py'den lazy import ile (circular import önlemi)
# ---------------------------------------------------------------------------

def _cli():
    import mico.cli as _c
    return _c


def _truncate(text: str, limit: int) -> str:
    return _cli().truncate(text, limit)


def _safe_path(path: str, ctx: "ToolContext", *, write: bool) -> Path:
    return _cli().safe_path_for_tool(path, ctx, write=write)


def _cached_read(path: Path) -> str:
    return _cli().cached_read_text(path)


def _cached_list(path: Path) -> list[str]:
    return _cli().cached_list_entries(path)


def _dispatch_mode(ctx: "ToolContext") -> str:
    return _cli().current_dispatch_mode(ctx)


def _disallowed(command: str, ctx: "ToolContext") -> str:
    return _cli().disallowed_command_reason(command, ctx)


def _lint(command: str) -> list[str]:
    return _cli().lint_bash_command(command)


def _confirm(label: str, ctx: "ToolContext") -> None:
    _cli().maybe_confirm(label, ctx)


def _ensure_binary(name: str) -> str:
    return _cli().ensure_binary(name)


async def _run_security_cmd(binary: str, args: list[str], ctx: "ToolContext") -> str:
    return await _cli().run_security_command(binary, args, ctx)


def _macos_admin(action: dict[str, Any]) -> str:
    return _cli().macos_admin_task(action)


def _MAX_OUT() -> int:
    return _cli().MAX_TOOL_OUTPUT_CHARS


def _MAX_READ() -> int:
    return _cli().MAX_READ_CHARS


def _candidate_project_matches(name: str, ctx: "ToolContext", *, limit: int = 8) -> list[Path]:
    root = Path(ctx.cwd).expanduser().resolve(strict=False)
    matches: list[Path] = []
    try:
        for found in root.rglob(name):
            if found.name != name:
                continue
            matches.append(found.resolve(strict=False))
            if len(matches) >= limit:
                break
    except Exception:
        return []
    return matches


def _resolve_missing_read_target(path: str, ctx: "ToolContext") -> tuple[Path | None, str]:
    raw = str(path or "").strip()
    if not raw:
        return None, ""
    requested = Path(raw).expanduser()
    cwd = Path(ctx.cwd).expanduser().resolve(strict=False)
    requested_abs = requested if requested.is_absolute() else (cwd / requested)
    requested_abs = requested_abs.resolve(strict=False)
    name = requested.name
    if not name:
        return None, ""

    # Common package-layout fallback: repo root request -> package module path.
    direct_candidates: list[Path] = []
    if requested.parent in {Path(""), Path(".")}:
        direct_candidates.extend([cwd / "mico" / name, cwd / "src" / name])
    if requested_abs.parent == cwd:
        direct_candidates.extend([cwd / "mico" / name, cwd / "src" / name])
    seen: set[Path] = set()
    for candidate in direct_candidates:
        candidate_r = candidate.resolve(strict=False)
        if candidate_r in seen:
            continue
        seen.add(candidate_r)
        if candidate_r.exists():
            return candidate_r, f"Requested path not found; resolved to project match: {candidate_r}"

    matches = _candidate_project_matches(name, ctx)
    if len(matches) == 1 and matches[0].exists():
        return matches[0], f"Requested path not found; resolved to unique project match: {matches[0]}"
    if matches:
        preview = ", ".join(str(p) for p in matches[:3])
        more = "" if len(matches) <= 3 else f" (+{len(matches) - 3} more)"
        return None, f"Requested path not found: {requested_abs}. Project matches: {preview}{more}"
    return None, f"Requested path not found: {requested_abs}"


Handler = Callable[[dict[str, Any], "ToolContext"], Awaitable[str]]


_IDEMPOTENT_RETRY_TOOLS = {
    "grep_code",
    "parse_json_file",
    "list_files",
    "read_file",
    "find_in_files",
    "rag_search",
    "env_info",
    "json_query",
    "macos_admin_task",
}


def _http_method(action: dict[str, Any]) -> str:
    return str(action.get("method", "GET")).strip().upper() or "GET"


def _is_retryable_tool(action: dict[str, Any]) -> bool:
    """Return True when retrying the action should not duplicate writes."""
    tool = str(action.get("tool", ""))
    if tool in _IDEMPOTENT_RETRY_TOOLS:
        return True
    if tool == "http_request":
        return _http_method(action) in {"GET", "HEAD", "OPTIONS"}
    if tool == "git_tool":
        return str(action.get("op", "")).strip().lower() in {"status", "log", "diff", "branch", "show"}
    return False


def _is_retryable_exception(exc: Exception) -> bool:
    if isinstance(exc, (httpx.TimeoutException, httpx.TransportError, OSError)):
        return True
    message = str(exc).lower()
    return any(
        marker in message
        for marker in (
            "temporarily unavailable",
            "connection reset",
            "connection refused",
            "timed out",
            "timeout",
            "resource busy",
        )
    )


def _is_retryable_result(action: dict[str, Any], result: str) -> bool:
    if str(action.get("tool", "")) != "http_request":
        return False
    if not _is_retryable_tool(action):
        return False
    first_line = result.splitlines()[0] if result else ""
    match = re.match(r"^status=(\d+)$", first_line.strip())
    if not match:
        return False
    status = int(match.group(1))
    return status == 429 or 500 <= status <= 599


async def _run_with_retry(handler: Handler, action: dict[str, Any], ctx: "ToolContext") -> str:
    """Minimal retry wrapper for transient failures on idempotent tools."""
    if not _is_retryable_tool(action):
        return await handler(action, ctx)

    attempts = max(1, min(int(action.get("retry_attempts", 2) or 2), 3))
    delay = max(0.0, min(float(action.get("retry_delay", 0.15) or 0.15), 1.0))
    last_exc: Exception | None = None
    result = ""

    for attempt in range(attempts):
        try:
            result = await handler(action, ctx)
            if not _is_retryable_result(action, result) or attempt == attempts - 1:
                return result
        except Exception as exc:
            if not _is_retryable_exception(exc) or attempt == attempts - 1:
                raise
            last_exc = exc
        await asyncio.sleep(delay * (2 ** attempt))

    if last_exc is not None:
        raise last_exc
    return result


# ---------------------------------------------------------------------------
# Handlers
# ---------------------------------------------------------------------------

async def _grep_code(action: dict[str, Any], ctx: "ToolContext") -> str:
    pattern = str(action.get("pattern", "")).strip()
    path = str(action.get("path", ".")).strip()
    if not pattern:
        raise ValueError("grep_code: pattern gerekli")
    target = _safe_path(path, ctx, write=False)
    # Support pipe-alternation like "TODO|FIXME" or "TODO\|FIXME" via multiple -e args for rg
    import re as _re
    raw_parts = _re.split(r"(?<!\\)\|", pattern.replace(r"\|", "|"))
    parts = [p.strip() for p in raw_parts if p.strip()]
    if len(parts) > 1:
        args: list[str] = ["-n", "--hidden"]
        for p in parts:
            args += ["-e", p]
        args.append(str(target))
    else:
        args = ["-n", "--hidden", pattern, str(target)]
    result = await _run_security_cmd(_ensure_binary("rg"), args, ctx)
    if result.startswith("exit_code=1") and "(no output)" in result:
        return f"exit_code=1\nNo matches found for '{pattern}' in {path}. Try a simpler pattern."
    return result


async def _parse_json_file(action: dict[str, Any], ctx: "ToolContext") -> str:
    path = str(action.get("path", "")).strip()
    if not path:
        raise ValueError("parse_json_file: path gerekli")
    try:
        target = _safe_path(path, ctx, write=False)
        data = json.loads(_cached_read(target))
        return _truncate(json.dumps(data, ensure_ascii=False, indent=2), _MAX_OUT())
    except FileNotFoundError:
        target, note = _resolve_missing_read_target(path, ctx)
        if target is None:
            raise FileNotFoundError(note or path)
        data = json.loads(_cached_read(target))
        return f"{note}\n{_truncate(json.dumps(data, ensure_ascii=False, indent=2), _MAX_OUT())}"


async def _http_request(action: dict[str, Any], ctx: "ToolContext") -> str:
    url = str(action.get("url", "")).strip()
    method = str(action.get("method", "GET")).strip().upper()
    headers = action.get("headers", {}) or {}
    body = str(action.get("body", ""))
    timeout = int(action.get("timeout", 120000)) / 1000.0
    if not url:
        raise ValueError("http_request: url gerekli")
    host_match = re.match(r"https?://([^\s/\"'?#]+)", url)
    if not host_match:
        raise RuntimeError("http_request: http(s) URL gerekli.")
    async with httpx.AsyncClient(timeout=timeout) as client:
        response = await client.request(
            method,
            url,
            headers={str(k): str(v) for k, v in headers.items()},
            content=body.encode("utf-8") if body else None,
        )
        header_text = "\n".join(f"{k}: {v}" for k, v in response.headers.items())
        return (
            f"status={response.status_code}\n"
            f"url={response.url}\n"
            f"headers:\n{header_text}\n\n"
            f"body:\n{_truncate(response.text or '', _MAX_OUT())}"
        )


async def _list_files(action: dict[str, Any], ctx: "ToolContext") -> str:
    path = str(action.get("path", ".")).strip()
    try:
        target = _safe_path(path, ctx, write=False)
    except FileNotFoundError:
        target, note = _resolve_missing_read_target(path, ctx)
        if target is None:
            raise FileNotFoundError(note or path)
        if target.is_file():
            return f"{note}\n{target}"
        return f"{note}\n" + "\n".join(_cached_list(target))
    if not target.exists():
        target, note = _resolve_missing_read_target(path, ctx)
        if target is None:
            raise FileNotFoundError(note or str(_safe_path(path, ctx, write=False)))
        if target.is_file():
            return f"{note}\n{target}"
        return f"{note}\n" + "\n".join(_cached_list(target))
    if target.is_file():
        return str(target)
    return "\n".join(_cached_list(target))


async def _read_file(action: dict[str, Any], ctx: "ToolContext") -> str:
    path = str(action["path"]).strip()
    try:
        target = _safe_path(path, ctx, write=False)
        text = _cached_read(target)
    except FileNotFoundError:
        resolved, note = _resolve_missing_read_target(path, ctx)
        if resolved is None:
            raise FileNotFoundError(note or path)
        text = _cached_read(resolved)
        text = f"{note}\n{text}"
    offset = action.get("offset")
    limit = action.get("limit")
    if offset is not None or limit is not None:
        lines = text.splitlines(keepends=True)
        start = max(0, int(offset or 0))
        end = start + int(limit) if limit is not None else len(lines)
        text = "".join(lines[start:end])
    return _truncate(text, _MAX_READ())


async def _write_file(action: dict[str, Any], ctx: "ToolContext") -> str:
    if _dispatch_mode(ctx) == "review":
        raise RuntimeError("write_file review modunda devre dışı.")
    target = _safe_path(action["path"], ctx, write=True)
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_text(action.get("content", ""))
    return f"Yazıldı: {target}"


async def _replace_in_file(action: dict[str, Any], ctx: "ToolContext") -> str:
    if _dispatch_mode(ctx) == "review":
        raise RuntimeError("replace_in_file review modunda devre dışı.")
    target = _safe_path(action["path"], ctx, write=True)
    old = action["old"]
    new = action["new"]
    text = target.read_text()
    if old not in text:
        raise ValueError("replace_in_file: old text bulunamadı")
    target.write_text(text.replace(old, new, 1))
    return f"Güncellendi: {target}"


async def _run_tests(action: dict[str, Any], ctx: "ToolContext") -> str:
    from mico.testloop import TestRunner, detect_test_runners
    from mico.testloop import run_tests as _run_tests_impl
    runner_name = str(action.get("runner", "auto") or "auto").strip().lower()
    timeout = max(1, min(int(action.get("timeout", 180)), 600))
    detected = detect_test_runners(ctx.cwd)
    if runner_name == "auto":
        if not detected:
            return "test runner bulunamadı"
        runner = detected[0]
    else:
        runner = next((r for r in detected if r.name == runner_name), None)
        if runner is None:
            forced = {
                "pytest": ["pytest", "-x", "--tb=short", "-q"],
                "npm": ["npm", "test", "--silent"],
                "cargo": ["cargo", "test", "--quiet"],
                "go": ["go", "test", "./..."],
                "make": ["make", "test"],
            }.get(runner_name)
            if not forced:
                return f"bilinmeyen test runner: {runner_name}"
            runner = TestRunner(name=runner_name, command=forced, config_file="(forced)", priority=99)
    result = _run_tests_impl(runner, ctx.cwd, timeout=timeout)
    return _truncate(result.summary, _MAX_OUT())


_COMMAND_ALTERNATIVES: dict[str, str] = {
    "nmap": "nmap kurulu değil. Alternatifler: `arp -a` (ARP tablosu), `dns-sd -B _services._dns-sd._udp local` (Bonjour/mDNS), `ping -c1 -W1 <ip>` ile sweep, `netstat -rn` (routing), `/usr/sbin/system_profiler SPNetworkDataType` (macOS network info).",
    "ifconfig": "ifconfig kurulu değil. Kullan: `ipconfig getifaddr en0` veya `networksetup -getinfo Wi-Fi`.",
    "netcat": "netcat/nc kurulu değil. Alternatifleri: `curl` veya `python3 -c 'import socket; ...'`.",
    "wget": "wget kurulu değil. Kullan: `curl -O <url>`.",
    "brew": "Homebrew (brew) kurulu değil. Kullanıcıya `brew install` öneremezsin; mevcut araçlarla çözüm bul.",
    "python": "python komutu bulunamadı. Kullan: `python3`.",
    "pip": "pip bulunamadı. Kullan: `pip3` veya `python3 -m pip`.",
    "apt": "apt kurulu değil (bu macOS). Homebrew (brew) veya mevcut macOS araçlarını kullan.",
    "apt-get": "apt-get kurulu değil (bu macOS). Homebrew (brew) veya mevcut macOS araçlarını kullan.",
    "systemctl": "systemctl kurulu değil (bu macOS). Kullan: `launchctl list` veya `launchctl start/stop`.",
    "lsb_release": "lsb_release kurulu değil (bu macOS). Kullan: `sw_vers` veya `uname -a`.",
    "docker": "docker kurulu değil veya çalışmıyor. Docker Desktop kurulu olup olmadığını kontrol et.",
    "kubectl": "kubectl kurulu değil. Kullanıcıya kubernetes araçlarını kurmalarını öner.",
    "ffmpeg": "ffmpeg kurulu değil. Kullanıcıdan `brew install ffmpeg` istemeden önce mevcut araçlarla çözüm bul.",
    "convert": "ImageMagick (convert) kurulu değil. Alternatif: `sips` (macOS built-in image processor).",
    "jq": "jq kurulu değil. Alternatif: `python3 -c 'import json,sys; d=json.load(sys.stdin); print(d[\"key\"])'`.",
    "tree": "tree kurulu değil. Alternatif: `find . -maxdepth 3 | head -50` veya `ls -R`.",
    "htop": "htop kurulu değil. Kullan: `top` (macOS built-in).",
    "nc": "nc/netcat bulunamadı. Alternatif: `curl` veya `python3 -c 'import socket; ...'`.",
    "telnet": "telnet kurulu değil. Kullan: `curl -v telnet://<host>:<port>` veya `nc`.",
    "traceroute": "traceroute bulunamadı. Kullan: `/usr/sbin/traceroute`.",
    "ping": "ping bulunamadı. Kullan: `/sbin/ping`.",
    "tcpdump": "tcpdump bulunamadı. Kullan: `/usr/sbin/tcpdump` (sudo gerekebilir).",
    "arp-scan": "arp-scan kurulu değil. Kullan: `arp -a` (mevcut ARP tablosunu göster).",
}


def _bash_failure_hint(command: str, output: str) -> str:
    """Return additional guidance appended to a failed bash result."""
    output_lower = output.lower()
    hints = []

    # find/grep exit with 1 on permission errors or no-match — not a real failure
    # when they produce output. Don't add a misleading "command failed" hint.
    cmd_first = command.strip().split()[0].lstrip("(").split("/")[-1]
    has_output = output.strip() not in {"", "(no output)"}
    if cmd_first in {"find", "grep", "egrep", "fgrep", "rg", "ag"} and has_output:
        return ""

    # Detect "command not found" for specific tools
    if "command not found" in output_lower or "not found" in output_lower:
        # Extract the failing command name (first word after last pipe/semicolon/newline)
        first_token = command.strip().split()[0] if command.strip() else ""
        # Scan output for the flagged command name.
        # zsh format: "zsh:1: command not found: nmap"
        # bash format: "bash: nmap: command not found"
        m = re.search(r"command not found:\s+(\S+)", output, re.IGNORECASE) or \
            re.search(r"(\S+):\s+command not found", output, re.IGNORECASE)
        flagged = m.group(1) if m else first_token
        if flagged in _COMMAND_ALTERNATIVES:
            hints.append(f"\n[HINT] {_COMMAND_ALTERNATIVES[flagged]}")
        else:
            hints.append(
                f"\n[HINT] '{flagged}' bu sistemde kurulu değil. "
                "Aynı komutu tekrar çalıştırma. Farklı bir araç veya platform-native alternatif kullan. "
                "Alternatif yoksa `final` ile kullanıcıya bildir."
            )

    # Generic non-zero guidance when not already hinted
    if not hints:
        hints.append(
            "\n[HINT] Komut başarısız oldu (exit_code!=0). "
            "Aynı komutu tekrar çalıştırma. Farklı argümanlar, farklı araç, ya da `final` kullan."
        )

    return "".join(hints)


async def _bash(action: dict[str, Any], ctx: "ToolContext") -> str:
    command = action["command"]
    normalized = command.strip().lower()
    if normalized in {"ip addr show", "ip address show", "ip a"}:
        return _macos_admin({"name": "list_network_interfaces"})
    if _dispatch_mode(ctx) == "review" and re.search(
        r"\b(sed\s+-i|perl\s+-i|mv|cp|rm|touch|mkdir|git\s+apply)\b", command
    ):
        raise RuntimeError("Mutating shell commands are disabled in review mode.")
    reason = _disallowed(command, ctx)
    if reason:
        raise RuntimeError(reason)
    lint_warnings = _lint(command)
    timeout = int(action.get("timeout", 120000)) / 1000.0
    _confirm(command, ctx)
    res = await ctx.runner.run_command(["/bin/zsh", "-lc", command], cwd=ctx.cwd, timeout=timeout)
    output = res.combined.strip() or "(no output)"
    if lint_warnings:
        output = "lint_warnings:\n- " + "\n- ".join(lint_warnings) + "\n\n" + output
    result = f"exit_code={res.exit_code}\n{_truncate(output, _MAX_OUT())}"
    if res.exit_code != 0:
        result += _bash_failure_hint(command, output)
    return result


async def _find_in_files(action: dict[str, Any], ctx: "ToolContext") -> str:
    pattern = str(action.get("pattern", "")).strip()
    path = str(action.get("path", ".")).strip()
    file_pattern = str(action.get("file_pattern", "")).strip()
    if not pattern:
        raise ValueError("find_in_files: pattern gerekli")
    target = _safe_path(path, ctx, write=False)
    rg_bin = _ensure_binary("rg")
    args = ["-n", "--hidden", "--no-heading"]
    if file_pattern:
        args += ["--glob", file_pattern]
    args += [pattern, str(target)]
    return await _run_security_cmd(rg_bin, args, ctx)


async def _git_tool(action: dict[str, Any], ctx: "ToolContext") -> str:
    op = str(action.get("op", "")).strip().lower()
    allowed_read = {"status", "log", "diff", "branch", "show"}
    allowed_write = {"add", "commit", "push", "checkout", "reset"}
    if op not in allowed_read | allowed_write:
        raise ValueError(f"git_tool: geçersiz op '{op}'. Geçerli: {sorted(allowed_read | allowed_write)}")
    if _dispatch_mode(ctx) == "review" and op in allowed_write:
        raise RuntimeError("git yazma işlemleri review modunda devre dışı.")
    cmd_map: dict[str, list[str]] = {
        "status": ["git", "status", "--short"],
        "log": ["git", "log", "--oneline", "-20"],
        "diff": ["git", "diff"],
        "branch": ["git", "branch", "-v"],
        "show": ["git", "show", "--stat"],
        "add": ["git", "add", action.get("paths", ".")],
        "commit": ["git", "commit", "-m", action.get("message", "mico commit")],
        "push": ["git", "push"],
        "checkout": ["git", "checkout", action.get("branch", "main")],
        "reset": ["git", "reset", "--soft", "HEAD~1"],
    }
    git_cmd = cmd_map[op]
    if isinstance(git_cmd[-1], list):
        git_cmd = git_cmd[:-1] + git_cmd[-1]
    res = await ctx.runner.run_command(git_cmd, cwd=ctx.cwd, timeout=30.0)
    output = res.combined.strip() or "(boş çıktı)"
    return f"exit_code={res.exit_code}\n{_truncate(output, _MAX_OUT())}"


async def _create_dir(action: dict[str, Any], ctx: "ToolContext") -> str:
    path = str(action.get("path", "")).strip()
    if not path:
        raise ValueError("create_dir: path gerekli")
    target = _safe_path(path, ctx, write=True)
    target.mkdir(parents=True, exist_ok=True)
    return f"Dizin oluşturuldu: {target}"


async def _move_file(action: dict[str, Any], ctx: "ToolContext") -> str:
    src = str(action.get("src", "")).strip()
    dst = str(action.get("dst", "")).strip()
    if not src or not dst:
        raise ValueError("move_file: src ve dst gerekli")
    if _dispatch_mode(ctx) == "review":
        raise RuntimeError("move_file review modunda devre dışı.")
    src_path = _safe_path(src, ctx, write=False)
    dst_path = _safe_path(dst, ctx, write=True)
    dst_path.parent.mkdir(parents=True, exist_ok=True)
    src_path.rename(dst_path)
    return f"Taşındı: {src_path} → {dst_path}"


async def _delete_file(action: dict[str, Any], ctx: "ToolContext") -> str:
    path = str(action.get("path", "")).strip()
    if not path:
        raise ValueError("delete_file: path gerekli")
    if _dispatch_mode(ctx) == "review":
        raise RuntimeError("delete_file review modunda devre dışı.")
    target = _safe_path(path, ctx, write=True)
    if not target.exists():
        return f"Dosya zaten yok: {target}"
    if target.is_dir():
        shutil.rmtree(target)
        return f"Dizin silindi: {target}"
    target.unlink()
    return f"Silindi: {target}"


async def _python_run(action: dict[str, Any], ctx: "ToolContext") -> str:
    code = str(action.get("code", "")).strip()
    if not code:
        raise ValueError("python_run: code gerekli")
    timeout = int(action.get("timeout", 30000)) / 1000.0
    _confirm(f"python_run: {code[:100]}", ctx)
    res = await ctx.runner.run_python(code, cwd=ctx.cwd, timeout=timeout)
    output = res.combined.strip() or "(no output)"
    return f"exit_code={res.exit_code}\n{_truncate(output, _MAX_OUT())}"


async def _rag_search(action: dict[str, Any], ctx: "ToolContext") -> str:
    query = str(action.get("query", "")).strip()
    if not query:
        raise ValueError("rag_search: query gerekli")
    n_results = int(action.get("n_results", 5))
    from .rag import get_rag
    rag = get_rag()
    results = rag.query(query, n_results=n_results)
    if not results:
        return "İlgili kod parçası bulunamadı."
    lines = []
    for res in results:
        path = res["metadata"].get("path", "?")
        line_start = res["metadata"].get("line_start", 0)
        lines.append(f"--- {path} (satır {line_start}) ---")
        lines.append(res["content"])
    return "\n".join(lines)


async def _env_info(action: dict[str, Any], ctx: "ToolContext") -> str:
    import platform
    keys = action.get("keys") or []
    lines = [
        f"platform: {platform.platform()}",
        f"python: {sys.version.split()[0]} @ {sys.executable}",
        f"cwd: {ctx.cwd}",
    ]
    if keys:
        for k in keys:
            lines.append(f"{k}={os.environ.get(str(k), '(tanımsız)')}")
    else:
        lines.append("(tüm env için keys listesi verin)")
    return "\n".join(lines)


async def _json_query(action: dict[str, Any], ctx: "ToolContext") -> str:
    path = str(action.get("path", "")).strip()
    query = str(action.get("query", "")).strip()
    if not path:
        raise ValueError("json_query: path gerekli")
    target = _safe_path(path, ctx, write=False)
    data = json.loads(_cached_read(target))
    if not query or query == ".":
        return _truncate(json.dumps(data, ensure_ascii=False, indent=2), _MAX_OUT())
    current = data
    for part in re.split(r"\.|(?=\[)", query.lstrip(".")):
        if not part:
            continue
        m = re.match(r"^\[(\d+)\]$", part)
        if m:
            current = current[int(m.group(1))]
        elif isinstance(current, dict):
            current = current[part]
        else:
            raise KeyError(f"json_query: '{part}' bulunamadı")
    return _truncate(json.dumps(current, ensure_ascii=False, indent=2), _MAX_OUT())


async def _macos_admin_tool(action: dict[str, Any], ctx: "ToolContext") -> str:
    return _macos_admin(action)


# ---------------------------------------------------------------------------
# Dispatch table
# ---------------------------------------------------------------------------

HANDLERS: dict[str, Any] = {
    "grep_code": _grep_code,
    "parse_json_file": _parse_json_file,
    "http_request": _http_request,
    "list_files": _list_files,
    "read_file": _read_file,
    "write_file": _write_file,
    "replace_in_file": _replace_in_file,
    "run_tests": _run_tests,
    "bash": _bash,
    "find_in_files": _find_in_files,
    "git_tool": _git_tool,
    "create_dir": _create_dir,
    "move_file": _move_file,
    "delete_file": _delete_file,
    "python_run": _python_run,
    "rag_search": _rag_search,
    "env_info": _env_info,
    "json_query": _json_query,
    "macos_admin_task": _macos_admin_tool,
}


async def dispatch(action: dict[str, Any], ctx: "ToolContext") -> str:
    """Ana giriş noktası — tool adına göre handler'ı çağırır."""
    tool = action.get("tool")
    handler = HANDLERS.get(str(tool or ""))
    if handler is None:
        raise ValueError(f"Desteklenmeyen tool: {tool}")
    return await _run_with_retry(handler, action, ctx)
