"""Secret redaction helpers for mico.

Provides ``redact_text`` (string in -> string with secrets masked) plus
``redact_dict``/``redact_json_safe`` for recursive structures bound for disk.
"""
from __future__ import annotations

import re
from typing import Any

# 5 MB ceiling: above this, the value is almost certainly binary or a giant
# blob, and the regex sweep is not worth the latency.
_MAX_REDACT_BYTES = 5 * 1024 * 1024

# Each entry: (label, compiled regex, replacement-callable-or-string).
# Order matters: the more specific patterns must run before the more
# permissive generic ones (e.g. private-key blocks before bearer/JWT).
_PATTERNS: list[tuple[str, "re.Pattern[str]", Any]] = [
    (
        "private_key",
        re.compile(
            r"-----BEGIN (?:RSA |EC |OPENSSH |DSA |PGP )?PRIVATE KEY-----[\s\S]*?-----END[^-]*-----"
        ),
        "[REDACTED:private_key]",
    ),
    (
        "aws_secret_access_key",
        re.compile(
            r"(?i)aws[_-]?secret[_-]?access[_-]?key[\"']?\s*[:=]\s*[\"']?[A-Za-z0-9/+=]{40}"
        ),
        "[REDACTED:aws_secret_access_key]",
    ),
    (
        "aws_access_key",
        re.compile(r"AKIA[0-9A-Z]{16}"),
        "[REDACTED:aws_access_key]",
    ),
    (
        "github_pat",
        re.compile(r"gh[pousr]_[A-Za-z0-9]{36,}"),
        "[REDACTED:github_pat]",
    ),
    (
        "slack_token",
        re.compile(r"xox[abprs]-[A-Za-z0-9-]{10,}"),
        "[REDACTED:slack_token]",
    ),
    (
        "anthropic_key",
        re.compile(r"sk-ant-[A-Za-z0-9_\-]{20,}"),
        "[REDACTED:anthropic_key]",
    ),
    (
        "openai_key",
        re.compile(r"sk-[A-Za-z0-9_\-]{20,}"),
        "[REDACTED:openai_key]",
    ),
    (
        "jwt",
        re.compile(r"eyJ[A-Za-z0-9_\-]{10,}\.[A-Za-z0-9_\-]{10,}\.[A-Za-z0-9_\-]{10,}"),
        "[REDACTED:jwt]",
    ),
    (
        "bearer",
        re.compile(r"(?i)bearer\s+[A-Za-z0-9._\-]{20,}"),
        lambda m: "Bearer [REDACTED:bearer_token]",
    ),
    (
        "env_secret",
        re.compile(
            r"(?im)^([A-Z0-9_]*(?:KEY|TOKEN|SECRET|PASSWORD|PASS|PWD)[A-Z0-9_]*)\s*=\s*(\S+)"
        ),
        lambda m: f"{m.group(1)}=[REDACTED:env_secret]",
    ),
]


def redact_text(s: str) -> str:
    """Return ``s`` with known secret patterns masked.

    Non-strings, empty values, and oversized blobs are returned unchanged.
    """
    if not isinstance(s, str) or not s:
        return s
    # Cheap byte-length check: skip clearly-binary or huge values.
    if len(s) > _MAX_REDACT_BYTES:
        return s
    out = s
    for _label, pattern, repl in _PATTERNS:
        out = pattern.sub(repl, out)
    return out


def redact_json_safe(value: Any) -> Any:
    """Recursively redact strings inside JSON-like structures.

    Dict keys are preserved verbatim; only values (and list/tuple items)
    are walked. Non-string scalars pass through untouched.
    """
    if isinstance(value, str):
        return redact_text(value)
    if isinstance(value, dict):
        return {k: redact_json_safe(v) for k, v in value.items()}
    if isinstance(value, list):
        return [redact_json_safe(v) for v in value]
    if isinstance(value, tuple):
        return tuple(redact_json_safe(v) for v in value)
    return value


def redact_dict(d: dict) -> dict:
    """Convenience wrapper for the common dict case."""
    if not isinstance(d, dict):
        return d
    return {k: redact_json_safe(v) for k, v in d.items()}
