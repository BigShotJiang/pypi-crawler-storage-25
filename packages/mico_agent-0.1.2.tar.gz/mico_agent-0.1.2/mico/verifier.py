"""Verifier logic for mico.

At regular intervals, mico asks a model to verify if the task is finished
or if there are obvious errors in the current plan/execution.
"""
from __future__ import annotations

import json
from typing import Any, Callable


def verifier_prompt(
    state: Any,
    history: list[dict[str, str]],
    step: int,
    *,
    build_task_state_prompt: Callable[[Any], str],
) -> list[dict[str, str]]:
    transcript_tail = history[-6:] if len(history) > 6 else history
    return [
        {
            "role": "system",
            "content": (
                "You are an objective verifier for a coding agent. "
                "Evaluate the current task state and recent transcript. "
                "Return exactly one JSON object: "
                '{"status": "ok" | "done" | "blocked" | "loop_risk", "reason": "...", "next_focus": "..."}. '
                "Do not mark done while a non-final phase is still active unless there is explicit evidence that the phase goal is already satisfied."
            ),
        },
        {
            "role": "user",
            "content": (
                f"step={step}\n\n"
                + build_task_state_prompt(state)
                + "\n\nrecent_transcript:\n"
                + json.dumps(transcript_tail, ensure_ascii=False)
            ),
        },
    ]


async def run_verifier(
    state: Any,
    history: list[dict[str, str]],
    step: int,
    *,
    prompt_builder: Callable[[Any, list[dict[str, str]], int], list[dict[str, str]]],
    call_model: Any,
    extract_json: Callable[[str], dict[str, Any]],
    thinking_budget: int,
    current_phase_entry: Callable[[Any], dict[str, Any]],
) -> dict[str, Any] | None:
    try:
        raw = await call_model(prompt_builder(state, history, step), thinking_budget=thinking_budget, stream=False, use_orchestra=False)
        data = extract_json(raw)
    except Exception:
        return None

    if not isinstance(data, dict):
        return None
    status = str(data.get("status", "ok")).strip().lower()
    if status not in ("ok", "done", "blocked", "loop_risk"):
        status = "ok"
    
    # If the verifier says done but the current phase is not finalize/answer, 
    # downgrade to ok unless it's a very simple task.
    if status == "done":
        phase = current_phase_entry(state)
        if str(phase.get("name")) not in ("finalize", "answer", "final"):
            status = "ok"

    return {
        "status": status,
        "reason": str(data.get("reason", "")).strip(),
        "next_focus": str(data.get("next_focus", "")).strip(),
        "done": status == "done",
    }
