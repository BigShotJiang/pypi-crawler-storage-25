from __future__ import annotations

from pathlib import Path
from typing import Any


def startup_note_paths(cwd: Path, global_startup_notes_path: Path, extra_notes_file: str = "") -> list[Path]:
    paths = [
        global_startup_notes_path,
        cwd / ".mico-startup.md",
        cwd / "mico.md",
        cwd / "QCODEX.md",
        cwd / "CLAUDE.md",
    ]
    extra = (extra_notes_file or "").strip()
    if extra:
        paths.append(Path(extra))
    return paths


def load_startup_notes(
    *,
    cwd: Path,
    global_startup_notes_path: Path,
    extra_notes_file: str,
    should_skip_minimal: bool,
    should_skip_memory_guard: bool,
    truncator: Any,
) -> str:
    if should_skip_minimal or should_skip_memory_guard:
        return ""
    parts: list[str] = []
    for path in startup_note_paths(cwd, global_startup_notes_path, extra_notes_file):
        if not path.exists() or not path.is_file():
            continue
        try:
            content = path.read_text().strip()
        except OSError:
            continue
        if content:
            parts.append(f"Startup notes from {path}:\n{content}")
    return truncator("\n\n".join(parts), 6000)


def is_inline_code_heavy_final(message: str) -> bool:
    text = (message or "").strip()
    if not text:
        return False
    # Triple-backtick fenced code blocks are always code-heavy
    if "```" in text:
        return True
    lines = text.splitlines()
    # More than 30 lines is suspicious for a final message
    if len(lines) >= 30:
        return True
    # Check for shell loop patterns and multi-line code
    if len(lines) >= 5:
        for ln in lines:
            s = ln.strip()
            # Shell loop patterns: while, for, do, if [ are strong signals
            if any(p in s for p in ("while ", "while true", "for ", "if [", "do\n", "; do")):
                return True
    # Check for long lines with shell metacharacters
    for ln in lines:
        if len(ln) > 80 and any(meta in ln for meta in ("|", "&&", ";", ">", "<")):
            return True
    # Count code-like lines
    codey = 0
    for ln in lines:
        s = ln.strip()
        if not s:
            continue
        # Extended keyword detection
        if s.startswith(("def ", "class ", "import ", "from ", "if ", "for ", "while ", "try:", "except ", "return ", "{", "}", "let ", "const ", "function ", "<?php", "package ", "#include")):
            codey += 1
            continue
        if s.endswith(("{", "}", ";")):
            codey += 1
    # Lower threshold for code detection
    return codey >= 5


def runtime_context_text(
    *,
    cwd: str,
    model_provider: str,
    model: str,
    offline: bool = False,
    network_access: bool = True,
    tool_install: bool,
    pentest_mode: bool,
    mode_display: str,
    profile: str,
    dry_run: bool,
    unattended: bool,
) -> str:
    return (
        "Runtime context:\n"
        "- OS: macOS (Darwin)\n"
        "- Architecture: arm64\n"
        f"- Working directory: {cwd}\n"
        f"- All file writes MUST use paths inside: {cwd}\n"
        "- Shell: zsh\n"
        f"- Model provider: {model_provider}\n"
        f"- Model: {model}\n"
        f"- Tool installation: {'on' if tool_install else 'off'}\n"
        f"- Pentest mode: {'on' if pentest_mode else 'off'}\n"
        f"- Mode: {mode_display}\n"
        f"- Profile: {profile}\n"
        f"- Dry run: {'on' if dry_run else 'off'}\n"
        f"- Unattended: {'on' if unattended else 'off'}\n"
        "- Behave like a coding agent, not a reconnaissance bot.\n"
        "- Prefer targeted reads over exploratory bash.\n"
        "- Special tools exist for local macOS admin tasks like listing interfaces, changing MAC, Wi-Fi power, DHCP renew, and DNS flush.\n"
        "- External downloads and package installs require explicit runtime enablement.\n"
        "- `tree` is NOT available on this system. Use `find . -maxdepth 2` or `ls -R` instead.\n"
    )


def compact_runtime_context_text(
    *,
    cwd: str,
    mode: str,
    profile: str,
    network_access: bool = True,
    tool_install: bool,
) -> str:
    return (
        "Runtime context:\n"
        f"- cwd: {cwd}\n"
        f"- mode: {mode}\n"
        f"- profile: {profile}\n"
        f"- tool_install: {'on' if tool_install else 'off'}\n"
        "- OS: macOS arm64\n"
    )
