from __future__ import annotations

import zipfile
from pathlib import Path
from typing import Any, Callable


def find_skill_by_name(name: str, *, discover_skills: Callable[[Any], list[Any]], ctx: Any) -> Any | None:
    target = name.strip().lower()
    for skill in discover_skills(ctx):
        if skill.name.lower() == target or skill.source.stem.lower() == target:
            return skill
    return None


def skill_archive_members(skill: Any) -> list[str]:
    try:
        if skill.source.suffix == ".skill":
            with zipfile.ZipFile(skill.source) as archive:
                return sorted(
                    member
                    for member in archive.namelist()
                    if not member.endswith("/") and not Path(member).name.startswith(".")
                )
        if skill.source.is_dir():
            return sorted(
                str(path.relative_to(skill.source))
                for path in skill.source.rglob("*")
                if path.is_file() and not path.name.startswith(".")
            )
    except Exception:
        return []
    return []


def read_skill_member(skill: Any, member: str) -> str:
    normalized = member.strip().lstrip("/")
    if not normalized:
        raise ValueError("reference path is required")
    if ".." in Path(normalized).parts:
        raise ValueError("reference path cannot contain ..")
    if skill.source.suffix == ".skill":
        with zipfile.ZipFile(skill.source) as archive:
            with archive.open(normalized) as handle:
                return handle.read().decode("utf-8", errors="replace")
    if skill.source.is_dir():
        target = (skill.source / normalized).resolve()
        if not target.is_file() or skill.source.resolve() not in target.parents:
            raise ValueError(f"reference not found: {normalized}")
        return target.read_text()
    raise ValueError("skill does not expose readable references")
