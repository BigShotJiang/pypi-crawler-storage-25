from __future__ import annotations

import os
import shlex
from pathlib import Path


def shell_join(parts: list[str]) -> str:
    return " ".join(shlex.quote(part) for part in parts)


def install_command_env() -> dict[str, str]:
    env = os.environ.copy()
    local_bin = str(Path.home() / ".local" / "bin")
    current_path = env.get("PATH", "")
    if local_bin not in current_path.split(":"):
        env["PATH"] = f"{local_bin}:{current_path}" if current_path else local_bin
    env.setdefault("GOBIN", local_bin)
    return env
