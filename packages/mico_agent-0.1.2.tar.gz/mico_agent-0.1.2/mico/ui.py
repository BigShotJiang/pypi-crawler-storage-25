"""mico TUI — sade, renkli, akıcı.

Claude CLI ve DeepCode benzeri estetik: tek bir welcome paneli, renk-kodlu log
satırları, akıcı stream çıktısı (full-screen TUI değil). Terminal scrollback
ve copy-paste native çalışır.
"""
from __future__ import annotations

import json
import os
import sys
from typing import Any, Callable

from rich.align import Align
from rich.console import Console, Group
from rich.panel import Panel
from rich.text import Text
from rich.theme import Theme

# ---------------------------------------------------------------------------
# Theme
# ---------------------------------------------------------------------------

MICO_THEME = Theme({
    # Brand
    "mico.brand":     "bold cyan",
    "mico.anchor":    "bright_cyan",
    "mico.tagline":   "italic dim white",
    "mico.hint":      "dim",
    "mico.kbd":       "bold yellow",
    "mico.divider":   "dim cyan",

    # Roles
    "mico.user":      "bold bright_cyan",
    "mico.assistant": "white",
    "mico.prompt":    "bold green",

    # Log categories
    "mico.step":      "bright_blue",
    "mico.model":     "magenta",
    "mico.tool":      "blue",
    "mico.memory":    "dim cyan",
    "mico.server":    "yellow",
    "mico.status":    "dim",
    "mico.diff.add":  "green",
    "mico.diff.del":  "red",
    "mico.error":     "bold red",
    "mico.warn":      "yellow",
    "mico.ok":        "green",
})


def _supports_color() -> bool:
    if not sys.stdout.isatty():
        return False
    if os.environ.get("NO_COLOR"):
        return False
    if os.environ.get("TERM") == "dumb":
        return False
    return True


# Single shared console for the session.
# Cap width at 120 — web terminals (ttyd/xterm.js) sometimes report huge COLUMNS
# values that cause the splash box and status bar to sprawl across the screen.
def _safe_console_width() -> int | None:
    import shutil as _shutil
    try:
        w = _shutil.get_terminal_size(fallback=(80, 24)).columns
        return min(w, 120) if w > 0 else None
    except Exception:
        return None

console: Console = Console(
    theme=MICO_THEME,
    highlight=False,
    soft_wrap=True,
    no_color=not _supports_color(),
    force_terminal=_supports_color(),
    width=_safe_console_width(),
)


# ---------------------------------------------------------------------------
# JSON Stream Filter — suppress JSON envelope, extract message
# ---------------------------------------------------------------------------

class JsonStreamFilter:
    """Buffer streaming output and suppress JSON action envelopes.

    When chunks arrive that form a complete JSON action like
    {"type":"final","message":"..."}, extract the message and suppress
    the envelope. Pre-JSON prose (model thinking/preamble before the first
    `{`) is routed to `on_monologue_text` instead of being passed through,
    so it never leaks to the visible output area.
    """
    def __init__(
        self,
        on_phase_change: Callable[[str], None] | None = None,
        on_monologue_text: Callable[[str], None] | None = None,
    ):
        self._buf: list[str] = []
        self._suppressing = False
        self._open_braces = 0
        self._in_string = False
        self._escape_next = False
        self.on_phase_change = on_phase_change
        self.on_monologue_text = on_monologue_text
        self.message_shown = False  # True if a final message was already streamed live
        self._prose_buf: list[str] = []  # accumulates all on_monologue_text chunks

    def feed(self, chunk: str) -> str:
        """Feed a chunk of streaming text. Returns visible text to print.

        Robust to leading garbage before `{` (some models emit boilerplate
        before the JSON action). Once `{` is seen, suppress until balanced.
        Pre-JSON prose is silently routed to on_monologue_text (if set) and
        never returned as visible output.
        """
        if not chunk:
            return ""

        # If we haven't entered JSON mode yet, scan for `{`
        if not self._suppressing:
            # Look for first `{` to start suppressing from
            brace_idx = chunk.find("{")
            if brace_idx == -1:
                # Pure prose before any JSON — route to monologue, not visible output
                self._prose_buf.append(chunk)
                if self.on_monologue_text:
                    self.on_monologue_text(chunk)
                return ""
            # There's a `{` somewhere — split: monologue prefix, suppress rest
            visible_prefix = chunk[:brace_idx]
            if visible_prefix:
                self._prose_buf.append(visible_prefix)
                if self.on_monologue_text:
                    self.on_monologue_text(visible_prefix)
            json_part = chunk[brace_idx:]
            self._suppressing = True
            self._open_braces = 0
            self._in_string = False
            self._escape_next = False
            # Recurse with the JSON portion
            tail = self.feed(json_part)
            return visible_prefix + tail

        # In JSON suppress mode: track brace balance
        out = ""
        for ch in chunk:
            self._buf.append(ch)

            if self._escape_next:
                self._escape_next = False
                continue
            if ch == "\\":
                self._escape_next = True
                continue
            if ch == '"':
                self._in_string = not self._in_string
                continue

            if not self._in_string:
                if ch == "{":
                    self._open_braces += 1
                elif ch == "}":
                    self._open_braces -= 1
                    if self._open_braces == 0:
                        # Complete JSON object
                        buf_str = "".join(self._buf).strip()
                        self._buf = []
                        self._suppressing = False
                        self._in_string = False
                        # Normalize bare \r (some streaming backends use it instead of space)
                        parseable = buf_str.replace("\r\n", "\n").replace("\r", " ")
                        try:
                            action = json.loads(parseable)
                            atype = action.get("type", "")
                            if atype == "final" and not self.message_shown:
                                msg = (action.get("message") or "").replace("\r\n", "\n").replace("\r", " ").strip()
                                if msg:
                                    if self.on_phase_change:
                                        self.on_phase_change("yazıyor")
                                    out += msg
                                    self.message_shown = True
                            # tool / patch / unknown / duplicate final: suppress
                        except json.JSONDecodeError:
                            pass  # suppress malformed JSON — don't dump raw to terminal
        return out

    def finalize(self) -> str:
        """Called at end of stream. Return any buffered text."""
        if not self._buf:
            return ""
        buf_str = "".join(self._buf).replace("\r\n", "\n").replace("\r", " ").strip()
        self._buf = []
        self._suppressing = False
        self._open_braces = 0
        # Try to extract message from incomplete/complete buffered JSON
        try:
            action = json.loads(buf_str)
            if action.get("type") == "final" and not self.message_shown:
                msg = (action.get("message") or "").strip()
                if msg:
                    self.message_shown = True
                    return msg
        except (json.JSONDecodeError, AttributeError):
            pass
        return "" if self.message_shown else buf_str

    def get_prose_fallback(self) -> str:
        """Return accumulated pre-JSON prose for use as fallback final message.

        Used when a model produces plain text without any JSON action envelope.
        Only returns a value when no JSON final message was received.
        """
        if self.message_shown:
            return ""
        return "".join(self._prose_buf).strip()


# ---------------------------------------------------------------------------
# Welcome banner
# ---------------------------------------------------------------------------

# Two compact ASCII-art banners. Use the wider one when terminal allows.
_LOGO_WIDE = r"""
        ⚓
   ╔╦╗╦╔═╗╔═╗
   ║║║║║  ║ ║
   ╩ ╩╩╚═╝╚═╝
""".strip("\n")

_LOGO_NARROW = r"""
   ⚓
  mico
""".strip("\n")


def _logo_text(width: int) -> Text:
    art = _LOGO_WIDE if width >= 60 else _LOGO_NARROW
    t = Text()
    for line in art.splitlines():
        if "⚓" in line:
            # Anchor in its own color, rest dim
            for ch in line:
                if ch == "⚓":
                    t.append(ch, style="mico.anchor")
                else:
                    t.append(ch, style="mico.brand")
        else:
            t.append(line, style="mico.brand")
        t.append("\n")
    return t


def _short_model_name(name: str, max_len: int) -> str:
    """Long model names → keep family + size + quant hint."""
    if len(name) <= max_len:
        return name
    # Take leading family token + look for size and quant tokens.
    import re
    size = re.search(r"(\d+(?:\.\d+)?)\s*[bB](?![a-zA-Z])", name)
    quant = re.search(r"(mxfp\d|q\d+|int\d+|\d+bit|\d+-bit|fp\d+|bf16)", name, re.I)
    head = re.split(r"[-_/.\s]", name, maxsplit=1)[0]
    parts = [head]
    if size:
        parts.append(size.group(1) + "B")
    if quant:
        parts.append(quant.group(1))
    short = " ".join(parts)
    return short if len(short) <= max_len else _truncate(name, max_len)


def render_welcome(*, model_name: str, profile_name: str, context_window: int,
                   workdir: str | None = None, version: str = "0.1.0") -> None:
    """Tek panel, üç bölüm: logo · meta · ipucu. Her satır panelin ortasına hizalı."""
    width = console.size.width
    panel_width = min(64, max(46, width - 4))

    logo_lines = _logo_text(panel_width).split("\n")
    logo_group = Group(*[Align.center(line) for line in logo_lines if line.plain])

    short = _short_model_name(model_name, panel_width - 14)

    line1 = Text()
    line1.append("local coding agent ", style="mico.tagline")
    line1.append("· ", style="mico.divider")
    line1.append(f"v{version}", style="mico.hint")

    line2 = Text()
    line2.append("model ", style="mico.hint")
    line2.append(short, style="bold")
    line2.append(" (lazy load)", style="mico.hint")

    line3 = Text()
    line3.append("profile ", style="mico.hint")
    line3.append(profile_name, style="mico.ok")
    line3.append("   ", style="mico.divider")
    line3.append("ctx ", style="mico.hint")
    line3.append(_human_tokens(context_window), style="bold")

    meta_lines = [Align.center(line1), Align.center(line2), Align.center(line3)]
    if workdir:
        line4 = Text()
        line4.append("dir ", style="mico.hint")
        line4.append(_compact_path(workdir), style="mico.tool")
        meta_lines.append(Align.center(line4))

    hint = Text()
    hint.append("/help", style="mico.kbd")
    hint.append(" yardım  ·  ", style="mico.hint")
    hint.append("ctrl+c", style="mico.kbd")
    hint.append(" iptal  ·  ", style="mico.hint")
    hint.append("ctrl+d", style="mico.kbd")
    hint.append(" çıkış", style="mico.hint")
    hint_block = Align.center(hint)

    body = Group(
        logo_group,
        Text(""),
        *meta_lines,
        Text(""),
        hint_block,
    )

    panel = Panel(
        body,
        border_style="mico.divider",
        padding=(1, 2),
        width=panel_width,
    )
    console.print()
    console.print(Align.center(panel))
    console.print()


# ---------------------------------------------------------------------------
# Log line renderer (replaces cli.py's render_log_line under USE_PLAIN_STDOUT)
# ---------------------------------------------------------------------------

_CATEGORY_STYLES = {
    "step":         "mico.step",
    "model":        "mico.model",
    "tool":         "mico.tool",
    "memory":       "mico.memory",
    "server":       "mico.server",
    "status":       "mico.status",
    "error":        "mico.error",
    "warn":         "mico.warn",
    "ok":           "mico.ok",
    "user":         "mico.user",
    "assistant":    "mico.assistant",
    "plan":         "mico.hint",
    "agent":        "mico.step",
    "narrate":      "mico.hint",
    "git":          "mico.tool",
    "triage":       "mico.hint",
}


_TOOL_LABEL_MAP = {
    # exploration tools → "Explored"
    "list_files": ("Explored", "bold white"),
    "read_file": ("Explored", "bold white"),
    "find_in_files": ("Explored", "bold white"),
    "grep_code": ("Explored", "bold white"),
    "parse_json_file": ("Explored", "bold white"),
    "json_query": ("Explored", "bold white"),
    "env_info": ("Explored", "bold white"),
    # execution tools → "Ran"
    "bash": ("Ran", "bold white"),
    "coding_tool": ("Ran", "bold white"),
    "macos_admin_task": ("Ran", "bold white"),
    "python_run": ("Ran", "bold white"),
    "run_tests": ("Ran", "bold white"),
    # git → "Git"
    "git_tool": ("Git", "bold white"),
    # edit tools → "Edited"
    "write_file": ("Edited", "bold white"),
    "replace_in_file": ("Edited", "bold white"),
    "create_dir": ("Edited", "bold white"),
    "move_file": ("Edited", "bold white"),
    "delete_file": ("Edited", "bold white"),
    "edit": ("Edited", "bold white"),
    # triage → "Evaluating"
    "triage": ("Evaluating", "bold yellow"),
}


def render_log(category: str, message: str) -> None:
    """Render a log line: ⏺ [Label] detail"""
    if category == "status":
        return
    if category == "model" and message in ("streaming response", "parsing action"):
        return

    t = Text()
    t.append("⏺ ", style="bold cyan")

    if category == "narrate":
        t.append(message or "Working", style="white")
        console.print(t)
        return

    if category in _TOOL_LABEL_MAP:
        label_text, label_style = _TOOL_LABEL_MAP[category]
        t.append(label_text, style=label_style)
        if message:
            t.append("  ", style="dim")
            t.append(message, style="white")
    else:
        style = _CATEGORY_STYLES.get(category, "mico.hint")
        t.append(message or category, style=style)

    console.print(t)


def render_activity(title: str, detail: str = "") -> None:
    """Render a high-level activity item like Codex/Claude progress logs.

    Example:
      ⏺ Explored
        └ Search foo in src
    """
    t = Text()
    t.append("⏺ ", style="bold cyan")
    t.append(title or "Working", style="bold white")
    if detail:
        t.append("\n  └ ", style="dim")
        t.append(detail, style="white")
    console.print(t)


def render_user(text: str) -> None:
    """Kullanıcı satırını (geçmişten replay sırasında) renkli yaz."""
    t = Text()
    t.append("❯ ", style="mico.prompt")
    t.append(text, style="mico.user")
    console.print(t)


def render_user_bubble(text: str) -> None:
    """Kullanıcı mesajını köşeli blok içinde göster — LLM çıktısından görsel ayrım sağlar."""
    color = _supports_color()
    if not color:
        sys.stdout.write(f"\n❯ {text}\n\n")
        sys.stdout.flush()
        return
    width = min(console.size.width, 120)
    label = " sen "
    bar = "─" * max(0, width - len(label) - 4)
    DIM  = "\033[2m"
    CYAN = "\033[96m"
    BOLD = "\033[1m"
    RST  = "\033[0m"
    sys.stdout.write(f"\n{DIM}{CYAN}╭─{label}{bar}╮{RST}\n")
    # Wrap long text
    import textwrap
    lines = textwrap.wrap(text, width - 4) or [text]
    for line in lines:
        sys.stdout.write(f"{DIM}{CYAN}│{RST} {BOLD}{line}{RST}\n")
    sys.stdout.write(f"{DIM}{CYAN}╰{'─' * (width - 2)}╯{RST}\n\n")
    sys.stdout.flush()


def render_assistant_header() -> None:
    """LLM yanıtı başlamadan önce 'mico' başlığı yaz."""
    color = _supports_color()
    if not color:
        sys.stdout.write("mico:\n")
        sys.stdout.flush()
        return
    width = min(console.size.width, 120)
    label = " mico "
    bar = "─" * max(0, width - len(label) - 4)
    DIM   = "\033[2m"
    WHITE = "\033[37m"
    RST   = "\033[0m"
    sys.stdout.write(f"{DIM}{WHITE}╭─{label}{bar}╮{RST}\n")
    sys.stdout.flush()


def render_error(message: str) -> None:
    t = Text()
    t.append("✗ ", style="mico.error")
    t.append(message, style="mico.error")
    console.print(t)


def render_separator() -> None:
    width = console.size.width
    console.print(Text("─" * width, style="mico.divider"))


# ---------------------------------------------------------------------------
# Stream raw text (model output) — keeps default terminal flow
# ---------------------------------------------------------------------------

_assistant_header_printed = False


def reset_assistant_header() -> None:
    """Her tur başında çağrılır — header bir kez basılsın diye."""
    global _assistant_header_printed
    _assistant_header_printed = False


def stream_text(text: str, *, end: str = "") -> None:
    global _assistant_header_printed
    if not text:
        return
    if not _assistant_header_printed:
        render_assistant_header()
        _assistant_header_printed = True
    # Normalize \r\n → \n and strip bare \r to prevent tokens overwriting each other
    # (rapid-mlx and mtplx SSE streams may use \r\n line endings)
    normalized = text.replace("\r\n", "\n").replace("\r", "")
    if not normalized:
        return
    sys.stdout.write(normalized)
    sys.stdout.flush()


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _truncate(s: str, n: int) -> str:
    return s if len(s) <= n else s[: n - 1] + "…"


def _human_tokens(n: int) -> str:
    if n >= 1024 and n % 1024 == 0:
        return f"{n // 1024}k"
    if n >= 1000:
        return f"{n / 1024:.1f}k"
    return str(n)


def _compact_path(path: str) -> str:
    home = os.path.expanduser("~")
    if path.startswith(home):
        return "~" + path[len(home):]
    return path


# ---------------------------------------------------------------------------
# Prompt style for prompt_toolkit input line
# ---------------------------------------------------------------------------

def prompt_fragments():
    """prompt_toolkit `prompt(...)` için renkli ❯ döner."""
    if _supports_color():
        return [("class:mico-prompt", "❯ ")]
    return [("", "❯ ")]


def prompt_toolkit_style():
    try:
        from prompt_toolkit.styles import Style
    except ImportError:
        return None
    return Style.from_dict({
        "mico-prompt":          "ansigreen bold",
        # Bottom toolbar base
        "bottom-toolbar":       "bg:#1c1c1c #6e7681",
        # Toolbar segments
        "tb.brand":             "bg:#1c1c1c #388bfd bold",
        "tb.sep":               "bg:#1c1c1c #30363d",
        "tb.label":             "bg:#1c1c1c #8b949e",
        "tb.model":             "bg:#1c1c1c #388bfd bold",
        "tb.mode":              "bg:#1c1c1c #8b949e",
        "tb.bar.filled":        "bg:#1c1c1c #388bfd",
        "tb.bar.empty":         "bg:#1c1c1c #30363d",
        "tb.pct":               "bg:#1c1c1c #6e7681",
        "tb.branch":            "bg:#1c1c1c #3fb950",
        "tb.net.on":            "bg:#1c1c1c #3fb950",
        "tb.net.off":           "bg:#1c1c1c #f85149",
        "tb.effort":            "bg:#1c1c1c #a371f7",
        "tb.toks.fast":         "bg:#1c1c1c #3fb950",
        "tb.toks.mid":          "bg:#1c1c1c #d29922",
        "tb.toks.slow":         "bg:#1c1c1c #f85149",
    })


# ---------------------------------------------------------------------------
# Tool and thinking renderers for Claude Code-style output
# ---------------------------------------------------------------------------

def render_tool_call(name: str, args_summary: str = "") -> None:
    """Render a tool invocation line in blue bold: ▸ tool_name(args)"""
    t = Text()
    t.append("▸ ", style="bold blue")
    t.append(f"{name}", style="bold blue")
    if args_summary:
        t.append(f"({args_summary})", style="blue")
    console.print(t)


def render_tool_output(text: str, *, max_lines: int = 20) -> None:
    """Render tool output: indented, dimmed, with fold message for long output.

    Args:
        text: The tool output text
        max_lines: Maximum lines to show before folding
    """
    if not text:
        return
    lines = text.split("\n")
    shown_lines = min(len(lines), max_lines)
    for line in lines[:shown_lines]:
        t = Text()
        t.append("  ", style="dim")
        t.append(line, style="dim")
        console.print(t)
    if len(lines) > max_lines:
        remaining = len(lines) - max_lines
        t = Text()
        t.append(f"  … {remaining} more lines (full output in logs)", style="dim")
        console.print(t)


_thinking_at_line_start: bool = True


def reset_thinking_line_state() -> None:
    global _thinking_at_line_start
    _thinking_at_line_start = True


def render_thinking(chunk: str) -> None:
    """Render thinking text: dim italic, indented, streamed inline.

    Tracks line position across calls so the 2-space indent is only added
    at the start of a line, not at every chunk boundary (which would cause
    spurious spaces when tokens are streamed mid-word).

    Uses stream_text() (which routes through the active output handle) rather
    than sys.stdout.write() directly, so prompt_toolkit TUI layout is not
    corrupted when the TUI is active.
    """
    global _thinking_at_line_start
    if not chunk:
        return
    color = _supports_color()
    DIM_IT = "\033[2;3m" if color else ""
    RST    = "\033[0m" if color else ""
    lines = chunk.split("\n")
    out = ""
    for i, line in enumerate(lines):
        is_last = i == len(lines) - 1
        if _thinking_at_line_start and line:
            out += f"  {DIM_IT}{line}{RST}"
        elif line:
            out += f"{DIM_IT}{line}{RST}"
        if not is_last:
            out += "\n"
            _thinking_at_line_start = True
        else:
            _thinking_at_line_start = not line
    if out:
        stream_text(out)


def render_turn_stamp(elapsed_sec: float, state: Any) -> None:
    """Print a compact one-line stamp after each turn response.

    Format:  ✓  0:23  │  12.3 tok/s  │  ctx 18%
    Printed directly to stdout so it lands right after the response text.
    """
    color = _supports_color()
    DIM  = "\033[2m" if color else ""
    RST  = "\033[0m" if color else ""
    SEP  = f"{DIM}  │  {RST}"

    from .spinner import _fmt_elapsed
    elapsed_str = _fmt_elapsed(elapsed_sec)

    parts: list[str] = [f"{DIM}✓  {elapsed_str}{RST}"]

    toks = getattr(state, "last_tokens_per_sec", 0.0) or 0.0
    if toks > 0:
        parts.append(f"{DIM}{toks:.1f} tok/s{RST}")

    ctx_window = getattr(state.profile, "context_window", 0) if state else 0
    used_chars = getattr(state, "history_chars_used", 0) or 0
    if ctx_window > 0:
        _, pct = _ctx_progress_bar(used_chars, ctx_window, width=0)
        parts.append(f"{DIM}ctx {pct}%{RST}")

    # Yanıt bloğunu kapat — header basıldıysa alt çizgi ekle
    if _assistant_header_printed:
        color2 = _supports_color()
        width2 = min(console.size.width, 120)
        DIM2  = "\033[2m"   if color2 else ""
        WHITE2= "\033[37m"  if color2 else ""
        RST2  = "\033[0m"   if color2 else ""
        sys.stdout.write(f"\n{DIM2}{WHITE2}╰{'─' * (width2 - 2)}╯{RST2}\n")
    sys.stdout.write(SEP.join(parts) + "\n\n")
    sys.stdout.flush()


def _ctx_progress_bar(used_chars: int, ctx_window_tokens: int, width: int = 12) -> tuple[str, int]:
    """Return (bar_text, percent_used). Estimate tokens as chars/4."""
    if ctx_window_tokens <= 0:
        return "·" * width, 0
    used_tokens = used_chars / 4
    raw_pct = 100 * used_tokens / ctx_window_tokens
    pct = max(0, min(100, int(raw_pct)))
    # Show <1 instead of 0 so non-empty history doesn't look like "unused"
    if pct == 0 and used_tokens > 0:
        pct = 1
    filled = int(width * pct / 100)
    bar = "█" * filled + "░" * (width - filled)
    return bar, pct


def _git_branch(cwd: str | None = None) -> str:
    """Return current git branch name or empty string."""
    import subprocess
    try:
        out = subprocess.run(
            ["git", "-C", cwd or os.getcwd(), "rev-parse", "--abbrev-ref", "HEAD"],
            capture_output=True, text=True, timeout=2,
        )
        if out.returncode == 0:
            return out.stdout.strip()
    except Exception:
        pass
    return ""


def _toolbar_sep() -> list[tuple[str, str]]:
    return [("class:tb.sep", "  │  ")]


def bottom_toolbar_fragments(state: Any) -> list[tuple[str, str]]:
    """Persistent bottom toolbar fragments (prompt_toolkit input prompt).

    Claude CLI style: brand │ model │ mode │ ██░░ 23% (6k/128k) │ ⎇ main │ net on │ eff:low │ 42.1 tok/s
    Uses styled (class, text) tuples for real prompt_toolkit colors.
    """
    try:
        model_short = _short_model_name(state.profile.model_name or "(no model)", max_len=20)
        ctx_window = state.profile.context_window or 0
    except Exception:
        model_short = "?"
        ctx_window = 0

    mode_text = state.mode or "auto"
    effort_raw = getattr(state, "effort", "low")
    effort_short = effort_raw[:3] if len(effort_raw) > 3 else effort_raw

    # Context bar
    used_chars = getattr(state, "history_chars_used", 0) or 0
    bar, pct = _ctx_progress_bar(used_chars, ctx_window, width=8)
    used_tokens_text = _human_tokens(int(used_chars / 4))
    ctx_total_text = _human_tokens(ctx_window)

    # tok/s — live (streaming) rate if available, else last completed turn
    toks = getattr(state, "live_tokens_per_sec", 0.0) or 0.0
    if toks <= 0:
        toks = getattr(state, "last_tokens_per_sec", 0.0) or 0.0

    # Git branch
    branch = _git_branch(getattr(state, "cwd", None))

    # Build fragment list
    frags: list[tuple[str, str]] = []

    # Brand
    frags.append(("class:tb.brand", " ⚓ mico"))
    frags += _toolbar_sep()

    # RAG Status
    try:
        from .rag import _RAG_INSTANCE
        rag_active = _RAG_INSTANCE is not None
        rag_style = "class:tb.net.on" if rag_active else "class:tb.hint"
        frags.append((rag_style, "RAG"))
        frags += _toolbar_sep()
    except Exception:
        pass

    # Model
    frags.append(("class:tb.model", model_short))
    frags += _toolbar_sep()

    # Mode
    frags.append(("class:tb.mode", mode_text))
    frags += _toolbar_sep()

    # Context bar — filled/empty blocks with styled colors
    filled = bar.count("█")
    empty = bar.count("░")
    frags.append(("class:tb.bar.filled", "█" * filled))
    frags.append(("class:tb.bar.empty", "░" * empty))
    frags.append(("class:tb.pct", f" {pct}% ({used_tokens_text}/{ctx_total_text})"))

    # Branch (optional)
    if branch:
        frags += _toolbar_sep()
        frags.append(("class:tb.branch", f"⎇ {branch}"))

    # Effort
    frags += _toolbar_sep()
    frags.append(("class:tb.effort", f"eff:{effort_short}"))

    # tok/s (optional — only after first turn with data)
    if toks > 0:
        frags += _toolbar_sep()
        if toks >= 25:
            tok_class = "class:tb.toks.fast"
        elif toks >= 8:
            tok_class = "class:tb.toks.mid"
        else:
            tok_class = "class:tb.toks.slow"
        frags.append((tok_class, f"{toks:.1f} tok/s"))

    frags.append(("class:bottom-toolbar", " "))
    return frags


def render_status_bar(state: Any) -> None:
    """Print ANSI-colored status bar after each turn (Claude CLI style).

    Mirrors the prompt_toolkit bottom toolbar but uses raw ANSI escape codes
    so it's visible during model output, not just at the input prompt.
    """
    if not _supports_color():
        return

    try:
        model_short = _short_model_name(state.profile.model_name or "?", max_len=20)
        ctx_window = state.profile.context_window or 0
    except Exception:
        model_short = "?"
        ctx_window = 0

    mode_text = state.mode or "auto"
    effort_raw = getattr(state, "effort", "low")
    effort_short = effort_raw[:3] if len(effort_raw) > 3 else effort_raw

    used_chars = getattr(state, "history_chars_used", 0) or 0
    bar, pct = _ctx_progress_bar(used_chars, ctx_window, width=8)
    used_tokens_text = _human_tokens(int(used_chars / 4))
    ctx_total_text = _human_tokens(ctx_window)

    toks = getattr(state, "last_tokens_per_sec", 0.0) or 0.0
    branch = _git_branch(getattr(state, "cwd", None))

    # ANSI color helpers — background dark (#1c1c1c ≈ 234), fg varies
    BG    = "\033[48;5;234m"
    RESET = "\033[0m"
    # Foreground colors
    BLUE  = "\033[38;5;75m"    # model, brand
    GRAY  = "\033[38;5;102m"   # mode, sep, pct
    DARK  = "\033[38;5;237m"   # separator │
    GREEN = "\033[38;5;71m"    # branch, net on, fast toks
    YELL  = "\033[38;5;179m"   # mid toks
    RED   = "\033[38;5;167m"   # net off, slow toks
    PURP  = "\033[38;5;140m"   # effort
    CYAN  = "\033[38;5;74m"    # bar filled

    def sep() -> str:
        return f"{BG}{DARK}  │  {RESET}"

    parts: list[str] = []
    parts.append(f"{BG}{BLUE} ⚓ mico{RESET}")
    parts.append(sep())
    parts.append(f"{BG}{BLUE}{model_short}{RESET}")
    parts.append(sep())
    parts.append(f"{BG}{GRAY}{mode_text}{RESET}")
    parts.append(sep())

    filled = bar.count("█")
    empty = bar.count("░")
    parts.append(f"{BG}{CYAN}{'█' * filled}{DARK}{'░' * empty}{GRAY} {pct}% ({used_tokens_text}/{ctx_total_text}){RESET}")

    if branch:
        parts.append(sep())
        parts.append(f"{BG}{GREEN}⎇ {branch}{RESET}")

    parts.append(sep())
    parts.append(f"{BG}{PURP}eff:{effort_short}{RESET}")

    if toks > 0:
        parts.append(sep())
        tok_color = GREEN if toks >= 25 else (YELL if toks >= 8 else RED)
        parts.append(f"{BG}{tok_color}{toks:.1f} tok/s{RESET}")

    parts.append(f"{BG} {RESET}")

    line = "".join(parts)
    sys.stdout.write("\n" + line + "\n")
    sys.stdout.flush()
