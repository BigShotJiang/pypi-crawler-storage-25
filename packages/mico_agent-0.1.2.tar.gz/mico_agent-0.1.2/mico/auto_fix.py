from __future__ import annotations

from typing import Any, Callable


async def run_auto_test_fix_loop(
    task: str,
    ctx: Any,
    session_id: str,
    state: Any,
    history: list[dict[str, str]],
    *,
    max_attempts: int,
    detect_primary_test_runner: Callable[[Any], Any],
    run_tests_impl: Callable[..., Any],
    save_task_state: Callable[[Any], None],
    should_continue_fix_loop: Callable[[Any], bool],
    git_diff_patch: Callable[[Any, int], str],
    collect_failure_file_context: Callable[[Any, Any, int], str],
    request_recovery_action: Any,
    apply_patch_pipeline: Callable[[str, Any], None],
    patch_error_type: type[Exception],
    truncator: Callable[[str, int], str],
    history_safe_text: Callable[[str], str],
    git_diff_summary: Callable[[Any], str],
    maybe_compact_history: Callable[[list[dict[str, str]], str], list[dict[str, str]]],
    save_session: Callable[[str, list[dict[str, str]]], None],
    cancel_requested: Callable[[], bool],
    stop_requested: Callable[[], bool],
    fix_loop_state_factory: Callable[..., Any],
) -> tuple[bool, str]:
    runner = detect_primary_test_runner(ctx.cwd)
    if runner is None:
        state.test_command = ""
        state.test_result = "no test runner detected"
        save_task_state(state)
        return (True, "No test runner detected.")
    loop_state = fix_loop_state_factory(
        attempts=state.test_attempts,
        max_attempts=max_attempts,
        last_summary=state.last_test_summary or None,
    )
    while True:
        if cancel_requested() or stop_requested():
            return (False, "Stopped before finishing auto test loop.")
        result = run_tests_impl(runner, ctx.cwd, timeout=180)
        state.test_command = " ".join(runner.command)
        state.test_result = result.summary
        state.last_test_summary = result.summary
        save_task_state(state)
        if result.exit_code == 0:
            return (True, result.summary)
        loop_state.attempts += 1
        state.test_attempts = loop_state.attempts
        save_task_state(state)
        if not should_continue_fix_loop(loop_state):
            return (False, result.summary)
        diff_text = git_diff_patch(ctx.cwd, 3500)
        excerpts = collect_failure_file_context(ctx.cwd, result)
        try:
            action, _raw = await request_recovery_action(
                task,
                ctx,
                state,
                "test_failed",
                details=result.summary,
                excerpts=excerpts,
                diff_text=diff_text,
                role="worker",
            )
        except Exception as exc:
            state.last_error = truncator(str(exc), 240)
            save_task_state(state)
            return (False, f"{result.summary}\nworker_fix_error: {exc}")
        if action.get("type") == "patch":
            diff = str(action.get("diff", "")).strip()
            if not diff:
                return (False, f"{result.summary}\nworker_fix_error: empty patch")
            try:
                apply_patch_pipeline(diff, ctx.cwd)
            except patch_error_type as patch_err:
                state.last_error = truncator(str(patch_err), 240)
                save_task_state(state)
                return (False, f"{result.summary}\npatch_fix_error: {patch_err}")
            history.append({"role": "user", "content": history_safe_text(f"auto_fix_patch_applied after failing tests\n{git_diff_summary(ctx.cwd)}")})
            history[:] = await maybe_compact_history(history, session_id)
            save_session(session_id, history)
            continue
        if action.get("type") == "final":
            return (False, f"{result.summary}\nreviewer_note: {action.get('message', '')}")
        return (False, f"{result.summary}\nworker_fix_error: unsupported action {action.get('type')}")
