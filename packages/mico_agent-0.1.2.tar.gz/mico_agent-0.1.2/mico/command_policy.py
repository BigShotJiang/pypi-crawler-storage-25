from __future__ import annotations

import ipaddress
import re
import shlex
import socket


def is_local_network_host(host: str) -> bool:
    normalized = host.strip().lower()
    if not normalized:
        return False
    if normalized.startswith("[") and normalized.endswith("]"):
        normalized = normalized[1:-1]
    if ":" in normalized and normalized.count(":") == 1:
        maybe_host, maybe_port = normalized.rsplit(":", 1)
        if maybe_port.isdigit():
            normalized = maybe_host
    if normalized in {"localhost"} or normalized.endswith(".local") or normalized.endswith(".localdomain"):
        return True
    try:
        ip = ipaddress.ip_address(normalized)
        return ip.is_loopback or ip.is_private or ip.is_link_local
    except ValueError:
        pass
    try:
        infos = socket.getaddrinfo(normalized, None)
    except socket.gaierror:
        return False
    for info in infos:
        try:
            ip = ipaddress.ip_address(info[4][0])
        except (ValueError, IndexError):
            continue
        if ip.is_loopback or ip.is_private or ip.is_link_local:
            return True
    return False


def command_targets_only_local_network(command: str) -> bool:
    hosts = [match.group(1) for match in re.finditer(r"https?://([^\s/\"'?#]+)", command)]
    if not hosts:
        try:
            parts = shlex.split(command)
        except ValueError:
            parts = command.split()
        if parts and parts[0] in {"curl", "wget"}:
            skip_next = False
            for part in parts[1:]:
                if skip_next:
                    skip_next = False
                    continue
                if part in {
                    "-o", "-O", "-A", "-H", "-d", "--data", "--data-raw", "--data-binary",
                    "-e", "--referer", "--interface", "--user-agent", "--header",
                    "--resolve", "--connect-to", "--proxy",
                }:
                    skip_next = True
                    continue
                if part.startswith("-"):
                    continue
                candidate = part
                if "://" not in candidate:
                    candidate = f"http://{candidate}"
                match = re.match(r"https?://([^\s/\"'?#]+)", candidate)
                if match:
                    hosts.append(match.group(1))
        if not hosts:
            return False
    return all(is_local_network_host(host) for host in hosts)


def lint_bash_command(command: str) -> list[str]:
    warnings: list[str] = []
    pipe_count = command.count("|")
    redirection_count = len(re.findall(r"<<|>>|[<>]", command))
    chained_ops = [op for op in ["&&", "||", ";"] if op in command]

    if pipe_count >= 2:
        warnings.append("contains a pipe; prefer a simpler typed tool when possible")
    if len(chained_ops) >= 2:
        warnings.append("contains chained shell operators; consider splitting into smaller steps")
    if redirection_count >= 2:
        warnings.append("contains shell redirection; verify this is necessary")
    if len(command) > 260:
        warnings.append("command is long; typed tools or coding_tool may be more reliable")
    return warnings


def dangerous_command(command: str) -> bool:
    patterns = [
        r"\brm\s+-rf\b",
        r"\bmkfs\b",
        r"\bshutdown\b",
        r"\breboot\b",
        r"\bdd\s+if=",
        r"\bgit\s+reset\s+--hard\b",
        r"\bgit\s+checkout\s+--\b",
        r"curl\s+.*\|\s*(sh|bash|zsh)",
    ]
    return any(re.search(p, command) for p in patterns)


CATASTROPHIC_COMMAND_PATTERNS: tuple[tuple[str, str], ...] = (
    (r"\bsu\s+-", "su is permanently disabled in mico."),
    (r"\bdoas\b", "doas privilege escalation is permanently disabled."),
    (r"\brm\s+-[rRfF]+[a-zA-Z]*\s+/(\s|$|\*|\.)", "Recursive delete on / is catastrophic and always blocked."),
    (r"\brm\s+-[rRfF]+[a-zA-Z]*\s+~(\s|$|/)", "Recursive delete on $HOME is catastrophic and always blocked."),
    (r"\brm\s+-[rRfF]+[a-zA-Z]*\s+\$HOME\b", "Recursive delete on $HOME is catastrophic and always blocked."),
    (r"\bmkfs\.", "Filesystem creation is catastrophic and always blocked."),
    (r"\bdd\b[^|;]*\bof=/dev/", "dd writing to a raw device is catastrophic and always blocked."),
    (r"\bwipefs\b", "wipefs is catastrophic and always blocked."),
    (r"\bshred\s+/(\s|$)", "shred on / is catastrophic and always blocked."),
    (r"\bshutdown\b", "shutdown is permanently disabled in mico."),
    (r"\breboot\b", "reboot is permanently disabled in mico."),
    (r"\bhalt\b", "halt is permanently disabled in mico."),
    (r"\bpoweroff\b", "poweroff is permanently disabled in mico."),
    (r"\bchmod\s+-R\s+\S+\s+/(\s|$)", "Recursive chmod on / is catastrophic and always blocked."),
    (r"\bchown\s+-R\s+\S+\s+/(\s|$)", "Recursive chown on / is catastrophic and always blocked."),
    (r"(curl|wget)\s+[^|]*\|\s*(sudo\s+)?(sh|bash|zsh|fish|ksh|tcsh)\b", "Remote-script-piped-to-shell is catastrophic and always blocked."),
    (r":\(\)\s*\{\s*:\s*\|\s*:&", "Fork bomb pattern is always blocked."),
    (r">+\s*/(etc|System|Library|bin|sbin|usr|private/etc)/", "Writes to system directories are always blocked."),
    (r"\bdiskutil\s+(eraseDisk|eraseVolume|secureErase|zeroDisk)\b", "Disk erase via diskutil is catastrophic and always blocked."),
    (r"\bcsrutil\s+disable\b", "Disabling SIP is always blocked."),
    (r"\bspctl\s+--master-disable\b", "Disabling Gatekeeper is always blocked."),
    (r"\bnvram\s+.*-c\b", "NVRAM clear is always blocked."),
)


def catastrophic_command_reason(command: str) -> str | None:
    for pattern, reason in CATASTROPHIC_COMMAND_PATTERNS:
        if re.search(pattern, command):
            return reason
    return None


COMMAND_ALLOWLIST_PATTERNS: tuple[str, ...] = (
    r"^\s*ls(\s|$)", r"^\s*pwd\s*$", r"^\s*cat\s+", r"^\s*head\s+", r"^\s*tail\s+",
    r"^\s*wc\s+", r"^\s*file\s+", r"^\s*stat\s+",
    r"^\s*grep\s+", r"^\s*rg\s+", r"^\s*find\s+\.", r"^\s*tree(\s|$)",
    r"^\s*sed\s+-n\s+", r"^\s*awk\s+",
    r"^\s*git\s+(status|diff|log|show|branch|remote|config\s+--get|rev-parse|ls-files|blame)\b",
    r"^\s*(python|python3|node|npm|pnpm|yarn|cargo|go|rustc|java|ruby|perl|php)\s+--version\b",
    r"^\s*which\s+",
    r"^\s*pytest(\s|$)", r"^\s*python(3)?\s+-m\s+pytest\b",
    r"^\s*python(3)?\s+-m\s+unittest\b",
    r"^\s*npm\s+(test|run\s+test)\b",
    r"^\s*yarn\s+(test|run\s+test)\b",
    r"^\s*pnpm\s+(test|run\s+test)\b",
    r"^\s*go\s+test\b",
    r"^\s*cargo\s+(test|check|build)\b",
    r"^\s*make\s+(test|check)\b",
    r"^\s*python(3)?\s+\S+\.py\b",
    r"^\s*node\s+\S+\.(js|mjs|cjs)\b",
    # Read-only network/system inspection — safe to allow without confirmation
    r"^\s*ipconfig\b",
    r"^\s*ifconfig\b",
    r"^\s*arp\b",
    r"^\s*ping\s+",
    r"^\s*netstat\b",
    r"^\s*route\b",
    r"^\s*networksetup\b",
    r"^\s*scutil\b",
    r"^\s*system_profiler\b",
    r"^\s*sw_vers\b",
    r"^\s*uname\b",
    r"^\s*hostname\b",
    r"^\s*id\b",
    r"^\s*whoami\b",
    r"^\s*env\b",
    r"^\s*printenv\b",
    r"^\s*echo\s+",
    r"^\s*date\b",
    r"^\s*uptime\b",
    r"^\s*df\b",
    r"^\s*du\s+",
    r"^\s*ps\b",
    r"^\s*top\s+-l\b",
    r"^\s*lsof\b",
    r"^\s*port\b",
    r"^\s*host\s+",
    r"^\s*dig\s+",
    r"^\s*nslookup\s+",
    r"^\s*curl\s+-[sI]",  # curl -s (silent) or -I (head-only) safe reads
    r"^\s*diff\b",
    r"^\s*sort\b",
    r"^\s*uniq\b",
)

COMMAND_ASK_PATTERNS: tuple[str, ...] = (
    r"\bgit\s+(add|commit|stash|tag)\b",
    r"\bgit\s+checkout\s+(?!--\s)",
    r"\bgit\s+merge\b", r"\bgit\s+rebase\b", r"\bgit\s+pull\b", r"\bgit\s+fetch\b",
    r"\b(pip|pip3|uv\s+pip|npm|pnpm|yarn|cargo|brew|gem)\s+install\b",
    r"\bdocker\s+(run|compose\s+up|build)\b",
    r"\bchmod\s+(?!-R)", r"\bmkdir\b", r"\btouch\b", r"\bmv\s+", r"\bcp\s+",
    r"\brm\s+(?!-rf?\s+/)", r"\bcurl\s+", r"\bwget\s+", r"\bgit\s+push\b",
)

# Hard deny regardless of any flag — catastrophic/destructive ops only.
COMMAND_DENY_PATTERNS: tuple[tuple[str, str], ...] = (
    (r"\bdocker\s+system\s+prune\b|\bdocker\s+volume\s+prune\b", "Docker prune is denied."),
    (r"\bnpm\s+install\s+-g\b|\bpnpm\s+add\s+-g\b|\byarn\s+global\s+add\b", "Global npm install is denied."),
    (r"\bpip\s+install\s+--user\b|\bpip3\s+install\s+--user\b", "User-site pip install — use venv instead."),
)


def classify_command(command: str) -> tuple[str, str]:
    for pat, reason in COMMAND_DENY_PATTERNS:
        if re.search(pat, command):
            return ("deny", reason)
    for pat in COMMAND_ASK_PATTERNS:
        if re.search(pat, command):
            return ("ask", "Side-effecting command — confirmation required.")
    for pat in COMMAND_ALLOWLIST_PATTERNS:
        if re.search(pat, command):
            return ("allow", "")
    return ("ask", "Unrecognised command — confirmation required.")


def command_uses_external_network(command: str) -> bool:
    if not re.search(r"\b(wget|curl|git\s+clone|ssh|scp|sftp|brew|pip|pip3|uv\s+pip|npm|pnpm|yarn|cargo)\b", command):
        return False
    return not command_targets_only_local_network(command)


def full_root_scan_reason() -> str:
    return (
        "Full-root filesystem scans are too broad for normal agent operation. "
        "Search a narrower location such as str(Path.home()), ~/.agent/skills, ~/.codex, "
        "the current working directory, or another task-specific path."
    )


def disallowed_command_reason(
    command: str,
    *,
    network_access: bool = True,
    tool_install: bool,
    permission_mode: str,
    unattended: bool,
) -> str | None:
    catastrophic = catastrophic_command_reason(command)
    if catastrophic:
        return catastrophic
    tier, tier_reason = classify_command(command)
    if tier == "deny":
        return tier_reason
    effective_mode = "yolo" if unattended else permission_mode
    if permission_mode in {"strict", "balanced", "yolo"} and permission_mode != "balanced":
        effective_mode = permission_mode
    if tier == "ask" and effective_mode == "strict":
        return f"Strict mode: {tier_reason}"
    checks = [
        (r"\bip\s+addr\b|\bip\s+route\b", "Linux network commands are not appropriate on macOS."),
        (r"\bapt(-get)?\b|\byum\b|\bdnf\b|\bpacman\b", "Linux package-manager commands are not appropriate on macOS."),
        (r"\bsystemctl\b|\bjournalctl\b|\bservice\b", "Linux service-management commands are not appropriate on macOS."),
        (r"/proc\b", "Direct /proc inspection is Linux-specific and not appropriate on macOS."),
        (r"\bsecurity\s+dump-keychain\b", "Broad keychain dumping is disallowed by default."),
        (r"\bifconfig\b.*\|\s*grep\b.*(en0|en1|awdl0|utun)", "Low-signal network interface probing is off-track unless the task is explicitly networking."),
    ]
    for pattern, reason in checks:
        if re.search(pattern, command):
            return reason
    if re.search(r"\bfind\s+/\s", command) or re.search(r"\bfind\s+/\s*$", command):
        return full_root_scan_reason()
    if re.search(r"\b(brew|pip|pip3|uv pip|npm|pnpm|yarn|cargo)\s+install\b", command) and not tool_install:
        return "Tool installation is disabled. Enable it with /tool-install on or --allow-tool-install."
    if re.search(r"\bgit\s+clone\b", command) and not tool_install:
        return "Remote repository cloning is disabled. Enable it with /tool-install on or --allow-tool-install."
    return None
