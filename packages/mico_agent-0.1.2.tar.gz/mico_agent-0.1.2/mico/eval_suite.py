from __future__ import annotations

import json
from pathlib import Path
from typing import Any, Callable


def default_eval_dataset_path(evals_dir: Path) -> Path:
    evals_dir.mkdir(parents=True, exist_ok=True)
    return evals_dir / "mico-regression.json"


def load_eval_cases(path: Path, evalcase_factory: Callable[..., Any]) -> list[Any]:
    data = json.loads(path.read_text())
    cases: list[Any] = []
    for item in data:
        cases.append(
            evalcase_factory(
                name=str(item.get("name", "")).strip(),
                kind=str(item.get("kind", "")).strip(),
                task=str(item.get("task", "")).strip(),
                expected=dict(item.get("expected", {})),
                options=dict(item.get("options", {})),
            )
        )
    return cases


def run_eval_suite(path: Path, *, loader: Callable[[Path], list[Any]], run_case: Callable[[Any], tuple[bool, str]]) -> str:
    cases = loader(path)
    passed = 0
    lines = ["Mico Eval Suite", f"dataset: {path}", f"cases: {len(cases)}"]
    for idx, case in enumerate(cases, start=1):
        ok, detail = run_case(case)
        if ok:
            passed += 1
        status = "PASS" if ok else "FAIL"
        lines.append(f"{idx:02d}. {status} {case.name} | {detail}")
    lines.append(f"summary: {passed}/{len(cases)} passed")
    return "\n".join(lines)


def eval_session_id(uuid4_hex: Callable[[], str]) -> str:
    return f"eval-{uuid4_hex()[:8]}"


def append_artifacts(state: Any, artifacts: list[dict[str, Any]] | None) -> None:
    for artifact in artifacts or []:
        state.artifacts.append(
            {
                "id": str(artifact.get("id", "")),
                "label": str(artifact.get("label", "")),
                "path": str(artifact.get("path", "")),
                "snippet": str(artifact.get("snippet", "")),
            }
        )


def activate_phase(state: Any, phase_name: str) -> None:
    phase_names = [str(p.get("name", "")) for p in state.phases]
    if phase_name not in phase_names:
        return
    pivot = phase_names.index(phase_name)
    state.current_phase = phase_name
    for idx, phase in enumerate(state.phases):
        name = str(phase.get("name", ""))
        if name == phase_name:
            phase["status"] = "active"
        elif idx < pivot:
            phase["status"] = "done"
