"""Uzun görev motoru — küçük LLM'lerin saatlerce kopmadan çalışabilmesi için.

Sorunlar çözülüyor:
  1. Context taşması   → otomatik compact + ledger inject
  2. Tekrar döngüsü   → action hash dedupe + plan yenileme
  3. Sonsuz döngü     → max_turns + wall_clock_timeout
  4. Bağlam kaybı     → ledger: todo/done/blocked her turn güncellenir
  5. Gözetim          → supervisor callback ile dışarıdan izleme

Kullanım:
    from mico.longrun import LongRunConfig, run_long_task
    cfg = LongRunConfig(goal="dosyaları düzenle ve testleri geçir", max_turns=40)
    result = await run_long_task(cfg)
    print(result.summary)
"""
from __future__ import annotations

import hashlib
import inspect
import json
import sys
import time
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any


# ---------------------------------------------------------------------------
# Veri yapıları
# ---------------------------------------------------------------------------

@dataclass
class LongRunConfig:
    goal: str
    max_turns: int = 60
    wall_clock_timeout: float = 3600.0   # saniye (default 1 saat)
    context_window: int = 8192
    compact_ratio: float = 0.70          # bu oran dolunca compact
    max_repeat_actions: int = 3          # aynı action N kez → plan yenile
    session_id: str = ""
    cwd: str = ""
    network_access: bool = True
    tool_install: bool = False
    approval: str = "auto"
    profile: str = "balanced"
    on_turn_end: Any = None              # supervisor callback
    mode: str = "loop"                  # "loop" | "plan_execute"
    initial_steps: list[str] = field(default_factory=list)  # triage'dan gelen adımlar
    turns_per_step: int = 12            # plan_execute: her adım için max tur


@dataclass
class LongRunState:
    goal: str
    turn: int = 0
    start_time: float = field(default_factory=time.time)
    todo: list[str] = field(default_factory=list)
    done: list[str] = field(default_factory=list)
    blocked: list[str] = field(default_factory=list)
    decisions: list[str] = field(default_factory=list)
    recent_action_hashes: list[str] = field(default_factory=list)
    repeat_count: int = 0
    compaction_count: int = 0
    final_message: str = ""
    exit_reason: str = ""        # "done"|"max_turns"|"timeout"|"repeat_limit"|"error"
    error: str = ""

    @property
    def elapsed(self) -> float:
        return time.time() - self.start_time

    @property
    def summary(self) -> str:
        lines = [
            f"Hedef: {self.goal}",
            f"Durum: {self.exit_reason}",
            f"Süre: {self.elapsed:.0f}s | {self.turn} tur | {self.compaction_count} compact",
        ]
        if self.done:
            lines.append("Tamamlananlar:\n" + "\n".join(f"  ✓ {d}" for d in self.done))
        if self.todo:
            lines.append("Kalan:\n" + "\n".join(f"  · {t}" for t in self.todo))
        if self.blocked:
            lines.append("Bloker:\n" + "\n".join(f"  ✗ {b}" for b in self.blocked))
        if self.final_message:
            lines.append(f"\nSon mesaj:\n{self.final_message}")
        if self.error:
            lines.append(f"\nHata:\n{self.error}")
        return "\n".join(lines)


# ---------------------------------------------------------------------------
# Ledger — görev defteri
# ---------------------------------------------------------------------------

LEDGER_PROMPT = """[LONGRUN LEDGER]
Görev: {goal}
Tur: {turn}/{max_turns} | Süre: {elapsed:.0f}s

Yapılacaklar:
{todo}

Tamamlananlar:
{done}

Blokerlar:
{blocked}

Kararlar:
{decisions}

Talimatlar:
- Tekrar etme. Zaten yapılanları tekrar yapma.
- Listedeki sıradaki yapılacağa odaklan.
- Bitince type=final döndür ve ledger'ı güncelle: "LEDGER_UPDATE: done=<madde>"
- Bloker varsa: type=final ile "LEDGER_BLOCKED: <neden>" döndür.
- Yeni adım keşfedersen: "LEDGER_TODO: <adım>" formatında final mesajına ekle.
"""


def _format_ledger(state: LongRunState, max_turns: int) -> str:
    def fmt(items: list[str]) -> str:
        return "\n".join(f"  - {x}" for x in items) if items else "  (boş)"
    return LEDGER_PROMPT.format(
        goal=state.goal,
        turn=state.turn,
        max_turns=max_turns,
        elapsed=state.elapsed,
        todo=fmt(state.todo),
        done=fmt(state.done),
        blocked=fmt(state.blocked),
        decisions=fmt(state.decisions[-6:]),
    )


def _parse_ledger_updates(message: str, state: LongRunState) -> None:
    """LLM'in final mesajından ledger güncellemelerini çıkar."""
    for line in message.splitlines():
        line = line.strip()
        if line.startswith("LEDGER_UPDATE: done="):
            item = line.split("done=", 1)[1].strip()
            if item and item not in state.done:
                state.done.append(item)
            state.todo = [t for t in state.todo if t != item]
        elif line.startswith("LEDGER_TODO:"):
            item = line.split("LEDGER_TODO:", 1)[1].strip()
            if item and item not in state.todo and item not in state.done:
                state.todo.append(item)
        elif line.startswith("LEDGER_BLOCKED:"):
            reason = line.split("LEDGER_BLOCKED:", 1)[1].strip()
            if reason and reason not in state.blocked:
                state.blocked.append(reason)
        elif line.startswith("LEDGER_DECISION:"):
            decision = line.split("LEDGER_DECISION:", 1)[1].strip()
            if decision and decision not in state.decisions:
                state.decisions.append(decision)


# ---------------------------------------------------------------------------
# Tekrar dedektörü
# ---------------------------------------------------------------------------

def _action_hash(action: dict[str, Any]) -> str:
    key = json.dumps({k: action.get(k) for k in sorted(action) if k != "timeout"}, sort_keys=True)
    return hashlib.md5(key.encode()).hexdigest()[:12]


def _detect_repeat(state: LongRunState, action_hash: str, max_repeat: int) -> bool:
    """Son N action aynıysa tekrar sayar ve limitde True döndürür."""
    state.recent_action_hashes.append(action_hash)
    if len(state.recent_action_hashes) > 10:
        state.recent_action_hashes.pop(0)
    tail = state.recent_action_hashes[-max_repeat:]
    if len(tail) == max_repeat and len(set(tail)) == 1:
        state.repeat_count += 1
        return True
    return False


# ---------------------------------------------------------------------------
# Compact
# ---------------------------------------------------------------------------

def _should_compact(history: list[dict[str, str]], config: LongRunConfig) -> bool:
    total = sum(len(str(m.get("content", ""))) for m in history)
    # chars → rough tokens (÷4), karşılaştır context_window ile
    approx_tokens = total / 4
    return approx_tokens >= config.context_window * config.compact_ratio


async def _compact_history(
    history: list[dict[str, str]],
    state: LongRunState,
    config: LongRunConfig,
    *,
    summarize_fn: Any,
    keep_tail: int = 12,
) -> list[dict[str, str]]:
    tail = history[-keep_tail:]
    prefix = history[:-keep_tail]
    try:
        summary = await summarize_fn(prefix)
    except Exception as exc:
        summary = f"(compact hatası: {exc})\nSon {keep_tail} mesaj korundu."
    state.compaction_count += 1
    compacted: list[dict[str, str]] = [
        {"role": "system", "content": "[COMPACTED SUMMARY]\n" + summary},
        {"role": "system", "content": _format_ledger(state, config.max_turns)},
        *tail,
    ]
    return compacted


# ---------------------------------------------------------------------------
# Ana motor
# ---------------------------------------------------------------------------

async def run_long_task(config: LongRunConfig) -> LongRunState:
    """Küçük LLM için uzun görev koşucu."""
    if config.mode == "plan_execute":
        return await _run_plan_execute(config)
    import mico.cli as _cli

    state = LongRunState(goal=config.goal)

    # İlk todo listesini hedeften türet (basit ilk adım)
    if not state.todo:
        state.todo.append(config.goal)

    cwd = Path(config.cwd) if config.cwd else Path.cwd()
    session_id = config.session_id or f"longrun-{int(time.time())}"

    ctx = _cli.ToolContext(
        cwd=cwd,
        approval=config.approval,
        force=False,
        mode="auto",
        narrate=False,
        dry_run=False,
        profile=config.profile,
        network_access=config.network_access,
        tool_install=config.tool_install,
        unattended=True,
        permission_mode="balanced",
        allowed_external_paths=[Path("/tmp")],
    )

    # Sistem prompt + ledger ile başlat
    history: list[dict[str, str]] = [
        {"role": "user", "content": _cli.runtime_context_text(ctx, effective_mode="auto")},
        {"role": "system", "content": _format_ledger(state, config.max_turns)},
        {"role": "user", "content": config.goal},
    ]

    _log(f"[longrun] başlatılıyor: {config.goal[:80]}")
    _log(f"[longrun] max_turns={config.max_turns} timeout={config.wall_clock_timeout:.0f}s")

    for turn in range(config.max_turns):
        state.turn = turn + 1

        # Wall clock timeout
        if state.elapsed > config.wall_clock_timeout:
            state.exit_reason = "timeout"
            _log(f"[longrun] zaman aşımı: {state.elapsed:.0f}s")
            break

        # Otomatik compact
        if _should_compact(history, config):
            _log(f"[longrun] compact #{state.compaction_count + 1} (tur {state.turn})")
            history = await _compact_history(
                history, state, config,
                summarize_fn=lambda h: _cli.summarize_history(h),
            )
            _cli.save_session(session_id, history)

        # Ledger inject — her turn'de taze ledger
        _inject_ledger(history, state, config)

        # Model çağrısı
        try:
            raw = await _cli.call_model(history, thinking_budget=0, stream=False, use_orchestra=False)
        except KeyboardInterrupt:
            state.exit_reason = "interrupted"
            _log("[longrun] kullanıcı tarafından durduruldu")
            break
        except Exception as exc:
            state.error = str(exc)
            state.exit_reason = "error"
            _log(f"[longrun] model hatası: {exc}")
            break

        # JSON parse
        try:
            action = _cli.extract_json(raw)
        except Exception:
            action = {"type": "final", "message": raw[:2000]}

        action_type = str(action.get("type", "")).strip()
        action_hash = _action_hash(action)

        # Tekrar dedektörü
        if action_type == "tool" and _detect_repeat(state, action_hash, config.max_repeat_actions):
            _log(f"[longrun] tekrar algılandı ({config.max_repeat_actions}x aynı action) — plan yenileniyor")
            state.blocked.append(f"Tekrar döngüsü: {action.get('tool', '?')} {str(action.get('command', action.get('path', '')))[:60]}")
            state.exit_reason = "repeat_limit"
            break

        # Tool çalıştır
        if action_type == "tool":
            tool_name = str(action.get("tool", ""))
            _log(f"[longrun] tur {state.turn}: tool={tool_name}")
            try:
                result = await _cli.run_tool(action, ctx)
            except Exception as exc:
                result = f"TOOL_ERROR: {exc}"
                _log(f"[longrun] tool hatası: {exc}")

            # History'e ekle
            history.append({"role": "assistant", "content": raw})
            history.append({"role": "user", "content": f"Tool result for {tool_name}:\n{result}"})
            _cli.save_session(session_id, history)

        elif action_type in ("final", "patch"):
            message = str(action.get("message", raw))
            state.final_message = message
            _parse_ledger_updates(message, state)
            _log(f"[longrun] final (tur {state.turn}): {message[:120]}")

            # Patch uygula
            if action_type == "patch":
                try:
                    patch_text = str(action.get("patch", action.get("content", "")))
                    import tempfile
                    with tempfile.NamedTemporaryFile("w", suffix=".patch", delete=False) as f:
                        f.write(patch_text)
                        pf = Path(f.name)
                    _cli.apply_patch_file(pf, ctx.cwd)
                    pf.unlink(missing_ok=True)
                    state.done.append(f"patch uygulandı (tur {state.turn})")
                except Exception as exc:
                    state.blocked.append(f"patch hatası: {exc}")

            # Tüm todo'lar bitti mi?
            if not state.todo or all(t in state.done for t in state.todo):
                state.exit_reason = "done"
                _log("[longrun] tüm görevler tamamlandı")
                history.append({"role": "assistant", "content": raw})
                _cli.save_session(session_id, history)
                break

            # Todo kaldıysa devam et — sonraki adımı sor
            next_todo = next((t for t in state.todo if t not in state.done), None)
            if next_todo:
                history.append({"role": "assistant", "content": raw})
                history.append({"role": "user", "content": f"Sonraki adım: {next_todo}"})
                _cli.save_session(session_id, history)
            else:
                state.exit_reason = "done"
                break

        else:
            # Bilinmeyen tip — final say
            state.final_message = raw[:500]
            state.exit_reason = "done"
            _log(f"[longrun] bilinmeyen action type: {action_type}")
            break

        # Supervisor callback
        if config.on_turn_end:
            try:
                if inspect.iscoroutinefunction(config.on_turn_end):
                    await config.on_turn_end(state)
                else:
                    config.on_turn_end(state)
            except Exception:
                pass

    else:
        state.exit_reason = "max_turns"
        _log(f"[longrun] max_turns ({config.max_turns}) aşıldı")

    _log(f"[longrun] bitti: {state.exit_reason} | {state.turn} tur | {state.elapsed:.0f}s")
    return state


# ---------------------------------------------------------------------------
# Yardımcılar
# ---------------------------------------------------------------------------

def _inject_ledger(
    history: list[dict[str, str]],
    state: LongRunState,
    config: LongRunConfig,
) -> None:
    """Önceki ledger mesajını çıkar, taze olanı ekle."""
    history[:] = [m for m in history if not str(m.get("content", "")).startswith("[LONGRUN LEDGER]")]
    # Son user mesajından önce inject et
    last_user = -1
    for i in range(len(history) - 1, -1, -1):
        if history[i].get("role") == "user":
            last_user = i
            break
    ledger_msg = {"role": "system", "content": _format_ledger(state, config.max_turns)}
    if last_user >= 0:
        history.insert(last_user, ledger_msg)
    else:
        history.append(ledger_msg)


def _log(msg: str) -> None:
    sys.stdout.write(msg + "\n")
    sys.stdout.flush()


# ---------------------------------------------------------------------------
# Plan-then-execute modu
# ---------------------------------------------------------------------------

_PLAN_SYSTEM = """Sen mico'nun görev planlayıcısısın.
Kullanıcının hedefini analiz et ve tam olarak şu JSON'u döndür, başka hiçbir şey yazma:

{
  "steps": ["adım1", "adım2", "adım3"]
}

Kurallar:
- Her adım bağımsız, tek seferde tamamlanabilir olmalı (araç çağrıları dahil).
- 3-8 adım arası üret. Daha fazla bölme.
- Adımlar sıralı ve birbirini izlemeli.
- Her adım bir fiille başlamalı: "Oku", "Yaz", "Düzelt", "Test et", "Doğrula".
- JSON dışında hiçbir şey yazma.
"""


async def _plan_phase(goal: str, _cli: Any) -> list[str]:
    """Model'e sadece plan ürettir, araç kullandırmaz."""
    messages = [
        {"role": "system", "content": _PLAN_SYSTEM},
        {"role": "user", "content": f"Hedef:\n{goal}"},
    ]
    try:
        raw = await _cli.call_model(messages, thinking_budget=0, stream=False, use_orchestra=False)
        raw = raw.strip()
        import re as _re
        m = _re.search(r"\{[\s\S]+\}", raw)
        if not m:
            return [goal]
        data = json.loads(m.group(0))
        steps = [str(s).strip() for s in data.get("steps", []) if str(s).strip()]
        return steps if steps else [goal]
    except Exception:
        return [goal]


async def _run_single_step(
    step: str,
    step_idx: int,
    total_steps: int,
    prior_summary: str,
    config: LongRunConfig,
    session_id: str,
    _cli: Any,
) -> tuple[str, bool]:
    """Tek bir adımı çalıştır. (özet, başarılı_mı) döndürür."""
    cwd = Path(config.cwd) if config.cwd else Path.cwd()
    ctx = _cli.ToolContext(
        cwd=cwd,
        approval=config.approval,
        force=False,
        mode="auto",
        narrate=False,
        dry_run=False,
        profile=config.profile,
        network_access=config.network_access,
        tool_install=config.tool_install,
        unattended=True,
        permission_mode="balanced",
        allowed_external_paths=[Path("/tmp")],
    )

    # Her adım için temiz history — sadece prior summary taşınır
    history: list[dict[str, str]] = []
    if prior_summary:
        history.append({"role": "system", "content": f"[ÖNCEKİ ADIMLAR ÖZETİ]\n{prior_summary}"})
    history.append({
        "role": "user",
        "content": (
            f"Adım {step_idx + 1}/{total_steps}: {step}\n\n"
            f"Genel hedef: {config.goal}\n\n"
            f"Bu adımı tamamla. Bitince type=final döndür."
        ),
    })

    step_cfg = LongRunConfig(
        goal=step,
        max_turns=config.turns_per_step,
        wall_clock_timeout=min(config.wall_clock_timeout, 600.0),
        context_window=config.context_window,
        compact_ratio=config.compact_ratio,
        max_repeat_actions=config.max_repeat_actions,
        session_id=f"{session_id}-step{step_idx}",
        cwd=config.cwd,
        network_access=config.network_access,
        tool_install=config.tool_install,
        approval=config.approval,
        profile=config.profile,
        mode="loop",
    )

    # loop modunda ama önceden oluşturulmuş history ile başlat
    state = LongRunState(goal=step)
    state.todo.append(step)

    _log(f"[plan_execute] adım {step_idx + 1}/{total_steps}: {step[:70]}")

    for turn in range(step_cfg.max_turns):
        state.turn = turn + 1

        if state.elapsed > step_cfg.wall_clock_timeout:
            state.exit_reason = "timeout"
            break

        if _should_compact(history, step_cfg):
            history = await _compact_history(
                history, state, step_cfg,
                summarize_fn=lambda h: _cli.summarize_history(h),
            )

        _inject_ledger(history, state, step_cfg)

        try:
            raw = await _cli.call_model(history, thinking_budget=0, stream=False, use_orchestra=False)
        except Exception as exc:
            state.error = str(exc)
            state.exit_reason = "error"
            break

        try:
            action = _cli.extract_json(raw)
        except Exception:
            action = {"type": "final", "message": raw[:2000]}

        action_type = str(action.get("type", "")).strip()
        ahash = _action_hash(action)

        if action_type == "tool" and _detect_repeat(state, ahash, step_cfg.max_repeat_actions):
            state.exit_reason = "repeat_limit"
            state.blocked.append(f"Tekrar: {action.get('tool')} {str(action.get('command', ''))[:40]}")
            break

        if action_type == "tool":
            try:
                result = await _cli.run_tool(action, ctx)
            except Exception as exc:
                result = f"TOOL_ERROR: {exc}"
            history.append({"role": "assistant", "content": raw})
            history.append({"role": "user", "content": f"Tool result for {action.get('tool', '?')}:\n{result}"})
        elif action_type in ("final", "patch"):
            message = str(action.get("message", raw))
            state.final_message = message
            _parse_ledger_updates(message, state)
            state.exit_reason = "done"
            history.append({"role": "assistant", "content": raw})
            break
        else:
            state.final_message = raw[:500]
            state.exit_reason = "done"
            break
    else:
        state.exit_reason = "max_turns"

    # Bu adımın özetini üret (bir sonraki adıma taşınacak)
    summary_parts = [f"Adım {step_idx + 1}: {step}"]
    if state.final_message:
        summary_parts.append(state.final_message[:400])
    if state.done:
        summary_parts.append("Tamamlananlar: " + ", ".join(state.done[:5]))
    if state.blocked:
        summary_parts.append("Blokerlar: " + ", ".join(state.blocked[:3]))
    summary_parts.append(f"Durum: {state.exit_reason}")
    step_summary = "\n".join(summary_parts)

    success = state.exit_reason in ("done",)
    return step_summary, success


async def _run_plan_execute(config: LongRunConfig) -> LongRunState:
    """Plan-then-execute modu: önce planla, sonra her adımı ayrı context'te koş."""
    import mico.cli as _cli

    state = LongRunState(goal=config.goal)
    session_id = config.session_id or f"pe-{int(time.time())}"

    # --- Planlama fazı ---
    if config.initial_steps:
        steps = list(config.initial_steps)
        _log(f"[plan_execute] triage'dan {len(steps)} adım alındı")
    else:
        _log("[plan_execute] planlama fazı başlıyor...")
        steps = await _plan_phase(config.goal, _cli)
        _log(f"[plan_execute] {len(steps)} adım üretildi")

    state.todo = list(steps)
    for s in steps:
        _log(f"[plan_execute]   · {s}")

    # --- Yürütme fazı ---
    prior_summary = ""
    all_summaries: list[str] = []

    for idx, step in enumerate(steps):
        if state.elapsed > config.wall_clock_timeout:
            state.exit_reason = "timeout"
            _log(f"[plan_execute] zaman aşımı toplam {state.elapsed:.0f}s")
            break

        step_summary, ok = await _run_single_step(
            step=step,
            step_idx=idx,
            total_steps=len(steps),
            prior_summary=prior_summary,
            config=config,
            session_id=session_id,
            _cli=_cli,
        )

        all_summaries.append(step_summary)
        # Bir sonraki adıma taşınan özet: son 2 adımın özeti (context baskısını sınırla)
        prior_summary = "\n\n---\n\n".join(all_summaries[-2:])

        state.todo = [s for s in state.todo if s != step]
        if ok:
            state.done.append(step)
        else:
            state.blocked.append(f"{step} (başarısız)")

        _log(f"[plan_execute] adım {idx + 1}/{len(steps)} {'✓' if ok else '✗'}: {step[:60]}")

        if config.on_turn_end:
            try:
                if inspect.iscoroutinefunction(config.on_turn_end):
                    await config.on_turn_end(state)
                else:
                    config.on_turn_end(state)
            except Exception:
                pass

    if state.exit_reason not in ("timeout", "error"):
        state.exit_reason = "done" if not state.todo else "partial"

    state.final_message = "\n\n".join(all_summaries[-3:]) if all_summaries else ""
    _log(f"[plan_execute] bitti: {state.exit_reason} | {len(state.done)}/{len(steps)} adım")
    return state


# ---------------------------------------------------------------------------
# CLI entegrasyonu — /longrun slash komutu için
# ---------------------------------------------------------------------------

async def longrun_from_slash(
    goal: str,
    *,
    max_turns: int = 60,
    timeout: float = 3600.0,
    cwd: str = "",
    on_turn_end: Any = None,
) -> LongRunState:
    """Slash komutundan veya test'ten çağırılacak basit arayüz."""
    cfg = LongRunConfig(
        goal=goal,
        max_turns=max_turns,
        wall_clock_timeout=timeout,
        cwd=cwd,
        on_turn_end=on_turn_end,
    )
    return await run_long_task(cfg)
