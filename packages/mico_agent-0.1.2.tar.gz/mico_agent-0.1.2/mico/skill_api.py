from __future__ import annotations

import abc
from typing import Callable, Awaitable


class ActiveSkill(abc.ABC):
    """Base class for active skills that can provide tools and hooks."""
    
    @property
    @abc.abstractmethod
    def name(self) -> str:
        """Name of the skill."""
        pass

    @property
    @abc.abstractmethod
    def description(self) -> str:
        """Description of what the skill does."""
        pass

    @abc.abstractmethod
    def get_tools(self) -> dict[str, Callable[..., Awaitable[str]]]:
        """Return a mapping of tool names to their implementation."""
        pass

    def get_system_prompt_extension(self) -> str:
        """Return text to be appended to the system prompt when skill is active."""
        return ""


class SkillRegistry:
    def __init__(self):
        self._skills: dict[str, ActiveSkill] = {}

    def register(self, skill: ActiveSkill):
        self._skills[skill.name] = skill

    def get_skill(self, name: str) -> ActiveSkill | None:
        return self._skills.get(name)

    def list_skills(self) -> list[ActiveSkill]:
        return list(self._skills.values())


_REGISTRY = SkillRegistry()

def get_skill_registry() -> SkillRegistry:
    return _REGISTRY
