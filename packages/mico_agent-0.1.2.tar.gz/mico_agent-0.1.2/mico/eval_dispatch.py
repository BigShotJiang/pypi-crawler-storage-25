from __future__ import annotations

from typing import Any, Callable


def run_eval_case_with_dispatch(
    case: Any,
    *,
    handlers: dict[str, Callable[[Any], tuple[bool, str]]],
) -> tuple[bool, str]:
    handler = handlers.get(str(getattr(case, "kind", "")))
    if handler is None:
        return (False, f"unsupported eval kind: {getattr(case, 'kind', '')}")
    return handler(case)
