from __future__ import annotations


def speculative_draft_active(model_provider: str, draft_model: str | None) -> bool:
    return model_provider == "mlx" and bool(draft_model)


def draft_mode_name(draft_model: str | None) -> str:
    lowered = (draft_model or "").lower()
    if "assistant" in lowered:
        return "assistant"
    if "dflash" in lowered:
        return "dflash"
    return ""
