"""İlk açılış sihirbazı + her-açılış model seçim ekranı.

Akış:
  İlk açılış (setup-complete yok):
    1. Welcome banner
    2. Donanım tespiti
    3. Sistem geneli model taraması
    4. Model seçimi
    5. Draft model seçimi (varsa)
    6. Profil önerisi + onay
    7. ~/.mico/setup-complete dokunulur

  Sonraki açılışlar:
    Her açılışta model seçim ekranı gösterilir (hızlı, setup yok).
    Kullanıcı Enter ile son modeli kabul edebilir, ya da farklı seçebilir.
    Draft seçimi varsa gösterilir.
"""
from __future__ import annotations

import os
import sys
from pathlib import Path

from . import hardware as hw_mod
from . import model_recommender as mr

CONFIG_DIR = Path(os.environ.get("MICO_HOME", str(Path.home() / ".mico")))
SETUP_FLAG = CONFIG_DIR / "setup-complete"
LAST_MODEL_FILE = CONFIG_DIR / "last_model.txt"


# ---------------------------------------------------------------------------
# Banner
# ---------------------------------------------------------------------------

BANNER = r"""
                          ⚓
                      ┏━━━━━━━━┓
                      ┃  mico  ┃
                      ┗━━━━━━━━┛
              local coding agent · Apache-2.0
"""


def print_banner() -> None:
    sys.stdout.write(BANNER + "\n")
    sys.stdout.flush()


# ---------------------------------------------------------------------------
# Prompt helpers
# ---------------------------------------------------------------------------

def ask(question: str, default: str = "") -> str:
    suffix = f" [{default}]" if default else ""
    sys.stdout.write(f"{question}{suffix}: ")
    sys.stdout.flush()
    try:
        ans = input().strip()
    except (EOFError, KeyboardInterrupt):
        sys.stdout.write("\n")
        return default
    return ans or default


def confirm(question: str, default: bool = True) -> bool:
    hint = "[Y/n]" if default else "[y/N]"
    sys.stdout.write(f"{question} {hint}: ")
    sys.stdout.flush()
    try:
        ans = input().strip().lower()
    except (EOFError, KeyboardInterrupt):
        sys.stdout.write("\n")
        return default
    if not ans:
        return default
    return ans.startswith("y") or ans in {"e", "evet"}


def choose(question: str, options: list[str], default_idx: int = 0) -> int:
    """Interactive menu with arrow-key navigation. Falls back to number input if no TTY."""
    if not options:
        return 0

    # Arrow-key menu via prompt_toolkit (requires TTY)
    try:
        import sys as _sys
        if _sys.stdin.isatty() and _sys.stdout.isatty():
            return _choose_arrow(question, options, default_idx)
    except Exception:
        pass

    # Fallback: plain number input
    if question:
        sys.stdout.write(question + "\n")
    for idx, opt in enumerate(options, 1):
        marker = "→" if (idx - 1) == default_idx else " "
        sys.stdout.write(f"  {marker} {idx}. {opt}\n")
    sys.stdout.write(f"Seçim [1-{len(options)}, Enter={default_idx + 1}]: ")
    sys.stdout.flush()
    try:
        ans = input().strip()
    except (EOFError, KeyboardInterrupt):
        sys.stdout.write("\n")
        return default_idx
    if not ans:
        return default_idx
    try:
        i = int(ans) - 1
        if 0 <= i < len(options):
            return i
    except ValueError:
        pass
    return default_idx


def _choose_arrow(question: str, options: list[str], default_idx: int = 0) -> int:
    """Arrow-key driven selection using termios raw mode."""
    import termios
    import tty
    import shutil

    n = len(options)
    sel = default_idx
    cols = shutil.get_terminal_size((80, 24)).columns

    HIDE  = "\033[?25l"
    SHOW  = "\033[?25h"
    CYAN  = "\033[96;1m"
    RESET = "\033[0m"
    DIM   = "\033[2m"

    def _truncate(s: str) -> str:
        return s if len(s) <= cols - 6 else s[: cols - 7] + "…"

    # lines_written: every \n counts. We track exactly how many \n we emit
    # so _go_to_top() can move cursor back precisely.
    def _render(final: bool = False) -> str:
        """Build the full menu string. final=True omits footer."""
        out = []
        if question:
            out.append(f"\033[2K\r{question}\n")
        for i, opt in enumerate(options):
            label = _truncate(opt)
            if i == sel:
                out.append(f"\033[2K\r  {CYAN}❯ {label}{RESET}\n")
            else:
                out.append(f"\033[2K\r    {label}\n")
        if not final:
            out.append(f"\033[2K\r{DIM}  ↑↓/jk · Enter · q iptal{RESET}")
        return "".join(out)

    header_lines = 1 if question else 0
    # Total \n chars emitted by _render(final=False):
    # header + n options + footer has no \n → move up header+n lines to reach top
    lines_above_cursor = header_lines + n  # footer line has no trailing \n

    def _go_to_top() -> None:
        if lines_above_cursor > 0:
            sys.stdout.write(f"\033[{lines_above_cursor}A")

    fd = sys.stdin.fileno()
    old = termios.tcgetattr(fd)
    sys.stdout.write(HIDE)
    sys.stdout.write(_render())
    sys.stdout.flush()

    cancelled = False
    try:
        tty.setraw(fd)
        while True:
            ch = sys.stdin.read(1)
            if ch in ("\r", "\n"):
                break
            if ch == "\x03":  # Ctrl+C
                cancelled = True
                break
            if ch == "\x1b":
                nxt = sys.stdin.read(1)
                if nxt == "[":
                    arrow = sys.stdin.read(1)
                    if arrow == "A":
                        sel = (sel - 1) % n
                    elif arrow == "B":
                        sel = (sel + 1) % n
                    else:
                        continue
                else:
                    # bare ESC → cancel
                    cancelled = True
                    break
            elif ch in ("q", "Q"):
                cancelled = True
                break
            elif ch == "k":
                sel = (sel - 1) % n
            elif ch == "j":
                sel = (sel + 1) % n
            elif ch.isdigit():
                d = int(ch) - 1
                if 0 <= d < n:
                    sel = d
                    break
                continue
            else:
                continue
            _go_to_top()
            sys.stdout.write(_render())
            sys.stdout.flush()
    finally:
        termios.tcsetattr(fd, termios.TCSADRAIN, old)

    # Move to top, redraw without footer, leave cursor on next line
    _go_to_top()
    sys.stdout.write(_render(final=True))
    sys.stdout.write("\033[2K\r")  # clear footer line
    sys.stdout.write(SHOW)
    sys.stdout.flush()

    if cancelled:
        raise KeyboardInterrupt
    return sel


# ---------------------------------------------------------------------------
# Model label for display
# ---------------------------------------------------------------------------

def _model_label(e: mr.ModelEntry) -> str:
    params = f"{e.params_b}B" if e.params_b else "?B"
    quant = f"{e.quant_bits}-bit" if e.quant_bits else "?-bit"
    size = f"{e.size_gb}GB" if e.size_gb else ""
    parts = [e.name, f"({params} / {quant} / {e.backend}"]
    if size:
        parts[-1] += f" / {size}"
    parts[-1] += ")"
    return "  ".join(parts)


_DRAFT_ONLY_MODEL_TYPES = {"gemma4_assistant"}


def _read_model_type(path: str) -> str:
    """Read model_type from config.json."""
    import json
    cfg_path = Path(path) / "config.json"
    if not cfg_path.exists():
        return ""
    try:
        cfg = json.loads(cfg_path.read_text())
        return str(cfg.get("model_type") or "").strip().lower()
    except Exception:
        return ""


def _is_likely_draft(entry: mr.ModelEntry) -> bool:
    """Heuristic: small model with assistant/draft/dflash in name, or known draft-only type."""
    # Check model_type first — definitive
    if entry.path:
        mt = _read_model_type(entry.path)
        if mt in _DRAFT_ONLY_MODEL_TYPES:
            return True
    name_lower = entry.name.lower()
    # Hard draft markers
    if "dflash" in name_lower or "draft" in name_lower:
        return True
    if "assistant" in name_lower and "gemma" in name_lower:
        return True  # gemma assistant models are draft-only
    # zaya is draft only if explicitly small (≤2B) — zaya1-8b is a real model
    if "zaya" in name_lower:
        if entry.params_b and entry.params_b > 3.0:
            return False  # large zaya model → main model
        return True  # small zaya → draft
    # Very small models (≤1.5B) are likely drafts
    if entry.params_b and entry.params_b <= 1.5:
        return True
    return False


def _is_compatible_draft(main: mr.ModelEntry, draft: mr.ModelEntry) -> bool:
    """Check if draft can be used with main model for speculative decoding."""
    if not draft.path or not main.path:
        return False
    # gemma4_assistant works with any gemma base
    draft_name = draft.name.lower()
    main_name = main.name.lower()
    if "assistant" in draft_name and "gemma" in main_name:
        return True
    # zaya: works as draft for zaya-based or compatible models
    if "zaya" in draft_name:
        return True
    # Same family heuristic
    for family in ("qwen", "gemma", "llama", "phi", "mistral"):
        if family in draft_name and family in main_name:
            return True
    # dflash is always compatible
    if "dflash" in draft_name:
        return True
    return False


# ---------------------------------------------------------------------------
# Full-system model scan
# ---------------------------------------------------------------------------

def scan_models(verbose: bool = True) -> list[mr.ModelEntry]:
    """Discover models — first from known dirs, then system-wide scan."""
    if verbose:
        sys.stdout.write("  Bilinen dizinler taranıyor...")
        sys.stdout.flush()
    entries = mr.discover_models()
    if verbose:
        sys.stdout.write(f" {len(entries)} model.\n")
        sys.stdout.write("  Sistem geneli taranıyor (maks 8 saniye)...")
        sys.stdout.flush()
    full = mr.discover_all_system_models()
    # Merge: add entries not already in known list
    known_paths = {e.path for e in entries}
    for e in full:
        if e.path not in known_paths:
            entries.append(e)
            known_paths.add(e.path)
    if verbose:
        sys.stdout.write(f" toplam {len(entries)} model.\n")
    entries.sort(key=lambda e: (-(e.params_b or 0), e.name))
    return entries


# ---------------------------------------------------------------------------
# Model selection screen (shown every launch)
# ---------------------------------------------------------------------------

def select_model_screen(entries: list[mr.ModelEntry], last_path: str = "") -> mr.ModelEntry:
    """Interactive model selection. Returns chosen entry."""
    # Separate draft candidates from main models for display
    main_models = [e for e in entries if not _is_likely_draft(e)]
    if not main_models:
        main_models = entries  # fallback: show all

    sys.stdout.write("\nModel seç:\n")
    labels = [_model_label(e) for e in main_models]

    # Default: last used model
    default_idx = 0
    if last_path:
        for i, e in enumerate(main_models):
            if e.path == last_path:
                default_idx = i
                break

    idx = choose("", labels, default_idx=default_idx)
    return main_models[idx]


def select_draft_screen(
    main: mr.ModelEntry, all_entries: list[mr.ModelEntry]
) -> mr.ModelEntry | None:
    """Ask user to pick a draft model for speculative decoding, or skip."""
    candidates = [
        e for e in all_entries
        if e.path != main.path and _is_likely_draft(e) and _is_compatible_draft(main, e)
    ]
    if not candidates:
        return None

    sys.stdout.write("\nSpeculative decoding için draft model:\n")
    labels = ["Hayır, draft kullanma"] + [_model_label(e) for e in candidates]
    idx = choose("", labels, default_idx=0)
    if idx == 0:
        return None
    return candidates[idx - 1]


# ---------------------------------------------------------------------------
# Sub-flows (first-run wizard)
# ---------------------------------------------------------------------------

def detect_hardware_step() -> hw_mod.HardwareInfo:
    cached = hw_mod.load_hardware()
    if cached:
        sys.stdout.write("\n[1/4] Donanım: önbellekten yüklendi.\n")
        sys.stdout.write(cached.summary() + "\n")
        return cached
    sys.stdout.write("\n[1/4] Donanım taranıyor...\n")
    info = hw_mod.detect_hardware()
    hw_mod.save_hardware(info)
    sys.stdout.write(info.summary() + "\n")
    return info


def discover_models_step(hw: hw_mod.HardwareInfo) -> list[mr.ModelEntry]:
    sys.stdout.write("\n[2/4] Modeller aranıyor...\n")
    entries = scan_models(verbose=True)
    if not entries:
        sys.stdout.write("\nUyarı: model bulunamadı.\n")
        sys.stdout.write("\n" + mr.generic_recommendation(hw) + "\n")
        custom = ask("Elinizde model varsa tam yolunu girin (boş bırakırsanız çıkış)", "")
        if not custom:
            sys.stdout.write(
                "\nModel olmadan devam edilemiyor.\n"
                "~/Desktop/ altına bir MLX modeli koyarak `mico setup` tekrar çalıştırın.\n"
            )
            sys.exit(0)
        entries = mr.discover_models(extra_dirs=[Path(custom).expanduser()])
        if not entries:
            sys.stdout.write(
                f"O dizinde model bulamadım: {custom}\n"
                "MLX modeli için klasörde config.json ve *.safetensors dosyaları olmalı.\n"
            )
            sys.exit(1)
    sys.stdout.write(f"{len(entries)} model bulundu.\n")
    return entries


def select_model_step(entries: list[mr.ModelEntry]) -> mr.ModelEntry:
    sys.stdout.write("\n[3/4] Varsayılan model seçimi:\n")
    return select_model_screen(entries)


def select_draft_step(main: mr.ModelEntry, all_entries: list[mr.ModelEntry]) -> mr.ModelEntry | None:
    return select_draft_screen(main, all_entries)


def recommend_profile_step(hw: hw_mod.HardwareInfo, model: mr.ModelEntry) -> mr.Profile:
    sys.stdout.write("\n[4/4] Profil önerisi hesaplanıyor...\n")
    profile = mr.recommend_profile(hw, model)
    sys.stdout.write(f"\nÖnerilen profil: {profile.name}\n")
    sys.stdout.write(f"  Bağlam : {profile.context_window} token\n")
    sys.stdout.write(f"  Max yanıt: {profile.max_tokens} token\n")
    sys.stdout.write(f"  Thinking : {'açık' if profile.thinking else 'kapalı'}\n")
    for note in profile.notes:
        sys.stdout.write(f"  · {note}\n")
    if not confirm("\nBu profili onaylıyor musunuz?", default=True):
        sys.stdout.write("Profil reddedildi. `mico setup --force` ile yeniden çalıştırabilirsiniz.\n")
        sys.exit(0)
    return profile


# ---------------------------------------------------------------------------
# Last-model persistence
# ---------------------------------------------------------------------------

def save_last_model(path: str) -> None:
    try:
        LAST_MODEL_FILE.parent.mkdir(parents=True, exist_ok=True)
        LAST_MODEL_FILE.write_text(path, encoding="utf-8")
    except OSError:
        pass


def load_last_model() -> str:
    try:
        return LAST_MODEL_FILE.read_text(encoding="utf-8").strip()
    except OSError:
        return ""


# ---------------------------------------------------------------------------
# Top-level entry
# ---------------------------------------------------------------------------

def run_wizard(force: bool = False, extra_dirs: list[Path] | None = None) -> mr.Profile:
    """First-run wizard: runs setup wizard once, then shows model picker every launch."""

    # --- First-run wizard ---
    if force or not SETUP_FLAG.exists():
        print_banner()
        sys.stdout.write("Hoş geldin. mico ilk kez çalıştırılıyor; birkaç saniyelik kurulum.\n")

        hw = detect_hardware_step()
        entries = discover_models_step(hw)
        chosen = select_model_step(entries)
        draft = select_draft_step(chosen, entries)
        profile = recommend_profile_step(hw, chosen)

        if draft:
            profile.draft_model_path = draft.path
            profile.num_draft_tokens = 4
            sys.stdout.write(f"  Draft model: {draft.name}\n")

        mr.save_models(entries, default_path=chosen.path)
        mr.save_model_profile(profile)
        mr.save_profile(profile)
        save_last_model(chosen.path)

        SETUP_FLAG.parent.mkdir(parents=True, exist_ok=True)
        SETUP_FLAG.write_text("ok\n", encoding="utf-8")

        sys.stdout.write(f"\nKurulum tamam. Tercihler: {CONFIG_DIR}\n\n")
        return profile

    # --- Every-launch model picker ---
    # Quick scan (no system-wide find, just known dirs)
    sys.stdout.write("\nModeller aranıyor...")
    sys.stdout.flush()
    entries = mr.discover_models()
    sys.stdout.write(f" {len(entries)} bulundu.\n")

    if not entries:
        # Fallback to saved profile
        prof = mr.load_profile()
        if prof:
            sys.stdout.write(
                f"[!] Aktif taramada model bulunamadı — önceki profil kullanılıyor: {prof.model_name}\n"
            )
            return prof
        sys.stdout.write(
            "\n[!] Model bulunamadı.\n\n"
            "mico çalışmak için yerelde bir MLX veya Ollama modeline ihtiyaç duyar.\n\n"
            "Seçenekler:\n"
            "  1. MLX modeli indir (Apple Silicon):\n"
            "       mico models --download mlx-community/Qwen3-8B-4bit\n\n"
            "  2. Ollama ile kur:\n"
            "       brew install ollama && ollama pull qwen2.5-coder:7b\n\n"
            "  3. Manuel model varsa tam yolu ile çalıştır:\n"
            "       mico setup --force\n\n"
            "Sonra: mico\n"
        )
        sys.exit(1)

    last_path = load_last_model()
    chosen = select_model_screen(entries, last_path=last_path)

    # Check for per-model saved profile
    existing_profile = mr.load_model_profile(chosen.path)

    # Draft selection
    draft: mr.ModelEntry | None = None
    draft_candidates = [
        e for e in entries
        if e.path != chosen.path and _is_likely_draft(e) and _is_compatible_draft(chosen, e)
    ]
    if draft_candidates:
        draft = select_draft_screen(chosen, entries)

    # Build profile
    if existing_profile and existing_profile.model_path == chosen.path:
        profile = existing_profile
    else:
        hw = hw_mod.load_hardware() or hw_mod.detect_hardware()
        profile = mr.recommend_profile(hw, chosen)

    if draft:
        profile.draft_model_path = draft.path
        profile.num_draft_tokens = 4
    else:
        profile.draft_model_path = ""
        profile.num_draft_tokens = 0

    save_last_model(chosen.path)
    mr.save_model_profile(profile)

    return profile


def is_setup_complete() -> bool:
    return SETUP_FLAG.exists()


if __name__ == "__main__":
    run_wizard(force="--force" in sys.argv)
