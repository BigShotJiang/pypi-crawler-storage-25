from __future__ import annotations

import time
from typing import Any


def new_turn_state() -> tuple[float, list[str], dict[str, Any]]:
    started_at = time.time()
    models: list[str] = []
    trace: dict[str, Any] = {
        "models": [],
        "orchestra": {"enabled": False, "handoff_injected": False, "repair_used": False, "invalid_action_streak": 0},
        "stop_reason": "",
        "usage": {
            "prompt_tokens": 0,
            "completion_tokens": 0,
            "total_tokens": 0,
            "llm_seconds": 0.0,
            "calls": 0,
            "tool_calls": 0,
            "estimated": False,
        },
    }
    return started_at, models, trace


def add_usage(
    trace: dict[str, Any],
    *,
    prompt_tokens: int,
    completion_tokens: int,
    total_tokens: int,
    llm_seconds: float,
    estimated: bool,
) -> None:
    usage = trace.setdefault(
        "usage",
        {"prompt_tokens": 0, "completion_tokens": 0, "total_tokens": 0, "llm_seconds": 0.0, "calls": 0, "estimated": False},
    )
    usage["prompt_tokens"] += max(0, int(prompt_tokens))
    usage["completion_tokens"] += max(0, int(completion_tokens))
    usage["total_tokens"] += max(0, int(total_tokens))
    usage["llm_seconds"] += max(0.0, float(llm_seconds))
    usage["calls"] += 1
    usage["estimated"] = bool(usage.get("estimated")) or estimated

