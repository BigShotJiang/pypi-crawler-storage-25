"""Inline arrow-key picker — navigable list with no full-screen takeover."""
from __future__ import annotations

import sys
import termios
import tty
from typing import Callable, Optional


def pick(items: list[str], *, title: str = "", default_index: int = 0,
         render_extra: Optional[Callable[[int], str]] = None) -> Optional[int]:
    """Show a navigable list. Returns selected index, or None if Esc/Ctrl+C.

    Uses ANSI escape sequences. Inline (no alt-screen). After return,
    erases its own output.

    Args:
        items: list of label strings (one per row).
        title: optional title line.
        default_index: initially selected index.
        render_extra: optional fn(idx) that returns an extra line under selection.

    Returns:
        Selected index, or None if Esc/Ctrl+C.
    """
    if not items or not sys.stdin.isatty():
        return default_index

    selected = max(0, min(default_index, len(items) - 1))
    n = len(items)

    fd = sys.stdin.fileno()
    old_settings = termios.tcgetattr(fd)

    def render():
        """Render the picker UI."""
        sys.stdout.write("\033[?25l")  # hide cursor
        if title:
            sys.stdout.write(f"  \033[1m{title}\033[0m\n")
        for i, label in enumerate(items):
            marker = "❯" if i == selected else " "
            style_open = "\033[1;36m" if i == selected else "\033[2m"
            style_close = "\033[0m"
            sys.stdout.write(f"  {style_open}{marker} {label}{style_close}\n")
        if render_extra:
            extra = render_extra(selected)
            if extra:
                sys.stdout.write(f"\n  \033[2m{extra}\033[0m\n")
        sys.stdout.write("\033[2m  ↑/↓ seç · Enter onayla · Esc iptal\033[0m\n")
        sys.stdout.flush()

    def lines_drawn() -> int:
        """Count lines we've drawn so we can erase them later."""
        extra = 1 if (render_extra and render_extra(selected)) else 0
        return (1 if title else 0) + n + (extra + 1 if extra else 0) + 1

    def clear():
        """Move up and clear each line we drew."""
        count = lines_drawn()
        for _ in range(count):
            sys.stdout.write("\033[F\033[2K")
        sys.stdout.write("\033[?25h")  # show cursor
        sys.stdout.flush()

    try:
        tty.setcbreak(fd)
        render()
        while True:
            ch = sys.stdin.read(1)
            if ch == "\033":  # escape sequence
                seq = sys.stdin.read(2)
                if seq == "[A":  # up arrow
                    selected = (selected - 1) % n
                elif seq == "[B":  # down arrow
                    selected = (selected + 1) % n
                else:  # plain Esc or other
                    clear()
                    return None
            elif ch in ("\r", "\n"):  # Enter
                clear()
                return selected
            elif ch == "\x03":  # Ctrl+C
                clear()
                return None
            elif ch == "j":  # vim-style down
                selected = (selected + 1) % n
            elif ch == "k":  # vim-style up
                selected = (selected - 1) % n
            else:
                continue
            # Re-render: move up to top of list
            count = lines_drawn()
            for _ in range(count):
                sys.stdout.write("\033[F\033[2K")
            render()
    finally:
        termios.tcsetattr(fd, termios.TCSADRAIN, old_settings)
        sys.stdout.write("\033[?25h")
        sys.stdout.flush()
