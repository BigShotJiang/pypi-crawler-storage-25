from __future__ import annotations

from typing import Callable


def compact_trigger_chars(
    *,
    context_window_tokens: int,
    auto_compact_ratio: float,
    history_compact_char_trigger: int,
) -> int:
    estimated = int(max(1, context_window_tokens) * 4 * auto_compact_ratio)
    return max(history_compact_char_trigger, estimated)


def update_compact_meter(
    history: list[dict[str, str]],
    *,
    compact_trigger_chars: Callable[[], int],
    history_total_chars: Callable[[list[dict[str, str]]], int],
) -> int:
    trigger = compact_trigger_chars()
    used = history_total_chars(history)
    remaining = max(0, trigger - used)
    return max(0, min(100, int((remaining / trigger) * 100))) if trigger else 0
