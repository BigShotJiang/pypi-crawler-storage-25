"""Tool dispatch, validation, and policy functions.

This module contains helper functions for tool validation, redundancy checking,
goal alignment, and result analysis. It's used by the main CLI to determine
whether to dispatch tools, what constraints to apply, and how to interpret results.

NOTE: Actual tool implementations (bash, read_file, write_file, grep_code, etc.) are in tool_dispatch.py.
      To analyze tool error handling or retry logic, read tool_dispatch.py instead.
"""

import re
import shlex
from pathlib import Path
from typing import TYPE_CHECKING, Any
from urllib.parse import urlparse

if TYPE_CHECKING:
    from mico.cli import TaskState, ToolContext


def truncate(text: str, limit: int) -> str:
    """Truncate text to a character limit with ellipsis."""
    if len(text) <= limit:
        return text
    return text[:limit] + f"\n...[truncated {len(text) - limit} chars]"


# ============================================================================
# INSPECTION AND ARTIFACT FUNCTIONS
# ============================================================================

def inspection_signature(action: dict[str, Any]) -> str | None:
    """Return a normalized signature for inspection-style tool calls.

    Used to detect redundant read/inspect operations in the history.
    Returns None if the action is not an inspection tool.
    """
    if action.get("type") != "tool":
        return None
    tool = str(action.get("tool", ""))
    if tool in {"read_file", "list_files", "parse_json_file"}:
        return f"{tool}:{action.get('path', '')}"
    if tool == "grep_code":
        return f"{tool}:{action.get('path', '')}:{action.get('pattern', '')}:{action.get('include', '')}"
    if tool == "bash":
        command = str(action.get("command", "")).strip()
        # Normalize common read-only commands to catch redundant inspections
        lowered = command.lower()
        if lowered.startswith("cat "):
            path = command[4:].strip().split()[0]
            return f"read:{path}"
        if lowered.startswith("sed -n") and (lowered.endswith("p") or "p " in lowered):
            # Extract the last argument which is likely the path
            parts = command.split()
            if len(parts) >= 3:
                return f"read:{parts[-1]}"
        if (lowered.startswith("grep ") or lowered.startswith("grep -a") or lowered.startswith("grep -b") or lowered.startswith("grep -i")) and not (">" in command or "|" in command):
            parts = command.split()
            # Often grep pattern file
            if len(parts) >= 3:
                return f"read:{parts[-1]}"
        if (lowered.startswith("head ") or lowered.startswith("tail ")) and not (">" in command or "|" in command):
            parts = command.split()
            if len(parts) >= 2:
                return f"read:{parts[-1]}"

        if command.startswith("cat ") or command.startswith("sed -n ") or command.startswith("grep -n "):
            return f"bash:{command}"
    return None


def is_inspection_tool(action: dict[str, Any]) -> bool:
    """Return True if the action is an inspection-style tool (read-only)."""
    if action.get("type") != "tool":
        return False
    return str(action.get("tool", "")) in {
        "bash", "read_file", "list_files", "grep_code", "parse_json_file", "http_request",
        "find_in_files", "git_tool", "env_info", "json_query", "python_run",
    }


def normalize_artifact_snippet(text: str, limit: int = 220) -> str:
    """Normalize artifact snippet text for comparison."""
    collapsed = re.sub(r"\s+", " ", str(text or "").strip()).lower()
    return collapsed[:limit]


def bash_read_target(command: str) -> str:
    """Extract the file path being read from a bash read command."""
    try:
        parts = shlex.split(command)
    except ValueError:
        parts = command.split()
    if not parts:
        return ""
    executable = parts[0]
    if executable == "cat" and len(parts) >= 2:
        return parts[1]
    if executable in {"head", "tail"} and len(parts) >= 2:
        return parts[-1]
    if executable == "sed" and "-n" in parts and len(parts) >= 3:
        return parts[-1]
    return ""


def redundant_artifact_read_reason(state: "TaskState", action: dict[str, Any]) -> str:
    """Determine if the action rereads an artifact that already exists in state.

    Returns a reason string if redundant, empty string otherwise.
    """
    if action.get("type") != "tool":
        return ""
    target = ""
    tool = str(action.get("tool", ""))
    if tool == "read_file":
        target = str(action.get("path", "")).strip()
    elif tool == "bash":
        target = bash_read_target(str(action.get("command", "")).strip())
    if not target:
        return ""
    try:
        normalized_target = str(Path(target).expanduser().resolve())
    except OSError:
        normalized_target = target
    artifact_paths: set[str] = set()
    for artifact in state.artifacts:
        path = str(artifact.get("path", "")).strip()
        if not path:
            continue
        try:
            artifact_paths.add(str(Path(path).expanduser().resolve()))
        except OSError:
            artifact_paths.add(path)
    if normalized_target not in artifact_paths:
        return ""
    if tool == "bash":
        return "The model tried to reread an existing artifact through bash."
    return "The model tried to reread an existing artifact."


def artifact_reread_guidance(state: "TaskState") -> str:
    """Provide guidance when artifact reread is detected."""
    from mico.task_classify import state_dispatch_mode

    if state_dispatch_mode(state) == "audit" and audit_task_requires_followthrough(state.goal):
        return (
            "You already have the captive portal HTML as artifact evidence. "
            "Do not reread the artifact with bash/cat/read_file. Continue with the next requested deliverable: "
            "identify the login form endpoint and fields from existing evidence, submit one random credential attempt "
            "with http_request if safe, measure the rejection time, then write the interval script."
        )
    return (
        "You already have this artifact in context. Do not reread it through another tool. "
        "Use the existing evidence to assess the next step or return a grounded final answer."
    )


def should_force_finalize_on_stale_audit(state: "TaskState", action: dict[str, Any]) -> bool:
    """Detect when an audit task is stuck reading the same artifact repeatedly."""
    from mico.cli import current_phase_entry
    from mico.task_classify import state_dispatch_mode

    if state_dispatch_mode(state) != "audit" or not is_inspection_tool(action):
        return False
    if audit_task_requires_followthrough(state.goal):
        return False
    phase_name = str(current_phase_entry(state).get("name", ""))
    if phase_name != "finalize":
        return False
    recent_artifacts = state.artifacts[-4:]
    if len(recent_artifacts) < 3:
        return False
    signatures = [
        normalize_artifact_snippet(item.get("snippet", ""))
        for item in recent_artifacts
        if normalize_artifact_snippet(item.get("snippet", ""))
    ]
    if len(signatures) < 3:
        return False
    if len(set(signatures[-3:])) == 1:
        return True
    if len(signatures) >= 4 and len(set(signatures[-4:])) <= 2 and signatures[-1] == signatures[-2]:
        return True
    return False


def audit_task_requires_followthrough(task: str) -> bool:
    """Return True if the audit task requires explicit followthrough steps."""
    from mico.task_classify import extract_task_body

    body = extract_task_body(task).lower()
    if not body:
        return False
    markers = (
        "script",
        "interval",
        "red ver",
        "reject",
        "kaç sn",
        "kac sn",
        "measure",
        "ölç",
        "olc",
        "username",
        "password",
        "gir çık",
        "gir cik",
        "login dene",
        "rastgele",
        "try",
        "yaz",
    )
    return any(marker in body for marker in markers)


# ============================================================================
# URL AND HTTP FUNCTIONS
# ============================================================================

def normalize_url_key(url: str) -> str:
    """Normalize URL for comparison (scheme + netloc + path, lowercase)."""
    parsed = urlparse(url.strip())
    if not parsed.scheme or not parsed.netloc:
        return ""
    path = parsed.path or "/"
    if path.endswith("/") and path != "/":
        path = path.rstrip("/")
    return f"{parsed.scheme.lower()}://{parsed.netloc.lower()}{path}"


def urls_from_bash_command(command: str) -> list[str]:
    """Extract HTTP URLs from a bash command (typically curl)."""
    try:
        parts = shlex.split(command)
    except ValueError:
        parts = command.split()
    urls: list[str] = []
    if not parts or "curl" not in {Path(part).name for part in parts}:
        return urls
    for part in parts:
        if part.startswith(("http://", "https://")):
            urls.append(part)
    return urls


def http_action_method(action: dict[str, Any]) -> str:
    """Extract HTTP method from an action (http_request tool or bash curl)."""
    if action.get("type") != "tool":
        return "GET"
    tool = str(action.get("tool", ""))
    if tool == "http_request":
        return str(action.get("method", "GET")).strip().upper() or "GET"
    if tool != "bash":
        return "GET"
    command = str(action.get("command", ""))
    try:
        parts = shlex.split(command)
    except ValueError:
        parts = command.split()
    method = "GET"
    for idx, part in enumerate(parts):
        if part in {"-X", "--request"} and idx + 1 < len(parts):
            method = str(parts[idx + 1]).strip().upper() or method
        elif part in {"-d", "--data", "--data-raw", "--data-binary", "--form", "-F"}:
            method = "POST"
    return method


def http_action_is_fetch(action: dict[str, Any]) -> bool:
    """Return True if the action is a GET/HEAD/OPTIONS request."""
    return http_action_method(action) in {"GET", "HEAD", "OPTIONS"}


def action_urls(action: dict[str, Any]) -> list[str]:
    """Extract URLs from an action."""
    if action.get("type") != "tool":
        return []
    tool = str(action.get("tool", ""))
    if tool == "http_request":
        return [str(action.get("url", "")).strip()]
    if tool == "bash":
        return urls_from_bash_command(str(action.get("command", "")))
    return []


def artifact_url_keys(state: "TaskState") -> set[str]:
    """Extract normalized URL keys from all artifacts."""
    keys: set[str] = set()
    for artifact in state.artifacts:
        snippet = str(artifact.get("snippet", ""))
        for match in re.findall(r"https?://[^\s\"'<>]+", snippet):
            key = normalize_url_key(match.rstrip(").,;"))
            if key:
                keys.add(key)
        url_match = re.search(r"(?m)^url=(\S+)", snippet)
        if url_match:
            key = normalize_url_key(url_match.group(1))
            if key:
                keys.add(key)
        location_match = re.search(r"(?im)^Location:\s*(\S+)", snippet)
        if location_match:
            key = normalize_url_key(location_match.group(1))
            if key:
                keys.add(key)
    return keys


def redundant_http_probe_reason(state: "TaskState", action: dict[str, Any]) -> str:
    """Detect if the action re-fetches a URL already seen in artifacts."""
    if not http_action_is_fetch(action):
        return ""
    urls = [normalize_url_key(url) for url in action_urls(action)]
    urls = [url for url in urls if url]
    if not urls:
        return ""
    seen = artifact_url_keys(state)
    if not seen:
        return ""
    repeated = [url for url in urls if url in seen]
    if not repeated:
        return ""
    from mico.task_classify import state_dispatch_mode

    if state_dispatch_mode(state) == "audit" and audit_task_requires_followthrough(state.goal):
        return f"The model tried to re-fetch an already observed portal URL: {', '.join(repeated)}."
    return ""


def redundant_http_probe_guidance(state: "TaskState") -> str:
    """Provide guidance when redundant HTTP probe is detected."""
    from mico.task_classify import state_dispatch_mode

    if state_dispatch_mode(state) == "audit" and audit_task_requires_followthrough(state.goal):
        artifact_paths = [str(item.get("path", "")) for item in state.artifacts if str(item.get("path", "")).strip()]
        latest = artifact_paths[-1] if artifact_paths else "the latest artifact"
        return (
            "Do not curl the same portal page again. Use existing artifact evidence instead. "
            f"If specific form fields are needed, run one local grep against {latest}; then measure one login rejection "
            "with a targeted POST and write the interval script."
        )
    return "Do not re-fetch the same URL without a new reason; use existing evidence."


# ============================================================================
# RESULT ANALYSIS FUNCTIONS
# ============================================================================

def extract_result_body(result: str) -> tuple[bool, str]:
    """Extract success flag and body from tool result.

    Returns (success, body) where success is True if exit_code=0 or no exit code line.
    """
    stripped = result.strip()
    if not stripped:
        return (False, "")
    if stripped.startswith("exit_code="):
        lines = stripped.splitlines()
        success = lines[0].strip() == "exit_code=0"
        return (success, "\n".join(lines[1:]).strip())
    return (True, stripped)


def phase_goal_keywords(goal: str) -> set[str]:
    """Extract meaningful keywords from a phase goal."""
    tokens = re.findall(r"[A-Za-z0-9_/-]{4,}", (goal or "").lower())
    stop = {
        "with",
        "from",
        "that",
        "this",
        "your",
        "then",
        "task",
        "phase",
        "tool",
        "local",
        "before",
        "after",
        "return",
        "evidence",
        "result",
        "perform",
        "using",
        "write",
        "summary",
        "final",
        "active",
        "concrete",
        "first",
    }
    return {token for token in tokens if token not in stop}


def result_supports_phase_goal(phase_goal: str, action: dict[str, Any], result: str) -> bool:
    """Determine if the tool result supports the current phase goal."""
    label = str(action.get("tool", ""))
    lowered_goal = (phase_goal or "").lower()
    success, body = extract_result_body(result)
    lowered_result = body.lower()
    method = http_action_method(action)

    if not success or not lowered_result or lowered_result == "(no output)":
        return False
    if "the model tried to re-fetch an already observed portal url" in lowered_result:
        return False
    if "strategy reset required" in lowered_result:
        return False

    if label in {"write_file", "replace_in_file"}:
        return any(word in lowered_goal for word in {"write", "script", "patch", "change", "edit"})
    if label in {"http_request", "bash"} and method not in {"GET", "HEAD", "OPTIONS"}:
        return any(word in lowered_goal for word in {"measure", "timing", "submit", "post", "request", "reject", "login", "auth", "test"})
    if any(word in lowered_goal for word in {"redirect", "portal redirect", "redirect target"}):
        if any(
            marker in lowered_result
            for marker in {
                "http_code:302",
                "status=302",
                "redirect_url:",
                "location:",
                "final_url:",
                "error 302: hotspot redirect",
                "hotspot redirect",
                "login",
            }
        ):
            return True
    if any(word in lowered_goal for word in {"form", "field", "endpoint", "login form"}):
        if any(marker in lowered_result for marker in {"<form", "action=", "method=", "name=", "username", "password", "voucher"}):
            return True

    keywords = phase_goal_keywords(phase_goal)
    if not keywords:
        return True
    hits = sum(1 for token in keywords if token in lowered_result)
    if hits >= 2:
        return True
    if hits >= 1 and len(keywords) <= 3:
        return True
    if ("http_code:" in lowered_result or "status=" in lowered_result) and any(
        word in lowered_goal for word in {"redirect", "endpoint", "status", "timing", "reject"}
    ):
        return True
    if any(word in lowered_result for word in {"<form", "action=", "method=", "name=", "username", "password"}):
        if any(word in lowered_goal for word in {"form", "field", "endpoint", "login"}):
            return True
    return False


def phase_requires_goal_alignment(state: "TaskState", phase_name: str) -> bool:
    """Return True if the phase requires strict goal alignment checking."""
    from mico.cli import current_phase_entry, explicit_step_phase_active

    if explicit_step_phase_active(state):
        return True
    if phase_name in {"redirect", "form", "measure", "script"}:
        return True
    keywords = phase_goal_keywords(str(current_phase_entry(state).get("goal", "")))
    return len(keywords) >= 4 and phase_name not in {"scope", "inspect", "probe", "change", "verify", "findings", "assess", "plan", "finalize", "answer"}


def result_answers_goal(goal: str | None, label: str, result: str) -> bool:
    """Determine if the tool result directly answers a specific goal."""
    if not goal:
        return False
    success, body = extract_result_body(result)
    if not success:
        return False
    if not body or body == "(no output)" or "Strategy reset required" in body:
        return False
    if goal == "local_ip":
        if label == "macos_admin_task":
            has_ip = bool(re.search(r"\b(?:\d{1,3}\.){3}\d{1,3}\b", body))
            has_interface = any(token in body.lower() for token in ("device:", "hardware port:", "inet "))
            return has_ip and has_interface
        return bool(re.search(r"\b(?:\d{1,3}\.){3}\d{1,3}\b", body))
    if goal in {"hostname", "cwd", "whoami"}:
        return label == "bash" and len(body.splitlines()) <= 8
    if goal == "time":
        return label == "bash"
    if goal in {"git_status", "git_log", "git_branch", "git_diff"}:
        return label == "git_tool"
    if goal and goal.startswith("run_file:"):
        return label == "bash"
    return False


def is_duplicate_goal_attempt(action: dict[str, Any], answered_goals: set[str]) -> bool:
    """Return True if the action attempts to answer a goal that was already answered."""
    from mico.task_classify import action_goal_tag

    goal = action_goal_tag(action)
    return bool(goal and goal in answered_goals)


# ============================================================================
# COMMAND POLICY FUNCTIONS
# ============================================================================

def maybe_confirm(command: str, ctx: "ToolContext") -> None:
    """Prompt user to confirm command execution if necessary."""
    from mico.command_policy import (
        classify_command,
        dangerous_command,
    )
    from rich.prompt import Prompt

    if ctx.force or ctx.approval == "never" or getattr(ctx, "unattended", False):
        return
    tier, _reason = classify_command(command)
    if tier == "allow":
        return
    effective_mode = getattr(ctx, "permission_mode", "balanced")
    if effective_mode == "yolo":
        return
    # In auto mode, file ops (cp/mv/mkdir/touch) and unknown commands are allowed
    # without prompting — path-safety checks already guard write targets.
    if ctx.approval == "auto" and tier == "ask" and not dangerous_command(command):
        return
    if ctx.approval == "ask" or (
        ctx.approval == "auto" and dangerous_command(command)
    ):
        ok = Prompt.ask(
            f"Run command?\n{command}\n[y/N]",
            default="n",
        ).lower()
        if ok not in {"y", "yes"}:
            raise RuntimeError("Command not approved by user.")


def command_uses_external_network(command: str) -> bool:
    """Return True if command makes external network requests."""
    from mico.command_policy import command_uses_external_network as _command_uses_external_network
    return _command_uses_external_network(command)


def full_root_scan_reason() -> str:
    """Return reason why full root filesystem scan is not allowed."""
    from mico.command_policy import full_root_scan_reason as _full_root_scan_reason
    return _full_root_scan_reason()


def disallowed_command_reason(command: str, ctx: "ToolContext") -> str | None:
    """Return reason if command is disallowed by policy, None if allowed."""
    from mico.command_policy import disallowed_command_reason as _policy_disallowed_command_reason

    return _policy_disallowed_command_reason(
        command,
        network_access=bool(ctx.network_access),
        tool_install=bool(ctx.tool_install),
        permission_mode=str(getattr(ctx, "permission_mode", "balanced")),
        unattended=bool(getattr(ctx, "unattended", False)),
    )


# ============================================================================
# TOOL OUTPUT PROCESSING
# ============================================================================

def lint_bash_command(command: str) -> list[str]:
    """Lint a bash command for common issues."""
    from mico.command_policy import lint_bash_command as _lint_bash_command
    return _lint_bash_command(command)


def distill_text_output(text: str, *, limit: int = 4000) -> str:
    """Reduce text output while preserving key information."""
    if len(text) <= limit:
        return text
    lines = [line for line in text.splitlines() if line.strip()]
    if not lines:
        return truncate(text, limit)
    key_patterns = (
        "error",
        "warning",
        "traceback",
        "exception",
        "failed",
        "fatal",
        "status",
        "http/",
        "exit_code",
        "inet ",
        "inet6 ",
        "netmask",
        "broadcast",
        "hardware port:",
        "device:",
        "ethernet address:",
    )
    selected: list[str] = []
    seen: set[str] = set()
    for line in lines[:25]:
        if line not in seen:
            selected.append(line)
            seen.add(line)
    for line in lines:
        lower = line.lower()
        if any(pattern in lower for pattern in key_patterns) and line not in seen:
            selected.append(line)
            seen.add(line)
        if len("\n".join(selected)) >= limit:
            break
    for line in lines[-15:]:
        if line not in seen:
            selected.append(line)
            seen.add(line)
        if len("\n".join(selected)) >= limit:
            break
    distilled = "\n".join(selected)
    return truncate(distilled, limit)


def summarize_tool_payload(label: str, result: str, goal: str | None = None) -> str:
    """Create a concise summary of tool output for history."""
    payload = result.strip()
    if not payload:
        return "(no output)"
    lines = payload.splitlines()
    summary: list[str] = []
    if lines and lines[0].startswith("exit_code="):
        # exit_code satırını özete dahil etme — sadece body'yi kullan
        body = "\n".join(lines[1:]).strip()
    else:
        body = payload
    if goal == "local_ip":
        keep_lines: list[str] = []
        for line in body.splitlines():
            lower = line.lower()
            if (
                re.search(r"\b(?:\d{1,3}\.){3}\d{1,3}\b", line)
                or "device:" in lower
                or "hardware port:" in lower
                or "inet " in lower
                or "dhcp" in lower
            ):
                keep_lines.append(line)
        if keep_lines:
            body = "\n".join(keep_lines)
        else:
            body = distill_text_output(body)
    else:
        body = distill_text_output(body)
    if body:
        body_lines = body.splitlines()
        preview = body_lines[:12]
        if len(body_lines) > 12:
            preview.append(f"... [distilled {len(body_lines) - 12} more lines]")
        summary.append("\n".join(preview))
    final = "\n".join(part for part in summary if part).strip()
    return final or f"{label}: (no output)"


def semantic_code_observation(summary: str) -> str:
    """Generate a semantic description of code excerpt."""
    lines = [line.strip() for line in summary.splitlines() if line.strip()]
    hints: list[str] = []
    joined = "\n".join(lines)
    if "def " in joined:
        hints.append("function boundaries")
    if "return " in joined:
        hints.append("return paths")
    if "if " in joined or "elif " in joined:
        hints.append("branching logic")
    if "history" in joined:
        hints.append("history/session handling")
    if "render_" in joined or "log_line" in joined:
        hints.append("logging or UI updates")
    if not hints:
        hints.append("code excerpt")
    return "Observed " + ", ".join(hints[:3]) + "."


def tool_result_history_text(label: str, result: str, task: str) -> str:
    """Format tool result for insertion into history with context guidance."""
    from mico.task_classify import task_goal_tag, task_requests_code_inspection

    goal = task_goal_tag(task)
    summary = summarize_tool_payload(label, result, goal)
    message = f"Tool result for {label}:\n{summary}"
    lowered_task = task.lower()
    if result_answers_goal(goal, label, result):
        message += "\nThis directly answers the task. Return final now unless the user explicitly requested more detail."
        return message
    if label == "bash" and task_requests_code_inspection(task) and summary.count("\n") >= 3:
        message += (
            "\n"
            + semantic_code_observation(summary)
            + " Synthesize from this excerpt instead of reading many tiny sequential sed slices."
        )
        return message
    if label in {"read_file", "list_files", "coding_tool", "grep_code", "parse_json_file", "http_request",
                 "find_in_files", "json_query", "env_info"}:
        if any(token in lowered_task for token in ["incele", "anlat", "özet", "ozet", "review", "risk", "neden", "what", "why", "show"]):
            message += "\nIf this already answers the task, return final next."
    return message


def compact_old_inspection_tool_results(history: list[dict[str, str]], keep_recent: int = 2) -> None:
    """Compact older inspection tool results in history to save tokens."""
    inspection_labels = {"read_file", "grep_code", "list_files", "parse_json_file", "find_in_files", "json_query"}
    candidates: list[tuple[int, str, str]] = []
    for idx, item in enumerate(history):
        if item.get("role") != "user":
            continue
        content = str(item.get("content", ""))
        if content.startswith("[COMPACTED_TOOL_RESULT"):
            continue
        m = re.match(r"^Tool result for ([a-zA-Z0-9_]+):\n", content)
        if not m:
            continue
        label = m.group(1)
        if label not in inspection_labels:
            continue
        candidates.append((idx, label, content))
    if len(candidates) <= keep_recent:
        return
    compact_targets = candidates[:-keep_recent]
    for idx, label, content in compact_targets:
        lines = [line.strip() for line in content.splitlines() if line.strip()]
        artifact_line = ""
        for line in lines:
            if line.startswith("Artifact: "):
                artifact_line = line
                break
        summary_line = ""
        for line in lines[1:]:
            if line.startswith("Artifact: "):
                break
            if line:
                summary_line = line
                break
        compacted = (
            f"[COMPACTED_TOOL_RESULT {label}]\n"
            f"{truncate(summary_line or '(no summary)', 220)}\n"
            f"{artifact_line or 'Artifact: (not recorded)'}"
        )
        history[idx]["content"] = compacted


# ============================================================================
# TOOL ARGS SUMMARY
# ============================================================================

def _tool_args_summary(tool: str, action: dict[str, Any]) -> str:
    """Extract a short args summary for UI rendering of tool calls."""
    try:
        if tool == "bash":
            cmd = action.get("command", "").strip()
            if len(cmd) > 80:
                cmd = cmd[:77] + "..."
            return cmd
        elif tool == "macos_admin_task":
            return action.get("name", "")
        elif tool in ("read_file", "write_file", "replace_in_file"):
            return action.get("path", "")
        elif tool == "grep_code":
            return f"{action.get('pattern', '')[:40]} @ {action.get('path', '')}"
        elif tool == "http_request":
            return action.get("url", "")[:60]
        elif tool == "run_tests":
            return action.get("runner", "")
        elif tool == "find_in_files":
            return f"{action.get('pattern', '')[:40]} @ {action.get('path', '.')}"
        elif tool == "git_tool":
            return f"git {action.get('op', '')}"
        elif tool in ("create_dir", "delete_file"):
            return action.get("path", "")
        elif tool == "move_file":
            return f"{action.get('src', '')} → {action.get('dst', '')}"
        elif tool == "python_run":
            code = str(action.get("code", ""))
            return code[:60] + ("..." if len(code) > 60 else "")
        elif tool == "env_info":
            keys = action.get("keys") or []
            return ", ".join(str(k) for k in keys[:4]) or "platform/python"
        elif tool == "json_query":
            return f"{action.get('path', '')} [{action.get('query', '.')}]"
        else:
            return ""
    except Exception:
        return ""
