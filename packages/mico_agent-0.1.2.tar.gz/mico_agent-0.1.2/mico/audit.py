"""Run audit logging for mico."""
from __future__ import annotations

import json
from dataclasses import asdict, dataclass, field
from datetime import datetime, timezone
from pathlib import Path
from typing import Optional

from mico.redact import redact_text


@dataclass
class RunAuditEntry:
    """Single audit entry for a mico run."""
    run_id: str
    timestamp: str
    mode: str
    profile: str
    task_size: str = ""
    task_preview: str = ""
    selected_files: list[str] = field(default_factory=list)
    changed_files: list[str] = field(default_factory=list)
    lines_changed_estimate: int = 0
    commands_executed: list[str] = field(default_factory=list)
    commands_blocked: list[str] = field(default_factory=list)
    tests_run: bool = False
    test_result: str = ""
    checkpoint_ref: str = ""
    final_status: str = ""
    warnings: list[str] = field(default_factory=list)


class AuditLogger:
    """Audit logging for mico runs."""

    def __init__(self, project_root: Optional[Path] = None):
        """Initialize audit logger.

        Args:
            project_root: Project root directory (for logging to .agent-runs/)
        """
        self._entry: Optional[RunAuditEntry] = None
        self._log_dir: Optional[Path] = None
        if project_root:
            self._log_dir = project_root / ".agent-runs"

    def start(self, mode: str, profile: str, task: str = "") -> None:
        """Start a new audit entry.

        Args:
            mode: Mode name (auto, manual, etc.)
            profile: Profile name (fast, normal, deep, review, docs)
            task: Task description (will be truncated and redacted)
        """
        run_id = datetime.now(timezone.utc).isoformat().replace(":", "-").replace(".", "-")
        timestamp = datetime.now(timezone.utc).isoformat()

        # Truncate and redact task preview
        task_preview = task[:120] if task else ""
        if task_preview:
            task_preview = redact_text(task_preview)

        self._entry = RunAuditEntry(
            run_id=run_id,
            timestamp=timestamp,
            mode=mode,
            profile=profile,
            task_preview=task_preview,
        )

    def record_file_selected(self, path: str) -> None:
        """Record a file as selected for analysis.

        Args:
            path: File path
        """
        if self._entry:
            if path not in self._entry.selected_files:
                self._entry.selected_files.append(path)

    def record_file_changed(self, path: str) -> None:
        """Record a file as changed/modified.

        Args:
            path: File path
        """
        if self._entry:
            if path not in self._entry.changed_files:
                self._entry.changed_files.append(path)

    def record_command(self, cmd: str, blocked: bool = False) -> None:
        """Record a command execution or blocking.

        Args:
            cmd: Command string
            blocked: Whether command was blocked
        """
        if self._entry:
            if blocked:
                if cmd not in self._entry.commands_blocked:
                    self._entry.commands_blocked.append(cmd)
            else:
                if cmd not in self._entry.commands_executed:
                    self._entry.commands_executed.append(cmd)

    def record_test(self, result_str: str) -> None:
        """Record test execution result.

        Args:
            result_str: Test result summary
        """
        if self._entry:
            self._entry.tests_run = True
            self._entry.test_result = result_str

    def record_checkpoint(self, ref: str) -> None:
        """Record git checkpoint reference.

        Args:
            ref: Git commit reference
        """
        if self._entry:
            self._entry.checkpoint_ref = ref

    def record_warning(self, msg: str) -> None:
        """Record a warning message.

        Args:
            msg: Warning text
        """
        if self._entry:
            if msg not in self._entry.warnings:
                self._entry.warnings.append(msg)

    def record_task_size(self, size: str) -> None:
        """Record classified task size.

        Args:
            size: Task size (small, medium, large)
        """
        if self._entry:
            self._entry.task_size = size

    def record_lines_changed(self, count: int) -> None:
        """Record estimated lines changed.

        Args:
            count: Line count
        """
        if self._entry:
            self._entry.lines_changed_estimate = count

    def finish(self, status: str = "ok") -> None:
        """Finish audit entry and write to disk.

        Args:
            status: Final status (ok, error, partial, rollback)
        """
        if not self._entry:
            return

        self._entry.final_status = status

        # Write to disk if log dir is set
        if self._log_dir:
            self._log_dir.mkdir(parents=True, exist_ok=True)

            # Redact sensitive paths before writing
            entry_dict = asdict(self._entry)
            entry_dict = self._redact_paths(entry_dict)

            log_file = self._log_dir / f"{self._entry.run_id}.json"
            try:
                with open(log_file, "w") as f:
                    json.dump(entry_dict, f, indent=2)
            except Exception:
                pass  # Silently fail on write errors

    def current(self) -> Optional[RunAuditEntry]:
        """Get current audit entry.

        Returns:
            Current RunAuditEntry or None if not started.
        """
        return self._entry

    @staticmethod
    def _redact_paths(entry_dict: dict) -> dict:
        """Redact sensitive paths from entry.

        Args:
            entry_dict: Dictionary to redact in-place

        Returns:
            Redacted dictionary
        """
        sensitive_patterns = [
            ".env",
            "~/.ssh",
            "~/.aws",
            ".git",
            ".venv",
            ".env.local",
            "credentials",
            "secrets",
        ]

        for key in ["selected_files", "changed_files"]:
            if key in entry_dict and isinstance(entry_dict[key], list):
                filtered = []
                for path in entry_dict[key]:
                    # Keep path if it doesn't match sensitive patterns
                    if not any(pattern in path for pattern in sensitive_patterns):
                        filtered.append(path)
                entry_dict[key] = filtered

        return entry_dict


def format_audit_summary(entry: RunAuditEntry) -> str:
    """Format audit entry as human-readable summary.

    Args:
        entry: RunAuditEntry to format

    Returns:
        Formatted string suitable for console output.
    """
    lines = [
        "Audit Summary:",
        f"  Run ID: {entry.run_id}",
        f"  Timestamp: {entry.timestamp}",
        f"  Mode: {entry.mode}",
        f"  Profile: {entry.profile}",
    ]

    if entry.task_size:
        lines.append(f"  Task size: {entry.task_size}")

    if entry.task_preview:
        lines.append(f"  Task: {entry.task_preview}")

    lines.append(f"  Files selected: {len(entry.selected_files)}")
    lines.append(f"  Files changed: {len(entry.changed_files)}")

    if entry.lines_changed_estimate:
        lines.append(f"  Lines changed: {entry.lines_changed_estimate}")

    lines.append(f"  Commands executed: {len(entry.commands_executed)}")
    lines.append(f"  Commands blocked: {len(entry.commands_blocked)}")
    lines.append(f"  Tests run: {'yes' if entry.tests_run else 'no'}")

    if entry.checkpoint_ref:
        lines.append(f"  Checkpoint: {entry.checkpoint_ref}")

    lines.append(f"  Status: {entry.final_status}")

    if entry.warnings:
        lines.append(f"  Warnings: {len(entry.warnings)}")

    return "\n".join(lines)
