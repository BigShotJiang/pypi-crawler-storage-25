from __future__ import annotations

from typing import Any, Callable


async def repair_action_response(
    raw: str,
    history: list[dict[str, str]],
    *,
    strip_thinking: Callable[[str], str],
    truncate: Callable[[str, int], str],
    recent_user_message: Callable[[list[dict[str, str]]], str],
    task_prefers_brief_answer: Callable[[str], bool],
    call_model: Callable[..., Any],
    min_thinking_budget: int,
    extract_json: Callable[[str], dict[str, Any]],
    task_state_summary: str = "",
) -> tuple[dict[str, Any], str]:
    cleaned = strip_thinking(raw).strip()
    last_user = truncate(recent_user_message(history), 1500)
    likely_short_task = task_prefers_brief_answer(last_user)
    strategy_text = (
        "This is a short direct-answer task. If the malformed output or latest tool result already answers the task, "
        "return a final action instead of preserving an unnecessary tool step. The final message must be in Turkish. "
        if likely_short_task
        else "Prefer preserving the assistant's intended actionable tool call over converting it into a final answer. "
        "Use a final action only when the malformed output truly contains no actionable next step. Any final message must be in Turkish. "
    )
    context_parts = [f"Latest context:\n{last_user}"]
    if task_state_summary:
        context_parts.append(f"Task state:\n{task_state_summary}")
    context_parts.append(f"Malformed assistant output:\n{truncate(cleaned, 3000)}")

    repair_prompt = [
        {
            "role": "system",
            "content": (
                "Repair malformed mico action outputs. "
                + "Return exactly one JSON object and nothing else. "
                + "All visible natural-language text, especially final.message, must be in Turkish. "
                + strategy_text
                + "Allowed forms: "
                + '{"type":"tool","tool":"list_files","path":"."} '
                + '{"type":"tool","tool":"read_file","path":"file.txt"} '
                + '{"type":"tool","tool":"bash","command":"pwd","timeout":120000} '
                + '{"type":"final","message":"task completed summary"} '
                + '{"type":"patch","diff":"..."} '
                + "If the next step is unclear, return a final action with a short explanation."
            ),
        },
        {
            "role": "user",
            "content": "\n\n".join(context_parts),
        },
    ]
    repaired_raw = await call_model(repair_prompt, thinking_budget=min_thinking_budget, stream=False, use_orchestra=False)
    return extract_json(repaired_raw), repaired_raw
