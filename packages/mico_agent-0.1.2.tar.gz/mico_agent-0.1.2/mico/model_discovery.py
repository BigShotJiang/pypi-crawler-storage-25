from __future__ import annotations

import re


def model_name_tokens(name: str, *, stopwords: set[str]) -> list[str]:
    normalized = name.lower()
    for marker in ("thecluster", "culturerevolt", "mlx-community", "mlxcommunity", "z-lab", "zlab"):
        normalized = normalized.replace(marker, " ")
    raw_tokens = re.split(r"[^a-z0-9]+", normalized)
    tokens: list[str] = []
    for token in raw_tokens:
        if not token or token in stopwords:
            continue
        if token.isdigit():
            continue
        tokens.append(token)
    return tokens


def is_draft_model_name(name: str, *, draft_model_markers: tuple[str, ...]) -> bool:
    lowered = name.lower()
    return any(marker in lowered for marker in draft_model_markers)


def draft_model_rank(name: str) -> tuple[int, str]:
    lowered = name.lower()
    if "assistant" in lowered:
        return (0, lowered)
    if "dflash" in lowered:
        return (1, lowered)
    if "draft" in lowered:
        return (2, lowered)
    return (9, lowered)
