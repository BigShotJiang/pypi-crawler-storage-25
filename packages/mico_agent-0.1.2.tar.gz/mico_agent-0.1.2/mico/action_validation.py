from __future__ import annotations

from typing import Any


def validate_action(action: dict[str, Any]) -> tuple[bool, str]:
    kind = str(action.get("type", "")).strip()
    if kind == "final":
        if not str(action.get("message", "")).strip() and not str(action.get("summary", "")).strip():
            return (False, "final.message or final.summary is required")
        return (True, "")
    if kind == "patch":
        if not str(action.get("diff", "")).strip():
            return (False, "patch.diff is required")
        return (True, "")
    if kind != "tool":
        return (False, "type must be tool, final, or patch")
    tool = str(action.get("tool", "")).strip()
    if not tool:
        return (False, "tool name is required")
    KNOWN_TOOLS = {
        "list_files", "read_file", "write_file", "replace_in_file",
        "bash", "grep_code", "parse_json_file", "http_request",
        "coding_tool", "skill_tool", "macos_admin_task",
    }
    if tool not in KNOWN_TOOLS:
        return (False, f"unknown tool '{tool}' — must be one of: {', '.join(sorted(KNOWN_TOOLS))}")
    required_fields = {
        "list_files": ["path"],
        "read_file": ["path"],
        "write_file": ["path", "content"],
        "replace_in_file": ["path", "old", "new"],
        "bash": ["command"],
        "grep_code": ["pattern", "path"],
        "parse_json_file": ["path"],
        "http_request": ["url"],
        "coding_tool": ["action"],
        "skill_tool": ["skill", "action"],
        "macos_admin_task": ["name"],
    }
    for field in required_fields.get(tool, []):
        if not str(action.get(field, "")).strip():
            return (False, f"{tool}.{field} is required")
    return (True, "")
