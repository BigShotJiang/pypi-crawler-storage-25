"""Model discovery, selection, and metrics operations for mico CLI.

This module handles:
- Model discovery and validation (Ollama, MLX)
- Model provider inference and selection
- Model profiles and auto-promotion
- Turn metrics (tokens, usage, trace data)
"""
from __future__ import annotations

import json
import math
import os
import shutil
import subprocess
from pathlib import Path
from typing import Any, TYPE_CHECKING

from mico.model_discovery import (
    model_name_tokens as _model_name_tokens,
    is_draft_model_name as _is_draft_model_name,
    draft_model_rank as _draft_model_rank,
)
from mico.output import (
    usage_footer_text as _usage_footer_text,
)
from mico.model_text import (
    flatten_model_content as _flatten_model_content,
    extract_choice_text as _extract_choice_text,
    extract_choice_reasoning as _extract_choice_reasoning,
)
from mico.metrics import (
    new_turn_state as _new_turn_state,
    add_usage as _add_usage,
)

if TYPE_CHECKING:
    from mico.profiles_runtime import ProfileConfig


# ============================================================================
# Utility functions
# ============================================================================

def _truncate(text: str, limit: int) -> str:
    """Truncate text to limit with ellipsis."""
    if len(text) <= limit:
        return text
    return text[:limit] + f"\n...[truncated {len(text) - limit} chars]"


# ============================================================================
# Module-level state for turn metrics (replaces CURRENT_TURN_* globals)
# ============================================================================

CURRENT_TURN_STARTED_AT: float | None = None
CURRENT_TURN_MODELS: list[str] = []
CURRENT_TURN_TRACE: dict[str, Any] = {}


# ============================================================================
# Turn metrics state accessors
# ============================================================================

def get_turn_started_at() -> float | None:
    """Get turn start time."""
    return CURRENT_TURN_STARTED_AT


def get_turn_models() -> list[str]:
    """Get list of models used in turn."""
    return CURRENT_TURN_MODELS


def get_turn_trace() -> dict[str, Any]:
    """Get turn trace data."""
    return CURRENT_TURN_TRACE


# ============================================================================
# Turn metrics functions
# ============================================================================

def reset_turn_metrics() -> None:
    """Initialize or reset turn metrics state."""
    global CURRENT_TURN_STARTED_AT, CURRENT_TURN_MODELS, CURRENT_TURN_TRACE
    CURRENT_TURN_STARTED_AT, CURRENT_TURN_MODELS, CURRENT_TURN_TRACE = _new_turn_state()


def note_turn_model(model: str) -> None:
    """Record a model used in this turn."""
    global CURRENT_TURN_MODELS, CURRENT_TURN_TRACE
    label = model_label(model)
    if label and label not in CURRENT_TURN_MODELS:
        CURRENT_TURN_MODELS.append(label)
    if label:
        models = CURRENT_TURN_TRACE.setdefault("models", [])
        if label not in models:
            models.append(label)


def set_turn_stop_reason(reason: str) -> None:
    """Record the stop reason for this turn."""
    CURRENT_TURN_TRACE["stop_reason"] = reason.strip()


def record_orchestra_trace(**updates: Any) -> None:
    """Update orchestra trace with new data."""
    trace = CURRENT_TURN_TRACE.setdefault("orchestra", {"enabled": False})
    trace.update({key: value for key, value in updates.items() if value is not None and value != ""})


def is_low_signal_final(message: str) -> bool:
    """Check if a message is low-signal (placeholder, short, etc)."""
    stripped = (message or "").strip()
    if not stripped:
        return True
    lowered = stripped.lower()
    if stripped in {"...", "..", ".", "…"}:
        return True
    if lowered in {"todo", "tbd", "unknown", "n/a", "none"}:
        return True
    if len(stripped) <= 6 and all(ch in ".-_* " for ch in stripped):
        return True
    return False


def record_turn_usage(
    *,
    prompt_tokens: int,
    completion_tokens: int,
    total_tokens: int,
    llm_seconds: float,
    estimated: bool,
) -> None:
    """Record token usage and LLM time for this turn."""
    _add_usage(
        CURRENT_TURN_TRACE,
        prompt_tokens=prompt_tokens,
        completion_tokens=completion_tokens,
        total_tokens=total_tokens,
        llm_seconds=llm_seconds,
        estimated=estimated,
    )


def usage_footer_text(active_profile: str | None = None) -> str:
    """Generate usage footer text for turn summary."""
    usage = CURRENT_TURN_TRACE.get("usage") or {}
    prompt_tokens = int(usage.get("prompt_tokens") or 0)
    completion_tokens = int(usage.get("completion_tokens") or 0)
    total_tokens = int(usage.get("total_tokens") or 0)
    llm_seconds = float(usage.get("llm_seconds") or 0.0)
    llm_calls = int(usage.get("calls") or 0)
    tool_calls = int(usage.get("tool_calls") or 0)
    profile_name = active_profile or "default"
    return _usage_footer_text(
        prompt_tokens=prompt_tokens,
        completion_tokens=completion_tokens,
        total_tokens=total_tokens,
        llm_seconds=llm_seconds,
        estimated=bool(usage.get("estimated")),
        llm_calls=llm_calls,
        tool_calls=tool_calls,
        active_profile=profile_name,
    )


# ============================================================================
# Token estimation functions
# ============================================================================

def estimate_tokens_from_text(text: str) -> int:
    """Estimate token count from text using 4-char-per-token heuristic."""
    if not text:
        return 0
    return max(1, math.ceil(len(text) / 4))


def estimate_prompt_tokens(messages: list[dict[str, Any]]) -> int:
    """Estimate token count from message list."""
    parts: list[str] = []
    for message in messages:
        role = str(message.get("role", ""))
        content = message.get("content", "")
        if isinstance(content, str):
            parts.append(f"{role}\n{content}")
        else:
            parts.append(f"{role}\n{json.dumps(content, ensure_ascii=False)}")
    return estimate_tokens_from_text("\n".join(parts))


def normalize_usage_payload(payload: dict[str, Any] | None) -> tuple[int, int, int] | None:
    """Normalize usage payload, handling both prompt_tokens/completion_tokens and input_tokens/output_tokens."""
    if not isinstance(payload, dict):
        return None
    prompt_tokens = payload.get("prompt_tokens")
    if prompt_tokens is None:
        prompt_tokens = payload.get("input_tokens")
    completion_tokens = payload.get("completion_tokens")
    if completion_tokens is None:
        completion_tokens = payload.get("output_tokens")
    total_tokens = payload.get("total_tokens")
    if total_tokens is None and prompt_tokens is not None and completion_tokens is not None:
        total_tokens = int(prompt_tokens) + int(completion_tokens)
    if prompt_tokens is None and completion_tokens is None and total_tokens is None:
        return None
    return (int(prompt_tokens or 0), int(completion_tokens or 0), int(total_tokens or 0))


# ============================================================================
# Model text extraction helpers
# ============================================================================

def flatten_model_content(value: Any) -> str:
    """Flatten model content to string."""
    return _flatten_model_content(value)


def extract_choice_text(choice: dict[str, Any] | None) -> str:
    """Extract text from model choice."""
    return _extract_choice_text(choice)


def extract_choice_reasoning(choice: dict[str, Any] | None) -> str:
    """Extract reasoning from model choice."""
    return _extract_choice_reasoning(choice)


def brief_model_error(exc: Exception) -> str:
    """Create a brief error message from exception, removing verbose context."""
    text = str(exc).strip()
    if "Last error:" in text:
        text = text.split("Last error:", 1)[-1].strip()
    if "Recent server log:" in text:
        text = text.split("Recent server log:", 1)[0].strip()
    return _truncate(text or exc.__class__.__name__, 280)


# ============================================================================
# Model discovery and validation
# ============================================================================

def model_label(model: str) -> str:
    """Get display label for model (filename if path, else model name)."""
    candidate = Path(model)
    if candidate.exists():
        return candidate.name
    return model


def discover_ollama_models() -> list[str]:
    """Discover Ollama models from running instance or manifest files."""
    models: list[str] = []

    def add_model(name: str) -> None:
        if name and name not in models:
            models.append(name)

    ollama_bin = shutil.which("ollama")
    if not ollama_bin:
        for candidate in ("/opt/homebrew/bin/ollama", "/usr/local/bin/ollama"):
            if Path(candidate).exists():
                ollama_bin = candidate
                break

    if ollama_bin:
        try:
            proc = subprocess.run(
                [ollama_bin, "list"],
                capture_output=True,
                text=True,
                timeout=10,
                check=False,
            )
        except Exception:
            proc = None
        if proc and proc.returncode == 0:
            for idx, line in enumerate(proc.stdout.splitlines()):
                stripped = line.strip()
                if not stripped:
                    continue
                if idx == 0 and stripped.lower().startswith("name"):
                    continue
                add_model(stripped.split()[0])
            if models:
                return models

    manifests_root = Path.home() / ".ollama" / "models" / "manifests" / "registry.ollama.ai"
    if manifests_root.exists():
        for path in manifests_root.rglob("*"):
            if not path.is_file():
                continue
            if path.name.startswith(".") or path.name == "Modelfile" or path.name.endswith(".Modelfile"):
                continue
            rel = path.relative_to(manifests_root).parts
            if len(rel) == 2:
                add_model(f"{rel[0]}:{rel[1]}")
            elif len(rel) >= 3:
                if rel[0] == "library":
                    add_model(f"{rel[1]}:{rel[2]}")
                else:
                    add_model(f"{rel[0]}/{rel[1]}:{rel[2]}")
    return models


def discover_lmstudio_models(host: str | None = None, port: int | None = None) -> list[tuple[str, str]]:
    """Discover models from a running LM Studio server.

    Returns list of (model_id, base_url) tuples.
    host/port are auto-detected if not provided: tries LMSTUDIO_HOST env,
    then common defaults (localhost:1234, localhost:11434-style variants).
    """
    import urllib.request
    import urllib.error

    candidates: list[str] = []
    if host and port:
        candidates = [f"http://{host}:{port}"]
    else:
        env_host = os.environ.get("LMSTUDIO_HOST", "").strip()
        if env_host:
            candidates = [env_host.rstrip("/")]
        else:
            candidates = [
                "http://localhost:1234",
                "http://127.0.0.1:1234",
                "http://localhost:11434",
            ]

    results: list[tuple[str, str]] = []
    for base in candidates:
        try:
            req = urllib.request.Request(
                f"{base}/v1/models",
                headers={"Authorization": "Bearer lm-studio"},
            )
            with urllib.request.urlopen(req, timeout=2) as resp:
                import json as _json
                data = _json.loads(resp.read().decode())
            for entry in data.get("data", []):
                model_id = entry.get("id", "")
                if model_id:
                    results.append((model_id, f"{base}/v1"))
        except Exception:
            continue
        if results:
            break
    return results


def infer_model_provider(model: str, default_provider: str = "mlx") -> str:
    """Infer model provider from model name or path."""
    candidate = Path(model)
    if candidate.exists():
        return "mlx"
    if model.startswith("lmstudio:"):
        return "lmstudio"
    if model in discover_ollama_models():
        return "ollama"
    if not model.startswith("/") and (":" in model or "/" in model):
        return "ollama"
    return default_provider


def discover_mlx_model_dirs() -> list[Path]:
    """Discover available MLX model directories from standard locations."""
    from mico.cli import MLX_MODEL_ROOTS

    model_dirs: list[Path] = []
    seen_realpaths: set[str] = set()

    def _add(entry: Path) -> None:
        try:
            resolved = str(entry.resolve())
        except OSError:
            resolved = str(entry)
        if resolved in seen_realpaths:
            return
        seen_realpaths.add(resolved)
        model_dirs.append(entry)

    for root in MLX_MODEL_ROOTS:
        if not root.exists():
            continue
        for entry in sorted(root.iterdir()):
            if not entry.is_dir():
                continue
            # HF cache format: models--org--name/snapshots/<hash>/
            if entry.name.startswith("models--"):
                snap = entry / "snapshots"
                if snap.exists():
                    for s in sorted(snap.iterdir()):
                        if s.is_dir():
                            _add(s)
                continue
            _add(entry)
    return model_dirs


def mlx_model_is_complete(model_dir: Path) -> bool:
    """Check if MLX model directory contains all required files."""
    if not model_dir.exists() or not model_dir.is_dir():
        return False
    safetensors = list(model_dir.glob("*.safetensors"))
    if safetensors:
        return True
    index_path = model_dir / "model.safetensors.index.json"
    if not index_path.exists():
        return False
    try:
        data = json.loads(index_path.read_text())
    except Exception:
        return False
    weight_map = data.get("weight_map", {}) if isinstance(data, dict) else {}
    if not isinstance(weight_map, dict) or not weight_map:
        return False
    shard_names = {str(name) for name in weight_map.values() if name}
    return all((model_dir / shard_name).exists() for shard_name in shard_names)


def model_name_tokens(name: str, stopwords: set[str] | None = None) -> list[str]:
    """Tokenize model name for matching and analysis."""
    from mico.cli import MODEL_NAME_STOPWORDS

    if stopwords is None:
        stopwords = MODEL_NAME_STOPWORDS
    return _model_name_tokens(name, stopwords=stopwords)


def is_draft_model_name(name: str) -> bool:
    """Check if model name indicates it's a draft/speculative model."""
    from mico.cli import DRAFT_MODEL_MARKERS

    return _is_draft_model_name(name, draft_model_markers=DRAFT_MODEL_MARKERS)


def read_model_type(model_path: Path) -> str:
    """Read model_type from model's config.json."""
    config_path = model_path / "config.json"
    if not config_path.exists():
        return ""
    try:
        data = json.loads(config_path.read_text())
    except Exception:
        return ""
    model_type = str(data.get("model_type") or "").strip().lower()
    if model_type:
        return model_type
    text_cfg = data.get("text_config")
    if isinstance(text_cfg, dict):
        return str(text_cfg.get("model_type") or "").strip().lower()
    return ""


def normalized_model_family(model_type: str) -> str:
    """Normalize model type to family (qwen, llama, gemma, etc)."""
    normalized = model_type.strip().lower()
    if not normalized:
        return ""
    for prefix in ("qwen", "gemma", "llama", "phi", "glm"):
        if normalized.startswith(prefix):
            return prefix
    return normalized.split("_", 1)[0]


def supported_model_types() -> set[str]:
    """Get set of model types supported by mlx_lm."""
    supported: set[str] = set()
    # Try to find mlx_lm models dir in any installed venv
    try:
        import mlx_lm.models as _mlx_models_pkg
        import inspect
        pkg_path = Path(inspect.getfile(_mlx_models_pkg)).parent
        for entry in pkg_path.iterdir():
            if entry.suffix == ".py" and entry.stem not in ("__init__", "__pycache__"):
                supported.add(entry.stem.lower())
        return supported
    except Exception:
        pass
    # Fallback: scan venv lib dirs
    from mico.cli import ROOT
    for py_ver in ("python3.13", "python3.12", "python3.11", "python3.10"):
        models_dir = ROOT / ".venv" / "lib" / py_ver / "site-packages" / "mlx_lm" / "models"
        if models_dir.exists():
            for entry in models_dir.iterdir():
                if entry.suffix == ".py" and entry.stem not in ("__init__", "__pycache__"):
                    supported.add(entry.stem.lower())
            return supported
    # Also try ~/.mico/.venv
    mico_home = Path(os.environ.get("MICO_HOME", str(Path.home() / ".mico")))
    for py_ver in ("python3.13", "python3.12", "python3.11", "python3.10"):
        models_dir = mico_home / ".venv" / "lib" / py_ver / "site-packages" / "mlx_lm" / "models"
        if models_dir.exists():
            for entry in models_dir.iterdir():
                if entry.suffix == ".py" and entry.stem not in ("__init__", "__pycache__"):
                    supported.add(entry.stem.lower())
            return supported
    return supported


def is_compatible_draft_model(base_path: Path, candidate_path: Path) -> bool:
    """Check if candidate is a compatible draft model for base model."""
    base_type = read_model_type(base_path)
    candidate_type = read_model_type(candidate_path)
    if not candidate_type:
        return False
    if candidate_type == "gemma4_assistant":
        return normalized_model_family(base_type) == "gemma"
    if candidate_type == "zaya" or "zaya" in candidate_path.name.lower():
        # zaya is a standalone draft architecture — compatible with any base
        return True
    if "dflash" in candidate_path.name.lower():
        return True
    supported_types = supported_model_types()
    if not base_type or candidate_type not in supported_types:
        return False
    return normalized_model_family(base_type) == normalized_model_family(candidate_type)


def draft_model_rank(name: str) -> tuple[int, str]:
    """Get rank/priority of draft model for sorting."""
    return _draft_model_rank(name)


def discover_draft_models(base_model: str, provider: str) -> list[Path]:
    """Discover compatible draft models for a base model."""
    if provider != "mlx":
        return []
    base_path = Path(base_model)
    if not base_path.exists():
        return []
    base_tokens = set(model_name_tokens(base_path.name))
    if not base_tokens:
        return []
    family_tokens = {token for token in base_tokens if any(ch.isalpha() for ch in token)}
    size_tokens = {token for token in base_tokens if __import__('re').search(r"\d+b$", token)}
    draft_matches: list[tuple[tuple[int, str], Path]] = []
    for candidate in discover_mlx_model_dirs():
        if candidate == base_path:
            continue
        if not is_draft_model_name(candidate.name):
            continue
        if not is_compatible_draft_model(base_path, candidate):
            continue
        candidate_tokens = set(model_name_tokens(candidate.name))
        shared = base_tokens & candidate_tokens
        if len(shared) < 2:
            continue
        if family_tokens and not (family_tokens & candidate_tokens):
            continue
        if size_tokens and not (size_tokens & candidate_tokens):
            continue
        draft_matches.append((draft_model_rank(candidate.name), candidate))
    draft_matches.sort(key=lambda item: item[0])
    return [path for _, path in draft_matches]


# ============================================================================
# Model selection and auto-promotion
# ============================================================================

def pick_auto_promote_model() -> str | None:
    """Pick best model for auto-promotion (deep profile)."""
    ranked: list[tuple[int, str]] = []
    for entry in discover_mlx_model_dirs():
        name = entry.name.lower()
        score = 0
        if "qwen3.6" in name:
            score += 5
        if "27b" in name:
            score += 4
        if "qwen" in name:
            score += 2
        if "abliterated" in name:
            score += 1
        if score > 0:
            ranked.append((score, str(entry)))
    if not ranked:
        return None
    ranked.sort(key=lambda item: item[0], reverse=True)
    return ranked[0][1]


def auto_promote_model_if_needed(
    state: Any,
    reason: str,
    active_profile: ProfileConfig | None = None,
) -> str:
    """Auto-promote model for deep reasoning if needed."""
    # This function needs access to external state and apply_model_profile
    # which should be imported from cli.py when called
    # Kept here as a signature reference; caller is responsible for importing apply_model_profile
    if not hasattr(state, 'auto_promoted'):
        return ""
    if state.auto_promoted:
        return ""

    from mico.cli import MODEL_PROVIDER, apply_model_profile

    if MODEL_PROVIDER != "mlx":
        return ""

    if active_profile is None or active_profile.name != "deep":
        try:
            apply_model_profile("deep")
            active_profile = None  # Would be set to ACTIVE_PROFILE in cli.py
        except Exception:
            pass

    promoted_model = pick_auto_promote_model()
    if promoted_model:
        try:
            if active_profile and "worker" in active_profile.roles:
                active_profile.roles["worker"].resolved_path = promoted_model
                active_profile.roles["worker"].model = promoted_model
            else:
                from mico.cli import select_startup_model
                select_startup_model(promoted_model, None)
        except Exception:
            pass

    state.auto_promoted = True
    state.active_model_profile = active_profile.name if active_profile else "default"
    target_label = model_label(promoted_model) if promoted_model else "deep-profile"
    state.decisions.append(f"Auto-promoted model due to {reason}: {target_label}")
    state.next_step = "Retry with promoted model and avoid repeating the previous failing step."
    return f"model upgraded to deep: {target_label}"
