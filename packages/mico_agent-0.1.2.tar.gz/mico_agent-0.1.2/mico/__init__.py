"""mico — local coding agent."""
from __future__ import annotations

try:
    from importlib.metadata import version as _pkg_version
    __version__ = _pkg_version("mico-agent")
except Exception:
    __version__ = "0.1.1"

# Re-export commonly used stdlib symbols for test patching compatibility.
import subprocess  # noqa: F401 — tests do patch.object(mico.subprocess, ...)
from pathlib import Path  # noqa: F401 — tests do mico.Path(...)

# Lazy proxy: any attribute not found here is looked up in mico.cli.
# This keeps `import mico` fast (no heavy CLI import at package load time)
# while letting tests access internal symbols via `mico.foo`.

_cli_mod = None


def _get_cli():
    global _cli_mod
    if _cli_mod is None:
        import importlib
        _cli_mod = importlib.import_module("mico.cli")
    return _cli_mod


_OUTPUT_ALIASES = {
    "_parse_git_status_paths": ("mico.output", "parse_git_status_paths"),
}


def __getattr__(name: str):
    if name in _OUTPUT_ALIASES:
        import importlib
        mod_name, attr = _OUTPUT_ALIASES[name]
        return getattr(importlib.import_module(mod_name), attr)
    # Fall through to cli for everything else
    try:
        return getattr(_get_cli(), name)
    except AttributeError:
        raise AttributeError(f"module 'mico' has no attribute {name!r}") from None


__all__ = ["__version__", "subprocess", "Path"]
