"""task_envelope — user-turn wrapper for local models.

Minimal enrichment: görev + çalışma dizini + git-shortcut hint.
Model hangi tool'u seçeceğine kendisi karar verir.
"""
from __future__ import annotations


_GOAL_TAG_HINTS: dict[str, str] = {
    "git_status":  "git_tool(op=status)",
    "git_log":     "git_tool(op=log)",
    "git_branch":  "git_tool(op=branch)",
    "git_diff":    "git_tool(op=diff)",
    "local_ip":    'bash(command="ipconfig getifaddr en0")',
    "hostname":    'bash(command="hostname")',
    "cwd":         'bash(command="pwd")',
    "whoami":      'bash(command="whoami")',
    "time":        'bash(command="date")',
}


def _resolve_paths_in_task(task: str, cwd: str | None) -> str:
    """Expand relative paths (with or without slashes) to absolute paths using cwd."""
    if not cwd:
        return task
    import re
    import os
    def _expand(m: "re.Match[str]") -> str:
        p = m.group(0)
        abs_p = os.path.join(cwd, p)
        if os.path.exists(abs_p):
            return abs_p
        return p
    # Match slash-based paths: mico/foo.py, mico/tool_dispatch.py etc.
    task = re.sub(r'\b(?:[a-zA-Z0-9_.-]+/)+[a-zA-Z0-9_.-]+\b', _expand, task)
    # Match bare filenames with known extensions that exist in cwd: todo_report.txt, result.txt etc.
    def _expand_bare(m: "re.Match[str]") -> str:
        p = m.group(0)
        abs_p = os.path.join(cwd, p)
        if os.path.exists(abs_p):
            return abs_p
        return p
    task = re.sub(r'\b[a-zA-Z0-9_-]+\.[a-zA-Z]{2,5}\b', _expand_bare, task)
    return task


def build_task_envelope(
    task: str,
    task_kind: str,
    goal_tag: str | None = None,
    *,
    cwd: str | None = None,
) -> str:
    body = task.strip()
    if cwd and task_kind not in {"trivial_chat", "brief_general"}:
        body = _resolve_paths_in_task(body, cwd)

    # Trivial/brief: sadece ham görevi ilet
    if task_kind in {"trivial_chat", "brief_general"}:
        return body

    parts: list[str] = [f"Task: {body}"]

    if cwd:
        parts.append(f"Working dir: {cwd}")

    # Sadece kesin bilinen shortcut'lar için tool hint ver
    if goal_tag and goal_tag in _GOAL_TAG_HINTS:
        parts.append(f"First tool: {_GOAL_TAG_HINTS[goal_tag]}")

    # Analiz/arama görevleri için flow ipucu
    if task_kind in {"agentic", "build", "test"} and not goal_tag:
        lower = body.lower()
        is_analysis = any(w in lower for w in (
            "tara", "bul", "analiz", "incele", "kontrol", "listele",
            "scan", "find", "analyze", "inspect", "check", "list", "detect"
        ))
        involves_file = any(w in lower for w in (
            ".py", ".js", ".ts", ".json", "dosya", "file", "module", "kod", "code"
        ))
        if is_analysis and involves_file:
            parts.append(
                "Approach: grep_code to locate patterns → read_file with offset/limit for relevant sections → final with findings."
            )

    return "\n".join(parts)
