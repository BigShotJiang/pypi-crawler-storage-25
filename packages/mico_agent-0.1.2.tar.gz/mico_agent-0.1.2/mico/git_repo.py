from __future__ import annotations

from pathlib import Path
from typing import Any, Callable


def git_repo_root(cwd: Path, *, run_subprocess: Callable[..., Any]) -> Path | None:
    try:
        proc = run_subprocess(["git", "rev-parse", "--show-toplevel"], cwd=cwd, timeout=10)
    except Exception:
        return None
    if proc.returncode != 0:
        return None
    out = proc.stdout.strip()
    return Path(out) if out else None
