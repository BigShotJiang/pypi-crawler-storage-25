from __future__ import annotations

from pathlib import Path
from typing import Any, Optional

try:
    import chromadb
    from chromadb.utils import embedding_functions
    _RAG_AVAILABLE = True
except ImportError:
    chromadb = None  # type: ignore[assignment]
    embedding_functions = None  # type: ignore[assignment]
    _RAG_AVAILABLE = False


class CodebaseRAG:
    def __init__(self, persist_directory: str = "~/.mico/rag_db"):
        if not _RAG_AVAILABLE:
            raise RuntimeError("RAG requires: pip install 'mico-agent[rag]'")
        self.persist_path = Path(persist_directory).expanduser()
        self.persist_path.mkdir(parents=True, exist_ok=True)

        self.client = chromadb.PersistentClient(path=str(self.persist_path))
        # Default embedding function: all-MiniLM-L6-v2 (fast and light)
        self.emb_fn = embedding_functions.SentenceTransformerEmbeddingFunction(
            model_name="all-MiniLM-L6-v2"
        )
        self.collection = self.client.get_or_create_collection(
            name="codebase",
            embedding_function=self.emb_fn
        )

    def index_file(self, file_path: Path, root_dir: Path):
        try:
            rel_path = file_path.relative_to(root_dir)
            content = file_path.read_text(encoding="utf-8", errors="replace")
            
            # Simple chunking by lines for now (e.g. 50 lines per chunk)
            lines = content.splitlines()
            chunk_size = 50
            for i in range(0, len(lines), chunk_size):
                chunk = "\n".join(lines[i:i + chunk_size])
                chunk_id = f"{rel_path}:{i}"
                
                self.collection.upsert(
                    ids=[chunk_id],
                    documents=[chunk],
                    metadatas=[{"path": str(rel_path), "line_start": i}]
                )
        except Exception:
            pass

    def index_directory(self, root_dir: Path, ignore_patterns: Optional[list[str]] = None):
        if ignore_patterns is None:
            ignore_patterns = [".git", "__pycache__", "node_modules", "venv", ".venv", "dist", "build"]
        
        for path in root_dir.rglob("*"):
            if any(p in path.parts for p in ignore_patterns):
                continue
            if path.is_file() and path.suffix in {".py", ".js", ".ts", ".go", ".c", ".cpp", ".rs", ".md", ".txt"}:
                self.index_file(path, root_dir)

    def query(self, query_text: str, n_results: int = 5) -> list[dict[str, Any]]:
        results = self.collection.query(
            query_texts=[query_text],
            n_results=n_results
        )
        
        formatted = []
        if results["documents"] and results["metadatas"]:
            for i in range(len(results["documents"][0])):
                formatted.append({
                    "content": results["documents"][0][i],
                    "metadata": results["metadatas"][0][i],
                    "id": results["ids"][0][i]
                })
        return formatted


_RAG_INSTANCE: Optional[CodebaseRAG] = None

def get_rag() -> CodebaseRAG:
    global _RAG_INSTANCE
    if _RAG_INSTANCE is None:
        _RAG_INSTANCE = CodebaseRAG()
    return _RAG_INSTANCE
