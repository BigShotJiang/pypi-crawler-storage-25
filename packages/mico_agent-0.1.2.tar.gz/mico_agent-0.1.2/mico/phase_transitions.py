from __future__ import annotations

import re
from typing import Any, Callable


def update_phase_after_tool(
    state: Any,
    action: dict[str, Any],
    result: str,
    *,
    error: bool,
    current_phase_entry: Callable[[Any], dict[str, Any]],
    phase_requires_goal_alignment: Callable[[Any, str], bool],
    result_supports_phase_goal: Callable[[str, dict[str, Any], str], bool],
    explicit_step_phase_active: Callable[[Any], bool],
    advance_phase: Callable[[Any, str], None],
    task_is_captive_portal_workflow: Callable[[str], bool],
    now_ts: Callable[[], int],
) -> None:
    phase = current_phase_entry(state)
    phase_name = str(phase.get("name", ""))
    phase_goal = str(phase.get("goal", ""))
    label = str(action.get("tool", ""))
    if error:
        phase["status"] = "active"
        state.next_step = str(phase.get("goal", state.next_step))
        return
    if phase_requires_goal_alignment(state, phase_name) and not result_supports_phase_goal(phase_goal, action, result):
        phase["status"] = "active"
        state.next_step = phase_goal or state.next_step
        state.checkpoints.append(
            {
                "phase": phase_name,
                "note": f"{label} did not yet satisfy the phase goal; continue with a different, goal-aligned step.",
                "created_at": now_ts(),
            }
        )
        return
    if explicit_step_phase_active(state) and label in {"http_request", "bash", "read_file", "grep_code", "parse_json_file", "macos_admin_task", "write_file", "replace_in_file"}:
        advance_phase(state, f"{label} produced evidence or output for `{phase_name}`.")
        return
    if task_is_captive_portal_workflow(state.goal):
        if phase_name == "redirect" and label in {"http_request", "bash"}:
            advance_phase(state, f"{label} confirmed the portal redirect target.")
            return
        if phase_name == "form" and label in {"read_file", "grep_code", "bash", "http_request"}:
            advance_phase(state, f"{label} extracted or narrowed the login form evidence.")
            return
        if phase_name == "measure" and label in {"http_request", "bash"}:
            advance_phase(state, f"{label} produced rejection timing evidence.")
            return
        if phase_name == "script" and label in {"write_file", "replace_in_file"}:
            advance_phase(state, f"{label} wrote the interval login script.")
            return
        if phase_name == "script" and label == "bash" and re.search(r"\b(py_compile|shellcheck|python3?\s+-m\s+py_compile)\b", str(action.get("command", ""))):
            advance_phase(state, f"{label} verified the interval script.")
            return
    if phase_name == "scope" and label in {"read_file", "list_files", "grep_code", "http_request", "bash", "macos_admin_task"}:
        advance_phase(state, f"{label} established the first scoped signal.")
        return
    if phase_name == "inspect" and label in {"read_file", "list_files", "grep_code", "parse_json_file", "bash", "http_request"}:
        advance_phase(state, f"{label} gathered the primary context.")
        return
    if phase_name == "probe" and label in {"http_request", "bash", "macos_admin_task"}:
        advance_phase(state, f"{label} collected a target probe result.")
        return
    if phase_name == "change" and label in {"write_file", "replace_in_file", "bash"}:
        advance_phase(state, f"{label} applied a concrete change.")
        return
    if phase_name == "verify" and label in {"bash", "read_file", "parse_json_file", "http_request"}:
        advance_phase(state, f"{label} produced verification evidence.")
        return
    if phase_name in {"findings", "assess", "plan"} and label in {"read_file", "grep_code", "bash", "http_request"}:
        advance_phase(state, f"{label} produced evidence to support the phase outcome.")
        return


def mark_pending_tool(
    state: Any,
    action: dict[str, Any],
    *,
    summarize_action: Callable[[dict[str, Any]], str],
    now_ts: Callable[[], int],
) -> None:
    state.pending_tool = {
        "tool": str(action.get("tool", "")),
        "summary": summarize_action(action),
        "phase": state.current_phase,
        "created_at": now_ts(),
    }
    state.checkpoints.append(
        {
            "phase": state.current_phase,
            "note": f"pending tool: {state.pending_tool['summary']}",
            "created_at": now_ts(),
        }
    )


def clear_pending_tool(state: Any, note: str = "", *, now_ts: Callable[[], int]) -> None:
    pending = state.pending_tool or {}
    if pending:
        state.checkpoints.append(
            {
                "phase": str(pending.get("phase", state.current_phase)),
                "note": note.strip() or f"tool completed: {pending.get('summary', '')}",
                "created_at": now_ts(),
            }
        )
    state.pending_tool = {}
