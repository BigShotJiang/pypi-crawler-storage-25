from __future__ import annotations

import json
import re
from json import JSONDecoder
from typing import Any, Callable

from mico.action_schemas import validate_action
from mico.capabilities import ModelCapabilities, ModelFormat

_MD_JSON_RE = re.compile(r"```(?:json)?\s*(\{.*?\})\s*```", re.DOTALL)
_XML_TOOL_RE = re.compile(r"<(tool|final|patch)(?:[^>]*)>(.*?)</\1>", re.DOTALL | re.IGNORECASE)


def normalize_action_schema(action: dict[str, Any]) -> dict[str, Any]:
    """Ensure action dict has a valid 'type' and 'tool' if applicable."""
    kind = str(action.get("type", "")).strip()
    if kind in {"final", "patch", "tool"}:
        return action
    
    # Legacy support for flattened tool calls
    legacy_tools = {
        "bash", "list_files", "read_file", "write_file", "replace_in_file", 
        "finish", "macos_admin_task", "grep_code", "http_request", "git_tool",
        "find_in_files", "create_dir", "move_file", "delete_file", "python_run",
        "env_info", "json_query"
    }
    if kind in legacy_tools:
        normalized = dict(action)
        normalized["type"] = "tool"
        normalized["tool"] = kind
        if kind == "finish" and "message" not in normalized:
            normalized["message"] = str(normalized.get("content", "")).strip()
        return normalized
    return action


def is_plain_text_response(text: str) -> bool:
    cleaned = text.strip()
    if not cleaned or len(cleaned) < 10:
        return False
    for idx, ch in enumerate(cleaned):
        if ch == "{":
            try:
                decoder = JSONDecoder()
                decoder.raw_decode(cleaned[idx:])
                return False
            except json.JSONDecodeError:
                continue
    return True


def extract_json(text: str, *, strip_thinking: Callable[[str], str]) -> dict[str, Any]:
    """Old entry point, now wraps the more advanced parsing logic."""
    # Since we don't have capabilities here, we assume default (MARKDOWN_JSON)
    caps = ModelCapabilities(format=ModelFormat.MARKDOWN_JSON)
    return parse_action(text, caps, strip_thinking=strip_thinking)


def parse_action(
    text: str, 
    caps: ModelCapabilities, 
    *, 
    strip_thinking: Callable[[str], str]
) -> dict[str, Any]:
    """Parse model response into a validated action dictionary."""
    cleaned = strip_thinking(text).strip()
    
    parsed_obj = None

    if caps.format == ModelFormat.XML:
        xml_match = _XML_TOOL_RE.search(cleaned)
        if xml_match:
            tag, content = xml_match.groups()
            if tag.lower() == "final":
                parsed_obj = {"type": "final", "message": content.strip()}
            elif tag.lower() == "patch":
                # Implementation for XML patch parsing if needed
                pass
            else:
                try:
                    parsed_obj = json.loads(content.strip())
                    parsed_obj["type"] = "tool"
                except json.JSONDecodeError:
                    pass

    if not parsed_obj:
        # Try markdown block (common for most models)
        md_match = _MD_JSON_RE.search(cleaned)
        if md_match:
            try:
                parsed_obj = json.loads(md_match.group(1))
            except json.JSONDecodeError:
                pass

    if not parsed_obj:
        # Try to find the outermost JSON object
        start_idx = cleaned.find("{")
        end_idx = cleaned.rfind("}")
        if start_idx != -1 and end_idx != -1 and end_idx > start_idx:
            json_str = cleaned[start_idx : end_idx + 1]
            try:
                decoder = JSONDecoder()
                obj, _ = decoder.raw_decode(json_str)
                if isinstance(obj, dict):
                    parsed_obj = obj
            except json.JSONDecodeError:
                pass

    if parsed_obj:
        normalized = normalize_action_schema(parsed_obj)
        try:
            validated = validate_action(normalized)
            import dataclasses
            return dataclasses.asdict(validated)
        except Exception as e:
            # If validation fails, we might want to return the raw normalized dict 
            # or raise an error so the model can be informed.
            # For now, let's raise to trigger a repair loop if Mico has one.
            raise ValueError(f"Action validation failed: {e}")

    # Fallback: If no valid JSON found but there's substantial text, treat as final message
    if len(cleaned) >= 5:
        return {"type": "final", "message": cleaned}

    raise ValueError(f"Model did not return valid JSON or actionable text:\n{cleaned}")

