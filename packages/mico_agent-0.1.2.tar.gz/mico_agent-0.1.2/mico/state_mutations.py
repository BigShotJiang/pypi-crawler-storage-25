from __future__ import annotations

from typing import Any, Callable


def update_state_after_tool(
    state: Any,
    action: dict[str, Any],
    result: str,
    artifact: dict[str, Any] | None,
    *,
    error: bool,
    track_tool_side_effects: Callable[[Any, dict[str, Any]], None],
    summarize_tool_payload: Callable[[str, str, str], str],
    task_goal_tag: Callable[[str], str],
    truncator: Callable[[str, int], str],
    dedupe_keep_order: Callable[[list[str]], list[str]],
) -> None:
    track_tool_side_effects(state, action)
    label = str(action.get("tool", "tool"))
    summary = summarize_tool_payload(label, result, task_goal_tag(state.goal))
    if artifact:
        state.artifacts.append(
            {
                "id": artifact["id"],
                "label": artifact["label"],
                "path": artifact["path"],
                "snippet": artifact["snippet"],
            }
        )
    if error:
        state.last_error = truncator(str(result).strip(), 400)
        state.open_questions.append(f"{label} failed: {truncator(str(result).strip(), 220)}")
        state.next_step = f"Recover from the {label} failure with a different targeted step."
    else:
        state.last_error = ""
        state.findings.append(f"{label}: {truncator(summary, 240)}")
        state.next_step = f"Use the latest {label} evidence to decide the next targeted action."
    state.files_touched = dedupe_keep_order(state.files_touched)
