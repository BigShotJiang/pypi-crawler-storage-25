"""Periodic MLX server health check — visibility only, no action."""
from __future__ import annotations

import threading
from typing import Optional, Callable

try:
    import requests
except ImportError:
    requests = None  # type: ignore

_thread: Optional[threading.Thread] = None
_stop_event = threading.Event()


def _watcher_loop(host: str, port: int, on_down: Optional[Callable[[], None]]) -> None:
    """Monitor server health every 10 seconds."""
    consecutive_down = 0
    while not _stop_event.wait(10.0):
        try:
            if requests is None:
                continue
            r = requests.get(f"http://{host}:{port}/v1/models", timeout=2)
            if r.status_code == 200:
                consecutive_down = 0
                continue
        except Exception:
            pass
        consecutive_down += 1
        if consecutive_down == 2:  # 20s of failures
            if on_down:
                try:
                    on_down()
                except Exception:
                    pass


def start(host: str = "127.0.0.1", port: int = 8080, on_down: Optional[Callable[[], None]] = None) -> None:
    """Start the server health watcher thread.

    Args:
        host: Server host (default: 127.0.0.1)
        port: Server port (default: 8080)
        on_down: Optional callback function when server is down
    """
    global _thread
    if _thread and _thread.is_alive():
        return
    _stop_event.clear()
    if on_down is None:
        def on_down():
            import sys
            sys.stderr.write("\n⚠ Model sunucusu yanıt vermiyor (~20sn).\n")
            sys.stderr.flush()
    _thread = threading.Thread(
        target=_watcher_loop,
        args=(host, port, on_down),
        daemon=True,
        name="mico-server-watcher"
    )
    _thread.start()


def stop() -> None:
    """Stop the server health watcher thread."""
    _stop_event.set()
