"""MLX sunucu yaşam döngüsü — başlat, sağlamlık kontrolü, sıkı kapat.

Eski `bin/qwen36-session` shell script'inin Python karşılığı. Avantajları:
  - Ctrl+D / SIGINT'te güvenilir kapatma (TERM → wait → KILL)
  - PID dosyası kontrolü, port çakışması tespiti
  - Yeniden başlatma race-condition korumalı

Tüm çağrılar non-fatal: sunucu zaten çalışıyorsa dokunmaz, çağıran taraf
URL üzerinden konuşur.
"""
from __future__ import annotations

import json
import os
import signal
import socket
import subprocess
import sys
import time
import urllib.request
import urllib.error
from pathlib import Path

from .model_recommender import Profile

CONFIG_DIR = Path(os.environ.get("MICO_HOME", str(Path.home() / ".mico")))
PID_FILE = CONFIG_DIR / "server.pid"
PORT_FILE = CONFIG_DIR / "server.port"
LOG_FILE = CONFIG_DIR / "logs" / "server.log"

# mtplx CLI binary always listens on this port (no --port flag support)
MTPLX_BINARY_PORT = 8000

# Sırayla denenen sabit port listesi. İlk boş olan seçilir.
CANDIDATE_PORTS = [
    8080, 8081, 8082, 8083, 8084, 8085, 8086, 8087, 8088, 8089,
    8090, 8091, 8092, 8093, 8094, 8095, 8096, 8097, 8098, 8099,
    8100, 8101, 8102, 8103, 8104, 8105, 8106, 8107, 8108, 8109,
    8110, 8111, 8112, 8113, 8114, 8115, 8116, 8117, 8118, 8119,
    8120, 8121, 8122, 8123, 8124, 8125, 8126, 8127, 8128, 8129,
]


def _is_pid_alive(pid: int) -> bool:
    if pid <= 0:
        return False
    try:
        os.kill(pid, 0)
        return True
    except (OSError, ProcessLookupError):
        return False


def _read_pid() -> int:
    if not PID_FILE.exists():
        return 0
    try:
        return int(PID_FILE.read_text().strip())
    except (OSError, ValueError):
        return 0


def _read_port() -> int:
    """Son başarılı server portunu döner; bulamazsa 0."""
    if not PORT_FILE.exists():
        return 0
    try:
        return int(PORT_FILE.read_text().strip())
    except (OSError, ValueError):
        return 0


def _write_port(port: int) -> None:
    PORT_FILE.parent.mkdir(parents=True, exist_ok=True)
    PORT_FILE.write_text(str(port), encoding="utf-8")


def _port_open(host: str, port: int, timeout: float = 0.3) -> bool:
    try:
        with socket.create_connection((host, port), timeout=timeout):
            return True
    except OSError:
        return False


def _http_ready(host: str, port: int, timeout: float = 2.0) -> bool:
    """Port açık olsa da model henüz yüklenmemiş olabilir; HTTP 200 gelene kadar bekle."""
    try:
        req = urllib.request.Request(f"http://{host}:{port}/v1/models")
        with urllib.request.urlopen(req, timeout=timeout) as resp:
            return resp.status == 200
    except Exception:
        return False


def _port_owner_pid(port: int) -> int:
    """Port'u dinleyen process'in PID'ini döner; bulamazsa 0."""
    try:
        result = subprocess.run(
            ["lsof", "-nP", f"-iTCP:{port}", "-sTCP:LISTEN", "-t"],
            capture_output=True, text=True, timeout=5,
        )
        for line in result.stdout.splitlines():
            line = line.strip()
            if line.isdigit():
                return int(line)
    except Exception:
        pass
    return 0


def find_free_port(host: str = "127.0.0.1") -> int:
    """Her zaman 7000'i kullan. Başkası tutuyorsa öldür ve portu boşalt."""
    preferred = 7000
    our_pid = _read_pid()
    owner = _port_owner_pid(preferred)
    if owner == 0 or owner == our_pid:
        return preferred
    # Another process holds 8080 — kill it so we can reclaim the port
    sys.stdout.write(f"  port {preferred} başka process tarafından kullanılıyor (pid {owner}), kapatılıyor...\n")
    sys.stdout.flush()
    try:
        os.kill(owner, signal.SIGTERM)
        for _ in range(20):
            time.sleep(0.2)
            if _port_owner_pid(preferred) == 0:
                break
        else:
            os.kill(owner, signal.SIGKILL)
            time.sleep(0.3)
    except (OSError, ProcessLookupError):
        pass
    return preferred


def active_port(host: str = "127.0.0.1") -> int:
    """Hâlâ ayakta olan server portunu döner; yoksa 0."""
    # mtplx binary externally started on port 8000 (no PID tracking needed)
    if _http_ready(host, MTPLX_BINARY_PORT):
        return MTPLX_BINARY_PORT
    pid = _read_pid()
    if not pid or not _is_pid_alive(pid):
        return 0
    saved = _read_port()
    if saved and _port_open(host, saved):
        return saved
    # Port dosyası eskiyse tüm adayları tara
    for port in CANDIDATE_PORTS:
        if _port_open(host, port) and _port_owner_pid(port) == pid:
            return port
    return 0


def is_running(host: str = "127.0.0.1") -> bool:
    """Server ayakta ve HTTP'ye hazır mı?"""
    port = active_port(host)
    if not port:
        return False
    return _http_ready(host, port)


def _resolve_python(require_module: str = "mlx_lm") -> str:
    """Verilen modülün kurulu olduğu Python yorumlayıcısını döner.

    Arama sırası:
      1. ~/.mico/.venv/bin/python
      2. ~/.mico/python pointer dosyası (dependency_consent'in kaydettiği donor)
      3. sys.executable
      4. /opt/homebrew/bin/python3, /usr/local/bin/python3, /usr/bin/python3
    """
    candidates: list[str] = []

    venv_python = CONFIG_DIR / ".venv" / "bin" / "python"
    if venv_python.exists():
        candidates.append(str(venv_python))

    pointer = CONFIG_DIR / "python"
    if pointer.exists():
        try:
            p = pointer.read_text(encoding="utf-8").strip()
            if p and p not in candidates:
                candidates.append(p)
        except OSError:
            pass

    if sys.executable not in candidates:
        candidates.append(sys.executable)

    for extra in ("/opt/homebrew/bin/python3", "/usr/local/bin/python3", "/usr/bin/python3"):
        if extra not in candidates:
            candidates.append(extra)

    for py in candidates:
        try:
            res = subprocess.run(
                [py, "-c", f"import {require_module}"],
                capture_output=True, timeout=10,
            )
            if res.returncode == 0:
                return py
        except (subprocess.TimeoutExpired, OSError):
            continue

    # Hiçbirinde bulunamadı — sys.executable'a düş, caller hata verir
    return sys.executable


def _probe_supported_flags(python: str, vlm: bool = False) -> set[str]:
    """`mlx_lm server --help` (veya mlx_vlm.server) çıktısını parse eder."""
    if vlm:
        candidates = ([python, "-m", "mlx_vlm.server", "--help"],)
    else:
        candidates = (
            [python, "-m", "mlx_lm", "server", "--help"],
            [python, "-m", "mlx_lm.server", "--help"],
        )
    for cmd in candidates:
        try:
            res = subprocess.run(cmd, capture_output=True, text=True, timeout=20)
        except (subprocess.TimeoutExpired, OSError):
            continue
        out = (res.stdout or "") + (res.stderr or "")
        if "--model" in out:
            import re
            return set(re.findall(r"--[a-z][a-z0-9-]+", out))
    return set()


def _server_invocation(python: str, vlm: bool = False) -> list[str]:
    """Model tipine göre doğru server modülünü döner."""
    if vlm:
        return [python, "-m", "mlx_vlm.server"]
    try:
        res = subprocess.run(
            [python, "-m", "mlx_lm", "server", "--help"],
            capture_output=True, timeout=15,
        )
        if res.returncode == 0:
            return [python, "-m", "mlx_lm", "server"]
    except (subprocess.TimeoutExpired, OSError):
        pass
    return [python, "-m", "mlx_lm.server"]


def _check_mlx_lm_version(python: str) -> None:
    """Seçilen Python'da mlx_lm'in minimum versiyon olup olmadığını kontrol et.

    Minimum versiyon: 0.21.0 (qwen3 desteği bu versiyonda geldi).
    Yetersizse kullanıcı-dostu hata mesajı göster ve RuntimeError fırla.
    """
    try:
        res = subprocess.run(
            [python, "-c", "import mlx_lm; print(mlx_lm.__version__)"],
            capture_output=True, text=True, timeout=10,
        )
    except (subprocess.TimeoutExpired, OSError) as e:
        raise RuntimeError(
            f"mlx_lm versiyonu kontrol edilemedi: {e}"
        )

    if res.returncode != 0:
        raise RuntimeError(
            "mlx_lm bulunamadı veya import başarısız oldu. "
            "`pip install mlx-lm` ile kurun."
        )

    version_str = res.stdout.strip()
    if not version_str:
        raise RuntimeError(
            "mlx_lm.__version__ boş döndü; mlx_lm kurulumu hatalı."
        )

    # Versiyon string'ini parse et (ör. "0.21.0" → [0, 21, 0])
    try:
        parts = [int(x) for x in version_str.split(".")[:3]]
        while len(parts) < 3:
            parts.append(0)
        major, minor, patch = parts[0], parts[1], parts[2]
    except (ValueError, IndexError):
        raise RuntimeError(
            f"mlx_lm versiyonu parse edilemedi: '{version_str}'. "
            "Lütfen mlx_lm'i yeniden kurun."
        )

    # Minimum 0.21.0 olmalı
    if (major, minor, patch) < (0, 21, 0):
        raise RuntimeError(
            f"mlx_lm versiyonu çok eski ({version_str}). "
            f"Güncellemek için: pip install --upgrade mlx-lm"
        )


def _is_mtplx_model(model_path: str) -> bool:
    """MTPLX (native multi-token prediction) model mi?

    Tanıma imzaları (öncelik sırasına göre):
      1. Klasör adında "mtplx" geçiyor (en güvenilir)
      2. config.json'da mtplx_version / mtplx_profile anahtarı var
      3. config.json'da model_type "mtplx" içeriyor

    NOT: "-mtp" suffix'i tek başına yeterli değil — mxfp8/mlx formatındaki MTP
    modeller (ör. Qwopus-mtp) rapid-mlx ile çalışır, mtplx gerektirmez.
    num_draft_layers da tek başına yeterli değil; mlx_lm kendi MTP'si için kullanır.
    """
    name_lower = Path(model_path).name.lower()
    if "mtplx" in name_lower:
        return True
    config_path = Path(model_path) / "config.json"
    if config_path.exists():
        try:
            cfg = json.loads(config_path.read_text(encoding="utf-8"))
            if "mtplx_version" in cfg or "mtplx_profile" in cfg:
                return True
            if "mtplx" in str(cfg.get("model_type", "")).lower():
                return True
        except (OSError, json.JSONDecodeError):
            pass
    return False


def _is_vlm_model(model_path: str) -> bool:
    """VLM (vision/multimodal) model mi?

    Sadece `model_type` yeterli değil. Özellikle Gemma4 text modelleri `gemma4`
    model_type'ı taşıyabiliyor; bunları ancak açık vision/multimodal sinyali
    varsa `mlx_vlm` tarafına yönlendirmek gerekir.
    """
    if _is_mtplx_model(model_path):
        return False  # MTPLX modellerini VLM olarak işleme
    config_path = Path(model_path) / "config.json"
    if not config_path.exists():
        name = Path(model_path).name.lower()
        return any(k in name for k in ("vlm", "vision", "vl", "pixtral", "llava", "qwen-vl", "minicpm-v", "internvl"))
    try:
        cfg = json.loads(config_path.read_text(encoding="utf-8"))
        model_type = cfg.get("model_type", "").lower()
        # Known VLM model_type values
        vlm_types = {
            "llava", "llava_next", "idefics", "pixtral", "qwen2_vl", "qwen2_5_vl",
            "internvl_chat", "phi3_v", "minicpmv", "mllama", "paligemma",
            "idefics3", "smolvlm", "florence2", "moondream",
        }
        if model_type in vlm_types:
            return True
        # Architectures check — sadece açıkça vision/multimodal mimarileri
        archs = [a.lower() for a in cfg.get("architectures", [])]
        vlm_arch_keywords = ("forvision", "visionlanguage", "vlm", "llava", "pixtral",
                             "qwen2vl", "qwen2_5vl", "internvlchat", "minicpmv",
                             "mllama", "paligemma", "smolvlm", "florence2")
        if any(any(kw in a for kw in vlm_arch_keywords) for a in archs):
            return True
        # Gemma4: text ve multimodal varyantlar aynı model_type altında gelebiliyor.
        if model_type == "gemma4":
            return any(key in cfg for key in ("vision_config", "image_token_index", "mm_tokens_per_image"))
        return False
    except (OSError, json.JSONDecodeError):
        return False


# rapid-mlx (vllm_mlx) tarafından desteklenen model ailelerinin regex listesi.
# Kaynak: vllm_mlx/model_auto_config.py _MODEL_PATTERNS (rapid-mlx 0.6.54).
# Her yeni rapid-mlx sürümünde bu listeyi güncelle.
import re as _re  # noqa: E402

_RAPID_MLX_SUPPORTED_PATTERNS: list[_re.Pattern] = [p for p in [
    _re.compile(r"deepseek",        _re.IGNORECASE),
    _re.compile(r"qwopus",          _re.IGNORECASE),
    _re.compile(r"qwen3",           _re.IGNORECASE),
    _re.compile(r"glm[-_]?4",       _re.IGNORECASE),
    _re.compile(r"minimax",         _re.IGNORECASE),
    _re.compile(r"gpt[-_]?oss",     _re.IGNORECASE),
    _re.compile(r"kimi",            _re.IGNORECASE),
    _re.compile(r"magistral",       _re.IGNORECASE),
    _re.compile(r"mistral|devstral",_re.IGNORECASE),
    _re.compile(r"gemma[-_]?[234]", _re.IGNORECASE),  # gemma-3n dahil
    _re.compile(r"hermes",          _re.IGNORECASE),
    _re.compile(r"llama",           _re.IGNORECASE),
    _re.compile(r"phi[-_]?[34]",    _re.IGNORECASE),
    _re.compile(r"granite[-_]?4",   _re.IGNORECASE),
    _re.compile(r"smollm3",         _re.IGNORECASE),
    _re.compile(r"nemotron",        _re.IGNORECASE),
    _re.compile(r"bonsai",          _re.IGNORECASE),
]]


def _resolve_python_for_vllm() -> str | None:
    """vllm_mlx'in kurulu olduğu Python'u döner; bulamazsa None."""
    py = _resolve_python(require_module="vllm_mlx")
    # _resolve_python bulamazsa sys.executable döner; orada da yoksa None
    try:
        res = subprocess.run([py, "-c", "import vllm_mlx"], capture_output=True, timeout=5)
        return py if res.returncode == 0 else None
    except (subprocess.TimeoutExpired, OSError):
        return None


def _rapid_mlx_package_available(python: str | None = None) -> bool:
    """vllm_mlx kurulu mu? python verilirse sadece onu dener, yoksa tüm adayları tarar."""
    if python is not None:
        try:
            res = subprocess.run(
                [python, "-c", "import vllm_mlx"],
                capture_output=True, timeout=5,
            )
            return res.returncode == 0
        except (subprocess.TimeoutExpired, OSError):
            return False
    return _resolve_python_for_vllm() is not None


def _is_rapid_mlx_supported_model(model_path: str) -> bool:
    """Model adı/yolu rapid-mlx'in desteklediği bir aileye ait mi?

    Hem klasör adına hem de config.json'daki model_type'a bakılır.
    Listesi _RAPID_MLX_SUPPORTED_PATTERNS'dan türetilir.
    """
    name = Path(model_path).name
    # config.json'daki model_type'ı da kontrol et
    config_path = Path(model_path) / "config.json"
    model_type = ""
    if config_path.exists():
        try:
            cfg = json.loads(config_path.read_text(encoding="utf-8"))
            model_type = cfg.get("model_type", "") or ""
        except (OSError, json.JSONDecodeError):
            pass

    for pat in _RAPID_MLX_SUPPORTED_PATTERNS:
        if pat.search(name) or (model_type and pat.search(model_type)):
            return True
    return False


def _is_rapid_mlx_model(model_path: str) -> bool:
    """rapid-mlx (vllm_mlx) runner kullanılmalı mı?

    İki koşulun ikisi de sağlanmalı:
      1. vllm_mlx paketi kurulu (rapid-mlx pip paketi gerekli)
      2. Model, rapid-mlx'in desteklediği bir aileye ait

    mtplx ve mlx_vlm zaten önce kontrol edildiğinden bu fonksiyon
    yalnızca text modeller için çağrılır.
    """
    if not _is_rapid_mlx_supported_model(model_path):
        return False
    python = _resolve_python()
    return _rapid_mlx_package_available(python)


def _select_runner_kind(model_path: str, *, rapid_mlx_available: bool | None = None) -> str:
    """Select the local runner family for a model path.

    Returns one of: `mtplx`, `mlx_vlm`, `rapid_mlx`, `mlx_lm`.
    This is the pure routing decision used by startup and smoke tests.
    """
    if _is_mtplx_model(model_path):
        return "mtplx"
    if _is_vlm_model(model_path):
        return "mlx_vlm"
    if _is_rapid_mlx_supported_model(model_path):
        if rapid_mlx_available is None:
            python = _resolve_python()
            if _rapid_mlx_package_available(python):
                return "rapid_mlx"
        elif rapid_mlx_available:
            return "rapid_mlx"
    return "mlx_lm"


def _check_rapid_mlx_deps(python: str) -> None:
    """rapid-mlx (vllm_mlx) kurulu mu kontrol et, yoksa kur. Onay caller'dan alınmış olmalı."""
    if _rapid_mlx_package_available(python):
        return

    sys.stdout.write("\nrapid-mlx kuruluyor...\n")
    sys.stdout.flush()
    try:
        result = subprocess.run(
            [python, "-m", "pip", "install", "--upgrade", "rapid-mlx"],
            timeout=300,
        )
    except subprocess.TimeoutExpired:
        raise RuntimeError("rapid-mlx kurulumu zaman aşımına uğradı.")

    if result.returncode != 0:
        raise RuntimeError(
            "rapid-mlx kurulumu başarısız.\n"
            "Manuel kurulum: pip install rapid-mlx"
        )
    sys.stdout.write("✓ rapid-mlx kuruldu.\n\n")


def _rapid_mlx_server_invocation(python: str) -> list[str]:
    """rapid-mlx server başlatma komutunu döner."""
    return [python, "-m", "vllm_mlx.server"]


def _check_mtplx_deps(python: str) -> None:
    """mtplx paketi kurulu mu kontrol et, yoksa kullanıcıya sor ve kur."""
    try:
        res = subprocess.run(
            [python, "-c", "import mtplx"],
            capture_output=True, timeout=10,
        )
        if res.returncode == 0:
            return
    except (subprocess.TimeoutExpired, OSError):
        pass

    sys.stdout.write("\n⚠  MTPLX modeli algılandı — 'mtplx' paketi gerekiyor.\n")
    sys.stdout.write("   Paket boyutu: ~1 MB\n\n")
    sys.stdout.write("   Kurmak istiyor musun? [Y/n]: ")
    sys.stdout.flush()
    try:
        ans = input().strip().lower()
    except (EOFError, KeyboardInterrupt):
        sys.stdout.write("\n")
        raise RuntimeError("mtplx kurulumu iptal edildi — MTPLX modeli kullanılamaz.")

    if ans and not (ans.startswith("y") or ans in {"e", "evet"}):
        raise RuntimeError(
            "mtplx kurulumu reddedildi.\n"
            "MTPLX modeli kullanmak için: pip install mtplx"
        )

    sys.stdout.write("\nmtplx kuruluyor...\n")
    sys.stdout.flush()
    try:
        result = subprocess.run(
            [python, "-m", "pip", "install", "--upgrade", "mtplx"],
            timeout=300,
        )
    except subprocess.TimeoutExpired:
        raise RuntimeError("mtplx kurulumu zaman aşımına uğradı.")

    if result.returncode != 0:
        raise RuntimeError(
            "mtplx kurulumu başarısız.\n"
            "Manuel kurulum: pip install mtplx"
        )
    sys.stdout.write("✓ mtplx kuruldu.\n\n")


def _find_mtplx_binary() -> str | None:
    """mtplx CLI binary'sini PATH ve bilinen konumlarda arar."""
    import shutil
    found = shutil.which("mtplx")
    if found:
        return found
    # ~/.mico/.venv/bin/mtplx — venv PATH'e eklenmemişse buraya bak
    venv_bin = CONFIG_DIR / ".venv" / "bin" / "mtplx"
    if venv_bin.exists():
        return str(venv_bin)
    return None


def _mtplx_server_invocation(python: str) -> list[str]:
    """MTPLX server başlatma komutunu döner.

    mtplx CLI binary varsa quickstart ile başlatır (fork gerektirmez).
    Yoksa Python paketine düşer.
    """
    binary = _find_mtplx_binary()
    if binary:
        # quickstart = API-only server (no browser/chat UI).
        # performance-cold + --max = no patched MLX fork required.
        return [binary, "quickstart", "--profile", "performance-cold", "--max"]
    return [python, "-c", "from mtplx.server.openai import main; main()"]


_UNSUPPORTED_MODEL_TYPES: dict[str, str] = {
    "gemma4_assistant": (
        "gemma4_assistant modeli (Gemma4AssistantForCausalLM) mlx_lm server tarafından "
        "desteklenmiyor. Bu mimari yalnızca speculative decoding draft modeli olarak "
        "tasarlanmış olup standalone çalışmaz.\n"
        "Çözüm: Ana model olarak gemma-4-e4b-it-4bit seç, "
        "draft olarak gemma-4-E4B-it-assistant-bf16 kullan."
    ),
}


def _check_model_runner(model_path: str) -> None:
    """Model tipini kontrol et; desteklenmeyen mimari ise RuntimeError fırlat."""
    config_path = Path(model_path) / "config.json"
    if not config_path.exists():
        return
    try:
        cfg = json.loads(config_path.read_text(encoding="utf-8"))
    except Exception:
        return
    model_type = str(cfg.get("model_type") or "").strip().lower()
    if model_type in _UNSUPPORTED_MODEL_TYPES:
        raise RuntimeError(_UNSUPPORTED_MODEL_TYPES[model_type])


def _check_model_deps(python: str, model_path: str) -> None:
    """Model tipine göre gerekli backend paketini kontrol et, yoksa kullanıcıya sor ve kur.

    VLM (gemma4, llava, vb.) → mlx_vlm gerektirir.
    Text-only → mlx_lm (zaten kontrol edilmiş).
    """
    if not _is_vlm_model(model_path):
        return

    # Check if mlx_vlm is importable in the target python
    try:
        res = subprocess.run(
            [python, "-c", "import mlx_vlm"],
            capture_output=True, timeout=10,
        )
        if res.returncode == 0:
            return  # Already installed
    except (subprocess.TimeoutExpired, OSError):
        pass

    model_name = Path(model_path).name
    sys.stdout.write(f"\n⚠  '{model_name}' bir VLM (görsel-dil) modelidir.\n")
    sys.stdout.write("   mlx_lm yerine mlx-vlm server gerekiyor.\n")
    sys.stdout.write("   Paket boyutu: ~30 MB\n\n")
    sys.stdout.write("   Kurmak istiyor musun? [Y/n]: ")
    sys.stdout.flush()
    try:
        ans = input().strip().lower()
    except (EOFError, KeyboardInterrupt):
        sys.stdout.write("\n")
        raise RuntimeError("mlx-vlm kurulumu iptal edildi — VLM modeli kullanılamaz.")

    if ans and not (ans.startswith("y") or ans in {"e", "evet"}):
        raise RuntimeError(
            "mlx-vlm kurulumu reddedildi.\n"
            "VLM modeli kullanmak için: pip install mlx-vlm"
        )

    sys.stdout.write("\nmlx-vlm kuruluyor...\n")
    sys.stdout.flush()
    try:
        result = subprocess.run(
            [python, "-m", "pip", "install", "--upgrade", "mlx-vlm"],
            timeout=300,
        )
    except subprocess.TimeoutExpired:
        raise RuntimeError("mlx-vlm kurulumu zaman aşımına uğradı.")

    if result.returncode != 0:
        raise RuntimeError(
            "mlx-vlm kurulumu başarısız.\n"
            "Manuel kurulum: pip install mlx-vlm"
        )
    sys.stdout.write("✓ mlx-vlm kuruldu.\n\n")


def _fix_model_config(model_path: str) -> None:
    """Model config.json'daki bilinen uyumsuz model_type değerlerini otomatik düzelt.

    Bazı HuggingFace modelleri (örn. lukey03/Qwen3.5-9B-abliterated-MLX-4bit)
    config.json'da mlx_lm tarafından tanınmayan model_type değerleri içerebilir.
    Bu fonksiyon bilinen uyumsuzlukları düzeltir.

    Eğer dosya yoksa veya okuma hatası olursa sessizce geçer.
    Değişiklik yapılırsa stderr'e kısa bir log yazar.
    """
    # Bilinen uyumsuz model_type → düzeltilmiş değer eşlemeleri
    KNOWN_REMAPPINGS = {
        "qwen3_5_text": "qwen3_5",
        "qwen3_5_text_vl": "qwen3_5",
        # gemma4_assistant: mlx_lm desteklemiyor; gemma4_text backbone'u ile
        # çalışmaya çalışır ama masked_embedding/projection katmanları eksik olduğu
        # için yükleme başarısız olur. Bu model draft-only olarak tasarlanmış,
        # standalone server modunda kullanılamaz.
        # "gemma4_assistant": "gemma4_text",  # disabled: weight mismatch
    }

    config_path = Path(model_path) / "config.json"
    if not config_path.exists():
        return

    try:
        config_data = json.loads(config_path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError):
        return

    old_model_type = config_data.get("model_type")
    if old_model_type not in KNOWN_REMAPPINGS:
        return

    new_model_type = KNOWN_REMAPPINGS[old_model_type]
    config_data["model_type"] = new_model_type

    try:
        config_path.write_text(
            json.dumps(config_data, indent=2, ensure_ascii=False) + "\n",
            encoding="utf-8"
        )
        print(
            f"Model config.json fixed: model_type '{old_model_type}' → '{new_model_type}'",
            file=sys.stderr
        )
    except OSError:
        pass


_FROGGERIC_CHAT_TEMPLATE = (
    "{%- set image_count = namespace(value=0) %}"
    "{%- set video_count = namespace(value=0) %}"
    "{%- macro render_content(content, do_vision_count, is_system_content=false) %}"
    "{%- if content is string %}{{- content }}"
    "{%- elif content is iterable and content is not mapping %}"
    "{%- for item in content %}"
    "{%- if 'image' in item or 'image_url' in item or item.type == 'image' %}"
    "{%- if is_system_content %}{{- raise_exception('System message cannot contain images.') }}{%- endif %}"
    "{%- if do_vision_count %}{%- set image_count.value = image_count.value + 1 %}{%- endif %}"
    "{%- if add_vision_id is defined and add_vision_id %}{{- 'Picture ' ~ image_count.value ~ ': ' }}{%- endif %}"
    "{{- '<|vision_start|><|image_pad|><|vision_end|>' }}"
    "{%- elif 'video' in item or item.type == 'video' %}"
    "{%- if is_system_content %}{{- raise_exception('System message cannot contain videos.') }}{%- endif %}"
    "{%- if do_vision_count %}{%- set video_count.value = video_count.value + 1 %}{%- endif %}"
    "{%- if add_vision_id is defined and add_vision_id %}{{- 'Video ' ~ video_count.value ~ ': ' }}{%- endif %}"
    "{{- '<|vision_start|><|video_pad|><|vision_end|>' }}"
    "{%- elif 'text' in item %}{{- item.text }}"
    "{%- else %}{{- raise_exception('Unexpected item type in content.') }}{%- endif %}"
    "{%- endfor %}"
    "{%- elif content is none or content is undefined %}{{- '' }}"
    "{%- else %}{{- raise_exception('Unexpected content type.') }}{%- endif %}"
    "{%- endmacro %}"
    "{%- set ns_flags = namespace(enable_thinking=true, has_tools=false, last_tool_failed=false, consecutive_failures=0) %}"
    "{%- if enable_thinking is defined %}{%- set ns_flags.enable_thinking = enable_thinking %}{%- endif %}"
    "{%- if not messages %}{{- raise_exception('No messages provided.') }}{%- endif %}"
    "{%- set system_content = '' %}{%- set has_system = false %}"
    "{%- if messages[0].role == 'system' or messages[0].role == 'developer' %}"
    "{%- set has_system = true %}"
    "{%- set system_content = render_content(messages[0].content, false, true)|trim %}"
    "{%- if '<|think_off|>' in system_content %}{%- set ns_flags.enable_thinking = false %}"
    "{%- set system_content = system_content | replace('<|think_off|>', '') %}{%- endif %}"
    "{%- if '<|think_on|>' in system_content %}{%- set ns_flags.enable_thinking = true %}"
    "{%- set system_content = system_content | replace('<|think_on|>', '') %}{%- endif %}"
    "{%- set system_content = system_content | trim %}{%- endif %}"
    "{%- if tools and tools is iterable and tools is not mapping %}{%- set ns_flags.has_tools = true %}"
    "{{- '<|im_start|>system\\n' }}{{- \"# Tools\\n\\nYou have access to the following functions:\\n\\n<tools>\" }}"
    "{%- for tool in tools %}{{- '\\n' }}{%- set fn = tool.function if tool.function is defined else tool %}{{- fn | tojson }}{%- endfor %}"
    "{{- \"\\n</tools>\" }}"
    "{%- set tool_instructions %}If you choose to call a function ONLY reply in the following format with NO suffix:\\n\\n<think>\\nBrief explanation of tool call\\n</think>\\n<tool_call>\\n<function=example_function_name>\\n<parameter=example_parameter_1>\\nvalue_1\\n</parameter>\\n</function>\\n</tool_call>\\n\\n<IMPORTANT>\\nReminder:\\n- ALL explanation and reasoning MUST be inside <think></think>.\\n- Function calls MUST follow the specified format.\\n- If you have gathered all necessary data, answer immediately after </think>.\\n</IMPORTANT>{%- endset %}"
    "{{- '\\n\\n' ~ tool_instructions | trim }}"
    "{%- if has_system and system_content %}{{- '\\n\\n' + system_content }}{%- endif %}"
    "{{- '<|im_end|>\\n' }}"
    "{%- elif has_system and system_content %}{{- '<|im_start|>system\\n' + system_content + '<|im_end|>\\n' }}{%- endif %}"
    "{%- for message in messages %}"
    "{%- set is_system = (message.role == \"system\" or message.role == \"developer\") %}"
    "{%- set content = render_content(message.content, true, is_system)|trim %}"
    "{%- if '<|think_off|>' in content %}{%- set ns_flags.enable_thinking = false %}{%- set content = content | replace('<|think_off|>', '') | trim %}"
    "{%- elif '<|think_on|>' in content %}{%- set ns_flags.enable_thinking = true %}{%- set content = content | replace('<|think_on|>', '') | trim %}{%- endif %}"
    "{%- if is_system %}{%- if not loop.first and content %}{{- '<|im_start|>system\\n' + content + '<|im_end|>\\n' }}{%- endif %}"
    "{%- elif message.role == \"user\" %}{{- '<|im_start|>' + message.role + '\\n' + content + '<|im_end|>\\n' }}"
    "{%- set ns_flags.last_tool_failed = false %}{%- set ns_flags.consecutive_failures = 0 %}"
    "{%- elif message.role == \"assistant\" %}{%- set ns_flags.last_tool_failed = false %}"
    "{%- set reasoning_content = '' %}"
    "{%- if message.reasoning_content is string %}{%- set reasoning_content = message.reasoning_content %}"
    "{%- else %}{%- set think_end_token = '' %}"
    "{%- if '</think>' in content %}{%- set think_end_token = '</think>' %}"
    "{%- elif '</thinking>' in content %}{%- set think_end_token = '</thinking>' %}"
    "{%- elif '</ think>' in content %}{%- set think_end_token = '</ think>' %}"
    "{%- elif '</think >' in content %}{%- set think_end_token = '</think >' %}{%- endif %}"
    "{%- if think_end_token %}{%- set reasoning_parts = content.split(think_end_token) %}"
    "{%- set reasoning_content = reasoning_parts[0] %}{%- set content = reasoning_parts[1:] | join(think_end_token) %}"
    "{%- if '<think>' in reasoning_content %}{%- set r_prefix = reasoning_content.split('<think>')[0] | trim %}"
    "{%- set reasoning_content = reasoning_content.split('<think>')[1:] | join('<think>') | trim %}"
    "{%- set content = (r_prefix ~ '\\n' ~ content) | trim %}{%- endif %}"
    "{%- elif '<think>' in content %}{%- set prefix = content.split('<think>')[0] %}"
    "{%- set think_part = content.split('<think>')[1:] | join('<think>') %}"
    "{%- if '<tool_call>' in think_part %}{%- set reasoning_content = think_part.split('<tool_call>')[0] %}"
    "{%- set content = prefix ~ '\\n<tool_call>' ~ think_part.split('<tool_call>')[1:] | join('<tool_call>') %}"
    "{%- else %}{%- set reasoning_content = think_part %}{%- set content = prefix %}{%- endif %}{%- endif %}{%- endif %}"
    "{%- set reasoning_content = reasoning_content | trim %}{%- set content = content | trim %}"
    "{%- if message.tool_calls and message.tool_calls is iterable and message.tool_calls is not mapping %}"
    "{%- if '<tool_call>' in content %}{%- set content = content.split('<tool_call>')[0] | trim %}{%- endif %}{%- endif %}"
    "{%- set show_think = true %}"
    "{%- if preserve_thinking is defined and preserve_thinking == false %}{%- set show_think = false %}{%- endif %}"
    "{%- if not reasoning_content %}{%- set show_think = false %}{%- endif %}"
    "{%- if show_think and ns_flags.enable_thinking is not false %}"
    "{%- if content %}{{- '<|im_start|>' + message.role + '\\n<think>\\n' + reasoning_content + '\\n</think>\\n' + content }}"
    "{%- else %}{{- '<|im_start|>' + message.role + '\\n<think>\\n' + reasoning_content + '\\n</think>' }}{%- endif %}"
    "{%- else %}{%- if content %}{{- '<|im_start|>' + message.role + '\\n' + content }}"
    "{%- else %}{{- '<|im_start|>' + message.role }}{%- endif %}{%- endif %}"
    "{%- if message.tool_calls and message.tool_calls is iterable and message.tool_calls is not mapping %}"
    "{%- for tool_call in message.tool_calls %}{%- if tool_call.function is defined %}{%- set tool_call = tool_call.function %}{%- endif %}"
    "{{- '\\n<tool_call>\\n' }}{{- '<function=' ~ tool_call.name ~ '>\\n' }}"
    "{%- if tool_call.arguments is defined and tool_call.arguments is mapping %}"
    "{%- if tool_call.arguments | length > 0 %}{%- for args_name in tool_call.arguments %}"
    "{%- set args_value = tool_call.arguments[args_name] %}{{- '<parameter=' ~ args_name ~ '>\\n' }}"
    "{%- set args_value = args_value | tojson if args_value is mapping or (args_value is iterable and args_value is not string) else args_value | string %}"
    "{{- args_value }}{{- '\\n</parameter>\\n' }}{%- endfor %}{%- endif %}"
    "{%- elif tool_call.arguments is defined and tool_call.arguments is string %}"
    "{%- if tool_call.arguments | trim | length > 0 %}{{- tool_call.arguments }}{{- '\\n' }}{%- endif %}{%- endif %}"
    "{{- '</function>\\n</tool_call>' }}{%- endfor %}{%- endif %}"
    "{{- '<|im_end|>\\n' }}"
    "{%- elif message.role == \"tool\" %}"
    "{%- set content_lower = content | lower %}"
    "{%- if content | length < 500 and '$ ' not in content and 'took ' not in content_lower"
    " and ('\"error\":' in content_lower or 'error:' in content_lower or 'exception:' in content_lower"
    " or 'traceback' in content_lower or 'command not found' in content_lower"
    " or 'invalid syntax' in content_lower or 'failed to' in content_lower) %}"
    "{%- set ns_flags.last_tool_failed = true %}"
    "{%- set ns_flags.consecutive_failures = ns_flags.consecutive_failures + 1 %}"
    "{%- else %}{%- set ns_flags.last_tool_failed = false %}{%- set ns_flags.consecutive_failures = 0 %}{%- endif %}"
    "{%- if loop.index0 > 0 and messages[loop.index0 - 1].role != \"tool\" %}{{- '<|im_start|>user' }}{%- endif %}"
    "{{- '\\n<tool_response>\\n' }}{{- content }}"
    "{%- if ns_flags.last_tool_failed %}"
    "{%- if ns_flags.consecutive_failures >= 2 %}"
    "{{- '\\n\\n⚠️ SYSTEM WARNING: ' ~ ns_flags.consecutive_failures ~ ' consecutive tool errors detected. You MUST use a fundamentally different approach.' }}"
    "{%- else %}{{- '\\n\\n⚠️ SYSTEM WARNING: The previous tool call returned an error. Diagnose and retry with corrected arguments.' }}{%- endif %}{%- endif %}"
    "{{- '\\n</tool_response>' }}"
    "{%- if not loop.last and messages[loop.index0 + 1].role != \"tool\" %}{{- '<|im_end|>\\n' }}"
    "{%- elif loop.last %}{{- '<|im_end|>\\n' }}{%- endif %}"
    "{%- else %}{{- raise_exception('Unexpected message role.') }}{%- endif %}"
    "{%- endfor %}"
    "{%- if add_generation_prompt %}{{- '<|im_start|>assistant\\n' }}"
    "{%- if ns_flags.enable_thinking is false %}{{- '<think>\\n</think>\\n' }}"
    "{%- elif ns_flags.last_tool_failed and ns_flags.consecutive_failures >= 2 %}{{- '<think>\\n</think>\\n' }}"
    "{%- else %}{{- '<think>\\n' }}{%- endif %}{%- endif %}"
)


def _is_qwen35_or_36(model_path: str) -> bool:
    """Model adına göre Qwen3.5 veya Qwen3.6 olup olmadığını tespit eder."""
    name = Path(model_path).name.lower()
    return "qwen3.5" in name or "qwen3_5" in name or "qwen3.6" in name or "qwen3_6" in name


def _patch_chat_template(model_path: str) -> None:
    """Qwen3.5/3.6 modellerine froggeric fixed chat template'ini uygular.

    tokenizer_config.json'da chat_template yoksa veya Qwen varsayılan
    basit template'i varsa froggeric template'ini yazar. Zaten doğru
    template varsa dokunmaz.
    """
    if not _is_qwen35_or_36(model_path):
        return
    tc_path = Path(model_path) / "tokenizer_config.json"
    if not tc_path.exists():
        return
    try:
        tc = json.loads(tc_path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError):
        return

    existing = tc.get("chat_template", "")
    # Zaten froggeric template uygulanmışsa dokunma
    if existing and "ns_flags" in existing and "last_tool_failed" in existing:
        return

    tc["chat_template"] = _FROGGERIC_CHAT_TEMPLATE
    try:
        tc_path.write_text(json.dumps(tc, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
        print(
            f"[mico] chat_template patched (froggeric): {Path(model_path).name}",
            file=sys.stderr,
        )
    except OSError:
        pass


def _read_log_tail(n: int = 20) -> str:
    """LOG_FILE'ın son n satırını döner; dosya yoksa boş string."""
    if not LOG_FILE.exists():
        return f"(log dosyası yok: {LOG_FILE})"
    try:
        lines = LOG_FILE.read_text(encoding="utf-8", errors="replace").splitlines()
        tail = lines[-n:] if len(lines) > n else lines
        header = f"--- son {len(tail)} satır: {LOG_FILE} ---\n"
        return header + "\n".join(tail)
    except OSError:
        return f"(log okunamadı: {LOG_FILE})"


def start(profile: Profile, *, host: str = "127.0.0.1", backend: str = "mlx") -> int:
    """Boş port bulup MLX sunucusunu başlatır. Seçilen portu döner.

    Eğer server zaten çalışıyorsa mevcut portu döner.
    """
    # Reuse running server: either our managed process or external mtplx binary
    if _http_ready(host, MTPLX_BINARY_PORT):
        return MTPLX_BINARY_PORT
    if _read_pid() and is_running(host):
        return active_port(host)

    if backend != "mlx":
        raise RuntimeError(f"Bu sürümde {backend} backend için server lifecycle desteği yok.")
    if not profile.model_path:
        raise RuntimeError("Profil model_path boş. `mico setup` ile yeniden ayarlayın.")

    _check_model_runner(profile.model_path)
    _fix_model_config(profile.model_path)
    _patch_chat_template(profile.model_path)

    port = find_free_port(host)

    LOG_FILE.parent.mkdir(parents=True, exist_ok=True)
    PID_FILE.parent.mkdir(parents=True, exist_ok=True)

    python = _resolve_python()

    # Detect runner: mtplx > rapid_mlx > mlx_vlm > mlx_lm
    initial_runner = _select_runner_kind(profile.model_path, rapid_mlx_available=False)
    use_mtplx = initial_runner == "mtplx"
    use_vlm = initial_runner == "mlx_vlm"

    rapid_supported = initial_runner == "mlx_lm" and _is_rapid_mlx_supported_model(profile.model_path)
    rapid_python: str | None = None
    if rapid_supported:
        # vllm_mlx'i bulabilen Python'u tüm adaylarda ara (mlx_lm'den farklı venv'de olabilir)
        rapid_python = _resolve_python_for_vllm()
        if rapid_python is None:
            # Model destekleniyor ama hiçbir yerde kurulu değil — sor ve kur
            sys.stdout.write(
                "\n[mico] Bu model için rapid-mlx (vllm_mlx) öneriliyor ama kurulu değil.\n"
                "       rapid-mlx: daha yüksek throughput, speculative decoding desteği.\n"
                "       Kurmak istiyor musun? [Y/n]: "
            )
            sys.stdout.flush()
            try:
                ans = input().strip().lower()
            except (EOFError, KeyboardInterrupt):
                sys.stdout.write("\n")
                ans = "n"
            if not ans or ans.startswith("y") or ans in {"e", "evet"}:
                _check_rapid_mlx_deps(python)  # mevcut python'a kur
                rapid_python = python
                use_rapid = True
            else:
                sys.stdout.write("  → mlx_lm ile devam ediliyor.\n\n")
                use_rapid = False
        else:
            use_rapid = True
    else:
        use_rapid = False

    if use_mtplx:
        using_binary = bool(_find_mtplx_binary())
        sys.stdout.write("  runner: mtplx (native MTP model)\n")
        base_cmd = _mtplx_server_invocation(python)
        if using_binary:
            port = MTPLX_BINARY_PORT
            args = base_cmd + ["--model", profile.model_path, "--port", str(port)]
        else:
            _check_mtplx_deps(python)
            args = base_cmd + [
                "--model", profile.model_path,
                "--host", host,
                "--port", str(port),
            ]
            # mtplx Python paketi flagleri
            if profile.max_tokens:
                args += ["--max-tokens", str(profile.max_tokens)]
            if profile.context_window:
                args += ["--context-window", str(profile.context_window)]
            if profile.temperature != 0.0:
                args += ["--temperature", str(profile.temperature)]

    elif use_rapid:
        _rpy = rapid_python or python
        sys.stdout.write(f"  runner: rapid-mlx / vllm_mlx (high-throughput text model) [{_rpy}]\n")
        args = _rapid_mlx_server_invocation(_rpy) + [
            "--model", profile.model_path,
            "--host", host,
            "--port", str(port),
            "--no-mllm",  # force text-only; prevents auto-detection routing hybrid models as MLLM
        ]
        # rapid-mlx desteklenen flagler
        if profile.max_tokens:
            args += ["--max-tokens", str(profile.max_tokens)]
        if profile.prefill_step_size:
            args += ["--prefill-step-size", str(profile.prefill_step_size)]
        if profile.temperature != 0.0:
            args += ["--default-temperature", str(profile.temperature)]
        # top_p / top_k profile'da yoksa rapid-mlx default kullanır
        # min_p, prompt-cache, kv_bits: rapid-mlx desteklemiyor

    elif use_vlm:
        _check_model_deps(python, profile.model_path)
        sys.stdout.write("  runner: mlx_vlm (vision/multimodal model)\n")
        supported = _probe_supported_flags(python, vlm=True)

        def _add_vlm(flag: str, value: str | int | None) -> None:
            if value is None or value == "" or value == 0:
                return
            if flag in supported:
                args.extend([flag, str(value)])

        args = _server_invocation(python, vlm=True) + [
            "--model", profile.model_path,
            "--host", host,
            "--port", str(port),
        ]
        _add_vlm("--max-tokens", profile.max_tokens)
        _add_vlm("--prefill-step-size", profile.prefill_step_size)
        _add_vlm("--kv-bits", profile.kv_bits)
        _add_vlm("--max-kv-size", getattr(profile, "max_kv_size", None))
        draft_path = getattr(profile, "draft_model_path", "") or ""
        if draft_path:
            if "--draft-model" not in supported:
                sys.stdout.write("  ⚠ Bu mlx_vlm sürümü --draft-model desteklemiyor. Güncelle: pip install --upgrade mlx-vlm\n")
            elif not Path(draft_path).exists():
                sys.stdout.write(f"  ⚠ Draft model bulunamadı: {draft_path} — speculative devre dışı.\n")
            else:
                args.extend(["--draft-model", draft_path])
                sys.stdout.write(f"  speculative decoding: {Path(draft_path).name}\n")

    else:
        _check_mlx_lm_version(python)
        sys.stdout.write("  runner: mlx_lm (text model)\n")
        supported = _probe_supported_flags(python, vlm=False)

        def _add(flag: str, value: str | int | None) -> None:
            if value is None or value == "" or value == 0:
                return
            if flag in supported:
                args.extend([flag, str(value)])

        args = _server_invocation(python, vlm=False) + [
            "--model", profile.model_path,
            "--host", host,
            "--port", str(port),
        ]
        _add("--max-tokens", profile.max_tokens)
        _add("--prefill-step-size", profile.prefill_step_size)
        _add("--prompt-cache-size", profile.prompt_cache_size)
        _add("--prompt-cache-bytes", profile.prompt_cache_bytes)
        _add("--kv-bits", profile.kv_bits)
        _add("--max-kv-size", getattr(profile, "max_kv_size", None))
        _add("--temp", profile.temperature)
        _add("--min-p", getattr(profile, "min_p", 0.0))
        draft_path = getattr(profile, "draft_model_path", "") or ""
        num_draft = getattr(profile, "num_draft_tokens", 0) or 0
        if draft_path:
            if "--draft-model" not in supported:
                sys.stdout.write("  ⚠ Bu mlx_lm sürümü --draft-model desteklemiyor. Güncelle: pip install --upgrade mlx-lm\n")
            elif not Path(draft_path).exists():
                sys.stdout.write(f"  ⚠ Draft model bulunamadı: {draft_path} — speculative devre dışı.\n")
            else:
                args.extend(["--draft-model", draft_path])
                effective_draft_tokens = num_draft if num_draft > 0 else 4
                if "--num-draft-tokens" in supported:
                    args.extend(["--num-draft-tokens", str(effective_draft_tokens)])
                sys.stdout.write(f"  speculative decoding: {Path(draft_path).name} ({effective_draft_tokens} draft token)\n")
        elif num_draft > 0:
            _add("--num-draft-tokens", num_draft)

    def _launch(cmd: list[str]) -> "subprocess.Popen[bytes]":
        fh = open(LOG_FILE, "ab", buffering=0)
        p = subprocess.Popen(
            cmd,
            stdout=fh, stderr=fh, stdin=subprocess.DEVNULL,
            preexec_fn=os.setsid if hasattr(os, "setsid") else None,
            close_fds=True,
        )
        fh.close()
        return p

    proc = _launch(args)
    PID_FILE.write_text(str(proc.pid), encoding="utf-8")
    _write_port(port)

    deadline = time.time() + 180
    last_dot = time.time()
    sys.stdout.write("  model yükleniyor ")
    sys.stdout.flush()
    while time.time() < deadline:
        if proc.poll() is not None:
            sys.stdout.write("\n")
            log_tail = _read_log_tail(20)
            raise RuntimeError(
                f"MLX server beklenmedik şekilde çıktı (returncode={proc.returncode}).\n"
                f"{log_tail}"
            )
        if _port_open(host, port) and _http_ready(host, port):
            sys.stdout.write(" hazır\n")
            sys.stdout.flush()
            return port
        now = time.time()
        if now - last_dot >= 2.0:
            sys.stdout.write(".")
            sys.stdout.flush()
            last_dot = now
        time.sleep(0.4)
    sys.stdout.write("\n")
    log_tail = _read_log_tail(20)
    raise RuntimeError(f"MLX server 180sn içinde hazır olmadı.\n{log_tail}")


def stop(*, grace_seconds: float = 3.0) -> None:
    """Çalışan sunucuyu sıkı kapat: TERM → wait → KILL.

    Process group olarak öldürür (preexec_fn=setsid sayesinde) — child proc'lar da gider.
    KV cache MLX server tarafından otomatik bırakılır.
    """
    pid = _read_pid()
    if not pid or not _is_pid_alive(pid):
        try:
            PID_FILE.unlink(missing_ok=True)
            PORT_FILE.unlink(missing_ok=True)
        except OSError:
            pass
        return

    pgid = pid
    try:
        pgid = os.getpgid(pid)
    except (OSError, ProcessLookupError):
        pass

    # SIGTERM
    try:
        os.killpg(pgid, signal.SIGTERM)
    except (OSError, ProcessLookupError):
        try:
            os.kill(pid, signal.SIGTERM)
        except OSError:
            pass

    # Wait
    deadline = time.time() + grace_seconds
    while time.time() < deadline:
        if not _is_pid_alive(pid):
            break
        time.sleep(0.1)

    # SIGKILL if still alive
    if _is_pid_alive(pid):
        try:
            os.killpg(pgid, signal.SIGKILL)
        except (OSError, ProcessLookupError):
            try:
                os.kill(pid, signal.SIGKILL)
            except OSError:
                pass
        for _ in range(20):
            if not _is_pid_alive(pid):
                break
            time.sleep(0.05)

    try:
        PID_FILE.unlink(missing_ok=True)
        PORT_FILE.unlink(missing_ok=True)
    except OSError:
        pass


def restart(profile: Profile, *, host: str = "127.0.0.1") -> int:
    stop()
    return start(profile, host=host)


# ============================================================================
# CLI lifecycle functions — moved from cli.py
# ============================================================================

import errno  # noqa: E402
import threading  # noqa: E402
import requests  # noqa: E402


def is_port_open(host: str, port: int) -> bool:
    """Check if a port is open via socket connection."""
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as sock:
        sock.settimeout(0.3)
        return sock.connect_ex((host, port)) == 0


def read_server_pid() -> int | None:
    """Read server PID from disk. Checks SESSION_SERVER_PID_PATH first, then SERVER_PID_PATH."""
    from mico.cli import SESSION_SERVER_PID_PATH, SERVER_PID_PATH

    path = SESSION_SERVER_PID_PATH if SESSION_SERVER_PID_PATH.exists() else SERVER_PID_PATH
    if not path.exists():
        return None
    try:
        raw = path.read_text().strip()
    except OSError:
        return None
    if not raw.isdigit():
        return None
    return int(raw)


def process_exists(pid: int) -> bool:
    """Check if process with given PID exists."""
    try:
        os.kill(pid, 0)
    except OSError as exc:
        if exc.errno == errno.EPERM:
            return True
        return False
    return True


def is_mico_server_process(pid: int) -> bool:
    """Check if PID is a mico server process (mlx_lm or mlx_vlm server)."""
    from mico.cli import MODEL, DRAFT_MODEL

    if pid <= 0:
        return False
    try:
        proc = subprocess.run(
            ["ps", "-p", str(pid), "-o", "command="],
            capture_output=True,
            text=True,
            timeout=5,
        )
    except Exception:
        managed_pid = read_server_pid()
        return managed_pid == pid and process_exists(pid)
    if proc.returncode != 0:
        return False
    command = proc.stdout.strip()
    if "server" not in command or MODEL not in command:
        return False
    if "mlx_lm" not in command and "mlx_vlm" not in command:
        return False
    if DRAFT_MODEL:
        return "--draft-model" in command and DRAFT_MODEL in command
    return "--draft-model" not in command


def listening_pids(port: int) -> list[int]:
    """Get list of PIDs listening on the given port."""
    try:
        proc = subprocess.run(
            ["lsof", "-nP", f"-iTCP:{port}", "-sTCP:LISTEN", "-t"],
            capture_output=True,
            text=True,
            timeout=5,
        )
    except Exception:
        return []
    if proc.returncode != 0:
        return []
    pids: list[int] = []
    for raw in proc.stdout.splitlines():
        raw = raw.strip()
        if raw.isdigit():
            pids.append(int(raw))
    return pids


def expected_mlx_server_running() -> bool:
    """Check if MLX server is expected and actually running."""
    from mico.cli import MODEL_PROVIDER, PORT

    if MODEL_PROVIDER != "mlx":
        return True
    return any(is_mico_server_process(pid) for pid in listening_pids(PORT))


def clear_server_pid_file() -> None:
    """Remove server PID file."""
    from mico.cli import SERVER_PID_PATH

    try:
        SERVER_PID_PATH.unlink(missing_ok=True)
    except OSError:
        pass


def mico_session_env() -> dict[str, str]:
    """Build environment dict for server session subprocess."""
    from mico.cli import (
        MODEL, DRAFT_MODEL, MODEL_PROVIDER, PORT,
        PREFILL_STEP_SIZE, SERVER_PREFILL_STEP_SIZE,
        SERVER_KV_BITS, SERVER_KV_QUANT_SCHEME, SERVER_KV_GROUP_SIZE,
        SERVER_MAX_KV_SIZE, SERVER_QUANTIZED_KV_START,
        SERVER_PROMPT_CACHE_SIZE, SERVER_PROMPT_CACHE_BYTES,
    )

    env = os.environ.copy()
    env["MODEL_NAME"] = MODEL
    env["DRAFT_MODEL_NAME"] = DRAFT_MODEL
    env["MODEL_PROVIDER"] = MODEL_PROVIDER
    env["PORT"] = str(PORT)
    env["PREFILL_STEP_SIZE"] = str(PREFILL_STEP_SIZE)
    env["SERVER_PREFILL_STEP_SIZE"] = str(SERVER_PREFILL_STEP_SIZE)
    env["SERVER_KV_BITS"] = str(SERVER_KV_BITS)
    env["SERVER_KV_QUANT_SCHEME"] = str(SERVER_KV_QUANT_SCHEME)
    env["SERVER_KV_GROUP_SIZE"] = str(SERVER_KV_GROUP_SIZE)
    env["SERVER_MAX_KV_SIZE"] = str(SERVER_MAX_KV_SIZE)
    env["SERVER_QUANTIZED_KV_START"] = str(SERVER_QUANTIZED_KV_START)
    env["SERVER_PROMPT_CACHE_SIZE"] = str(SERVER_PROMPT_CACHE_SIZE)
    env["SERVER_PROMPT_CACHE_BYTES"] = str(SERVER_PROMPT_CACHE_BYTES)
    return env


# Global state for active model response
_ACTIVE_RESPONSE: requests.Response | None = None
_ACTIVE_RESPONSE_LOCK = threading.Lock()


def set_active_model_response(response: requests.Response | None) -> None:
    """Store active model response for tracking."""
    global _ACTIVE_RESPONSE
    with _ACTIVE_RESPONSE_LOCK:
        _ACTIVE_RESPONSE = response


def close_active_model_response() -> None:
    """Close active model response if present."""
    with _ACTIVE_RESPONSE_LOCK:
        response = _ACTIVE_RESPONSE
    if response is None:
        return
    try:
        response.close()
    except Exception:
        pass


def stop_managed_server(force: bool = False) -> None:
    """Release server session via qwen36-session manager."""
    from mico.cli import (
        SESSION_MANAGER, ROOT,
    )
    import mico.cli as cli_module

    if not cli_module.SERVER_SESSION_ACQUIRED:
        return
    try:
        subprocess.run(
            [str(SESSION_MANAGER), "force-release" if force else "release"],
            cwd=str(ROOT),
            env=mico_session_env(),
            capture_output=True,
            text=True,
            timeout=5 if force else 30,
            check=False,
        )
    except Exception:
        return
    cli_module.SERVER_SESSION_ACQUIRED = False
    cli_module.SERVER_STARTED_BY_QCODEX = False


def write_mico_heartbeat() -> None:
    """Write mico heartbeat JSON (PID + timestamp)."""
    from mico.cli import LOGS_DIR, MICO_HEARTBEAT_PATH

    try:
        LOGS_DIR.mkdir(parents=True, exist_ok=True)
        payload = {"pid": os.getpid(), "updated_at": int(time.time())}
        MICO_HEARTBEAT_PATH.write_text(json.dumps(payload))
    except OSError:
        pass


def start_mico_heartbeat() -> None:
    """Start heartbeat thread if not already running."""
    import mico.cli as cli_module

    if cli_module.MICO_HEARTBEAT_THREAD is not None and cli_module.MICO_HEARTBEAT_THREAD.is_alive():
        return
    cli_module.MICO_HEARTBEAT_STOP.clear()

    def _loop() -> None:
        while not cli_module.MICO_HEARTBEAT_STOP.is_set():
            write_mico_heartbeat()
            cli_module.MICO_HEARTBEAT_STOP.wait(5.0)

    cli_module.MICO_HEARTBEAT_THREAD = threading.Thread(target=_loop, name="mico-heartbeat", daemon=True)
    cli_module.MICO_HEARTBEAT_THREAD.start()


def clear_mico_heartbeat() -> None:
    """Stop heartbeat and remove heartbeat file."""
    import mico.cli as cli_module
    from mico.cli import MICO_HEARTBEAT_PATH

    cli_module.MICO_HEARTBEAT_STOP.set()
    try:
        MICO_HEARTBEAT_PATH.unlink(missing_ok=True)
    except OSError:
        pass


def shutdown_on_exit() -> None:
    """Cleanup on interpreter shutdown."""
    clear_mico_heartbeat()
    import mico.cli as cli_module
    if cli_module.SERVER_STOP_ON_EXIT:
        stop_managed_server()


def release_server_now() -> None:
    """Force server release (hard shutdown)."""
    import mico.cli as cli_module
    if not cli_module.SERVER_STOP_ON_EXIT:
        return
    close_active_model_response()
    clear_mico_heartbeat()
    stop_managed_server(force=True)


def ensure_server() -> None:
    """Ensure MLX server is running via session manager."""
    from mico.cli import (
        MODEL_PROVIDER, SESSIONS_DIR, PATCHES_DIR, LOGS_DIR,
        SESSION_MANAGED_EXTERNALLY, SERVER_HOST, PORT,
        SERVER_LOG, SESSION_MANAGER, ROOT,
    )
    import mico.cli as cli_module

    SESSIONS_DIR.mkdir(parents=True, exist_ok=True)
    PATCHES_DIR.mkdir(parents=True, exist_ok=True)
    LOGS_DIR.mkdir(parents=True, exist_ok=True)

    if MODEL_PROVIDER == "ollama":
        return
    # mico runs the server lifecycle externally (mico.server) — never call the
    # legacy bin/qwen36-session script. Trust that the server is up if the
    # caller marked the session as external.
    if SESSION_MANAGED_EXTERNALLY:
        return
    if cli_module.SERVER_SESSION_ACQUIRED and expected_mlx_server_running():
        return
    if is_port_open(SERVER_HOST, PORT) and not expected_mlx_server_running():
        # Import here to avoid circular dependency
        from mico.cli import render_log_line, COLOR_PLAN
        render_log_line("server", "unexpected process owns model port; asking session manager to repair it", COLOR_PLAN)

    proc = subprocess.run(
        [str(SESSION_MANAGER), "acquire"],
        cwd=str(ROOT),
        env=mico_session_env(),
        capture_output=True,
        text=True,
        timeout=180,
        check=False,
    )
    if proc.returncode != 0:
        detail = proc.stderr.strip() or proc.stdout.strip() or read_server_log_tail()
        raise RuntimeError(f"Server failed to start.\n{detail}")

    cli_module.SERVER_SESSION_ACQUIRED = True
    cli_module.SERVER_STARTED_BY_QCODEX = True
    start_mico_heartbeat()

    deadline = time.time() + 120
    while time.time() < deadline:
        if expected_mlx_server_running():
            return
        time.sleep(1)

    try:
        subprocess.run(
            [str(SESSION_MANAGER), "release"],
            cwd=str(ROOT),
            env=mico_session_env(),
            capture_output=True,
            text=True,
            timeout=30,
            check=False,
        )
    except Exception:
        pass
    cli_module.SERVER_SESSION_ACQUIRED = False
    cli_module.SERVER_STARTED_BY_QCODEX = False
    raise RuntimeError(f"Server failed to start. Check log: {SERVER_LOG}")


def read_server_log_tail(lines: int = 30) -> str:
    """Read last N lines of server log."""
    from mico.cli import SERVER_LOG

    if not SERVER_LOG.exists():
        return "(server log not available)"
    content = SERVER_LOG.read_text(errors="replace").splitlines()
    return "\n".join(content[-lines:]) or "(server log empty)"


def warmup_model() -> None:
    """Send a test request to warm up the model."""
    from mico.cli import MODEL_PROVIDER, MODEL, API_BASE, API_KEY

    if MODEL_PROVIDER != "mlx":
        return
    payload = {
        "model": MODEL,
        "messages": [{"role": "user", "content": "hi"}],
        "stream": False,
        "temperature": 0,
        "max_tokens": 1,
    }
    response = requests.post(
        f"{API_BASE}/chat/completions",
        json=payload,
        headers={"Authorization": f"Bearer {API_KEY}"},
        timeout=1800,
    )
    response.raise_for_status()
