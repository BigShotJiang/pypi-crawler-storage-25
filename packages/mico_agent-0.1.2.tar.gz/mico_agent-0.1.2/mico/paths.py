from __future__ import annotations

from pathlib import Path


def safe_path(path: str, cwd: Path) -> Path:
    candidate = Path(path)
    if not candidate.is_absolute():
        candidate = (cwd / candidate).resolve()
    else:
        candidate = candidate.resolve()
    return candidate
