from __future__ import annotations

import unittest
from types import SimpleNamespace
from unittest.mock import AsyncMock, patch

from mico.model_client import router_load_hook, router_unload_hook
from mico.model_recommender import ModelEntry, recommend_profile
from mico.hardware import HardwareInfo


class TestLightering(unittest.IsolatedAsyncioTestCase):
    async def test_router_hooks_skip_admin_calls_for_direct_mlx_server(self) -> None:
        fake_cfg = SimpleNamespace()
        with patch("mico.cli.MODEL_PROVIDER", "mlx"), patch.dict("mico.cli.os.environ", {}, clear=False):
            post = AsyncMock()
            with patch("httpx.AsyncClient.post", post):
                await router_load_hook("/tmp/model", fake_cfg)
                await router_unload_hook("/tmp/model")
        post.assert_not_called()


class TestProfileTuning(unittest.TestCase):
    def test_large_model_on_24gb_becomes_tight_and_small_prefill(self) -> None:
        hw = HardwareInfo(os="macOS", chip="M4", memory_gb=24, gpu_type="apple-integrated")
        model = ModelEntry(path="/tmp/qwen", name="qwen3-coder-30b", backend="mlx", params_b=30, quant_bits=4)
        profile = recommend_profile(hw, model)
        self.assertEqual(profile.name, "tight")
        self.assertEqual(profile.prefill_step_size, 512)
        self.assertEqual(profile.prompt_cache_size, 4)
        self.assertFalse(profile.thinking)

    def test_medium_model_on_24gb_keeps_balanced_profile_but_uses_smaller_prefill(self) -> None:
        hw = HardwareInfo(os="macOS", chip="M4", memory_gb=24, gpu_type="apple-integrated")
        model = ModelEntry(path="/tmp/qwen", name="qwen3-coder-14b", backend="mlx", params_b=14, quant_bits=4)
        profile = recommend_profile(hw, model)
        self.assertEqual(profile.name, "balanced")
        self.assertEqual(profile.prefill_step_size, 1024)
        self.assertEqual(profile.prompt_cache_size, 4)


if __name__ == "__main__":
    unittest.main(verbosity=2)
