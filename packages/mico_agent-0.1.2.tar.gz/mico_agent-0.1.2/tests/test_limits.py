"""Tests for mico.limits module."""
import unittest

from mico.limits import (
    check_limits,
    format_limit_exceeded,
    PROFILE_LIMITS,
    LimitCheckResult,
)


class TestCheckLimits(unittest.TestCase):
    """Test limit checking."""

    def test_fast_limits_not_exceeded(self):
        """Test fast mode limits not exceeded."""
        result = check_limits("fast", files_changed=2, new_files=1, lines_changed=200)
        self.assertFalse(result.exceeded)
        self.assertEqual(len(result.exceeded_fields), 0)

    def test_fast_limits_exceeded_files(self):
        """Test fast mode files limit exceeded."""
        result = check_limits("fast", files_changed=5, new_files=1, lines_changed=200)
        self.assertTrue(result.exceeded)
        self.assertIn("files_changed", result.exceeded_fields)

    def test_fast_limits_exceeded_lines(self):
        """Test fast mode lines limit exceeded."""
        result = check_limits("fast", files_changed=2, new_files=1, lines_changed=500)
        self.assertTrue(result.exceeded)
        self.assertIn("lines_changed", result.exceeded_fields)

    def test_fast_limits_exceeded_new_files(self):
        """Test fast mode new files limit exceeded."""
        result = check_limits("fast", files_changed=2, new_files=5, lines_changed=200)
        self.assertTrue(result.exceeded)
        self.assertIn("new_files", result.exceeded_fields)

    def test_normal_limits_not_exceeded(self):
        """Test normal mode limits not exceeded."""
        result = check_limits("normal", files_changed=5, new_files=4, lines_changed=600)
        self.assertFalse(result.exceeded)
        self.assertEqual(len(result.exceeded_fields), 0)

    def test_normal_limits_exceeded_multiple(self):
        """Test normal mode multiple limits exceeded."""
        result = check_limits("normal", files_changed=10, new_files=10, lines_changed=1000)
        self.assertTrue(result.exceeded)
        self.assertGreater(len(result.exceeded_fields), 1)

    def test_deep_limits(self):
        """Test deep mode allows more changes."""
        result = check_limits("deep", files_changed=10, new_files=7, lines_changed=1200)
        self.assertFalse(result.exceeded)

    def test_deep_limits_exceeded(self):
        """Test deep mode limits can be exceeded."""
        result = check_limits("deep", files_changed=15, new_files=10, lines_changed=2000)
        self.assertTrue(result.exceeded)

    def test_review_limits_zero(self):
        """Test review mode has zero limits (read-only)."""
        limits = PROFILE_LIMITS["review"]
        self.assertEqual(limits["max_files_changed"], 0)
        self.assertEqual(limits["max_new_files"], 0)
        self.assertEqual(limits["max_lines_changed"], 0)

    def test_format_limit_exceeded_message(self):
        """Test format_limit_exceeded produces valid output."""
        result = LimitCheckResult(
            profile="fast",
            files_changed=5,
            new_files=1,
            lines_changed=200,
            max_files_changed=3,
            max_new_files=3,
            max_lines_changed=300,
            exceeded=True,
            exceeded_fields=["files_changed"],
        )
        output = format_limit_exceeded(result)
        self.assertIn("Limit exceeded", output)
        self.assertIn("fast", output)
        self.assertIn("5", output)
        self.assertIn("3", output)

    def test_all_profiles_have_limits(self):
        """Test all standard profiles have defined limits."""
        profiles = ["fast", "normal", "deep", "review", "docs"]
        for profile in profiles:
            self.assertIn(profile, PROFILE_LIMITS)
            limits = PROFILE_LIMITS[profile]
            self.assertIn("max_files_changed", limits)
            self.assertIn("max_new_files", limits)
            self.assertIn("max_lines_changed", limits)
            self.assertIn("max_fix_loops", limits)


if __name__ == "__main__":
    unittest.main()
