from __future__ import annotations

import json
import tempfile
import unittest
from pathlib import Path

from mico.server import _select_runner_kind


class ModelCompatibilitySmokeTests(unittest.TestCase):
    def _make_model_dir(self, root: Path, name: str, config: dict[str, object]) -> Path:
        model_dir = root / name
        model_dir.mkdir()
        (model_dir / "config.json").write_text(json.dumps(config), encoding="utf-8")
        return model_dir

    def test_runner_selection_matrix(self) -> None:
        cases = [
            (
                "qwen3-text",
                "Qwen3.5-7B-Instruct",
                {"model_type": "qwen3", "architectures": ["Qwen3ForCausalLM"]},
                "rapid_mlx",
            ),
            (
                "llama-text",
                "Llama-3.1-8B-Instruct",
                {"model_type": "llama", "architectures": ["LlamaForCausalLM"]},
                "rapid_mlx",
            ),
            (
                "mistral-text",
                "Mistral-7B-Instruct-v0.3",
                {"model_type": "mistral", "architectures": ["MistralForCausalLM"]},
                "rapid_mlx",
            ),
            (
                "deepseek-text",
                "DeepSeek-R1-Distill-Qwen-14B",
                {"model_type": "deepseek_v3", "architectures": ["DeepseekV3ForCausalLM"]},
                "rapid_mlx",
            ),
            (
                "gemma4-text",
                "gemma-4-27b-it",
                {"model_type": "gemma4", "architectures": ["Gemma4ForCausalLM"]},
                "rapid_mlx",
            ),
            (
                "gemma4-multimodal",
                "gemma-4-27b-it-vl",
                {
                    "model_type": "gemma4",
                    "architectures": ["Gemma4ForConditionalGeneration"],
                    "vision_config": {"image_size": 896},
                },
                "mlx_vlm",
            ),
            (
                "llava-vlm",
                "llava-1.6-7b",
                {"model_type": "llava", "architectures": ["LlavaForConditionalGeneration"]},
                "mlx_vlm",
            ),
            (
                "mtplx-native",
                "QwOpus-32B-mtplx",
                {"model_type": "mtplx_qwen", "mtplx_version": "0.1"},
                "mtplx",
            ),
        ]

        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            for label, dirname, config, expected in cases:
                with self.subTest(label=label):
                    model_dir = self._make_model_dir(root, dirname, config)
                    runner = _select_runner_kind(str(model_dir), rapid_mlx_available=True)
                    self.assertEqual(runner, expected)

    def test_supported_text_families_fall_back_to_mlx_lm_without_rapid_mlx(self) -> None:
        cases = [
            ("Qwen3.5-7B-Instruct", {"model_type": "qwen3", "architectures": ["Qwen3ForCausalLM"]}),
            ("Qwen3.5-2B-MLX-4bit", {"model_type": "qwen3", "architectures": ["Qwen3ForConditionalGeneration"]}),
            ("Llama-3.1-8B-Instruct", {"model_type": "llama", "architectures": ["LlamaForCausalLM"]}),
            ("gemma-4-27b-it", {"model_type": "gemma4", "architectures": ["Gemma4ForCausalLM"]}),
        ]

        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            for dirname, config in cases:
                with self.subTest(model=dirname):
                    model_dir = self._make_model_dir(root, dirname, config)
                    runner = _select_runner_kind(str(model_dir), rapid_mlx_available=False)
                    self.assertEqual(runner, "mlx_lm")

    def test_qwen_conditional_generation_text_model_is_not_vlm(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            model_dir = self._make_model_dir(
                root,
                "Qwen3.5-2B-MLX-4bit",
                {"model_type": "qwen3", "architectures": ["Qwen3ForConditionalGeneration"]},
            )
            runner = _select_runner_kind(str(model_dir), rapid_mlx_available=True)
            self.assertEqual(runner, "rapid_mlx")


if __name__ == "__main__":
    unittest.main(verbosity=2)
