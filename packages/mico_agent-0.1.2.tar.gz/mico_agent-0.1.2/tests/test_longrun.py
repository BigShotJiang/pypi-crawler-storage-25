"""longrun.py testleri — model mock'lanarak çalışır, gerçek LLM gerekmez."""
from __future__ import annotations

import json
import tempfile
import unittest
from pathlib import Path
from unittest.mock import MagicMock, patch

from mico.longrun import (
    LongRunConfig,
    LongRunState,
    _action_hash,
    _compact_history,
    _detect_repeat,
    _format_ledger,
    _inject_ledger,
    _parse_ledger_updates,
    _should_compact,
)


# ---------------------------------------------------------------------------
# Ledger testleri
# ---------------------------------------------------------------------------

class TestLedger(unittest.TestCase):
    def _state(self, **kw) -> LongRunState:
        s = LongRunState(goal="test")
        for k, v in kw.items():
            setattr(s, k, v)
        return s

    def test_format_ledger_contains_goal(self):
        s = self._state(goal="dosyaları düzenle", todo=["a"], done=["b"])
        text = _format_ledger(s, 40)
        self.assertIn("dosyaları düzenle", text)
        self.assertIn("a", text)
        self.assertIn("b", text)

    def test_parse_done_update(self):
        s = self._state(todo=["adım1", "adım2"])
        _parse_ledger_updates("LEDGER_UPDATE: done=adım1", s)
        self.assertIn("adım1", s.done)
        self.assertNotIn("adım1", s.todo)

    def test_parse_todo_update(self):
        s = self._state()
        _parse_ledger_updates("LEDGER_TODO: yeni adım", s)
        self.assertIn("yeni adım", s.todo)

    def test_parse_blocked_update(self):
        s = self._state()
        _parse_ledger_updates("LEDGER_BLOCKED: izin yok", s)
        self.assertIn("izin yok", s.blocked)

    def test_parse_decision_update(self):
        s = self._state()
        _parse_ledger_updates("LEDGER_DECISION: pytest kullan", s)
        self.assertIn("pytest kullan", s.decisions)

    def test_parse_ignores_unknown_lines(self):
        s = self._state()
        _parse_ledger_updates("bu normal bir mesajdır, ledger değil", s)
        self.assertEqual(s.todo, [])
        self.assertEqual(s.done, [])

    def test_inject_ledger_replaces_old(self):
        s = self._state(goal="test")
        history: list[dict] = [
            {"role": "user", "content": "merhaba"},
        ]
        cfg = LongRunConfig(goal="test")
        _inject_ledger(history, s, cfg)
        # inject sonrası 2 mesaj olmalı
        self.assertEqual(len(history), 2)
        # ikinci inject sonrası hâlâ 2 olmalı (önceki kaldırıldı)
        s.turn = 2
        _inject_ledger(history, s, cfg)
        self.assertEqual(len(history), 2)


# ---------------------------------------------------------------------------
# Tekrar dedektörü testleri
# ---------------------------------------------------------------------------

class TestRepeatDetector(unittest.TestCase):
    def test_no_repeat_initially(self):
        s = LongRunState(goal="x")
        result = _detect_repeat(s, "abc123", 3)
        self.assertFalse(result)

    def test_detects_repeat_at_limit(self):
        s = LongRunState(goal="x")
        _detect_repeat(s, "aaa", 3)
        _detect_repeat(s, "aaa", 3)
        result = _detect_repeat(s, "aaa", 3)
        self.assertTrue(result)

    def test_different_hashes_no_repeat(self):
        s = LongRunState(goal="x")
        for h in ["aaa", "bbb", "ccc"]:
            result = _detect_repeat(s, h, 3)
        self.assertFalse(result)

    def test_action_hash_stable(self):
        action = {"type": "tool", "tool": "bash", "command": "ls", "timeout": 30000}
        h1 = _action_hash(action)
        h2 = _action_hash(action)
        self.assertEqual(h1, h2)

    def test_action_hash_timeout_ignored(self):
        a1 = {"type": "tool", "tool": "bash", "command": "ls", "timeout": 30000}
        a2 = {"type": "tool", "tool": "bash", "command": "ls", "timeout": 60000}
        self.assertEqual(_action_hash(a1), _action_hash(a2))

    def test_action_hash_different_commands(self):
        a1 = {"type": "tool", "tool": "bash", "command": "ls"}
        a2 = {"type": "tool", "tool": "bash", "command": "pwd"}
        self.assertNotEqual(_action_hash(a1), _action_hash(a2))


# ---------------------------------------------------------------------------
# Compact testleri
# ---------------------------------------------------------------------------

class TestCompact(unittest.IsolatedAsyncioTestCase):
    def _make_big_history(self, n: int = 20) -> list[dict]:
        return [{"role": "user", "content": "x" * 500} for _ in range(n)]

    def test_should_compact_large(self):
        cfg = LongRunConfig(goal="test", context_window=1000, compact_ratio=0.5)
        history = self._make_big_history(30)  # 30 * 500 chars = 15000, /4 = 3750 tokens > 500
        self.assertTrue(_should_compact(history, cfg))

    def test_should_not_compact_small(self):
        cfg = LongRunConfig(goal="test", context_window=100000, compact_ratio=0.8)
        history = [{"role": "user", "content": "merhaba"}]
        self.assertFalse(_should_compact(history, cfg))

    async def test_compact_reduces_history(self):
        s = LongRunState(goal="test")
        cfg = LongRunConfig(goal="test")
        history = self._make_big_history(30)
        summarize_fn = lambda h: f"Özet: {len(h)} mesaj."
        compacted = await _compact_history(history, s, cfg, summarize_fn=summarize_fn, keep_tail=6)
        # 1 compacted summary + 1 ledger + 6 tail = 8
        self.assertEqual(len(compacted), 8)
        self.assertEqual(s.compaction_count, 1)

    async def test_compact_preserves_tail(self):
        s = LongRunState(goal="test")
        cfg = LongRunConfig(goal="test")
        tail_marker = {"role": "user", "content": "TAIL_MARKER"}
        history = [{"role": "user", "content": "x" * 200}] * 20 + [tail_marker]
        compacted = await _compact_history(history, s, cfg, summarize_fn=lambda h: "özet", keep_tail=5)
        contents = [m["content"] for m in compacted]
        self.assertIn("TAIL_MARKER", contents)


# ---------------------------------------------------------------------------
# LongRunState summary testleri
# ---------------------------------------------------------------------------

class TestLongRunStateSummary(unittest.TestCase):
    def test_summary_contains_goal(self):
        s = LongRunState(goal="projeyi düzelt")
        s.exit_reason = "done"
        s.done = ["adım1"]
        summary = s.summary
        self.assertIn("projeyi düzelt", summary)
        self.assertIn("adım1", summary)
        self.assertIn("done", summary)

    def test_summary_shows_blocked(self):
        s = LongRunState(goal="test")
        s.exit_reason = "repeat_limit"
        s.blocked = ["sonsuz döngü"]
        self.assertIn("sonsuz döngü", s.summary)


# ---------------------------------------------------------------------------
# run_long_task mock testi — gerçek model yok
# ---------------------------------------------------------------------------

class TestRunLongTaskMocked(unittest.IsolatedAsyncioTestCase):
    async def test_done_on_first_final(self):
        """Model ilk turda final döndürürse done ile çıkmalı."""
        final_response = json.dumps({"type": "final", "message": "LEDGER_UPDATE: done=test hedefi\nTamamlandı."})

        import mico.longrun as lr_mod
        import mico.cli as cli_mod

        with tempfile.TemporaryDirectory() as tmp:
            cfg = LongRunConfig(
                goal="test hedefi",
                max_turns=5,
                cwd=tmp,
            )

            async def fake_call(*a, **kw): return final_response

            with patch.object(cli_mod, "call_model", side_effect=fake_call), \
                 patch.object(cli_mod, "save_session"), \
                 patch.object(cli_mod, "runtime_context_text", return_value="ctx"), \
                 patch.object(cli_mod, "build_system_prompt", return_value="sys"), \
                 patch.object(cli_mod, "ToolContext", MagicMock(return_value=MagicMock(cwd=Path(tmp)))):
                result = await lr_mod.run_long_task(cfg)

        self.assertIn(result.exit_reason, ("done", "max_turns"))

    async def test_max_turns_respected(self):
        """max_turns=2 ile model hep tool döndürürse max_turns ile çıkmalı."""
        tool_response = json.dumps({"type": "tool", "tool": "bash", "command": "echo hi"})

        import mico.longrun as lr_mod
        import mico.cli as cli_mod

        async def fake_call(*a, **kw): return tool_response
        async def fake_run(*a, **kw): return "exit_code=0\nhi"

        with tempfile.TemporaryDirectory() as tmp:
            cfg = LongRunConfig(goal="sonsuz", max_turns=2, cwd=tmp)
            with patch.object(cli_mod, "call_model", side_effect=fake_call), \
                 patch.object(cli_mod, "run_tool", side_effect=fake_run), \
                 patch.object(cli_mod, "save_session"), \
                 patch.object(cli_mod, "runtime_context_text", return_value="ctx"), \
                 patch.object(cli_mod, "build_system_prompt", return_value="sys"), \
                 patch.object(cli_mod, "ToolContext", MagicMock(return_value=MagicMock(cwd=Path(tmp)))):
                result = await lr_mod.run_long_task(cfg)

        self.assertEqual(result.exit_reason, "max_turns")
        self.assertEqual(result.turn, 2)

    async def test_repeat_limit_triggers(self):
        """Aynı action 3 kez döndürülürse repeat_limit ile durmalı."""
        tool_response = json.dumps({"type": "tool", "tool": "bash", "command": "same_cmd"})

        import mico.longrun as lr_mod
        import mico.cli as cli_mod

        async def fake_call(*a, **kw): return tool_response
        async def fake_run(*a, **kw): return "exit_code=0\nout"

        with tempfile.TemporaryDirectory() as tmp:
            cfg = LongRunConfig(goal="test", max_turns=10, max_repeat_actions=3, cwd=tmp)
            with patch.object(cli_mod, "call_model", side_effect=fake_call), \
                 patch.object(cli_mod, "run_tool", side_effect=fake_run), \
                 patch.object(cli_mod, "save_session"), \
                 patch.object(cli_mod, "runtime_context_text", return_value="ctx"), \
                 patch.object(cli_mod, "build_system_prompt", return_value="sys"), \
                 patch.object(cli_mod, "ToolContext", MagicMock(return_value=MagicMock(cwd=Path(tmp)))):
                result = await lr_mod.run_long_task(cfg)

        self.assertEqual(result.exit_reason, "repeat_limit")
        self.assertTrue(len(result.blocked) > 0)

    async def test_supervisor_callback_called(self):
        """on_turn_end her tur sonunda çağrılmalı."""
        tool_response = json.dumps({"type": "tool", "tool": "bash", "command": "echo"})
        calls: list[int] = []

        import mico.longrun as lr_mod
        import mico.cli as cli_mod

        def supervisor(s: LongRunState) -> None:
            calls.append(s.turn)

        async def fake_call(*a, **kw): return tool_response
        async def fake_run(*a, **kw): return "exit_code=0\nout"

        with tempfile.TemporaryDirectory() as tmp:
            cfg = LongRunConfig(
                goal="test", max_turns=3, max_repeat_actions=10, cwd=tmp,
                on_turn_end=supervisor,
            )
            with patch.object(cli_mod, "call_model", side_effect=fake_call), \
                 patch.object(cli_mod, "run_tool", side_effect=fake_run), \
                 patch.object(cli_mod, "save_session"), \
                 patch.object(cli_mod, "runtime_context_text", return_value="ctx"), \
                 patch.object(cli_mod, "build_system_prompt", return_value="sys"), \
                 patch.object(cli_mod, "ToolContext", MagicMock(return_value=MagicMock(cwd=Path(tmp)))):
                result = await lr_mod.run_long_task(cfg)

        self.assertTrue(len(calls) > 0)
        self.assertEqual(calls, list(range(1, len(calls) + 1)))

    async def test_wall_clock_timeout(self):
        """Zaman aşımı simülasyonu — timeout çok kısa, repeat limiti yüksek."""
        import mico.longrun as lr_mod
        import mico.cli as cli_mod

        call_count = [0]
        async def varying_tool(*a, **kw):
            call_count[0] += 1
            return json.dumps({"type": "tool", "tool": "bash", "command": f"echo {call_count[0]}"})

        async def fake_run(*a, **kw): return "exit_code=0\nout"

        with tempfile.TemporaryDirectory() as tmp:
            cfg = LongRunConfig(
                goal="test", max_turns=100,
                wall_clock_timeout=0.001,   # 1ms — ilk tur başlar başlamaz timeout
                max_repeat_actions=100,      # repeat engelleme devre dışı
                cwd=tmp,
            )
            with patch.object(cli_mod, "call_model", side_effect=varying_tool), \
                 patch.object(cli_mod, "run_tool", side_effect=fake_run), \
                 patch.object(cli_mod, "save_session"), \
                 patch.object(cli_mod, "runtime_context_text", return_value="ctx"), \
                 patch.object(cli_mod, "build_system_prompt", return_value="sys"), \
                 patch.object(cli_mod, "ToolContext", MagicMock(return_value=MagicMock(cwd=Path(tmp)))):
                result = await lr_mod.run_long_task(cfg)

        self.assertEqual(result.exit_reason, "timeout")


if __name__ == "__main__":
    unittest.main(verbosity=2)
