"""triage.py testleri — kural tabanlı, LLM mock gerektirmez."""
from __future__ import annotations

import unittest

from mico.triage import (
    TriageResult,
    format_reject_message,
    triage_task,
)


class TestTriageTask(unittest.IsolatedAsyncioTestCase):

    async def test_trivial_chat_ok(self):
        r = await triage_task("merhaba", task_kind="trivial_chat")
        self.assertEqual(r.verdict, "ok")

    async def test_normal_task_ok(self):
        r = await triage_task("dosyayı düzelt", task_kind="agentic")
        self.assertEqual(r.verdict, "ok")

    async def test_physical_world_rejected(self):
        r = await triage_task("arabayı sürdür", task_kind="agentic")
        self.assertEqual(r.verdict, "reject")

    async def test_physical_english_rejected(self):
        r = await triage_task("launch the rocket", task_kind="agentic")
        self.assertEqual(r.verdict, "reject")

    async def test_pentest_not_rejected(self):
        r = await triage_task("ağ taraması yap ve açıkları listele", task_kind="agentic")
        self.assertEqual(r.verdict, "ok")

    async def test_security_tool_not_rejected(self):
        r = await triage_task("exploit scripti yaz", task_kind="agentic")
        self.assertEqual(r.verdict, "ok")

    async def test_no_llm_call(self):
        """call_model verilmese de çalışmalı."""
        r = await triage_task("git status göster", task_kind="local_info")
        self.assertEqual(r.verdict, "ok")


class TestFormatRejectMessage(unittest.TestCase):

    def test_with_reason(self):
        msg = format_reject_message("fiziksel olarak imkânsız")
        self.assertIn("fiziksel olarak imkânsız", msg)

    def test_empty_reason_fallback(self):
        msg = format_reject_message("")
        self.assertTrue(bool(msg.strip()))


if __name__ == "__main__":
    unittest.main(verbosity=2)
