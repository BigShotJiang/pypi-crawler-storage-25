"""Tests for the 3-tier (allow/ask/deny) command classifier in mico."""
from __future__ import annotations

import sys
import unittest
from pathlib import Path

# Ensure the project root is on the import path.
ROOT = Path(__file__).resolve().parent.parent
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

import mico  # noqa: E402


class ClassifyCommandTests(unittest.TestCase):
    def test_ls_is_allow(self) -> None:
        tier, _ = mico.classify_command("ls -la")
        self.assertEqual(tier, "allow")

    def test_pytest_is_allow(self) -> None:
        tier, _ = mico.classify_command("pytest tests/")
        self.assertEqual(tier, "allow")

    def test_grep_is_allow(self) -> None:
        tier, _ = mico.classify_command("grep -rn foo src/")
        self.assertEqual(tier, "allow")

    def test_git_status_is_allow(self) -> None:
        tier, _ = mico.classify_command("git status")
        self.assertEqual(tier, "allow")

    def test_pip_install_is_ask(self) -> None:
        tier, _ = mico.classify_command("pip install foo")
        self.assertEqual(tier, "ask")

    def test_rm_file_is_ask(self) -> None:
        tier, _ = mico.classify_command("rm file.txt")
        self.assertEqual(tier, "ask")

    def test_git_push_is_ask(self) -> None:
        # Catastrophic floor only blocks --force to main/master; plain push is ask tier.
        tier, _ = mico.classify_command("git push origin main")
        self.assertEqual(tier, "ask")

    def test_curl_is_ask(self) -> None:
        tier, _ = mico.classify_command("curl https://example.com")
        self.assertEqual(tier, "ask")

    def test_nmap_is_ask(self) -> None:
        # nmap is ask-tier (confirmation required), not hard-deny
        tier, _ = mico.classify_command("nmap 1.1.1.1")
        self.assertIn(tier, ("ask", "allow"))  # not hard-deny

    def test_remote_rsync_is_ask(self) -> None:
        # rsync moved to network-gated; classify_command returns ask not deny
        tier, _ = mico.classify_command("rsync -avz x host::path")
        self.assertIn(tier, ("ask", "allow"))

    def test_global_npm_install_is_deny(self) -> None:
        tier, _ = mico.classify_command("npm install -g typescript")
        self.assertEqual(tier, "deny")

    def test_unknown_command_is_ask(self) -> None:
        tier, reason = mico.classify_command("totally-unknown-binary --weird")
        self.assertEqual(tier, "ask")
        self.assertIn("Unrecognised", reason)


class DisallowedReasonTierTests(unittest.TestCase):
    def _ctx(self, **overrides):
        from mico import ToolContext
        defaults = dict(
            cwd=Path.cwd(),
            approval="ask",
            force=False,
            mode="auto",
            narrate=False,
            dry_run=False,
            profile="balanced",
            network_access=True,
            tool_install=True,
            unattended=False,
            permission_mode="balanced",
        )
        defaults.update(overrides)
        return ToolContext(**defaults)

    def test_nmap_allowed(self) -> None:
        # network access is always on — nmap is always allowed (ask-tier)
        ctx = self._ctx(network_access=True)
        self.assertIsNone(mico.disallowed_command_reason("nmap 1.1.1.1", ctx))

    def test_strict_blocks_ask_tier(self) -> None:
        ctx = self._ctx(permission_mode="strict")
        reason = mico.disallowed_command_reason("rm file.txt", ctx)
        self.assertIsNotNone(reason)
        self.assertIn("Strict mode", reason)

    def test_balanced_allows_ask_tier(self) -> None:
        ctx = self._ctx(permission_mode="balanced")
        # rm file.txt is ask-tier; disallowed_command_reason should NOT block (maybe_confirm handles prompt).
        self.assertIsNone(mico.disallowed_command_reason("rm file.txt", ctx))


if __name__ == "__main__":
    unittest.main()
