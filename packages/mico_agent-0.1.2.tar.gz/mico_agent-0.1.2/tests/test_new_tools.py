"""Yeni tool'ların benchmark testi: find_in_files, git_tool, create_dir, move_file,
delete_file, python_run, env_info, json_query."""
import json
import tempfile
import unittest
from pathlib import Path

import mico


def make_ctx(cwd: Path, **overrides) -> mico.ToolContext:
    params = dict(
        cwd=cwd,
        approval="never",
        force=False,
        mode="auto",
        narrate=False,
        profile="fast",
    )
    params.update(overrides)
    return mico.ToolContext(**params)


class TestFindInFiles(unittest.IsolatedAsyncioTestCase):
    async def test_finds_pattern(self):
        with tempfile.TemporaryDirectory() as tmp:
            p = Path(tmp) / "hello.py"
            p.write_text("def hello_world():\n    pass\n")
            ctx = make_ctx(Path(tmp))
            result = await mico.run_tool({"type": "tool", "tool": "find_in_files", "pattern": "hello_world", "path": tmp}, ctx)
            self.assertIn("hello_world", result)

    async def test_file_pattern_filter(self):
        with tempfile.TemporaryDirectory() as tmp:
            (Path(tmp) / "a.py").write_text("needle here\n")
            (Path(tmp) / "b.txt").write_text("needle here\n")
            ctx = make_ctx(Path(tmp))
            result = await mico.run_tool({
                "type": "tool", "tool": "find_in_files",
                "pattern": "needle", "path": tmp, "file_pattern": "*.py"
            }, ctx)
            self.assertIn("a.py", result)
            self.assertNotIn("b.txt", result)

    async def test_no_pattern_raises(self):
        with tempfile.TemporaryDirectory() as tmp:
            ctx = make_ctx(Path(tmp))
            with self.assertRaises(ValueError):
                await mico.run_tool({"type": "tool", "tool": "find_in_files", "pattern": "", "path": tmp}, ctx)


class TestCreateDir(unittest.IsolatedAsyncioTestCase):
    async def test_creates_nested(self):
        with tempfile.TemporaryDirectory() as tmp:
            ctx = make_ctx(Path(tmp))
            result = await mico.run_tool({"type": "tool", "tool": "create_dir", "path": f"{tmp}/a/b/c"}, ctx)
            self.assertTrue((Path(tmp) / "a" / "b" / "c").is_dir())
            self.assertIn("oluşturuldu", result)

    async def test_idempotent(self):
        with tempfile.TemporaryDirectory() as tmp:
            ctx = make_ctx(Path(tmp))
            await mico.run_tool({"type": "tool", "tool": "create_dir", "path": tmp}, ctx)

    async def test_no_path_raises(self):
        with tempfile.TemporaryDirectory() as tmp:
            ctx = make_ctx(Path(tmp))
            with self.assertRaises(ValueError):
                await mico.run_tool({"type": "tool", "tool": "create_dir", "path": ""}, ctx)


class TestMoveFile(unittest.IsolatedAsyncioTestCase):
    async def test_moves_file(self):
        with tempfile.TemporaryDirectory() as tmp:
            src = Path(tmp) / "old.txt"
            src.write_text("content")
            dst = Path(tmp) / "new.txt"
            ctx = make_ctx(Path(tmp))
            result = await mico.run_tool({"type": "tool", "tool": "move_file", "src": str(src), "dst": str(dst)}, ctx)
            self.assertFalse(src.exists())
            self.assertTrue(dst.exists())
            self.assertIn("Taşındı", result)

    async def test_missing_args_raises(self):
        with tempfile.TemporaryDirectory() as tmp:
            ctx = make_ctx(Path(tmp))
            with self.assertRaises(ValueError):
                await mico.run_tool({"type": "tool", "tool": "move_file", "src": "", "dst": ""}, ctx)


class TestDeleteFile(unittest.IsolatedAsyncioTestCase):
    async def test_deletes_file(self):
        with tempfile.TemporaryDirectory() as tmp:
            f = Path(tmp) / "del.txt"
            f.write_text("bye")
            ctx = make_ctx(Path(tmp))
            result = await mico.run_tool({"type": "tool", "tool": "delete_file", "path": str(f)}, ctx)
            self.assertFalse(f.exists())
            self.assertIn("Silindi", result)

    async def test_nonexistent_returns_message(self):
        with tempfile.TemporaryDirectory() as tmp:
            ctx = make_ctx(Path(tmp))
            result = await mico.run_tool({"type": "tool", "tool": "delete_file", "path": f"{tmp}/ghost.txt"}, ctx)
            self.assertIn("zaten yok", result)

    async def test_deletes_directory(self):
        with tempfile.TemporaryDirectory() as tmp:
            d = Path(tmp) / "subdir"
            d.mkdir()
            (d / "file.txt").write_text("x")
            ctx = make_ctx(Path(tmp))
            result = await mico.run_tool({"type": "tool", "tool": "delete_file", "path": str(d)}, ctx)
            self.assertFalse(d.exists())


class TestPythonRun(unittest.IsolatedAsyncioTestCase):
    async def test_simple_arithmetic(self):
        with tempfile.TemporaryDirectory() as tmp:
            ctx = make_ctx(Path(tmp))
            result = await mico.run_tool({"type": "tool", "tool": "python_run", "code": "print(2 + 2)"}, ctx)
            self.assertIn("4", result)
            self.assertIn("exit_code=0", result)

    async def test_error_output(self):
        with tempfile.TemporaryDirectory() as tmp:
            ctx = make_ctx(Path(tmp))
            result = await mico.run_tool({"type": "tool", "tool": "python_run", "code": "raise ValueError('test error')"}, ctx)
            self.assertIn("exit_code=1", result)
            self.assertIn("ValueError", result)

    async def test_no_code_raises(self):
        with tempfile.TemporaryDirectory() as tmp:
            ctx = make_ctx(Path(tmp))
            with self.assertRaises(ValueError):
                await mico.run_tool({"type": "tool", "tool": "python_run", "code": ""}, ctx)


class TestEnvInfo(unittest.IsolatedAsyncioTestCase):
    async def test_basic_info(self):
        with tempfile.TemporaryDirectory() as tmp:
            ctx = make_ctx(Path(tmp))
            result = await mico.run_tool({"type": "tool", "tool": "env_info"}, ctx)
            self.assertIn("platform", result)
            self.assertIn("python", result)

    async def test_specific_keys(self):
        import os
        with tempfile.TemporaryDirectory() as tmp:
            ctx = make_ctx(Path(tmp))
            result = await mico.run_tool({"type": "tool", "tool": "env_info", "keys": ["HOME"]}, ctx)
            self.assertIn("HOME=", result)
            self.assertIn(os.environ.get("HOME", ""), result)


class TestJsonQuery(unittest.IsolatedAsyncioTestCase):
    async def test_root_query(self):
        with tempfile.TemporaryDirectory() as tmp:
            f = Path(tmp) / "data.json"
            f.write_text(json.dumps({"name": "mico", "version": 1}))
            ctx = make_ctx(Path(tmp))
            result = await mico.run_tool({"type": "tool", "tool": "json_query", "path": str(f), "query": "."}, ctx)
            self.assertIn("mico", result)

    async def test_nested_query(self):
        with tempfile.TemporaryDirectory() as tmp:
            f = Path(tmp) / "data.json"
            f.write_text(json.dumps({"results": [{"name": "alice"}, {"name": "bob"}]}))
            ctx = make_ctx(Path(tmp))
            result = await mico.run_tool({"type": "tool", "tool": "json_query", "path": str(f), "query": "results[0].name"}, ctx)
            self.assertIn("alice", result)

    async def test_missing_path_raises(self):
        with tempfile.TemporaryDirectory() as tmp:
            ctx = make_ctx(Path(tmp))
            with self.assertRaises(ValueError):
                await mico.run_tool({"type": "tool", "tool": "json_query", "path": "", "query": "."}, ctx)


class TestGitTool(unittest.IsolatedAsyncioTestCase):
    async def test_status_in_repo(self):
        repo = Path("/Users/micobot/mico")
        ctx = make_ctx(repo)
        result = await mico.run_tool({"type": "tool", "tool": "git_tool", "op": "status"}, ctx)
        self.assertIn("exit_code=0", result)

    async def test_log_in_repo(self):
        repo = Path("/Users/micobot/mico")
        ctx = make_ctx(repo)
        result = await mico.run_tool({"type": "tool", "tool": "git_tool", "op": "log"}, ctx)
        self.assertIn("exit_code=0", result)

    async def test_invalid_op_raises(self):
        with tempfile.TemporaryDirectory() as tmp:
            ctx = make_ctx(Path(tmp))
            with self.assertRaises(ValueError):
                await mico.run_tool({"type": "tool", "tool": "git_tool", "op": "hack"}, ctx)


if __name__ == "__main__":
    unittest.main(verbosity=2)
