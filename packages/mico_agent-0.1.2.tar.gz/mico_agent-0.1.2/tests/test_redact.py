import unittest

from mico.redact import redact_dict, redact_json_safe, redact_text


class RedactTextTests(unittest.TestCase):
    def test_aws_access_key(self) -> None:
        secret = "AKIAIOSFODNN7EXAMPLE"
        out = redact_text(f"creds: {secret} end")
        self.assertNotIn(secret, out)
        self.assertIn("[REDACTED:aws_access_key]", out)

    def test_aws_secret_access_key(self) -> None:
        secret = "AWS_SECRET_ACCESS_KEY=wJalrXUtnFEMI/K7MDENG/bPxRfiCYEXAMPLEKEY"
        out = redact_text(secret)
        self.assertNotIn("wJalrXUtnFEMI/K7MDENG/bPxRfiCYEXAMPLEKEY", out)
        # Either the env_secret or aws_secret pattern should fire; ensure
        # *some* REDACTED tag appears and the raw secret is gone.
        self.assertIn("[REDACTED:", out)

    def test_github_pat(self) -> None:
        secret = "ghp_" + "a" * 40
        # Use a context that won't trip the env-style line rule so we get
        # the github_pat label specifically.
        out = redact_text(f"see token {secret} in commit")
        self.assertNotIn(secret, out)
        self.assertIn("[REDACTED:github_pat]", out)

    def test_github_pat_in_env_line_still_redacted(self) -> None:
        secret = "ghp_" + "b" * 40
        out = redact_text(f"GITHUB_TOKEN={secret}")
        self.assertNotIn(secret, out)
        self.assertIn("[REDACTED:", out)

    def test_slack_token(self) -> None:
        secret = "xoxb-1234567890-abcdefghij"
        out = redact_text(f"slack {secret}")
        self.assertNotIn(secret, out)
        self.assertIn("[REDACTED:slack_token]", out)

    def test_anthropic_key(self) -> None:
        secret = "sk-ant-" + "X" * 40
        out = redact_text(f"key {secret}!")
        self.assertNotIn(secret, out)
        self.assertIn("[REDACTED:anthropic_key]", out)

    def test_openai_key(self) -> None:
        secret = "sk-" + "Y" * 40
        out = redact_text(f"openai={secret}")
        self.assertNotIn(secret, out)
        self.assertIn("[REDACTED:", out)

    def test_bearer_token(self) -> None:
        secret = "abcdefghijklmnopqrstuvwxyz1234567890"
        out = redact_text(f"Authorization: Bearer {secret}")
        self.assertNotIn(secret, out)
        self.assertIn("Bearer", out)
        self.assertIn("[REDACTED:bearer_token]", out)

    def test_jwt(self) -> None:
        secret = (
            "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9."
            "eyJzdWIiOiIxMjM0NTY3ODkwIiwibmFtZSI6IkpvaG4ifQ."
            "SflKxwRJSMeKKF2QT4fwpMeJf36POk6yJV_adQssw5c"
        )
        out = redact_text(f"jwt={secret}")
        self.assertNotIn(secret, out)
        self.assertIn("[REDACTED:jwt]", out)

    def test_private_key_block(self) -> None:
        secret = (
            "-----BEGIN RSA PRIVATE KEY-----\n"
            "MIIEpAIBAAKCAQEAxyz...\nlinetwo\n"
            "-----END RSA PRIVATE KEY-----"
        )
        out = redact_text(f"before\n{secret}\nafter")
        self.assertNotIn("MIIEpAIBAAKCAQEAxyz", out)
        self.assertIn("[REDACTED:private_key]", out)
        self.assertIn("before", out)
        self.assertIn("after", out)

    def test_env_secret_line(self) -> None:
        secret_line = "DATABASE_PASSWORD=hunter2supersecret"
        out = redact_text(secret_line)
        self.assertNotIn("hunter2supersecret", out)
        self.assertIn("DATABASE_PASSWORD=", out)
        self.assertIn("[REDACTED:env_secret]", out)

    def test_oversized_blob_is_skipped(self) -> None:
        big = "AKIAIOSFODNN7EXAMPLE" + ("x" * (5 * 1024 * 1024 + 10))
        out = redact_text(big)
        # Oversized: passthrough — secret remains, no redaction performed.
        self.assertIn("AKIAIOSFODNN7EXAMPLE", out)


class RedactJsonSafeTests(unittest.TestCase):
    def test_recursive_dict(self) -> None:
        secret = "AKIAIOSFODNN7EXAMPLE"
        payload = {
            "name": "x",
            "creds": {"aws": secret, "count": 3},
            "tail": ["fine", f"leak {secret}"],
        }
        out = redact_json_safe(payload)
        self.assertEqual(out["count"] if "count" in out else out["creds"]["count"], 3)
        self.assertNotIn(secret, out["creds"]["aws"])
        self.assertNotIn(secret, out["tail"][1])
        self.assertEqual(out["tail"][0], "fine")

    def test_redact_dict_passthrough_for_non_dict(self) -> None:
        self.assertEqual(redact_dict("not a dict"), "not a dict")  # type: ignore[arg-type]


if __name__ == "__main__":
    unittest.main()
