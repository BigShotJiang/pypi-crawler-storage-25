"""Tests for mico.testloop module."""
from __future__ import annotations

import json
import sys
import tempfile
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from mico.testloop import (  # noqa: E402
    FixLoopState,
    TestRunner,
    detect_test_runners,
    parse_pytest_failures,
    run_tests,
    should_continue_fix_loop,
    summarize_test_result,
)


PYTEST_SAMPLE_OUTPUT = """\
============================= test session starts ==============================
collected 2 items

tests/test_foo.py F                                                       [ 50%]
tests/test_bar.py .                                                       [100%]

=================================== FAILURES ===================================
________________________________ test_addition _________________________________

    def test_addition():
>       assert 1 + 1 == 3
E       AssertionError: assert 2 == 3

tests/test_foo.py:7: AssertionError
=========================== short test summary info ============================
FAILED tests/test_foo.py::test_addition - AssertionError: assert 2 == 3
======================== 1 failed, 1 passed in 0.05s ===========================
"""


class DetectionTests(unittest.TestCase):
    def test_pyproject_with_pytest_detected(self):
        with tempfile.TemporaryDirectory() as td:
            cwd = Path(td)
            (cwd / "pyproject.toml").write_text(
                "[tool.pytest.ini_options]\nminversion = '6.0'\n"
            )
            runners = detect_test_runners(cwd)
            self.assertTrue(any(r.name == "pytest" for r in runners))
            self.assertEqual(runners[0].name, "pytest")

    def test_package_json_with_test_script_detected(self):
        with tempfile.TemporaryDirectory() as td:
            cwd = Path(td)
            (cwd / "package.json").write_text(
                json.dumps({"scripts": {"test": "jest"}})
            )
            runners = detect_test_runners(cwd)
            self.assertTrue(any(r.name == "npm" for r in runners))

    def test_package_json_without_test_script_not_detected(self):
        with tempfile.TemporaryDirectory() as td:
            cwd = Path(td)
            (cwd / "package.json").write_text(json.dumps({"scripts": {}}))
            runners = detect_test_runners(cwd)
            self.assertFalse(any(r.name == "npm" for r in runners))

    def test_no_runner_returns_empty_list(self):
        with tempfile.TemporaryDirectory() as td:
            cwd = Path(td)
            (cwd / "README.md").write_text("hello")
            self.assertEqual(detect_test_runners(cwd), [])

    def test_priority_ordering(self):
        with tempfile.TemporaryDirectory() as td:
            cwd = Path(td)
            (cwd / "pyproject.toml").write_text("[tool.pytest.ini_options]\n")
            (cwd / "Cargo.toml").write_text("[package]\nname='x'\n")
            runners = detect_test_runners(cwd)
            names = [r.name for r in runners]
            self.assertEqual(names[0], "pytest")
            self.assertIn("cargo", names)


class ParsingTests(unittest.TestCase):
    def test_parse_pytest_failures_from_sample(self):
        fails = parse_pytest_failures(PYTEST_SAMPLE_OUTPUT)
        self.assertGreaterEqual(len(fails), 1)
        first = fails[0]
        self.assertIn("test_addition", first["name"])
        self.assertEqual(first["file"], "tests/test_foo.py")
        self.assertIn("AssertionError", first["message"])


class RunTestsIntegrationTests(unittest.TestCase):
    def test_run_tests_passing_unittest(self):
        td = Path(tempfile.mkdtemp(prefix="mico.testloop_"))
        (td / "test_pass.py").write_text(
            "import unittest\n"
            "class T(unittest.TestCase):\n"
            "    def test_ok(self):\n"
            "        self.assertEqual(1 + 1, 2)\n"
        )
        runner = TestRunner(
            name="pytest",  # use pytest-style parser; nothing to parse on success
            command=[sys.executable, "-m", "unittest", "test_pass", "-v"],
            config_file="(synthetic)",
            priority=10,
        )
        result = run_tests(runner, td, timeout=60)
        self.assertEqual(result.exit_code, 0)
        self.assertEqual(result.failing_tests, [])
        self.assertIn("runner: pytest", result.summary)

    def test_run_tests_failing_emits_failures(self):
        td = Path(tempfile.mkdtemp(prefix="mico.testloop_"))
        # Synthesize pytest-style output via a python script so the parser
        # has something to match without requiring pytest to be installed.
        script = (
            "import sys\n"
            "print('FAILED tests/test_foo.py::test_bar - AssertionError: expected 3, got 4')\n"
            "print('tests/test_foo.py:7: AssertionError')\n"
            "sys.exit(1)\n"
        )
        runner = TestRunner(
            name="pytest",
            command=[sys.executable, "-c", script],
            config_file="(synthetic)",
            priority=10,
        )
        result = run_tests(runner, td, timeout=30)
        self.assertNotEqual(result.exit_code, 0)
        self.assertGreaterEqual(len(result.failing_tests), 1)
        self.assertIn("test_bar", result.failing_tests[0]["name"])


class SummarizeAndLoopTests(unittest.TestCase):
    def test_summarize_format(self):
        from mico.testloop import TestResult
        r = TestResult(
            runner_name="pytest",
            command=["pytest", "-x"],
            exit_code=1,
            duration_s=3.2,
            summary="",
            failing_tests=[
                {"name": "tests/test_foo.py::test_bar", "file": "tests/test_foo.py", "line": 42, "message": "AssertionError: expected 3, got 4"},
            ],
            raw_tail="some tail",
        )
        text = summarize_test_result(r)
        self.assertIn("runner: pytest", text)
        self.assertIn("exit_code: 1", text)
        self.assertIn("duration: 3.2s", text)
        self.assertIn("failures (1 total", text)
        self.assertIn("line 42", text)
        self.assertIn("AssertionError", text)

    def test_fix_loop_state_progression(self):
        st = FixLoopState()
        self.assertTrue(should_continue_fix_loop(st))
        st.attempts = 3
        self.assertFalse(should_continue_fix_loop(st))


if __name__ == "__main__":
    unittest.main()
