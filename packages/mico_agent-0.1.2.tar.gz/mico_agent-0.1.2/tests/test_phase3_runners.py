import os
import unittest
from pathlib import Path
from mico.runners import LocalRunner, DockerRunner


class TestLocalRunner(unittest.IsolatedAsyncioTestCase):
    async def test_run_command(self):
        runner = LocalRunner()
        res = await runner.run_command(["echo", "hello"], cwd=Path.cwd())
        self.assertEqual(res.stdout.strip(), "hello")
        self.assertEqual(res.exit_code, 0)

    async def test_run_python(self):
        runner = LocalRunner()
        res = await runner.run_python("print(1+1)", cwd=Path.cwd())
        self.assertEqual(res.stdout.strip(), "2")
        self.assertEqual(res.exit_code, 0)


class TestDockerRunner(unittest.IsolatedAsyncioTestCase):
    async def test_run_command(self):
        if os.system("docker ps > /dev/null 2>&1") != 0:
            self.skipTest("Docker not running")
        runner = DockerRunner()
        res = await runner.run_command(["echo", "hello from docker"], cwd=Path.cwd())
        self.assertIn("hello from docker", res.stdout)
        self.assertEqual(res.exit_code, 0)

    async def test_run_python(self):
        if os.system("docker ps > /dev/null 2>&1") != 0:
            self.skipTest("Docker not running")
        runner = DockerRunner()
        res = await runner.run_python("print('isolated')", cwd=Path.cwd())
        self.assertIn("isolated", res.stdout)
        self.assertEqual(res.exit_code, 0)


if __name__ == "__main__":
    unittest.main(verbosity=2)
