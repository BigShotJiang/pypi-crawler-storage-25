from __future__ import annotations

import io
import unittest

from mico.spinner import Spinner


class TtyBuffer(io.StringIO):
    def isatty(self) -> bool:
        return True


class TestSpinner(unittest.TestCase):
    def test_nested_pause_resume_does_not_deadlock(self) -> None:
        spinner = Spinner(stream=TtyBuffer())

        spinner.pause()
        spinner.pause()
        spinner.resume()
        spinner.resume()

        spinner.pause()
        spinner.resume()

    def test_statusbar_is_rendered_on_bottom_row(self) -> None:
        stream = TtyBuffer()
        spinner = Spinner(stream=stream)

        spinner._write_statusbar("thinking...")

        self.assertIn("\033[s", stream.getvalue())
        self.assertIn("\033[24;1H", stream.getvalue())
        self.assertIn("thinking...", stream.getvalue())


if __name__ == "__main__":
    unittest.main(verbosity=2)
