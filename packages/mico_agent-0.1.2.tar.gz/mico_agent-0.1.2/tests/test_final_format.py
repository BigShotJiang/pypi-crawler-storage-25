import unittest

import mico


class FormatFinalSummaryTests(unittest.TestCase):
    def test_empty_payload_renders_only_summary_section(self) -> None:
        out = mico.format_final_summary({})
        self.assertTrue(out.startswith("## Summary"))
        self.assertIn("(no summary)", out)
        self.assertNotIn("## Changed files", out)
        self.assertNotIn("## Tests", out)
        self.assertNotIn("## Review", out)
        self.assertNotIn("## Next steps", out)
        self.assertNotIn("## Commit", out)

    def test_summary_only(self) -> None:
        out = mico.format_final_summary({"summary": "Refactored auth module."})
        self.assertIn("## Summary", out)
        self.assertIn("Refactored auth module.", out)
        self.assertNotIn("## Changed files", out)

    def test_full_payload_section_order(self) -> None:
        payload = {
            "summary": "Did the thing.",
            "changed_files": ["a.py"],
            "added_files": ["b.py"],
            "deleted_files": ["c.py"],
            "tests": {
                "command": "pytest -q",
                "exit_code": 0,
                "summary": "5 passed",
                "errors": None,
            },
            "review": {"risks": ["race condition"], "missing": ["unit test for X"]},
            "next_steps": ["deploy", "monitor"],
            "commit_suggestion": "feat: add the thing",
        }
        out = mico.format_final_summary(payload)
        positions = {
            "summary": out.index("## Summary"),
            "changed": out.index("## Changed files"),
            "tests": out.index("## Tests"),
            "review": out.index("## Review"),
            "next": out.index("## Next steps"),
            "commit": out.index("## Commit"),
        }
        ordered = sorted(positions.items(), key=lambda kv: kv[1])
        self.assertEqual(
            [k for k, _ in ordered],
            ["summary", "changed", "tests", "review", "next", "commit"],
        )
        self.assertIn("- a.py", out)
        self.assertIn("- b.py (added)", out)
        self.assertIn("- c.py (deleted)", out)
        self.assertIn("command: pytest -q", out)
        self.assertIn("exit_code: 0", out)
        self.assertIn("- risk: race condition", out)
        self.assertIn("- missing: unit test for X", out)
        self.assertIn("1. deploy", out)
        self.assertIn("2. monitor", out)
        self.assertIn("feat: add the thing", out)

    def test_tests_none_is_skipped(self) -> None:
        out = mico.format_final_summary(
            {"summary": "x", "tests": None, "next_steps": ["go"]}
        )
        self.assertNotIn("## Tests", out)
        self.assertIn("## Next steps", out)

    def test_tests_with_errors_renders_errors(self) -> None:
        out = mico.format_final_summary(
            {
                "summary": "x",
                "tests": {
                    "command": "pytest",
                    "exit_code": 1,
                    "summary": "1 failed",
                    "errors": "AssertionError: nope",
                },
            }
        )
        self.assertIn("errors:", out)
        self.assertIn("AssertionError: nope", out)
        self.assertIn("exit_code: 1", out)

    def test_review_empty_lists_skipped(self) -> None:
        out = mico.format_final_summary(
            {"summary": "x", "review": {"risks": [], "missing": []}}
        )
        self.assertNotIn("## Review", out)

    def test_markdown_headings_use_double_hash(self) -> None:
        out = mico.format_final_summary(
            {"summary": "x", "next_steps": ["a"], "commit_suggestion": "fix: y"}
        )
        for heading in ("## Summary", "## Next steps", "## Commit"):
            self.assertIn(heading, out)

    def test_non_dict_payload_safe(self) -> None:
        out = mico.format_final_summary(None)  # type: ignore[arg-type]
        self.assertTrue(out.startswith("## Summary"))


class ParseGitStatusTests(unittest.TestCase):
    def test_clean_returns_empty(self) -> None:
        ch, ad, de = mico._parse_git_status_paths("clean")
        self.assertEqual((ch, ad, de), ([], [], []))

    def test_mixed_status(self) -> None:
        text = "## main\n M mico.py\n?? new.py\n D old.py\n"
        ch, ad, de = mico._parse_git_status_paths(text)
        self.assertIn("mico.py", ch)
        self.assertIn("new.py", ad)
        self.assertIn("old.py", de)


if __name__ == "__main__":
    unittest.main()
