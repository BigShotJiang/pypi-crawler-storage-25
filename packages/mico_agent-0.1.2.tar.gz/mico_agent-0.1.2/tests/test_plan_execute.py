"""plan_execute modu testleri — gerçek model yok, mock tabanlı."""
from __future__ import annotations

import json
import unittest
from pathlib import Path
from unittest.mock import patch, MagicMock

from mico.longrun import LongRunConfig, LongRunState, run_long_task, _plan_phase


def _final(msg: str) -> str:
    return json.dumps({"type": "final", "message": msg})


def _tool(cmd: str) -> str:
    return json.dumps({"type": "tool", "tool": "bash", "command": cmd})


class TestPlanPhase(unittest.IsolatedAsyncioTestCase):
    async def test_returns_steps_from_json(self):
        async def fake_call(messages, **kw):
            return json.dumps({"steps": ["Adım A", "Adım B", "Adım C"]})

        import mico.cli as cli_mod
        with patch.object(cli_mod, "call_model", side_effect=fake_call):
            import mico.longrun as lr
            steps = await lr._plan_phase("hedef", cli_mod)
        self.assertEqual(steps, ["Adım A", "Adım B", "Adım C"])

    async def test_fallback_to_goal_on_bad_json(self):
        async def fake_call(messages, **kw):
            return "bu json değil"

        import mico.cli as cli_mod
        with patch.object(cli_mod, "call_model", side_effect=fake_call):
            import mico.longrun as lr
            steps = await lr._plan_phase("tek hedef", cli_mod)
        self.assertEqual(steps, ["tek hedef"])

    async def test_fallback_on_model_error(self):
        async def bad_call(messages, **kw):
            raise RuntimeError("model down")

        import mico.cli as cli_mod
        with patch.object(cli_mod, "call_model", side_effect=bad_call):
            import mico.longrun as lr
            steps = await lr._plan_phase("hedef", cli_mod)
        self.assertEqual(steps, ["hedef"])


class TestPlanExecuteMode(unittest.IsolatedAsyncioTestCase):
    """run_long_task(mode='plan_execute') entegrasyon testleri."""

    def _make_cfg(self, steps: list[str], **kw) -> LongRunConfig:
        import tempfile
        tmp = tempfile.mkdtemp()
        defaults = dict(
            goal="test hedefi",
            mode="plan_execute",
            initial_steps=steps,
            max_turns=20,
            turns_per_step=5,
            wall_clock_timeout=60.0,
            cwd=tmp,
        )
        defaults.update(kw)
        return LongRunConfig(**defaults)

    async def test_initial_steps_skip_plan_phase(self):
        """initial_steps verilince plan fazı atlanmalı, model sadece execute eder."""
        call_log: list[str] = []

        async def fake_call(messages, **kw):
            # İlk mesajın içeriğine göre ne yapılacağını belirle
            user_content = next(
                (m["content"] for m in messages if m["role"] == "user"), ""
            )
            call_log.append(user_content[:40])
            return _final("LEDGER_UPDATE: done=adım\nTamamlandı.")

        async def fake_run(action, ctx):
            return "exit_code=0"

        import mico.cli as cli_mod
        with patch.object(cli_mod, "call_model", side_effect=fake_call), \
             patch.object(cli_mod, "run_tool", side_effect=fake_run), \
             patch.object(cli_mod, "save_session"), \
             patch.object(cli_mod, "runtime_context_text", return_value="ctx"), \
             patch.object(cli_mod, "build_system_prompt", return_value="sys"), \
             patch.object(cli_mod, "summarize_history", return_value="özet"), \
             patch.object(cli_mod, "ToolContext", MagicMock(return_value=MagicMock(
                 cwd=Path("/tmp"), approval="never", network_access=True,
                 tool_install=False, profile="fast",
             ))):
            cfg = self._make_cfg(["Adım 1", "Adım 2"])
            state = await run_long_task(cfg)

        self.assertIn(state.exit_reason, ("done", "partial"))
        # plan_phase çağrılmamış olmalı — call_log'da "steps" içeren JSON yok
        plan_calls = [c for c in call_log if '"steps"' in c]
        self.assertEqual(plan_calls, [])

    async def test_each_step_gets_fresh_context(self):
        """Her adım ayrı history ile başlamalı — adım 2 adım 1'in tool çıktılarını görmemeli."""
        step1_history_len: list[int] = []
        step2_history_len: list[int] = []
        current_step: list[int] = [0]

        async def fake_call(messages, **kw):
            if current_step[0] == 0:
                step1_history_len.append(len(messages))
            else:
                step2_history_len.append(len(messages))
            return _final("LEDGER_UPDATE: done=adım\nTamamlandı.")

        async def fake_run(action, ctx):
            return "exit_code=0\nçok uzun çıktı " * 50

        import mico.cli as cli_mod
        with patch.object(cli_mod, "call_model", side_effect=fake_call), \
             patch.object(cli_mod, "run_tool", side_effect=fake_run), \
             patch.object(cli_mod, "save_session"), \
             patch.object(cli_mod, "runtime_context_text", return_value="ctx"), \
             patch.object(cli_mod, "build_system_prompt", return_value="sys"), \
             patch.object(cli_mod, "summarize_history", return_value="özet"), \
             patch.object(cli_mod, "ToolContext", MagicMock(return_value=MagicMock(
                 cwd=Path("/tmp"), approval="never", network_access=True,
                 tool_install=False, profile="fast",
             ))):
            cfg = self._make_cfg(["Adım 1", "Adım 2"])
            state = await run_long_task(cfg)

        # Adım 2'nin ilk mesaj sayısı, adım 1'den bağımsız olmalı (≤3: system+summary+user)
        if step2_history_len:
            self.assertLessEqual(step2_history_len[0], 3)

    async def test_prior_summary_passed_to_next_step(self):
        """Adım 1'in sonucu adım 2'nin history'sine [ÖNCEKİ ADIMLAR ÖZETİ] olarak eklenmeli."""
        captured_messages: list[list[dict]] = []
        call_count = [0]

        async def fake_call(messages, **kw):
            captured_messages.append(list(messages))
            call_count[0] += 1
            return _final(f"Adım {call_count[0]} tamamlandı.")

        async def fake_run(action, ctx):
            return "exit_code=0"

        import mico.cli as cli_mod
        with patch.object(cli_mod, "call_model", side_effect=fake_call), \
             patch.object(cli_mod, "run_tool", side_effect=fake_run), \
             patch.object(cli_mod, "save_session"), \
             patch.object(cli_mod, "runtime_context_text", return_value="ctx"), \
             patch.object(cli_mod, "build_system_prompt", return_value="sys"), \
             patch.object(cli_mod, "summarize_history", return_value="özet"), \
             patch.object(cli_mod, "ToolContext", MagicMock(return_value=MagicMock(
                 cwd=Path("/tmp"), approval="never", network_access=True,
                 tool_install=False, profile="fast",
             ))):
            cfg = self._make_cfg(["Adım 1", "Adım 2"])
            state = await run_long_task(cfg)

        # Adım 2'nin mesajlarında ÖNCEKİ ADIMLAR ÖZETİ bulunmalı
        if len(captured_messages) >= 2:
            step2_msgs = captured_messages[1]
            contents = " ".join(m.get("content", "") for m in step2_msgs)
            self.assertIn("Adım 1", contents)

    async def test_done_steps_tracked_correctly(self):
        """Başarılı adımlar state.done'a, başarısız olanlar state.blocked'a gitmeli."""
        responses = [
            _final("LEDGER_UPDATE: done=adım1\nAdım 1 tamam."),
            # Adım 2: repeat_limit simüle et — hep aynı tool
            json.dumps({"type": "tool", "tool": "bash", "command": "same"}),
            json.dumps({"type": "tool", "tool": "bash", "command": "same"}),
            json.dumps({"type": "tool", "tool": "bash", "command": "same"}),
            _final("LEDGER_UPDATE: done=adım3\nAdım 3 tamam."),
        ]
        idx = [0]

        async def fake_call(messages, **kw):
            r = responses[min(idx[0], len(responses) - 1)]
            idx[0] += 1
            return r

        async def fake_run(action, ctx):
            return "exit_code=0\nout"

        import mico.cli as cli_mod
        with patch.object(cli_mod, "call_model", side_effect=fake_call), \
             patch.object(cli_mod, "run_tool", side_effect=fake_run), \
             patch.object(cli_mod, "save_session"), \
             patch.object(cli_mod, "runtime_context_text", return_value="ctx"), \
             patch.object(cli_mod, "build_system_prompt", return_value="sys"), \
             patch.object(cli_mod, "summarize_history", return_value="özet"), \
             patch.object(cli_mod, "ToolContext", MagicMock(return_value=MagicMock(
                 cwd=Path("/tmp"), approval="never", network_access=True,
                 tool_install=False, profile="fast",
             ))):
            cfg = self._make_cfg(["adım1", "adım2", "adım3"], max_repeat_actions=3)
            state = await run_long_task(cfg)

        self.assertIn("adım1", state.done)
        # adım2 repeat_limit'e girdi → blocked'a geçmeli
        blocked_text = " ".join(state.blocked)
        self.assertIn("adım2", blocked_text)
        self.assertIn("adım3", state.done)

    async def test_wall_clock_timeout_stops_steps(self):
        """Toplam wall_clock_timeout aşılınca kalan adımlar çalıştırılmamalı."""
        import mico.cli as cli_mod

        async def slow_call(messages, **kw):
            import asyncio
            await asyncio.sleep(0.05)
            return _final("tamamlandı")

        async def fake_run(action, ctx):
            return "exit_code=0"

        with patch.object(cli_mod, "call_model", side_effect=slow_call), \
             patch.object(cli_mod, "run_tool", side_effect=fake_run), \
             patch.object(cli_mod, "save_session"), \
             patch.object(cli_mod, "runtime_context_text", return_value="ctx"), \
             patch.object(cli_mod, "build_system_prompt", return_value="sys"), \
             patch.object(cli_mod, "summarize_history", return_value="özet"), \
             patch.object(cli_mod, "ToolContext", MagicMock(return_value=MagicMock(
                 cwd=Path("/tmp"), approval="never", network_access=True,
                 tool_install=False, profile="fast",
             ))):
            cfg = self._make_cfg(
                ["A", "B", "C", "D", "E"],
                wall_clock_timeout=0.001,  # 1ms — hemen timeout
            )
            state = await run_long_task(cfg)

        self.assertEqual(state.exit_reason, "timeout")
        # Tüm adımlar bitmemiş olmalı
        self.assertLess(len(state.done), 5)

    async def test_on_turn_end_called_per_step(self):
        """on_turn_end her adım sonunda çağrılmalı."""
        callbacks: list[str] = []

        def supervisor(s: LongRunState) -> None:
            callbacks.append(s.exit_reason or "?")

        async def fake_call(messages, **kw):
            return _final("tamamlandı")

        async def fake_run(action, ctx):
            return "exit_code=0"

        import mico.cli as cli_mod
        with patch.object(cli_mod, "call_model", side_effect=fake_call), \
             patch.object(cli_mod, "run_tool", side_effect=fake_run), \
             patch.object(cli_mod, "save_session"), \
             patch.object(cli_mod, "runtime_context_text", return_value="ctx"), \
             patch.object(cli_mod, "build_system_prompt", return_value="sys"), \
             patch.object(cli_mod, "summarize_history", return_value="özet"), \
             patch.object(cli_mod, "ToolContext", MagicMock(return_value=MagicMock(
                 cwd=Path("/tmp"), approval="never", network_access=True,
                 tool_install=False, profile="fast",
             ))):
            cfg = self._make_cfg(["A", "B", "C"], on_turn_end=supervisor)
            state = await run_long_task(cfg)

        self.assertEqual(len(callbacks), 3)


# TestTriagePlanExecuteIntegration kaldırıldı — longrun devre dışı bırakıldı.


if __name__ == "__main__":
    unittest.main(verbosity=2)
