from __future__ import annotations

import asyncio
import io
import json
import os
import tempfile
import unittest
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import patch

from prompt_toolkit.document import Document

import mico.repl as repl
import mico.slash as slash


class SlashRegistryTests(unittest.TestCase):
    def test_core_slash_commands_are_curated(self) -> None:
        self.assertEqual(
            slash.names(),
            ["cd", "clear", "compact", "exit", "help", "history", "mode", "model", "reload", "save", "thinking"],
        )

    def test_model_alias_does_not_appear_in_top_level_names(self) -> None:
        self.assertNotIn("models", slash.names())
        self.assertIs(slash.REGISTRY["models"], slash.REGISTRY["model"])


class SlashSuggestionTests(unittest.TestCase):
    def test_slash_suggestion_text_returns_suffix(self) -> None:
        self.assertEqual(repl._slash_suggestion_text("/mo"), "de")

    def test_slash_suggestion_text_returns_args_hint_for_exact_match(self) -> None:
        self.assertEqual(repl._slash_suggestion_text("/thinking"), " <on|off>")

    def test_slash_completer_lists_commands_for_bare_slash(self) -> None:
        completer = repl._build_slash_completer()
        assert completer is not None
        items = list(completer.get_completions(Document("/"), None))
        texts = [item.display_text for item in items]
        self.assertIn("/help", texts)
        self.assertIn("/model", texts)
        self.assertIn("/thinking <on|off>", texts)


class SlashDispatchTests(unittest.TestCase):
    def make_state(self, cwd: str) -> slash.RuntimeState:
        profile = SimpleNamespace(
            model_name="demo-model",
            model_path="/tmp/demo-model",
            backend="mlx",
            max_tokens=2048,
            context_window=8192,
            prompt_cache_size=8,
            prompt_cache_bytes="1GB",
            kv_bits=4,
            temperature=0.0,
            min_p=0.0,
            repetition_penalty=1.0,
            name="fast",
        )
        return slash.RuntimeState(profile=profile, cwd=cwd, session_id="test-session")

    def dispatch_and_capture(self, line: str, state: slash.RuntimeState) -> str:
        stream = io.StringIO()
        with patch("sys.stdout", stream):
            handled = asyncio.run(slash.dispatch(line, state))
        self.assertTrue(handled)
        return stream.getvalue()

    def test_mode_thinking_clear_and_exit_are_local(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            state = self.make_state(tmp)
            text = self.dispatch_and_capture("/mode code", state)
            self.assertIn("Mod ayarlandı: code", text)
            self.assertEqual(state.mode, "code")

            text = self.dispatch_and_capture("/thinking on", state)
            self.assertIn("Düşünme modu: açık", text)
            self.assertTrue(state.thinking)

            text = self.dispatch_and_capture("/clear", state)
            self.assertIn("Ekran temizlendi.", text)

            text = self.dispatch_and_capture("/exit", state)
            self.assertIn("Çıkılıyor...", text)
            self.assertTrue(state.quit_requested)

    def test_cd_and_model_work_without_live_model_call(self) -> None:
        original_cwd = Path.cwd()
        with tempfile.TemporaryDirectory() as tmp:
            state = self.make_state(tmp)
            nested = Path(tmp) / "nested"
            nested.mkdir()

            text = self.dispatch_and_capture(f"/cd {nested}", state)
            self.assertIn("Değiştirildi:", text)
            self.assertEqual(Path(state.cwd).resolve(), nested.resolve())

            with patch("mico.model_recommender.discover_models", return_value=[]):
                with patch("mico.model_recommender.save_models"):
                    text = self.dispatch_and_capture("/model", state)
            self.assertIn("Algılanan model yok.", text)
        os.chdir(original_cwd)

    def test_history_save_compact_reload_do_not_depend_on_model_family(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            state = self.make_state(tmp)
            session_dir = Path(tmp) / "sessions"
            session_dir.mkdir()
            session_file = session_dir / "test-session.json"
            session_file.write_text(json.dumps([{"role": "user", "content": "merhaba"}]), encoding="utf-8")

            with patch("mico.cli.SESSIONS_DIR", session_dir):
                text = self.dispatch_and_capture("/history", state)
                self.assertIn("[user", text)

                with patch("mico.cli.save_session") as save_session:
                    text = self.dispatch_and_capture("/save", state)
                    self.assertIn("Oturum kayıtlı.", text)
                    save_session.assert_called_once()

                async def _fake_compact(history, session_id, force=False):
                    return history

                with patch("mico.cli.maybe_compact_history", side_effect=_fake_compact):
                    text = self.dispatch_and_capture("/compact", state)
                    self.assertIn("Geçmiş özetlendi:", text)

            new_profile = SimpleNamespace(name="reloaded")
            with patch("mico.model_recommender.load_profile", return_value=new_profile):
                text = self.dispatch_and_capture("/reload", state)
            self.assertIn("Profil diskten yeniden yüklendi.", text)
            self.assertIs(state.profile, new_profile)

    def test_switch_model_clears_incompatible_draft(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            model_dir = root / "base-model"
            model_dir.mkdir()
            draft_dir = root / "old-draft"
            draft_dir.mkdir()

            state = self.make_state(tmp)
            state.profile.draft_model_path = str(draft_dir)

            new_profile = SimpleNamespace(
                model_name="base-model",
                model_path=str(model_dir),
                backend="mlx",
                max_tokens=1024,
                context_window=4096,
                thinking=False,
                thinking_budget=0,
                temperature=0.0,
                draft_model_path="",
            )

            with patch("mico.hardware.load_hardware", return_value=object()):
                with patch("mico.model_recommender.recommend_profile", return_value=new_profile):
                    with patch("mico.model_recommender.save_profile") as save_profile:
                        with patch("mico.server.stop") as stop_server:
                            with patch("mico.model_ops.is_compatible_draft_model", return_value=False):
                                with patch("mico.model_ops.discover_draft_models", return_value=[]):
                                    with patch("sys.stdout", io.StringIO()) as out:
                                        slash._switch_model_inplace(state, {"path": str(model_dir), "name": "base-model", "backend": "mlx"})

            self.assertEqual(state.profile.draft_model_path, "")
            self.assertEqual(out.getvalue().count("Draft: none"), 1)
            save_profile.assert_called_once()
            stop_server.assert_called_once()

    def test_switch_model_keeps_compatible_existing_draft(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            model_dir = root / "base-model"
            model_dir.mkdir()
            draft_dir = root / "assistant-draft"
            draft_dir.mkdir()

            state = self.make_state(tmp)
            state.profile.draft_model_path = str(draft_dir)

            new_profile = SimpleNamespace(
                model_name="base-model",
                model_path=str(model_dir),
                backend="mlx",
                max_tokens=1024,
                context_window=4096,
                thinking=False,
                thinking_budget=0,
                temperature=0.0,
                draft_model_path="",
            )

            with patch("mico.hardware.load_hardware", return_value=object()):
                with patch("mico.model_recommender.recommend_profile", return_value=new_profile):
                    with patch("mico.model_recommender.save_profile"):
                        with patch("mico.server.stop"):
                            with patch("mico.model_ops.is_compatible_draft_model", return_value=True):
                                with patch("mico.model_ops.discover_draft_models") as discover_draft_models:
                                    slash._switch_model_inplace(state, {"path": str(model_dir), "name": "base-model", "backend": "mlx"})

            self.assertEqual(state.profile.draft_model_path, str(draft_dir))
            discover_draft_models.assert_not_called()


if __name__ == "__main__":
    unittest.main(verbosity=2)
