"""Tests for the role-based model profile system and ModelSlot mutex."""
from __future__ import annotations

import os
import sys
import threading
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch

REPO = Path(__file__).resolve().parent.parent
if str(REPO) not in sys.path:
    sys.path.insert(0, str(REPO))

from mico.profiles_runtime import (  # noqa: E402
    BUILTIN_PROFILES,
    ModelSlot,
    RoleConfig,
    list_profiles,
    load_profile,
    resolve_logical_model,
    resolve_role_model,
)


class ProfileLoadingTests(unittest.TestCase):
    def test_load_profile_fast_has_worker(self) -> None:
        profile = load_profile("fast")
        self.assertEqual(profile.name, "fast")
        self.assertIn("worker", profile.roles)
        self.assertEqual(profile.default_role, "worker")

    def test_load_profile_deep_has_three_roles(self) -> None:
        profile = load_profile("deep")
        for role in ("architect", "worker", "reviewer"):
            self.assertIn(role, profile.roles, f"deep profile missing {role}")

    def test_load_profile_unknown_raises(self) -> None:
        with self.assertRaises(ValueError):
            load_profile("nonexistent")

    def test_list_profiles_contains_builtins(self) -> None:
        names = set(list_profiles())
        self.assertEqual(names, set(BUILTIN_PROFILES.keys()))
        for expected in ("fast", "normal", "deep", "review", "docs"):
            self.assertIn(expected, names)

    def test_resolve_role_model_missing_returns_none(self) -> None:
        profile = load_profile("fast")
        self.assertIsNone(resolve_role_model("reviewer", profile))

    def test_resolve_logical_model_substring_match(self) -> None:
        # Use synthetic Path stand-ins so we don't depend on local model files.
        candidates = [Path("/tmp/Qwen3.5-9B-instruct"), Path("/tmp/QwOpus-18B-8bit")]
        match = resolve_logical_model("qwen3.5", candidates)
        self.assertEqual(match, "/tmp/Qwen3.5-9B-instruct")
        match2 = resolve_logical_model("qwopus", candidates)
        self.assertEqual(match2, "/tmp/QwOpus-18B-8bit")
        self.assertIsNone(resolve_logical_model("gemma", candidates))

    def test_resolve_logical_model_fallback(self) -> None:
        candidates = [Path("/tmp/Qwen3.6-27B-4bit")]
        match = resolve_logical_model("qwopus", candidates, fallbacks=("qwen3.6",))
        self.assertEqual(match, "/tmp/Qwen3.6-27B-4bit")

    def test_load_profile_repo_toml_override(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            config = root / "mico.profiles.toml"
            config.write_text(
                """
[profiles.normal.reviewer]
model = "local-reviewer"
base_url = "http://127.0.0.1:1235/v1"
context = 4096

[profiles.custom.worker]
model = "tiny-worker"
base_url = "http://127.0.0.1:9999/v1"
context = 2048
                """.strip(),
                encoding="utf-8",
            )
            with patch.dict(os.environ, {}, clear=False):
                with patch("pathlib.Path.cwd", return_value=root):
                    profile = load_profile("normal")
                    self.assertEqual(profile.roles["reviewer"].model, "local-reviewer")
                    self.assertEqual(profile.roles["reviewer"].base_url, "http://127.0.0.1:1235/v1")
                    custom = load_profile("custom")
                    self.assertEqual(custom.roles["worker"].model, "tiny-worker")

    def test_list_profiles_includes_disk_profile(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            config = root / "mico.profiles.toml"
            config.write_text(
                """
[profiles.edge.worker]
model = "edge-worker"
                """.strip(),
                encoding="utf-8",
            )
            with patch.dict(os.environ, {}, clear=False):
                with patch("pathlib.Path.cwd", return_value=root):
                    names = list_profiles()
            self.assertIn("edge", names)


class ModelSlotMutexTests(unittest.IsolatedAsyncioTestCase):
    def setUp(self) -> None:
        # Reset slot state for isolation.
        ModelSlot.current_model = None
        ModelSlot.current_role = None
        ModelSlot.set_unload_hook(None)
        ModelSlot.set_load_hook(None)

    async def test_acquire_same_model_twice_no_unload(self) -> None:
        unloaded: list[str] = []
        loaded: list[str] = []
        ModelSlot.set_unload_hook(lambda m: unloaded.append(m))
        ModelSlot.set_load_hook(lambda m, cfg: loaded.append(m))
        cfg = RoleConfig(model="m1", resolved_path="/path/m1")
        async with ModelSlot.acquire("worker", cfg):
            pass
        async with ModelSlot.acquire("worker", cfg):
            pass
        self.assertEqual(unloaded, [])
        self.assertEqual(loaded, ["/path/m1"])  # only one load
        self.assertEqual(ModelSlot.current_model, "/path/m1")

    async def test_acquire_different_model_triggers_unload(self) -> None:
        unloaded: list[str] = []
        loaded: list[str] = []
        ModelSlot.set_unload_hook(lambda m: unloaded.append(m))
        ModelSlot.set_load_hook(lambda m, cfg: loaded.append(m))
        a = RoleConfig(model="ma", resolved_path="/path/A")
        b = RoleConfig(model="mb", resolved_path="/path/B")
        async with ModelSlot.acquire("worker", a):
            self.assertEqual(ModelSlot.current_model, "/path/A")
        async with ModelSlot.acquire("reviewer", b):
            self.assertEqual(ModelSlot.current_model, "/path/B")
            self.assertEqual(ModelSlot.current_role, "reviewer")
        self.assertEqual(unloaded, ["/path/A"])
        self.assertEqual(loaded, ["/path/A", "/path/B"])

    async def test_acquire_serializes_concurrent_calls(self) -> None:
        # ModelSlot.acquire is now an async context manager; threading-based
        # serialization test replaced with asyncio task concurrency check.
        import asyncio
        observed: list[tuple[str, str]] = []
        cfg_a = RoleConfig(model="ma", resolved_path="/A")
        cfg_b = RoleConfig(model="mb", resolved_path="/B")

        async def hold(role: str, cfg: RoleConfig) -> None:
            async with ModelSlot.acquire(role, cfg):
                observed.append((role, ModelSlot.current_model or ""))

        await asyncio.gather(hold("worker", cfg_a), hold("reviewer", cfg_b))
        self.assertEqual(len(observed), 2)
        for role, model in observed:
            if role == "worker":
                self.assertEqual(model, "/A")
            else:
                self.assertEqual(model, "/B")


if __name__ == "__main__":
    unittest.main()
