"""Tests for mico.audit module."""
import json
import unittest
from pathlib import Path
from tempfile import TemporaryDirectory

from mico.audit import (
    AuditLogger,
    RunAuditEntry,
    format_audit_summary,
)


class TestAuditLogger(unittest.TestCase):
    """Test audit logging."""

    def test_audit_logger_start(self):
        """Test starting audit entry."""
        logger = AuditLogger()
        logger.start("auto", "fast", "test task")
        entry = logger.current()
        self.assertIsNotNone(entry)
        self.assertEqual(entry.mode, "auto")
        self.assertEqual(entry.profile, "fast")

    def test_audit_logger_record_command(self):
        """Test recording commands."""
        logger = AuditLogger()
        logger.start("auto", "fast")
        logger.record_command("git status")
        logger.record_command("ls -la", blocked=True)

        entry = logger.current()
        self.assertIn("git status", entry.commands_executed)
        self.assertIn("ls -la", entry.commands_blocked)

    def test_audit_logger_record_file_selected(self):
        """Test recording selected files."""
        logger = AuditLogger()
        logger.start("auto", "fast")
        logger.record_file_selected("src/main.py")
        logger.record_file_selected("src/utils.py")

        entry = logger.current()
        self.assertEqual(len(entry.selected_files), 2)
        self.assertIn("src/main.py", entry.selected_files)

    def test_audit_logger_record_file_changed(self):
        """Test recording changed files."""
        logger = AuditLogger()
        logger.start("auto", "fast")
        logger.record_file_changed("src/main.py")
        logger.record_file_changed("tests/test_main.py")

        entry = logger.current()
        self.assertEqual(len(entry.changed_files), 2)

    def test_audit_logger_record_test(self):
        """Test recording test results."""
        logger = AuditLogger()
        logger.start("auto", "fast")
        logger.record_test("5 tests passed, 0 failed")

        entry = logger.current()
        self.assertTrue(entry.tests_run)
        self.assertEqual(entry.test_result, "5 tests passed, 0 failed")

    def test_audit_logger_finish_writes_file(self):
        """Test finish() writes JSON file."""
        with TemporaryDirectory() as tmpdir:
            project_root = Path(tmpdir)
            logger = AuditLogger(project_root)
            logger.start("auto", "fast", "test")
            logger.record_command("ls -la")
            logger.finish("ok")

            # Check that .agent-runs directory was created
            log_dir = project_root / ".agent-runs"
            self.assertTrue(log_dir.exists())

            # Check that JSON files were written
            json_files = list(log_dir.glob("*.json"))
            self.assertGreater(len(json_files), 0)

            # Verify JSON is valid
            with open(json_files[0]) as f:
                data = json.load(f)
                self.assertEqual(data["mode"], "auto")
                self.assertEqual(data["profile"], "fast")

    def test_audit_logger_redacts_secrets(self):
        """Test that sensitive paths are redacted."""
        with TemporaryDirectory() as tmpdir:
            project_root = Path(tmpdir)
            logger = AuditLogger(project_root)
            logger.start("auto", "fast")
            # Record paths that should be redacted
            logger.record_file_selected(".env")
            logger.record_file_selected("~/.ssh/id_rsa")
            logger.record_file_selected("src/utils.py")  # Should be kept
            logger.finish("ok")

            # Read back the JSON and verify redaction
            log_dir = project_root / ".agent-runs"
            json_files = list(log_dir.glob("*.json"))
            if json_files:
                with open(json_files[0]) as f:
                    data = json.load(f)
                    # .env and ~/.ssh paths should be filtered out
                    for path in data.get("selected_files", []):
                        self.assertNotIn(".env", path)
                        self.assertNotIn("~/.ssh", path)

    def test_audit_logger_no_log_dir(self):
        """Test audit logger without log directory doesn't crash."""
        logger = AuditLogger(None)
        logger.start("auto", "fast")
        logger.record_command("ls")
        # Should not crash
        logger.finish("ok")
        entry = logger.current()
        self.assertEqual(entry.final_status, "ok")

    def test_audit_logger_deduplicates_entries(self):
        """Test audit logger deduplicates command entries."""
        logger = AuditLogger()
        logger.start("auto", "fast")
        logger.record_command("git status")
        logger.record_command("git status")
        logger.record_command("git status")

        entry = logger.current()
        self.assertEqual(entry.commands_executed.count("git status"), 1)

    def test_format_audit_summary(self):
        """Test format_audit_summary produces valid output."""
        entry = RunAuditEntry(
            run_id="2024-01-01T00-00-00",
            timestamp="2024-01-01T00:00:00",
            mode="auto",
            profile="fast",
            task_size="small",
            task_preview="fix typo",
            selected_files=["src/main.py"],
            changed_files=["src/main.py"],
            lines_changed_estimate=5,
            commands_executed=["git status"],
            final_status="ok",
        )
        output = format_audit_summary(entry)
        self.assertIn("Audit Summary:", output)
        self.assertIn("Run ID:", output)
        self.assertIn("Mode: auto", output)
        self.assertIn("Profile: fast", output)
        self.assertIn("Status: ok", output)


if __name__ == "__main__":
    unittest.main()
