from __future__ import annotations

import sys
import types
import unittest

import importlib

import mico

model_client = importlib.import_module("mico.model_client")


class TestModelClientControls(unittest.TestCase):
    def test_local_openai_backend_supports_extended_controls(self) -> None:
        fake_cli = types.SimpleNamespace(
            MODEL_PROVIDER="openai",
            API_BASE="http://127.0.0.1:8080/v1",
            os=types.SimpleNamespace(environ={"MICO_EXTERNAL_API_BASE": "http://127.0.0.1:8080/v1"}),
        )
        old_cli = mico.__dict__.get("cli")
        old_module = sys.modules.get("mico.cli")
        try:
            mico.cli = fake_cli
            sys.modules["mico.cli"] = fake_cli
            self.assertTrue(model_client.supports_extended_generation_controls())
        finally:
            if old_cli is None:
                try:
                    delattr(mico, "cli")
                except AttributeError:
                    pass
            else:
                mico.cli = old_cli
            if old_module is None:
                sys.modules.pop("mico.cli", None)
            else:
                sys.modules["mico.cli"] = old_module

    def test_remote_ollama_backend_does_not_support_extended_controls(self) -> None:
        fake_cli = types.SimpleNamespace(
            MODEL_PROVIDER="ollama",
            API_BASE="http://remote-host:11434/v1",
            os=types.SimpleNamespace(environ={}),
        )
        old_cli = mico.__dict__.get("cli")
        old_module = sys.modules.get("mico.cli")
        try:
            mico.cli = fake_cli
            sys.modules["mico.cli"] = fake_cli
            self.assertFalse(model_client.supports_extended_generation_controls())
        finally:
            if old_cli is None:
                try:
                    delattr(mico, "cli")
                except AttributeError:
                    pass
            else:
                mico.cli = old_cli
            if old_module is None:
                sys.modules.pop("mico.cli", None)
            else:
                sys.modules["mico.cli"] = old_module


if __name__ == "__main__":
    unittest.main(verbosity=2)
