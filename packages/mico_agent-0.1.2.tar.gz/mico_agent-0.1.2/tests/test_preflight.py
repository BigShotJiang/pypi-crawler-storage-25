"""Tests for mico.preflight module."""
import unittest
from pathlib import Path
from tempfile import TemporaryDirectory
from unittest.mock import patch, MagicMock

from mico.preflight import (
    classify_task_size,
    check_model_sanity,
    format_task_size,
    format_preflight,
    run_preflight,
    PreflightResult,
)


class TestClassifyTaskSize(unittest.TestCase):
    """Test task size classification."""

    def test_classify_task_size_small(self):
        """Test small task classification."""
        result = classify_task_size("fix typo in readme")
        self.assertEqual(result.size, "small")
        self.assertEqual(result.recommended_profile, "fast")

    def test_classify_task_size_medium(self):
        """Test medium task classification."""
        result = classify_task_size("add feature with tests in auth and api modules")
        self.assertEqual(result.size, "medium")
        self.assertEqual(result.recommended_profile, "normal")

    def test_classify_task_size_large(self):
        """Test large task classification."""
        result = classify_task_size("refactor entire codebase for better structure")
        self.assertEqual(result.size, "large")
        self.assertEqual(result.recommended_profile, "deep")

    def test_classify_task_size_large_migrate(self):
        """Test large classification for migrate keyword."""
        result = classify_task_size("migrate from old framework to new one")
        self.assertEqual(result.size, "large")

    def test_classify_task_size_large_rewrite(self):
        """Test large classification for rewrite keyword."""
        result = classify_task_size("rewrite authentication system")
        self.assertEqual(result.size, "large")

    def test_classify_task_size_empty(self):
        """Test empty task defaults to small."""
        result = classify_task_size("")
        self.assertEqual(result.size, "small")

    def test_format_task_size_output(self):
        """Test format_task_size produces valid output."""
        result = classify_task_size("fix bug in main.py")
        output = format_task_size(result)
        self.assertIn("Task size:", output)
        self.assertIn("Recommended mode:", output)
        self.assertIn("Reason:", output)
        self.assertIn("Estimated touched files:", output)
        self.assertIn("Risk:", output)


class TestModelSanity(unittest.TestCase):
    """Test model sanity checking."""

    def test_check_model_sanity_ok(self):
        """Test successful model sanity check."""
        with patch("mico.preflight.requests.get") as mock_get:
            mock_response = MagicMock()
            mock_response.status_code = 200
            mock_response.json.return_value = {
                "data": [{"id": "qwen3.5 9b 8-bit"}]
            }
            mock_get.return_value = mock_response

            result = check_model_sanity(
                "fast", "worker",
                "http://localhost:8080/v1",
                "qwen3.5"
            )
            self.assertTrue(result.ok)
            self.assertIn("qwen3.5", result.connected_model.lower())

    def test_check_model_sanity_mismatch(self):
        """Test model mismatch detection."""
        with patch("mico.preflight.requests.get") as mock_get:
            mock_response = MagicMock()
            mock_response.status_code = 200
            mock_response.json.return_value = {
                "data": [{"id": "some-other-model"}]
            }
            mock_get.return_value = mock_response

            result = check_model_sanity(
                "fast", "worker",
                "http://localhost:8080/v1",
                "qwen3.5"
            )
            self.assertFalse(result.ok)
            self.assertNotEqual(result.connected_model, "unknown")

    def test_check_model_sanity_endpoint_unreachable(self):
        """Test behavior when endpoint is unreachable."""
        import requests
        with patch("mico.preflight.requests.get") as mock_get:
            mock_get.side_effect = requests.RequestException("Connection refused")

            result = check_model_sanity(
                "fast", "worker",
                "http://localhost:9999/v1",
                "qwen3.5"
            )
            self.assertEqual(result.connected_model, "unknown")

    def test_check_model_sanity_case_insensitive(self):
        """Test case-insensitive hint matching."""
        with patch("mico.preflight.requests.get") as mock_get:
            mock_response = MagicMock()
            mock_response.status_code = 200
            mock_response.json.return_value = {
                "data": [{"id": "QWEN3.5 9B 8-BIT"}]
            }
            mock_get.return_value = mock_response

            result = check_model_sanity(
                "fast", "worker",
                "http://localhost:8080/v1",
                "qwen3.5"
            )
            self.assertTrue(result.ok)


class TestFormatPreflight(unittest.TestCase):
    """Test preflight formatting."""

    def test_format_preflight_output(self):
        """Test format_preflight produces valid output."""
        result = PreflightResult(
            project_root=Path("/tmp/project"),
            git_ok=True,
            dirty=False,
            mode="auto",
            profile="fast",
            model_info="Qwen3.5 9B 8-bit (ok)",
            context_limit=8192,
            task_size="small",
            permission_policy="balanced",
            ready=True,
            warnings=[],
        )
        output = format_preflight(result)
        self.assertIn("Preflight:", output)
        self.assertIn("project root:", output)
        self.assertIn("git:", output)
        self.assertIn("ready:", output)
        self.assertIn("yes", output)

    def test_format_preflight_with_warnings(self):
        """Test format_preflight includes warnings."""
        result = PreflightResult(
            project_root=Path("/tmp/project"),
            git_ok=True,
            dirty=True,
            mode="auto",
            profile="fast",
            model_info="Qwen3.5 9B 8-bit",
            context_limit=8192,
            ready=False,
            warnings=["Repo is dirty", "Model mismatch"],
        )
        output = format_preflight(result)
        self.assertIn("Warnings:", output)
        self.assertIn("Repo is dirty", output)
        self.assertIn("Model mismatch", output)
        self.assertIn("NO", output)


class TestRunPreflight(unittest.TestCase):
    """Test run_preflight integration."""

    def test_run_preflight_no_crash(self):
        """Test run_preflight doesn't crash with temp directory."""
        with TemporaryDirectory() as tmpdir:
            cwd = Path(tmpdir)
            ctx = MagicMock()
            ctx.mode = "auto"
            ctx.profile = "fast"
            ctx.permission_mode = "balanced"

            result = run_preflight(ctx, task="test task", cwd=cwd)
            self.assertIsNotNone(result)
            self.assertEqual(result.profile, "fast")

    def test_run_preflight_extracts_mode(self):
        """Test run_preflight extracts mode from context."""
        ctx = MagicMock()
        ctx.mode = "manual"
        ctx.profile = "normal"
        ctx.permission_mode = "strict"

        result = run_preflight(ctx)
        self.assertEqual(result.mode, "manual")
        self.assertEqual(result.profile, "normal")
        self.assertEqual(result.permission_policy, "strict")

    def test_run_preflight_classifies_task(self):
        """Test run_preflight classifies task size."""
        ctx = MagicMock()
        ctx.mode = "auto"
        ctx.profile = "fast"

        result = run_preflight(ctx, task="refactor entire codebase")
        self.assertEqual(result.task_size, "large")


if __name__ == "__main__":
    unittest.main()
