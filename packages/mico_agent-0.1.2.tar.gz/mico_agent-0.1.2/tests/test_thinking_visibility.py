from __future__ import annotations

import unittest
from unittest.mock import patch

import mico.cli as cli
from mico.model_client import stream_model_text


class TestThinkingVisibility(unittest.TestCase):
    def setUp(self) -> None:
        self.original_monologue_open = cli.MONOLOGUE_OPEN
        self.original_monologue_buffer = cli.MONOLOGUE_BUFFER
        self.original_thinking_full_buffer = cli.THINKING_FULL_BUFFER
        self.original_thinking_collapsed = cli.THINKING_COLLAPSED
        self.original_default_collapse = cli.DEFAULT_COLLAPSE_THINKING
        self.original_use_plain_stdout = cli.USE_PLAIN_STDOUT
        self.original_stream_expect_action_json = cli.STREAM_EXPECT_ACTION_JSON
        self.original_json_stream_filter = cli._JSON_STREAM_FILTER
        self.original_streaming_active = cli._STREAMING_ACTIVE
        self.original_active_spinner = cli._ACTIVE_SPINNER

    def tearDown(self) -> None:
        cli.MONOLOGUE_OPEN = self.original_monologue_open
        cli.MONOLOGUE_BUFFER = self.original_monologue_buffer
        cli.THINKING_FULL_BUFFER = self.original_thinking_full_buffer
        cli.THINKING_COLLAPSED = self.original_thinking_collapsed
        cli.DEFAULT_COLLAPSE_THINKING = self.original_default_collapse
        cli.USE_PLAIN_STDOUT = self.original_use_plain_stdout
        cli.STREAM_EXPECT_ACTION_JSON = self.original_stream_expect_action_json
        cli._JSON_STREAM_FILTER = self.original_json_stream_filter
        cli._STREAMING_ACTIVE = self.original_streaming_active
        cli._ACTIVE_SPINNER = self.original_active_spinner

    def test_monologue_is_visible_by_default_in_tui(self) -> None:
        cli.MONOLOGUE_OPEN = False
        cli.DEFAULT_COLLAPSE_THINKING = False
        cli.USE_PLAIN_STDOUT = False

        with patch.object(cli, "stream_stdout") as stream_stdout:
            cli.ensure_monologue_open()

        self.assertFalse(cli.THINKING_COLLAPSED)
        stream_stdout.assert_not_called()

    def test_placeholder_is_shown_when_collapse_enabled(self) -> None:
        cli.MONOLOGUE_OPEN = False
        cli.DEFAULT_COLLAPSE_THINKING = True
        cli.USE_PLAIN_STDOUT = False

        with patch.object(cli, "stream_stdout") as stream_stdout:
            cli.ensure_monologue_open()

        self.assertTrue(cli.THINKING_COLLAPSED)
        stream_stdout.assert_called_once()

    def test_plain_stdout_direct_answer_suppresses_thinking_and_streams_visible_text(self) -> None:
        cli.USE_PLAIN_STDOUT = True
        cli.STREAM_EXPECT_ACTION_JSON = False

        with patch.object(cli, "stream_monologue_text") as stream_monologue_text:
            with patch.object(cli, "stream_stdout") as stream_stdout:
                in_think, carry, public_output_started, suppress_think = stream_model_text(
                    "<think>private scratch</think>Sonuc: x = -1/11",
                )

        self.assertFalse(in_think)
        self.assertEqual(carry, "")
        self.assertTrue(public_output_started)
        self.assertFalse(suppress_think)
        stream_monologue_text.assert_not_called()
        stream_stdout.assert_called_once_with("Sonuc: x = -1/11")

    def test_plain_stdout_agentic_stream_keeps_pre_json_prose_out_of_public_output(self) -> None:
        cli.USE_PLAIN_STDOUT = True
        cli.STREAM_EXPECT_ACTION_JSON = True

        with patch.object(cli, "stream_monologue_text") as stream_monologue_text:
            with patch.object(cli, "stream_stdout") as stream_stdout:
                in_think, carry, public_output_started, suppress_think = stream_model_text(
                    "Planning...\n{\"type\":\"final\",\"message\":\"ok\"}",
                )

        self.assertFalse(in_think)
        self.assertEqual(carry, "")
        self.assertTrue(public_output_started)
        self.assertFalse(suppress_think)
        stream_monologue_text.assert_called_once_with("Planning...\n")
        stream_stdout.assert_called_once_with("{\"type\":\"final\",\"message\":\"ok\"}")

    def test_plain_stdout_direct_answer_bypasses_json_filter(self) -> None:
        class DummyFilter:
            def feed(self, chunk: str) -> str:
                return ""

        cli.USE_PLAIN_STDOUT = True
        cli.STREAM_EXPECT_ACTION_JSON = False
        cli._JSON_STREAM_FILTER = DummyFilter()
        cli._STREAMING_ACTIVE = False
        cli._ACTIVE_SPINNER = None

        with patch("mico.ui.stream_text") as stream_text:
            cli.stream_stdout("{not json}")

        stream_text.assert_called_once_with("{not json}")


class TestJsonStreamFilterProseFallback(unittest.TestCase):
    def test_prose_only_stream_returns_fallback(self) -> None:
        from mico.ui import JsonStreamFilter

        collected: list[str] = []
        f = JsonStreamFilter(on_monologue_text=collected.append)

        f.feed("Yanıt: ")
        f.feed("x = 42\n")

        self.assertEqual(f.get_prose_fallback(), "Yanıt: x = 42")
        self.assertFalse(f.message_shown)

    def test_json_final_suppresses_prose_fallback(self) -> None:
        from mico.ui import JsonStreamFilter

        f = JsonStreamFilter()
        f.feed('{"type":"final","message":"merhaba"}')
        f.finalize()

        self.assertTrue(f.message_shown)
        self.assertEqual(f.get_prose_fallback(), "")

    def test_prose_before_json_captured_in_fallback(self) -> None:
        from mico.ui import JsonStreamFilter

        collected: list[str] = []
        f = JsonStreamFilter(on_monologue_text=collected.append)
        # Prose prefix then JSON final
        f.feed('Düşünüyorum...\n{"type":"final","message":"sonuç"}')
        f.finalize()

        self.assertTrue(f.message_shown)
        # Fallback returns empty because JSON final was received
        self.assertEqual(f.get_prose_fallback(), "")


if __name__ == "__main__":
    unittest.main(verbosity=2)
