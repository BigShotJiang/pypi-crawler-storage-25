from __future__ import annotations

import json
import sys
import tempfile
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from benchmarks import run_benchmarks as bench_run
from benchmarks import validate_suite as bench_validate
from benchmarks.init_submission import template_payload


class BenchmarkManifestTests(unittest.TestCase):
    def test_infer_category_prefers_explicit_category(self) -> None:
        task = {"category": "docs", "title": "Fix bug", "task": "debug traceback"}
        self.assertEqual(bench_validate.infer_category(task), "docs")

    def test_render_markdown_includes_structured_fields(self) -> None:
        rendered = bench_run.render_markdown(
            [
                {
                    "id": "t1",
                    "title": "Sample task",
                    "category": "bugfix",
                    "mode": "code",
                    "recommended_profile": "fast",
                    "status": "pass",
                    "metrics": {"tests_passed": True},
                    "aggregate": {"passed_checks": 1, "possible_checks": 1},
                }
            ],
            Path("123.json"),
        )
        self.assertIn("Category: bugfix", rendered)
        self.assertIn("Mode: code", rendered)
        self.assertIn("Recommended profile: fast", rendered)

    def test_template_payload_preserves_task_metadata(self) -> None:
        payload = template_payload(
            {
                "id": "fix-broken-pytest",
                "category": "bugfix",
                "mode": "code",
                "recommended_profile": "fast",
            }
        )
        self.assertEqual(payload["task_id"], "fix-broken-pytest")
        self.assertEqual(payload["category"], "bugfix")
        self.assertEqual(payload["mode"], "code")
        self.assertEqual(payload["recommended_profile"], "fast")
        self.assertEqual(payload["changed_files"], [])

    def test_evaluate_task_pending_submission_carries_metadata(self) -> None:
        with tempfile.TemporaryDirectory() as td:
            original = bench_run.SUBMISSIONS_DIR
            bench_run.SUBMISSIONS_DIR = Path(td)
            try:
                result = bench_run.evaluate_task(
                    {
                        "id": "sample-task",
                        "title": "Sample",
                        "category": "tests",
                        "mode": "code",
                        "recommended_profile": "normal",
                    }
                )
            finally:
                bench_run.SUBMISSIONS_DIR = original
        self.assertEqual(result["status"], "pending_submission")
        self.assertEqual(result["category"], "tests")
        self.assertEqual(result["mode"], "code")
        self.assertEqual(result["recommended_profile"], "normal")


if __name__ == "__main__":
    unittest.main()
