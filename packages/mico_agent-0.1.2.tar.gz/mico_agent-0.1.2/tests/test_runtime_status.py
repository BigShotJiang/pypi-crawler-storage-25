from __future__ import annotations

from types import SimpleNamespace

from mico.spinner import _fmt_stage


def test_spinner_reports_missing_chat_request() -> None:
    state = SimpleNamespace(
        turn_started_at=100.0,
        request_sent_at=0.0,
        first_token_at=0.0,
        live_stage="server ready",
        live_detail="",
    )
    import mico.spinner as spinner
    original = spinner.time.monotonic
    spinner.time.monotonic = lambda: 109.0
    try:
        assert _fmt_stage(state) == "stuck: no chat request 9s"
    finally:
        spinner.time.monotonic = original


def test_spinner_reports_missing_first_token() -> None:
    state = SimpleNamespace(
        turn_started_at=100.0,
        request_sent_at=105.0,
        first_token_at=0.0,
        live_stage="request sent",
        live_detail="chat",
    )
    import mico.spinner as spinner
    original = spinner.time.monotonic
    spinner.time.monotonic = lambda: 114.0
    try:
        assert _fmt_stage(state) == "stuck: no first token 9s"
    finally:
        spinner.time.monotonic = original


def test_spinner_reports_live_stage_detail() -> None:
    state = SimpleNamespace(
        turn_started_at=100.0,
        request_sent_at=101.0,
        first_token_at=102.0,
        live_stage="tool running",
        live_detail="nmap",
    )
    assert _fmt_stage(state) == "tool running: nmap"
