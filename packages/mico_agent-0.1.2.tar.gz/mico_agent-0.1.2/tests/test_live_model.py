"""
Qwen3.5-9B ile gerçek model üzerinden uçtan uca integration testleri.

Her görev başarılı olana kadar tekrar dener (max_attempts). Tüm görev
kategorileri test edilir: bilgi sorgusu, dosya işlemi, kod yazma, git,
web, matematiksel hesap, hata düzeltme, çok adımlı görevler.

Çalıştırma:
    pytest tests/test_live_model.py -v -s --timeout=600

Uyarı: MLX server başlatılmalı (mico server-stop sonrası otomatik başlar).
"""
from __future__ import annotations

import asyncio
import json
import os
import re
import shutil
import tempfile
import time
from pathlib import Path
from typing import Any

import pytest

# ---------------------------------------------------------------------------
# Setup: model + context
# ---------------------------------------------------------------------------

@pytest.fixture(scope="session", autouse=True)
def ensure_model_loaded():
    """MLX sunucusunun çalıştığını doğrula, profili yükle, debug logları kapat."""
    import mico.cli as cli
    cli.apply_model_profile("fast")
    # Per-chunk "first token" log satırlarını kapat
    cli.UI_STATUS_LOGGING = False
    # render_log_line'ı da sessizleştir
    cli.render_log_line = lambda *a, **kw: None
    from mico.server import is_running
    if not is_running():
        pytest.skip("MLX server çalışmıyor — önce 'mico' ile başlat")
    yield


def _make_ctx(cwd: Path | None = None, network: bool = True):
    from mico.task_state import ToolContext
    return ToolContext(
        cwd=cwd or Path.cwd(),
        approval="never",
        force=False,
        mode="auto",
        narrate=False,
        dry_run=False,
        profile="fast",
        network_access=network,
        tool_install=False,
        unattended=True,
        permission_mode="balanced",
        allowed_external_paths=[Path(tempfile.gettempdir())],
        force_model_mismatch=False,
    )


async def _ask(task: str, cwd: Path | None = None, network: bool = True) -> str:
    """Modele tek görev gönder, final mesajını döndür."""
    import mico.cli as cli
    # Her çağrıda profili tekrar yükle — port senkronizasyonu için
    cli.apply_model_profile("fast")
    ctx = _make_ctx(cwd=cwd, network=network)
    session_id = f"live_test_{int(time.time()*1000)}"
    result, _ = await cli.tool_loop(task, ctx, session_id, history=None)
    return result or ""


def run(coro):
    loop = asyncio.new_event_loop()
    try:
        return loop.run_until_complete(coro)
    finally:
        loop.close()


# ---------------------------------------------------------------------------
# Retry helper
# ---------------------------------------------------------------------------

def retry_until_pass(coro_factory, validate_fn, *, max_attempts: int = 5, label: str = ""):
    """
    coro_factory() çağrısı bir coroutine döndürmeli.
    validate_fn(result) → True ise geçti, False ise tekrar dene.
    max_attempts başarısız olursa pytest.fail().
    """
    last_result = None
    for attempt in range(1, max_attempts + 1):
        try:
            result = run(coro_factory())
            last_result = result
            if validate_fn(result):
                print(f"\n  [PASS attempt={attempt}] {label}\n  → {result[:120]!r}")
                return result
            print(f"\n  [FAIL attempt={attempt}] {label}\n  → {result[:200]!r}")
        except Exception as exc:
            last_result = str(exc)
            print(f"\n  [ERROR attempt={attempt}] {label}: {exc}")
        time.sleep(2)  # kısa bekleme, model soğumasın
    pytest.fail(f"{label} — {max_attempts} denemede geçemedi. Son: {last_result!r}")


# ---------------------------------------------------------------------------
# Validation helpers
# ---------------------------------------------------------------------------

def contains_any(text: str, *words: str) -> bool:
    t = text.lower()
    return any(w.lower() in t for w in words)


def is_nonempty(text: str) -> bool:
    return bool(text and text.strip())


def has_number(text: str) -> bool:
    return bool(re.search(r"\d+", text))


def file_exists_and_nonempty(path: Path) -> bool:
    return path.exists() and path.stat().st_size > 0


# ===========================================================================
# KATEGORI 1: Yerel bilgi sorguları
# ===========================================================================

class TestLocalInfo:
    """Bash araçları ile yanıtlanabilen basit bilgi sorguları."""

    def test_current_time(self):
        label = "saat kaç"
        retry_until_pass(
            lambda: _ask("şu anki saat nedir?"),
            lambda r: has_number(r) and contains_any(r, ":", "saat", "zaman", "tarih", "time"),
            label=label,
        )

    def test_hostname(self):
        label = "hostname"
        retry_until_pass(
            lambda: _ask("bu bilgisayarın adı (hostname) nedir?"),
            lambda r: is_nonempty(r) and not contains_any(r, "hata", "error", "bilemiyorum"),
            label=label,
        )

    def test_local_ip(self):
        label = "yerel ip"
        retry_until_pass(
            lambda: _ask("yerel ip adresim nedir?"),
            lambda r: re.search(r"\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}", r) is not None,
            label=label,
        )

    def test_whoami(self):
        label = "whoami"
        retry_until_pass(
            lambda: _ask("hangi kullanıcı adıyla çalışıyorum?"),
            lambda r: is_nonempty(r) and not contains_any(r, "bilemiyorum", "error"),
            label=label,
        )

    def test_disk_usage(self):
        label = "disk kullanımı"
        retry_until_pass(
            lambda: _ask("mevcut disk kullanımını göster"),
            lambda r: contains_any(r, "GB", "MB", "TB", "disk", "%", "kullanım", "available"),
            label=label,
        )

    def test_memory_usage(self):
        label = "bellek"
        retry_until_pass(
            lambda: _ask("RAM kullanımı ne kadar?"),
            lambda r: contains_any(r, "GB", "MB", "bellek", "ram", "memory", "kullanım"),
            label=label,
        )

    def test_list_desktop(self):
        label = "masaüstü dosyaları"
        desktop = Path.home() / "Desktop"
        retry_until_pass(
            lambda: _ask("masaüstündeki dosyaları listele"),
            lambda r: is_nonempty(r) and not contains_any(r, "hata alıyorum", "yapamıyorum"),
            label=label,
        )

    def test_running_processes(self):
        label = "çalışan süreçler"
        retry_until_pass(
            lambda: _ask("en çok CPU kullanan 5 süreci listele"),
            lambda r: is_nonempty(r) and has_number(r),
            label=label,
        )


# ===========================================================================
# KATEGORI 2: Dosya okuma ve anlama
# ===========================================================================

class TestFileRead:
    """Var olan dosyaları okuyup anlama görevleri."""

    def test_read_pyproject(self):
        label = "pyproject.toml oku"
        retry_until_pass(
            lambda: _ask("pyproject.toml dosyasındaki projenin adını söyle"),
            lambda r: contains_any(r, "mico"),
            label=label,
        )

    def test_count_lines(self):
        label = "satır say"
        target = Path("/Users/micobot/mico/mico/triage.py")
        real_count = len(target.read_text().splitlines())
        retry_until_pass(
            lambda: _ask(f"mico/triage.py dosyasında kaç satır var?"),
            lambda r: has_number(r),
            label=label,
        )

    def test_find_function(self):
        label = "fonksiyon bul"
        # task_envelope.py sadece build_task_envelope içerir, doğrudan grep ile sor
        retry_until_pass(
            lambda: _ask("mico/task_envelope.py dosyasında 'def build_' ile başlayan satırları göster"),
            lambda r: contains_any(r, "build_task_envelope", "build_"),
            label=label,
        )

    def test_list_python_files(self):
        label = "python dosyaları listele"
        retry_until_pass(
            lambda: _ask("mico/ klasöründeki .py dosyalarını listele"),
            lambda r: contains_any(r, ".py", "cli", "triage", "task"),
            label=label,
        )

    def test_grep_pattern(self):
        label = "pattern ara"
        retry_until_pass(
            lambda: _ask("mico/ klasöründe 'def build_' ile başlayan fonksiyonları bul"),
            lambda r: contains_any(r, "build_", "def ", "fonksiyon"),
            label=label,
        )


# ===========================================================================
# KATEGORI 3: Dosya yazma ve düzenleme
# ===========================================================================

class TestFileWrite:
    """Geçici dizinde dosya oluşturma, düzenleme görevleri."""

    @pytest.fixture(autouse=True)
    def tmpdir(self, tmp_path):
        self._tmp = tmp_path
        yield tmp_path

    def test_create_hello_py(self):
        label = "hello.py yaz"
        out = self._tmp / "hello.py"

        def validate(r: str) -> bool:
            return out.exists() and "print" in out.read_text()

        retry_until_pass(
            lambda: _ask(
                f'"{out}" dosyasına "Merhaba Dünya!" yazdıran basit bir Python scripti yaz',
                cwd=self._tmp,
            ),
            validate,
            label=label,
        )

    def test_create_and_edit(self):
        label = "dosya yarat + düzenle"
        out = self._tmp / "config.json"
        out.write_text('{"version": 1}')

        def validate(r: str) -> bool:
            if not out.exists():
                return False
            try:
                data = json.loads(out.read_text())
                return data.get("version") == 2
            except Exception:
                return False

        retry_until_pass(
            lambda: _ask(
                f'"{out}" dosyasındaki version değerini 1\'den 2\'ye güncelle',
                cwd=self._tmp,
            ),
            validate,
            label=label,
        )

    def test_write_markdown(self):
        label = "markdown yaz"
        out = self._tmp / "README.md"

        def validate(r: str) -> bool:
            return out.exists() and "#" in out.read_text()

        retry_until_pass(
            lambda: _ask(
                f'"{out}" dosyasına "mico" projesi için kısa bir README.md yaz (başlık + 2 cümle)',
                cwd=self._tmp,
            ),
            validate,
            label=label,
        )

    def test_append_line(self):
        label = "dosyaya satır ekle"
        out = self._tmp / "log.txt"
        out_path = str(out)

        def make_task():
            Path(out_path).write_text("satir1\nsatir2\n")
            return _ask(
                f'Şu bash komutunu çalıştır: echo "satir3" >> "{out_path}"',
                cwd=self._tmp,
            )

        def validate(r: str) -> bool:
            p = Path(out_path)
            if not p.exists():
                return False
            content = p.read_text()
            return "satir1" in content and "satir3" in content

        retry_until_pass(make_task, validate, label=label)

    def test_create_multiple_files(self):
        label = "çok dosya yaz"
        f1 = self._tmp / "a.txt"
        f2 = self._tmp / "b.txt"

        def validate(r: str) -> bool:
            return f1.exists() and f2.exists()

        retry_until_pass(
            lambda: _ask(
                f'"{self._tmp}" klasörüne a.txt ("merhaba") ve b.txt ("dünya") dosyaları oluştur',
                cwd=self._tmp,
            ),
            validate,
            label=label,
        )


# ===========================================================================
# KATEGORI 4: Kod yazma ve çalıştırma
# ===========================================================================

class TestCodeWrite:
    """Python kodu yazıp çalıştırma görevleri."""

    @pytest.fixture(autouse=True)
    def tmpdir(self, tmp_path):
        self._tmp = tmp_path
        yield tmp_path

    def test_fibonacci(self):
        label = "fibonacci scripti"
        out = self._tmp / "fib.py"
        out_path = str(out)

        def make_task():
            # Her denemede eski dosyayı temizle
            p = Path(out_path)
            if p.exists():
                p.unlink()
            return _ask(
                f'"{out_path}" dosyasını yaz — içeriği tam olarak şu olsun:\n'
                f'def fib(n):\n'
                f'    a, b = 0, 1\n'
                f'    for _ in range(n): a, b = b, a+b\n'
                f'    return a\n'
                f'print(fib(10))\n'
                f'Dosyayı yaz ve python3 ile çalıştır.',
                cwd=self._tmp,
            )

        def validate(r: str) -> bool:
            import subprocess
            p = Path(out_path)
            if not p.exists():
                return False
            res = subprocess.run(["python3", out_path], capture_output=True, text=True, timeout=10)
            return res.returncode == 0 and ("55" in res.stdout or "89" in res.stdout)

        retry_until_pass(make_task, validate, label=label)

    def test_sort_list(self):
        label = "liste sıralama"
        retry_until_pass(
            lambda: _ask(
                "Python ile [5, 2, 8, 1, 9, 3] listesini küçükten büyüğe sırala ve sonucu göster"
            ),
            lambda r: contains_any(r, "1", "2", "3", "5", "8", "9") and "9" in r,
            label=label,
        )

    def test_word_count(self):
        label = "kelime sayacı"
        out = self._tmp / "wordcount.py"
        sample = self._tmp / "sample.txt"
        sample.write_text("bir iki üç dört beş\nalti yedi sekiz\n")

        def validate(r: str) -> bool:
            return out.exists() and "def " in out.read_text()

        retry_until_pass(
            lambda: _ask(
                f'"{out}" dosyasına bir metin dosyasının kelime sayısını bulan Python scripti yaz',
                cwd=self._tmp,
            ),
            validate,
            label=label,
        )

    def test_fix_syntax_error(self):
        label = "sözdizimi hatası düzelt"
        out = self._tmp / "broken.py"
        out.write_text("def toplam(a, b)\n    return a + b\n")

        def validate(r: str) -> bool:
            if not out.exists():
                return False
            import subprocess
            res = subprocess.run(
                ["python3", "-c", f"import ast; ast.parse(open('{out}').read())"],
                capture_output=True, text=True, timeout=10
            )
            return res.returncode == 0

        retry_until_pass(
            lambda: _ask(
                f'"{out}" dosyasındaki Python sözdizimi hatasını düzelt',
                cwd=self._tmp,
            ),
            validate,
            label=label,
        )

    def test_add_function_to_existing(self):
        label = "var olan dosyaya fonksiyon ekle"
        out = self._tmp / "utils.py"
        out_path = str(out)

        def make_task():
            Path(out_path).write_text("def kare(x):\n    return x * x\n")
            return _ask(
                f'"{out_path}" dosyasına bu satırları ekle (dosyanın sonuna append et):\n'
                f'def kup(x):\n    return x * x * x\n',
                cwd=self._tmp,
            )

        def validate(r: str) -> bool:
            p = Path(out_path)
            if not p.exists():
                return False
            content = p.read_text()
            return "kare" in content and "kup" in content and "x * x * x" in content

        retry_until_pass(make_task, validate, label=label)


# ===========================================================================
# KATEGORI 5: Git işlemleri
# ===========================================================================

class TestGitOps:
    """Git sorguları ve temel git işlemleri."""

    def test_git_status(self):
        label = "git status"
        retry_until_pass(
            lambda: _ask("git durumunu göster ve hangi branch'te olduğumuzu söyle"),
            lambda r: is_nonempty(r) and "exit_code" not in r.lower() and not r.startswith("exit_code"),
            label=label,
        )

    def test_git_branch(self):
        label = "aktif branch"
        retry_until_pass(
            lambda: _ask("şu anki git branch nedir?"),
            lambda r: is_nonempty(r) and not contains_any(r, "hata", "error"),
            label=label,
        )

    def test_git_log(self):
        label = "son commit"
        retry_until_pass(
            lambda: _ask("son 3 git commit'i göster"),
            lambda r: is_nonempty(r) and (has_number(r) or contains_any(r, "fix", "feat", "commit")),
            label=label,
        )

    def test_git_diff(self):
        label = "git diff"
        retry_until_pass(
            lambda: _ask("staged olmayan değişiklikler var mı? git diff ile göster"),
            lambda r: is_nonempty(r),
            label=label,
        )

    def test_git_init_and_commit(self, tmp_path):
        label = "git init + commit"
        repo = tmp_path / "testrepo"
        repo.mkdir()
        (repo / "README.md").write_text("# Test\n")

        def validate(r: str) -> bool:
            import subprocess
            res = subprocess.run(
                ["git", "log", "--oneline"],
                cwd=str(repo), capture_output=True, text=True, timeout=10
            )
            return res.returncode == 0 and len(res.stdout.strip()) > 0

        retry_until_pass(
            lambda: _ask(
                f'"{repo}" klasöründe git init yap, README.md\'yi stage et ve ilk commit oluştur',
                cwd=repo,
            ),
            validate,
            label=label,
        )


# ===========================================================================
# KATEGORI 6: Hesaplama ve matematik
# ===========================================================================

class TestMath:
    """Model ya da python_run ile hesaplama görevleri."""

    def test_simple_arithmetic(self):
        label = "basit aritmetik"
        retry_until_pass(
            lambda: _ask("Python ile 357 * 489 hesapla ve sadece sonucu yaz"),
            lambda r: "174573" in r.replace(",", "").replace(".", "").replace(" ", ""),
            label=label,
        )

    def test_prime_check(self):
        label = "asal sayı kontrolü"
        retry_until_pass(
            lambda: _ask("97 asal sayı mı?"),
            lambda r: contains_any(r, "evet", "asal", "yes", "prime", "doğru", "true"),
            label=label,
        )

    def test_factorial(self):
        label = "faktöriyel"
        retry_until_pass(
            lambda: _ask("10! (10 faktöriyel) hesapla"),
            lambda r: "3628800" in r.replace(",", "").replace(".", "").replace(" ", ""),
            label=label,
        )

    def test_list_statistics(self):
        label = "liste istatistikleri"
        retry_until_pass(
            lambda: _ask("Python ile [4, 8, 15, 16, 23, 42] listesinin ortalamasını hesapla ve sadece sayıyı söyle"),
            # ortalama = 108/6 = 18.0
            lambda r: contains_any(r, "18", "18.0", "18,0"),
            label=label,
        )


# ===========================================================================
# KATEGORI 7: Sistem ve environment bilgisi
# ===========================================================================

class TestSystemInfo:
    """OS, Python ve environment sorguları."""

    def test_python_version(self):
        label = "python versiyonu"
        retry_until_pass(
            lambda: _ask("python3 versiyonu nedir?"),
            lambda r: re.search(r"3\.\d+", r) is not None,
            label=label,
        )

    def test_env_variables(self):
        label = "env değişkenleri"
        retry_until_pass(
            lambda: _ask("HOME ve PATH environment değişkenlerini göster"),
            lambda r: contains_any(r, "home", "HOME", "/Users", "PATH", "path"),
            label=label,
        )

    def test_macos_version(self):
        label = "macOS versiyonu"
        retry_until_pass(
            lambda: _ask("macOS versiyonu nedir?"),
            lambda r: re.search(r"\d+\.\d+", r) is not None,
            label=label,
        )

    def test_installed_packages(self):
        label = "pip paketleri"
        retry_until_pass(
            lambda: _ask("yüklü python paketlerini listele (pip list)"),
            lambda r: contains_any(r, "pip", "package", "paket", "requests", "httpx"),
            label=label,
        )


# ===========================================================================
# KATEGORI 8: Çok adımlı görevler
# ===========================================================================

class TestMultiStep:
    """Birden fazla araç gerektiren, sıralı adımlı görevler."""

    @pytest.fixture(autouse=True)
    def tmpdir(self, tmp_path):
        self._tmp = tmp_path
        yield tmp_path

    def test_create_run_verify(self):
        """Yaz → çalıştır → sonucu doğrula zinciri."""
        label = "yaz + çalıştır + doğrula"
        out = self._tmp / "sum.py"

        def validate(r: str) -> bool:
            if not out.exists():
                return False
            import subprocess
            res = subprocess.run(["python3", str(out)], capture_output=True, text=True, timeout=10)
            return res.returncode == 0 and "15" in res.stdout  # 1+2+3+4+5=15

        retry_until_pass(
            lambda: _ask(
                f'"{out}" dosyasına 1\'den 5\'e kadar sayıların toplamını hesaplayan Python scripti yaz, '
                f'çalıştır ve sonucun 15 olduğunu doğrula',
                cwd=self._tmp,
            ),
            validate,
            label=label,
        )

    def test_read_modify_verify(self):
        """Oku → değiştir → doğrula."""
        label = "oku + değiştir + doğrula"
        cfg = self._tmp / "config.py"
        cfg.write_text("DEBUG = False\nVERSION = '1.0.0'\nTIMEOUT = 30\n")

        def validate(r: str) -> bool:
            if not cfg.exists():
                return False
            content = cfg.read_text()
            return "True" in content and "DEBUG" in content

        retry_until_pass(
            lambda: _ask(
                f'"{cfg}" dosyasında DEBUG = False satırını DEBUG = True yap',
                cwd=self._tmp,
            ),
            validate,
            label=label,
        )

    def test_analyze_and_report(self):
        """Dosyaları analiz edip rapor yaz."""
        label = "analiz + rapor"
        src = self._tmp / "src"
        src.mkdir()
        (src / "main.py").write_text("def main():\n    pass\n\ndef helper():\n    pass\n")
        (src / "utils.py").write_text("def add(a, b):\n    return a + b\n")
        report = self._tmp / "report.txt"

        def validate(r: str) -> bool:
            return report.exists() or contains_any(r, "fonksiyon", "function", "def", "main", "helper")

        retry_until_pass(
            lambda: _ask(
                f'"{src}" klasöründeki Python dosyalarını analiz et: '
                f'kaç fonksiyon var? Sonuçları "{report}" dosyasına yaz',
                cwd=self._tmp,
            ),
            validate,
            label=label,
        )

    def test_refactor_function(self):
        """Var olan kodu refactor et."""
        label = "refactor"
        code = self._tmp / "calc.py"
        code.write_text(
            "def hesapla(a, b, op):\n"
            "    if op == 'topla': return a + b\n"
            "    if op == 'cikar': return a - b\n"
            "    if op == 'carp': return a * b\n"
            "    if op == 'bol': return a / b\n"
        )

        def validate(r: str) -> bool:
            if not code.exists():
                return False
            content = code.read_text()
            # En az orijinal fonksiyonun adı korunmuş olmalı
            return "hesapla" in content or "def " in content

        retry_until_pass(
            lambda: _ask(
                f'"{code}" dosyasındaki hesapla() fonksiyonunu if-elif zinciri yerine '
                f'sözlük (dict) tabanlı yaklaşımla yeniden yaz',
                cwd=self._tmp,
            ),
            validate,
            label=label,
        )


# ===========================================================================
# KATEGORI 9: Hata kurtarma ve edge case
# ===========================================================================

class TestErrorHandling:
    """Model hatalı durumlardan kurtulabilmeli."""

    def test_nonexistent_file_graceful(self):
        label = "olmayan dosya"
        retry_until_pass(
            lambda: _ask("olmayan_dosya_xyz_12345.py dosyasını oku"),
            lambda r: contains_any(r, "bulunamadı", "yok", "mevcut değil", "not found", "does not exist", "hata"),
            label=label,
        )

    def test_ambiguous_task(self):
        label = "belirsiz görev"
        retry_until_pass(
            lambda: _ask("bir şeyler yap"),
            lambda r: is_nonempty(r),
            label=label,
        )

    def test_large_output_summary(self):
        label = "büyük çıktı özeti"
        retry_until_pass(
            lambda: _ask("find /usr/lib -name '*.dylib' 2>/dev/null ile kaç dylib dosyası var?"),
            lambda r: has_number(r),
            label=label,
        )


# ===========================================================================
# KATEGORI 10: final.message kalitesi
# ===========================================================================

class TestFinalMessageQuality:
    """Model ham tool çıktısını final.message'a kopyalamamalı."""

    def test_no_raw_exitcode_in_final(self):
        label = "exit_code final'de olmamalı"
        retry_until_pass(
            lambda: _ask("ls /tmp komutunu çalıştır"),
            lambda r: "exit_code=0" not in r and "exit_code" not in r.lower(),
            label=label,
        )

    def test_ip_not_raw_output(self):
        label = "IP cevabı düzgün formatlanmış"
        retry_until_pass(
            lambda: _ask("yerel ip adresim nedir? söyle"),
            lambda r: "exit_code" not in r.lower()
                and re.search(r"\d{1,3}\.\d{1,3}", r) is not None,
            label=label,
        )

    def test_final_in_turkish(self):
        label = "Türkçe final mesajı"
        retry_until_pass(
            lambda: _ask("mevcut dizindeki dosya sayısını göster"),
            # Türkçe karakterler veya yaygın Türkçe kelimeler olmalı
            lambda r: contains_any(r, "dosya", "klasör", "tane", "adet", "bulundu", "toplam", "file"),
            label=label,
        )

    def test_summary_not_verbatim_copy(self):
        label = "özet, komut çıktısının kopyası olmamalı"
        retry_until_pass(
            lambda: _ask("uptime komutunu çalıştır ve makine ne zamandan beri açık söyle"),
            lambda r: is_nonempty(r) and len(r) < 500,  # ham uptime çıktısı çok uzun olur
            label=label,
        )
