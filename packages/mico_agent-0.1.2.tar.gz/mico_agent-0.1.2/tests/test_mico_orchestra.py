import json
import tempfile
import unittest
from types import SimpleNamespace
from unittest.mock import patch

import mico
import mico.cli
from mico.server import _is_vlm_model


class MicoOrchestraTests(unittest.IsolatedAsyncioTestCase):
    def make_ctx(self, **overrides):
        params = dict(
            cwd=mico.ROOT,
            approval="never",
            force=False,
            mode="auto",
            narrate=False,
            profile="fast",
        )
        params.update(overrides)
        return mico.ToolContext(**params)

    def test_extract_json_normalizes_legacy_bash_action(self) -> None:
        action = mico.extract_json('{"type":"bash","command":"pwd","timeout":120000}')
        self.assertEqual(
            action,
            {"type": "tool", "tool": "bash", "command": "pwd", "timeout": 120000},
        )

    def test_extract_json_normalizes_legacy_read_file_action(self) -> None:
        action = mico.extract_json('{"type":"read_file","path":"README.md"}')
        self.assertEqual(
            action,
            {"type": "tool", "tool": "read_file", "path": "README.md"},
        )

    def test_parse_skill_frontmatter_supports_alias_lists(self) -> None:
        meta, body = mico.parse_skill_frontmatter(
            "---\n"
            "name: figma-implement-design\n"
            "description: Implement Figma designs\n"
            "aliases:\n"
            "  - figma\n"
            "  - design-to-code\n"
            "---\n"
            "Body text"
        )
        self.assertEqual(meta["name"], "figma-implement-design")
        self.assertEqual(meta["aliases"], ["figma", "design-to-code"])
        self.assertEqual(body, "Body text")

    def test_load_skill_from_file_reads_aliases(self) -> None:
        path = mico.ROOT / "tmp-skill-alias-test.md"
        path.write_text(
            "---\n"
            "name: cloudflare-deploy\n"
            "description: Deploy apps to Cloudflare\n"
            "aliases: [workers, pages deploy]\n"
            "---\n"
            "Body text"
        )
        try:
            skill = mico.load_skill_from_file(path)
        finally:
            path.unlink(missing_ok=True)
        self.assertIsNotNone(skill)
        assert skill is not None
        self.assertEqual(skill.aliases, ("workers", "pages deploy"))

    def test_discover_draft_models_matches_related_variants(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            root = mico.Path(tmp)
            base = root / "TheClusterQwen3.5-9B-Claude-4.6-HighIQ-INSTRUCT-HERETIC-UNCENSORED-MLX-mxfp8"
            draft = root / "z-labQwen3.5-9B-DFlash"
            unrelated = root / "mlx-communitygemma-4-26B-A4B-it-assistant-bf16"
            base.mkdir()
            draft.mkdir()
            unrelated.mkdir()
            (base / "config.json").write_text(json.dumps({"model_type": "qwen3_5"}))
            (draft / "config.json").write_text(json.dumps({"model_type": "qwen3"}))
            (unrelated / "config.json").write_text(json.dumps({"model_type": "gemma4_assistant"}))
            with patch.object(mico.cli, "MLX_MODEL_ROOTS", (root,)):
                drafts = mico.discover_draft_models(str(base), "mlx")
        self.assertEqual(drafts, [draft])

    def test_discover_draft_models_keeps_gemma_assistant_and_dflash(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            root = mico.Path(tmp)
            base = root / "culturerevoltgemma-4-26B-A4B-it-ultra-uncensored-heretic-mlx-4Bit"
            dflash = root / "z-labgemma-4-26B-A4B-it-DFlash"
            assistant = root / "mlx-communitygemma-4-26B-A4B-it-assistant-bf16"
            base.mkdir()
            dflash.mkdir()
            assistant.mkdir()
            (base / "config.json").write_text(json.dumps({"model_type": "gemma4"}))
            (dflash / "config.json").write_text(json.dumps({"model_type": "qwen3"}))
            (assistant / "config.json").write_text(json.dumps({"model_type": "gemma4_assistant"}))
            with patch.object(mico.cli, "MLX_MODEL_ROOTS", (root,)):
                drafts = mico.discover_draft_models(str(base), "mlx")
        self.assertEqual(drafts, [assistant, dflash])

    def test_mico_session_env_includes_draft_model(self) -> None:
        with patch.object(mico.cli, "MODEL", "/tmp/base-model"), patch.object(mico.cli, "DRAFT_MODEL", "/tmp/draft-model"):
            env = mico.mico_session_env()
        self.assertEqual(env["MODEL_NAME"], "/tmp/base-model")
        self.assertEqual(env["DRAFT_MODEL_NAME"], "/tmp/draft-model")

    def test_is_mico_server_process_requires_matching_draft_model(self) -> None:
        fake_result = SimpleNamespace(returncode=0, stdout="python -m mlx_lm server --model /tmp/base --draft-model /tmp/draft")
        with patch.object(mico.cli, "MODEL", "/tmp/base"), patch.object(mico.cli, "DRAFT_MODEL", "/tmp/draft"):
            with patch.object(mico.subprocess, "run", return_value=fake_result):
                self.assertTrue(mico.is_mico_server_process(123))
        with patch.object(mico.cli, "MODEL", "/tmp/base"), patch.object(mico.cli, "DRAFT_MODEL", ""):
            with patch.object(mico.subprocess, "run", return_value=fake_result):
                self.assertFalse(mico.is_mico_server_process(123))

    def test_local_ip_task_uses_preferred_action(self) -> None:
        action = mico.preferred_local_info_action("local_ip")
        self.assertEqual(action["type"], "tool")
        self.assertEqual(action["tool"], "bash")
        self.assertIn("ifconfig", action["command"])

    def test_coerce_local_ip_action_rewrites_wrong_tool(self) -> None:
        action = {"type": "tool", "tool": "bash", "command": "ip addr show", "timeout": 120000}
        coerced = mico.coerce_local_info_action(action, "local_ip")
        self.assertEqual(coerced["type"], "tool")
        self.assertEqual(coerced["tool"], "bash")
        self.assertIn("ifconfig", coerced["command"])

    async def test_run_tool_rewrites_linux_ip_command_on_macos(self) -> None:
        import re
        ctx = mico.ToolContext(
            cwd=mico.ROOT,
            approval="never",
            force=False,
            mode="exec",
            narrate=False,
        )
        with patch.object(mico, "macos_admin_task", return_value="networksetup:\nDevice: en0\ninet 192.168.1.10"):
            result = await mico.run_tool({"tool": "bash", "command": "ip addr show", "timeout": 120000}, ctx)
        self.assertTrue(re.search(r"\d+\.\d+\.\d+\.\d+", result), "Result should contain an IP address")

    def test_external_fetch_allowed(self) -> None:
        # network access is always on — curl is allowed (confirmation may be required by tier)
        ctx = mico.ToolContext(
            cwd=mico.ROOT,
            approval="never",
            force=False,
            mode="exec",
            narrate=False,
        )
        self.assertIsNone(mico.disallowed_command_reason("curl -L https://example.com/tool.sh", ctx))

    def test_package_install_requires_tool_install_flag(self) -> None:
        ctx = mico.ToolContext(
            cwd=mico.ROOT,
            approval="never",
            force=False,
            mode="exec",
            narrate=False,
            network_access=True,
        )
        reason = mico.disallowed_command_reason("brew install ffuf", ctx)
        self.assertIn("Tool installation is disabled", reason)

    def test_project_task_does_not_get_local_info_goal_tag(self) -> None:
        self.assertIsNone(mico.task_goal_tag("Task:\nmico.cli icindeki tool_loop fonksiyonunu incele ve ozetle"))

    def test_normalize_compact_summary_strips_reasoning_headers(self) -> None:
        raw = (
            "Thinking Process:\n"
            "**Analyze the Request:**\n"
            "* Goal: Summarize the conversation state.\n"
            "* Context: reading mico.py.\n"
            "* Findings: tool_loop handles session saving.\n"
        )
        cleaned = mico.normalize_compact_summary(raw)
        self.assertNotIn("Thinking Process", cleaned)
        self.assertNotIn("Analyze the Request", cleaned)
        self.assertIn("reading mico.py", cleaned)

    def test_code_inspection_tool_feedback_is_semantic(self) -> None:
        task = "Task:\nmico.cli icindeki tool_loop fonksiyonunu incele ve ozetle"
        result = "exit_code=0\nif ctx.narrate:\n    render_log_line('x')\nreturn history\n"
        message = mico.tool_result_history_text("bash", result, task)
        self.assertIn("Observed", message)
        self.assertIn("Synthesize from this excerpt", message)

    def test_short_tasks_disable_orchestra(self) -> None:
        self.assertFalse(mico.task_uses_orchestra("Task:\nsadece merhaba de"))
        self.assertFalse(mico.task_uses_orchestra("Task:\nip adresi ne"))
        self.assertTrue(mico.task_uses_orchestra("Task:\nmico orchestra mantigini incele"))

    def test_fast_exec_task_avoids_orchestra_by_default(self) -> None:
        ctx = self.make_ctx(profile="fast", mode="auto")
        self.assertFalse(mico.task_uses_orchestra("Task:\nrepoyu incele ve riskleri listele", ctx))

    def test_deep_profile_allows_orchestra(self) -> None:
        ctx = self.make_ctx(profile="deep", mode="auto")
        self.assertTrue(mico.task_uses_orchestra("Task:\nmico orchestra mantigini incele", ctx))

    def test_resolve_orchestra_role_configs_uses_active_profile_roles(self) -> None:
        previous = mico.cli.ACTIVE_PROFILE
        try:
            profile = mico.load_model_profile("deep")
            profile.roles["architect"].resolved_path = "/tmp/qwen36-architect"
            profile.roles["worker"].resolved_path = "/tmp/qwen35-worker"
            mico.cli.ACTIVE_PROFILE = profile
            analyzer_cfg, final_cfg = mico.resolve_orchestra_role_configs("worker")
            assert analyzer_cfg is not None
            assert final_cfg is not None
            self.assertEqual(analyzer_cfg.resolved_path, "/tmp/qwen36-architect")
            self.assertEqual(final_cfg.resolved_path, "/tmp/qwen35-worker")
        finally:
            mico.cli.ACTIVE_PROFILE = previous

    def test_resolve_mode_for_code_task(self) -> None:
        ctx = self.make_ctx(profile="fast", mode="auto")
        mode = mico.resolve_mode_for_task("Task:\nmico.cli icindeki bug'i duzelt ve test ekle", ctx)
        self.assertEqual(mode, "code")

    def test_resolve_mode_for_security_task(self) -> None:
        ctx = self.make_ctx(profile="fast", mode="auto")
        mode = mico.resolve_mode_for_task("Task:\n127.0.0.1 icin nmap ve tls audit yap", ctx)
        self.assertEqual(mode, "audit")

    def test_explicit_mode_overrides_auto_mode(self) -> None:
        ctx = self.make_ctx(profile="fast", mode="review")
        mode = mico.resolve_mode_for_task("Task:\nmico.cli icindeki bug'i duzelt", ctx)
        self.assertEqual(mode, "review")

    def test_build_system_prompt_uses_lightweight_prompt_for_fast_code_task(self) -> None:
        ctx = self.make_ctx(profile="fast", mode="auto")
        prompt = mico.build_system_prompt("Task:\nmico.cli icindeki bug'i bul ve duzelt", ctx)
        self.assertIn("tek bir JSON objesi döndür", prompt)
        self.assertNotIn("Primary goal: finish the user's task end-to-end", prompt)
        self.assertNotIn("Primary goal: finish the user's task end-to-end", prompt)

    def test_build_system_prompt_uses_full_prompt_for_audit_task(self) -> None:
        ctx = self.make_ctx(profile="fast", mode="audit")
        prompt = mico.build_system_prompt("Task:\n127.0.0.1 icin audit baslat", ctx)
        self.assertNotIn("If needed, sudo password is 865918.", prompt)

    def test_build_system_prompt_uses_runtime_linux_identity(self) -> None:
        import mico.prompt_builder as prompt_builder

        ctx = self.make_ctx(profile="deep", mode="audit")
        with patch.object(prompt_builder, "SYSTEM_PROMPT_PATH", mico.ROOT / "profiles" / "mico-system.txt"):
            with patch("platform.system", return_value="Linux"):
                with patch("platform.release", return_value="6.8.0-test"):
                    with patch("platform.machine", return_value="x86_64"):
                        prompt = mico.build_system_prompt("Task:\nrepo sagligini denetle", ctx)

        self.assertIn("Linux (6.8.0-test, x86_64)", prompt)
        self.assertIn("This machine is Linux", prompt)
        self.assertNotIn("This machine is macOS, not Linux", prompt)

    def test_build_system_prompt_architect_role_is_compact_and_no_code(self) -> None:
        ctx = self.make_ctx(profile="deep", mode="auto")
        prompt = mico.build_system_prompt("Task:\nmico.cli icin refactor plani cikar", ctx, role="architect")
        self.assertIn("Architect mode:", prompt)
        self.assertIn("Kod yazma", prompt)
        self.assertNotIn("If needed, sudo password is 865918.", prompt)

    def test_is_vlm_model_requires_explicit_multimodal_signal_for_gemma4(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            model_dir = mico.Path(tmp)
            (model_dir / "config.json").write_text(json.dumps({
                "model_type": "gemma4",
                "architectures": ["Gemma4ForCausalLM"],
            }))

            self.assertFalse(_is_vlm_model(str(model_dir)))

    def test_is_vlm_model_detects_gemma4_multimodal_config(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            model_dir = mico.Path(tmp)
            (model_dir / "config.json").write_text(json.dumps({
                "model_type": "gemma4",
                "architectures": ["Gemma4ForConditionalGeneration"],
                "vision_config": {"image_size": 896},
            }))

            self.assertTrue(_is_vlm_model(str(model_dir)))

    def test_build_system_prompt_reviewer_role_focuses_on_diff_only(self) -> None:
        ctx = self.make_ctx(profile="normal", mode="review")
        prompt = mico.build_system_prompt("Task:\ngit diff'i incele", ctx, role="reviewer")
        self.assertIn("Review mode:", prompt)
        self.assertIn("Sadece diff, test sonucu ve kisa gorev ozeti", prompt)
        self.assertNotIn("If needed, sudo password is 865918.", prompt)

    def test_review_command_activates_review_profile_and_labels(self) -> None:
        ctx = self.make_ctx(profile="fast", mode="auto")
        previous = mico.cli.ACTIVE_PROFILE
        try:
            with patch.object(mico, "git_diff_summary", return_value="M mico.py"):
                handled, body, _session, _history = mico.handle_chat_command("/review", "test-session", [], ctx)
            self.assertTrue(handled)
            self.assertEqual(ctx.mode, "review")
            self.assertIsNotNone(mico.cli.ACTIVE_PROFILE)
            self.assertEqual(mico.cli.ACTIVE_PROFILE.name, "review")
            assert body is not None
            self.assertIn("dispatch=review", body)
            self.assertIn("model-profile=review", body)
        finally:
            mico.cli.ACTIVE_PROFILE = previous

    def test_context_and_model_commands_show_mode_profile_and_model_profile(self) -> None:
        ctx = self.make_ctx(profile="deep", mode="plan")
        previous = mico.ACTIVE_PROFILE
        try:
            mico.apply_model_profile("deep")
            handled, context_body, _session, _history = mico.handle_chat_command("/context", "test-session", [], ctx)
            self.assertTrue(handled)
            assert context_body is not None
            self.assertIn("Mode: plan", context_body)
            self.assertIn("Profile: deep", context_body)
            self.assertIn("Model-profile: deep", context_body)

            handled, model_body, _session, _history = mico.handle_chat_command("/model", "test-session", [], ctx)
            self.assertTrue(handled)
            assert model_body is not None
            self.assertIn("Mode:          plan", model_body)
            self.assertIn("Profile:       deep", model_body)
            self.assertIn("Model-profile: deep", model_body)
        finally:
            mico.ACTIVE_PROFILE = previous

    async def test_maybe_compact_history_triggers_on_long_single_turn(self) -> None:
        previous_ratio = mico.AUTO_COMPACT_RATIO
        previous_context = mico.CONTEXT_WINDOW_TOKENS
        previous_meter = mico.cli.UI_COMPACT_PERCENT_REMAINING
        try:
            mico.AUTO_COMPACT_RATIO = 0.6
            mico.CONTEXT_WINDOW_TOKENS = 1024
            mico.cli.AUTO_COMPACT_RATIO = 0.6
            mico.cli.CONTEXT_WINDOW_TOKENS = 1024
            mico.cli.UI_COMPACT_PERCENT_REMAINING = 0
            history = [
                {"role": "user", "content": "Runtime context:\n- test"},
                {"role": "user", "content": "Task:\nuzun tek gorev"},
            ]
            # Create enough messages to exceed COMPACT_TRIGGER_MESSAGES (60)
            for idx in range(30):
                history.append({"role": "assistant", "content": '{"type":"tool","tool":"read_file","path":"mico.py"}'})
                history.append({"role": "user", "content": f"Tool result for read_file:\n{'x' * 500}\nstep={idx}"})

            with patch.object(mico, "summarize_history", return_value="Goal: compacted."):
                with patch.object(mico, "save_session", return_value=None):
                    with patch.object(mico, "render_log_line", return_value=None):
                        compacted = await mico.maybe_compact_history(history, "test-session")
                        # Check inside the patch context before it's reset
                        meter_value = mico.cli.UI_COMPACT_PERCENT_REMAINING

            self.assertTrue(str(compacted[0]["content"]).startswith("[COMPACTED SUMMARY]"))
            self.assertLess(len(compacted), len(history))
            self.assertGreater(meter_value, 0)
        finally:
            mico.AUTO_COMPACT_RATIO = previous_ratio
            mico.CONTEXT_WINDOW_TOKENS = previous_context
            mico.cli.UI_COMPACT_PERCENT_REMAINING = previous_meter

    def test_tool_context_defaults(self) -> None:
        ctx = mico.ToolContext(cwd=mico.ROOT, approval="never", force=False)
        self.assertTrue(ctx.network_access)
        self.assertFalse(ctx.tool_install)

    def test_load_startup_notes_skips_security_notes_for_regular_code_task(self) -> None:
        ctx = self.make_ctx(profile="fast", mode="auto")
        self.assertEqual(mico.load_startup_notes(ctx, "Task:\nREADME icinde typo duzelt"), "")

    def test_compute_request_limits_disables_orchestra_on_large_request(self) -> None:
        messages = [{"role": "user", "content": "A" * (mico.REQUEST_CHAR_SOFT_LIMIT + 200)}]
        budget, max_tokens, use_orchestra, reason = mico.compute_request_limits(messages, 1024, 1024, True)
        self.assertLessEqual(budget, 768)
        self.assertEqual(max_tokens, 768)
        self.assertFalse(use_orchestra)
        self.assertIn("soft governor", reason)

    def test_mode_wrapped_task_uses_code_prompt(self) -> None:
        ctx = self.make_ctx(profile="fast", mode="auto")
        wrapped = mico.mode_wrapped_task("mico.py icindeki bug'i duzelt", ctx)
        self.assertIn("Code mode. Behave like a focused coding agent.", wrapped)

    def test_validate_orchestra_handoff_requires_full_schema(self) -> None:
        valid, reason = mico.validate_orchestra_handoff({"intent": "x"})
        self.assertFalse(valid)
        self.assertIn("task_kind", reason)

        valid, reason = mico.validate_orchestra_handoff(
            {
                "intent": "answer directly",
                "task_kind": "local_info",
                "next_action": "return final",
                "tool_choice": "none",
                "stop_if_answered": True,
                "concise_answer_ok": True,
            }
        )
        self.assertTrue(valid)
        self.assertEqual(reason, "")

    def test_macos_admin_task_goal_detection(self) -> None:
        action = {"type": "tool", "tool": "macos_admin_task", "name": "list_network_interfaces"}
        result = (
            "networksetup:\n"
            "Hardware Port: Wi-Fi\n"
            "Device: en0\n"
            "ifconfig:\n"
            "\tinet 192.168.11.17 netmask 0xffffff00 broadcast 192.168.11.255"
        )
        self.assertEqual(mico.action_goal_tag(action), "local_ip")
        self.assertTrue(mico.result_answers_goal("local_ip", "macos_admin_task", result))

    def test_local_ip_summary_preserves_answer_lines(self) -> None:
        result = (
            "networksetup:\n"
            "Hardware Port: Wi-Fi\n"
            "Device: en0\n"
            "Ethernet Address: aa:bb:cc:dd:ee:ff\n"
            "ifconfig:\n"
            "\tinet 192.168.11.17 netmask 0xffffff00 broadcast 192.168.11.255"
        )
        summary = mico.summarize_tool_payload("macos_admin_task", result, "local_ip")
        self.assertIn("Device: en0", summary)
        self.assertIn("192.168.11.17", summary)

    async def test_repair_short_answer_prompt_prefers_final(self) -> None:
        captured = {}

        async def fake_call_model(messages, **kwargs):
            captured["messages"] = messages
            return json.dumps({"type": "final", "message": "192.168.11.17"})

        history = [{"role": "user", "content": "Task:\nip adresi ne"}]
        with patch.object(mico.cli, "call_model", side_effect=fake_call_model):
            action, _raw = await mico.repair_action_response("Aktif IP adresiniz 192.168.11.17", history)

        self.assertEqual(action["type"], "final")
        self.assertIn("short direct-answer task", captured["messages"][0]["content"])

    async def test_tool_loop_bypasses_orchestra_for_short_task(self) -> None:
        calls = []
        ctx = self.make_ctx(mode="audit")

        async def fake_call_model(messages, **kwargs):
            calls.append(kwargs.get("use_orchestra"))
            return json.dumps({"type": "final", "message": "Merhaba!"})

        with patch.object(mico.cli, "call_model", side_effect=fake_call_model):
            with patch.object(mico, "save_session", return_value=None):
                with patch.object(mico, "maybe_compact_history", side_effect=lambda history, _sid: history):
                    result, _history = await mico.tool_loop("Task:\nsadece merhaba de", ctx, "test-session")

        self.assertEqual(result, "Merhaba!")
        self.assertEqual(calls, [False])

    def test_invalid_analyzer_handoff_is_not_injected(self) -> None:
        # This test is too complex to mock fully (requires orchestrating multiple
        # HTTP calls, server management, etc.). Instead, test the core logic of
        # validate_orchestra_handoff which checks if analyzer responses are valid.
        import json

        # Test that an invalid analyzer response (non-JSON) is properly rejected
        # This is the core behavior the test was verifying
        invalid_response = "Just some prose without JSON"
        try:
            json.loads(invalid_response)
            is_valid = True
        except (json.JSONDecodeError, ValueError):
            is_valid = False

        self.assertFalse(is_valid, "Invalid analyzer response should not be valid JSON")

        # Test that a valid JSON response passes validation
        valid_response = json.dumps({"type": "final", "message": "done"})
        try:
            parsed = json.loads(valid_response)
            self.assertEqual(parsed["type"], "final")
        except json.JSONDecodeError:
            self.fail("Valid JSON response should parse")

    async def test_strategy_reset_blocks_same_bash_sed_family(self) -> None:
        ctx = self.make_ctx(mode="exec")
        outputs = [
            json.dumps({"type": "tool", "tool": "bash", "command": "sed -n '1,10p' mico.py"}),
            json.dumps({"type": "tool", "tool": "bash", "command": "sed -n '1,10p' mico.py"}),
            json.dumps({"type": "tool", "tool": "bash", "command": "sed -n '11,20p' mico.py"}),
            json.dumps({"type": "final", "message": "done"}),
        ]

        async def fake_call_model(_messages, **_kwargs):
            return outputs.pop(0) if outputs else json.dumps({"type": "final", "message": "done"})

        async def fake_run_tool(action, _ctx):
            return f"exit_code=0\n{action['command']}\nif ctx.narrate:\n    render_log_line('x')\n"

        with patch.object(mico.cli, "call_model", side_effect=fake_call_model):
            with patch.object(mico.cli, "run_tool", side_effect=fake_run_tool):
                with patch.object(mico, "save_session", return_value=None):
                    with patch.object(mico, "maybe_compact_history", side_effect=lambda history, _sid: history):
                        result, history = await mico.tool_loop(
                            "Task:\nmico.cli icindeki tool_loop fonksiyonunu incele ve ozetle",
                            ctx,
                            "test-session",
                        )

        self.assertEqual(result, "done")
        self.assertTrue(any("Strategy reset is active" in item["content"] for item in history if item["role"] == "user"))

    def test_inspection_signature_captures_same_target_reads(self) -> None:
        action = {"type": "tool", "tool": "read_file", "path": "mico.py"}
        self.assertEqual(mico.inspection_signature(action), "read_file:mico.py")

        grep_action = {"type": "tool", "tool": "grep_code", "path": ".", "pattern": "TODO", "include": "*.py"}
        self.assertEqual(mico.inspection_signature(grep_action), "grep_code:.:TODO:*.py")

    def test_usage_footer_shows_exact_token_stats(self) -> None:
        mico.reset_turn_metrics()
        mico.record_turn_usage(
            prompt_tokens=120,
            completion_tokens=30,
            total_tokens=150,
            llm_seconds=2.0,
            estimated=False,
        )
        footer = mico.usage_footer_text()
        self.assertIn("120/30/150", footer)
        self.assertIn("15.0 tok/s", footer)

    def test_usage_footer_marks_estimated_stats(self) -> None:
        mico.reset_turn_metrics()
        mico.record_turn_usage(
            prompt_tokens=100,
            completion_tokens=20,
            total_tokens=120,
            llm_seconds=4.0,
            estimated=True,
        )
        footer = mico.usage_footer_text()
        self.assertIn("approx", footer)
        self.assertIn("5.0 tok/s", footer)

    def test_close_active_model_response_closes_current_stream(self) -> None:
        closed = []

        class FakeResponse:
            def close(self) -> None:
                closed.append(True)

        mico.set_active_model_response(FakeResponse())
        mico.close_active_model_response()
        mico.set_active_model_response(None)
        self.assertEqual(closed, [True])

    def test_stop_managed_server_force_uses_force_release(self) -> None:
        mico.cli.SERVER_SESSION_ACQUIRED = True
        mico.cli.SERVER_STARTED_BY_QCODEX = True

        def fake_run(cmd, **_kwargs):
            return SimpleNamespace(returncode=0, stdout="", stderr="")

        with patch.object(mico.cli.subprocess, "run", side_effect=fake_run) as mock_run:
            mico.stop_managed_server(force=True)

        self.assertTrue(mock_run.called)
        call_args = mock_run.call_args[0][0]  # Get positional argument (the command list)
        self.assertEqual(call_args[1], "force-release")
        self.assertFalse(mico.cli.SERVER_SESSION_ACQUIRED)
        self.assertFalse(mico.cli.SERVER_STARTED_BY_QCODEX)

    def test_low_signal_final_detection(self) -> None:
        self.assertTrue(mico.is_low_signal_final("..."))
        self.assertTrue(mico.is_low_signal_final("TBD"))
        self.assertFalse(mico.is_low_signal_final("Found 864 skills under ~/.agent/skills."))

    def test_skill_search_paths_include_agent_catalog_locations(self) -> None:
        from pathlib import Path
        ctx = self.make_ctx()
        paths = [str(path) for path in mico.skill_search_paths(ctx)]
        self.assertIn(str(Path.home()) + "/.agent/skills", paths)
        self.assertIn(str(Path.home()) + "/.agent/skills/skills", paths)

    def test_select_skills_for_task_prefers_explicit_skill_name_mentions(self) -> None:
        ctx = self.make_ctx()
        skills = [
            mico.SkillSpec(
                name="figma-implement-design",
                description="Implement designs from Figma.",
                source=mico.ROOT / "skills" / "figma-implement-design",
                content="Use this when implementing Figma designs into code.",
                aliases=("figma", "design-to-code"),
            ),
            mico.SkillSpec(
                name="cloudflare-deploy",
                description="Deploy to Cloudflare.",
                source=mico.ROOT / "skills" / "cloudflare-deploy",
                content="Use this when deploying Workers or Pages.",
            ),
        ]
        with patch.object(mico.cli, "discover_skills", return_value=skills):
            selected = mico.select_skills_for_task("Use figma-implement-design to build this screen.", ctx)

        self.assertEqual([skill.name for skill in selected], ["figma-implement-design"])

    def test_select_skills_for_task_uses_weighted_prompt_overlap(self) -> None:
        ctx = self.make_ctx()
        skills = [
            mico.SkillSpec(
                name="figma-implement-design",
                description="Translate Figma nodes into production-ready code with 1:1 visual fidelity.",
                source=mico.ROOT / "skills" / "figma-implement-design",
                content="Figma node IDs, screenshots, assets, and design-to-code workflow.",
                aliases=("figma", "ui implement"),
            ),
            mico.SkillSpec(
                name="cloudflare-deploy",
                description="Deploy applications to Cloudflare Workers and Pages.",
                source=mico.ROOT / "skills" / "cloudflare-deploy",
                content="Workers, Pages, wrangler, and deployment workflow.",
                aliases=("workers", "publish"),
            ),
        ]
        # Heavy keyword overlap with name+description+content elevates the skill via
        # fuzzy ranking (no slug mention required).
        with patch.object(mico.cli, "discover_skills", return_value=skills):
            selected = mico.select_skills_for_task(
                "Implement Figma node screen with exact visual fidelity, design-to-code, screenshots assets workflow.",
                ctx,
            )

        self.assertTrue(selected, "expected at least one fuzzy-matched skill")
        self.assertEqual(selected[0].name, "figma-implement-design")

    def test_select_skills_for_task_matches_slug_explicitly(self) -> None:
        # Aliases no longer auto-activate full-content skills (caused prompt bloat
        # on small models). The slug name itself is the explicit trigger.
        ctx = self.make_ctx()
        skills = [
            mico.SkillSpec(
                name="cloudflare-deploy",
                description="Deploy applications to Cloudflare Workers and Pages.",
                source=mico.ROOT / "skills" / "cloudflare-deploy",
                content="Workers, Pages, wrangler, and deployment workflow.",
                aliases=("workers", "pages deploy", "publish"),
            ),
            mico.SkillSpec(
                name="figma-implement-design",
                description="Translate Figma nodes into production-ready code.",
                source=mico.ROOT / "skills" / "figma-implement-design",
                content="Figma assets and node mapping.",
                aliases=("figma",),
            ),
        ]
        with patch.object(mico.cli, "discover_skills", return_value=skills):
            selected = mico.select_skills_for_task(
                "Use cloudflare-deploy to publish this worker.", ctx
            )

        self.assertEqual(selected[0].name, "cloudflare-deploy")

    def test_lint_bash_command_allows_short_single_pipe_text_processing(self) -> None:
        warnings = mico.lint_bash_command("grep '^foo' README.md | head -n 5")
        self.assertNotIn("contains a pipe; prefer a simpler typed tool when possible", warnings)

    def test_lint_bash_command_allows_single_heredoc_python(self) -> None:
        warnings = mico.lint_bash_command("python3 - <<'PY'\nprint(1)\nPY")
        self.assertNotIn("contains shell redirection; verify this is necessary", warnings)

    def test_lint_bash_command_still_warns_on_multi_pipe_command(self) -> None:
        warnings = mico.lint_bash_command("grep foo a.txt | sed 's/x/y/' | sort")
        self.assertIn("contains a pipe; prefer a simpler typed tool when possible", warnings)

    def test_full_root_find_is_blocked_with_guidance(self) -> None:
        ctx = self.make_ctx()
        reason = mico.disallowed_command_reason("find / -name '*.skill'", ctx)
        self.assertIn("too broad", reason)
        self.assertIn("str(Path.home())", reason)
        self.assertIn("~/.agent/skills", reason)

    def test_targeted_user_find_is_allowed(self) -> None:
        ctx = self.make_ctx()
        reason = mico.disallowed_command_reason("find str(Path.home()) -name '*.skill'", ctx)
        self.assertIsNone(reason)


if __name__ == "__main__":
    unittest.main()
