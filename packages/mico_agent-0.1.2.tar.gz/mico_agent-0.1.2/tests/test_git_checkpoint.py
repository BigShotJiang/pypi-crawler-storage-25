import os
import subprocess
import tempfile
import unittest
from pathlib import Path

import mico


def _run(args: list[str], cwd: Path) -> None:
    subprocess.run(args, cwd=str(cwd), capture_output=True, text=True, check=True)


class GitCheckpointTests(unittest.TestCase):
    def setUp(self) -> None:
        self._tmp = tempfile.TemporaryDirectory()
        self.repo = Path(self._tmp.name)
        env_overrides = {
            "GIT_AUTHOR_NAME": "mico-test",
            "GIT_AUTHOR_EMAIL": "mico@test.local",
            "GIT_COMMITTER_NAME": "mico-test",
            "GIT_COMMITTER_EMAIL": "mico@test.local",
        }
        self._prev_env: dict[str, str | None] = {}
        for key, value in env_overrides.items():
            self._prev_env[key] = os.environ.get(key)
            os.environ[key] = value
        _run(["git", "init", "-q", "-b", "main"], self.repo)
        (self.repo / "hello.txt").write_text("v1\n")
        _run(["git", "add", "hello.txt"], self.repo)
        _run(["git", "commit", "-q", "-m", "initial"], self.repo)

    def tearDown(self) -> None:
        for key, prev in self._prev_env.items():
            if prev is None:
                os.environ.pop(key, None)
            else:
                os.environ[key] = prev
        self._tmp.cleanup()

    def test_repo_root_detection(self) -> None:
        self.assertEqual(mico.git_repo_root(self.repo).resolve(), self.repo.resolve())
        with tempfile.TemporaryDirectory() as non_repo:
            self.assertIsNone(mico.git_repo_root(Path(non_repo)))

    def test_create_checkpoint_returns_ref(self) -> None:
        ref, sha = mico.create_git_checkpoint(self.repo, "first")
        self.assertIsNotNone(ref)
        self.assertTrue(ref.startswith("mico-checkpoints/"))
        self.assertEqual(len(sha), 40)

    def test_list_checkpoints_orders_two_entries(self) -> None:
        ref1, _ = mico.create_git_checkpoint(self.repo, "first")
        self.assertIsNotNone(ref1)
        # Modify a file then create a second checkpoint.
        (self.repo / "hello.txt").write_text("v2\n")
        # Force distinct timestamp slug.
        import time as _t
        _t.sleep(1.1)
        ref2, _ = mico.create_git_checkpoint(self.repo, "second")
        self.assertIsNotNone(ref2)
        items = mico.list_git_checkpoints(self.repo)
        self.assertGreaterEqual(len(items), 2)
        refs = [item["ref"] for item in items]
        self.assertIn(ref1, refs)
        self.assertIn(ref2, refs)

    def test_rollback_restores_file_contents(self) -> None:
        # Modify file then checkpoint with v2 content captured.
        (self.repo / "hello.txt").write_text("v2\n")
        ref_v2, _ = mico.create_git_checkpoint(self.repo, "v2-state")
        self.assertIsNotNone(ref_v2)
        # Further mutate the worktree.
        (self.repo / "hello.txt").write_text("v3-broken\n")
        msg = mico.rollback_to_checkpoint(self.repo, ref_v2, None)
        self.assertIn("restored", msg)
        self.assertEqual((self.repo / "hello.txt").read_text(), "v2\n")

    def test_rollback_path_subset(self) -> None:
        (self.repo / "a.txt").write_text("A1\n")
        (self.repo / "b.txt").write_text("B1\n")
        _run(["git", "add", "."], self.repo)
        _run(["git", "commit", "-q", "-m", "two files"], self.repo)
        (self.repo / "a.txt").write_text("A2\n")
        (self.repo / "b.txt").write_text("B2\n")
        ref, _ = mico.create_git_checkpoint(self.repo, "ab2")
        # Break both files.
        (self.repo / "a.txt").write_text("broken\n")
        (self.repo / "b.txt").write_text("broken\n")
        msg = mico.rollback_to_checkpoint(self.repo, ref, ["a.txt"])
        self.assertIn("restored", msg)
        self.assertEqual((self.repo / "a.txt").read_text(), "A2\n")
        # b.txt should NOT have been restored.
        self.assertEqual((self.repo / "b.txt").read_text(), "broken\n")


if __name__ == "__main__":
    unittest.main()
