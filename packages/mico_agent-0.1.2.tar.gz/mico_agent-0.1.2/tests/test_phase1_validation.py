import sys
from mico.action_parse import parse_action
from mico.capabilities import ModelCapabilities, ModelFormat

def strip_thinking(text):
    return text # dummy

def test_json_parsing():
    text = '```json\n{"type": "tool", "tool": "read_file", "path": "test.txt"}\n```'
    caps = ModelCapabilities(format=ModelFormat.MARKDOWN_JSON)
    action = parse_action(text, caps, strip_thinking=strip_thinking)
    assert action["tool"] == "read_file"
    assert action["path"] == "test.txt"
    print("JSON parsing test passed.")

def test_xml_parsing():
    text = '<tool>{"tool": "bash", "command": "ls"}</tool>'
    caps = ModelCapabilities(format=ModelFormat.XML)
    action = parse_action(text, caps, strip_thinking=strip_thinking)
    assert action["tool"] == "bash"
    assert action["command"] == "ls"
    print("XML parsing test passed.")

def test_validation_error():
    text = '```json\n{"type": "tool", "tool": "read_file"}\n```' # missing path
    caps = ModelCapabilities(format=ModelFormat.MARKDOWN_JSON)
    try:
        parse_action(text, caps, strip_thinking=strip_thinking)
        assert False, "Should have failed validation"
    except ValueError as e:
        print(f"Validation error test passed: {e}")

if __name__ == "__main__":
    try:
        test_json_parsing()
        test_xml_parsing()
        test_validation_error()
        print("All Phase 1 tests passed!")
    except Exception as e:
        print(f"Test failed: {e}")
        sys.exit(1)
