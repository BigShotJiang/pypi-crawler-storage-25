import pytest


def test_rag_flow(tmp_path):
    pytest.importorskip("chromadb")
    pytest.importorskip("sentence_transformers")

    from mico.rag import get_rag

    test_dir = tmp_path / "rag_src"
    test_dir.mkdir()
    (test_dir / "hello.py").write_text("def hello_world():\n    print('Hello from RAG test!')\n")

    rag = get_rag()
    rag.index_directory(test_dir)
    results = rag.query("hello world function")
    assert len(results) > 0
    assert "hello_world" in results[0]["content"]
