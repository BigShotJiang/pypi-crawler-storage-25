"""Tests for the mico.patch pipeline."""

from __future__ import annotations

import os
import subprocess
import sys
import tempfile
import textwrap
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

from mico.patch import (  # noqa: E402
    ContextMismatchError,
    FileNotFoundInPatchError,
    InvalidPatchError,
    PatchError,
    PatchPlan,
    RewriteTooLargeError,
    apply_patch,
    parse_unified_diff,
    recovery_prompt,
    validate_patch,
)


def _git(args: list[str], cwd: Path) -> subprocess.CompletedProcess:
    env = os.environ.copy()
    env.setdefault("GIT_AUTHOR_NAME", "t")
    env.setdefault("GIT_AUTHOR_EMAIL", "t@t")
    env.setdefault("GIT_COMMITTER_NAME", "t")
    env.setdefault("GIT_COMMITTER_EMAIL", "t@t")
    return subprocess.run(
        ["git", *args], cwd=str(cwd), capture_output=True, text=True, env=env, check=False
    )


class ParseUnifiedDiffTests(unittest.TestCase):
    def test_parses_simple_modify(self) -> None:
        diff = textwrap.dedent(
            """\
            --- a/hello.py
            +++ b/hello.py
            @@ -1,3 +1,3 @@
             a
            -b
            +B
             c
            """
        )
        plan = parse_unified_diff(diff)
        self.assertEqual(len(plan.files), 1)
        change = plan.files[0]
        self.assertEqual(change.path, "hello.py")
        self.assertEqual(change.kind, "modify")
        self.assertEqual(change.added_lines, 1)
        self.assertEqual(change.removed_lines, 1)

    def test_parses_create(self) -> None:
        diff = textwrap.dedent(
            """\
            --- /dev/null
            +++ b/new.txt
            @@ -0,0 +1,2 @@
            +line1
            +line2
            """
        )
        plan = parse_unified_diff(diff)
        self.assertEqual(plan.files[0].kind, "create")
        self.assertEqual(plan.files[0].added_lines, 2)

    def test_invalid_diff_raises(self) -> None:
        with self.assertRaises(InvalidPatchError):
            parse_unified_diff("not a diff")

    def test_empty_diff_raises(self) -> None:
        with self.assertRaises(InvalidPatchError):
            parse_unified_diff("")


class IsTooLargeTests(unittest.TestCase):
    def test_threshold_triggers(self) -> None:
        plan = PatchPlan()
        from mico.patch import PatchFileChange

        plan.files.append(
            PatchFileChange(
                path="x.py",
                kind="modify",
                added_lines=40,
                removed_lines=40,
                existing_lines=100,
            )
        )
        self.assertTrue(plan.is_too_large(threshold=0.6))

    def test_small_change_ok(self) -> None:
        plan = PatchPlan()
        from mico.patch import PatchFileChange

        plan.files.append(
            PatchFileChange(
                path="x.py",
                kind="modify",
                added_lines=2,
                removed_lines=1,
                existing_lines=200,
            )
        )
        self.assertFalse(plan.is_too_large())


class ValidatePatchTests(unittest.TestCase):
    def test_missing_file_raises(self) -> None:
        diff = textwrap.dedent(
            """\
            --- a/missing.py
            +++ b/missing.py
            @@ -1,1 +1,1 @@
            -old
            +new
            """
        )
        with tempfile.TemporaryDirectory() as tmp:
            with self.assertRaises(FileNotFoundInPatchError):
                validate_patch(diff, Path(tmp))


class ApplyPatchTests(unittest.TestCase):
    def setUp(self) -> None:
        self.tmpdir = tempfile.TemporaryDirectory()
        self.cwd = Path(self.tmpdir.name)
        _git(["init", "-q"], self.cwd)
        (self.cwd / "hello.py").write_text("a\nb\nc\n")
        _git(["add", "."], self.cwd)
        _git(["commit", "-q", "-m", "init"], self.cwd)

    def tearDown(self) -> None:
        self.tmpdir.cleanup()

    def test_apply_succeeds(self) -> None:
        diff = textwrap.dedent(
            """\
            --- a/hello.py
            +++ b/hello.py
            @@ -1,3 +1,3 @@
             a
            -b
            +B
             c
            """
        )
        plan = apply_patch(diff, self.cwd)
        self.assertEqual(plan.files[0].path, "hello.py")
        self.assertIn("B", (self.cwd / "hello.py").read_text())

    def test_apply_context_mismatch(self) -> None:
        # File has "a/b/c" but patch expects "x/y/z" context
        diff = textwrap.dedent(
            """\
            --- a/hello.py
            +++ b/hello.py
            @@ -1,3 +1,3 @@
             x
            -y
            +Y
             z
            """
        )
        with self.assertRaises((ContextMismatchError, PatchError)) as ctx:
            apply_patch(diff, self.cwd)
        self.assertIsInstance(ctx.exception, PatchError)

    def test_apply_too_large_blocked(self) -> None:
        # Create a file with 100 lines, then emit a patch that rewrites >60%
        big = self.cwd / "big.py"
        big.write_text("".join(f"line{i}\n" for i in range(100)))
        _git(["add", "big.py"], self.cwd)
        _git(["commit", "-q", "-m", "add big"], self.cwd)

        removed = "\n".join(f"-line{i}" for i in range(80))
        added = "\n".join(f"+NEW{i}" for i in range(80))
        diff = (
            "--- a/big.py\n"
            "+++ b/big.py\n"
            "@@ -1,80 +1,80 @@\n"
            + removed + "\n"
            + added + "\n"
        )
        with self.assertRaises(RewriteTooLargeError):
            apply_patch(diff, self.cwd)


class RecoveryPromptTests(unittest.TestCase):
    def test_each_error_type_renders(self) -> None:
        cases = [
            InvalidPatchError("x"),
            ContextMismatchError("x", path="hello.py"),
            FileNotFoundInPatchError("x", path="missing.py"),
            RewriteTooLargeError("x", path="big.py"),
        ]
        for err in cases:
            prompt = recovery_prompt(err)
            self.assertIsInstance(prompt, str)
            self.assertGreater(len(prompt), 20)

    def test_excerpts_included(self) -> None:
        err = ContextMismatchError("x", path="hello.py")
        prompt = recovery_prompt(err, file_excerpts={"hello.py": "current line\n"})
        self.assertIn("current line", prompt)


if __name__ == "__main__":
    unittest.main()
