import tempfile
import unittest
from pathlib import Path

import mico


class PathGuardTests(unittest.TestCase):
    def make_ctx(self, cwd: Path, **overrides) -> mico.ToolContext:
        params = dict(
            cwd=cwd,
            approval="never",
            force=False,
            mode="auto",
            narrate=False,
            profile="fast",
        )
        params.update(overrides)
        return mico.ToolContext(**params)

    def test_is_sensitive_ssh(self) -> None:
        self.assertTrue(mico.is_sensitive_path(Path("~/.ssh/id_rsa").expanduser()))

    def test_is_sensitive_etc_passwd(self) -> None:
        self.assertTrue(mico.is_sensitive_path(Path("/etc/passwd")))

    def test_is_sensitive_aws(self) -> None:
        self.assertTrue(mico.is_sensitive_path(Path("~/.aws/credentials").expanduser()))

    def test_is_sensitive_system(self) -> None:
        self.assertTrue(mico.is_sensitive_path(Path("/System/Library/Foo")))

    def test_not_sensitive_repo_readme(self) -> None:
        self.assertFalse(mico.is_sensitive_path(mico.ROOT / "README.md"))

    def test_not_sensitive_tmp(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            self.assertFalse(mico.is_sensitive_path(Path(tmp) / "foo.txt"))

    def test_enforce_blocks_sensitive_even_with_whitelist(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            ctx = self.make_ctx(Path(tmp))
            ctx.allowed_external_paths.append(Path("/etc"))
            with self.assertRaises(PermissionError):
                mico.enforce_path_policy(Path("/etc/passwd"), ctx, write=False)

    def test_enforce_blocks_outside_cwd(self) -> None:
        with tempfile.TemporaryDirectory() as tmp_a, tempfile.TemporaryDirectory() as tmp_b:
            ctx = self.make_ctx(Path(tmp_a))
            outside = Path(tmp_b) / "x.txt"
            with self.assertRaises(PermissionError):
                mico.enforce_path_policy(outside, ctx, write=True)

    def test_enforce_allows_inside_cwd(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            ctx = self.make_ctx(Path(tmp))
            inside = Path(tmp) / "sub" / "file.txt"
            mico.enforce_path_policy(inside, ctx, write=True)

    def test_enforce_allows_whitelisted_external(self) -> None:
        with tempfile.TemporaryDirectory() as tmp_a, tempfile.TemporaryDirectory() as tmp_b:
            ctx = self.make_ctx(Path(tmp_a))
            ctx.allowed_external_paths.append(Path(tmp_b))
            external_file = Path(tmp_b) / "ok.txt"
            mico.enforce_path_policy(external_file, ctx, write=False)

    def test_safe_path_for_tool_returns_resolved(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            ctx = self.make_ctx(Path(tmp))
            result = mico.safe_path_for_tool("inner.txt", ctx, write=True)
            self.assertEqual(result, (Path(tmp) / "inner.txt").resolve())


if __name__ == "__main__":
    unittest.main()
