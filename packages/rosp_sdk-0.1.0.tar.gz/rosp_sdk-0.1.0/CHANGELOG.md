# Changelog

All notable changes to the ROSP SDK and adapters will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.1.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [0.1.0] - 2026-04-01

### Added

- **ROSP v0.1 Specification** - Complete protocol spec for Description Mode (describe, stream, discover)
- **Core SDK** (`rosp-sdk`)
  - `ROSPAdapter` abstract base class with 6 lifecycle methods
  - `RobotCard` dataclass with 16 fields matching robot-card.schema.json
  - `StreamMessage`, `StreamQoS`, `CommandResult`, `HealthStatus` models
  - `ROSPEnvelope` transport-agnostic message format
  - `Validator` with JSON Schema validation
  - `CompletenessScorer` with 4 progressive enrichment levels
  - CLI: `rosp validate`, `rosp inspect`, `rosp export-card`, `rosp version`
- **Adapter: ROS2** (`rosp-adapter-ros2`)
  - URDF parsing from `/robot_description`
  - Topic/service/action introspection
  - QoS profile mapping (ROS2 QoS -> ROSP StreamQoS)
  - Presets for TurtleBot3, UR, ABB
- **Adapter: gRPC** (`rosp-adapter-grpc`)
  - ROSP-native and generic gRPC robot support
  - Server reflection auto-discovery
  - TLS/mTLS authentication
  - Presets for Boston Dynamics Spot, Viam
- **Adapter: VDA 5050** (`rosp-adapter-vda5050`)
  - Full MQTT state/order handling
  - Automatic Robot Card inference from AGV capabilities
  - Stream conversion (MQTT state -> StreamMessage)
  - Orchestrator pattern with state, order, and connection handlers
- **JSON Schemas** for Robot Card, Integration Manifest, Skill Description
- **Protobuf** definitions for gRPC transport binding
- **60 tests** for core SDK, additional tests per adapter

### Known Limitations

- Control Mode (`command`, `coordinate`) is **DRAFT** - interface defined but not production-ready
- Security enforcement (RBAC, audit logging) specified but not implemented
- Zenoh transport binding specified but SDK support not yet included
