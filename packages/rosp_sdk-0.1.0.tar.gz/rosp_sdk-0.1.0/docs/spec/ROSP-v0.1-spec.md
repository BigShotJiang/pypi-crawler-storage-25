# Robot Open Specification Protocol (ROSP) v0.1

**Version:** 0.1
**Status:** Draft
**Date:** 2026-03-25
**License:** Apache 2.0
**Authors:** RoboSwarm Project

---

## Table of Contents

1. [Introduction](#1-introduction)
2. [Terminology](#2-terminology)
3. [Architecture Overview](#3-architecture-overview)
4. [Message Envelope](#4-message-envelope)
5. [Operations](#5-operations)
   - 5.1 [describe](#51-describe)
   - 5.2 [stream](#52-stream)
   - 5.3 [discover](#53-discover)
   - 5.4 [command (DRAFT)](#54-command-draft--control-mode)
   - 5.5 [coordinate (DRAFT)](#55-coordinate-draft--control-mode)
6. [Capability Negotiation](#6-capability-negotiation)
7. [Transport Bindings](#7-transport-bindings)
8. [Security Model](#8-security-model)
9. [Error Handling](#9-error-handling)
10. [Versioning and Compatibility](#10-versioning-and-compatibility)
11. [Robot Card Schema](#appendix-a-robot-card-schema)
12. [Type Definitions](#appendix-b-type-definitions)

---

## 1. Introduction

The Robot Open Specification Protocol (ROSP) is a vendor-agnostic, transport-agnostic communication protocol that standardizes how software platforms describe, discover, monitor, and command robots. ROSP reduces the robot integration problem from M platforms x N robot types (M*N custom integrations) to M + N standardized adapters, analogous to how the Model Context Protocol (MCP) standardized LLM-to-tool connectivity and how the Language Server Protocol (LSP) standardized IDE-to-language connectivity.

### 1.1 Design Goals

1. **Vendor-agnostic.** ROSP does not assume any specific robot manufacturer, middleware, or operating system. A ROSP adapter can be written for any programmable machine.
2. **Transport-agnostic.** ROSP defines message semantics independently of the wire protocol. The same message can be carried over Zenoh, gRPC, WebSocket, MQTT, or any future transport.
3. **Security-first.** Every connection is authenticated. Every command is authorized. Every action is audited. ROSP is designed to meet EU Machinery Regulation 2023/1230 and the Cyber Resilience Act requirements from day one.
4. **Fleet-aware from day one.** The addressing scheme, discovery mechanism, and coordination operations are designed for multi-robot fleets, not retrofitted onto a single-robot protocol.

### 1.2 Design Principles

1. **Progressive enrichment.** A Robot Card can start with just an ID and type, and grow incrementally. No field should block onboarding.
2. **Extensible by default.** All content objects accept additional properties beyond the standard fields. Custom vendor-specific fields coexist with standard fields.
3. **Device-agnostic.** While "Robot Card" is the primary concept, the protocol supports any connected physical device — standalone sensors, infrastructure, charging stations, and custom hardware.

### 1.3 Scope of v0.1

ROSP v0.1 defines two operational modes:

- **Description Mode** (fully specified, implementable): `describe`, `stream`, and `discover` operations. A compliant v0.1 implementation MUST support Description Mode.
- **Control Mode** (interface-level definition, marked DRAFT): `command` and `coordinate` operations. These sections define message formats and lifecycle semantics but MAY change before v1.0. Implementers SHOULD NOT treat Control Mode as stable.

### 1.4 Relationship to Existing Standards

ROSP builds on and references existing standards rather than replacing them:

| Standard | Relationship to ROSP |
|----------|---------------------|
| **W3C WoT Thing Description 2.0** | The Robot Card schema borrows the Properties/Actions/Events model. ROSP extends it with robotics-specific fields (kinematics, safety zones, payload limits). |
| **SOSA/SSN (W3C/OGC)** | Sensor metadata in Robot Cards uses SOSA vocabulary for accuracy, precision, observation frequency, and measurement drift. |
| **IEEE CORA** | The Robot/RobotPart/RobotGroup taxonomy informs ROSP's type system for robots, components, and fleets. |
| **VDA 5050 v2.1** | ROSP's MQTT transport binding follows VDA 5050 topic naming conventions to enable bridging. The `command` operation's action lifecycle is compatible with VDA 5050 order states. |
| **MCP (Model Context Protocol)** | ROSP's capability negotiation handshake is modeled on MCP's `initialize`/`initialized` exchange. The JSON message envelope extends MCP's JSON-RPC pattern with robotics-specific fields. |

### 1.5 Relationship to Existing RCP (arXiv 2506.11650)

The Robot Context Protocol (RCP) paper by Lee and Lau (June 2025) defines a single-robot, HTTP/WebSocket protocol with read/write/execute/subscribe operations mapped to ROS2. ROSP extends this work in the following dimensions; it does not compete with it:

1. **Multi-robot addressing.** RCP uses flat namespace paths (`/sensor/pose`). ROSP adds hierarchical fleet addressing (`/fleet/{fleet_id}/robot/{robot_id}/sensor/pose`).
2. **Fleet coordination.** RCP has no multi-robot operations. ROSP defines `discover` for network-level robot finding and `coordinate` for multi-robot task assignment.
3. **Security model.** RCP mentions ACLs and client certificates but does not specify them. ROSP defines a 5-level RBAC model with mTLS, audit logging, and command expiration.
4. **Transport independence.** RCP specifies HTTP, WebSocket, and SSE. ROSP is transport-agnostic with defined bindings for Zenoh, gRPC, WebSocket, and MQTT.
5. **Capability description.** RCP's discovery returns paths and schemas. ROSP defines a full Robot Card with manufacturer data, kinematic limits, safety constraints, and sensor metadata.
6. **Safety.** RCP has no safety mechanisms. ROSP includes command expiration, watchdog heartbeats, kinematic validation, and a hardware-backed Safety role.

An existing RCP adapter (e.g., one based on ros-mcp-server or RynnRCP) can be wrapped in a ROSP adapter that adds addressing, security, and fleet context.

---

## 2. Terminology

The key words "MUST", "MUST NOT", "REQUIRED", "SHALL", "SHALL NOT", "SHOULD", "SHOULD NOT", "RECOMMENDED", "MAY", and "OPTIONAL" in this document are to be interpreted as described in RFC 2119.

### 2.1 Definitions

**Robot**
Any programmable physical machine equipped with sensors and/or actuators that can receive and act on electronic instructions. This includes mobile robots (AMRs, drones, quadrupeds), manipulators (robotic arms, grippers), humanoids, and fixed industrial robots. Simulated robots running in physics engines (Isaac Sim, MuJoCo, Gazebo) are also considered robots for the purposes of ROSP.

**Fleet**
A managed collection of one or more robots that share a common operational context. A fleet has an identifier, an owner, and a set of access policies. A robot MAY belong to multiple fleets simultaneously (e.g., a physical fleet and a simulation fleet).

**Device**
Any connected physical entity in the ROSP ecosystem — robots, sensors, actuators, infrastructure (doors, elevators), stations (charging docks), or controllers. The Robot Card can describe any device type.

**Robot Card**
The standardized description document for any ROSP device. Despite the name, it covers all device types — robots are the primary but not only use case. A Robot Card contains the device's identity, manufacturer information, physical specifications, sensor inventory, actuator inventory, capability declarations, communication endpoints, and safety constraints. Robot Cards are the primary payload of the `describe` operation. See [Appendix A](#appendix-a-robot-card-schema).

**Completeness Score**
A percentage (0-100%) indicating how much of a Robot Card's recommended fields are populated. Levels: minimal (id + type only), basic (+ manufacturer/model/hardware), standard (+ sensors/actuators/integration), complete (all recommended fields).

**Progressive Enrichment**
The design principle that a Robot Card starts with minimal required information and grows over time as more data becomes available. Users are never blocked by missing optional fields.

**Adapter**
A software component that bridges ROSP to a robot's native communication protocol. An adapter translates ROSP messages into the robot's native commands (e.g., ROS2 topics/services/actions, gRPC calls, VDA 5050 MQTT messages, OPC UA nodes) and translates native robot data back into ROSP messages. Each robot type requires one adapter; each platform requires one ROSP client. This is the M + N reduction.

**Platform**
Any software system that consumes ROSP data or sends ROSP commands. RoboSwarm is one such platform. Third-party fleet management systems, analytics dashboards, AI agents, simulation environments, and custom applications are all valid platforms.

**Description Mode**
The set of read-only ROSP operations: `describe`, `stream`, and `discover`. Description Mode enables platforms to find robots, read their capabilities, and subscribe to sensor data without issuing any commands that cause physical motion. Description Mode is fully specified in ROSP v0.1.

**Control Mode**
The set of read-write ROSP operations: `command` and `coordinate`. Control Mode enables platforms to send action commands to individual robots and coordinate tasks across multiple robots. Control Mode is defined at the interface level in ROSP v0.1 but marked DRAFT.

**Capability**
A machine-readable declaration of what a robot can do, expressed as a structured object within the Robot Card. Capabilities include sensor types, actuator types, navigation modes, manipulation skills, payload limits, and workspace constraints. Capabilities are used for discovery filtering, task assignment, and compatibility checking.

---

## 3. Architecture Overview

### 3.1 System Diagram

```
                          ROSP Messages
    +-----------+        (JSON / Protobuf)        +-------------+
    |           |  <---------------------------->  |             |
    | Platform  |         Transport Layer          |   Adapter   |
    | (Client)  |    (Zenoh / gRPC / WS / MQTT)   |  (Server)   |
    |           |  <---------------------------->  |             |
    +-----------+                                  +------+------+
                                                          |
                                                   Native Protocol
                                                  (ROS2 / gRPC /
                                                   VDA 5050 / OPC UA /
                                                   proprietary)
                                                          |
                                                   +------+------+
                                                   |             |
                                                   |    Robot    |
                                                   |             |
                                                   +-------------+
```

The Platform is the ROSP client. It initiates connections, sends requests, and subscribes to data. The Adapter is the ROSP server. It accepts connections, processes requests, translates them to the robot's native protocol, and returns responses. The robot itself is unaware of ROSP; it communicates only with the adapter via its native protocol.

For fleets, a single platform connects to multiple adapters:

```
                                +-- Adapter A ---> Robot A (ROS2)
                                |
    Platform ---[ROSP]---+-----+-- Adapter B ---> Robot B (gRPC)
                                |
                                +-- Adapter C ---> Robot C (VDA 5050)
```

### 3.2 Three-Tier Transport Model

Robot data and commands span six orders of magnitude in latency requirements (sub-millisecond servo control to seconds-scale fleet coordination). No single transport protocol can optimally serve all tiers. ROSP defines a three-tier model:

```
+---------------------------------------------------------------+
| TIER 3: FLEET-CLOUD  (100ms - 1s latency)                    |
| Fleet coordination, task assignment, analytics, dashboards    |
| Transport: gRPC over TLS, Zenoh over WAN, MQTT 5.0           |
| ROSP operates here: discover, coordinate                      |
+---------------------------------------------------------------+
| TIER 2: ROBOT-LEVEL  (1ms - 100ms latency)                   |
| Navigation, manipulation, sensor fusion, path planning        |
| Transport: Zenoh, DDS/ROS2, WebSocket                         |
| ROSP operates here: describe, stream, command                 |
+---------------------------------------------------------------+
| TIER 1: REAL-TIME BUS  (<1ms latency)                         |
| Servo control, safety systems, joint encoders, force feedback |
| Transport: EtherCAT, TSN, CAN, SPI                           |
| ROSP does NOT operate here. Tier 1 is bridged by adapters.   |
+---------------------------------------------------------------+
```

**ROSP operates at Tier 2 and Tier 3.** Tier 1 real-time bus protocols are bridged by adapters, not replaced. An adapter MAY expose Tier 1 data (e.g., joint encoder values) as ROSP `stream` topics, but the adapter is responsible for the real-time guarantees internally.

### 3.3 Client-Server Model

ROSP follows a client-server model:

- The **Platform** is always the client. It initiates connections, sends requests, and subscribes to streams.
- The **Robot** (via its adapter) is always the server. It accepts connections, responds to requests, and publishes stream data.

A single adapter MAY serve multiple platforms simultaneously. A single platform MAY connect to multiple adapters simultaneously. The `initialize` handshake (Section 6) establishes the session between a platform and an adapter.

---

## 4. Message Envelope

Every ROSP message -- requests, responses, stream data, errors -- uses the same envelope format. This uniformity simplifies parsing, logging, and routing.

### 4.1 Envelope Schema

```json
{
  "rosp": "0.1",
  "type": "describe",
  "path": "/fleet/warehouse-1/robot/amr-007/sensor/lidar",
  "id": "a3f1c9e2-7b4d-4e8a-9f12-3c5d6e7f8a9b",
  "timestamp": "2026-03-25T14:30:00.123456789Z",
  "body": {}
}
```

### 4.2 Field Definitions

#### `rosp` (string, REQUIRED)

The ROSP protocol version string. For this specification, the value MUST be `"0.1"`. Receivers MUST reject messages with an unrecognized version by returning error code `2001` (unsupported protocol version).

**Type:** string
**Format:** `MAJOR.MINOR` (both integers, dot-separated)
**Example:** `"0.1"`

#### `type` (string, REQUIRED)

The operation type. Determines how the `body` field is interpreted and what response is expected.

**Type:** string
**Allowed values:**

| Value | Mode | Direction | Description |
|-------|------|-----------|-------------|
| `"describe"` | Description | Request/Response | Request or return a Robot Card |
| `"stream"` | Description | Subscribe/Publish | Subscribe to or publish sensor/state data |
| `"discover"` | Description | Broadcast/Response | Find robots on the network |
| `"command"` | Control (DRAFT) | Request/Response/Feedback | Send an action command to a robot |
| `"coordinate"` | Control (DRAFT) | Request/Response | Multi-robot task assignment |
| `"initialize"` | Handshake | Request/Response | Capability negotiation (Section 6) |
| `"error"` | Any | Response | Error response (Section 9) |

#### `path` (string, REQUIRED)

Hierarchical resource address. Identifies the target robot, fleet, and resource within the robot.

**Type:** string
**Format:** URI-like path with segments separated by `/`.

**Path Grammar (ABNF):**

```abnf
rosp-path     = fleet-path / robot-path
fleet-path    = "/fleet/" fleet-id "/robot/" robot-selector [resource-path]
robot-path    = "/robot/" robot-id [resource-path]
fleet-id      = identifier
robot-id      = identifier
robot-selector= robot-id / "*"
resource-path = "/" resource-type "/" resource-id [sub-path]
resource-type = "sensor" / "actuator" / "capability" / "state" / "health"
resource-id   = identifier
sub-path      = "/" identifier *("/" identifier)
identifier    = 1*(ALPHA / DIGIT / "-" / "_" / ".")
```

**Path Examples:**

| Path | Meaning |
|------|---------|
| `/robot/amr-007` | Robot amr-007 (no fleet context) |
| `/fleet/warehouse-1/robot/amr-007` | Robot amr-007 in fleet warehouse-1 |
| `/fleet/warehouse-1/robot/*` | All robots in fleet warehouse-1 (wildcard) |
| `/robot/amr-007/sensor/lidar` | The lidar sensor on robot amr-007 |
| `/robot/amr-007/sensor/lidar/pointcloud` | The pointcloud topic of the lidar sensor |
| `/robot/amr-007/actuator/drive` | The drive actuator on robot amr-007 |
| `/robot/amr-007/capability/navigation` | Navigation capability of robot amr-007 |
| `/robot/amr-007/state` | Full state of robot amr-007 |
| `/robot/amr-007/health` | Health/diagnostics of robot amr-007 |
| `/fleet/warehouse-1/robot/*/health` | Health of all robots in fleet warehouse-1 |

**Wildcard semantics:** The `*` selector in `robot-selector` matches all robots in the specified fleet. It is valid only within a fleet context. Responses to wildcard paths MUST include the specific `robot-id` in each response message's path.

#### `id` (string, REQUIRED)

Client-assigned correlation identifier. Used to match responses and feedback messages to the originating request. The client MUST ensure `id` values are unique within a session.

**Type:** string
**Format:** UUID v4 (RECOMMENDED) or any non-empty string.
**Max length:** 128 characters.
**Example:** `"a3f1c9e2-7b4d-4e8a-9f12-3c5d6e7f8a9b"`

For stream data messages published by the server, the `id` field contains the subscription ID assigned during the subscribe handshake.

#### `timestamp` (string, REQUIRED)

The time the message was created.

**Type:** string
**Format:** ISO 8601 extended format with optional nanosecond precision. MUST be UTC (indicated by trailing `Z`).
**Examples:**
- `"2026-03-25T14:30:00Z"` (second precision)
- `"2026-03-25T14:30:00.123Z"` (millisecond precision)
- `"2026-03-25T14:30:00.123456789Z"` (nanosecond precision)

Implementations MUST accept any precision from seconds to nanoseconds. Implementations SHOULD generate timestamps with at least millisecond precision. For Tier 2 sensor data, microsecond or nanosecond precision is RECOMMENDED.

All timestamps MUST be UTC. Local time offsets MUST NOT be used. Clock synchronization between platform and robot is RECOMMENDED (via PTP IEEE 1588 or NTP) but not enforced by ROSP.

#### `body` (object, REQUIRED)

The operation-specific payload. The schema of `body` is determined by the `type` field. See Section 5 for each operation's body schema. For operations that carry no payload (e.g., a simple describe request), `body` MUST be an empty object `{}` or contain only optional fields.

---

## 5. Operations

### 5.1 describe

#### Purpose

Return the robot's Robot Card -- a complete, machine-readable description of the robot's identity, capabilities, sensors, actuators, and constraints.

#### Direction

- **Request:** Platform -> Robot (via adapter)
- **Response:** Robot -> Platform (via adapter)

#### Request Body Schema

```json
{
  "depth": "summary | full"
}
```

| Field | Type | Required | Default | Description |
|-------|------|----------|---------|-------------|
| `depth` | string | No | `"full"` | `"summary"` returns identity and capabilities list only. `"full"` returns the complete Robot Card including sensor schemas, actuator specifications, and safety constraints. |

#### Response Body Schema

The response body is a Robot Card object. See [Appendix A](#appendix-a-robot-card-schema) for the full schema. A summary response includes only the `identity`, `capabilities_summary`, and `endpoints` sections.

#### Example: Full Describe Request

```json
{
  "rosp": "0.1",
  "type": "describe",
  "path": "/fleet/warehouse-1/robot/amr-007",
  "id": "d1a2b3c4-5678-9abc-def0-123456789abc",
  "timestamp": "2026-03-25T14:30:00.000Z",
  "body": {
    "depth": "full"
  }
}
```

#### Example: Full Describe Response

```json
{
  "rosp": "0.1",
  "type": "describe",
  "path": "/fleet/warehouse-1/robot/amr-007",
  "id": "d1a2b3c4-5678-9abc-def0-123456789abc",
  "timestamp": "2026-03-25T14:30:00.052Z",
  "body": {
    "robot_card_version": "2026-03-25T10:00:00Z",
    "identity": {
      "robot_id": "amr-007",
      "manufacturer": "ExampleBot Inc.",
      "model": "WarehouseRunner 3000",
      "serial_number": "WR3K-2026-00842",
      "firmware_version": "2.4.1",
      "rosp_version": "0.1",
      "type": "mobile_robot",
      "description": "Autonomous mobile robot for warehouse logistics with integrated LIDAR and payload shelf."
    },
    "physical": {
      "dimensions_m": { "length": 0.8, "width": 0.6, "height": 0.35 },
      "weight_kg": 45.0,
      "payload_capacity_kg": 100.0,
      "max_velocity_ms": 2.0,
      "max_angular_velocity_rads": 1.5,
      "battery": {
        "type": "lithium_ion",
        "capacity_wh": 960,
        "nominal_voltage_v": 48
      }
    },
    "sensors": [
      {
        "sensor_id": "lidar",
        "type": "lidar_2d",
        "manufacturer": "SICK",
        "model": "TiM781",
        "mount_position": { "x": 0.35, "y": 0.0, "z": 0.15, "frame": "base_link" },
        "specifications": {
          "range_m": { "min": 0.05, "max": 25.0 },
          "angular_range_deg": 270,
          "angular_resolution_deg": 0.33,
          "scan_frequency_hz": 15,
          "accuracy_mm": 30
        },
        "topics": [
          {
            "topic_id": "scan",
            "data_type": "laser_scan",
            "frequency_hz": 15,
            "encoding": "json"
          },
          {
            "topic_id": "pointcloud",
            "data_type": "point_cloud_2d",
            "frequency_hz": 15,
            "encoding": "binary"
          }
        ]
      },
      {
        "sensor_id": "imu",
        "type": "imu_6dof",
        "manufacturer": "Bosch",
        "model": "BMI088",
        "mount_position": { "x": 0.0, "y": 0.0, "z": 0.10, "frame": "base_link" },
        "specifications": {
          "accelerometer_range_g": 24,
          "gyroscope_range_dps": 2000,
          "output_frequency_hz": 400,
          "noise_density_ug_sqrt_hz": 175
        },
        "topics": [
          {
            "topic_id": "orientation",
            "data_type": "orientation_quaternion",
            "frequency_hz": 100,
            "encoding": "json"
          },
          {
            "topic_id": "raw",
            "data_type": "imu_raw",
            "frequency_hz": 400,
            "encoding": "json"
          }
        ]
      },
      {
        "sensor_id": "battery_monitor",
        "type": "power_monitor",
        "topics": [
          {
            "topic_id": "status",
            "data_type": "battery_status",
            "frequency_hz": 1,
            "encoding": "json"
          }
        ]
      }
    ],
    "actuators": [
      {
        "actuator_id": "drive",
        "type": "differential_drive",
        "motors": 2,
        "max_torque_nm": 15.0,
        "commands": [
          {
            "command_id": "velocity",
            "data_type": "twist_2d",
            "description": "Set linear and angular velocity"
          }
        ]
      },
      {
        "actuator_id": "payload_shelf",
        "type": "linear_lift",
        "range_m": { "min": 0.0, "max": 0.15 },
        "commands": [
          {
            "command_id": "lift",
            "data_type": "float",
            "unit": "meters",
            "description": "Set shelf height"
          }
        ]
      }
    ],
    "capabilities": [
      {
        "capability_id": "navigation",
        "type": "autonomous_navigation",
        "description": "Navigate to a goal pose in a known map using AMCL localization and DWA local planner.",
        "parameters": {
          "map_required": true,
          "localization_method": "amcl",
          "planner": "dwa",
          "min_obstacle_distance_m": 0.3
        }
      },
      {
        "capability_id": "payload_transport",
        "type": "cargo_transport",
        "description": "Transport payloads up to 100 kg on integrated shelf.",
        "parameters": {
          "max_payload_kg": 100.0,
          "shelf_dimensions_m": { "length": 0.6, "width": 0.4 }
        }
      }
    ],
    "capabilities_summary": ["autonomous_navigation", "cargo_transport"],
    "safety": {
      "emergency_stop": true,
      "safety_rated_speed_ms": 1.0,
      "protective_stop_distance_m": 0.5,
      "safety_zones": [
        {
          "zone_id": "warning",
          "type": "speed_reduction",
          "distance_m": 1.5,
          "action": "reduce_speed_50_percent"
        },
        {
          "zone_id": "protective",
          "type": "stop",
          "distance_m": 0.5,
          "action": "protective_stop"
        }
      ],
      "certifications": ["ISO_3691-4", "CE"]
    },
    "endpoints": {
      "primary": "zenoh://192.168.10.107:7447",
      "fallback": "wss://192.168.10.107:9443/rosp"
    }
  }
}
```

#### Example: Summary Describe Response

```json
{
  "rosp": "0.1",
  "type": "describe",
  "path": "/fleet/warehouse-1/robot/amr-007",
  "id": "d1a2b3c4-5678-9abc-def0-123456789abc",
  "timestamp": "2026-03-25T14:30:00.048Z",
  "body": {
    "robot_card_version": "2026-03-25T10:00:00Z",
    "identity": {
      "robot_id": "amr-007",
      "manufacturer": "ExampleBot Inc.",
      "model": "WarehouseRunner 3000",
      "serial_number": "WR3K-2026-00842",
      "firmware_version": "2.4.1",
      "rosp_version": "0.1",
      "type": "mobile_robot",
      "description": "Autonomous mobile robot for warehouse logistics with integrated LIDAR and payload shelf."
    },
    "capabilities_summary": ["autonomous_navigation", "cargo_transport"],
    "endpoints": {
      "primary": "zenoh://192.168.10.107:7447",
      "fallback": "wss://192.168.10.107:9443/rosp"
    }
  }
}
```

---

### 5.2 stream

#### Purpose

Subscribe to continuous sensor data or state updates from a robot. The platform sends a subscribe request specifying topics and desired QoS. The robot responds with the QoS it can actually deliver, then begins publishing data messages on the subscribed topics.

#### Direction

- **Subscribe request:** Platform -> Robot
- **QoS negotiation response:** Robot -> Platform
- **Stream data:** Robot -> Platform (continuous)
- **Unsubscribe request:** Platform -> Robot

#### Subscribe Request Body Schema

```json
{
  "action": "subscribe",
  "topics": [
    "/sensor/lidar/pointcloud",
    "/sensor/imu/orientation"
  ],
  "qos": {
    "reliability": "best_effort | reliable",
    "frequency_hz": 10,
    "max_latency_ms": 100,
    "compression": "none | lz4 | zstd",
    "encoding": "json | cbor | protobuf"
  }
}
```

| Field | Type | Required | Description |
|-------|------|----------|-------------|
| `action` | string | Yes | `"subscribe"` or `"unsubscribe"`. |
| `topics` | string[] | Yes | Array of resource sub-paths relative to the robot's path. Each topic corresponds to a `topic_id` in the Robot Card's sensor definition. |
| `qos` | object | No | Requested Quality of Service parameters. If omitted, the robot uses its defaults. |
| `qos.reliability` | string | No | `"best_effort"`: messages may be dropped under load. `"reliable"`: all messages delivered in order (may increase latency). Default: `"best_effort"`. |
| `qos.frequency_hz` | number | No | Desired publish rate in Hz. The robot will downsample if its native rate is higher. Default: native sensor rate. |
| `qos.max_latency_ms` | number | No | Maximum acceptable end-to-end latency in milliseconds. The robot MAY reject the subscription if it cannot meet this constraint. |
| `qos.compression` | string | No | Compression algorithm for stream payloads. `"none"`, `"lz4"` (fast, low ratio), `"zstd"` (better ratio, more CPU). Default: `"none"`. |
| `qos.encoding` | string | No | Serialization format. `"json"` (human-readable, larger), `"cbor"` (binary, compact), `"protobuf"` (binary, schema-required). Default: `"json"`. |

#### QoS Negotiation Response Body Schema

The robot responds with the QoS it can actually provide. This MAY differ from the requested QoS.

```json
{
  "subscriptions": [
    {
      "topic": "/sensor/lidar/pointcloud",
      "status": "active",
      "qos": {
        "reliability": "best_effort",
        "frequency_hz": 10,
        "max_latency_ms": 50,
        "compression": "lz4",
        "encoding": "cbor"
      },
      "subscription_id": "sub-lidar-001"
    },
    {
      "topic": "/sensor/imu/orientation",
      "status": "active",
      "qos": {
        "reliability": "reliable",
        "frequency_hz": 10,
        "max_latency_ms": 10,
        "compression": "none",
        "encoding": "json"
      },
      "subscription_id": "sub-imu-001"
    }
  ]
}
```

| Field | Type | Description |
|-------|------|-------------|
| `subscriptions` | array | One entry per requested topic. |
| `subscriptions[].topic` | string | The topic path, echoed from the request. |
| `subscriptions[].status` | string | `"active"` if the subscription was accepted. `"rejected"` if the robot cannot serve this topic. `"degraded"` if the robot accepted but cannot meet the requested QoS. |
| `subscriptions[].qos` | object | The actual QoS the robot will provide. The platform MUST use these values, not the requested ones. |
| `subscriptions[].subscription_id` | string | Server-assigned identifier for this subscription. Used as the `id` field in subsequent stream data messages. |

If `status` is `"rejected"`, the response SHOULD include a `reason` string explaining why (e.g., `"topic not available"`, `"frequency exceeds sensor capability"`).

#### Stream Data Message Body Schema

Once a subscription is active, the robot publishes data messages continuously:

```json
{
  "topic": "/sensor/imu/orientation",
  "seq": 12345,
  "sensor_timestamp": "2026-03-25T14:30:01.234567890Z",
  "data": {
    "x": 0.001,
    "y": -0.003,
    "z": 0.707,
    "w": 0.707
  }
}
```

| Field | Type | Description |
|-------|------|-------------|
| `topic` | string | The topic this data belongs to. |
| `seq` | integer | Monotonically increasing sequence number. Starts at 0 for each subscription. Used to detect dropped messages. |
| `sensor_timestamp` | string | ISO 8601 timestamp from the sensor's clock at the moment of measurement. This MAY differ from the envelope `timestamp` (which is the time the ROSP message was created). |
| `data` | object | Sensor-specific payload. The schema is defined in the Robot Card's sensor topic definition. |

The envelope-level `id` field for stream data messages MUST be set to the `subscription_id` returned during QoS negotiation. The envelope-level `type` is `"stream"`.

#### Unsubscribe Request Body Schema

```json
{
  "action": "unsubscribe",
  "topics": ["/sensor/lidar/pointcloud"]
}
```

The robot responds with a confirmation:

```json
{
  "unsubscribed": ["/sensor/lidar/pointcloud"],
  "remaining": ["/sensor/imu/orientation"]
}
```

#### Example: Full Subscribe Exchange

**1. Subscribe request:**

```json
{
  "rosp": "0.1",
  "type": "stream",
  "path": "/fleet/warehouse-1/robot/amr-007",
  "id": "sub-req-001",
  "timestamp": "2026-03-25T14:30:00.000Z",
  "body": {
    "action": "subscribe",
    "topics": [
      "/sensor/lidar/scan",
      "/sensor/imu/orientation",
      "/sensor/battery_monitor/status"
    ],
    "qos": {
      "reliability": "best_effort",
      "frequency_hz": 10,
      "compression": "lz4",
      "encoding": "json"
    }
  }
}
```

**2. QoS negotiation response:**

```json
{
  "rosp": "0.1",
  "type": "stream",
  "path": "/fleet/warehouse-1/robot/amr-007",
  "id": "sub-req-001",
  "timestamp": "2026-03-25T14:30:00.023Z",
  "body": {
    "subscriptions": [
      {
        "topic": "/sensor/lidar/scan",
        "status": "active",
        "qos": {
          "reliability": "best_effort",
          "frequency_hz": 10,
          "max_latency_ms": 30,
          "compression": "lz4",
          "encoding": "json"
        },
        "subscription_id": "sub-lidar-scan-4a7b"
      },
      {
        "topic": "/sensor/imu/orientation",
        "status": "active",
        "qos": {
          "reliability": "best_effort",
          "frequency_hz": 10,
          "max_latency_ms": 5,
          "compression": "none",
          "encoding": "json"
        },
        "subscription_id": "sub-imu-orient-8c3d"
      },
      {
        "topic": "/sensor/battery_monitor/status",
        "status": "degraded",
        "qos": {
          "reliability": "reliable",
          "frequency_hz": 1,
          "max_latency_ms": 500,
          "compression": "none",
          "encoding": "json"
        },
        "subscription_id": "sub-battery-e1f2",
        "reason": "Battery monitor publishes at 1 Hz maximum. Requested 10 Hz not achievable."
      }
    ]
  }
}
```

**3. Stream data message (one of many):**

```json
{
  "rosp": "0.1",
  "type": "stream",
  "path": "/fleet/warehouse-1/robot/amr-007/sensor/imu/orientation",
  "id": "sub-imu-orient-8c3d",
  "timestamp": "2026-03-25T14:30:01.100Z",
  "body": {
    "topic": "/sensor/imu/orientation",
    "seq": 11,
    "sensor_timestamp": "2026-03-25T14:30:01.099832000Z",
    "data": {
      "x": 0.0012,
      "y": -0.0028,
      "z": 0.7071,
      "w": 0.7071
    }
  }
}
```

---

### 5.3 discover

#### Purpose

Find ROSP-compatible robots on the network. Discovery can be local (mDNS/DNS-SD on a LAN) or remote (MQTT retained messages, HTTP registry). Platforms broadcast a discovery request; robots (via adapters) respond with their identity and capabilities summary.

#### Direction

- **Discovery request:** Platform -> broadcast (local) or registry (remote)
- **Discovery response:** Each robot -> Platform

#### Discovery Mechanisms

ROSP v0.1 supports two discovery mechanisms. Implementations MUST support at least one:

**1. Local network discovery (mDNS/DNS-SD):**
- Service type: `_rosp._tcp`
- TXT records include: `rosp_version`, `robot_id`, `model`, `type`
- Adapters register themselves as mDNS services on startup
- Platforms browse for `_rosp._tcp` services and send `describe` requests to discovered endpoints

**2. Remote/WAN discovery (MQTT 5.0 retained messages):**
- Topic: `rosp/discovery/{fleet_id}/{robot_id}`
- Adapters publish their discovery response as a retained message
- Platforms subscribe to `rosp/discovery/{fleet_id}/+` to receive all robots in a fleet
- Message expiry interval SHOULD be set to the adapter's heartbeat interval x 3

**3. HTTP Registry (OPTIONAL):**
- A centralized registry (e.g., RoboSwarm platform) MAY provide an HTTP API for discovery
- `GET /api/v1/discover?type=mobile_robot&sensors=lidar`
- This is a platform feature, not part of the core ROSP protocol

#### Discovery Request Body Schema (ROSP Message)

For ROSP-native discovery (not mDNS), the platform sends a discover message:

```json
{
  "filter": {
    "type": "mobile_robot",
    "manufacturer": "ExampleBot Inc.",
    "sensors": ["lidar", "imu"],
    "capabilities": ["autonomous_navigation"],
    "payload_kg_min": 5.0,
    "rosp_version": "0.1"
  }
}
```

| Field | Type | Required | Description |
|-------|------|----------|-------------|
| `filter` | object | No | If omitted, all robots respond. |
| `filter.type` | string | No | Robot type filter. Values: `"mobile_robot"`, `"manipulator"`, `"humanoid"`, `"drone"`, `"fixed_industrial"`, `"quadruped"`, `"custom"`. |
| `filter.manufacturer` | string | No | Manufacturer name (case-insensitive substring match). |
| `filter.sensors` | string[] | No | Required sensor types. Robot must have ALL listed sensor types. |
| `filter.capabilities` | string[] | No | Required capability types. Robot must have ALL listed capabilities. |
| `filter.payload_kg_min` | number | No | Minimum payload capacity in kg. |
| `filter.rosp_version` | string | No | Required ROSP version. |

A robot MUST respond to a discovery request only if it matches ALL specified filter criteria. If no filter is provided, all robots MUST respond.

#### Discovery Response Body Schema

```json
{
  "robot_id": "amr-007",
  "manufacturer": "ExampleBot Inc.",
  "model": "WarehouseRunner 3000",
  "serial_number": "WR3K-2026-00842",
  "type": "mobile_robot",
  "rosp_version": "0.1",
  "capabilities_summary": ["autonomous_navigation", "cargo_transport"],
  "sensors_summary": ["lidar_2d", "imu_6dof", "power_monitor"],
  "status": "online",
  "battery_percent": 84,
  "uptime_s": 43200,
  "endpoint": "zenoh://192.168.10.107:7447",
  "fleet_ids": ["warehouse-1"]
}
```

| Field | Type | Description |
|-------|------|-------------|
| `robot_id` | string | Unique robot identifier. |
| `manufacturer` | string | Robot manufacturer. |
| `model` | string | Robot model name. |
| `serial_number` | string | Hardware serial number. |
| `type` | string | Robot type classification. |
| `rosp_version` | string | ROSP version supported by this adapter. |
| `capabilities_summary` | string[] | List of capability type identifiers. |
| `sensors_summary` | string[] | List of sensor type identifiers. |
| `status` | string | Current robot status: `"online"`, `"busy"`, `"charging"`, `"error"`, `"offline"`. |
| `battery_percent` | number | Battery charge percentage (0-100). OPTIONAL. |
| `uptime_s` | number | Seconds since last boot. OPTIONAL. |
| `endpoint` | string | ROSP endpoint URI for connecting to this robot. |
| `fleet_ids` | string[] | Fleets this robot belongs to. |

#### Example: Full Discovery Exchange

**1. Discovery request (broadcast):**

```json
{
  "rosp": "0.1",
  "type": "discover",
  "path": "/fleet/warehouse-1/robot/*",
  "id": "disc-001",
  "timestamp": "2026-03-25T14:00:00.000Z",
  "body": {
    "filter": {
      "type": "mobile_robot",
      "sensors": ["lidar"],
      "payload_kg_min": 50.0
    }
  }
}
```

**2. Discovery response from Robot A:**

```json
{
  "rosp": "0.1",
  "type": "discover",
  "path": "/fleet/warehouse-1/robot/amr-007",
  "id": "disc-001",
  "timestamp": "2026-03-25T14:00:00.031Z",
  "body": {
    "robot_id": "amr-007",
    "manufacturer": "ExampleBot Inc.",
    "model": "WarehouseRunner 3000",
    "serial_number": "WR3K-2026-00842",
    "type": "mobile_robot",
    "rosp_version": "0.1",
    "capabilities_summary": ["autonomous_navigation", "cargo_transport"],
    "sensors_summary": ["lidar_2d", "imu_6dof", "power_monitor"],
    "status": "online",
    "battery_percent": 84,
    "uptime_s": 43200,
    "endpoint": "zenoh://192.168.10.107:7447",
    "fleet_ids": ["warehouse-1"]
  }
}
```

**3. Discovery response from Robot B:**

```json
{
  "rosp": "0.1",
  "type": "discover",
  "path": "/fleet/warehouse-1/robot/amr-012",
  "id": "disc-001",
  "timestamp": "2026-03-25T14:00:00.045Z",
  "body": {
    "robot_id": "amr-012",
    "manufacturer": "ExampleBot Inc.",
    "model": "WarehouseRunner 3000",
    "serial_number": "WR3K-2026-01103",
    "type": "mobile_robot",
    "rosp_version": "0.1",
    "capabilities_summary": ["autonomous_navigation", "cargo_transport"],
    "sensors_summary": ["lidar_2d", "imu_6dof", "power_monitor"],
    "status": "busy",
    "battery_percent": 62,
    "uptime_s": 28800,
    "endpoint": "zenoh://192.168.10.112:7447",
    "fleet_ids": ["warehouse-1"]
  }
}
```

---

### 5.4 command (DRAFT -- Control Mode)

> **This section is DRAFT. Message formats and semantics MAY change before ROSP v1.0.**

#### Purpose

Send an action command to a single robot. Commands follow a lifecycle modeled on ROS2 Actions: the platform sends a goal, the robot accepts or rejects it, provides periodic feedback during execution, and returns a final result.

#### Direction

- **Command request:** Platform -> Robot
- **Acceptance:** Robot -> Platform
- **Feedback:** Robot -> Platform (periodic, during execution)
- **Result:** Robot -> Platform (terminal)

#### Command Request Body Schema

```json
{
  "action": "navigate",
  "params": {
    "target": {
      "x": 12.5,
      "y": 7.3,
      "theta": 1.57
    },
    "frame": "map",
    "velocity_limit_ms": 1.0
  },
  "timeout_ms": 30000,
  "priority": "normal",
  "expires_at": "2026-03-25T14:31:00.000Z",
  "idempotency_key": "nav-to-shelf-A3-attempt-1"
}
```

| Field | Type | Required | Description |
|-------|------|----------|-------------|
| `action` | string | Yes | Action identifier. Must match a `capability_id` or `command_id` in the Robot Card. |
| `params` | object | Yes | Action-specific parameters. Schema defined by the Robot Card's capability/command definition. |
| `timeout_ms` | number | No | Maximum execution time in milliseconds. If exceeded, the robot MUST abort and return a `"timed_out"` result. Default: adapter-defined. |
| `priority` | string | No | Execution priority. `"normal"` (default), `"urgent"` (preempt normal tasks), `"critical"` (safety-critical, immediate execution). |
| `expires_at` | string | Yes | ISO 8601 UTC timestamp after which the command MUST be rejected. This is a safety mechanism: if a command is delayed in transit, it will not execute unexpectedly. The robot MUST compare `expires_at` against its own clock and reject the command with error code `5002` if expired. |
| `idempotency_key` | string | No | Client-assigned key for idempotent execution. If the robot receives a duplicate `idempotency_key`, it MUST return the result of the original execution, not execute again. |

#### Command Response Lifecycle

A command progresses through the following states:

```
                  +----------+
    Request ----->| received |
                  +----+-----+
                       |
              +--------+--------+
              |                 |
        +-----v-----+    +-----v-----+
        |  accepted  |    |  rejected |
        +-----+------+    +-----------+
              |
        +-----v------+
        | in_progress |<--+
        +-----+------+   |
              |           | (feedback loop)
              +-----------+
              |
     +--------+--------+--------+
     |        |        |        |
+----v---+ +--v---+ +--v----+ +-v--------+
|completed| |failed| |timed_ | |preempted |
|         | |      | |out    | |          |
+---------+ +------+ +-------+ +----------+
```

**State definitions:**

| State | Terminal? | Description |
|-------|----------|-------------|
| `received` | No | Command has been received by the adapter. |
| `accepted` | No | Robot has validated the command and will execute it. |
| `rejected` | Yes | Robot cannot or will not execute the command. Includes reason. |
| `in_progress` | No | Command is actively executing. Accompanied by feedback. |
| `completed` | Yes | Command finished successfully. Includes result data. |
| `failed` | Yes | Command failed during execution. Includes error details. |
| `timed_out` | Yes | Command exceeded `timeout_ms`. Robot has stopped the action. |
| `preempted` | Yes | Command was preempted by a higher-priority command or safety stop. |

#### Acceptance Response Body

```json
{
  "state": "accepted",
  "command_id": "cmd-nav-5a8f",
  "estimated_duration_ms": 15000
}
```

#### Feedback Body (periodic during `in_progress`)

```json
{
  "state": "in_progress",
  "command_id": "cmd-nav-5a8f",
  "progress": 0.65,
  "eta_ms": 5200,
  "feedback": {
    "current_position": { "x": 10.2, "y": 6.1, "theta": 1.2 },
    "distance_remaining_m": 3.1,
    "velocity_ms": 0.8
  }
}
```

| Field | Type | Description |
|-------|------|-------------|
| `state` | string | Always `"in_progress"` for feedback messages. |
| `command_id` | string | Server-assigned command identifier. |
| `progress` | number | Estimated completion progress, 0.0 to 1.0. |
| `eta_ms` | number | Estimated time to completion in milliseconds. |
| `feedback` | object | Action-specific feedback data. Schema is action-dependent. |

#### Result Body (terminal state)

```json
{
  "state": "completed",
  "command_id": "cmd-nav-5a8f",
  "result": {
    "final_position": { "x": 12.48, "y": 7.31, "theta": 1.57 },
    "actual_duration_ms": 14200,
    "distance_traveled_m": 8.7
  }
}
```

For `"failed"`:

```json
{
  "state": "failed",
  "command_id": "cmd-nav-5a8f",
  "error": {
    "code": 3012,
    "category": "robot",
    "message": "Path blocked by obstacle. Replanning failed after 3 attempts.",
    "details": {
      "obstacle_position": { "x": 11.0, "y": 7.0 },
      "last_position": { "x": 9.8, "y": 6.5 }
    }
  }
}
```

#### Safety Requirements for Commands

1. **Expiration:** Every command MUST include `expires_at`. The robot MUST reject commands where `expires_at` is in the past relative to the robot's clock. Clock skew tolerance: 5 seconds (configurable per adapter).
2. **Watchdog heartbeat:** During `in_progress`, the platform MUST send a heartbeat at least every `watchdog_interval_ms` (default: 5000 ms). If the robot does not receive a heartbeat within 2x the interval, it MUST initiate a safe stop and return state `"preempted"` with reason `"watchdog_timeout"`.
3. **Kinematic validation:** The adapter SHOULD validate command parameters against the robot's kinematic limits (from the Robot Card) before forwarding to the robot. Out-of-range parameters MUST result in `"rejected"` with error code `5003`.
4. **Authorization:** Commands require the Controller RBAC role or higher (see Section 8). Commands with `priority: "critical"` require the Safety role.

#### Example: Full Command Lifecycle

**1. Command request:**

```json
{
  "rosp": "0.1",
  "type": "command",
  "path": "/fleet/warehouse-1/robot/amr-007",
  "id": "cmd-001",
  "timestamp": "2026-03-25T14:30:00.000Z",
  "body": {
    "action": "navigate",
    "params": {
      "target": { "x": 12.5, "y": 7.3, "theta": 1.57 },
      "frame": "map"
    },
    "timeout_ms": 30000,
    "priority": "normal",
    "expires_at": "2026-03-25T14:31:00.000Z"
  }
}
```

**2. Acceptance:**

```json
{
  "rosp": "0.1",
  "type": "command",
  "path": "/fleet/warehouse-1/robot/amr-007",
  "id": "cmd-001",
  "timestamp": "2026-03-25T14:30:00.085Z",
  "body": {
    "state": "accepted",
    "command_id": "cmd-nav-5a8f",
    "estimated_duration_ms": 15000
  }
}
```

**3. Feedback (first):**

```json
{
  "rosp": "0.1",
  "type": "command",
  "path": "/fleet/warehouse-1/robot/amr-007",
  "id": "cmd-001",
  "timestamp": "2026-03-25T14:30:05.000Z",
  "body": {
    "state": "in_progress",
    "command_id": "cmd-nav-5a8f",
    "progress": 0.35,
    "eta_ms": 9800,
    "feedback": {
      "current_position": { "x": 8.1, "y": 5.2, "theta": 0.9 },
      "distance_remaining_m": 5.6,
      "velocity_ms": 1.0
    }
  }
}
```

**4. Feedback (second):**

```json
{
  "rosp": "0.1",
  "type": "command",
  "path": "/fleet/warehouse-1/robot/amr-007",
  "id": "cmd-001",
  "timestamp": "2026-03-25T14:30:10.000Z",
  "body": {
    "state": "in_progress",
    "command_id": "cmd-nav-5a8f",
    "progress": 0.72,
    "eta_ms": 4200,
    "feedback": {
      "current_position": { "x": 10.9, "y": 6.8, "theta": 1.3 },
      "distance_remaining_m": 2.1,
      "velocity_ms": 0.9
    }
  }
}
```

**5. Completion:**

```json
{
  "rosp": "0.1",
  "type": "command",
  "path": "/fleet/warehouse-1/robot/amr-007",
  "id": "cmd-001",
  "timestamp": "2026-03-25T14:30:14.200Z",
  "body": {
    "state": "completed",
    "command_id": "cmd-nav-5a8f",
    "result": {
      "final_position": { "x": 12.48, "y": 7.31, "theta": 1.57 },
      "actual_duration_ms": 14200,
      "distance_traveled_m": 8.7
    }
  }
}
```

---

### 5.5 coordinate (DRAFT -- Control Mode)

> **This section is DRAFT. Message formats and semantics MAY change before ROSP v1.0.**

#### Purpose

Assign and coordinate tasks across multiple robots in a fleet. Unlike `command` (which targets a single robot), `coordinate` targets a fleet and specifies assignments for multiple robots, with optional inter-robot constraints.

#### Direction

- **Coordination request:** Platform -> Fleet (adapter routes to individual robots)
- **Coordination status:** Fleet -> Platform (aggregated)

#### Coordination Request Body Schema

```json
{
  "task": "fleet_navigate",
  "assignments": [
    {
      "robot_id": "amr-007",
      "action": "navigate",
      "params": {
        "target": { "x": 12.5, "y": 7.3, "theta": 1.57 },
        "frame": "map"
      },
      "priority": "normal"
    },
    {
      "robot_id": "amr-012",
      "action": "navigate",
      "params": {
        "target": { "x": 8.0, "y": 12.1, "theta": 0.0 },
        "frame": "map"
      },
      "priority": "normal"
    }
  ],
  "constraints": {
    "min_distance_m": 1.0,
    "priority_order": ["amr-007", "amr-012"],
    "synchronization": "none | start_together | finish_together",
    "timeout_ms": 60000
  },
  "expires_at": "2026-03-25T14:32:00.000Z"
}
```

| Field | Type | Required | Description |
|-------|------|----------|-------------|
| `task` | string | Yes | Coordination task identifier. |
| `assignments` | array | Yes | Per-robot action assignments. Each entry follows the same schema as the `command` body, with an added `robot_id` field. |
| `assignments[].robot_id` | string | Yes | Target robot for this assignment. |
| `constraints` | object | No | Inter-robot constraints. |
| `constraints.min_distance_m` | number | No | Minimum distance between any two assigned robots during execution. |
| `constraints.priority_order` | string[] | No | If robots' paths conflict, robots earlier in this list have priority. |
| `constraints.synchronization` | string | No | `"none"`: robots execute independently. `"start_together"`: all robots begin simultaneously. `"finish_together"`: faster robots wait for slower ones. Default: `"none"`. |
| `constraints.timeout_ms` | number | No | Maximum time for the entire coordination task. |
| `expires_at` | string | Yes | Expiration timestamp (same semantics as `command`). |

#### Coordination Response Body Schema

```json
{
  "task_id": "coord-fleet-nav-7e2a",
  "state": "accepted",
  "robot_states": [
    {
      "robot_id": "amr-007",
      "state": "accepted",
      "command_id": "cmd-nav-5a8f"
    },
    {
      "robot_id": "amr-012",
      "state": "accepted",
      "command_id": "cmd-nav-b2c1"
    }
  ]
}
```

The coordination task's aggregate state is determined by the individual robot states:

| Aggregate State | Condition |
|----------------|-----------|
| `accepted` | All robots accepted. |
| `in_progress` | At least one robot is `in_progress` and none have `failed`. |
| `completed` | All robots completed. |
| `partially_completed` | Some robots completed, others failed or timed out. |
| `failed` | All robots failed. |
| `rejected` | At least one robot rejected and the task cannot proceed without it. |

#### Coordination Feedback

Coordination feedback messages contain per-robot progress:

```json
{
  "task_id": "coord-fleet-nav-7e2a",
  "state": "in_progress",
  "robot_states": [
    {
      "robot_id": "amr-007",
      "state": "in_progress",
      "progress": 0.65
    },
    {
      "robot_id": "amr-012",
      "state": "in_progress",
      "progress": 0.42
    }
  ],
  "constraint_status": {
    "min_distance_m": {
      "current_min": 4.2,
      "satisfied": true
    }
  }
}
```

---

## 6. Capability Negotiation

When a platform connects to a robot adapter for the first time, they perform an initialization handshake to establish the session, negotiate supported features, and authenticate.

### 6.1 Handshake Sequence

```
Platform                                     Adapter (Robot)
   |                                              |
   |  1. initialize (request)                     |
   |--------------------------------------------->|
   |                                              |
   |  2. initialize_response                      |
   |<---------------------------------------------|
   |                                              |
   |  3. initialized (notification)               |
   |--------------------------------------------->|
   |                                              |
   |  Session established. Operations may begin.  |
```

### 6.2 Initialize Request

Sent by the platform to the adapter.

```json
{
  "rosp": "0.1",
  "type": "initialize",
  "path": "/",
  "id": "init-001",
  "timestamp": "2026-03-25T14:29:55.000Z",
  "body": {
    "platform_id": "roboswarm-cloud-01",
    "platform_name": "RoboSwarm Fleet Manager",
    "features": ["describe", "stream", "discover"],
    "protocol_versions": ["0.1"],
    "auth": {
      "method": "mtls",
      "client_cert_fingerprint": "SHA256:2CF24DBA5FB0A30E26E83B2AC5B9E29E..."
    },
    "session_config": {
      "heartbeat_interval_ms": 5000,
      "max_subscriptions": 50,
      "preferred_encoding": "json"
    }
  }
}
```

| Field | Type | Description |
|-------|------|-------------|
| `platform_id` | string | Unique identifier for the connecting platform. |
| `platform_name` | string | Human-readable platform name. |
| `features` | string[] | ROSP operations the platform supports. Must be a subset of: `["describe", "stream", "discover", "command", "coordinate"]`. |
| `protocol_versions` | string[] | ROSP versions the platform supports, in preference order. |
| `auth` | object | Authentication credentials. See Section 8. |
| `session_config` | object | Optional session configuration preferences. |

### 6.3 Initialize Response

Sent by the adapter to the platform.

```json
{
  "rosp": "0.1",
  "type": "initialize",
  "path": "/",
  "id": "init-001",
  "timestamp": "2026-03-25T14:29:55.042Z",
  "body": {
    "robot_id": "amr-007",
    "adapter_name": "ROS2 ROSP Adapter",
    "adapter_version": "0.1.0",
    "features": ["describe", "stream"],
    "protocol_version": "0.1",
    "robot_card_version": "2026-03-25T10:00:00Z",
    "auth": {
      "status": "authenticated",
      "role": "observer",
      "session_token": "eyJhbGciOiJFZERTQSIs...",
      "expires_at": "2026-03-25T15:29:55.000Z"
    },
    "session_config": {
      "heartbeat_interval_ms": 5000,
      "max_subscriptions": 20,
      "supported_encodings": ["json", "cbor"],
      "watchdog_interval_ms": 5000
    }
  }
}
```

| Field | Type | Description |
|-------|------|-------------|
| `robot_id` | string | Robot identifier served by this adapter. |
| `adapter_name` | string | Human-readable adapter name. |
| `adapter_version` | string | Adapter software version. |
| `features` | string[] | ROSP operations the adapter supports. |
| `protocol_version` | string | Selected protocol version (from the intersection of both parties' supported versions). |
| `robot_card_version` | string | ISO 8601 timestamp of the current Robot Card version. Platforms can cache Robot Cards and skip `describe` if the version has not changed. |
| `auth` | object | Authentication result. |
| `session_config` | object | Negotiated session parameters. Both parties MUST use the values in this field. |

### 6.4 Feature Negotiation Rules

1. Both parties declare their supported features in the `features` array.
2. The effective feature set for the session is the **intersection** of both parties' features.
3. Neither party MAY invoke an operation outside the negotiated feature set. Doing so results in error code `2003` (unsupported operation).
4. If the intersection is empty (no common features), the adapter MUST respond with error code `2002` (incompatible features) and close the connection.

### 6.5 Session Lifecycle

- **Heartbeat:** Both parties MUST send heartbeat messages at the negotiated `heartbeat_interval_ms`. A heartbeat is a message with `type: "heartbeat"` and an empty body.
- **Session expiration:** The `auth.expires_at` timestamp indicates when the session token expires. The platform MUST re-authenticate before this time.
- **Graceful shutdown:** Either party MAY close the session by sending a message with `type: "shutdown"` and an empty body. The other party MUST acknowledge and release resources.
- **Ungraceful disconnection:** If a party does not receive a heartbeat within 3x the `heartbeat_interval_ms`, it MUST consider the session dead and release all resources (subscriptions, pending commands).

---

## 7. Transport Bindings

ROSP is transport-agnostic. The message envelope (Section 4) and operation semantics (Section 5) are defined independently of how messages are carried on the wire. This section defines how ROSP maps to specific transport protocols.

A compliant ROSP implementation MUST support at least one transport binding. Implementations SHOULD support Zenoh or WebSocket for broadest compatibility.

### 7.1 Zenoh (Recommended for Tier 2 / Tier 3)

[Eclipse Zenoh](https://zenoh.io) is a pub/sub/query protocol that unifies data in motion, data at rest, and computations. It outperforms DDS by 97-99% in latency benchmarks and is NAT/firewall-friendly.

#### Topic Mapping

ROSP paths map directly to Zenoh key expressions:

| ROSP Path | Zenoh Key Expression |
|-----------|---------------------|
| `/fleet/warehouse-1/robot/amr-007/sensor/lidar/scan` | `rosp/warehouse-1/amr-007/sensor/lidar/scan` |
| `/fleet/warehouse-1/robot/*/health` | `rosp/warehouse-1/*/health` |

**Prefix:** All ROSP Zenoh keys begin with `rosp/`.

**Mapping rule:** Remove `/fleet/` and `/robot/` path segments and replace with `/`. The fleet ID and robot ID become direct path segments.

#### Serialization

- Default: JSON (UTF-8 encoded)
- Recommended for high-frequency data: CBOR (RFC 8949) or Protobuf
- Content type declared via Zenoh attachment metadata

#### Operation Mapping

| ROSP Operation | Zenoh Primitive |
|---------------|-----------------|
| `describe` | Queryable (request/reply) |
| `stream` subscribe | Subscriber |
| `stream` data | Publisher |
| `discover` | Liveliness tokens + Queryable |
| `command` | Queryable (request) + Publisher (feedback) |
| `heartbeat` | Liveliness token |

#### QoS Profiles

| Profile | Zenoh Configuration | Use Case |
|---------|-------------------|----------|
| Real-time sensor | Reliability: BestEffort, Congestion: Drop, Priority: RealTime | Lidar, IMU, camera |
| Reliable state | Reliability: Reliable, Congestion: Block, Priority: DataHigh | State updates, battery |
| Command | Reliability: Reliable, Congestion: Block, Priority: InteractiveHigh | Navigation goals |
| Discovery | Reliability: Reliable + Transient Local, Priority: Data | Robot announcements |

#### Connection Lifecycle

1. Adapter opens a Zenoh session on startup and declares liveliness token at `rosp/{fleet_id}/{robot_id}/alive`.
2. Platform opens a Zenoh session and subscribes to liveliness tokens for discovery.
3. Platform sends `initialize` via Zenoh queryable at `rosp/{fleet_id}/{robot_id}/rpc`.
4. After handshake, platform subscribes to data topics and sends commands via queryables.
5. On shutdown, adapter undeclares liveliness token. Subscribers are notified.

### 7.2 gRPC + Protobuf (Cloud API, Tier 3)

For cloud-to-platform and platform-to-platform communication, gRPC provides strong typing, code generation, and standard HTTP/2 infrastructure compatibility.

#### Service Definition

```protobuf
syntax = "proto3";
package rosp.v0_1;

service RospService {
  // Description Mode
  rpc Describe(RospRequest) returns (RospResponse);
  rpc Subscribe(StreamRequest) returns (stream StreamData);
  rpc Discover(DiscoverRequest) returns (stream DiscoverResponse);

  // Control Mode (DRAFT)
  rpc Command(CommandRequest) returns (stream CommandUpdate);
  rpc Coordinate(CoordinateRequest) returns (stream CoordinateUpdate);

  // Session Management
  rpc Initialize(InitializeRequest) returns (InitializeResponse);
  rpc Heartbeat(HeartbeatRequest) returns (HeartbeatResponse);
}

message RospRequest {
  string rosp_version = 1;      // "0.1"
  string path = 2;              // ROSP path
  string id = 3;                // Correlation ID
  string timestamp = 4;         // ISO 8601
  bytes body_json = 5;          // JSON-encoded body (for flexibility)
}

message RospResponse {
  string rosp_version = 1;
  string path = 2;
  string id = 3;
  string timestamp = 4;
  bytes body_json = 5;
}

message StreamData {
  string topic = 1;
  uint64 seq = 2;
  string sensor_timestamp = 3;
  bytes data = 4;               // Encoded per negotiated format
  string encoding = 5;          // "json", "cbor", "protobuf"
}
```

**Note:** The `body_json` field carries the ROSP body as JSON bytes for maximum flexibility. Implementations MAY define strongly-typed Protobuf messages for specific operations in future versions.

#### Connection Lifecycle

1. Platform establishes gRPC channel with mTLS.
2. Platform calls `Initialize` RPC.
3. Platform calls `Describe`, `Subscribe`, etc. as needed.
4. Platform maintains heartbeat via periodic `Heartbeat` RPCs.
5. On shutdown, platform closes the gRPC channel.

### 7.3 WebSocket (Web Clients, Simple Integrations)

For browser-based dashboards, lightweight tools, and environments where Zenoh/gRPC are not available.

#### Connection

- Endpoint: `wss://{host}:{port}/rosp`
- Protocol: TLS 1.3 required. Plain `ws://` MUST NOT be used in production.
- Subprotocol: `rosp.v0.1` (declared in WebSocket handshake `Sec-WebSocket-Protocol` header)

#### Message Format

Each WebSocket message is a single ROSP envelope encoded as UTF-8 JSON text. Binary frames MAY be used for stream data with `cbor` or `protobuf` encoding.

#### Multiplexing

Multiple ROSP operations share a single WebSocket connection. The `id` field is used to correlate requests with responses. Stream data messages use the `subscription_id` as the `id`.

#### Connection Lifecycle

1. Platform opens WebSocket with `Sec-WebSocket-Protocol: rosp.v0.1`.
2. Platform sends `initialize` message.
3. Adapter responds with `initialize_response`.
4. Platform sends `initialized` notification.
5. Operations proceed over the same connection.
6. Either party sends `shutdown` message to close gracefully.
7. WebSocket close frame sent after `shutdown` acknowledgment.

#### Ping/Pong

WebSocket ping/pong frames serve as the transport-level heartbeat. ROSP-level heartbeats (`type: "heartbeat"`) are still REQUIRED for application-level liveness detection.

### 7.4 MQTT 5.0 (VDA 5050 Bridging, IoT)

For bridging to VDA 5050-compliant warehouse robots and lightweight IoT devices.

#### Topic Naming Convention

ROSP MQTT topics follow a hierarchical structure compatible with VDA 5050's topic design:

```
rosp/{version}/{fleet_id}/{robot_id}/{operation}/{resource}
```

**Examples:**

| ROSP Operation | MQTT Topic |
|---------------|------------|
| Describe request | `rosp/v0.1/warehouse-1/amr-007/describe/request` |
| Describe response | `rosp/v0.1/warehouse-1/amr-007/describe/response` |
| Stream data (lidar) | `rosp/v0.1/warehouse-1/amr-007/stream/sensor/lidar/scan` |
| Discovery | `rosp/v0.1/warehouse-1/+/discover/response` (wildcard) |
| Command request | `rosp/v0.1/warehouse-1/amr-007/command/request` |
| Command feedback | `rosp/v0.1/warehouse-1/amr-007/command/feedback` |
| Heartbeat | `rosp/v0.1/warehouse-1/amr-007/heartbeat` |

#### MQTT 5.0 Features Used

- **Retained messages:** Discovery responses are published as retained so new subscribers see current robot state.
- **Message expiry:** Heartbeat and discovery messages use `Message Expiry Interval` (3x heartbeat interval).
- **Response topic:** Request/response correlation uses MQTT 5.0 `Response Topic` and `Correlation Data` properties.
- **Content type:** `application/json` for JSON payloads, `application/cbor` for CBOR.
- **User properties:** `rosp-version: 0.1`, `rosp-type: stream`, etc.

#### QoS Mapping

| ROSP QoS | MQTT QoS | Use Case |
|----------|----------|----------|
| `best_effort` | QoS 0 (at most once) | High-frequency sensor data |
| `reliable` | QoS 1 (at least once) | State updates, commands |
| (commands) | QoS 2 (exactly once) | Safety-critical commands |

#### VDA 5050 Bridge

A VDA 5050 bridge adapter translates between ROSP messages and VDA 5050 MQTT topics:

| ROSP | VDA 5050 |
|------|----------|
| `describe` response | `connection` + `factsheet` topics |
| `stream` (state) | `state` topic |
| `command` (navigate) | `order` topic |
| `command` (instant action) | `instantActions` topic |
| discovery | `connection` topic with retained messages |

---

## 8. Security Model

Security is a foundational requirement for ROSP, not an afterthought. Real-world robot security incidents (ABB robot hijacking demonstrated at Black Hat, EUR 6M factory loss from robot system compromise, Unitree Go2 Bluetooth botnet) and upcoming EU regulations (Machinery Regulation 2023/1230, Cyber Resilience Act) make security non-negotiable.

### 8.1 Authentication

#### mTLS (Mutual TLS) -- REQUIRED

All ROSP connections MUST use mutual TLS authentication. Both the platform (client) and the adapter (server) present X.509 certificates during the TLS handshake.

- **TLS version:** TLS 1.3 REQUIRED. TLS 1.2 MAY be supported for legacy devices but MUST be disabled by default.
- **Certificate provisioning:** Certificates are provisioned during robot onboarding. The ROSP specification does not mandate a specific CA or provisioning mechanism. Implementations MAY use ACME, manual provisioning, or a platform-specific onboarding flow.
- **Certificate fields:** The `Subject Alternative Name` (SAN) extension MUST include the entity's ROSP identifier (e.g., `URI:rosp://robot/amr-007` or `URI:rosp://platform/roboswarm-cloud-01`).
- **Certificate rotation:** Implementations MUST support certificate rotation without service interruption. The new certificate SHOULD be deployed at least 24 hours before the old one expires.

#### DTLS 1.3 -- For UDP Transports

When ROSP is carried over UDP-based transports (e.g., Zenoh over UDP), DTLS 1.3 MUST be used instead of TLS 1.3. The same certificate requirements apply.

### 8.2 Authorization (RBAC)

ROSP defines a 5-level Role-Based Access Control model. Each authenticated session is assigned exactly one role. Roles are hierarchical: higher roles include all permissions of lower roles.

| Level | Role | Permitted Operations | Description |
|-------|------|---------------------|-------------|
| 1 | **Observer** | `describe`, `stream`, `discover` | Read-only monitoring. Can view robot data but cannot cause any physical action. |
| 2 | **Operator** | + `command` with action type `navigate` | Can send navigation goals. Cannot directly control actuators. |
| 3 | **Controller** | + `command` with any action type, `coordinate` | Full command authority. Can control actuators, assign fleet tasks. |
| 4 | **Administrator** | + configuration changes, firmware updates, adapter management | System administration. Can modify robot configuration and update firmware. |
| 5 | **Safety** | + emergency stop, safety zone override | Hardware-backed safety authority. Emergency stop commands from this role MUST be routed to the robot's safety controller, bypassing software layers. This role is typically bound to a physical key switch or hardware token, not a software credential alone. |

**Role assignment:** Roles are assigned during the `initialize` handshake based on the client certificate's identity and the adapter's access control list. The adapter responds with the granted `role` in the `initialize_response`.

**Permission enforcement:** The adapter MUST enforce role permissions before executing any operation. An Observer sending a `command` message MUST receive error code `4002` (insufficient permissions).

### 8.3 Audit Logging

Every `command` and `coordinate` operation MUST be logged with the following fields:

```json
{
  "audit_id": "aud-7f3e2a1b-...",
  "timestamp": "2026-03-25T14:30:00.000Z",
  "session_id": "sess-...",
  "platform_id": "roboswarm-cloud-01",
  "role": "controller",
  "robot_id": "amr-007",
  "operation": "command",
  "action": "navigate",
  "params_hash": "SHA256:a1b2c3...",
  "result_state": "completed",
  "duration_ms": 14200
}
```

Audit logs MUST be stored for a minimum of 90 days. Audit logs MUST NOT be modifiable after creation (append-only). Audit logs SHOULD be stored on a separate system from the robot adapter to prevent tampering.

### 8.4 Command Safety

1. **`expires_at` field:** REQUIRED on all `command` and `coordinate` messages. See Section 5.4.
2. **Watchdog heartbeat:** Platform MUST maintain heartbeat during command execution. See Section 5.4.
3. **Kinematic validation:** Adapter SHOULD validate parameters against Robot Card limits. See Section 5.4.
4. **Rate limiting:** Adapters SHOULD implement rate limiting on commands. Recommended: no more than 10 commands/second per session for navigation, no more than 100 commands/second for actuator control.
5. **Command queue depth:** Adapters SHOULD reject commands when the queue exceeds a configurable depth (default: 5). Error code: `3005` (command queue full).

---

## 9. Error Handling

### 9.1 Error Response Format

When an operation fails, the adapter (or platform) responds with an error message:

```json
{
  "rosp": "0.1",
  "type": "error",
  "path": "/fleet/warehouse-1/robot/amr-007",
  "id": "cmd-001",
  "timestamp": "2026-03-25T14:30:00.100Z",
  "body": {
    "code": 4002,
    "category": "auth",
    "message": "Insufficient permissions. Role 'observer' cannot execute 'command' operations. Required role: 'controller' or higher.",
    "details": {
      "current_role": "observer",
      "required_role": "controller",
      "operation": "command"
    }
  }
}
```

### 9.2 Error Body Schema

| Field | Type | Required | Description |
|-------|------|----------|-------------|
| `code` | integer | Yes | Numeric error code. See Section 9.3. |
| `category` | string | Yes | Error category: `"transport"`, `"protocol"`, `"robot"`, `"auth"`, `"safety"`. |
| `message` | string | Yes | Human-readable error description. Implementations SHOULD provide actionable messages. |
| `details` | object | No | Machine-readable error details. Schema varies by error code. |

### 9.3 Error Code Registry

#### 1xxx -- Transport Errors

| Code | Name | Description |
|------|------|-------------|
| 1001 | `connection_failed` | Unable to establish transport connection. |
| 1002 | `connection_lost` | Transport connection dropped unexpectedly. |
| 1003 | `timeout` | Transport-level timeout (no response within transport timeout). |
| 1004 | `serialization_error` | Message could not be serialized/deserialized. |
| 1005 | `message_too_large` | Message exceeds maximum size limit. |
| 1006 | `compression_error` | Compression or decompression failed. |

#### 2xxx -- Protocol Errors

| Code | Name | Description |
|------|------|-------------|
| 2001 | `unsupported_version` | ROSP version not supported. |
| 2002 | `incompatible_features` | No common features between platform and adapter. |
| 2003 | `unsupported_operation` | Operation not in the negotiated feature set. |
| 2004 | `invalid_path` | Path does not match ROSP path grammar. |
| 2005 | `invalid_message` | Message does not conform to envelope schema. |
| 2006 | `unknown_topic` | Requested stream topic does not exist on this robot. |
| 2007 | `duplicate_subscription` | Already subscribed to this topic. |
| 2008 | `session_not_initialized` | Operation attempted before `initialize` handshake. |
| 2009 | `session_expired` | Session token has expired. Re-authenticate. |

#### 3xxx -- Robot Errors

| Code | Name | Description |
|------|------|-------------|
| 3001 | `robot_unavailable` | Robot is offline, powered down, or unreachable. |
| 3002 | `robot_busy` | Robot is executing another command and cannot accept this one. |
| 3003 | `action_not_supported` | The requested action is not in the robot's capability set. |
| 3004 | `action_failed` | The action began but failed during execution. Details in `details`. |
| 3005 | `command_queue_full` | The adapter's command queue is at capacity. |
| 3006 | `hardware_fault` | A hardware fault prevents execution. |
| 3007 | `low_battery` | Battery too low to execute the requested action. |
| 3008 | `localization_lost` | Robot has lost localization and cannot navigate safely. |
| 3009 | `sensor_fault` | A required sensor is malfunctioning. |
| 3010 | `actuator_fault` | A required actuator is malfunctioning. |
| 3011 | `map_not_available` | Required map data is not loaded. |
| 3012 | `path_blocked` | Navigation path is blocked by an obstacle. |

#### 4xxx -- Authentication / Security Errors

| Code | Name | Description |
|------|------|-------------|
| 4001 | `authentication_failed` | Client certificate invalid, expired, or not trusted. |
| 4002 | `insufficient_permissions` | Authenticated role lacks permission for this operation. |
| 4003 | `session_token_invalid` | Session token is malformed or revoked. |
| 4004 | `session_token_expired` | Session token has expired. Re-authenticate. |
| 4005 | `rate_limited` | Too many requests. Retry after backoff. |
| 4006 | `certificate_expired` | Client or server certificate has expired. |

#### 5xxx -- Safety Errors

Safety errors indicate conditions that affect physical safety. When a 5xxx error occurs, the robot MUST transition to a safe state (as defined by the robot's safety configuration).

| Code | Name | Description |
|------|------|-------------|
| 5001 | `emergency_stop` | Emergency stop has been triggered (hardware or software). |
| 5002 | `command_expired` | Command's `expires_at` timestamp has passed. Command rejected. |
| 5003 | `kinematic_limit_exceeded` | Command parameters exceed the robot's kinematic limits. |
| 5004 | `safety_zone_violation` | Robot would enter a restricted safety zone. |
| 5005 | `watchdog_timeout` | Platform heartbeat not received within watchdog interval. Robot has stopped. |
| 5006 | `collision_imminent` | Collision detection triggered protective stop. |
| 5007 | `payload_overweight` | Detected payload exceeds maximum capacity. |
| 5008 | `environmental_hazard` | Environmental sensor detected unsafe conditions (temperature, gas, etc.). |

**Safe-state behavior:** When a 5xxx error is raised, the robot MUST:
1. Cease all motion immediately (protective stop).
2. Publish the error to all subscribed platforms.
3. Remain in safe state until an authorized operator (Controller role or higher) explicitly clears the condition.
4. Log the event in the audit log.

---

## 10. Versioning and Compatibility

### 10.1 Version Scheme

ROSP uses **semantic versioning** with two components: `MAJOR.MINOR`.

- **MAJOR** version changes indicate breaking changes to the protocol (message format, operation semantics, or security model changes that are not backward-compatible).
- **MINOR** version changes indicate backward-compatible additions (new optional fields, new operations, new error codes).

### 10.2 v0.1 Status

ROSP v0.1 is the initial draft specification. Breaking changes are expected before v1.0. Implementers SHOULD expect:
- Message envelope fields MAY be added or renamed.
- Operation body schemas MAY change.
- Error codes MAY be renumbered.
- Control Mode operations (`command`, `coordinate`) are explicitly DRAFT and WILL change.

Description Mode operations (`describe`, `stream`, `discover`) are considered stable within v0.1 and are the foundation for v1.0.

### 10.3 Backward Compatibility Strategy

1. **Capability negotiation ensures compatibility.** During the `initialize` handshake, both parties declare their supported protocol versions and features. An older robot (v0.1) connecting to a newer platform (v0.2) will negotiate to v0.1 and use only v0.1 features. The robot continues to work; it simply does not expose newer capabilities.

2. **Robot Card includes `rosp_version`.** The `identity.rosp_version` field in the Robot Card declares the ROSP version the adapter implements. Platforms use this to determine available operations.

3. **Unknown fields MUST be ignored.** Implementations MUST ignore unrecognized fields in message bodies. This allows newer senders to include additional fields without breaking older receivers.

4. **New operations are opt-in.** New operations added in minor versions are only available if both parties declare support during capability negotiation. An adapter that does not list `"coordinate"` in its features will never receive `coordinate` messages.

### 10.4 Version Negotiation

During `initialize`, the platform sends `protocol_versions: ["0.2", "0.1"]` (in preference order). The adapter selects the highest version it supports and responds with `protocol_version: "0.1"`. Both parties then use v0.1 semantics for the session.

If there is no common version, the adapter responds with error code `2001` (unsupported version) and closes the connection.

---

## Appendix A: Robot Card Schema

The Robot Card is the primary data structure in ROSP. It is returned by the `describe` operation and cached by platforms. The full JSON Schema is defined below.

### Top-Level Fields

| Field | Type | Required | Description |
|-------|------|----------|-------------|
| `robot_card_version` | string | Yes | ISO 8601 timestamp of this Robot Card revision. Used for cache invalidation. |
| `identity` | object | Yes | Robot identity and classification. |
| `physical` | object | No | Physical specifications (dimensions, weight, payload). |
| `sensors` | array | No | Sensor inventory and specifications. |
| `actuators` | array | No | Actuator inventory and specifications. |
| `capabilities` | array | No | Machine-readable capability declarations. |
| `capabilities_summary` | string[] | No | Short list of capability type identifiers. |
| `safety` | object | No | Safety configuration and certifications. |
| `endpoints` | object | Yes | ROSP communication endpoints. |

### Identity Object

| Field | Type | Required | Description |
|-------|------|----------|-------------|
| `robot_id` | string | Yes | Unique robot identifier. |
| `manufacturer` | string | Yes | Robot manufacturer name. |
| `model` | string | Yes | Robot model name. |
| `serial_number` | string | No | Hardware serial number. |
| `firmware_version` | string | No | Current firmware version. |
| `rosp_version` | string | Yes | ROSP version implemented by the adapter. |
| `type` | string | Yes | Robot type: `"mobile_robot"`, `"manipulator"`, `"humanoid"`, `"drone"`, `"fixed_industrial"`, `"quadruped"`, `"custom"`. |
| `description` | string | No | Human-readable description. |

### Sensor Object (array element)

| Field | Type | Required | Description |
|-------|------|----------|-------------|
| `sensor_id` | string | Yes | Unique sensor identifier within this robot. |
| `type` | string | Yes | Sensor type (e.g., `"lidar_2d"`, `"lidar_3d"`, `"camera_rgb"`, `"camera_depth"`, `"imu_6dof"`, `"imu_9dof"`, `"force_torque"`, `"proximity"`, `"encoder"`, `"gps"`, `"power_monitor"`). |
| `manufacturer` | string | No | Sensor manufacturer. |
| `model` | string | No | Sensor model. |
| `mount_position` | object | No | Position and orientation in the robot's coordinate frame. Fields: `x`, `y`, `z` (meters), `frame` (reference frame ID). |
| `specifications` | object | No | Sensor-specific technical specifications. Schema varies by sensor type. |
| `topics` | array | Yes | Available data topics for this sensor. |

### Sensor Topic Object (array element)

| Field | Type | Required | Description |
|-------|------|----------|-------------|
| `topic_id` | string | Yes | Topic identifier within this sensor. Used in stream `topics` paths. |
| `data_type` | string | Yes | Data type identifier (e.g., `"laser_scan"`, `"point_cloud_2d"`, `"orientation_quaternion"`, `"imu_raw"`, `"battery_status"`, `"rgb_image"`, `"depth_image"`). |
| `frequency_hz` | number | Yes | Native publish frequency in Hz. |
| `encoding` | string | Yes | Default encoding: `"json"`, `"cbor"`, `"protobuf"`, `"binary"`. |
| `schema` | object | No | JSON Schema describing the `data` field structure in stream messages. |

### Actuator Object (array element)

| Field | Type | Required | Description |
|-------|------|----------|-------------|
| `actuator_id` | string | Yes | Unique actuator identifier within this robot. |
| `type` | string | Yes | Actuator type (e.g., `"differential_drive"`, `"omnidirectional_drive"`, `"ackermann_drive"`, `"revolute_joint"`, `"prismatic_joint"`, `"gripper"`, `"linear_lift"`, `"propeller"`). |
| `commands` | array | Yes | Available command interfaces for this actuator. |

### Actuator Command Object (array element)

| Field | Type | Required | Description |
|-------|------|----------|-------------|
| `command_id` | string | Yes | Command identifier. Used as the `action` field in `command` messages. |
| `data_type` | string | Yes | Parameter data type (e.g., `"twist_2d"`, `"joint_position"`, `"float"`, `"bool"`). |
| `unit` | string | No | Unit of measurement (SI). |
| `description` | string | No | Human-readable description. |
| `limits` | object | No | Min/max/step constraints. |

### Capability Object (array element)

| Field | Type | Required | Description |
|-------|------|----------|-------------|
| `capability_id` | string | Yes | Unique capability identifier. |
| `type` | string | Yes | Capability type (e.g., `"autonomous_navigation"`, `"teleoperation"`, `"pick_and_place"`, `"cargo_transport"`, `"inspection"`, `"mapping"`). |
| `description` | string | No | Human-readable description of what this capability does. |
| `parameters` | object | No | Capability-specific parameters and constraints. |
| `required_sensors` | string[] | No | Sensor IDs required for this capability. |
| `required_actuators` | string[] | No | Actuator IDs required for this capability. |

### Safety Object

| Field | Type | Required | Description |
|-------|------|----------|-------------|
| `emergency_stop` | boolean | Yes | Whether the robot has a hardware emergency stop. |
| `safety_rated_speed_ms` | number | No | Maximum speed in safety-rated mode (m/s). |
| `protective_stop_distance_m` | number | No | Distance at which protective stop activates (m). |
| `safety_zones` | array | No | Configured safety zones. |
| `certifications` | string[] | No | Safety certifications (e.g., `"ISO_3691-4"`, `"ISO_10218"`, `"CE"`, `"UL"`, `"IEC_62443"`). |

### Endpoints Object

| Field | Type | Required | Description |
|-------|------|----------|-------------|
| `primary` | string | Yes | Primary ROSP endpoint URI. Format: `{transport}://{host}:{port}[/path]`. Examples: `zenoh://192.168.10.107:7447`, `grpc://robot.example.com:50051`, `wss://192.168.10.107:9443/rosp`, `mqtt://broker.example.com:8883`. |
| `fallback` | string | No | Fallback endpoint URI, used if primary is unreachable. |

---

## Appendix B: Type Definitions

### Common Data Types

These data types are referenced throughout the specification in sensor topics, actuator commands, and capability parameters.

#### Pose2D

```json
{
  "x": 12.5,
  "y": 7.3,
  "theta": 1.57
}
```

| Field | Type | Unit | Description |
|-------|------|------|-------------|
| `x` | number | meters | X position. |
| `y` | number | meters | Y position. |
| `theta` | number | radians | Orientation (yaw). |

#### Pose3D

```json
{
  "position": { "x": 1.0, "y": 2.0, "z": 0.5 },
  "orientation": { "x": 0.0, "y": 0.0, "z": 0.707, "w": 0.707 }
}
```

| Field | Type | Description |
|-------|------|-------------|
| `position` | object | XYZ position in meters. |
| `orientation` | object | Quaternion (x, y, z, w). |

#### Twist2D

```json
{
  "linear_ms": 1.0,
  "angular_rads": 0.5
}
```

| Field | Type | Unit | Description |
|-------|------|------|-------------|
| `linear_ms` | number | m/s | Linear velocity. |
| `angular_rads` | number | rad/s | Angular velocity. |

#### LaserScan

```json
{
  "angle_min_rad": -2.356,
  "angle_max_rad": 2.356,
  "angle_increment_rad": 0.00576,
  "range_min_m": 0.05,
  "range_max_m": 25.0,
  "ranges": [1.2, 1.3, 1.5, "..."],
  "intensities": [100, 120, 95, "..."]
}
```

#### OrientationQuaternion

```json
{
  "x": 0.001,
  "y": -0.003,
  "z": 0.707,
  "w": 0.707
}
```

Unit quaternion (x, y, z, w). MUST be normalized: x^2 + y^2 + z^2 + w^2 = 1.

#### IMURaw

```json
{
  "linear_acceleration": { "x": 0.02, "y": -0.01, "z": 9.81 },
  "angular_velocity": { "x": 0.001, "y": 0.002, "z": -0.001 }
}
```

| Field | Unit |
|-------|------|
| `linear_acceleration` | m/s^2 |
| `angular_velocity` | rad/s |

#### BatteryStatus

```json
{
  "voltage_v": 48.2,
  "current_a": -2.5,
  "charge_percent": 84,
  "temperature_c": 32.1,
  "charging": false,
  "estimated_remaining_s": 14400
}
```

### Units Convention

All ROSP data MUST use SI units unless explicitly stated otherwise:

| Quantity | Unit | Abbreviation |
|----------|------|-------------|
| Length | meter | m |
| Mass | kilogram | kg |
| Time | second | s |
| Angle | radian | rad |
| Linear velocity | meters per second | m/s |
| Angular velocity | radians per second | rad/s |
| Linear acceleration | meters per second squared | m/s^2 |
| Force | newton | N |
| Torque | newton-meter | Nm |
| Temperature | degree Celsius | C |
| Voltage | volt | V |
| Current | ampere | A |
| Energy | watt-hour | Wh |

Degree-based fields (e.g., sensor angular range specifications) MUST have `_deg` suffix in the field name. All operational data (commands, stream data, feedback) MUST use radians.

---

## Appendix C: Conformance Levels

### Level 1: Description (Minimum Conformance)

A Level 1 implementation MUST support:
- Message envelope (Section 4)
- `describe` operation (Section 5.1)
- `discover` operation (Section 5.3) via at least one mechanism
- Capability negotiation `initialize` handshake (Section 6)
- mTLS authentication (Section 8.1)
- Error handling (Section 9)
- At least one transport binding (Section 7)

### Level 2: Streaming

A Level 2 implementation includes Level 1 and MUST additionally support:
- `stream` operation (Section 5.2) including subscribe, QoS negotiation, and unsubscribe
- At least 10 concurrent subscriptions per session

### Level 3: Control (requires v1.0 finalization)

A Level 3 implementation includes Level 2 and MUST additionally support:
- `command` operation (Section 5.4)
- RBAC enforcement (Section 8.2)
- Audit logging (Section 8.3)
- Command safety: `expires_at`, watchdog heartbeat, kinematic validation (Section 8.4)

### Level 4: Fleet (requires v1.0 finalization)

A Level 4 implementation includes Level 3 and MUST additionally support:
- `coordinate` operation (Section 5.5)
- Wildcard path handling (`/fleet/{fleet_id}/robot/*`)
- Multi-robot status aggregation

---

---

## References

### Normative References

| ID | Standard | Description |
|----|----------|-------------|
| [WoT-TD] | W3C Web of Things Thing Description 2.0 | Core data model for robot description (Properties, Actions, Events). https://www.w3.org/TR/wot-thing-description11/ |
| [SOSA/SSN] | W3C/OGC Sensor, Observation, Sample, Actuator Ontology | Sensor capability metadata (accuracy, precision, resolution, frequency, drift). https://www.w3.org/TR/vocab-ssn/ |
| [IEEE-1872] | IEEE Standard Ontologies for Robotics and Automation (CORA) | Robot taxonomy: Robot, RobotPart, RobotGroup, RoboticSystem. https://standards.ieee.org/standard/1872-2015.html |
| [VDA-5050] | VDA 5050 v2.1.0 | AGV/AMR fleet communication standard (JSON over MQTT). https://github.com/VDA5050/VDA5050 |
| [JSON-Schema] | JSON Schema Draft 2020-12 | Schema language for Robot Card validation. https://json-schema.org/draft/2020-12/json-schema-core |
| [RFC-8259] | The JavaScript Object Notation (JSON) Data Interchange Format | Message envelope serialization. https://datatracker.ietf.org/doc/html/rfc8259 |
| [RFC-3339] | Date and Time on the Internet: Timestamps | Timestamp format (ISO 8601 profile). https://datatracker.ietf.org/doc/html/rfc3339 |
| [RFC-8446] | The Transport Layer Security (TLS) Protocol Version 1.3 | Transport encryption baseline. https://datatracker.ietf.org/doc/html/rfc8446 |
| [RFC-6762] | Multicast DNS | Local network robot discovery. https://datatracker.ietf.org/doc/html/rfc6762 |
| [RFC-6763] | DNS-Based Service Discovery | Service advertisement for `_rosp._tcp`. https://datatracker.ietf.org/doc/html/rfc6763 |

### Informative References

| ID | Reference | Description |
|----|-----------|-------------|
| [MCP] | Model Context Protocol (Anthropic, 2024) | Architectural inspiration for capability negotiation and transport-agnostic design. Now governed by Linux Foundation Agentic AI Foundation. https://modelcontextprotocol.io/ |
| [RCP] | Robot Context Protocol (Lee & Lau, arXiv:2506.11650, June 2025) | Prior art for single-robot agent-aware control. ROSP extends RCP with fleet management, security, multi-robot coordination, and non-ROS2 protocol support. https://arxiv.org/abs/2506.11650 |
| [ros-mcp-server] | MCP-ROS2 Bridge (1,105 GitHub stars) | Community-validated approach to MCP-robot connectivity. Informs the ROS2 adapter design. https://github.com/robotmcp/ros-mcp-server |
| [RynnRCP] | Alibaba DAMO Academy RCP implementation (Apache 2.0) | Independent RCP implementation using MQTT/Protobuf. Device authentication pattern adopted for edge security. https://github.com/alibaba-damo-academy/RynnRCP |
| [Zenoh] | Eclipse Zenoh | Recommended primary transport. 7-16us latency, 60 Gbps, 97-99% less discovery overhead than DDS. https://zenoh.io/ |
| [OpenRMF] | Open Robotics Middleware Framework | Multi-robot fleet coordination reference. Adapter pattern influences ROSP's fleet adapter design. https://www.open-rmf.org/ |
| [OPC-UA-Rob] | OPC UA Robotics Companion Specification (VDMA 40010) | Industrial robot information model for FANUC/KUKA/ABB. OPC UA adapter maps this to ROSP. https://opcfoundation.org/markets-collaboration/robotics/ |
| [Matter] | Matter Smart Home Protocol (CSA) | Commissioning flow (PASE → CASE) inspires ROSP robot onboarding. Multi-fabric model informs multi-tenant fleet management. https://csa-iot.org/all-solutions/matter/ |
| [ISO-10218] | ISO 10218:2025 — Safety requirements for industrial robots | Safety constraints and cybersecurity requirements referenced in ROSP security model. |
| [IEC-62443] | IEC 62443 — Industrial Automation and Control Systems Security | Security framework for RBAC, zone segmentation, and compliance mapping. |
| [EU-MR] | EU Machinery Regulation 2023/1230 (effective Jan 2027) | Cybersecurity and AI governance requirements. ROSP's audit logging and safety interlocks designed for compliance. |
| [IEEE-1588] | IEEE 1588 Precision Time Protocol | Sub-microsecond time synchronization for heterogeneous sensor streams. |
| [MCAP] | MCAP Multi-Channel Data Format | Robot data recording format for telemetry archival and replay. https://mcap.dev/ |

### Research References

| ID | Reference | Finding |
|----|-----------|---------|
| [RS-01] | RoboSwarm Fleet Orchestration Research (Track 01) | AMR fleet orchestration growing at 138% CAGR. VDA 5050 is the converging standard. |
| [RS-02] | RoboSwarm NVIDIA Stack Research (Track 02) | Isaac Sim, Newton 1.0 are free/open-source. Newton 252-475x faster than MJX. |
| [RS-06] | RoboSwarm Academic MRTA Research (Track 06) | Zenoh outperforms DDS by 97-99% for discovery. LaCAM scales to 10K+ agents. |
| [RS-09] | RoboSwarm Robot Onboarding Research (Track 09) | No existing standard for robot capabilities. Integration takes 2 weeks to 6 months. |
| [RS-12] | RoboSwarm Robot Context Protocol Research (Track 12) | N x M problem: 350+ robots x 145+ platforms = 50K+ integrations at 4-6x robot cost. |
| [RS-13] | RoboSwarm IoT Device Standards Research (Track 13) | WoT TD 2.0 is strongest fit for robot description. Layered standard stack validated. |
| [RS-14] | RoboSwarm Data Transport Research (Track 14) | Sensor data spans 6 orders of magnitude. Three-tier architecture is necessary. |
| [RS-16] | RoboSwarm Security Research (Track 16) | Documented robot hacking incidents. EU 2027 regulations require cybersecurity. |

---

*End of ROSP v0.1 Specification.*

*This document is licensed under Apache 2.0. Contributions and feedback are welcome.*
